<?php
/** Persistence gateway for Glute Lab operations. @package GluteLabChildTheme */
if ( ! defined( 'ABSPATH' ) ) exit;

function glutelab_app_now_utc() { return gmdate( 'Y-m-d H:i:s' ); }
function glutelab_app_reference( $prefix ) { return strtoupper( sanitize_key( $prefix ) ) . '-' . gmdate( 'ymd' ) . '-' . strtoupper( substr( wp_generate_uuid4(), 0, 8 ) ); }

function glutelab_app_upsert_customer( array $data ) {
	global $wpdb;
	$email = sanitize_email( $data['email'] ?? '' );
	if ( ! $email || ! is_email( $email ) ) return new WP_Error( 'invalid_email', __( 'Inserisci un indirizzo email valido.', 'glutelab-child-theme' ) );
	$table = glutelab_app_table( 'customers' ); $now = glutelab_app_now_utc();
	$id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE email = %s", $email ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	$row = array( 'email' => $email, 'first_name' => sanitize_text_field( $data['first_name'] ?? '' ), 'last_name' => sanitize_text_field( $data['last_name'] ?? '' ), 'phone' => sanitize_text_field( $data['phone'] ?? '' ), 'locale' => sanitize_text_field( $data['locale'] ?? get_locale() ), 'updated_at' => $now );
	if ( $id ) { $wpdb->update( $table, $row, array( 'id' => $id ) ); return $id; }
	$row['created_at'] = $now; return $wpdb->insert( $table, $row ) ? (int) $wpdb->insert_id : new WP_Error( 'customer_write_failed', __( 'Non è stato possibile salvare il contatto.', 'glutelab-child-theme' ) );
}

function glutelab_app_get_customer( $customer_id ) { global $wpdb; $table = glutelab_app_table( 'customers' ); return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $customer_id ), ARRAY_A ); } // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
function glutelab_app_get_order( $order_id ) { global $wpdb; $table = glutelab_app_table( 'orders' ); return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $order_id ), ARRAY_A ); } // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
function glutelab_app_get_order_by_reference( $reference ) { global $wpdb; $table = glutelab_app_table( 'orders' ); return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE reference = %s", sanitize_text_field( $reference ) ), ARRAY_A ); } // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
function glutelab_app_get_booking( $booking_id ) { global $wpdb; $table = glutelab_app_table( 'bookings' ); return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $booking_id ), ARRAY_A ); } // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

function glutelab_app_create_order( array $data ) {
	global $wpdb; $now = glutelab_app_now_utc();
	$row = array( 'reference' => glutelab_app_reference( 'GL' ), 'customer_id' => (int) $data['customer_id'], 'package_id' => sanitize_key( $data['package_id'] ), 'amount_cents' => max( 0, (int) $data['amount_cents'] ), 'currency' => 'CHF', 'payment_method' => sanitize_key( $data['payment_method'] ), 'status' => sanitize_key( $data['status'] ?? 'pending' ), 'credits_granted' => 0, 'created_at' => $now, 'updated_at' => $now );
	return $wpdb->insert( glutelab_app_table( 'orders' ), $row ) ? array_merge( $row, array( 'id' => (int) $wpdb->insert_id ) ) : new WP_Error( 'order_write_failed', __( 'Non è stato possibile creare la richiesta.', 'glutelab-child-theme' ) );
}

function glutelab_app_slot_capacity( $package ) { return max( 1, (int) ( $package['max_participants'] ?? 1 ) ); }
function glutelab_app_create_booking( array $data, array $package ) {
	global $wpdb; $table = glutelab_app_table( 'bookings' ); $start = $data['start_at_utc'] ?? null; $end = $data['end_at_utc'] ?? null; $service = sanitize_key( $package['group_id'] ?? $package['id'] );
	$lock_name = 'glutelab-service-' . get_current_blog_id() . '-' . md5( $service );
	$wpdb->query( 'START TRANSACTION' );
	try {
		if ( $start && ! $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 5)', $lock_name ) ) ) throw new RuntimeException( 'slot_locked' );
		if ( $start && $end ) {
			$overlapping = (array) $wpdb->get_results( $wpdb->prepare( "SELECT start_at_utc, end_at_utc, seats FROM {$table} WHERE service_key = %s AND start_at_utc < %s AND end_at_utc > %s AND status IN ('pending','requested','confirmed','paid') AND (status <> 'pending' OR expires_at IS NULL OR expires_at > UTC_TIMESTAMP())", $service, $end, $start ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$used = glutelab_app_interval_peak_seats( $overlapping, $start, $end );
			if ( $used + max( 1, (int) ( $data['seats'] ?? 1 ) ) > glutelab_app_slot_capacity( $package ) ) throw new RuntimeException( 'slot_unavailable' );
		}
		$now = glutelab_app_now_utc();
		$row = array( 'reference' => glutelab_app_reference( 'PREN' ), 'customer_id' => (int) $data['customer_id'], 'package_id' => sanitize_key( $package['id'] ), 'service_key' => $service, 'order_id' => ! empty( $data['order_id'] ) ? (int) $data['order_id'] : null, 'preferred_date' => ! empty( $data['preferred_date'] ) ? sanitize_text_field( $data['preferred_date'] ) : null, 'start_at_utc' => $start, 'end_at_utc' => $end, 'seats' => max( 1, (int) ( $data['seats'] ?? 1 ) ), 'status' => sanitize_key( $data['status'] ?? 'pending' ), 'credits_used' => 0, 'notes' => sanitize_textarea_field( $data['notes'] ?? '' ), 'expires_at' => $data['expires_at'] ?? null, 'created_at' => $now, 'updated_at' => $now );
		if ( ! $wpdb->insert( $table, $row ) ) throw new RuntimeException( 'booking_write_failed' );
		$row['id'] = (int) $wpdb->insert_id; $wpdb->query( 'COMMIT' );
		if ( $start ) $wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock_name ) );
		return $row;
	} catch ( Throwable $error ) {
		$wpdb->query( 'ROLLBACK' ); if ( $start ) $wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock_name ) );
		return new WP_Error( $error->getMessage(), 'slot_unavailable' === $error->getMessage() ? __( 'L’orario selezionato non è più disponibile.', 'glutelab-child-theme' ) : __( 'Non è stato possibile creare la prenotazione.', 'glutelab-child-theme' ) );
	}
}

function glutelab_app_filter_available_slots( array $slots, array $package ) {
	global $wpdb; if ( ! $slots ) return array(); $table = glutelab_app_table( 'bookings' ); $service = sanitize_key( $package['group_id'] ?? $package['id'] ); $capacity = glutelab_app_slot_capacity( $package );
	$valid_slots = array_values( array_filter( $slots, static fn( $slot ) => ! empty( $slot['utc'] ) && ! empty( $slot['end_utc'] ) ) );
	if ( ! $valid_slots ) return array();
	$starts = array_column( $valid_slots, 'utc' ); $ends = array_column( $valid_slots, 'end_utc' );
	$range_start = min( $starts ); $range_end = max( $ends );
	$bookings = (array) $wpdb->get_results( $wpdb->prepare( "SELECT start_at_utc, end_at_utc, seats FROM {$table} WHERE service_key = %s AND start_at_utc < %s AND end_at_utc > %s AND status IN ('pending','requested','confirmed','paid') AND (status <> 'pending' OR expires_at IS NULL OR expires_at > UTC_TIMESTAMP())", $service, $range_end, $range_start ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	return array_values( array_filter( $valid_slots, static function ( $slot ) use ( $bookings, $capacity ) {
		return glutelab_app_interval_peak_seats( $bookings, $slot['utc'], $slot['end_utc'] ) < $capacity;
	} ) );
}

function glutelab_app_credit_balance( $customer_id ) { global $wpdb; $table = glutelab_app_table( 'credit_ledger' ); return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(delta),0) FROM {$table} WHERE customer_id = %d", (int) $customer_id ) ); } // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

function glutelab_app_add_credit_entry( array $data ) {
	global $wpdb; $table = glutelab_app_table( 'credit_ledger' ); $key = sanitize_text_field( $data['idempotency_key'] );
	$existing = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE idempotency_key = %s", $key ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	if ( $existing ) return $existing;
	$balance = glutelab_app_credit_balance( (int) $data['customer_id'] ) + (int) $data['delta'];
	$row = array( 'customer_id' => (int) $data['customer_id'], 'order_id' => ! empty( $data['order_id'] ) ? (int) $data['order_id'] : null, 'booking_id' => ! empty( $data['booking_id'] ) ? (int) $data['booking_id'] : null, 'delta' => (int) $data['delta'], 'balance_after' => $balance, 'reason' => sanitize_key( $data['reason'] ), 'idempotency_key' => $key, 'note' => sanitize_text_field( $data['note'] ?? '' ), 'created_at' => glutelab_app_now_utc() );
	return $wpdb->insert( $table, $row ) ? (int) $wpdb->insert_id : new WP_Error( 'credit_write_failed', __( 'Non è stato possibile aggiornare i crediti.', 'glutelab-child-theme' ) );
}

function glutelab_app_admin_rows( $type, $limit = 100 ) {
	global $wpdb; $allowed = array( 'customers', 'orders', 'bookings', 'credit_ledger' ); if ( ! in_array( $type, $allowed, true ) ) return array();
	$table = glutelab_app_table( $type ); return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} ORDER BY id DESC LIMIT %d", min( 250, max( 1, (int) $limit ) ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
}

/**
 * Load all request choices for the customers currently shown in the admin list.
 *
 * The join keeps orders without a booking visible and avoids one query per
 * customer. Results are grouped newest-first by customer identifier.
 *
 * @param int[] $customer_ids Customer identifiers from the current table.
 * @return array<int,array<int,array<string,mixed>>>
 */
function glutelab_app_customer_requests_by_customer( array $customer_ids ) {
	global $wpdb;
	$customer_ids = array_values( array_unique( array_filter( array_map( 'absint', $customer_ids ) ) ) );
	sort( $customer_ids, SORT_NUMERIC );
	if ( ! $customer_ids ) return array();

	$orders       = glutelab_app_table( 'orders' );
	$bookings     = glutelab_app_table( 'bookings' );
	$placeholders = implode( ',', array_fill( 0, count( $customer_ids ), '%d' ) );
	$query        = "SELECT o.id AS order_id, o.reference AS order_reference, o.customer_id, o.package_id, o.payment_method, o.status AS order_status, o.created_at, b.id AS booking_id, b.preferred_date, b.start_at_utc, b.end_at_utc FROM {$orders} o LEFT JOIN {$bookings} b ON b.order_id = o.id WHERE o.customer_id IN ({$placeholders}) ORDER BY o.created_at DESC, o.id DESC";
	$rows         = (array) $wpdb->get_results( $wpdb->prepare( $query, $customer_ids ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	$grouped      = array_fill_keys( $customer_ids, array() );

	foreach ( $rows as $row ) {
		$customer_id = (int) ( $row['customer_id'] ?? 0 );
		if ( isset( $grouped[ $customer_id ] ) ) $grouped[ $customer_id ][] = $row;
	}

	return $grouped;
}
