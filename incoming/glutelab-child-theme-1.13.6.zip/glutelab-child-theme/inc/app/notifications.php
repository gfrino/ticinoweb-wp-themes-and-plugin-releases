<?php
/** Reminder scheduling and delivery. @package GluteLabChildTheme */
if ( ! defined( 'ABSPATH' ) ) exit;

function glutelab_app_schedule_reminders() { if ( ! wp_next_scheduled( 'glutelab_app_send_reminders' ) ) wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', 'glutelab_app_send_reminders' ); }
function glutelab_app_unschedule_reminders() { $timestamp = wp_next_scheduled( 'glutelab_app_send_reminders' ); if ( $timestamp ) wp_unschedule_event( $timestamp, 'glutelab_app_send_reminders' ); }
function glutelab_app_send_reminders() {
	global $wpdb; $settings = glutelab_app_get_settings(); if ( empty( $settings['enabled'] ) || empty( $settings['reminder_hours'] ) ) return;
	$from = gmdate( 'Y-m-d H:i:s', time() + ( max( 1, (int) $settings['reminder_hours'] ) - 1 ) * HOUR_IN_SECONDS ); $to = gmdate( 'Y-m-d H:i:s', time() + ( (int) $settings['reminder_hours'] + 1 ) * HOUR_IN_SECONDS );
	$bookings = glutelab_app_table( 'bookings' ); $customers = glutelab_app_table( 'customers' );
	$rows = $wpdb->get_results( $wpdb->prepare( "SELECT b.id,b.reference,b.start_at_utc,b.package_id,c.email,c.first_name FROM {$bookings} b INNER JOIN {$customers} c ON c.id=b.customer_id WHERE b.status IN ('confirmed','paid') AND b.reminder_sent_at IS NULL AND b.start_at_utc BETWEEN %s AND %s LIMIT 100", $from, $to ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	foreach ( $rows as $row ) {
		$package = glutelab_get_package( $row['package_id'] ); $local = get_date_from_gmt( $row['start_at_utc'], 'd.m.Y H:i' );
		$sent = wp_mail( $row['email'], __( 'Promemoria appuntamento Glute Lab', 'glutelab-child-theme' ), sprintf( __( "Ciao %1$s,\n\nti ricordiamo l’appuntamento Glute Lab per %2$s il %3$s.\nRiferimento: %4$s.", 'glutelab-child-theme' ), $row['first_name'], $package ? $package['title'] : $row['package_id'], $local, $row['reference'] ) );
		if ( $sent ) $wpdb->update( $bookings, array( 'reminder_sent_at' => glutelab_app_now_utc() ), array( 'id' => (int) $row['id'] ) );
	}
}
add_action( 'glutelab_app_send_reminders', 'glutelab_app_send_reminders' );

