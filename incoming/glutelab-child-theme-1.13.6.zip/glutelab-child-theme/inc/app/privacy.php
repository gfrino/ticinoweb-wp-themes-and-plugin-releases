<?php
/** WordPress privacy integration for Glute Lab records. @package GluteLabChildTheme */
if ( ! defined( 'ABSPATH' ) ) exit;

function glutelab_app_privacy_policy() {
	if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) return;
	wp_add_privacy_policy_content( 'Glute Lab', wp_kses_post( '<p>' . __( 'Quando invii una richiesta Glute Lab conserviamo nome, cognome, email, telefono, offerta scelta, eventuale orario, note, stato del pagamento e movimenti dei crediti per gestire il servizio. I pagamenti online vengono elaborati da Stripe; nel sito conserviamo soltanto gli identificativi tecnici e lo stato, non i dati completi della carta.', 'glutelab-child-theme' ) . '</p>' ) );
}
add_action( 'admin_init', 'glutelab_app_privacy_policy' );

function glutelab_app_register_exporter( $exporters ) { $exporters['glutelab'] = array( 'exporter_friendly_name' => 'Glute Lab', 'callback' => 'glutelab_app_personal_data_exporter' ); return $exporters; }
add_filter( 'wp_privacy_personal_data_exporters', 'glutelab_app_register_exporter' );
function glutelab_app_register_eraser( $erasers ) { $erasers['glutelab'] = array( 'eraser_friendly_name' => 'Glute Lab', 'callback' => 'glutelab_app_personal_data_eraser' ); return $erasers; }
add_filter( 'wp_privacy_personal_data_erasers', 'glutelab_app_register_eraser' );

function glutelab_app_personal_data_exporter( $email_address, $page = 1 ) {
	global $wpdb; $customer_table = glutelab_app_table( 'customers' ); $customer = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$customer_table} WHERE email = %s", sanitize_email( $email_address ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	if ( ! $customer ) return array( 'data' => array(), 'done' => true );
	$page = max( 1, (int) $page ); $limit = 100; $offset = ( $page - 1 ) * $limit; $orders_table = glutelab_app_table( 'orders' );
	$data = 1 === $page ? array( array( 'group_id' => 'glutelab-customer', 'group_label' => 'Glute Lab', 'item_id' => 'glutelab-customer-' . $customer['id'], 'data' => array( array( 'name' => __( 'Nome', 'glutelab-child-theme' ), 'value' => $customer['first_name'] ), array( 'name' => __( 'Cognome', 'glutelab-child-theme' ), 'value' => $customer['last_name'] ), array( 'name' => __( 'Email', 'glutelab-child-theme' ), 'value' => $customer['email'] ), array( 'name' => __( 'Telefono', 'glutelab-child-theme' ), 'value' => $customer['phone'] ), array( 'name' => __( 'Crediti disponibili', 'glutelab-child-theme' ), 'value' => glutelab_app_credit_balance( $customer['id'] ) ) ) ) ) : array();
	$orders = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$orders_table} WHERE customer_id = %d ORDER BY id ASC LIMIT %d OFFSET %d", (int) $customer['id'], $limit, $offset ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	foreach ( $orders as $order ) $data[] = array( 'group_id' => 'glutelab-orders', 'group_label' => __( 'Richieste e pagamenti Glute Lab', 'glutelab-child-theme' ), 'item_id' => 'glutelab-order-' . $order['id'], 'data' => array( array( 'name' => __( 'Riferimento', 'glutelab-child-theme' ), 'value' => $order['reference'] ), array( 'name' => __( 'Offerta', 'glutelab-child-theme' ), 'value' => $order['package_id'] ), array( 'name' => __( 'Stato', 'glutelab-child-theme' ), 'value' => $order['status'] ), array( 'name' => __( 'Data', 'glutelab-child-theme' ), 'value' => $order['created_at'] ) ) );
	return array( 'data' => $data, 'done' => count( $orders ) < $limit );
}

function glutelab_app_personal_data_eraser( $email_address, $page = 1 ) {
	global $wpdb; $table = glutelab_app_table( 'customers' ); $customer = $wpdb->get_row( $wpdb->prepare( "SELECT id FROM {$table} WHERE email = %s", sanitize_email( $email_address ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	if ( ! $customer ) return array( 'items_removed' => false, 'items_retained' => false, 'messages' => array(), 'done' => true );
	$id = (int) $customer['id']; $anonymous = 'deleted+' . $id . '@invalid.local';
	$wpdb->update( $table, array( 'email' => $anonymous, 'first_name' => '', 'last_name' => '', 'phone' => '', 'updated_at' => glutelab_app_now_utc() ), array( 'id' => $id ) );
	$wpdb->update( glutelab_app_table( 'bookings' ), array( 'notes' => '' ), array( 'customer_id' => $id ) );
	return array( 'items_removed' => true, 'items_retained' => true, 'messages' => array( __( 'I dati identificativi sono stati anonimizzati; i record contabili e il registro crediti vengono conservati senza dati di contatto.', 'glutelab-child-theme' ) ), 'done' => true );
}
