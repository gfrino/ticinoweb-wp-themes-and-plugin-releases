<?php
/** Minimal Stripe Checkout adapter using the WordPress HTTP API. @package GluteLabChildTheme */
if ( ! defined( 'ABSPATH' ) ) exit;

function glutelab_app_stripe_verify_signature( $payload, $header, $secret, $now = null, $tolerance = 300 ) {
	if ( ! $secret || ! is_string( $header ) ) return false;
	$parts = array(); foreach ( explode( ',', $header ) as $piece ) { $pair = array_map( 'trim', explode( '=', $piece, 2 ) ); if ( 2 === count( $pair ) ) $parts[ $pair[0] ][] = $pair[1]; }
	$timestamp = isset( $parts['t'][0] ) ? (int) $parts['t'][0] : 0; $now = null === $now ? time() : (int) $now;
	if ( ! $timestamp || abs( $now - $timestamp ) > (int) $tolerance || empty( $parts['v1'] ) ) return false;
	$expected = hash_hmac( 'sha256', $timestamp . '.' . $payload, $secret );
	foreach ( $parts['v1'] as $signature ) if ( hash_equals( $expected, $signature ) ) return true;
	return false;
}

/** Verify the event against the webhook secret belonging to its declared Stripe environment. */
function glutelab_app_stripe_verify_webhook_environment( $payload, $header, $now = null ) {
	$event = json_decode( $payload, true );
	if ( ! is_array( $event ) || ! array_key_exists( 'livemode', $event ) || ! is_bool( $event['livemode'] ) ) return false;
	$mode = ! empty( $event['livemode'] ) ? 'live' : 'test';
	$secret = glutelab_app_get_stripe_credential( 'webhook_secret', $mode );
	return glutelab_app_stripe_verify_signature( $payload, $header, $secret, $now ) ? $mode : false;
}

/**
 * Ensure that a signed Checkout event belongs to this site and exact order.
 *
 * @param array $session Stripe Checkout Session payload.
 * @param array $order   Local order row.
 * @param int   $site_id Current WordPress site ID.
 * @return bool
 */
function glutelab_app_stripe_session_matches_order( array $session, array $order, $site_id = null ) {
	$site_id = null === $site_id ? get_current_blog_id() : (int) $site_id;
	if ( (int) ( $session['metadata']['site_id'] ?? 0 ) !== $site_id || (int) ( $session['metadata']['order_id'] ?? 0 ) !== (int) ( $order['id'] ?? 0 ) ) {
		return false;
	}
	if ( ! hash_equals( (string) ( $order['reference'] ?? '' ), (string) ( $session['client_reference_id'] ?? '' ) ) ) {
		return false;
	}
	if ( strtolower( (string) ( $session['currency'] ?? '' ) ) !== strtolower( (string) ( $order['currency'] ?? '' ) ) || (int) ( $session['amount_total'] ?? -1 ) !== (int) ( $order['amount_cents'] ?? -2 ) ) {
		return false;
	}
	return empty( $order['stripe_session_id'] ) || hash_equals( (string) $order['stripe_session_id'], (string) ( $session['id'] ?? '' ) );
}

function glutelab_app_stripe_create_checkout( array $request ) {
	if ( ! glutelab_app_stripe_is_configured() ) return new WP_Error( 'stripe_not_configured', __( 'Il pagamento online non è ancora configurato.', 'glutelab-child-theme' ) );
	$secret = glutelab_app_get_secret( 'stripe_key' );
	$order = $request['order']; $package = $request['package']; $customer = glutelab_app_get_customer( $order['customer_id'] );
	if ( 'one_time' !== ( $package['price_model'] ?? '' ) || (int) $order['amount_cents'] < 50 ) return new WP_Error( 'unsupported_price', __( 'Questa offerta non è disponibile per il pagamento online.', 'glutelab-child-theme' ) );
	$success = add_query_arg( array( 'gl_result' => 'payment-return', 'reference' => $order['reference'], 'session_id' => '{CHECKOUT_SESSION_ID}' ), glutelab_page_url( 'acquista-o-prenota' ) );
	$success = str_replace( array( '%7BCHECKOUT_SESSION_ID%7D', '%7bCHECKOUT_SESSION_ID%7d' ), '{CHECKOUT_SESSION_ID}', $success );
	$cancel = add_query_arg( array( 'gl_result' => 'payment-cancelled', 'reference' => $order['reference'] ), glutelab_page_url( 'acquista-o-prenota' ) );
	$body = array( 'mode' => 'payment', 'automatic_payment_methods[enabled]' => 'true', 'success_url' => $success, 'cancel_url' => $cancel, 'client_reference_id' => $order['reference'], 'customer_email' => $customer['email'], 'line_items[0][quantity]' => 1, 'line_items[0][price_data][currency]' => 'chf', 'line_items[0][price_data][unit_amount]' => (int) $order['amount_cents'], 'line_items[0][price_data][product_data][name]' => $package['title'], 'metadata[order_id]' => (int) $order['id'], 'metadata[site_id]' => get_current_blog_id() );
	$response = wp_remote_post( 'https://api.stripe.com/v1/checkout/sessions', array( 'timeout' => 20, 'headers' => array( 'Authorization' => 'Bearer ' . $secret, 'Idempotency-Key' => 'glutelab-order-' . $order['id'] ), 'body' => $body ) );
	if ( is_wp_error( $response ) ) return $response; $data = json_decode( wp_remote_retrieve_body( $response ), true );
	if ( wp_remote_retrieve_response_code( $response ) >= 300 || empty( $data['id'] ) || empty( $data['url'] ) || 0 !== strpos( $data['url'], 'https://checkout.stripe.com/' ) ) return new WP_Error( 'stripe_checkout_failed', __( 'Non è stato possibile avviare il pagamento.', 'glutelab-child-theme' ) );
	global $wpdb; $wpdb->update( glutelab_app_table( 'orders' ), array( 'stripe_session_id' => sanitize_text_field( $data['id'] ), 'updated_at' => glutelab_app_now_utc() ), array( 'id' => (int) $order['id'] ) ); return $data['url'];
}

function glutelab_app_stripe_webhook( $request ) {
	$payload = $request->get_body(); $signature = $request->get_header( 'stripe-signature' );
	if ( false === glutelab_app_stripe_verify_webhook_environment( $payload, $signature ) ) return new WP_Error( 'invalid_signature', 'Invalid signature', array( 'status' => 400 ) );
	$event = json_decode( $payload, true ); $allowed = array( 'checkout.session.completed', 'checkout.session.async_payment_succeeded', 'checkout.session.async_payment_failed', 'checkout.session.expired' );
	if ( empty( $event['id'] ) || ! in_array( $event['type'] ?? '', $allowed, true ) ) return rest_ensure_response( array( 'received' => true ) );
	global $wpdb; $table = glutelab_app_table( 'webhook_events' ); $existing = $wpdb->get_row( $wpdb->prepare( "SELECT id, status FROM {$table} WHERE provider_event_id = %s", $event['id'] ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	if ( $existing && in_array( $existing['status'], array( 'processed', 'rejected' ), true ) ) return rest_ensure_response( array( 'received' => true, 'duplicate' => true ) );
	if ( $existing ) $wpdb->update( $table, array( 'status' => 'received', 'processed_at' => null ), array( 'id' => (int) $existing['id'] ) );
	else {
		$inserted = $wpdb->insert( $table, array( 'provider_event_id' => sanitize_text_field( $event['id'] ), 'event_type' => sanitize_text_field( $event['type'] ), 'status' => 'received', 'payload_hash' => hash( 'sha256', $payload ), 'created_at' => glutelab_app_now_utc() ) );
		if ( ! $inserted ) return new WP_Error( 'event_write_failed', 'Webhook event could not be stored', array( 'status' => 500 ) );
	}
	$session = $event['data']['object'] ?? array(); $order_id = absint( $session['metadata']['order_id'] ?? 0 );
	$order = $order_id ? glutelab_app_get_order( $order_id ) : null;
	if ( ! $order || ! glutelab_app_stripe_session_matches_order( $session, $order ) ) {
		$wpdb->update( $table, array( 'status' => 'rejected', 'processed_at' => glutelab_app_now_utc() ), array( 'provider_event_id' => $event['id'] ) );
		return rest_ensure_response( array( 'received' => true, 'processed' => false ) );
	}
	if ( in_array( $event['type'], array( 'checkout.session.completed', 'checkout.session.async_payment_succeeded' ), true ) && 'paid' === ( $session['payment_status'] ?? '' ) && $order_id ) {
		$finalized = glutelab_app_finalize_paid_order( $order_id, sanitize_text_field( $session['payment_intent'] ?? $session['id'] ?? '' ) );
		if ( is_wp_error( $finalized ) ) {
			$wpdb->update( $table, array( 'status' => 'failed', 'processed_at' => null ), array( 'provider_event_id' => $event['id'] ) );
			return new WP_Error( 'payment_finalization_failed', 'Payment finalization failed', array( 'status' => 500 ) );
		}
	}
	elseif ( $order_id && in_array( $event['type'], array( 'checkout.session.async_payment_failed', 'checkout.session.expired' ), true ) ) { $wpdb->update( glutelab_app_table( 'orders' ), array( 'status' => 'payment_failed', 'updated_at' => glutelab_app_now_utc() ), array( 'id' => $order_id ) ); if ( ! empty( $order['booking_id'] ) ) $wpdb->update( glutelab_app_table( 'bookings' ), array( 'status' => 'cancelled', 'updated_at' => glutelab_app_now_utc() ), array( 'id' => (int) $order['booking_id'] ) ); }
	$wpdb->update( $table, array( 'status' => 'processed', 'processed_at' => glutelab_app_now_utc() ), array( 'provider_event_id' => $event['id'] ) ); return rest_ensure_response( array( 'received' => true ) );
}

function glutelab_app_register_stripe_route() { register_rest_route( 'glutelab/v1', '/stripe/webhook', array( 'methods' => 'POST', 'callback' => 'glutelab_app_stripe_webhook', 'permission_callback' => '__return_true' ) ); }
