<?php
/** Glute Lab operational application bootstrap. @package GluteLabChildTheme */
if ( ! defined( 'ABSPATH' ) ) exit;

$glutelab_app_files = array( 'access', 'settings', 'schema', 'scheduling', 'credits', 'repository', 'payments', 'stripe', 'notifications', 'privacy', 'actions', 'admin', 'frontend' );
foreach ( $glutelab_app_files as $glutelab_app_file ) require_once __DIR__ . '/' . $glutelab_app_file . '.php';
unset( $glutelab_app_files, $glutelab_app_file );

add_action( 'after_switch_theme', 'glutelab_app_install_schema' );
add_action( 'admin_init', 'glutelab_app_maybe_upgrade_schema' );
add_action( 'admin_init', 'glutelab_app_schedule_reminders' );
add_action( 'rest_api_init', 'glutelab_app_register_stripe_route' );
add_action( 'rest_api_init', 'glutelab_app_register_slots_route' );
add_action( 'after_switch_theme', 'glutelab_app_schedule_reminders' );
add_action( 'switch_theme', 'glutelab_app_unschedule_reminders' );

