<?php
/** Credit rules. @package GluteLabChildTheme */
if ( ! defined( 'ABSPATH' ) ) exit;

function glutelab_app_package_credits( array $package ) {
	$purchased = isset( $package['lessons_purchased'] ) && null !== $package['lessons_purchased'] ? max( 0, (int) $package['lessons_purchased'] ) : 0;
	$bonus = isset( $package['bonus_lessons'] ) && null !== $package['bonus_lessons'] ? max( 0, (int) $package['bonus_lessons'] ) : 0;
	return $purchased + $bonus;
}

function glutelab_app_ledger_balance( array $entries ) {
	return array_reduce( $entries, static function ( $balance, $entry ) { return $balance + (int) ( $entry['delta'] ?? 0 ); }, 0 );
}

function glutelab_app_credit_reason_label( $reason ) {
	$labels = array( 'purchase' => __( 'Acquisto', 'glutelab-child-theme' ), 'booking' => __( 'Prenotazione', 'glutelab-child-theme' ), 'cancellation' => __( 'Annullamento', 'glutelab-child-theme' ), 'manual' => __( 'Rettifica manuale', 'glutelab-child-theme' ) );
	return $labels[ $reason ] ?? ucfirst( sanitize_key( $reason ) );
}
