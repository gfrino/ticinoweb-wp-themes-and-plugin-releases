<?php
/**
 * Read-only adapters for data owned by the parent CMS.
 *
 * @package GluteLabChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Pass dynamic strings through the parent translation compatibility layer. */
function glutelab_frontend_text( $value, $context ) {
	return function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( $value, $context ) : $value;
}

/** Pass dynamic URLs through the parent translation compatibility layer. */
function glutelab_frontend_url( $value, $context ) {
	return function_exists( 'ticinoweb_frontend_url' ) ? ticinoweb_frontend_url( $value, $context ) : $value;
}

/**
 * Return contact data using the parent API when available.
 *
 * @return array<string,mixed>
 */
function glutelab_get_contact_data() {
	if ( function_exists( 'ticinoweb_get_contact_info' ) ) {
		return (array) ticinoweb_get_contact_info();
	}

	return array(
		'phone'              => get_option( 'ticinoweb_contact_phone', '' ),
		'email'              => get_option( 'ticinoweb_contact_email', '' ),
		'address'            => get_option( 'ticinoweb_contact_address', '' ),
		'opening_hours'      => get_option( 'ticinoweb_contact_opening_hours', array() ),
		'opening_hours_note' => get_option( 'ticinoweb_contact_opening_hours_note', '' ),
	);
}

/**
 * Return configured slides.
 *
 * @return array<int,array<string,string>>
 */
function glutelab_get_slides() {
	return function_exists( 'ticinoweb_get_slider_data' ) ? (array) ticinoweb_get_slider_data() : array();
}

/**
 * Return complete Home slides with contiguous display positions.
 *
 * @return array<int,array<string,mixed>>
 */
function glutelab_get_home_slides() {
	$slides = array();

	foreach ( glutelab_get_slides() as $source_index => $slide ) {
		$slide = is_array( $slide ) ? $slide : array();
		$image = trim( (string) ( $slide['image'] ?? '' ) );
		$title = trim( (string) ( $slide['title'] ?? '' ) );

		if ( '' === $image || '' === $title ) {
			continue;
		}

		$slides[] = array(
			'image'       => $image,
			'title'       => glutelab_frontend_text( $title, 'glutelab:slider:' . $source_index . ':title' ),
			'description' => glutelab_frontend_text( trim( (string) ( $slide['desc'] ?? '' ) ), 'glutelab:slider:' . $source_index . ':description' ),
			'button_text' => glutelab_frontend_text( trim( (string) ( $slide['btn1_text'] ?? '' ) ), 'glutelab:slider:' . $source_index . ':button' ),
			'button_url'  => glutelab_frontend_url( trim( (string) ( $slide['btn1_link'] ?? '' ) ), 'glutelab:slider:' . $source_index . ':url' ),
			'position'    => count( $slides ) + 1,
		);
	}

	return $slides;
}

/**
 * Return configured services.
 *
 * @return array<int,array<string,mixed>>
 */
function glutelab_get_services() {
	return function_exists( 'ticinoweb_get_services' ) ? (array) ticinoweb_get_services() : (array) get_option( 'ticinoweb_services', array() );
}

/**
 * Split the Method page editor content into its H2-led sections.
 *
 * The copy remains owned by the WordPress page. This adapter only gives the
 * template enough structure to place those sections in distinct layouts.
 *
 * @param string $content Filtered WordPress page content.
 * @return array<int,array{title:string,content:string}>
 */
function glutelab_split_method_content( $content ) {
	if ( ! is_string( $content ) || '' === trim( $content ) ) {
		return array();
	}

	$matches = array();
	preg_match_all( '/<h2\b[^>]*>(.*?)<\/h2>\s*(.*?)(?=<h2\b[^>]*>|$)/is', $content, $matches, PREG_SET_ORDER );

	$sections = array();
	foreach ( $matches as $match ) {
		$title = trim( wp_strip_all_tags( html_entity_decode( $match[1], ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) );
		$body  = trim( $match[2] );
		if ( '' === $title || '' === $body ) {
			continue;
		}
		$sections[] = array(
			'title'   => $title,
			'content' => $body,
		);
	}

	return $sections;
}

/**
 * Return the generic Home process labels.
 *
 * @return array<int,string>
 */
function glutelab_get_home_process_steps() {
	$steps = array(
		__( 'Scegli la lezione o il pacchetto', 'glutelab-child-theme' ),
		__( 'Concorda giorno e orario', 'glutelab-child-theme' ),
		__( 'Svolgi la seduta seguita', 'glutelab-child-theme' ),
		__( 'Integra Glute Lab nel tuo allenamento', 'glutelab-child-theme' ),
	);

	return apply_filters( 'glutelab_home_process_steps', $steps );
}

/**
 * Resolve a page URL without assuming the installation path.
 *
 * @param string $slug Page slug.
 * @return string
 */
function glutelab_page_url( $slug ) {
	$page = get_page_by_path( sanitize_title( $slug ) );
	return $page ? get_permalink( $page ) : home_url( '/' . trim( $slug, '/' ) . '/' );
}

/**
 * Format the parent opening-hours structure.
 *
 * @return array<int,array{label:string,value:string}>
 */
function glutelab_get_opening_hours_rows() {
	$contact = glutelab_get_contact_data();
	$hours   = is_array( $contact['opening_hours'] ?? null ) ? $contact['opening_hours'] : array();
	$labels  = array(
		'monday' => __( 'Lunedì', 'glutelab-child-theme' ), 'tuesday' => __( 'Martedì', 'glutelab-child-theme' ),
		'wednesday' => __( 'Mercoledì', 'glutelab-child-theme' ), 'thursday' => __( 'Giovedì', 'glutelab-child-theme' ),
		'friday' => __( 'Venerdì', 'glutelab-child-theme' ), 'saturday' => __( 'Sabato', 'glutelab-child-theme' ),
		'sunday' => __( 'Domenica', 'glutelab-child-theme' ),
	);
	$rows = array();
	foreach ( $labels as $key => $label ) {
		if ( ! isset( $hours[ $key ] ) ) {
			continue;
		}
		$value = function_exists( 'ticinoweb_format_day_hours' ) ? ticinoweb_format_day_hours( $hours[ $key ] ) : '';
		if ( '' !== $value ) {
			$rows[] = array( 'label' => $label, 'value' => $value );
		}
	}
	return $rows;
}

/**
 * Render an image URL with stable accessibility and loading attributes.
 *
 * @param string $url     Image URL.
 * @param string $alt     Alternative text.
 * @param bool   $eager   Whether this is the LCP image.
 * @param string $class   CSS class.
 * @return void
 */
function glutelab_image( $url, $alt, $eager = false, $class = '' ) {
	if ( ! $url ) {
		return;
	}
	$attachment_id = attachment_url_to_postid( $url );
	if ( $attachment_id ) {
		$library_alt = trim( (string) get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ) );
		echo wp_get_attachment_image( $attachment_id, 'full', false, array(
			'alt' => '' !== $library_alt ? $library_alt : $alt, 'class' => $class, 'loading' => $eager ? 'eager' : 'lazy',
			'fetchpriority' => $eager ? 'high' : 'auto', 'decoding' => 'async',
		) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		return;
	}
	?>
	<img src="<?php echo esc_url( $url ); ?>" alt="<?php echo esc_attr( $alt ); ?>" class="<?php echo esc_attr( $class ); ?>" loading="<?php echo $eager ? 'eager' : 'lazy'; ?>"<?php echo $eager ? ' fetchpriority="high"' : ''; ?> decoding="async">
	<?php
}

/**
 * Return ordered attachment IDs from a parent-managed media gallery.
 *
 * @param string $slug Gallery term slug.
 * @return array<int,int>
 */
function glutelab_get_gallery_images( $slug = 'allenamento-e-attrezzature' ) {
	$term = get_term_by( 'slug', $slug, 'ticinoweb_media_gallery' );
	if ( ! $term || is_wp_error( $term ) ) {
		return array();
	}
	$order = array_map( 'absint', (array) get_term_meta( $term->term_id, '_ticinoweb_gallery_order', true ) );
	if ( $order ) {
		return array_values( array_filter( $order ) );
	}
	return get_posts( array(
		'post_type' => 'attachment', 'post_status' => 'inherit', 'posts_per_page' => 12,
		'fields' => 'ids', 'tax_query' => array( array( 'taxonomy' => 'ticinoweb_media_gallery', 'field' => 'term_id', 'terms' => $term->term_id ) ), // phpcs:ignore WordPress.DB.SlowDBQuery
	) );
}
