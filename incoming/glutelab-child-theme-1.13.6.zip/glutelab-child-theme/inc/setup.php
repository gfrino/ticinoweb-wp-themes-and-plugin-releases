<?php
/**
 * Idempotent per-site initializer for Glute Lab.
 *
 * @package GluteLabChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'after_switch_theme', 'glutelab_maybe_initialize_site' );
add_action( 'admin_init', 'glutelab_maybe_initialize_site' );

/**
 * Store a default only when the site has no value yet.
 *
 * @param string $key   Option key.
 * @param mixed  $value Initial value.
 * @return bool
 */
function glutelab_add_option_default( $key, $value ) {
	if ( null !== get_option( $key, null ) ) {
		return false;
	}
	return add_option( $key, $value );
}

/**
 * Create a page or fill a genuinely empty one.
 *
 * @param array<string,mixed> $definition Page definition.
 * @return int
 */
function glutelab_upsert_page( $definition ) {
	$page = get_page_by_path( $definition['slug'], OBJECT, 'page' );
	if ( $page ) {
		if ( '' === trim( (string) $page->post_content ) && ! empty( $definition['content'] ) ) {
			wp_update_post( array( 'ID' => $page->ID, 'post_content' => $definition['content'] ) );
		}
		return (int) $page->ID;
	}

	$result = wp_insert_post( array(
		'post_type' => 'page', 'post_status' => $definition['status'] ?? 'publish',
		'post_title' => $definition['title'], 'post_name' => $definition['slug'],
		'post_content' => $definition['content'] ?? '', 'post_excerpt' => $definition['excerpt'] ?? '',
	), true );
	return is_wp_error( $result ) ? 0 : (int) $result;
}

/**
 * Replace only the obsolete purchase-page placeholder installed by older versions.
 * Editorial content is deliberately left untouched.
 *
 * @param int $page_id Purchase page ID.
 * @return void
 */
function glutelab_migrate_purchase_page_copy( $page_id ) {
	$page = get_post( $page_id );
	if ( ! $page ) {
		return;
	}

	$legacy = '<p>L’acquisto online non è ancora attivo. In questa fase puoi richiedere un appuntamento e concordare il pagamento in sede.</p>';
	if ( trim( (string) $page->post_content ) !== $legacy ) {
		return;
	}

	wp_update_post( array(
		'ID'           => $page_id,
		'post_content' => '<p>Scegli un’offerta e invia la richiesta. Disponibilità e metodi di pagamento vengono mostrati solo quando configurati.</p>',
		'post_excerpt' => 'Scegli un’offerta Glute Lab e invia una richiesta di informazioni o prenotazione.',
	) );
}

/**
 * Copy a bundled image to Media Library once.
 *
 * @param string $relative Relative file below the theme.
 * @param string $title    Attachment title.
 * @param string $alt      Alternative text.
 * @param string $source   Original source URL or official-file note.
 * @return int
 */
function glutelab_import_bundled_image( $relative, $title, $alt, $source ) {
	$existing = get_posts( array(
		'post_type' => 'attachment', 'post_status' => 'inherit', 'numberposts' => 1,
		'meta_key' => '_glutelab_source_file', 'meta_value' => $relative, // phpcs:ignore WordPress.DB.SlowDBQuery
	) );
	if ( $existing ) {
		return (int) $existing[0]->ID;
	}
	$file = trailingslashit( get_stylesheet_directory() ) . ltrim( $relative, '/' );
	if ( ! is_readable( $file ) ) {
		return 0;
	}
	$upload = wp_upload_bits( wp_basename( $file ), null, file_get_contents( $file ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
	if ( ! empty( $upload['error'] ) ) {
		return 0;
	}
	$type = wp_check_filetype( $upload['file'] );
	$id   = wp_insert_attachment( array(
		'post_mime_type' => $type['type'], 'post_title' => $title,
		'post_content' => $source, 'post_status' => 'inherit',
	), $upload['file'] );
	if ( ! $id || is_wp_error( $id ) ) {
		return 0;
	}
	require_once ABSPATH . 'wp-admin/includes/image.php';
	wp_update_attachment_metadata( $id, wp_generate_attachment_metadata( $id, $upload['file'] ) );
	update_post_meta( $id, '_wp_attachment_image_alt', $alt );
	update_post_meta( $id, '_glutelab_source_file', $relative );
	update_post_meta( $id, '_glutelab_source_url', $source );
	return (int) $id;
}

/**
 * Seed pages, CMS options, menu, media and FAQ for the current subsite.
 *
 * @return void
 */
function glutelab_maybe_initialize_site() {
	if ( 'glutelab-child-theme' !== get_stylesheet() || ! current_user_can( 'edit_pages' ) ) {
		return;
	}
	if ( version_compare( (string) get_option( 'glutelab_setup_version', '0' ), GLUTELAB_THEME_VERSION, '>=' ) ) {
		return;
	}

	$pages = array(
		'home' => array( 'title' => 'Home', 'slug' => 'home', 'excerpt' => 'Completa il tuo allenamento con Glute Lab.', 'content' => '<p>Non devi cambiare il tuo allenamento.<br><strong>Devi completarlo nel modo giusto.</strong></p>' ),
		'il-metodo' => array( 'title' => 'Il metodo', 'slug' => 'il-metodo', 'excerpt' => 'Un lavoro specifico, progressivo e seguito che completa il tuo programma abituale.', 'content' => '<h2>Che cos’è Glute Lab</h2><p>Glute Lab è l’evoluzione del percorso Glute Up di ASCO Fit: un allenamento dedicato ai glutei e costruito sul livello di partenza della persona.</p><h2>Un complemento al tuo programma</h2><p>Non sostituisce il tuo allenamento abituale. Lo completa con movimenti controllati, macchinari specializzati e una progressione concordata.</p><h2>A chi è rivolto</h2><p>È pensato sia per chi già si allena sia per chi desidera iniziare un percorso mirato.</p>' ),
		'pacchetti-e-lezioni' => array( 'title' => 'Pacchetti e lezioni', 'slug' => 'pacchetti-e-lezioni', 'content' => '<p>Scegli la formula più adatta alla continuità che desideri. Tutte le lezioni sono individuali e si svolgono su appuntamento.</p>' ),
		'contatti' => array( 'title' => 'Contatti', 'slug' => 'contatti', 'content' => '<p>Raccontaci che cosa stai cercando: ti ricontatteremo per concordare la lezione e rispondere alle tue domande.</p>' ),
		'acquista-o-prenota' => array( 'title' => 'Acquista o prenota', 'slug' => 'acquista-o-prenota', 'content' => '<p>Scegli un’offerta e invia la richiesta. Disponibilità e metodi di pagamento vengono mostrati solo quando configurati.</p>' ),
	);
	$page_ids = array();
	foreach ( $pages as $key => $definition ) {
		$page_ids[ $key ] = glutelab_upsert_page( $definition );
	}
	if ( ! empty( $page_ids['acquista-o-prenota'] ) ) {
		glutelab_migrate_purchase_page_copy( $page_ids['acquista-o-prenota'] );
	}

	if ( empty( get_option( 'page_on_front' ) ) && ! empty( $page_ids['home'] ) ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $page_ids['home'] );
	}

	$assets = array(
		'logo' => array( 'assets/images/glutelab-logo.png', 'Logo Glute Lab', 'Glute Lab', 'Logo ufficiale fornito dal cliente.' ),
		'slider-1' => array( 'assets/images/stock/slider-strength.webp', 'Allenamento di forza', 'Donna adulta utilizza un macchinario in una palestra luminosa', 'https://www.pexels.com/photo/3756690/ — Andrea Piacquadio, Pexels License' ),
		'slider-2' => array( 'assets/images/stock/slider-equipment.webp', 'Macchinari per lower body', 'Persona adulta al leg press in palestra', 'https://www.pexels.com/photo/woman-using-leg-press-machine-28076/ — Scott Webb, Pexels License' ),
		'slider-3' => array( 'assets/images/stock/slider-coaching.webp', 'Allenamento seguito', 'Trainer che segue due adulte durante un allenamento di forza', 'https://www.pexels.com/photo/a-woman-exercising-in-a-gym-13621287/ — TSquared Lab, Pexels License' ),
		'method' => array( 'assets/images/stock/method-training.webp', 'Metodo Glute Lab', 'Trainer e cliente adulto discutono un piano di allenamento', 'https://www.pexels.com/photo/female-trainer-instructing-a-male-athlete-16966329/ — Ardit Mbrati, Pexels License' ),
		'about' => array( 'assets/images/stock/about-coaching.webp', 'Percorso seguito', 'Donna adulta esegue un affondo in palestra', 'https://www.pexels.com/photo/photo-of-woman-exercising-4662340/ — Antoni Shkraba, Pexels License' ),
		'gallery-1' => array( 'assets/images/stock/gallery-dumbbells.webp', 'Allenamento lower body', 'Donna adulta durante un esercizio per le gambe in palestra', 'https://www.pexels.com/photo/healthy-people-woman-women-6539845/ — RDNE Stock project, Pexels License' ),
		'gallery-2' => array( 'assets/images/stock/gallery-machine.webp', 'Forza funzionale', 'Donna adulta esegue un esercizio con palla medica in palestra', 'https://www.pexels.com/photo/woman-exercising-in-the-gym-5128325/ — Web Daytona, Pexels License' ),
	);
	$media_ids = array();
	foreach ( $assets as $key => $asset ) {
		$media_ids[ $key ] = glutelab_import_bundled_image( $asset[0], $asset[1], $asset[2], $asset[3] );
	}
	$media_ids = array_filter( $media_ids );
	if ( $media_ids ) {
		update_option( 'glutelab_media_ids', $media_ids );
	}

	$media_url = static function ( $key ) use ( $media_ids ) {
		return ! empty( $media_ids[ $key ] ) ? wp_get_attachment_url( $media_ids[ $key ] ) : '';
	};
	glutelab_add_option_default( 'ticinoweb_site_logo', $media_url( 'logo' ) );
	glutelab_add_option_default( 'ticinoweb_palette_primary', '#9418f5' );
	glutelab_add_option_default( 'ticinoweb_palette_suggested_1', '#f4ecff' );
	glutelab_add_option_default( 'ticinoweb_palette_suggested_2', '#e948a8' );
	glutelab_add_option_default( 'ticinoweb_palette_suggested_3', '#171020' );
	glutelab_add_option_default( 'ticinoweb_font_headings', 'Poppins' );
	glutelab_add_option_default( 'ticinoweb_font_body', 'Inter' );
	glutelab_add_option_default( 'ticinoweb_contact_address', 'Via Locarno 25, 6616 Losone' );
	glutelab_add_option_default( 'ticinoweb_contact_phone', '+41 91 791 6750' );
	glutelab_add_option_default( 'ticinoweb_contact_phone_display', '+41 91 791 6750' );
	glutelab_add_option_default( 'ticinoweb_contact_email', 'ascofitness@gmail.com' );
	glutelab_add_option_default( 'ticinoweb_contact_opening_hours_note', 'Le lezioni Glute Lab si svolgono su appuntamento.' );
	glutelab_add_option_default( 'ticinoweb_contact_opening_hours', array(
		'monday' => array( 'closed' => 0, 'open_24h' => 0, 'slots' => array( array( 'open' => '08:30', 'close' => '20:30' ) ) ),
		'tuesday' => array( 'closed' => 0, 'open_24h' => 0, 'slots' => array( array( 'open' => '08:30', 'close' => '20:30' ) ) ),
		'wednesday' => array( 'closed' => 0, 'open_24h' => 0, 'slots' => array( array( 'open' => '08:30', 'close' => '20:30' ) ) ),
		'thursday' => array( 'closed' => 0, 'open_24h' => 0, 'slots' => array( array( 'open' => '08:30', 'close' => '20:30' ) ) ),
		'friday' => array( 'closed' => 0, 'open_24h' => 0, 'slots' => array( array( 'open' => '08:30', 'close' => '20:30' ) ) ),
		'saturday' => array( 'closed' => 0, 'open_24h' => 0, 'slots' => array( array( 'open' => '09:00', 'close' => '13:00' ) ) ),
		'sunday' => array( 'closed' => 1, 'open_24h' => 0, 'slots' => array() ),
	) );

	glutelab_add_option_default( 'ticinoweb_chi_siamo_title', 'Glute Lab: il tuo alleato per un lavoro mirato' );
	glutelab_add_option_default( 'ticinoweb_chi_siamo_text', "Glute Lab nasce come evoluzione del percorso Glute Up di ASCO Fit e unisce accompagnamento personale, esperienza nell’allenamento dei glutei e macchinari specializzati.\n\nIntegrare una seduta settimanale di Glute Lab nel proprio programma può completare il lavoro svolto in palestra con un allenamento più specifico, progressivo e costruito sulle esigenze della persona.\n\nNon devi cambiare il tuo allenamento. Devi completarlo nel modo giusto." );
	glutelab_add_option_default( 'ticinoweb_chi_siamo_image', $media_url( 'about' ) );
	glutelab_add_option_default( 'ticinoweb_chi_siamo_link', glutelab_page_url( 'il-metodo' ) );
	glutelab_add_option_default( 'ticinoweb_services', array(
		array( 'id' => 'srv_gl_mirato', 'title' => 'Allenamento mirato', 'description' => 'Un lavoro specifico dedicato ai glutei, integrato nel tuo programma di allenamento.', 'image' => $media_url( 'method' ), 'icon_type' => 'dashicon', 'icon' => 'dashicons-universal-access' ),
		array( 'id' => 'srv_gl_macchinari', 'title' => 'Macchinari specializzati', 'description' => 'Attrezzature selezionate per eseguire movimenti controllati e allenare i glutei in modo preciso.', 'image' => $media_url( 'slider-2' ), 'icon_type' => 'dashicon', 'icon' => 'dashicons-admin-tools' ),
		array( 'id' => 'srv_gl_personale', 'title' => 'Percorso personalizzato', 'description' => 'La seduta viene adattata al livello di partenza, agli obiettivi e alla progressione della persona.', 'image' => $media_url( 'about' ), 'icon_type' => 'dashicon', 'icon' => 'dashicons-groups' ),
		array( 'id' => 'srv_gl_forza', 'title' => 'Forza e tonicità', 'description' => 'Un percorso pensato per migliorare forza, controllo, tonicità e consapevolezza del movimento.', 'image' => $media_url( 'slider-1' ), 'icon_type' => 'dashicon', 'icon' => 'dashicons-chart-line' ),
	) );
	glutelab_add_option_default( 'ticinoweb_slider_count', 3 );
	$slides = array(
		1 => array( 'slider-1', 'Il complemento ideale al tuo allenamento', 'Integra una seduta settimanale di Glute Lab nel tuo programma e completa il tuo allenamento con un lavoro specifico dedicato ai glutei.', 'Scopri Glute Lab', home_url( '/#metodo' ) ),
		2 => array( 'slider-2', 'Macchinari specializzati. Lavoro mirato.', 'Attrezzature progettate per allenare i glutei in modo preciso, progressivo e complementare al tuo programma abituale.', 'Scopri il metodo', glutelab_page_url( 'il-metodo' ) ),
		3 => array( 'slider-3', 'Un percorso seguito, costruito su di te', 'L’esperienza del percorso Glute Up con Mirella incontra un ambiente dedicato e attrezzature specifiche per accompagnarti nel tuo allenamento.', 'Vedi i pacchetti', glutelab_page_url( 'pacchetti-e-lezioni' ) ),
	);
	foreach ( $slides as $index => $slide ) {
		glutelab_add_option_default( "ticinoweb_slider_image_{$index}", $media_url( $slide[0] ) );
		glutelab_add_option_default( "ticinoweb_slider_title_{$index}", $slide[1] );
		glutelab_add_option_default( "ticinoweb_slider_desc_{$index}", $slide[2] );
		glutelab_add_option_default( "ticinoweb_slider_btn_text_{$index}", $slide[3] );
		glutelab_add_option_default( "ticinoweb_slider_btn_link_{$index}", $slide[4] );
	}

	glutelab_migrate_legacy_catalog();
	glutelab_add_option_default( 'tw_seo_home_title', 'Glute Lab | Allenamento mirato per i glutei a Losone' );
	glutelab_add_option_default( 'tw_seo_description', 'Completa il tuo allenamento con Glute Lab: percorso seguito, macchinari specializzati e lezioni mirate presso ASCO Fit a Losone.' );
	glutelab_add_option_default( 'tw_seo_schema_type', 'LocalBusiness' );
	glutelab_add_option_default( 'tw_seo_org_name', 'Glute Lab presso ASCO Fit' );
	glutelab_add_option_default( 'tw_seo_org_logo', $media_url( 'logo' ) );
	glutelab_add_option_default( 'tw_seo_business_phone', '+41 91 791 6750' );
	glutelab_add_option_default( 'tw_seo_business_address', 'Via Locarno 25, 6616 Losone' );
	if ( ! empty( $page_ids['il-metodo'] ) ) {
		add_post_meta( $page_ids['il-metodo'], '_tw_seo_title', 'Metodo Glute Lab | Allenamento mirato e personalizzato', true );
	}
	if ( ! empty( $page_ids['pacchetti-e-lezioni'] ) ) {
		add_post_meta( $page_ids['pacchetti-e-lezioni'], '_tw_seo_title', 'Pacchetti e lezioni Glute Lab | Losone', true );
	}
	if ( ! empty( $page_ids['acquista-o-prenota'] ) ) {
		add_post_meta( $page_ids['acquista-o-prenota'], '_tw_seo_robots', 'noindex,follow', true );
	}

	glutelab_setup_menu( $page_ids );
	glutelab_setup_faq();
	glutelab_setup_gallery( $media_ids );
	update_option( 'glutelab_setup_version', GLUTELAB_THEME_VERSION );
}

/**
 * Create and assign the native primary menu without duplicates.
 *
 * @param array<string,int> $page_ids Page IDs.
 * @return void
 */
function glutelab_setup_menu( $page_ids ) {
	$menu = wp_get_nav_menu_object( 'Menu principale Glute Lab' );
	if ( $menu ) {
		$menu_id = (int) $menu->term_id;
	} else {
		$created = wp_create_nav_menu( 'Menu principale Glute Lab' );
		if ( is_wp_error( $created ) ) {
			return;
		}
		$menu_id = (int) $created;
	}
	if ( ! $menu_id ) {
		return;
	}
	$existing = wp_get_nav_menu_items( $menu_id );
	$objects  = array();
	foreach ( (array) $existing as $item ) {
		$objects[ (int) $item->object_id ] = true;
	}
	foreach ( array( 'home', 'il-metodo', 'pacchetti-e-lezioni', 'contatti' ) as $key ) {
		if ( empty( $page_ids[ $key ] ) || isset( $objects[ $page_ids[ $key ] ] ) ) {
			continue;
		}
		wp_update_nav_menu_item( $menu_id, 0, array(
			'menu-item-object-id' => $page_ids[ $key ], 'menu-item-object' => 'page',
			'menu-item-type' => 'post_type', 'menu-item-status' => 'publish',
			'menu-item-classes' => '',
		) );
	}
	$has_cta = false;
	foreach ( (array) $existing as $item ) {
		if ( in_array( 'gl-menu-cta', (array) $item->classes, true ) ) {
			$has_cta = true;
			break;
		}
	}
	if ( ! $has_cta && ! empty( $page_ids['contatti'] ) ) {
		wp_update_nav_menu_item( $menu_id, 0, array(
			'menu-item-title' => 'Richiedi una lezione', 'menu-item-url' => get_permalink( $page_ids['contatti'] ),
			'menu-item-type' => 'custom', 'menu-item-status' => 'publish', 'menu-item-classes' => 'gl-menu-cta',
		) );
	}
	$locations = get_theme_mod( 'nav_menu_locations', array() );
	if ( empty( $locations['primary'] ) ) {
		$locations['primary'] = $menu_id;
		set_theme_mod( 'nav_menu_locations', $locations );
	}
}

/**
 * Create/update the parent FAQ set.
 *
 * @return void
 */
function glutelab_setup_faq() {
	if ( ! function_exists( 'ticinoweb_faq_upsert_set' ) ) {
		return;
	}
	$items = array(
		array( 'q' => 'Che cos’è Glute Lab?', 'a' => 'È un percorso individuale dedicato ai glutei, con macchinari specifici e accompagnamento personale.', 'section' => 'Percorso', 'visible' => 1, 'extra' => '' ),
		array( 'q' => 'In che modo completa il mio allenamento?', 'a' => 'Aggiunge un lavoro mirato e progressivo senza chiederti di sostituire il programma che già segui.', 'section' => 'Percorso', 'visible' => 1, 'extra' => '' ),
		array( 'q' => 'È adatto anche a chi ha appena iniziato?', 'a' => 'Sì. La seduta viene adattata al livello di partenza e alla progressione della persona.', 'section' => 'Percorso', 'visible' => 1, 'extra' => '' ),
		array( 'q' => 'Posso scegliere una lezione singola?', 'a' => 'Sì, è disponibile anche la lezione singola.', 'section' => 'Lezioni', 'visible' => 1, 'extra' => '' ),
		array( 'q' => 'Come funzionano i pacchetti 5+1 e 10+1?', 'a' => 'Comprendono rispettivamente sei e undici lezioni complessive.', 'section' => 'Pacchetti', 'visible' => 1, 'extra' => '' ),
		array( 'q' => 'Come posso richiedere una lezione?', 'a' => 'Invia il modulo Contatti oppure telefona ad ASCO Fit per concordare giorno e orario.', 'section' => 'Contatti', 'visible' => 1, 'extra' => '' ),
		array( 'q' => 'Il pagamento online è già disponibile?', 'a' => 'Non ancora. In questa fase la richiesta viene gestita tramite contatto diretto; il pagamento online verrà attivato successivamente.', 'section' => 'Pagamenti', 'visible' => 1, 'extra' => '' ),
	);
	ticinoweb_faq_upsert_set( 'glute-lab', 'FAQ Glute Lab', $items, array( 'intro' => 'Risposte rapide sul percorso, sulle lezioni e sui pacchetti.' ) );
}

/**
 * Populate the parent Media Library gallery taxonomy.
 *
 * @param array<string,int> $media_ids Imported media.
 * @return void
 */
function glutelab_setup_gallery( $media_ids ) {
	if ( ! taxonomy_exists( 'ticinoweb_media_gallery' ) ) {
		return;
	}
	$term = term_exists( 'allenamento-e-attrezzature', 'ticinoweb_media_gallery' );
	if ( ! $term ) {
		$term = wp_insert_term( 'Allenamento e attrezzature', 'ticinoweb_media_gallery', array( 'slug' => 'allenamento-e-attrezzature' ) );
	}
	if ( is_wp_error( $term ) ) {
		return;
	}
	$term_id = (int) ( is_array( $term ) ? $term['term_id'] : $term );
	$order   = array();
	foreach ( array( 'gallery-1', 'gallery-2', 'method', 'slider-2' ) as $key ) {
		if ( ! empty( $media_ids[ $key ] ) ) {
			wp_set_object_terms( $media_ids[ $key ], array( $term_id ), 'ticinoweb_media_gallery', false );
			$order[] = $media_ids[ $key ];
		}
	}
	if ( $order && ! get_term_meta( $term_id, '_ticinoweb_gallery_order', true ) ) {
		update_term_meta( $term_id, '_ticinoweb_gallery_order', $order );
	}
}
