<?php
/** Site header. @package GluteLabChildTheme */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class( 'gl-site no-js' ); ?>>
<?php wp_body_open(); ?>
<a class="gl-skip-link" href="#primary"><?php esc_html_e( 'Vai al contenuto', 'glutelab-child-theme' ); ?></a>
<header class="gl-header" data-gl-header>
	<div class="gl-shell gl-header__inner">
		<a class="gl-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
			<?php $logo = function_exists( 'ticinoweb_get_site_logo' ) ? ticinoweb_get_site_logo() : get_option( 'ticinoweb_site_logo', '' ); ?>
			<?php if ( $logo ) : ?>
				<span class="gl-brand__art">
					<img class="gl-brand__logo" src="<?php echo esc_url( $logo ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" width="170" height="78" fetchpriority="high">
					<span class="gl-brand__shield" aria-hidden="true"><img src="<?php echo esc_url( $logo ); ?>" alt="" width="214" height="98"></span>
				</span>
			<?php else : ?>
				<span>GLUTE <b>LAB</b></span>
			<?php endif; ?>
		</a>
		<button class="gl-menu-toggle" type="button" aria-expanded="false" aria-controls="gl-primary-menu" data-gl-menu-toggle data-open-label="<?php esc_attr_e( 'Apri il menu', 'glutelab-child-theme' ); ?>" data-close-label="<?php esc_attr_e( 'Chiudi il menu', 'glutelab-child-theme' ); ?>"><span class="gl-menu-toggle__lines" aria-hidden="true"></span><span class="screen-reader-text" data-gl-menu-label><?php esc_html_e( 'Apri il menu', 'glutelab-child-theme' ); ?></span></button>
		<nav class="gl-nav" id="gl-primary-menu" aria-label="<?php esc_attr_e( 'Navigazione principale', 'glutelab-child-theme' ); ?>" data-gl-menu>
			<?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'menu_class' => 'gl-nav__list', 'fallback_cb' => false, 'depth' => 2 ) ); ?>
		</nav>
	</div>
</header>
