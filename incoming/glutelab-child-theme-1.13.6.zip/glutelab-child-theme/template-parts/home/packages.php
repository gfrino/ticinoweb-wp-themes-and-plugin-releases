<?php
/** Home path summaries. @package GluteLabChildTheme */
$groups = array_values( (array) ( $args['package_groups'] ?? array() ) );
$page   = $args['package_page'] ?? null;
if ( ! $groups ) return;
$catalog = glutelab_get_catalog();
$url = $page ? get_permalink( $page ) : glutelab_page_url( 'pacchetti-e-lezioni' );
$packages_by_group = array();
foreach ( glutelab_get_packages() as $package ) {
	$packages_by_group[ $package['group_id'] ][] = $package;
}
?>
<section class="gl-home-paths gl-section" id="pacchetti">
	<div class="gl-shell">
		<header class="gl-home-heading gl-home-heading--split" data-gl-home-reveal><div><p class="gl-kicker"><?php esc_html_e( 'Lezioni e pacchetti', 'glutelab-child-theme' ); ?></p><h2><?php echo esc_html( $catalog['general']['title'] ); ?></h2></div><a class="gl-text-link" href="<?php echo esc_url( $url ); ?>"><?php esc_html_e( 'Confronta tutte le offerte', 'glutelab-child-theme' ); ?> <span aria-hidden="true">→</span></a></header>
		<div class="gl-paths" data-gl-home-reveal>
			<?php foreach ( $groups as $group ) : $group_packages = $packages_by_group[ $group['id'] ] ?? array(); ?>
			<article class="gl-path-card">
				<header class="gl-path-card__head">
					<div class="gl-path-card__meta"><span><?php echo esc_html( $group['order_label'] ); ?></span><strong><?php echo esc_html( glutelab_group_primary_characteristic( $group ) ); ?></strong></div>
					<h3 id="gl-path-title-<?php echo esc_attr( $group['id'] ); ?>"><?php echo esc_html( $group['title'] ); ?></h3>
					<p><?php echo esc_html( $group['description'] ); ?></p>
				</header>
				<?php if ( $group_packages ) : ?>
					<ul class="gl-path-card__options" aria-labelledby="gl-path-title-<?php echo esc_attr( $group['id'] ); ?>">
						<?php foreach ( $group_packages as $package ) : ?>
							<li class="gl-path-card__option">
								<span class="gl-path-card__option-copy"><strong><?php echo esc_html( $package['title'] ); ?></strong><?php if ( $package['description'] ) : ?><small><?php echo esc_html( $package['description'] ); ?></small><?php endif; ?></span>
								<span class="gl-path-card__option-price"><?php echo esc_html( glutelab_package_price_text( $package ) ); ?></span>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
				<a class="gl-button gl-button--primary gl-path-card__cta" href="<?php echo esc_url( $url . '#' . $group['id'] ); ?>"><?php echo esc_html( $group['cta_label'] ); ?> <span aria-hidden="true">→</span></a>
			</article><?php endforeach; ?>
		</div>
	</div>
</section>
