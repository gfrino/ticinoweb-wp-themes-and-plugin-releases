<?php
/** Method and machinery summary sourced from CMS services. @package GluteLabChildTheme */
$services  = array_slice( array_values( array_filter( (array) ( $args['services'] ?? array() ) ) ), 0, 4 );
$gallery   = array_values( (array) ( $args['gallery'] ?? array() ) );
$image_id  = isset( $gallery[0] ) ? absint( $gallery[0] ) : 0;
$image_url = trim( (string) ( $args['about_image'] ?? '' ) );
$page      = $args['method_page'] ?? null;
$url       = $page ? get_permalink( $page ) : glutelab_page_url( 'il-metodo' );

if ( ! $services ) {
	return;
}
?>
<section class="gl-home-method gl-section gl-section--tint" id="metodo">
	<div class="gl-shell gl-home-method__layout<?php echo ( ! $image_id && '' === $image_url ) ? ' gl-home-method__layout--no-media' : ''; ?>">
		<header class="gl-home-method__head" data-gl-home-reveal>
			<div>
				<p class="gl-kicker"><?php esc_html_e( 'Metodo e macchinari', 'glutelab-child-theme' ); ?></p>
				<h2><?php esc_html_e( 'Un lavoro preciso, costruito intorno a te', 'glutelab-child-theme' ); ?></h2>
			</div>
			<p><?php esc_html_e( 'Quattro elementi lavorano insieme per integrare Glute Lab nel tuo programma in modo mirato e progressivo.', 'glutelab-child-theme' ); ?></p>
		</header>

		<div class="gl-home-method__body">
			<?php if ( $image_id || '' !== $image_url ) : ?>
				<figure class="gl-home-method__media" data-gl-home-reveal>
					<?php if ( $image_id ) : ?><?php echo wp_get_attachment_image( $image_id, 'large', false, array( 'loading' => 'lazy', 'decoding' => 'async', 'class' => 'gl-home-method__image' ) ); ?><?php else : ?><?php glutelab_image( $image_url, __( 'Allenamento Glute Lab', 'glutelab-child-theme' ), false, 'gl-home-method__image' ); ?><?php endif; ?>
				</figure>
			<?php endif; ?>

			<div class="gl-home-method__points" data-gl-home-reveal>
				<?php foreach ( $services as $index => $service ) : ?>
					<article class="gl-home-method__point">
						<span><?php echo esc_html( sprintf( '%02d', $index + 1 ) ); ?></span>
						<?php if ( ! empty( $service['title'] ) ) : ?><h3><?php echo esc_html( $service['title'] ); ?></h3><?php endif; ?>
						<?php if ( ! empty( $service['description'] ) ) : ?><p><?php echo esc_html( $service['description'] ); ?></p><?php endif; ?>
					</article>
				<?php endforeach; ?>
			</div>
			<?php if ( $url ) : ?><a class="gl-button gl-home-method__cta" href="<?php echo esc_url( $url ); ?>" data-gl-home-reveal><span><?php esc_html_e( 'Scopri il metodo', 'glutelab-child-theme' ); ?></span><span aria-hidden="true">→</span></a><?php endif; ?>
		</div>
	</div>
</section>
