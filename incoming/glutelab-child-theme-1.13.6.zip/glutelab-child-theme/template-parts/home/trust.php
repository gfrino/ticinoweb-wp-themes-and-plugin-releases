<?php
/** Home trust section. @package GluteLabChildTheme */
$title    = trim( (string) ( $args['about_title'] ?? '' ) );
$text     = trim( (string) ( $args['about_text'] ?? '' ) );
$gallery  = array_values( (array) ( $args['gallery'] ?? array() ) );
$image_id = isset( $gallery[2] ) ? absint( $gallery[2] ) : ( isset( $gallery[1] ) ? absint( $gallery[1] ) : 0 );
$image    = trim( (string) ( $args['about_image'] ?? '' ) );
$method_page = $args['method_page'] ?? null;
$method_url  = $method_page ? get_permalink( $method_page ) : glutelab_page_url( 'il-metodo' );
if ( '' === $title && '' === $text ) {
	return;
}
?>
<section class="gl-home-trust gl-section">
	<div class="gl-shell gl-home-trust__layout">
		<div class="gl-home-trust__copy" data-gl-home-reveal>
			<p class="gl-kicker"><?php esc_html_e( 'Continuità', 'glutelab-child-theme' ); ?></p>
			<?php if ( '' !== $title ) : ?><h2><?php echo esc_html( $title ); ?></h2><?php endif; ?>
			<?php if ( '' !== $text ) : ?><div class="gl-prose"><?php echo wpautop( esc_html( $text ) ); ?></div><?php endif; ?>
			<ul class="gl-home-trust__indicators" aria-label="<?php esc_html_e( 'Punti chiave del percorso', 'glutelab-child-theme' ); ?>">
				<li class="gl-home-trust__indicator"><strong aria-hidden="true">01</strong><span><?php esc_html_e( 'Evoluzione di Glute Up', 'glutelab-child-theme' ); ?></span></li>
				<li class="gl-home-trust__indicator"><strong aria-hidden="true">02</strong><span><?php esc_html_e( 'Presso ASCO Fit', 'glutelab-child-theme' ); ?></span></li>
				<li class="gl-home-trust__indicator"><strong aria-hidden="true">03</strong><span><?php esc_html_e( 'Percorso seguito', 'glutelab-child-theme' ); ?></span></li>
			</ul>
			<?php if ( '' !== $method_url ) : ?><a class="gl-home-trust__cta" href="<?php echo esc_url( $method_url ); ?>"><?php esc_html_e( 'Scopri il metodo', 'glutelab-child-theme' ); ?><span aria-hidden="true">→</span></a><?php endif; ?>
		</div>
		<?php if ( $image_id || '' !== $image ) : ?>
			<figure class="gl-home-trust__media" data-gl-home-reveal>
				<div class="gl-home-trust__image-wrap"><?php if ( $image_id ) : ?><?php echo wp_get_attachment_image( $image_id, 'large', false, array( 'loading' => 'lazy', 'class' => 'gl-home-trust__image' ) ); ?><?php else : ?><?php glutelab_image( $image, $title, false, 'gl-home-trust__image' ); ?><?php endif; ?></div>
			</figure>
		<?php endif; ?>
	</div>
</section>
