<?php
/** Home final CTA. @package GluteLabChildTheme */
$contact_page = $args['contact_page'] ?? null;
$package_page = $args['package_page'] ?? null;
$title        = trim( (string) ( $args['home_excerpt'] ?? '' ) );
$contact_url  = $contact_page ? get_permalink( $contact_page ) : glutelab_page_url( 'contatti' );
$package_url  = $package_page ? get_permalink( $package_page ) : glutelab_page_url( 'pacchetti-e-lezioni' );
$contact      = function_exists( 'glutelab_get_contact_data' ) ? glutelab_get_contact_data() : array();
$phone        = trim( (string) ( $contact['phone'] ?? '' ) );
$phone_href   = preg_replace( '/[^0-9+]/', '', $phone );
if ( '' === $title ) {
	$title = get_bloginfo( 'description' );
}
if ( '' === $title ) {
	return;
}
?>
<section class="gl-home-final gl-section" data-gl-home-reveal>
	<div class="gl-shell gl-home-final__inner">
		<div class="gl-home-final__copy">
			<p class="gl-kicker"><?php esc_html_e( 'Il prossimo passo', 'glutelab-child-theme' ); ?></p>
			<h2><?php echo esc_html( $title ); ?></h2>
			<p class="gl-home-final__support"><?php esc_html_e( 'Scegli il percorso oppure richiedi una lezione.', 'glutelab-child-theme' ); ?></p>
		</div>
		<div class="gl-home-final__actions">
			<?php if ( '' !== $contact_url ) : ?><a class="gl-button gl-button--light" href="<?php echo esc_url( $contact_url ); ?>"><?php esc_html_e( 'Richiedi una lezione', 'glutelab-child-theme' ); ?></a><?php endif; ?>
			<?php if ( '' !== $package_url ) : ?><a class="gl-button gl-button--outline-light" href="<?php echo esc_url( $package_url ); ?>"><?php esc_html_e( 'Scopri i pacchetti', 'glutelab-child-theme' ); ?></a><?php endif; ?>
			<?php if ( '' !== $phone && '' !== $phone_href ) : ?><a class="gl-home-final__phone" href="tel:<?php echo esc_attr( $phone_href ); ?>"><span><?php esc_html_e( 'Preferisci chiamare?', 'glutelab-child-theme' ); ?></span><strong><?php echo esc_html( $phone ); ?></strong></a><?php endif; ?>
		</div>
	</div>
</section>
