<?php
/** Compact Home introduction sourced from the Home editor. @package GluteLabChildTheme */
$content = trim( (string) ( $args['home_content'] ?? '' ) );
if ( '' === $content ) {
	return;
}
?>
<section class="gl-home-intro gl-section">
	<div class="gl-shell gl-home-intro__layout" data-gl-home-reveal>
		<header>
			<p class="gl-kicker"><?php esc_html_e( 'Glute Lab by ASCO Fit', 'glutelab-child-theme' ); ?></p>
			<h2><?php esc_html_e( 'Il complemento mirato al tuo allenamento', 'glutelab-child-theme' ); ?></h2>
		</header>
		<div class="gl-prose gl-home-intro__text"><?php echo apply_filters( 'the_content', $content ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
	</div>
</section>
