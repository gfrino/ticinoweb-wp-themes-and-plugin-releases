<?php
/** Fixed-stage, CMS-driven Home hero. @package GluteLabChildTheme */
$slides      = array_values( (array) ( $args['slides'] ?? array() ) );
$package_url = trim( (string) ( $args['package_url'] ?? '' ) );
$total       = count( $slides );
$normalize_destination = static function ( $url ) {
	$parts = wp_parse_url( trim( (string) $url ) );
	if ( ! is_array( $parts ) ) {
		return '';
	}
	$host = strtolower( (string) ( $parts['host'] ?? '' ) );
	$path = '/' . trim( (string) ( $parts['path'] ?? '' ), '/' );
	return $host . ( '/' === $path ? '/' : untrailingslashit( $path ) );
};

if ( ! $slides ) {
	return;
}
?>
<section class="gl-home-hero" data-gl-hero data-gl-hero-autoplay-delay="3200" tabindex="-1" aria-label="<?php esc_attr_e( 'Presentazione Glute Lab', 'glutelab-child-theme' ); ?>">
	<div class="gl-home-hero__atmosphere" data-gl-hero-atmosphere aria-hidden="true">
		<span class="gl-home-hero__ambient gl-home-hero__ambient--one"></span>
		<span class="gl-home-hero__ambient gl-home-hero__ambient--two"></span>
		<span class="gl-home-hero__ambient gl-home-hero__ambient--three"></span>
		<span class="gl-home-hero__ambient gl-home-hero__ambient--ring"></span>
	</div>
	<div class="gl-home-hero__stage">
		<?php foreach ( $slides as $index => $slide ) :
			$is_first = 0 === $index;
			$heading  = $is_first ? 'h1' : 'h2';
			$primary_url = trim( (string) ( $slide['button_url'] ?? '' ) );
			$show_package_cta = '' !== $package_url && ( '' === $primary_url || $normalize_destination( $primary_url ) !== $normalize_destination( $package_url ) );
			?>
			<article class="gl-home-hero__slide<?php echo $is_first ? ' is-active' : ''; ?>" data-gl-hero-slide data-title="<?php echo esc_attr( $slide['title'] ); ?>"<?php echo $is_first ? '' : ' aria-hidden="true"'; ?>>
				<div class="gl-shell gl-home-hero__layout">
					<div class="gl-home-hero__copy">
						<div class="gl-home-hero__meta">
							<p class="gl-kicker"><?php esc_html_e( 'Glute Lab by ASCO Fit', 'glutelab-child-theme' ); ?></p>
							<p class="gl-home-hero__counter" aria-hidden="true"><?php echo esc_html( sprintf( '%02d / %02d', $index + 1, $total ) ); ?></p>
						</div>
						<<?php echo esc_attr( $heading ); ?>><?php echo esc_html( $slide['title'] ); ?></<?php echo esc_attr( $heading ); ?>>
						<?php if ( ! empty( $slide['description'] ) ) : ?><p class="gl-home-hero__lead"><?php echo esc_html( $slide['description'] ); ?></p><?php endif; ?>
						<div class="gl-home-hero__actions">
							<?php if ( ! empty( $slide['button_text'] ) && ! empty( $slide['button_url'] ) ) : ?><a class="gl-button gl-button--primary gl-home-hero__primary" href="<?php echo esc_url( $slide['button_url'] ); ?>"><?php echo esc_html( $slide['button_text'] ); ?></a><?php endif; ?>
							<?php if ( $show_package_cta ) : ?><a class="gl-text-link gl-home-hero__secondary" href="<?php echo esc_url( $package_url ); ?>"><?php esc_html_e( 'Scopri i pacchetti', 'glutelab-child-theme' ); ?> <span aria-hidden="true">→</span></a><?php endif; ?>
						</div>
					</div>
					<figure class="gl-home-hero__media">
						<?php glutelab_image( $slide['image'], $slide['title'], $is_first, 'gl-home-hero__image' ); ?>
						<span class="gl-home-hero__accent" aria-hidden="true"></span>
					</figure>
				</div>
			</article>
		<?php endforeach; ?>
	</div>
	<?php if ( 1 < $total ) : ?>
		<div class="gl-shell gl-home-hero__controls" data-gl-hero-controls>
			<button type="button" class="gl-home-hero__loop" data-gl-hero-autoplay data-pause-label="<?php esc_attr_e( 'Metti in pausa lo slider', 'glutelab-child-theme' ); ?>" data-play-label="<?php esc_attr_e( 'Riprendi lo slider', 'glutelab-child-theme' ); ?>" data-running-label="<?php esc_attr_e( 'Auto', 'glutelab-child-theme' ); ?>" data-paused-label="<?php esc_attr_e( 'In pausa', 'glutelab-child-theme' ); ?>" aria-label="<?php esc_attr_e( 'Metti in pausa lo slider', 'glutelab-child-theme' ); ?>" aria-pressed="false">
				<span class="gl-home-hero__loop-icon" data-gl-hero-autoplay-icon aria-hidden="true">↻</span>
				<span class="gl-home-hero__loop-copy">
					<span class="gl-home-hero__loop-meta"><strong data-gl-hero-loop-label><?php esc_html_e( 'Auto', 'glutelab-child-theme' ); ?></strong><span data-gl-hero-loop-index><?php echo esc_html( sprintf( '%02d / %02d', 1, $total ) ); ?></span></span>
					<span class="gl-home-hero__loop-track" aria-hidden="true"><span></span></span>
				</span>
			</button>
			<p class="screen-reader-text" data-gl-hero-status aria-live="polite"></p>
		</div>
	<?php endif; ?>
</section>
