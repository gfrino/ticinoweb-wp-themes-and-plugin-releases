<?php
/** Home FAQ. @package GluteLabChildTheme */
if ( ! function_exists( 'ticinoweb_faq_render' ) ) {
	return;
}
$contact_page = $args['contact_page'] ?? null;
$contact_url  = $contact_page ? get_permalink( $contact_page ) : glutelab_page_url( 'contatti' );
$faq_set      = function_exists( 'ticinoweb_faq_get_set' ) ? ticinoweb_faq_get_set( 'glute-lab' ) : array();
$faq_title    = trim( (string) ( $faq_set['title'] ?? '' ) );
$faq_intro    = trim( (string) ( $faq_set['intro'] ?? '' ) );
$faq_title    = '' !== $faq_title ? $faq_title : __( 'Le risposte prima di iniziare', 'glutelab-child-theme' );
$faq_html = ticinoweb_faq_render( 'glute-lab', array( 'show_title' => false, 'heading_level' => 3 ) );
if ( ! $faq_html ) {
	return;
}
?>
<section class="gl-home-faq gl-section" id="faq">
	<div class="gl-shell gl-home-faq__layout">
		<header class="gl-home-faq__intro" data-gl-home-reveal>
			<p class="gl-kicker"><?php esc_html_e( 'FAQ', 'glutelab-child-theme' ); ?></p>
			<h2><?php echo esc_html( $faq_title ); ?></h2>
			<?php if ( '' !== $faq_intro ) : ?><div class="gl-prose"><?php echo wp_kses_post( wpautop( $faq_intro ) ); ?></div><?php endif; ?>
			<?php if ( '' !== $contact_url ) : ?><a class="gl-home-faq__contact" href="<?php echo esc_url( $contact_url ); ?>"><?php esc_html_e( 'Non trovi la risposta? Contattaci', 'glutelab-child-theme' ); ?><span aria-hidden="true">→</span></a><?php endif; ?>
		</header>
		<div class="gl-home-faq__items" data-gl-home-reveal><?php echo $faq_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped by the parent FAQ renderer. ?></div>
	</div>
</section>
