<?php
/** Home process. @package GluteLabChildTheme */
$steps = array_values( array_filter( (array) ( $args['process_steps'] ?? array() ) ) );
if ( ! $steps ) {
	return;
}
?>
<section class="gl-home-process gl-section gl-section--tint">
	<div class="gl-shell">
		<header class="gl-home-heading" data-gl-home-reveal><p class="gl-kicker"><?php esc_html_e( 'Come funziona', 'glutelab-child-theme' ); ?></p><h2><?php esc_html_e( 'Dal primo passo alla continuità', 'glutelab-child-theme' ); ?></h2></header>
		<ol class="gl-home-process__steps" data-gl-process>
			<?php foreach ( $steps as $index => $step ) : ?><li data-gl-home-reveal><span><?php echo esc_html( sprintf( '%02d', $index + 1 ) ); ?></span><strong><?php echo esc_html( $step ); ?></strong></li><?php endforeach; ?>
		</ol>
	</div>
</section>
