<?php
/** Featured active packages sourced from the package catalogue. @package GluteLabChildTheme */
$packages = glutelab_get_packages( array( 'featured' => true, 'limit' => 3 ) );
$groups   = array_values( (array) ( $args['package_groups'] ?? array() ) );
$url      = trim( (string) ( $args['package_url'] ?? '' ) );

if ( ! $packages ) {
	foreach ( $groups as $group ) {
		$group_packages = glutelab_get_packages_by_group( $group['id'] );
		if ( $group_packages ) {
			$packages[] = $group_packages[0];
		}
		if ( 3 === count( $packages ) ) {
			break;
		}
	}
}

if ( ! $packages ) {
	return;
}
?>
<section class="gl-home-featured gl-section gl-section--tint" aria-labelledby="gl-featured-title">
	<div class="gl-shell">
		<header class="gl-home-heading gl-home-heading--split" data-gl-home-reveal>
			<div><p class="gl-kicker"><?php esc_html_e( 'Pacchetti in evidenza', 'glutelab-child-theme' ); ?></p><h2 id="gl-featured-title"><?php esc_html_e( 'Inizia dal formato più adatto a te', 'glutelab-child-theme' ); ?></h2></div>
			<?php if ( $url ) : ?><a class="gl-text-link" href="<?php echo esc_url( $url ); ?>"><?php esc_html_e( 'Vedi tutti i pacchetti', 'glutelab-child-theme' ); ?> <span aria-hidden="true">→</span></a><?php endif; ?>
		</header>
		<div class="gl-home-featured__grid">
			<?php foreach ( $packages as $package ) :
				$cta_url   = apply_filters( 'glutelab_package_cta_url', $package['cta_url'], $package, null );
				$card_url  = $cta_url ?: ( $url ? $url . '#' . $package['group_id'] : '' );
				$benefits  = array_slice( glutelab_package_inclusions( $package ), 0, 3 );
				?>
				<article class="gl-home-offer<?php echo ! empty( $package['featured'] ) ? ' gl-home-offer--featured' : ''; ?>" data-gl-home-reveal>
					<div class="gl-home-offer__top">
						<?php if ( ! empty( $package['badge'] ) ) : ?><p class="gl-home-offer__badge"><?php echo esc_html( $package['badge'] ); ?></p><?php endif; ?>
						<?php if ( ! empty( $package['subtitle'] ) ) : ?><p class="gl-home-offer__eyebrow"><?php echo esc_html( $package['subtitle'] ); ?></p><?php endif; ?>
						<h3><?php echo esc_html( $package['title'] ); ?></h3>
						<p class="gl-home-offer__price"><?php echo esc_html( glutelab_package_price_text( $package ) ); ?></p>
					</div>
					<?php if ( ! empty( $package['description'] ) ) : ?><p><?php echo esc_html( $package['description'] ); ?></p><?php endif; ?>
					<?php if ( $benefits ) : ?><ul><?php foreach ( $benefits as $benefit ) : ?><li><?php echo esc_html( $benefit ); ?></li><?php endforeach; ?></ul><?php endif; ?>
					<?php if ( $card_url ) : ?><a class="gl-text-link" href="<?php echo esc_url( $card_url ); ?>"><?php echo esc_html( $package['cta_label'] ?: __( 'Scopri il pacchetto', 'glutelab-child-theme' ) ); ?> <span aria-hidden="true">→</span></a><?php endif; ?>
				</article>
			<?php endforeach; ?>
		</div>
	</div>
</section>
