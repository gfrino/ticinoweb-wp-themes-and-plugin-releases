<?php
/** Package card bridge. Expected variable: $args['package']. */
if ( ! empty( $args['package'] ) ) {
	echo glutelab_package_card_html( $args['package'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}
