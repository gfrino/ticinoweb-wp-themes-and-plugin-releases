<?php
/** Contact form compatible with the parent AJAX handler. */
$contact        = glutelab_get_contact_data();
$fallback_email = sanitize_email( $contact['email'] ?? get_option( 'admin_email', '' ) );
$privacy_url    = get_privacy_policy_url();
?>
<form class="gl-contact-form" data-gl-contact-form method="post" action="<?php echo esc_attr( $fallback_email ? 'mailto:' . $fallback_email : '' ); ?>" enctype="text/plain">
	<div class="gl-form-grid">
		<label><?php esc_html_e( 'Nome e cognome', 'glutelab-child-theme' ); ?><input type="text" name="nome" autocomplete="name" required></label>
		<label><?php esc_html_e( 'E-mail', 'glutelab-child-theme' ); ?><input type="email" name="email" autocomplete="email" required></label>
		<label><?php esc_html_e( 'Telefono', 'glutelab-child-theme' ); ?><input type="tel" name="telefono" autocomplete="tel"></label>
		<label><?php esc_html_e( 'Oggetto', 'glutelab-child-theme' ); ?><input type="text" name="oggetto" value="<?php echo esc_attr( isset( $_GET['pacchetto'] ) ? sprintf( 'Richiesta: %s', sanitize_text_field( wp_unslash( $_GET['pacchetto'] ) ) ) : 'Richiesta lezione Glute Lab' ); ?>"></label>
	</div>
	<label><?php esc_html_e( 'Messaggio', 'glutelab-child-theme' ); ?><textarea name="messaggio" rows="6" required><?php echo isset( $_GET['pacchetto'] ) ? esc_textarea( sprintf( 'Vorrei ricevere informazioni su %s.', sanitize_text_field( wp_unslash( $_GET['pacchetto'] ) ) ) ) : ''; ?></textarea></label>
	<label class="gl-honeypot" aria-hidden="true">Website<input type="text" name="tw_hp" tabindex="-1" autocomplete="off"></label>
	<p class="gl-form-privacy"><?php if ( $privacy_url ) : ?><a href="<?php echo esc_url( $privacy_url ); ?>"><?php esc_html_e( 'Consulta la privacy policy', 'glutelab-child-theme' ); ?></a>. <?php endif; ?><?php esc_html_e( 'I dati inseriti saranno usati esclusivamente per rispondere alla richiesta.', 'glutelab-child-theme' ); ?></p>
	<button class="gl-button gl-button--primary" type="submit"><?php esc_html_e( 'Invia la richiesta', 'glutelab-child-theme' ); ?></button>
	<p class="gl-form-status" role="status" aria-live="polite" data-gl-form-status></p>
	<?php if ( $fallback_email ) : ?><noscript><p><?php echo esc_html( sprintf( /* translators: %s: contact email. */ __( 'JavaScript non è disponibile: il pulsante aprirà il tuo programma e-mail. In alternativa scrivi a %s.', 'glutelab-child-theme' ), $fallback_email ) ); ?></p></noscript><?php endif; ?>
</form>
