<?php
/** Parent-owned contact details. */
$contact = glutelab_get_contact_data();
$hours   = glutelab_get_opening_hours_rows();
?>
<div class="gl-contact-details">
	<?php if ( ! empty( $contact['address'] ) ) : ?><div><span><?php esc_html_e( 'Sede', 'glutelab-child-theme' ); ?></span><strong><?php echo esc_html( $contact['address'] ); ?></strong></div><?php endif; ?>
	<?php if ( ! empty( $contact['phone'] ) ) : ?><div><span><?php esc_html_e( 'Telefono', 'glutelab-child-theme' ); ?></span><strong><a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $contact['phone'] ) ); ?>"><?php echo esc_html( $contact['phone'] ); ?></a></strong></div><?php endif; ?>
	<?php if ( ! empty( $contact['email'] ) ) : ?><div><span><?php esc_html_e( 'E-mail', 'glutelab-child-theme' ); ?></span><strong><a href="mailto:<?php echo esc_attr( antispambot( $contact['email'] ) ); ?>"><?php echo esc_html( antispambot( $contact['email'] ) ); ?></a></strong></div><?php endif; ?>
	<?php if ( $hours ) : ?><div><span><?php esc_html_e( 'Ricezione', 'glutelab-child-theme' ); ?></span><ul><?php foreach ( $hours as $row ) : ?><li><b><?php echo esc_html( $row['label'] ); ?></b> <?php echo esc_html( $row['value'] ); ?></li><?php endforeach; ?></ul></div><?php endif; ?>
	<?php if ( ! empty( $contact['opening_hours_note'] ) ) : ?><p class="gl-contact-details__note"><?php echo esc_html( $contact['opening_hours_note'] ); ?></p><?php endif; ?>
</div>

