<?php
/**
 * Gestione App → Driver: consegne con i propri fattorini (v2.27.0, solo app dalla 2.28.0).
 *
 * L'amministratore promuove un utente a Driver; il Driver vede gli ordini a domicilio nell'app,
 * li accetta (uno solo per ordine), apre la navigazione e segna «Consegnato». Il cliente riceve le notifiche,
 * segue l'auto sulla mappa e (iPhone) la Live Activity. Posizione, notifiche e mappa passano dalle
 * Cloud Functions dell'app (Firebase): vedi includes/driver/firebase.php.
 *
 * Spento di default su ogni sito: finché nessuno lo accende in Gestione App → Driver non crea tabelle,
 * ruoli, pagine né API e non tocca gli ordini. Si accende e spegne per sito (sede), così lo stesso Mobile Admin
 * serve anche le app degli altri clienti.
 *
 * Prefisso `madr_` (Mobile Admin Driver), API REST `app-driver/v1`.
 *
 * @package mobile-admin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'MADR_VERSION', '2.28.0' );
define( 'MADR_DB_VERSION', '2' );
define( 'MADR_DIR', WPADR_PATH . 'includes/driver/' );
define( 'MADR_URL', WPADR_URL . 'assets/driver/' );
const MADR_ENABLED_OPTION = 'madr_enabled';
const MADR_ADMIN_SLUG     = 'madr-drivers';

/** Il Driver è acceso su questo sito. */
function madr_enabled() {
	return '1' === (string) get_option( MADR_ENABLED_OPTION, '0' );
}

if ( madr_enabled() ) {
	require_once MADR_DIR . 'setup.php';
	require_once MADR_DIR . 'deliveries.php';
	require_once MADR_DIR . 'firebase.php';
	require_once MADR_DIR . 'rest.php';
	require_once MADR_DIR . 'admin.php';
	require_once MADR_DIR . 'frontend.php';
} else {
	// Spento: solo la pagina con l'interruttore.
	add_action( 'admin_menu', function () {
		$title  = __( 'Driver e consegne', 'wp-app-dashboard' );
		$parent = ! empty( $GLOBALS['admin_page_hooks']['ard_stato_app'] ) ? 'ard_stato_app' : '';
		if ( $parent ) {
			add_submenu_page( $parent, $title, __( 'Driver', 'wp-app-dashboard' ), 'manage_woocommerce', MADR_ADMIN_SLUG, 'madr_admin_page_off' );
		}
	}, 30 );
}

/** Pagina del Driver spento: cosa fa e come si accende. */
function madr_admin_page_off() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Driver e consegne', 'wp-app-dashboard' ); ?></h1>
		<p><?php esc_html_e( 'Consegne a domicilio con i vostri fattorini: il Driver accetta gli ordini dal sito o dall\'app, apre la navigazione e segna «Consegnato»; il cliente riceve le notifiche e segue l\'auto sulla mappa.', 'wp-app-dashboard' ); ?></p>
		<p><?php esc_html_e( 'Serve l\'app con l\'area Driver e le Cloud Functions del tracking. Finché è spento non cambia nulla su questo sito.', 'wp-app-dashboard' ); ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="madr_toggle">
			<input type="hidden" name="enable" value="1">
			<?php wp_nonce_field( 'madr_toggle' ); ?>
			<?php submit_button( __( 'Attiva le consegne con Driver', 'wp-app-dashboard' ), 'primary', 'submit', false ); ?>
		</form>
	</div>
	<?php
}

/** Accende o spegne il Driver su questo sito. Spegnendo, dati e Driver restano: si ritrovano riaccendendo. */
add_action( 'admin_post_madr_toggle', function () {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		wp_die( esc_html__( 'Non hai i permessi per questa operazione.', 'wp-app-dashboard' ), 403 );
	}
	check_admin_referer( 'madr_toggle' );
	$on = ! empty( $_POST['enable'] );
	update_option( MADR_ENABLED_OPTION, $on ? '1' : '0', true );
	if ( $on ) {
		require_once MADR_DIR . 'setup.php';
		madr_install_site();
	} else {
		wp_clear_scheduled_hook( 'madr_retry_sync' );
	}
	wp_safe_redirect( add_query_arg( array( 'page' => MADR_ADMIN_SLUG ), admin_url( 'admin.php' ) ) );
	exit;
} );
