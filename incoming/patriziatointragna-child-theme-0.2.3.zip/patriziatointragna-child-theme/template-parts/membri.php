<?php
/** Ufficio patriziale: una riga per persona, carica a sinistra, recapiti a destra. */
$membri = pi_opz('membri');
if (!$membri) {
	return;
}
?>
<ul class="pi-membri" role="list">
	<?php foreach ($membri as $m) : ?>
		<li class="pi-membro">
			<span class="pi-membro__ruolo"><?php echo esc_html($m['ruolo']); ?></span>
			<span class="pi-membro__nome"><?php echo esc_html($m['nome']); ?></span>
			<span class="pi-membro__recapiti">
				<?php if ($m['email']) : ?><a href="mailto:<?php echo esc_attr($m['email']); ?>"><?php echo esc_html($m['email']); ?></a><?php endif; ?>
				<?php if ($m['telefono']) : ?><a href="tel:<?php echo esc_attr(pi_tel($m['telefono'])); ?>"><?php echo esc_html($m['telefono']); ?></a><?php endif; ?>
			</span>
		</li>
	<?php endforeach; ?>
</ul>
