<?php
/** Colonna laterale (albo, atti, prima pagina): prossima assemblea, documenti, gettoni. */
$o = pi_opz();
$ev = pi_assemblea_in_evidenza();
?>
<aside class="pi-laterale" aria-label="Informazioni utili">
	<?php if ($ev) :
		$t = $ev['term'];
		$d = pi_assemblea_data($t);
		$ora = get_term_meta($t->term_id, 'pi_ora', true); ?>
		<section class="pi-box pi-box--assemblea">
			<h2><?php echo $ev['futura'] ? 'Prossima assemblea' : 'Ultima assemblea'; ?></h2>
			<p class="pi-box__data"><span><?php echo esc_html(wp_date('j', strtotime($d . ' 12:00'))); ?></span> <?php echo esc_html(pi_mese((int) wp_date('n', strtotime($d . ' 12:00'))) . ' ' . wp_date('Y', strtotime($d . ' 12:00'))); ?><?php echo $ora ? ', ore ' . esc_html($ora) : ''; ?></p>
			<ul role="list">
				<?php foreach (pi_atti_assemblea($t->term_id) as $a) : ?>
					<li><a href="<?php echo esc_url(get_permalink($a)); ?>"><?php echo esc_html(pi_tipo_etichetta(pi_tipo_di($a->ID))); ?></a></li>
				<?php endforeach; ?>
			</ul>
			<a class="pi-box__link" href="<?php echo esc_url(pi_url('assemblee')); ?>">Tutte le assemblee »</a>
		</section>
	<?php endif; ?>
	<section class="pi-box">
		<h2>Documenti</h2>
		<ul role="list">
			<?php foreach (pi_documenti() as $doc) : ?>
				<li><a href="<?php echo esc_url(get_permalink($doc)); ?>"><?php echo esc_html(get_the_title($doc)); ?></a></li>
			<?php endforeach; ?>
		</ul>
	</section>
	<?php if ($o['gettoni']) : ?>
		<section class="pi-box pi-box--gettoni">
			<h2>Gettoni strade forestali</h2>
			<?php echo $o['gettoni_testo'] ? '<p>' . esc_html($o['gettoni_testo']) . '</p>' : ''; ?>
			<ul role="list">
				<?php foreach ($o['gettoni'] as $g) : ?>
					<li><strong><?php echo esc_html($g['nome']); ?></strong><?php if ($g['telefono']) : ?><br><a href="tel:<?php echo esc_attr(pi_tel($g['telefono'])); ?>"><?php echo esc_html($g['telefono']); ?></a><?php endif; ?></li>
				<?php endforeach; ?>
			</ul>
		</section>
	<?php endif; ?>
</aside>
