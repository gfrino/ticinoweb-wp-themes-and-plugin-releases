<?php
/**
 * Prima pagina, come il vecchio sito ma rinnovata: grande foto del territorio, avvisi, ultimi comunicati
 * con «Scarica il PDF» e colonna laterale, i tre paesi, chi siamo.
 */
get_header();
$o = pi_opz();
$avvisi = pi_avvisi_attivi(3);
$ultimi = get_posts(['post_type' => 'post', 'posts_per_page' => 6, 'post__not_in' => wp_list_pluck($avvisi, 'ID'), 'no_found_rows' => true]);
$ev = pi_assemblea_in_evidenza();
$catalogo = get_page_by_path('catalogo-elettorale', OBJECT, 'pi_documento');
$chi = get_page_by_path('chi-siamo');

// Foto della testata: quella scelta nel CMS, poi le foto dei paesi (si alternano piano).
$foto = array_values(array_unique(array_filter([$o['foto_oggi'], $o['intragna_foto'], $o['golino_foto'], $o['verdasio_foto']])));
?>

<?php if ($foto) : ?>
	<section class="pi-hero" aria-label="Il territorio del Patriziato" data-pi-hero>
		<?php foreach ($foto as $i => $id) : ?>
			<figure class="pi-hero__foto<?php echo $i === 0 ? ' pi-attiva' : ''; ?>" <?php echo $i ? 'aria-hidden="true"' : ''; ?>>
				<?php echo pi_foto($id, 'pi-largo', ['loading' => $i ? 'lazy' : 'eager', 'fetchpriority' => $i ? 'auto' : 'high', 'sizes' => '100vw']); ?>
				<?php $didascalia = wp_get_attachment_caption($id); if ($didascalia) : ?><figcaption><?php echo esc_html($didascalia); ?></figcaption><?php endif; ?>
			</figure>
		<?php endforeach; ?>
		<?php if (count($foto) > 1) : ?>
			<button class="pi-hero__pausa" type="button" data-pi-pausa aria-label="Ferma lo scorrimento delle foto">❚❚</button>
		<?php endif; ?>
	</section>
<?php endif; ?>

<section class="pi-benvenuto">
	<div class="contenitore pi-benvenuto__riga">
		<p class="pi-benvenuto__testo"><?php echo esc_html($o['home_intro']); ?></p>
		<ul class="pi-benvenuto__vie" role="list">
			<?php if ($ev) : ?>
				<li><a href="<?php echo esc_url(get_term_link($ev['term'])); ?>"><span><?php echo $ev['futura'] ? 'Prossima assemblea' : 'Ultima assemblea'; ?></span><?php echo esc_html(pi_data_lunga(pi_assemblea_data($ev['term']))); ?></a></li>
			<?php endif; ?>
			<?php if ($catalogo) : ?><li><a href="<?php echo esc_url(get_permalink($catalogo)); ?>"><span>Registri</span>Catalogo elettorale</a></li><?php endif; ?>
			<li><a href="<?php echo esc_url(pi_url('contatti')); ?>"><span>Scrivere al Patriziato</span>Contatti</a></li>
		</ul>
	</div>
</section>

<?php if ($avvisi) : ?>
	<section class="pi-avvisi" aria-label="Avvisi importanti">
		<div class="contenitore">
			<?php foreach ($avvisi as $a) : ?>
				<a class="pi-avviso" href="<?php echo esc_url(get_permalink($a)); ?>">
					<span class="pi-avviso__etichetta">Avviso</span>
					<span class="pi-avviso__titolo"><?php echo esc_html(pi_titolo_pulito(get_the_title($a))); ?></span>
					<span class="pi-avviso__data"><?php echo esc_html(pi_data_lunga(get_post_time('U', false, $a))); ?> »</span>
				</a>
			<?php endforeach; ?>
		</div>
	</section>
<?php endif; ?>

<div class="contenitore pi-colonne">
	<section class="pi-colonne__principale" aria-labelledby="pi-comunicati-titolo">
		<h2 id="pi-comunicati-titolo" class="pi-titolo-sezione">Ultimi comunicati</h2>
		<div class="pi-schede-atti">
			<?php foreach ($ultimi as $p) {
				pi_scheda_atto($p);
			} ?>
		</div>
		<a class="pi-bottone" href="<?php echo esc_url(pi_url_albo()); ?>">Tutti i comunicati</a>
	</section>
	<?php get_template_part('template-parts/laterale'); ?>
</div>

<?php
$paesi = array_filter(pi_paesi(), function ($k) use ($o) {
	return !empty($o[$k . '_foto']);
}, ARRAY_FILTER_USE_KEY);
if ($paesi) : ?>
	<section class="pi-paesi" aria-labelledby="pi-paesi-titolo">
		<div class="contenitore">
			<h2 id="pi-paesi-titolo" class="pi-titolo-sezione">Il territorio</h2>
			<ul class="pi-paesi__griglia" role="list">
				<?php foreach ($paesi as $k => $nome) : ?>
					<li class="pi-paese">
						<a href="<?php echo esc_url(pi_url('territorio') . '#' . $k); ?>">
							<span class="pi-cornice" data-pi-rivela><?php echo pi_foto($o[$k . '_foto'], 'pi-medio', ['sizes' => '(min-width: 1024px) 33vw, (min-width: 600px) 50vw, 100vw']); ?></span>
							<span class="pi-paese__nome"><?php echo esc_html($nome); ?></span>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</section>
<?php endif; ?>

<?php if ($chi) :
	$estratto = preg_match('#<p>(.*?)</p>#s', $chi->post_content, $m) ? wp_strip_all_tags($m[1]) : ''; ?>
	<section class="pi-chi">
		<div class="contenitore pi-chi__griglia">
			<?php if ($o['storia_foto']) : ?>
				<figure class="pi-chi__foto">
					<span class="pi-cornice" data-pi-rivela><?php echo pi_foto($o['storia_foto'], 'pi-medio', ['sizes' => '(min-width: 900px) 40vw, 100vw']); ?></span>
					<figcaption><?php echo esc_html(wp_get_attachment_caption($o['storia_foto'])); ?></figcaption>
				</figure>
			<?php endif; ?>
			<div class="pi-chi__testo">
				<h2 class="pi-titolo-sezione">Chi siamo</h2>
				<p><?php echo esc_html($estratto); ?></p>
				<a class="pi-bottone pi-bottone--linea" href="<?php echo esc_url(get_permalink($chi)); ?>">Il Patriziato e l'Ufficio patriziale</a>
			</div>
		</div>
	</section>
<?php endif; ?>

<?php get_footer(); ?>
