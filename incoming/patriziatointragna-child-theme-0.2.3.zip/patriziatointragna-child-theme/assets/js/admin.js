/* CMS del Patriziato: tipo dell'atto, allegati, file dei documenti, foto e righe delle impostazioni. */
(function ($) {
	'use strict';

	function cornice(opzioni, scelto) {
		var f = wp.media(opzioni);
		f.on('select', function () {
			scelto(f.state().get('selection').toJSON());
		});
		f.open();
	}

	/* Atto: mostra solo i passi che servono al tipo scelto. */
	var $atto = $('[data-pi-atto]');
	if ($atto.length) {
		var aggiorna = function () {
			var $r = $atto.find('input[name="pi_tipo"]:checked');
			var tipo = $r.val() || '';
			$atto.find('[data-se="assemblea"]').prop('hidden', $r.data('assemblea') !== 1);
			$atto.find('[data-se="avviso"]').prop('hidden', tipo !== 'avviso');
			$atto.find('[data-se="convocazione"]').prop('hidden', tipo !== 'convocazione');
			var n = (tipo === 'avviso' || $r.data('assemblea') === 1) ? 3 : 2;
			$atto.find('.pi-passo-testo .pi-numero').text(n);
			$('[data-pi-allegati] .pi-numero').text(n + 1);
		};
		$atto.on('change', 'input[name="pi_tipo"]', aggiorna);
		aggiorna();
	}

	/* Allegati: aggiungi, riordina, togli. */
	var $all = $('[data-pi-allegati]');
	if ($all.length) {
		var $lista = $all.find('.pi-allegati__lista');
		$all.on('click', '[data-aggiungi-allegati]', function () {
			cornice({ title: 'Scegli o carica documenti e foto', button: { text: 'Allega' }, multiple: true }, function (files) {
				files.forEach(function (f) {
					if ($lista.find('li[data-id="' + f.id + '"]').length) { return; }
					var formato = (f.filename || '').split('.').pop().toUpperCase();
					var $li = $('<li>').attr('data-id', f.id).append(
						$('<input type="hidden" name="pi_allegati[]">').val(f.id),
						$('<span class="pi-formato">').text(formato),
						$('<span class="pi-nome">').text(f.title || f.filename),
						$('<span class="pi-azioni">').append(
							'<button type="button" class="button-link" data-su aria-label="Sposta su">↑</button>',
							'<button type="button" class="button-link" data-giu aria-label="Sposta giù">↓</button>',
							'<button type="button" class="button-link pi-togli" data-togli-allegato>Togli</button>'
						)
					);
					$lista.append($li);
				});
			});
		});
		$all.on('click', '[data-togli-allegato]', function () { $(this).closest('li').remove(); });
		$all.on('click', '[data-su]', function () { var $li = $(this).closest('li'); $li.prev().before($li); });
		$all.on('click', '[data-giu]', function () { var $li = $(this).closest('li'); $li.next().after($li); });
	}

	/* Documento: scegli il file nuovo. */
	var $doc = $('[data-pi-file]');
	if ($doc.length) {
		$doc.on('click', '[data-scegli-file]', function () {
			cornice({ title: 'Scegli o carica il file', button: { text: 'Usa questo file' }, multiple: false }, function (files) {
				var f = files[0];
				if (!f) { return; }
				$doc.find('[data-file-id]').val(f.id);
				$doc.find('[data-file-nome]').empty().append(
					$('<span class="pi-formato">').text((f.filename || '').split('.').pop().toUpperCase()),
					document.createTextNode(' ' + (f.title || f.filename))
				);
				var orig = String($doc.find('[data-file-id]').data('originale'));
				$doc.find('[data-avviso-sostituzione]').prop('hidden', orig === '0' || orig === String(f.id));
			});
		});
	}

	/* Impostazioni: foto. */
	$(document).on('click', '[data-pi-foto] [data-scegli]', function () {
		var $c = $(this).closest('[data-pi-foto]');
		cornice({ title: 'Scegli una foto', button: { text: 'Usa questa foto' }, library: { type: 'image' }, multiple: false }, function (files) {
			var f = files[0];
			if (!f) { return; }
			var src = (f.sizes && (f.sizes.medium || f.sizes.full) || {}).url || f.url;
			$c.find('input').val(f.id);
			$c.find('img').attr('src', src).prop('hidden', false);
			$c.find('[data-togli]').prop('hidden', false);
		});
	});
	$(document).on('click', '[data-pi-foto] [data-togli]', function () {
		var $c = $(this).closest('[data-pi-foto]');
		$c.find('input').val('0');
		$c.find('img').prop('hidden', true);
		$(this).prop('hidden', true);
	});

	/* Impostazioni: righe ripetibili. */
	$(document).on('click', '[data-aggiungi-riga]', function () {
		var nome = $(this).data('aggiungi-riga');
		var $c = $('[data-pi-righe="' + nome + '"]');
		var $n = $c.find('.pi-riga').last().clone();
		var i = Date.now();
		$n.find('input').each(function () {
			this.value = '';
			this.name = this.name.replace(/\[\d+\]/, '[' + i + ']');
		});
		$c.append($n);
		$n.find('input').first().trigger('focus');
	});
	$(document).on('click', '[data-togli-riga]', function () {
		var $c = $(this).closest('[data-pi-righe]');
		if ($c.find('.pi-riga').length > 1) {
			$(this).closest('.pi-riga').remove();
		} else {
			$(this).closest('.pi-riga').find('input').val('');
		}
	});
})(jQuery);

/* Moduli semplici: nomi dei file scelti, avviso in prima pagina, conferma prima di togliere. */
(function () {
	'use strict';
	document.querySelectorAll('[data-pi-file]').forEach(function (inp) {
		inp.addEventListener('change', function () {
			var box = inp.closest('label').querySelector('[data-pi-file-nomi]');
			if (!box) { return; }
			var nomi = Array.prototype.map.call(inp.files, function (f) { return f.name; });
			box.textContent = nomi.length ? 'Scelto: ' + nomi.join(', ') : '';
			box.classList.toggle('pi-ok', nomi.length > 0);
		});
	});
	var ev = document.querySelector('[data-pi-evidenza]');
	if (ev) {
		ev.addEventListener('change', function () {
			var f = document.querySelector('[data-pi-fino]');
			f.hidden = !ev.checked;
			var d = f.querySelector('input');
			if (ev.checked && !d.value) {
				var t = new Date(Date.now() + 14 * 864e5);
				d.value = t.toISOString().slice(0, 10);
			}
		});
	}
	document.querySelectorAll('[data-pi-conferma]').forEach(function (f) {
		f.addEventListener('submit', function (e) {
			if (!window.confirm(f.getAttribute('data-pi-conferma'))) { e.preventDefault(); }
		});
	});
	document.querySelectorAll('.pi-modulo-semplice, .pi-doc').forEach(function (f) {
		f.addEventListener('submit', function () {
			var b = f.querySelector('button[type="submit"]');
			if (b) { b.disabled = true; b.textContent = 'Un momento, sto caricando…'; }
		});
	});
})();
