<?php
/**
 * Territorio: i tre paesi (testo e foto dal CMS, pagina «Il Patriziato»), le strade forestali e i gettoni,
 * poi il testo libero della pagina (galleria, note).
 */
get_header();
$o = pi_opz();
pi_testa_pagina(get_the_title(), $o['territorio_intro']);
?>
<div class="pi-territorio contenitore">
	<div class="pi-territorio__griglia">
	<?php foreach (pi_paesi() as $k => $nome) :
		if (!$o[$k . '_testo'] && !$o[$k . '_foto']) {
			continue;
		}
		?>
		<section class="pi-luogo" id="<?php echo esc_attr($k); ?>">
			<?php if ($o[$k . '_foto']) : ?>
				<figure class="pi-luogo__foto">
					<div class="pi-cornice" data-pi-rivela><?php echo pi_foto($o[$k . '_foto'], 'pi-largo', ['sizes' => '(min-width: 900px) 33vw, 100vw']); ?></div>
					<?php $cr = pi_credito($o[$k . '_foto']); if ($cr) : ?><figcaption><?php echo esc_html($cr); ?></figcaption><?php endif; ?>
				</figure>
			<?php endif; ?>
			<div class="pi-luogo__testo">
				<h2><?php echo esc_html($nome); ?></h2>
				<div class="pi-testo"><?php echo pi_paragrafi($o[$k . '_testo']); ?></div>
			</div>
		</section>
	<?php endforeach; ?>
	</div>

	<?php if ($o['strade_testo'] || $o['gettoni']) : ?>
		<section class="pi-strade" id="strade-forestali">
			<div class="pi-strade__griglia">
				<div>
					<h2>Strade forestali</h2>
					<div class="pi-testo"><?php echo pi_paragrafi($o['strade_testo']); ?></div>
					<?php $reg = get_page_by_path('regolamento-concernente-luso-delle-strade-forestali', OBJECT, 'pi_documento');
					if ($reg) : ?>
						<a class="pi-link-freccia" href="<?php echo esc_url(get_permalink($reg)); ?>">Regolamento per l'uso delle strade forestali</a>
					<?php endif; ?>
				</div>
				<?php if ($o['gettoni']) : ?>
					<aside class="pi-box pi-box--gettoni">
						<h2>Dove si comprano i gettoni</h2>
						<?php echo $o['gettoni_testo'] ? '<p>' . esc_html($o['gettoni_testo']) . '</p>' : ''; ?>
						<ul role="list">
							<?php foreach ($o['gettoni'] as $g) : ?>
								<li><strong><?php echo esc_html($g['nome']); ?></strong><?php if ($g['telefono']) : ?><br><a href="tel:<?php echo esc_attr(pi_tel($g['telefono'])); ?>"><?php echo esc_html($g['telefono']); ?></a><?php endif; ?></li>
							<?php endforeach; ?>
						</ul>
					</aside>
				<?php endif; ?>
			</div>
		</section>
	<?php endif; ?>

	<?php while (have_posts()) : the_post();
		if (trim(get_the_content()) !== '') : ?>
			<section class="pi-strade"><div class="pi-testo"><?php the_content(); ?></div></section>
		<?php endif;
	endwhile; ?>
</div>
<?php get_footer(); ?>
