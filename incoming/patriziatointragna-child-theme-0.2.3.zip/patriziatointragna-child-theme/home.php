<?php
/**
 * Comunicati: tutti gli atti dal più recente, come sul vecchio sito, con la ricerca e un filtro semplice per tipo.
 */
get_header();
$tipo_sel = sanitize_key($_GET['tipo'] ?? '');
$base = pi_url_albo();
pi_testa_pagina('Comunicati', 'Convocazioni, verbali, risoluzioni, avvisi e ratifiche, dal più recente.');
?>
<div class="contenitore pi-colonne">
	<div class="pi-colonne__principale">
		<form class="pi-cerca" role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
			<label for="pi-cerca-albo">Cerca un comunicato</label>
			<input id="pi-cerca-albo" type="search" name="s" placeholder="legna, verbale 2024…">
			<button type="submit" class="pi-bottone">Cerca</button>
		</form>
		<nav class="pi-filtri" aria-label="Mostra solo">
			<a href="<?php echo esc_url($base); ?>" class="pi-chip" <?php echo $tipo_sel ? '' : 'aria-current="true"'; ?>>Tutti</a>
			<?php foreach (['convocazione' => 'Convocazioni', 'verbale' => 'Verbali', 'risoluzioni' => 'Risoluzioni', 'avviso' => 'Avvisi', 'ratifica' => 'Ratifiche'] as $slug => $nome) : ?>
				<a href="<?php echo esc_url(add_query_arg('tipo', $slug, $base)); ?>" class="pi-chip" <?php echo $tipo_sel === $slug ? 'aria-current="true"' : ''; ?>><?php echo esc_html($nome); ?></a>
			<?php endforeach; ?>
		</nav>
		<?php if (have_posts()) : ?>
			<div class="pi-schede-atti">
				<?php while (have_posts()) : the_post();
					pi_scheda_atto(get_post(), 2);
				endwhile; ?>
			</div>
			<nav class="pi-paginazione" aria-label="Altre pagine">
				<?php echo paginate_links(['prev_text' => '« Più recenti', 'next_text' => 'Meno recenti »', 'mid_size' => 1]); ?>
			</nav>
		<?php else : ?>
			<p class="pi-vuoto">Nessun comunicato. <a href="<?php echo esc_url($base); ?>">Mostra tutti</a>.</p>
		<?php endif; ?>
	</div>
	<?php get_template_part('template-parts/laterale'); ?>
</div>
<?php get_footer(); ?>
