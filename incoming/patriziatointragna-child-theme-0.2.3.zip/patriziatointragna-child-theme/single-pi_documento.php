<?php
/**
 * Un documento: versione in vigore con anteprima e storico delle versioni.
 */
get_header();
while (have_posts()) : the_post();
	$id = get_the_ID();
	$file = pi_documento_file($id);
	$dal = get_post_meta($id, '_pi_valido_dal', true);
	$desc = get_post_meta($id, '_pi_descrizione', true);
	$vers = pi_documento_versioni($id);
	$riservato = pi_documento_riservato($id);
	$racc = pi_raccolte()[pi_documento_raccolta($id)];
	pi_testa_pagina(get_the_title(), $desc, ['Documenti', get_post_type_archive_link('pi_documento') . '#' . pi_documento_raccolta($id)]);
	?>
	<div class="contenitore pi-atto__corpo">
		<div class="pi-atto__principale">
			<?php if ($file && !$riservato) {
				pi_anteprima_pdf($file);
			} elseif ($file) {
				echo '<p class="pi-grande">Il documento si apre come PDF. Contiene i nomi dei patrizi: non è indicizzato dai motori di ricerca.</p>';
			} else {
				echo '<p class="pi-vuoto">Il documento non è ancora disponibile.</p>';
			} ?>
		</div>
		<aside class="pi-atto__lato">
			<h2 class="pi-lato__titolo">Versione in vigore</h2>
			<?php if ($dal) : ?><p class="pi-meta">Dal <?php echo esc_html(pi_data_lunga($dal)); ?></p><?php endif; ?>
			<?php pi_lista_file($file ? [$file] : [], $riservato); ?>
			<?php if ($vers && !$riservato) : // registri con nomi di persone: solo la versione in vigore (minimizzazione dei dati) ?>
				<h2 class="pi-lato__titolo">Versioni precedenti</h2>
				<ul class="pi-lato__lista" role="list">
					<?php foreach ($vers as $v) :
						$vi = pi_file_info((int) $v['file']);
						if (!$vi) {
							continue;
						} ?>
						<li><a href="<?php echo esc_url($vi['url']); ?>"<?php echo $riservato ? ' rel="nofollow"' : ''; ?>><?php echo esc_html($vi['titolo']); ?></a> <span><?php echo esc_html(pi_data_breve($v['data'])); ?></span></li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
			<p class="pi-meta">Raccolta: <a href="<?php echo esc_url(get_post_type_archive_link('pi_documento') . '#' . pi_documento_raccolta($id)); ?>"><?php echo esc_html($racc[0]); ?></a></p>
		</aside>
	</div>
<?php endwhile;
get_footer();
