</main>
<?php
$c = function_exists('ticinoweb_get_contact_info') ? ticinoweb_get_contact_info() : [];
$email = $c['email'] ?? '';
$indirizzo = $c['address'] ?? '';
$logo = function_exists('ticinoweb_get_site_logo') ? ticinoweb_get_site_logo() : '';
$privacy = get_privacy_policy_url();
$crediti = get_page_by_path('crediti-fotografici');
$patriziato = get_page_by_path('chi-siamo');
$chi = '';
if ($patriziato && preg_match('#<p>(.*?)</p>#s', $patriziato->post_content, $m)) {
	$chi = wp_trim_words(wp_strip_all_tags($m[1]), 38);
}
?>
<footer class="pi-piede">
	<div class="contenitore pi-piede__alto">
		<div class="pi-piede__marca">
			<?php if ($logo) : ?><img src="<?php echo esc_url($logo); ?>" alt="" width="96" height="96" loading="lazy"><?php endif; ?>
			<p><?php echo esc_html(get_bloginfo('name')); ?></p>
		</div>
		<?php if ($chi) : ?>
			<div>
				<h2 class="pi-piede__titolo">Chi siamo</h2>
				<p><?php echo esc_html($chi); ?></p>
				<a class="pi-piede__link" href="<?php echo esc_url(get_permalink($patriziato)); ?>">Chi siamo →</a>
			</div>
		<?php endif; ?>
		<div>
			<h2 class="pi-piede__titolo">Contatti</h2>
			<?php if ($indirizzo) : ?><p><?php echo nl2br(esc_html($indirizzo)); ?></p><?php endif; ?>
			<?php if ($email) : ?><p><a href="mailto:<?php echo esc_attr($email); ?>"><?php echo esc_html($email); ?></a></p><?php endif; ?>
		</div>
		<nav aria-label="Pagine del sito">
			<h2 class="pi-piede__titolo">Pagine</h2>
			<?php
			if (has_nav_menu('pi-piede')) {
				wp_nav_menu(['theme_location' => 'pi-piede', 'container' => false, 'menu_class' => 'pi-piede__lista', 'depth' => 1]);
			} else {
				pi_menu_di_ripiego();
			}
			?>
		</nav>
	</div>
	<div class="pi-piede__basso">
		<div class="contenitore pi-piede__basso-riga">
			<span>© <?php echo esc_html(wp_date('Y')); ?> <?php echo esc_html(get_bloginfo('name')); ?></span>
			<?php if ($privacy) : ?><a href="<?php echo esc_url($privacy); ?>">Privacy</a><?php endif; ?>
			<?php if ($crediti && $crediti->post_status === 'publish') : ?><a href="<?php echo esc_url(get_permalink($crediti)); ?>">Crediti fotografici</a><?php endif; ?>
			<a href="<?php echo esc_url(trailingslashit(get_option('home')) . 'tw-login/'); ?>" rel="nofollow">Area riservata</a>
			<span class="pi-piede__firma">design by <a href="https://ticinoweb.com" target="_blank" rel="noopener">ticinoWEB</a></span>
		</div>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
