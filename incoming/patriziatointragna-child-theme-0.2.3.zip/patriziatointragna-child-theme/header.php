<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="pi-salta" href="#contenuto">Vai al contenuto</a>
<?php
$c = function_exists('ticinoweb_get_contact_info') ? ticinoweb_get_contact_info() : [];
$email = $c['email'] ?? '';
$logo = function_exists('ticinoweb_get_site_logo') ? ticinoweb_get_site_logo() : '';
?>
<div class="pi-barra">
	<div class="contenitore pi-barra__riga">
		<span class="pi-barra__luogo">Intragna · Golino · Verdasio</span>
		<?php if ($email) : ?><a href="mailto:<?php echo esc_attr($email); ?>"><?php echo esc_html($email); ?></a><?php endif; ?>
	</div>
</div>
<header class="pi-testata">
	<div class="contenitore pi-testata__marca">
		<a class="pi-marca" href="<?php echo esc_url(home_url('/')); ?>" rel="home">
			<?php if ($logo) : ?><img src="<?php echo esc_url($logo); ?>" alt="Stemma del Patriziato" width="88" height="88"><?php endif; ?>
			<?php if (is_front_page()) : ?><h1 class="pi-marca__nome"><?php echo esc_html(get_bloginfo('name')); ?></h1><?php else : ?><span class="pi-marca__nome"><?php echo esc_html(get_bloginfo('name')); ?></span><?php endif; ?>
		</a>
		<button class="pi-menu-btn" type="button" aria-expanded="false" aria-controls="pi-navigazione" data-pi-menu>
			<span class="pi-menu-btn__linee" aria-hidden="true"></span><span class="pi-menu-btn__testo">Menu</span>
		</button>
	</div>
	<nav class="pi-nav" id="pi-navigazione" aria-label="Menu principale">
		<div class="contenitore pi-nav__riga">
			<?php
			wp_nav_menu([
				'theme_location' => 'pi-principale',
				'container'      => false,
				'menu_class'     => 'pi-nav__lista',
				'depth'          => 2,
				'fallback_cb'    => 'pi_menu_di_ripiego',
			]);
			?>
			<form class="pi-nav__cerca" role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
				<label for="pi-cerca-testata">Cerca nel sito</label>
				<input id="pi-cerca-testata" type="search" name="s" placeholder="Cerca" value="<?php echo esc_attr(get_search_query(false)); ?>">
			</form>
		</div>
	</nav>
</header>
<main id="contenuto" class="pi-principale">
