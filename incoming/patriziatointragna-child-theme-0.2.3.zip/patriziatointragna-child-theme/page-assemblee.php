<?php
/**
 * Assemblee: una riga per assemblea con gli atti disponibili. Le schede nascono da sole dagli atti.
 */
get_header();
pi_testa_pagina(get_the_title(), 'Ogni assemblea patriziale con convocazione, messaggi, verbale, risoluzioni e presenze, appena pubblicati.');
$oggi = current_time('Y-m-d');
$per_anno = [];
foreach (pi_assemblee() as $t) {
	$d = pi_assemblea_data($t);
	$per_anno[substr($d, 0, 4)][] = $t;
}
?>
<div class="contenitore pi-assemblee">
	<?php while (have_posts()) : the_post();
		if (trim(get_the_content()) !== '') : ?>
			<div class="pi-testo pi-intro"><?php the_content(); ?></div>
		<?php endif;
	endwhile; ?>
	<?php foreach ($per_anno as $anno => $terms) : ?>
		<section class="pi-anno">
			<h2 class="pi-anno__titolo"><?php echo esc_html($anno); ?></h2>
			<ol class="pi-assemblee__lista" role="list">
				<?php foreach ($terms as $t) :
					$d = pi_assemblea_data($t);
					$atti = pi_atti_assemblea($t->term_id); ?>
					<li class="pi-assemblea-riga<?php echo $d >= $oggi ? ' pi-assemblea-riga--futura' : ''; ?>">
						<span class="pi-assemblea-riga__data" aria-hidden="true">
							<span class="pi-assemblea-riga__giorno"><?php echo esc_html(wp_date('j', strtotime($d . ' 12:00'))); ?></span>
							<span><?php echo esc_html(pi_mese((int) wp_date('n', strtotime($d . ' 12:00')))); ?></span>
						</span>
						<div>
							<p class="pi-assemblea-riga__titolo"><a href="<?php echo esc_url(get_term_link($t)); ?>"><?php echo $d >= $oggi ? 'Prossima assemblea' : 'Assemblea patriziale'; ?> del <?php echo esc_html(pi_data_lunga($d)); ?></a></p>
							<ul class="pi-assemblea-riga__atti" role="list">
								<?php foreach ($atti as $a) : ?>
									<li><a href="<?php echo esc_url(get_permalink($a)); ?>"><?php echo esc_html(pi_tipo_etichetta(pi_tipo_di($a->ID))); ?></a></li>
								<?php endforeach; ?>
							</ul>
						</div>
					</li>
				<?php endforeach; ?>
			</ol>
		</section>
	<?php endforeach; ?>
	<?php if (!$per_anno) : ?><p class="pi-vuoto">Nessuna assemblea pubblicata.</p><?php endif; ?>
</div>
<?php get_footer(); ?>
