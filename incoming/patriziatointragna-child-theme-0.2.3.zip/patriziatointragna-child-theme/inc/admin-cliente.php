<?php
/**
 * Il CMS del Patriziato: un Cruscotto e un menu corto, con le stesse voci, icone e colori.
 * Cruscotto · Pubblicazioni · Documenti · Ufficio patriziale · Gettoni.
 * Gli amministratori vedono in più ticinoWEB CMS, Pagine, Media e gli strumenti tecnici.
 */
if (!defined('ABSPATH')) {
	exit;
}

function pi_e_cliente() {
	return !current_user_can('manage_options');
}

/** Le sezioni del CMS: stesso nome, icona e colore nel menu e nel Cruscotto. */
function pi_sezioni_cms() {
	return [
		'pi-pubblicazioni' => ['nome' => 'Pubblicazioni', 'icona' => 'megaphone', 'colore' => '#2f5bea', 'testo' => 'Pubblica un comunicato o un avviso, correggi quelli già online.', 'link' => 'admin.php?page=pi-pubblica', 'azione' => 'Nuova pubblicazione'],
		'pi-documenti'     => ['nome' => 'Documenti', 'icona' => 'media-document', 'colore' => '#1f8a4c', 'testo' => 'Catalogo elettorale, elenco dei patrizi e regolamenti: carica la versione nuova.', 'link' => 'admin.php?page=pi-documenti', 'azione' => 'Aggiorna un documento'],
		'pi-ufficio'       => ['nome' => 'Ufficio patriziale', 'icona' => 'groups', 'colore' => '#7b3fc4', 'testo' => 'Le persone dell\'amministrazione con i loro recapiti.', 'link' => 'admin.php?page=pi-ufficio', 'azione' => 'Modifica le persone'],
		'pi-gettoni'       => ['nome' => 'Gettoni', 'icona' => 'tickets-alt', 'colore' => '#d9730d', 'testo' => 'Dove si comprano i gettoni per le strade forestali.', 'link' => 'admin.php?page=pi-gettoni', 'azione' => 'Modifica i punti vendita'],
	];
}

add_action('admin_menu', function () {
	add_menu_page('Cruscotto', 'Cruscotto', 'edit_posts', 'pi-cruscotto', 'pi_pagina_cruscotto', 'dashicons-admin-home', 1);
}, 5);

// Voci che nessuno deve vedere (la Bacheca diventa il Cruscotto; atti e documenti hanno le pagine semplici).
add_action('admin_menu', function () {
	foreach (['index.php', 'edit.php', 'edit.php?post_type=pi_documento', 'edit-comments.php'] as $m) {
		remove_menu_page($m);
	}
	if (pi_e_cliente()) {
		foreach (['tools.php', 'themes.php', 'options-general.php', 'plugins.php', 'edit.php?post_type=page', 'upload.php', 'edit.php?post_type=tw_faq'] as $m) {
			remove_menu_page($m);
		}
	}
}, 999);

add_filter('custom_menu_order', '__return_true', 1000);
add_filter('menu_order', function ($ordine) {
	$prima = ['pi-cruscotto', 'pi-pubblicazioni', 'pi-documenti', 'pi-ufficio', 'pi-gettoni', 'separator1', 'ticinoweb-cms'];
	$resto = array_values(array_diff($ordine, $prima));
	return array_merge(array_values(array_intersect($prima, $ordine)), $resto);
}, 1001);

// Il parent rimette ticinoWEB CMS subito sotto la Bacheca (che qui non c'è più, quindi in cima):
// su questo sito le cinque voci del Patriziato vengono prima. Si toglie solo quel filtro, il parent non si tocca.
add_action('admin_init', function () {
	remove_filter('submenu_file', 'ticinoweb_admin_ui_menu_cms_second', PHP_INT_MAX);
	remove_filter('menu_order', 'ticinoweb_admin_ui_menu_order', 999);
});
add_filter('submenu_file', function ($f) {
	global $menu;
	if (!is_array($menu)) {
		return $f;
	}
	$nostre = ['pi-cruscotto', 'pi-pubblicazioni', 'pi-documenti', 'pi-ufficio', 'pi-gettoni'];
	$davanti = [];
	foreach ($menu as $k => $voce) {
		if (in_array($voce[2] ?? '', $nostre, true)) {
			$davanti[$voce[2]] = $voce;
			unset($menu[$k]);
		}
	}
	$ordinati = [];
	foreach ($nostre as $slug) {
		if (isset($davanti[$slug])) {
			$ordinati[] = $davanti[$slug];
		}
	}
	$menu = array_merge($ordinati, array_values($menu));
	return $f;
}, PHP_INT_MAX);

// Dopo l'accesso, e da «Bacheca», si arriva al Cruscotto. Vale per tutti.
add_filter('login_redirect', function ($to, $req, $user) {
	if ($user instanceof WP_User && user_can($user, 'edit_posts') && ($to === '' || strpos((string) $to, 'wp-admin') !== false)) {
		return admin_url('admin.php?page=pi-cruscotto');
	}
	return $to;
}, 20, 3);
add_action('load-index.php', function () {
	wp_safe_redirect(admin_url('admin.php?page=pi-cruscotto'));
	exit;
});

// Niente avvisi tecnici (aggiornamenti, plugin) per il Patriziato.
add_action('admin_head', function () {
	if (pi_e_cliente()) {
		remove_all_actions('admin_notices');
		remove_all_actions('all_admin_notices');
	}
}, 1);

// Colore di ogni sezione anche sull'icona del menu a sinistra.
add_action('admin_head', function () {
	echo '<style>';
	foreach (pi_sezioni_cms() as $slug => $s) {
		printf('#toplevel_page_%1$s .wp-menu-image::before{color:%2$s!important;opacity:1}#toplevel_page_%1$s.current .wp-menu-image::before,#toplevel_page_%1$s.wp-has-current-submenu .wp-menu-image::before{color:#fff!important}', esc_attr($slug), esc_attr($s['colore']));
	}
	echo '</style>';
});

add_filter('admin_footer_text', function ($t) {
	return pi_e_cliente() ? 'Hai bisogno di aiuto? Contatta <a href="https://ticinoweb.com" target="_blank" rel="noopener">ticinoWEB</a>.' : $t;
});

add_action('admin_enqueue_scripts', function ($hook) {
	$schermo = get_current_screen();
	$tipo = $schermo->post_type ?? '';
	$nostre = strpos($hook, 'pi-') !== false || in_array($tipo, ['post', 'pi_documento', 'page'], true);
	if (!$nostre) {
		return;
	}
	if (in_array($hook, ['post.php', 'post-new.php'], true) || strpos($hook, 'pi-patriziato') !== false) {
		wp_enqueue_media();
	}
	wp_enqueue_style('pi-admin', PI_URI . '/assets/css/admin.css', [], PI_VERSIONE . '.' . filemtime(PI_DIR . '/assets/css/admin.css'));
	wp_enqueue_script('pi-admin', PI_URI . '/assets/js/admin.js', ['jquery'], PI_VERSIONE . '.' . filemtime(PI_DIR . '/assets/js/admin.js'), true);
});

/** Riga di un elenco nel Cruscotto. */
function pi_cruscotto_riga($p, $nota = '') {
	printf(
		'<li><a href="%s"><span class="pi-c-tipo">%s</span> %s</a><span class="pi-c-meta">%s%s</span></li>',
		esc_url((string) get_edit_post_link($p->ID)),
		esc_html($p->post_type === 'pi_documento' ? 'Documento' : pi_tipo_etichetta(pi_tipo_di($p->ID))),
		esc_html(pi_titolo_pulito(get_the_title($p)) ?: '(senza titolo)'),
		esc_html(get_the_date('d.m.Y', $p)),
		$nota ? ' · ' . esc_html($nota) : ''
	);
}

function pi_pagina_cruscotto() {
	$utente = wp_get_current_user();
	$ora = (int) current_time('G');
	$saluto = $ora < 12 ? 'Buongiorno' : ($ora < 18 ? 'Buon pomeriggio' : 'Buonasera');
	$avvisi = pi_avvisi_attivi(5);
	$ev = pi_assemblea_in_evidenza();
	$ultimi = get_posts(['post_type' => 'post', 'posts_per_page' => 6, 'no_found_rows' => true]);
	?>
	<div class="wrap pi-cruscotto">
		<h1><?php echo esc_html($saluto . ($utente->first_name ? ', ' . $utente->first_name : '')); ?></h1>
		<p class="pi-aiuto">Scegli che cosa vuoi fare. Il sito si aggiorna da solo. <a href="<?php echo esc_url(home_url('/')); ?>" target="_blank" rel="noopener">Apri il sito ↗</a></p>

		<div class="pi-azioni-grandi">
			<?php foreach (pi_sezioni_cms() as $s) : ?>
				<a class="pi-azione" href="<?php echo esc_url(admin_url($s['link'])); ?>" style="--pi-colore: <?php echo esc_attr($s['colore']); ?>">
					<span class="pi-azione__icona dashicons dashicons-<?php echo esc_attr($s['icona']); ?>" aria-hidden="true"></span>
					<strong><?php echo esc_html($s['nome']); ?></strong>
					<span class="pi-azione__testo"><?php echo esc_html($s['testo']); ?></span>
					<span class="pi-azione__vai"><?php echo esc_html($s['azione']); ?> →</span>
				</a>
			<?php endforeach; ?>
		</div>

		<div class="pi-pannelli">
			<section class="pi-pannello">
				<h2>Avvisi in prima pagina</h2>
				<?php if ($avvisi) : ?>
					<ul>
						<?php foreach ($avvisi as $a) {
							pi_cruscotto_riga($a, 'fino al ' . pi_data_breve(get_post_meta($a->ID, '_pi_evidenza_fino', true)));
						} ?>
					</ul>
				<?php else : ?>
					<p class="pi-vuoto">Nessun avviso in prima pagina. Quando pubblichi qualcosa di importante, spunta «È un avviso importante».</p>
				<?php endif; ?>
			</section>

			<section class="pi-pannello">
				<h2><?php echo $ev && $ev['futura'] ? 'Prossima assemblea' : 'Ultima assemblea'; ?></h2>
				<?php if ($ev) :
					$t = $ev['term'];
					$atti = pi_atti_assemblea($t->term_id);
					$presenti = array_map(function ($p) {
						return pi_tipo_di($p->ID);
					}, $atti);
					$attesi = $ev['futura'] ? ['convocazione'] : ['convocazione', 'verbale', 'risoluzioni'];
					$mancano = array_diff($attesi, $presenti); ?>
					<p><strong><?php echo esc_html(pi_data_lunga(pi_assemblea_data($t))); ?></strong> · <a href="<?php echo esc_url(get_term_link($t)); ?>" target="_blank" rel="noopener">pagina sul sito ↗</a></p>
					<ul>
						<?php foreach ($atti as $a) {
							pi_cruscotto_riga($a);
						} ?>
					</ul>
					<?php if ($mancano) : ?>
						<p class="pi-manca">Ancora da pubblicare: <?php echo esc_html(implode(', ', array_map('pi_tipo_etichetta', $mancano))); ?>.</p>
					<?php endif; ?>
				<?php else : ?>
					<p class="pi-vuoto">Nessuna assemblea ancora.</p>
				<?php endif; ?>
			</section>

			<section class="pi-pannello">
				<h2>Ultime pubblicazioni</h2>
				<ul>
					<?php foreach ($ultimi as $p) {
						pi_cruscotto_riga($p);
					} ?>
				</ul>
				<p><a href="<?php echo esc_url(admin_url('admin.php?page=pi-pubblicazioni')); ?>">Tutte le pubblicazioni →</a></p>
			</section>
		</div>
	</div>
	<?php
}
