<?php
/**
 * Pagina «Il Patriziato» nel ticinoWEB CMS: i dati del sito che non sono atti né documenti.
 * Tutto in un'opzione sola `pi_opzioni`. Contatti (email, indirizzo) restano quelli del parent:
 * ticinoWEB CMS → Contatti (`ticinoweb_contact_*`).
 */
if (!defined('ABSPATH')) {
	exit;
}

function pi_paesi() {
	return ['intragna' => 'Intragna', 'golino' => 'Golino', 'verdasio' => 'Verdasio'];
}

function pi_opzioni_vuote() {
	$o = [
		'home_intro'     => '',
		'foto_oggi'      => 0,
		'foto_ieri'      => 0,
		'foto_ieri_nota' => '',
		'membri'         => [],
		'gettoni_testo'  => '',
		'gettoni'        => [],
		'strade_testo'   => '',
		'storia_foto'    => 0,
		'territorio_intro' => '',
		'contatti_nota'  => '',
	];
	foreach (array_keys(pi_paesi()) as $p) {
		$o[$p . '_testo'] = '';
		$o[$p . '_foto']  = 0;
	}
	return $o;
}

function pi_opz($chiave = null) {
	static $o = null;
	if ($o === null) {
		$o = wp_parse_args((array) get_option('pi_opzioni', []), pi_opzioni_vuote());
	}
	return $chiave === null ? $o : ($o[$chiave] ?? '');
}

if (!is_admin()) {
	return;
}

/*
 * Tre pagine separate, ognuna con la sua voce nel menu e il suo pulsante nel Cruscotto:
 * Ufficio patriziale, Gettoni (per il Patriziato) e Testi e foto del sito (sotto ticinoWEB CMS).
 * Ognuna salva solo i suoi campi.
 */
function pi_sezioni_impostazioni() {
	return [
		'ufficio' => ['titolo' => 'Ufficio patriziale', 'pagina' => 'pi-ufficio'],
		'gettoni' => ['titolo' => 'Gettoni', 'pagina' => 'pi-gettoni'],
		'sito'    => ['titolo' => 'Testi e foto del sito', 'pagina' => 'pi-patriziato'],
	];
}

add_action('admin_menu', function () {
	add_menu_page('Ufficio patriziale', 'Ufficio patriziale', 'edit_pages', 'pi-ufficio', function () {
		pi_pagina_impostazioni('ufficio');
	}, 'dashicons-groups', 4);
	add_menu_page('Gettoni', 'Gettoni', 'edit_pages', 'pi-gettoni', function () {
		pi_pagina_impostazioni('gettoni');
	}, 'dashicons-tickets-alt', 5);
	add_submenu_page('ticinoweb-cms', 'Testi e foto del sito', 'Testi e foto del sito', 'edit_pages', 'pi-patriziato', function () {
		pi_pagina_impostazioni('sito');
	});
}, 20);

add_action('admin_post_pi_salva_impostazioni', 'pi_salva_impostazioni');
function pi_salva_impostazioni() {
	if (!current_user_can('edit_pages')) {
		wp_die('Non hai i permessi per questa operazione.');
	}
	check_admin_referer('pi_impostazioni');
	$sezione = sanitize_key($_POST['sezione'] ?? '');
	if (!isset(pi_sezioni_impostazioni()[$sezione])) {
		wp_die('Sezione sconosciuta.');
	}
	$in = wp_unslash($_POST['pi'] ?? []);
	$o  = wp_parse_args((array) get_option('pi_opzioni', []), pi_opzioni_vuote()); // le altre sezioni restano come sono

	if ($sezione === 'ufficio') {
		$o['contatti_nota'] = sanitize_textarea_field($in['contatti_nota'] ?? '');
		$o['membri'] = [];
		foreach ((array) ($in['membri'] ?? []) as $m) {
			$r = [
				'nome'     => sanitize_text_field($m['nome'] ?? ''),
				'ruolo'    => sanitize_text_field($m['ruolo'] ?? ''),
				'email'    => sanitize_email($m['email'] ?? ''),
				'telefono' => sanitize_text_field($m['telefono'] ?? ''),
			];
			if ($r['nome'] !== '') {
				$o['membri'][] = $r;
			}
		}
	}
	if ($sezione === 'gettoni') {
		$o['gettoni_testo'] = sanitize_textarea_field($in['gettoni_testo'] ?? '');
		$o['strade_testo'] = sanitize_textarea_field($in['strade_testo'] ?? '');
		$o['gettoni'] = [];
		foreach ((array) ($in['gettoni'] ?? []) as $g) {
			$r = ['nome' => sanitize_text_field($g['nome'] ?? ''), 'telefono' => sanitize_text_field($g['telefono'] ?? '')];
			if ($r['nome'] !== '') {
				$o['gettoni'][] = $r;
			}
		}
	}
	if ($sezione === 'sito') {
		foreach (['home_intro', 'territorio_intro'] as $k) {
			$o[$k] = sanitize_textarea_field($in[$k] ?? '');
		}
		$o['foto_ieri_nota'] = sanitize_text_field($in['foto_ieri_nota'] ?? '');
		foreach (['foto_oggi', 'foto_ieri', 'storia_foto'] as $k) {
			$o[$k] = absint($in[$k] ?? 0);
		}
		foreach (array_keys(pi_paesi()) as $p) {
			$o[$p . '_testo'] = sanitize_textarea_field($in[$p . '_testo'] ?? '');
			$o[$p . '_foto']  = absint($in[$p . '_foto'] ?? 0);
		}
	}
	update_option('pi_opzioni', $o, true);
	do_action('litespeed_purge_all');
	wp_safe_redirect(add_query_arg(['page' => pi_sezioni_impostazioni()[$sezione]['pagina'], 'salvato' => '1'], admin_url('admin.php')));
	exit;
}

/** Campo foto: anteprima + «Scegli una foto» + «Togli». */
function pi_campo_foto($nome, $valore, $etichetta) {
	$src = $valore ? wp_get_attachment_image_url($valore, 'medium') : '';
	?>
	<div class="pi-campo pi-foto" data-pi-foto>
		<span class="pi-etichetta"><?php echo esc_html($etichetta); ?></span>
		<img src="<?php echo esc_url($src); ?>" alt="" <?php echo $src ? '' : 'hidden'; ?>>
		<input type="hidden" name="pi[<?php echo esc_attr($nome); ?>]" value="<?php echo (int) $valore; ?>">
		<span class="pi-bottoni">
			<button type="button" class="button" data-scegli>Scegli una foto</button>
			<button type="button" class="button-link pi-togli" data-togli <?php echo $valore ? '' : 'hidden'; ?>>Togli</button>
		</span>
	</div>
	<?php
}

function pi_pagina_impostazioni($sezione) {
	if (!current_user_can('edit_pages')) {
		return;
	}
	$o = pi_opz();
	$info = pi_sezioni_impostazioni()[$sezione];
	if ($sezione === 'sito') {
		wp_enqueue_media();
	}
	?>
	<div class="wrap pi-impostazioni pi-semplice">
		<h1><?php echo esc_html($info['titolo']); ?></h1>
		<?php if (!empty($_GET['salvato'])) : ?>
			<div class="notice notice-success pi-avviso-grande"><p><strong>Salvato.</strong> Il sito è già aggiornato.</p></div>
		<?php endif; ?>
		<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
			<input type="hidden" name="action" value="pi_salva_impostazioni">
			<input type="hidden" name="sezione" value="<?php echo esc_attr($sezione); ?>">
			<?php wp_nonce_field('pi_impostazioni'); ?>

			<?php if ($sezione === 'ufficio') :
				$membri = $o['membri'] ?: [['nome' => '', 'ruolo' => '', 'email' => '', 'telefono' => '']]; ?>
				<p class="pi-aiuto">Le persone dell'amministrazione, nell'ordine in cui compaiono sul sito (pagine Chi siamo e Contatti). Email e telefono si possono lasciare vuoti.</p>
				<section class="pi-blocco">
					<div class="pi-righe" data-pi-righe="membri">
						<?php foreach ($membri as $i => $m) : ?>
							<div class="pi-riga">
								<label>Nome e cognome<input type="text" name="pi[membri][<?php echo (int) $i; ?>][nome]" value="<?php echo esc_attr($m['nome']); ?>"></label>
								<label>Carica<input type="text" name="pi[membri][<?php echo (int) $i; ?>][ruolo]" value="<?php echo esc_attr($m['ruolo']); ?>" placeholder="Presidente, Membro…"></label>
								<label>Email<input type="email" name="pi[membri][<?php echo (int) $i; ?>][email]" value="<?php echo esc_attr($m['email']); ?>"></label>
								<label>Telefono<input type="text" name="pi[membri][<?php echo (int) $i; ?>][telefono]" value="<?php echo esc_attr($m['telefono']); ?>"></label>
								<button type="button" class="button-link pi-togli" data-togli-riga>Togli</button>
							</div>
						<?php endforeach; ?>
					</div>
					<button type="button" class="button button-large" data-aggiungi-riga="membri">+ Aggiungi una persona</button>
				</section>
				<section class="pi-blocco">
					<label class="pi-campo">Frase per chi scrive al Patriziato (compare in Contatti e in fondo al sito)<textarea name="pi[contatti_nota]" rows="2"><?php echo esc_textarea($o['contatti_nota']); ?></textarea></label>
				</section>
			<?php endif; ?>

			<?php if ($sezione === 'gettoni') :
				$gettoni = $o['gettoni'] ?: [['nome' => '', 'telefono' => '']]; ?>
				<p class="pi-aiuto">Dove si comprano i gettoni per le strade forestali. Compare nella colonna a destra del sito e nella pagina Territorio.</p>
				<section class="pi-blocco">
					<label class="pi-campo">Frase sopra l'elenco<textarea name="pi[gettoni_testo]" rows="2"><?php echo esc_textarea($o['gettoni_testo']); ?></textarea></label>
					<div class="pi-righe" data-pi-righe="gettoni">
						<?php foreach ($gettoni as $i => $g) : ?>
							<div class="pi-riga">
								<label>Negozio o ristorante<input type="text" name="pi[gettoni][<?php echo (int) $i; ?>][nome]" value="<?php echo esc_attr($g['nome']); ?>"></label>
								<label>Telefono<input type="text" name="pi[gettoni][<?php echo (int) $i; ?>][telefono]" value="<?php echo esc_attr($g['telefono']); ?>"></label>
								<button type="button" class="button-link pi-togli" data-togli-riga>Togli</button>
							</div>
						<?php endforeach; ?>
					</div>
					<button type="button" class="button button-large" data-aggiungi-riga="gettoni">+ Aggiungi un punto vendita</button>
				</section>
				<section class="pi-blocco">
					<label class="pi-campo">Le strade forestali (testo della pagina Territorio)<textarea name="pi[strade_testo]" rows="4"><?php echo esc_textarea($o['strade_testo']); ?></textarea></label>
				</section>
			<?php endif; ?>

			<?php if ($sezione === 'sito') : ?>
				<p class="pi-aiuto">Testi e foto fissi del sito. Email e indirizzo del Patriziato stanno in <a href="<?php echo esc_url(admin_url('admin.php?page=ticinoweb-cms')); ?>">ticinoWEB CMS → Contatti</a>.</p>
				<section class="pi-blocco">
					<h2>Pagina iniziale</h2>
					<label class="pi-campo">Frase di benvenuto<textarea name="pi[home_intro]" rows="3"><?php echo esc_textarea($o['home_intro']); ?></textarea></label>
					<div class="pi-griglia">
						<?php pi_campo_foto('foto_oggi', $o['foto_oggi'], 'Foto grande in alto'); ?>
						<?php pi_campo_foto('storia_foto', $o['storia_foto'], 'Foto della sezione «Chi siamo»'); ?>
					</div>
				</section>
				<section class="pi-blocco">
					<h2>Territorio</h2>
					<label class="pi-campo">Introduzione<textarea name="pi[territorio_intro]" rows="3"><?php echo esc_textarea($o['territorio_intro']); ?></textarea></label>
					<div class="pi-griglia">
						<?php foreach (pi_paesi() as $k => $nome) : ?>
							<div>
								<h3><?php echo esc_html($nome); ?></h3>
								<label class="pi-campo">Testo<textarea name="pi[<?php echo esc_attr($k); ?>_testo]" rows="6"><?php echo esc_textarea($o[$k . '_testo']); ?></textarea></label>
								<?php pi_campo_foto($k . '_foto', $o[$k . '_foto'], 'Foto'); ?>
							</div>
						<?php endforeach; ?>
					</div>
				</section>
				<input type="hidden" name="pi[foto_ieri]" value="<?php echo (int) $o['foto_ieri']; ?>">
				<input type="hidden" name="pi[foto_ieri_nota]" value="<?php echo esc_attr($o['foto_ieri_nota']); ?>">
			<?php endif; ?>

			<p class="pi-salva"><button type="submit" class="button button-primary button-hero">Salva</button></p>
		</form>
	</div>
	<?php
}
