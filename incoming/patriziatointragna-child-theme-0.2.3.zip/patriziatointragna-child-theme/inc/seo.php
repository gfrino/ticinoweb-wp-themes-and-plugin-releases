<?php
/**
 * SEO del child: vecchi indirizzi → nuovi (301), registri con nomi di persone fuori da Google,
 * sitemap pulita. Title, description, canonical e JSON-LD restano del parent (tW SEO).
 */
if (!defined('ABSPATH')) {
	exit;
}

/** Vecchi indirizzi del sito Elementor che non esistono più. Percorso => destinazione. */
function pi_redirect_fissi() {
	return [
		'home'                           => '/',
		'albo'                           => '/comunicati/',
		'regolamenti'                    => '/documenti/#regolamenti',
		'catalogo-elettorale'            => '/documenti/catalogo-elettorale/',
		'catalogo/catalogo-elettorale'   => '/documenti/catalogo-elettorale/',
		'catalogo/elenco-dei-patrizi'    => '/documenti/elenco-dei-patrizi/',
		'catalogo'                       => '/documenti/',
		'galleria'                       => '/territorio/',
		'il-patriziato'                  => '/chi-siamo/',
		'category/comunicati'            => '/comunicati/',
		'category/uncategorized'         => '/comunicati/',
		'category/regolamenti'           => '/documenti/#regolamenti',
		'category/catalogo-elettorale'   => '/documenti/#registri',
		'privacy-policy'                 => '/privacy/',
	];
}

// Controllo prima che WordPress indovini l'indirizzo (altrimenti /catalogo/catalogo-elettorale/ finisce su un PDF).
add_action('template_redirect', function () {
	if (is_admin() || is_preview()) {
		return;
	}
	$path = trim((string) parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), '/');
	$home = trim((string) parse_url(home_url('/'), PHP_URL_PATH), '/');
	if ($home !== '' && strpos($path, $home) === 0) {
		$path = trim(substr($path, strlen($home)), '/');
	}
	$path = preg_replace('#/page/\d+$#', '', $path);
	$mappa = pi_redirect_fissi() + (array) get_option('pi_redirect', []); // aggiunte dalla migrazione
	if (isset($mappa[$path])) {
		wp_safe_redirect(home_url($mappa[$path]), 301, 'Patriziato');
		exit;
	}
}, 1);

/** Documento dei registri (nomi di persone): fuori da Google, come deciso con il Patriziato. */
function pi_documento_riservato($post_id) {
	return get_post_type($post_id) === 'pi_documento' && !empty(pi_raccolte()[pi_documento_raccolta($post_id)][2]);
}

add_filter('wp_robots', function ($r) {
	if (is_search() || (is_home() && (isset($_GET['tipo']) || isset($_GET['anno'])))) {
		$r['noindex'] = true;
	}
	return $r;
}, 20);

// Il parent stampa il suo meta robots dai post meta: lo allineo per i registri.
add_filter('get_post_metadata', function ($v, $id, $key) {
	if ($key === '_tw_seo_robots' && pi_documento_riservato($id)) {
		return ['noindex, nofollow'];
	}
	return $v;
}, 10, 3);

add_filter('wp_sitemaps_posts_query_args', function ($args, $type) {
	if ($type === 'pi_documento') {
		$mq = isset($args['meta_query']) ? (array) $args['meta_query'] : [];
		$mq[] = ['key' => '_pi_raccolta', 'value' => 'registri', 'compare' => '!='];
		$args['meta_query'] = $mq;
	}
	return $args;
}, 10, 2);
add_filter('wp_sitemaps_taxonomies', function ($t) {
	unset($t['category'], $t['post_tag']);
	return $t;
});
add_filter('wp_sitemaps_add_provider', function ($p, $name) {
	return $name === 'users' ? false : $p;
}, 10, 2);
