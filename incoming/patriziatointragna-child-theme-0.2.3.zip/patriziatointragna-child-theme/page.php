<?php
/** Pagina semplice (privacy, crediti, testi liberi). */
get_header();
while (have_posts()) : the_post();
	pi_testa_pagina(get_the_title(), has_excerpt() ? get_the_excerpt() : '');
	?>
	<div class="contenitore"><div class="pi-testo pi-testo--editoriale"><?php the_content(); ?></div></div>
<?php endwhile;
get_footer();
