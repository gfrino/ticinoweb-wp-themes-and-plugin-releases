<?php
/**
 * Pagina di un'assemblea: data, ora, luogo e tutti i suoi atti, in ordine.
 */
$t = get_queried_object();
if (!pi_atti_assemblea($t->term_id)) {
	wp_safe_redirect(pi_url('assemblee'), 301);
	exit;
}
get_header();
$d = pi_assemblea_data($t);
$ora = get_term_meta($t->term_id, 'pi_ora', true);
$luogo = get_term_meta($t->term_id, 'pi_luogo', true);
$futura = $d >= current_time('Y-m-d');
$titolo = ($futura ? 'Prossima assemblea' : 'Assemblea patriziale') . ' del ' . pi_data_lunga($d);
$sotto = trim(($ora ? 'Ore ' . $ora : '') . ($ora && $luogo ? ', ' : '') . $luogo);
pi_testa_pagina($titolo, $sotto, ['Assemblee', pi_url('assemblee')]);
$atti = pi_atti_assemblea($t->term_id);
?>
<div class="contenitore pi-assemblea">
	<ol class="pi-assemblea__atti" role="list">
		<?php foreach ($atti as $a) :
			$all = pi_allegati($a->ID); ?>
			<li class="pi-assemblea__atto">
				<div class="pi-assemblea__atto-testa">
					<?php echo pi_etichetta_tipo($a->ID); ?>
					<h2><a href="<?php echo esc_url(get_permalink($a)); ?>"><?php echo esc_html(pi_titolo_pulito(get_the_title($a))); ?></a></h2>
					<p class="pi-meta">Pubblicato il <?php echo esc_html(mb_strtolower(get_the_date('j F Y', $a))); ?></p>
				</div>
				<?php pi_lista_file($all); ?>
			</li>
		<?php endforeach; ?>
	</ol>
	<?php if ($futura) : ?>
		<p class="pi-nota">Verbale e risoluzioni compaiono qui dopo l'assemblea.</p>
	<?php endif; ?>
</div>
<?php get_footer(); ?>
