<?php
/**
 * Un comunicato: titolo, data, documenti da scaricare (grandi e chiari), testo, anteprima del PDF.
 */
get_header();
while (have_posts()) : the_post();
	$id = get_the_ID();
	$all = pi_allegati($id);
	$ass = wp_get_post_terms($id, 'pi_assemblea');
	$ass = (!is_wp_error($ass) && $ass) ? $ass[0] : null;
	$immagini = array_values(array_filter($all, 'wp_attachment_is_image'));
	$pdf = null;
	foreach ($all as $a) {
		if (get_post_mime_type($a) === 'application/pdf') {
			$pdf = $a;
			break;
		}
	}
	?>
	<header class="pi-testa">
		<div class="contenitore">
			<nav class="pi-briciole" aria-label="Sei qui"><a href="<?php echo esc_url(home_url('/')); ?>">Home</a><span aria-hidden="true">›</span><a href="<?php echo esc_url(pi_url_albo()); ?>">Comunicati</a></nav>
			<h1><?php echo esc_html(pi_titolo_pulito(get_the_title())); ?></h1>
			<p class="pi-testa__sotto"><?php echo pi_etichetta_tipo($id); ?> Pubblicato il <?php echo esc_html(pi_data_lunga(get_post_time('U'))); ?><?php if ($ass) : ?> · <a href="<?php echo esc_url(get_term_link($ass)); ?>">assemblea del <?php echo esc_html(pi_data_lunga(pi_assemblea_data($ass))); ?></a><?php endif; ?></p>
		</div>
	</header>
	<div class="contenitore pi-colonne">
		<article class="pi-colonne__principale pi-atto">
			<?php if ($all) : ?>
				<section class="pi-scarica" aria-label="Documenti">
					<?php pi_lista_file($all); ?>
				</section>
			<?php endif; ?>
			<?php if (trim(get_the_content()) !== '') : ?>
				<div class="pi-testo"><?php the_content(); ?></div>
			<?php endif; ?>
			<?php foreach ($immagini as $img) : ?>
				<a class="pi-atto__immagine" href="<?php echo esc_url(wp_get_attachment_url($img)); ?>" aria-label="<?php echo esc_attr('Apri l\'immagine a grandezza piena: ' . pi_titolo_pulito(get_the_title())); ?>"><?php echo pi_foto($img, 'pi-medio', ['sizes' => '(min-width: 1024px) 60vw, 100vw']); ?></a>
			<?php endforeach; ?>
			<?php if ($pdf) {
				pi_anteprima_pdf($pdf);
			} ?>
			<nav class="pi-atto__vicini" aria-label="Altri comunicati">
				<?php
				$prec = get_previous_post();
				$succ = get_next_post();
				if ($prec) {
					printf('<a class="pi-vicino" href="%s"><span>« Precedente</span>%s</a>', esc_url(get_permalink($prec)), esc_html(pi_titolo_pulito(get_the_title($prec))));
				}
				if ($succ) {
					printf('<a class="pi-vicino pi-vicino--dopo" href="%s"><span>Successivo »</span>%s</a>', esc_url(get_permalink($succ)), esc_html(pi_titolo_pulito(get_the_title($succ))));
				}
				?>
			</nav>
		</article>
		<?php get_template_part('template-parts/laterale'); ?>
	</div>
<?php endwhile;
get_footer();
