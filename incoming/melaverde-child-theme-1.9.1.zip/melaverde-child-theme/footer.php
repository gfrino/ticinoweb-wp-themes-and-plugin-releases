<?php
/**
 * Mela Verde – chiusura della pagina.
 *
 * Sostituisce footer.php del parent: Mela Verde ha il suo piè di pagina (inc/footer.php,
 * stampato da front-page.php e page.php), quindi il <footer class="site-footer" id="contatti">
 * del parent qui non serve. Prima veniva stampato e poi nascosto con il CSS: era un doppione
 * di contatti nel codice e creava due elementi con id="contatti" sulla home.
 *
 * Resta tutto il resto: wp_footer() (banner cookie, script del parent e dei plugin) e le
 * chiusure del documento.
 *
 * @package melaverde-child-theme
 */
?>
<?php wp_footer(); ?>
</body>
</html>
