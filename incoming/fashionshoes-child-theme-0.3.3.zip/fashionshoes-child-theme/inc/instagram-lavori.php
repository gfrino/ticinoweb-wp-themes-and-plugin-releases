<?php
/**
 * Foto da Instagram: la galleria scelta in Personalizza → Fashion Shoes → Instagram resta con le 6 foto più recenti del
 * profilo Instagram. Ogni ora si chiedono a Instagram gli ultimi post, si scaricano nella Libreria media solo quelli
 * nuovi e si tolgono dalla galleria (e dalla Libreria) le foto sincronizzate uscite dalle 6. Le foto caricate a mano
 * restano nella Libreria e in coda alla galleria.
 *
 * Il collegamento con Instagram (account, chiave d'accesso, rinnovo) lo tiene il plugin Smash Balloon Instagram Feed,
 * già presente sulla rete: qui si usa il suo account collegato, non si salva nessuna chiave. Se il plugin manca,
 * l'account non è collegato o Instagram non risponde, non si tocca niente: il sito non resta mai senza foto.
 * Nella pagina non parte nessuna richiesta verso Instagram: le foto sono servite dal sito.
 *
 * @package fashionshoes-child-theme
 */

defined('ABSPATH') || exit;

const FASHIONSHOES_IG_QUANTE = 6;
const FASHIONSHOES_IG_EVENTO = 'fashionshoes_instagram_lavori';
const FASHIONSHOES_IG_META   = '_fs_instagram_id';

/** La sincronizzazione è accesa? (casella nel Personalizza e galleria scelta) */
function fashionshoes_ig_attiva()
{
    return (bool) fashionshoes_setting('instagram_sync', false) && (string) fashionshoes_setting('instagram_gallery', '') !== '';
}

/** Pianifica (o toglie) il controllo orario, in base all'impostazione. */
add_action('init', function () {
    $pianificato = wp_next_scheduled(FASHIONSHOES_IG_EVENTO);
    if (fashionshoes_ig_attiva() && !$pianificato) {
        wp_schedule_event(time() + 60, 'hourly', FASHIONSHOES_IG_EVENTO);
    } elseif (!fashionshoes_ig_attiva() && $pianificato) {
        wp_clear_scheduled_hook(FASHIONSHOES_IG_EVENTO);
    }
});
add_action(FASHIONSHOES_IG_EVENTO, 'fashionshoes_ig_sincronizza');
add_action('switch_theme', function () {
    wp_clear_scheduled_hook(FASHIONSHOES_IG_EVENTO);
});
// Appena si accende la casella nel Personalizza, il primo aggiornamento parte subito.
add_action('customize_save_after', function () {
    if (fashionshoes_ig_attiva()) {
        wp_schedule_single_event(time(), FASHIONSHOES_IG_EVENTO);
    }
});

/**
 * Gli ultimi post del profilo, dal più recente: [ ['id', 'url' (foto), 'link', 'testo'] … ], solo immagini.
 * Album: la prima foto. Video: la copertina. Restituisce WP_Error se non si possono leggere.
 */
function fashionshoes_ig_post_recenti()
{
    // Per le prove: un filtro può fornire i post senza chiamare Instagram.
    $finti = apply_filters('fashionshoes_ig_post_prova', null);
    if (is_array($finti)) {
        return $finti;
    }
    if (!class_exists('SB_Instagram_Connected_Account') || !class_exists('SB_Instagram_API_Connect')) {
        return new WP_Error('fs_ig_plugin', __('Il plugin Instagram Feed (Smash Balloon) non è attivo.', 'fashionshoes-child-theme'));
    }
    $account  = null;
    $profilo  = strtolower(trim((string) wp_parse_url((string) get_option('ticinoweb_contact_instagram', ''), PHP_URL_PATH), '/'));
    $accounts = (array) SB_Instagram_Connected_Account::get_all_connected_accounts();
    foreach ($accounts as $a) {
        if (is_array($a) && ($profilo === '' || strtolower((string) ($a['username'] ?? '')) === $profilo)) {
            $account = $a;
            break;
        }
    }
    if (!$account) {
        return new WP_Error('fs_ig_account', __('Nessun account Instagram collegato in Instagram Feed (o non è quello indicato in ticinoWEB CMS → Contatti).', 'fashionshoes-child-theme'));
    }
    $api = new SB_Instagram_API_Connect($account, 'user', array('num' => 25));
    $api->connect();
    if ($api->is_wp_error() || $api->is_instagram_error()) {
        return new WP_Error('fs_ig_api', __('Instagram non ha risposto o la chiave d’accesso è scaduta: va ricollegato l’account in Instagram Feed.', 'fashionshoes-child-theme'));
    }
    $post = array();
    foreach ((array) $api->get_data() as $p) {
        $tipo = (string) ($p['media_type'] ?? '');
        $url  = '';
        if ($tipo === 'IMAGE') {
            $url = (string) ($p['media_url'] ?? '');
        } elseif ($tipo === 'CAROUSEL_ALBUM') {
            foreach ((array) ($p['children']['data'] ?? array()) as $figlio) {
                if (($figlio['media_type'] ?? '') === 'IMAGE' && !empty($figlio['media_url'])) {
                    $url = (string) $figlio['media_url'];
                    break;
                }
            }
            $url = $url !== '' ? $url : (string) ($p['media_url'] ?? '');
        } elseif ($tipo === 'VIDEO') {
            $url = (string) ($p['thumbnail_url'] ?? '');
        }
        if ($url !== '' && !empty($p['id'])) {
            $post[] = array('id' => (string) $p['id'], 'url' => $url, 'link' => (string) ($p['permalink'] ?? ''), 'testo' => (string) ($p['caption'] ?? ''));
        }
    }
    return $post;
}

/** Scarica una foto in un file temporaneo (filtrabile per le prove). */
function fashionshoes_ig_scarica($url)
{
    $file = apply_filters('fashionshoes_ig_scarica_prova', null, $url);
    if (is_string($file)) {
        return $file;
    }
    if (!function_exists('download_url')) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
    }
    return download_url($url, 30);
}

/** Il testo alternativo: la prima frase della didascalia di Instagram, senza hashtag. */
function fashionshoes_ig_alt($testo)
{
    $t = trim((string) preg_replace('/[#@][\p{L}\p{N}_.]+/u', '', wp_strip_all_tags((string) $testo)));
    $t = trim((string) preg_split('/(?<=[.!?])\s|\R/u', $t)[0]);
    if ($t === '') {
        /* translators: %s: nome del sito */
        $t = sprintf(__('Lavoro di %s', 'fashionshoes-child-theme'), get_bloginfo('name'));
    }
    return wp_html_excerpt($t, 140, '…');
}

/** Il controllo: tiene la galleria allineata alle 6 foto più recenti. */
function fashionshoes_ig_sincronizza()
{
    $stato = array('quando' => time(), 'nuove' => 0, 'tolte' => 0, 'errore' => '');
    $slug  = sanitize_title((string) fashionshoes_setting('instagram_gallery', ''));
    $term  = $slug !== '' && taxonomy_exists('ticinoweb_media_gallery') ? get_term_by('slug', $slug, 'ticinoweb_media_gallery') : false;
    $post  = fashionshoes_ig_attiva() && $term ? fashionshoes_ig_post_recenti() : new WP_Error('fs_ig_spenta', __('Sincronizzazione spenta o galleria non scelta.', 'fashionshoes-child-theme'));

    if (is_wp_error($post) || !$post) {
        $stato['errore'] = is_wp_error($post) ? $post->get_error_message() : __('Instagram non ha restituito foto.', 'fashionshoes-child-theme');
        update_option('fashionshoes_ig_stato', $stato, false);
        return $stato;
    }
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';

    $tenere = array();
    foreach (array_slice($post, 0, FASHIONSHOES_IG_QUANTE) as $p) {
        $gia = get_posts(array('post_type' => 'attachment', 'post_status' => 'inherit', 'numberposts' => 1, 'fields' => 'ids', 'meta_key' => FASHIONSHOES_IG_META, 'meta_value' => $p['id']));
        if ($gia) {
            $tenere[] = (int) $gia[0];
            continue;
        }
        $tmp = fashionshoes_ig_scarica($p['url']);
        if (is_wp_error($tmp)) {
            continue; // questa foto riprova al prossimo giro
        }
        $id = media_handle_sideload(array('name' => 'instagram-' . sanitize_file_name($p['id']) . '.jpg', 'tmp_name' => $tmp), 0, fashionshoes_ig_alt($p['testo']));
        if (is_wp_error($id)) {
            @unlink($tmp); // phpcs:ignore WordPress.PHP.NoSilencedErrors
            continue;
        }
        update_post_meta($id, FASHIONSHOES_IG_META, $p['id']);
        update_post_meta($id, '_fs_instagram_link', esc_url_raw($p['link']));
        update_post_meta($id, '_wp_attachment_image_alt', fashionshoes_ig_alt($p['testo']));
        $tenere[] = (int) $id;
        $stato['nuove']++;
    }
    if (!$tenere) {
        $stato['errore'] = __('Nessuna foto scaricata da Instagram.', 'fashionshoes-child-theme');
        update_option('fashionshoes_ig_stato', $stato, false);
        return $stato;
    }

    // Galleria: prima le 6 di Instagram (dalla più recente), poi eventuali foto caricate a mano.
    $attuali = fashionshoes_gallery_images($slug, 500);
    foreach ($tenere as $id) {
        wp_set_object_terms($id, (int) $term->term_id, 'ticinoweb_media_gallery', true);
    }
    $altre = array();
    foreach ($attuali as $id) {
        if (in_array($id, $tenere, true)) {
            continue;
        }
        if (get_post_meta($id, FASHIONSHOES_IG_META, true) !== '') {
            // Foto sincronizzata uscita dalle 6: via dalla galleria e dalla Libreria (l'aveva caricata la sincronizzazione).
            wp_delete_attachment($id, true);
            $stato['tolte']++;
        } else {
            $altre[] = $id;
        }
    }
    update_term_meta((int) $term->term_id, '_ticinoweb_gallery_order', array_merge($tenere, $altre));
    update_option('fashionshoes_ig_stato', $stato, false);
    return $stato;
}

/** Una riga sullo stato, per il Personalizza. */
function fashionshoes_ig_stato_testo()
{
    $s = get_option('fashionshoes_ig_stato');
    if (!is_array($s) || empty($s['quando'])) {
        return __('Non ancora aggiornata.', 'fashionshoes-child-theme');
    }
    $quando = wp_date(get_option('date_format') . ' ' . get_option('time_format'), (int) $s['quando']);
    if (!empty($s['errore'])) {
        /* translators: 1: data, 2: messaggio d'errore */
        return sprintf(__('Ultimo controllo %1$s: %2$s', 'fashionshoes-child-theme'), $quando, $s['errore']);
    }
    /* translators: 1: data, 2: foto nuove, 3: foto tolte */
    return sprintf(__('Ultimo controllo %1$s: %2$d foto nuove, %3$d tolte.', 'fashionshoes-child-theme'), $quando, (int) $s['nuove'], (int) $s['tolte']);
}
