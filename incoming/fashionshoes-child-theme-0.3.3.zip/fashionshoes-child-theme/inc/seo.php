<?php
/**
 * SEO e ricerche AI, sopra il parent (niente schema doppio):
 * - i dati strutturati Organization/LocalBusiness del parent diventano «ShoeStore» con indirizzo, telefono, email,
 *   orari e social presi da ticinoWEB CMS → Contatti (si attiva scegliendo «Attività Locale» in tW SEO);
 * - /llms.txt del sottosito: una scheda in testo semplice per gli assistenti AI, generata dagli stessi dati.
 *
 * @package fashionshoes-child-theme
 */

defined('ABSPATH') || exit;

/** «Via Esempio 1, 6600 Località» → parti dell'indirizzo per PostalAddress. */
function fashionshoes_postal_address()
{
    $line = fashionshoes_address_line();
    if ($line === '') {
        return array();
    }
    $address = array('@type' => 'PostalAddress', 'streetAddress' => $line, 'addressCountry' => 'CH');
    if (preg_match('/^(.*?),\s*(\d{4})\s+(.+)$/u', $line, $m)) {
        $address['streetAddress']   = trim($m[1]);
        $address['postalCode']      = $m[2];
        $address['addressLocality'] = trim($m[3]);
    }
    return $address;
}

/** Orari del CMS nel formato di schema.org (OpeningHoursSpecification). */
function fashionshoes_opening_spec()
{
    $hours = get_option('ticinoweb_contact_opening_hours', array());
    $days  = array('monday' => 'Monday', 'tuesday' => 'Tuesday', 'wednesday' => 'Wednesday', 'thursday' => 'Thursday', 'friday' => 'Friday', 'saturday' => 'Saturday', 'sunday' => 'Sunday');
    $out   = array();
    foreach ($days as $key => $day) {
        $d = isset($hours[$key]) && is_array($hours[$key]) ? $hours[$key] : array();
        if (!$d || !empty($d['closed'])) {
            continue;
        }
        if (!empty($d['open_24h'])) {
            $out[] = array('@type' => 'OpeningHoursSpecification', 'dayOfWeek' => $day, 'opens' => '00:00', 'closes' => '23:59');
            continue;
        }
        foreach ((array) ($d['slots'] ?? array()) as $slot) {
            if (!empty($slot['open']) && !empty($slot['close'])) {
                $out[] = array('@type' => 'OpeningHoursSpecification', 'dayOfWeek' => $day, 'opens' => $slot['open'], 'closes' => $slot['close']);
            }
        }
    }
    return $out;
}

add_filter('ticinoweb_seo_jsonld_org_schema', function ($schema) {
    if (!is_array($schema) || ($schema['@type'] ?? '') !== 'LocalBusiness') {
        return $schema;
    }
    $c = fashionshoes_contacts();
    $schema['@type'] = 'ShoeStore';
    $address = fashionshoes_postal_address();
    if ($address) {
        $schema['address'] = $address;
    }
    if ($c['phone'] !== '' && empty($schema['telephone'])) {
        $schema['telephone'] = $c['phone'];
    }
    if ($c['email'] !== '') {
        $schema['email'] = $c['email'];
    }
    $spec = fashionshoes_opening_spec();
    if ($spec) {
        $schema['openingHoursSpecification'] = $spec;
    }
    $hero = fashionshoes_image_id(fashionshoes_setting('hero_image', 0));
    if ($hero) {
        $schema['image'] = wp_get_attachment_image_url($hero, 'large');
    }
    $map = fashionshoes_map_url();
    if ($map !== '') {
        $schema['hasMap'] = $map;
    }
    if (empty($schema['sameAs'])) {
        $same = array_values(fashionshoes_socials());
        if ($same) {
            $schema['sameAs'] = $same;
        }
    }
    return $schema;
});

/** /llms.txt del sottosito: testo semplice con chi siete, dove, orari, collezioni e contatti. */
add_action('template_redirect', function () {
    if (!is_404()) {
        return;
    }
    $path = (string) wp_parse_url(home_url('/'), PHP_URL_PATH);
    $req  = (string) wp_parse_url(isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '', PHP_URL_PATH); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
    if (untrailingslashit($req) !== rtrim($path, '/') . '/llms.txt') {
        return;
    }
    $c     = fashionshoes_contacts();
    $lines = array('# ' . get_bloginfo('name'), '');
    $desc  = trim((string) get_option('tw_seo_home_description', get_bloginfo('description')));
    if ($desc !== '') {
        $lines[] = '> ' . $desc;
        $lines[] = '';
    }
    if (fashionshoes_text('hero_text') !== '') {
        $lines[] = fashionshoes_text('hero_text');
        $lines[] = '';
    }
    $lines[] = '## Contatti';
    foreach (array(fashionshoes_address_line(), $c['phone_display'], $c['email']) as $v) {
        if ($v !== '') {
            $lines[] = '- ' . $v;
        }
    }
    $lines[] = '- Sito: ' . home_url('/');
    $hours = fashionshoes_hours();
    if ($hours) {
        $lines[] = '';
        $lines[] = '## ' . (fashionshoes_text('hours_title') !== '' ? fashionshoes_text('hours_title') : 'Orari');
        foreach ($hours as $h) {
            $lines[] = '- ' . $h['giorni'] . ': ' . $h['ore'];
        }
    }
    $note = fashionshoes_hours_note();
    if ($note) {
        $lines[] = '';
        $lines[] = '## ' . (fashionshoes_text('hours_note_title') !== '' ? fashionshoes_text('hours_note_title') : 'Altri orari');
        foreach ($note as $n) {
            $lines[] = '- ' . $n['giorni'] . ($n['ore'] !== '' ? ': ' . $n['ore'] : '');
        }
    }
    $services = fashionshoes_services();
    if ($services) {
        $lines[] = '';
        $lines[] = '## Collezioni';
        foreach ($services as $s) {
            $lines[] = '- ' . $s['title'] . (!empty($s['description']) ? ': ' . wp_strip_all_tags($s['description']) : '');
        }
    }
    $about = trim((string) get_option('ticinoweb_chi_siamo_text', ''));
    if ($about !== '') {
        $lines[] = '';
        $lines[] = '## Il negozio';
        $lines[] = wp_strip_all_tags($about);
    }
    status_header(200);
    header('Content-Type: text/plain; charset=utf-8');
    header('X-Robots-Tag: noindex');
    echo implode("\n", $lines) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput -- testo semplice
    exit;
});
