<?php
/**
 * Piè di pagina: logo, indirizzo e contatti dal CMS, social, riga legale (anno, privacy, cookie, ticinoWEB).
 * Sulla pagina iniziale anche il visore delle foto (si apre dal negozio e dalle foto caricate a mano).
 *
 * @package fashionshoes-child-theme
 */

defined('ABSPATH') || exit;

$fs_contacts = fashionshoes_contacts();
$fs_name     = get_bloginfo('name');
$fs_address  = fashionshoes_address_line();
$fs_privacy  = fashionshoes_privacy_url();
$fs_networks = array('instagram' => 'Instagram', 'facebook' => 'Facebook', 'linkedin' => 'LinkedIn', 'youtube' => 'YouTube', 'tiktok' => 'TikTok');
$fs_socials  = fashionshoes_socials();
$fs_legal    = trim((string) get_option('tw_seo_org_name', ''));
$fs_legal    = $fs_legal !== '' ? $fs_legal : $fs_name;
?>
<footer class="fs-pie">
    <div class="fs-contenitore">
        <div class="fs-pie__in">
            <div class="fs-pie__marca">
                <a class="fs-pie__logo" href="<?php echo esc_url(fashionshoes_url(home_url('/'), 'url:home')); ?>">
                    <img src="<?php echo esc_url(FASHIONSHOES_URI . '/assets/img/logo-beige.svg'); ?>" alt="<?php echo esc_attr($fs_name); ?>" width="2768" height="385" loading="lazy" decoding="async">
                </a>
            </div>
            <div>
                <h2><?php esc_html_e('Negozio', 'fashionshoes-child-theme'); ?></h2>
                <ul>
                    <?php if ($fs_address !== '') : ?><li><span><?php echo fashionshoes_icona('posizione'); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo esc_html($fs_address); ?></span></li><?php endif; ?>
                    <?php if ($fs_contacts['phone'] !== '') : ?><li><a href="<?php echo esc_attr(fashionshoes_tel($fs_contacts['phone'])); ?>"><?php echo fashionshoes_icona('telefono'); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo esc_html($fs_contacts['phone_display']); ?></a></li><?php endif; ?>
                    <?php // Niente antispambot(): cambia a ogni visita e tW Translate lascerebbe la pagina «in attesa» (noindex). ?>
                    <?php if ($fs_contacts['email'] !== '') : ?><li><a href="<?php echo esc_attr('mailto:' . $fs_contacts['email']); ?>"><?php echo fashionshoes_icona('email'); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo esc_html($fs_contacts['email']); ?></a></li><?php endif; ?>
                </ul>
            </div>
            <?php if ($fs_socials) : ?>
                <div>
                    <h2><?php esc_html_e('Seguici', 'fashionshoes-child-theme'); ?></h2>
                    <ul>
                        <?php foreach ($fs_networks as $fs_network => $fs_label) : ?>
                            <?php if (!empty($fs_socials[$fs_network])) : ?><li><a href="<?php echo esc_url($fs_socials[$fs_network]); ?>" target="_blank" rel="noopener"><?php echo fashionshoes_icona($fs_network); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo esc_html($fs_label); ?></a></li><?php endif; ?>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
        <div class="fs-pie__legale">
            <span>© <?php echo esc_html(wp_date('Y')); ?> <?php echo esc_html($fs_legal); ?></span>
            <?php if ($fs_privacy !== '') : ?><a href="<?php echo esc_url(fashionshoes_url($fs_privacy, 'url:privacy')); ?>"><?php esc_html_e('Privacy', 'fashionshoes-child-theme'); ?></a><?php endif; ?>
            <?php if (get_option('tw_cookie_banner_enable')) : ?><button type="button" data-fs-cookies><?php esc_html_e('Impostazioni cookie', 'fashionshoes-child-theme'); ?></button><?php endif; ?>
            <a href="https://ticinoweb.com" target="_blank" rel="noopener"><?php esc_html_e('Sito di ticinoWEB', 'fashionshoes-child-theme'); ?></a>
        </div>
    </div>
</footer>
<?php if (is_front_page()) : ?>
<dialog class="fs-visore" aria-label="<?php echo esc_attr(fashionshoes_t(__('Foto ingrandita', 'fashionshoes-child-theme'), 'ui:viewer')); ?>">
    <figure><figcaption></figcaption></figure>
    <button class="fs-visore__btn fs-visore__chiudi" type="button" aria-label="<?php echo esc_attr(fashionshoes_t(__('Chiudi', 'fashionshoes-child-theme'), 'ui:close')); ?>"><?php echo fashionshoes_icona('chiudi'); // phpcs:ignore WordPress.Security.EscapeOutput ?></button>
    <button class="fs-visore__btn fs-visore__prec" type="button" aria-label="<?php echo esc_attr(fashionshoes_t(__('Foto precedente', 'fashionshoes-child-theme'), 'ui:prev')); ?>"><?php echo fashionshoes_icona('freccia'); // phpcs:ignore WordPress.Security.EscapeOutput ?></button>
    <button class="fs-visore__btn fs-visore__succ" type="button" aria-label="<?php echo esc_attr(fashionshoes_t(__('Foto successiva', 'fashionshoes-child-theme'), 'ui:next')); ?>"><?php echo fashionshoes_icona('freccia'); // phpcs:ignore WordPress.Security.EscapeOutput ?></button>
</dialog>
<?php endif; ?>
<?php wp_footer(); ?>
</body>
</html>
