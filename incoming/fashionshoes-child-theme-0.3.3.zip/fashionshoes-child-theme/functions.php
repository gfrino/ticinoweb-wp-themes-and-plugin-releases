<?php
/**
 * Fashion Shoes Locarno: child di ticinoWEB CMS (ticinoweb-ai-theme), senza Elementor.
 * Pagina iniziale 0.3 «Insegna rosa antico» (23.11.2026), costruita contro i segni dei siti generati dall'AI (tools/fashionshoes/ANTI-SLOP.md).
 * Contatti, orari, logo, collezioni (Servizi), «Chi siamo», gallerie, FAQ, SEO, cookie e modulo (Invii Ricevuti,
 * reCAPTCHA, SMTP) restano nel parent; i pochi testi della home stanno in Aspetto → Personalizza → Fashion Shoes.
 *
 * @package fashionshoes-child-theme
 */

defined('ABSPATH') || exit;

define('FASHIONSHOES_VERSION', wp_get_theme(get_stylesheet())->get('Version'));
define('FASHIONSHOES_DIR', get_stylesheet_directory());
define('FASHIONSHOES_URI', get_stylesheet_directory_uri());

require_once FASHIONSHOES_DIR . '/inc/helpers.php';
require_once FASHIONSHOES_DIR . '/inc/settings.php';
require_once FASHIONSHOES_DIR . '/inc/instagram-lavori.php'; // galleria Instagram allineata alle 6 foto più recenti
require_once FASHIONSHOES_DIR . '/inc/seo.php';             // ShoeStore nei dati strutturati, llms.txt
require_once FASHIONSHOES_DIR . '/inc/icone.php';           // icone su misura (assets/icons, wp-themes/tools/icone)
if (is_admin()) {
    require_once FASHIONSHOES_DIR . '/inc/content-transfer.php';
}

add_action('after_setup_theme', function () {
    load_child_theme_textdomain('fashionshoes-child-theme', FASHIONSHOES_DIR . '/languages');
}, 20);

/**
 * Stili e script. Il parent accoda già lo style.css del child («ticinoweb-ai-style») con la versione del
 * parent: qui si aggiunge il suo style.css come dipendenza e si versiona tutto con la versione del child
 * (ogni rilascio svuota la cache del browser). I caratteri sono nel tema: Poppins di Google non si scarica.
 */
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('fashionshoes-parent', get_template_directory_uri() . '/style.css', array(), wp_get_theme(get_template())->get('Version'));
    if (isset(wp_styles()->registered['ticinoweb-ai-style'])) {
        wp_styles()->registered['ticinoweb-ai-style']->deps[] = 'fashionshoes-parent';
        wp_styles()->registered['ticinoweb-ai-style']->ver    = FASHIONSHOES_VERSION . '.' . (int) @filemtime(FASHIONSHOES_DIR . '/style.css');
    }
    // Handle vuoto al posto del carattere di Google: la dipendenza del parent resta valida, non si stampa nulla.
    wp_deregister_style('poppins-font');
    wp_register_style('poppins-font', false, array(), null);

    // Le pagine sono HTML del tema, non blocchi: gli stili dei blocchi pesano ~28 KB su ogni pagina.
    wp_dequeue_style('wp-block-library');
    wp_dequeue_style('classic-theme-styles');
    wp_dequeue_style('global-styles');

    // Movimento: Lenis ovunque, GSAP + ScrollTrigger; tutto nel tema, niente CDN. Con «riduci movimento» lo script non fa nulla.
    $fs_lib = FASHIONSHOES_URI . '/assets/vendor/';
    wp_enqueue_script('fashionshoes-lenis', $fs_lib . 'lenis.min.js', array(), '1.3', array('in_footer' => true, 'strategy' => 'defer'));
    wp_enqueue_script('fashionshoes-gsap', $fs_lib . 'gsap.min.js', array(), '3', array('in_footer' => true, 'strategy' => 'defer'));
    wp_enqueue_script('fashionshoes-scrolltrigger', $fs_lib . 'ScrollTrigger.min.js', array('fashionshoes-gsap'), '3', array('in_footer' => true, 'strategy' => 'defer'));
    wp_enqueue_script('fashionshoes-movimento', FASHIONSHOES_URI . '/assets/js/movimento.js', array('fashionshoes-lenis', 'fashionshoes-scrolltrigger'), FASHIONSHOES_VERSION . '.' . (int) @filemtime(FASHIONSHOES_DIR . '/assets/js/movimento.js'), array('in_footer' => true, 'strategy' => 'defer'));

    wp_enqueue_script('fashionshoes-site', FASHIONSHOES_URI . '/assets/js/site.js', array(), FASHIONSHOES_VERSION . '.' . (int) @filemtime(FASHIONSHOES_DIR . '/assets/js/site.js'), array('in_footer' => true, 'strategy' => 'defer'));
    wp_enqueue_script('fashionshoes-impronte', FASHIONSHOES_URI . '/assets/js/impronte.js', array(), FASHIONSHOES_VERSION . '.' . (int) @filemtime(FASHIONSHOES_DIR . '/assets/js/impronte.js'), array('in_footer' => true, 'strategy' => 'defer'));
    wp_localize_script('fashionshoes-site', 'fashionShoes', array(
        'ajaxUrl'      => admin_url('admin-ajax.php'),
        'recaptchaKey' => (string) get_option('ticinoweb_recaptcha_site_key', ''),
        'subject'      => fashionshoes_t(__('Messaggio dal sito', 'fashionshoes-child-theme'), 'form:subject'),
        'sending'      => fashionshoes_t(__('Invio in corso…', 'fashionshoes-child-theme'), 'form:sending'),
        'sent'         => fashionshoes_t(__('Grazie, abbiamo ricevuto il messaggio. Ti rispondiamo al più presto.', 'fashionshoes-child-theme'), 'form:sent'),
        'failed'       => fashionshoes_t(__('Il messaggio non è partito. Riprova tra poco oppure chiamaci.', 'fashionshoes-child-theme'), 'form:failed'),
        'offline'      => fashionshoes_t(__('Sembra che la connessione sia assente. Controlla la rete e riprova.', 'fashionshoes-child-theme'), 'form:offline'),
        'consent'      => fashionshoes_t(__('Per inviare il messaggio serve il consenso all’informativa sulla privacy.', 'fashionshoes-child-theme'), 'form:consent'),
        'menuOpen'     => fashionshoes_t(__('Apri il menu', 'fashionshoes-child-theme'), 'ui:menu_open'),
        'menuClose'    => fashionshoes_t(__('Chiudi il menu', 'fashionshoes-child-theme'), 'ui:menu_close'),
    ));
}, 20);

/** I tre caratteri del primo schermo (insegna, titoli, testo) si precaricano. */
add_action('wp_head', function () {
    foreach (array('cormorant', 'hanken-grotesk') as $font) {
        printf('<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url(FASHIONSHOES_URI . '/assets/fonts/' . $font . '.woff2'));
    }
    echo '<meta name="theme-color" content="#c99a96">' . "\n";
}, 1);

/**
 * Prima del primo disegno si decide il movimento: html.fs-moto solo sulla pagina iniziale e solo senza «riduci movimento».
 * Se le librerie non partono entro 3 secondi la classe si toglie e la pagina resta tutta visibile.
 */
add_action('wp_head', function () {
    if (!is_front_page()) {
        return;
    }
    echo "<script>(function(){var d=document.documentElement;try{if(window.matchMedia('(prefers-reduced-motion: reduce)').matches)return;d.classList.add('fs-moto');setTimeout(function(){if(!window.fsIntroPartita)d.classList.remove('fs-moto')},3000)}catch(e){d.classList.remove('fs-moto')}})();</script>\n";
}, 2);

/**
 * Il parent apre due preconnect verso Google Fonts su ogni pagina (closure su wp_head 0): si tolgono,
 * perché nessun carattere arriva da Google e l'IP del visitatore non deve uscire prima del consenso.
 */
add_action('wp_head', function () {
    global $wp_filter;
    if (empty($wp_filter['wp_head']) || empty($wp_filter['wp_head']->callbacks[0])) {
        return;
    }
    $parent_functions = wp_normalize_path(get_template_directory() . '/functions.php');
    foreach ($wp_filter['wp_head']->callbacks[0] as $callback) {
        if (!($callback['function'] instanceof Closure)) {
            continue;
        }
        $ref = new ReflectionFunction($callback['function']);
        if (wp_normalize_path((string) $ref->getFileName()) !== $parent_functions) {
            continue;
        }
        $lines = file($parent_functions);
        $body  = implode('', array_slice((array) $lines, $ref->getStartLine() - 1, $ref->getEndLine() - $ref->getStartLine() + 1));
        if (strpos($body, 'fonts.googleapis.com') !== false) {
            remove_action('wp_head', $callback['function'], 0);
        }
    }
}, -100);

/** Emoji di WordPress: scaricherebbero immagini da s.w.org prima del consenso ai cookie. */
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');
add_filter('emoji_svg_url', '__return_false');

/** WordPress mette sizes="auto" sulle immagini lazy e le pianta a 1500px finché il CSS non arriva: si spegne. */
add_filter('wp_img_tag_add_auto_sizes', '__return_false');

/** Classe del body del tema. */
add_filter('body_class', function ($classes) {
    $classes[] = 'fs-site';
    return $classes;
});

/** Il modulo della home usa il gestore del parent: senza oggetto, gli si dà «Messaggio dal sito». */
add_filter('ticinoweb_form_fields', function ($fields, $post) {
    if (!empty($post['fs_form']) && isset($fields['oggetto']) && $fields['oggetto'] === '') {
        $fields['oggetto'] = __('Messaggio dal sito', 'fashionshoes-child-theme');
    }
    return $fields;
}, 10, 2);

/**
 * Un'impostazione che manca la dice la bacheca, invece di lasciare la pagina vuota senza spiegazioni:
 * email del modulo, SMTP, reCAPTCHA, pagina privacy.
 */
add_action('admin_notices', function () {
    if (!current_user_can('manage_options')) {
        return;
    }
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if ($screen && !in_array($screen->id, array('dashboard', 'themes', 'toplevel_page_ticinoweb-settings'), true)) {
        return;
    }
    $missing = array();
    if (!get_option('ticinoweb_contact_email')) {
        $missing[] = __('l’email di contatto (ticinoWEB CMS → Contatti): senza, i messaggi arrivano all’email dell’amministratore', 'fashionshoes-child-theme');
    }
    if (!get_option('ticinoweb_smtp_host') && !get_option('ticinoweb_sendgrid_api_key')) {
        $missing[] = __('l’invio email (ticinoWEB CMS → SMTP): dai nostri server la posta senza SMTP non arriva', 'fashionshoes-child-theme');
    }
    if (!get_option('ticinoweb_recaptcha_site_key')) {
        $missing[] = __('le chiavi reCAPTCHA (ticinoWEB CMS): senza, il modulo riceve molto spam', 'fashionshoes-child-theme');
    }
    if (fashionshoes_privacy_url() === '') {
        $missing[] = __('la pagina Privacy (tW SEO → Cookie e privacy)', 'fashionshoes-child-theme');
    }
    if (!$missing) {
        return;
    }
    echo '<div class="notice notice-warning"><p><strong>' . esc_html__('Tema Fashion Shoes: da completare', 'fashionshoes-child-theme') . '</strong></p><ul style="list-style:disc;padding-left:20px">';
    foreach ($missing as $item) {
        echo '<li>' . esc_html($item) . '</li>';
    }
    echo '</ul></div>';
});
