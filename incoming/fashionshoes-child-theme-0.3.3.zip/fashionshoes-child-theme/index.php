<?php
/**
 * Ripiego per ogni vista senza un template proprio (articoli, archivi, ricerca, 404): titolo e testo,
 * oppure il messaggio che la pagina non c'è con il ritorno alla pagina iniziale.
 *
 * @package fashionshoes-child-theme
 */

defined('ABSPATH') || exit;

get_header();
?>
<main id="fs-main" class="fs-pagina">
    <div class="fs-contenitore">
        <div class="fs-pagina__corpo">
            <?php if (have_posts() && !is_404()) : ?>
                <?php while (have_posts()) : the_post(); ?>
                    <article>
                        <h1><?php the_title(); ?></h1>
                        <div class="fs-prosa"><?php the_content(); ?></div>
                    </article>
                <?php endwhile; ?>
            <?php else : ?>
                <h1><?php esc_html_e('Pagina non trovata', 'fashionshoes-child-theme'); ?></h1>
                <div class="fs-prosa">
                    <p><?php esc_html_e('L’indirizzo non porta a nessuna pagina del sito: forse è cambiato.', 'fashionshoes-child-theme'); ?></p>
                    <p><a class="fs-link" href="<?php echo esc_url(fashionshoes_url(home_url('/'), 'url:home')); ?>"><?php esc_html_e('Vai alla pagina iniziale', 'fashionshoes-child-theme'); ?></a></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</main>
<?php
get_footer();
