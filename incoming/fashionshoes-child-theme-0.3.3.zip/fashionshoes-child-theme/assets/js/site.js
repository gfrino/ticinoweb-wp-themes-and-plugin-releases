/**
 * Fashion Shoes: menu sotto i 1024 px, visore delle foto, preferenze dei cookie, modulo «Scrivici».
 * Testi e indirizzi arrivano da functions.php (window.fashionShoes). Nessuna libreria, nessun movimento allo scroll.
 */
(function () {
  'use strict';
  var cfg = window.fashionShoes || {};

  /* ---------- Menu sotto i 1024 px: pannello sotto la barra, si chiude con una voce, con Esc o allargando ---------- */
  var menuBtn = document.querySelector('.fs-testata__menu');
  var menu = document.getElementById('fs-menu');
  function setMenu(open) {
    if (!menuBtn || !menu) return;
    menu.classList.toggle('aperto', open);
    document.documentElement.classList.toggle('fs-menu-aperto', open); // il logo grande della testata non deve stare sopra il menu aperto
    menuBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
    menuBtn.setAttribute('aria-label', open ? (cfg.menuClose || 'Chiudi il menu') : (cfg.menuOpen || 'Apri il menu'));
  }
  if (menuBtn && menu) {
    menuBtn.addEventListener('click', function () { setMenu(!menu.classList.contains('aperto')); });
    menu.addEventListener('click', function (e) { if (e.target.closest('a')) setMenu(false); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && menu.classList.contains('aperto')) { setMenu(false); menuBtn.focus(); } });
    window.matchMedia('(min-width: 1024px)').addEventListener('change', function (m) { if (m.matches) setMenu(false); });
  }

  /* ---------- Visore delle foto: la foto intera con frecce e tastiera; l'immagine nasce qui (nessun <img> vuoto) ---------- */
  var visore = document.querySelector('.fs-visore');
  var apri = Array.prototype.slice.call(document.querySelectorAll('[data-fs-apri]'));
  if (visore && apri.length && typeof visore.showModal === 'function') {
    var fig = visore.querySelector('figure');
    var cap = visore.querySelector('figcaption');
    var img = document.createElement('img');
    fig.insertBefore(img, cap);
    var ora = 0, daDove = null, inCorso = false;
    var bottoni = Array.prototype.slice.call(visore.querySelectorAll('.fs-visore__btn'));
    // Movimento: la foto si apre ingrandendosi dalla miniatura e ci torna alla chiusura; tra una foto e l'altra
    // scorre di lato con una dissolvenza. Con «riduci movimento» tutto avviene senza animazioni.
    var calmo = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var anima = function (el, frames, opz) {
      if (calmo || !el.animate) return Promise.resolve();
      var a = el.animate(frames, Object.assign({ easing: 'cubic-bezier(.22,.8,.24,1)', fill: 'both' }, opz));
      // Se la pagina non disegna (scheda in secondo piano) l'animazione resta ferma: dopo la sua durata si va avanti lo stesso.
      var tetto = new Promise(function (r) { setTimeout(function () { if (a.playState !== 'finished') a.finish(); r(); }, (opz.duration || 400) + (opz.delay || 0) + 150); });
      return Promise.race([a.finished.catch(function () {}), tetto]);
    };
    // decode() non si risolve finché la pagina non disegna: al massimo 1,2 secondi di attesa, poi si mostra comunque.
    var pronta = function () { return img.decode ? Promise.race([img.decode().catch(function () {}), new Promise(function (r) { setTimeout(r, 1200); })]) : Promise.resolve(); };
    var imposta = function (i) {
      ora = (i + apri.length) % apri.length;
      var src = apri[ora].querySelector('img');
      img.src = apri[ora].getAttribute('data-fs-full') || (src && (src.currentSrc || src.src)) || '';
      img.alt = src ? src.alt : '';
      cap.textContent = src ? src.alt : '';
    };
    // Trasformazione che porta la foto grande sopra la miniatura (tecnica FLIP).
    var versoMiniatura = function (b) {
      var m = b.getBoundingClientRect(), g = img.getBoundingClientRect();
      if (!m.width || !g.width) return 'scale(.9)';
      var k = Math.max(m.width / g.width, m.height / g.height);
      return 'translate(' + (m.left + m.width / 2 - g.left - g.width / 2) + 'px,' + (m.top + m.height / 2 - g.top - g.height / 2) + 'px) scale(' + k + ')';
    };
    var ritaglio = function (b) {
      var m = b.getBoundingClientRect(), g = img.getBoundingClientRect();
      var k = Math.max(m.width / g.width, m.height / g.height) || 1;
      var x = Math.max(0, (g.width - m.width / k) / 2 / g.width * 100), y = Math.max(0, (g.height - m.height / k) / 2 / g.height * 100);
      return 'inset(' + y + '% ' + x + '% round 4px)';
    };
    var apriDa = function (b, i) {
      if (inCorso) return;
      daDove = b; imposta(i);
      img.style.opacity = '0';
      visore.showModal();
      inCorso = true;
      pronta().then(function () {
        img.style.opacity = '';
        return Promise.all([
          anima(visore, [{ backgroundColor: 'rgba(20,18,16,0)' }, { backgroundColor: 'rgba(20,18,16,.94)' }], { duration: 420, easing: 'ease-out' }),
          anima(img, [{ transform: versoMiniatura(b), clipPath: ritaglio(b) }, { transform: 'none', clipPath: 'inset(0% 0% round 0px)' }], { duration: 560 }),
          anima(cap, [{ opacity: 0, transform: 'translateY(8px)' }, { opacity: 1, transform: 'none' }], { duration: 360, delay: 260 }),
          Promise.all(bottoni.map(function (el) { return anima(el, [{ opacity: 0 }, { opacity: 1 }], { duration: 300, delay: 200 }); }))
        ]);
      }).then(function () { inCorso = false; });
    };
    var chiudi = function () {
      if (inCorso || !visore.open) return;
      inCorso = true;
      var b = apri[ora];
      // Torna sulla miniatura della foto mostrata ora, se è visibile; altrimenti svanisce.
      var r = b.getBoundingClientRect(), vista = r.bottom > 0 && r.top < window.innerHeight;
      Promise.all([
        anima(visore, [{ backgroundColor: 'rgba(20,18,16,.94)' }, { backgroundColor: 'rgba(20,18,16,0)' }], { duration: 380, easing: 'ease-in' }),
        anima(cap, [{ opacity: 1 }, { opacity: 0 }], { duration: 160 }),
        Promise.all(bottoni.map(function (el) { return anima(el, [{ opacity: 1 }, { opacity: 0 }], { duration: 200 }); })),
        anima(img, vista ? [{ transform: 'none', clipPath: 'inset(0% 0% round 0px)' }, { transform: versoMiniatura(b), clipPath: ritaglio(b) }]
                         : [{ opacity: 1, transform: 'none' }, { opacity: 0, transform: 'scale(.94)' }], { duration: 440, easing: 'cubic-bezier(.5,0,.2,1)' })
      ]).then(function () {
        visore.close();
        img.getAnimations && img.getAnimations().forEach(function (a) { a.cancel(); });
        cap.getAnimations && cap.getAnimations().forEach(function (a) { a.cancel(); });
        [visore].concat(bottoni).forEach(function (el) { if (el.getAnimations) el.getAnimations().forEach(function (a) { a.cancel(); }); });
        inCorso = false;
      });
    };
    var mostra = function (i, verso) {
      if (inCorso) return;
      inCorso = true;
      var d = (verso || 1) * 48;
      Promise.all([
        anima(img, [{ opacity: 1, transform: 'none' }, { opacity: 0, transform: 'translateX(' + (-d) + 'px) scale(.98)' }], { duration: 200, easing: 'ease-in' }),
        anima(cap, [{ opacity: 1 }, { opacity: 0 }], { duration: 160 })
      ]).then(function () {
        imposta(i);
        return pronta();
      }).then(function () {
        return Promise.all([
          anima(img, [{ opacity: 0, transform: 'translateX(' + d + 'px) scale(.98)' }, { opacity: 1, transform: 'none' }], { duration: 420 }),
          anima(cap, [{ opacity: 0 }, { opacity: 1 }], { duration: 300, delay: 120 })
        ]);
      }).then(function () { inCorso = false; });
    };
    apri.forEach(function (b, i) { b.addEventListener('click', function () { apriDa(b, i); }); });
    visore.querySelector('.fs-visore__prec').addEventListener('click', function () { mostra(ora - 1, -1); });
    visore.querySelector('.fs-visore__succ').addEventListener('click', function () { mostra(ora + 1, 1); });
    visore.querySelector('.fs-visore__chiudi').addEventListener('click', chiudi);
    visore.addEventListener('click', function (e) { if (e.target === visore || e.target === fig) chiudi(); });
    visore.addEventListener('cancel', function (e) { e.preventDefault(); chiudi(); }); // Esc: chiusura animata
    visore.addEventListener('keydown', function (e) { if (e.key === 'ArrowLeft') mostra(ora - 1, -1); if (e.key === 'ArrowRight') mostra(ora + 1, 1); });
    // Sul telefono: trascinare la foto di lato passa alla successiva o alla precedente.
    var x0 = null, y0 = 0;
    img.addEventListener('touchstart', function (e) { x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; }, { passive: true });
    img.addEventListener('touchend', function (e) {
      if (x0 === null) return;
      var dx = e.changedTouches[0].clientX - x0, dy = e.changedTouches[0].clientY - y0;
      x0 = null;
      if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.4) mostra(ora + (dx < 0 ? 1 : -1), dx < 0 ? 1 : -1);
    });
    visore.addEventListener('close', function () { if (daDove) daDove.focus(); });
  }

  /* ---------- Preferenze dei cookie: il banner del parent sparisce dopo la scelta; si riapre togliendo la scelta ---------- */
  document.querySelectorAll('[data-fs-cookies]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var expired = '=; expires=Thu, 01 Jan 1970 00:00:00 GMT; SameSite=Lax; path=';
      var path = window.location.pathname.split('/').slice(0, 2).join('/') || '/';
      document.cookie = 'tw_cookie_consent' + expired + '/';
      if (path !== '/') document.cookie = 'tw_cookie_consent' + expired + path;
      window.location.reload();
    });
  });

  /* ---------- Modulo «Scrivici» (gestore del parent: Invii Ricevuti, reCAPTCHA, SMTP) ---------- */
  var recaptchaLoading = null;
  function loadRecaptcha() {
    if (!cfg.recaptchaKey) return Promise.resolve(null);
    if (window.grecaptcha && window.grecaptcha.execute) return Promise.resolve(window.grecaptcha);
    if (!recaptchaLoading) {
      recaptchaLoading = new Promise(function (resolve, reject) {
        var s = document.createElement('script');
        s.src = 'https://www.google.com/recaptcha/api.js?render=' + encodeURIComponent(cfg.recaptchaKey);
        s.async = true;
        s.onload = function () { window.grecaptcha.ready(function () { resolve(window.grecaptcha); }); };
        s.onerror = function () { recaptchaLoading = null; reject(new Error('recaptcha')); };
        document.head.appendChild(s);
      });
    }
    return recaptchaLoading;
  }

  document.querySelectorAll('[data-fs-form]').forEach(function (form) {
    var status = form.querySelector('.fs-modulo__stato');
    var button = form.querySelector('button[type="submit"]');
    // reCAPTCHA si carica solo quando il visitatore inizia a compilare, non con la pagina.
    form.addEventListener('focusin', function () { loadRecaptcha().catch(function () {}); }, { once: true });

    function say(text, kind) {
      status.textContent = text || '';
      status.className = 'fs-modulo__stato' + (kind ? ' is-' + kind : '');
    }
    function clearErrors() {
      form.querySelectorAll('.fs-campo.non-valido').forEach(function (f) {
        f.classList.remove('non-valido');
        var msg = f.querySelector('.fs-errore');
        if (msg) msg.remove();
        var input = f.querySelector('input, textarea');
        if (input) { input.removeAttribute('aria-invalid'); input.removeAttribute('aria-describedby'); }
      });
    }
    function markErrors(fields) {
      var first = null;
      Object.keys(fields || {}).forEach(function (name) {
        var field = form.querySelector('[data-field="' + name + '"]');
        if (!field) return;
        field.classList.add('non-valido');
        var input = field.querySelector('input, textarea');
        var msg = document.createElement('span');
        msg.className = 'fs-errore';
        msg.id = 'fs-errore-' + name;
        msg.textContent = fields[name];
        field.appendChild(msg);
        if (input) { input.setAttribute('aria-invalid', 'true'); input.setAttribute('aria-describedby', msg.id); first = first || input; }
      });
      if (first) first.focus();
    }
    function localErrors() {
      var out = {};
      form.querySelectorAll('[data-field] input, [data-field] textarea').forEach(function (input) {
        if (input.type === 'checkbox') { if (!input.checked) out[input.closest('[data-field]').getAttribute('data-field')] = cfg.consent || input.validationMessage; return; }
        if (!input.checkValidity()) out[input.closest('[data-field]').getAttribute('data-field')] = input.validationMessage;
      });
      return out;
    }

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      clearErrors();
      var local = localErrors();
      if (Object.keys(local).length) { markErrors(local); say(''); return; }
      if (!navigator.onLine) { say(cfg.offline, 'error'); return; }

      button.disabled = true;
      say(cfg.sending, 'wait');
      var data = new FormData(form);
      data.set('oggetto', cfg.subject || '');
      // Il consenso resta scritto nel messaggio salvato in Invii Ricevuti (prova del consenso, nLPD/GDPR).
      var consenso = form.querySelector('.fs-consenso span');
      data.delete('privacy');
      data.set('messaggio', (data.get('messaggio') || '') + '\n\n— ' + (consenso ? consenso.textContent.trim().replace(/\s+/g, ' ') : 'Consenso privacy') + ' ✓');

      fetch(cfg.ajaxUrl + '?action=ticinoweb_form_token', { credentials: 'same-origin', cache: 'no-store' })
        .then(function (r) { return r.json(); })
        .then(function (t) {
          if (!t || !t.success) throw new Error('token');
          data.set('token', t.data.token);
          return loadRecaptcha().then(function (g) {
            return g ? g.execute(cfg.recaptchaKey, { action: 'contact' }) : '';
          }, function () { return ''; });
        })
        .then(function (rc) {
          if (rc) data.set('recaptcha_token', rc);
          return fetch(cfg.ajaxUrl, { method: 'POST', body: data, credentials: 'same-origin' });
        })
        .then(function (r) { return r.json().catch(function () { return { success: false }; }); })
        .then(function (res) {
          if (res && res.success) {
            form.reset();
            say((res.data && res.data.message) || cfg.sent, 'ok');
            return;
          }
          var d = (res && res.data) || {};
          if (d.fields) markErrors(d.fields);
          say(d.message || cfg.failed, 'error');
        })
        .catch(function () { say(cfg.failed, 'error'); })
        .finally(function () { button.disabled = false; });
    });
  });

  /* ---------- Stato del negozio («Aperto ora · fino alle 18:00» / «Chiuso · riapre martedì alle 10:00»), dagli orari
     del CMS e nell'ora di Locarno, qualunque sia il fuso del visitatore. Si aggiorna ogni minuto. ---------- */
  var chiavi = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  function oraLocarno() {
    var p = {};
    new Intl.DateTimeFormat('en-GB', { timeZone: 'Europe/Zurich', weekday: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' })
      .formatToParts(new Date()).forEach(function (x) { p[x.type] = x.value; });
    return { giorno: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].indexOf(p.weekday), minuti: (+p.hour) * 60 + (+p.minute) };
  }
  function minuti(hhmm) { var m = /^(\d{1,2})[:.](\d{2})/.exec(hhmm || ''); return m ? (+m[1]) * 60 + (+m[2]) : null; }
  function fasce(orari, g) {
    var d = orari[chiavi[g]];
    if (!d || d.closed) return [];
    if (d.open_24h) return [[0, 1440, '00:00', '24:00']];
    return (d.slots || []).map(function (s) { return [minuti(s.open), minuti(s.close), s.open, s.close]; }).filter(function (f) { return f[0] !== null && f[1] !== null; });
  }
  function aggiornaStato() {
    document.querySelectorAll('[data-fs-orari]').forEach(function (el) {
      var orari;
      try { orari = JSON.parse(el.getAttribute('data-fs-orari') || '{}'); } catch (e) { return; }
      if (!orari || typeof orari !== 'object') return;
      var ora = oraLocarno(), testo = '', aperto = false;
      fasce(orari, ora.giorno).forEach(function (f) { if (ora.minuti >= f[0] && ora.minuti < f[1]) { aperto = true; testo = (el.dataset.aperto || '%s').replace('%s', f[3]); } });
      if (!aperto) {
        var giorni = (el.dataset.giorni || '').split(',');
        for (var i = 0; i < 8 && !testo; i++) {
          var g = (ora.giorno + i) % 7;
          var prossima = fasce(orari, g).filter(function (f) { return i > 0 || f[0] > ora.minuti; })[0];
          if (prossima) {
            var quando = i === 0 ? el.dataset.oggi : (i === 1 ? el.dataset.domani : (giorni[g] || chiavi[g]));
            testo = (el.dataset.riapre || '%1$s %2$s').replace('%1$s', quando).replace('%2$s', prossima[2]);
          }
        }
        if (!testo) testo = el.dataset.chiuso || '';
      }
      el.textContent = testo;
      el.classList.toggle('aperto', aperto);
    });
  }
  if (window.Intl && Intl.DateTimeFormat) { aggiornaStato(); setInterval(aggiornaStato, 60000); }


  /* Galleria a file giustificate: le foto restano intere, ogni fila riempie tutta la larghezza e tutte le file hanno quasi la stessa
     altezza. Niente colonne che finiscono a quote diverse, niente buchi. Si ricalcola quando cambia la larghezza. */
  document.querySelectorAll('.fs-muratura').forEach(function (box) {
    var voci = Array.prototype.slice.call(box.querySelectorAll('.fs-foto')).map(function (el) {
      var im = el.querySelector('img'), w = im && +im.getAttribute('width'), h = im && +im.getAttribute('height');
      return { el: el, ar: (w && h) ? w / h : 1.5 };
    });
    if (!voci.length) return;
    var ultimaL = 0;
    function dispone() {
      var W = box.clientWidth; if (!W || W === ultimaL) return; ultimaL = W;
      var cs = getComputedStyle(box), gap = parseFloat(cs.rowGap) || parseFloat(cs.columnGap) || 12;
      var Ht = W >= 1100 ? 300 : (W >= 700 ? 240 : 170), n = voci.length;
      // Si cerca l'ordine delle foto e la suddivisione in file che tengono tutte le file vicine all'altezza ideale (in proporzione): né una foto
      // sola altissima, né foto minuscole. Per ogni ordine la suddivisione migliore è un calcolo a programmazione dinamica; gli ordini provati
      // sono quello originale e alcune centinaia di rimescolate con un generatore fisso (a parità di larghezza esce sempre lo stesso risultato).
      function migliore(ordine) {
        function costo(a, b) {
          var S = 0; for (var i = a; i < b; i++) S += ordine[i].ar;
          var h = (W - gap * (b - a - 1)) / S, r = Math.log(h / Ht), c = r * r;
          var e = Math.abs(r) - 0.4; if (e > 0) c += e * e * 8;          // file molto più alte o più basse del giusto pesano di più
          var minAr = 9; for (var q2 = a; q2 < b; q2++) if (ordine[q2].ar < minAr) minAr = ordine[q2].ar;
          var largMin = minAr * h; if (largMin < 100) c += Math.pow((100 - largMin) / 25, 2); // niente foto strettissime (una foto verticale in una fila da tre su telefono)
          if (b - a === 1 && W < 700) c += 0.35;                           // su telefono una foto sola per fila solo se serve davvero
          return c;
        }
        var dp = new Array(n + 1).fill(1e18), da = new Array(n + 1).fill(0);
        dp[0] = 0;
        for (var i2 = 1; i2 <= n; i2++) for (var s = 0; s < i2; s++) { var c2 = dp[s] + costo(s, i2); if (c2 < dp[i2]) { dp[i2] = c2; da[i2] = s; } }
        var tagli = [], fine = n;
        while (fine > 0) { var ini = da[fine]; tagli.unshift([ini, fine]); fine = ini; }
        // le file devono anche somigliarsi tra loro: si aggiunge la varianza delle altezze (in proporzione)
        var lg = tagli.map(function (t) { var S = 0; for (var i = t[0]; i < t[1]; i++) S += ordine[i].ar; return Math.log(((W - gap * (t[1] - t[0] - 1)) / S) / Ht); });
        var med = lg.reduce(function (x, y) { return x + y; }, 0) / lg.length, vr = lg.reduce(function (x, y) { return x + (y - med) * (y - med); }, 0);
        return { costo: dp[n] + 1.5 * vr, tagli: tagli, ordine: ordine };
      }
      var seme = W * 2654435761 >>> 0;
      function caso() { seme = (seme + 0x6D2B79F5) >>> 0; var t = seme; t = Math.imul(t ^ t >>> 15, t | 1); t ^= t + Math.imul(t ^ t >>> 7, t | 61); return ((t ^ t >>> 14) >>> 0) / 4294967296; }
      var scelto = migliore(voci.slice());
      for (var prova = 0; prova < 500; prova++) {
        var o = voci.slice();
        for (var q = o.length - 1; q > 0; q--) { var r2 = Math.floor(caso() * (q + 1)), tmp = o[q]; o[q] = o[r2]; o[r2] = tmp; }
        var m = migliore(o); if (m.costo < scelto.costo - 1e-9) scelto = m;
      }
      var ordine = scelto.ordine, tagli = scelto.tagli, vecchie = Array.prototype.slice.call(box.querySelectorAll(':scope > .fs-fila')), frag = document.createDocumentFragment();
      // Ogni fila è un suo contenitore (nessuna foto può andare a capo per un decimale): le larghezze le ripartisce il browser in proporzione
      // alle proporzioni delle foto, e l'altezza della fila è quella che ne risulta. Il visore a tutto schermo ha il suo elenco.
      tagli.forEach(function (t) {
        var S = 0; for (var i = t[0]; i < t[1]; i++) S += ordine[i].ar;
        var h = (W - gap * (t[1] - t[0] - 1)) / S, fila = document.createElement('div');
        fila.className = 'fs-fila';
        for (var j = t[0]; j < t[1]; j++) {
          var st = ordine[j].el.style;
          st.flex = ordine[j].ar.toFixed(4) + ' 1 0%'; st.width = 'auto'; st.height = h.toFixed(2) + 'px'; st.aspectRatio = 'auto';
          fila.appendChild(ordine[j].el);
        }
        frag.appendChild(fila);
      });
      vecchie.forEach(function (f) { if (f.parentNode) f.parentNode.removeChild(f); });
      box.classList.add('fs-muratura--file');
      box.appendChild(frag);
    }
    dispone();
    if (window.ResizeObserver) new ResizeObserver(dispone).observe(box); else addEventListener('resize', dispone);
  });

  document.documentElement.classList.add('fs-js');
})();
