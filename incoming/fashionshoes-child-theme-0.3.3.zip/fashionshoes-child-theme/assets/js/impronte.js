/**
 * Fashion Shoes: impronte di scarpe sullo sfondo della testata (fino alla barra del menu, che resta pulita) e della sezione «Il negozio».
 * Muovendo il mouse su queste zone compaiono impronte di suola, una a sinistra e una a destra, orientate nel verso del movimento,
 * che svaniscono in un paio di secondi. Le impronte continuano anche passando da una zona all'altra:
 * ogni zona ha il suo canvas dietro il contenuto e disegna la parte di impronte che le cade sopra.
 * Il disegno è fatto in canvas (nessuna immagine, nessuna libreria).
 * Non parte con «riduci movimento» né sugli schermi senza mouse (telefono, tablet): lì il dito serve a scorrere.
 */
(function () {
  'use strict';
  if (!window.matchMedia || !HTMLCanvasElement) return;
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  if (!matchMedia('(hover: hover) and (pointer: fine)').matches) return;

  var dpr = Math.min(window.devicePixelRatio || 1, 2);
  var PASSO = 46, LATERALE = 11, SVANIRE = 0.982;
  var superfici = [], orme = [], acc = 0, lato = 1, ultimo = null, giro = 0;

  // Le zone dove compaiono le impronte (la testata, «Il negozio»). La barra del menu in alto resta pulita.
  Array.prototype.forEach.call(document.querySelectorAll('.fs-hero, .fs-negozio'), function (el) {
    var cv = document.createElement('canvas');
    cv.className = 'fs-impronte';
    cv.setAttribute('aria-hidden', 'true');
    el.insertBefore(cv, el.firstChild);
    var cx = cv.getContext('2d');
    if (!cx) return;
    var s = { el: el, cv: cv, cx: cx, W: 0, H: 0, visibile: true };
    function misura() {
      var r = el.getBoundingClientRect();
      s.W = r.width; s.H = r.height;
      cv.width = Math.round(s.W * dpr); cv.height = Math.round(s.H * dpr);
      cx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    misura();
    if (window.ResizeObserver) new ResizeObserver(misura).observe(el); else addEventListener('resize', misura);
    if (window.IntersectionObserver) new IntersectionObserver(function (v) { s.visibile = v[0].isIntersecting; if (s.visibile && orme.length) avvia(); }, { threshold: 0 }).observe(el);
    superfici.push(s);
  });
  if (!superfici.length) return;

  function suola(cx, o, x, y) {
    cx.save();
    cx.translate(x, y);
    cx.rotate(o.a + Math.PI / 2);
    cx.scale(o.l * 0.8, 0.8);
    cx.fillStyle = 'rgba(58,41,34,' + (o.v * 0.5).toFixed(3) + ')';
    cx.beginPath(); cx.ellipse(0, -6, 8, 14, 0, 0, 6.2832); cx.fill();   // suola
    cx.beginPath(); cx.ellipse(0, 14, 5.4, 6.6, 0, 0, 6.2832); cx.fill(); // tacco
    cx.restore();
  }

  // Le impronte stanno in coordinate della pagina (x, y + scroll): ogni zona le disegna con la propria posizione sullo schermo.
  function frame() {
    giro = 0;
    var sy = window.scrollY || window.pageYOffset || 0;
    orme = orme.filter(function (o) { return o.v > 0.02; });
    superfici.forEach(function (s) {
      s.cx.clearRect(0, 0, s.W, s.H);
      if (!s.visibile) return;
      var r = s.el.getBoundingClientRect();
      orme.forEach(function (o) {
        var x = o.x - r.left, y = o.y - sy - r.top;
        if (x < -30 || x > s.W + 30 || y < -30 || y > s.H + 30) return;
        suola(s.cx, o, x, y);
      });
    });
    orme.forEach(function (o) { o.v *= SVANIRE; });
    if (orme.length && !document.hidden) giro = requestAnimationFrame(frame);
  }
  function avvia() { if (!giro) giro = requestAnimationFrame(frame); }

  // Si ascolta tutta la pagina e si lavora solo quando il mouse sta sopra una delle zone: così la camminata passa da una zona all'altra.
  function sopraUnaZona(x, y) {
    for (var i = 0; i < superfici.length; i++) { var r = superfici[i].el.getBoundingClientRect(); if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) return true; }
    return false;
  }
  document.addEventListener('pointermove', function (e) {
    if (e.pointerType && e.pointerType !== 'mouse' && e.pointerType !== 'pen') return;
    if (!sopraUnaZona(e.clientX, e.clientY)) { ultimo = null; return; }
    var x = e.clientX, y = e.clientY;
    if (!ultimo) { ultimo = { x: x, y: y }; return; }
    var dx = x - ultimo.x, dy = y - ultimo.y, d = Math.hypot(dx, dy);
    if (d > 420) { ultimo = { x: x, y: y }; return; } // salto (il mouse è uscito e rientrato): non è una camminata
    acc += d;
    if (acc > PASSO) {
      acc = 0;
      var a = Math.atan2(dy, dx), sy = window.scrollY || window.pageYOffset || 0;
      orme.push({ x: x - Math.sin(a) * LATERALE * lato, y: y + Math.cos(a) * LATERALE * lato + sy, a: a, l: lato, v: 1 });
      lato = -lato;
      if (orme.length > 60) orme.shift();
      avvia();
    }
    ultimo = { x: x, y: y };
  }, { passive: true });
  document.documentElement.addEventListener('pointerleave', function () { ultimo = null; });
  document.addEventListener('visibilitychange', function () { if (!document.hidden && orme.length) avvia(); });
})();
