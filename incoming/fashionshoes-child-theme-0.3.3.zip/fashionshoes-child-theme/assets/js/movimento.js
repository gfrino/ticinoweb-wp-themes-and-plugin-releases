/**
 * Fashion Shoes: movimento con intenzione (regole in tools/fashionshoes/ANTI-SLOP.md), solo dove aiuta a leggere:
 * 1. il logo grande: si scopre da sinistra a destra e, scorrendo, vola in alto a sinistra fino al posto del logo della testata e lì resta;
 * 2. titolo e informazioni entrano dopo la parola; i due post della testata si muovono a velocità diverse mentre scorri;
 * 3. collezioni: la linea di ogni riga si disegna, poi entrano nome, testo e miniatura;
 * 4. blocchi del negozio, dei contatti e delle domande: entrano una volta sola quando arrivano in vista;
 * 5. Instagram: i post si scoprono uno dopo l'altro;
 * 6. Lenis: scorrimento morbido, anche per le àncore del menu (con lo spazio della testata).
 * Parte solo se nell'head è stato messo html.fs-moto (niente «riduci movimento»). Se le librerie non arrivano entro 3 secondi,
 * oppure qui dentro qualcosa va storto, la classe si toglie e la pagina resta tutta visibile.
 */
(function () {
  'use strict';
  var d = document.documentElement;
  if (!d.classList.contains('fs-moto') || !window.gsap || !window.ScrollTrigger) {
    d.classList.remove('fs-moto');
    return;
  }
  var gsap = window.gsap;
  window.fsIntroPartita = true;
  try {
    gsap.registerPlugin(window.ScrollTrigger);

    // Dopo un ricaricamento il browser rimetterebbe la pagina dov'era: l'ingresso della testata andrebbe perso.
    // Si riparte dall'alto, salvo quando l'indirizzo punta a una sezione (#...).
    // ScrollTrigger si ricorda la posizione per conto suo e rimette il ripristino del browser su «auto»: va fatto dimenticare.
    if (!location.hash) {
      var daCapo = function () {
        window.ScrollTrigger.clearScrollMemory('manual');
        window.scrollTo(0, 0);
      };
      daCapo();
      window.addEventListener('load', function () { daCapo(); setTimeout(daCapo, 60); });
    }

    /* ---------- Lenis ---------- */
    var lenis = null;
    if (window.Lenis) {
      lenis = new window.Lenis({ lerp: 0.1, wheelMultiplier: 1 });
      lenis.on('scroll', window.ScrollTrigger.update);
      gsap.ticker.add(function (t) { lenis.raf(t * 1000); });
      gsap.ticker.lagSmoothing(0);
      // Àncore della stessa pagina (anche scritte come indirizzo completo nel menu del CMS).
      document.addEventListener('click', function (e) {
        var a = e.target.closest && e.target.closest('a[href*="#"]');
        if (!a || e.defaultPrevented || e.metaKey || e.ctrlKey) return;
        var url = new URL(a.href, location.href);
        if (url.pathname !== location.pathname || !url.hash || url.hash.length < 2) return;
        var dove = document.getElementById(decodeURIComponent(url.hash.slice(1)));
        if (!dove) return;
        e.preventDefault();
        // Lenis usa già lo scroll-padding-top del CSS (lo spazio della testata): nessun offset in più.
        lenis.scrollTo(dove, { duration: 1.1 });
        history.replaceState(null, '', url.hash);
      });
      // Il visore e il menu aperto fermano lo scorrimento della pagina dietro.
      var visore = document.querySelector('.fs-visore');
      if (visore && window.MutationObserver) {
        new MutationObserver(function () { visore.open ? lenis.stop() : lenis.start(); }).observe(visore, { attributes: true, attributeFilter: ['open'] });
      }
    }

    /* ---------- 1. Il logo grande che vola nella testata ---------- */
    var logo = document.querySelector('[data-fs-logo]'), posto = document.querySelector('[data-fs-logo-posto]'), hl = document.querySelector('.fs-testata__logo img'), main = document.getElementById('fs-main');
    if (logo && posto && hl && main) {
      var m0 = { x: 0, y: 0, w: 1, h: 1 }, mE = { x: 0, y: 0, w: 1 };
      // Il logo si fissa e si porta fuori dai contenitori della testata: così sta sopra la testata (z-index) e non balla con lo scorrimento.
      var medi = function () {
        // Il segnaposto ha l'altezza dalle proporzioni del logo (CSS), il logo è fisso: le misure non dipendono dal logo stesso.
        var pr = posto.getBoundingClientRect(), hr = hl.getBoundingClientRect();
        m0 = { x: pr.left, y: pr.top + window.scrollY, w: pr.width, h: pr.height };
        mE = { x: hr.left, y: hr.top, w: hr.width };
        logo.style.width = pr.width + 'px';
      };
      d.classList.add('fs-logo-vola');
      medi();
      main.parentNode.insertBefore(logo, main); // fuori dai contenitori della testata, subito dopo l'intestazione: così sta sopra tutto
      window.ScrollTrigger.addEventListener('refreshInit', medi);
      gsap.fromTo(logo,
        { x: function () { return m0.x; }, y: function () { return m0.y; }, scale: 1, transformOrigin: '0 0' },
        { x: function () { return mE.x; }, y: function () { return mE.y; }, scale: function () { return mE.w / m0.w; }, ease: 'power1.inOut',
          scrollTrigger: { start: 0, end: function () { return Math.max(260, (m0.y - mE.y + m0.h) * 0.85); }, scrub: 0.5, invalidateOnRefresh: true,
            // Cliccabile (e raggiungibile con la tastiera) solo quando è arrivato nella testata: prima non deve coprire i pulsanti sotto.
            onUpdate: function (st) { arrivato(st.progress > 0.985); }, onRefresh: function (st) { arrivato(st.progress > 0.985); } } });
      var statoArrivo = null;
      function arrivato(si) { if (si === statoArrivo) return; statoArrivo = si; logo.classList.toggle('fs-logo-arrivato', si); if (si) logo.removeAttribute('tabindex'); else logo.setAttribute('tabindex', '-1'); }
      arrivato(false);
      // Sfocatura di movimento: una scia di copie del logo nella direzione in cui si muove (anche di lato, anche in diagonale), lunga in proporzione
      // alla velocità; ferma = nessun filtro. Il filtro lavora prima della scala del logo: gli spostamenti si dividono per la scala.
      var offs = document.querySelectorAll('#fs-sfoca feOffset'), mix = document.getElementById('fs-mix');
      if (offs.length && mix) {
        var r0 = logo.getBoundingClientRect(), pcx = r0.left + r0.width / 2, pcy = r0.top + r0.height / 2, svx = 0, svy = 0, acceso = false, ms = 0;
        gsap.ticker.add(function () {
          var r = logo.getBoundingClientRect(), cxn = r.left + r.width / 2, cyn = r.top + r.height / 2, sc = gsap.getProperty(logo, 'scaleX') || 1;
          var tx = cxn - pcx, ty = cyn - pcy; pcx = cxn; pcy = cyn;
          // sale e scende in fretta: appena il logo si ferma, la sfocatura sparisce subito (e senza scatto, grazie al mescolamento continuo)
          svx += (tx - svx) * 0.4; svy += (ty - svy) * 0.4;
          var L = Math.hypot(svx, svy), m = Math.max(0, Math.min(1, (L - 0.6) / 4)); m = m * m * (3 - 2 * m); // quanta sfocatura mescolare al logo nitido (0 = nitido)
          ms += (m - ms) * (m > ms ? 1 : 0.45); m = ms; // sale subito, scende in una decina di frame (circa un decimo di secondo): niente scatto finale
          if (m < 0.012) { if (acceso) { logo.style.filter = ''; acceso = false; } return; }
          var k = Math.min(1, 11 / (L * 1.1));
          for (var i = 0; i < offs.length; i++) {
            var f = (i / (offs.length - 1) - 0.5) * 1.1 * k; // le copie stanno a cavallo della posizione attuale, lungo la direzione del moto
            offs[i].setAttribute('dx', (svx * f / sc).toFixed(2)); offs[i].setAttribute('dy', (svy * f / sc).toFixed(2));
          }
          mix.setAttribute('k2', (1 - m).toFixed(3)); mix.setAttribute('k3', m.toFixed(3));
          if (!acceso) { logo.style.filter = 'url(#fs-sfoca)'; acceso = true; }
        });
      }
      // ingresso: il logo si scopre da sinistra a destra
      var img = logo.querySelector('img');
      gsap.fromTo(img, { clipPath: 'inset(0 100% 0 0)' }, { clipPath: 'inset(0 0% 0 0)', duration: 1.2, ease: 'power3.inOut', delay: 0.1, clearProps: 'clipPath' });
    }

    /* ---------- 2. Titolo, informazioni e i due post ---------- */
    gsap.to('[data-fs-su]', { opacity: 1, y: 0, duration: 0.9, ease: 'power3.out', stagger: 0.12, delay: 0.7 });
    var coppia = document.querySelector('.fs-coppia');
    if (coppia) {
      var foto = coppia.querySelectorAll('.fs-foto');
      // Si muovono le cornici, mai le immagini: i post hanno il testo dentro e non vanno ritagliati.
      if (foto[0]) gsap.fromTo(foto[0], { yPercent: 4 }, { yPercent: -4, ease: 'none', scrollTrigger: { trigger: coppia, start: 'top bottom', end: 'bottom top', scrub: true } });
      if (foto[1]) gsap.fromTo(foto[1], { yPercent: 12 }, { yPercent: -8, ease: 'none', scrollTrigger: { trigger: coppia, start: 'top bottom', end: 'bottom top', scrub: true } });
    }

    /* ---------- 3. Collezioni ---------- */
    document.querySelectorAll('.fs-riga').forEach(function (riga) {
      gsap.to(riga, { '--fs-l': 1, duration: 1, ease: 'power3.inOut', scrollTrigger: { trigger: riga, start: 'top 88%' } });
      gsap.from(riga.querySelectorAll('h3, p, .fs-foto'), { y: 36, opacity: 0, duration: 0.9, ease: 'power3.out', stagger: 0.08, clearProps: 'transform,opacity', scrollTrigger: { trigger: riga, start: 'top 88%' } });
    });

    /* ---------- 4. Blocchi che entrano una volta sola ---------- */
    window.ScrollTrigger.batch('[data-fs-rev]', {
      start: 'top 90%',
      once: true,
      onEnter: function (els) { gsap.to(els, { opacity: 1, y: 0, duration: 0.9, ease: 'power3.out', stagger: 0.12 }); }
    });
    var neg = document.querySelector('.fs-negozio__foto');
    if (neg) {
      neg.querySelectorAll('.fs-foto').forEach(function (f, n) {
        gsap.fromTo(f, { yPercent: n ? 6 : 2 }, { yPercent: n ? -6 : -2, ease: 'none', scrollTrigger: { trigger: '.fs-negozio', start: 'top bottom', end: 'bottom top', scrub: true } });
      });
    }

    /* ---------- 5. Instagram ---------- */
    var post = document.querySelectorAll('.fs-striscia .fs-foto');
    if (post.length) {
      gsap.to(post, { clipPath: 'inset(0 0 0% 0)', duration: 1, ease: 'power3.inOut', stagger: 0.12, scrollTrigger: { trigger: '.fs-striscia', start: 'top 85%' } });
    }
  } catch (err) {
    d.classList.remove('fs-moto');
  }
})();
