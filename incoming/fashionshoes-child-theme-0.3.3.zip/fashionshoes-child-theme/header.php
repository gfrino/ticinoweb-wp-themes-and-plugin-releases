<?php
/**
 * Testata: logo del CMS a sinistra, voci del menu «primary», bottone «Chiama» (telefono del CMS).
 * Sotto i 1024 px le voci si aprono da un bottone menu (44 px) in un pannello sotto la barra.
 *
 * @package fashionshoes-child-theme
 */

defined('ABSPATH') || exit;

$fs_name  = function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text(get_bloginfo('name'), 'theme:branding:site_name') : get_bloginfo('name');
$fs_home  = fashionshoes_url(home_url('/'), 'url:home');
$fs_items = array();
$fs_locs  = get_nav_menu_locations();
if (!empty($fs_locs['primary'])) {
    foreach ((array) wp_get_nav_menu_items($fs_locs['primary']) as $fs_item) {
        if ((int) $fs_item->menu_item_parent === 0) {
            $fs_items[] = array('title' => $fs_item->title, 'url' => $fs_item->url, 'target' => $fs_item->target);
        }
    }
}
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="fs-salta fs-bottone fs-bottone--pieno" href="#fs-main"><?php esc_html_e('Vai al contenuto', 'fashionshoes-child-theme'); ?></a>
<header class="fs-testata">
    <div class="fs-contenitore fs-testata__in">
        <a class="fs-testata__logo" href="<?php echo esc_url($fs_home); ?>" rel="home">
<?php // Il logo del cliente ridisegnato in SVG (ridisegna-logo-svg, 23.11.2026): senza sfondo, marrone sul rosa dei fondali. ?>
            <img src="<?php echo esc_url(FASHIONSHOES_URI . '/assets/img/logo-marrone.svg'); ?>" alt="<?php echo esc_attr($fs_name); ?>" width="2768" height="385" decoding="async">
        </a>
        <?php if ($fs_items) : ?>
            <nav class="fs-testata__nav" id="fs-menu" aria-label="<?php echo esc_attr(fashionshoes_t(__('Principale', 'fashionshoes-child-theme'), 'ui:nav')); ?>">
                <?php foreach ($fs_items as $fs_item) : ?>
                    <a href="<?php echo esc_url($fs_item['url']); ?>"<?php echo $fs_item['target'] ? ' target="' . esc_attr($fs_item['target']) . '" rel="noopener"' : ''; ?>><?php echo esc_html($fs_item['title']); ?></a>
                <?php endforeach; ?>
            </nav>
        <?php endif; ?>
        <?php $fs_tel = fashionshoes_contacts()['phone']; ?>
        <?php if ($fs_tel !== '') : ?><div class="fs-testata__azione"><a class="fs-bottone fs-bottone--pieno" href="<?php echo esc_attr(fashionshoes_tel($fs_tel)); ?>"><?php echo fashionshoes_icona('telefono'); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e('Chiama', 'fashionshoes-child-theme'); ?></a></div><?php endif; ?>
        <?php if ($fs_items) : ?>
            <button class="fs-testata__menu" type="button" aria-expanded="false" aria-controls="fs-menu" aria-label="<?php echo esc_attr(fashionshoes_t(__('Apri il menu', 'fashionshoes-child-theme'), 'ui:menu_open')); ?>"><?php echo fashionshoes_icona('menu') . fashionshoes_icona('chiudi'); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG del tema ?></button>
        <?php endif; ?>
    </div>
</header>
