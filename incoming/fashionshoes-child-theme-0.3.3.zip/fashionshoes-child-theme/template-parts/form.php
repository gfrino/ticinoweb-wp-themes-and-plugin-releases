<?php
/**
 * Modulo «Scrivici». Lo invia il gestore del parent (admin-ajax.php?action=ticinoweb_submit_form): salvataggio in
 * Invii Ricevuti, email all'indirizzo di ticinoWEB CMS → Contatti via SMTP, reCAPTCHA v3 se configurato, honeypot
 * e limite di invii. Il consenso alla privacy è obbligatorio (nLPD/GDPR) e viaggia nel messaggio salvato.
 * Lo script è assets/js/site.js; senza JavaScript il modulo non parte e lo dice, con telefono ed email.
 *
 * @package fashionshoes-child-theme
 */

defined('ABSPATH') || exit;

$fs_contacts = fashionshoes_contacts();
$fs_privacy  = fashionshoes_privacy_url();
$fs_title    = fashionshoes_text('form_title');
?>
<form class="fs-modulo" data-fs-form style="--fs-t:8; --fs-d:6; --fs-d-start:7" method="post" action="<?php echo esc_url(admin_url('admin-ajax.php')); ?>" novalidate>
    <input type="hidden" name="action" value="ticinoweb_submit_form">
    <input type="hidden" name="fs_form" value="1">
    <label class="fs-modulo__hp" aria-hidden="true"><?php esc_html_e('Non compilare questo campo', 'fashionshoes-child-theme'); ?><input type="text" name="tw_hp" tabindex="-1" autocomplete="off"></label>
    <?php if ($fs_title !== '') : ?><h3><?php echo esc_html($fs_title); ?></h3><?php endif; ?>
    <div class="fs-modulo__coppia">
        <div class="fs-campo" data-field="nome"><label for="fs-f-nome"><?php esc_html_e('Nome', 'fashionshoes-child-theme'); ?></label><input id="fs-f-nome" name="nome" autocomplete="name" required minlength="2"></div>
        <div class="fs-campo" data-field="telefono"><label for="fs-f-tel"><?php esc_html_e('Telefono', 'fashionshoes-child-theme'); ?></label><input id="fs-f-tel" name="telefono" type="tel" autocomplete="tel"></div>
    </div>
    <div class="fs-campo" data-field="email"><label for="fs-f-email"><?php esc_html_e('Email', 'fashionshoes-child-theme'); ?></label><input id="fs-f-email" name="email" type="email" autocomplete="email" required></div>
    <div class="fs-campo" data-field="messaggio"><label for="fs-f-msg"><?php esc_html_e('Messaggio', 'fashionshoes-child-theme'); ?></label><textarea id="fs-f-msg" name="messaggio" required minlength="5"></textarea></div>
    <div class="fs-campo fs-campo--consenso" data-field="privacy">
        <label class="fs-consenso"><input type="checkbox" name="privacy" value="1" required>
            <span><?php
            if ($fs_privacy !== '') {
                printf(
                    /* translators: %s: link all'informativa sulla privacy */
                    esc_html__('Ho letto l’%s e accetto che i miei dati siano usati per rispondere al messaggio.', 'fashionshoes-child-theme'),
                    '<a class="fs-link" href="' . esc_url(fashionshoes_url($fs_privacy, 'url:privacy')) . '" target="_blank" rel="noopener">' . esc_html__('informativa sulla privacy', 'fashionshoes-child-theme') . '</a>'
                );
            } else {
                esc_html_e('Accetto che i miei dati siano usati per rispondere al messaggio.', 'fashionshoes-child-theme');
            }
            ?></span>
        </label>
    </div>
    <div><button class="fs-bottone fs-bottone--pieno fs-modulo__invia" type="submit"><?php esc_html_e('Invia il messaggio', 'fashionshoes-child-theme'); ?></button></div>
    <p class="fs-modulo__stato" role="status" aria-live="polite"></p>
    <noscript><p class="fs-modulo__stato is-error"><?php
        echo esc_html(trim(sprintf(
            /* translators: 1: telefono, 2: email */
            __('Per inviare il modulo serve JavaScript. Puoi chiamarci al %1$s o scrivere a %2$s.', 'fashionshoes-child-theme'),
            $fs_contacts['phone_display'],
            $fs_contacts['email']
        )));
    ?></p></noscript>
</form>
