<?php
/**
 * Pagina di testo (Privacy e altre): titolo e contenuto della pagina, poi la chiusura e il piè di pagina.
 *
 * @package fashionshoes-child-theme
 */

defined('ABSPATH') || exit;

get_header();
?>
<main id="fs-main" class="fs-pagina">
    <div class="fs-contenitore">
        <?php while (have_posts()) : the_post(); ?>
            <article class="fs-pagina__corpo">
                <h1><?php the_title(); ?></h1>
                <div class="fs-prosa"><?php the_content(); ?></div>
            </article>
        <?php endwhile; ?>
    </div>
</main>
<?php
get_footer();
