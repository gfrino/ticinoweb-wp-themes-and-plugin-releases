<?php
/**
 * Plugin Name: IBSA Menu
 * Description: Implements a custom Menu Builder shortcode [ibsa_select_menu] for controlling grouping and pricing of specific IBSA Menus. Replaces older cart validation rules.
 * Version: 2.4.0
 * Author: ticinoWEB
 * Update URI: https://github.com/gfrino/ticinoweb-wp-themes-and-plugin-releases
 */

if (!defined('ABSPATH')) {
    exit;
}

define('IBSA_MENU_DIR', plugin_dir_path(__FILE__));
// Version of the bundled includes/tw-release-updater.php (keep in sync with its header).
define('IBSA_RELEASE_UPDATER_VERSION', '1.2.0');

/*
 * Updates from the ticinoWEB releases repo (see the Update URI header). The
 * bundled loader is generic and is also installed as a mu-plugin, so updates
 * work in Network Admin and the main site's cron too. If the mu-plugin is
 * already loaded this include is a no-op.
 */
require_once IBSA_MENU_DIR . 'includes/tw-release-updater.php';

function ibsa_install_release_updater() {
    if (!class_exists('TW_Release_Updater') || TW_Release_Updater::mu_is_current(IBSA_RELEASE_UPDATER_VERSION)) {
        return;
    }
    if (get_site_transient('ibsa_release_updater_failed')) {
        return;
    }
    $result = TW_Release_Updater::install_mu(IBSA_MENU_DIR . 'includes/tw-release-updater.php');
    if (is_wp_error($result)) {
        set_site_transient('ibsa_release_updater_failed', $result->get_error_message(), 12 * HOUR_IN_SECONDS);
    }
}
register_activation_hook(__FILE__, 'ibsa_install_release_updater');
add_action('admin_init', function () {
    if (current_user_can(is_multisite() ? 'manage_network_plugins' : 'activate_plugins')) {
        ibsa_install_release_updater();
    }
}, 20);

/**
 * Verifica se l'utente corrente è autorizzato ad usare lo switch (solo gio@ticinoweb.net)
 */
function ibsa_can_user_switch_system() {
    $current_user = wp_get_current_user();
    if (!$current_user || !$current_user->exists()) {
        return false;
    }
    return (strtolower(trim($current_user->user_email)) === 'gio@ticinoweb.net');
}

/**
 * Rileva il sistema attualmente attivo ('new' oppure 'legacy')
 */
function ibsa_get_current_active_system() {
    $saved = get_option('ibsa_active_system');
    if (!empty($saved) && in_array($saved, array('new', 'legacy'), true)) {
        return $saved;
    }
    // Rilevamento di fallback dallo stato effettivo della pagina 2343
    $edit_mode = get_post_meta(2343, '_elementor_edit_mode', true);
    return ($edit_mode === 'builder') ? 'legacy' : 'new';
}

/**
 * Restituisce il markup e gli shortcode originali del vecchio sistema
 */
function ibsa_get_legacy_post_content() {
    return '<h6>Incluso nella comanda</h6>
Pane, tovagliolo, posate, salse, condimenti, acqua minerale con o senza gas (<b>da selezionare nell\'account</b>).
<h6>Possibilità di ordinazione</h6>
<p>- 1 antipasto e 1 secondo piatto<br />- 1 secondo piatto e 1 dessert<br />- 2 antipasti</p>
<h6>Informazione importante</h6>
<p>I primi piatti sono interscambiabili con gli antipasti.<br />Il piatto del giorno e il piatto vegetariano sono considerati come secondi piatti.</p><p>Avvisiamo la gentile clientela che a partire da oggi la riservazione dei pasti potrà essere fatta unicamente tramite il portale del TALETE. Eventuali E-mail non verranno lette. Inoltre le telefonate dopo le 10:00 non saranno più possibili.<br />Ringraziandovi per la collaborazione vi attendiamo comunque numerosi con il nostro servizio.</p>
<h4>Scelta dei piatti</h4>
<h2>Menu settimanale</h2>
<h3>Piatti del giorno</h3>
[product_table id="2346" category="piatto-del-giorno"] 
<h2>Menu IBSA</h2>
<h3>Insalate e Antipasti</h3>
[product_table id="2346" category="insalate-e-antipasti"]
<h3>Primi Piatti</h3>
[product_table id="2346" category="primi-piatti"]
<h3>Secondi freddi</h3>
[product_table id="2346" category="Secondi-freddi"]
<h3>Secondi con carne</h3>
[product_table id="2346" category="Secondi-con-carne"]
<h3>Secondi con Pesce</h3>
[product_table id="2346" category="Secondi-con-Pesce"]
<h3>Vegetariano</h3>
[product_table id="2346" category="Vegetariano"]
<h3>Dessert</h3>
[product_table id="2346" category="Dessert"]
<h3>Bibite</h3>
[product_table id="2346" category="bibite"]';
}

/**
 * Esegue lo switch atomico tra Nuovo e Vecchio sistema
 */
function ibsa_switch_system($target) {
    global $wpdb;

    if ($target === 'legacy') {
        // 1. Pagina /menu-ibsa/ (ID 2343): attiva Elementor e ripristina markup a tabelle
        update_post_meta(2343, '_elementor_edit_mode', 'builder');
        wp_update_post(array(
            'ID'           => 2343,
            'post_content' => ibsa_get_legacy_post_content(),
        ));

        // 2. Pagina shop WooCommerce -> reimpostata su 2343
        update_option('woocommerce_shop_page_id', 2343);

        // 3. Snippets 6, 7, 14 -> riattivati
        $table = $wpdb->prefix . 'snippets';
        $wpdb->query("UPDATE {$table} SET active = 1 WHERE id IN (6, 7, 14)");

        // 4. Stato globale
        update_option('ibsa_active_system', 'legacy');

    } elseif ($target === 'new') {
        // 1. Pagina /menu-ibsa/ (ID 2343): disattiva Elementor builder e imposta lo shortcode del wizard
        delete_post_meta(2343, '_elementor_edit_mode');
        wp_update_post(array(
            'ID'           => 2343,
            'post_content' => '[ibsa_select_menu]',
        ));

        // 2. Pagina shop WooCommerce -> svincolata a 2299 (Shop/negozio)
        update_option('woocommerce_shop_page_id', 2299);

        // 3. Snippets 6, 7, 14 -> disattivati
        $table = $wpdb->prefix . 'snippets';
        $wpdb->query("UPDATE {$table} SET active = 0 WHERE id IN (6, 7, 14)");

        // 4. Stato globale
        update_option('ibsa_active_system', 'new');
    }

    // 5. Svuotamento cache e transient
    wp_cache_flush();
    $wpdb->query("DELETE FROM {$wpdb->prefix}options WHERE option_name LIKE '_transient_%'");
}

/**
 * Indicatore rapido nella barra di amministrazione (visibile ESCLUSIVAMENTE a gio@ticinoweb.net)
 */
add_action('admin_bar_menu', 'ibsa_admin_bar_system_status', 100);
function ibsa_admin_bar_system_status($wp_admin_bar) {
    if (!ibsa_can_user_switch_system()) {
        return;
    }
    $current = ibsa_get_current_active_system();
    $badge_color = ($current === 'new') ? '#46b450' : '#e28743';
    $label = ($current === 'new') ? 'IBSA Menu: Nuovo (Wizard)' : 'IBSA Menu: Vecchio (Tabelle)';

    $wp_admin_bar->add_node(array(
        'id'    => 'ibsa_system_toggle',
        'title' => '<span style="color:' . $badge_color . '; font-size:14px;">●</span> ' . esc_html($label),
        'href'  => admin_url('admin.php?page=ibsa_menu_settings'),
        'meta'  => array('title' => 'Gestione stato del Menu IBSA (1-Click Switch)')
    ));
}

// 1. Add Global Settings Menu
add_action('admin_menu', 'ibsa_menu_add_admin_menu');
function ibsa_menu_add_admin_menu() {
    add_submenu_page(
        'woocommerce',
        'IBSA Menu Settings',
        'IBSA Menu',
        'manage_woocommerce',
        'ibsa_menu_settings',
        'ibsa_menu_settings_page'
    );
}

function ibsa_menu_settings_page() {
    // Gestione Switch 1-Click (riservata esclusivamente a gio@ticinoweb.net)
    if (isset($_POST['ibsa_action_switch_system'])) {
        if (!ibsa_can_user_switch_system()) {
            wp_die('Accesso negato: solo l\'utente gio@ticinoweb.net ha i permessi per utilizzare questa funzione.');
        }
        check_admin_referer('ibsa_switch_system_verify');
        $target = sanitize_text_field($_POST['target_system']);
        if (in_array($target, array('new', 'legacy'), true)) {
            ibsa_switch_system($target);
            $msg = ($target === 'new') 
                ? '<strong>Nuovo Sistema (Wizard v2.1.0) ATTIVATO:</strong> prezzi dinamici (12, 16, 18 CHF), shortcode [ibsa_select_menu] attivo e vecchi snippet disattivati.' 
                : '<strong>Vecchio Sistema (Tabelle) RIPRISTINATO:</strong> Elementor attivo su /menu-ibsa/, tabelle WooCommerce e vecchie regole (Snippet 6, 7 e 14) riattivate.';
            echo '<div class="notice notice-success is-dismissible" style="padding: 12px 15px; margin-top: 15px;"><p style="font-size: 14px;">' . $msg . '</p></div>';
        }
    }

    // Salvataggio struttura menu, opzioni e regole
    if (isset($_POST['ibsa_menu_save_settings']) && check_admin_referer('ibsa_menu_settings_verify')) {
        update_option('ibsa_enable_excerpt_fix', isset($_POST['ibsa_enable_excerpt_fix']) ? 'yes' : 'no');

        // --- Struttura: menu -> portate -> categorie (l'ordine conta) ---
        if (isset($_POST['ibsa_menu']) && is_array($_POST['ibsa_menu'])) {
            $struttura = array();
            $usati = array();

            foreach ($_POST['ibsa_menu'] as $m) {
                if (!is_array($m)) {
                    continue;
                }
                $titolo = isset($m['title']) ? sanitize_text_field($m['title']) : '';
                if ($titolo === '') {
                    continue; // menu senza nome: lo ignoro invece di salvarlo rotto
                }

                // Id: quello esistente, oppure generato dal titolo per i menu nuovi.
                $id = isset($m['id']) ? sanitize_key($m['id']) : '';
                if ($id === '') {
                    $id = sanitize_key(sanitize_title($titolo));
                    if ($id === '') { $id = 'menu'; }
                }
                $base = $id; $n = 2;
                while (isset($usati[$id])) { $id = $base . '-' . $n; $n++; }
                $usati[$id] = true;

                $portate = array();
                if (isset($m['components']) && is_array($m['components'])) {
                    foreach ($m['components'] as $c) {
                        if (!is_array($c)) { continue; }
                        $label = isset($c['label']) ? sanitize_text_field($c['label']) : '';
                        if ($label === '') { continue; }
                        $cats = array();
                        if (isset($c['cats']) && is_array($c['cats'])) {
                            foreach ($c['cats'] as $slug) {
                                $slug = sanitize_key($slug);
                                if ($slug !== '' && !in_array($slug, $cats, true)) {
                                    $cats[] = $slug; // ordine di arrivo = ordine mostrato al cliente
                                }
                            }
                        }
                        $portate[] = array(
                            'label'    => $label,
                            'cats'     => $cats,
                            'optional' => !empty($c['optional']) ? 1 : 0,
                        );
                    }
                }

                $struttura[$id] = array(
                    'title'      => $titolo,
                    'price'      => isset($m['price']) ? floatval($m['price']) : 0,
                    'color'      => isset($m['color']) ? sanitize_hex_color($m['color']) : '#005f88',
                    'components' => $portate,
                );
            }

            if (!empty($struttura) && class_exists('IBSA_Menu_Builder')) {
                IBSA_Menu_Builder::salva_struttura($struttura);

                // Le vecchie opzioni prezzo restano allineate: altro codice del sito
                // (report, gateway) potrebbe ancora leggerle.
                foreach (array('light' => 'ibsa_price_light', 'soft' => 'ibsa_price_soft', 'gold' => 'ibsa_price_gold') as $k => $opt) {
                    if (isset($struttura[$k]['price'])) {
                        update_option($opt, $struttura[$k]['price']);
                    }
                }
            }
        }

        // --- Regole di esclusione SE -> ALLORA ---
        // Nota: salviamo sempre, anche un array vuoto. Se non lo facessimo,
        // get_exclusion_rules() rimetterebbe le regole predefinite e quelle
        // cancellate tornerebbero da sole al ricaricamento della pagina.
        $rules = array();
        $menu_validi = class_exists('IBSA_Menu_Builder') ? array_keys(IBSA_Menu_Builder::get_struttura()) : array();
        if (isset($_POST['ibsa_rule']) && is_array($_POST['ibsa_rule'])) {
            foreach ($_POST['ibsa_rule'] as $r) {
                if (!is_array($r)) { continue; }
                $r_if   = (isset($r['if'])   && is_array($r['if']))   ? array_values(array_filter(array_map('sanitize_key', $r['if'])))   : array();
                $r_then = (isset($r['then']) && is_array($r['then'])) ? array_values(array_filter(array_map('sanitize_key', $r['then']))) : array();
                if (empty($r_if) || empty($r_then)) { continue; }

                $r_menu    = isset($r['menu']) ? sanitize_key($r['menu']) : '';
                $r_enabled = !empty($r['enabled']) ? 1 : 0;

                // Se il menu a cui la regola era agganciata e' stato appena eliminato,
                // la regola viene disattivata e non estesa a tutti i menu: estenderla
                // cambierebbe in silenzio cosa i clienti possono ordinare.
                if ($r_menu !== '' && !in_array($r_menu, $menu_validi, true)) {
                    $r_enabled = 0;
                }

                $rules[] = array(
                    'label'   => isset($r['label']) ? sanitize_text_field($r['label']) : '',
                    'menu'    => $r_menu,
                    'if'      => $r_if,
                    'then'    => $r_then,
                    'enabled' => $r_enabled,
                );
            }
        }
        update_option('ibsa_menu_exclusions', $rules);

        echo '<div class="notice notice-success is-dismissible"><p>Impostazioni salvate con successo.</p></div>';
    }

    $current_system = ibsa_get_current_active_system();
    $excerpt_fix    = get_option('ibsa_enable_excerpt_fix', 'yes');
    $price_light    = get_option('ibsa_price_light', 12.00);
    $price_soft     = get_option('ibsa_price_soft', 16.00);
    $price_gold     = get_option('ibsa_price_gold', 18.00);
    $can_switch     = ibsa_can_user_switch_system();
    ?>
    <div class="wrap">
        <h1 style="margin-bottom: 20px;">Gestione Menu IBSA</h1>

        <!-- CARD INTERRUTTORE 1-CLICK (visibile esclusivamente a gio@ticinoweb.net) -->
        <?php if ($can_switch): ?>
        <div style="background: #ffffff; border: 1px solid #ccd0d4; border-left: 6px solid <?php echo ($current_system === 'new') ? '#46b450' : '#e28743'; ?>; box-shadow: 0 1px 3px rgba(0,0,0,0.05); padding: 25px; margin-bottom: 30px; border-radius: 4px;">
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 20px;">
                <div>
                    <h2 style="margin: 0 0 10px 0; font-size: 20px; display: flex; align-items: center; gap: 10px;">
                        <span>Interruttore Sistema Menu IBSA</span>
                        <?php if ($current_system === 'new'): ?>
                            <span style="background: #e7f6ea; color: #1e7e34; border: 1px solid #c3e6cb; padding: 3px 10px; border-radius: 20px; font-size: 13px; font-weight: 600;">🟢 NUOVO SISTEMA ATTIVO (Wizard v2.1.0)</span>
                        <?php else: ?>
                            <span style="background: #fff3cd; color: #856404; border: 1px solid #ffeeba; padding: 3px 10px; border-radius: 20px; font-size: 13px; font-weight: 600;">🟠 VECCHIO SISTEMA ATTIVO (Tabelle Prodotto)</span>
                        <?php endif; ?>
                    </h2>
                    <p style="margin: 0; color: #555; font-size: 14px; max-width: 750px; line-height: 1.5;">
                        <?php if ($current_system === 'new'): ?>
                            La pagina <a href="/menu-ibsa/" target="_blank"><strong>/menu-ibsa/</strong></a> sta usando il <strong>Nuovo Wizard a step</strong> con prezzi differenziati (Light 12 CHF, Soft 16 CHF, Gourmet 18 CHF). I vecchi Snippet 6, 7 e 14 sono disattivati.
                        <?php else: ?>
                            La pagina <a href="/menu-ibsa/" target="_blank"><strong>/menu-ibsa/</strong></a> sta usando il <strong>Vecchio Layout Elementor a Tabelle</strong>. I vecchi Snippet 6, 7 e 14 (regola fissa 15 CHF) sono attivi.
                        <?php endif; ?>
                    </p>
                </div>

                <div>
                    <form method="post" action="">
                        <?php wp_nonce_field('ibsa_switch_system_verify'); ?>
                        <?php if ($current_system === 'new'): ?>
                            <input type="hidden" name="target_system" value="legacy">
                            <button type="submit" name="ibsa_action_switch_system" class="button button-secondary" style="background: #fdf2f2; border-color: #d63638; color: #d63638; font-weight: 600; padding: 8px 18px; font-size: 14px; height: auto;" onclick="return confirm('ATTENZIONE:\nVuoi davvero ripristinare il VECCHIO SISTEMA a tabelle?\n\nVerranno riattivate le vecchie regole (Snippet 6, 7 e la fee fissa di 15 CHF) e ripristinato il layout Elementor su /menu-ibsa/.');">
                                ↺ Passa al Vecchio Sistema (Tabelle)
                            </button>
                        <?php else: ?>
                            <input type="hidden" name="target_system" value="new">
                            <button type="submit" name="ibsa_action_switch_system" class="button button-primary" style="background: #0073aa; font-weight: 600; padding: 8px 20px; font-size: 14px; height: auto;" onclick="return confirm('Vuoi attivare il NUOVO SISTEMA (Wizard Step-by-Step)?\n\nLa pagina /menu-ibsa/ mostrerà il wizard interattivo con i prezzi 12/16/18 CHF e i vecchi snippet verranno disattivati.');">
                                🚀 Passa al Nuovo Sistema (Wizard)
                            </button>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <form method="post" action="">
            <?php wp_nonce_field('ibsa_menu_settings_verify'); ?>
            <?php
            $all_cats = get_terms(array('taxonomy' => 'product_cat', 'hide_empty' => false));
            if (is_wp_error($all_cats)) { $all_cats = array(); }

            $struttura = class_exists('IBSA_Menu_Builder') ? IBSA_Menu_Builder::get_struttura() : array();
            $rules     = class_exists('IBSA_Menu_Builder') ? IBSA_Menu_Builder::get_exclusion_rules() : array();

            // Nome leggibile + quanti prodotti sono davvero utilizzabili (solo i semplici)
            $cat_names = array();
            $cat_info  = array();
            foreach ($all_cats as $c) {
                $cat_names[$c->slug] = $c->name;
                $cat_info[$c->slug]  = class_exists('IBSA_Menu_Builder')
                    ? IBSA_Menu_Builder::conta_prodotti_categoria($c->slug)
                    : array('usabili' => intval($c->count), 'esclusi' => 0);
            }

            /**
             * Griglia di spunte + striscia ordinata delle categorie scelte.
             * $base e' il prefisso del name, es. ibsa_menu[0][components][1]
             */
            if (!function_exists('ibsa_render_categorie')) {
                function ibsa_render_categorie($base, $scelte, $all_cats, $cat_info) {
                    $name = $base . '[cats][]';
                    ?>
                    <div class="ibsa-cats" data-catname="<?php echo esc_attr($name); ?>">
                        <p class="ibsa-leg">Categorie di questa portata</p>
                        <div class="ibsa-grid">
                            <?php foreach ($all_cats as $cat):
                                $on  = in_array($cat->slug, $scelte, true);
                                $inf = isset($cat_info[$cat->slug]) ? $cat_info[$cat->slug] : array('usabili'=>0,'esclusi'=>0);
                            ?>
                                <?php
                                $motivi = array();
                                if (!empty($inf['variabili']))    { $motivi[] = $inf['variabili'] . ' con varianti'; }
                                if (!empty($inf['senza_prezzo'])) { $motivi[] = $inf['senza_prezzo'] . ' senza prezzo (mettilo a 0)'; }
                                $tip = $motivi ? 'Non compaiono al cliente: ' . implode(', ', $motivi) : '';
                                ?>
                                <label class="ibsa-chk <?php echo $on ? 'on' : ''; ?>" title="<?php echo esc_attr($tip); ?>">
                                    <input type="checkbox" data-cat value="<?php echo esc_attr($cat->slug); ?>" <?php checked($on); ?>>
                                    <span><?php echo esc_html($cat->name); ?></span>
                                    <span class="cnt"><?php echo intval($inf['usabili']); ?><?php if ($inf['esclusi']): ?><em class="warn">+<?php echo intval($inf['esclusi']); ?>!</em><?php endif; ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                        <p class="ibsa-leg" style="margin-top:12px;">Ordine in cui il cliente le vede <span class="ibsa-hint">(usa le frecce)</span></p>
                        <div class="ibsa-chips">
                            <?php foreach ($scelte as $slug):
                                if (!isset($cat_info[$slug]) && !isset($GLOBALS['ibsa_dummy'])) { /* slug orfano: lo mostro comunque */ }
                            ?>
                                <span class="ibsa-chip" data-slug="<?php echo esc_attr($slug); ?>">
                                    <input type="hidden" name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr($slug); ?>">
                                    <a class="mv" onclick="ibsaMoveChip(this,-1)" title="Sposta a sinistra">◀</a>
                                    <b><?php echo esc_html(isset($GLOBALS['ibsa_cat_names'][$slug]) ? $GLOBALS['ibsa_cat_names'][$slug] : $slug); ?></b>
                                    <a class="mv" onclick="ibsaMoveChip(this,1)" title="Sposta a destra">▶</a>
                                    <a class="rm" onclick="ibsaDropChip(this)" title="Togli">✕</a>
                                </span>
                            <?php endforeach; ?>
                            <span class="ibsa-chips-empty" <?php echo $scelte ? 'style="display:none"' : ''; ?>>Nessuna categoria selezionata: questa portata verrebbe saltata.</span>
                        </div>
                    </div>
                    <?php
                }
            }
            $GLOBALS['ibsa_cat_names'] = $cat_names;

            if (!function_exists('ibsa_render_portata')) {
                function ibsa_render_portata($base, $label, $scelte, $all_cats, $cat_info, $optional = 0) {
                    ?>
                    <div class="ibsa-portata" data-portata>
                        <div class="ibsa-portata-head">
                            <span class="ibsa-drag">☰</span>
                            <span class="ibsa-pnum">Portata <b data-pnum>?</b></span>
                            <input type="text" name="<?php echo esc_attr($base); ?>[label]" value="<?php echo esc_attr($label); ?>"
                                   placeholder="Nome della portata (es. Dessert)" class="ibsa-pname">
                            <label class="ibsa-opt" title="Il cliente può saltarla. Prima di andare al carrello gli viene chiesto conferma, e il prezzo del menu non cambia.">
                                <input type="checkbox" name="<?php echo esc_attr($base); ?>[optional]" value="1" <?php checked(!empty($optional)); ?>>
                                facoltativa
                            </label>
                            <span class="spacer"></span>
                            <a class="ibsa-mini" onclick="ibsaMovePortata(this,-1)">▲ su</a>
                            <a class="ibsa-mini" onclick="ibsaMovePortata(this,1)">▼ giù</a>
                            <a class="ibsa-del" onclick="ibsaDelPortata(this)">✕ Elimina portata</a>
                        </div>
                        <?php ibsa_render_categorie($base, $scelte, $all_cats, $cat_info); ?>
                    </div>
                    <?php
                }
            }
            ?>

            <style>
                .ibsa-box{background:#fff;border:1px solid #ccd0d4;border-radius:6px;padding:20px;margin-bottom:20px;box-shadow:0 1px 2px rgba(0,0,0,.04)}
                .ibsa-help{background:#f0f6fc;border:1px solid #c5d9ed;border-left:4px solid #2271b1;border-radius:4px;padding:16px 20px;margin-bottom:22px}
                .ibsa-help h2{margin:0 0 10px;font-size:16px}
                .ibsa-help ol{margin:0 0 6px 18px;line-height:1.7;font-size:13px}
                .ibsa-help p{margin:8px 0 0;font-size:13px;color:#50575e}
                .ibsa-menu-card{border-left:5px solid #ccc}
                .ibsa-menu-head{display:flex;gap:12px;align-items:flex-end;flex-wrap:wrap;padding-bottom:14px;border-bottom:1px solid #f0f0f1;margin-bottom:6px}
                .ibsa-f{display:flex;flex-direction:column;gap:4px}
                .ibsa-f label{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:#50575e}
                .ibsa-f input[type=text]{min-width:260px}
                .ibsa-portata{border-top:1px dashed #e0e0e0;padding:14px 0 6px;margin-left:6px}
                .ibsa-portata-head{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:10px}
                .ibsa-pname{min-width:240px}
                .ibsa-pnum{font-size:12px;color:#787c82;white-space:nowrap}
                .ibsa-opt{display:inline-flex;align-items:center;gap:5px;font-size:12px;color:#50575e;background:#f6f7f7;border:1px solid #e0e0e0;border-radius:12px;padding:3px 10px;cursor:pointer;white-space:nowrap}
                .ibsa-opt:hover{background:#f0f6fc;border-color:#2271b1}
                .ibsa-opt input{margin:0}
                .ibsa-drag{color:#c3c4c7;cursor:default}
                .spacer{flex:1}
                .ibsa-mini{font-size:12px;color:#2271b1;cursor:pointer;text-decoration:none;white-space:nowrap}
                .ibsa-mini:hover{text-decoration:underline}
                .ibsa-del{color:#b32d2e;cursor:pointer;font-size:12px;text-decoration:none;white-space:nowrap}
                .ibsa-del:hover{text-decoration:underline}
                .ibsa-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(205px,1fr));gap:5px 12px}
                .ibsa-chk{display:flex;align-items:center;gap:7px;padding:5px 9px;border:1px solid #e0e0e0;border-radius:4px;cursor:pointer;background:#fafafa;font-size:13px}
                .ibsa-chk:hover{background:#f0f6fc;border-color:#2271b1}
                .ibsa-chk.on{background:#eef6ff;border-color:#2271b1}
                .ibsa-chk .cnt{color:#999;font-size:11px;margin-left:auto}
                .ibsa-chk .warn{color:#b32d2e;font-style:normal;font-weight:700;margin-left:2px}
                .ibsa-leg{font-weight:700;font-size:11px;letter-spacing:.06em;text-transform:uppercase;color:#50575e;margin:0 0 7px}
                .ibsa-hint{font-weight:400;text-transform:none;letter-spacing:0;color:#787c82}
                .ibsa-chips{display:flex;flex-wrap:wrap;gap:7px;min-height:34px;padding:8px;background:#f6f7f7;border-radius:4px}
                .ibsa-chip{display:inline-flex;align-items:center;gap:5px;background:#fff;border:1px solid #2271b1;border-radius:14px;padding:3px 9px;font-size:12px}
                .ibsa-chip b{font-weight:600}
                .ibsa-chip .mv,.ibsa-chip .rm{cursor:pointer;color:#2271b1;font-size:11px;text-decoration:none}
                .ibsa-chip .rm{color:#b32d2e;font-weight:700}
                .ibsa-chips-empty{font-size:12px;color:#996800;align-self:center}
                .ibsa-rule{border-left:4px solid #8c8f94}
                .ibsa-rule.on{border-left-color:#2271b1}
                .ibsa-rule-head{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:14px}
                .ibsa-leg .if{color:#996800}.ibsa-leg .then{color:#b32d2e}
                .ibsa-preview{background:#f6f7f7;border-left:3px solid #2271b1;padding:10px 13px;font-size:13px;line-height:1.5;border-radius:0 4px 4px 0;margin-top:12px}
                .ibsa-empty{background:#fcf9e8;border:1px solid #f0e6a6;border-radius:4px;padding:14px;font-size:13px;color:#7a6a20}
                .ibsa-addbtn{margin:4px 0 22px}
            </style>

            <div class="ibsa-help">
                <h2>Come funziona</h2>
                <ol>
                    <li>Il cliente apre <a href="/menu-ibsa/" target="_blank">/menu-ibsa/</a> e <strong>sceglie un menu</strong> fra quelli qui sotto. Il prezzo del menu è quello che paga, indipendentemente dai piatti scelti.</li>
                    <li>Poi il wizard gli fa scegliere <strong>una portata alla volta</strong>, nell'ordine in cui sono elencate qui. Per ogni portata vede i prodotti delle categorie che hai spuntato, raggruppati per categoria e nell'ordine che decidi tu.</li>
                    <li>Le <strong>regole SE → ALLORA</strong> (in fondo alla pagina) nascondono categorie negli step successivi in base a quello che ha già scelto: servono a evitare doppioni, per esempio la pasta due volte.</li>
                    <li>Alla fine aggiunge tutto al carrello. <strong>Un menu = un'ordinazione</strong>: se ne configura un altro, il precedente viene sostituito. Il carrello si svuota da solo ogni nuovo giorno.</li>
                </ol>
                <p>Una portata segnata <strong>facoltativa</strong> può essere saltata dal cliente: prima di andare al carrello gli viene chiesta conferma, e il prezzo del menu non cambia. Le altre sono obbligatorie e il wizard non avanza finché non sceglie.</p>
                <p><strong>Due cose da sapere.</strong> Il numero accanto a ogni categoria è quanti prodotti sono davvero ordinabili; se vedi <em style="color:#b32d2e;font-style:normal;font-weight:700">+n!</em> significa che <em>n</em> prodotti di quella categoria <strong>non compaiono</strong> al cliente perché non sono prodotti semplici. Una portata senza categorie viene saltata automaticamente.</p>
            </div>

            <h2>Menu, portate e categorie</h2>
            <p style="max-width:860px;">Ogni riquadro è un menu. Puoi rinominarlo, cambiarne il prezzo, aggiungere o togliere portate e decidere quali categorie di prodotti entrano in ciascuna.</p>

            <div id="ibsaMenus">
                <?php $mi = 0; foreach ($struttura as $m_id => $menu): $base = 'ibsa_menu[' . $mi . ']'; ?>
                    <div class="ibsa-box ibsa-menu-card" data-menu style="border-left-color:<?php echo esc_attr($menu['color']); ?>">
                        <input type="hidden" name="<?php echo esc_attr($base); ?>[id]" value="<?php echo esc_attr($m_id); ?>">
                        <div class="ibsa-menu-head">
                            <div class="ibsa-f">
                                <label>Nome del menu</label>
                                <input type="text" name="<?php echo esc_attr($base); ?>[title]" value="<?php echo esc_attr($menu['title']); ?>">
                            </div>
                            <div class="ibsa-f">
                                <label>Prezzo (CHF)</label>
                                <input type="number" step="0.01" min="0" name="<?php echo esc_attr($base); ?>[price]" value="<?php echo esc_attr($menu['price']); ?>" style="width:100px">
                            </div>
                            <div class="ibsa-f">
                                <label>Colore</label>
                                <input type="color" name="<?php echo esc_attr($base); ?>[color]" value="<?php echo esc_attr($menu['color']); ?>" style="width:54px;padding:2px" onchange="this.closest('[data-menu]').style.borderLeftColor=this.value">
                            </div>
                            <span class="spacer"></span>
                            <a class="ibsa-del" onclick="ibsaDelMenu(this)">✕ Elimina menu</a>
                        </div>

                        <div data-portate>
                            <?php foreach ($menu['components'] as $ci => $comp):
                                ibsa_render_portata($base . '[components][' . $ci . ']', $comp['label'], $comp['cats'], $all_cats, $cat_info, !empty($comp['optional']));
                            endforeach; ?>
                        </div>
                        <p style="margin:12px 0 0"><button type="button" class="button button-small" onclick="ibsaAddPortata(this)">+ Aggiungi portata</button></p>
                    </div>
                <?php $mi++; endforeach; ?>
            </div>

            <p class="ibsa-addbtn"><button type="button" class="button" onclick="ibsaAddMenu()">+ Aggiungi menu</button></p>

            <script type="text/template" id="ibsaTplPortata">
                <?php ibsa_render_portata('__BASE__', '', array(), $all_cats, $cat_info); ?>
            </script>
            <script type="text/template" id="ibsaTplMenu">
                <div class="ibsa-box ibsa-menu-card" data-menu style="border-left-color:#005f88">
                    <input type="hidden" name="ibsa_menu[__M__][id]" value="">
                    <div class="ibsa-menu-head">
                        <div class="ibsa-f"><label>Nome del menu</label>
                            <input type="text" name="ibsa_menu[__M__][title]" value="" placeholder="es. MENU VEGETARIANO"></div>
                        <div class="ibsa-f"><label>Prezzo (CHF)</label>
                            <input type="number" step="0.01" min="0" name="ibsa_menu[__M__][price]" value="0" style="width:100px"></div>
                        <div class="ibsa-f"><label>Colore</label>
                            <input type="color" name="ibsa_menu[__M__][color]" value="#005f88" style="width:54px;padding:2px" onchange="this.closest('[data-menu]').style.borderLeftColor=this.value"></div>
                        <span class="spacer"></span>
                        <a class="ibsa-del" onclick="ibsaDelMenu(this)">✕ Elimina menu</a>
                    </div>
                    <div data-portate></div>
                    <p style="margin:12px 0 0"><button type="button" class="button button-small" onclick="ibsaAddPortata(this)">+ Aggiungi portata</button></p>
                </div>
            </script>

            <h2 style="margin-top:30px;">Opzioni generali</h2>
            <table class="form-table ibsa-box" style="padding:6px 18px">
                <tr>
                    <th scope="row"><label for="ibsa_enable_excerpt_fix">Nascondi estratto tabelle</label></th>
                    <td>
                        <input type="checkbox" name="ibsa_enable_excerpt_fix" id="ibsa_enable_excerpt_fix" value="yes" <?php checked($excerpt_fix, 'yes'); ?>>
                        <span class="description">Nasconde il testo "Visualizzazione di 1-16" dagli estratti Product Table.</span>
                    </td>
                </tr>
            </table>

            <h2 style="margin-top:30px;">Regole di esclusione (SE → ALLORA)</h2>
            <p style="max-width:860px;">Guardano che cosa il cliente ha scelto <strong>negli step precedenti</strong> e nascondono categorie in <strong>quelli successivi</strong>.</p>

            <div id="ibsaRules">
                <?php if (empty($rules)): ?>
                    <div class="ibsa-empty" id="ibsaNoRules">Nessuna regola attiva: tutte le categorie spuntate qui sopra restano sempre disponibili.</div>
                <?php endif; ?>
                <?php foreach ($rules as $i => $rule): ?>
                    <div class="ibsa-box ibsa-rule <?php echo !empty($rule['enabled']) ? 'on' : ''; ?>" data-rule>
                        <div class="ibsa-rule-head">
                            <span style="font-weight:700">Regola <span data-num><?php echo intval($i) + 1; ?></span></span>
                            <input type="text" name="ibsa_rule[<?php echo $i; ?>][label]" value="<?php echo esc_attr($rule['label']); ?>" placeholder="Nome (facoltativo)" style="width:220px">
                            <label style="font-size:13px">Vale per:
                                <select name="ibsa_rule[<?php echo $i; ?>][menu]" data-menu>
                                    <option value="" <?php selected($rule['menu'], ''); ?>>Tutti i menu</option>
                                    <?php foreach ($struttura as $mk => $mv): ?>
                                        <option value="<?php echo esc_attr($mk); ?>" <?php selected($rule['menu'], $mk); ?>><?php echo esc_html($mv['title']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </label>
                            <label style="font-size:13px"><input type="checkbox" name="ibsa_rule[<?php echo $i; ?>][enabled]" value="1" data-enabled <?php checked(!empty($rule['enabled'])); ?>> attiva</label>
                            <span class="spacer"></span>
                            <a class="ibsa-del" onclick="ibsaDelRule(this)">✕ Elimina</a>
                        </div>
                        <p class="ibsa-leg"><span class="if">SE</span> il cliente sceglie da una di queste categorie</p>
                        <div class="ibsa-grid">
                            <?php foreach ($all_cats as $cat): ?>
                                <label class="ibsa-chk <?php echo in_array($cat->slug, $rule['if'], true) ? 'on' : ''; ?>">
                                    <input type="checkbox" data-if name="ibsa_rule[<?php echo $i; ?>][if][]" value="<?php echo esc_attr($cat->slug); ?>" <?php checked(in_array($cat->slug, $rule['if'], true)); ?>>
                                    <span><?php echo esc_html($cat->name); ?></span></label>
                            <?php endforeach; ?>
                        </div>
                        <p class="ibsa-leg" style="margin-top:14px"><span class="then">ALLORA</span> nascondi queste categorie negli step successivi</p>
                        <div class="ibsa-grid">
                            <?php foreach ($all_cats as $cat): ?>
                                <label class="ibsa-chk <?php echo in_array($cat->slug, $rule['then'], true) ? 'on' : ''; ?>">
                                    <input type="checkbox" data-then name="ibsa_rule[<?php echo $i; ?>][then][]" value="<?php echo esc_attr($cat->slug); ?>" <?php checked(in_array($cat->slug, $rule['then'], true)); ?>>
                                    <span><?php echo esc_html($cat->name); ?></span></label>
                            <?php endforeach; ?>
                        </div>
                        <div class="ibsa-preview" data-preview></div>
                    </div>
                <?php endforeach; ?>
            </div>
            <p class="ibsa-addbtn"><button type="button" class="button" onclick="ibsaAddRule()">+ Aggiungi regola</button></p>

            <script type="text/template" id="ibsaRuleTpl">
                <div class="ibsa-box ibsa-rule on" data-rule>
                    <div class="ibsa-rule-head">
                        <span style="font-weight:700">Regola <span data-num>?</span></span>
                        <input type="text" name="ibsa_rule[__I__][label]" placeholder="Nome (facoltativo)" style="width:220px">
                        <label style="font-size:13px">Vale per:
                            <select name="ibsa_rule[__I__][menu]" data-menu>
                                <option value="">Tutti i menu</option>
                                <?php foreach ($struttura as $mk => $mv): ?>
                                    <option value="<?php echo esc_attr($mk); ?>"><?php echo esc_html($mv['title']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </label>
                        <label style="font-size:13px"><input type="checkbox" name="ibsa_rule[__I__][enabled]" value="1" data-enabled checked> attiva</label>
                        <span class="spacer"></span>
                        <a class="ibsa-del" onclick="ibsaDelRule(this)">✕ Elimina</a>
                    </div>
                    <p class="ibsa-leg"><span class="if">SE</span> il cliente sceglie da una di queste categorie</p>
                    <div class="ibsa-grid">
                        <?php foreach ($all_cats as $cat): ?>
                            <label class="ibsa-chk"><input type="checkbox" data-if name="ibsa_rule[__I__][if][]" value="<?php echo esc_attr($cat->slug); ?>"><span><?php echo esc_html($cat->name); ?></span></label>
                        <?php endforeach; ?>
                    </div>
                    <p class="ibsa-leg" style="margin-top:14px"><span class="then">ALLORA</span> nascondi queste categorie negli step successivi</p>
                    <div class="ibsa-grid">
                        <?php foreach ($all_cats as $cat): ?>
                            <label class="ibsa-chk"><input type="checkbox" data-then name="ibsa_rule[__I__][then][]" value="<?php echo esc_attr($cat->slug); ?>"><span><?php echo esc_html($cat->name); ?></span></label>
                        <?php endforeach; ?>
                    </div>
                    <div class="ibsa-preview" data-preview></div>
                </div>
            </script>

            <script>
            (function(){
                var catNames = <?php echo wp_json_encode($cat_names); ?>;

                /* ---------- categorie: spunta <-> chip ordinato ---------- */
                function chipsBox(catsEl){ return catsEl.querySelector('.ibsa-chips'); }
                function syncEmpty(catsEl){
                    var box = chipsBox(catsEl);
                    var n = box.querySelectorAll('.ibsa-chip').length;
                    var e = box.querySelector('.ibsa-chips-empty');
                    if (e) { e.style.display = n ? 'none' : ''; }
                }
                function makeChip(name, slug){
                    var s = document.createElement('span');
                    s.className = 'ibsa-chip';
                    s.setAttribute('data-slug', slug);
                    s.innerHTML = '<input type="hidden" name="' + name + '" value="' + slug + '">'
                        + '<a class="mv" onclick="ibsaMoveChip(this,-1)">◀</a>'
                        + '<b>' + (catNames[slug] || slug) + '</b>'
                        + '<a class="mv" onclick="ibsaMoveChip(this,1)">▶</a>'
                        + '<a class="rm" onclick="ibsaDropChip(this)">✕</a>';
                    return s;
                }
                window.ibsaMoveChip = function(a, dir){
                    var chip = a.closest('.ibsa-chip'), box = chip.parentNode;
                    if (dir < 0 && chip.previousElementSibling && chip.previousElementSibling.classList.contains('ibsa-chip')) {
                        box.insertBefore(chip, chip.previousElementSibling);
                    } else if (dir > 0 && chip.nextElementSibling && chip.nextElementSibling.classList.contains('ibsa-chip')) {
                        box.insertBefore(chip.nextElementSibling, chip);
                    }
                };
                window.ibsaDropChip = function(a){
                    var chip = a.closest('.ibsa-chip');
                    var catsEl = chip.closest('.ibsa-cats');
                    var slug = chip.getAttribute('data-slug');
                    var cb = catsEl.querySelector('input[data-cat][value="' + slug + '"]');
                    if (cb) { cb.checked = false; cb.closest('.ibsa-chk').classList.remove('on'); }
                    chip.remove();
                    syncEmpty(catsEl);
                };
                function wireCats(catsEl){
                    var name = catsEl.getAttribute('data-catname');
                    catsEl.addEventListener('change', function(e){
                        var cb = e.target;
                        if (!cb.hasAttribute('data-cat')) { return; }
                        cb.closest('.ibsa-chk').classList.toggle('on', cb.checked);
                        var box = chipsBox(catsEl);
                        var esistente = box.querySelector('.ibsa-chip[data-slug="' + cb.value + '"]');
                        if (cb.checked && !esistente) {
                            box.insertBefore(makeChip(name, cb.value), box.querySelector('.ibsa-chips-empty'));
                        } else if (!cb.checked && esistente) {
                            esistente.remove();
                        }
                        syncEmpty(catsEl);
                    });
                    syncEmpty(catsEl);
                }

                /* ---------- portate ---------- */
                function renumberPortate(menuEl){
                    menuEl.querySelectorAll('[data-portata]').forEach(function(p, i){
                        var b = p.querySelector('[data-pnum]'); if (b) { b.textContent = i + 1; }
                    });
                }
                window.ibsaMovePortata = function(a, dir){
                    var p = a.closest('[data-portata]'), box = p.parentNode;
                    if (dir < 0 && p.previousElementSibling) { box.insertBefore(p, p.previousElementSibling); }
                    else if (dir > 0 && p.nextElementSibling) { box.insertBefore(p.nextElementSibling, p); }
                    renumberPortate(box.closest('[data-menu]'));
                };
                window.ibsaDelPortata = function(a){
                    var p = a.closest('[data-portata]'), m = p.closest('[data-menu]');
                    if (!confirm('Eliminare questa portata?')) { return; }
                    p.remove(); renumberPortate(m);
                };
                window.ibsaAddPortata = function(btn){
                    var menuEl = btn.closest('[data-menu]');
                    var box = menuEl.querySelector('[data-portate]');
                    var mIdx = menuEl.querySelector('input[name^="ibsa_menu["]').name.match(/ibsa_menu\[([^\]]+)\]/)[1];
                    var base = 'ibsa_menu[' + mIdx + '][components][' + Date.now() + ']';
                    var html = document.getElementById('ibsaTplPortata').innerHTML.split('__BASE__').join(base);
                    var w = document.createElement('div'); w.innerHTML = html.trim();
                    var el = w.firstElementChild;
                    box.appendChild(el);
                    wireCats(el.querySelector('.ibsa-cats'));
                    renumberPortate(menuEl);
                    el.querySelector('.ibsa-pname').focus();
                };

                /* ---------- menu ---------- */
                window.ibsaDelMenu = function(a){
                    var m = a.closest('[data-menu]');
                    var nome = m.querySelector('input[name$="[title]"]').value || 'questo menu';
                    if (!confirm('Eliminare "' + nome + '"?\n\nGli ordini gia fatti non vengono toccati.')) { return; }
                    m.remove();
                };
                window.ibsaAddMenu = function(){
                    var idx = Date.now();
                    var html = document.getElementById('ibsaTplMenu').innerHTML.split('__M__').join(idx);
                    var w = document.createElement('div'); w.innerHTML = html.trim();
                    var el = w.firstElementChild;
                    document.getElementById('ibsaMenus').appendChild(el);
                    el.querySelector('input[name$="[title]"]').focus();
                    el.scrollIntoView({behavior:'smooth', block:'center'});
                };

                /* ---------- regole ---------- */
                function names(l){ return l.map(function(s){ return '"' + (catNames[s] || s) + '"'; }); }
                function join(l, sep){ return l.length <= 1 ? l.join('') : l.slice(0,-1).join(', ') + ' ' + sep + ' ' + l[l.length-1]; }
                function refreshRule(card){
                    var ifs   = [].slice.call(card.querySelectorAll('input[data-if]:checked')).map(function(c){return c.value;});
                    var thens = [].slice.call(card.querySelectorAll('input[data-then]:checked')).map(function(c){return c.value;});
                    var sel = card.querySelector('[data-menu]');
                    var menuTxt = sel.value ? sel.options[sel.selectedIndex].text : 'tutti i menu';
                    var on = card.querySelector('[data-enabled]').checked;
                    var box = card.querySelector('[data-preview]');
                    card.classList.toggle('on', on);
                    if (!ifs.length || !thens.length) {
                        box.innerHTML = '<em>Regola incompleta: spunta almeno una categoria sopra e una sotto. Cosi non verra salvata.</em>';
                        return;
                    }
                    box.innerHTML = '<strong>In parole semplici:</strong> in <strong>' + menuTxt + '</strong>, se il cliente sceglie da '
                        + join(names(ifs), 'o') + ', allora non potra piu scegliere ' + join(names(thens), 'ne') + '.'
                        + (on ? '' : ' <em>(regola disattivata)</em>');
                }
                function wireRule(card){
                    card.addEventListener('change', function(e){
                        var l = e.target.closest('.ibsa-chk'); if (l) { l.classList.toggle('on', e.target.checked); }
                        refreshRule(card);
                    });
                    refreshRule(card);
                }
                function renumberRules(){
                    document.querySelectorAll('#ibsaRules [data-rule]').forEach(function(c,i){ c.querySelector('[data-num]').textContent = i+1; });
                }
                window.ibsaDelRule = function(el){ el.closest('[data-rule]').remove(); renumberRules(); };
                window.ibsaAddRule = function(){
                    var no = document.getElementById('ibsaNoRules'); if (no) { no.remove(); }
                    var idx = Date.now();
                    var html = document.getElementById('ibsaRuleTpl').innerHTML.split('__I__').join(idx);
                    var w = document.createElement('div'); w.innerHTML = html.trim();
                    var card = w.firstElementChild;
                    document.getElementById('ibsaRules').appendChild(card);
                    wireRule(card); renumberRules();
                    card.scrollIntoView({behavior:'smooth', block:'center'});
                };

                /* ---------- avvio ---------- */
                document.querySelectorAll('.ibsa-cats').forEach(wireCats);
                document.querySelectorAll('#ibsaMenus [data-menu]').forEach(renumberPortate);
                document.querySelectorAll('#ibsaRules [data-rule]').forEach(wireRule);
            })();
            </script>

            <br>
            <?php submit_button('Salva tutte le impostazioni', 'primary', 'ibsa_menu_save_settings'); ?>
        </form>
    </div>
    <?php
}

/**
 * ---------------------------------------------------------------------------
 * ASPETTO DI CARRELLO E CHECKOUT
 * Foglio di stile caricato solo dove serve, e rinomina delle etichette di
 * spedizione: qui non si spedisce niente, il cliente ritira in sede.
 * ---------------------------------------------------------------------------
 */
add_action('wp_enqueue_scripts', 'ibsa_stile_negozio', 20);
function ibsa_stile_negozio() {
    // Nessun vincolo allo switch: l'aspetto nuovo di carrello e checkout vale
    // anche col vecchio sistema (scelta di Gio).
    if (!function_exists('is_cart') || (!is_cart() && !is_checkout())) {
        return;
    }

    $file = plugin_dir_path(__FILE__) . 'assets/ibsa-shop.css';
    wp_enqueue_style(
        'ibsa-shop',
        plugin_dir_url(__FILE__) . 'assets/ibsa-shop.css',
        array(),
        file_exists($file) ? filemtime($file) : '1.0.0' // cache-busting sulla data del file
    );

    $js = plugin_dir_path(__FILE__) . 'assets/ibsa-shop.js';
    wp_enqueue_script(
        'ibsa-shop',
        plugin_dir_url(__FILE__) . 'assets/ibsa-shop.js',
        array('jquery'),
        file_exists($js) ? filemtime($js) : '1.0.0',
        true
    );
}

/**
 * "Spedizione" -> "Luogo di ritiro" nel carrello e al checkout.
 * Intervengo sull'etichetta del pacco e sulle stringhe di WooCommerce, filtrando
 * sul testo inglese originale: il sito e' in italiano, ma gettext riceve comunque
 * il msgid inglese. Limitato a carrello e checkout per non toccare il resto.
 */
add_filter('woocommerce_shipping_package_name', 'ibsa_nome_pacco_ritiro', 20);
function ibsa_nome_pacco_ritiro($nome) {
    // Vale sempre, anche col vecchio sistema: qui non si spedisce mai.
    return 'Luogo di ritiro';
}

add_filter('gettext', 'ibsa_etichette_ritiro', 20, 3);
function ibsa_etichette_ritiro($tradotto, $originale, $dominio) {
    if ($dominio !== 'woocommerce') {
        return $tradotto;
    }
    if (!function_exists('is_cart') || (!is_cart() && !is_checkout())) {
        return $tradotto;
    }


    switch ($originale) {
        case 'Shipping':
            return 'Luogo di ritiro';
        case 'Shipping to %s.':
            return 'Ritiro presso %s.';
        case 'Shipping costs are calculated during checkout.':
            return 'Il luogo di ritiro si sceglie qui sotto.';
        case 'No shipping options were found for %s.':
            return 'Nessun luogo di ritiro disponibile per %s.';
        case 'Enter a different address':
        case 'Change address':
            return 'Cambia indirizzo';
        case 'Calculate shipping':
            return 'Scegli il luogo di ritiro';
        case 'Shipping options will be updated during checkout.':
            return 'Il luogo di ritiro si conferma al momento dell\'ordine.';
        case 'Shipping options will be updated during checkout':
            return 'Il luogo di ritiro si conferma al momento dell\'ordine';
        case 'Shipping method':
            return 'Luogo di ritiro';
        case 'Free shipping':
            return 'Ritiro in sede';
        case 'Shipping address':
            return 'Indirizzo';
        case 'Ship to a different address?':
            return 'Ritirare a un indirizzo diverso?';
    }
    return $tradotto;
}

/**
 * Sposta il blocco pagamento dalla colonna stretta del riepilogo a quella larga,
 * sotto i dati di fatturazione: il form Lunch-Check (numero carta + CVC) in 420px
 * era illeggibile, mentre la colonna di sinistra restava vuota.
 *
 * Si usa lo spostamento di hook e non JavaScript perche' WooCommerce, a ogni
 * ricalcolo del checkout, sostituisce il frammento `.woocommerce-checkout-payment`
 * cercandolo per selettore: funziona ovunque si trovi nel DOM.
 */
add_action('wp', 'ibsa_sposta_pagamento_a_sinistra');
function ibsa_sposta_pagamento_a_sinistra() {
    if (!function_exists('is_checkout') || !is_checkout()) {
        return;
    }
    remove_action('woocommerce_checkout_order_review', 'woocommerce_checkout_payment', 20);
    add_action('woocommerce_checkout_after_customer_details', 'woocommerce_checkout_payment', 20);
}

/**
 * ---------------------------------------------------------------------------
 * REGOLE CARRELLO
 * Riprendono due comportamenti che stavano nello Snippet 7 (ora disattivato)
 * e li rendono parte del plugin.
 * ---------------------------------------------------------------------------
 */

/**
 * Svuota il carrello al primo caricamento di un nuovo giorno.
 * Il menu cambia ogni giorno: senza questo, le scelte di ieri resterebbero nel
 * carrello e il cliente ordinerebbe piatti non piu' in produzione.
 * Usa current_time() e non date(): conta il giorno nel fuso del sito, non quello del server.
 */
add_action('wp_loaded', 'ibsa_svuota_carrello_a_nuovo_giorno');
function ibsa_svuota_carrello_a_nuovo_giorno() {
    if (is_admin() && !wp_doing_ajax()) {
        return;
    }
    // Vale solo col nuovo sistema: se si torna al vecchio (pulsante in cima alla
    // pagina impostazioni) devono tornare in vigore gli Snippet 6/7/14 e l'aspetto
    // originale, senza residui di questo plugin.
    if (ibsa_get_current_active_system() !== 'new') {
        return;
    }

    if (!function_exists('WC') || !WC()->session) {
        return;
    }

    $oggi = current_time('Y-m-d');
    $giorno_carrello = WC()->session->get('ibsa_giorno_carrello');

    if ($giorno_carrello && $giorno_carrello !== $oggi) {
        if (WC()->cart && !WC()->cart->is_empty()) {
            WC()->cart->empty_cart();
        }
    }

    WC()->session->set('ibsa_giorno_carrello', $oggi);
}

/**
 * Ricorda il luogo di ritiro dell'ultimo ordine.
 *
 * Il luogo scelto vive solo nella sessione WooCommerce, e ogni svuotamento del
 * carrello (nuovo giorno, nuovo menu dal wizard) lo azzera: il cliente doveva
 * sceglierlo di nuovo a ogni ordine. Qui lo si salva sull'utente quando l'ordine
 * viene creato e lo si ripropone come predefinito al checkout successivo.
 * Per i clienti che hanno gia' ordinato vale il dato che WooCommerce stesso
 * conserva nella user meta `shipping_method`, quindi funziona da subito.
 * Vale con entrambi i sistemi (nuovo e legacy): anche lo Snippet 7 svuota il carrello.
 */
define('IBSA_META_LUOGO_RITIRO', 'ibsa_ultimo_luogo_ritiro');

add_action('woocommerce_checkout_order_created', 'ibsa_ricorda_luogo_ritiro', 20, 1);
add_action('woocommerce_store_api_checkout_order_processed', 'ibsa_ricorda_luogo_ritiro', 20, 1);
function ibsa_ricorda_luogo_ritiro($order) {
    if (!($order instanceof WC_Order)) {
        return;
    }
    $customer_id = (int) $order->get_customer_id();
    if ($customer_id <= 0) {
        return;
    }
    foreach ($order->get_items('shipping') as $item) {
        $rate_id = $item->get_method_id() . ':' . $item->get_instance_id();
        if ($item->get_instance_id()) {
            update_user_meta($customer_id, IBSA_META_LUOGO_RITIRO, $rate_id);
        }
        return; // un solo luogo di ritiro per ordine
    }
}

add_filter('woocommerce_shipping_chosen_method', 'ibsa_luogo_ritiro_predefinito', 20, 3);
function ibsa_luogo_ritiro_predefinito($default, $rates, $chosen_method) {
    if (!is_user_logged_in()) {
        return $default;
    }
    // Se il cliente ha gia' scelto un luogo valido in questa sessione, non si tocca.
    if ($chosen_method && isset($rates[$chosen_method])) {
        return $default;
    }

    $user_id = get_current_user_id();
    $salvato = (string) get_user_meta($user_id, IBSA_META_LUOGO_RITIRO, true);
    if ($salvato === '') {
        $legacy = get_user_meta($user_id, 'shipping_method', true);
        $salvato = is_array($legacy) && !empty($legacy[0]) ? (string) $legacy[0] : '';
    }

    // Solo se quel luogo e' ancora tra quelli disponibili.
    return ($salvato !== '' && isset($rates[$salvato])) ? $salvato : $default;
}

/**
 * Un menu = un'ordinazione.
 * Se nel carrello c'e' gia' un menu configurato col wizard, blocca qualunque
 * altra aggiunta fatta da fuori (pagine negozio, link diretti, prodotto correlato).
 * Le aggiunte del wizard stesso passano: sono marcate da $GLOBALS['ibsa_aggiunta_dal_wizard'],
 * e il wizard azzera gia' il carrello quando inizia un menu nuovo.
 */
add_filter('woocommerce_add_to_cart_validation', 'ibsa_un_solo_menu_per_ordine', 20, 3);
function ibsa_un_solo_menu_per_ordine($valid, $product_id, $quantity) {
    if (ibsa_get_current_active_system() !== 'new') {
        return $valid; // col vecchio sistema comandano gli Snippet 6 e 7
    }
    if (!empty($GLOBALS['ibsa_aggiunta_dal_wizard'])) {
        return $valid;
    }
    if (!function_exists('WC') || !WC()->cart) {
        return $valid;
    }

    foreach (WC()->cart->get_cart() as $item) {
        if (isset($item['ibsa_menu_group'])) {
            wc_add_notice(
                sprintf(
                    'Hai gia un menu nel carrello e ogni ordine puo contenerne uno solo. '
                    . 'Completa l\'ordine, oppure <a href="%s">svuota il carrello</a> per ricominciare.',
                    esc_url(wc_get_cart_url())
                ),
                'error'
            );
            return false;
        }
    }

    return $valid;
}

/**
 * I prodotti non hanno una pagina propria: si ordina solo dal menu.
 * - Nome del prodotto nel carrello, nel mini-carrello e negli ordini: testo semplice, non un link.
 * - Chi apre l'indirizzo di un prodotto (link vecchi, Google, tabella prodotti) torna alla home.
 * Restano accessibili a chi gestisce i prodotti (admin e negozianti) e, per la modifica delle
 * opzioni dal carrello, a chi arriva con la chiave di una riga che ha davvero nel carrello.
 */
add_filter('woocommerce_cart_item_permalink', '__return_empty_string', 20);
add_filter('woocommerce_order_item_permalink', '__return_empty_string', 20);

add_action('template_redirect', 'ibsa_blocca_pagina_prodotto', 1);
function ibsa_blocca_pagina_prodotto() {
    if (!function_exists('is_product') || !is_product()) {
        return;
    }
    if (current_user_can('edit_products') || current_user_can('manage_woocommerce')) {
        return;
    }
    // Modifica delle opzioni dal carrello (Product Add-Ons): serve la chiave di una riga presente.
    $chiave = isset($_GET['pao_key']) ? sanitize_text_field(wp_unslash($_GET['pao_key'])) : '';
    if ($chiave !== '' && isset($_GET['pao_edit']) && function_exists('WC') && WC()->cart && WC()->cart->get_cart_item($chiave)) {
        return;
    }
    wp_safe_redirect(home_url('/'), 302);
    exit;
}

// 2. Product Table Excerpt Fix
add_filter('wcpt_excerpt', 'ibsa_menu_wcpt_excerpt_callback');
function ibsa_menu_wcpt_excerpt_callback($content) {
    if (get_option('ibsa_enable_excerpt_fix', 'yes') !== 'yes') {
        return $content;
    }
    
    if (preg_match('/Visualizzazione di 1-16\b/', $content)) {
        return false;
    }
    if (empty($content)) {
        return false;
    }
    return $content;
}

// 3. Load Menu Builder Logic
require_once plugin_dir_path(__FILE__) . 'includes/class-ibsa-menu-builder.php';
