/**
 * Luogo di ritiro: da elenco di radio a menu a tendina.
 *
 * PERCHE': i luoghi sono 12 e in elenco allungavano il carrello di ~800px,
 * schiacciando tutto il resto.
 *
 * COME: si costruisce un <select> con lo stesso name dei radio e la classe
 * "shipping_method". WooCommerce (cart.js / checkout.js) ha gia' un handler
 * delegato su "select.shipping_method", quindi il ricalcolo del carrello parte
 * da solo: non serve simulare eventi ne' chiamare AJAX a mano.
 *
 * I radio originali vengono rimossi, non nascosti: lasciandoli nel DOM
 * verrebbero inviati anche loro e il valore finale sarebbe ambiguo.
 */
(function ($) {
    'use strict';

    function inTendina() {
        $('ul.woocommerce-shipping-methods').each(function () {
            var $ul = $(this);
            var $radio = $ul.find('input[type="radio"]');

            // Con una sola opzione il menu non serve: resta l'etichetta semplice.
            if ($radio.length < 2) { return; }

            var name = $radio.first().attr('name');

            // data-index e' indispensabile: cart.js costruisce la richiesta con
            // shipping_methods[ $(this).data('index') ]. Senza, l'indice e'
            // undefined, la scelta non viene salvata e torna quella di prima.
            var index = $radio.first().attr('data-index');
            if (typeof index === 'undefined') {
                var m = /\[(\d+)\]/.exec(name || '');
                index = m ? m[1] : 0;
            }

            var $sel = $('<select>', {
                'class': 'shipping_method ibsa-ritiro-select',
                'name': name,
                'data-index': index,
                'aria-label': 'Luogo di ritiro'
            });

            $radio.each(function () {
                var $i = $(this);
                var id = $i.attr('id');
                var testo = $ul.find('label[for="' + id + '"]').text().trim();
                if (!testo) { testo = $i.closest('li').text().trim(); }

                $('<option>', { value: $i.val(), text: testo })
                    .prop('selected', $i.is(':checked'))
                    .appendTo($sel);
            });

            $ul.replaceWith($sel);
        });
    }

    $(function () { inTendina(); });

    // WooCommerce rigenera questi blocchi a ogni ricalcolo: riconverto ogni volta.
    $(document.body).on(
        'updated_wc_div updated_cart_totals updated_checkout updated_shipping_method',
        function () { setTimeout(inTendina, 30); }
    );
})(jQuery);
