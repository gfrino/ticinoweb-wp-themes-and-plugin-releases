<?php
if (!defined('ABSPATH')) {
    exit;
}

class IBSA_Menu_Builder {

    private $menu_config = array();

    public function __construct() {
        $this->init_config();

        // Register the Piatto gourmet category dynamically on init
        add_action('init', array($this, 'register_gourmet_category'));

        add_shortcode('ibsa_select_menu', array($this, 'render_shortcode'));
        
        // Handle AJAX for loading products for a category
        add_action('wp_ajax_ibsa_get_category_products', array($this, 'ajax_get_category_products'));
        add_action('wp_ajax_nopriv_ibsa_get_category_products', array($this, 'ajax_get_category_products'));

        // Intercept cart grouping and pricing
        add_filter('woocommerce_add_cart_item_data', array($this, 'add_menu_group_data_to_cart'), 10, 3);
        add_action('woocommerce_before_calculate_totals', array($this, 'calculate_menu_group_totals'), 9999, 1);
        
        // Display cutlery in Cart/Checkout and save to order
        add_filter('woocommerce_get_item_data', array($this, 'display_cutlery_in_cart'), 10, 2);
        add_action('woocommerce_checkout_create_order_line_item', array($this, 'save_cutlery_to_order_items'), 10, 4);

        // Add scripts and styles
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
    }

    public function register_gourmet_category() {
        if (taxonomy_exists('product_cat') && !term_exists('piatto-gourmet', 'product_cat')) {
            wp_insert_term('Piatto gourmet', 'product_cat', array('slug' => 'piatto-gourmet'));
        }
    }

    private function init_config() {
        $this->menu_config = self::get_struttura();
    }

    /**
     * Struttura completa dei menu, configurabile da IBSA Menu > Impostazioni.
     *
     * Forma: array( '<id>' => array(
     *   'title' => string, 'price' => float, 'color' => '#rrggbb',
     *   'components' => array( array('label' => string, 'cats' => array di slug), ... )
     * ) )
     *
     * L'ordine dei componenti e' l'ordine delle portate nel wizard; l'ordine degli
     * slug dentro 'cats' e' l'ordine in cui le categorie appaiono al cliente.
     */
    public static function get_struttura() {
        $s = get_option('ibsa_menu_struttura', null);
        if (is_array($s) && !empty($s)) {
            return self::pulisci_struttura($s);
        }

        // Prima esecuzione: semino dai valori attuali (default storici + mappature +
        // prezzi gia' salvati), cosi' l'aggiornamento non cambia niente da solo.
        $seed = self::struttura_di_partenza();
        update_option('ibsa_menu_struttura', $seed);
        return $seed;
    }

    public static function salva_struttura($struttura) {
        update_option('ibsa_menu_struttura', self::pulisci_struttura($struttura));
    }

    /**
     * Normalizza: scarta menu senza titolo, componenti senza etichetta, slug vuoti.
     * Non scarta un componente senza categorie: puo' essere una portata appena creata
     * che l'utente sta ancora configurando.
     */
    public static function pulisci_struttura($s) {
        $out = array();
        if (!is_array($s)) {
            return $out;
        }
        foreach ($s as $id => $menu) {
            $id = sanitize_key($id);
            if ($id === '' || !is_array($menu)) {
                continue;
            }
            $title = isset($menu['title']) ? sanitize_text_field($menu['title']) : '';
            if ($title === '') {
                continue;
            }
            $color = isset($menu['color']) ? sanitize_hex_color($menu['color']) : '';
            if (!$color) {
                $color = '#005f88';
            }

            $comps = array();
            if (isset($menu['components']) && is_array($menu['components'])) {
                foreach ($menu['components'] as $c) {
                    if (!is_array($c)) {
                        continue;
                    }
                    $label = isset($c['label']) ? sanitize_text_field($c['label']) : '';
                    if ($label === '') {
                        continue;
                    }
                    $cats = array();
                    if (isset($c['cats']) && is_array($c['cats'])) {
                        foreach ($c['cats'] as $slug) {
                            $slug = sanitize_key($slug);
                            if ($slug !== '' && !in_array($slug, $cats, true)) {
                                $cats[] = $slug; // l'ordine e' significativo: non ordinare
                            }
                        }
                    }
                    // 'optional' assente = struttura salvata prima che il flag esistesse:
                    // lo deduco una volta sola dal nome, con la vecchia regola, cosi'
                    // l'aggiornamento non rende improvvisamente obbligatoria la bibita.
                    if (array_key_exists('optional', $c)) {
                        $opt = !empty($c['optional']) ? 1 : 0;
                    } else {
                        $l = function_exists('mb_strtolower') ? mb_strtolower($label) : strtolower($label);
                        $opt = (strpos($l, 'acqua') !== false || strpos($l, 'bibit') !== false) ? 1 : 0;
                    }

                    $comps[] = array('label' => $label, 'cats' => $cats, 'optional' => $opt);
                }
            }

            $out[$id] = array(
                'title'      => $title,
                'price'      => round(floatval(isset($menu['price']) ? $menu['price'] : 0), 2),
                'color'      => $color,
                'components' => array_values($comps),
            );
        }
        return $out;
    }

    /**
     * Struttura iniziale: i tre menu storici, con i prezzi e le mappature gia' in uso.
     */
    private static function struttura_di_partenza() {
        $base = array(
            'light' => array(
                'title' => 'MENU LIGHT (1 PORTATA)',
                'price' => floatval(get_option('ibsa_price_light', 12.00)),
                'color' => '#005f88',
                'components' => array(
                    array('label' => 'Portata Principale', 'cats' => array('primo-piatto', 'primi-piatti', 'insalatona', 'insalate', 'verdure-grigliate', 'verdure', 'contorni')),
                    array('label' => 'Acqua Minerale o Bibita', 'cats' => array('acqua-minerale', 'acqua', 'bibite'), 'optional' => 1),
                ),
            ),
            'soft' => array(
                'title' => 'MENU SOFT (2 PORTATE)',
                'price' => floatval(get_option('ibsa_price_soft', 16.00)),
                'color' => '#7a4545',
                'components' => array(
                    array('label' => 'Portata Principale', 'cats' => array('primo-piatto', 'primi-piatti', 'piatto-del-giorno', 'piatti-del-giorno', 'piatto-principale', 'secondi-piatti')),
                    array('label' => 'Secondo/Contorno/Dessert', 'cats' => array('insalatina', 'mezza-pasta', 'dessert')),
                    array('label' => 'Acqua Minerale o Bibita', 'cats' => array('acqua-minerale', 'acqua', 'bibite'), 'optional' => 1),
                ),
            ),
            'gold' => array(
                'title' => 'PIATTO GOURMET',
                'price' => floatval(get_option('ibsa_price_gold', 18.00)),
                'color' => '#d4af37',
                'components' => array(
                    array('label' => 'Piatto gourmet', 'cats' => array('piatto-gourmet')),
                    array('label' => 'Dessert', 'cats' => array('dessert')),
                    array('label' => 'Acqua Minerale o Bibita', 'cats' => array('acqua-minerale', 'acqua', 'bibite'), 'optional' => 1),
                ),
            ),
        );

        // Le mappature salvate vincono sui default: sono quelle in uso oggi.
        $saved = get_option('ibsa_menu_mappings');
        if (!empty($saved) && is_array($saved)) {
            foreach ($base as $m_id => &$menu) {
                if (!isset($saved[$m_id]['components'])) {
                    continue;
                }
                foreach ($menu['components'] as $c_id => &$comp) {
                    if (isset($saved[$m_id]['components'][$c_id]['cats']) && is_array($saved[$m_id]['components'][$c_id]['cats'])) {
                        $comp['cats'] = $saved[$m_id]['components'][$c_id]['cats'];
                    }
                }
                unset($comp);
            }
            unset($menu);
        }

        return self::pulisci_struttura($base);
    }

    /**
     * Quanti prodotti pubblicati di una categoria NON sono utilizzabili nel wizard
     * (variabili, raggruppati, esterni, non acquistabili). Serve all'admin per
     * segnalarli: altrimenti il gestore mappa una categoria e non capisce perche'
     * al cliente compaiono meno piatti.
     */
    public static function conta_prodotti_categoria($slug) {
        $q = new WP_Query(array(
            'post_type'      => 'product',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'no_found_rows'  => true,
            'tax_query'      => array(array('taxonomy' => 'product_cat', 'field' => 'slug', 'terms' => $slug)),
        ));
        $ok = 0; $variabili = 0; $senza_prezzo = 0;
        foreach ($q->posts as $pid) {
            $prod = wc_get_product($pid);
            if (!$prod) { continue; }
            if ($prod->get_type() !== 'simple') {
                $variabili++;
            } elseif (!$prod->is_purchasable()) {
                // Quasi sempre significa prezzo vuoto: WooCommerce rifiuta di metterlo
                // nel carrello. Qui i prodotti vanno a 0, non a prezzo vuoto.
                $senza_prezzo++;
            } else {
                $ok++;
            }
        }
        return array(
            'usabili'      => $ok,
            'esclusi'      => $variabili + $senza_prezzo,
            'variabili'    => $variabili,
            'senza_prezzo' => $senza_prezzo,
        );
    }

    public static function get_default_config() {
        return self::get_struttura();
    }

    public static function get_exclusion_rules() {
        $rules = get_option('ibsa_menu_exclusions', null);

        if ($rules === null) {
            $rules = array(
                array(
                    'label'   => 'Niente pasta due volte',
                    'menu'    => 'soft',
                    'if'      => array('primi-piatti', 'mezza-pasta'),
                    'then'    => array('mezza-pasta'),
                    'enabled' => 1,
                ),
            );
        }

        if (!is_array($rules)) {
            return array();
        }

        $menu_validi = array();
        foreach (self::get_struttura() as $mk => $mv) {
            $menu_validi[$mk] = true;
        }

        $clean = array();
        foreach ($rules as $rule) {
            if (!is_array($rule)) {
                continue;
            }
            $if   = isset($rule['if'])   && is_array($rule['if'])   ? array_values(array_filter(array_map('sanitize_key', $rule['if']))) : array();
            $then = isset($rule['then']) && is_array($rule['then']) ? array_values(array_filter(array_map('sanitize_key', $rule['then']))) : array();

            // Una regola senza condizione o senza effetto non serve a niente: la salto.
            if (empty($if) || empty($then)) {
                continue;
            }

            // La whitelist dei menu e' quella configurata, non piu' una lista fissa:
            // altrimenti una regola creata per un menu nuovo verrebbe azzerata.
            $menu = isset($rule['menu']) ? sanitize_key($rule['menu']) : '';
            $enabled = !empty($rule['enabled']) ? 1 : 0;
            if ($menu !== '' && !isset($menu_validi[$menu])) {
                // Il menu a cui era agganciata non esiste piu'. La regola viene
                // DISATTIVATA, non estesa a tutti i menu: allargarla in silenzio
                // cambierebbe cosa i clienti possono ordinare senza che nessuno lo sappia.
                $enabled = 0;
            }

            $clean[] = array(
                'label'   => isset($rule['label']) ? sanitize_text_field($rule['label']) : '',
                'menu'    => $menu,
                'if'      => $if,
                'then'    => $then,
                'enabled' => $enabled,
            );
        }

        return $clean;
    }

    public function enqueue_scripts() {
        wp_enqueue_script('jquery');
        wp_enqueue_script('wc-add-to-cart');
    }

    public function render_shortcode($atts) {
        ob_start();
        ?>
        <style>
            .ibsa-app {
                font-family: Arial, sans-serif;
                color: #333;
                background: transparent;
                border-radius: 8px;
                margin-bottom: 40px;
            }
            .ibsa-fade-in {
                animation: ibsaFadeIn 0.4s ease;
            }
            @keyframes ibsaFadeIn {
                from { opacity: 0; transform: translateY(15px); }
                to { opacity: 1; transform: translateY(0); }
            }

            /* Step 0: Choose Menu Base Grid */
            .ibsa-menu-grid {
                display: flex;
                flex-wrap: wrap;
                margin: 0 -10px;
            }
            .ibsa-menu-column {
                flex: 1 1 250px;
                padding: 10px;
                display: flex;
                flex-direction: column;
            }
            .ibsa-menu-header {
                text-align: center;
                padding: 20px;
                color: #fff;
                font-weight: bold;
                border: 1px solid rgba(255,255,255,0.2);
                margin-bottom: 0px;
                min-height: 80px;
                display: flex;
                flex-direction: column;
                justify-content: center;
                border-radius: 8px 8px 0 0;
            }
            .ibsa-menu-option {
                text-align: center;
                padding: 30px;
                color: #fff;
                border: 1px solid rgba(255,255,255,0.2);
                border-radius: 8px;
                cursor: pointer;
                transition: transform 0.2s, box-shadow 0.2s;
                white-space: pre-line;
                flex-grow: 1;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            }
            .ibsa-menu-option:hover {
                filter: brightness(1.1);
                box-shadow: inset 0 0 10px rgba(255,255,255,0.2);
            }
            .ibsa-menu-option.selected {
                border: 3px solid #4CAF50;
                filter: brightness(1.1);
            }

            /* Configurator Vertical Flow Blocks */
            .ibsa-step-block {
                background: #f9f9f9;
                border: 1px solid #eaeaea;
                border-radius: 12px;
                padding: 25px;
                margin-top: 30px;
                box-shadow: 0 4px 15px rgba(0,0,0,0.03);
            }
            .ibsa-step-header {
                text-align: center;
                margin-bottom: 25px;
            }
            .ibsa-step-header h2 {
                margin: 0 0 5px 0;
                font-size: 22px;
                color: #333;
            }
            .ibsa-btn-skip {
                margin-top: 12px;
                background: #fff;
                border: 1px solid #cbd5e1;
                color: #475569;
                padding: 9px 20px;
                border-radius: 8px;
                font-size: 14px;
                font-weight: 600;
                cursor: pointer;
                transition: all .2s ease;
            }
            .ibsa-btn-skip:hover {
                background: #f1f5f9;
                border-color: #94a3b8;
                color: #1e293b;
            }
            .ibsa-step-header p {
                color: #777;
                margin: 0;
                font-size: 14px;
            }

            /* Product Selection Grid */
            .ibsa-products {
                display: grid;
                grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
                gap: 15px;
            }
            .ibsa-product-card {
                background: #fff;
                border: 2px solid #eaeaea;
                border-radius: 12px;
                cursor: pointer;
                transition: all 0.2s ease;
                display: flex;
                align-items: center;
                padding: 15px;
            }
            .ibsa-product-card:hover {
                transform: translateY(-3px);
                border-color: #aaa;
                box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            }
            .ibsa-product-card.selected {
                border-color: #4CAF50;
                background-color: #f0fdf4;
            }
            .ibsa-icon {
                font-size: 32px;
                margin-right: 15px;
                display: flex;
                align-items: center;
                justify-content: center;
                width: 50px;
                height: 50px;
                background: #f4f4f4;
                border-radius: 50%;
                flex-shrink: 0;
            }
            .ibsa-product-card.selected .ibsa-icon {
                background: #dcfce7;
            }
            .ibsa-product-info {
                flex-grow: 1;
            }
            .ibsa-product-title {
                font-weight: bold;
                font-size: 15px;
                line-height: 1.3;
                color: #333;
            }
            .ibsa-product-desc {
                font-size: 12px;
                color: #888;
                margin-top: 4px;
            }

            /* Controls & Summary */
            .ibsa-summary-total {
                text-align: center;
                font-size: 20px;
                font-weight: bold;
                margin: 20px 0;
                color: #333;
            }
            .ibsa-btn-primary {
                display: block;
                width: 100%;
                max-width: 300px;
                margin: 0 auto;
                padding: 15px;
                background: #4CAF50;
                color: #fff;
                border: none;
                border-radius: 8px;
                cursor: pointer;
                font-weight: bold;
                font-size: 18px;
                transition: background 0.2s;
            }
            .ibsa-btn-primary:hover { background: #45a049; }

            .ibsa-loading-state {
                text-align: center;
                padding: 40px;
                color: #888;
            }
            .ibsa-loader-spinner {
                border: 4px solid #f3f3f3;
                border-top: 4px solid #4CAF50;
                border-radius: 50%;
                width: 30px;
                height: 30px;
                animation: spin 1s linear infinite;
                margin: 0 auto 10px auto;
            }
            @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }



            /* Custom Modal Styles for Confirmation */
            .ibsa-modal-overlay {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.6);
                backdrop-filter: blur(8px);
                -webkit-backdrop-filter: blur(8px);
                display: flex;
                align-items: center;
                justify-content: center;
                z-index: 999999;
                opacity: 0;
                pointer-events: none;
                transition: opacity 0.3s ease;
            }
            .ibsa-modal-overlay.active {
                opacity: 1;
                pointer-events: auto;
            }
            .ibsa-modal-content {
                background: #ffffff;
                border-radius: 16px;
                padding: 35px 30px;
                max-width: 460px;
                width: 95%;
                text-align: center;
                box-shadow: 0 20px 50px rgba(0, 0, 0, 0.3);
                transform: scale(0.85);
                transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
            }
            .ibsa-modal-overlay.active .ibsa-modal-content {
                transform: scale(1);
            }
            .ibsa-modal-icon {
                font-size: 56px;
                margin-bottom: 20px;
                display: block;
                animation: ibsaPulse 2s infinite;
            }
            @keyframes ibsaPulse {
                0% { transform: scale(1); }
                50% { transform: scale(1.08); }
                100% { transform: scale(1); }
            }
            .ibsa-modal-title {
                margin: 0 0 12px 0 !important;
                font-size: 24px !important;
                font-weight: 700 !important;
                color: #111827 !important;
                line-height: 1.2 !important;
            }
            .ibsa-modal-text {
                font-size: 16px !important;
                color: #4b5563 !important;
                margin: 0 0 28px 0 !important;
                line-height: 1.6 !important;
            }
            .ibsa-modal-buttons {
                display: flex;
                flex-direction: column;
                gap: 12px;
            }
            .ibsa-btn-modal {
                padding: 14px 24px;
                font-size: 16px;
                font-weight: 700;
                border-radius: 10px;
                cursor: pointer;
                transition: all 0.2s ease;
                border: none;
                width: 100%;
                text-align: center;
            }
            .ibsa-btn-add-water {
                background: #005f88;
                color: #ffffff;
                box-shadow: 0 4px 12px rgba(0, 95, 136, 0.2);
            }
            .ibsa-btn-add-water:hover {
                background: #004b6c;
                transform: translateY(-1px);
                box-shadow: 0 6px 16px rgba(0, 95, 136, 0.35);
            }
            .ibsa-btn-no-water {
                background: #f3f4f6;
                color: #4b5563;
                border: 1px solid #e5e7eb;
            }
            .ibsa-btn-no-water:hover {
                background: #e5e7eb;
                color: #1f2937;
                transform: translateY(-1px);
            }
        </style>

        <div class="ibsa-app" id="ibsaApp">
            
            <!-- Step 0: Choose Menu Base -->
            <div id="ibsaMenuSelector" class="ibsa-fade-in">
                <div class="ibsa-step-header" style="margin-bottom: 20px;">
                    <h2 style="text-align: left;">1. Scegli il tuo Menu</h2>
                </div>
                <div class="ibsa-menu-grid">
                    <?php foreach ($this->menu_config as $menu_id => $menu): ?>
                        <div class="ibsa-menu-column">
                            <div class="ibsa-menu-option" 
                                 style="background-color: <?php echo esc_attr($menu['color']); ?>"
                                 id="menu_opt_<?php echo esc_attr($menu_id); ?>"
                                 onclick="ibsaSelectMenu('<?php echo esc_js($menu_id); ?>')">
                                <div style="font-size: 20px; font-weight: bold; margin-bottom: 8px;"><?php echo esc_html($menu['title']); ?></div>
                                <div style="font-size: 16px;">CHF <?php echo number_format($menu['price'], 2); ?></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Dynamic Steps Container -->
            <div id="ibsaStepsStrap"></div>

            <!-- Custom Water Selection Dialog Modal -->
            <div id="ibsaWaterModal" class="ibsa-modal-overlay">
                <div class="ibsa-modal-content">
                    <span class="ibsa-modal-icon">💧⚠️</span>
                    <h3 class="ibsa-modal-title">Non hai aggiunto l'acqua</h3>
                    <p class="ibsa-modal-text">Sei sicuro di voler procedere al carrello senza acqua o bibita?<br><strong style="color: #b91c1c; display: block; margin-top: 10px;">N.B. Il prezzo del menu rimane invariato.</strong></p>
                    <div class="ibsa-modal-buttons">
                        <button type="button" class="ibsa-btn-modal ibsa-btn-add-water" onclick="ibsaModalAddWater()">Sì, voglio aggiungere l'acqua</button>
                        <button type="button" class="ibsa-btn-modal ibsa-btn-no-water" onclick="ibsaModalNoWater()">No, non la voglio</button>
                    </div>
                </div>
            </div>

        </div>

        <script>
            var ibsaConfig = <?php echo json_encode($this->menu_config); ?>;
            var ibsaExclusions = <?php echo json_encode(self::get_exclusion_rules()); ?>;
            var ibsaAjaxNonce = '<?php echo esc_js(wp_create_nonce('ibsa_ajax_nonce')); ?>';
            var state = {
                menuId: null,
                components: [], 
                selections: [], // array of product IDs matching components index
                categorySelections: [] // array of category slugs chosen in each step
            };
            var $ = jQuery;

            function ibsaEscHtml(str) {
                if (typeof str !== 'string') { str = String(str || ''); }
                return str
                    .replace(/&/g, '&amp;')
                    .replace(/</g, '&lt;')
                    .replace(/>/g, '&gt;')
                    .replace(/"/g, '&quot;')
                    .replace(/'/g, '&#039;');
            }

            function ibsaSelectMenu(menuId) {
                // Visual toggle
                $('.ibsa-menu-option').removeClass('selected');
                $('#menu_opt_' + menuId).addClass('selected');

                // Reset state
                state.menuId = menuId;
                state.components = ibsaConfig[menuId].components;
                state.selections = [];
                state.categorySelections = [];
                
                // Clear all steps below
                $('#ibsaStepsStrap').empty();
                
                // Load first component step
                loadComponentStep(0);

                // Scroll to it slightly
                setTimeout(function(){
                    $('html, body').animate({
                        scrollTop: $("#ibsaStepsStrap").offset().top - 100
                    }, 500);
                }, 100);
            }

            // Determines an emoji icon based on the component title
            function getIconFor(label) {
                var l = label.toLowerCase();
                if (l.includes('gourmet')) return '⭐';
                if (l.includes('primo') || l.includes('primi') || l.includes('pasta')) return '🍝';
                if (l.includes('insalat')) return '🥗';
                if (l.includes('verdura') || l.includes('verdure') || l.includes('grigliat')) return '🍆';
                if (l.includes('acqua') || l.includes('bibit')) return '💧';
                if (l.includes('pane')) return '🥖';
                if (l.includes('dessert')) return '🍰';
                if (l.includes('giorno')) return '🍛';
                if (l.includes('second')) return '🥩';
                return '🍽️';
            }

            // Applica le regole di esclusione alle categorie di uno step, in base a
            // quello che il cliente ha gia' scelto negli step precedenti.
            function ibsaApplyExclusions(cats, stepIndex) {
                var out = (cats || []).slice();
                if (!ibsaExclusions || !ibsaExclusions.length) {
                    return out;
                }

                var chosen = state.categorySelections.slice(0, stepIndex).filter(function(c) {
                    return !!c;
                });
                if (!chosen.length) {
                    return out;
                }

                ibsaExclusions.forEach(function(rule) {
                    if (!rule || !Number(rule.enabled)) { return; }
                    if (rule.menu && rule.menu !== state.menuId) { return; }

                    var triggered = (rule['if'] || []).some(function(slug) {
                        return chosen.indexOf(slug) !== -1;
                    });
                    if (!triggered) { return; }

                    out = out.filter(function(slug) {
                        return (rule['then'] || []).indexOf(slug) === -1;
                    });
                });

                return out;
            }

            function loadComponentStep(stepIndex) {
                if (stepIndex >= state.components.length) {
                    renderFinalSummary();
                    return;
                }

                var comp = state.components[stepIndex];
                var stepId = 'ibsa_step_' + stepIndex;
                var emoji = getIconFor(comp.label);

                // Destroy any steps that are >= this stepIndex (if user goes back to change a previous step)
                $('.ibsa-dynamic-step').each(function() {
                    if ($(this).data('step') >= stepIndex) {
                        $(this).remove();
                    }
                });
                $('#ibsaFinalSummary').remove();

                // Determine if this is the water/drink step to make it optional
                // Facoltativa o no lo dice la configurazione, non il nome della portata.
                var isOptional = !!Number(comp.optional);
                var titleText = ibsaEscHtml(comp.label);
                if (isOptional) {
                    titleText += ' (facoltativa)';
                }

                // Build container for this step
                // Una portata facoltativa va poter essere superata: si avanza solo
                // cliccando un piatto, quindi senza questo pulsante una portata
                // facoltativa in mezzo al percorso bloccherebbe il cliente.
                var sottotitolo = isOptional
                    ? "Scegli un'opzione, oppure salta questa portata."
                    : "Scegli un'opzione per continuare.";
                var skipBtn = isOptional
                    ? `<button type="button" class="ibsa-btn-skip" onclick="ibsaSkipStep(${stepIndex})">Salta questa portata →</button>`
                    : '';

                var html = `
                    <div id="${stepId}" class="ibsa-step-block ibsa-fade-in ibsa-dynamic-step" data-step="${stepIndex}">
                        <div class="ibsa-step-header">
                            <h2>${stepIndex + 2}. ${titleText}</h2>
                            <p>${sottotitolo}</p>
                            ${skipBtn}
                        </div>
                        <div id="products_container_${stepIndex}">
                            <div class="ibsa-loading-state"><div class="ibsa-loader-spinner"></div>Caricamento...</div>
                        </div>
                    </div>
                `;
                
                $('#ibsaStepsStrap').append(html);

                // If this is the water step (the last component step), also render the final summary at the bottom
                if (stepIndex === state.components.length - 1) {
                    renderFinalSummary();
                }

                // Regole di esclusione SE -> ALLORA (configurate da IBSA Menu > Impostazioni).
                // Confronto per slug esatto: piu' prevedibile del vecchio match per sottostringa.
                var catsToRequest = ibsaApplyExclusions(comp.cats, stepIndex);

                // Se le regole hanno svuotato lo step non c'e' niente da cliccare e il wizard
                // si bloccherebbe: lo salto e passo direttamente al successivo.
                if (!catsToRequest.length) {
                    $('#' + stepId).remove();
                    state.selections[stepIndex] = null;
                    state.categorySelections[stepIndex] = null;
                    loadComponentStep(stepIndex + 1);
                    return;
                }

                // Fetch Products
                $.post('<?php echo admin_url('admin-ajax.php'); ?>', {
                    action: 'ibsa_get_category_products',
                    categories: catsToRequest,
                    security: ibsaAjaxNonce
                }, function(res) {
                    if (res.success) {
                        // Nessun prodotto utilizzabile in questo step: si avanza solo
                        // cliccando un piatto, quindi lasciarlo vuoto bloccherebbe il
                        // cliente su una pagina senza uscita. Lo salto.
                        if (res.data.length === 0) {
                            $('#' + stepId).remove();
                            state.selections[stepIndex] = null;
                            state.categorySelections[stepIndex] = null;
                            loadComponentStep(stepIndex + 1);
                            return;
                        }

                        var phtml = '';
                        if (false) {
                        } else {
                            res.data.forEach(function(catGroup) {
                                // Determine emoji based on category name instead of generic step label
                                var catEmoji = getIconFor(catGroup.category_name);
                                
                                // Only show header if there are multiple categories, or always, let's always show it
                                phtml += `<h3 style="width: 100%; border-bottom: 2px solid #eaeaea; padding-bottom: 10px; margin-top: 20px; margin-bottom: 15px; font-size: 18px; color: #555;">${ibsaEscHtml(catGroup.category_name)}</h3>`;
                                phtml += `<div class="ibsa-products">`;
                                catGroup.products.forEach(function(product) {
                                    var safeName = product.name.replace(/'/g, "\\'").replace(/"/g, '&quot;');
                                    var descHtml = '';
                                    if (product.desc && product.desc.trim() !== '') {
                                        descHtml = `<div class="ibsa-product-desc">${ibsaEscHtml(product.desc)}</div>`;
                                    }
                                    
                                    // Pass both stepIndex, productId, and category_slug
                                    phtml += `
                                        <div class="ibsa-product-card ibsa-card-for-step-${stepIndex}" id="card_${stepIndex}_${product.id}" onclick="ibsaSelectProduct(${stepIndex}, ${product.id}, '${catGroup.category_slug}')">
                                            <div class="ibsa-icon">${catEmoji}</div>
                                            <div class="ibsa-product-info">
                                                <div class="ibsa-product-title">${ibsaEscHtml(product.name)}</div>
                                                ${descHtml}
                                            </div>
                                        </div>
                                    `;
                                });
                                phtml += `</div>`;
                            });
                        }
                        $('#products_container_' + stepIndex).html(phtml);
                    }
                });
            }

            // Salta una portata facoltativa: azzera la scelta e passa alla successiva.
            window.ibsaSkipStep = function(stepIndex) {
                state.selections[stepIndex] = null;
                state.categorySelections[stepIndex] = null;
                $('.ibsa-card-for-step-' + stepIndex).removeClass('selected');
                loadComponentStep(stepIndex + 1);

                setTimeout(function() {
                    var next = (stepIndex + 1 >= state.components.length)
                        ? '#ibsaFinalSummary' : '#ibsa_step_' + (stepIndex + 1);
                    if ($(next).length) {
                        $('html, body').animate({ scrollTop: $(next).offset().top - 150 }, 400);
                    }
                }, 120);
            };

            // Expose globally so inline onclick works
            window.ibsaSelectProduct = function(stepIndex, productId, catSlug) {
                var comp = state.components[stepIndex];
                var isOptional = !!Number(comp.optional);

                // Su una portata facoltativa, ricliccare il piatto gia' scelto lo toglie.
                if (isOptional && state.selections[stepIndex] === productId) {
                    $('#card_' + stepIndex + '_' + productId).removeClass('selected');
                    state.selections[stepIndex] = null;
                    state.categorySelections[stepIndex] = null;

                    // Reload next step (which is final summary) to update selections
                    loadComponentStep(stepIndex + 1);
                    return;
                }

                // Visual highlight
                $('.ibsa-card-for-step-' + stepIndex).removeClass('selected');
                $('#card_' + stepIndex + '_' + productId).addClass('selected');

                // Save selection
                state.selections[stepIndex] = productId;
                state.categorySelections[stepIndex] = catSlug;

                // Load NEXT step
                loadComponentStep(stepIndex + 1);

                // Scroll down slightly
                setTimeout(function(){
                    var nextEl = stepIndex + 1 >= state.components.length ? '#ibsaFinalSummary' : '#ibsa_step_' + (stepIndex + 1);
                    if($(nextEl).length) {
                        $('html, body').animate({
                            scrollTop: $(nextEl).offset().top - 150
                        }, 400);
                    }
                }, 100);
            };



            function renderFinalSummary() {
                var menuObj = ibsaConfig[state.menuId];
                
                $('#ibsaFinalSummary').remove();

                var html = `
                    <div id="ibsaFinalSummary" class="ibsa-step-block ibsa-fade-in" style="background: #eefdf2; border-color: #4CAF50;">
                        <div class="ibsa-step-header">
                            <h2 style="color: #2e7d32;">Hai completato il Menu!</h2>
                            <p>Aggiungi tutto al carrello con un clic.</p>
                        </div>
                        
                        <div class="ibsa-cutlery-container" style="text-align: center; margin: 15px 0 20px 0;">
                            <div style="background: #ffffff; border: 1px solid #c3e6cb; border-radius: 8px; padding: 12px 18px; display: inline-flex; align-items: center; gap: 10px; cursor: pointer; user-select: none; max-width: 320px; width: 100%; box-sizing: border-box; text-align: left;" onclick="var chk = $('#ibsaNeedCutlery'); chk.prop('checked', !chk.prop('checked')); event.stopPropagation();">
                                <input type="checkbox" id="ibsaNeedCutlery" name="ibsa_need_cutlery" style="width: 18px; height: 18px; cursor: pointer; accent-color: #4CAF50; margin: 0;" onclick="event.stopPropagation();" checked>
                                <label for="ibsaNeedCutlery" style="cursor: pointer; font-size: 15px; font-weight: 600; color: #155724; display: flex; align-items: center; gap: 6px; margin: 0; width: 100%; line-height: 1;" onclick="event.stopPropagation();">
                                    🍴 Desidero le posate
                                </label>
                            </div>
                        </div>

                        <div class="ibsa-summary-total">Totale: CHF ${menuObj.price.toFixed(2)}</div>
                        <button id="ibsaBtnAddCart" class="ibsa-btn-primary" onclick="ibsaSubmitCart()">Aggiungi al Carrello →</button>
                    </div>
                `;
                $('#ibsaStepsStrap').append(html);
            }

            // Custom Dialog Modal controls
            window.ibsaModalStep = null;

            window.openIbsaModal = function(stepIndex) {
                var modal = $('#ibsaWaterModal');
                window.ibsaModalStep = (typeof stepIndex === 'number') ? stepIndex : null;
                var nome = (window.ibsaModalStep !== null && state.components[window.ibsaModalStep])
                    ? state.components[window.ibsaModalStep].label : '';
                if (nome) {
                    modal.find('.ibsa-modal-title').text('Non hai scelto: ' + nome);
                    modal.find('.ibsa-modal-text').html(
                        'Vuoi procedere al carrello senza ' + ibsaEscHtml(nome) + '?'
                        + '<br><strong style="color:#b91c1c;display:block;margin-top:10px;">N.B. Il prezzo del menu rimane invariato.</strong>');
                    modal.find('.ibsa-btn-add-water').text('Sì, voglio sceglierlo');
                    modal.find('.ibsa-btn-no-water').text('No, procedi senza');
                }
                modal.show();
                modal[0].offsetHeight; // Trigger reflow for transition
                modal.addClass('active');
            };

            window.closeIbsaModal = function() {
                var modal = $('#ibsaWaterModal');
                modal.removeClass('active');
                setTimeout(function() {
                    modal.hide();
                }, 300);
            };

            window.ibsaModalAddWater = function() {
                closeIbsaModal();
                var idx = (window.ibsaModalStep !== null) ? window.ibsaModalStep : state.components.length - 1;
                var targetEl = $('#ibsa_step_' + idx);
                if (targetEl.length) {
                    $('html, body').animate({
                        scrollTop: targetEl.offset().top - 100
                    }, 500);
                }
            };

            window.ibsaModalNoWater = function() {
                closeIbsaModal();
                ibsaSubmitCartForce();
            };

            // Main submission trigger (intercepts checkout without water)
            window.ibsaSubmitCart = function() {
                // Chiedo conferma sulla PRIMA portata facoltativa rimasta senza scelta,
                // qualunque sia e comunque si chiami. Le portate obbligatorie non
                // arrivano qui: senza una scelta il wizard non avanza.
                for (var i = 0; i < state.components.length; i++) {
                    if (Number(state.components[i].optional) && !state.selections[i]) {
                        openIbsaModal(i);
                        return;
                    }
                }
                ibsaSubmitCartForce();
            };

            window.ibsaSubmitCartForce = function() {
                var btn = $('#ibsaBtnAddCart');
                btn.text('Caricamento...').prop('disabled', true);

                var groupId = 'ibsa_' + state.menuId + '_' + Date.now();
                var price = ibsaConfig[state.menuId].price;
                var productIds = state.selections;
                var needCutlery = $('#ibsaNeedCutlery').is(':checked') ? 'yes' : 'no';

                function addToCartRecursive(index) {
                    if (index >= productIds.length) {
                        btn.text('Aggiunto!');
                        setTimeout(function() {
                            window.location.href = '<?php echo wc_get_cart_url(); ?>';
                        }, 500);
                        return;
                    }

                    if (!productIds[index]) {
                        // Skip skipped products (e.g. water skipped)
                        addToCartRecursive(index + 1);
                        return;
                    }

                    var isFirst = (index === 0) ? 'yes' : 'no';

                    $.post('<?php echo admin_url('admin-ajax.php'); ?>', {
                        action: 'ibsa_add_to_cart_group',
                        product_id: productIds[index],
                        group_id: groupId,
                        menu_id: state.menuId,
                        is_first: isFirst,
                        need_cutlery: needCutlery,
                        security: ibsaAjaxNonce
                    }, function() {
                        addToCartRecursive(index + 1);
                    }).fail(function() {
                        alert("Errore durante l'aggiunta al carrello. Riprova.");
                        btn.text('Aggiungi al Carrello →').prop('disabled', false);
                    });
                }

                addToCartRecursive(0);
            };

        </script>
        <?php
        return ob_get_clean();
    }

    public function ajax_get_category_products() {
        check_ajax_referer('ibsa_ajax_nonce', 'security');
        $cats = isset($_POST['categories']) ? (array) $_POST['categories'] : array();
        $cats = array_map('sanitize_key', $cats);
        $result = array();
        
        foreach ($cats as $cat_slug) {
            $term = get_term_by('slug', $cat_slug, 'product_cat');
            if (!$term) continue;
            
            $args = array(
                'post_type' => 'product',
                'posts_per_page' => -1,
                'post_status' => 'publish',
                'tax_query' => array(
                    array(
                        'taxonomy' => 'product_cat',
                        'field'    => 'slug',
                        'terms'    => $cat_slug,
                    ),
                ),
            );
            
            $products = get_posts($args);

            // Solo prodotti SEMPLICI: un prodotto variabile richiede la scelta di una
            // variazione, e add_to_cart() senza variation_id la rifiuta in silenzio.
            // Mostrarlo qui significherebbe farlo sparire dal carrello senza avvisi.
            $products = array_values(array_filter($products, function($p) {
                $prod = wc_get_product($p->ID);
                return $prod && $prod->get_type() === 'simple' && $prod->is_purchasable();
            }));

            if (!empty($products)) {
                $cat_data = array(
                    'category_name' => $term->name,
                    'category_slug' => $term->slug,
                    'products' => array()
                );
                foreach ($products as $p) {
                    $desc = !empty($p->post_excerpt) ? $p->post_excerpt : $p->post_content;
                    $desc = wp_trim_words(strip_tags(strip_shortcodes($desc)), 15, '...');

                    $cat_data['products'][] = array(
                        'id' => $p->ID,
                        'name' => html_entity_decode(get_the_title($p->ID)),
                        'desc' => $desc
                    );
                }

                // Custom sort to force Monday -> Friday order, then alphabetical
                usort($cat_data['products'], function($a, $b) {
                    $days = array('lunedì'=>1, 'lunedi'=>1, 'martedì'=>2, 'martedi'=>2, 'mercoledì'=>3, 'mercoledi'=>3, 'giovedì'=>4, 'giovedi'=>4, 'venerdì'=>5, 'venerdi'=>5);
                    $a_name = strtolower($a['name']);
                    $b_name = strtolower($b['name']);
                    
                    $a_day = 99; $b_day = 99;
                    foreach ($days as $day => $val) {
                        if (strpos($a_name, $day) !== false) $a_day = min($a_day, $val);
                        if (strpos($b_name, $day) !== false) $b_day = min($b_day, $val);
                    }
                    
                    if ($a_day != $b_day) {
                        return $a_day - $b_day;
                    }
                    return strcasecmp($a_name, $b_name);
                });

                $result[] = $cat_data;
            }
        }
        
        wp_send_json_success($result);
    }
    
    public function add_menu_group_data_to_cart($cart_item_data, $product_id, $variation_id) {
        return $cart_item_data;
    }

    public function calculate_menu_group_totals($cart) {
        if (is_admin() && !defined('DOING_AJAX')) {
            return;
        }

        if (did_action('woocommerce_before_calculate_totals') >= 2) {
            return;
        }

        $groups = array();

        foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
            if (isset($cart_item['ibsa_menu_group'])) {
                $grp = $cart_item['ibsa_menu_group'];
                if (!isset($groups[$grp])) {
                    $groups[$grp] = array();
                }
                $groups[$grp][] = $cart_item_key;
            }
        }

        foreach ($groups as $grp_id => $item_keys) {
            $is_first = true;
            foreach ($item_keys as $key) {
                if ($is_first) {
                    $cart->cart_contents[$key]['data']->set_price($cart->cart_contents[$key]['ibsa_menu_price']);
                    $menu_id = $cart->cart_contents[$key]['ibsa_menu_id'];
                    // Il nome mostrato e' il titolo configurato dall'admin; se il menu e'
                    // stato nel frattempo rinominato o rimosso si ripiega sull'id.
                    $struttura_nomi = IBSA_Menu_Builder::get_struttura();
                    $display_menu_name = isset($struttura_nomi[$menu_id]['title'])
                        ? $struttura_nomi[$menu_id]['title']
                        : strtoupper($menu_id);
                    $cart->cart_contents[$key]['data']->set_name($display_menu_name . " - " . $cart->cart_contents[$key]['data']->get_name());
                    $is_first = false;
                } else {
                    $cart->cart_contents[$key]['data']->set_price(0);
                    $cart->cart_contents[$key]['data']->set_name(" ⤷ " . $cart->cart_contents[$key]['data']->get_name());
                }
            }
        }
    }

    public function display_cutlery_in_cart($item_data, $cart_item) {
        if (isset($cart_item['ibsa_need_cutlery']) && isset($cart_item['ibsa_is_first']) && $cart_item['ibsa_is_first']) {
            $item_data[] = array(
                'key'     => 'Posate',
                'name'    => 'Posate',
                'value'   => $cart_item['ibsa_need_cutlery'],
                'display' => $cart_item['ibsa_need_cutlery'],
            );
        }
        return $item_data;
    }

    public function save_cutlery_to_order_items($item, $cart_item_key, $values, $order) {
        if (isset($values['ibsa_need_cutlery']) && isset($values['ibsa_is_first']) && $values['ibsa_is_first']) {
            $item->add_meta_data('Posate', $values['ibsa_need_cutlery'], true);
        }

        $this->save_menu_data_to_order_item($item, $values);
    }

    /**
     * Salva sulla riga d'ordine i dati strutturati del menu (meta nascoste, con
     * underscore: non compaiono in admin, email o fatture). Le legge lo scontrino
     * di Star CloudPRNT per stampare cosa va consegnato: titolo del menu, poi
     * una riga per portata. Chiavi: _ibsa_menu_group, _ibsa_menu_id,
     * _ibsa_menu_title, _ibsa_is_first, _ibsa_component, _ibsa_dish.
     */
    private function save_menu_data_to_order_item($item, $values) {
        if (empty($values['ibsa_menu_group']) || empty($values['ibsa_menu_id'])) {
            return;
        }

        $menu_id   = (string) $values['ibsa_menu_id'];
        $is_first  = !empty($values['ibsa_is_first']);
        $struttura = self::get_struttura();
        $titolo    = isset($struttura[$menu_id]['title']) ? (string) $struttura[$menu_id]['title'] : strtoupper($menu_id);

        // Nome del piatto senza i prefissi aggiunti nel carrello ("Titolo - " / " ⤷ ").
        $piatto = $item->get_name();
        $piatto = preg_replace('/^\s*⤷\s*/u', '', $piatto);
        if ($is_first && strpos($piatto, $titolo . ' - ') === 0) {
            $piatto = substr($piatto, strlen($titolo . ' - '));
        }

        // Portata: la prima del menu che accetta una categoria del prodotto e non e'
        // ancora stata assegnata a un altro piatto dello stesso ordine.
        static $assegnate = array();
        $gruppo    = (string) $values['ibsa_menu_group'];
        $slugs     = array();
        foreach (wc_get_product_term_ids((int) $values['product_id'], 'product_cat') as $term_id) {
            $term = get_term($term_id, 'product_cat');
            if ($term && !is_wp_error($term)) {
                $slugs[] = $term->slug;
            }
        }
        $portata = '';
        if (!empty($struttura[$menu_id]['components'])) {
            foreach ($struttura[$menu_id]['components'] as $i => $comp) {
                if (!array_intersect($comp['cats'], $slugs)) {
                    continue;
                }
                if ($portata === '') {
                    $portata = (string) $comp['label']; // prima corrispondenza, anche se gia' usata
                }
                if (empty($assegnate[$gruppo][$i])) {
                    $assegnate[$gruppo][$i] = true;
                    $portata = (string) $comp['label'];
                    break;
                }
            }
        }

        $item->add_meta_data('_ibsa_menu_group', $gruppo, true);
        $item->add_meta_data('_ibsa_menu_id', $menu_id, true);
        $item->add_meta_data('_ibsa_menu_title', $titolo, true);
        $item->add_meta_data('_ibsa_is_first', $is_first ? 'yes' : 'no', true);
        $item->add_meta_data('_ibsa_component', $portata, true);
        $item->add_meta_data('_ibsa_dish', trim($piatto), true);
    }
}

new IBSA_Menu_Builder();

add_action('wp_ajax_ibsa_add_to_cart_group', 'ibsa_ajax_add_to_cart_group');
add_action('wp_ajax_nopriv_ibsa_add_to_cart_group', 'ibsa_ajax_add_to_cart_group');
function ibsa_ajax_add_to_cart_group() {
    // 1. Verify nonce (CSRF protection)
    check_ajax_referer('ibsa_ajax_nonce', 'security');

    $product_id = intval($_POST['product_id']);
    $group_id   = sanitize_text_field($_POST['group_id']);
    $menu_id    = sanitize_key($_POST['menu_id']);
    $is_first   = sanitize_text_field($_POST['is_first']) === 'yes';

    // 2. Whitelist menu_id: ricavata dalla struttura configurata, non piu' fissa,
    //    cosi' i menu aggiunti dall'admin funzionano senza toccare il codice.
    $struttura = IBSA_Menu_Builder::get_struttura();
    if (!isset($struttura[$menu_id])) {
        wp_send_json_error('Menu non valido.', 403);
    }

    // 3. Prezzo deciso dal server (mai dal client)
    $total_price = floatval($struttura[$menu_id]['price']);

    // 4. Validate product_id belongs to allowed menu categories
    if ($product_id <= 0) {
        wp_send_json_error('Prodotto non valido.', 400);
    }

    $allowed_cats = array();
    foreach ($struttura[$menu_id]['components'] as $comp) {
        $allowed_cats = array_merge($allowed_cats, $comp['cats']);
    }
    $allowed_cats = array_unique($allowed_cats);

    $product_term_ids = wc_get_product_term_ids($product_id, 'product_cat');
    $product_slugs    = array();
    foreach ($product_term_ids as $term_id) {
        $term = get_term($term_id, 'product_cat');
        if ($term && !is_wp_error($term)) {
            $product_slugs[] = $term->slug;
        }
    }

    if (empty(array_intersect($allowed_cats, $product_slugs))) {
        wp_send_json_error('Prodotto non valido per questo menu.', 403);
    }

    // 5. Add to cart
    $need_cutlery = isset($_POST['need_cutlery']) && $_POST['need_cutlery'] === 'yes' ? 'Sì' : 'No';
    
    $cart_item_data = array(
        'ibsa_menu_group'   => $group_id,
        'ibsa_menu_id'      => $menu_id,
        'ibsa_menu_price'   => $total_price,
        'ibsa_is_first'     => $is_first,
        'ibsa_need_cutlery' => $need_cutlery,
    );
    // Un menu = un'ordinazione. Quando parte un nuovo menu (primo elemento del gruppo)
    // il carrello viene azzerato: cosi' non possono convivere due configurazioni nello
    // stesso ordine, ne' restare i pezzi di un menu abbandonato a meta'.
    if ($is_first && WC()->cart && !WC()->cart->is_empty()) {
        WC()->cart->empty_cart();
    }

    // Segnala al filtro di validazione che questa aggiunta arriva dal wizard, altrimenti
    // bloccherebbe gli elementi dal secondo in poi dello stesso menu.
    $GLOBALS['ibsa_aggiunta_dal_wizard'] = true;
    WC()->cart->add_to_cart($product_id, 1, 0, array(), $cart_item_data);
    unset($GLOBALS['ibsa_aggiunta_dal_wizard']);

    wp_send_json_success();
}
