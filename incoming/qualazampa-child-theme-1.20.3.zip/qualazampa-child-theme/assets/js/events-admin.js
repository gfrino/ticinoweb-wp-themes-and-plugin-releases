(() => {
  'use strict';
  const start = document.querySelector('#qz-event-start_date');
  const end = document.querySelector('#qz-event-end_date');
  const output = document.querySelector('[data-event-date-preview]');
  if (!start || !end || !output) return;
  const time = key => document.querySelector('#qz-event-' + key)?.value || '';
  const format = value => {
    const [y, m, d] = value.split('-').map(Number);
    return new Intl.DateTimeFormat(document.documentElement.lang || 'it', {day:'numeric',month:'long',year:'numeric'}).format(new Date(y,m-1,d));
  };
  function update() {
    end.min = start.value;
    if (!start.value) { output.textContent = qzEventsAdmin.empty; return; }
    if (end.value && end.value < start.value) { output.textContent = qzEventsAdmin.invalid; return; }
    const from = time('start_time'), until = time('end_time');
    output.textContent = format(start.value) + (end.value && end.value !== start.value ? ' – ' + format(end.value) : '') + (from ? ' · ' + from + (until ? ' – ' + until : '') : '');
  }
  document.querySelectorAll('#qz-event-details input').forEach(input => input.addEventListener('input', update));
  update();
})();
