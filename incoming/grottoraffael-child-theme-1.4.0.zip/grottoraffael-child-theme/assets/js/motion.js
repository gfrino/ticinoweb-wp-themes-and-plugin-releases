/**
 * Grotto Raffael: movimento con GSAP (incluso nel tema, assets/vendor/gsap).
 * - header che si stringe e prende ombra quando si scorre (anche senza GSAP);
 * - entrata del titolo in home;
 * - sezioni che compaiono morbide mentre si scorre, a gruppi in sequenza;
 * - parallasse sulle foto grandi (home, fasce delle pagine, «qualità», recensione su foto).
 * Con «riduci movimento» attivo nel sistema non si anima nulla. Senza JavaScript tutto è visibile:
 * gli stati iniziali li mette GSAP, non il CSS.
 */
(function () {
  'use strict';

  var header = document.querySelector('.gr-header');
  if (header) {
    var onScroll = function () { header.classList.toggle('is-scrolled', window.scrollY > 10); };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduce || !window.gsap || !window.ScrollTrigger) {
    return;
  }
  var gsap = window.gsap;
  gsap.registerPlugin(window.ScrollTrigger);
  document.documentElement.classList.add('gr-motion');

  /* Home: titolo e pulsante entrano dal basso */
  var heroText = document.querySelector('.gr-hero__text');
  if (heroText) {
    gsap.from(heroText.children, { y: 40, opacity: 0, duration: 1.1, ease: 'power3.out', stagger: 0.18, delay: 0.15 });
  }
  var bannerTitle = document.querySelector('.gr-banner__title');
  if (bannerTitle) {
    gsap.from(bannerTitle, { y: 24, opacity: 0, duration: 1, ease: 'power3.out', delay: 0.1 });
  }

  /* Comparsa morbida delle sezioni, a gruppi: ogni gruppo entra in sequenza quando arriva in vista */
  var groups = [
    '.gr-split__text > *',
    '.gr-quality__text > *',
    '.gr-head > *',
    '.gr-story .gr-wrap > *',
    '.gr-reviews__head > *',
    '.gr-miniature .gr-wrap > *:not(.gr-gallery)',
    '.gr-contact__grid > div > *',
    '.gr-events .gr-wrap > *',
    '.gr-voucher__info > *',
    '.gr-banquets__intro',
    '.gr-cta__inner > *'
  ];
  groups.forEach(function (selector) {
    document.querySelectorAll(selector).forEach(function (el) {
      gsap.from(el, {
        y: 28, opacity: 0, duration: 0.9, ease: 'power2.out',
        scrollTrigger: { trigger: el, start: 'top 88%', once: true }
      });
    });
  });

  var batches = [
    ['.gr-split__media', { y: 40, scale: 0.98 }],
    ['.gr-logos__row a', { y: 20 }],
    ['.gr-menu-list li', { x: -24 }],
    ['.gr-photos img', { y: 40 }],
    ['.gr-review', { y: 40 }],
    ['.gr-gallery__item', { y: 24, scale: 0.97 }],
    ['.gr-row', { y: 40 }],
    ['.gr-hours', { y: 30 }],
    ['.gr-dishes__image', { y: 40 }]
  ];
  batches.forEach(function (b) {
    var items = document.querySelectorAll(b[0]);
    if (!items.length) return;
    gsap.set(items, Object.assign({ opacity: 0 }, b[1]));
    window.ScrollTrigger.batch(items, {
      start: 'top 90%',
      once: true,
      onEnter: function (batch) {
        gsap.to(batch, { opacity: 1, x: 0, y: 0, scale: 1, duration: 0.85, ease: 'power2.out', stagger: 0.09, overwrite: true });
      }
    });
  });

  /* Parallasse: la foto si sposta più piano della pagina */
  var parallax = [
    ['.gr-hero__slides', '.gr-hero', 14],
    ['.gr-banner__image', '.gr-banner', 18],
    ['.gr-quote__bg', '.gr-quote', 18]
  ];
  if (window.matchMedia('(min-width: 768px)').matches) {
    parallax.push(['.gr-quality__image', '.gr-quality', 12]);
  }
  parallax.forEach(function (p) {
    document.querySelectorAll(p[0]).forEach(function (el) {
      var box = el.closest(p[1]) || el.parentNode;
      gsap.fromTo(el, { yPercent: -p[2] / 2 }, {
        yPercent: p[2] / 2, ease: 'none',
        scrollTrigger: { trigger: box, start: 'top bottom', end: 'bottom top', scrub: true }
      });
    });
  });

  /* Le foto caricate «lazy» cambiano le altezze: ricalcola i punti di partenza a pagina caricata */
  window.addEventListener('load', function () { window.ScrollTrigger.refresh(); });
})();
