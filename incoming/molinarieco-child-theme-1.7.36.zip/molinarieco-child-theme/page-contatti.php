<?php
/** Contact page: page copy stays in the editor; contact data comes from the parent CMS. */
get_header();

$phone   = trim( (string) get_option( 'ticinoweb_contact_phone' ) );
$email   = trim( (string) get_option( 'ticinoweb_contact_email' ) );
$address = trim( (string) get_option( 'ticinoweb_contact_address' ) );
$hours   = molinarieco_opening_hours_label();
$map_url = trim( (string) get_option( 'ticinoweb_contact_map_url' ) );
$tel_url = $phone ? 'tel:' . preg_replace( '/[^+0-9]/', '', $phone ) : '';
$map_embed_url = $address ? 'https://maps.google.com/maps?q=' . rawurlencode( $address ) . '&t=m&z=13&output=embed&iwloc=near' : '';
?>
<main id="main" class="mol-content mol-content--contact">
	<?php while ( have_posts() ) : the_post(); ?>
		<?php
		// The editor owns the welcome copy and vehicle list. Move the list into the approved layout.
		$editor_html = apply_filters( 'the_content', get_the_content() );
		$intro_html  = $editor_html;
		$vehicles    = array();
		$document    = new DOMDocument();
		$previous    = libxml_use_internal_errors( true );
		$loaded      = $document->loadHTML( '<?xml encoding="utf-8" ?><div id="mol-contact-editor">' . $editor_html . '</div>', LIBXML_NONET );
		libxml_clear_errors();
		libxml_use_internal_errors( $previous );

		if ( $loaded ) {
			$xpath = new DOMXPath( $document );
			$root  = $xpath->query( '//*[@id="mol-contact-editor"]' )->item( 0 );
			if ( $root ) {
				foreach ( $xpath->query( './/ul[contains(concat(" ", normalize-space(@class), " "), " mol-vehicle-list ")]', $root ) as $list ) {
					foreach ( $xpath->query( './li', $list ) as $item ) {
						$label = trim( $item->textContent );
						if ( $label ) {
							$vehicles[] = $label;
						}
					}
					$list->parentNode->removeChild( $list );
				}
				$intro_html = '';
				foreach ( $root->childNodes as $node ) {
					$intro_html .= $document->saveHTML( $node );
				}
			}
		}
		?>
		<article <?php post_class( 'mol-contact-page' ); ?>>
			<div class="mol-contact-hero">
				<figure class="mol-contact-photo">
					<?php if ( has_post_thumbnail() ) : ?>
						<?php echo wp_get_attachment_image( get_post_thumbnail_id(), 'large', false, array( 'loading' => 'eager', 'fetchpriority' => 'high', 'sizes' => '(max-width: 760px) 100vw, 55vw' ) ); ?>
					<?php endif; ?>
					<figcaption><?php echo esc_html( get_bloginfo( 'name' ) ); ?></figcaption>
				</figure>
				<div class="mol-contact-intro">
					<h1><?php the_title(); ?></h1>
					<?php if ( trim( wp_strip_all_tags( $intro_html ) ) ) : ?>
						<div class="mol-contact-welcome entry-content"><?php echo wp_kses_post( $intro_html ); ?></div>
					<?php endif; ?>
					<?php if ( $address || $phone || $email ) : ?>
						<dl class="mol-contact-details">
							<?php if ( $address ) : ?><div><dt><?php esc_html_e( 'Dove', 'molinarieco-child-theme' ); ?></dt><dd><?php echo esc_html( $address ); ?></dd></div><?php endif; ?>
							<?php if ( $phone ) : ?><div><dt><?php esc_html_e( 'Telefono', 'molinarieco-child-theme' ); ?></dt><dd><a href="<?php echo esc_url( $tel_url ); ?>"><?php echo esc_html( $phone ); ?></a></dd></div><?php endif; ?>
							<?php if ( $email ) : ?><div><dt><?php esc_html_e( 'Email', 'molinarieco-child-theme' ); ?></dt><dd><a href="<?php echo esc_url( 'mailto:' . $email ); ?>"><?php echo esc_html( $email ); ?></a></dd></div><?php endif; ?>
						</dl>
					<?php endif; ?>
					<?php if ( $map_url || $phone ) : ?>
						<div class="mol-contact-actions">
							<?php if ( $map_url ) : ?><a class="mol-contact-action" href="<?php echo esc_url( $map_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Indicazioni stradali', 'molinarieco-child-theme' ); ?></a><?php endif; ?>
							<?php if ( $phone ) : ?><a class="mol-contact-text-link mol-contact-call" href="<?php echo esc_url( $tel_url ); ?>"><?php esc_html_e( 'Chiama ora', 'molinarieco-child-theme' ); ?><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M7.3 3.5H4.8A1.8 1.8 0 0 0 3 5.4C3.5 14 10 20.5 18.6 21a1.8 1.8 0 0 0 1.9-1.8v-2.5l-4.4-1.1-2 2a14.7 14.7 0 0 1-6.7-6.7l2-2-1.1-4.4Z"/></svg></a><?php endif; ?>
						</div>
					<?php endif; ?>
				</div>
			</div>

			<?php if ( $vehicles ) : ?>
				<section class="mol-contact-vehicles" aria-label="<?php esc_attr_e( 'Veicoli', 'molinarieco-child-theme' ); ?>">
					<h2><?php esc_html_e( 'Lavoriamo su', 'molinarieco-child-theme' ); ?></h2>
					<ul>
						<?php foreach ( $vehicles as $vehicle ) : ?>
							<li>
								<?php if ( 'automobili' === sanitize_title( $vehicle ) ) : ?>
									<svg viewBox="0 0 48 48" aria-hidden="true" focusable="false"><path d="M8 29h32l-3-10a5 5 0 0 0-5-4H16a5 5 0 0 0-5 4L8 29Z"/><path d="M8 29v8h5m27-8v8h-5M8 24l-3-2m35 2 3-2M15 36h18"/><circle cx="14" cy="30" r="2"/><circle cx="34" cy="30" r="2"/></svg>
								<?php elseif ( 'camion' === sanitize_title( $vehicle ) ) : ?>
									<svg viewBox="0 0 48 48" aria-hidden="true" focusable="false"><path d="M5 13h25v22H5zM30 21h8l5 7v7H30zM30 28h12"/><circle cx="13" cy="36" r="4"/><circle cx="36" cy="36" r="4"/></svg>
								<?php elseif ( 'bus' === sanitize_title( $vehicle ) ) : ?>
									<svg viewBox="0 0 48 48" aria-hidden="true" focusable="false"><rect x="10" y="6" width="28" height="34" rx="5"/><path d="M10 25h28M15 12h18M15 31h2m14 0h2M17 40v3m14-3v3"/></svg>
								<?php endif; ?>
								<span><?php echo esc_html( $vehicle ); ?></span>
							</li>
						<?php endforeach; ?>
					</ul>
				</section>
			<?php endif; ?>

			<?php if ( $address || $map_url ) : ?>
				<section class="mol-contact-location<?php echo $map_embed_url ? '' : ' mol-contact-location--no-map'; ?>" aria-labelledby="mol-location-heading">
					<div class="mol-contact-location-copy">
						<h2 id="mol-location-heading"><?php esc_html_e( 'Dove siamo', 'molinarieco-child-theme' ); ?></h2>
						<?php if ( $address ) : ?><p class="mol-contact-location-address"><?php echo esc_html( $address ); ?></p><?php endif; ?>
						<?php if ( $hours ) : ?><p class="mol-contact-hours"><?php echo esc_html( $hours ); ?></p><?php endif; ?>
						<?php if ( $map_url ) : ?><a class="mol-contact-text-link mol-contact-map-link" href="<?php echo esc_url( $map_url ); ?>" target="_blank" rel="noopener noreferrer"><span><?php esc_html_e( 'Apri la mappa', 'molinarieco-child-theme' ); ?></span><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M4 12h16m-6-6 6 6-6 6"/></svg></a><?php endif; ?>
					</div>
					<?php if ( $map_embed_url ) : ?>
						<div class="mol-contact-map-preview" data-map-src="<?php echo esc_url( $map_embed_url ); ?>" data-map-title="<?php echo esc_attr( sprintf( __( 'Mappa interattiva: %s', 'molinarieco-child-theme' ), $address ) ); ?>">
							<div class="mol-contact-map-consent">
								<div class="mol-contact-map-card">
									<span class="mol-contact-map-place"><?php esc_html_e( 'La nostra sede', 'molinarieco-child-theme' ); ?></span>
									<strong><?php echo esc_html( get_bloginfo( 'name' ) ); ?></strong>
									<span class="mol-contact-map-address"><?php echo esc_html( $address ); ?></span>
									<a class="mol-button mol-contact-map-activate" href="<?php echo esc_url( $map_url ?: $map_embed_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Mostra la mappa', 'molinarieco-child-theme' ); ?></a>
									<span class="mol-contact-map-note"><?php esc_html_e( 'La mappa di Google si carica dopo il clic.', 'molinarieco-child-theme' ); ?></span>
								</div>
							</div>
						</div>
					<?php endif; ?>
				</section>
			<?php endif; ?>
		</article>
	<?php endwhile; ?>
</main>
<?php get_footer(); ?>
