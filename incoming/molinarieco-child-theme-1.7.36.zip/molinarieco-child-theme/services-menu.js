(() => {
  const desktop = window.matchMedia('(min-width: 761px)');
  const triggers = document.querySelectorAll('.mol-header-menu .mol-services-trigger');
  if (!triggers.length) return;

  document.documentElement.classList.add('mol-menu-ready');
  triggers.forEach((button, index) => {
    const item = button.parentElement;
    const submenu = item.querySelector(':scope > .sub-menu');
    if (!submenu) return;

    submenu.id = `mol-services-submenu-${index + 1}`;
    button.setAttribute('aria-controls', submenu.id);

    const setOpen = (open) => {
      item.classList.toggle('is-open', open);
      button.setAttribute('aria-expanded', String(open));
    };

    button.addEventListener('click', () => {
      setOpen(desktop.matches || !item.classList.contains('is-open'));
    });
    item.addEventListener('mouseenter', () => {
      if (desktop.matches) setOpen(true);
    });
    item.addEventListener('mouseleave', () => {
      if (desktop.matches && !item.contains(document.activeElement)) setOpen(false);
    });
    item.addEventListener('focusin', () => {
      if (desktop.matches) setOpen(true);
    });
    item.addEventListener('focusout', (event) => {
      if (!item.contains(event.relatedTarget)) setOpen(false);
    });
    item.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') {
        button.focus();
        setOpen(false);
      }
    });
    document.addEventListener('click', (event) => {
      if (!item.contains(event.target)) setOpen(false);
    });
    item.closest('details')?.addEventListener('toggle', (event) => {
      if (!event.target.open) setOpen(false);
    });
  });
})();
