<?php
/** Standard content page. */
get_header();
$is_about = is_page( 'chi-siamo' );
?>
<main id="main" class="mol-content<?php echo is_page( 'servizi' ) ? ' mol-content--services' : ''; ?><?php echo $is_about ? ' mol-content--about' : ''; ?>">
<?php while ( have_posts() ) : the_post(); ?>
<article <?php post_class(); ?>><?php if ( ! $is_about ) : ?><h1><?php the_title(); ?></h1><?php endif; ?><div class="entry-content"><?php the_content(); ?></div></article>
<?php endwhile; ?>
</main>
<?php get_footer(); ?>
