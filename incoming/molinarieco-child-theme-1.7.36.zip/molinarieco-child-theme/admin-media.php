<?php
/** Media controls inside the existing ticinoWEB CMS screen. */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/** Pages whose images are managed by this child, without duplicating their storage. */
function mol_cms_media_pages() {
    $pages = array();
    $front = (int) get_option( 'page_on_front' );
    if ( $front ) {
        $pages['home'] = array( 'id' => $front, 'label' => __( 'Home', 'molinarieco-child-theme' ), 'kind' => 'home' );
    }
    $services = get_page_by_path( 'servizi' );
    if ( $services ) {
        foreach ( get_pages( array( 'parent' => $services->ID, 'sort_column' => 'menu_order', 'post_status' => 'publish' ) ) as $page ) {
            $pages[ 'service-' . $page->ID ] = array( 'id' => $page->ID, 'label' => get_the_title( $page ), 'kind' => 'service' );
        }
    }
    foreach ( array( 'chi-siamo' => 'history', 'il-nostro-impegno' => 'featured', 'contatti' => 'featured' ) as $slug => $kind ) {
        $page = get_page_by_path( $slug );
        if ( $page ) {
            $pages[ $slug ] = array( 'id' => $page->ID, 'label' => get_the_title( $page ), 'kind' => $kind );
        }
    }
    return $pages;
}

/** The home and history photos live in page content, so read those images in document order. */
function mol_cms_content_image_ids( $page_id ) {
    $post = get_post( $page_id );
    if ( ! $post || ! preg_match_all( '/<img\b[^>]*\bsrc=["\']([^"\']+)["\'][^>]*>/i', $post->post_content, $matches ) ) {
        return array();
    }
    return array_map( static function ( $url ) {
        $id = attachment_url_to_postid( $url );
        if ( ! $id ) {
            $original = preg_replace( '/-\d+x\d+(?=\.[a-z0-9]+$)/i', '', $url );
            $id = attachment_url_to_postid( $original );
        }
        return (int) $id;
    }, $matches[1] );
}

function mol_cms_gallery_ids( $term_id ) {
    $ids = get_posts( array(
        'post_type' => 'attachment', 'post_status' => 'inherit', 'post_mime_type' => 'image',
        'posts_per_page' => 30, 'fields' => 'ids',
        'tax_query' => array( array( 'taxonomy' => 'ticinoweb_media_gallery', 'field' => 'term_id', 'terms' => $term_id ) ),
    ) );
    $order = array_map( 'intval', (array) get_term_meta( $term_id, '_ticinoweb_gallery_order', true ) );
    $positions = array_flip( $order );
    usort( $ids, static function ( $a, $b ) use ( $positions ) {
        return ( $positions[ $a ] ?? PHP_INT_MAX ) <=> ( $positions[ $b ] ?? PHP_INT_MAX ) ?: $a <=> $b;
    } );
    return $ids;
}

function mol_cms_media_attachment( $id ) {
    $post = get_post( $id );
    if ( ! $post || 'attachment' !== $post->post_type ) {
        return null;
    }
    $image = wp_get_attachment_image_src( $id, 'medium_large' );
    return array(
        'id' => (int) $id,
        'url' => $image ? $image[0] : '',
        'width' => $image ? (int) $image[1] : 0,
        'height' => $image ? (int) $image[2] : 0,
        'title' => wp_specialchars_decode( get_the_title( $id ), ENT_QUOTES ),
    );
}

function mol_cms_media_data() {
    $data = array();
    foreach ( mol_cms_media_pages() as $key => $entry ) {
        $id = $entry['id'];
        $item = $entry;
        $item['featured'] = get_post_thumbnail_id( $id );
        if ( 'home' === $entry['kind'] ) {
            $item['video'] = (int) get_post_meta( $id, 'mol_hero_video_id', true );
            $item['images'] = mol_cms_content_image_ids( $id );
        } elseif ( 'history' === $entry['kind'] ) {
            $item['images'] = mol_cms_content_image_ids( $id );
        } elseif ( 'service' === $entry['kind'] ) {
            $slug = sanitize_title( (string) get_post_meta( $id, 'mol_service_gallery_slug', true ) );
            $term = $slug ? get_term_by( 'slug', $slug, 'ticinoweb_media_gallery' ) : false;
            $item['gallery_term'] = $term ? (int) $term->term_id : 0;
            $item['gallery'] = $term ? mol_cms_gallery_ids( $term->term_id ) : array();
        }
        $data[ $key ] = $item;
    }
    return $data;
}

add_action( 'admin_enqueue_scripts', function ( $hook ) {
    if ( 'toplevel_page_ticinoweb-cms' !== $hook || ! current_user_can( 'edit_pages' ) ) {
        return;
    }
    wp_enqueue_media();
    $version = wp_get_theme()->get( 'Version' );
    wp_enqueue_style( 'mol-cms-media', get_stylesheet_directory_uri() . '/admin-media.css', array(), $version );
    wp_enqueue_script( 'mol-cms-media', get_stylesheet_directory_uri() . '/admin-media.js', array( 'jquery', 'media-views' ), $version, true );
    $pages = mol_cms_media_data();
    $attachment_ids = array();
    foreach ( $pages as $page ) {
        $attachment_ids = array_merge( $attachment_ids, array( $page['featured'] ), $page['images'] ?? array(), $page['gallery'] ?? array(), array( $page['video'] ?? 0 ) );
    }
    $attachments = array();
    foreach ( array_unique( array_filter( array_map( 'intval', $attachment_ids ) ) ) as $id ) {
        $attachments[ $id ] = mol_cms_media_attachment( $id );
    }
    wp_add_inline_script( 'mol-cms-media', 'window.molCmsMedia=' . wp_json_encode( array(
        'pages' => $pages,
        'attachments' => $attachments,
        'ajaxUrl' => admin_url( 'admin-ajax.php' ),
        'nonce' => wp_create_nonce( 'mol_cms_media_save' ),
        'labels' => array(
            'selectImage' => __( 'Scegli una fotografia', 'molinarieco-child-theme' ),
            'selectVideo' => __( 'Scegli un video', 'molinarieco-child-theme' ),
            'useImage' => __( 'Usa questa fotografia', 'molinarieco-child-theme' ),
            'useVideo' => __( 'Usa questo video', 'molinarieco-child-theme' ),
            'saveError' => __( 'Non è stato possibile salvare. Riprova o ricarica la pagina.', 'molinarieco-child-theme' ),
            'unsaved' => __( 'Hai modifiche non salvate. Vuoi lasciare questa pagina?', 'molinarieco-child-theme' ),
            'tab' => __( 'Immagini e video', 'molinarieco-child-theme' ),
            'services' => __( 'Servizi', 'molinarieco-child-theme' ),
            'otherPages' => __( 'Altre pagine', 'molinarieco-child-theme' ),
            'mainVideo' => __( 'Video principale', 'molinarieco-child-theme' ),
            'videoDescription' => __( 'Questo video appare all’inizio della Home.', 'molinarieco-child-theme' ),
            'replaceVideo' => __( 'Sostituisci video', 'molinarieco-child-theme' ),
            'videoPoster' => __( 'Anteprima del video', 'molinarieco-child-theme' ),
            'replacePoster' => __( 'Cambia anteprima', 'molinarieco-child-theme' ),
            'homePhotos' => __( 'Fotografie delle sezioni', 'molinarieco-child-theme' ),
            'homeSectionTitles' => array(
                __( 'ISUZU', 'molinarieco-child-theme' ),
                __( 'Elettrauto', 'molinarieco-child-theme' ),
                __( 'Aria condizionata', 'molinarieco-child-theme' ),
                __( 'Cambio gomme', 'molinarieco-child-theme' ),
            ),
            'homeDescription' => __( 'Una fotografia per ciascuna sezione della Home.', 'molinarieco-child-theme' ),
            'mainPhoto' => __( 'Foto principale', 'molinarieco-child-theme' ),
            'mainDescription' => __( 'L’immagine grande accanto al testo.', 'molinarieco-child-theme' ),
            'replacePhoto' => __( 'Sostituisci foto', 'molinarieco-child-theme' ),
            'changePhoto' => __( 'Cambia foto', 'molinarieco-child-theme' ),
            'gallery' => __( 'Galleria del servizio', 'molinarieco-child-theme' ),
            'galleryDescription' => __( 'Trascina le foto per cambiare l’ordine in cui scorrono sul sito. Rimuovi le toglie solo da questa pagina.', 'molinarieco-child-theme' ),
            'addPhoto' => __( 'Aggiungi foto', 'molinarieco-child-theme' ),
            'remove' => __( 'Rimuovi', 'molinarieco-child-theme' ),
            'confirmRemove' => __( 'Rimuovere questa foto dalla galleria? La foto resterà nella Libreria media.', 'molinarieco-child-theme' ),
            'moveBefore' => __( 'Sposta prima', 'molinarieco-child-theme' ),
            'moveAfter' => __( 'Sposta dopo', 'molinarieco-child-theme' ),
            'firstPhoto' => __( 'Prima foto', 'molinarieco-child-theme' ),
            'historyPhotos' => __( 'Fotografie storiche', 'molinarieco-child-theme' ),
            'historyDescription' => __( 'Le due fotografie inserite nella storia del garage.', 'molinarieco-child-theme' ),
            'photo' => __( 'Foto', 'molinarieco-child-theme' ),
            'noPhoto' => __( 'Nessuna foto selezionata', 'molinarieco-child-theme' ),
            'noGallery' => __( 'Questa pagina non ha ancora una galleria associata. Apri la pagina in WordPress e scegline una nel riquadro “Galleria del servizio”.', 'molinarieco-child-theme' ),
            'saved' => __( 'Immagini salvate. Il sito mostra ora le modifiche.', 'molinarieco-child-theme' ),
            'saving' => __( 'Salvataggio in corso…', 'molinarieco-child-theme' ),
            'unsavedStatus' => __( 'Modifiche non salvate', 'molinarieco-child-theme' ),
            'siteSection' => __( 'Immagini della pagina', 'molinarieco-child-theme' ),
        ),
    ) ) . ';', 'before' );
} );

/** The parent has no child tab hook: inject this markup after its form, then move it beside its existing tabs. */
add_action( 'admin_footer', function () {
    $screen = get_current_screen();
    if ( ! $screen || 'toplevel_page_ticinoweb-cms' !== $screen->id || ! current_user_can( 'edit_pages' ) ) {
        return;
    }
    ?>
    <template id="mol-cms-media-template">
        <div id="mol-media" class="ticinoweb-tab-content mol-cms-media" aria-label="<?php esc_attr_e( 'Immagini e video Molinari', 'molinarieco-child-theme' ); ?>">
            <div class="mol-media-intro"><div><h2><?php esc_html_e( 'Immagini e video · Molinari', 'molinarieco-child-theme' ); ?></h2><p><?php esc_html_e( 'Seleziona una pagina, scegli le foto dalla Libreria media e salva. I testi si modificano nelle sezioni già esistenti.', 'molinarieco-child-theme' ); ?></p></div><span><?php esc_html_e( 'Solo questo sito', 'molinarieco-child-theme' ); ?></span></div>
            <div class="mol-media-layout"><nav class="mol-media-pages" aria-label="<?php esc_attr_e( 'Pagine del sito', 'molinarieco-child-theme' ); ?>"><h3><?php esc_html_e( 'Dove vuoi cambiare le immagini?', 'molinarieco-child-theme' ); ?></h3><div class="mol-media-page-list"></div><p><?php esc_html_e( 'Le immagini già caricate restano nella Libreria media di WordPress.', 'molinarieco-child-theme' ); ?></p></nav><div class="mol-media-workspace"><div class="mol-media-status" role="status" aria-live="polite"></div><div class="mol-media-fields"></div><div class="mol-media-actions"><p><?php esc_html_e( 'Le modifiche diventano visibili sul sito dopo il salvataggio.', 'molinarieco-child-theme' ); ?></p><button type="button" class="button button-primary mol-media-save"><?php esc_html_e( 'Salva le modifiche', 'molinarieco-child-theme' ); ?></button></div></div></div>
        </div>
    </template>
    <?php
} );

/** Replace only the image elements in an approved page's content. */
function mol_cms_replace_content_images( $page_id, $ids, $expected ) {
    $post = get_post( $page_id );
    if ( ! $post || count( $ids ) !== $expected ) {
        return false;
    }
    if ( preg_match_all( '/<img\b[^>]*>/i', $post->post_content ) !== $expected ) {
        return false;
    }
    $count = 0;
    $content = preg_replace_callback( '/<img\b[^>]*>/i', static function ( $match ) use ( $ids, &$count ) {
        $image = wp_get_attachment_image( $ids[ $count ], 'large', false, array( 'loading' => 'lazy' ) );
        ++$count;
        return $image ?: $match[0];
    }, $post->post_content );
    if ( $count !== $expected || null === $content ) {
        return false;
    }
    $updated = wp_update_post( array( 'ID' => $page_id, 'post_content' => wp_slash( $content ) ), true );
    return ! is_wp_error( $updated ) && $updated > 0;
}

add_action( 'wp_ajax_mol_cms_save_media', function () {
    check_ajax_referer( 'mol_cms_media_save', 'nonce' );
    if ( ! current_user_can( 'edit_pages' ) || ! current_user_can( 'upload_files' ) ) {
        wp_send_json_error( array( 'message' => __( 'Non hai i permessi per modificare i media.', 'molinarieco-child-theme' ) ), 403 );
    }
    $key = isset( $_POST['page'] ) && is_string( $_POST['page'] ) ? sanitize_key( wp_unslash( $_POST['page'] ) ) : '';
    $pages = mol_cms_media_pages();
    if ( ! isset( $pages[ $key ] ) || ! current_user_can( 'edit_post', $pages[ $key ]['id'] ) ) {
        wp_send_json_error( array( 'message' => __( 'Pagina non valida.', 'molinarieco-child-theme' ) ), 400 );
    }
    $entry = $pages[ $key ];
    $payload = isset( $_POST['media'] ) && is_array( $_POST['media'] ) ? wp_unslash( $_POST['media'] ) : array();
    $image_ids = isset( $payload['images'] ) && is_array( $payload['images'] ) ? array_map( 'absint', $payload['images'] ) : array();
    $gallery_ids = isset( $payload['gallery'] ) && is_array( $payload['gallery'] ) ? array_map( 'absint', $payload['gallery'] ) : array();
    $featured = isset( $payload['featured'] ) ? absint( $payload['featured'] ) : 0;
    $video = isset( $payload['video'] ) ? absint( $payload['video'] ) : 0;
    $valid_image = static function ( $id ) { return $id && 'attachment' === get_post_type( $id ) && wp_attachment_is_image( $id ); };
    if ( $featured && ! $valid_image( $featured ) ) {
        wp_send_json_error( array( 'message' => __( 'La foto principale selezionata non è valida.', 'molinarieco-child-theme' ) ), 400 );
    }
    if ( 'home' === $entry['kind'] && $video && ( 'attachment' !== get_post_type( $video ) || ! wp_attachment_is( 'video', $video ) ) ) {
        wp_send_json_error( array( 'message' => __( 'Il video selezionato non è valido.', 'molinarieco-child-theme' ) ), 400 );
    }
    $term = false;
    if ( 'service' === $entry['kind'] ) {
        $term_slug = sanitize_title( (string) get_post_meta( $entry['id'], 'mol_service_gallery_slug', true ) );
        $term = $term_slug ? get_term_by( 'slug', $term_slug, 'ticinoweb_media_gallery' ) : false;
        if ( ! $term || count( $gallery_ids ) > 30 || count( $gallery_ids ) !== count( array_unique( $gallery_ids ) ) || count( array_filter( $gallery_ids, $valid_image ) ) !== count( $gallery_ids ) ) {
            wp_send_json_error( array( 'message' => __( 'La galleria selezionata non è valida.', 'molinarieco-child-theme' ) ), 400 );
        }
    }
    if ( 'home' === $entry['kind'] || 'history' === $entry['kind'] ) {
        $expected = 'home' === $entry['kind'] ? 4 : 2;
        if ( count( $image_ids ) !== $expected || count( array_filter( $image_ids, $valid_image ) ) !== $expected ) {
            wp_send_json_error( array( 'message' => __( 'Seleziona tutte le fotografie richieste.', 'molinarieco-child-theme' ) ), 400 );
        }
        if ( mol_cms_content_image_ids( $entry['id'] ) !== $image_ids && ! mol_cms_replace_content_images( $entry['id'], $image_ids, $expected ) ) {
            wp_send_json_error( array( 'message' => __( 'Il contenuto della pagina è cambiato. Ricarica la scheda e riprova.', 'molinarieco-child-theme' ) ), 409 );
        }
    }
    if ( 'home' === $entry['kind'] ) {
        if ( $featured ) {
            set_post_thumbnail( $entry['id'], $featured );
        }
        if ( $video ) {
            update_post_meta( $entry['id'], 'mol_hero_video_id', $video );
        } else {
            delete_post_meta( $entry['id'], 'mol_hero_video_id' );
        }
    } elseif ( 'service' === $entry['kind'] ) {
        $old = mol_cms_gallery_ids( $term->term_id );
        foreach ( array_diff( $old, $gallery_ids ) as $id ) {
            wp_remove_object_terms( $id, $term->term_id, 'ticinoweb_media_gallery' );
        }
        foreach ( array_diff( $gallery_ids, $old ) as $id ) {
            wp_set_object_terms( $id, (int) $term->term_id, 'ticinoweb_media_gallery', true );
        }
        update_term_meta( $term->term_id, '_ticinoweb_gallery_order', $gallery_ids );
    }
    if ( in_array( $entry['kind'], array( 'service', 'featured' ), true ) ) {
        if ( $featured ) {
            set_post_thumbnail( $entry['id'], $featured );
        } else {
            delete_post_thumbnail( $entry['id'] );
        }
    }
    wp_send_json_success( array( 'message' => __( 'Immagini salvate. Il sito mostra ora le modifiche.', 'molinarieco-child-theme' ) ) );
} );
