<?php
/**
 * Home page: media and content remain editable in this site's WordPress CMS.
 *
 * @package Molinarieco
 */
get_header();

$front_id     = (int) get_option( 'page_on_front' );
$hero_id      = $front_id ? get_post_thumbnail_id( $front_id ) : 0;
$video_id     = $front_id ? (int) get_post_meta( $front_id, 'mol_hero_video_id', true ) : 0;
$video_url    = $video_id && wp_attachment_is( 'video', $video_id ) ? wp_get_attachment_url( $video_id ) : '';
$poster_url   = $hero_id ? wp_get_attachment_image_url( $hero_id, 'full' ) : '';
// The current film starts on this frame; matching its poster avoids a visible jump when playback begins.
if ( $video_url && 'Molinari-Co-web-540p.mp4' === wp_basename( $video_url ) ) {
    $poster_url = get_stylesheet_directory_uri() . '/hero-first-frame.jpg';
}
?>
<main id="main" class="mol-container mol-home">
<section class="mol-hero" aria-labelledby="mol-hero-title">
<h1 id="mol-hero-title" class="screen-reader-text"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></h1>
<p id="mol-hero-video-description" class="screen-reader-text"><?php esc_html_e( 'Il filmato mostra il garage, il lavoro in officina e i servizi. La schermata finale riporta il messaggio “Pronti a servirvi”; i recapiti sono disponibili nel footer.', 'molinarieco-child-theme' ); ?></p>
<div class="mol-hero-media">
<?php if ( $video_url ) : ?>
<video class="mol-hero-loop" muted loop playsinline preload="metadata"<?php if ( $poster_url ) : ?> poster="<?php echo esc_url( $poster_url ); ?>"<?php endif; ?> aria-label="<?php esc_attr_e( 'Video aziendale Garage Molinari', 'molinarieco-child-theme' ); ?>" aria-describedby="mol-hero-video-description">
<source src="<?php echo esc_url( $video_url ); ?>" type="<?php echo esc_attr( get_post_mime_type( $video_id ) ); ?>">
<?php esc_html_e( 'Il tuo browser non supporta la riproduzione video.', 'molinarieco-child-theme' ); ?>
</video>
<?php elseif ( $hero_id ) : ?>
<?php echo wp_get_attachment_image( $hero_id, 'full', false, array( 'fetchpriority' => 'high', 'loading' => 'eager' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WordPress generates and escapes attachment markup. ?>
<?php endif; ?>
</div>
</section>
<?php
if ( $front_id ) :
    $front = get_post( $front_id );
    if ( $front ) :
        ?>
<section class="mol-home-services" aria-labelledby="mol-home-services-title">
<div class="mol-home-services-heading"><h2 id="mol-home-services-title"><?php esc_html_e( 'Servizi', 'molinarieco-child-theme' ); ?></h2></div>
<div class="mol-home-sections"><?php echo apply_filters( 'the_content', $front->post_content ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WordPress content filters render the editor's approved HTML. ?></div>
</section>
        <?php
    endif;
endif;
?>
</main>
<?php get_footer(); ?>
