(function () {
    'use strict';
    const config = window.molCmsMedia;
    const template = document.getElementById('mol-cms-media-template');
    const tabs = document.querySelector('.ticinoweb-settings-tabs .nav-tab-wrapper');
    if (!config || !template || !tabs || !window.wp || !wp.media) return;

    const parentForm = tabs.closest('form');
    const panel = template.content.firstElementChild.cloneNode(true);
    const tab = document.createElement('a');
    tab.href = '#mol-media';
    tab.className = 'nav-tab';
    tab.textContent = config.labels.tab;
    const after = tabs.querySelector('a[href="#chi-siamo"]');
    (after || tabs.lastElementChild).after(tab);
    tabs.after(panel);
    const pageList = panel.querySelector('.mol-media-page-list');
    const fields = panel.querySelector('.mol-media-fields');
    const status = panel.querySelector('.mol-media-status');
    const save = panel.querySelector('.mol-media-save');
    const pages = config.pages;
    const media = config.attachments;
    const labels = config.labels;
    let current = Object.keys(pages)[0];
    let dirty = false;
    let saving = false;
    let dragging = -1;

    const node = (tag, className, content) => {
        const element = document.createElement(tag);
        if (className) element.className = className;
        if (content !== undefined) element.textContent = content;
        return element;
    };
    const button = (text, action, className = 'button', accessibleName = '') => {
        const element = node('button', className, text);
        element.type = 'button';
        if (accessibleName) element.setAttribute('aria-label', accessibleName);
        element.addEventListener('click', action);
        return element;
    };
    const image = (id, alt) => {
        if (!id || !media[id] || !media[id].url) return node('div', 'mol-media-empty', labels.noPhoto);
        const element = node('img');
        element.src = media[id].url;
        element.alt = alt;
        if (media[id].width && media[id].height) {
            element.width = media[id].width;
            element.height = media[id].height;
        }
        element.loading = 'lazy';
        return element;
    };
    const heading = (title, detail) => {
        const wrap = node('div', 'mol-media-heading');
        wrap.append(node('h3', '', title), node('p', '', detail));
        return wrap;
    };
    const section = (title, caption) => {
        const sectionEl = node('section', 'mol-media-panel');
        const head = node('div', 'mol-media-panel-title');
        head.append(node('strong', '', title), node('span', '', caption));
        sectionEl.append(head);
        return sectionEl;
    };
    const markDirty = () => {
        dirty = true;
        status.textContent = labels.unsavedStatus;
        status.className = 'mol-media-status is-dirty';
    };
    const rememberAttachment = (attachment) => {
        const value = attachment.toJSON();
        const preview = value.sizes?.medium_large || value.sizes?.large || value;
        media[value.id] = {
            id: value.id,
            title: value.title || '',
            url: preview.url,
            width: preview.width,
            height: preview.height
        };
        return value.id;
    };
    const choose = (type, multiple, callback) => {
        const frame = wp.media({
            title: type === 'video' ? labels.selectVideo : labels.selectImage,
            button: { text: type === 'video' ? labels.useVideo : labels.useImage },
            library: { type },
            multiple
        });
        frame.on('select', () => callback(frame.state().get('selection').map(rememberAttachment)));
        frame.open();
    };
    const replace = (property, index, type) => {
        choose(type, false, (selected) => {
            if (!selected.length) return;
            if (index === null) pages[current][property] = selected[0];
            else pages[current][property][index] = selected[0];
            markDirty();
            renderFields();
        });
    };
    const photoCards = (ids, property, titles) => {
        const grid = node('div', 'mol-media-photo-grid');
        ids.forEach((id, index) => {
            const card = node('div', 'mol-media-photo-card');
            card.append(image(id, titles[index] || labels.photo));
            const copy = node('div', 'mol-media-photo-copy');
            copy.append(node('strong', '', titles[index] || `${labels.photo} ${index + 1}`));
            copy.append(button(labels.changePhoto, () => replace(property, index, 'image')));
            card.append(copy);
            grid.append(card);
        });
        return grid;
    };
    const mainPhoto = (id, property, title, description) => {
        const block = section(title, description);
        const row = node('div', 'mol-media-feature');
        row.append(image(id, title));
        const detail = node('div', 'mol-media-feature-detail');
        detail.append(node('h4', '', media[id]?.title || title));
        detail.append(node('p', '', description));
        detail.append(button(labels.replacePhoto, () => replace(property, null, 'image')));
        row.append(detail);
        block.append(row);
        return block;
    };
    const renderGallery = (page) => {
        const block = section(labels.gallery, `${page.gallery.length} ${labels.photo.toLowerCase()}`);
        if (!page.gallery_term) {
            block.append(node('p', 'mol-media-help', labels.noGallery));
            return block;
        }
        block.append(node('p', 'mol-media-help', labels.galleryDescription));
        const grid = node('div', 'mol-media-gallery');
        page.gallery.forEach((id, index) => {
            const card = node('div', 'mol-media-gallery-card');
            card.draggable = true;
            card.addEventListener('dragstart', () => { dragging = index; });
            card.addEventListener('dragover', (event) => event.preventDefault());
            card.addEventListener('drop', (event) => {
                event.preventDefault();
                if (dragging < 0 || dragging === index) return;
                page.gallery.splice(index, 0, page.gallery.splice(dragging, 1)[0]);
                dragging = -1;
                markDirty();
                renderFields();
            });
            card.append(image(id, `${labels.photo} ${index + 1}`));
            const controls = node('div', 'mol-media-gallery-controls');
            controls.append(node('strong', '', `${index + 1}${index === 0 ? ' · ' + labels.firstPhoto : ''}`));
            const moves = node('div', 'mol-media-gallery-moves');
            if (index > 0) moves.append(button('←', () => move(index, -1), 'button-link', labels.moveBefore));
            if (index < page.gallery.length - 1) moves.append(button('→', () => move(index, 1), 'button-link', labels.moveAfter));
            moves.append(button(labels.remove, () => {
                if (!window.confirm(labels.confirmRemove)) return;
                page.gallery.splice(index, 1);
                markDirty();
                renderFields();
            }, 'button-link-delete', `${labels.remove} ${labels.photo.toLowerCase()} ${index + 1}`));
            controls.append(moves);
            card.append(controls);
            grid.append(card);
        });
        block.append(grid);
        const footer = node('div', 'mol-media-panel-footer');
        footer.append(button(`＋ ${labels.addPhoto}`, () => choose('image', true, (selected) => {
            page.gallery = [...new Set([...page.gallery, ...selected])].slice(0, 30);
            markDirty();
            renderFields();
        })));
        block.append(footer);
        return block;
    };
    const move = (index, step) => {
        const ids = pages[current].gallery;
        [ids[index], ids[index + step]] = [ids[index + step], ids[index]];
        markDirty();
        renderFields();
    };
    const renderFields = () => {
        const page = pages[current];
        fields.replaceChildren();
        const description = page.kind === 'home' ? labels.homeDescription : page.kind === 'service' ? labels.mainDescription : page.kind === 'history' ? labels.historyDescription : labels.siteSection;
        fields.append(heading(page.kind === 'service' ? `${labels.services} › ${page.label}` : page.label, description));
        if (page.kind === 'home') {
            const videoBlock = section(labels.mainVideo, page.video ? '✓' : '');
            const row = node('div', 'mol-media-feature');
            row.append(image(page.featured, labels.videoPoster));
            const detail = node('div', 'mol-media-feature-detail');
            detail.append(node('h4', '', media[page.video]?.title || labels.mainVideo));
            detail.append(node('p', '', labels.videoDescription));
            detail.append(button(labels.replaceVideo, () => replace('video', null, 'video')));
            detail.append(button(labels.replacePoster, () => replace('featured', null, 'image'), 'button mol-media-secondary'));
            row.append(detail);
            videoBlock.append(row);
            fields.append(videoBlock);
            const photos = section(labels.homePhotos, `${page.images.length} ${labels.photo.toLowerCase()}`);
            photos.append(photoCards(page.images, 'images', labels.homeSectionTitles));
            fields.append(photos);
        } else if (page.kind === 'history') {
            const photos = section(labels.historyPhotos, `${page.images.length} ${labels.photo.toLowerCase()}`);
            photos.append(photoCards(page.images, 'images', []));
            fields.append(photos);
        } else {
            fields.append(mainPhoto(page.featured, 'featured', labels.mainPhoto, labels.mainDescription));
            if (page.kind === 'service') fields.append(renderGallery(page));
        }
    };
    const renderMenu = () => {
        pageList.replaceChildren();
        let group = '';
        Object.entries(pages).forEach(([key, page]) => {
            const nextGroup = page.kind === 'service' ? labels.services : page.kind === 'home' ? '' : labels.otherPages;
            if (nextGroup && nextGroup !== group) pageList.append(node('div', 'mol-media-group', nextGroup));
            group = nextGroup;
            const entry = button(page.label, () => {
                if (saving || key === current || (dirty && !window.confirm(labels.unsaved))) return;
                current = key;
                dirty = false;
                status.textContent = '';
                renderMenu();
                renderFields();
            }, `mol-media-page ${page.kind === 'service' ? 'is-service ' : ''}${key === current ? 'is-current' : ''}`);
            entry.setAttribute('aria-current', key === current ? 'page' : 'false');
            pageList.append(entry);
        });
    };
    save.addEventListener('click', async () => {
        if (!dirty) return;
        saving = true;
        save.disabled = true;
        status.textContent = labels.saving;
        const page = pages[current];
        const body = new FormData();
        body.append('action', 'mol_cms_save_media');
        body.append('nonce', config.nonce);
        body.append('page', current);
        body.append('media[featured]', page.featured || 0);
        if (page.kind === 'home') body.append('media[video]', page.video || 0);
        (page.images || []).forEach((id) => body.append('media[images][]', id));
        (page.gallery || []).forEach((id) => body.append('media[gallery][]', id));
        try {
            const response = await fetch(config.ajaxUrl, { method: 'POST', body, credentials: 'same-origin' });
            const data = await response.json();
            if (!response.ok || !data.success) throw new Error(data.data?.message || labels.saveError);
            dirty = false;
            status.textContent = data.data?.message || labels.saved;
            status.className = 'mol-media-status is-saved';
        } catch (error) {
            status.textContent = error.message || labels.saveError;
            status.className = 'mol-media-status is-error';
        } finally {
            saving = false;
            save.disabled = false;
        }
    });
    tab.addEventListener('click', (event) => {
        event.preventDefault();
        tabs.querySelectorAll('.nav-tab').forEach((item) => item.classList.remove('nav-tab-active'));
        tab.classList.add('nav-tab-active');
        parentForm.querySelectorAll('.ticinoweb-tab-content').forEach((item) => item.classList.remove('active'));
        panel.classList.add('active');
        document.body.classList.add('mol-media-active');
        history.replaceState(null, '', '#mol-media');
        try { localStorage.setItem('ticinoweb_active_tab', '#mol-media'); } catch (e) {}
    });
    tabs.querySelectorAll('.nav-tab:not([href="#mol-media"])').forEach((item) => item.addEventListener('click', () => {
        document.body.classList.remove('mol-media-active');
    }));
    window.addEventListener('beforeunload', (event) => {
        if (!dirty) return;
        event.preventDefault();
        event.returnValue = '';
    });
    renderMenu();
    renderFields();
    if (location.hash === '#mol-media' || (() => { try { return localStorage.getItem('ticinoweb_active_tab') === '#mol-media'; } catch (e) { return false; } })()) tab.click();
})();
