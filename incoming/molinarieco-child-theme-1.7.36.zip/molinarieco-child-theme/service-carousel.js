(() => {
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const hasHover = window.matchMedia('(hover: hover)');

  document.querySelectorAll('.mol-carousel').forEach((carousel, carouselIndex) => {
    const viewport = carousel.querySelector('.mol-carousel-viewport');
    const track = carousel.querySelector('.mol-carousel-track');
    const status = carousel.querySelector('.mol-carousel-status');
    const originals = Array.from(track?.children || []);
    const count = originals.length;
    if (count < 2) return;

    const clone = (slide) => {
      const copy = slide.cloneNode(true);
      copy.setAttribute('aria-hidden', 'true');
      copy.tabIndex = -1;
      return copy;
    };
    track.prepend(...originals.map(clone));
    track.append(...originals.map(clone));

    const help = document.createElement('span');
    help.id = `mol-carousel-help-${carouselIndex + 1}`;
    help.className = 'screen-reader-text';
    help.textContent = carousel.dataset.keyboardHelp;
    carousel.append(help);
    carousel.setAttribute('aria-describedby', help.id);
    carousel.tabIndex = 0;
    carousel.classList.add('is-ready');

    let index = count;
    let moving = false;
    let paused = reducedMotion.matches;
    let hovered = false;
    let focused = false;
    let pointer = null;
    let suppressClick = false;
    const slideWidth = () => {
      const gap = parseFloat(window.getComputedStyle(track).columnGap) || 0;
      return track.firstElementChild.getBoundingClientRect().width + gap;
    };
    const updateFocusable = () => {
      const visible = parseInt(window.getComputedStyle(carousel).getPropertyValue('--mol-carousel-visible'), 10) || 1;
      originals.forEach((slide, imageIndex) => {
        const trackIndex = count + imageIndex;
        slide.tabIndex = trackIndex >= index && trackIndex < index + visible ? 0 : -1;
      });
    };
    const position = (animate) => {
      track.style.transitionDuration = animate && !reducedMotion.matches ? '500ms' : '0ms';
      track.style.transform = `translate3d(${-index * slideWidth()}px, 0, 0)`;
      updateFocusable();
    };
    const normalize = () => {
      if (index >= count * 2) index -= count;
      if (index < count) index += count;
    };
    const announcePosition = () => {
      const photo = ((index - count) % count + count) % count + 1;
      status.textContent = `${carousel.dataset.photoLabel} ${photo} ${carousel.dataset.ofLabel} ${count}`;
    };
    const advance = (direction, manual = false) => {
      if (moving || pointer) return;
      if (manual) paused = true;
      index += direction;
      moving = true;
      position(true);
      if (manual) announcePosition();
      if (reducedMotion.matches) {
        moving = false;
        normalize();
        position(false);
      }
    };

    track.addEventListener('transitionend', (event) => {
      if (event.target !== track) return;
      moving = false;
      normalize();
      position(false);
    });
    viewport.addEventListener('pointerdown', (event) => {
      if (moving || (event.pointerType === 'mouse' && event.button !== 0)) return;
      const width = slideWidth();
      pointer = { id: event.pointerId, startX: event.clientX, delta: 0, dragged: false, width };
      carousel.classList.add('is-dragging');
      track.style.transitionDuration = '0ms';
    });
    window.addEventListener('pointermove', (event) => {
      if (!pointer || event.pointerId !== pointer.id) return;
      pointer.delta = event.clientX - pointer.startX;
      if (Math.abs(pointer.delta) > 5) pointer.dragged = true;
      if (!pointer.dragged) return;
      if (event.cancelable) event.preventDefault();
      track.style.transform = `translate3d(${-index * pointer.width + pointer.delta}px, 0, 0)`;
    });
    const finishDrag = (event, cancelled = false) => {
      if (!pointer || event.pointerId !== pointer.id) return;
      const { delta, dragged, width } = pointer;
      pointer = null;
      carousel.classList.remove('is-dragging');
      if (cancelled) {
        position(false);
        return;
      }
      if (dragged) {
        paused = true;
        suppressClick = true;
        window.setTimeout(() => { suppressClick = false; }, 350);
      }
      const threshold = Math.min(50, width * .15);
      if (dragged && Math.abs(delta) >= threshold) {
        index += delta < 0 ? 1 : -1;
        moving = true;
        position(true);
        announcePosition();
        if (reducedMotion.matches) {
          moving = false;
          normalize();
          position(false);
        }
      } else if (dragged) {
        moving = true;
        position(true);
        if (reducedMotion.matches) moving = false;
      } else {
        position(false);
      }
    };
    window.addEventListener('pointerup', (event) => finishDrag(event));
    window.addEventListener('pointercancel', (event) => finishDrag(event, true));
    window.addEventListener('blur', () => {
      if (!pointer) return;
      pointer = null;
      carousel.classList.remove('is-dragging');
      position(false);
    });
    viewport.addEventListener('dragstart', (event) => event.preventDefault());
    viewport.addEventListener('click', (event) => {
      if (suppressClick) {
        event.preventDefault();
        event.stopPropagation();
      }
    }, true);
    carousel.addEventListener('keydown', (event) => {
      if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
        event.preventDefault();
        advance(event.key === 'ArrowLeft' ? -1 : 1, true);
      } else if (event.key === ' ' || event.key === 'Spacebar') {
        event.preventDefault();
        paused = !paused;
        status.textContent = paused ? carousel.dataset.pausedLabel : carousel.dataset.resumedLabel;
      }
    });
    carousel.addEventListener('mouseenter', () => { if (hasHover.matches) hovered = true; });
    carousel.addEventListener('mouseleave', () => { hovered = false; });
    carousel.addEventListener('focusin', () => { focused = true; });
    carousel.addEventListener('focusout', (event) => { focused = carousel.contains(event.relatedTarget); });
    window.addEventListener('resize', () => {
      moving = false;
      position(false);
    }, { passive: true });
    reducedMotion.addEventListener('change', (event) => {
      if (event.matches) paused = true;
      moving = false;
      position(false);
    });

    position(false);
    window.setInterval(() => {
      if (!paused && !hovered && !focused && !pointer && !document.hidden) advance(1);
    }, 5000);
  });
})();
