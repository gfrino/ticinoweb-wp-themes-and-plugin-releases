<?php
/**
 * Template Name: Dettaglio servizio Molinari
 * Template Post Type: page
 *
 * Individual service with its featured photograph and a parent Media Gallery.
 */
get_header();
$contact_page  = get_page_by_path( 'contatti' );
?>
<main id="main" class="mol-service-detail">
    <?php while ( have_posts() ) : the_post(); ?>
        <?php
        $service_id     = get_the_ID();
        $gallery_slug   = sanitize_title( (string) get_post_meta( $service_id, 'mol_service_gallery_slug', true ) );
        $gallery        = molinarieco_gallery_data( $gallery_slug );
        $featured_id    = get_post_thumbnail_id( $service_id );
        $main_image_id  = $featured_id ? $featured_id : ( $gallery['ids'][0] ?? 0 );
        $thumbnail_ids  = array_values( array_unique( array_filter( array_merge( array( $main_image_id ), $gallery['ids'] ) ) ) );
        $gallery_html   = $gallery_slug ? do_shortcode( '[mol_gallery slug="' . esc_attr( $gallery_slug ) . '" mode="carousel"]' ) : '';
        $main_photo_id  = 'mol-service-main-photo-' . $service_id;
        ?>
        <article <?php post_class(); ?>>
            <div class="mol-service-detail-hero">
                <?php if ( $main_image_id ) : ?>
                    <div class="mol-service-detail-media">
                        <figure class="mol-service-detail-photo">
                            <?php echo wp_get_attachment_image( $main_image_id, 'large', false, array( 'id' => $main_photo_id, 'loading' => 'eager', 'fetchpriority' => 'high', 'sizes' => '(max-width: 760px) 100vw, 55vw' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core image markup. ?>
                        </figure>
                        <?php if ( count( $thumbnail_ids ) > 1 ) : ?>
                            <div class="mol-service-mobile-gallery" role="group" aria-label="<?php esc_attr_e( 'Scegli la fotografia del servizio', 'molinarieco-child-theme' ); ?>">
                                <?php foreach ( $thumbnail_ids as $index => $image_id ) : ?>
                                    <?php
                                    $full_src = wp_get_attachment_image_url( $image_id, 'large' );
                                    if ( ! $full_src ) {
                                        continue;
                                    }
                                    $alt = (string) get_post_meta( $image_id, '_wp_attachment_image_alt', true );
                                    if ( '' === $alt ) {
                                        $alt = get_the_title( $image_id );
                                    }
                                    $srcset = wp_get_attachment_image_srcset( $image_id, 'large' );
                                    ?>
                                    <button class="mol-service-mobile-thumb<?php echo 0 === $index ? ' is-selected' : ''; ?>" type="button" aria-controls="<?php echo esc_attr( $main_photo_id ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Mostra foto: %s', 'molinarieco-child-theme' ), $alt ) ); ?>" aria-pressed="<?php echo 0 === $index ? 'true' : 'false'; ?>" data-image-src="<?php echo esc_url( $full_src ); ?>" data-image-srcset="<?php echo esc_attr( $srcset ?: '' ); ?>" data-image-alt="<?php echo esc_attr( $alt ); ?>">
                                        <?php echo wp_get_attachment_image( $image_id, 'thumbnail', false, array( 'loading' => 'lazy', 'alt' => '' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core image markup. ?>
                                    </button>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                <div class="mol-service-detail-copy">
                    <h1><?php echo esc_html( get_the_title() ); ?></h1>
                    <div class="entry-content"><?php the_content(); ?></div>
                    <?php if ( $contact_page ) : ?>
                        <a class="mol-button" href="<?php echo esc_url( get_permalink( $contact_page ) ); ?>">
                            <?php esc_html_e( 'Contattaci', 'molinarieco-child-theme' ); ?>
                            <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M7.3 3.5H4.8A1.8 1.8 0 0 0 3 5.4C3.5 14 10 20.5 18.6 21a1.8 1.8 0 0 0 1.9-1.8v-2.5l-4.4-1.1-2 2a14.7 14.7 0 0 1-6.7-6.7l2-2-1.1-4.4Z"/></svg>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <?php if ( $gallery_html ) : ?>
                <section class="mol-service-detail-gallery" aria-label="<?php esc_attr_e( 'Fotografie del servizio', 'molinarieco-child-theme' ); ?>">
                    <h2><?php esc_html_e( 'Fotografie del servizio', 'molinarieco-child-theme' ); ?></h2>
                    <?php echo $gallery_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped shortcode markup. ?>
                </section>
            <?php endif; ?>
        </article>
    <?php endwhile; ?>
</main>
<?php get_footer(); ?>
