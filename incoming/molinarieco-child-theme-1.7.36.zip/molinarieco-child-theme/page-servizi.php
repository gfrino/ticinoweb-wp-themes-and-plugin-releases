<?php
/** Overview of service pages managed in WordPress. */
get_header();
$services_page = get_queried_object();
$services = get_posts( array(
    'post_type'      => 'page',
    'post_status'    => 'publish',
    'post_parent'    => $services_page->ID,
    'posts_per_page' => 20,
    'orderby'        => 'menu_order title',
    'order'          => 'ASC',
) );
?>
<main id="main" class="mol-services-overview">
    <header class="mol-services-overview-heading">
        <h1><?php echo esc_html( get_the_title( $services_page ) ); ?></h1>
        <?php if ( trim( wp_strip_all_tags( $services_page->post_content ) ) ) : ?>
            <div class="entry-content"><?php echo apply_filters( 'the_content', $services_page->post_content ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WordPress content filter. ?></div>
        <?php endif; ?>
    </header>
    <?php if ( $services ) : ?>
        <div class="mol-services-overview-grid">
            <?php foreach ( $services as $service ) : ?>
                <?php
                preg_match( '~<p[^>]*>(.*?)</p>~s', $service->post_content, $description_match );
                $description = wp_strip_all_tags( $description_match[1] ?? '' );
                ?>
                <article class="mol-services-overview-card" id="<?php echo esc_attr( $service->post_name ); ?>">
                    <a href="<?php echo esc_url( get_permalink( $service ) ); ?>">
                        <?php echo get_the_post_thumbnail( $service, 'large', array( 'loading' => 'lazy', 'sizes' => '(max-width: 760px) 100vw, 50vw' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core image markup. ?>
                        <span class="mol-services-overview-card-copy">
                            <strong><?php echo esc_html( get_the_title( $service ) ); ?></strong>
                            <span><?php echo esc_html( wp_trim_words( $description, 24 ) ); ?></span>
                            <em><?php esc_html_e( 'Scopri il servizio', 'molinarieco-child-theme' ); ?></em>
                        </span>
                    </a>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</main>
<?php get_footer(); ?>
