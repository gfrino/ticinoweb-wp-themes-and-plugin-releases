<?php
/**
 * Editorial layout for the commitment page.
 *
 * The photograph is the page's featured image; the text stays in the editor.
 *
 * @package Molinarieco
 */

get_header();
?>
<main id="main" class="mol-commitment-page">
    <?php while ( have_posts() ) : the_post(); ?>
        <article <?php post_class(); ?>>
            <h1 class="screen-reader-text"><?php echo esc_html( get_the_title() ); ?></h1>

            <?php if ( has_post_thumbnail() ) : ?>
                <figure class="mol-commitment-image">
                    <?php
                    echo get_the_post_thumbnail(
                        get_the_ID(),
                        'full',
                        array(
                            'loading'       => 'eager',
                            'fetchpriority' => 'high',
                            'sizes'         => '(max-width: 1200px) 100vw, 1200px',
                        )
                    ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WordPress escapes attachment markup.
                    ?>
                </figure>
            <?php endif; ?>

            <div class="mol-commitment-panel">
                <div class="entry-content"><?php the_content(); ?></div>
                <div class="mol-commitment-footer">
                    <strong><?php echo esc_html( get_bloginfo( 'name', 'raw' ) ); ?></strong>
                    <?php
                    $contact_page = get_page_by_path( 'contatti' );
                    if ( $contact_page ) :
                        ?>
                        <a class="mol-button" href="<?php echo esc_url( get_permalink( $contact_page ) ); ?>"><?php esc_html_e( 'Contattaci', 'molinarieco-child-theme' ); ?></a>
                    <?php endif; ?>
                </div>
            </div>
        </article>
    <?php endwhile; ?>
</main>
<?php get_footer(); ?>
