(() => {
  const galleries = document.querySelectorAll('.mol-service-mobile-gallery');
  if (!galleries.length) return;

  const mobile = window.matchMedia('(max-width: 760px)');
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const hoverable = window.matchMedia('(hover: hover) and (pointer: fine)');

  galleries.forEach((gallery) => {
    const image = gallery.closest('.mol-service-detail-media')?.querySelector('.mol-service-detail-photo img');
    const buttons = Array.from(gallery.querySelectorAll('.mol-service-mobile-thumb'));
    if (!image || buttons.length < 2) return;

    let current = 0;
    let visible = false;
    let pointerDown = false;
    let dragging = false;
    let pointerStartX = 0;
    let scrollStart = 0;
    let lastInteraction = 0;

    const show = (index, automatic = false) => {
      const button = buttons[index];
      if (!button?.dataset.imageSrc) return;

      image.srcset = button.dataset.imageSrcset || '';
      image.sizes = '(max-width: 760px) 100vw, 55vw';
      image.src = button.dataset.imageSrc;
      image.alt = button.dataset.imageAlt || '';
      current = index;

      buttons.forEach((thumb, thumbIndex) => {
        const selected = thumbIndex === index;
        thumb.classList.toggle('is-selected', selected);
        thumb.setAttribute('aria-pressed', String(selected));
      });

      if (automatic) {
        const left = button.offsetLeft - gallery.offsetLeft - (gallery.clientWidth - button.offsetWidth) / 2;
        gallery.scrollTo({ left, behavior: reducedMotion.matches ? 'instant' : 'smooth' });
      } else {
        lastInteraction = Date.now();
      }
    };

    buttons.forEach((button, index) => {
      button.querySelector('img')?.setAttribute('draggable', 'false');
      button.addEventListener('click', () => show(index));
    });

    gallery.addEventListener('pointerdown', (event) => {
      if (event.pointerType === 'touch') {
        lastInteraction = Date.now();
        return;
      }
      pointerDown = true;
      dragging = false;
      pointerStartX = event.clientX;
      scrollStart = gallery.scrollLeft;
      lastInteraction = Date.now();
    });

    gallery.addEventListener('pointermove', (event) => {
      if (!pointerDown) return;
      const distance = event.clientX - pointerStartX;
      if (Math.abs(distance) > 5 && !dragging) {
        dragging = true;
        gallery.setPointerCapture(event.pointerId);
      }
      if (dragging) {
        gallery.classList.add('is-dragging');
        gallery.scrollLeft = scrollStart - distance;
      }
    });

    const finishDrag = () => {
      pointerDown = false;
      gallery.classList.remove('is-dragging');
      lastInteraction = Date.now();
      window.setTimeout(() => { dragging = false; }, 0);
    };
    gallery.addEventListener('pointerup', finishDrag);
    gallery.addEventListener('pointercancel', finishDrag);
    gallery.addEventListener('click', (event) => {
      if (!dragging) return;
      event.preventDefault();
      event.stopPropagation();
      dragging = false;
    }, true);
    gallery.addEventListener('focusin', () => { lastInteraction = Date.now(); });
    gallery.addEventListener('scroll', () => { lastInteraction = Date.now(); }, { passive: true });

    if ('IntersectionObserver' in window) {
      const observer = new IntersectionObserver((entries) => {
        visible = entries[0]?.isIntersecting || false;
      }, { threshold: 0.2 });
      observer.observe(gallery);
    } else {
      visible = true;
    }

    window.setInterval(() => {
      if (!mobile.matches || reducedMotion.matches || document.hidden || !visible || pointerDown) return;
      if ((hoverable.matches && gallery.matches(':hover')) || gallery.contains(document.activeElement)) return;
      if (Date.now() - lastInteraction < 5000) return;
      show((current + 1) % buttons.length, true);
    }, 5000);
  });

  document.documentElement.classList.add('mol-mobile-gallery-ready');
})();
