document.addEventListener('click', function (event) {
  const trigger = event.target.closest('.mol-contact-map-activate');
  if (!trigger) return;

  const container = trigger.closest('.mol-contact-map-preview');
  if (!container || !container.dataset.mapSrc) return;
  event.preventDefault();

  const frame = document.createElement('iframe');
  frame.src = container.dataset.mapSrc;
  frame.title = container.dataset.mapTitle || trigger.textContent.trim();
  frame.width = '900';
  frame.height = '600';
  frame.loading = 'eager';
  frame.referrerPolicy = 'no-referrer-when-downgrade';
  frame.allowFullscreen = true;
  container.replaceChildren(frame);
  frame.focus();
});
