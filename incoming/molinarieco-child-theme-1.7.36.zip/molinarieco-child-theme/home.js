document.addEventListener('DOMContentLoaded', () => {
  const video = document.querySelector('.mol-hero-loop');
  const motion = window.matchMedia('(prefers-reduced-motion: reduce)');

  motion.addEventListener('change', event => {
    if (event.matches) {
      if (video) video.pause();
    } else if (video) video.play().catch(() => {});
  });
  if (video && !motion.matches) video.play().catch(() => {});
});
