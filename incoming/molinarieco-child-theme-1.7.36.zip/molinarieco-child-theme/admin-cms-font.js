document.addEventListener('DOMContentLoaded', () => {
  const saved = window.molinariecoCmsFonts || {};
  for (const role of ['headings', 'subheadings', 'body']) {
    const select = document.getElementById(`ticinoweb_font_${role}`);
    if (!select) continue;
    const option = document.createElement('option');
    option.value = 'Arial';
    option.textContent = 'Arial (sistema)';
    select.prepend(option);
    if (saved[role] === 'Arial') select.value = 'Arial';
  }
});
