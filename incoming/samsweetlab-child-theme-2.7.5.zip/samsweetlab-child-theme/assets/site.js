(() => {
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('#site-navigation');
  if (!toggle || !nav) return;
  const close = () => { toggle.setAttribute('aria-expanded', 'false'); nav.classList.remove('is-open'); };
  toggle.addEventListener('click', () => {
    const open = toggle.getAttribute('aria-expanded') !== 'true';
    toggle.setAttribute('aria-expanded', String(open)); nav.classList.toggle('is-open', open);
  });
  nav.addEventListener('click', event => { if (event.target.closest('a')) close(); });
  document.addEventListener('keydown', event => { if (event.key === 'Escape' && nav.classList.contains('is-open')) { close(); toggle.focus(); } });
})();

/* Titoli che non spezzano le parole. I titoli sono tutti maiuscoli e il font è largo:
   in tedesco, ungherese o russo una parola sola può essere più larga della colonna, e
   il browser la spezzerebbe a metà («POSSIBIL-ITÀ»). Qui si misura la parola più lunga
   di ogni titolo e, se non sta nella riga, quel titolo si rimpicciolisce quanto basta.
   I titoli che stanno già restano come sono. Si rifà quando arrivano i caratteri e
   quando cambia la larghezza della finestra. Senza JavaScript resta il CSS. */
(() => {
  const SEL = 'h1, h2, h3, .footer-brand > a:not(.footer-logo), .hero-label strong';
  const els = [...document.querySelectorAll(SEL)];
  if (!els.length) return;
  const words = el => {
    const out = [];
    const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      const re = /\S+/g; let m;
      while ((m = re.exec(node.textContent))) {
        const r = document.createRange(); r.setStart(node, m.index); r.setEnd(node, m.index + m[0].length); out.push(r);
      }
    }
    return out;
  };
  const fit = () => {
    // prima si torna alle misure del CSS, poi si misura tutto (righe non spezzate), poi si scrive
    els.forEach(el => { el.style.fontSize = ''; el.style.maxWidth = ''; el.style.whiteSpace = 'nowrap'; });
    const plan = els.map(el => {
      const cs = getComputedStyle(el);
      // la riga disponibile: la larghezza del titolo (che può avere un massimo in «ch»)
      const box = el.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
      let widest = 0;
      for (const r of words(el)) widest = Math.max(widest, r.getBoundingClientRect().width);
      return widest > box && box > 0 ? { size: Math.max(12, parseFloat(cs.fontSize) * box / widest * .96), box: el.clientWidth } : null;
    });
    // il massimo in «ch» si rimpicciolirebbe con il carattere: lo si fissa in pixel
    els.forEach((el, i) => { el.style.whiteSpace = ''; if (plan[i]) { el.style.maxWidth = plan[i].box + 'px'; el.style.fontSize = plan[i].size + 'px'; } });
  };
  fit();
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(fit);
  let t = 0;
  addEventListener('resize', () => { clearTimeout(t); t = setTimeout(fit, 120); });
})();

/* Le righe del titolo dell'hero, divise per farle salire una dopo l'altra.
   Se qui non arriva nulla il titolo resta visibile e fermo: l'effetto è un
   di più, non una condizione per leggere la pagina. */
(() => {
  if (!window.matchMedia('(prefers-reduced-motion: no-preference)').matches) return;
  const title = document.querySelector('.hero-copy h1');
  if (!title || title.querySelector('.sweet-line')) return;
  const lines = title.innerHTML.split(/<br\s*\/?>/i);
  if (lines.length < 2) return;
  title.innerHTML = lines.map(line => `<span class="sweet-line"><span>${line}</span></span>`).join('');
})();

/* Passaggio fra catalogo e scheda: la foto su cui si è cliccato prende il
   nome che la pagina di dettaglio assegna alla sua immagine, e il browser
   la fa crescere fino a diventare quella. Dove non è sostenuto, il clic
   resta un clic normale.

   Il nome deve stare su UNA foto sola: con due foto con lo stesso nome il browser
   salta tutta l'animazione. Tornando indietro la pagina del catalogo viene
   ripresentata com'era, con la foto cliccata ancora segnata: per questo a ogni
   uscita si tolgono gli altri segni, e al ritorno ci pensa la riga in <head>
   (functions.php), che segna la foto del prodotto da cui si arriva e poi la pulisce. */
(() => {
  if (!document.startViewTransition) return;
  const NAME = 'sweet-scheda';
  const clear = () => document.querySelectorAll('.card-image img').forEach(img => { if (img.style.viewTransitionName) img.style.viewTransitionName = ''; });
  const mark = img => { clear(); if (img) img.style.viewTransitionName = NAME; };
  const imageFor = url => {
    let path;
    try { path = new URL(url, location.href).pathname; } catch (e) { return null; }
    const link = [...document.querySelectorAll('.catalog-card .card-image')].find(a => new URL(a.href, location.href).pathname === path);
    return link ? link.querySelector('img') : null;
  };
  document.addEventListener('click', event => {
    const link = event.target.closest('.catalog-card a');
    if (!link) return;
    mark(link.closest('.catalog-card').querySelector('.card-image img'));
  }, true);
  // Uscita senza clic sulla scheda (tastiera, tasto Avanti): segna la foto giusta o nessuna.
  addEventListener('pageswap', event => {
    if (!event.viewTransition) return;
    const to = event.activation && event.activation.entry && event.activation.entry.url;
    const img = to ? imageFor(to) : null;
    if (img) mark(img); else if (!document.querySelector('.card-image img[style*="view-transition-name"]')) clear();
  });
})();

/* La parola in evidenza del titolo si alterna ogni tre secondi.
   La lista arriva da PHP ed è vuota in tutte le lingue in cui quella parola
   non è un aggettivo: lì il titolo resta fermo, com'è giusto.

   Si ferma col puntatore SUL TITOLO, col fuoco da tastiera dentro l'apertura
   e quando la scheda del browser non è in primo piano; con «riduci animazioni»
   non parte proprio. Quando la causa della pausa finisce riprende da dove si
   era fermata, non da capo: prima ripartiva sempre da zero, e chi muoveva il
   mouse sulla pagina la vedeva cambiare una volta ogni tanto. */
(() => {
  const parole = Array.isArray(window.sweetHeroWords) ? window.sweetHeroWords.filter(Boolean) : [];
  if (parole.length < 2) return;
  if (!window.matchMedia('(prefers-reduced-motion: no-preference)').matches) return;
  const parola = document.querySelector('.hero-copy h1 em');
  const titolo = document.querySelector('.hero-copy h1');
  const hero = document.querySelector('.hero-copy');
  if (!parola || !titolo || !hero) return;

  const DURATA = 3000, USCITA = 340, MINIMO = 500;
  let indice = parole.indexOf(parola.textContent.trim());
  if (indice < 0) indice = 0;

  const gsap = window.gsap;
  if (!gsap) return;

  /* Tutte le parole stanno una sopra l'altra nello stesso posto (griglia a una
     cella): la parola misura sempre quanto la più lunga, così il cambio non
     sposta mai il resto del titolo né la pagina sotto. Se la più lunga non sta
     sulla riga accanto a «più», la parola si rimpicciolisce finché ci sta. */
  const spans = parole.map((testo, i) => {
    const span = document.createElement('span');
    span.textContent = testo;
    if (i !== indice) { span.setAttribute('aria-hidden', 'true'); gsap.set(span, { autoAlpha: 0 }); }
    return span;
  });
  parola.textContent = '';
  parola.append(...spans);
  parola.classList.add('is-rotating');
  // Il testo prima della parola («più »): se la parola finisce sotto di lui, è andata a capo.
  let prima = parola.previousSibling;
  while (prima && !(prima.nodeType === 3 && prima.textContent.trim())) prima = prima.previousSibling;
  const adatta = () => {
    parola.style.fontSize = '';
    if (!prima) return;
    const range = document.createRange();
    range.selectNodeContents(prima);
    const alta = () => {
      const righe = range.getClientRects();
      const ultima = righe[righe.length - 1];
      // L'interlinea del titolo è stretta (0,9): le righe si sovrappongono, quindi si
      // confronta l'inizio della parola con l'inizio della riga di «più».
      return ultima && parola.getBoundingClientRect().top - ultima.top > parseFloat(getComputedStyle(titolo).fontSize) * .45;
    };
    let scala = 1;
    while (alta() && scala > .55) { scala -= .03; parola.style.fontSize = scala + 'em'; }
  };
  adatta();
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(adatta);
  let ridimensiona = 0;
  addEventListener('resize', () => { clearTimeout(ridimensiona); ridimensiona = setTimeout(adatta, 150); });

  const cambia = () => {
    const via = spans[indice];
    indice = (indice + 1) % parole.length;
    const arriva = spans[indice];
    via.setAttribute('aria-hidden', 'true');
    arriva.removeAttribute('aria-hidden');
    // una parola sola alla volta, anche se un cambio precedente non ha finito
    gsap.killTweensOf(spans);
    spans.forEach(s => { if (s !== via && s !== arriva) gsap.set(s, { autoAlpha: 0, y: 0 }); });
    gsap.to(via, { autoAlpha: 0, y: '-0.22em', duration: USCITA / 1000, ease: 'expo.out' });
    gsap.fromTo(arriva, { autoAlpha: 0, y: '0.22em' }, { autoAlpha: 1, y: 0, duration: USCITA / 1000, ease: 'expo.out', delay: USCITA / 1000 * .6 });
  };

  // Un orologio che si può mettere in pausa davvero: ricorda quanto mancava.
  let attesa = 0, partito = 0, mancano = DURATA;
  const programma = ms => { clearTimeout(attesa); partito = performance.now(); mancano = ms; attesa = setTimeout(giro, ms); };
  const giro = () => { cambia(); programma(DURATA); };

  // Più motivi di pausa possono sovrapporsi (mouse sul titolo e scheda nascosta):
  // si riparte solo quando non ce n'è più nessuno.
  const motivi = new Set();
  const aggiorna = () => {
    if (motivi.size) {
      if (attesa) { clearTimeout(attesa); attesa = 0; mancano = Math.max(0, mancano - (performance.now() - partito)); }
    } else if (!attesa) {
      programma(Math.max(MINIMO, mancano));
    }
  };
  const pausa = (motivo, attiva) => { attiva ? motivi.add(motivo) : motivi.delete(motivo); aggiorna(); };

  programma(DURATA);
  titolo.addEventListener('mouseenter', () => pausa('mouse', true));
  titolo.addEventListener('mouseleave', () => pausa('mouse', false));
  hero.addEventListener('focusin', () => pausa('fuoco', true));
  hero.addEventListener('focusout', () => pausa('fuoco', false));
  document.addEventListener('visibilitychange', () => pausa('nascosta', document.hidden));
  // il gioco segreto ferma il sito sotto di sé: anche l'orologio della parola si ferma
  document.addEventListener('sweet:site-pause', e => pausa('gioco', e.detail));
})();

/* Ricerca con suggerimenti mentre si scrive.
   Il pannello è un <dialog>: lo apre il browser dai pulsanti con commandfor, e
   lo chiude con Esc o cliccando fuori (closedby="any"). Qui si aggiungono i
   ripieghi per i browser che non hanno ancora quei due attributi, e i
   suggerimenti. Senza JavaScript il modulo cerca lo stesso con Invio.

   I suggerimenti non chiedono al server a ogni lettera: all'apertura si scarica
   una volta l'indice di ciò che si può trovare in quella lingua, e poi si filtra
   qui, a ogni battuta, senza attese. Prima si aspettava una pausa nella battitura
   e poi la risposta del server, e chi scriveva veloce vedeva i suggerimenti tardi.
   Se l'indice non arriva si torna alla domanda al server. */
(() => {
  const dialog = document.getElementById('sweet-search');
  const config = window.sweetSearch;
  if (!dialog) return;

  // Apertura e chiusura dai pulsanti, dove commandfor/command non è sostenuto.
  if (!('commandForElement' in HTMLButtonElement.prototype)) {
    document.addEventListener('click', event => {
      const button = event.target.closest('button[commandfor="sweet-search"]');
      if (!button) return;
      const command = button.getAttribute('command');
      if (command === 'show-modal' && !dialog.open) dialog.showModal();
      if (command === 'close' && dialog.open) dialog.close();
    });
  }

  // Chiusura cliccando fuori dal pannello, dove closedby non è sostenuto (Safari).
  if (!('closedBy' in HTMLDialogElement.prototype)) {
    dialog.addEventListener('click', event => {
      if (event.target !== dialog) return;
      const r = dialog.getBoundingClientRect();
      const dentro = r.top <= event.clientY && event.clientY <= r.bottom && r.left <= event.clientX && event.clientX <= r.right;
      if (!dentro) dialog.close();
    });
  }

  const form = dialog.querySelector('form');
  const input = dialog.querySelector('input[type="search"]');
  const list = dialog.querySelector('.search-suggestions');
  const status = dialog.querySelector('.search-status');
  const all = dialog.querySelector('.search-all');
  if (!config || !form || !input || !list) return;

  const MASSIMO = 8;
  const aggiungi = (url, chiave, valore) => url + (url.includes('?') ? '&' : '?') + chiave + '=' + encodeURIComponent(valore);
  let voci = [], attivo = -1;

  const escape = testo => testo.replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  /* Confronto senza maiuscole e senza accenti: «creme» trova «crème», «ingredients»
     trova «ingrédients». Restituisce anche, per ogni lettera normalizzata, la sua
     posizione nel testo originale, per poter evidenziare la parte giusta. */
  const normalizza = testo => {
    let norm = '', mappa = [];
    for (let i = 0; i < testo.length; i++) {
      const pulita = testo[i].normalize('NFD').replace(/[̀-ͯ]/g, '').toLocaleLowerCase();
      for (const c of pulita) { norm += c; mappa.push(i); }
    }
    return { norm, mappa };
  };

  const evidenzia = (testo, cercato) => {
    const t = normalizza(testo), q = normalizza(cercato).norm;
    const i = q ? t.norm.indexOf(q) : -1;
    if (i < 0) return escape(testo);
    const da = t.mappa[i], a = (t.mappa[i + q.length - 1] ?? testo.length - 1) + 1;
    return escape(testo.slice(0, da)) + '<mark>' + escape(testo.slice(da, a)) + '</mark>' + escape(testo.slice(a));
  };

  const etichetta = voce => voce.kind === 'macchina'
    ? (config.families[voce.family] || config.kinds.macchina)
    : (config.kinds[voce.kind] || '');

  /* L'indice, scaricato una volta sola. Parte già quando il puntatore si avvicina
     alla lente, così di solito è pronto prima della prima lettera. */
  let indice = null;
  const caricaIndice = () => {
    if (indice) return indice;
    const indirizzo = config.lang ? aggiungi(config.index, 'lang', config.lang) : config.index;
    indice = fetch(indirizzo, { headers: { Accept: 'application/json' } })
      .then(r => (r.ok ? r.json() : Promise.reject(new Error(String(r.status)))))
      .then(dati => (Array.isArray(dati) ? dati : []).map(voce => {
        const titolo = normalizza(voce.title).norm;
        return { ...voce, _titolo: titolo, _parole: titolo.split(/[\s\/\-–—(),.«»"“”„]+/).filter(Boolean), _etichetta: normalizza(etichetta(voce)).norm };
      }))
      .catch(() => { indice = null; return null; });
    return indice;
  };
  document.querySelectorAll('button[commandfor="sweet-search"][command="show-modal"]').forEach(b => {
    b.addEventListener('pointerenter', caricaIndice, { once: true });
    b.addEventListener('focus', caricaIndice, { once: true });
    b.addEventListener('click', caricaIndice);
  });

  /* Prima i titoli che cominciano con quello che si scrive, poi quelli con una
     parola che comincia così, poi quelli che lo contengono, infine le voci la cui
     etichetta corrisponde (scrivere «mantecatori» propone le macchine Easy). */
  const filtra = (elenco, cercato) => {
    const q = normalizza(cercato).norm;
    const punteggio = voce => {
      if (voce._titolo.startsWith(q)) return 0;
      if (voce._parole.some(p => p.startsWith(q))) return 1;
      if (voce._titolo.includes(q)) return 2;
      if (voce._etichetta.includes(q)) return 3;
      return -1;
    };
    return elenco.map(voce => ({ voce, p: punteggio(voce) }))
      .filter(x => x.p >= 0)
      .sort((a, b) => a.p - b.p || a.voce.title.localeCompare(b.voce.title, config.lang || undefined, { numeric: true }))
      .slice(0, MASSIMO).map(x => x.voce);
  };

  const svuota = () => {
    list.hidden = true;
    list.innerHTML = '';
    input.setAttribute('aria-expanded', 'false');
    input.removeAttribute('aria-activedescendant');
    if (all) all.hidden = true;
    voci = []; attivo = -1;
  };

  const seleziona = n => {
    const opzioni = list.querySelectorAll('[role="option"]');
    opzioni.forEach((o, i) => o.setAttribute('aria-selected', String(i === n)));
    attivo = n;
    if (n >= 0 && opzioni[n]) {
      input.setAttribute('aria-activedescendant', opzioni[n].id);
      opzioni[n].scrollIntoView({ block: 'nearest' });
    } else {
      input.removeAttribute('aria-activedescendant');
    }
  };

  const mostra = (cercato, risultati) => {
    voci = risultati;
    attivo = -1;
    if (!risultati.length) {
      list.innerHTML = '<li class="search-empty" role="presentation">' + escape(config.none.replace('%s', cercato)) + '</li>';
    } else {
      list.innerHTML = risultati.map((voce, i) => `
        <li id="sweet-search-option-${i}" role="option" aria-selected="false">
          <a href="${escape(voce.url)}" tabindex="-1">
            <span class="search-thumb">${voce.image ? `<img src="${escape(voce.image)}" alt="" width="56" height="56" decoding="async">` : ''}</span>
            <span class="search-text">
              <span class="search-kind">${escape(etichetta(voce))}</span>
              <span class="search-title">${evidenzia(voce.title, cercato)}</span>
            </span>
          </a>
        </li>`).join('');
    }
    list.hidden = false;
    input.setAttribute('aria-expanded', 'true');
    input.removeAttribute('aria-activedescendant');
    if (status) status.textContent = config.counts[risultati.length] || '';
    if (all) { all.hidden = false; all.href = aggiungi(form.action, 's', cercato); }
  };

  /* Ripiego: se l'indice non è arrivato, si chiede al server come prima. */
  let richiesta = null, attesa = 0;
  const chiediAlServer = cercato => {
    if (richiesta) richiesta.abort();
    richiesta = new AbortController();
    let indirizzo = aggiungi(config.endpoint, 'q', cercato);
    if (config.lang) indirizzo = aggiungi(indirizzo, 'lang', config.lang);
    fetch(indirizzo, { signal: richiesta.signal, headers: { Accept: 'application/json' } })
      .then(r => (r.ok ? r.json() : []))
      .then(dati => { if (input.value.trim() === cercato) mostra(cercato, Array.isArray(dati) ? dati : []); })
      .catch(errore => { if (errore.name !== 'AbortError') svuota(); });
  };

  const aggiornaSuggerimenti = () => {
    const cercato = input.value.trim();
    if (cercato.length < 2) { svuota(); if (status) status.textContent = ''; return; }
    caricaIndice().then(elenco => {
      if (input.value.trim() !== cercato) return; // nel frattempo si è scritto altro
      if (elenco) { mostra(cercato, filtra(elenco, cercato)); return; }
      clearTimeout(attesa);
      attesa = setTimeout(() => chiediAlServer(cercato), 160);
    });
  };

  input.addEventListener('input', aggiornaSuggerimenti);

  input.addEventListener('keydown', event => {
    if (!voci.length) return;
    if (event.key === 'ArrowDown') { event.preventDefault(); seleziona((attivo + 1) % voci.length); }
    else if (event.key === 'ArrowUp') { event.preventDefault(); seleziona((attivo - 1 + voci.length) % voci.length); }
    else if (event.key === 'Enter' && attivo >= 0) { event.preventDefault(); window.location.href = voci[attivo].url; }
  });

  list.addEventListener('mousemove', event => {
    const opzione = event.target.closest('[role="option"]');
    if (!opzione) return;
    const n = [...list.querySelectorAll('[role="option"]')].indexOf(opzione);
    if (n !== attivo) seleziona(n);
  });

  // Alla chiusura il pannello si ripresenta pulito.
  dialog.addEventListener('close', () => { input.value = ''; svuota(); if (status) status.textContent = ''; });
})();

/*
 * Il gelato che sa il segreto. Aprendo la ricerca, in basso spunta un adesivo a forma
 * di gelato che dondola. Toccandolo diventa un gelato con occhi e bocca che parla:
 * nella nuvoletta suggerisce di cercare «samsweetlab» (il gioco segreto). La parola
 * nella nuvoletta, toccata, si scrive da sola nella ricerca. Mentre si scrive il gelato
 * si fa da parte, per non coprire i suggerimenti; a ricerca vuota torna.
 * Sta dentro la finestra di ricerca: fuori da una finestra modale non si può cliccare.
 */
(() => {
  const dialog = document.getElementById('sweet-search');
  const cfg = window.sweetSearch && window.sweetSearch.hint;
  const input = dialog && dialog.querySelector('input[type="search"]');
  if (!dialog || !cfg || !input || !cfg.word) return;
  const quiet = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const [before, after] = String(cfg.say || '%s').split('%s');

  // Il gelato: cono a cialda, pallina alla fragola che cola, ciliegina. La faccia c'è
  // sempre, ma si accende solo quando parla.
  const svg = `
    <svg class="sweet-buddy-art" viewBox="0 0 120 150" aria-hidden="true" focusable="false">
      <g class="sweet-buddy-body">
        <g class="sweet-buddy-cone">
          <path d="M32 74 L60 142 L88 74 Z" fill="#d99a52" stroke="#fffdf8" stroke-width="9" stroke-linejoin="round" paint-order="stroke"/>
          <path d="M32 74 L60 142 L88 74 Z" fill="#d99a52"/>
          <path d="M40 80 L68 128 M54 78 L76 112 M68 78 L82 96 M80 80 L52 128 M66 78 L44 112 M52 78 L38 94" stroke="#a8692c" stroke-width="2.6" stroke-linecap="round" fill="none"/>
        </g>
        <path class="sweet-buddy-scoop" d="M24 70 C14 44 34 18 60 18 C86 18 106 44 96 70 C93 78 86 76 84 84 C82 92 74 92 73 82 C72 74 64 76 60 80 C55 85 47 84 46 77 C45 71 36 72 32 78 C27 84 25 75 24 70 Z" fill="#f6a9bc" stroke="#fffdf8" stroke-width="9" stroke-linejoin="round" paint-order="stroke"/>
        <path d="M38 34 C44 26 52 23 60 23" stroke="#fff" stroke-width="5" stroke-linecap="round" fill="none" opacity=".7"/>
        <g class="sweet-buddy-sprinkles" stroke-width="3.4" stroke-linecap="round">
          <path d="M44 44 l5 -2" stroke="#f2d44c"/><path d="M78 40 l4 3" stroke="#a3b86c"/><path d="M70 30 l-4 3" stroke="#fffdf8"/><path d="M36 58 l3 4" stroke="#8fd3ff"/><path d="M84 60 l-3 4" stroke="#f2d44c"/>
        </g>
        <g class="sweet-buddy-cherry"><path d="M62 16 C64 8 70 4 76 3" stroke="#3b2218" stroke-width="2.6" stroke-linecap="round" fill="none"/><circle cx="60" cy="16" r="8" fill="#e8607a" stroke="#fffdf8" stroke-width="4" paint-order="stroke"/><circle cx="57" cy="13" r="2.2" fill="#fff" opacity=".8"/></g>
        <g class="sweet-buddy-face">
          <g class="sweet-buddy-eyes">
            <ellipse cx="46" cy="50" rx="6.4" ry="7.6" fill="#fffdf8"/><ellipse cx="74" cy="50" rx="6.4" ry="7.6" fill="#fffdf8"/>
            <g class="sweet-buddy-pupils"><circle cx="47.5" cy="51.5" r="3.6" fill="#1f1510"/><circle cx="75.5" cy="51.5" r="3.6" fill="#1f1510"/><circle cx="48.8" cy="49.8" r="1.2" fill="#fff"/><circle cx="76.8" cy="49.8" r="1.2" fill="#fff"/></g>
          </g>
          <ellipse cx="37" cy="61" rx="5.5" ry="3.4" fill="#e8607a" opacity=".55"/><ellipse cx="83" cy="61" rx="5.5" ry="3.4" fill="#e8607a" opacity=".55"/>
          <path class="sweet-buddy-smile" d="M52 61 Q60 69 68 61" stroke="#1f1510" stroke-width="3.2" stroke-linecap="round" fill="none"/>
          <g class="sweet-buddy-mouth"><ellipse cx="60" cy="64" rx="6.5" ry="5.5" fill="#3b2218"/><ellipse cx="60" cy="67.2" rx="3.8" ry="2.2" fill="#e8607a"/></g>
        </g>
      </g>
    </svg>`;

  const box = document.createElement('div');
  box.className = 'sweet-buddy';
  box.hidden = true;
  box.innerHTML = `
    <div class="sweet-buddy-bubble" id="sweet-buddy-bubble" role="status">
      <p><span class="screen-reader-text">${esc(before)}${esc(cfg.word)}${esc(after || '')}</span><span class="sweet-buddy-say" aria-hidden="true"></span></p>
      <button type="button" class="sweet-buddy-close" aria-label="${esc(cfg.close || '')}"><svg viewBox="0 0 16 16" width="10" height="10" aria-hidden="true"><path d="M3 3l10 10M13 3L3 13" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg></button>
    </div>
    <button type="button" class="sweet-buddy-button" aria-label="${esc(cfg.badge || '')}" aria-expanded="false" aria-controls="sweet-buddy-bubble">${svg}</button>`;
  dialog.append(box);
  const button = box.querySelector('.sweet-buddy-button');
  const say = box.querySelector('.sweet-buddy-say');
  const live = box.querySelector('.screen-reader-text');
  const liveText = live.textContent;
  live.textContent = '';
  let timer = 0, showTimer = 0;

  // La frase compare una lettera alla volta, con la bocca che si muove; la parola segreta
  // è un pulsante che la scrive nella ricerca.
  // Le virgolette attorno alla parola («», „“, “”) restano sulla stessa riga della parola.
  const lead = before.match(/\S*$/)[0], trail = (after || '').match(/^\S*/)[0];
  const head = before.slice(0, before.length - lead.length), tail = (after || '').slice(trail.length);
  const wordButton = () => `<span class="sweet-buddy-nowrap">${esc(lead)}<button type="button" class="sweet-buddy-word" title="${esc(cfg.fill || '')}">${esc(cfg.word)}</button>${esc(trail)}</span>`;
  const talk = () => {
    clearTimeout(timer);
    live.textContent = liveText;
    const full = head + '\u0000' + tail;
    if (quiet()) { say.innerHTML = esc(head) + wordButton() + esc(tail); return; }
    box.classList.add('is-talking');
    let i = 0;
    const tick = () => {
      i = Math.min(full.length, i + 1);
      const shown = full.slice(0, i), cut = shown.indexOf('\u0000');
      say.innerHTML = cut < 0 ? esc(shown) : esc(shown.slice(0, cut)) + wordButton() + esc(shown.slice(cut + 1));
      if (i < full.length) timer = setTimeout(tick, /[,.?!:;]/.test(full[i - 1]) ? 180 : 34);
      else box.classList.remove('is-talking');
    };
    tick();
  };
  const reset = () => {
    clearTimeout(timer); clearTimeout(showTimer);
    box.dataset.state = 'badge'; box.classList.remove('is-talking', 'is-away');
    button.setAttribute('aria-expanded', 'false'); say.innerHTML = ''; live.textContent = '';
  };
  const away = () => box.classList.toggle('is-away', input.value.trim() !== '');

  button.addEventListener('click', () => {
    if (box.dataset.state !== 'talk') {
      box.dataset.state = 'talk'; button.setAttribute('aria-expanded', 'true');
      setTimeout(talk, quiet() ? 0 : 380);
    } else {
      // già sveglio: un saltello e la ripete
      if (!quiet()) button.animate([{ translate: '0 0' }, { translate: '0 -14px' }, { translate: '0 0' }], { duration: 360, easing: 'cubic-bezier(.3,1.6,.5,1)' });
      talk();
    }
  });
  box.querySelector('.sweet-buddy-close').addEventListener('click', () => { reset(); button.focus({ preventScroll: true }); });
  box.addEventListener('click', event => {
    if (!event.target.closest('.sweet-buddy-word')) return;
    input.value = cfg.word;
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.focus();
    away();
  });
  input.addEventListener('input', away);

  // Si apre la ricerca: il gelato spunta dal basso poco dopo. Si chiude: torna adesivo.
  new MutationObserver(() => {
    if (dialog.open) {
      reset(); away();
      showTimer = setTimeout(() => { box.hidden = false; }, quiet() ? 0 : 450);
    } else { reset(); box.hidden = true; }
  }).observe(dialog, { attributes: true, attributeFilter: ['open'] });
})();

/*
 * Il gioco segreto. Chi cerca «samsweetlab» (maiuscole e spazi non contano), con Invio,
 * con il pulsante «Cerca» o con «Vedi tutti i risultati», invece dei risultati trova
 * Ice Cream Tower. Il gioco è un file a parte (assets/game) che si scarica solo in quel
 * momento: le pagine normali non pesano un byte di più. Tutte le altre ricerche vanno
 * come sempre; se il gioco non si carica, la ricerca prosegue normalmente.
 */
(() => {
  const cfg = window.sweetGame;
  if (!cfg || !cfg.src) return;
  const isSecret = value => String(value || '').trim().toLowerCase() === 'samsweetlab';
  let loading = null;
  const load = () => loading || (loading = new Promise((resolve, reject) => {
    if (window.SweetIceCreamTower) { resolve(window.SweetIceCreamTower); return; }
    const script = document.createElement('script');
    script.src = cfg.src;
    script.async = true;
    script.onload = () => (window.SweetIceCreamTower ? resolve(window.SweetIceCreamTower) : reject(new Error('gioco')));
    script.onerror = () => { loading = null; reject(new Error('gioco')); };
    document.head.append(script);
  }));
  const searchButton = () => [...document.querySelectorAll('button[commandfor="sweet-search"][command="show-modal"]')].find(b => b.getClientRects().length) || null;
  const centerOf = el => { const r = el.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; };
  const play = (from, fallback, extra = {}) => {
    const origin = from ? centerOf(from) : null;
    const dialog = from && from.closest('dialog');
    if (dialog && dialog.open) dialog.close();
    load()
      .then(game => game.open(Object.assign({ origin, strings: cfg.strings, returnFocus: searchButton() || document.activeElement }, extra)))
      .catch(fallback);
  };
  document.addEventListener('submit', event => {
    const form = event.target;
    const field = form && form.querySelector && form.querySelector('input[name="s"]');
    if (!field || !isSecret(field.value)) return;
    event.preventDefault();
    play(field, () => HTMLFormElement.prototype.submit.call(form));
  }, true);
  document.addEventListener('click', event => {
    const link = event.target.closest && event.target.closest('a[href*="s="]');
    if (!link) return;
    let url;
    try { url = new URL(link.href, location.href); } catch (e) { return; }
    if (url.origin !== location.origin || !isSecret(url.searchParams.get('s'))) return;
    event.preventDefault();
    play(link.closest('form') ? link.closest('form').querySelector('input[name="s"]') || link : link, () => { location.href = link.href; });
  }, true);
  // Arrivati direttamente su /?s=samsweetlab (ricerca partita prima che la pagina fosse pronta,
  // o un indirizzo condiviso): si apre il gioco; chiudendolo si torna dove si era.
  if (isSecret(new URLSearchParams(location.search).get('s'))) {
    const back = document.referrer && new URL(document.referrer).origin === location.origin && history.length > 1;
    play(null, () => {}, { onClose: () => { if (back) history.back(); } });
  }
})();

/*
 * Avviso «aggiunto al carrello». WooCommerce aggiunge il prodotto senza ricaricare
 * e annuncia l'evento added_to_cart (jQuery): qui compare un riquadro con il nome
 * del prodotto e il collegamento al carrello. Il riquadro è una regione di stato,
 * quindi i lettori di schermo lo leggono senza spostare il fuoco. Il collegamento
 * «Visualizza carrello» che WooCommerce mette accanto al pulsante è nascosto dal CSS.
 */
(() => {
  const config = window.sweetShop;
  if (!config || !window.jQuery) return;

  const toast = document.createElement('div');
  toast.className = 'cart-toast';
  toast.setAttribute('role', 'status');
  toast.hidden = true;
  toast.innerHTML = '<p class="cart-toast-text"></p><a class="button cart-toast-link"></a><button type="button" class="cart-toast-close"><svg viewBox="0 0 16 16" width="12" height="12" aria-hidden="true" focusable="false"><path d="M3 3 13 13M13 3 3 13" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg></button>';
  const text = toast.querySelector('.cart-toast-text');
  const link = toast.querySelector('.cart-toast-link');
  const close = toast.querySelector('.cart-toast-close');
  link.href = config.cart;
  link.textContent = config.view;
  close.setAttribute('aria-label', config.close);
  document.body.append(toast);

  let timer;
  const hide = () => { toast.classList.remove('is-visible'); timer = setTimeout(() => { toast.hidden = true; }, 250); };
  close.addEventListener('click', hide);
  // Finché il puntatore o il fuoco ci sono sopra, l'avviso non sparisce.
  toast.addEventListener('mouseenter', () => clearTimeout(timer));
  toast.addEventListener('focusin', () => clearTimeout(timer));
  toast.addEventListener('mouseleave', () => { clearTimeout(timer); timer = setTimeout(hide, 3000); });

  window.jQuery(document.body).on('added_to_cart', (event, fragments, hash, $button) => {
    const button = $button && $button[0];
    const name = (button && button.dataset.product_name) || '';
    text.textContent = config.added.replace('%s', name);
    clearTimeout(timer);
    toast.hidden = false;
    requestAnimationFrame(() => toast.classList.add('is-visible'));
    timer = setTimeout(hide, 6000);
  });
})();

/*
 * Colonna dei filtri del negozio. Scegliere un ordinamento lo applica subito (il
 * pulsante «Cerca» resta per chi non ha JavaScript). Sul telefono la colonna sta
 * sopra i prodotti: l'elenco delle categorie parte chiuso, salvo che se ne sia
 * scelta una, così i prodotti si vedono subito.
 */
(() => {
  document.querySelectorAll('.catalog-sort select').forEach(select => {
    select.addEventListener('change', () => select.form.requestSubmit());
  });
  const cats = document.querySelector('.catalog-cats');
  if (cats && window.matchMedia('(max-width: 900px)').matches && !new URLSearchParams(location.search).has('categoria')) {
    cats.open = false;
  }
})();

/*
 * Filtro prezzo: due cursori sovrapposti (le maniglie) e due caselle. Si tengono
 * allineati a vicenda, la fascia scelta si colora sull'istogramma e sulla barra,
 * e quando si lascia una maniglia (o si conferma una casella) il filtro si applica.
 * Senza JavaScript restano le caselle e il pulsante «Cerca».
 */
(() => {
  document.querySelectorAll('.price-filter').forEach(box => {
    const min = Number(box.dataset.min);
    const max = Number(box.dataset.max);
    const range = box.querySelector('.price-range');
    const [low, high] = range.querySelectorAll('input');
    const lowBox = box.querySelector('[name="prezzo_min"]');
    const highBox = box.querySelector('[name="prezzo_max"]');
    const bars = box.querySelectorAll('.price-histogram span');
    const form = box.closest('form');
    range.hidden = false;

    const paint = () => {
      const lo = Number(low.value);
      const hi = Number(high.value);
      const span = Math.max(1, max - min);
      range.style.setProperty('--lo', ((lo - min) / span * 100) + '%');
      range.style.setProperty('--hi', ((hi - min) / span * 100) + '%');
      bars.forEach(bar => bar.classList.toggle('is-in', Number(bar.dataset.to) > lo && Number(bar.dataset.from) < hi));
    };

    low.addEventListener('input', () => {
      if (Number(low.value) > Number(high.value) - 1) low.value = Number(high.value) - 1;
      lowBox.value = Number(low.value) > min ? low.value : '';
      paint();
    });
    high.addEventListener('input', () => {
      if (Number(high.value) < Number(low.value) + 1) high.value = Number(low.value) + 1;
      highBox.value = Number(high.value) < max ? high.value : '';
      paint();
    });
    lowBox.addEventListener('input', () => { low.value = lowBox.value === '' ? min : lowBox.value; paint(); });
    highBox.addEventListener('input', () => { high.value = highBox.value === '' ? max : highBox.value; paint(); });

    [low, high, lowBox, highBox].forEach(input => input.addEventListener('change', () => form.requestSubmit()));
    paint();
  });

  // Nell'indirizzo restano solo i filtri usati: niente «cerca=&ordina=».
  document.querySelectorAll('.catalog-search').forEach(form => {
    form.addEventListener('submit', () => {
      form.querySelectorAll('[name]').forEach(field => { if (field.value === '') field.disabled = true; });
    });
    // Tornando indietro il browser può ripresentare la pagina com'era: si riattivano i campi.
    window.addEventListener('pageshow', () => form.querySelectorAll('[name]').forEach(field => { field.disabled = false; }));
  });
})();

/*
 * Cono e palline. Il cursore a cono (style.css) mostra tante palline quanti sono
 * gli articoli nel carrello, fino a tre: qui si legge il numero dall'icona del
 * carrello e lo si scrive in <html data-scoops>. Quando un prodotto entra nel
 * carrello senza ricaricare la pagina, una pallina vola dalla foto della scheda
 * all'icona del carrello; il cono riceve la pallina nuova quando atterra.
 * Con «riduci animazioni» niente volo: il numero si aggiorna e basta.
 */
(() => {
  const root = document.documentElement;
  const COLORS = ['#b9c47c', '#ec9aa0', '#f7eedd'];
  const still = !window.matchMedia('(prefers-reduced-motion: no-preference)').matches;
  let flying = 0;
  let pending = null;

  const count = () => {
    const badge = document.querySelector('.cart-link .cart-count');
    const n = badge && !badge.hidden ? parseInt(badge.textContent.replace(/\D/g, ''), 10) : 0;
    return Number.isFinite(n) ? n : 0;
  };
  const apply = n => { root.dataset.scoops = String(Math.min(n, 3)); };
  const sync = () => { const n = count(); if (flying) pending = n; else apply(n); };
  sync();

  const links = document.querySelector('.shop-links');
  if (links) new MutationObserver(sync).observe(links, { childList: true, subtree: true, characterData: true });

  if (still || !window.jQuery) return;

  // Dove atterrare: l'icona del carrello se si vede, altrimenti l'avviso in basso.
  const target = () => {
    const cart = [...document.querySelectorAll('.cart-link')].find(el => el.getClientRects().length);
    const r = cart && cart.getBoundingClientRect();
    if (r && r.bottom > 0) return { x: r.left + r.width / 2, y: r.top + r.height / 2, cart };
    return { x: innerWidth - 60, y: innerHeight - 60, cart: null };
  };

  window.jQuery(document.body).on('adding_to_cart', (event, $button) => {
    const button = $button && $button[0];
    if (!button) return;
    const image = button.closest('.catalog-card')?.querySelector('.card-image img');
    const from = (image || button).getBoundingClientRect();
    flying++;
    const scoop = document.createElement('div');
    scoop.className = 'scoop-fly';
    scoop.innerHTML = '<span></span>';
    scoop.firstChild.style.setProperty('--scoop', COLORS[Math.min(count(), 2)]);
    document.body.append(scoop);

    const x0 = from.left + from.width / 2, y0 = from.top + from.height / 2;
    const to = target();
    const lift = Math.min(160, Math.max(70, Math.hypot(to.x - x0, to.y - y0) * 0.25));
    const land = () => {
      scoop.remove();
      flying = Math.max(0, flying - 1);
      if (to.cart) { to.cart.classList.remove('is-filled'); void to.cart.offsetWidth; to.cart.classList.add('is-filled'); }
      if (!flying) { apply(pending !== null ? pending : count()); pending = null; }
    };
    const gsap = window.gsap;
    if (!gsap) { land(); return; }
    const time = 0.82;
    gsap.timeline({ onComplete: land })
      .fromTo(scoop, { x: x0, y: y0 }, { x: to.x, y: to.y, duration: time, ease: 'sine.inOut' }, 0)
      .fromTo(scoop.firstChild, { y: 0, scale: .4, opacity: 0 }, { keyframes: { '38%': { y: -lift, scale: 1.15, opacity: 1 }, '100%': { y: 0, scale: .5, opacity: 1 }, easeEach: 'sine.inOut' }, duration: time, ease: 'expo.out' }, 0);
  });
})();

/*
 * Movimento con GSAP (assets/motion: gsap + ScrollTrigger) e scorrimento morbido con Lenis.
 *
 * Un solo orologio: quello di GSAP. Lenis avanza nello stesso fotogramma delle
 * animazioni legate allo scorrimento, così foto, titoli e schede non restano mai
 * indietro di un fotogramma rispetto alla pagina.
 *
 * Tutto parte solo con «riduci animazioni» spento. Senza JavaScript, o se GSAP non
 * arriva, la pagina è ferma e completa: la riga in <head> che nasconde l'apertura
 * (classe sweet-motion) si toglie da sola.
 */
(() => {
  const root = document.documentElement;
  const gsap = window.gsap;
  const ScrollTrigger = window.ScrollTrigger;
  if (!gsap || !ScrollTrigger || !window.matchMedia('(prefers-reduced-motion: no-preference)').matches) {
    root.classList.remove('sweet-motion');
    return;
  }
  gsap.registerPlugin(ScrollTrigger);
  const EASE = 'expo.out'; // = cubic-bezier(.16, 1, .3, 1), la --ease del CSS
  const fine = window.matchMedia('(hover: hover) and (pointer: fine)').matches;

  /* Apertura della home: l'etichetta della foto si appiccica (scende, ruota, rimbalza),
     l'adesivo tondo arriva dopo, le righe del titolo salgono una alla volta.
     Le rotazioni di GSAP si sommano a quelle del CSS (proprietà rotate). */
  const hero = document.querySelector('.sweet-hero');
  if (hero) {
    const intro = gsap.timeline({ defaults: { ease: EASE } });
    const rise = (sel, at) => { const el = hero.querySelector(sel); if (el) intro.fromTo(el, { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: .7 }, at); };
    const title = hero.querySelector('.hero-copy h1');
    if (title) {
      intro.set(title, { visibility: 'visible' }, 0);
      title.querySelectorAll('.sweet-line > span').forEach((line, i) => {
        intro.fromTo(line, { yPercent: 105 }, { yPercent: 0, duration: .9 }, .1 + i * .12);
      });
    }
    rise('.hero-copy .eyebrow', .05);
    rise('.hero-copy p:not(.eyebrow)', .5);
    rise('.hero-actions', .62);
    // GSAP assorbe la rotazione del CSS nella sua: gli angoli qui sono quelli finali veri.
    const figure = hero.querySelector('.hero-visual figure, .hero-visual .wp-block-image');
    if (figure) {
      const base = gsap.getProperty(figure, 'rotation');
      intro.fromTo(figure, { opacity: 0, scale: 1.18, rotation: base + 6, y: -30 }, {
        keyframes: { '70%': { scale: .98, rotation: base - .6 }, '100%': { opacity: 1, scale: 1, rotation: base, y: 0 }, easeEach: EASE },
        duration: 1, ease: 'none',
      }, .15);
    }
    const label = hero.querySelector('.hero-label');
    if (label) {
      intro.fromTo(label, { opacity: 0, scale: .3, rotation: 30 }, {
        keyframes: { '70%': { scale: 1.08 }, '100%': { opacity: 1, scale: 1, rotation: gsap.getProperty(label, 'rotation') }, easeEach: EASE },
        duration: .7, ease: 'none',
      }, .95);
    }
    intro.eventCallback('onComplete', () => root.classList.remove('sweet-motion'));
  } else {
    root.classList.remove('sweet-motion');
  }

  /* Comparse legate allo scorrimento: come le view() del CSS, la corsa va da quando
     l'elemento entra dal basso per una frazione della sua altezza (da..a). */
  const range = (el, from, to) => ({
    trigger: el, scrub: true, invalidateOnRefresh: true,
    start: () => 'top bottom-=' + Math.round(el.offsetHeight * from),
    end: () => 'top bottom-=' + Math.round(el.offsetHeight * to),
  });
  // Titoli e testi: salgono e compaiono (la loro inclinazione resta: GSAP la conserva).
  const reveal = (el, from, to) => gsap.fromTo(el, { opacity: 0, y: 24 }, { opacity: 1, y: 0, ease: 'none', scrollTrigger: range(el, from, to) });
  document.querySelectorAll('.section-heading :is(.eyebrow, p), .editorial-copy :is(.eyebrow, p, .wp-block-buttons), .contact-band :is(.eyebrow, p, .wp-block-buttons), .page-heading :is(.eyebrow, .page-intro)')
    .forEach(el => reveal(el, .08, .46));
  document.querySelectorAll('.section-heading h2, .editorial-copy h2, .contact-band h2, .page-heading h1')
    .forEach(el => reveal(el, .12, .52));
  // Le etichette si appiccicano una dopo l'altra (in griglia, la colonna dà il ritardo).
  // Si muovono --in-y e --in-r, che il CSS somma al sollevamento del mouse.
  document.querySelectorAll('.catalog-card, .world-card, .contact-item').forEach(el => {
    const grid = el.parentElement && el.parentElement.matches('.catalog-grid') ? el.parentElement : null;
    const col = grid ? [...grid.children].indexOf(el) % 3 : 0;
    gsap.fromTo(el, { opacity: 0, '--in-y': '36px', '--in-r': '-3deg' }, { opacity: 1, '--in-y': '0px', '--in-r': '0deg', ease: 'none', scrollTrigger: range(el, .04 + col * .06, .40 + col * .06) });
  });

  // Foto che respirano: restano un po' indietro mentre la pagina sale.
  // Con i prodotti si muovono solo le foto: il nome resta fermo e non esce dalla cornice.
  const productImages = [...document.querySelectorAll('.hero-product img')];
  const heroImages = productImages.length ? productImages : [document.querySelector('.hero-visual img')].filter(Boolean);
  if (heroImages.length) {
    gsap.set(heroImages, { scale: productImages.length ? 1.04 : 1.12 });
    gsap.fromTo(heroImages, { yPercent: -3 }, { yPercent: 5, ease: 'none', scrollTrigger: { start: 0, end: () => innerHeight * .9, scrub: true, invalidateOnRefresh: true } });
  }

  /* I prodotti dell'apertura si alternano: quello che esce si stacca e cade
     indietro, il nuovo si appiccica con un piccolo rimbalzo, come l'etichetta
     all'apertura. Si passa al successivo solo quando la sua foto è pronta.
     Il giro si ferma col mouse (o il fuoco) sopra, così si può cliccare, e
     quando l'apertura è fuori dallo schermo. */
  const slides = [...document.querySelectorAll('.hero-product')];
  if (slides.length > 1) {
    const figure = slides[0].closest('figure');
    let current = 0, busy = false, call = null, visible = true;
    const stopReasons = new Set();
    gsap.set(slides, { autoAlpha: i => (i === 0 ? 1 : 0) });
    const swap = () => {
      const from = slides[current], next = (current + 1) % slides.length, to = slides[next];
      busy = true;
      const img = to.querySelector('img');
      const ready = img && img.decode ? img.decode().catch(() => {}) : Promise.resolve();
      ready.then(() => {
        from.classList.remove('is-on'); from.setAttribute('aria-hidden', 'true'); from.setAttribute('tabindex', '-1');
        to.classList.add('is-on'); to.removeAttribute('aria-hidden'); to.removeAttribute('tabindex');
        gsap.to(from, { autoAlpha: 0, scale: .9, rotation: -5, y: -24, duration: .55, ease: 'power3.in' });
        gsap.fromTo(to, { autoAlpha: 0, scale: 1.12, rotation: 6, y: 34 }, {
          keyframes: { '70%': { autoAlpha: 1, scale: .98, rotation: -.8, y: 0 }, '100%': { scale: 1, rotation: 0 }, easeEach: EASE },
          duration: .9, ease: 'none', delay: .3, onComplete: () => { busy = false; current = next; schedule(); },
        });
      });
    };
    const schedule = () => {
      if (call) call.kill();
      call = null;
      if (!busy && visible && !stopReasons.size) call = gsap.delayedCall(3.2, swap);
    };
    const hold = (reason, on) => { on ? stopReasons.add(reason) : stopReasons.delete(reason); if (on && call) { call.kill(); call = null; } else schedule(); };
    figure.addEventListener('pointerenter', () => hold('mouse', true));
    figure.addEventListener('pointerleave', () => hold('mouse', false));
    figure.addEventListener('focusin', () => hold('fuoco', true));
    figure.addEventListener('focusout', () => hold('fuoco', false));
    ScrollTrigger.create({ trigger: figure, start: 'top bottom', end: 'bottom top', onToggle: self => { visible = self.isActive; schedule(); } });
    gsap.delayedCall(1.8, schedule); // dopo l'apertura
  }
  document.querySelectorAll('.world-card img, .editorial-band img').forEach(img => {
    const box = img.closest('.world-card, .editorial-band');
    gsap.set(img, { scale: 1.1 });
    gsap.fromTo(img, { yPercent: -4 }, { yPercent: 4, ease: 'none', scrollTrigger: { trigger: box, start: 'top bottom', end: 'bottom top', scrub: true } });
  });

  /* Nastro delle categorie senza fine: due copie delle stesse parole, la seconda
     nascosta ai lettori di schermo; la velocità resta la stessa a ogni lunghezza.
     Col mouse sopra rallenta fino a fermarsi, e riparte allo stesso modo. */
  document.querySelectorAll('.category-strip').forEach(strip => {
    const box = strip.querySelector('.wp-block-group__inner-container') || strip;
    const words = [...box.children].filter(el => el.matches('p, span'));
    if (words.length < 2) return;
    const track = document.createElement('div');
    track.className = 'strip-track';
    const first = document.createElement('div');
    first.className = 'strip-set';
    first.append(...words);
    track.append(first);
    box.append(track);
    strip.classList.add('is-marquee');
    // Abbastanza copie da coprire anche uno schermo molto largo, poi il tutto raddoppiato.
    const width = strip.offsetWidth;
    let setWidth = first.offsetWidth;
    while (setWidth && setWidth < width) { first.append(...words.map(w => w.cloneNode(true))); setWidth = first.offsetWidth; }
    const copy = first.cloneNode(true);
    copy.setAttribute('aria-hidden', 'true');
    track.append(copy);
    const loop = gsap.to(track, { xPercent: -50, duration: Math.max(20, setWidth / 55), ease: 'none', repeat: -1 });
    // Fuori dallo schermo il nastro si ferma: niente lavoro per una cosa che non si vede.
    ScrollTrigger.create({ trigger: strip, start: 'top bottom', end: 'bottom top', onToggle: self => (self.isActive ? loop.resume() : loop.pause()) });
    strip.addEventListener('mouseenter', () => gsap.to(loop, { timeScale: 0, duration: .5, ease: 'power2.out', overwrite: true }));
    strip.addEventListener('mouseleave', () => gsap.to(loop, { timeScale: 1, duration: .5, ease: 'power2.in', overwrite: true }));
  });

  /* Pulsanti principali «calamitati»: si spostano di poco verso il mouse. */
  if (fine) {
    document.querySelectorAll('.hero-actions .wp-block-button__link, .editorial-copy .wp-block-button__link, .contact-band .wp-block-button__link, .hero-actions .button, .contact-band .button').forEach(el => {
      el.classList.add('is-magnetic');
      const toX = gsap.quickTo(el, 'x', { duration: .45, ease: EASE });
      const toY = gsap.quickTo(el, 'y', { duration: .45, ease: EASE });
      let box = null;
      el.addEventListener('pointerenter', () => { box = el.getBoundingClientRect(); });
      el.addEventListener('pointermove', event => {
        const r = box || (box = el.getBoundingClientRect());
        toX(Math.max(-12, Math.min(12, (event.clientX - (r.left + r.width / 2)) * .3)));
        toY(Math.max(-9, Math.min(9, (event.clientY - (r.top + r.height / 2)) * .4)));
      });
      el.addEventListener('pointerleave', () => { box = null; toX(0); toY(0); });
    });
  }

  // Le misure cambiano quando arrivano i caratteri e le foto: si ricalcolano le corse.
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => ScrollTrigger.refresh());

  /*
   * Scorrimento morbido con la rotella del mouse (Lenis). Solo su computer: sul
   * telefono lo scorrimento del dito resta quello del sistema. Lenis addolcisce lo
   * scorrimento vero della pagina, quindi tastiera, barra, colonna fissa dei filtri
   * e ScrollTrigger funzionano come prima. Con una finestra aperta (ricerca) si ferma.
   */
  const src = window.sweetLenis;
  if (!src || !fine) return;
  const script = document.createElement('script');
  script.src = src;
  script.async = true;
  script.onload = () => {
    if (!window.Lenis) return;
    // Il trackpad ha già l'inerzia del sistema: addolcirlo ancora lo fa sembrare in
    // ritardo. Lenis lavora quindi solo con la rotella del mouse. Un trackpad (Chrome,
    // Edge, Safari) manda wheelDeltaY pari a -3 volte deltaY; una rotella no. Dove il
    // dato manca (Firefox) decide l'unità: righe = rotella, pixel = trackpad.
    const trackpad = event => event.wheelDeltaY ? event.wheelDeltaY === -3 * event.deltaY : event.deltaMode === 0;
    const lenis = new window.Lenis({
      autoRaf: false,
      lerp: 0.16,
      allowNestedScroll: true,
      virtualScroll: ({ event }) => !(event.type === 'wheel' && trackpad(event)),
      prevent: node => node.matches && node.matches('dialog, select, textarea, .language-switcher ul'),
    });
    lenis.on('scroll', ScrollTrigger.update);
    gsap.ticker.add(time => lenis.raf(time * 1000));
    gsap.ticker.lagSmoothing(0);
    const dialogs = [...document.querySelectorAll('dialog')];
    const check = () => { if (dialogs.some(d => d.open)) lenis.stop(); else lenis.start(); };
    dialogs.forEach(d => new MutationObserver(check).observe(d, { attributes: true, attributeFilter: ['open'] }));
  };
  document.head.append(script);
})();

/*
 * Il sito cambia gusto. Ogni sezione ha il suo campo di colore (--field, nel CSS);
 * lo sfondo della pagina segue la sezione che attraversa il centro dello schermo,
 * così i bordi tra una sezione e l'altra si fondono. Passando con il mouse su un
 * prodotto, la sezione che lo contiene prende il colore del suo gusto.
 *
 * Fluidità: i colori si leggono una volta sola, all'avvio, e non a ogni passaggio;
 * la tinta della pagina va sullo sfondo di <body> e non in una variabile su <html>,
 * che tutti gli elementi ereditano e che li faceva ricalcolare tutti a ogni cambio.
 * Mentre la pagina scorre sotto un mouse fermo le schede gli passano sotto: quelle
 * non sono un vero passaggio del mouse, e la tinta aspetta che il mouse si muova.
 */
(() => {
  const body = document.body;
  const SECTIONS = '.sweet-hero, .category-strip, .section, .editorial-band, .contact-band, .page-heading, .page-content, .detail-main, .site-footer';
  const fields = [...document.querySelectorAll(SECTIONS)];
  if (!fields.length) return;
  const colour = el => getComputedStyle(el).getPropertyValue('--field').trim();
  const base = new Map(fields.map(el => [el, colour(el)]));
  const hovered = new Map(); // sezione -> colore della scheda sotto il mouse
  let current = fields[0];
  let shown = null;
  const paint = () => {
    const c = hovered.has(current) ? hovered.get(current) : base.get(current);
    if (c === shown) return;
    shown = c;
    body.style.backgroundColor = c;
  };
  paint();

  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver(entries => {
      entries.forEach(entry => { if (entry.isIntersecting) { current = entry.target; paint(); } });
    }, { rootMargin: '-50% 0px -50% 0px', threshold: 0 });
    fields.forEach(el => io.observe(el));
  }

  if (!window.matchMedia('(hover: hover) and (pointer: fine)').matches) return;
  // Le schede che scorrono sotto un mouse fermo non cambiano colore alla sezione mentre
  // la pagina si muove (era il ricalcolo che faceva scattare): appena lo scorrimento si
  // ferma, la scheda rimasta sotto il mouse prende la sua tinta, come prima.
  let scrolled = 0, quiet = 0;
  const moving = () => performance.now() - scrolled < 150;
  const cards = new Map();
  addEventListener('scroll', () => {
    scrolled = performance.now();
    clearTimeout(quiet);
    quiet = setTimeout(() => {
      const card = document.querySelector('.catalog-card:hover');
      if (card && cards.has(card)) cards.get(card)();
    }, 160);
  }, { passive: true });
  document.querySelectorAll('.catalog-card').forEach(card => {
    const section = card.closest(SECTIONS);
    if (!section) return;
    const tinta = colour(card);
    let on = false;
    const enter = () => {
      if (on) return;
      on = true;
      hovered.set(section, tinta);
      section.style.setProperty('--field', tinta);
      if (section === current) paint();
    };
    cards.set(card, enter);
    card.addEventListener('pointerenter', () => { if (!moving()) enter(); });
    card.addEventListener('pointermove', () => { if (!on && !moving()) enter(); }, { passive: true });
    card.addEventListener('pointerleave', () => {
      if (!on) return;
      on = false;
      if (hovered.get(section) === tinta) hovered.delete(section);
      section.style.removeProperty('--field');
      if (section === current) paint();
    });
  });
})();
