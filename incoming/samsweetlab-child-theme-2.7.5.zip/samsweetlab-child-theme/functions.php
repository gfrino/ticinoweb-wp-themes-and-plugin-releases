<?php
/** Presentation and catalog integration; shared CMS functionality stays in the parent. */
defined('ABSPATH') || exit;
add_action('after_setup_theme', function () {
    load_child_theme_textdomain('samsweetlab-child-theme', get_stylesheet_directory() . '/languages');
    remove_action('wp_enqueue_scripts', 'ticinoweb_ai_assets');
});
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('samsweetlab-style', get_stylesheet_uri(), array(), wp_get_theme()->get('Version'));
    // GSAP 3.15.0 + ScrollTrigger (licenza gratuita GreenSock, dentro il tema: assets/motion/README.txt).
    wp_enqueue_script('samsweetlab-gsap', get_stylesheet_directory_uri() . '/assets/motion/gsap.min.js', array(), '3.15.0', true);
    wp_enqueue_script('samsweetlab-scrolltrigger', get_stylesheet_directory_uri() . '/assets/motion/ScrollTrigger.min.js', array('samsweetlab-gsap'), '3.15.0', true);
    wp_enqueue_script('samsweetlab-site', get_stylesheet_directory_uri() . '/assets/site.js', array('samsweetlab-scrolltrigger'), wp_get_theme()->get('Version'), true);
    $accent = sanitize_hex_color(get_option('ticinoweb_palette_primary', ''));
    if ($accent) wp_add_inline_style('samsweetlab-style', ':root{--accent:' . $accent . ';}');
    // Scorrimento morbido: site.js carica Lenis solo dove serve (mouse, niente «riduci animazioni»).
    wp_add_inline_script('samsweetlab-site', 'window.sweetLenis=' . wp_json_encode(get_stylesheet_directory_uri() . '/assets/scroll/lenis.min.js?ver=1.3.26') . ';', 'before');
    // Il gioco segreto (assets/game/ice-cream-tower.js): site.js lo scarica solo quando qualcuno cerca «samsweetlab».
    wp_add_inline_script('samsweetlab-site', 'window.sweetGame=' . wp_json_encode(array(
        'src' => get_stylesheet_directory_uri() . '/assets/game/ice-cream-tower.js?ver=' . rawurlencode(wp_get_theme()->get('Version')),
        'strings' => sweet_game_strings(),
    )) . ';', 'before');
    $parole = sweet_hero_words();
    if ($parole) wp_add_inline_script('samsweetlab-site', 'window.sweetHeroWords=' . wp_json_encode($parole) . ';', 'before');
}, 20);

/**
 * Punto di partenza dell'apertura animata: prima che la pagina si disegni, se le
 * animazioni sono ammesse, <html> riceve sweet-motion e il CSS tiene nascosti i pezzi
 * che GSAP farà entrare. Se GSAP non parte entro 3 secondi la classe si toglie e la
 * pagina compare ferma; senza JavaScript la classe non c'è proprio.
 */
add_action('wp_head', function () {
    echo "<script>(function(d){if(!matchMedia('(prefers-reduced-motion: no-preference)').matches)return;d.classList.add('sweet-motion');setTimeout(function(){if(!window.gsap)d.classList.remove('sweet-motion')},3000)})(document.documentElement)</script>\n";
}, 1);

/**
 * Ritorno dalla scheda al catalogo con la foto che torna al suo posto: la pagina
 * che arriva segna la foto del prodotto da cui si viene (deve farlo prima di
 * disegnarsi, quindi qui in <head>), e a fine animazione la pulisce. Toglie anche
 * i segni rimasti quando il browser ripresenta la pagina dalla memoria (Indietro):
 * con due foto con lo stesso nome l'animazione salterebbe.
 */
add_action('wp_head', function () {
    echo "<script>addEventListener('pagereveal',function(e){var N='sweet-scheda',q=function(){return document.querySelectorAll('.card-image img')},c=function(){q().forEach(function(i){i.style.viewTransitionName=''})};c();if(!e.viewTransition)return;var n=window.navigation,f=(n&&n.activation&&n.activation.from&&n.activation.from.url)||document.referrer;if(f){try{var p=new URL(f,location.href).pathname,a=[].find.call(document.querySelectorAll('.catalog-card .card-image'),function(x){return new URL(x.href,location.href).pathname===p}),i=a&&a.querySelector('img');if(i)i.style.viewTransitionName=N}catch(x){}}e.viewTransition.finished.finally(c)})</script>\n";
}, 2);

/** I testi del gioco segreto Ice Cream Tower, nella lingua della pagina. */
function sweet_game_strings() {
    return array(
        'label'      => __('Gioco segreto: Ice Cream Tower', 'samsweetlab-child-theme'),
        'tagline'    => __('Sovrapponi. Bilancia. Batti il record.', 'samsweetlab-child-theme'),
        'play'       => __('Gioca ora', 'samsweetlab-child-theme'),
        'howMouse'   => __('Muovi il cono con il mouse o con le frecce.', 'samsweetlab-child-theme'),
        'howTouch'   => __('Trascina il dito per muovere il cono.', 'samsweetlab-child-theme'),
        'howGoal'    => __('Prendi le palline e tieni la torre in equilibrio: più sale, più oscilla.', 'samsweetlab-child-theme'),
        'mouse'      => __('Mouse', 'samsweetlab-child-theme'),
        'keys'       => __('Frecce · A D', 'samsweetlab-child-theme'),
        'drag'       => __('Trascina', 'samsweetlab-child-theme'),
        'scoops'     => __('Palline', 'samsweetlab-child-theme'),
        'best'       => __('Record', 'samsweetlab-child-theme'),
        'balance'    => __('Equilibrio', 'samsweetlab-child-theme'),
        'pause'      => __('Pausa', 'samsweetlab-child-theme'),
        'paused'     => __('In pausa', 'samsweetlab-child-theme'),
        'resume'     => __('Riprendi', 'samsweetlab-child-theme'),
        'retry'      => __('Riprova', 'samsweetlab-child-theme'),
        'back'       => __('Torna al sito', 'samsweetlab-child-theme'),
        'exit'       => __('Esci dal gioco', 'samsweetlab-child-theme'),
        'soundOn'    => __('Suono acceso', 'samsweetlab-child-theme'),
        'soundOff'   => __('Suono spento', 'samsweetlab-child-theme'),
        'ohNo'       => __('Oh no!', 'samsweetlab-child-theme'),
        'fell'       => __('Il gelato è caduto!', 'samsweetlab-child-theme'),
        'caught'     => __('Palline raccolte', 'samsweetlab-child-theme'),
        'newRecord'  => __('Nuovo record!', 'samsweetlab-child-theme'),
        'beatRecord' => __('Hai battuto il tuo record!', 'samsweetlab-child-theme'),
        'almost'     => __('Così vicino al record!', 'samsweetlab-child-theme'),
        'm10'        => __('Che equilibrio!', 'samsweetlab-child-theme'),
        'm20'        => __('Torre da maestro gelatiere!', 'samsweetlab-child-theme'),
        'm30'        => __('Leggendario!', 'samsweetlab-child-theme'),
        'missed'     => __('Palline cadute', 'samsweetlab-child-theme'),
        'tooMany'    => __('Tre palline a terra!', 'samsweetlab-child-theme'),
        'howLives'   => __('Tre palline a terra e la partita finisce.', 'samsweetlab-child-theme'),
    );
}

/**
 * Le parole che si alternano nel titolo della home.
 *
 * Solo italiano e francese: in quelle due lingue la parola in evidenza è un
 * aggettivo riferito alle idee, e si può sostituire. Nelle altre sei lingue
 * in evidenza c'è un sostantivo — «ideas», «Form», «идеи», «nápadom» — e far
 * ruotare lì degli aggettivi darebbe frasi sgrammaticate. Finché quei titoli
 * restano così, la lista è vuota e il titolo non si muove: è voluto.
 */
function sweet_hero_words() {
    $lingua = sweet_lang();
    $parole = array(
        'it' => array('dolci.', 'golose.', 'originali.', 'sfiziose.', 'deliziose.'),
        'fr' => array('douces.', 'gourmandes.', 'originales.', 'savoureuses.', 'délicieuses.'),
    );
    return isset($parole[$lingua]) ? $parole[$lingua] : array();
}
/**
 * Lingua della pagina, da tW Translate Plus. Senza il plugin il sito è
 * monolingua e la lingua è quella predefinita.
 */
function sweet_lang() {
    return function_exists('twtr_get_current_language') ? twtr_get_current_language() : 'it';
}

/** La lingua chiesta se è attiva sul sito, altrimenti quella predefinita. */
function sweet_valid_lang($lingua) {
    $attive = function_exists('twtr_get_languages') ? twtr_get_languages() : array();
    if (isset($attive[$lingua])) return $lingua;
    foreach ($attive as $codice => $info) {
        if (!empty($info['is_default'])) return $codice;
    }
    return 'it';
}

function sweet_default_lang() {
    return sweet_valid_lang('');
}

/**
 * Titolo di un contenuto in una lingua data, anche fuori dalla pagina (servizi
 * REST, dove tW non sa in che lingua si è). Find non mette nulla in coda: un
 * titolo senza traduzione resta quello italiano.
 */
function sweet_title_in($post, $lingua) {
    $titolo = get_post_field('post_title', $post, 'raw');
    if ($lingua !== sweet_default_lang() && class_exists('Twtr_Resolver')) {
        $tradotto = Twtr_Resolver::find($titolo, 'post:' . (int) $post->ID . ':title', $lingua);
        if ($tradotto !== null) $titolo = $tradotto;
    }
    return html_entity_decode(wp_strip_all_tags($titolo), ENT_QUOTES, 'UTF-8');
}

/** Indirizzo di un contenuto in una lingua data (prefisso e slug tradotti). */
function sweet_url_in($post, $lingua) {
    $url = get_permalink($post);
    return function_exists('twtr_get_language_url') ? twtr_get_language_url($lingua, $url) : $url;
}

/**
 * Id dei contenuti il cui titolo TRADOTTO contiene il testo cercato.
 *
 * I contenuti esistono una volta sola, in italiano: le traduzioni stanno nella
 * tabella di tW Translate Plus. La ricerca di WordPress guarda solo l'italiano,
 * quindi chi cerca «cone» sul sito inglese non troverebbe i coni. Qui si cercano
 * i titoli pronti nella lingua della pagina.
 */
function sweet_translated_title_matches($testo, $lingua, $limite = 200) {
    global $wpdb;
    $testo = trim((string) $testo);
    if ($testo === '' || $lingua === sweet_default_lang() || !class_exists('Twtr_Storage')) return array();
    $chiave = $lingua . '|' . $testo;
    static $cache = array();
    if (isset($cache[$chiave])) return $cache[$chiave];
    $righe = $wpdb->get_col($wpdb->prepare(
        'SELECT context_key FROM ' . Twtr_Storage::entries_table() . " WHERE blog_id = %d AND target_locale = %s AND status = 'ready' AND context_key LIKE %s AND translated_text LIKE %s LIMIT %d",
        get_current_blog_id(), $lingua, 'post:%:title', '%' . $wpdb->esc_like($testo) . '%', $limite
    ));
    $ids = array();
    foreach ((array) $righe as $riga) {
        if (preg_match('/^post:(\d+):title$/', $riga, $m)) $ids[] = (int) $m[1];
    }
    return $cache[$chiave] = array_values(array_unique($ids));
}

/*
 * Ogni ricerca del sito (pagina dei risultati, suggerimenti, filtro del catalogo)
 * trova anche i contenuti il cui titolo tradotto corrisponde.
 */
add_filter('posts_search', function ($search, $query) {
    global $wpdb;
    if ($search === '' || is_admin() || !$query->get('s')) return $search;
    $lingua = $query->get('sweet_lang') ?: sweet_lang();
    $ids = sweet_translated_title_matches($query->get('s'), $lingua);
    if (!$ids) return $search;
    // WordPress scrive « AND (…) »: si aggiunge un'alternativa dentro la stessa condizione.
    $ricerca = preg_replace('/^\s*AND\s*/', '', $search);
    return ' AND (' . $ricerca . ' OR ' . $wpdb->posts . '.ID IN (' . implode(',', array_map('intval', $ids)) . '))';
}, 10, 2);

// Il negozio: prezzi, carrello, cassa e testi di WooCommerce tradotti.
if (class_exists('WooCommerce')) require get_stylesheet_directory() . '/inc/shop.php';

function sweet_page_url($key) {
    $pages = get_option('samsweetlab_pages', array());
    if (empty($pages[$key])) return home_url('/');
    // tW Translate Plus aggiunge da sé lingua e slug tradotto all'indirizzo.
    return get_permalink((int)$pages[$key]);
}

/**
 * Le categorie da mostrare nel menu del catalogo ingredienti.
 *
 * Quali categorie compaiono si decide sulle categorie italiane (la bandierina
 * _sweet_catalog_visible): sono le sole che esistono, i nomi nelle altre lingue
 * li mette tW Translate Plus. Restano fuori le categorie senza prodotti visibili.
 */
function sweet_catalog_categories() {
    $terms = get_terms(array(
        'taxonomy'   => 'product_cat',
        'hide_empty' => true,
        'orderby'    => 'name',
        'meta_query' => array(
            array('key' => '_sweet_language', 'value' => 'it'),
            array('key' => '_sweet_catalog_visible', 'value' => '1'),
        ),
    ));
    if (is_wp_error($terms) || !$terms) return array();
    // Ordine alfabetico nella lingua della pagina, non in quella italiana.
    usort($terms, function ($a, $b) { return strcasecmp(remove_accents($a->name), remove_accents($b->name)); });
    return $terms;
}

/**
 * Selettore di lingua: mostra la lingua corrente e apre l'elenco delle altre.
 * Senza tW Translate Plus non stampa nulla, così il tema resta usabile su un
 * sito monolingua.
 */
function sweet_language_switcher() {
    $languages = function_exists('twtr_get_languages') ? twtr_get_languages() : array();
    if (count($languages) < 2) return;

    $current = reset($languages);
    foreach ($languages as $language) {
        if (!empty($language['is_current'])) { $current = $language; break; }
    }
    ?>
    <details class="language-switcher">
      <summary aria-label="<?php esc_attr_e('Lingua', 'samsweetlab-child-theme'); ?>"><?php echo esc_html(strtoupper($current['slug'])); ?><span aria-hidden="true">▾</span></summary>
      <ul>
        <?php foreach ($languages as $language) :
            if (!empty($language['is_current'])) continue; ?>
          <li><a href="<?php echo esc_url($language['url']); ?>" hreflang="<?php echo esc_attr($language['slug']); ?>" lang="<?php echo esc_attr($language['slug']); ?>"><?php echo esc_html($language['label']); ?></a></li>
        <?php endforeach; ?>
      </ul>
    </details>
    <?php
}
function sweet_text($value, $key) {
    return function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text($value, 'samsweetlab:' . $key) : $value;
}
function sweet_summary($post) {
    $html = $post->post_excerpt ?: $post->post_content;
    if (sweet_lang() !== sweet_default_lang()) {
        // Il contenuto esiste in italiano: il testo tradotto lo dà tW Translate Plus,
        // che riconosce il contenuto solo se è quello in corso.
        if (has_excerpt($post)) {
            $html = get_the_excerpt($post);
        } else {
            $prima = isset($GLOBALS['post']) ? $GLOBALS['post'] : null;
            $GLOBALS['post'] = $post;
            setup_postdata($post);
            $html = apply_filters('the_content', $post->post_content);
            if ($prima instanceof WP_Post) { $GLOBALS['post'] = $prima; setup_postdata($prima); } else { wp_reset_postdata(); }
        }
    }
    $text = wp_strip_all_tags(preg_replace('~</p>|<br\s*/?>~i', ' ', $html));
    $text = preg_replace('/(?:Prezzo e quantit[àa]|Tempi di consegna).*?(?:\n|$)/iu', '', $text);
    return wp_trim_words($text, 25);
}
/** La famiglia della macchina è registrata in italiano: la si traduce con gettext. */
function sweet_machine_family_key($postId) {
    return (string) get_post_meta((int)$postId, '_sweet_machine_family', true);
}

function sweet_machine_family($postId) {
    return sweet_machine_family_label(sweet_machine_family_key($postId));
}

function sweet_machine_family_label($family) {
    switch ($family) {
        case 'Granite e sorbetti': return __('Granite e sorbetti', 'samsweetlab-child-theme');
        case 'Cuocicrema':         return __('Cuocicrema', 'samsweetlab-child-theme');
        case 'Mantecatori':        return __('Mantecatori', 'samsweetlab-child-theme');
        case 'Creme fredde':       return __('Creme fredde', 'samsweetlab-child-theme');
        case 'Bevande calde':      return __('Bevande calde', 'samsweetlab-child-theme');
    }
    return $family;
}

/**
 * La categoria da mostrare sulla foto del prodotto: la più specifica (la più
 * profonda nell'albero), per esempio «Basi Latte» invece di «Gelaterie».
 */
function sweet_card_category($post_id) {
    $terms = get_the_terms($post_id, 'product_cat');
    if (!$terms || is_wp_error($terms)) return '';
    $best = null; $best_depth = -1;
    foreach ($terms as $term) {
        $depth = count(get_ancestors($term->term_id, 'product_cat', 'taxonomy'));
        if ($depth > $best_depth || ($depth === $best_depth && strcmp($term->name, $best->name) < 0)) { $best = $term; $best_depth = $depth; }
    }
    return $best ? $best->name : '';
}

/**
 * Il «gusto» di un prodotto: uno dei sei colori del tema, scelto dalla categoria.
 * Le parole chiave coprono le famiglie note; per il resto decide il nome della
 * categoria, sempre allo stesso modo, così un prodotto non cambia colore.
 */
function sweet_flavour($post_id) {
    static $cache = array();
    if (isset($cache[$post_id])) return $cache[$post_id];
    $names = array();
    if (get_post_type($post_id) === 'macchina') {
        $names[] = sweet_machine_family($post_id);
    } else {
        $terms = get_the_terms($post_id, 'product_cat');
        // Gli slug, non i nomi: i nomi cambiano con la lingua, il colore no.
        if ($terms && !is_wp_error($terms)) foreach ($terms as $term) $names[] = $term->slug;
    }
    $text = remove_accents(strtolower(str_replace('-', ' ', implode(' ', $names))));
    $rules = array(
        'pistacchio' => '/pistacc|verd/',
        'fragola'    => '/fragol|frutt|variegat|lampon|ciliegi|amaren/',
        'cioccolato' => '/cioccol|cacao|copertur|gianduj|gianduia|stecc|pingu/',
        'nocciola'   => '/noccio|con[io]\b|cono|cialde|wafer|biscott|caff|caramel/',
        'latte'      => '/latte|panna|basi|base\b|neutr|yogurt|fior/',
        'limone'     => '/limon|coppett|cucchia|imball|monous|termoscat|coperch|bar\b/',
    );
    $flavour = '';
    foreach ($rules as $name => $rule) if (preg_match($rule, $text)) { $flavour = $name; break; }
    if ($flavour === '') { $keys = array_keys($rules); $flavour = $keys[crc32($text) % count($keys)]; }
    return $cache[$post_id] = $flavour;
}

/* La scheda del prodotto prende il colore del suo gusto. */
add_filter('body_class', function ($classes) {
    if (is_singular(array('product', 'macchina'))) $classes[] = 'flavour-' . sweet_flavour(get_queried_object_id());
    return $classes;
});

function sweet_card($post) {
    $machine = $post->post_type === 'macchina';
    $label = $machine ? sweet_machine_family($post->ID) : sweet_card_category($post->ID);
    if ($label === '') $label = $machine ? '' : __('Ingredienti e accessori', 'samsweetlab-child-theme');
    ?>
    <article class="catalog-card flavour-<?php echo esc_attr(sweet_flavour($post->ID)); ?>">
      <a class="card-image" href="<?php echo esc_url(get_permalink($post)); ?>">
        <?php echo get_the_post_thumbnail($post, 'medium_large', array('loading'=>'lazy')); ?>
        <?php if ($label !== '') : ?><span class="card-badge"><?php echo esc_html($label); ?></span><?php endif; ?>
        <span class="card-arrow" aria-hidden="true">↗</span>
      </a>
      <div class="card-copy">
        <h3><a href="<?php echo esc_url(get_permalink($post)); ?>"><?php echo esc_html(get_the_title($post)); ?></a></h3>
        <?php if ($machine) : ?><p><?php echo esc_html(sweet_summary($post)); ?></p><?php endif; ?>
        <?php if (!$machine && function_exists('wc_get_product') && ($product = wc_get_product($post))) : ?>
          <div class="card-buy"><?php echo sweet_price($product); echo sweet_add_to_cart_button($product); ?></div>
        <?php endif; ?>
      </div>
    </article>
    <?php
}
add_shortcode('sweet_catalog', function ($attributes) {
    $a = shortcode_atts(array('type'=>'product', 'limit'=>12, 'featured'=>'no'), $attributes);
    $type = $a['type'] === 'machine' ? 'macchina' : 'product';
    $featured = $a['featured'] === 'yes';
    $get = function ($key) { return isset($_GET[$key]) && is_scalar($_GET[$key]) ? wp_unslash((string) $_GET[$key]) : ''; };
    $page = $featured ? 1 : max(1, absint($get('pagina')));
    $search = $featured ? '' : sanitize_text_field($get('cerca'));
    $category = $featured ? '' : sanitize_title($get('categoria'));
    if (!$featured && !$category && is_tax('product_cat')) $category = get_queried_object()->slug;
    $sorts = array(
        ''                   => array(__('In evidenza', 'samsweetlab-child-theme'), array('orderby'=>'menu_order title','order'=>'ASC')),
        'prezzo-crescente'   => array(__('Prezzo crescente', 'samsweetlab-child-theme'), array('meta_key'=>'_price','orderby'=>'meta_value_num','order'=>'ASC')),
        'prezzo-decrescente' => array(__('Prezzo decrescente', 'samsweetlab-child-theme'), array('meta_key'=>'_price','orderby'=>'meta_value_num','order'=>'DESC')),
        'nome'               => array(__('Nome', 'samsweetlab-child-theme'), array('orderby'=>'title','order'=>'ASC')),
    );
    $sort = $featured || $type !== 'product' ? '' : sanitize_key($get('ordina'));
    if (!isset($sorts[$sort])) $sort = '';
    $args = array_merge(array('post_type'=>$type,'post_status'=>'publish','posts_per_page'=>max(1,min(24,(int)$a['limit'])),'paged'=>$page,'s'=>$search), $sorts[$sort][1]);
    $tax = array();
    if ($category && $type === 'product') $tax[] = array('taxonomy'=>'product_cat','field'=>'slug','terms'=>$category);
    // In home: i prodotti segnati «In evidenza» in WooCommerce (la stellina nell'elenco prodotti).
    if ($featured && $type === 'product') $tax[] = array('taxonomy'=>'product_visibility','field'=>'name','terms'=>'featured');
    if ($tax) $args['tax_query'] = $tax;
    // Filtro prezzo del negozio: l'istogramma conta i prodotti di categoria e ricerca
    // scelte, senza il filtro prezzo, così mostra sempre tutta la gamma disponibile.
    $price = null;
    if (!$featured && $type === 'product') {
        $price = sweet_price_range($args, $get('prezzo_min'), $get('prezzo_max'));
        if ($price['from'] !== null || $price['to'] !== null) {
            $args['meta_query'] = array(array('key'=>'_price', 'value'=>array($price['from'] ?? 0, $price['to'] ?? $price['max']), 'compare'=>'BETWEEN', 'type'=>'DECIMAL(10,2)'));
        }
    }
    $query = new WP_Query($args);
    $count_text = sprintf(_n('%s risultato','%s risultati',$query->found_posts,'samsweetlab-child-theme'),number_format_i18n($query->found_posts));
    $results = function () use ($query, $featured, $page) { ?>
      <div class="catalog-grid"><?php foreach ($query->posts as $post) sweet_card($post); ?></div>
      <?php if (!$query->have_posts()) : ?><p class="empty-state"><?php esc_html_e('Nessun risultato. Prova un altro nome o un’altra categoria.', 'samsweetlab-child-theme'); ?></p><?php endif; ?>
      <?php if (!$featured && $query->max_num_pages > 1) : ?><nav class="pagination" aria-label="<?php esc_attr_e('Pagine del catalogo', 'samsweetlab-child-theme'); ?>"><?php echo wp_kses_post(paginate_links(array('base'=>add_query_arg('pagina','%#%'),'format'=>'','current'=>$page,'total'=>$query->max_num_pages,'add_fragment'=>'#catalogo','prev_text'=>'←','next_text'=>'→'))); ?></nav><?php endif; ?>
    <?php };
    ob_start();

    // Negozio: filtri in una colonna a sinistra che resta in vista mentre si scorre.
    if (!$featured && $type === 'product') :
        $base = sweet_page_url('ingredients');
        $link = function ($slug) use ($base, $search, $sort, $price) {
            $args = array_filter(array('categoria' => $slug, 'cerca' => $search, 'ordina' => $sort, 'prezzo_min' => (string) $price['from'], 'prezzo_max' => (string) $price['to']), 'strlen');
            return add_query_arg(array_map('rawurlencode', $args), $base) . '#catalogo';
        };
        ?>
    <div id="catalogo" class="catalog-wrap catalog-wrap--shop">
      <aside class="catalog-sidebar" aria-label="<?php esc_attr_e('Filtri del catalogo', 'samsweetlab-child-theme'); ?>">
        <form class="catalog-search" method="get" action="<?php echo esc_url($base); ?>#catalogo">
          <label><span><?php esc_html_e('Cerca nel catalogo', 'samsweetlab-child-theme'); ?></span><input type="search" name="cerca" value="<?php echo esc_attr($search); ?>" placeholder="<?php esc_attr_e('Nome o modello', 'samsweetlab-child-theme'); ?>"></label>
          <label class="catalog-sort"><span><?php esc_html_e('Ordina per', 'samsweetlab-child-theme'); ?></span><select name="ordina"><?php foreach ($sorts as $value => $sortItem) : ?><option value="<?php echo esc_attr($value); ?>" <?php selected($sort, $value); ?>><?php echo esc_html($sortItem[0]); ?></option><?php endforeach; ?></select></label>
          <?php echo sweet_price_filter($price); ?>
          <?php if ($category) : ?><input type="hidden" name="categoria" value="<?php echo esc_attr($category); ?>"><?php endif; ?>
          <button class="button" type="submit"><?php esc_html_e('Cerca', 'samsweetlab-child-theme'); ?> <span aria-hidden="true">↗</span></button>
        </form>
        <details class="catalog-cats" open>
          <summary><span class="eyebrow"><?php esc_html_e('Categorie', 'samsweetlab-child-theme'); ?></span><span class="catalog-cats-toggle" aria-hidden="true"></span></summary>
          <?php echo sweet_category_tree(sweet_catalog_categories(), $category, $link); ?>
        </details>
        <?php if ($category || $search || $sort || $price['from'] !== null || $price['to'] !== null) : ?><a class="text-link catalog-reset" href="<?php echo esc_url($base . '#catalogo'); ?>"><?php esc_html_e('Azzera i filtri', 'samsweetlab-child-theme'); ?> <span aria-hidden="true">×</span></a><?php endif; ?>
      </aside>
      <div class="catalog-main">
        <p class="result-count" role="status"><?php echo esc_html($count_text); ?></p>
        <?php $results(); ?>
      </div>
    </div>
    <?php else : ?>
    <div id="catalogo" class="catalog-wrap">
      <?php if (!$featured) : ?>
      <form class="catalog-filters" method="get" action="<?php echo esc_url(sweet_page_url($type === 'macchina' ? 'machines' : 'ingredients')); ?>#catalogo">
        <label><span><?php esc_html_e('Cerca nel catalogo', 'samsweetlab-child-theme'); ?></span><input type="search" name="cerca" value="<?php echo esc_attr($search); ?>" placeholder="<?php esc_attr_e('Nome o modello', 'samsweetlab-child-theme'); ?>"></label>
        <button class="button" type="submit"><?php esc_html_e('Cerca', 'samsweetlab-child-theme'); ?> <span aria-hidden="true">↗</span></button>
      </form>
      <p class="result-count"><?php echo esc_html($count_text); ?></p>
      <?php endif; ?>
      <?php $results(); ?>
    </div>
    <?php endif;
    return ob_get_clean();
});

/**
 * Gamma di prezzo per il filtro: limiti, valori scelti e istogramma.
 *
 * @param array  $args Argomenti della ricerca del catalogo (categoria, testo).
 * @param string $from Prezzo minimo chiesto, '' se nessuno.
 * @param string $to   Prezzo massimo chiesto, '' se nessuno.
 * @return array{min:int,max:int,from:?int,to:?int,bins:array}
 */
function sweet_price_range($args, $from, $to) {
    global $wpdb;
    $ids = (new WP_Query(array(
        'post_type' => 'product', 'post_status' => 'publish', 's' => $args['s'] ?? '',
        'tax_query' => $args['tax_query'] ?? array(), 'posts_per_page' => -1, 'fields' => 'ids',
        'no_found_rows' => true, 'orderby' => 'none', 'update_post_meta_cache' => false, 'update_post_term_cache' => false,
    )))->posts;
    $prices = array();
    if ($ids) {
        $prices = array_filter(array_map('floatval', $wpdb->get_col(
            "SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_price' AND meta_value <> '' AND post_id IN (" . implode(',', array_map('intval', $ids)) . ')'
        )));
    }
    // Il massimo arrotondato alla decina: la scala resta leggibile.
    $max = $prices ? (int) (ceil(max($prices) / 10) * 10) : 10;
    $bins = array_fill(0, 24, 0);
    $width = $max / 24;
    foreach ($prices as $p) $bins[min(23, (int) floor($p / $width))]++;
    $from = is_numeric($from) ? max(0, min($max, (int) floor((float) $from))) : null;
    $to   = is_numeric($to) ? max(0, min($max, (int) ceil((float) $to))) : null;
    if ($from === 0) $from = null;
    if ($to === $max) $to = null;
    if ($from !== null && $to !== null && $from > $to) list($from, $to) = array($to, $from);
    return array('min' => 0, 'max' => $max, 'from' => $from, 'to' => $to, 'bins' => $bins, 'width' => $width);
}

/** Filtro prezzo: istogramma, cursore a due maniglie, caselle minimo e massimo. */
function sweet_price_filter($price) {
    if (!$price) return '';
    $top = max(1, max($price['bins']));
    $lo = $price['from'] ?? $price['min'];
    $hi = $price['to'] ?? $price['max'];
    $currency = get_woocommerce_currency();
    ob_start(); ?>
    <fieldset class="price-filter" data-min="<?php echo (int) $price['min']; ?>" data-max="<?php echo (int) $price['max']; ?>">
      <legend><?php esc_html_e('Prezzo', 'samsweetlab-child-theme'); ?></legend>
      <div class="price-histogram" aria-hidden="true"><?php foreach ($price['bins'] as $i => $n) :
          $f = $i * $price['width']; $t = ($i + 1) * $price['width']; ?><span data-from="<?php echo esc_attr(round($f, 2)); ?>" data-to="<?php echo esc_attr(round($t, 2)); ?>" class="<?php echo ($t > $lo && $f < $hi) ? 'is-in' : ''; ?>" style="--h:<?php echo esc_attr(round($n / $top * 100)); ?>%"></span><?php endforeach; ?></div>
      <div class="price-range" hidden style="--lo:<?php echo esc_attr(round(($lo - $price['min']) / max(1, $price['max'] - $price['min']) * 100, 2)); ?>%;--hi:<?php echo esc_attr(round(($hi - $price['min']) / max(1, $price['max'] - $price['min']) * 100, 2)); ?>%">
        <input type="range" min="<?php echo (int) $price['min']; ?>" max="<?php echo (int) $price['max']; ?>" step="1" value="<?php echo (int) $lo; ?>" aria-label="<?php esc_attr_e('Prezzo minimo', 'samsweetlab-child-theme'); ?>">
        <input type="range" min="<?php echo (int) $price['min']; ?>" max="<?php echo (int) $price['max']; ?>" step="1" value="<?php echo (int) $hi; ?>" aria-label="<?php esc_attr_e('Prezzo massimo', 'samsweetlab-child-theme'); ?>">
      </div>
      <div class="price-inputs">
        <label><span><?php esc_html_e('Minimo', 'samsweetlab-child-theme'); ?></span><span class="price-input"><span aria-hidden="true"><?php echo esc_html($currency); ?></span><input type="number" name="prezzo_min" min="<?php echo (int) $price['min']; ?>" max="<?php echo (int) $price['max']; ?>" step="1" inputmode="numeric" value="<?php echo $price['from'] === null ? '' : (int) $price['from']; ?>" placeholder="<?php echo (int) $price['min']; ?>"></span></label>
        <label><span><?php esc_html_e('Massimo', 'samsweetlab-child-theme'); ?></span><span class="price-input"><span aria-hidden="true"><?php echo esc_html($currency); ?></span><input type="number" name="prezzo_max" min="<?php echo (int) $price['min']; ?>" max="<?php echo (int) $price['max']; ?>" step="1" inputmode="numeric" value="<?php echo $price['to'] === null ? '' : (int) $price['to']; ?>" placeholder="<?php echo (int) $price['max']; ?>"></span></label>
      </div>
    </fieldset>
    <?php return ob_get_clean();
}

/**
 * Albero delle categorie della colonna del negozio.
 *
 * Sempre visibili i primi due livelli; i rami più profondi si aprono solo lungo la
 * categoria scelta (i suoi antenati e i suoi figli), così la colonna resta corta.
 * Sono collegamenti normali: funziona anche senza JavaScript.
 */
function sweet_category_tree($terms, $active_slug, $link) {
    if (!$terms) return '';
    $by_id = array();
    foreach ($terms as $term) $by_id[$term->term_id] = $term;
    $children = array();
    foreach ($terms as $term) {
        $parent = isset($by_id[$term->parent]) ? $term->parent : 0;
        $children[$parent][] = $term;
    }
    // La strada dalla categoria scelta fino alla radice.
    $path = array();
    foreach ($terms as $term) {
        if ($term->slug !== $active_slug) continue;
        for ($t = $term; $t; $t = isset($by_id[$t->parent]) ? $by_id[$t->parent] : null) $path[$t->term_id] = true;
    }
    $render = function ($parent, $depth) use (&$render, $children, $path, $active_slug, $link) {
        if (empty($children[$parent])) return '';
        $html = '<ul class="catalog-cat-list catalog-cat-list--' . (int) $depth . '">';
        foreach ($children[$parent] as $term) {
            $current = $term->slug === $active_slug;
            $open = $depth === 0 || isset($path[$term->term_id]);
            $html .= '<li' . (isset($path[$term->term_id]) ? ' class="is-open"' : '') . '><a href="' . esc_url($link($term->slug)) . '"' . ($current ? ' aria-current="page"' : '') . '><span>' . esc_html($term->name) . '</span><span class="catalog-cat-count">' . esc_html(number_format_i18n($term->count)) . '</span></a>';
            if ($open) $html .= $render($term->term_id, $depth + 1);
            $html .= '</li>';
        }
        return $html . '</ul>';
    };
    $all = '<li><a href="' . esc_url($link('')) . '"' . ($active_slug === '' ? ' aria-current="page"' : '') . '><span>' . esc_html__('Tutte le categorie', 'samsweetlab-child-theme') . '</span></a></li>';
    $tree = $render(0, 0);
    return '<nav aria-label="' . esc_attr__('Categorie', 'samsweetlab-child-theme') . '"><ul class="catalog-cat-list catalog-cat-list--root">' . $all . '</ul>' . $tree . '</nav>';
}
add_shortcode('sweet_contact', function () {
    $contact = ticinoweb_get_contact_info();
    ob_start(); ?><div class="contact-grid">
    <?php if ($contact['email']) : ?><a class="contact-item" href="<?php echo esc_url('mailto:' . $contact['email']); ?>"><span class="eyebrow"><?php esc_html_e('Scrivici', 'samsweetlab-child-theme'); ?></span><strong><?php echo esc_html($contact['email']); ?></strong><span aria-hidden="true">↗</span></a><?php endif; ?>
    <?php if ($contact['phone']) : ?><a class="contact-item" href="<?php echo esc_url('tel:' . preg_replace('/[^+0-9]/','',$contact['phone'])); ?>"><span class="eyebrow"><?php esc_html_e('Chiamaci', 'samsweetlab-child-theme'); ?></span><strong><?php echo esc_html(get_option('ticinoweb_contact_phone_display') ?: $contact['phone']); ?></strong><span aria-hidden="true">↗</span></a><?php endif; ?>
    <?php if ($contact['address']) : ?><div class="contact-item"><span class="eyebrow"><?php esc_html_e('Dove siamo', 'samsweetlab-child-theme'); ?></span><strong><?php echo esc_html($contact['address']); ?></strong></div><?php endif; ?>
    <?php if ($contact['instagram']) : ?><a class="contact-item" href="<?php echo esc_url($contact['instagram']); ?>" target="_blank" rel="noopener"><span class="eyebrow"><?php esc_html_e('Seguici', 'samsweetlab-child-theme'); ?></span><strong><?php echo esc_html(sweet_instagram_handle($contact['instagram'])); ?></strong><span aria-hidden="true">↗</span></a><?php endif; ?>
    </div><?php return ob_get_clean();
});

/**
 * Il nome del profilo Instagram, «@nome», ricavato dall'indirizzo inserito nei
 * recapiti del CMS (ticinoWEB → Recapiti → Instagram).
 */
function sweet_instagram_handle($url) {
    $path = trim((string) wp_parse_url($url, PHP_URL_PATH), '/');
    $name = $path !== '' ? explode('/', $path)[0] : '';
    return $name !== '' ? '@' . $name : 'Instagram';
}
add_filter('manage_product_posts_columns', function ($columns) { $columns['sweet_language']=__('Lingua originale', 'samsweetlab-child-theme'); return $columns; });
add_filter('manage_macchina_posts_columns', function ($columns) { $columns['sweet_language']=__('Lingua originale', 'samsweetlab-child-theme'); return $columns; });
add_action('manage_product_posts_custom_column', 'sweet_admin_language', 10, 2);
add_action('manage_macchina_posts_custom_column', 'sweet_admin_language', 10, 2);
function sweet_admin_language($column, $id) { if ($column==='sweet_language') echo esc_html(strtoupper(get_post_meta($id,'_sweet_source_language',true))); }

// Native list filter keeps recovered translations easy to find without exposing drafts.
add_action('restrict_manage_posts', function ($type) {
    if (!in_array($type, array('product','macchina'), true)) return;
    $selected=sanitize_key($_GET['sweet_language']??'');
    $languages=array('it'=>'Italiano','en'=>'English','de'=>'Deutsch','fr'=>'Français','hu'=>'Magyar','ro'=>'Română','ru'=>'Русский','sk'=>'Slovenčina');
    echo '<label class="screen-reader-text" for="sweet-language">'.esc_html__('Lingua originale','samsweetlab-child-theme').'</label><select id="sweet-language" name="sweet_language"><option value="">'.esc_html__('Tutte le lingue','samsweetlab-child-theme').'</option>';
    foreach($languages as $code=>$label) echo '<option value="'.esc_attr($code).'" '.selected($selected,$code,false).'>'.esc_html($label).'</option>';
    echo '</select>';
});
add_action('pre_get_posts', function ($query) {
    if(!is_admin()||!$query->is_main_query()||!in_array($query->get('post_type'),array('product','macchina'),true)) return;
    $language=sanitize_key($_GET['sweet_language']??'');
    if(!in_array($language,array('it','en','de','fr','hu','ro','ru','sk'),true)) return;
    $meta=(array)$query->get('meta_query');$meta[]=array('key'=>'_sweet_source_language','value'=>$language);$query->set('meta_query',$meta);
});

// A catalog does not need order-attribution tracking.
add_filter('wc_order_attribution_allow_tracking', '__return_false');
add_action('wp_enqueue_scripts', function () { wp_dequeue_script('sourcebuster-js'); wp_dequeue_script('wc-order-attribution'); }, 100);

// La scheda prodotto ha un suo modello (single.php): zoom, galleria e varianti di
// WooCommerce non servono. Restano gli script del carrello: aggiunta senza ricaricare,
// cassa e account. Il contatore del carrello arriva con la risposta dell'aggiunta,
// quindi niente wc-cart-fragments, che interrogherebbe il server a ogni pagina.
// I nomi senza prefisso sono quelli delle versioni precedenti di WooCommerce.
add_action('wp_enqueue_scripts', function () {
    foreach (array(
        'wc-add-to-cart-variation', 'wc-cart-fragments', 'wc-single-product',
        'wc-zoom', 'wc-flexslider', 'wc-photoswipe', 'wc-photoswipe-ui-default',
        'zoom', 'flexslider', 'photoswipe', 'photoswipe-ui-default',
    ) as $handle) {
        wp_dequeue_script($handle);
    }
}, 100);

function sweet_shop_metadata($field, $fallback) {
    if (!function_exists('is_shop') || !is_shop()) return $fallback;
    $page=(int)get_option('woocommerce_shop_page_id');
    $value=$page?get_post_meta($page,$field,true):'';
    return $value?sweet_text($value,'shop:'.$field):$fallback;
}
add_filter('ticinoweb_seo_meta_description', function ($value) { return sweet_shop_metadata('_tw_seo_description',$value); });
add_filter('ticinoweb_seo_og_title', function ($value) { return sweet_shop_metadata('_tw_seo_title',$value); });
add_filter('ticinoweb_seo_document_title_parts', function ($parts) {
    $title=sweet_shop_metadata('_tw_seo_title','');
    if($title){$parts['title']=$title;unset($parts['site'],$parts['tagline']);}
    return $parts;
});
/*
 * Il tema madre, per un contenuto senza titolo SEO, mette nella scheda del browser
 * il titolo italiano grezzo, senza passare dalla traduzione. Nelle altre lingue si
 * usa il titolo tradotto da tW Translate Plus.
 */
add_filter('ticinoweb_seo_document_title_parts', function ($parts) {
    if (!is_singular() || is_front_page() || sweet_lang() === sweet_default_lang()) return $parts;
    $id = get_queried_object_id();
    if (!$id || get_post_meta($id, '_tw_seo_title', true)) return $parts;
    $parts['title'] = wp_strip_all_tags(get_the_title($id));
    return $parts;
}, 20);


/* ===================================================================
   Ricerca
   =================================================================== */

/** Cosa si cerca: le schede del catalogo e le pagine del sito. */
function sweet_search_post_types() {
    return array('macchina', 'product', 'page');
}

/* La pagina dei risultati mostra gli stessi tipi dei suggerimenti, e mai la home. */
add_action('pre_get_posts', function ($query) {
    if (is_admin() || !$query->is_main_query() || !$query->is_search()) return;
    $query->set('post_type', sweet_search_post_types());
    $query->set('post__not_in', array((int) get_option('page_on_front')));
    $query->set('posts_per_page', 24);
});

/**
 * Servizio dei suggerimenti: GET /wp-json/samsweetlab/v1/suggerimenti?q=…&lang=…
 *
 * Restituisce al massimo otto contenuti PUBBLICATI nella lingua chiesta: le schede
 * private, le bozze e le pagine con password non escono mai, nemmeno a chi è
 * collegato come amministratore. È sola lettura su contenuti già pubblici, quindi
 * non serve autenticazione.
 *
 * Le etichette (Macchina, Pagina, famiglia) non vengono tradotte qui: una richiesta
 * REST si carica con la lingua predefinita, e gettext risponderebbe in italiano.
 * Il servizio restituisce chiavi, e le traduce la pagina, che ha la lingua giusta.
 */
add_action('rest_api_init', function () {
    register_rest_route('samsweetlab/v1', '/indice', array(
        'methods'             => 'GET',
        'callback'            => 'sweet_search_index',
        'permission_callback' => '__return_true',
        'args'                => array(
            'lang' => array('type' => 'string', 'required' => false, 'sanitize_callback' => 'sanitize_key'),
        ),
    ));
    register_rest_route('samsweetlab/v1', '/suggerimenti', array(
        'methods'             => 'GET',
        'callback'            => 'sweet_search_suggestions',
        'permission_callback' => '__return_true',
        'args'                => array(
            'q'    => array('type' => 'string', 'required' => true, 'sanitize_callback' => 'sanitize_text_field'),
            'lang' => array('type' => 'string', 'required' => false, 'sanitize_callback' => 'sanitize_key'),
        ),
    ));
});

function sweet_search_suggestions(WP_REST_Request $request) {
    $q = trim(mb_substr((string) $request->get_param('q'), 0, 60));
    if (mb_strlen($q) < 2) return rest_ensure_response(array());

    $lingua = sweet_valid_lang((string) $request->get_param('lang'));

    $query = new WP_Query(array(
        'sweet_lang'             => $lingua,
        'post_type'              => sweet_search_post_types(),
        'post_status'            => 'publish',
        'has_password'           => false,
        's'                      => $q,
        'posts_per_page'         => 16,
        'post__not_in'           => array((int) get_option('page_on_front')),
        'no_found_rows'          => true,
        'ignore_sticky_posts'    => true,
        'update_post_term_cache' => false,
    ));

    // Prima i titoli che cominciano con quello che si sta scrivendo, poi quelli
    // che lo contengono, poi il resto (corrispondenze nel testo).
    $cercato = mb_strtolower($q);
    $voci = array();
    foreach ($query->posts as $ordine => $post) {
        $titolo = sweet_title_in($post, $lingua);
        $pos = mb_strpos(mb_strtolower($titolo), $cercato);
        $voci[] = array(
            'peso'   => $pos === 0 ? 0 : ($pos !== false ? 1 : 2),
            'ordine' => $ordine,
            'dati'   => array(
                'title'  => $titolo,
                'url'    => sweet_url_in($post, $lingua),
                'kind'   => $post->post_type,
                'family' => $post->post_type === 'macchina' ? sweet_machine_family_key($post->ID) : '',
                'image'  => (string) get_the_post_thumbnail_url($post, 'thumbnail'),
            ),
        );
    }
    usort($voci, function ($a, $b) { return $a['peso'] <=> $b['peso'] ?: $a['ordine'] <=> $b['ordine']; });

    $risposta = rest_ensure_response(array_map(function ($v) { return $v['dati']; }, array_slice($voci, 0, 8)));
    $risposta->header('Cache-Control', 'public, max-age=300');
    return $risposta;
}

/**
 * Indice per i suggerimenti: GET /wp-json/samsweetlab/v1/indice?lang=…
 *
 * Tutti i contenuti PUBBLICATI cercabili in quella lingua, con titolo, indirizzo,
 * tipo e foto. Il pannello lo scarica una volta sola all'apertura e poi filtra nel
 * browser a ogni lettera, quindi i suggerimenti seguono la battitura senza aspettare
 * il server. Oggi sono una ventina di voci per lingua; con tutto il catalogo
 * pubblicato diventano qualche centinaio, ancora poche decine di kilobyte.
 * Per la ricerca nel testo completo resta la pagina dei risultati.
 */
function sweet_search_index(WP_REST_Request $request) {
    $lingua = sweet_valid_lang((string) $request->get_param('lang'));

    $query = new WP_Query(array(
        'post_type'              => sweet_search_post_types(),
        'post_status'            => 'publish',
        'has_password'           => false,
        'posts_per_page'         => 2000,
        'post__not_in'           => array((int) get_option('page_on_front')),
        'orderby'                => 'title',
        'order'                  => 'ASC',
        'update_post_meta_cache' => true,
        'no_found_rows'          => true,
        'ignore_sticky_posts'    => true,
        'update_post_term_cache' => false,
    ));
    $voci = array();
    foreach ($query->posts as $post) {
        $voci[] = array(
            'title'  => sweet_title_in($post, $lingua),
            'url'    => sweet_url_in($post, $lingua),
            'kind'   => $post->post_type,
            'family' => $post->post_type === 'macchina' ? sweet_machine_family_key($post->ID) : '',
            'image'  => (string) get_the_post_thumbnail_url($post, 'thumbnail'),
        );
    }
    // Ordine alfabetico nella lingua chiesta: la query ordina sui titoli italiani.
    usort($voci, function ($a, $b) { return strcasecmp(remove_accents($a["title"]), remove_accents($b["title"])); });
    $risposta = rest_ensure_response($voci);
    $risposta->header('Cache-Control', 'public, max-age=600');
    return $risposta;
}

/* Le scritte del pannello, tradotte nella lingua della pagina, passate allo script. */
add_action('wp_enqueue_scripts', function () {
    $lingua = sweet_lang();
    $conteggi = array();
    for ($n = 0; $n <= 8; $n++) {
        $conteggi[$n] = sprintf(_n('%s risultato', '%s risultati', $n, 'samsweetlab-child-theme'), number_format_i18n($n));
    }
    $famiglie = array();
    foreach (array('Granite e sorbetti', 'Cuocicrema', 'Mantecatori', 'Creme fredde', 'Bevande calde') as $chiave) {
        $famiglie[$chiave] = sweet_machine_family_label($chiave);
    }
    wp_add_inline_script('samsweetlab-site', 'window.sweetSearch=' . wp_json_encode(array(
        'endpoint' => esc_url_raw(rest_url('samsweetlab/v1/suggerimenti')),
        'index'    => esc_url_raw(rest_url('samsweetlab/v1/indice')),
        'lang'     => $lingua ? $lingua : '',
        'kinds'    => array(
            'macchina' => __('Macchina', 'samsweetlab-child-theme'),
            'product'  => __('Ingredienti e accessori', 'samsweetlab-child-theme'),
            'page'     => __('Pagina', 'samsweetlab-child-theme'),
        ),
        'families' => $famiglie,
        'counts'   => $conteggi,
        /* translators: %s: il testo cercato */
        'none'     => __('Nessun risultato per «%s».', 'samsweetlab-child-theme'),
        // Il gelato che compare in basso quando si apre la ricerca: suggerisce la parola del gioco segreto.
        'hint'     => array(
            'word'  => 'samsweetlab',
            'badge' => __('Psst! Il gelato ha un segreto per te', 'samsweetlab-child-theme'),
            /* translators: %s: la parola segreta, samsweetlab (resta così in tutte le lingue) */
            'say'   => __('Hai provato a scrivere «%s» nella barra di ricerca?', 'samsweetlab-child-theme'),
            'fill'  => __('Scrivilo nella ricerca', 'samsweetlab-child-theme'),
            'close' => __('Chiudi', 'samsweetlab-child-theme'),
        ),
    )) . ';', 'before');
}, 21);

/**
 * Loghi. In alto c'è il logo del parent (ticinoWEB CMS → Look & Feel → Logo): quello orizzontale.
 * Il parent non ha un secondo logo, quindi la versione verticale per il piè di pagina si sceglie
 * in Aspetto → Personalizza → Identità del sito. Senza logo resta il nome del sito in testo.
 */
add_action('customize_register', function ($wp_customize) {
    $wp_customize->add_setting('sweet_footer_logo', array('default' => 0, 'sanitize_callback' => 'absint'));
    $wp_customize->add_control(new WP_Customize_Media_Control($wp_customize, 'sweet_footer_logo', array(
        'label'       => __('Logo del piè di pagina', 'samsweetlab-child-theme'),
        'description' => __('La versione verticale del logo, in fondo a ogni pagina. Il logo in alto si cambia in ticinoWEB CMS.', 'samsweetlab-child-theme'),
        'section'     => 'title_tagline',
        'mime_type'   => 'image',
    )));
});

/**
 * Un logo come <img> con larghezza e altezza vere, così la pagina non salta mentre arriva.
 * Sempre il file originale: le copie ridotte che fa WordPress sono ricompresse e perdono qualità.
 *
 * @param int|string $logo  ID dell'immagine, o il suo indirizzo (il campo del parent salva l'indirizzo).
 * @param array      $attrs Attributi in più (loading…).
 * @return string HTML già con escape, vuoto se il logo non c'è.
 */
function sweet_logo_img($logo, $attrs = array()) {
    $id  = is_numeric($logo) ? (int) $logo : ($logo ? attachment_url_to_postid((string) $logo) : 0);
    $src = $id ? wp_get_attachment_image_src($id, 'full') : false;
    $url = $src ? $src[0] : (is_numeric($logo) ? '' : (string) $logo);
    if (!$url) {
        return '';
    }
    $attrs = array_merge(array('src' => $url, 'alt' => get_bloginfo('name'), 'decoding' => 'async'), $src ? array('width' => $src[1], 'height' => $src[2]) : array(), $attrs);
    $html = '<img';
    foreach ($attrs as $name => $value) {
        $html .= ' ' . $name . '="' . ($name === 'src' ? esc_url($value) : esc_attr($value)) . '"';
    }
    return $html . '>';
}
