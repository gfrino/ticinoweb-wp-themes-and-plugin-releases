<?php
/**
 * Negozio: prezzi, carrello, cassa e testi di WooCommerce nella lingua della pagina.
 *
 * Carrello e cassa usano gli shortcode classici, non i blocchi: i blocchi leggono
 * prodotti, spedizioni e pagamenti dall'API JSON di WooCommerce, che tW Translate
 * Plus non traduce (non ha il prefisso della lingua). Gli shortcode li genera il
 * server, nella lingua della pagina.
 */
defined('ABSPATH') || exit;

/*
 * I fogli di stile di WooCommerce solo dove servono: carrello, cassa e account.
 * Altrove le schede hanno i modelli del tema, e il CSS di WooCommerce ridisegnerebbe
 * i pulsanti del tema (.woocommerce a.button) anche nelle schede prodotto.
 */
add_filter('woocommerce_enqueue_styles', function ($styles) {
    return (is_cart() || is_checkout() || is_account_page()) ? $styles : array();
});

/** Soglia della spedizione gratuita, letta dalle impostazioni (0 se non c'è). */
function sweet_free_shipping_min() {
    static $min = null;
    if ($min !== null) return $min;
    $min = 0.0;
    if (!class_exists('WC_Shipping_Zones')) return $min;
    foreach (WC_Shipping_Zones::get_zones() as $zone) {
        foreach ($zone['shipping_methods'] as $method) {
            if ($method->id === 'free_shipping' && $method->is_enabled() && (float) $method->get_option('min_amount') > 0) {
                $min = (float) $method->get_option('min_amount');
            }
        }
    }
    return $min;
}

/** Prezzo di un prodotto con la nota IVA, o «Prezzo su richiesta». */
function sweet_price($product) {
    if (!$product || $product->get_price() === '') {
        return '<p class="sweet-price sweet-price--request">' . esc_html__('Prezzo su richiesta', 'samsweetlab-child-theme') . '</p>';
    }
    return '<p class="sweet-price">' . $product->get_price_html() . ' <span class="sweet-price-note">' . esc_html__('IVA esclusa', 'samsweetlab-child-theme') . '</span></p>';
}

/** Pulsante «Aggiungi» delle schede: lo gestisce lo script di WooCommerce, senza ricaricare. */
function sweet_add_to_cart_button($product) {
    if (!$product || !$product->is_purchasable() || !$product->is_in_stock()) return '';
    $title = wp_strip_all_tags(get_the_title($product->get_id()));
    return sprintf(
        '<a href="%s" data-quantity="1" data-product_id="%d" data-product_sku="%s" data-product_name="%s" class="button sweet-add add_to_cart_button ajax_add_to_cart" aria-label="%s" rel="nofollow">%s <span aria-hidden="true">+</span></a>',
        esc_url($product->add_to_cart_url()),
        $product->get_id(),
        esc_attr($product->get_sku()),
        esc_attr($title),
        /* translators: %s: nome del prodotto */
        esc_attr(sprintf(__('Aggiungi «%s» al carrello', 'samsweetlab-child-theme'), $title)),
        esc_html__('Aggiungi', 'samsweetlab-child-theme')
    );
}

/** La città della sede, dall'indirizzo del negozio in WooCommerce (vuota se non impostata). */
function sweet_pickup_city() {
    return trim((string) get_option('woocommerce_store_city', ''));
}

/** I vantaggi del negozio, con gli importi presi dalle impostazioni. */
function sweet_shop_perks($class = '') {
    $min = sweet_free_shipping_min();
    $perks = array(
        array('truck', __('Consegna in tutta la Svizzera in 2-5 giorni lavorativi', 'samsweetlab-child-theme')),
        $min > 0 ? array('gift', sprintf(
            /* translators: %s: importo minimo, es. CHF 200.00 */
            __('Spedizione gratuita da %s', 'samsweetlab-child-theme'), wp_strip_all_tags(wc_price($min)))) : null,
        array('card', __('Paghi con carta o TWINT', 'samsweetlab-child-theme')),
        array('store', sweet_pickup_city() !== '' ? sprintf(
            /* translators: %s: città della sede (Impostazioni WooCommerce → Indirizzo del negozio) */
            __('Ritiro gratuito in sede a %s', 'samsweetlab-child-theme'), sweet_pickup_city()) : __('Ritiro gratuito in sede', 'samsweetlab-child-theme')),
    );
    $icons = array(
        'truck' => '<path d="M3 6h11v9H3zM14 9h4l3 3v3h-7" /><circle cx="7" cy="17" r="1.8"/><circle cx="17" cy="17" r="1.8"/>',
        'gift'  => '<path d="M4 10h16v10H4zM3 7h18v3H3zM12 7v13M12 7c-2-4-6-3-5 0M12 7c2-4 6-3 5 0"/>',
        'card'  => '<rect x="3" y="6" width="18" height="12" rx="1.5"/><path d="M3 10h18M7 15h4"/>',
        'store' => '<path d="M4 10v10h16V10M3 10l2-5h14l2 5zM10 20v-5h4v5"/>',
    );
    $html = '<ul class="sweet-perks ' . esc_attr($class) . '">';
    foreach (array_filter($perks) as $perk) {
        $html .= '<li><svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round" stroke-linecap="round">' . $icons[$perk[0]] . '</svg><span>' . esc_html($perk[1]) . '</span></li>';
    }
    return $html . '</ul>';
}

/** Riquadro d'acquisto della scheda prodotto: prezzo, quantità, pulsante, vantaggi. */
function sweet_purchase_box($product) {
    echo sweet_price($product);
    if ($product && $product->is_purchasable() && $product->is_in_stock()) : ?>
      <form class="cart sweet-buy" action="<?php echo esc_url(get_permalink($product->get_id())); ?>" method="post">
        <label class="sweet-qty"><span><?php esc_html_e('Quantità', 'samsweetlab-child-theme'); ?></span>
          <input type="number" name="quantity" value="1" min="1" max="999" step="1" inputmode="numeric" required></label>
        <button type="submit" name="add-to-cart" value="<?php echo esc_attr($product->get_id()); ?>" class="button single_add_to_cart_button"><?php esc_html_e('Aggiungi al carrello', 'samsweetlab-child-theme'); ?> <span aria-hidden="true">+</span></button>
      </form>
    <?php elseif ($product && $product->get_price() !== '') : ?>
      <p class="sweet-stock-out"><?php esc_html_e('Al momento non disponibile', 'samsweetlab-child-theme'); ?></p>
    <?php else : ?>
      <a class="button" href="<?php echo esc_url(sweet_page_url('contacts')); ?>"><?php esc_html_e('Richiedi un’offerta', 'samsweetlab-child-theme'); ?> <span aria-hidden="true">↗</span></a>
    <?php endif;
    echo sweet_shop_perks('sweet-perks--detail');
}

/** Carrello nell'intestazione, con il numero di articoli. */
function sweet_cart_link() {
    $count = (function_exists('WC') && WC()->cart) ? (int) WC()->cart->get_cart_contents_count() : 0;
    /* translators: %s: numero di articoli nel carrello */
    $label = sprintf(_n('Carrello, %s articolo', 'Carrello, %s articoli', $count, 'samsweetlab-child-theme'), number_format_i18n($count));
    printf(
        '<a class="cart-link" href="%s" aria-label="%s"><svg viewBox="0 0 24 24" width="21" height="21" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round" stroke-linecap="round"><path d="M5 8h14l-1.2 12H6.2z"/><path d="M9 8V6.5a3 3 0 0 1 6 0V8"/></svg><span class="cart-count"%s>%s</span></a>',
        esc_url(wc_get_cart_url()),
        esc_attr($label),
        $count ? '' : ' hidden',
        esc_html(number_format_i18n($count))
    );
}

/** Account nell'intestazione. */
function sweet_account_link() {
    printf(
        '<a class="account-link" href="%s" aria-label="%s"><svg viewBox="0 0 24 24" width="21" height="21" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><circle cx="12" cy="8.5" r="3.6"/><path d="M4.5 20c1.3-3.6 4.2-5.4 7.5-5.4s6.2 1.8 7.5 5.4"/></svg></a>',
        esc_url(wc_get_page_permalink('myaccount')),
        esc_attr(is_user_logged_in() ? __('Il mio account', 'samsweetlab-child-theme') : __('Accedi', 'samsweetlab-child-theme'))
    );
}

// Dopo un'aggiunta senza ricaricare, WooCommerce sostituisce questi pezzi di pagina.
add_filter('woocommerce_add_to_cart_fragments', function ($fragments) {
    ob_start();
    sweet_cart_link();
    $fragments['a.cart-link'] = ob_get_clean();
    return $fragments;
});

/* ---------------------------------------------------------------
 * Testi di WooCommerce salvati nelle impostazioni (in italiano):
 * qui passano dai dizionari del tema, nella lingua della pagina.
 * --------------------------------------------------------------- */

function sweet_shipping_label($method_id, $fallback) {
    switch ($method_id) {
        case 'flat_rate':     return __('Spedizione standard, 2-5 giorni lavorativi', 'samsweetlab-child-theme');
        case 'free_shipping': return __('Spedizione gratuita', 'samsweetlab-child-theme');
        case 'local_pickup':  return sweet_pickup_city() !== ''
            /* translators: %s: città della sede (Impostazioni WooCommerce → Indirizzo del negozio) */
            ? sprintf(__('Ritiro in sede a %s', 'samsweetlab-child-theme'), sweet_pickup_city())
            : __('Ritiro in sede', 'samsweetlab-child-theme');
    }
    return $fallback;
}

// Con la spedizione gratuita disponibile, la tariffa a pagamento non si propone più
// (il ritiro in sede resta).
add_filter('woocommerce_package_rates', function ($rates) {
    $free = array_filter($rates, function ($rate) { return $rate->get_method_id() === 'free_shipping'; });
    if (!$free) return $rates;
    return array_filter($rates, function ($rate) { return $rate->get_method_id() !== 'flat_rate'; });
}, 10);

// Il nome registrato nell'ordine.
add_filter('woocommerce_package_rates', function ($rates) {
    foreach ($rates as $rate) {
        $rate->set_label(sweet_shipping_label($rate->get_method_id(), $rate->get_label()));
    }
    return $rates;
}, 20);

// Il nome mostrato: le tariffe restano in sessione, quindi si ritraduce a ogni visualizzazione.
add_filter('woocommerce_cart_shipping_method_full_label', function ($label, $method) {
    $name = sweet_shipping_label($method->get_method_id(), $method->get_label());
    return $name === $method->get_label() ? $label : str_replace(esc_html($method->get_label()), esc_html($name), $label);
}, 20, 2);

add_filter('woocommerce_gateway_title', function ($title, $id = '') {
    switch ($id) {
        case 'stripe_cc':       return __('Carta di credito o di debito', 'samsweetlab-child-theme');
        case 'stripe_twint':    return 'TWINT';
        case 'stripe_applepay': return 'Apple Pay';
    }
    return $title;
}, 20, 2);

// «IVA 2,6%» e «IVA 8,1%»: due aliquote nello stesso carrello vanno distinte.
add_filter('woocommerce_rate_label', function ($label, $rate_id = 0) {
    if (!$rate_id) return $label;
    $percent = (float) WC_Tax::get_rate_percent_value($rate_id);
    /* translators: %s: aliquota, es. 2,6% */
    return sprintf(__('IVA %s', 'samsweetlab-child-theme'), number_format_i18n($percent, 1) . '%');
}, 20, 2);

add_filter('woocommerce_get_terms_and_conditions_checkbox_text', function () {
    /* translators: [terms] diventa il collegamento «termini e condizioni» di WooCommerce */
    return __('Ho letto e accetto i [terms]', 'samsweetlab-child-theme');
});

/*
 * Nomi dei prodotti in carrello, cassa e ordine. WooCommerce li prende dal prodotto
 * (get_name), senza passare dal filtro dei titoli che tW Translate Plus traduce: qui
 * si sostituiscono con il titolo nella lingua della pagina. Solo a video: l'ordine
 * resta registrato con i nomi italiani, come li vede il negozio.
 */
function sweet_translated_name($html, $product_id, $name) {
    if ($name === '' || sweet_lang() === sweet_default_lang()) return $html;
    $post = get_post($product_id);
    if (!$post) return $html;
    $title = sweet_title_in($post, sweet_lang());
    if ($title === '' || $title === $name) return $html;
    return str_replace(array(esc_html($name), $name), esc_html($title), $html);
}
add_filter('woocommerce_cart_item_name', function ($html, $item) {
    $product = isset($item['data']) ? $item['data'] : null;
    return $product ? sweet_translated_name($html, $product->get_id(), $product->get_name()) : $html;
}, 20, 2);
add_filter('woocommerce_order_item_name', function ($html, $item) {
    return is_callable(array($item, 'get_product_id')) ? sweet_translated_name($html, $item->get_product_id(), $item->get_name()) : $html;
}, 20, 2);

/*
 * Dopo il pagamento si torna alla conferma nella lingua in cui si è ordinato: la
 * richiesta che crea l'ordine è una chiamata AJAX e l'indirizzo arriverebbe senza
 * il prefisso della lingua. Vale anche per il ritorno da TWINT.
 */
add_filter('woocommerce_get_checkout_order_received_url', function ($url) {
    return function_exists('twtr_get_language_url') ? twtr_get_language_url(sweet_lang(), $url) : $url;
}, 20);

add_filter('woocommerce_get_privacy_policy_text', function ($text, $type = '') {
    if ($type === 'registration') {
        /* translators: [privacy_policy] diventa il collegamento all'informativa */
        return __('I tuoi dati servono per gestire il tuo account e sono trattati come descritto nella nostra [privacy_policy].', 'samsweetlab-child-theme');
    }
    /* translators: [privacy_policy] diventa il collegamento all'informativa */
    return __('I tuoi dati servono per gestire l’ordine e sono trattati come descritto nella nostra [privacy_policy].', 'samsweetlab-child-theme');
}, 20, 2);

/* ---------------------------------------------------------------
 * Home: la sezione dello shop. Testi nei dizionari del tema, così
 * resta tradotta nelle otto lingue senza toccare la pagina.
 * --------------------------------------------------------------- */
add_shortcode('sweet_shop_highlight', function () {
    ob_start(); ?>
    <section class="section shop-section wrap" aria-labelledby="sweet-shop-title">
      <div class="section-heading">
        <div>
          <p class="eyebrow"><?php esc_html_e('Shop online', 'samsweetlab-child-theme'); ?></p>
          <h2 id="sweet-shop-title"><?php echo wp_kses(__('Ordina online.<br>Lo ricevi in pochi giorni.', 'samsweetlab-child-theme'), array('br' => array())); ?></h2>
        </div>
        <p><a class="text-link" href="<?php echo esc_url(sweet_page_url('ingredients')); ?>"><?php esc_html_e('Tutto lo shop', 'samsweetlab-child-theme'); ?> <span aria-hidden="true">↗</span></a></p>
      </div>
      <?php echo do_shortcode('[sweet_catalog type="product" limit="6" featured="yes"]'); ?>
      <?php echo sweet_shop_perks('sweet-perks--band'); ?>
    </section>
    <?php return ob_get_clean();
});

/* Le scritte dell'avviso «aggiunto al carrello», nella lingua della pagina. */
add_action('wp_enqueue_scripts', function () {
    wp_add_inline_script('samsweetlab-site', 'window.sweetShop=' . wp_json_encode(array(
        'cart'  => esc_url_raw(wc_get_cart_url()),
        /* translators: %s: nome del prodotto */
        'added' => __('«%s» è nel carrello.', 'samsweetlab-child-theme'),
        'view'  => __('Vai al carrello', 'samsweetlab-child-theme'),
        'close' => __('Chiudi', 'samsweetlab-child-theme'),
    )) . ';', 'before');
}, 22);

/* ---------------------------------------------------------------
 * Home: nell'etichetta grande dell'apertura, al posto della foto, i
 * prodotti del negozio che si alternano (site.js li fa girare con GSAP).
 * Sono i prodotti «In evidenza» di WooCommerce con una foto, nella lingua
 * della pagina; se non ce ne sono, resta la foto messa nella pagina.
 * Senza JavaScript, o con «riduci animazioni», si vede il primo.
 * --------------------------------------------------------------- */
function sweet_hero_products($limit = 8) {
    if (!function_exists('wc_get_product')) return array();
    $query = new WP_Query(array(
        'post_type' => 'product', 'post_status' => 'publish', 'posts_per_page' => $limit,
        'orderby' => 'menu_order title', 'order' => 'ASC', 'no_found_rows' => true,
        'meta_query' => array(array('key' => '_thumbnail_id', 'compare' => 'EXISTS')),
        'tax_query' => array(array('taxonomy' => 'product_visibility', 'field' => 'name', 'terms' => 'featured')),
    ));
    return $query->posts;
}

add_filter('render_block', function ($html, $block) {
    if (empty($block['blockName']) || $block['blockName'] !== 'core/group' || !is_front_page()) return $html;
    if (empty($block['attrs']['className']) || strpos($block['attrs']['className'], 'hero-visual') === false) return $html;
    $products = sweet_hero_products();
    if (count($products) < 2) return $html;
    ob_start(); ?>
<figure class="wp-block-image hero-products" aria-label="<?php esc_attr_e('Prodotti in evidenza', 'samsweetlab-child-theme'); ?>"><div class="hero-products-track">
<?php foreach ($products as $i => $post) :
    $label = sweet_card_category($post->ID); ?>
  <a class="hero-product flavour-<?php echo esc_attr(sweet_flavour($post->ID)); ?><?php echo $i === 0 ? ' is-on' : ''; ?>" href="<?php echo esc_url(get_permalink($post)); ?>"<?php echo $i === 0 ? '' : ' tabindex="-1" aria-hidden="true"'; ?>>
    <?php echo get_the_post_thumbnail($post, 'large', array(
        'alt' => get_the_title($post),
        'sizes' => '(max-width: 1000px) 90vw, 46vw',
        'loading' => $i === 0 ? 'eager' : 'lazy',
        'fetchpriority' => $i === 0 ? 'high' : 'low',
        'decoding' => 'async',
    )); ?>
    <span class="hero-product-name"><?php if ($label !== '') : ?><small><?php echo esc_html($label); ?></small><?php endif; ?><?php echo esc_html(get_the_title($post)); ?> <span aria-hidden="true">↗</span></span>
  </a>
<?php endforeach; ?>
</div></figure>
<?php
    $figure = ob_get_clean();
    // Solo la prima figura del gruppo (la foto); l'adesivo tondo resta com'è.
    return preg_replace_callback('~<figure\b[^>]*>.*?</figure>~s', function () use ($figure) { return $figure; }, $html, 1);
}, 10, 2);
