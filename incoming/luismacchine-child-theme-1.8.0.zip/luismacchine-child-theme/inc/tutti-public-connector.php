<?php
/**
 * Read-only connector for Luismacchine's public tutti.ch seller inventory.
 *
 * The connector reads the seller profile and the public detail page of each
 * listing. It never signs in, posts data to tutti.ch or calls private API
 * routes. Imported images are copied into WordPress by tutti-sync-media.php.
 *
 * @package LuismacchineChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'LUISMACCHINE_TUTTI_DOCUMENT_LIMIT', 4 * MB_IN_BYTES );
define( 'LUISMACCHINE_TUTTI_DETAIL_CACHE_TTL', 7 * DAY_IN_SECONDS );

/**
 * Make the prepared synchronization available when this site has a seller ID.
 *
 * @param bool $available Current connector state.
 * @return bool
 */
function luismacchine_tutti_public_connector_available( $available ) {
	return $available || '' !== luismacchine_tutti_seller_id();
}
add_filter( 'luismacchine_tutti_connector_available', 'luismacchine_tutti_public_connector_available' );

/**
 * Supply a complete normalized inventory to the synchronization engine.
 *
 * @param mixed  $inventory Existing inventory value.
 * @param string $seller_id Configured seller identifier.
 * @return array|WP_Error
 */
function luismacchine_tutti_public_inventory( $inventory, $seller_id ) {
	if ( ! is_wp_error( $inventory ) ) {
		return $inventory;
	}

	$seller_id = preg_replace( '/[^0-9]/', '', (string) $seller_id );
	if ( '' === $seller_id ) {
		return new WP_Error( 'missing_seller_id', __( 'Manca l’ID del profilo venditore tutti.ch.', 'luismacchine-child-theme' ) );
	}

	$seller_url = add_query_arg( 'id', rawurlencode( $seller_id ), 'https://www.tutti.ch/it/seller' );
	$seller     = luismacchine_tutti_public_fetch_json( $seller_url );
	if ( is_wp_error( $seller ) ) {
		return $seller;
	}

	$listings = isset( $seller['props']['pageProps']['publicAccountData']['listings'] ) && is_array( $seller['props']['pageProps']['publicAccountData']['listings'] )
		? $seller['props']['pageProps']['publicAccountData']['listings']
		: array();
	$items    = isset( $listings['listings'] ) && is_array( $listings['listings'] ) ? $listings['listings'] : array();
	$total    = isset( $listings['totalCount'] ) ? absint( $listings['totalCount'] ) : count( $items );

	if ( 0 === $total || empty( $items ) ) {
		return new WP_Error( 'empty_seller_inventory', __( 'Il profilo tutti.ch non ha restituito annunci. Nessun prodotto è stato modificato.', 'luismacchine-child-theme' ) );
	}
	if ( $total !== count( $items ) ) {
		return new WP_Error( 'incomplete_seller_inventory', __( 'tutti.ch non ha restituito l’inventario completo. Nessun prodotto è stato modificato.', 'luismacchine-child-theme' ) );
	}

	$normalized = array();
	foreach ( $items as $summary ) {
		$external_id = isset( $summary['listingID'] ) ? preg_replace( '/[^0-9]/', '', (string) $summary['listingID'] ) : '';
		$updated_at  = isset( $summary['timestamp'] ) ? sanitize_text_field( $summary['timestamp'] ) : '';
		if ( '' === $external_id ) {
			return new WP_Error( 'invalid_seller_inventory', __( 'Un annuncio tutti.ch non contiene un ID valido. Nessun prodotto è stato modificato.', 'luismacchine-child-theme' ) );
		}

		$cache_key = 'lm_tutti_' . md5( $external_id . '|' . $updated_at );
		$item      = get_transient( $cache_key );
		if ( ! is_array( $item ) ) {
			$item = luismacchine_tutti_public_fetch_item( $external_id, $updated_at );
			if ( is_wp_error( $item ) ) {
				return $item;
			}
			set_transient( $cache_key, $item, LUISMACCHINE_TUTTI_DETAIL_CACHE_TTL );
		}

		$normalized[] = $item;
	}

	return array(
		'complete' => true,
		'items'    => $normalized,
	);
}
add_filter( 'luismacchine_tutti_inventory', 'luismacchine_tutti_public_inventory', 10, 2 );

/**
 * Fetch and normalize one public listing detail page.
 *
 * @param string $external_id Listing ID.
 * @param string $updated_at  Timestamp shown in the seller inventory.
 * @return array|WP_Error
 */
function luismacchine_tutti_public_fetch_item( $external_id, $updated_at ) {
	$source_url = 'https://www.tutti.ch/it/vi/' . rawurlencode( $external_id );
	$json       = luismacchine_tutti_public_fetch_json( $source_url );
	if ( is_wp_error( $json ) ) {
		return $json;
	}

	$queries = isset( $json['props']['pageProps']['dehydratedState']['queries'] ) && is_array( $json['props']['pageProps']['dehydratedState']['queries'] )
		? $json['props']['pageProps']['dehydratedState']['queries']
		: array();
	$listing = array();
	foreach ( $queries as $query ) {
		$candidate = isset( $query['state']['data']['listing'] ) && is_array( $query['state']['data']['listing'] ) ? $query['state']['data']['listing'] : array();
		if ( $candidate && $external_id === (string) ( $candidate['listingID'] ?? '' ) ) {
			$listing = $candidate;
			break;
		}
	}

	if ( empty( $listing ) ) {
		return new WP_Error(
			'listing_detail_missing',
			sprintf(
				/* translators: %s: tutti.ch listing ID. */
				__( 'Non è stato possibile leggere tutti i dati dell’annuncio %s. Nessun prodotto è stato modificato.', 'luismacchine-child-theme' ),
				$external_id
			)
		);
	}

	$localization = isset( $listing['localization'] ) && is_array( $listing['localization'] ) ? $listing['localization'] : array();
	$category     = isset( $listing['primaryCategory'] ) && is_array( $listing['primaryCategory'] ) ? $listing['primaryCategory'] : array();
	$seo          = isset( $listing['seoInformation'] ) && is_array( $listing['seoInformation'] ) ? $listing['seoInformation'] : array();
	$canonical    = isset( $seo['canonical'] ) ? esc_url_raw( $seo['canonical'] ) : $source_url;

	return array(
		'external_id'   => $external_id,
		'source_url'    => luismacchine_tutti_source_url_allowed( $canonical ) ? $canonical : $source_url,
		'category_key'  => luismacchine_tutti_public_category_key( $category ),
		'category_label'=> isset( $category['label'] ) ? sanitize_text_field( $category['label'] ) : '',
		'title'         => isset( $localization['title'] ) ? sanitize_text_field( $localization['title'] ) : '',
		'content'       => isset( $localization['body'] ) ? sanitize_textarea_field( $localization['body'] ) : '',
		'price'         => luismacchine_tutti_public_price( $listing ),
		'images'        => luismacchine_tutti_public_images( $listing ),
		'attributes'    => luismacchine_tutti_public_attributes( $listing ),
		'updated_at'    => $updated_at,
	);
}

/**
 * Download one allowed public HTML document and decode its Next.js payload.
 *
 * @param string $url Public tutti.ch URL.
 * @return array|WP_Error
 */
function luismacchine_tutti_public_fetch_json( $url ) {
	if ( ! luismacchine_tutti_source_url_allowed( $url ) ) {
		return new WP_Error( 'invalid_tutti_url', __( 'L’indirizzo tutti.ch configurato non è valido.', 'luismacchine-child-theme' ) );
	}

	$response = wp_safe_remote_get(
		$url,
		array(
			'timeout'             => 25,
			'redirection'         => 3,
			'limit_response_size' => LUISMACCHINE_TUTTI_DOCUMENT_LIMIT,
			'user-agent'          => 'LuismacchineInventorySync/1.0; ' . home_url( '/' ),
			'headers'             => array(
				'Accept'          => 'text/html,application/xhtml+xml',
				'Accept-Language' => 'it-CH,it;q=0.9',
			),
		)
	);
	if ( is_wp_error( $response ) ) {
		return new WP_Error( 'tutti_request_failed', __( 'tutti.ch non è raggiungibile in questo momento. Riprova più tardi.', 'luismacchine-child-theme' ) );
	}
	if ( 200 !== wp_remote_retrieve_response_code( $response ) ) {
		return new WP_Error( 'tutti_unexpected_response', __( 'tutti.ch ha restituito una risposta inattesa. Nessun prodotto è stato modificato.', 'luismacchine-child-theme' ) );
	}

	$body = wp_remote_retrieve_body( $response );
	if ( ! preg_match( '#<script[^>]+id=["\']__NEXT_DATA__["\'][^>]*>(.*?)</script>#s', $body, $match ) ) {
		return new WP_Error( 'tutti_payload_missing', __( 'Il formato della pagina tutti.ch è cambiato. Nessun prodotto è stato modificato.', 'luismacchine-child-theme' ) );
	}

	$decoded = json_decode( html_entity_decode( $match[1], ENT_QUOTES | ENT_HTML5, 'UTF-8' ), true );
	if ( ! is_array( $decoded ) ) {
		return new WP_Error( 'tutti_payload_invalid', __( 'I dati ricevuti da tutti.ch non sono validi. Nessun prodotto è stato modificato.', 'luismacchine-child-theme' ) );
	}

	return $decoded;
}

/**
 * Build a stable category path from the public listing category.
 *
 * @param array $category Category payload.
 * @return string
 */
function luismacchine_tutti_public_category_key( $category ) {
	$parts  = array();
	$parent = isset( $category['parent'] ) && is_array( $category['parent'] ) ? $category['parent'] : array();
	if ( ! empty( $parent['label'] ) ) {
		$parts[] = $parent['label'];
	} elseif ( ! empty( $parent['categoryID'] ) ) {
		$parts[] = $parent['categoryID'];
	}
	if ( ! empty( $category['label'] ) ) {
		$parts[] = $category['label'];
	} elseif ( ! empty( $category['categoryID'] ) ) {
		$parts[] = $category['categoryID'];
	}

	return luismacchine_tutti_normalize_category_key( implode( '-', $parts ) );
}

/**
 * Read the numeric price from a listing.
 *
 * @param array $listing Listing payload.
 * @return float|null
 */
function luismacchine_tutti_public_price( $listing ) {
	if ( isset( $listing['seoInformation']['numericPrice'] ) && is_numeric( $listing['seoInformation']['numericPrice'] ) ) {
		return (float) $listing['seoInformation']['numericPrice'];
	}

	$formatted = isset( $listing['formattedPrice'] ) ? (string) $listing['formattedPrice'] : '';
	$numeric   = preg_replace( '/[^0-9.]/', '', str_replace( array( "'", ' ' ), '', $formatted ) );
	return '' !== $numeric && is_numeric( $numeric ) ? (float) $numeric : null;
}

/**
 * Return only image URLs from the approved tutti.ch media hosts.
 *
 * @param array $listing Listing payload.
 * @return array
 */
function luismacchine_tutti_public_images( $listing ) {
	$images = array();
	foreach ( isset( $listing['images'] ) && is_array( $listing['images'] ) ? $listing['images'] : array() as $image ) {
		$url = isset( $image['rendition']['src'] ) ? esc_url_raw( $image['rendition']['src'] ) : '';
		if ( $url && luismacchine_tutti_image_url_allowed( $url ) ) {
			$images[] = $url;
		}
	}

	return array_values( array_unique( $images ) );
}

/**
 * Map public tutti.ch properties onto the catalog fields supported by the child.
 *
 * @param array $listing Listing payload.
 * @return array
 */
function luismacchine_tutti_public_attributes( $listing ) {
	$map = array(
		'cars_carAutoScoutBrand'            => 'brand',
		'cars_carAutoScoutModel'            => 'model',
		'cars_carAutoScoutRegistrationYear' => 'year',
		'cars_carAutoScoutMileage'          => 'mileage',
		'cars_carAutoScoutBodyType'         => 'body_type',
		'cars_carAutoScoutDoors'            => 'doors',
		'cars_carAutoScoutFuelType'         => 'fuel',
		'cars_carAutoScoutTransmissionType' => 'transmission',
		'cars_carAutoScoutHorsepower'       => 'power_ps',
		'cars_carAutoScoutPower'            => 'power_kw',
		'cars_itemCondition'                => 'vehicle_condition',
		'carAccessories_itemCondition'      => 'condition',
	);
	$attributes = array();

	foreach ( isset( $listing['properties'] ) && is_array( $listing['properties'] ) ? $listing['properties'] : array() as $property ) {
		$id    = isset( $property['listingPropertyID'] ) ? (string) $property['listingPropertyID'] : '';
		$value = isset( $property['text'] ) ? trim( (string) $property['text'] ) : '';
		if ( '' === $value || ! isset( $map[ $id ] ) ) {
			continue;
		}

		$key = $map[ $id ];
		if ( in_array( $key, array( 'mileage', 'doors', 'power_ps', 'power_kw' ), true ) ) {
			$digits = preg_replace( '/[^0-9]/', '', $value );
			if ( '' !== $digits ) {
				$attributes[ $key ] = absint( $digits );
			}
		} elseif ( in_array( $key, array( 'fuel', 'transmission' ), true ) ) {
			$attributes[ $key ] = sanitize_title( $value );
		} else {
			$attributes[ $key ] = sanitize_text_field( $value );
		}
	}

	return $attributes;
}
