<?php
/**
 * Fondazione DEMIAP child theme functions
 */

add_action('wp_enqueue_scripts', 'fondazionedemiap_enqueue_styles', 20);
function fondazionedemiap_enqueue_styles()
{
    // Enqueue parent theme stylesheet
    wp_enqueue_style('ticinoweb-parent-style', get_template_directory_uri() . '/style.css', array(), '1.0.0');

    // Google Font in una sola richiesta: Playfair Display (titoli), Plus Jakarta Sans (testo), Material Symbols (icone)
    wp_enqueue_style('fondazionedemiap-google-fonts', 'https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&family=Plus+Jakarta+Sans:ital,wght@0,200..800;1,200..800&family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap', array(), null);

    // Carica libreria AOS per animazioni su scroll
    wp_enqueue_style('aos-css', 'https://unpkg.com/aos@2.3.1/dist/aos.css', array(), '2.3.1');
    wp_enqueue_script('aos-js', 'https://unpkg.com/aos@2.3.1/dist/aos.js', array(), '2.3.1', true);

    // Enqueue Tailwind stylesheet
    wp_enqueue_style('fondazionedemiap-tailwind-style', get_stylesheet_directory_uri() . '/assets/css/tailwind.css', array(), filemtime(get_stylesheet_directory() . '/assets/css/tailwind.css'));

    // Enqueue child theme stylesheet (loads after parent and fonts)
    wp_enqueue_style('fondazionedemiap-child-style', get_stylesheet_directory_uri() . '/style.css', array('ticinoweb-parent-style', 'fondazionedemiap-google-fonts', 'aos-css', 'fondazionedemiap-tailwind-style'), wp_get_theme()->get('Version'));

    // Enqueue magic titles script
    wp_enqueue_script('fondazionedemiap-magic-titles', get_stylesheet_directory_uri() . '/js/magic-titles.js', array(), wp_get_theme()->get('Version'), true);

    // Modulo contatti: invia al gestore del parent (Invii Ricevuti, antispam, reCAPTCHA). Dipende da ticinoweb-ai-main, che riceve ajax_url e chiavi.
    wp_enqueue_script('fondazionedemiap-contact-form', get_stylesheet_directory_uri() . '/js/contact-form.js', array('ticinoweb-ai-main'), wp_get_theme()->get('Version'), true);

    // Link «Preferenze cookie» del footer: solo se il banner del parent è attivo
    if (get_option('tw_cookie_banner_enable')) {
        wp_enqueue_script('fondazionedemiap-cookie-preferences', get_stylesheet_directory_uri() . '/js/cookie-preferences.js', array(), wp_get_theme()->get('Version'), true);
    }
}

if (file_exists(get_stylesheet_directory() . '/inc/admin-attivita.php')) {
    require_once get_stylesheet_directory() . '/inc/admin-attivita.php';
}

// Genera automaticamente il menu One Page la prima volta se non esiste
function fondazionedemiap_setup_default_menu() {
    $menu_name = 'Menu DEMIAP';
    $menu_exists = wp_get_nav_menu_object( $menu_name );

    if( ! $menu_exists ){
        $menu_id = wp_create_nav_menu($menu_name);

        $items = [
            ['Home', '#home'],
            ['La Fondazione', '#fondazionetesto'],
            ['Chi Siamo', '#chisiamo'],
            ['Attività', '#attivitasociali'],
            ['Agenda', '#agenda'],
            ['Contatti', '#contatti'],
            ['Dona', '#donazioni']
        ];

        foreach ($items as $item) {
            wp_update_nav_menu_item($menu_id, 0, array(
                'menu-item-title' => $item[0],
                'menu-item-url' => home_url( '/' ) . $item[1], 
                'menu-item-status' => 'publish'
            ));
        }

        // Assegna il menu creato alla location "primary" se il tema genitore la espone
        $locations = get_theme_mod('nav_menu_locations');
        if (!is_array($locations)) {
            $locations = array();
        }
        $locations['primary'] = $menu_id;
        set_theme_mod('nav_menu_locations', $locations);
    }
}
add_action('init', 'fondazionedemiap_setup_default_menu');

 

/**
 * URL di un file della libreria Media cercato per slug (es. «sfondo-animato-hero-demiap-loop»).
 * Stringa vuota se il file non c'è.
 */
function fondazionedemiap_media_url_by_name($name, $mime)
{
    $key = 'media_url_' . $name;
    $url = wp_cache_get($key, 'fondazionedemiap');
    if (false === $url) {
        $ids = get_posts(array(
            'post_type'      => 'attachment',
            'post_status'    => 'inherit',
            'name'           => $name,
            'post_mime_type' => $mime,
            'posts_per_page' => 1,
            'fields'         => 'ids',
        ));
        $url = $ids ? (string) wp_get_attachment_url($ids[0]) : '';
        wp_cache_set($key, $url, 'fondazionedemiap', HOUR_IN_SECONDS);
    }
    return $url;
}

/**
 * Video della hero e sua immagine di copertina (poster): stanno nella libreria Media (non nel tema,
 * che l'aggiornamento sostituisce). Per cambiarli basta caricare in Media un video
 * «sfondo-animato-hero-demiap-loop» e un'immagine «sfondo-animato-hero-demiap-poster».
 * Filtri: demiap_hero_video_url, demiap_hero_poster_url.
 */
function fondazionedemiap_hero_video_url()
{
    return (string) apply_filters('demiap_hero_video_url', fondazionedemiap_media_url_by_name('sfondo-animato-hero-demiap-loop', 'video'));
}

function fondazionedemiap_hero_poster_url()
{
    return (string) apply_filters('demiap_hero_poster_url', fondazionedemiap_media_url_by_name('sfondo-animato-hero-demiap-poster', 'image'));
}
