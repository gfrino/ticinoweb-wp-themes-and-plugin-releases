<?php
/** Site header. @package WistariaChildTheme */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="theme-color" content="#ffffff">
	<link rel="preload" href="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/fonts/inter-variable.woff2' ); ?>" as="font" type="font/woff2" crossorigin>
	<link rel="preload" href="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/fonts/heebo-variable.woff2' ); ?>" as="font" type="font/woff2" crossorigin>
	<?php wp_head(); ?>
</head>
<body <?php body_class( 'wistaria-site' ); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#main"><?php esc_html_e( 'Vai al contenuto', 'wistaria-child-theme' ); ?></a>
<header class="site-header">
	<div class="site-header__inner">
		<div class="site-brand">
			<?php
			$logo_url = function_exists( 'ticinoweb_get_site_logo' ) ? ticinoweb_get_site_logo() : '';
			if ( $logo_url ) {
				?><a class="custom-logo-link" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"><img class="custom-logo" src="<?php echo esc_url( $logo_url ); ?>" alt="" width="66" height="66"></a><span class="site-brand__name"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></span><?php
			} else {
				printf( '<a href="%s" class="site-brand__text">%s</a>', esc_url( home_url( '/' ) ), esc_html( get_bloginfo( 'name' ) ) );
			}
			?>
		</div>
		<button class="nav-toggle" type="button" aria-controls="site-navigation" aria-expanded="false" hidden>
			<span class="nav-toggle__bars" aria-hidden="true"><span></span><span></span><span></span></span>
			<span><?php esc_html_e( 'Menu', 'wistaria-child-theme' ); ?></span>
		</button>
		<nav id="site-navigation" class="site-navigation" aria-label="<?php esc_attr_e( 'Navigazione principale', 'wistaria-child-theme' ); ?>">
			<?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'menu_class' => 'site-navigation__list', 'fallback_cb' => false ) ); ?>
			<a class="button button--mobile-nav" href="<?php echo esc_url( home_url( '/#contatti' ) ); ?>"><?php echo esc_html( wistaria_quote_label() ); ?></a>
		</nav>
		<a class="button button--header" href="<?php echo esc_url( home_url( '/#contatti' ) ); ?>"><?php echo esc_html( wistaria_quote_label() ); ?></a>
	</div>
</header>
