document.addEventListener('DOMContentLoaded', () => {
  const motion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const hero = document.querySelector('[data-hero-slides]');
  if (hero) {
    const slides = [...hero.querySelectorAll('.hero__slide')];
    let active = 0;
    let heroVisible = true;
    if (window.IntersectionObserver) {
      new IntersectionObserver(([entry]) => { heroVisible = entry.isIntersecting; }, { threshold: 0.05 }).observe(hero);
    }
    if (slides.length > 1) {
      window.setInterval(() => {
        if (motion.matches || !heroVisible || document.hidden) return;
        slides[active].classList.remove('is-active');
        active = (active + 1) % slides.length;
        slides[active].classList.add('is-active');
      }, 6500);
    }
  }

  const carousel = document.querySelector('[data-work-carousel]');
  const track = carousel?.querySelector('[data-carousel-track]');
  if (!carousel || !track) return;
  const originals = [...track.querySelectorAll('.work-carousel__item')];
  if (!originals.length) return;

  // Keep the repeat boundary aligned to complete columns at both 3 and 2 rows.
  const cycleItems = [...originals];
  while (cycleItems.length % 6 !== 0) {
    const filler = originals[cycleItems.length % originals.length].cloneNode(true);
    filler.setAttribute('aria-hidden', 'true');
    filler.tabIndex = -1;
    track.appendChild(filler);
    cycleItems.push(filler);
  }

  let cycleWidth = 0;
  for (const item of cycleItems) {
    const clone = item.cloneNode(true);
    clone.setAttribute('aria-hidden', 'true');
    clone.tabIndex = -1;
    track.appendChild(clone);
  }
  const measure = () => {
    const firstClone = track.children[cycleItems.length];
    cycleWidth = firstClone ? firstClone.getBoundingClientRect().left - track.children[0].getBoundingClientRect().left : 0;
  };
  measure();
  window.addEventListener('resize', measure, { passive: true });

  let visible = true;
  let focus = false;
  let pauseUntil = 0;
  let previous = 0;
  let autoPosition = carousel.scrollLeft;
  let lastAppliedScroll = carousel.scrollLeft;
  const dialog = document.querySelector('[data-work-lightbox]');
  if (window.IntersectionObserver) {
    new IntersectionObserver(([entry]) => { visible = entry.isIntersecting; }, { threshold: 0.05 }).observe(carousel);
  }
  const pauseBriefly = () => { pauseUntil = performance.now() + 3500; };
  const section = carousel.closest('.works-section') || carousel;
  section.addEventListener('focusin', (event) => { focus = event.target !== carousel && event.target.matches(':focus-visible'); });
  section.addEventListener('focusout', (event) => {
    if (!section.contains(event.relatedTarget)) focus = false;
  });
  let drag = null;
  let suppressClick = false;
  carousel.addEventListener('pointerdown', (event) => {
    if (event.pointerType !== 'mouse' || event.button !== 0) return;
    pauseBriefly();
    drag = { id: event.pointerId, x: event.clientX, left: carousel.scrollLeft, moved: false };
    event.preventDefault();
  });
  window.addEventListener('pointermove', (event) => {
    if (!drag || event.pointerId !== drag.id) return;
    const delta = event.clientX - drag.x;
    if (Math.abs(delta) > 5) {
      drag.moved = true;
      carousel.classList.add('is-dragging');
    }
    if (!drag.moved) return;
    event.preventDefault();
    let next = drag.left - delta;
    if (cycleWidth > 0) next = ((next % cycleWidth) + cycleWidth) % cycleWidth;
    carousel.scrollLeft = next;
  });
  const finishDrag = (event) => {
    if (!drag || event.pointerId !== drag.id) return;
    if (drag.moved) {
      suppressClick = true;
      window.setTimeout(() => { suppressClick = false; }, 150);
    }
    drag = null;
    carousel.classList.remove('is-dragging');
    pauseBriefly();
  };
  window.addEventListener('pointerup', finishDrag);
  window.addEventListener('pointercancel', finishDrag);
  carousel.addEventListener('dragstart', (event) => event.preventDefault());
  carousel.addEventListener('click', (event) => {
    if (!suppressClick) return;
    event.preventDefault();
    event.stopPropagation();
    suppressClick = false;
  }, true);
  const normalize = () => {
    if (cycleWidth > 0 && carousel.scrollLeft >= cycleWidth) carousel.scrollLeft -= cycleWidth;
    if (carousel.scrollLeft < 0) carousel.scrollLeft += cycleWidth;
    autoPosition = carousel.scrollLeft;
  };
  const tick = (time) => {
    if (!previous) previous = time;
    const elapsed = Math.min(time - previous, 64);
    previous = time;
    if (!motion.matches && visible && !document.hidden && !focus && !dialog?.open && !carousel.classList.contains('is-revealing') && time >= pauseUntil && cycleWidth) {
      if (Math.abs(carousel.scrollLeft - lastAppliedScroll) > 0.01) autoPosition = carousel.scrollLeft;
      autoPosition += elapsed * 0.085;
      if (autoPosition >= cycleWidth) autoPosition -= cycleWidth;
      carousel.scrollLeft = autoPosition;
      lastAppliedScroll = carousel.scrollLeft;
      // Preserve fractional movement when scrollLeft is rounded to whole pixels.
      track.style.transform = `translateX(${lastAppliedScroll - autoPosition}px)`;
    } else {
      track.style.transform = '';
      autoPosition = carousel.scrollLeft;
      lastAppliedScroll = autoPosition;
    }
    requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);

  carousel.addEventListener('keydown', (event) => {
    if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return;
    event.preventDefault();
    pauseBriefly();
    carousel.scrollBy({ left: (event.key === 'ArrowLeft' ? -1 : 1) * carousel.clientWidth * 0.7, behavior: motion.matches ? 'auto' : 'smooth' });
    window.setTimeout(normalize, 450);
  });

  const dialogImage = dialog?.querySelector('img');
  track.addEventListener('click', (event) => {
    const link = event.target.closest('[data-lightbox-image]');
    if (!link || !dialog || !dialogImage || !dialog.showModal) return;
    event.preventDefault();
    pauseBriefly();
    dialogImage.src = link.href;
    dialogImage.alt = link.dataset.imageAlt || '';
    dialog.showModal();
  });
  dialog?.querySelector('[data-lightbox-close]')?.addEventListener('click', () => dialog.close());
  dialog?.addEventListener('click', (event) => {
    if (event.target === dialog) dialog.close();
  });
  dialog?.addEventListener('close', () => {
    dialogImage.removeAttribute('src');
    pauseBriefly();
  });
});
