document.addEventListener('DOMContentLoaded', () => {
  const section = document.querySelector('.services-showcase');
  if (!section || !window.IntersectionObserver || !window.matchMedia) return;

  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  if (reducedMotion.matches) return;

  const targets = section.querySelectorAll('.section-heading, .services-showcase__choices, .services-showcase__desktop-photo');
  const animations = new Set();
  const observer = new IntersectionObserver((entries) => {
    for (const entry of entries) {
      if (!entry.isIntersecting) continue;
      const target = entry.target;
      observer.unobserve(target);
      if (reducedMotion.matches || target.matches(':focus-within') || typeof target.animate !== 'function') {
        target.classList.remove('services-reveal-pending');
        continue;
      }

      const animation = target.animate(
        [{ opacity: 0, transform: 'translateY(44px)' }, { opacity: 1, transform: 'translateY(0)' }],
        { duration: 950, easing: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)' }
      );
      target.classList.remove('services-reveal-pending');
      animations.add(animation);
      animation.finished.catch(() => {}).finally(() => animations.delete(animation));
      target.addEventListener('focusin', () => animation.cancel(), { once: true });
    }
  }, { rootMargin: '0px 0px -10% 0px', threshold: 0 });

  targets.forEach((target) => {
    // Do not change elements already visible when the page or an anchor loads.
    if (target.getBoundingClientRect().top < window.innerHeight || typeof target.animate !== 'function') return;
    target.classList.add('services-reveal-pending');
    target.addEventListener('focusin', () => {
      target.classList.remove('services-reveal-pending');
      observer.unobserve(target);
    }, { once: true });
    observer.observe(target);
  });
  reducedMotion.addEventListener('change', (event) => {
    if (event.matches) {
      observer.disconnect();
      targets.forEach((target) => target.classList.remove('services-reveal-pending'));
      animations.forEach((animation) => animation.cancel());
    }
  });
});
