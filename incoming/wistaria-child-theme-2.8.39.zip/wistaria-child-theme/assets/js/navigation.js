document.addEventListener('DOMContentLoaded', () => {
  const header = document.querySelector('.site-header');
  const toggle = header?.querySelector('.nav-toggle');
  const navigation = header?.querySelector('.site-navigation');
  if (!header || !toggle || !navigation) return;

  header.classList.add('has-js');
  toggle.hidden = false;
  if (document.body.classList.contains('home') && document.querySelector('.hero')) {
    const syncHeader = () => header.classList.toggle('is-over-hero', window.scrollY <= 4);
    syncHeader();
    window.addEventListener('scroll', syncHeader, { passive: true });
    window.addEventListener('pageshow', syncHeader);
  }
  const close = () => {
    header.classList.remove('is-open');
    toggle.setAttribute('aria-expanded', 'false');
  };
  toggle.addEventListener('click', () => {
    const open = !header.classList.contains('is-open');
    header.classList.toggle('is-open', open);
    toggle.setAttribute('aria-expanded', String(open));
  });
  navigation.addEventListener('click', (event) => {
    if (event.target.closest('a')) close();
  });
  const sectionIds = ['servizi', 'lavori', 'chi-siamo', 'contatti'];
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  let scrollFrame = 0;
  const scrollToSection = (target, animate = true) => {
    cancelAnimationFrame(scrollFrame);
    const destination = Math.max(0, window.scrollY + target.getBoundingClientRect().top - header.getBoundingClientRect().height + (target.id === 'servizi' ? 0 : 2));
    const start = window.scrollY;
    const distance = destination - start;
    if (!animate || reducedMotion.matches || Math.abs(distance) < 1) {
      window.scrollTo({ top: destination, behavior: 'instant' });
      return;
    }
    const duration = Math.min(1100, Math.max(500, 500 + Math.abs(distance) * 0.2));
    let started;
    const step = (time) => {
      if (started === undefined) started = time;
      const progress = Math.min((time - started) / duration, 1);
      window.scrollTo({ top: start + distance * (1 - Math.pow(1 - progress, 3)), behavior: 'instant' });
      if (progress < 1) scrollFrame = requestAnimationFrame(step);
    };
    scrollFrame = requestAnimationFrame(step);
  };
  // Preserve links to the section anchors used by the previous website.
  const legacyAnchors = { '#chisiamo': '#chi-siamo', '#contatto': '#contatti' };
  const normalizeLegacyAnchor = () => {
    const replacement = legacyAnchors[location.hash.toLowerCase()];
    if (!replacement) return;
    history.replaceState(history.state, '', location.pathname + location.search + replacement);
    const target = document.getElementById(replacement.slice(1));
    if (target && document.readyState === 'complete') scrollToSection(target, false);
    window.dispatchEvent(new HashChangeEvent('hashchange'));
  };
  window.addEventListener('hashchange', normalizeLegacyAnchor);
  normalizeLegacyAnchor();
  document.addEventListener('click', (event) => {
    const link = event.target.closest('a[href]');
    if (!link || event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || link.target || link.hasAttribute('download')) return;
    if (link.origin !== location.origin || link.pathname !== location.pathname || !sectionIds.includes(link.hash.slice(1))) return;
    const target = document.getElementById(link.hash.slice(1));
    if (!target) return;
    event.preventDefault();
    close();
    if (location.hash !== link.hash) history.pushState(null, '', link.hash);
    window.dispatchEvent(new HashChangeEvent('hashchange'));
    scrollToSection(target);
  });
  ['wheel', 'touchstart'].forEach((type) => window.addEventListener(type, () => cancelAnimationFrame(scrollFrame), { passive: true }));
  if (sectionIds.includes(location.hash.slice(1))) {
    const target = document.getElementById(location.hash.slice(1));
    if (target) window.addEventListener('load', () => scrollToSection(target, false), { once: true });
  }
  if (document.body.classList.contains('home')) {
    const homeLinks = [...navigation.querySelectorAll('.site-navigation__list > li > a')]
      .filter(link => link.origin === location.origin && link.pathname === location.pathname);
    const syncCurrentSection = () => {
      const hash = ['#servizi', '#lavori', '#chi-siamo', '#contatti'].includes(location.hash) ? location.hash : '';
      for (const link of homeLinks) {
        const current = link.hash === hash;
        link.parentElement.classList.toggle('current-menu-item', current);
        link.parentElement.classList.toggle('current_page_item', current);
        if (current) link.setAttribute('aria-current', hash ? 'location' : 'page');
        else link.removeAttribute('aria-current');
      }
    };
    window.addEventListener('hashchange', syncCurrentSection);
    syncCurrentSection();
  }
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && header.classList.contains('is-open')) {
      close();
      toggle.focus();
    }
  });
  window.matchMedia('(min-width: 801px)').addEventListener('change', close);

});
