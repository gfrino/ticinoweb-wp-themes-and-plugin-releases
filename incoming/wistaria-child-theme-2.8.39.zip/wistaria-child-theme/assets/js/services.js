document.addEventListener('DOMContentLoaded', () => {
  const section = document.querySelector('[data-services-showcase]');
  if (!section) return;

  const list = section.querySelector('[data-service-list]');
  const buttons = [...section.querySelectorAll('[data-service-button]')];
  const thumb = section.querySelector('[data-service-scroll-thumb]');
  const showAll = section.querySelector('[data-show-all-services]');
  const images = [...section.querySelectorAll('.services-showcase__image')];
  const desktopTitle = section.querySelector('[data-desktop-service-title]');
  const mobileTitle = section.querySelector('[data-mobile-service-title]');
  if (!list || !buttons.length) return;

  section.classList.add('has-js');
  buttons.forEach(button => { button.disabled = false; });

  const updateThumb = () => {
    if (!thumb) return;
    const remaining = list.scrollHeight - list.clientHeight;
    if (remaining <= 0) {
      thumb.style.height = '100%';
      thumb.style.transform = 'translateY(0)';
      return;
    }
    thumb.style.height = Math.max(34, list.clientHeight * list.clientHeight / list.scrollHeight) + 'px';
    thumb.style.transform = 'translateY(' + (list.scrollTop / remaining) * (list.clientHeight - thumb.offsetHeight) + 'px)';
  };

  const selectService = index => {
    const selected = buttons[index];
    if (!selected) return;
    buttons.forEach((button, buttonIndex) => {
      const active = buttonIndex === index;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-pressed', String(active));
    });

    const title = selected.querySelector('.services-showcase__name')?.textContent || '';
    for (const image of images) {
      if (selected.dataset.imageSrc) {
        image.srcset = selected.dataset.imageSrcset || '';
        image.src = selected.dataset.imageSrc;
        image.alt = selected.dataset.imageAlt || '';
      }
    }
    if (desktopTitle) desktopTitle.textContent = title;
    if (mobileTitle) mobileTitle.textContent = title;
  };

  buttons.forEach((button, index) => button.addEventListener('click', () => selectService(index)));
  list.addEventListener('scroll', updateThumb, { passive: true });
  window.addEventListener('resize', updateThumb, { passive: true });
  updateThumb();

  if (showAll) {
    showAll.addEventListener('click', () => {
      const expanded = section.classList.toggle('is-expanded');
      showAll.setAttribute('aria-expanded', String(expanded));
      showAll.textContent = expanded ? showAll.dataset.showLess : showAll.dataset.showMore;
      if (!expanded) {
        const selectedIndex = buttons.findIndex(button => button.classList.contains('is-active'));
        if (selectedIndex > 4) selectService(0);
      }
    });
  }
});
