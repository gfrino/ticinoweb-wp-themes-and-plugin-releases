document.addEventListener('DOMContentLoaded', () => {
  const config = window.wistariaForm;
  if (!config) return;
  document.querySelectorAll('[data-wistaria-form]').forEach((form) => {
    form.hidden = false;
    const status = form.querySelector('.contact-form__status');
    const button = form.querySelector('[type="submit"]');
    const clearErrors = () => {
      form.querySelectorAll('[aria-invalid="true"]').forEach((field) => { field.removeAttribute('aria-invalid'); field.removeAttribute('aria-describedby'); });
      form.querySelectorAll('.contact-form__field-error').forEach((error) => error.remove());
      status.className = 'contact-form__status';
      status.textContent = '';
    };
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      clearErrors();
      if (!form.reportValidity()) return;
      const originalLabel = button.textContent;
      button.disabled = true;
      button.textContent = config.sending;
      form.setAttribute('aria-busy', 'true');
      try {
        const tokenUrl = new URL(config.ajaxUrl);
        tokenUrl.searchParams.set('action', 'ticinoweb_form_token');
        const tokenResponse = await fetch(tokenUrl, { credentials: 'same-origin', cache: 'no-store' });
        const tokenData = await tokenResponse.json();
        if (!tokenResponse.ok || !tokenData.success || !tokenData.data?.token) throw new Error(config.connectionError);
        const payload = new FormData(form);
        payload.set('action', 'ticinoweb_submit_form');
        payload.set('token', tokenData.data.token);
        if (config.recaptchaSiteKey) {
          if (!window.grecaptcha) throw new Error(config.connectionError);
          const captchaToken = await new Promise((resolve, reject) => {
            window.grecaptcha.ready(() => window.grecaptcha.execute(config.recaptchaSiteKey, { action: 'contact' }).then(resolve, reject));
          });
          payload.set('recaptcha_token', captchaToken);
        }
        const response = await fetch(config.ajaxUrl, { method: 'POST', body: payload, credentials: 'same-origin', cache: 'no-store' });
        const result = await response.json();
        if (!response.ok || !result.success) {
          status.classList.add('is-error');
          status.textContent = result.data?.message || config.fallbackError;
          for (const [name, message] of Object.entries(result.data?.fields || {})) {
            const field = form.elements.namedItem(name);
            if (!field || !field.id) continue;
            field.setAttribute('aria-invalid', 'true');
            const error = document.createElement('span');
            error.className = 'contact-form__field-error';
            error.id = field.id + '-error';
            error.textContent = message;
            field.setAttribute('aria-describedby', error.id);
            field.insertAdjacentElement('afterend', error);
          }
          form.querySelector('[aria-invalid="true"]')?.focus();
          return;
        }
        form.reset();
        status.classList.add('is-success');
        status.textContent = result.data?.message || '';
      } catch (error) {
        status.classList.add('is-error');
        status.textContent = config.connectionError;
      } finally {
        button.disabled = false;
        button.textContent = originalLabel;
        form.removeAttribute('aria-busy');
      }
    });
  });
});
