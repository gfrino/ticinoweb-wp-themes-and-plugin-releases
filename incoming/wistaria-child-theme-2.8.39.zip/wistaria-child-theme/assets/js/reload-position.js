(() => {
  const navigation = performance.getEntriesByType?.('navigation')[0];
  if (navigation?.type !== 'reload' || !('scrollRestoration' in history)) return;

  // Prevent the browser from restoring the old scroll position over the active menu target.
  const previous = history.scrollRestoration;
  history.scrollRestoration = 'manual';
  window.addEventListener('load', () => {
    if (!location.hash || location.hash === '#home') {
      window.scrollTo({ top: 0, behavior: 'instant' });
    }
    requestAnimationFrame(() => requestAnimationFrame(() => {
      history.scrollRestoration = previous;
    }));
  }, { once: true });
})();
