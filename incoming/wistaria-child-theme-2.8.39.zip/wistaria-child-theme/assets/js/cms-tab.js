/** The child provides these fonts locally; use the existing CMS selectors. */
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('select[name^="ticinoweb_font_"]').forEach((select) => {
    const key = select.name.replace('ticinoweb_font_', '');
    const current = window.wistariaCmsFonts?.[key];
    select.replaceChildren(new Option('Inter', 'Inter'), new Option('Heebo', 'Heebo'));
    select.value = current === 'Heebo' ? 'Heebo' : 'Inter';
  });
});

// Extend the existing Chi Siamo form with its second photo.
document.addEventListener('DOMContentLoaded', () => {
  const first = document.getElementById('ticinoweb_chi_siamo_image');
  const template = document.getElementById('wistaria-about-detail-template');
  if (!first || !template) return;
  first.closest('tr').after(template.content.cloneNode(true));
  const upload = document.getElementById('wistaria-about-detail-upload');
  const input = document.getElementById('wistaria-about-detail-image');
  const preview = document.getElementById('wistaria-about-detail-preview');
  upload.addEventListener('click', () => {
    const frame = wp.media({ title: template.dataset.pickerTitle, multiple: false, library: { type: 'image' } });
    frame.on('select', () => {
      const image = frame.state().get('selection').first().toJSON();
      input.value = image.url;
      const img = document.createElement('img');
      img.src = image.url; img.alt = ''; img.style.maxWidth = '300px'; img.style.height = 'auto';
      preview.replaceChildren(img);
    });
    frame.open();
  });
  input.addEventListener('input', () => { if (!input.value) preview.replaceChildren(); });
});
