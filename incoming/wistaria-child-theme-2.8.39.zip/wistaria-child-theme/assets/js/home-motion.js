document.addEventListener('DOMContentLoaded', () => {
  if (!window.IntersectionObserver || !window.matchMedia) return;
  const motion = window.matchMedia('(prefers-reduced-motion: reduce)');
  if (motion.matches) return;

  const running = new Set();
  const targets = document.querySelectorAll('.works-section > .section-heading, .about-preview__content, .about-preview__photos, .home-faq__intro, .home-faq__items, .home-contact-section .contact-page__intro, .home-contact-section .contact-page__quick, .home-contact-section .contact-map, .home-contact-section .contact-panel');
  const options = { duration: 950, easing: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)' };
  const play = (target, frames, settings) => {
    const animation = target.animate(frames, settings);
    running.add(animation);
    animation.finished.catch(() => {}).finally(() => running.delete(animation));
    target.addEventListener('focusin', () => animation.cancel(), { once: true });
    return animation;
  };
  const observer = new IntersectionObserver((entries) => {
    for (const entry of entries) {
      if (!entry.isIntersecting) continue;
      const target = entry.target;
      observer.unobserve(target);
      if (!motion.matches && !target.matches(':focus-within')) {
        play(target, [{ opacity: 0, transform: 'translateY(44px)' }, { opacity: 1, transform: 'translateY(0)' }], options);
      }
      target.classList.remove('home-motion-pending');
    }
  }, { rootMargin: '0px 0px -10% 0px', threshold: 0 });
  targets.forEach((target) => {
    if (target.getBoundingClientRect().top < window.innerHeight || typeof target.animate !== 'function') return;
    target.classList.add('home-motion-pending');
    target.addEventListener('focusin', () => {
      target.classList.remove('home-motion-pending');
      observer.unobserve(target);
    }, { once: true });
    observer.observe(target);
  });

  const gallery = document.querySelector('[data-work-carousel]');
  let galleryObserver;
  let galleryItems = [];
  const stopGallery = () => {
    galleryObserver?.disconnect();
    galleryItems.forEach((item) => item.classList.remove('work-motion-pending'));
    gallery?.classList.remove('is-revealing');
  };
  if (gallery && gallery.getBoundingClientRect().top >= window.innerHeight) {
    const bounds = gallery.getBoundingClientRect();
    galleryItems = [...gallery.querySelectorAll('.work-carousel__item')]
      .filter((item) => {
        const rect = item.getBoundingClientRect();
        return rect.right > bounds.left && rect.left < bounds.right && typeof item.animate === 'function';
      });
    galleryItems.forEach((item) => item.classList.add('work-motion-pending'));
    galleryObserver = new IntersectionObserver(([entry]) => {
      if (!entry.isIntersecting) return;
      galleryObserver.disconnect();
      gallery.classList.add('is-revealing');
      const started = galleryItems.map((item, index) => {
        const animation = play(item, [{ opacity: 0, translate: '70px 0' }, { opacity: 1, translate: '0px 0' }], { ...options, delay: Math.min(index * 65, 900), fill: 'backwards' });
        item.classList.remove('work-motion-pending');
        return animation.finished.catch(() => {});
      });
      Promise.all(started).then(() => gallery.classList.remove('is-revealing'));
    }, { rootMargin: '0px 0px -10% 0px', threshold: 0 });
    galleryObserver.observe(gallery);
    gallery.addEventListener('focusin', (event) => {
      // Scrolling can focus the gallery itself; only a focused photo needs immediate visibility.
      if (event.target === gallery) return;
      stopGallery();
      galleryItems.forEach((item) => item.getAnimations().forEach((animation) => animation.cancel()));
    });
  }
  motion.addEventListener('change', (event) => {
    if (!event.matches) return;
    observer.disconnect();
    targets.forEach((target) => target.classList.remove('home-motion-pending'));
    stopGallery();
    running.forEach((animation) => animation.cancel());
  });
});
