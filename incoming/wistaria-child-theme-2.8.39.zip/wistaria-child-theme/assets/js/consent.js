(function () {
	'use strict';
	function cookie(name) {
		var item = document.cookie.split('; ').find(function (part) { return part.indexOf(name + '=') === 0; });
		try { return item ? decodeURIComponent(item.slice(name.length + 1)) : ''; } catch (error) { return ''; }
	}
	function updateMap() {
		var frame = document.querySelector('.contact-map__frame');
		if (!frame) return;
		var allowed = cookie('wistaria_cookie_consent') === 'accepted';
		if (cookie('wistaria_cookie_consent') === 'custom') {
			try { allowed = JSON.parse(cookie('wistaria_cookie_preferences')).marketing === true; } catch (error) { allowed = false; }
		}
		if (allowed && !frame.getAttribute('src')) {
			frame.setAttribute('src', frame.dataset.src);
			frame.hidden = false;
			frame.previousElementSibling.hidden = true;
		}
	}
	document.addEventListener('DOMContentLoaded', function () {
		var text = document.querySelector('.tw-cookie-text');
		if (text && text.firstChild) text.firstChild.nodeValue = wistariaConsent.message;
		var category = document.getElementById('tw-cookie-opt-marketing-label');
		if (category) {
			category.textContent = wistariaConsent.category;
			category.nextElementSibling.textContent = wistariaConsent.description;
		}
		['tw-cookie-opt-analytics', 'tw-cookie-opt-marketing'].forEach(function (id) {
			var input = document.getElementById(id);
			if (input) input.checked = false;
		});
		['tw-cookie-accept', 'tw-cookie-save-preferences'].forEach(function (id) {
			var button = document.getElementById(id);
			if (button) button.addEventListener('click', function () { setTimeout(updateMap, 0); });
		});
		var settings = document.querySelector('.site-footer__cookie-settings');
		if (settings) settings.addEventListener('click', function () {
			['wistaria_cookie_consent', 'wistaria_cookie_preferences'].forEach(function (name) {
				document.cookie = name + '=; Max-Age=0; path=/; SameSite=Lax';
			});
			window.location.reload();
		});
		updateMap();
	});
}());
