(() => {
	const photos = document.querySelector('[data-about-photos]');
	if (!photos) return;

	const main = photos.querySelector('[data-about-main]');
	const detail = photos.querySelector('[data-about-detail]');
	if (!main?.querySelector('img') || !detail?.querySelector('img')) return;

	main.disabled = false;
	detail.disabled = false;

	const swap = () => {
		const mainImage = main.querySelector('img');
		const detailImage = detail.querySelector('img');
		main.replaceChildren(detailImage);
		detail.replaceChildren(mainImage);
		photos.classList.remove('is-swapping');
		void photos.offsetWidth;
		photos.classList.add('is-swapping');
	};

	main.addEventListener('click', swap);
	detail.addEventListener('click', swap);
})();
