<?php
/** Wistaria-specific fields inside the existing ticinoWEB CMS screen. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** The parent remains the source for services, slides, contacts, logo and brand colors. */
function wistaria_cms_fields() {
	return array(
		'services_heading'      => array( 'label' => __( 'Titolo Servizi', 'wistaria-child-theme' ), 'default' => __( 'I nostri servizi', 'wistaria-child-theme' ) ),
		'services_intro'        => array( 'label' => __( 'Introduzione Servizi', 'wistaria-child-theme' ), 'default' => __( 'Costruzione e cura di giardini, parchi e spazi verdi.', 'wistaria-child-theme' ) ),
		'works_heading'         => array( 'label' => __( 'Titolo Lavori', 'wistaria-child-theme' ), 'default' => __( 'I nostri lavori', 'wistaria-child-theme' ) ),
		'works_intro'           => array( 'label' => __( 'Introduzione Lavori', 'wistaria-child-theme' ), 'default' => '' ),
		'about_lead'            => array( 'label' => __( 'Sottotitolo Chi siamo', 'wistaria-child-theme' ), 'default' => __( 'Costruiamo e curiamo giardini, parchi e spazi verdi.', 'wistaria-child-theme' ) ),
		'about_fact_one'        => array( 'label' => __( 'Primo dato Chi siamo', 'wistaria-child-theme' ), 'default' => '' ),
		'about_fact_two'        => array( 'label' => __( 'Secondo dato Chi siamo', 'wistaria-child-theme' ), 'default' => '' ),
		'about_cta'             => array( 'label' => __( 'Pulsante Chi siamo', 'wistaria-child-theme' ), 'default' => __( 'Parliamo del tuo giardino', 'wistaria-child-theme' ) ),
		'contact_heading'       => array( 'label' => __( 'Titolo Contatti', 'wistaria-child-theme' ), 'default' => __( 'Contatti', 'wistaria-child-theme' ) ),
		'contact_form_heading'  => array( 'label' => __( 'Titolo modulo', 'wistaria-child-theme' ), 'default' => __( 'Parliamo del tuo progetto', 'wistaria-child-theme' ) ),
		'contact_form_intro'    => array( 'label' => __( 'Introduzione modulo', 'wistaria-child-theme' ), 'default' => __( 'Descrivi il lavoro o il servizio di cui hai bisogno.', 'wistaria-child-theme' ) ),
		'surface'               => array( 'label' => __( 'Sfondo principale', 'wistaria-child-theme' ), 'default' => '#ffffff', 'type' => 'color' ),
		'soft'                  => array( 'label' => __( 'Sfondo sezioni alternate', 'wistaria-child-theme' ), 'default' => '#f3f7ef', 'type' => 'color' ),
		'border'                => array( 'label' => __( 'Bordi discreti', 'wistaria-child-theme' ), 'default' => '#dbe6d7', 'type' => 'color' ),
		'muted'                 => array( 'label' => __( 'Testo secondario', 'wistaria-child-theme' ), 'default' => '#41564a', 'type' => 'color' ),
		'container'             => array( 'label' => __( 'Larghezza contenuto (px)', 'wistaria-child-theme' ), 'default' => 1180, 'type' => 'number' ),
	);
}

function wistaria_cms_value( $key ) {
	$fields = wistaria_cms_fields();
	if ( ! isset( $fields[ $key ] ) ) {
		return '';
	}
	return get_option( 'wistaria_' . $key, $fields[ $key ]['default'] );
}

/** A second photograph is specific to the Wistaria layout. */
add_action( 'admin_init', static function () {
	register_setting( 'ticinoweb_settings_group', 'wistaria_about_detail_image', array(
		'sanitize_callback' => static function ( $value ) {
			if ( null === $value || ! current_user_can( 'manage_options' ) ) {
				return get_option( 'wistaria_about_detail_image', '' );
			}
			return esc_url_raw( $value );
		},
	) );
} );

add_action( 'admin_footer-toplevel_page_ticinoweb-cms', static function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$images = wistaria_gallery_images( 'chi-siamo-wistaria' );
	$value = get_option( 'wistaria_about_detail_image', false );
	$url = false === $value && ! empty( $images[1] ) ? wp_get_attachment_url( $images[1] ) : $value;
	?>
	<template id="wistaria-about-detail-template" data-picker-title="<?php esc_attr_e( 'Seleziona la seconda immagine', 'wistaria-child-theme' ); ?>">
		<tr><th scope="row"><label for="wistaria-about-detail-image"><?php esc_html_e( 'Seconda immagine', 'wistaria-child-theme' ); ?></label></th>
		<td><input type="url" class="regular-text" id="wistaria-about-detail-image" name="wistaria_about_detail_image" value="<?php echo esc_attr( $url ); ?>">
		<button type="button" class="button button-secondary" id="wistaria-about-detail-upload"><?php esc_html_e( 'Carica immagine', 'wistaria-child-theme' ); ?></button>
		<div id="wistaria-about-detail-preview" style="margin-top:10px"><?php if ( $url ) : ?><img src="<?php echo esc_url( $url ); ?>" alt="" style="max-width:300px;height:auto"><?php endif; ?></div></td></tr>
	</template>
	<?php
} );
