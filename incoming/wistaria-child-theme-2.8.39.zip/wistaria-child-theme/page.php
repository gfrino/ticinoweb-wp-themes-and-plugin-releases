<?php
/** Generic pages such as the legal notices. @package WistariaChildTheme */
get_header();
?>
<main id="main" class="page-shell page-shell--text">
	<?php while ( have_posts() ) : the_post(); ?>
		<article <?php post_class( 'prose-page' ); ?>>
			<h1><?php the_title(); ?></h1>
			<div class="prose-page__content"><?php the_content(); ?></div>
		</article>
	<?php endwhile; ?>
</main>
<?php get_footer(); ?>
