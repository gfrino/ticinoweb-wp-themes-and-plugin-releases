<?php
/** Homepage FAQ, selected in the parent theme's page FAQ box. */
$faq_ref = get_post_meta( get_the_ID(), '_tw_faq_page_set', true );
$faq = $faq_ref && function_exists( 'ticinoweb_faq_get_set' ) ? ticinoweb_faq_get_set( $faq_ref ) : null;
if ( empty( $faq['items'] ) ) {
	return;
}
$items = array_values( array_filter( $faq['items'], static function ( $item ) {
	return ! empty( $item['question'] ) && trim( wp_strip_all_tags( $item['answer'] ) ) !== '';
} ) );
if ( ! $items ) {
	return;
}
if ( function_exists( 'ticinoweb_faq_schema_add' ) ) {
	ticinoweb_faq_schema_add( $items );
}
?>
<section class="home-section home-faq" id="faq" aria-labelledby="home-faq-title">
	<div class="page-shell home-faq__layout">
		<div class="home-faq__intro">
			<h2 id="home-faq-title"><?php echo esc_html( $faq['title'] ); ?></h2>
			<?php if ( $faq['intro'] ) : ?><p><?php echo esc_html( $faq['intro'] ); ?></p><?php endif; ?>
		</div>
		<div class="home-faq__items">
			<?php foreach ( $items as $index => $item ) : ?>
				<details class="home-faq__item"<?php echo 0 === $index ? ' open' : ''; ?>>
					<summary><span><?php echo esc_html( $item['question'] ); ?></span><span class="home-faq__icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M5 12h14"/><path class="home-faq__plus" d="M12 5v14"/></svg></span></summary>
					<div class="home-faq__answer"><?php echo wp_kses_post( wpautop( $item['answer'] ) ); ?></div>
				</details>
			<?php endforeach; ?>
		</div>
	</div>
</section>
