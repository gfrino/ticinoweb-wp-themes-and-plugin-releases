<?php
/** Shared contact form using the parent theme's submission endpoint. @package WistariaChildTheme */
$email = sanitize_email( (string) get_option( 'ticinoweb_contact_email', '' ) );
$privacy = get_privacy_policy_url();
?>
<div class="contact-panel" id="modulo">
	<div class="contact-panel__intro">
		<h2><?php echo esc_html( wistaria_cms_value( 'contact_form_heading' ) ); ?></h2>
		<p><?php echo esc_html( wistaria_cms_value( 'contact_form_intro' ) ); ?></p>
		<?php if ( $email ) : ?><p><?php esc_html_e( 'Puoi anche scriverci a', 'wistaria-child-theme' ); ?> <a href="<?php echo esc_url( 'mailto:' . $email ); ?>"><?php echo esc_html( $email ); ?></a>.</p><?php endif; ?>
	</div>
	<form class="contact-form" data-wistaria-form hidden>
		<div class="contact-form__row">
			<div><label for="wistaria-nome-<?php echo esc_attr( get_the_ID() ); ?>"><?php esc_html_e( 'Nome', 'wistaria-child-theme' ); ?> <span aria-hidden="true">*</span></label><input id="wistaria-nome-<?php echo esc_attr( get_the_ID() ); ?>" name="nome" type="text" autocomplete="name" required minlength="2"></div>
			<div><label for="wistaria-email-<?php echo esc_attr( get_the_ID() ); ?>"><?php esc_html_e( 'Email', 'wistaria-child-theme' ); ?> <span aria-hidden="true">*</span></label><input id="wistaria-email-<?php echo esc_attr( get_the_ID() ); ?>" name="email" type="email" autocomplete="email" spellcheck="false" required></div>
		</div>
		<div class="contact-form__row">
			<div><label for="wistaria-telefono-<?php echo esc_attr( get_the_ID() ); ?>"><?php esc_html_e( 'Telefono', 'wistaria-child-theme' ); ?></label><input id="wistaria-telefono-<?php echo esc_attr( get_the_ID() ); ?>" name="telefono" type="tel" autocomplete="tel"></div>
			<div><label for="wistaria-oggetto-<?php echo esc_attr( get_the_ID() ); ?>"><?php esc_html_e( 'Oggetto', 'wistaria-child-theme' ); ?></label><input id="wistaria-oggetto-<?php echo esc_attr( get_the_ID() ); ?>" name="oggetto" type="text"></div>
		</div>
		<div><label for="wistaria-messaggio-<?php echo esc_attr( get_the_ID() ); ?>"><?php esc_html_e( 'Messaggio', 'wistaria-child-theme' ); ?> <span aria-hidden="true">*</span></label><textarea id="wistaria-messaggio-<?php echo esc_attr( get_the_ID() ); ?>" name="messaggio" rows="6" required minlength="5" maxlength="5000"></textarea></div>
		<div class="contact-form__hp" aria-hidden="true"><label for="wistaria-hp-<?php echo esc_attr( get_the_ID() ); ?>"><?php esc_html_e( 'Lascia vuoto', 'wistaria-child-theme' ); ?></label><input id="wistaria-hp-<?php echo esc_attr( get_the_ID() ); ?>" name="tw_hp" type="text" tabindex="-1" autocomplete="off"></div>
		<?php if ( $privacy ) : ?><p class="contact-form__privacy"><?php esc_html_e( 'Prima di inviare, leggi l’', 'wistaria-child-theme' ); ?><a href="<?php echo esc_url( $privacy ); ?>"><?php esc_html_e( 'informativa privacy', 'wistaria-child-theme' ); ?></a>.</p><?php endif; ?>
		<p class="contact-form__status" role="status" aria-live="polite"></p>
		<button class="button button--primary" type="submit"><?php esc_html_e( 'Invia la richiesta', 'wistaria-child-theme' ); ?></button>
	</form>
</div>
