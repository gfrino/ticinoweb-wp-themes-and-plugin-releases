<?php
/** Homepage contact section. @package WistariaChildTheme */
$address   = sanitize_text_field( (string) get_option( 'ticinoweb_contact_address', '' ) );
$phone     = sanitize_text_field( (string) get_option( 'ticinoweb_contact_phone', '' ) );
$email     = sanitize_email( (string) get_option( 'ticinoweb_contact_email', '' ) );
$maps_url  = $address ? add_query_arg( array( 'api' => 1, 'query' => $address ), 'https://www.google.com/maps/search/' ) : '';
$embed_url = $address ? add_query_arg( array( 'q' => $address, 'z' => 16, 'output' => 'embed' ), 'https://maps.google.com/maps' ) : '';
?>
<section class="home-section home-contact-section contact-page" id="contatti" aria-labelledby="home-contact-title">
		<div class="contact-page__intro page-shell">
			<h2 id="home-contact-title"><?php echo esc_html( wistaria_cms_value( 'contact_heading' ) ); ?></h2>
		</div>
		<div class="page-shell">
			<nav class="contact-page__quick" aria-label="<?php esc_attr_e( 'Recapiti', 'wistaria-child-theme' ); ?>">
				<?php if ( $address ) : ?>
					<a class="contact-page__quick-item" href="<?php echo esc_url( $maps_url ); ?>" target="_blank" rel="noopener noreferrer">
						<span class="contact-page__quick-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none"><path d="M20 10c0 5-8 12-8 12S4 15 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.7"/></svg></span>
						<span><span class="contact-page__quick-label"><?php esc_html_e( 'Indirizzo', 'wistaria-child-theme' ); ?></span><strong><?php echo esc_html( $address ); ?></strong></span>
					</a>
				<?php endif; ?>
				<?php if ( $phone ) : ?>
					<a class="contact-page__quick-item" href="<?php echo esc_url( 'tel:' . preg_replace( '/[^+0-9]/', '', $phone ) ); ?>">
						<span class="contact-page__quick-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none"><path d="M6.6 2.5 9.8 6l-1.7 2.5a15 15 0 0 0 7.4 7.4l2.5-1.7 3.5 3.2-1.5 3.4c-.4.8-1.3 1.2-2.1 1C9.4 20 4 14.6 2.2 6.1c-.2-.8.2-1.7 1-2.1l3.4-1.5Z"/></svg></span>
						<span><span class="contact-page__quick-label"><?php esc_html_e( 'Telefono', 'wistaria-child-theme' ); ?></span><strong><?php echo esc_html( $phone ); ?></strong></span>
					</a>
				<?php endif; ?>
				<?php if ( $email ) : ?>
					<a class="contact-page__quick-item" href="<?php echo esc_url( 'mailto:' . $email ); ?>">
						<span class="contact-page__quick-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none"><rect x="2.5" y="4.5" width="19" height="15" rx="2"/><path d="m3.5 6 8.5 7 8.5-7"/></svg></span>
						<span><span class="contact-page__quick-label"><?php esc_html_e( 'Email', 'wistaria-child-theme' ); ?></span><strong><?php echo esc_html( $email ); ?></strong></span>
					</a>
				<?php endif; ?>
			</nav>
			<div class="contact-page__layout">
				<?php if ( $address ) : ?>
					<div class="contact-map">
						<div class="contact-map__placeholder"><p><?php esc_html_e( 'Per visualizzare la mappa, autorizza i contenuti esterni nelle preferenze cookie.', 'wistaria-child-theme' ); ?></p><a href="<?php echo esc_url( $maps_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Apri Google Maps', 'wistaria-child-theme' ); ?></a></div>
						<iframe class="contact-map__frame" data-src="<?php echo esc_url( $embed_url ); ?>" title="<?php esc_attr_e( 'Mappa di Wistaria Sagl a Minusio', 'wistaria-child-theme' ); ?>" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen hidden></iframe>
					</div>
				<?php endif; ?>
				<?php get_template_part( 'template-parts/contact-form' ); ?>
			</div>
		</div>
</section>
