<?php
/** Wistaria homepage. @package WistariaChildTheme */
get_header();
$slides = function_exists( 'ticinoweb_get_slider_data' ) ? ticinoweb_get_slider_data() : array();
$services = wistaria_services();
$work_ids = wistaria_work_images();
$about_title = (string) get_option( 'ticinoweb_chi_siamo_title', get_bloginfo( 'name' ) );
$about_text = (string) get_option( 'ticinoweb_chi_siamo_text', '' );
$about_images = wistaria_gallery_images( 'chi-siamo-wistaria' );
$about_main_url = get_option( 'ticinoweb_chi_siamo_image', false );
$about_detail_url = get_option( 'wistaria_about_detail_image', false );
$about_main_image = empty( $about_main_url ) ? (int) ( $about_images[0] ?? 0 ) : (int) attachment_url_to_postid( $about_main_url );
$about_detail_image = false === $about_detail_url ? (int) ( $about_images[1] ?? 0 ) : (int) attachment_url_to_postid( $about_detail_url );
$contact_url = home_url( '/#contatti' );
$hero = $slides[0] ?? array();
$service_items = array();
$service_image_ids = array();
$fallback_service_image_id = $work_ids[0] ?? 0;
$service_image_sizes = '(max-width: 760px) calc(100vw - 32px), (max-width: 1000px) 50vw, 54vw';
foreach ( $services as $service ) {
	$title = trim( (string) ( $service['title'] ?? '' ) );
	if ( '' === $title ) {
		continue;
	}
	$image_url = (string) ( $service['image'] ?? '' );
	if ( $image_url && ! isset( $service_image_ids[ $image_url ] ) ) {
		$service_image_ids[ $image_url ] = attachment_url_to_postid( $image_url );
	}
	$image_id = $image_url ? (int) $service_image_ids[ $image_url ] : 0;
	if ( ! $image_id ) {
		$image_id = (int) $fallback_service_image_id;
	}
	$service_items[] = array(
		'title'  => $title,
		'image'  => $image_id,
		'src'    => $image_id ? wp_get_attachment_image_url( $image_id, 'large' ) : '',
		'srcset' => $image_id ? wp_get_attachment_image_srcset( $image_id, 'large' ) : '',
		'alt'    => $image_id ? trim( (string) get_post_meta( $image_id, '_wp_attachment_image_alt', true ) ) : '',
	);
}
$first_service = $service_items[0] ?? array();
?>
<main id="main">
	<?php while ( have_posts() ) : the_post(); ?>
		<section class="hero" aria-labelledby="hero-title">
			<div class="hero__media" data-hero-slides>
				<?php foreach ( $slides as $index => $slide ) :
					$image_id = attachment_url_to_postid( $slide['image'] ?? '' );
					if ( ! $image_id ) { continue; }
					$image = wp_get_attachment_image( $image_id, 'full', false, array(
						'alt' => '',
						'class' => 'hero__image',
						'loading' => 0 === $index ? 'eager' : 'lazy',
						'fetchpriority' => 0 === $index ? 'high' : 'low',
						'sizes' => '100vw',
					) );
					?>
					<div class="hero__slide<?php echo 0 === $index ? ' is-active' : ''; ?>" aria-hidden="true"><?php echo $image; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WordPress image markup. ?></div>
				<?php endforeach; ?>
			</div>
			<div class="hero__shade" aria-hidden="true"></div>
			<div class="hero__content page-shell">
				<h1 id="hero-title"><?php echo esc_html( $hero['title'] ?? get_bloginfo( 'name' ) ); ?></h1>
				<?php if ( ! empty( $hero['desc'] ) ) : ?><p><?php echo esc_html( $hero['desc'] ); ?></p><?php endif; ?>
				<a class="button button--hero" href="<?php echo esc_url( $contact_url ); ?>"><?php echo esc_html( wistaria_quote_label() ); ?></a>
			</div>
		</section>

		<?php if ( $service_items ) : ?>
		<section class="home-section services-showcase" id="servizi" aria-labelledby="home-services-title" data-services-showcase>
			<div class="page-shell">
				<div class="section-heading"><div><h2 id="home-services-title"><?php echo esc_html( wistaria_cms_value( 'services_heading' ) ); ?></h2><p><?php echo esc_html( wistaria_cms_value( 'services_intro' ) ); ?></p></div></div>
				<div class="services-showcase__layout">
					<div class="services-showcase__choices">
						<?php if ( ! empty( $first_service['image'] ) ) : ?>
							<div class="services-showcase__mobile-photo" data-mobile-service-photo>
								<figure class="services-showcase__figure">
									<?php echo wp_get_attachment_image( $first_service['image'], 'large', false, array( 'class' => 'services-showcase__image', 'alt' => $first_service['alt'], 'loading' => 'lazy', 'sizes' => $service_image_sizes ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WordPress image markup. ?>
									<figcaption class="services-showcase__caption" aria-live="polite"><strong data-mobile-service-title><?php echo esc_html( $first_service['title'] ); ?></strong></figcaption>
								</figure>
							</div>
						<?php endif; ?>
						<div class="services-showcase__list" id="wistaria-services-list" role="region" tabindex="0" aria-label="<?php esc_attr_e( 'Elenco scorrevole dei servizi', 'wistaria-child-theme' ); ?>" data-service-list>
							<?php foreach ( $service_items as $index => $service ) : ?>
								<div class="services-showcase__item">
									<button class="services-showcase__button<?php echo 0 === $index ? ' is-active' : ''; ?>" type="button" data-service-button data-image-src="<?php echo esc_url( $service['src'] ); ?>" data-image-srcset="<?php echo esc_attr( $service['srcset'] ); ?>" data-image-alt="<?php echo esc_attr( $service['alt'] ); ?>" aria-pressed="<?php echo 0 === $index ? 'true' : 'false'; ?>" disabled>
										<span class="services-showcase__name"><?php echo esc_html( $service['title'] ); ?></span>
										<svg class="services-showcase__arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 12h15m-6-6 6 6-6 6"/></svg>
									</button>
								</div>
							<?php endforeach; ?>
						</div>
						<div class="services-showcase__rail" aria-hidden="true"><span data-service-scroll-thumb></span></div>
						<p class="services-showcase__hint"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 4v15m-6-6 6 6 6-6"/></svg><?php echo esc_html( sprintf( __( 'Scorri la lista per vedere tutti i %d servizi', 'wistaria-child-theme' ), count( $service_items ) ) ); ?></p>
						<button class="services-showcase__show-all" type="button" data-show-all-services data-show-more="<?php echo esc_attr( sprintf( __( 'Mostra tutti i %d servizi', 'wistaria-child-theme' ), count( $service_items ) ) ); ?>" data-show-less="<?php esc_attr_e( 'Mostra meno servizi', 'wistaria-child-theme' ); ?>" aria-controls="wistaria-services-list" aria-expanded="false"><?php echo esc_html( sprintf( __( 'Mostra tutti i %d servizi', 'wistaria-child-theme' ), count( $service_items ) ) ); ?></button>
					</div>
					<?php if ( ! empty( $first_service['image'] ) ) : ?>
						<div class="services-showcase__desktop-photo">
							<figure class="services-showcase__figure">
								<?php echo wp_get_attachment_image( $first_service['image'], 'large', false, array( 'class' => 'services-showcase__image', 'alt' => $first_service['alt'], 'loading' => 'lazy', 'sizes' => $service_image_sizes ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WordPress image markup. ?>
								<figcaption class="services-showcase__caption" aria-live="polite"><strong data-desktop-service-title><?php echo esc_html( $first_service['title'] ); ?></strong></figcaption>
							</figure>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</section>
		<?php endif; ?>

		<section class="home-section works-section" id="lavori" aria-labelledby="works-title">
			<div class="page-shell section-heading"><div><h2 id="works-title"><?php echo esc_html( wistaria_cms_value( 'works_heading' ) ); ?></h2><?php if ( wistaria_cms_value( 'works_intro' ) ) : ?><p><?php echo esc_html( wistaria_cms_value( 'works_intro' ) ); ?></p><?php endif; ?></div>
			</div>
			<?php if ( $work_ids ) : ?>
				<div class="work-carousel" data-work-carousel role="region" tabindex="0" aria-label="<?php esc_attr_e( 'Galleria dei lavori: usa le frecce della tastiera per scorrere', 'wistaria-child-theme' ); ?>">
					<div class="work-carousel__track" data-carousel-track>
						<?php foreach ( $work_ids as $index => $image_id ) :
							$full = wp_get_attachment_image_url( $image_id, 'full' );
							$alt = trim( (string) get_post_meta( $image_id, '_wp_attachment_image_alt', true ) );
							if ( ! $alt ) { $alt = __( 'Fotografia dei lavori Wistaria', 'wistaria-child-theme' ); }
							?>
							<a class="work-carousel__item" href="<?php echo esc_url( $full ); ?>" data-lightbox-image data-image-alt="<?php echo esc_attr( $alt ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Apri fotografia %1$d di %2$d', 'wistaria-child-theme' ), $index + 1, count( $work_ids ) ) ); ?>">
								<?php echo wp_get_attachment_image( $image_id, 'large', false, array( 'alt' => $alt, 'loading' => 'lazy', 'sizes' => '(max-width: 600px) 250px, (max-width: 1132px) 215px, 260px' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WordPress image markup. ?>
							</a>
						<?php endforeach; ?>
					</div>
				</div>
				<dialog class="work-lightbox" data-work-lightbox aria-label="<?php esc_attr_e( 'Fotografia dei lavori', 'wistaria-child-theme' ); ?>"><button class="work-lightbox__close" type="button" data-lightbox-close aria-label="<?php esc_attr_e( 'Chiudi fotografia', 'wistaria-child-theme' ); ?>">×</button><img alt=""></dialog>
			<?php endif; ?>
		</section>

		<section class="home-section about-preview-section" id="chi-siamo" aria-labelledby="about-preview-title">
			<div class="page-shell about-preview">
				<div class="about-preview__content">
					<h2 id="about-preview-title"><?php echo esc_html( $about_title ); ?></h2>
					<p class="about-preview__lead"><?php echo esc_html( wistaria_cms_value( 'about_lead' ) ); ?></p>
					<?php if ( $about_text ) : ?><p class="about-preview__text"><?php echo esc_html( $about_text ); ?></p><?php endif; ?>
					<?php if ( wistaria_cms_value( 'about_fact_one' ) || wistaria_cms_value( 'about_fact_two' ) ) : ?><div class="about-preview__facts" aria-label="<?php esc_attr_e( 'Informazioni sull’azienda', 'wistaria-child-theme' ); ?>"><?php if ( wistaria_cms_value( 'about_fact_one' ) ) : ?><span><?php echo esc_html( wistaria_cms_value( 'about_fact_one' ) ); ?></span><?php endif; ?><?php if ( wistaria_cms_value( 'about_fact_two' ) ) : ?><span><?php echo esc_html( wistaria_cms_value( 'about_fact_two' ) ); ?></span><?php endif; ?></div><?php endif; ?>
					<a class="button button--primary about-preview__cta" href="#contatti"><?php echo esc_html( wistaria_cms_value( 'about_cta' ) ); ?> <span aria-hidden="true">→</span></a>
				</div>
				<?php if ( $about_main_image && $about_detail_image ) : ?>
					<div class="about-preview__photos" data-about-photos>
						<button class="about-preview__photo about-preview__photo--main" type="button" aria-label="<?php esc_attr_e( 'Scambia le due fotografie', 'wistaria-child-theme' ); ?>" disabled data-about-main>
							<?php echo wp_get_attachment_image( $about_main_image, 'large', false, array( 'loading' => 'lazy', 'sizes' => '(max-width: 800px) calc(100vw - 100px), 43vw' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WordPress image markup. ?>
						</button>
						<button class="about-preview__photo about-preview__photo--detail" type="button" aria-label="<?php esc_attr_e( 'Mostra la fotografia piccola in grande', 'wistaria-child-theme' ); ?>" disabled data-about-detail>
							<?php echo wp_get_attachment_image( $about_detail_image, 'medium_large', false, array( 'loading' => 'lazy', 'sizes' => '(max-width: 800px) calc(100vw - 100px), 43vw' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WordPress image markup. ?>
						</button>
					</div>
				<?php endif; ?>
			</div>
		</section>

		<?php get_template_part( 'template-parts/home-faq' ); ?>
		<?php get_template_part( 'template-parts/contact-section' ); ?>
	<?php endwhile; ?>
</main>
<?php get_footer(); ?>
