<?php
/**
 * Mela Verde Child Theme - Testi editabili da Aspetto > Personalizza
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function melaverde_customizer_fields() {
	$uploads_base = wp_get_upload_dir()['baseurl'];

	return array(
		'melaverde_hero' => array(
			'title'    => __( 'Sezione Hero', 'melaverde-child-theme' ),
			'priority' => 20,
			'fields'   => array(
				'melaverde_hero_title' => array( 'label' => 'Titolo grande', 'default' => 'Ispirazioni genuine per la tua tavola' ),
				'melaverde_hero_desc'  => array( 'label' => 'Sottotitolo', 'type' => 'textarea', 'default' => 'Prodotti di stagione, locali e selezionati ogni giorno.' ),
			),
		),
		'melaverde_chisiamo' => array(
			'title'    => __( 'Sezione Chi Siamo', 'melaverde-child-theme' ),
			'priority' => 25,
			'fields'   => array(
				'melaverde_chisiamo_title' => array( 'label' => 'Titolo sezione', 'default' => 'La nostra storia' ),
				'melaverde_chisiamo_text'  => array(
					'label'       => 'Testo',
					'type'        => 'textarea',
					'description' => 'Lascia una riga vuota per andare a capo con un nuovo paragrafo.',
					'default'     => "Da oltre 20 anni lavoriamo nel mondo della gastronomia con passione, esperienza e attenzione alla qualità. Oggi, con il nostro punto vendita di Bellinzona, portiamo questa esperienza direttamente al cliente, offrendo ogni giorno prodotti freschi e selezionati.\n\nSiamo specializzati nella vendita di frutta e verdura di stagione, accuratamente scelta per garantire gusto, freschezza e genuinità. Accanto a questo, proponiamo un'ampia selezione di prodotti alimentari, tra cui latticini, salumi e formaggi, privilegiando fornitori locali e filiere corte a km 0.\nIl nostro obiettivo è semplice: offrire prodotti di qualità superiore, senza conservanti e nel rispetto della stagionalità, per portare sulla tavola sapori autentici e genuini.\n\nCrediamo nella cura dei dettagli, nella scelta delle materie prime e in un servizio attento alle esigenze di ogni cliente. Grazie a infrastrutture adeguate per lo stoccaggio e la logistica, siamo in grado di garantire freschezza costante e standard elevati in ogni prodotto.\nMela Verde non è solo un negozio, ma un punto di riferimento per chi cerca qualità, autenticità e prodotti selezionati con competenza.",
				),
			),
		),
		'melaverde_prodotti' => array(
			'title'    => __( 'Sezione Prodotti', 'melaverde-child-theme' ),
			'priority' => 30,
			'fields'   => array(
				'melaverde_prodotti_title'      => array( 'label' => 'Titolo sezione', 'default' => 'I Nostri Prodotti' ),
				'melaverde_prodotti_subtitle'   => array( 'label' => 'Sottotitolo sezione', 'default' => "Selezionati con cura per offrire solo l'eccellenza alla tua tavola, dai campi freschi alle cantine stagionate.", 'type' => 'textarea' ),
				'melaverde_prodotti_card1_image' => array( 'label' => 'Scheda 1 - Foto (Frutta e verdura)', 'type' => 'image', 'default' => $uploads_base . '/2026/04/PHOTO-2026-04-16-11-18-25-5.jpg' ),
				'melaverde_prodotti_card1_title' => array( 'label' => 'Scheda 1 - Titolo (Frutta e verdura)', 'default' => 'Frutta e verdura di stagione' ),
				'melaverde_prodotti_card1_desc'  => array( 'label' => 'Scheda 1 - Descrizione', 'default' => 'Raccolte al momento giusto per il massimo del sapore e dei nutrienti.', 'type' => 'textarea' ),
				'melaverde_prodotti_card2_image' => array( 'label' => 'Scheda 2 - Foto (Latticini)', 'type' => 'image', 'default' => $uploads_base . '/2026/04/PHOTO-2026-04-26-18-52-03.jpg' ),
				'melaverde_prodotti_card2_title' => array( 'label' => 'Scheda 2 - Titolo (Latticini)', 'default' => 'Latticini Freschi' ),
				'melaverde_prodotti_card2_desc'  => array( 'label' => 'Scheda 2 - Descrizione', 'default' => 'Latte, yogurt e mozzarelle dal sapore genuino garantito.', 'type' => 'textarea' ),
				'melaverde_prodotti_card3_image' => array( 'label' => 'Scheda 3 - Foto (Salumi)', 'type' => 'image', 'default' => $uploads_base . '/2026/04/PHOTO-2026-04-26-18-52-03-2.jpg' ),
				'melaverde_prodotti_card3_title' => array( 'label' => 'Scheda 3 - Titolo (Salumi)', 'default' => 'Salumi Selezionati' ),
				'melaverde_prodotti_card3_desc'  => array( 'label' => 'Scheda 3 - Descrizione', 'default' => 'I migliori insaccati artigianali perfetti per i tuoi taglieri.', 'type' => 'textarea' ),
				'melaverde_prodotti_card4_image' => array( 'label' => 'Scheda 4 - Foto (Formaggi)', 'type' => 'image', 'default' => $uploads_base . '/2026/04/PHOTO-2026-04-16-11-18-25.jpg' ),
				'melaverde_prodotti_card4_title' => array( 'label' => 'Scheda 4 - Titolo (Formaggi)', 'default' => 'Formaggi Locali' ),
				'melaverde_prodotti_card4_desc'  => array( 'label' => 'Scheda 4 - Descrizione', 'default' => 'Profumi e sapori intensi, dai pascoli ticinesi alla tua tavola.', 'type' => 'textarea' ),
				'melaverde_prodotti_card5_title' => array( 'label' => 'Scheda 5 - Titolo (Km 0)', 'default' => 'Prodotti a Km 0' ),
				'melaverde_prodotti_card5_desc'  => array( 'label' => 'Scheda 5 - Descrizione', 'default' => "Sosteniamo l'agricoltura ticinese per offrirti il vero sapore del nostro territorio.", 'type' => 'textarea' ),
			),
		),
		'melaverde_galleria' => array(
			'title'    => __( 'Sezione Galleria', 'melaverde-child-theme' ),
			'priority' => 40,
			'fields'   => array(
				'melaverde_galleria_title'    => array( 'label' => 'Titolo sezione', 'default' => 'Scatti di Freschezza' ),
				'melaverde_galleria_subtitle' => array( 'label' => 'Sottotitolo sezione', 'default' => 'Un\'occhiata all\'interno del nostro negozio e ai prodotti che selezioniamo ogni giorno per voi.', 'type' => 'textarea' ),
			),
		),
		'melaverde_contatti' => array(
			'title'       => __( 'Sezione Contatti', 'melaverde-child-theme' ),
			'description' => __( 'Email, telefono, indirizzo e orari di apertura si cambiano in ticinoWEB CMS → Contatti: la home li mostra da lì.', 'melaverde-child-theme' ),
			'priority'    => 50,
			'fields'   => array(
				'melaverde_contatti_title'    => array( 'label' => 'Titolo sezione', 'default' => 'Vieni a trovarci a Bellinzona' ),
				'melaverde_contatti_subtitle' => array(
					'label'       => 'Sottotitolo sezione',
					'default'     => 'Siamo in {indirizzo}. Passa a scoprire i nostri prodotti freschi.',
					'type'        => 'textarea',
					'description' => 'Usa {indirizzo} nel punto in cui vuoi che compaia l\'indirizzo (impostato nel CMS ticinoWEB).',
				),
				// Email, telefoni, indirizzo e orari NON stanno qui: si inseriscono una volta sola
				// nel ticinoWEB CMS → Contatti, e la home li legge da lì.
				'melaverde_form_title'         => array( 'label' => 'Titolo modulo di contatto', 'default' => 'Contattaci per informazioni' ),
			),
		),
		'melaverde_footer' => array(
			'title'    => __( 'Footer', 'melaverde-child-theme' ),
			'priority' => 60,
			'fields'   => array(
				'melaverde_footer_copyright'      => array( 'label' => 'Testo copyright (dopo "© anno")', 'default' => 'Mela Verde Bellinzona. Tutti i diritti riservati.' ),
				'melaverde_footer_privacy_label'  => array( 'label' => 'Testo link "Privacy Policy"', 'default' => 'Privacy Policy' ),
				'melaverde_footer_area_riservata' => array( 'label' => 'Testo link "Area Riservata"', 'default' => 'Area Riservata' ),
			),
		),
	);
}

function melaverde_sanitize_multiline_text( $value ) {
	$value = wp_strip_all_tags( $value );
	$value = str_replace( "\r\n", "\n", $value );
	return trim( $value );
}

add_action( 'customize_register', 'melaverde_customize_register' );
function melaverde_customize_register( $wp_customize ) {
	$wp_customize->add_panel( 'melaverde_texts_panel', array(
		'title'       => __( 'Mela Verde – Testi del Sito', 'melaverde-child-theme' ),
		'description' => __( 'Tutte le scritte e le foto della pagina, divise per sezione. Ogni modifica si vede subito qui a fianco.', 'melaverde-child-theme' ),
		'priority'    => 160,
	) );

	foreach ( melaverde_customizer_fields() as $section_id => $section ) {
		$wp_customize->add_section( $section_id, array(
			'title'       => $section['title'],
			'description' => isset( $section['description'] ) ? $section['description'] : '',
			'panel'       => 'melaverde_texts_panel',
			'priority'    => $section['priority'],
		) );

		foreach ( $section['fields'] as $key => $field ) {
			$type = isset( $field['type'] ) ? $field['type'] : 'text';

			$sanitize_callback = 'sanitize_text_field';
			if ( 'textarea' === $type ) {
				$sanitize_callback = 'melaverde_sanitize_multiline_text';
			} elseif ( 'image' === $type ) {
				$sanitize_callback = 'esc_url_raw';
			}

			$wp_customize->add_setting( $key, array(
				'default'           => $field['default'],
				'sanitize_callback' => $sanitize_callback,
				'transport'         => 'refresh',
			) );

			if ( 'image' === $type ) {
				$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, $key, array(
					'label'       => $field['label'],
					'description' => isset( $field['description'] ) ? $field['description'] : '',
					'section'     => $section_id,
				) ) );
			} else {
				$wp_customize->add_control( $key, array(
					'label'       => $field['label'],
					'description' => isset( $field['description'] ) ? $field['description'] : '',
					'section'     => $section_id,
					'type'        => $type,
				) );
			}
		}
	}
}
