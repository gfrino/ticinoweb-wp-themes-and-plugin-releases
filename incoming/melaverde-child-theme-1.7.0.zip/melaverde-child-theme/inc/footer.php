<?php
/**
 * Mela Verde – piè di pagina condiviso (home e pagine interne) e aiutanti per i contatti.
 *
 * Tutti i recapiti arrivano dal ticinoWEB CMS → Contatti (ticinoweb_get_contact_info() del
 * parent). Nessun dato del cliente è scritto qui: un campo vuoto nasconde la sua riga.
 *
 * @package melaverde-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Giorni nell'ordine del CMS, con etichetta lunga, corta e numero JS (Date.getDay()).
 *
 * @return array
 */
function melaverde_days() {
	return array(
		'monday'    => array( 'long' => 'Lunedì', 'short' => 'Lun', 'js' => 1 ),
		'tuesday'   => array( 'long' => 'Martedì', 'short' => 'Mar', 'js' => 2 ),
		'wednesday' => array( 'long' => 'Mercoledì', 'short' => 'Mer', 'js' => 3 ),
		'thursday'  => array( 'long' => 'Giovedì', 'short' => 'Gio', 'js' => 4 ),
		'friday'    => array( 'long' => 'Venerdì', 'short' => 'Ven', 'js' => 5 ),
		'saturday'  => array( 'long' => 'Sabato', 'short' => 'Sab', 'js' => 6 ),
		'sunday'    => array( 'long' => 'Domenica', 'short' => 'Dom', 'js' => 0 ),
	);
}

/**
 * Telefoni del CMS (principale, fisso, cellulare) senza doppioni.
 *
 * @return array cifre per il link tel: => testo da mostrare.
 */
function melaverde_contact_phones() {
	$info   = ticinoweb_get_contact_info();
	$phones = array();
	foreach ( array( $info['phone'], $info['phone_landline'], $info['phone_mobile'] ) as $phone ) {
		$phone  = trim( (string) $phone );
		$digits = preg_replace( '/[^0-9+]/', '', $phone );
		if ( $phone !== '' && $digits !== '' && ! isset( $phones[ $digits ] ) ) {
			$phones[ $digits ] = $phone;
		}
	}
	return $phones;
}

/**
 * Orari del CMS, un giorno per riga. Giorni senza dati: saltati.
 *
 * @return array di array( label, short, js, text, closed ).
 */
function melaverde_hours_rows() {
	$info  = ticinoweb_get_contact_info();
	$raw   = is_array( $info['opening_hours'] ) ? $info['opening_hours'] : array();
	$rows  = array();
	foreach ( melaverde_days() as $key => $day ) {
		if ( ! isset( $raw[ $key ] ) ) {
			continue;
		}
		$text = ticinoweb_format_day_hours( $raw[ $key ], ', ' );
		if ( $text === '' ) {
			continue;
		}
		$rows[] = array(
			'label'  => $day['long'],
			'short'  => $day['short'],
			'js'     => $day['js'],
			'text'   => $text,
			'closed' => ! empty( $raw[ $key ]['closed'] ),
		);
	}
	return $rows;
}

/**
 * Orari compatti: giorni consecutivi con lo stesso orario uniti ("Mar – Ven").
 *
 * @return array di array( label, days (numeri JS), text, closed ).
 */
function melaverde_hours_grouped() {
	$groups = array();
	foreach ( melaverde_hours_rows() as $row ) {
		$last = count( $groups ) - 1;
		if ( $last >= 0 && $groups[ $last ]['text'] === $row['text'] ) {
			$groups[ $last ]['to']     = $row['short'];
			$groups[ $last ]['days'][] = $row['js'];
			continue;
		}
		$groups[] = array(
			'from'   => $row['short'],
			'to'     => '',
			'days'   => array( $row['js'] ),
			'text'   => $row['text'],
			'closed' => $row['closed'],
		);
	}
	foreach ( $groups as &$group ) {
		$group['label'] = $group['to'] !== '' ? $group['from'] . ' – ' . $group['to'] : $group['from'];
	}
	unset( $group );
	return $groups;
}

/**
 * Stampa il piè di pagina.
 *
 * @param array $args logo_url, on_home (link ad ancora sulla stessa pagina), nav (ancora => etichetta).
 */
function melaverde_render_footer( $args ) {
	$logo_url = isset( $args['logo_url'] ) ? $args['logo_url'] : '';
	$on_home  = ! empty( $args['on_home'] );
	$nav      = isset( $args['nav'] ) ? (array) $args['nav'] : array();

	$info     = ticinoweb_get_contact_info();
	$address  = trim( (string) $info['address'] );
	$email    = trim( (string) $info['email'] );
	$phones   = melaverde_contact_phones();
	$hours    = melaverde_hours_grouped();
	$note     = trim( (string) $info['opening_hours_note'] );
	$vat      = trim( (string) $info['vat'] );
	$maps_url = trim( (string) $info['map_url'] );
	if ( $maps_url === '' && $address !== '' ) {
		$maps_url = 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $address );
	}
	$tagline  = get_theme_mod( 'melaverde_hero_desc', 'Prodotti di stagione, locali e selezionati ogni giorno.' );
	$privacy  = get_privacy_policy_url() ?: home_url( '/privacy-policy/' );
	$socials  = array_filter( array(
		'Facebook'  => $info['facebook'],
		'Instagram' => $info['instagram'],
		'TikTok'    => $info['tiktok'],
		'YouTube'   => $info['youtube'],
		'LinkedIn'  => $info['linkedin'],
	) );

	$heading = 'font-headline text-xs font-bold uppercase tracking-[0.18em] text-[#2a6038] mb-5';
	$link    = 'text-stone-600 hover:text-[#4a7c59] transition-colors underline decoration-transparent hover:decoration-[#4a7c59] underline-offset-4';
	?>
<footer class="mv-footer relative w-full bg-[#f1ece2] text-stone-700 font-body border-t border-[#e3dccd]" role="contentinfo">
	<div class="max-w-7xl mx-auto px-6 md:px-8 pt-16 pb-10">
		<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-x-10 gap-y-12">

			<div class="lg:col-span-4 flex flex-col gap-5">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="block w-fit hover:opacity-80 transition-opacity" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?> – Home">
					<?php if ( ! empty( $logo_url ) ) : ?>
						<img src="<?php echo esc_url( $logo_url ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" class="h-28 w-auto object-contain -ml-2" loading="lazy" width="173" height="112">
					<?php else : ?>
						<span class="font-headline text-2xl font-bold text-[#4a7c59]"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></span>
					<?php endif; ?>
				</a>
				<?php if ( $tagline !== '' ) : ?>
					<p class="font-headline italic text-lg leading-snug text-stone-700 max-w-xs"><?php echo esc_html( $tagline ); ?></p>
				<?php endif; ?>
				<?php if ( $maps_url !== '' ) : ?>
					<a href="<?php echo esc_url( $maps_url ); ?>" target="_blank" rel="noopener" class="inline-flex items-center gap-2 w-fit bg-[#4a7c59] text-white text-sm font-semibold py-2.5 px-5 rounded-full hover:bg-[#3d684a] transition-colors">
						<span class="material-symbols-outlined text-lg" aria-hidden="true">directions</span>
						Come raggiungerci
					</a>
				<?php endif; ?>
				<?php if ( $socials ) : ?>
					<ul class="flex flex-wrap gap-3 text-sm" aria-label="Social">
						<?php foreach ( $socials as $name => $url ) : ?>
							<li><a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener" class="<?php echo esc_attr( $link ); ?>"><?php echo esc_html( $name ); ?></a></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			</div>

			<nav class="lg:col-span-2" aria-label="Menu del piè di pagina">
				<h2 class="<?php echo esc_attr( $heading ); ?>">Naviga</h2>
				<ul class="flex flex-col gap-3">
					<?php foreach ( $nav as $anchor => $label ) : ?>
						<li><a class="<?php echo esc_attr( $link ); ?>" href="<?php echo esc_url( $on_home ? '#' . $anchor : home_url( '/#' . $anchor ) ); ?>"><?php echo esc_html( $label ); ?></a></li>
					<?php endforeach; ?>
				</ul>
			</nav>

			<?php if ( $address !== '' || $phones || $email !== '' ) : ?>
			<div class="lg:col-span-3">
				<h2 class="<?php echo esc_attr( $heading ); ?>">Contatti</h2>
				<ul class="flex flex-col gap-4 text-[15px]">
					<?php if ( $address !== '' ) : ?>
						<li class="flex gap-3"><span class="material-symbols-outlined text-[#4a7c59] text-xl shrink-0" aria-hidden="true">location_on</span><span><?php echo esc_html( $address ); ?></span></li>
					<?php endif; ?>
					<?php if ( $phones ) : ?>
						<li class="flex gap-3"><span class="material-symbols-outlined text-[#4a7c59] text-xl shrink-0" aria-hidden="true">call</span>
							<span class="flex flex-col gap-1">
								<?php foreach ( $phones as $digits => $label ) : ?>
									<a class="<?php echo esc_attr( $link ); ?>" href="tel:<?php echo esc_attr( $digits ); ?>"><?php echo esc_html( $label ); ?></a>
								<?php endforeach; ?>
							</span>
						</li>
					<?php endif; ?>
					<?php if ( $email !== '' ) : ?>
						<li class="flex gap-3"><span class="material-symbols-outlined text-[#4a7c59] text-xl shrink-0" aria-hidden="true">mail</span><a class="<?php echo esc_attr( $link ); ?> break-all" href="mailto:<?php echo esc_attr( antispambot( $email ) ); ?>"><?php echo esc_html( antispambot( $email ) ); ?></a></li>
					<?php endif; ?>
				</ul>
			</div>
			<?php endif; ?>

			<?php if ( $hours ) : ?>
			<div class="lg:col-span-3">
				<h2 class="<?php echo esc_attr( $heading ); ?>">Orari</h2>
				<dl class="flex flex-col text-[15px]" data-mv-hours>
					<?php foreach ( $hours as $group ) : ?>
						<div class="mv-hours-row flex justify-between gap-4 py-2 border-b border-[#e3dccd] last:border-b-0 rounded-md -mx-2 px-2" data-days="<?php echo esc_attr( implode( ',', $group['days'] ) ); ?>">
							<dt class="text-stone-600"><?php echo esc_html( $group['label'] ); ?></dt>
							<dd class="font-semibold text-right <?php echo $group['closed'] ? 'text-red-700' : 'text-stone-800'; ?>"><?php echo esc_html( $group['text'] ); ?></dd>
						</div>
					<?php endforeach; ?>
				</dl>
				<?php if ( $note !== '' ) : ?>
					<p class="text-xs text-stone-600 mt-3"><?php echo esc_html( $note ); ?></p>
				<?php endif; ?>
			</div>
			<?php endif; ?>
		</div>

		<div class="mt-14 pt-6 border-t border-[#e3dccd] flex flex-col md:flex-row gap-4 md:items-center md:justify-between text-sm text-stone-600">
			<p>
				© <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php echo esc_html( get_theme_mod( 'melaverde_footer_copyright', 'Mela Verde Bellinzona. Tutti i diritti riservati.' ) ); ?>
				<?php if ( $vat !== '' ) : ?><span class="block md:inline md:ml-2">IVA <?php echo esc_html( $vat ); ?></span><?php endif; ?>
			</p>
			<ul class="flex flex-wrap items-center gap-x-5 gap-y-2">
				<li><a class="<?php echo esc_attr( $link ); ?>" href="<?php echo esc_url( $privacy ); ?>"><?php echo esc_html( get_theme_mod( 'melaverde_footer_privacy_label', 'Privacy Policy' ) ); ?></a></li>
				<li><button type="button" class="<?php echo esc_attr( $link ); ?> cursor-pointer" data-mv-cookie-settings>Preferenze cookie</button></li>
				<li><a class="<?php echo esc_attr( $link ); ?>" href="<?php echo esc_url( wp_login_url() ); /* /tw-login/ del parent: wp-admin dà 404 ai visitatori */ ?>" rel="nofollow"><?php echo esc_html( get_theme_mod( 'melaverde_footer_area_riservata', 'Area Riservata' ) ); ?></a></li>
				<li class="text-stone-600">Design by <a href="https://ticinoweb.com/" target="_blank" rel="noopener" class="font-bold text-stone-700 hover:text-[#4a7c59] transition-colors">ticinoWEB</a></li>
			</ul>
		</div>
	</div>
</footer>
<script>
(function () {
	// Evidenzia la riga degli orari di oggi (ora del visitatore: la pagina può essere in cache per giorni).
	var today = String(new Date().getDay());
	document.querySelectorAll('[data-mv-hours] .mv-hours-row').forEach(function (row) {
		if ((row.getAttribute('data-days') || '').split(',').indexOf(today) !== -1) {
			row.classList.add('bg-white/70');
			var dt = row.querySelector('dt');
			if (dt) {
				dt.insertAdjacentHTML('beforeend', ' <span class="ml-1 text-[11px] font-bold uppercase tracking-wide text-[#2a6038]">oggi</span>');
			}
		}
	});
	// Preferenze cookie: il banner del parent sparisce dopo la scelta; togliendo la scelta salvata
	// e ricaricando, il visitatore può cambiarla quando vuole.
	document.querySelectorAll('[data-mv-cookie-settings]').forEach(function (btn) {
		btn.addEventListener('click', function () {
			['tw_cookie_consent', 'tw_cookie_preferences'].forEach(function (name) {
				document.cookie = name + '=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/; SameSite=Lax';
			});
			window.location.reload();
		});
	});
})();
</script>
	<?php
}

/**
 * Dati strutturati: aggiunge gli orari del CMS al LocalBusiness del parent (stesso blocco
 * JSON-LD, nessun duplicato). Giorni chiusi o senza fasce: esclusi, come vuole schema.org.
 */
add_filter( 'ticinoweb_seo_jsonld_org_schema', 'melaverde_schema_opening_hours' );
function melaverde_schema_opening_hours( $schema ) {
	if ( ! is_array( $schema ) || ( isset( $schema['@type'] ) && $schema['@type'] !== 'LocalBusiness' ) || ! function_exists( 'ticinoweb_get_contact_info' ) ) {
		return $schema;
	}
	$info  = ticinoweb_get_contact_info();
	$raw   = is_array( $info['opening_hours'] ) ? $info['opening_hours'] : array();
	$names = array( 'monday' => 'Monday', 'tuesday' => 'Tuesday', 'wednesday' => 'Wednesday', 'thursday' => 'Thursday', 'friday' => 'Friday', 'saturday' => 'Saturday', 'sunday' => 'Sunday' );
	$specs = array();
	foreach ( $names as $key => $name ) {
		if ( empty( $raw[ $key ] ) || ! empty( $raw[ $key ]['closed'] ) ) {
			continue;
		}
		if ( ! empty( $raw[ $key ]['open_24h'] ) ) {
			$specs[] = array( '@type' => 'OpeningHoursSpecification', 'dayOfWeek' => $name, 'opens' => '00:00', 'closes' => '23:59' );
			continue;
		}
		foreach ( (array) ( $raw[ $key ]['slots'] ?? array() ) as $slot ) {
			$open  = isset( $slot['open'] ) ? trim( (string) $slot['open'] ) : '';
			$close = isset( $slot['close'] ) ? trim( (string) $slot['close'] ) : '';
			if ( preg_match( '/^\d{1,2}:\d{2}$/', $open ) && preg_match( '/^\d{1,2}:\d{2}$/', $close ) ) {
				$specs[] = array( '@type' => 'OpeningHoursSpecification', 'dayOfWeek' => $name, 'opens' => $open, 'closes' => $close );
			}
		}
	}
	if ( $specs && empty( $schema['openingHoursSpecification'] ) ) {
		$schema['openingHoursSpecification'] = $specs;
	}
	return $schema;
}
