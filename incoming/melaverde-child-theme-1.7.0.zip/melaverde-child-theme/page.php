<?php
/**
 * Mela Verde Child Theme - Default Page Template
 * Usato per pagine statiche come la Privacy Policy
 */

get_header();

// Recupera il logo (stessa logica di front-page.php)
$logo_url = get_option('ticinoweb_site_logo', '');
if ( empty($logo_url) ) {
    $custom_logo_id = get_theme_mod( 'custom_logo' );
    $logo_url = wp_get_attachment_image_url( $custom_logo_id , 'full' );
}

// Testi del menu e del footer (fissi: non modificabili dal pannello testi)
$nav_home     = 'Home';
$nav_chisiamo = 'Chi Siamo';
$nav_prodotti = 'Prodotti';
$nav_contatti = 'Contatti';
$nav_cta      = 'Contattaci';
$nav_back_home = '← Torna alla Home';
$nav_back_site = 'Torna al sito';
?>

<style>
/* CSS Reset for Parent Theme Spacing and Headers */
#content, .site-content, .site {
    padding-top: 0 !important;
    padding-bottom: 0 !important;
    margin-top: 0 !important;
    margin-bottom: 0 !important;
}
#masthead, .site-header, .site-footer {
    display: none !important;
}
</style>

<!-- TopNavBar Shared Component (Adattato per Sottopagine) -->
<nav class="fixed top-0 w-full z-50 bg-[#faf6f0]/90 backdrop-blur-md dark:bg-stone-900/90 border-b border-stone-200/50 dark:border-stone-800 shadow-sm transition-all duration-300 ease-in-out">
<div class="flex justify-between items-center px-4 md:px-8 h-24 max-w-7xl mx-auto">
<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="font-['Literata'] text-2xl font-bold text-[#4a7c59] dark:text-emerald-500 flex items-center hover:opacity-80 transition-opacity">
    <?php if ( $logo_url ) : ?>
        <img src="<?php echo esc_url( $logo_url ); ?>" alt="Mela Verde Logo" class="h-20 w-auto object-contain drop-shadow-sm scale-110 origin-left">
    <?php else : ?>
        Mela Verde
    <?php endif; ?>
</a>
<div class="relative hidden md:flex items-center gap-2" id="header-nav-container">
<a class="header-nav-link font-['Nunito_Sans'] font-semibold text-sm uppercase tracking-wide px-3 py-2 text-stone-600 dark:text-stone-400 hover:text-[#4a7c59] transition-colors duration-300 ease-in-out" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo esc_html( $nav_back_home ); ?></a>
</div>
<a href="<?php echo esc_url( home_url( '/' ) ); ?>#contatti" class="bg-primary text-on-primary font-body font-semibold py-2 px-6 rounded-lg hover:bg-primary-container hover:text-on-primary-container transition-colors hidden md:block">
    <?php echo esc_html( $nav_cta ); ?>
</a>
<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="md:hidden text-[#4a7c59] p-2 hover:scale-110 transition-transform">
    <span class="material-symbols-outlined text-[32px]">arrow_back</span>
</a>
</div>
</nav>

<!-- MAIN CONTENT -->
<main class="pt-32 pb-24 px-6 min-h-[70vh] bg-surface-container-low">
    <div class="max-w-4xl mx-auto bg-white dark:bg-stone-900 rounded-2xl soft-shadow p-8 md:p-14">
        
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="inline-flex items-center gap-2 text-stone-500 hover:text-[#4a7c59] transition-colors mb-8 font-body text-sm uppercase tracking-wider font-semibold">
            <span class="material-symbols-outlined text-[20px]">arrow_back</span>
            <?php echo esc_html( $nav_back_site ); ?>
        </a>

        <?php
        if ( have_posts() ) :
            while ( have_posts() ) : the_post();
                echo '<h1 class="font-headline text-3xl md:text-5xl text-primary mb-10 border-b border-stone-200 dark:border-stone-800 pb-6">' . get_the_title() . '</h1>';
                
                // Content wrapper for styling standard WP elements
                echo '<div class="prose prose-stone prose-lg dark:prose-invert max-w-none prose-headings:font-headline prose-headings:text-primary prose-a:text-[#4a7c59] hover:prose-a:text-emerald-600">';
                the_content();
                echo '</div>';
                
            endwhile;
        endif;
        ?>
    </div>
</main>

<!-- Footer Shared Component: inc/footer.php -->
<?php
melaverde_render_footer( array(
    'logo_url' => $logo_url,
    'on_home'  => false,
    'nav'      => array( 'home' => $nav_home, 'chisiamo' => $nav_chisiamo, 'prodotti' => $nav_prodotti, 'galleria' => 'Galleria', 'contatti' => $nav_contatti ),
) );
?>

<?php get_footer(); ?>
