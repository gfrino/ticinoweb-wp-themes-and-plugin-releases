document.addEventListener('DOMContentLoaded', () => {

    // 1. Inizializza le animazioni del testo della PRIMA SLIDE
    // (GSAP parte settando a 0 l'opacità, e poi li fa apparire con un fade e un leggero scale/blur)
    function animateTextIn(slideElement) {
        if (!slideElement) return;
        
        const revealElements = slideElement.querySelectorAll('.gs-reveal');
        
        // Se non ci sono elementi, o se l'animazione GSAP non è caricata (fallback fallback)
        if (revealElements.length === 0 || typeof gsap === 'undefined') {
            revealElements.forEach(el => {
                el.style.opacity = 1;
                el.style.visibility = 'visible';
            });
            return;
        }

        // Imposta stato iniziale e animazione
        revealElements.forEach(el => {
            // Assicuriamoci che GSAP lo metta come visible
            gsap.set(el, { visibility: 'visible', opacity: 0, y: 30, scale: 0.95, filter: 'blur(10px)' });
            
            const delay = parseFloat(el.getAttribute('data-gsap-delay')) || 0;
            
            gsap.to(el, {
                opacity: 1,
                y: 0,
                scale: 1,
                filter: 'blur(0px)',
                duration: 1.5,
                delay: delay + 0.3, // Add base delay on load
                ease: 'power3.out'
            });
        });
    }

    // 2. Anima i testi in uscita (PRIMA di cambiare slide)
    function animateTextOut(slideElement) {
        if (!slideElement || typeof gsap === 'undefined') return;
        
        const revealElements = slideElement.querySelectorAll('.gs-reveal');
        
        revealElements.forEach(el => {
            gsap.to(el, {
                opacity: 0,
                y: -30,
                scale: 1.05,
                filter: 'blur(10px)',
                duration: 1,
                ease: 'power2.inOut' // Smooth exit
            });
        });
    }

    // 3. Verifica esistenza container 
    const heroSwiperContainer = document.querySelector('.mv-hero-swiper');
    if (!heroSwiperContainer) return;

    // 4. Inizializza Swiper
    // Effetto "Fade" cinematico. crossFade a true per far sì che le foto si mescolino poeticamente
    const heroSwiper = new Swiper('.mv-hero-swiper', {
        effect: 'fade',
        fadeEffect: {
            crossFade: true
        },
        speed: 1500, // Transizione molto lenta per un feel cinematico
        loop: true,
        autoplay: {
            delay: 6000, // Rimangono sulla slide per 6 secondi
            disableOnInteraction: false,
        },
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        on: {
            init: function () {
                // Al caricamento, anima la slide attualmente attiva
                const activeSlide = this.slides[this.activeIndex];
                animateTextIn(activeSlide);
            },
            slideChangeTransitionStart: function () {
                // Durante la transizione, fai sparire la precedente slide attiva
                const previousSlide = this.slides[this.previousIndex];
                animateTextOut(previousSlide);
                
                // Metti gli elementi della nuova slide fuori schermo
                const activeSlide = this.slides[this.activeIndex];
                if(activeSlide) {
                    const reveals = activeSlide.querySelectorAll('.gs-reveal');
                    gsap.set(reveals, { opacity: 0, visibility: 'hidden' }); 
                }
            },
            slideChangeTransitionEnd: function () {
                // Appena è finita la dissolvenza immagine, entra fluida la scritta
                const activeSlide = this.slides[this.activeIndex];
                animateTextIn(activeSlide);
            }
        }
    });

});
