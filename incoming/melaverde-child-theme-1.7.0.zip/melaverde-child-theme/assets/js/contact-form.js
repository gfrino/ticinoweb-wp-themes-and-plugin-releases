/**
 * Modulo "Contattaci per informazioni" → gestore del parent (ticinoweb_submit_form).
 *
 * La home può arrivare dalla cache LiteSpeed per giorni: il token si chiede al parent
 * subito prima dell'invio. reCAPTCHA v3 si usa solo se il sito ha le chiavi nel
 * pannello ticinoWEB CMS, e viene caricato quando il visitatore inizia a scrivere.
 */
(function () {
    'use strict';

    var form = document.querySelector('[data-melaverde-contact-form]');
    if (!form || !window.fetch || !window.FormData) {
        return;
    }

    var cfg = window.ticinoweb_ai_main || {};
    var ajaxUrl = cfg.ajax_url || form.getAttribute('data-ajax-url');
    var tokenAction = cfg.token_action || 'ticinoweb_form_token';
    var submitAction = cfg.submit_action || 'ticinoweb_submit_form';
    var siteKey = cfg.recaptcha_site_key || '';
    var statusEl = form.querySelector('[data-form-status]');
    var successBox = form.parentNode.querySelector('[data-form-success]');
    var successText = form.parentNode.querySelector('[data-form-success-text]');
    var button = form.querySelector('button[type="submit"]');
    var recaptchaLoading = null;
    var mail = form.getAttribute('data-fallback-mail') || '';
    var i18n = {
        name: 'Inserisci il tuo nome.',
        email: 'Inserisci un indirizzo email valido.',
        message: 'Scrivi il tuo messaggio.',
        privacy: 'Conferma di aver letto la Privacy Policy.',
        sending: 'Invio in corso…',
        sent: 'Grazie! Il tuo messaggio è stato inviato. Ti risponderemo al più presto.',
        failed: 'Non è stato possibile inviare il messaggio. Riprova più tardi' + (mail ? ' oppure scrivici a ' + mail + '.' : '.')
    };

    function setStatus(text, isError) {
        statusEl.textContent = text || '';
        statusEl.classList.toggle('text-red-700', !!isError);
        statusEl.classList.toggle('text-stone-600', !isError);
    }

    function setError(name, text) {
        var slot = form.querySelector('[data-error-for="' + name + '"]');
        var field = form.elements[name];
        if (slot) { slot.textContent = text || ''; }
        if (field && field.setAttribute) {
            if (text) { field.setAttribute('aria-invalid', 'true'); } else { field.removeAttribute('aria-invalid'); }
        }
    }

    function validate() {
        var ok = true;
        ['nome', 'email', 'messaggio', 'privacy'].forEach(function (n) { setError(n, ''); });
        if (form.elements.nome.value.trim().length < 2) { setError('nome', i18n.name); ok = false; }
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.elements.email.value.trim())) { setError('email', i18n.email); ok = false; }
        if (form.elements.messaggio.value.trim().length < 5) { setError('messaggio', i18n.message); ok = false; }
        if (!form.elements.privacy.checked) { setError('privacy', i18n.privacy); ok = false; }
        return ok;
    }

    function loadRecaptcha() {
        if (!siteKey) { return Promise.resolve(); }
        if (recaptchaLoading) { return recaptchaLoading; }
        recaptchaLoading = new Promise(function (resolve) {
            var s = document.createElement('script');
            s.src = 'https://www.google.com/recaptcha/api.js?render=' + encodeURIComponent(siteKey);
            s.async = true;
            s.onload = resolve;
            s.onerror = resolve;
            document.head.appendChild(s);
        });
        return recaptchaLoading;
    }

    function recaptchaToken() {
        if (!siteKey) { return Promise.resolve(''); }
        return loadRecaptcha().then(function () {
            if (!window.grecaptcha) { return ''; }
            return new Promise(function (resolve) {
                window.grecaptcha.ready(function () {
                    window.grecaptcha.execute(siteKey, { action: 'contact' }).then(resolve, function () { resolve(''); });
                });
            });
        });
    }

    if (siteKey) {
        form.addEventListener('focusin', loadRecaptcha, { once: true });
    }

    function showSuccess(message) {
        successText.textContent = message || i18n.sent;
        form.classList.add('hidden');
        successBox.classList.remove('hidden');
        successBox.classList.add('flex');
        successBox.focus();
    }

    function finish() {
        button.disabled = false;
        button.removeAttribute('aria-busy');
    }

    form.addEventListener('submit', function (event) {
        event.preventDefault();
        if (!validate()) {
            setStatus('', false);
            var first = form.querySelector('[aria-invalid="true"]');
            if (first) { first.focus(); }
            return;
        }

        button.disabled = true;
        button.setAttribute('aria-busy', 'true');
        setStatus(i18n.sending, false);

        fetch(ajaxUrl + '?action=' + encodeURIComponent(tokenAction), { credentials: 'same-origin', cache: 'no-store' })
            .then(function (r) { return r.json(); })
            .then(function (tokenResponse) {
                return recaptchaToken().then(function (rc) {
                    var data = new FormData(form);
                    data.delete('privacy');
                    data.append('action', submitAction);
                    data.append('token', tokenResponse && tokenResponse.data ? tokenResponse.data.token : '');
                    if (rc) { data.append('recaptcha_token', rc); }
                    return fetch(ajaxUrl, { method: 'POST', body: data, credentials: 'same-origin' });
                });
            })
            .then(function (r) { return r.json(); })
            .then(function (res) {
                finish();
                if (res && res.success) {
                    form.reset();
                    setStatus('', false);
                    showSuccess(res.data && res.data.message);
                    return;
                }
                var payload = (res && res.data) || {};
                if (payload.fields) {
                    Object.keys(payload.fields).forEach(function (name) { setError(name, payload.fields[name]); });
                }
                setStatus(payload.message || i18n.failed, true);
            })
            .catch(function () {
                finish();
                setStatus(i18n.failed, true);
            });
    });
})();
