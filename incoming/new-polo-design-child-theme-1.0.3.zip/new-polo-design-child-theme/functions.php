<?php
/**
 * New Polo Design 360° - child theme di ticinoweb-ai-theme.
 *
 * Design (HTML/CSS) fedele al sito originale; i dati del cliente stanno nel database:
 * contatti, logo, servizi, FAQ e SEO nel pannello ticinoWEB CMS del parent, testi e
 * recensioni nei pannelli del tema (Aspetto > Contenuti New Polo, menu Recensioni).
 *
 * @package new-polo-design-child-theme
 */

if (!defined('ABSPATH')) {
    exit;
}

define('NPD_DIR', get_stylesheet_directory());
define('NPD_URI', get_stylesheet_directory_uri());
define('NPD_VERSION', wp_get_theme()->get('Version'));

require_once NPD_DIR . '/inc/icons.php';
require_once NPD_DIR . '/inc/content.php';
require_once NPD_DIR . '/inc/services.php';
require_once NPD_DIR . '/inc/reviews.php';
require_once NPD_DIR . '/inc/helpers.php';
if (is_admin()) {
    require_once NPD_DIR . '/inc/admin-content.php';
}

/**
 * CSS e JS: il design usa il proprio CSS compilato, quindi il foglio del parent
 * (che definisce header, footer e .container propri) non viene caricato.
 */
add_action('wp_enqueue_scripts', function () {
    foreach (array('ticinoweb-ai-style', 'poppins-font') as $handle) {
        wp_dequeue_style($handle);
    }
    wp_dequeue_script('ticinoweb-ai-main');

    wp_enqueue_style('npd-fonts', NPD_URI . '/assets/css/fonts.css', array(), NPD_VERSION);
    wp_enqueue_style('npd-app', NPD_URI . '/assets/css/app.css', array('npd-fonts'), NPD_VERSION);
    wp_enqueue_style('npd-extra', get_stylesheet_uri(), array('npd-app'), NPD_VERSION);

    wp_enqueue_script('npd-app', NPD_URI . '/assets/js/app.js', array(), NPD_VERSION, array('in_footer' => true, 'strategy' => 'defer'));
    wp_localize_script('npd-app', 'NPD', array(
        'ajaxUrl'    => admin_url('admin-ajax.php'),
        'tokenAction' => 'ticinoweb_form_token',
        'submitAction' => 'ticinoweb_submit_form',
        'recaptchaKey' => (string) get_option('ticinoweb_recaptcha_site_key', ''),
        'whatsapp'   => npd_whatsapp_number(),
        'email'      => npd_contact('email'),
        'i18n'       => array(
            'quoteTitle'   => __('Richiedi Preventivo', 'new-polo-design-child-theme'),
            'quoteTitleTpl' => __('Richiedi %s', 'new-polo-design-child-theme'),
            'quoteDesc'    => __('Compila il form per ricevere una proposta su misura.', 'new-polo-design-child-theme'),
            'sending'      => __('Invio in corso...', 'new-polo-design-child-theme'),
            'errName'      => __('Il nome è obbligatorio', 'new-polo-design-child-theme'),
            'errSurname'   => __('Il cognome è obbligatorio', 'new-polo-design-child-theme'),
            'errEmail'     => __('Email non valida', 'new-polo-design-child-theme'),
            'errPhone'     => __('Telefono obbligatorio', 'new-polo-design-child-theme'),
            'errDesc'      => __('Inserisci una descrizione di almeno 10 caratteri', 'new-polo-design-child-theme'),
            'errReview'    => __('Inserisci nome e una recensione di almeno 10 caratteri.', 'new-polo-design-child-theme'),
            'errGeneric'   => __('Si è verificato un errore. Riprova più tardi.', 'new-polo-design-child-theme'),
            'errNewsletter' => __('Inserisci un indirizzo email valido.', 'new-polo-design-child-theme'),
            'okNewsletter' => __('Grazie! Iscrizione ricevuta.', 'new-polo-design-child-theme'),
            'quoteHeader'  => __('Nuova richiesta di preventivo', 'new-polo-design-child-theme'),
            'lblName'      => __('Nome', 'new-polo-design-child-theme'),
            'lblCompany'   => __('Azienda', 'new-polo-design-child-theme'),
            'lblEmail'     => __('Email', 'new-polo-design-child-theme'),
            'lblPhone'     => __('Telefono', 'new-polo-design-child-theme'),
            'lblService'   => __('Servizio', 'new-polo-design-child-theme'),
            'lblBudget'    => __('Budget', 'new-polo-design-child-theme'),
            'lblTimeline'  => __('Tempistiche', 'new-polo-design-child-theme'),
            'lblAddress'   => __('Indirizzo', 'new-polo-design-child-theme'),
            'lblCity'      => __('Città', 'new-polo-design-child-theme'),
            'lblNotes'     => __('Note', 'new-polo-design-child-theme'),
            'lblDesc'      => __('Descrizione', 'new-polo-design-child-theme'),
            'quoteSubject' => __('Richiesta di preventivo', 'new-polo-design-child-theme'),
            'reviewSubject' => __('Nuova recensione da approvare', 'new-polo-design-child-theme'),
            'newsletterSubject' => __('Iscrizione newsletter', 'new-polo-design-child-theme'),
            'rating'       => __('Valutazione', 'new-polo-design-child-theme'),
            'close'        => __('Chiudi', 'new-polo-design-child-theme'),
            'zoomIn'       => __('Ingrandisci', 'new-polo-design-child-theme'),
            'zoomOut'      => __('Riduci', 'new-polo-design-child-theme'),
        ),
    ));
}, 100);

/** Il tema usa il tag <title> e le miniature; il resto (SEO, schema) e' del parent. */
add_action('after_setup_theme', function () {
    load_child_theme_textdomain('new-polo-design-child-theme', NPD_DIR . '/languages');
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
});

/** Font principale precaricato: evita il lampo di testo con il font di ripiego. */
add_action('wp_head', function () {
    echo '<link rel="preload" href="' . esc_url(NPD_URI . '/assets/fonts/inter-latin.woff2') . '" as="font" type="font/woff2" crossorigin>' . "\n";
}, 1);

/** Colore della barra del browser come nel sito originale. */
add_action('wp_head', function () {
    echo '<meta name="theme-color" content="#3469B7">' . "\n";
}, 2);

add_filter('body_class', function ($classes) {
    $classes[] = 'npd-site';
    return $classes;
});
