<?php
/**
 * Modello di riserva: contenuti generici nel design del sito.
 */
if (!defined('ABSPATH')) {
    exit;
}
get_header();
?>
<main id="main" class="flex-1">
    <section class="py-20 sm:py-24 bg-white">
        <div class="max-w-3xl mx-auto px-4 sm:px-6">
            <?php while (have_posts()) : the_post(); ?>
                <article <?php post_class(); ?>>
                    <h1 class="text-3xl sm:text-4xl font-extrabold text-foreground mb-8"><?php the_title(); ?></h1>
                    <div class="npd-prose text-foreground/80 leading-relaxed"><?php the_content(); ?></div>
                </article>
            <?php endwhile; ?>
        </div>
    </section>
</main>
<?php get_footer(); ?>
