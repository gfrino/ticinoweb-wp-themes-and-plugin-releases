<?php
/**
 * Recensioni dei clienti: tipo di contenuto "Recensioni" (titolo = nome, testo = recensione,
 * campo "Ruolo / azienda"). Le nuove recensioni inviate dal sito arrivano come messaggio nel
 * pannello "Invii Ricevuti" e vengono pubblicate dal titolare dopo la verifica.
 */
if (!defined('ABSPATH')) {
    exit;
}

add_action('init', function () {
    register_post_type('npd_review', array(
        'labels' => array(
            'name'          => __('Recensioni', 'new-polo-design-child-theme'),
            'singular_name' => __('Recensione', 'new-polo-design-child-theme'),
            'add_new_item'  => __('Aggiungi recensione', 'new-polo-design-child-theme'),
            'edit_item'     => __('Modifica recensione', 'new-polo-design-child-theme'),
        ),
        'public'              => false,
        'show_ui'             => true,
        'show_in_rest'        => false,
        'menu_icon'           => 'dashicons-star-filled',
        'menu_position'       => 25,
        'supports'            => array('title', 'editor', 'page-attributes'),
        'exclude_from_search' => true,
    ));
});

add_action('add_meta_boxes', function () {
    add_meta_box('npd_review_role', __('Ruolo o azienda', 'new-polo-design-child-theme'), function ($post) {
        wp_nonce_field('npd_review_role', 'npd_review_role_nonce');
        printf(
            '<p><input type="text" class="widefat" name="npd_role" value="%s" placeholder="%s"></p><p class="description">%s</p>',
            esc_attr((string) get_post_meta($post->ID, '_npd_role', true)),
            esc_attr__('Es. Titolare, Officina MB', 'new-polo-design-child-theme'),
            esc_html__('Il titolo della recensione è il nome del cliente; l\'ordine si cambia con "Ordine" nella colonna a destra.', 'new-polo-design-child-theme')
        );
    }, 'npd_review', 'side');
});

add_action('save_post_npd_review', function ($post_id) {
    if (!isset($_POST['npd_review_role_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['npd_review_role_nonce'])), 'npd_review_role')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    update_post_meta($post_id, '_npd_role', isset($_POST['npd_role']) ? sanitize_text_field(wp_unslash($_POST['npd_role'])) : '');
});

/** Recensioni pubblicate nell'ordine scelto. */
function npd_reviews() {
    $posts = get_posts(array(
        'post_type'      => 'npd_review',
        'post_status'    => 'publish',
        'posts_per_page' => 20,
        'orderby'        => array('menu_order' => 'ASC', 'ID' => 'ASC'),
    ));
    $out = array();
    foreach ($posts as $p) {
        $ctx = 'post:' . $p->ID;
        $out[] = array(
            'name' => $p->post_title,
            'role' => ticinoweb_frontend_text((string) get_post_meta($p->ID, '_npd_role', true), $ctx . ':role'),
            'text' => ticinoweb_frontend_text(wp_strip_all_tags($p->post_content), $ctx . ':content'),
        );
    }
    return $out;
}
