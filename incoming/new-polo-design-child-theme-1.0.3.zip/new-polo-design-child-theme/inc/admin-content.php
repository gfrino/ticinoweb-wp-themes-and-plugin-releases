<?php
/**
 * Pannello "Contenuti New Polo" (Aspetto): testi della home e dettagli dei servizi.
 * Titolo, descrizione e immagine dei servizi, contatti, logo, FAQ e SEO restano nel
 * pannello ticinoWEB CMS e in Bacheca > FAQ: qui non si duplicano.
 */
if (!defined('ABSPATH')) {
    exit;
}

add_action('admin_menu', function () {
    add_theme_page(
        __('Contenuti New Polo', 'new-polo-design-child-theme'),
        __('Contenuti New Polo', 'new-polo-design-child-theme'),
        'edit_theme_options',
        'npd-content',
        'npd_render_content_page'
    );
});

add_action('admin_enqueue_scripts', function ($hook) {
    if ($hook !== 'appearance_page_npd-content') {
        return;
    }
    wp_enqueue_media();
    wp_add_inline_script('jquery-core', "jQuery(function($){\$('.npd-pick').on('click',function(e){e.preventDefault();var t=\$(this).data('target');var f=wp.media({multiple:false,library:{type:'image'}});f.on('select',function(){var a=f.state().get('selection').first().toJSON();\$('#'+t).val(a.url);\$('#'+t+'-prev').attr('src',a.url).show();});f.open();});});");
});

function npd_icon_choices() {
    return array(
        'shirt' => 'Maglietta', 'car' => 'Auto', 'presentation' => 'Cartello', 'lightbulb' => 'Lampadina',
        'gift' => 'Regalo', 'tent' => 'Tenda / eventi', 'square-square' => 'Pellicola', 'pen-tool' => 'Penna grafica',
        'house' => 'Casa', 'chart-line' => 'Grafico', 'chart-pie' => 'Torta', 'printer' => 'Stampante', 'sparkles' => 'Stelle',
    );
}

function npd_render_content_page() {
    if (!current_user_can('edit_theme_options')) {
        return;
    }
    $saved = false;
    if (isset($_POST['npd_content_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['npd_content_nonce'])), 'npd_save_content')) {
        $values = array();
        foreach (npd_content_schema() as $section) {
            foreach ($section[1] as $key => $field) {
                $raw = isset($_POST['npd'][$key]) ? wp_unslash($_POST['npd'][$key]) : '';
                if ($field[1] === 'textarea') {
                    $values[$key] = sanitize_textarea_field($raw);
                } elseif ($field[1] === 'image') {
                    $values[$key] = esc_url_raw($raw);
                } else {
                    $values[$key] = sanitize_text_field($raw);
                }
            }
        }
        update_option('npd_content', $values, false);

        $details = array();
        $posted = isset($_POST['npd_srv']) && is_array($_POST['npd_srv']) ? wp_unslash($_POST['npd_srv']) : array();
        $icons = npd_icon_choices();
        foreach ($posted as $id => $d) {
            $id = sanitize_key($id);
            $lines = isset($d['contents']) ? preg_split('/\R/', sanitize_textarea_field($d['contents'])) : array();
            $details[$id] = array(
                'category' => isset($d['category']) ? sanitize_text_field($d['category']) : '',
                'icon'     => isset($d['icon'], $icons[$d['icon']]) ? $d['icon'] : 'sparkles',
                'contents' => array_values(array_filter(array_map('trim', $lines))),
            );
        }
        update_option('npd_service_details', $details, false);
        $saved = true;
    }

    $values  = get_option('npd_content', array());
    $details = get_option('npd_service_details', array());
    $services = function_exists('npd_services') ? npd_services() : array();
    ?>
    <div class="wrap">
        <h1><?php esc_html_e('Contenuti New Polo', 'new-polo-design-child-theme'); ?></h1>
        <?php if ($saved) : ?>
            <div class="notice notice-success is-dismissible"><p><?php esc_html_e('Contenuti salvati.', 'new-polo-design-child-theme'); ?></p></div>
        <?php endif; ?>
        <p><?php esc_html_e('Qui si modificano i testi della home. Contatti, logo, titoli e immagini dei servizi si cambiano in ticinoWEB CMS; le domande frequenti in Bacheca > FAQ; le recensioni nel menu Recensioni; le foto dei lavori in Gallerie media (una galleria per servizio).', 'new-polo-design-child-theme'); ?></p>
        <form method="post">
            <?php wp_nonce_field('npd_save_content', 'npd_content_nonce'); ?>
            <?php foreach (npd_content_schema() as $sid => $section) : ?>
                <h2 class="title" style="margin-top:2em"><?php echo esc_html($section[0]); ?></h2>
                <table class="form-table" role="presentation"><tbody>
                <?php foreach ($section[1] as $key => $field) :
                    $val = isset($values[$key]) ? (string) $values[$key] : ''; ?>
                    <tr>
                        <th scope="row"><label for="npd-<?php echo esc_attr($key); ?>"><?php echo esc_html($field[0]); ?></label></th>
                        <td>
                        <?php if ($field[1] === 'textarea') : ?>
                            <textarea id="npd-<?php echo esc_attr($key); ?>" name="npd[<?php echo esc_attr($key); ?>]" rows="4" class="large-text"><?php echo esc_textarea($val); ?></textarea>
                        <?php elseif ($field[1] === 'image') : ?>
                            <input type="text" id="npd-<?php echo esc_attr($key); ?>" name="npd[<?php echo esc_attr($key); ?>]" value="<?php echo esc_attr($val); ?>" class="regular-text">
                            <button type="button" class="button npd-pick" data-target="npd-<?php echo esc_attr($key); ?>"><?php esc_html_e('Scegli immagine', 'new-polo-design-child-theme'); ?></button><br>
                            <img id="npd-<?php echo esc_attr($key); ?>-prev" src="<?php echo esc_url($val); ?>" alt="" style="max-width:120px;margin-top:8px;<?php echo $val ? '' : 'display:none'; ?>">
                        <?php else : ?>
                            <input type="text" id="npd-<?php echo esc_attr($key); ?>" name="npd[<?php echo esc_attr($key); ?>]" value="<?php echo esc_attr($val); ?>" class="large-text">
                        <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody></table>
            <?php endforeach; ?>

            <h2 class="title" style="margin-top:2em"><?php esc_html_e('Dettagli dei servizi', 'new-polo-design-child-theme'); ?></h2>
            <p><?php esc_html_e('Per ogni servizio: l\'icona, la categoria mostrata nella scheda e l\'elenco "Cosa offriamo" (una voce per riga).', 'new-polo-design-child-theme'); ?></p>
            <?php foreach ($services as $s) :
                $d = isset($details[$s['id']]) && is_array($details[$s['id']]) ? $details[$s['id']] : array(); ?>
                <div style="background:#fff;border:1px solid #c3c4c7;padding:12px 16px;margin:0 0 12px;max-width:760px">
                    <strong><?php echo esc_html($s['name']); ?></strong>
                    <p><label><?php esc_html_e('Categoria', 'new-polo-design-child-theme'); ?><br>
                        <input type="text" class="regular-text" name="npd_srv[<?php echo esc_attr($s['id']); ?>][category]" value="<?php echo esc_attr($d['category'] ?? ''); ?>"></label></p>
                    <p><label><?php esc_html_e('Icona', 'new-polo-design-child-theme'); ?><br>
                        <select name="npd_srv[<?php echo esc_attr($s['id']); ?>][icon]">
                            <?php foreach (npd_icon_choices() as $ik => $il) : ?>
                                <option value="<?php echo esc_attr($ik); ?>" <?php selected($d['icon'] ?? '', $ik); ?>><?php echo esc_html($il); ?></option>
                            <?php endforeach; ?>
                        </select></label></p>
                    <p><label><?php esc_html_e('Cosa offriamo (una voce per riga)', 'new-polo-design-child-theme'); ?><br>
                        <textarea rows="5" class="large-text" name="npd_srv[<?php echo esc_attr($s['id']); ?>][contents]"><?php echo esc_textarea(implode("\n", $d['contents'] ?? array())); ?></textarea></label></p>
                </div>
            <?php endforeach; ?>
            <?php submit_button(__('Salva contenuti', 'new-polo-design-child-theme')); ?>
        </form>
    </div>
    <?php
}
