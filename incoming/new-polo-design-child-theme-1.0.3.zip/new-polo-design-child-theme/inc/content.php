<?php
/**
 * Testi del design (hero, sezioni, passi del metodo...). Sono salvati nell'opzione
 * `npd_content` e si modificano da Aspetto > Contenuti New Polo; il tema non contiene
 * testi del cliente, solo le etichette dei campi.
 */
if (!defined('ABSPATH')) {
    exit;
}

/** Schema dei campi: sezione => titolo + campi (chiave => etichetta, tipo). */
function npd_content_schema() {
    $t = 'new-polo-design-child-theme';
    $schema = array(
        'hero' => array(__('Prima schermata', $t), array(
            'hero_badge'    => array(__('Etichetta sopra il titolo', $t), 'text'),
            'hero_t1'       => array(__('Titolo, parte bianca iniziale', $t), 'text'),
            'hero_t2'       => array(__('Titolo, parte blu', $t), 'text'),
            'hero_t3'       => array(__('Titolo, parte bianca finale', $t), 'text'),
            'hero_subtitle' => array(__('Sottotitolo', $t), 'textarea'),
            'hero_cta1'     => array(__('Pulsante 1 (porta ai servizi)', $t), 'text'),
            'hero_cta2'     => array(__('Pulsante 2 (apre il preventivo)', $t), 'text'),
        )),
        'direction' => array(__('Esperienza e Visione', $t), array(
            'dir_title'  => array(__('Titolo della sezione', $t), 'text'),
            'dir_name'   => array(__('Nome', $t), 'text'),
            'dir_role'   => array(__('Ruolo', $t), 'text'),
            'dir_photo'  => array(__('Foto', $t), 'image'),
            'dir_text'   => array(__('Presentazione', $t), 'textarea'),
            'dir_points' => array(__('Punti di forza (uno per riga)', $t), 'textarea'),
            'dir_cta'    => array(__('Pulsante WhatsApp', $t), 'text'),
        )),
        'services' => array(__('Servizi e portfolio', $t), array(
            'srv_title'    => array(__('Titolo', $t), 'text'),
            'srv_subtitle' => array(__('Sottotitolo', $t), 'text'),
            'srv_more'     => array(__('Testo "Scopri di più"', $t), 'text'),
            'det_tagline'  => array(__('Scheda servizio: frase sotto il titolo', $t), 'text'),
            'det_offer'    => array(__('Scheda servizio: titolo elenco', $t), 'text'),
            'det_why'      => array(__('Scheda servizio: "Perché sceglierci"', $t), 'text'),
            'det_adv_1_t'  => array(__('Vantaggio 1, titolo', $t), 'text'),
            'det_adv_1_d'  => array(__('Vantaggio 1, testo', $t), 'text'),
            'det_adv_2_t'  => array(__('Vantaggio 2, titolo', $t), 'text'),
            'det_adv_2_d'  => array(__('Vantaggio 2, testo', $t), 'text'),
            'det_adv_3_t'  => array(__('Vantaggio 3, titolo', $t), 'text'),
            'det_adv_3_d'  => array(__('Vantaggio 3, testo', $t), 'text'),
            'det_proc'     => array(__('Scheda servizio: fasi del lavoro (una per riga)', $t), 'textarea'),
            'det_gallery'  => array(__('Scheda servizio: titolo galleria', $t), 'text'),
            'det_cta_t'    => array(__('Scheda servizio: titolo finale', $t), 'text'),
            'det_cta_d'    => array(__('Scheda servizio: testo finale', $t), 'text'),
        )),
        'method' => array(__('Come lavoriamo', $t), array(
            'met_title'    => array(__('Titolo', $t), 'text'),
            'met_subtitle' => array(__('Sottotitolo', $t), 'text'),
        )),
        'reviews' => array(__('Recensioni', $t), array(
            'rev_badge'    => array(__('Etichetta', $t), 'text'),
            'rev_title'    => array(__('Titolo', $t), 'text'),
            'rev_subtitle' => array(__('Sottotitolo', $t), 'text'),
            'rev_verified' => array(__('Testo del bollino', $t), 'text'),
            'rev_cta'      => array(__('Pulsante "Lascia una recensione"', $t), 'text'),
        )),
        'faq' => array(__('Domande frequenti', $t), array(
            'faq_badge'    => array(__('Etichetta', $t), 'text'),
            'faq_title'    => array(__('Titolo', $t), 'text'),
            'faq_subtitle' => array(__('Sottotitolo', $t), 'text'),
            'faq_set'      => array(__('Scheda FAQ da mostrare (nome o slug, da Bacheca > FAQ)', $t), 'text'),
        )),
        'sede' => array(__('Dove siamo', $t), array(
            'sede_badge' => array(__('Etichetta', $t), 'text'),
            'sede_title' => array(__('Titolo', $t), 'text'),
            'sede_text'  => array(__('Testo', $t), 'textarea'),
        )),
        'cta' => array(__('Invito finale', $t), array(
            'cta_title' => array(__('Titolo', $t), 'text'),
            'cta_text'  => array(__('Testo', $t), 'textarea'),
        )),
        'footer' => array(__('Piè di pagina e newsletter', $t), array(
            'foot_tagline' => array(__('Frase sotto il logo', $t), 'text'),
            'news_title'   => array(__('Newsletter: titolo', $t), 'text'),
            'news_text'    => array(__('Newsletter: testo', $t), 'textarea'),
            'news_note'    => array(__('Newsletter: nota sulla privacy', $t), 'text'),
        )),
        'whatsapp' => array(__('Messaggi WhatsApp precompilati', $t), array(
            'wa_info'        => array(__('Richiesta informazioni', $t), 'text'),
            'wa_appointment' => array(__('Richiesta appuntamento in sede', $t), 'text'),
        )),
    );
    for ($i = 1; $i <= 5; $i++) {
        $schema['method'][1]['met_' . $i . '_t'] = array(sprintf(__('Passo %d: titolo', $t), $i), 'text');
        $schema['method'][1]['met_' . $i . '_d'] = array(sprintf(__('Passo %d: testo', $t), $i), 'text');
    }
    return $schema;
}

/** Testo salvato per una chiave, passato dal filtro di traduzione del parent. */
function npd_c($key) {
    static $opt = null;
    if ($opt === null) {
        $opt = get_option('npd_content', array());
        $opt = is_array($opt) ? $opt : array();
    }
    $v = isset($opt[$key]) ? (string) $opt[$key] : '';
    return function_exists('ticinoweb_frontend_text') ? (string) ticinoweb_frontend_text($v, 'npd:' . $key) : $v;
}

/** Righe di un campo textarea (una per riga). */
function npd_lines($key) {
    $v = npd_c($key);
    if ($v === '') {
        return array();
    }
    return array_values(array_filter(array_map('trim', preg_split('/\R/', $v))));
}
