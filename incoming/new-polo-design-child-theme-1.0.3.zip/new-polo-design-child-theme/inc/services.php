<?php
/**
 * Servizi: titolo, descrizione e immagine sono quelli del pannello ticinoWEB CMS del parent
 * (opzione `ticinoweb_services`). Il tema aggiunge per ogni servizio icona, categoria e
 * l'elenco "Cosa offriamo" (opzione `npd_service_details`); le foto dei lavori sono nelle
 * Gallerie media del parent, una galleria per servizio con lo stesso slug dell'id.
 */
if (!defined('ABSPATH')) {
    exit;
}

/** Servizi pronti per i template. */
function npd_services() {
    $services = get_option('ticinoweb_services', array());
    $details  = get_option('npd_service_details', array());
    $services = is_array($services) ? $services : array();
    $details  = is_array($details) ? $details : array();
    $out = array();
    foreach ($services as $s) {
        if (empty($s['title'])) {
            continue;
        }
        $id = !empty($s['id']) ? sanitize_key($s['id']) : sanitize_title($s['title']);
        $d  = isset($details[$id]) && is_array($details[$id]) ? $details[$id] : array();
        $ctx = 'theme:service:' . $id;
        $contents = isset($d['contents']) && is_array($d['contents']) ? $d['contents'] : array();
        $out[] = array(
            'id'       => $id,
            'name'     => ticinoweb_frontend_text((string) $s['title'], $ctx . ':title'),
            'desc'     => ticinoweb_frontend_text(wp_strip_all_tags((string) ($s['description'] ?? '')), $ctx . ':description'),
            'image'    => !empty($s['image']) ? $s['image'] : '',
            'icon'     => !empty($d['icon']) ? $d['icon'] : 'sparkles',
            'category' => ticinoweb_frontend_text((string) ($d['category'] ?? ''), $ctx . ':category'),
            'contents' => array_map(function ($c) use ($ctx) {
                return ticinoweb_frontend_text((string) $c, $ctx . ':content:' . md5($c));
            }, $contents),
        );
    }
    return $out;
}

/** Foto di una galleria media del parent, nell'ordine scelto in Gallerie media. */
function npd_gallery($slug) {
    $term = get_term_by('slug', $slug, 'ticinoweb_media_gallery');
    if (!$term || is_wp_error($term)) {
        return array();
    }
    $posts = get_posts(array(
        'post_type'      => 'attachment',
        'post_status'    => 'inherit',
        'posts_per_page' => -1,
        'orderby'        => 'ID',
        'order'          => 'ASC',
        'tax_query'      => array(array('taxonomy' => 'ticinoweb_media_gallery', 'field' => 'term_id', 'terms' => $term->term_id)),
    ));
    $order = get_term_meta($term->term_id, '_ticinoweb_gallery_order', true);
    if (is_array($order) && $order) {
        usort($posts, function ($a, $b) use ($order) {
            $pa = array_search($a->ID, $order);
            $pb = array_search($b->ID, $order);
            return ($pa === false ? 999999 : $pa) <=> ($pb === false ? 999999 : $pb);
        });
    }
    $items = array();
    foreach ($posts as $p) {
        $large = wp_get_attachment_image_src($p->ID, 'large');
        $full  = wp_get_attachment_image_src($p->ID, 'full');
        if (!$large) {
            continue;
        }
        $items[] = array(
            'src'   => $large[0],
            'w'     => $large[1],
            'h'     => $large[2],
            'full'  => $full ? $full[0] : $large[0],
            'title' => ticinoweb_frontend_text($p->post_title, 'post:' . $p->ID . ':title'),
        );
    }
    return $items;
}
