/* New Polo Design 360° - interazioni del design (JavaScript puro, nessuna libreria). */
(function () {
  'use strict';

  var cfg = window.NPD || {};
  var t = cfg.i18n || {};
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  /* ---------- Barra di avanzamento ---------- */
  var bar = $('[data-npd-progress]');
  if (bar) {
    var tick = false;
    var update = function () {
      var h = document.documentElement.scrollHeight - window.innerHeight;
      bar.style.transform = 'scaleX(' + (h > 0 ? Math.min(1, window.scrollY / h) : 0) + ')';
      tick = false;
    };
    window.addEventListener('scroll', function () { if (!tick) { tick = true; requestAnimationFrame(update); } }, { passive: true });
    update();
  }

  /* ---------- Menu mobile ---------- */
  var menuBtn = $('[data-npd-menu]');
  var menu = $('#mobile-nav');
  function setMenu(open) {
    if (!menuBtn || !menu) { return; }
    menu.hidden = !open;
    menuBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
    $('[data-npd-menu-open]', menuBtn).hidden = open;
    $('[data-npd-menu-close]', menuBtn).hidden = !open;
  }
  if (menuBtn) {
    menuBtn.addEventListener('click', function () { setMenu(menu.hidden); });
    $$('[data-npd-menu-link]').forEach(function (a) { a.addEventListener('click', function () { setMenu(false); }); });
  }

  /* ---------- Selettore lingua ---------- */
  $$('.npd-lang').forEach(function (box) {
    var btn = $('[data-npd-lang]', box);
    var list = $('.npd-lang-menu', box);
    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      var open = list.hidden;
      $$('.npd-lang-menu').forEach(function (l) { l.hidden = true; });
      list.hidden = !open;
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  });
  document.addEventListener('click', function () { $$('.npd-lang-menu').forEach(function (l) { l.hidden = true; }); });

  /* ---------- Pannelli a comparsa ---------- */
  var openLayers = [];
  var lastFocus = null;
  function lock() { document.body.classList.toggle('npd-lock', openLayers.length > 0); }
  function showLayer(el, focusEl) {
    if (!el) { return; }
    lastFocus = document.activeElement;
    el.hidden = false;
    openLayers.push(el);
    lock();
    var f = focusEl || $('[role="dialog"]', el) || el;
    setTimeout(function () { if (f && f.focus) { f.focus({ preventScroll: true }); } }, 30);
  }
  function hideLayer(el) {
    if (!el || el.hidden) { return; }
    el.hidden = true;
    openLayers = openLayers.filter(function (l) { return l !== el; });
    lock();
    if (!openLayers.length && lastFocus && lastFocus.focus) { try { lastFocus.focus({ preventScroll: true }); } catch (e) {} }
  }
  function topLayer() { return openLayers[openLayers.length - 1]; }

  document.addEventListener('keydown', function (e) {
    var layer = topLayer();
    if (!layer) { return; }
    if (e.key === 'Escape') { e.preventDefault(); if (layer === lb) { closeLightbox(); } else { hideLayer(layer); } }
    if (layer === lb) {
      if (e.key === 'ArrowRight') { stepLightbox(1); }
      if (e.key === 'ArrowLeft') { stepLightbox(-1); }
    }
    if (e.key === 'Tab' && !layer.hasAttribute('data-npd-sheet-overlay')) {
      var items = $$('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])', layer).filter(function (n) { return !n.disabled && n.offsetParent !== null; });
      if (!items.length) { return; }
      var first = items[0], last = items[items.length - 1];
      if (!layer.contains(document.activeElement)) { e.preventDefault(); first.focus(); }
      else if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });

  /* click sullo sfondo o su un pulsante "chiudi" */
  $$('.npd-overlay').forEach(function (ov) {
    ov.addEventListener('mousedown', function (e) { if (e.target === ov) { hideLayer(ov); } });
    $$('[data-npd-close]', ov).forEach(function (b) { b.addEventListener('click', function () { hideLayer(ov); }); });
  });

  /* Il menu resta visibile sopra la scheda servizio: un clic sul menu la chiude e porta alla sezione. */
  $$('.npd-header a[href]').forEach(function (a) {
    a.addEventListener('click', function () { if (sheetOv && !sheetOv.hidden) { hideLayer(sheetOv); } });
  });

  /* ---------- Scheda servizio ---------- */
  var sheetOv = $('[data-npd-sheet-overlay]');
  var sheetBody = $('[data-npd-sheet-body]');
  var galleryItems = [];
  function openService(id) {
    var src = document.getElementById('npd-detail-' + id);
    if (!src || !sheetOv) { return; }
    sheetBody.innerHTML = src.innerHTML;
    sheetBody.scrollTop = 0;
    galleryItems = $$('[data-npd-zoom]', sheetBody).map(function (b) {
      return { src: b.getAttribute('data-full'), title: b.getAttribute('data-title') || '', cat: b.getAttribute('data-cat') || '' };
    });
    $$('[data-npd-zoom]', sheetBody).forEach(function (b, i) { b.addEventListener('click', function () { openLightbox(i); }); });
    var hd = $('.npd-header');
    sheetOv.style.paddingTop = (hd ? Math.max(0, Math.round(hd.getBoundingClientRect().bottom)) : 80) + 'px';
    showLayer(sheetOv, $('.npd-sheet', sheetOv));
  }
  $$('[data-npd-service]').forEach(function (card) {
    var id = card.getAttribute('data-npd-service');
    card.addEventListener('click', function () { openService(id); });
    card.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openService(id); } });
  });

  /* ---------- Galleria ingrandita ---------- */
  var lb = $('[data-npd-lightbox]');
  var lbIndex = 0, lbZoom = false;
  function renderLightbox() {
    var it = galleryItems[lbIndex];
    if (!it) { return; }
    var img = $('[data-npd-lb-img]', lb);
    img.src = it.src; img.alt = it.title;
    $('[data-npd-lb-title]', lb).textContent = it.title;
    $('[data-npd-lb-cat]', lb).textContent = it.cat;
    $('[data-npd-lb-count]', lb).textContent = (lbIndex + 1) + ' / ' + galleryItems.length;
    lbZoom = false; img.classList.remove('scale-150', 'cursor-zoom-out'); img.classList.add('cursor-zoom-in');
  }
  function openLightbox(i) { lbIndex = i; renderLightbox(); showLayer(lb, $('[data-npd-lb-close]', lb)); }
  function closeLightbox() { hideLayer(lb); }
  function stepLightbox(d) { lbIndex = (lbIndex + d + galleryItems.length) % galleryItems.length; renderLightbox(); }
  function toggleZoom() {
    var img = $('[data-npd-lb-img]', lb);
    lbZoom = !lbZoom;
    img.classList.toggle('scale-150', lbZoom); img.classList.toggle('cursor-zoom-out', lbZoom); img.classList.toggle('cursor-zoom-in', !lbZoom);
  }
  if (lb) {
    lb.addEventListener('click', function (e) { if (e.target === lb) { closeLightbox(); } });
    $('[data-npd-lb-close]', lb).addEventListener('click', function (e) { e.stopPropagation(); closeLightbox(); });
    $('[data-npd-lb-prev]', lb).addEventListener('click', function (e) { e.stopPropagation(); stepLightbox(-1); });
    $('[data-npd-lb-next]', lb).addEventListener('click', function (e) { e.stopPropagation(); stepLightbox(1); });
    $('[data-npd-lb-zoom]', lb).addEventListener('click', function (e) { e.stopPropagation(); toggleZoom(); });
    $('[data-npd-lb-img]', lb).addEventListener('click', function (e) { e.stopPropagation(); toggleZoom(); });
  }

  /* ---------- Recensioni (carosello) ---------- */
  var car = $('[data-npd-carousel]');
  if (car) {
    var slides = $$('[data-npd-slide]', car), dots = $$('[data-npd-dot]', car), cur = 0, paused = false;
    var go = function (n) {
      cur = (n + slides.length) % slides.length;
      slides.forEach(function (s, i) { s.hidden = i !== cur; });
      dots.forEach(function (d, i) { d.className = 'h-2 rounded-full transition-all ' + (i === cur ? 'w-6 bg-primary' : 'w-2 bg-border'); });
    };
    var prev = $('[data-npd-prev]', car), next = $('[data-npd-next]', car);
    if (prev) { prev.addEventListener('click', function () { go(cur - 1); }); }
    if (next) { next.addEventListener('click', function () { go(cur + 1); }); }
    dots.forEach(function (d, i) { d.addEventListener('click', function () { go(i); }); });
    car.addEventListener('mouseenter', function () { paused = true; });
    car.addEventListener('mouseleave', function () { paused = false; });
    car.addEventListener('focusin', function () { paused = true; });
    car.addEventListener('focusout', function () { paused = false; });
    var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (slides.length > 1 && !reduce) { setInterval(function () { if (!paused && !document.hidden) { go(cur + 1); } }, 5000); }
  }

  /* ---------- FAQ ---------- */
  $$('.npd-faq-item').forEach(function (item) {
    var btn = $('.npd-faq-btn', item), panel = document.getElementById(btn.getAttribute('aria-controls'));
    btn.addEventListener('click', function () {
      var open = btn.getAttribute('aria-expanded') === 'true';
      btn.setAttribute('aria-expanded', open ? 'false' : 'true');
      panel.hidden = open;
      item.classList.toggle('is-open', !open);
    });
  });

  /* ---------- Invio dei moduli (gestore del parent ticinoWEB) ---------- */
  function getToken() {
    return fetch(cfg.ajaxUrl + '?action=' + cfg.tokenAction, { credentials: 'same-origin', cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .then(function (j) { if (!j || !j.success) { throw new Error('token'); } return j.data.token; });
  }
  function recaptcha() {
    if (!cfg.recaptchaKey || !window.grecaptcha) { return Promise.resolve(''); }
    return new Promise(function (resolve) {
      window.grecaptcha.ready(function () {
        window.grecaptcha.execute(cfg.recaptchaKey, { action: 'submit' }).then(resolve, function () { resolve(''); });
      });
    });
  }
  /** Invia nome, email, telefono, oggetto, messaggio al gestore generico del parent. */
  function submitForm(fields, honeypot) {
    return Promise.all([getToken(), recaptcha()]).then(function (res) {
      var body = new URLSearchParams();
      body.set('action', cfg.submitAction);
      body.set('token', res[0]);
      if (res[1]) { body.set('recaptcha_token', res[1]); }
      body.set('tw_hp', honeypot || '');
      Object.keys(fields).forEach(function (k) { body.set(k, fields[k] || ''); });
      return fetch(cfg.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body });
    }).then(function (r) { return r.json(); }).then(function (j) {
      if (!j || !j.success) { var m = j && j.data && j.data.message; throw new Error(m || t.errGeneric); }
      return j.data;
    });
  }
  function emailOk(v) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(v).trim()); }
  function val(form, name) { var el = form.elements[name]; return el ? el.value.trim() : ''; }
  function showErr(form, name, msg) {
    var em = $('[data-err="' + name + '"]', form), el = form.elements[name];
    if (em) { em.textContent = msg || ''; }
    if (el) { if (msg) { el.setAttribute('aria-invalid', 'true'); } else { el.removeAttribute('aria-invalid'); } }
  }

  /* ---------- Preventivo ---------- */
  var quoteOv = $('[data-npd-quote-overlay]');
  var quoteForm = quoteOv && $('[data-npd-quote-form]', quoteOv);
  function quoteServiceInfo(name) {
    var box = $('[data-npd-quote-include]', quoteOv), list = $('[data-npd-quote-include-list]', quoteOv);
    var title = $('[data-npd-quote-title]', quoteOv), desc = $('[data-npd-quote-desc]', quoteOv);
    list.innerHTML = '';
    var contents = [];
    if (name) {
      $$('.npd-details article').forEach(function (a) {
        if (a.getAttribute('data-name') === name) { try { contents = JSON.parse(a.getAttribute('data-contents') || '[]'); } catch (e) {} }
      });
    }
    title.textContent = name ? (t.quoteTitleTpl || '%s').replace('%s', name) : t.quoteTitle;
    desc.textContent = t.quoteDesc;
    contents.forEach(function (c) { var li = document.createElement('li'); li.textContent = '• ' + c; list.appendChild(li); });
    box.hidden = !contents.length;
  }
  function openQuote(service) {
    if (!quoteOv) { return; }
    hideLayer(sheetOv);
    setMenu(false);
    $('[data-npd-quote-form-wrap]', quoteOv).hidden = false;
    $('[data-npd-quote-done]', quoteOv).hidden = true;
    if (service !== undefined) { quoteForm.elements.servizio.value = service || ''; }
    quoteServiceInfo(quoteForm.elements.servizio.value);
    showLayer(quoteOv, $('.npd-modal', quoteOv));
  }
  if (quoteForm) {
    quoteForm.elements.servizio.addEventListener('change', function () { quoteServiceInfo(this.value); });
    $('[data-npd-quote-again]', quoteOv).addEventListener('click', function () { quoteForm.reset(); openQuote(''); });
    var sending = false;
    $$('[data-npd-send]', quoteForm).forEach(function (btn) {
      btn.addEventListener('click', function () {
        if (sending) { return; }
        var ok = true, errBox = $('[data-npd-quote-error]', quoteOv);
        errBox.hidden = true;
        var checks = [['nome', val(quoteForm, 'nome').length >= 2, t.errName], ['cognome', val(quoteForm, 'cognome').length >= 2, t.errSurname], ['email', emailOk(val(quoteForm, 'email')), t.errEmail], ['telefono', val(quoteForm, 'telefono').length >= 5, t.errPhone], ['descrizione', val(quoteForm, 'descrizione').length >= 10, t.errDesc]];
        checks.forEach(function (c) { showErr(quoteForm, c[0], c[1] ? '' : c[2]); if (!c[1]) { ok = false; } });
        if (!ok) { var bad = $('[aria-invalid="true"]', quoteForm); if (bad) { bad.focus(); } return; }

        var channel = btn.getAttribute('data-npd-send');
        var d = function (n) { return val(quoteForm, n) || '-'; };
        var lines = [
          t.lblName + ': ' + val(quoteForm, 'nome') + ' ' + val(quoteForm, 'cognome'), t.lblCompany + ': ' + d('azienda'),
          t.lblEmail + ': ' + val(quoteForm, 'email'), t.lblPhone + ': ' + val(quoteForm, 'telefono'),
          t.lblService + ': ' + d('servizio'), t.lblBudget + ': ' + d('budget'), t.lblTimeline + ': ' + d('tempistiche'),
          t.lblAddress + ': ' + d('indirizzo'), t.lblCity + ': ' + d('citta'), t.lblNotes + ': ' + d('note'),
          t.lblDesc + ':\n' + val(quoteForm, 'descrizione')
        ];
        var waWin = null;
        if (channel === 'whatsapp') { waWin = window.open('about:blank', '_blank'); }
        sending = true; btn.disabled = true;
        var label = $('span', btn), old = label.textContent; label.textContent = t.sending;
        submitForm({
          nome: val(quoteForm, 'nome') + ' ' + val(quoteForm, 'cognome'), email: val(quoteForm, 'email'), telefono: val(quoteForm, 'telefono'),
          oggetto: t.quoteSubject + (val(quoteForm, 'servizio') ? ' - ' + val(quoteForm, 'servizio') : ''), messaggio: lines.join('\n')
        }, quoteForm.elements.tw_hp.value).then(function () {
          if (channel === 'whatsapp' && cfg.whatsapp) {
            var url = 'https://wa.me/' + cfg.whatsapp + '?text=' + encodeURIComponent(t.quoteHeader + '\n\n' + lines.join('\n'));
            if (waWin) { waWin.location.href = url; } else { window.open(url, '_blank'); }
          } else if (waWin) { waWin.close(); }
          $('[data-npd-quote-form-wrap]', quoteOv).hidden = true;
          $('[data-npd-quote-done]', quoteOv).hidden = false;
          quoteForm.reset();
        }).catch(function (err) {
          if (waWin) { waWin.close(); }
          errBox.textContent = err && err.message ? err.message : t.errGeneric;
          errBox.hidden = false;
        }).then(function () { sending = false; btn.disabled = false; label.textContent = old; });
      });
    });
  }

  document.addEventListener('click', function (e) {
    var o = e.target.closest ? e.target.closest('[data-npd-open]') : null;
    if (!o) { return; }
    e.preventDefault();
    var what = o.getAttribute('data-npd-open');
    if (what === 'quote') { openQuote(o.hasAttribute('data-service') ? o.getAttribute('data-service') : ''); }
    if (what === 'review') { openReview(); }
  });

  /* ---------- Nuova recensione ---------- */
  var revOv = $('[data-npd-review-overlay]');
  var revForm = revOv && $('[data-npd-review-form]', revOv);
  var rating = 5;
  function paintStars() {
    $$('[data-npd-star]', revOv).forEach(function (s) {
      var n = parseInt(s.getAttribute('data-npd-star'), 10);
      s.setAttribute('aria-checked', n === rating ? 'true' : 'false');
      var svg = $('svg', s); if (svg) { svg.classList.toggle('fill-current', n <= rating); }
    });
  }
  function openReview() {
    if (!revOv) { return; }
    $('[data-npd-review-form-wrap]', revOv).hidden = false;
    $('[data-npd-review-done]', revOv).hidden = true;
    rating = 5; paintStars();
    showLayer(revOv, $('.npd-modal', revOv));
  }
  if (revForm) {
    $$('[data-npd-star]', revOv).forEach(function (s) { s.addEventListener('click', function () { rating = parseInt(s.getAttribute('data-npd-star'), 10); paintStars(); }); });
    revForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var errBox = $('[data-npd-review-error]', revOv);
      errBox.hidden = true;
      if (val(revForm, 'nome').length < 2 || val(revForm, 'testo').length < 10 || !emailOk(val(revForm, 'email'))) { errBox.textContent = t.errReview; errBox.hidden = false; return; }
      var submit = $('button[type="submit"]', revForm); submit.disabled = true;
      var msg = [t.lblName + ': ' + val(revForm, 'nome'), t.lblCompany + ': ' + (val(revForm, 'azienda') || '-'), t.rating + ': ' + rating + '/5', '', val(revForm, 'testo')].join('\n');
      submitForm({ nome: val(revForm, 'nome'), email: val(revForm, 'email'), telefono: '', oggetto: t.reviewSubject, messaggio: msg }, revForm.elements.tw_hp.value)
        .then(function () { $('[data-npd-review-form-wrap]', revOv).hidden = true; $('[data-npd-review-done]', revOv).hidden = false; revForm.reset(); })
        .catch(function (err) { errBox.textContent = err && err.message ? err.message : t.errGeneric; errBox.hidden = false; })
        .then(function () { submit.disabled = false; });
    });
  }

  /* ---------- Newsletter ---------- */
  $$('[data-npd-newsletter]').forEach(function (form) {
    var msg = $('[data-npd-newsletter-msg]', form);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var email = val(form, 'email').toLowerCase();
      msg.className = 'text-sm font-medium text-red-400';
      if (!emailOk(email)) { msg.textContent = t.errNewsletter; return; }
      var btn = $('button[type="submit"]', form); btn.disabled = true;
      submitForm({ nome: 'Newsletter', email: email, telefono: '', oggetto: t.newsletterSubject, messaggio: t.newsletterSubject + ': ' + email }, form.elements.tw_hp.value)
        .then(function () { msg.className = 'text-sm font-medium text-[#25D366]'; msg.textContent = t.okNewsletter; form.reset(); })
        .catch(function (err) { msg.textContent = err && err.message ? err.message : t.errGeneric; })
        .then(function () { btn.disabled = false; });
    });
  });

  /* reCAPTCHA v3: caricato solo se il sito ha le chiavi, alla prima interazione con un modulo */
  if (cfg.recaptchaKey) {
    var loaded = false;
    var loadRc = function () {
      if (loaded) { return; }
      loaded = true;
      var s = document.createElement('script');
      s.src = 'https://www.google.com/recaptcha/api.js?render=' + encodeURIComponent(cfg.recaptchaKey);
      s.async = true; document.head.appendChild(s);
    };
    document.addEventListener('focusin', function (e) { if (e.target.closest && e.target.closest('form')) { loadRc(); } });
  }
})();
