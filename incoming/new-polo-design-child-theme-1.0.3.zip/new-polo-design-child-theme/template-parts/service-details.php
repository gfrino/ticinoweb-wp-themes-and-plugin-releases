<?php
/**
 * Schede di dettaglio dei servizi. Il testo e' nell'HTML (leggibile da Google e dalle AI);
 * il JS le apre in un pannello a scorrimento quando si clicca sulla card del servizio.
 *
 * @var array $args ['services' => elenco da npd_services()]
 */
if (!defined('ABSPATH')) {
    exit;
}
$npd_services = isset($args['services']) ? $args['services'] : array();
$npd_adv = array();
for ($i = 1; $i <= 3; $i++) {
    if (npd_c('det_adv_' . $i . '_t') !== '') {
        $npd_adv[] = array(npd_c('det_adv_' . $i . '_t'), npd_c('det_adv_' . $i . '_d'));
    }
}
$npd_proc = npd_lines('det_proc');
?>
<div class="npd-details" hidden>
<?php foreach ($npd_services as $s) :
    $img = $s['image'] !== '' ? $s['image'] : NPD_URI . '/assets/img/services/' . $s['id'] . '.webp';
    $gallery = npd_gallery($s['id']); ?>
    <article id="npd-detail-<?php echo esc_attr($s['id']); ?>" data-name="<?php echo esc_attr($s['name']); ?>" data-contents="<?php echo esc_attr(wp_json_encode($s['contents'])); ?>">
        <div class="relative w-full h-[42vh] min-h-[280px] max-h-[440px] overflow-hidden">
            <img alt="<?php echo esc_attr($s['name']); ?>" class="w-full h-full object-cover" src="<?php echo esc_url($img); ?>" loading="lazy">
            <div class="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-black/20"></div>
            <div class="absolute inset-0 flex items-end">
                <div class="mx-auto w-full max-w-4xl px-4 sm:px-6 pb-7">
                    <div class="flex items-center gap-3 mb-4">
                        <div class="w-12 h-12 rounded-xl bg-accent text-white flex items-center justify-center shadow-lg"><?php echo npd_icon($s['icon'], 24, '', 1.75); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
                        <?php if ($s['category'] !== '') : ?><span class="text-xs font-semibold uppercase tracking-wider text-white/90 bg-white/15 backdrop-blur px-3 py-1 rounded-full"><?php echo esc_html($s['category']); ?></span><?php endif; ?>
                    </div>
                    <h2 class="tracking-tight text-3xl sm:text-4xl font-bold text-white"><?php echo esc_html($s['name']); ?></h2>
                    <?php if (npd_c('det_tagline') !== '') : ?><p class="text-white/80 text-sm sm:text-base mt-2 max-w-2xl"><?php echo esc_html(npd_c('det_tagline')); ?></p><?php endif; ?>
                </div>
            </div>
        </div>
        <div class="mx-auto w-full max-w-4xl px-4 sm:px-6">
            <p class="text-base sm:text-lg text-muted-foreground leading-relaxed mt-8 mb-10 max-w-3xl"><?php echo esc_html($s['desc']); ?></p>
            <?php if ($s['contents']) : ?>
            <div class="mb-10 p-6 sm:p-8 bg-primary/5 rounded-2xl border border-primary/10">
                <h3 class="font-semibold text-primary mb-5 flex items-center gap-2 text-lg"><?php echo npd_icon('circle-check', 20); // phpcs:ignore WordPress.Security.EscapeOutput ?> <?php echo esc_html(npd_c('det_offer')); ?></h3>
                <ul class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm sm:text-base text-foreground/80">
                    <?php foreach ($s['contents'] as $c) : ?><li class="flex items-start gap-2"><?php echo npd_icon('circle-check', 16, 'text-accent mt-1 flex-shrink-0'); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo esc_html($c); ?></li><?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>
            <?php if ($npd_adv) : ?>
            <div class="mb-10">
                <h3 class="font-bold text-foreground mb-5 text-xl"><?php echo esc_html(npd_c('det_why')); ?></h3>
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <?php foreach ($npd_adv as $a) : ?>
                        <div class="p-5 rounded-2xl border border-border bg-card hover:shadow-md transition-shadow">
                            <div class="w-10 h-10 rounded-lg bg-accent/10 text-accent flex items-center justify-center mb-3"><?php echo npd_icon('circle-check', 20); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
                            <h4 class="font-semibold text-foreground mb-1"><?php echo esc_html($a[0]); ?></h4>
                            <p class="text-sm text-muted-foreground leading-relaxed"><?php echo esc_html($a[1]); ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
            <?php if ($npd_proc) : ?>
            <div class="mb-10">
                <h3 class="font-bold text-foreground mb-5 text-xl"><?php echo esc_html(npd_c('met_title')); ?></h3>
                <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <?php foreach ($npd_proc as $n => $step) : ?>
                        <div class="relative p-4 rounded-2xl bg-muted/50 border border-border"><span class="text-2xl font-bold text-primary/30"><?php echo esc_html(str_pad((string) ($n + 1), 2, '0', STR_PAD_LEFT)); ?></span><p class="text-sm font-medium text-foreground mt-1 leading-snug"><?php echo esc_html($step); ?></p></div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
            <?php if ($gallery) : ?>
            <div class="mb-10">
                <h3 class="font-bold text-foreground mb-5 text-xl flex items-center gap-2"><?php echo npd_icon('images', 20, 'text-accent'); // phpcs:ignore WordPress.Security.EscapeOutput ?> <?php echo esc_html(npd_c('det_gallery')); ?></h3>
                <div class="columns-2 lg:columns-3 gap-3 sm:gap-4 [column-fill:_balance]">
                    <?php foreach ($gallery as $g) : ?>
                        <div class="mb-3 sm:mb-4 break-inside-avoid">
                            <button type="button" data-npd-zoom data-full="<?php echo esc_url($g['full']); ?>" data-title="<?php echo esc_attr($g['title']); ?>" data-cat="<?php echo esc_attr($s['category']); ?>" aria-label="<?php echo esc_attr($g['title']); ?>" class="group relative block w-full overflow-hidden rounded-2xl shadow-[0_8px_30px_rgb(0,0,0,0.08)] focus:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 cursor-pointer">
                                <img alt="<?php echo esc_attr($g['title']); ?>" loading="lazy" width="<?php echo (int) $g['w']; ?>" height="<?php echo (int) $g['h']; ?>" class="w-full h-auto block transition-transform duration-500 group-hover:scale-105" src="<?php echo esc_url($g['src']); ?>">
                                <div class="absolute inset-0 bg-gradient-to-t from-black/70 via-black/0 to-transparent opacity-70 group-hover:opacity-90 transition-opacity duration-300 pointer-events-none"></div>
                                <div class="absolute bottom-0 left-0 p-3 sm:p-4 z-10 pointer-events-none"><span class="block text-xs sm:text-sm font-bold text-white leading-tight"><?php echo esc_html($g['title']); ?></span></div>
                                <div class="absolute top-3 right-3 w-9 h-9 rounded-full bg-white/0 group-hover:bg-accent flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-all duration-300 z-10 pointer-events-none"><?php echo npd_icon('zoom-in', 18); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
                            </button>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
            <div class="rounded-3xl bg-gradient-to-br from-primary to-[#2F65B8] p-8 sm:p-10 text-center text-white">
                <h3 class="text-2xl sm:text-3xl font-bold mb-2"><?php echo esc_html(npd_c('det_cta_t')); ?></h3>
                <p class="text-white/85 mb-7 max-w-xl mx-auto"><?php echo esc_html(npd_c('det_cta_d')); ?></p>
                <div class="flex flex-col sm:flex-row gap-3 justify-center max-w-lg mx-auto">
                    <button type="button" data-npd-open="quote" data-service="<?php echo esc_attr($s['name']); ?>" class="inline-flex items-center justify-center gap-2 whitespace-nowrap transition-colors min-h-9 px-4 flex-1 h-13 py-6 text-base bg-accent hover:bg-accent/90 text-accent-foreground rounded-xl font-bold"><?php esc_html_e('Richiedi Preventivo', 'new-polo-design-child-theme'); ?></button>
                    <?php if (npd_whatsapp_number()) : ?>
                    <a href="<?php echo esc_url(npd_whatsapp_url(sprintf(__('Ciao! Vorrei informazioni sul servizio "%s".', 'new-polo-design-child-theme'), $s['name']))); ?>" target="_blank" rel="noopener noreferrer" class="inline-flex items-center justify-center gap-2 whitespace-nowrap min-h-9 px-4 flex-1 h-13 py-6 text-base rounded-xl border-2 border-white/70 text-white bg-transparent hover:bg-white/10 font-bold"><?php echo npd_icon('message-circle', 20); // phpcs:ignore WordPress.Security.EscapeOutput ?> WhatsApp</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </article>
<?php endforeach; ?>
</div>
