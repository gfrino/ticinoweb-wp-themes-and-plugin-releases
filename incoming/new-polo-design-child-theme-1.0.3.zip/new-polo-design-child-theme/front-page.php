<?php
/**
 * Home del design New Polo Design 360°.
 */
if (!defined('ABSPATH')) {
    exit;
}
get_header();

$npd_name     = ticinoweb_frontend_text(get_bloginfo('name'), 'theme:branding:site_name');
$npd_services = npd_services();
$npd_reviews  = npd_reviews();
$npd_faq      = npd_c('faq_set') !== '' && function_exists('ticinoweb_faq_get_set') ? ticinoweb_faq_get_set(npd_c('faq_set')) : null;
if ($npd_faq && !empty($npd_faq['items'])) {
    ticinoweb_faq_schema_add($npd_faq['items']);
}
$npd_wa_url = npd_whatsapp_url(npd_c('wa_info'));
$npd_btn    = 'inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 hover-elevate active-elevate-2';
$npd_phone  = npd_phone_display();
$npd_addr   = npd_contact('address');
$npd_email  = npd_contact('email');
$npd_hours  = npd_opening_rows();
$npd_dir_photo = npd_c('dir_photo') !== '' ? npd_c('dir_photo') : NPD_URI . '/assets/img/direzione.webp';
?>
<main id="main" class="flex-1">

<section class="relative overflow-hidden pt-20 pb-32 lg:pt-32 lg:pb-48 flex items-center justify-center min-h-[80vh] bg-gradient-to-br from-[#0a1d3a] via-[#081a32] to-[#061428]">
    <div class="absolute inset-0 z-0 overflow-hidden opacity-30 pointer-events-none">
        <div class="absolute -top-[50%] -left-[50%] w-[200%] h-[200%] bg-[conic-gradient(from_0deg,transparent_0_330deg,rgba(242,140,40,0.18)_360deg)] npd-spin-slow"></div>
        <div class="absolute -top-[20%] -right-[20%] w-[150%] h-[150%] rounded-full border border-white/10 border-dashed npd-spin-slower"></div>
    </div>
    <div class="container mx-auto px-4 relative z-10 text-center max-w-4xl">
        <div class="npd-in"><span class="inline-block py-1 px-3 rounded-full bg-white/10 text-white/90 ring-1 ring-white/15 backdrop-blur font-semibold text-sm mb-6 uppercase tracking-wider"><?php echo esc_html(npd_c('hero_badge')); ?></span></div>
        <img alt="<?php echo esc_attr($npd_name); ?>" class="mx-auto mb-8 h-28 md:h-40 object-contain npd-in" style="--d:.05s" src="<?php echo esc_url(npd_logo_url(true)); ?>" width="218" height="140" fetchpriority="high">
        <h1 class="text-5xl md:text-7xl font-extrabold tracking-tight mb-6 leading-[1.1] npd-in" style="--d:.1s"><span class="text-white"><?php echo esc_html(npd_c('hero_t1')); ?></span><span class="text-primary"><?php echo esc_html(npd_c('hero_t2')); ?></span> <span class="text-white"><?php echo esc_html(npd_c('hero_t3')); ?></span></h1>
        <p class="text-xl md:text-2xl text-white/70 mb-10 leading-relaxed font-light npd-in" style="--d:.2s"><?php echo esc_html(npd_c('hero_subtitle')); ?></p>
        <div class="flex flex-col sm:flex-row items-center justify-center gap-4 npd-in" style="--d:.3s">
            <a href="#servizi" class="<?php echo esc_attr($npd_btn); ?> border border-primary-border min-h-10 w-full sm:w-auto h-14 px-8 text-lg bg-primary hover:bg-primary/90 text-primary-foreground rounded-full shadow-lg shadow-primary/40 ring-1 ring-white/10 hover:-translate-y-1 transition-all flex items-center gap-2"><?php echo esc_html(npd_c('hero_cta1')); ?> <?php echo npd_icon('arrow-right', 20); // phpcs:ignore WordPress.Security.EscapeOutput ?></a>
            <button type="button" data-npd-open="quote" class="<?php echo esc_attr($npd_btn); ?> shadow-xs active:shadow-none min-h-10 w-full sm:w-auto h-14 px-8 text-lg rounded-full border-2 border-primary bg-primary/10 text-white hover:bg-primary hover:text-primary-foreground hover:-translate-y-1 transition-all"><?php echo esc_html(npd_c('hero_cta2')); ?></button>
        </div>
    </div>
</section>

<?php if (npd_c('dir_name') !== '') : ?>
<section id="direzione" class="py-20 sm:py-24 bg-muted/40 relative z-10 overflow-hidden">
    <div class="max-w-6xl mx-auto px-4 sm:px-6">
        <div class="text-center mb-12"><h2 class="text-2xl sm:text-4xl font-extrabold text-foreground"><?php echo esc_html(npd_c('dir_title')); ?></h2></div>
        <div class="relative grid md:grid-cols-[0.9fr_1.1fr] gap-8 items-center rounded-3xl bg-white border border-border shadow-xl p-6 sm:p-10 overflow-hidden">
            <div class="pointer-events-none absolute -top-24 -right-24 h-64 w-64 rounded-full bg-accent/20 blur-3xl"></div>
            <div class="pointer-events-none absolute -bottom-24 -left-24 h-64 w-64 rounded-full bg-primary/20 blur-3xl"></div>
            <div class="relative mx-auto">
                <div class="relative h-64 w-64 sm:h-72 sm:w-72 rounded-3xl bg-gradient-to-br from-primary to-[#2F65B8] p-1.5 shadow-2xl">
                    <div class="h-full w-full rounded-[1.35rem] overflow-hidden bg-primary/10 flex items-center justify-center">
                        <img alt="<?php echo esc_attr(npd_c('dir_name')); ?>" class="h-full w-full object-cover" src="<?php echo esc_url($npd_dir_photo); ?>" loading="lazy" width="500" height="500">
                    </div>
                </div>
            </div>
            <div class="relative">
                <?php echo npd_icon('quote', 40, 'text-accent/30 mb-2'); // phpcs:ignore WordPress.Security.EscapeOutput ?>
                <h3 class="text-2xl font-extrabold text-foreground"><?php echo esc_html(npd_c('dir_name')); ?></h3>
                <p class="text-sm font-semibold text-accent uppercase tracking-wide mt-1"><?php echo esc_html(npd_c('dir_role')); ?></p>
                <p class="mt-4 text-base text-muted-foreground leading-relaxed"><?php echo esc_html(npd_c('dir_text')); ?></p>
                <ul class="mt-5 space-y-2">
                    <?php foreach (npd_lines('dir_points') as $point) : ?>
                        <li class="flex items-center gap-2 text-sm font-medium text-foreground/80"><?php echo npd_icon('circle-check', 16, 'text-accent flex-shrink-0'); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo esc_html($point); ?></li>
                    <?php endforeach; ?>
                </ul>
                <?php if ($npd_wa_url) : ?>
                    <a href="<?php echo esc_url($npd_wa_url); ?>" target="_blank" rel="noopener noreferrer" class="mt-6 inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-bold text-white shadow-md hover:bg-primary/90 hover:-translate-y-0.5 transition-all"><?php echo npd_icon('message-circle', 18); // phpcs:ignore WordPress.Security.EscapeOutput ?> <?php echo esc_html(npd_c('dir_cta')); ?></a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<section id="servizi" class="py-24 relative z-10 bg-gradient-to-br from-[#0a1d3a] via-[#081a32] to-[#061428]">
    <div class="container mx-auto px-4">
        <div class="text-center max-w-2xl mx-auto mb-16">
            <h2 class="text-4xl font-bold text-white mb-4"><?php echo esc_html(npd_c('srv_title')); ?></h2>
            <p class="text-lg text-white/70"><?php echo esc_html(npd_c('srv_subtitle')); ?></p>
        </div>
        <div class="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-6">
            <?php foreach ($npd_services as $s) :
                $img = $s['image'] !== '' ? $s['image'] : NPD_URI . '/assets/img/services/' . $s['id'] . '.webp'; ?>
                <div class="group relative rounded-2xl sm:rounded-3xl overflow-hidden cursor-pointer h-full aspect-[4/5] shadow-[0_8px_30px_rgb(0,0,0,0.18)] ring-1 ring-white/10 hover:ring-accent transition-all duration-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 focus-visible:ring-offset-[#081a32]" role="button" tabindex="0" data-npd-service="<?php echo esc_attr($s['id']); ?>" aria-label="<?php echo esc_attr(sprintf(__('Scopri di più su %s', 'new-polo-design-child-theme'), $s['name'])); ?>">
                    <img alt="<?php echo esc_attr($s['name']); ?>" loading="lazy" class="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" src="<?php echo esc_url($img); ?>" width="960" height="672">
                    <div class="absolute inset-0 bg-gradient-to-t from-black/85 via-black/35 to-black/10"></div>
                    <div class="absolute top-2 left-2 sm:top-3 sm:left-3 w-9 h-9 sm:w-11 sm:h-11 rounded-lg sm:rounded-xl bg-white/90 backdrop-blur text-primary flex items-center justify-center shadow-sm group-hover:bg-accent group-hover:text-white transition-colors duration-300 z-10">
                        <?php echo npd_icon($s['icon'], 18, 'sm:hidden', 1.75); // phpcs:ignore WordPress.Security.EscapeOutput ?>
                        <?php echo npd_icon($s['icon'], 22, 'hidden sm:block', 1.75); // phpcs:ignore WordPress.Security.EscapeOutput ?>
                    </div>
                    <div class="absolute inset-x-0 bottom-0 p-3 sm:p-5 z-10">
                        <h3 class="text-base sm:text-xl font-bold mb-1 sm:mb-1.5 text-white leading-tight"><?php echo esc_html($s['name']); ?></h3>
                        <p class="text-white/80 text-xs sm:text-sm leading-relaxed line-clamp-2"><?php echo esc_html($s['desc']); ?></p>
                        <div class="mt-2 sm:mt-3 flex items-center text-xs sm:text-sm font-semibold text-white group-hover:text-accent transition-colors"><?php echo esc_html(npd_c('srv_more')); ?>
                            <?php echo npd_icon('arrow-right', 14, 'ml-1.5 sm:ml-2 sm:hidden group-hover:translate-x-1 transition-transform'); // phpcs:ignore WordPress.Security.EscapeOutput ?>
                            <?php echo npd_icon('arrow-right', 16, 'ml-2 hidden sm:inline group-hover:translate-x-1 transition-transform'); // phpcs:ignore WordPress.Security.EscapeOutput ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<div id="portfolio" class="scroll-mt-24" aria-hidden="true"></div>

<section id="metodo" class="py-24 bg-primary text-primary-foreground">
    <div class="container mx-auto px-4">
        <div class="text-center max-w-2xl mx-auto mb-16">
            <h2 class="text-4xl font-bold mb-4"><?php echo esc_html(npd_c('met_title')); ?></h2>
            <p class="text-lg text-primary-foreground/80"><?php echo esc_html(npd_c('met_subtitle')); ?></p>
        </div>
        <div class="max-w-5xl mx-auto">
            <div class="flex flex-col md:flex-row gap-8 relative">
                <div class="hidden md:block absolute top-[40px] left-0 w-full h-[2px] bg-primary-foreground/20 z-0"></div>
                <?php for ($i = 1; $i <= 5; $i++) :
                    if (npd_c('met_' . $i . '_t') === '') {
                        continue;
                    } ?>
                    <div class="flex-1 relative z-10 flex flex-row md:flex-col items-start md:items-center gap-6 md:gap-4 md:text-center">
                        <div class="w-20 h-20 md:w-16 md:h-16 shrink-0 rounded-full bg-accent text-accent-foreground font-bold text-2xl md:text-xl flex items-center justify-center shadow-lg shadow-accent/20 border-4 border-primary"><?php echo esc_html(str_pad((string) $i, 2, '0', STR_PAD_LEFT)); ?></div>
                        <div>
                            <h3 class="text-xl md:text-lg font-bold mb-2"><?php echo esc_html(npd_c('met_' . $i . '_t')); ?></h3>
                            <p class="text-primary-foreground/70 text-sm"><?php echo esc_html(npd_c('met_' . $i . '_d')); ?></p>
                        </div>
                    </div>
                <?php endfor; ?>
            </div>
        </div>
    </div>
</section>

<?php if ($npd_reviews) : ?>
<section id="recensioni" class="py-20 sm:py-24 bg-muted/40 relative z-10">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 text-center">
        <span class="inline-block text-xs font-bold tracking-widest uppercase text-accent mb-3"><?php echo esc_html(npd_c('rev_badge')); ?></span>
        <h2 class="text-2xl sm:text-4xl font-extrabold text-foreground"><?php echo esc_html(npd_c('rev_title')); ?></h2>
        <p class="mt-3 text-muted-foreground"><?php echo esc_html(npd_c('rev_subtitle')); ?></p>
        <div class="relative mt-10" data-npd-carousel>
            <div class="min-h-[260px] sm:min-h-[220px] flex items-stretch">
                <?php foreach ($npd_reviews as $i => $r) : ?>
                    <figure class="w-full rounded-2xl bg-white border border-border shadow-lg p-6 sm:p-8 flex flex-col items-center npd-slide" data-npd-slide <?php echo $i ? 'hidden' : ''; ?>>
                        <div class="flex gap-0.5" role="img" aria-label="<?php esc_attr_e('5 stelle su 5', 'new-polo-design-child-theme'); ?>">
                            <?php for ($k = 0; $k < 5; $k++) { echo '<span>' . npd_icon('star', 18, 'fill-accent text-accent') . '</span>'; } // phpcs:ignore WordPress.Security.EscapeOutput ?>
                        </div>
                        <blockquote class="mt-5 text-base sm:text-lg text-foreground/90 leading-relaxed italic">“<?php echo esc_html($r['text']); ?>”</blockquote>
                        <figcaption class="mt-6 flex items-center gap-3">
                            <div class="h-11 w-11 rounded-full bg-primary text-white flex items-center justify-center font-bold"><?php echo esc_html(mb_strtoupper(mb_substr($r['name'], 0, 1))); ?></div>
                            <div class="text-left">
                                <div class="flex items-center gap-1.5 font-bold text-foreground"><?php echo esc_html($r['name']); ?><?php echo npd_icon('badge-check', 16, 'text-primary'); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
                                <?php if ($r['role'] !== '') : ?><div class="text-xs text-muted-foreground"><?php echo esc_html($r['role']); ?></div><?php endif; ?>
                            </div>
                        </figcaption>
                        <span class="mt-4 inline-flex items-center gap-1 rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary"><?php echo npd_icon('badge-check', 12); // phpcs:ignore WordPress.Security.EscapeOutput ?> <?php echo esc_html(npd_c('rev_verified')); ?></span>
                    </figure>
                <?php endforeach; ?>
            </div>
            <?php if (count($npd_reviews) > 1) : ?>
            <div class="mt-6 flex items-center justify-center gap-4">
                <button type="button" data-npd-prev aria-label="<?php esc_attr_e('Precedente', 'new-polo-design-child-theme'); ?>" class="h-10 w-10 rounded-full border border-border bg-white flex items-center justify-center text-foreground/70 hover:text-primary hover:border-primary transition-colors"><?php echo npd_icon('chevron-left', 18); // phpcs:ignore WordPress.Security.EscapeOutput ?></button>
                <div class="flex gap-2">
                    <?php foreach ($npd_reviews as $i => $r) : ?>
                        <button type="button" data-npd-dot="<?php echo (int) $i; ?>" aria-label="<?php echo esc_attr(sprintf(__('Recensione %d', 'new-polo-design-child-theme'), $i + 1)); ?>" class="h-2 rounded-full transition-all <?php echo $i ? 'w-2 bg-border' : 'w-6 bg-primary'; ?>"></button>
                    <?php endforeach; ?>
                </div>
                <button type="button" data-npd-next aria-label="<?php esc_attr_e('Successivo', 'new-polo-design-child-theme'); ?>" class="h-10 w-10 rounded-full border border-border bg-white flex items-center justify-center text-foreground/70 hover:text-primary hover:border-primary transition-colors"><?php echo npd_icon('chevron-right', 18); // phpcs:ignore WordPress.Security.EscapeOutput ?></button>
            </div>
            <?php endif; ?>
        </div>
        <div class="mt-10">
            <button type="button" data-npd-open="review" class="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-bold text-white shadow-md hover:bg-primary/90 hover:-translate-y-0.5 transition-all"><?php echo npd_icon('message-square-plus', 18); // phpcs:ignore WordPress.Security.EscapeOutput ?> <?php echo esc_html(npd_c('rev_cta')); ?></button>
        </div>
    </div>
</section>
<?php endif; ?>

<?php if ($npd_faq && !empty($npd_faq['items'])) : ?>
<section id="faq" class="py-20 sm:py-24 bg-white relative z-10">
    <div class="max-w-3xl mx-auto px-4 sm:px-6">
        <div class="text-center">
            <span class="inline-block text-xs font-bold tracking-widest uppercase text-accent mb-3"><?php echo esc_html(npd_c('faq_badge')); ?></span>
            <h2 class="text-2xl sm:text-4xl font-extrabold text-foreground"><?php echo esc_html(npd_c('faq_title')); ?></h2>
            <p class="mt-3 text-muted-foreground"><?php echo esc_html(npd_c('faq_subtitle')); ?></p>
        </div>
        <div class="mt-10">
            <div class="w-full space-y-3" data-npd-faq>
                <?php foreach ($npd_faq['items'] as $i => $item) : $pid = 'npd-faq-' . $i; ?>
                    <div class="rounded-xl border border-border bg-white px-4 shadow-sm transition-all npd-faq-item">
                        <h3 class="flex">
                            <button type="button" aria-controls="<?php echo esc_attr($pid); ?>" aria-expanded="false" class="flex flex-1 items-center justify-between py-4 transition-all text-left text-base font-semibold text-foreground hover:no-underline npd-faq-btn"><?php echo esc_html($item['question']); ?><?php echo npd_icon('chevron-down', 16, 'shrink-0 transition-transform duration-200'); // phpcs:ignore WordPress.Security.EscapeOutput ?></button>
                        </h3>
                        <div id="<?php echo esc_attr($pid); ?>" role="region" hidden class="overflow-hidden text-sm">
                            <div class="pb-4 pt-0 text-muted-foreground leading-relaxed"><?php echo wp_kses_post($item['answer']); ?></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<section id="sede" class="py-20 sm:py-24 bg-white relative z-10">
    <div class="max-w-6xl mx-auto px-4 sm:px-6">
        <div class="text-center mb-12">
            <span class="inline-block text-xs font-bold tracking-widest uppercase text-accent mb-3"><?php echo esc_html(npd_c('sede_badge')); ?></span>
            <h2 class="text-2xl sm:text-4xl font-extrabold text-foreground"><?php echo esc_html(npd_c('sede_title')); ?></h2>
            <p class="mt-3 text-muted-foreground"><?php echo esc_html(npd_c('sede_text')); ?></p>
        </div>
        <div class="grid lg:grid-cols-2 gap-8 items-stretch">
            <?php if ($npd_addr) : ?>
            <div class="rounded-2xl overflow-hidden border border-border shadow-lg min-h-[320px]">
                <iframe title="<?php esc_attr_e('Mappa della sede', 'new-polo-design-child-theme'); ?>" src="<?php echo esc_url('https://www.google.com/maps?q=' . rawurlencode($npd_addr) . '&output=embed'); ?>" class="w-full h-full min-h-[320px]" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe>
            </div>
            <?php endif; ?>
            <div class="flex flex-col gap-6">
                <?php if ($npd_addr || $npd_phone) : ?>
                <div class="rounded-2xl border border-border bg-muted/30 p-6">
                    <div class="flex items-start gap-3">
                        <span class="h-10 w-10 flex-shrink-0 rounded-full bg-primary/10 text-primary flex items-center justify-center"><?php echo npd_icon('map-pin', 20); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
                        <div>
                            <h3 class="text-sm font-bold uppercase tracking-wide text-foreground/70"><?php esc_html_e('Indirizzo', 'new-polo-design-child-theme'); ?></h3>
                            <p class="mt-1 text-foreground font-medium"><?php echo esc_html($npd_addr); ?></p>
                            <?php if ($npd_phone) : ?><p class="mt-1 text-sm text-muted-foreground"><?php echo esc_html($npd_phone); ?></p><?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <?php if ($npd_hours) : ?>
                <div class="rounded-2xl border border-border bg-muted/30 p-6">
                    <div class="flex items-start gap-3">
                        <span class="h-10 w-10 flex-shrink-0 rounded-full bg-accent/10 text-accent flex items-center justify-center"><?php echo npd_icon('clock', 20); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
                        <div class="flex-1">
                            <h3 class="text-sm font-bold uppercase tracking-wide text-foreground/70 mb-2"><?php esc_html_e('Orari di apertura', 'new-polo-design-child-theme'); ?></h3>
                            <ul class="space-y-1.5">
                                <?php foreach ($npd_hours as $row) : ?>
                                    <li class="flex items-center justify-between gap-4 text-sm"><span class="text-foreground/80 font-medium"><?php echo esc_html($row['label']); ?></span><span class="text-muted-foreground text-right"><?php echo esc_html($row['text']); ?></span></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <?php $npd_card = 'flex flex-col items-center justify-center gap-1.5 rounded-xl border border-border bg-white px-3 py-4 text-sm font-semibold text-foreground/80 shadow-sm hover:border-primary hover:text-primary hover:-translate-y-0.5 transition-all'; ?>
                <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <?php if ($npd_addr) : ?><a href="<?php echo esc_url('https://www.google.com/maps/dir/?api=1&destination=' . rawurlencode($npd_addr)); ?>" target="_blank" rel="noopener noreferrer" class="<?php echo esc_attr($npd_card); ?>"><?php echo npd_icon('navigation', 20); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e('Naviga', 'new-polo-design-child-theme'); ?></a><?php endif; ?>
                    <?php if ($npd_phone) : ?><a href="tel:<?php echo esc_attr(npd_phone_href()); ?>" class="<?php echo esc_attr($npd_card); ?>"><?php echo npd_icon('phone', 20); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e('Chiama', 'new-polo-design-child-theme'); ?></a><?php endif; ?>
                    <?php if (npd_whatsapp_number()) : ?><a href="<?php echo esc_url(npd_whatsapp_url(npd_c('wa_appointment'))); ?>" target="_blank" rel="noopener noreferrer" class="<?php echo esc_attr($npd_card); ?>"><?php echo npd_icon('message-circle', 20); // phpcs:ignore WordPress.Security.EscapeOutput ?>WhatsApp</a><?php endif; ?>
                    <?php if ($npd_email) : ?><a href="<?php echo esc_url('mailto:' . $npd_email . '?subject=' . rawurlencode(__('Preventivo', 'new-polo-design-child-theme')) . '&body=' . rawurlencode(npd_c('wa_appointment'))); ?>" class="<?php echo esc_attr($npd_card); ?>"><?php echo npd_icon('mail', 20); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e('Email', 'new-polo-design-child-theme'); ?></a><?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="py-32 bg-white relative overflow-hidden">
    <div class="absolute inset-0 bg-gradient-to-br from-accent/5 to-primary/5"></div>
    <div class="container mx-auto px-4 relative z-10 text-center max-w-3xl">
        <h2 class="text-4xl md:text-5xl font-bold text-foreground mb-6"><?php echo esc_html(npd_c('cta_title')); ?></h2>
        <p class="text-xl text-muted-foreground mb-12"><?php echo esc_html(npd_c('cta_text')); ?></p>
        <div class="flex flex-col sm:flex-row items-center justify-center gap-4">
            <?php if ($npd_wa_url) : ?><a href="<?php echo esc_url($npd_wa_url); ?>" target="_blank" rel="noopener noreferrer" class="<?php echo esc_attr($npd_btn); ?> border border-primary-border min-h-10 w-full sm:w-auto h-14 px-8 text-lg bg-[#25D366] hover:bg-[#20bd5a] text-white rounded-full shadow-lg hover:-translate-y-1 transition-all"><?php echo npd_icon('message-circle', 24, 'mr-2'); // phpcs:ignore WordPress.Security.EscapeOutput ?> WhatsApp</a><?php endif; ?>
            <button type="button" data-npd-open="quote" class="<?php echo esc_attr($npd_btn); ?> border border-primary-border min-h-10 w-full sm:w-auto h-14 px-8 text-lg bg-accent hover:bg-accent/90 text-accent-foreground rounded-full shadow-lg hover:-translate-y-1 transition-all"><?php esc_html_e('Richiedi Preventivo', 'new-polo-design-child-theme'); ?></button>
            <?php if ($npd_email) : ?><a href="<?php echo esc_url('mailto:' . $npd_email); ?>" class="<?php echo esc_attr($npd_btn); ?> shadow-xs active:shadow-none min-h-10 w-full sm:w-auto h-14 px-8 text-lg rounded-full border-2 border-border hover:bg-muted transition-all"><?php echo npd_icon('mail', 24, 'mr-2'); // phpcs:ignore WordPress.Security.EscapeOutput ?> <?php esc_html_e('Email', 'new-polo-design-child-theme'); ?></a><?php endif; ?>
        </div>
    </div>
</section>

</main>

<?php get_template_part('template-parts/service-details', null, array('services' => $npd_services)); ?>
<?php
get_footer();
