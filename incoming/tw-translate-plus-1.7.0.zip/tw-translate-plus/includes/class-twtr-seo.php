<?php
/**
 * SEO layer: hreflang alternates, x-default, robots gating for not-yet-ready
 * translations, and a core-sitemaps provider exposing the translated URLs.
 *
 * Canonical URLs, document titles, meta descriptions and og:* need no extra
 * markup here: they are built from permalinks (already language-prefixed by
 * the home_url filter) and translated through the content/theme adapters,
 * so nothing is duplicated against the tW SEO module or WordPress core.
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Seo {

    /** @var array<string,bool> Request-level readiness cache: "id|lang" => bool. */
    private static $ready = array();

    /**
     * Register frontend SEO hooks.
     */
    public static function init() {
        add_action('wp_head', array(__CLASS__, 'hreflang'), 2);
        add_filter('wp_robots', array(__CLASS__, 'robots'), 20);
        add_action('init', array(__CLASS__, 'register_sitemap_provider'), 20);
    }

    /**
     * Output reciprocal hreflang links on the front page and singular views.
     * A translated alternate is listed only when its essential content is
     * ready; x-default always points to the default language.
     */
    public static function hreflang() {
        $published = Twtr_Settings::extra_languages(true);
        if (!$published || (!is_singular() && !is_front_page())) {
            return;
        }
        $default   = Twtr_Settings::default_lang();
        $canonical = self::unprefixed_current_url();
        if ($canonical === '') {
            return;
        }

        $post_id = is_singular() ? (int) get_queried_object_id() : 0;
        $links   = array($default => $canonical);
        foreach ($published as $lang) {
            if ($post_id && !self::is_ready($post_id, $lang)) {
                continue;
            }
            $links[$lang] = Twtr_Router::language_url($lang, $canonical);
        }
        if (count($links) < 2) {
            return;
        }
        foreach ($links as $lang => $url) {
            printf(
                '<link rel="alternate" hreflang="%s" href="%s" />' . "\n",
                esc_attr(str_replace('_', '-', Twtr_Settings::wp_locale($lang))),
                esc_url($url)
            );
        }
        printf('<link rel="alternate" hreflang="x-default" href="%s" />' . "\n", esc_url($canonical));
    }

    /**
     * wp_robots filter: noindex translated pages whose essential content is
     * not ready yet, and every page of an unpublished (suspended) language.
     *
     * @param array $robots
     * @return array
     */
    public static function robots($robots) {
        $lang = Twtr_Router::current_language();
        if ($lang === '') {
            return $robots;
        }
        $published = Twtr_Settings::extra_languages(true);
        $noindex   = !in_array($lang, $published, true);

        if (!$noindex && is_singular()) {
            $noindex = !self::is_ready((int) get_queried_object_id(), $lang);
        }
        if ($noindex) {
            $robots['noindex'] = true;
            $robots['follow']  = true;
            unset($robots['max-image-preview']);
        }
        return $robots;
    }

    /**
     * A post is "ready" in a language when its title is translated and no
     * unlocked entry of the post is still pending or failed.
     *
     * @param int    $post_id
     * @param string $lang
     * @return bool
     */
    public static function is_ready($post_id, $lang) {
        $key = $post_id . '|' . $lang;
        if (isset(self::$ready[$key])) {
            return self::$ready[$key];
        }
        global $wpdb;
        $table = Twtr_Storage::entries_table();
        $row   = $wpdb->get_row($wpdb->prepare(
            "SELECT
                SUM(CASE WHEN context_key = %s AND status = 'ready' THEN 1 ELSE 0 END) AS title_ready,
                SUM(CASE WHEN status IN ('pending','error') AND locked = 0 THEN 1 ELSE 0 END) AS unresolved
             FROM {$table}
             WHERE blog_id = %d AND target_locale = %s AND context_key LIKE %s",
            'post:' . $post_id . ':title',
            get_current_blog_id(),
            $lang,
            $wpdb->esc_like('post:' . $post_id . ':') . '%'
        ));
        $ready = $row && (int) $row->title_ready > 0 && (int) $row->unresolved === 0;
        self::$ready[$key] = $ready;
        return $ready;
    }

    /**
     * Register the translated-URLs provider with core sitemaps.
     */
    public static function register_sitemap_provider() {
        if (!function_exists('wp_register_sitemap_provider') || !Twtr_Settings::extra_languages(true)) {
            return;
        }
        require_once TWTR_DIR . 'includes/class-twtr-sitemap-provider.php';
        wp_register_sitemap_provider('twtr', new Twtr_Sitemap_Provider());
    }

    /**
     * Current URL without any language prefix (the default-language URL).
     *
     * @return string
     */
    private static function unprefixed_current_url() {
        if (is_singular()) {
            $url = get_permalink(get_queried_object_id());
            // Strip the prefix the home_url filter may have added.
            return $url ? Twtr_Router::language_url(Twtr_Settings::default_lang(), $url) : '';
        }
        return Twtr_Router::language_url(Twtr_Settings::default_lang(), null);
    }
}
