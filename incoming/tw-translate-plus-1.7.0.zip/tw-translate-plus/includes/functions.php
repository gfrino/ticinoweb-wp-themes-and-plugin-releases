<?php
/**
 * Public API for child themes and integrations.
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Languages available on this site, ready for building a language switcher.
 *
 * @param bool $published_only Include only languages published to visitors (default true).
 * @return array<string,array{slug:string,label:string,locale:string,is_default:bool,is_current:bool,url:string}>
 */
function twtr_get_languages($published_only = true) {
    $catalog = Twtr_Settings::catalog();
    $default = Twtr_Settings::default_lang();
    $current = twtr_get_current_language();
    $slugs   = array_merge(array($default), Twtr_Settings::extra_languages($published_only));

    $out = array();
    foreach ($slugs as $slug) {
        $out[$slug] = array(
            'slug'       => $slug,
            'label'      => isset($catalog[$slug]) ? $catalog[$slug]['label'] : $slug,
            'locale'     => Twtr_Settings::wp_locale($slug),
            'flag'       => Twtr_Settings::flag($slug),
            'is_default' => $slug === $default,
            'is_current' => $slug === $current,
            'url'        => twtr_get_language_url($slug),
        );
    }
    return $out;
}

/**
 * Current language slug. Returns the default language slug on unprefixed URLs.
 *
 * @return string
 */
function twtr_get_current_language() {
    $lang = Twtr_Router::current_language();
    return $lang !== '' ? $lang : Twtr_Settings::default_lang();
}

/**
 * URL of the given (or current) page in another language.
 *
 * @param string      $lang Language slug.
 * @param string|null $url  Absolute internal URL, null = current request.
 * @return string
 */
function twtr_get_language_url($lang, $url = null) {
    return Twtr_Router::language_url((string) $lang, $url);
}

/**
 * Translate a string through the resolver (manual → automatica → originale).
 * Escaping remains the caller's responsibility.
 *
 * @param string      $text    Original text.
 * @param string      $context Stable context key (see theme translation-compat conventions).
 * @param string|null $lang    Language slug, null = current.
 * @return string
 */
function twtr_translate($text, $context, $lang = null) {
    return Twtr_Resolver::translate($text, $context, $lang);
}
