<?php
/**
 * Google Cloud Translation Advanced (v3) client.
 *
 * Pure REST via wp_remote_*: no SDK dependency. Authenticates with a
 * service-account JSON key (RS256 JWT → OAuth2 token). Never called during a
 * normal frontend visit — only from the background queue, WP-CLI or explicit
 * admin actions.
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Google {

    const TOKEN_TRANSIENT = 'twtr_google_token';
    const TIMEOUT = 20;

    /** @var Twtr_Google|null */
    private static $instance = null;

    /** @var array<int,array> Decoded service-account key, per blog id. */
    private $key = array();

    /** @var string|null */
    private $last_error = null;

    /**
     * @return Twtr_Google
     */
    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * @return string|null Last human-readable error (no secrets, no content).
     */
    public function last_error() {
        return $this->last_error;
    }

    /**
     * Translate a batch of HTML strings.
     *
     * @param string[] $texts       Source strings (HTML allowed).
     * @param string   $source_lang Language slug of the source.
     * @param string   $target_lang Language slug of the target.
     * @return string[]|WP_Error Translations in the same order.
     */
    public function translate_batch($texts, $source_lang, $target_lang) {
        $cfg = Twtr_Settings::google_config();
        if ($cfg['project_id'] === '') {
            return new WP_Error('twtr_config', __('Project ID Google non configurato.', 'tw-translate-plus'));
        }
        $body = array(
            'contents'           => array_values($texts),
            'mimeType'           => 'text/html',
            'sourceLanguageCode' => Twtr_Settings::google_code($source_lang),
            'targetLanguageCode' => Twtr_Settings::google_code($target_lang),
        );

        $glossary_id = $this->ready_glossary_id($source_lang, $target_lang);
        if ($glossary_id) {
            $body['glossaryConfig'] = array(
                'glossary'   => sprintf('projects/%s/locations/%s/glossaries/%s', $cfg['project_id'], $cfg['location'], $glossary_id),
                'ignoreCase' => true,
            );
        }

        $url  = sprintf('https://translation.googleapis.com/v3/projects/%s/locations/%s:translateText', $cfg['project_id'], $cfg['location']);
        $resp = $this->request('POST', $url, $body, true);
        if (is_wp_error($resp)) {
            return $resp;
        }

        // When a glossary is applied Google returns both plain and glossary
        // translations; glossaryTranslations take precedence.
        $list = array();
        $plain = isset($resp['translations']) ? $resp['translations'] : array();
        $gloss = isset($resp['glossaryTranslations']) ? $resp['glossaryTranslations'] : array();
        $count = count($texts);
        for ($i = 0; $i < $count; $i++) {
            if (isset($gloss[$i]['translatedText']) && $gloss[$i]['translatedText'] !== '') {
                $list[$i] = $gloss[$i]['translatedText'];
            } elseif (isset($plain[$i]['translatedText'])) {
                $list[$i] = $plain[$i]['translatedText'];
            } else {
                return new WP_Error('twtr_response', __('Risposta Google incompleta.', 'tw-translate-plus'));
            }
        }
        return $list;
    }

    /**
     * Lightweight connectivity/permission test.
     *
     * @return true|WP_Error
     */
    public function test_connection() {
        $result = $this->translate_batch(array('Buongiorno'), 'it', 'en');
        if (is_wp_error($result)) {
            return $result;
        }
        return true;
    }

    /**
     * Glossary id for a language pair when its sync state is ready.
     *
     * @param string $source_lang
     * @param string $target_lang
     * @return string Empty when not available.
     */
    public function ready_glossary_id($source_lang, $target_lang) {
        $state = (array) Twtr_Settings::engine()['glossary_state'];
        $pair  = $source_lang . '-' . $target_lang;
        if (isset($state[$pair]['status']) && $state[$pair]['status'] === 'ready') {
            return self::glossary_resource_id($source_lang, $target_lang);
        }
        return '';
    }

    /**
     * @return string Stable glossary resource id for a pair.
     */
    public static function glossary_resource_id($source_lang, $target_lang) {
        return 'twtr-' . $source_lang . '-' . $target_lang;
    }

    /**
     * Upload a small object to the configured GCS bucket.
     *
     * @param string $object_name e.g. twtr/glossary-it-en.csv
     * @param string $content     File content.
     * @return string|WP_Error gs:// URI on success.
     */
    public function gcs_upload($object_name, $content) {
        $cfg = Twtr_Settings::google_config();
        if ($cfg['gcs_bucket'] === '') {
            return new WP_Error('twtr_config', __('Bucket GCS non configurato: necessario per il glossario.', 'tw-translate-plus'));
        }
        $url  = sprintf(
            'https://storage.googleapis.com/upload/storage/v1/b/%s/o?uploadType=media&name=%s',
            rawurlencode($cfg['gcs_bucket']),
            rawurlencode($object_name)
        );
        $resp = $this->request('POST', $url, $content, false, 'text/csv');

        // Bucket missing: try to create it once, then retry the upload.
        if (is_wp_error($resp) && $resp->get_error_code() === 'twtr_http_404') {
            $created = $this->create_bucket($cfg['gcs_bucket']);
            if (is_wp_error($created)) {
                return new WP_Error('twtr_bucket', sprintf(
                    __('Il bucket "%1$s" non esiste e la creazione automatica è fallita (%2$s). Crealo manualmente su Cloud Storage nello stesso progetto, oppure concedi al service account il ruolo "Storage Admin".', 'tw-translate-plus'),
                    $cfg['gcs_bucket'],
                    $created->get_error_message()
                ));
            }
            $resp = $this->request('POST', $url, $content, false, 'text/csv');
        }
        if (is_wp_error($resp)) {
            return $resp;
        }
        return 'gs://' . $cfg['gcs_bucket'] . '/' . $object_name;
    }

    /**
     * Create the configured GCS bucket in the project (regional, matching
     * the Translation location when possible).
     *
     * @param string $bucket
     * @return true|WP_Error
     */
    public function create_bucket($bucket) {
        $cfg  = Twtr_Settings::google_config();
        $body = array(
            'name'         => $bucket,
            'location'     => strtoupper($cfg['location'] ?: 'US'),
            'storageClass' => 'STANDARD',
        );
        $url  = 'https://storage.googleapis.com/storage/v1/b?project=' . rawurlencode($cfg['project_id']);
        $resp = $this->request('POST', $url, $body, true);
        if (is_wp_error($resp)) {
            return $resp;
        }
        return true;
    }

    /**
     * Delete a glossary resource (idempotent: 404 is treated as success).
     *
     * @param string $glossary_id
     * @return true|WP_Error
     */
    public function delete_glossary($glossary_id) {
        $cfg  = Twtr_Settings::google_config();
        $url  = sprintf('https://translation.googleapis.com/v3/projects/%s/locations/%s/glossaries/%s', $cfg['project_id'], $cfg['location'], $glossary_id);
        $resp = $this->request('DELETE', $url, null, true, null, array(404));
        if (is_wp_error($resp)) {
            return $resp;
        }
        return true;
    }

    /**
     * Create a unidirectional glossary from a CSV already uploaded to GCS.
     *
     * @param string $glossary_id
     * @param string $source_lang
     * @param string $target_lang
     * @param string $gcs_uri
     * @return string|WP_Error Operation name.
     */
    public function create_glossary($glossary_id, $source_lang, $target_lang, $gcs_uri) {
        $cfg  = Twtr_Settings::google_config();
        $body = array(
            'name'         => sprintf('projects/%s/locations/%s/glossaries/%s', $cfg['project_id'], $cfg['location'], $glossary_id),
            'languagePair' => array(
                'sourceLanguageCode' => Twtr_Settings::google_code($source_lang),
                'targetLanguageCode' => Twtr_Settings::google_code($target_lang),
            ),
            'inputConfig'  => array('gcsSource' => array('inputUri' => $gcs_uri)),
        );
        $url  = sprintf('https://translation.googleapis.com/v3/projects/%s/locations/%s/glossaries', $cfg['project_id'], $cfg['location']);
        $resp = $this->request('POST', $url, $body, true);
        if (is_wp_error($resp)) {
            return $resp;
        }
        return isset($resp['name']) ? $resp['name'] : '';
    }

    /**
     * Check a long-running operation.
     *
     * @param string $operation_name
     * @return array|WP_Error ['done' => bool, 'error' => string]
     */
    public function get_operation($operation_name) {
        $resp = $this->request('GET', 'https://translation.googleapis.com/v3/' . $operation_name, null, true);
        if (is_wp_error($resp)) {
            return $resp;
        }
        return array(
            'done'  => !empty($resp['done']),
            'error' => isset($resp['error']['message']) ? (string) $resp['error']['message'] : '',
        );
    }

    /**
     * Authenticated request with limited retry (backoff on 429/5xx/network).
     *
     * @param string      $method
     * @param string      $url
     * @param mixed       $body         Array (JSON) or raw string.
     * @param bool        $json         Whether body is JSON.
     * @param string|null $content_type Override content type for raw bodies.
     * @param int[]       $ok_errors    HTTP codes to treat as success with empty body.
     * @return array|WP_Error Decoded JSON response.
     */
    private function request($method, $url, $body, $json = true, $content_type = null, $ok_errors = array()) {
        $token = $this->access_token();
        if (is_wp_error($token)) {
            return $token;
        }

        $args = array(
            'method'  => $method,
            'timeout' => self::TIMEOUT,
            'headers' => array('Authorization' => 'Bearer ' . $token),
        );
        if ($body !== null) {
            if ($json && is_array($body)) {
                $args['headers']['Content-Type'] = 'application/json; charset=utf-8';
                $args['body'] = wp_json_encode($body);
            } else {
                $args['headers']['Content-Type'] = $content_type ? $content_type : 'application/octet-stream';
                $args['body'] = $body;
            }
        }

        $attempts = 0;
        do {
            if ($attempts > 0) {
                usleep((int) (500000 * pow(2, $attempts - 1))); // 0.5s, 1s backoff.
            }
            $attempts++;
            $resp = wp_remote_request($url, $args);
            $code = is_wp_error($resp) ? 0 : (int) wp_remote_retrieve_response_code($resp);
            $retryable = is_wp_error($resp) || $code === 429 || $code >= 500;
        } while ($retryable && $attempts < 3);

        if (is_wp_error($resp)) {
            $this->last_error = __('Errore di rete verso Google (timeout o DNS).', 'tw-translate-plus');
            return new WP_Error('twtr_network', $this->last_error);
        }
        if (in_array($code, $ok_errors, true)) {
            return array();
        }
        $decoded = json_decode(wp_remote_retrieve_body($resp), true);
        if ($code >= 200 && $code < 300) {
            $this->last_error = null;
            return is_array($decoded) ? $decoded : array();
        }

        $this->last_error = self::friendly_error($code, $decoded);
        return new WP_Error('twtr_http_' . $code, $this->last_error);
    }

    /**
     * Map API errors to actionable Italian messages, without echoing content.
     *
     * @param int        $code
     * @param array|null $decoded
     * @return string
     */
    public static function friendly_error($code, $decoded) {
        $api_msg = isset($decoded['error']['message']) ? (string) $decoded['error']['message'] : '';
        $api_msg = mb_substr($api_msg, 0, 200);
        switch ($code) {
            case 400:
                return sprintf(__('Richiesta non valida (verifica location e codici lingua): %s', 'tw-translate-plus'), $api_msg);
            case 401:
                return __('Credenziali non valide o scadute: verifica il file del service account.', 'tw-translate-plus');
            case 403:
                if (stripos($api_msg, 'has not been used') !== false || stripos($api_msg, 'disabled') !== false) {
                    return sprintf(__('La Cloud Translation API non è abilitata nel progetto: abilitala dalla console Google (link nella pagina Google API), attendi 1-2 minuti e riprova. Dettaglio: %s', 'tw-translate-plus'), $api_msg);
                }
                if (stripos($api_msg, 'billing') !== false) {
                    return sprintf(__('Fatturazione non attiva sul progetto Google Cloud: attivala per usare la Translation API. Dettaglio: %s', 'tw-translate-plus'), $api_msg);
                }
                return sprintf(__('Permessi IAM insufficienti: il service account deve avere i ruoli "Cloud Translation API Editor" e (per il glossario) "Storage Object Admin" sul bucket. Dettaglio: %s', 'tw-translate-plus'), $api_msg);
            case 404:
                return sprintf(__('Risorsa non trovata: verifica Project ID, location o nome bucket. Dettaglio: %s', 'tw-translate-plus'), $api_msg);
            case 429:
                return __('Quota Google esaurita o troppe richieste: la coda riproverà automaticamente.', 'tw-translate-plus');
            default:
                return sprintf(__('Errore Google (%d): %s', 'tw-translate-plus'), $code, $api_msg);
        }
    }

    /**
     * OAuth2 access token from the service-account key, cached ~50 minutes.
     *
     * @return string|WP_Error
     */
    private function access_token() {
        $cached = get_transient(self::TOKEN_TRANSIENT);
        if (is_string($cached) && $cached !== '') {
            return $cached;
        }

        $key = $this->load_key();
        if (is_wp_error($key)) {
            return $key;
        }

        $now    = time();
        $header = self::b64url(wp_json_encode(array('alg' => 'RS256', 'typ' => 'JWT')));
        $claims = self::b64url(wp_json_encode(array(
            'iss'   => $key['client_email'],
            'scope' => 'https://www.googleapis.com/auth/cloud-platform',
            'aud'   => $key['token_uri'],
            'iat'   => $now,
            'exp'   => $now + 3600,
        )));
        $signature = '';
        if (!openssl_sign($header . '.' . $claims, $signature, $key['private_key'], OPENSSL_ALGO_SHA256)) {
            return new WP_Error('twtr_sign', __('Impossibile firmare il JWT: chiave privata non valida.', 'tw-translate-plus'));
        }
        $jwt = $header . '.' . $claims . '.' . self::b64url($signature);

        $resp = wp_remote_post($key['token_uri'], array(
            'timeout' => self::TIMEOUT,
            'body'    => array(
                'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
                'assertion'  => $jwt,
            ),
        ));
        if (is_wp_error($resp)) {
            return new WP_Error('twtr_network', __('Errore di rete durante l\'autenticazione Google.', 'tw-translate-plus'));
        }
        $data = json_decode(wp_remote_retrieve_body($resp), true);
        if (empty($data['access_token'])) {
            return new WP_Error('twtr_auth', __('Autenticazione Google rifiutata: verifica il service account.', 'tw-translate-plus'));
        }
        // Per-site transient: every site authenticates with its own service account.
        set_transient(self::TOKEN_TRANSIENT, $data['access_token'], 50 * MINUTE_IN_SECONDS);
        return $data['access_token'];
    }

    /**
     * Load and validate the service-account JSON key.
     *
     * @return array|WP_Error
     */
    private function load_key() {
        $blog_id = get_current_blog_id();
        if (isset($this->key[$blog_id])) {
            return $this->key[$blog_id];
        }
        $path = Twtr_Settings::credentials_path();
        if ($path !== '') {
            if (!is_readable($path)) {
                return new WP_Error('twtr_config', __('Il file delle credenziali Google non esiste o non è leggibile dal server.', 'tw-translate-plus'));
            }
            $raw = (string) file_get_contents($path);
        } else {
            // Fallback: service-account JSON pasted in the admin UI.
            $raw = Twtr_Settings::credentials_json();
            if ($raw === '') {
                return new WP_Error('twtr_config', __('Credenziali Google non configurate per questo sito: incolla il JSON del service account in tW Translate ▸ API traduzione.', 'tw-translate-plus'));
            }
        }
        $data = json_decode($raw, true);
        if (empty($data['client_email']) || empty($data['private_key']) || empty($data['token_uri'])) {
            return new WP_Error('twtr_config', __('Le credenziali non sono un service account JSON valido.', 'tw-translate-plus'));
        }
        $this->key[$blog_id] = $data;
        return $data;
    }

    /**
     * @param string $data
     * @return string Base64url without padding.
     */
    private static function b64url($data) {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }
}
