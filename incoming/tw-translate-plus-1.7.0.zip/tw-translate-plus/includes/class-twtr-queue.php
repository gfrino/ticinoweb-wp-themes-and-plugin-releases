<?php
/**
 * Background translation queue.
 *
 * The entries table itself is the queue: rows with status=pending and
 * locked=0 are claimed atomically with a token, translated in small batches
 * and marked ready. Safe under concurrency (claim via single UPDATE),
 * recoverable (stuck claims are released after 10 minutes) and quota-aware.
 *
 * Processing runs via WP-Cron single events (works with a real server cron
 * hitting wp-cron.php), via WP-CLI, or inline from the admin "Processa ora"
 * action. It never runs during a normal frontend visit.
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Queue {

    const HOOK = 'twtr_process_queue';
    const MAX_ATTEMPTS = 3;
    const CLAIM_TIMEOUT_MIN = 10;
    const MAX_BATCH_CHARS = 24000;
    const MAX_BATCH_CHARS_LLM = 8000;

    /**
     * Character budget of a single request to the engine.
     *
     * Google answers one translation per input string and has no output
     * ceiling worth worrying about. An LLM re-emits the whole batch as
     * generated tokens instead, so a batch that is fine on input can still
     * hit the model's maximum output length and come back truncated — which
     * would fail the entire chunk. Hence the smaller budget for OpenAI.
     *
     * @return int
     */
    public static function max_batch_chars() {
        $chars = Twtr_Settings::provider() === 'openai' ? self::MAX_BATCH_CHARS_LLM : self::MAX_BATCH_CHARS;
        return max(500, (int) apply_filters('twtr_max_batch_chars', $chars, Twtr_Settings::provider()));
    }

    /**
     * Schedule a near-future processing run for this site (idempotent).
     */
    public static function schedule() {
        /*
         * IL FRENO CENTRALE. Ogni innesco automatico — l'estrattore quando un
         * post o un termine viene salvato, il resolver alla prima visita
         * frontend di una pagina in una lingua attiva, il ripristino di una
         * traduzione automatica o il rimettere in coda gli errori dal tab
         * Traduzioni — passa da qui prima di arrivare al cron. Un solo
         * controllo, in un solo posto, invece di quattro sparsi nel codice
         * che potrebbero disallinearsi nel tempo.
         *
         * "Processa ora" (Twtr_Queue::process(), chiamato direttamente da
         * ajax_process_now() e dal comando WP-CLI) non passa da qui: resta
         * sempre disponibile per tradurre su decisione esplicita, anche con
         * l'interruttore spento. Attivare una lingua non deve mai, da solo,
         * avviare una traduzione automatica non richiesta.
         */
        if (!Twtr_Settings::auto_translate()) {
            return;
        }
        // Senza la chiave del sito non c'e' nulla da elaborare: niente cron.
        if (!Twtr_Settings::engine_ready()) {
            return;
        }
        if (!wp_next_scheduled(self::HOOK)) {
            wp_schedule_single_event(time() + 30, self::HOOK);
        }
    }

    /**
     * Process one batch for the current site.
     *
     * @param int|null $batch_size Override the configured batch size.
     * @return array{processed:int,errors:int,remaining:int,message:string}
     */
    public static function process($batch_size = null) {
        global $wpdb;
        $table   = Twtr_Storage::entries_table();
        $blog_id = get_current_blog_id();
        $n       = Twtr_Settings::network();
        $size    = $batch_size ? (int) $batch_size : max(1, (int) $n['batch_size']);
        $default = Twtr_Settings::default_lang();
        $result  = array('processed' => 0, 'errors' => 0, 'remaining' => 0, 'message' => '');

        // Release claims stuck by fatals/timeouts.
        $wpdb->query($wpdb->prepare(
            "UPDATE {$table} SET claim_token = NULL WHERE blog_id = %d AND claim_token IS NOT NULL AND updated_at < (UTC_TIMESTAMP() - INTERVAL %d MINUTE)",
            $blog_id, self::CLAIM_TIMEOUT_MIN
        ));

        // No key of its own, no translation: there is no network fallback.
        // Entries stay pending and are processed once the site gets a key.
        if (!Twtr_Settings::engine_ready()) {
            $result['message']   = Twtr_Settings::engine_missing_reason();
            $result['remaining'] = self::remaining();
            return $result;
        }

        // Quota guard: the site's own limit against the site's own usage.
        $limit = Twtr_Settings::daily_char_limit();
        if ($limit > 0 && Twtr_Settings::usage_today() >= $limit) {
            $result['message']   = __('Limite giornaliero di caratteri raggiunto: la coda riprende domani.', 'tw-translate-plus');
            $result['remaining'] = self::remaining();
            self::reschedule_if_needed($result['remaining'], 6 * HOUR_IN_SECONDS);
            return $result;
        }

        // Keep Google glossaries aligned before translating (no-op when clean,
        // and skipped entirely on engines that take the glossary inline).
        twtr_glossary();
        if (Twtr_Glossary::remote_sync_supported() && self::glossary_needs_attention()) {
            Twtr_Glossary::refresh_sync();
        }

        // Atomic claim.
        $token = uniqid('twtr', true);
        $token = substr($token, 0, 23);
        $wpdb->query($wpdb->prepare(
            "UPDATE {$table} SET claim_token = %s, updated_at = UTC_TIMESTAMP()
             WHERE blog_id = %d AND status = 'pending' AND locked = 0 AND claim_token IS NULL
             ORDER BY id ASC LIMIT %d",
            $token, $blog_id, $size
        ));
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table} WHERE blog_id = %d AND claim_token = %s",
            $blog_id, $token
        ));

        if (!$rows) {
            $result['remaining'] = self::remaining();
            return $result;
        }

        $engine  = twtr_translator();
        $origin  = Twtr_Settings::provider();
        $version = (int) Twtr_Settings::network()['glossary_version'];

        // Group by target locale, then translate in char-bounded sub-batches.
        $by_locale = array();
        foreach ($rows as $row) {
            $by_locale[$row->target_locale][] = $row;
        }

        foreach ($by_locale as $locale => $locale_rows) {
            foreach (self::chunk_by_chars($locale_rows) as $chunk) {
                $texts = array();
                foreach ($chunk as $row) {
                    $texts[] = $row->source_text;
                }
                $chars        = array_sum(array_map('mb_strlen', $texts));
                $translations = $engine->translate_batch($texts, $default, $locale);

                if (is_wp_error($translations)) {
                    $message = mb_substr($translations->get_error_message(), 0, 490);
                    foreach ($chunk as $row) {
                        self::mark_failed($row, $message);
                        $result['errors']++;
                    }
                    $result['message'] = $message;
                    continue;
                }

                Twtr_Settings::add_usage($chars);
                foreach ($chunk as $i => $row) {
                    $wpdb->update($table, array(
                        'translated_text'  => $translations[$i],
                        'origin'           => $origin,
                        'status'           => 'ready',
                        'attempts'         => 0,
                        'glossary_version' => $version,
                        'claim_token'      => null,
                        'error_message'    => null,
                        'updated_at'       => current_time('mysql', true),
                    ), array('id' => (int) $row->id));
                    Twtr_Resolver::flush_group($row->target_locale, $row->context_key);
                    Twtr_Cache::purge_for_context($row->context_key, $row->target_locale);
                    $result['processed']++;
                }
            }
        }

        $result['remaining'] = self::remaining();
        self::reschedule_if_needed($result['remaining'], 60);
        return $result;
    }

    /**
     * Pending entries left for the current site.
     *
     * @return int
     */
    public static function remaining() {
        global $wpdb;
        return (int) $wpdb->get_var($wpdb->prepare(
            'SELECT COUNT(*) FROM ' . Twtr_Storage::entries_table() .
            " WHERE blog_id = %d AND status = 'pending' AND locked = 0",
            get_current_blog_id()
        ));
    }

    /**
     * Failure handling: retry with attempt counter, then park as error.
     *
     * @param object $row
     * @param string $message
     */
    private static function mark_failed($row, $message) {
        global $wpdb;
        $attempts = (int) $row->attempts + 1;
        $wpdb->update(Twtr_Storage::entries_table(), array(
            'status'        => $attempts >= self::MAX_ATTEMPTS ? 'error' : 'pending',
            'attempts'      => $attempts,
            'claim_token'   => null,
            'error_message' => $message,
            'updated_at'    => current_time('mysql', true),
        ), array('id' => (int) $row->id));
    }

    /**
     * Split rows into sub-batches bounded by total character count.
     *
     * @param object[] $rows
     * @return object[][]
     */
    private static function chunk_by_chars($rows) {
        $chunks  = array();
        $current = array();
        $chars   = 0;
        $budget  = self::max_batch_chars();
        foreach ($rows as $row) {
            $len = mb_strlen($row->source_text);
            if ($current && ($chars + $len) > $budget) {
                $chunks[] = $current;
                $current  = array();
                $chars    = 0;
            }
            $current[] = $row;
            $chars    += $len;
        }
        if ($current) {
            $chunks[] = $current;
        }
        return $chunks;
    }

    /**
     * @param int $remaining
     * @param int $delay Seconds.
     */
    private static function reschedule_if_needed($remaining, $delay) {
        if ($remaining > 0 && !wp_next_scheduled(self::HOOK)) {
            wp_schedule_single_event(time() + $delay, self::HOOK);
        }
    }

    /**
     * @return bool Whether the site's Google glossaries are behind the
     *              network glossary, or a pair is dirty or syncing.
     */
    private static function glossary_needs_attention() {
        $e = Twtr_Settings::engine();
        if ((int) $e['glossary_synced_version'] !== (int) Twtr_Settings::network()['glossary_version']) {
            return true;
        }
        foreach ((array) $e['glossary_state'] as $info) {
            if (isset($info['status']) && in_array($info['status'], array('dirty', 'syncing'), true)) {
                return true;
            }
        }
        return false;
    }
}
