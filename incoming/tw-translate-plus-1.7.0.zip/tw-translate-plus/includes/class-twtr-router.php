<?php
/**
 * Language router.
 *
 * The language prefix is interpreted BEFORE WordPress resolves the request:
 * at plugins_loaded the prefix is removed from REQUEST_URI so the original
 * object is loaded, and the original URI is restored right after
 * parse_request so canonical redirects and pagination keep working.
 *
 * No rewrite rules are registered and no flush is ever needed: the prefix
 * never reaches WP's rewrite parser. URL generation is handled by filtering
 * home_url on frontend requests.
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Router {

    /** @var string Current language slug, '' when serving the default language. */
    private static $current = '';

    /** @var string WP locale of the current language (e.g. en_US). */
    private static $wp_locale = '';

    /** @var string Path portion of the home URL, no trailing slash (e.g. /site1). */
    private static $home_path = '';

    /** @var string Original REQUEST_URI before the prefix strip. */
    private static $original_uri = '';

    /**
     * Detect the language prefix and register frontend filters.
     */
    public static function init() {
        if (is_admin() || wp_doing_cron() || (defined('WP_CLI') && WP_CLI) || empty($_SERVER['REQUEST_URI'])) {
            return;
        }

        $uri = $_SERVER['REQUEST_URI']; // phpcs:ignore WordPress.Security -- raw URI needed for routing, parsed strictly below.

        // Never route technical endpoints.
        if (preg_match('#/(wp-login\.php|wp-cron\.php|xmlrpc\.php|wp-json/|wp-content/|wp-includes/)#', $uri)) {
            return;
        }

        // Warm the settings cache BEFORE the locale filter is added, so the
        // default-language guess cannot recurse through get_locale().
        $default = Twtr_Settings::default_lang();
        $extra   = Twtr_Settings::extra_languages();

        self::$home_path = rtrim((string) parse_url(get_option('home'), PHP_URL_PATH), '/');

        if ($extra && preg_match(
            '#^' . preg_quote(self::$home_path, '#') . '/(' . implode('|', array_map('preg_quote', $extra)) . ')(/|$|\?)#',
            $uri,
            $m
        )) {
            self::$current      = $m[1];
            self::$wp_locale    = Twtr_Settings::wp_locale($m[1]);
            self::$original_uri = $uri;

            // Strip the prefix so WordPress resolves the original object.
            $stripped = self::$home_path . substr($uri, strlen(self::$home_path . '/' . $m[1]));
            if ($stripped === self::$home_path || $stripped === self::$home_path . '?') {
                $stripped = self::$home_path . '/';
            }
            if (strpos($stripped, self::$home_path . '?') === 0) {
                $stripped = self::$home_path . '/' . substr($stripped, strlen(self::$home_path));
            }
            $_SERVER['REQUEST_URI'] = $stripped;

            // Restore the real URI once the request has been parsed, so
            // redirect_canonical() compares against the true public URL.
            add_action('parse_request', array(__CLASS__, 'restore_request_uri'), 0);

            // Serve the whole request in the target locale: WP core, theme and
            // WooCommerce UI strings come from official language packs at zero
            // API cost.
            add_filter('locale', array(__CLASS__, 'filter_locale'), 5);
            add_filter('determine_locale', array(__CLASS__, 'filter_locale'), 5);
        }

        /*
         * URL generation: prefix internal links while a language is active —
         * but only AFTER WordPress core has finished resolving the request,
         * never before.
         *
         * BUG FOUND AND FIXED (subdirectory multisite): registering this
         * filter directly in init() — which runs on plugins_loaded, long
         * before WP::parse_request() executes — made every internal
         * home_url() call return the PREFIXED URL (".../en/") while
         * WordPress core was still resolving the request. On a subdirectory
         * multisite install, WP::parse_request() itself calls home_url() to
         * compute the site's own path and subtract it from REQUEST_URI. With
         * the filter already active, that internal call returned
         * "/tenconi/en" instead of "/tenconi" — a path that no longer
         * appears in the already-stripped REQUEST_URI (self::init() had
         * already removed "/en/" from it above) — so the subtraction found
         * nothing to remove. WordPress was left with "/tenconi" as the full
         * remaining path and matched it as if it were a page slug named
         * "tenconi", which does not exist: every prefixed URL 404'd,
         * including the language homepage itself.
         *
         * The fix: defer registration to the 'wp' action, which fires only
         * after WP::main() has fully resolved parse_request() + query_posts().
         * By then core has no further reason to call home_url() for its own
         * routing, so the filter is free to prefix links the theme generates
         * during template rendering without poisoning core's own resolution.
         */
        if (self::$current !== '') {
            add_action('wp', array(__CLASS__, 'register_home_url_filter'));
        }
    }

    /**
     * Deferred registration of the home_url prefixing filter — see the long
     * comment in init() for why this cannot be registered any earlier.
     */
    public static function register_home_url_filter() {
        add_filter('home_url', array(__CLASS__, 'filter_home_url'), 10, 2);
    }

    /**
     * @return string Current extra-language slug, '' for the default language.
     */
    public static function current_language() {
        return self::$current;
    }

    /**
     * @return string Original REQUEST_URI (with prefix) for the current request.
     */
    public static function original_uri() {
        return self::$original_uri !== '' ? self::$original_uri : (string) ($_SERVER['REQUEST_URI'] ?? '/');
    }

    /**
     * parse_request action: put the real URI back.
     */
    public static function restore_request_uri() {
        if (self::$original_uri !== '') {
            $_SERVER['REQUEST_URI'] = self::$original_uri;
        }
    }

    /**
     * locale filter while serving a translated page.
     *
     * @return string
     */
    public static function filter_locale() {
        return self::$wp_locale;
    }

    /**
     * home_url filter: insert the language prefix into internal frontend URLs.
     *
     * @param string $url  Full URL.
     * @param string $path Path passed to home_url().
     * @return string
     */
    public static function filter_home_url($url, $path = '') {
        if (self::$current === '') {
            return $url;
        }
        return self::add_prefix($url, self::$current);
    }

    /**
     * Build the URL of $url (default: current request) in the given language.
     *
     * @param string      $lang Language slug; the default language yields the unprefixed URL.
     * @param string|null $url  Absolute URL within this site, null = current request.
     * @return string
     */
    public static function language_url($lang, $url = null) {
        $home = get_option('home');
        if ($url === null) {
            $clean = self::strip_prefix_from_path(self::original_uri());
            $url   = rtrim($home, '/') . substr($clean, strlen(self::home_path()));
        } else {
            $parts = parse_url($url);
            $host  = isset($parts['host']) ? $parts['host'] : '';
            $home_host = (string) parse_url($home, PHP_URL_HOST);
            if ($host !== '' && strcasecmp($host, $home_host) !== 0) {
                return $url; // External URL: leave untouched.
            }
            $clean = self::strip_prefix_from_path(
                (isset($parts['path']) ? $parts['path'] : '/') .
                (isset($parts['query']) ? '?' . $parts['query'] : '')
            );
            $url = rtrim($home, '/') . substr($clean, strlen(self::home_path()));
            if (isset($parts['fragment'])) {
                $url .= '#' . $parts['fragment'];
            }
        }

        if ($lang === '' || $lang === Twtr_Settings::default_lang()) {
            return $url;
        }
        return self::add_prefix($url, $lang);
    }

    /**
     * Insert /{lang} after the home base path of an internal URL, skipping
     * technical endpoints and already-prefixed URLs.
     *
     * @param string $url
     * @param string $lang
     * @return string
     */
    private static function add_prefix($url, $lang) {
        if (!is_string($url) || $url === '') {
            return $url;
        }
        if (preg_match('#(wp-admin|wp-login|wp-json|wp-content|wp-includes|wp-cron|xmlrpc|admin-ajax|wp-sitemap|robots\.txt|\.php)#', $url)) {
            return $url;
        }
        $home_path = self::home_path();
        $parts     = parse_url($url);
        $path      = isset($parts['path']) ? $parts['path'] : '';

        if ($home_path !== '' && strpos($path, $home_path) !== 0) {
            return $url;
        }
        $rel = substr($path, strlen($home_path));
        if ($rel === false) {
            $rel = '';
        }
        if (preg_match('#^/' . preg_quote($lang, '#') . '(/|$)#', $rel)) {
            return $url; // Already prefixed.
        }
        if ($rel === '' || $rel === '/') {
            $new_path = $home_path . '/' . $lang . '/';
        } else {
            $new_path = $home_path . '/' . $lang . $rel;
        }
        // Rebuild preserving scheme/host/port/query/fragment: locate the path
        // AFTER the host so a root path '/' cannot match the '//' of the scheme.
        $search_from = 0;
        if (isset($parts['host'])) {
            $host_pos = strpos($url, $parts['host']);
            if ($host_pos !== false) {
                $search_from = $host_pos + strlen($parts['host']);
                if (isset($parts['port'])) {
                    $search_from += strlen(':' . $parts['port']);
                }
            }
        }
        if ($path === '') {
            return substr($url, 0, $search_from) . $new_path . substr($url, $search_from);
        }
        $prefix_end = strpos($url, $path, $search_from);
        if ($prefix_end === false) {
            return $url;
        }
        return substr($url, 0, $prefix_end) . $new_path . substr($url, $prefix_end + strlen($path));
    }

    /**
     * Remove any enabled-language prefix from a home-relative path.
     *
     * @param string $path_and_query Path starting with the home path.
     * @return string
     */
    private static function strip_prefix_from_path($path_and_query) {
        $home_path = self::home_path();
        $extra     = Twtr_Settings::extra_languages();
        if ($extra && preg_match(
            '#^' . preg_quote($home_path, '#') . '/(' . implode('|', array_map('preg_quote', $extra)) . ')(/|$|\?)#',
            $path_and_query,
            $m
        )) {
            $rest = substr($path_and_query, strlen($home_path . '/' . $m[1]));
            if ($rest === '' || $rest[0] === '?') {
                $rest = '/' . $rest;
            }
            return $home_path . $rest;
        }
        return $path_and_query;
    }

    /**
     * @return string Home path, memoized, no trailing slash.
     */
    private static function home_path() {
        if (self::$home_path === '') {
            self::$home_path = rtrim((string) parse_url(get_option('home'), PHP_URL_PATH), '/');
        }
        return self::$home_path;
    }

    /**
     * Whether a language slug would collide with existing top-level content.
     * Used by the admin UI before enabling a language.
     *
     * @param string $slug
     * @return bool
     */
    public static function slug_collides($slug) {
        global $wpdb;
        $post = $wpdb->get_var($wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} WHERE post_name = %s AND post_status = 'publish' AND post_parent = 0 LIMIT 1",
            $slug
        ));
        return !empty($post);
    }
}
