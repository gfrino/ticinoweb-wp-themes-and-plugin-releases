<?php
/**
 * Core-sitemaps provider for translated URLs.
 *
 * Appears in wp-sitemap.xml as "twtr" with one subtype per published
 * language. A translated URL enters the sitemap only when the post's
 * essential content is fully translated (see Twtr_Seo::is_ready()).
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Sitemap_Provider extends WP_Sitemaps_Provider {

    const PER_PAGE = 500;

    public function __construct() {
        $this->name        = 'twtr';
        $this->object_type = 'twtr';
    }

    /**
     * One subtype per published language.
     *
     * @return array
     */
    public function get_object_subtypes() {
        $subtypes = array();
        foreach (Twtr_Settings::extra_languages(true) as $lang) {
            $subtypes[$lang] = (object) array('name' => $lang);
        }
        return $subtypes;
    }

    /**
     * @param int    $page_num
     * @param string $object_subtype Language slug.
     * @return array[]
     */
    public function get_url_list($page_num, $object_subtype = '') {
        if ($object_subtype === '') {
            return array();
        }
        $ids  = $this->ready_post_ids($object_subtype);
        $ids  = array_slice($ids, ($page_num - 1) * self::PER_PAGE, self::PER_PAGE);
        $urls = array();

        // Home page of the language always leads the first page.
        if ($page_num === 1) {
            $urls[] = array('loc' => Twtr_Router::language_url($object_subtype, home_url('/')));
        }
        foreach ($ids as $post_id) {
            $post = get_post($post_id);
            if (!$post || $post->post_status !== 'publish' || !is_post_type_viewable($post->post_type)) {
                continue;
            }
            $urls[] = array(
                'loc'     => Twtr_Router::language_url($object_subtype, get_permalink($post)),
                'lastmod' => get_post_modified_time('c', true, $post),
            );
        }
        return $urls;
    }

    /**
     * @param string $object_subtype
     * @return int
     */
    public function get_max_num_pages($object_subtype = '') {
        if ($object_subtype === '') {
            return 0;
        }
        return max(1, (int) ceil(count($this->ready_post_ids($object_subtype)) / self::PER_PAGE));
    }

    /**
     * Post ids whose translation is complete for a language: title ready and
     * nothing pending or failed. Memoized per request and object-cached.
     *
     * @param string $lang
     * @return int[]
     */
    private function ready_post_ids($lang) {
        static $memo = array();
        if (isset($memo[$lang])) {
            return $memo[$lang];
        }
        $cache_key = 'twtr_sitemap_' . get_current_blog_id() . '_' . $lang;
        $cached    = wp_cache_get($cache_key, 'twtr');
        if (is_array($cached)) {
            $memo[$lang] = $cached;
            return $cached;
        }
        global $wpdb;
        $table = Twtr_Storage::entries_table();
        $ids   = $wpdb->get_col($wpdb->prepare(
            "SELECT CAST(SUBSTRING_INDEX(SUBSTRING_INDEX(context_key, ':', 2), ':', -1) AS UNSIGNED) AS pid
             FROM {$table}
             WHERE blog_id = %d AND target_locale = %s AND context_key LIKE 'post:%%'
             GROUP BY pid
             HAVING SUM(CASE WHEN context_key LIKE '%%:title' AND status = 'ready' THEN 1 ELSE 0 END) > 0
                AND SUM(CASE WHEN status IN ('pending','error') AND locked = 0 THEN 1 ELSE 0 END) = 0
             LIMIT 5000",
            get_current_blog_id(),
            $lang
        ));
        $ids = array_map('intval', (array) $ids);
        wp_cache_set($cache_key, $ids, 'twtr', HOUR_IN_SECONDS);
        $memo[$lang] = $ids;
        return $ids;
    }
}
