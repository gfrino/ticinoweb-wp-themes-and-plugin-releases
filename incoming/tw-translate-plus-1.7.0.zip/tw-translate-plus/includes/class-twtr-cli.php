<?php
/**
 * WP-CLI commands: wp twtr queue|status|retry|index|glossary-sync|legacy-keys
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_CLI {

    /**
     * Process the translation queue of the current site.
     *
     * ## OPTIONS
     *
     * [--batches=<n>]
     * : Number of batches to process (default 1, 0 = until empty).
     *
     * ## EXAMPLES
     *
     *     wp twtr queue --url=https://example.com/site1 --batches=0
     *
     * @subcommand queue
     */
    public function queue($args, $assoc_args) {
        twtr_queue();
        $batches = isset($assoc_args['batches']) ? (int) $assoc_args['batches'] : 1;
        $run     = 0;
        do {
            $result = Twtr_Queue::process();
            $run++;
            WP_CLI::log(sprintf(
                'Batch %d: %d tradotte, %d errori, %d in coda. %s',
                $run, $result['processed'], $result['errors'], $result['remaining'], $result['message']
            ));
            if ($result['remaining'] === 0 || ($result['processed'] === 0 && $result['errors'] === 0)) {
                break;
            }
        } while ($batches === 0 || $run < $batches);
        WP_CLI::success('Coda processata.');
    }

    /**
     * Show translation status per language.
     *
     * @subcommand status
     */
    public function status($args, $assoc_args) {
        $counts = Twtr_Storage::status_counts();
        if (!$counts) {
            WP_CLI::log('Nessuna traduzione registrata per questo sito.');
            return;
        }
        $rows = array();
        foreach ($counts as $locale => $statuses) {
            $rows[] = array(
                'lingua'  => $locale,
                'ready'   => isset($statuses['ready']) ? $statuses['ready'] : 0,
                'pending' => isset($statuses['pending']) ? $statuses['pending'] : 0,
                'stale'   => isset($statuses['stale']) ? $statuses['stale'] : 0,
                'error'   => isset($statuses['error']) ? $statuses['error'] : 0,
            );
        }
        \WP_CLI\Utils\format_items('table', $rows, array('lingua', 'ready', 'pending', 'stale', 'error'));
        WP_CLI::log('Motore di traduzione del sito: ' . Twtr_Settings::provider_label());
        $missing = Twtr_Settings::engine_missing_reason();
        if ($missing !== '') {
            WP_CLI::warning($missing);
        } elseif (Twtr_Settings::provider() === 'openai') {
            WP_CLI::log('Chiave OpenAI del sito: …' . Twtr_Settings::openai_key_hint());
        }
        $limit = Twtr_Settings::daily_char_limit();
        WP_CLI::log('Caratteri usati oggi (sito): ' . number_format_i18n(Twtr_Settings::usage_today())
            . ' / ' . ($limit > 0 ? number_format_i18n($limit) : 'nessun limite'));
    }

    /**
     * Reset failed entries back to pending and process them.
     *
     * @subcommand retry
     */
    public function retry($args, $assoc_args) {
        $reset = Twtr_Storage::retry_errors();
        WP_CLI::log($reset . ' entry in errore rimesse in coda.');
        if ($reset > 0) {
            $this->queue(array(), array('batches' => 0));
        }
    }

    /**
     * Index every published content and public term of the current site,
     * queueing the strings not translated yet (same as the admin button).
     *
     * ## OPTIONS
     *
     * [--process]
     * : Process the queue until empty right after indexing.
     *
     * ## EXAMPLES
     *
     *     wp twtr index --url=https://example.com/site1 --process
     *
     * @subcommand index
     */
    public function index($args, $assoc_args) {
        if (!Twtr_Settings::extra_languages()) {
            WP_CLI::error('Nessuna lingua aggiuntiva attiva su questo sito.');
        }
        twtr_queue();
        $before  = Twtr_Queue::remaining();
        $phase   = 'posts';
        $offset  = 0;
        $scanned = 0;
        do {
            $result   = Twtr_Extractor::index_batch($phase, $offset, 50);
            $scanned += $result['scanned'];
            $phase    = $result['phase'];
            $offset   = $result['offset'];
            WP_CLI::log(sprintf('%d/%d elementi esaminati…', $scanned, $result['total']));
        } while (!$result['done']);
        WP_CLI::success(sprintf(
            'Indicizzazione completata: %d elementi esaminati, %d nuove stringhe in coda.',
            $scanned, max(0, Twtr_Queue::remaining() - $before)
        ));
        if (!empty($assoc_args['process'])) {
            $this->queue(array(), array('batches' => 0));
        }
    }

    /**
     * Force a Google glossary re-sync for all needed language pairs.
     *
     * Only meaningful with the Google engine: OpenAI receives the glossary
     * inline in the prompt, so there is nothing to push.
     *
     * @subcommand glossary-sync
     */
    public function glossary_sync($args, $assoc_args) {
        twtr_glossary();
        if (!Twtr_Glossary::remote_sync_supported()) {
            WP_CLI::success(sprintf(
                'Motore attivo: %s. Il glossario viene applicato al momento della traduzione, nessuna sincronizzazione necessaria.',
                Twtr_Settings::provider_label()
            ));
            return;
        }
        foreach (Twtr_Glossary::needed_pairs() as $pair) {
            list($src, $tgt) = explode('-', $pair, 2);
            $result = Twtr_Glossary::sync_pair($src, $tgt);
            if (is_wp_error($result)) {
                WP_CLI::warning($pair . ': ' . $result->get_error_message());
            } else {
                WP_CLI::log($pair . ': sincronizzazione avviata.');
            }
        }
        Twtr_Glossary::refresh_sync();
        WP_CLI::success('Sync glossario completata (verifica lo stato nella pagina Glossario del sito).');
    }

    /**
     * Network-level credentials left by versions before 1.7.0.
     *
     * Since 1.7.0 every site translates only with its own key and the
     * network values are never read. They are not moved automatically
     * because the plugin cannot know which site a key belongs to: assign
     * them explicitly, then purge them from the network option.
     *
     * ## OPTIONS
     *
     * [--assign=<engine>]
     * : Copy the network credentials of this engine (openai|google) into the
     * site given with --url and select that engine for the site.
     *
     * [--purge]
     * : Delete every credential and the old network usage counter from the
     * network option.
     *
     * ## EXAMPLES
     *
     *     wp twtr legacy-keys
     *     wp twtr legacy-keys --assign=openai --url=https://example.com/
     *     wp twtr legacy-keys --purge
     *
     * @subcommand legacy-keys
     */
    public function legacy_keys($args, $assoc_args) {
        $legacy = get_site_option(Twtr_Settings::NETWORK_OPTION, array());
        $legacy = is_array($legacy) ? $legacy : array();
        $openai = isset($legacy['openai_api_key']) ? (string) $legacy['openai_api_key'] : '';
        $gjson  = isset($legacy['credentials_json']) ? (string) $legacy['credentials_json'] : '';
        $gpath  = isset($legacy['credentials_path']) ? (string) $legacy['credentials_path'] : '';
        $gdata  = $gjson !== '' ? json_decode($gjson, true) : null;

        if (!empty($assoc_args['assign'])) {
            $engine = sanitize_key($assoc_args['assign']);
            if ($engine === 'openai') {
                if ($openai === '') {
                    WP_CLI::error('Nessuna chiave OpenAI di rete da assegnare.');
                }
                Twtr_Settings::update_engine(array(
                    'provider'       => 'openai',
                    'openai_api_key' => $openai,
                    'openai_model'   => !empty($legacy['openai_model']) ? (string) $legacy['openai_model'] : 'gpt-4o-mini',
                ));
            } elseif ($engine === 'google') {
                if ($gjson === '' && $gpath === '') {
                    WP_CLI::error('Nessuna credenziale Google di rete da assegnare.');
                }
                Twtr_Settings::update_engine(array(
                    'provider'         => 'google',
                    'project_id'       => isset($legacy['project_id']) ? (string) $legacy['project_id'] : '',
                    'location'         => !empty($legacy['location']) ? (string) $legacy['location'] : 'us-central1',
                    'credentials_json' => $gjson,
                    'credentials_path' => $gpath,
                    'gcs_bucket'       => isset($legacy['gcs_bucket']) ? (string) $legacy['gcs_bucket'] : '',
                    // The Google glossaries already exist in that project.
                    'glossary_state'          => isset($legacy['glossary_state']) ? (array) $legacy['glossary_state'] : array(),
                    'glossary_synced_version' => (int) Twtr_Settings::network()['glossary_version'],
                ));
            } else {
                WP_CLI::error('--assign accetta openai oppure google.');
            }
            delete_transient('twtr_google_token');
            WP_CLI::success(sprintf('Credenziali %s assegnate a %s.', $engine, home_url('/')));
            return;
        }

        if (!empty($assoc_args['purge'])) {
            foreach (array('provider', 'openai_api_key', 'openai_model', 'openai_models', 'openai_models_at', 'project_id', 'location',
                'credentials_path', 'credentials_json', 'gcs_bucket', 'daily_char_limit', 'glossary_state') as $key) {
                unset($legacy[$key]);
            }
            update_site_option(Twtr_Settings::NETWORK_OPTION, $legacy);
            delete_site_option('twtr_usage');
            delete_site_transient('twtr_google_token');
            WP_CLI::success('Credenziali di rete eliminate: ogni sito usa solo le proprie.');
            return;
        }

        WP_CLI::log('OpenAI di rete: ' . ($openai !== '' ? 'chiave …' . substr($openai, -4) : 'nessuna'));
        WP_CLI::log('Google di rete: ' . (is_array($gdata) && !empty($gdata['client_email'])
            ? $gdata['client_email'] . (!empty($legacy['project_id']) ? ' (progetto ' . $legacy['project_id'] . ')' : '')
            : ($gpath !== '' ? 'file ' . $gpath : 'nessuna')));
        WP_CLI::log('Queste credenziali non vengono piu\' usate: assegnale al sito a cui appartengono con --assign, poi eliminale con --purge.');
    }
}
