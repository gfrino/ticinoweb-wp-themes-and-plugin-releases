<?php
/**
 * Content-change tracking.
 *
 * When a post or term is saved, its translatable strings are extracted,
 * hashes are compared against stored entries, missing translations are
 * enqueued and superseded entries are marked stale. The editor never waits
 * for the translation engine: everything is processed by the background queue.
 *
 * Strings the extractor cannot predict (shortcode output, theme strings)
 * are discovered on their first frontend render and enqueued the same way.
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Extractor {

    /**
     * Register save hooks (cheap; they only act on actual saves).
     */
    public static function init() {
        add_action('save_post', array(__CLASS__, 'on_save_post'), 20, 2);
        add_action('edited_term', array(__CLASS__, 'on_saved_term'), 20, 3);
        add_action('created_term', array(__CLASS__, 'on_saved_term'), 20, 3);
    }

    /**
     * Extract and enqueue the translatable strings of a saved post.
     *
     * @param int     $post_id
     * @param WP_Post $post
     */
    public static function on_save_post($post_id, $post) {
        if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) {
            return;
        }
        if ($post->post_status !== 'publish' || !is_post_type_viewable($post->post_type)) {
            return;
        }
        $locales = Twtr_Settings::extra_languages();
        if (!$locales) {
            return;
        }

        $touched = false;
        if ($post->post_title !== '') {
            Twtr_Storage::sync_source('post:' . $post_id . ':title', $post->post_title, $locales);
            $touched = true;
        }
        if ($post->post_excerpt !== '') {
            $context = ($post->post_type === 'product') ? 'product:' . $post_id . ':short-description' : 'post:' . $post_id . ':excerpt';
            // WooCommerce renders the short description through wpautop.
            $excerpt = ($post->post_type === 'product') ? trim(wpautop($post->post_excerpt)) : $post->post_excerpt;
            Twtr_Storage::sync_source($context, $excerpt, $locales);
            if ($post->post_type === 'product') {
                Twtr_Storage::sync_source('post:' . $post_id . ':excerpt', $post->post_excerpt, $locales);
            }
            $touched = true;
        }
        if (trim($post->post_content) !== '' ) {
            require_once TWTR_DIR . 'includes/class-twtr-content.php';
        }
        if (trim($post->post_content) !== '' && Twtr_Content::is_translatable_chunk(strip_shortcodes($post->post_content))) {
            // Approximate the render pipeline (do_blocks → wptexturize →
            // wpautop → shortcode_unautop) without executing shortcodes;
            // chunks that differ at render time are discovered there.
            $html   = shortcode_unautop(wpautop(wptexturize(do_blocks($post->post_content))));
            $chunks = array();
            foreach (Twtr_Content::split_html($html) as $chunk) {
                if (Twtr_Content::is_translatable_chunk($chunk)) {
                    $chunks[] = $chunk;
                }
            }
            if ($chunks) {
                Twtr_Storage::sync_source_multi('post:' . $post_id . ':content', $chunks, $locales);
                $touched = true;
            }
        }

        // SEO meta description managed by the tW SEO module.
        $seo_desc = get_post_meta($post_id, '_tw_seo_description', true);
        if (is_string($seo_desc) && $seo_desc !== '') {
            Twtr_Storage::sync_source('seo:post:' . $post_id . ':description', $seo_desc, $locales);
            $touched = true;
        }

        if ($touched) {
            self::flush_and_schedule($locales, array(
                'post:' . $post_id . ':title',
                'post:' . $post_id . ':excerpt',
                'post:' . $post_id . ':content',
                'product:' . $post_id . ':short-description',
                'seo:post:' . $post_id . ':description',
            ));
            Twtr_Cache::purge_post_all_languages($post_id);
        }
    }

    /**
     * Extract and enqueue term name/description.
     *
     * @param int    $term_id
     * @param int    $tt_id
     * @param string $taxonomy
     */
    public static function on_saved_term($term_id, $tt_id, $taxonomy) {
        $tax = get_taxonomy($taxonomy);
        if (!$tax || !$tax->public) {
            return;
        }
        $locales = Twtr_Settings::extra_languages();
        if (!$locales) {
            return;
        }
        $term = get_term($term_id, $taxonomy);
        if (!($term instanceof WP_Term)) {
            return;
        }
        if ($term->name !== '') {
            Twtr_Storage::sync_source('term:' . $term_id . ':name', $term->name, $locales);
        }
        if ($term->description !== '') {
            Twtr_Storage::sync_source('term:' . $term_id . ':description', $term->description, $locales);
        }
        self::flush_and_schedule($locales, array(
            'term:' . $term_id . ':name',
            'term:' . $term_id . ':description',
        ));
    }

    /* ------------------------------------------------------ Full-site indexing */

    /**
     * Post types the indexer walks: public, viewable, not attachments
     * (same set used by Twtr_Storage::language_progress()).
     *
     * @return string[]
     */
    public static function indexable_post_types() {
        $types = array();
        foreach (get_post_types(array('public' => true)) as $type) {
            if ($type !== 'attachment' && is_post_type_viewable($type)) {
                $types[] = $type;
            }
        }
        return $types;
    }

    /**
     * Taxonomies the indexer walks (the same on_saved_term() accepts).
     *
     * @return string[]
     */
    public static function indexable_taxonomies() {
        return array_values(get_taxonomies(array('public' => true)));
    }

    /**
     * How many items a full index has to walk.
     *
     * @return array{posts:int,terms:int}
     */
    public static function index_totals() {
        $posts = 0;
        foreach (self::indexable_post_types() as $type) {
            $counts = wp_count_posts($type);
            $posts += isset($counts->publish) ? (int) $counts->publish : 0;
        }
        $taxes = self::indexable_taxonomies();
        $terms = $taxes ? wp_count_terms(array('taxonomy' => $taxes, 'hide_empty' => false)) : 0;
        return array(
            'posts' => $posts,
            'terms' => is_wp_error($terms) ? 0 : (int) $terms,
        );
    }

    /**
     * Index the whole site one batch at a time: every published content of
     * a public post type, then every term of a public taxonomy, goes through
     * the same extraction used on save. Strings already known are left
     * untouched (sync_source() compares hashes), missing ones are queued.
     *
     * Exists because discovery is otherwise lazy — on save or on the first
     * frontend visit of the translated page — so a catalogue published
     * before a language was activated never enters the queue on its own.
     *
     * Called repeatedly (AJAX loop or WP-CLI) with the phase/offset returned
     * by the previous call until done=true.
     *
     * @param string $phase  'posts' or 'terms'.
     * @param int    $offset Items already walked in this phase.
     * @param int    $limit  Items per call.
     * @return array{phase:string,offset:int,done:bool,scanned:int,total:int}
     */
    public static function index_batch($phase = 'posts', $offset = 0, $limit = 20) {
        $totals  = self::index_totals();
        $limit   = max(1, (int) $limit);
        $offset  = max(0, (int) $offset);
        $scanned = 0;
        $done    = false;

        if ($phase !== 'terms') {
            $phase = 'posts';
            $types = self::indexable_post_types();
            $posts = $types ? get_posts(array(
                'post_type'        => $types,
                'post_status'      => 'publish',
                'posts_per_page'   => $limit,
                'offset'           => $offset,
                'orderby'          => 'ID',
                'order'            => 'ASC',
                'suppress_filters' => true,
                'no_found_rows'    => true,
            )) : array();
            foreach ($posts as $post) {
                self::on_save_post($post->ID, $post);
                $scanned++;
            }
            $offset += $scanned;
            if ($scanned < $limit) {
                $phase  = 'terms';
                $offset = 0;
            }
        } else {
            $taxes = self::indexable_taxonomies();
            $terms = $taxes ? get_terms(array(
                'taxonomy'   => $taxes,
                'hide_empty' => false,
                'number'     => $limit,
                'offset'     => $offset,
                'orderby'    => 'term_id',
                'order'      => 'ASC',
            )) : array();
            if (is_wp_error($terms)) {
                $terms = array();
            }
            foreach ($terms as $term) {
                self::on_saved_term($term->term_id, $term->term_taxonomy_id, $term->taxonomy);
                $scanned++;
            }
            $offset += $scanned;
            $done    = $scanned < $limit;
        }

        return array(
            'phase'   => $phase,
            'offset'  => $offset,
            'done'    => $done,
            'scanned' => $scanned,
            'total'   => $totals['posts'] + $totals['terms'],
        );
    }

    /**
     * Invalidate resolver caches for the touched contexts and kick the queue.
     *
     * @param string[] $locales
     * @param string[] $contexts
     */
    private static function flush_and_schedule($locales, $contexts) {
        foreach ($locales as $locale) {
            foreach ($contexts as $context) {
                Twtr_Resolver::flush_group($locale, $context);
            }
        }
        twtr_queue();
        Twtr_Queue::schedule();
    }
}
