<?php
/**
 * Aggiornamenti del plugin dal repository pubblico delle release ticinoWEB.
 *
 * Repo: https://github.com/gfrino/ticinoweb-wp-themes-and-plugin-releases
 * Convenzione (la stessa del parent theme, inc/github-updater.php): una
 * release per versione, tag `tw-translate-plus-v<versione>`, asset
 * `tw-translate-plus-<versione>.zip` con dentro la cartella
 * `tw-translate-plus/`. Il corpo della release e' il changelog mostrato
 * nella finestra "Dettagli versione".
 *
 * Il plugin si aggancia a `pre_set_site_transient_update_plugins`: la nuova
 * versione compare in Aggiornamenti e nella lista plugin (in multisite nella
 * bacheca di rete) e viene installata dall'aggiornatore standard di
 * WordPress. Quando non c'e' nulla da aggiornare il plugin viene comunque
 * dichiarato in `no_update`: senza, WordPress non mostra l'interruttore
 * "Abilita aggiornamenti automatici" per un plugin che non viene da
 * wordpress.org.
 *
 * Le release sono lette al massimo una volta ogni 12 ore (site transient);
 * "Controlla di nuovo" in Aggiornamenti forza il ricontrollo.
 *
 * Classe con nome proprio (non TW_GitHub_Updater del parent): i plugin si
 * caricano prima del tema, e una classe con lo stesso nome farebbe saltare
 * quella del parent tramite il suo class_exists().
 *
 * @package tw-translate-plus
 * @since 1.7.0
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!defined('TWTR_RELEASES_REPO')) {
    define('TWTR_RELEASES_REPO', 'gfrino/ticinoweb-wp-themes-and-plugin-releases');
}

if (!class_exists('Twtr_Updater')) :

class Twtr_Updater {

    const SLUG      = 'tw-translate-plus';
    const BASENAME  = 'tw-translate-plus/tw-translate-plus.php';
    const CACHE_TTL = 12 * HOUR_IN_SECONDS;

    /** @var bool */
    private static $registered = false;

    /** @var string */
    private static $version = '';

    /**
     * Hook the updater once per request. Safe to call from the plugin itself
     * and from a network-wide loader: the second call is a no-op.
     */
    public static function register() {
        if (self::$registered) {
            return;
        }
        self::$registered = true;

        add_filter('pre_set_site_transient_update_plugins', array(__CLASS__, 'inject_update'));
        add_filter('site_transient_update_plugins', array(__CLASS__, 'inject_update'));
        add_filter('plugins_api', array(__CLASS__, 'plugin_details'), 10, 3);
        add_filter('upgrader_source_selection', array(__CLASS__, 'fix_source_folder'), 10, 4);
        add_action('upgrader_process_complete', array(__CLASS__, 'flush_cache'), 10, 0);
        add_action('load-update-core.php', array(__CLASS__, 'maybe_force_check'));
        add_action('load-plugins.php', array(__CLASS__, 'maybe_force_check'));
    }

    /**
     * Installed version, read from the plugin header on disk (not from the
     * TWTR_VERSION constant: a network-wide loader can run where the plugin
     * itself is not loaded).
     *
     * @return string
     */
    private static function installed_version() {
        if (self::$version === '') {
            if (!function_exists('get_plugin_data')) {
                require_once ABSPATH . 'wp-admin/includes/plugin.php';
            }
            $file = WP_PLUGIN_DIR . '/' . self::BASENAME;
            self::$version = file_exists($file) ? (string) get_plugin_data($file, false, false)['Version'] : '0';
        }
        return self::$version;
    }

    /* ---------- lettura release ---------- */

    private static function cache_key() {
        return 'twtr_ghu_' . md5(TWTR_RELEASES_REPO . '|' . self::SLUG);
    }

    public static function flush_cache() {
        delete_site_transient(self::cache_key());
    }

    public static function maybe_force_check() {
        if (isset($_GET['force-check'])) { // phpcs:ignore WordPress.Security.NonceVerification -- read-only cache flush, same as core.
            self::flush_cache();
        }
    }

    /**
     * Latest stable release of this plugin, or null.
     *
     * @return array{version:string,package:string,url:string,body:string,published:string}|null
     */
    public static function latest_release() {
        $cached = get_site_transient(self::cache_key());
        if (is_array($cached)) {
            return empty($cached['none']) ? $cached : null;
        }

        $response = wp_remote_get(
            sprintf('https://api.github.com/repos/%s/releases?per_page=50', TWTR_RELEASES_REPO),
            array(
                'timeout' => 8,
                'headers' => array(
                    'Accept'     => 'application/vnd.github+json',
                    'User-Agent' => 'ticinoWEB-updater/' . self::SLUG,
                ),
            )
        );

        if (is_wp_error($response) || (int) wp_remote_retrieve_response_code($response) !== 200) {
            // Network error or rate limit: retry in an hour, quietly.
            set_site_transient(self::cache_key(), array('none' => true), HOUR_IN_SECONDS);
            return null;
        }

        $releases = json_decode(wp_remote_retrieve_body($response), true);
        $prefix   = self::SLUG . '-v';
        $latest   = null;

        foreach ((array) $releases as $rel) {
            if (!is_array($rel) || !empty($rel['draft']) || !empty($rel['prerelease'])) {
                continue;
            }
            $tag = isset($rel['tag_name']) ? (string) $rel['tag_name'] : '';
            if (strpos($tag, $prefix) !== 0) {
                continue;
            }
            $version = substr($tag, strlen($prefix));
            if (!preg_match('/^\d+(\.\d+){1,3}$/', $version)) {
                continue;
            }
            $package = '';
            foreach ((array) (isset($rel['assets']) ? $rel['assets'] : array()) as $asset) {
                $name = isset($asset['name']) ? (string) $asset['name'] : '';
                if (substr($name, -4) === '.zip' && strpos($name, self::SLUG . '-') === 0) {
                    $package = (string) $asset['browser_download_url'];
                    break;
                }
            }
            if ($package === '') {
                continue;
            }
            if ($latest === null || version_compare($version, $latest['version'], '>')) {
                $latest = array(
                    'version'   => $version,
                    'package'   => $package,
                    'url'       => isset($rel['html_url']) ? (string) $rel['html_url'] : '',
                    'body'      => isset($rel['body']) ? (string) $rel['body'] : '',
                    'published' => isset($rel['published_at']) ? (string) $rel['published_at'] : '',
                );
            }
        }

        set_site_transient(self::cache_key(), $latest ? $latest : array('none' => true), self::CACHE_TTL);
        return $latest;
    }

    /* ---------- integrazione aggiornatore ---------- */

    /**
     * @param object|mixed $transient update_plugins site transient.
     * @return object
     */
    public static function inject_update($transient) {
        if (!is_object($transient)) {
            $transient = new stdClass();
        }
        $installed = self::installed_version();
        $latest    = self::latest_release();

        $item = (object) array(
            'id'           => self::BASENAME,
            'slug'         => self::SLUG,
            'plugin'       => self::BASENAME,
            'new_version'  => $installed,
            'url'          => 'https://github.com/' . TWTR_RELEASES_REPO,
            'package'      => '',
            'requires'     => '6.2',
            'requires_php' => '7.4',
        );

        if ($latest && version_compare($latest['version'], $installed, '>')) {
            $item->new_version = $latest['version'];
            $item->url         = $latest['url'];
            $item->package     = $latest['package'];
            if (!isset($transient->response) || !is_array($transient->response)) {
                $transient->response = array();
            }
            $transient->response[self::BASENAME] = $item;
            if (isset($transient->no_update[self::BASENAME])) {
                unset($transient->no_update[self::BASENAME]);
            }
        } else {
            if (isset($transient->response[self::BASENAME])) {
                unset($transient->response[self::BASENAME]);
            }
            // Listed as "up to date" so the auto-update toggle is offered.
            if (!isset($transient->no_update) || !is_array($transient->no_update)) {
                $transient->no_update = array();
            }
            $transient->no_update[self::BASENAME] = $item;
        }
        return $transient;
    }

    /**
     * "Dettagli versione" popup.
     */
    public static function plugin_details($result, $action, $args) {
        if ($action !== 'plugin_information' || empty($args->slug) || $args->slug !== self::SLUG) {
            return $result;
        }
        $latest = self::latest_release();
        if (!$latest) {
            return $result;
        }
        return (object) array(
            'name'          => 'tW Translate Plus',
            'slug'          => self::SLUG,
            'version'       => $latest['version'],
            'author'        => 'ticinoWEB',
            'homepage'      => 'https://github.com/' . TWTR_RELEASES_REPO,
            'requires'      => '6.2',
            'requires_php'  => '7.4',
            'last_updated'  => $latest['published'],
            'download_link' => $latest['package'],
            'sections'      => array('changelog' => self::format_body($latest['body'])),
        );
    }

    /**
     * The zip must extract to a folder named after the slug: rename it when
     * the asset was built with another folder name.
     */
    public static function fix_source_folder($source, $remote_source, $upgrader, $hook_extra) {
        if (is_wp_error($source) || empty($hook_extra['plugin']) || $hook_extra['plugin'] !== self::BASENAME) {
            return $source;
        }
        global $wp_filesystem;
        if (basename(untrailingslashit($source)) === self::SLUG) {
            return $source;
        }
        $target = trailingslashit(dirname(untrailingslashit($source))) . self::SLUG;
        if ($wp_filesystem && $wp_filesystem->move($source, $target)) {
            return trailingslashit($target);
        }
        return $source;
    }

    /**
     * Minimal markdown of the release body → safe HTML.
     */
    private static function format_body($md) {
        $md = trim((string) $md);
        if ($md === '') {
            return '';
        }
        $html    = '';
        $in_list = false;
        foreach (preg_split('/\r?\n/', $md) as $line) {
            $line = trim($line);
            if (preg_match('/^[-*]\s+(.*)$/', $line, $m)) {
                if (!$in_list) { $html .= '<ul>'; $in_list = true; }
                $html .= '<li>' . self::inline_md($m[1]) . '</li>';
                continue;
            }
            if ($in_list) { $html .= '</ul>'; $in_list = false; }
            if ($line === '') {
                continue;
            }
            if (preg_match('/^(#{1,6})\s+(.*)$/', $line, $m)) {
                $level = min(4, max(3, strlen($m[1])));
                $html .= "<h{$level}>" . self::inline_md($m[2]) . "</h{$level}>";
                continue;
            }
            $html .= '<p>' . self::inline_md($line) . '</p>';
        }
        if ($in_list) { $html .= '</ul>'; }
        return $html;
    }

    private static function inline_md($text) {
        $text = esc_html($text);
        $text = preg_replace('/`([^`]+)`/', '<code>$1</code>', $text);
        $text = preg_replace('/\*\*([^*]+)\*\*/', '<strong>$1</strong>', $text);
        return $text;
    }
}

endif;
