<?php
/**
 * WordPress content adapter (frontend, non-default language only).
 *
 * Hooks the standard display filters and maps them to stable context keys.
 * Post content is segmented into top-level HTML chunks; each chunk is one
 * entry identified by (post:{id}:content, hash), so reordering paragraphs
 * never invalidates translations and editing one paragraph re-translates
 * only that paragraph.
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Content {

    /**
     * Register frontend filters.
     */
    public static function init() {
        add_filter('the_title', array(__CLASS__, 'title'), 20, 2);
        add_filter('single_post_title', array(__CLASS__, 'single_title'), 20, 2);
        add_filter('the_content', array(__CLASS__, 'content'), 20);
        add_filter('get_the_excerpt', array(__CLASS__, 'excerpt'), 20, 2);
        add_filter('get_term', array(__CLASS__, 'term'), 20);
        add_filter('single_term_title', array(__CLASS__, 'term_title'), 20);
        add_filter('widget_title', array(__CLASS__, 'widget_title'), 20);
        add_filter('nav_menu_link_attributes', array(__CLASS__, 'menu_link'), 20);
        add_filter('list_pages', array(__CLASS__, 'list_pages_title'), 20, 2);
        add_filter('document_title_parts', array(__CLASS__, 'document_title_parts'), 20);
    }

    /**
     * the_title filter.
     *
     * @param string $title
     * @param int    $post_id
     * @return string
     */
    public static function title($title, $post_id = 0) {
        if (!$post_id || is_admin()) {
            return $title;
        }
        return Twtr_Resolver::translate($title, 'post:' . (int) $post_id . ':title');
    }

    /**
     * single_post_title filter (used by document titles).
     *
     * @param string  $title
     * @param WP_Post $post
     * @return string
     */
    public static function single_title($title, $post = null) {
        $id = $post instanceof WP_Post ? $post->ID : 0;
        if (!$id) {
            return $title;
        }
        return Twtr_Resolver::translate($title, 'post:' . $id . ':title');
    }

    /**
     * the_content filter: chunked translation.
     *
     * @param string $content Rendered HTML.
     * @return string
     */
    public static function content($content) {
        $post_id = get_the_ID();
        if (!$post_id || trim($content) === '') {
            return $content;
        }
        // Pages whose stored content is only shortcodes (template/builder
        // pages) render through their own filters, which are often already
        // localized: chunking their output would register TRANSLATED text as
        // "source". Their strings are translated by the inner adapters.
        $raw = get_post_field('post_content', $post_id);
        if (is_string($raw) && !self::is_translatable_chunk(strip_shortcodes($raw))) {
            return $content;
        }
        $context = 'post:' . (int) $post_id . ':content';
        $chunks  = self::split_html($content);
        if (count($chunks) === 1 && !self::is_translatable_chunk($content)) {
            return $content;
        }
        $out = '';
        foreach ($chunks as $chunk) {
            if (self::is_translatable_chunk($chunk)) {
                $out .= Twtr_Resolver::translate($chunk, $context);
            } else {
                $out .= $chunk;
            }
        }
        return $out;
    }

    /**
     * get_the_excerpt filter.
     *
     * @param string  $excerpt
     * @param WP_Post $post
     * @return string
     */
    public static function excerpt($excerpt, $post = null) {
        $id = $post instanceof WP_Post ? $post->ID : get_the_ID();
        if (!$id || $excerpt === '') {
            return $excerpt;
        }
        return Twtr_Resolver::translate($excerpt, 'post:' . (int) $id . ':excerpt');
    }

    /**
     * get_term filter: translate name and description for display. The term
     * object itself (slug, ids, relations) is untouched.
     *
     * @param WP_Term $term
     * @return WP_Term
     */
    public static function term($term) {
        if (!($term instanceof WP_Term) || is_admin()) {
            return $term;
        }
        if ($term->name !== '') {
            $term->name = Twtr_Resolver::translate($term->name, 'term:' . (int) $term->term_id . ':name');
        }
        if ($term->description !== '') {
            $term->description = Twtr_Resolver::translate($term->description, 'term:' . (int) $term->term_id . ':description');
        }
        return $term;
    }

    /**
     * single_term_title filter (archive headings/document title).
     *
     * @param string $title
     * @return string
     */
    public static function term_title($title) {
        $term = get_queried_object();
        if ($term instanceof WP_Term && $title !== '') {
            return Twtr_Resolver::translate($title, 'term:' . (int) $term->term_id . ':name');
        }
        return $title;
    }

    /**
     * widget_title filter.
     *
     * @param string $title
     * @return string
     */
    public static function widget_title($title) {
        if (!is_string($title) || $title === '') {
            return $title;
        }
        return Twtr_Resolver::translate($title, 'widget:title:' . md5($title));
    }

    /**
     * Prefix custom menu links pointing to this site (permalinks are already
     * handled by the home_url filter, but custom URLs are stored verbatim).
     *
     * @param array $atts
     * @return array
     */
    public static function menu_link($atts) {
        if (!empty($atts['href'])) {
            $atts['href'] = Twtr_Router::language_url(Twtr_Router::current_language(), $atts['href']);
        }
        return $atts;
    }

    /**
     * wp_list_pages titles (page-list menus/widgets) — same context identity
     * as the_title, so existing translations apply immediately.
     *
     * @param string  $title
     * @param WP_Post $page
     * @return string
     */
    public static function list_pages_title($title, $page = null) {
        if (!($page instanceof WP_Post) || $title === '') {
            return $title;
        }
        return Twtr_Resolver::translate($title, 'post:' . $page->ID . ':title');
    }

    /**
     * Translate the site name / tagline parts of the document title. The
     * "title" part is already translated upstream via single_post_title.
     *
     * @param array $parts
     * @return array
     */
    public static function document_title_parts($parts) {
        if (!empty($parts['site'])) {
            $parts['site'] = Twtr_Resolver::translate($parts['site'], 'site:name');
        }
        if (!empty($parts['tagline'])) {
            $parts['tagline'] = Twtr_Resolver::translate($parts['tagline'], 'site:description');
        }
        return $parts;
    }

    const MAX_CHUNK_CHARS = 6000;

    /**
     * Split rendered post HTML into balanced top-level chunks.
     *
     * A depth-aware tokenizer cuts ONLY at nesting depth zero, so every chunk
     * is well-formed HTML (inline tags, images and shortcode output stay
     * intact). Oversized wrapper elements (page builders wrapping the whole
     * content in one div) are descended recursively: the wrapper tags become
     * pass-through chunks and the inner content is split again.
     *
     * @param string $html
     * @param int    $depth_guard Recursion guard.
     * @return string[]
     */
    public static function split_html($html, $depth_guard = 0) {
        $void = array('area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr');
        $chunks = array();
        $buffer = '';
        $depth  = 0;
        $offset = 0;
        $len    = strlen($html);

        while ($offset < $len && preg_match('#<(/?)([a-zA-Z][a-zA-Z0-9-]*)((?:"[^"]*"|\'[^\']*\'|[^>"\'])*)>#', $html, $m, PREG_OFFSET_CAPTURE, $offset)) {
            $tag_pos = $m[0][1];
            $tag_len = strlen($m[0][0]);
            $is_close = $m[1][0] === '/';
            $name     = strtolower($m[2][0]);
            $attrs    = $m[3][0];

            // Text before this tag.
            $buffer .= substr($html, $offset, $tag_pos - $offset) . $m[0][0];
            $offset  = $tag_pos + $tag_len;

            if (in_array($name, $void, true) || substr(rtrim($attrs), -1) === '/') {
                // Void/self-closing: depth unchanged.
            } elseif ($is_close) {
                $depth = max(0, $depth - 1);
            } else {
                if ($name === 'script' || $name === 'style') {
                    // Consume up to the matching close tag verbatim.
                    $close = stripos($html, '</' . $name, $offset);
                    if ($close !== false) {
                        $end     = strpos($html, '>', $close);
                        $end     = ($end === false) ? $len : $end + 1;
                        $buffer .= substr($html, $offset, $end - $offset);
                        $offset  = $end;
                    }
                } else {
                    $depth++;
                }
            }

            if ($depth === 0 && trim($buffer) !== '') {
                $chunks[] = $buffer;
                $buffer   = '';
            }
        }
        if ($offset < $len) {
            $buffer .= substr($html, $offset);
        }
        if (trim($buffer) !== '') {
            $chunks[] = $buffer;
        }
        if (!$chunks) {
            return array($html);
        }

        // Descend into oversized single wrappers (max 3 levels).
        if ($depth_guard < 3) {
            $expanded = array();
            foreach ($chunks as $chunk) {
                if (mb_strlen($chunk) > self::MAX_CHUNK_CHARS &&
                    preg_match('#^\s*(<([a-zA-Z][a-zA-Z0-9-]*)(?:"[^"]*"|\'[^\']*\'|[^>"\'])*>)(.*)(</\2\s*>)\s*$#s', $chunk, $w)) {
                    $expanded[] = $w[1];
                    foreach (self::split_html($w[3], $depth_guard + 1) as $inner) {
                        $expanded[] = $inner;
                    }
                    $expanded[] = $w[4];
                } else {
                    $expanded[] = $chunk;
                }
            }
            $chunks = $expanded;
        }
        return $chunks;
    }

    /**
     * A chunk is translatable when it contains letters outside of tags,
     * script/style blocks are excluded.
     *
     * @param string $chunk
     * @return bool
     */
    public static function is_translatable_chunk($chunk) {
        if (preg_match('#<(script|style)\b#i', $chunk)) {
            return false;
        }
        // Never translate raw shortcode tags: a "translated" shortcode name
        // breaks the shortcode when rendered.
        if (preg_match('/\[[a-z0-9_-]{3,}(\s|\])/i', $chunk)) {
            return false;
        }
        $text = trim(wp_strip_all_tags($chunk));
        return $text !== '' && preg_match('/\p{L}/u', $text);
    }
}
