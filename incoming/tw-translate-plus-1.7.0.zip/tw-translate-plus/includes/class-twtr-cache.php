<?php
/**
 * Selective cache invalidation.
 *
 * The language is part of the URL, so LiteSpeed caches translated pages by
 * URL with no cookie/vary tricks. When a translation changes, only the
 * affected URLs are purged through LiteSpeed's public hooks; site-wide
 * strings (theme footer/header texts) require a full purge because they
 * appear on every page. Without LiteSpeed only the internal object cache is
 * touched — standard WordPress has no page cache to purge.
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Cache {

    /** @var bool One full purge per request at most. */
    private static $purged_all = false;

    /**
     * Nothing to register up-front; kept for bootstrap symmetry/future hooks.
     */
    public static function init() {}

    /**
     * @return bool Whether LiteSpeed Cache is active.
     */
    private static function has_litespeed() {
        return defined('LSCWP_V');
    }

    /**
     * Purge the URLs affected by one translation entry.
     *
     * @param string $context Context key (e.g. post:152:content).
     * @param string $locale  Target language slug.
     */
    public static function purge_for_context($context, $locale) {
        if (!self::has_litespeed() || self::$purged_all) {
            return;
        }
        if (preg_match('/^(?:post|seo:post|product):(\d+):/', $context, $m)) {
            $permalink = get_permalink((int) $m[1]);
            if ($permalink) {
                do_action('litespeed_purge_url', Twtr_Router::language_url($locale, $permalink));
            }
            return;
        }
        if (preg_match('/^term:(\d+):/', $context, $m)) {
            $link = get_term_link((int) $m[1]);
            if (!is_wp_error($link)) {
                do_action('litespeed_purge_url', Twtr_Router::language_url($locale, $link));
            }
            return;
        }
        // theme:*, site:*, widget:*, woo:* strings appear on many/all pages:
        // a full purge is the only correct invalidation.
        self::purge_all();
    }

    /**
     * Full page-cache purge (language/settings/glossary changes).
     */
    public static function purge_all() {
        if (self::$purged_all) {
            return;
        }
        self::$purged_all = true;
        if (self::has_litespeed()) {
            do_action('litespeed_purge_all');
        }
        if (function_exists('wp_cache_flush_group')) {
            wp_cache_flush_group('twtr');
        }
    }

    /**
     * Purge every language variant of one post (used on manual override save).
     *
     * @param int $post_id
     */
    public static function purge_post_all_languages($post_id) {
        if (!self::has_litespeed()) {
            return;
        }
        $permalink = get_permalink((int) $post_id);
        if (!$permalink) {
            return;
        }
        foreach (Twtr_Settings::extra_languages() as $lang) {
            do_action('litespeed_purge_url', Twtr_Router::language_url($lang, $permalink));
        }
    }
}
