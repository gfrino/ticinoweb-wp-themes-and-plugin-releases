<?php
/**
 * Storage: shared network tables for translation entries and the global
 * glossary. Uses $wpdb->base_prefix so a single table serves the whole
 * network; on single-site installs base_prefix equals the normal prefix.
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Storage {

    /**
     * @return string Entries table name.
     */
    public static function entries_table() {
        global $wpdb;
        return $wpdb->base_prefix . 'twtr_entries';
    }

    /**
     * @return string Glossary table name.
     */
    public static function glossary_table() {
        global $wpdb;
        return $wpdb->base_prefix . 'twtr_glossary';
    }

    /**
     * Create or upgrade the schema. Called only on activation and when the
     * stored DB version differs from TWTR_DB_VERSION — never per request.
     */
    public static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset = $wpdb->get_charset_collate();
        $entries = self::entries_table();
        $gloss   = self::glossary_table();

        dbDelta("CREATE TABLE {$entries} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            blog_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            context_key VARCHAR(191) NOT NULL,
            source_hash CHAR(32) NOT NULL,
            source_text LONGTEXT NOT NULL,
            target_locale VARCHAR(10) NOT NULL,
            translated_text LONGTEXT NULL,
            origin VARCHAR(10) NOT NULL DEFAULT 'google',
            status VARCHAR(10) NOT NULL DEFAULT 'pending',
            locked TINYINT(1) NOT NULL DEFAULT 0,
            attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
            glossary_version INT UNSIGNED NOT NULL DEFAULT 0,
            claim_token CHAR(23) NULL DEFAULT NULL,
            error_message VARCHAR(500) NULL DEFAULT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY entry_identity (blog_id,target_locale,context_key,source_hash),
            KEY queue_scan (blog_id,status,locked),
            KEY context_scan (blog_id,target_locale,context_key)
        ) {$charset};");

        dbDelta("CREATE TABLE {$gloss} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            source_text VARCHAR(191) NOT NULL,
            translations LONGTEXT NOT NULL,
            active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY source_term (source_text)
        ) {$charset};");

        update_site_option('twtr_db_version', TWTR_DB_VERSION);
    }

    /**
     * Fetch every entry for a (locale, context) group of the current site,
     * keyed by source hash. One query typically covers all content chunks of
     * a post at once.
     *
     * @param string $locale  Target language slug.
     * @param string $context Context key.
     * @return array<string,object>
     */
    public static function get_context_group($locale, $context) {
        global $wpdb;
        $rows = $wpdb->get_results($wpdb->prepare(
            'SELECT source_hash, translated_text, origin, status, locked FROM ' . self::entries_table() .
            ' WHERE blog_id = %d AND target_locale = %s AND context_key = %s',
            get_current_blog_id(), $locale, $context
        ));
        $out = array();
        foreach ((array) $rows as $row) {
            $out[$row->source_hash] = $row;
        }
        return $out;
    }

    /**
     * Insert missing entries as pending, ignoring duplicates.
     *
     * @param array $items Each item: [context, hash, source, locale].
     * @return int Number of new rows.
     */
    public static function insert_pending($items) {
        global $wpdb;
        if (!$items) {
            return 0;
        }
        $blog_id = get_current_blog_id();
        $now     = current_time('mysql', true);
        $values  = array();
        foreach ($items as $it) {
            $values[] = $wpdb->prepare('(%d,%s,%s,%s,%s,%s,%s)',
                $blog_id, $it['context'], $it['hash'], $it['source'], $it['locale'], $now, $now);
        }
        // INSERT IGNORE: the unique key on (blog_id,target_locale,context_key,source_hash)
        // makes concurrent discovery safe.
        $sql = 'INSERT IGNORE INTO ' . self::entries_table() .
            ' (blog_id, context_key, source_hash, source_text, target_locale, created_at, updated_at) VALUES ' .
            implode(',', $values);
        $result = $wpdb->query($sql); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- values prepared above.
        return (int) $result;
    }

    /**
     * Ensure entries exist for a source string across the given locales and
     * mark superseded manual overrides of the same context as stale.
     *
     * @param string   $context Context key.
     * @param string   $source  Original text.
     * @param string[] $locales Target language slugs.
     */
    public static function sync_source($context, $source, $locales) {
        global $wpdb;
        if ($source === '' || !$locales) {
            return;
        }
        $blog_id = get_current_blog_id();
        $hash    = md5($source);
        $items   = array();
        foreach ($locales as $locale) {
            $items[] = array('context' => $context, 'hash' => $hash, 'source' => $source, 'locale' => $locale);
        }
        $created = self::insert_pending($items);

        if ($created > 0) {
            // The source changed: previous entries of this context (any hash but
            // the current one) become stale. Manual ones are kept for review;
            // old google ones are kept only as history and never requeued
            // because the lookup is hash-based.
            $placeholders = implode(',', array_fill(0, count($locales), '%s'));
            $params = array_merge(array($blog_id, $context, $hash), $locales);
            $wpdb->query($wpdb->prepare(
                'UPDATE ' . self::entries_table() .
                " SET status = 'stale', updated_at = UTC_TIMESTAMP() " .
                " WHERE blog_id = %d AND context_key = %s AND source_hash <> %s AND target_locale IN ({$placeholders}) AND status = 'ready'",
                $params
            ));
        }
    }

    /**
     * Multi-string variant of sync_source() for chunked contexts (post
     * content): entries are inserted for every current chunk and only rows
     * whose hash no longer belongs to the current set are marked stale.
     *
     * @param string   $context Context key shared by all chunks.
     * @param string[] $sources Current chunk texts.
     * @param string[] $locales Target language slugs.
     */
    public static function sync_source_multi($context, $sources, $locales) {
        global $wpdb;
        $sources = array_values(array_filter($sources, 'strlen'));
        if (!$sources || !$locales) {
            return;
        }
        $blog_id = get_current_blog_id();
        $hashes  = array();
        $items   = array();
        foreach ($sources as $source) {
            $hash = md5($source);
            $hashes[$hash] = true;
            foreach ($locales as $locale) {
                $items[] = array('context' => $context, 'hash' => $hash, 'source' => $source, 'locale' => $locale);
            }
        }
        self::insert_pending($items);

        $hash_list   = array_keys($hashes);
        $hash_ph     = implode(',', array_fill(0, count($hash_list), '%s'));
        $locale_ph   = implode(',', array_fill(0, count($locales), '%s'));
        $params      = array_merge(array($blog_id, $context), $hash_list, $locales);
        $wpdb->query($wpdb->prepare(
            'UPDATE ' . self::entries_table() .
            " SET status = 'stale', updated_at = UTC_TIMESTAMP()" .
            " WHERE blog_id = %d AND context_key = %s AND source_hash NOT IN ({$hash_ph})" .
            " AND target_locale IN ({$locale_ph}) AND status = 'ready'",
            $params
        ));
    }

    /**
     * Save a manual override.
     *
     * @param int    $id   Entry id (must belong to the current site).
     * @param string $text Translated text.
     * @return bool
     */
    public static function save_manual($id, $text) {
        global $wpdb;
        $updated = $wpdb->update(
            self::entries_table(),
            array(
                'translated_text' => $text,
                'origin'          => 'manual',
                'status'          => 'ready',
                'locked'          => 1,
                'error_message'   => null,
                'updated_at'      => current_time('mysql', true),
            ),
            array('id' => (int) $id, 'blog_id' => get_current_blog_id())
        );
        return (bool) $updated;
    }

    /**
     * Drop a manual override: unlock the entry and requeue it for the active
     * translation engine, keeping the current text visible until the new
     * translation arrives.
     *
     * @param int $id Entry id.
     * @return bool
     */
    public static function restore_machine($id) {
        global $wpdb;
        $updated = $wpdb->update(
            self::entries_table(),
            array(
                'origin'     => Twtr_Settings::provider(),
                'status'     => 'pending',
                'locked'     => 0,
                'attempts'   => 0,
                'updated_at' => current_time('mysql', true),
            ),
            array('id' => (int) $id, 'blog_id' => get_current_blog_id())
        );
        return (bool) $updated;
    }

    /**
     * @deprecated 1.6.0 Use restore_machine(); kept for older integrations.
     *
     * @param int $id Entry id.
     * @return bool
     */
    public static function restore_google($id) {
        return self::restore_machine($id);
    }

    /**
     * Get one entry of the current site by id.
     *
     * @param int $id
     * @return object|null
     */
    public static function get_entry($id) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare(
            'SELECT * FROM ' . self::entries_table() . ' WHERE id = %d AND blog_id = %d',
            (int) $id, get_current_blog_id()
        ));
    }

    /**
     * Previous manual override for the same context (different hash), used by
     * the admin UI to offer "recupera traduzione precedente".
     *
     * @param object $entry Current entry row.
     * @return object|null
     */
    public static function previous_manual($entry) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare(
            'SELECT * FROM ' . self::entries_table() .
            ' WHERE blog_id = %d AND target_locale = %s AND context_key = %s AND source_hash <> %s' .
            " AND origin = 'manual' ORDER BY updated_at DESC LIMIT 1",
            get_current_blog_id(), $entry->target_locale, $entry->context_key, $entry->source_hash
        ));
    }

    /**
     * Status counters for the current site, grouped by locale and status.
     *
     * @return array<string,array<string,int>> locale => status => count
     */
    public static function status_counts() {
        global $wpdb;
        $rows = $wpdb->get_results($wpdb->prepare(
            'SELECT target_locale, status, COUNT(*) AS n FROM ' . self::entries_table() .
            ' WHERE blog_id = %d GROUP BY target_locale, status',
            get_current_blog_id()
        ));
        $out = array();
        foreach ((array) $rows as $row) {
            $out[$row->target_locale][$row->status] = (int) $row->n;
        }
        return $out;
    }

    /**
     * Site-wide translation progress for one language: percentage of
     * discovered strings already translated, scaled by how much of the
     * published content has been discovered at all. Reaches 100% only when
     * every published post/page has entries and nothing is pending/failed.
     *
     * @param string $locale Language slug.
     * @return array{percent:int,ready:int,total:int,posts_covered:int,posts_total:int}
     */
    public static function language_progress($locale) {
        global $wpdb;
        $table   = self::entries_table();
        $blog_id = get_current_blog_id();

        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT
                SUM(CASE WHEN status = 'ready' THEN 1 ELSE 0 END) AS ready_entries,
                SUM(CASE WHEN status IN ('pending','error') AND locked = 0 THEN 1 ELSE 0 END) AS unresolved_entries,
                SUM(CASE WHEN status <> 'stale' THEN 1 ELSE 0 END) AS total_entries
             FROM {$table}
             WHERE blog_id = %d AND target_locale = %s",
            $blog_id, $locale
        ));

        // Posts fully translated: title ready and nothing pending/failed
        // (same criteria used for sitemap/noindex gating).
        $ready_posts = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM (
                SELECT CAST(SUBSTRING_INDEX(SUBSTRING_INDEX(context_key, ':', 2), ':', -1) AS UNSIGNED) AS pid
                FROM {$table}
                WHERE blog_id = %d AND target_locale = %s AND context_key LIKE 'post:%%'
                GROUP BY pid
                HAVING SUM(CASE WHEN context_key LIKE '%%:title' AND status = 'ready' THEN 1 ELSE 0 END) > 0
                   AND SUM(CASE WHEN status IN ('pending','error') AND locked = 0 THEN 1 ELSE 0 END) = 0
            ) AS ready_posts",
            $blog_id, $locale
        ));

        $posts_total = 0;
        foreach (get_post_types(array('public' => true)) as $type) {
            if ($type === 'attachment') {
                continue;
            }
            $counts = wp_count_posts($type);
            $posts_total += isset($counts->publish) ? (int) $counts->publish : 0;
        }

        $ready      = $row ? (int) $row->ready_entries : 0;
        $unresolved = $row ? (int) $row->unresolved_entries : 0;
        $total      = $row ? (int) $row->total_entries : 0;

        if ($total === 0) {
            $percent = 0;
        } else {
            // Strict: the weakest of the two ratios drives the bar.
            $entry_ratio = $ready / $total;
            $post_ratio  = $posts_total > 0 ? min(1, $ready_posts / $posts_total) : 1;
            $percent     = (int) floor(min($entry_ratio, $post_ratio) * 100);
            // 100% only when queue is empty, nothing failed and EVERY
            // published content is fully translated.
            $complete = $unresolved === 0 && $ready > 0 && ($posts_total === 0 || $ready_posts >= $posts_total);
            if (!$complete && $percent >= 100) {
                $percent = 99;
            }
            if ($complete) {
                $percent = 100;
            }
        }
        return array(
            'percent'       => max(0, min(100, $percent)),
            'ready'         => $ready,
            'total'         => $total,
            'posts_covered' => $ready_posts,
            'posts_total'   => $posts_total,
        );
    }

    /**
     * Reset error entries of the current site back to pending.
     *
     * @return int Rows affected.
     */
    public static function retry_errors() {
        global $wpdb;
        return (int) $wpdb->query($wpdb->prepare(
            'UPDATE ' . self::entries_table() .
            " SET status = 'pending', attempts = 0, error_message = NULL, claim_token = NULL, updated_at = UTC_TIMESTAMP()" .
            " WHERE blog_id = %d AND status = 'error' AND locked = 0",
            get_current_blog_id()
        ));
    }

    /**
     * Paginated entry search for the admin UI.
     *
     * @param array $args {search, locale, status, page, per_page}
     * @return array{rows:array,total:int}
     */
    public static function search($args) {
        global $wpdb;
        $where  = array('blog_id = %d');
        $params = array(get_current_blog_id());

        if (!empty($args['locale'])) {
            $where[]  = 'target_locale = %s';
            $params[] = $args['locale'];
        }
        if (!empty($args['status'])) {
            if ($args['status'] === 'manual') {
                $where[] = "origin = 'manual'";
            } else {
                $where[]  = 'status = %s';
                $params[] = $args['status'];
            }
        }
        if (!empty($args['search'])) {
            $like     = '%' . $wpdb->esc_like($args['search']) . '%';
            $where[]  = '(source_text LIKE %s OR translated_text LIKE %s OR context_key LIKE %s)';
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }

        $per_page = max(1, (int) ($args['per_page'] ?? 50));
        $offset   = (max(1, (int) ($args['page'] ?? 1)) - 1) * $per_page;
        $where_sql = implode(' AND ', $where);
        $table     = self::entries_table();

        $total = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}", $params
        ));
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY updated_at DESC LIMIT %d OFFSET %d",
            array_merge($params, array($per_page, $offset))
        ));
        return array('rows' => (array) $rows, 'total' => $total);
    }
}
