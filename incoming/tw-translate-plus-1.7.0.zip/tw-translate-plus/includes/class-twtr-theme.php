<?php
/**
 * ticinoweb-ai-theme adapter.
 *
 * The parent theme routes every frontend string through
 * ticinoweb_frontend_text($text, $context) and every internal URL through
 * ticinoweb_frontend_url($url, $context). Texts are resolved against the
 * translation store using the theme's own context keys; URLs are already
 * covered by the home_url filter, so the URL hook only normalizes URLs that
 * were built before the filter was in place.
 *
 * The adapter is inert on themes that never fire these filters.
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Theme_Adapter {

    /**
     * Register theme filters.
     */
    public static function init() {
        add_filter('ticinoweb_frontend_text', array(__CLASS__, 'text'), 10, 2);
        add_filter('ticinoweb_frontend_url', array(__CLASS__, 'url'), 10, 1);
        // tW SEO module integration.
        add_filter('ticinoweb_seo_meta_description', array(__CLASS__, 'meta_description'), 10);
        add_filter('ticinoweb_seo_og_locale', array(__CLASS__, 'og_locale'), 10);
    }

    /**
     * Translate a theme string by its context key.
     *
     * @param string $text
     * @param string $context
     * @return string
     */
    public static function text($text, $context = '') {
        if ($context === '') {
            return $text;
        }
        return Twtr_Resolver::translate($text, $context);
    }

    /**
     * Ensure theme URLs carry the language prefix (idempotent).
     *
     * @param string $url
     * @return string
     */
    public static function url($url) {
        return Twtr_Router::language_url(Twtr_Router::current_language(), $url);
    }

    /**
     * Translate the meta description emitted by the tW SEO module.
     *
     * @param string $description
     * @return string
     */
    public static function meta_description($description) {
        if ($description === '') {
            return $description;
        }
        $obj = get_queried_object();
        if ($obj instanceof WP_Post) {
            return Twtr_Resolver::translate($description, 'seo:post:' . $obj->ID . ':description');
        }
        if (is_front_page() || is_home()) {
            return Twtr_Resolver::translate($description, 'seo:home:description');
        }
        return $description;
    }

    /**
     * Correct og:locale for the served language.
     *
     * @return string
     */
    public static function og_locale() {
        return str_replace('-', '_', Twtr_Settings::wp_locale(twtr_get_current_language()));
    }
}
