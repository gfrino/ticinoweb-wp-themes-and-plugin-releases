<?php
/**
 * Global network glossary.
 *
 * The WordPress table is the source of truth. How it reaches the engine
 * depends on which one is active: Google gets official v3 glossary
 * resources (one per language pair) synchronized from the table, while
 * OpenAI receives the relevant terms inline in the prompt, which needs no
 * sync at all and takes effect on the very next translation.
 *
 * On change: glossary_version is incremented, only affected machine
 * translations are requeued, manual overrides are never touched, and the
 * last valid translation stays visible until the new one arrives.
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Glossary {

    /**
     * All glossary rows.
     *
     * @param string $search Optional term filter.
     * @return object[]
     */
    public static function all($search = '') {
        global $wpdb;
        $table = Twtr_Storage::glossary_table();
        if ($search !== '') {
            return (array) $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM {$table} WHERE source_text LIKE %s ORDER BY source_text ASC LIMIT 500",
                '%' . $wpdb->esc_like($search) . '%'
            ));
        }
        return (array) $wpdb->get_results("SELECT * FROM {$table} ORDER BY source_text ASC LIMIT 500");
    }

    /**
     * Create or update a term.
     *
     * @param string $source       Original term.
     * @param array  $translations lang-slug => translated term.
     * @param bool   $active
     * @return true|WP_Error
     */
    public static function save_term($source, $translations, $active = true) {
        global $wpdb;
        $source = trim(wp_strip_all_tags($source));
        if ($source === '' || strlen($source) > 191) {
            return new WP_Error('twtr_glossary', __('Termine non valido (vuoto o troppo lungo).', 'tw-translate-plus'));
        }
        $clean = array();
        foreach ((array) $translations as $lang => $value) {
            $lang  = sanitize_key($lang);
            $value = trim(wp_strip_all_tags((string) $value));
            if ($value !== '' && isset(Twtr_Settings::catalog()[$lang])) {
                $clean[$lang] = $value;
            }
        }
        $table = Twtr_Storage::glossary_table();
        $now   = current_time('mysql', true);
        $existing_id = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE source_text = %s", $source));

        if ($existing_id) {
            $wpdb->update($table, array(
                'translations' => wp_json_encode($clean),
                'active'       => $active ? 1 : 0,
                'updated_at'   => $now,
            ), array('id' => (int) $existing_id));
        } else {
            $wpdb->insert($table, array(
                'source_text'  => $source,
                'translations' => wp_json_encode($clean),
                'active'       => $active ? 1 : 0,
                'created_at'   => $now,
                'updated_at'   => $now,
            ));
        }

        self::bump_version($source, array_keys($clean));
        return true;
    }

    /**
     * Delete a term permanently.
     *
     * @param int $id
     */
    public static function delete_term($id) {
        global $wpdb;
        $table = Twtr_Storage::glossary_table();
        $row   = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", (int) $id));
        if (!$row) {
            return;
        }
        $wpdb->delete($table, array('id' => (int) $id));
        $langs = array_keys((array) json_decode($row->translations, true));
        self::bump_version($row->source_text, $langs);
    }

    /**
     * Increment the glossary version and requeue ONLY affected machine
     * entries (matching term, affected languages, not manual/locked).
     *
     * The Google resources are per site (each site syncs into its own Google
     * project): a site whose glossary_synced_version is behind the new
     * version re-syncs its pairs on its next refresh_sync().
     *
     * @param string   $term  The changed source term.
     * @param string[] $langs Affected target language slugs.
     */
    private static function bump_version($term, $langs) {
        global $wpdb;
        $version = (int) Twtr_Settings::network()['glossary_version'] + 1;
        Twtr_Settings::update_network(array('glossary_version' => $version));

        if ($term !== '' && $langs) {
            $origins      = Twtr_Settings::machine_origins();
            $origin_ph    = implode(',', array_fill(0, count($origins), '%s'));
            $placeholders = implode(',', array_fill(0, count($langs), '%s'));
            $params = array_merge(
                $origins,
                array('%' . $wpdb->esc_like($term) . '%'),
                $langs
            );
            // Selective staling: only ready machine translations whose source
            // actually contains the term — whichever engine produced them, since
            // a network that switched engine still has the older rows. They keep
            // their current text until the queue replaces it.
            $wpdb->query($wpdb->prepare(
                'UPDATE ' . Twtr_Storage::entries_table() .
                " SET status = 'pending', attempts = 0, updated_at = UTC_TIMESTAMP()" .
                " WHERE origin IN ({$origin_ph}) AND locked = 0 AND status = 'ready'" .
                " AND source_text LIKE %s AND target_locale IN ({$placeholders})",
                $params
            ));
        }

        // Flush resolver group caches network-wide.
        if (function_exists('wp_cache_flush_group')) {
            wp_cache_flush_group('twtr');
        }
    }

    /**
     * Whether the active engine needs glossary resources pushed to it.
     * Google builds server-side glossaries from CSV files in Cloud Storage;
     * OpenAI reads the terms straight from the prompt, so there is nothing
     * to synchronize and no bucket to configure.
     *
     * @return bool
     */
    public static function remote_sync_supported() {
        return Twtr_Settings::provider() === 'google';
    }

    /**
     * Active terms that have a translation into one language, as a flat map.
     * Used by the OpenAI engine to build the glossary section of its prompt.
     *
     * @param string $target_lang
     * @return array<string,string> source term => fixed translation.
     */
    public static function terms_for($target_lang) {
        $out = array();
        foreach (self::all() as $row) {
            if (!(int) $row->active) {
                continue;
            }
            $tr = (array) json_decode($row->translations, true);
            if (!empty($tr[$target_lang])) {
                $out[$row->source_text] = (string) $tr[$target_lang];
            }
        }
        return $out;
    }

    /**
     * Synchronize the Google glossary resource of one language pair from the
     * WordPress table: upload CSV to GCS, drop the old resource, create the
     * new one. The pair stays "syncing" until the operation completes; the
     * translation queue simply translates without glossary in the meantime.
     *
     * @param string $source_lang
     * @param string $target_lang
     * @return true|WP_Error
     */
    public static function sync_pair($source_lang, $target_lang) {
        if (!self::remote_sync_supported()) {
            return true;
        }
        $google = twtr_google();
        $pair   = $source_lang . '-' . $target_lang;
        $csv    = self::build_csv($source_lang, $target_lang);

        if ($csv === '') {
            // No terms for this pair: remove the remote glossary if any.
            $google->delete_glossary(Twtr_Google::glossary_resource_id($source_lang, $target_lang));
            self::set_pair_state($pair, array('status' => 'empty', 'error' => '', 'operation' => ''));
            return true;
        }

        $uri = $google->gcs_upload('twtr/glossary-' . $pair . '.csv', $csv);
        if (is_wp_error($uri)) {
            self::set_pair_state($pair, array('status' => 'error', 'error' => $uri->get_error_message()));
            return $uri;
        }

        $glossary_id = Twtr_Google::glossary_resource_id($source_lang, $target_lang);
        $deleted     = $google->delete_glossary($glossary_id);
        if (is_wp_error($deleted)) {
            self::set_pair_state($pair, array('status' => 'error', 'error' => $deleted->get_error_message()));
            return $deleted;
        }

        // Glossary deletion is async on Google's side; a create issued too
        // early returns ALREADY_EXISTS. Retry briefly, then leave it to the
        // next status check.
        $operation = null;
        for ($i = 0; $i < 3; $i++) {
            $operation = $google->create_glossary($glossary_id, $source_lang, $target_lang, $uri);
            if (!is_wp_error($operation)) {
                break;
            }
            if (strpos($operation->get_error_code(), 'twtr_http_409') !== 0) {
                break;
            }
            sleep(2);
        }
        if (is_wp_error($operation)) {
            self::set_pair_state($pair, array('status' => 'error', 'error' => $operation->get_error_message()));
            return $operation;
        }

        self::set_pair_state($pair, array('status' => 'syncing', 'operation' => $operation, 'error' => ''));
        return true;
    }

    /**
     * Refresh the state of pairs in "syncing" by polling their operations,
     * and sync pairs marked dirty. Called from the network admin page and
     * from the queue worker (cheap: no-op when nothing is dirty/syncing).
     */
    public static function refresh_sync() {
        if (!self::remote_sync_supported()) {
            return;
        }
        if (!Twtr_Settings::engine_ready()) {
            return;
        }
        $e       = Twtr_Settings::engine();
        $state   = (array) $e['glossary_state'];
        $version = (int) Twtr_Settings::network()['glossary_version'];

        // The network glossary changed since this site last synced: every
        // pair of this site's Google project has to be rebuilt.
        if ((int) $e['glossary_synced_version'] !== $version) {
            foreach (array_keys($state) as $pair) {
                $state[$pair]['status'] = 'dirty';
            }
        }

        // Ensure every needed pair has a state entry.
        foreach (self::needed_pairs() as $pair) {
            if (!isset($state[$pair])) {
                $state[$pair] = array('status' => 'dirty', 'operation' => '', 'error' => '');
            }
        }
        Twtr_Settings::update_engine(array(
            'glossary_state'          => $state,
            'glossary_synced_version' => $version,
        ));

        foreach ($state as $pair => $info) {
            $status = isset($info['status']) ? $info['status'] : '';
            list($src, $tgt) = array_pad(explode('-', $pair, 2), 2, '');
            if ($src === '' || $tgt === '') {
                continue;
            }
            if ($status === 'dirty') {
                self::sync_pair($src, $tgt);
            } elseif ($status === 'syncing' && !empty($info['operation'])) {
                $op = twtr_google()->get_operation($info['operation']);
                if (is_wp_error($op)) {
                    self::set_pair_state($pair, array('status' => 'error', 'error' => $op->get_error_message()));
                } elseif ($op['done'] && $op['error'] === '') {
                    self::set_pair_state($pair, array('status' => 'ready', 'operation' => '', 'error' => ''));
                } elseif ($op['done']) {
                    self::set_pair_state($pair, array('status' => 'error', 'error' => mb_substr($op['error'], 0, 200)));
                }
            }
        }
    }

    /**
     * Language pairs needed across the network. Derived from the glossary
     * content itself (source: every language that appears as default
     * somewhere would be exhaustive; v1 keeps it simple: the main site's
     * default language is the glossary source language).
     *
     * @return string[] e.g. ['it-en', 'it-de']
     */
    public static function needed_pairs() {
        global $wpdb;
        $table = Twtr_Storage::glossary_table();
        $rows  = $wpdb->get_col("SELECT translations FROM {$table} WHERE active = 1 LIMIT 500");
        $langs = array();
        foreach ($rows as $json) {
            foreach ((array) json_decode($json, true) as $lang => $value) {
                if ($value !== '') {
                    $langs[$lang] = true;
                }
            }
        }
        $source = Twtr_Settings::default_lang();
        $pairs  = array();
        foreach (array_keys($langs) as $lang) {
            if ($lang !== $source) {
                $pairs[] = $source . '-' . $lang;
            }
        }
        return $pairs;
    }

    /**
     * CSV (source,target) of active terms translated into $target_lang.
     *
     * @return string Empty when no usable terms.
     */
    private static function build_csv($source_lang, $target_lang) {
        $lines = array();
        foreach (self::all() as $row) {
            if (!(int) $row->active) {
                continue;
            }
            $tr = (array) json_decode($row->translations, true);
            if (empty($tr[$target_lang])) {
                continue;
            }
            $lines[] = self::csv_field($row->source_text) . ',' . self::csv_field($tr[$target_lang]);
        }
        return $lines ? implode("\n", $lines) . "\n" : '';
    }

    /**
     * @param string $value
     * @return string CSV-escaped field.
     */
    private static function csv_field($value) {
        return '"' . str_replace('"', '""', $value) . '"';
    }

    /**
     * Merge state for one pair.
     *
     * @param string $pair
     * @param array  $partial
     */
    private static function set_pair_state($pair, $partial) {
        $state = (array) Twtr_Settings::engine()['glossary_state'];
        $state[$pair] = array_merge(
            isset($state[$pair]) ? (array) $state[$pair] : array(),
            $partial,
            array('updated' => gmdate('Y-m-d H:i:s'))
        );
        Twtr_Settings::update_engine(array('glossary_state' => $state));
    }
}
