<?php
/**
 * Translation resolver: maps (context, source text, target language) to the
 * stored translation. Never calls the translation engine — unknown strings are recorded and
 * inserted as pending queue entries on shutdown.
 *
 * Priority: manual override → stored machine translation → original text.
 * An entry keeps showing its last valid translation while it is requeued
 * (e.g. after a glossary change).
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Resolver {

    /** @var array<string,array<string,object>> Request cache: "locale|context" => hash => row. */
    private static $groups = array();

    /** @var array<string,array> Missing strings discovered this request. */
    private static $misses = array();

    /** @var bool */
    private static $shutdown_hooked = false;

    /** @var bool Whether any lookup missed for the main request (used for noindex). */
    private static $had_miss = false;

    /** @var array<string,bool> Hashes of translations already returned this request,
     *  used to detect double-filtering (e.g. get_term applied twice on the same object). */
    private static $emitted = array();

    const MAX_DISCOVERIES_PER_REQUEST = 100;
    const CACHE_GROUP = 'twtr';

    /**
     * Translate a string for the current (or given) language.
     *
     * @param string      $text    Original text.
     * @param string      $context Stable context key.
     * @param string|null $locale  Language slug; defaults to the current one.
     * @return string
     */
    public static function translate($text, $context, $locale = null) {
        if (!is_string($text) || $text === '' || $context === '') {
            return $text;
        }
        if ($locale === null) {
            $locale = Twtr_Router::current_language();
        }
        if ($locale === '' || $locale === Twtr_Settings::default_lang()) {
            return $text;
        }

        $context = self::normalize_context($context);
        $group   = self::group($locale, $context);
        $hash    = md5($text);

        // Some WordPress filters run twice on the same object (get_term,
        // repeated the_title calls): if this text is a translation we already
        // returned for this context, pass it through untouched instead of
        // registering it as a new source string.
        if (isset(self::$emitted[$locale . '|' . $context . '|' . $hash])) {
            return $text;
        }

        if (isset($group[$hash])) {
            $row = $group[$hash];
            if ($row->translated_text !== null && $row->translated_text !== '') {
                self::$emitted[$locale . '|' . $context . '|' . md5($row->translated_text)] = true;
                return $row->translated_text;
            }
            // Entry exists but is not translated yet (pending/error).
            self::$had_miss = true;
            return $text;
        }

        self::record_miss($text, $context, $hash, $locale);
        return $text;
    }

    /**
     * Whether any string of this request had no ready translation. Used by
     * the SEO layer as a cheap signal.
     *
     * @return bool
     */
    public static function had_miss() {
        return self::$had_miss;
    }

    /**
     * Fetch (and memoize) all entries of a context group. Uses the object
     * cache when persistent, so warm requests may skip the DB entirely.
     *
     * @param string $locale
     * @param string $context
     * @return array<string,object>
     */
    private static function group($locale, $context) {
        $key = $locale . '|' . $context;
        if (isset(self::$groups[$key])) {
            return self::$groups[$key];
        }
        $cache_key = md5(get_current_blog_id() . '|' . $key);
        $cached    = wp_cache_get($cache_key, self::CACHE_GROUP);
        if (is_array($cached)) {
            self::$groups[$key] = $cached;
            return $cached;
        }
        $rows = Twtr_Storage::get_context_group($locale, $context);
        self::$groups[$key] = $rows;
        wp_cache_set($cache_key, $rows, self::CACHE_GROUP, 6 * HOUR_IN_SECONDS);
        return $rows;
    }

    /**
     * Invalidate the cached group of a context after a write.
     *
     * @param string $locale
     * @param string $context
     */
    public static function flush_group($locale, $context) {
        $key = $locale . '|' . self::normalize_context($context);
        unset(self::$groups[$key]);
        wp_cache_delete(md5(get_current_blog_id() . '|' . $key), self::CACHE_GROUP);
    }

    /**
     * Record an unknown string; it will be persisted as a pending entry on
     * shutdown (single batched INSERT IGNORE), then translated in background.
     */
    private static function record_miss($text, $context, $hash, $locale) {
        self::$had_miss = true;
        if (count(self::$misses) >= self::MAX_DISCOVERIES_PER_REQUEST) {
            return;
        }
        // Skip strings without letters (numbers, prices, separators).
        if (!preg_match('/\p{L}/u', $text)) {
            return;
        }
        $key = $locale . '|' . $context . '|' . $hash;
        if (isset(self::$misses[$key])) {
            return;
        }
        self::$misses[$key] = array(
            'context' => $context,
            'hash'    => $hash,
            'source'  => $text,
            'locale'  => $locale,
        );
        if (!self::$shutdown_hooked) {
            self::$shutdown_hooked = true;
            add_action('shutdown', array(__CLASS__, 'persist_misses'), 5);
        }
    }

    /**
     * Shutdown handler: persist discovered strings and kick the queue.
     */
    public static function persist_misses() {
        if (!self::$misses) {
            return;
        }
        $created = Twtr_Storage::insert_pending(array_values(self::$misses));
        foreach (self::$misses as $miss) {
            self::flush_group($miss['locale'], $miss['context']);
        }
        self::$misses = array();
        if ($created > 0) {
            twtr_queue();
            Twtr_Queue::schedule();
        }
    }

    /**
     * Context keys are limited to 191 chars (index constraint); overly long
     * keys are shortened deterministically.
     *
     * @param string $context
     * @return string
     */
    private static function normalize_context($context) {
        if (strlen($context) <= 191) {
            return $context;
        }
        return substr($context, 0, 158) . ':' . md5($context);
    }
}
