<?php
/**
 * OpenAI Chat Completions client, alternative translation engine.
 *
 * Same contract as Twtr_Google (translate_batch / test_connection /
 * last_error) so the queue can use either one interchangeably. Pure REST via
 * wp_remote_*: no SDK. Never called during a normal frontend visit — only
 * from the background queue, WP-CLI or explicit admin actions.
 *
 * Batches travel as JSON in and JSON out: the model receives an array of
 * segments and must return exactly as many translations, in order. The
 * global glossary cannot be a Google resource here, so the terms that
 * actually appear in the batch are injected into the system prompt.
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Openai {

    const TIMEOUT = 90;

    /** @var Twtr_Openai|null */
    private static $instance = null;

    /** @var string|null */
    private $last_error = null;

    /**
     * @return Twtr_Openai
     */
    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * @return string|null Last human-readable error (no secrets, no content).
     */
    public function last_error() {
        return $this->last_error;
    }

    /**
     * Translate a batch of HTML strings.
     *
     * @param string[] $texts       Source strings (HTML allowed).
     * @param string   $source_lang Language slug of the source.
     * @param string   $target_lang Language slug of the target.
     * @return string[]|WP_Error Translations in the same order.
     */
    public function translate_batch($texts, $source_lang, $target_lang) {
        $cfg = Twtr_Settings::openai_config();
        if ($cfg['api_key'] === '') {
            return new WP_Error('twtr_config', __('Chiave API OpenAI non configurata per questo sito.', 'tw-translate-plus'));
        }
        $texts = array_values($texts);
        $count = count($texts);
        if ($count === 0) {
            return array();
        }

        $payload = array(
            'model'           => $cfg['model'],
            'temperature'     => 0,
            'response_format' => array('type' => 'json_object'),
            'messages'        => array(
                array('role' => 'system', 'content' => $this->system_prompt($source_lang, $target_lang, $texts)),
                array('role' => 'user',   'content' => self::json(array('segments' => $texts))),
            ),
        );

        $resp = $this->request('POST', '/chat/completions', $payload);

        // Reasoning models reject a custom temperature: retry once with the
        // model default rather than failing the whole batch.
        if (is_wp_error($resp) && $resp->get_error_code() === 'twtr_http_400'
            && stripos($resp->get_error_message(), 'temperature') !== false) {
            unset($payload['temperature']);
            $resp = $this->request('POST', '/chat/completions', $payload);
        }
        if (is_wp_error($resp)) {
            return $resp;
        }

        if (isset($resp['choices'][0]['finish_reason']) && $resp['choices'][0]['finish_reason'] === 'length') {
            $this->last_error = __('Risposta OpenAI troncata: il testo supera la lunghezza massima che il modello può restituire in una volta. Prova un modello con output più ampio, oppure spezza il contenuto troppo lungo.', 'tw-translate-plus');
            return new WP_Error('twtr_response', $this->last_error);
        }

        $content = isset($resp['choices'][0]['message']['content']) ? (string) $resp['choices'][0]['message']['content'] : '';
        $decoded = json_decode($content, true);
        $list    = isset($decoded['segments']) && is_array($decoded['segments']) ? array_values($decoded['segments']) : null;

        if ($list === null || count($list) !== $count) {
            $this->last_error = sprintf(
                /* translators: 1: expected segment count, 2: received segment count. */
                __('Risposta OpenAI non allineata: attesi %1$d segmenti, ricevuti %2$d. La coda riproverà.', 'tw-translate-plus'),
                $count,
                is_array($list) ? count($list) : 0
            );
            return new WP_Error('twtr_response', $this->last_error);
        }

        $out = array();
        foreach ($list as $i => $value) {
            $out[$i] = is_scalar($value) ? (string) $value : '';
        }
        return $out;
    }

    /**
     * Lightweight connectivity/permission test.
     *
     * @return true|WP_Error
     */
    public function test_connection() {
        $result = $this->translate_batch(array('Buongiorno'), 'it', 'en');
        if (is_wp_error($result)) {
            return $result;
        }
        return true;
    }

    /**
     * Model ids available to this API key, filtered to the ones that can
     * plausibly hold a chat conversation.
     *
     * The filter is a deny-list, not an allow-list: OpenAI keeps publishing
     * new chat models and an allow-list would hide them until someone
     * updated the plugin — exactly the problem this feature exists to solve.
     * So anything that is not recognisably an embedding, audio, image or
     * moderation model stays in.
     *
     * @return string[]|WP_Error Sorted model ids.
     */
    public function list_models() {
        $cfg = Twtr_Settings::openai_config();
        if ($cfg['api_key'] === '') {
            return new WP_Error('twtr_config', __('Chiave API OpenAI non configurata: salvala prima di aggiornare l\'elenco dei modelli.', 'tw-translate-plus'));
        }
        $resp = $this->request('GET', '/models');
        if (is_wp_error($resp)) {
            return $resp;
        }
        if (empty($resp['data']) || !is_array($resp['data'])) {
            $this->last_error = __('Risposta OpenAI inattesa: elenco dei modelli vuoto.', 'tw-translate-plus');
            return new WP_Error('twtr_response', $this->last_error);
        }

        $models = array();
        foreach ($resp['data'] as $item) {
            $id = isset($item['id']) ? (string) $item['id'] : '';
            if ($id !== '' && !self::is_non_chat_model($id)) {
                $models[] = $id;
            }
        }
        $models = array_values(array_unique($models));
        sort($models, SORT_NATURAL);
        return $models;
    }

    /**
     * @param string $id Model id.
     * @return bool Whether the id is clearly not a chat model.
     */
    private static function is_non_chat_model($id) {
        $id = strtolower($id);
        $excluded = array(
            'embedding', 'moderation', 'tts', 'whisper', 'audio', 'realtime',
            'transcribe', 'dall-e', 'image', 'sora', 'guard',
            'davinci', 'babbage', 'curie', 'ada',
        );
        foreach ($excluded as $needle) {
            if (strpos($id, $needle) !== false) {
                return true;
            }
        }
        return false;
    }

    /**
     * Instructions for the model. Deliberately explicit about structure:
     * a lost or merged segment would silently shift every translation in the
     * batch onto the wrong row.
     *
     * @param string   $source_lang
     * @param string   $target_lang
     * @param string[] $texts
     * @return string
     */
    private function system_prompt($source_lang, $target_lang, $texts) {
        $source = Twtr_Settings::language_name($source_lang);
        $target = Twtr_Settings::language_name($target_lang);
        $count  = count($texts);

        $lines = array(
            sprintf('You are a professional translator working on a WordPress website. Translate from %1$s to %2$s.', $source, $target),
            '',
            'Output format (strict):',
            sprintf('- Reply with a JSON object {"segments": [...]} containing exactly %d strings, in the same order as the input.', $count),
            '- Never merge, split, drop, reorder or add segments. An empty input segment stays an empty output segment.',
            '- No explanations, no markdown fences, no comments.',
            '',
            'Translation rules:',
            '- Segments may contain HTML. Reproduce every tag, attribute, HTML entity, shortcode ([...]) and placeholder (%s, %1$s, {{...}}) exactly as received; translate only the human-readable text.',
            '- Preserve leading and trailing whitespace of each segment.',
            '- Do not translate URLs, file paths, e-mail addresses, CSS classes, brand and product names.',
            '- Keep the register and tone of the original; use the wording conventional for the target language on commercial websites.',
            '- Translate the text even when a segment is a single word or looks like a UI label.',
        );

        $glossary = $this->glossary_lines($target_lang, $texts);
        if ($glossary) {
            $lines[] = '';
            $lines[] = 'Glossary — these terms MUST be rendered exactly as specified (match is case-insensitive, keep the original capitalisation style of the sentence):';
            foreach ($glossary as $line) {
                $lines[] = $line;
            }
        }
        return implode("\n", $lines);
    }

    /**
     * Glossary entries worth spending prompt tokens on: only the terms that
     * actually occur in this batch, capped so a large glossary cannot
     * outgrow the content being translated.
     *
     * @param string   $target_lang
     * @param string[] $texts
     * @return string[]
     */
    private function glossary_lines($target_lang, $texts) {
        twtr_glossary();
        $terms = Twtr_Glossary::terms_for($target_lang);
        if (!$terms) {
            return array();
        }
        $haystack = implode("\n", $texts);
        $lines    = array();
        foreach ($terms as $source => $translation) {
            if (mb_stripos($haystack, (string) $source) === false) {
                continue;
            }
            $lines[] = sprintf('- "%s" -> "%s"', $source, $translation);
            if (count($lines) >= 60) {
                break;
            }
        }
        return $lines;
    }

    /**
     * Authenticated request with limited retry (backoff on 429/5xx/network).
     *
     * @param string     $method  HTTP method.
     * @param string     $path    Path under the API base, e.g. /chat/completions.
     * @param array|null $payload JSON body, null for a bodyless request.
     * @return array|WP_Error Decoded JSON response.
     */
    private function request($method, $path, $payload = null) {
        $cfg  = Twtr_Settings::openai_config();
        $url  = rtrim($cfg['base_url'], '/') . $path;
        $args = array(
            'method'  => $method,
            'timeout' => self::TIMEOUT,
            'headers' => array(
                'Authorization' => 'Bearer ' . $cfg['api_key'],
            ),
        );
        if ($payload !== null) {
            $args['headers']['Content-Type'] = 'application/json; charset=utf-8';
            $args['body'] = self::json($payload);
        }

        $attempts = 0;
        do {
            if ($attempts > 0) {
                usleep((int) (1000000 * pow(2, $attempts - 1))); // 1s, 2s backoff.
            }
            $attempts++;
            $resp = wp_remote_request($url, $args);
            $code = is_wp_error($resp) ? 0 : (int) wp_remote_retrieve_response_code($resp);
            $retryable = is_wp_error($resp) || $code === 429 || $code >= 500;
        } while ($retryable && $attempts < 3);

        if (is_wp_error($resp)) {
            $this->last_error = __('Errore di rete verso OpenAI (timeout o DNS).', 'tw-translate-plus');
            return new WP_Error('twtr_network', $this->last_error);
        }
        $decoded = json_decode(wp_remote_retrieve_body($resp), true);
        if ($code >= 200 && $code < 300) {
            $this->last_error = null;
            return is_array($decoded) ? $decoded : array();
        }

        $this->last_error = self::friendly_error($code, $decoded);
        return new WP_Error('twtr_http_' . $code, $this->last_error);
    }

    /**
     * Map API errors to actionable Italian messages, without echoing content.
     *
     * @param int        $code
     * @param array|null $decoded
     * @return string
     */
    public static function friendly_error($code, $decoded) {
        $api_msg  = isset($decoded['error']['message']) ? (string) $decoded['error']['message'] : '';
        $api_msg  = mb_substr($api_msg, 0, 200);
        $api_type = isset($decoded['error']['type']) ? (string) $decoded['error']['type'] : '';

        switch ($code) {
            case 400:
                if (stripos($api_msg, 'response_format') !== false) {
                    return sprintf(__('Il modello scelto non supporta le risposte in formato JSON: scegline uno più recente (es. gpt-4o-mini). Dettaglio: %s', 'tw-translate-plus'), $api_msg);
                }
                return sprintf(__('Richiesta non valida (verifica il nome del modello): %s', 'tw-translate-plus'), $api_msg);
            case 401:
                return __('Chiave API OpenAI non valida o revocata: generane una nuova dalla dashboard OpenAI.', 'tw-translate-plus');
            case 403:
                return sprintf(__('Accesso negato: la chiave non è abilitata a questo modello o al tuo paese. Dettaglio: %s', 'tw-translate-plus'), $api_msg);
            case 404:
                return sprintf(__('Modello non trovato: verifica il nome esatto e che il tuo account vi abbia accesso. Dettaglio: %s', 'tw-translate-plus'), $api_msg);
            case 429:
                if ($api_type === 'insufficient_quota' || stripos($api_msg, 'quota') !== false) {
                    return __('Credito OpenAI esaurito: aggiungi fondi al progetto (Billing) e riprova.', 'tw-translate-plus');
                }
                return __('Troppe richieste a OpenAI (rate limit): la coda riproverà automaticamente.', 'tw-translate-plus');
            default:
                return sprintf(__('Errore OpenAI (%1$d): %2$s', 'tw-translate-plus'), $code, $api_msg);
        }
    }

    /**
     * @param mixed $data
     * @return string JSON with readable unicode (smaller payload than \uXXXX).
     */
    private static function json($data) {
        return (string) wp_json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
}
