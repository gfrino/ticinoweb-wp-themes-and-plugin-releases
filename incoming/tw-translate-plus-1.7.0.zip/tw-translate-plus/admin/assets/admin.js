/* global twtrAdmin, jQuery */
/**
 * tW Translate Plus — admin interactions.
 * Inline translation editing, queue actions, connection test, glossary table.
 */
(function ($) {
    'use strict';

    function post(action, data) {
        return $.post(twtrAdmin.ajaxUrl, $.extend({
            action: action,
            _ajax_nonce: twtrAdmin.nonce
        }, data));
    }

    function feedback($el, message, ok) {
        $el.text(message)
            .removeClass('twtr-feedback-ok twtr-feedback-error')
            .addClass(ok ? 'twtr-feedback-ok' : 'twtr-feedback-error');
    }

    /* ------------------------------------------------ Translations: inline edit */

    $(document).on('click keydown', '.twtr-entries .twtr-view', function (e) {
        if (e.type === 'keydown' && e.key !== 'Enter' && e.key !== ' ') {
            return;
        }
        e.preventDefault();
        var $cell = $(this).closest('.twtr-target');
        $cell.find('.twtr-view').prop('hidden', true);
        $cell.find('.twtr-editor').prop('hidden', false).find('textarea').trigger('focus');
    });

    $(document).on('click', '.twtr-cancel', function () {
        var $cell = $(this).closest('.twtr-target');
        $cell.find('.twtr-editor').prop('hidden', true);
        $cell.find('.twtr-view').prop('hidden', false);
    });

    $(document).on('click', '.twtr-save', function () {
        var $btn = $(this),
            $row = $btn.closest('tr'),
            $cell = $btn.closest('.twtr-target'),
            text = $cell.find('textarea').val();

        $btn.prop('disabled', true).text(twtrAdmin.i18n.working);
        post('twtr_save_entry', { entry_id: $row.data('entry'), text: text })
            .done(function (res) {
                if (res && res.success) {
                    window.location.reload();
                } else {
                    window.alert((res && res.data && res.data.message) || twtrAdmin.i18n.error);
                    $btn.prop('disabled', false).text(twtrAdmin.i18n.saved);
                }
            })
            .fail(function () {
                window.alert(twtrAdmin.i18n.error);
                $btn.prop('disabled', false);
            });
    });

    $(document).on('click', '.twtr-restore', function () {
        var $row = $(this).closest('tr');
        post('twtr_restore_google', { entry_id: $row.data('entry') }).done(function (res) {
            if (res && res.success) {
                window.location.reload();
            } else {
                window.alert((res && res.data && res.data.message) || twtrAdmin.i18n.error);
            }
        });
    });

    $(document).on('click', '.twtr-recover', function () {
        var $cell = $(this).closest('.twtr-target');
        post('twtr_recover_previous', { entry_id: $(this).closest('tr').data('entry') }).done(function (res) {
            if (res && res.success && res.data.text) {
                $cell.find('textarea').val(res.data.text).trigger('focus');
            } else {
                window.alert((res && res.data && res.data.message) || twtrAdmin.i18n.error);
            }
        });
    });

    /* ------------------------------------------------------------- Status tab */

    $('#twtr-process-now').on('click', function () {
        var $btn = $(this), $fb = $('#twtr-status-feedback');
        $btn.prop('disabled', true);
        feedback($fb, twtrAdmin.i18n.working, true);
        post('twtr_process_now', {})
            .done(function (res) {
                feedback($fb, res && res.data ? res.data.message : twtrAdmin.i18n.error, res && res.success);
            })
            .fail(function () { feedback($fb, twtrAdmin.i18n.error, false); })
            .always(function () { $btn.prop('disabled', false); });
    });

    $('#twtr-index-site').on('click', function () {
        var $btn = $(this), $fb = $('#twtr-index-feedback'), scanned = 0, queued = 0;
        $btn.prop('disabled', true);
        feedback($fb, twtrAdmin.i18n.working, true);
        function stop(message, ok) {
            feedback($fb, message, ok);
            $btn.prop('disabled', false);
        }
        function step(phase, offset) {
            post('twtr_index_site', { phase: phase, offset: offset })
                .done(function (res) {
                    if (!res || !res.success || !res.data) {
                        stop(res && res.data && res.data.message ? res.data.message : twtrAdmin.i18n.error, false);
                        return;
                    }
                    scanned += res.data.scanned || 0;
                    queued  += res.data.queued || 0;
                    if (res.data.done) {
                        stop(twtrAdmin.i18n.indexDone.replace('%1$d', scanned).replace('%2$d', queued), true);
                        return;
                    }
                    feedback($fb, twtrAdmin.i18n.indexProgress.replace('%1$d', scanned).replace('%2$d', res.data.total), true);
                    step(res.data.phase, res.data.offset);
                })
                .fail(function () { stop(twtrAdmin.i18n.error, false); });
        }
        step('posts', 0);
    });

    $('#twtr-retry-errors').on('click', function () {
        var $fb = $('#twtr-status-feedback');
        feedback($fb, twtrAdmin.i18n.working, true);
        post('twtr_retry_errors', {}).done(function (res) {
            feedback($fb, res && res.data ? res.data.message : twtrAdmin.i18n.error, res && res.success);
        });
    });

    /* ------------------------------------------------------- Network: Google */

    /* Show only the settings of the selected translation engine. The other
       engine's fields stay in the DOM (and are still submitted, so saved
       credentials survive a switch), they are only hidden. */
    $('#twtr_provider').on('change', function () {
        var provider = $(this).val();
        $('.twtr-provider-panel').each(function () {
            $(this).prop('hidden', $(this).data('provider') !== provider);
        });
    });

    /* Refill the model dropdown from the account behind the saved API key.
       The current selection is preserved when the refreshed list still
       contains it, so a refresh never silently switches engine model. */
    $('#twtr-fetch-models').on('click', function () {
        var $btn = $(this),
            $fb = $('#twtr-models-feedback'),
            $select = $('#twtr_openai_model');

        $btn.prop('disabled', true);
        feedback($fb, twtrAdmin.i18n.working, true);
        post('twtr_fetch_openai_models', {})
            .done(function (res) {
                if (!res || !res.success || !res.data || !res.data.models) {
                    feedback($fb, res && res.data ? res.data.message : twtrAdmin.i18n.error, false);
                    return;
                }
                var previous = $select.val();
                $select.empty();
                $.each(res.data.models, function (i, model) {
                    $select.append($('<option></option>').attr('value', model).text(model));
                });
                $select.val($.inArray(previous, res.data.models) !== -1 ? previous : res.data.selected);
                feedback($fb, res.data.message, true);
            })
            .fail(function () { feedback($fb, twtrAdmin.i18n.error, false); })
            .always(function () { $btn.prop('disabled', false); });
    });

    $('#twtr-test-connection').on('click', function () {
        var $btn = $(this), $fb = $('#twtr-test-feedback');
        $btn.prop('disabled', true);
        feedback($fb, twtrAdmin.i18n.working, true);
        post('twtr_test_connection', {})
            .done(function (res) {
                feedback($fb, res && res.data ? res.data.message : twtrAdmin.i18n.error, res && res.success);
            })
            .fail(function () { feedback($fb, twtrAdmin.i18n.error, false); })
            .always(function () { $btn.prop('disabled', false); });
    });

    /* ----------------------------------------------------- Network: glossary */

    $(document).on('click', '.twtr-glossary .twtr-g-save', function () {
        var $row = $(this).closest('tr'),
            $fb = $('#twtr-glossary-feedback'),
            translations = {};

        $row.find('.twtr-g-lang').each(function () {
            translations[$(this).data('lang')] = $(this).val();
        });
        feedback($fb, twtrAdmin.i18n.working, true);
        post('twtr_save_glossary_term', {
            source: $row.find('.twtr-g-source').val(),
            active: $row.find('.twtr-g-active').is(':checked') ? 1 : '',
            translations: translations
        }).done(function (res) {
            if (res && res.success) {
                window.location.reload();
            } else {
                feedback($fb, (res && res.data && res.data.message) || twtrAdmin.i18n.error, false);
            }
        });
    });

    $(document).on('click', '.twtr-glossary .twtr-g-delete', function () {
        if (!window.confirm('Eliminare definitivamente questo termine?')) {
            return;
        }
        var $row = $(this).closest('tr');
        post('twtr_delete_glossary_term', { term_id: $row.data('term') }).done(function () {
            $row.remove();
        });
    });

    $('#twtr-glossary-sync').on('click', function () {
        var $btn = $(this), $fb = $('#twtr-glossary-feedback');
        $btn.prop('disabled', true);
        feedback($fb, twtrAdmin.i18n.working, true);
        post('twtr_glossary_sync', {})
            .done(function (res) {
                feedback($fb, res && res.data ? res.data.message : twtrAdmin.i18n.error, res && res.success);
            })
            .always(function () { $btn.prop('disabled', false); });
    });
})(jQuery);
