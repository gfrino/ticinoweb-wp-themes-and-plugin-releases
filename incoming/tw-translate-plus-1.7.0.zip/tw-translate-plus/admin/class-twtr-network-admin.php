<?php
/**
 * Configuration UI: two compact pages, "API traduzione" (engine choice,
 * credentials, daily limit, connection test) and "Glossario" (global
 * glossary inline table + this site's Google sync status).
 *
 * Since 1.7.0 "API traduzione" is PER SITE: engine, key and limit are stored
 * in the site's own twtr_engine option and translate only that site. A site
 * without its own key does not translate — there is no network fallback.
 * The page is a site-level submenu visible only to Super Admins on
 * Multisite (administrators on single-site). The glossary terms stay global
 * and also appear in Network Admin when the plugin is loaded there.
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Network_Admin {

    const SLUG          = 'tw-translate-plus-network';
    const SLUG_GLOSSARY = 'tw-translate-plus-glossary';

    /**
     * Register menus and handlers for the current context.
     */
    public static function init() {
        if (is_multisite()) {
            // Network admin menus: reachable only when the plugin is active on
            // the network's main site (or network-activated).
            add_action('network_admin_menu', array(__CLASS__, 'network_menu'));
        }
        // Site-level submenus: on multisite they are visible ONLY to Super
        // Admins. "API traduzione" configures the current site's engine.
        add_action('admin_menu', array(__CLASS__, 'site_menu'), 20);
        add_action('admin_post_twtr_save_google', array(__CLASS__, 'handle_save_google'));

        add_action('admin_enqueue_scripts', array('Twtr_Admin', 'assets'));
        add_action('wp_ajax_twtr_test_connection', array(__CLASS__, 'ajax_test_connection'));
        add_action('wp_ajax_twtr_fetch_openai_models', array(__CLASS__, 'ajax_fetch_openai_models'));
        add_action('wp_ajax_twtr_save_glossary_term', array(__CLASS__, 'ajax_save_glossary_term'));
        add_action('wp_ajax_twtr_delete_glossary_term', array(__CLASS__, 'ajax_delete_glossary_term'));
        add_action('wp_ajax_twtr_glossary_sync', array(__CLASS__, 'ajax_glossary_sync'));
    }

    /**
     * Network Admin: only the global glossary. Engine and keys are per site
     * and live in each site's "API traduzione" page.
     */
    public static function network_menu() {
        add_menu_page(
            'tW Translate Plus',
            'tW Translate',
            'manage_network_options',
            self::SLUG_GLOSSARY,
            array(__CLASS__, 'render_glossary'),
            'dashicons-translation',
            61
        );
    }

    public static function site_menu() {
        $cap = is_multisite() ? 'manage_network_options' : 'manage_options';
        add_submenu_page(
            Twtr_Admin::SLUG,
            __('Glossario', 'tw-translate-plus'),
            __('Glossario', 'tw-translate-plus'),
            $cap,
            self::SLUG_GLOSSARY,
            array(__CLASS__, 'render_glossary')
        );
        add_submenu_page(
            Twtr_Admin::SLUG,
            __('API traduzione', 'tw-translate-plus'),
            __('API traduzione', 'tw-translate-plus'),
            $cap,
            self::SLUG,
            array(__CLASS__, 'render_api')
        );
    }

    /**
     * @return bool Whether the current user may manage the global config.
     */
    private static function can_manage() {
        return is_multisite() ? current_user_can('manage_network_options') : current_user_can('manage_options');
    }

    /* ---------------------------------------------------- Page: API traduzione */

    public static function render_api() {
        if (!self::can_manage()) {
            wp_die(esc_html__('Permessi insufficienti.', 'tw-translate-plus'));
        }
        $n         = Twtr_Settings::network();
        $engine    = Twtr_Settings::engine();
        $cfg       = Twtr_Settings::google_config();
        $openai    = Twtr_Settings::openai_config();
        $cred_path = Twtr_Settings::credentials_path();
        $provider  = Twtr_Settings::provider();
        $form_url  = admin_url('admin-post.php');
        ?>
        <div class="wrap twtr-wrap">
            <?php Twtr_Admin::branding_header(); ?>
            <h1>tW Translate Plus — <?php esc_html_e('API traduzione', 'tw-translate-plus'); ?></h1>
            <?php settings_errors('twtr'); ?>

            <div class="twtr-card">
                <p>
                    <?php echo esc_html(sprintf(
                        /* translators: %s: site URL. */
                        __('Queste impostazioni valgono solo per questo sito (%s): la chiave inserita qui traduce soltanto questo sito, e nessun altro sito della rete la usa. Un sito senza la propria chiave non traduce.', 'tw-translate-plus'),
                        home_url('/')
                    )); ?>
                </p>
                <?php $missing = Twtr_Settings::engine_missing_reason(); ?>
                <?php if ($missing !== '') : ?>
                    <p class="twtr-warning"><?php echo esc_html($missing); ?></p>
                <?php endif; ?>
            </div>

            <form method="post" action="<?php echo esc_url($form_url); ?>">
                <input type="hidden" name="action" value="twtr_save_google" />
                <?php wp_nonce_field('twtr_save_google'); ?>

                <div class="twtr-card">
                    <h2><?php esc_html_e('Motore di traduzione', 'tw-translate-plus'); ?></h2>
                    <p class="description">
                        <?php esc_html_e('Scegli chi traduce i testi. Google Cloud Translation è un traduttore specializzato: velocissimo, si paga a carattere inviato e supporta i glossari ufficiali. OpenAI è un modello linguistico: più lento e in genere più caro, ma rende meglio frasi di marketing, modi di dire e testi in cui conta il contesto, e rispetta il glossario tramite istruzioni nel prompt. Puoi cambiare motore quando vuoi: le traduzioni già presenti restano intatte, solo le nuove useranno il motore selezionato.', 'tw-translate-plus'); ?>
                    </p>
                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row"><label for="twtr_provider"><?php esc_html_e('Motore', 'tw-translate-plus'); ?></label></th>
                            <td>
                                <select id="twtr_provider" name="provider">
                                    <?php foreach (Twtr_Settings::providers() as $slug => $label) : ?>
                                        <option value="<?php echo esc_attr($slug); ?>" <?php selected($provider, $slug); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <p class="description"><?php esc_html_e('Qui sotto compaiono solo le impostazioni del motore scelto. Le credenziali dell\'altro motore restano salvate e tornano disponibili se cambi idea.', 'tw-translate-plus'); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>

                <div class="twtr-card twtr-provider-panel" data-provider="google" <?php echo $provider === 'google' ? '' : 'hidden'; ?>>
                    <h2><?php esc_html_e('Google Cloud Translation', 'tw-translate-plus'); ?></h2>
                    <p class="description">
                        <?php esc_html_e('Prerequisito: un progetto Google Cloud con fatturazione attiva e la Cloud Translation API abilitata.', 'tw-translate-plus'); ?>
                        <a href="https://console.cloud.google.com/apis/library/translate.googleapis.com" target="_blank" rel="noopener"><?php esc_html_e('Abilita la Cloud Translation API →', 'tw-translate-plus'); ?></a>
                    </p>
                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row"><label for="twtr_project"><?php esc_html_e('Project ID', 'tw-translate-plus'); ?></label></th>
                            <td>
                                <input type="text" class="regular-text" id="twtr_project" name="project_id" value="<?php echo esc_attr($cfg['project_id']); ?>" placeholder="es. ticinoweb-translate" />
                                <p class="description">
                                    <?php esc_html_e('È l\'ID del progetto (non il nome né il numero): lo trovi nella dashboard del progetto, campo "ID progetto".', 'tw-translate-plus'); ?>
                                    <a href="https://console.cloud.google.com/projectselector2/home/dashboard" target="_blank" rel="noopener"><?php esc_html_e('Apri/crea un progetto →', 'tw-translate-plus'); ?></a>
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="twtr_location"><?php esc_html_e('Location', 'tw-translate-plus'); ?></label></th>
                            <td>
                                <input type="text" class="regular-text" id="twtr_location" name="location" value="<?php echo esc_attr($cfg['location']); ?>" />
                                <p class="description"><?php esc_html_e('Lascia us-central1 se non hai esigenze particolari: il glossario richiede una location regionale (non "global").', 'tw-translate-plus'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="twtr_credentials_json"><?php esc_html_e('Credenziali (service account JSON)', 'tw-translate-plus'); ?></label></th>
                            <td>
                                <p class="description" style="margin-bottom:8px;">
                                    <?php esc_html_e('Come ottenerle: 1) crea un service account; 2) assegnagli il ruolo "Cloud Translation API Editor" (più "Storage Admin" se userai il glossario); 3) nella scheda "Chiavi" crea una chiave di tipo JSON: il file si scarica sul tuo computer; 4) aprilo con un editor di testo e incolla qui sotto tutto il contenuto.', 'tw-translate-plus'); ?>
                                    <a href="https://console.cloud.google.com/iam-admin/serviceaccounts" target="_blank" rel="noopener"><?php esc_html_e('Apri Service Accounts →', 'tw-translate-plus'); ?></a>
                                </p>
                                <?php $source = Twtr_Settings::credentials_source(); ?>
                                    <?php if ($source === 'db') : ?>
                                        <p>
                                            <span class="dashicons dashicons-yes-alt" style="color:#1e7e34;"></span>
                                            <?php
                                            $stored = json_decode(Twtr_Settings::credentials_json(), true);
                                            $sa_email = is_array($stored) && !empty($stored['client_email']) ? $stored['client_email'] : '';
                                            echo esc_html(sprintf(__('Credenziali caricate (service account: %s). Per motivi di sicurezza non vengono mai rivisualizzate.', 'tw-translate-plus'), $sa_email));
                                            ?>
                                        </p>
                                        <label style="display:block; margin-bottom:8px;">
                                            <input type="checkbox" name="remove_credentials" value="1" />
                                            <?php esc_html_e('Rimuovi le credenziali salvate', 'tw-translate-plus'); ?>
                                        </label>
                                        <p class="description"><?php esc_html_e('Per sostituirle, incolla qui sotto il nuovo JSON:', 'tw-translate-plus'); ?></p>
                                    <?php endif; ?>
                                    <textarea id="twtr_credentials_json" name="credentials_json" rows="4" class="large-text code" placeholder='{ "type": "service_account", "project_id": "...", "private_key": "...", "client_email": "..." }' autocomplete="off"></textarea>
                                    <p class="description"><?php esc_html_e('Il contenuto viene salvato nelle impostazioni di questo sito e non mostrato mai più. Alternativa più sicura (opzionale): carica il file sul server fuori dalla cartella del sito e indica qui il suo percorso assoluto (es. /var/lib/secrets/twtr-sa.json) — ha priorità sul JSON incollato:', 'tw-translate-plus'); ?></p>
                                    <input type="text" class="large-text" id="twtr_credentials" name="credentials_path" value="<?php echo esc_attr($engine['credentials_path']); ?>" placeholder="<?php esc_attr_e('(opzionale) /percorso/assoluto/service-account.json', 'tw-translate-plus'); ?>" />
                                    <?php if ($cred_path !== '' && strpos($cred_path, rtrim(ABSPATH, '/')) === 0) : ?>
                                        <p class="twtr-warning"><?php esc_html_e('Attenzione: il file si trova dentro la webroot. Spostalo fuori o proteggilo dal web server.', 'tw-translate-plus'); ?></p>
                                    <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="twtr_bucket"><?php esc_html_e('Bucket GCS (per il glossario)', 'tw-translate-plus'); ?></label></th>
                            <td>
                                <input type="text" class="regular-text" id="twtr_bucket" name="gcs_bucket" value="<?php echo esc_attr($cfg['gcs_bucket']); ?>" placeholder="es. ticinoweb-glossari" />
                                <p class="description">
                                    <?php esc_html_e('Opzionale: serve SOLO se usi il glossario. È lo spazio di archiviazione su Google Cloud dove il plugin deposita i file CSV dei termini, da cui Google costruisce i glossari ufficiali. Scegli tu un nome (solo minuscole, numeri e trattini, senza gs://): se il bucket non esiste, il plugin lo crea automaticamente alla prima sincronizzazione — per questo il service account deve avere il ruolo "Storage Admin".', 'tw-translate-plus'); ?>
                                    <a href="https://console.cloud.google.com/storage/browser" target="_blank" rel="noopener"><?php esc_html_e('Apri Cloud Storage →', 'tw-translate-plus'); ?></a>
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>

                <div class="twtr-card twtr-provider-panel" data-provider="openai" <?php echo $provider === 'openai' ? '' : 'hidden'; ?>>
                    <h2><?php esc_html_e('OpenAI', 'tw-translate-plus'); ?></h2>
                    <p class="description">
                        <?php esc_html_e('Prerequisito: un account OpenAI con credito attivo sul progetto (la fatturazione è separata da ChatGPT: un abbonamento ChatGPT Plus NON include l\'uso delle API).', 'tw-translate-plus'); ?>
                        <a href="https://platform.openai.com/settings/organization/billing/overview" target="_blank" rel="noopener"><?php esc_html_e('Apri la fatturazione OpenAI →', 'tw-translate-plus'); ?></a>
                    </p>
                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row"><label for="twtr_openai_key"><?php esc_html_e('Chiave API', 'tw-translate-plus'); ?></label></th>
                            <td>
                                <?php $key_source = Twtr_Settings::openai_key_source(); ?>
                                    <?php if ($key_source === 'db') : ?>
                                        <p>
                                            <span class="dashicons dashicons-yes-alt" style="color:#1e7e34;"></span>
                                            <?php echo esc_html(sprintf(__('Chiave salvata (termina con …%s). Per motivi di sicurezza non viene mai rivisualizzata per intero.', 'tw-translate-plus'), Twtr_Settings::openai_key_hint())); ?>
                                        </p>
                                        <label style="display:block; margin-bottom:8px;">
                                            <input type="checkbox" name="remove_openai_key" value="1" />
                                            <?php esc_html_e('Rimuovi la chiave salvata', 'tw-translate-plus'); ?>
                                        </label>
                                        <p class="description"><?php esc_html_e('Per sostituirla, incolla qui sotto la nuova chiave:', 'tw-translate-plus'); ?></p>
                                    <?php endif; ?>
                                    <input type="password" class="large-text code" id="twtr_openai_key" name="openai_api_key" value="" autocomplete="off" placeholder="sk-…" />
                                    <p class="description">
                                        <?php esc_html_e('Creala in "API keys" sulla piattaforma OpenAI (con l\'account di chi paga le traduzioni di questo sito) e incollala qui: viene salvata nelle impostazioni di questo sito e non mostrata mai più.', 'tw-translate-plus'); ?>
                                        <a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener"><?php esc_html_e('Apri API keys →', 'tw-translate-plus'); ?></a>
                                    </p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="twtr_openai_model"><?php esc_html_e('Modello', 'tw-translate-plus'); ?></label></th>
                            <td>
                                <?php $model_choices = Twtr_Settings::openai_model_choices(); ?>
                                <select id="twtr_openai_model" name="openai_model" class="regular-text">
                                    <?php foreach ($model_choices as $model) : ?>
                                        <option value="<?php echo esc_attr($model); ?>" <?php selected($openai['model'], $model); ?>><?php echo esc_html($model); ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <button type="button" class="button" id="twtr-fetch-models"><?php esc_html_e('Aggiorna elenco dal tuo account', 'tw-translate-plus'); ?></button>
                                <span id="twtr-models-feedback" role="status"></span>
                                <p class="description">
                                    <?php esc_html_e('gpt-4o-mini è il compromesso consigliato: costa poco ed è più che sufficiente per tradurre. I modelli più grandi rendono meglio i testi creativi ma costano parecchio di più. Il modello deve supportare le risposte in formato JSON.', 'tw-translate-plus'); ?>
                                </p>
                                <p class="description">
                                    <?php esc_html_e('«Aggiorna elenco dal tuo account» interroga OpenAI e riempie il menu con i modelli che la tua chiave può davvero usare: se un modello viene ritirato, da qui ne scegli un altro senza aggiornare il plugin. Serve la chiave API già salvata. L\'elenco esclude i modelli non conversazionali (embedding, audio, immagini).', 'tw-translate-plus'); ?>
                                    <a href="https://platform.openai.com/docs/models" target="_blank" rel="noopener"><?php esc_html_e('Documentazione modelli →', 'tw-translate-plus'); ?></a>
                                </p>
                                <?php $fetched_at = Twtr_Settings::openai_models_fetched_at(); ?>
                                <?php if ($fetched_at !== '') : ?>
                                    <p class="description"><?php echo esc_html(sprintf(
                                        /* translators: 1: number of models, 2: date and time. */
                                        __('Elenco aggiornato il %2$s (%1$d modelli).', 'tw-translate-plus'),
                                        count($model_choices),
                                        wp_date(get_option('date_format') . ' H:i', strtotime($fetched_at . ' UTC'))
                                    )); ?></p>
                                <?php else : ?>
                                    <p class="description"><?php esc_html_e('Elenco mai aggiornato: qui sotto ci sono per ora solo i modelli predefiniti del plugin.', 'tw-translate-plus'); ?></p>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Glossario', 'tw-translate-plus'); ?></th>
                            <td>
                                <p class="description"><?php esc_html_e('Con OpenAI il glossario non richiede né bucket né sincronizzazione: i termini che compaiono nel testo da tradurre vengono passati al modello come istruzioni e valgono dalla traduzione successiva.', 'tw-translate-plus'); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>

                <div class="twtr-card">
                    <h2><?php esc_html_e('Limiti e dati', 'tw-translate-plus'); ?></h2>
                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row"><label for="twtr_quota"><?php esc_html_e('Limite caratteri/giorno', 'tw-translate-plus'); ?></label></th>
                            <td>
                                <input type="number" min="0" id="twtr_quota" name="daily_char_limit" value="<?php echo esc_attr(Twtr_Settings::daily_char_limit()); ?>" />
                                <p class="description"><?php echo esc_html(sprintf(__('Tetto di spesa di sicurezza di questo sito, sulla sua chiave, valido per entrambi i motori (Google fattura a caratteri inviati, OpenAI a token: i caratteri restano comunque una buona stima del volume). Gli altri siti hanno il proprio limite e il proprio contatore. 0 = nessun limite. Oggi usati da questo sito: %s caratteri.', 'tw-translate-plus'), number_format_i18n(Twtr_Settings::usage_today()))); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Dati alla disinstallazione', 'tw-translate-plus'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="delete_on_uninstall" value="1" <?php checked(!empty($n['delete_on_uninstall'])); ?> />
                                    <?php esc_html_e('Elimina traduzioni e glossario alla disinstallazione (default: conserva tutto). Impostazione di rete: vale per tutti i siti.', 'tw-translate-plus'); ?>
                                </label>
                            </td>
                        </tr>
                    </table>
                    <p>
                        <?php submit_button(__('Salva configurazione', 'tw-translate-plus'), 'primary', 'submit', false); ?>
                        <button type="button" class="button" id="twtr-test-connection"><?php esc_html_e('Test connessione', 'tw-translate-plus'); ?></button>
                        <span id="twtr-test-feedback" role="status"></span>
                    </p>
                    <p class="description"><?php esc_html_e('Il test traduce una parola con il motore attualmente salvato: salva prima di testare se hai appena cambiato motore o credenziali.', 'tw-translate-plus'); ?></p>
                </div>
            </form>
            <?php Twtr_Admin::license_footer(); ?>
        </div>
        <?php
    }

    /* -------------------------------------------------------- Page: Glossario */

    public static function render_glossary() {
        if (!self::can_manage()) {
            wp_die(esc_html__('Permessi insufficienti.', 'tw-translate-plus'));
        }
        twtr_glossary();
        $terms = Twtr_Glossary::all(isset($_GET['gsearch']) ? sanitize_text_field(wp_unslash($_GET['gsearch'])) : ''); // phpcs:ignore WordPress.Security.NonceVerification -- read-only filter.
        $glossary_langs = self::glossary_languages();
        $remote_sync    = Twtr_Glossary::remote_sync_supported();
        ?>
        <div class="wrap twtr-wrap">
            <?php Twtr_Admin::branding_header(); ?>
            <h1>tW Translate Plus — <?php esc_html_e('Glossario globale', 'tw-translate-plus'); ?></h1>
            <?php settings_errors('twtr'); ?>

            <div class="twtr-card">
                <h2><?php esc_html_e('A cosa serve il glossario', 'tw-translate-plus'); ?></h2>
                <p class="description">
                    <?php echo esc_html(sprintf(
                        /* translators: %s: translation engine name. */
                        __('Il glossario impone al motore di traduzione (ora: %s) una traduzione fissa per determinati termini, su tutti i siti della rete. Esempi tipici: nomi di brand e prodotti che non vanno mai tradotti ("Ambrosini" → "Ambrosini"), oppure termini tecnici che vuoi rendere sempre nello stesso modo ("ricarica munizioni" → "Wiederladen"). Senza glossario il motore decide di volta in volta e può essere incoerente.', 'tw-translate-plus'),
                        Twtr_Settings::provider_label()
                    )); ?>
                </p>
                <p class="description">
                    <?php if ($remote_sync) : ?>
                        <?php esc_html_e('Come funziona con Google: 1) aggiungi un termine nella tabella qui sotto con le sue traduzioni fisse; 2) premi "Sincronizza con Google" (o attendi il prossimo ciclo automatico): il plugin carica i termini come file CSV nel bucket Cloud Storage e crea i glossari ufficiali Google, uno per coppia di lingue; 3) da quel momento ogni nuova traduzione automatica rispetta il glossario, e le traduzioni automatiche esistenti che contengono il termine vengono rigenerate in background. Le traduzioni manuali non vengono MAI toccate.', 'tw-translate-plus'); ?>
                    <?php else : ?>
                        <?php esc_html_e('Come funziona con OpenAI: aggiungi un termine nella tabella qui sotto con le sue traduzioni fisse e sei a posto — non serve sincronizzare nulla. I termini che compaiono in un testo vengono passati al modello come istruzioni vincolanti al momento della traduzione, quindi valgono già dalla traduzione successiva; le traduzioni automatiche esistenti che contengono il termine vengono rigenerate in background. Le traduzioni manuali non vengono MAI toccate.', 'tw-translate-plus'); ?>
                    <?php endif; ?>
                </p>

                <form method="get" class="twtr-filters">
                    <input type="hidden" name="page" value="<?php echo esc_attr(self::SLUG_GLOSSARY); ?>" />
                    <input type="search" name="gsearch" value="<?php echo isset($_GET['gsearch']) ? esc_attr(sanitize_text_field(wp_unslash($_GET['gsearch']))) : ''; // phpcs:ignore WordPress.Security.NonceVerification ?>" placeholder="<?php esc_attr_e('Cerca termine…', 'tw-translate-plus'); ?>" />
                    <?php submit_button(__('Cerca', 'tw-translate-plus'), 'secondary', '', false); ?>
                    <?php if ($remote_sync) : ?>
                        <button type="button" class="button" id="twtr-glossary-sync"><?php esc_html_e('Sincronizza con Google', 'tw-translate-plus'); ?></button>
                    <?php endif; ?>
                    <span id="twtr-glossary-feedback" role="status"></span>
                </form>

                <table class="widefat striped twtr-glossary" data-langs="<?php echo esc_attr(implode(',', $glossary_langs)); ?>">
                    <thead>
                        <tr>
                            <th><?php esc_html_e('Termine originale', 'tw-translate-plus'); ?></th>
                            <?php foreach ($glossary_langs as $lang) : ?>
                                <th><?php echo esc_html(strtoupper($lang)); ?></th>
                            <?php endforeach; ?>
                            <th><?php esc_html_e('Attivo', 'tw-translate-plus'); ?></th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="twtr-glossary-new">
                            <td><input type="text" class="twtr-g-source" placeholder="<?php esc_attr_e('Nuovo termine…', 'tw-translate-plus'); ?>" /></td>
                            <?php foreach ($glossary_langs as $lang) : ?>
                                <td><input type="text" class="twtr-g-lang" data-lang="<?php echo esc_attr($lang); ?>" /></td>
                            <?php endforeach; ?>
                            <td><input type="checkbox" class="twtr-g-active" checked /></td>
                            <td><button type="button" class="button button-primary twtr-g-save"><?php esc_html_e('Aggiungi', 'tw-translate-plus'); ?></button></td>
                        </tr>
                        <?php foreach ($terms as $term) :
                            $tr = (array) json_decode($term->translations, true); ?>
                            <tr data-term="<?php echo esc_attr($term->id); ?>">
                                <td><input type="text" class="twtr-g-source" value="<?php echo esc_attr($term->source_text); ?>" readonly /></td>
                                <?php foreach ($glossary_langs as $lang) : ?>
                                    <td><input type="text" class="twtr-g-lang" data-lang="<?php echo esc_attr($lang); ?>" value="<?php echo isset($tr[$lang]) ? esc_attr($tr[$lang]) : ''; ?>" /></td>
                                <?php endforeach; ?>
                                <td><input type="checkbox" class="twtr-g-active" <?php checked((int) $term->active === 1); ?> /></td>
                                <td>
                                    <button type="button" class="button twtr-g-save"><?php esc_html_e('Salva', 'tw-translate-plus'); ?></button>
                                    <button type="button" class="button-link-delete twtr-g-delete" aria-label="<?php esc_attr_e('Elimina termine', 'tw-translate-plus'); ?>">&times;</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <p class="description"><?php esc_html_e('Le colonne mostrano le lingue attivate. Le traduzioni già inserite in altre lingue restano salvate anche se la colonna non è visibile.', 'tw-translate-plus'); ?></p>

                <?php if ($remote_sync) : ?>
                    <?php self::render_sync_status(); ?>
                <?php endif; ?>
            </div>
            <?php Twtr_Admin::license_footer(); ?>
        </div>
        <?php
    }

    /**
     * Language columns for the glossary table: the languages actually
     * enabled on the current site (site context), falling back to the union
     * of languages already present in saved glossary terms plus the catalog
     * defaults when nothing is enabled yet. Never includes the default
     * language, capped at 6 to keep the inline table usable.
     *
     * @return string[]
     */
    private static function glossary_languages() {
        $default = Twtr_Settings::default_lang();
        $langs   = Twtr_Settings::extra_languages();

        // Keep columns for languages already used by saved terms.
        foreach (Twtr_Glossary::all() as $term) {
            foreach (array_keys((array) json_decode($term->translations, true)) as $used) {
                if ($used !== $default && !in_array($used, $langs, true)) {
                    $langs[] = $used;
                }
            }
        }
        if (!$langs) {
            $langs = array_values(array_diff(array_keys(Twtr_Settings::catalog()), array($default)));
        }
        return array_slice($langs, 0, 6);
    }

    /**
     * Google glossary resources of the CURRENT site (they live in the site's
     * own Google project).
     */
    private static function render_sync_status() {
        $state = (array) Twtr_Settings::engine()['glossary_state'];
        if (!$state) {
            return;
        }
        ?>
        <h3><?php esc_html_e('Stato sincronizzazione glossari Google di questo sito', 'tw-translate-plus'); ?></h3>
        <table class="widefat striped twtr-sync-status">
            <thead><tr><th><?php esc_html_e('Coppia', 'tw-translate-plus'); ?></th><th><?php esc_html_e('Stato', 'tw-translate-plus'); ?></th><th><?php esc_html_e('Dettaglio', 'tw-translate-plus'); ?></th></tr></thead>
            <tbody>
            <?php foreach ($state as $pair => $info) :
                $status = isset($info['status']) ? $info['status'] : '';
                $labels = array(
                    'ready'   => __('Pronto', 'tw-translate-plus'),
                    'syncing' => __('In sincronizzazione', 'tw-translate-plus'),
                    'dirty'   => __('Da sincronizzare', 'tw-translate-plus'),
                    'empty'   => __('Nessun termine', 'tw-translate-plus'),
                    'error'   => __('Errore', 'tw-translate-plus'),
                ); ?>
                <tr>
                    <td><code><?php echo esc_html($pair); ?></code></td>
                    <td><span class="twtr-badge twtr-badge-<?php echo esc_attr($status === 'ready' ? 'ready' : ($status === 'error' ? 'error' : 'pending')); ?>"><?php echo esc_html(isset($labels[$status]) ? $labels[$status] : $status); ?></span></td>
                    <td><?php echo !empty($info['error']) ? esc_html($info['error']) : ''; ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php
    }

    /**
     * Save the current site's engine settings. Only the network-wide
     * uninstall policy goes to the network option.
     */
    public static function handle_save_google() {
        if (!self::can_manage()) {
            wp_die(esc_html__('Permessi insufficienti.', 'tw-translate-plus'));
        }
        check_admin_referer('twtr_save_google');

        Twtr_Settings::update_network(array(
            'delete_on_uninstall' => !empty($_POST['delete_on_uninstall']),
        ));

        $partial = array(
            'daily_char_limit' => isset($_POST['daily_char_limit']) ? max(0, (int) $_POST['daily_char_limit']) : 500000,
        );
        if (isset($_POST['provider'])) {
            $provider = sanitize_key(wp_unslash($_POST['provider']));
            if (isset(Twtr_Settings::providers()[$provider])) {
                $partial['provider'] = $provider;
            }
        }
        if (isset($_POST['openai_model'])) {
            // The field is a dropdown built from openai_model_choices(), so
            // anything outside that list is a stale or tampered POST: keep
            // the stored model rather than writing a name that would only
            // fail at the first translation.
            $model = sanitize_text_field(wp_unslash($_POST['openai_model']));
            if ($model !== '' && in_array($model, Twtr_Settings::openai_model_choices(), true)) {
                $partial['openai_model'] = $model;
            }
        }
        if (!empty($_POST['remove_openai_key'])) {
            $partial['openai_api_key'] = '';
            // The model list belongs to the removed key's account.
            $partial['openai_models']    = array();
            $partial['openai_models_at'] = '';
        }
        // Never sanitized through sanitize_text_field: the key is opaque
        // and must survive byte for byte. Stored in this site's option,
        // never echoed back to any page or log.
        if (!empty($_POST['openai_api_key'])) {
            $key = trim((string) wp_unslash($_POST['openai_api_key'])); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- opaque credential, validated below.
            // Deliberately loose: the key is opaque and OpenAI has changed
            // its format before. This only catches a truncated or
            // whitespace-mangled paste.
            if (preg_match('/^\S{20,}$/', $key)) {
                $partial['openai_api_key'] = $key;
            } else {
                add_settings_error('twtr', 'twtr_bad_key', __('La chiave OpenAI incollata non ha un formato valido (attesa una stringa lunga senza spazi, tipicamente con prefisso sk-): chiave NON salvata.', 'tw-translate-plus'));
                set_transient('settings_errors', get_settings_errors(), 30);
            }
        }
        if (isset($_POST['project_id'])) {
            $partial['project_id'] = sanitize_text_field(wp_unslash($_POST['project_id']));
        }
        if (isset($_POST['location'])) {
            $partial['location'] = sanitize_text_field(wp_unslash($_POST['location']));
        }
        if (isset($_POST['gcs_bucket'])) {
            $partial['gcs_bucket'] = sanitize_text_field(wp_unslash($_POST['gcs_bucket']));
        }
        if (isset($_POST['credentials_path'])) {
            $partial['credentials_path'] = sanitize_text_field(wp_unslash($_POST['credentials_path']));
        }
        if (!empty($_POST['remove_credentials'])) {
            $partial['credentials_json'] = '';
        }
        // Pasted service-account JSON: validated, stored in this site's
        // option, never echoed back to any page or log.
        if (!empty($_POST['credentials_json'])) {
            $raw  = trim((string) wp_unslash($_POST['credentials_json'])); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- JSON validated below, sanitize_* would corrupt the key.
            $data = json_decode($raw, true);
            if (is_array($data) && !empty($data['client_email']) && !empty($data['private_key']) && !empty($data['token_uri'])) {
                $partial['credentials_json'] = wp_json_encode($data);
                // Convenience: derive the Project ID from the key if the field was left empty.
                if (empty($partial['project_id']) && !empty($data['project_id'])) {
                    $partial['project_id'] = sanitize_text_field($data['project_id']);
                }
            } else {
                add_settings_error('twtr', 'twtr_bad_json', __('Il JSON incollato non è un service account valido (devono esserci client_email, private_key e token_uri): credenziali NON salvate.', 'tw-translate-plus'));
                set_transient('settings_errors', get_settings_errors(), 30);
            }
        }
        Twtr_Settings::update_engine($partial);
        delete_transient('twtr_google_token');

        // New credentials may unblock a queue that was parked for lack of a key.
        twtr_queue();
        Twtr_Queue::schedule();

        $redirect = wp_get_referer();
        if (!$redirect) {
            $redirect = admin_url('admin.php?page=' . self::SLUG);
        }
        wp_safe_redirect(add_query_arg('settings-updated', '1', $redirect));
        exit;
    }

    /* ---------------------------------------------------------------------- AJAX */

    private static function ajax_guard() {
        check_ajax_referer('twtr_admin');
        if (!self::can_manage()) {
            wp_send_json_error(array('message' => __('Permessi insufficienti.', 'tw-translate-plus')), 403);
        }
    }

    public static function ajax_test_connection() {
        self::ajax_guard();
        $result = twtr_translator()->test_connection();
        if ($result === true) {
            wp_send_json_success(array('message' => sprintf(
                /* translators: %s: translation engine name. */
                __('Connessione riuscita: la traduzione di prova con %s ha risposto correttamente.', 'tw-translate-plus'),
                Twtr_Settings::provider_label()
            )));
        }
        wp_send_json_error(array('message' => $result->get_error_message()));
    }

    /**
     * Refresh the model dropdown from the OpenAI account behind the saved
     * key. Purely a convenience: it stores the list, it does not change
     * which model is selected.
     */
    public static function ajax_fetch_openai_models() {
        self::ajax_guard();
        $models = twtr_openai()->list_models();
        if (is_wp_error($models)) {
            wp_send_json_error(array('message' => $models->get_error_message()));
        }
        if (!$models) {
            wp_send_json_error(array('message' => __('Nessun modello conversazionale disponibile per questa chiave.', 'tw-translate-plus')));
        }
        Twtr_Settings::update_openai_models($models);
        wp_send_json_success(array(
            'models'   => Twtr_Settings::openai_model_choices(),
            'selected' => Twtr_Settings::openai_config()['model'],
            'message'  => sprintf(
                /* translators: %d: number of models found. */
                _n('%d modello trovato.', '%d modelli trovati.', count($models), 'tw-translate-plus'),
                count($models)
            ),
        ));
    }

    public static function ajax_save_glossary_term() {
        self::ajax_guard();
        twtr_glossary();
        $source       = isset($_POST['source']) ? sanitize_text_field(wp_unslash($_POST['source'])) : '';
        $active       = !empty($_POST['active']);
        $translations = array();
        if (isset($_POST['translations']) && is_array($_POST['translations'])) {
            foreach (wp_unslash($_POST['translations']) as $lang => $value) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitized below.
                $translations[sanitize_key($lang)] = sanitize_text_field($value);
            }
        }
        // Merge with stored translations so hidden language columns are kept.
        if ($source !== '') {
            foreach (Twtr_Glossary::all($source) as $existing) {
                if ($existing->source_text === $source) {
                    $stored = (array) json_decode($existing->translations, true);
                    foreach ($stored as $lang => $value) {
                        if (!array_key_exists($lang, $translations)) {
                            $translations[$lang] = $value;
                        }
                    }
                    break;
                }
            }
        }
        $result = Twtr_Glossary::save_term($source, $translations, $active);
        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()));
        }
        Twtr_Cache::purge_all();
        wp_send_json_success(array('message' => __('Termine salvato. Le traduzioni interessate verranno rigenerate in background.', 'tw-translate-plus')));
    }

    public static function ajax_delete_glossary_term() {
        self::ajax_guard();
        twtr_glossary();
        $id = isset($_POST['term_id']) ? (int) $_POST['term_id'] : 0;
        if ($id > 0) {
            Twtr_Glossary::delete_term($id);
            Twtr_Cache::purge_all();
        }
        wp_send_json_success(array('message' => __('Termine eliminato.', 'tw-translate-plus')));
    }

    public static function ajax_glossary_sync() {
        self::ajax_guard();
        twtr_glossary();
        if (!Twtr_Glossary::remote_sync_supported()) {
            wp_send_json_success(array('message' => __('Con il motore OpenAI non serve sincronizzare: i termini sono già attivi.', 'tw-translate-plus')));
        }
        Twtr_Glossary::refresh_sync();
        wp_send_json_success(array('message' => __('Sincronizzazione avviata: ricarica la pagina tra qualche minuto per lo stato aggiornato.', 'tw-translate-plus')));
    }
}
