<?php
/**
 * Product archive for Oasi delle Spezie.
 *
 * @package OasiDelleSpezieChild
 * @version 8.6.0
 */

defined( 'ABSPATH' ) || exit;

get_header( 'shop' );

$filters = oasi_shop_get_current_filters();
?>
<section class="oasi-shop" data-oasi-shop>
	<header class="oasi-shop__intro">
		<div class="oasi-container">
			<?php woocommerce_breadcrumb(); ?>
			<p class="oasi-shop__eyebrow"><?php esc_html_e( 'Il catalogo del laboratorio', 'oasidellespezie-child-theme' ); ?></p>
			<h1><?php woocommerce_page_title(); ?></h1>
			<?php do_action( 'woocommerce_archive_description' ); ?>
		</div>
	</header>

	<div class="oasi-shop__toolbar oasi-container">
		<?php oasi_shop_render_toolbar( $filters ); ?>
	</div>

	<div class="oasi-shop__layout oasi-container">
		<div class="oasi-shop__drawer-overlay" data-oasi-filter-close aria-hidden="true"></div>
		<aside class="oasi-shop__filters" id="oasi-shop-filters" aria-labelledby="oasi-shop-filter-title" data-oasi-filter-drawer>
			<?php oasi_shop_render_filters( $filters ); ?>
		</aside>

		<section class="oasi-shop__results" data-oasi-shop-results aria-live="polite" aria-busy="false">
			<?php oasi_shop_render_results(); ?>
		</section>
	</div>
</section>
<?php
get_footer( 'shop' );
