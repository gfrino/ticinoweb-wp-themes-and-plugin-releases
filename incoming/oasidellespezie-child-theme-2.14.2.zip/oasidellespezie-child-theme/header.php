<?php
/**
 * Header template for Oasi delle Spezie Child Theme.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$logo_url    = oasi_get_master_logo_url();
$cart_count  = ( function_exists( 'WC' ) && WC()->cart ) ? WC()->cart->get_cart_contents_count() : 0;
$cart_url    = function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : home_url( '/carrello/' );
$account_url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/mio-account/' );

$contact_top = function_exists( 'oasi_get_contact_data' ) ? oasi_get_contact_data() : array();
$top_phone   = $contact_top['phone'] ?? '+41 91 859 05 32';
$top_tel     = $contact_top['phone_tel'] ?? '+41918590532';
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip-link screen-reader-text" href="#main-content">
	<?php esc_html_e( 'Vai al contenuto principale', 'oasidellespezie-child-theme' ); ?>
</a>

<header class="<?php echo esc_attr( implode( ' ', oasi_get_header_class_names() ) ); ?>" id="oasi-site-header">
	<!-- Topbar: Free shipping & live assistance -->
	<div class="oasi-header__topbar">
		<div class="oasi-container oasi-header__topbar-inner">
			<div class="oasi-header__topbar-item">
				<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="1" y="3" width="15" height="13"></rect><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon><circle cx="5.5" cy="18.5" r="2.5"></circle><circle cx="18.5" cy="18.5" r="2.5"></circle></svg>
				<?php $oasi_free_from = ( function_exists( 'oasi_free_shipping_threshold' ) ? oasi_free_shipping_threshold() : '' ); ?>
				<span><?php echo esc_html( '' !== $oasi_free_from ? sprintf( /* translators: %s: amount in CHF. */ __( 'Spedizione gratuita in Svizzera da CHF %s', 'oasidellespezie-child-theme' ), $oasi_free_from ) : __( 'Spedizioni in tutta la Svizzera', 'oasidellespezie-child-theme' ) ); ?></span>
			</div>
			<div class="oasi-header__topbar-item oasi-header__topbar-item--right">
				<a href="tel:<?php echo esc_attr( $top_tel ); ?>" class="oasi-header__topbar-link">
					<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
					<span><?php esc_html_e( 'Assistenza:', 'oasidellespezie-child-theme' ); ?> <?php echo esc_html( $top_phone ); ?></span>
				</a>
			</div>
		</div>
	</div>

	<!-- Main Header -->
	<div class="oasi-header__main">
		<div class="oasi-container oasi-header__inner">
			<div class="oasi-header__branding">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" class="oasi-header__logo-link">
					<img src="<?php echo esc_url( $logo_url ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" class="oasi-header__logo" width="220" height="97">
				</a>
			</div>

			<nav class="oasi-header__nav" id="oasi-main-nav" aria-label="<?php esc_attr_e( 'Menu principale', 'oasidellespezie-child-theme' ); ?>">
				<?php
				$menu_args = array(
					'theme_location' => 'primary',
					'menu_class'     => 'oasi-nav-list',
					'container'      => false,
					'fallback_cb'    => function() {
						wp_nav_menu(
							array(
								'theme_location' => 'menu-1',
								'menu_class'     => 'oasi-nav-list',
								'container'      => false,
							)
						);
					},
				);
				wp_nav_menu( $menu_args );
				?>
			</nav>

			<div class="oasi-header__actions">
				<?php
				if ( function_exists( 'oasi_render_language_switcher' ) ) {
					oasi_render_language_switcher( 'header' );
				}
				?>

				<a href="<?php echo esc_url( $account_url ); ?>" class="oasi-header__action-btn" aria-label="<?php esc_attr_e( 'Mio Account', 'oasidellespezie-child-theme' ); ?>" title="<?php esc_attr_e( 'Mio Account', 'oasidellespezie-child-theme' ); ?>">
					<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
				</a>

				<a href="<?php echo esc_url( $cart_url ); ?>" class="oasi-header__action-btn oasi-header__cart-btn" aria-label="<?php echo esc_attr( sprintf( __( 'Carrello: %d articoli', 'oasidellespezie-child-theme' ), $cart_count ) ); ?>">
					<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
					<span class="oasi-header__cart-count" id="oasi-cart-count"><?php echo esc_html( (string) $cart_count ); ?></span>
				</a>

				<button type="button" class="oasi-header__mobile-toggle" id="oasi-mobile-toggle" aria-expanded="false" aria-controls="oasi-mobile-drawer" aria-label="<?php esc_attr_e( 'Apri menu di navigazione', 'oasidellespezie-child-theme' ); ?>">
					<span class="oasi-header__hamburger-bar"></span>
					<span class="oasi-header__hamburger-bar"></span>
					<span class="oasi-header__hamburger-bar"></span>
				</button>
			</div>
		</div>
	</div>

	<?php
	// Render Desktop Mega Menu "Spice Atlas"
	if ( function_exists( 'oasi_render_desktop_megamenu' ) ) {
		oasi_render_desktop_megamenu();
	}
	?>
</header>

<?php
// Render Mobile Sliding Drawer Navigation directly under viewport (outside <header> to avoid transform/filter trap)
if ( function_exists( 'oasi_render_mobile_drawer' ) ) {
	oasi_render_mobile_drawer();
}
?>

<main id="main-content" class="oasi-site-main">
