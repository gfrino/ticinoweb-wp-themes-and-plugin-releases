<?php
/**
 * Premium editorial footer for Oasi delle Spezie.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$logo_url          = oasi_get_master_logo_url();
$bio_inspecta_logo = wp_get_attachment_image_url( 61699, 'medium' );
if ( ! $bio_inspecta_logo ) {
	$bio_inspecta_logo = oasi_upload_url( '2022/02/logo-avec-label-bio-inspecta.jpg' );
}

$contact         = function_exists( 'oasi_get_contact_data' ) ? oasi_get_contact_data() : array();
$quick_links     = function_exists( 'oasi_footer_get_quick_links' ) ? oasi_footer_get_quick_links() : array();
$payment_methods = function_exists( 'oasi_footer_get_payment_methods' ) ? oasi_footer_get_payment_methods() : array();
$certificate_url = function_exists( 'oasi_legal_get_page_url' ) ? oasi_legal_get_page_url( 'certificazione' ) : home_url( '/certificazione/' );
$opening_hours    = function_exists( 'oasi_footer_group_opening_hours' )
	? oasi_footer_group_opening_hours( is_array( $contact['hours_days'] ?? null ) ? $contact['hours_days'] : array() )
	: array();
?>
</main><?php // Close #main-content. ?>

<footer class="oasi-footer" id="oasi-site-footer">
	<div class="oasi-footer__bg-overlay" aria-hidden="true"></div>

	<div class="oasi-container oasi-footer__inner">
		<div class="oasi-footer__layout">
			<section class="oasi-footer__brand" aria-labelledby="oasi-footer-brand-title">
				<p class="oasi-footer__eyebrow">Laboratorio artigianale svizzero</p>
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" class="oasi-footer__logo-link" id="oasi-footer-brand-title">
					<img src="<?php echo esc_url( $logo_url ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" class="oasi-footer__logo" width="220" height="97" loading="lazy">
				</a>
				<p class="oasi-footer__about-text">
					Spezie, miscele e specialità selezionate e lavorate nel nostro laboratorio ticinese, con cura artigianale e attenzione alla qualità.
				</p>

				<address class="oasi-footer__contact-info">
					<p class="oasi-footer__contact-item oasi-footer__contact-item--address">
						<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
						<a href="<?php echo esc_url( $contact['maps_url'] ?? 'https://maps.google.com/?q=Alla+Monda+12%2C+6515+Gudo' ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $contact['address'] ?? 'Alla Monda 12, 6515 Gudo' ); ?></a>
					</p>
					<p class="oasi-footer__contact-item">
						<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
						<a href="<?php echo esc_url( 'tel:' . ( $contact['phone_tel'] ?? '+41918590532' ) ); ?>"><?php echo esc_html( $contact['phone'] ?? '+41 91 859 05 32' ); ?></a>
					</p>
					<p class="oasi-footer__contact-item">
						<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"></rect><path d="m3 7 9 6 9-6"></path></svg>
						<a href="<?php echo esc_url( 'mailto:' . ( $contact['email'] ?? 'info@oasidellespezie.ch' ) ); ?>"><?php echo esc_html( $contact['email'] ?? 'info@oasidellespezie.ch' ); ?></a>
					</p>
					<?php if ( $opening_hours ) : ?>
						<div class="oasi-footer__contact-item oasi-footer__contact-item--hours">
							<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"></circle><path d="M12 7v5l3 2"></path></svg>
							<div class="oasi-footer__hours">
								<span class="screen-reader-text"><?php esc_html_e( 'Orari di apertura', 'oasidellespezie-child-theme' ); ?></span>
								<dl class="oasi-footer__hours-list">
									<?php foreach ( $opening_hours as $opening_hour ) : ?>
										<div class="oasi-footer__hours-row">
											<dt><?php echo esc_html( $opening_hour['label'] ); ?></dt>
											<dd><?php echo esc_html( $opening_hour['hours'] ); ?></dd>
										</div>
									<?php endforeach; ?>
								</dl>
								<?php if ( ! empty( $contact['hours_note'] ) ) : ?>
									<p class="oasi-footer__hours-note"><?php echo esc_html( $contact['hours_note'] ); ?></p>
								<?php endif; ?>
							</div>
						</div>
					<?php endif; ?>
				</address>

				<?php if ( ! empty( $contact['facebook'] ) || ! empty( $contact['instagram'] ) ) : ?>
					<nav class="oasi-footer__social" aria-label="Canali social">
						<?php if ( ! empty( $contact['facebook'] ) ) : ?>
							<a href="<?php echo esc_url( $contact['facebook'] ); ?>" target="_blank" rel="noopener noreferrer" aria-label="Oasi delle Spezie su Facebook" class="oasi-footer__social-link">
								<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"></path></svg>
								<span>Facebook</span>
							</a>
						<?php endif; ?>
						<?php if ( ! empty( $contact['instagram'] ) ) : ?>
							<a href="<?php echo esc_url( $contact['instagram'] ); ?>" target="_blank" rel="noopener noreferrer" aria-label="Oasi delle Spezie su Instagram" class="oasi-footer__social-link">
								<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="5"></rect><circle cx="12" cy="12" r="4"></circle><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"></circle></svg>
								<span>Instagram</span>
							</a>
						<?php endif; ?>
					</nav>
				<?php endif; ?>
			</section>

			<nav class="oasi-footer__navigation" aria-label="Navigazione del footer">
				<details class="oasi-footer__disclosure" data-oasi-footer-disclosure open>
					<summary aria-expanded="true">
						<span class="oasi-footer__heading">Esplora</span>
						<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="m6 9 6 6 6-6"></path></svg>
					</summary>
					<div class="oasi-footer__disclosure-body">
						<?php if ( has_nav_menu( 'menu-2' ) ) : ?>
							<?php
							wp_nav_menu(
								array(
									'theme_location' => 'menu-2',
									'container'      => false,
									'menu_class'     => 'oasi-footer__links',
									'depth'          => 1,
									'fallback_cb'    => false,
								)
							);
							?>
						<?php else : ?>
							<ul class="oasi-footer__links">
								<?php foreach ( $quick_links as $link ) : ?>
									<li><a href="<?php echo esc_url( $link['url'] ); ?>"><?php echo esc_html( $link['label'] ); ?></a></li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>
					</div>
				</details>

				<details class="oasi-footer__disclosure" data-oasi-footer-disclosure open>
					<summary aria-expanded="true">
						<span class="oasi-footer__heading">Legale &amp; Aiuto</span>
						<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="m6 9 6 6 6-6"></path></svg>
					</summary>
					<div class="oasi-footer__disclosure-body">
						<ul class="oasi-footer__links">
							<li><a href="<?php echo esc_url( oasi_legal_get_page_url( 'impressum' ) ); ?>">Impressum</a></li>
							<li><a href="<?php echo esc_url( oasi_legal_get_page_url( 'privacy-policy' ) ); ?>">Privacy Policy</a></li>
							<li><a href="<?php echo esc_url( oasi_legal_get_page_url( 'cookie-policy' ) ); ?>">Cookie Policy</a></li>
							<li><button type="button" class="oasi-footer__cookie-settings" data-oasi-cookie-settings><?php esc_html_e( 'Impostazioni cookie', 'oasidellespezie-child-theme' ); ?></button></li>
							<li><a href="<?php echo esc_url( oasi_legal_get_page_url( 'condizioni-generali-di-vendita' ) ); ?>">Condizioni generali</a></li>
							<li><a href="<?php echo esc_url( oasi_legal_get_page_url( 'termini-e-condizioni' ) ); ?>">Termini e condizioni</a></li>
							<li><a href="<?php echo esc_url( oasi_legal_get_page_url( 'certificazione' ) ); ?>">Certificazione</a></li>
							<li><a href="<?php echo esc_url( oasi_legal_get_page_url( 'domande-frequenti' ) ); ?>">Domande frequenti</a></li>
						</ul>
					</div>
				</details>
			</nav>

			<aside class="oasi-footer__trust" aria-label="Pagamenti e certificazione">
				<section class="oasi-footer__payments" aria-labelledby="oasi-footer-payments-title">
					<p class="oasi-footer__trust-label" id="oasi-footer-payments-title">
						<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><rect x="4" y="10" width="16" height="11" rx="2"></rect><path d="M8 10V7a4 4 0 0 1 8 0v3"></path></svg>
						Metodi di pagamento accettati
					</p>
					<?php if ( $payment_methods ) : ?>
						<ul class="oasi-footer__payment-methods" aria-label="Metodi di pagamento accettati">
							<?php foreach ( $payment_methods as $method ) : ?>
								<li class="oasi-footer__payment-tile">
									<img class="oasi-footer__payment-logo <?php echo esc_attr( $method['class'] ); ?>" src="<?php echo esc_url( $method['icon'] ); ?>" alt="<?php echo esc_attr( $method['label'] ); ?>" loading="lazy">
								</li>
							<?php endforeach; ?>
						</ul>
					<?php else : ?>
						<p class="oasi-footer__payments-note">Le opzioni disponibili vengono mostrate in modo sicuro al checkout.</p>
					<?php endif; ?>
				</section>

				<section class="oasi-footer__certification" aria-labelledby="oasi-footer-cert-title">
					<div>
						<p class="oasi-footer__trust-label" id="oasi-footer-cert-title">Certificazione biologica</p>
						<p class="oasi-footer__cert-copy">Controllo indipendente dei processi certificati.</p>
					</div>
					<?php if ( $bio_inspecta_logo ) : ?>
						<a class="oasi-footer__cert-box" href="<?php echo esc_url( $certificate_url ); ?>" aria-label="Consulta la certificazione biologica CH-BIO-006">
							<img src="<?php echo esc_url( $bio_inspecta_logo ); ?>" alt="Certificazione Bio Inspecta CH-BIO-006" width="150" height="92" loading="lazy" class="oasi-footer__cert-logo">
						</a>
					<?php endif; ?>
				</section>
			</aside>
		</div>

		<div class="oasi-footer__bottom">
			<p class="oasi-footer__copyright">&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?> Oasi delle Spezie. Tutti i diritti riservati.</p>
			<p class="oasi-footer__credits">Design &amp; Sviluppo di <a href="https://ticinoweb.com" target="_blank" rel="noopener noreferrer">ticinoWEB</a></p>
		</div>
	</div>
</footer>

<?php
$is_shop_catalog = function_exists( 'oasi_is_shop_catalog' )
	? oasi_is_shop_catalog()
	: ( ( function_exists( 'is_shop' ) && is_shop() ) || ( function_exists( 'is_product_taxonomy' ) && is_product_taxonomy() ) );

if ( $is_shop_catalog ) :
	$fixed_watermark_url = function_exists( 'oasi_get_master_logo_url' ) ? oasi_get_master_logo_url() : '';
	if ( ! empty( $fixed_watermark_url ) ) :
		?>
		<div class="oasi-fixed-watermark" aria-hidden="true">
			<img src="<?php echo esc_url( $fixed_watermark_url ); ?>" alt="" width="600" height="265" loading="lazy">
		</div>
		<?php
	endif;
endif;
?>

<?php wp_footer(); ?>
</body>
</html>
