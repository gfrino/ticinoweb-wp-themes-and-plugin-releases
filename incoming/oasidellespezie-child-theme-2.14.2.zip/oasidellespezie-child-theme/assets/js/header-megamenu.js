/**
 * Header and Spice Atlas Mega Menu Controller
 * Oasi delle Spezie Child Theme
 *
 * Handles:
 * 1. Sticky header scroll transitions (fluid compactor)
 * 2. Desktop Mega Menu "Spice Atlas" interactions & family preview cross-fade
 * 3. Mobile & Tablet multi-level sliding drawer navigation (drill-down)
 * 4. Live WooCommerce cart count synchronizer
 *
 * @package OasiDelleSpezieChild
 */

(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		initStickyHeader();
		initDesktopMegaMenu();
		initMobileDrawer();
		initCartCountSync();
	});

	/* ==========================================================================
	   1. Sticky Header Fluid Compactor
	   ========================================================================== */
	function initStickyHeader() {
		var header = document.getElementById('oasi-site-header');
		if (!header) return;

		// Hysteresis: the sticky header sits in the document flow and loses ~60px
		// when it compacts (topbar hidden, smaller padding and logo). With a single
		// threshold the page got shorter, the browser pulled the scroll back under
		// the threshold, the header expanded again and so on: the header shook.
		// Compact only once the scroll is past the threshold plus the full expanded
		// height, expand only below the threshold: the jump can never cross back.
		var expandBelow = 40;
		var expandedHeight = header.offsetHeight;
		var ticking = false;

		function updateHeaderState() {
			var scrollY = window.pageYOffset || document.documentElement.scrollTop;
			var isScrolled = header.classList.contains('is-scrolled');

			if (!isScrolled) {
				expandedHeight = header.offsetHeight;
			}

			if (!isScrolled && scrollY > expandBelow + expandedHeight) {
				header.classList.add('is-scrolled');
			} else if (isScrolled && scrollY < expandBelow) {
				header.classList.remove('is-scrolled');
			}
			ticking = false;
		}

		window.addEventListener('scroll', function () {
			if (!ticking) {
				window.requestAnimationFrame(updateHeaderState);
				ticking = true;
			}
		}, { passive: true });

		// Initial check
		updateHeaderState();
	}

	/* ==========================================================================
	   2. Desktop Mega Menu "Spice Atlas"
	   ========================================================================== */
	function initDesktopMegaMenu() {
		var shopMenuItem = document.querySelector('.oasi-menu-item--has-megamenu');
		var megaPanel = document.getElementById('oasi-megamenu-panel');
		if (!shopMenuItem || !megaPanel) return;

		var triggerLink = shopMenuItem.querySelector('a');
		var familyLinks = megaPanel.querySelectorAll('.oasi-megamenu__family-link');
		var subpanels = megaPanel.querySelectorAll('.oasi-megamenu__subpanel');
		var previewImg = document.getElementById('oasi-megamenu-preview-img');
		var previewTitle = document.getElementById('oasi-megamenu-preview-title');
		var previewMeta = document.getElementById('oasi-megamenu-preview-meta');
		var previewLink = document.getElementById('oasi-megamenu-preview-link');

		var closeTimer = null;
		var openTimer = null;

		function openMegaMenu() {
			clearTimeout(closeTimer);
			openTimer = setTimeout(function () {
				megaPanel.classList.add('is-open');
				shopMenuItem.classList.add('is-open');
				document.body.classList.add('oasi-megamenu-open');
				if (triggerLink) {
					triggerLink.setAttribute('aria-expanded', 'true');
				}
			}, 80);
		}

		function closeMegaMenu() {
			clearTimeout(openTimer);
			closeTimer = setTimeout(function () {
				megaPanel.classList.remove('is-open');
				shopMenuItem.classList.remove('is-open');
				document.body.classList.remove('oasi-megamenu-open');
				if (triggerLink) {
					triggerLink.setAttribute('aria-expanded', 'false');
				}
			}, 220); // 220ms grace period prevents jittery accidental close
		}

		// Trigger on hover & focus
		shopMenuItem.addEventListener('mouseenter', openMegaMenu);
		shopMenuItem.addEventListener('mouseleave', closeMegaMenu);

		megaPanel.addEventListener('mouseenter', function () {
			clearTimeout(closeTimer);
		});
		megaPanel.addEventListener('mouseleave', closeMegaMenu);

		// Keyboard navigation
		if (triggerLink) {
			triggerLink.addEventListener('focus', openMegaMenu);
		}

		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' && megaPanel.classList.contains('is-open')) {
				megaPanel.classList.remove('is-open');
				if (triggerLink) {
					triggerLink.setAttribute('aria-expanded', 'false');
					triggerLink.focus();
				}
			}
		});

		// Dynamic family tab switching with cross-fade
		familyLinks.forEach(function (link) {
			link.addEventListener('mouseenter', function () {
				activateFamily(link);
			});

			link.addEventListener('focus', function () {
				activateFamily(link);
			});
		});

		function activateFamily(activeLink) {
			var familyId = activeLink.getAttribute('data-family-id');
			var thumbUrl = activeLink.getAttribute('data-thumb');
			var title = activeLink.getAttribute('data-title');
			var count = parseInt(activeLink.getAttribute('data-count'), 10) || 0;
			var url = activeLink.getAttribute('data-url');

			// Update family links state
			familyLinks.forEach(function (fl) {
				fl.classList.remove('is-active');
				fl.setAttribute('aria-selected', 'false');
			});
			activeLink.classList.add('is-active');
			activeLink.setAttribute('aria-selected', 'true');

			// Update center subpanels
			subpanels.forEach(function (panel) {
				if (panel.id === 'oasi-subpanel-' + familyId) {
					panel.classList.add('is-active');
				} else {
					panel.classList.remove('is-active');
				}
			});

			// Update right dynamic visual card with smooth cross-fade
			var card = megaPanel.querySelector('.oasi-megamenu__card');
			if (card) {
				card.classList.add('is-updating');
				setTimeout(function () {
					if (previewImg && thumbUrl) {
						previewImg.src = thumbUrl;
						previewImg.alt = title;
					}
					if (previewTitle && title) {
						previewTitle.textContent = title;
					}
					if (previewMeta) {
						if (count > 0) {
							previewMeta.textContent = count + (count === 1 ? ' prodotto disponibile' : ' prodotti disponibili');
						} else {
							previewMeta.textContent = 'Selezione d’eccellenza';
						}
					}
					if (previewLink && url) {
						previewLink.href = url;
					}
					card.classList.remove('is-updating');
				}, 110);
			}
		}
	}

	/* ==========================================================================
	   3. Mobile & Tablet Multi-Level Sliding Drawer Navigation
	   ========================================================================== */
	function initMobileDrawer() {
		var toggleBtn = document.getElementById('oasi-mobile-toggle');
		var drawer = document.getElementById('oasi-mobile-drawer');
		var closeBtn = document.getElementById('oasi-drawer-close');
		var backdrop = document.getElementById('oasi-drawer-backdrop');
		var slider = document.getElementById('oasi-drawer-slider');

		if (!toggleBtn || !drawer || !slider) return;

		// Ensure drawer is a direct child of <body> to avoid any ancestor containing block issues
		if (drawer.parentElement !== document.body) {
			document.body.appendChild(drawer);
		}

		var shopTrigger = document.getElementById('oasi-mobile-shop-trigger');
		var drilldownSubs = drawer.querySelectorAll('.oasi-drawer__drilldown-sub');
		var backBtns = drawer.querySelectorAll('.oasi-drawer__back-btn');
		var subpanels = drawer.querySelectorAll('.oasi-drawer__subgroup');
		var level3BackLabel = document.getElementById('oasi-mob-level3-back-label');
		var level3Title = document.getElementById('oasi-mob-level3-title');

		function openDrawer() {
			if (drawer.parentElement !== document.body) {
				document.body.appendChild(drawer);
			}

			// Prevent layout shift from disappearing scrollbar
			var scrollbarWidth = window.innerWidth - document.documentElement.clientWidth;
			if (scrollbarWidth > 0) {
				document.body.style.paddingRight = scrollbarWidth + 'px';
			}

			drawer.classList.add('is-open');
			drawer.setAttribute('aria-hidden', 'false');
			toggleBtn.classList.add('is-active');
			toggleBtn.setAttribute('aria-expanded', 'true');
			document.body.classList.add('oasi-drawer-open');
		}

		function closeDrawer() {
			drawer.classList.remove('is-open');
			drawer.setAttribute('aria-hidden', 'true');
			toggleBtn.classList.remove('is-active');
			toggleBtn.setAttribute('aria-expanded', 'false');
			document.body.classList.remove('oasi-drawer-open');
			document.body.style.paddingRight = '';

			// Reset to Level 1 after transition completes
			setTimeout(function () {
				slider.setAttribute('data-active-level', '1');
				subpanels.forEach(function (sp) {
					sp.style.display = 'none';
				});
			}, 380);
		}

		toggleBtn.addEventListener('click', function () {
			if (drawer.classList.contains('is-open')) {
				closeDrawer();
			} else {
				openDrawer();
			}
		});

		if (closeBtn) {
			closeBtn.addEventListener('click', closeDrawer);
		}

		if (backdrop) {
			backdrop.addEventListener('click', closeDrawer);
		}

		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' && drawer.classList.contains('is-open')) {
				closeDrawer();
			}
		});

		// Level 1 -> Level 2: Shop trigger
		if (shopTrigger) {
			shopTrigger.addEventListener('click', function () {
				slider.setAttribute('data-active-level', '2');
			});
		}

		// Level 2 -> Level 3: Category Subgroups
		drilldownSubs.forEach(function (btn) {
			btn.addEventListener('click', function () {
				var targetPanelId = btn.getAttribute('data-target-subpanel');
				var parentTitle = btn.getAttribute('data-parent-title') || 'Categorie';

				// Hide all subgroups and show targeted one
				subpanels.forEach(function (sp) {
					sp.style.display = (sp.id === targetPanelId) ? 'block' : 'none';
				});

				if (level3BackLabel) {
					level3BackLabel.textContent = parentTitle;
				}
				if (level3Title) {
					level3Title.textContent = parentTitle;
				}

				slider.setAttribute('data-active-level', '3');
			});
		});

		// Back buttons navigation
		backBtns.forEach(function (bBtn) {
			bBtn.addEventListener('click', function () {
				var backLevel = bBtn.getAttribute('data-back-level') || '1';
				slider.setAttribute('data-active-level', backLevel);
			});
		});
	}

	/* ==========================================================================
	   4. Live WooCommerce Cart Synchronizer
	   ========================================================================== */
	function initCartCountSync() {
		var deskCountElem = document.getElementById('oasi-cart-count');
		var mobCountElems = document.querySelectorAll('.oasi-mob-cart-count');

		function updateCounts(count) {
			if (deskCountElem) {
				deskCountElem.textContent = count;
			}
			mobCountElems.forEach(function (el) {
				el.textContent = count;
			});
		}

		// Listen to native WooCommerce jQuery events if jQuery is present
		if (window.jQuery) {
			window.jQuery(document.body).on('added_to_cart wc_fragments_refreshed wc_fragments_loaded', function (e, fragments) {
				if (fragments && fragments['span.oasi-header__cart-count']) {
					// Direct fragment replace handled by WC
					return;
				}
				// Fetch latest cart count if needed
				if (window.wc_cart_fragments_params) {
					var cartCount = getCookie('woocommerce_items_in_cart');
					if (cartCount !== null) {
						updateCounts(cartCount);
					}
				}
			});
		}

		function getCookie(name) {
			var match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
			return match ? match[2] : null;
		}
	}
})();
