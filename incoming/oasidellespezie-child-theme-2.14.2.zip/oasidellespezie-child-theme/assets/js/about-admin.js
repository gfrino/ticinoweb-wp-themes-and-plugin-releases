/**
 * Attach Oasi-only fields to the existing ticinoWEB CMS Chi Siamo tab.
 */
(function () {
	'use strict';

	function mountFields() {
		var source = document.getElementById('oasi-about-cms-fields');
		var table = document.querySelector('#chi-siamo table.form-table');

		if (!source || !table || table.querySelector('.oasi-about-cms-row')) {
			return;
		}

		Array.prototype.slice.call(source.querySelectorAll('.oasi-about-cms-row')).forEach(function (row) {
			table.querySelector('tbody').appendChild(row);
		});
		source.remove();

		table.addEventListener('click', function (event) {
			var button = event.target.closest('.oasi-about-media-button');
			var removeButton = event.target.closest('.oasi-about-media-remove');

			if (removeButton) {
				event.preventDefault();
				var removeIndex = removeButton.getAttribute('data-oasi-image-index');
				var removeInput = document.getElementById('oasi_team_image_' + removeIndex);
				var removePreview = table.querySelector('[data-oasi-image-preview="' + removeIndex + '"]');
				removeInput.value = '';
				removePreview.innerHTML = '';
				var emptyLabel = document.createElement('span');
				emptyLabel.textContent = removePreview.getAttribute('data-empty-label') || 'Nessuna foto';
				removePreview.appendChild(emptyLabel);
				removeButton.disabled = true;
				return;
			}

			if (!button || !window.wp || !window.wp.media) {
				return;
			}

			event.preventDefault();
			var index = button.getAttribute('data-oasi-image-index');
			var input = document.getElementById('oasi_team_image_' + index);
			var preview = table.querySelector('[data-oasi-image-preview="' + index + '"]');
			var matchingRemoveButton = table.querySelector('.oasi-about-media-remove[data-oasi-image-index="' + index + '"]');
			var frame = window.wp.media({
				title: 'Seleziona la foto del collaboratore',
				button: { text: 'Usa questa foto' },
				library: { type: 'image' },
				multiple: false
			});

			frame.on('select', function () {
				var attachment = frame.state().get('selection').first().toJSON();
				var imageUrl = attachment.sizes && attachment.sizes.thumbnail
					? attachment.sizes.thumbnail.url
					: attachment.url;

				input.value = attachment.id;
				preview.innerHTML = '';
				var image = document.createElement('img');
				image.src = imageUrl;
				image.alt = '';
				preview.appendChild(image);
				matchingRemoveButton.disabled = false;
			});

			frame.open();
		});
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', mountFields);
	} else {
		mountFields();
	}
}());
