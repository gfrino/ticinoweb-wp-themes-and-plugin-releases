<?php
/**
 * Oasi delle Spezie child-theme bootstrap.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once get_stylesheet_directory() . '/inc/bootstrap.php';
require_once get_stylesheet_directory() . '/inc/local-safety.php';
require_once get_stylesheet_directory() . '/inc/home-functions.php';
require_once get_stylesheet_directory() . '/inc/maintenance-mode.php';
require_once get_stylesheet_directory() . '/inc/shop-functions.php';
require_once get_stylesheet_directory() . '/inc/header-menu-functions.php';
require_once get_stylesheet_directory() . '/inc/single-product-functions.php';
require_once get_stylesheet_directory() . '/inc/about-functions.php';
require_once get_stylesheet_directory() . '/inc/news-functions.php';
require_once get_stylesheet_directory() . '/inc/single-post-functions.php';
require_once get_stylesheet_directory() . '/inc/contact-functions.php';
require_once get_stylesheet_directory() . '/inc/professional-functions.php';
require_once get_stylesheet_directory() . '/inc/legal-functions.php';
require_once get_stylesheet_directory() . '/inc/professional-application-functions.php';
require_once get_stylesheet_directory() . '/inc/professional-ultimate-member.php';
require_once get_stylesheet_directory() . '/inc/account-functions.php';
require_once get_stylesheet_directory() . '/inc/cart-functions.php';
require_once get_stylesheet_directory() . '/inc/checkout-functions.php';
require_once get_stylesheet_directory() . '/inc/lots-functions.php';
require_once get_stylesheet_directory() . '/inc/lots-report.php';
require_once get_stylesheet_directory() . '/inc/admin-fixes.php';
require_once get_stylesheet_directory() . '/inc/performance-functions.php';
require_once get_stylesheet_directory() . '/inc/security-functions.php';
require_once get_stylesheet_directory() . '/inc/seo-functions.php';
require_once get_stylesheet_directory() . '/inc/age-verification-functions.php';
require_once get_stylesheet_directory() . '/inc/consent-functions.php';
require_once get_stylesheet_directory() . '/inc/footer-functions.php';
