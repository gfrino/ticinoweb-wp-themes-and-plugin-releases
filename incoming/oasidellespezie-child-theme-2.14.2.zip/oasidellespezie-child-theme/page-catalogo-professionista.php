<?php
/**
 * Template Name: Oasi — Area Professionisti
 *
 * THESIS: un accesso B2B chiaro e concreto, non una seconda vetrina prodotti.
 * OWN-WORLD: carta naturale, terracotta, oro e dettagli scuri ereditati dalla Home.
 * STORY: comprendere l'offerta, verificare il proprio stato e raggiungere il catalogo corretto.
 * FIRST VIEWPORT: messaggio e azioni a sinistra, fotografia reale del laboratorio a destra.
 * FORM: pagina editoriale compatta, con lista merceologica e condizioni progressive.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$access_state = oasi_professional_get_access_state();
$categories   = oasi_professional_get_categories();
$contact      = oasi_get_contact_data();
$register_url = oasi_professional_get_register_url();
$account_url  = oasi_professional_get_account_url();
$shop_url     = oasi_professional_get_shop_url();
$contact_url  = oasi_professional_get_contact_url();
$application_url = function_exists( 'oasi_professional_application_get_url' ) ? oasi_professional_application_get_url() : $contact_url;
$catalog_cta  = oasi_professional_get_catalog_cta( $access_state );
$image_html   = oasi_professional_get_image_html();
$phone        = isset( $contact['phone'] ) ? (string) $contact['phone'] : '';
$phone_tel    = isset( $contact['phone_tel'] ) ? (string) $contact['phone_tel'] : '';
$hours_short  = isset( $contact['hours_short'] ) ? (string) $contact['hours_short'] : '';

if ( 'guest' === $access_state ) {
	$access_label = __( 'Accesso da attivare', 'oasidellespezie-child-theme' );
	$access_title = __( 'Richiedi il tuo account professionale', 'oasidellespezie-child-theme' );
	$access_text  = __( 'Registrati attraverso il modulo già predisposto. Il laboratorio verificherà la richiesta prima di abilitare il listino riservato.', 'oasidellespezie-child-theme' );
} elseif ( 'customer' === $access_state ) {
	$access_label = __( 'Accesso professionale', 'oasidellespezie-child-theme' );
	$access_title = __( 'Completa il formulario per richiedere l’accesso professionale', 'oasidellespezie-child-theme' );
	$access_text  = __( 'Il tuo account è già attivo. Clicca sul pulsante rosso “Richiedi la verifica professionale” e completa il formulario con i dati della tua attività. Esamineremo la richiesta e ti contatteremo via email.', 'oasidellespezie-child-theme' );
} else {
	$access_label = __( 'Accesso professionale attivo', 'oasidellespezie-child-theme' );
	$access_title = __( 'Il tuo catalogo riservato è pronto', 'oasidellespezie-child-theme' );
	$access_text  = __( 'Accedi allo Shop con questo account: prezzi e disponibilità professionali vengono applicati direttamente dal sistema wholesale esistente.', 'oasidellespezie-child-theme' );
}
?>

<div id="primary" class="site-main oasi-professional">
	<section class="oasi-professional-intro" aria-labelledby="oasi-professional-title">
		<div class="oasi-container oasi-professional-intro__grid">
			<div class="oasi-professional-intro__copy">
				<span class="oasi-professional-kicker"><?php esc_html_e( 'Area professionisti', 'oasidellespezie-child-theme' ); ?></span>
				<h1 id="oasi-professional-title"><?php esc_html_e( 'Soluzioni dedicate ai professionisti', 'oasidellespezie-child-theme' ); ?></h1>
				<p class="oasi-professional-intro__lead"><?php esc_html_e( 'Una selezione di spezie, erbe, pepi e sali per ristorazione, laboratori e attività che cercano materie prime scelte con cura.', 'oasidellespezie-child-theme' ); ?></p>
				<p><?php esc_html_e( 'Siamo un laboratorio artigianale, non un negozio su strada: prepariamo gli ordini con attenzione e lavoriamo con un listino riservato agli account professionali approvati.', 'oasidellespezie-child-theme' ); ?></p>

				<ul class="oasi-professional-intro__facts" aria-label="<?php esc_attr_e( 'Caratteristiche dell’offerta professionale', 'oasidellespezie-child-theme' ); ?>">
					<li>
						<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 4 7v5c0 4.7 3.2 8.6 8 10 4.8-1.4 8-5.3 8-10V7l-8-4Z"/><path d="m8.5 12 2.2 2.2 4.8-5"/></svg>
						<span><?php esc_html_e( 'Accesso verificato', 'oasidellespezie-child-theme' ); ?></span>
					</li>
					<li>
						<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16v12H4z"/><path d="M8 7V5h8v2M8 12h8"/></svg>
						<span><?php esc_html_e( 'Listino nel normale Shop', 'oasidellespezie-child-theme' ); ?></span>
					</li>
					<li>
						<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s7-3.8 7-10V5l-7-2-7 2v6c0 6.2 7 10 7 10Z"/><path d="M9 12c2.5 0 4-1.5 6-4 0 4-1.5 7-5 7"/></svg>
						<span><?php esc_html_e( 'Preparazione artigianale', 'oasidellespezie-child-theme' ); ?></span>
					</li>
				</ul>
			</div>

			<?php if ( '' !== $image_html ) : ?>
				<figure class="oasi-professional-intro__visual">
					<?php echo wp_kses_post( $image_html ); ?>
					<figcaption>
						<span><?php esc_html_e( 'Selezione Oasi', 'oasidellespezie-child-theme' ); ?></span>
						<strong><?php esc_html_e( 'Materie prime scelte per il lavoro quotidiano', 'oasidellespezie-child-theme' ); ?></strong>
					</figcaption>
				</figure>
			<?php endif; ?>
		</div>
	</section>

	<section class="oasi-professional-access oasi-professional-access--<?php echo esc_attr( $access_state ); ?>" aria-labelledby="oasi-professional-access-title">
		<div class="oasi-container oasi-professional-access__inner">
			<div class="oasi-professional-access__copy">
				<div class="oasi-professional-access__status" aria-hidden="true">
					<span></span>
					<?php echo esc_html( $access_label ); ?>
				</div>
				<h2 id="oasi-professional-access-title"><?php echo esc_html( $access_title ); ?></h2>
				<p><?php echo esc_html( $access_text ); ?></p>
			</div>
			<div class="oasi-professional-access__actions">
				<?php if ( 'guest' === $access_state ) : ?>
					<a class="oasi-btn oasi-btn--primary" href="<?php echo esc_url( $register_url ); ?>">
						<span><?php esc_html_e( 'Registrati come professionista', 'oasidellespezie-child-theme' ); ?></span>
						<span aria-hidden="true">→</span>
					</a>
					<a class="oasi-btn oasi-btn--secondary" href="<?php echo esc_url( $account_url ); ?>"><?php esc_html_e( 'Accedi all’area riservata', 'oasidellespezie-child-theme' ); ?></a>
				<?php elseif ( 'customer' === $access_state ) : ?>
					<a class="oasi-btn oasi-btn--primary" href="<?php echo esc_url( $application_url ); ?>">
						<span><?php esc_html_e( 'Richiedi la verifica professionale', 'oasidellespezie-child-theme' ); ?></span>
						<span aria-hidden="true">→</span>
					</a>
					<a class="oasi-btn oasi-btn--secondary" href="<?php echo esc_url( $account_url ); ?>"><?php esc_html_e( 'Vai al mio account', 'oasidellespezie-child-theme' ); ?></a>
				<?php else : ?>
					<a class="oasi-btn oasi-btn--primary" href="<?php echo esc_url( $shop_url ); ?>">
						<span><?php esc_html_e( 'Accedi al catalogo professionale', 'oasidellespezie-child-theme' ); ?></span>
						<span aria-hidden="true">→</span>
					</a>
				<?php endif; ?>
			</div>
		</div>
	</section>

	<section class="oasi-professional-range" aria-labelledby="oasi-professional-range-title">
		<div class="oasi-container oasi-professional-range__grid">
			<header class="oasi-professional-range__header">
				<span><?php esc_html_e( 'Selezione merceologica', 'oasidellespezie-child-theme' ); ?></span>
				<h2 id="oasi-professional-range-title"><?php esc_html_e( 'Trova rapidamente la materia prima che cerchi', 'oasidellespezie-child-theme' ); ?></h2>
				<p><?php esc_html_e( 'Le categorie portano allo Shop reale: assortimento, stock e prezzi rimangono gestiti da WooCommerce.', 'oasidellespezie-child-theme' ); ?></p>
			</header>

			<ul class="oasi-professional-categories">
				<?php foreach ( $categories as $category ) : ?>
					<li>
						<a href="<?php echo esc_url( $category['url'] ); ?>">
							<span>
								<strong><?php echo esc_html( $category['label'] ); ?></strong>
								<small><?php echo esc_html( $category['description'] ); ?></small>
							</span>
							<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14m-6-6 6 6-6 6"/></svg>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</section>

	<section class="oasi-professional-catalog" aria-labelledby="oasi-professional-catalog-title">
		<div class="oasi-container oasi-professional-catalog__inner">
			<div>
				<span class="oasi-professional-catalog__label"><?php esc_html_e( 'Un solo catalogo, il prezzo corretto', 'oasidellespezie-child-theme' ); ?></span>
				<h2 id="oasi-professional-catalog-title"><?php esc_html_e( 'Il listino professionale vive nello Shop Oasi', 'oasidellespezie-child-theme' ); ?></h2>
				<p><?php esc_html_e( 'Prodotti, varianti, disponibilità e ordini restano sincronizzati con WooCommerce. Accedendo con un account autorizzato visualizzerai automaticamente le condizioni riservate.', 'oasidellespezie-child-theme' ); ?></p>
			</div>
			<a class="oasi-professional-catalog__link" href="<?php echo esc_url( $catalog_cta['url'] ); ?>">
				<span><?php echo esc_html( $catalog_cta['label'] ); ?></span>
				<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14m-6-6 6 6-6 6"/></svg>
			</a>
		</div>
	</section>

	<section id="condizioni" class="oasi-professional-conditions" aria-labelledby="oasi-professional-conditions-title">
		<div class="oasi-container oasi-professional-conditions__grid">
			<header class="oasi-professional-conditions__header">
				<span><?php esc_html_e( 'Informazioni prima dell’ordine', 'oasidellespezie-child-theme' ); ?></span>
				<h2 id="oasi-professional-conditions-title"><?php esc_html_e( 'Condizioni per professionisti', 'oasidellespezie-child-theme' ); ?></h2>
				<p><?php esc_html_e( 'Le condizioni già pubblicate sono qui raccolte in un unico punto, senza cambiare il funzionamento commerciale del sito.', 'oasidellespezie-child-theme' ); ?></p>
				<a href="<?php echo esc_url( $contact_url ); ?>"><?php esc_html_e( 'Hai una richiesta specifica? Contattaci', 'oasidellespezie-child-theme' ); ?> <span aria-hidden="true">↗</span></a>
			</header>

			<div class="oasi-professional-accordion" data-oasi-professional-accordion>
				<div class="oasi-professional-accordion__item">
					<h3>
						<button type="button" class="oasi-professional-accordion__button" id="oasi-professional-condition-orders" aria-expanded="true" aria-controls="oasi-professional-panel-orders">
							<span><small>01</small><?php esc_html_e( 'Ordini', 'oasidellespezie-child-theme' ); ?></span>
							<span class="oasi-professional-accordion__mark" aria-hidden="true"></span>
						</button>
					</h3>
					<div class="oasi-professional-accordion__panel" id="oasi-professional-panel-orders" role="region" aria-labelledby="oasi-professional-condition-orders" aria-hidden="false">
						<p><?php esc_html_e( 'Effettuiamo ordini professionali esclusivamente in Svizzera e Liechtenstein. L’accesso al listino riservato richiede registrazione e approvazione.', 'oasidellespezie-child-theme' ); ?></p>
					</div>
				</div>

				<div class="oasi-professional-accordion__item">
					<h3>
						<button type="button" class="oasi-professional-accordion__button" id="oasi-professional-condition-payments" aria-expanded="true" aria-controls="oasi-professional-panel-payments">
							<span><small>02</small><?php esc_html_e( 'Pagamenti', 'oasidellespezie-child-theme' ); ?></span>
							<span class="oasi-professional-accordion__mark" aria-hidden="true"></span>
						</button>
					</h3>
					<div class="oasi-professional-accordion__panel" id="oasi-professional-panel-payments" role="region" aria-labelledby="oasi-professional-condition-payments" aria-hidden="false">
						<p><?php esc_html_e( 'Per ogni ordine professionale è richiesto il pagamento anticipato.', 'oasidellespezie-child-theme' ); ?></p>
					</div>
				</div>

				<div class="oasi-professional-accordion__item">
					<h3>
						<button type="button" class="oasi-professional-accordion__button" id="oasi-professional-condition-preparation" aria-expanded="true" aria-controls="oasi-professional-panel-preparation">
							<span><small>03</small><?php esc_html_e( 'Preparazione ed erbe', 'oasidellespezie-child-theme' ); ?></span>
							<span class="oasi-professional-accordion__mark" aria-hidden="true"></span>
						</button>
					</h3>
					<div class="oasi-professional-accordion__panel" id="oasi-professional-panel-preparation" role="region" aria-labelledby="oasi-professional-condition-preparation" aria-hidden="false">
						<p><?php esc_html_e( 'Le erbe aromatiche vengono selezionate a mano; possono rimanere alcuni rami o rametti. La lavorazione richiede tempo, quindi consigliamo di ordinare con largo anticipo.', 'oasidellespezie-child-theme' ); ?></p>
					</div>
				</div>

				<div class="oasi-professional-accordion__item">
					<h3>
						<button type="button" class="oasi-professional-accordion__button" id="oasi-professional-condition-shipping" aria-expanded="true" aria-controls="oasi-professional-panel-shipping">
							<span><small>04</small><?php esc_html_e( 'Spedizione', 'oasidellespezie-child-theme' ); ?></span>
							<span class="oasi-professional-accordion__mark" aria-hidden="true"></span>
						</button>
					</h3>
					<div class="oasi-professional-accordion__panel" id="oasi-professional-panel-shipping" role="region" aria-labelledby="oasi-professional-condition-shipping" aria-hidden="false">
						<p><?php esc_html_e( 'Per i clienti professionali le spese di spedizione sono variabili secondo il peso della merce.', 'oasidellespezie-child-theme' ); ?></p>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="oasi-professional-trust" aria-label="<?php esc_attr_e( 'Servizi per clienti professionali', 'oasidellespezie-child-theme' ); ?>">
		<div class="oasi-container oasi-professional-trust__grid">
			<div><strong><?php esc_html_e( 'Territorio', 'oasidellespezie-child-theme' ); ?></strong><span><?php esc_html_e( 'Svizzera e Liechtenstein', 'oasidellespezie-child-theme' ); ?></span></div>
			<div><strong><?php esc_html_e( 'Pagamento', 'oasidellespezie-child-theme' ); ?></strong><span><?php esc_html_e( 'Anticipato per ogni ordine', 'oasidellespezie-child-theme' ); ?></span></div>
			<div><strong><?php esc_html_e( 'Preparazione', 'oasidellespezie-child-theme' ); ?></strong><span><?php esc_html_e( 'Artigianale, da ordinare in anticipo', 'oasidellespezie-child-theme' ); ?></span></div>
			<div>
				<strong><?php esc_html_e( 'Assistenza', 'oasidellespezie-child-theme' ); ?></strong>
				<?php if ( '' !== $phone && '' !== $phone_tel ) : ?>
					<a href="tel:<?php echo esc_attr( $phone_tel ); ?>"><?php echo esc_html( $phone ); ?></a>
				<?php endif; ?>
				<?php if ( '' !== $hours_short ) : ?><span><?php echo esc_html( $hours_short ); ?></span><?php endif; ?>
			</div>
		</div>
	</section>
</div>

<?php get_footer(); ?>
