<?php
/**
 * Legal/help pages, content and routing for Oasi delle Spezie.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return the verified business identity and the existing CMS contact data.
 */
function oasi_legal_get_identity(): array {
	$contact = function_exists( 'oasi_get_contact_data' ) ? oasi_get_contact_data() : array();

	return array(
		'name'                => 'L’Oasi delle Spezie di Jaunin',
		'uid'                 => 'CHE-308.064.519',
		'legal_address'       => 'Via Cantonale 65, 6805 Mezzovico, Svizzera',
		'operational_address' => (string) ( $contact['address'] ?? 'Alla Monda 12, 6515 Gudo, Svizzera' ),
		'email'               => (string) ( $contact['email'] ?? 'info@oasidellespezie.ch' ),
		'phone'               => (string) ( $contact['phone'] ?? '+41 91 859 05 32' ),
	);
}

/**
 * Canonical definitions for all footer legal/help destinations.
 */
function oasi_legal_get_definitions(): array {
	$identity = oasi_legal_get_identity();
	$email    = esc_html( $identity['email'] );
	$name     = esc_html( $identity['name'] );
	$updated  = '29 settembre 2026';
	$shipping = function_exists( 'oasi_shipping_facts' ) ? oasi_shipping_facts() : array( 'free_from' => null, 'flat_rate' => null );
	$shipping_costs = trim(
		( null !== $shipping['flat_rate'] ? 'La tariffa standard è di CHF ' . oasi_format_chf_amount( (float) $shipping['flat_rate'] ) . '. ' : '' )
		. ( null !== $shipping['free_from'] ? 'Per i clienti privati la spedizione è gratuita per ordini da CHF ' . oasi_format_chf_amount( (float) $shipping['free_from'] ) . ' netti.' : '' )
	);

	return array(
		'impressum' => array(
			'title'   => 'Impressum',
			'kicker'  => 'Chi gestisce il sito',
			'summary' => 'Dati identificativi e di contatto del gestore del sito e del negozio online (art. 3 cpv. 1 lett. s LCSl).',
			'updated' => $updated,
			'sections' => array(
				array( 'id' => 'gestore', 'title' => 'Gestore del sito e del negozio online', 'body' => array( "<strong>{$name}</strong><br>IDI/UID: {$identity['uid']}<br>Sede legale: {$identity['legal_address']}<br>Laboratorio e punto di ritiro: {$identity['operational_address']}" ) ),
				array( 'id' => 'contatti', 'title' => 'Contatti', 'body' => array( "Email: <a href=\"mailto:{$email}\">{$email}</a><br>Telefono: {$identity['phone']}" ) ),
				array( 'id' => 'certificazione-bio', 'title' => 'Certificazione biologica', 'body' => array( 'Organismo di certificazione: bio.inspecta AG (CH-BIO-006), certificato n. BVH-62064. I dettagli sono nella pagina “Certificazione biologica”.' ) ),
				array( 'id' => 'contenuti', 'title' => 'Responsabilità per i contenuti', 'body' => array( 'I contenuti del sito sono curati con attenzione, ma non possiamo garantirne in ogni momento completezza e attualità. Per i siti esterni collegati sono responsabili i rispettivi gestori.' ) ),
				array( 'id' => 'realizzazione', 'title' => 'Realizzazione tecnica', 'body' => array( 'Sito realizzato e gestito tecnicamente da ticinoWEB, Ticino (Svizzera).' ) ),
			),
		),
		'privacy-policy' => array(
			'title'   => 'Privacy Policy',
			'kicker'  => 'Protezione dei dati',
			'summary' => 'Come raccogliamo, utilizziamo e proteggiamo i dati personali quando visiti il sito, acquisti o richiedi un accesso professionale.',
			'updated' => $updated,
			'sections' => array(
				array( 'id' => 'titolare', 'title' => '1. Titolare e contatti', 'body' => array( "Il titolare del trattamento è <strong>{$name}</strong>, {$identity['uid']}, con sede legale in {$identity['legal_address']}. Il laboratorio e punto di ritiro opera all’indirizzo {$identity['operational_address']}.", "Per richieste sulla protezione dei dati puoi scrivere a <a href=\"mailto:{$email}\">{$email}</a> o telefonare al {$identity['phone']}." ) ),
				array( 'id' => 'dati', 'title' => '2. Dati trattati', 'body' => array( 'Trattiamo i dati forniti direttamente dall’utente: dati identificativi e di contatto, indirizzi di fatturazione e consegna, contenuto delle comunicazioni, dati dell’account, richieste professionali e preferenze espresse.', 'Per ordini e pagamenti trattiamo dati relativi a prodotti, importi, consegna, fatturazione, stato del pagamento, rimborsi e documenti contabili. I dati completi della carta sono gestiti dal relativo prestatore di pagamento e non vengono conservati dal negozio.', 'I sistemi possono registrare dati tecnici necessari a sicurezza e funzionamento, come indirizzo IP, data e ora, user agent, log di errore e cookie tecnici.' ) ),
				array( 'id' => 'finalita', 'title' => '3. Finalità e basi del trattamento', 'list' => array( 'Gestione di account, carrello, ordini, pagamenti, consegne, ritiro, resi, assistenza e garanzia.', 'Esecuzione di misure precontrattuali e valutazione manuale delle richieste professionali.', 'Adempimenti fiscali, contabili, legali e prevenzione di frodi o abusi.', 'Gestione dei punti fedeltà, coupon e servizi richiesti dall’utente.', 'Invio di comunicazioni promozionali soltanto quando l’utente ha espresso un consenso valido, revocabile in qualsiasi momento.' ), 'body' => array( 'Il trattamento si fonda, secondo il caso, sull’esecuzione del contratto o di misure precontrattuali, su obblighi di legge, su interessi legittimi proporzionati alla sicurezza e alla gestione del servizio oppure sul consenso.' ) ),
				array( 'id' => 'destinatari', 'title' => '4. Destinatari e servizi esterni', 'body' => array( 'I dati sono accessibili solo a personale autorizzato e, nella misura necessaria, ai fornitori elencati qui sotto, a consulenti contabili e alle autorità competenti. Non vendiamo dati personali.' ), 'list' => array( '<strong>Hosting e posta elettronica</strong>: Infomaniak Network SA, Ginevra (Svizzera). Sito, database, backup e invio delle email del negozio restano in Svizzera.', '<strong>Pagamenti</strong>: Stripe Payments Europe Ltd (Irlanda) e Stripe, Inc. (Stati Uniti) per carte, TWINT, Apple Pay, Google Pay e Link. Ricevono i dati necessari al pagamento e alla prevenzione delle frodi; per gli Stati Uniti valgono lo Swiss-U.S. Data Privacy Framework e le clausole contrattuali standard. Usando Apple Pay o Google Pay si applicano anche le informative di Apple e Google.', '<strong>Statistiche di visita</strong>: Google Analytics 4 (Google Ireland Ltd / Google LLC), <em>solo se lo accetti</em> nel banner dei cookie. Senza consenso lo script non viene caricato. Puoi cambiare idea in ogni momento dal link “Impostazioni cookie” a piè di pagina.', '<strong>Traduzione del sito</strong>: i testi delle pagine (non i tuoi dati personali) possono essere tradotti automaticamente tramite Google Cloud Translation.', '<strong>Spedizioni</strong>: il vettore scelto (ad esempio La Posta Svizzera) riceve nome, indirizzo e, se utile alla consegna, telefono ed email.', '<strong>Caratteri tipografici</strong>: sono ospitati sui nostri server; il sito non li carica da servizi di terzi.' ) ),
				array( 'id' => 'estero', 'title' => '4a. Trasferimenti all’estero', 'body' => array( 'Alcuni fornitori (Stripe, Google) trattano dati in Paesi dell’UE/SEE o negli Stati Uniti. Per l’UE/SEE vale la decisione di adeguatezza del Consiglio federale; per gli Stati Uniti il Swiss-U.S. Data Privacy Framework, al quale Stripe e Google aderiscono, o in alternativa le clausole contrattuali standard.' ) ),
				array( 'id' => 'conservazione', 'title' => '5. Conservazione e sicurezza', 'body' => array( 'Conserviamo i dati per il tempo necessario alle finalità indicate. I documenti commerciali e contabili possono essere conservati per 10 anni; account e corrispondenza vengono mantenuti finché utili al rapporto o agli obblighi legali, poi cancellati o anonimizzati.', 'Le richieste di accesso professionale respinte sono conservate solo per il tempo necessario a gestire eventuali chiarimenti e vengono cancellate su richiesta. Per gli ordini con bevande alcoliche conserviamo, insieme all’ordine, la dichiarazione di maggiore età resa al checkout.', 'Applichiamo misure tecniche e organizzative ragionevoli, inclusi accessi limitati, connessioni protette, aggiornamenti e backup. Nessun sistema online può tuttavia garantire sicurezza assoluta.' ) ),
				array( 'id' => 'diritti', 'title' => '6. Diritti dell’interessato', 'body' => array( "Puoi chiedere informazioni sui tuoi dati, rettifica, cancellazione, limitazione, portabilità quando applicabile e revoca del consenso. Puoi inoltre opporti a determinati trattamenti e presentare reclamo all’Incaricato federale della protezione dei dati e della trasparenza. Scrivi a <a href=\"mailto:{$email}\">{$email}</a>; potremo richiedere una verifica dell’identità." ) ),
				array( 'id' => 'minori', 'title' => '7. Minori, modifiche e prevalenza', 'body' => array( 'Il negozio non è rivolto intenzionalmente a minori non autorizzati a concludere acquisti. Questa informativa può essere aggiornata per modifiche normative o tecniche; la data in alto indica la versione corrente.' ) ),
			),
		),
		'cookie-policy' => array(
			'title'   => 'Cookie Policy',
			'kicker'  => 'Scelte trasparenti',
			'summary' => 'Quali tecnologie locali servono al funzionamento dello Shop e come gestirle dal browser.',
			'updated' => $updated,
			'sections' => array(
				array( 'id' => 'cosa-sono', 'title' => '1. Cosa sono i cookie', 'body' => array( 'I cookie sono piccoli file salvati dal browser. Tecnologie analoghe, come il local storage, possono ricordare sessione, preferenze e stato dell’interfaccia.' ) ),
				array( 'id' => 'necessari', 'title' => '2. Cookie strettamente necessari', 'body' => array( 'WordPress e WooCommerce usano cookie di sessione e sicurezza per autenticazione, carrello, checkout, protezione dei moduli, lingua dell’interfaccia e prevenzione degli abusi. Senza questi strumenti alcune funzioni richieste non possono operare.' ), 'list' => array( 'Sessione WordPress e accesso account.', 'Carrello, prodotti selezionati e aggiornamenti checkout WooCommerce.', 'Nonce e controlli di sicurezza dei moduli.', 'Preferenze tecniche indispensabili alla navigazione.' ) ),
				array( 'id' => 'pagamenti', 'title' => '3. Pagamenti e contenuti esterni', 'body' => array( 'Quando scegli un metodo di pagamento, il relativo prestatore può impostare tecnologie proprie per sicurezza, autenticazione e completamento dell’operazione. Tali strumenti sono regolati anche dalle informative del prestatore selezionato.', 'Le mappe vengono proposte come collegamenti esterni e non vengono incorporate automaticamente nella pagina Contatto.' ) ),
				array( 'id' => 'non-utilizzati', 'title' => '4. Statistiche di visita e profilazione', 'body' => array( 'Solo se lo accetti nel banner, usiamo Google Analytics 4 per statistiche aggregate sulle visite (cookie _ga e _ga_*, durata fino a 2 anni). Senza consenso lo script non viene caricato. Non usiamo cookie pubblicitari né profilazione a fini di marketing.', 'Il banner registra la tua scelta nei cookie tecnici tw_cookie_consent e tw_cookie_preferences (12 mesi).' ) ),
				array( 'id' => 'gestione', 'title' => '5. Come gestire i cookie', 'body' => array( 'Puoi modificare o revocare il consenso in qualsiasi momento dal link “Impostazioni cookie” a piè di pagina, che riapre il banner. Puoi cancellare o bloccare i cookie nelle impostazioni del browser. Il blocco dei cookie necessari può impedire accesso, carrello o checkout. Le scelte sono specifiche del browser e del dispositivo.' ) ),
				array( 'id' => 'contatti-cookie', 'title' => '6. Contatti e aggiornamenti', 'body' => array( "Per domande scrivi a <a href=\"mailto:{$email}\">{$email}</a>. Questa pagina viene aggiornata quando cambiano le tecnologie effettivamente utilizzate." ) ),
			),
		),
		'condizioni-generali-di-vendita' => array(
			'title'   => 'Condizioni generali di vendita',
			'kicker'  => 'Acquisti chiari',
			'summary' => 'Regole applicabili agli ordini effettuati nello Shop Oasi delle Spezie.',
			'updated' => $updated,
			'sections' => array(
				array( 'id' => 'venditore', 'title' => '1. Venditore e ambito', 'body' => array( "Il negozio online oasidellespezie.ch è gestito da <strong>{$name}</strong>, {$identity['uid']}. Le presenti condizioni si applicano esclusivamente agli ordini effettuati sul sito e alla consegna della merce ordinata, per clienti privati e, dove indicato, professionali. Gli ordini possono essere effettuati solo tramite il sito.", 'Prima di inviare l’ordine il cliente vede a schermo le condizioni particolari (prodotto, prezzo, peso, quantità, eventuali particolarità e costo dei servizi) e dispone di un meccanismo per correggere o modificare le proprie scelte. L’invio e la conferma dell’ordine comportano la piena accettazione di tali condizioni e delle presenti condizioni generali. Eventuali accordi individuali scritti prevalgono sul testo generale.' ) ),
				array( 'id' => 'ordine', 'title' => '2. Prodotti e conclusione dell’ordine', 'body' => array( 'Descrizioni, formati, ingredienti, allergeni, origine quando prevista e disponibilità sono indicati nelle schede prodotto o sull’etichetta. Le immagini sono illustrative; variazioni naturali di colore e consistenza non costituiscono difetto. Le offerte presenti sul sito non sono vincolanti.', 'Dopo l’invio ricevi una conferma elettronica dell’ordine. Il contratto si perfeziona con la nostra accettazione, subordinata a disponibilità e controlli antifrode. Ci riserviamo il diritto di rifiutare un ordine; se non possiamo evaderlo, ti avvisiamo via email.' ) ),
				array( 'id' => 'alcolici', 'title' => '2a. Bevande alcoliche', 'body' => array( 'Le bevande alcoliche sono vendute esclusivamente a persone maggiorenni (almeno 18 anni). Ordinandole, il cliente dichiara di avere almeno 18 anni; la dichiarazione viene registrata con l’ordine. Alla consegna o al ritiro può essere richiesto un documento d’identità: se la maggiore età non è dimostrata, la merce non viene consegnata e l’importo delle bevande alcoliche viene rimborsato.' ) ),
				array( 'id' => 'disponibilita', 'title' => '2b. Disponibilità e imballaggi', 'body' => array( 'Il nostro impegno di consegna decade se i nostri fornitori non rispettano i termini di approvvigionamento, nella misura in cui l’indisponibilità non ci sia imputabile. In caso di prodotto non disponibile ti informiamo il prima possibile.', 'Con il passare delle stagioni alcuni imballaggi possono cambiare: ci riserviamo di modificare l’imballaggio al momento della conferma dell’ordine, senza cambiare contenuto e quantità.' ) ),
				array( 'id' => 'prezzi', 'title' => '3. Prezzi, pagamenti e promozioni', 'body' => array( 'I prezzi sono espressi in franchi svizzeri (CHF) e includono l’IVA applicabile e i costi di imballaggio, salvo indicazione chiara diversa per aree professionali. Spedizione e altri costi obbligatori sono mostrati prima della conferma. Non è previsto un ordine minimo né un sovrapprezzo per i piccoli ordini.', 'Il pagamento avviene con i metodi presentati al checkout, tra cui carte Visa e Mastercard, PostFinance, TWINT o bonifico bancario quando abilitati. Coupon, punti e crediti seguono le regole visualizzate e non sono convertibili in denaro, salvo obblighi di legge. In caso di errore manifesto di prezzo contatteremo il cliente prima di procedere.' ) ),
				array( 'id' => 'preparazione', 'title' => '4. Preparazione, spedizione e ritiro', 'body' => array( 'La preparazione ordinaria richiede indicativamente 5–10 giorni lavorativi; gli ordini non vengono elaborati la domenica e nei giorni festivi. Per articoli selezionati a mano, grandi quantitativi o ritardi dovuti all’importazione delle materie prime i tempi possono aumentare; comunicheremo ritardi rilevanti.', "Spediamo esclusivamente in Svizzera, dal lunedì al venerdì, attualmente con Planzer Paket. {$shipping_costs} Le spese di spedizione seguono le tariffe del nostro trasportatore e possono essere adeguate, ad esempio in base all’andamento del prezzo del carburante; il costo effettivo è sempre mostrato al checkout prima dell’ordine.", 'Il ritiro in sede, solo per il Ticino, è disponibile quando selezionabile al checkout e dopo conferma di disponibilità.' ) ),
				array( 'id' => 'controllo', 'title' => '5. Consegna, reclami e difetti', 'body' => array( 'Controlla immediatamente la merce consegnata per escludere difetti evidenti di materiale o lavorazione e danni dovuti al trasporto. Eventuali reclami vanno presentati entro 3 giorni dal ricevimento, se possibile con fotografie, conservando l’imballaggio: trascorso tale termine la consegna si considera accettata, fatti salvi i difetti non riconoscibili al controllo. Una comunicazione rapida ci permette di verificare il caso con il vettore e proporre sostituzione, rimborso o altra soluzione appropriata.', 'Nei limiti consentiti dalla legge, la merce viaggia a rischio del cliente e non rispondiamo degli incidenti avvenuti durante il trasporto; ti assistiamo comunque nella segnalazione al vettore. Le garanzie e i rimedi previsti dal diritto applicabile restano impregiudicati. Non sono difetti il normale calo aromatico dopo apertura, l’uso o conservazione non conformi, né caratteristiche naturali dichiarate.' ) ),
				array( 'id' => 'recesso', 'title' => '6. Modifiche, annullamento e resi', 'body' => array( 'Il diritto svizzero non prevede un diritto generale di recesso per gli acquisti online. Contattaci subito se desideri modificare o annullare un ordine: valuteremo la richiesta finché la preparazione non è iniziata.', 'Per ragioni igieniche e di sicurezza alimentare non accettiamo normalmente resi di alimenti aperti, personalizzati o deperibili. Un reso è possibile solo previo nostro accordo: gli articoli devono essere integri e completi nella confezione originale, con le etichette di riferimento, e accompagnati dalla bolla di consegna. Le spese di spedizione del reso sono a carico del cliente, salvo difetto del prodotto. Il reso è escluso se l’articolo è stato danneggiato o reso inutilizzabile dal cliente o da persona sotto la sua responsabilità. I diritti per prodotti difettosi restano validi.' ) ),
				array( 'id' => 'professionisti', 'title' => '7. Clienti professionali', 'body' => array( 'I clienti professionali possono registrarsi come tali dalla pagina Professionista; l’accesso richiede un account e l’approvazione manuale. Per i primi tre ordini è richiesto il pagamento anticipato.', "Dopo tre ordini regolari i clienti esistenti possono chiedere il pagamento su fattura a 30 giorni scrivendo a <a href=\"mailto:{$email}\">{$email}</a>; la modalità è disponibile solo previa nostra conferma e può essere sospesa in caso di ritardi.", 'Per gli ordini professionali inferiori a CHF 250 d’acquisto sono addebitati CHF 15 di spedizione, salvo diversa indicazione al checkout. Quantità, listini, minimi e trasporto professionale sono quelli mostrati all’account approvato o concordati per iscritto.' ) ),
				array( 'id' => 'dati', 'title' => '8. Protezione dei dati', 'body' => array( 'Trattiamo i dati personali in modo confidenziale e non li vendiamo a terzi. Li utilizziamo per elaborare l’ordine e, solo se ti sei iscritto, per la newsletter. I dettagli, compresi i fornitori coinvolti, sono nella Privacy Policy.' ) ),
				array( 'id' => 'responsabilita', 'title' => '9. Responsabilità, legge e foro', 'body' => array( 'Rispondiamo dei danni al bene acquistato causati da nostra colpa grave e, in generale, secondo la legge applicabile. Nei limiti consentiti, non rispondiamo di danni indiretti, uso improprio dei prodotti o indisponibilità fuori dal nostro ragionevole controllo.', 'Le informazioni pubblicate sul sito hanno scopo divulgativo e informativo, non hanno valore medico o prescrittivo e non sostituiscono il parere del proprio medico.', 'Si applica il diritto svizzero. Il foro competente è Bellinzona; per i consumatori rimangono salvi i fori imperativi previsti dalla legge.' ) ),
			),
		),
		'termini-e-condizioni' => array(
			'title'   => 'Termini e condizioni d’uso',
			'kicker'  => 'Uso del sito',
			'summary' => 'Regole per navigazione, account, contenuti e servizi digitali del sito.',
			'updated' => $updated,
			'sections' => array(
				array( 'id' => 'accettazione', 'title' => '1. Accettazione e disponibilità', 'body' => array( 'Utilizzando il sito accetti questi termini. Possiamo aggiornare funzioni, contenuti e disponibilità per manutenzione, sicurezza o evoluzione del servizio.' ) ),
				array( 'id' => 'account', 'title' => '2. Account e credenziali', 'body' => array( 'Fornisci dati corretti, mantieni riservate le credenziali e comunica accessi sospetti. Ogni account è personale; possiamo limitarlo in caso di frode, abuso o violazione dei termini. Le richieste professionali sono valutate manualmente e non garantiscono l’approvazione.' ) ),
				array( 'id' => 'uso-corretto', 'title' => '3. Uso corretto', 'list' => array( 'Non interferire con sicurezza, disponibilità o prestazioni del sito.', 'Non usare procedure automatizzate abusive, identità false o contenuti illeciti.', 'Non tentare accessi non autorizzati, estrazioni massive o elusione di limiti e prezzi.' ) ),
				array( 'id' => 'contenuti', 'title' => '4. Contenuti e proprietà intellettuale', 'body' => array( 'Marchi, fotografie, testi, ricette, grafica e codice sono protetti dai rispettivi diritti. È consentito l’uso personale del sito; riproduzione commerciale, modifica o ridistribuzione richiedono autorizzazione.' ) ),
				array( 'id' => 'salute', 'title' => '5. Informazioni alimentari e salute', 'body' => array( 'Ingredienti, allergeni e istruzioni vanno verificati sulla scheda e sull’etichetta ricevuta. In caso di allergie o esigenze specifiche contattaci prima dell’ordine.', 'Le informazioni su spezie, piante e tradizioni hanno finalità descrittiva e non sostituiscono il parere medico, una diagnosi o un trattamento. Non interrompere terapie e consulta un professionista sanitario per dubbi.' ) ),
				array( 'id' => 'link', 'title' => '6. Link e servizi di terzi', 'body' => array( 'Link, mappe e servizi di pagamento esterni sono gestiti dai rispettivi fornitori. Non controlliamo contenuti, disponibilità o informative di siti terzi.' ) ),
				array( 'id' => 'legge', 'title' => '7. Responsabilità e diritto applicabile', 'body' => array( 'Adottiamo cura ragionevole per accuratezza e continuità, ma non garantiamo assenza assoluta di errori o interruzioni. Restano ferme le responsabilità non escludibili per legge. Si applica il diritto svizzero, con salvezza dei fori imperativi.' ) ),
			),
		),
		'certificazione' => array(
			'title'   => 'Certificazione biologica',
			'kicker'  => 'Controllo indipendente',
			'summary' => 'Il certificato bio.inspecta 2026 e cosa significa per i prodotti espressamente contrassegnati come biologici.',
			'updated' => $updated,
			'certificate' => true,
			'sections' => array(
				array( 'id' => 'certificato', 'title' => 'Certificato 2026', 'body' => array( '<strong>Numero BVH-62064</strong>, azienda n. 34698, rilasciato da bio.inspecta AG (CH-BIO-006) per L’Oasi delle spezie di Jaunin.', 'Campo: Ordinanza federale sull’agricoltura biologica (CH-Bio). Attività certificate: preparazione, distribuzione/immissione sul mercato e importazione. Gruppi: piante e prodotti vegetali non trasformati; prodotti alimentari trasformati.', '<strong>Validità: 31.12.2026.</strong>' ) ),
				array( 'id' => 'cosa-significa', 'title' => 'Cosa significa', 'body' => array( 'La certificazione attesta i processi e i prodotti inclusi nel campo certificato alla data di emissione. Non significa che ogni articolo dell’assortimento sia biologico: fa fede la dicitura BIO, il riferimento di controllo e l’etichetta del singolo prodotto.' ) ),
				array( 'id' => 'verifica', 'title' => 'Verifica e aggiornamenti', 'body' => array( 'Il PDF pubblicato è il documento di riferimento corrente. Certificati e assortimento possono essere aggiornati; per una verifica relativa a un lotto o articolo specifico contatta il laboratorio prima dell’acquisto.' ) ),
			),
		),
		'domande-frequenti' => array(
			'title'   => 'Domande frequenti',
			'kicker'  => 'Risposte utili',
			'summary' => 'Ordini, laboratorio, consegne, pagamenti, allergeni, punti e accesso professionale.',
			'updated' => $updated,
			'faqs' => array(
				array( 'question' => 'Avete un negozio aperto al pubblico?', 'answer' => 'No. Oasi delle Spezie è un laboratorio senza vetrina su strada. Puoi scegliere il ritiro al checkout quando disponibile e attendere la conferma prima di recarti in sede.' ),
				array( 'question' => 'Quanto richiede la preparazione?', 'answer' => 'Indicativamente 5–10 giorni lavorativi. Selezioni manuali, grandi quantità o picchi di lavoro possono richiedere più tempo.' ),
				array( 'question' => 'Dove spedite?', 'answer' => 'Spediamo in tutta la Svizzera, dal lunedì al venerdì. Le opzioni disponibili per il tuo ordine, compreso il ritiro in sede per il Ticino, sono mostrate al checkout; per i professionisti il costo può dipendere dall’importo dell’ordine.' ),
				array( 'question' => 'Quando la spedizione è gratuita?', 'answer' => ( null !== $shipping['free_from'] ? 'Per i clienti privati la spedizione in Svizzera è gratuita per ordini da CHF ' . oasi_format_chf_amount( (float) $shipping['free_from'] ) . '.' : 'Il costo di spedizione dipende dall’ordine.' ) . ' Il checkout mostra sempre il costo effettivo prima dell’ordine.' ),
				array( 'question' => 'Quali pagamenti accettate?', 'answer' => 'I metodi effettivamente disponibili, tra cui carte, TWINT, PostFinance o bonifico quando abilitati, vengono mostrati al checkout. Non inviare dati carta via email.' ),
				array( 'question' => 'Come verifico ingredienti e allergeni?', 'answer' => 'Consulta scheda prodotto ed etichetta. In caso di allergia, contaminazione crociata o dieta specifica contattaci prima dell’ordine indicando il prodotto.' ),
				array( 'question' => 'Posso restituire un prodotto?', 'answer' => 'In Svizzera non esiste un diritto generale di recesso online. Contattaci subito: gli alimenti aperti, personalizzati o deperibili non sono normalmente restituibili, mentre i diritti per difetti restano validi.' ),
				array( 'question' => 'Come funzionano i punti fedeltà?', 'answer' => 'Saldo, movimenti e possibilità di utilizzo sono mostrati nell’account e al checkout. I punti non sono denaro e seguono le regole visualizzate al momento dell’uso.' ),
				array( 'question' => 'Come richiedo l’accesso professionale?', 'answer' => 'Accedi con il tuo account, apri la pagina Professionista e usa il pulsante “Richiedi la verifica professionale”. Non creare un secondo account: i dati anagrafici vengono letti dall’account esistente.' ),
				array( 'question' => 'Le indicazioni sulle spezie sono consigli medici?', 'answer' => 'No. I contenuti sono informativi e gastronomici e non sostituiscono il parere di un medico o farmacista.' ),
			),
			'sections' => array(),
		),
	);
}

/** Return whether a slug belongs to the legal/help collection. */
function oasi_legal_is_slug( string $slug ): bool {
	return isset( oasi_legal_get_definitions()[ $slug ] );
}

/** Resolve a legal page through WordPress, with a safe canonical fallback. */
function oasi_legal_get_page_url( string $slug ): string {
	$page = get_page_by_path( $slug, OBJECT, 'page' );
	if ( $page instanceof WP_Post && 'publish' === $page->post_status ) {
		$url = get_permalink( $page );
		if ( $url ) {
			return (string) $url;
		}
	}
	return home_url( '/' . trim( $slug, '/' ) . '/' );
}

/** Return the definition belonging to the current queried page. */
function oasi_legal_get_current_definition(): array {
	$post = get_queried_object();
	$slug = $post instanceof WP_Post ? (string) $post->post_name : '';
	return oasi_legal_get_definitions()[ $slug ] ?? array();
}

/** Return the public certificate PDF when the verified upload is present. */
function oasi_legal_get_certificate_url(): string {
	$uploads = wp_upload_dir();
	$path    = trailingslashit( (string) ( $uploads['basedir'] ?? '' ) ) . '2026/01/CERTIFICATION-2026.pdf';
	$url     = trailingslashit( (string) ( $uploads['baseurl'] ?? '' ) ) . '2026/01/CERTIFICATION-2026.pdf';
	return is_file( $path ) ? $url : '';
}

/** Create missing legal pages only for this child theme and never overwrite content. */
function oasi_legal_ensure_pages(): void {
	if ( get_stylesheet() !== 'oasidellespezie-child-theme' ) {
		return;
	}

	// Run only when the set of legal pages changes, not on every request: each
	// get_page_by_path() is a real query whenever any post was saved meanwhile.
	$version = md5( implode( ',', array_keys( oasi_legal_get_definitions() ) ) );
	if ( get_option( 'oasi_legal_pages_version' ) === $version ) {
		return;
	}

	$privacy_id = 0;
	foreach ( oasi_legal_get_definitions() as $slug => $definition ) {
		$page = get_page_by_path( $slug, OBJECT, 'page' );
		if ( ! $page instanceof WP_Post ) {
			$page_id = wp_insert_post(
				array(
					'post_type'    => 'page',
					'post_status'  => 'publish',
					'post_name'    => $slug,
					'post_title'   => $definition['title'],
					'post_content' => $definition['summary'],
				)
			);
			if ( ! is_wp_error( $page_id ) && 'privacy-policy' === $slug ) {
				$privacy_id = (int) $page_id;
			}
		} elseif ( 'privacy-policy' === $slug ) {
			$privacy_id = (int) $page->ID;
		}
	}

	if ( $privacy_id > 0 && ! (int) get_option( 'wp_page_for_privacy_policy', 0 ) ) {
		update_option( 'wp_page_for_privacy_policy', $privacy_id, false );
	}
	update_option( 'oasi_legal_pages_version', $version, false );
}
add_action( 'init', 'oasi_legal_ensure_pages', 8 );

/** Use the native legal template for all canonical legal/help slugs. */
function oasi_legal_template_include( string $template ): string {
	$post = get_queried_object();
	if ( ! $post instanceof WP_Post || ! oasi_legal_is_slug( (string) $post->post_name ) ) {
		return $template;
	}
	$legal_template = get_stylesheet_directory() . '/page-legal.php';
	return is_file( $legal_template ) ? $legal_template : $template;
}
add_filter( 'template_include', 'oasi_legal_template_include', 99 );
