<?php
/**
 * Theme setup and assets.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * URL of a file in this site's uploads folder.
 *
 * Fallback images used to hardcode "/uploads/sites/28/" (the blog ID of the
 * local development copy): in production the site is blog 73, so every such
 * fallback would have been a 404. The uploads base URL is correct everywhere.
 *
 * @param string $relative Path relative to the uploads folder, e.g. "2022/02/a.jpg".
 */
function oasi_upload_url( string $relative ): string {
	$base = function_exists( 'wp_get_upload_dir' ) ? (string) ( wp_get_upload_dir()['baseurl'] ?? '' ) : '';

	return '' !== $base ? trailingslashit( $base ) . ltrim( $relative, '/' ) : home_url( '/wp-content/uploads/' . ltrim( $relative, '/' ) );
}

/**
 * Register child-theme support and navigation menu locations.
 */
function oasi_child_bootstrap(): void {
	add_theme_support( 'woocommerce' );

	register_nav_menus(
		array(
			'primary'       => __( 'Menu Principale (Header)', 'oasidellespezie-child-theme' ),
			'shop_megamenu' => __( 'Oasi Mega Menu Shop (Spice Atlas)', 'oasidellespezie-child-theme' ),
			'menu-1'        => __( 'Menu Principale (Header Legacy)', 'oasidellespezie-child-theme' ),
			'menu-2'        => __( 'Menu Footer', 'oasidellespezie-child-theme' ),
			'utility'       => __( 'Menu Utility / Secondario', 'oasidellespezie-child-theme' ),
		)
	);
}
add_action( 'after_setup_theme', 'oasi_child_bootstrap' );

/**
 * Enqueue the ticinoWEB parent stylesheet followed by the Oasi stylesheet and dedicated assets.
 *
 * The parent registers its main handle with get_stylesheet_uri(), which points
 * to this child stylesheet while a child theme is active. Correct that source
 * locally without modifying the parent theme.
 */
function oasi_child_enqueue_assets(): void {
	$theme_version = wp_get_theme()->get( 'Version' );
	$parent_version = wp_get_theme( get_template() )->get( 'Version' );

	wp_dequeue_style( 'ticinoweb-ai-style' );
	wp_deregister_style( 'ticinoweb-ai-style' );

	wp_enqueue_style(
		'ticinoweb-ai-style',
		get_template_directory_uri() . '/style.css',
		array( 'poppins-font' ),
		$parent_version
	);

	wp_enqueue_style(
		'oasidellespezie-child',
		get_stylesheet_uri(),
		array( 'ticinoweb-ai-style' ),
		$theme_version
	);

	wp_enqueue_style(
		'oasi-header-footer',
		get_stylesheet_directory_uri() . '/assets/css/header-footer.css',
		array( 'oasidellespezie-child' ),
		$theme_version
	);

	wp_enqueue_style(
		'oasi-footer-style',
		get_stylesheet_directory_uri() . '/assets/css/footer.css',
		array( 'oasi-header-footer' ),
		$theme_version
	);

	// Dedicated Header & Mega Menu controller (sticky, desk hover, mobile drilldown, cart sync).
	wp_enqueue_script(
		'oasi-header-megamenu',
		get_stylesheet_directory_uri() . '/assets/js/header-megamenu.js',
		array(),
		$theme_version,
		true
	);

	// Shared Home interactions.
	wp_enqueue_script(
		'oasi-home-script',
		get_stylesheet_directory_uri() . '/assets/js/home.js',
		array(),
		$theme_version,
		true
	);

	// Lightweight responsive disclosures for footer navigation groups.
	wp_enqueue_script(
		'oasi-footer-script',
		get_stylesheet_directory_uri() . '/assets/js/footer.js',
		array(),
		$theme_version,
		true
	);

	if ( is_front_page() || is_home() || ( function_exists( 'is_product' ) && is_product() ) ) {
		wp_enqueue_style(
			'oasi-product-cards',
			get_stylesheet_directory_uri() . '/assets/css/product-cards.css',
			array( 'oasi-header-footer' ),
			$theme_version
		);
	}

	if ( is_front_page() || is_home() ) {
		wp_enqueue_style(
			'oasi-home-style',
			get_stylesheet_directory_uri() . '/assets/css/home.css',
			array( 'oasi-product-cards' ),
			$theme_version
		);

		wp_enqueue_script(
			'oasi-bestseller-ribbon',
			get_stylesheet_directory_uri() . '/assets/js/bestseller-ribbon.js',
			array(),
			$theme_version,
			true
		);
	}

	if ( function_exists( 'is_shop' ) && function_exists( 'is_product_taxonomy' ) && ( is_shop() || is_product_taxonomy() ) ) {
		wp_enqueue_style(
			'oasi-shop-style',
			get_stylesheet_directory_uri() . '/assets/css/shop.css',
			array( 'oasi-header-footer' ),
			$theme_version
		);

		wp_enqueue_script(
			'oasi-shop-script',
			get_stylesheet_directory_uri() . '/assets/js/shop.js',
			array(),
			$theme_version,
			true
		);

		wp_localize_script(
			'oasi-shop-script',
			'oasiShopConfig',
			array(
				'partialParam' => 'oasi_shop_partial',
				'loadingText'  => __( 'Aggiornamento prodotti…', 'oasidellespezie-child-theme' ),
				'errorText'    => __( 'Impossibile aggiornare il catalogo.', 'oasidellespezie-child-theme' ),
			)
		);
	}

	if ( function_exists( 'is_product' ) && is_product() ) {
		wp_enqueue_style(
			'oasi-single-product-style',
			get_stylesheet_directory_uri() . '/assets/css/single-product.css',
			array( 'oasi-product-cards' ),
			$theme_version
		);

		wp_enqueue_script(
			'oasi-single-product-script',
			get_stylesheet_directory_uri() . '/assets/js/single-product.js',
			array(),
			$theme_version,
			true
		);
	}

	if ( function_exists( 'is_singular' ) && is_singular( 'post' ) ) {
		wp_enqueue_style(
			'oasi-single-post-style',
			get_stylesheet_directory_uri() . '/assets/css/single-post.css',
			array( 'oasi-header-footer' ),
			$theme_version
		);
	}

	if ( is_page( 'chi-siamo' ) || is_page_template( 'page-chi-siamo.php' ) ) {
		wp_enqueue_style(
			'oasi-about-style',
			get_stylesheet_directory_uri() . '/assets/css/about.css',
			array( 'oasi-header-footer' ),
			$theme_version
		);

		wp_enqueue_script(
			'oasi-about-script',
			get_stylesheet_directory_uri() . '/assets/js/about.js',
			array(),
			$theme_version,
			true
		);
	}

	// Blog archives, search and 404 reuse the News page styling.
	$is_blog_listing = function_exists( 'is_archive' ) && ( ( is_archive() && ! ( function_exists( 'is_woocommerce' ) && is_woocommerce() ) ) || is_search() || is_404() );
	if ( $is_blog_listing ) {
		wp_enqueue_style(
			'oasi-news-style',
			get_stylesheet_directory_uri() . '/assets/css/news.css',
			array( 'oasi-header-footer' ),
			$theme_version
		);
		wp_add_inline_style(
			'oasi-news-style',
			'.oasi-not-found__search{display:flex;gap:10px;max-width:560px;margin:8px 0 20px}.oasi-not-found__search input{flex:1;min-width:0;min-height:48px;padding:0 18px;border:1px solid var(--oasi-border-color,#e8e2d8);border-radius:999px;background:#fff;font:inherit}.oasi-not-found__search input:focus-visible{outline:2px solid var(--oasi-color-primary,#8b3a2b);outline-offset:2px}.oasi-not-found .oasi-btn{display:inline-flex;align-items:center;justify-content:center;min-height:48px;padding:0 24px;border-radius:999px;border:1px solid var(--oasi-color-primary,#8b3a2b);font:inherit;font-weight:600;text-decoration:none;cursor:pointer;transition:background-color .2s,color .2s}.oasi-not-found .oasi-btn--primary{background:var(--oasi-color-primary,#8b3a2b);color:#fff}.oasi-not-found .oasi-btn--primary:hover{background:var(--oasi-color-primary-dark,#68261a)}.oasi-not-found .oasi-btn--secondary{background:transparent;color:var(--oasi-color-primary,#8b3a2b)}.oasi-not-found .oasi-btn--secondary:hover{background:var(--oasi-color-primary,#8b3a2b);color:#fff}.oasi-not-found__links{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:64px}.oasi-news-page .nav-links{display:flex;gap:8px;justify-content:center;margin:32px 0}'
		);
	}

	if ( is_page( 'scoprite-le-nostre-novita' ) || is_page( 16465 ) || is_page_template( 'page-scoprite-le-nostre-novita.php' ) ) {
		wp_enqueue_style(
			'oasi-news-style',
			get_stylesheet_directory_uri() . '/assets/css/news.css',
			array( 'oasi-header-footer' ),
			$theme_version
		);

		wp_enqueue_script(
			'oasi-news-script',
			get_stylesheet_directory_uri() . '/assets/js/news.js',
			array(),
			$theme_version,
			true
		);
	}

	if ( is_page( 'contatto' ) || is_page_template( 'page-contatto.php' ) ) {
		wp_enqueue_style(
			'oasi-contact-style',
			get_stylesheet_directory_uri() . '/assets/css/contact.css',
			array( 'oasi-header-footer' ),
			$theme_version
		);

		// Contact form: submissions go to the parent handler (inc/form-handler.php).
		wp_enqueue_script(
			'oasi-contact-form',
			get_stylesheet_directory_uri() . '/assets/js/contact-form.js',
			array(),
			$theme_version,
			true
		);

	}

	if ( is_page( 'catalogo-professionista' ) || is_page_template( 'page-catalogo-professionista.php' ) ) {
		wp_enqueue_style(
			'oasi-professional-style',
			get_stylesheet_directory_uri() . '/assets/css/professional.css',
			array( 'oasi-header-footer' ),
			$theme_version
		);

		wp_enqueue_script(
			'oasi-professional-script',
			get_stylesheet_directory_uri() . '/assets/js/professional.js',
			array(),
			$theme_version,
			true
		);
	}

	$legal_slugs = array( 'impressum', 'privacy-policy', 'cookie-policy', 'condizioni-generali-di-vendita', 'termini-e-condizioni', 'certificazione', 'domande-frequenti' );
	if ( is_page( $legal_slugs ) || is_page_template( 'page-legal.php' ) ) {
		wp_enqueue_style(
			'oasi-legal-style',
			get_stylesheet_directory_uri() . '/assets/css/legal.css',
			array( 'oasi-header-footer' ),
			$theme_version
		);
		wp_enqueue_script(
			'oasi-legal-script',
			get_stylesheet_directory_uri() . '/assets/js/legal.js',
			array(),
			$theme_version,
			true
		);
	}

	if ( is_page( 'richiesta-professionale' ) || is_page_template( 'page-richiesta-professionale.php' ) ) {
		wp_enqueue_style(
			'oasi-professional-application-style',
			get_stylesheet_directory_uri() . '/assets/css/professional-application.css',
			array( 'oasi-header-footer' ),
			$theme_version
		);
		wp_enqueue_script(
			'oasi-professional-application-script',
			get_stylesheet_directory_uri() . '/assets/js/professional-application.js',
			array(),
			$theme_version,
			true
		);
	}

	if ( function_exists( 'is_account_page' ) && is_account_page() ) {
		wp_enqueue_style(
			'oasi-account-style',
			get_stylesheet_directory_uri() . '/assets/css/account.css',
			array( 'oasi-header-footer' ),
			$theme_version
		);

		wp_enqueue_script(
			'oasi-account-script',
			get_stylesheet_directory_uri() . '/assets/js/account.js',
			array(),
			$theme_version,
			true
		);
	}

	if ( function_exists( 'is_cart' ) && is_cart() ) {
		wp_enqueue_style(
			'oasi-cart-style',
			get_stylesheet_directory_uri() . '/assets/css/cart.css',
			array( 'oasi-header-footer' ),
			$theme_version
		);
	}

	if ( function_exists( 'oasi_is_main_checkout' ) && oasi_is_main_checkout() ) {
		wp_enqueue_style(
			'oasi-checkout-style',
			get_stylesheet_directory_uri() . '/assets/css/checkout.css',
			array( 'oasi-header-footer' ),
			$theme_version
		);
	}

}
add_action( 'wp_enqueue_scripts', 'oasi_child_enqueue_assets', 20 );
