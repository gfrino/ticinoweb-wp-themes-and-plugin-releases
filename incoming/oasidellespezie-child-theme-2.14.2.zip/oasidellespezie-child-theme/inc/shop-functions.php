<?php
/**
 * WooCommerce product archive filters and rendering helpers.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Determine if the current view is the Shop catalog (shop archive or product taxonomy).
 *
 * Strictly excludes single product pages, front page, and standard content pages.
 *
 * @return bool
 */
function oasi_is_shop_catalog(): bool {
	if ( function_exists( 'is_product' ) && is_product() ) {
		return false;
	}

	return ( function_exists( 'is_shop' ) && is_shop() )
		|| ( function_exists( 'is_product_taxonomy' ) && is_product_taxonomy() )
		|| ( function_exists( 'is_post_type_archive' ) && is_post_type_archive( 'product' ) );
}

/**
 * Normalize the public catalog filters.
 *
 * @param array $source Raw request values.
 * @return array{
 *     search:string,
 *     categories:string[],
 *     min_price:?float,
 *     max_price:?float,
 *     in_stock:bool,
 *     on_sale:bool,
 *     orderby:string
 * }
 */
function oasi_shop_get_filters( array $source ): array {
	$allowed_orderby = array( 'menu_order', 'popularity', 'rating', 'date', 'price', 'price-desc' );
	$orderby         = isset( $source['orderby'] ) && is_scalar( $source['orderby'] ) ? sanitize_key( (string) wp_unslash( $source['orderby'] ) ) : 'menu_order';
	// Query strings bypass the page cache: cap the categories so a crafted URL
	// cannot trigger hundreds of term lookups, and ignore non-scalar values.
	$raw_categories  = isset( $source['oasi_cat'] ) ? array_slice( array_filter( (array) wp_unslash( $source['oasi_cat'] ), 'is_scalar' ), 0, 20 ) : array();
	$categories      = array();

	foreach ( $raw_categories as $raw_category ) {
		$slug = sanitize_title( (string) $raw_category );
		if ( '' !== $slug && null !== term_exists( $slug, 'product_cat' ) && ! in_array( $slug, $categories, true ) ) {
			$categories[] = $slug;
		}
	}

	$normalize_price = static function ( mixed $value ): ?float {
		if ( ! is_scalar( $value ) || '' === $value || ! is_numeric( $value ) || (float) $value < 0 ) {
			return null;
		}

		return (float) wc_format_decimal( $value );
	};

	return array(
		'search'     => isset( $source['oasi_q'] ) && is_scalar( $source['oasi_q'] ) ? sanitize_text_field( (string) wp_unslash( $source['oasi_q'] ) ) : '',
		'categories' => $categories,
		'min_price'  => $normalize_price( $source['min_price'] ?? '' ),
		'max_price'  => $normalize_price( $source['max_price'] ?? '' ),
		'in_stock'   => ! empty( $source['oasi_in_stock'] ),
		'on_sale'    => ! empty( $source['oasi_on_sale'] ),
		'orderby'    => in_array( $orderby, $allowed_orderby, true ) ? $orderby : 'menu_order',
	);
}

/**
 * Apply Oasi filters to the existing WooCommerce main archive query.
 *
 * @param WP_Query $query Product archive query.
 */
function oasi_shop_apply_product_query( $query ): void {
	if ( ! ( is_shop() || is_product_taxonomy() ) ) {
		return;
	}

	$filters = oasi_shop_get_filters( $_GET ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

	// WooCommerce reads these two values directly from the request later when
	// composing lookup-table SQL, so pass only the normalized values onward.
	foreach ( array( 'min_price', 'max_price' ) as $price_key ) {
		if ( null === $filters[ $price_key ] ) {
			unset( $_GET[ $price_key ] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		} else {
			$_GET[ $price_key ] = wc_format_decimal( $filters[ $price_key ] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}
	}

	if ( '' !== $filters['search'] ) {
		$query->set( 's', $filters['search'] );
	}

	if ( $filters['categories'] ) {
		$tax_query   = (array) $query->get( 'tax_query' );
		$tax_query[] = array(
			'taxonomy' => 'product_cat',
			'field'    => 'slug',
			'terms'    => $filters['categories'],
			'operator' => 'IN',
		);
		$query->set( 'tax_query', $tax_query );
	}

	if ( $filters['in_stock'] ) {
		$meta_query   = (array) $query->get( 'meta_query' );
		$meta_query[] = array(
			'key'     => '_stock_status',
			'value'   => 'instock',
			'compare' => '=',
		);
		$query->set( 'meta_query', $meta_query );
	}

	if ( $filters['on_sale'] && function_exists( 'wc_get_product_ids_on_sale' ) ) {
		$sale_ids     = array_map( 'absint', wc_get_product_ids_on_sale() );
		$current_ids  = array_filter( array_map( 'absint', (array) $query->get( 'post__in' ) ) );
		$filtered_ids = $current_ids ? array_intersect( $current_ids, $sale_ids ) : $sale_ids;
		$query->set( 'post__in', $filtered_ids ? array_values( $filtered_ids ) : array( 0 ) );
	}
}
add_action( 'woocommerce_product_query', 'oasi_shop_apply_product_query' );

/**
 * Return the filters for the current archive, including its taxonomy term.
 *
 * @return array{
 *     search:string,
 *     categories:string[],
 *     min_price:?float,
 *     max_price:?float,
 *     in_stock:bool,
 *     on_sale:bool,
 *     orderby:string
 * }
 */
function oasi_shop_get_current_filters(): array {
	$filters = oasi_shop_get_filters( $_GET ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

	if ( ! $filters['categories'] && function_exists( 'is_product_category' ) && is_product_category() ) {
		$term = get_queried_object();
		if ( $term instanceof WP_Term ) {
			$filters['categories'][] = $term->slug;
		}
	}

	return $filters;
}

/**
 * Return the canonical base URL used by every catalog filter control.
 */
function oasi_shop_get_base_url(): string {
	$url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' );

	return is_string( $url ) && '' !== $url ? $url : home_url( '/shop/' );
}

/**
 * Build a canonical catalog URL from current filters and overrides.
 *
 * A null override removes a key; pagination and the internal partial-response
 * marker are always removed.
 *
 * @param array $overrides Filter values to replace or remove.
 */
function oasi_shop_build_filter_url( array $overrides = array() ): string {
	$filters = oasi_shop_get_current_filters();
	$args    = array(
		'oasi_q'        => $filters['search'],
		'oasi_cat'      => $filters['categories'],
		'min_price'     => $filters['min_price'],
		'max_price'     => $filters['max_price'],
		'oasi_in_stock' => $filters['in_stock'] ? '1' : null,
		'oasi_on_sale'  => $filters['on_sale'] ? '1' : null,
		'orderby'       => 'menu_order' !== $filters['orderby'] ? $filters['orderby'] : null,
	);

	foreach ( $overrides as $key => $value ) {
		if ( array_key_exists( $key, $args ) ) {
			$args[ $key ] = $value;
		}
	}

	$args = array_filter(
		$args,
		static fn ( mixed $value ): bool => null !== $value && '' !== $value && array() !== $value
	);

	return add_query_arg( $args, oasi_shop_get_base_url() );
}

/**
 * Preserve the current pagination path while removing the internal AJAX flag.
 */
function oasi_shop_get_response_url(): string {
	global $wp;

	$filter_url = oasi_shop_build_filter_url();
	$query      = (string) wp_parse_url( $filter_url, PHP_URL_QUERY );
	$request    = isset( $wp->request ) ? trim( (string) $wp->request, '/' ) : '';
	$base       = home_url( '/' . ( '' !== $request ? trailingslashit( $request ) : '' ) );

	return '' !== $query ? $base . '?' . $query : $base;
}

/**
 * Return the catalog price bounds from WooCommerce's lookup table.
 *
 * @return array{min:float,max:float}
 */
function oasi_shop_get_price_bounds(): array {
	global $wpdb;

	$bounds = $wpdb->get_row(
		"SELECT FLOOR(MIN(lookup.min_price)) AS min_price, CEIL(MAX(lookup.max_price)) AS max_price
		FROM {$wpdb->wc_product_meta_lookup} lookup
		INNER JOIN {$wpdb->posts} posts ON posts.ID = lookup.product_id
		WHERE posts.post_type = 'product' AND posts.post_status = 'publish'"
	);

	return array(
		'min' => isset( $bounds->min_price ) ? max( 0, (float) $bounds->min_price ) : 0,
		'max' => isset( $bounds->max_price ) ? max( 0, (float) $bounds->max_price ) : 0,
	);
}

/**
 * Return the WooCommerce product categories for the catalog filter.
 *
 * Categories come straight from Prodotti -> Categorie, in the order set there
 * (drag and drop), with sub-categories right after their parent. Empty
 * categories are left out unless currently selected.
 *
 * @param array<int, string> $selected Selected category slugs.
 * @return array<int, array{slug: string, name: string, count: int, depth: int}>
 */
function oasi_shop_get_filter_categories( array $selected = array() ): array {
	$terms = get_terms(
		array(
			'taxonomy'   => 'product_cat',
			'hide_empty' => false,
			'orderby'    => 'menu_order',
			'order'      => 'ASC',
		)
	);

	if ( is_wp_error( $terms ) || ! is_array( $terms ) ) {
		return array();
	}

	$children = array();
	foreach ( $terms as $term ) {
		$children[ (int) $term->parent ][] = $term;
	}

	$list = array();
	$walk = static function ( int $parent, int $depth ) use ( &$walk, &$list, $children, $selected ): void {
		foreach ( $children[ $parent ] ?? array() as $term ) {
			$count = (int) $term->count;
			if ( 'uncategorized' !== $term->slug && ( $count > 0 || in_array( $term->slug, $selected, true ) ) ) {
				$list[] = array(
					'slug'  => (string) $term->slug,
					'name'  => html_entity_decode( (string) $term->name, ENT_QUOTES, 'UTF-8' ),
					'count' => $count,
					'depth' => $depth,
				);
			}
			$walk( (int) $term->term_id, $depth + 1 );
		}
	};
	$walk( 0, 0 );

	return $list;
}

/**
 * Render the single catalog filter form used by desktop and mobile.
 *
 * @param array $filters Normalized filters.
 */
function oasi_shop_render_filters( array $filters ): void {
	$categories = oasi_shop_get_filter_categories( $filters['categories'] );
	$bounds     = oasi_shop_get_price_bounds();
	?>
	<div class="oasi-shop__drawer-head">
		<h2 id="oasi-shop-filter-title"><?php esc_html_e( 'Filtra il catalogo', 'oasidellespezie-child-theme' ); ?></h2>
		<button type="button" class="oasi-shop__drawer-close" data-oasi-filter-close aria-label="<?php esc_attr_e( 'Chiudi i filtri', 'oasidellespezie-child-theme' ); ?>">
			<span aria-hidden="true">&times;</span>
		</button>
	</div>
	<form class="oasi-shop-filter" id="oasi-shop-filter-form" action="<?php echo esc_url( oasi_shop_get_base_url() ); ?>" method="get" data-oasi-shop-form>
		<details class="oasi-shop-filter__section oasi-shop-filter__section--categories oasi-shop-filter__accordion" <?php echo $filters['categories'] ? 'open' : ''; ?>>
			<summary>
				<h3><?php esc_html_e( 'Categorie', 'oasidellespezie-child-theme' ); ?></h3>
				<?php if ( $filters['categories'] ) : ?>
					<span class="oasi-shop-filter__accordion-meta">
						<?php
						/* translators: %d: number of selected categories. */
						echo esc_html( sprintf( _n( '%d selezionata', '%d selezionate', count( $filters['categories'] ), 'oasidellespezie-child-theme' ), count( $filters['categories'] ) ) );
						?>
					</span>
				<?php endif; ?>
			</summary>
			<div class="oasi-shop-filter__categories oasi-shop-filter__options">
				<?php foreach ( $categories as $category ) : ?>
					<label class="oasi-shop-filter__check<?php echo $category['depth'] > 0 ? ' oasi-shop-filter__check--child' : ''; ?>">
						<input type="checkbox" name="oasi_cat[]" value="<?php echo esc_attr( $category['slug'] ); ?>" <?php checked( in_array( $category['slug'], $filters['categories'], true ) ); ?>>
						<span><?php echo esc_html( $category['name'] ); ?></span>
						<small><?php echo esc_html( (string) $category['count'] ); ?></small>
					</label>
				<?php endforeach; ?>
			</div>
		</details>

		<div class="oasi-shop-filter__section">
			<h3><?php esc_html_e( 'Fascia di prezzo', 'oasidellespezie-child-theme' ); ?></h3>
			<div class="oasi-shop-filter__price">
				<label>
					<span><?php esc_html_e( 'Da', 'oasidellespezie-child-theme' ); ?></span>
					<span class="oasi-shop-filter__money"><b>CHF</b><input type="number" name="min_price" min="<?php echo esc_attr( (string) $bounds['min'] ); ?>" max="<?php echo esc_attr( (string) $bounds['max'] ); ?>" step="0.05" value="<?php echo esc_attr( null !== $filters['min_price'] ? (string) $filters['min_price'] : '' ); ?>"></span>
				</label>
				<span aria-hidden="true">—</span>
				<label>
					<span><?php esc_html_e( 'A', 'oasidellespezie-child-theme' ); ?></span>
					<span class="oasi-shop-filter__money"><b>CHF</b><input type="number" name="max_price" min="<?php echo esc_attr( (string) $bounds['min'] ); ?>" max="<?php echo esc_attr( (string) $bounds['max'] ); ?>" step="0.05" value="<?php echo esc_attr( null !== $filters['max_price'] ? (string) $filters['max_price'] : '' ); ?>"></span>
				</label>
			</div>
		</div>

		<div class="oasi-shop-filter__section oasi-shop-filter__toggles">
			<label class="oasi-shop-filter__toggle">
				<input type="checkbox" name="oasi_in_stock" value="1" <?php checked( $filters['in_stock'] ); ?>>
				<span class="oasi-shop-filter__switch" aria-hidden="true"></span>
				<span><?php esc_html_e( 'Solo disponibili', 'oasidellespezie-child-theme' ); ?></span>
			</label>
			<label class="oasi-shop-filter__toggle">
				<input type="checkbox" name="oasi_on_sale" value="1" <?php checked( $filters['on_sale'] ); ?>>
				<span class="oasi-shop-filter__switch" aria-hidden="true"></span>
				<span><?php esc_html_e( 'Solo in offerta', 'oasidellespezie-child-theme' ); ?></span>
			</label>
		</div>

		<div class="oasi-shop-filter__actions">
			<a href="<?php echo esc_url( oasi_shop_get_base_url() ); ?>" class="oasi-shop-filter__reset" data-oasi-filter-link><?php esc_html_e( 'Azzera', 'oasidellespezie-child-theme' ); ?></a>
			<button type="submit" class="oasi-shop-filter__apply"><?php esc_html_e( 'Mostra i prodotti', 'oasidellespezie-child-theme' ); ?></button>
		</div>
	</form>
	<?php
}

/**
 * Render the archive toolbar. Search and order values are mirrored into the
 * single filter form by JavaScript before submission, avoiding duplicate names.
 *
 * @param array $filters Normalized filters.
 */
function oasi_shop_render_toolbar( array $filters ): void {
	?>
	<div class="oasi-shop-toolbar">
		<div class="oasi-shop-toolbar__search">
			<label class="screen-reader-text" for="oasi-shop-search"><?php esc_html_e( 'Cerca nel catalogo', 'oasidellespezie-child-theme' ); ?></label>
			<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="11" cy="11" r="8"></circle><path d="m21 21-4.35-4.35"></path></svg>
			<input type="search" id="oasi-shop-search" name="oasi_q" form="oasi-shop-filter-form" value="<?php echo esc_attr( $filters['search'] ); ?>" placeholder="<?php esc_attr_e( 'Cerca spezie, miscele, tè…', 'oasidellespezie-child-theme' ); ?>" autocomplete="off" data-oasi-search>
		</div>
		<button type="button" class="oasi-shop-toolbar__filter-button" data-oasi-filter-open aria-controls="oasi-shop-filters" aria-expanded="false">
			<span><?php esc_html_e( 'Filtri', 'oasidellespezie-child-theme' ); ?></span>
			<span class="oasi-shop-toolbar__filter-count" data-oasi-filter-count><?php echo esc_html( (string) oasi_shop_count_active_filters( $filters ) ); ?></span>
		</button>
		<label class="oasi-shop-toolbar__sort">
			<span><?php esc_html_e( 'Ordina', 'oasidellespezie-child-theme' ); ?></span>
			<select name="orderby" form="oasi-shop-filter-form" data-oasi-orderby>
				<option value="menu_order" <?php selected( $filters['orderby'], 'menu_order' ); ?>><?php esc_html_e( 'In evidenza', 'oasidellespezie-child-theme' ); ?></option>
				<option value="popularity" <?php selected( $filters['orderby'], 'popularity' ); ?>><?php esc_html_e( 'Più venduti', 'oasidellespezie-child-theme' ); ?></option>
				<option value="rating" <?php selected( $filters['orderby'], 'rating' ); ?>><?php esc_html_e( 'Valutazione', 'oasidellespezie-child-theme' ); ?></option>
				<option value="date" <?php selected( $filters['orderby'], 'date' ); ?>><?php esc_html_e( 'Più recenti', 'oasidellespezie-child-theme' ); ?></option>
				<option value="price" <?php selected( $filters['orderby'], 'price' ); ?>><?php esc_html_e( 'Prezzo crescente', 'oasidellespezie-child-theme' ); ?></option>
				<option value="price-desc" <?php selected( $filters['orderby'], 'price-desc' ); ?>><?php esc_html_e( 'Prezzo decrescente', 'oasidellespezie-child-theme' ); ?></option>
			</select>
		</label>
	</div>
	<?php
}

/**
 * Count filters that materially narrow or reorder the archive.
 *
 * @param array $filters Normalized filters.
 */
function oasi_shop_count_active_filters( array $filters ): int {
	$count  = count( $filters['categories'] );
	$count += '' !== $filters['search'] ? 1 : 0;
	$count += null !== $filters['min_price'] ? 1 : 0;
	$count += null !== $filters['max_price'] ? 1 : 0;
	$count += $filters['in_stock'] ? 1 : 0;
	$count += $filters['on_sale'] ? 1 : 0;

	return $count;
}

/**
 * Render removable chips for each active filter.
 *
 * @param array $filters Normalized filters.
 */
function oasi_shop_render_active_filters( array $filters ): void {
	$chips = array();

	if ( '' !== $filters['search'] ) {
		$chips[] = array( 'label' => sprintf( __( 'Ricerca: %s', 'oasidellespezie-child-theme' ), $filters['search'] ), 'url' => oasi_shop_build_filter_url( array( 'oasi_q' => null ) ) );
	}

	foreach ( $filters['categories'] as $slug ) {
		$term = get_term_by( 'slug', $slug, 'product_cat' );
		if ( $term && ! is_wp_error( $term ) ) {
			$remaining = array_values( array_diff( $filters['categories'], array( $slug ) ) );
			$chips[]   = array( 'label' => $term->name, 'url' => oasi_shop_build_filter_url( array( 'oasi_cat' => $remaining ) ) );
		}
	}

	if ( null !== $filters['min_price'] ) {
		$chips[] = array( 'label' => sprintf( __( 'Da CHF %s', 'oasidellespezie-child-theme' ), wc_format_localized_price( $filters['min_price'] ) ), 'url' => oasi_shop_build_filter_url( array( 'min_price' => null ) ) );
	}
	if ( null !== $filters['max_price'] ) {
		$chips[] = array( 'label' => sprintf( __( 'Fino a CHF %s', 'oasidellespezie-child-theme' ), wc_format_localized_price( $filters['max_price'] ) ), 'url' => oasi_shop_build_filter_url( array( 'max_price' => null ) ) );
	}
	if ( $filters['in_stock'] ) {
		$chips[] = array( 'label' => __( 'Disponibili', 'oasidellespezie-child-theme' ), 'url' => oasi_shop_build_filter_url( array( 'oasi_in_stock' => null ) ) );
	}
	if ( $filters['on_sale'] ) {
		$chips[] = array( 'label' => __( 'In offerta', 'oasidellespezie-child-theme' ), 'url' => oasi_shop_build_filter_url( array( 'oasi_on_sale' => null ) ) );
	}

	if ( ! $chips ) {
		return;
	}
	?>
	<div class="oasi-shop-active" data-oasi-active-filters>
		<div class="oasi-shop-active__chips">
			<?php foreach ( $chips as $chip ) : ?>
				<a href="<?php echo esc_url( $chip['url'] ); ?>" class="oasi-shop-chip" data-oasi-filter-link>
					<span><?php echo esc_html( $chip['label'] ); ?></span><span aria-hidden="true">&times;</span>
				</a>
			<?php endforeach; ?>
		</div>
		<a href="<?php echo esc_url( oasi_shop_get_base_url() ); ?>" class="oasi-shop-active__clear" data-oasi-filter-link><?php esc_html_e( 'Azzera tutto', 'oasidellespezie-child-theme' ); ?></a>
	</div>
	<?php
}

/**
 * Render result count, loop and pagination from the active WooCommerce query.
 */
function oasi_shop_render_results(): void {
	$filters  = oasi_shop_get_current_filters();
	?>
	<div class="oasi-shop-results__summary" data-oasi-result-summary>
		<?php oasi_shop_render_active_filters( $filters ); ?>
		<div class="oasi-shop-results__count"><?php woocommerce_result_count(); ?></div>
	</div>
	<?php

	woocommerce_output_all_notices();

	if ( woocommerce_product_loop() ) {
		woocommerce_product_loop_start();
		while ( have_posts() ) {
			the_post();
			do_action( 'woocommerce_shop_loop' );
			wc_get_template_part( 'content', 'product' );
		}
		woocommerce_product_loop_end();
		woocommerce_pagination();
	} else {
		do_action( 'woocommerce_no_products_found' );
	}
}

/**
 * Return archive fragments for progressive AJAX navigation.
 */
function oasi_shop_maybe_send_partial_response(): void {
	// Read-only public archive request; no nonce is necessary.
	$is_partial = isset( $_GET['oasi_shop_partial'] ) && '1' === (string) wp_unslash( $_GET['oasi_shop_partial'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( ! $is_partial || 'GET' !== strtoupper( (string) ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) || ! ( is_shop() || is_product_taxonomy() ) ) {
		return;
	}

	$filters = oasi_shop_get_current_filters();
	ob_start();
	oasi_shop_render_results();
	$results = (string) ob_get_clean();

	ob_start();
	oasi_shop_render_active_filters( $filters );
	$active_filters = (string) ob_get_clean();

	ob_start();
	woocommerce_result_count();
	$result_count = (string) ob_get_clean();

	wp_send_json_success(
		array(
			'results'       => $results,
			'activeFilters' => $active_filters,
			'resultCount'   => $result_count,
			'documentTitle' => wp_get_document_title(),
			'url'           => oasi_shop_get_response_url(),
		)
	);
}
add_action( 'template_redirect', 'oasi_shop_maybe_send_partial_response' );

/**
 * Shipping figures read from the WooCommerce settings (zone "Svizzera").
 *
 * The theme used to hardcode "CHF 90" in header, home, product page and legal
 * texts while WooCommerce actually granted free shipping from CHF 80: customers
 * were shown one threshold and charged by another. Everything now reads the
 * enabled methods, cached for a day and refreshed when shipping settings change.
 *
 * @return array{free_from: float|null, flat_rate: float|null, pickup: bool}
 */
function oasi_shipping_facts(): array {
	$facts = function_exists( 'get_transient' ) ? get_transient( 'oasi_shipping_facts' ) : false;
	if ( is_array( $facts ) ) {
		return $facts;
	}

	$facts = array(
		'free_from' => null,
		'flat_rate' => null,
		'pickup'    => false,
	);

	if ( class_exists( 'WC_Shipping_Zones' ) ) {
		foreach ( WC_Shipping_Zones::get_zones() as $zone ) {
			$codes = array_map( static fn( $location ): string => (string) $location->code, (array) ( $zone['zone_locations'] ?? array() ) );
			if ( ! in_array( 'CH', $codes, true ) ) {
				continue;
			}
			foreach ( (array) ( $zone['shipping_methods'] ?? array() ) as $method ) {
				if ( 'yes' !== $method->enabled ) {
					continue;
				}
				if ( 'free_shipping' === $method->id && in_array( $method->get_option( 'requires' ), array( 'min_amount', 'either', 'both' ), true ) && is_numeric( $method->get_option( 'min_amount' ) ) ) {
					$facts['free_from'] = (float) $method->get_option( 'min_amount' );
				} elseif ( 'flat_rate' === $method->id && is_numeric( $method->get_option( 'cost' ) ) ) {
					$facts['flat_rate'] = (float) $method->get_option( 'cost' );
				} elseif ( 'local_pickup' === $method->id ) {
					$facts['pickup'] = true;
				}
			}
		}
	}

	if ( function_exists( 'set_transient' ) ) {
		set_transient( 'oasi_shipping_facts', $facts, DAY_IN_SECONDS );
	}

	return $facts;
}

/**
 * Format an amount in CHF without useless decimals ("80" but "10.50").
 *
 * @param float $amount Amount.
 */
function oasi_format_chf_amount( float $amount ): string {
	return floor( $amount ) === $amount ? number_format( $amount, 0, '.', "'" ) : number_format( $amount, 2, '.', "'" );
}

/**
 * Free-shipping threshold as text ("80"), or '' when there is none.
 */
function oasi_free_shipping_threshold(): string {
	$free = oasi_shipping_facts()['free_from'];

	return null === $free ? '' : oasi_format_chf_amount( (float) $free );
}

/**
 * Forget the cached shipping figures when WooCommerce shipping settings change.
 *
 * @param string $option Option name.
 */
function oasi_shipping_facts_flush( string $option = '' ): void {
	if ( '' === $option || str_starts_with( $option, 'woocommerce_free_shipping_' ) || str_starts_with( $option, 'woocommerce_flat_rate_' ) || str_starts_with( $option, 'woocommerce_local_pickup_' ) ) {
		delete_transient( 'oasi_shipping_facts' );
	}
}
if ( function_exists( 'add_action' ) ) {
	add_action( 'updated_option', 'oasi_shipping_facts_flush' );
	add_action( 'added_option', 'oasi_shipping_facts_flush' );
	add_action( 'woocommerce_shipping_zone_method_added', static fn() => oasi_shipping_facts_flush() );
	add_action( 'woocommerce_shipping_zone_method_deleted', static fn() => oasi_shipping_facts_flush() );
	add_action( 'woocommerce_shipping_zone_method_status_toggled', static fn() => oasi_shipping_facts_flush() );
}
