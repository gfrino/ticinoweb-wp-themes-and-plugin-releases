<?php
/**
 * Dynamic CMS fields and data helpers for the Oasi Chi siamo page.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return the four real team members used to initialize the CMS once.
 *
 * The frontend never reads this array directly: after initialization the
 * editable CMS option is the only source of truth.
 *
 * @return array<int, array<string, int|string>>
 */
function oasi_about_default_team(): array {
	return array(
		array(
			'image_id' => 36542,
			'name'     => 'Brigitte',
			'role'     => 'Nostra direttrice e creatrice di miscele MIXTIS',
		),
		array(
			'image_id' => 35188,
			'name'     => 'Norbert',
			'role'     => 'Responsabile acquisti e RHACCP',
		),
		array(
			'image_id' => 35182,
			'name'     => 'Virginie',
			'role'     => 'Responsabile produzione, controllo qualità',
		),
		array(
			'image_id' => 35185,
			'name'     => 'Delian',
			'role'     => 'futuro Direttore (successione assicurata)',
		),
	);
}

/**
 * Sanitize the fixed four-slot team editor.
 *
 * @param mixed $value Submitted setting value.
 * @return array<int, array<string, int|string>>
 */
function oasi_about_sanitize_team( $value ): array {
	$rows      = is_array( $value ) ? $value : array();
	$sanitized = array();

	for ( $index = 0; $index < 4; $index++ ) {
		$row = isset( $rows[ $index ] ) && is_array( $rows[ $index ] ) ? $rows[ $index ] : array();
		$sanitized[] = array(
			'image_id' => absint( $row['image_id'] ?? 0 ),
			'name'     => sanitize_text_field( $row['name'] ?? '' ),
			'role'     => sanitize_text_field( $row['role'] ?? '' ),
		);
	}

	return $sanitized;
}

/**
 * Register Oasi-only fields in the existing ticinoWEB CMS settings group.
 */
function oasi_about_register_cms_settings(): void {
	register_setting(
		'ticinoweb_settings_group',
		'ticinoweb_chi_siamo_closing',
		array(
			'type'              => 'string',
			'default'           => 'BIO-LOGICA',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);

	register_setting(
		'ticinoweb_settings_group',
		'ticinoweb_chi_siamo_team',
		array(
			'type'              => 'array',
			'default'           => array(),
			'sanitize_callback' => 'oasi_about_sanitize_team',
		)
	);
}
add_action( 'admin_init', 'oasi_about_register_cms_settings', 20 );

/**
 * Remove the historical BIO-LOGICA ending from the main story copy.
 *
 * @param string $text    Full story text.
 * @param string $closing Highlighted closing.
 * @return string
 */
function oasi_about_strip_story_closing( string $text, string $closing ): string {
	if ( '' === trim( $closing ) ) {
		return trim( $text );
	}

	$pattern = '/(?:\R\s*)?' . preg_quote( trim( $closing ), '/' ) . '[\s\.\x{2026}\x{2024}\x{2025}]*$/iu';
	return trim( (string) preg_replace( $pattern, '', trim( $text ) ) );
}

/**
 * Seed only missing Oasi CMS values, preserving every later editor change.
 */
function oasi_about_seed_cms_content(): void {
	if ( 'oasidellespezie-child-theme' !== get_stylesheet() ) {
		return;
	}

	if ( '1' === (string) get_option( 'oasi_about_cms_seed_version', '' ) ) {
		return;
	}

	$closing = trim( (string) get_option( 'ticinoweb_chi_siamo_closing', '' ) );
	if ( '' === $closing ) {
		$closing = 'BIO-LOGICA';
		update_option( 'ticinoweb_chi_siamo_closing', $closing, false );
	}

	$team = get_option( 'ticinoweb_chi_siamo_team', array() );
	if ( ! is_array( $team ) || empty( array_filter( wp_list_pluck( $team, 'name' ) ) ) ) {
		update_option( 'ticinoweb_chi_siamo_team', oasi_about_default_team(), false );
	}

	if ( '' === trim( (string) get_option( 'ticinoweb_chi_siamo_image', '' ) ) ) {
		$story_image = wp_get_attachment_image_url( 35170, 'full' );
		if ( $story_image ) {
			update_option( 'ticinoweb_chi_siamo_image', $story_image, false );
		}
	}

	if ( '' === trim( (string) get_option( 'ticinoweb_chi_siamo_link', '' ) ) ) {
		$shop_id  = function_exists( 'wc_get_page_id' ) ? (int) wc_get_page_id( 'shop' ) : 0;
		$shop_url = $shop_id > 0 ? get_permalink( $shop_id ) : home_url( '/shop-online-oasi-delle-spezie/' );
		if ( $shop_url ) {
			update_option( 'ticinoweb_chi_siamo_link', esc_url_raw( $shop_url ), false );
		}
	}

	update_option( 'oasi_about_cms_seed_version', '1', false );
}
add_action( 'init', 'oasi_about_seed_cms_content', 20 );

/**
 * Determine whether the current admin screen is one of the ticinoWEB CMS pages.
 */
function oasi_about_is_cms_screen(): bool {
	if ( ! is_admin() || ! current_user_can( 'edit_pages' ) ) {
		return false;
	}

	$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	return in_array( $page, array( 'ticinoweb-cms', 'ticinoweb-settings' ), true );
}

/**
 * Load the child-owned CMS enhancer only on the relevant parent admin page.
 */
function oasi_about_enqueue_admin_assets(): void {
	if ( ! oasi_about_is_cms_screen() ) {
		return;
	}

	wp_enqueue_media();
	wp_enqueue_script(
		'oasi-about-admin',
		get_stylesheet_directory_uri() . '/assets/js/about-admin.js',
		array(),
		wp_get_theme()->get( 'Version' ),
		true
	);
}
add_action( 'admin_enqueue_scripts', 'oasi_about_enqueue_admin_assets' );

/**
 * Render child-owned fields, then let the admin script attach them to the
 * existing ticinoWEB CMS → Chi Siamo table without modifying the parent.
 */
function oasi_about_render_admin_fields(): void {
	if ( ! oasi_about_is_cms_screen() ) {
		return;
	}

	$closing = (string) get_option( 'ticinoweb_chi_siamo_closing', 'BIO-LOGICA' );
	$team    = oasi_about_sanitize_team( get_option( 'ticinoweb_chi_siamo_team', oasi_about_default_team() ) );
	?>
	<div id="oasi-about-cms-fields" hidden>
	<table><tbody>
		<tr class="oasi-about-cms-row">
			<th scope="row"><label for="ticinoweb_chi_siamo_closing"><?php esc_html_e( 'Chiusura evidenziata', 'oasidellespezie-child-theme' ); ?></label></th>
			<td>
				<input type="text" id="ticinoweb_chi_siamo_closing" name="ticinoweb_chi_siamo_closing" value="<?php echo esc_attr( $closing ); ?>" class="regular-text">
				<p class="description"><?php esc_html_e( 'Conclusione editoriale mostrata subito dopo il testo della storia.', 'oasidellespezie-child-theme' ); ?></p>
			</td>
		</tr>
		<tr class="oasi-about-cms-row">
			<th scope="row"><?php esc_html_e( 'Team Oasi delle Spezie', 'oasidellespezie-child-theme' ); ?></th>
			<td>
				<p class="description oasi-about-cms-intro"><?php esc_html_e( 'Foto, nome e ruolo sono modificabili e vengono pubblicati direttamente nella pagina Chi siamo.', 'oasidellespezie-child-theme' ); ?></p>
				<div class="oasi-about-cms-team">
					<?php foreach ( $team as $index => $member ) : ?>
						<?php $preview = $member['image_id'] ? wp_get_attachment_image_url( (int) $member['image_id'], 'thumbnail' ) : ''; ?>
						<section class="oasi-about-cms-member" aria-labelledby="oasi-team-member-<?php echo esc_attr( (string) $index ); ?>">
							<h3 id="oasi-team-member-<?php echo esc_attr( (string) $index ); ?>"><?php echo esc_html( sprintf( __( 'Collaboratore %d', 'oasidellespezie-child-theme' ), $index + 1 ) ); ?></h3>
							<div class="oasi-about-cms-member__media">
								<div class="oasi-about-cms-member__preview" data-oasi-image-preview="<?php echo esc_attr( (string) $index ); ?>" data-empty-label="<?php esc_attr_e( 'Nessuna foto', 'oasidellespezie-child-theme' ); ?>">
									<?php if ( $preview ) : ?>
										<img src="<?php echo esc_url( $preview ); ?>" alt="">
									<?php else : ?>
										<span><?php esc_html_e( 'Nessuna foto', 'oasidellespezie-child-theme' ); ?></span>
									<?php endif; ?>
								</div>
								<div>
									<input type="hidden" id="oasi_team_image_<?php echo esc_attr( (string) $index ); ?>" name="ticinoweb_chi_siamo_team[<?php echo esc_attr( (string) $index ); ?>][image_id]" value="<?php echo esc_attr( (string) $member['image_id'] ); ?>">
									<button type="button" class="button oasi-about-media-button" data-oasi-image-index="<?php echo esc_attr( (string) $index ); ?>"><?php esc_html_e( 'Seleziona foto', 'oasidellespezie-child-theme' ); ?></button>
									<button type="button" class="button-link-delete oasi-about-media-remove" data-oasi-image-index="<?php echo esc_attr( (string) $index ); ?>"<?php disabled( empty( $member['image_id'] ) ); ?>><?php esc_html_e( 'Rimuovi foto', 'oasidellespezie-child-theme' ); ?></button>
								</div>
							</div>
							<label>
								<span><?php esc_html_e( 'Nome', 'oasidellespezie-child-theme' ); ?></span>
								<input type="text" name="ticinoweb_chi_siamo_team[<?php echo esc_attr( (string) $index ); ?>][name]" value="<?php echo esc_attr( (string) $member['name'] ); ?>" class="regular-text">
							</label>
							<label>
								<span><?php esc_html_e( 'Ruolo', 'oasidellespezie-child-theme' ); ?></span>
								<input type="text" name="ticinoweb_chi_siamo_team[<?php echo esc_attr( (string) $index ); ?>][role]" value="<?php echo esc_attr( (string) $member['role'] ); ?>" class="large-text">
							</label>
						</section>
					<?php endforeach; ?>
				</div>
			</td>
		</tr>
	</tbody></table>
	</div>
	<style>
		.oasi-about-cms-intro{margin-bottom:16px!important}.oasi-about-cms-team{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;max-width:920px}.oasi-about-cms-member{margin:0;padding:18px;border:1px solid #dcdcde;border-radius:12px;background:#fff}.oasi-about-cms-member h3{margin:0 0 12px}.oasi-about-cms-member label{display:block;margin-top:12px}.oasi-about-cms-member label>span{display:block;font-weight:600;margin-bottom:5px}.oasi-about-cms-member input{width:100%}.oasi-about-cms-member__media{display:flex;align-items:center;gap:12px}.oasi-about-cms-member__media .button-link-delete{display:block;margin-top:10px}.oasi-about-cms-member__preview{display:grid;place-items:center;width:84px;height:84px;overflow:hidden;border-radius:10px;background:#f0f0f1;color:#646970}.oasi-about-cms-member__preview img{width:100%;height:100%;object-fit:cover}@media(max-width:782px){.oasi-about-cms-team{grid-template-columns:1fr}}
	</style>
	<?php
}
add_action( 'admin_footer', 'oasi_about_render_admin_fields' );

/**
 * Return all dynamic content needed by the frontend template.
 *
 * @return array<string, mixed>
 */
function oasi_get_about_page_data(): array {
	$closing = trim( (string) get_option( 'ticinoweb_chi_siamo_closing', 'BIO-LOGICA' ) );
	$story   = (string) get_option( 'ticinoweb_chi_siamo_text', '' );
	$team    = oasi_about_sanitize_team( get_option( 'ticinoweb_chi_siamo_team', array() ) );

	$team = array_values(
		array_filter(
			$team,
			static fn( array $member ): bool => '' !== $member['name'] || '' !== $member['role'] || $member['image_id'] > 0
		)
	);

	$image_url = trim( (string) get_option( 'ticinoweb_chi_siamo_image', '' ) );
	$image_id  = $image_url ? (int) attachment_url_to_postid( $image_url ) : 0;

	return array(
		'title'       => trim( (string) get_option( 'ticinoweb_chi_siamo_title', __( 'La nostra storia', 'oasidellespezie-child-theme' ) ) ),
		'story'       => oasi_about_strip_story_closing( $story, $closing ),
		'image_url'   => $image_url,
		'image_id'    => $image_id,
		'link'        => esc_url_raw( (string) get_option( 'ticinoweb_chi_siamo_link', '' ) ),
		'closing'     => $closing,
		'team'        => $team,
		'mixtis_id'   => 3883,
		'whole_id'    => 33435,
		'practice_ids' => array( 35170, 35173, 35176 ),
	);
}
