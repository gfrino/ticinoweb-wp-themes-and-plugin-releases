<?php
/**
 * Data helpers and page routing for the professional area.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return the visitor state used by the professional page.
 *
 * @param WP_User|null $user Optional user object, primarily useful to callers
 *                           that already resolved the current user.
 * @return string One of guest, customer or professional.
 */
function oasi_professional_get_access_state( ?WP_User $user = null ): string {
	if ( ! is_user_logged_in() ) {
		return 'guest';
	}

	$user = $user instanceof WP_User ? $user : wp_get_current_user();

	if ( class_exists( 'WWP_Wholesale_Roles' ) ) {
		$roles_api = WWP_Wholesale_Roles::getInstance();
		$roles     = is_object( $roles_api ) && method_exists( $roles_api, 'getUserWholesaleRole' )
			? (array) $roles_api->getUserWholesaleRole( $user )
			: array();

		if ( ! empty( $roles ) ) {
			return 'professional';
		}
	}

	return in_array( 'wholesale_customer', (array) $user->roles, true ) ? 'professional' : 'customer';
}

/**
 * Return the existing Ultimate Member professional registration URL.
 */
function oasi_professional_get_register_url(): string {
	$url = get_permalink( 33822 );
	return $url ? (string) $url : home_url( '/register/' );
}

/**
 * Return the WooCommerce account URL.
 */
function oasi_professional_get_account_url(): string {
	if ( function_exists( 'wc_get_page_permalink' ) ) {
		$url = wc_get_page_permalink( 'myaccount' );
		if ( $url ) {
			return (string) $url;
		}
	}

	return home_url( '/mio-account/' );
}

/**
 * Return the WooCommerce Shop URL.
 */
function oasi_professional_get_shop_url(): string {
	if ( function_exists( 'wc_get_page_id' ) ) {
		$shop_id = (int) wc_get_page_id( 'shop' );
		if ( $shop_id > 0 ) {
			$url = get_permalink( $shop_id );
			if ( $url ) {
				return (string) $url;
			}
		}
	}

	return home_url( '/shop-online-oasi-delle-spezie/' );
}

/**
 * Return the existing Contact page URL.
 */
function oasi_professional_get_contact_url(): string {
	$page = get_page_by_path( 'contatto' );
	if ( $page instanceof WP_Post && 'publish' === $page->post_status ) {
		$url = get_permalink( $page );
		if ( $url ) {
			return (string) $url;
		}
	}

	return home_url( '/contatto/' );
}

/**
 * Return the safe catalog bridge action for a visitor state.
 *
 * @param string $access_state Visitor state from oasi_professional_get_access_state().
 * @return array{url:string,label:string}
 */
function oasi_professional_get_catalog_cta( string $access_state ): array {
	if ( 'professional' === $access_state ) {
		return array(
			'url'   => oasi_professional_get_shop_url(),
			'label' => __( 'Apri lo Shop professionale', 'oasidellespezie-child-theme' ),
		);
	}

	if ( 'customer' === $access_state ) {
		return array(
			'url'   => oasi_professional_get_contact_url(),
			'label' => __( 'Richiedi la verifica', 'oasidellespezie-child-theme' ),
		);
	}

	return array(
		'url'   => oasi_professional_get_register_url(),
		'label' => __( 'Richiedi l’accesso', 'oasidellespezie-child-theme' ),
	);
}

/**
 * Return the existing professional editorial image.
 */
function oasi_professional_get_image_html(): string {
	return (string) wp_get_attachment_image(
		33865,
		'large',
		false,
		array(
			'class'   => 'oasi-professional-intro__image',
			'loading' => 'eager',
			'alt'     => __( 'Selezione di spezie per il catalogo professionale', 'oasidellespezie-child-theme' ),
		)
	);
}

/**
 * Return editorial category links backed by real WooCommerce terms.
 *
 * @return array<int, array{label:string,slug:string,description:string,url:string}>
 */
function oasi_professional_get_categories(): array {
	$definitions = array(
		array(
			'label'       => __( 'Spezie BIO', 'oasidellespezie-child-theme' ),
			'slug'        => 'spezie-bio',
			'description' => __( 'Spezie pure selezionate per cucine e laboratori professionali.', 'oasidellespezie-child-theme' ),
		),
		array(
			'label'       => __( 'Erbe aromatiche BIO', 'oasidellespezie-child-theme' ),
			'slug'        => 'erbe-aromatiche-bio',
			'description' => __( 'Erbe lavorate e selezionate a mano.', 'oasidellespezie-child-theme' ),
		),
		array(
			'label'       => __( 'Peperoncini BIO', 'oasidellespezie-child-theme' ),
			'slug'        => 'chili-paprika-bio',
			'description' => __( 'Piccantezze, paprika e varietà da differenti origini.', 'oasidellespezie-child-theme' ),
		),
		array(
			'label'       => __( 'Pepi BIO', 'oasidellespezie-child-theme' ),
			'slug'        => 'pepi-e-bacche-bio',
			'description' => __( 'Pepi e bacche aromatiche per uso professionale.', 'oasidellespezie-child-theme' ),
		),
		array(
			'label'       => __( 'Sali dal mondo', 'oasidellespezie-child-theme' ),
			'slug'        => 'sali-del-mondo',
			'description' => __( 'Sali selezionati per cucina, finitura e miscelazione.', 'oasidellespezie-child-theme' ),
		),
	);
	$shop_url   = oasi_professional_get_shop_url();

	foreach ( $definitions as &$definition ) {
		$term = get_term_by( 'slug', $definition['slug'], 'product_cat' );
		$url  = $term instanceof WP_Term ? get_term_link( $term ) : $shop_url;

		$definition['url'] = is_wp_error( $url ) ? $shop_url : (string) $url;
	}
	unset( $definition );

	return $definitions;
}

/**
 * Use the native child template even when the imported page keeps legacy metadata.
 *
 * @param string $template Resolved WordPress template path.
 */
function oasi_professional_template_include( string $template ): string {
	if ( ! is_page( 'catalogo-professionista' ) ) {
		return $template;
	}

	$professional_template = get_stylesheet_directory() . '/page-catalogo-professionista.php';
	return is_file( $professional_template ) ? $professional_template : $template;
}
add_filter( 'template_include', 'oasi_professional_template_include', 99 );
