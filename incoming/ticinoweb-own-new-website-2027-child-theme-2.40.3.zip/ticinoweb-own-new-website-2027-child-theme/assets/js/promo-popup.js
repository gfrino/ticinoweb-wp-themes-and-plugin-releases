/* Popup promozione: si apre dopo un attimo, si chiude con X, Esc, sfondo o "Continua"; ricorda la chiusura per 24 ore. */
(function () {
	'use strict';
	var box = document.getElementById('tw-promo');
	if (!box) { return; }
	var storeKey = 'tw-promo-' + (box.getAttribute('data-key') || '');
	var DAY = 24 * 60 * 60 * 1000;
	var lastFocus = null;

	try {
		var seen = parseInt(window.localStorage.getItem(storeKey), 10);
		if (seen && Date.now() - seen < DAY) { return; }
	} catch (e) { /* storage non disponibile: il popup si mostra comunque */ }

	function open() {
		lastFocus = document.activeElement;
		box.hidden = false;
		document.body.classList.add('tw-promo-open');
		window.requestAnimationFrame(function () {
			box.classList.add('is-open');
			var close = box.querySelector('.tw-promo__close');
			if (close) { close.focus(); }
		});
	}
	function close() {
		box.classList.remove('is-open');
		document.body.classList.remove('tw-promo-open');
		window.setTimeout(function () { box.hidden = true; }, 260);
		try { window.localStorage.setItem(storeKey, String(Date.now())); } catch (e) { /* ignora */ }
		if (lastFocus && lastFocus.focus) { lastFocus.focus(); }
	}

	box.addEventListener('click', function (e) {
		if (e.target.closest('[data-tw-promo-close]')) { close(); }
		else if (e.target.closest('.tw-promo__cta')) {
			try { window.localStorage.setItem(storeKey, String(Date.now())); } catch (err) { /* ignora */ }
		}
	});
	document.addEventListener('keydown', function (e) {
		if (box.hidden) { return; }
		if (e.key === 'Escape') { close(); return; }
		if (e.key === 'Tab') {
			var f = box.querySelectorAll('a[href], button');
			if (!f.length) { return; }
			var first = f[0], last = f[f.length - 1];
			if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
			else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
		}
	});
	window.setTimeout(open, 1500);
})();
