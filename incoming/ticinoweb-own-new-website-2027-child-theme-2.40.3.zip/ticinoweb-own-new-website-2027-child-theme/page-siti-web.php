<?php
/**
 * Template Name: ticinoWEB — Panoramica Siti Web
 *
 * @package ticinoWEB_Child_Theme
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$tw_data       = tw_web_services_get_data();
$tw_contact    = tw_home_mapped_url( 'page_contatti', 'contatti' );
$tw_projects   = tw_home_mapped_url( 'page_referenze', 'referenze' );
$tw_primary    = $tw_data['hero_cta_url'] ?: $tw_contact;
$tw_final_url  = $tw_data['final_cta_url'] ?: $tw_contact;

$tw_img = static function ( $file, $alt, $w, $h ) {
	$path = get_stylesheet_directory() . '/assets/images/web/' . $file;
	$ver  = file_exists( $path ) ? '?ver=' . filemtime( $path ) : '';
	return '<img src="' . esc_url( get_stylesheet_directory_uri() . '/assets/images/web/' . $file . $ver ) . '" alt="' . esc_attr( $alt ) . '" width="' . (int) $w . '" height="' . (int) $h . '" loading="lazy" decoding="async">';
};

get_header();
?>
<main class="tw-web-service tw-web-service--overview">
	<?php $tw_hero_bg = ! empty( $tw_data['hero_media_id'] ); ?>
	<section class="tw-web-hero<?php echo $tw_hero_bg ? ' has-bg-media' : ''; ?>">
		<?php if ( $tw_hero_bg ) : ?><figure class="tw-web-hero__bg"><?php echo wp_get_attachment_image( $tw_data['hero_media_id'], 'full', false, array( 'alt' => '', 'fetchpriority' => 'high', 'decoding' => 'async', 'sizes' => '100vw' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></figure><?php endif; ?>
		<div class="tw-shell">
			<div class="tw-web-hero__grid">
				<div>
					<p class="tw-kicker"><?php echo esc_html( $tw_data['hero_eyebrow'] ); ?></p>
					<h1><?php echo esc_html( $tw_data['hero_title'] ); ?></h1>
					<p><?php echo wp_kses_post( $tw_data['hero_text'] ); ?></p>
					<?php if ( $tw_data['hero_cta_text'] ) : ?><a class="tw-text-link" href="<?php echo esc_url( $tw_primary ); ?>"><?php echo esc_html( $tw_data['hero_cta_text'] ); ?> <span class="tw-arrow" aria-hidden="true"></span></a><?php endif; ?>
				<?php if(function_exists('tw_page_share'))tw_page_share(); ?>
				</div>
			</div>
		</div>
	</section>

	<?php tw_parallax_band( 'web/web-studio-light.webp', __( 'Sviluppo', 'ticinoweb-child-theme' ), __( 'Un unico studio, dal primo schizzo alla messa online', 'ticinoweb-child-theme' ), __( 'Design, sviluppo e gestione nello stesso team, a Locarno: un solo referente per il tuo sito.', 'ticinoweb-child-theme' ), __( 'Portatile su una scrivania luminosa', 'ticinoweb-child-theme' ), '45% 60%', 'light' ); ?>

	<?php if ( '1' === ( $tw_data['show_intro'] ?? '1' ) ) : ?>
	<section class="tw-web-intro">
		<div class="tw-shell tw-web-split">
			<div class="tw-web-split__lead"><p class="tw-kicker"><?php esc_html_e( 'Siti Web', 'ticinoweb-child-theme' ); ?></p><figure class="tw-web-split__media"><?php echo $tw_img( 'web-intro-light.webp', __( 'Portatile aperto su una scrivania in legno chiaro', 'ticinoweb-child-theme' ), 1400, 933 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></figure></div>
			<div><h2><?php echo esc_html( $tw_data['intro_title'] ); ?></h2><?php echo wp_kses_post( wpautop( $tw_data['intro_text'] ) ); ?></div>
		</div>
	</section>
	<?php endif; ?>

	<?php if ( ! empty( $tw_data['ai_title'] ) ) : ?>
	<section class="tw-web-intro tw-web-ai">
		<div class="tw-shell tw-web-split">
			<div class="tw-web-split__lead"><p class="tw-kicker"><?php esc_html_e( 'Intelligenza artificiale', 'ticinoweb-child-theme' ); ?></p><figure class="tw-web-split__media is-drawing"><?php echo $tw_img( 'draw/ai-site.svg', __( 'Disegno di un sito collegato a un chip di intelligenza artificiale', 'ticinoweb-child-theme' ), 460, 280 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></figure></div>
			<div><h2><?php echo esc_html( $tw_data['ai_title'] ); ?></h2><?php echo wp_kses_post( wpautop( $tw_data['ai_text'] ?? '' ) ); ?></div>
		</div>
	</section>
	<?php endif; ?>

	<?php
	$tw_type_count = count( $tw_data['overview_types'] ?? array() );
	$tw_count_word = array( 2 => 'Due', 3 => 'Tre', 4 => 'Quattro', 5 => 'Cinque', 6 => 'Sei', 7 => 'Sette', 8 => 'Otto' );
	?>
	<section class="tw-web-overview-types" aria-labelledby="tw-web-types-title">
		<?php tw_parallax_backdrop( 'web/web-laptop.webp' ); ?>
		<div class="tw-shell">
			<p class="tw-kicker"><?php esc_html_e( 'Tipologie', 'ticinoweb-child-theme' ); ?></p>
			<h2 id="tw-web-types-title"><?php echo esc_html( isset( $tw_count_word[ $tw_type_count ] ) ? sprintf( /* translators: %s: number of structures, in words */ __( '%s strutture, una sola attenzione al risultato.', 'ticinoweb-child-theme' ), $tw_count_word[ $tw_type_count ] ) : __( 'Una sola attenzione al risultato.', 'ticinoweb-child-theme' ) ); ?></h2>
			<div class="tw-web-overview-types__list">
				<?php foreach ( $tw_data['overview_types'] ?? array() as $tw_type ) : ?>
					<?php $tw_type_url = home_url( '/' . trim( $tw_type['url'], '/' ) . '/' ); ?>
					<article class="tw-web-overview-types__item">
						<a href="<?php echo esc_url( $tw_type_url ); ?>">
							<span><?php echo esc_html( $tw_type['number'] ); ?></span>
							<h3><?php echo esc_html( $tw_type['title'] ); ?></h3>
							<p><?php echo esc_html( $tw_type['text'] ); ?></p>
							<i class="tw-arrow" aria-hidden="true"></i>
						</a>
						<?php $tw_slug = trim( (string) $tw_type['url'], '/' ); ?>
						<?php if ( file_exists( get_stylesheet_directory() . '/assets/images/web/draw/' . $tw_slug . '-1.svg' ) ) : ?>
							<div class="tw-web-overview-types__drawings" aria-hidden="true">
								<?php for ( $tw_n = 1; $tw_n <= 3; $tw_n++ ) : ?><figure><?php echo $tw_img( 'draw/' . $tw_slug . '-' . $tw_n . '.svg', '', 400, 300 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></figure><?php endfor; ?>
							</div>
						<?php endif; ?>
						<?php $tw_features = array_filter( array_map( 'trim', explode( "\n", (string) ( $tw_type['features'] ?? '' ) ) ) ); ?>
						<?php if ( $tw_features ) : ?>
							<div class="tw-web-overview-types__more">
								<ul><?php foreach ( $tw_features as $tw_feature ) : ?><li><?php echo esc_html( $tw_feature ); ?></li><?php endforeach; ?></ul>
								<a class="tw-text-link" href="<?php echo esc_url( $tw_primary ); ?>"><?php esc_html_e( 'Richiedi offerta', 'ticinoweb-child-theme' ); ?> <span class="tw-arrow" aria-hidden="true"></span></a>
							</div>
						<?php endif; ?>
					</article>
				<?php endforeach; ?>
			</div>
		</div>
	</section>

	<?php if ( ! empty( $tw_data['highlights'] ) ) : ?>
	<section class="tw-web-highlights" aria-labelledby="tw-web-highlights-title">
		<div class="tw-shell">
			<p class="tw-kicker"><?php esc_html_e( 'Perché ticinoWEB', 'ticinoweb-child-theme' ); ?></p>
			<h2 id="tw-web-highlights-title"><?php echo esc_html( $tw_data['highlights_title'] ?? '' ); ?></h2>
			<div class="tw-web-highlights__grid">
				<?php foreach ( $tw_data['highlights'] as $tw_item ) : ?>
					<div><?php if ( ! empty( $tw_item['icon'] ) && file_exists( get_stylesheet_directory() . '/assets/images/web/draw/icon-' . sanitize_file_name( $tw_item['icon'] ) . '.svg' ) ) : ?><span class="tw-web-highlights__icon"><?php echo $tw_img( 'draw/icon-' . sanitize_file_name( $tw_item['icon'] ) . '.svg', '', 64, 64 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span><?php endif; ?><h3><?php echo esc_html( $tw_item['title'] ); ?></h3><?php echo wp_kses_post( wpautop( $tw_item['text'] ) ); ?></div>
				<?php endforeach; ?>
			</div>
		</div>
	</section>
	<?php endif; ?>

	<?php if ( ! empty( $tw_data['agency_title'] ) ) : ?>
	<section class="tw-web-intro tw-web-agency">
		<div class="tw-shell tw-web-split">
			<div class="tw-web-split__lead"><p class="tw-kicker"><?php esc_html_e( 'La tua agenzia web in Ticino', 'ticinoweb-child-theme' ); ?></p><figure class="tw-web-split__media"><?php echo $tw_img( 'web-ticino-lago.webp', __( 'Il lago di Lugano visto dal Monte Brè', 'ticinoweb-child-theme' ), 1250, 977 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></figure></div>
			<div><h2><?php echo esc_html( $tw_data['agency_title'] ); ?></h2><?php echo wp_kses_post( wpautop( $tw_data['agency_text'] ?? '' ) ); ?></div>
		</div>
	</section>
	<?php endif; ?>

	<?php if ( function_exists( 'tw_service_extras' ) ) tw_service_extras( 'before_final' ); ?>

	<?php if ( '1' === ( $tw_data['show_final_cta'] ?? '1' ) ) : ?>
	<section class="tw-web-final-cta">
		<div class="tw-shell tw-web-final-cta__grid">
			<div><p class="tw-kicker"><?php esc_html_e( 'Il prossimo passo', 'ticinoweb-child-theme' ); ?></p><h2><?php echo esc_html( $tw_data['final_cta_title'] ); ?></h2></div>
			<div><?php echo wp_kses_post( wpautop( $tw_data['final_cta_text'] ) ); ?><a class="tw-button" href="<?php echo esc_url( $tw_final_url ); ?>"><?php echo esc_html( $tw_data['final_cta_button'] ); ?> <span class="tw-arrow" aria-hidden="true"></span></a><?php if ( $tw_data['portfolio_link_text'] ) : ?><a class="tw-web-portfolio-link" href="<?php echo esc_url( $tw_projects ); ?>"><?php echo esc_html( $tw_data['portfolio_link_text'] ); ?> <span class="tw-arrow" aria-hidden="true"></span></a><?php endif; ?></div>
		</div>
	</section>
	<?php endif; ?>
</main>
<?php get_footer(); ?>
