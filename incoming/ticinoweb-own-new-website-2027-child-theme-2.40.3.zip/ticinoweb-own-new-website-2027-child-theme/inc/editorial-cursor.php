<?php
/** Codrops 018 cursor: child-only markup and fine-pointer conditional assets. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'wp_footer', static function () {
 if ( is_admin() ) { return; }
 ?>
 <div class="tw-cursor" id="tw-cursor" aria-hidden="true" hidden>
 <?php foreach ( array( array( 'main', 12, '.75', 3, 3 ), array( 'echo', 16, '.32', 10, 7 ) ) as $part ) : ?>
  <svg class="tw-cursor__element tw-cursor__element--<?php echo esc_attr( $part[0] ); ?>" data-cursor-element data-amt="<?php echo esc_attr( $part[2] ); ?>" data-max-lag="<?php echo esc_attr( $part[3] ); ?>" width="64" height="64" viewBox="0 0 64 64" focusable="false">
   <defs><filter id="tw-cursor-filter-<?php echo esc_attr( $part[0] ); ?>" x="-50%" y="-50%" width="200%" height="200%" filterUnits="objectBoundingBox" color-interpolation-filters="sRGB">
    <feTurbulence type="fractalNoise" seed="<?php echo esc_attr( $part[4] ); ?>" baseFrequency=".01" numOctaves="1" result="warp"/>
    <feDisplacementMap in="SourceGraphic" in2="warp" xChannelSelector="R" yChannelSelector="G" scale="0"/>
   </filter></defs>
   <circle class="tw-cursor__inner" cx="32" cy="32" r="<?php echo esc_attr( $part[1] ); ?>" fill="none"/>
  </svg>
 <?php endforeach; ?>
 </div>
 <?php
}, 5 );

add_action( 'wp_enqueue_scripts', static function () {
 if ( is_admin() ) { return; }
 $uri = get_stylesheet_directory_uri();
 $version = wp_get_theme()->get( 'Version' );
 wp_register_style( 'tw-editorial-cursor', $uri . '/assets/css/editorial-cursor.css', array(), $version );
 wp_register_script( 'tw-editorial-cursor', $uri . '/assets/js/editorial-cursor.js', array(), $version, true );
 wp_register_script( 'tw-cursor-gsap', $uri . '/assets/vendor/gsap.min.js', array(), '3.15.0', true );
 // Reuse an already enqueued GSAP core before the existing child bootstrap.
 $scripts = wp_scripts();
 foreach ( $scripts->queue as $handle ) {
  $registered = $scripts->registered[ $handle ] ?? null;
  if ( $registered && preg_match( '~(?:^|/)gsap(?:\.min)?\.js(?:\?|$)~i', $registered->src ) && isset( $scripts->registered['ticinoweb-child-site'] ) ) {
   $scripts->registered['ticinoweb-child-site']->deps[] = $handle;
   break;
  }
 }
 $assets = wp_json_encode( array(
  'css' => add_query_arg( 'ver', $version, $uri . '/assets/css/editorial-cursor.css' ),
  'js' => add_query_arg( 'ver', $version, $uri . '/assets/js/editorial-cursor.js' ),
  'gsap' => add_query_arg( 'ver', '3.15.0', $uri . '/assets/vendor/gsap.min.js' ),
 ), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT );
 $bootstrap = <<<'JS'
(()=>{'use strict';const assets=ASSETS;const media=matchMedia('(hover: hover) and (pointer: fine)');let loaded=false;const load=async()=>{if(loaded||!media.matches)return;loaded=true;const styled=await new Promise(resolve=>{const css=document.createElement('link');css.rel='stylesheet';css.href=assets.css;css.onload=()=>resolve(true);css.onerror=()=>resolve(false);document.head.append(css);});if(!styled)return;if(!window.gsap)await new Promise(resolve=>{const lib=document.createElement('script');lib.src=assets.gsap;lib.onload=lib.onerror=resolve;document.body.append(lib);});const script=document.createElement('script');script.type='module';script.src=assets.js;script.onerror=()=>{document.documentElement.classList.remove('tw-cursor-on');document.getElementById('tw-cursor')?.remove();};document.body.append(script);};load();media.addEventListener('change',load);})();
JS;
 wp_add_inline_script( 'ticinoweb-child-site', str_replace( 'ASSETS', $assets, $bootstrap ), 'after' );
}, 25 );
