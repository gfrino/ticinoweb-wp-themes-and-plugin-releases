<?php
/**
 * Small, read-only helpers for the tBlog single-article template.
 *
 * @package ticinoWEB_Child_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Calculates a human reading time from the rendered post content.
 *
 * @param string $content          Article content.
 * @param int    $words_per_minute Reading pace.
 * @return int
 */
function tw_single_reading_time( $content, $words_per_minute = 220 ) {
	$content = html_entity_decode( wp_strip_all_tags( strip_shortcodes( (string) $content ) ), ENT_QUOTES, 'UTF-8' );
	$words   = preg_split( '/\s+/u', trim( $content ), -1, PREG_SPLIT_NO_EMPTY );
	$count   = is_array( $words ) ? count( $words ) : 0;
	$pace    = max( 1, (int) $words_per_minute );

	return max( 1, (int) ceil( $count / $pace ) );
}

/**
 * Chooses the most useful editorial category for the article label.
 *
 * Web Design is the broad project category and therefore takes precedence
 * when present; otherwise WordPress' first assigned category is retained.
 *
 * @param int $post_id Post ID.
 * @return WP_Term|null
 */
function tw_single_get_primary_category( $post_id ) {
	$categories = get_the_category( $post_id );
	if ( ! $categories ) {
		return null;
	}

	foreach ( $categories as $category ) {
		if ( 'web-design' === $category->slug ) {
			return $category;
		}
	}

	return $categories[0];
}

/**
 * Gets related article IDs, prioritising shared categories and then recency.
 *
 * Only articles with a featured image are returned so the related grid never
 * needs to invent a placeholder.
 *
 * @param int $post_id Current post ID.
 * @param int $limit   Number of posts requested.
 * @return int[]
 */
function tw_single_get_related_post_ids( $post_id, $limit = 3 ) {
	$post_id    = (int) $post_id;
	$limit      = max( 1, (int) $limit );
	$categories = get_the_category( $post_id );
	$category_ids = $categories ? array_map( 'intval', wp_list_pluck( $categories, 'term_id' ) ) : array();
	$common_args = array(
		'post_type'           => 'post',
		'post_status'         => 'publish',
		'posts_per_page'      => $limit,
		'post__not_in'        => array( $post_id ),
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
		'fields'              => 'ids',
		'meta_query'          => array(
			array(
				'key'     => '_thumbnail_id',
				'compare' => 'EXISTS',
			),
		),
	);
	$related = array();

	if ( $category_ids ) {
		$category_query = new WP_Query(
			wp_parse_args(
				array( 'category__in' => $category_ids ),
				$common_args
			)
		);
		$related = array_map( 'intval', $category_query->posts );
	}

	if ( count( $related ) < $limit ) {
		$recent_query = new WP_Query(
			wp_parse_args(
				array(
					'posts_per_page' => $limit - count( $related ),
					'post__not_in'   => array_merge( array( $post_id ), $related ),
				),
				$common_args
			)
		);
		$related = array_merge( $related, array_map( 'intval', $recent_query->posts ) );
	}

	return array_slice( array_values( array_unique( $related ) ), 0, $limit );
}


/**
 * Link di condivisione dell'articolo (nessuno script di terzi: semplici URL).
 *
 * @param int $post_id Articolo.
 * @return array<int,array{key:string,label:string,url:string,icon:string}>
 */
function tw_single_share_links( $post_id ) {
	$url   = get_permalink( $post_id );
	$title = wp_strip_all_tags( get_the_title( $post_id ) );
	$enc_u = rawurlencode( $url );
	$enc_t = rawurlencode( $title );
	$svg   = static function ( $path ) {
		return '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false"><path fill="currentColor" d="' . $path . '"/></svg>';
	};
	return array(
		array( 'key' => 'linkedin', 'label' => __( 'Condividi su LinkedIn', 'ticinoweb-child-theme' ), 'url' => 'https://www.linkedin.com/sharing/share-offsite/?url=' . $enc_u, 'icon' => $svg( 'M4.98 3.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5zM3 9h4v12H3zM9 9h3.8v1.7h.05c.53-1 1.83-2.05 3.77-2.05C20.6 8.65 21 11.2 21 14.5V21h-4v-5.8c0-1.4-.03-3.2-1.95-3.2-1.95 0-2.25 1.52-2.25 3.1V21H9z' ) ),
		array( 'key' => 'facebook', 'label' => __( 'Condividi su Facebook', 'ticinoweb-child-theme' ), 'url' => 'https://www.facebook.com/sharer/sharer.php?u=' . $enc_u, 'icon' => $svg( 'M14 8.5V6.8c0-.8.2-1.3 1.4-1.3H17V2.2c-.3 0-1.3-.2-2.5-.2-2.5 0-4.2 1.5-4.2 4.3v2.2H7.5V12h2.8v10H14V12h2.8l.4-3.5z' ) ),
		array( 'key' => 'x', 'label' => __( 'Condividi su X', 'ticinoweb-child-theme' ), 'url' => 'https://twitter.com/intent/tweet?url=' . $enc_u . '&text=' . $enc_t, 'icon' => $svg( 'M17.7 3H21l-7.2 8.2L22 21h-6.6l-5.2-6.8L4.3 21H1l7.7-8.8L1 3h6.8l4.7 6.2zm-1.2 16h1.8L7.6 4.9H5.7z' ) ),
		array( 'key' => 'whatsapp', 'label' => __( 'Condividi su WhatsApp', 'ticinoweb-child-theme' ), 'url' => 'https://wa.me/?text=' . rawurlencode( $title . ' ' . $url ), 'icon' => $svg( 'M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 18.2c-1.5 0-3-.4-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8-.2-.1-.4-.1-.6.1l-.8 1c-.1.2-.3.2-.5.1-.2-.1-1-.4-2-1.2-.7-.6-1.2-1.4-1.3-1.7-.1-.2 0-.4.1-.5l.4-.4.2-.4v-.4l-.8-1.9c-.2-.5-.4-.4-.6-.4h-.5c-.2 0-.4.1-.6.3-.2.2-.8.8-.8 2s.8 2.3.9 2.5c.1.2 1.6 2.5 4 3.5 2 .8 2.4.6 2.8.6.4-.1 1.5-.6 1.7-1.2.2-.6.2-1.1.2-1.2-.1-.1-.3-.2-.5-.3z' ) ),
		array( 'key' => 'email', 'label' => __( 'Invia per email', 'ticinoweb-child-theme' ), 'url' => 'mailto:?subject=' . $enc_t . '&body=' . $enc_u, 'icon' => $svg( 'M3 5h18a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1zm9 7.4L4 7.2V17h16V7.2zm0-2.3L19.2 7H4.8z' ) ),
		array( 'key' => 'copy', 'label' => __( 'Copia link', 'ticinoweb-child-theme' ), 'url' => $url, 'icon' => $svg( 'M10.6 13.4a1 1 0 0 1 0-1.4l3.5-3.5a1 1 0 1 1 1.4 1.4l-3.5 3.5a1 1 0 0 1-1.4 0zM8.5 19.5a4 4 0 0 1-2.8-6.8l2.1-2.1a1 1 0 1 1 1.4 1.4l-2.1 2.1a2 2 0 0 0 2.8 2.8l2.1-2.1a1 1 0 1 1 1.4 1.4l-2.1 2.1a4 4 0 0 1-2.8 1.2zm7.8-6.4a1 1 0 0 1-.7-1.7l2.1-2.1a2 2 0 0 0-2.8-2.8l-2.1 2.1a1 1 0 1 1-1.4-1.4l2.1-2.1a4 4 0 0 1 5.6 5.6l-2.1 2.1a1 1 0 0 1-.7.3z' ) ),
	);
}

/**
 * Bottoni di condivisione in fondo alle pagine dei servizi (stessi link e stesso pulsante «Copia link» degli articoli).
 */
function tw_page_share() {
	$post_id = get_the_ID();
	if ( ! $post_id ) {
		return;
	}
	if ( ! wp_script_is( 'ticinoweb-child-single', 'enqueued' ) ) {
		wp_enqueue_script( 'ticinoweb-child-single', get_stylesheet_directory_uri() . '/assets/js/single.js', array(), wp_get_theme()->get( 'Version' ), true );
	}
	?>
	<div class="tw-page-share" role="group" aria-label="<?php esc_attr_e( 'Condividi questa pagina', 'ticinoweb-child-theme' ); ?>">
			<p class="tw-page-share__label"><?php esc_html_e( 'Condividi', 'ticinoweb-child-theme' ); ?></p>
			<ul class="tw-page-share__list">
				<?php foreach ( tw_single_share_links( $post_id ) as $share ) : ?>
					<li>
						<?php if ( 'copy' === $share['key'] ) : ?>
							<button type="button" class="tw-page-share__link" data-share-copy="<?php echo esc_url( $share['url'] ); ?>" data-copied-label="<?php esc_attr_e( 'Link copiato', 'ticinoweb-child-theme' ); ?>" aria-label="<?php echo esc_attr( $share['label'] ); ?>" title="<?php echo esc_attr( $share['label'] ); ?>"><?php echo $share['icon']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button>
						<?php else : ?>
							<a class="tw-page-share__link" href="<?php echo esc_url( $share['url'] ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr( $share['label'] ); ?>" title="<?php echo esc_attr( $share['label'] ); ?>"><?php echo $share['icon']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
						<?php endif; ?>
					</li>
				<?php endforeach; ?>
			</ul>
	</div>
	<?php
}
