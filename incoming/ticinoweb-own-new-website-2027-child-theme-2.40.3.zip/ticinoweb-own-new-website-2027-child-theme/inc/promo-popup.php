<?php
/**
 * Popup promozione: mostra i dati di ticinoWEB CMS → Promozioni (parent).
 *
 * Nessun dato nel tema: titolo, testo, immagine, link, date di inizio/fine e
 * l'interruttore "disattiva promozioni" arrivano dalle opzioni del parent
 * (`ticinoweb_promozioni_*`). Fuori dal periodo impostato il parent svuota le
 * opzioni sul sito pubblico, quindi il popup non viene stampato.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Dati della promozione da mostrare, oppure array vuoto se non c'è nulla. */
function tw_promo_popup_data() {
	if ( get_option( 'ticinoweb_disable_promozioni' ) ) {
		return array();
	}
	if ( function_exists( 'ticinoweb_promozioni_is_active' ) && ! ticinoweb_promozioni_is_active() ) {
		return array();
	}
	$data = array(
		'title' => trim( (string) get_option( 'ticinoweb_promozioni_title', '' ) ),
		'text'  => trim( (string) get_option( 'ticinoweb_promozioni_text', '' ) ),
		'image' => trim( (string) get_option( 'ticinoweb_promozioni_image', '' ) ),
		'link'  => trim( (string) get_option( 'ticinoweb_promozioni_link', '' ) ),
	);
	if ( '' === $data['title'] && '' === $data['text'] && '' === $data['image'] ) {
		return array();
	}
	return $data;
}

/** Non nelle pagine di acquisto, nell'editor o nelle anteprime. */
function tw_promo_popup_should_show() {
	if ( is_admin() || is_feed() || is_404() || is_customize_preview() || is_preview() ) {
		return false;
	}
	if ( function_exists( 'is_cart' ) && ( is_cart() || is_checkout() ) ) {
		return false;
	}
	return ! empty( tw_promo_popup_data() );
}

add_action( 'wp_enqueue_scripts', static function () {
	if ( ! tw_promo_popup_should_show() ) {
		return;
	}
	$version = wp_get_theme()->get( 'Version' );
	wp_enqueue_style( 'tw-promo-popup', get_stylesheet_directory_uri() . '/assets/css/promo-popup.css', array( 'ticinoweb-child-site' ), $version );
	wp_enqueue_script( 'tw-promo-popup', get_stylesheet_directory_uri() . '/assets/js/promo-popup.js', array(), $version, true );
	wp_script_add_data( 'tw-promo-popup', 'strategy', 'defer' );
}, 30 );

add_action( 'wp_footer', static function () {
	if ( ! tw_promo_popup_should_show() ) {
		return;
	}
	$d    = tw_promo_popup_data();
	$key  = substr( md5( wp_json_encode( $d ) . get_option( 'ticinoweb_promozioni_end', '' ) ), 0, 12 );
	$link = $d['link'];
	$ext  = $link && wp_parse_url( $link, PHP_URL_HOST ) && wp_parse_url( $link, PHP_URL_HOST ) !== wp_parse_url( home_url(), PHP_URL_HOST );
	$alt  = $d['title'] ?: __( 'Promozione ticinoWEB', 'ticinoweb-child-theme' );
	?>
	<div class="tw-promo" id="tw-promo" data-key="<?php echo esc_attr( $key ); ?>" role="dialog" aria-modal="true" aria-labelledby="tw-promo-title" hidden>
		<div class="tw-promo__overlay" data-tw-promo-close></div>
		<div class="tw-promo__card">
			<button type="button" class="tw-promo__close" data-tw-promo-close aria-label="<?php esc_attr_e( 'Chiudi la promozione', 'ticinoweb-child-theme' ); ?>">
				<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12"/></svg>
			</button>
			<?php if ( $d['image'] ) : ?>
				<img class="tw-promo__img" src="<?php echo esc_url( $d['image'] ); ?>" alt="<?php echo esc_attr( $alt ); ?>" decoding="async">
			<?php endif; ?>
			<div class="tw-promo__body">
				<p class="tw-promo__kicker"><?php esc_html_e( 'Offerta speciale', 'ticinoweb-child-theme' ); ?></p>
				<?php if ( $d['title'] ) : ?>
					<h2 class="tw-promo__title" id="tw-promo-title"><?php echo esc_html( $d['title'] ); ?></h2>
				<?php endif; ?>
				<?php if ( $d['text'] ) : ?>
					<div class="tw-promo__text"><?php echo wp_kses_post( wpautop( $d['text'] ) ); ?></div>
				<?php endif; ?>
				<div class="tw-promo__actions">
					<?php if ( $link ) : ?>
						<a class="tw-promo__cta" href="<?php echo esc_url( $link ); ?>"<?php echo $ext ? ' target="_blank" rel="noopener"' : ''; ?>>
							<?php esc_html_e( 'Scopri l\'offerta', 'ticinoweb-child-theme' ); ?> <span aria-hidden="true">→</span>
						</a>
					<?php endif; ?>
					<button type="button" class="tw-promo__dismiss" data-tw-promo-close><?php esc_html_e( 'Continua a navigare', 'ticinoweb-child-theme' ); ?></button>
				</div>
			</div>
		</div>
	</div>
	<?php
}, 60 );
