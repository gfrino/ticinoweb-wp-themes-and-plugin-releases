<?php
/**
 * Mela Verde Child Theme functions and definitions
 *
 * @link https://developer.wordpress.org/themes/advanced-topics/child-themes/
 */

require get_stylesheet_directory() . '/inc/customizer.php';
require get_stylesheet_directory() . '/inc/footer.php';

add_action( 'wp_enqueue_scripts', 'melaverde_child_enqueue_styles' );
function melaverde_child_enqueue_styles() {
    // Carica il CSS del parent theme
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
    
    // Carica il CSS del child theme
    wp_enqueue_style( 'child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array( 'parent-style' ),
        wp_get_theme()->get('Version')
    );
    
    // ==============================================
    // LIBRERIE ESTERNE (SWIPER & GSAP)
    // ==============================================
    if ( is_front_page() || is_home() ) {
        // Swiper JS & CSS
        wp_enqueue_style( 'swiper-style', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css', array(), '11.0.0' );
        wp_enqueue_script( 'swiper-js', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js', array(), '11.0.0', true );
        
        // GSAP Core & ScrollTrigger
        wp_enqueue_script( 'gsap-js', 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js', array(), '3.12.2', true );
        wp_enqueue_script( 'gsap-scrolltrigger-js', 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js', array('gsap-js'), '3.12.2', true );

        // Modulo contatti della home → gestore invii del parent (Invii Ricevuti + email).
        wp_enqueue_script(
            'melaverde-contact-form',
            get_stylesheet_directory_uri() . '/assets/js/contact-form.js',
            array( 'ticinoweb-ai-main' ),
            wp_get_theme()->get( 'Version' ),
            true
        );
        
        // Custom Apple-style GSAP Animations
        // We output the script inline in WP footer or directly inside front-page for simplicity 
        // to avoid creating new files if not strictly necessary, but let's enqueue an inline script later if needed.
        // For now we just load the libraries.
    }
}

// ==============================================================================
// AGGIUNGI SOTTO LE TUE FUNZIONI PERSONALIZZATE (HOOKS, FILTRI, SHORTCODES, ECC)
// ==============================================================================

add_action('wp_head', 'melaverde_child_custom_fonts_and_tailwind');
function melaverde_child_custom_fonts_and_tailwind() {
        ?>
        <script src="https://cdn.tailwindcss.com?plugins=forms,typography,container-queries"></script>
        <?php // Font ospitati sul sito (assets/fonts): niente richieste a Google prima del consenso. ?>
        <link rel="preload" href="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/fonts/nunito-sans-latin.woff2' ); ?>" as="font" type="font/woff2" crossorigin>
        <link rel="preload" href="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/fonts/literata-latin.woff2' ); ?>" as="font" type="font/woff2" crossorigin>
        <link rel="stylesheet" href="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/fonts/fonts.css?ver=' . wp_get_theme()->get( 'Version' ) ); ?>">
        <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    "colors": {
                        "surface-tint": "#4a7c59",
                        "on-surface-variant": "#4a4e4a",
                        "on-secondary-fixed-variant": "#4a4538",
                        "on-tertiary-fixed": "#221a05",
                        "tertiary-fixed-dim": "#dcc48e",
                        "on-error-container": "#690005",
                        "primary-fixed-dim": "#8ecf9e",
                        "outline": "#74796e",
                        "surface-container": "#f0ece4",
                        "inverse-primary": "#8ecf9e",
                        "secondary-fixed-dim": "#d4ccbf",
                        "on-secondary": "#ffffff",
                        "background": "#faf6f0",
                        "surface-container-highest": "#e4e0d8",
                        "surface-container-low": "#f5f1ea",
                        "surface-container-high": "#eae6de",
                        "outline-variant": "#c4c8bc",
                        "on-error": "#ffffff",
                        "surface-bright": "#faf6f0",
                        "surface-dim": "#dbd7cf",
                        "secondary-container": "#f0e8db",
                        "surface": "#faf6f0",
                        "on-surface": "#2e3230",
                        "on-primary-fixed-variant": "#2a6038",
                        "on-background": "#2e3230",
                        "on-secondary-fixed": "#1e1a13",
                        "primary-fixed": "#c8e8d0",
                        "on-tertiary-container": "#554020",
                        "on-primary-fixed": "#002110",
                        "tertiary-fixed": "#f8e0a8",
                        "inverse-surface": "#2e3230",
                        "surface-variant": "#e4e0d8",
                        "on-tertiary": "#ffffff",
                        "on-primary": "#ffffff",
                        "on-tertiary-fixed-variant": "#554020",
                        "surface-container-lowest": "#ffffff",
                        "on-primary-container": "#d8f0de",
                        "tertiary": "#705c30",
                        "error": "#b83230",
                        "on-secondary-container": "#5e5548",
                        "primary-container": "#78a886",
                        "tertiary-container": "#c4a66a",
                        "secondary": "#6b6358",
                        "primary": "#4a7c59",
                        "inverse-on-surface": "#f5f0e8",
                        "error-container": "#ffdad8",
                        "secondary-fixed": "#f0e8db"
                    },
                    "borderRadius": {
                        "DEFAULT": "0.5rem",
                        "lg": "1rem",
                        "xl": "1.5rem",
                        "full": "9999px"
                    },
                    "fontFamily": {
                        "headline": ["Literata", "serif"],
                        "body": ["Nunito Sans", "sans-serif"],
                        "label": ["Nunito Sans", "sans-serif"]
                    }
                }
            }
        }
        </script>
        <style>
            body { font-family: 'Nunito Sans', sans-serif; background-color: #faf6f0; color: #2e3230; line-height: 1.6; }
            h1, h2, h3, h4, h5, h6 { font-family: 'Literata', serif; }
            .soft-shadow { box-shadow: 0 4px 20px rgba(46, 50, 48, 0.06); }
            /* Hide parent theme header and footer specific for the Tailwind frontpage */
            body.home .site-header, body.home .site-footer { display: none !important; }
            /* Properly space standard WordPress paragraphs injected via the_content() */
            body.home .leading-relaxed p { margin-bottom: 1.5rem; }
        </style>
        <?php
}

add_filter( 'body_class', 'melaverde_child_body_classes' );
function melaverde_child_body_classes( $classes ) {
    $classes[] = 'bg-background';
    $classes[] = 'text-on-background';
    $classes[] = 'antialiased';
    $classes[] = 'pt-20';
    return $classes;
}


// ==============================================================================
// PRIVACY: NIENTE RICHIESTE A GOOGLE FONTS
// Il parent carica Poppins da fonts.googleapis.com e apre due preconnect verso Google
// su ogni pagina: l'IP del visitatore arriva a Google prima di qualsiasi consenso.
// Questo sito usa solo font ospitati in assets/fonts, quindi li togliamo qui (solo Mela Verde).
// ==============================================================================

add_action( 'wp_enqueue_scripts', 'melaverde_no_google_fonts', 20 );
function melaverde_no_google_fonts() {
    // ticinoweb-ai-style dipende da poppins-font: lo si sostituisce con un handle vuoto
    // invece di toglierlo, così la dipendenza resta valida e non si stampa nulla.
    wp_deregister_style( 'poppins-font' );
    wp_register_style( 'poppins-font', false, array(), null );
}

add_action( 'wp_head', 'melaverde_remove_parent_google_preconnect', -100 );
function melaverde_remove_parent_google_preconnect() {
    global $wp_filter;
    if ( empty( $wp_filter['wp_head'] ) || empty( $wp_filter['wp_head']->callbacks[0] ) ) {
        return;
    }
    $parent_functions = wp_normalize_path( get_template_directory() . '/functions.php' );
    foreach ( $wp_filter['wp_head']->callbacks[0] as $callback ) {
        if ( ! ( $callback['function'] instanceof Closure ) ) {
            continue;
        }
        $ref = new ReflectionFunction( $callback['function'] );
        // Solo la closure del parent che stampa i preconnect verso fonts.googleapis.com.
        if ( wp_normalize_path( (string) $ref->getFileName() ) === $parent_functions ) {
            $lines = file( $parent_functions );
            $body  = implode( '', array_slice( (array) $lines, $ref->getStartLine() - 1, $ref->getEndLine() - $ref->getStartLine() + 1 ) );
            if ( strpos( $body, 'fonts.googleapis.com' ) !== false ) {
                remove_action( 'wp_head', $callback['function'], 0 );
            }
        }
    }
}

// Banner cookie del parent nei font e nei colori del sito (prima ereditava Poppins).
add_action( 'wp_head', 'melaverde_cookie_banner_style', 100 );
function melaverde_cookie_banner_style() {
    ?>
    <style id="melaverde-cookie-banner">
        body { --tw-cookie-primary: #4a7c59; }
        body .tw-cookie-banner, body .tw-cookie-banner button, body .tw-cookie-btn, body .tw-cookie-modal, body .tw-cookie-modal button { font-family: 'Nunito Sans', sans-serif; }
    </style>
    <?php
}
