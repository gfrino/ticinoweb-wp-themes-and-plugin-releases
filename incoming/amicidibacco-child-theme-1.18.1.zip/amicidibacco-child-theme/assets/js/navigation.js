(() => {
    'use strict';
    const menuButton = document.querySelector('[data-menu-toggle]');
    const menu = document.querySelector('#adb-main-nav');
    const header = document.querySelector('[data-header]');
    const mobile = window.matchMedia('(max-width: 1000px)');
    const inertState = new Map();
    const openLabel = menuButton?.getAttribute('aria-label') || '';
    let isOpen = false;
    const closeMenu = (restoreFocus = false) => {
        const wasOpen = isOpen;
        isOpen = false;
        menu?.classList.remove('is-open');
        menuButton?.setAttribute('aria-expanded', 'false');
        menuButton?.setAttribute('aria-label', openLabel);
        document.documentElement.classList.remove('adb-menu-open');
        document.body.classList.remove('adb-menu-open');
        inertState.forEach((value, node) => { node.inert = value; });
        inertState.clear();
        if (menu) menu.inert = mobile.matches;
        if (wasOpen && !document.querySelector('dialog[open]')) window.adbSmoothScroll?.start();
        if (restoreFocus && wasOpen) menuButton?.focus({preventScroll: true});
    };
    const openMenu = () => {
        if (!mobile.matches || !menu || !menuButton) return;
        isOpen = true;
        menu.inert = false;
        menu.classList.add('is-open');
        menuButton.setAttribute('aria-expanded', 'true');
        menuButton.setAttribute('aria-label', menuButton.dataset.closeLabel || openLabel);
        document.documentElement.classList.add('adb-menu-open');
        document.body.classList.add('adb-menu-open');
        document.querySelectorAll('#main-content, .adb-footer, .adb-skip').forEach(node => { inertState.set(node, node.inert); node.inert = true; });
        window.adbSmoothScroll?.stop();
        menu.querySelector('a')?.focus({preventScroll: true});
    };
    menuButton?.addEventListener('click', () => { if (isOpen) closeMenu(true); else openMenu(); });
    header?.addEventListener('click', event => { if (event.target.closest('a')) closeMenu(); });
    document.addEventListener('keydown', event => {
        if (!isOpen) return;
        if (event.key === 'Escape') { event.preventDefault(); closeMenu(true); }
        if (event.key !== 'Tab') return;
        const controls = [...header.querySelectorAll('a[href],button:not([disabled])')].filter(node => node.getClientRects().length && !node.closest('[inert]'));
        if (event.shiftKey && document.activeElement === controls[0]) { event.preventDefault(); controls.at(-1)?.focus(); }
        else if (!event.shiftKey && document.activeElement === controls.at(-1)) { event.preventDefault(); controls[0]?.focus(); }
    });
    document.addEventListener('click', event => { if (isOpen && !event.target.closest('.adb-header')) closeMenu(); });
    mobile.addEventListener('change', () => closeMenu());
    window.addEventListener('pageshow', () => closeMenu());
    closeMenu();

    // WordPress's phone toolbar scrolls away; the tablet/desktop toolbar stays fixed.
    const toolbar = document.querySelector('#wpadminbar');
    if (toolbar && header) {
        let frame;
        const position = () => { frame = 0; header.style.setProperty('--adb-toolbar-offset', `${Math.max(0, toolbar.getBoundingClientRect().bottom)}px`); };
        const schedule = () => { if (!frame) frame = requestAnimationFrame(position); };
        window.addEventListener('scroll', schedule, {passive:true});
        window.addEventListener('resize', schedule, {passive:true});
        position();
    }
    const dialog = document.querySelector('[data-search-dialog]');
    const openSearch = document.querySelector('[data-search-open]');
    openSearch?.addEventListener('click', () => {
        closeMenu();
        if (dialog?.showModal) { dialog.showModal(); window.adbSmoothScroll?.stop(); dialog.querySelector('input[type="search"]')?.focus({ preventScroll: true }); }
    });
    dialog?.querySelector('[data-search-close]')?.addEventListener('click', () => dialog.close());
    dialog?.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
    dialog?.addEventListener('close', () => { if (document.querySelector('[data-vigna][open]')) return; window.adbSmoothScroll?.start(); openSearch?.focus(); });
})();
