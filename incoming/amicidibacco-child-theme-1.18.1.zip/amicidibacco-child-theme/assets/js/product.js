/* A single quiet settling motion. Every section remains visible without JS. */
(function () {
    'use strict';
    var sections = document.querySelectorAll('[data-product-reveal]');
    if (!sections.length || !('IntersectionObserver' in window) ||
        window.matchMedia('(prefers-reduced-motion: reduce)').matches) { return; }
    var observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (!entry.isIntersecting) { return; }
            entry.target.classList.add('is-product-visible');
            observer.unobserve(entry.target);
        });
    }, { threshold: 0.08, rootMargin: '0px 0px -30px 0px' });
    sections.forEach(function (section) { observer.observe(section); });
}());
