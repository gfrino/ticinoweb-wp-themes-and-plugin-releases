<?php
/**
 * Template Name: FAQ
 * Template Post Type: page
 *
 * Pagina dedicata alle Domande Frequenti (FAQ / AEO) per Idea Lugano.
 * Progettata per gli utenti e per i motori di ricerca AI e tradizionali.
 *
 * @package Idealugano
 * @version 1.14.0
 */

$site = idealugano_get_site_data();
$contact = $site['contact'];

$faq_categories = idealugano_faq_categories();

// Dati strutturati FAQPage (Google e assistenti AI): stampati una volta per pagina.
$faq_schema_items = array();
foreach ($faq_categories as $cat) {
    $faq_schema_items = array_merge($faq_schema_items, $cat['items']);
}
?>
<?php get_header(); ?>
<?php idealugano_faq_schema($faq_schema_items); ?>


<main id="primary" class="site-main">

	<!-- ═══════════════════════════════════════════
	     1. PAGE HERO
	     ═══════════════════════════════════════════ -->
	<section class="idea-page-hero" aria-labelledby="faq-page-title">
		<span class="idea-deco-word idea-fx" data-speed="0.8" style="bottom: -3rem; right: -5%; opacity: 0.25;" aria-hidden="true">RISPOSTE</span>
		<div class="idea-container">
			<span class="idea-eyebrow">Guida & Risposte</span>
			<h1 id="faq-page-title" class="idea-page-hero__title">Domande Frequenti su Idea Lugano</h1>
			<hr class="idea-gold-line idea-gold-line--center">
			<p class="idea-page-hero__subtitle">
				Tutto ciò che desideri sapere sui nostri servizi di tappezzeria, tende su misura, imbottiti artigianali e consulenza d'arredo a Lugano e nel Canton Ticino.
			</p>
		</div>
	</section>

	<!-- ═══════════════════════════════════════════
	     2. CATEGORY QUICK NAV (Anchor Pills)
	     ═══════════════════════════════════════════ -->
	<section class="idea-section idea-section--white idea-faq-nav-section">
		<div class="idea-container">
			<nav class="idea-faq-pills" aria-label="<?php esc_attr_e('Indice argomenti FAQ', 'idealugano'); ?>">
				<?php foreach ($faq_categories as $cat): ?>
					<a class="idea-faq-pill" href="#<?php echo esc_attr($cat['id']); ?>">
						<?php echo esc_html($cat['title']); ?>
					</a>
				<?php endforeach; ?>
			</nav>
		</div>
	</section>

	<!-- ═══════════════════════════════════════════
	     3. FAQ ACCORDION LIST
	     ═══════════════════════════════════════════ -->
	<section class="idea-section idea-section--cream idea-faq-main-section">
		<div class="idea-container idea-faq-container">

			<?php foreach ($faq_categories as $cat_index => $cat): ?>
				<div class="idea-faq-category" id="<?php echo esc_attr($cat['id']); ?>">
					<div class="idea-faq-category__header reveal">
						<span class="idea-eyebrow">Sezione <?php echo str_pad($cat_index + 1, 2, '0', STR_PAD_LEFT); ?></span>
						<h2 class="idea-faq-category__title"><?php echo esc_html($cat['title']); ?></h2>
						<hr class="idea-gold-line">
						<p class="idea-faq-category__desc"><?php echo esc_html($cat['desc']); ?></p>
					</div>

					<div class="idea-faq-items reveal">
						<?php foreach ($cat['items'] as $item_index => $item): ?>
							<details class="idea-faq-item" <?php echo ($cat_index === 0 && $item_index === 0) ? 'open' : ''; ?>>
								<summary class="idea-faq-question">
									<h3 class="idea-faq-question__title"><?php echo esc_html($item['q']); ?></h3>
									<span class="idea-faq-toggle" aria-hidden="true">
										<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
											<polyline points="6 9 12 15 18 9"></polyline>
										</svg>
									</span>
								</summary>
								<div class="idea-faq-answer">
									<?php echo wp_kses_post(wpautop($item['a'])); ?>
								</div>
							</details>
						<?php endforeach; ?>
					</div>
				</div>
			<?php endforeach; ?>

		</div>
	</section>

	<!-- ═══════════════════════════════════════════
	     4. CALL TO ACTION
	     ═══════════════════════════════════════════ -->
	<section class="idea-section idea-section--petrol">
		<div class="idea-container idea-text-center reveal">
			<span class="idea-eyebrow" style="color: var(--idea-gold-light);">Hai altre domande?</span>
			<h2>Parliamo del tuo progetto d'arredo</h2>
			<hr class="idea-gold-line idea-gold-line--center" style="background: linear-gradient(90deg, transparent, var(--idea-gold-light), transparent);">
			<p class="idea-lead idea-mx-auto" style="color: rgba(247, 243, 234, 0.85); max-width: 680px;">
				Ogni casa e ogni spazio hanno esigenze particolari. Monica Spirig Papini e il team di Idea Lugano sono a disposizione per una consulenza personalizzata su appuntamento.
			</p>
			<div class="idea-mt-6" style="display:flex; justify-content:center; gap:16px; flex-wrap:wrap;">
				<a class="idea-btn idea-btn--gold" href="<?php echo esc_url(home_url('/contatti/')); ?>">
					Prenota una consulenza
				</a>
				<a class="idea-btn idea-btn--ghost" href="tel:<?php echo esc_attr(str_replace(' ', '', $contact['phone'])); ?>">
					Chiamaci: <?php echo esc_html($contact['phone']); ?>
				</a>
			</div>
		</div>
	</section>

</main>

<?php get_footer(); ?>
