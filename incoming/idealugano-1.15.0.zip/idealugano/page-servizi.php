<?php
/**
 * Template Name: Servizi
 * Template Post Type: page
 *
 * @package Idealugano
 * @version 1.1.0
 */
$site = idealugano_get_site_data();
$services = $site['services'];
?>
<?php get_header(); ?>

<main id="primary" class="site-main">

	<!-- Page Hero -->
	<section class="idea-page-hero" aria-labelledby="services-page-title">
		<div class="idea-container">
			<span class="idea-eyebrow">Servizi</span>
			<h1 id="services-page-title" class="idea-page-hero__title">I nostri servizi</h1>
			<hr class="idea-gold-line idea-gold-line--center">
			<p class="idea-page-hero__subtitle">
				Tende su misura, divani e letti, rifacimento di imbottiti, tessuti d'arredamento e arredamento completo: ogni servizio ha una pagina dedicata con dettagli, marchi partner e domande frequenti.
			</p>
		</div>
	</section>

	<!-- Services Detail -->
	<section class="idea-section idea-section--white">
		<div class="idea-container">
			<?php foreach ($services as $index => $service): ?>
				<div class="idea-service-detail reveal" id="servizio-<?php echo esc_attr($service['slug']); ?>">
					<div class="idea-service-detail__text">
						<span class="idea-eyebrow">Servizio <?php echo str_pad($index + 1, 2, '0', STR_PAD_LEFT); ?></span>
						<h2><?php echo esc_html($service['title']); ?></h2>
						<hr class="idea-gold-line">
						<p style="line-height: 1.8; color: var(--idea-grey); margin-bottom: 1.5rem;">
							<?php echo esc_html($service['desc']); ?>
						</p>
						<?php if (!empty($service['url'])): ?>
							<div class="idea-landing-hero__actions" style="margin-top:0;">
								<a class="idea-btn idea-btn--primary" href="<?php echo esc_url($service['url']); ?>">Scopri il servizio</a>
								<a class="idea-link" href="<?php echo esc_url($service['url'] . '#richiesta'); ?>">Richiedi un preventivo <span class="idea-link__arrow">→</span></a>
							</div>
						<?php else: ?>
							<a class="idea-link" href="<?php echo esc_url(home_url('/contatti/')); ?>">
								Richiedi informazioni <span class="idea-link__arrow">→</span>
							</a>
						<?php endif; ?>
					</div>
					<div class="idea-service-detail__image">
						<?php
						$srv_img = (!empty($service['slot']) ? idealugano_get_slot_image($service['slot']) : false) ?: idealugano_get_image_by_filename(basename($service['image']));
						if ($srv_img):
						?>
							<img src="<?php echo esc_url($srv_img); ?>" <?php idealugano_img_attrs($srv_img); ?> alt="<?php echo esc_attr($service['title']); ?>" loading="lazy" decoding="async" sizes="(max-width: 767px) calc(100vw - 2.3rem), 50vw">
						<?php else: ?>
							<?php idealugano_placeholder_image('4/3', $service['title']); ?>
						<?php endif; ?>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</section>

	<!-- CTA -->
	<section class="idea-section idea-section--petrol">
		<div class="idea-container idea-text-center reveal">
			<h2>Raccontaci il tuo progetto</h2>
			<hr class="idea-gold-line idea-gold-line--center" style="background: linear-gradient(90deg, transparent, var(--idea-gold-light), transparent);">
			<p class="idea-lead idea-mx-auto" style="color: rgba(247, 243, 234, 0.7);">
				Ogni ambiente ha una storia da raccontare. Contattaci per iniziare la tua.
			</p>
			<div class="idea-mt-4">
				<a class="idea-btn idea-btn--gold" href="<?php echo esc_url(home_url('/contatti/')); ?>">
					Raccontaci il tuo progetto
				</a>
			</div>
		</div>
	</section>

</main>

<?php get_footer(); ?>
