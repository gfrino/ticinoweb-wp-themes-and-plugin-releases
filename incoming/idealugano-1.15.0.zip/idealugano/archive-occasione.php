<?php
/**
 * Template per l'archivio delle Occasioni di Idea Lugano.
 * URL: /occasioni/
 *
 * @package Idealugano
 * @version 1.9.78
 */

get_header();

$site = idealugano_get_site_data();
$contact = $site['contact'];
?>

<main id="primary" class="site-main">

	<!-- Page Hero -->
	<section class="idea-page-hero" aria-labelledby="occasioni-title">
		<div class="idea-container">
			<span class="idea-eyebrow"><?php esc_html_e( 'Idea Lugano · Atelier Artigianale', 'idealugano' ); ?></span>
			<h1 id="occasioni-title" class="idea-page-hero__title"><?php esc_html_e( 'Occasioni d\'Atelier', 'idealugano' ); ?></h1>
			<hr class="idea-gold-line idea-gold-line--center">
			<p class="idea-page-hero__subtitle">
				<?php esc_html_e( 'Campionari showroom, pezzi unici realizzati a mano e tessuti pregiati in pronta consegna a condizioni speciali.', 'idealugano' ); ?>
			</p>
		</div>
	</section>

	<!-- Griglia Occasioni -->
	<section class="idea-section idea-section--white" id="catalogo-occasioni">
		<div class="idea-container">

			<div class="idea-occasioni-header reveal">
				<div>
					<span class="idea-eyebrow"><?php esc_html_e( 'Disponibilità immediata', 'idealugano' ); ?></span>
					<h2 class="idea-occasioni-header__title"><?php esc_html_e( 'Creazioni e Campionari in Evidenza', 'idealugano' ); ?></h2>
					<hr class="idea-gold-line">
				</div>
				<div class="idea-occasioni-header__note">
					<span><?php esc_html_e( 'Tutti i pezzi sono visionabili su appuntamento presso il nostro atelier.', 'idealugano' ); ?></span>
					<a href="<?php echo esc_url( home_url( '/contatti/' ) ); ?>" class="idea-link-gold">
						<?php esc_html_e( 'Prenota un appuntamento', 'idealugano' ); ?> &rarr;
					</a>
				</div>
			</div>

			<?php if ( have_posts() ) : ?>
				<div class="idea-occasioni-grid reveal-stagger">
					<?php while ( have_posts() ) : the_post();
						$meta        = idealugano_get_occasione_meta( get_the_ID() );
						$contact_url = idealugano_get_occasione_contact_url( get_the_ID() );

						$status_labels = array(
							'disponibile' => array( 'label' => __( 'Disponibile subito', 'idealugano' ), 'class' => 'status-disponibile' ),
							'pezzo_unico' => array( 'label' => __( 'Pezzo unico d\'atelier', 'idealugano' ), 'class' => 'status-pezzo-unico' ),
							'campionario' => array( 'label' => __( 'Campionario showroom', 'idealugano' ), 'class' => 'status-campionario' ),
							'trattativa'  => array( 'label' => __( 'In trattativa', 'idealugano' ), 'class' => 'status-trattativa' ),
							'venduto'     => array( 'label' => __( 'Venduto', 'idealugano' ), 'class' => 'status-venduto' ),
						);
						$st_info = isset( $status_labels[ $meta['status'] ] ) ? $status_labels[ $meta['status'] ] : $status_labels['disponibile'];
					?>
						<article id="post-<?php the_ID(); ?>" <?php post_class( 'idea-occ-card ' . $st_info['class'] ); ?>>
							<div class="idea-occ-card__media">
								<a href="<?php the_permalink(); ?>" class="idea-occ-card__media-link" aria-label="<?php the_title_attribute(); ?>">
									<?php if ( has_post_thumbnail() ) : ?>
										<?php the_post_thumbnail( 'large', array( 'loading' => 'lazy', 'alt' => get_the_title() ) ); ?>
									<?php else : ?>
										<div class="idea-occ-card__placeholder">
											<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
											<span><?php esc_html_e( 'Idea Lugano Atelier', 'idealugano' ); ?></span>
										</div>
									<?php endif; ?>
								</a>
								<span class="idea-occ-badge <?php echo esc_attr( $st_info['class'] ); ?>">
									<?php echo esc_html( $st_info['label'] ); ?>
								</span>
								<?php if ( ! empty( $meta['old_price'] ) && 'venduto' !== $meta['status'] ) : ?>
									<span class="idea-occ-discount-badge">
										<?php esc_html_e( 'Offerta', 'idealugano' ); ?>
									</span>
								<?php endif; ?>
							</div>

							<div class="idea-occ-card__body">
								<div class="idea-occ-card__meta">
									<?php if ( ! empty( $meta['type'] ) ) : ?>
										<span class="idea-occ-type"><?php echo esc_html( $meta['type'] ); ?></span>
									<?php endif; ?>
									<?php if ( ! empty( $meta['dimensions'] ) ) : ?>
										<span class="idea-occ-dimensions"><?php echo esc_html( $meta['dimensions'] ); ?></span>
									<?php endif; ?>
								</div>

								<h3 class="idea-occ-card__title">
									<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
								</h3>

								<?php if ( ! empty( $meta['materials'] ) ) : ?>
									<p class="idea-occ-card__materials">
										<strong><?php esc_html_e( 'Tessuto / Materiali:', 'idealugano' ); ?></strong> <?php echo esc_html( $meta['materials'] ); ?>
									</p>
								<?php endif; ?>

								<div class="idea-occ-card__excerpt">
									<?php
									$excerpt = get_the_excerpt();
									if ( empty( $excerpt ) ) {
										$excerpt = wp_trim_words( get_the_content(), 18, '…' );
									}
									echo esc_html( wp_trim_words( $excerpt, 18, '…' ) );
									?>
								</div>

								<div class="idea-occ-card__price-box">
									<?php if ( ! empty( $meta['price'] ) ) : ?>
										<div class="idea-occ-price">
											<span class="idea-occ-price__amount"><?php echo esc_html( $meta['price'] ); ?></span>
											<?php if ( ! empty( $meta['old_price'] ) ) : ?>
												<s class="idea-occ-price__old"><?php echo esc_html( $meta['old_price'] ); ?></s>
											<?php endif; ?>
										</div>
									<?php else : ?>
										<div class="idea-occ-price idea-occ-price--request">
											<span class="idea-occ-price__amount"><?php esc_html_e( 'Prezzo su richiesta', 'idealugano' ); ?></span>
										</div>
									<?php endif; ?>
								</div>

								<div class="idea-occ-card__actions">
									<?php if ( 'venduto' === $meta['status'] ) : ?>
										<span class="idea-btn idea-btn--outline is-disabled" aria-disabled="true">
											<?php esc_html_e( 'Pezzo non disponibile', 'idealugano' ); ?>
										</span>
									<?php else : ?>
										<a href="<?php echo esc_url( $contact_url ); ?>" class="idea-btn idea-btn--gold idea-occ-btn-contact">
											<?php echo esc_html( $meta['cta_text'] ); ?>
										</a>
									<?php endif; ?>
									<a href="<?php the_permalink(); ?>" class="idea-btn idea-btn--outline" aria-label="<?php echo esc_attr( sprintf( __( 'Dettagli su %s', 'idealugano' ), get_the_title() ) ); ?>">
										<?php esc_html_e( 'Dettagli', 'idealugano' ); ?> &rarr;
									</a>
								</div>
							</div>
						</article>
					<?php endwhile; ?>
				</div>

				<?php
				$pagination = paginate_links( array(
					'type'      => 'list',
					'prev_text' => '&larr; ' . esc_html__( 'Precedente', 'idealugano' ),
					'next_text' => esc_html__( 'Successivo', 'idealugano' ) . ' &rarr;',
				) );
				if ( $pagination ) : ?>
					<nav class="idea-pagination" aria-label="<?php esc_attr_e( 'Paginazione occasioni', 'idealugano' ); ?>">
						<?php echo wp_kses_post( $pagination ); ?>
					</nav>
				<?php endif; ?>

			<?php else : ?>
				<div class="idea-occasioni-empty reveal">
					<div class="idea-occasioni-empty__icon">
						<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>
					</div>
					<h3 class="idea-occasioni-empty__title"><?php esc_html_e( 'Nessuna occasione disponibile al momento', 'idealugano' ); ?></h3>
					<hr class="idea-gold-line idea-gold-line--center">
					<p class="idea-occasioni-empty__text">
						<?php esc_html_e( 'I nostri pezzi unici e campionari d\'atelier vengono aggiornati periodicamente. Contattaci per informarci sui tessuti, tende o arredi che stai cercando: saremo felici di guidarti o realizzare una proposta su misura per i tuoi spazi.', 'idealugano' ); ?>
					</p>
					<div class="idea-mt-6">
						<a href="<?php echo esc_url( home_url( '/contatti/' ) ); ?>" class="idea-btn idea-btn--gold">
							<?php esc_html_e( 'Contatta Monica all\'Atelier', 'idealugano' ); ?> &rarr;
						</a>
					</div>
				</div>
			<?php endif; ?>

		</div>
	</section>

	<!-- Banner Atelier CTA -->
	<section class="idea-section idea-section--petrol">
		<div class="idea-container idea-text-center reveal">
			<span class="idea-eyebrow" style="color: var(--idea-gold-light);"><?php esc_html_e( 'Su misura per te', 'idealugano' ); ?></span>
			<h2><?php esc_html_e( 'Desideri un arredo su misura o personalizzato?', 'idealugano' ); ?></h2>
			<hr class="idea-gold-line idea-gold-line--center" style="background: linear-gradient(90deg, transparent, var(--idea-gold-light), transparent);">
			<p class="idea-lead idea-mx-auto" style="color: rgba(247, 243, 234, 0.75);">
				<?php esc_html_e( 'Ogni ambiente ha la sua storia e le sue misure. Realizziamo tende, cuscini, imbottiti e paralumi totalmente personalizzati con tessuti esclusivi.', 'idealugano' ); ?>
			</p>
			<div class="idea-mt-6">
				<a class="idea-btn idea-btn--gold" href="tel:<?php echo esc_attr( str_replace( ' ', '', $contact['phone'] ) ); ?>">
					<?php esc_html_e( 'Chiamaci per una consulenza', 'idealugano' ); ?>
				</a>
			</div>
		</div>
	</section>

</main>

<?php get_footer(); ?>
