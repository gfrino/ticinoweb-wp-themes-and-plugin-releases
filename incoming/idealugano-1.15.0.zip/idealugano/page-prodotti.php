<?php
/**
 * Template Name: Prodotti
 * Template Post Type: page
 *
 * @package Idealugano
 * @version 1.1.0
 */
$site = idealugano_get_site_data();
$curtain_types = $site['curtain_types'];
$products = $site['products'];
$brands = $site['brands'];
$contact = $site['contact'];
?>
<?php get_header(); ?>

<main id="primary" class="site-main">

	<!-- Page Hero -->
	<section class="idea-page-hero" aria-labelledby="products-page-title">
		<div class="idea-container">
			<span class="idea-eyebrow">Prodotti</span>
			<h1 id="products-page-title" class="idea-page-hero__title">I nostri prodotti</h1>
			<hr class="idea-gold-line idea-gold-line--center">
			<p class="idea-page-hero__subtitle">
				Tende, tessuti d'arredamento, divani e letti, materassi Tréca Paris e complementi: tutto ciò che forniamo, sempre su misura.
			</p>
		</div>
	</section>

	<!-- 1. Tende e sistemi -->
	<section class="idea-section idea-section--white" aria-labelledby="prod-curtains-title">
		<div class="idea-container">
			<div class="idea-mb-8 reveal">
				<span class="idea-eyebrow">Tende e sistemi</span>
				<h2 id="prod-curtains-title">Tende su misura</h2>
				<hr class="idea-gold-line">
				<div class="idea-curtains-desc">
					<p class="idea-lead">
						Creiamo tende su misura per interni ed esterni, progettate specificamente per le tue finestre e per il tuo stile di vita. Ogni soluzione viene curata nei dettagli per garantire qualità, funzionalità ed eleganza.
					</p>
					<p class="idea-lead">
						Dal sopralluogo alla posa in opera, ti seguiamo in ogni fase del progetto, assicurando un risultato armonioso, pratico e perfettamente integrato con i tuoi spazi.
					</p>
					<p><a class="idea-btn idea-btn--ghost" href="<?php echo esc_url(idealugano_landing_url('tende-su-misura')); ?>">Tutto sulle tende su misura</a></p>
				</div>
			</div>
			<div class="idea-grid idea-grid--4 reveal-stagger">
				<?php foreach ($curtain_types as $curtain): ?>
					<a href="<?php echo esc_url(home_url('/galleria/?categoria=tende#gallery-grid-title')); ?>"
					   class="idea-curtain-card reveal"
					   aria-label="<?php echo esc_attr(sprintf(__('Scopri i lavori di %s nella galleria', 'idealugano'), $curtain['title'])); ?>">
						<?php
						$crt_img = (!empty($curtain['slot']) ? idealugano_get_slot_image($curtain['slot']) : false) ?: idealugano_get_image_by_filename(basename($curtain['image']));
						if ($crt_img):
						?>
							<img class="idea-curtain-card__image" src="<?php echo esc_url($crt_img); ?>" <?php idealugano_img_attrs($crt_img); ?> alt="<?php echo esc_attr($curtain['title']); ?>" loading="lazy" decoding="async" sizes="(max-width: 767px) calc(100vw - 2.3rem), 25vw">
						<?php else: ?>
							<?php idealugano_placeholder_image('3/4', $curtain['title']); ?>
						<?php endif; ?>
						<div class="idea-curtain-card__overlay"></div>
						<div class="idea-curtain-card__content">
							<h3 class="idea-curtain-card__title"><?php echo esc_html($curtain['title']); ?></h3>
							<span class="idea-curtain-card__cta">
								Vedi in galleria <span class="idea-link__arrow" aria-hidden="true">→</span>
							</span>
						</div>
					</a>
				<?php endforeach; ?>
			</div>
		</div>
	</section>

	<!-- 2. Tessuti e imbottiti -->
	<section class="idea-section idea-section--cream" aria-labelledby="prod-fabrics-title">
		<div class="idea-container">
			<div class="idea-mb-8 reveal">
				<span class="idea-eyebrow">Collezioni e complementi</span>
				<h2 id="prod-fabrics-title">Tessuti e imbottiti</h2>
				<hr class="idea-gold-line">
				<p class="idea-lead">
					Tessuti d'arredamento dei maggiori editori, anche al metro; divani, poltrone e letti su misura; imbottiti rimessi a nuovo; cuscini, copriletti e paralumi coordinati.
				</p>
			</div>
			<div class="idea-products-grid reveal-stagger">
				<?php foreach ($products as $product): ?>
					<?php $cat_url = !empty($product['url']) ? $product['url'] : home_url('/galleria/#gallery-grid-title'); ?>
					<a href="<?php echo esc_url($cat_url); ?>"
					   class="idea-product-card reveal"
					   aria-label="<?php echo esc_attr(sprintf(__('Scopri %s', 'idealugano'), $product['title'])); ?>">
						<div class="idea-product-card__image">
							<?php
							$prod_img = (!empty($product['slot']) ? idealugano_get_slot_image($product['slot']) : false) ?: idealugano_get_image_by_filename(basename($product['image']));
							if ($prod_img):
							?>
								<img src="<?php echo esc_url($prod_img); ?>" <?php idealugano_img_attrs($prod_img); ?> alt="<?php echo esc_attr($product['title']); ?>" loading="lazy" decoding="async" sizes="(max-width: 767px) calc(100vw - 2.3rem), 300px">
							<?php else: ?>
								<?php idealugano_placeholder_image('3/4', $product['title']); ?>
							<?php endif; ?>
						</div>
						<div class="idea-product-card__body">
							<h3 class="idea-product-card__title"><?php echo esc_html($product['title']); ?></h3>
							<span class="idea-product-card__action">
								Scopri <span class="idea-link__arrow" aria-hidden="true">→</span>
							</span>
						</div>
					</a>
				<?php endforeach; ?>
			</div>
		</div>
	</section>

	<!-- 2b. Letti e materassi Tréca Paris (1.13.0) -->
	<section class="idea-section idea-section--white" aria-labelledby="prod-treca-title">
		<div class="idea-container">
			<div class="idea-mb-8 reveal">
				<span class="idea-eyebrow">Rivenditori autorizzati</span>
				<h2 id="prod-treca-title">Letti, materassi e testiere Tréca Paris</h2>
				<hr class="idea-gold-line">
				<p class="idea-lead">
					L'unica maison francese di letti interamente confezionati a mano: sistemi di riposo che uniscono sur-matelas, materasso e sommier, con testiere rivestite nel tessuto o nella pelle che scegli con noi in atelier.
				</p>
			</div>
			<div class="idea-landing-gallery reveal-stagger">
				<?php
				$treca_items = array(
					array('slot' => 'sup_treca_sistema_paris_vienne_venise', 'title' => 'Sistemi di riposo'),
					array('slot' => 'sup_treca_materassi', 'title' => 'Materassi confezionati a mano'),
					array('slot' => 'sup_treca_testiera_versailles', 'title' => 'Testiere su misura'),
				);
				foreach ($treca_items as $treca):
					$treca_img = idealugano_get_slot_image($treca['slot']);
					if (!$treca_img) continue;
				?>
					<a class="idea-landing-gallery__item reveal" href="<?php echo esc_url(idealugano_landing_url('divani-letti-su-misura')); ?>">
						<img src="<?php echo esc_url($treca_img); ?>" <?php idealugano_img_attrs($treca_img); ?> alt="Tréca Paris: <?php echo esc_attr($treca['title']); ?>" loading="lazy" decoding="async" sizes="(max-width: 640px) calc(100vw - 2.3rem), 30vw">
						<span class="idea-landing-gallery__caption"><?php echo esc_html($treca['title']); ?></span>
					</a>
				<?php endforeach; ?>
			</div>
			<div class="idea-mt-6 reveal">
				<a class="idea-btn idea-btn--gold" href="<?php echo esc_url(idealugano_landing_url('divani-letti-su-misura')); ?>">Divani, letti e imbottiti su misura <span class="idea-btn__arrow">→</span></a>
			</div>
			<p class="idea-partner-note" style="text-align:left;">Foto © Tréca Paris.</p>
		</div>
	</section>

	<!-- 3. Oggettistica -->
	<section class="idea-section idea-section--cream" aria-labelledby="prod-objects-title">
		<div class="idea-container">
			<div class="idea-mb-8 reveal">
				<span class="idea-eyebrow">Complementi</span>
				<h2 id="prod-objects-title">Oggettistica e dettagli</h2>
				<hr class="idea-gold-line">
				<p class="idea-lead">
					Su richiesta selezioniamo oggetti e complementi d'arredo coordinati al progetto: alcuni esempi tra i pezzi che abbiamo trattato.
				</p>
			</div>
			<div class="idea-objects-grid reveal">
				<?php
				$object_captions = array('Scultura decorativa', 'Vaso in pietra', 'Complemento naturale', 'Dettaglio per interni');
				$object_slots = array('object_01', 'object_02', 'object_03');
				for ($i = 1; $i <= 3; $i++):
					$obj_img = idealugano_get_slot_image($object_slots[$i - 1]) ?: idealugano_get_image_by_filename("object-0{$i}.jpg");
					$caption = $object_captions[$i - 1];
				?>
					<div class="idea-object-item">
						<?php if ($obj_img): ?>
							<img src="<?php echo esc_url($obj_img); ?>" <?php idealugano_img_attrs($obj_img); ?> alt="<?php echo esc_attr($caption); ?>" loading="lazy" decoding="async" sizes="(max-width: 767px) 46vw, 25vw">
						<?php else: ?>
							<?php idealugano_placeholder_image('1/1', $caption); ?>
						<?php endif; ?>
						<div class="idea-object-item__caption"><?php echo esc_html($caption); ?></div>
					</div>
				<?php endfor; ?>
			</div>
		</div>
	</section>

	<!-- 4. Marchi selezionati -->
	<section class="idea-section idea-section--white" aria-labelledby="prod-brands-title">
		<div class="idea-container">
			<div class="idea-text-center idea-mb-8 reveal">
				<span class="idea-eyebrow">Partner</span>
				<h2 id="prod-brands-title">Marchi selezionati</h2>
				<hr class="idea-gold-line idea-gold-line--center">
			</div>
			<div class="idea-brands-grid idea-brands-grid--3x2 reveal">
				<?php foreach (array_slice($brands, 0, 6) as $brand): ?>
					<?php
					$brand_img = !empty($brand['logo']) ? $brand['logo'] : ((!empty($brand['slot']) ? idealugano_get_slot_image($brand['slot']) : false) ?: idealugano_get_image_by_filename(basename(!empty($brand['logo']) ? $brand['logo'] : '')));
					?>
					<div class="idea-brand-item" title="<?php echo esc_attr($brand['name']); ?>">
						<?php if ($brand_img): ?>
							<img src="<?php echo esc_url($brand_img); ?>" <?php idealugano_img_attrs($brand_img); ?> alt="<?php echo esc_attr($brand['name']); ?>" loading="lazy" decoding="async" sizes="(max-width: 767px) 135px, 180px">
						<?php else: ?>
							<span class="idea-brand-item__text"><?php echo esc_html($brand['name']); ?></span>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>

			<div class="idea-text-center idea-mt-8 reveal">
				<a class="idea-btn idea-btn--gold" href="<?php echo esc_url(home_url('/marchi/')); ?>">
					Vedi tutti i marchi <span class="idea-btn__arrow">→</span>
				</a>
			</div>
		</div>
	</section>

	<!-- 5. CTA Instagram -->
	<?php if (!empty($contact['instagram'])): ?>
	<section class="idea-section idea-section--white">
		<div class="idea-container idea-text-center reveal">
			<h2>Scopri di più</h2>
			<hr class="idea-gold-line idea-gold-line--center">
			<p class="idea-lead idea-mx-auto idea-mb-4">
				Seguici su Instagram per vedere le ultime creazioni, lavorazioni e ispirazioni.
			</p>
			<a class="idea-btn idea-btn--primary" href="<?php echo esc_url($contact['instagram']); ?>" target="_blank" rel="noopener">
				<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>
				Scopri di più su Instagram
			</a>
		</div>
	</section>
	<?php endif; ?>

</main>

<?php get_footer(); ?>
