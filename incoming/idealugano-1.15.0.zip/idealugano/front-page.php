<?php
/**
 * Front page template for Idealugano — 12-section homepage
 *
 * @package Idealugano
 * @version 1.8.0
 */
$site = idealugano_get_site_data();
$hero = $site['hero'];
$about = $site['about'];
$services = $site['services'];
$curtain_types = $site['curtain_types'];
$products = $site['products'];
$brands = $site['brands'];
$testimonials = $site['testimonials'];
$before_after = $site['before_after'];
$contact = $site['contact'];
$hours = $site['hours'];
?>
<?php get_header(); ?>

<script>document.documentElement.classList.add('curtain-active');document.body.classList.add('idea-hero-visible', 'curtain-active');</script>

<main id="primary" class="site-main">

	<!-- ═══════════════════════════════════════════
	     1. CURTAIN INTRO
	     ═══════════════════════════════════════════ -->
	<div class="curtain-overlay" id="curtain-overlay" aria-hidden="true">
		<!-- Soft scrim behind the sheer fabric, fades as curtains open -->
		<div class="curtain-overlay__scrim" id="curtain-scrim"></div>
		<!-- Frosted-glass layers: backdrop blur clipped to each curtain's live shape (JS-driven) -->
		<div class="curtain-overlay__blur" id="curtain-blur-left"></div>
		<div class="curtain-overlay__blur" id="curtain-blur-right"></div>
		<!-- Center logo — sits behind the curtains, revealed as they open -->
		<div class="curtain-overlay__logo" id="curtain-logo">
			<?php $intro_logo = function_exists('ticinoweb_get_site_logo') ? ticinoweb_get_site_logo() : false; ?>
			<?php if ($intro_logo): ?>
				<img class="curtain-overlay__logo-img" src="<?php echo esc_url($intro_logo); ?>" <?php idealugano_img_attrs($intro_logo); ?> alt="<?php echo esc_attr(get_bloginfo('name')); ?>">
			<?php else: ?>
				<div class="curtain-overlay__logo-text">
					Idea
					<small>Lugano</small>
				</div>
			<?php endif; ?>
		</div>
		<!-- Live fabric simulation: paths are drawn per-frame by curtain-intro.js -->
		<svg class="curtain-overlay__svg" id="curtain-svg" viewBox="0 0 1000 700" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
			<defs>
				<linearGradient id="curtainBodyL" x1="0" y1="0" x2="1" y2="0.15">
					<stop offset="0%"  stop-color="#052D3A" stop-opacity="0.58"/>
					<stop offset="35%" stop-color="#0A4052" stop-opacity="0.44"/>
					<stop offset="70%" stop-color="#0E5068" stop-opacity="0.50"/>
					<stop offset="100%" stop-color="#1A6070" stop-opacity="0.40"/>
				</linearGradient>
				<linearGradient id="curtainBodyR" x1="1" y1="0" x2="0" y2="0.15">
					<stop offset="0%"  stop-color="#052D3A" stop-opacity="0.58"/>
					<stop offset="35%" stop-color="#0A4052" stop-opacity="0.44"/>
					<stop offset="70%" stop-color="#0E5068" stop-opacity="0.50"/>
					<stop offset="100%" stop-color="#1A6070" stop-opacity="0.40"/>
				</linearGradient>
				<!-- Soft-edged ribbons via gradients: same feathered look as a
				     gaussian blur on a vertical stripe, but with zero per-frame
				     filter cost (feGaussianBlur re-renders on every path change) -->
				<linearGradient id="pleatHiGrad" x1="0" y1="0" x2="1" y2="0">
					<stop offset="0"   stop-color="#BEE1EE" stop-opacity="0"/>
					<stop offset="0.5" stop-color="#BEE1EE" stop-opacity="0.12"/>
					<stop offset="1"   stop-color="#BEE1EE" stop-opacity="0"/>
				</linearGradient>
				<linearGradient id="pleatLoGrad" x1="0" y1="0" x2="1" y2="0">
					<stop offset="0"   stop-color="#021E2D" stop-opacity="0"/>
					<stop offset="0.5" stop-color="#021E2D" stop-opacity="0.15"/>
					<stop offset="1"   stop-color="#021E2D" stop-opacity="0"/>
				</linearGradient>
				<linearGradient id="foldShadowGrad" x1="0" y1="0" x2="1" y2="0">
					<stop offset="0"   stop-color="#011420" stop-opacity="0"/>
					<stop offset="0.45" stop-color="#011420" stop-opacity="0.17"/>
					<stop offset="1"   stop-color="#011420" stop-opacity="0"/>
				</linearGradient>
				<linearGradient id="edgeBandGrad" x1="0" y1="0" x2="1" y2="0">
					<stop offset="0"   stop-color="#032332" stop-opacity="0"/>
					<stop offset="0.5" stop-color="#032332" stop-opacity="0.30"/>
					<stop offset="1"   stop-color="#032332" stop-opacity="0"/>
				</linearGradient>
			</defs>
			<g id="curtain-left-group"></g>
			<g id="curtain-right-group"></g>
		</svg>
		<button class="curtain-skip" id="curtain-skip" aria-label="Salta introduzione">
			Salta intro
		</button>
	</div>


	<!-- ═══════════════════════════════════════════
	     2. HERO
	     ═══════════════════════════════════════════ -->
	<section class="idea-hero" id="home" aria-labelledby="hero-title">
		<div class="idea-hero__bg">
			<?php
			$hero_img = idealugano_get_slot_image('hero') ?: idealugano_get_image_by_filename('hero.jpg');
			if ($hero_img):
			?>
				<img class="idea-hero__bg-img" src="<?php echo esc_url($hero_img); ?>" <?php idealugano_img_attrs($hero_img); ?> alt="Atelier Idea Lugano — tessuti e tende artigianali" loading="eager" fetchpriority="high" sizes="100vw">
			<?php else: ?>
				<!-- TODO: replace with client hero image -->
				<div class="idea-hero__bg-img" style="width:100%;height:100%;background:linear-gradient(135deg, #052D3A 0%, #0A4052 40%, #003241 100%);"></div>
			<?php endif; ?>
			<div class="idea-hero__overlay"></div>
		</div>
		<div class="idea-hero__content">
			<h1 id="hero-title" class="idea-hero__title idea-split-title" aria-label="<?php echo esc_attr($hero['title']); ?>">
				<span class="idea-split-title__line">Diamo nuova vita</span>
				<span class="idea-split-title__line idea-split-title__line--accent">ai tuoi arredi</span>
			</h1>
			<div class="idea-hero__gold-line"></div>
			<p class="idea-hero__subtitle"><?php echo esc_html($hero['subtitle']); ?></p>
			<div class="idea-hero__buttons">
				<a class="idea-btn idea-btn--primary" href="<?php echo esc_url(home_url('/contatti/')); ?>">
					<?php echo esc_html($hero['cta_primary']); ?>
				</a>
				<a class="idea-btn idea-btn--ghost" href="<?php echo esc_url(home_url('/servizi/')); ?>">
					<?php echo esc_html($hero['cta_secondary']); ?>
				</a>
			</div>
		</div>
		<a class="idea-hero__scroll" href="#chi-siamo-preview"><span>Scorri</span><i aria-hidden="true"></i></a>
	</section>


	<!-- ═══════════════════════════════════════════
	     3. EDITORIAL — "Artigianalità su misura"
	     ═══════════════════════════════════════════ -->
	<section class="idea-signature" id="chi-siamo-preview" aria-labelledby="editorial-title">
		<div class="idea-signature__stage">
			<div class="idea-signature__word idea-signature__word--back" aria-hidden="true">ARTE</div>
			<div class="idea-signature__image">
					<?php
					$atelier_img = (!empty($about['image']) ? $about['image'] : false) ?: (idealugano_get_slot_image('atelier') ?: idealugano_get_image_by_filename('atelier.jpg'));
					if ($atelier_img):
					?>
						<img src="<?php echo esc_url($atelier_img); ?>" <?php idealugano_img_attrs($atelier_img); ?> alt="Interno dell'atelier Idea Lugano" loading="eager" decoding="async" sizes="(max-width: 767px) 78vw, (max-width: 1024px) 62vw, 490px">
					<?php else: ?>
						<?php idealugano_placeholder_image('3/4', 'Atelier Idea Lugano'); ?>
					<?php endif; ?>
				</div>
			<div class="idea-signature__word idea-signature__word--front" aria-hidden="true">SU MISURA</div>
			<div class="idea-signature__copy">
				<span class="idea-eyebrow">Chi siamo</span>
				<h2 id="editorial-title"><?php echo esc_html(!empty($about['title']) ? $about['title'] : 'Arte tessile su misura'); ?></h2>
				<hr class="idea-gold-line">
				<p><?php echo esc_html(!empty($about['preview_text']) ? $about['preview_text'] : 'Ogni ambiente racconta una storia. Tessuti, finiture e dettagli trasformano lo spazio con eleganza e personalità.'); ?></p>
				<a class="idea-link" href="<?php echo esc_url(home_url('/chi-siamo/')); ?>">Chi siamo <span class="idea-link__arrow">→</span></a>
			</div>
		</div>
	</section>


	<!-- ═══════════════════════════════════════════
	     4. SERVIZI IN EVIDENZA
	     ═══════════════════════════════════════════ -->
	<section class="idea-section idea-section--cream" id="servizi-preview" aria-labelledby="services-title">
		<div class="idea-container">
			<div class="idea-text-center idea-mb-8 reveal">
				<span class="idea-eyebrow">I nostri servizi</span>
				<h2 id="services-title">Soluzioni artigianali<br>su misura</h2>
				<hr class="idea-gold-line idea-gold-line--center">
				<p class="idea-lead idea-mx-auto">
					Tende, divani e letti, rifacimento di imbottiti, tessuti d'arredo e arredamento completo: ogni servizio ha una pagina dedicata.
				</p>
			</div>

			<div class="idea-grid idea-grid--3 reveal-stagger idea-services-scene">
				<?php foreach ($services as $service): ?>
					<div class="idea-service-card reveal">
						<div class="idea-service-card__image">
							<?php
							$srv_img = (!empty($service['slot']) ? idealugano_get_slot_image($service['slot']) : false) ?: idealugano_get_image_by_filename(basename($service['image']));
							if ($srv_img):
							?>
								<img src="<?php echo esc_url($srv_img); ?>" <?php idealugano_img_attrs($srv_img); ?> alt="<?php echo esc_attr($service['title']); ?>" loading="lazy" decoding="async" sizes="(max-width: 767px) calc(100vw - 2.3rem), (max-width: 1024px) 46vw, 33vw">
							<?php else: ?>
								<?php idealugano_placeholder_image('4/3', $service['title']); ?>
							<?php endif; ?>
						</div>
						<div class="idea-service-card__body">
							<h3 class="idea-service-card__title"><?php echo esc_html($service['title']); ?></h3>
							<p class="idea-service-card__desc"><?php echo esc_html($service['desc']); ?></p>
							<a class="idea-link" href="<?php echo esc_url(!empty($service['url']) ? $service['url'] : home_url('/servizi/#servizio-' . $service['slug'])); ?>">
								Scopri <?php echo esc_html($service['title']); ?> <span class="idea-link__arrow">→</span>
							</a>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</section>


	<!-- ═══════════════════════════════════════════
	     5. TENDE SU MISURA
	     ═══════════════════════════════════════════ -->
	<section class="idea-curtains-story" id="tende" aria-labelledby="curtains-title">
		<div class="idea-curtains-story__stage">
		<div class="idea-container">
			<div class="idea-text-center idea-mb-8 reveal">
				<span class="idea-eyebrow">Specialità</span>
				<h2 id="curtains-title">Tende su misura<br>per ogni stile</h2>
				<hr class="idea-gold-line idea-gold-line--center">
				<p class="idea-lead idea-mx-auto">
					Dalle soluzioni moderne ai modelli più tradizionali, progettiamo tende su misura capaci di unire estetica, funzionalità e qualità dei materiali.
				</p>
				<p class="idea-mt-4"><a class="idea-btn idea-btn--ghost" href="<?php echo esc_url(idealugano_landing_url('tende-su-misura')); ?>">Scopri le tende su misura</a></p>
			</div>

			<div class="idea-curtains-track">
				<?php foreach ($curtain_types as $curtain): ?>
					<article class="idea-curtain-card">
						<?php
						$crt_img = (!empty($curtain['slot']) ? idealugano_get_slot_image($curtain['slot']) : false) ?: idealugano_get_image_by_filename(basename($curtain['image']));
						if ($crt_img):
						?>
							<img class="idea-curtain-card__image" src="<?php echo esc_url($crt_img); ?>" <?php idealugano_img_attrs($crt_img); ?> alt="<?php echo esc_attr($curtain['title']); ?>" loading="lazy" decoding="async" sizes="(max-width: 1024px) 86vw, 68vw">
						<?php else: ?>
							<?php idealugano_placeholder_image('3/4', $curtain['title']); ?>
						<?php endif; ?>
						<div class="idea-curtain-card__overlay"></div>
						<h3 class="idea-curtain-card__title"><?php echo esc_html($curtain['title']); ?></h3>
					</article>
				<?php endforeach; ?>
			</div>
			<div class="idea-curtains-progress" aria-hidden="true"><span></span></div>
		</div>
		</div>
	</section>


	<!-- ═══════════════════════════════════════════
	     5b. DIVANI, LETTI E IMBOTTITI (1.13.0)
	     ═══════════════════════════════════════════ -->
	<section class="idea-section idea-section--white idea-editorial" id="divani-letti" aria-labelledby="sofas-title">
		<div class="idea-container">
			<div class="idea-editorial__grid">
				<div class="idea-editorial__text reveal">
					<span class="idea-eyebrow">Mobili imbottiti</span>
					<h2 id="sofas-title">Divani e letti<br>su misura</h2>
					<hr class="idea-gold-line">
					<p class="idea-lead idea-mb-4">
						Divani, poltrone, letti e testiere progettati per il tuo spazio e rivestiti con il tessuto che scegli tu. Siamo rivenditori Tréca Paris per materassi e sistemi di riposo confezionati a mano. E se il tuo divano ha una buona struttura, lo rimettiamo a nuovo nel nostro laboratorio di tappezzeria.
					</p>
					<div class="idea-landing-hero__actions">
						<a class="idea-btn idea-btn--primary" href="<?php echo esc_url(idealugano_landing_url('divani-letti-su-misura')); ?>">Divani e letti nuovi</a>
						<a class="idea-btn idea-btn--ghost" href="<?php echo esc_url(idealugano_landing_url('rifacimento-divani-poltrone')); ?>">Rifacimento imbottiti</a>
					</div>
				</div>
				<div class="idea-editorial__image reveal reveal--right">
					<?php $sofa_img = idealugano_get_slot_image('srv_divani') ?: idealugano_get_slot_image('prod_letti'); ?>
					<?php if ($sofa_img): ?>
						<img src="<?php echo esc_url($sofa_img); ?>" <?php idealugano_img_attrs($sofa_img); ?> alt="Letto con testiera imbottita su misura" loading="lazy" decoding="async" sizes="(max-width: 1024px) calc(100vw - 2.3rem), 40vw" style="width:100%; height:100%; object-fit:cover; border-radius: var(--radius-lg); aspect-ratio: 4/5;">
					<?php else: ?>
						<?php idealugano_placeholder_image('4/5', 'Divani e letti su misura'); ?>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</section>


	<!-- ═══════════════════════════════════════════
	     6. PRODOTTI / COLLEZIONI
	     ═══════════════════════════════════════════ -->
	<section class="idea-section idea-section--cream" id="prodotti-preview" aria-labelledby="products-title">
		<div class="idea-container">
			<div class="idea-mb-8 reveal">
				<span class="idea-eyebrow">Collezioni e complementi</span>
				<h2 id="products-title">Tessuti e imbottiti</h2>
				<hr class="idea-gold-line">
			</div>

			<div class="idea-products-scroll reveal-stagger">
				<?php $idx = 0; foreach ($products as $product): ?>
					<div class="idea-product-card reveal">
						<div class="idea-product-card__image">
							<?php
							$prod_img = (!empty($product['slot']) ? idealugano_get_slot_image($product['slot']) : false) ?: idealugano_get_image_by_filename(basename($product['image']));
							if ($prod_img):
								// Solo l'hero ha fetchpriority="high": qui basta l'eager sulle prime due card.
								$loading = ($idx < 2) ? 'eager' : 'lazy';
								$fetchpriority = '';
							?>
								<img src="<?php echo esc_url($prod_img); ?>" <?php idealugano_img_attrs($prod_img); ?> alt="<?php echo esc_attr($product['title']); ?>" loading="<?php echo $loading; ?>" <?php echo $fetchpriority; ?> decoding="async" sizes="(max-width: 767px) 84vw, 300px">
							<?php else: ?>
								<?php idealugano_placeholder_image('3/4', $product['title']); ?>
							<?php endif; ?>
						</div>
						<div class="idea-product-card__body">
							<h3 class="idea-product-card__title"><?php echo esc_html($product['title']); ?></h3>
							<a class="idea-link" href="<?php echo esc_url(!empty($product['url']) ? $product['url'] : home_url('/prodotti/')); ?>">
								Scopri <span class="idea-link__arrow">→</span>
							</a>
						</div>
					</div>
				<?php $idx++; endforeach; ?>
			</div>
		</div>
	</section>


	<!-- ═══════════════════════════════════════════
	     7. MARCHI PARTNER
	     ═══════════════════════════════════════════ -->
	<section class="idea-section idea-section--white" id="marchi" aria-labelledby="brands-title">
		<div class="idea-container">
			<div class="idea-text-center idea-mb-8 reveal">
				<span class="idea-eyebrow">Partner</span>
				<h2 id="brands-title">Marchi selezionati</h2>
				<hr class="idea-gold-line idea-gold-line--center">
				<p class="idea-lead idea-mx-auto">
					Collaboriamo con aziende riconosciute per qualità, innovazione e affidabilità, per offrire soluzioni tecniche ed estetiche adatte a ogni progetto.
				</p>
			</div>

			<div class="idea-brands-grid idea-brands-grid--3x2 reveal" id="brands-grid">
				<?php foreach (array_slice($brands, 0, 6) as $brand): ?>
					<?php
					$brand_img = !empty($brand['logo']) ? $brand['logo'] : ((!empty($brand['slot']) ? idealugano_get_slot_image($brand['slot']) : false) ?: idealugano_get_image_by_filename(basename(!empty($brand['logo']) ? $brand['logo'] : '')));
					?>
					<div class="idea-brand-item" title="<?php echo esc_attr($brand['name']); ?>">
						<?php if ($brand_img): ?>
							<img src="<?php echo esc_url($brand_img); ?>" <?php idealugano_img_attrs($brand_img); ?> alt="<?php echo esc_attr($brand['name']); ?>" loading="lazy" decoding="async" sizes="(max-width: 767px) 135px, 180px">
						<?php else: ?>
							<span class="idea-brand-item__text"><?php echo esc_html($brand['name']); ?></span>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>

			<div class="idea-text-center idea-mt-8 reveal">
				<a class="idea-btn idea-btn--gold" href="<?php echo esc_url(home_url('/marchi/')); ?>">
					Vedi tutti i marchi <span class="idea-btn__arrow">→</span>
				</a>
			</div>
		</div>
	</section>


	<!-- ═══════════════════════════════════════════
	     8. OGGETTISTICA
	     ═══════════════════════════════════════════ -->
	<section class="idea-section idea-section--cream idea-objects-collage" id="oggettistica" aria-labelledby="objects-title">
		<div class="idea-kinetic idea-kinetic--objects" data-motion-text data-direction="right" data-speed="0.4" data-outline="true" aria-hidden="true"><span>DETTAGLI</span></div>
		<div class="idea-container">
			<div class="idea-editorial__grid">
				<div class="idea-editorial__text reveal">
					<span class="idea-eyebrow">Complementi</span>
					<h2 id="objects-title">Cuscini, copriletti<br>e dettagli</h2>
					<hr class="idea-gold-line">
					<p class="idea-lead idea-mb-4">
						Cuscini decorativi e copriletti coordinati, paralumi su misura e, su richiesta, una selezione di oggetti d'arredo: i dettagli che completano un progetto.
					</p>
					<a class="idea-link" href="<?php echo esc_url(home_url('/servizi/#servizio-complementi')); ?>">
						Scopri i complementi <span class="idea-link__arrow">→</span>
					</a>
				</div>
				<div class="reveal reveal--right idea-objects-collage__media">
					<div class="idea-objects-grid">
						<?php
						$object_captions = array('Scultura decorativa', 'Vaso in pietra', 'Complemento naturale', 'Dettaglio per interni');
						$object_slots = array('object_01', 'object_02', 'object_03');
						for ($i = 1; $i <= 3; $i++):
							$obj_img = idealugano_get_slot_image($object_slots[$i - 1]) ?: idealugano_get_image_by_filename("object-0{$i}.jpg");
							$caption = $object_captions[$i - 1];
						?>
							<div class="idea-object-item">
								<?php if ($obj_img): ?>
									<img src="<?php echo esc_url($obj_img); ?>" <?php idealugano_img_attrs($obj_img); ?> alt="<?php echo esc_attr($caption); ?>" loading="lazy" decoding="async" sizes="(max-width: 374px) calc(100vw - 2rem), (max-width: 767px) 46vw, 30vw">
								<?php else: ?>
									<?php idealugano_placeholder_image('1/1', $caption); ?>
								<?php endif; ?>
								<div class="idea-object-item__caption"><?php echo esc_html($caption); ?></div>
							</div>
						<?php endfor; ?>
					</div>
				</div>
			</div>
		</div>
	</section>


	<!-- ═══════════════════════════════════════════
	     9. GALLERIA / TRASFORMAZIONI
	     ═══════════════════════════════════════════ -->
	<section class="idea-section idea-section--white idea-transformations" id="trasformazioni" aria-labelledby="ba-title">
		<div class="idea-kinetic idea-kinetic--transform" data-motion-text data-direction="left" data-speed="1.1" data-outline="false" aria-hidden="true"><span>TRASFORMARE</span></div>
		<div class="idea-container">
			<div class="idea-text-center idea-mb-8 reveal">
				<span class="idea-eyebrow">Prima & Dopo</span>
				<h2 id="ba-title">Guarda le nostre<br>trasformazioni</h2>
				<hr class="idea-gold-line idea-gold-line--center">
				<p class="idea-lead idea-mx-auto">
					Progetti di rifacimento, restauro e creazioni su misura: il prima e dopo racconta il valore del lavoro artigianale.
				</p>
			</div>

			<div class="idea-ba-carousel reveal" aria-roledescription="carousel">
			<?php foreach ($before_after as $ba_index => $ba): ?>
				<div class="idea-ba-project<?php echo $ba_index === 0 ? ' is-active' : ''; ?>" <?php echo $ba_index === 0 ? '' : 'hidden'; ?>>
					<div class="idea-ba-slider" role="slider" aria-label="Confronto prima e dopo" aria-valuemin="0" aria-valuemax="100" aria-valuenow="50" tabindex="0">
						<div class="idea-ba-slider__before">
							<?php
							$ba_before = (!empty($ba['slot_before']) ? idealugano_get_slot_image($ba['slot_before']) : false) ?: idealugano_get_image_by_filename(basename($ba['before']));
							if ($ba_before):
							?>
								<img src="<?php echo esc_url($ba_before); ?>" <?php idealugano_img_attrs($ba_before); ?> alt="Prima: <?php echo esc_attr($ba['title']); ?>" loading="lazy" decoding="async" sizes="(max-width: 767px) calc(100vw - 2.3rem), 100vw">
							<?php else: ?>
								<?php idealugano_placeholder_image('16/9', 'Prima — ' . $ba['title']); ?>
							<?php endif; ?>
						</div>
						<div class="idea-ba-slider__after">
							<?php
							$ba_after = (!empty($ba['slot_after']) ? idealugano_get_slot_image($ba['slot_after']) : false) ?: idealugano_get_image_by_filename(basename($ba['after']));
							if ($ba_after):
							?>
								<img src="<?php echo esc_url($ba_after); ?>" <?php idealugano_img_attrs($ba_after); ?> alt="Dopo: <?php echo esc_attr($ba['title']); ?>" loading="lazy" decoding="async" sizes="(max-width: 767px) calc(100vw - 2.3rem), 100vw">
							<?php else: ?>
								<?php idealugano_placeholder_image('16/9', 'Dopo — ' . $ba['title']); ?>
							<?php endif; ?>
						</div>
						<div class="idea-ba-slider__handle"></div>
						<span class="idea-ba-slider__label idea-ba-slider__label--before">Prima</span>
						<span class="idea-ba-slider__label idea-ba-slider__label--after">Dopo</span>
					</div>
					<div class="idea-text-center idea-mt-4">
						<h3><?php echo esc_html($ba['title']); ?></h3>
						<p class="idea-lead idea-mx-auto"><?php echo esc_html($ba['description']); ?></p>
					</div>
				</div>
			<?php endforeach; ?>
			<?php if (count($before_after) > 1): ?>
				<button class="idea-ba-carousel__arrow idea-ba-carousel__arrow--prev" type="button" aria-label="Progetto precedente">‹</button>
				<button class="idea-ba-carousel__arrow idea-ba-carousel__arrow--next" type="button" aria-label="Progetto successivo">›</button>
				<div class="idea-ba-carousel__status" aria-live="polite">1 / <?php echo count($before_after); ?></div>
			<?php endif; ?>
			</div>

			<div class="idea-text-center idea-mt-6 reveal">
				<a class="idea-btn idea-btn--ghost" href="<?php echo esc_url(home_url('/galleria/')); ?>">
					Vedi la galleria
				</a>
			</div>
		</div>
	</section>


	<!-- ═══════════════════════════════════════════
	     10. TESTIMONIANZE
	     ═══════════════════════════════════════════ -->
	<section class="idea-section idea-section--cream" id="testimonianze" aria-labelledby="testimonials-title">
		<div class="idea-container">
			<div class="idea-text-center idea-mb-8 reveal">
				<span class="idea-eyebrow">Testimonianze</span>
				<h2 id="testimonials-title">Cosa dicono<br>i nostri clienti</h2>
				<hr class="idea-gold-line idea-gold-line--center">
			</div>

			<div class="idea-grid idea-grid--3 reveal-stagger">
				<?php foreach ($testimonials as $testimonial): ?>
					<div class="idea-testimonial-card reveal">
						<div class="idea-testimonial-card__quote">&ldquo;</div>
						<p class="idea-testimonial-card__text"><?php echo esc_html($testimonial['text']); ?></p>
						<span class="idea-testimonial-card__author">&mdash; <?php echo esc_html($testimonial['author']); ?></span>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</section>


	<!-- ═══════════════════════════════════════════
	     11. CONTATTI
	     ═══════════════════════════════════════════ -->
	<section class="idea-contact-prelude" aria-label="Invito al contatto">
		<p class="idea-contact-prelude__line idea-contact-prelude__line--one">RACCONTACI</p>
		<p class="idea-contact-prelude__line idea-contact-prelude__line--two">IL TUO SPAZIO</p>
	</section>
	<section class="idea-section idea-section--white" id="contatti" aria-labelledby="contact-title">
		<div class="idea-container">
			<div class="idea-text-center idea-mb-8 reveal">
				<span class="idea-eyebrow">Contatti</span>
				<h2 id="contact-title">Contattaci</h2>
				<hr class="idea-gold-line idea-gold-line--center">
				<p class="idea-lead idea-mx-auto">
					Scrivici o chiamaci per una consulenza personalizzata.
				</p>
			</div>

			<div class="idea-contact-grid reveal">
				<!-- Info cards -->
				<div>
					<div class="idea-contact-info-card">
						<div class="idea-contact-info-card__icon">
							<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
						</div>
						<div>
							<div class="idea-contact-info-card__label">Indirizzo</div>
							<div class="idea-contact-info-card__value">
								<a href="<?php echo esc_url(!empty($contact['maps_url']) ? $contact['maps_url'] : 'https://maps.app.goo.gl/X1EE7Ba3UHm9cBoU6'); ?>" target="_blank" rel="noopener noreferrer" style="color: inherit; text-decoration: none;" title="Apri su Google Maps">
									<?php echo nl2br(esc_html($contact['address'])); ?>
								</a>
							</div>
						</div>
					</div>
					<div class="idea-contact-info-card">
						<div class="idea-contact-info-card__icon">
							<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
						</div>
						<div>
							<div class="idea-contact-info-card__label">Telefono</div>
							<div class="idea-contact-info-card__value">
								<a href="tel:<?php echo esc_attr(str_replace(' ', '', $contact['phone'])); ?>"><?php echo esc_html($contact['phone']); ?></a>
								<?php if (!empty($contact['phone_landline'])): ?>
									<br><a href="tel:<?php echo esc_attr(str_replace(' ', '', $contact['phone_landline'])); ?>"><?php echo esc_html($contact['phone_landline']); ?></a>
								<?php endif; ?>
							</div>
						</div>
					</div>
					<div class="idea-contact-info-card">
						<div class="idea-contact-info-card__icon">
							<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
						</div>
						<div>
							<div class="idea-contact-info-card__label">Email</div>
							<div class="idea-contact-info-card__value">
								<a href="mailto:<?php echo esc_attr($contact['email']); ?>"><?php echo esc_html($contact['email']); ?></a>
							</div>
						</div>
					</div>
					<div class="idea-contact-info-card">
						<div class="idea-contact-info-card__icon">
							<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
						</div>
						<div>
							<div class="idea-contact-info-card__label">Orari</div>
							<div class="idea-contact-info-card__value">
								<?php if (!empty($site['hours_note'])): ?>
									<?php echo esc_html($site['hours_note']); ?>
								<?php else: ?>
								<?php foreach ($hours as $day => $time): ?>
									<?php echo esc_html("$day: $time"); ?><br>
								<?php endforeach; ?>
								<?php endif; ?>
							</div>
						</div>
					</div>
				</div>

				<!-- Contact form -->
				<div>
					<form class="idea-form" id="idea-contact-form" novalidate>
						<div class="idea-form__hp" aria-hidden="true">
							<label for="idea-hp-home">Lascia vuoto questo campo</label>
							<input type="text" id="idea-hp-home" name="tw_hp" tabindex="-1" autocomplete="off">
						</div>
						<div class="idea-form__group">
							<label class="idea-form__label" for="idea-name">Nome *</label>
							<input class="idea-form__input" type="text" id="idea-name" name="nome" required autocomplete="name" placeholder="Il tuo nome">
							<span class="idea-form__error" id="idea-name-error">Inserisci il tuo nome</span>
						</div>
						<div class="idea-form__group">
							<label class="idea-form__label" for="idea-email">Email *</label>
							<input class="idea-form__input" type="email" id="idea-email" name="email" required autocomplete="email" placeholder="La tua email">
							<span class="idea-form__error" id="idea-email-error">Inserisci un'email valida</span>
						</div>
						<div class="idea-form__group">
							<label class="idea-form__label" for="idea-message">Messaggio *</label>
							<textarea class="idea-form__textarea" id="idea-message" name="messaggio" required rows="5" placeholder="Descrivi il tuo progetto o la tua richiesta..."></textarea>
							<span class="idea-form__error" id="idea-message-error">Inserisci un messaggio</span>
						</div>
						<button type="submit" class="idea-btn idea-btn--primary" id="idea-submit">
							Invia messaggio
						</button>
						<div class="idea-form__fail" id="idea-form-fail" role="alert"></div>
						<div class="idea-form__success" id="idea-form-success" role="status" tabindex="-1">
							Grazie! Il tuo messaggio è stato inviato. Ti risponderemo al più presto.
						</div>
					</form>
				</div>
			</div>
		</div>
	</section>

</main>

<?php get_footer(); ?>
