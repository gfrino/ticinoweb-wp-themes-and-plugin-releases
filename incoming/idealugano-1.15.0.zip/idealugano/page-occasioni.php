<?php
/**
 * Template per la pagina con slug 'occasioni'
 *
 * @package Idealugano
 * @version 1.9.78
 */

require_once get_stylesheet_directory() . '/archive-occasione.php';
