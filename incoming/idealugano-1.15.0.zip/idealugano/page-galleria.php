<?php
/**
 * Template Name: Galleria
 * Template Post Type: page
 *
 * @package Idealugano
 * @version 1.1.0
 */
$site = idealugano_get_site_data();
$before_after = $site['before_after'];
$contact = $site['contact'];

$gallery_items = idealugano_get_frontend_gallery_items();
?>
<?php get_header(); ?>

<main id="primary" class="site-main">

	<!-- Page Hero -->
	<section class="idea-page-hero" aria-labelledby="gallery-page-title">
		<div class="idea-container">
			<span class="idea-eyebrow">Galleria</span>
			<h1 id="gallery-page-title" class="idea-page-hero__title">I nostri lavori</h1>
			<hr class="idea-gold-line idea-gold-line--center">
			<p class="idea-page-hero__subtitle">
				Una selezione di progetti, restauri e creazioni su misura.
			</p>
		</div>
	</section>

	<!-- Gallery Grid -->
	<section class="idea-section idea-section--white" aria-labelledby="gallery-grid-title">
		<div class="idea-container">
			<h2 id="gallery-grid-title" class="idea-gallery-title">Galleria immagini</h2>

			<!-- Filters — derived from the categories actually present, so a filter
			     can never come up empty when a category has no photos yet -->
			<?php
			$filter_labels = array(
				'tende'        => 'Tende',
				'divani-letti' => 'Divani e letti',
				'rifacimenti'  => 'Rifacimenti',
				'tessuti'      => 'Tessuti',
				'interni'      => 'Interni',
				'cuscini'      => 'Cuscini',
				'paralumi'     => 'Paralumi',
				'oggettistica' => 'Oggettistica',
			);
			$present = array_unique(array_column($gallery_items, 'category'));
			$filters = array_intersect(array_keys($filter_labels), $present);

			// Support pre-selecting a category via URL query param (?categoria=... or ?filtro=...)
			$req_cat = isset($_GET['categoria']) ? sanitize_key($_GET['categoria']) : (isset($_GET['filtro']) ? sanitize_key($_GET['filtro']) : '');
			$initial_category = (in_array($req_cat, $filters, true)) ? $req_cat : 'tutti';
			?>
			<?php if (count($filters) > 1): ?>
				<div class="idea-gallery-filters">
					<button type="button" class="idea-gallery-filter-btn<?php echo $initial_category === 'tutti' ? ' active' : ''; ?>" data-filter="tutti" aria-pressed="<?php echo $initial_category === 'tutti' ? 'true' : 'false'; ?>">Tutti</button>
					<?php foreach ($filters as $slug): ?>
						<?php $is_active = ($initial_category === $slug); ?>
						<button type="button" class="idea-gallery-filter-btn<?php echo $is_active ? ' active' : ''; ?>" data-filter="<?php echo esc_attr($slug); ?>" aria-pressed="<?php echo $is_active ? 'true' : 'false'; ?>">
							<?php echo esc_html($filter_labels[$slug]); ?>
						</button>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<!-- Masonry Grid -->
			<div class="idea-gallery-masonry">
				<?php foreach ($gallery_items as $item): ?>
					<?php
					$gal_img = idealugano_get_slot_image($item['slot']);
					$cat_label = isset($filter_labels[$item['category']]) ? $filter_labels[$item['category']] : ucfirst($item['category']);
					$is_initially_hidden = ($initial_category !== 'tutti' && $item['category'] !== $initial_category);
					?>
					<div class="idea-gallery-masonry__item"
					     data-category="<?php echo esc_attr($item['category']); ?>"
					     data-category-label="<?php echo esc_attr($cat_label); ?>"
					     data-title="<?php echo esc_attr($item['title']); ?>"
					     role="button"
					     tabindex="0"
					     aria-label="Apri <?php echo esc_attr($item['title']); ?>"
					     <?php if ($is_initially_hidden): ?>style="display: none;" aria-hidden="true"<?php endif; ?>>
						<?php if ($gal_img): ?>
							<img src="<?php echo esc_url($gal_img); ?>" <?php idealugano_img_attrs($gal_img); ?>
							     alt="<?php echo esc_attr($item['title']); ?>"
							     loading="lazy"
							     decoding="async"
							     sizes="(max-width: 767px) calc(100vw - 2.3rem), (max-width: 1024px) 48vw, 33vw">
							<div class="idea-gallery-masonry__overlay" aria-hidden="true">
								<span class="idea-gallery-masonry__zoom">
									<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
										<circle cx="11" cy="11" r="8"></circle>
										<line x1="21" y1="21" x2="16.65" y2="16.65"></line>
										<line x1="11" y1="8" x2="11" y2="14"></line>
										<line x1="8" y1="11" x2="14" y2="11"></line>
									</svg>
								</span>
								<span class="idea-gallery-masonry__item-title"><?php echo esc_html($item['title']); ?></span>
							</div>
						<?php else: ?>
							<?php
							$ratios = array('4/3', '3/4', '1/1', '4/5');
							$ratio = $ratios[array_rand($ratios)];
							idealugano_placeholder_image($ratio, $item['title']);
							?>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</section>

	<!-- Before/After Section -->
	<section class="idea-section idea-section--cream" aria-labelledby="gallery-ba-title">
		<div class="idea-container">
			<div class="idea-text-center idea-mb-8 reveal">
				<span class="idea-eyebrow">Prima & Dopo</span>
				<h2 id="gallery-ba-title">Trasformazioni</h2>
				<hr class="idea-gold-line idea-gold-line--center">
				<p class="idea-lead idea-mx-auto">
					Il prima e dopo racconta il valore del lavoro artigianale.
				</p>
			</div>

			<div class="idea-ba-carousel reveal" aria-roledescription="carousel">
			<?php foreach ($before_after as $ba_index => $ba): ?>
				<div class="idea-ba-project<?php echo $ba_index === 0 ? ' is-active' : ''; ?>" <?php echo $ba_index === 0 ? '' : 'hidden'; ?>>
					<div class="idea-ba-slider" role="slider" aria-label="Confronto prima e dopo" aria-valuemin="0" aria-valuemax="100" aria-valuenow="50" tabindex="0">
						<div class="idea-ba-slider__before">
							<?php
							$ba_before = (!empty($ba['slot_before']) ? idealugano_get_slot_image($ba['slot_before']) : false) ?: idealugano_get_image_by_filename(basename($ba['before']));
							if ($ba_before):
							?>
								<img src="<?php echo esc_url($ba_before); ?>" <?php idealugano_img_attrs($ba_before); ?> alt="Prima: <?php echo esc_attr($ba['title']); ?>" loading="lazy" decoding="async" sizes="(max-width: 767px) calc(100vw - 2.3rem), 100vw">
							<?php else: ?>
								<?php idealugano_placeholder_image('16/9', 'Prima — ' . $ba['title']); ?>
							<?php endif; ?>
						</div>
						<div class="idea-ba-slider__after">
							<?php
							$ba_after = (!empty($ba['slot_after']) ? idealugano_get_slot_image($ba['slot_after']) : false) ?: idealugano_get_image_by_filename(basename($ba['after']));
							if ($ba_after):
							?>
								<img src="<?php echo esc_url($ba_after); ?>" <?php idealugano_img_attrs($ba_after); ?> alt="Dopo: <?php echo esc_attr($ba['title']); ?>" loading="lazy" decoding="async" sizes="(max-width: 767px) calc(100vw - 2.3rem), 100vw">
							<?php else: ?>
								<?php idealugano_placeholder_image('16/9', 'Dopo — ' . $ba['title']); ?>
							<?php endif; ?>
						</div>
						<div class="idea-ba-slider__handle"></div>
						<span class="idea-ba-slider__label idea-ba-slider__label--before">Prima</span>
						<span class="idea-ba-slider__label idea-ba-slider__label--after">Dopo</span>
					</div>
					<div class="idea-text-center idea-mt-4">
						<h3><?php echo esc_html($ba['title']); ?></h3>
						<p class="idea-lead idea-mx-auto"><?php echo esc_html($ba['description']); ?></p>
					</div>
				</div>
			<?php endforeach; ?>
			<?php if (count($before_after) > 1): ?>
				<button class="idea-ba-carousel__arrow idea-ba-carousel__arrow--prev" type="button" aria-label="Progetto precedente">‹</button>
				<button class="idea-ba-carousel__arrow idea-ba-carousel__arrow--next" type="button" aria-label="Progetto successivo">›</button>
				<div class="idea-ba-carousel__status" aria-live="polite">1 / <?php echo count($before_after); ?></div>
			<?php endif; ?>
			</div>
		</div>
	</section>

	<!-- Instagram CTA -->
	<?php if (!empty($contact['instagram'])): ?>
	<section class="idea-section idea-section--white">
		<div class="idea-container idea-text-center reveal">
			<p class="idea-lead idea-mx-auto idea-mb-4">
				Seguici su Instagram per scoprire i nostri ultimi progetti e ispirazioni.
			</p>
			<a class="idea-btn idea-btn--primary" href="<?php echo esc_url($contact['instagram']); ?>" target="_blank" rel="noopener">
				<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>
				Scopri di più su Instagram
			</a>
		</div>
	</section>
	<?php endif; ?>

	<!-- Lightbox Modal Slider -->
	<div class="idea-lightbox" id="idea-lightbox" role="dialog" aria-modal="true" aria-hidden="true" aria-label="Galleria a schermo intero">
		<div class="idea-lightbox__backdrop" id="idea-lightbox-backdrop"></div>

		<!-- Top Bar: Category badge, Counter, Close button -->
		<div class="idea-lightbox__topbar">
			<div class="idea-lightbox__meta">
				<span class="idea-lightbox__badge" id="idea-lightbox-badge"></span>
				<span class="idea-lightbox__counter" id="idea-lightbox-counter" aria-live="polite">1 / 1</span>
			</div>
			<button class="idea-lightbox__close" id="idea-lightbox-close" type="button" aria-label="Chiudi galleria (Esc)">
				<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
					<line x1="18" y1="6" x2="6" y2="18"></line>
					<line x1="6" y1="6" x2="18" y2="18"></line>
				</svg>
			</button>
		</div>

		<!-- Main Stage: Arrow Prev, Picture/Figure, Arrow Next -->
		<div class="idea-lightbox__stage" id="idea-lightbox-stage">
			<button class="idea-lightbox__arrow idea-lightbox__arrow--prev" id="idea-lightbox-prev" type="button" aria-label="Immagine precedente (Freccia sinistra)">
				<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
					<polyline points="15 18 9 12 15 6"></polyline>
				</svg>
			</button>

			<div class="idea-lightbox__figure-wrap">
				<figure class="idea-lightbox__figure">
					<img class="idea-lightbox__img" id="idea-lightbox-img" src="" alt="">
				</figure>
			</div>

			<button class="idea-lightbox__arrow idea-lightbox__arrow--next" id="idea-lightbox-next" type="button" aria-label="Immagine successiva (Freccia destra)">
				<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
					<polyline points="9 18 15 12 9 6"></polyline>
				</svg>
			</button>
		</div>

		<!-- Bottom Bar: Image Title and navigation hint -->
		<div class="idea-lightbox__bottombar">
			<h3 class="idea-lightbox__title" id="idea-lightbox-title"></h3>
			<p class="idea-lightbox__hint">Usa le frecce o trascina con il dito per scorrere i lavori</p>
		</div>
	</div>

</main>

<?php get_footer(); ?>
