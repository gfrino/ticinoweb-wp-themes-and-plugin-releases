<?php
/**
 * Template Name: Chi Siamo
 * Template Post Type: page
 *
 * @package Idealugano
 * @version 1.0.0
 */
$site = idealugano_get_site_data();
$about = $site['about'];
$steps = $site['method_steps'];
?>
<?php get_header(); ?>

<main id="primary" class="site-main">

	<!-- Page Hero -->
	<section class="idea-page-hero" aria-labelledby="about-title">
		<span class="idea-deco-word idea-fx" data-speed="0.9" style="bottom: -3rem; right: -5%; opacity: 0.3;" aria-hidden="true">MESTIERE</span>
		<div class="idea-container">
			<span class="idea-eyebrow">Chi siamo</span>
			<h1 id="about-title" class="idea-page-hero__title"><?php echo esc_html($about['title']); ?></h1>
			<hr class="idea-gold-line idea-gold-line--center">
			<p class="idea-page-hero__subtitle">
				Tappezzeria e arredamento su misura a Lugano dal 2000.
			</p>
		</div>
	</section>

	<!-- About Content -->
	<section class="idea-section idea-section--white">
		<div class="idea-container">
			<div class="idea-editorial__grid">
				<div class="idea-editorial__text reveal">
					<h2>La nostra storia</h2>
					<hr class="idea-gold-line">
					<?php if (!empty($about['paragraphs']) && is_array($about['paragraphs'])): ?>
						<?php foreach ($about['paragraphs'] as $idx => $para): ?>
							<p class="<?php echo $idx < count($about['paragraphs']) - 1 ? 'idea-mb-3' : ''; ?>" style="line-height: 1.8; color: var(--idea-grey);">
								<?php echo nl2br(esc_html($para)); ?>
							</p>
						<?php endforeach; ?>
					<?php else: ?>
						<?php if (!empty($about['text_1'])): ?>
							<p class="idea-mb-3" style="line-height: 1.8; color: var(--idea-grey);">
								<?php echo esc_html($about['text_1']); ?>
							</p>
						<?php endif; ?>
						<?php if (!empty($about['text_2'])): ?>
							<p style="line-height: 1.8; color: var(--idea-grey);">
								<?php echo esc_html($about['text_2']); ?>
							</p>
						<?php endif; ?>
					<?php endif; ?>
				</div>
				<div class="idea-editorial__image reveal reveal--right">
					<?php
					$about_img = (!empty($about['image']) ? $about['image'] : false) ?: (idealugano_get_slot_image('atelier') ?: idealugano_get_image_by_filename('atelier.jpg'));
					if ($about_img):
					?>
						<img src="<?php echo esc_url($about_img); ?>" <?php idealugano_img_attrs($about_img); ?> alt="Tessuti e passamaneria IDeA Lugano" loading="lazy" decoding="async" sizes="(max-width: 767px) calc(100vw - 2.3rem), 50vw">
					<?php else: ?>
						<?php idealugano_placeholder_image('3/4', 'Tessuti e passamaneria IDeA Lugano'); ?>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</section>

	<!-- Method Steps -->
	<section class="idea-section idea-section--cream" id="metodo" aria-labelledby="method-title">
		<div class="idea-container idea-container--narrow">
			<div class="idea-text-center idea-mb-8 reveal">
				<span class="idea-eyebrow">Il nostro metodo</span>
				<h2 id="method-title">Come lavoriamo</h2>
				<hr class="idea-gold-line idea-gold-line--center">
				<p class="idea-lead idea-mx-auto">
					Ogni progetto segue un percorso strutturato, dalla prima consulenza fino alla consegna finale.
				</p>
			</div>

			<div class="reveal-stagger">
				<?php foreach ($steps as $step): ?>
					<div class="idea-method-step reveal">
						<div class="idea-method-step__num"><?php echo esc_html($step['num']); ?></div>
						<div>
							<h3 class="idea-method-step__title"><?php echo esc_html($step['title']); ?></h3>
							<p class="idea-method-step__desc"><?php echo esc_html($step['desc']); ?></p>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</section>

	<!-- CTA -->
	<section class="idea-section idea-section--petrol">
		<div class="idea-container idea-text-center reveal">
			<h2>Raccontaci il tuo progetto</h2>
			<hr class="idea-gold-line idea-gold-line--center" style="background: linear-gradient(90deg, transparent, var(--idea-gold-light), transparent);">
			<p class="idea-lead idea-mx-auto" style="color: rgba(247, 243, 234, 0.7);">
				Prenota una consulenza personalizzata per dare forma alla tua idea.
			</p>
			<div class="idea-mt-4">
				<a class="idea-btn idea-btn--gold" href="<?php echo esc_url(home_url('/contatti/')); ?>">
					Prenota una consulenza
				</a>
			</div>
		</div>
	</section>

</main>

<?php get_footer(); ?>
