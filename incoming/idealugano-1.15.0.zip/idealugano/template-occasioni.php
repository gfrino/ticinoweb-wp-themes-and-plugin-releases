<?php
/**
 * Template Name: Idea Lugano — Occasioni & Pezzi d'Atelier
 * Template Post Type: page
 *
 * @package Idealugano
 * @version 1.9.78
 */

require_once get_stylesheet_directory() . '/archive-occasione.php';
