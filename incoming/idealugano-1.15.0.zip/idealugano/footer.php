<?php
/**
 * Idealugano child theme footer
 *
 * @package Idealugano
 * @version 1.1.0
 */
$site = idealugano_get_site_data();
$contact = $site['contact'];
$hours = $site['hours'];
?>

<!-- Footer -->
<footer class="idea-footer idea-footer--reveal" role="contentinfo">
	<div class="idea-container">
		<div class="idea-footer__grid">
			<!-- Brand column -->
			<div class="idea-footer__brand">
				<?php $footer_logo = function_exists('ticinoweb_get_site_logo') ? ticinoweb_get_site_logo() : false; ?>
				<a class="idea-footer__logo" href="<?php echo esc_url(home_url('/')); ?>" rel="home">
					<?php if ($footer_logo): ?>
						<img class="idea-footer__logo-img" src="<?php echo esc_url($footer_logo); ?>" alt="<?php echo esc_attr($site['brand']); ?>">
					<?php else: ?>
						<span class="idea-footer__brand-name">IDeA Lugano</span>
					<?php endif; ?>
				</a>
				<p class="idea-footer__brand-desc">
					Atelier di tende su misura, divani, letti, rifacimento imbottiti e tessuti d'arredo a Lugano, Ticino.
				</p>
				<div class="idea-footer__social">
					<?php if (!empty($contact['instagram'])): ?>
						<a href="<?php echo esc_url($contact['instagram']); ?>" target="_blank" rel="noopener" aria-label="Seguici su Instagram">
							<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>
							Instagram
						</a>
					<?php endif; ?>
					<?php if (!empty($contact['facebook'])): ?>
						<a href="<?php echo esc_url($contact['facebook']); ?>" target="_blank" rel="noopener" aria-label="Seguici su Facebook">
							<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
							Facebook
						</a>
					<?php endif; ?>
					<?php if (!empty($contact['linkedin'])): ?>
						<a href="<?php echo esc_url($contact['linkedin']); ?>" target="_blank" rel="noopener" aria-label="Seguici su LinkedIn">
							<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg>
							LinkedIn
						</a>
					<?php endif; ?>
				</div>
			</div>

			<!-- Chi siamo -->
			<div>
				<h2 class="idea-footer__col-title">Chi Siamo</h2>
				<ul class="idea-footer__links">
					<li><a href="<?php echo esc_url(home_url('/chi-siamo/')); ?>">La nostra storia</a></li>
					<li><a href="<?php echo esc_url(home_url('/chi-siamo/')); ?>#metodo">Il nostro metodo</a></li>
				</ul>
			</div>

			<!-- Servizi -->
			<div>
				<h2 class="idea-footer__col-title">Servizi</h2>
				<ul class="idea-footer__links">
					<?php foreach (array_slice($site['services'], 0, 5) as $service): ?>
						<li><a href="<?php echo esc_url(!empty($service['url']) ? $service['url'] : home_url('/servizi/#servizio-' . $service['slug'])); ?>"><?php echo esc_html($service['title']); ?></a></li>
					<?php endforeach; ?>
				</ul>
			</div>

			<!-- Prodotti & Esplora -->
			<div>
				<h2 class="idea-footer__col-title">Esplora</h2>
				<ul class="idea-footer__links">
					<li><a href="<?php echo esc_url(home_url('/prodotti/')); ?>">Prodotti</a></li>
					<li><a href="<?php echo esc_url(home_url('/marchi/')); ?>">Marchi</a></li>
					<li><a href="<?php echo esc_url(home_url('/occasioni/')); ?>">Occasioni</a></li>
					<li><a href="<?php echo esc_url(home_url('/galleria/')); ?>">Galleria</a></li>
					<li><a href="<?php echo esc_url(home_url('/contatti/')); ?>">Contatti</a></li>
				</ul>
			</div>

			<!-- Contatti -->
			<div>
				<h2 class="idea-footer__col-title">Contatti</h2>
				<ul class="idea-footer__links idea-footer__contact-list">
					<li class="idea-footer__contact-item">
						<span class="idea-footer__contact-label">Telefono</span>
						<a href="tel:<?php echo esc_attr(str_replace(' ', '', $contact['phone'])); ?>">
							<?php echo esc_html($contact['phone']); ?>
						</a>
						<?php if (!empty($contact['phone_landline'])): ?>
							<br><a href="tel:<?php echo esc_attr(str_replace(' ', '', $contact['phone_landline'])); ?>"><?php echo esc_html($contact['phone_landline']); ?></a>
						<?php endif; ?>
					</li>
					<li class="idea-footer__contact-item">
						<span class="idea-footer__contact-label">Email</span>
						<a href="mailto:<?php echo esc_attr($contact['email']); ?>">
							<?php echo esc_html($contact['email']); ?>
						</a>
					</li>
					<li class="idea-footer__contact-item">
						<span class="idea-footer__contact-label">Indirizzo</span>
						<address>
							<a href="<?php echo esc_url(!empty($contact['maps_url']) ? $contact['maps_url'] : 'https://maps.app.goo.gl/X1EE7Ba3UHm9cBoU6'); ?>" target="_blank" rel="noopener noreferrer" style="color: inherit; text-decoration: none;" title="Apri su Google Maps">
								<?php echo nl2br(esc_html($contact['address'])); ?>
							</a>
						</address>
					</li>
					<li class="idea-footer__contact-item">
						<span class="idea-footer__contact-label">Ricevimento</span>
						<div class="idea-footer__hours">
							<?php if (!empty($site['hours_note'])): ?>
								<?php echo esc_html($site['hours_note']); ?>
							<?php else: ?>
							<?php foreach ($hours as $day => $time): ?>
								<span><strong><?php echo esc_html($day); ?></strong><?php echo esc_html($time); ?></span>
							<?php endforeach; ?>
							<?php endif; ?>
						</div>
					</li>
				</ul>
			</div>
		</div>

		<!-- Bottom bar -->
		<div class="idea-footer__bottom">
			<span class="idea-footer__copyright">
				&copy; <?php echo date('Y'); ?> <?php echo esc_html($site['brand']); ?>. Tutti i diritti riservati.
			</span>
			<div class="idea-footer__bottom-links">
				<div class="idea-footer__utility">
					<a href="<?php echo esc_url(home_url('/tw-login/')); ?>">Area privata</a>
					<a href="https://ticinoweb.com/" target="_blank" rel="noopener noreferrer">Design by&nbsp;<strong>ticinoWEB</strong></a>
				</div>
				<div class="idea-footer__legal">
					<a href="<?php echo esc_url(home_url('/faq/')); ?>">FAQ</a>
					<a href="<?php echo esc_url(home_url('/privacy-policy/')); ?>">Privacy Policy</a>
					<a href="<?php echo esc_url(home_url('/cookie-policy/')); ?>">Cookie Policy</a>
					<a href="<?php echo esc_url(home_url('/termini-e-condizioni/')); ?>">Termini e Condizioni</a>
				</div>
			</div>
		</div>
	</div>
</footer>

	<!-- Close ScrollSmoother structure (opened in header.php) -->
	</div><!-- #smooth-content -->
</div><!-- #smooth-wrapper -->

<?php wp_footer(); ?>
</body>
</html>
