<?php
/**
 * Template Name: Contatti
 * Template Post Type: page
 *
 * @package Idealugano
 * @version 1.0.0
 */
$site = idealugano_get_site_data();
$contact = $site['contact'];
$hours = $site['hours'];
?>
<?php get_header(); ?>

<main id="primary" class="site-main">

	<!-- Page Hero -->
	<section class="idea-page-hero" aria-labelledby="contact-page-title">
		<div class="idea-container">
			<span class="idea-eyebrow">Contatti</span>
			<h1 id="contact-page-title" class="idea-page-hero__title">Contattaci</h1>
			<hr class="idea-gold-line idea-gold-line--center">
			<p class="idea-page-hero__subtitle">
				Scrivici o chiamaci per una consulenza personalizzata.
			</p>
		</div>
	</section>

	<!-- Contact Info + Form -->
	<section class="idea-section idea-section--white">
		<div class="idea-container">
			<div class="idea-contact-grid">
				<!-- Info cards -->
				<div class="reveal">
					<div class="idea-contact-info-card">
						<div class="idea-contact-info-card__icon">
							<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
						</div>
						<div>
							<div class="idea-contact-info-card__label">Indirizzo</div>
							<div class="idea-contact-info-card__value">
								<a href="<?php echo esc_url(!empty($contact['maps_url']) ? $contact['maps_url'] : 'https://maps.app.goo.gl/X1EE7Ba3UHm9cBoU6'); ?>" target="_blank" rel="noopener noreferrer" style="color: inherit; text-decoration: none;" title="Apri su Google Maps">
									<?php echo nl2br(esc_html($contact['address'])); ?>
								</a>
							</div>
						</div>
					</div>
					<div class="idea-contact-info-card">
						<div class="idea-contact-info-card__icon">
							<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
						</div>
						<div>
							<div class="idea-contact-info-card__label">Telefono</div>
							<div class="idea-contact-info-card__value">
								<a href="tel:<?php echo esc_attr(str_replace(' ', '', $contact['phone'])); ?>"><?php echo esc_html($contact['phone']); ?></a>
								<?php if (!empty($contact['phone_landline'])): ?>
									<br><a href="tel:<?php echo esc_attr(str_replace(' ', '', $contact['phone_landline'])); ?>"><?php echo esc_html($contact['phone_landline']); ?></a>
								<?php endif; ?>
								<?php if (!empty($contact['contact_person'])): ?>
									<br><?php echo esc_html($contact['contact_person']); ?>
								<?php endif; ?>
							</div>
						</div>
					</div>
					<div class="idea-contact-info-card">
						<div class="idea-contact-info-card__icon">
							<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
						</div>
						<div>
							<div class="idea-contact-info-card__label">Email</div>
							<div class="idea-contact-info-card__value">
								<a href="mailto:<?php echo esc_attr($contact['email']); ?>"><?php echo esc_html($contact['email']); ?></a>
							</div>
						</div>
					</div>
					<div class="idea-contact-info-card">
						<div class="idea-contact-info-card__icon">
							<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
						</div>
						<div>
							<div class="idea-contact-info-card__label">Ricevimento</div>
							<div class="idea-contact-info-card__value">
								<?php if (!empty($site['hours_note'])): ?>
									<?php echo esc_html($site['hours_note']); ?>
								<?php else: ?>
								<?php foreach ($hours as $day => $time): ?>
									<strong><?php echo esc_html($day); ?>:</strong> <?php echo esc_html($time); ?><br>
								<?php endforeach; ?>
								<?php endif; ?>
							</div>
						</div>
					</div>

					<?php if (!empty($contact['instagram']) || !empty($contact['facebook']) || !empty($contact['linkedin'])): ?>
						<div class="idea-contact-info-card">
							<div class="idea-contact-info-card__icon">
								<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>
							</div>
							<div>
								<div class="idea-contact-info-card__label">Social</div>
								<div class="idea-contact-info-card__value" style="display:flex; flex-direction:column; gap:4px;">
									<?php if (!empty($contact['instagram'])): ?>
										<a href="<?php echo esc_url($contact['instagram']); ?>" target="_blank" rel="noopener">Instagram</a>
									<?php endif; ?>
									<?php if (!empty($contact['facebook'])): ?>
										<a href="<?php echo esc_url($contact['facebook']); ?>" target="_blank" rel="noopener">Facebook</a>
									<?php endif; ?>
									<?php if (!empty($contact['linkedin'])): ?>
										<a href="<?php echo esc_url($contact['linkedin']); ?>" target="_blank" rel="noopener">LinkedIn</a>
									<?php endif; ?>
								</div>
							</div>
						</div>
					<?php endif; ?>
				</div>

				<!-- Contact form -->
				<div class="reveal reveal--right">
					<?php
					$occasione_prefill = isset( $_GET['occasione'] ) ? sanitize_text_field( wp_unslash( $_GET['occasione'] ) ) : '';
					$rif_prefill       = isset( $_GET['rif'] ) ? sanitize_text_field( wp_unslash( $_GET['rif'] ) ) : '';
					$initial_message   = '';
					if ( $occasione_prefill ) {
						$initial_message = sprintf(
							/* translators: 1: product name, 2: reference code */
							__( "Buongiorno, desidero richiedere maggiori informazioni in merito al pezzo in occasione: \"%1\$s\"%2\$s.", 'idealugano' ),
							$occasione_prefill,
							$rif_prefill ? sprintf( __( ' (Rif: %s)', 'idealugano' ), $rif_prefill ) : ''
						);
					}
					if ( $occasione_prefill ) : ?>
						<div class="idea-contact-prefill-badge">
							<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>
							<span><strong><?php esc_html_e( 'Richiesta per pezzo in occasione:', 'idealugano' ); ?></strong> <?php echo esc_html( $occasione_prefill ); ?> <?php if ( $rif_prefill ) : ?>(<?php esc_html_e( 'Rif.', 'idealugano' ); ?> <?php echo esc_html( $rif_prefill ); ?>)<?php endif; ?></span>
						</div>
					<?php endif; ?>
					<form class="idea-form" id="idea-contact-form" novalidate>
						<div class="idea-form__hp" aria-hidden="true">
							<label for="idea-hp-contatti">Lascia vuoto questo campo</label>
							<input type="text" id="idea-hp-contatti" name="tw_hp" tabindex="-1" autocomplete="off">
						</div>
						<?php if ( $occasione_prefill ) : ?>
							<input type="hidden" name="oggetto" value="<?php echo esc_attr( sprintf( __( 'Richiesta occasione: %s', 'idealugano' ), $occasione_prefill . ( $rif_prefill ? ' (Rif: ' . $rif_prefill . ')' : '' ) ) ); ?>">
						<?php endif; ?>
						<div class="idea-form__group">
							<label class="idea-form__label" for="idea-name">Nome *</label>
							<input class="idea-form__input" type="text" id="idea-name" name="nome" required autocomplete="name" placeholder="Il tuo nome">
							<span class="idea-form__error" id="idea-name-error">Inserisci il tuo nome</span>
						</div>
						<div class="idea-form__group">
							<label class="idea-form__label" for="idea-email">Email *</label>
							<input class="idea-form__input" type="email" id="idea-email" name="email" required autocomplete="email" placeholder="La tua email">
							<span class="idea-form__error" id="idea-email-error">Inserisci un'email valida</span>
						</div>
						<div class="idea-form__group">
							<label class="idea-form__label" for="idea-message">Messaggio *</label>
							<textarea class="idea-form__textarea" id="idea-message" name="messaggio" required rows="6" placeholder="Descrivi il tuo progetto o la tua richiesta..."><?php echo esc_textarea( $initial_message ); ?></textarea>
							<span class="idea-form__error" id="idea-message-error">Inserisci un messaggio</span>
						</div>
						<button type="submit" class="idea-btn idea-btn--gold" id="idea-submit">
							Invia messaggio
						</button>
						<div class="idea-form__fail" id="idea-form-fail" role="alert"></div>
						<div class="idea-form__success" id="idea-form-success" role="status" tabindex="-1">
							Grazie! Il tuo messaggio è stato inviato. Ti risponderemo al più presto.
						</div>
					</form>
				</div>
			</div>
		</div>
	</section>

	<!-- Google Map -->
	<section class="idea-section idea-section--cream idea-map-section">
		<div class="idea-container reveal">
			<div class="idea-map-placeholder">
				<?php
				$map_address = !empty($contact['address']) ? trim($contact['address']) : 'Via alla Gerra 9, Stabile Vallone, Piano Superiore, 6930 Bedano';
				$map_embed_url = 'https://www.google.com/maps?q=Via+alla+Gerra+9%2C+6930+Bedano&t=&z=17&ie=UTF8&iwloc=&output=embed';
				$map_direct_url = !empty($contact['maps_url']) ? $contact['maps_url'] : 'https://maps.app.goo.gl/X1EE7Ba3UHm9cBoU6';
				$map_directions_url = 'https://www.google.com/maps/dir/?api=1&destination=' . rawurlencode('Via alla Gerra 9, 6930 Bedano');
				?>
				<iframe
					class="idea-google-map"
					src="<?php echo esc_url($map_embed_url); ?>"
					title="Mappa Google — <?php echo esc_attr($map_address); ?>"
					loading="lazy"
					referrerpolicy="no-referrer-when-downgrade"
					allowfullscreen></iframe>
			</div>
			<div class="idea-map-actions" style="margin-top: 18px; display: flex; justify-content: center; gap: 14px; flex-wrap: wrap;">
				<a class="idea-btn idea-btn--ghost" href="<?php echo esc_url($map_directions_url); ?>" target="_blank" rel="noopener noreferrer" style="display: inline-flex; align-items: center; gap: 8px; font-size: 0.92rem; padding: 10px 20px;">
					<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="3 11 22 2 13 21 11 13 3 11"/></svg>
					Ottieni indicazioni stradali
				</a>
				<a class="idea-btn idea-btn--ghost" href="<?php echo esc_url($map_direct_url); ?>" target="_blank" rel="noopener noreferrer" style="display: inline-flex; align-items: center; gap: 8px; font-size: 0.92rem; padding: 10px 20px;">
					<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
					Apri in Google Maps
				</a>
			</div>
		</div>
	</section>

	<!-- CTA -->
	<section class="idea-section idea-section--petrol">
		<div class="idea-container idea-text-center reveal">
			<h2>Prenota una consulenza personalizzata</h2>
			<hr class="idea-gold-line idea-gold-line--center" style="background: linear-gradient(90deg, transparent, var(--idea-gold-light), transparent);">
			<p class="idea-lead idea-mx-auto" style="color: rgba(247, 243, 234, 0.7);">
				Siamo a tua disposizione per ascoltare le tue esigenze e proporti la soluzione migliore.
			</p>
			<div class="idea-mt-4">
				<a class="idea-btn idea-btn--gold" href="tel:<?php echo esc_attr(str_replace(' ', '', $contact['phone'])); ?>">
					Chiamaci ora
				</a>
			</div>
		</div>
	</section>

</main>

<?php get_footer(); ?>
