<?php
/**
 * Pagina 404 reale (il parent reindirizzava alla home con 301: soft 404).
 *
 * @package Idealugano
 * @version 1.0.0
 */

get_header();
?>

<main id="primary" class="site-main">
	<section class="idea-section idea-section--white">
		<div class="idea-container idea-404">
			<div>
				<p class="idea-404__code" aria-hidden="true">404</p>
				<span class="idea-eyebrow"><?php esc_html_e('Pagina non trovata', 'idealugano'); ?></span>
				<h1><?php esc_html_e('Questa pagina non esiste o è stata spostata', 'idealugano'); ?></h1>
				<hr class="idea-gold-line idea-gold-line--center">
				<p class="idea-lead idea-mx-auto">
					<?php esc_html_e('Il contenuto che cercavi non è più disponibile. Puoi tornare alla home, esplorare i nostri servizi o cercare nel sito.', 'idealugano'); ?>
				</p>

				<form role="search" method="get" class="idea-404__search" action="<?php echo esc_url(home_url('/')); ?>">
					<label class="screen-reader-text" for="idea-404-search"><?php esc_html_e('Cerca nel sito', 'idealugano'); ?></label>
					<input type="search" id="idea-404-search" name="s" placeholder="<?php esc_attr_e('Cerca…', 'idealugano'); ?>">
					<button type="submit" class="idea-btn idea-btn--gold"><?php esc_html_e('Cerca', 'idealugano'); ?></button>
				</form>

				<ul class="idea-404__links">
					<li><a class="idea-link" href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e('Home', 'idealugano'); ?></a></li>
					<li><a class="idea-link" href="<?php echo esc_url(home_url('/servizi/')); ?>"><?php esc_html_e('Servizi', 'idealugano'); ?></a></li>
					<li><a class="idea-link" href="<?php echo esc_url(home_url('/prodotti/')); ?>"><?php esc_html_e('Prodotti', 'idealugano'); ?></a></li>
					<li><a class="idea-link" href="<?php echo esc_url(home_url('/galleria/')); ?>"><?php esc_html_e('Galleria', 'idealugano'); ?></a></li>
					<li><a class="idea-link" href="<?php echo esc_url(get_post_type_archive_link('occasione')); ?>"><?php esc_html_e('Occasioni', 'idealugano'); ?></a></li>
					<li><a class="idea-link" href="<?php echo esc_url(home_url('/contatti/')); ?>"><?php esc_html_e('Contatti', 'idealugano'); ?></a></li>
				</ul>
			</div>
		</div>
	</section>
</main>

<?php get_footer(); ?>
