/**
 * Gallery — Masonry filters + Lightbox
 *
 * @package Idealugano
 * @version 1.0.0
 */
(function () {
  'use strict';

  // ── Filters ──
  var filterBtns = document.querySelectorAll('.idea-gallery-filter-btn');
  var galleryItems = document.querySelectorAll('.idea-gallery-masonry__item');
  var galleryGrid = document.querySelector('.idea-gallery-masonry');
  var gsap = window.gsap;
  var filtering = false;
  var queuedFilter = null;

  // Add the class to enable JS hide state
  document.documentElement.classList.add('js-motion-ready');

  // Shared entrance animation function
  function animateEntrance(items, onComplete) {
    if (!items.length) {
      if (onComplete) onComplete();
      return;
    }

    items.forEach(function (item) {
      item.classList.add('is-animated');
    });

    if (!gsap || window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      gsap.set(items, { opacity: 1, y: 0, scale: 1 });
      if (onComplete) onComplete();
      return;
    }

    var desktop = window.innerWidth >= 1025;
    var tablet = window.innerWidth >= 641 && window.innerWidth <= 1024;
    var duration = desktop ? 0.62 : (tablet ? 0.52 : 0.45);
    var yVal = desktop ? 24 : (tablet ? 16 : 12);
    var staggerVal = desktop ? 0.065 : (tablet ? 0.045 : 0.025);

    gsap.fromTo(items, {
      opacity: 0,
      y: yVal,
      scale: 0.985
    }, {
      opacity: 1,
      y: 0,
      scale: 1,
      duration: duration,
      stagger: { each: staggerVal, from: 'start' },
      ease: 'power3.out',
      onComplete: onComplete
    });
  }

  // IntersectionObserver to reveal items during scroll
  var observer = null;

  function initObserver() {
    if (observer) {
      observer.disconnect();
    }

    if (!window.IntersectionObserver || !gsap || window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      var visibleItems = Array.prototype.filter.call(galleryItems, function (item) {
        return item.style.display !== 'none';
      });
      animateEntrance(visibleItems);
      return;
    }

    var batch = [];
    var batchTimer = null;

    observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          var item = entry.target;
          batch.push(item);
          observer.unobserve(item);
        }
      });

      if (batch.length > 0) {
        window.clearTimeout(batchTimer);
        batchTimer = window.setTimeout(function () {
          // Sort items by offsetTop then offsetLeft for natural layout sequence stagger
          batch.sort(function (a, b) {
            return a.offsetTop - b.offsetTop || a.offsetLeft - b.offsetLeft;
          });
          animateEntrance([].concat(batch));
          batch = [];
        }, 30);
      }
    }, {
      rootMargin: '0px 0px -8% 0px',
      threshold: 0.05
    });

    galleryItems.forEach(function (item) {
      if (item.style.display !== 'none' && !item.classList.contains('is-animated')) {
        observer.observe(item);
      }
    });
  }

  // Initialize on page load
  if (gsap) {
    // Clear any previous inline styles
    gsap.set(galleryItems, { clearProps: 'clipPath,borderRadius,opacity,transform' });
  }

  // Wait a brief moment for layout/fonts to settle so bounding calculations are accurate
  window.addEventListener('DOMContentLoaded', function () {
    setTimeout(initObserver, 100);
  });

  function matchesFilter(item, filter) {
    return filter === 'tutti' || item.getAttribute('data-category') === filter;
  }

  function updateActiveButton(filter) {
    filterBtns.forEach(function (button) {
      var active = button.getAttribute('data-filter') === filter;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });
  }

  function applyFilter(filter) {
    if (filtering) {
      queuedFilter = filter;
      return;
    }
    filtering = true;
    updateActiveButton(filter);

    var visibleItems = Array.prototype.filter.call(galleryItems, function (item) {
      return item.style.display !== 'none';
    });
    var nextItems = Array.prototype.filter.call(galleryItems, function (item) {
      return matchesFilter(item, filter);
    });

    function swapItems() {
      galleryItems.forEach(function (item) {
        var visible = matchesFilter(item, filter);
        item.style.display = visible ? '' : 'none';
        item.setAttribute('aria-hidden', visible ? 'false' : 'true');
      });
    }

    function finish() {
      filtering = false;
      document.dispatchEvent(new CustomEvent('idealugano:layoutchange'));
      if (queuedFilter && queuedFilter !== filter) {
        var nextFilter = queuedFilter;
        queuedFilter = null;
        applyFilter(nextFilter);
      } else {
        queuedFilter = null;
      }
    }

    if (!gsap || window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      swapItems();
      finish();
      return;
    }

    gsap.killTweensOf(galleryItems);
    galleryGrid.classList.add('is-filtering');

    // Filter fade out
    gsap.to(visibleItems, {
      opacity: 0,
      y: -12,
      scale: .985,
      duration: .28,
      stagger: { each: .018, from: 'end' },
      ease: 'power2.in',
      onComplete: function () {
        swapItems();

        // Separate nextItems into already animated vs new
        var animatedItems = [];
        var newItems = [];
        nextItems.forEach(function (item) {
          if (item.classList.contains('is-animated')) {
            animatedItems.push(item);
          } else {
            newItems.push(item);
          }
        });

        // Prepare newItems to be hidden and observed
        var desktop = window.innerWidth >= 1025;
        var tablet = window.innerWidth >= 641 && window.innerWidth <= 1024;
        var yVal = desktop ? 24 : (tablet ? 16 : 12);
        gsap.set(newItems, { opacity: 0, y: yVal, scale: 0.985 });

        // Reset the observer to detect which new items are now in the viewport, and observe scroll
        initObserver();

        // Smoothly fade in already animated items
        if (animatedItems.length > 0) {
          gsap.fromTo(animatedItems, { opacity: 0 }, {
            opacity: 1,
            y: 0,
            scale: 1,
            duration: .35,
            stagger: { each: .02, from: 'start' },
            ease: 'power2.out'
          });
        }

        // Complete filter transition animation
        galleryGrid.classList.remove('is-filtering');
        finish();
      }
    });
  }

  filterBtns.forEach(function (btn) {
    btn.addEventListener('click', function () {
      var filter = this.getAttribute('data-filter');
      if (!filtering && this.classList.contains('active')) return;
      applyFilter(filter);
    });
  });

  // Handle URL category query param (?categoria=... or ?filtro=...) and hash
  function getRequestedCategory() {
    var params = new URLSearchParams(window.location.search);
    var cat = params.get('categoria') || params.get('filtro');
    if (cat) return cat.toLowerCase();

    var hash = window.location.hash ? window.location.hash.replace(/^#/, '').toLowerCase() : '';
    if (hash && hash !== 'gallery-grid-title') {
      return hash;
    }
    return '';
  }

  var requestedCat = getRequestedCategory();
  if (requestedCat && requestedCat !== 'tutti') {
    var matchingBtn = Array.prototype.filter.call(filterBtns, function (btn) {
      return btn.getAttribute('data-filter') === requestedCat;
    })[0];
    if (matchingBtn && !matchingBtn.classList.contains('active')) {
      applyFilter(requestedCat);
    }
  }

  // Smooth scroll to gallery title if arriving with category or anchor
  if (requestedCat || window.location.hash === '#gallery-grid-title' || window.location.search.indexOf('categoria=') !== -1) {
    var scrollToGallery = function () {
      setTimeout(function () {
        var target = document.getElementById('gallery-grid-title') || document.querySelector('.idea-gallery-filters');
        if (target) {
          if (window.ScrollSmoother && typeof window.ScrollSmoother.get === 'function') {
            var sm = window.ScrollSmoother.get();
            if (sm && typeof sm.scrollTo === 'function') {
              sm.scrollTo(target, true, 'top 120px');
              return;
            }
          }
          var top = target.getBoundingClientRect().top + window.pageYOffset - 110;
          window.scrollTo({ top: top, behavior: 'smooth' });
        }
      }, 250);
    };

    if (document.readyState === 'complete') {
      scrollToGallery();
    } else {
      window.addEventListener('load', scrollToGallery);
    }
  }

  // ── Lightbox Slider ──
  var lightbox = document.getElementById('idea-lightbox');
  var lightboxBackdrop = document.getElementById('idea-lightbox-backdrop');
  var lightboxImg = document.getElementById('idea-lightbox-img');
  var lightboxTitle = document.getElementById('idea-lightbox-title');
  var lightboxBadge = document.getElementById('idea-lightbox-badge');
  var lightboxCounter = document.getElementById('idea-lightbox-counter');
  var lightboxClose = document.getElementById('idea-lightbox-close');
  var lightboxPrev = document.getElementById('idea-lightbox-prev');
  var lightboxNext = document.getElementById('idea-lightbox-next');
  var lightboxStage = document.getElementById('idea-lightbox-stage');
  var lightboxTrigger = null;
  var currentIndex = 0;
  var activeItemsList = [];
  var isAnimating = false;

  if (lightbox && lightboxImg) {
    // CRITICAL: Move lightbox to direct child of document.body so that ScrollSmoother
    // matrix3d transform on #smooth-content does not break position: fixed!
    if (lightbox.parentNode !== document.body) {
      document.body.appendChild(lightbox);
    }

    function getVisibleGalleryItems() {
      var visible = [];
      galleryItems.forEach(function (item) {
        if (item.style.display !== 'none') {
          var img = item.querySelector('img');
          if (img && img.src) {
            visible.push({
              element: item,
              src: img.getAttribute('data-full') || img.src,
              alt: img.alt || '',
              title: item.getAttribute('data-title') || img.alt || 'Lavoro d\'Atelier',
              category: item.getAttribute('data-category-label') || ''
            });
          }
        }
      });
      return visible;
    }

    function preloadImage(url) {
      if (!url) return;
      var pre = new Image();
      pre.src = url;
    }

    function updateLightboxSlide(newIndex, direction) {
      if (!activeItemsList.length) return;
      if (newIndex < 0) newIndex = activeItemsList.length - 1;
      if (newIndex >= activeItemsList.length) newIndex = 0;

      currentIndex = newIndex;
      var curItem = activeItemsList[currentIndex];

      if (lightboxTitle) lightboxTitle.textContent = curItem.title || '';
      if (lightboxBadge) {
        if (curItem.category) {
          lightboxBadge.textContent = curItem.category;
          lightboxBadge.style.display = 'inline-block';
        } else {
          lightboxBadge.style.display = 'none';
        }
      }
      if (lightboxCounter) {
        lightboxCounter.textContent = (currentIndex + 1) + ' / ' + activeItemsList.length;
      }

      var hasMultiple = activeItemsList.length > 1;
      if (lightboxPrev) lightboxPrev.style.display = hasMultiple ? 'flex' : 'none';
      if (lightboxNext) lightboxNext.style.display = hasMultiple ? 'flex' : 'none';

      if (hasMultiple) {
        var nextIdx = (currentIndex + 1) % activeItemsList.length;
        var prevIdx = (currentIndex - 1 + activeItemsList.length) % activeItemsList.length;
        preloadImage(activeItemsList[nextIdx].src);
        preloadImage(activeItemsList[prevIdx].src);
      }

      if (direction && lightboxImg.src) {
        isAnimating = true;
        var outX = direction === 'next' ? -24 : 24;
        var inX = direction === 'next' ? 24 : -24;

        lightboxImg.style.transition = 'opacity 0.16s ease, transform 0.16s ease';
        lightboxImg.style.opacity = '0';
        lightboxImg.style.transform = 'translateX(' + outX + 'px) scale(0.96)';

        setTimeout(function () {
          lightboxImg.src = curItem.src;
          lightboxImg.alt = curItem.alt || curItem.title || '';
          lightboxImg.style.transition = 'none';
          lightboxImg.style.transform = 'translateX(' + inX + 'px) scale(0.96)';

          // Force reflow
          void lightboxImg.offsetWidth;

          lightboxImg.style.transition = 'opacity 0.28s ease, transform 0.28s cubic-bezier(0.16, 1, 0.3, 1)';
          lightboxImg.style.opacity = '1';
          lightboxImg.style.transform = 'translateX(0) scale(1)';
          isAnimating = false;
        }, 160);
      } else {
        lightboxImg.src = curItem.src;
        lightboxImg.alt = curItem.alt || curItem.title || '';
        lightboxImg.style.opacity = '1';
        lightboxImg.style.transform = 'scale(1)';
      }
    }

    function openLightbox(itemElement) {
      activeItemsList = getVisibleGalleryItems();
      if (!activeItemsList.length) return;

      var foundIdx = -1;
      for (var i = 0; i < activeItemsList.length; i++) {
        if (activeItemsList[i].element === itemElement) {
          foundIdx = i;
          break;
        }
      }
      if (foundIdx === -1) foundIdx = 0;

      lightboxTrigger = itemElement;
      updateLightboxSlide(foundIdx);

      lightbox.classList.add('open');
      lightbox.setAttribute('aria-hidden', 'false');
      document.documentElement.classList.add('idea-lightbox-open');
      document.body.classList.add('idea-lightbox-open');

      if (window.ScrollSmoother && typeof window.ScrollSmoother.get === 'function') {
        var smoother = window.ScrollSmoother.get();
        if (smoother && typeof smoother.paused === 'function') {
          smoother.paused(true);
        }
      }

      if (lightboxClose) lightboxClose.focus();
    }

    function closeLightbox() {
      lightbox.classList.remove('open');
      lightbox.setAttribute('aria-hidden', 'true');
      document.documentElement.classList.remove('idea-lightbox-open');
      document.body.classList.remove('idea-lightbox-open');

      if (window.ScrollSmoother && typeof window.ScrollSmoother.get === 'function') {
        var smoother = window.ScrollSmoother.get();
        if (smoother && typeof smoother.paused === 'function') {
          smoother.paused(false);
        }
      }

      if (lightboxTrigger && typeof lightboxTrigger.focus === 'function') {
        lightboxTrigger.focus();
      }

      setTimeout(function () {
        if (!lightbox.classList.contains('open')) {
          lightboxImg.src = '';
        }
      }, 350);
    }

    function nextSlide() {
      if (isAnimating || activeItemsList.length <= 1) return;
      updateLightboxSlide(currentIndex + 1, 'next');
    }

    function prevSlide() {
      if (isAnimating || activeItemsList.length <= 1) return;
      updateLightboxSlide(currentIndex - 1, 'prev');
    }

    galleryItems.forEach(function (item) {
      item.addEventListener('click', function () {
        openLightbox(this);
      });
      item.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          openLightbox(this);
        }
      });
    });

    if (lightboxPrev) {
      lightboxPrev.addEventListener('click', function (e) {
        e.stopPropagation();
        prevSlide();
      });
    }

    if (lightboxNext) {
      lightboxNext.addEventListener('click', function (e) {
        e.stopPropagation();
        nextSlide();
      });
    }

    if (lightboxClose) {
      lightboxClose.addEventListener('click', function (e) {
        e.stopPropagation();
        closeLightbox();
      });
    }

    if (lightboxBackdrop) {
      lightboxBackdrop.addEventListener('click', closeLightbox);
    }

    lightbox.addEventListener('click', function (e) {
      if (e.target === lightbox || e.target === lightboxStage || (e.target.classList && e.target.classList.contains('idea-lightbox__figure-wrap'))) {
        closeLightbox();
      }
    });

    document.addEventListener('keydown', function (e) {
      if (!lightbox.classList.contains('open')) return;

      if (e.key === 'Escape') {
        e.preventDefault();
        closeLightbox();
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        prevSlide();
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        nextSlide();
      }
    });

    // Touch swipe gestures
    var touchStartX = 0;
    var touchStartY = 0;
    var touchEndX = 0;
    var touchEndY = 0;

    lightbox.addEventListener('touchstart', function (e) {
      if (!lightbox.classList.contains('open')) return;
      var touch = e.changedTouches[0];
      touchStartX = touch.screenX;
      touchStartY = touch.screenY;
    }, { passive: true });

    lightbox.addEventListener('touchend', function (e) {
      if (!lightbox.classList.contains('open')) return;
      var touch = e.changedTouches[0];
      touchEndX = touch.screenX;
      touchEndY = touch.screenY;

      var diffX = touchEndX - touchStartX;
      var diffY = touchEndY - touchStartY;

      if (Math.abs(diffX) > 40 && Math.abs(diffX) > Math.abs(diffY) * 1.3) {
        if (diffX < 0) {
          nextSlide();
        } else {
          prevSlide();
        }
      }
    }, { passive: true });
  }
})();
