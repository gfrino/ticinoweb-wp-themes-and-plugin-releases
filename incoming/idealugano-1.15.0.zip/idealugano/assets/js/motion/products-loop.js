(function () {
  'use strict';
  window.IdeaMotion.register(function (motion) {
    var scroller = document.querySelector('#prodotti-preview .idea-products-scroll');
    if (!scroller || scroller.dataset.loopReady === 'true') return;
    if (motion.touch) return; // Native momentum scroll on touch devices

    var originals = Array.prototype.slice.call(scroller.children);
    if (originals.length < 2) return;
    scroller.dataset.loopReady = 'true';

    // 1. Create track wrapper and move items
    var track = document.createElement('div');
    track.className = 'idea-products-track';
    originals.forEach(function (card) {
      track.appendChild(card);
    });

    // 2. Clone and append items for infinite marquee loop
    originals.forEach(function (card) {
      var clone = card.cloneNode(true);
      clone.classList.add('idea-product-card--clone', 'visible');
      clone.setAttribute('aria-hidden', 'true');
      clone.querySelectorAll('a').forEach(function (link) { link.setAttribute('tabindex', '-1'); });
      
      // Ensure clones load eagerly (pulled from cache) and keep same loaded class
      var img = clone.querySelector('img');
      if (img) {
        img.setAttribute('loading', 'eager');
        img.removeAttribute('fetchpriority');
        if (!img.classList.contains('loaded')) {
          if (img.complete) {
            img.classList.add('loaded');
          } else {
            img.addEventListener('load', function () {
              img.classList.add('loaded');
            });
            if (img.complete) {
              img.classList.add('loaded');
            }
          }
        }
      }

      var frame = clone.querySelector('.idea-product-card__image');
      var image = frame && frame.querySelector('img, .idea-placeholder');
      if (frame) frame.removeAttribute('style');
      if (image) image.removeAttribute('style');
      track.appendChild(clone);
    });

    scroller.appendChild(track);

    // 3. Setup load fade-in for original images
    var originalImages = track.querySelectorAll('.idea-product-card__image img');
    originalImages.forEach(function (img) {
      if (img.complete) {
        img.classList.add('loaded');
      } else {
        img.addEventListener('load', function () {
          img.classList.add('loaded');
        });
        if (img.complete) {
          img.classList.add('loaded');
        }
      }
    });

    // 4. Animation, State and Drag Variables
    var gsap = window.gsap;
    var loop = null;
    var cycleWidth = 0;
    
    // States: 'AUTO_PLAYING', 'DRAGGING', 'INERTIA', 'PAUSED'
    var state = 'AUTO_PLAYING';
    
    var dragging = false;
    var dragged = false;
    var startX = 0;
    var startTrackX = 0;
    var lastX = 0;
    var lastTime = 0;
    var velocity = 0;
    
    var hovered = false;
    var inViewport = false;
    var documentActive = !document.hidden;
    var resumeTimer = 0;
    var viewObserver = null;
    var preloadObserver = null;
    var active = true;

    // Configurable speeds
    var baseDuration = window.innerWidth >= 1025 ? 36 : 42;

    function wrapX(value) {
      if (!cycleWidth) return value;
      while (value <= -cycleWidth) value += cycleWidth;
      while (value > 0) value -= cycleWidth;
      return value;
    }

    function initLoop() {
      if (!active) return;
      var firstClone = track.querySelector('.idea-product-card--clone');
      if (!firstClone) return;

      cycleWidth = firstClone.offsetLeft - originals[0].offsetLeft;
      if (!cycleWidth) return;

      // Infinite loop animation using translateX
      loop = gsap.to(track, {
        x: -cycleWidth,
        ease: 'none',
        repeat: -1,
        duration: baseDuration,
        paused: true
      });

      if (!window.IdeaMotion.reduced) {
        initIntersectionObserver();
        initPreloadObserver();
      }
    }

    function playAutoplay(smooth) {
      if (!loop || state === 'DRAGGING' || state === 'INERTIA' || hovered || !inViewport || !documentActive || window.IdeaMotion.reduced) return;

      state = 'AUTO_PLAYING';
      gsap.killTweensOf(track);
      gsap.killTweensOf(loop);

      var currentX = gsap.getProperty(track, 'x');
      var currentProgress = -currentX / cycleWidth;

      // Wrap progress
      if (currentProgress < 0) currentProgress += 1;
      if (currentProgress >= 1) currentProgress -= 1;

      loop.progress(currentProgress);

      if (smooth) {
        loop.timeScale(0);
        loop.play();
        // Luxurious soft acceleration from 0 speed to default marquee speed
        gsap.to(loop, { timeScale: 1, duration: 1.8, ease: 'power1.out' });
      } else {
        loop.timeScale(1);
        loop.play();
      }
    }

    function pauseAutoplay() {
      if (loop) loop.pause();
    }

    // IntersectionObserver to pause loop when section is outside viewport
    function initIntersectionObserver() {
      if (!window.IntersectionObserver) {
        inViewport = true;
        playAutoplay();
        return;
      }
      viewObserver = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          inViewport = entry.isIntersecting;
          if (inViewport) {
            playAutoplay();
          } else {
            pauseAutoplay();
          }
        });
      }, { threshold: 0.05 });
      viewObserver.observe(scroller);
    }

    // IntersectionObserver with rootMargin looking ahead 600px to prefetch lazy images
    function initPreloadObserver() {
      if (!window.IntersectionObserver) return;
      preloadObserver = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            var img = entry.target.querySelector('img');
            if (img && img.getAttribute('loading') === 'lazy') {
              img.setAttribute('loading', 'eager');
            }
            preloadObserver.unobserve(entry.target);
          }
        });
      }, {
        rootMargin: '0px 600px 0px 0px',
        threshold: 0
      });

      originals.forEach(function (card) {
        preloadObserver.observe(card);
      });
    }

    function handleVisibility() {
      documentActive = !document.hidden;
      if (documentActive) {
        playAutoplay();
      } else {
        pauseAutoplay();
      }
    }
    document.addEventListener('visibilitychange', handleVisibility);

    function handlePageshow(event) {
      if (event.persisted) {
        documentActive = !document.hidden;
        if (inViewport && !hovered && state !== 'DRAGGING') {
          state = 'AUTO_PLAYING';
          playAutoplay(true);
        }
      }
    }
    window.addEventListener('pageshow', handlePageshow);

    // Hover Pause Listeners (Throttled to active mouse movement inside)
    var hasMovedHover = false;
    scroller.addEventListener('pointerenter', function (event) {
      if (event.pointerType === 'mouse') {
        hasMovedHover = false;
      }
    });

    scroller.addEventListener('pointermove', function (event) {
      if (state !== 'DRAGGING' && state !== 'INERTIA' && event.pointerType === 'mouse') {
        if (!hasMovedHover) {
          hasMovedHover = true;
          hovered = true;
          state = 'PAUSED';
          pauseAutoplay();
        }
      }
    });

    scroller.addEventListener('pointerleave', function (event) {
      if (event.pointerType === 'mouse') {
        hasMovedHover = false;
        hovered = false;
        if (state === 'PAUSED') {
          playAutoplay(true);
        }
      }
    });

    // Drag / Swipe Pointer Listeners
    scroller.addEventListener('pointerdown', function (event) {
      if (event.pointerType === 'mouse' && event.button !== 0) return;

      gsap.killTweensOf(track);
      window.clearTimeout(resumeTimer);
      
      dragging = true;
      dragged = false;
      state = 'DRAGGING';
      pauseAutoplay();

      startX = event.clientX;
      startTrackX = gsap.getProperty(track, 'x');
      lastX = event.clientX;
      lastTime = event.timeStamp;
      velocity = 0;

      scroller.classList.add('is-dragging');
      scroller.setPointerCapture(event.pointerId);
    });

    scroller.addEventListener('pointermove', function (event) {
      if (!dragging) return;

      var deltaX = event.clientX - startX;
      if (Math.abs(deltaX) > 5) {
        dragged = true;
      }

      var timeDelta = event.timeStamp - lastTime;
      if (timeDelta > 0) {
        var instantVelocity = (event.clientX - lastX) / (timeDelta / 1000);
        velocity = velocity * 0.6 + instantVelocity * 0.4;
        lastX = event.clientX;
        lastTime = event.timeStamp;
      }

      var newX = wrapX(startTrackX + deltaX);
      gsap.set(track, { x: newX });
    });

    function release(event) {
      if (!dragging) return;
      dragging = false;
      scroller.classList.remove('is-dragging');
      if (scroller.hasPointerCapture(event.pointerId)) {
        scroller.releasePointerCapture(event.pointerId);
      }

      var currentX = gsap.getProperty(track, 'x');
      if (dragged && Math.abs(velocity) > 60) {
        state = 'INERTIA';

        // Calculate momentum slide duration and distance based on velocity
        var cappedVelocity = Math.max(-1800, Math.min(1800, velocity));
        var slideDuration = Math.max(0.6, Math.min(1.5, Math.abs(cappedVelocity) / 800));
        var slideDist = cappedVelocity * (slideDuration * 0.45);

        // Tween using proxy object to avoid wrapping boundary inversion
        var proxy = { x: currentX };
        gsap.to(proxy, {
          x: currentX + slideDist,
          duration: slideDuration,
          ease: 'power2.out',
          onUpdate: function () {
            gsap.set(track, { x: wrapX(proxy.x) });
          },
          onComplete: function () {
            gsap.set(track, { x: wrapX(proxy.x) });
            state = hovered ? 'PAUSED' : 'AUTO_PLAYING';
            if (state === 'AUTO_PLAYING') {
              playAutoplay(true); // Smoothly ramp up autoplay
            } else {
              pauseAutoplay();
            }
          }
        });
      } else {
        state = 'INERTIA';
        resumeTimer = window.setTimeout(function () {
          state = hovered ? 'PAUSED' : 'AUTO_PLAYING';
          if (state === 'AUTO_PLAYING') {
            playAutoplay(true);
          } else {
            pauseAutoplay();
          }
        }, 1500);
      }
    }

    scroller.addEventListener('pointerup', release);
    scroller.addEventListener('pointercancel', release);

    scroller.addEventListener('click', function (event) {
      if (dragged) {
        event.preventDefault();
        event.stopPropagation();
        dragged = false;
      }
    }, true);

    // Support trackpad and horizontal wheel scrolling
    scroller.addEventListener('wheel', function (event) {
      if (Math.abs(event.deltaX) > Math.abs(event.deltaY)) {
        event.preventDefault();
        
        gsap.killTweensOf(track);
        window.clearTimeout(resumeTimer);
        pauseAutoplay();
        state = 'DRAGGING';
        
        var currentX = gsap.getProperty(track, 'x');
        var newX = wrapX(currentX - event.deltaX * 0.8);
        gsap.set(track, { x: newX });
        
        state = 'INERTIA';
        resumeTimer = window.setTimeout(function () {
          state = hovered ? 'PAUSED' : 'AUTO_PLAYING';
          if (state === 'AUTO_PLAYING') {
            playAutoplay(true);
          } else {
            pauseAutoplay();
          }
        }, 1500);
      }
    }, { passive: false });

    // Delay initialization to let layout settle
    if (document.readyState === 'complete') {
      setTimeout(initLoop, 300);
    } else {
      window.addEventListener('load', function () {
        setTimeout(initLoop, 300);
      });
    }

    // Cleanup hook
    return function () {
      active = false;
      pauseAutoplay();
      if (loop) loop.kill();
      if (viewObserver) viewObserver.disconnect();
      if (preloadObserver) preloadObserver.disconnect();
      document.removeEventListener('visibilitychange', handleVisibility);
      window.removeEventListener('pageshow', handlePageshow);
      window.clearTimeout(resumeTimer);
      gsap.killTweensOf(track);
    };
  });
})();
