(function () {
  'use strict';
  window.IdeaMotion.register(function (motion) {
    var gsap = motion.gsap;
    document.querySelectorAll('[data-motion-text]').forEach(function (wrap) {
      var text = wrap.querySelector('span') || wrap;
      var direction = wrap.dataset.direction === 'right' ? 1 : -1;
      var speed = parseFloat(wrap.dataset.speed || '1');
      var startOffset = wrap.classList.contains('idea-kinetic--transform') ? 4 : 0;
      motion.media.add({ desktop: '(min-width: 1025px)', tablet: '(min-width: 641px) and (max-width: 1024px)', mobile: '(max-width: 640px)' }, function (context) {
        var factor = context.conditions.desktop ? 1 : (context.conditions.tablet ? .52 : .25);
        var travel = motion.config.textTravel * speed * factor;
        gsap.fromTo(text, { xPercent: -direction * travel + startOffset }, {
          xPercent: direction * travel,
          ease: 'none',
          scrollTrigger: {
            trigger: wrap.closest('section') || wrap,
            start: 'top bottom',
            end: 'bottom top',
            scrub: context.conditions.desktop ? motion.config.scrubSoft : .45
          }
        });
      });
    });

    var signature = document.querySelector('.idea-signature');
    if (signature) {
      motion.media.add({
        desktop: '(min-width: 1025px)',
        tablet: '(min-width: 641px) and (max-width: 1024px)',
        mobile: '(max-width: 640px)'
      }, function (context) {
        var desktop = context.conditions.desktop;
        var tablet = context.conditions.tablet;
        var mobile = context.conditions.mobile;

        var back = signature.querySelector('.idea-signature__word--back');
        var front = signature.querySelector('.idea-signature__word--front');
        var image = signature.querySelector('.idea-signature__image');
        var imageInner = image.querySelector('img, .idea-placeholder');
        var copy = signature.querySelector('.idea-signature__copy');
        var line = copy.querySelector('.idea-gold-line');

        /* ARTE target centered X position relative to the vertical image behind.
           Calculates center of image - center of text (untransformed). */
        var calculateTargetX = function () {
          var prevTransform = back.style.transform;
          back.style.transform = 'none';
          var imgRect = image.getBoundingClientRect();
          var textRect = back.getBoundingClientRect();
          back.style.transform = prevTransform;

          var imgCenterX = imgRect.left + imgRect.width / 2;
          var textCenterX = textRect.left + textRect.width / 2;
          return imgCenterX - textCenterX;
        };

        /* Starts further left. Bounded so that the left edge of the text
           never exceeds a 16px safety margin from the viewport boundary. */
        var calculateStartX = function () {
          var targetX = calculateTargetX();
          var prevTransform = back.style.transform;
          back.style.transform = 'none';
          var textRect = back.getBoundingClientRect();
          back.style.transform = prevTransform;

          var vw = window.innerWidth;
          var travel = Math.min(vw * 0.35, 150);
          var startX = targetX - travel;
          var minX = 16 - textRect.left;
          return Math.max(startX, minX);
        };

        /* SU MISURA end position, measured — not estimated.
           Rest state: left edge lands at ~30vw, clamped so it never reaches
           the copy block. xPercent is relative to word width; anchor left:50%. */
        var frontEnd = function () {
          var vw = window.innerWidth;
          var w = front.offsetWidth || 1;
          var end = ((vw * 0.30) - vw * 0.5) / w * 100;
          var minLeft = copy.offsetLeft + copy.offsetWidth + 24;
          var minEnd = ((minLeft - vw * 0.5) / w) * 100;
          return Math.max(end, minEnd);
        };
        /* Arrives from further right: ~35% of its own width past the rest point */
        var frontStart = function () { return frontEnd() + 35; };

        /* Align the left edge of ARTE (back) with the left edge of SU MISURA (front) on desktop */
        var backEnd = function () {
          var wBack = back.offsetWidth || 1;
          var wFront = front.offsetWidth || 1;
          var targetXPercentFront = frontEnd();
          return targetXPercentFront * (wFront / wBack);
        };

        var eyebrow = copy.querySelector('.idea-eyebrow');
        var title = copy.querySelector('h2');
        var p = copy.querySelector('p');
        var cta = copy.querySelector('a');

        var contentItems = [eyebrow, title, line, p, cta].filter(Boolean);

        // Normalize the main timeline duration to 1
        var mainDuration = 1;

        /* Two strict phases: the big words own [0 → wordsDuration], the copy
           block owns [wordsDuration + gap → 1]. No overlap — the copy starts
           only after ARTE and SU MISURA sit at their final position. */
        var wordsDuration = desktop ? 0.68 : (tablet ? 0.62 : 0.55);
        var phaseGap = 0.03;

        // Calculate the exact stagger and duration to finish exactly at 1.0
        var remaining = mainDuration - (wordsDuration + phaseGap);
        var totalItems = contentItems.length;
        var itemStagger = desktop ? 0.04 : 0.05;
        var itemDuration = remaining - (itemStagger * (totalItems - 1));
        if (mobile) itemDuration = Math.min(itemDuration, 0.18); // snappier reveal on phones

        var itemY = desktop ? 28 : (tablet ? 24 : 16);

        /* Hide the copy immediately: the fromTo below sits at textStartPercent
           (> 0) in the timeline, so without this the items stay CSS-visible
           until the scrub reaches that point and then snap to alpha 0. */
        gsap.set(contentItems, { autoAlpha: 0, y: itemY });

        var tl = gsap.timeline({
          scrollTrigger: {
            trigger: signature,
            start: desktop ? 'top top' : 'top 82%',
            end: desktop ? 'bottom bottom' : 'bottom 18%',
            scrub: desktop ? 1.2 : (tablet ? 0.75 : 0.45),
            invalidateOnRefresh: true
          }
        });

        // Set initial state at time 0 inside the timeline so ScrollTrigger maintains it before the fade-in tween starts
        tl.set(contentItems, { autoAlpha: 0, y: itemY }, 0);

        /* inOut easing: velocity is zero at both ends of every tween, so the
           words and the image frame start and stop gently at the pin
           boundaries — with a linear ease they froze/launched abruptly and,
           through the scrub lag, kept drifting after the stage unpinned. */
        tl.fromTo(back,
          {
            xPercent: desktop ? -75 : 0,
            x: desktop ? 0 : function () { return calculateStartX(); }
          },
          {
            xPercent: desktop ? backEnd : 0,
            x: desktop ? 0 : function () { return calculateTargetX(); },
            ease: 'power1.inOut',
            duration: wordsDuration
          },
          0
        )
        .fromTo(front,
          { xPercent: desktop ? frontStart : 15 },
          { xPercent: desktop ? frontEnd : -50, ease: 'power1.inOut', duration: wordsDuration },
          0
        )
        .to(image, { clipPath: 'inset(0% round 28px)', ease: 'power2.inOut', duration: mainDuration * 0.5 }, 0)
        .to(imageInner, { scale: 1, ease: 'power2.inOut', duration: mainDuration * 0.5 }, 0)
        .addLabel('mainTextComplete', wordsDuration);

        // Phase 2: the copy block reveals only after the words are done
        tl.fromTo(contentItems,
          {
            autoAlpha: 0,
            y: itemY
          },
          {
            autoAlpha: 1,
            y: 0,
            duration: itemDuration,
            stagger: itemStagger,
            ease: "power2.out"
          },
          'mainTextComplete+=' + phaseGap
        );
      });
    }

    var prelude = document.querySelector('.idea-contact-prelude');
    if (prelude) {
      /* Lines span the FULL timeline (duration 1) so they never freeze.
         The travel is asymmetric: the centered, fully-readable position sits
         at ~30% of the scroll range instead of halfway — both words are well
         visible early, then keep drifting for the rest of the section. */
      motion.media.add({ desktop: '(min-width: 1025px)', compact: '(max-width: 1024px)' }, function (context) {
        var compact = context.conditions.compact;
        /* Small `from` + large `to` = the lines cross at ~from/(from+to) of
           the scroll range — kept low so they cross with little scrolling */
        var from = compact ? 1 : 4;
        var to = compact ? 13 : 44;
        gsap.timeline({ scrollTrigger: { trigger: prelude, start: 'top bottom', end: 'bottom top', scrub: compact ? .45 : motion.config.scrubSoft } })
          .fromTo('.idea-contact-prelude__line--one', { xPercent: -from }, { xPercent: to, ease: 'none', duration: 1 }, 0)
          .fromTo('.idea-contact-prelude__line--two', { xPercent: from }, { xPercent: -to, ease: 'none', duration: 1 }, 0)
          .to(prelude, { backgroundColor: '#052d3a', color: '#f7f3ea', ease: 'none', duration: .45 }, .08);
      });
    }
  });
})();
