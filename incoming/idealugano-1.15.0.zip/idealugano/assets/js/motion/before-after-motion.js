(function () {
  'use strict';
  window.IdeaMotion.register(function (motion) {
    var gsap = motion.gsap;
    var sliders = gsap.utils.toArray('.idea-ba-slider');
    var carousels = gsap.utils.toArray('.idea-ba-carousel');
    carousels.forEach(function (carousel) {
      var lastActiveProject = carousel.querySelector('.idea-ba-project.is-active');

      if (lastActiveProject) {
        var activeSlider = lastActiveProject.querySelector('.idea-ba-slider');
        var description = lastActiveProject.querySelector('.idea-text-center');

        motion.media.add({ desktop: '(min-width: 1025px)', compact: '(max-width: 1024px)' }, function (context) {
          var desktop = context.conditions.desktop;
          if (activeSlider) {
            gsap.fromTo(activeSlider, 
              { 
                clipPath: desktop ? 'inset(0 49% 0 49% round 24px)' : 'inset(0 12% 0 12% round 20px)', 
                scale: desktop ? .97 : .99 
              }, 
              { 
                clipPath: 'inset(0 0% 0 0% round 24px)', 
                scale: 1, 
                duration: desktop ? 1.05 : .48, 
                ease: motion.config.easeCinematic, 
                scrollTrigger: { trigger: carousel, start: 'top 88%', once: true } 
              }
            );
          }
          if (description) {
            gsap.from(description, { 
              y: desktop ? 35 : 16, 
              opacity: 0, 
              duration: desktop ? .72 : .42, 
              delay: desktop ? .38 : .12, 
              ease: motion.config.easeSoft, 
              scrollTrigger: { trigger: carousel, start: 'top 88%', once: true } 
            });
          }
        });
      }

      document.addEventListener('idealugano:layoutchange', function () {
        var currentActiveProject = carousel.querySelector('.idea-ba-project.is-active');
        if (!currentActiveProject || currentActiveProject === lastActiveProject) return;
        lastActiveProject = currentActiveProject;

        var activeSlider = currentActiveProject.querySelector('.idea-ba-slider');
        var description = currentActiveProject.querySelector('.idea-text-center');
        var desktop = window.innerWidth >= 1025;

        if (activeSlider) {
          gsap.killTweensOf(activeSlider);
          gsap.fromTo(activeSlider, 
            { 
              clipPath: desktop ? 'inset(0 49% 0 49% round 24px)' : 'inset(0 12% 0 12% round 20px)', 
              scale: desktop ? .97 : .99 
            }, 
            { 
              clipPath: 'inset(0 0% 0 0% round 24px)', 
              scale: 1, 
              duration: desktop ? 0.85 : 0.48, 
              ease: motion.config.easeCinematic 
            }
          );
        }

        if (description) {
          gsap.killTweensOf(description);
          gsap.from(description, { 
            y: desktop ? 25 : 12, 
            opacity: 0, 
            duration: desktop ? .6 : .4, 
            ease: motion.config.easeSoft 
          });
        }
      });
    });

    if (motion.touch || !sliders.length) return;
    var cursor = document.createElement('div');
    cursor.className = 'idea-drag-cursor';
    cursor.setAttribute('aria-hidden', 'true');
    var inner = document.createElement('div');
    inner.className = 'idea-drag-cursor__inner';
    inner.textContent = 'Trascina';
    cursor.appendChild(inner);
    document.body.appendChild(cursor);

    var moveX = gsap.quickTo(cursor, 'x', { duration: .1, ease: 'power1.out' });
    var moveY = gsap.quickTo(cursor, 'y', { duration: .1, ease: 'power1.out' });
    sliders.forEach(function (slider) {
      slider.addEventListener('pointerenter', function () { cursor.classList.add('is-visible'); });
      slider.addEventListener('pointerleave', function () { cursor.classList.remove('is-visible'); });
      slider.addEventListener('pointermove', function (event) { moveX(event.clientX); moveY(event.clientY); });
      slider.addEventListener('pointerdown', function () { cursor.classList.remove('is-visible'); });
      slider.addEventListener('pointerup', function () { cursor.classList.add('is-visible'); });
    });
  });
})();
