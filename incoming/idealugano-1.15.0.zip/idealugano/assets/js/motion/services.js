(function () {
  'use strict';
  window.IdeaMotion.register(function (motion) {
    var gsap = motion.gsap;
    var cards = gsap.utils.toArray('.idea-services-scene .idea-service-card');
    cards.forEach(function (card) { card.classList.add('visible'); });
    if (cards.length) {
      motion.media.add({ desktop: '(min-width: 1025px)', compact: '(max-width: 1024px)' }, function (context) {
        var desktop = context.conditions.desktop;
        if (desktop) {
          var images = cards.map(function (card) { return card.querySelector('.idea-service-card__image'); });
          gsap.timeline({ scrollTrigger: { trigger: '.idea-services-scene', start: 'top 90%', once: true } })
            .fromTo(cards, {
              y: 45,
              opacity: 0,
              scale: 0.98
            }, {
              y: 0,
              opacity: 1,
              scale: 1,
              duration: 0.75,
              stagger: 0.08,
              ease: motion.config.easeSoft,
              clearProps: 'transform'
            }, 0)
            .fromTo(images, {
              clipPath: 'inset(6% 0 0 0 round 12px)'
            }, {
              clipPath: 'inset(0% 0 0 0 round 0px)',
              duration: 0.72,
              stagger: 0.08,
              ease: motion.config.easeCinematic
            }, 0.03);
        }
        cards.forEach(function (card, index) {
          var image = card.querySelector('.idea-service-card__image');
          if (desktop) return;
          var timeline = gsap.timeline({ scrollTrigger: { trigger: card, start: 'top 95%', once: true } });
          timeline.fromTo(card,
            { x: motion.touch ? 0 : (index % 2 ? 15 : -15), y: 30, opacity: 0 },
            { x: 0, y: 0, opacity: 1, duration: 0.55, ease: motion.config.easeSoft, clearProps: 'transform' }
          )
            .fromTo(image, { clipPath: 'inset(6% 0 0 0 round 12px)' }, { clipPath: 'inset(0 0 0 0 round 0px)', duration: 0.5, ease: motion.config.easeSoft }, 0.05);
        });
      });
    }

    gsap.utils.toArray('.idea-service-detail').forEach(function (detail, index) {
      detail.classList.add('visible');
      var text = detail.querySelector('.idea-service-detail__text');
      gsap.from(text, { x: motion.touch ? 0 : (index % 2 ? 32 : -32), y: motion.touch ? 22 : 0, opacity: 0, duration: motion.touch ? .6 : .9, ease: motion.config.easeSoft, scrollTrigger: { trigger: detail, start: 'top 86%', once: true } });
    });
    var methodSteps = gsap.utils.toArray('.idea-method-step');
    if (methodSteps.length) {
      gsap.from(methodSteps, {
        x: motion.touch ? 0 : -18,
        y: motion.touch ? 18 : 0,
        stagger: .1,
        duration: .65,
        ease: motion.config.easeSoft,
        clearProps: 'transform',
        scrollTrigger: { trigger: methodSteps[0], start: 'top 90%', once: true }
      });
    }
  });
})();
