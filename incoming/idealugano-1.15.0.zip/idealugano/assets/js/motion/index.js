/** Motion bootstrap: one context, responsive matchMedia and deterministic cleanup. */
(function () {
  'use strict';
  var motion = window.IdeaMotion;
  if (!motion) return;
  document.documentElement.classList.add(motion.reduced ? 'idea-reduced-motion' : 'idea-motion-enabled');
  if (!motion.gsap || !motion.ScrollTrigger || motion.reduced) {
    motion.reveal(document.querySelectorAll('.reveal'));
    return;
  }
  motion.gsap.registerPlugin(motion.ScrollTrigger);
  /* Legacy reveal classes remain in the templates, but visibility is immediate.
     Dedicated modules now own every entrance to avoid stacked fades and blanks. */
  motion.reveal(document.querySelectorAll('.reveal'));
  motion.media = motion.gsap.matchMedia();
  motion.context = motion.gsap.context(function () {
    motion.initializers.forEach(function (initializer) { initializer(motion); });
  });
  window.addEventListener('load', function () { motion.ScrollTrigger.refresh(); }, { once: true });
  window.addEventListener('pageshow', function (event) {
    if (event.persisted) {
      if (motion.smoother && typeof motion.smoother.paused === 'function') {
        motion.smoother.paused(false);
      }
      if (motion.ScrollTrigger) {
        motion.ScrollTrigger.refresh();
        requestAnimationFrame(function () {
          motion.ScrollTrigger.refresh();
        });
      }
    }
  });
})();
