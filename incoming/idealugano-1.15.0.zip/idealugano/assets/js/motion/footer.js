(function () {
  'use strict';
  window.IdeaMotion.register(function (motion) {
    var gsap = motion.gsap;
    document.querySelectorAll('.idea-brands-grid').forEach(function (grid) {
      var items = grid.querySelectorAll('.idea-brand-item');
      gsap.from(items, { y: 20, stagger: .1, duration: .65, ease: motion.config.easeSoft, clearProps: 'transform', scrollTrigger: { trigger: grid, start: 'top 90%', once: true } });
      gsap.fromTo(grid, { '--brand-line': '0%' }, { '--brand-line': '100%', duration: 1.2, ease: motion.config.easeCinematic, scrollTrigger: { trigger: grid, start: 'top 82%', once: true } });
    });

    var contact = document.querySelector('.idea-contact-grid');
    if (contact) {
      gsap.from(contact.querySelectorAll('.idea-contact-info-card'), { x: motion.touch ? 0 : -22, y: motion.touch ? 18 : 0, opacity: 0, stagger: .1, duration: .7, ease: motion.config.easeSoft, scrollTrigger: { trigger: contact, start: 'top 82%', once: true } });
      gsap.from(contact.querySelectorAll('.idea-form__group, .idea-form .idea-btn'), { y: 26, opacity: 0, stagger: .08, duration: .65, ease: motion.config.easeSoft, scrollTrigger: { trigger: contact, start: 'top 78%', once: true } });
    }

    var footer = document.querySelector('.idea-footer--reveal');
    if (!footer) return;
    var columns = footer.querySelectorAll('.idea-footer__grid > *');
    if (!motion.touch) {
      gsap.from(footer, { y: 40, opacity: .6, ease: 'none', scrollTrigger: { trigger: footer, start: 'top bottom', end: 'top 85%', scrub: .6 } });
    }
    gsap.from(columns, { y: motion.touch ? 14 : 20, opacity: 0, stagger: motion.touch ? .04 : .08, duration: motion.touch ? .48 : .65, ease: motion.config.easeSoft, scrollTrigger: { trigger: footer, start: 'top 92%', once: true } });
    gsap.from('.idea-footer__bottom', { scaleX: .9, opacity: 0, duration: .75, transformOrigin: 'center', ease: motion.config.easeSoft, scrollTrigger: { trigger: footer, start: 'top 85%', once: true } });
  });
})();
