(function () {
  'use strict';
  window.IdeaMotion.register(function (motion) {
    var gsap = motion.gsap;
    var signal = motion.abort.signal;

    document.querySelectorAll('.idea-page-hero').forEach(function (hero) {
      var eyebrow = hero.querySelector('.idea-eyebrow');
      var title = hero.querySelector('.idea-page-hero__title');
      var line = hero.querySelector('.idea-gold-line');
      var subtitle = hero.querySelector('.idea-page-hero__subtitle');
      gsap.timeline({ defaults: { ease: motion.config.easeSoft } })
        .from(eyebrow, { y: 18, opacity: 0, duration: .55 })
        .from(title, { yPercent: 55, opacity: 0, duration: .9 }, .12)
        .from(line, { scaleX: 0, duration: .75 }, .42)
        .from(subtitle, { y: 22, opacity: 0, duration: .65 }, .5);
    });

    /* The signature copy's gold line is owned by the kinetic-text timeline —
       a second viewport-based trigger here would reveal it too early. */
    document.querySelectorAll('.idea-gold-line:not(.idea-page-hero .idea-gold-line):not(.idea-signature .idea-gold-line)').forEach(function (line) {
      gsap.from(line, { scaleX: 0, transformOrigin: line.classList.contains('idea-gold-line--center') ? 'center' : 'left', duration: .8, ease: motion.config.easeCinematic, scrollTrigger: { trigger: line, start: 'top 88%', once: true } });
    });

    initPageTransitions(motion, signal);
  });

  function initPageTransitions(motion, signal) {
    if (motion.config.pageTransitions === false) return;
    var gsap = motion.gsap;
    var panel = document.querySelector('.idea-page-transition');
    if (!panel) return;

    function resetTransition() {
      document.body.classList.remove('idea-transitioning');
      document.documentElement.classList.remove('idea-transition-arrival');
      try { sessionStorage.removeItem('idealuganoTransition'); } catch (error) {}
      gsap.killTweensOf(panel);
      var span = panel.querySelector('span');
      if (span) {
        gsap.killTweensOf(span);
        gsap.set(span, { opacity: 0, clearProps: 'opacity' });
      }
      gsap.set(panel, { y: '', yPercent: 101, clearProps: 'transform,y' });
    }

    // Dismiss transition immediately when page is restored from bfcache (Back/Forward)
    window.addEventListener('pageshow', function (event) {
      if (event.persisted) {
        resetTransition();
      }
    });

    // Reset visual panel state when departing so page is clean if stored in bfcache
    window.addEventListener('pagehide', function () {
      document.body.classList.remove('idea-transitioning');
      document.documentElement.classList.remove('idea-transition-arrival');
      gsap.killTweensOf(panel);
      var span = panel.querySelector('span');
      if (span) {
        gsap.killTweensOf(span);
        gsap.set(span, { opacity: 0, clearProps: 'opacity' });
      }
      gsap.set(panel, { y: '', yPercent: 101, clearProps: 'transform,y' });
    });

    try {
      if (sessionStorage.getItem('idealuganoTransition') === '1') {
        sessionStorage.removeItem('idealuganoTransition');
        gsap.set(panel, { y: 0 });
        gsap.set(panel.querySelector('span'), { opacity: 1 });
        document.documentElement.classList.remove('idea-transition-arrival');
        gsap.timeline().to(panel.querySelector('span'), { opacity: 0, duration: .2, delay: .12 }).to(panel, { yPercent: -101, duration: .6, ease: motion.config.easeCinematic }, .12);
      } else {
        resetTransition();
      }
    } catch (error) { /* Storage can be disabled. */ }

    document.addEventListener('click', function (event) {
      var link = event.target.closest('a');
      if (!link || event.defaultPrevented || event.button > 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      var href = link.getAttribute('href');
      if (!href || href.charAt(0) === '#' || link.target === '_blank' || link.hasAttribute('download')) return;
      var url;
      try { url = new URL(link.href, location.href); } catch (error) { return; }
      if (url.origin !== location.origin || (url.pathname === location.pathname && url.hash)) return;

      event.preventDefault();
      document.body.classList.add('idea-transitioning');
      gsap.timeline({ onComplete: function () {
        try { sessionStorage.setItem('idealuganoTransition', '1'); } catch (error) { /* Storage can be disabled. */ }
        location.href = url.href;
      } }).to(panel, { y: 0, duration: .55, ease: motion.config.easeCinematic }).to(panel.querySelector('span'), { opacity: 1, duration: .25 }, .2);
    }, { signal: signal });
  }
})();
