(function () {
  'use strict';
  window.IdeaMotion.register(function (motion) {
    var gsap = motion.gsap;
    var section = document.querySelector('.idea-objects-collage');
    if (!section) return;
    var items = gsap.utils.toArray('.idea-objects-collage .idea-object-item');
    if (motion.touch) {
      items.forEach(function (item, index) {
        gsap.from(item, {
          y: 22,
          opacity: 0,
          duration: .55,
          delay: index * .05,
          ease: motion.config.easeSoft,
          clearProps: 'transform',
          scrollTrigger: { trigger: item, start: 'top 92%', once: true }
        });
      });
      return;
    }
    motion.media.add({ desktop: '(min-width: 1025px)', compact: '(max-width: 1024px)' }, function (context) {
      items.forEach(function (item, index) {
        var distance = context.conditions.desktop ? 65 + index * 34 : 24 + index * 9;
        gsap.fromTo(item, { y: distance, rotation: index % 2 ? 1.4 : -1.2 }, { y: -distance * .55, rotation: index % 2 ? .35 : -.3, ease: 'none', scrollTrigger: { trigger: section, start: 'top bottom', end: 'bottom top', scrub: context.conditions.desktop ? 1 : .6 } });
        var caption = item.querySelector('.idea-object-item__caption');
        if (caption) gsap.fromTo(caption, { yPercent: 110, opacity: 0 }, { yPercent: 0, opacity: 1, duration: .65, ease: motion.config.easeSoft, scrollTrigger: { trigger: item, start: 'top 72%', once: true } });
      });
    });
  });
})();
