(function () {
  'use strict';
  window.IdeaMotion.register(function (motion) {
    var gsap = motion.gsap;
    var story = document.querySelector('.idea-curtains-story');
    if (!story) return;
    var track = story.querySelector('.idea-curtains-track');
    var cards = gsap.utils.toArray('.idea-curtains-track .idea-curtain-card');
    var images = gsap.utils.toArray('.idea-curtains-track .idea-curtain-card__image');
    var heading = story.querySelector('.idea-text-center');
    var progress = story.querySelector('.idea-curtains-progress span');

    motion.media.add({ desktop: '(min-width: 1025px)', compact: '(max-width: 1024px)' }, function (context) {
      if (context.conditions.desktop) {
        var distance = function () { return Math.max(0, track.scrollWidth - window.innerWidth + window.innerWidth * .08); };
        gsap.to(track, { x: function () { return -distance(); }, ease: 'none', scrollTrigger: { trigger: story, start: 'top top', end: 'bottom bottom', scrub: motion.config.scrubSoft, invalidateOnRefresh: true } });
        /* Heading drifts but stays readable (was fading to .42, illegible
           over the passing card images) */
        gsap.to(heading, { xPercent: 22, opacity: .85, ease: 'none', scrollTrigger: { trigger: story, start: 'top top', end: 'bottom bottom', scrub: 1.4 } });
        /* Soft cream veil behind the copy, fading in early — right as the
           first cards start sliding underneath the text. Low opacity + a wide
           matching halo so it reads as a glow, not a box */
        gsap.to(heading, { backgroundColor: 'rgba(251,248,241,0.68)', boxShadow: '0 0 42px 28px rgba(251,248,241,0.68)', ease: 'none', scrollTrigger: { trigger: story, start: 'top top', end: '22% top', scrub: .8 } });
        gsap.to(progress, { scaleX: 1, ease: 'none', scrollTrigger: { trigger: story, start: 'top top', end: 'bottom bottom', scrub: .55 } });
        var revealTimeline = gsap.timeline({ scrollTrigger: { trigger: story, start: 'top top', end: 'bottom bottom', scrub: 1 } });
        cards.forEach(function (card, index) {
          revealTimeline.fromTo(card, { clipPath: 'inset(0 48% 0 48% round 28px)' }, { clipPath: 'inset(0 0% 0 0% round 28px)', duration: .28, ease: 'power2.out' }, index * .24);
        });
        images.forEach(function (image) {
          gsap.fromTo(image, { scale: 1.13, xPercent: -4 }, { scale: 1.02, xPercent: 4, ease: 'none', scrollTrigger: { trigger: story, start: 'top top', end: 'bottom bottom', scrub: 1 } });
        });
      } else {
        var update = function () {
          var max = track.scrollWidth - track.clientWidth;
          gsap.set(progress, { scaleX: max > 0 ? track.scrollLeft / max : 0 });
        };
        track.addEventListener('scroll', update, { passive: true });
        gsap.set(cards, { clipPath: 'none', opacity: 1 });
        update();
        return function () { track.removeEventListener('scroll', update); };
      }
    });
  });
})();
