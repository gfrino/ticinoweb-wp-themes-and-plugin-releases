/**
 * ScrollSmoother bootstrap — single instance, created before every other
 * motion module so ScrollTrigger measures against the smoothed scroller.
 *
 * Guards:
 *  - prefers-reduced-motion never reaches this module (index.js bails earlier)
 *  - touch-only devices keep 100% native scroll: no instance is created at all
 *    (this also keeps the CSS position:sticky scenes working untouched there)
 *
 * On desktop the two sticky cinematic stages are re-pinned with ScrollTrigger,
 * because position:sticky cannot work inside ScrollSmoother's transformed
 * content. The CSS sticky is neutralised via the `idea-smooth-active` class.
 */
(function () {
  'use strict';
  window.IdeaMotion.register(function (motion) {
    var gsap = motion.gsap;
    var ScrollTrigger = motion.ScrollTrigger;
    var ScrollSmoother = window.ScrollSmoother;
    var wrapper = document.getElementById('smooth-wrapper');
    var content = document.getElementById('smooth-content');

    if (!ScrollSmoother || !wrapper || !content) return;
    if (motion.touch) return; // native scroll on touch devices — no artificial scroll, no lag
    if (ScrollSmoother.get()) return; // never allow a second instance

    gsap.registerPlugin(ScrollSmoother);

    // Fixed elements rendered inside the templates must live outside the
    // transformed content, or position:fixed stops working for them.
    ['#curtain-overlay'].forEach(function (selector) {
      var el = document.querySelector(selector);
      if (el && content.contains(el)) document.body.appendChild(el);
    });

    // Neutralise native smooth anchor scrolling and CSS sticky stages
    document.documentElement.classList.add('idea-smooth-active');

    motion.smoother = ScrollSmoother.create({
      wrapper: wrapper,
      content: content,
      smooth: 1.15,
      /* Only elements explicitly marked .idea-fx get data-speed/data-lag
         effects — the kinetic-text module owns its own [data-speed] markup
         and must not be double-driven by ScrollSmoother. */
      effects: '.idea-fx',
      smoothTouch: 0,
      normalizeScroll: false,
      ignoreMobileResize: true
    });

    // Re-pin the sticky cinematic stages with ScrollTrigger (transform-based
    // pinning works inside the smoothed content, CSS sticky does not).
    ['.idea-signature__stage', '.idea-curtains-story__stage'].forEach(function (selector) {
      var stage = document.querySelector(selector);
      if (!stage || !stage.parentElement) return;
      ScrollTrigger.create({
        trigger: stage.parentElement,
        start: 'top top',
        end: 'bottom bottom',
        pin: stage,
        pinSpacing: false,
        // pre-applies the pin transform one frame early: kills the visible
        // one-frame jump when the pin engages during fast scrolling
        anticipatePin: 1
      });
    });

    // Anchor links: route same-page hash navigation through the smoother so
    // clicks, browser back/forward and page loads with a hash all line up.
    function scrollToHash(hash, instant) {
      if (!hash || hash === '#') return false;
      var target;
      try { target = document.querySelector(hash); } catch (err) { return false; }
      if (!target) return false;
      motion.smoother.scrollTo(target, !instant);
      return true;
    }

    document.addEventListener('click', function (e) {
      if (e.defaultPrevented || e.button > 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      var link = e.target.closest('a[href*="#"]');
      if (!link || link.target === '_blank' || link.hasAttribute('download')) return;
      var url = new URL(link.href, window.location.href);
      if (url.pathname !== window.location.pathname || url.origin !== window.location.origin) return;
      if (scrollToHash(url.hash)) {
        e.preventDefault();
        if (url.hash !== window.location.hash) history.pushState(null, '', url.hash);
      }
    }, { signal: motion.abort.signal });

    window.addEventListener('popstate', function () {
      scrollToHash(window.location.hash);
    }, { signal: motion.abort.signal });

    if (window.location.hash) {
      ScrollTrigger.refresh();
      scrollToHash(window.location.hash, true);
    }

    /* NOTE: no per-image ScrollTrigger.refresh() here. Images are eager-loaded,
       so the window 'load' refresh in index.js already runs after every image
       is complete (while the curtain intro still covers the page). A refresh
       fired mid-scroll would snap `once: true` entrance animations straight to
       their end state — the section would appear with no animation at all. */
  });
})();
