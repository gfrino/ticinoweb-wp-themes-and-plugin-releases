(function () {
  'use strict';
  window.IdeaMotion.register(function (motion) {
    var gsap = motion.gsap;
    var selector = [
      '.idea-editorial__image', '.idea-service-detail__image',
      '.idea-product-card__image',
      '.idea-map-placeholder'
    ].join(',');
    var frames = gsap.utils.toArray(selector);
    var masks = ['inset(0 100% 0 0)', 'inset(0 0 0 100%)', 'inset(100% 0 0 0)', 'inset(0 48% 0 48%)'];
    motion.media.add({ desktop: '(min-width: 1025px)', compact: '(max-width: 1024px)' }, function (context) {
      frames.forEach(function (frame, index) {
        var image = frame.querySelector('img, .idea-placeholder');
        var startMask = context.conditions.desktop ? masks[index % masks.length] : (index % 2 ? 'inset(0 0 0 18%)' : 'inset(0 18% 0 0)');
        var reveal = gsap.timeline({ scrollTrigger: { trigger: frame, start: 'top 90%', once: true } });
        reveal.fromTo(frame, { clipPath: startMask, borderRadius: '28px' }, {
          clipPath: 'inset(0% 0% 0% 0%)', borderRadius: index % 3 ? '16px' : '24px',
          duration: context.conditions.desktop ? .95 : .52, ease: motion.config.easeSoft
        });
        if (image) {
          reveal.fromTo(image, { scale: context.conditions.desktop ? 1.1 : 1.04 }, {
            scale: 1, duration: context.conditions.desktop ? 1.25 : .6, ease: motion.config.easeSoft
          }, 0);
          if (context.conditions.desktop) gsap.fromTo(image, { yPercent: -motion.config.parallax * .35 }, { yPercent: motion.config.parallax * .35, ease: 'none', scrollTrigger: { trigger: frame, start: 'top bottom', end: 'bottom top', scrub: 1.2 } });
        }
      });
    });
  });
})();
