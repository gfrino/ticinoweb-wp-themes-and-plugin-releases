/** Central motion registry and shared settings. */
(function () {
  'use strict';
  var defaults = {
    desktopBreakpoint: 1025,
    easeSoft: 'power3.out',
    easeCinematic: 'power3.inOut',
    scrubSoft: 1.1,
    parallax: 8,
    textTravel: 22,
    pageTransitions: true
  };
  var options = Object.assign({}, defaults, window.idealuganoMotion || {});
  window.IdeaMotion = {
    config: options,
    gsap: window.gsap,
    ScrollTrigger: window.ScrollTrigger,
    reduced: window.matchMedia('(prefers-reduced-motion: reduce)').matches,
    touch: window.matchMedia('(hover: none), (pointer: coarse)').matches,
    abort: new AbortController(),
    initializers: [],
    register: function (initializer) { this.initializers.push(initializer); },
    reveal: function (elements) {
      Array.prototype.forEach.call(elements || [], function (element) { element.classList.add('visible'); });
    }
  };
})();
