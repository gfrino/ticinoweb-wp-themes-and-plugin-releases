(function () {
  'use strict';
  window.IdeaMotion.register(function (motion) {
    var gsap = motion.gsap;
    var hero = document.querySelector('.idea-hero');
    if (!hero) return;
    var lines = hero.querySelectorAll('.idea-split-title__line');
    var title = hero.querySelector('.idea-hero__title');
    var bg = hero.querySelector('.idea-hero__bg');
    var image = hero.querySelector('.idea-hero__bg-img');
    var overlay = hero.querySelector('.idea-hero__overlay');
    var goldLine = hero.querySelector('.idea-hero__gold-line');
    var subtitle = hero.querySelector('.idea-hero__subtitle');
    var buttons = hero.querySelector('.idea-hero__buttons');
    var indicator = hero.querySelector('.idea-hero__scroll');

    // Dynamically wrap line contents to isolate entrance yPercent from scrollTrigger xPercent transforms
    var lineInners = [];
    lines.forEach(function (line) {
      var inner = document.createElement('span');
      inner.style.display = 'block';
      inner.innerHTML = line.innerHTML;
      line.innerHTML = '';
      line.appendChild(inner);
      lineInners.push(inner);
    });

    function enter() {
      if (hero.dataset.motionEntered) return;
      hero.dataset.motionEntered = 'true';
      gsap.timeline({ defaults: { ease: motion.config.easeSoft } })
        .fromTo(image, { scale: 1.09 }, { scale: 1, duration: 3 }, 0)
        .fromTo(title, { y: 24, opacity: 0 }, { y: 0, opacity: 1, duration: .5 }, .08)
        .fromTo(lineInners, { yPercent: 115 }, { yPercent: 0, duration: 1.05, stagger: .16 }, .12)
        .fromTo(goldLine, { width: 0 }, { width: 100, duration: .85, ease: motion.config.easeCinematic }, .5)
        .fromTo(subtitle, { y: 28, opacity: 0 }, { y: 0, opacity: 1, duration: .8 }, .62)
        .fromTo(buttons, { y: 24, opacity: 0 }, { y: 0, opacity: 1, duration: .72 }, .83)
        .fromTo(indicator, { opacity: 0, y: 15 }, { opacity: 1, y: 0, duration: .6 }, 1.05);
    }
    if (hero.classList.contains('loaded')) enter();
    else new MutationObserver(function (_, observer) {
      if (hero.classList.contains('loaded')) { enter(); observer.disconnect(); }
    }).observe(hero, { attributes: true, attributeFilter: ['class'] });

    if (!motion.touch) {
      motion.media.add({ desktop: '(min-width: 1025px)', compact: '(max-width: 1024px)' }, function (context) {
        var desktop = context.conditions.desktop;
        var timeline = gsap.timeline({
          scrollTrigger: {
            trigger: hero,
            start: 'top top',
            end: 'bottom top',
            scrub: desktop ? motion.config.scrubSoft : .55
          }
        });
        timeline
          .to(bg, { scale: desktop ? 1.1 : 1.045, yPercent: desktop ? motion.config.parallax * .6 : 0, ease: 'none' }, 0)
          .to(overlay, { backgroundColor: desktop ? 'rgba(5,45,58,.68)' : 'rgba(5,45,58,.56)', ease: 'none' }, 0);
        if (desktop && lines.length > 1) {
          timeline
            .to(lines[0], { xPercent: -18, opacity: .34, ease: 'none' }, 0)
            .to(lines[1], { xPercent: 18, opacity: .34, ease: 'none' }, 0);
        }
      });
    }
  });
})();
