/**
 * Contact Form — validazione client e invio al gestore AJAX del parent
 * (ticinoweb-ai-theme/inc/form-handler.php). Niente più fallback mailto:
 * se l'invio fallisce l'utente vede l'errore e può riprovare.
 *
 * @package Idealugano
 * @version 2.1.0
 */
(function () {
  'use strict';

  var form = document.getElementById('idea-contact-form');
  if (!form) return;

  var cfg = window.ticinoweb_ai_main || {};
  var nameInput = document.getElementById('idea-name');
  var emailInput = document.getElementById('idea-email');
  var messageInput = document.getElementById('idea-message');
  var submitBtn = document.getElementById('idea-submit');
  var successMsg = document.getElementById('idea-form-success');
  var failMsg = document.getElementById('idea-form-fail');

  var nameError = document.getElementById('idea-name-error');
  var emailError = document.getElementById('idea-email-error');
  var messageError = document.getElementById('idea-message-error');
  var submitLabel = submitBtn ? submitBtn.textContent : '';

  function validateEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }
  function showError(input, errorEl, text) {
    if (input) input.classList.add('error');
    if (errorEl) {
      if (text) errorEl.textContent = text;
      errorEl.classList.add('visible');
    }
  }
  function clearError(input, errorEl) {
    if (input) input.classList.remove('error');
    if (errorEl) errorEl.classList.remove('visible');
  }
  function showFail(text) {
    if (!failMsg) return;
    failMsg.textContent = text || 'Invio non riuscito. Riprova tra qualche istante oppure scrivici via email.';
    failMsg.classList.add('visible');
  }
  function setBusy(busy) {
    if (!submitBtn) return;
    submitBtn.disabled = busy;
    submitBtn.textContent = busy ? 'Invio in corso…' : submitLabel;
  }

  if (nameInput) nameInput.addEventListener('blur', function () {
    if (!this.value.trim()) showError(this, nameError); else clearError(this, nameError);
  });
  if (emailInput) emailInput.addEventListener('blur', function () {
    if (!validateEmail(this.value.trim())) showError(this, emailError); else clearError(this, emailError);
  });
  if (messageInput) messageInput.addEventListener('blur', function () {
    if (!this.value.trim()) showError(this, messageError); else clearError(this, messageError);
  });

  /* reCAPTCHA v3: caricato solo se il sito ha una site key, e solo al primo focus sul form. */
  var recaptchaReady = null;
  function loadRecaptcha() {
    if (recaptchaReady || !cfg.recaptcha_site_key) return;
    recaptchaReady = new Promise(function (resolve) {
      var s = document.createElement('script');
      s.src = 'https://www.google.com/recaptcha/api.js?render=' + encodeURIComponent(cfg.recaptcha_site_key);
      s.async = true;
      s.onload = resolve;
      s.onerror = resolve;
      document.head.appendChild(s);
    });
  }
  form.addEventListener('focusin', loadRecaptcha, { once: true });

  function getRecaptchaToken() {
    if (!cfg.recaptcha_site_key) return Promise.resolve('');
    loadRecaptcha();
    return recaptchaReady.then(function () {
      if (!window.grecaptcha || !grecaptcha.execute) return '';
      return new Promise(function (resolve) {
        grecaptcha.ready(function () {
          grecaptcha.execute(cfg.recaptcha_site_key, { action: 'contact' }).then(resolve, function () { resolve(''); });
        });
      });
    });
  }

  function getToken() {
    return fetch(cfg.ajax_url + '?action=' + encodeURIComponent(cfg.token_action || 'ticinoweb_form_token'), {
      credentials: 'same-origin',
      cache: 'no-store'
    }).then(function (r) { return r.json(); }).then(function (d) {
      return d && d.success && d.data ? d.data.token : '';
    });
  }


  /* Foto facoltative: anteprime, rimozione, ridimensionamento prima dell'invio. */
  var MAX_PHOTOS = 5;
  var photoInput = document.getElementById('idea-photos');
  var photoList = document.getElementById('idea-photos-list');
  var photoText = document.getElementById('idea-photos-text');
  var photoError = document.getElementById('idea-photos-error');
  var photoDefaultText = photoText ? photoText.textContent : '';
  var photos = [];

  function photoMsg(text) {
    if (!photoError) return;
    photoError.textContent = text || '';
    photoError.classList.toggle('visible', !!text);
  }
  function renderPhotos() {
    if (!photoList) return;
    photoList.innerHTML = '';
    photos.forEach(function (file, i) {
      var li = document.createElement('li');
      var img = document.createElement('img');
      img.alt = file.name;
      img.src = URL.createObjectURL(file);
      img.onload = function () { URL.revokeObjectURL(img.src); };
      img.onerror = function () { img.remove(); li.classList.add('idea-form__thumb--generic'); };
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.setAttribute('aria-label', 'Rimuovi ' + file.name);
      btn.textContent = '×';
      btn.addEventListener('click', function () { photos.splice(i, 1); photoMsg(''); renderPhotos(); });
      li.appendChild(img);
      li.appendChild(btn);
      photoList.appendChild(li);
    });
    if (photoText) {
      photoText.textContent = photos.length
        ? photos.length + (photos.length === 1 ? ' foto selezionata' : ' foto selezionate') + (photos.length < MAX_PHOTOS ? ' · aggiungine un’altra' : '')
        : photoDefaultText;
    }
  }
  if (photoInput) photoInput.addEventListener('change', function () {
    var added = Array.prototype.slice.call(photoInput.files);
    photoInput.value = '';
    photoMsg('');
    added.forEach(function (f) {
      if (f.type && f.type.indexOf('image/') !== 0) { photoMsg('Puoi allegare solo foto.'); return; }
      if (photos.length >= MAX_PHOTOS) { photoMsg('Puoi allegare al massimo ' + MAX_PHOTOS + ' foto.'); return; }
      photos.push(f);
    });
    renderPhotos();
  });

  /* Riduce a max 1800 px e JPEG: una foto da telefono passa da ~6 MB a ~400 KB. Se il browser non sa leggerla, si invia l'originale. */
  function shrinkPhoto(file) {
    return new Promise(function (resolve) {
      if (file.size < 600 * 1024 && /^image\/(jpeg|png|webp)$/.test(file.type)) { resolve(file); return; }
      var img = new Image();
      var url = URL.createObjectURL(file);
      img.onload = function () {
        var max = 1800, w = img.naturalWidth, h = img.naturalHeight, k = Math.min(1, max / Math.max(w, h));
        var c = document.createElement('canvas');
        c.width = Math.round(w * k); c.height = Math.round(h * k);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        URL.revokeObjectURL(url);
        c.toBlob(function (blob) { resolve(blob && blob.size < file.size ? blob : file); }, 'image/jpeg', 0.85);
      };
      img.onerror = function () { URL.revokeObjectURL(url); resolve(file); };
      img.src = url;
    });
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    if (failMsg) failMsg.classList.remove('visible');
    var valid = true;

    if (!nameInput || !nameInput.value.trim()) { showError(nameInput, nameError); valid = false; } else clearError(nameInput, nameError);
    if (!emailInput || !validateEmail(emailInput.value.trim())) { showError(emailInput, emailError); valid = false; } else clearError(emailInput, emailError);
    if (!messageInput || !messageInput.value.trim()) { showError(messageInput, messageError); valid = false; } else clearError(messageInput, messageError);
    if (!valid) return;

    if (!cfg.ajax_url) {
      showFail('Il modulo non è disponibile al momento. Scrivici via email o chiamaci.');
      return;
    }

    setBusy(true);
    Promise.all([getToken(), getRecaptchaToken(), Promise.all(photos.map(shrinkPhoto))]).then(function (tokens) {
      var formData = new FormData(form);
      tokens[2].forEach(function (blob, i) {
        var base = (photos[i].name || 'foto').replace(/\.[^.]+$/, '');
        formData.append('foto[]', blob, base + (blob === photos[i] ? (photos[i].name.match(/\.[^.]+$/) || [''])[0] : '.jpg'));
      });
      formData.append('action', cfg.submit_action || 'ticinoweb_submit_form');
      formData.append('token', tokens[0]);
      if (tokens[1]) formData.append('recaptcha_token', tokens[1]);

      return fetch(cfg.ajax_url, { method: 'POST', body: formData, credentials: 'same-origin' })
        .then(function (res) { return res.json().then(function (data) { return { ok: res.ok, data: data }; }); });
    }).then(function (result) {
      var data = result.data || {};
      if (data.success) {
        form.reset();
        photos = [];
        renderPhotos();
        form.style.display = 'none';
        if (successMsg) {
          if (data.data && data.data.message) successMsg.textContent = data.data.message;
          successMsg.classList.add('visible');
          successMsg.focus && successMsg.focus();
        }
        return;
      }
      var err = data.data || {};
      if (err.fields) {
        if (err.fields.nome) showError(nameInput, nameError, err.fields.nome);
        if (err.fields.email) showError(emailInput, emailError, err.fields.email);
        if (err.fields.messaggio) showError(messageInput, messageError, err.fields.messaggio);
      }
      showFail(err.message);
    }).catch(function () {
      showFail();
    }).then(function () {
      setBusy(false);
    });
  });
})();
