/**
 * Before/After Slider — Draggable comparison slider
 *
 * @package Idealugano
 * @version 1.0.0
 */
(function () {
  'use strict';

  var sliders = document.querySelectorAll('.idea-ba-slider');

  sliders.forEach(function (slider) {
    var handle = slider.querySelector('.idea-ba-slider__handle');
    var afterLayer = slider.querySelector('.idea-ba-slider__after');
    if (!handle || !afterLayer) return;

    var isDragging = false;

    function getPosition(e) {
      var rect = slider.getBoundingClientRect();
      var x = e.clientX - rect.left;
      return Math.max(0, Math.min(x / rect.width * 100, 100));
    }

    function updateSlider(percent) {
      handle.style.left = percent + '%';
      afterLayer.style.clipPath = 'inset(0 0 0 ' + percent + '%)';
      slider.setAttribute('aria-valuenow', Math.round(percent));
    }

    function onStart(e) {
      isDragging = true;
      slider.style.cursor = 'col-resize';
      updateSlider(getPosition(e));
      if (slider.setPointerCapture) slider.setPointerCapture(e.pointerId);
      if (e.pointerType === 'mouse') e.preventDefault();
    }

    function onMove(e) {
      if (!isDragging) return;
      updateSlider(getPosition(e));
      if (e.pointerType === 'mouse') e.preventDefault();
    }

    function onEnd(e) {
      isDragging = false;
      slider.style.cursor = 'col-resize';
      if (e && slider.hasPointerCapture && slider.hasPointerCapture(e.pointerId)) {
        slider.releasePointerCapture(e.pointerId);
      }
    }

    // Pointer Events cover mouse, pen and touch. CSS touch-action: pan-y keeps
    // vertical page scrolling native while horizontal comparison stays usable.
    slider.addEventListener('pointerdown', onStart);
    slider.addEventListener('pointermove', onMove);
    slider.addEventListener('pointerup', onEnd);
    slider.addEventListener('pointercancel', onEnd);

    // Keyboard accessibility
    slider.addEventListener('keydown', function (e) {
      var current = parseFloat(handle.style.left) || 50;
      var step = 2;
      if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') {
        updateSlider(Math.max(0, current - step));
        e.preventDefault();
      } else if (e.key === 'ArrowRight' || e.key === 'ArrowUp') {
        updateSlider(Math.min(100, current + step));
        e.preventDefault();
      }
    });
  });

  document.querySelectorAll('.idea-ba-carousel').forEach(function (carousel) {
    var projects = Array.prototype.slice.call(carousel.querySelectorAll('.idea-ba-project'));
    var previous = carousel.querySelector('.idea-ba-carousel__arrow--prev');
    var next = carousel.querySelector('.idea-ba-carousel__arrow--next');
    var status = carousel.querySelector('.idea-ba-carousel__status');
    var current = 0;
    if (projects.length < 2) return;

    function centerArrows() {
      var slider = projects[current].querySelector('.idea-ba-slider');
      if (!slider) return;
      var center = slider.offsetTop + (slider.offsetHeight / 2);
      previous.style.top = center + 'px';
      next.style.top = center + 'px';
    }

    function show(index) {
      current = (index + projects.length) % projects.length;
      projects.forEach(function (project, projectIndex) {
        var active = projectIndex === current;
        project.hidden = !active;
        project.classList.toggle('is-active', active);
      });
      if (status) status.textContent = (current + 1) + ' / ' + projects.length;
      centerArrows();
      document.dispatchEvent(new CustomEvent('idealugano:layoutchange'));
    }

    previous.addEventListener('click', function () { show(current - 1); });
    next.addEventListener('click', function () { show(current + 1); });
    window.addEventListener('resize', centerArrows);
    centerArrows();
  });
})();
