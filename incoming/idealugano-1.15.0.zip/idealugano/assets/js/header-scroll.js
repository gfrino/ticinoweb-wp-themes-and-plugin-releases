/**
 * Header scroll effect — transparent to blur/opaque
 *
 * @package Idealugano
 * @version 1.0.0
 */
(function () {
  'use strict';

  var header = document.querySelector('.idea-header');
  if (!header) return;

  var scrollThreshold = 80;
  var ticking = false;

  function updateHeader() {
    if (window.scrollY > scrollThreshold) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }
    ticking = false;
  }

  window.addEventListener('scroll', function () {
    if (!ticking) {
      requestAnimationFrame(updateHeader);
      ticking = true;
    }
  }, { passive: true });

  // Initial check
  updateHeader();

  window.addEventListener('pageshow', function (event) {
    if (event.persisted) {
      updateHeader();
    }
  });
})();
