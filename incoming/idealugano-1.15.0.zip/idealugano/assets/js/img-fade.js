/**
 * Image fade-in safety net.
 *
 * Images are eager-loaded (no loading="lazy"), so normally everything is ready
 * before the user scrolls. On slow connections an image may still arrive late:
 * instead of painting progressively in front of the user, it stays invisible
 * and fades in smoothly once fully loaded.
 *
 * @package Idealugano
 */
(function () {
  'use strict';

  var imgs = document.querySelectorAll('.site-main img, .idea-footer img');

  Array.prototype.forEach.call(imgs, function (img) {
    if (img.complete) return; // already painted — leave it alone

    img.classList.add('idea-img-pending');

    function reveal() {
      // One-shot inline transition, then clean up so GSAP keeps full control
      img.style.transition = 'opacity 0.45s ease';
      requestAnimationFrame(function () {
        img.classList.remove('idea-img-pending');
      });
      setTimeout(function () {
        img.style.transition = '';
      }, 600);
    }

    img.addEventListener('load', reveal, { once: true });
    img.addEventListener('error', reveal, { once: true });
  });
})();
