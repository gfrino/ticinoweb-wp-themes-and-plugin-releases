/**
 * Curtain Intro — Live sheer-fabric simulation
 *
 * The two curtain halves are SVG paths redrawn every frame:
 *  - the inner (leading) edge is a layered sine wave, so it undulates like hanging fabric
 *  - the wave amplitude grows toward the bottom (fabric is fixed to the rail at the top)
 *  - vertical pleats are drawn as wavy highlight/shadow ribbons; as the curtain is
 *    drawn open the pleats compress together, like real fabric gathering on a rail
 *  - during the opening motion the fabric billows (amplitude swells mid-motion, then settles)
 *  - fills are semi-transparent so the site underneath shows through the fabric
 *
 * Timeline: idle sway (~1s) -> draw open (~1.9s, eased) -> hold logo -> fade overlay
 *
 * @package Idealugano
 * @version 1.10.0
 */
(function () {
  'use strict';

  var overlay = document.getElementById('curtain-overlay');
  var skipBtn = document.getElementById('curtain-skip');
  var svg = document.getElementById('curtain-svg');
  var hero = document.querySelector('.idea-hero');
  var logo = document.getElementById('curtain-logo');
  var motionConfig = window.idealuganoMotion || {};

  function unlockPage() {
    document.documentElement.classList.remove('curtain-active');
    document.body.classList.remove('curtain-active');
  }

  // No overlay? Show hero immediately
  if (!overlay || !svg) {
    unlockPage();
    if (hero) hero.classList.add('loaded');
    return;
  }

  if (motionConfig.curtainIntro === false) {
    overlay.remove();
    unlockPage();
    if (hero) hero.classList.add('loaded');
    return;
  }

  // Lock scrolling
  document.documentElement.classList.add('curtain-active');
  document.body.classList.add('curtain-active');

  var prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  // The fabric intro plays once per browser session: on the next visit to the
  // home in the same tab it falls back to the short fade (saves ~2s and CPU).
  var seenThisSession = false;
  try {
    seenThisSession = sessionStorage.getItem('idealuganoIntroSeen') === '1';
    sessionStorage.setItem('idealuganoIntroSeen', '1');
  } catch (error) {}
  if (seenThisSession) prefersReduced = true;
  var compactDevice = window.matchMedia('(max-width: 767px), (pointer: coarse)').matches;

  /* ── Geometry (viewBox units, preserveAspectRatio="none" stretches to viewport) ── */
  var W = 1000;
  var H = 700;
  var SAMPLES = compactDevice ? 14 : 22; // lower mobile paint cost
  var PLEATS = compactDevice ? 4 : 6;
  var CLOSED_X = 505;        // inner edge when closed (small overlap at center)
  var OPEN_X = 26;           // fabric bundle width when fully gathered

  var IDLE_MS = compactDevice ? 240 : 500;
  var OPEN_MS = compactDevice ? 1100 : 1750;
  var HOLD_MS = compactDevice ? 100 : 250;
  var FADE_REMOVE_MS = compactDevice ? 420 : 600;

  var NS = 'http://www.w3.org/2000/svg';

  /* Build the path elements once per curtain: body + fold shadows + pleats + edge band.
     All soft edges come from gradient fills — no SVG filters, so redrawing the
     paths every frame stays cheap (feGaussianBlur would re-render per frame). */
  function buildCurtain(groupId, bodyFill) {
    var group = document.getElementById(groupId);
    var els = { body: null, edge: null, pleats: [], shadows: [] };

    els.body = document.createElementNS(NS, 'path');
    els.body.setAttribute('fill', bodyFill);
    group.appendChild(els.body);

    // Soft shadows cast by the folds onto the fabric — feathered via gradient
    for (var s = 0; s < PLEATS; s++) {
      var sh = document.createElementNS(NS, 'path');
      sh.setAttribute('fill', 'url(#foldShadowGrad)');
      group.appendChild(sh);
      els.shadows.push(sh);
    }

    for (var i = 0; i < PLEATS; i++) {
      var p = document.createElementNS(NS, 'path');
      // Alternate highlight / shadow ribbons, both fading out at their edges
      p.setAttribute('fill', i % 2 === 0 ? 'url(#pleatHiGrad)' : 'url(#pleatLoGrad)');
      group.appendChild(p);
      els.pleats.push(p);
    }

    // Leading-edge band: whisper of deeper petrol along the hem
    els.edge = document.createElementNS(NS, 'path');
    els.edge.setAttribute('fill', 'url(#edgeBandGrad)');
    group.appendChild(els.edge);

    return els;
  }

  var leftC = buildCurtain('curtain-left-group', 'url(#curtainBodyL)');
  var rightC = buildCurtain('curtain-right-group', 'url(#curtainBodyR)');

  // Frosted-glass layers (backdrop blur), clipped per-frame to the fabric shape
  leftC.blur = document.getElementById('curtain-blur-left');
  rightC.blur = document.getElementById('curtain-blur-right');

  /* ── Easing: slow fabric start, long glide, soft settle ── */
  function easeInOutQuart(t) {
    return t < 0.5 ? 8 * t * t * t * t : 1 - Math.pow(-2 * t + 2, 4) / 2;
  }

  /*
   * Inner-edge x offset at height y (0..H), time t (s).
   * Two superimposed sine waves; amplitude grows toward the bottom hem
   * and swells while the curtain is moving (billow), then calms down.
   */
  function waveOffset(y, t, phase, billow) {
    var vertical = 0.12 + 0.88 * Math.pow(y / H, 1.4); // pinned at rail, free at hem
    var amp = (7 + 15 * billow) * vertical;
    return amp * Math.sin(y * 0.011 + t * 1.9 + phase)
         + amp * 0.45 * Math.sin(y * 0.027 - t * 2.7 + phase * 1.7);
  }

  /* Build an "M x0,y0 L ..." polyline segment from a points array */
  function seg(pts) {
    var d = 'M' + pts[0][0].toFixed(1) + ',' + pts[0][1].toFixed(1);
    for (var i = 1; i < pts.length; i++) {
      d += 'L' + pts[i][0].toFixed(1) + ',' + pts[i][1].toFixed(1);
    }
    return d;
  }

  /*
   * Redraw one curtain.
   * side: -1 = left (anchored at x=0), +1 = right (anchored at x=W)
   * open: 0 closed .. 1 fully gathered
   * updateBlur: the backdrop-blur clip is refreshed every other frame only —
   *             re-blurring the backdrop is the most expensive step and 30fps
   *             on the clip edge is visually indistinguishable.
   */
  function drawCurtain(els, side, t, open, billow, updateBlur) {
    var width = CLOSED_X - (CLOSED_X - OPEN_X) * open; // current fabric span
    var i, y, x;

    // Mirror x numerically for the right curtain (no string post-processing)
    function mx(v) { return side < 0 ? v : W - v; }

    // Inner (leading) edge points, top to bottom (already mirrored)
    var edgePts = [];
    var raw = [];
    for (i = 0; i <= SAMPLES; i++) {
      y = (H * i) / SAMPLES;
      x = width + waveOffset(y, t, side * 1.3, billow);
      raw.push([x, y]);
      edgePts.push([mx(x), y]);
    }

    // Body: outer edge -> along top -> wavy inner edge down -> back along bottom
    var d = 'M' + mx(0) + ',0 L' + edgePts[0][0].toFixed(1) + ',0 ';
    for (i = 1; i <= SAMPLES; i++) {
      d += 'L' + edgePts[i][0].toFixed(1) + ',' + edgePts[i][1].toFixed(1);
    }
    d += 'L' + mx(0) + ',' + H + ' Z';
    els.body.setAttribute('d', d);

    // Leading-edge band: ribbon hugging the inner edge (deeper when closed)
    var bandW = 10 - 5 * open;
    var pts = [];
    var back = [];
    for (i = 0; i <= SAMPLES; i++) pts.push([mx(raw[i][0] - bandW), raw[i][1]]);
    for (i = SAMPLES; i >= 0; i--) back.push(edgePts[i]);
    els.edge.setAttribute('d', seg(pts.concat(back)) + ' Z');

    // Pleats: ribbons at fixed fractions of the current span -> they compress as it gathers
    for (var k = 0; k < PLEATS; k++) {
      var frac = (k + 1) / (PLEATS + 1);
      var pw = width * 0.022 * (1 + 0.35 * Math.sin(t * 1.6 + k * 2.1)); // breathing pleat width
      var fPts = [];
      var bPts = [];
      var sF = [];
      var sB = [];
      for (i = 0; i <= SAMPLES; i++) {
        y = (H * i) / SAMPLES;
        // Each pleat has its own wave phase and a slightly smaller amplitude
        x = width * frac + 0.6 * waveOffset(y, t, side * 1.3 + k * 1.15, billow);
        fPts.push([mx(x - pw), y]);
        bPts.push([mx(x + pw), y]);
        // Shadow cast beside the fold — wider than before since the gradient
        // feathers within the ribbon instead of bleeding past it like a blur
        sF.push([mx(x + pw * 0.2), y]);
        sB.push([mx(x + pw * 3.2), y]);
      }
      bPts.reverse();
      sB.reverse();
      els.pleats[k].setAttribute('d', seg(fPts.concat(bPts)) + ' Z');
      els.shadows[k].setAttribute('d', seg(sF.concat(sB)) + ' Z');
      // Pleats and their shadows deepen gently as the fabric bunches together
      els.pleats[k].setAttribute('opacity', (0.4 + 0.35 * open).toFixed(2));
      els.shadows[k].setAttribute('opacity', (0.45 + 0.4 * open).toFixed(2));
    }

    // Frosted glass: clip the backdrop-blur layer to the same wavy fabric shape.
    // Every 2nd edge point is plenty for the clip outline.
    if (els.blur && updateBlur) {
      var poly = side < 0 ? '0% 0%' : '100% 0%';
      for (i = 0; i <= SAMPLES; i += 2) {
        var px = (raw[i][0] / W) * 100;
        if (side > 0) px = 100 - px;
        poly += ',' + px.toFixed(2) + '% ' + ((raw[i][1] / H) * 100).toFixed(2) + '%';
      }
      poly += side < 0 ? ',0% 100%' : ',100% 100%';
      var clip = 'polygon(' + poly + ')';
      els.blur.style.clipPath = clip;
      els.blur.style.webkitClipPath = clip;
    }
  }

  /* ── Animation loop ── */
  var startTime = null;
  var openStart = null;   // set when opening begins (idle elapsed or skip pressed)
  var finished = false;
  var rendering = true;   // false once the overlay starts fading out
  var rafId = null;
  var heroStarted = false;
  var frameCount = 0;

  function frame(now) {
    if (startTime === null) startTime = now;
    var t = (now - startTime) / 1000; // seconds, drives the waves
    frameCount++;

    var open = 0;
    var billow = 0;
    if (openStart !== null) {
      var p = Math.min((now - openStart) / OPEN_MS, 1);
      open = easeInOutQuart(p);
      billow = Math.sin(p * Math.PI); // swells mid-motion, settles at the end
      if (p >= 1 && !finished) finish();
    } else if (now - startTime >= IDLE_MS) {
      openStart = now;
    }

    var updateBlur = frameCount % 2 === 0;
    drawCurtain(leftC, -1, t, open, billow, updateBlur);
    drawCurtain(rightC, +1, t, open, billow, updateBlur);

    if (logo) {
      var idleReveal = Math.min((now - startTime) / IDLE_MS, 1);
      logo.style.opacity = Math.min(1, .08 + idleReveal * .32 + open * .6).toFixed(2);
      logo.style.transform = 'scale(' + (.94 + open * .06).toFixed(3) + ')';
    }

    if (!heroStarted && open >= .62) {
      heroStarted = true;
      if (hero) hero.classList.add('loaded');
    }

    // Scrim thins out with the fabric
    if (openStart !== null && scrim) {
      scrim.style.opacity = (1 - open).toFixed(2);
    }

    if (rendering && overlay.parentNode) {
      rafId = requestAnimationFrame(frame);
    }
  }

  var scrim = document.getElementById('curtain-scrim');

  /* Freeze the fabric simulation: once the overlay only fades out, there is
     no reason to keep repainting the SVG and re-blurring the backdrop. */
  function stopRendering() {
    rendering = false;
    if (rafId) cancelAnimationFrame(rafId);
  }

  function finish() {
    if (finished) return;
    finished = true;
    // Let the logo breathe with the fabric settled, then fade the overlay out
    setTimeout(function () {
      overlay.classList.add('done');
      stopRendering();
      if (hero) hero.classList.add('loaded');
      setTimeout(function () {
        unlockPage();
        if (overlay.parentNode) overlay.remove();
      }, FADE_REMOVE_MS);
    }, HOLD_MS);
  }

  function skip() {
    if (finished) return;
    finished = true;
    overlay.classList.add('done');
    stopRendering();
    if (hero) hero.classList.add('loaded');
    setTimeout(function () {
      unlockPage();
      if (overlay.parentNode) overlay.remove();
    }, FADE_REMOVE_MS);
  }

  if (prefersReduced) {
    // No fabric simulation — static scrim + logo, simple fade
    overlay.classList.add('reduced');
    setTimeout(skip, 500);
  } else {
    rafId = requestAnimationFrame(frame);
  }

  if (skipBtn) skipBtn.addEventListener('click', skip);
  document.addEventListener('keydown', function handler(e) {
    if (e.key === 'Escape' || e.key === 'Enter') {
      skip();
      document.removeEventListener('keydown', handler);
    }
  });

  // Safety fallback: force the site visible after 7s max
  setTimeout(function () {
    if (hero && !hero.classList.contains('loaded')) hero.classList.add('loaded');
    if (overlay && overlay.parentNode) {
      overlay.classList.add('done');
      stopRendering();
      setTimeout(function () {
        unlockPage();
        if (overlay.parentNode) overlay.remove();
      }, 1000);
    } else {
      unlockPage();
    }
  }, 7000);
})();
