/**
 * Admin Image Manager — Media Library Integration
 *
 * @package Idealugano
 * @version 1.4.0
 */
(function ($) {
  'use strict';

  var config = window.idealuganoAdmin || {};

  /**
   * Show a toast notification on a card
   */
  function showToast(card, message, type) {
    var toast = card.find('.idealugano-image-card__toast');
    toast.text(message).removeClass('success error').addClass(type + ' show');
    setTimeout(function () {
      toast.removeClass('show');
    }, 2000);
  }

  /**
   * Save image via AJAX
   */
  function saveImage(slot, attachmentId, card) {
    $.ajax({
      url: config.ajaxUrl,
      type: 'POST',
      data: {
        action: 'idealugano_save_image',
        nonce: config.nonce,
        slot: slot,
        attachment_id: attachmentId,
      },
      success: function (response) {
        if (response.success) {
          showToast(card, config.i18n.saved, 'success');

          if (attachmentId > 0 && response.data.url) {
            // Update card with new image
            card.addClass('has-image');
            card.attr('data-attachment-id', attachmentId);
            card.find('.idealugano-image-card__preview').html(
              '<img src="' + response.data.url + '" alt="">'
            );
            // Update buttons
            card.find('.idealugano-image-card__btn--select').html(
              '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg> Sostituisci'
            );
            // Add remove button if missing
            if (card.find('.idealugano-image-card__btn--remove').length === 0) {
              card.find('.idealugano-image-card__actions').append(
                '<button class="idealugano-image-card__btn idealugano-image-card__btn--remove" type="button">' +
                  '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg> ' +
                  'Rimuovi</button>'
              );
            }
          } else {
            // Removed image
            card.removeClass('has-image');
            card.attr('data-attachment-id', '0');
            card.find('.idealugano-image-card__preview').html(
              '<div class="idealugano-image-card__empty">' +
                '<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">' +
                  '<rect x="3" y="3" width="18" height="18" rx="2"/>' +
                  '<circle cx="8.5" cy="8.5" r="1.5"/>' +
                  '<path d="M21 15l-5-5L5 21"/>' +
                '</svg>' +
                '<span>Clicca per aggiungere</span>' +
              '</div>'
            );
            card.find('.idealugano-image-card__btn--select').html(
              '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg> Carica'
            );
            card.find('.idealugano-image-card__btn--remove').remove();
          }

          // Update section count
          updateSectionCount(card.closest('.idealugano-admin-section'));
        } else {
          showToast(card, config.i18n.error, 'error');
        }
      },
      error: function () {
        showToast(card, config.i18n.error, 'error');
      },
    });
  }

  /**
   * Update the filled/total count badge
   */
  function updateSectionCount(section) {
    var total = section.find('.idealugano-image-card').length;
    var filled = section.find('.idealugano-image-card.has-image').length;
    section.find('.idealugano-admin-section__count').text(filled + '/' + total);
  }

  /**
   * Open WP Media Library for a slot
   */
  function openMediaLibrary(card) {
    var slot = card.data('slot');
    var currentId = card.data('attachment-id') || 0;

    var frame = wp.media({
      title: config.i18n.selectImage,
      button: { text: config.i18n.useImage },
      multiple: false,
      library: { type: 'image' },
    });

    frame.on('select', function () {
      var attachment = frame.state().get('selection').first().toJSON();
      saveImage(slot, attachment.id, card);
    });

    // Pre-select current image if exists
    frame.on('open', function () {
      if (currentId > 0) {
        var selection = frame.state().get('selection');
        var attachment = wp.media.attachment(currentId);
        attachment.fetch();
        selection.add(attachment);
      }
    });

    frame.open();
  }

  // ── Event Listeners ──

  // Click on select/upload button
  $(document).on('click', '.idealugano-image-card__btn--select', function (e) {
    e.preventDefault();
    e.stopPropagation();
    openMediaLibrary($(this).closest('.idealugano-image-card'));
  });

  // Click on remove button
  $(document).on('click', '.idealugano-image-card__btn--remove', function (e) {
    e.preventDefault();
    e.stopPropagation();
    var card = $(this).closest('.idealugano-image-card');
    saveImage(card.data('slot'), 0, card);
  });

  // Click on card preview area to open media library
  $(document).on('click', '.idealugano-image-card__preview', function (e) {
    e.preventDefault();
    openMediaLibrary($(this).closest('.idealugano-image-card'));
  });

  var isDirty = false;

  function setDirty(dirty) {
    isDirty = !!dirty;
    var dot = $('#idealugano-status-dot');
    var text = $('#idealugano-status-text');
    var btn = $('#idealugano-save-all-btn');

    if (isDirty) {
      dot.removeClass('is-saving is-error').addClass('has-unsaved');
      text.text('Modifiche non salvate');
      btn.addClass('has-unsaved');
    } else {
      dot.removeClass('has-unsaved is-saving is-error');
      text.text('Tutte le modifiche salvate');
      btn.removeClass('has-unsaved');
    }
  }

  // Track field changes
  $(document).on('input change', '.idealugano-ba-title, .idealugano-ba-description, .idealugano-gallery-title, .idealugano-gallery-category', function () {
    setDirty(true);
  });

  function projectImageCard(slot, label) {
    return '<div class="idealugano-image-card" data-slot="' + slot + '" data-attachment-id="0">' +
      '<div class="idealugano-image-card__preview"><div class="idealugano-image-card__empty"><span>Clicca per aggiungere</span></div></div>' +
      '<div class="idealugano-image-card__info"><h3>' + label + '</h3><p>Foto "' + label.toLowerCase() + '" del restauro</p></div>' +
      '<div class="idealugano-image-card__actions"><button class="idealugano-image-card__btn idealugano-image-card__btn--select" type="button">Carica</button></div>' +
      '<div class="idealugano-image-card__toast"></div></div>';
  }

  $(document).on('click', '.idealugano-ba-add', function () {
    var id = Date.now().toString(36);
    var html = '<div class="idealugano-ba-project" data-project-id="' + id + '">' +
      '<div class="idealugano-ba-project__heading"><strong>Nuovo progetto</strong><button type="button" class="button-link-delete idealugano-ba-remove">Rimuovi progetto</button></div>' +
      '<div class="idealugano-ba-fields"><label>Titolo<input type="text" class="idealugano-ba-title"></label>' +
      '<label>Descrizione<textarea class="idealugano-ba-description" rows="2"></textarea></label></div>' +
      '<div class="idealugano-admin-grid idealugano-ba-images">' + projectImageCard('ba_' + id + '_before', 'Prima') + projectImageCard('ba_' + id + '_after', 'Dopo') + '</div></div>';
    $('.idealugano-ba-projects').append(html);
    $('.idealugano-ba-projects .idealugano-ba-project').last().find('input').trigger('focus');
    setDirty(true);
  });

  $(document).on('click', '.idealugano-ba-remove', function () {
    if (window.confirm('Rimuovere questo progetto?')) {
      $(this).closest('.idealugano-ba-project').remove();
      setDirty(true);
    }
  });

  function galleryCategoryOptions() {
    return '<option value="tende">Tende</option><option value="imbottiti">Imbottiti</option><option value="cuscini">Cuscini</option><option value="tessuti">Tessuti</option><option value="interni">Interni</option><option value="oggettistica">Oggettistica</option><option value="paralumi">Paralumi</option>';
  }

  $(document).on('click', '.idealugano-gallery-add', function () {
    var id = Date.now().toString(36);
    var html = '<div class="idealugano-gallery-item" data-gallery-id="' + id + '"><div class="idealugano-image-card" data-slot="gallery_' + id + '" data-attachment-id="0">' +
      '<div class="idealugano-image-card__preview"><div class="idealugano-image-card__empty"><span>Clicca per aggiungere</span></div></div>' +
      '<div class="idealugano-gallery-item__fields"><label>Titolo<input class="idealugano-gallery-title" type="text"></label><label>Categoria<select class="idealugano-gallery-category">' + galleryCategoryOptions() + '</select></label></div>' +
      '<div class="idealugano-image-card__actions"><button class="idealugano-image-card__btn idealugano-image-card__btn--select" type="button">Carica</button><button class="idealugano-image-card__btn idealugano-gallery-delete" type="button">Elimina voce</button></div><div class="idealugano-image-card__toast"></div></div></div>';
    $('.idealugano-gallery-items').append(html);
    $('.idealugano-gallery-item').last().find('input').trigger('focus');
    setDirty(true);
  });

  $(document).on('click', '.idealugano-gallery-delete', function (e) {
    e.stopPropagation();
    if (window.confirm('Eliminare questa voce dalla galleria?')) {
      $(this).closest('.idealugano-gallery-item').remove();
      setDirty(true);
    }
  });

  /**
   * Universal save handler for all admin settings
   */
  function saveAllChanges(callback) {
    var btn = $('#idealugano-save-all-btn');
    var dot = $('#idealugano-status-dot');
    var text = $('#idealugano-status-text');
    var btnText = btn.find('.idealugano-btn-text');

    var projects = [];
    $('.idealugano-ba-project').each(function () {
      var project = $(this);
      projects.push({
        id: String(project.data('project-id')),
        title: project.find('.idealugano-ba-title').val(),
        description: project.find('.idealugano-ba-description').val(),
      });
    });

    var items = [];
    $('.idealugano-gallery-item').each(function () {
      var item = $(this);
      items.push({
        id: String(item.data('gallery-id')),
        title: item.find('.idealugano-gallery-title').val(),
        category: item.find('.idealugano-gallery-category').val()
      });
    });

    btn.prop('disabled', true).addClass('is-saving');
    btnText.text('Salvataggio…');
    dot.removeClass('has-unsaved is-error').addClass('is-saving');
    text.text('Salvataggio in corso…');

    $.ajax({
      url: config.ajaxUrl,
      type: 'POST',
      data: {
        action: 'idealugano_save_all',
        nonce: config.nonce,
        projects: JSON.stringify(projects),
        items: JSON.stringify(items),
      },
      success: function (response) {
        btn.removeClass('is-saving');
        if (response.success) {
          setDirty(false);
          dot.removeClass('is-saving has-unsaved is-error');
          text.text('Modifiche salvate con successo!');
          btnText.text('Salvato');

          setTimeout(function () {
            btnText.text('Salva modifiche');
            text.text('Tutte le modifiche salvate');
          }, 2500);

          if (typeof callback === 'function') callback(true);
        } else {
          dot.removeClass('is-saving').addClass('is-error');
          text.text(response.data || config.i18n.error);
          btnText.text('Riprova');
          if (typeof callback === 'function') callback(false);
        }
      },
      error: function () {
        btn.removeClass('is-saving');
        dot.removeClass('is-saving').addClass('is-error');
        text.text(config.i18n.error);
        btnText.text('Riprova');
        if (typeof callback === 'function') callback(false);
      },
      complete: function () {
        btn.prop('disabled', false);
      }
    });
  }

  // Click on universal save button
  $(document).on('click', '#idealugano-save-all-btn, .idealugano-ba-save, .idealugano-gallery-save', function (e) {
    e.preventDefault();
    saveAllChanges();
  });

  // Ctrl+S / Cmd+S shortcut
  $(document).on('keydown', function (e) {
    if ((e.ctrlKey || e.metaKey) && e.key === 's') {
      e.preventDefault();
      saveAllChanges();
    }
  });

  // Warn on navigation if unsaved changes exist
  window.addEventListener('beforeunload', function (e) {
    if (isDirty) {
      e.preventDefault();
      e.returnValue = '';
    }
  });

})(jQuery);

/* ── "Usa le immagini del tema" ──
   Frees every image slot so the front end falls back to the copies shipped in
   assets/images/slots/. Needed when a migration leaves the slots pointing at
   attachments that mean something else on this server. */
jQuery(function ($) {
  $('#idealugano-use-bundled').on('click', function () {
    var btn = $(this);
    if (!window.confirm(
      'Tutti gli slot immagine verranno liberati e le sezioni useranno le immagini incluse nel tema.\n\n' +
      'Le impostazioni attuali vengono salvate come backup. Procedere?'
    )) {
      return;
    }

    btn.prop('disabled', true).text('Attendere…');

    $.post(idealuganoAdmin.ajaxUrl, {
      action: 'idealugano_use_bundled',
      nonce: idealuganoAdmin.nonce
    }).done(function (res) {
      if (res && res.success) {
        btn.text('Fatto, ricarico…');
        window.location.reload();
      } else {
        btn.prop('disabled', false).text('Usa le immagini del tema');
        window.alert('Operazione non riuscita: ' + ((res && res.data) || 'errore sconosciuto'));
      }
    }).fail(function () {
      btn.prop('disabled', false).text('Usa le immagini del tema');
      window.alert('Errore di rete.');
    });
  });
});
