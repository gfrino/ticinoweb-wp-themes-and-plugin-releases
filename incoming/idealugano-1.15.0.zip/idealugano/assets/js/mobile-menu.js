/**
 * Mobile Menu — Hamburger toggle with accessible states
 *
 * @package Idealugano
 * @version 1.0.0
 */
(function () {
  'use strict';

  var hamburger = document.getElementById('idea-hamburger');
  var mobileMenu = document.getElementById('idea-mobile-menu');
  var closeButton = document.getElementById('idea-mobile-menu-close');
  if (!hamburger || !mobileMenu) return;

  var isOpen = false;
  var previousFocus = null;

  function getFocusable() {
    return Array.prototype.slice.call(mobileMenu.querySelectorAll(
      'a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])'
    )).filter(function (element) {
      return element.offsetParent !== null;
    });
  }

  function setMenuState(open) {
    isOpen = open;
    hamburger.classList.toggle('active', isOpen);
    hamburger.setAttribute('aria-expanded', String(isOpen));
    mobileMenu.classList.toggle('open', isOpen);
    mobileMenu.setAttribute('aria-hidden', String(!isOpen));
    document.documentElement.classList.toggle('idea-menu-open', isOpen);
    document.body.classList.toggle('idea-menu-open', isOpen);
    hamburger.setAttribute('aria-label', isOpen ? 'Chiudi menu' : 'Apri menu');

    if (isOpen) {
      previousFocus = document.activeElement;
      window.requestAnimationFrame(function () {
        var focusable = getFocusable();
        if (focusable.length) focusable[0].focus();
      });
    } else if (previousFocus && typeof previousFocus.focus === 'function') {
      previousFocus.focus();
      previousFocus = null;
    }

    document.dispatchEvent(new CustomEvent('idealugano:layoutchange'));
  }

  function toggleMenu() {
    setMenuState(!isOpen);
  }

  hamburger.addEventListener('click', toggleMenu);
  if (closeButton) {
    closeButton.addEventListener('click', function () {
      if (isOpen) setMenuState(false);
    });
  }

  // Close menu on link click
  var links = mobileMenu.querySelectorAll('.idea-mobile-menu__link, .idea-mobile-menu__cta a');
  links.forEach(function (link) {
    link.addEventListener('click', function () {
      if (isOpen) toggleMenu();
    });
  });

  // Close on Escape
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && isOpen) {
      setMenuState(false);
      return;
    }

    if (e.key === 'Tab' && isOpen) {
      var focusable = getFocusable();
      if (!focusable.length) return;
      var first = focusable[0];
      var last = focusable[focusable.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }
  });

  window.addEventListener('resize', function () {
    if (isOpen && window.innerWidth > 1024) setMenuState(false);
  }, { passive: true });
})();
