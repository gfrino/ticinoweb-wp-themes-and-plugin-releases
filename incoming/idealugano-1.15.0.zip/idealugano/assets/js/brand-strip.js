/**
 * Brand Strip — Stagger reveal animation for brand logos
 *
 * @package Idealugano
 * @version 1.0.0
 */
(function () {
  'use strict';

  var grid = document.getElementById('brands-grid');
  if (!grid) return;

  var items = grid.querySelectorAll('.idea-brand-item');
  if (!items.length) return;

  // Respect reduced motion
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    items.forEach(function (item) {
      item.style.opacity = '1';
      item.style.transform = 'none';
    });
    return;
  }

  // Initially hide items
  items.forEach(function (item) {
    item.style.opacity = '0';
    item.style.transform = 'translateY(20px)';
    item.style.transition = 'opacity 0.6s ease, transform 0.6s cubic-bezier(0.19, 1, 0.22, 1)';
  });

  var observer = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        items.forEach(function (item, index) {
          setTimeout(function () {
            item.style.opacity = '1';
            item.style.transform = 'translateY(0)';
          }, index * 150);
        });
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.3 });

  observer.observe(grid);
})();
