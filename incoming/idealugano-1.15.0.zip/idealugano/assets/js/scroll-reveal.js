/**
 * Scroll Reveal — IntersectionObserver-based reveal animations
 *
 * @package Idealugano
 * @version 1.2.0
 */
(function () {
  'use strict';

  // Respect prefers-reduced-motion
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    // Make all elements visible immediately
    var elements = document.querySelectorAll('.reveal');
    for (var i = 0; i < elements.length; i++) {
      elements[i].classList.add('visible');
    }
    // Also ensure hero is loaded
    var heroRM = document.querySelector('.idea-hero');
    if (heroRM) heroRM.classList.add('loaded');
    return;
  }

  // The GSAP motion layer owns reveal timing when it is available. Avoid a
  // second observer changing opacity during scrubbed sequences.
  if (window.IdeaMotion) {
    document.querySelectorAll('.reveal').forEach(function (element) {
      element.classList.add('visible');
    });
    return;
  }

  var observer = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  });

  // Observe all .reveal elements
  var revealElements = document.querySelectorAll('.reveal');
  revealElements.forEach(function (el) {
    observer.observe(el);
  });

  // Safety: if no curtain overlay exists (inner pages or removed),
  // trigger hero animation immediately
  var hero = document.querySelector('.idea-hero');
  if (hero && !document.getElementById('curtain-overlay')) {
    setTimeout(function () {
      hero.classList.add('loaded');
    }, 200);
  }

  // Extra safety: always ensure hero is visible after 5s max
  if (hero) {
    setTimeout(function () {
      if (!hero.classList.contains('loaded')) {
        hero.classList.add('loaded');
      }
    }, 5000);
  }
})();
