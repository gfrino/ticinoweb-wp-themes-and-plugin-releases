<?php
/**
 * Template per la scheda singola del pezzo in Occasione.
 * URL: /occasione/{slug}/
 *
 * @package Idealugano
 * @version 1.9.78
 */

get_header();

$site = idealugano_get_site_data();
$contact = $site['contact'];
?>

<main id="primary" class="site-main">

	<?php while ( have_posts() ) : the_post();
		$post_id     = get_the_ID();
		$meta        = idealugano_get_occasione_meta( $post_id );
		$contact_url = idealugano_get_occasione_contact_url( $post_id );

		$status_labels = array(
			'disponibile' => array( 'label' => __( 'Disponibile subito in atelier', 'idealugano' ), 'class' => 'status-disponibile' ),
			'pezzo_unico' => array( 'label' => __( 'Pezzo unico d\'atelier', 'idealugano' ), 'class' => 'status-pezzo-unico' ),
			'campionario' => array( 'label' => __( 'Campionario showroom', 'idealugano' ), 'class' => 'status-campionario' ),
			'trattativa'  => array( 'label' => __( 'In trattativa / Riservato', 'idealugano' ), 'class' => 'status-trattativa' ),
			'venduto'     => array( 'label' => __( 'Venduto', 'idealugano' ), 'class' => 'status-venduto' ),
		);
		$st_info = isset( $status_labels[ $meta['status'] ] ) ? $status_labels[ $meta['status'] ] : $status_labels['disponibile'];
	?>

		<!-- Breadcrumbs bar -->
		<nav class="idea-breadcrumbs-bar" aria-label="<?php esc_attr_e( 'Percorso di navigazione', 'idealugano' ); ?>">
			<div class="idea-container">
				<ol class="idea-breadcrumbs-list">
					<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'idealugano' ); ?></a></li>
					<li><a href="<?php echo esc_url( get_post_type_archive_link( 'occasione' ) ); ?>"><?php esc_html_e( 'Occasioni', 'idealugano' ); ?></a></li>
					<li aria-current="page"><?php the_title(); ?></li>
				</ol>
			</div>
		</nav>

		<!-- Articolo Singolo -->
		<article id="post-<?php the_ID(); ?>" <?php post_class( 'idea-section idea-section--white idea-occ-single-article' ); ?>>
			<div class="idea-container">

				<div class="idea-occ-single-layout">

					<!-- Colonna Sinistra: Media & Scheda Tecnica -->
					<div class="idea-occ-single-visual reveal">
						<div class="idea-occ-single-photo-wrap">
							<?php if ( has_post_thumbnail() ) : ?>
								<?php the_post_thumbnail( 'large', array( 'class' => 'idea-occ-single-photo', 'alt' => get_the_title() ) ); ?>
							<?php else : ?>
								<div class="idea-occ-single-photo-empty">
									<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
									<p><?php esc_html_e( 'Foto del pezzo d\'atelier in aggiornamento', 'idealugano' ); ?></p>
								</div>
							<?php endif; ?>
							<span class="idea-occ-badge <?php echo esc_attr( $st_info['class'] ); ?>">
								<?php echo esc_html( $st_info['label'] ); ?>
							</span>
						</div>

						<!-- Scheda Caratteristiche Atelier -->
						<div class="idea-occ-specs-card">
							<h3 class="idea-occ-specs-card__title">
								<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/></svg>
								<?php esc_html_e( 'Scheda del Pezzo d\'Atelier', 'idealugano' ); ?>
							</h3>
							<dl class="idea-occ-specs-list">
								<?php if ( ! empty( $meta['type'] ) ) : ?>
									<div class="idea-occ-specs-row">
										<dt><?php esc_html_e( 'Tipologia', 'idealugano' ); ?></dt>
										<dd><strong><?php echo esc_html( $meta['type'] ); ?></strong></dd>
									</div>
								<?php endif; ?>

								<?php if ( ! empty( $meta['dimensions'] ) ) : ?>
									<div class="idea-occ-specs-row">
										<dt><?php esc_html_e( 'Dimensioni / Misure', 'idealugano' ); ?></dt>
										<dd><?php echo esc_html( $meta['dimensions'] ); ?></dd>
									</div>
								<?php endif; ?>

								<?php if ( ! empty( $meta['materials'] ) ) : ?>
									<div class="idea-occ-specs-row">
										<dt><?php esc_html_e( 'Tessuto e Materiali', 'idealugano' ); ?></dt>
										<dd><?php echo esc_html( $meta['materials'] ); ?></dd>
									</div>
								<?php endif; ?>

								<?php if ( ! empty( $meta['code'] ) ) : ?>
									<div class="idea-occ-specs-row">
										<dt><?php esc_html_e( 'Codice di riferimento', 'idealugano' ); ?></dt>
										<dd><?php echo esc_html( $meta['code'] ); ?></dd>
									</div>
								<?php endif; ?>

								<div class="idea-occ-specs-row">
									<dt><?php esc_html_e( 'Disponibilità', 'idealugano' ); ?></dt>
									<dd><span class="idea-occ-status-pill <?php echo esc_attr( $st_info['class'] ); ?>"><?php echo esc_html( $st_info['label'] ); ?></span></dd>
								</div>
							</dl>
						</div>
					</div>

					<!-- Colonna Destra: Informazioni, Prezzo & Azioni -->
					<div class="idea-occ-single-info reveal reveal--right">

						<div class="idea-occ-single-header">
							<span class="idea-eyebrow"><?php esc_html_e( 'Pezzo d\'Occasione · Idea Lugano', 'idealugano' ); ?></span>
							<h1 class="idea-occ-single-title"><?php the_title(); ?></h1>
							<hr class="idea-gold-line">

							<!-- Box Prezzo -->
							<div class="idea-occ-single-price-box">
								<div class="idea-occ-single-price-row">
									<?php if ( ! empty( $meta['price'] ) ) : ?>
										<span class="idea-occ-single-price__val"><?php echo esc_html( $meta['price'] ); ?></span>
										<?php if ( ! empty( $meta['old_price'] ) ) : ?>
											<s class="idea-occ-single-price__old"><?php echo esc_html( $meta['old_price'] ); ?></s>
										<?php endif; ?>
									<?php else : ?>
										<span class="idea-occ-single-price__val"><?php esc_html_e( 'Prezzo su richiesta', 'idealugano' ); ?></span>
									<?php endif; ?>
								</div>
								<span class="idea-occ-single-price__sub">
									<?php esc_html_e( 'Prezzo speciale per pezzo disponibile · Visionabile in atelier su appuntamento', 'idealugano' ); ?>
								</span>
							</div>
						</div>

						<!-- Descrizione completa -->
						<div class="idea-occ-single-desc">
							<h2 class="idea-occ-desc-title"><?php esc_html_e( 'Dettagli e Descrizione', 'idealugano' ); ?></h2>
							<div class="idea-occ-desc-content">
								<?php the_content(); ?>
							</div>
						</div>

						<!-- Box Contatto CTA -->
						<div class="idea-occ-cta-box">
							<div class="idea-occ-cta-box__header">
								<div class="idea-occ-cta-box__icon">
									<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
								</div>
								<div>
									<h3 class="idea-occ-cta-box__title"><?php esc_html_e( 'Ti interessa questo pezzo d\'occasione?', 'idealugano' ); ?></h3>
									<p class="idea-occ-cta-box__sub">
										<?php esc_html_e( 'Contattaci per bloccarlo, concordare una visione dal vivo in atelier o richiedere una modifica su misura.', 'idealugano' ); ?>
									</p>
								</div>
							</div>

							<div class="idea-occ-cta-box__actions">
								<?php if ( 'venduto' === $meta['status'] ) : ?>
									<span class="idea-btn idea-btn--outline is-disabled" aria-disabled="true">
										<?php esc_html_e( 'Pezzo non disponibile (Venduto)', 'idealugano' ); ?>
									</span>
									<a href="<?php echo esc_url( home_url( '/contatti/' ) ); ?>" class="idea-btn idea-btn--gold">
										<?php esc_html_e( 'Richiedi una creazione simile', 'idealugano' ); ?> &rarr;
									</a>
								<?php else : ?>
									<a href="<?php echo esc_url( $contact_url ); ?>" class="idea-btn idea-btn--gold idea-occ-cta-box__btn">
										<span><?php echo esc_html( $meta['cta_text'] ); ?></span> &rarr;
									</a>
									<div class="idea-occ-cta-box__phone">
										<span><?php esc_html_e( 'Oppure telefonaci direttamente:', 'idealugano' ); ?></span>
										<a href="tel:<?php echo esc_attr( str_replace( ' ', '', $contact['phone'] ) ); ?>" class="idea-phone-link">
											<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
											<strong><?php echo esc_html( $contact['phone'] ); ?></strong>
										</a>
									</div>
								<?php endif; ?>
							</div>
						</div>

					</div>

				</div>

				<!-- Altre Occasioni Correlate -->
				<?php
				$related = new WP_Query( array(
					'post_type'      => 'occasione',
					'post_status'    => 'publish',
					'posts_per_page' => 3,
					'post__not_in'   => array( $post_id ),
				) );
				if ( $related->have_posts() ) : ?>
					<div class="idea-occ-related-section">
						<div class="idea-occasioni-header">
							<div>
								<span class="idea-eyebrow"><?php esc_html_e( 'Altre opportunità', 'idealugano' ); ?></span>
								<h2 class="idea-occasioni-header__title"><?php esc_html_e( 'Altre Creazioni d\'Occasione', 'idealugano' ); ?></h2>
								<hr class="idea-gold-line">
							</div>
							<a href="<?php echo esc_url( get_post_type_archive_link( 'occasione' ) ); ?>" class="idea-link-gold">
								<?php esc_html_e( 'Vedi tutte le occasioni', 'idealugano' ); ?> &rarr;
							</a>
						</div>

						<div class="idea-occasioni-grid">
							<?php while ( $related->have_posts() ) : $related->the_post();
								$rel_meta = idealugano_get_occasione_meta( get_the_ID() );
							?>
								<article class="idea-occ-card">
									<div class="idea-occ-card__media">
										<a href="<?php the_permalink(); ?>">
											<?php if ( has_post_thumbnail() ) : ?>
												<?php the_post_thumbnail( 'medium_large' ); ?>
											<?php else : ?>
												<div class="idea-occ-card__placeholder">
													<span>Idea Lugano</span>
												</div>
											<?php endif; ?>
										</a>
									</div>
									<div class="idea-occ-card__body">
										<h4 class="idea-occ-card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
										<div class="idea-occ-card__price-box">
											<span class="idea-occ-price__amount"><?php echo esc_html( ! empty( $rel_meta['price'] ) ? $rel_meta['price'] : __( 'Prezzo su richiesta', 'idealugano' ) ); ?></span>
										</div>
										<div class="idea-occ-card__actions">
											<a href="<?php the_permalink(); ?>" class="idea-btn idea-btn--outline"><?php esc_html_e( 'Vedi pezzo', 'idealugano' ); ?> &rarr;</a>
										</div>
									</div>
								</article>
							<?php endwhile; wp_reset_postdata(); ?>
						</div>
					</div>
				<?php endif; ?>

			</div>
		</article>

	<?php endwhile; ?>

</main>

<?php get_footer(); ?>
