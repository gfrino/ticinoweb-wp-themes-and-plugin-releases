<?php
/**
 * Sezione "Occasioni / Outlet & Pezzi Unici d'Atelier" (CPT, Meta Box, Gestione Admin e Contatti).
 *
 * Permette la gestione autonoma e semplice dal backend di WordPress dei pezzi
 * e prodotti in occasione di Idea Lugano (campionari, tessuti, cuscini, imbottiti, tende),
 * con campi dedicati per prezzo, stato di disponibilità, dimensioni, tessuti e pulsante contatti.
 *
 * @package Idealugano
 * @version 1.9.78
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 1. REGISTRAZIONE CUSTOM POST TYPE "OCCASIONE"
 */
function idealugano_register_occasione_cpt() {
	$labels = array(
		'name'                  => _x( 'Occasioni', 'Post Type General Name', 'idealugano' ),
		'singular_name'         => _x( 'Occasione', 'Post Type Singular Name', 'idealugano' ),
		'menu_name'             => __( 'Occasioni', 'idealugano' ),
		'name_admin_bar'        => __( 'Occasione', 'idealugano' ),
		'archives'              => __( 'Archivio Occasioni', 'idealugano' ),
		'attributes'            => __( 'Attributi Occasione', 'idealugano' ),
		'parent_item_colon'     => __( 'Occasione genitore:', 'idealugano' ),
		'all_items'             => __( 'Tutte le occasioni', 'idealugano' ),
		'add_new_item'          => __( 'Aggiungi nuova occasione', 'idealugano' ),
		'add_new'               => __( 'Aggiungi nuova', 'idealugano' ),
		'new_item'              => __( 'Nuova occasione', 'idealugano' ),
		'edit_item'             => __( 'Modifica occasione', 'idealugano' ),
		'update_item'           => __( 'Aggiorna occasione', 'idealugano' ),
		'view_item'             => __( 'Visualizza occasione', 'idealugano' ),
		'view_items'            => __( 'Visualizza occasioni', 'idealugano' ),
		'search_items'          => __( 'Cerca occasioni', 'idealugano' ),
		'not_found'             => __( 'Nessuna occasione trovata', 'idealugano' ),
		'not_found_in_trash'    => __( 'Nessuna occasione trovata nel cestino', 'idealugano' ),
		'featured_image'        => __( 'Foto principale del pezzo', 'idealugano' ),
		'set_featured_image'    => __( 'Imposta foto principale', 'idealugano' ),
		'remove_featured_image' => __( 'Rimuovi foto principale', 'idealugano' ),
		'use_featured_image'    => __( 'Usa come foto principale', 'idealugano' ),
		'insert_into_item'      => __( 'Inserisci nell\'occasione', 'idealugano' ),
		'uploaded_to_this_item' => __( 'Caricato per questa occasione', 'idealugano' ),
		'items_list'            => __( 'Elenco occasioni', 'idealugano' ),
		'items_list_navigation' => __( 'Navigazione elenco occasioni', 'idealugano' ),
		'filter_items_list'     => __( 'Filtra elenco occasioni', 'idealugano' ),
	);

	$args = array(
		'label'                 => __( 'Occasione', 'idealugano' ),
		'description'           => __( 'Prodotti, campionari e pezzi unici d\'occasione dell\'atelier', 'idealugano' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
		'taxonomies'            => array(),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 25,
		'menu_icon'             => 'dashicons-tag',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => 'occasioni',
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'post',
		'show_in_rest'          => true,
		'rewrite'               => array(
			'slug'       => 'occasione',
			'with_front' => false,
		),
	);

	register_post_type( 'occasione', $args );
}
add_action( 'init', 'idealugano_register_occasione_cpt', 0 );

/**
 * Flush automatico delle regole di rewrite al cambio versione del tema.
 * Eseguito una sola volta per versione.
 */
function idealugano_flush_rules_on_version_change() {
	$ver    = wp_get_theme()->get( 'Version' );
	$stored = get_option( 'idealugano_rewrite_version' );
	if ( $stored !== $ver ) {
		flush_rewrite_rules( false );
		update_option( 'idealugano_rewrite_version', $ver );
	}
}
add_action( 'init', 'idealugano_flush_rules_on_version_change', 99 );


/**
 * 2. META BOX: DETTAGLI OCCASIONE (BACKEND ADMIN)
 */
function idealugano_add_occasione_meta_boxes() {
	add_meta_box(
		'idealugano_occasione_details',
		__( 'Dettagli Prodotto in Occasione', 'idealugano' ),
		'idealugano_render_occasione_meta_box',
		'occasione',
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'idealugano_add_occasione_meta_boxes' );

/**
 * Rendering del Meta Box
 */
function idealugano_render_occasione_meta_box( $post ) {
	wp_nonce_field( 'idealugano_save_occasione_meta', 'idealugano_occasione_meta_nonce' );

	$meta = idealugano_get_occasione_meta( $post->ID );
	?>
	<style>
		.idea-admin-meta-grid {
			display: grid;
			grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
			gap: 16px;
			margin-top: 10px;
		}
		.idea-admin-meta-field {
			display: flex;
			flex-direction: column;
		}
		.idea-admin-meta-field label {
			font-weight: 600;
			margin-bottom: 6px;
			color: #1d2327;
			font-size: 13px;
		}
		.idea-admin-meta-field .description {
			font-size: 12px;
			color: #646970;
			margin-top: 4px;
		}
		.idea-admin-meta-field input[type="text"],
		.idea-admin-meta-field select {
			width: 100%;
			padding: 8px 10px;
			border: 1px solid #8c8f94;
			border-radius: 4px;
			font-size: 14px;
		}
		.idea-admin-meta-field input[type="text"]:focus,
		.idea-admin-meta-field select:focus {
			border-color: #A98242;
			box-shadow: 0 0 0 1px #A98242;
			outline: 2px solid transparent;
		}
		.idea-admin-section-title {
			grid-column: 1 / -1;
			font-size: 13px;
			font-weight: 700;
			text-transform: uppercase;
			letter-spacing: 0.06em;
			color: #052D3A;
			border-bottom: 2px solid #e0d7c6;
			padding-bottom: 6px;
			margin-top: 16px;
			margin-bottom: 4px;
		}
	</style>

	<div class="idea-admin-meta-grid">

		<div class="idea-admin-section-title"><?php esc_html_e( 'Prezzo e Disponibilità', 'idealugano' ); ?></div>

		<div class="idea-admin-meta-field">
			<label for="_occasione_price"><?php esc_html_e( 'Prezzo di Vendita *', 'idealugano' ); ?></label>
			<input type="text" id="_occasione_price" name="_occasione_price" value="<?php echo esc_attr( isset( $meta['raw_price'] ) && '' !== $meta['raw_price'] ? $meta['raw_price'] : $meta['price'] ); ?>" placeholder="es. 200">
			<span class="idea-price-preview" id="_occasione_price_preview" style="display:none;margin-top:6px;font-size:12px;color:#052D3A;background:#f6f3ee;padding:6px 10px;border-radius:4px;border-left:3px solid #A98242;font-weight:600;"></span>
			<span class="description"><?php esc_html_e( 'Basta inserire la cifra (es. 200): "CHF" e ".-" vengono aggiunti automaticamente sul sito.', 'idealugano' ); ?></span>
		</div>

		<div class="idea-admin-meta-field">
			<label for="_occasione_old_price"><?php esc_html_e( 'Prezzo Originale / Barrato (Opzionale)', 'idealugano' ); ?></label>
			<input type="text" id="_occasione_old_price" name="_occasione_old_price" value="<?php echo esc_attr( isset( $meta['raw_old_price'] ) && '' !== $meta['raw_old_price'] ? $meta['raw_old_price'] : $meta['old_price'] ); ?>" placeholder="es. 350">
			<span class="idea-price-preview" id="_occasione_old_price_preview" style="display:none;margin-top:6px;font-size:12px;color:#646970;background:#f6f3ee;padding:6px 10px;border-radius:4px;border-left:3px solid #8c8f94;font-weight:600;"></span>
			<span class="description"><?php esc_html_e( 'Se inserito, verrà mostrato barrato (es. CHF 350.-) per evidenziare l\'offerta.', 'idealugano' ); ?></span>
		</div>

		<script>
		(function() {
			function formatSwissPrice(val) {
				val = (val || '').trim();
				if (!val) return '';
				if (/richiesta|trattativa|contatta|offerta|da definire|su misura/i.test(val)) return val;
				var clean = val.replace(/^(?:chf|fr\.|frs)\s*/i, '').trim();
				clean = clean.replace(/[.,][\-_—]+$/, '').replace(/[.,]$/, '').trim();
				var numStr = clean.replace(/['’\s]/g, '');
				var m = numStr.match(/^(\d+)(?:[.,](\d{1,2}))?$/);
				if (m) {
					var intPart = parseInt(m[1], 10);
					var formattedInt = intPart.toLocaleString('de-CH');
					var dec = m[2];
					if (dec && parseInt(dec, 10) > 0) {
						if (dec.length === 1) dec += '0';
						return 'CHF ' + formattedInt + '.' + dec;
					}
					return 'CHF ' + formattedInt + '.-';
				}
				var res = /^chf\b/i.test(val) ? val : 'CHF ' + val;
				if (/\d$/.test(res)) res += '.-';
				return res;
			}

			function updatePreview(id, previewId) {
				var input = document.getElementById(id);
				var preview = document.getElementById(previewId);
				if (!input || !preview) return;
				var update = function() {
					var formatted = formatSwissPrice(input.value);
					if (formatted) {
						preview.textContent = '✓ Sul sito verrà mostrato: ' + formatted;
						preview.style.display = 'block';
					} else {
						preview.textContent = '';
						preview.style.display = 'none';
					}
				};
				input.addEventListener('input', update);
				update();
			}

			updatePreview('_occasione_price', '_occasione_price_preview');
			updatePreview('_occasione_old_price', '_occasione_old_price_preview');
		})();
		</script>

		<div class="idea-admin-meta-field">
			<label for="_occasione_status"><?php esc_html_e( 'Stato Disponibilità', 'idealugano' ); ?></label>
			<select id="_occasione_status" name="_occasione_status">
				<option value="disponibile" <?php selected( $meta['status'], 'disponibile' ); ?>><?php esc_html_e( '🟢 Disponibile subito in atelier', 'idealugano' ); ?></option>
				<option value="pezzo_unico" <?php selected( $meta['status'], 'pezzo_unico' ); ?>><?php esc_html_e( '⭐ Pezzo unico d\'atelier', 'idealugano' ); ?></option>
				<option value="campionario" <?php selected( $meta['status'], 'campionario' ); ?>><?php esc_html_e( '🏷️ Da showroom / Campionario', 'idealugano' ); ?></option>
				<option value="trattativa" <?php selected( $meta['status'], 'trattativa' ); ?>><?php esc_html_e( '🟠 In trattativa / Riservato', 'idealugano' ); ?></option>
				<option value="venduto" <?php selected( $meta['status'], 'venduto' ); ?>><?php esc_html_e( '⚪ Venduto / Non disponibile', 'idealugano' ); ?></option>
			</select>
			<span class="description"><?php esc_html_e( 'Mostra un elegante badge di stato sulla scheda prodotto.', 'idealugano' ); ?></span>
		</div>

		<div class="idea-admin-section-title"><?php esc_html_e( 'Caratteristiche dell\'Atelier', 'idealugano' ); ?></div>

		<div class="idea-admin-meta-field">
			<label for="_occasione_type"><?php esc_html_e( 'Tipologia Prodotto', 'idealugano' ); ?></label>
			<input type="text" id="_occasione_type" name="_occasione_type" value="<?php echo esc_attr( $meta['type'] ); ?>" placeholder="es. Tenda su misura, Coppia Cuscini, Poltroncina, Tessuto a metraggio">
		</div>

		<div class="idea-admin-meta-field">
			<label for="_occasione_dimensions"><?php esc_html_e( 'Misure / Dimensioni', 'idealugano' ); ?></label>
			<input type="text" id="_occasione_dimensions" name="_occasione_dimensions" value="<?php echo esc_attr( $meta['dimensions'] ); ?>" placeholder="es. L 140 x H 280 cm oppure 50 x 50 cm">
		</div>

		<div class="idea-admin-meta-field">
			<label for="_occasione_materials"><?php esc_html_e( 'Tessuto / Materiali', 'idealugano' ); ?></label>
			<input type="text" id="_occasione_materials" name="_occasione_materials" value="<?php echo esc_attr( $meta['materials'] ); ?>" placeholder="es. 100% Lino naturale, Velluto operato Rubelli">
		</div>

		<div class="idea-admin-meta-field">
			<label for="_occasione_code"><?php esc_html_e( 'Codice Riferimento (Opzionale)', 'idealugano' ); ?></label>
			<input type="text" id="_occasione_code" name="_occasione_code" value="<?php echo esc_attr( $meta['code'] ); ?>" placeholder="es. OCC-01">
		</div>

		<div class="idea-admin-section-title"><?php esc_html_e( 'Pulsante Contattaci (Azione)', 'idealugano' ); ?></div>

		<div class="idea-admin-meta-field">
			<label for="_occasione_cta_text"><?php esc_html_e( 'Testo Pulsante Contatta', 'idealugano' ); ?></label>
			<input type="text" id="_occasione_cta_text" name="_occasione_cta_text" value="<?php echo esc_attr( $meta['cta_text'] ); ?>" placeholder="es. Richiedi informazioni">
			<span class="description"><?php esc_html_e( 'Default: "Richiedi informazioni".', 'idealugano' ); ?></span>
		</div>

		<div class="idea-admin-meta-field">
			<label for="_occasione_cta_link"><?php esc_html_e( 'Link Personalizzato (Opzionale)', 'idealugano' ); ?></label>
			<input type="text" id="_occasione_cta_link" name="_occasione_cta_link" value="<?php echo esc_attr( $meta['cta_link'] ); ?>" placeholder="Lascia vuoto per inviare al modulo contatti precompilato">
			<span class="description"><?php esc_html_e( 'Se lasciato vuoto, porta direttamente alla pagina Contatti con oggetto e testo precompilati.', 'idealugano' ); ?></span>
		</div>

	</div>
	<?php
}

/**
 * Salvataggio dei metadati
 */
function idealugano_save_occasione_meta( $post_id ) {
	if ( ! isset( $_POST['idealugano_occasione_meta_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['idealugano_occasione_meta_nonce'] ), 'idealugano_save_occasione_meta' ) ) {
		return;
	}

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$fields = array(
		'_occasione_price'      => 'sanitize_text_field',
		'_occasione_old_price'  => 'sanitize_text_field',
		'_occasione_status'     => 'sanitize_text_field',
		'_occasione_type'       => 'sanitize_text_field',
		'_occasione_dimensions' => 'sanitize_text_field',
		'_occasione_materials'  => 'sanitize_text_field',
		'_occasione_code'       => 'sanitize_text_field',
		'_occasione_cta_text'   => 'sanitize_text_field',
		'_occasione_cta_link'   => 'esc_url_raw',
	);

	foreach ( $fields as $field => $sanitizer ) {
		if ( isset( $_POST[ $field ] ) ) {
			$val = call_user_func( $sanitizer, wp_unslash( $_POST[ $field ] ) );
			update_post_meta( $post_id, $field, $val );
		} else {
			delete_post_meta( $post_id, $field );
		}
	}
}
add_action( 'save_post_occasione', 'idealugano_save_occasione_meta' );


/**
 * 3. COLONNE PERSONALIZZATE IN TABELLA ADMIN
 */
function idealugano_set_occasione_columns( $columns ) {
	$new_columns = array();
	foreach ( $columns as $key => $title ) {
		if ( 'title' === $key ) {
			$new_columns['thumb'] = __( 'Foto', 'idealugano' );
			$new_columns['title'] = $title;
			$new_columns['price'] = __( 'Prezzo', 'idealugano' );
			$new_columns['status'] = __( 'Stato', 'idealugano' );
			$new_columns['details'] = __( 'Tipologia / Misure', 'idealugano' );
		} else {
			$new_columns[ $key ] = $title;
		}
	}
	return $new_columns;
}
add_filter( 'manage_occasione_posts_columns', 'idealugano_set_occasione_columns' );

function idealugano_render_occasione_custom_columns( $column, $post_id ) {
	$meta = idealugano_get_occasione_meta( $post_id );

	switch ( $column ) {
		case 'thumb':
			if ( has_post_thumbnail( $post_id ) ) {
				echo get_the_post_thumbnail( $post_id, array( 55, 55 ), array( 'style' => 'width:55px;height:55px;object-fit:cover;border-radius:4px;' ) );
			} else {
				echo '<span style="display:inline-block;width:55px;height:55px;background:#F0EBE0;border-radius:4px;text-align:center;line-height:55px;color:#9B9588;font-size:11px;">No foto</span>';
			}
			break;

		case 'price':
			if ( ! empty( $meta['price'] ) ) {
				echo '<strong style="color:#052D3A;font-size:13px;">' . esc_html( $meta['price'] ) . '</strong>';
				if ( ! empty( $meta['old_price'] ) ) {
					echo '<br><s style="color:#9B9588;font-size:11px;">' . esc_html( $meta['old_price'] ) . '</s>';
				}
			} else {
				echo '<span style="color:#9B9588;">—</span>';
			}
			break;

		case 'status':
			$status_styles = array(
				'disponibile' => array( 'label' => __( 'Disponibile', 'idealugano' ), 'bg' => '#2e7d32', 'fg' => '#fff' ),
				'pezzo_unico' => array( 'label' => __( 'Pezzo unico', 'idealugano' ), 'bg' => '#A98242', 'fg' => '#fff' ),
				'campionario' => array( 'label' => __( 'Campionario', 'idealugano' ), 'bg' => '#052D3A', 'fg' => '#fff' ),
				'trattativa'  => array( 'label' => __( 'In trattativa', 'idealugano' ), 'bg' => '#e65100', 'fg' => '#fff' ),
				'venduto'     => array( 'label' => __( 'Venduto', 'idealugano' ), 'bg' => '#757575', 'fg' => '#fff' ),
			);
			$st = isset( $status_styles[ $meta['status'] ] ) ? $status_styles[ $meta['status'] ] : $status_styles['disponibile'];
			printf(
				'<span style="display:inline-block;padding:3px 9px;border-radius:12px;font-size:11px;font-weight:600;background:%s;color:%s;">%s</span>',
				esc_attr( $st['bg'] ),
				esc_attr( $st['fg'] ),
				esc_html( $st['label'] )
			);
			break;

		case 'details':
			$parts = array();
			if ( ! empty( $meta['type'] ) ) {
				$parts[] = esc_html( $meta['type'] );
			}
			if ( ! empty( $meta['dimensions'] ) ) {
				$parts[] = esc_html( $meta['dimensions'] );
			}
			if ( ! empty( $meta['materials'] ) ) {
				$parts[] = '<em>' . esc_html( $meta['materials'] ) . '</em>';
			}
			echo ! empty( $parts ) ? implode( '<br>', $parts ) : '<span style="color:#9B9588;">—</span>';
			break;
	}
}
add_action( 'manage_occasione_posts_custom_column', 'idealugano_render_occasione_custom_columns', 10, 2 );


/**
 * 4. HELPER FORMATTAZIONE PREZZO SVIZZERO E RECUPERO METADATI
 */

/**
 * Formatta automaticamente un valore di prezzo in franchi svizzeri standard:
 * es. "200" => "CHF 200.-"
 * es. "1250" => "CHF 1'250.-"
 * es. "200.-" o "200._" => "CHF 200.-"
 * es. "CHF 200" o "CHF 200.-" => "CHF 200.-"
 * Se il valore contiene espressioni descrittive (es. "Su richiesta"), viene mantenuto inalterato.
 */
function idealugano_format_price( $val ) {
	if ( null === $val || '' === trim( (string) $val ) ) {
		return '';
	}

	$val = trim( (string) $val );

	// Se è solo testo descrittivo (es. "Su richiesta", "Trattativa riservata")
	if ( preg_match( '/(richiesta|trattativa|contatta|offerta|da definire|su misura)/i', $val ) ) {
		return $val;
	}

	// Normalizziamo varianti di valuta all'inizio (CHF, Fr., etc.)
	$cleaned = preg_replace( '/^(?:chf|fr\.|frs)\s*/i', '', $val );
	$cleaned = trim( $cleaned );

	// Rimuoviamo terminatori comuni come .-, ._, --, -, ., etc.
	$cleaned = preg_replace( '/[.,][\-_—]+$/', '', $cleaned );
	$cleaned = preg_replace( '/[.,]$/', '', $cleaned );
	$cleaned = trim( $cleaned );

	// Rimuoviamo separatori di migliaia svizzeri (', ’, spazio)
	$numeric_check = str_replace( array( "'", "’", ' ' ), '', $cleaned );

	// Controllo se è un numero intero o con decimali (es. "200", "1250", "250.50", "250,00")
	if ( preg_match( '/^\d+([.,]\d{1,2})?$/', $numeric_check, $matches ) ) {
		$has_decimals  = false;
		$formatted_dec = '00';

		if ( ! empty( $matches[1] ) ) {
			$dec_sep = substr( $matches[1], 0, 1 );
			$dec_num = substr( $matches[1], 1 );
			$int_part = (int) strstr( $numeric_check, $dec_sep, true );
			$dec_int  = (int) $dec_num;
			if ( $dec_int > 0 ) {
				$has_decimals  = true;
				$formatted_dec = str_pad( $dec_num, 2, '0', STR_PAD_RIGHT );
			}
		} else {
			$int_part = (int) $numeric_check;
		}

		// Migliaia svizzere con apostrofo (es. 1'250)
		$formatted_int = number_format( $int_part, 0, '.', "'" );

		if ( $has_decimals ) {
			return 'CHF ' . $formatted_int . '.' . $formatted_dec;
		} else {
			return 'CHF ' . $formatted_int . '.-';
		}
	}

	// Se ha cifre ma con testo aggiuntivo (es. "200 cad.", "150 / m")
	if ( ! preg_match( '/^chf\b/i', $val ) ) {
		$val = 'CHF ' . $val;
	}
	if ( preg_match( '/\d$/', $val ) ) {
		$val .= '.-';
	}

	return $val;
}

function idealugano_get_occasione_meta( $post_id ) {
	$raw_price     = get_post_meta( $post_id, '_occasione_price', true );
	$raw_old_price = get_post_meta( $post_id, '_occasione_old_price', true );
	$status        = get_post_meta( $post_id, '_occasione_status', true );
	$type          = get_post_meta( $post_id, '_occasione_type', true );
	$dimensions    = get_post_meta( $post_id, '_occasione_dimensions', true );
	$materials     = get_post_meta( $post_id, '_occasione_materials', true );
	$code          = get_post_meta( $post_id, '_occasione_code', true );
	$cta_text      = get_post_meta( $post_id, '_occasione_cta_text', true );
	$cta_link      = get_post_meta( $post_id, '_occasione_cta_link', true );

	if ( empty( $status ) ) {
		$status = 'disponibile';
	}
	if ( empty( $cta_text ) ) {
		$cta_text = __( 'Richiedi informazioni', 'idealugano' );
	}

	return array(
		'raw_price'     => $raw_price ? $raw_price : '',
		'price'         => idealugano_format_price( $raw_price ),
		'raw_old_price' => $raw_old_price ? $raw_old_price : '',
		'old_price'     => idealugano_format_price( $raw_old_price ),
		'status'        => $status,
		'type'          => $type ? $type : '',
		'dimensions'    => $dimensions ? $dimensions : '',
		'materials'     => $materials ? $materials : '',
		'code'          => $code ? $code : '',
		'cta_text'      => $cta_text,
		'cta_link'      => $cta_link ? $cta_link : '',
	);
}

/**
 * Helper che genera l'URL per il pulsante "Contattaci" dell'occasione.
 */
function idealugano_get_occasione_contact_url( $post ) {
	$post = get_post( $post );
	if ( ! $post ) {
		return home_url( '/contatti/' );
	}

	$meta = idealugano_get_occasione_meta( $post->ID );
	if ( ! empty( $meta['cta_link'] ) ) {
		return $meta['cta_link'];
	}

	return add_query_arg(
		array(
			'occasione' => rawurlencode( $post->post_title ),
			'rif'       => ! empty( $meta['code'] ) ? rawurlencode( $meta['code'] ) : $post->ID,
		),
		home_url( '/contatti/' )
	);
}
