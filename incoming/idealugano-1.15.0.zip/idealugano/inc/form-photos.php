<?php
/**
 * Foto allegate al modulo di contatto.
 *
 * Il gestore del parent (ticinoweb-ai-theme/inc/form-handler.php) non gestisce allegati:
 * qui li aggiungiamo con i suoi filtri, senza toccarlo.
 *
 * - Campo `foto[]` (fino a 5 immagini, JPG/PNG/WebP/HEIC, max 10 MB l'una).
 * - Il contenuto è verificato davvero (getimagesize / firma HEIC), non l'estensione.
 * - Le foto sono copiate in una cartella temporanea non indicizzabile, allegate alla mail
 *   al titolare e cancellate subito dopo l'invio. Nel messaggio salvato in "Invii Ricevuti"
 *   resta la riga con il numero di foto.
 *
 * @package Idealugano
 */

if (!defined('ABSPATH')) {
    exit;
}

const IDEA_PHOTO_MAX_FILES = 5;
const IDEA_PHOTO_MAX_BYTES = 10 * 1024 * 1024;

/**
 * Valida $_FILES['foto'] e restituisce l'elenco dei file accettati.
 *
 * @return array<int,array{tmp:string,name:string,mime:string}>|WP_Error
 */
function idealugano_form_collect_photos() {
    if (empty($_FILES['foto']) || !is_array($_FILES['foto']['name'])) {
        return array();
    }
    $f     = $_FILES['foto'];
    $files = array();
    foreach ($f['name'] as $i => $name) {
        if ((int) $f['error'][$i] === UPLOAD_ERR_NO_FILE) {
            continue;
        }
        if ((int) $f['error'][$i] !== UPLOAD_ERR_OK) {
            return new WP_Error('upload', __('Una foto non è stata caricata correttamente, riprova.', 'idealugano'));
        }
        if (count($files) >= IDEA_PHOTO_MAX_FILES) {
            return new WP_Error('count', sprintf(__('Puoi allegare al massimo %d foto.', 'idealugano'), IDEA_PHOTO_MAX_FILES));
        }
        $tmp = $f['tmp_name'][$i];
        if (!is_uploaded_file($tmp) || (int) $f['size'][$i] > IDEA_PHOTO_MAX_BYTES) {
            return new WP_Error('size', __('Ogni foto può pesare al massimo 10 MB.', 'idealugano'));
        }
        $mime = '';
        $info = @getimagesize($tmp);
        if ($info && in_array($info[2], array(IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_WEBP), true)) {
            $mime = image_type_to_mime_type($info[2]);
        } else {
            // HEIC/HEIF (iPhone): non leggibile da getimagesize, si controlla la firma "ftyp".
            $head = (string) file_get_contents($tmp, false, null, 0, 16);
            if (substr($head, 4, 4) === 'ftyp' && in_array(substr($head, 8, 4), array('heic', 'heix', 'hevc', 'mif1', 'msf1'), true)) {
                $mime = 'image/heic';
            }
        }
        if ($mime === '') {
            return new WP_Error('type', __('Puoi allegare solo foto (JPG, PNG, WebP o HEIC).', 'idealugano'));
        }
        $files[] = array('tmp' => $tmp, 'name' => '', 'mime' => $mime);
    }
    return $files;
}

add_filter('ticinoweb_form_fields', 'idealugano_form_photos_prepare', 10, 2);
function idealugano_form_photos_prepare($fields) {
    $files = idealugano_form_collect_photos();
    if (is_wp_error($files)) {
        wp_send_json_error(array('message' => $files->get_error_message(), 'code' => 'foto'), 422);
    }
    if (!$files) {
        return $fields;
    }

    $dir = trailingslashit(get_temp_dir()) . 'idealugano-foto-' . wp_generate_password(20, false, false);
    if (!wp_mkdir_p($dir)) {
        wp_send_json_error(array('message' => __('Non sono riuscito a salvare le foto, riprova o scrivici via email.', 'idealugano'), 'code' => 'foto'), 500);
    }
    $ext   = array('image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/heic' => 'heic');
    $paths = array();
    foreach ($files as $n => $file) {
        $dest = $dir . '/foto-' . ($n + 1) . '.' . $ext[$file['mime']];
        if (move_uploaded_file($file['tmp'], $dest)) {
            $paths[] = $dest;
        }
    }
    $GLOBALS['idealugano_form_photos'] = array('dir' => $dir, 'paths' => $paths);
    // Se la richiesta termina prima dell'invio (es. validazione fallita) le foto vengono comunque cancellate.
    register_shutdown_function('idealugano_form_photos_cleanup');

    if ($paths) {
        $fields['messaggio'] .= "\n\n" . sprintf(_n('[%d foto allegata alla mail]', '[%d foto allegate alla mail]', count($paths), 'idealugano'), count($paths));
    }
    return $fields;
}

// Aggiunge le foto alla mail del gestore del parent (che non passa allegati a wp_mail).
add_filter('wp_mail', 'idealugano_form_photos_attach');
function idealugano_form_photos_attach($args) {
    if (!empty($GLOBALS['idealugano_form_photos']['paths'])) {
        $args['attachments'] = array_merge((array) $args['attachments'], $GLOBALS['idealugano_form_photos']['paths']);
    }
    return $args;
}

// Pulizia: le foto non restano sul server dopo l'invio.
add_action('ticinoweb_form_submitted', 'idealugano_form_photos_cleanup');
function idealugano_form_photos_cleanup() {
    if (empty($GLOBALS['idealugano_form_photos'])) {
        return;
    }
    $p = $GLOBALS['idealugano_form_photos'];
    foreach ($p['paths'] as $path) {
        @unlink($path);
    }
    @rmdir($p['dir']);
    unset($GLOBALS['idealugano_form_photos']);
}
