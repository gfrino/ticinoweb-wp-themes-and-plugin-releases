<?php
/**
 * Role-based admin restrictions for Idea Lugano.
 *
 * Restricts users with the "editor" role so they can ONLY see and access:
 *  1. Occasioni (edit.php?post_type=occasione)
 *  2. Immagini Sito (idealugano-images)
 *  3. ticinoWEB CMS (ticinoweb-cms)
 *
 * Administrators retain full access to everything.
 *
 * @package Idealugano
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Check if the current user is an Editor (and NOT an Administrator).
 *
 * @return bool
 */
function idealugano_is_editor_user()
{
    if (!is_user_logged_in()) {
        return false;
    }

    // Administrators and Super Admins are never restricted
    if (current_user_can('administrator') || (is_multisite() && is_super_admin())) {
        return false;
    }

    $user = wp_get_current_user();
    return in_array('editor', (array) $user->roles, true);
}

/**
 * Filter the admin menu for Editors: keep ONLY Occasioni, Immagini Sito, and ticinoWEB CMS.
 */
add_action('admin_menu', 'idealugano_restrict_editor_admin_menu', 99999);
function idealugano_restrict_editor_admin_menu()
{
    if (!idealugano_is_editor_user()) {
        return;
    }

    global $menu, $submenu;

    // The ONLY allowed top-level menu slugs:
    $allowed_slugs = array(
        'edit.php?post_type=occasione',
        'idealugano-brands',
        'idealugano-images',
        'ticinoweb-cms',
    );

    if (is_array($menu)) {
        $reordered_menu = array();
        $target_positions = array(
            'edit.php?post_type=occasione' => 10,
            'idealugano-brands'            => 15,
            'idealugano-images'            => 20,
            'ticinoweb-cms'                => 30,
        );

        foreach ($menu as $pos => $item) {
            $slug = isset($item[2]) ? $item[2] : '';
            if (in_array($slug, $allowed_slugs, true)) {
                $new_pos = isset($target_positions[$slug]) ? $target_positions[$slug] : $pos;
                $reordered_menu[$new_pos] = $item;
            }
        }

        ksort($reordered_menu);
        $menu = $reordered_menu;
    }

    // Clean up submenus: only keep submenus belonging to allowed parents
    if (is_array($submenu)) {
        foreach ($submenu as $parent_slug => $sub_items) {
            if (!in_array($parent_slug, $allowed_slugs, true)) {
                unset($submenu[$parent_slug]);
            }
        }
    }
}

/**
 * Protect admin screens: redirect editors away from any disallowed screen.
 */
add_action('admin_init', 'idealugano_restrict_editor_admin_screens');
function idealugano_restrict_editor_admin_screens()
{
    if (!idealugano_is_editor_user()) {
        return;
    }

    // Do not interfere with AJAX, cron, or REST requests
    if (wp_doing_ajax() || wp_doing_cron() || (defined('REST_REQUEST') && REST_REQUEST)) {
        return;
    }

    global $pagenow;

    // Technical pages required for core admin actions (media upload, options saving)
    $allowed_core_pages = array(
        'async-upload.php',
        'media-upload.php',
        'options.php',
        'admin-post.php',
    );

    if (in_array($pagenow, $allowed_core_pages, true)) {
        return;
    }

    // 1. admin.php: only allowed for idealugano-brands, idealugano-images and ticinoweb-cms
    if ($pagenow === 'admin.php') {
        $page = isset($_GET['page']) ? sanitize_key($_GET['page']) : '';
        // Solo le tre schermate previste: niente wildcard su "ticinoweb", che
        // apriva agli editor qualsiasi pagina admin del parent (SEO, impostazioni).
        if ($page === 'idealugano-brands' || $page === 'idealugano-images' || $page === 'ticinoweb-cms') {
            return;
        }
    }

    // 2. edit.php / post-new.php: only allowed for post_type=occasione
    if ($pagenow === 'edit.php' || $pagenow === 'post-new.php') {
        $post_type = isset($_GET['post_type']) ? sanitize_key($_GET['post_type']) : 'post';
        if ($post_type === 'occasione') {
            return;
        }
    }

    // 3. post.php: only allowed if editing an 'occasione'
    if ($pagenow === 'post.php') {
        $post_id = 0;
        if (isset($_GET['post'])) {
            $post_id = (int) $_GET['post'];
        } elseif (isset($_POST['post_ID'])) {
            $post_id = (int) $_POST['post_ID'];
        }

        if ($post_id > 0 && get_post_type($post_id) === 'occasione') {
            return;
        }
    }

    // Disallowed page or root dashboard (/wp-admin/ or index.php) -> redirect to Occasioni
    wp_safe_redirect(admin_url('edit.php?post_type=occasione'));
    exit;
}

/**
 * Redirect editors to Occasioni after login instead of the Dashboard.
 */
add_filter('login_redirect', 'idealugano_editor_login_redirect', 10, 3);
function idealugano_editor_login_redirect($redirect_to, $request, $user)
{
    if ($user instanceof WP_User && in_array('editor', (array) $user->roles, true) && !user_can($user, 'administrator')) {
        return admin_url('edit.php?post_type=occasione');
    }
    return $redirect_to;
}

/**
 * Clean up top Admin Bar for editors: remove comments, WP logo, and disallowed "+ Nuovo" nodes.
 */
add_action('wp_before_admin_bar_render', 'idealugano_clean_editor_admin_bar', 999);
function idealugano_clean_editor_admin_bar()
{
    if (!idealugano_is_editor_user()) {
        return;
    }

    global $wp_admin_bar;
    if (!$wp_admin_bar) {
        return;
    }

    $wp_admin_bar->remove_node('wp-logo');
    $wp_admin_bar->remove_node('comments');
    $wp_admin_bar->remove_node('new-post');
    $wp_admin_bar->remove_node('new-media');
    $wp_admin_bar->remove_node('new-page');
    $wp_admin_bar->remove_node('new-user');
}
