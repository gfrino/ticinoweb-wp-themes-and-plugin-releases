<?php
/**
 * Idea Lugano — Admin Image Manager
 * Custom admin page to manage all site images from one place
 *
 * @package Idealugano
 * @version 1.5.0
 */

if (!defined('ABSPATH')) exit;

/* ─────────────────────────────────────────────
   1. REGISTER ADMIN MENU
   ───────────────────────────────────────────── */
add_action('admin_menu', 'idealugano_add_images_menu');
function idealugano_add_images_menu()
{
    add_menu_page(
        'Immagini Sito',                          // Page title
        'Immagini Sito',                          // Menu title
        'edit_pages',                             // Capability (accessible to Editors and Admins)
        'idealugano-images',                      // Slug
        'idealugano_images_page',                 // Callback
        'dashicons-format-gallery',               // Icon
        59                                        // Position (just before Appearance)
    );
}


/* ─────────────────────────────────────────────
   2. IMAGE SLOTS CONFIGURATION
   ───────────────────────────────────────────── */

/**
 * Returns all available image slots grouped by section.
 * This is the single source of truth — add new slots here
 * and they automatically appear in both the admin UI and frontend.
 */
function idealugano_get_image_slots()
{
    return array(
        'homepage' => array(
            'label' => 'Homepage',
            'icon'  => '🏠',
            'slots' => array(
                'hero' => array(
                    'label'       => 'Hero principale',
                    'description' => 'Immagine full-screen della homepage (consigliata: 1920×1080px)',
                    'ratio'       => '16/9',
                ),
                'atelier' => array(
                    'label'       => 'Atelier / Editoriale',
                    'description' => 'Foto dell\'interno dell\'atelier nella sezione editoriale',
                    'ratio'       => '3/4',
                ),
            ),
        ),
        'servizi' => array(
            'label' => 'Servizi',
            'icon'  => '✂️',
            'slots' => array(
                'srv_oggettistica' => array(
                    'label'       => 'Oggettistica',
                    'description' => 'Foto servizio oggettistica e complementi',
                    'ratio'       => '4/3',
                ),
                'srv_tende' => array(
                    'label'       => 'Tende su misura',
                    'description' => 'Foto servizio tende',
                    'ratio'       => '4/3',
                ),
                'srv_cuscini' => array(
                    'label'       => 'Cuscini personalizzati',
                    'description' => 'Foto servizio cuscini',
                    'ratio'       => '4/3',
                ),
                'srv_imbottiti' => array(
                    'label'       => 'Rifacimento imbottiti',
                    'description' => 'Foto servizio imbottiti',
                    'ratio'       => '4/3',
                ),
                'srv_paralumi' => array(
                    'label'       => 'Paralumi',
                    'description' => 'Foto servizio paralumi',
                    'ratio'       => '4/3',
                ),
                'srv_interior' => array(
                    'label'       => 'Interior design',
                    'description' => 'Foto servizio interior design',
                    'ratio'       => '4/3',
                ),
            ),
        ),
        'tende' => array(
            'label' => 'Tipologie Tende',
            'icon'  => '🪟',
            'slots' => array(
                'curtain_moderne' => array(
                    'label'       => 'Tende moderne',
                    'description' => 'Foto tende moderne a pannello/wave',
                    'ratio'       => '3/4',
                ),
                'curtain_classiche' => array(
                    'label'       => 'Tende tradizionali',
                    'description' => 'Foto tende classiche con mantovana',
                    'ratio'       => '3/4',
                ),
                'curtain_rullo' => array(
                    'label'       => 'Tende a rullo',
                    'description' => 'Foto tende a rullo e tecniche',
                    'ratio'       => '3/4',
                ),
                'curtain_lamelle' => array(
                    'label'       => 'Lamelle e veneziane',
                    'description' => 'Foto lamelle e veneziane',
                    'ratio'       => '3/4',
                ),
            ),
        ),
        'prodotti' => array(
            'label' => 'Prodotti / Collezioni',
            'icon'  => '🛋️',
            'slots' => array(
                'prod_tessuti' => array(
                    'label'       => 'Tessuti e stoffe',
                    'description' => 'Foto collezione tessuti',
                    'ratio'       => '3/4',
                ),
                'prod_imbottiti' => array(
                    'label'       => 'Imbottiti e divani',
                    'description' => 'Foto imbottiti e divani',
                    'ratio'       => '3/4',
                ),
                'prod_letti' => array(
                    'label'       => 'Letti e materassi',
                    'description' => 'Foto letti e materassi',
                    'ratio'       => '3/4',
                ),
                'prod_paralumi' => array(
                    'label'       => 'Paralumi',
                    'description' => 'Foto paralumi artigianali',
                    'ratio'       => '3/4',
                ),
                'prod_oggettistica' => array(
                    'label'       => 'Oggettistica',
                    'description' => 'Foto collezione oggettistica e complementi',
                    'ratio'       => '3/4',
                ),
                'prod_interior' => array(
                    'label'       => 'Interior design',
                    'description' => 'Foto progetto e consulenza interior design',
                    'ratio'       => '3/4',
                ),
            ),
        ),
        'oggettistica' => array(
            'label' => 'Oggettistica',
            'icon'  => '🏺',
            'slots' => array(
                'object_01' => array(
                    'label'       => 'Oggetto 1',
                    'description' => 'Prima foto oggettistica',
                    'ratio'       => '1/1',
                ),
                'object_02' => array(
                    'label'       => 'Oggetto 2',
                    'description' => 'Seconda foto oggettistica',
                    'ratio'       => '1/1',
                ),
                'object_03' => array(
                    'label'       => 'Oggetto 3',
                    'description' => 'Terza foto oggettistica',
                    'ratio'       => '1/1',
                ),
            ),
        ),
        'landing' => array(
            'label' => 'Landing servizi e foto partner',
            'icon'  => '🎯',
            'slots' => function_exists('idealugano_get_landing_image_slots') ? idealugano_get_landing_image_slots() : array(),
        ),
        'marchi' => array(
            'label' => 'Loghi Marchi Partner',
            'icon'  => '🏷️',
            'slots' => array(
                'brand_kadeco' => array(
                    'label'       => 'KADECO',
                    'description' => 'Logo KADECO (sfondo trasparente, PNG)',
                    'ratio'       => '3/1',
                ),
                'brand_mhz' => array(
                    'label'       => 'MHZ',
                    'description' => 'Logo MHZ (sfondo trasparente, PNG)',
                    'ratio'       => '3/1',
                ),
                'brand_silentgliss' => array(
                    'label'       => 'SILENT GLISS',
                    'description' => 'Logo Silent Gliss (sfondo trasparente, PNG)',
                    'ratio'       => '3/1',
                ),
                'brand_treca' => array(
                    'label'       => 'TRECA Interiors Paris',
                    'description' => 'Logo TRECA (sfondo trasparente, PNG)',
                    'ratio'       => '3/1',
                ),
            ),
        ),
    );
}

/**
 * Hand every slot back to the images bundled with the theme.
 *
 * Clearing the option is what makes the front end fall back to
 * assets/images/slots/. Needed after a migration where the database arrived from
 * another environment: the slots then point at attachments that mean something
 * else — or nothing — on this server, and the site keeps showing the wrong
 * pictures even though the theme carries the right ones.
 *
 * Only image slots are cleared; the gallery arrangement and the before/after
 * projects are left alone, and they fall back to the bundle on their own.
 */
add_action('wp_ajax_idealugano_use_bundled', 'idealugano_ajax_use_bundled');
function idealugano_ajax_use_bundled()
{
    check_ajax_referer('idealugano_images_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Permessi insufficienti');
    }

    $before = get_option('idealugano_images', array());
    // Backup non-autoload e con tetto: si tengono solo gli ultimi 5.
    update_option('idealugano_images_backup_' . gmdate('Ymd_His'), $before, false);
    idealugano_prune_image_backups(5);
    update_option('idealugano_images', array());

    // Report how many slots the theme can actually cover on its own.
    $map = get_stylesheet_directory() . '/inc/bundled-images.php';
    $bundled = file_exists($map) ? (array) require $map : array();

    wp_send_json_success(array(
        'cleared'  => count($before),
        'bundled'  => count($bundled),
        'message'  => sprintf(
            'Ripristinate le immagini del tema: %d slot liberati, %d coperti dal tema. Le impostazioni precedenti sono salvate come backup.',
            count($before),
            count($bundled)
        ),
    ));
}


/**
 * Gallery items or before/after projects shipped with the theme.
 *
 * @param string $section 'gallery' or 'before_after'
 * @return array          Empty when the theme carries no bundled content.
 */
function idealugano_get_bundled_content($section)
{
    static $content = null;

    if ($content === null) {
        $file = get_stylesheet_directory() . '/inc/bundled-content.php';
        $content = file_exists($file) ? (array) require $file : array();
    }

    return !empty($content[$section]) ? $content[$section] : array();
}


/** Return the editable before/after projects, including the legacy defaults. */
function idealugano_get_before_after_projects()
{
    $projects = get_option('idealugano_before_after_projects', null);
    if (is_array($projects)) return $projects;

    // Prefer the projects bundled with the theme over the legacy demo entries.
    $bundled = idealugano_get_bundled_content('before_after');
    if ($bundled) return $bundled;

    return array(
        array(
            'id' => '1',
            'title' => 'Divano classico verde',
            'description' => 'Rifacimento completo con velluto verde e nuova imbottitura.',
            'slot_before' => 'ba_1_before',
            'slot_after' => 'ba_1_after',
            'before' => 'before-after/divano-verde-before.jpg',
            'after' => 'before-after/divano-verde-after.jpg',
        ),
        array(
            'id' => '2',
            'title' => 'Progetto 2',
            'description' => '',
            'slot_before' => 'ba_2_before',
            'slot_after' => 'ba_2_after',
        ),
    );
}

/** Return only complete projects for the public carousel. */
function idealugano_get_frontend_before_after_projects()
{
    return array_values(array_filter(idealugano_get_before_after_projects(), function ($project) {
        $before = idealugano_get_slot_image($project['slot_before'] ?? '') || !empty($project['before']);
        $after = idealugano_get_slot_image($project['slot_after'] ?? '') || !empty($project['after']);
        return $before && $after;
    }));
}

function idealugano_get_gallery_categories()
{
    // Ordine = priorita' commerciale (set 2026). 'imbottiti' e' la vecchia
    // categoria unica: viene ancora accettata e mostrata come "Divani e letti".
    return array(
        'tende'        => 'Tende',
        'divani-letti' => 'Divani e letti',
        'rifacimenti'  => 'Rifacimenti',
        'tessuti'      => 'Tessuti',
        'interni'      => 'Interni',
        'cuscini'      => 'Cuscini',
        'paralumi'     => 'Paralumi',
        'oggettistica' => 'Oggettistica',
        'imbottiti'    => 'Imbottiti (vecchia categoria)',
    );
}

/**
 * Categoria effettiva di un elemento galleria: le voci salvate con la vecchia
 * categoria "imbottiti" vengono lette come "rifacimenti" se il titolo parla di
 * rifacimento/rivestimento, altrimenti come "divani-letti".
 */
function idealugano_normalize_gallery_category($category, $title = '')
{
    $category = sanitize_key($category);
    if ($category !== 'imbottiti') {
        return $category;
    }
    return preg_match('/rifoder|ritappezz|rivestit|rifacim|restaur/i', (string) $title) ? 'rifacimenti' : 'divani-letti';
}

function idealugano_get_gallery_items()
{
    $items = get_option('idealugano_gallery_items', null);
    if (is_array($items)) return $items;

    // Fall back to the real work bundled with the theme, so a fresh install
    // shows the actual gallery instead of six demo placeholders.
    $bundled = idealugano_get_bundled_content('gallery');
    if ($bundled) return $bundled;

    $defaults = array(
        array('id' => '01', 'title' => 'Tende su misura', 'category' => 'tende'),
        array('id' => '02', 'title' => 'Rifacimento poltrona', 'category' => 'imbottiti'),
        array('id' => '03', 'title' => 'Cuscini personalizzati', 'category' => 'cuscini'),
        array('id' => '04', 'title' => 'Complemento decorativo', 'category' => 'oggettistica'),
        array('id' => '05', 'title' => 'Paralume su misura', 'category' => 'paralumi'),
        array('id' => '06', 'title' => 'Tende moderne soggiorno', 'category' => 'tende'),
    );
    foreach ($defaults as &$item) $item['slot'] = 'gallery_' . $item['id'];
    return $defaults;
}

function idealugano_get_frontend_gallery_items()
{
    $items = array_filter(idealugano_get_gallery_items(), function ($item) {
        return idealugano_get_slot_image($item['slot'] ?? '');
    });
    foreach ($items as &$item) {
        $item['category'] = idealugano_normalize_gallery_category($item['category'] ?? '', $item['title'] ?? '');
    }
    unset($item);
    return array_values($items);
}


/* ─────────────────────────────────────────────
   3. HELPER: GET IMAGE URL FROM OPTION
   ───────────────────────────────────────────── */

/**
 * Get saved image URL for a slot.
 *
 * @param string $slot_key  The image slot key (e.g. 'hero', 'srv_tappezzeria')
 * @param string $size      WordPress image size (default: 'full')
 * @return string|false     Image URL or false if not set
 */
function idealugano_get_slot_image($slot_key, $size = 'full')
{
    static $images = null;
    if ($images === null) {
        $images = (array) get_option('idealugano_images', array());
    }

    // What the client picked in the admin panel always wins — but only if the
    // file is really there. After a migration the attachment rows often arrive
    // while the files do not: wp_get_attachment_image_url() still returns a URL
    // for those, so without checking the disk the page would fill up with broken
    // images instead of falling back to the copies shipped with the theme.
    if (!empty($images[$slot_key])) {
        $attachment_id = intval($images[$slot_key]);
        $url = wp_get_attachment_image_url($attachment_id, $size);
        if ($url) {
            $file = get_attached_file($attachment_id);
            if ($file && file_exists($file)) {
                idealugano_remember_image_attachment($url, $attachment_id);
                return $url;
            }
        }
    }

    return idealugano_get_bundled_image($slot_key);
}


/**
 * URL of the image the theme ships with for this slot, or false.
 *
 * The theme carries its own copy of every image under assets/images/slots/,
 * mapped by inc/bundled-images.php. That is what makes a deploy self-sufficient:
 * install the theme and the site is fully illustrated, with no media to import
 * and no attachment ids to keep in sync between environments.
 */
function idealugano_get_bundled_image($slot_key)
{
    static $map = null;

    if ($map === null) {
        $manifest = get_stylesheet_directory() . '/inc/bundled-images.php';
        $map = file_exists($manifest) ? (array) require $manifest : array();
    }

    if (empty($map[$slot_key])) {
        return false;
    }

    $file = get_stylesheet_directory() . '/assets/images/slots/' . $map[$slot_key];
    if (!file_exists($file)) {
        return false;
    }

    return get_stylesheet_directory_uri() . '/assets/images/slots/' . $map[$slot_key];
}


/**
 * Registro URL → attachment ID delle immagini risolte in questa richiesta.
 * Serve a idealugano_img_attrs() per stampare srcset/width/height senza
 * ulteriori query (attachment_url_to_postid costerebbe una query per immagine).
 */
function idealugano_remember_image_attachment($url, $attachment_id = null)
{
    static $registry = array();
    if ($attachment_id !== null) {
        $registry[$url] = (int) $attachment_id;
        return $attachment_id;
    }
    return isset($registry[$url]) ? $registry[$url] : 0;
}

/**
 * Attributi responsive per un <img> il cui src viene da idealugano_get_slot_image().
 *
 * Stampa srcset + width/height ricavati dall'allegato (il template mantiene il
 * proprio attributo `sizes`). Per le immagini bundled nel tema (nessun allegato)
 * non stampa nulla. Uso: <img src="..." <?php idealugano_img_attrs($url); ?> ...>
 *
 * @param string $url  URL restituito da idealugano_get_slot_image().
 * @param string $size Dimensione WP di riferimento per srcset (default 'full').
 */
function idealugano_img_attrs($url, $size = 'full')
{
    echo idealugano_get_img_attrs($url, $size); // phpcs:ignore WordPress.Security.EscapeOutput -- gia' escapato
}

function idealugano_get_img_attrs($url, $size = 'full')
{
    $attachment_id = idealugano_remember_image_attachment($url);
    if (!$attachment_id) {
        return '';
    }

    $attrs = array();
    $srcset = wp_get_attachment_image_srcset($attachment_id, $size);
    if ($srcset) {
        $attrs[] = 'srcset="' . esc_attr($srcset) . '"';
    }
    $meta = wp_get_attachment_metadata($attachment_id);
    if (!empty($meta['width']) && !empty($meta['height'])) {
        $attrs[] = 'width="' . (int) $meta['width'] . '" height="' . (int) $meta['height'] . '"';
    }
    return $attrs ? ' ' . implode(' ', $attrs) : '';
}

/**
 * Le chiavi slot ammesse: quelle dichiarate in idealugano_get_image_slots() piu'
 * le famiglie dinamiche (prima/dopo, galleria, marchi) create dal pannello.
 */
function idealugano_is_valid_slot_key($slot)
{
    if (!is_string($slot) || $slot === '' || strlen($slot) > 64) {
        return false;
    }
    foreach (idealugano_get_image_slots() as $group) {
        if (isset($group['slots'][$slot])) {
            return true;
        }
    }
    return (bool) preg_match('/^(ba_[a-z0-9_]+_(before|after)|gallery_[a-z0-9_]+|brand_[a-z0-9_]+)$/', $slot);
}

/**
 * Mantiene al massimo $keep backup idealugano_images_backup_*.
 */
function idealugano_prune_image_backups($keep = 5)
{
    global $wpdb;
    $names = $wpdb->get_col($wpdb->prepare(
        "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s ORDER BY option_name DESC",
        $wpdb->esc_like('idealugano_images_backup_') . '%'
    ));
    foreach (array_slice((array) $names, (int) $keep) as $name) {
        delete_option($name);
    }
}


/* ─────────────────────────────────────────────
   4. AJAX SAVE HANDLER
   ───────────────────────────────────────────── */
add_action('wp_ajax_idealugano_save_image', 'idealugano_ajax_save_image');
function idealugano_ajax_save_image()
{
    check_ajax_referer('idealugano_images_nonce', 'nonce');

    if (!current_user_can('edit_pages')) {
        wp_send_json_error('Permessi insufficienti');
    }

    $slot = isset($_POST['slot']) ? sanitize_key(wp_unslash($_POST['slot'])) : '';
    $attachment_id = isset($_POST['attachment_id']) ? intval($_POST['attachment_id']) : 0;

    if (!idealugano_is_valid_slot_key($slot)) {
        wp_send_json_error('Slot immagine non valido');
    }
    if ($attachment_id > 0 && !wp_attachment_is_image($attachment_id)) {
        wp_send_json_error('L\'allegato selezionato non e\' un\'immagine');
    }

    $images = get_option('idealugano_images', array());
    if ($attachment_id > 0) {
        $images[$slot] = $attachment_id;
    } else {
        unset($images[$slot]);
    }
    update_option('idealugano_images', $images);

    $url = $attachment_id > 0 ? wp_get_attachment_image_url($attachment_id, 'medium_large') : '';
    wp_send_json_success(array('url' => $url));
}

add_action('wp_ajax_idealugano_save_before_after_projects', 'idealugano_ajax_save_before_after_projects');
function idealugano_ajax_save_before_after_projects()
{
    check_ajax_referer('idealugano_images_nonce', 'nonce');
    if (!current_user_can('edit_pages')) wp_send_json_error('Permessi insufficienti');

    $raw = isset($_POST['projects']) ? json_decode(wp_unslash($_POST['projects']), true) : array();
    if (!is_array($raw)) wp_send_json_error('Dati non validi');

    $projects = array();
    foreach ($raw as $item) {
        $id = isset($item['id']) ? sanitize_key($item['id']) : '';
        if (!$id) continue;
        $projects[] = array(
            'id' => $id,
            'title' => sanitize_text_field($item['title'] ?? ''),
            'description' => sanitize_textarea_field($item['description'] ?? ''),
            'slot_before' => 'ba_' . $id . '_before',
            'slot_after' => 'ba_' . $id . '_after',
        );
    }
    update_option('idealugano_before_after_projects', $projects);
    wp_send_json_success();
}

add_action('wp_ajax_idealugano_save_gallery_items', 'idealugano_ajax_save_gallery_items');
function idealugano_ajax_save_gallery_items()
{
    check_ajax_referer('idealugano_images_nonce', 'nonce');
    if (!current_user_can('edit_pages')) wp_send_json_error('Permessi insufficienti');
    $raw = isset($_POST['items']) ? json_decode(wp_unslash($_POST['items']), true) : array();
    if (!is_array($raw)) wp_send_json_error('Dati non validi');
    $categories = idealugano_get_gallery_categories();
    $items = array();
    foreach ($raw as $item) {
        $id = sanitize_key($item['id'] ?? '');
        $category = sanitize_key($item['category'] ?? '');
        if (!$id || !isset($categories[$category])) continue;
        $items[] = array('id' => $id, 'title' => sanitize_text_field($item['title'] ?? ''), 'category' => $category, 'slot' => 'gallery_' . $id);
    }
    update_option('idealugano_gallery_items', $items);
    wp_send_json_success();
}

add_action('wp_ajax_idealugano_save_all', 'idealugano_ajax_save_all');
function idealugano_ajax_save_all()
{
    check_ajax_referer('idealugano_images_nonce', 'nonce');
    if (!current_user_can('edit_pages')) {
        wp_send_json_error('Permessi insufficienti');
    }

    // 1. Save Before/After projects
    if (isset($_POST['projects'])) {
        $raw_projects = json_decode(wp_unslash($_POST['projects']), true);
        if (is_array($raw_projects)) {
            $projects = array();
            foreach ($raw_projects as $item) {
                $id = isset($item['id']) ? sanitize_key($item['id']) : '';
                if (!$id) continue;
                $projects[] = array(
                    'id'          => $id,
                    'title'       => sanitize_text_field($item['title'] ?? ''),
                    'description' => sanitize_textarea_field($item['description'] ?? ''),
                    'slot_before' => 'ba_' . $id . '_before',
                    'slot_after'  => 'ba_' . $id . '_after',
                );
            }
            update_option('idealugano_before_after_projects', $projects);
        }
    }

    // 2. Save Gallery items
    if (isset($_POST['items'])) {
        $raw_items = json_decode(wp_unslash($_POST['items']), true);
        if (is_array($raw_items)) {
            $categories = idealugano_get_gallery_categories();
            $items = array();
            foreach ($raw_items as $item) {
                $id       = sanitize_key($item['id'] ?? '');
                $category = sanitize_key($item['category'] ?? '');
                if (!$id || !isset($categories[$category])) continue;
                $items[] = array(
                    'id'       => $id,
                    'title'    => sanitize_text_field($item['title'] ?? ''),
                    'category' => $category,
                    'slot'     => 'gallery_' . $id,
                );
            }
            update_option('idealugano_gallery_items', $items);
        }
    }

    wp_send_json_success(array('message' => 'Modifiche salvate con successo.'));
}


/* ─────────────────────────────────────────────
   5. ADMIN PAGE SCRIPTS & STYLES
   ───────────────────────────────────────────── */
add_action('admin_enqueue_scripts', 'idealugano_admin_assets');
function idealugano_admin_assets($hook)
{
    if ($hook !== 'toplevel_page_idealugano-images') return;

    wp_enqueue_media();
    wp_enqueue_style(
        'idealugano-admin-images',
        get_stylesheet_directory_uri() . '/assets/css/admin-images.css',
        array(),
        wp_get_theme()->get('Version')
    );
    wp_enqueue_script(
        'idealugano-admin-images',
        get_stylesheet_directory_uri() . '/assets/js/admin-images.js',
        array('jquery', 'media-upload', 'thickbox'),
        wp_get_theme()->get('Version'),
        true
    );
    wp_localize_script('idealugano-admin-images', 'idealuganoAdmin', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('idealugano_images_nonce'),
        'i18n'    => array(
            'selectImage'  => 'Seleziona immagine',
            'useImage'     => 'Usa questa immagine',
            'removeImage'  => 'Rimuovi',
            'saved'        => 'Salvato!',
            'error'        => 'Errore nel salvataggio',
        ),
    ));
}


/* ─────────────────────────────────────────────
   6. ADMIN PAGE RENDER
   ───────────────────────────────────────────── */
function idealugano_images_page()
{
    $slots = idealugano_get_image_slots();
    $images = get_option('idealugano_images', array());
    ?>
    <div class="idealugano-admin-wrap">

        <div class="idealugano-admin-header">
            <div class="idealugano-admin-header__content">
                <h1>Immagini del sito</h1>
                <p>Gestisci tutte le immagini di Idea Lugano da un unico pannello. Clicca su una card per caricare o sostituire l'immagine.</p>
            </div>
        </div>

        <?php
        // Section index. The panel holds eight sections, so the ones further
        // down (Tipologie Tende, Prodotti…) are easy to miss without it; the
        // counters also show at a glance where images are still missing.
        ?>
        <?php
        // How many slots are currently served by the theme's own copies. When a
        // migration leaves the slots pointing elsewhere, this is the number that
        // tells the story at a glance.
        $bundled_map = file_exists(get_stylesheet_directory() . '/inc/bundled-images.php')
            ? (array) require get_stylesheet_directory() . '/inc/bundled-images.php'
            : array();
        $from_theme_count = 0;
        foreach (array_keys($bundled_map) as $bk) {
            $u = idealugano_get_slot_image($bk, 'medium_large');
            if ($u && strpos($u, '/assets/images/slots/') !== false) {
                $from_theme_count++;
            }
        }
        ?>
        <?php if ($bundled_map): ?>
            <div class="idealugano-admin-bundle">
                <div class="idealugano-admin-bundle__text">
                    <strong>Immagini incluse nel tema</strong>
                    <span>
                        <?php
                        echo esc_html(sprintf(
                            'Il tema porta con sé %d immagini per %d slot. In questo momento %d slot le stanno usando.',
                            count(array_unique($bundled_map)),
                            count($bundled_map),
                            $from_theme_count
                        ));
                        ?>
                        <br>
                        Se dopo una migrazione il sito mostra immagini sbagliate, usa il pulsante:
                        libera gli slot e ogni sezione torna a usare l'immagine del tema.
                        Le impostazioni attuali vengono salvate come backup.
                    </span>
                </div>
                <button type="button" class="button" id="idealugano-use-bundled">
                    Usa le immagini del tema
                </button>
            </div>
        <?php endif; ?>

        <nav class="idealugano-admin-nav" aria-label="Sezioni del pannello">
            <div class="idealugano-admin-nav__inner">
                <a class="idealugano-admin-nav__link" href="#section-before-after">
                    <span aria-hidden="true">🔄</span> Before / After
                </a>
                <a class="idealugano-admin-nav__link" href="#section-galleria">
                    <span aria-hidden="true">🖼️</span> Galleria Lavori
                </a>
                <?php foreach ($slots as $group_key => $group): ?>
                    <?php
                    $nav_filled = 0;
                    foreach (array_keys($group['slots']) as $nav_sk) {
                        if (!empty($images[$nav_sk])) $nav_filled++;
                    }
                    $nav_total = count($group['slots']);
                    ?>
                    <a class="idealugano-admin-nav__link" href="#section-<?php echo esc_attr($group_key); ?>">
                        <span aria-hidden="true"><?php echo $group['icon']; ?></span>
                        <?php echo esc_html($group['label']); ?>
                        <span class="idealugano-admin-nav__count<?php echo ($nav_filled === $nav_total) ? ' is-complete' : ''; ?>">
                            <?php echo $nav_filled . '/' . $nav_total; ?>
                        </span>
                    </a>
                <?php endforeach; ?>
            </div>
        </nav>

        <div class="idealugano-admin-sections">
            <?php idealugano_render_before_after_admin($images); ?>
            <?php idealugano_render_gallery_admin($images); ?>
            <?php foreach ($slots as $group_key => $group): ?>
                <div class="idealugano-admin-section" id="section-<?php echo esc_attr($group_key); ?>">
                    <div class="idealugano-admin-section__header">
                        <span class="idealugano-admin-section__icon"><?php echo $group['icon']; ?></span>
                        <h2><?php echo esc_html($group['label']); ?></h2>
                        <span class="idealugano-admin-section__count">
                            <?php
                            $filled = 0;
                            foreach ($group['slots'] as $sk => $sv) {
                                if (!empty($images[$sk])) $filled++;
                            }
                            echo $filled . '/' . count($group['slots']);
                            ?>
                        </span>
                    </div>

                    <div class="idealugano-admin-grid">
                        <?php foreach ($group['slots'] as $slot_key => $slot): ?>
                            <?php
                            $attachment_id = isset($images[$slot_key]) ? intval($images[$slot_key]) : 0;
                            $img_url = $attachment_id ? wp_get_attachment_image_url($attachment_id, 'medium_large') : '';

                            // Show what the visitor actually sees, not just what the
                            // option says: after a migration an attachment can exist
                            // with its file gone, in which case the front end falls
                            // back to the copy bundled with the theme. Without this
                            // the panel and the site can disagree without explaining why.
                            $att_file  = $attachment_id ? get_attached_file($attachment_id) : '';
                            $att_ok    = $att_file && file_exists($att_file);
                            $live_url  = idealugano_get_slot_image($slot_key, 'medium_large');
                            $from_theme = $live_url && strpos($live_url, '/assets/images/slots/') !== false;

                            if (!$att_ok && $live_url) {
                                $img_url = $live_url; // preview what the site really shows
                            }
                            $has_image = !empty($img_url);
                            ?>
                            <div class="idealugano-image-card <?php echo $has_image ? 'has-image' : ''; ?>"
                                 data-slot="<?php echo esc_attr($slot_key); ?>"
                                 data-attachment-id="<?php echo esc_attr($attachment_id); ?>">

                                <div class="idealugano-image-card__preview">
                                    <?php if ($has_image): ?>
                                        <img src="<?php echo esc_url($img_url); ?>" alt="<?php echo esc_attr($slot['label']); ?>">
                                    <?php else: ?>
                                        <div class="idealugano-image-card__empty">
                                            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                                                <rect x="3" y="3" width="18" height="18" rx="2"/>
                                                <circle cx="8.5" cy="8.5" r="1.5"/>
                                                <path d="M21 15l-5-5L5 21"/>
                                            </svg>
                                            <span>Clicca per aggiungere</span>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <div class="idealugano-image-card__info">
                                    <h3><?php echo esc_html($slot['label']); ?></h3>
                                    <p><?php echo esc_html($slot['description']); ?></p>
                                    <?php if ($live_url): ?>
                                        <span class="idealugano-image-card__origin<?php echo $from_theme ? ' is-theme' : ''; ?>">
                                            <?php
                                            if ($from_theme) {
                                                echo $attachment_id && ! $att_ok
                                                    ? 'dal tema (il file caricato non esiste più)'
                                                    : 'dal tema';
                                            } else {
                                                echo 'dalla libreria media';
                                            }
                                            ?>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="idealugano-image-card__actions">
                                    <button class="idealugano-image-card__btn idealugano-image-card__btn--select" type="button">
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                                        <?php echo $has_image ? 'Sostituisci' : 'Carica'; ?>
                                    </button>
                                    <?php if ($has_image): ?>
                                        <button class="idealugano-image-card__btn idealugano-image-card__btn--remove" type="button">
                                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
                                            Rimuovi
                                        </button>
                                    <?php endif; ?>
                                </div>

                                <div class="idealugano-image-card__toast"></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Sticky Universal Save Bar -->
        <div class="idealugano-admin-sticky-bar" id="idealugano-sticky-bar">
            <div class="idealugano-admin-sticky-bar__inner">
                <div class="idealugano-admin-sticky-bar__status" id="idealugano-sticky-status">
                    <span class="idealugano-status-dot" id="idealugano-status-dot"></span>
                    <span class="idealugano-status-text" id="idealugano-status-text">Tutte le modifiche salvate</span>
                </div>
                <div class="idealugano-admin-sticky-bar__actions">
                    <button type="button" class="button button-primary idealugano-btn-save-all" id="idealugano-save-all-btn">
                        <span class="idealugano-btn-icon-wrap" aria-hidden="true">
                            <svg class="idealugano-btn-icon idealugano-icon-check" width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M3.8 10.2L7.8 14.2L16.2 5.8" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            <svg class="idealugano-btn-icon idealugano-icon-spinner" width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="2.4" stroke-dasharray="40 18" stroke-linecap="round"/>
                            </svg>
                        </span>
                        <span class="idealugano-btn-text">Salva modifiche</span>
                    </button>
                </div>
            </div>
        </div>

    </div>
    <?php
}

function idealugano_render_before_after_admin($images)
{
    $projects = idealugano_get_before_after_projects();
    ?>
    <div class="idealugano-admin-section idealugano-ba-admin" id="section-before-after">
        <div class="idealugano-admin-section__header">
            <span class="idealugano-admin-section__icon">🔄</span>
            <h2>Before / After</h2>
            <button type="button" class="button button-primary idealugano-ba-add">Aggiungi progetto</button>
        </div>
        <p class="idealugano-ba-admin__intro">Aggiungi i progetti, inserisci titolo e descrizione e scegli le due fotografie. Salva le modifiche con il pulsante universale in basso.</p>
        <div class="idealugano-ba-projects">
            <?php foreach ($projects as $project) idealugano_render_before_after_project($project, $images); ?>
        </div>
    </div>
    <?php
}

function idealugano_render_before_after_project($project, $images)
{
    $id = sanitize_key($project['id']);
    ?>
    <div class="idealugano-ba-project" data-project-id="<?php echo esc_attr($id); ?>">
        <div class="idealugano-ba-project__heading">
            <strong>Progetto</strong>
            <button type="button" class="button-link-delete idealugano-ba-remove">Rimuovi progetto</button>
        </div>
        <div class="idealugano-ba-fields">
            <label>Titolo<input type="text" class="idealugano-ba-title" value="<?php echo esc_attr($project['title'] ?? ''); ?>"></label>
            <label>Descrizione<textarea class="idealugano-ba-description" rows="2"><?php echo esc_textarea($project['description'] ?? ''); ?></textarea></label>
        </div>
        <div class="idealugano-admin-grid idealugano-ba-images">
            <?php foreach (array('before' => 'Prima', 'after' => 'Dopo') as $side => $label):
                $slot = 'ba_' . $id . '_' . $side;
                $attachment_id = isset($images[$slot]) ? intval($images[$slot]) : 0;
                $img_url = $attachment_id ? wp_get_attachment_image_url($attachment_id, 'medium_large') : '';
            ?>
                <div class="idealugano-image-card <?php echo $img_url ? 'has-image' : ''; ?>" data-slot="<?php echo esc_attr($slot); ?>" data-attachment-id="<?php echo esc_attr($attachment_id); ?>">
                    <div class="idealugano-image-card__preview"><?php if ($img_url): ?><img src="<?php echo esc_url($img_url); ?>" alt=""><?php else: ?><div class="idealugano-image-card__empty"><span>Clicca per aggiungere</span></div><?php endif; ?></div>
                    <div class="idealugano-image-card__info"><h3><?php echo esc_html($label); ?></h3><p>Foto "<?php echo strtolower(esc_html($label)); ?>" del restauro</p></div>
                    <div class="idealugano-image-card__actions"><button class="idealugano-image-card__btn idealugano-image-card__btn--select" type="button"><?php echo $img_url ? 'Sostituisci' : 'Carica'; ?></button><?php if ($img_url): ?><button class="idealugano-image-card__btn idealugano-image-card__btn--remove" type="button">Rimuovi</button><?php endif; ?></div>
                    <div class="idealugano-image-card__toast"></div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php
}

function idealugano_render_gallery_admin($images)
{
    ?>
    <div class="idealugano-admin-section idealugano-gallery-admin" id="section-galleria">
        <div class="idealugano-admin-section__header"><span class="idealugano-admin-section__icon">📸</span><h2>Galleria Lavori</h2><button type="button" class="button button-primary idealugano-gallery-add">Aggiungi immagine</button></div>
        <p class="idealugano-ba-admin__intro">Aggiungi tutte le immagini desiderate e assegna a ciascuna una categoria. Salva le modifiche con il pulsante universale in basso.</p>
        <div class="idealugano-gallery-items">
            <?php foreach (idealugano_get_gallery_items() as $item) idealugano_render_gallery_item($item, $images); ?>
        </div>
    </div>
    <?php
}

function idealugano_render_gallery_item($item, $images)
{
    $id = sanitize_key($item['id']); $slot = 'gallery_' . $id;
    $attachment_id = isset($images[$slot]) ? intval($images[$slot]) : 0;
    $img_url = $attachment_id ? wp_get_attachment_image_url($attachment_id, 'medium_large') : '';
    ?>
    <div class="idealugano-gallery-item" data-gallery-id="<?php echo esc_attr($id); ?>">
        <div class="idealugano-image-card <?php echo $img_url ? 'has-image' : ''; ?>" data-slot="<?php echo esc_attr($slot); ?>" data-attachment-id="<?php echo esc_attr($attachment_id); ?>">
            <div class="idealugano-image-card__preview"><?php if ($img_url): ?><img src="<?php echo esc_url($img_url); ?>" alt=""><?php else: ?><div class="idealugano-image-card__empty"><span>Clicca per aggiungere</span></div><?php endif; ?></div>
            <div class="idealugano-gallery-item__fields">
                <label>Titolo<input class="idealugano-gallery-title" type="text" value="<?php echo esc_attr($item['title'] ?? ''); ?>"></label>
                <label>Categoria<select class="idealugano-gallery-category"><?php foreach (idealugano_get_gallery_categories() as $value => $label): ?><option value="<?php echo esc_attr($value); ?>" <?php selected($item['category'] ?? '', $value); ?>><?php echo esc_html($label); ?></option><?php endforeach; ?></select></label>
            </div>
            <div class="idealugano-image-card__actions"><button class="idealugano-image-card__btn idealugano-image-card__btn--select" type="button"><?php echo $img_url ? 'Sostituisci' : 'Carica'; ?></button><?php if ($img_url): ?><button class="idealugano-image-card__btn idealugano-image-card__btn--remove" type="button">Rimuovi foto</button><?php endif; ?><button class="idealugano-image-card__btn idealugano-gallery-delete" type="button">Elimina voce</button></div><div class="idealugano-image-card__toast"></div>
        </div>
    </div>
    <?php
}
