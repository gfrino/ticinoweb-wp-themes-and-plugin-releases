<?php
/**
 * SEO Schema — arricchimento del JSON-LD LocalBusiness generato da tW SEO
 *
 * Meta description, Open Graph, Twitter Card e lo schema base sono emessi dal
 * parent theme (ticinoweb-ai-theme/inc/seo.php) a partire dalle opzioni del
 * pannello "tW SEO". Questo file NON stampa più tag propri (fino alla 1.9.x
 * duplicava description, og:* e lo script ld+json): si limita ad agganciarsi
 * ai filtri del parent per aggiungere i dati specifici dell'attività
 * (recapiti completi, coordinate, area servita, competenze).
 *
 * @package Idealugano
 * @version 2.2.1
 */

/* ─────────────────────────────────────────────
   JSON-LD LOCALBUSINESS — dati aggiuntivi
   ───────────────────────────────────────────── */
add_filter('ticinoweb_seo_jsonld_org_schema', 'idealugano_enrich_org_schema');
function idealugano_enrich_org_schema($schema)
{
    $site    = idealugano_get_site_data();
    $contact = $site['contact'];

    // Il pannello tW SEO permette di scegliere "Organization": qui il tipo
    // corretto è sempre LocalBusiness (atelier con sede fisica).
    $schema['@type'] = 'LocalBusiness';

    if (empty($schema['description'])) {
        $desc = trim((string) get_option('tw_seo_description'));
        $schema['description'] = $desc !== '' ? $desc : $site['seo']['home_desc'];
    }

    $phones = array_values(array_filter(array(
        $contact['phone_landline'] ?? '',
        $contact['phone'] ?? '',
    )));
    if (!empty($phones)) {
        $schema['telephone'] = count($phones) === 1 ? $phones[0] : $phones;
    }

    if (!empty($contact['email'])) {
        $schema['email'] = $contact['email'];
    }

    // Indirizzo strutturato: il parent scrive solo streetAddress.
    $city = (string) ($contact['city'] ?? '');
    $schema['address'] = array(
        '@type'           => 'PostalAddress',
        'streetAddress'   => trim($contact['address'] . (empty($contact['address_2']) ? '' : ', ' . $contact['address_2'])),
        'addressLocality' => trim(preg_replace('/^\d{4}\s*/', '', $city)),
        'addressRegion'   => 'Ticino',
        'postalCode'      => (preg_match('/\b(\d{4})\b/', $city, $m) ? $m[1] : ''),
        'addressCountry'  => 'CH',
    );

    $schema['geo'] = array(
        '@type'     => 'GeoCoordinates',
        'latitude'  => 46.0543466,
        'longitude' => 8.9244311,
    );

    // Sede a Lugano, interventi in tutta la Svizzera e all'estero (richiesta cliente ott 2026).
    $schema['areaServed'] = array(
        array('@type' => 'City', 'name' => 'Lugano'),
        array('@type' => 'AdministrativeArea', 'name' => 'Ticino'),
        array('@type' => 'Country', 'name' => 'Svizzera'),
        array('@type' => 'Place', 'name' => 'Estero'),
    );

    $schema['hasMap'] = !empty($contact['maps_url']) ? $contact['maps_url'] : 'https://maps.app.goo.gl/X1EE7Ba3UHm9cBoU6';

    // sameAs: unione tra i profili del pannello tW SEO e l'Instagram del CMS.
    $same_as = isset($schema['sameAs']) ? (array) $schema['sameAs'] : array();
    if (!empty($contact['instagram'])) {
        $same_as[] = $contact['instagram'];
    }
    $same_as = array_values(array_unique(array_filter(array_map('trim', $same_as))));
    if (!empty($same_as)) {
        $schema['sameAs'] = $same_as;
    }

    $schema['priceRange']         = '$$';
    $schema['currenciesAccepted'] = 'CHF';
    $schema['paymentAccepted']    = 'Cash, Credit Card';
    // Competenze = le parole chiave delle landing servizi, in ordine di priorita'.
    $knows = array('Tappezzeria');
    if (function_exists('idealugano_get_landings')) {
        foreach (idealugano_get_landings() as $landing) {
            $knows = array_merge($knows, $landing['keywords']);
        }
    }
    $knows[] = 'Cuscini e copriletti su misura';
    $schema['knowsAbout'] = array_values(array_unique($knows));

    // Catalogo servizi: un Service per landing, con URL della pagina dedicata.
    if (function_exists('idealugano_get_landings')) {
        $offers = array();
        foreach (idealugano_get_landings() as $slug => $landing) {
            $offers[] = array(
                '@type'       => 'Offer',
                'itemOffered' => array(
                    '@type' => 'Service',
                    'name'  => $landing['service_type'],
                    'url'   => idealugano_landing_url($slug),
                ),
            );
        }
        $schema['hasOfferCatalog'] = array(
            '@type'           => 'OfferCatalog',
            'name'            => 'Servizi Idea Lugano',
            'itemListElement' => $offers,
        );
    }

    return $schema;
}

/* ─────────────────────────────────────────────
   OPEN GRAPH — locale svizzero
   ───────────────────────────────────────────── */
add_filter('ticinoweb_seo_og_locale', 'idealugano_og_locale');
function idealugano_og_locale($locale)
{
    return 'it_CH';
}

/* ─────────────────────────────────────────────
   META DESCRIPTION — archivio Occasioni
   (il parent gestisce singoli e pagine; l'archivio CPT non ha meta proprio)
   ───────────────────────────────────────────── */
add_filter('ticinoweb_seo_meta_description', 'idealugano_archive_meta_description');
function idealugano_archive_meta_description($desc)
{
    // Il parent passa qui la description globale del sito: sull'archivio
    // occasioni va sempre sostituita con quella specifica.
    if (is_post_type_archive('occasione')) {
        return 'Occasioni Idea Lugano: pezzi unici d\'atelier, campionari, divani, tende e complementi d\'arredo a prezzo speciale, visionabili su appuntamento a Bedano, Lugano.';
    }
    return $desc;
}

/* ─────────────────────────────────────────────
   JSON-LD — Product + BreadcrumbList sulla singola occasione
   Il parent emette schema solo in home e sui post: qui non c'e' duplicazione.
   ───────────────────────────────────────────── */
add_action('wp_head', 'idealugano_occasione_schema', 6);
function idealugano_occasione_schema()
{
    if (!is_singular('occasione') || !function_exists('idealugano_get_occasione_meta')) {
        return;
    }

    $post = get_post();
    $meta = idealugano_get_occasione_meta($post->ID);
    $site = idealugano_get_site_data();

    $availability = array(
        'disponibile' => 'https://schema.org/InStock',
        'pezzo_unico' => 'https://schema.org/LimitedAvailability',
        'campionario' => 'https://schema.org/LimitedAvailability',
        'trattativa'  => 'https://schema.org/LimitedAvailability',
        'venduto'     => 'https://schema.org/SoldOut',
    );

    $description = has_excerpt($post) ? get_the_excerpt($post) : wp_trim_words(wp_strip_all_tags(strip_shortcodes($post->post_content)), 40, '');

    $product = array(
        '@context'    => 'https://schema.org',
        '@type'       => 'Product',
        'name'        => get_the_title($post),
        'url'         => get_permalink($post),
        'description' => $description,
        'brand'       => array('@type' => 'Brand', 'name' => $site['brand']),
    );
    if (has_post_thumbnail($post)) {
        $product['image'] = get_the_post_thumbnail_url($post, 'large');
    }
    if (!empty($meta['code'])) {
        $product['sku'] = $meta['code'];
    }
    if (!empty($meta['materials'])) {
        $product['material'] = $meta['materials'];
    }
    if (!empty($meta['type'])) {
        $product['category'] = $meta['type'];
    }

    // Offer solo con prezzo numerico: "su richiesta" non e' un prezzo per Google.
    $numeric = preg_replace('/[^\d.,]/', '', str_replace(array("'", '’', ' '), '', (string) $meta['raw_price']));
    if ($numeric !== '' && preg_match('/^\d+([.,]\d{1,2})?$/', $numeric)) {
        $product['offers'] = array(
            '@type'         => 'Offer',
            'price'         => number_format((float) str_replace(',', '.', $numeric), 2, '.', ''),
            'priceCurrency' => 'CHF',
            'availability'  => isset($availability[$meta['status']]) ? $availability[$meta['status']] : 'https://schema.org/InStock',
            'itemCondition' => 'https://schema.org/UsedCondition',
            'url'           => get_permalink($post),
            'seller'        => array('@type' => 'LocalBusiness', 'name' => $site['brand']),
        );
    }

    $breadcrumb = array(
        '@context'        => 'https://schema.org',
        '@type'           => 'BreadcrumbList',
        'itemListElement' => array(
            array('@type' => 'ListItem', 'position' => 1, 'name' => 'Home', 'item' => home_url('/')),
            array('@type' => 'ListItem', 'position' => 2, 'name' => 'Occasioni', 'item' => get_post_type_archive_link('occasione')),
            array('@type' => 'ListItem', 'position' => 3, 'name' => get_the_title($post)),
        ),
    );

    $flags = JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE;
    echo '<script type="application/ld+json">' . wp_json_encode($product, $flags) . "</script>\n";
    echo '<script type="application/ld+json">' . wp_json_encode($breadcrumb, $flags) . "</script>\n";
}

/* ─────────────────────────────────────────────
   JSON-LD — Service + BreadcrumbList + FAQPage sulle landing servizi
   Il parent emette schema solo in home e sui post: nessuna duplicazione.
   ───────────────────────────────────────────── */
add_action('wp_head', 'idealugano_landing_schema', 6);
function idealugano_landing_schema()
{
    if (!is_page() || !is_page_template('page-landing.php') || !function_exists('idealugano_get_current_landing')) {
        return;
    }
    $landing = idealugano_get_current_landing();
    if (!$landing) {
        return;
    }

    $site     = idealugano_get_site_data();
    $contact  = $site['contact'];
    $url      = get_permalink();
    $hero     = idealugano_get_slot_image($landing['hero_slot']);
    $provider = array(
        '@type'     => 'LocalBusiness',
        'name'      => $site['brand'],
        'url'       => home_url('/'),
        'telephone' => $contact['phone_landline'] ?: $contact['phone'],
        'address'   => array(
            '@type'           => 'PostalAddress',
            'streetAddress'   => $contact['address'],
            'addressLocality' => 'Bedano',
            'addressRegion'   => 'Ticino',
            'postalCode'      => '6930',
            'addressCountry'  => 'CH',
        ),
    );

    $service = array(
        '@context'    => 'https://schema.org',
        '@type'       => 'Service',
        'name'        => $landing['title'],
        'serviceType' => $landing['service_type'],
        'description' => $landing['seo_desc'],
        'url'         => $url,
        'provider'    => $provider,
        'areaServed'  => array(
            array('@type' => 'City', 'name' => 'Lugano'),
            array('@type' => 'AdministrativeArea', 'name' => 'Ticino'),
            array('@type' => 'Country', 'name' => 'Svizzera'),
            array('@type' => 'Place', 'name' => 'Estero'),
        ),
        'availableChannel' => array(
            '@type'                => 'ServiceChannel',
            'serviceUrl'           => $url . '#richiesta',
            'servicePhone'         => $contact['phone_landline'] ?: $contact['phone'],
            'availableLanguage'    => array('it', 'de', 'fr'),
        ),
    );
    if ($hero) {
        $service['image'] = $hero;
    }
    $brands = array();
    foreach ($landing['suppliers']['items'] as $item) {
        $brands[$item['brand']] = array('@type' => 'Brand', 'name' => $item['brand']);
    }
    if ($brands) {
        $service['brand'] = array_values($brands);
    }

    $breadcrumb = array(
        '@context'        => 'https://schema.org',
        '@type'           => 'BreadcrumbList',
        'itemListElement' => array(
            array('@type' => 'ListItem', 'position' => 1, 'name' => 'Home', 'item' => home_url('/')),
            array('@type' => 'ListItem', 'position' => 2, 'name' => 'Servizi', 'item' => home_url('/servizi/')),
            array('@type' => 'ListItem', 'position' => 3, 'name' => $landing['menu_label']),
        ),
    );

    $flags = JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE;
    echo '<script type="application/ld+json">' . wp_json_encode($service, $flags) . "</script>\n";
    echo '<script type="application/ld+json">' . wp_json_encode($breadcrumb, $flags) . "</script>\n";

    // FAQPage: con il parent lo stampa il parent nel footer (una volta per pagina).
    idealugano_faq_schema(idealugano_landing_faq($landing));
}
