<?php
/**
 * FAQ di Idea Lugano sul sistema del parent (ticinoweb-ai-theme >= 3.13.0).
 *
 * Le FAQ si gestiscono in Bacheca → FAQ:
 * - "FAQ Idea Lugano" (`faq-idea-lugano`): la pagina /faq/, una sezione per
 *   argomento (titolo + descrizione della sezione = intestazione della pagina);
 * - "FAQ <servizio>" (`faq-<slug landing>`): le FAQ di ogni landing.
 *
 * I testi qui sotto e le chiavi `faq` di inc/landings.php servono solo alla
 * migrazione iniziale (una volta, flag `idealugano_faqs_parent_migrated_v1`) e
 * come riserva se il parent non e' aggiornato. Dopo la migrazione fa fede la
 * bacheca: modificare qui non cambia il sito.
 *
 * @package Idealugano
 */

if (!defined('ABSPATH')) {
    exit;
}

define('IDEALUGANO_FAQ_SET', 'faq-idea-lugano');

/** Contenuto iniziale della pagina FAQ (id = anchor storico della sezione). */
function idealugano_faq_seed_categories()
{
    return array(
        array(
            'id'    => 'arredamento-consulenza',
            'title' => 'Arredamento e Consulenza d\'Interni a Lugano e in Ticino',
            'desc'  => 'Informazioni su progettazione, consulenza personalizzata e soluzioni su misura per la casa.',
            'items' => array(
                array(
                    'q' => 'Dove trovare consulenza per l\'arredamento d\'interni a Lugano e in Ticino?',
                    'a' => 'A Lugano e in tutto il Canton Ticino è possibile rivolgersi a Idea Lugano, atelier specializzato nella progettazione tessile e nell\'arredamento su misura. Il team affianca privati, architetti e designer nella scelta di tessuti, finiture e arredi coordinati, organizzando incontri dedicati presso il laboratorio o direttamente a domicilio.',
                ),
                array(
                    'q' => 'Come si svolge una consulenza d\'arredo con Idea Lugano?',
                    'a' => 'Il percorso inizia con una fase di ascolto per comprendere lo stile di vita, i gusti e le esigenze funzionali del cliente. Seguono il rilievo delle misure sul posto, la presentazione di campionari tessili e materiali d\'arredo selezionati, e la formulazione di una proposta su misura con preventivo dettagliato e trasparente.',
                ),
                array(
                    'q' => 'Idea Lugano fornisce anche tappeti, moquette, carte da parati e illuminazione?',
                    'a' => 'Sì. Oltre a tende, imbottiti e tessuti, forniamo tutto ciò che serve ad arredare una casa o un appartamento: tappeti su misura, moquette, carte da parati e rivestimenti murali, illuminazione decorativa e complementi, con un unico interlocutore che coordina fornitori e posa.',
                ),
                array(
                    'q' => 'Idea Lugano interviene anche fuori dal Canton Ticino?',
                    'a' => 'Sì. L\'atelier è a Bedano, alle porte di Lugano, e molti progetti nascono nel Luganese e in Ticino, ma Idea Lugano realizza tende, mobili imbottiti, forniture tessili e progetti d\'arredo in tutta la Svizzera e anche all\'estero, organizzando sopralluoghi, consegna e posa in opera ovunque si trovi la casa del cliente.',
                ),
                array(
                    'q' => 'Qual è la differenza tra un negozio di mobili e un atelier di tappezzeria e arredo su misura?',
                    'a' => 'Un negozio di mobili propone prevalentemente arredi standardizzati di serie, mentre un atelier artigianale come Idea Lugano crea pezzi unici o personalizzati in base alle esatte dimensioni e allo stile degli ambienti. Questo approccio permette di recuperare arredi preesistenti con nuova tappezzeria, realizzare tendaggi su misura e coordinare ogni dettaglio tessile con precisione millimetrica.',
                ),
            ),
        ),
        array(
            'id'    => 'tende-schermature',
            'title' => 'Tende su Misura e Sistemi di Schermatura Solare',
            'desc'  => 'Dettagli su tendaggi d\'arredo, tende tecniche, tessuti e sistemi motorizzati per finestre.',
            'items' => array(
                array(
                    'q' => 'Dove posso far realizzare tende su misura a Lugano?',
                    'a' => 'Idea Lugano realizza tendaggi su misura per ogni tipologia di finestra e ambiente abitativo o professionale. Nel laboratorio di Bedano vengono confezionate tende moderne a onda, tende classiche arricciate, tende a pacchetto e pannelli scorrevoli, garantendo un servizio completo che include il rilievo misure e la posa in opera a regola d\'arte.',
                ),
                array(
                    'q' => 'Quali tipologie di tende per interni propone Idea Lugano?',
                    'a' => 'La proposta comprende tendaggi decorativi tradizionali e contemporanei, tende a rullo tecniche, veneziane su misura, tende plissettate e soluzioni oscuranti o filtranti. Ogni soluzione viene studiata per bilanciare luce naturale, privacy, isolamento termico ed estetica complessiva dello spazio.',
                ),
                array(
                    'q' => 'Idea Lugano installa anche sistemi di binari motorizzati e schermature tecniche?',
                    'a' => 'Sì, attraverso la collaborazione con marchi specializzati come Silent Gliss, MHZ e Kadeco, Idea Lugano installa binari per tende, sistemi scorrevoli tecnici e schermature solari motorizzate integrabili con impianti domotici moderni.',
                ),
                array(
                    'q' => 'Posso acquistare solo il tessuto, al metro, senza confezione?',
                    'a' => 'Sì. Idea Lugano vende tessuti d\'arredamento al metro dai campionari di Dedar, Decortex Firenze e degli altri distributori rappresentati, anche a chi vuole farli confezionare altrove o lavorarli personalmente. In atelier aiutiamo a calcolare metrature, altezze e verso del disegno.',
                ),
                array(
                    'q' => 'Come scegliere il tessuto giusto per le tende di casa?',
                    'a' => 'La scelta dipende dall\'esposizione solare, dal livello di privacy desiderato e dallo stile dell\'arredamento. Presso l\'atelier di Idea Lugano è possibile visionare e toccare con mano un\'ampia selezione di lini, sete, velluti, cotoni e tessuti tecnici ignifughi, ricevendo consigli tecnici sulla caduta del tessuto e sulla manutenzione nel tempo.',
                ),
            ),
        ),
        array(
            'id'    => 'tappezzeria-imbottiti',
            'title' => 'Tappezzeria Artigianale e Rifacimento Mobili Imbottiti',
            'desc'  => 'Restauro, rivestimento sartoriale e rinnovamento di divani, poltrone, sedie e testiere.',
            'items' => array(
                array(
                    'q' => 'Idea Lugano vende anche divani e letti nuovi su misura?',
                    'a' => 'Sì. Oltre al rifacimento, Idea Lugano fornisce mobili imbottiti nuovi realizzati su misura: divani lineari, angolari e modulari, poltrone, panche, letti imbottiti e testiere, rivestiti con il tessuto o la pelle scelti dal cliente. Per il riposo è rivenditore Tréca Paris (materassi, sommier e testiere confezionati a mano).',
                ),
                array(
                    'q' => 'A chi posso rivolgermi a Lugano per rinnovare o ritappezzare un divano o una poltrona?',
                    'a' => 'Idea Lugano offre un servizio specializzato di tappezzeria artigianale per il rifacimento e il restauro di divani, poltrone, sedie, panche e testate letto. L\'intervento comprende la sostituzione o l\'integrazione delle imbottiture, il controllo del molleggio e il rivestimento sartoriale con tessuti o pelli di alta qualità.',
                ),
                array(
                    'q' => 'Conviene rifare un divano o una poltrona esistente invece di comprarne uno nuovo?',
                    'a' => 'Il rifacimento è particolarmente conveniente quando il mobile presenta una struttura solida, un valore affettivo o proporzioni perfette per la stanza che difficilmente si troverebbero sul mercato. Rinnovare un imbottito permette di scegliere esattamente il tessuto e il comfort desiderati, valorizzando un arredo destinato a durare ancora molti anni in un\'ottica di sostenibilità.',
                ),
                array(
                    'q' => 'Quali materiali vengono utilizzati per le imbottiture e i rivestimenti?',
                    'a' => 'Vengono impiegati materiali conformi agli standard artigianali più rigorosi, tra cui espansi a densità differenziata per un sostegno ergonomico, ovatte traspiranti, cinghie elastiche rinforzate e tessuti d\'arredo ad alta resistenza allo sfregamento (test Martindale), oltre a passamanerie e cordoni decorativi.',
                ),
                array(
                    'q' => 'Idea Lugano realizza anche testate per letti imbottite su misura?',
                    'a' => 'Sì, l\'atelier progetta e realizza testate letto imbottite su disegno del cliente o su progetto d\'interior design, disponibili con lavorazione liscia, capitonné, a pannelli geometrici o con bordure a contrasto, perfettamente coordinate a copriletti e cuscini.',
                ),
            ),
        ),
        array(
            'id'    => 'cuscini-paralumi-complementi',
            'title' => 'Cuscini, Paralumi e Complementi d\'Arredo',
            'desc'  => 'Personalizzazione tessile per accessori, imbottiti d\'arredo e illuminazione su misura.',
            'items' => array(
                array(
                    'q' => 'È possibile ordinare cuscini personalizzati per divani, letti o spazi esterni?',
                    'a' => 'Certamente. Idea Lugano confeziona cuscini decorativi e funzionali in qualsiasi dimensione, forma e spessore, curando dettagli quali cerniere a scomparsa, piping, profili in cordoncino, bottoni e impunture sartoriali. Vengono realizzati anche cuscini su misura per panche fisse, bovindo e arredi outdoor con tessuti idrorepellenti e resistenti ai raggi UV.',
                ),
                array(
                    'q' => 'In cosa consiste il servizio di rifacimento e rivestimento paralumi?',
                    'a' => 'Il servizio permette di restaurare lampade d\'epoca o rinnovare paralumi contemporanei usurati o fuori stile. Nel laboratorio vengono ricoperti telai esistenti con sete, lini o pergamene coordinati al resto della stanza, ricreando forme coniche, cilindriche o sagomate con finiture accurate.',
                ),
                array(
                    'q' => 'Che tipo di oggettistica e accessori per la casa si trovano da Idea Lugano?',
                    'a' => 'Idea Lugano propone una curata selezione di complementi d\'arredo, tra cui plaid pregiati, copriletti artigianali, vasi, candele profumate e piccoli oggetti decorativi scelti per dialogare armoniosamente con i tessuti e con l\'atmosfera degli interni.',
                ),
            ),
        ),
        array(
            'id'    => 'marchi-qualita',
            'title' => 'Marchi Partner e Qualità dei Materiali',
            'desc'  => 'Collaborazioni con manifatture d\'eccellenza per schermature solari e sistemi letto.',
            'items' => array(
                array(
                    'q' => 'Quali marchi partner seleziona Idea Lugano per i propri progetti?',
                    'a' => 'L\'atelier collabora con manifatture europee di riferimento nel settore dell\'arredo e della protezione solare, tra cui KADECO per le schermature su misura, MHZ per i sistemi solari e decorativi intelligenti, SILENT GLISS per i binari scorrevoli e motorizzati d\'alta precisione, e TRECA PARIS per i sistemi letto e materassi di alta sartoria francese.',
                ),
                array(
                    'q' => 'È possibile acquistare letti e materassi Tréca Paris a Lugano tramite Idea Lugano?',
                    'a' => 'Sì, Idea Lugano è punto di riferimento in Ticino e in Svizzera per i sistemi di riposo Tréca Paris, sinonimo di materassi artigianali cuciti a mano con fibre naturali e nobili come lana, seta e cashmere, abbinabili a sommier e testiere personalizzate.',
                ),
            ),
        ),
        array(
            'id'    => 'informazioni-atelier',
            'title' => 'Informazioni Pratiche, Atelier e Appuntamenti',
            'desc'  => 'Come raggiungerci a Bedano/Lugano, modalità di appuntamento e preventivi.',
            'items' => array(
                array(
                    'q' => 'Dove si trova l\'atelier e laboratorio di Idea Lugano?',
                    'a' => 'La sede e il laboratorio artigianale si trovano in Via alla Gerra 9, presso lo Stabile Vallone (Piano Superiore), a 6930 Bedano, a pochi minuti da Lugano. La posizione è facilmente accessibile dall\'autostrada A2 (uscita Lugano Nord) e dispone di comodi parcheggi per i clienti.',
                ),
                array(
                    'q' => 'Come posso prenotare un appuntamento o richiedere un preventivo?',
                    'a' => 'Per garantire una consulenza dedicata e approfondita senza attese, Idea Lugano riceve su appuntamento. È possibile prenotare telefonando al numero +41 78 803 92 01 o al +41 91 923 45 60, oppure inviando un\'email a info@idealugano.ch o tramite il modulo contatti sul sito.',
                ),
                array(
                    'q' => 'Idea Lugano effettua sopralluoghi e rilievi a domicilio?',
                    'a' => 'Sì, per tutti i progetti che richiedono misure precise — come tendaggi, schermature o rivestimenti su misura — viene concordato un sopralluogo sul posto. Durante la visita vengono valutati i vincoli architettonici, la luminosità e l\'orientamento degli spazi, mostrando i campionari direttamente nel contesto in cui andranno inseriti.',
                ),
            ),
        ),
    );
}

/** True quando le FAQ vivono nelle schede del parent. */
function idealugano_faq_on_parent()
{
    return function_exists('ticinoweb_faq_get_set') && get_option('idealugano_faqs_parent_migrated_v1') === '1';
}

/** Copia una volta le FAQ (pagina FAQ + landing) nelle schede del parent. */
function idealugano_migrate_faqs_to_parent()
{
    if (!function_exists('ticinoweb_faq_upsert_set') || get_option('idealugano_faqs_parent_migrated_v1') === '1') {
        return;
    }

    $items = array();
    $sections = array();
    foreach (idealugano_faq_seed_categories() as $cat) {
        $sections[$cat['title']] = $cat['desc'];
        foreach ($cat['items'] as $item) {
            $items[] = array('q' => $item['q'], 'a' => $item['a'], 'section' => $cat['title']);
        }
    }
    $ok = !is_wp_error(ticinoweb_faq_upsert_set(IDEALUGANO_FAQ_SET, 'FAQ Idea Lugano', $items, array('sections' => $sections)));

    foreach (idealugano_get_landings() as $slug => $landing) {
        if (empty($landing['faq'])) {
            continue;
        }
        $result = ticinoweb_faq_upsert_set('faq-' . $slug, 'FAQ ' . $landing['menu_label'], $landing['faq']);
        $ok = $ok && !is_wp_error($result);
    }

    if ($ok) {
        update_option('idealugano_faqs_parent_migrated_v1', '1', false);
    }
}
add_action('init', 'idealugano_migrate_faqs_to_parent', 30);

/**
 * Categorie della pagina FAQ: [id, title, desc, items => [q, a (HTML)]].
 * Le sezioni della scheda mantengono l'anchor storico quando il titolo coincide.
 */
function idealugano_faq_categories()
{
    $seed = idealugano_faq_seed_categories();
    if (!idealugano_faq_on_parent()) {
        foreach ($seed as &$cat) {
            foreach ($cat['items'] as &$item) {
                $item['a'] = esc_html($item['a']);
            }
            unset($item);
        }
        unset($cat);
        return $seed;
    }

    $anchors = array();
    foreach ($seed as $cat) {
        $anchors[sanitize_title($cat['title'])] = $cat['id'];
    }

    $set = ticinoweb_faq_get_set(IDEALUGANO_FAQ_SET);
    if (!$set) {
        return array();
    }
    $categories = array();
    foreach ($set['items'] as $item) {
        $key = $item['section_slug'] !== '' ? $item['section_slug'] : 'domande';
        if (!isset($categories[$key])) {
            $section = isset($set['sections'][$key]) ? $set['sections'][$key] : array('title' => '', 'desc' => '');
            $categories[$key] = array(
                'id'    => isset($anchors[$key]) ? $anchors[$key] : $key,
                'title' => $section['title'] !== '' ? $section['title'] : 'Domande frequenti',
                'desc'  => $section['desc'],
                'items' => array(),
            );
        }
        $categories[$key]['items'][] = array('q' => $item['question'], 'a' => $item['answer']);
    }
    return array_values($categories);
}

/** Domande di una landing: [q, a (HTML)]. */
function idealugano_landing_faq($landing)
{
    if (empty($landing['slug'])) {
        return array();
    }
    if (!idealugano_faq_on_parent()) {
        $items = array();
        foreach ((array) ($landing['faq'] ?? array()) as $item) {
            $items[] = array('q' => $item['q'], 'a' => esc_html($item['a']));
        }
        return $items;
    }
    $set = ticinoweb_faq_get_set('faq-' . $landing['slug']);
    if (!$set) {
        return array();
    }
    $items = array();
    foreach ($set['items'] as $item) {
        $items[] = array('q' => $item['question'], 'a' => $item['answer']);
    }
    return $items;
}

/**
 * Dati strutturati FAQPage per le domande mostrate: con il parent li stampa
 * il parent (una volta per pagina), altrimenti un blocco JSON-LD qui.
 */
function idealugano_faq_schema($items)
{
    if (!$items) {
        return;
    }
    if (function_exists('ticinoweb_faq_schema_add')) {
        $list = array();
        foreach ($items as $item) {
            $list[] = array('question' => $item['q'], 'answer' => $item['a']);
        }
        ticinoweb_faq_schema_add($list);
        return;
    }
    $schema = array('@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => array());
    foreach ($items as $item) {
        $schema['mainEntity'][] = array(
            '@type'          => 'Question',
            'name'           => wp_strip_all_tags($item['q']),
            'acceptedAnswer' => array('@type' => 'Answer', 'text' => wp_strip_all_tags($item['a'])),
        );
    }
    echo '<script type="application/ld+json">' . wp_json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "</script>\n";
}
