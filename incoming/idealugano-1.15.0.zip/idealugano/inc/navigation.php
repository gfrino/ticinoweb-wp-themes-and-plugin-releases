<?php
/**
 * Navigazione — menu WordPress "primary" con sottomenu
 *
 * Fino alla 1.12 header.php e il menu mobile avevano i link scritti a mano.
 * Dalla 1.13 leggono il menu WordPress assegnato alla posizione `primary`
 * (Aspetto → Menu), cosi' l'amministratore puo' aggiungere, togliere e
 * riordinare voci e sottovoci. Le voci figlie diventano un menu a tendina sul
 * desktop e un gruppo di sottovoci nel menu mobile. Se nessun menu e'
 * assegnato si usa la struttura predefinita qui sotto.
 *
 * @package Idealugano
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Struttura predefinita (usata anche dal seeder per costruire il menu WP).
 *
 * @return array Ogni voce: title, url|slug, children[]
 */
function idealugano_default_nav_structure()
{
    $services = array();
    foreach (idealugano_get_landings() as $slug => $landing) {
        $services[] = array('title' => $landing['menu_label'], 'slug' => $slug);
    }
    $services[] = array('title' => 'Cuscini e complementi', 'url' => home_url('/servizi/#servizio-complementi'));

    return array(
        array('title' => 'Home',      'slug' => 'home', 'url' => home_url('/')),
        array('title' => 'Servizi',   'slug' => 'servizi', 'children' => $services),
        array('title' => 'Prodotti',  'slug' => 'prodotti'),
        array('title' => 'Galleria',  'slug' => 'galleria'),
        array('title' => 'Occasioni', 'url' => home_url('/occasioni/')),
        array('title' => 'Marchi',    'slug' => 'marchi'),
        array('title' => 'Chi Siamo', 'slug' => 'chi-siamo'),
        array('title' => 'Contatti',  'slug' => 'contatti'),
    );
}

/**
 * Albero del menu primario: array di voci con title, url, current, ancestor,
 * children (stessa forma). Dal menu WP se assegnato, altrimenti predefinito.
 */
function idealugano_get_nav_tree()
{
    static $tree = null;
    if ($tree !== null) {
        return $tree;
    }

    $locations = get_nav_menu_locations();
    $menu_id   = !empty($locations['primary']) ? (int) $locations['primary'] : 0;
    $items     = $menu_id ? wp_get_nav_menu_items($menu_id, array('update_post_term_cache' => false)) : array();

    if (!empty($items)) {
        _wp_menu_item_classes_by_context($items);
        $by_parent = array();
        foreach ($items as $item) {
            $by_parent[(int) $item->menu_item_parent][] = $item;
        }
        $tree = idealugano_nav_branch($by_parent, 0);
        return $tree;
    }

    $tree = idealugano_nav_from_structure(idealugano_default_nav_structure());
    return $tree;
}

function idealugano_nav_branch($by_parent, $parent_id)
{
    $branch = array();
    if (empty($by_parent[$parent_id])) {
        return $branch;
    }
    foreach ($by_parent[$parent_id] as $item) {
        $classes  = (array) $item->classes;
        $children = idealugano_nav_branch($by_parent, (int) $item->ID);
        $branch[] = array(
            'title'    => $item->title,
            'url'      => $item->url,
            'target'   => $item->target,
            'current'  => in_array('current-menu-item', $classes, true) || idealugano_nav_url_is_current($item->url),
            'ancestor' => in_array('current-menu-ancestor', $classes, true) || in_array('current-menu-parent', $classes, true) || idealugano_nav_has_current($children),
            'children' => $children,
        );
    }
    return $branch;
}

function idealugano_nav_from_structure($structure)
{
    $tree = array();
    foreach ($structure as $entry) {
        $url = '';
        if (!empty($entry['url'])) {
            $url = $entry['url'];
        } elseif (!empty($entry['slug'])) {
            $page = get_page_by_path($entry['slug'], OBJECT, 'page');
            $url  = $page ? get_permalink($page) : home_url('/' . $entry['slug'] . '/');
        }
        $children = !empty($entry['children']) ? idealugano_nav_from_structure($entry['children']) : array();
        $tree[] = array(
            'title'    => $entry['title'],
            'url'      => $url,
            'target'   => '',
            'current'  => idealugano_nav_url_is_current($url),
            'ancestor' => idealugano_nav_has_current($children),
            'children' => $children,
        );
    }
    return $tree;
}

function idealugano_nav_has_current($children)
{
    foreach ($children as $child) {
        if ($child['current'] || $child['ancestor']) {
            return true;
        }
    }
    return false;
}

/**
 * Confronto URL voce ↔ pagina corrente (senza query string e ancore).
 */
function idealugano_nav_url_is_current($url)
{
    static $current = null;
    if ($current === null) {
        global $wp;
        $current = untrailingslashit(home_url(isset($wp->request) ? $wp->request : ''));
        if (is_front_page()) {
            $current = untrailingslashit(home_url('/'));
        }
    }
    if (empty($url) || strpos($url, '#') !== false) {
        return false;
    }
    $clean = untrailingslashit(preg_replace('/\?.*$/', '', $url));
    return $clean !== '' && strtolower($clean) === strtolower($current);
}

/**
 * Divide le voci di primo livello fra colonna sinistra e destra dell'header.
 */
function idealugano_nav_split($tree)
{
    $half = (int) ceil(count($tree) / 2);
    return array(array_slice($tree, 0, $half), array_slice($tree, $half));
}

/**
 * Stampa le voci desktop (link + eventuale tendina).
 */
function idealugano_render_nav_items($items)
{
    foreach ($items as $index => $item) {
        $has_children = !empty($item['children']);
        $active       = ($item['current'] || $item['ancestor']) ? ' active' : '';
        $target       = !empty($item['target']) ? ' target="' . esc_attr($item['target']) . '" rel="noopener"' : '';

        if (!$has_children) {
            echo '<a class="idea-nav__link' . $active . '" href="' . esc_url($item['url']) . '"' . $target . ($item['current'] ? ' aria-current="page"' : '') . '>' . esc_html($item['title']) . '</a>';
            continue;
        }

        $sub_id = 'idea-nav-sub-' . sanitize_html_class(strtolower($item['title'])) . '-' . $index;
        echo '<div class="idea-nav__item idea-nav__item--has-children">';
        echo '<a class="idea-nav__link' . $active . '" href="' . esc_url($item['url']) . '" aria-haspopup="true" aria-expanded="false" aria-controls="' . esc_attr($sub_id) . '">';
        echo esc_html($item['title']);
        echo '<svg class="idea-nav__caret" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"></polyline></svg>';
        echo '</a>';
        echo '<ul class="idea-nav__sub" id="' . esc_attr($sub_id) . '" aria-label="' . esc_attr($item['title']) . '">';
        foreach ($item['children'] as $child) {
            echo '<li><a class="idea-nav__sub-link' . ($child['current'] ? ' active' : '') . '" href="' . esc_url($child['url']) . '"' . ($child['current'] ? ' aria-current="page"' : '') . '>' . esc_html($child['title']) . '</a></li>';
        }
        echo '</ul>';
        echo '</div>';
    }
}

/**
 * Stampa le voci del menu mobile (link grandi + gruppo di sottovoci).
 */
function idealugano_render_mobile_nav_items($items)
{
    foreach ($items as $item) {
        $active = ($item['current'] || $item['ancestor']) ? ' active' : '';
        echo '<a class="idea-mobile-menu__link' . $active . '" href="' . esc_url($item['url']) . '">' . esc_html($item['title']) . '</a>';
        if (!empty($item['children'])) {
            echo '<div class="idea-mobile-menu__sub" aria-label="' . esc_attr($item['title']) . '">';
            foreach ($item['children'] as $child) {
                echo '<a class="idea-mobile-menu__sublink' . ($child['current'] ? ' active' : '') . '" href="' . esc_url($child['url']) . '">' . esc_html($child['title']) . '</a>';
            }
            echo '</div>';
        }
    }
}
