<?php
/**
 * Content Seeder for Idea Lugano
 *
 * Crea le pagine e le opzioni di base del sito quando il child theme viene
 * attivato o quando cambia la versione del seed (nuove pagine legali ecc.).
 *
 * Fino alla 1.10.x il seeder girava su `init` a ogni richiesta (anche anonime,
 * AJAX, REST, cron), ricreava le pagine dal frontend, forzava a "publish" le
 * pagine messe in bozza dall'amministratore e serviva /qualsiasi/cosa/contatti
 * con il template Contatti. Dalla 1.11.0 gira SOLO:
 *   - all'attivazione del tema (`after_switch_theme`);
 *   - in `admin_init` per un amministratore, se la versione del seed e' cambiata;
 *   - su richiesta esplicita: admin.php?idealugano_reseed=1&_wpnonce=<nonce>
 *     (nonce action `idealugano_reseed`, capability `manage_options`).
 * Non tocca mai lo stato di pubblicazione di pagine esistenti.
 *
 * Dalla 2.1.0 (child 1.13.0) crea anche le cinque landing dei servizi
 * (inc/landings.php) con titolo/description SEO nel metabox tW SEO, allinea il
 * menu WordPress `primary` (voce Servizi con sottovoci) e migra le categorie
 * della galleria (imbottiti → divani-letti / rifacimenti).
 *
 * @package Idealugano
 * @version 2.1.0
 */

if (!defined('ABSPATH')) {
    exit;
}

define('IDEALUGANO_CONTENT_SEED_VERSION', '2.1.0');

/**
 * All'attivazione del tema: seed completo.
 */
add_action('after_switch_theme', 'idealugano_seed_on_activation');
function idealugano_seed_on_activation()
{
    idealugano_auto_seed_content(true);
}

/**
 * In admin, solo per amministratori: seed se la versione e' cambiata
 * oppure se richiesto esplicitamente con nonce valido.
 */
add_action('admin_init', 'idealugano_maybe_seed_content', 15);
function idealugano_maybe_seed_content()
{
    if (wp_doing_ajax() || (defined('REST_REQUEST') && REST_REQUEST)) {
        return;
    }
    if (!current_user_can('manage_options')) {
        return;
    }

    $reseed_requested = false;
    if (isset($_GET['idealugano_reseed'])) {
        $nonce = isset($_GET['_wpnonce']) ? sanitize_text_field(wp_unslash($_GET['_wpnonce'])) : '';
        if (!wp_verify_nonce($nonce, 'idealugano_reseed')) {
            wp_die(esc_html__('Richiesta non valida: nonce mancante o scaduto.', 'idealugano'), 403);
        }
        $reseed_requested = true;
    }

    if (!$reseed_requested && get_option('idealugano_content_seed_version') === IDEALUGANO_CONTENT_SEED_VERSION) {
        return;
    }

    idealugano_auto_seed_content($reseed_requested);

    if ($reseed_requested) {
        wp_safe_redirect(remove_query_arg(array('idealugano_reseed', '_wpnonce')));
        exit;
    }
}

/**
 * 1. CONTENT & PAGES SEEDER
 *
 * Crea le pagine mancanti, allinea i template e le opzioni di base; non tocca
 * lo stato di pubblicazione delle pagine esistenti.
 *
 * @param bool $force Riservato ai chiamanti (attivazione tema / reseed esplicito).
 */
function idealugano_auto_seed_content($force = false)
{
    $current_seed_version = IDEALUGANO_CONTENT_SEED_VERSION;

    $identity = '<p><strong>IDeA Lugano</strong><br>Via alla Gerra 9, Stabile Vallone, Piano Superiore<br>6930 Bedano, Svizzera<br><a href="mailto:info@idealugano.ch">info@idealugano.ch</a></p>';

    $privacy_content = '<div class="idea-legal-content">
        <p class="idea-legal-content__updated">Ultimo aggiornamento: 15 luglio 2026</p>
        <p>La presente informativa descrive come Idea Lugano tratta i dati personali raccolti tramite questo sito, nel rispetto della Legge federale svizzera sulla protezione dei dati (LPD) e, ove applicabile, del Regolamento generale europeo sulla protezione dei dati (GDPR).</p>
        <h2>1. Titolare del trattamento</h2>' . $identity . '
        <h2>2. Dati trattati</h2>
        <p>Possiamo trattare i dati forniti volontariamente tramite moduli, email o telefono, come nome, recapiti e contenuto della richiesta. Durante la navigazione possono inoltre essere registrati dati tecnici, quali indirizzo IP, data e ora, pagina richiesta, dispositivo, browser e informazioni necessarie alla sicurezza del sito.</p>
        <h2>3. Finalità</h2>
        <ul><li>rispondere a richieste di informazioni e consulenza;</li><li>preparare preventivi ed eseguire servizi richiesti;</li><li>garantire funzionamento, sicurezza e prevenzione degli abusi;</li><li>adempiere a obblighi legali e amministrativi;</li><li>migliorare sito e servizi mediante dati aggregati, ove applicabile.</li></ul>
        <h2>4. Comunicazione e fornitori</h2>
        <p>I dati possono essere trattati da fornitori tecnici strettamente necessari, quali hosting, posta elettronica e manutenzione, vincolati alla riservatezza. Il sito integra o collega servizi esterni, tra cui Google Maps e Instagram, che trattano dati secondo le rispettive informative. Non vendiamo dati personali.</p>
        <h2>5. Trasferimenti all’estero</h2>
        <p>Qualora un fornitore tratti dati fuori dalla Svizzera, adottiamo le garanzie richieste dalla normativa applicabile, come decisioni di adeguatezza o clausole contrattuali riconosciute.</p>
        <h2>6. Conservazione</h2>
        <p>Conserviamo i dati per il tempo necessario alle finalità indicate, alla gestione del rapporto e agli obblighi legali. Le richieste non sfociate in un rapporto contrattuale vengono eliminate o anonimizzate quando non sono più necessarie.</p>
        <h2>7. Diritti</h2>
        <p>Nei limiti previsti dalla legge, è possibile chiedere accesso, rettifica, cancellazione, limitazione o consegna dei propri dati e opporsi a determinati trattamenti. Le richieste possono essere inviate a <a href="mailto:info@idealugano.ch">info@idealugano.ch</a>. È inoltre possibile rivolgersi all’Incaricato federale della protezione dei dati e della trasparenza (IFPDT).</p>
        <h2>8. Sicurezza e modifiche</h2>
        <p>Adottiamo misure tecniche e organizzative adeguate al rischio. Questa informativa può essere aggiornata in caso di modifiche al sito, ai servizi o alla normativa.</p>
    </div>';

    $cookie_content = '<div class="idea-legal-content">
        <p class="idea-legal-content__updated">Ultimo aggiornamento: 15 luglio 2026</p>
        <p>Questa pagina spiega l’uso di cookie e tecnologie simili sul sito Idea Lugano. I cookie sono piccoli file salvati dal browser che permettono al sito di funzionare, ricordare preferenze o integrare servizi esterni.</p>
        <h2>1. Tipologie utilizzate</h2>
        <h3>Cookie tecnici e di sicurezza</h3>
        <p>Sono necessari al funzionamento del sito, alla gestione della sessione, alla sicurezza e alle preferenze essenziali. Non vengono usati per pubblicità comportamentale.</p>
        <h3>Contenuti e servizi esterni</h3>
        <p>La pagina Contatti incorpora Google Maps. Quando la mappa viene caricata, Google può ricevere dati tecnici e impostare proprie tecnologie secondo la sua informativa. I collegamenti a Instagram aprono il servizio esterno; la navigazione successiva è regolata dalle condizioni e informative di Meta.</p>
        <h3>Misurazione e marketing</h3>
        <p>Il sito non attiva intenzionalmente cookie di profilazione o marketing senza la base giuridica o il consenso richiesto. Se in futuro verranno introdotti strumenti di analisi non essenziali, questa informativa e le relative preferenze saranno aggiornate.</p>
        <h2>2. Gestione dei cookie</h2>
        <p>È possibile eliminare o bloccare i cookie dalle impostazioni del browser. La disattivazione di cookie tecnici può compromettere alcune funzioni. Le preferenze relative a eventuali cookie opzionali possono essere modificate tramite il banner o pannello cookie, quando presente.</p>
        <h2>3. Durata</h2>
        <p>I cookie di sessione vengono eliminati alla chiusura del browser; quelli persistenti restano fino alla scadenza indicata dal fornitore o alla cancellazione manuale.</p>
        <h2>4. Contatti</h2>' . $identity . '
        <p>Per ulteriori informazioni sul trattamento dei dati consulta la <a href="' . esc_url(home_url('/privacy-policy/')) . '">Privacy Policy</a>.</p>
    </div>';

    $termini_content = '<div class="idea-legal-content">
        <p class="idea-legal-content__updated">Ultimo aggiornamento: 15 luglio 2026</p>
        <p>L’accesso e l’utilizzo del sito implicano l’accettazione delle presenti condizioni. Il sito presenta l’attività e i servizi di Idea Lugano; non costituisce un negozio online né un’offerta vincolante.</p>
        <h2>1. Informazioni e preventivi</h2>
        <p>Testi, immagini, esempi e descrizioni hanno finalità informative. Prezzi, materiali, tempi, misure e prestazioni vengono definiti nel preventivo o contratto applicabile. Una richiesta inviata dal sito non comporta automaticamente accettazione dell’incarico.</p>
        <h2>2. Servizi su misura</h2>
        <p>I lavori artigianali e personalizzati possono presentare normali variazioni di colore, trama o finitura dovute ai materiali e alla lavorazione. Campioni, misure, condizioni di consegna, installazione, pagamento, modifiche e garanzie sono disciplinati dal singolo preventivo o accordo.</p>
        <h2>3. Proprietà intellettuale</h2>
        <p>Salvo diversa indicazione, contenuti, grafica, fotografie, marchi e struttura del sito sono protetti. Non è consentita la riproduzione o l’uso commerciale senza autorizzazione scritta, fatti salvi gli usi consentiti dalla legge.</p>
        <h2>4. Collegamenti esterni</h2>
        <p>Il sito può contenere collegamenti o contenuti di terzi. Idea Lugano non controlla disponibilità, sicurezza o contenuti dei siti esterni e non risponde delle loro pratiche.</p>
        <h2>5. Disponibilità e responsabilità</h2>
        <p>Ci impegniamo a mantenere informazioni corrette e il sito disponibile, senza garantire assenza di errori o interruzioni. Nei limiti consentiti dalla legge, è esclusa la responsabilità per danni indiretti derivanti dall’uso del sito. Restano impregiudicate le responsabilità inderogabili previste dalla legge.</p>
        <h2>6. Legge applicabile</h2>
        <p>Si applica il diritto svizzero. Salvo disposizioni imperative, il foro competente è Lugano, Svizzera.</p>
        <h2>7. Contatti</h2>' . $identity . '
    </div>';

    $pages = array();
    // Landing servizi (una per gruppo di annunci): template dedicato + SEO.
    if (function_exists('idealugano_get_landings')) {
        foreach (idealugano_get_landings() as $slug => $landing) {
            $pages[$slug] = array(
                'title'    => $landing['menu_label'],
                'template' => 'page-landing.php',
                'content'  => '',
                'seo'      => array('title' => $landing['seo_title'], 'desc' => $landing['seo_desc']),
                'meta'     => array('_idealugano_landing' => $slug),
            );
        }
    }
    $pages += array(
        'faq' => array(
            'title'    => 'FAQ',
            'template' => 'page-faq.php',
            'content'  => '',
        ),
        'marchi' => array(
            'title'    => 'Marchi',
            'template' => 'page-marchi.php',
            'content'  => '',
        ),
        'chi-siamo' => array(
            'title'    => 'Chi Siamo',
            'template' => 'page-chi-siamo.php',
            'content'  => '',
        ),
        'servizi' => array(
            'title'    => 'Servizi',
            'template' => 'page-servizi.php',
            'content'  => '',
        ),
        'prodotti' => array(
            'title'    => 'Prodotti',
            'template' => 'page-prodotti.php',
            'content'  => '',
        ),
        'galleria' => array(
            'title'    => 'Galleria',
            'template' => 'page-galleria.php',
            'content'  => '',
        ),
        'contatti' => array(
            'title'    => 'Contatti',
            'template' => 'page-contatti.php',
            'content'  => '',
        ),
        'home' => array(
            'title'    => 'Home',
            'template' => 'front-page.php',
            'content'  => '',
        ),
        'privacy-policy' => array(
            'title'    => 'Privacy Policy',
            'template' => '',
            'content'  => $privacy_content,
        ),
        'cookie-policy' => array(
            'title'    => 'Cookie Policy',
            'template' => '',
            'content'  => $cookie_content,
        ),
        'termini-e-condizioni' => array(
            'title'    => 'Termini e Condizioni',
            'template' => '',
            'content'  => $termini_content,
        ),
    );

    global $wpdb;
    $created_any = false;
    $author_id   = get_current_user_id();
    if (!$author_id) {
        $admins    = get_users(array('role' => 'administrator', 'number' => 1, 'fields' => 'ID', 'orderby' => 'ID'));
        $author_id = !empty($admins) ? (int) $admins[0] : 0;
    }

    foreach ($pages as $slug => $pdata) {
        $existing = get_page_by_path($slug, OBJECT, 'page');

        if (!$existing) {
            $post_id = $wpdb->get_var($wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts} WHERE post_name = %s AND post_type = 'page' AND post_status != 'trash' LIMIT 1",
                $slug
            ));
            if ($post_id) {
                $existing = get_post($post_id);
            }
        }

        if (!$existing) {
            $new_id = wp_insert_post(array(
                'post_type'    => 'page',
                'post_status'  => 'publish',
                'post_title'   => $pdata['title'],
                'post_name'    => $slug,
                'post_content' => $pdata['content'],
                'post_author'  => $author_id,
            ), true);

            if (!is_wp_error($new_id) && $new_id) {
                if (!empty($pdata['template'])) {
                    update_post_meta($new_id, '_wp_page_template', $pdata['template']);
                }
                idealugano_seed_page_meta($new_id, $pdata);
                $created_any = true;
            }
        } else {
            // Ensure template is set correctly
            if (!empty($pdata['template'])) {
                $current_tpl = get_post_meta($existing->ID, '_wp_page_template', true);
                if ($current_tpl !== $pdata['template']) {
                    update_post_meta($existing->ID, '_wp_page_template', $pdata['template']);
                }
            }
            idealugano_seed_page_meta($existing->ID, $pdata);
            // Lo stato di pubblicazione resta quello scelto dall'amministratore.
        }
    }

    idealugano_seed_migrate_gallery_categories();
    idealugano_sync_primary_menu();

    // Ensure homepage setting
    $home_page = get_page_by_path('home', OBJECT, 'page');
    if ($home_page && get_option('show_on_front') !== 'page') {
        update_option('show_on_front', 'page');
        update_option('page_on_front', $home_page->ID);
    }

    // Ensure brands default option
    $brands = get_option('idealugano_brands');
    if (!is_array($brands) || empty($brands)) {
        if (function_exists('idealugano_get_default_brands')) {
            update_option('idealugano_brands', idealugano_get_default_brands());
        }
    }

    if ($created_any) {
        flush_rewrite_rules(false);
    }

    update_option('idealugano_content_seed_version', $current_seed_version);
    update_option('idealugano_legal_pages_version', '1');
}

/**
 * Meta della pagina seminata: titolo/description SEO (metabox tW SEO del
 * parent) e collegamento alla landing. Non sovrascrive valori gia' compilati
 * dall'amministratore.
 */
function idealugano_seed_page_meta($post_id, $pdata)
{
    if (!empty($pdata['seo']['title']) && get_post_meta($post_id, '_tw_seo_title', true) === '') {
        update_post_meta($post_id, '_tw_seo_title', $pdata['seo']['title']);
    }
    if (!empty($pdata['seo']['desc']) && get_post_meta($post_id, '_tw_seo_description', true) === '') {
        update_post_meta($post_id, '_tw_seo_description', $pdata['seo']['desc']);
    }
    if (!empty($pdata['meta'])) {
        foreach ($pdata['meta'] as $key => $value) {
            if (get_post_meta($post_id, $key, true) === '') {
                update_post_meta($post_id, $key, $value);
            }
        }
    }
}

/**
 * Galleria: la vecchia categoria unica "imbottiti" viene divisa in
 * "rifacimenti" (titoli che parlano di rifacimento/rivestimento) e
 * "divani-letti". Interviene solo sull'opzione salvata; il bundle del tema e'
 * gia' aggiornato.
 */
function idealugano_seed_migrate_gallery_categories()
{
    $items = get_option('idealugano_gallery_items', null);
    if (!is_array($items) || !function_exists('idealugano_normalize_gallery_category')) {
        return;
    }
    $changed = false;
    foreach ($items as &$item) {
        $cat = $item['category'] ?? '';
        $new = idealugano_normalize_gallery_category($cat, $item['title'] ?? '');
        if ($new !== $cat) {
            $item['category'] = $new;
            $changed = true;
        }
    }
    unset($item);
    if ($changed) {
        update_option('idealugano_gallery_items', $items);
    }
}

/**
 * Menu WordPress `primary`: garantisce le voci della struttura predefinita
 * (Home, Servizi con le landing come sottovoci, Prodotti, Galleria, Occasioni,
 * Marchi, Chi Siamo, Contatti) e il loro ordine. Le voci aggiunte a mano
 * dall'amministratore vengono lasciate in coda, mai cancellate.
 */
function idealugano_sync_primary_menu()
{
    if (!function_exists('idealugano_default_nav_structure')) {
        return;
    }

    $menu_name = 'Menu Principale Idealugano';
    $menu      = wp_get_nav_menu_object($menu_name);
    $locations = get_nav_menu_locations();
    if (!$menu && !empty($locations['primary'])) {
        $menu = wp_get_nav_menu_object((int) $locations['primary']);
    }
    if (!$menu) {
        $menu_id = wp_create_nav_menu($menu_name);
        if (is_wp_error($menu_id)) {
            return;
        }
        $menu = wp_get_nav_menu_object($menu_id);
    }
    $menu_id = (int) $menu->term_id;

    if (!is_array($locations)) {
        $locations = array();
    }
    if (empty($locations['primary']) || (int) $locations['primary'] !== $menu_id) {
        $locations['primary'] = $menu_id;
        set_theme_mod('nav_menu_locations', $locations);
    }

    $existing = wp_get_nav_menu_items($menu_id, array('post_status' => 'any'));
    $existing = is_array($existing) ? $existing : array();

    $position = 1;
    foreach (idealugano_default_nav_structure() as $entry) {
        $parent_id = idealugano_sync_menu_item($menu_id, $existing, $entry, 0, $position);
        $position++;
        if ($parent_id && !empty($entry['children'])) {
            foreach ($entry['children'] as $child) {
                idealugano_sync_menu_item($menu_id, $existing, $child, $parent_id, $position);
                $position++;
            }
        }
    }
}

/**
 * Crea o aggiorna una voce di menu. Ritorna l'ID della voce (0 se fallisce).
 */
function idealugano_sync_menu_item($menu_id, &$existing, $entry, $parent_id, $position)
{
    $page = !empty($entry['slug']) ? get_page_by_path($entry['slug'], OBJECT, 'page') : null;
    $url  = !empty($entry['url']) ? $entry['url'] : ($page ? get_permalink($page) : '');
    if (!$page && $url === '') {
        return 0;
    }

    $match = null;
    foreach ($existing as $item) {
        if ($page && $item->type === 'post_type' && $item->object === 'page' && (int) $item->object_id === (int) $page->ID) {
            $match = $item;
            break;
        }
        if (!$page && $item->type === 'custom' && untrailingslashit($item->url) === untrailingslashit($url)) {
            $match = $item;
            break;
        }
    }

    $args = array(
        'menu-item-title'     => $match ? $match->title : $entry['title'],
        'menu-item-status'    => 'publish',
        'menu-item-position'  => $position,
        'menu-item-parent-id' => $parent_id,
    );
    if ($page) {
        $args['menu-item-type']      = 'post_type';
        $args['menu-item-object']    = 'page';
        $args['menu-item-object-id'] = (int) $page->ID;
        // Il titolo esplicito e' quello della struttura (es. "Chi Siamo").
        if (!$match) {
            $args['menu-item-title'] = $entry['title'];
        }
    } else {
        $args['menu-item-type'] = 'custom';
        $args['menu-item-url']  = $url;
    }

    if ($match) {
        $same = (int) $match->menu_order === (int) $position && (int) $match->menu_item_parent === (int) $parent_id;
        if ($same) {
            return (int) $match->ID;
        }
        $args['menu-item-url'] = $match->url;
        $id = wp_update_nav_menu_item($menu_id, (int) $match->ID, $args);
        return is_wp_error($id) ? (int) $match->ID : (int) $id;
    }

    $id = wp_update_nav_menu_item($menu_id, 0, $args);
    if (is_wp_error($id) || !$id) {
        return 0;
    }
    $new_item = get_post($id);
    if ($new_item) {
        $new_item = wp_setup_nav_menu_item($new_item);
        $existing[] = $new_item;
    }
    return (int) $id;
}
