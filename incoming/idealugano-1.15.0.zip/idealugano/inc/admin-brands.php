<?php
/**
 * Backend Management for Marchi (Partner Brands)
 *
 * Provides a dedicated admin page at admin.php?page=idealugano-brands.
 * Allows adding, editing, reordering, and deleting partner brands with logos.
 * Enforces a maximum of 6 brands (layout: 3 top, 3 bottom) as specified.
 * Accessible to both Administrators and Editors (capability: edit_pages).
 *
 * @package Idealugano
 * @version 1.9.94
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Returns default partner brands when no database option is found.
 */
function idealugano_get_default_brands()
{
    $base_uri = get_stylesheet_directory_uri() . '/assets/images/slots/';

    return array(
        array(
            'id'          => 'brand_1',
            'name'        => 'KADECO',
            'logo'        => $base_uri . 'logo-kadeco-nobg.png',
            'description' => 'Sistemi di protezione solare, tende a rullo, plissé e veneziane su misura di altissima precisione artigianale.',
        ),
        array(
            'id'          => 'brand_2',
            'name'        => 'MHZ',
            'logo'        => $base_uri . 'mhz-logo-nobg.png',
            'description' => 'Schermature solari intelligenti, tende tecniche e sistemi decorativi di design all\'avanguardia per interni ed esterni.',
        ),
        array(
            'id'          => 'brand_3',
            'name'        => 'SILENT GLISS',
            'logo'        => $base_uri . 'silentgliss-nobg.png',
            'description' => 'Leader mondiale svizzero nei sistemi scorrevoli motorizzati, binari per tende e soluzioni acustiche per l\'architettura.',
        ),
        array(
            'id'          => 'brand_4',
            'name'        => 'TRECA INTERIORS PARIS',
            'logo'        => $base_uri . 'treca.png',
            'description' => 'Alta sartoria del riposo francese: materassi artigianali, letti di lusso e imbottiti realizzati a mano con fibre nobili.',
        ),
    );
}

/**
 * Returns active partner brands from wp_options with fallback.
 */
function idealugano_get_brands()
{
    $brands = get_option('idealugano_brands');
    if (!is_array($brands) || empty($brands)) {
        $brands = idealugano_get_default_brands();
    }
    return array_slice($brands, 0, 6);
}

/**
 * Register the Marchi menu item in WordPress admin.
 */
add_action('admin_menu', 'idealugano_register_brands_menu');
function idealugano_register_brands_menu()
{
    add_menu_page(
        __('Marchi', 'idealugano'),
        __('Marchi', 'idealugano'),
        'edit_pages',
        'idealugano-brands',
        'idealugano_render_brands_page',
        'dashicons-tag',
        26
    );
}

/**
 * AJAX handler to save all brands.
 */
add_action('wp_ajax_idealugano_save_brands', 'idealugano_ajax_save_brands');
function idealugano_ajax_save_brands()
{
    check_ajax_referer('idealugano_brands_nonce', 'nonce');

    if (!current_user_can('edit_pages')) {
        wp_send_json_error(array('message' => __('Permessi insufficienti.', 'idealugano')));
    }

    $raw = isset($_POST['brands']) ? json_decode(wp_unslash($_POST['brands']), true) : array();
    if (!is_array($raw)) {
        wp_send_json_error(array('message' => __('Dati non validi.', 'idealugano')));
    }

    // Limit to max 6 brands (3 above, 3 below)
    $raw = array_slice($raw, 0, 6);

    $clean = array();
    foreach ($raw as $idx => $item) {
        $name = isset($item['name']) ? sanitize_text_field($item['name']) : '';
        $logo = isset($item['logo']) ? esc_url_raw($item['logo']) : '';
        $desc = isset($item['description']) ? sanitize_textarea_field($item['description']) : '';

        if ($name === '' && $logo === '') {
            continue;
        }

        $clean[] = array(
            'id'          => 'brand_' . ($idx + 1) . '_' . substr(md5($name . microtime()), 0, 6),
            'name'        => $name,
            'logo'        => $logo,
            'description' => $desc,
        );
    }

    update_option('idealugano_brands', $clean);

    wp_send_json_success(array(
        'message' => __('Marchi salvati con successo!', 'idealugano'),
        'count'   => count($clean),
        'brands'  => $clean,
    ));
}

/**
 * Render the Marchi management backend page.
 */
function idealugano_render_brands_page()
{
    if (!current_user_can('edit_pages')) {
        wp_die(__('Non hai i permessi per accedere a questa pagina.', 'idealugano'));
    }

    wp_enqueue_media();

    $brands = idealugano_get_brands();
    $nonce  = wp_create_nonce('idealugano_brands_nonce');
    $max_brands = 6;
    ?>
    <div class="wrap idealugano-brands-admin">
        <div class="idealugano-brands-header">
            <div class="idealugano-brands-header__title">
                <h1>
                    <span class="dashicons dashicons-tag" style="font-size:28px; width:28px; height:28px; margin-right:8px; vertical-align:middle; color:#052d3a;"></span>
                    <?php _e('Gestione Marchi Partner', 'idealugano'); ?>
                </h1>
                <p class="idealugano-brands-header__desc">
                    <?php _e('Gestisci i marchi partner di Idea Lugano. I marchi vengono mostrati nella sezione dedicata (massimo 6 marchi, disposti su 2 righe: 3 sopra e 3 sotto) e nella pagina "Marchi".', 'idealugano'); ?>
                </p>
            </div>
            <div class="idealugano-brands-header__actions">
                <span class="idealugano-brands-counter" id="brands-counter">
                    <span id="brands-count"><?php echo count($brands); ?></span> / <?php echo $max_brands; ?> marchi
                </span>
                <button type="button" class="button button-primary button-hero" id="add-brand-btn" <?php echo count($brands) >= $max_brands ? 'disabled' : ''; ?>>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <line x1="12" y1="5" x2="12" y2="19"></line>
                        <line x1="5" y1="12" x2="19" y2="12"></line>
                    </svg>
                    <span><?php _e('Aggiungi Marchio', 'idealugano'); ?></span>
                </button>
            </div>
        </div>

        <div id="brands-limit-warning" class="notice notice-info inline" style="<?php echo count($brands) >= $max_brands ? 'display:block;' : 'display:none;'; ?> margin: 15px 0 20px;">
            <p>
                <strong><?php _e('Limite massimo raggiunto:', 'idealugano'); ?></strong>
                <?php _e('Puoi impostare fino a un massimo di 6 marchi (layout grafico: 3 sopra, 3 sotto). Per aggiungerne uno nuovo, elimina prima uno di quelli esistenti.', 'idealugano'); ?>
            </p>
        </div>

        <!-- Brands Grid Container -->
        <div class="idealugano-brands-list" id="brands-list">
            <?php foreach ($brands as $index => $brand): ?>
                <div class="idealugano-brand-card" data-index="<?php echo $index; ?>">
                    <div class="idealugano-brand-card__header">
                        <span class="idealugano-brand-card__num">#<?php echo $index + 1; ?></span>
                        <div class="idealugano-brand-card__controls">
                            <button type="button" class="button button-small move-up-btn" title="<?php esc_attr_e('Sposta su', 'idealugano'); ?>" <?php echo $index === 0 ? 'disabled' : ''; ?>>
                                <span class="dashicons dashicons-arrow-up-alt2"></span>
                            </button>
                            <button type="button" class="button button-small move-down-btn" title="<?php esc_attr_e('Sposta giù', 'idealugano'); ?>" <?php echo $index === count($brands) - 1 ? 'disabled' : ''; ?>>
                                <span class="dashicons dashicons-arrow-down-alt2"></span>
                            </button>
                            <button type="button" class="button button-small button-link-delete delete-brand-btn" title="<?php esc_attr_e('Elimina marchio', 'idealugano'); ?>">
                                <span class="dashicons dashicons-trash"></span>
                            </button>
                        </div>
                    </div>

                    <div class="idealugano-brand-card__body">
                        <!-- Logo Upload Section -->
                        <div class="idealugano-brand-logo-col">
                            <div class="idealugano-brand-preview" id="preview-<?php echo $index; ?>">
                                <?php if (!empty($brand['logo'])): ?>
                                    <img src="<?php echo esc_url($brand['logo']); ?>" alt="<?php echo esc_attr($brand['name']); ?>">
                                <?php else: ?>
                                    <div class="idealugano-brand-preview__placeholder">
                                        <span class="dashicons dashicons-format-image"></span>
                                        <span><?php _e('Nessun logo', 'idealugano'); ?></span>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <input type="hidden" class="brand-logo-input" value="<?php echo esc_attr($brand['logo']); ?>">
                            <div class="idealugano-brand-logo-actions">
                                <button type="button" class="button button-secondary upload-logo-btn">
                                    <span class="dashicons dashicons-upload"></span> <?php _e('Carica Logo', 'idealugano'); ?>
                                </button>
                                <button type="button" class="button button-link remove-logo-btn" style="<?php echo empty($brand['logo']) ? 'display:none;' : ''; ?>">
                                    <?php _e('Rimuovi', 'idealugano'); ?>
                                </button>
                            </div>
                            <p class="description" style="font-size:11px; margin-top:4px;">PNG o SVG consigliati con sfondo trasparente.</p>
                        </div>

                        <!-- Brand Info Section -->
                        <div class="idealugano-brand-info-col">
                            <div class="idealugano-field-group">
                                <label><?php _e('Nome Marchio *', 'idealugano'); ?></label>
                                <input type="text" class="regular-text brand-name-input" value="<?php echo esc_attr($brand['name']); ?>" placeholder="<?php esc_attr_e('Es: KADECO, Silent Gliss', 'idealugano'); ?>" required>
                            </div>

                            <div class="idealugano-field-group">
                                <label><?php _e('Descrizione / Specializzazione', 'idealugano'); ?></label>
                                <textarea class="large-text brand-desc-input" rows="2" placeholder="<?php esc_attr_e('Breve descrizione delle specializzazioni del marchio (visibile nella pagina "Marchi").', 'idealugano'); ?>"><?php echo esc_textarea($brand['description']); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Sticky Save Bar -->
        <div class="idealugano-sticky-bar" id="sticky-bar">
            <div class="idealugano-sticky-bar__inner">
                <div class="idealugano-dirty-indicator" id="dirty-indicator">
                    <span class="idealugano-dirty-dot" id="dirty-dot"></span>
                    <span class="idealugano-dirty-label" id="dirty-label"><?php _e('Tutte le modifiche salvate', 'idealugano'); ?></span>
                </div>
                <button type="button" class="button button-primary button-large" id="save-brands-btn">
                    <span class="dashicons dashicons-saved" id="save-icon"></span>
                    <span id="save-btn-text"><?php _e('Salva modifiche', 'idealugano'); ?></span>
                </button>
            </div>
        </div>
    </div>

    <!-- Template for new brand card -->
    <template id="brand-card-template">
        <div class="idealugano-brand-card" data-index="__INDEX__">
            <div class="idealugano-brand-card__header">
                <span class="idealugano-brand-card__num">#__NUM__</span>
                <div class="idealugano-brand-card__controls">
                    <button type="button" class="button button-small move-up-btn" title="<?php esc_attr_e('Sposta su', 'idealugano'); ?>">
                        <span class="dashicons dashicons-arrow-up-alt2"></span>
                    </button>
                    <button type="button" class="button button-small move-down-btn" title="<?php esc_attr_e('Sposta giù', 'idealugano'); ?>">
                        <span class="dashicons dashicons-arrow-down-alt2"></span>
                    </button>
                    <button type="button" class="button button-small button-link-delete delete-brand-btn" title="<?php esc_attr_e('Elimina marchio', 'idealugano'); ?>">
                        <span class="dashicons dashicons-trash"></span>
                    </button>
                </div>
            </div>

            <div class="idealugano-brand-card__body">
                <div class="idealugano-brand-logo-col">
                    <div class="idealugano-brand-preview">
                        <div class="idealugano-brand-preview__placeholder">
                            <span class="dashicons dashicons-format-image"></span>
                            <span><?php _e('Nessun logo', 'idealugano'); ?></span>
                        </div>
                    </div>
                    <input type="hidden" class="brand-logo-input" value="">
                    <div class="idealugano-brand-logo-actions">
                        <button type="button" class="button button-secondary upload-logo-btn">
                            <span class="dashicons dashicons-upload"></span> <?php _e('Carica Logo', 'idealugano'); ?>
                        </button>
                        <button type="button" class="button button-link remove-logo-btn" style="display:none;">
                            <?php _e('Rimuovi', 'idealugano'); ?>
                        </button>
                    </div>
                    <p class="description" style="font-size:11px; margin-top:4px;">PNG o SVG consigliati con sfondo trasparente.</p>
                </div>

                <div class="idealugano-brand-info-col">
                    <div class="idealugano-field-group">
                        <label><?php _e('Nome Marchio *', 'idealugano'); ?></label>
                        <input type="text" class="regular-text brand-name-input" value="" placeholder="<?php esc_attr_e('Es: KADECO, Silent Gliss', 'idealugano'); ?>" required>
                    </div>

                    <div class="idealugano-field-group">
                        <label><?php _e('Descrizione / Specializzazione', 'idealugano'); ?></label>
                        <textarea class="large-text brand-desc-input" rows="2" placeholder="<?php esc_attr_e('Breve descrizione delle specializzazioni del marchio (visibile nella pagina "Marchi").', 'idealugano'); ?>"></textarea>
                    </div>
                </div>
            </div>
        </div>
    </template>

    <style>
    .idealugano-brands-admin {
        max-width: 1100px;
        margin: 20px 20px 100px;
    }
    .idealugano-brands-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 20px;
        background: #fff;
        padding: 24px 28px;
        border-radius: 8px;
        border: 1px solid #ccd0d4;
        box-shadow: 0 1px 3px rgba(0,0,0,.04);
        margin-bottom: 20px;
        flex-wrap: wrap;
    }
    .idealugano-brands-header h1 {
        margin: 0 0 6px;
        font-size: 24px;
        font-weight: 600;
        color: #052d3a;
        display: flex;
        align-items: center;
    }
    .idealugano-brands-header__desc {
        margin: 0;
        color: #50575e;
        font-size: 13px;
        max-width: 650px;
        line-height: 1.5;
    }
    .idealugano-brands-header__actions {
        display: flex;
        align-items: center;
        gap: 15px;
    }
    #add-brand-btn {
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
        gap: 8px !important;
        line-height: 1 !important;
        padding: 0 24px !important;
        height: 44px !important;
        min-height: 44px !important;
        vertical-align: middle !important;
        box-sizing: border-box !important;
    }
    #add-brand-btn svg {
        width: 16px;
        height: 16px;
        display: block;
        flex-shrink: 0;
        margin: 0 !important;
    }
    #add-brand-btn span {
        display: inline-block;
        line-height: 1;
    }
    .idealugano-brands-counter {
        background: #f0f0f1;
        padding: 6px 14px;
        border-radius: 20px;
        font-weight: 600;
        font-size: 13px;
        color: #052d3a;
        border: 1px solid #dcdcde;
    }
    .idealugano-brands-list {
        display: flex;
        flex-direction: column;
        gap: 18px;
    }
    .idealugano-brand-card {
        background: #fff;
        border: 1px solid #ccd0d4;
        border-radius: 8px;
        box-shadow: 0 1px 3px rgba(0,0,0,.04);
        transition: border-color .2s, box-shadow .2s;
    }
    .idealugano-brand-card:hover {
        border-color: #8c8f94;
        box-shadow: 0 2px 6px rgba(0,0,0,.07);
    }
    .idealugano-brand-card__header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 10px 18px;
        background: #f6f7f7;
        border-bottom: 1px solid #ebebeb;
        border-top-left-radius: 7px;
        border-top-right-radius: 7px;
    }
    .idealugano-brand-card__num {
        font-weight: 700;
        color: #052d3a;
        font-size: 13px;
    }
    .idealugano-brand-card__controls {
        display: flex;
        align-items: center;
        gap: 6px;
    }
    .idealugano-brand-card__body {
        display: grid;
        grid-template-columns: 240px 1fr;
        gap: 24px;
        padding: 20px;
    }
    .idealugano-brand-logo-col {
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
    }
    .idealugano-brand-preview {
        width: 100%;
        height: 120px;
        background: #fafafa;
        border: 1px dashed #c3c4c7;
        border-radius: 6px;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 12px;
        box-sizing: border-box;
        margin-bottom: 10px;
        overflow: hidden;
    }
    .idealugano-brand-preview img {
        max-width: 100%;
        max-height: 100%;
        object-fit: contain;
    }
    .idealugano-brand-preview__placeholder {
        color: #8c8f94;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 4px;
        font-size: 12px;
    }
    .idealugano-brand-logo-actions {
        display: flex;
        gap: 8px;
        align-items: center;
    }
    .idealugano-brand-info-col {
        display: flex;
        flex-direction: column;
        gap: 14px;
    }
    .idealugano-field-group label {
        display: block;
        font-weight: 600;
        margin-bottom: 5px;
        color: #1d2327;
        font-size: 13px;
    }
    .idealugano-field-group .description {
        margin: 4px 0 0;
        font-size: 12px;
        color: #646970;
    }

    /* Sticky bar */
    .idealugano-sticky-bar {
        position: fixed;
        bottom: 0;
        left: 160px;
        right: 0;
        background: rgba(255, 255, 255, 0.96);
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
        border-top: 1px solid #dcdcde;
        box-shadow: 0 -4px 14px rgba(0,0,0,0.06);
        padding: 12px 30px;
        z-index: 9999;
        transition: left .2s ease;
    }
    body.folded .idealugano-sticky-bar {
        left: 36px;
    }
    @media (max-width: 782px) {
        .idealugano-sticky-bar { left: 0; }
        .idealugano-brand-card__body { grid-template-columns: 1fr; }
    }
    .idealugano-sticky-bar__inner {
        max-width: 1080px;
        margin: 0 auto;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    .idealugano-dirty-indicator {
        display: flex;
        align-items: center;
        gap: 10px;
        font-size: 13px;
        font-weight: 500;
        color: #2c3338;
    }
    .idealugano-dirty-dot {
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background: #00a32a;
        transition: background .3s;
    }
    .idealugano-dirty-dot.is-dirty {
        background: #dba617;
        box-shadow: 0 0 0 3px rgba(219, 166, 23, 0.2);
    }
    .idealugano-dirty-dot.is-saving {
        background: #2271b1;
        animation: idealugano-pulse 1s infinite alternate;
    }
    @keyframes idealugano-pulse {
        from { opacity: 0.4; transform: scale(0.9); }
        to { opacity: 1; transform: scale(1.1); }
    }
    </style>

    <script>
    jQuery(document).ready(function($) {
        var maxBrands = <?php echo (int) $max_brands; ?>;
        var nonce = '<?php echo esc_js($nonce); ?>';
        var isDirty = false;

        function updateState(dirty) {
            isDirty = dirty;
            if (dirty) {
                $('#dirty-dot').removeClass('is-saving').addClass('is-dirty');
                $('#dirty-label').text('Modifiche non salvate — premi Salva o Ctrl+S');
            } else {
                $('#dirty-dot').removeClass('is-saving is-dirty');
                $('#dirty-label').text('Tutte le modifiche salvate');
            }
        }

        function reindexCards() {
            var cards = $('#brands-list .idealugano-brand-card');
            var total = cards.length;
            $('#brands-count').text(total);

            cards.each(function(idx) {
                $(this).attr('data-index', idx);
                $(this).find('.idealugano-brand-card__num').text('#' + (idx + 1));
                $(this).find('.move-up-btn').prop('disabled', idx === 0);
                $(this).find('.move-down-btn').prop('disabled', idx === total - 1);
            });

            if (total >= maxBrands) {
                $('#add-brand-btn').prop('disabled', true);
                $('#brands-limit-warning').slideDown(200);
            } else {
                $('#add-brand-btn').prop('disabled', false);
                $('#brands-limit-warning').slideUp(200);
            }
        }

        // Detect form changes
        $('#brands-list').on('input change', 'input, textarea', function() {
            updateState(true);
        });

        // Add Brand
        $('#add-brand-btn').on('click', function() {
            var count = $('#brands-list .idealugano-brand-card').length;
            if (count >= maxBrands) return;

            var tpl = $('#brand-card-template').html();
            tpl = tpl.replace(/__INDEX__/g, count).replace(/__NUM__/g, count + 1);

            var $newCard = $(tpl);
            $('#brands-list').append($newCard);
            reindexCards();
            updateState(true);

            $newCard.find('.brand-name-input').focus();
        });

        // Delete Brand
        $('#brands-list').on('click', '.delete-brand-btn', function() {
            if (confirm('Sei sicuro di voler eliminare questo marchio?')) {
                $(this).closest('.idealugano-brand-card').fadeOut(200, function() {
                    $(this).remove();
                    reindexCards();
                    updateState(true);
                });
            }
        });

        // Move Up
        $('#brands-list').on('click', '.move-up-btn', function() {
            var $card = $(this).closest('.idealugano-brand-card');
            var $prev = $card.prev('.idealugano-brand-card');
            if ($prev.length) {
                $card.insertBefore($prev);
                reindexCards();
                updateState(true);
            }
        });

        // Move Down
        $('#brands-list').on('click', '.move-down-btn', function() {
            var $card = $(this).closest('.idealugano-brand-card');
            var $next = $card.next('.idealugano-brand-card');
            if ($next.length) {
                $card.insertAfter($next);
                reindexCards();
                updateState(true);
            }
        });

        // Media Library Uploader for Logo
        $('#brands-list').on('click', '.upload-logo-btn', function(e) {
            e.preventDefault();
            var $btn = $(this);
            var $card = $btn.closest('.idealugano-brand-card');
            var $preview = $card.find('.idealugano-brand-preview');
            var $input = $card.find('.brand-logo-input');
            var $removeBtn = $card.find('.remove-logo-btn');

            var frame = wp.media({
                title: 'Seleziona o Carica Logo Marchio',
                button: { text: 'Usa come logo' },
                multiple: false,
                library: { type: 'image' }
            });

            frame.on('select', function() {
                var attachment = frame.state().get('selection').first().toJSON();
                var url = attachment.url;
                $input.val(url);
                $preview.html('<img src="' + url + '" alt="Logo">');
                $removeBtn.show();
                updateState(true);
            });

            frame.open();
        });

        // Remove Logo
        $('#brands-list').on('click', '.remove-logo-btn', function(e) {
            e.preventDefault();
            var $card = $(this).closest('.idealugano-brand-card');
            $card.find('.brand-logo-input').val('');
            $card.find('.idealugano-brand-preview').html(
                '<div class="idealugano-brand-preview__placeholder">' +
                '<span class="dashicons dashicons-format-image"></span>' +
                '<span>Nessun logo</span></div>'
            );
            $(this).hide();
            updateState(true);
        });

        // Save Brands via AJAX
        function saveBrands() {
            var brands = [];
            $('#brands-list .idealugano-brand-card').each(function() {
                var name = $(this).find('.brand-name-input').val().trim();
                var logo = $(this).find('.brand-logo-input').val().trim();
                var desc = $(this).find('.brand-desc-input').val().trim();

                if (name !== '' || logo !== '') {
                    brands.push({
                        name: name,
                        logo: logo,
                        description: desc
                    });
                }
            });

            $('#dirty-dot').removeClass('is-dirty').addClass('is-saving');
            $('#dirty-label').text('Salvataggio in corso...');
            $('#save-brands-btn').prop('disabled', true);

            $.post(ajaxurl, {
                action: 'idealugano_save_brands',
                nonce: nonce,
                brands: JSON.stringify(brands)
            }, function(response) {
                $('#save-brands-btn').prop('disabled', false);
                if (response && response.success) {
                    updateState(false);
                    $('#dirty-label').text('Salvato ✓');
                    setTimeout(function() {
                        if (!isDirty) {
                            $('#dirty-label').text('Tutte le modifiche salvate');
                        }
                    }, 3000);
                } else {
                    alert((response && response.data && response.data.message) ? response.data.message : 'Errore durante il salvataggio.');
                    updateState(true);
                }
            }).fail(function() {
                $('#save-brands-btn').prop('disabled', false);
                alert('Errore di connessione durante il salvataggio.');
                updateState(true);
            });
        }

        $('#save-brands-btn').on('click', saveBrands);

        // Keyboard Shortcut Ctrl+S / Cmd+S
        $(window).on('keydown', function(e) {
            if ((e.ctrlKey || e.metaKey) && (e.which === 83 || e.keyCode === 83)) {
                e.preventDefault();
                saveBrands();
            }
        });

        // Warn before leaving with unsaved changes
        $(window).on('beforeunload', function() {
            if (isDirty) {
                return 'Hai modifiche non salvate. Sei sicuro di voler uscire?';
            }
        });

        reindexCards();
    });
    </script>
    <?php
}
