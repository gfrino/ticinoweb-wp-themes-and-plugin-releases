<?php
/**
 * Template Name: Landing servizio
 * Template Post Type: page
 *
 * Pagina dedicata a un singolo servizio (una per gruppo di annunci Google Ads).
 * I contenuti arrivano da inc/landings.php in base allo slug della pagina o al
 * meta `_idealugano_landing`; le immagini dal pannello "Immagini Sito" con
 * fallback alle foto incluse nel tema.
 *
 * @package Idealugano
 * @version 1.0.1
 */

$site    = idealugano_get_site_data();
$contact = $site['contact'];
$landing = idealugano_get_current_landing();

if (!$landing) {
    // Slug sconosciuto: si torna al template pagina generico.
    get_template_part('page');
    return;
}

$hero_img   = idealugano_get_slot_image($landing['hero_slot']);
$gallery    = array();
$gallery_cat = $landing['gallery_category'];
foreach (idealugano_get_frontend_gallery_items() as $g_item) {
    $cat = idealugano_normalize_gallery_category($g_item['category']);
    if ($cat === $gallery_cat) {
        $gallery[] = $g_item;
    }
    if (count($gallery) >= 6) {
        break;
    }
}
$before_after = $landing['before_after'] ? $site['before_after'] : array();
$phone_raw    = str_replace(' ', '', $contact['phone_landline'] ?: $contact['phone']);
$phone_label  = $contact['phone_landline'] ?: $contact['phone'];
$landing_index = array_search($landing['slug'], array_keys(idealugano_get_landings()), true);
?>
<?php get_header(); ?>

<main id="primary" class="site-main idea-landing" data-landing="<?php echo esc_attr($landing['slug']); ?>">

	<!-- 1. HERO -->
	<section class="idea-landing-hero" aria-labelledby="landing-title">
		<div class="idea-container">
			<nav class="idea-landing-breadcrumb" aria-label="<?php esc_attr_e('Percorso', 'idealugano'); ?>">
				<a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
				<span aria-hidden="true">/</span>
				<a href="<?php echo esc_url(home_url('/servizi/')); ?>">Servizi</a>
				<span aria-hidden="true">/</span>
				<span aria-current="page"><?php echo esc_html($landing['menu_label']); ?></span>
			</nav>
			<div class="idea-landing-hero__grid">
				<div class="idea-landing-hero__text reveal">
					<span class="idea-eyebrow"><?php echo esc_html($landing['eyebrow']); ?></span>
					<h1 id="landing-title" class="idea-landing-hero__title"><?php echo esc_html($landing['title']); ?></h1>
					<hr class="idea-gold-line">
					<p class="idea-lead"><?php echo esc_html($landing['subtitle']); ?></p>
					<div class="idea-landing-hero__actions">
						<a class="idea-btn idea-btn--gold" href="#richiesta">Richiedi un preventivo</a>
						<a class="idea-btn idea-btn--ghost" href="tel:<?php echo esc_attr($phone_raw); ?>">
							<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
							<?php echo esc_html($phone_label); ?>
						</a>
					</div>
					<p class="idea-landing-hero__meta">Atelier a Bedano (Lugano) · Interventi in tutta la Svizzera e all'estero · Su appuntamento</p>
				</div>
				<div class="idea-landing-hero__media reveal reveal--right">
					<?php if ($hero_img): ?>
						<img src="<?php echo esc_url($hero_img); ?>" <?php idealugano_img_attrs($hero_img); ?> alt="<?php echo esc_attr($landing['title']); ?>" fetchpriority="high" decoding="async" sizes="(max-width: 1024px) calc(100vw - 2.3rem), 55vw">
					<?php else: ?>
						<?php idealugano_placeholder_image('4/3', $landing['menu_label']); ?>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</section>

	<!-- 2. INTRO + PILASTRI -->
	<section class="idea-section idea-section--white" aria-labelledby="landing-intro-title">
		<div class="idea-container">
			<div class="idea-landing-intro reveal">
				<span class="idea-eyebrow">Il servizio</span>
				<h2 id="landing-intro-title">Come lavoriamo</h2>
				<hr class="idea-gold-line">
				<?php foreach ($landing['intro'] as $paragraph): ?>
					<p class="idea-landing-intro__p"><?php echo esc_html($paragraph); ?></p>
				<?php endforeach; ?>
			</div>
			<div class="idea-pillars-grid reveal-stagger">
				<?php foreach ($landing['pillars'] as $i => $pillar): ?>
					<div class="idea-pillar-card reveal">
						<div class="idea-pillar-card__icon" aria-hidden="true"><span class="idea-pillar-card__num"><?php echo str_pad($i + 1, 2, '0', STR_PAD_LEFT); ?></span></div>
						<h3><?php echo esc_html($pillar['title']); ?></h3>
						<p><?php echo esc_html($pillar['text']); ?></p>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</section>

	<!-- 3. COSA REALIZZIAMO -->
	<section class="idea-section idea-section--cream" aria-labelledby="landing-offer-title">
		<div class="idea-container">
			<div class="idea-landing-offer">
				<div class="idea-landing-offer__text reveal">
					<span class="idea-eyebrow">In dettaglio</span>
					<h2 id="landing-offer-title"><?php echo esc_html($landing['offer']['title']); ?></h2>
					<hr class="idea-gold-line">
					<p class="idea-lead">Ogni lavoro parte da un sopralluogo e da un preventivo chiaro. Ecco cosa possiamo fare per te.</p>
				</div>
				<ul class="idea-check-list reveal reveal--right">
					<?php foreach ($landing['offer']['items'] as $item): ?>
						<li>
							<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="20 6 9 17 4 12"></polyline></svg>
							<span><?php echo esc_html($item); ?></span>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
		</div>
	</section>

	<!-- 4. PARTNER / COLLEZIONI -->
	<?php if (!empty($landing['suppliers']['items'])): ?>
	<section class="idea-section idea-section--white" aria-labelledby="landing-partners-title">
		<div class="idea-container">
			<div class="idea-text-center idea-mb-8 reveal">
				<span class="idea-eyebrow">Marchi partner</span>
				<h2 id="landing-partners-title"><?php echo esc_html($landing['suppliers']['title']); ?></h2>
				<hr class="idea-gold-line idea-gold-line--center">
				<p class="idea-lead idea-mx-auto"><?php echo esc_html($landing['suppliers']['text']); ?></p>
			</div>
			<div class="idea-partner-grid reveal-stagger">
				<?php foreach ($landing['suppliers']['items'] as $item): ?>
					<?php $p_img = !empty($item['slot']) ? idealugano_get_slot_image($item['slot']) : false; ?>
					<article class="idea-partner-card reveal">
						<div class="idea-partner-card__image">
							<?php if ($p_img): ?>
								<img src="<?php echo esc_url($p_img); ?>" <?php idealugano_img_attrs($p_img); ?> alt="<?php echo esc_attr($item['brand'] . ': ' . $item['title']); ?>" loading="lazy" decoding="async" sizes="(max-width: 640px) calc(100vw - 2.3rem), (max-width: 1024px) 46vw, 30vw">
							<?php else: ?>
								<?php idealugano_placeholder_image('4/3', $item['title']); ?>
							<?php endif; ?>
							<span class="idea-partner-card__brand"><?php echo esc_html($item['brand']); ?></span>
						</div>
						<div class="idea-partner-card__body">
							<h3 class="idea-partner-card__title"><?php echo esc_html($item['title']); ?></h3>
							<p class="idea-partner-card__desc"><?php echo esc_html($item['desc']); ?></p>
							<?php if (!empty($item['url'])): ?>
								<a class="idea-partner-card__link" href="<?php echo esc_url($item['url']); ?>" target="_blank" rel="noopener nofollow">Scheda sul sito <?php echo esc_html($item['brand']); ?> <span class="idea-link__arrow" aria-hidden="true">→</span></a>
							<?php endif; ?>
						</div>
					</article>
				<?php endforeach; ?>
			</div>
			<p class="idea-partner-note">Foto e nomi dei prodotti: © dei rispettivi marchi. Idea Lugano è rivenditore e partner con consegna in tutta la Svizzera e all'estero; disponibilità, tessuti e finiture si definiscono in atelier.</p>
		</div>
	</section>
	<?php endif; ?>

	<!-- 5. PRIMA & DOPO (solo rifacimento) -->
	<?php if (!empty($before_after)): ?>
	<section class="idea-section idea-section--cream" aria-labelledby="landing-ba-title">
		<div class="idea-container">
			<div class="idea-text-center idea-mb-8 reveal">
				<span class="idea-eyebrow">Prima &amp; Dopo</span>
				<h2 id="landing-ba-title">Le nostre trasformazioni</h2>
				<hr class="idea-gold-line idea-gold-line--center">
				<p class="idea-lead idea-mx-auto">Trascina il cursore per confrontare il mobile prima e dopo il rifacimento.</p>
			</div>
			<div class="idea-ba-carousel reveal" aria-roledescription="carousel">
			<?php foreach ($before_after as $ba_index => $ba): ?>
				<div class="idea-ba-project<?php echo $ba_index === 0 ? ' is-active' : ''; ?>" <?php echo $ba_index === 0 ? '' : 'hidden'; ?>>
					<div class="idea-ba-slider" role="slider" aria-label="Confronto prima e dopo" aria-valuemin="0" aria-valuemax="100" aria-valuenow="50" tabindex="0">
						<div class="idea-ba-slider__before">
							<?php $ba_before = (!empty($ba['slot_before']) ? idealugano_get_slot_image($ba['slot_before']) : false) ?: idealugano_get_image_by_filename(basename($ba['before'] ?? '')); ?>
							<?php if ($ba_before): ?>
								<img src="<?php echo esc_url($ba_before); ?>" <?php idealugano_img_attrs($ba_before); ?> alt="Prima: <?php echo esc_attr($ba['title']); ?>" loading="lazy" decoding="async" sizes="(max-width: 767px) calc(100vw - 2.3rem), 100vw">
							<?php else: ?>
								<?php idealugano_placeholder_image('16/9', 'Prima — ' . $ba['title']); ?>
							<?php endif; ?>
						</div>
						<div class="idea-ba-slider__after">
							<?php $ba_after = (!empty($ba['slot_after']) ? idealugano_get_slot_image($ba['slot_after']) : false) ?: idealugano_get_image_by_filename(basename($ba['after'] ?? '')); ?>
							<?php if ($ba_after): ?>
								<img src="<?php echo esc_url($ba_after); ?>" <?php idealugano_img_attrs($ba_after); ?> alt="Dopo: <?php echo esc_attr($ba['title']); ?>" loading="lazy" decoding="async" sizes="(max-width: 767px) calc(100vw - 2.3rem), 100vw">
							<?php else: ?>
								<?php idealugano_placeholder_image('16/9', 'Dopo — ' . $ba['title']); ?>
							<?php endif; ?>
						</div>
						<div class="idea-ba-slider__handle"></div>
						<span class="idea-ba-slider__label idea-ba-slider__label--before">Prima</span>
						<span class="idea-ba-slider__label idea-ba-slider__label--after">Dopo</span>
					</div>
					<div class="idea-text-center idea-mt-4">
						<h3><?php echo esc_html($ba['title']); ?></h3>
						<p class="idea-lead idea-mx-auto"><?php echo esc_html($ba['description']); ?></p>
					</div>
				</div>
			<?php endforeach; ?>
			<?php if (count($before_after) > 1): ?>
				<button class="idea-ba-carousel__arrow idea-ba-carousel__arrow--prev" type="button" aria-label="Progetto precedente">‹</button>
				<button class="idea-ba-carousel__arrow idea-ba-carousel__arrow--next" type="button" aria-label="Progetto successivo">›</button>
				<div class="idea-ba-carousel__status" aria-live="polite">1 / <?php echo count($before_after); ?></div>
			<?php endif; ?>
			</div>
		</div>
	</section>
	<?php endif; ?>

	<!-- 6. GALLERIA LAVORI -->
	<?php if (!empty($gallery)): ?>
	<section class="idea-section <?php echo empty($before_after) ? 'idea-section--cream' : 'idea-section--white'; ?>" aria-labelledby="landing-gallery-title">
		<div class="idea-container">
			<div class="idea-mb-8 reveal">
				<span class="idea-eyebrow">Realizzazioni</span>
				<h2 id="landing-gallery-title">Alcuni nostri lavori</h2>
				<hr class="idea-gold-line">
			</div>
			<div class="idea-landing-gallery reveal-stagger">
				<?php foreach ($gallery as $g_item): ?>
					<?php $g_img = idealugano_get_slot_image($g_item['slot']); ?>
					<a class="idea-landing-gallery__item reveal" href="<?php echo esc_url(home_url('/galleria/?categoria=' . $gallery_cat . '#gallery-grid-title')); ?>" aria-label="<?php echo esc_attr(sprintf(__('Vedi %s nella galleria', 'idealugano'), $g_item['title'])); ?>">
						<img src="<?php echo esc_url($g_img); ?>" <?php idealugano_img_attrs($g_img); ?> alt="<?php echo esc_attr($g_item['title']); ?>" loading="lazy" decoding="async" sizes="(max-width: 640px) calc(100vw - 2.3rem), (max-width: 1024px) 46vw, 30vw">
						<span class="idea-landing-gallery__caption"><?php echo esc_html($g_item['title']); ?></span>
					</a>
				<?php endforeach; ?>
			</div>
			<div class="idea-text-center idea-mt-6 reveal">
				<a class="idea-btn idea-btn--ghost" href="<?php echo esc_url(home_url('/galleria/?categoria=' . $gallery_cat . '#gallery-grid-title')); ?>">Vedi tutta la galleria</a>
			</div>
		</div>
	</section>
	<?php endif; ?>

	<!-- 7. FAQ -->
	<?php $landing_faq = idealugano_landing_faq($landing); ?>
	<?php if (!empty($landing_faq)): ?>
	<section class="idea-section idea-section--white idea-faq-main-section" aria-labelledby="landing-faq-title">
		<div class="idea-container idea-faq-container">
			<div class="idea-faq-category">
				<div class="idea-faq-category__header reveal">
					<span class="idea-eyebrow">Domande frequenti</span>
					<h2 id="landing-faq-title" class="idea-faq-category__title">Le domande che ci fanno più spesso</h2>
					<hr class="idea-gold-line">
				</div>
				<div class="idea-faq-items reveal">
					<?php foreach ($landing_faq as $f_index => $faq): ?>
						<details class="idea-faq-item" <?php echo $f_index === 0 ? 'open' : ''; ?>>
							<summary class="idea-faq-question">
								<h3 class="idea-faq-question__title"><?php echo esc_html($faq['q']); ?></h3>
								<span class="idea-faq-toggle" aria-hidden="true">
									<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
								</span>
							</summary>
							<div class="idea-faq-answer"><?php echo wp_kses_post(wpautop($faq['a'])); ?></div>
						</details>
					<?php endforeach; ?>
				</div>
				<p class="idea-mt-4"><a class="idea-link" href="<?php echo esc_url(home_url('/faq/')); ?>">Tutte le domande frequenti <span class="idea-link__arrow" aria-hidden="true">→</span></a></p>
			</div>
		</div>
	</section>
	<?php endif; ?>

	<!-- 8. RICHIESTA / FORM -->
	<section class="idea-section idea-section--petrol idea-landing-request" id="richiesta" aria-labelledby="landing-request-title">
		<div class="idea-container">
			<div class="idea-landing-request__grid">
				<div class="idea-landing-request__text reveal">
					<span class="idea-eyebrow" style="color: var(--idea-gold-light);">Preventivo gratuito</span>
					<h2 id="landing-request-title"><?php echo esc_html($landing['cta_title']); ?></h2>
					<hr class="idea-gold-line" style="background: linear-gradient(90deg, var(--idea-gold-light), transparent);">
					<p class="idea-lead" style="color: rgba(247, 243, 234, 0.8);"><?php echo esc_html($landing['cta_text']); ?></p>
					<ul class="idea-landing-request__contacts">
						<li>
							<span>Telefono</span>
							<a href="tel:<?php echo esc_attr($phone_raw); ?>"><?php echo esc_html($phone_label); ?></a>
							<?php if (!empty($contact['phone']) && $contact['phone'] !== $phone_label): ?>
								<a href="tel:<?php echo esc_attr(str_replace(' ', '', $contact['phone'])); ?>"><?php echo esc_html($contact['phone']); ?></a>
							<?php endif; ?>
						</li>
						<li><span>Email</span><a href="mailto:<?php echo esc_attr($contact['email']); ?>"><?php echo esc_html($contact['email']); ?></a></li>
						<li><span>Atelier</span><address><?php echo esc_html($contact['address']); ?></address></li>
						<li><span>Ricevimento</span><?php echo esc_html($site['hours_note']); ?></li>
					</ul>
				</div>
				<div class="idea-landing-request__form reveal reveal--right">
					<form class="idea-form idea-form--on-dark" id="idea-contact-form" novalidate>
						<div class="idea-form__hp" aria-hidden="true">
							<label for="idea-hp-landing">Lascia vuoto questo campo</label>
							<input type="text" id="idea-hp-landing" name="tw_hp" tabindex="-1" autocomplete="off">
						</div>
						<input type="hidden" name="oggetto" value="<?php echo esc_attr($landing['form_subject']); ?>">
						<input type="hidden" name="pagina" value="<?php echo esc_attr($landing['title']); ?>">
						<div class="idea-form__group">
							<label class="idea-form__label" for="idea-name">Nome *</label>
							<input class="idea-form__input" type="text" id="idea-name" name="nome" required autocomplete="name" placeholder="Il tuo nome">
							<span class="idea-form__error" id="idea-name-error">Inserisci il tuo nome</span>
						</div>
						<div class="idea-form__group">
							<label class="idea-form__label" for="idea-email">Email *</label>
							<input class="idea-form__input" type="email" id="idea-email" name="email" required autocomplete="email" placeholder="La tua email">
							<span class="idea-form__error" id="idea-email-error">Inserisci un'email valida</span>
						</div>
						<div class="idea-form__group">
							<label class="idea-form__label" for="idea-phone">Telefono</label>
							<input class="idea-form__input" type="tel" id="idea-phone" name="telefono" autocomplete="tel" placeholder="Per richiamarti (facoltativo)">
						</div>
						<div class="idea-form__group">
							<label class="idea-form__label" for="idea-message">La tua richiesta *</label>
							<textarea class="idea-form__textarea" id="idea-message" name="messaggio" required rows="5" placeholder="<?php echo esc_attr(sprintf('Descrivi cosa ti serve: %s', strtolower($landing['short']))); ?>"></textarea>
							<span class="idea-form__error" id="idea-message-error">Inserisci un messaggio</span>
						</div>
						<div class="idea-form__group">
							<label class="idea-form__label" for="idea-photos">Foto (facoltativo)</label>
							<label class="idea-form__file" for="idea-photos">
								<input type="file" id="idea-photos" name="foto[]" accept="image/*" multiple>
								<span class="idea-form__file-text" id="idea-photos-text">Aggiungi una o più foto (max 5)</span>
							</label>
							<ul class="idea-form__thumbs" id="idea-photos-list" aria-live="polite"></ul>
							<span class="idea-form__error" id="idea-photos-error"></span>
						</div>
						<button type="submit" class="idea-btn idea-btn--gold" id="idea-submit">Invia la richiesta</button>
						<p class="idea-form__privacy">Inviando accetti la <a href="<?php echo esc_url(home_url('/privacy-policy/')); ?>">Privacy Policy</a>. Rispondiamo di norma entro un giorno lavorativo.</p>
						<div class="idea-form__fail" id="idea-form-fail" role="alert"></div>
						<div class="idea-form__success" id="idea-form-success" role="status" tabindex="-1">Grazie! La tua richiesta è stata inviata. Ti ricontatteremo al più presto.</div>
					</form>
				</div>
			</div>
		</div>
	</section>

	<!-- 9. ALTRI SERVIZI -->
	<?php if (!empty($landing['related'])): ?>
	<section class="idea-section idea-section--cream" aria-labelledby="landing-related-title">
		<div class="idea-container">
			<div class="idea-mb-6 reveal">
				<span class="idea-eyebrow">Potrebbe interessarti</span>
				<h2 id="landing-related-title">Gli altri nostri servizi</h2>
				<hr class="idea-gold-line">
			</div>
			<div class="idea-related-grid reveal-stagger">
				<?php foreach ($landing['related'] as $rel_slug): ?>
					<?php $rel = idealugano_get_landing($rel_slug); if (!$rel) continue; $rel_img = idealugano_get_slot_image($rel['hero_slot']); ?>
					<a class="idea-related-card reveal" href="<?php echo esc_url(idealugano_landing_url($rel_slug)); ?>">
						<?php if ($rel_img): ?>
							<img src="<?php echo esc_url($rel_img); ?>" <?php idealugano_img_attrs($rel_img); ?> alt="" loading="lazy" decoding="async" sizes="(max-width: 640px) calc(100vw - 2.3rem), 33vw">
						<?php endif; ?>
						<span class="idea-related-card__body">
							<span class="idea-eyebrow"><?php echo esc_html($rel['eyebrow']); ?></span>
							<span class="idea-related-card__title"><?php echo esc_html($rel['menu_label']); ?></span>
							<span class="idea-link">Scopri <span class="idea-link__arrow" aria-hidden="true">→</span></span>
						</span>
					</a>
				<?php endforeach; ?>
				<a class="idea-related-card idea-related-card--all reveal" href="<?php echo esc_url(home_url('/servizi/')); ?>">
					<span class="idea-related-card__body">
						<span class="idea-eyebrow">Panoramica</span>
						<span class="idea-related-card__title">Tutti i servizi</span>
						<span class="idea-link">Vai ai servizi <span class="idea-link__arrow" aria-hidden="true">→</span></span>
					</span>
				</a>
			</div>
		</div>
	</section>
	<?php endif; ?>

</main>

<?php get_footer(); ?>
