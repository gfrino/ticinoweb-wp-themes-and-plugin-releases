<?php
/**
 * Template Name: Marchi
 * Template Post Type: page
 *
 * Pagina dedicata ai marchi partner d'eccellenza di Idea Lugano.
 *
 * @package Idealugano
 * @version 1.9.93
 */

$site = idealugano_get_site_data();
$brands = $site['brands'];
$contact = $site['contact'];
?>
<?php get_header(); ?>

<main id="primary" class="site-main">

	<!-- ═══════════════════════════════════════════
	     1. PAGE HERO
	     ═══════════════════════════════════════════ -->
	<section class="idea-page-hero" aria-labelledby="brands-page-title">
		<span class="idea-deco-word idea-fx" data-speed="0.8" style="bottom: -3rem; right: -5%; opacity: 0.25;" aria-hidden="true">PARTNER</span>
		<div class="idea-container">
			<span class="idea-eyebrow">Partner d'eccellenza</span>
			<h1 id="brands-page-title" class="idea-page-hero__title">I nostri marchi selezionati</h1>
			<hr class="idea-gold-line idea-gold-line--center">
			<p class="idea-page-hero__subtitle">
				Collaboriamo con le migliori manifatture europee per garantire soluzioni tecniche raffinate, tessuti d'autore e arredi su misura di altissima qualità.
			</p>
		</div>
	</section>

	<!-- ═══════════════════════════════════════════
	     2. BRANDS DETAILED SHOWCASE
	     ═══════════════════════════════════════════ -->
	<section class="idea-section idea-section--white" aria-labelledby="brands-showcase-title">
		<div class="idea-container">
			<div class="idea-text-center idea-mb-8 reveal">
				<h2 id="brands-showcase-title" class="idea-section-title">Qualità e innovazione al servizio del tuo spazio</h2>
				<hr class="idea-gold-line idea-gold-line--center">
				<p class="idea-lead idea-mx-auto">
					Ogni marchio è scelto per la sua capacità di coniugare rigore costruttivo, estetica senza tempo e affidabilità nel tempo.
				</p>
			</div>

			<div class="idea-brands-detail-grid reveal">
				<?php foreach ($brands as $index => $brand): ?>
					<?php
					$brand_img = !empty($brand['logo']) ? $brand['logo'] : ((!empty($brand['slot']) ? idealugano_get_slot_image($brand['slot']) : false) ?: idealugano_get_image_by_filename(basename(!empty($brand['logo']) ? $brand['logo'] : '')));
					?>
					<article class="idea-brand-detail-card" aria-label="<?php echo esc_attr($brand['name']); ?>">
						<div class="idea-brand-detail-card__logo-wrap">
							<?php if ($brand_img): ?>
								<img class="idea-brand-detail-card__logo" src="<?php echo esc_url($brand_img); ?>" <?php idealugano_img_attrs($brand_img); ?> alt="Logo <?php echo esc_attr($brand['name']); ?>" loading="lazy" decoding="async">
							<?php else: ?>
								<span class="idea-brand-detail-card__text-logo"><?php echo esc_html($brand['name']); ?></span>
							<?php endif; ?>
						</div>
						<div class="idea-brand-detail-card__content">
							<h3 class="idea-brand-detail-card__name"><?php echo esc_html($brand['name']); ?></h3>
							<?php if (!empty($brand['description'])): ?>
								<p class="idea-brand-detail-card__desc"><?php echo nl2br(esc_html($brand['description'])); ?></p>
							<?php endif; ?>
						</div>
					</article>
				<?php endforeach; ?>
			</div>
		</div>
	</section>

	<!-- ═══════════════════════════════════════════
	     3. QUALITY PHILOSOPHY PILLARS
	     ═══════════════════════════════════════════ -->
	<section class="idea-section idea-section--cream">
		<div class="idea-container">
			<div class="idea-text-center idea-mb-8 reveal">
				<span class="idea-eyebrow">La nostra filosofia</span>
				<h2>Perché selezioniamo solo i migliori</h2>
				<hr class="idea-gold-line idea-gold-line--center">
				<p class="idea-lead idea-mx-auto">
					Un progetto di arredo sartoriale richiede componenti meccaniche perfette e tessuti che mantengano la loro bellezza negli anni.
				</p>
			</div>

			<div class="idea-pillars-grid reveal-stagger">
				<div class="idea-pillar-card reveal">
					<div class="idea-pillar-card__icon">
						<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/></svg>
					</div>
					<h3>Meccanica di Precisione</h3>
					<p>Binari scorrevoli, sistemi motorizzati silenziosi e schermature solari progettati per durare decenni con la massima fluidità di scorrimento.</p>
				</div>
				<div class="idea-pillar-card reveal">
					<div class="idea-pillar-card__icon">
						<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
					</div>
					<h3>Tessuti e Fibre Nobili</h3>
					<p>Lini puri, velluti pregiati, lane pettinate e tessuti tecnici ignifughi selezionati direttamente dalle maison tessili più rinomate al mondo.</p>
				</div>
				<div class="idea-pillar-card reveal">
					<div class="idea-pillar-card__icon">
						<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>
					</div>
					<h3>Sartorialità e Installazione</h3>
					<p>La lavorazione manuale nel nostro laboratorio di Bedano e la posa in opera eseguita a regola d'arte per valorizzare ogni ambiente abitativo o commerciale.</p>
				</div>
			</div>
		</div>
	</section>

	<!-- ═══════════════════════════════════════════
	     4. CALL TO ACTION
	     ═══════════════════════════════════════════ -->
	<section class="idea-section idea-section--petrol">
		<div class="idea-container idea-text-center reveal">
			<h2>Scopri i campionari nel nostro atelier</h2>
			<hr class="idea-gold-line idea-gold-line--center" style="background: linear-gradient(90deg, transparent, var(--idea-gold-light), transparent);">
			<p class="idea-lead idea-mx-auto" style="color: rgba(247, 243, 234, 0.75);">
				Tocca con mano le texture, confronta i sistemi tecnici e lasciati consigliare per trovare la combinazione ideale per la tua casa.
			</p>
			<div class="idea-mt-4" style="display:flex; justify-content:center; gap:16px; flex-wrap:wrap;">
				<a class="idea-btn idea-btn--gold" href="<?php echo esc_url(home_url('/contatti/')); ?>">
					Prenota una consulenza
				</a>
				<a class="idea-btn idea-btn--ghost" href="tel:<?php echo esc_attr(str_replace(' ', '', $contact['phone'])); ?>">
					Chiamaci ora
				</a>
			</div>
		</div>
	</section>

</main>

<?php get_footer(); ?>
