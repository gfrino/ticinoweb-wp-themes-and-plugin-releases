<?php
/**
 * Generic page fallback template
 *
 * @package Idealugano
 * @version 1.0.0
 */
?>
<?php get_header(); ?>

<main id="primary" class="site-main">

	<section class="idea-page-hero" aria-labelledby="page-title">
		<div class="idea-container">
			<h1 id="page-title" class="idea-page-hero__title"><?php the_title(); ?></h1>
			<hr class="idea-gold-line idea-gold-line--center">
		</div>
	</section>

	<section class="idea-section idea-section--white">
		<div class="idea-container idea-container--narrow">
			<?php
			while (have_posts()):
				the_post();
				the_content();
			endwhile;
			?>
		</div>
	</section>

</main>

<?php get_footer(); ?>
