<?php
/**
 * Idealugano child theme header
 * Layout: Left nav | Center logo | Right nav + icons
 * Le voci arrivano dal menu WordPress `primary` (inc/navigation.php).
 *
 * @package Idealugano
 * @version 1.4.0
 */
$site = idealugano_get_site_data();
$contact = $site['contact'];
$idea_nav_tree = idealugano_get_nav_tree();
list($idea_nav_left, $idea_nav_right) = idealugano_nav_split($idea_nav_tree);
?><!doctype html>
<html <?php language_attributes(); ?> class="no-js">

<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<script>document.documentElement.classList.remove('no-js');</script>
	<script>
		try {
			if (sessionStorage.getItem('idealuganoTransition') === '1') {
				document.documentElement.classList.add('idea-transition-arrival');
				window.setTimeout(function () {
					document.documentElement.classList.remove('idea-transition-arrival');
				}, 6000);
			}
		} catch (error) {}
		window.addEventListener('pageshow', function (event) {
			if (event.persisted) {
				document.documentElement.classList.remove('idea-transition-arrival');
				if (document.body) {
					document.body.classList.remove('idea-transitioning');
				}
				var panel = document.querySelector('.idea-page-transition');
				if (panel) {
					panel.style.transform = 'translateY(101%)';
					var span = panel.querySelector('span');
					if (span) span.style.opacity = '0';
				}
			}
		});
	</script>
	<style>
		html.idea-transition-arrival,
		html.idea-transition-arrival body { background: #052d3a !important; }
		html.idea-transition-arrival body > :not(.idea-page-transition) { visibility: hidden !important; }
		html.idea-transition-arrival .idea-page-transition {
			position: fixed !important;
			inset: 0 !important;
			z-index: 20000 !important;
			display: grid !important;
			place-items: center !important;
			background: #052d3a !important;
			color: #f7f3ea !important;
			visibility: visible !important;
			transform: translateY(0) !important;
		}
	</style>
	<?php wp_head(); ?>
</head>

<body <?php body_class('idea-body'); ?>>
	<?php wp_body_open(); ?>
	<a class="idea-skip-link" href="#primary"><?php esc_html_e('Vai al contenuto', 'idealugano'); ?></a>
	<?php // Grafia ufficiale del marchio: IDeA, con la sola "e" minuscola. ?>
	<div class="idea-page-transition" aria-hidden="true"><span>IDeA Lugano</span></div>

	<!-- Mobile Menu Overlay -->
	<div class="idea-mobile-menu" id="idea-mobile-menu" aria-hidden="true">
		<button class="idea-mobile-menu__close" id="idea-mobile-menu-close" type="button" aria-label="<?php esc_attr_e('Chiudi menu', 'idealugano'); ?>">
			<span></span><span></span>
		</button>
		<?php idealugano_render_mobile_nav_items($idea_nav_tree); ?>
		<div class="idea-mobile-menu__cta">
			<a class="idea-btn idea-btn--gold" href="<?php echo esc_url(home_url('/contatti/')); ?>">
				Richiedi consulenza
			</a>
		</div>
	</div>

	<!-- Header — 3-column: Left nav | Center logo | Right nav + icons -->
	<header id="masthead" class="idea-header" role="banner">
		<div class="idea-header__inner">

			<!-- Left navigation -->
			<nav class="idea-header__nav-left" aria-label="<?php esc_attr_e('Navigazione sinistra', 'idealugano'); ?>">
				<?php idealugano_render_nav_items($idea_nav_left); ?>
			</nav>

			<!-- Center logo -->
			<a class="idea-header__logo" href="<?php echo esc_url(home_url('/')); ?>" rel="home">
				<?php
				$logo = '';
				if (function_exists('ticinoweb_get_site_logo')) {
					$logo = ticinoweb_get_site_logo();
				}
				if ($logo):
				?>
					<img src="<?php echo esc_url($logo); ?>" alt="<?php echo esc_attr($site['brand']); ?>" class="idea-header__logo-img">
				<?php else: ?>
					<span class="idea-header__logo-monogram">IL</span>
					<span class="idea-header__logo-brand">IDEA LUGANO</span>
				<?php endif; ?>
			</a>

			<!-- Right navigation + icons -->
			<div class="idea-header__nav-right">
				<nav aria-label="<?php esc_attr_e('Navigazione destra', 'idealugano'); ?>">
					<?php idealugano_render_nav_items($idea_nav_right); ?>
				</nav>

				<!-- Hamburger -->
				<button class="idea-hamburger" id="idea-hamburger"
					aria-controls="idea-mobile-menu" aria-expanded="false"
					aria-label="<?php esc_attr_e('Apri menu', 'idealugano'); ?>">
					<span></span>
					<span></span>
					<span></span>
				</button>
			</div>

		</div>
	</header>

	<!-- ScrollSmoother structure — every fixed element (page transition, mobile
	     menu, header, curtain intro) stays OUTSIDE #smooth-content -->
	<div id="smooth-wrapper">
		<div id="smooth-content">
