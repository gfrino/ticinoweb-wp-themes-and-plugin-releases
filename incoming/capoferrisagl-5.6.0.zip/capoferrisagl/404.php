<?php
/**
 * Pagina 404. Testi modificabili in ticinoWEB CMS → Impostazioni sito.
 *
 * @package Capoferrisagl
 */

get_header();

$title = cfs_settings('e404_title', '');
$text  = cfs_settings('e404_text', '');
$btn   = cfs_settings('e404_btn', '');
$url   = cfs_settings('e404_url', '');
?>

<section class="cfs-404">
    <div class="cfs-container cfs-404__inner">
        <p class="cfs-404__code" aria-hidden="true">404</p>
        <?php if ($title) : ?>
            <h1 class="cfs-section-title"><?php echo esc_html($title); ?></h1>
        <?php endif; ?>
        <?php if ($text) : ?>
            <div class="cfs-prose"><?php cfs_paragraphs($text); ?></div>
        <?php endif; ?>
        <?php cfs_the_button($btn, $url ?: home_url('/'), 'cfs-btn cfs-btn--primary'); ?>
    </div>
</section>

<?php get_footer(); ?>
