<?php
/**
 * Template dinamico unico per tutte le pagine dei servizi.
 *
 * @package Capoferrisagl
 */

get_header();

while (have_posts()) :
    the_post();

    $id       = get_the_ID();
    $cover    = cfs_service_cover($id);
    $mobile   = (int) cfs_service_meta($id, 'cover_mobile', 0);
    $focal    = cfs_focal(cfs_service_meta($id, 'cover_focal', ''));
    $title    = cfs_service_meta($id, 'hero_title', '') ?: get_the_title();
    $label    = cfs_service_meta($id, 'label', '');
    $number   = cfs_service_meta($id, 'hero_number', '');
    $intro    = cfs_service_meta($id, 'intro', '');
    ?>

    <article class="cfs-service-page">

        <header class="cfs-hero cfs-hero--service">
            <div class="cfs-hero__media" aria-hidden="true">
                <?php if ($cover) : ?>
                    <picture>
                        <?php if ($mobile) :
                            $m = cfs_image($mobile, 'cfs-portrait'); ?>
                            <source media="(max-width: 767px)" srcset="<?php echo esc_url($m['url']); ?>">
                        <?php endif; ?>
                        <?php cfs_the_image($cover, 'cfs-hero', array(
                            'class'         => 'cfs-hero__img',
                            'loading'       => 'eager',
                            'fetchpriority' => 'high',
                            'focal'         => $focal,
                            'alt'           => cfs_service_meta($id, 'cover_alt', ''),
                        )); ?>
                    </picture>
                <?php endif; ?>
                <span class="cfs-hero__scrim"></span>
            </div>

            <div class="cfs-container cfs-hero__content">
                <?php cfs_the_breadcrumb(array(
                    array('label' => get_the_title(cfs_page_id('servizi')) ?: __('Servizi', 'capoferrisagl'), 'url' => cfs_page_url('servizi')),
                    array('label' => get_the_title()),
                )); ?>

                <?php if ($label) : ?>
                    <p class="cfs-eyebrow cfs-eyebrow--light" data-hero-item>
                        <span class="cfs-eyebrow__mark" aria-hidden="true"></span><?php echo esc_html($label); ?>
                    </p>
                <?php endif; ?>

                <h1 class="cfs-hero__title cfs-hero__title--service" data-hero-title><?php echo esc_html($title); ?></h1>

                <?php if (cfs_service_meta($id, 'hero_intro', '')) : ?>
                    <div class="cfs-hero__text" data-hero-item><?php cfs_paragraphs(cfs_service_meta($id, 'hero_intro', '')); ?></div>
                <?php endif; ?>

                <div class="cfs-hero__actions" data-hero-item>
                    <?php cfs_the_button(
                        cfs_service_meta($id, 'hero_cta_text', ''),
                        cfs_service_meta($id, 'hero_cta_url', ''),
                        'cfs-btn cfs-btn--primary'
                    ); ?>
                </div>

                <?php if ($number) : ?>
                    <span class="cfs-hero__number" aria-hidden="true"><?php echo esc_html($number); ?></span>
                <?php endif; ?>
            </div>
        </header>

        <?php if ($intro || cfs_service_meta($id, 'intro_title', '')) : ?>
            <section class="cfs-service-intro">
                <div class="cfs-container cfs-service-intro__grid">
                    <div class="cfs-service-intro__text">
                        <?php if (cfs_service_meta($id, 'intro_title', '')) : ?>
                            <h2 class="cfs-section-title" data-split="lines"><?php echo esc_html(cfs_service_meta($id, 'intro_title', '')); ?></h2>
                        <?php endif; ?>
                        <div class="cfs-prose" data-reveal="text"><?php cfs_paragraphs($intro); ?></div>
                    </div>

                    <?php
                    $intro_image = (int) cfs_service_meta($id, 'intro_image', 0);
                    if ($intro_image) : ?>
                        <figure class="cfs-service-intro__media" data-reveal="image">
                            <?php cfs_the_image($intro_image, 'cfs-portrait', array('class' => 'cfs-service-intro__img')); ?>
                            <span class="cfs-tech-frame" aria-hidden="true"></span>
                        </figure>
                    <?php endif; ?>
                </div>

                <?php
                $strengths = cfs_rows(cfs_service_meta($id, 'strengths', array()));
                if ($strengths) : ?>
                    <div class="cfs-container">
                        <?php cfs_render_strengths($strengths, 'cfs-strengths cfs-strengths--grid'); ?>
                    </div>
                <?php endif; ?>
            </section>
        <?php endif; ?>

        <?php
        $blocks = cfs_service_meta($id, 'blocks', array());
        if (is_array($blocks) && $blocks) : ?>
            <div class="cfs-blocks">
                <div class="cfs-container">
                    <?php cfs_render_blocks($blocks); ?>
                </div>
            </div>
        <?php endif; ?>

        <?php
        cfs_render_gallery(
            cfs_service_gallery($id),
            cfs_service_meta($id, 'gallery_title', ''),
            cfs_service_meta($id, 'gallery_text', '')
        );
        ?>

        <?php
        cfs_render_cta(array(
            'title'     => cfs_service_meta($id, 'cta_title', ''),
            'text'      => cfs_service_meta($id, 'cta_text', ''),
            'btn1_text' => cfs_service_meta($id, 'cta_btn1_text', ''),
            'btn1_url'  => cfs_service_meta($id, 'cta_btn1_url', ''),
            'btn2_text' => cfs_service_meta($id, 'cta_btn2_text', ''),
            'btn2_url'  => cfs_service_meta($id, 'cta_btn2_url', ''),
            'image'     => cfs_service_meta($id, 'cta_image', ''),
        ));
        ?>

        <?php
        // Altri servizi: navigazione trasversale.
        $others = array_filter(cfs_get_services(), function ($service) use ($id) {
            return $service->ID !== $id;
        });
        $others = array_slice(array_values($others), 0, 3);
        $related_title = cfs_settings('related_title', '');
        if ($others && $related_title) : ?>
            <section class="cfs-related">
                <div class="cfs-container">
                    <h2 class="cfs-section-title" data-split="lines"><?php echo esc_html($related_title); ?></h2>
                    <div class="cfs-related__grid" data-services-grid>
                        <?php foreach ($others as $index => $service) : ?>
                            <?php cfs_service_card($service->ID, $index); ?>
                        <?php endforeach; ?>
                    </div>
                </div>
            </section>
        <?php endif; ?>

    </article>

<?php endwhile; ?>

<?php get_footer(); ?>
