<?php
/**
 * Fallback generico.
 *
 * @package Capoferrisagl
 */

get_header(); ?>

<section class="cfs-page">
    <div class="cfs-container cfs-prose cfs-prose--page">
        <?php while (have_posts()) : the_post(); ?>
            <article <?php post_class(); ?>>
                <h1><?php the_title(); ?></h1>
                <?php the_content(); ?>
            </article>
        <?php endwhile; ?>
    </div>
</section>

<?php get_footer(); ?>
