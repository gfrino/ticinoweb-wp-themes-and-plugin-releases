<?php
/**
 * Pagina standard (privacy, cookie policy, contenuti testuali).
 *
 * @package Capoferrisagl
 */

get_header();

while (have_posts()) :
    the_post(); ?>

    <header class="cfs-hero cfs-hero--compact">
        <div class="cfs-container cfs-hero__content">
            <?php cfs_the_breadcrumb(array(array('label' => get_the_title()))); ?>
            <h1 class="cfs-hero__title cfs-hero__title--page" data-hero-title><?php echo esc_html(get_the_title()); ?></h1>
        </div>
    </header>

    <section class="cfs-page">
        <div class="cfs-container cfs-prose cfs-prose--page" data-reveal="text">
            <?php the_content(); ?>
        </div>
    </section>

<?php endwhile; ?>

<?php get_footer(); ?>
