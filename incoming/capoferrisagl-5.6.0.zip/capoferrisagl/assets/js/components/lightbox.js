/**
 * Lightbox accessibile.
 *
 * - apertura: l'immagine si espande dalla miniatura con Flip (cambio di
 *   layout reale, non un effetto decorativo);
 * - navigazione: pulsanti, frecce, Escape, click sullo sfondo;
 * - swipe: Observer unifica touch e pointer;
 * - focus trap e ripristino del focus.
 *
 * Senza Flip o Observer la lightbox funziona comunque: cambia solo la
 * transizione di apertura e lo swipe.
 */

import { gsap, Flip, Observer, ease, reduceMotion } from '../gsap/gsap-config.js';

export function initLightbox() {
    const lightbox = document.querySelector('[data-lightbox]');
    const galleries = document.querySelectorAll('[data-lightbox-gallery]');
    if (!lightbox || !galleries.length) {
        return;
    }

    const image = lightbox.querySelector('[data-image]');
    const caption = lightbox.querySelector('[data-caption]');
    const btnClose = lightbox.querySelector('[data-close]');
    const btnPrev = lightbox.querySelector('[data-prev]');
    const btnNext = lightbox.querySelector('[data-next]');

    let items = [];
    let index = 0;
    let lastFocused = null;
    let observer = null;

    const render = () => {
        const item = items[index];
        if (!item) {
            return;
        }
        image.src = item.dataset.full;
        image.alt = item.dataset.alt || '';
        caption.textContent = item.dataset.caption || '';
        caption.hidden = !item.dataset.caption;

        const many = items.length > 1;
        btnPrev.hidden = !many;
        btnNext.hidden = !many;
    };

    const show = (delta) => {
        index = (index + delta + items.length) % items.length;
        render();
        if (!reduceMotion) {
            gsap.fromTo(image,
                { autoAlpha: 0, x: delta > 0 ? 40 : -40 },
                { autoAlpha: 1, x: 0, duration: 0.45, ease: ease() });
        }
    };

    const onKeydown = (event) => {
        switch (event.key) {
            case 'Escape':
                event.preventDefault();
                close();
                break;
            case 'ArrowLeft':
                event.preventDefault();
                show(-1);
                break;
            case 'ArrowRight':
                event.preventDefault();
                show(1);
                break;
            case 'Tab': {
                const focusables = [btnClose, btnPrev, btnNext].filter((el) => el && !el.hidden);
                if (!focusables.length) {
                    return;
                }
                const first = focusables[0];
                const last = focusables[focusables.length - 1];
                if (event.shiftKey && document.activeElement === first) {
                    event.preventDefault();
                    last.focus();
                } else if (!event.shiftKey && document.activeElement === last) {
                    event.preventDefault();
                    first.focus();
                }
                break;
            }
            default:
                break;
        }
    };

    /** Espansione dalla miniatura: cambio di layout reale gestito da Flip. */
    const animateOpen = (thumb) => {
        if (reduceMotion || !Flip || !thumb) {
            return;
        }
        try {
            Flip.fit(image, thumb, { scale: true, absolute: true });
            const state = Flip.getState(image);
            gsap.set(image, { clearProps: 'transform,width,height,top,left,position' });
            Flip.from(state, { duration: 0.55, ease: ease(), absolute: true });
        } catch (error) {
            console.warn('[Capoferri] Flip non disponibile per la lightbox:', error);
        }
    };

    function open(gallery, startIndex, thumb) {
        items = Array.from(gallery.querySelectorAll('[data-lightbox-item]'));
        index = startIndex;
        lastFocused = document.activeElement;

        lightbox.hidden = false;
        void lightbox.offsetWidth;
        lightbox.classList.add('is-open');
        document.body.classList.add('is-locked');
        document.addEventListener('keydown', onKeydown);

        render();

        const start = () => animateOpen(thumb);
        if (image.complete) {
            start();
        } else {
            image.addEventListener('load', start, { once: true });
        }

        btnClose.focus();

        // Swipe unificato touch/pointer.
        if (Observer && !observer) {
            observer = Observer.create({
                target: lightbox,
                type: 'touch,pointer',
                tolerance: 60,
                dragMinimum: 30,
                onLeft: () => show(1),
                onRight: () => show(-1),
                preventDefault: false,
            });
        } else if (observer) {
            observer.enable();
        }
    }

    function close() {
        lightbox.classList.remove('is-open');
        document.body.classList.remove('is-locked');
        document.removeEventListener('keydown', onKeydown);

        if (observer) {
            observer.disable();
        }

        window.setTimeout(() => {
            lightbox.hidden = true;
            image.removeAttribute('src');
        }, 320);

        if (lastFocused) {
            lastFocused.focus();
        }
    }

    galleries.forEach((gallery) => {
        gallery.addEventListener('click', (event) => {
            const trigger = event.target.closest('[data-lightbox-item]');
            if (!trigger) {
                return;
            }
            const all = Array.from(gallery.querySelectorAll('[data-lightbox-item]'));
            open(gallery, all.indexOf(trigger), trigger.querySelector('img'));
        });
    });

    btnClose.addEventListener('click', close);
    btnPrev.addEventListener('click', () => show(-1));
    btnNext.addEventListener('click', () => show(1));

    lightbox.addEventListener('click', (event) => {
        if (event.target === lightbox) {
            close();
        }
    });
}
