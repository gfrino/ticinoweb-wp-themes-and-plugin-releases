/**
 * Menu mobile fullscreen.
 *
 * L'animazione è una timeline GSAP (pannello, logo, link, contatti, CTA) ma
 * il menu resta pienamente funzionante anche senza: apertura, chiusura,
 * Escape, focus trap e blocco dello scroll non dipendono dall'animazione.
 */

import { gsap, ease, reduceMotion } from '../gsap/gsap-config.js';

const FOCUSABLE = 'a[href], button:not([disabled]), input, select, textarea, [tabindex]:not([tabindex="-1"])';

export function initMobileMenu() {
    const toggle = document.querySelector('[data-menu-toggle]');
    const menu = document.querySelector('[data-mobile-menu]');
    if (!toggle || !menu) {
        return;
    }

    const links = menu.querySelectorAll('.cfs-mobile-menu__list a');
    const foot = menu.querySelector('.cfs-mobile-menu__foot');
    let isOpen = false;
    let timeline = null;

    const buildTimeline = () => {
        if (reduceMotion || !gsap) {
            return null;
        }
        const tl = gsap.timeline({ paused: true, defaults: { ease: ease() } });

        tl.fromTo(menu,
            { clipPath: 'inset(0 0 100% 0)' },
            { clipPath: 'inset(0 0 0% 0)', duration: 0.6 }, 0);

        if (links.length) {
            tl.fromTo(links,
                { autoAlpha: 0, y: 26 },
                { autoAlpha: 1, y: 0, duration: 0.5, stagger: 0.07 }, 0.25);
        }
        if (foot) {
            tl.fromTo(foot,
                { autoAlpha: 0, y: 18 },
                { autoAlpha: 1, y: 0, duration: 0.45 }, 0.45);
        }
        return tl;
    };

    const focusable = () => Array.from(menu.querySelectorAll(FOCUSABLE))
        .filter((el) => el.offsetParent !== null);

    const onKeydown = (event) => {
        if (event.key === 'Escape') {
            event.preventDefault();
            close();
            return;
        }
        if (event.key !== 'Tab') {
            return;
        }
        const list = focusable();
        if (!list.length) {
            return;
        }
        const first = list[0];
        const last = list[list.length - 1];
        if (event.shiftKey && document.activeElement === first) {
            event.preventDefault();
            last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
            event.preventDefault();
            first.focus();
        }
    };

    function open() {
        isOpen = true;
        menu.hidden = false;
        void menu.offsetWidth;
        menu.classList.add('is-open');
        toggle.setAttribute('aria-expanded', 'true');
        document.body.classList.add('is-locked');
        document.addEventListener('keydown', onKeydown);

        if (!timeline) {
            timeline = buildTimeline();
        }
        if (timeline) {
            timeline.play(0);
        }

        const list = focusable();
        if (list.length) {
            list[0].focus();
        }
    }

    function close() {
        if (!isOpen) {
            return;
        }
        isOpen = false;
        toggle.setAttribute('aria-expanded', 'false');
        document.body.classList.remove('is-locked');
        document.removeEventListener('keydown', onKeydown);
        toggle.focus();

        const hide = () => {
            if (!isOpen) {
                menu.classList.remove('is-open');
                menu.hidden = true;
            }
        };

        if (timeline) {
            timeline.eventCallback('onReverseComplete', hide);
            timeline.reverse();
        } else {
            menu.classList.remove('is-open');
            window.setTimeout(hide, 300);
        }
    }

    // Sottomenu espandibili (Servizi): pulsante di apertura accanto alla voce.
    menu.querySelectorAll('.cfs-mobile-menu__list .menu-item-has-children').forEach((li) => {
        const sub = li.querySelector('.sub-menu');
        const link = li.querySelector(':scope > a');
        if (!sub || !link) {
            return;
        }
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'cfs-submenu-toggle';
        btn.setAttribute('aria-label', 'Mostra i servizi');
        btn.setAttribute('aria-expanded', 'false');
        link.insertAdjacentElement('afterend', btn);
        btn.addEventListener('click', (event) => {
            event.preventDefault();
            event.stopPropagation();
            const opened = li.classList.toggle('is-open');
            btn.setAttribute('aria-expanded', opened ? 'true' : 'false');
        });
    });

    toggle.addEventListener('click', () => (isOpen ? close() : open()));

    menu.addEventListener('click', (event) => {
        if (event.target.closest('a')) {
            close();
        }
    });

    window.addEventListener('resize', () => {
        if (isOpen && window.innerWidth >= 1000) {
            close();
        }
    }, { passive: true });
}
