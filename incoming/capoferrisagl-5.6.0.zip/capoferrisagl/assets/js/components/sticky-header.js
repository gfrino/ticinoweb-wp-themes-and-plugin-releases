/**
 * Header sticky: si compatta allo scroll, resta trasparente sopra gli hero
 * scuri e mostra l'avanzamento di lettura.
 */

export function initStickyHeader() {
    const header = document.querySelector('[data-header]');
    if (!header) {
        return;
    }

    const progress = header.querySelector('[data-scroll-progress]');
    const darkHero = document.querySelector('.cfs-hero:not(.cfs-hero--compact)');
    let ticking = false;

    const update = () => {
        const y = window.scrollY;

        header.classList.toggle('is-scrolled', y > 12);

        if (darkHero) {
            const limit = darkHero.offsetHeight - header.offsetHeight - 40;
            header.classList.toggle('is-transparent', y < limit);
        }

        if (progress) {
            const max = document.documentElement.scrollHeight - window.innerHeight;
            progress.style.width = max > 0 ? `${Math.min(100, (y / max) * 100)}%` : '0';
        }

        ticking = false;
    };

    const onScroll = () => {
        if (!ticking) {
            ticking = true;
            window.requestAnimationFrame(update);
        }
    };

    update();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll, { passive: true });
}
