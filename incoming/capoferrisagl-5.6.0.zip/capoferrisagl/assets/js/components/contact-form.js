/**
 * Modulo contatti: validazione frontend, stati di invio e feedback
 * accessibili. La validazione autorevole resta lato server.
 */

let recaptchaLoader = null;

/** Carica lo script reCAPTCHA v3 (chiave dal CMS) alla prima interazione e ne restituisce il token. */
function getRecaptchaToken(siteKey) {
    if (!siteKey) {
        return Promise.resolve('');
    }
    if (!recaptchaLoader) {
        recaptchaLoader = new Promise((resolve) => {
            const script = document.createElement('script');
            script.src = `https://www.google.com/recaptcha/api.js?render=${encodeURIComponent(siteKey)}`;
            script.async = true;
            script.onload = () => window.grecaptcha.ready(resolve);
            script.onerror = () => resolve();
            document.head.appendChild(script);
        });
    }
    return recaptchaLoader.then(() => (window.grecaptcha
        ? window.grecaptcha.execute(siteKey, { action: 'contact' })
        : ''));
}

export function initContactForm() {
    const form = document.querySelector('[data-cfs-contact]');
    if (!form || typeof window.cfsData === 'undefined') {
        return;
    }

    // Lo script di Google si carica solo quando l'utente tocca il modulo.
    form.addEventListener('focusin', () => getRecaptchaToken(window.cfsData.recaptchaSiteKey), { once: true });

    const submit = form.querySelector('[data-submit]');
    const feedback = form.querySelector('[data-feedback]');

    const setError = (name, message) => {
        const field = form.querySelector(`[name="${name}"]`);
        const box = form.querySelector(`#cfs-${name}-error`);
        if (field) {
            field.classList.toggle('is-invalid', Boolean(message));
            field.setAttribute('aria-invalid', message ? 'true' : 'false');
        }
        if (box) {
            box.textContent = message || '';
        }
        return !message;
    };

    const value = (name) => (form.querySelector(`[name="${name}"]`)?.value || '').trim();

    const validate = () => {
        let valid = true;

        valid = setError('name', value('name').length < 2 ? 'Inserisci il tuo nome e cognome.' : '') && valid;
        valid = setError('email', /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value('email')) ? '' : 'Inserisci un indirizzo email valido.') && valid;
        valid = setError('message', value('message').length < 10 ? 'Scrivi un messaggio di almeno 10 caratteri.' : '') && valid;
        valid = setError('privacy', form.querySelector('[name="privacy"]')?.checked ? '' : 'Devi accettare l\'informativa sulla privacy.') && valid;

        return valid;
    };

    form.querySelectorAll('input, textarea, select').forEach((field) => {
        field.addEventListener('blur', () => {
            if (field.classList.contains('is-invalid')) {
                validate();
            }
        });
    });

    form.addEventListener('submit', async (event) => {
        event.preventDefault();

        feedback.textContent = '';
        feedback.className = 'cfs-form__feedback';

        if (!validate()) {
            const invalid = form.querySelector('.is-invalid');
            if (invalid) {
                invalid.focus();
            }
            return;
        }

        submit.disabled = true;
        submit.textContent = submit.dataset.sending;

        // Invio al gestore del parent (ticinoWEB CMS): token fresco, reCAPTCHA v3 e invio.
        const { ajaxUrl, submitAction, tokenAction, recaptchaSiteKey } = window.cfsData;
        const fieldMap = { nome: 'name', telefono: 'phone', oggetto: 'service', messaggio: 'message' };

        try {
            const tokenResponse = await fetch(`${ajaxUrl}?action=${tokenAction}`, { credentials: 'same-origin' });
            const token = (await tokenResponse.json())?.data?.token || '';
            const recaptchaToken = await getRecaptchaToken(recaptchaSiteKey);

            const data = new FormData(form);
            data.append('action', submitAction);
            data.append('token', token);
            data.set('nome', value('name'));
            data.set('telefono', value('phone'));
            data.set('oggetto', value('service'));
            data.set('messaggio', value('message'));
            if (recaptchaToken) {
                data.append('recaptcha_token', recaptchaToken);
            }

            const response = await fetch(ajaxUrl, {
                method: 'POST',
                credentials: 'same-origin',
                body: data,
            });
            const result = await response.json();

            if (result.success) {
                feedback.textContent = result.data.message;
                feedback.classList.add('is-success');
                form.reset();
            } else {
                feedback.textContent = result.data?.message || 'Si è verificato un errore. Riprova.';
                feedback.classList.add('is-error');
                Object.entries(result.data?.fields || {}).forEach(([name, message]) => {
                    setError(fieldMap[name] || name, message);
                });
            }
        } catch (error) {
            feedback.textContent = 'Non è stato possibile inviare la richiesta. Riprova o chiamaci.';
            feedback.classList.add('is-error');
        } finally {
            submit.disabled = false;
            submit.textContent = submit.dataset.label;
        }
    });
}
