/**
 * Link interni: scorrimento animato che rispetta ancore, tastiera e cronologia.
 *
 * Se ScrollSmoother è attivo si usa il suo scrollTo (mantiene lo smoothing),
 * altrimenti ScrollToPlugin. Senza nessuno dei due il browser fa il suo salto
 * nativo: il link continua a funzionare.
 */

import { gsap, ScrollToPlugin, reduceMotion, ease } from '../gsap/gsap-config.js';
import { getSmoother } from '../animations/smooth-scroll.js';

const HEADER_OFFSET = 90;

export function initScrollLinks() {
    const links = document.querySelectorAll('a[href*="#"]:not([href="#"]):not([data-lightbox-item])');
    if (!links.length) {
        return;
    }

    links.forEach((link) => {
        // Solo ancore della stessa pagina.
        if (link.pathname !== window.location.pathname || link.host !== window.location.host) {
            return;
        }

        link.addEventListener('click', (event) => {
            const id = link.getAttribute('href').split('#')[1];
            if (!id) {
                return;
            }
            const target = document.getElementById(id);
            if (!target) {
                return;
            }

            event.preventDefault();

            const smoother = getSmoother();
            if (reduceMotion) {
                target.scrollIntoView();
            } else if (smoother) {
                smoother.scrollTo(target, true, `top ${HEADER_OFFSET}px`);
            } else if (ScrollToPlugin) {
                gsap.to(window, {
                    duration: 0.9,
                    scrollTo: { y: target, offsetY: HEADER_OFFSET },
                    ease: ease(),
                });
            } else {
                target.scrollIntoView({ behavior: 'smooth' });
            }

            // L'URL resta condivisibile e il focus si sposta davvero:
            // senza questo la navigazione da tastiera resterebbe indietro.
            history.pushState(null, '', `#${id}`);
            target.setAttribute('tabindex', '-1');
            target.focus({ preventScroll: true });
        });
    });
}
