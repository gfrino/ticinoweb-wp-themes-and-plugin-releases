/**
 * Configurazione GSAP centralizzata.
 *
 * Il progetto non usa bundler: i plugin ufficiali sono caricati come file UMD
 * locali (assets/vendor/gsap/) ed espongono i propri global. Questo modulo fa
 * ciò che in un progetto con build tool farebbero gli import: raccoglie i
 * plugin, li registra una volta sola, definisce le ease condivise e le utility.
 *
 * Nessun plugin è obbligatorio: se un file non è stato caricato per quella
 * pagina, il modulo che lo usa si limita a non fare nulla.
 */

const g = window;

export const gsap = g.gsap || null;
export const ScrollTrigger = g.ScrollTrigger || null;
export const ScrollSmoother = g.ScrollSmoother || null;
export const SplitText = g.SplitText || null;
export const DrawSVGPlugin = g.DrawSVGPlugin || null;
export const MotionPathPlugin = g.MotionPathPlugin || null;
export const ScrollToPlugin = g.ScrollToPlugin || null;
export const CustomEase = g.CustomEase || null;
export const Flip = g.Flip || null;
export const Observer = g.Observer || null;

/** GSAP core è l'unica dipendenza davvero indispensabile. */
export const hasGsap = Boolean(gsap);

/** Preferenza di sistema per il movimento ridotto. */
const motionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
export const reduceMotion = motionQuery.matches;

/** Linguaggio di movimento del sito: una curva principale, una più morbida. */
export const EASE = 'power3.out';
export const EASE_SOFT = 'power2.inOut';

let registered = false;

/**
 * Registra i plugin disponibili. Sicura da chiamare più volte.
 *
 * @returns {boolean} true se GSAP è utilizzabile.
 */
export function setupGsap() {
    if (!hasGsap) {
        return false;
    }
    if (registered) {
        return true;
    }

    const plugins = [
        ScrollTrigger, ScrollSmoother, SplitText, DrawSVGPlugin,
        MotionPathPlugin, ScrollToPlugin, CustomEase, Flip, Observer,
    ].filter(Boolean);

    gsap.registerPlugin(...plugins);

    if (ScrollTrigger) {
        ScrollTrigger.config({ ignoreMobileResize: true });
    }

    if (CustomEase) {
        // Curva principale: partenza decisa, arrivo lungo e controllato.
        CustomEase.create('capoferri', 'M0,0 C0.16,1 0.3,1 1,1');
        // Curva morbida per i movimenti legati allo scroll.
        CustomEase.create('capoferriSoft', 'M0,0 C0.4,0 0.2,1 1,1');
        gsap.defaults({ ease: 'capoferri' });
    } else {
        gsap.defaults({ ease: EASE });
    }

    registered = true;
    return true;
}

/** Ease principale, con fallback se CustomEase non è caricato. */
export const ease = () => (CustomEase ? 'capoferri' : EASE);
export const easeSoft = () => (CustomEase ? 'capoferriSoft' : EASE_SOFT);

/**
 * matchMedia condiviso: un'unica istanza per tutto il sito, così i cleanup
 * al cambio di breakpoint avvengono in modo coerente.
 */
export const mm = hasGsap ? gsap.matchMedia() : null;

export const MQ_DESKTOP = '(min-width: 1024px)';
export const MQ_MOBILE = '(max-width: 1023px)';
export const MQ_MOTION = '(prefers-reduced-motion: no-preference)';

/**
 * Rende visibile tutto ciò che attende un'animazione.
 * Usata come rete di sicurezza in caso di errore o assenza di GSAP.
 */
export function revealAll() {
    document.documentElement.classList.add('cfs-motion-off');
    document.querySelectorAll('[data-reveal], [data-hero-item], [data-hero-title]').forEach((el) => {
        el.style.opacity = '1';
        el.style.transform = 'none';
        el.style.visibility = 'visible';
    });
    document.querySelectorAll('[data-reveal="image"] img').forEach((el) => {
        el.style.clipPath = 'none';
    });
}

/**
 * Aggiorna ScrollTrigger quando le immagini finiscono di caricare: senza
 * questo i trigger calcolati prima del layout finale risultano sfalsati.
 */
export function refreshOnLoad() {
    if (!ScrollTrigger) {
        return;
    }
    window.addEventListener('load', () => ScrollTrigger.refresh(), { once: true });

    document.querySelectorAll('img[loading="lazy"]').forEach((img) => {
        if (img.complete) {
            return;
        }
        img.addEventListener('load', () => ScrollTrigger.refresh(), { once: true });
    });
}
