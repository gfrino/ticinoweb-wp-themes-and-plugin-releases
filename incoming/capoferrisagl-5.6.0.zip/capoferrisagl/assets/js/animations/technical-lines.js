/**
 * Linee tecniche: tracciati SVG che richiamano le canalizzazioni, disegnati
 * con DrawSVGPlugin, percorsi da un indicatore con MotionPathPlugin.
 *
 * Il tratto avanza legato allo scroll (scrub): il movimento accompagna la
 * lettura invece di partire da solo.
 */

import {
    gsap, ScrollTrigger, DrawSVGPlugin, MotionPathPlugin, mm, MQ_DESKTOP, reduceMotion,
} from '../gsap/gsap-config.js';

export function initTechnicalLines() {
    if (reduceMotion || !ScrollTrigger) {
        return;
    }

    const sections = gsap.utils.toArray('[data-technical-section]');
    if (!sections.length) {
        return;
    }

    sections.forEach((section) => {
        const path = section.querySelector('[data-technical-path]');
        if (!path) {
            return;
        }

        const trigger = {
            trigger: section,
            start: 'top 75%',
            end: 'bottom 65%',
            scrub: 0.5,
        };

        if (DrawSVGPlugin) {
            gsap.from(path, { drawSVG: '0%', ease: 'none', scrollTrigger: trigger });
        } else {
            // Senza il plugin la linea resta semplicemente disegnata.
            gsap.set(path, { autoAlpha: 1 });
        }

        // Indicatore che percorre la linea: dettaglio tecnico, non decorativo.
        const dot = section.querySelector('[data-flow-dot]');
        if (dot && MotionPathPlugin) {
            mm.add(MQ_DESKTOP, () => {
                const tween = gsap.to(dot, {
                    motionPath: {
                        path,
                        align: path,
                        alignOrigin: [0.5, 0.5],
                    },
                    ease: 'none',
                    force3D: true,
                    scrollTrigger: trigger,
                });
                return () => tween.kill();
            });
        } else if (dot) {
            gsap.set(dot, { autoAlpha: 0 });
        }
    });
}
