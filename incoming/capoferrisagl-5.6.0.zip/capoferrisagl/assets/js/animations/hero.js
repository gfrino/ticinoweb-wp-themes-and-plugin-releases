/**
 * Hero: apertura coordinata (immagine, titolo, testi, linea tecnica) e
 * uscita controllata durante lo scroll.
 */

import { gsap, ScrollTrigger, DrawSVGPlugin, ease, easeSoft, mm, MQ_DESKTOP } from '../gsap/gsap-config.js';
import { splitHeroTitle } from './split-text.js';

export function initHero() {
    const hero = document.querySelector('.cfs-hero');
    if (!hero) {
        return;
    }

    const items = hero.querySelectorAll('[data-hero-item]');
    const flow = hero.querySelector('[data-hero-flow]');
    const media = hero.querySelector('.cfs-hero__img, .cfs-hero__video');

    const tl = gsap.timeline({ defaults: { ease: ease() } });

    // L'immagine entra in scala: profondità senza spostare il layout.
    if (media) {
        tl.fromTo(media,
            { scale: 1.1, opacity: 0.85 },
            { scale: 1, opacity: 1, duration: 1.6, ease: easeSoft(), force3D: true }, 0);
    }

    const titleAnimation = splitHeroTitle();
    if (titleAnimation) {
        tl.add(titleAnimation, 0.25);
    }

    if (items.length) {
        tl.to(items, { autoAlpha: 1, y: 0, duration: 0.9, stagger: 0.08, force3D: true }, 0.55);
    }

    if (flow) {
        tl.fromTo(flow,
            { autoAlpha: 0, scaleX: 0, transformOrigin: 'left center' },
            { autoAlpha: 0.6, scaleX: 1, duration: 1.5, ease: easeSoft(), force3D: true }, 0.35);
    }

    // Sottolineatura "a mano" sotto l'ultima riga: si traccia dopo il titolo.
    const underline = hero.querySelector('[data-hero-underline]');
    const underlinePath = underline && underline.querySelector('path');
    if (underlinePath) {
        tl.set(underline, { autoAlpha: 1 }, 1.35);
        if (DrawSVGPlugin) {
            tl.from(underlinePath, { drawSVG: '0%', duration: 0.75, ease: 'power1.inOut' }, 1.35);
        }
    }

    if (!ScrollTrigger) {
        return;
    }

    // Parallasse e uscita: solo su desktop, dove non crea instabilità.
    mm.add(MQ_DESKTOP, () => {
        const content = hero.querySelector('.cfs-hero__content');
        const out = gsap.timeline({
            scrollTrigger: {
                trigger: hero,
                start: 'top top',
                end: 'bottom top',
                scrub: true,
            },
        });

        if (media) {
            out.to(media, { yPercent: 12, ease: 'none', force3D: true }, 0);
        }
        if (content) {
            out.to(content, { yPercent: -10, autoAlpha: 0.3, ease: 'none', force3D: true }, 0);
        }

        return () => out.kill();
    });
}
