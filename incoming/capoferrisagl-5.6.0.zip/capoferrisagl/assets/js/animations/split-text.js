/**
 * Titoli divisi in righe con SplitText ufficiale.
 *
 * Usa `mask: 'lines'` per la maschera e `autoSplit: true` così al resize il
 * testo viene ricalcolato: senza questo, cambiando larghezza le righe restano
 * spezzate dove non serve. SplitText mantiene il testo accessibile nel DOM.
 */

import { gsap, SplitText, ease, mm, MQ_MOTION } from '../gsap/gsap-config.js';

const instances = [];

/**
 * @param {string} selector Elementi da dividere.
 * @param {object} vars     Opzioni dell'animazione.
 */
function splitAndAnimate(selector, vars = {}) {
    const targets = gsap.utils.toArray(selector).filter((el) => el.textContent.trim() !== '');
    if (!targets.length || !SplitText) {
        return;
    }

    targets.forEach((el) => {
        const split = SplitText.create(el, {
            type: 'lines',
            mask: 'lines',
            autoSplit: true,
            linesClass: 'cfs-line',
            onSplit(self) {
                gsap.set(el, { autoAlpha: 1 });
                return gsap.from(self.lines, {
                    yPercent: 110,
                    duration: vars.duration || 1,
                    stagger: vars.stagger || 0.09,
                    ease: ease(),
                    force3D: true,
                    scrollTrigger: vars.scrollTrigger === false ? undefined : {
                        trigger: el,
                        start: 'top 88%',
                        once: true,
                    },
                    delay: vars.delay || 0,
                });
            },
        });
        instances.push(split);
    });
}

/** Titoli di sezione: partono allo scroll. */
export function initSplitHeadings() {
    if (!SplitText) {
        // Senza il plugin i titoli restano semplicemente visibili.
        gsap.set('[data-split="lines"], [data-hero-title]', { autoAlpha: 1 });
        return;
    }

    mm.add(MQ_MOTION, () => {
        splitAndAnimate('[data-split="lines"]');
    });
}

/**
 * Titolo dell'hero: nessuno ScrollTrigger, entra subito nella timeline
 * di apertura della pagina.
 *
 * @returns {gsap.core.Tween|null}
 */
export function splitHeroTitle() {
    const el = document.querySelector('[data-hero-title]');
    if (!el) {
        return null;
    }
    if (!SplitText) {
        gsap.set(el, { autoAlpha: 1 });
        return null;
    }

    let animation = null;

    const split = SplitText.create(el, {
        type: 'lines',
        mask: 'lines',
        autoSplit: true,
        linesClass: 'cfs-line',
        onSplit(self) {
            gsap.set(el, { autoAlpha: 1 });
            animation = gsap.from(self.lines, {
                yPercent: 115,
                duration: 1.15,
                stagger: 0.1,
                ease: ease(),
                force3D: true,
            });
            return animation;
        },
    });

    instances.push(split);
    return animation;
}

/** Libera le istanze (usato solo in caso di re-init). */
export function revertSplits() {
    instances.forEach((split) => split.revert());
    instances.length = 0;
}
