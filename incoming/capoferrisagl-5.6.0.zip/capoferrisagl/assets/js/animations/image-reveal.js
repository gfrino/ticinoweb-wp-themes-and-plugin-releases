/**
 * Reveal delle immagini: maschera clip-path sul contenitore e leggera scala
 * sulla foto.
 *
 * Lo scatto è gestito da IntersectionObserver invece che da ScrollTrigger:
 * è affidabile anche con ScrollSmoother attivo (tiene conto delle trasformazioni)
 * e, se l'immagine è già visibile al caricamento, la rivela subito. Così una
 * foto non resta mai nascosta lasciando un vuoto bianco.
 */

import { gsap, ease, mm, MQ_DESKTOP } from '../gsap/gsap-config.js';

export function initImageReveal() {
    const figures = gsap.utils.toArray('[data-reveal="image"]');
    if (!figures.length) {
        return;
    }

    const revealFigure = (figure) => {
        const image = figure.querySelector('img');
        if (!image || figure.dataset.revealed) {
            return;
        }
        figure.dataset.revealed = '1';
        gsap.to(image, { clipPath: 'inset(0% 0% 0% 0%)', duration: 1.2, ease: ease() });
        gsap.from(image, { scale: 1.08, duration: 1.4, ease: ease(), force3D: true });
    };

    // Stato iniziale mascherato solo dove c'è davvero un'immagine.
    figures.forEach((figure) => {
        const image = figure.querySelector('img');
        if (image) {
            gsap.set(image, { clipPath: 'inset(100% 0% 0% 0%)' });
        }
    });

    if ('IntersectionObserver' in window) {
        const io = new IntersectionObserver((entries) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    revealFigure(entry.target);
                    io.unobserve(entry.target);
                }
            });
        }, { rootMargin: '0px 0px -8% 0px' });

        figures.forEach((figure) => io.observe(figure));
    } else {
        // Senza IntersectionObserver mostriamo tutto subito: mai nascosto.
        figures.forEach(revealFigure);
    }

    // Parallasse molto contenuto: solo poche immagini editoriali, solo desktop.
    mm.add(MQ_DESKTOP, () => {
        const parallax = gsap.utils.toArray(
            '.cfs-intro__media img, .cfs-about-intro__media img, .cfs-service-intro__media img'
        );
        if (!parallax.length) {
            return undefined;
        }

        const tweens = parallax.map((image) => gsap.to(image, {
            yPercent: -7,
            ease: 'none',
            force3D: true,
            scrollTrigger: {
                trigger: image.closest('figure') || image,
                start: 'top bottom',
                end: 'bottom top',
                scrub: true,
            },
        }));

        return () => tweens.forEach((t) => t.kill());
    });
}
