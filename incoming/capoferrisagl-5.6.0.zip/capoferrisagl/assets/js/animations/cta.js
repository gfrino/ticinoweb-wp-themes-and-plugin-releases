/**
 * CTA finale: immagine, linea tecnica, titolo e infine i pulsanti.
 * L'ordine è voluto: il testo è leggibile prima che arrivi l'azione.
 */

import { gsap, ScrollTrigger, DrawSVGPlugin, ease, mm, MQ_DESKTOP, reduceMotion } from '../gsap/gsap-config.js';

export function initCta() {
    const cta = document.querySelector('[data-cta-section]');
    if (!cta || reduceMotion || !ScrollTrigger) {
        return;
    }

    const image = cta.querySelector('.cfs-cta__img');
    const path = cta.querySelector('[data-technical-path]');
    const actions = cta.querySelector('.cfs-cta__actions');
    const text = cta.querySelector('.cfs-cta__text');

    const tl = gsap.timeline({
        defaults: { ease: ease() },
        scrollTrigger: { trigger: cta, start: 'top 75%', once: true },
    });

    if (image) {
        tl.from(image, { scale: 1.1, duration: 1.5, force3D: true }, 0);
    }
    if (path && DrawSVGPlugin) {
        tl.from(path, { drawSVG: '0%', duration: 1.2, ease: 'none' }, 0.2);
    }
    if (text) {
        tl.from(text, { autoAlpha: 0, y: 24, duration: 0.8, force3D: true }, 0.5);
    }
    if (actions) {
        tl.from(actions.children, { autoAlpha: 0, y: 20, duration: 0.6, stagger: 0.08, force3D: true }, 0.7);
    }

    // Parallasse dello sfondo: solo desktop.
    mm.add(MQ_DESKTOP, () => {
        if (!image) {
            return undefined;
        }
        const tween = gsap.to(image, {
            yPercent: 10,
            ease: 'none',
            force3D: true,
            scrollTrigger: { trigger: cta, start: 'top bottom', end: 'bottom top', scrub: true },
        });
        return () => tween.kill();
    });
}
