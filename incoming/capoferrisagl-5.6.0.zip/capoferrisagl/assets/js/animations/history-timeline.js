/**
 * Timeline della pagina Chi siamo: la linea si disegna con lo scroll e le
 * tappe si accendono al passaggio. La linea non supera mai la lettura.
 */

import { gsap, ScrollTrigger, DrawSVGPlugin, ease, reduceMotion } from '../gsap/gsap-config.js';

export function initHistoryTimeline() {
    const list = document.querySelector('[data-history-timeline]');
    if (!list || !ScrollTrigger) {
        return;
    }

    const items = gsap.utils.toArray('[data-history-item]', list);
    const path = list.querySelector('[data-technical-path]');
    const progress = list.querySelector('[data-timeline-progress]');

    if (reduceMotion) {
        items.forEach((item) => item.classList.add('is-active'));
        return;
    }

    const trigger = {
        trigger: list,
        start: 'top 70%',
        end: 'bottom 70%',
        scrub: 0.5,
    };

    if (path && DrawSVGPlugin) {
        gsap.from(path, { drawSVG: '0%', ease: 'none', scrollTrigger: trigger });
    } else if (progress) {
        // Fallback senza SVG: barra che si riempie.
        gsap.fromTo(progress, { height: '0%' }, { height: '100%', ease: 'none', scrollTrigger: trigger });
    }

    // Anno e testo della tappa attiva.
    items.forEach((item) => {
        ScrollTrigger.create({
            trigger: item,
            start: 'top 75%',
            end: 'bottom 60%',
            onEnter: () => item.classList.add('is-active'),
            onEnterBack: () => item.classList.add('is-active'),
        });

        gsap.from(item.querySelector('[data-history-body]') || item, {
            autoAlpha: 0,
            y: 28,
            duration: 0.8,
            ease: ease(),
            force3D: true,
            scrollTrigger: { trigger: item, start: 'top 85%', once: true },
        });
    });
}
