/**
 * Galleria: sola comparsa a gruppi (fade + leggero movimento verticale).
 * Nessun parallax: con il layout masonry muoverebbe le foto a velocità diverse
 * creando disallineamenti. Nessun effetto sugli elementi interattivi.
 */

import { gsap, ScrollTrigger, ease, reduceMotion } from '../gsap/gsap-config.js';

export function initGallery() {
    const gallery = document.querySelector('[data-lightbox-gallery]');
    if (!gallery || reduceMotion) {
        return;
    }

    const items = gsap.utils.toArray('.cfs-grid-gallery__item', gallery);
    if (!items.length) {
        return;
    }

    // Le foto partono già nascoste da CSS (html.js [data-reveal]): niente
    // "visibile → nascosto → dissolvenza", quindi nessun flicker.
    if (!ScrollTrigger) {
        gsap.set(items, { autoAlpha: 1, y: 0 });
        return;
    }

    ScrollTrigger.batch(items, {
        start: 'top 94%',
        once: true,
        onEnter: (batch) => gsap.to(batch, {
            autoAlpha: 1,
            y: 0,
            duration: 0.7,
            stagger: 0.05,
            ease: ease(),
            force3D: true,
            overwrite: true,
        }),
    });
}
