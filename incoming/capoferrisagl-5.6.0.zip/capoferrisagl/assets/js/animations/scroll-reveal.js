/**
 * Comparsa dei blocchi di testo e delle card.
 *
 * Gli elementi vicini vengono raggruppati con ScrollTrigger.batch: un solo
 * trigger per gruppo invece di uno per elemento, molto più leggero su pagine
 * lunghe. Tutti i reveal usano once: true, non si ripetono allo scroll indietro.
 */

import { gsap, ScrollTrigger, ease, reduceMotion } from '../gsap/gsap-config.js';

export function initScrollReveal() {
    if (reduceMotion) {
        return;
    }

    const targets = gsap.utils.toArray('[data-reveal="text"], [data-reveal="card"]');
    if (!targets.length) {
        return;
    }

    if (!ScrollTrigger) {
        gsap.set(targets, { autoAlpha: 1, y: 0 });
        return;
    }

    ScrollTrigger.batch(targets, {
        start: 'top 88%',
        once: true,
        onEnter: (batch) => gsap.to(batch, {
            autoAlpha: 1,
            y: 0,
            duration: 0.8,
            stagger: 0.06,
            ease: ease(),
            force3D: true,
        }),
    });
}
