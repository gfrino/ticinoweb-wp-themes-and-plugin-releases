/**
 * Servizi: ingresso ordinato delle card e showcase con immagine sticky
 * sincronizzata alla voce attiva.
 */

import { gsap, ScrollTrigger, ease, mm, MQ_DESKTOP } from '../gsap/gsap-config.js';
import { getSmoother } from './smooth-scroll.js';

/** Card dei servizi: stagger unico sulla griglia, non un trigger per card. */
function initServiceCards() {
    const grid = document.querySelector('[data-services-grid]');
    const cards = gsap.utils.toArray('[data-service-card]');
    if (!grid || !cards.length) {
        return;
    }

    gsap.to(cards, {
        autoAlpha: 1,
        y: 0,
        duration: 0.8,
        stagger: 0.1,
        ease: ease(),
        force3D: true,
        scrollTrigger: { trigger: grid, start: 'top 78%', once: true },
    });
}

/** Showcase: l'immagine sticky segue hover, focus e scroll. */
function initShowcase() {
    const showcase = document.querySelector('[data-showcase]');
    if (!showcase) {
        return;
    }

    const items = Array.from(showcase.querySelectorAll('[data-item]'));
    const medias = Array.from(showcase.querySelectorAll('[data-media]'));
    if (!items.length || !medias.length) {
        return;
    }

    let current = 0;
    items[0].classList.add('is-active');

    const activate = (index) => {
        if (index === current || !medias[index]) {
            return;
        }
        if (medias[current]) {
            medias[current].classList.remove('is-active');
        }
        if (items[current]) {
            items[current].classList.remove('is-active');
        }
        medias[index].classList.add('is-active');
        items[index].classList.add('is-active');
        current = index;
    };

    items.forEach((item, index) => {
        item.addEventListener('mouseenter', () => activate(index));
        const link = item.querySelector('a');
        if (link) {
            link.addEventListener('focus', () => activate(index));
        }
    });

    if (!ScrollTrigger) {
        return;
    }

    // La sincronizzazione con lo scroll ha senso solo dove il visual è sticky.
    mm.add(MQ_DESKTOP, () => {
        const triggers = items.map((item, index) => ScrollTrigger.create({
            trigger: item,
            start: 'top 60%',
            end: 'bottom 60%',
            onEnter: () => activate(index),
            onEnterBack: () => activate(index),
        }));

        // position:sticky non funziona sotto ScrollSmoother (il contenuto è
        // spostato con una transform): quando lo smoother è attivo fissiamo
        // l'immagine con un pin, così accompagna la lista fino all'ultimo servizio.
        let pin = null;
        const stack = showcase.querySelector('.cfs-showcase__stack');
        const visual = showcase.querySelector('.cfs-showcase__visual');
        const topOffset = 100;

        if (stack && visual && getSmoother()) {
            gsap.set(stack, { position: 'relative', top: 'auto' });
            pin = ScrollTrigger.create({
                trigger: visual,
                start: `top top+=${topOffset}`,
                end: () => `+=${Math.max(1, visual.offsetHeight - stack.offsetHeight - topOffset + 82)}`,
                pin: stack,
                pinSpacing: false,
                invalidateOnRefresh: true,
            });
        }

        return () => {
            triggers.forEach((t) => t.kill());
            if (pin) {
                pin.kill();
            }
            if (stack) {
                gsap.set(stack, { clearProps: 'position,top' });
            }
        };
    });
}

export function initServices() {
    initServiceCards();
    initShowcase();
}
