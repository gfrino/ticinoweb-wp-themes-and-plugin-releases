/**
 * Metodo di lavoro.
 *
 * Desktop: i passaggi sono in riga orizzontale; si accendono in ordine
 * (01→02→03→04) man mano che la sezione scorre, e la linea in alto si riempie
 * da sinistra come un avanzamento. Nessun pin.
 * Mobile: timeline verticale, i passaggi compaiono in sequenza.
 */

import { gsap, ScrollTrigger, ease, mm, MQ_DESKTOP, MQ_MOBILE } from '../gsap/gsap-config.js';

export function initWorkProcess() {
    const section = document.querySelector('[data-work-process]');
    if (!section) {
        return;
    }

    const steps = gsap.utils.toArray('[data-process-step]', section);
    if (!steps.length || !ScrollTrigger) {
        return;
    }

    mm.add(MQ_DESKTOP, () => {
        // Avanzamento cumulativo legato al progresso di scroll della sezione:
        // gli step orizzontali sono alla stessa altezza, quindi non ha senso
        // un trigger per step — si accendono progressivamente in ordine.
        const setProgress = (p) => {
            const activeCount = Math.round(p * steps.length);
            steps.forEach((step, i) => step.classList.toggle('is-active', i < activeCount));
        };

        const st = ScrollTrigger.create({
            trigger: section,
            start: 'top 72%',
            end: 'bottom 65%',
            onUpdate: (self) => setProgress(self.progress),
        });

        setProgress(0);

        return () => {
            st.kill();
            steps.forEach((step) => step.classList.remove('is-active'));
        };
    });

    // Su mobile i passaggi compaiono e restano tutti leggibili.
    mm.add(MQ_MOBILE, () => {
        const tween = gsap.to(steps, {
            autoAlpha: 1,
            y: 0,
            duration: 0.7,
            stagger: 0.08,
            ease: ease(),
            force3D: true,
            scrollTrigger: { trigger: section, start: 'top 80%', once: true },
        });
        return () => tween.kill();
    });
}
