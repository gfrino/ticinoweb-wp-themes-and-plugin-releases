/**
 * Striscia scorrevole dei servizi: scorrimento continuo che accelera e
 * cambia direzione seguendo lo scroll della pagina.
 */

import { gsap, ScrollTrigger, reduceMotion } from '../gsap/gsap-config.js';

export function initMarquee() {
    const track = document.querySelector('[data-marquee]');
    if (!track || reduceMotion) {
        return;
    }

    const group = track.querySelector('.cfs-marquee__group');
    if (!group) {
        return;
    }

    const distance = group.offsetWidth;
    if (!distance) {
        return;
    }

    const tween = gsap.to(track, {
        x: -distance,
        duration: distance / 60, // velocità costante a prescindere dalla lunghezza
        ease: 'none',
        repeat: -1,
        force3D: true,
    });

    if (!ScrollTrigger) {
        return;
    }

    let targetTimeScale = 1;

    ScrollTrigger.create({
        trigger: track,
        start: 'top bottom',
        end: 'bottom top',
        onUpdate: (self) => {
            const vel = self.getVelocity();
            if (Math.abs(vel) > 30) {
                const boost = 1 + Math.min(Math.abs(vel) / 2000, 2);
                targetTimeScale = (self.direction || 1) * boost;
            } else {
                targetTimeScale = 1;
            }
        },
    });

    gsap.ticker.add(() => {
        if (!tween) return;
        const current = tween.timeScale();
        const diff = targetTimeScale - current;
        if (Math.abs(diff) > 0.005) {
            tween.timeScale(current + diff * 0.12);
        }
    });
}
