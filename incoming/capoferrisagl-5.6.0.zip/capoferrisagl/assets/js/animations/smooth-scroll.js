/**
 * Smooth scroll con ScrollSmoother.
 *
 * Attivo solo su desktop con puntatore fine: su touch resta lo scroll nativo
 * (smoothTouch: 0), come raccomandato per non appesantire i dispositivi mobili.
 * Con movimento ridotto non viene inizializzato affatto.
 */

import { ScrollSmoother, reduceMotion } from '../gsap/gsap-config.js';

let smoother = null;

export function initSmoothScroll() {
    if (reduceMotion || !ScrollSmoother) {
        return null;
    }

    const wrapper = document.querySelector('#smooth-wrapper');
    const content = document.querySelector('#smooth-content');
    if (!wrapper || !content) {
        return null;
    }

    // Solo puntatore fine e schermi larghi.
    if (!window.matchMedia('(min-width: 1024px) and (pointer: fine)').matches) {
        return null;
    }

    smoother = ScrollSmoother.create({
        wrapper,
        content,
        smooth: 0.6,
        effects: true,        // abilita data-speed / data-lag
        smoothTouch: 0,       // nessuno smoothing su touch
        normalizeScroll: false, // evita conflitti con la barra del browser mobile
        ignoreMobileResize: true,
    });

    return smoother;
}

export function getSmoother() {
    return smoother;
}
