/* global jQuery, wp, cfsAdmin */
/**
 * Backend Capoferri: tab, repeater ordinabili, selezione media,
 * campi condizionali, contatori e riordino dei servizi.
 */
(function ($) {
    'use strict';

    /* ── Tab ─────────────────────────────────── */

    function initTabs(context) {
        $(context).find('[data-cfs-tabs]').each(function () {
            var $nav = $(this);
            var $scope = $nav.closest('form, .cfs-admin');

            $nav.on('click', '.cfs-tabs__btn', function () {
                var tab = $(this).data('tab');

                $nav.find('.cfs-tabs__btn')
                    .removeClass('is-active')
                    .attr('aria-selected', 'false');
                $(this).addClass('is-active').attr('aria-selected', 'true');

                $scope.find('.cfs-panel').removeClass('is-active');
                $scope.find('.cfs-panel[data-panel="' + tab + '"]').addClass('is-active');

                $scope.find('input[name="cfs_current_tab"]').val(tab);
            });
        });
    }

    /* ── Campi condizionali ──────────────────── */

    function applyConditions(scope) {
        $(scope).find('[data-show-if]').each(function () {
            var $field = $(this);
            var rules = $field.data('show-if');
            var $row = $field.closest('.cfs-row__body, .cfs-panel');
            var visible = true;

            Object.keys(rules).forEach(function (key) {
                var $control = $row.find('[name$="[' + key + ']"]').first();
                if (!$control.length) {
                    return;
                }
                var allowed = [].concat(rules[key]);
                if (allowed.indexOf($control.val()) === -1) {
                    visible = false;
                }
            });

            $field.toggle(visible);
        });
    }

    /* ── Selezione immagini ──────────────────── */

    function initImageFields(context) {
        $(context).find('[data-cfs-image]').each(function () {
            var $wrap = $(this);
            if ($wrap.data('cfs-ready')) {
                return;
            }
            $wrap.data('cfs-ready', true);

            var $input = $wrap.find('[data-input]');
            var $preview = $wrap.find('[data-preview]');
            var frame;

            $wrap.on('click', '[data-select]', function (event) {
                event.preventDefault();

                if (!frame) {
                    frame = wp.media({
                        title: cfsAdmin.chooseImage,
                        button: { text: cfsAdmin.useImage },
                        library: { type: 'image' },
                        multiple: false
                    });

                    frame.on('select', function () {
                        var attachment = frame.state().get('selection').first().toJSON();
                        var url = (attachment.sizes && attachment.sizes.medium)
                            ? attachment.sizes.medium.url
                            : attachment.url;

                        $input.val(attachment.id).trigger('change');
                        $preview.removeClass('is-empty').html($('<img>').attr('src', url));
                        $wrap.find('[data-remove]').prop('hidden', false);
                    });
                }

                frame.open();
            });

            $wrap.on('click', '[data-remove]', function (event) {
                event.preventDefault();
                $input.val('').trigger('change');
                $preview.addClass('is-empty').html(
                    $('<span class="cfs-image__empty"></span>').text('Nessuna immagine selezionata')
                );
                $(this).prop('hidden', true);
            });
        });
    }

    /* ── Video ───────────────────────────────── */

    function videoTag(url) {
        return $('<video muted playsinline></video>')
            .attr('src', url)
            .css({ maxHeight: '200px', width: 'auto' });
    }

    function initVideoFields(context) {
        $(context).find('[data-cfs-video]').each(function () {
            var $wrap = $(this);
            if ($wrap.data('cfs-ready')) {
                return;
            }
            $wrap.data('cfs-ready', true);

            var $input = $wrap.find('[data-input]');
            var $preview = $wrap.find('[data-preview]');
            var frame;

            $wrap.on('click', '[data-select]', function (event) {
                event.preventDefault();
                if (!frame) {
                    frame = wp.media({
                        title: 'Seleziona un video',
                        library: { type: 'video' },
                        multiple: false
                    });
                    frame.on('select', function () {
                        var attachment = frame.state().get('selection').first().toJSON();
                        $input.val(attachment.url);
                        $preview.removeClass('is-empty').html(videoTag(attachment.url));
                        $wrap.find('[data-remove]').prop('hidden', false);
                    });
                }
                frame.open();
            });

            $wrap.on('click', '[data-remove]', function (event) {
                event.preventDefault();
                $input.val('');
                $preview.addClass('is-empty').html(
                    $('<span class="cfs-image__empty"></span>').text('Nessun video selezionato')
                );
                $(this).prop('hidden', true);
            });

            // URL incollato a mano: aggiorna l'anteprima.
            $input.on('change', function () {
                var url = $input.val();
                if (url) {
                    $preview.removeClass('is-empty').html(videoTag(url));
                    $wrap.find('[data-remove]').prop('hidden', false);
                }
            });
        });
    }

    /* ── Gallerie ────────────────────────────── */

    function initGalleryFields(context) {
        $(context).find('[data-cfs-gallery]').each(function () {
            var $wrap = $(this);
            if ($wrap.data('cfs-ready')) {
                return;
            }
            $wrap.data('cfs-ready', true);

            var $input = $wrap.find('[data-input]');
            var $list = $wrap.find('[data-list]');
            var $empty = $wrap.find('[data-empty]');
            var frame;

            function sync() {
                var ids = $list.find('[data-id]').map(function () {
                    return $(this).data('id');
                }).get();

                $input.val(ids.join(',')).trigger('change');
                $empty.prop('hidden', ids.length > 0);
                $list.toggleClass('is-empty', ids.length === 0);
            }

            $list.sortable({ items: '> li', cursor: 'move', update: sync });

            $wrap.on('click', '[data-add]', function (event) {
                event.preventDefault();

                if (!frame) {
                    frame = wp.media({
                        title: cfsAdmin.chooseImages,
                        button: { text: cfsAdmin.useImages },
                        library: { type: 'image' },
                        multiple: 'add'
                    });

                    frame.on('select', function () {
                        frame.state().get('selection').each(function (item) {
                            var attachment = item.toJSON();
                            if ($list.find('[data-id="' + attachment.id + '"]').length) {
                                return;
                            }
                            var url = (attachment.sizes && attachment.sizes.thumbnail)
                                ? attachment.sizes.thumbnail.url
                                : attachment.url;

                            $list.append(
                                '<li class="cfs-gallery__item" data-id="' + attachment.id + '">' +
                                '<img src="' + url + '" alt="">' +
                                '<button type="button" class="cfs-gallery__remove" data-remove aria-label="Rimuovi immagine dalla galleria">&times;</button>' +
                                '</li>'
                            );
                        });
                        sync();
                    });
                }

                frame.open();
            });

            $wrap.on('click', '[data-remove]', function (event) {
                event.preventDefault();
                $(this).closest('[data-id]').remove();
                sync();
            });
        });
    }

    /* ── Punto focale ────────────────────────── */

    function initFocalFields(context) {
        $(context).find('[data-cfs-focal]').each(function () {
            var $wrap = $(this);
            if ($wrap.data('cfs-ready')) {
                return;
            }
            $wrap.data('cfs-ready', true);

            var $input = $wrap.find('[data-input]');

            $wrap.on('input', 'input[type="range"]', function () {
                $(this).siblings('output').text($(this).val() + '%');
                var x = $wrap.find('[data-axis="x"]').val();
                var y = $wrap.find('[data-axis="y"]').val();
                $input.val(x + '|' + y).trigger('change');
            });
        });
    }

    /* ── Repeater ────────────────────────────── */

    function reindexRow($row, name, index) {
        var pattern = new RegExp('^' + name.replace(/[[\]]/g, '\\$&') + '\\[[^\\]]*\\]');
        $row.find('[name]').each(function () {
            var current = $(this).attr('name');
            $(this).attr('name', current.replace(pattern, name + '[' + index + ']'));
        });
    }

    function initRepeaters(context) {
        $(context).find('[data-cfs-repeater]').each(function () {
            var $rep = $(this);
            if ($rep.data('cfs-ready')) {
                return;
            }
            $rep.data('cfs-ready', true);

            var name = $rep.data('name');
            var $rows = $rep.children('[data-rows]');
            var $empty = $rep.children('[data-empty]');

            function refresh() {
                $rows.children('[data-row]').each(function (index) {
                    reindexRow($(this), name, index);
                });
                $empty.prop('hidden', $rows.children('[data-row]').length > 0);
            }

            $rows.sortable({
                items: '> [data-row]',
                handle: '[data-handle]',
                cursor: 'move',
                update: refresh
            });

            $rep.children('.cfs-repeater__actions').on('click', '[data-add]', function (event) {
                event.preventDefault();

                var html = $rep.children('[data-template]').html()
                    .split('__INDEX__').join($rows.children('[data-row]').length);
                var $row = $(html);

                $rows.append($row);
                $row.find('[data-row__body], .cfs-row__body').prop('hidden', false);
                $row.find('[data-toggle]').attr('aria-expanded', 'true');

                initAll($row);
                refresh();
                applyConditions($row);
            });

            $rows.on('click', '[data-toggle]', function (event) {
                event.preventDefault();
                var $row = $(this).closest('[data-row]');
                var $body = $row.children('.cfs-row__body');
                var open = $body.prop('hidden');
                $body.prop('hidden', !open);
                $(this).attr('aria-expanded', open ? 'true' : 'false');
            });

            $rows.on('click', '[data-delete]', function (event) {
                event.preventDefault();
                if (!window.confirm(cfsAdmin.confirmRemove)) {
                    return;
                }
                $(this).closest('[data-row]').remove();
                refresh();
            });

            $rows.on('click', '[data-duplicate]', function (event) {
                event.preventDefault();
                var $row = $(this).closest('[data-row]');
                var $copy = $row.clone();
                $copy.removeData('cfs-ready');
                $copy.find('[data-cfs-image], [data-cfs-gallery], [data-cfs-focal], [data-cfs-repeater]').removeData('cfs-ready');
                $row.after($copy);
                initAll($copy);
                refresh();
                applyConditions($copy);
            });

            // Il titolo della riga segue il campo di riferimento.
            $rows.on('input change', 'input, select', function () {
                var $row = $(this).closest('[data-row]');
                var $title = $row.find('[data-row-title]').first();
                var key = $title.data('title-key');
                if (!key) {
                    return;
                }
                var $source = $row.find('[name$="[' + key + ']"]').first();
                if ($source.length && $source.val()) {
                    $title.text($source.val());
                }
                applyConditions($row);
            });

            $rows.on('change', '[data-enabled]', function () {
                $(this).closest('[data-row]').toggleClass('is-disabled', !$(this).prop('checked'));
            });
        });
    }

    /* ── Contatori caratteri ─────────────────── */

    function initCounters(context) {
        $(context).find('[data-cfs-counter]').each(function () {
            var $field = $(this);
            var max = parseInt($field.data('cfs-counter'), 10);
            var $out = $('.cfs-counter[data-for="' + $field.attr('id') + '"]');

            function update() {
                var length = ($field.val() || '').length;
                $out.text(length + ' / ' + max);
                $out.toggleClass('is-over', length > max);
            }

            $field.on('input', update);
            update();
        });
    }

    /* ── Riordino servizi ────────────────────── */

    function initServiceOrder() {
        var $list = $('[data-cfs-order]');
        if (!$list.length) {
            return;
        }
        var $feedback = $('[data-feedback]');

        $list.sortable({
            items: '> li',
            cursor: 'move',
            update: function () {
                var order = $list.children('li').map(function () {
                    return $(this).data('id');
                }).get();

                $feedback.text('Salvataggio in corso…');

                $.post(window.ajaxurl, {
                    action: 'cfs_reorder_services',
                    nonce: $list.data('nonce'),
                    order: order
                }).done(function (response) {
                    $feedback.text(response.data.message);
                }).fail(function () {
                    $feedback.text('Non è stato possibile salvare l\'ordine. Ricarica la pagina e riprova.');
                    $list.sortable('cancel');
                });
            }
        });
    }

    /* ── Modifiche non salvate ───────────────── */

    function initDirtyGuard() {
        var $form = $('[data-cfs-form]');
        if (!$form.length) {
            return;
        }
        var dirty = false;

        $form.on('input change', 'input, select, textarea', function () {
            if (!dirty) {
                dirty = true;
                $form.find('[data-dirty]').prop('hidden', false);
            }
        });

        $form.on('submit', function () {
            dirty = false;
        });

        window.addEventListener('beforeunload', function (event) {
            if (dirty) {
                event.preventDefault();
                event.returnValue = cfsAdmin.unsaved;
            }
        });
    }

    /* ── Bootstrap ───────────────────────────── */

    function initAll(context) {
        initTabs(context);
        initImageFields(context);
        initVideoFields(context);
        initGalleryFields(context);
        initFocalFields(context);
        initRepeaters(context);
        initCounters(context);
    }

    $(function () {
        initAll(document);
        applyConditions(document);
        initServiceOrder();
        initDirtyGuard();

        $(document).on('change', 'select', function () {
            applyConditions($(this).closest('.cfs-row__body, .cfs-panel'));
        });
    });
}(jQuery));
