/**
 * Capoferri SA — entry point del frontend.
 *
 * Ordine: prima i componenti (funzionano senza GSAP), poi le animazioni.
 * Se GSAP non è disponibile o il movimento è ridotto, i contenuti vengono
 * mostrati subito e il sito resta pienamente utilizzabile.
 */

import { setupGsap, hasGsap, reduceMotion, revealAll, refreshOnLoad, ScrollTrigger } from './gsap/gsap-config.js';

import { initStickyHeader } from './components/sticky-header.js';
import { initMobileMenu } from './components/mobile-menu.js';
import { initLightbox } from './components/lightbox.js';
import { initContactForm } from './components/contact-form.js';
import { initScrollLinks } from './components/scroll-links.js';

import { initSmoothScroll } from './animations/smooth-scroll.js';
import { initHero } from './animations/hero.js';
import { initSplitHeadings } from './animations/split-text.js';
import { initImageReveal } from './animations/image-reveal.js';
import { initScrollReveal } from './animations/scroll-reveal.js';
import { initServices } from './animations/services.js';
import { initTechnicalLines } from './animations/technical-lines.js';
import { initWorkProcess } from './animations/work-process.js';
import { initHistoryTimeline } from './animations/history-timeline.js';
import { initGallery } from './animations/gallery.js';
import { initCta } from './animations/cta.js';
import { initMarquee } from './animations/marquee.js';

/** Ogni modulo fallisce da solo, senza fermare gli altri. */
const run = (name, fn) => {
    try {
        fn();
    } catch (error) {
        console.error(`[Capoferri] modulo "${name}" non inizializzato:`, error);
    }
};

/**
 * Attende che i font siano pronti prima di dividere i titoli con SplitText:
 * misurare le righe col font di fallback e poi caricare Archivo (più largo)
 * è ciò che tagliava le parole. Con un limite di sicurezza: se i font
 * tardano non blocchiamo mai l'apertura della pagina.
 */
const fontsReady = () => {
    if (!document.fonts || !document.fonts.ready) {
        return Promise.resolve();
    }
    const timeout = new Promise((resolve) => window.setTimeout(resolve, 1500));
    return Promise.race([document.fonts.ready, timeout]);
};

const boot = async () => {
    // Componenti: indipendenti da GSAP, attivi subito.
    run('sticky-header', initStickyHeader);
    run('mobile-menu', initMobileMenu);
    run('contact-form', initContactForm);

    if (!setupGsap() || reduceMotion) {
        // Nessuna animazione: contenuti subito visibili, lightbox e link normali.
        revealAll();
        run('lightbox', initLightbox);
        run('scroll-links', initScrollLinks);
        if (!hasGsap) {
            console.warn('[Capoferri] GSAP non disponibile: animazioni disattivate.');
        }
        return;
    }

    // Lo smooth scroll e i componenti non dipendono dal font.
    run('smooth-scroll', initSmoothScroll);
    run('lightbox', initLightbox);
    run('scroll-links', initScrollLinks);

    // I titoli si dividono solo a font pronto: nessuna parola tagliata.
    await fontsReady();

    run('hero', initHero);
    run('split-headings', initSplitHeadings);
    run('image-reveal', initImageReveal);
    run('scroll-reveal', initScrollReveal);
    run('services', initServices);
    run('technical-lines', initTechnicalLines);
    run('work-process', initWorkProcess);
    run('history-timeline', initHistoryTimeline);
    run('gallery', initGallery);
    run('cta', initCta);
    run('marquee', initMarquee);

    // Ricalcolo dopo font e immagini: i trigger partono dalle posizioni giuste.
    if (ScrollTrigger) {
        ScrollTrigger.refresh();
    }
    refreshOnLoad();
    document.documentElement.classList.add('cfs-ready');
};

const start = () => {
    boot().catch((error) => {
        console.error('[Capoferri] errore di inizializzazione:', error);
        revealAll();
    });
};

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
} else {
    start();
}

/* Rete di sicurezza: se qualcosa impedisce l'avvio, dopo 3 secondi i
   contenuti vengono comunque mostrati. Nessun elemento resta a opacity 0. */
window.setTimeout(() => {
    if (!document.documentElement.classList.contains('cfs-ready')
        && !document.documentElement.classList.contains('cfs-motion-off')) {
        console.warn('[Capoferri] avvio non completato: contenuti mostrati senza animazioni.');
        revealAll();
    }
}, 3000);
