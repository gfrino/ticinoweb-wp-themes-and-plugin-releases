<?php
/**
 * Footer del sito.
 *
 * @package Capoferrisagl
 */

$company     = cfs_company();
$logo        = (int) cfs_settings('logo_alt', 0) ?: cfs_site_logo_id();
$services    = cfs_get_services(6);
$legal_links = cfs_rows(cfs_settings('legal_links', array()));
$copyright   = cfs_settings('copyright', '');
$mobile_bar  = cfs_settings('mobile_bar', '1') === '1';
?>
</main>

<footer class="cfs-footer">
    <div class="cfs-container cfs-footer__grid">

        <div class="cfs-footer__brand">
            <?php if ($logo) : ?>
                <?php cfs_the_image($logo, 'large', array('class' => 'cfs-footer__logo', 'alt' => $company['name'])); ?>
            <?php else : ?>
                <p class="cfs-footer__name"><?php echo esc_html($company['name']); ?></p>
            <?php endif; ?>
            <?php if (cfs_settings('footer_text', '')) : ?>
                <div class="cfs-footer__text"><?php cfs_paragraphs(cfs_settings('footer_text', '')); ?></div>
            <?php endif; ?>
        </div>

        <?php if ($services) : ?>
            <nav class="cfs-footer__col" aria-label="<?php esc_attr_e('Servizi', 'capoferrisagl'); ?>">
                <?php if (cfs_settings('footer_services', '')) : ?>
                    <h2 class="cfs-footer__title"><?php echo esc_html(cfs_settings('footer_services', '')); ?></h2>
                <?php endif; ?>
                <ul class="cfs-footer__list">
                    <?php foreach ($services as $service) : ?>
                        <li><a href="<?php echo esc_url(get_permalink($service->ID)); ?>"><?php echo esc_html($service->post_title); ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </nav>
        <?php endif; ?>

        <div class="cfs-footer__col">
            <?php if (cfs_settings('footer_contacts', '')) : ?>
                <h2 class="cfs-footer__title"><?php echo esc_html(cfs_settings('footer_contacts', '')); ?></h2>
            <?php endif; ?>
            <address class="cfs-footer__address">
                <?php if ($company['legal_name']) : ?>
                    <p class="cfs-footer__legal-name"><strong><?php echo esc_html($company['legal_name']); ?></strong></p>
                <?php endif; ?>
                <?php $addrs = cfs_company_addresses(); ?>
                <div class="cfs-footer__addr-item">
                    <span class="cfs-footer__addr-label"><?php echo esc_html($addrs['legal']['label']); ?>:</span>
                    <span><?php echo esc_html($addrs['legal']['formatted']); ?></span>
                </div>
                <div class="cfs-footer__addr-item">
                    <span class="cfs-footer__addr-label"><?php echo esc_html($addrs['operational']['label']); ?>:</span>
                    <span><?php echo esc_html($addrs['operational']['formatted']); ?></span>
                </div>
                <?php if ($company['phone'] && $company['phone_href']) : ?>
                    <p><a href="<?php echo esc_url($company['phone_href']); ?>"><?php echo esc_html($company['phone']); ?></a></p>
                <?php endif; ?>
                <?php if ($company['email']) : ?>
                    <p><a href="mailto:<?php echo esc_attr($company['email']); ?>"><?php echo esc_html($company['email']); ?></a></p>
                <?php endif; ?>
            </address>

            <?php if ($company['facebook'] || $company['linkedin'] || $company['instagram']) : ?>
                <ul class="cfs-footer__social">
                    <?php if ($company['facebook']) : ?>
                        <li><a href="<?php echo esc_url($company['facebook']); ?>" rel="noopener" target="_blank">Facebook</a></li>
                    <?php endif; ?>
                    <?php if ($company['linkedin']) : ?>
                        <li><a href="<?php echo esc_url($company['linkedin']); ?>" rel="noopener" target="_blank">LinkedIn</a></li>
                    <?php endif; ?>
                    <?php if ($company['instagram']) : ?>
                        <li><a href="<?php echo esc_url($company['instagram']); ?>" rel="noopener" target="_blank">Instagram</a></li>
                    <?php endif; ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>

    <div class="cfs-footer__bar">
        <div class="cfs-container cfs-footer__bar-inner">
            <?php if ($copyright) : ?>
                <p><?php echo esc_html(sprintf($copyright, wp_date('Y'))); ?></p>
            <?php endif; ?>
            <ul class="cfs-footer__legal">
                <?php if ($legal_links) : foreach ($legal_links as $link) :
                    if (empty($link['text']) || empty($link['url'])) {
                        continue;
                    } ?>
                    <li><a href="<?php echo esc_url($link['url']); ?>"><?php echo esc_html($link['text']); ?></a></li>
                <?php endforeach; endif; ?>
                <li><a href="<?php echo esc_url(wp_login_url()); ?>"><?php esc_html_e('Area riservata', 'capoferrisagl'); ?></a></li>
                <li><a class="cfs-footer__credit" href="https://ticinoweb.com" target="_blank" rel="noopener">design by ticinoWEB</a></li>
            </ul>
        </div>
    </div>
</footer>

</div><!-- /#smooth-content -->
</div><!-- /#smooth-wrapper -->

<?php if ($mobile_bar && ($company['phone_href'] || $company['email'])) : ?>
    <div class="cfs-mobile-bar" aria-label="<?php esc_attr_e('Contatti rapidi', 'capoferrisagl'); ?>">
        <?php if ($company['phone_href']) : ?>
            <a href="<?php echo esc_url($company['phone_href']); ?>">
                <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 2 .7 2.9a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.2-1.2a2 2 0 0 1 2.1-.5c.9.3 1.9.6 2.9.7a2 2 0 0 1 1.7 2Z"/></svg>
                <span><?php esc_html_e('Chiama ora', 'capoferrisagl'); ?></span>
            </a>
        <?php endif; ?>
        <?php if ($company['email']) : ?>
            <a href="<?php echo esc_url(cfs_page_url('contatti') . '#scrivici'); ?>">
                <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m2 7 10 6 10-6"/></svg>
                <span><?php esc_html_e('Scrivici', 'capoferrisagl'); ?></span>
            </a>
        <?php endif; ?>
    </div>
<?php endif; ?>

<div class="cfs-lightbox" data-lightbox hidden role="dialog" aria-modal="true" aria-label="<?php esc_attr_e('Visualizzatore immagini', 'capoferrisagl'); ?>">
    <button type="button" class="cfs-lightbox__close" data-close aria-label="<?php esc_attr_e('Chiudi', 'capoferrisagl'); ?>">&times;</button>
    <button type="button" class="cfs-lightbox__nav cfs-lightbox__nav--prev" data-prev aria-label="<?php esc_attr_e('Immagine precedente', 'capoferrisagl'); ?>">&#8249;</button>
    <figure class="cfs-lightbox__figure">
        <img src="" alt="" data-image>
        <figcaption data-caption></figcaption>
    </figure>
    <button type="button" class="cfs-lightbox__nav cfs-lightbox__nav--next" data-next aria-label="<?php esc_attr_e('Immagine successiva', 'capoferrisagl'); ?>">&#8250;</button>
</div>

<?php wp_footer(); ?>
</body>
</html>
