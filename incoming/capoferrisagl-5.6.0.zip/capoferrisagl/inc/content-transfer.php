<?php
/**
 * Trasferimento contenuti Capoferri: porta pagine, servizi, opzioni e immagini
 * dal sito locale al sito live, senza toccare il database del multisito.
 *
 * Concetto: si esporta un file JSON leggero dal locale e lo si importa sul live.
 * I contenuti si riconoscono per slug/chiave: quelli esistenti vengono aggiornati,
 * non duplicati. Le immagini viaggiano come "token" per NOME FILE, così gli ID
 * allegato (diversi tra un sito e l'altro) vengono riagganciati correttamente.
 *
 * @package Capoferri_SA
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * Cosa viene trasferito
 * ============================================================ */

/** Pagine editoriali (per slug). */
function cfs_ct_pages() {
	return array(
		'home'           => 'Home',
		'servizi'        => 'Servizi',
		'chi-siamo'      => 'Chi siamo',
		'contatti'       => 'Contatti',
		'privacy-policy' => 'Privacy Policy',
		'cookie-policy'  => 'Cookie Policy',
	);
}

/** Opzioni gestite dal tema (contengono i testi e gli ID immagine). */
function cfs_ct_options() {
	return array( 'cfs_home', 'cfs_about', 'cfs_contact', 'cfs_servizi', 'cfs_settings' );
}

/** Prefissi dei meta del CPT servizio da trasferire. */
function cfs_ct_meta_prefixes() {
	return array( '_cfs_', '_tw_seo_' );
}

/** Meta singoli (senza prefisso) da trasferire per i servizi. */
function cfs_ct_meta_extra() {
	return array( '_thumbnail_id' );
}

/** Meta delle immagini (didascalie / alt / titolo) trasferiti per nome file. */
function cfs_ct_media_meta() {
	return array( '_wp_attachment_image_alt' );
}

/** Prefisso token che rappresenta un'immagine per nome file. */
const CFS_CT_TOKEN = 'cfsmedia:';

/* ============================================================
 * Utility immagini
 * ============================================================ */

/** True se l'ID è un allegato media presente su questo sito. */
function cfs_ct_is_attachment( $id ) {
	$id = (int) $id;
	return $id > 0 && 'attachment' === get_post_type( $id );
}

/** Nome file (basename) di un allegato, o '' se assente. */
function cfs_ct_basename( $id ) {
	$file = get_post_meta( (int) $id, '_wp_attached_file', true );
	return $file ? basename( $file ) : '';
}

/**
 * Converte un valore in forma portabile: gli ID immagine diventano token
 * "cfsmedia:nomefile.jpg". Gestisce singoli ID, liste CSV di ID e array annidati.
 * Raccoglie in $ref_ids tutti gli ID immagine incontrati.
 *
 * @param mixed $value
 * @param int[] $ref_ids  Raccolta (per riferimento) degli ID trovati.
 * @return mixed
 */
function cfs_ct_encode( $value, array &$ref_ids ) {
	if ( is_array( $value ) ) {
		$out = array();
		foreach ( $value as $k => $v ) {
			$out[ $k ] = cfs_ct_encode( $v, $ref_ids );
		}
		return $out;
	}

	if ( ! is_scalar( $value ) ) {
		return $value;
	}

	$str = (string) $value;

	// Singolo ID immagine.
	if ( ctype_digit( $str ) && cfs_ct_is_attachment( $str ) ) {
		$name = cfs_ct_basename( $str );
		if ( '' !== $name ) {
			$ref_ids[] = (int) $str;
			return CFS_CT_TOKEN . $name;
		}
	}

	// Lista CSV di ID (es. gallerie: "71,70,69").
	if ( preg_match( '/^\d+(,\d+)+$/', $str ) ) {
		$ids    = array_map( 'trim', explode( ',', $str ) );
		$tokens = array();
		$all    = true;
		foreach ( $ids as $id ) {
			if ( ! cfs_ct_is_attachment( $id ) ) {
				$all = false;
				break;
			}
			$name = cfs_ct_basename( $id );
			if ( '' === $name ) {
				$all = false;
				break;
			}
			$ref_ids[] = (int) $id;
			$tokens[]  = CFS_CT_TOKEN . $name;
		}
		if ( $all ) {
			return implode( ',', $tokens );
		}
	}

	return $value;
}

/**
 * Riporta un valore portabile ai dati locali: i token "cfsmedia:nomefile"
 * tornano ID locali; gli URL uploads e il dominio di partenza vengono riscritti.
 *
 * @param mixed                 $value
 * @param array<string,string>  $media_map   URL sorgente -> URL locale.
 * @param string                $source_url  Home del sito di partenza.
 * @param string                $target_url  Home di questo sito.
 * @param string[]              $missing     Raccolta (per riferimento) file mancanti.
 * @return mixed
 */
function cfs_ct_decode( $value, array $media_map, $source_url, $target_url, array &$missing ) {
	if ( is_array( $value ) ) {
		$out = array();
		foreach ( $value as $k => $v ) {
			$out[ $k ] = cfs_ct_decode( $v, $media_map, $source_url, $target_url, $missing );
		}
		return $out;
	}

	if ( ! is_string( $value ) ) {
		return $value;
	}

	// Token immagine (singolo o lista CSV).
	if ( false !== strpos( $value, CFS_CT_TOKEN ) ) {
		$parts = explode( ',', $value );
		$ids   = array();
		$ok    = true;
		foreach ( $parts as $part ) {
			$part = trim( $part );
			if ( 0 !== strpos( $part, CFS_CT_TOKEN ) ) {
				$ok = false;
				break;
			}
			$file  = substr( $part, strlen( CFS_CT_TOKEN ) );
			$local = cfs_ct_find_local_asset( $file );
			if ( $local ) {
				$ids[] = (int) $local['id'];
			} else {
				$missing[] = $file;
				$ids[]     = 0;
			}
		}
		if ( $ok ) {
			$ids = array_filter( $ids ); // togli gli 0 (non trovati).
			return implode( ',', $ids );
		}
	}

	// URL immagini uploads -> URL locale (per nome file), poi dominio.
	if ( $media_map ) {
		$value = strtr( $value, $media_map );
	}
	if ( $source_url && $target_url && $source_url !== $target_url ) {
		$value = str_replace( $source_url, $target_url, $value );
	}

	return $value;
}

/** Estrae gli URL della cartella uploads da una stringa. */
function cfs_ct_extract_upload_urls( $content ) {
	$urls = array();
	if ( ! is_string( $content ) || '' === $content ) {
		return $urls;
	}
	preg_match_all(
		'~(?:https?:)?//[^\s"\'()]+/wp-content/uploads/[^\s"\'(),]+|/wp-content/uploads/[^\s"\'(),]+~i',
		$content,
		$m
	);
	foreach ( $m[0] as $u ) {
		$u = html_entity_decode( $u, ENT_QUOTES, 'UTF-8' );
		$u = preg_replace( '/[?#].*$/', '', $u );
		if ( $u ) {
			$urls[] = $u;
		}
	}
	return array_values( array_unique( $urls ) );
}

/** Raccoglie ricorsivamente gli URL uploads da una struttura. */
function cfs_ct_collect_urls( $value, array &$urls ) {
	if ( is_array( $value ) ) {
		foreach ( $value as $v ) {
			cfs_ct_collect_urls( $v, $urls );
		}
	} elseif ( is_string( $value ) ) {
		$urls = array_merge( $urls, cfs_ct_extract_upload_urls( $value ) );
	}
}

/** Dati di un file uploads per l'esportazione (base64). Null se troppo grande/assente. */
function cfs_ct_asset_from_url( $url ) {
	$path = wp_parse_url( $url, PHP_URL_PATH );
	if ( ! is_string( $path ) || false === strpos( $path, '/wp-content/uploads/' ) ) {
		return null;
	}
	$relative = ltrim( substr( $path, strpos( $path, '/wp-content/uploads/' ) + strlen( '/wp-content/uploads/' ) ), '/' );
	$file     = wp_normalize_path( WP_CONTENT_DIR . '/uploads/' . $relative );
	$root     = trailingslashit( wp_normalize_path( WP_CONTENT_DIR . '/uploads' ) );
	$real     = realpath( $file );
	if ( ! $real || 0 !== strpos( wp_normalize_path( $real ), $root ) || ! is_file( $real ) || ! is_readable( $real ) ) {
		return null;
	}
	$size = filesize( $real );
	if ( false === $size || $size > 12 * MB_IN_BYTES ) {
		return null;
	}
	$mime = wp_check_filetype( basename( $real ) );
	return array(
		'source'        => $url,
		'filename'      => basename( $real ),
		'relative_path' => $relative,
		'mime_type'     => $mime['type'] ? $mime['type'] : 'application/octet-stream',
		'sha256'        => hash_file( 'sha256', $real ),
		'data'          => base64_encode( file_get_contents( $real ) ), // phpcs:ignore
	);
}

/** Cerca un allegato locale dal solo nome file. */
function cfs_ct_find_local_asset( $filename ) {
	global $wpdb;
	$filename = sanitize_file_name( (string) $filename );
	if ( '' === $filename ) {
		return null;
	}
	$id = (int) $wpdb->get_var(
		$wpdb->prepare(
			"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_wp_attached_file' AND meta_value LIKE %s ORDER BY post_id DESC LIMIT 1",
			'%' . $wpdb->esc_like( $filename )
		)
	);
	if ( ! $id ) {
		return null;
	}
	$url = wp_get_attachment_url( $id );
	return $url ? array( 'url' => $url, 'id' => $id ) : null;
}

/* ============================================================
 * Menu amministrativo
 * ============================================================ */

function cfs_ct_menu() {
	add_submenu_page(
		defined( 'CFS_MENU' ) ? CFS_MENU : 'capoferri',
		'Porta sul sito',
		'Porta sul sito',
		'manage_options',
		'cfs-content-transfer',
		'cfs_ct_screen'
	);
}
add_action( 'admin_menu', 'cfs_ct_menu', 30 );

function cfs_ct_screen() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Non hai i permessi necessari.', 'capoferrisagl' ) );
	}
	$notice  = isset( $_GET['cfs_ct_notice'] ) ? sanitize_key( wp_unslash( $_GET['cfs_ct_notice'] ) ) : '';
	$count   = isset( $_GET['cfs_ct_count'] ) ? absint( $_GET['cfs_ct_count'] ) : 0;
	$missing = isset( $_GET['cfs_ct_missing'] ) ? absint( $_GET['cfs_ct_missing'] ) : 0;
	$max     = size_format( wp_max_upload_size() );
	?>
	<div class="wrap">
		<h1>Porta i contenuti sul sito</h1>

		<?php if ( 'success' === $notice ) : ?>
			<div class="notice notice-success is-dismissible">
				<p><?php echo esc_html( sprintf( '%d elementi importati o aggiornati.', $count ) ); ?></p>
				<?php if ( $missing ) : ?>
					<p><?php echo esc_html( sprintf( 'Attenzione: %d immagini non sono state trovate nella Libreria media di questo sito.', $missing ) ); ?>
					<strong>Trovi l’elenco qui sotto</strong>: copialo, incollalo nel campo «Immagini da includere» sul sito di partenza e rifai esportazione e importazione.</p>
				<?php endif; ?>
			</div>
		<?php elseif ( 'error' === $notice ) : ?>
			<div class="notice notice-error is-dismissible">
				<p>Non è stato possibile importare il file. Verifica che sia un pacchetto prodotto da questo strumento e che non superi il limite di caricamento (<?php echo esc_html( $max ); ?>).</p>
			</div>
		<?php endif; ?>

		<p>Copia dal sito locale al sito live i contenuti gestiti dal tema, con le immagini. Gli elementi si riconoscono per nome: quelli già presenti vengono <strong>aggiornati</strong>, non duplicati. Non tocca il resto del multisito.</p>
		<p><strong>Incluso:</strong> le pagine (<?php echo esc_html( implode( ', ', array_values( cfs_ct_pages() ) ) ); ?>), tutti i Servizi con i loro campi e immagini, le impostazioni del tema (home, chi siamo, contatti, servizi, generali) e le gallerie media.</p>
		<p><em>Non incluso:</em> i moduli ricevuti dai clienti.</p>

		<div class="card" style="max-width:760px;padding:20px;margin-top:24px;">
			<h2>1. Esporta (sul sito locale)</h2>
			<p>Scarica un file JSON dei contenuti. Le immagini si riagganciano sul live per nome file, quindi di norma <strong>non serve spedire i file</strong>: il pacchetto resta leggero.</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="cfs_ct_export">
				<?php wp_nonce_field( 'cfs_ct_export' ); ?>
				<p>
					<label for="cfs_only_files"><strong>Immagini da includere</strong> (facoltativo, un nome file per riga)</label><br>
					<textarea id="cfs_only_files" name="cfs_only_files" rows="4" style="width:100%;max-width:640px;font-family:monospace;font-size:12px;" placeholder="foto.jpg&#10;copertina.png"></textarea><br>
					<span class="description">Lascia vuoto per non spedire file. Qui va incollato l’elenco che l’importazione segnala come mancante.</span>
				</p>
				<p>
					<label><input type="checkbox" name="cfs_include_files" value="1"> Includi <em>tutti</em> i file delle immagini</label><br>
					<span class="description">Sconsigliato: il pacchetto diventa pesante e può superare il limite (<?php echo esc_html( $max ); ?>). Meglio usare l’elenco qui sopra.</span>
				</p>
				<?php submit_button( 'Scarica i contenuti', 'primary', 'submit', false ); ?>
			</form>
		</div>

		<?php $miss = get_option( 'cfs_ct_missing_files', array() ); ?>
		<?php if ( is_array( $miss ) && $miss ) : ?>
			<div class="card" style="max-width:760px;padding:20px;margin-top:24px;border-left:4px solid #d63638;">
				<h2>Immagini mancanti su questo sito</h2>
				<p>Copia l’elenco, incollalo nel campo «Immagini da includere» sul sito di partenza e rifai l’esportazione.</p>
				<textarea rows="<?php echo esc_attr( min( 12, max( 3, count( $miss ) ) ) ); ?>" style="width:100%;font-family:monospace;font-size:12px;" onclick="this.select();" readonly><?php echo esc_textarea( implode( "\n", $miss ) ); ?></textarea>
			</div>
		<?php endif; ?>

		<div class="card" style="max-width:760px;padding:20px;margin-top:24px;">
			<h2>2. Importa (sul sito live)</h2>
			<p>Le immagini incluse vengono copiate nella Libreria media e gli URL aggiornati. Prima di ogni modifica WordPress conserva una revisione della pagina.</p>
			<form method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="cfs_ct_import">
				<?php wp_nonce_field( 'cfs_ct_import' ); ?>
				<input type="file" name="cfs_file" accept="application/json,.json" required>
				<?php submit_button( 'Importa e aggiorna', 'primary', 'submit', false ); ?>
			</form>
		</div>
	</div>
	<?php
}

/* ============================================================
 * Esportazione
 * ============================================================ */

function cfs_ct_export() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Non hai i permessi necessari.', 'capoferrisagl' ) );
	}
	check_admin_referer( 'cfs_ct_export' );

	$ref_ids = array();
	$urls    = array();

	// Pagine.
	$pages = array();
	foreach ( cfs_ct_pages() as $slug => $label ) {
		$page = get_page_by_path( $slug, OBJECT, 'page' );
		if ( ! $page instanceof WP_Post ) {
			continue;
		}
		$pages[] = array(
			'slug'     => $slug,
			'title'    => $page->post_title,
			'content'  => $page->post_content,
			'excerpt'  => $page->post_excerpt,
			'template' => get_post_meta( $page->ID, '_wp_page_template', true ),
		);
		cfs_ct_collect_urls( $page->post_content, $urls );
		cfs_ct_collect_urls( $page->post_excerpt, $urls );
	}

	// Servizi (CPT) con i loro meta.
	$services = array();
	$posts    = get_posts(
		array(
			'post_type'      => 'cfs_servizio',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'orderby'        => array( 'menu_order' => 'ASC', 'ID' => 'ASC' ),
		)
	);
	foreach ( $posts as $post ) {
		$meta = array();
		foreach ( get_post_meta( $post->ID ) as $key => $vals ) {
			$keep = in_array( $key, cfs_ct_meta_extra(), true );
			foreach ( cfs_ct_meta_prefixes() as $pref ) {
				if ( 0 === strpos( $key, $pref ) ) {
					$keep = true;
					break;
				}
			}
			if ( ! $keep ) {
				continue;
			}
			$val          = maybe_unserialize( $vals[0] );
			$meta[ $key ] = cfs_ct_encode( $val, $ref_ids );
			cfs_ct_collect_urls( $val, $urls );
		}
		$services[] = array(
			'slug'       => $post->post_name,
			'title'      => $post->post_title,
			'content'    => $post->post_content,
			'excerpt'    => $post->post_excerpt,
			'menu_order' => (int) $post->menu_order,
			'meta'       => $meta,
		);
		cfs_ct_collect_urls( $post->post_content, $urls );
	}

	// Opzioni del tema (con ID immagine -> token).
	$options = array();
	foreach ( cfs_ct_options() as $name ) {
		$val = get_option( $name, null );
		if ( null === $val ) {
			continue;
		}
		cfs_ct_collect_urls( $val, $urls );
		$options[ $name ] = cfs_ct_encode( $val, $ref_ids );
	}

	// Gallerie media: tutte le foto con un termine di galleria (per nome file).
	$galleries = array();
	if ( taxonomy_exists( 'ticinoweb_media_gallery' ) ) {
		$att_ids = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'tax_query'      => array( array( 'taxonomy' => 'ticinoweb_media_gallery', 'operator' => 'EXISTS' ) ),
			)
		);
		foreach ( $att_ids as $aid ) {
			$file = cfs_ct_basename( $aid );
			if ( '' === $file ) {
				continue;
			}
			$terms = wp_get_object_terms( $aid, 'ticinoweb_media_gallery', array( 'fields' => 'slugs' ) );
			$entry = array( 'file' => $file );
			if ( ! is_wp_error( $terms ) && $terms ) {
				$entry['galleries'] = $terms;
			}
			$title = get_the_title( $aid );
			if ( '' !== trim( (string) $title ) ) {
				$entry['title'] = $title;
			}
			$alt = get_post_meta( $aid, '_wp_attachment_image_alt', true );
			if ( '' !== trim( (string) $alt ) ) {
				$entry['alt'] = $alt;
			}
			if ( count( $entry ) > 1 ) {
				$galleries[] = $entry;
			}
		}
	}

	// Indice immagini (per riagganciare gli URL per nome file) e file opzionali.
	$include_all = ! empty( $_POST['cfs_include_files'] );
	$only        = array();
	if ( ! empty( $_POST['cfs_only_files'] ) ) {
		foreach ( preg_split( '/[\r\n,]+/', (string) wp_unslash( $_POST['cfs_only_files'] ) ) as $line ) {
			$n = sanitize_file_name( trim( $line ) );
			if ( '' !== $n ) {
				$only[ $n ] = true;
			}
		}
		if ( $only ) {
			$include_all = true;
		}
	}

	// URL di tutti gli allegati referenziati per ID (per l'indice + eventuale file).
	foreach ( array_unique( $ref_ids ) as $rid ) {
		$u = wp_get_attachment_url( $rid );
		if ( $u ) {
			$urls[] = $u;
		}
	}

	$media_index = array();
	$media       = array();
	foreach ( array_values( array_unique( $urls ) ) as $u ) {
		$fn = basename( (string) ( wp_parse_url( $u, PHP_URL_PATH ) ?? '' ) );
		if ( '' !== $fn ) {
			$media_index[] = array( 'source' => $u, 'file' => $fn );
		}
		if ( ! $include_all ) {
			continue;
		}
		if ( $only && ! isset( $only[ $fn ] ) ) {
			continue;
		}
		$asset = cfs_ct_asset_from_url( $u );
		if ( $asset ) {
			$media[] = $asset;
		}
	}

	$payload = array(
		'format'      => 'capoferri-content',
		'version'     => 1,
		'exported_at' => gmdate( 'c' ),
		'source_url'  => home_url(),
		'pages'       => $pages,
		'services'    => $services,
		'options'     => $options,
		'galleries'   => $galleries,
		'media_index' => $media_index,
		'media'       => $media,
	);

	$filename = 'capoferri-contenuti-' . gmdate( 'Y-m-d-His' ) . '.json';
	nocache_headers();
	header( 'Content-Type: application/json; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
	echo wp_json_encode( $payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
	exit;
}
add_action( 'admin_post_cfs_ct_export', 'cfs_ct_export' );

/* ============================================================
 * Importazione
 * ============================================================ */

/** Copia nella Media Library un file incluso nel pacchetto. */
function cfs_ct_import_asset( $asset ) {
	if ( ! is_array( $asset ) || empty( $asset['filename'] ) || empty( $asset['data'] ) || empty( $asset['sha256'] ) ) {
		return new WP_Error( 'invalid', 'Dati immagine non validi.' );
	}
	$filename = sanitize_file_name( $asset['filename'] );
	$binary   = base64_decode( $asset['data'], true ); // phpcs:ignore
	if ( ! $filename || false === $binary || hash( 'sha256', $binary ) !== $asset['sha256'] ) {
		return new WP_Error( 'hash', 'Immagine danneggiata.' );
	}
	$time = null;
	if ( ! empty( $asset['relative_path'] ) && preg_match( '~(?:^|/)(20\d{2})/(0[1-9]|1[0-2])(?:/|$)~', $asset['relative_path'], $d ) ) {
		$time = $d[1] . '/' . $d[2];
	}
	$uploads = wp_upload_dir( $time );
	$target  = trailingslashit( $uploads['path'] ) . $filename;
	$url     = trailingslashit( $uploads['url'] ) . rawurlencode( $filename );

	if ( file_exists( $target ) && hash_file( 'sha256', $target ) === $asset['sha256'] ) {
		$id = attachment_url_to_postid( $url );
		if ( ! $id ) {
			$ft = wp_check_filetype( $target );
			$id = wp_insert_attachment(
				array(
					'guid'           => $url,
					'post_mime_type' => $ft['type'] ? $ft['type'] : ( $asset['mime_type'] ?? 'application/octet-stream' ),
					'post_title'     => sanitize_text_field( pathinfo( $filename, PATHINFO_FILENAME ) ),
					'post_status'    => 'inherit',
				),
				$target
			);
		}
		return array( 'url' => $url, 'id' => is_wp_error( $id ) ? 0 : (int) $id );
	}

	$res = wp_upload_bits( $filename, null, $binary, $time );
	if ( ! empty( $res['error'] ) ) {
		return new WP_Error( 'upload', $res['error'] );
	}
	$ft = wp_check_filetype( $res['file'] );
	$id = wp_insert_attachment(
		array(
			'guid'           => $res['url'],
			'post_mime_type' => $ft['type'] ? $ft['type'] : ( $asset['mime_type'] ?? 'application/octet-stream' ),
			'post_title'     => sanitize_text_field( pathinfo( $filename, PATHINFO_FILENAME ) ),
			'post_status'    => 'inherit',
		),
		$res['file']
	);
	if ( ! is_wp_error( $id ) ) {
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$md = wp_generate_attachment_metadata( $id, $res['file'] );
		if ( $md ) {
			wp_update_attachment_metadata( $id, $md );
		}
	}
	return array( 'url' => $res['url'], 'id' => is_wp_error( $id ) ? 0 : (int) $id );
}

/** Aggiunge alla mappa URL le varianti col prefisso del sotto-sito di partenza. */
function cfs_ct_expand_map( array $map, $source_url ) {
	$prefix = trim( (string) wp_parse_url( (string) $source_url, PHP_URL_PATH ), '/' );
	if ( '' === $prefix ) {
		return $map;
	}
	$prefix = '/' . $prefix;
	$out    = $map;
	foreach ( $map as $k => $v ) {
		if ( 0 === strpos( $k, '/wp-content/' ) ) {
			$out[ $prefix . $k ] = $v;
		}
	}
	return $out;
}

function cfs_ct_import() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Non hai i permessi necessari.', 'capoferrisagl' ) );
	}
	check_admin_referer( 'cfs_ct_import' );

	$redirect = admin_url( 'admin.php?page=cfs-content-transfer' );
	$file     = isset( $_FILES['cfs_file'] ) ? $_FILES['cfs_file'] : null;
	$limit    = max( (int) wp_max_upload_size(), 8 * MB_IN_BYTES );

	if ( ! is_array( $file ) || UPLOAD_ERR_OK !== (int) $file['error'] || empty( $file['tmp_name'] ) || (int) $file['size'] > $limit ) {
		wp_safe_redirect( add_query_arg( 'cfs_ct_notice', 'error', $redirect ) );
		exit;
	}
	$data = json_decode( file_get_contents( $file['tmp_name'] ), true ); // phpcs:ignore
	if ( ! is_array( $data ) || 'capoferri-content' !== ( $data['format'] ?? '' ) ) {
		wp_safe_redirect( add_query_arg( 'cfs_ct_notice', 'error', $redirect ) );
		exit;
	}

	$source_url = isset( $data['source_url'] ) ? untrailingslashit( esc_url_raw( $data['source_url'] ) ) : '';
	$target_url = untrailingslashit( home_url() );
	$updated    = 0;
	$missing    = array();
	$media_map  = array();

	// 1) File immagine inclusi nel pacchetto.
	if ( is_array( $data['media'] ?? null ) ) {
		foreach ( $data['media'] as $asset ) {
			$src = isset( $asset['source'] ) ? (string) $asset['source'] : '';
			if ( ! $src ) {
				continue;
			}
			$new = cfs_ct_import_asset( $asset );
			if ( ! is_wp_error( $new ) ) {
				$media_map[ $src ] = $new['url'];
			}
		}
	}

	// 2) Immagini non spedite: riaggancio per nome file (URL locale).
	if ( is_array( $data['media_index'] ?? null ) ) {
		foreach ( $data['media_index'] as $voce ) {
			$src = isset( $voce['source'] ) ? (string) $voce['source'] : '';
			$fn  = isset( $voce['file'] ) ? (string) $voce['file'] : '';
			if ( '' === $src || isset( $media_map[ $src ] ) ) {
				continue;
			}
			$local = cfs_ct_find_local_asset( $fn );
			if ( $local ) {
				$media_map[ $src ] = $local['url'];
			} else {
				$missing[] = $fn;
			}
		}
	}
	$media_map = cfs_ct_expand_map( $media_map, $source_url );

	// 3) Pagine.
	$allowed_pages = cfs_ct_pages();
	$home_id       = 0;
	foreach ( (array) ( $data['pages'] ?? array() ) as $item ) {
		$slug = isset( $item['slug'] ) ? sanitize_title( $item['slug'] ) : '';
		if ( ! isset( $allowed_pages[ $slug ] ) ) {
			continue;
		}
		$content = cfs_ct_decode( (string) ( $item['content'] ?? '' ), $media_map, $source_url, $target_url, $missing );
		$excerpt = cfs_ct_decode( (string) ( $item['excerpt'] ?? '' ), $media_map, $source_url, $target_url, $missing );
		$page    = get_page_by_path( $slug, OBJECT, 'page' );
		$post    = array(
			'post_type'    => 'page',
			'post_name'    => $slug,
			'post_title'   => isset( $item['title'] ) ? sanitize_text_field( $item['title'] ) : $allowed_pages[ $slug ],
			'post_content' => wp_kses_post( $content ),
			'post_excerpt' => wp_kses_post( $excerpt ),
		);
		if ( $page instanceof WP_Post ) {
			wp_save_post_revision( $page->ID );
			$post['ID'] = $page->ID;
			$res        = wp_update_post( wp_slash( $post ), true );
		} else {
			$post['post_status'] = 'publish';
			$res                 = wp_insert_post( wp_slash( $post ), true );
		}
		if ( is_wp_error( $res ) ) {
			continue;
		}
		$template = isset( $item['template'] ) ? sanitize_file_name( $item['template'] ) : '';
		if ( $template ) {
			update_post_meta( $res, '_wp_page_template', $template );
		}
		if ( 'home' === $slug ) {
			$home_id = (int) $res;
		}
		++$updated;
	}

	// Imposta la Home come pagina iniziale.
	if ( $home_id ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $home_id );
	}

	// 4) Servizi (CPT) + meta.
	foreach ( (array) ( $data['services'] ?? array() ) as $item ) {
		$slug = isset( $item['slug'] ) ? sanitize_title( $item['slug'] ) : '';
		if ( '' === $slug ) {
			continue;
		}
		$content = cfs_ct_decode( (string) ( $item['content'] ?? '' ), $media_map, $source_url, $target_url, $missing );
		$excerpt = cfs_ct_decode( (string) ( $item['excerpt'] ?? '' ), $media_map, $source_url, $target_url, $missing );
		$existing = get_page_by_path( $slug, OBJECT, 'cfs_servizio' );
		$pd       = array(
			'post_type'    => 'cfs_servizio',
			'post_name'    => $slug,
			'post_title'   => isset( $item['title'] ) ? sanitize_text_field( $item['title'] ) : $slug,
			'post_content' => wp_kses_post( $content ),
			'post_excerpt' => wp_kses_post( $excerpt ),
			'menu_order'   => isset( $item['menu_order'] ) ? (int) $item['menu_order'] : 0,
		);
		if ( $existing instanceof WP_Post ) {
			wp_save_post_revision( $existing->ID );
			$pd['ID'] = $existing->ID;
			$res      = wp_update_post( wp_slash( $pd ), true );
		} else {
			$pd['post_status'] = 'publish';
			$res               = wp_insert_post( wp_slash( $pd ), true );
		}
		if ( is_wp_error( $res ) ) {
			continue;
		}
		if ( is_array( $item['meta'] ?? null ) ) {
			foreach ( $item['meta'] as $mk => $mv ) {
				$mk   = sanitize_key( $mk );
				$keep = in_array( $mk, cfs_ct_meta_extra(), true );
				foreach ( cfs_ct_meta_prefixes() as $pref ) {
					if ( 0 === strpos( $mk, $pref ) ) {
						$keep = true;
						break;
					}
				}
				if ( ! $keep ) {
					continue;
				}
				$mv = cfs_ct_decode( $mv, $media_map, $source_url, $target_url, $missing );
				update_post_meta( $res, $mk, $mv );
			}
		}
		++$updated;
	}

	// 5) Opzioni del tema.
	if ( is_array( $data['options'] ?? null ) ) {
		$allowed_opts = cfs_ct_options();
		foreach ( $data['options'] as $name => $val ) {
			if ( ! in_array( $name, $allowed_opts, true ) ) {
				continue;
			}
			$val = cfs_ct_decode( $val, $media_map, $source_url, $target_url, $missing );
			update_option( $name, $val );
			++$updated;
		}
	}

	// 6) Gallerie media: appartenenza + titolo + alt, per nome file.
	if ( is_array( $data['galleries'] ?? null ) && taxonomy_exists( 'ticinoweb_media_gallery' ) ) {
		foreach ( $data['galleries'] as $voce ) {
			$fn = isset( $voce['file'] ) ? (string) $voce['file'] : '';
			if ( '' === $fn ) {
				continue;
			}
			$local = cfs_ct_find_local_asset( $fn );
			if ( ! $local ) {
				$missing[] = $fn;
				continue;
			}
			$aid = (int) $local['id'];
			if ( is_array( $voce['galleries'] ?? null ) ) {
				wp_set_object_terms( $aid, array_map( 'sanitize_title', $voce['galleries'] ), 'ticinoweb_media_gallery', true );
			}
			if ( ! empty( $voce['title'] ) ) {
				wp_update_post( array( 'ID' => $aid, 'post_title' => sanitize_text_field( (string) $voce['title'] ) ) );
			}
			if ( isset( $voce['alt'] ) ) {
				update_post_meta( $aid, '_wp_attachment_image_alt', sanitize_text_field( (string) $voce['alt'] ) );
			}
			++$updated;
		}
	}

	$missing = array_values( array_unique( array_filter( $missing ) ) );
	if ( $missing ) {
		update_option( 'cfs_ct_missing_files', $missing, false );
	} else {
		delete_option( 'cfs_ct_missing_files' );
	}

	flush_rewrite_rules();

	wp_safe_redirect(
		add_query_arg(
			array(
				'cfs_ct_notice'  => $updated ? 'success' : 'error',
				'cfs_ct_count'   => $updated,
				'cfs_ct_missing' => count( $missing ),
			),
			$redirect
		)
	);
	exit;
}
add_action( 'admin_post_cfs_ct_import', 'cfs_ct_import' );
