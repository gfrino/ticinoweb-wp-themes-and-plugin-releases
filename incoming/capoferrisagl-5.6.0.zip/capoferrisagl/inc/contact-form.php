<?php
/**
 * Modulo contatti: il design è del child, l'invio è del parent.
 *
 * Il modulo invia a `ticinoweb_submit_form` (ticinoWEB CMS): salvataggio in
 * Invii Ricevuti, reCAPTCHA v3, limite di invii, destinatario e SMTP dal CMS.
 * Qui si adattano solo i nomi dei campi e i testi, con i filtri del parent.
 *
 * @package Capoferrisagl
 */

if (!defined('ABSPATH')) {
    exit;
}

/** Vero quando l'invio in corso arriva dal modulo del child. */
function cfs_is_contact_post($post = null)
{
    $post = $post ?? $_POST; // phpcs:ignore WordPress.Security.NonceVerification
    return !empty($post['cfs_form']);
}

/** Campi del modulo → campi del parent (il servizio scelto diventa l'oggetto). */
add_filter('ticinoweb_form_fields', 'cfs_map_form_fields', 10, 2);
function cfs_map_form_fields($fields, $post)
{
    if (!cfs_is_contact_post($post)) {
        return $fields;
    }
    $get = function ($key) use ($post) {
        return isset($post[$key]) ? wp_unslash($post[$key]) : '';
    };
    $fields['nome']      = sanitize_text_field($get('name'));
    $fields['email']     = sanitize_email($get('email'));
    $fields['telefono']  = sanitize_text_field($get('phone'));
    $fields['oggetto']   = sanitize_text_field($get('service'));
    $fields['messaggio'] = sanitize_textarea_field($get('message'));
    return $fields;
}

/** Controlli del modulo: messaggio di almeno 10 caratteri e consenso privacy. */
add_filter('ticinoweb_form_errors', 'cfs_form_errors', 10, 3);
function cfs_form_errors($errors, $fields, $post)
{
    if (!cfs_is_contact_post($post)) {
        return $errors;
    }
    if (empty($errors['messaggio']) && mb_strlen($fields['messaggio']) < 10) {
        $errors['messaggio'] = __('Scrivi un messaggio di almeno 10 caratteri.', 'capoferrisagl');
    }
    if (empty($post['privacy'])) {
        $errors['privacy'] = __('Per inviare la richiesta devi accettare l\'informativa sulla privacy.', 'capoferrisagl');
    }
    return $errors;
}

/** Oggetto dell'email (testo del CMS del child) e messaggio di conferma. */
add_filter('ticinoweb_form_email_subject', function ($subject) {
    if (!cfs_is_contact_post()) {
        return $subject;
    }
    $custom = cfs_contact('mail.subject', '');
    return $custom !== '' ? $custom : $subject;
});

add_filter('ticinoweb_form_success_message', function ($message) {
    return cfs_is_contact_post() ? cfs_contact('form.success', $message) : $message;
});
