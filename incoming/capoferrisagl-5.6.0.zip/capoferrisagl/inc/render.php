<?php
/**
 * Funzioni di render condivise fra i template.
 * Nessun testo editoriale qui dentro: tutto arriva dal CMS.
 *
 * @package Capoferrisagl
 */

if (!defined('ABSPATH')) {
    exit;
}

/* ─────────────────────────────────────────────
   INTESTAZIONE DI SEZIONE
   ───────────────────────────────────────────── */

function cfs_section_header($label, $title, $text = '', $align = 'left')
{
    if (trim((string) $title) === '' && trim((string) $label) === '') {
        return;
    }
    ?>
    <header class="cfs-section-head cfs-section-head--<?php echo esc_attr($align); ?>">
        <?php if ($label) : ?>
            <p class="cfs-eyebrow" data-reveal="text"><span class="cfs-eyebrow__mark" aria-hidden="true"></span><?php echo esc_html($label); ?></p>
        <?php endif; ?>
        <?php if ($title) : ?>
            <h2 class="cfs-section-title" data-split="lines"><?php echo esc_html($title); ?></h2>
        <?php endif; ?>
        <?php if ($text) : ?>
            <div class="cfs-section-lead" data-reveal="text"><?php cfs_paragraphs($text); ?></div>
        <?php endif; ?>
    </header>
    <?php
}

/* ─────────────────────────────────────────────
   LINEE TECNICHE
   ───────────────────────────────────────────── */

/**
 * Tracciato SVG che richiama una condotta. Viene disegnato da DrawSVGPlugin
 * e percorso dall'indicatore con MotionPathPlugin; senza JavaScript resta
 * un dettaglio grafico statico e decorativo.
 *
 * @param string $variant hero | light | dark
 * @param bool   $dot     Mostra l'indicatore di flusso.
 */
function cfs_technical_line($variant = 'dark', $dot = true)
{
    $paths = array(
        'hero'  => 'M-280,96 C120,96 260,30 560,30 L880,30 C1140,30 1220,92 1480,92',
        'dark'  => 'M-40,60 C220,60 280,14 520,14 L940,14 C1180,14 1240,62 1480,62',
        'light' => 'M-40,40 C260,40 320,88 620,88 L860,88 C1160,88 1220,36 1480,36',
    );
    $d = $paths[$variant] ?? $paths['dark'];
    ?>
    <svg class="cfs-tech-svg cfs-tech-svg--<?php echo esc_attr($variant); ?>"
         viewBox="0 0 1440 120" preserveAspectRatio="none" aria-hidden="true" focusable="false">
        <path d="<?php echo esc_attr($d); ?>" data-technical-path />
        <?php if ($dot) : ?>
            <circle class="cfs-tech-svg__dot" r="5" cx="0" cy="0" data-flow-dot />
        <?php endif; ?>
    </svg>
    <?php
}

/* ─────────────────────────────────────────────
   CARD SERVIZIO
   ───────────────────────────────────────────── */

/**
 * Card di un servizio. $variant: "feature" (grande) o "standard".
 */
function cfs_service_card($post_id, $index = 0, $variant = 'standard')
{
    $cover = cfs_service_cover($post_id);
    $label = cfs_service_meta($post_id, 'label', '');
    $text  = cfs_service_meta($post_id, 'excerpt', '');
    $focal = cfs_focal(cfs_service_meta($post_id, 'cover_focal', ''));
    ?>
    <article class="cfs-card cfs-card--<?php echo esc_attr($variant); ?>" data-reveal="card" data-service-card>
        <a class="cfs-card__link" href="<?php echo esc_url(get_permalink($post_id)); ?>">
            <span class="cfs-card__media">
                <?php if ($cover) : ?>
                    <?php cfs_the_image($cover, $variant === 'feature' ? 'cfs-hero' : 'cfs-card', array(
                        'class' => 'cfs-card__img',
                        'focal' => $focal,
                        'alt'   => cfs_service_meta($post_id, 'cover_alt', ''),
                    )); ?>
                <?php endif; ?>
                <span class="cfs-card__index" aria-hidden="true"><?php echo esc_html(str_pad((string) ($index + 1), 2, '0', STR_PAD_LEFT)); ?></span>
            </span>
            <span class="cfs-card__body">
                <?php if ($label) : ?>
                    <span class="cfs-card__label"><?php echo esc_html($label); ?></span>
                <?php endif; ?>
                <h3 class="cfs-card__title"><?php echo esc_html(get_the_title($post_id)); ?></h3>
                <?php if ($text) : ?>
                    <span class="cfs-card__text"><?php echo esc_html(wp_trim_words($text, 26)); ?></span>
                <?php endif; ?>
                <span class="cfs-card__cta" aria-hidden="true">
                    <?php esc_html_e('Scopri il servizio', 'capoferrisagl'); ?>
                    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
                </span>
            </span>
        </a>
    </article>
    <?php
}

/* ─────────────────────────────────────────────
   BLOCCHI MODULARI (pagine servizio)
   ───────────────────────────────────────────── */

function cfs_render_blocks($blocks)
{
    $blocks = cfs_rows($blocks);
    if (!$blocks) {
        return;
    }

    foreach ($blocks as $block) {
        $type = $block['type'] ?? 'title_text';

        switch ($type) {

            case 'text_image_right':
            case 'text_image_left':
                $image = (int) ($block['image'] ?? 0);
                if (!$image && trim((string) ($block['text'] ?? '')) === '') {
                    break;
                }
                $side = $type === 'text_image_left' ? 'left' : 'right';
                ?>
                <section class="cfs-block cfs-block--media cfs-block--media-<?php echo esc_attr($side); ?>">
                    <div class="cfs-block__text" data-reveal="text">
                        <?php if (!empty($block['heading'])) : ?>
                            <h2 data-split="lines"><?php echo esc_html($block['heading']); ?></h2>
                        <?php endif; ?>
                        <?php cfs_paragraphs($block['text'] ?? ''); ?>
                        <?php cfs_the_button($block['cta_text'] ?? '', $block['cta_url'] ?? '', 'cfs-btn cfs-btn--ghost'); ?>
                    </div>
                    <?php if ($image) : ?>
                        <figure class="cfs-block__media" data-reveal="image">
                            <?php cfs_the_image($image, 'cfs-portrait', array('class' => 'cfs-block__img')); ?>
                            <?php if (!empty($block['image_caption'])) : ?>
                                <figcaption><?php echo esc_html($block['image_caption']); ?></figcaption>
                            <?php endif; ?>
                        </figure>
                    <?php endif; ?>
                </section>
                <?php
                break;

            case 'image_full':
                $image = (int) ($block['image'] ?? 0);
                if (!$image) {
                    break;
                }
                ?>
                <figure class="cfs-block cfs-block--image-full" data-reveal="image">
                    <?php cfs_the_image($image, 'cfs-hero', array('class' => 'cfs-block__img')); ?>
                    <?php if (!empty($block['image_caption'])) : ?>
                        <figcaption><?php echo esc_html($block['image_caption']); ?></figcaption>
                    <?php endif; ?>
                </figure>
                <?php
                break;

            case 'two_columns':
                if (trim((string) ($block['text'] ?? '')) === '') {
                    break;
                }
                ?>
                <section class="cfs-block cfs-block--columns" data-reveal="text">
                    <?php if (!empty($block['heading'])) : ?>
                        <h2 class="cfs-block__heading" data-split="lines"><?php echo esc_html($block['heading']); ?></h2>
                    <?php endif; ?>
                    <div class="cfs-block__columns"><?php cfs_paragraphs($block['text']); ?></div>
                </section>
                <?php
                break;

            case 'list':
            case 'benefits':
                $items = cfs_lines($block['items'] ?? '');
                if (!$items) {
                    break;
                }
                ?>
                <section class="cfs-block cfs-block--<?php echo esc_attr($type); ?>" data-reveal="text">
                    <?php if (!empty($block['heading'])) : ?>
                        <h2 class="cfs-block__heading" data-split="lines"><?php echo esc_html($block['heading']); ?></h2>
                    <?php endif; ?>
                    <ul class="cfs-list cfs-list--<?php echo esc_attr($type); ?>">
                        <?php foreach ($items as $item) : ?>
                            <li><span class="cfs-list__mark" aria-hidden="true"></span><?php echo esc_html($item); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </section>
                <?php
                break;

            case 'quote':
                if (trim((string) ($block['text'] ?? '')) === '') {
                    break;
                }
                ?>
                <blockquote class="cfs-block cfs-block--quote" data-reveal="text">
                    <p><?php echo esc_html($block['text']); ?></p>
                    <?php if (!empty($block['author'])) : ?>
                        <cite><?php echo esc_html($block['author']); ?></cite>
                    <?php endif; ?>
                </blockquote>
                <?php
                break;

            case 'cta':
                if (trim((string) ($block['heading'] ?? '')) === '' && trim((string) ($block['text'] ?? '')) === '') {
                    break;
                }
                ?>
                <section class="cfs-block cfs-block--cta" data-reveal="text">
                    <?php if (!empty($block['heading'])) : ?>
                        <h2><?php echo esc_html($block['heading']); ?></h2>
                    <?php endif; ?>
                    <?php cfs_paragraphs($block['text'] ?? ''); ?>
                    <?php cfs_the_button($block['cta_text'] ?? '', $block['cta_url'] ?? ''); ?>
                </section>
                <?php
                break;

            case 'gallery':
                $ids = array_filter(array_map('absint', explode(',', (string) ($block['gallery'] ?? ''))));
                if (!$ids) {
                    break;
                }
                cfs_render_gallery($ids, $block['heading'] ?? '', '');
                break;

            case 'separator':
                echo '<hr class="cfs-block cfs-block--separator">';
                break;

            case 'spacer':
                printf('<div class="cfs-block cfs-block--spacer cfs-block--spacer-%s" aria-hidden="true"></div>', esc_attr($block['space'] ?? 'md'));
                break;

            default: // title_text
                if (trim((string) ($block['heading'] ?? '')) === '' && trim((string) ($block['text'] ?? '')) === '') {
                    break;
                }
                ?>
                <section class="cfs-block cfs-block--text" data-reveal="text">
                    <?php if (!empty($block['heading'])) : ?>
                        <h2 data-split="lines"><?php echo esc_html($block['heading']); ?></h2>
                    <?php endif; ?>
                    <?php cfs_paragraphs($block['text'] ?? ''); ?>
                    <?php cfs_the_button($block['cta_text'] ?? '', $block['cta_url'] ?? '', 'cfs-btn cfs-btn--ghost'); ?>
                </section>
                <?php
                break;
        }
    }
}

/* ─────────────────────────────────────────────
   GALLERIA + LIGHTBOX
   ───────────────────────────────────────────── */

/**
 * Griglia di immagini con lightbox. Non stampa nulla se non ci sono immagini.
 */
function cfs_render_gallery($ids, $title = '', $text = '', $label = '')
{
    $ids = array_values(array_filter(array_map('absint', (array) $ids)));
    if (!$ids) {
        return;
    }
    ?>
    <section class="cfs-gallery-section" id="galleria">
        <div class="cfs-container">
            <?php cfs_section_header($label, $title, $text); ?>
            <ul class="cfs-grid-gallery" data-lightbox-gallery>
                <?php foreach ($ids as $index => $image_id) :
                    $full = cfs_image($image_id, 'full');
                    $thumb = cfs_image($image_id, 'cfs-card');
                    if (!$full || !$thumb) {
                        continue;
                    } ?>
                    <li class="cfs-grid-gallery__item" data-reveal="fade">
                        <button type="button"
                                class="cfs-grid-gallery__btn"
                                data-lightbox-item
                                data-full="<?php echo esc_url($full['url']); ?>"
                                data-caption="<?php echo esc_attr($full['caption']); ?>"
                                data-alt="<?php echo esc_attr($full['alt']); ?>"
                                aria-label="<?php echo esc_attr(sprintf(__('Apri l\'immagine %d a schermo intero', 'capoferrisagl'), $index + 1)); ?>">
                            <?php cfs_the_image($image_id, 'cfs-card', array('class' => 'cfs-grid-gallery__img')); ?>
                        </button>
                        <?php if ($full['caption']) : ?>
                            <p class="cfs-grid-gallery__caption"><?php echo esc_html($full['caption']); ?></p>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </section>
    <?php
}

/* ─────────────────────────────────────────────
   CALL TO ACTION
   ───────────────────────────────────────────── */

/**
 * Sezione CTA. $data accetta title, text, btn1_text/url, btn2_text/url, image, label.
 * Se il titolo è vuoto usa la CTA globale delle Impostazioni sito.
 */
function cfs_render_cta($data = array())
{
    $data = is_array($data) ? $data : array();

    if (trim((string) ($data['title'] ?? '')) === '') {
        $data = array(
            'title'     => cfs_settings('cta_title', ''),
            'text'      => cfs_settings('cta_text', ''),
            'btn1_text' => cfs_settings('cta_btn1_text', ''),
            'btn1_url'  => cfs_settings('cta_btn1_url', ''),
            'btn2_text' => cfs_settings('cta_btn2_text', ''),
            'btn2_url'  => cfs_settings('cta_btn2_url', ''),
            'image'     => $data['image'] ?? '',
            'label'     => '',
        );
    }

    if (trim((string) $data['title']) === '') {
        return;
    }

    $company = cfs_company();
    $image   = (int) ($data['image'] ?? 0);
    ?>
    <section class="cfs-cta<?php echo $image ? ' cfs-cta--image' : ''; ?>" data-cta-section data-technical-section>
        <?php cfs_technical_line('dark'); ?>
        <?php if ($image) : ?>
            <div class="cfs-cta__bg" aria-hidden="true">
                <?php cfs_the_image($image, 'cfs-hero', array('class' => 'cfs-cta__img')); ?>
            </div>
        <?php endif; ?>
        <div class="cfs-container cfs-cta__inner">
            <?php if (!empty($data['label'])) : ?>
                <p class="cfs-eyebrow cfs-eyebrow--light"><span class="cfs-eyebrow__mark" aria-hidden="true"></span><?php echo esc_html($data['label']); ?></p>
            <?php endif; ?>
            <h2 class="cfs-cta__title" data-split="lines"><?php echo esc_html($data['title']); ?></h2>
            <?php if (!empty($data['text'])) : ?>
                <div class="cfs-cta__text"><?php cfs_paragraphs($data['text']); ?></div>
            <?php endif; ?>
            <div class="cfs-cta__actions">
                <?php cfs_the_button($data['btn1_text'] ?? '', $data['btn1_url'] ?? '', 'cfs-btn cfs-btn--primary'); ?>
                <?php cfs_the_button($data['btn2_text'] ?? '', $data['btn2_url'] ?? '', 'cfs-btn cfs-btn--outline'); ?>
                <?php if ($company['phone'] && $company['phone_href']) : ?>
                    <a class="cfs-cta__phone" href="<?php echo esc_url($company['phone_href']); ?>">
                        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 2 .7 2.9a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.2-1.2a2 2 0 0 1 2.1-.5c.9.3 1.9.6 2.9.7a2 2 0 0 1 1.7 2Z"/></svg>
                        <?php echo esc_html($company['phone']); ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <?php
}

/* ─────────────────────────────────────────────
   PUNTI DI FORZA
   ───────────────────────────────────────────── */

/** Icone predefinite coerenti per la griglia dei valori (scudo, fulmine, foglia, ingranaggio). */
function cfs_strength_icon($index)
{
    $icons = array(
        // Solidità — scudo
        '<path d="M12 3l7 3v5c0 4.4-3 8-7 9-4-1-7-4.6-7-9V6l7-3z"/>',
        // Prontezza — fulmine
        '<path d="M13 3L5 13h5l-1 8 8-11h-5l1-7z"/>',
        // Ambiente — foglia
        '<path d="M4 20s-.8-8 6-12c3.6-2.1 10-2 10-2s.1 6.4-2 10c-3.5 6-14 4-14 4z"/><path d="M8.5 15.5C11 13 14 12 17.5 11"/>',
        // Competenza — ingranaggio
        '<circle cx="12" cy="12" r="3"/><path d="M19.4 13a7.6 7.6 0 0 0 0-2l2-1.5-2-3.4-2.4 1a7.6 7.6 0 0 0-1.7-1L14.9 3h-3.8l-.4 2.6a7.6 7.6 0 0 0-1.7 1l-2.4-1-2 3.4L6.6 11a7.6 7.6 0 0 0 0 2l-2 1.5 2 3.4 2.4-1a7.6 7.6 0 0 0 1.7 1l.4 2.6h3.8l.4-2.6a7.6 7.6 0 0 0 1.7-1l2.4 1 2-3.4-2-1.5z"/>',
    );
    $d = $icons[$index % count($icons)];
    return '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round" stroke-linecap="round">' . $d . '</svg>';
}

function cfs_render_strengths($rows, $class = 'cfs-strengths')
{
    $rows = cfs_rows($rows);
    if (!$rows) {
        return;
    }
    ?>
    <ul class="<?php echo esc_attr($class); ?>">
        <?php foreach ($rows as $row) :
            if (trim((string) ($row['title'] ?? '')) === '') {
                continue;
            } ?>
            <li data-reveal="text">
                <?php if (!empty($row['icon'])) : ?>
                    <span class="cfs-strengths__icon"><?php cfs_the_image((int) $row['icon'], 'cfs-thumb', array('alt' => '')); ?></span>
                <?php elseif (strpos($class, 'cfs-strengths--grid') !== false) : ?>
                    <span class="cfs-strengths__ico" aria-hidden="true"><?php echo cfs_strength_icon($i ?? 0); // phpcs:ignore ?></span>
                <?php endif; ?>
                <h3><?php echo esc_html($row['title']); ?></h3>
                <?php if (!empty($row['text'])) : ?>
                    <p><?php echo esc_html($row['text']); ?></p>
                <?php endif; ?>
            </li>
        <?php $i = ($i ?? 0) + 1; endforeach; ?>
    </ul>
    <?php
}

/* ─────────────────────────────────────────────
   MODULO CONTATTI
   ───────────────────────────────────────────── */

function cfs_render_contact_form()
{
    $form     = cfs_contact('form', array());
    $services = cfs_get_services();
    ?>
    <form class="cfs-form" data-cfs-contact novalidate>
        <input type="hidden" name="cfs_form" value="1">

        <p class="cfs-form__hp" aria-hidden="true">
            <label><?php esc_html_e('Lascia vuoto questo campo', 'capoferrisagl'); ?>
                <input type="text" name="tw_hp" tabindex="-1" autocomplete="off">
            </label>
        </p>

        <div class="cfs-form__grid">
            <p class="cfs-form__field">
                <label for="cfs-name"><?php echo esc_html($form['label_name'] ?? __('Nome e cognome', 'capoferrisagl')); ?> <span class="cfs-req">*</span></label>
                <input type="text" id="cfs-name" name="name" required autocomplete="name" aria-describedby="cfs-name-error">
                <span class="cfs-form__error" id="cfs-name-error" role="alert"></span>
            </p>

            <p class="cfs-form__field">
                <label for="cfs-email"><?php echo esc_html($form['label_email'] ?? __('Email', 'capoferrisagl')); ?> <span class="cfs-req">*</span></label>
                <input type="email" id="cfs-email" name="email" required autocomplete="email" aria-describedby="cfs-email-error">
                <span class="cfs-form__error" id="cfs-email-error" role="alert"></span>
            </p>

            <p class="cfs-form__field">
                <label for="cfs-phone"><?php echo esc_html($form['label_phone'] ?? __('Telefono', 'capoferrisagl')); ?></label>
                <input type="tel" id="cfs-phone" name="phone" autocomplete="tel" aria-describedby="cfs-phone-error">
                <span class="cfs-form__error" id="cfs-phone-error" role="alert"></span>
            </p>

            <p class="cfs-form__field">
                <label for="cfs-service"><?php echo esc_html($form['label_service'] ?? __('Servizio di interesse', 'capoferrisagl')); ?></label>
                <select id="cfs-service" name="service">
                    <option value=""><?php esc_html_e('— Seleziona —', 'capoferrisagl'); ?></option>
                    <?php foreach ($services as $service) : ?>
                        <option value="<?php echo esc_attr($service->post_title); ?>"><?php echo esc_html($service->post_title); ?></option>
                    <?php endforeach; ?>
                </select>
            </p>

            <p class="cfs-form__field cfs-form__field--full">
                <label for="cfs-message"><?php echo esc_html($form['label_message'] ?? __('Messaggio', 'capoferrisagl')); ?> <span class="cfs-req">*</span></label>
                <textarea id="cfs-message" name="message" rows="6" required aria-describedby="cfs-message-error"></textarea>
                <span class="cfs-form__error" id="cfs-message-error" role="alert"></span>
            </p>

            <p class="cfs-form__field cfs-form__field--full cfs-form__privacy">
                <label for="cfs-privacy">
                    <input type="checkbox" id="cfs-privacy" name="privacy" value="1" required aria-describedby="cfs-privacy-error">
                    <span><?php echo wp_kses_post($form['label_privacy'] ?? __('Acconsento al trattamento dei miei dati per essere ricontattato.', 'capoferrisagl')); ?> <span class="cfs-req">*</span></span>
                </label>
                <span class="cfs-form__error" id="cfs-privacy-error" role="alert"></span>
            </p>
        </div>

        <div class="cfs-form__actions">
            <button type="submit" class="cfs-btn cfs-btn--primary" data-submit
                    data-label="<?php echo esc_attr($form['submit'] ?? __('Invia la richiesta', 'capoferrisagl')); ?>"
                    data-sending="<?php echo esc_attr($form['sending'] ?? __('Invio in corso…', 'capoferrisagl')); ?>">
                <?php echo esc_html($form['submit'] ?? __('Invia la richiesta', 'capoferrisagl')); ?>
            </button>
        </div>

        <p class="cfs-form__feedback" data-feedback role="status" aria-live="polite"></p>
    </form>
    <?php
}
