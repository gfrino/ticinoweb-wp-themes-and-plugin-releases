<?php
/**
 * Migrazione una tantum: i dati che il child teneva in proprio passano ai campi
 * del parent (ticinoWEB CMS → Contatti, Look & Feel, Invii Ricevuti).
 *
 * - Non sovrascrive mai un campo del parent già compilato.
 * - Prima di toccare qualcosa salva una copia di `cfs_settings` e `cfs_contact`
 *   in `cfs_premigration_backup`.
 * - I dati si tolgono dal child solo dopo che sono stati copiati.
 *
 * @package Capoferrisagl
 */

if (!defined('ABSPATH')) {
    exit;
}

define('CFS_PARENT_MIGRATION', 1);

add_action('init', 'cfs_maybe_migrate_to_parent', 5);
function cfs_maybe_migrate_to_parent()
{
    if ((int) get_option('cfs_parent_migration', 0) >= CFS_PARENT_MIGRATION) {
        return;
    }
    cfs_migrate_to_parent();
}

/** Copia un valore nel parent solo se il campo è ancora vuoto. */
function cfs_fill_parent_option($option, $value)
{
    $value = is_string($value) ? trim($value) : $value;
    if ($value === '' || $value === null || $value === false) {
        return;
    }
    if (trim((string) get_option($option, '')) === '') {
        update_option($option, $value);
    }
}

function cfs_migrate_to_parent()
{
    $settings = get_option('cfs_settings', array());
    $contact  = get_option('cfs_contact', array());
    if (!is_array($settings)) {
        $settings = array();
    }
    if (!is_array($contact)) {
        $contact = array();
    }

    if (get_option('cfs_premigration_backup', null) === null) {
        add_option('cfs_premigration_backup', array('cfs_settings' => $settings, 'cfs_contact' => $contact), '', false);
    }

    $s = function ($key) use ($settings) {
        return isset($settings[$key]) && !is_array($settings[$key]) ? trim((string) $settings[$key]) : '';
    };

    // Telefono (numero per il link + testo mostrato), email, social.
    $raw = $s('phone_raw');
    cfs_fill_parent_option('ticinoweb_contact_phone', $raw !== '' ? $raw : $s('phone'));
    if ($raw !== '') {
        cfs_fill_parent_option('ticinoweb_contact_phone_display', $s('phone'));
    }
    cfs_fill_parent_option('ticinoweb_contact_email', !empty($contact['mail']['to']) ? $contact['mail']['to'] : $s('email'));
    cfs_fill_parent_option('ticinoweb_contact_facebook', $s('facebook'));
    cfs_fill_parent_option('ticinoweb_contact_linkedin', $s('linkedin'));
    cfs_fill_parent_option('ticinoweb_contact_instagram', $s('instagram'));
    cfs_fill_parent_option('ticinoweb_contact_vat', $s('vat'));
    cfs_fill_parent_option('ticinoweb_contact_map_url', $s('map_url'));

    // Indirizzi: stessa riga che il sito mostrava già ("Via X 1, 6900 Lugano – Casella Postale 5").
    $legal = trim($s('street') . ($s('postal_code') . $s('city') !== '' ? ', ' . trim($s('postal_code') . ' ' . $s('city')) : ''));
    $po    = $s('po_box');
    if ($legal !== '' && $po !== '') {
        $legal .= ' – ' . (stripos($po, 'casella') === false && stripos($po, 'cp') === false ? 'CP ' . $po : $po);
    }
    $op = trim($s('op_street') . ($s('op_postal_code') . $s('op_city') !== '' ? ', ' . trim($s('op_postal_code') . ' ' . $s('op_city')) : ''));
    cfs_fill_parent_option('ticinoweb_contact_address', $legal);
    cfs_fill_parent_option('ticinoweb_contact_address_label', $s('legal_address_label'));
    cfs_fill_parent_option('ticinoweb_contact_address_2', $op);
    cfs_fill_parent_option('ticinoweb_contact_address_2_label', $s('op_address_label'));

    // Logo: il parent salva l'URL.
    $logo_id = (int) ($settings['logo'] ?? 0);
    if ($logo_id) {
        cfs_fill_parent_option('ticinoweb_site_logo', (string) wp_get_attachment_url($logo_id));
    }

    // Richieste già ricevute: dal CPT del child alla tabella Invii Ricevuti.
    cfs_migrate_leads();

    // Il child non conserva più questi dati.
    foreach (array('street', 'po_box', 'postal_code', 'city', 'country', 'legal_address_label', 'op_street', 'op_postal_code',
        'op_city', 'op_address_label', 'phone', 'phone_raw', 'email', 'vat', 'hours', 'map_url', 'latitude', 'longitude',
        'logo', 'favicon', 'og_default', 'facebook', 'linkedin', 'instagram') as $key) {
        unset($settings[$key]);
    }
    unset($contact['mail']);
    update_option('cfs_settings', $settings);
    update_option('cfs_contact', $contact);

    update_option('cfs_parent_migration', CFS_PARENT_MIGRATION);
}

/** Sposta le richieste salvate dal vecchio modulo (CPT cfs_lead) in Invii Ricevuti. */
function cfs_migrate_leads()
{
    global $wpdb;
    $table = $wpdb->prefix . 'ticinoweb_form_submissions';
    if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) !== $table) {
        return; // la tabella la crea il parent: la migrazione delle richieste si ripete al prossimo avvio
    }

    $leads = get_posts(array('post_type' => 'cfs_lead', 'post_status' => 'any', 'posts_per_page' => -1, 'orderby' => 'date', 'order' => 'ASC'));
    foreach ($leads as $lead) {
        $m = function ($key) use ($lead) {
            return (string) get_post_meta($lead->ID, '_cfs_lead_' . $key, true);
        };
        $wpdb->insert($table, array(
            'data_invio' => $lead->post_date,
            'nome'       => $m('name'),
            'email'      => $m('email'),
            'telefono'   => $m('phone'),
            'oggetto'    => $m('service'),
            'messaggio'  => $m('message'),
            'letto'      => $m('status') === 'new' ? 0 : 1,
        ), array('%s', '%s', '%s', '%s', '%s', '%s', '%d'));
        wp_delete_post($lead->ID, true);
    }
}
