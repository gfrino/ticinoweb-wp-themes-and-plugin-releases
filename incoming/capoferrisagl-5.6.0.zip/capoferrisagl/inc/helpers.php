<?php
/**
 * Helper di lettura contenuti dal CMS.
 *
 * Regola: nessun contenuto editoriale hardcoded nei template.
 * Tutto passa da qui e legge da wp_options / post meta.
 *
 * @package Capoferrisagl
 */

if (!defined('ABSPATH')) {
    exit;
}

/* ─────────────────────────────────────────────
   OPTION STORE
   ───────────────────────────────────────────── */

/**
 * Elenco delle option gestite dal child theme.
 */
function cfs_option_keys()
{
    return array('cfs_home', 'cfs_about', 'cfs_contact', 'cfs_servizi', 'cfs_settings');
}

/**
 * Ritorna l'intero gruppo di option (array).
 */
function cfs_group($group)
{
    static $cache = array();
    if (isset($cache[$group])) {
        return $cache[$group];
    }
    $value = get_option($group, array());
    if (!is_array($value)) {
        $value = array();
    }
    $cache[$group] = $value;
    return $value;
}

/**
 * Legge un campo da un gruppo di option, con path a punti: "hero.title".
 */
function cfs_get($group, $path = '', $default = '')
{
    $data = cfs_group($group);
    if ($path === '') {
        return $data;
    }
    foreach (explode('.', $path) as $segment) {
        if (is_array($data) && array_key_exists($segment, $data)) {
            $data = $data[$segment];
        } else {
            return $default;
        }
    }
    if ($data === '' || $data === null) {
        return $default;
    }
    return $data;
}

/** Scorciatoie per gruppo. */
function cfs_home($path = '', $default = '')     { return cfs_get('cfs_home', $path, $default); }
function cfs_about($path = '', $default = '')    { return cfs_get('cfs_about', $path, $default); }
function cfs_contact($path = '', $default = '')  { return cfs_get('cfs_contact', $path, $default); }
function cfs_servizi($path = '', $default = '')  { return cfs_get('cfs_servizi', $path, $default); }
function cfs_settings($path = '', $default = '') { return cfs_get('cfs_settings', $path, $default); }

/**
 * Una riga di repeater è "attiva"? I repeater salvano enabled='1' di default.
 */
function cfs_row_enabled($row)
{
    if (!is_array($row)) {
        return false;
    }
    if (!array_key_exists('enabled', $row)) {
        return true;
    }
    return $row['enabled'] === '1' || $row['enabled'] === 1 || $row['enabled'] === true;
}

/**
 * Filtra le righe attive di un repeater e le ordina per "order" se presente.
 */
function cfs_rows($rows)
{
    if (!is_array($rows)) {
        return array();
    }
    $rows = array_filter($rows, 'cfs_row_enabled');
    $has_order = false;
    foreach ($rows as $row) {
        if (isset($row['order']) && $row['order'] !== '') {
            $has_order = true;
            break;
        }
    }
    if ($has_order) {
        usort($rows, function ($a, $b) {
            return ((int) ($a['order'] ?? 0)) <=> ((int) ($b['order'] ?? 0));
        });
    }
    return array_values($rows);
}

/**
 * Una sezione è abilitata? (checkbox "enabled" a livello di sezione)
 */
function cfs_section_enabled($group, $section)
{
    $value = cfs_get($group, $section . '.enabled', '1');
    return $value === '1' || $value === 1 || $value === true;
}

/* ─────────────────────────────────────────────
   IMMAGINI
   ───────────────────────────────────────────── */

/**
 * Dati completi di un'immagine partendo dall'ID allegato.
 * Ritorna array vuoto se l'immagine non esiste più.
 */
function cfs_image($attachment_id, $size = 'large')
{
    $attachment_id = (int) $attachment_id;
    if (!$attachment_id) {
        return array();
    }
    $src = wp_get_attachment_image_src($attachment_id, $size);
    if (!$src) {
        return array();
    }
    $meta_alt = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
    $post     = get_post($attachment_id);

    return array(
        'id'      => $attachment_id,
        'url'     => $src[0],
        'width'   => $src[1],
        'height'  => $src[2],
        'alt'     => $meta_alt !== '' ? $meta_alt : ($post ? $post->post_title : ''),
        'caption' => $post ? $post->post_excerpt : '',
        'title'   => $post ? $post->post_title : '',
        'srcset'  => wp_get_attachment_image_srcset($attachment_id, $size),
        'sizes'   => wp_get_attachment_image_sizes($attachment_id, $size),
    );
}

/**
 * Stampa un <img> responsive con dimensioni esplicite (evita layout shift).
 *
 * @param int   $attachment_id ID allegato.
 * @param string $size         Dimensione registrata.
 * @param array $args          class, loading, sizes, alt (override), focal (es. "50% 30%").
 */
function cfs_the_image($attachment_id, $size = 'large', $args = array())
{
    $image = cfs_image($attachment_id, $size);
    if (!$image) {
        return;
    }
    $args = wp_parse_args($args, array(
        'class'   => '',
        'loading' => 'lazy',
        'sizes'   => $image['sizes'],
        'alt'     => $image['alt'],
        'focal'   => '',
        'fetchpriority' => '',
    ));

    $attrs = array(
        'src="' . esc_url($image['url']) . '"',
        'width="' . (int) $image['width'] . '"',
        'height="' . (int) $image['height'] . '"',
        'alt="' . esc_attr($args['alt']) . '"',
        'decoding="async"',
    );
    if ($image['srcset']) {
        $attrs[] = 'srcset="' . esc_attr($image['srcset']) . '"';
        if ($args['sizes']) {
            $attrs[] = 'sizes="' . esc_attr($args['sizes']) . '"';
        }
    }
    if ($args['class']) {
        $attrs[] = 'class="' . esc_attr($args['class']) . '"';
    }
    if ($args['loading'] === 'lazy') {
        $attrs[] = 'loading="lazy"';
    }
    if ($args['fetchpriority']) {
        $attrs[] = 'fetchpriority="' . esc_attr($args['fetchpriority']) . '"';
    }
    if ($args['focal']) {
        $attrs[] = 'style="object-position:' . esc_attr($args['focal']) . '"';
    }

    echo '<img ' . implode(' ', $attrs) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput
}

/**
 * Punto focale salvato come "x|y" → stringa CSS object-position.
 */
function cfs_focal($value)
{
    $value = trim((string) $value);
    if ($value === '' || strpos($value, '|') === false) {
        return '50% 50%';
    }
    list($x, $y) = array_map('floatval', explode('|', $value, 2));
    return max(0, min(100, $x)) . '% ' . max(0, min(100, $y)) . '%';
}

/* ─────────────────────────────────────────────
   TESTO
   ───────────────────────────────────────────── */

/**
 * Paragrafi da textarea: righe vuote separano i paragrafi.
 */
function cfs_paragraphs($text, $class = '')
{
    $text = trim((string) $text);
    if ($text === '') {
        return;
    }
    $blocks = preg_split('/\n\s*\n/', $text);
    foreach ($blocks as $block) {
        $block = trim($block);
        if ($block === '') {
            continue;
        }
        printf(
            '<p%s>%s</p>',
            $class ? ' class="' . esc_attr($class) . '"' : '',
            nl2br(esc_html($block))
        );
    }
}

/**
 * Righe di una textarea come array (per elenchi puntati).
 */
function cfs_lines($text)
{
    $lines = preg_split('/\r\n|\r|\n/', (string) $text);
    $lines = array_map('trim', $lines);
    return array_values(array_filter($lines, function ($line) {
        return $line !== '';
    }));
}

/* ─────────────────────────────────────────────
   CTA / LINK
   ───────────────────────────────────────────── */

/**
 * Stampa un pulsante solo se ha sia testo che link (niente pulsanti orfani).
 */
function cfs_the_button($text, $url, $class = 'cfs-btn cfs-btn--primary', $attrs = '')
{
    $text = trim((string) $text);
    $url  = trim((string) $url);
    if ($text === '' || $url === '') {
        return;
    }
    printf(
        '<a class="%s" href="%s"%s>%s</a>',
        esc_attr($class),
        esc_url($url),
        $attrs ? ' ' . $attrs : '', // phpcs:ignore
        esc_html($text)
    );
}

/**
 * Numero di telefono → href tel: normalizzato.
 */
function cfs_tel_href($number)
{
    $clean = preg_replace('/[^0-9+]/', '', (string) $number);
    return $clean ? 'tel:' . $clean : '';
}

/* ─────────────────────────────────────────────
   DATI AZIENDA (fonte unica: ticinoWEB CMS → Contatti)
   ───────────────────────────────────────────── */

/**
 * Dati aziendali. Contatti, indirizzi, social, P.IVA e link alla mappa vivono
 * nel CMS del parent (`ticinoweb_contact_*`): qui si leggono soltanto.
 * Nel child restano solo nome e ragione sociale per l'intestazione.
 */
function cfs_company()
{
    static $company = null;
    if ($company !== null) {
        return $company;
    }

    $parent = function_exists('ticinoweb_get_contact_info') ? ticinoweb_get_contact_info() : array();
    $s      = cfs_group('cfs_settings');
    $opt    = function ($key) {
        return trim((string) get_option('ticinoweb_contact_' . $key, ''));
    };

    $phone_raw = $opt('phone');
    $phone     = $opt('phone_display') ?: $phone_raw;

    // Indirizzo principale: "Via X 1, 6900 Lugano – Casella Postale 5" → pezzi per i dati strutturati.
    $address = $opt('address');
    $street = $postal = $city = '';
    if (preg_match('/^(.*?),\s*(\d{4})\s+([^–\-]+?)(?:\s+[–\-].*)?$/u', $address, $m)) {
        list(, $street, $postal, $city) = $m;
    } else {
        $street = $address;
    }

    $company = array(
        'name'          => $s['company_name'] ?? get_bloginfo('name'),
        'legal_name'    => $s['legal_name'] ?? '',
        'address'       => $address,
        'street'        => $street,
        'postal_code'   => $postal,
        'city'          => $city,
        'country'       => 'CH',
        'legal_label'   => $opt('address_label'),
        'address_2'     => $opt('address_2'),
        'op_label'      => $opt('address_2_label'),
        'phone'         => $phone,
        'phone_href'    => cfs_tel_href($phone_raw ?: $phone),
        'email'         => $parent['email'] ?? $opt('email'),
        'vat'           => $opt('vat'),
        'map_url'       => $opt('map_url'),
        'facebook'      => $parent['facebook'] ?? $opt('facebook'),
        'linkedin'      => $parent['linkedin'] ?? $opt('linkedin'),
        'instagram'     => $parent['instagram'] ?? $opt('instagram'),
    );

    return $company;
}

/**
 * ID dell'allegato del logo impostato in ticinoWEB CMS (0 se manca o non è nella Libreria).
 */
function cfs_site_logo_id()
{
    $url = function_exists('ticinoweb_get_site_logo') ? ticinoweb_get_site_logo() : '';
    return $url ? (int) attachment_url_to_postid($url) : 0;
}

/**
 * Le due sedi (principale e seconda) già formattate, dal CMS del parent.
 */
function cfs_company_addresses()
{
    $c = cfs_company();

    return array(
        'legal' => array(
            'label'     => $c['legal_label'],
            'formatted' => $c['address'],
        ),
        'operational' => array(
            'label'     => $c['op_label'],
            'formatted' => $c['address_2'],
        ),
    );
}

/**
 * Orari di apertura dal CMS del parent: una riga per giorno, solo se il sito
 * li ha davvero compilati (tutti i giorni "chiuso" = non configurati).
 */
function cfs_opening_hours_lines()
{
    $hours = get_option('ticinoweb_contact_opening_hours', array());
    if (!is_array($hours) || !function_exists('ticinoweb_format_day_hours')) {
        return array();
    }
    $days = array(
        'monday' => __('Lunedì', 'capoferrisagl'), 'tuesday' => __('Martedì', 'capoferrisagl'),
        'wednesday' => __('Mercoledì', 'capoferrisagl'), 'thursday' => __('Giovedì', 'capoferrisagl'),
        'friday' => __('Venerdì', 'capoferrisagl'), 'saturday' => __('Sabato', 'capoferrisagl'),
        'sunday' => __('Domenica', 'capoferrisagl'),
    );
    $lines = array();
    $any_open = false;
    foreach ($days as $key => $label) {
        if (empty($hours[$key])) {
            continue;
        }
        if (empty($hours[$key]['closed'])) {
            $any_open = true;
        }
        $lines[] = $label . ': ' . ticinoweb_format_day_hours($hours[$key]);
    }
    return $any_open ? $lines : array();
}

/* ─────────────────────────────────────────────
   SERVIZI
   ───────────────────────────────────────────── */

/**
 * Servizi pubblicati, ordinati come nel backend.
 *
 * @param int $limit -1 per tutti.
 * @param array $include ID specifici (mantiene l'ordine passato).
 */
function cfs_get_services($limit = -1, $include = array())
{
    $args = array(
        'post_type'      => 'cfs_servizio',
        'post_status'    => 'publish',
        'posts_per_page' => $limit,
        'orderby'        => 'menu_order title',
        'order'          => 'ASC',
        'no_found_rows'  => true,
    );

    $include = array_filter(array_map('absint', (array) $include));
    if ($include) {
        $args['post__in'] = $include;
        $args['orderby']  = 'post__in';
        unset($args['order']);
    }

    return get_posts($args);
}

/**
 * Meta di un servizio con prefisso _cfs_.
 */
function cfs_service_meta($post_id, $key, $default = '')
{
    $value = get_post_meta($post_id, '_cfs_' . $key, true);
    if ($value === '' || $value === null || $value === array()) {
        return $default;
    }
    return $value;
}

/**
 * Copertina del servizio: immagine dedicata o featured image.
 */
function cfs_service_cover($post_id)
{
    $cover = (int) cfs_service_meta($post_id, 'cover_desktop', 0);
    if (!$cover) {
        $cover = (int) get_post_thumbnail_id($post_id);
    }
    return $cover;
}

/**
 * Galleria del servizio come array di ID.
 */
function cfs_service_gallery($post_id)
{
    $ids = cfs_service_meta($post_id, 'gallery', '');
    if (is_array($ids)) {
        $ids = implode(',', $ids);
    }
    $ids = array_filter(array_map('absint', explode(',', (string) $ids)));
    return array_values($ids);
}
