<?php
/**
 * Home page. Tutti i contenuti arrivano da ticinoWEB CMS → Home.
 *
 * @package Capoferrisagl
 */

get_header();

$hero    = cfs_home('hero', array());
$company = cfs_company();
?>

<section class="cfs-hero cfs-hero--home cfs-hero--<?php echo esc_attr($hero['position'] ?? 'left'); ?>" data-technical-section>
    <div class="cfs-hero__media" aria-hidden="true">
        <?php
        $hero_desktop = (int) ($hero['image'] ?? 0);
        $hero_mobile  = (int) ($hero['image_mobile'] ?? 0);
        $focal        = cfs_focal($hero['focal'] ?? '');

        if (!empty($hero['video_enabled']) && $hero['video_enabled'] === '1' && !empty($hero['video'])) :
            $poster = cfs_image((int) ($hero['video_poster'] ?? 0), 'cfs-hero');
            ?>
            <video class="cfs-hero__video" data-hero-video autoplay muted loop playsinline preload="auto" disablepictureinpicture
                   <?php echo $poster ? 'poster="' . esc_url($poster['url']) . '"' : ''; ?>
                   style="object-position:<?php echo esc_attr($focal); ?>">
                <source src="<?php echo esc_url($hero['video']); ?>" type="video/mp4">
            </video>
        <?php elseif ($hero_desktop) : ?>
            <picture>
                <?php if ($hero_mobile) :
                    $mobile = cfs_image($hero_mobile, 'cfs-portrait'); ?>
                    <source media="(max-width: 767px)" srcset="<?php echo esc_url($mobile['url']); ?>">
                <?php endif; ?>
                <?php cfs_the_image($hero_desktop, 'cfs-hero', array(
                    'class'   => 'cfs-hero__img',
                    'loading' => 'eager',
                    'fetchpriority' => 'high',
                    'focal'   => $focal,
                    'alt'     => $hero['alt'] ?? '',
                )); ?>
            </picture>
        <?php endif; ?>
        <span class="cfs-hero__scrim"></span>
        <span class="cfs-hero__flow" data-hero-flow></span>
        <?php cfs_technical_line('hero'); ?>
    </div>

    <div class="cfs-container cfs-hero__content">
        <?php if (!empty($hero['label'])) : ?>
            <p class="cfs-eyebrow cfs-eyebrow--light" data-hero-item>
                <span class="cfs-eyebrow__mark" aria-hidden="true"></span><?php echo esc_html($hero['label']); ?>
            </p>
        <?php endif; ?>

        <?php if (!empty($hero['title'])) : ?>
            <div class="cfs-hero__title-wrap">
                <h1 class="cfs-hero__title" data-hero-title><?php echo nl2br(esc_html($hero['title'])); ?></h1>
                <svg class="cfs-hero__underline" data-hero-underline viewBox="0 0 320 26" fill="none" preserveAspectRatio="none" aria-hidden="true">
                    <path d="M5,16 C90,10 230,9 316,13" stroke="currentColor" stroke-width="4" stroke-linecap="round"/>
                </svg>
            </div>
        <?php endif; ?>

        <?php if (!empty($hero['subtitle'])) : ?>
            <p class="cfs-hero__subtitle" data-hero-item><?php echo esc_html($hero['subtitle']); ?></p>
        <?php endif; ?>

        <?php if (!empty($hero['text'])) : ?>
            <div class="cfs-hero__text" data-hero-item><?php cfs_paragraphs($hero['text']); ?></div>
        <?php endif; ?>

        <div class="cfs-hero__actions" data-hero-item>
            <?php cfs_the_button($hero['btn1_text'] ?? '', $hero['btn1_url'] ?? '', 'cfs-btn cfs-btn--primary'); ?>
            <?php cfs_the_button($hero['btn2_text'] ?? '', $hero['btn2_url'] ?? '', 'cfs-btn cfs-btn--outline'); ?>
        </div>

        <?php if (!empty($hero['caption'])) : ?>
            <p class="cfs-hero__caption"><?php echo esc_html($hero['caption']); ?></p>
        <?php endif; ?>
    </div>

    <?php
    $badge = array_key_exists('badge', $hero) ? (string) $hero['badge'] : 'Picchetto attivo 7/7 · 24H';
    if ($badge !== '') :
        $badge_tag  = !empty($company['phone_href']) ? 'a' : 'span';
        $badge_href = $badge_tag === 'a' ? ' href="' . esc_url($company['phone_href']) . '"' : '';
        ?>
        <<?php echo $badge_tag . $badge_href; ?> class="cfs-hero__badge" data-hero-item>
            <span class="cfs-hero__badge-dot" aria-hidden="true"></span>
            <span class="cfs-hero__badge-text"><?php echo esc_html($badge); ?></span>
        </<?php echo $badge_tag; ?>>
    <?php endif; ?>

    <?php if (!empty($hero['scroll_hint'])) : ?>
        <a class="cfs-hero__scroll" href="#cfs-after-hero" aria-label="<?php esc_attr_e('Scorri per scoprire di più', 'capoferrisagl'); ?>">
            <span><?php echo esc_html($hero['scroll_hint']); ?></span>
            <span class="cfs-hero__scroll-line" aria-hidden="true"></span>
        </a>
    <?php endif; ?>
</section>

<span id="cfs-after-hero" tabindex="-1" aria-hidden="true"></span>

<?php
/* ── Striscia scorrevole: i servizi pubblicati ── */
$marquee_services = cfs_get_services();
if ($marquee_services) : ?>
    <div class="cfs-marquee" aria-hidden="true">
        <div class="cfs-marquee__track" data-marquee>
            <?php for ($copy = 0; $copy < 2; $copy++) : ?>
                <div class="cfs-marquee__group">
                    <?php foreach ($marquee_services as $service) : ?>
                        <span class="cfs-marquee__item"><?php echo esc_html($service->post_title); ?></span>
                    <?php endforeach; ?>
                </div>
            <?php endfor; ?>
        </div>
    </div>
<?php endif; ?>

<?php
/* ── Banner in evidenza (messaggio pubblicitario) ── */
$promo = cfs_home('promo', array());
if (($promo['enabled'] ?? '1') === '1' && !empty($promo['title'])) : ?>
    <section class="cfs-promo" data-reveal="text">
        <div class="cfs-container cfs-promo__inner">
            <div class="cfs-promo__text">
                <?php if (!empty($promo['label'])) : ?>
                    <p class="cfs-eyebrow cfs-eyebrow--light"><span class="cfs-eyebrow__mark" aria-hidden="true"></span><?php echo esc_html($promo['label']); ?></p>
                <?php endif; ?>
                <h2 class="cfs-promo__title"><?php echo esc_html($promo['title']); ?></h2>
                <?php if (!empty($promo['text'])) : ?>
                    <p class="cfs-promo__desc"><?php echo esc_html($promo['text']); ?></p>
                <?php endif; ?>
            </div>
            <?php cfs_the_button($promo['btn_text'] ?? '', $promo['btn_url'] ?? '', 'cfs-btn cfs-btn--primary'); ?>
        </div>
    </section>
<?php endif; ?>

<?php
/* ── Presentazione ───────────────────────────── */
$intro = cfs_home('intro', array());
if (cfs_section_enabled('cfs_home', 'intro') && (!empty($intro['title']) || !empty($intro['text']))) :
    $intro_has_media = !empty($intro['image']); ?>
    <section class="cfs-intro<?php echo $intro_has_media ? '' : ' cfs-intro--text'; ?>">
        <div class="cfs-container cfs-intro__grid">
            <div class="cfs-intro__text">
                <?php cfs_section_header($intro['label'] ?? '', $intro['title'] ?? '', ''); ?>
                <div class="cfs-prose" data-reveal="text"><?php cfs_paragraphs($intro['text'] ?? ''); ?></div>
                <?php if (!empty($intro['btn_text']) && !empty($intro['btn_url'])) : ?>
                    <a class="cfs-arrow-link" href="<?php echo esc_url($intro['btn_url']); ?>">
                        <span><?php echo esc_html($intro['btn_text']); ?></span>
                        <span class="cfs-arrow-link__icon" aria-hidden="true">
                            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.9"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
                        </span>
                    </a>
                <?php endif; ?>
                <?php cfs_render_strengths($intro['strengths'] ?? array(), 'cfs-strengths cfs-strengths--inline'); ?>
            </div>

            <?php if (!empty($intro['image'])) : ?>
                <figure class="cfs-intro__media" data-reveal="image">
                    <?php cfs_the_image((int) $intro['image'], 'large', array(
                        'class' => 'cfs-intro__img',
                        'alt'   => $intro['alt'] ?? '',
                    )); ?>
                    <?php if (!empty($intro['caption'])) : ?>
                        <figcaption><?php echo esc_html($intro['caption']); ?></figcaption>
                    <?php endif; ?>
                    <span class="cfs-tech-frame" aria-hidden="true"></span>
                </figure>
            <?php endif; ?>
        </div>
    </section>
<?php endif; ?>

<?php
/* ── Servizi ─────────────────────────────────── */
$services_cfg = cfs_home('services', array());
if (cfs_section_enabled('cfs_home', 'services')) :
    $selected = $services_cfg['items'] ?? array();
    $limit    = (int) ($services_cfg['limit'] ?? 0);
    $services = cfs_get_services(-1, $selected);
    if (!$services) {
        $services = cfs_get_services($limit > 0 ? $limit : -1);
    } elseif ($limit > 0) {
        $services = array_slice($services, 0, $limit);
    }

    if ($services) : ?>
        <section class="cfs-showcase" id="servizi">
            <div class="cfs-container">
                <?php cfs_section_header($services_cfg['label'] ?? '', $services_cfg['title'] ?? '', $services_cfg['text'] ?? ''); ?>

                <div class="cfs-showcase__grid" data-showcase>
                    <div class="cfs-showcase__visual" aria-hidden="true">
                        <div class="cfs-showcase__stack">
                            <?php foreach ($services as $index => $service) :
                                $cover = cfs_service_cover($service->ID);
                                if (!$cover) {
                                    continue;
                                } ?>
                                <figure class="cfs-showcase__media<?php echo $index === 0 ? ' is-active' : ''; ?>" data-media="<?php echo esc_attr($index); ?>">
                                    <?php cfs_the_image($cover, 'cfs-card', array(
                                        'class' => 'cfs-showcase__img',
                                        'focal' => cfs_focal(cfs_service_meta($service->ID, 'cover_focal', '')),
                                        'alt'   => '',
                                    )); ?>
                                </figure>
                            <?php endforeach; ?>
                            <span class="cfs-showcase__frame" aria-hidden="true"></span>
                        </div>
                    </div>

                    <ol class="cfs-showcase__list">
                        <?php foreach ($services as $index => $service) :
                            $cover = cfs_service_cover($service->ID); ?>
                            <li class="cfs-showcase__item" data-item="<?php echo esc_attr($index); ?>">
                                <a class="cfs-showcase__link" href="<?php echo esc_url(get_permalink($service->ID)); ?>">
                                    <span class="cfs-showcase__num" aria-hidden="true"><?php echo esc_html(str_pad((string) ($index + 1), 2, '0', STR_PAD_LEFT)); ?></span>
                                    <span class="cfs-showcase__body">
                                        <span class="cfs-showcase__title"><?php echo esc_html($service->post_title); ?></span>
                                        <?php if (cfs_service_meta($service->ID, 'excerpt', '')) : ?>
                                            <span class="cfs-showcase__text"><?php echo esc_html(wp_trim_words(cfs_service_meta($service->ID, 'excerpt', ''), 22)); ?></span>
                                        <?php endif; ?>
                                    </span>
                                    <span class="cfs-showcase__arrow" aria-hidden="true">
                                        <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
                                    </span>
                                    <?php if ($cover) : ?>
                                        <span class="cfs-showcase__thumb" aria-hidden="true">
                                            <?php cfs_the_image($cover, 'cfs-thumb', array('alt' => '')); ?>
                                        </span>
                                    <?php endif; ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ol>
                </div>

                <div class="cfs-services__actions">
                    <?php cfs_the_button($services_cfg['btn_text'] ?? '', $services_cfg['btn_url'] ?? '', 'cfs-btn cfs-btn--outline'); ?>
                </div>
            </div>
        </section>
    <?php endif;
endif; ?>

<?php
/* ── Metodo di lavoro ────────────────────────── */
$method = cfs_home('method', array());
$steps  = cfs_rows($method['steps'] ?? array());
if (cfs_section_enabled('cfs_home', 'method') && $steps) : ?>
    <section class="cfs-method" data-work-process data-technical-section>
        <?php cfs_technical_line('dark'); ?>
        <div class="cfs-container">
            <?php cfs_section_header($method['label'] ?? '', $method['title'] ?? '', $method['text'] ?? ''); ?>
            <ol class="cfs-method__list">
                <?php foreach ($steps as $index => $step) : ?>
                    <li class="cfs-method__step" data-process-step data-reveal="text">
                        <span class="cfs-method__num" aria-hidden="true"><?php echo esc_html(str_pad((string) ($index + 1), 2, '0', STR_PAD_LEFT)); ?></span>
                        <?php if (!empty($step['icon'])) : ?>
                            <span class="cfs-method__icon"><?php cfs_the_image((int) $step['icon'], 'cfs-thumb', array('alt' => '')); ?></span>
                        <?php endif; ?>
                        <h3 class="cfs-method__title"><?php echo esc_html($step['title'] ?? ''); ?></h3>
                        <?php if (!empty($step['text'])) : ?>
                            <p class="cfs-method__text"><?php echo esc_html($step['text']); ?></p>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ol>
        </div>
    </section>
<?php endif; ?>

<?php
/* ── Galleria lavori: gestita dalla media-gallery "Galleria home" ──── */
$gallery_cfg = cfs_home('gallery', array());
if (cfs_section_enabled('cfs_home', 'gallery')) :
    $images = get_posts(array(
        'post_type'      => 'attachment',
        'post_mime_type' => 'image',
        'posts_per_page' => 30,
        'orderby'        => array('menu_order' => 'ASC', 'date' => 'ASC'),
        'fields'         => 'ids',
        'tax_query'      => array(array(
            'taxonomy' => 'ticinoweb_media_gallery',
            'field'    => 'slug',
            'terms'    => 'galleria-home',
        )),
    ));
    // Fallback: se la galleria media è vuota, usa le immagini dei servizi.
    if (!$images) {
        $images = array();
        foreach (cfs_get_services() as $service) {
            $images = array_merge($images, cfs_service_gallery($service->ID));
        }
        $images = array_slice(array_unique($images), 0, 12);
    }
    if ($images) {
        cfs_render_gallery(
            $images,
            $gallery_cfg['title'] ?? '',
            $gallery_cfg['text'] ?? '',
            $gallery_cfg['label'] ?? ''
        );
    }
endif; ?>

<?php
/* ── Call to action finale ───────────────────── */
if (cfs_section_enabled('cfs_home', 'cta')) {
    cfs_render_cta(cfs_home('cta', array()));
}
?>

<?php get_footer(); ?>
