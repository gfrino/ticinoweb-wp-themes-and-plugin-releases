<?php
/**
 * Template Name: Contatti
 *
 * @package Capoferrisagl
 */

get_header();

$hero    = cfs_contact('hero', array());
$info    = cfs_contact('info', array());
$map     = cfs_contact('map', array());
$form    = cfs_contact('form', array());
$company = cfs_company();
$hours   = cfs_opening_hours_lines();
?>

<header class="cfs-hero cfs-hero--page">
    <div class="cfs-hero__media" aria-hidden="true">
        <?php
        $img    = (int) ($hero['image'] ?? 0);
        $mobile = (int) ($hero['image_mobile'] ?? 0);
        if ($img) : ?>
            <picture>
                <?php if ($mobile) :
                    $m = cfs_image($mobile, 'cfs-portrait'); ?>
                    <source media="(max-width: 767px)" srcset="<?php echo esc_url($m['url']); ?>">
                <?php endif; ?>
                <?php cfs_the_image($img, 'cfs-hero', array(
                    'class'         => 'cfs-hero__img',
                    'loading'       => 'eager',
                    'fetchpriority' => 'high',
                    'focal'         => cfs_focal($hero['focal'] ?? ''),
                    'alt'           => $hero['alt'] ?? '',
                )); ?>
            </picture>
        <?php endif; ?>
        <span class="cfs-hero__scrim"></span>
    </div>

    <div class="cfs-container cfs-hero__content">
        <?php cfs_the_breadcrumb(array(array('label' => get_the_title()))); ?>
        <?php if (!empty($hero['label'])) : ?>
            <p class="cfs-eyebrow cfs-eyebrow--light" data-hero-item><span class="cfs-eyebrow__mark" aria-hidden="true"></span><?php echo esc_html($hero['label']); ?></p>
        <?php endif; ?>
        <h1 class="cfs-hero__title cfs-hero__title--page" data-hero-title><?php echo esc_html($hero['title'] ?? get_the_title()); ?></h1>
        <?php if (!empty($hero['intro'])) : ?>
            <div class="cfs-hero__text" data-hero-item><?php cfs_paragraphs($hero['intro']); ?></div>
        <?php endif; ?>
    </div>
</header>

<section class="cfs-contact">
    <div class="cfs-container cfs-contact__grid">

        <div class="cfs-contact__info" data-reveal="text">
            <ul class="cfs-contact__list">
                <?php if ($company['phone'] && $company['phone_href']) : ?>
                    <li>
                        <span class="cfs-contact__label"><?php esc_html_e('Telefono', 'capoferrisagl'); ?></span>
                        <a class="cfs-contact__value" href="<?php echo esc_url($company['phone_href']); ?>"><?php echo esc_html($company['phone']); ?></a>
                    </li>
                <?php endif; ?>

                <?php if ($company['email']) : ?>
                    <li>
                        <span class="cfs-contact__label"><?php esc_html_e('Email', 'capoferrisagl'); ?></span>
                        <a class="cfs-contact__value" href="mailto:<?php echo esc_attr($company['email']); ?>"><?php echo esc_html($company['email']); ?></a>
                    </li>
                <?php endif; ?>

                <?php $addrs = cfs_company_addresses(); ?>
                <li>
                    <span class="cfs-contact__label"><?php esc_html_e('Indirizzi', 'capoferrisagl'); ?></span>
                    <address class="cfs-contact__value cfs-contact__addresses">
                        <?php if ($company['legal_name']) : ?>
                            <div class="cfs-contact__company-name"><?php echo esc_html($company['legal_name']); ?></div>
                        <?php endif; ?>

                        <div class="cfs-contact__addr-block">
                            <span class="cfs-contact__addr-type"><?php echo esc_html($addrs['legal']['label']); ?>:</span>
                            <span class="cfs-contact__addr-detail"><?php echo esc_html($addrs['legal']['formatted']); ?></span>
                        </div>

                        <div class="cfs-contact__addr-block">
                            <span class="cfs-contact__addr-type"><?php echo esc_html($addrs['operational']['label']); ?>:</span>
                            <span class="cfs-contact__addr-detail"><?php echo esc_html($addrs['operational']['formatted']); ?></span>
                        </div>
                    </address>
                    <?php if ($company['map_url']) : ?>
                        <a class="cfs-contact__maplink" href="<?php echo esc_url($company['map_url']); ?>" target="_blank" rel="noopener"><?php esc_html_e('Apri nella mappa', 'capoferrisagl'); ?></a>
                    <?php endif; ?>
                </li>

                <?php if ($hours) : ?>
                    <li>
                        <span class="cfs-contact__label"><?php echo esc_html($info['hours_title'] ?? __('Orari', 'capoferrisagl')); ?></span>
                        <ul class="cfs-contact__hours">
                            <?php foreach ($hours as $line) : ?>
                                <li><?php echo esc_html($line); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>

            <?php if (!empty($info['note'])) : ?>
                <div class="cfs-contact__note"><?php cfs_paragraphs($info['note']); ?></div>
            <?php endif; ?>

            <?php if (!empty($hero['image'])) : ?>
                <figure class="cfs-contact__photo" data-reveal="image">
                    <?php cfs_the_image((int) $hero['image'], 'cfs-card', array('alt' => $hero['alt'] ?? '')); ?>
                </figure>
            <?php endif; ?>
        </div>

        <div class="cfs-contact__form" id="scrivici" data-reveal="text">
            <?php if (!empty($form['title'])) : ?>
                <h2 class="cfs-section-title"><?php echo esc_html($form['title']); ?></h2>
            <?php endif; ?>
            <?php if (!empty($form['text'])) : ?>
                <div class="cfs-prose"><?php cfs_paragraphs($form['text']); ?></div>
            <?php endif; ?>
            <?php cfs_render_contact_form(); ?>
        </div>
    </div>
</section>

<?php if (($map['enabled'] ?? '1') === '1' && !empty($map['embed'])) : ?>
    <section class="cfs-map">
        <iframe
            src="<?php echo esc_url($map['embed']); ?>"
            title="<?php echo esc_attr($map['title'] ?? __('Mappa della sede', 'capoferrisagl')); ?>"
            loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"></iframe>
    </section>
<?php endif; ?>

<?php get_footer(); ?>
