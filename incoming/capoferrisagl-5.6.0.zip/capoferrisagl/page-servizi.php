<?php
/**
 * Template Name: Servizi
 *
 * Elenco editoriale dei servizi. Testi dalla pagina Home → sezione Servizi
 * e dai singoli servizi.
 *
 * @package Capoferrisagl
 */

get_header();

$hero     = cfs_servizi('hero', array());
$intro    = cfs_servizi('intro', array());
$services = cfs_get_services();
$img      = (int) ($hero['image'] ?? 0);
$mobile   = (int) ($hero['image_mobile'] ?? 0);
?>

<header class="cfs-hero cfs-hero--page">
    <div class="cfs-hero__media" aria-hidden="true">
        <?php if ($img) : ?>
            <picture>
                <?php if ($mobile) :
                    $m = cfs_image($mobile, 'cfs-portrait'); ?>
                    <source media="(max-width: 767px)" srcset="<?php echo esc_url($m['url']); ?>">
                <?php endif; ?>
                <?php cfs_the_image($img, 'cfs-hero', array(
                    'class'         => 'cfs-hero__img',
                    'loading'       => 'eager',
                    'fetchpriority' => 'high',
                    'focal'         => cfs_focal($hero['focal'] ?? ''),
                    'alt'           => $hero['alt'] ?? '',
                )); ?>
            </picture>
        <?php endif; ?>
        <span class="cfs-hero__scrim"></span>
    </div>
    <div class="cfs-container cfs-hero__content">
        <?php cfs_the_breadcrumb(array(array('label' => get_the_title()))); ?>
        <?php if (!empty($hero['label'])) : ?>
            <p class="cfs-eyebrow cfs-eyebrow--light" data-hero-item><span class="cfs-eyebrow__mark" aria-hidden="true"></span><?php echo esc_html($hero['label']); ?></p>
        <?php endif; ?>
        <h1 class="cfs-hero__title cfs-hero__title--page" data-hero-title><?php echo esc_html(!empty($hero['title']) ? $hero['title'] : get_the_title()); ?></h1>
        <?php if (!empty($hero['intro'])) : ?>
            <div class="cfs-hero__text" data-hero-item><?php cfs_paragraphs($hero['intro']); ?></div>
        <?php endif; ?>
    </div>
</header>

<?php if (!empty($intro['text'])) : ?>
    <section class="cfs-page-intro">
        <div class="cfs-container cfs-prose" data-reveal="text">
            <?php cfs_paragraphs($intro['text']); ?>
        </div>
    </section>
<?php endif; ?>

<?php if ($services) : ?>
    <section class="cfs-services cfs-services--list">
        <div class="cfs-container">
            <div class="cfs-services__editorial">
                <?php foreach ($services as $index => $service) :
                    $cover = cfs_service_cover($service->ID);
                    $side  = $index % 2 === 0 ? 'left' : 'right'; ?>
                    <article class="cfs-service-row cfs-service-row--<?php echo esc_attr($side); ?>" data-reveal="text">
                        <a class="cfs-service-row__media" href="<?php echo esc_url(get_permalink($service->ID)); ?>" tabindex="-1" aria-hidden="true">
                            <?php if ($cover) : ?>
                                <?php cfs_the_image($cover, 'cfs-card', array(
                                    'class' => 'cfs-service-row__img',
                                    'focal' => cfs_focal(cfs_service_meta($service->ID, 'cover_focal', '')),
                                    'alt'   => '',
                                )); ?>
                            <?php endif; ?>
                        </a>
                        <div class="cfs-service-row__body">
                            <span class="cfs-service-row__index" aria-hidden="true"><?php echo esc_html(str_pad((string) ($index + 1), 2, '0', STR_PAD_LEFT)); ?></span>
                            <h2 class="cfs-service-row__title">
                                <a href="<?php echo esc_url(get_permalink($service->ID)); ?>"><?php echo esc_html($service->post_title); ?></a>
                            </h2>
                            <?php if (cfs_service_meta($service->ID, 'excerpt', '')) : ?>
                                <p class="cfs-service-row__text"><?php echo esc_html(cfs_service_meta($service->ID, 'excerpt', '')); ?></p>
                            <?php endif; ?>
                            <span class="cfs-service-row__cta" aria-hidden="true">
                                <?php esc_html_e('Scopri il servizio', 'capoferrisagl'); ?>
                                <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
                            </span>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
<?php else : ?>
    <section class="cfs-services">
        <div class="cfs-container">
            <p class="cfs-prose"><?php esc_html_e('I servizi saranno disponibili a breve.', 'capoferrisagl'); ?></p>
        </div>
    </section>
<?php endif; ?>

<?php cfs_render_cta(cfs_home('cta', array())); ?>

<?php get_footer(); ?>
