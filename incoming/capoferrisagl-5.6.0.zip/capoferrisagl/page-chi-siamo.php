<?php
/**
 * Template Name: Chi siamo
 *
 * @package Capoferrisagl
 */

get_header();

$hero = cfs_about('hero', array());
?>

<header class="cfs-hero cfs-hero--page">
    <div class="cfs-hero__media" aria-hidden="true">
        <?php
        $img    = (int) ($hero['image'] ?? 0);
        $mobile = (int) ($hero['image_mobile'] ?? 0);
        if ($img) : ?>
            <picture>
                <?php if ($mobile) :
                    $m = cfs_image($mobile, 'cfs-portrait'); ?>
                    <source media="(max-width: 767px)" srcset="<?php echo esc_url($m['url']); ?>">
                <?php endif; ?>
                <?php cfs_the_image($img, 'cfs-hero', array(
                    'class'         => 'cfs-hero__img',
                    'loading'       => 'eager',
                    'fetchpriority' => 'high',
                    'focal'         => cfs_focal($hero['focal'] ?? ''),
                    'alt'           => $hero['alt'] ?? '',
                )); ?>
            </picture>
        <?php endif; ?>
        <span class="cfs-hero__scrim"></span>
    </div>

    <div class="cfs-container cfs-hero__content">
        <?php cfs_the_breadcrumb(array(array('label' => get_the_title()))); ?>
        <?php if (!empty($hero['label'])) : ?>
            <p class="cfs-eyebrow cfs-eyebrow--light" data-hero-item><span class="cfs-eyebrow__mark" aria-hidden="true"></span><?php echo esc_html($hero['label']); ?></p>
        <?php endif; ?>
        <h1 class="cfs-hero__title cfs-hero__title--page" data-hero-title><?php echo esc_html($hero['title'] ?? get_the_title()); ?></h1>
        <?php if (!empty($hero['intro'])) : ?>
            <div class="cfs-hero__text" data-hero-item><?php cfs_paragraphs($hero['intro']); ?></div>
        <?php endif; ?>
    </div>
</header>

<?php
/* ── Introduzione ────────────────────────────── */
$intro = cfs_about('intro', array());
if (cfs_section_enabled('cfs_about', 'intro') && (!empty($intro['title']) || !empty($intro['text']))) : ?>
    <section class="cfs-about-intro">
        <div class="cfs-container cfs-about-intro__grid">
            <div class="cfs-about-intro__text">
                <?php if (!empty($intro['title'])) : ?>
                    <h2 class="cfs-section-title" data-split="lines"><?php echo esc_html($intro['title']); ?></h2>
                <?php endif; ?>
                <div class="cfs-prose" data-reveal="text"><?php cfs_paragraphs($intro['text'] ?? ''); ?></div>
            </div>
            <?php if (!empty($intro['image'])) : ?>
                <figure class="cfs-about-intro__media" data-reveal="image">
                    <?php /* Formato originale: la foto si vede intera, senza ritagli */
                    cfs_the_image((int) $intro['image'], 'large', array('alt' => $intro['alt'] ?? '')); ?>
                    <?php if (!empty($intro['caption'])) : ?>
                        <figcaption><?php echo esc_html($intro['caption']); ?></figcaption>
                    <?php endif; ?>
                    <span class="cfs-tech-frame" aria-hidden="true"></span>
                </figure>
            <?php endif; ?>
        </div>
    </section>
<?php endif; ?>

<?php
/* ── Storia ──────────────────────────────────── */
$story = cfs_about('story', array());
if (cfs_section_enabled('cfs_about', 'story') && !empty($story['text'])) :
    $story_images = array_filter(array_map('absint', explode(',', (string) ($story['gallery'] ?? ''))));
    $layout       = $story['layout'] ?? 'side'; ?>
    <section class="cfs-story cfs-story--<?php echo esc_attr($layout); ?>">
        <div class="cfs-container">
            <?php cfs_section_header($story['label'] ?? '', $story['title'] ?? '', ''); ?>
            <div class="cfs-story__grid">
                <div class="cfs-prose cfs-story__text" data-reveal="text"><?php cfs_paragraphs($story['text']); ?></div>
                <?php if ($story_images) : ?>
                    <div class="cfs-story__media">
                        <?php foreach (array_slice($story_images, 0, 1) as $image_id) : ?>
                            <figure data-reveal="image"><?php cfs_the_image($image_id, 'large'); ?></figure>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php
/* ── Timeline ────────────────────────────────── */
$timeline = cfs_about('timeline', array());
$steps    = cfs_rows($timeline['items'] ?? array());
if (cfs_section_enabled('cfs_about', 'timeline') && $steps) : ?>
    <section class="cfs-timeline">
        <div class="cfs-container">
            <?php cfs_section_header('', $timeline['title'] ?? '', $timeline['text'] ?? ''); ?>
            <ol class="cfs-timeline__list" data-history-timeline>
                <span class="cfs-timeline__rail" aria-hidden="true"><span data-timeline-progress></span></span>
                <?php foreach ($steps as $step) : ?>
                    <li class="cfs-timeline__item" data-history-item>
                        <?php if (!empty($step['year'])) : ?>
                            <span class="cfs-timeline__year"><?php echo esc_html($step['year']); ?></span>
                        <?php endif; ?>
                        <div class="cfs-timeline__body" data-history-body>
                            <?php if (!empty($step['title'])) : ?>
                                <h3><?php echo esc_html($step['title']); ?></h3>
                            <?php endif; ?>
                            <?php if (!empty($step['text'])) : ?>
                                <p><?php echo esc_html($step['text']); ?></p>
                            <?php endif; ?>
                            <?php if (!empty($step['image'])) : ?>
                                <figure><?php cfs_the_image((int) $step['image'], 'cfs-card', array('alt' => $step['alt'] ?? '')); ?></figure>
                            <?php endif; ?>
                        </div>
                    </li>
                <?php endforeach; ?>
            </ol>
        </div>
    </section>
<?php endif; ?>

<?php
/* ── Valori ──────────────────────────────────── */
$values = cfs_about('values', array());
$items  = cfs_rows($values['items'] ?? array());
if (cfs_section_enabled('cfs_about', 'values') && $items) : ?>
    <section class="cfs-values">
        <div class="cfs-container">
            <?php cfs_section_header('', $values['title'] ?? '', $values['text'] ?? ''); ?>
            <?php cfs_render_strengths($items, 'cfs-strengths cfs-strengths--grid'); ?>
        </div>
    </section>
<?php endif; ?>

<?php
/* ── Citazione ───────────────────────────────── */
$quote = cfs_about('quote', array());
if (cfs_section_enabled('cfs_about', 'quote') && !empty($quote['text'])) : ?>
    <section class="cfs-quote">
        <div class="cfs-container cfs-quote__inner" data-reveal="text">
            <svg class="cfs-quote__mark" viewBox="0 0 24 24" width="42" height="42" fill="currentColor" aria-hidden="true"><path d="M7 7h5v5c0 3-2 5-5 5V14c1 0 2-.7 2-2H7V7Zm8 0h5v5c0 3-2 5-5 5V14c1 0 2-.7 2-2h-2V7Z"/></svg>
            <blockquote>
                <p><?php echo esc_html($quote['text']); ?></p>
                <?php if (!empty($quote['author'])) : ?>
                    <cite>
                        <?php echo esc_html($quote['author']); ?>
                        <?php if (!empty($quote['role'])) : ?>
                            <span><?php echo esc_html($quote['role']); ?></span>
                        <?php endif; ?>
                    </cite>
                <?php endif; ?>
            </blockquote>
        </div>
    </section>
<?php endif; ?>

<?php
if (cfs_section_enabled('cfs_about', 'cta')) {
    cfs_render_cta(cfs_about('cta', array()));
}
?>

<?php get_footer(); ?>
