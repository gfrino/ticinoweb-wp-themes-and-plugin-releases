<?php
/**
 * Capoferri SA — child theme di ticinoweb-ai-theme.
 *
 * @package Capoferrisagl
 * @version 5.4.3
 */

if (!defined('ABSPATH')) {
    exit;
}

define('CFS_DIR', get_stylesheet_directory());
define('CFS_URI', get_stylesheet_directory_uri());

/* ─────────────────────────────────────────────
   1. SETUP
   ───────────────────────────────────────────── */

add_action('after_setup_theme', 'cfs_setup');
function cfs_setup()
{
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('automatic-feed-links');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script'));

    register_nav_menus(array(
        'primary' => __('Menu Principale', 'capoferrisagl'),
        'footer'  => __('Menu Footer', 'capoferrisagl'),
    ));

    // Formati usati dai layout editoriali.
    add_image_size('cfs-hero', 2200, 1200, true);
    add_image_size('cfs-card', 900, 640, true);
    add_image_size('cfs-portrait', 900, 1200, true);
    add_image_size('cfs-thumb', 480, 360, true);
}

/* ─────────────────────────────────────────────
   2. INCLUDE
   ───────────────────────────────────────────── */

require_once CFS_DIR . '/inc/helpers.php';
require_once CFS_DIR . '/inc/admin-ui.php';
require_once CFS_DIR . '/inc/cpt-servizi.php';
require_once CFS_DIR . '/inc/admin-pages.php';
require_once CFS_DIR . '/inc/migrate-to-parent.php';
require_once CFS_DIR . '/inc/contact-form.php';
require_once CFS_DIR . '/inc/seo.php';
require_once CFS_DIR . '/inc/render.php';
require_once CFS_DIR . '/inc/setup-content.php';
require_once CFS_DIR . '/inc/content-transfer.php';

/* ─────────────────────────────────────────────
   3. ASSET FRONTEND
   ───────────────────────────────────────────── */

add_action('wp_enqueue_scripts', 'cfs_enqueue', 20);
function cfs_enqueue()
{
    $ver = wp_get_theme()->get('Version');

    wp_enqueue_style(
        'cfs-fonts',
        'https://fonts.googleapis.com/css2?family=Archivo:wght@500;600;700;800;900&family=Inter:wght@400;500;600&display=swap',
        array(),
        null
    );

    wp_enqueue_style('cfs-style', CFS_URI . '/assets/css/capoferrisagl.css', array('cfs-fonts'), $ver);

    // GSAP: file UMD ufficiali versionati nel tema (un solo metodo, nessuna CDN).
    $deps = cfs_enqueue_gsap();

    wp_enqueue_script('cfs-main', CFS_URI . '/assets/js/main.js', $deps, $ver, true);

    wp_localize_script('cfs-main', 'cfsData', array(
        'ajaxUrl'          => admin_url('admin-ajax.php'),
        'tokenAction'      => 'ticinoweb_form_token',
        'submitAction'     => 'ticinoweb_submit_form',
        'recaptchaSiteKey' => (string) get_option('ticinoweb_recaptcha_site_key', ''),
        'i18n'    => array(
            'closeLightbox' => __('Chiudi', 'capoferrisagl'),
            'prevImage'     => __('Immagine precedente', 'capoferrisagl'),
            'nextImage'     => __('Immagine successiva', 'capoferrisagl'),
        ),
    ));
}

/**
 * Registra e accoda i file GSAP necessari alla pagina corrente.
 *
 * Core, ScrollTrigger, CustomEase e SplitText servono ovunque (reveal e
 * titoli). Gli altri plugin vengono caricati solo dove hanno un uso reale.
 *
 * @return array Handle da usare come dipendenze dello script principale.
 */
function cfs_enqueue_gsap()
{
    $base = CFS_URI . '/assets/vendor/gsap/';
    $v    = '3.15.0';

    // Sempre: linguaggio di movimento di base del sito.
    $files = array(
        'gsap'              => array('gsap.min.js', array()),
        'gsap-scrolltrigger' => array('ScrollTrigger.min.js', array('gsap')),
        'gsap-customease'   => array('CustomEase.min.js', array('gsap')),
        'gsap-splittext'    => array('SplitText.min.js', array('gsap')),
        'gsap-scrollto'     => array('ScrollToPlugin.min.js', array('gsap')),
    );

    $is_home    = is_front_page();
    $is_about   = is_page_template('page-chi-siamo.php');
    $is_service = is_singular('cfs_servizio');
    $is_list    = is_page_template('page-servizi.php');

    // Smooth scroll: solo dove c'è una pagina lunga da percorrere.
    if ($is_home || $is_about || $is_service || $is_list || is_page_template('page-contatti.php')) {
        $files['gsap-scrollsmoother'] = array('ScrollSmoother.min.js', array('gsap', 'gsap-scrolltrigger'));
    }

    // Linee tecniche e indicatore di flusso: hero, metodo, timeline, CTA.
    if ($is_home || $is_about || $is_service) {
        $files['gsap-drawsvg']    = array('DrawSVGPlugin.min.js', array('gsap'));
        $files['gsap-motionpath'] = array('MotionPathPlugin.min.js', array('gsap'));
    }

    // Galleria e lightbox: Flip per l'apertura, Observer per lo swipe.
    if ($is_home || $is_service || $is_about) {
        $files['gsap-flip']     = array('Flip.min.js', array('gsap'));
        $files['gsap-observer'] = array('Observer.min.js', array('gsap'));
    }

    foreach ($files as $handle => $file) {
        wp_enqueue_script($handle, $base . $file[0], $file[1], $v, true);
    }

    return array_keys($files);
}

/** I moduli JS sono ES modules: caricali come type="module". */
add_filter('script_loader_tag', 'cfs_module_script', 10, 3);
function cfs_module_script($tag, $handle, $src)
{
    if ($handle === 'cfs-main') {
        return '<script type="module" src="' . esc_url($src) . '"></script>' . "\n";
    }
    return $tag;
}

/**
 * Cache-busting dei moduli ES.
 *
 * main.js viene versionato dall'enqueue, ma i suoi import statici (relativi)
 * non ereditano la query di versione: il browser potrebbe servirli dalla cache
 * dopo un aggiornamento. Una import map rimappa ogni modulo alla sua versione
 * corrente, così ogni bump del tema invalida davvero tutta la catena.
 */
add_action('wp_head', 'cfs_module_importmap', 1);
function cfs_module_importmap()
{
    if (is_admin()) {
        return;
    }

    $base_dir = CFS_DIR . '/assets/js';
    $base_uri = CFS_URI . '/assets/js';
    if (!is_dir($base_dir)) {
        return;
    }

    $ver = wp_get_theme()->get('Version');
    $map = array();

    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($base_dir, FilesystemIterator::SKIP_DOTS)
    );
    foreach ($iterator as $file) {
        if (strtolower($file->getExtension()) !== 'js') {
            continue;
        }
        $rel = str_replace('\\', '/', substr($file->getPathname(), strlen($base_dir)));
        // I file dell'admin non fanno parte della catena del frontend.
        if (strpos($rel, '/admin/') === 0) {
            continue;
        }
        $url = $base_uri . $rel;
        $map[$url] = add_query_arg('ver', $ver, $url);
    }

    if (!$map) {
        return;
    }

    echo '<script type="importmap">'
        . wp_json_encode(array('imports' => $map))
        . "</script>\n";
}

/* ─────────────────────────────────────────────
   4. TEMPLATE
   ───────────────────────────────────────────── */

/** Il singolo servizio usa il template dinamico unico. */
add_filter('single_template', 'cfs_single_template');
function cfs_single_template($template)
{
    if (is_singular('cfs_servizio')) {
        $custom = CFS_DIR . '/single-servizio.php';
        if (file_exists($custom)) {
            return $custom;
        }
    }
    return $template;
}

/**
 * Il parent reindirizza tutti i 404 alla home: qui serve invece una vera
 * pagina 404 (richiesta di progetto e buona pratica SEO).
 */
add_action('after_setup_theme', 'cfs_restore_404', 99);
function cfs_restore_404()
{
    remove_action('template_redirect', 'ticinoweb_redirect_404_to_home');
}

/**
 * Pulizia della barra laterale admin: nasconde le voci ridondanti del ticinoWEB
 * CMS ora che i contenuti si gestiscono dal menu "Capoferri". Nasconde soltanto
 * (non elimina) e non tocca il parent theme.
 */
add_action('admin_menu', 'cfs_clean_admin_menu', 999);
function cfs_clean_admin_menu()
{
    // "Gallerie media" resta disponibile: la galleria della home si gestisce da lì
    // (media-gallery "Galleria home"), senza codice.
}

/**
 * Inietta i servizi pubblicati come sottomenu della voce "Servizi" nel menu
 * principale (dropdown desktop + espandibile su mobile). Nessuna gestione
 * manuale: il sottomenu segue i servizi del CMS.
 */
add_filter('wp_nav_menu_objects', 'cfs_inject_services_submenu', 10, 2);
function cfs_inject_services_submenu($items, $args)
{
    if (empty($args->theme_location) || $args->theme_location !== 'primary') {
        return $items;
    }
    $servizi_id = cfs_page_id('servizi');
    if (!$servizi_id) {
        return $items;
    }

    $parent = null;
    foreach ($items as $item) {
        if ((int) $item->object_id === (int) $servizi_id) {
            $parent = $item;
            break;
        }
    }
    if (!$parent) {
        return $items;
    }

    $services = cfs_get_services();
    if (!$services) {
        return $items;
    }

    $parent->classes[] = 'menu-item-has-children';
    $parent->classes[] = 'cfs-has-sub';

    $uid = 900000;
    foreach ($services as $service) {
        $obj = (object) array(
            'ID'               => $uid,
            'db_id'            => $uid,
            'menu_item_parent' => (string) $parent->ID,
            'object_id'        => $service->ID,
            'object'           => 'cfs_servizio',
            'type'             => 'post_type',
            'type_label'       => 'Servizio',
            'title'            => $service->post_title,
            'url'              => get_permalink($service->ID),
            'target'           => '',
            'xfn'              => '',
            'attr_title'       => '',
            'description'      => '',
            'classes'          => array('cfs-nav__sub-item'),
            'current'          => false,
            'current_item_ancestor' => false,
            'current_item_parent'   => false,
        );
        $items[] = $obj;
        $uid++;
    }

    return $items;
}

/** Classi utili sul body. */
add_filter('body_class', 'cfs_body_class');
function cfs_body_class($classes)
{
    $classes[] = 'cfs';
    if (is_singular('cfs_servizio')) {
        $classes[] = 'cfs-service';
    }
    return $classes;
}

/* ─────────────────────────────────────────────
   5. PRESTAZIONI E SICUREZZA
   ───────────────────────────────────────────── */

/** Preload della copertina hero: migliora l'LCP. */
add_action('wp_head', 'cfs_preload_hero', 2);
function cfs_preload_hero()
{
    $image_id = 0;

    if (is_front_page()) {
        $image_id = (int) cfs_home('hero.image', 0);
    } elseif (is_singular('cfs_servizio')) {
        $image_id = cfs_service_cover(get_the_ID());
    }

    if (!$image_id) {
        return;
    }
    $src = wp_get_attachment_image_src($image_id, 'cfs-hero');
    if ($src) {
        printf('<link rel="preload" as="image" href="%s">' . "\n", esc_url($src[0]));
    }
}

/** Formati immagine accettati negli upload del sito. */
add_filter('upload_mimes', 'cfs_upload_mimes');
function cfs_upload_mimes($mimes)
{
    return array(
        'jpg|jpeg|jpe' => 'image/jpeg',
        'png'          => 'image/png',
        'webp'         => 'image/webp',
        'avif'         => 'image/avif',
        'pdf'          => 'application/pdf',
        'mp4'          => 'video/mp4',
    );
}

/** Avviso prima di eliminare un'immagine ancora usata nel sito. */
add_action('admin_notices', 'cfs_media_usage_notice');
function cfs_media_usage_notice()
{
    $screen = get_current_screen();
    if (!$screen || $screen->base !== 'upload') {
        return;
    }
    echo '<div class="notice notice-info"><p>' . esc_html__(
        'Prima di eliminare un\'immagine, verifica che non sia usata in un servizio o in una pagina: eliminandola potrebbe non essere più visibile nel sito.',
        'capoferrisagl'
    ) . '</p></div>';
}
