<?php
/**
 * Header del sito.
 *
 * @package Capoferrisagl
 */

$company  = cfs_company();
$logo     = cfs_site_logo_id();
$cta_text = cfs_settings('cta_text', '');
$cta_url  = cfs_settings('cta_url', '');
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script>
        /* Gli stati iniziali delle animazioni valgono solo se JavaScript è
           disponibile: così senza JS (o in caso di errore) nulla resta nascosto. */
        (function (d) {
            try {
                d.documentElement.className = d.documentElement.className.replace('no-js', 'js');
                if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
                    d.documentElement.classList.add('cfs-motion-off');
                }
            } catch (e) {}
        }(document));
    </script>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="cfs-skip" href="#cfs-main"><?php esc_html_e('Vai al contenuto principale', 'capoferrisagl'); ?></a>

<header class="cfs-header" data-header>
    <div class="cfs-header__inner">
        <a class="cfs-header__brand" href="<?php echo esc_url(home_url('/')); ?>" rel="home">
            <?php if ($logo) : ?>
                <?php cfs_the_image($logo, 'large', array('class' => 'cfs-header__logo', 'loading' => 'eager', 'fetchpriority' => 'high', 'alt' => $company['name'])); ?>
            <?php else : ?>
                <span class="cfs-header__name"><?php echo esc_html($company['name']); ?></span>
            <?php endif; ?>
        </a>

        <nav class="cfs-nav" aria-label="<?php esc_attr_e('Menu principale', 'capoferrisagl'); ?>">
            <?php
            wp_nav_menu(array(
                'theme_location' => 'primary',
                'container'      => false,
                'menu_class'     => 'cfs-nav__list',
                'depth'          => 0,
                'fallback_cb'    => false,
            ));
            ?>
        </nav>

        <div class="cfs-header__actions">
            <?php cfs_the_button($cta_text, $cta_url, 'cfs-btn cfs-btn--primary cfs-btn--sm cfs-header__cta'); ?>
            <button type="button" class="cfs-burger" data-menu-toggle
                    aria-expanded="false" aria-controls="cfs-mobile-menu">
                <span class="cfs-burger__lines" aria-hidden="true"><span></span><span></span></span>
                <span class="screen-reader-text"><?php esc_html_e('Apri il menu', 'capoferrisagl'); ?></span>
            </button>
        </div>
    </div>
    <span class="cfs-header__progress" aria-hidden="true" data-scroll-progress></span>
</header>

<div class="cfs-mobile-menu" id="cfs-mobile-menu" data-mobile-menu hidden>
    <div class="cfs-mobile-menu__inner">
        <nav aria-label="<?php esc_attr_e('Menu principale (mobile)', 'capoferrisagl'); ?>">
            <?php
            wp_nav_menu(array(
                'theme_location' => 'primary',
                'container'      => false,
                'menu_class'     => 'cfs-mobile-menu__list',
                'depth'          => 0,
                'fallback_cb'    => false,
            ));
            ?>
        </nav>
        <div class="cfs-mobile-menu__foot">
            <?php cfs_the_button($cta_text, $cta_url, 'cfs-btn cfs-btn--primary'); ?>
            <?php if ($company['phone'] && $company['phone_href']) : ?>
                <a class="cfs-mobile-menu__link" href="<?php echo esc_url($company['phone_href']); ?>"><?php echo esc_html($company['phone']); ?></a>
            <?php endif; ?>
            <?php if ($company['email']) : ?>
                <a class="cfs-mobile-menu__link" href="mailto:<?php echo esc_attr($company['email']); ?>"><?php echo esc_html($company['email']); ?></a>
            <?php endif; ?>
        </div>
    </div>
</div>

<div id="smooth-wrapper">
<div id="smooth-content">
<main id="cfs-main" class="cfs-main">
