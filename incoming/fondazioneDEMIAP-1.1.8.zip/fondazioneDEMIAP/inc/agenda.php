<?php
/**
 * Agenda: eventi del Google Calendar pubblico della Fondazione mostrati con la grafica del sito.
 *
 * Il sito scarica il feed iCal pubblico (sola lettura) dal server, lo tiene in cache 15 minuti e
 * mostra i prossimi eventi; ogni evento si apre sul posto per leggere la descrizione.
 * Il browser del visitatore non si collega mai a Google (niente iframe, niente cookie di Google,
 * nessun link che apra Google Calendar con l'account di chi guarda).
 */

if (!defined('ABSPATH')) {
    exit;
}

const DEMIAP_AGENDA_ICS = 'https://calendar.google.com/calendar/ical/urtiriconciliazione%40gmail.com/public/basic.ics';
const DEMIAP_AGENDA_TZ  = 'Europe/Zurich';

/**
 * Testo del feed iCal: dalla cache, altrimenti scaricato. Se Google non risponde usa l'ultima copia buona.
 */
function demiap_agenda_ics()
{
    $ics = get_transient('demiap_agenda_ics');
    if (false !== $ics) {
        return (string) $ics;
    }
    $url      = (string) apply_filters('demiap_agenda_ics_url', DEMIAP_AGENDA_ICS);
    $response = wp_remote_get($url, array('timeout' => 8));
    $body     = is_wp_error($response) ? '' : (string) wp_remote_retrieve_body($response);

    if (200 === (int) wp_remote_retrieve_response_code($response) && false !== strpos($body, 'BEGIN:VCALENDAR')) {
        set_transient('demiap_agenda_ics', $body, 15 * MINUTE_IN_SECONDS);
        update_option('demiap_agenda_ics_last_good', $body, false);
        return $body;
    }
    // Google irraggiungibile: riprova tra 5 minuti, intanto l'ultima copia buona.
    $fallback = (string) get_option('demiap_agenda_ics_last_good', '');
    set_transient('demiap_agenda_ics', $fallback, 5 * MINUTE_IN_SECONDS);
    return $fallback;
}

/**
 * Converte il testo iCal in eventi grezzi (proprietà con parametri).
 *
 * @return array<int, array<string, array{params: array<string,string>, value: string}|array>>
 */
function demiap_agenda_parse_ics($ics)
{
    // Righe «piegate»: una riga che inizia con spazio o tab continua la precedente.
    $ics   = preg_replace("/\r\n[ \t]|\n[ \t]/", '', str_replace("\r\n", "\n", (string) $ics));
    $lines = explode("\n", $ics);

    $events = array();
    $event  = null;
    $depth  = 0; // per ignorare i VALARM dentro gli eventi
    foreach ($lines as $line) {
        if ('BEGIN:VEVENT' === $line) {
            $event = array('EXDATE' => array());
            $depth = 0;
            continue;
        }
        if ('END:VEVENT' === $line) {
            if ($event) {
                $events[] = $event;
            }
            $event = null;
            continue;
        }
        if (null === $event) {
            continue;
        }
        if (0 === strpos($line, 'BEGIN:')) {
            $depth++;
            continue;
        }
        if (0 === strpos($line, 'END:')) {
            $depth--;
            continue;
        }
        if ($depth > 0 || false === ($colon = strpos($line, ':'))) {
            continue;
        }
        $left   = substr($line, 0, $colon);
        $value  = substr($line, $colon + 1);
        $parts  = explode(';', $left);
        $name   = strtoupper(array_shift($parts));
        $params = array();
        foreach ($parts as $part) {
            if (false !== strpos($part, '=')) {
                list($k, $v)            = explode('=', $part, 2);
                $params[strtoupper($k)] = trim($v, '"');
            }
        }
        if ('EXDATE' === $name) {
            foreach (explode(',', $value) as $ex) {
                $event['EXDATE'][] = array('params' => $params, 'value' => $ex);
            }
        } else {
            $event[$name] = array('params' => $params, 'value' => $value);
        }
    }
    return $events;
}

/**
 * Data iCal → DateTimeImmutable nel fuso della Svizzera. Restituisce [data, giornata_intera].
 */
function demiap_agenda_date($prop)
{
    $tz    = new DateTimeZone(DEMIAP_AGENDA_TZ);
    $value = trim($prop['value']);
    if ((isset($prop['params']['VALUE']) && 'DATE' === $prop['params']['VALUE']) || preg_match('/^\d{8}$/', $value)) {
        $date = DateTimeImmutable::createFromFormat('!Ymd', substr($value, 0, 8), $tz);
        return array($date ?: null, true);
    }
    try {
        if ('Z' === substr($value, -1)) {
            $date = new DateTimeImmutable(substr($value, 0, -1), new DateTimeZone('UTC'));
        } else {
            $source = new DateTimeZone(isset($prop['params']['TZID']) ? $prop['params']['TZID'] : DEMIAP_AGENDA_TZ);
            $date   = new DateTimeImmutable($value, $source);
        }
        return array($date->setTimezone($tz), false);
    } catch (Exception $e) {
        return array(null, false);
    }
}

/**
 * Testo iCal → testo normale (toglie le sequenze di escape).
 */
function demiap_agenda_text($value)
{
    return str_replace(array('\\n', '\\N', '\\,', '\\;', '\\\\'), array("\n", "\n", ',', ';', '\\'), (string) $value);
}

/**
 * Prossimi eventi (anche ricorrenti), dal più vicino.
 *
 * @param int $limit  numero massimo di eventi
 * @param int $months quanti mesi guardare avanti
 * @return array<int, array{uid:string,start:DateTimeImmutable,end:DateTimeImmutable,all_day:bool,title:string,location:string,description:string}>
 */
function demiap_agenda_upcoming($limit = 20, $months = 12)
{
    $tz      = new DateTimeZone(DEMIAP_AGENDA_TZ);
    $now     = new DateTimeImmutable('now', $tz);
    $horizon = $now->modify('+' . (int) $months . ' months');
    $raw     = demiap_agenda_parse_ics(demiap_agenda_ics());

    // Occorrenze modificate di un evento ricorrente (RECURRENCE-ID): sostituiscono quella originale.
    $overrides = array();
    foreach ($raw as $ev) {
        if (isset($ev['RECURRENCE-ID'], $ev['UID'])) {
            list($rid) = demiap_agenda_date($ev['RECURRENCE-ID']);
            if ($rid) {
                $overrides[$ev['UID']['value'] . '|' . $rid->getTimestamp()] = true;
            }
        }
    }

    $out = array();
    foreach ($raw as $ev) {
        if (!isset($ev['DTSTART'])) {
            continue;
        }
        if (isset($ev['STATUS']) && 'CANCELLED' === strtoupper($ev['STATUS']['value'])) {
            continue;
        }
        list($start, $all_day) = demiap_agenda_date($ev['DTSTART']);
        if (!$start) {
            continue;
        }
        $end = null;
        if (isset($ev['DTEND'])) {
            list($end) = demiap_agenda_date($ev['DTEND']);
        }
        if (!$end) {
            $end = $all_day ? $start->modify('+1 day') : $start;
        }
        $duration = $end->getTimestamp() - $start->getTimestamp();

        $base = array(
            'uid'         => isset($ev['UID']) ? $ev['UID']['value'] : md5(serialize($ev['DTSTART'])),
            'all_day'     => $all_day,
            'title'       => isset($ev['SUMMARY']) ? demiap_agenda_text($ev['SUMMARY']['value']) : 'Evento',
            'location'    => isset($ev['LOCATION']) ? demiap_agenda_text($ev['LOCATION']['value']) : '',
            'description' => isset($ev['DESCRIPTION']) ? demiap_agenda_text($ev['DESCRIPTION']['value']) : '',
        );

        $starts = isset($ev['RRULE']) && !isset($ev['RECURRENCE-ID'])
            ? demiap_agenda_expand($start, $ev['RRULE']['value'], $ev['EXDATE'], $horizon)
            : array($start);

        foreach ($starts as $occurrence) {
            if (isset($ev['RRULE']) && !isset($ev['RECURRENCE-ID']) && isset($overrides[$base['uid'] . '|' . $occurrence->getTimestamp()])) {
                continue;
            }
            $occurrence_end = $occurrence->setTimestamp($occurrence->getTimestamp() + $duration);
            if ($occurrence_end <= $now || $occurrence > $horizon) {
                continue;
            }
            $out[] = $base + array('start' => $occurrence, 'end' => $occurrence_end);
        }
    }

    usort($out, function ($a, $b) {
        return $a['start'] <=> $b['start'];
    });
    return array_slice($out, 0, (int) $limit);
}

/**
 * Date di un evento ricorrente (RRULE) fino a $horizon. Gestisce FREQ DAILY/WEEKLY/MONTHLY/YEARLY
 * con INTERVAL, COUNT, UNTIL e BYDAY (settimanale), più le date escluse (EXDATE).
 *
 * @return DateTimeImmutable[]
 */
function demiap_agenda_expand(DateTimeImmutable $start, $rrule, array $exdates, DateTimeImmutable $horizon)
{
    $rule = array();
    foreach (explode(';', $rrule) as $part) {
        if (false !== strpos($part, '=')) {
            list($k, $v)          = explode('=', $part, 2);
            $rule[strtoupper($k)] = strtoupper($v);
        }
    }
    $freq     = isset($rule['FREQ']) ? $rule['FREQ'] : '';
    $interval = max(1, isset($rule['INTERVAL']) ? (int) $rule['INTERVAL'] : 1);
    $count    = isset($rule['COUNT']) ? (int) $rule['COUNT'] : 0;
    $until    = $horizon;
    if (isset($rule['UNTIL'])) {
        list($u) = demiap_agenda_date(array('params' => array(), 'value' => $rule['UNTIL']));
        if ($u && $u < $until) {
            $until = preg_match('/^\d{8}$/', $rule['UNTIL']) ? $u->modify('+1 day -1 second') : $u;
        }
    }

    $excluded = array();
    foreach ($exdates as $ex) {
        list($d) = demiap_agenda_date($ex);
        if ($d) {
            $excluded[$d->format('Ymd\THis')] = true;
            $excluded[$d->format('Ymd')]      = true;
        }
    }
    $is_excluded = function (DateTimeImmutable $d) use ($excluded) {
        return isset($excluded[$d->format('Ymd\THis')]) || ('000000' === $d->format('His') && isset($excluded[$d->format('Ymd')]));
    };

    $dates = array();
    $n     = 0;
    $guard = 0;

    if ('WEEKLY' === $freq && !empty($rule['BYDAY'])) {
        $map  = array('MO' => 1, 'TU' => 2, 'WE' => 3, 'TH' => 4, 'FR' => 5, 'SA' => 6, 'SU' => 7);
        $days = array();
        foreach (explode(',', $rule['BYDAY']) as $d) {
            $d = preg_replace('/[^A-Z]/', '', $d);
            if (isset($map[$d])) {
                $days[] = $map[$d];
            }
        }
        sort($days);
        $week = $start->modify('-' . ((int) $start->format('N') - 1) . ' days'); // lunedì della prima settimana
        while ($week <= $until && $guard++ < 600) {
            foreach ($days as $dow) {
                $d = $week->modify('+' . ($dow - 1) . ' days');
                if ($d < $start || $d > $until) {
                    continue;
                }
                $n++;
                if ($count && $n > $count) {
                    return $dates;
                }
                if (!$is_excluded($d)) {
                    $dates[] = $d;
                }
            }
            $week = $week->modify('+' . $interval . ' weeks');
        }
        return $dates;
    }

    $step = array('DAILY' => 'day', 'WEEKLY' => 'week', 'MONTHLY' => 'month', 'YEARLY' => 'year');
    if (!isset($step[$freq])) {
        return array($start);
    }
    for ($i = 0; $guard++ < 1500; $i++) {
        // Si parte sempre da $start: «+1 month» dal 31 non scivola al giorno 1 del mese dopo.
        $d = $start->modify('+' . ($i * $interval) . ' ' . $step[$freq]);
        if (in_array($freq, array('MONTHLY', 'YEARLY'), true) && $d->format('d') !== $start->format('d')) {
            continue; // il giorno non esiste in quel mese (es. 31 novembre): Google lo salta
        }
        if ($d > $until) {
            break;
        }
        $n++;
        if ($count && $n > $count) {
            break;
        }
        if (!$is_excluded($d)) {
            $dates[] = $d;
        }
    }
    return $dates;
}

/**
 * Descrizione dell'evento in HTML sicuro. Google la salva a volte in HTML (testo formattato), a volte
 * in testo semplice: in entrambi i casi restano solo tag di testo e i link si aprono in una nuova finestra.
 */
function demiap_agenda_description_html($text)
{
    $text = trim((string) $text);
    if ('' === $text) {
        return '';
    }
    if ($text === wp_strip_all_tags($text)) {
        $html = nl2br(esc_html($text));
    } else {
        $text = preg_replace('#<(script|style)\b[^>]*>.*?</\1>#is', '', $text);
        $html = wp_kses($text, array(
            'a'      => array('href' => true),
            'br'     => array(),
            'p'      => array(),
            'b'      => array(),
            'strong' => array(),
            'i'      => array(),
            'em'     => array(),
            'u'      => array(),
            'ul'     => array(),
            'ol'     => array(),
            'li'     => array(),
        ));
    }
    $html = make_clickable($html);
    return str_replace('<a ', '<a target="_blank" rel="noopener nofollow" ', $html);
}

/**
 * Orario leggibile di un evento («19:00 – 20:30», «Tutto il giorno», «Dal 21 novembre al 22 novembre 2026»).
 */
function demiap_agenda_when(array $event)
{
    $tz    = new DateTimeZone(DEMIAP_AGENDA_TZ);
    $start = $event['start'];
    $end   = $event['end'];
    if ($event['all_day']) {
        $last = $end->modify('-1 day');
        return $last->format('Ymd') > $start->format('Ymd')
            ? sprintf('Dal %s al %s', wp_date('j F', $start->getTimestamp(), $tz), wp_date('j F Y', $last->getTimestamp(), $tz))
            : 'Tutto il giorno';
    }
    return $start->format('Ymd') === $end->format('Ymd')
        ? sprintf('%s – %s', wp_date('H:i', $start->getTimestamp(), $tz), wp_date('H:i', $end->getTimestamp(), $tz))
        : sprintf('Dal %s al %s', wp_date('j F, H:i', $start->getTimestamp(), $tz), wp_date('j F, H:i', $end->getTimestamp(), $tz));
}

/**
 * Una scheda evento (<li>): data, titolo, orario, luogo; con descrizione si apre sul posto.
 */
function demiap_agenda_render_event(array $event)
{
    $tz          = new DateTimeZone(DEMIAP_AGENDA_TZ);
    $start       = $event['start'];
    $description = demiap_agenda_description_html($event['description']);
    $tag         = '' !== $description ? 'details' : 'div';
    $inner       = 'details' === $tag ? 'summary' : 'div';
    ?>
    <li class="demiap-events__item">
        <<?php echo $tag; ?> class="demiap-event">
            <<?php echo $inner; ?> class="demiap-event__summary">
                <time class="demiap-event__date" datetime="<?php echo esc_attr($start->format($event['all_day'] ? 'Y-m-d' : 'c')); ?>">
                    <span class="demiap-event__day"><?php echo esc_html(wp_date('j', $start->getTimestamp(), $tz)); ?></span>
                    <span class="demiap-event__month"><?php echo esc_html(wp_date('M', $start->getTimestamp(), $tz)); ?></span>
                </time>
                <span class="demiap-event__info">
                    <span class="demiap-event__title"><?php echo esc_html($event['title']); ?></span>
                    <span class="demiap-event__meta">
                        <?php echo esc_html(ucfirst(wp_date('l', $start->getTimestamp(), $tz)) . ' · ' . demiap_agenda_when($event)); ?>
                        <?php if ('' !== $event['location']) : ?>
                            <span class="demiap-event__place"><span class="material-symbols-outlined" aria-hidden="true">location_on</span><?php echo esc_html($event['location']); ?></span>
                        <?php endif; ?>
                    </span>
                </span>
                <?php if ('details' === $tag) : ?>
                    <span class="demiap-event__toggle" aria-hidden="true"></span>
                <?php endif; ?>
            </<?php echo $inner; ?>>
            <?php if ('' !== $description) : ?>
                <div class="demiap-event__description"><?php echo $description; // già filtrata da demiap_agenda_description_html() ?></div>
            <?php endif; ?>
        </<?php echo $tag; ?>>
    </li>
    <?php
}

/**
 * Agenda con due viste: «Elenco» (i prossimi 20 eventi) e «Calendario» (griglia mensile, costruita da
 * js/agenda.js con i dati qui sotto). Senza JavaScript si vede l'elenco e i pulsanti restano nascosti.
 */
function demiap_agenda_render($events = null)
{
    if (null === $events) {
        $events = demiap_agenda_upcoming(300, 12);
    }
    $tz   = new DateTimeZone(DEMIAP_AGENDA_TZ);
    $data = array();
    foreach ($events as $event) {
        $last = $event['all_day'] ? $event['end']->modify('-1 day') : $event['end'];
        if ($last < $event['start'] || (!$event['all_day'] && '000000' === $last->format('His') && $last > $event['start'])) {
            $last = $last->modify('-1 second'); // un evento che finisce a mezzanotte non occupa il giorno dopo
        }
        $data[] = array(
            'd' => $event['start']->format('Y-m-d'),
            'e' => max($event['start'], $last)->format('Y-m-d'),
            't' => $event['title'],
            'w' => demiap_agenda_when($event),
            'l' => $event['location'],
            'h' => demiap_agenda_description_html($event['description']),
            'g' => ucfirst(wp_date('l j F', $event['start']->getTimestamp(), $tz)),
        );
    }
    ?>
    <div class="demiap-agenda-views" data-demiap-agenda>
        <div class="demiap-agenda-views__switch" role="group" aria-label="Vista dell'agenda" hidden>
            <button type="button" class="demiap-agenda-views__btn" data-view="list" aria-pressed="true"><span class="material-symbols-outlined" aria-hidden="true">view_agenda</span> Elenco</button>
            <button type="button" class="demiap-agenda-views__btn" data-view="calendar" aria-pressed="false"><span class="material-symbols-outlined" aria-hidden="true">calendar_view_month</span> Calendario</button>
        </div>

        <div data-view-panel="list">
            <?php if (empty($events)) : ?>
                <p class="demiap-events__empty">Al momento non ci sono eventi in programma.</p>
            <?php else : ?>
                <ul class="demiap-events">
                    <?php foreach (array_slice($events, 0, 20) as $event) {
                        demiap_agenda_render_event($event);
                    } ?>
                </ul>
            <?php endif; ?>
        </div>

        <div data-view-panel="calendar" hidden>
            <div class="demiap-cal" data-demiap-cal></div>
            <script type="application/json" class="demiap-cal__data"><?php echo wp_json_encode($data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE); ?></script>
        </div>
    </div>
    <?php
}

// Script della vista calendario: solo nella pagina Agenda.
add_action('wp_enqueue_scripts', function () {
    if (is_page('agenda')) {
        wp_enqueue_script('fondazionedemiap-agenda', get_stylesheet_directory_uri() . '/js/agenda.js', array(), wp_get_theme()->get('Version'), true);
    }
}, 30);
