<?php
/**
 * Template Name: Oasi — Buono regalo
 *
 * Request flow backed by the parent theme secure form pipeline.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
$logo_url   = function_exists( 'oasi_get_master_logo_url' ) ? oasi_get_master_logo_url() : '';
$privacy_url = function_exists( 'oasi_contact_get_privacy_url' ) ? oasi_contact_get_privacy_url() : '';
?>
<main id="primary" class="oasi-gift-voucher">
	<section class="oasi-gift-voucher__hero" aria-labelledby="oasi-gift-voucher-title">
		<div class="oasi-container oasi-gift-voucher__hero-grid">
			<div class="oasi-gift-voucher__intro">
				<span class="oasi-gift-voucher__kicker"><?php esc_html_e( 'Un pensiero scelto con cura', 'oasidellespezie-child-theme' ); ?></span>
				<h1 id="oasi-gift-voucher-title"><?php esc_html_e( 'Buono regalo Oasi', 'oasidellespezie-child-theme' ); ?></h1>
				<p><?php esc_html_e( 'Regala la libertà di scegliere tra spezie, pepi, sali, miscele e specialità del nostro catalogo. Invia la richiesta: il laboratorio ti ricontatterà per confermare valore, destinatario e consegna.', 'oasidellespezie-child-theme' ); ?></p>
				<ol><li><strong><?php esc_html_e( 'Compila la richiesta', 'oasidellespezie-child-theme' ); ?></strong><span><?php esc_html_e( 'Indica valore e destinatario.', 'oasidellespezie-child-theme' ); ?></span></li><li><strong><?php esc_html_e( 'Ricevi la conferma', 'oasidellespezie-child-theme' ); ?></strong><span><?php esc_html_e( 'Verifichiamo insieme tutti i dettagli.', 'oasidellespezie-child-theme' ); ?></span></li><li><strong><?php esc_html_e( 'Consegna il regalo', 'oasidellespezie-child-theme' ); ?></strong><span><?php esc_html_e( 'Il buono viene preparato secondo gli accordi confermati.', 'oasidellespezie-child-theme' ); ?></span></li></ol>
			</div>
			<div class="oasi-gift-voucher__brand" aria-label="<?php esc_attr_e( 'Oasi delle Spezie', 'oasidellespezie-child-theme' ); ?>"><?php if ( $logo_url ) : ?><img src="<?php echo esc_url( $logo_url ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" width="480" height="310"><?php endif; ?><span><?php esc_html_e( 'BUONO REGALO', 'oasidellespezie-child-theme' ); ?></span></div>
		</div>
	</section>

	<section class="oasi-container oasi-gift-voucher__request" aria-labelledby="oasi-gift-voucher-form-title">
		<header><span><?php esc_html_e( 'Richiesta senza impegno', 'oasidellespezie-child-theme' ); ?></span><h2 id="oasi-gift-voucher-form-title"><?php esc_html_e( 'Prepara il tuo buono regalo', 'oasidellespezie-child-theme' ); ?></h2><p><?php esc_html_e( 'I campi contrassegnati sono necessari per poterti ricontattare. Nessun pagamento viene effettuato da questo modulo.', 'oasidellespezie-child-theme' ); ?></p></header>
		<form class="oasi-gift-voucher-form" data-oasi-gift-voucher-form data-ajax-url="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>" novalidate>
			<div class="oasi-gift-voucher-form__grid">
				<label><span><?php esc_html_e( 'Il tuo nome e cognome', 'oasidellespezie-child-theme' ); ?> *</span><input type="text" name="nome" autocomplete="name" required maxlength="120"><small data-error-for="nome" role="alert"></small></label>
				<label><span><?php esc_html_e( 'La tua email', 'oasidellespezie-child-theme' ); ?> *</span><input type="email" name="email" autocomplete="email" required maxlength="190"><small data-error-for="email" role="alert"></small></label>
				<label><span><?php esc_html_e( 'Telefono', 'oasidellespezie-child-theme' ); ?></span><input type="tel" name="telefono" autocomplete="tel" maxlength="40"></label>
				<label><span><?php esc_html_e( 'Valore desiderato in CHF', 'oasidellespezie-child-theme' ); ?> *</span><input type="number" name="voucher_amount" min="10" step="5" inputmode="decimal" required><small data-error-for="voucher_amount" role="alert"></small></label>
				<label><span><?php esc_html_e( 'Nome del destinatario', 'oasidellespezie-child-theme' ); ?> *</span><input type="text" name="recipient_name" maxlength="120" required><small data-error-for="recipient_name" role="alert"></small></label>
				<label><span><?php esc_html_e( 'Data desiderata', 'oasidellespezie-child-theme' ); ?></span><input type="date" name="delivery_date"></label>
				<label class="oasi-gift-voucher-form__full"><span><?php esc_html_e( 'Messaggio o richieste particolari', 'oasidellespezie-child-theme' ); ?></span><textarea name="gift_message" rows="5" maxlength="1200"></textarea></label>
			</div>
			<input type="hidden" name="oggetto" value="Richiesta buono regalo">
			<input type="hidden" name="messaggio" value="">
			<p class="oasi-gift-voucher-form__hp" aria-hidden="true"><label><?php esc_html_e( 'Lascia vuoto', 'oasidellespezie-child-theme' ); ?><input type="text" name="tw_hp" tabindex="-1" autocomplete="off"></label></p>
			<label class="oasi-gift-voucher-form__privacy"><input type="checkbox" name="privacy" value="1" required><span><?php if ( $privacy_url ) : ?><?php printf( wp_kses_post( __( 'Ho letto l’<a href="%s" target="_blank" rel="noopener">informativa sulla privacy</a> e autorizzo il contatto relativo alla richiesta.', 'oasidellespezie-child-theme' ) ), esc_url( $privacy_url ) ); ?><?php else : ?><?php esc_html_e( 'Ho letto l’informativa sulla privacy e autorizzo il contatto relativo alla richiesta.', 'oasidellespezie-child-theme' ); ?><?php endif; ?></span></label><small data-error-for="privacy" role="alert"></small>
			<div class="oasi-gift-voucher-form__actions"><button type="submit"><?php esc_html_e( 'Invia la richiesta', 'oasidellespezie-child-theme' ); ?><span aria-hidden="true">→</span></button><p data-oasi-gift-voucher-status role="status" aria-live="polite"></p></div>
		</form>
	</section>
</main>
<?php get_footer(); ?>
