<?php
/**
 * WooCommerce checkout surface.
 *
 * THESIS: a single calm path from customer details to a secure order.
 * OWN-WORLD: Oasi cream, peppercorn text, terracotta actions and restrained gold trust cues.
 * STORY: complete details, verify the order, choose an existing payment method and submit.
 * FIRST VIEWPORT: compact heading, trust row and the start of the operational two-column form.
 * FORM: 62/38 checkout workspace that becomes one linear column on narrow screens.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<div id="primary" class="oasi-checkout">
	<header class="oasi-checkout-head">
		<div class="oasi-container oasi-checkout-head__inner">
			<div class="oasi-checkout-head__copy">
				<span class="oasi-checkout-kicker"><?php esc_html_e( 'Il tuo acquisto', 'oasidellespezie-child-theme' ); ?></span>
				<h1><?php esc_html_e( 'Concludi il tuo ordine', 'oasidellespezie-child-theme' ); ?></h1>
				<p><?php esc_html_e( 'Completa i tuoi dati e scegli il metodo di pagamento in modo semplice e sicuro.', 'oasidellespezie-child-theme' ); ?></p>
			</div>

			<ul class="oasi-checkout-trust" aria-label="<?php esc_attr_e( 'Garanzie del checkout', 'oasidellespezie-child-theme' ); ?>">
				<li><span aria-hidden="true">✓</span><?php esc_html_e( 'Pagamento sicuro', 'oasidellespezie-child-theme' ); ?></li>
				<li><span aria-hidden="true">✓</span><?php esc_html_e( 'Spedizione in Svizzera', 'oasidellespezie-child-theme' ); ?></li>
				<li><span aria-hidden="true">✓</span><?php esc_html_e( 'Assistenza clienti', 'oasidellespezie-child-theme' ); ?></li>
			</ul>
		</div>
	</header>

	<section class="oasi-checkout-body" aria-label="<?php esc_attr_e( 'Dati e riepilogo del checkout', 'oasidellespezie-child-theme' ); ?>">
		<div class="oasi-container">
			<?php echo do_shortcode( '[woocommerce_checkout]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Trusted WooCommerce shortcode output. ?>
		</div>
	</section>
</div>

<?php get_footer(); ?>
