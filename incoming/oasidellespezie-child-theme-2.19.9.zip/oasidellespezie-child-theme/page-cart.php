<?php
/**
 * WooCommerce cart surface.
 *
 * THESIS: prodotti e totale devono essere comprensibili senza una hero promozionale.
 * OWN-WORLD: crema naturale, terracotta, marrone caldo e oro misurato del sistema Oasi.
 * STORY: controllare il contenuto, regolare le quantità e procedere al pagamento.
 * FIRST VIEWPORT: titolo compatto, prodotti e riepilogo ordine visibili insieme su desktop.
 * FORM: lista operativa e pannello totale; singola colonna lineare su mobile.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<div id="primary" class="oasi-cart">
	<header class="oasi-cart-head">
		<div class="oasi-container oasi-cart-head__inner">
			<div>
				<span class="oasi-cart-kicker"><?php esc_html_e( 'Il tuo ordine', 'oasidellespezie-child-theme' ); ?></span>
				<h1><?php esc_html_e( 'Il tuo carrello', 'oasidellespezie-child-theme' ); ?></h1>
				<p><?php esc_html_e( 'Controlla i tuoi prodotti prima di procedere al pagamento.', 'oasidellespezie-child-theme' ); ?></p>
			</div>
		</div>
	</header>

	<section class="oasi-cart-body" aria-label="<?php esc_attr_e( 'Contenuto del carrello', 'oasidellespezie-child-theme' ); ?>">
		<div class="oasi-container">
			<?php echo do_shortcode( '[woocommerce_cart]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Trusted WooCommerce shortcode output. ?>
		</div>
	</section>
</div>

<?php get_footer(); ?>
