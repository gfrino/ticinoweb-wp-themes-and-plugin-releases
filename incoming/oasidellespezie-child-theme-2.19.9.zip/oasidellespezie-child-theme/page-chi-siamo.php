<?php
/**
 * Template Name: Oasi — Chi siamo
 *
 * A compact, Home-aligned editorial story powered by the existing ticinoWEB CMS.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$about     = oasi_get_about_page_data();
$shop_link = ! empty( $about['link'] ) ? $about['link'] : home_url( '/shop-online-oasi-delle-spezie/' );
$story_alt = ! empty( $about['image_id'] ) ? trim( (string) get_post_meta( (int) $about['image_id'], '_wp_attachment_image_alt', true ) ) : '';
$story_alt = $story_alt ?: $about['title'];
$practices = array(
	array(
		'label'    => __( 'Conservazione', 'oasidellespezie-child-theme' ),
		'title'    => __( 'La conservazione dei nostri prodotti', 'oasidellespezie-child-theme' ),
		'text'     => __( "La conservazione di spezie o erbe aromatiche è semplice ma richiede rigore. Tutte le nostre spezie, le erbe, gli zuccheri e gli infusi sono conservati in un magazzino protetto dalla luce e la cui temperatura e umidità sono controllate ogni giorno. I prodotti vengono confezionati quando l’ordine viene preparato nel nostro laboratorio: è essenziale per garantire la freschezza dei sapori e la buona conservazione. Questo modo di procedere richiede un po’ più tempo, ma garantisce un prodotto di alta qualità, perché controlliamo ogni spezia ed erba prima del confezionamento.", 'oasidellespezie-child-theme' ),
		'image_id' => (int) ( $about['practice_ids'][0] ?? 0 ),
	),
	array(
		'label'    => __( 'Confezionamento', 'oasidellespezie-child-theme' ),
		'title'    => __( 'Sacchetti e barattoli di qualità alimentare', 'oasidellespezie-child-theme' ),
		'text'     => __( "Abbiamo scelto volutamente sacchetti Kraft ecologici per alimenti, opachi, con o senza finestre e richiudibili ermeticamente. La chiusura a zip permette al prodotto di conservare freschezza e sapore. Anche i nostri barattoli in ferro bianco sono studiati per mantenere la freschezza e il carattere di ogni ingrediente, nel rispetto dell’ambiente.", 'oasidellespezie-child-theme' ),
		'image_id' => (int) ( $about['practice_ids'][1] ?? 0 ),
	),
	array(
		'label'    => __( 'Igiene e qualità', 'oasidellespezie-child-theme' ),
		'title'    => __( 'Rispetto delle norme igieniche', 'oasidellespezie-child-theme' ),
		'text'     => __( "Questa è la regola fondamentale quando si lavora nell’industria alimentare. Siamo formati su questo importante argomento e lavoriamo nel pieno rispetto delle norme igieniche.", 'oasidellespezie-child-theme' ),
		'image_id' => (int) ( $about['practice_ids'][2] ?? 0 ),
	),
);

foreach ( $practices as &$practice ) {
	$practice_alt          = trim( (string) get_post_meta( $practice['image_id'], '_wp_attachment_image_alt', true ) );
	$practice['image_alt'] = $practice_alt ?: $practice['title'];
}
unset( $practice );
?>

<div id="primary" class="oasi-about">
	<section class="oasi-about-story" aria-labelledby="oasi-about-title">
		<div class="oasi-container oasi-about-story__grid">
			<div class="oasi-about-story__copy oasi-reveal">
				<p class="oasi-about-kicker"><?php esc_html_e( 'Oasi delle Spezie · Gudo', 'oasidellespezie-child-theme' ); ?></p>
				<h1 id="oasi-about-title"><?php echo esc_html( $about['title'] ); ?></h1>
				<div class="oasi-about-story__text">
					<?php echo wp_kses_post( wpautop( esc_html( $about['story'] ) ) ); ?>
				</div>

				<div class="oasi-about-story__footer">
					<?php if ( ! empty( $about['closing'] ) ) : ?>
						<div class="oasi-bio" aria-label="<?php echo esc_attr( $about['closing'] ); ?>">
							<span class="oasi-bio__line" aria-hidden="true"></span>
							<strong class="oasi-bio__word"><?php echo esc_html( $about['closing'] ); ?></strong>
							<span class="oasi-bio__period" aria-hidden="true">…</span>
						</div>
					<?php endif; ?>

					<?php if ( ! empty( $about['link'] ) ) : ?>
						<a class="oasi-about-link" href="<?php echo esc_url( $about['link'] ); ?>">
							<span><?php esc_html_e( 'Scopri le nostre spezie', 'oasidellespezie-child-theme' ); ?></span>
							<span aria-hidden="true">→</span>
						</a>
					<?php endif; ?>
				</div>
			</div>

			<figure class="oasi-about-story__media oasi-reveal">
				<div class="oasi-about-story__frame">
					<?php if ( ! empty( $about['image_id'] ) ) : ?>
						<?php echo wp_kses_post( wp_get_attachment_image( (int) $about['image_id'], 'large', false, array( 'loading' => 'eager', 'fetchpriority' => 'high', 'alt' => $story_alt ) ) ); ?>
					<?php elseif ( ! empty( $about['image_url'] ) ) : ?>
						<img src="<?php echo esc_url( $about['image_url'] ); ?>" alt="<?php echo esc_attr( $about['title'] ); ?>" loading="eager" fetchpriority="high">
					<?php endif; ?>
				</div>
				<figcaption><?php esc_html_e( 'Selezione · Controllo · Confezionamento', 'oasidellespezie-child-theme' ); ?></figcaption>
			</figure>
		</div>
	</section>

	<?php if ( ! empty( $about['team'] ) ) : ?>
		<section class="oasi-team" aria-labelledby="oasi-team-title">
			<div class="oasi-container">
				<header class="oasi-team__header oasi-reveal">
					<p class="oasi-about-kicker"><?php esc_html_e( 'Le persone dietro ogni miscela', 'oasidellespezie-child-theme' ); ?></p>
					<h2 id="oasi-team-title"><?php esc_html_e( 'Il team di Oasi delle Spezie', 'oasidellespezie-child-theme' ); ?></h2>
				</header>

				<div class="oasi-team__composition">
					<?php foreach ( $about['team'] as $index => $member ) : ?>
						<article class="oasi-team-person oasi-reveal" style="--oasi-team-index: <?php echo esc_attr( (string) $index ); ?>;">
							<figure class="oasi-team-person__portrait">
								<?php if ( ! empty( $member['image_id'] ) ) : ?>
									<?php echo wp_kses_post( wp_get_attachment_image( (int) $member['image_id'], 'medium_large', false, array( 'loading' => 'lazy', 'alt' => $member['name'] ) ) ); ?>
								<?php endif; ?>
							</figure>
							<div class="oasi-team-person__identity">
								<h3><?php echo esc_html( $member['name'] ); ?></h3>
								<p><?php echo esc_html( $member['role'] ); ?></p>
							</div>
						</article>
					<?php endforeach; ?>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<section class="oasi-mixtis" aria-labelledby="oasi-mixtis-title">
		<div class="oasi-container oasi-mixtis__grid">
			<div class="oasi-mixtis__visual oasi-reveal">
				<figure class="oasi-mixtis__image oasi-mixtis__image--primary">
					<?php echo wp_kses_post( wp_get_attachment_image( (int) $about['mixtis_id'], 'large', false, array( 'loading' => 'lazy', 'alt' => __( 'Creazione artigianale MIXTIS', 'oasidellespezie-child-theme' ) ) ) ); ?>
				</figure>
				<figure class="oasi-mixtis__image oasi-mixtis__image--secondary">
					<?php echo wp_kses_post( wp_get_attachment_image( (int) $about['whole_id'], 'medium', false, array( 'loading' => 'lazy', 'alt' => __( 'Spezie intere macinate al momento', 'oasidellespezie-child-theme' ) ) ) ); ?>
				</figure>
			</div>

			<div class="oasi-mixtis__copy oasi-reveal">
				<p class="oasi-about-kicker"><?php esc_html_e( 'Creazioni esclusive artigianali', 'oasidellespezie-child-theme' ); ?></p>
				<h2 id="oasi-mixtis-title"><?php esc_html_e( 'La linea biologica MIXTIS', 'oasidellespezie-child-theme' ); ?></h2>
				<p><?php esc_html_e( 'Tutta la nostra linea biologica “MIXTIS” è garantita al 100% naturale. Ciò che rende le nostre miscele di spezie macinate biologiche così speciali è che tutti i sapori, gli oli essenziali, le vitamine e i minerali unici di ogni spezia sono preservati, così come la loro durata, grazie a una macinatura appena fatta.', 'oasidellespezie-child-theme' ); ?></p>
				<h3><?php esc_html_e( 'PERCHÉ LE SPEZIE INTERE?', 'oasidellespezie-child-theme' ); ?></h3>
				<p><?php esc_html_e( 'La spezia intera contiene i sapori, gli oli essenziali, le vitamine e i minerali che le sono propri. Per questo le miscele MIXTIS sono realizzate e manipolate con delicatezza, rispetto e conoscenza, preservando ed esaltando la ricchezza del gusto.', 'oasidellespezie-child-theme' ); ?></p>
				<a class="oasi-about-link oasi-about-link--light" href="<?php echo esc_url( $shop_link ); ?>">
					<span><?php esc_html_e( 'Esplora MIXTIS', 'oasidellespezie-child-theme' ); ?></span>
					<span aria-hidden="true">→</span>
				</a>
			</div>
		</div>
	</section>

	<section class="oasi-lab" aria-labelledby="oasi-lab-title" data-oasi-lab>
		<div class="oasi-container oasi-lab__grid">
			<figure class="oasi-lab__media oasi-reveal">
				<?php echo wp_kses_post( wp_get_attachment_image( $practices[0]['image_id'], 'large', false, array( 'class' => 'oasi-lab__image', 'loading' => 'lazy', 'alt' => $practices[0]['image_alt'] ) ) ); ?>
			</figure>

			<div class="oasi-lab__content oasi-reveal">
				<header class="oasi-lab__intro">
					<p class="oasi-about-kicker"><?php esc_html_e( 'Il nostro modo di lavorare', 'oasidellespezie-child-theme' ); ?></p>
					<h2 id="oasi-lab-title"><?php esc_html_e( 'Il nostro laboratorio', 'oasidellespezie-child-theme' ); ?></h2>
					<p><?php esc_html_e( 'Siamo un laboratorio, non siamo un negozio e non abbiamo vetrina su strada.', 'oasidellespezie-child-theme' ); ?></p>
				</header>

				<div class="oasi-lab__tabs" role="tablist" aria-label="<?php esc_attr_e( 'Pratiche del laboratorio', 'oasidellespezie-child-theme' ); ?>">
					<?php foreach ( $practices as $index => $practice ) : ?>
						<?php
						$image_url    = wp_get_attachment_image_url( $practice['image_id'], 'large' );
						$image_srcset = wp_get_attachment_image_srcset( $practice['image_id'], 'large' );
						?>
						<button
							type="button"
							class="oasi-lab__tab<?php echo 0 === $index ? ' is-active' : ''; ?>"
							id="oasi-lab-tab-<?php echo esc_attr( (string) $index ); ?>"
							role="tab"
							aria-selected="<?php echo 0 === $index ? 'true' : 'false'; ?>"
							aria-controls="oasi-lab-panel-<?php echo esc_attr( (string) $index ); ?>"
							tabindex="<?php echo 0 === $index ? '0' : '-1'; ?>"
							data-oasi-lab-image="<?php echo esc_url( $image_url ?: '' ); ?>"
							data-oasi-lab-srcset="<?php echo esc_attr( $image_srcset ?: '' ); ?>"
							data-oasi-lab-alt="<?php echo esc_attr( $practice['image_alt'] ); ?>"
						>
							<span class="oasi-lab__tab-num">0<?php echo (int) ( $index + 1 ); ?></span>
							<span class="oasi-lab__tab-label"><?php echo esc_html( $practice['label'] ); ?></span>
						</button>
					<?php endforeach; ?>
				</div>

				<div class="oasi-lab__panels">
					<?php foreach ( $practices as $index => $practice ) : ?>
						<div
							class="oasi-lab-panel<?php echo 0 === $index ? ' is-active' : ''; ?>"
							id="oasi-lab-panel-<?php echo esc_attr( (string) $index ); ?>"
							role="tabpanel"
							aria-labelledby="oasi-lab-tab-<?php echo esc_attr( (string) $index ); ?>"
							data-oasi-lab-panel
						>
							<h3><?php echo esc_html( $practice['title'] ); ?></h3>
							<p><?php echo esc_html( $practice['text'] ); ?></p>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
	</section>

	<section class="oasi-about-close" aria-label="<?php esc_attr_e( 'Scopri le spezie Oasi', 'oasidellespezie-child-theme' ); ?>">
		<div class="oasi-container oasi-about-close__inner oasi-reveal">
			<p><?php esc_html_e( 'Conoscenza e passione per le spezie del mondo.', 'oasidellespezie-child-theme' ); ?></p>
			<a href="<?php echo esc_url( $shop_link ); ?>"><?php esc_html_e( 'Entra nello shop', 'oasidellespezie-child-theme' ); ?><span aria-hidden="true">→</span></a>
		</div>
	</section>
</div>

<?php
get_footer();
