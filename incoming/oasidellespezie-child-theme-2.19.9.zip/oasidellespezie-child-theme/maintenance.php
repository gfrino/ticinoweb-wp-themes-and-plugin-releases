<?php
/**
 * Standalone maintenance screen.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$site_name        = get_bloginfo( 'name' );
$logo_url         = function_exists( 'oasi_get_master_logo_url' ) ? oasi_get_master_logo_url() : '';
$stylesheet_path  = get_stylesheet_directory() . '/assets/css/maintenance.css';
$stylesheet_url   = get_stylesheet_directory_uri() . '/assets/css/maintenance.css';
$stylesheet_stamp = is_file( $stylesheet_path ) ? (string) filemtime( $stylesheet_path ) : '';
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php echo esc_attr( get_bloginfo( 'charset' ) ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex, nofollow, noarchive">
	<meta name="theme-color" content="#1d1815">
	<title><?php echo esc_html( 'Stiamo arrivando — ' . $site_name ); ?></title>
	<link rel="stylesheet" href="<?php echo esc_url( $stylesheet_url . ( '' !== $stylesheet_stamp ? '?ver=' . $stylesheet_stamp : '' ) ); ?>">
</head>
<body class="oasi-maintenance">
	<main class="oasi-maintenance__shell">
		<header class="oasi-maintenance__masthead">
			<?php if ( '' !== $logo_url ) : ?>
				<img class="oasi-maintenance__logo" src="<?php echo esc_url( $logo_url ); ?>" alt="<?php echo esc_attr( $site_name ); ?>" width="300" height="132">
			<?php else : ?>
				<p class="oasi-maintenance__brand"><?php echo esc_html( $site_name ); ?></p>
			<?php endif; ?>

			<div class="oasi-maintenance__title-group">
				<p class="oasi-maintenance__date">2 · 11 · 2026</p>
				<h1>STIAMO ARRIVANDO</h1>
				<p class="oasi-maintenance__lead">Il nostro shop online sta per riaprire.</p>
			</div>
		</header>

		<div class="oasi-maintenance__notices" aria-label="Avviso di riapertura in tre lingue">
			<section class="oasi-maintenance__notice" lang="it" aria-labelledby="oasi-maintenance-it">
				<h2 id="oasi-maintenance-it">Italiano</h2>
				<p>Avviso alla nostra gentile e paziente clientela che saremmo di nuovo aperti con il nostro shop-online a partire del <strong>2 novembre 2026</strong> con qualche novità e un sito tutto nuovo.</p>
				<p>Vi ringraziamo per la vostra pazienza e saremmo lieti di offrirvi i nostri migliori servizi.</p>
				<p class="oasi-maintenance__closing">A presto, nel nostro shop-online<br>Saluti speziati<br><strong>Il Team Oasi</strong></p>
			</section>

			<section class="oasi-maintenance__notice" lang="fr" aria-labelledby="oasi-maintenance-fr">
				<h2 id="oasi-maintenance-fr">Français</h2>
				<p>Nous informons notre chère clientèle que notre boutique en ligne rouvrira ses portes à partir du <strong>2 novembre 2026</strong>, avec quelques nouveautés et un tout nouveau site.</p>
				<p>Nous vous remercions de votre patience et serons ravis de vous offrir nos meilleurs services.</p>
				<p class="oasi-maintenance__closing">À bientôt, sur notre boutique en ligne<br>Salutations épicées<br><strong>L'équipe Oasi</strong></p>
			</section>

			<section class="oasi-maintenance__notice" lang="de" aria-labelledby="oasi-maintenance-de">
				<h2 id="oasi-maintenance-de">Deutsch</h2>
				<p>Wir möchten unsere geschätzten Kunden darauf hinweisen, dass unser Online-Shop ab dem <strong>2. November 2026</strong> wieder geöffnet sein wird – mit einigen Neuheiten und einer komplett neuen Website.</p>
				<p>Wir danken Ihnen für Ihre Geduld und freuen uns darauf, Ihnen unseren besten Service zu bieten.</p>
				<p class="oasi-maintenance__closing">Bis bald in unserem Online-Shop<br>Pikante Grüße<br><strong>Das Oasi-Team</strong></p>
			</section>
		</div>
	</main>
</body>
</html>
