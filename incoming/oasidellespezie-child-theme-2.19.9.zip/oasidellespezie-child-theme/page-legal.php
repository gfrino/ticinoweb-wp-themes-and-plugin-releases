<?php
/**
 * Shared legal/help page template.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$definition  = oasi_legal_get_current_definition();
$definitions = oasi_legal_get_definitions();
$current     = get_queried_object();
$current_slug = $current instanceof WP_Post ? (string) $current->post_name : '';
$certificate_url = 'certificazione' === $current_slug ? oasi_legal_get_certificate_url() : '';
$certificate_data = 'certificazione' === $current_slug && function_exists( 'oasi_get_certification_content' ) ? oasi_get_certification_content() : array();
$certificate_url = 'certificazione' === $current_slug && function_exists( 'oasi_certification_get_pdf_url' ) ? oasi_certification_get_pdf_url() : $certificate_url;
$contact_url = function_exists( 'oasi_professional_get_contact_url' ) ? oasi_professional_get_contact_url() : home_url( '/contatto/' );

get_header();
?>
<div id="primary" class="site-main oasi-legal">
	<section class="oasi-legal__hero" aria-labelledby="oasi-legal-title">
		<div class="oasi-container oasi-legal__hero-inner">
			<nav class="oasi-legal__breadcrumb" aria-label="<?php esc_attr_e( 'Percorso', 'oasidellespezie-child-theme' ); ?>">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'oasidellespezie-child-theme' ); ?></a>
				<span aria-hidden="true">/</span>
				<span><?php esc_html_e( 'Legale & Aiuto', 'oasidellespezie-child-theme' ); ?></span>
			</nav>
			<span class="oasi-legal__kicker"><?php echo esc_html( $definition['kicker'] ?? '' ); ?></span>
			<h1 id="oasi-legal-title"><?php echo esc_html( $definition['title'] ?? get_the_title() ); ?></h1>
			<p><?php echo esc_html( $definition['summary'] ?? '' ); ?></p>
			<small><?php echo esc_html( sprintf( __( 'Ultimo aggiornamento: %s', 'oasidellespezie-child-theme' ), $definition['updated'] ?? '' ) ); ?></small>
		</div>
	</section>

	<div class="oasi-container oasi-legal__layout">
		<aside class="oasi-legal__aside" aria-label="<?php esc_attr_e( 'Navigazione Legale e Aiuto', 'oasidellespezie-child-theme' ); ?>">
			<p><?php esc_html_e( 'Legale & Aiuto', 'oasidellespezie-child-theme' ); ?></p>
			<nav class="oasi-legal__pages">
				<?php foreach ( $definitions as $slug => $item ) : ?>
					<a href="<?php echo esc_url( oasi_legal_get_page_url( $slug ) ); ?>"<?php echo $slug === $current_slug ? ' aria-current="page"' : ''; ?>>
						<?php echo esc_html( $item['title'] ); ?><span aria-hidden="true">→</span>
					</a>
				<?php endforeach; ?>
			</nav>

			<?php if ( ! empty( $definition['sections'] ) ) : ?>
				<nav class="oasi-legal__toc" aria-label="<?php esc_attr_e( 'Indice della pagina', 'oasidellespezie-child-theme' ); ?>" data-oasi-legal-toc>
					<strong><?php esc_html_e( 'In questa pagina', 'oasidellespezie-child-theme' ); ?></strong>
					<?php foreach ( $definition['sections'] as $section ) : ?>
						<a href="#<?php echo esc_attr( $section['id'] ); ?>"><?php echo esc_html( $section['title'] ); ?></a>
					<?php endforeach; ?>
				</nav>
			<?php endif; ?>
		</aside>

		<article class="oasi-legal__content">
			<?php if ( 'privacy-policy' === $current_slug ) : ?>
				<div class="oasi-legal__notice">
					<strong><?php esc_html_e( 'In breve', 'oasidellespezie-child-theme' ); ?></strong>
					<p><?php esc_html_e( 'Usiamo i dati necessari a gestire il servizio richiesto, proteggere il sito e rispettare gli obblighi di legge. Non vendiamo dati personali.', 'oasidellespezie-child-theme' ); ?></p>
				</div>
			<?php endif; ?>

			<?php if ( ! empty( $definition['certificate'] ) ) : ?>
				<div class="oasi-legal__certificate">
					<?php if ( ! empty( $certificate_data['certificate_image_id'] ) ) : ?><figure><?php echo wp_get_attachment_image( (int) $certificate_data['certificate_image_id'], 'medium_large', false, array( 'loading' => 'eager', 'alt' => $certificate_data['title'] ?? '' ) ); ?></figure><?php endif; ?>
					<div><span><?php echo esc_html( $certificate_data['certificate_code'] ?? 'CH-BIO-006' ); ?></span><strong><?php echo esc_html( $certificate_data['certificate_number'] ?? 'BVH-62064' ); ?></strong><small><?php echo esc_html( $certificate_data['validity'] ?? __( 'Valido fino al 31.12.2026', 'oasidellespezie-child-theme' ) ); ?></small></div>
					<?php if ( $certificate_url ) : ?>
						<a class="oasi-legal__button" href="<?php echo esc_url( $certificate_url ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $certificate_data['cta_label'] ?? __( 'Apri il certificato PDF', 'oasidellespezie-child-theme' ) ); ?><span aria-hidden="true">↗</span></a>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<?php foreach ( $definition['sections'] ?? array() as $section ) : ?>
				<section id="<?php echo esc_attr( $section['id'] ); ?>" class="oasi-legal__section" data-oasi-legal-section>
					<h2><?php echo esc_html( $section['title'] ); ?></h2>
					<?php foreach ( $section['body'] ?? array() as $paragraph ) : ?>
						<p><?php echo wp_kses_post( $paragraph ); ?></p>
					<?php endforeach; ?>
					<?php if ( ! empty( $section['list'] ) ) : ?>
						<ul><?php foreach ( $section['list'] as $item ) : ?><li><?php echo esc_html( $item ); ?></li><?php endforeach; ?></ul>
					<?php endif; ?>
				</section>
			<?php endforeach; ?>

			<?php if ( ! empty( $definition['faqs'] ) ) : ?>
				<div class="oasi-legal__faq" data-oasi-faq>
					<?php foreach ( $definition['faqs'] as $index => $faq ) : ?>
						<details<?php echo 0 === $index ? ' open' : ''; ?>>
							<summary><span><?php echo esc_html( sprintf( '%02d', $index + 1 ) ); ?></span><?php echo esc_html( $faq['question'] ); ?><i aria-hidden="true"></i></summary>
							<div><p><?php echo esc_html( $faq['answer'] ); ?></p></div>
						</details>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<footer class="oasi-legal__support">
				<span><?php esc_html_e( 'Hai bisogno di un chiarimento?', 'oasidellespezie-child-theme' ); ?></span>
				<strong><?php esc_html_e( 'Parlane direttamente con il laboratorio.', 'oasidellespezie-child-theme' ); ?></strong>
				<a href="<?php echo esc_url( $contact_url ); ?>"><?php esc_html_e( 'Contattaci', 'oasidellespezie-child-theme' ); ?><span aria-hidden="true">→</span></a>
			</footer>
		</article>
	</div>
</div>
<?php if ( ! empty( $definition['faqs'] ) ) : ?>
	<script type="application/ld+json"><?php echo wp_json_encode( array( '@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => array_map( static fn( array $faq ): array => array( '@type' => 'Question', 'name' => $faq['question'], 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $faq['answer'] ) ), $definition['faqs'] ) ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON encoded structured data. ?></script>
<?php endif; ?>
<?php get_footer(); ?>
