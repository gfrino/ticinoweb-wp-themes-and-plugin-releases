<?php
/**
 * WooCommerce account surface.
 *
 * THESIS: il cliente vede identità, stato e prossima azione senza una hero promozionale.
 * OWN-WORLD: carta crema, ruggine, marrone caldo, oro misurato e linee sottili del sistema Oasi.
 * STORY: salutare il cliente, orientarlo nel Customer Hub e completare attività WooCommerce native.
 * FIRST VIEWPORT: testata compatta seguita immediatamente da navigazione e contenuto dell’endpoint.
 * FORM: spazio operativo a due aree su desktop e disclosure progressivo su mobile.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$is_logged_in = is_user_logged_in();
$user         = $is_logged_in ? wp_get_current_user() : null;
$display_name = $user instanceof WP_User ? trim( (string) ( $user->display_name ?: $user->user_login ) ) : '';
$role_label   = $user instanceof WP_User ? oasi_account_get_role_label( $user ) : '';
$initials     = $user instanceof WP_User ? oasi_account_get_initials( $user ) : '';
$shop_url     = oasi_account_get_shop_url();
?>

<div id="primary" class="oasi-account <?php echo $is_logged_in ? 'oasi-account--authenticated' : 'oasi-account--guest'; ?>">
	<section class="oasi-account-head" aria-labelledby="oasi-account-title">
		<div class="oasi-container oasi-account-head__inner">
			<div class="oasi-account-head__copy">
				<span class="oasi-account-kicker"><?php echo $is_logged_in ? esc_html__( 'Il tuo spazio Oasi', 'oasidellespezie-child-theme' ) : esc_html__( 'Account Oasi', 'oasidellespezie-child-theme' ); ?></span>
				<?php if ( $is_logged_in ) : ?>
					<h1 id="oasi-account-title"><?php echo esc_html( sprintf( __( 'Ciao, %s', 'oasidellespezie-child-theme' ), $display_name ) ); ?></h1>
					<p><?php esc_html_e( 'Ordini, indirizzi, vantaggi e dati del tuo account.', 'oasidellespezie-child-theme' ); ?></p>
				<?php else : ?>
					<h1 id="oasi-account-title"><?php esc_html_e( 'Bentornato nell’Oasi', 'oasidellespezie-child-theme' ); ?></h1>
					<p><?php esc_html_e( 'Accedi per seguire i tuoi ordini e gestire i dati di acquisto, oppure crea il tuo account.', 'oasidellespezie-child-theme' ); ?></p>
				<?php endif; ?>
			</div>

			<?php if ( $is_logged_in ) : ?>
				<div class="oasi-account-identity" aria-label="<?php esc_attr_e( 'Profilo attivo', 'oasidellespezie-child-theme' ); ?>">
					<span class="oasi-account-identity__monogram" aria-hidden="true"><?php echo esc_html( $initials ); ?></span>
					<span class="oasi-account-identity__details">
						<small><?php esc_html_e( 'Profilo', 'oasidellespezie-child-theme' ); ?></small>
						<strong><?php echo esc_html( $role_label ); ?></strong>
					</span>
				</div>
			<?php else : ?>
				<div class="oasi-account-head__aside">
					<span><?php esc_html_e( 'Nel tuo account', 'oasidellespezie-child-theme' ); ?></span>
					<ul>
						<li><?php esc_html_e( 'Controlli lo stato degli ordini', 'oasidellespezie-child-theme' ); ?></li>
						<li><?php esc_html_e( 'Salvi indirizzi e metodi di pagamento', 'oasidellespezie-child-theme' ); ?></li>
						<li><?php esc_html_e( 'Aggiorni i tuoi dati in autonomia', 'oasidellespezie-child-theme' ); ?></li>
					</ul>
				</div>
			<?php endif; ?>
		</div>
	</section>

	<section class="oasi-account__body <?php echo $is_logged_in ? 'oasi-account__body--authenticated' : 'oasi-account__body--guest'; ?>" aria-label="<?php esc_attr_e( 'Gestione account', 'oasidellespezie-child-theme' ); ?>">
		<div class="oasi-container">
			<?php echo do_shortcode( '[woocommerce_my_account]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Trusted WooCommerce shortcode output. ?>
		</div>
	</section>

	<section class="oasi-account-shop-link" aria-label="<?php esc_attr_e( 'Continua gli acquisti', 'oasidellespezie-child-theme' ); ?>">
		<div class="oasi-container oasi-account-shop-link__inner">
			<span><?php esc_html_e( 'Cerchi qualcosa di speciale?', 'oasidellespezie-child-theme' ); ?></span>
			<a href="<?php echo esc_url( $shop_url ); ?>">
				<?php esc_html_e( 'Torna allo Shop', 'oasidellespezie-child-theme' ); ?>
				<span aria-hidden="true">→</span>
			</a>
		</div>
	</section>
</div>

<?php get_footer(); ?>
