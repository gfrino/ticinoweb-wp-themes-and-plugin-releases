<?php
/**
 * Page not found: one H1 and useful ways back instead of an empty page.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$shop_url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );
?>
<div class="oasi-news-page oasi-not-found">
	<div class="oasi-container">
		<header class="oasi-news-intro">
			<span class="oasi-news-intro__kicker"><?php esc_html_e( 'Errore 404', 'oasidellespezie-child-theme' ); ?></span>
			<h1 class="oasi-news-intro__title"><?php esc_html_e( 'Pagina non trovata', 'oasidellespezie-child-theme' ); ?></h1>
			<p class="oasi-news-intro__desc"><?php esc_html_e( 'La pagina che cerchi non esiste più o è stata spostata. Puoi cercare un prodotto nel negozio o tornare alla home.', 'oasidellespezie-child-theme' ); ?></p>
		</header>

		<form class="oasi-not-found__search" role="search" method="get" action="<?php echo esc_url( $shop_url ); ?>">
			<label for="oasi-404-search" class="screen-reader-text"><?php esc_html_e( 'Cerca nel negozio', 'oasidellespezie-child-theme' ); ?></label>
			<input type="search" id="oasi-404-search" name="oasi_q" placeholder="<?php esc_attr_e( 'Cerca spezie, miscele, tè…', 'oasidellespezie-child-theme' ); ?>">
			<button type="submit" class="oasi-btn oasi-btn--primary"><?php esc_html_e( 'Cerca', 'oasidellespezie-child-theme' ); ?></button>
		</form>

		<p class="oasi-not-found__links">
			<a class="oasi-btn oasi-btn--secondary" href="<?php echo esc_url( $shop_url ); ?>"><?php esc_html_e( 'Vai al negozio', 'oasidellespezie-child-theme' ); ?></a>
			<a class="oasi-btn oasi-btn--secondary" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Torna alla home', 'oasidellespezie-child-theme' ); ?></a>
		</p>
	</div>
</div>
<?php
get_footer();
