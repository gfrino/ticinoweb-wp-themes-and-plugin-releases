<?php
/**
 * Product archive for Oasi delle Spezie.
 *
 * @package OasiDelleSpezieChild
 * @version 8.6.0
 */

defined( 'ABSPATH' ) || exit;

get_header( 'shop' );

$filters                  = oasi_shop_get_current_filters();
$category_banner_image_id = oasi_shop_get_category_banner_image_id();
$category_object          = is_product_category() ? get_queried_object() : null;
$category_image_alt       = $category_object instanceof WP_Term ? $category_object->name : woocommerce_page_title( false );
?>
<section class="oasi-shop" data-oasi-shop>
	<header class="oasi-shop__intro<?php echo $category_banner_image_id ? ' oasi-shop__intro--has-image' : ''; ?>">
		<?php if ( $category_banner_image_id ) : ?>
			<div class="oasi-shop__intro-media" aria-hidden="true">
				<?php
				echo wp_get_attachment_image(
					$category_banner_image_id,
					'full',
					false,
					array(
						'class'         => 'oasi-shop__intro-image',
						'alt'           => '',
						'loading'       => 'eager',
						'fetchpriority' => 'high',
						'decoding'      => 'async',
						'sizes'         => '100vw',
					)
				); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WordPress generates escaped attachment markup.
				?>
			</div>
		<?php endif; ?>
		<div class="oasi-container oasi-shop__intro-content">
			<?php woocommerce_breadcrumb(); ?>
			<p class="oasi-shop__eyebrow"><?php esc_html_e( 'Il catalogo del laboratorio', 'oasidellespezie-child-theme' ); ?></p>
			<h1><?php woocommerce_page_title(); ?></h1>
			<?php do_action( 'woocommerce_archive_description' ); ?>
		</div>
		<?php if ( $category_banner_image_id ) : ?>
			<figure class="oasi-shop__category-overlay">
				<?php
				echo wp_get_attachment_image(
					$category_banner_image_id,
					'medium_large',
					false,
					array(
						'alt'      => $category_image_alt,
						'loading'  => 'eager',
						'decoding' => 'async',
						'sizes'    => '(max-width: 820px) 70vw, (max-width: 1440px) 19vw, 270px',
					)
				); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WordPress generates escaped attachment markup.
				?>
			</figure>
		<?php endif; ?>
	</header>

	<div class="oasi-shop__toolbar-row oasi-container">
		<div class="oasi-shop__toolbar">
			<?php oasi_shop_render_toolbar( $filters ); ?>
		</div>
	</div>

	<div class="oasi-shop__layout oasi-container">
		<div class="oasi-shop__drawer-overlay" data-oasi-filter-close aria-hidden="true"></div>
		<aside class="oasi-shop__filters" id="oasi-shop-filters" aria-labelledby="oasi-shop-filter-title" data-oasi-filter-drawer>
			<?php oasi_shop_render_filters( $filters ); ?>
		</aside>

		<section class="oasi-shop__results" data-oasi-shop-results aria-live="polite" aria-busy="false">
			<?php oasi_shop_render_results(); ?>
		</section>
	</div>
</section>
<?php
get_footer( 'shop' );
