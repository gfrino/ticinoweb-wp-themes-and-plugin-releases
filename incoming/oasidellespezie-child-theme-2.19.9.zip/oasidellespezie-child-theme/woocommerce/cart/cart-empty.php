<?php
/**
 * Empty cart page.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 7.0.1
 */

defined( 'ABSPATH' ) || exit;
?>

<div class="oasi-cart-empty">
	<span class="oasi-cart-empty__mark" aria-hidden="true">O</span>
	<div class="oasi-cart-empty__copy">
		<h2><?php esc_html_e( 'Il tuo carrello è vuoto', 'oasidellespezie-child-theme' ); ?></h2>
		<?php do_action( 'woocommerce_cart_is_empty' ); ?>
		<p><?php esc_html_e( 'Esplora la selezione del laboratorio e scegli le spezie per il tuo prossimo ordine.', 'oasidellespezie-child-theme' ); ?></p>
	</div>

	<?php if ( wc_get_page_id( 'shop' ) > 0 ) : ?>
		<p class="return-to-shop">
			<a class="button wc-backward<?php echo esc_attr( wc_wp_theme_get_element_class_name( 'button' ) ? ' ' . wc_wp_theme_get_element_class_name( 'button' ) : '' ); ?>" href="<?php echo esc_url( apply_filters( 'woocommerce_return_to_shop_redirect', wc_get_page_permalink( 'shop' ) ) ); ?>">
				<?php echo esc_html( apply_filters( 'woocommerce_return_to_shop_text', __( 'Esplora lo shop', 'oasidellespezie-child-theme' ) ) ); ?>
			</a>
		</p>
	<?php endif; ?>
</div>
