<?php
/**
 * Checkout Form
 *
 * @see https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 9.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

do_action( 'woocommerce_before_checkout_form', $checkout );

if ( ! $checkout->is_registration_enabled() && $checkout->is_registration_required() && ! is_user_logged_in() ) {
	echo esc_html( apply_filters( 'woocommerce_checkout_must_be_logged_in_message', __( 'You must be logged in to checkout.', 'woocommerce' ) ) );
	return;
}
?>

<form name="checkout" method="post" class="checkout woocommerce-checkout" action="<?php echo esc_url( wc_get_checkout_url() ); ?>" enctype="multipart/form-data" aria-label="<?php echo esc_attr__( 'Checkout', 'woocommerce' ); ?>">
	<div class="oasi-checkout-layout">
		<section class="oasi-checkout-customer" aria-labelledby="oasi-checkout-customer-title">
			<div class="oasi-checkout-section-head">
				<span><?php esc_html_e( 'I tuoi dati', 'oasidellespezie-child-theme' ); ?></span>
				<h2 id="oasi-checkout-customer-title"><?php esc_html_e( 'Fatturazione e consegna', 'oasidellespezie-child-theme' ); ?></h2>
				<p><?php esc_html_e( 'I campi contrassegnati con * sono obbligatori.', 'oasidellespezie-child-theme' ); ?></p>
			</div>

			<?php if ( $checkout->get_checkout_fields() ) : ?>
				<?php do_action( 'woocommerce_checkout_before_customer_details' ); ?>

				<div class="col2-set" id="customer_details">
					<div class="col-1">
						<?php do_action( 'woocommerce_checkout_billing' ); ?>
					</div>

					<div class="col-2">
						<?php do_action( 'woocommerce_checkout_shipping' ); ?>
					</div>
				</div>

				<?php do_action( 'woocommerce_checkout_after_customer_details' ); ?>
			<?php endif; ?>
		</section>

		<aside class="oasi-checkout-summary" aria-labelledby="order_review_heading">
			<div class="oasi-checkout-summary__inner">
				<?php do_action( 'woocommerce_checkout_before_order_review_heading' ); ?>

				<div class="oasi-checkout-summary__head">
					<span><?php esc_html_e( 'Verifica finale', 'oasidellespezie-child-theme' ); ?></span>
					<h2 id="order_review_heading"><?php esc_html_e( 'Riepilogo ordine', 'oasidellespezie-child-theme' ); ?></h2>
				</div>

				<?php do_action( 'woocommerce_checkout_before_order_review' ); ?>

				<div id="order_review" class="woocommerce-checkout-review-order">
					<?php do_action( 'woocommerce_checkout_order_review' ); ?>
				</div>

				<?php do_action( 'woocommerce_checkout_after_order_review' ); ?>
			</div>
		</aside>
	</div>
</form>

<?php do_action( 'woocommerce_after_checkout_form', $checkout ); ?>
