<?php
/**
 * Customer Hub account shell.
 *
 * Keeps plugin output emitted by the navigation hooks inside the navigation
 * region so it cannot become a third item in the account layout grid.
 *
 * @package OasiDelleSpezieChild
 * @version 3.5.0
 */

defined( 'ABSPATH' ) || exit;
?>

<div class="oasi-account-hub">
	<div class="oasi-account-hub__navigation">
		<?php do_action( 'woocommerce_account_navigation' ); ?>
	</div>

	<div class="oasi-account-hub__content">
		<div class="woocommerce-MyAccount-content">
			<?php do_action( 'woocommerce_account_content' ); ?>
		</div>
	</div>
</div>
