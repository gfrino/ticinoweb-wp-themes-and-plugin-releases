<?php
/**
 * My Account navigation.
 *
 * @package OasiDelleSpezieChild
 * @version 9.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$account_items = oasi_account_get_navigation_items();
$current_label = oasi_account_get_current_navigation_label( $account_items );

do_action( 'woocommerce_before_account_navigation' );
?>

<nav class="woocommerce-MyAccount-navigation" aria-label="<?php esc_attr_e( 'Pagine account', 'oasidellespezie-child-theme' ); ?>">
	<p class="oasi-account-nav__label"><?php esc_html_e( 'Il mio account', 'oasidellespezie-child-theme' ); ?></p>
	<button class="oasi-account-nav__toggle" type="button" aria-expanded="false" aria-controls="oasi-account-navigation-list">
		<span>
			<small><?php esc_html_e( 'Il mio account', 'oasidellespezie-child-theme' ); ?></small>
			<strong><?php echo esc_html( $current_label ); ?></strong>
		</span>
		<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m7 9 5 5 5-5"/></svg>
	</button>
	<ul id="oasi-account-navigation-list">
		<?php foreach ( $account_items as $endpoint => $label ) : ?>
			<li class="<?php echo esc_attr( wc_get_account_menu_item_classes( $endpoint ) ); ?>">
				<a href="<?php echo esc_url( wc_get_account_endpoint_url( $endpoint ) ); ?>" <?php echo wc_is_current_account_menu_item( $endpoint ) ? 'aria-current="page"' : ''; ?>>
					<span class="oasi-account-nav__icon"><?php echo oasi_account_get_navigation_icon( $endpoint ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Internal SVG map. ?></span>
					<span><?php echo esc_html( $label ); ?></span>
				</a>
			</li>
		<?php endforeach; ?>
	</ul>
</nav>

<?php do_action( 'woocommerce_after_account_navigation' ); ?>
