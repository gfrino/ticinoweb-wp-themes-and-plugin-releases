<?php
/**
 * Customer Hub dashboard.
 *
 * @package OasiDelleSpezieChild
 * @version 4.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$current_user   = $current_user instanceof WP_User ? $current_user : wp_get_current_user();
$dashboard_data = oasi_account_get_dashboard_data( $current_user );
$account_items  = oasi_account_get_navigation_items();
$metrics        = array(
	array(
		'label' => __( 'Ordini', 'oasidellespezie-child-theme' ),
		'value' => (string) $dashboard_data['order_count'],
		'url'   => wc_get_endpoint_url( 'orders' ),
	),
);

if ( null !== $dashboard_data['points'] ) {
	$metrics[] = array(
		'label' => __( 'Punti fedeltà', 'oasidellespezie-child-theme' ),
		'value' => number_format_i18n( (int) $dashboard_data['points'] ),
		'url'   => isset( $account_items['points-history'] ) ? wc_get_endpoint_url( 'points-history' ) : '',
	);
}

if ( null !== $dashboard_data['store_credit'] ) {
	$store_credit_endpoint = '';
	foreach ( array_keys( $account_items ) as $endpoint ) {
		if ( str_contains( (string) $endpoint, 'store-credit' ) ) {
			$store_credit_endpoint = (string) $endpoint;
			break;
		}
	}
	$metrics[] = array(
		'label' => __( 'Store Credit', 'oasidellespezie-child-theme' ),
		'value' => wc_price( (float) $dashboard_data['store_credit'] ),
		'url'   => $store_credit_endpoint ? wc_get_endpoint_url( $store_credit_endpoint ) : '',
	);
}

$benefit_items = array();
foreach ( $account_items as $endpoint => $label ) {
	$endpoint = (string) $endpoint;
	if ( str_contains( $endpoint, 'point' ) || str_contains( $endpoint, 'credit' ) || str_contains( $endpoint, 'coupon' ) || str_contains( $endpoint, 'mycred' ) ) {
		$benefit_items[ $endpoint ] = (string) $label;
	}
}
?>

<section class="oasi-account-dashboard" aria-labelledby="oasi-account-dashboard-title">
	<header class="oasi-account-dashboard__intro">
		<div>
			<span><?php esc_html_e( 'Panoramica', 'oasidellespezie-child-theme' ); ?></span>
			<h2 id="oasi-account-dashboard-title"><?php esc_html_e( 'Il tuo account, a colpo d’occhio.', 'oasidellespezie-child-theme' ); ?></h2>
		</div>
		<p><?php esc_html_e( 'Qui trovi le informazioni più utili per gestire i tuoi acquisti.', 'oasidellespezie-child-theme' ); ?></p>
	</header>

	<div class="oasi-account-summary" aria-label="<?php esc_attr_e( 'Riepilogo account', 'oasidellespezie-child-theme' ); ?>">
		<?php foreach ( $metrics as $metric ) : ?>
			<?php $metric_tag = $metric['url'] ? 'a' : 'div'; ?>
			<<?php echo esc_html( $metric_tag ); ?> class="oasi-account-summary__item"<?php echo $metric['url'] ? ' href="' . esc_url( $metric['url'] ) . '"' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<span><?php echo esc_html( $metric['label'] ); ?></span>
				<strong><?php echo wp_kses_post( $metric['value'] ); ?></strong>
			</<?php echo esc_html( $metric_tag ); ?>>
		<?php endforeach; ?>
	</div>

	<div class="oasi-account-dashboard__grid">
		<section class="oasi-account-panel oasi-account-panel--orders" aria-labelledby="oasi-recent-orders-title">
			<header class="oasi-account-panel__header">
				<div>
					<span><?php esc_html_e( 'Acquisti', 'oasidellespezie-child-theme' ); ?></span>
					<h3 id="oasi-recent-orders-title"><?php esc_html_e( 'Ultimi ordini', 'oasidellespezie-child-theme' ); ?></h3>
				</div>
				<a href="<?php echo esc_url( wc_get_endpoint_url( 'orders' ) ); ?>"><?php esc_html_e( 'Vedi tutti', 'oasidellespezie-child-theme' ); ?> <span aria-hidden="true">→</span></a>
			</header>

			<?php if ( ! empty( $dashboard_data['recent_orders'] ) ) : ?>
				<div class="oasi-account-orders-list">
					<?php foreach ( $dashboard_data['recent_orders'] as $order ) : ?>
						<?php if ( ! is_object( $order ) || ! is_callable( array( $order, 'get_id' ) ) ) { continue; } ?>
						<article class="oasi-account-order">
							<div class="oasi-account-order__number">
								<span><?php esc_html_e( 'Ordine', 'oasidellespezie-child-theme' ); ?></span>
								<strong>#<?php echo esc_html( $order->get_order_number() ); ?></strong>
							</div>
							<div><span><?php esc_html_e( 'Data', 'oasidellespezie-child-theme' ); ?></span><strong><?php echo esc_html( wc_format_datetime( $order->get_date_created() ) ); ?></strong></div>
							<div><span><?php esc_html_e( 'Stato', 'oasidellespezie-child-theme' ); ?></span><strong class="oasi-order-status oasi-order-status--<?php echo esc_attr( $order->get_status() ); ?>"><?php echo esc_html( wc_get_order_status_name( $order->get_status() ) ); ?></strong></div>
							<div><span><?php esc_html_e( 'Totale', 'oasidellespezie-child-theme' ); ?></span><strong><?php echo wp_kses_post( $order->get_formatted_order_total() ); ?></strong></div>
							<a class="oasi-account-order__action" href="<?php echo esc_url( $order->get_view_order_url() ); ?>"><?php esc_html_e( 'Dettagli', 'oasidellespezie-child-theme' ); ?></a>
						</article>
					<?php endforeach; ?>
				</div>
			<?php else : ?>
				<div class="oasi-account-empty"><p><?php esc_html_e( 'Non hai ancora effettuato ordini.', 'oasidellespezie-child-theme' ); ?></p><a class="button" href="<?php echo esc_url( oasi_account_get_shop_url() ); ?>"><?php esc_html_e( 'Scopri lo Shop', 'oasidellespezie-child-theme' ); ?></a></div>
			<?php endif; ?>
		</section>

		<div class="oasi-account-dashboard__side">
			<section class="oasi-account-panel" aria-labelledby="oasi-address-title">
				<header class="oasi-account-panel__header"><div><span><?php esc_html_e( 'Consegna', 'oasidellespezie-child-theme' ); ?></span><h3 id="oasi-address-title"><?php esc_html_e( 'Indirizzo principale', 'oasidellespezie-child-theme' ); ?></h3></div><a href="<?php echo esc_url( wc_get_endpoint_url( 'edit-address', 'billing' ) ); ?>"><?php esc_html_e( 'Modifica', 'oasidellespezie-child-theme' ); ?></a></header>
				<?php if ( $dashboard_data['billing_address'] ) : ?><address><?php echo wp_kses_post( $dashboard_data['billing_address'] ); ?></address><?php else : ?><p><?php esc_html_e( 'Aggiungi un indirizzo di fatturazione per velocizzare il prossimo ordine.', 'oasidellespezie-child-theme' ); ?></p><?php endif; ?>
			</section>

			<section class="oasi-account-panel" aria-labelledby="oasi-payment-title">
				<header class="oasi-account-panel__header"><div><span><?php esc_html_e( 'Checkout', 'oasidellespezie-child-theme' ); ?></span><h3 id="oasi-payment-title"><?php esc_html_e( 'Metodi di pagamento', 'oasidellespezie-child-theme' ); ?></h3></div><a href="<?php echo esc_url( wc_get_endpoint_url( 'payment-methods' ) ); ?>"><?php esc_html_e( 'Gestisci', 'oasidellespezie-child-theme' ); ?></a></header>
				<?php if ( ! empty( $dashboard_data['payment_tokens'] ) ) : ?><p><?php echo esc_html( sprintf( _n( '%d metodo salvato in modo sicuro.', '%d metodi salvati in modo sicuro.', count( $dashboard_data['payment_tokens'] ), 'oasidellespezie-child-theme' ), count( $dashboard_data['payment_tokens'] ) ) ); ?></p><?php else : ?><p><?php esc_html_e( 'Non risultano metodi di pagamento salvati.', 'oasidellespezie-child-theme' ); ?></p><?php endif; ?>
			</section>
		</div>
	</div>

	<?php if ( $benefit_items ) : ?>
		<section class="oasi-account-benefits" aria-labelledby="oasi-benefits-title">
			<div><span><?php esc_html_e( 'Vantaggi', 'oasidellespezie-child-theme' ); ?></span><h3 id="oasi-benefits-title"><?php esc_html_e( 'I tuoi vantaggi Oasi', 'oasidellespezie-child-theme' ); ?></h3></div>
			<nav aria-label="<?php esc_attr_e( 'Vantaggi account', 'oasidellespezie-child-theme' ); ?>">
				<?php foreach ( $benefit_items as $endpoint => $label ) : ?><a href="<?php echo esc_url( wc_get_endpoint_url( $endpoint ) ); ?>"><?php echo esc_html( $label ); ?> <span aria-hidden="true">→</span></a><?php endforeach; ?>
			</nav>
		</section>
	<?php endif; ?>
</section>

<?php
$points_hook_priority = function_exists( 'has_action' ) ? has_action( 'woocommerce_account_dashboard', 'PA_show_points_in_account' ) : false;
if ( false !== $points_hook_priority && function_exists( 'remove_action' ) ) {
	remove_action( 'woocommerce_account_dashboard', 'PA_show_points_in_account', (int) $points_hook_priority );
}
do_action( 'woocommerce_account_dashboard' );
if ( false !== $points_hook_priority && function_exists( 'add_action' ) ) {
	add_action( 'woocommerce_account_dashboard', 'PA_show_points_in_account', (int) $points_hook_priority );
}
do_action( 'woocommerce_before_my_account' );
do_action( 'woocommerce_after_my_account' );
