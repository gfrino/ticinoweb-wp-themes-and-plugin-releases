<?php
/**
 * Single Product template for Oasi delle Spezie.
 *
 * @package OasiDelleSpezieChild
 * @version 1.6.4
 */

defined( 'ABSPATH' ) || exit;

get_header( 'shop' );
?>
<div class="oasi-single-product-page">
	<div class="oasi-container">
		<?php
		/**
		 * Hook: woocommerce_before_main_content.
		 *
		 * @hooked woocommerce_output_content_wrapper - 10
		 * @hooked woocommerce_breadcrumb - 20
		 */
		do_action( 'woocommerce_before_main_content' );
		?>

		<?php while ( have_posts() ) : ?>
			<?php the_post(); ?>

			<?php wc_get_template_part( 'content', 'single-product' ); ?>

		<?php endwhile; ?>

		<?php
		/**
		 * Hook: woocommerce_after_main_content.
		 *
		 * @hooked woocommerce_output_content_wrapper_end - 10
		 */
		do_action( 'woocommerce_after_main_content' );
		?>
	</div>
</div>
<?php
get_footer( 'shop' );
