<?php
/**
 * Product card used by the Oasi catalog loop.
 *
 * @package OasiDelleSpezieChild
 * @version 9.4.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

if ( ! is_a( $product, WC_Product::class ) || ! $product->is_visible() ) {
	return;
}
?>
<li <?php wc_product_class( 'oasi-catalog-card', $product ); ?>>
	<?php do_action( 'woocommerce_before_shop_loop_item' ); ?>

	<div class="oasi-catalog-card__media">
		<?php do_action( 'woocommerce_before_shop_loop_item_title' ); ?>
		<?php if ( function_exists( 'oasi_render_sold_out_badge' ) ) { oasi_render_sold_out_badge( $product ); } ?>
	</div>

	<div class="oasi-catalog-card__body">
		<?php if ( function_exists( 'wc_get_product_category_list' ) ) : ?>
			<div class="oasi-catalog-card__category">
				<?php echo esc_html( wp_strip_all_tags( wc_get_product_category_list( $product->get_id(), ', ' ) ) ); ?>
			</div>
		<?php endif; ?>

		<?php do_action( 'woocommerce_shop_loop_item_title' ); ?>
		<?php do_action( 'woocommerce_after_shop_loop_item_title' ); ?>
	</div>

	<?php do_action( 'woocommerce_after_shop_loop_item' ); ?>
</li>
