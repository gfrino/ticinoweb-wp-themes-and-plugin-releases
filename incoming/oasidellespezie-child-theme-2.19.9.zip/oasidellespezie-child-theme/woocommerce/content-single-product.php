<?php
/**
 * Single Product content template for Oasi delle Spezie.
 *
 * @package OasiDelleSpezieChild
 * @version 3.6.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

if ( ! $product instanceof WC_Product ) {
	return;
}

/**
 * Hook: woocommerce_before_single_product.
 *
 * @hooked woocommerce_output_all_notices - 10
 */
do_action( 'woocommerce_before_single_product' );

if ( post_password_required() ) {
	echo get_the_password_form(); // WPCS: XSS ok.
	return;
}

$parsed_content = oasi_parse_product_specification_fields( $product );
$specs          = $parsed_content['specs'];
$narrative      = $parsed_content['narrative'];
$disclaimer     = $parsed_content['disclaimer'];
$is_variable    = $product->is_type( 'variable' );
$sku            = $product->get_sku();
$stock_status   = $product->get_stock_status();
$in_stock       = $product->is_in_stock();
?>
<article id="product-<?php the_ID(); ?>" <?php wc_product_class( 'oasi-single-product', $product ); ?>>

	<?php
	// 1. Category Banner Compatto
	if ( function_exists( 'oasi_render_product_category_banner' ) ) {
		oasi_render_product_category_banner( $product );
	}
	?>

	<!-- 2. Main Product Showcase -->
	<div class="oasi-product-showcase">
		<!-- Left Column: Balanced Media & Gallery -->
		<div class="oasi-product-showcase__media-col">
			<?php
			if ( function_exists( 'oasi_render_product_media' ) ) {
				oasi_render_product_media( $product );
			}
			?>
		</div>

		<!-- Right Column: Editorial Summary, Purchase Flow & Trust -->
		<div class="oasi-product-showcase__summary-col">
			<div class="oasi-product-summary">
				<header class="oasi-product-summary__header">
					<div class="oasi-product-summary__meta-top">
						<?php if ( ! empty( $sku ) ) : ?>
							<span class="oasi-product-summary__sku">
								<?php esc_html_e( 'COD:', 'oasidellespezie-child-theme' ); ?>
								<strong><?php echo esc_html( $sku ); ?></strong>
							</span>
						<?php endif; ?>

						<?php if ( $in_stock ) : ?>
							<span class="oasi-product-summary__stock oasi-product-summary__stock--in">
								<span class="oasi-product-summary__stock-dot" aria-hidden="true"></span>
								<?php esc_html_e( 'Disponibile in laboratorio', 'oasidellespezie-child-theme' ); ?>
							</span>
						<?php else : ?>
							<span class="oasi-product-summary__stock oasi-product-summary__stock--out">
								<span class="oasi-product-summary__stock-dot" aria-hidden="true"></span>
								<?php esc_html_e( 'Momentaneamente esaurito', 'oasidellespezie-child-theme' ); ?>
							</span>
						<?php endif; ?>
					</div>

					<h1 class="oasi-product-summary__title product_title entry-title">
						<?php the_title(); ?>
					</h1>

					<div class="oasi-product-summary__price-wrap">
						<?php woocommerce_template_single_price(); ?>
					</div>

					<?php if ( has_excerpt() || ! empty( $product->get_short_description() ) ) : ?>
						<div class="oasi-product-summary__excerpt">
							<?php woocommerce_template_single_excerpt(); ?>
						</div>
					<?php endif; ?>
				</header>

				<!-- Clear Purchase Flow -->
				<div class="oasi-purchase-card">
					<div class="oasi-purchase-card__flow-label">
						<span class="oasi-purchase-card__flow-step">1</span>
						<span class="oasi-purchase-card__flow-text">
							<?php echo $is_variable ? esc_html__( 'Scegli il formato e la quantità', 'oasidellespezie-child-theme' ) : esc_html__( 'Imposta quantità e aggiungi al carrello', 'oasidellespezie-child-theme' ); ?>
						</span>
					</div>

					<div class="oasi-purchase-card__form">
						<?php woocommerce_template_single_add_to_cart(); ?>
					</div>
				</div>

				<!-- Trust & Reassurance Block -->
				<?php
				if ( function_exists( 'oasi_render_product_trust_box' ) ) {
					oasi_render_product_trust_box();
				}
				?>
			</div>
		</div>
	</div>

	<!-- 3. Product Contents & Technical Specifications -->
	<?php if ( ! empty( $specs ) || ! empty( $narrative ) ) : ?>
		<section class="oasi-product-details">
			<div class="oasi-product-details__container">
				<?php if ( ! empty( $specs ) ) : ?>
					<div class="oasi-product-specs">
						<header class="oasi-product-specs__header">
							<div class="oasi-product-specs__badge">
								<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
									<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
								</svg>
								<span><?php esc_html_e( 'Scheda Botanica & Artigianale', 'oasidellespezie-child-theme' ); ?></span>
							</div>
							<h2 class="oasi-product-specs__title">
								<?php esc_html_e( 'Caratteristiche & Proprietà', 'oasidellespezie-child-theme' ); ?>
							</h2>
						</header>

						<div class="oasi-product-specs__grid">
							<?php foreach ( $specs as $spec_key => $spec_data ) : ?>
								<div class="oasi-spec-card oasi-spec-card--<?php echo esc_attr( $spec_key ); ?>">
									<div class="oasi-spec-card__icon-wrap" aria-hidden="true">
										<?php oasi_render_spec_icon_svg( $spec_data['icon'] ); ?>
									</div>
									<div class="oasi-spec-card__body">
										<span class="oasi-spec-card__label"><?php echo esc_html( $spec_data['label'] ); ?></span>
										<div class="oasi-spec-card__value"><?php echo wp_kses_post( $spec_data['value'] ); ?></div>
									</div>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				<?php endif; ?>

				<?php if ( ! empty( $narrative ) ) : ?>
					<div class="oasi-product-narrative">
						<h3 class="oasi-product-narrative__title">
							<?php esc_html_e( 'Note del Maestro Speziere', 'oasidellespezie-child-theme' ); ?>
						</h3>
						<div class="oasi-product-narrative__content entry-content">
							<?php echo wp_kses_post( wpautop( $narrative ) ); ?>
						</div>
					</div>
				<?php endif; ?>

				<?php if ( ! empty( $disclaimer ) ) : ?>
					<div class="oasi-product-disclaimer">
						<svg class="oasi-product-disclaimer__icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
							<circle cx="12" cy="12" r="10"></circle>
							<line x1="12" y1="16" x2="12" y2="12"></line>
							<line x1="12" y1="8" x2="12.01" y2="8"></line>
						</svg>
						<p><?php echo esc_html( $disclaimer ); ?></p>
					</div>
				<?php endif; ?>
			</div>
		</section>
	<?php endif; ?>

	<!-- 4. Related Products -->
	<?php
	if ( function_exists( 'oasi_render_related_products_section' ) ) {
		oasi_render_related_products_section( $product );
	}
	?>

</article>

<?php do_action( 'woocommerce_after_single_product' ); ?>
