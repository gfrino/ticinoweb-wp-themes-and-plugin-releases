<?php
/**
 * Blog archives (categories, tags, authors, dates) with one H1 and excerpts.
 *
 * Replaces the parent index.php fallback, which printed every post in full with
 * its own H1 (duplicate content and many H1s on a single page).
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>
<div class="oasi-news-page">
	<div class="oasi-container">
		<header class="oasi-news-intro">
			<span class="oasi-news-intro__kicker"><?php esc_html_e( 'Dal mondo di Oasi', 'oasidellespezie-child-theme' ); ?></span>
			<h1 class="oasi-news-intro__title"><?php echo esc_html( wp_strip_all_tags( get_the_archive_title() ) ); ?></h1>
			<?php if ( get_the_archive_description() ) : ?>
				<div class="oasi-news-intro__desc"><?php echo wp_kses_post( get_the_archive_description() ); ?></div>
			<?php endif; ?>
		</header>

		<?php if ( have_posts() ) : ?>
			<div class="oasi-news-grid">
				<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/archive/post-card' );
				endwhile;
				?>
			</div>
			<?php the_posts_pagination( array( 'mid_size' => 1 ) ); ?>
		<?php else : ?>
			<p><?php esc_html_e( 'Non ci sono ancora contenuti in questa sezione.', 'oasidellespezie-child-theme' ); ?></p>
		<?php endif; ?>
	</div>
</div>
<?php
get_footer();
