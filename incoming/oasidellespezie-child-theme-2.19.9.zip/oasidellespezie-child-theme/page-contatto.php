<?php
/**
 * Template Name: Oasi — Contatti
 *
 * Editorial Contact page focused on direct channels, laboratory hours and pickup.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$contact  = oasi_get_contact_page_data();
$shop_url = function_exists( 'wc_get_page_id' ) && wc_get_page_id( 'shop' ) > 0
	? get_permalink( wc_get_page_id( 'shop' ) )
	: home_url( '/shop-online-oasi-delle-spezie/' );

$kicker = ! empty( $contact['city'] )
	? sprintf( __( 'Laboratorio artigianale · %s', 'oasidellespezie-child-theme' ), $contact['city'] )
	: __( 'Laboratorio artigianale', 'oasidellespezie-child-theme' );

$intro_text = ! empty( $contact['intro'] )
	? $contact['intro']
	: __( 'Siamo un laboratorio artigianale dedicato alla creazione e al confezionamento di spezie pure, erbe e miscele esclusive. Siamo a tua completa disposizione per informazioni, consigli e ordini.', 'oasidellespezie-child-theme' );
?>

<div id="primary" class="oasi-contact">
	<!-- Hero / Header Section -->
	<section class="oasi-contact-hero" aria-labelledby="oasi-contact-title">
		<div class="oasi-container oasi-contact-hero__inner">
			<span class="oasi-contact-eyebrow"><?php echo esc_html( $kicker ); ?></span>
			<h1 id="oasi-contact-title" class="oasi-contact-title"><?php esc_html_e( 'Contatti', 'oasidellespezie-child-theme' ); ?></h1>
			<div class="oasi-contact-divider" aria-hidden="true"></div>
			<p class="oasi-contact-lead"><?php echo esc_html( $intro_text ); ?></p>
		</div>
	</section>

	<section class="oasi-contact-main" aria-label="<?php esc_attr_e( 'Canali di contatto e orari', 'oasidellespezie-child-theme' ); ?>">
		<div class="oasi-container">
			<!-- 3 Direct Channels Grid -->
			<div class="oasi-contact-channels" aria-label="<?php esc_attr_e( 'Recapiti diretti', 'oasidellespezie-child-theme' ); ?>">
				<!-- Channel 1: Telefono -->
				<div class="oasi-contact-channel-card">
					<div class="oasi-contact-channel-card__header">
						<span class="oasi-contact-channel-card__icon" aria-hidden="true">
							<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.8 19.8 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.8 19.8 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.12.9.36 1.78.7 2.61a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.47-1.27a2 2 0 0 1 2.11-.45c.83.34 1.71.58 2.61.7A2 2 0 0 1 22 16.92z"/></svg>
						</span>
						<span class="oasi-contact-channel-card__tag"><?php esc_html_e( 'Consulenza diretta', 'oasidellespezie-child-theme' ); ?></span>
					</div>
					<div class="oasi-contact-channel-card__body">
						<h3><?php esc_html_e( 'Telefono', 'oasidellespezie-child-theme' ); ?></h3>
						<p class="oasi-contact-channel-card__value"><?php echo esc_html( $contact['phone'] ); ?></p>
						<p class="oasi-contact-channel-card__desc"><?php esc_html_e( 'Per consigli sulle spezie, disponibilità prodotti o chiarimenti immediati.', 'oasidellespezie-child-theme' ); ?></p>
					</div>
					<div class="oasi-contact-channel-card__footer">
						<a class="oasi-contact-channel-card__btn" href="tel:<?php echo esc_attr( $contact['phone_tel'] ); ?>">
							<span><?php esc_html_e( 'Chiama subito', 'oasidellespezie-child-theme' ); ?></span>
							<span class="oasi-arrow" aria-hidden="true">↗</span>
						</a>
					</div>
				</div>

				<!-- Channel 2: Email -->
				<div class="oasi-contact-channel-card">
					<div class="oasi-contact-channel-card__header">
						<span class="oasi-contact-channel-card__icon" aria-hidden="true">
							<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><path d="m22 6-10 7L2 6"/></svg>
						</span>
						<span class="oasi-contact-channel-card__tag"><?php esc_html_e( 'Scrivici sempre', 'oasidellespezie-child-theme' ); ?></span>
					</div>
					<div class="oasi-contact-channel-card__body">
						<h3><?php esc_html_e( 'Email', 'oasidellespezie-child-theme' ); ?></h3>
						<p class="oasi-contact-channel-card__value"><?php echo esc_html( antispambot( $contact['email'] ) ); ?></p>
						<p class="oasi-contact-channel-card__desc"><?php esc_html_e( 'Per richieste personalizzate, ordini per professionisti o informazioni generali.', 'oasidellespezie-child-theme' ); ?></p>
					</div>
					<div class="oasi-contact-channel-card__footer">
						<a class="oasi-contact-channel-card__btn" href="mailto:<?php echo esc_attr( antispambot( $contact['email'] ) ); ?>">
							<span><?php esc_html_e( 'Invia un’email', 'oasidellespezie-child-theme' ); ?></span>
							<span class="oasi-arrow" aria-hidden="true">↗</span>
						</a>
					</div>
				</div>

				<!-- Channel 3: Sede & Ritiro -->
				<div class="oasi-contact-channel-card">
					<div class="oasi-contact-channel-card__header">
						<span class="oasi-contact-channel-card__icon" aria-hidden="true">
							<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 12-9 12S3 17 3 10a9 9 0 1 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
						</span>
						<span class="oasi-contact-channel-card__tag"><?php esc_html_e( 'Sede laboratorio', 'oasidellespezie-child-theme' ); ?></span>
					</div>
					<div class="oasi-contact-channel-card__body">
						<h3><?php esc_html_e( 'Laboratorio', 'oasidellespezie-child-theme' ); ?></h3>
						<p class="oasi-contact-channel-card__value"><?php echo esc_html( $contact['address'] ); ?></p>
						<p class="oasi-contact-channel-card__desc"><?php esc_html_e( 'Sede artigianale a Gudo per il ritiro ordini concordati.', 'oasidellespezie-child-theme' ); ?></p>
					</div>
					<div class="oasi-contact-channel-card__footer">
						<a class="oasi-contact-channel-card__btn" href="<?php echo esc_url( $contact['maps_url'] ); ?>" target="_blank" rel="noopener noreferrer">
							<span><?php esc_html_e( 'Apri su Google Maps', 'oasidellespezie-child-theme' ); ?></span>
							<span class="oasi-arrow" aria-hidden="true">↗</span>
						</a>
					</div>
				</div>
			</div>

			<!-- Contact form: handled by the parent theme (ticinoweb_submit_form) -->
			<?php get_template_part( 'template-parts/contact/form' ); ?>

			<!-- 2 Balanced Information Panels: Orari & Ritiro -->
			<div class="oasi-contact-panels">
				<!-- Panel 1: Orari -->
				<div class="oasi-contact-panel oasi-contact-panel--hours">
					<div class="oasi-contact-panel__header">
						<span class="oasi-contact-panel__icon" aria-hidden="true">
							<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>
						</span>
						<div>
							<span class="oasi-contact-panel__kicker"><?php esc_html_e( 'Disponibilità settimanale', 'oasidellespezie-child-theme' ); ?></span>
							<h2 class="oasi-contact-panel__title"><?php esc_html_e( 'Orari del Laboratorio', 'oasidellespezie-child-theme' ); ?></h2>
						</div>
					</div>

					<div class="oasi-contact-hours-table">
						<?php foreach ( $contact['hours_days'] as $day ) : ?>
							<div class="oasi-contact-hours-row<?php echo 'Domenica' === $day['label'] ? ' is-closed' : ''; ?>">
								<span class="oasi-contact-hours-day"><?php echo esc_html( $day['label'] ); ?></span>
								<span class="oasi-contact-hours-time"><?php echo esc_html( $day['hours'] ); ?></span>
							</div>
						<?php endforeach; ?>
					</div>

					<?php if ( ! empty( $contact['hours_note'] ) ) : ?>
						<p class="oasi-contact-panel__note"><?php echo esc_html( $contact['hours_note'] ); ?></p>
					<?php else : ?>
						<p class="oasi-contact-panel__note"><?php esc_html_e( 'Gli orari si riferiscono alla disponibilità telefonica e al servizio di ritiro concordato in sede.', 'oasidellespezie-child-theme' ); ?></p>
					<?php endif; ?>
				</div>

				<!-- Panel 2: Guida al Ritiro & Visite -->
				<div class="oasi-contact-panel oasi-contact-panel--pickup">
					<div class="oasi-contact-panel__header">
						<span class="oasi-contact-panel__icon oasi-contact-panel__icon--accent" aria-hidden="true">
							<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>
						</span>
						<div>
							<span class="oasi-contact-panel__kicker"><?php esc_html_e( 'Informazioni utili', 'oasidellespezie-child-theme' ); ?></span>
							<h2 class="oasi-contact-panel__title"><?php esc_html_e( 'Laboratorio e Ritiro Ordini', 'oasidellespezie-child-theme' ); ?></h2>
						</div>
					</div>

					<div class="oasi-contact-pickup-cards">
						<div class="oasi-contact-pickup-card">
							<span class="oasi-contact-pickup-card__icon" aria-hidden="true">🏺</span>
							<div>
								<strong><?php esc_html_e( 'Atelier artigianale (non negozio su strada)', 'oasidellespezie-child-theme' ); ?></strong>
								<p><?php esc_html_e( 'Non abbiamo vetrina su strada: il nostro spazio è un laboratorio dedicato alla selezione, macinatura su misura e confezionamento ermetico dei prodotti.', 'oasidellespezie-child-theme' ); ?></p>
							</div>
						</div>

						<div class="oasi-contact-pickup-card">
							<span class="oasi-contact-pickup-card__icon" aria-hidden="true">📦</span>
							<div>
								<strong><?php esc_html_e( 'Ritiro in sede', 'oasidellespezie-child-theme' ); ?></strong>
								<p><?php echo ! empty( $contact['pickup_note'] ) ? esc_html( $contact['pickup_note'] ) : esc_html__( 'Il ritiro in sede è disponibile previo ordine online o accordo telefonico.', 'oasidellespezie-child-theme' ); ?></p>
							</div>
						</div>

						<div class="oasi-contact-pickup-card">
							<span class="oasi-contact-pickup-card__icon" aria-hidden="true">🗣️</span>
							<div>
								<strong><?php esc_html_e( 'Lingue di contatto', 'oasidellespezie-child-theme' ); ?></strong>
								<p><?php esc_html_e( 'Al telefono e per iscritto parliamo correntemente italiano e francese.', 'oasidellespezie-child-theme' ); ?></p>
							</div>
						</div>
					</div>
				</div>
			</div>

			<!-- Bottom CTA Banner: Shop Bridge -->
			<div class="oasi-contact-cta-banner">
				<div class="oasi-contact-cta-banner__content">
					<span class="oasi-contact-cta-banner__eyebrow"><?php esc_html_e( 'Spedizioni in tutta la Svizzera', 'oasidellespezie-child-theme' ); ?></span>
					<h2 class="oasi-contact-cta-banner__title"><?php esc_html_e( 'Desideri acquistare le nostre spezie e miscele?', 'oasidellespezie-child-theme' ); ?></h2>
					<p class="oasi-contact-cta-banner__text"><?php esc_html_e( 'Scopri il catalogo completo online con oltre 45 categorie, dai pepi rari alle creazioni MIXTIS biologiche.', 'oasidellespezie-child-theme' ); ?></p>
				</div>
				<div class="oasi-contact-cta-banner__action">
					<a href="<?php echo esc_url( $shop_url ); ?>" class="oasi-btn oasi-btn--primary">
						<span><?php esc_html_e( 'Esplora lo Shop Online', 'oasidellespezie-child-theme' ); ?></span>
						<span aria-hidden="true">→</span>
					</a>
				</div>
			</div>
		</div>
	</section>
</div>

<?php get_footer(); ?>
