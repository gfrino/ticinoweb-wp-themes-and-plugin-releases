<?php
/**
 * Template Name: Oasi — Novità
 *
 * Culinary magazine archive template for Oasi delle Spezie news, recipes, and stories.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$categories = oasi_news_get_categories();
$news_query = oasi_news_query();
$total_posts = $news_query->found_posts;
?>

<div class="oasi-news-page">
	<div class="oasi-container">

		<!-- 1. Breadcrumb -->
		<nav class="oasi-news-breadcrumb" aria-label="<?php esc_attr_e( 'Percorso di navigazione', 'oasidellespezie-child-theme' ); ?>">
			<ol class="oasi-news-breadcrumb__list">
				<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'oasidellespezie-child-theme' ); ?></a></li>
				<li aria-hidden="true">/</li>
				<li aria-current="page"><?php esc_html_e( 'Novità', 'oasidellespezie-child-theme' ); ?></li>
			</ol>
		</nav>

		<!-- 2. Compact Editorial Intro -->
		<header class="oasi-news-intro">
			<span class="oasi-news-intro__kicker"><?php esc_html_e( 'NOVITÀ · RICETTE · ISPIRAZIONI', 'oasidellespezie-child-theme' ); ?></span>
			<h1 class="oasi-news-intro__title"><?php esc_html_e( 'Dal mondo di Oasi', 'oasidellespezie-child-theme' ); ?></h1>
			<p class="oasi-news-intro__desc">
				<?php esc_html_e( 'Racconti dal nostro laboratorio artigianale, ricette gourmet con spezie pure e consigli per arricchire la tavola con aromi autentici da tutto il mondo.', 'oasidellespezie-child-theme' ); ?>
			</p>
		</header>

		<!-- 3. Dynamic Category Filters -->
		<?php if ( ! empty( $categories ) ) : ?>
			<nav class="oasi-news-filter" aria-label="<?php esc_attr_e( 'Filtra articoli per categoria', 'oasidellespezie-child-theme' ); ?>">
				<ul class="oasi-news-filter__list">
					<li class="oasi-news-filter__item">
						<button type="button" class="oasi-news-filter__btn is-active" data-filter="all" aria-pressed="true">
							<span class="oasi-news-filter__label"><?php esc_html_e( 'Tutti', 'oasidellespezie-child-theme' ); ?></span>
							<span class="oasi-news-filter__count"><?php echo esc_html( (string) $total_posts ); ?></span>
						</button>
					</li>
					<?php foreach ( $categories as $cat ) : ?>
						<li class="oasi-news-filter__item">
							<button type="button" class="oasi-news-filter__btn" data-filter="<?php echo esc_attr( $cat->slug ); ?>" aria-pressed="false">
								<span class="oasi-news-filter__label"><?php echo esc_html( $cat->name ); ?></span>
								<span class="oasi-news-filter__count"><?php echo esc_html( (string) $cat->count ); ?></span>
							</button>
						</li>
					<?php endforeach; ?>
				</ul>
			</nav>
		<?php endif; ?>

		<!-- 4. Dynamic News & Recipe Magazine Stream -->
		<?php if ( $news_query->have_posts() ) : ?>
			<div class="oasi-news-grid" id="oasi-news-stream" data-oasi-news-stream>
				<?php
				$index = 0;
				while ( $news_query->have_posts() ) :
					$news_query->the_post();
					$post_id      = get_the_ID();
					$primary_cat  = oasi_news_get_primary_category( $post_id );
					$cat_slugs    = oasi_news_get_category_slugs( $post_id );
					$cat_name     = $primary_cat ? $primary_cat->name : __( 'Novità', 'oasidellespezie-child-theme' );
					$is_recipe    = ( $primary_cat && 'ricette' === $primary_cat->slug ) || str_contains( $cat_slugs, 'ricette' );
					$action_label = $is_recipe ? __( 'Scopri la ricetta', 'oasidellespezie-child-theme' ) : __( "Leggi l'articolo", 'oasidellespezie-child-theme' );
					$formatted_date = oasi_news_format_date( $post_id );
					$permalink    = get_permalink( $post_id );
					$excerpt      = oasi_news_get_clean_excerpt( $post_id, 0 === $index ? 28 : 20 );

					// Layout rhythm pattern:
					// Index 0: Featured hero-split
					// Index 1, 2: Duo pair
					// Index 3: Editorial split (image left)
					// Index 4, 5: Duo pair
					// Index 6: Editorial split reversed (image right)
					// Index 7, 8: Duo pair
					// Index 9: Editorial split (image left)
					// Index 10, 11: Duo pair
					$card_classes = array( 'oasi-news-card' );

					if ( 0 === $index ) {
						$card_classes[] = 'oasi-news-card--featured';
					} elseif ( 3 === $index || 9 === $index ) {
						$card_classes[] = 'oasi-news-card--split';
					} elseif ( 6 === $index ) {
						$card_classes[] = 'oasi-news-card--split oasi-news-card--reversed';
					} else {
						$card_classes[] = 'oasi-news-card--duo';
					}
					?>
					<article
						class="<?php echo esc_attr( implode( ' ', $card_classes ) ); ?>"
						data-category-slug="<?php echo esc_attr( $cat_slugs ); ?>"
						id="post-<?php echo esc_attr( (string) $post_id ); ?>"
					>
						<div class="oasi-news-card__media">
							<a href="<?php echo esc_url( $permalink ); ?>" class="oasi-news-card__media-link" tabindex="-1" aria-hidden="true">
								<?php echo oasi_news_get_featured_image_html( $post_id, 'large' ); ?>
								<?php if ( $primary_cat ) : ?>
									<span class="oasi-news-card__badge oasi-news-card__badge--floating"><?php echo esc_html( $cat_name ); ?></span>
								<?php endif; ?>
							</a>
						</div>

						<div class="oasi-news-card__body">
							<div class="oasi-news-card__meta">
								<?php if ( $primary_cat ) : ?>
									<span class="oasi-news-card__category"><?php echo esc_html( $cat_name ); ?></span>
									<span class="oasi-news-card__meta-separator" aria-hidden="true">&bull;</span>
								<?php endif; ?>
								<time class="oasi-news-card__date" datetime="<?php echo esc_attr( get_the_date( 'c', $post_id ) ); ?>">
									<?php echo esc_html( $formatted_date ); ?>
								</time>
							</div>

							<h2 class="oasi-news-card__title">
								<a href="<?php echo esc_url( $permalink ); ?>" class="oasi-news-card__title-link">
									<?php the_title(); ?>
								</a>
							</h2>

							<?php if ( ! empty( $excerpt ) ) : ?>
								<p class="oasi-news-card__excerpt">
									<?php echo esc_html( $excerpt ); ?>
								</p>
							<?php endif; ?>

							<div class="oasi-news-card__footer">
								<a href="<?php echo esc_url( $permalink ); ?>" class="oasi-news-card__action">
									<span class="oasi-news-card__action-text"><?php echo esc_html( $action_label ); ?></span>
									<span class="oasi-news-card__arrow" aria-hidden="true">
										<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
											<line x1="5" y1="12" x2="19" y2="12"></line>
											<polyline points="12 5 19 12 12 19"></polyline>
										</svg>
									</span>
								</a>
							</div>
						</div>
					</article>
					<?php
					$index++;
				endwhile;
				wp_reset_postdata();
				?>
			</div>

			<!-- Empty State for JS filtering (hidden by default) -->
			<div class="oasi-news-empty is-hidden" id="oasi-news-filter-empty" role="status" aria-live="polite">
				<div class="oasi-news-empty__icon" aria-hidden="true">
					<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
						<circle cx="11" cy="11" r="8"></circle>
						<line x1="21" y1="21" x2="16.65" y2="16.65"></line>
					</svg>
				</div>
				<h3 class="oasi-news-empty__title"><?php esc_html_e( 'Nessun articolo in questa categoria', 'oasidellespezie-child-theme' ); ?></h3>
				<p class="oasi-news-empty__desc"><?php esc_html_e( 'Prova a selezionare un’altra categoria o visualizza tutti gli articoli.', 'oasidellespezie-child-theme' ); ?></p>
				<button type="button" class="oasi-news-empty__reset" data-filter-reset>
					<?php esc_html_e( 'Mostra tutti gli articoli', 'oasidellespezie-child-theme' ); ?>
				</button>
			</div>

			<!-- 5. Future-proof Pagination -->
			<?php if ( $news_query->max_num_pages > 1 ) : ?>
				<nav class="oasi-news-pagination" aria-label="<?php esc_attr_e( 'Paginazione articoli', 'oasidellespezie-child-theme' ); ?>">
					<?php
					$big = 999999999;
					echo paginate_links(
						array(
							'base'      => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
							'format'    => '?paged=%#%',
							'current'   => max( 1, (int) get_query_var( 'paged' ), (int) get_query_var( 'page' ) ),
							'total'     => $news_query->max_num_pages,
							'prev_text' => '&larr; ' . esc_html__( 'Precedenti', 'oasidellespezie-child-theme' ),
							'next_text' => esc_html__( 'Successivi', 'oasidellespezie-child-theme' ) . ' &rarr;',
							'type'      => 'list',
						)
					);
					?>
				</nav>
			<?php endif; ?>

		<?php else : ?>
			<div class="oasi-news-empty">
				<h3 class="oasi-news-empty__title"><?php esc_html_e( 'Nessun articolo pubblicato al momento', 'oasidellespezie-child-theme' ); ?></h3>
				<p class="oasi-news-empty__desc"><?php esc_html_e( 'Torna presto a trovarci per scoprire le nostre nuove ricette e le storie dal laboratorio.', 'oasidellespezie-child-theme' ); ?></p>
			</div>
		<?php endif; ?>

	</div>
</div>

<?php
get_footer();
