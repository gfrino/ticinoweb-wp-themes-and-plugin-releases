<?php
/**
 * Page-controlled maintenance mode.
 *
 * Publishing page 186598 enables the public maintenance screen. Returning
 * that page to draft (or any non-published state) restores the storefront.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return the production page used as the maintenance switch.
 */
function oasi_maintenance_page_id(): int {
	return (int) apply_filters( 'oasi_maintenance_page_id', 186598 );
}

/** Approved automatic reopening: 2 November 2026 at 08:00 in Zurich. */
function oasi_maintenance_reopens_at(): int {
	return (int) apply_filters( 'oasi_maintenance_reopens_at', strtotime( '2026-11-02 08:00:00 Europe/Zurich' ) );
}

/**
 * Determine whether the maintenance switch is enabled.
 */
function oasi_maintenance_is_enabled(): bool {
	$page_id = oasi_maintenance_page_id();
	$now     = (int) current_time( 'timestamp', true );

	if ( $now >= oasi_maintenance_reopens_at() ) {
		return false;
	}

	return $page_id > 0 && 'publish' === get_post_status( $page_id );
}

/**
 * Determine whether this is a technical request that must never be blocked.
 */
function oasi_maintenance_is_system_request(): bool {
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
		return true;
	}

	if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
		return true;
	}

	if ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) {
		return true;
	}

	if ( defined( 'WP_CLI' ) && WP_CLI ) {
		return true;
	}

	return function_exists( 'wp_is_json_request' ) && wp_is_json_request();
}

/**
 * Determine whether the current request must render the maintenance page.
 */
function oasi_maintenance_should_render(): bool {
	if ( ! oasi_maintenance_is_enabled() || oasi_maintenance_is_system_request() ) {
		return false;
	}

	$page_id = oasi_maintenance_page_id();
	if ( is_user_logged_in() && current_user_can( 'edit_post', $page_id ) ) {
		return false;
	}

	return true;
}

/**
 * Resolve the child-owned standalone maintenance template.
 */
function oasi_maintenance_template_path(): string {
	return get_stylesheet_directory() . '/maintenance.php';
}

/**
 * Return the temporary-unavailability status code.
 */
function oasi_maintenance_http_status(): int {
	return 503;
}

/**
 * Return the additional maintenance response headers.
 *
 * @return string[]
 */
function oasi_maintenance_response_headers(): array {
	return array(
		'Retry-After: 86400',
		'X-Robots-Tag: noindex, nofollow, noarchive',
	);
}

/**
 * Emit temporary-unavailability and indexing headers.
 */
function oasi_maintenance_send_headers(): void {
	status_header( oasi_maintenance_http_status() );
	nocache_headers();

	foreach ( oasi_maintenance_response_headers() as $header ) {
		header( $header, true );
	}
}

/**
 * Replace the public frontend response while maintenance is enabled.
 */
function oasi_maintenance_maybe_render(): void {
	if ( ! oasi_maintenance_should_render() ) {
		return;
	}

	$template = oasi_maintenance_template_path();
	if ( ! is_readable( $template ) ) {
		return;
	}

	oasi_maintenance_send_headers();
	require $template;
	exit;
}
add_action( 'template_redirect', 'oasi_maintenance_maybe_render', -100 );
