<?php
/**
 * Dynamic CMS fields, data helpers and native form handling for Contatti.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register only the editorial fields missing from ticinoWEB CMS -> Contatti.
 */
function oasi_contact_register_cms_settings(): void {
	register_setting(
		'ticinoweb_settings_group',
		'ticinoweb_contact_intro',
		array(
			'type'              => 'string',
			'default'           => '',
			'sanitize_callback' => 'sanitize_textarea_field',
		)
	);

	register_setting(
		'ticinoweb_settings_group',
		'ticinoweb_contact_pickup_note',
		array(
			'type'              => 'string',
			'default'           => '',
			'sanitize_callback' => 'sanitize_textarea_field',
		)
	);
}
add_action( 'admin_init', 'oasi_contact_register_cms_settings', 20 );

/**
 * Initialize missing editorial values once from the real legacy page copy.
 */
function oasi_contact_seed_cms_content(): void {
	if ( 'oasidellespezie-child-theme' !== get_stylesheet() ) {
		return;
	}

	if ( '1' === (string) get_option( 'oasi_contact_cms_seed_version', '' ) ) {
		return;
	}

	if ( '' === trim( (string) get_option( 'ticinoweb_contact_intro', '' ) ) ) {
		update_option(
			'ticinoweb_contact_intro',
			'Siamo un laboratorio, non siamo un negozio e non abbiamo vetrina su strada.',
			false
		);
	}

	if ( '' === trim( (string) get_option( 'ticinoweb_contact_pickup_note', '' ) ) ) {
		update_option(
			'ticinoweb_contact_pickup_note',
			'Solo per ritiro prodotti. Parliamo solo in italiano e francese.',
			false
		);
	}

	update_option( 'oasi_contact_cms_seed_version', '1', false );
}
add_action( 'init', 'oasi_contact_seed_cms_content', 20 );

/**
 * Determine whether the current admin screen is the inherited ticinoWEB CMS.
 */
function oasi_contact_is_cms_screen(): bool {
	if ( ! is_admin() || ! current_user_can( 'edit_pages' ) ) {
		return false;
	}

	$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	return in_array( $page, array( 'ticinoweb-cms', 'ticinoweb-settings' ), true );
}

/**
 * Enqueue the small CMS enhancer only where its controls are needed.
 */
function oasi_contact_enqueue_admin_assets(): void {
	if ( ! oasi_contact_is_cms_screen() ) {
		return;
	}

	wp_enqueue_script(
		'oasi-contact-admin',
		get_stylesheet_directory_uri() . '/assets/js/contact-admin.js',
		array(),
		wp_get_theme()->get( 'Version' ),
		true
	);
}
add_action( 'admin_enqueue_scripts', 'oasi_contact_enqueue_admin_assets' );

/**
 * Render child-owned rows and let the enhancer mount them in the existing tab.
 */
function oasi_contact_render_admin_fields(): void {
	if ( ! oasi_contact_is_cms_screen() ) {
		return;
	}

	$intro       = (string) get_option( 'ticinoweb_contact_intro', '' );
	$pickup_note = (string) get_option( 'ticinoweb_contact_pickup_note', '' );
	?>
	<div id="oasi-contact-cms-fields" hidden>
		<table><tbody>
			<tr class="oasi-contact-cms-row">
				<th scope="row"><label for="ticinoweb_contact_intro"><?php esc_html_e( 'Introduzione pagina Contatti', 'oasidellespezie-child-theme' ); ?></label></th>
				<td>
					<textarea id="ticinoweb_contact_intro" name="ticinoweb_contact_intro" rows="3" class="large-text"><?php echo esc_textarea( $intro ); ?></textarea>
					<p class="description"><?php esc_html_e( 'Breve testo mostrato sotto il titolo Contatti.', 'oasidellespezie-child-theme' ); ?></p>
				</td>
			</tr>
			<tr class="oasi-contact-cms-row">
				<th scope="row"><label for="ticinoweb_contact_pickup_note"><?php esc_html_e( 'Nota laboratorio e ritiro', 'oasidellespezie-child-theme' ); ?></label></th>
				<td>
					<textarea id="ticinoweb_contact_pickup_note" name="ticinoweb_contact_pickup_note" rows="3" class="large-text"><?php echo esc_textarea( $pickup_note ); ?></textarea>
					<p class="description"><?php esc_html_e( 'Informazioni reali sul laboratorio, sul ritiro in sede e sulle lingue parlate.', 'oasidellespezie-child-theme' ); ?></p>
				</td>
			</tr>
		</tbody></table>
	</div>
	<?php
}
add_action( 'admin_footer', 'oasi_contact_render_admin_fields' );

/**
 * Return all Contact-page values from the existing CMS source of truth.
 *
 * @return array<string, mixed>
 */
function oasi_get_contact_page_data(): array {
	$contact = oasi_get_contact_data();

	$contact['intro']               = trim( (string) get_option( 'ticinoweb_contact_intro', '' ) );
	$contact['pickup_note']         = trim( (string) get_option( 'ticinoweb_contact_pickup_note', '' ) );

	return $contact;
}

/**
 * Return the configured privacy URL, or an existing published privacy page.
 */
function oasi_contact_get_privacy_url(): string {
	$privacy_url = get_privacy_policy_url();
	if ( $privacy_url ) {
		return $privacy_url;
	}

	$page = get_page_by_path( 'privacy-policy' );
	return $page instanceof WP_Post && 'publish' === $page->post_status ? (string) get_permalink( $page ) : '';
}

/**
 * Count user-facing characters without penalizing multibyte text.
 */
function oasi_contact_text_length( string $value ): int {
	return function_exists( 'mb_strlen' ) ? mb_strlen( $value ) : strlen( $value );
}

/**
 * Atomically reserve one per-site option key until its expiry.
 *
 * The unique options index serializes concurrent inserts. The conditional
 * upsert replaces only an already-expired owner, and the read-back confirms
 * that this request still owns the reservation.
 *
 * @return string|false Opaque ownership value, or false when already reserved.
 */
function oasi_contact_reserve( string $key, int $ttl ) {
	global $wpdb;

	$now   = time();
	$owner = (string) ( $now + $ttl ) . ':' . wp_generate_uuid4();
	$query = $wpdb->prepare(
		"INSERT INTO {$wpdb->options} (option_name, option_value, autoload)
		VALUES (%s, %s, 'no')
		ON DUPLICATE KEY UPDATE
		option_value = IF(CAST(SUBSTRING_INDEX(option_value, ':', 1) AS UNSIGNED) <= %d, VALUES(option_value), option_value)",
		$key,
		$owner,
		$now
	);
	$wpdb->query( $query ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Prepared above; table name is WordPress-owned.

	$current_owner = $wpdb->get_var(
		$wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s LIMIT 1", $key )
	);

	return is_string( $current_owner ) && hash_equals( $owner, $current_owner ) ? $owner : false;
}

/**
 * Release reservations when no message was delivered.
 *
 * @param array<string, string> $reservations Option name to opaque owner value.
 */
function oasi_contact_release_reservations( array $reservations ): void {
	global $wpdb;

	foreach ( $reservations as $key => $owner ) {
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s",
				$key,
				$owner
			)
		); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Prepared above; table name is WordPress-owned.
	}
}

/**
 * Remove expired idempotency and rate-limit rows without touching live owners.
 */
function oasi_contact_cleanup_reservations(): void {
	global $wpdb;

	$now       = time();
	$like_once = $wpdb->esc_like( 'oasi_contact_once_' ) . '%';
	$like_rate = $wpdb->esc_like( 'oasi_contact_rate_' ) . '%';
	$wpdb->query(
		$wpdb->prepare(
			"DELETE FROM {$wpdb->options}
			WHERE (option_name LIKE %s OR option_name LIKE %s)
			AND CAST(SUBSTRING_INDEX(option_value, ':', 1) AS UNSIGNED) <= %d
			LIMIT 500",
			$like_once,
			$like_rate,
			$now
		)
	); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Prepared above; table name is WordPress-owned.
}
add_action( 'oasi_contact_cleanup_reservations', 'oasi_contact_cleanup_reservations' );

/**
 * Schedule bounded cleanup only on the Oasi child site.
 */
function oasi_contact_schedule_cleanup(): void {
	if ( 'oasidellespezie-child-theme' !== get_stylesheet() || wp_next_scheduled( 'oasi_contact_cleanup_reservations' ) ) {
		return;
	}

	wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'oasi_contact_cleanup_reservations' );
}
add_action( 'init', 'oasi_contact_schedule_cleanup', 30 );

// Contact form submissions are handled by the parent theme (inc/form-handler.php:
// AJAX endpoint ticinoweb_submit_form with fresh token, honeypot, rate limit,
// optional reCAPTCHA, storage in "Invii Ricevuti" and wp_mail/SMTP). The child
// keeps no backend of its own. The reservation helpers above stay: the
// professional application uses them against duplicate submissions.

/**
 * Use the child template even when the imported page retains legacy metadata.
 *
 * @param string $template Resolved WordPress template path.
 */
function oasi_contact_template_include( string $template ): string {
	if ( ! is_page( 'contatto' ) ) {
		return $template;
	}

	$contact_template = get_stylesheet_directory() . '/page-contatto.php';
	return is_file( $contact_template ) ? $contact_template : $template;
}
add_filter( 'template_include', 'oasi_contact_template_include', 99 );
