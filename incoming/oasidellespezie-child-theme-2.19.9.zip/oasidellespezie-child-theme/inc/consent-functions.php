<?php
/**
 * Cookie consent and checkout legal texts, on top of the parent cookie banner.
 *
 * The parent banner (tW SEO) is shared by every ticinoWEB site and is not
 * modified here: the child only corrects its behaviour on this site.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Consent helpers for the parent banner.
 *
 * - The "Personalizza" panel had the analytics and marketing switches pre-ticked:
 *   under GDPR a pre-ticked box is not consent. They start unticked here.
 * - Once a choice was made the banner could never be reopened, so consent could
 *   not be withdrawn. The footer link "Impostazioni cookie" deletes the stored
 *   choice and reloads the page, which shows the banner again.
 *
 * Runs in the browser, so cached pages stay identical for every visitor.
 */
function oasi_consent_script(): void {
	?>
	<script id="oasi-consent-helpers">
	( function () {
		'use strict';
		function hasChoice() {
			return /(?:^|;\s*)tw_cookie_consent=/.test( document.cookie );
		}
		document.addEventListener( 'DOMContentLoaded', function () {
			if ( ! hasChoice() ) {
				[ 'tw-cookie-opt-analytics', 'tw-cookie-opt-marketing' ].forEach( function ( id ) {
					var input = document.getElementById( id );
					if ( input ) { input.checked = false; }
				} );
			}
			document.querySelectorAll( '[data-oasi-cookie-settings]' ).forEach( function ( button ) {
				button.addEventListener( 'click', function () {
					[ 'tw_cookie_consent', 'tw_cookie_preferences' ].forEach( function ( name ) {
						document.cookie = name + '=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/; SameSite=Lax';
					} );
					window.location.reload();
				} );
			} );
		} );
	}() );
	</script>
	<?php
}
add_action( 'wp_footer', 'oasi_consent_script', 5 );

/**
 * Footer button styled as the other legal links.
 */
function oasi_consent_styles(): void {
	wp_add_inline_style(
		'oasi-footer-style',
		'.oasi-footer__cookie-settings{padding:0;border:0;background:none;color:inherit;font:inherit;text-align:left;cursor:pointer;opacity:inherit}'
		. '.oasi-footer__cookie-settings:hover,.oasi-footer__cookie-settings:focus-visible{text-decoration:underline}'
	);
}
add_action( 'wp_enqueue_scripts', 'oasi_consent_styles', 30 );

/**
 * Accept at checkout the terms of sale shown on the site.
 *
 * WooCommerce pointed to an older page (ID 1173, "condizioni-generali", January
 * 2026) while the footer links to the current "condizioni-generali-di-vendita":
 * customers accepted a different text from the one published.
 *
 * @param int $page_id Terms page ID from the WooCommerce settings.
 * @return int
 */
function oasi_consent_terms_page( $page_id ): int {
	$page = get_page_by_path( 'condizioni-generali-di-vendita', OBJECT, 'page' );

	return $page instanceof WP_Post && 'publish' === $page->post_status ? (int) $page->ID : (int) $page_id;
}
add_filter( 'woocommerce_get_terms_page_id', 'oasi_consent_terms_page' );

/**
 * Permanently redirect the retired terms page to the current one.
 *
 * The old "condizioni-generali" page (ID 1173, January 2026) was merged into
 * "condizioni-generali-di-vendita" and trashed on 2026-09-29; existing links
 * (for example the "Cassa NEW" page and external sites) keep working.
 */
function oasi_redirect_retired_terms_page(): void {
	if ( ! is_404() ) {
		return;
	}

	$path = trim( (string) wp_parse_url( (string) ( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH ), '/' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- compared to a constant only.
	$path = preg_replace( '#^(de|fr)/#', '', $path );

	if ( 'condizioni-generali' === $path ) {
		$page = get_page_by_path( 'condizioni-generali-di-vendita', OBJECT, 'page' );
		if ( $page instanceof WP_Post ) {
			wp_safe_redirect( get_permalink( $page ), 301 );
			exit;
		}
	}
}
add_action( 'template_redirect', 'oasi_redirect_retired_terms_page', 1 );
