<?php
/**
 * Lotti di magazzino per prodotti e varianti WooCommerce.
 *
 * Ogni prodotto (o variante con giacenza propria) puo' avere piu' lotti, ognuno
 * con codice, scadenza e quantita'. La giacenza WooCommerce resta la fonte per le
 * vendite ed e' la somma dei lotti quando questi vengono salvati da wp-admin.
 *
 * Le vendite scalano i lotti con criterio FIFO (prima scadenza, poi ordine di
 * inserimento). L'assegnazione non dipende da un flusso specifico: ogni volta che
 * una riga d'ordine viene salvata si confronta `_reduced_stock` (quanto
 * WooCommerce, OpenPOS o un rimborso hanno effettivamente scalato) con quanto e'
 * gia' assegnato ai lotti, e si assegna o si restituisce la differenza. Cosi' sono
 * coperti checkout, POS, modifiche manuali dell'ordine, annullamenti e rimborsi.
 *
 * Le righe d'ordine esistenti prima dei lotti non toccano i lotti: la prima volta
 * che vengono viste con stock gia' scalato, quella quantita' e' registrata come
 * "precedente ai lotti".
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const OASI_LOTS_META        = '_oasi_lots';
const OASI_LOTS_ALLOC_META  = '_oasi_lot_alloc';
const OASI_LOTS_NONE        = 'none';
const OASI_LOTS_LEGACY      = 'legacy';
const OASI_LOTS_PRECISION   = 4;

/*
 * -------------------------------------------------------------------------
 * Logica pura (senza WordPress): assegnazione e restituzione.
 * -------------------------------------------------------------------------
 */

/**
 * Normalize a quantity for comparisons (stock can be fractional for weight sales).
 *
 * @param mixed $qty Raw quantity.
 */
function oasi_lots_qty( mixed $qty ): float {
	return round( (float) $qty, OASI_LOTS_PRECISION );
}

/**
 * Sort lots FIFO: earliest expiry first, lots without expiry last, then insertion order.
 *
 * @param array<int, array<string, mixed>> $lots Lots.
 * @return array<int, array<string, mixed>>
 */
function oasi_lots_sort_fifo( array $lots ): array {
	$indexed = array();
	foreach ( array_values( $lots ) as $position => $lot ) {
		$indexed[] = array( $position, $lot );
	}

	usort(
		$indexed,
		static function ( array $a, array $b ): int {
			$expiry_a = (string) ( $a[1]['expiry'] ?? '' );
			$expiry_b = (string) ( $b[1]['expiry'] ?? '' );

			if ( $expiry_a !== $expiry_b ) {
				if ( '' === $expiry_a ) {
					return 1;
				}
				if ( '' === $expiry_b ) {
					return -1;
				}
				return strcmp( $expiry_a, $expiry_b );
			}

			return $a[0] <=> $b[0];
		}
	);

	return array_map( static fn( array $pair ): array => $pair[1], $indexed );
}

/**
 * Take a quantity from the lots, FIFO.
 *
 * Whatever the lots cannot cover is returned as a "senza lotto" entry, so the
 * allocation always matches what was actually removed from stock.
 *
 * @param array<int, array<string, mixed>> $lots Current lots of the stock owner.
 * @param float                            $qty  Quantity to take.
 * @return array{lots: array<int, array<string, mixed>>, taken: array<int, array<string, mixed>>}
 */
function oasi_lots_take( array $lots, float $qty ): array {
	$lots  = array_values( $lots );
	$need  = oasi_lots_qty( $qty );
	$taken = array();
	$order = array_keys( oasi_lots_sort_fifo_keys( $lots ) );

	foreach ( $order as $key ) {
		if ( $need <= 0 ) {
			break;
		}

		$available = oasi_lots_qty( $lots[ $key ]['qty'] ?? 0 );
		if ( $available <= 0 ) {
			continue;
		}

		$use                  = min( $available, $need );
		$lots[ $key ]['qty']  = oasi_lots_qty( $available - $use );
		$need                 = oasi_lots_qty( $need - $use );
		$taken[]              = array(
			'lot'    => (string) $lots[ $key ]['id'],
			'code'   => (string) ( $lots[ $key ]['code'] ?? '' ),
			'expiry' => (string) ( $lots[ $key ]['expiry'] ?? '' ),
			'qty'    => $use,
		);
	}

	if ( $need > 0 ) {
		$taken[] = array(
			'lot'    => OASI_LOTS_NONE,
			'code'   => '',
			'expiry' => '',
			'qty'    => $need,
		);
	}

	return array(
		'lots'  => array_values( $lots ),
		'taken' => $taken,
	);
}

/**
 * Keys of the lots in FIFO order (keeps the caller's keys, unlike oasi_lots_sort_fifo()).
 *
 * @param array<int, array<string, mixed>> $lots Lots.
 * @return array<int, true>
 */
function oasi_lots_sort_fifo_keys( array $lots ): array {
	$lots = array_values( $lots );
	foreach ( $lots as $key => $lot ) {
		$lots[ $key ]['__key'] = $key;
	}

	$keys = array();
	foreach ( oasi_lots_sort_fifo( $lots ) as $lot ) {
		$keys[ (int) $lot['__key'] ] = true;
	}

	return $keys;
}

/**
 * Give a quantity back to the lots, undoing the most recent allocation entries first.
 *
 * A lot that was deleted in the meantime is recreated with the returned quantity,
 * so the goods keep their traceability.
 *
 * @param array<int, array<string, mixed>> $lots  Current lots of the stock owner.
 * @param array<int, array<string, mixed>> $alloc Allocation stored on the order item.
 * @param float                            $qty   Quantity to give back.
 * @return array{lots: array<int, array<string, mixed>>, alloc: array<int, array<string, mixed>>}
 */
function oasi_lots_give_back( array $lots, array $alloc, float $qty ): array {
	$left  = oasi_lots_qty( $qty );
	$lots  = array_values( $lots );
	$alloc = array_values( $alloc );

	for ( $index = count( $alloc ) - 1; $index >= 0 && $left > 0; $index-- ) {
		$entry_qty = oasi_lots_qty( $alloc[ $index ]['qty'] ?? 0 );
		$back      = min( $entry_qty, $left );
		$left      = oasi_lots_qty( $left - $back );

		$alloc[ $index ]['qty'] = oasi_lots_qty( $entry_qty - $back );

		$lot_id = (string) ( $alloc[ $index ]['lot'] ?? '' );
		if ( in_array( $lot_id, array( OASI_LOTS_NONE, OASI_LOTS_LEGACY, '' ), true ) ) {
			continue;
		}

		$found = false;
		foreach ( $lots as $key => $lot ) {
			if ( (string) $lot['id'] === $lot_id ) {
				$lots[ $key ]['qty'] = oasi_lots_qty( ( $lot['qty'] ?? 0 ) + $back );
				$found               = true;
				break;
			}
		}

		if ( ! $found ) {
			$lots[] = array(
				'id'     => $lot_id,
				'code'   => (string) ( $alloc[ $index ]['code'] ?? '' ),
				'expiry' => (string) ( $alloc[ $index ]['expiry'] ?? '' ),
				'qty'    => $back,
			);
		}
	}

	$alloc = array_values(
		array_filter( $alloc, static fn( array $entry ): bool => oasi_lots_qty( $entry['qty'] ?? 0 ) > 0 )
	);

	return array(
		'lots'  => $lots,
		'alloc' => $alloc,
	);
}

/**
 * Merge new allocation entries into an existing allocation (same lot = one entry).
 *
 * @param array<int, array<string, mixed>> $alloc Existing allocation.
 * @param array<int, array<string, mixed>> $taken New entries.
 * @return array<int, array<string, mixed>>
 */
function oasi_lots_merge_alloc( array $alloc, array $taken ): array {
	foreach ( $taken as $entry ) {
		$merged = false;
		foreach ( $alloc as $key => $existing ) {
			if ( (string) $existing['lot'] === (string) $entry['lot'] && OASI_LOTS_LEGACY !== $entry['lot'] ) {
				$alloc[ $key ]['qty'] = oasi_lots_qty( $existing['qty'] + $entry['qty'] );
				$merged               = true;
				break;
			}
		}
		if ( ! $merged ) {
			$alloc[] = $entry;
		}
	}

	return array_values( $alloc );
}

/**
 * Total quantity of a list of lots or allocation entries.
 *
 * @param array<int, array<string, mixed>> $rows Lots or allocation entries.
 */
function oasi_lots_total( array $rows ): float {
	$total = 0.0;
	foreach ( $rows as $row ) {
		$total += (float) ( $row['qty'] ?? 0 );
	}

	return oasi_lots_qty( $total );
}

/*
 * -------------------------------------------------------------------------
 * Persistenza.
 * -------------------------------------------------------------------------
 */

/**
 * Read the lots of a product, bypassing a possibly stale object cache.
 *
 * @param int  $product_id Product or variation ID that owns the stock.
 * @param bool $fresh      Drop the meta cache first (use inside a lock).
 * @return array<int, array<string, mixed>>
 */
function oasi_lots_get( int $product_id, bool $fresh = false ): array {
	if ( $product_id <= 0 ) {
		return array();
	}

	if ( $fresh ) {
		wp_cache_delete( $product_id, 'post_meta' );
	}

	$lots = get_post_meta( $product_id, OASI_LOTS_META, true );

	return is_array( $lots ) ? array_values( $lots ) : array();
}

/**
 * Store the lots of a product.
 *
 * @param int                              $product_id Product or variation ID.
 * @param array<int, array<string, mixed>> $lots       Lots.
 */
function oasi_lots_put( int $product_id, array $lots ): void {
	if ( array() === $lots ) {
		delete_post_meta( $product_id, OASI_LOTS_META );
		return;
	}

	update_post_meta( $product_id, OASI_LOTS_META, array_values( $lots ) );
}

/**
 * Serialize concurrent changes to the lots of one product (checkout, POS, admin).
 *
 * @param int $product_id Product ID.
 */
function oasi_lots_lock( int $product_id ): bool {
	global $wpdb;

	$name = 'oasi_lots_' . get_current_blog_id() . '_' . $product_id;

	return '1' === (string) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 5)', $name ) );
}

/**
 * Release the lock taken by oasi_lots_lock().
 *
 * @param int $product_id Product ID.
 */
function oasi_lots_unlock( int $product_id ): void {
	global $wpdb;

	$name = 'oasi_lots_' . get_current_blog_id() . '_' . $product_id;
	$wpdb->query( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $name ) );
}

/*
 * -------------------------------------------------------------------------
 * Sincronizzazione con le righe d'ordine.
 * -------------------------------------------------------------------------
 */

/**
 * Align the lots with what was actually removed from stock for an order item.
 *
 * Hooked on every order item create/update, so it covers WooCommerce checkout,
 * OpenPOS, manual edits in wp-admin, cancellations and restocking refunds.
 *
 * @param int   $item_id  Order item ID.
 * @param mixed $item     Order item.
 */
function oasi_lots_sync_order_item( int $item_id, mixed $item ): void {
	static $running = false;

	if ( $running || ! ( $item instanceof WC_Order_Item_Product ) ) {
		return;
	}

	$product = $item->get_product();
	if ( ! $product ) {
		return;
	}

	$owner_id = (int) $product->get_stock_managed_by_id();
	$reduced  = oasi_lots_qty( $item->get_meta( '_reduced_stock', true ) );
	$has_mark = $item->meta_exists( OASI_LOTS_ALLOC_META );

	if ( ! $has_mark ) {
		// Never seen before: only products that use lots are tracked.
		if ( array() === oasi_lots_get( $owner_id ) ) {
			return;
		}

		$alloc = array();
		if ( $reduced > 0 ) {
			// Stock was removed before this item was tracked: not taken from any lot.
			$alloc[] = array(
				'lot'    => OASI_LOTS_LEGACY,
				'code'   => '',
				'expiry' => '',
				'qty'    => $reduced,
				'owner'  => $owner_id,
			);
		}

		$running = true;
		$item->update_meta_data( OASI_LOTS_ALLOC_META, $alloc );
		$item->save_meta_data();
		$running = false;
		return;
	}

	$alloc     = $item->get_meta( OASI_LOTS_ALLOC_META, true );
	$alloc     = is_array( $alloc ) ? array_values( $alloc ) : array();
	$allocated = oasi_lots_total( $alloc );
	$diff      = oasi_lots_qty( $reduced - $allocated );

	if ( 0.0 === $diff ) {
		return;
	}

	// Lots are always moved on the product that owned them when they were taken.
	$alloc_owner = (int) ( $alloc[0]['owner'] ?? $owner_id );

	if ( ! oasi_lots_lock( $alloc_owner ) ) {
		wc_get_logger()->warning(
			sprintf( 'Lotti: lock non ottenuto per il prodotto %d, riga d\'ordine %d.', $alloc_owner, $item_id ),
			array( 'source' => 'oasi-lotti' )
		);
		return;
	}

	$running = true;

	try {
		$lots = oasi_lots_get( $alloc_owner, true );

		if ( $diff > 0 ) {
			$result = oasi_lots_take( $lots, $diff );
			$taken  = array_map(
				static fn( array $entry ): array => $entry + array( 'owner' => $alloc_owner ),
				$result['taken']
			);
			$alloc  = oasi_lots_merge_alloc( $alloc, $taken );
			$lots   = $result['lots'];
		} else {
			$result = oasi_lots_give_back( $lots, $alloc, -$diff );
			$alloc  = $result['alloc'];
			$lots   = $result['lots'];
		}

		oasi_lots_put( $alloc_owner, $lots );
		$item->update_meta_data( OASI_LOTS_ALLOC_META, $alloc );
		$item->save_meta_data();
	} finally {
		$running = false;
		oasi_lots_unlock( $alloc_owner );
	}
}
add_action( 'woocommerce_new_order_item', 'oasi_lots_sync_order_item', 20, 2 );
add_action( 'woocommerce_update_order_item', 'oasi_lots_sync_order_item', 20, 2 );

/*
 * -------------------------------------------------------------------------
 * wp-admin: modifica dei lotti nella scheda prodotto.
 * -------------------------------------------------------------------------
 */

/**
 * Format a Y-m-d expiry as d.m.Y.
 *
 * @param string $expiry Stored date.
 */
function oasi_lots_format_expiry( string $expiry ): string {
	$date = DateTimeImmutable::createFromFormat( '!Y-m-d', $expiry );

	return $date ? $date->format( 'd.m.Y' ) : $expiry;
}

/**
 * Fingerprint of the stored lots, to detect sales that happened while the form was open.
 *
 * @param array<int, array<string, mixed>> $lots Lots.
 */
function oasi_lots_fingerprint( array $lots ): string {
	return md5( (string) wp_json_encode( array_values( $lots ) ) );
}

/**
 * Render the lots editor for one stock owner.
 *
 * In compact mode (bulk stock page) the title is hidden and a product without
 * lots gets one pre-filled row with its current stock, ready for code and expiry.
 *
 * @param int        $product_id Product or variation ID.
 * @param float|null $stock      Current WooCommerce stock.
 * @param bool       $compact    Bulk page layout.
 */
function oasi_lots_render_editor( int $product_id, ?float $stock, bool $compact = false ): void {
	$lots   = oasi_lots_get( $product_id );
	$prefix = 'oasi_lots[' . $product_id . ']';
	$total  = oasi_lots_total( $lots );
	?>
	<div class="oasi-lots<?php echo $compact ? ' oasi-lots--compact' : ''; ?>" data-oasi-lots data-prefix="<?php echo esc_attr( $prefix ); ?>" data-stock="<?php echo esc_attr( null === $stock ? '' : (string) $stock ); ?>">
		<?php if ( ! $compact ) : ?>
		<p class="oasi-lots__title"><strong><?php esc_html_e( 'Lotti', 'oasidellespezie-child-theme' ); ?></strong>
			<span class="description"><?php esc_html_e( 'Le vendite scalano prima il lotto con la scadenza più vicina. Con almeno un lotto, la quantità in magazzino diventa la somma dei lotti al salvataggio.', 'oasidellespezie-child-theme' ); ?></span>
		</p>
		<?php endif; ?>
		<input type="hidden" name="<?php echo esc_attr( $prefix . '[present]' ); ?>" value="1" />
		<input type="hidden" class="oasi-lots__dirty" name="<?php echo esc_attr( $prefix . '[dirty]' ); ?>" value="0" />
		<input type="hidden" name="<?php echo esc_attr( $prefix . '[fingerprint]' ); ?>" value="<?php echo esc_attr( oasi_lots_fingerprint( $lots ) ); ?>" />
		<table class="widefat striped oasi-lots__table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Codice lotto', 'oasidellespezie-child-theme' ); ?></th>
					<th><?php esc_html_e( 'Scadenza', 'oasidellespezie-child-theme' ); ?></th>
					<th><?php esc_html_e( 'Quantità', 'oasidellespezie-child-theme' ); ?></th>
					<th><span class="screen-reader-text"><?php esc_html_e( 'Azioni', 'oasidellespezie-child-theme' ); ?></span></th>
				</tr>
			</thead>
			<tbody>
				<?php
				foreach ( oasi_lots_sort_fifo( $lots ) as $index => $lot ) {
					oasi_lots_render_row( $prefix, (string) $index, $lot );
				}
				if ( $compact && array() === $lots && null !== $stock && $stock > 0 ) {
					oasi_lots_render_row( $prefix, 'n0', array( 'qty' => $stock ) );
				}
				?>
			</tbody>
			<tfoot>
				<tr>
					<td colspan="2"><button type="button" class="button oasi-lots__add"><?php esc_html_e( 'Aggiungi lotto', 'oasidellespezie-child-theme' ); ?></button></td>
					<td colspan="2" class="oasi-lots__summary" aria-live="polite">
						<?php
						if ( array() !== $lots ) {
							printf(
								/* translators: %s: total quantity in lots. */
								esc_html__( 'Totale lotti: %s', 'oasidellespezie-child-theme' ),
								esc_html( wc_format_localized_decimal( $total ) )
							);
						}
						?>
					</td>
				</tr>
			</tfoot>
		</table>
		<?php if ( ! $compact && array() !== $lots && null !== $stock && oasi_lots_qty( $stock ) !== $total ) : ?>
			<p class="oasi-lots__warning">
				<?php
				printf(
					/* translators: 1: WooCommerce stock, 2: total in lots. */
					esc_html__( 'Attenzione: il magazzino segna %1$s ma i lotti sommano %2$s (giacenza modificata fuori dai lotti, o vendite oltre i lotti disponibili). Salvando, la quantità in magazzino diventa %2$s.', 'oasidellespezie-child-theme' ),
					esc_html( wc_format_localized_decimal( $stock ) ),
					esc_html( wc_format_localized_decimal( $total ) )
				);
				?>
			</p>
		<?php endif; ?>
		<template class="oasi-lots__template">
			<?php oasi_lots_render_row( $prefix, '__INDEX__', array() ); ?>
		</template>
	</div>
	<?php
}

/**
 * Render one editable lot row.
 *
 * @param string               $prefix Field name prefix.
 * @param string               $index  Row index.
 * @param array<string, mixed> $lot    Lot data.
 */
function oasi_lots_render_row( string $prefix, string $index, array $lot ): void {
	$name = $prefix . '[rows][' . $index . ']';
	?>
	<tr class="oasi-lots__row">
		<td>
			<input type="hidden" name="<?php echo esc_attr( $name . '[id]' ); ?>" value="<?php echo esc_attr( (string) ( $lot['id'] ?? '' ) ); ?>" />
			<input type="text" name="<?php echo esc_attr( $name . '[code]' ); ?>" value="<?php echo esc_attr( (string) ( $lot['code'] ?? '' ) ); ?>" aria-label="<?php esc_attr_e( 'Codice lotto', 'oasidellespezie-child-theme' ); ?>" maxlength="64" />
		</td>
		<td><input type="date" name="<?php echo esc_attr( $name . '[expiry]' ); ?>" value="<?php echo esc_attr( (string) ( $lot['expiry'] ?? '' ) ); ?>" aria-label="<?php esc_attr_e( 'Scadenza', 'oasidellespezie-child-theme' ); ?>" /></td>
		<td><input type="number" step="any" min="0" class="oasi-lots__qty" name="<?php echo esc_attr( $name . '[qty]' ); ?>" value="<?php echo esc_attr( isset( $lot['qty'] ) ? (string) $lot['qty'] : '' ); ?>" aria-label="<?php esc_attr_e( 'Quantità', 'oasidellespezie-child-theme' ); ?>" /></td>
		<td><button type="button" class="button-link-delete oasi-lots__remove"><?php esc_html_e( 'Rimuovi', 'oasidellespezie-child-theme' ); ?></button></td>
	</tr>
	<?php
}

/**
 * Lots editor inside the product Inventory tab (simple products and parent-level stock).
 */
function oasi_lots_render_product_editor(): void {
	global $product_object;

	if ( ! ( $product_object instanceof WC_Product ) ) {
		return;
	}

	$stock = $product_object->get_manage_stock() ? (float) $product_object->get_stock_quantity( 'edit' ) : null;
	oasi_lots_render_editor( (int) $product_object->get_id(), $stock );
}
add_action( 'woocommerce_product_options_stock_fields', 'oasi_lots_render_product_editor' );

/**
 * Lots editor inside each variation that manages its own stock.
 *
 * @param int     $loop           Variation position.
 * @param array   $variation_data Variation data.
 * @param WP_Post $variation      Variation post.
 */
function oasi_lots_render_variation_editor( int $loop, array $variation_data, WP_Post $variation ): void {
	unset( $loop, $variation_data );

	$variation_object = wc_get_product( $variation->ID );
	$stock            = ( $variation_object && true === $variation_object->get_manage_stock() )
		? (float) $variation_object->get_stock_quantity( 'edit' )
		: null;

	oasi_lots_render_editor( (int) $variation->ID, $stock );
}
add_action( 'woocommerce_variation_options_inventory', 'oasi_lots_render_variation_editor', 10, 3 );

/**
 * Parse the posted rows for one product into clean lots.
 *
 * @param array<string, mixed>             $posted   Posted data for this product.
 * @param array<int, array<string, mixed>> $existing Stored lots (to keep IDs stable).
 * @return array<int, array<string, mixed>>
 */
function oasi_lots_parse_posted( array $posted, array $existing ): array {
	$known = array();
	foreach ( $existing as $lot ) {
		$known[ (string) $lot['id'] ] = true;
	}

	$lots = array();
	foreach ( (array) ( $posted['rows'] ?? array() ) as $row ) {
		if ( ! is_array( $row ) ) {
			continue;
		}

		$code   = sanitize_text_field( wp_unslash( (string) ( $row['code'] ?? '' ) ) );
		$expiry = sanitize_text_field( wp_unslash( (string) ( $row['expiry'] ?? '' ) ) );
		$qty    = max( 0.0, oasi_lots_qty( wc_format_decimal( wp_unslash( (string) ( $row['qty'] ?? '' ) ) ) ) );
		$id     = sanitize_key( wp_unslash( (string) ( $row['id'] ?? '' ) ) );

		if ( '' === $code && '' === $expiry && 0.0 === $qty ) {
			continue;
		}

		if ( '' !== $expiry && ! DateTimeImmutable::createFromFormat( '!Y-m-d', $expiry ) ) {
			$expiry = '';
		}

		if ( '' === $id || ! isset( $known[ $id ] ) ) {
			$id = strtolower( wp_generate_password( 12, false, false ) );
		}

		$lots[] = array(
			'id'     => $id,
			'code'   => $code,
			'expiry' => $expiry,
			'qty'    => $qty,
		);
	}

	return $lots;
}

/**
 * Save the posted lots of one product and return their total.
 *
 * Returns null when nothing was saved: the editor was not on the page, or the
 * lots changed (a sale) while the form was open, in which case the admin is told.
 *
 * @param int $product_id Product or variation ID.
 */
function oasi_lots_save_posted( int $product_id ): ?float {
	// phpcs:ignore WordPress.Security.NonceVerification.Missing -- WooCommerce verified its product/variation nonce before these hooks.
	$posted = $_POST['oasi_lots'][ $product_id ] ?? null;

	if ( ! is_array( $posted ) || empty( $posted['present'] ) || ! current_user_can( 'edit_product', $product_id ) ) {
		return null;
	}

	if ( ! oasi_lots_lock( $product_id ) ) {
		return null;
	}

	try {
		$existing = oasi_lots_get( $product_id, true );

		if ( oasi_lots_fingerprint( $existing ) !== sanitize_text_field( wp_unslash( (string) ( $posted['fingerprint'] ?? '' ) ) ) ) {
			set_transient(
				'oasi_lots_notice_' . get_current_user_id(),
				sprintf(
					/* translators: %d: product ID. */
					__( 'Lotti del prodotto #%d non salvati: nel frattempo una vendita li ha modificati. Ricarica la pagina e reinserisci le modifiche.', 'oasidellespezie-child-theme' ),
					$product_id
				),
				300
			);
			return null;
		}

		$lots = oasi_lots_parse_posted( $posted, $existing );
		oasi_lots_put( $product_id, $lots );
	} finally {
		oasi_lots_unlock( $product_id );
	}

	return array() === $lots ? null : oasi_lots_total( $lots );
}

/**
 * Save lots of a simple product (or parent-level stock) and align the stock quantity.
 *
 * @param WC_Product $product Product being saved.
 */
function oasi_lots_save_product( WC_Product $product ): void {
	$total = oasi_lots_save_posted( (int) $product->get_id() );

	if ( null !== $total && $product->get_manage_stock() ) {
		$product->set_stock_quantity( $total );
	}
}
add_action( 'woocommerce_admin_process_product_object', 'oasi_lots_save_product' );

/**
 * Save lots of a variation and align its stock quantity.
 *
 * @param int $variation_id Variation ID.
 */
function oasi_lots_save_variation( int $variation_id ): void {
	$total     = oasi_lots_save_posted( $variation_id );
	$variation = null !== $total ? wc_get_product( $variation_id ) : null;

	if ( $variation && true === $variation->get_manage_stock() ) {
		wc_update_product_stock( $variation, $total, 'set' );
	}
}
add_action( 'woocommerce_save_product_variation', 'oasi_lots_save_variation', 20 );

/**
 * Show the "lots not saved" notice after the redirect.
 */
function oasi_lots_admin_notice(): void {
	$key     = 'oasi_lots_notice_' . get_current_user_id();
	$message = get_transient( $key );

	if ( ! $message ) {
		return;
	}

	delete_transient( $key );
	printf( '<div class="notice notice-error"><p>%s</p></div>', esc_html( (string) $message ) );
}
add_action( 'admin_notices', 'oasi_lots_admin_notice' );

/**
 * Editor behaviour (add/remove rows, stock field read-only while lots exist) and styles.
 */
function oasi_lots_admin_assets(): void {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $screen || ! in_array( $screen->id, array( 'product', 'woocommerce_page_oasi-lotti' ), true ) ) {
		return;
	}
	?>
	<style>
		.oasi-lots { clear: both; padding: 8px 12px 12px; }
		.oasi-lots__title .description { display: block; margin-top: 2px; }
		.oasi-lots__table input[type="text"], .oasi-lots__table input[type="date"], .oasi-lots__table input[type="number"] { width: 100%; float: none; }
		.oasi-lots__table td, .oasi-lots__table th { padding: 6px 8px; vertical-align: middle; }
		.oasi-lots__warning { color: #b32d2e; }
		.woocommerce_variation .oasi-lots { padding: 8px 0 0; }
		.oasi-lots--compact { padding: 0; }
		.oasi-lots--compact .oasi-lots__table { box-shadow: none; }
		.oasi-lots--compact .oasi-lots__table thead th { font-size: 12px; padding: 2px 8px; }
		.oasi-lots--compact.is-dirty .oasi-lots__table { outline: 2px solid #dba617; }
	</style>
	<script>
	( function ( $ ) {
		function stockInput( $box ) {
			var $variation = $box.closest( '.woocommerce_variation' );
			return $variation.length ? $variation.find( 'input[name^="variable_stock["]' ) : $( '#_stock' );
		}

		function markDirty( $box ) {
			$box.addClass( 'is-dirty' ).find( '.oasi-lots__dirty' ).val( '1' );
		}

		function refresh( $box ) {
			var rows = $box.find( 'tbody .oasi-lots__row' ).length;
			var total = 0;
			$box.find( 'tbody .oasi-lots__qty' ).each( function () {
				total += parseFloat( $( this ).val() ) || 0;
			} );
			$box.find( '.oasi-lots__summary' ).text( rows ? 'Totale lotti: ' + Math.round( total * 10000 ) / 10000 : '' );
			stockInput( $box ).prop( 'readonly', rows > 0 ).attr( 'title', rows > 0 ? 'Calcolata dalla somma dei lotti' : '' );
		}

		$( document.body ).on( 'click', '.oasi-lots__add', function () {
			var $box = $( this ).closest( '[data-oasi-lots]' );
			var html = $box.find( 'template.oasi-lots__template' ).html().replace( /__INDEX__/g, 'n' + Date.now() );
			var $row = $( html ).appendTo( $box.find( 'tbody' ) );
			$row.find( 'input[type="text"]' ).trigger( 'focus' ).trigger( 'change' );
			markDirty( $box );
			refresh( $box );
		} );

		$( document.body ).on( 'click', '.oasi-lots__remove', function () {
			var $box = $( this ).closest( '[data-oasi-lots]' );
			var $marker = $box.find( 'input[name$="[present]"]' );
			$( this ).closest( 'tr' ).remove();
			$marker.trigger( 'change' );
			markDirty( $box );
			refresh( $box );
		} );

		$( document.body ).on( 'input change', '.oasi-lots__row input', function () {
			markDirty( $( this ).closest( '[data-oasi-lots]' ) );
		} );

		$( document.body ).on( 'input change', '.oasi-lots__qty', function () {
			refresh( $( this ).closest( '[data-oasi-lots]' ) );
		} );

		$( function () { $( '[data-oasi-lots]' ).each( function () { refresh( $( this ) ); } ); } );
		$( '#woocommerce-product-data' ).on( 'woocommerce_variations_loaded woocommerce_variations_added', function () {
			$( '[data-oasi-lots]' ).each( function () { refresh( $( this ) ); } );
		} );
	}( jQuery ) );
	</script>
	<?php
}
add_action( 'admin_footer', 'oasi_lots_admin_assets' );

/*
 * -------------------------------------------------------------------------
 * wp-admin: lotti sulla riga d'ordine.
 * -------------------------------------------------------------------------
 */

/**
 * Show which lots an order line was taken from (wp-admin only, not in emails).
 *
 * @param int   $item_id Order item ID.
 * @param mixed $item    Order item.
 */
function oasi_lots_render_order_item( int $item_id, mixed $item ): void {
	unset( $item_id );

	if ( ! ( $item instanceof WC_Order_Item_Product ) ) {
		return;
	}

	$alloc = $item->get_meta( OASI_LOTS_ALLOC_META, true );
	if ( ! is_array( $alloc ) || array() === $alloc ) {
		return;
	}

	$parts = array();
	foreach ( $alloc as $entry ) {
		$qty = wc_format_localized_decimal( oasi_lots_qty( $entry['qty'] ?? 0 ) );

		if ( OASI_LOTS_LEGACY === $entry['lot'] ) {
			/* translators: %s: quantity. */
			$parts[] = sprintf( __( 'precedente ai lotti × %s', 'oasidellespezie-child-theme' ), $qty );
			continue;
		}

		if ( OASI_LOTS_NONE === $entry['lot'] ) {
			/* translators: %s: quantity. */
			$parts[] = sprintf( __( 'senza lotto disponibile × %s', 'oasidellespezie-child-theme' ), $qty );
			continue;
		}

		$label = '' !== (string) $entry['code'] ? (string) $entry['code'] : __( '(senza codice)', 'oasidellespezie-child-theme' );
		if ( '' !== (string) $entry['expiry'] ) {
			/* translators: %s: expiry date. */
			$label .= ' ' . sprintf( __( '(scad. %s)', 'oasidellespezie-child-theme' ), oasi_lots_format_expiry( (string) $entry['expiry'] ) );
		}
		$parts[] = $label . ' × ' . $qty;
	}

	printf(
		'<div class="oasi-lots-order"><strong>%s</strong> %s</div>',
		esc_html__( 'Lotti:', 'oasidellespezie-child-theme' ),
		esc_html( implode( ' · ', $parts ) )
	);
}
add_action( 'woocommerce_after_order_itemmeta', 'oasi_lots_render_order_item', 10, 2 );

/**
 * Hide the raw allocation meta from the order item meta list.
 *
 * @param array<int, string> $hidden Hidden meta keys.
 * @return array<int, string>
 */
function oasi_lots_hide_item_meta( array $hidden ): array {
	$hidden[] = OASI_LOTS_ALLOC_META;

	return $hidden;
}
add_filter( 'woocommerce_hidden_order_itemmeta', 'oasi_lots_hide_item_meta' );
