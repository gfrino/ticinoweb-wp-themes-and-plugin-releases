<?php
/** Homepage editorial controls below ticinoWEB CMS. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Keep only unique, positive product IDs, in the editor-defined order. */
function oasi_home_sanitize_product_ids( $value ): array {
	$ids = is_array( $value ) ? $value : explode( ',', (string) $value );
	$ids = array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );

	return array_slice( $ids, 0, 12 );
}

/** Register the Homepage settings. */
function oasi_home_cms_register_settings(): void {
	register_setting( 'oasi_home_settings', 'oasi_home_bestseller_ids', array( 'type' => 'array', 'default' => array(), 'sanitize_callback' => 'oasi_home_sanitize_product_ids' ) );
	register_setting( 'oasi_home_settings', 'oasi_home_gift_ids', array( 'type' => 'array', 'default' => array(), 'sanitize_callback' => 'oasi_home_sanitize_product_ids' ) );
	register_setting( 'oasi_home_settings', 'oasi_home_bestseller_title', array( 'type' => 'string', 'default' => 'Novità e prodotti Best-Seller', 'sanitize_callback' => 'sanitize_text_field' ) );
	register_setting( 'oasi_home_settings', 'oasi_home_gift_title', array( 'type' => 'string', 'default' => 'Scoprite le nostre idee regalo...', 'sanitize_callback' => 'sanitize_text_field' ) );
	register_setting( 'oasi_home_settings', 'oasi_home_gift_intro', array( 'type' => 'string', 'default' => 'Cambiamo le nostre abitudini! Un regalo originale fa sempre piacere!', 'sanitize_callback' => 'sanitize_textarea_field' ) );
}
add_action( 'admin_init', 'oasi_home_cms_register_settings' );

function oasi_home_cms_option_capability(): string {
	return 'edit_pages';
}
add_filter( 'option_page_capability_oasi_home_settings', 'oasi_home_cms_option_capability' );

/** Add the dedicated editor below the existing CMS menu. */
function oasi_home_cms_menu(): void {
	add_submenu_page(
		'ticinoweb-cms',
		__( 'Homepage Oasi', 'oasidellespezie-child-theme' ),
		__( 'Homepage Oasi', 'oasidellespezie-child-theme' ),
		'edit_pages',
		'oasi-home-settings',
		'oasi_home_cms_render_page'
	);
}
add_action( 'admin_menu', 'oasi_home_cms_menu', 40 );

/** Load WooCommerce product search only on this editor. */
function oasi_home_cms_assets( string $hook ): void {
	if ( 'ticinoweb-cms_page_oasi-home-settings' !== $hook ) {
		return;
	}

	wp_enqueue_style( 'woocommerce_admin_styles' );
	wp_enqueue_script( 'wc-enhanced-select' );
	wp_enqueue_style( 'oasi-cms-editor', get_stylesheet_directory_uri() . '/assets/css/cms-editor.css', array(), wp_get_theme()->get( 'Version' ) );
}
add_action( 'admin_enqueue_scripts', 'oasi_home_cms_assets' );

/** Render a WooCommerce-native multi-product selector. */
function oasi_home_cms_product_select( string $name, array $ids, int $limit ): void {
	?>
	<select class="wc-product-search" multiple="multiple" style="width:100%" name="<?php echo esc_attr( $name ); ?>[]" data-placeholder="<?php esc_attr_e( 'Cerca un prodotto…', 'oasidellespezie-child-theme' ); ?>" data-action="woocommerce_json_search_products_and_variations" data-maximum-selection-length="<?php echo esc_attr( (string) $limit ); ?>">
		<?php foreach ( $ids as $product_id ) : ?>
			<?php $product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : null; ?>
			<?php if ( $product ) : ?><option value="<?php echo esc_attr( (string) $product_id ); ?>" selected><?php echo esc_html( wp_strip_all_tags( $product->get_formatted_name() ) ); ?></option><?php endif; ?>
		<?php endforeach; ?>
	</select>
	<?php
}

/** Homepage CMS screen. */
function oasi_home_cms_render_page(): void {
	if ( ! current_user_can( 'edit_pages' ) ) {
		wp_die( esc_html__( 'Non hai i permessi per modificare la Homepage.', 'oasidellespezie-child-theme' ) );
	}

	$bestsellers = oasi_home_sanitize_product_ids( get_option( 'oasi_home_bestseller_ids', array() ) );
	$gifts       = oasi_home_sanitize_product_ids( get_option( 'oasi_home_gift_ids', array() ) );
	?>
	<div class="wrap oasi-cms-editor">
		<h1><?php esc_html_e( 'Homepage Oasi', 'oasidellespezie-child-theme' ); ?></h1>
		<p class="oasi-cms-editor__lead"><?php esc_html_e( 'Scegli qui i prodotti e i testi delle vetrine principali. L’ordine della selezione è lo stesso mostrato sul sito.', 'oasidellespezie-child-theme' ); ?></p>
		<?php settings_errors(); ?>
		<form method="post" action="options.php">
			<?php settings_fields( 'oasi_home_settings' ); ?>
			<section class="oasi-cms-editor__section">
				<div class="oasi-cms-editor__section-heading"><div><span>01</span><h2><?php esc_html_e( 'Novità e prodotti Best-Seller', 'oasidellespezie-child-theme' ); ?></h2></div><p><?php esc_html_e( 'Seleziona fino a 8 prodotti. Se non scegli nulla, resta attiva la selezione verificata già presente.', 'oasidellespezie-child-theme' ); ?></p></div>
				<label class="oasi-cms-editor__field"><span><?php esc_html_e( 'Titolo della sezione', 'oasidellespezie-child-theme' ); ?></span><input type="text" class="large-text" name="oasi_home_bestseller_title" value="<?php echo esc_attr( (string) get_option( 'oasi_home_bestseller_title', 'Novità e prodotti Best-Seller' ) ); ?>"></label>
				<label class="oasi-cms-editor__field"><span><?php esc_html_e( 'Prodotti mostrati', 'oasidellespezie-child-theme' ); ?></span><?php oasi_home_cms_product_select( 'oasi_home_bestseller_ids', $bestsellers, 8 ); ?><small><?php esc_html_e( 'Digita almeno tre lettere del nome o il codice prodotto.', 'oasidellespezie-child-theme' ); ?></small></label>
			</section>
			<section class="oasi-cms-editor__section">
				<div class="oasi-cms-editor__section-heading"><div><span>02</span><h2><?php esc_html_e( 'Idee regalo', 'oasidellespezie-child-theme' ); ?></h2></div><p><?php esc_html_e( 'Seleziona fino a 5 prodotti e aggiorna il testo introduttivo.', 'oasidellespezie-child-theme' ); ?></p></div>
				<div class="oasi-cms-editor__grid"><label class="oasi-cms-editor__field"><span><?php esc_html_e( 'Titolo', 'oasidellespezie-child-theme' ); ?></span><input type="text" class="large-text" name="oasi_home_gift_title" value="<?php echo esc_attr( (string) get_option( 'oasi_home_gift_title', 'Scoprite le nostre idee regalo...' ) ); ?>"></label><label class="oasi-cms-editor__field"><span><?php esc_html_e( 'Testo breve', 'oasidellespezie-child-theme' ); ?></span><textarea class="large-text" rows="3" name="oasi_home_gift_intro"><?php echo esc_textarea( (string) get_option( 'oasi_home_gift_intro', 'Cambiamo le nostre abitudini! Un regalo originale fa sempre piacere!' ) ); ?></textarea></label></div>
				<label class="oasi-cms-editor__field"><span><?php esc_html_e( 'Prodotti mostrati', 'oasidellespezie-child-theme' ); ?></span><?php oasi_home_cms_product_select( 'oasi_home_gift_ids', $gifts, 5 ); ?></label>
			</section>
			<section class="oasi-cms-editor__section oasi-cms-editor__section--help">
				<div class="oasi-cms-editor__section-heading"><div><span>03</span><h2><?php esc_html_e( 'Novità, ricette e blog', 'oasidellespezie-child-theme' ); ?></h2></div></div>
				<p><?php esc_html_e( 'La pagina Novità si aggiorna automaticamente con gli articoli pubblicati. Per aggiungere una ricetta o una notizia crea un nuovo articolo, assegna immagine in evidenza e categoria, quindi pubblicalo.', 'oasidellespezie-child-theme' ); ?></p>
				<p class="oasi-cms-editor__actions"><a class="button button-primary" href="<?php echo esc_url( admin_url( 'post-new.php' ) ); ?>"><?php esc_html_e( 'Aggiungi articolo o ricetta', 'oasidellespezie-child-theme' ); ?></a><a class="button" href="<?php echo esc_url( admin_url( 'edit.php' ) ); ?>"><?php esc_html_e( 'Gestisci articoli esistenti', 'oasidellespezie-child-theme' ); ?></a></p>
			</section>
			<?php submit_button( __( 'Salva Homepage', 'oasidellespezie-child-theme' ) ); ?>
		</form>
	</div>
	<?php
}

/** Turn saved IDs into visible WooCommerce products. */
function oasi_home_products_from_ids( array $ids, int $limit ): array {
	$products = array();
	if ( ! function_exists( 'wc_get_product' ) ) {
		return $products;
	}
	foreach ( array_slice( $ids, 0, $limit ) as $id ) {
		$product = wc_get_product( $id );
		if ( $product && $product->is_visible() ) {
			$products[] = $product;
		}
	}
	return $products;
}

/** Curated bestseller rows, falling back to the existing verified list. */
function oasi_get_home_bestseller_showcase_products(): array {
	$products = oasi_home_products_from_ids( oasi_home_sanitize_product_ids( get_option( 'oasi_home_bestseller_ids', array() ) ), 8 );
	if ( empty( $products ) ) {
		return oasi_get_bestseller_showcase_products();
	}
	return array( 'row1' => array_slice( $products, 0, 4 ), 'row2' => array_slice( $products, 4, 4 ) );
}

/** Curated gift products, falling back to the current verified list. */
function oasi_get_home_gift_products(): array {
	$products = oasi_home_products_from_ids( oasi_home_sanitize_product_ids( get_option( 'oasi_home_gift_ids', array() ) ), 5 );
	return ! empty( $products ) ? $products : oasi_get_gift_boxes();
}
