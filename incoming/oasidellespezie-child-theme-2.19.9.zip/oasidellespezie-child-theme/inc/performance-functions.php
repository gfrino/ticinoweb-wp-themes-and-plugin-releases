<?php
/**
 * Front-end performance and privacy of third-party assets.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Serve Poppins from the child theme instead of Google Fonts.
 *
 * The parent enqueues `poppins-font` from fonts.googleapis.com (weights 300-700).
 * Every visitor's IP reached Google before any consent, it was one more
 * render-blocking third-party request, weight 300 was never used and weight 800
 * (used by the theme) was missing, so browsers faked the bold. The same handle
 * is re-registered on the local file, so every stylesheet that depends on
 * `poppins-font` keeps working without touching the parent theme.
 */
function oasi_self_host_poppins(): void {
	$file = get_stylesheet_directory() . '/assets/css/fonts.css';
	if ( ! is_file( $file ) ) {
		return;
	}

	wp_deregister_style( 'poppins-font' );
	wp_register_style( 'poppins-font', get_stylesheet_directory_uri() . '/assets/css/fonts.css', array(), (string) filemtime( $file ) );
	wp_enqueue_style( 'poppins-font' );
}
add_action( 'wp_enqueue_scripts', 'oasi_self_host_poppins', 999 );

/**
 * Remove the parent's preconnect to Google Fonts.
 *
 * A preconnect alone already opens a connection to Google, exposing the IP.
 * The parent adds it with an anonymous function on `wp_head` priority 0, so it
 * is identified by its file and by its source text, never by position.
 */
function oasi_remove_google_fonts_preconnect(): void {
	global $wp_filter;

	if ( empty( $wp_filter['wp_head'] ) || ! $wp_filter['wp_head'] instanceof WP_Hook ) {
		return;
	}

	$parent_functions = wp_normalize_path( get_template_directory() . '/functions.php' );

	foreach ( (array) ( $wp_filter['wp_head']->callbacks[0] ?? array() ) as $callback ) {
		if ( ! ( $callback['function'] instanceof Closure ) ) {
			continue;
		}

		try {
			$reflection = new ReflectionFunction( $callback['function'] );
		} catch ( ReflectionException $exception ) {
			continue;
		}

		if ( wp_normalize_path( (string) $reflection->getFileName() ) !== $parent_functions ) {
			continue;
		}

		$lines  = file( $parent_functions );
		$source = is_array( $lines ) ? implode( '', array_slice( $lines, $reflection->getStartLine() - 1, $reflection->getEndLine() - $reflection->getStartLine() + 1 ) ) : '';

		if ( str_contains( $source, 'fonts.gstatic.com' ) ) {
			remove_action( 'wp_head', $callback['function'], 0 );
		}
	}
}
add_action( 'wp_head', 'oasi_remove_google_fonts_preconnect', -1 );

/**
 * Preload the two Poppins faces used above the fold (body text and headings).
 */
function oasi_preload_poppins(): void {
	foreach ( array( 'poppins-400-latin.woff2', 'poppins-600-latin.woff2' ) as $font ) {
		printf(
			'<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n",
			esc_url( get_stylesheet_directory_uri() . '/assets/fonts/' . $font )
		);
	}
}
add_action( 'wp_head', 'oasi_preload_poppins', 1 );

/**
 * Preload the home hero image (the LCP element).
 *
 * The hero is an autoplay video whose poster is what the visitor sees first,
 * or an image when the CMS sets one: without a preload the browser discovers it
 * only after parsing the CSS and markup.
 */
function oasi_preload_home_hero(): void {
	if ( ! is_front_page() || ! function_exists( 'oasi_get_hero_data' ) ) {
		return;
	}

	$hero  = oasi_get_hero_data();
	$image = ! empty( $hero['is_video'] ) ? (string) ( $hero['poster_url'] ?? '' ) : (string) ( $hero['media_url'] ?? '' );

	if ( '' !== $image ) {
		printf( '<link rel="preload" as="image" href="%s" fetchpriority="high">' . "\n", esc_url( $image ) );
	}
}
add_action( 'wp_head', 'oasi_preload_home_hero', 2 );
