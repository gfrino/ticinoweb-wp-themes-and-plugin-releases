<?php
/**
 * HTTP security headers for this site only.
 *
 * Set here rather than in the shared .htaccess, which serves every site of the
 * multisite network. LiteSpeed Cache stores these headers with cached pages.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Send the baseline security headers on every front-end and admin response.
 *
 * Deliberately not set: a Content-Security-Policy (Stripe, reCAPTCHA of Ultimate
 * Member and the plugins inject inline and third-party scripts: a CSP needs its
 * own report-only rollout) and the `payment` Permissions-Policy feature (Apple Pay
 * and Google Pay run inside Stripe iframes).
 */
function oasi_send_security_headers(): void {
	if ( headers_sent() ) {
		return;
	}

	header( 'X-Content-Type-Options: nosniff' );
	header( 'X-Frame-Options: SAMEORIGIN' );
	header( 'Referrer-Policy: strict-origin-when-cross-origin' );
	header( 'Permissions-Policy: camera=(), microphone=(), geolocation=()' );

	if ( is_ssl() ) {
		// One year, this host only: subdomains are not verified to be HTTPS.
		header( 'Strict-Transport-Security: max-age=31536000' );
	}
}
add_action( 'send_headers', 'oasi_send_security_headers' );
add_action( 'admin_init', 'oasi_send_security_headers' );
