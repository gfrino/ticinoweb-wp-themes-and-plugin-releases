<?php
/**
 * Local-only outbound communication guard.
 *
 * These filters load only when this child theme is active, so they cannot
 * affect another multisite blog.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Determine whether the local Oasi safety policy applies.
 */
function oasi_local_safety_enabled(): bool {
	return defined( 'DOMAIN_CURRENT_SITE' ) && 'localhost:8081' === DOMAIN_CURRENT_SITE;
}

/**
 * Short-circuit outgoing WordPress email in the local multisite.
 *
 * @param null|bool $return Short-circuit value.
 * @param array     $attributes Mail arguments.
 * @return null|bool
 */
function oasi_block_outgoing_mail( null|bool $return, array $attributes ): null|bool {
	unset( $attributes );

	return oasi_local_safety_enabled() ? true : $return;
}
add_filter( 'pre_wp_mail', 'oasi_block_outgoing_mail', 10, 2 );

/**
 * Block non-loopback WordPress HTTP requests in the local multisite.
 *
 * @param false|array|WP_Error $preempt Short-circuit value.
 * @param array                $parsed_args HTTP request arguments.
 * @param string               $url Request URL.
 * @return false|array|WP_Error
 */
function oasi_block_external_request( false|array|WP_Error $preempt, array $parsed_args, string $url ): false|array|WP_Error {
	unset( $parsed_args );

	if ( ! oasi_local_safety_enabled() ) {
		return $preempt;
	}

	$host = wp_parse_url( $url, PHP_URL_HOST );
	if ( is_string( $host ) && in_array( strtolower( $host ), array( 'localhost', '127.0.0.1', '::1' ), true ) ) {
		return $preempt;
	}

	return new WP_Error(
		'oasi_local_http_blocked',
		__( 'External HTTP requests are disabled for Oasi delle Spezie in the local environment.', 'oasidellespezie-child-theme' )
	);
}
add_filter( 'pre_http_request', 'oasi_block_external_request', 10, 3 );

/**
 * Allow local preview of the shop catalog without coming soon barrier.
 */
add_filter( 'woocommerce_is_store_coming_soon', static function( $is_coming_soon ) {
	return oasi_local_safety_enabled() ? false : $is_coming_soon;
} );
add_filter( 'pre_option_woocommerce_coming_soon', static function( $val ) {
	return oasi_local_safety_enabled() ? 'no' : $val;
} );

/**
 * Prevent SSL redirect on local development where port 8081 is plain HTTP.
 */
add_filter( 'pre_option_woocommerce_force_ssl_checkout', static function( $val ) {
	return oasi_local_safety_enabled() ? 'no' : $val;
} );

add_filter( 'woocommerce_force_ssl_checkout', static function( $force_ssl ) {
	return oasi_local_safety_enabled() ? false : $force_ssl;
}, 20 );

add_filter( 'page_link', static function( string $url ): string {
	if ( oasi_local_safety_enabled() && str_starts_with( $url, 'https://localhost:8081/' ) ) {
		return str_replace( 'https://localhost:8081/', 'http://localhost:8081/', $url );
	}
	return $url;
}, 20 );

add_filter( 'woocommerce_get_page_permalink', static function( string $url ): string {
	if ( oasi_local_safety_enabled() && str_starts_with( $url, 'https://localhost:8081/' ) ) {
		return str_replace( 'https://localhost:8081/', 'http://localhost:8081/', $url );
	}
	return $url;
}, 20 );

