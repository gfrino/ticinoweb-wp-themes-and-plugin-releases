<?php
/**
 * SEO corrections for the Oasi templates, on top of the parent tW SEO engine.
 *
 * The parent theme is never modified: everything goes through its filters or
 * through WordPress/WooCommerce hooks.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Query arguments of the shop filter form: any of them makes a listing a filtered view.
 *
 * @return array<int, string>
 */
function oasi_seo_filter_args(): array {
	return array( 'oasi_q', 'oasi_cat', 'min_price', 'max_price', 'oasi_in_stock', 'oasi_on_sale', 'orderby', 'oasi_shop_partial' );
}

/**
 * Whether the current request is a filtered or sorted catalog view.
 */
function oasi_seo_is_filtered_listing(): bool {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only check of the query string.
	return (bool) array_intersect( oasi_seo_filter_args(), array_keys( $_GET ) );
}

/*
 * -------------------------------------------------------------------------
 * Structured data: Product instead of Article on product pages.
 * -------------------------------------------------------------------------
 */

/**
 * Build WooCommerce's Product JSON-LD on product pages.
 *
 * WooCommerce generates it from the `woocommerce_single_product_summary` hook,
 * which the Oasi product template does not fire (it renders price, cart and
 * details itself). Calling the generator directly adds price, currency,
 * availability (also "out of stock"), SKU and image for every product, without
 * firing the whole summary hook and its plugin output into the custom layout.
 * WooCommerce prints the collected data itself in the footer.
 */
function oasi_seo_product_structured_data(): void {
	if ( ! function_exists( 'is_product' ) || ! is_product() || ! function_exists( 'WC' ) || ! isset( WC()->structured_data ) ) {
		return;
	}

	$product = wc_get_product( get_queried_object_id() );
	if ( $product instanceof WC_Product ) {
		WC()->structured_data->generate_product_data( $product );
	}
}
add_action( 'wp_footer', 'oasi_seo_product_structured_data', 5 );

/**
 * Complete the Product JSON-LD with brand and all gallery images.
 *
 * @param array      $markup  Product markup.
 * @param WC_Product $product Product.
 * @return array
 */
function oasi_seo_product_markup( array $markup, $product ): array {
	$markup['brand'] = array(
		'@type' => 'Brand',
		'name'  => 'Oasi delle Spezie',
	);

	if ( $product instanceof WC_Product ) {
		$images = array();
		foreach ( array_merge( array( $product->get_image_id() ), $product->get_gallery_image_ids() ) as $image_id ) {
			$url = $image_id ? wp_get_attachment_image_url( (int) $image_id, 'large' ) : '';
			if ( $url ) {
				$images[] = $url;
			}
		}
		if ( $images ) {
			$markup['image'] = array_values( array_unique( $images ) );
		}
	}

	return $markup;
}
add_filter( 'woocommerce_structured_data_product', 'oasi_seo_product_markup', 10, 2 );

/**
 * Stop the parent from describing products as blog "Article".
 *
 * The parent's schema injector treats every single post type as an Article; on
 * a product that contradicts the Product data and has a "Title | Site" headline.
 */
function oasi_seo_remove_article_schema_on_products(): void {
	if ( function_exists( 'is_product' ) && is_product() ) {
		remove_action( 'wp_footer', 'tw_seo_inject_schema' );
	}
}
add_action( 'wp', 'oasi_seo_remove_article_schema_on_products' );

/**
 * Give the LocalBusiness schema a structured postal address.
 *
 * The parent puts the whole address into streetAddress.
 *
 * @param array $schema Organization / LocalBusiness schema.
 * @return array
 */
function oasi_seo_org_schema( array $schema ): array {
	$identity = function_exists( 'oasi_legal_get_identity' ) ? oasi_legal_get_identity() : array();
	$address  = (string) ( $identity['operational_address'] ?? '' );

	if ( preg_match( '/^(.+?),\s*(\d{4})\s+([^,]+)/u', $address, $parts ) ) {
		$schema['address'] = array(
			'@type'           => 'PostalAddress',
			'streetAddress'   => trim( $parts[1] ),
			'postalCode'      => $parts[2],
			'addressLocality' => trim( $parts[3] ),
			'addressRegion'   => 'TI',
			'addressCountry'  => 'CH',
		);
	}
	if ( ! empty( $identity['phone'] ) ) {
		$schema['telephone'] = (string) $identity['phone'];
	}
	if ( ! empty( $identity['email'] ) ) {
		$schema['email'] = (string) $identity['email'];
	}

	return $schema;
}
add_filter( 'ticinoweb_seo_jsonld_org_schema', 'oasi_seo_org_schema' );

/*
 * -------------------------------------------------------------------------
 * Indexing: filtered views and coming-soon mode.
 * -------------------------------------------------------------------------
 */

/**
 * Noindex filtered/sorted catalog views and the coming-soon placeholder.
 *
 * Filters: every combination of categories, prices, availability and sorting
 * returned an indexable 200 page, an endless crawl space of near-duplicates.
 * `follow` stays so products linked from them are still discovered.
 *
 * Coming soon: WooCommerce serves its placeholder with 200 on the real URLs;
 * without noindex Google can index the placeholder in place of the shop. The
 * option is read live, so this switches off by itself at launch.
 *
 * @param array $robots Robots directives.
 * @return array
 */
function oasi_seo_robots( array $robots ): array {
	$catalog = function_exists( 'oasi_is_shop_catalog' ) && oasi_is_shop_catalog();

	if ( $catalog && oasi_seo_is_filtered_listing() ) {
		$robots['noindex'] = true;
		$robots['follow']  = true;
		unset( $robots['index'] );
	}

	if ( 'yes' === get_option( 'woocommerce_coming_soon' ) && ! is_user_logged_in() ) {
		$robots['noindex'] = true;
		unset( $robots['index'] );
	}

	return $robots;
}
add_filter( 'wp_robots', 'oasi_seo_robots', 20 );

/**
 * Same signal as a header on the AJAX partial responses of the shop filter.
 */
function oasi_seo_partial_noindex_header(): void {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only check.
	if ( isset( $_GET['oasi_shop_partial'] ) && ! headers_sent() ) {
		header( 'X-Robots-Tag: noindex, follow' );
	}
}
add_action( 'send_headers', 'oasi_seo_partial_noindex_header' );

/*
 * -------------------------------------------------------------------------
 * Canonical and hreflang on paginated / archive listings.
 * -------------------------------------------------------------------------
 */

/**
 * Keep page 2+ of shop, categories and news self-canonical.
 *
 * The parent canonicalises every page of an archive to page 1, so Google treats
 * deeper pages (and the products only listed there) as duplicates. Filtered
 * views keep the parent's base canonical: they are noindexed anyway.
 *
 * @param string $canonical Canonical URL from the parent.
 * @return string
 */
function oasi_seo_paged_canonical( string $canonical ): string {
	$paged = max( (int) get_query_var( 'paged' ), (int) get_query_var( 'page' ) );

	if ( '' === $canonical || $paged < 2 || is_singular( 'post' ) || oasi_seo_is_filtered_listing() ) {
		return $canonical;
	}

	return (string) strtok( get_pagenum_link( $paged, false ), '?' );
}
add_filter( 'ticinoweb_seo_canonical_url', 'oasi_seo_paged_canonical' );

/**
 * Add hreflang alternates to the shop and product category listings.
 *
 * tW Translate prints them only on singular pages and the front page, so the
 * shop and the 45 category archives had none in three published languages.
 */
function oasi_seo_catalog_hreflang(): void {
	if ( ! function_exists( 'twtr_get_languages' ) || ! function_exists( 'oasi_is_shop_catalog' ) || ! oasi_is_shop_catalog() || oasi_seo_is_filtered_listing() || is_paged() ) {
		return;
	}

	$languages = twtr_get_languages();
	if ( count( $languages ) < 2 ) {
		return;
	}

	$default = '';
	foreach ( $languages as $language ) {
		if ( empty( $language['url'] ) ) {
			continue;
		}
		printf( '<link rel="alternate" hreflang="%s" href="%s" />' . "\n", esc_attr( (string) $language['slug'] ), esc_url( (string) $language['url'] ) );
		if ( ! empty( $language['is_default'] ) ) {
			$default = (string) $language['url'];
		}
	}

	if ( '' !== $default ) {
		printf( '<link rel="alternate" hreflang="x-default" href="%s" />' . "\n", esc_url( $default ) );
	}
}
add_action( 'wp_head', 'oasi_seo_catalog_hreflang', 3 );

/**
 * Use the SEO description written on the Shop page for the shop archive.
 *
 * The shop is a post-type archive, so the parent falls back to the global site
 * description and ignores the one set on the page itself.
 *
 * @param string $description Description from the parent.
 * @return string
 */
function oasi_seo_shop_description( string $description ): string {
	if ( ! function_exists( 'is_shop' ) || ! is_shop() || is_paged() ) {
		return $description;
	}

	$custom = trim( (string) get_post_meta( (int) wc_get_page_id( 'shop' ), '_tw_seo_description', true ) );

	return '' !== $custom ? $custom : $description;
}
add_filter( 'ticinoweb_seo_meta_description', 'oasi_seo_shop_description' );

/**
 * Serve a real 404 page instead of the parent's blanket redirect to the home.
 *
 * The parent 301-redirects every 404 to the home page: Google treats those as
 * soft 404s and every broken link turns into a signal for the home page. Oasi
 * has its own 404.php (shop search and links back), so on this site only the
 * redirect is removed; the parent keeps it for the other ticinoWEB sites.
 * Specific redirects (e.g. the retired terms page) run earlier on template_redirect.
 */
function oasi_seo_keep_real_404(): void {
	remove_action( 'template_redirect', 'ticinoweb_redirect_404_to_home' );
}
add_action( 'wp', 'oasi_seo_keep_real_404' );
