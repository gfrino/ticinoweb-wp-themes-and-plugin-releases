<?php
/**
 * Shared WooCommerce product-category hierarchy helpers.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return direct-plus-descendant product counts for every supplied category.
 *
 * WooCommerce stores only each term's direct count, so a container category
 * with products exclusively in its children otherwise displays zero.
 *
 * @param WP_Term[] $terms Product category terms.
 * @return array<int, int> Counts keyed by term ID.
 */
function oasi_category_aggregate_counts( array $terms ): array {
	$children_by_parent = array();
	$direct_counts      = array();
	foreach ( $terms as $term ) {
		$term_id                            = (int) $term->term_id;
		$direct_counts[ $term_id ]          = (int) $term->count;
		$children_by_parent[ (int) $term->parent ][] = $term_id;
	}

	$counts = array();
	$walk   = static function ( int $term_id, array $ancestors = array() ) use ( &$walk, &$counts, $children_by_parent, $direct_counts ): int {
		if ( isset( $counts[ $term_id ] ) ) {
			return $counts[ $term_id ];
		}
		if ( isset( $ancestors[ $term_id ] ) ) {
			return $direct_counts[ $term_id ] ?? 0;
		}

		$ancestors[ $term_id ] = true;
		$total                 = $direct_counts[ $term_id ] ?? 0;
		foreach ( $children_by_parent[ $term_id ] ?? array() as $child_id ) {
			$total += $walk( $child_id, $ancestors );
		}

		return $counts[ $term_id ] = $total;
	};

	foreach ( array_keys( $direct_counts ) as $term_id ) {
		$walk( $term_id );
	}

	return $counts;
}
