<?php
/**
 * Routing and presentation helpers for the WooCommerce checkout.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Determine whether the request is the main editable checkout screen.
 */
function oasi_is_main_checkout(): bool {
	if ( ! function_exists( 'is_checkout' ) || ! is_checkout() ) {
		return false;
	}

	if ( function_exists( 'is_wc_endpoint_url' ) ) {
		if ( is_wc_endpoint_url( 'order-received' ) || is_wc_endpoint_url( 'order-pay' ) ) {
			return false;
		}
	}

	return true;
}

/**
 * Use the child-owned checkout page only for the main checkout route.
 *
 * @param string $template Template selected by WordPress.
 * @return string
 */
function oasi_checkout_template_include( string $template ): string {
	if ( ! oasi_is_main_checkout() ) {
		return $template;
	}

	$checkout_template = get_stylesheet_directory() . '/page-checkout.php';
	return is_file( $checkout_template ) ? $checkout_template : $template;
}
add_filter( 'template_include', 'oasi_checkout_template_include', 60 );

/**
 * Apply presentation metadata to an existing checkout field.
 *
 * No field is created here: missing or plugin-owned fields remain untouched.
 *
 * @param array<string, array<string, mixed>> $group Field group.
 * @param string                              $key Field key.
 * @param string                              $label Italian label.
 * @param array<int, string>                  $classes Layout classes.
 * @param string                              $placeholder Optional placeholder.
 */
function oasi_checkout_present_field( array &$group, string $key, string $label, array $classes, string $placeholder = '' ): void {
	if ( ! isset( $group[ $key ] ) || ! is_array( $group[ $key ] ) ) {
		return;
	}

	$group[ $key ]['label'] = $label;
	$group[ $key ]['class'] = $classes;

	if ( '' !== $placeholder ) {
		$group[ $key ]['placeholder'] = $placeholder;
	}
}

/**
 * Normalize labels and grid classes on WooCommerce's existing checkout fields.
 *
 * @param array<string, array<string, array<string, mixed>>> $fields Checkout fields.
 * @return array<string, array<string, array<string, mixed>>>
 */
function oasi_checkout_filter_fields( array $fields ): array {
	foreach ( array( 'billing', 'shipping' ) as $group_name ) {
		if ( empty( $fields[ $group_name ] ) || ! is_array( $fields[ $group_name ] ) ) {
			continue;
		}

		$prefix = $group_name . '_';
		oasi_checkout_present_field( $fields[ $group_name ], $prefix . 'first_name', __( 'Nome', 'oasidellespezie-child-theme' ), array( 'form-row-first' ) );
		oasi_checkout_present_field( $fields[ $group_name ], $prefix . 'last_name', __( 'Cognome', 'oasidellespezie-child-theme' ), array( 'form-row-last' ) );
		oasi_checkout_present_field( $fields[ $group_name ], $prefix . 'company', __( 'Azienda (opzionale)', 'oasidellespezie-child-theme' ), array( 'form-row-wide' ) );
		oasi_checkout_present_field( $fields[ $group_name ], $prefix . 'country', __( 'Paese/regione', 'oasidellespezie-child-theme' ), array( 'form-row-wide' ) );
		oasi_checkout_present_field( $fields[ $group_name ], $prefix . 'address_1', __( 'Via e numero', 'oasidellespezie-child-theme' ), array( 'form-row-wide' ), __( 'Nome della via e numero civico', 'oasidellespezie-child-theme' ) );
		oasi_checkout_present_field( $fields[ $group_name ], $prefix . 'address_2', __( 'Appartamento, interno, piano (opzionale)', 'oasidellespezie-child-theme' ), array( 'form-row-wide' ) );
		oasi_checkout_present_field( $fields[ $group_name ], $prefix . 'postcode', __( 'CAP', 'oasidellespezie-child-theme' ), array( 'form-row-first' ) );
		oasi_checkout_present_field( $fields[ $group_name ], $prefix . 'city', __( 'Città', 'oasidellespezie-child-theme' ), array( 'form-row-last' ) );
		oasi_checkout_present_field( $fields[ $group_name ], $prefix . 'state', __( 'Cantone', 'oasidellespezie-child-theme' ), array( 'form-row-first' ) );
	}

	if ( ! empty( $fields['billing'] ) && is_array( $fields['billing'] ) ) {
		oasi_checkout_present_field( $fields['billing'], 'billing_phone', __( 'Telefono', 'oasidellespezie-child-theme' ), array( 'form-row-last' ) );
		oasi_checkout_present_field( $fields['billing'], 'billing_email', __( 'Email', 'oasidellespezie-child-theme' ), array( 'form-row-wide' ) );
	}

	if ( ! empty( $fields['order'] ) && is_array( $fields['order'] ) ) {
		oasi_checkout_present_field(
			$fields['order'],
			'order_comments',
			__( 'Note sull’ordine (opzionale)', 'oasidellespezie-child-theme' ),
			array( 'form-row-wide' ),
			__( 'Indicazioni utili per la preparazione o la consegna.', 'oasidellespezie-child-theme' )
		);
	}

	return $fields;
}
add_filter( 'woocommerce_checkout_fields', 'oasi_checkout_filter_fields', 30 );

/**
 * Localize the existing Advanced Coupons Store Credits checkout UI.
 *
 * @param array<string, string> $labels Plugin labels.
 * @return array<string, string>
 */
function oasi_checkout_store_credit_labels( array $labels ): array {
	$labels['toggle_text']  = __( 'Vuoi applicare Store Credits?', 'oasidellespezie-child-theme' );
	$labels['placeholder']  = __( 'Importo da utilizzare', 'oasidellespezie-child-theme' );
	$labels['balance_text'] = __( 'Saldo Store Credits disponibile: %s', 'oasidellespezie-child-theme' );
	$labels['instructions'] = __( 'Inserisci l’importo che desideri applicare a questo ordine.', 'oasidellespezie-child-theme' );

	return $labels;
}
add_filter( 'acfw_funnelkit_store_credit_field_labels', 'oasi_checkout_store_credit_labels', 30 );

/**
 * Remove the invalid configured image from the Stripe credit-card option.
 *
 * The payment method itself remains unchanged; only its broken decorative
 * image is suppressed. Other gateway icons are preserved verbatim.
 *
 * @param string $icon       Gateway icon markup.
 * @param string $gateway_id Gateway identifier.
 * @return string
 */
function oasi_checkout_gateway_icon( string $icon, string $gateway_id ): string {
	if ( 'stripe_cc' === $gateway_id ) {
		return '';
	}

	return $icon;
}
add_filter( 'woocommerce_gateway_icon', 'oasi_checkout_gateway_icon', 30, 2 );

/**
 * Replace the two raw Punti Acquisto blocks with one native disclosure.
 */
function oasi_checkout_wrap_loyalty_hooks(): void {
	static $wrapped = false;

	if ( $wrapped || ( ! function_exists( 'PA_display_points_info' ) && ! function_exists( 'PA_redemption_field' ) ) ) {
		return;
	}

	$info_priority = has_action( 'woocommerce_review_order_before_payment', 'PA_display_points_info' );
	if ( false !== $info_priority ) {
		remove_action( 'woocommerce_review_order_before_payment', 'PA_display_points_info', (int) $info_priority );
	}

	$redeem_priority = has_action( 'woocommerce_review_order_before_payment', 'PA_redemption_field' );
	if ( false !== $redeem_priority ) {
		remove_action( 'woocommerce_review_order_before_payment', 'PA_redemption_field', (int) $redeem_priority );
	}

	add_action( 'woocommerce_review_order_before_payment', 'oasi_checkout_render_loyalty_tool', 10 );
	$wrapped = true;
}
add_action( 'wp_loaded', 'oasi_checkout_wrap_loyalty_hooks', 40 );

/**
 * Render the original Punti Acquisto callbacks inside an accessible disclosure.
 */
function oasi_checkout_render_loyalty_tool(): void {
	if ( ! function_exists( 'PA_display_points_info' ) && ! function_exists( 'PA_redemption_field' ) ) {
		return;
	}
	?>
	<details class="oasi-checkout-tool oasi-checkout-tool--points">
		<summary><?php esc_html_e( 'Vuoi usare i punti fedeltà?', 'oasidellespezie-child-theme' ); ?></summary>
		<div class="oasi-checkout-tool__content">
			<?php
			if ( function_exists( 'PA_display_points_info' ) ) {
				PA_display_points_info();
			}
			if ( function_exists( 'PA_redemption_field' ) ) {
				PA_redemption_field();
			}
			?>
		</div>
	</details>
	<?php
}

/**
 * Add a concise reassurance after WooCommerce's dynamic order button.
 */
function oasi_checkout_render_security_note(): void {
	?>
	<p class="oasi-checkout-security-note">
		<span aria-hidden="true">✓</span>
		<?php esc_html_e( 'Pagamento protetto e ordine elaborato in sicurezza', 'oasidellespezie-child-theme' ); ?>
	</p>
	<?php
}
add_action( 'woocommerce_review_order_after_submit', 'oasi_checkout_render_security_note', 20 );
