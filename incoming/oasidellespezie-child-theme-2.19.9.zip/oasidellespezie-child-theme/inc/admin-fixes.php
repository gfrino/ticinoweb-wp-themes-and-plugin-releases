<?php
/**
 * Correzioni wp-admin a bug di plugin terzi, senza toccare i plugin.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WooCommerce 11.1 + WordPress 7.1: the default product category shows no name.
 *
 * WooCommerce moves the "default category" help tip into the row's first <th>,
 * emptying it first. Since WordPress 7.1 the checkbox cell is a <td> and the first
 * <th> is the name cell, so the category name is wiped from the list (the data is
 * intact). Replace that inline script with one that targets the checkbox cell.
 */
function oasi_fix_default_product_cat_tip(): void {
	$scripts = wp_scripts();
	$handle  = 'wc-admin-taxonomies';

	if ( ! isset( $scripts->registered[ $handle ] ) ) {
		return;
	}

	$default_cat = absint( get_option( 'default_product_cat', 0 ) );

	$scripts->registered[ $handle ]->extra['after'] = array(
		sprintf(
			"(function () {
				'use strict';
				var row = document.getElementById('tag-%d');
				if (!row) { return; }
				var cell = row.querySelector('.check-column');
				var tip = row.querySelector('td.thumb .woocommerce-help-tip');
				if (cell && tip && !cell.querySelector('input')) {
					cell.appendChild(tip);
				}
			})();",
			$default_cat
		),
	);
}
add_action( 'admin_footer', 'oasi_fix_default_product_cat_tip', 11 );
