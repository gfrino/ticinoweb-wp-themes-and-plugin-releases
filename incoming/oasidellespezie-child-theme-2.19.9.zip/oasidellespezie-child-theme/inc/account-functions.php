<?php
/**
 * Routing and presentation helpers for the WooCommerce account area.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Use the child-owned account surface for the WooCommerce account page and endpoints.
 *
 * @param string $template Template selected by WordPress.
 * @return string
 */
function oasi_account_template_include( string $template ): string {
	if ( ! function_exists( 'is_account_page' ) || ! is_account_page() ) {
		return $template;
	}

	$account_template = get_stylesheet_directory() . '/page-account.php';
	return is_file( $account_template ) ? $account_template : $template;
}
add_filter( 'template_include', 'oasi_account_template_include', 60 );

/**
 * Return the account label without introducing a second role source.
 *
 * @param WP_User|null $user User to inspect.
 * @return string
 */
function oasi_account_get_role_label( ?WP_User $user = null ): string {
	$user = $user instanceof WP_User ? $user : wp_get_current_user();

	if ( function_exists( 'oasi_professional_get_access_state' ) ) {
		return 'professional' === oasi_professional_get_access_state( $user )
			? __( 'Account professionale', 'oasidellespezie-child-theme' )
			: __( 'Cliente registrato', 'oasidellespezie-child-theme' );
	}

	return in_array( 'wholesale_customer', (array) $user->roles, true )
		? __( 'Account professionale', 'oasidellespezie-child-theme' )
		: __( 'Cliente registrato', 'oasidellespezie-child-theme' );
}

/**
 * Build a compact, decorative monogram from the existing display name.
 *
 * @param WP_User $user Current user.
 * @return string
 */
function oasi_account_get_initials( WP_User $user ): string {
	$name  = trim( (string) ( $user->display_name ?: $user->user_login ) );
	$parts = preg_split( '/\s+/u', $name, -1, PREG_SPLIT_NO_EMPTY );

	if ( empty( $parts ) ) {
		return 'O';
	}

	$first = function_exists( 'mb_substr' ) ? mb_substr( $parts[0], 0, 1 ) : substr( $parts[0], 0, 1 );
	$last  = count( $parts ) > 1
		? ( function_exists( 'mb_substr' ) ? mb_substr( $parts[ count( $parts ) - 1 ], 0, 1 ) : substr( $parts[ count( $parts ) - 1 ], 0, 1 ) )
		: '';
	$value = $first . $last;

	return function_exists( 'mb_strtoupper' ) ? mb_strtoupper( $value ) : strtoupper( $value );
}

/**
 * Return the real WooCommerce Shop URL with a safe local fallback.
 */
function oasi_account_get_shop_url(): string {
	if ( function_exists( 'wc_get_page_permalink' ) ) {
		$url = wc_get_page_permalink( 'shop' );
		if ( $url ) {
			return (string) $url;
		}
	}

	return home_url( '/shop-online-oasi-delle-spezie/' );
}

/**
 * Normalize a visible account-menu label for duplicate detection.
 *
 * Endpoint registrations remain untouched: this value is used only to avoid
 * rendering the same visible destination more than once.
 *
 * @param string $label Visible menu label.
 * @return string
 */
function oasi_account_normalize_navigation_label( string $label ): string {
	$label = html_entity_decode( wp_strip_all_tags( $label ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
	$label = function_exists( 'remove_accents' ) ? remove_accents( $label ) : $label;
	$label = function_exists( 'mb_strtolower' ) ? mb_strtolower( $label ) : strtolower( $label );

	return trim( (string) preg_replace( '/\s+/u', ' ', $label ) );
}

/**
 * Return the real WooCommerce account items with presentation duplicates removed.
 *
 * The first endpoint registered for a visible label wins. Logout is always
 * presented last even when a plugin appends another endpoint after it.
 *
 * @param array<string,string>|null $items Optional menu items for testing.
 * @return array<string,string>
 */
function oasi_account_get_navigation_items( ?array $items = null ): array {
	$items  = is_array( $items ) ? $items : ( function_exists( 'wc_get_account_menu_items' ) ? wc_get_account_menu_items() : array() );
	$unique = array();
	$seen   = array();
	$logout = null;

	foreach ( $items as $endpoint => $label ) {
		$endpoint = (string) $endpoint;
		$label    = (string) $label;

		if ( 'customer-logout' === $endpoint ) {
			$logout = $label;
			continue;
		}

		$normalized = oasi_account_normalize_navigation_label( $label );
		if ( '' !== $normalized && isset( $seen[ $normalized ] ) ) {
			continue;
		}

		if ( '' !== $normalized ) {
			$seen[ $normalized ] = true;
		}
		$unique[ $endpoint ] = $label;
	}

	if ( null !== $logout ) {
		$unique['customer-logout'] = $logout;
	}

	return $unique;
}

/**
 * Return the current visible account-section label.
 *
 * @param array<string,string> $items Navigation items.
 * @return string
 */
function oasi_account_get_current_navigation_label( array $items ): string {
	foreach ( $items as $endpoint => $label ) {
		if ( function_exists( 'wc_is_current_account_menu_item' ) && wc_is_current_account_menu_item( (string) $endpoint ) ) {
			return (string) $label;
		}
	}

	return (string) ( reset( $items ) ?: __( 'Il mio account', 'oasidellespezie-child-theme' ) );
}

/**
 * Read the Advanced Coupons store-credit balance through its public model.
 *
 * @param int $user_id Current customer ID.
 * @return float|null Null when the plugin API is unavailable.
 */
function oasi_account_get_store_credit_balance( int $user_id ): ?float {
	if ( $user_id <= 0 || ! function_exists( 'ACFWF' ) ) {
		return null;
	}

	try {
		$plugin     = ACFWF();
		$calculator = is_object( $plugin ) ? $plugin->Store_Credits_Calculate : null;

		return is_object( $calculator ) && is_callable( array( $calculator, 'get_customer_balance' ) )
			? (float) $calculator->get_customer_balance( $user_id )
			: null;
	} catch ( Throwable $exception ) {
		unset( $exception );
		return null;
	}
}

/**
 * Collect read-only dashboard data for the current customer.
 *
 * @param WP_User|null $user Customer to inspect.
 * @return array<string,mixed>
 */
function oasi_account_get_dashboard_data( ?WP_User $user = null ): array {
	$user    = $user instanceof WP_User ? $user : wp_get_current_user();
	$user_id = isset( $user->ID ) ? (int) $user->ID : 0;
	$data    = array(
		'order_count'     => 0,
		'recent_orders'   => array(),
		'points'          => null,
		'store_credit'    => null,
		'billing_address' => '',
		'payment_tokens'  => array(),
	);

	if ( $user_id <= 0 ) {
		return $data;
	}

	if ( function_exists( 'wc_get_customer_order_count' ) ) {
		$data['order_count'] = (int) wc_get_customer_order_count( $user_id );
	}

	if ( function_exists( 'wc_get_orders' ) ) {
		$order_args = array(
			'customer_id' => $user_id,
			'limit'       => 3,
			'orderby'     => 'date',
			'order'       => 'DESC',
		);

		if ( function_exists( 'wc_get_order_statuses' ) ) {
			$order_args['status'] = array_keys( wc_get_order_statuses() );
		}

		$data['recent_orders'] = wc_get_orders( $order_args );
	}

	if ( function_exists( 'PA_get_user_points' ) ) {
		$data['points'] = (int) PA_get_user_points( $user_id );
	}

	$data['store_credit'] = oasi_account_get_store_credit_balance( $user_id );

	if ( function_exists( 'wc_get_account_formatted_address' ) ) {
		$data['billing_address'] = (string) wc_get_account_formatted_address( 'billing', $user_id );
	}

	if ( class_exists( 'WC_Payment_Tokens' ) && is_callable( array( 'WC_Payment_Tokens', 'get_customer_tokens' ) ) ) {
		$data['payment_tokens'] = WC_Payment_Tokens::get_customer_tokens( $user_id );
	}

	return $data;
}

/**
 * Return a theme-owned icon for a WooCommerce account endpoint.
 *
 * Unknown endpoints receive a neutral icon so plugin-added menu items remain usable.
 *
 * @param string $endpoint WooCommerce account endpoint.
 * @return string
 */
function oasi_account_get_navigation_icon( string $endpoint ): string {
	$icons = array(
		'dashboard'       => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z"/></svg>',
		'orders'          => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 4h14v16H5zM8 8h8M8 12h8M8 16h5"/></svg>',
		'downloads'       => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3v12m-4-4 4 4 4-4M5 20h14"/></svg>',
		'edit-address'    => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/></svg>',
		'payment-methods' => '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18M7 15h4"/></svg>',
		'edit-account'    => '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg>',
		'points-history'  => '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8"/><path d="M12 7v10M8.5 9.5C8.5 8.1 10 7 12 7s3.5 1.1 3.5 2.5S14 12 12 12s-3.5 1.1-3.5 2.5S10 17 12 17s3.5-1.1 3.5-2.5"/></svg>',
		'store-credit'     => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16v12H4zM7 4h10M4 11h16"/><circle cx="16" cy="15" r="1"/></svg>',
		'my-coupons'      => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7a3 3 0 0 0 3-3h10a3 3 0 0 0 3 3v3a3 3 0 0 0 0 6v3a3 3 0 0 0-3 3H7a3 3 0 0 0-3-3v-3a3 3 0 0 0 0-6zM12 7v10"/></svg>',
		'customer-logout' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M10 4H5v16h5M14 8l4 4-4 4M18 12H9"/></svg>',
	);

	return $icons[ $endpoint ] ?? '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8"/><path d="M12 8v8M8 12h8"/></svg>';
}
