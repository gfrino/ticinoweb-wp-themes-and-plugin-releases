<?php
/** Gift Voucher page routing. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function oasi_gift_voucher_template_include( string $template ): string {
	if ( ! is_page( 'buono-regalo' ) ) {
		return $template;
	}
	$child_template = get_stylesheet_directory() . '/page-buono-regalo.php';
	return is_file( $child_template ) ? $child_template : $template;
}
add_filter( 'template_include', 'oasi_gift_voucher_template_include', 99 );
