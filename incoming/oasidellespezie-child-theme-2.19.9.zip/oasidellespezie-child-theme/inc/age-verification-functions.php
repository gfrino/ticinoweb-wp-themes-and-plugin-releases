<?php
/**
 * Age check for alcoholic beverages.
 *
 * Swiss law forbids selling spirits and liqueurs to anyone under 18 (LAlc art. 41)
 * and beer or wine to anyone under 16. The shop sells liqueurs and grappa in the
 * "Bevande alcoliche" category. Every product in it is treated as 18+, which
 * also covers wine and beer.
 *
 * - product page: clear notice under the price;
 * - checkout: mandatory declaration when the cart contains alcohol, validated
 *   server side and stored on the order (visible in wp-admin);
 * - express buttons (Google Pay / Apple Pay / Link on product and cart pages)
 *   are hidden for alcohol: they skip the checkout form and so the declaration.
 *
 * In-store POS sales are checked by the staff at the counter and are not affected.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const OASI_AGE_CATEGORY   = 'bevande-alcoliche';
const OASI_AGE_MINIMUM    = 18;
const OASI_AGE_ORDER_META = '_oasi_age_confirmed';

/**
 * Whether a product (or the parent of a variation) is an alcoholic beverage.
 *
 * @param mixed $product Product object or ID.
 */
function oasi_age_product_is_alcohol( mixed $product ): bool {
	$product = $product instanceof WC_Product ? $product : wc_get_product( $product );
	if ( ! $product instanceof WC_Product ) {
		return false;
	}

	$id = $product->get_parent_id() ?: $product->get_id();

	return has_term( OASI_AGE_CATEGORY, 'product_cat', $id );
}

/**
 * Whether the current cart contains an alcoholic beverage.
 */
function oasi_age_cart_has_alcohol(): bool {
	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		return false;
	}

	foreach ( WC()->cart->get_cart() as $item ) {
		if ( ! empty( $item['data'] ) && oasi_age_product_is_alcohol( $item['data'] ) ) {
			return true;
		}
	}

	return false;
}

/**
 * Notice on alcoholic products, just above the add-to-cart form.
 */
function oasi_age_product_notice(): void {
	global $product;

	if ( ! oasi_age_product_is_alcohol( $product ) ) {
		return;
	}

	printf(
		'<p class="oasi-age-notice" role="note"><span class="oasi-age-notice__badge" aria-hidden="true">%1$d+</span> %2$s</p>',
		(int) OASI_AGE_MINIMUM,
		esc_html(
			sprintf(
				/* translators: %d: minimum age. */
				__( 'Bevanda alcolica: vendita vietata ai minori di %d anni. Al momento dell’ordine ti chiederemo di confermare la maggiore età.', 'oasidellespezie-child-theme' ),
				OASI_AGE_MINIMUM
			)
		)
	);
}
add_action( 'woocommerce_before_add_to_cart_form', 'oasi_age_product_notice', 5 );

/**
 * Mandatory declaration in the checkout, just above the order button.
 */
function oasi_age_checkout_field(): void {
	if ( ! oasi_age_cart_has_alcohol() ) {
		return;
	}
	?>
	<div class="oasi-age-confirm">
		<label class="woocommerce-form__label woocommerce-form__label-for-checkbox checkbox">
			<input type="checkbox" class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" name="oasi_age_confirm" id="oasi_age_confirm" value="1" />
			<span>
				<?php
				echo esc_html(
					sprintf(
						/* translators: %d: minimum age. */
						__( 'Confermo di avere almeno %d anni. Le bevande alcoliche vengono vendute e consegnate solo a persone maggiorenni; potremo richiedere un documento d’identità alla consegna o al ritiro.', 'oasidellespezie-child-theme' ),
						OASI_AGE_MINIMUM
					)
				);
				?>
			</span>&nbsp;<abbr class="required" title="<?php esc_attr_e( 'obbligatorio', 'oasidellespezie-child-theme' ); ?>">*</abbr>
		</label>
	</div>
	<?php
}
add_action( 'woocommerce_review_order_before_submit', 'oasi_age_checkout_field', 5 );

/**
 * Block the order when the cart contains alcohol and the declaration is missing.
 *
 * @param array    $data   Posted checkout data.
 * @param WP_Error $errors Checkout errors.
 */
function oasi_age_checkout_validate( array $data, WP_Error $errors ): void {
	unset( $data );

	// phpcs:ignore WordPress.Security.NonceVerification.Missing -- WooCommerce verified the checkout nonce.
	if ( oasi_age_cart_has_alcohol() && empty( $_POST['oasi_age_confirm'] ) ) {
		$errors->add(
			'oasi_age_confirm',
			sprintf(
				/* translators: %d: minimum age. */
				__( 'Il carrello contiene bevande alcoliche: per procedere conferma di avere almeno %d anni.', 'oasidellespezie-child-theme' ),
				OASI_AGE_MINIMUM
			)
		);
	}
}
add_action( 'woocommerce_after_checkout_validation', 'oasi_age_checkout_validate', 10, 2 );

/**
 * Record the declaration on the order (date and time, for traceability).
 *
 * @param WC_Order $order Order being created.
 */
function oasi_age_save_confirmation( WC_Order $order ): void {
	// phpcs:ignore WordPress.Security.NonceVerification.Missing -- WooCommerce verified the checkout nonce.
	if ( ! empty( $_POST['oasi_age_confirm'] ) && oasi_age_cart_has_alcohol() ) {
		$order->update_meta_data( OASI_AGE_ORDER_META, current_time( 'mysql' ) );
	}
}
add_action( 'woocommerce_checkout_create_order', 'oasi_age_save_confirmation' );

/**
 * Show the declaration to staff in the order screen.
 *
 * @param WC_Order $order Order.
 */
function oasi_age_admin_order_notice( $order ): void {
	if ( ! $order instanceof WC_Order ) {
		return;
	}

	$confirmed = (string) $order->get_meta( OASI_AGE_ORDER_META );
	if ( '' === $confirmed ) {
		return;
	}

	printf(
		'<p class="form-field form-field-wide"><strong>%s</strong><br>%s</p>',
		esc_html__( 'Bevande alcoliche', 'oasidellespezie-child-theme' ),
		esc_html(
			sprintf(
				/* translators: 1: minimum age, 2: date and time. */
				__( 'Il cliente ha dichiarato di avere almeno %1$d anni (%2$s). Verificare il documento alla consegna o al ritiro.', 'oasidellespezie-child-theme' ),
				OASI_AGE_MINIMUM,
				mysql2date( 'd.m.Y H:i', $confirmed )
			)
		)
	);
}
add_action( 'woocommerce_admin_order_data_after_billing_address', 'oasi_age_admin_order_notice' );

/**
 * Hide Stripe express buttons on alcoholic product pages.
 *
 * @param array $gateways Express gateways.
 * @param mixed $product  Product.
 * @return array
 */
function oasi_age_hide_product_express( $gateways, $product = null ) {
	return oasi_age_product_is_alcohol( $product ) ? array() : $gateways;
}
add_filter( 'wc_stripe_product_payment_methods', 'oasi_age_hide_product_express', 20, 2 );

/**
 * Hide Stripe express buttons in the cart when it contains alcohol.
 *
 * @param array $gateways Express gateways.
 * @return array
 */
function oasi_age_hide_cart_express( $gateways ) {
	return oasi_age_cart_has_alcohol() ? array() : $gateways;
}
add_filter( 'wc_stripe_cart_payment_methods', 'oasi_age_hide_cart_express', 20 );

/**
 * Minimal styles for the notice and the declaration.
 */
function oasi_age_styles(): void {
	if ( ! ( function_exists( 'is_product' ) && is_product() ) && ! ( function_exists( 'is_checkout' ) && is_checkout() ) ) {
		return;
	}

	wp_register_style( 'oasi-age', false, array(), null );
	wp_enqueue_style( 'oasi-age' );
	wp_add_inline_style(
		'oasi-age',
		'.oasi-age-notice{display:flex;align-items:center;gap:10px;margin:0 0 16px;padding:10px 14px;border:1px solid rgba(139,58,43,.18);border-radius:12px;background:#fcf6f3;color:var(--oasi-color-primary-dark,#68261a);font-size:.8125rem;line-height:1.45}'
		. '.oasi-age-notice__badge{flex:0 0 auto;display:inline-grid;place-items:center;min-width:34px;height:34px;border-radius:50%;background:var(--oasi-color-primary,#8b3a2b);color:#fff;font-weight:700;font-size:.8125rem}'
		. '.oasi-age-confirm{margin:0 0 16px;padding:12px 14px;border:1px solid rgba(139,58,43,.22);border-radius:12px;background:#fcf6f3}'
		. '.oasi-age-confirm label{display:flex;gap:10px;align-items:flex-start;line-height:1.45;font-size:.875rem}'
		. '.oasi-age-confirm input{margin-top:3px;flex:0 0 auto;accent-color:var(--oasi-color-primary,#8b3a2b)}'
	);
}
add_action( 'wp_enqueue_scripts', 'oasi_age_styles', 30 );
