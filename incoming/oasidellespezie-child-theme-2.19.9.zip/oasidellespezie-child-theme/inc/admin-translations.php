<?php
/**
 * Italian wp-admin labels for product-pricing plugins used by Oasi.
 *
 * The bundled Italian catalogue of WooCommerce Wholesale Prices is incomplete
 * and the Premium extension ships without an Italian catalogue. Keep these
 * site-specific corrections in the child theme so plugin updates remain safe.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Translate product-pricing labels that are missing from third-party catalogues.
 *
 * @param string $translated_text Translation selected by WordPress.
 * @param string $source_text     Original plugin string.
 * @param string $domain          Plugin text domain.
 * @return string
 */
function oasi_translate_product_pricing_admin_text( string $translated_text, string $source_text, string $domain ): string {
	if ( ! is_admin() ) {
		return $translated_text;
	}

	if ( 'openpos' === $domain && 'OP Cost price' === $source_text ) {
		return 'Prezzo di costo POS';
	}

	$wholesale_domains = array(
		'woocommerce-wholesale-prices',
		'woocommerce-wholesale-prices-premium',
		// The Premium plugin uses this typo in two sale-price fields.
		'woocommerce-wholesale-prices-premiums',
	);

	if ( ! in_array( $domain, $wholesale_domains, true ) ) {
		return $translated_text;
	}

	static $translations = array(
		'Wholesale' => 'Professionisti',
		'Wholesale Price' => 'Prezzo professionisti',
		'Wholesale Prices' => 'Prezzi professionisti',
		'Wholesale Sale Price' => 'Prezzo promozionale professionisti',
		'%1$s Price (%2$s)' => 'Prezzo %1$s (%2$s)',
		'Wholesale Price (%1$s)' => 'Prezzo professionisti (%1$s)',
		'Wholesale Price%1$s' => 'Prezzo professionisti%1$s',
		'Wholesale Sale Price (%1$s)' => 'Prezzo promozionale professionisti (%1$s)',
		'Set a wholesale price for this product.' => 'Imposta un prezzo riservato ai professionisti per questo prodotto.',
		'Add additional wholesale price levels.' => 'Aggiungi altri livelli di prezzo per professionisti.',
		'Add additional wholesale price levels' => 'Aggiungi altri livelli di prezzo per professionisti',
		'Wholesale prices are set per role and currency.%1$s%1$s%2$sNote:%3$s Wholesale price must be set for the base currency to enable wholesale pricing for that role. The base currency will be used for conversion to other currencies that have no wholesale price explicitly set (Auto).' => 'I prezzi professionisti sono definiti per ruolo e valuta.%1$s%1$s%2$sNota:%3$s per attivare i prezzi per un ruolo, imposta il prezzo nella valuta di base. La valuta di base verrà usata per convertire automaticamente i prezzi nelle altre valute non compilate.',
		'Only applies to users with the role of %1$s for %2$s currency' => 'Si applica soltanto agli utenti con ruolo %1$s per la valuta %2$s',
		'Only applies to users with the role of "%1$s"' => 'Si applica soltanto agli utenti con ruolo “%1$s”',
		'Auto' => 'Automatico',
		'Wholesale price for %1$s customers' => 'Prezzo riservato ai clienti %1$s',
		'Wholesale price for %1$s customers %2$s Note: Prices are shown up to 6 decimal places but may be calculated and stored at higher precision.' => 'Prezzo riservato ai clienti %1$s%2$sNota: i prezzi sono mostrati con un massimo di 6 decimali, ma possono essere calcolati e salvati con maggiore precisione.',
		'Discount Type' => 'Tipo di sconto',
		'Fixed' => 'Prezzo fisso',
		'Percentage' => 'Percentuale',
		'Choose Price Type%1$sFixed (default)%1$sPercentage' => 'Scegli il tipo di prezzo%1$sPrezzo fisso (predefinito)%1$sPercentuale',
		'Choose Price Type. Fixed (default)/Percentage' => 'Scegli il tipo di prezzo: fisso (predefinito) o percentuale.',
		'Discount (%)' => 'Sconto (%)',
		'The percentage amount discounted from the regular price' => 'Percentuale di sconto applicata al prezzo normale',
		'Wholesale Signup Fee (%1$s)' => 'Quota di iscrizione professionisti (%1$s)',
		'Wholesale Signup Fee for %1$s customers' => 'Quota di iscrizione per i clienti %1$s',
		'Signup Fee Discount (%)' => 'Sconto sulla quota di iscrizione (%)',
		'The percentage amount discounted from the Sign-up fee' => 'Percentuale di sconto applicata alla quota di iscrizione',
		'Sale Discount (%)' => 'Sconto promozionale (%)',
		'The percentage amount discounted from the wholesale price' => 'Percentuale di sconto applicata al prezzo professionisti',
		'Schedule' => 'Programma',
		'Cancel schedule' => 'Annulla programmazione',
		'Sale price dates' => 'Date del prezzo promozionale',
		'Sale start date' => 'Data di inizio promozione',
		'Sale end date' => 'Data di fine promozione',
		'Cancel' => 'Annulla',
		'The sale will start at 00:00:00 of "From" date and end at 23:59:59 of "To" date.' => 'La promozione inizierà alle 00:00:00 della data “Da” e terminerà alle 23:59:59 della data “A”.',
		'Set wholesale prices (%1$s)' => 'Imposta i prezzi professionisti (%1$s)',
		'Set wholesale sale prices (%1$s)' => 'Imposta i prezzi promozionali professionisti (%1$s)',
		'Set minimum order quantity (%1$s)' => 'Imposta la quantità minima d’ordine (%1$s)',
		'Set order quantity step (%1$s)' => 'Imposta l’incremento della quantità (%1$s)',
		'Wholesale Minimum Order Quantity' => 'Quantità minima d’ordine per professionisti',
		'Parent Product Wholesale Minimum Order Quantity' => 'Quantità minima d’ordine del prodotto principale',
		'%1$s Minimum Order Quantity' => 'Quantità minima d’ordine – %1$s',
		"Minimum number of items to be purchased in order to avail this product's wholesale price.<br/>Only applies to wholesale users.<br/><br/>Setting a step value below for the corresponding wholesale role will prevent the specific wholesale customer from adding to cart quantity of this product lower than the set minimum." => 'Numero minimo di articoli da acquistare per applicare il prezzo professionisti.<br/>Si applica soltanto agli utenti professionisti.<br/><br/>Impostando sotto un incremento per il ruolo corrispondente, il cliente non potrà aggiungere al carrello una quantità inferiore al minimo definito.',
		'Wholesale Order Quantity Step' => 'Incremento quantità d’ordine per professionisti',
		'Parent Product Wholesale Order Quantity Step' => 'Incremento quantità del prodotto principale',
		'%1$s Order Quantity Step' => 'Incremento quantità – %1$s',
		'Order quantity step wholesale users are restricted to when purchasing this product.<br/>Only applies to wholesale users.<br/><br/>Minimum order quantity above for corresponding wholesale role must be set for this feature to take effect.' => 'Incremento di quantità obbligatorio per gli utenti professionisti che acquistano questo prodotto.<br/>Si applica soltanto agli utenti professionisti.<br/><br/>Per attivare questa funzione devi impostare sopra la quantità minima d’ordine per il ruolo corrispondente.',
		'Order quantity step wholesale users are restricted to when purchasing this product for the "%1$s" role.' => 'Incremento di quantità obbligatorio per gli utenti con ruolo “%1$s” che acquistano questo prodotto.',
		'Product Quantity Based Wholesale Pricing' => 'Prezzi professionisti in base alla quantità',
		'Specify wholesale price for this current product depending on the quantity being purchased. Ending Qty can be left blank to apply that price for all quantities above the Starting Qty. Only applies to the wholesale roles that you specify.' => 'Definisci il prezzo professionisti del prodotto in base alla quantità acquistata. Lascia vuota la quantità finale per applicare il prezzo a tutte le quantità superiori a quella iniziale. Si applica soltanto ai ruoli selezionati.',
		'Specify further wholesale discounts based on the total quantity of all variations of this product in the cart. If you wish to use quantity based pricing on individual variations, uncheck this option and use the controls on the variations instead. Ending Qty can be left blank to apply that price for all quantities above the Starting Qty. Only applies to the wholesale roles that you specify.' => 'Definisci ulteriori sconti professionisti in base alla quantità totale di tutte le varianti presenti nel carrello. Per applicare prezzi per quantità alle singole varianti, disattiva questa opzione e usa i controlli delle varianti. Lascia vuota la quantità finale per applicare il prezzo a tutte le quantità superiori a quella iniziale. Si applica soltanto ai ruoli selezionati.',
		'Note: Wholesale Price is calculated via percentage discount, it is based on the wholesale price of variation if set else it will use the regular price.' => 'Nota: il prezzo professionisti viene calcolato con uno sconto percentuale sul prezzo professionisti della variante, se presente; in caso contrario viene usato il prezzo normale.',
		'Note: If you have not specify mapping for other currencies for a given wholesale role, it will derive its wholesale price automatically by converting the base currency wholesale price to that currency' => 'Nota: se non definisci un valore per le altre valute di un ruolo, il prezzo verrà calcolato automaticamente convertendo quello della valuta di base.',
		'Enable further wholesale pricing discounts based on quantity purchased?' => 'Attivare ulteriori sconti professionisti in base alla quantità acquistata?',
		'% value off the wholesale price. This will be the discount value used for quantities within the given range. Please input value without comma separator.' => 'Percentuale di sconto sul prezzo professionisti applicata alle quantità nell’intervallo indicato. Inserisci il valore senza separatore delle migliaia.',
		'$ or the new % value off the wholesale price. This will be the discount value used for quantities within the given range. Please input value without comma separator.' => 'Prezzo fisso oppure percentuale di sconto sul prezzo professionisti applicata alle quantità nell’intervallo indicato. Inserisci il valore senza separatore delle migliaia.',
		'Discount % off the wholesale price' => 'Sconto percentuale sul prezzo professionisti',
		'Fixed Price' => 'Prezzo fisso',
		'Wholesale Role' => 'Ruolo professionista',
		'Select wholesale role to which this rule applies.' => 'Seleziona il ruolo professionista a cui applicare la regola.',
		'Starting Qty' => 'Quantità iniziale',
		'Minimum order quantity required for this rule. Must be a number.' => 'Quantità minima richiesta dalla regola. Inserisci un numero.',
		'Ending Qty' => 'Quantità finale',
		'Maximum order quantity required for this rule. Must be a number. Leave this blank for no maximum quantity.' => 'Quantità massima prevista dalla regola. Inserisci un numero oppure lascia vuoto per non impostare un limite.',
		'Price Type' => 'Tipo di prezzo',
		'Select pricing type' => 'Seleziona il tipo di prezzo',
		'Only percentage discount is allowed for variable level quantity discount.' => 'Per gli sconti quantità delle varianti è consentito soltanto lo sconto percentuale.',
		'(Base Currency)' => '(Valuta di base)',
		'Currency' => 'Valuta',
		'Select Currency' => 'Seleziona la valuta',
		'Save Quantity Discount Rule' => 'Salva regola quantità',
		'Add Quantity Discount Rule' => 'Aggiungi regola quantità',
		'No Quantity Discount Rules Found' => 'Nessuna regola quantità trovata',
		'%1$s role does not exist anymore' => 'Il ruolo %1$s non esiste più',
		'Quantity discount rule data passed is in invalid format.' => 'I dati della regola quantità non sono in un formato valido.',
		'Quantity discount rule data passed is invalid. The following fields are required ( Wholesale Role / Starting Qty / Price Type / Wholesale Price ).' => 'I dati della regola quantità non sono validi. Compila i campi Ruolo professionista, Quantità iniziale, Tipo di prezzo e Prezzo professionisti.',
		'Quantity discount rule data passed is invalid. The following fields must be a number ( Starting Qty / Ending Qty / Wholesale Price ).' => 'I dati della regola quantità non sono validi. Quantità iniziale, Quantità finale e Prezzo professionisti devono essere numeri.',
		'Ending Qty must not be less than Starting Qty' => 'La quantità finale non può essere inferiore a quella iniziale',
		'Duplicate quantity discount rule' => 'Questa regola quantità esiste già',
		'Overlap quantity discount rule' => 'Questa regola quantità si sovrappone a una regola esistente',
		'Quantity discount rule entry you want to edit does not exist' => 'La regola quantità che vuoi modificare non esiste',
		'Quantity discount rule entry you want to delete does not exist' => 'La regola quantità che vuoi eliminare non esiste',
	);

	return $translations[ $source_text ] ?? $translated_text;
}
add_filter( 'gettext', 'oasi_translate_product_pricing_admin_text', 10, 3 );
