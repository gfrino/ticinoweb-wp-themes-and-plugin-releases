<?php
/**
 * WooCommerce single product page helpers, parser and rendering components.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Retrieve the most specific primary category for a given product.
 *
 * @param WC_Product|int $product Product object or ID.
 * @return WP_Term|null Primary category term or null.
 */
function oasi_get_product_primary_category( mixed $product ): ?WP_Term {
	$product_id = $product instanceof WC_Product ? $product->get_id() : (int) $product;
	if ( $product_id <= 0 ) {
		return null;
	}

	// 1. Check Yoast SEO primary term if configured
	$yoast_primary_id = (int) get_post_meta( $product_id, '_yoast_wpseo_primary_product_cat', true );
	if ( $yoast_primary_id > 0 ) {
		$term = get_term( $yoast_primary_id, 'product_cat' );
		if ( $term instanceof WP_Term && ! is_wp_error( $term ) ) {
			return $term;
		}
	}

	// 2. Query all assigned product categories
	$terms = wp_get_post_terms( $product_id, 'product_cat' );
	if ( is_wp_error( $terms ) || empty( $terms ) ) {
		return null;
	}

	// Exclude generic 'senza-categoria' or 'uncategorized'
	$valid_terms = array_filter(
		$terms,
		static function ( $t ) {
			return $t instanceof WP_Term && ! in_array( $t->slug, array( 'senza-categoria', 'uncategorized' ), true );
		}
	);

	if ( empty( $valid_terms ) ) {
		return $terms[0] instanceof WP_Term ? $terms[0] : null;
	}

	// Prioritize child categories (parent > 0) or terms with an assigned thumbnail
	$best_term = null;
	foreach ( $valid_terms as $t ) {
		$has_thumb = (int) get_term_meta( $t->term_id, 'thumbnail_id', true ) > 0;
		if ( $t->parent > 0 && $has_thumb ) {
			return $t; // Deep child with photo is ideal
		}
		if ( $t->parent > 0 && null === $best_term ) {
			$best_term = $t;
		} elseif ( $has_thumb && null === $best_term ) {
			$best_term = $t;
		}
	}

	return $best_term ?? reset( $valid_terms );
}

/**
 * Render the compact editorial category banner above the single product showcase.
 *
 * @param WC_Product $product Current product.
 */
function oasi_render_product_category_banner( WC_Product $product ): void {
	$category = oasi_get_product_primary_category( $product );
	if ( ! $category instanceof WP_Term ) {
		return;
	}

	$category_link = get_term_link( $category, 'product_cat' );
	if ( is_wp_error( $category_link ) ) {
		$category_link = home_url( '/shop-online-oasi-delle-spezie/' );
	}

	// Term image or fallback
	$thumb_url = '';
	if ( function_exists( 'oasi_get_category_term_thumbnail_url' ) ) {
		$thumb_url = oasi_get_category_term_thumbnail_url( $category->term_id );
	}
	if ( empty( $thumb_url ) ) {
		$thumb_id = (int) get_term_meta( $category->term_id, 'thumbnail_id', true );
		if ( $thumb_id > 0 ) {
			$thumb_url = (string) wp_get_attachment_image_url( $thumb_id, 'medium' );
		}
	}
	if ( empty( $thumb_url ) ) {
		$thumb_url = oasi_upload_url( '2022/02/spices-2.jpg' );
	}

	$count_label = '';
	if ( $category->count > 0 ) {
		$count_label = sprintf(
			/* translators: %d: count of products */
			_n( '%d prodotto disponibile', '%d prodotti disponibili', $category->count, 'oasidellespezie-child-theme' ),
			$category->count
		);
	}
	?>
	<div class="oasi-product-category-banner">
		<div class="oasi-product-category-banner__inner">
			<a href="<?php echo esc_url( $category_link ); ?>" class="oasi-product-category-banner__media" aria-hidden="true" tabindex="-1">
				<img src="<?php echo esc_url( $thumb_url ); ?>" alt="<?php echo esc_attr( $category->name ); ?>" loading="lazy" width="56" height="56" />
			</a>
			<div class="oasi-product-category-banner__content">
				<div class="oasi-product-category-banner__badge">
					<svg class="oasi-product-category-banner__badge-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
						<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
					</svg>
					<span><?php esc_html_e( 'Collezione Oasi', 'oasidellespezie-child-theme' ); ?></span>
				</div>
				<a href="<?php echo esc_url( $category_link ); ?>" class="oasi-product-category-banner__title">
					<?php echo esc_html( $category->name ); ?>
				</a>
				<?php if ( '' !== $count_label ) : ?>
					<span class="oasi-product-category-banner__count"><?php echo esc_html( $count_label ); ?></span>
				<?php endif; ?>
			</div>
			<div class="oasi-product-category-banner__action">
				<a href="<?php echo esc_url( $category_link ); ?>" class="oasi-product-category-banner__btn">
					<span><?php esc_html_e( 'Vedi tutta la selezione', 'oasidellespezie-child-theme' ); ?></span>
					<svg class="oasi-product-category-banner__btn-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
						<line x1="5" y1="12" x2="19" y2="12"></line>
						<polyline points="12 5 19 12 12 19"></polyline>
					</svg>
				</a>
			</div>
		</div>
	</div>
	<?php
}

/**
 * Parse product description for structured specification fields.
 *
 * Extracts items like:
 * - Ingredienti
 * - Provenienza / Origine
 * - Qualità
 * - Confezionamento / Confezioni
 * - Conservazione
 * - Allergeni
 * - Valori nutrizionali
 *
 * Returns clean structured data and the remainder narrative description.
 *
 * @param WC_Product $product Current product.
 * @return array{
 *     specs: array<string, array{label:string, value:string, icon:string}>,
 *     narrative: string,
 *     disclaimer: string
 * }
 */
function oasi_parse_product_specification_fields( WC_Product $product ): array {
	$raw_content = (string) $product->get_description();
	if ( empty( trim( $raw_content ) ) ) {
		$raw_content = (string) $product->get_short_description();
	}

	// Normalize with wpautop so all lines and paragraphs are consistently wrapped
	if ( function_exists( 'wpautop' ) ) {
		$raw_content = wpautop( $raw_content );
	}

	$specs        = array();
	$field_values = array();
	$disclaimer   = '';

	// Match complete normalized labels. Substring matching is deliberately
	// avoided: "Provenienza degli ingredienti" must never become "Ingredienti".
	$field_aliases = array(
		'ingredienti'                  => 'ingredienti',
		'provenienza'                  => 'provenienza',
		'provenienza degli ingredienti'=> 'provenienza',
		'provenienza ingredienti'      => 'provenienza',
		'origine'                      => 'origine',
		'origine e provenienza'        => 'provenienza',
		'qualita'                      => 'qualita',
		'produzione'                   => 'produzione',
		'lavorazione'                  => 'produzione',
		'elaborazione'                 => 'produzione',
		'prodotto da'                  => 'produzione',
		'produttore'                   => 'produzione',
		'prodotto e imbottigliato da'  => 'produzione',
		'prodotto in svizzera da'      => 'produzione',
		'confezionamento'              => 'confezionamento',
		'confezione'                   => 'confezionamento',
		'confezioni'                   => 'confezionamento',
		'conservazione'                => 'conservazione',
		'allergeni'                    => 'allergeni',
		'consigli d\'uso'              => 'utilizzo',
		'utilizzo'                     => 'utilizzo',
	);

	// Extract standard medical/info disclaimer if present
	if ( preg_match( '/<p>\s*(?:<[^>]+>)*\s*(Le informazioni riportate in questo sito non hanno mai valore medico.*?)(?:<\/[^>]+>)*\s*<\/p>/is', $raw_content, $disc_match ) ) {
		$disclaimer  = trim( strip_tags( $disc_match[1] ) );
		$raw_content = str_replace( $disc_match[0], '', $raw_content );
	}

	// Regex to find paragraphs starting with strong/bold key
	$pattern = '/<p>\s*(?:<strong>|<b>)\s*(.*?)\s*(?:<\/strong>|<\/b>)\s*:?\s*(.*?)\s*<\/p>/is';

	if ( preg_match_all( $pattern, $raw_content, $matches, PREG_SET_ORDER ) ) {
		foreach ( $matches as $match ) {
			$strong_text    = trim( strip_tags( $match[1] ) );
			$raw_key        = trim( rtrim( $strong_text, ':' ) );
			$value          = trim( ltrim( trim( $match[2] ), ':' ) );

			// Some legacy descriptions keep both label and value inside <strong>.
			if ( '' === $value && preg_match( '/^(.+?):\s*(.+)$/u', $strong_text, $inline_parts ) ) {
				$raw_key = trim( $inline_parts[1] );
				$value   = trim( $inline_parts[2] );
			}

			$normalized_key = oasi_normalize_product_specification_key( $raw_key );

			if ( isset( $field_aliases[ $normalized_key ] ) ) {
				$canonical_key = $field_aliases[ $normalized_key ];
				$clean_val     = wp_kses_post( $value );

				// Always strip a recognized specification line from the narrative.
				$raw_content = str_replace( $match[0], '', $raw_content );

				if ( oasi_product_specification_value_is_meaningful( $clean_val ) && ! isset( $field_values[ $canonical_key ] ) ) {
					$field_values[ $canonical_key ] = $clean_val;
				}
			}
		}
	}

	// Also check WooCommerce custom product attributes
	$attributes = $product->get_attributes();
	if ( ! empty( $attributes ) ) {
		foreach ( $attributes as $attr_key => $attr_obj ) {
			$attribute_label = str_replace( array( 'pa_', '-' ), array( '', ' ' ), (string) $attr_key );
			$normalized_key  = oasi_normalize_product_specification_key( $attribute_label );

			if ( ! isset( $field_aliases[ $normalized_key ] ) ) {
				continue;
			}

			$canonical_key = $field_aliases[ $normalized_key ];
			if ( isset( $field_values[ $canonical_key ] ) ) {
				continue;
			}

			$val_text = '';
			if ( $attr_obj->is_taxonomy() ) {
				$terms    = wc_get_product_terms( $product->get_id(), $attr_obj->get_name(), array( 'fields' => 'names' ) );
				$val_text = implode( ', ', $terms );
			} else {
				$val_text = implode( ', ', $attr_obj->get_options() );
			}

			if ( oasi_product_specification_value_is_meaningful( $val_text ) ) {
				$field_values[ $canonical_key ] = esc_html( $val_text );
			}
		}
	}

	$specs = oasi_build_product_specification_cards( $field_values );

	// Remove empty paragraph tags and whitespace
	$clean_narrative = trim( preg_replace( '/<p>\s*(?:&nbsp;)*\s*<\/p>/i', '', $raw_content ) );
	if ( '' === trim( strip_tags( $clean_narrative ) ) ) {
		$clean_narrative = '';
	}

	return array(
		'specs'      => $specs,
		'narrative'  => $clean_narrative,
		'disclaimer' => $disclaimer,
	);
}

/**
 * Normalize an editorial specification label for exact alias matching.
 */
function oasi_normalize_product_specification_key( string $key ): string {
	$key = html_entity_decode( strip_tags( $key ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
	$key = mb_strtolower( trim( $key ), 'UTF-8' );
	$key = str_replace( array( 'à', 'á', 'â', 'ä' ), 'a', $key );
	$key = preg_replace( '/[^\p{L}\p{N}\']+/u', ' ', $key );

	return trim( (string) $key );
}

/**
 * Determine whether a specification contains useful customer information.
 */
function oasi_product_specification_value_is_meaningful( string $value ): bool {
	$plain_value = mb_strtolower( trim( strip_tags( $value ) ), 'UTF-8' );

	return '' !== $plain_value && 'no' !== $plain_value;
}

/**
 * Build one explicit row inside a combined specification card.
 */
function oasi_product_specification_detail( string $label, string $value ): string {
	return sprintf(
		'<span class="oasi-spec-card__detail"><strong>%1$s:</strong> %2$s</span>',
		esc_html( $label ),
		$value
	);
}

/**
 * Build customer-facing cards from canonical backend values.
 *
 * @param array<string,string> $values Canonical values parsed from content/attributes.
 * @return array<string,array{label:string,value:string,icon:string}>
 */
function oasi_build_product_specification_cards( array $values ): array {
	$cards = array();

	if ( isset( $values['ingredienti'] ) ) {
		$cards['ingredienti'] = array(
			'label' => __( 'Ingredienti', 'oasidellespezie-child-theme' ),
			'value' => $values['ingredienti'],
			'icon'  => 'leaf',
		);
	}

	$origin_details = '';
	if ( isset( $values['origine'] ) ) {
		$origin_details .= oasi_product_specification_detail( __( 'Origine', 'oasidellespezie-child-theme' ), $values['origine'] );
	}
	if ( isset( $values['provenienza'] ) ) {
		$origin_details .= oasi_product_specification_detail( __( 'Provenienza degli ingredienti', 'oasidellespezie-child-theme' ), $values['provenienza'] );
	}
	if ( '' !== $origin_details ) {
		$cards['provenienza'] = array(
			'label' => __( 'Origine & Provenienza', 'oasidellespezie-child-theme' ),
			'value' => $origin_details,
			'icon'  => 'globe',
		);
	}

	$quality_details = '';
	if ( isset( $values['qualita'] ) ) {
		$quality_details .= oasi_product_specification_detail( __( 'Qualità', 'oasidellespezie-child-theme' ), $values['qualita'] );
	}
	if ( isset( $values['produzione'] ) ) {
		$quality_details .= oasi_product_specification_detail( __( 'Produzione', 'oasidellespezie-child-theme' ), $values['produzione'] );
	}
	if ( '' !== $quality_details ) {
		$cards['qualità'] = array(
			'label' => __( 'Qualità & Lavorazione', 'oasidellespezie-child-theme' ),
			'value' => $quality_details,
			'icon'  => 'shield-check',
		);
	}

	$single_cards = array(
		'confezionamento' => array( __( 'Confezionamento', 'oasidellespezie-child-theme' ), 'package' ),
		'conservazione'   => array( __( 'Conservazione', 'oasidellespezie-child-theme' ), 'clock' ),
		'allergeni'       => array( __( 'Allergeni', 'oasidellespezie-child-theme' ), 'alert-triangle' ),
		'utilizzo'        => array( __( 'Consigli d\'Uso', 'oasidellespezie-child-theme' ), 'sparkles' ),
	);

	foreach ( $single_cards as $key => $definition ) {
		if ( isset( $values[ $key ] ) ) {
			$cards[ $key ] = array(
				'label' => $definition[0],
				'value' => $values[ $key ],
				'icon'  => $definition[1],
			);
		}
	}

	return $cards;
}

/**
 * Render trust, reassurance and security features directly in the purchase block.
 */
function oasi_render_product_trust_box(): void {
	?>
	<div class="oasi-product-trust">
		<div class="oasi-product-trust__grid">
			<div class="oasi-product-trust__item">
				<span class="oasi-product-trust__icon">
					<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
						<rect x="1" y="3" width="15" height="13"></rect>
						<polygon points="16 8 20 8 23 11 23 16 16 16 8"></polygon>
						<circle cx="5.5" cy="18.5" r="2.5"></circle>
						<circle cx="18.5" cy="18.5" r="2.5"></circle>
					</svg>
				</span>
				<div class="oasi-product-trust__text">
					<strong><?php esc_html_e( 'Spedizione Svizzera', 'oasidellespezie-child-theme' ); ?></strong>
					<span><?php $oasi_free_from = ( function_exists( 'oasi_free_shipping_threshold' ) ? oasi_free_shipping_threshold() : '' ); echo esc_html( '' !== $oasi_free_from ? sprintf( /* translators: %s: amount in CHF. */ __( 'Gratuita da %s CHF • 5–10 giorni lavorativi', 'oasidellespezie-child-theme' ), $oasi_free_from ) : __( '5–10 giorni lavorativi', 'oasidellespezie-child-theme' ) ); ?></span>
				</div>
			</div>

			<div class="oasi-product-trust__item">
				<span class="oasi-product-trust__icon">
					<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
						<rect x="2" y="4" width="20" height="16" rx="2"></rect>
						<line x1="2" y1="10" x2="22" y2="10"></line>
					</svg>
				</span>
				<div class="oasi-product-trust__text">
					<strong><?php esc_html_e( 'Pagamenti 100% Sicuri', 'oasidellespezie-child-theme' ); ?></strong>
					<span><?php esc_html_e( 'TWINT, PostFinance, Carte, Bonifico', 'oasidellespezie-child-theme' ); ?></span>
				</div>
			</div>

			<div class="oasi-product-trust__item">
				<span class="oasi-product-trust__icon">
					<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
						<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
					</svg>
				</span>
				<div class="oasi-product-trust__text">
					<strong><?php esc_html_e( 'Qualità Oasi Garantita', 'oasidellespezie-child-theme' ); ?></strong>
					<span><?php esc_html_e( '100% Naturale • Macinato fresco', 'oasidellespezie-child-theme' ); ?></span>
				</div>
			</div>

			<div class="oasi-product-trust__item">
				<span class="oasi-product-trust__icon">
					<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
						<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
					</svg>
				</span>
				<div class="oasi-product-trust__text">
					<strong><?php esc_html_e( 'Assistenza Laboratorio', 'oasidellespezie-child-theme' ); ?></strong>
					<span><a href="tel:+41918590532" class="oasi-product-trust__link">+41 91 859 05 32</a> • Gudo (TI)</span>
				</div>
			</div>
		</div>
	</div>
	<?php
}

/**
 * Render the balanced product media showcase with gallery support.
 *
 * @param WC_Product $product Current product.
 */
function oasi_render_product_media( WC_Product $product ): void {
	$image_id     = $product->get_image_id();
	$gallery_ids  = $product->get_gallery_image_ids();
	$has_gallery  = ! empty( $gallery_ids );

	// Build array of all images
	$images = array();
	if ( $image_id > 0 ) {
		$images[] = $image_id;
	}
	if ( $has_gallery ) {
		foreach ( $gallery_ids as $gid ) {
			if ( $gid !== $image_id && ! in_array( $gid, $images, true ) ) {
				$images[] = $gid;
			}
		}
	}

	// Fallback if zero images
	$has_images = ! empty( $images );
	?>
	<div class="oasi-product-media" data-oasi-gallery>
		<div class="oasi-product-media__main-wrap">
			<?php if ( $product->is_on_sale() ) : ?>
				<span class="oasi-product-media__badge oasi-product-media__badge--sale">
					<?php esc_html_e( 'In Offerta', 'oasidellespezie-child-theme' ); ?>
				</span>
			<?php elseif ( ! $product->is_in_stock() ) : ?>
				<span class="oasi-product-media__badge oasi-product-media__badge--out">
					<?php esc_html_e( 'Esaurito', 'oasidellespezie-child-theme' ); ?>
				</span>
			<?php else : ?>
				<span class="oasi-product-media__badge oasi-product-media__badge--artisan">
					<?php esc_html_e( 'Artigianale Svizzero', 'oasidellespezie-child-theme' ); ?>
				</span>
			<?php endif; ?>

			<div class="oasi-product-media__stage">
				<?php if ( $has_images ) : ?>
					<?php
					$main_id = $images[0];
					$img_url = wp_get_attachment_image_url( $main_id, 'large' );
					$img_src = wp_get_attachment_image_src( $main_id, 'large' );
					$srcset  = wp_get_attachment_image_srcset( $main_id, 'large' );
					$alt     = get_post_meta( $main_id, '_wp_attachment_image_alt', true ) ?: $product->get_name();
					?>
					<img
						id="oasi-product-main-img"
						class="oasi-product-media__main-img"
						src="<?php echo esc_url( $img_url ); ?>"
						alt="<?php echo esc_attr( $alt ); ?>"
						<?php if ( $srcset ) : ?>srcset="<?php echo esc_attr( $srcset ); ?>" sizes="(min-width: 900px) 450px, 100vw"<?php endif; ?>
						width="<?php echo esc_attr( $img_src[1] ?? 600 ); ?>"
						height="<?php echo esc_attr( $img_src[2] ?? 600 ); ?>"
						loading="eager"
						fetchpriority="high"
						decoding="async"
					/>
				<?php else : ?>
					<div class="oasi-product-media__placeholder">
						<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
							<rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
							<circle cx="8.5" cy="8.5" r="1.5"></circle>
							<polyline points="21 15 16 10 5 21"></polyline>
						</svg>
						<span><?php esc_html_e( 'Immagine in arrivo dal laboratorio', 'oasidellespezie-child-theme' ); ?></span>
					</div>
				<?php endif; ?>
			</div>
		</div>

		<?php if ( count( $images ) > 1 ) : ?>
			<div class="oasi-product-media__thumbs" role="tablist" aria-label="<?php esc_attr_e( 'Galleria immagini prodotto', 'oasidellespezie-child-theme' ); ?>">
				<?php foreach ( $images as $idx => $img_id ) : ?>
					<?php
					$thumb_url   = wp_get_attachment_image_url( $img_id, 'thumbnail' );
					$large_url   = wp_get_attachment_image_url( $img_id, 'large' );
					$large_src   = wp_get_attachment_image_src( $img_id, 'large' );
					$large_set   = wp_get_attachment_image_srcset( $img_id, 'large' );
					$thumb_alt   = get_post_meta( $img_id, '_wp_attachment_image_alt', true ) ?: sprintf( '%s - foto %d', $product->get_name(), $idx + 1 );
					$is_active   = 0 === $idx;
					?>
					<button
						type="button"
						class="oasi-product-media__thumb-btn <?php echo $is_active ? 'is-active' : ''; ?>"
						role="tab"
						aria-selected="<?php echo $is_active ? 'true' : 'false'; ?>"
						data-large-url="<?php echo esc_url( $large_url ); ?>"
						data-large-srcset="<?php echo esc_attr( $large_set ?: '' ); ?>"
						data-large-alt="<?php echo esc_attr( $thumb_alt ); ?>"
						aria-label="<?php echo esc_attr( sprintf( __( 'Visualizza immagine %d', 'oasidellespezie-child-theme' ), $idx + 1 ) ); ?>"
					>
						<img src="<?php echo esc_url( $thumb_url ); ?>" alt="<?php echo esc_attr( $thumb_alt ); ?>" loading="lazy" width="64" height="64" />
					</button>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</div>
	<?php
}

/**
 * Render icon SVG for product specs.
 *
 * @param string $icon Icon key.
 */
function oasi_render_spec_icon_svg( string $icon ): void {
	switch ( $icon ) {
		case 'leaf':
			echo '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"/><path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"/></svg>';
			break;
		case 'globe':
			echo '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>';
			break;
		case 'shield-check':
			echo '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path><polyline points="9 12 11 14 15 10"></polyline></svg>';
			break;
		case 'package':
			echo '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="16.5" y1="9.4" x2="7.5" y2="4.21"></line><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg>';
			break;
		case 'clock':
			echo '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>';
			break;
		case 'alert-triangle':
			echo '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>';
			break;
		case 'sparkles':
		default:
			echo '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/></svg>';
			break;
	}
}

/**
 * Render related products using Oasi catalog card layout.
 *
 * @param WC_Product $product Current product.
 * @param int        $limit   Number of products to show.
 */
function oasi_render_related_products_section( WC_Product $product, int $limit = 5 ): void {
	$category = oasi_get_product_primary_category( $product );
	$cat_slug = $category ? $category->slug : '';

	// Query related products from same category, excluding current product
	$args = array(
		'post_type'           => 'product',
		'posts_per_page'      => $limit,
		'post__not_in'        => array( $product->get_id() ),
		'post_status'         => 'publish',
		'ignore_sticky_posts' => 1,
		'orderby'             => 'rand',
		'no_found_rows'       => true,
	);

	if ( '' !== $cat_slug ) {
		$args['tax_query'] = array(
			array(
				'taxonomy' => 'product_cat',
				'field'    => 'slug',
				'terms'    => $cat_slug,
			),
		);
	}

	$query = new WP_Query( $args );

	if ( ! $query->have_posts() ) {
		// Fallback: query any other products up to the same visual limit.
		unset( $args['tax_query'] );
		$query = new WP_Query( $args );
	}

	if ( ! $query->have_posts() ) {
		return;
	}
	?>
	<section class="oasi-product-related">
		<header class="oasi-product-related__header">
			<div class="oasi-product-related__eyebrow">
				<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
					<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
				</svg>
				<span><?php esc_html_e( 'Scoperte del Laboratorio', 'oasidellespezie-child-theme' ); ?></span>
			</div>
			<h2 class="oasi-product-related__title">
				<?php esc_html_e( 'Dalla Stessa Selezione di Eccellenza', 'oasidellespezie-child-theme' ); ?>
			</h2>
			<p class="oasi-product-related__subtitle">
				<?php esc_html_e( 'Combinazioni aromatiche e spezie pure affini consigliate dai nostri artigiani.', 'oasidellespezie-child-theme' ); ?>
			</p>
		</header>

		<div class="oasi-product-related__grid oasi-products-grid oasi-products-grid--5cols">
			<?php
			while ( $query->have_posts() ) {
				$query->the_post();
				$related_product = wc_get_product( get_the_ID() );
				if ( $related_product instanceof WC_Product && $related_product->is_visible() ) {
					oasi_render_product_card( $related_product );
				}
			}
			wp_reset_postdata();
			?>
		</div>
	</section>
	<?php
}
