<?php
/**
 * Dynamic helpers for single Oasi articles.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Resolve the existing Novità page without storing an environment-specific URL.
 */
function oasi_single_post_get_archive_url(): string {
	$page = get_page_by_path( 'scoprite-le-nostre-novita', OBJECT, 'page' );

	if ( $page instanceof WP_Post && 'publish' === $page->post_status ) {
		return get_permalink( $page );
	}

	return home_url( '/scoprite-le-nostre-novita/' );
}

/**
 * Query up to three recent articles sharing at least one real category.
 *
 * @param int $post_id Current article ID.
 * @param int $limit   Maximum number of related articles.
 */
function oasi_single_post_get_related_posts( int $post_id, int $limit = 3 ): WP_Query {
	$limit        = max( 2, min( 3, $limit ) );
	$category_ids = wp_get_post_categories( $post_id, array( 'fields' => 'ids' ) );
	$args         = array(
		'post_type'           => 'post',
		'post_status'         => 'publish',
		'posts_per_page'      => $limit,
		'post__not_in'        => array( $post_id ),
		'ignore_sticky_posts' => true,
		'orderby'             => 'date',
		'order'               => 'DESC',
		'no_found_rows'       => true,
	);

	if ( ! is_wp_error( $category_ids ) && ! empty( $category_ids ) ) {
		$args['category__in'] = array_map( 'intval', $category_ids );
	} else {
		// No editorial taxonomy means no trustworthy "related" relationship.
		$args['post__in'] = array( 0 );
	}

	return new WP_Query( $args );
}

/**
 * Collect product IDs from supported WooCommerce blocks, including nested blocks.
 *
 * @param array $block Parsed WordPress block.
 * @return int[]
 */
function oasi_single_post_get_block_product_ids( array $block ): array {
	$product_ids = array();
	$block_name  = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
	$attrs       = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();

	if ( in_array( $block_name, array( 'woocommerce/handpicked-products', 'woocommerce/product-collection' ), true ) ) {
		$raw_ids = $attrs['products'] ?? $attrs['productIds'] ?? array();
		if ( is_array( $raw_ids ) ) {
			$product_ids = array_merge( $product_ids, array_map( 'absint', $raw_ids ) );
		}
	}

	if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
		foreach ( $block['innerBlocks'] as $inner_block ) {
			if ( is_array( $inner_block ) ) {
				$product_ids = array_merge( $product_ids, oasi_single_post_get_block_product_ids( $inner_block ) );
			}
		}

	}

	return array_values( array_unique( array_filter( $product_ids ) ) );
}

/**
 * Render a verified WooCommerce product as an editorial callout.
 *
 * The filter changes presentation only; stored post content remains untouched and
 * the article is still rendered through the_content().
 *
 * @param string $block_content Original rendered block.
 * @param array  $block         Parsed block data.
 */
function oasi_single_post_render_product_block( string $block_content, array $block ): string {
	if ( ! function_exists( 'is_singular' ) || ! is_singular( 'post' ) || ! function_exists( 'wc_get_product' ) ) {
		return $block_content;
	}

	$product_ids = oasi_single_post_get_block_product_ids( $block );
	if ( empty( $product_ids ) ) {
		return $block_content;
	}

	$products = array();
	foreach ( array_slice( $product_ids, 0, 3 ) as $product_id ) {
		$product = wc_get_product( $product_id );
		if ( $product instanceof WC_Product && $product->is_visible() ) {
			$products[] = $product;
		}
	}

	if ( empty( $products ) ) {
		return $block_content;
	}

	ob_start();
	?>
	<aside class="oasi-single-post__products" aria-label="<?php esc_attr_e( 'Prodotti citati nell’articolo', 'oasidellespezie-child-theme' ); ?>">
		<?php foreach ( $products as $product ) :
			$product_id = $product->get_id();
			$permalink  = get_permalink( $product_id );
			$image_id   = $product->get_image_id();
			?>
			<article class="oasi-single-post__product">
				<?php if ( $image_id ) : ?>
					<a class="oasi-single-post__product-media" href="<?php echo esc_url( $permalink ); ?>" tabindex="-1" aria-hidden="true">
						<?php echo wp_get_attachment_image( $image_id, 'medium', false, array( 'loading' => 'lazy' ) ); ?>
					</a>
				<?php endif; ?>
				<div class="oasi-single-post__product-copy">
					<span class="oasi-single-post__product-kicker"><?php esc_html_e( 'Dalla bottega', 'oasidellespezie-child-theme' ); ?></span>
					<h2 class="oasi-single-post__product-title"><?php echo esc_html( $product->get_name() ); ?></h2>
					<div class="oasi-single-post__product-price"><?php echo wp_kses_post( $product->get_price_html() ); ?></div>
					<a class="oasi-single-post__product-link" href="<?php echo esc_url( $permalink ); ?>">
						<?php esc_html_e( 'Scopri il prodotto', 'oasidellespezie-child-theme' ); ?>
						<span aria-hidden="true">→</span>
					</a>
				</div>
			</article>
		<?php endforeach; ?>
	</aside>
	<?php

	return (string) ob_get_clean();
}
add_filter( 'render_block', 'oasi_single_post_render_product_block', 10, 2 );
