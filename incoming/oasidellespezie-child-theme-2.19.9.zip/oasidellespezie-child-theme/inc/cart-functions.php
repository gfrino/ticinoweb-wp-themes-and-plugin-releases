<?php
/**
 * Routing helpers for the WooCommerce cart page.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Use the child-owned cart surface only on the WooCommerce cart route.
 *
 * @param string $template Template selected by WordPress.
 * @return string
 */
function oasi_cart_template_include( string $template ): string {
	if ( ! function_exists( 'is_cart' ) || ! is_cart() ) {
		return $template;
	}

	$cart_template = get_stylesheet_directory() . '/page-cart.php';
	return is_file( $cart_template ) ? $cart_template : $template;
}
add_filter( 'template_include', 'oasi_cart_template_include', 60 );

/**
 * Return the mapped WooCommerce Shop URL.
 */
function oasi_cart_get_shop_url(): string {
	if ( function_exists( 'wc_get_page_permalink' ) ) {
		$shop_url = wc_get_page_permalink( 'shop' );
		if ( $shop_url ) {
			return (string) $shop_url;
		}
	}

	return home_url( '/' );
}
