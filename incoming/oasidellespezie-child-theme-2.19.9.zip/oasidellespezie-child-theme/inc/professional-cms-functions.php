<?php
/** Editable content for the Professional page. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Current public copy, used only until the editor saves its first revision. */
function oasi_professional_content_defaults(): array {
	return array(
		'kicker' => 'Area professionisti',
		'title' => 'Soluzioni dedicate ai professionisti',
		'lead' => 'Una selezione di spezie, erbe, pepi e sali per ristorazione, laboratori e attività che cercano materie prime scelte con cura.',
		'intro' => 'Siamo un laboratorio artigianale, non un negozio su strada: prepariamo gli ordini con attenzione e lavoriamo con un listino riservato agli account professionali approvati.',
		'fact_access' => 'Accesso verificato',
		'fact_catalog' => 'Listino nel normale Shop',
		'fact_preparation' => 'Preparazione artigianale',
		'image_id' => 33865,
		'image_eyebrow' => 'Selezione Oasi',
		'image_caption' => 'Materie prime scelte per il lavoro quotidiano',
		'guest_access_label' => 'Accesso da attivare',
		'guest_access_title' => 'Richiedi il tuo account professionale',
		'guest_access_body' => 'Registrati attraverso il modulo già predisposto. Il laboratorio verificherà la richiesta prima di abilitare il listino riservato.',
		'guest_primary_cta' => 'Registrati come professionista',
		'guest_secondary_cta' => 'Accedi all’area riservata',
		'customer_access_label' => 'Accesso professionale',
		'customer_access_title' => 'Completa il formulario per richiedere l’accesso professionale',
		'customer_access_body' => 'Il tuo account è già attivo. Clicca sul pulsante rosso “Richiedi la verifica professionale” e completa il formulario con i dati della tua attività. Esamineremo la richiesta e ti contatteremo via email.',
		'customer_primary_cta' => 'Richiedi la verifica professionale',
		'professional_access_label' => 'Accesso professionale attivo',
		'professional_access_title' => 'Il tuo catalogo riservato è pronto',
		'professional_access_body' => 'Accedi allo Shop con questo account: prezzi e disponibilità professionali vengono applicati direttamente dal sistema wholesale esistente.',
		'professional_primary_cta' => 'Accedi al catalogo professionale',
		'conditions_kicker' => 'Informazioni prima dell’ordine',
		'conditions_title' => 'Condizioni per professionisti',
		'conditions_intro' => 'Le condizioni già pubblicate sono qui raccolte in un unico punto, senza cambiare il funzionamento commerciale del sito.',
		'conditions_cta_label' => 'Hai una richiesta specifica? Contattaci',
		'conditions_cta_url' => '',
		'trust_territory_label' => 'Territorio',
		'trust_territory_value' => 'Svizzera e Liechtenstein',
		'trust_payment_label' => 'Pagamento',
		'trust_payment_value' => 'Anticipato per ogni ordine',
		'trust_preparation_label' => 'Preparazione',
		'trust_preparation_value' => 'Artigianale, da ordinare in anticipo',
		'trust_assistance_label' => 'Assistenza',
		'conditions' => array(
			array( 'title' => 'Ordini', 'body' => 'Effettuiamo ordini professionali esclusivamente in Svizzera e Liechtenstein. L’accesso al listino riservato richiede registrazione e approvazione.' ),
			array( 'title' => 'Pagamenti', 'body' => 'Per ogni ordine professionale è richiesto il pagamento anticipato.' ),
			array( 'title' => 'Preparazione ed erbe', 'body' => 'Le erbe aromatiche vengono selezionate a mano; possono rimanere alcuni rami o rametti. La lavorazione richiede tempo, quindi consigliamo di ordinare con largo anticipo.' ),
			array( 'title' => 'Spedizione', 'body' => 'Per i clienti professionali le spese di spedizione sono variabili secondo il peso della merce.' ),
		),
	);
}

/** Sanitize every editable professional field. */
function oasi_professional_sanitize_content( $value ): array {
	$value    = is_array( $value ) ? $value : array();
	$defaults = oasi_professional_content_defaults();
	$result   = array();
	$textareas = array( 'lead', 'intro', 'guest_access_body', 'customer_access_body', 'professional_access_body', 'conditions_intro' );
	$urls      = array( 'conditions_cta_url' );

	foreach ( $defaults as $key => $default ) {
		if ( 'conditions' === $key ) {
			$conditions = array_key_exists( 'conditions_present', $value )
				? ( is_array( $value['conditions'] ?? null ) ? array_values( $value['conditions'] ) : array() )
				: ( is_array( $value['conditions'] ?? null ) ? array_values( $value['conditions'] ) : $default );
			$result['conditions'] = array();
			foreach ( array_slice( $conditions, 0, 12 ) as $row ) {
				$row   = is_array( $row ) ? $row : array();
				$title = sanitize_text_field( $row['title'] ?? '' );
				$body  = sanitize_textarea_field( $row['body'] ?? '' );
				if ( '' === $title && '' === $body ) {
					continue;
				}
				$result['conditions'][] = array( 'title' => $title, 'body' => $body );
			}
		} elseif ( 'image_id' === $key ) {
			$result[ $key ] = absint( $value[ $key ] ?? $default );
		} elseif ( in_array( $key, $urls, true ) ) {
			$result[ $key ] = esc_url_raw( $value[ $key ] ?? '' );
		} elseif ( in_array( $key, $textareas, true ) ) {
			$result[ $key ] = sanitize_textarea_field( $value[ $key ] ?? $default );
		} else {
			$result[ $key ] = sanitize_text_field( $value[ $key ] ?? $default );
		}
	}

	return $result;
}

/** Merged professional data for frontend and editor. */
function oasi_get_professional_content(): array {
	$saved = get_option( 'oasi_professional_content', array() );
	return oasi_professional_sanitize_content( is_array( $saved ) ? array_replace( oasi_professional_content_defaults(), $saved ) : array() );
}

function oasi_professional_cms_register_setting(): void {
	register_setting( 'oasi_professional_settings', 'oasi_professional_content', array( 'type' => 'array', 'default' => oasi_professional_content_defaults(), 'sanitize_callback' => 'oasi_professional_sanitize_content' ) );
}
add_action( 'admin_init', 'oasi_professional_cms_register_setting' );

function oasi_professional_cms_option_capability(): string {
	return 'edit_pages';
}
add_filter( 'option_page_capability_oasi_professional_settings', 'oasi_professional_cms_option_capability' );

function oasi_professional_cms_menu(): void {
	add_submenu_page( 'ticinoweb-cms', __( 'Professionisti', 'oasidellespezie-child-theme' ), __( 'Professionisti', 'oasidellespezie-child-theme' ), 'edit_pages', 'oasi-professional-settings', 'oasi_professional_cms_render_page' );
}
add_action( 'admin_menu', 'oasi_professional_cms_menu', 41 );

function oasi_professional_cms_assets( string $hook ): void {
	if ( 'ticinoweb-cms_page_oasi-professional-settings' !== $hook ) {
		return;
	}
	wp_enqueue_media();
	wp_enqueue_style( 'oasi-cms-editor', get_stylesheet_directory_uri() . '/assets/css/cms-editor.css', array(), wp_get_theme()->get( 'Version' ) );
	wp_enqueue_script( 'oasi-cms-editor', get_stylesheet_directory_uri() . '/assets/js/cms-editor.js', array(), wp_get_theme()->get( 'Version' ), true );
}
add_action( 'admin_enqueue_scripts', 'oasi_professional_cms_assets' );

/** Small field renderer for a deliberately simple backend. */
function oasi_professional_cms_field( array $data, string $key, string $label, bool $textarea = false ): void {
	?>
	<label class="oasi-cms-editor__field"><span><?php echo esc_html( $label ); ?></span>
		<?php if ( $textarea ) : ?><textarea class="large-text" rows="4" name="oasi_professional_content[<?php echo esc_attr( $key ); ?>]"><?php echo esc_textarea( (string) $data[ $key ] ); ?></textarea><?php else : ?><input type="text" class="large-text" name="oasi_professional_content[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( (string) $data[ $key ] ); ?>"><?php endif; ?>
	</label>
	<?php
}

/** One sortable condition row in the administration editor. */
function oasi_professional_cms_condition_row( array $condition, string $index ): void {
	$number = is_numeric( $index ) ? ( (int) $index + 1 ) : 1;
	?>
	<section class="oasi-cms-editor__condition" data-oasi-condition-row>
		<div class="oasi-cms-editor__condition-heading">
			<h3><?php esc_html_e( 'Condizione', 'oasidellespezie-child-theme' ); ?> <span data-oasi-condition-number><?php echo esc_html( (string) $number ); ?></span></h3>
			<div class="oasi-cms-editor__condition-actions">
				<button type="button" class="button-link" data-oasi-condition-up><?php esc_html_e( 'Sposta su', 'oasidellespezie-child-theme' ); ?></button>
				<button type="button" class="button-link" data-oasi-condition-down><?php esc_html_e( 'Sposta giù', 'oasidellespezie-child-theme' ); ?></button>
				<button type="button" class="button-link-delete" data-oasi-condition-remove><?php esc_html_e( 'Rimuovi', 'oasidellespezie-child-theme' ); ?></button>
			</div>
		</div>
		<label class="oasi-cms-editor__field"><span><?php esc_html_e( 'Titolo', 'oasidellespezie-child-theme' ); ?></span><input type="text" class="large-text" name="oasi_professional_content[conditions][<?php echo esc_attr( $index ); ?>][title]" value="<?php echo esc_attr( (string) ( $condition['title'] ?? '' ) ); ?>"></label>
		<label class="oasi-cms-editor__field"><span><?php esc_html_e( 'Descrizione', 'oasidellespezie-child-theme' ); ?></span><textarea class="large-text" rows="4" name="oasi_professional_content[conditions][<?php echo esc_attr( $index ); ?>][body]"><?php echo esc_textarea( (string) ( $condition['body'] ?? '' ) ); ?></textarea></label>
	</section>
	<?php
}

function oasi_professional_cms_render_page(): void {
	if ( ! current_user_can( 'edit_pages' ) ) {
		wp_die( esc_html__( 'Non hai i permessi per modificare questa sezione.', 'oasidellespezie-child-theme' ) );
	}
	$data    = oasi_get_professional_content();
	$preview = $data['image_id'] ? wp_get_attachment_image_url( $data['image_id'], 'medium' ) : '';
	?>
	<div class="wrap oasi-cms-editor"><h1><?php esc_html_e( 'Pagina Professionisti', 'oasidellespezie-child-theme' ); ?></h1><p class="oasi-cms-editor__lead"><?php esc_html_e( 'Da questa pagina puoi modificare tutti i contenuti della pagina Professionisti. I collegamenti a registrazione, verifica, account e Shop sono automatici; telefono e orari arrivano da ticinoWEB CMS → Impostazioni generali.', 'oasidellespezie-child-theme' ); ?></p><?php settings_errors(); ?>
	<form method="post" action="options.php"><?php settings_fields( 'oasi_professional_settings' ); ?>
		<nav class="oasi-cms-editor__nav" aria-label="<?php esc_attr_e( 'Vai a una sezione', 'oasidellespezie-child-theme' ); ?>"><a href="#oasi-cms-introduzione"><?php esc_html_e( 'Introduzione', 'oasidellespezie-child-theme' ); ?></a><a href="#oasi-cms-accesso"><?php esc_html_e( 'Accesso', 'oasidellespezie-child-theme' ); ?></a><a href="#oasi-cms-condizioni"><?php esc_html_e( 'Condizioni', 'oasidellespezie-child-theme' ); ?></a><a href="#oasi-cms-riepilogo"><?php esc_html_e( 'Riepilogo', 'oasidellespezie-child-theme' ); ?></a></nav>
		<section id="oasi-cms-introduzione" class="oasi-cms-editor__section"><div class="oasi-cms-editor__section-heading"><div><span>01</span><h2><?php esc_html_e( 'Introduzione', 'oasidellespezie-child-theme' ); ?></h2></div><p><?php esc_html_e( 'Titolo, presentazione e immagine iniziale.', 'oasidellespezie-child-theme' ); ?></p></div>
			<div class="oasi-cms-editor__grid"><?php oasi_professional_cms_field( $data, 'kicker', 'Etichetta breve' ); ?><?php oasi_professional_cms_field( $data, 'title', 'Titolo principale' ); ?><?php oasi_professional_cms_field( $data, 'lead', 'Testo introduttivo', true ); ?><?php oasi_professional_cms_field( $data, 'intro', 'Descrizione', true ); ?></div>
			<div class="oasi-cms-editor__field" data-oasi-media-field><span><?php esc_html_e( 'Immagine', 'oasidellespezie-child-theme' ); ?></span><div class="oasi-cms-editor__media"><div class="oasi-cms-editor__preview" data-oasi-media-preview data-empty-label="Nessuna immagine"><?php if ( $preview ) : ?><img src="<?php echo esc_url( $preview ); ?>" alt=""><?php else : ?><span><?php esc_html_e( 'Nessuna immagine', 'oasidellespezie-child-theme' ); ?></span><?php endif; ?></div><div class="oasi-cms-editor__media-actions"><input type="hidden" name="oasi_professional_content[image_id]" value="<?php echo esc_attr( (string) $data['image_id'] ); ?>"><button type="button" class="button" data-oasi-media-pick data-media-type="image"><?php esc_html_e( 'Scegli immagine', 'oasidellespezie-child-theme' ); ?></button><button type="button" class="button-link-delete" data-oasi-media-clear><?php esc_html_e( 'Rimuovi', 'oasidellespezie-child-theme' ); ?></button></div></div></div>
			<?php oasi_professional_cms_field( $data, 'image_eyebrow', 'Etichetta sopra la didascalia' ); ?>
			<?php oasi_professional_cms_field( $data, 'image_caption', 'Didascalia immagine' ); ?>
		</section>
		<section id="oasi-cms-accesso" class="oasi-cms-editor__section"><div class="oasi-cms-editor__section-heading"><div><span>02</span><h2><?php esc_html_e( 'Accesso professionale', 'oasidellespezie-child-theme' ); ?></h2></div><p><?php esc_html_e( 'Testi e pulsanti cambiano automaticamente in base allo stato dell’utente.', 'oasidellespezie-child-theme' ); ?></p></div>
			<div class="oasi-cms-editor__grid"><?php oasi_professional_cms_field( $data, 'fact_access', 'Punto chiave 1' ); ?><?php oasi_professional_cms_field( $data, 'fact_catalog', 'Punto chiave 2' ); ?><?php oasi_professional_cms_field( $data, 'fact_preparation', 'Punto chiave 3' ); ?></div>
			<div class="oasi-cms-editor__groups">
				<section class="oasi-cms-editor__group"><h3><?php esc_html_e( 'Visitatore non autenticato', 'oasidellespezie-child-theme' ); ?></h3><p><?php esc_html_e( 'Vede i pulsanti di registrazione e accesso.', 'oasidellespezie-child-theme' ); ?></p><div class="oasi-cms-editor__grid"><?php oasi_professional_cms_field( $data, 'guest_access_label', 'Stato' ); ?><?php oasi_professional_cms_field( $data, 'guest_access_title', 'Titolo' ); ?><?php oasi_professional_cms_field( $data, 'guest_access_body', 'Descrizione', true ); ?><?php oasi_professional_cms_field( $data, 'guest_primary_cta', 'Pulsante registrazione' ); ?><?php oasi_professional_cms_field( $data, 'guest_secondary_cta', 'Pulsante accesso' ); ?></div></section>
				<section class="oasi-cms-editor__group"><h3><?php esc_html_e( 'Cliente con account', 'oasidellespezie-child-theme' ); ?></h3><p><?php esc_html_e( 'Vede il pulsante per richiedere la verifica professionale.', 'oasidellespezie-child-theme' ); ?></p><div class="oasi-cms-editor__grid"><?php oasi_professional_cms_field( $data, 'customer_access_label', 'Stato' ); ?><?php oasi_professional_cms_field( $data, 'customer_access_title', 'Titolo' ); ?><?php oasi_professional_cms_field( $data, 'customer_access_body', 'Descrizione', true ); ?><?php oasi_professional_cms_field( $data, 'customer_primary_cta', 'Pulsante verifica' ); ?></div></section>
				<section class="oasi-cms-editor__group"><h3><?php esc_html_e( 'Professionista approvato', 'oasidellespezie-child-theme' ); ?></h3><p><?php esc_html_e( 'Vede il collegamento diretto allo Shop con il listino riservato.', 'oasidellespezie-child-theme' ); ?></p><div class="oasi-cms-editor__grid"><?php oasi_professional_cms_field( $data, 'professional_access_label', 'Stato' ); ?><?php oasi_professional_cms_field( $data, 'professional_access_title', 'Titolo' ); ?><?php oasi_professional_cms_field( $data, 'professional_access_body', 'Descrizione', true ); ?><?php oasi_professional_cms_field( $data, 'professional_primary_cta', 'Pulsante Shop' ); ?></div></section>
			</div>
		</section>
		<section id="oasi-cms-condizioni" class="oasi-cms-editor__section"><div class="oasi-cms-editor__section-heading"><div><span>03</span><h2><?php esc_html_e( 'Condizioni', 'oasidellespezie-child-theme' ); ?></h2></div><p><?php esc_html_e( 'Aggiungi, rimuovi e riordina le informazioni mostrate nella pagina e dal link Condizioni del menu.', 'oasidellespezie-child-theme' ); ?></p></div><div class="oasi-cms-editor__grid"><?php oasi_professional_cms_field( $data, 'conditions_kicker', 'Etichetta' ); ?><?php oasi_professional_cms_field( $data, 'conditions_title', 'Titolo' ); ?><?php oasi_professional_cms_field( $data, 'conditions_intro', 'Introduzione', true ); ?><?php oasi_professional_cms_field( $data, 'conditions_cta_label', 'Testo CTA' ); ?><label class="oasi-cms-editor__field"><span><?php esc_html_e( 'URL CTA (facoltativo)', 'oasidellespezie-child-theme' ); ?></span><input type="url" class="large-text" name="oasi_professional_content[conditions_cta_url]" value="<?php echo esc_attr( (string) $data['conditions_cta_url'] ); ?>"><small><?php esc_html_e( 'Se lo lasci vuoto, il pulsante porta automaticamente alla pagina Contatto.', 'oasidellespezie-child-theme' ); ?></small></label></div>
			<input type="hidden" name="oasi_professional_content[conditions_present]" value="1">
			<div class="oasi-cms-editor__conditions-toolbar"><p><?php esc_html_e( 'Ogni voce diventa un pannello apribile nel frontend.', 'oasidellespezie-child-theme' ); ?></p><button type="button" class="button button-secondary" data-oasi-condition-add><?php esc_html_e( 'Aggiungi condizione', 'oasidellespezie-child-theme' ); ?></button></div>
			<div class="oasi-cms-editor__conditions" data-oasi-condition-list><?php foreach ( $data['conditions'] as $index => $condition ) : ?><?php oasi_professional_cms_condition_row( $condition, (string) $index ); ?><?php endforeach; ?></div>
			<template data-oasi-condition-template><?php oasi_professional_cms_condition_row( array( 'title' => '', 'body' => '' ), '__INDEX__' ); ?></template>
		</section>
		<section id="oasi-cms-riepilogo" class="oasi-cms-editor__section"><div class="oasi-cms-editor__section-heading"><div><span>04</span><h2><?php esc_html_e( 'Riepilogo finale', 'oasidellespezie-child-theme' ); ?></h2></div><p><?php esc_html_e( 'Etichette e valori mostrati nella fascia conclusiva. Telefono e orari sono automatici.', 'oasidellespezie-child-theme' ); ?></p></div><div class="oasi-cms-editor__grid">
			<?php foreach ( array( 'trust_territory_label' => 'Etichetta territorio', 'trust_territory_value' => 'Valore territorio', 'trust_payment_label' => 'Etichetta pagamento', 'trust_payment_value' => 'Valore pagamento', 'trust_preparation_label' => 'Etichetta preparazione', 'trust_preparation_value' => 'Valore preparazione', 'trust_assistance_label' => 'Etichetta assistenza' ) as $key => $label ) : ?><?php oasi_professional_cms_field( $data, $key, $label ); ?><?php endforeach; ?>
		</div></section><?php submit_button( __( 'Salva pagina Professionisti', 'oasidellespezie-child-theme' ) ); ?></form></div>
	<?php
}
