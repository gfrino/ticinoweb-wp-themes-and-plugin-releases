<?php
/**
 * Dynamic news & recipes helpers for Oasi delle Spezie.
 *
 * Powers /scoprite-le-nostre-novita/ with dynamic WordPress posts,
 * categories, media fallback, and template routing.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Query published news and recipes ordered by date descending.
 *
 * @param array $overrides Optional query argument overrides.
 * @return WP_Query
 */
function oasi_news_query( array $overrides = array() ): WP_Query {
	$paged = max( 1, (int) get_query_var( 'paged' ), (int) get_query_var( 'page' ) );

	$defaults = array(
		'post_type'      => 'post',
		'post_status'    => 'publish',
		'orderby'        => 'date',
		'order'          => 'DESC',
		'posts_per_page' => 12,
		'paged'          => $paged,
		'no_found_rows'  => false,
	);

	$args = wp_parse_args( $overrides, $defaults );

	return new WP_Query( $args );
}

/**
 * Retrieve active categories that have published posts.
 *
 * @return WP_Term[] Array of categories.
 */
function oasi_news_get_categories(): array {
	$categories = get_categories(
		array(
			'hide_empty' => true,
			'orderby'    => 'count',
			'order'      => 'DESC',
		)
	);

	if ( is_wp_error( $categories ) || empty( $categories ) ) {
		return array();
	}

	// Filter out "Non categorizzato" if present
	return array_values(
		array_filter(
			$categories,
			static function ( WP_Term $term ): bool {
				return 'non-categorizzato' !== $term->slug && $term->count > 0;
			}
		)
	);
}

/**
 * Return the primary category of a post.
 *
 * Prioritizes specific editorial categories (e.g. 'Ricette', 'Blog').
 *
 * @param int $post_id Post ID.
 * @return WP_Term|null
 */
function oasi_news_get_primary_category( int $post_id ): ?WP_Term {
	$categories = get_the_category( $post_id );

	if ( empty( $categories ) || is_wp_error( $categories ) ) {
		return null;
	}

	// If multiple, prefer 'ricette' or 'blog'
	foreach ( $categories as $cat ) {
		if ( in_array( $cat->slug, array( 'ricette', 'blog' ), true ) ) {
			return $cat;
		}
	}

	return $categories[0];
}

/**
 * Return all category slugs for a post as a space-separated string for JS filtering.
 *
 * @param int $post_id Post ID.
 * @return string Space-separated category slugs.
 */
function oasi_news_get_category_slugs( int $post_id ): string {
	$categories = get_the_category( $post_id );

	if ( empty( $categories ) || is_wp_error( $categories ) ) {
		return '';
	}

	$slugs = array_map(
		static function ( WP_Term $term ): string {
			return $term->slug;
		},
		$categories
	);

	return implode( ' ', $slugs );
}

/**
 * Render featured image with graceful Oasi botanical brand fallback if missing.
 *
 * @param int    $post_id Post ID.
 * @param string $size    WordPress image size.
 * @param array  $attr    Image attributes.
 * @return string HTML img tag or brand SVG fallback.
 */
function oasi_news_get_featured_image_html( int $post_id, string $size = 'large', array $attr = array() ): string {
	if ( has_post_thumbnail( $post_id ) ) {
		$default_attr = array(
			'loading' => 'lazy',
			'class'   => 'oasi-news-card__img',
		);
		$attr = wp_parse_args( $attr, $default_attr );
		return get_the_post_thumbnail( $post_id, $size, $attr );
	}

	// Graceful brand fallback: SVG emblem on natural sand background
	$title = get_the_title( $post_id );
	return sprintf(
		'<div class="oasi-news-card__fallback" role="img" aria-label="%s">' .
			'<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' .
				'<path d="M12 2a9 9 0 0 1 9 9c0 4.97-4.03 9-9 9s-9-4.03-9-9 4.03-9 9-9z"></path>' .
				'<path d="M12 6v6l4 2"></path>' .
				'<path d="M7 12c1.5 2 3.5 3 5 3s3.5-1 5-3"></path>' .
			'</svg>' .
			'<span class="oasi-news-card__fallback-label">%s</span>' .
		'</div>',
		esc_attr( $title ),
		esc_html__( 'Oasi delle Spezie', 'oasidellespezie-child-theme' )
	);
}

/**
 * Format a post date localized in Italian.
 *
 * @param int $post_id Post ID.
 * @return string Localized date string (e.g. "26 Novembre 2023").
 */
function oasi_news_format_date( int $post_id ): string {
	$timestamp = get_post_timestamp( $post_id );

	if ( ! $timestamp ) {
		return get_the_date( 'j F Y', $post_id );
	}

	return wp_date( 'j F Y', $timestamp );
}

/**
 * Return a clean, balanced excerpt without shortcode garbage or unclosed tags.
 *
 * @param int $post_id Post ID.
 * @param int $words   Number of words limit.
 * @return string Clean excerpt text.
 */
function oasi_news_get_clean_excerpt( int $post_id, int $words = 22 ): string {
	$post = get_post( $post_id );

	if ( ! $post ) {
		return '';
	}

	$text = $post->post_excerpt;

	if ( empty( $text ) ) {
		$text = $post->post_content;
	}

	$text = strip_shortcodes( $text );
	$text = wp_strip_all_tags( $text );
	$text = str_replace( array( "\r\n", "\r", "\n" ), ' ', $text );

	return wp_trim_words( $text, $words, '…' );
}

/**
 * Defensive template include hook for /scoprite-le-nostre-novita/.
 *
 * Ensures the custom editorial magazine template is loaded even if postmeta
 * has an Elementor canvas or legacy template assigned.
 *
 * @param string $template Current matched template file path.
 * @return string Matched or overridden template path.
 */
function oasi_news_template_include( string $template ): string {
	if ( is_page( 'scoprite-le-nostre-novita' ) || is_page( 16465 ) ) {
		$custom = get_stylesheet_directory() . '/page-scoprite-le-nostre-novita.php';
		if ( file_exists( $custom ) ) {
			return $custom;
		}
	}

	return $template;
}
add_filter( 'template_include', 'oasi_news_template_include', 99 );
