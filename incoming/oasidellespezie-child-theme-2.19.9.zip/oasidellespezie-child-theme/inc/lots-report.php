<?php
/**
 * Pagina wp-admin "WooCommerce -> Lotti e vendite".
 *
 * Cinque schede, tutte esportabili in CSV:
 * - Vendite: prodotti venduti in un giorno (o intervallo), divisi per lotto;
 * - Magazzino: tutte le giacenze con i loro lotti, modificabili in blocco;
 * - Lotti: tutti i lotti con quantita' residua e stato di scadenza;
 * - Controlli: giacenze che non tornano con i lotti e vendite senza lotto;
 * - Tracciabilita': in quali ordini e' uscito un codice lotto.
 *
 * Solo la scheda Magazzino scrive, e solo i lotti (con la stessa logica della
 * scheda prodotto); le altre leggono soltanto.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const OASI_LOTS_REPORT_SLUG = 'oasi-lotti';

/**
 * Order statuses counted as sales.
 *
 * @return array<int, string>
 */
function oasi_lots_report_statuses(): array {
	return array( 'wc-processing', 'wc-completed', 'wc-on-hold' );
}

/**
 * Sales channel of an order.
 *
 * @param WC_Order $order Order.
 */
function oasi_lots_report_channel( WC_Order $order ): string {
	return 'openpos' === $order->get_created_via() ? 'pos' : 'online';
}

/**
 * Label of a sales channel.
 *
 * @param string $channel Channel key.
 */
function oasi_lots_report_channel_label( string $channel ): string {
	return 'pos' === $channel ? __( 'POS', 'oasidellespezie-child-theme' ) : __( 'Online', 'oasidellespezie-child-theme' );
}

/**
 * Human label of an allocation entry's lot.
 *
 * @param array<string, mixed> $entry Allocation entry.
 */
function oasi_lots_report_lot_label( array $entry ): string {
	$lot = (string) ( $entry['lot'] ?? '' );

	if ( OASI_LOTS_LEGACY === $lot ) {
		return __( 'precedente ai lotti', 'oasidellespezie-child-theme' );
	}
	if ( OASI_LOTS_NONE === $lot ) {
		return __( 'senza lotto disponibile', 'oasidellespezie-child-theme' );
	}
	if ( '' === $lot ) {
		return '—';
	}

	return '' !== (string) ( $entry['code'] ?? '' ) ? (string) $entry['code'] : __( '(senza codice)', 'oasidellespezie-child-theme' );
}

/**
 * Split one order line into per-lot parts.
 *
 * The allocation holds what left the stock (it can differ from the line quantity for
 * weight sales and already excludes restocked refunds). Revenue is split in
 * proportion. Lines without allocation become a single part without lot.
 *
 * @param float                            $line_qty     Line quantity net of refunds.
 * @param float                            $line_revenue Line revenue net of refunds, tax included.
 * @param array<int, array<string, mixed>> $alloc        Allocation entries.
 * @return array<int, array{lot: string, code: string, expiry: string, label: string, qty: float, revenue: float}>
 */
function oasi_lots_report_split_line( float $line_qty, float $line_revenue, array $alloc ): array {
	$alloc = array_values( array_filter( $alloc, static fn( $entry ): bool => is_array( $entry ) && (float) ( $entry['qty'] ?? 0 ) > 0 ) );
	$total = oasi_lots_total( $alloc );

	if ( array() === $alloc || $total <= 0 ) {
		return array(
			array(
				'lot'     => '',
				'code'    => '',
				'expiry'  => '',
				'label'   => '—',
				'qty'     => oasi_lots_qty( $line_qty ),
				'revenue' => round( $line_revenue, 2 ),
			),
		);
	}

	$parts = array();
	foreach ( $alloc as $entry ) {
		$qty     = oasi_lots_qty( $entry['qty'] );
		$parts[] = array(
			'lot'     => (string) $entry['lot'],
			'code'    => (string) ( $entry['code'] ?? '' ),
			'expiry'  => (string) ( $entry['expiry'] ?? '' ),
			'label'   => oasi_lots_report_lot_label( $entry ),
			'qty'     => $qty,
			'revenue' => round( $line_revenue * $qty / $total, 2 ),
		);
	}

	return $parts;
}

/**
 * Read the report filters from the request.
 *
 * @return array{tab: string, from: string, to: string, channel: string, days: string, code: string}
 */
function oasi_lots_report_filters(): array {
	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only filters.
	$today = wp_date( 'Y-m-d' );
	$from  = sanitize_text_field( wp_unslash( (string) ( $_GET['from'] ?? $today ) ) );
	$to    = sanitize_text_field( wp_unslash( (string) ( $_GET['to'] ?? '' ) ) );
	$tab   = sanitize_key( wp_unslash( (string) ( $_GET['tab'] ?? 'vendite' ) ) );
	$show  = sanitize_key( wp_unslash( (string) ( $_GET['show'] ?? '' ) ) );

	$filters = array(
		'tab'     => in_array( $tab, array( 'vendite', 'magazzino', 'lotti', 'controlli', 'tracciabilita' ), true ) ? $tab : 'vendite',
		'from'    => DateTimeImmutable::createFromFormat( '!Y-m-d', $from ) ? $from : $today,
		'to'      => DateTimeImmutable::createFromFormat( '!Y-m-d', $to ) ? $to : '',
		'channel' => in_array( $_GET['channel'] ?? '', array( 'online', 'pos' ), true ) ? (string) $_GET['channel'] : '',
		'days'    => in_array( $_GET['days'] ?? '', array( 'scaduti', '30', '60', '90' ), true ) ? (string) $_GET['days'] : '',
		'code'    => sanitize_text_field( wp_unslash( (string) ( $_GET['code'] ?? '' ) ) ),
		'q'       => sanitize_text_field( wp_unslash( (string) ( $_GET['q'] ?? '' ) ) ),
		'show'    => in_array( $show, array( 'senza', 'senza-giacenza', 'con' ), true ) ? $show : '',
		'paged'   => (string) max( 1, absint( $_GET['paged'] ?? 1 ) ),
	);
	// phpcs:enable

	if ( '' === $filters['to'] || $filters['to'] < $filters['from'] ) {
		$filters['to'] = $filters['from'];
	}

	return $filters;
}

/*
 * -------------------------------------------------------------------------
 * Dati delle schede.
 * -------------------------------------------------------------------------
 */

/**
 * Sold products grouped by product and lot for a date range (site timezone).
 *
 * @param string $from    First day, Y-m-d.
 * @param string $to      Last day, Y-m-d.
 * @param string $channel '' (all), 'online' or 'pos'.
 * @return array{rows: array<int, array<string, mixed>>, orders: int, by_channel: array<string, array{orders: int, revenue: float}>, qty: float, revenue: float}
 */
function oasi_lots_report_sales( string $from, string $to, string $channel ): array {
	$timezone = wp_timezone();
	$start    = new DateTimeImmutable( $from . ' 00:00:00', $timezone );
	$end      = new DateTimeImmutable( $to . ' 23:59:59', $timezone );

	$orders = wc_get_orders(
		array(
			'type'         => 'shop_order',
			'status'       => oasi_lots_report_statuses(),
			'date_created' => $start->getTimestamp() . '...' . $end->getTimestamp(),
			'limit'        => -1,
			'orderby'      => 'date',
			'order'        => 'ASC',
		)
	);

	$rows       = array();
	$by_channel = array(
		'online' => array( 'orders' => 0, 'revenue' => 0.0 ),
		'pos'    => array( 'orders' => 0, 'revenue' => 0.0 ),
	);
	$count      = 0;

	foreach ( $orders as $order ) {
		if ( ! ( $order instanceof WC_Order ) ) {
			continue;
		}

		$order_channel = oasi_lots_report_channel( $order );
		if ( '' !== $channel && $channel !== $order_channel ) {
			continue;
		}

		$order_revenue = 0.0;
		foreach ( $order->get_items() as $item ) {
			if ( ! ( $item instanceof WC_Order_Item_Product ) ) {
				continue;
			}

			$qty     = (float) $item->get_quantity() + (float) $order->get_qty_refunded_for_item( $item->get_id() );
			$revenue = (float) $item->get_total() + (float) $item->get_total_tax()
				- (float) $order->get_total_refunded_for_item( $item->get_id() )
				- (float) oasi_lots_report_refunded_tax_for_item( $order, $item->get_id() );

			if ( $qty <= 0 && $revenue <= 0 ) {
				continue;
			}

			$alloc = $item->get_meta( OASI_LOTS_ALLOC_META, true );
			$parts = oasi_lots_report_split_line( $qty, $revenue, is_array( $alloc ) ? $alloc : array() );
			$pid   = (int) ( $item->get_variation_id() ?: $item->get_product_id() );
			$prod  = $item->get_product();

			foreach ( $parts as $part ) {
				$key = $pid . '|' . $part['lot'] . '|' . $part['code'];
				if ( ! isset( $rows[ $key ] ) ) {
					$rows[ $key ] = array(
						'product' => $item->get_name(),
						'sku'     => $prod ? (string) $prod->get_sku() : '',
						'lot'     => $part['label'],
						'code'    => in_array( $part['lot'], array( '', OASI_LOTS_NONE, OASI_LOTS_LEGACY ), true ) ? '' : $part['code'],
						'expiry'  => $part['expiry'],
						'qty'     => 0.0,
						'revenue' => 0.0,
						'orders'  => array(),
					);
				}
				$rows[ $key ]['qty']                           = oasi_lots_qty( $rows[ $key ]['qty'] + $part['qty'] );
				$rows[ $key ]['revenue']                       = round( $rows[ $key ]['revenue'] + $part['revenue'], 2 );
				$rows[ $key ]['orders'][ $order->get_id() ] = true;
			}

			$order_revenue += $revenue;
		}

		++$count;
		$by_channel[ $order_channel ]['orders']++;
		$by_channel[ $order_channel ]['revenue'] = round( $by_channel[ $order_channel ]['revenue'] + $order_revenue, 2 );
	}

	$rows = array_values( $rows );
	usort( $rows, static fn( array $a, array $b ): int => strcasecmp( $a['product'], $b['product'] ) ?: strcmp( $a['lot'], $b['lot'] ) );

	$qty = 0.0;
	$rev = 0.0;
	foreach ( $rows as $key => $row ) {
		$rows[ $key ]['orders'] = count( $row['orders'] );
		$qty                   += $row['qty'];
		$rev                   += $row['revenue'];
	}

	return array(
		'rows'       => $rows,
		'orders'     => $count,
		'by_channel' => $by_channel,
		'qty'        => oasi_lots_qty( $qty ),
		'revenue'    => round( $rev, 2 ),
	);
}

/**
 * Tax refunded for one line item (WooCommerce only exposes it per tax rate).
 *
 * @param WC_Order $order   Order.
 * @param int      $item_id Item ID.
 */
function oasi_lots_report_refunded_tax_for_item( WC_Order $order, int $item_id ): float {
	$tax = 0.0;
	foreach ( $order->get_taxes() as $tax_item ) {
		$tax += (float) $order->get_tax_refunded_for_item( $item_id, $tax_item->get_rate_id() );
	}

	return $tax;
}

/**
 * IDs of all products and variations that have lots.
 *
 * @return array<int, int>
 */
function oasi_lots_report_product_ids(): array {
	global $wpdb;

	$ids = $wpdb->get_col( $wpdb->prepare( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s", OASI_LOTS_META ) );

	return array_map( 'intval', $ids );
}

/**
 * Expiry status of a lot.
 *
 * @param string $expiry Y-m-d or ''.
 * @param string $today  Y-m-d.
 * @return array{key: string, label: string, days: int|null}
 */
function oasi_lots_report_expiry_status( string $expiry, string $today ): array {
	$date = '' !== $expiry ? DateTimeImmutable::createFromFormat( '!Y-m-d', $expiry ) : false;
	if ( ! $date ) {
		return array( 'key' => 'none', 'label' => __( 'senza scadenza', 'oasidellespezie-child-theme' ), 'days' => null );
	}

	$days = (int) DateTimeImmutable::createFromFormat( '!Y-m-d', $today )->diff( $date )->format( '%r%a' );

	if ( $days < 0 ) {
		return array( 'key' => 'expired', 'label' => __( 'scaduto', 'oasidellespezie-child-theme' ), 'days' => $days );
	}
	if ( $days <= 90 ) {
		/* translators: %d: days to expiry. */
		return array( 'key' => 'soon', 'label' => sprintf( _n( 'scade tra %d giorno', 'scade tra %d giorni', $days, 'oasidellespezie-child-theme' ), $days ), 'days' => $days );
	}

	return array( 'key' => 'ok', 'label' => __( 'ok', 'oasidellespezie-child-theme' ), 'days' => $days );
}

/**
 * All lots with residual quantity, earliest expiry first.
 *
 * @param string $days Filter: '' all, 'scaduti', or a number of days.
 * @return array<int, array<string, mixed>>
 */
function oasi_lots_report_lots( string $days ): array {
	$today = wp_date( 'Y-m-d' );
	$rows  = array();

	foreach ( oasi_lots_report_product_ids() as $product_id ) {
		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			continue;
		}

		foreach ( oasi_lots_get( $product_id ) as $lot ) {
			if ( oasi_lots_qty( $lot['qty'] ?? 0 ) <= 0 ) {
				continue;
			}

			$status = oasi_lots_report_expiry_status( (string) ( $lot['expiry'] ?? '' ), $today );

			if ( 'scaduti' === $days && 'expired' !== $status['key'] ) {
				continue;
			}
			if ( ctype_digit( $days ) && ( null === $status['days'] || $status['days'] > (int) $days ) ) {
				continue;
			}

			$rows[] = array(
				'product'    => wp_strip_all_tags( $product->get_name() ),
				'sku'        => (string) $product->get_sku(),
				'code'       => (string) ( $lot['code'] ?? '' ),
				'expiry'     => (string) ( $lot['expiry'] ?? '' ),
				'qty'        => oasi_lots_qty( $lot['qty'] ),
				'status'     => $status,
				'edit_url'   => (string) get_edit_post_link( $product->get_parent_id() ?: $product_id, 'raw' ),
			);
		}
	}

	usort(
		$rows,
		static function ( array $a, array $b ): int {
			if ( $a['expiry'] !== $b['expiry'] ) {
				if ( '' === $a['expiry'] ) {
					return 1;
				}
				if ( '' === $b['expiry'] ) {
					return -1;
				}
				return strcmp( $a['expiry'], $b['expiry'] );
			}
			return strcasecmp( $a['product'], $b['product'] );
		}
	);

	return $rows;
}

/**
 * Products whose WooCommerce stock differs from the sum of their lots.
 *
 * @return array<int, array<string, mixed>>
 */
function oasi_lots_report_mismatches(): array {
	$rows = array();

	foreach ( oasi_lots_report_product_ids() as $product_id ) {
		$product = wc_get_product( $product_id );
		if ( ! $product || ! $product->managing_stock() || (int) $product->get_stock_managed_by_id() !== $product_id ) {
			continue;
		}

		$stock = oasi_lots_qty( $product->get_stock_quantity() );
		$lots  = oasi_lots_total( oasi_lots_get( $product_id ) );

		if ( $stock !== $lots ) {
			$rows[] = array(
				'product'  => wp_strip_all_tags( $product->get_name() ),
				'sku'      => (string) $product->get_sku(),
				'stock'    => $stock,
				'lots'     => $lots,
				'diff'     => oasi_lots_qty( $stock - $lots ),
				'edit_url' => (string) get_edit_post_link( $product->get_parent_id() ?: $product_id, 'raw' ),
			);
		}
	}

	return $rows;
}

/**
 * Order lines whose allocation contains the given lot marker or lot code.
 *
 * @param string $needle  Text to search in the stored allocation.
 * @param callable $match Receives an allocation entry, returns the matched quantity (0 = no match).
 * @param int    $limit   Maximum number of lines.
 * @return array<int, array<string, mixed>>
 */
function oasi_lots_report_find_lines( string $needle, callable $match, int $limit = 500 ): array {
	global $wpdb;

	$items = $wpdb->get_results(
		$wpdb->prepare(
			"SELECT im.order_item_id, oi.order_id
			FROM {$wpdb->prefix}woocommerce_order_itemmeta im
			INNER JOIN {$wpdb->prefix}woocommerce_order_items oi ON oi.order_item_id = im.order_item_id
			WHERE im.meta_key = %s AND im.meta_value LIKE %s
			ORDER BY oi.order_id DESC
			LIMIT %d",
			OASI_LOTS_ALLOC_META,
			'%' . $wpdb->esc_like( $needle ) . '%',
			$limit
		)
	);

	$rows = array();
	foreach ( $items as $row ) {
		$order = wc_get_order( (int) $row->order_id );
		if ( ! ( $order instanceof WC_Order ) ) {
			continue;
		}
		$item = $order->get_item( (int) $row->order_item_id );
		if ( ! ( $item instanceof WC_Order_Item_Product ) ) {
			continue;
		}

		$alloc = $item->get_meta( OASI_LOTS_ALLOC_META, true );
		foreach ( is_array( $alloc ) ? $alloc : array() as $entry ) {
			$qty = (float) $match( $entry );
			if ( $qty <= 0 ) {
				continue;
			}

			$date   = $order->get_date_created();
			$rows[] = array(
				'date'     => $date ? $date->date_i18n( 'd.m.Y H:i' ) : '',
				'order'    => $order->get_order_number(),
				'channel'  => oasi_lots_report_channel_label( oasi_lots_report_channel( $order ) ),
				'customer' => trim( $order->get_formatted_billing_full_name() ) ?: __( '(cliente al banco)', 'oasidellespezie-child-theme' ),
				'email'    => (string) $order->get_billing_email(),
				'product'  => $item->get_name(),
				'lot'      => oasi_lots_report_lot_label( $entry ),
				'expiry'   => (string) ( $entry['expiry'] ?? '' ),
				'qty'      => oasi_lots_qty( $qty ),
				'status'   => wc_get_order_status_name( $order->get_status() ),
				'edit_url' => $order->get_edit_order_url(),
			);
		}
	}

	return $rows;
}

/**
 * Where a lot code went: every order line that took from it.
 *
 * @param string $code Lot code (case-insensitive, exact).
 * @return array<int, array<string, mixed>>
 */
function oasi_lots_report_trace( string $code ): array {
	if ( '' === $code ) {
		return array();
	}

	return oasi_lots_report_find_lines(
		$code,
		static function ( array $entry ) use ( $code ): float {
			$is_lot = ! in_array( (string) ( $entry['lot'] ?? '' ), array( OASI_LOTS_NONE, OASI_LOTS_LEGACY, '' ), true );
			return ( $is_lot && 0 === strcasecmp( (string) ( $entry['code'] ?? '' ), $code ) ) ? (float) $entry['qty'] : 0.0;
		}
	);
}

/**
 * Recent sales that could not be taken from a lot.
 *
 * @return array<int, array<string, mixed>>
 */
function oasi_lots_report_without_lot(): array {
	return oasi_lots_report_find_lines(
		OASI_LOTS_NONE,
		static fn( array $entry ): float => OASI_LOTS_NONE === (string) ( $entry['lot'] ?? '' ) ? (float) $entry['qty'] : 0.0,
		200
	);
}

/*
 * -------------------------------------------------------------------------
 * CSV.
 * -------------------------------------------------------------------------
 */

/**
 * Header and rows of the CSV for the current tab.
 *
 * @param array<string, string> $filters Filters.
 * @return array{name: string, header: array<int, string>, rows: array<int, array<int, mixed>>}
 */
function oasi_lots_report_csv_data( array $filters ): array {
	switch ( $filters['tab'] ) {
		case 'lotti':
			return array(
				'name'   => 'lotti-' . wp_date( 'Y-m-d' ),
				'header' => array( 'Prodotto', 'SKU', 'Lotto', 'Scadenza', 'Quantità', 'Stato' ),
				'rows'   => array_map(
					static fn( array $r ): array => array( $r['product'], $r['sku'], $r['code'], $r['expiry'] ? oasi_lots_format_expiry( $r['expiry'] ) : '', $r['qty'], $r['status']['label'] ),
					oasi_lots_report_lots( $filters['days'] )
				),
			);

		case 'magazzino':
			$stock_rows = array();
			foreach ( oasi_lots_report_stock_items( $filters, false )['ids'] as $product_id ) {
				$product = wc_get_product( $product_id );
				if ( ! $product ) {
					continue;
				}
				$lots = oasi_lots_get( $product_id );
				if ( array() === $lots ) {
					$stock_rows[] = array( wp_strip_all_tags( $product->get_name() ), $product->get_sku(), $product->get_stock_quantity(), '', '', '' );
				}
				foreach ( oasi_lots_sort_fifo( $lots ) as $lot ) {
					$stock_rows[] = array( wp_strip_all_tags( $product->get_name() ), $product->get_sku(), $product->get_stock_quantity(), $lot['code'], $lot['expiry'] ? oasi_lots_format_expiry( (string) $lot['expiry'] ) : '', $lot['qty'] );
				}
			}
			return array(
				'name'   => 'magazzino-lotti-' . wp_date( 'Y-m-d' ),
				'header' => array( 'Prodotto', 'SKU', 'Giacenza', 'Lotto', 'Scadenza', 'Quantità lotto' ),
				'rows'   => $stock_rows,
			);

		case 'controlli':
			return array(
				'name'   => 'controlli-lotti-' . wp_date( 'Y-m-d' ),
				'header' => array( 'Prodotto', 'SKU', 'Magazzino', 'Somma lotti', 'Differenza' ),
				'rows'   => array_map(
					static fn( array $r ): array => array( $r['product'], $r['sku'], $r['stock'], $r['lots'], $r['diff'] ),
					oasi_lots_report_mismatches()
				),
			);

		case 'tracciabilita':
			return array(
				'name'   => 'tracciabilita-' . sanitize_file_name( $filters['code'] ),
				'header' => array( 'Data', 'Ordine', 'Canale', 'Cliente', 'Email', 'Prodotto', 'Lotto', 'Scadenza', 'Quantità', 'Stato' ),
				'rows'   => array_map(
					static fn( array $r ): array => array( $r['date'], $r['order'], $r['channel'], $r['customer'], $r['email'], $r['product'], $r['lot'], $r['expiry'] ? oasi_lots_format_expiry( $r['expiry'] ) : '', $r['qty'], $r['status'] ),
					oasi_lots_report_trace( $filters['code'] )
				),
			);
	}

	$sales = oasi_lots_report_sales( $filters['from'], $filters['to'], $filters['channel'] );
	$name  = 'vendite-' . $filters['from'] . ( $filters['to'] !== $filters['from'] ? '_' . $filters['to'] : '' ) . ( $filters['channel'] ? '-' . $filters['channel'] : '' );

	return array(
		'name'   => $name,
		'header' => array( 'Prodotto', 'SKU', 'Lotto', 'Scadenza', 'Quantità', 'Incasso IVA incl.', 'Ordini' ),
		'rows'   => array_map(
			static fn( array $r ): array => array( $r['product'], $r['sku'], $r['lot'], $r['expiry'] ? oasi_lots_format_expiry( $r['expiry'] ) : '', $r['qty'], number_format( $r['revenue'], 2, '.', '' ), $r['orders'] ),
			$sales['rows']
		),
	);
}

/**
 * Neutralise a CSV cell so spreadsheet apps never run it as a formula.
 *
 * Customer names and emails come from checkout fields anyone can fill in:
 * a value starting with = + - @ tab or CR would become a live formula in Excel.
 * Plain numbers (including negative differences) are left numeric.
 *
 * @param mixed $value Cell value.
 * @return mixed
 */
function oasi_lots_csv_cell( mixed $value ): mixed {
	if ( is_int( $value ) || is_float( $value ) ) {
		return $value;
	}

	$value = (string) $value;
	if ( '' !== $value && str_contains( "=+-@\t\r", $value[0] ) && ! is_numeric( $value ) ) {
		return "'" . $value;
	}

	return $value;
}

/**
 * Stream the CSV before any admin output (Excel-friendly: BOM and semicolons).
 */
function oasi_lots_report_maybe_export(): void {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- nonce checked below.
	if ( ( $_GET['page'] ?? '' ) !== OASI_LOTS_REPORT_SLUG || empty( $_GET['export'] ) ) {
		return;
	}

	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		wp_die( esc_html__( 'Permesso negato.', 'oasidellespezie-child-theme' ), 403 );
	}
	check_admin_referer( 'oasi_lots_export' );

	$data = oasi_lots_report_csv_data( oasi_lots_report_filters() );

	nocache_headers();
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename="' . $data['name'] . '.csv"' );

	$out = fopen( 'php://output', 'w' );
	fwrite( $out, "\xEF\xBB\xBF" );
	fputcsv( $out, array_map( 'oasi_lots_csv_cell', $data['header'] ), ';', '"', '' );
	foreach ( $data['rows'] as $row ) {
		fputcsv( $out, array_map( 'oasi_lots_csv_cell', $row ), ';', '"', '' );
	}
	fclose( $out );
	exit;
}
add_action( 'admin_init', 'oasi_lots_report_maybe_export' );

/*
 * -------------------------------------------------------------------------
 * Pagina.
 * -------------------------------------------------------------------------
 */

/**
 * Register the page under WooCommerce.
 */
function oasi_lots_report_menu(): void {
	add_submenu_page(
		'woocommerce',
		__( 'Lotti e vendite', 'oasidellespezie-child-theme' ),
		__( 'Lotti e vendite', 'oasidellespezie-child-theme' ),
		'manage_woocommerce',
		OASI_LOTS_REPORT_SLUG,
		'oasi_lots_report_render'
	);
}
add_action( 'admin_menu', 'oasi_lots_report_menu', 60 );

/**
 * URL of the report page with the given arguments.
 *
 * @param array<string, string> $args Query arguments.
 */
function oasi_lots_report_url( array $args ): string {
	return add_query_arg( array_filter( array( 'page' => OASI_LOTS_REPORT_SLUG ) + $args, static fn( $v ): bool => '' !== $v ), admin_url( 'admin.php' ) );
}

/**
 * Format a quantity for display.
 *
 * @param float $qty Quantity.
 */
function oasi_lots_report_num( float $qty ): string {
	return wc_format_localized_decimal( oasi_lots_qty( $qty ) );
}

/**
 * Render the report page.
 */
function oasi_lots_report_render(): void {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}

	$filters = oasi_lots_report_filters();
	$tabs    = array(
		'vendite'       => __( 'Vendite giornaliere', 'oasidellespezie-child-theme' ),
		'magazzino'     => __( 'Magazzino e lotti', 'oasidellespezie-child-theme' ),
		'lotti'         => __( 'Lotti in magazzino', 'oasidellespezie-child-theme' ),
		'controlli'     => __( 'Controlli', 'oasidellespezie-child-theme' ),
		'tracciabilita' => __( 'Tracciabilità lotto', 'oasidellespezie-child-theme' ),
	);
	$export  = wp_nonce_url( oasi_lots_report_url( $filters + array( 'export' => '1' ) ), 'oasi_lots_export' );
	?>
	<div class="wrap oasi-lots-report">
		<h1 class="wp-heading-inline"><?php esc_html_e( 'Lotti e vendite', 'oasidellespezie-child-theme' ); ?></h1>
		<a class="page-title-action" href="<?php echo esc_url( $export ); ?>"><?php esc_html_e( 'Esporta CSV', 'oasidellespezie-child-theme' ); ?></a>
		<hr class="wp-header-end" />

		<nav class="nav-tab-wrapper">
			<?php foreach ( $tabs as $key => $label ) : ?>
				<a class="nav-tab<?php echo $key === $filters['tab'] ? ' nav-tab-active' : ''; ?>" href="<?php echo esc_url( oasi_lots_report_url( array( 'tab' => $key ) ) ); ?>"><?php echo esc_html( $label ); ?></a>
			<?php endforeach; ?>
		</nav>

		<?php
		switch ( $filters['tab'] ) {
			case 'magazzino':
				oasi_lots_report_render_stock( $filters );
				break;
			case 'lotti':
				oasi_lots_report_render_lots( $filters );
				break;
			case 'controlli':
				oasi_lots_report_render_checks();
				break;
			case 'tracciabilita':
				oasi_lots_report_render_trace( $filters );
				break;
			default:
				oasi_lots_report_render_sales( $filters );
		}
		?>
	</div>
	<style>
		.oasi-lots-report .oasi-filters { display: flex; flex-wrap: wrap; gap: 8px 16px; align-items: end; margin: 16px 0; }
		.oasi-lots-report .oasi-filters label { display: flex; flex-direction: column; gap: 2px; font-weight: 600; }
		.oasi-lots-report .oasi-cards { display: flex; flex-wrap: wrap; gap: 12px; margin: 0 0 16px; }
		.oasi-lots-report .oasi-card { background: #fff; border: 1px solid #c3c4c7; padding: 10px 16px; min-width: 150px; }
		.oasi-lots-report .oasi-card strong { display: block; font-size: 20px; line-height: 1.4; }
		.oasi-lots-report td.num, .oasi-lots-report th.num { text-align: right; white-space: nowrap; }
		.oasi-lots-report tfoot td { font-weight: 600; }
		.oasi-lots-report .oasi-status { display: inline-block; padding: 1px 8px; border-radius: 10px; font-size: 12px; }
		.oasi-lots-report .oasi-status--expired { background: #fcf0f1; color: #8a2424; }
		.oasi-lots-report .oasi-status--soon { background: #fcf9e8; color: #6e4e00; }
		.oasi-lots-report .oasi-status--ok { background: #edfaef; color: #00450c; }
		.oasi-lots-report .oasi-status--none { background: #f0f0f1; color: #3c434a; }
		@media print { #adminmenumain, #wpadminbar, .nav-tab-wrapper, .oasi-filters, .page-title-action, #wpfooter { display: none !important; } #wpcontent { margin-left: 0 !important; } }
	</style>
	<?php
}

/**
 * Hidden fields that keep the current tab when a filter form is submitted.
 *
 * @param string $tab Tab key.
 */
function oasi_lots_report_hidden_fields( string $tab ): void {
	printf( '<input type="hidden" name="page" value="%s" /><input type="hidden" name="tab" value="%s" />', esc_attr( OASI_LOTS_REPORT_SLUG ), esc_attr( $tab ) );
}

/**
 * Tab: daily sales by product and lot.
 *
 * @param array<string, string> $filters Filters.
 */
function oasi_lots_report_render_sales( array $filters ): void {
	$sales    = oasi_lots_report_sales( $filters['from'], $filters['to'], $filters['channel'] );
	$currency = get_woocommerce_currency();
	$day      = DateTimeImmutable::createFromFormat( '!Y-m-d', $filters['from'] );
	$prev     = $day->modify( '-1 day' )->format( 'Y-m-d' );
	$next     = $day->modify( '+1 day' )->format( 'Y-m-d' );
	?>
	<form class="oasi-filters" method="get">
		<?php oasi_lots_report_hidden_fields( 'vendite' ); ?>
		<label><?php esc_html_e( 'Dal', 'oasidellespezie-child-theme' ); ?> <input type="date" name="from" value="<?php echo esc_attr( $filters['from'] ); ?>" /></label>
		<label><?php esc_html_e( 'Al', 'oasidellespezie-child-theme' ); ?> <input type="date" name="to" value="<?php echo esc_attr( $filters['to'] ); ?>" /></label>
		<label><?php esc_html_e( 'Canale', 'oasidellespezie-child-theme' ); ?>
			<select name="channel">
				<option value=""><?php esc_html_e( 'Tutti', 'oasidellespezie-child-theme' ); ?></option>
				<option value="online" <?php selected( $filters['channel'], 'online' ); ?>><?php esc_html_e( 'Online', 'oasidellespezie-child-theme' ); ?></option>
				<option value="pos" <?php selected( $filters['channel'], 'pos' ); ?>><?php esc_html_e( 'POS', 'oasidellespezie-child-theme' ); ?></option>
			</select>
		</label>
		<button class="button button-primary"><?php esc_html_e( 'Mostra', 'oasidellespezie-child-theme' ); ?></button>
		<a class="button" href="<?php echo esc_url( oasi_lots_report_url( array( 'tab' => 'vendite', 'from' => $prev, 'channel' => $filters['channel'] ) ) ); ?>">&larr; <?php esc_html_e( 'Giorno prima', 'oasidellespezie-child-theme' ); ?></a>
		<a class="button" href="<?php echo esc_url( oasi_lots_report_url( array( 'tab' => 'vendite', 'from' => wp_date( 'Y-m-d' ), 'channel' => $filters['channel'] ) ) ); ?>"><?php esc_html_e( 'Oggi', 'oasidellespezie-child-theme' ); ?></a>
		<a class="button" href="<?php echo esc_url( oasi_lots_report_url( array( 'tab' => 'vendite', 'from' => $next, 'channel' => $filters['channel'] ) ) ); ?>"><?php esc_html_e( 'Giorno dopo', 'oasidellespezie-child-theme' ); ?> &rarr;</a>
	</form>

	<div class="oasi-cards">
		<div class="oasi-card"><?php esc_html_e( 'Ordini', 'oasidellespezie-child-theme' ); ?><strong><?php echo esc_html( (string) $sales['orders'] ); ?></strong></div>
		<div class="oasi-card"><?php esc_html_e( 'Quantità venduta', 'oasidellespezie-child-theme' ); ?><strong><?php echo esc_html( oasi_lots_report_num( $sales['qty'] ) ); ?></strong></div>
		<div class="oasi-card"><?php esc_html_e( 'Incasso IVA incl.', 'oasidellespezie-child-theme' ); ?><strong><?php echo wp_kses_post( wc_price( $sales['revenue'], array( 'currency' => $currency ) ) ); ?></strong></div>
		<?php foreach ( $sales['by_channel'] as $channel => $data ) : ?>
			<?php if ( '' === $filters['channel'] || $channel === $filters['channel'] ) : ?>
				<div class="oasi-card"><?php echo esc_html( oasi_lots_report_channel_label( $channel ) ); ?><strong><?php echo esc_html( (string) $data['orders'] ); ?> &middot; <?php echo wp_kses_post( wc_price( $data['revenue'], array( 'currency' => $currency ) ) ); ?></strong></div>
			<?php endif; ?>
		<?php endforeach; ?>
	</div>

	<table class="widefat striped">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Prodotto', 'oasidellespezie-child-theme' ); ?></th>
				<th><?php esc_html_e( 'SKU', 'oasidellespezie-child-theme' ); ?></th>
				<th><?php esc_html_e( 'Lotto', 'oasidellespezie-child-theme' ); ?></th>
				<th><?php esc_html_e( 'Scadenza', 'oasidellespezie-child-theme' ); ?></th>
				<th class="num"><?php esc_html_e( 'Quantità', 'oasidellespezie-child-theme' ); ?></th>
				<th class="num"><?php esc_html_e( 'Incasso IVA incl.', 'oasidellespezie-child-theme' ); ?></th>
				<th class="num"><?php esc_html_e( 'Ordini', 'oasidellespezie-child-theme' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php if ( array() === $sales['rows'] ) : ?>
				<tr><td colspan="7"><?php esc_html_e( 'Nessuna vendita nel periodo selezionato.', 'oasidellespezie-child-theme' ); ?></td></tr>
			<?php endif; ?>
			<?php foreach ( $sales['rows'] as $row ) : ?>
				<tr>
					<td><?php echo esc_html( $row['product'] ); ?></td>
					<td><?php echo esc_html( $row['sku'] ); ?></td>
					<td><?php echo '' === $row['code'] ? esc_html( $row['lot'] ) : '<a href="' . esc_url( oasi_lots_report_url( array( 'tab' => 'tracciabilita', 'code' => $row['code'] ) ) ) . '">' . esc_html( $row['lot'] ) . '</a>'; ?></td>
					<td><?php echo esc_html( $row['expiry'] ? oasi_lots_format_expiry( $row['expiry'] ) : '' ); ?></td>
					<td class="num"><?php echo esc_html( oasi_lots_report_num( $row['qty'] ) ); ?></td>
					<td class="num"><?php echo wp_kses_post( wc_price( $row['revenue'], array( 'currency' => $currency ) ) ); ?></td>
					<td class="num"><?php echo esc_html( (string) $row['orders'] ); ?></td>
				</tr>
			<?php endforeach; ?>
		</tbody>
		<?php if ( array() !== $sales['rows'] ) : ?>
			<tfoot>
				<tr>
					<td colspan="4"><?php esc_html_e( 'Totale', 'oasidellespezie-child-theme' ); ?></td>
					<td class="num"><?php echo esc_html( oasi_lots_report_num( $sales['qty'] ) ); ?></td>
					<td class="num"><?php echo wp_kses_post( wc_price( $sales['revenue'], array( 'currency' => $currency ) ) ); ?></td>
					<td class="num"><?php echo esc_html( (string) $sales['orders'] ); ?></td>
				</tr>
			</tfoot>
		<?php endif; ?>
	</table>
	<p class="description"><?php esc_html_e( 'Ordini in lavorazione, completati e in attesa, al netto dei rimborsi. La quantità per lotto è quella uscita dal magazzino (per le vendite a peso, i kg).', 'oasidellespezie-child-theme' ); ?></p>
	<?php
}

/**
 * Tab: lots in stock with expiry status.
 *
 * @param array<string, string> $filters Filters.
 */
function oasi_lots_report_render_lots( array $filters ): void {
	$rows = oasi_lots_report_lots( $filters['days'] );
	?>
	<form class="oasi-filters" method="get">
		<?php oasi_lots_report_hidden_fields( 'lotti' ); ?>
		<label><?php esc_html_e( 'Scadenza', 'oasidellespezie-child-theme' ); ?>
			<select name="days">
				<option value=""><?php esc_html_e( 'Tutti i lotti', 'oasidellespezie-child-theme' ); ?></option>
				<option value="scaduti" <?php selected( $filters['days'], 'scaduti' ); ?>><?php esc_html_e( 'Solo scaduti', 'oasidellespezie-child-theme' ); ?></option>
				<?php foreach ( array( '30', '60', '90' ) as $days ) : ?>
					<?php /* translators: %s: number of days. */ ?>
					<option value="<?php echo esc_attr( $days ); ?>" <?php selected( $filters['days'], $days ); ?>><?php echo esc_html( sprintf( __( 'Scaduti o in scadenza entro %s giorni', 'oasidellespezie-child-theme' ), $days ) ); ?></option>
				<?php endforeach; ?>
			</select>
		</label>
		<button class="button button-primary"><?php esc_html_e( 'Mostra', 'oasidellespezie-child-theme' ); ?></button>
	</form>
	<table class="widefat striped">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Prodotto', 'oasidellespezie-child-theme' ); ?></th>
				<th><?php esc_html_e( 'SKU', 'oasidellespezie-child-theme' ); ?></th>
				<th><?php esc_html_e( 'Lotto', 'oasidellespezie-child-theme' ); ?></th>
				<th><?php esc_html_e( 'Scadenza', 'oasidellespezie-child-theme' ); ?></th>
				<th class="num"><?php esc_html_e( 'Quantità', 'oasidellespezie-child-theme' ); ?></th>
				<th><?php esc_html_e( 'Stato', 'oasidellespezie-child-theme' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php if ( array() === $rows ) : ?>
				<tr><td colspan="6"><?php esc_html_e( 'Nessun lotto con quantità residua.', 'oasidellespezie-child-theme' ); ?></td></tr>
			<?php endif; ?>
			<?php foreach ( $rows as $row ) : ?>
				<tr>
					<td><a href="<?php echo esc_url( $row['edit_url'] ); ?>"><?php echo esc_html( $row['product'] ); ?></a></td>
					<td><?php echo esc_html( $row['sku'] ); ?></td>
					<td><a href="<?php echo esc_url( oasi_lots_report_url( array( 'tab' => 'tracciabilita', 'code' => $row['code'] ) ) ); ?>"><?php echo esc_html( '' !== $row['code'] ? $row['code'] : __( '(senza codice)', 'oasidellespezie-child-theme' ) ); ?></a></td>
					<td><?php echo esc_html( $row['expiry'] ? oasi_lots_format_expiry( $row['expiry'] ) : '' ); ?></td>
					<td class="num"><?php echo esc_html( oasi_lots_report_num( $row['qty'] ) ); ?></td>
					<td><span class="oasi-status oasi-status--<?php echo esc_attr( $row['status']['key'] ); ?>"><?php echo esc_html( $row['status']['label'] ); ?></span></td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	<?php
}

/**
 * Tab: consistency checks.
 */
function oasi_lots_report_render_checks(): void {
	$mismatches = oasi_lots_report_mismatches();
	$without    = oasi_lots_report_without_lot();
	?>
	<h2><?php esc_html_e( 'Magazzino diverso dalla somma dei lotti', 'oasidellespezie-child-theme' ); ?></h2>
	<p class="description"><?php esc_html_e( 'Succede quando la giacenza viene cambiata fuori dai lotti (import, OpenPOS, modifica diretta) o quando si vende più di quanto c’è nei lotti. Aprendo il prodotto e salvando i lotti, la giacenza torna uguale alla somma.', 'oasidellespezie-child-theme' ); ?></p>
	<table class="widefat striped">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Prodotto', 'oasidellespezie-child-theme' ); ?></th>
				<th><?php esc_html_e( 'SKU', 'oasidellespezie-child-theme' ); ?></th>
				<th class="num"><?php esc_html_e( 'Magazzino', 'oasidellespezie-child-theme' ); ?></th>
				<th class="num"><?php esc_html_e( 'Somma lotti', 'oasidellespezie-child-theme' ); ?></th>
				<th class="num"><?php esc_html_e( 'Differenza', 'oasidellespezie-child-theme' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php if ( array() === $mismatches ) : ?>
				<tr><td colspan="5"><?php esc_html_e( 'Tutto torna: nessuna differenza.', 'oasidellespezie-child-theme' ); ?></td></tr>
			<?php endif; ?>
			<?php foreach ( $mismatches as $row ) : ?>
				<tr>
					<td><a href="<?php echo esc_url( $row['edit_url'] ); ?>"><?php echo esc_html( $row['product'] ); ?></a></td>
					<td><?php echo esc_html( $row['sku'] ); ?></td>
					<td class="num"><?php echo esc_html( oasi_lots_report_num( $row['stock'] ) ); ?></td>
					<td class="num"><?php echo esc_html( oasi_lots_report_num( $row['lots'] ) ); ?></td>
					<td class="num"><?php echo esc_html( oasi_lots_report_num( $row['diff'] ) ); ?></td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>

	<h2><?php esc_html_e( 'Vendite senza lotto disponibile', 'oasidellespezie-child-theme' ); ?></h2>
	<p class="description"><?php esc_html_e( 'Righe d’ordine in cui i lotti non bastavano: la merce è uscita senza un lotto assegnato (ultime 200).', 'oasidellespezie-child-theme' ); ?></p>
	<?php oasi_lots_report_render_lines( $without, __( 'Nessuna vendita senza lotto.', 'oasidellespezie-child-theme' ) ); ?>
	<?php
}

/**
 * Tab: traceability of one lot code.
 *
 * @param array<string, string> $filters Filters.
 */
function oasi_lots_report_render_trace( array $filters ): void {
	?>
	<form class="oasi-filters" method="get">
		<?php oasi_lots_report_hidden_fields( 'tracciabilita' ); ?>
		<label><?php esc_html_e( 'Codice lotto', 'oasidellespezie-child-theme' ); ?> <input type="search" name="code" value="<?php echo esc_attr( $filters['code'] ); ?>" required /></label>
		<button class="button button-primary"><?php esc_html_e( 'Cerca', 'oasidellespezie-child-theme' ); ?></button>
	</form>
	<?php
	if ( '' === $filters['code'] ) {
		echo '<p>' . esc_html__( 'Inserisci un codice lotto per vedere in quali ordini è uscito, con cliente e quantità.', 'oasidellespezie-child-theme' ) . '</p>';
		return;
	}

	$rows  = oasi_lots_report_trace( $filters['code'] );
	$total = oasi_lots_total( $rows );
	?>
	<div class="oasi-cards">
		<div class="oasi-card"><?php esc_html_e( 'Righe d’ordine', 'oasidellespezie-child-theme' ); ?><strong><?php echo esc_html( (string) count( $rows ) ); ?></strong></div>
		<div class="oasi-card"><?php esc_html_e( 'Quantità uscita', 'oasidellespezie-child-theme' ); ?><strong><?php echo esc_html( oasi_lots_report_num( $total ) ); ?></strong></div>
	</div>
	<?php
	/* translators: %s: lot code. */
	oasi_lots_report_render_lines( $rows, sprintf( __( 'Nessun ordine con il lotto %s.', 'oasidellespezie-child-theme' ), $filters['code'] ) );
}

/**
 * Table of order lines (traceability and checks).
 *
 * @param array<int, array<string, mixed>> $rows  Lines.
 * @param string                           $empty Message when empty.
 */
function oasi_lots_report_render_lines( array $rows, string $empty ): void {
	?>
	<table class="widefat striped">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Data', 'oasidellespezie-child-theme' ); ?></th>
				<th><?php esc_html_e( 'Ordine', 'oasidellespezie-child-theme' ); ?></th>
				<th><?php esc_html_e( 'Canale', 'oasidellespezie-child-theme' ); ?></th>
				<th><?php esc_html_e( 'Cliente', 'oasidellespezie-child-theme' ); ?></th>
				<th><?php esc_html_e( 'Prodotto', 'oasidellespezie-child-theme' ); ?></th>
				<th><?php esc_html_e( 'Lotto', 'oasidellespezie-child-theme' ); ?></th>
				<th class="num"><?php esc_html_e( 'Quantità', 'oasidellespezie-child-theme' ); ?></th>
				<th><?php esc_html_e( 'Stato', 'oasidellespezie-child-theme' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php if ( array() === $rows ) : ?>
				<tr><td colspan="8"><?php echo esc_html( $empty ); ?></td></tr>
			<?php endif; ?>
			<?php foreach ( $rows as $row ) : ?>
				<tr>
					<td><?php echo esc_html( $row['date'] ); ?></td>
					<td><a href="<?php echo esc_url( $row['edit_url'] ); ?>">#<?php echo esc_html( (string) $row['order'] ); ?></a></td>
					<td><?php echo esc_html( $row['channel'] ); ?></td>
					<td><?php echo esc_html( $row['customer'] ); ?><?php echo $row['email'] ? '<br><span class="description">' . esc_html( $row['email'] ) . '</span>' : ''; ?></td>
					<td><?php echo esc_html( $row['product'] ); ?></td>
					<td><?php echo esc_html( $row['lot'] . ( $row['expiry'] ? ' (' . oasi_lots_format_expiry( $row['expiry'] ) . ')' : '' ) ); ?></td>
					<td class="num"><?php echo esc_html( oasi_lots_report_num( $row['qty'] ) ); ?></td>
					<td><?php echo esc_html( $row['status'] ); ?></td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	<?php
}

/*
 * -------------------------------------------------------------------------
 * Scheda Magazzino: tutte le giacenze con i lotti, modificabili in blocco.
 * -------------------------------------------------------------------------
 */

const OASI_LOTS_STOCK_PER_PAGE = 50;

/**
 * Stock owners (simple products, variations and parents with their own stock) for the bulk page.
 *
 * @param array<string, string> $filters  Filters (q, show, paged).
 * @param bool                  $paginate Limit to one page.
 * @return array{ids: array<int, int>, total: int}
 */
function oasi_lots_report_stock_items( array $filters, bool $paginate = true ): array {
	global $wpdb;

	$where  = array(
		"p.post_type IN ('product', 'product_variation')",
		"p.post_status IN ('publish', 'private')",
		"( p.post_parent = 0 OR parent.post_status IN ('publish', 'private') )",
		"ms.meta_value = 'yes'",
	);
	$params = array();

	if ( '' !== $filters['q'] ) {
		$like     = '%' . $wpdb->esc_like( $filters['q'] ) . '%';
		$where[]  = '( p.post_title LIKE %s OR sku.meta_value LIKE %s OR parent.post_title LIKE %s )';
		$params[] = $like;
		$params[] = $like;
		$params[] = $like;
	}

	if ( 'con' === $filters['show'] ) {
		$where[] = 'lots.meta_id IS NOT NULL';
	} elseif ( 'senza' === $filters['show'] ) {
		$where[] = 'lots.meta_id IS NULL';
	} elseif ( 'senza-giacenza' === $filters['show'] ) {
		$where[] = 'lots.meta_id IS NULL AND CAST(st.meta_value AS DECIMAL(12,4)) > 0';
	}

	$from = "FROM {$wpdb->posts} p
		LEFT JOIN {$wpdb->posts} parent ON parent.ID = p.post_parent
		INNER JOIN {$wpdb->postmeta} ms ON ms.post_id = p.ID AND ms.meta_key = '_manage_stock'
		LEFT JOIN {$wpdb->postmeta} st ON st.post_id = p.ID AND st.meta_key = '_stock'
		LEFT JOIN {$wpdb->postmeta} sku ON sku.post_id = p.ID AND sku.meta_key = '_sku'
		LEFT JOIN {$wpdb->postmeta} lots ON lots.post_id = p.ID AND lots.meta_key = '" . OASI_LOTS_META . "'
		WHERE " . implode( ' AND ', $where );

	$count_sql = "SELECT COUNT(DISTINCT p.ID) {$from}";
	$ids_sql   = "SELECT DISTINCT p.ID, COALESCE(parent.post_title, p.post_title) AS sort_title, p.post_title {$from} ORDER BY sort_title ASC, p.post_title ASC";

	if ( $paginate ) {
		$ids_sql .= $wpdb->prepare( ' LIMIT %d OFFSET %d', OASI_LOTS_STOCK_PER_PAGE, ( (int) $filters['paged'] - 1 ) * OASI_LOTS_STOCK_PER_PAGE );
	}

	// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared -- fragments are static, values go through prepare().
	$total = (int) $wpdb->get_var( $params ? $wpdb->prepare( $count_sql, $params ) : $count_sql );
	$rows  = $wpdb->get_col( $params ? $wpdb->prepare( $ids_sql, $params ) : $ids_sql );
	// phpcs:enable

	return array(
		'ids'   => array_map( 'intval', $rows ),
		'total' => $total,
	);
}

/**
 * Save the lots edited on the bulk page (only rows the user touched).
 */
function oasi_lots_report_save_stock(): void {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		wp_die( esc_html__( 'Permesso negato.', 'oasidellespezie-child-theme' ), 403 );
	}
	check_admin_referer( 'oasi_lots_bulk_save' );

	$posted  = isset( $_POST['oasi_lots'] ) && is_array( $_POST['oasi_lots'] ) ? $_POST['oasi_lots'] : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized per field in oasi_lots_parse_posted().
	$saved   = 0;
	$skipped = 0;

	foreach ( $posted as $product_id => $data ) {
		$product_id = (int) $product_id;
		if ( $product_id <= 0 || ! is_array( $data ) || '1' !== (string) ( $data['dirty'] ?? '0' ) ) {
			continue;
		}

		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			continue;
		}

		// A sale changed these lots after the page was loaded: do not overwrite it.
		if ( oasi_lots_fingerprint( oasi_lots_get( $product_id, true ) ) !== sanitize_text_field( wp_unslash( (string) ( $data['fingerprint'] ?? '' ) ) ) ) {
			++$skipped;
			continue;
		}

		$total = oasi_lots_save_posted( $product_id );
		++$saved;

		if ( null === $total ) {
			// All rows removed: lots deleted, stock left as it is.
			continue;
		}

		if ( $product->managing_stock() && (int) $product->get_stock_managed_by_id() === $product_id ) {
			wc_update_product_stock( $product, $total, 'set' );
		}
	}

	$back = wp_get_referer() ?: oasi_lots_report_url( array( 'tab' => 'magazzino' ) );
	wp_safe_redirect( add_query_arg( array( 'saved' => $saved, 'skipped' => $skipped ), $back ) );
	exit;
}
add_action( 'admin_post_oasi_lots_bulk_save', 'oasi_lots_report_save_stock' );

/**
 * Tab: every stock item with its lots, editable in bulk.
 *
 * @param array<string, string> $filters Filters.
 */
function oasi_lots_report_render_stock( array $filters ): void {
	$result = oasi_lots_report_stock_items( $filters );
	$pages  = max( 1, (int) ceil( $result['total'] / OASI_LOTS_STOCK_PER_PAGE ) );

	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- display-only result of the redirect.
	if ( isset( $_GET['saved'] ) ) {
		$saved   = absint( $_GET['saved'] );
		$skipped = absint( $_GET['skipped'] ?? 0 );
		printf(
			'<div class="notice notice-%s is-dismissible"><p>%s</p></div>',
			$skipped ? 'warning' : 'success',
			esc_html(
				sprintf(
					/* translators: 1: saved products, 2: skipped products. */
					__( 'Lotti salvati per %1$d prodotti.%2$s', 'oasidellespezie-child-theme' ),
					$saved,
					$skipped ? ' ' . sprintf( __( '%d non salvati perché una vendita li ha modificati nel frattempo: ricontrollali.', 'oasidellespezie-child-theme' ), $skipped ) : ''
				)
			)
		);
	}
	// phpcs:enable
	?>
	<form class="oasi-filters" method="get">
		<?php oasi_lots_report_hidden_fields( 'magazzino' ); ?>
		<label><?php esc_html_e( 'Cerca prodotto o SKU', 'oasidellespezie-child-theme' ); ?> <input type="search" name="q" value="<?php echo esc_attr( $filters['q'] ); ?>" /></label>
		<label><?php esc_html_e( 'Mostra', 'oasidellespezie-child-theme' ); ?>
			<select name="show">
				<option value=""><?php esc_html_e( 'Tutti', 'oasidellespezie-child-theme' ); ?></option>
				<option value="senza-giacenza" <?php selected( $filters['show'], 'senza-giacenza' ); ?>><?php esc_html_e( 'In magazzino senza lotti', 'oasidellespezie-child-theme' ); ?></option>
				<option value="senza" <?php selected( $filters['show'], 'senza' ); ?>><?php esc_html_e( 'Tutti quelli senza lotti', 'oasidellespezie-child-theme' ); ?></option>
				<option value="con" <?php selected( $filters['show'], 'con' ); ?>><?php esc_html_e( 'Con lotti', 'oasidellespezie-child-theme' ); ?></option>
			</select>
		</label>
		<button class="button button-primary"><?php esc_html_e( 'Filtra', 'oasidellespezie-child-theme' ); ?></button>
		<span class="description">
			<?php
			/* translators: %d: number of items. */
			echo esc_html( sprintf( _n( '%d articolo', '%d articoli', $result['total'], 'oasidellespezie-child-theme' ), $result['total'] ) );
			?>
		</span>
	</form>

	<p class="description"><?php esc_html_e( 'Per ogni articolo si possono aggiungere o correggere i lotti. Agli articoli in magazzino senza lotti è già proposta una riga con la giacenza attuale: basta inserire codice e scadenza. Vengono salvati solo gli articoli modificati (bordo giallo); la giacenza diventa la somma dei lotti.', 'oasidellespezie-child-theme' ); ?></p>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="oasi-stock-form">
		<input type="hidden" name="action" value="oasi_lots_bulk_save" />
		<?php wp_nonce_field( 'oasi_lots_bulk_save' ); ?>
		<p><button class="button button-primary"><?php esc_html_e( 'Salva lotti modificati', 'oasidellespezie-child-theme' ); ?></button></p>
		<table class="widefat striped oasi-stock-table">
			<thead>
				<tr>
					<th style="width:28%"><?php esc_html_e( 'Prodotto', 'oasidellespezie-child-theme' ); ?></th>
					<th style="width:10%"><?php esc_html_e( 'SKU', 'oasidellespezie-child-theme' ); ?></th>
					<th class="num" style="width:8%"><?php esc_html_e( 'Giacenza', 'oasidellespezie-child-theme' ); ?></th>
					<th><?php esc_html_e( 'Lotti', 'oasidellespezie-child-theme' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php if ( array() === $result['ids'] ) : ?>
					<tr><td colspan="4"><?php esc_html_e( 'Nessun articolo con gestione magazzino corrisponde ai filtri.', 'oasidellespezie-child-theme' ); ?></td></tr>
				<?php endif; ?>
				<?php
				foreach ( $result['ids'] as $product_id ) :
					$product = wc_get_product( $product_id );
					if ( ! $product ) {
						continue;
					}
					$stock = (float) $product->get_stock_quantity();
					$total = oasi_lots_total( oasi_lots_get( $product_id ) );
					$lots  = array() !== oasi_lots_get( $product_id );
					?>
					<tr>
						<td>
							<a href="<?php echo esc_url( (string) get_edit_post_link( $product->get_parent_id() ?: $product_id, 'raw' ) ); ?>"><?php echo esc_html( wp_strip_all_tags( $product->get_name() ) ); ?></a>
							<?php if ( $lots && oasi_lots_qty( $stock ) !== $total ) : ?>
								<br><span class="oasi-status oasi-status--expired">
									<?php
									/* translators: %s: total in lots. */
									echo esc_html( sprintf( __( 'i lotti sommano %s', 'oasidellespezie-child-theme' ), oasi_lots_report_num( $total ) ) );
									?>
								</span>
							<?php endif; ?>
						</td>
						<td><?php echo esc_html( (string) $product->get_sku() ); ?></td>
						<td class="num"><?php echo esc_html( oasi_lots_report_num( $stock ) ); ?></td>
						<td><?php oasi_lots_render_editor( $product_id, $stock, true ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<p><button class="button button-primary"><?php esc_html_e( 'Salva lotti modificati', 'oasidellespezie-child-theme' ); ?></button></p>
	</form>

	<?php if ( $pages > 1 ) : ?>
		<div class="tablenav"><div class="tablenav-pages">
			<?php
			echo wp_kses_post(
				paginate_links(
					array(
						'base'    => oasi_lots_report_url( array( 'tab' => 'magazzino', 'q' => $filters['q'], 'show' => $filters['show'] ) ) . '&paged=%#%',
						'format'  => '',
						'current' => (int) $filters['paged'],
						'total'   => $pages,
					)
				)
			);
			?>
		</div></div>
	<?php endif; ?>
	<script>
	( function () {
		var form = document.querySelector( '.oasi-stock-form' );
		if ( ! form ) { return; }
		var submitting = false;
		form.addEventListener( 'submit', function () { submitting = true; } );
		window.addEventListener( 'beforeunload', function ( event ) {
			if ( ! submitting && form.querySelector( '.oasi-lots.is-dirty' ) ) { event.preventDefault(); event.returnValue = ''; }
		} );
	}() );
	</script>
	<?php
}
