<?php
/**
 * Footer data resolvers for Oasi delle Spezie.
 *
 * All customer-facing payment marks are derived from enabled WooCommerce
 * gateways. Brand assets come from the gateway plugins already installed.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Group consecutive days that share the same CMS opening hours.
 *
 * The input is already normalized by oasi_get_contact_data(). Keeping the
 * grouping here lets the footer show every configured slot without creating
 * another source of truth for the schedule.
 *
 * @param array<string, array{label?: string, hours?: string}> $days Ordered day data.
 * @return array<int, array{label: string, hours: string}>
 */
function oasi_footer_group_opening_hours( array $days ): array {
	$groups = array();

	foreach ( $days as $day ) {
		$label = trim( (string) ( $day['label'] ?? '' ) );
		$hours = trim( (string) ( $day['hours'] ?? '' ) );

		if ( '' === $label || '' === $hours ) {
			continue;
		}

		$last_index = array_key_last( $groups );
		if ( null !== $last_index && $groups[ $last_index ]['hours'] === $hours ) {
			$groups[ $last_index ]['last_label'] = $label;
			continue;
		}

		$groups[] = array(
			'first_label' => $label,
			'last_label'  => $label,
			'hours'       => $hours,
		);
	}

	return array_map(
		static function ( array $group ): array {
			$label = $group['first_label'];
			if ( $group['first_label'] !== $group['last_label'] ) {
				$label .= '–' . $group['last_label'];
			}

			return array(
				'label' => $label,
				'hours' => $group['hours'],
			);
		},
		$groups
	);
}

/**
 * Resolve the fallback quick links through real WordPress pages.
 *
 * The assigned `menu-2` WordPress menu remains the primary source in the
 * template; this list is used only when no footer menu is assigned.
 *
 * @return array<int, array{label:string,url:string}>
 */
function oasi_footer_get_quick_links(): array {
	$definitions = array(
		array( 'label' => __( 'Home', 'oasidellespezie-child-theme' ), 'slug' => '' ),
		array( 'label' => __( 'Chi siamo', 'oasidellespezie-child-theme' ), 'slug' => 'chi-siamo' ),
		array( 'label' => __( 'Novità', 'oasidellespezie-child-theme' ), 'slug' => 'scoprite-le-nostre-novita' ),
		array( 'label' => __( 'Professionista', 'oasidellespezie-child-theme' ), 'slug' => 'catalogo-professionista' ),
		array( 'label' => __( 'Contatto', 'oasidellespezie-child-theme' ), 'slug' => 'contatto' ),
	);

	return array_map(
		static function ( array $definition ): array {
			if ( '' === $definition['slug'] ) {
				return array( 'label' => $definition['label'], 'url' => home_url( '/' ) );
			}

			$page = get_page_by_path( $definition['slug'], OBJECT, 'page' );
			$url  = $page instanceof WP_Post && 'publish' === $page->post_status ? get_permalink( $page ) : '';

			return array(
				'label' => $definition['label'],
				'url'   => $url ? (string) $url : home_url( '/' . $definition['slug'] . '/' ),
			);
		},
		$definitions
	);
}

/**
 * Return enabled WooCommerce gateways without depending on checkout context.
 *
 * @return array<string, object>
 */
function oasi_footer_get_enabled_gateways(): array {
	if ( ! function_exists( 'WC' ) || ! WC() || ! is_callable( array( WC(), 'payment_gateways' ) ) ) {
		return array();
	}

	try {
		$manager  = WC()->payment_gateways();
		$gateways = $manager && is_callable( array( $manager, 'payment_gateways' ) ) ? $manager->payment_gateways() : array();
	} catch ( Throwable $exception ) {
		return array();
	}

	return array_filter(
		is_array( $gateways ) ? $gateways : array(),
		static function ( $gateway ): bool {
			return is_object( $gateway ) && isset( $gateway->id, $gateway->enabled ) && 'yes' === $gateway->enabled;
		}
	);
}

/**
 * Extract the first official image exposed by a gateway, when available.
 */
function oasi_footer_get_gateway_icon_url( object $gateway ): string {
	if ( ! is_callable( array( $gateway, 'get_icon' ) ) ) {
		return '';
	}

	$icon_html = (string) $gateway->get_icon();
	if ( preg_match( '/<img[^>]+src=["\']([^"\']+)["\']/i', $icon_html, $match ) ) {
		return esc_url_raw( html_entity_decode( $match[1], ENT_QUOTES, 'UTF-8' ) );
	}

	return '';
}

/**
 * Resolve the official payment marks for currently enabled gateways.
 *
 * Stripe is intentionally never presented as a customer payment method. The
 * card networks and wallets actually configured through it are shown instead.
 *
 * @return array<int, array{key:string,label:string,icon:string,class:string}>
 */
function oasi_footer_get_payment_methods(): array {
	// Building the gateways loads every payment plugin (Stripe, WCPay, PostFinance):
	// WooCommerce normally does that only on cart/checkout, but the footer is on every
	// page. Cache the resulting logo list; it changes only when payment settings do.
	$can_cache = function_exists( 'get_transient' ) && function_exists( 'set_transient' );
	$cached    = $can_cache ? get_transient( 'oasi_footer_payment_methods' ) : false;
	if ( is_array( $cached ) ) {
		return $cached;
	}

	$methods = oasi_footer_build_payment_methods();
	if ( $can_cache ) {
		set_transient( 'oasi_footer_payment_methods', $methods, 12 * HOUR_IN_SECONDS );
	}

	return $methods;
}

/**
 * Forget the cached payment logos when any WooCommerce payment setting changes.
 *
 * @param string $option Option name.
 */
function oasi_footer_flush_payment_methods( string $option ): void {
	if ( str_starts_with( $option, 'woocommerce_' ) && str_ends_with( $option, '_settings' ) ) {
		delete_transient( 'oasi_footer_payment_methods' );
	}
}
if ( function_exists( 'add_action' ) ) {
	add_action( 'updated_option', 'oasi_footer_flush_payment_methods' );
	add_action( 'added_option', 'oasi_footer_flush_payment_methods' );
}

/**
 * Build the payment logo list from the enabled gateways (uncached).
 *
 * @return array<int, array{key:string,label:string,icon:string,class:string}>
 */
function oasi_footer_build_payment_methods(): array {
	$gateways       = oasi_footer_get_enabled_gateways();
	$stripe_asset   = static fn( string $file ): string => plugins_url( 'woo-stripe-payment/assets/img/' . ltrim( $file, '/' ) );
	$payments_asset = static fn( string $file ): string => plugins_url( 'woocommerce-payments/assets/images/' . ltrim( $file, '/' ) );
	$methods        = array();
	$card_definitions = array(
		'visa'            => array( 'Visa', 'cards/visa.svg' ),
		'mastercard'      => array( 'Mastercard', 'cards/mastercard.svg' ),
		'amex'            => array( 'American Express', 'cards/amex.svg' ),
		'discover'        => array( 'Discover', 'cards/discover.svg' ),
		'diners'          => array( 'Diners Club', 'cards/diners.svg' ),
		'jcb'             => array( 'JCB', 'cards/jcb.svg' ),
		'maestro'         => array( 'Maestro', 'cards/maestro.svg' ),
		'china_union_pay' => array( 'UnionPay', 'cards/china_union_pay.svg' ),
	);

	$add = static function ( string $key, string $label, string $icon, string $class = '' ) use ( &$methods ): void {
		if ( '' === $icon || isset( $methods[ $key ] ) ) {
			return;
		}
		$methods[ $key ] = array( 'key' => $key, 'label' => $label, 'icon' => $icon, 'class' => $class );
	};

	foreach ( $gateways as $gateway ) {
		$gateway_id    = strtolower( (string) $gateway->id );
		$gateway_title = strtolower( wp_strip_all_tags( (string) ( $gateway->title ?? '' ) ) );

		if ( 'stripe_cc' === $gateway_id ) {
			$cards = is_callable( array( $gateway, 'get_option' ) )
				? (array) $gateway->get_option( 'card_icons', array( 'visa', 'mastercard' ) )
				: array( 'visa', 'mastercard' );
			foreach ( $cards as $card ) {
				if ( isset( $card_definitions[ $card ] ) ) {
					$add( $card, $card_definitions[ $card ][0], $stripe_asset( $card_definitions[ $card ][1] ), 'oasi-footer__payment-logo--card' );
				}
			}
			if ( is_callable( array( $gateway, 'get_option' ) ) && 'yes' === $gateway->get_option( 'link_enabled', 'no' ) ) {
				$add( 'link', 'Link', $stripe_asset( 'link.svg' ), 'oasi-footer__payment-logo--wide' );
			}
		}

		if ( in_array( $gateway_id, array( 'woocommerce_payments', 'woocommerce_payments_cc' ), true ) ) {
			$add( 'visa', 'Visa', $payments_asset( 'payment-method-icons/visa.svg' ), 'oasi-footer__payment-logo--card' );
			$add( 'mastercard', 'Mastercard', $payments_asset( 'payment-method-icons/mastercard.svg' ), 'oasi-footer__payment-logo--card' );
		}

		if ( str_contains( $gateway_id, 'twint' ) || str_contains( $gateway_title, 'twint' ) ) {
			$add( 'twint', 'TWINT', $stripe_asset( 'twint.svg' ), 'oasi-footer__payment-logo--twint' );
		}

		if ( str_contains( $gateway_id, 'applepay' ) || str_contains( $gateway_title, 'apple pay' ) ) {
			$add( 'applepay', 'Apple Pay', $stripe_asset( 'applepay.svg' ), 'oasi-footer__payment-logo--wide' );
		}

		if ( 'stripe_link_checkout' === $gateway_id || str_contains( $gateway_title, 'link checkout' ) ) {
			$add( 'link', 'Link', $stripe_asset( 'link.svg' ), 'oasi-footer__payment-logo--wide' );
		}

		if ( str_contains( $gateway_id, 'postfinance' ) || str_contains( $gateway_title, 'postfinance' ) ) {
			$add( 'postfinance', 'PostFinance', oasi_footer_get_gateway_icon_url( $gateway ), 'oasi-footer__payment-logo--wide' );
		}
	}

	return array_values( $methods );
}
