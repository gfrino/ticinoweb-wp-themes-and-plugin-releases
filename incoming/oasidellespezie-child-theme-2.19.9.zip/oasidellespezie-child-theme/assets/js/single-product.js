/**
 * Single Product Interactive Behaviors — Oasi delle Spezie
 *
 * Handles:
 * 1. Image gallery thumbnail switcher with smooth transition
 * 2. Quantity stepper buttons (- / +)
 * 3. Synchronization with WooCommerce variations form
 *
 * @package OasiDelleSpezieChild
 */

(function () {
	'use strict';

	window.OasiSingleProductLoaded = true;

	function init() {
		initGallerySwitcher();
		initQuantitySteppers();
		initVariationSync();

		// Reinforce stepper after WooCommerce variation scripts initialize
		setTimeout(initQuantitySteppers, 150);
		setTimeout(initQuantitySteppers, 450);
	}

	window.initQuantitySteppers = initQuantitySteppers;

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}

	/* ==========================================================================
	   1. Image Gallery Thumbnail Switcher
	   ========================================================================== */
	function initGallerySwitcher() {
		var gallery = document.querySelector('[data-oasi-gallery]');
		if (!gallery) return;

		var mainImg = document.getElementById('oasi-product-main-img');
		var stage = gallery.querySelector('.oasi-product-media__stage');
		var thumbBtns = gallery.querySelectorAll('.oasi-product-media__thumb-btn');

		if (!mainImg || !stage || thumbBtns.length === 0) return;

		thumbBtns.forEach(function (btn) {
			btn.addEventListener('click', function (e) {
				e.preventDefault();

				var largeUrl = btn.getAttribute('data-large-url');
				var largeSrcset = btn.getAttribute('data-large-srcset');
				var largeAlt = btn.getAttribute('data-large-alt');

				if (!largeUrl || btn.classList.contains('is-active')) return;

				// Update active state
				thumbBtns.forEach(function (b) {
					b.classList.remove('is-active');
					b.setAttribute('aria-selected', 'false');
				});
				btn.classList.add('is-active');
				btn.setAttribute('aria-selected', 'true');

				// Smooth image cross-fade
				stage.classList.add('is-switching');
				setTimeout(function () {
					mainImg.src = largeUrl;
					if (largeSrcset) {
						mainImg.srcset = largeSrcset;
					} else {
						mainImg.removeAttribute('srcset');
					}
					if (largeAlt) {
						mainImg.alt = largeAlt;
					}
					stage.classList.remove('is-switching');
				}, 120);
			});
		});
	}

	/* ==========================================================================
	   2. Quantity Stepper Controls (- / +)
	   ========================================================================== */
	function initQuantitySteppers() {
		var qtyWrappers = document.querySelectorAll('.oasi-purchase-card .quantity');

		qtyWrappers.forEach(function (wrap) {
			if (wrap.closest('.oasi-qty-stepper')) return;

			var input = wrap.querySelector('input.qty');
			if (!input) return;

			// Create stepper container
			var stepper = document.createElement('div');
			stepper.className = 'oasi-qty-stepper';

			var minusBtn = document.createElement('button');
			minusBtn.type = 'button';
			minusBtn.className = 'oasi-qty-stepper__btn oasi-qty-stepper__btn--minus';
			minusBtn.innerHTML = '&minus;';
			minusBtn.setAttribute('aria-label', 'Riduci quantità');

			var plusBtn = document.createElement('button');
			plusBtn.type = 'button';
			plusBtn.className = 'oasi-qty-stepper__btn oasi-qty-stepper__btn--plus';
			plusBtn.innerHTML = '&plus;';
			plusBtn.setAttribute('aria-label', 'Aumenta quantità');

			// Reorganize DOM
			wrap.parentNode.insertBefore(stepper, wrap);
			stepper.appendChild(minusBtn);
			stepper.appendChild(wrap);
			stepper.appendChild(plusBtn);

			minusBtn.addEventListener('click', function () {
				var val = parseFloat(input.value) || 1;
				var min = parseFloat(input.getAttribute('min')) || 1;
				var step = parseFloat(input.getAttribute('step')) || 1;
				if (val > min) {
					input.value = Math.max(min, val - step);
					triggerChangeEvent(input);
				}
			});

			plusBtn.addEventListener('click', function () {
				var val = parseFloat(input.value) || 1;
				var max = parseFloat(input.getAttribute('max')) || 9999;
				var step = parseFloat(input.getAttribute('step')) || 1;
				if (val < max) {
					input.value = Math.min(max, val + step);
					triggerChangeEvent(input);
				}
			});
		});

		function triggerChangeEvent(el) {
			var event = new Event('change', { bubbles: true });
			el.dispatchEvent(event);
		}
	}

	/* ==========================================================================
	   3. Synchronization with WooCommerce Variations
	   ========================================================================== */
	function initVariationSync() {
		if (typeof jQuery === 'undefined') return;

		jQuery(document).on('show_variation', function (event, variation) {
			var mainImg = document.getElementById('oasi-product-main-img');
			var stage = document.querySelector('.oasi-product-media__stage');

			if (variation && variation.image && variation.image.src && mainImg && stage) {
				stage.classList.add('is-switching');
				setTimeout(function () {
					mainImg.src = variation.image.src;
					if (variation.image.srcset) {
						mainImg.srcset = variation.image.srcset;
					}
					if (variation.image.alt) {
						mainImg.alt = variation.image.alt;
					}
					stage.classList.remove('is-switching');
				}, 100);
			}

			// Ensure stepper is attached to newly revealed/updated quantity input
			setTimeout(initQuantitySteppers, 50);
		});

		jQuery(document).on('woocommerce_variation_has_changed hide_variation wc_variation_form check_variations', function () {
			setTimeout(initQuantitySteppers, 50);
		});
	}
})();
