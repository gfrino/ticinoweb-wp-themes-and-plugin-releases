/**
 * Compact Chi siamo interactions: accessible laboratory tabs and restrained reveals.
 */
(function () {
	'use strict';

	var page = document.querySelector('.oasi-about');
	if (!page) {
		return;
	}

	var reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

	function initLaboratory() {
		var laboratory = page.querySelector('[data-oasi-lab]');
		if (!laboratory) {
			return;
		}

		var tabs = Array.prototype.slice.call(laboratory.querySelectorAll('[role="tab"]'));
		var panels = Array.prototype.slice.call(laboratory.querySelectorAll('[data-oasi-lab-panel]'));
		var image = laboratory.querySelector('.oasi-lab__image');
		var imageTimer = 0;

		function activateLabPanel(nextIndex, moveFocus) {
			if (!tabs[nextIndex] || !panels[nextIndex]) {
				return;
			}

			tabs.forEach(function (tab, index) {
				var active = index === nextIndex;
				tab.classList.toggle('is-active', active);
				tab.setAttribute('aria-selected', active ? 'true' : 'false');
				tab.tabIndex = active ? 0 : -1;
				panels[index].classList.toggle('is-active', active);
				panels[index].hidden = !active;
			});

			if (moveFocus) {
				tabs[nextIndex].focus();
			}

			if (!image || !tabs[nextIndex].dataset.oasiLabImage || image.src === tabs[nextIndex].dataset.oasiLabImage) {
				return;
			}

			window.clearTimeout(imageTimer);
			image.classList.add('is-switching');
			imageTimer = window.setTimeout(function () {
				image.src = tabs[nextIndex].dataset.oasiLabImage;
				image.srcset = tabs[nextIndex].dataset.oasiLabSrcset || '';
				image.alt = tabs[nextIndex].dataset.oasiLabAlt || '';
				image.classList.remove('is-switching');
			}, reducedMotion ? 0 : 140);
		}

		laboratory.classList.add('is-enhanced');
		activateLabPanel(0, false);

		tabs.forEach(function (tab, index) {
			tab.addEventListener('click', function () {
				activateLabPanel(index, false);
			});

			tab.addEventListener('keydown', function (event) {
				var nextIndex = index;
				if ('ArrowRight' === event.key || 'ArrowDown' === event.key) {
					nextIndex = (index + 1) % tabs.length;
				} else if ('ArrowLeft' === event.key || 'ArrowUp' === event.key) {
					nextIndex = (index - 1 + tabs.length) % tabs.length;
				} else if ('Home' === event.key) {
					nextIndex = 0;
				} else if ('End' === event.key) {
					nextIndex = tabs.length - 1;
				} else {
					return;
				}

				event.preventDefault();
				activateLabPanel(nextIndex, true);
			});
		});
	}

	function initReveals() {
		var elements = Array.prototype.slice.call(page.querySelectorAll('.oasi-reveal'));
		if (reducedMotion || !('IntersectionObserver' in window)) {
			elements.forEach(function (element) {
				element.classList.add('is-visible');
			});
			return;
		}

		page.classList.add('oasi-about-motion-ready');
		var observer = new IntersectionObserver(function (entries) {
			entries.forEach(function (entry) {
				if (!entry.isIntersecting) {
					return;
				}

				entry.target.classList.add('is-visible');
				observer.unobserve(entry.target);
			});
		}, {
			rootMargin: '0px 0px -7% 0px',
			threshold: 0.1
		});

		elements.forEach(function (element) {
			observer.observe(element);
		});
	}

	initLaboratory();
	initReveals();
}());
