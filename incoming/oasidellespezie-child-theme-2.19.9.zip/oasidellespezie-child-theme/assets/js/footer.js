( function () {
	'use strict';

	var disclosures = Array.prototype.slice.call( document.querySelectorAll( '[data-oasi-footer-disclosure]' ) );
	if ( ! disclosures.length ) {
		return;
	}

	var mobileQuery = window.matchMedia( '(max-width: 720px)' );
	var initialized = false;

	function updateSummaryState( disclosure ) {
		var summary = disclosure.querySelector( 'summary' );
		if ( summary ) {
			summary.setAttribute( 'aria-expanded', disclosure.open ? 'true' : 'false' );
		}
	}

	function syncLayout() {
		disclosures.forEach( function ( disclosure ) {
			if ( mobileQuery.matches ) {
				if ( ! initialized ) {
					disclosure.open = false;
				}
			} else {
				disclosure.open = true;
			}
			updateSummaryState( disclosure );
		} );
		initialized = true;
	}

	disclosures.forEach( function ( disclosure ) {
		disclosure.addEventListener( 'toggle', function () {
			updateSummaryState( disclosure );
		} );
	} );

	syncLayout();
	if ( typeof mobileQuery.addEventListener === 'function' ) {
		mobileQuery.addEventListener( 'change', syncLayout );
	} else {
		mobileQuery.addListener( syncLayout );
	}
}() );
