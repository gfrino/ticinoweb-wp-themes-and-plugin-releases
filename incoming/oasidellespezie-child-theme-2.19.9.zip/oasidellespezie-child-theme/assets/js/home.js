/**
 * Interactive behaviors for Oasi delle Spezie Home Page.
 *
 * @package OasiDelleSpezieChild
 */

document.addEventListener('DOMContentLoaded', function() {
	'use strict';

	// 1. Mobile Navigation Toggle
	const mobileToggle = document.getElementById('oasi-mobile-toggle');
	const mainNav      = document.getElementById('oasi-main-nav');

	if (mobileToggle && mainNav) {
		mobileToggle.addEventListener('click', function() {
			const isOpen = mainNav.classList.toggle('is-open');
			mobileToggle.classList.toggle('is-active');
			mobileToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
		});

		// Close nav when clicking outside on mobile
		document.addEventListener('click', function(e) {
			if (mainNav.classList.contains('is-open') && !mainNav.contains(e.target) && !mobileToggle.contains(e.target)) {
				mainNav.classList.remove('is-open');
				mobileToggle.classList.remove('is-active');
				mobileToggle.setAttribute('aria-expanded', 'false');
			}
		});
	}

	// 2. Video Background Autoplay Assurance
	const heroVideo = document.querySelector('.oasi-hero__video');
	if (heroVideo) {
		const playPromise = heroVideo.play();
		if (playPromise !== undefined) {
			playPromise.catch(function() {
				// Autoplay prevented by browser policy; play on first user interaction
				const playOnInteraction = function() {
					heroVideo.play();
					window.removeEventListener('touchstart', playOnInteraction);
					window.removeEventListener('click', playOnInteraction);
				};
				window.addEventListener('touchstart', playOnInteraction, { once: true });
				window.addEventListener('click', playOnInteraction, { once: true });
			});
		}
	}

	// 3. Header scroll state: owned by header-megamenu.js (with hysteresis).
	//    A second handler here, with a fixed 40px threshold, fought with it and
	//    made the sticky header shake.

	// 4. WooCommerce AJAX Add-to-Cart Count Update
	if (typeof jQuery !== 'undefined') {
		jQuery(document.body).on('added_to_cart', function(event, fragments, cartHash, $button) {
			const countElement = document.getElementById('oasi-cart-count');
			if (countElement && fragments && fragments['div.widget_shopping_cart_content']) {
				// Parse cart count if present or increment locally
				const current = parseInt(countElement.textContent, 10) || 0;
				countElement.textContent = current + 1;
			}
		});
	}

	// 5. Interactive Category Macro-Groups (Tabs on Desktop / Accordion on Mobile)
	const macroTabs = document.querySelectorAll('.oasi-macro-tab');
	const macroAccordionTriggers = document.querySelectorAll('.oasi-macro-accordion__trigger');
	const macroGroups = document.querySelectorAll('.oasi-macro-group');

	function setActiveGroup(groupId) {
		// Update desktop tabs
		macroTabs.forEach(function(tab) {
			const isTarget = tab.getAttribute('data-group') === groupId;
			tab.classList.toggle('oasi-macro-tab--active', isTarget);
			tab.setAttribute('aria-selected', isTarget ? 'true' : 'false');
		});

		// Update accordion groups and triggers
		macroGroups.forEach(function(group) {
			const isTarget = group.getAttribute('data-group-id') === groupId;
			const trigger = group.querySelector('.oasi-macro-accordion__trigger');
			const panel = group.querySelector('.oasi-macro-panel');

			group.classList.toggle('oasi-macro-group--open', isTarget);
			if (trigger) {
				trigger.classList.toggle('oasi-macro-accordion__trigger--active', isTarget);
				trigger.setAttribute('aria-expanded', isTarget ? 'true' : 'false');
			}
			if (panel) {
				panel.classList.toggle('oasi-macro-panel--active', isTarget);
			}
		});
	}

	// Desktop tab click handler
	macroTabs.forEach(function(tab) {
		tab.addEventListener('click', function() {
			const targetGroup = this.getAttribute('data-group');
			if (targetGroup) {
				setActiveGroup(targetGroup);
			}
		});
	});

	// Mobile accordion click handler
	macroAccordionTriggers.forEach(function(trigger) {
		trigger.addEventListener('click', function() {
			const targetGroup = this.getAttribute('data-group');
			const parentGroup = this.closest('.oasi-macro-group');
			const isOpen = parentGroup && parentGroup.classList.contains('oasi-macro-group--open');

			if (isOpen) {
				// Toggle close this accordion
				parentGroup.classList.remove('oasi-macro-group--open');
				this.classList.remove('oasi-macro-accordion__trigger--active');
				this.setAttribute('aria-expanded', 'false');
			} else if (targetGroup) {
				// Open this group and close others
				setActiveGroup(targetGroup);
				setTimeout(function() {
					trigger.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
				}, 50);
			}
		});
	});

});
