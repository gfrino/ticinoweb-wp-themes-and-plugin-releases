(() => {
	'use strict';

	const accordions = document.querySelectorAll('[data-oasi-professional-accordion]');

	accordions.forEach((accordion) => {
		accordion.classList.add('is-enhanced');
		const buttons = Array.from(accordion.querySelectorAll('.oasi-professional-accordion__button'));

		const setState = (button, expanded) => {
			const panel = document.getElementById(button.getAttribute('aria-controls'));
			button.setAttribute('aria-expanded', expanded ? 'true' : 'false');

			if (panel) {
				panel.setAttribute('aria-hidden', expanded ? 'false' : 'true');
			}
		};

		buttons.forEach((button, index) => {
			setState(button, index === 0);

			button.addEventListener('click', () => {
				const nextState = button.getAttribute('aria-expanded') !== 'true';
				buttons.forEach((candidate) => {
					setState(candidate, candidate === button ? nextState : false);
				});
			});
		});
	});
})();
