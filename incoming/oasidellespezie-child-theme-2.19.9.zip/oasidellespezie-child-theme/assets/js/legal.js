(() => {
	'use strict';
	const links = [...document.querySelectorAll('[data-oasi-legal-toc] a')];
	const sections = [...document.querySelectorAll('[data-oasi-legal-section]')];
	if (!links.length || !sections.length || !('IntersectionObserver' in window)) return;
	const observer = new IntersectionObserver((entries) => {
		entries.forEach((entry) => {
			if (!entry.isIntersecting) return;
			links.forEach((link) => link.classList.toggle('is-current', link.hash === `#${entry.target.id}`));
		});
	}, { rootMargin: '-20% 0px -65%', threshold: 0 });
	sections.forEach((section) => observer.observe(section));
})();
