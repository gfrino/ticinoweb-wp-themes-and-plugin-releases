/**
 * Dynamic News & Recipes Archive Controller — Oasi delle Spezie
 *
 * Lightweight, accessible category filtering, URL sync, and micro-animations.
 * Uses event delegation for instant click response and defensive DOM execution.
 *
 * @package OasiDelleSpezieChild
 */

(function () {
	'use strict';

	/**
	 * Apply category filter to news cards.
	 *
	 * @param {string}  filterSlug Target category slug ('all', 'ricette', 'blog', etc.).
	 * @param {boolean} updateUrl  Whether to update URL search parameter.
	 */
	function applyNewsFilter(filterSlug, updateUrl) {
		var buttons = document.querySelectorAll('.oasi-news-filter__btn');
		var stream = document.querySelector('[data-oasi-news-stream]');
		var cards = stream ? stream.querySelectorAll('.oasi-news-card') : document.querySelectorAll('.oasi-news-card');
		var emptyState = document.getElementById('oasi-news-filter-empty');
		var targetSlug = (filterSlug || 'all').toLowerCase();
		var visibleCount = 0;

		// 1. Update filter button active states and aria attributes
		buttons.forEach(function (btn) {
			var btnSlug = (btn.getAttribute('data-filter') || 'all').toLowerCase();
			var isActive = btnSlug === targetSlug;
			btn.classList.toggle('is-active', isActive);
			btn.setAttribute('aria-pressed', isActive ? 'true' : 'false');
		});

		// 2. Filter cards with subtle CSS entrance animation
		cards.forEach(function (card) {
			var rawSlugs = (card.getAttribute('data-category-slug') || '').toLowerCase();
			var cardSlugs = rawSlugs.split(/\s+/).filter(Boolean);
			var matches = targetSlug === 'all' || cardSlugs.indexOf(targetSlug) !== -1;

			if (matches) {
				card.classList.remove('is-filtered-hidden');
				card.classList.remove('is-animating-in');
				// Trigger reflow to restart CSS animation smoothly
				void card.offsetWidth;
				card.classList.add('is-animating-in');
				visibleCount++;
			} else {
				card.classList.add('is-filtered-hidden');
				card.classList.remove('is-animating-in');
			}
		});

		// 3. Handle empty state visibility
		if (emptyState) {
			emptyState.classList.toggle('is-hidden', visibleCount > 0);
		}

		// 4. Update browser URL without reload if requested
		if (updateUrl && window.history && window.history.replaceState) {
			try {
				var url = new URL(window.location.href);
				if (targetSlug === 'all') {
					url.searchParams.delete('categoria');
				} else {
					url.searchParams.set('categoria', targetSlug);
				}
				window.history.replaceState({}, '', url.toString());
			} catch (e) {
				// History API fallback
			}
		}
	}

	/**
	 * Initialize news archive features.
	 */
	function initNewsArchive() {
		var filterNav = document.querySelector('.oasi-news-filter');
		var stream = document.querySelector('[data-oasi-news-stream]');

		if (!filterNav || !stream) {
			return;
		}

		// Check for initial category query parameter in URL (e.g. ?categoria=ricette)
		try {
			var params = new URLSearchParams(window.location.search);
			var initialCat = params.get('categoria');
			if (initialCat) {
				var matchingBtn = filterNav.querySelector('[data-filter="' + initialCat.toLowerCase() + '"]');
				if (matchingBtn) {
					applyNewsFilter(initialCat.toLowerCase(), false);
				}
			}
		} catch (e) {
			// URLSearchParams not supported or invalid URL
		}
	}

	// 1. Delegated click listener on document for instant and dynamic handling
	document.addEventListener('click', function (e) {
		var filterBtn = e.target.closest('.oasi-news-filter__btn');
		if (filterBtn) {
			e.preventDefault();
			var slug = filterBtn.getAttribute('data-filter') || 'all';
			applyNewsFilter(slug, true);
			return;
		}

		var resetBtn = e.target.closest('[data-filter-reset]');
		if (resetBtn) {
			e.preventDefault();
			applyNewsFilter('all', true);
			return;
		}
	});

	// 2. Run initialization immediately if DOM elements exist, or on DOMContentLoaded
	if (document.querySelector('.oasi-news-filter') && document.querySelector('[data-oasi-news-stream]')) {
		initNewsArchive();
	} else if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', initNewsArchive);
	} else {
		initNewsArchive();
	}

	// Expose safe API on window for testing or integrations
	window.oasiNewsFilter = {
		apply: applyNewsFilter,
		init: initNewsArchive
	};
})();
