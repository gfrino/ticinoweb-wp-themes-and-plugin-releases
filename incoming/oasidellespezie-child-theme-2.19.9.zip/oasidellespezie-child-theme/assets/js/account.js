/**
 * Progressive enhancement for the mobile Customer Hub navigation.
 */
( function () {
	'use strict';

	document.querySelectorAll( '.oasi-account .woocommerce-MyAccount-navigation' ).forEach( function ( navigation ) {
		var toggle = navigation.querySelector( '.oasi-account-nav__toggle' );
		var list = navigation.querySelector( 'ul' );

		if ( ! toggle || ! list ) {
			return;
		}

		navigation.classList.add( 'is-enhanced' );

		function setExpanded( expanded ) {
			toggle.setAttribute( 'aria-expanded', expanded ? 'true' : 'false' );
			navigation.classList.toggle( 'is-open', expanded );
		}

		toggle.addEventListener( 'click', function () {
			setExpanded( toggle.getAttribute( 'aria-expanded' ) !== 'true' );
		} );

		navigation.addEventListener( 'keydown', function ( event ) {
			if ( 'Escape' === event.key && navigation.classList.contains( 'is-open' ) ) {
				setExpanded( false );
				toggle.focus();
			}
		} );

		list.addEventListener( 'click', function ( event ) {
			if ( event.target.closest( 'a' ) && window.matchMedia( '(max-width: 880px)' ).matches ) {
				setExpanded( false );
			}
		} );
	} );
}() );
