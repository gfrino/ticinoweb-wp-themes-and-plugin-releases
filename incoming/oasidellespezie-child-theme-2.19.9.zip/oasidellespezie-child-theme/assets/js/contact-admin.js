/**
 * Attach Oasi-only editorial fields to ticinoWEB CMS -> Contatti.
 */
(function () {
	'use strict';

	function mountContactFields() {
		var source = document.getElementById('oasi-contact-cms-fields');
		var table = document.querySelector('#contatti .form-table');

		if (!source || !table || table.querySelector('.oasi-contact-cms-row')) {
			return;
		}

		Array.prototype.slice.call(source.querySelectorAll('.oasi-contact-cms-row')).forEach(function (row) {
			table.querySelector('tbody').appendChild(row);
		});

		source.remove();
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', mountContactFields);
	} else {
		mountContactFields();
	}
}());
