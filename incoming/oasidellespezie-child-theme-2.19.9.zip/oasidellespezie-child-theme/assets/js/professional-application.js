(() => {
	'use strict';
	document.querySelectorAll('[data-oasi-count]').forEach((field) => {
		const output = field.parentElement.querySelector('[data-oasi-count-value]');
		if (!output) return;
		const update = () => { output.textContent = String(field.value.length); };
		field.addEventListener('input', update);
		update();
	});
	const form = document.querySelector('[data-oasi-professional-form]');
	if (form) form.addEventListener('submit', () => {
		const button = form.querySelector('button[type="submit"]');
		if (button) { button.disabled = true; button.setAttribute('aria-busy', 'true'); }
	});
})();
