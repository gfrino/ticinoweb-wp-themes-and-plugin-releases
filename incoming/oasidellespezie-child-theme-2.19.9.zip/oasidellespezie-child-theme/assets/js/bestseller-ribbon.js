/**
 * Oasi Home Product Ribbon: progressive deceleration and restart.
 */
(function (root, factory) {
	'use strict';
	const api = factory();
	if (typeof module === 'object' && module.exports) {
		module.exports = api;
	}
	if (root && root.document) {
		root.OasiProductRibbon = api;
		const boot = function () {
			root.requestAnimationFrame(function () { api.init(root.document, root); });
		};
		if (root.document.readyState === 'loading') {
			root.document.addEventListener('DOMContentLoaded', boot, { once: true });
		} else {
			boot();
		}
	}
}(typeof window !== 'undefined' ? window : null, function () {
	'use strict';

	function createRateController(animations, options) {
		const settings = options || {};
		const duration = Number(settings.duration) || 560;
		const requestFrame = settings.requestFrame || window.requestAnimationFrame.bind(window);
		const cancelFrame = settings.cancelFrame || window.cancelAnimationFrame.bind(window);
		const items = animations.filter(function (animation) {
			return animation && typeof animation.playbackRate === 'number';
		});
		let currentRate = items.length ? items[0].playbackRate : 1;
		let startRate = currentRate;
		let targetRate = currentRate;
		let startTime = null;
		let frameId = null;

		function apply(rate) {
			currentRate = rate;
			items.forEach(function (animation) { animation.playbackRate = rate; });
		}

		function tick(timestamp) {
			if (startTime === null) {
				startTime = timestamp;
			}
			const progress = Math.min((timestamp - startTime) / duration, 1);
			const eased = 1 - Math.pow(1 - progress, 3);
			apply(startRate + (targetRate - startRate) * eased);
			if (progress < 1) {
				frameId = requestFrame(tick);
			} else {
				apply(targetRate);
				frameId = null;
			}
		}

		return {
			setTarget(rate) {
				const nextRate = Math.max(0, Math.min(1, Number(rate)));
				if (frameId !== null) {
					cancelFrame(frameId);
				}
				startRate = currentRate;
				targetRate = nextRate;
				startTime = null;
				if (Math.abs(targetRate - startRate) < 0.001) {
					apply(targetRate);
					frameId = null;
					return;
				}
				frameId = requestFrame(tick);
			},
			destroy() {
				if (frameId !== null) {
					cancelFrame(frameId);
				}
				frameId = null;
			},
		};
	}

	function init(documentRef, windowRef) {
		const showcase = documentRef.querySelector('.oasi-marquee-showcase');
		if (!showcase || windowRef.matchMedia('(prefers-reduced-motion: reduce)').matches) {
			return null;
		}
		const animations = Array.from(showcase.querySelectorAll('.oasi-marquee-track')).reduce(function (all, track) {
			return all.concat(track.getAnimations ? track.getAnimations() : []);
		}, []);
		const controller = createRateController(animations, {
			duration: 560,
			requestFrame: windowRef.requestAnimationFrame.bind(windowRef),
			cancelFrame: windowRef.cancelAnimationFrame.bind(windowRef),
		});
		let activeItem = null;
		let touchTimer = null;

		function activate(item) {
			if (activeItem && activeItem !== item) {
				activeItem.classList.remove('is-active');
			}
			activeItem = item;
			activeItem.classList.add('is-active');
			showcase.classList.add('has-active-item');
			controller.setTarget(0);
		}

		function reset() {
			if (activeItem) {
				activeItem.classList.remove('is-active');
			}
			activeItem = null;
			showcase.classList.remove('has-active-item');
			controller.setTarget(1);
		}

		showcase.addEventListener('pointerover', function (event) {
			if (event.pointerType === 'touch') {
				return;
			}
			const item = event.target.closest('.oasi-marquee-item');
			if (item && showcase.contains(item)) {
				activate(item);
			}
		});
		showcase.addEventListener('pointerleave', reset);
		showcase.addEventListener('focusin', function (event) {
			const item = event.target.closest('.oasi-marquee-item');
			if (item) {
				activate(item);
			}
		});
		showcase.addEventListener('focusout', function (event) {
			if (!showcase.contains(event.relatedTarget)) {
				reset();
			}
		});
		showcase.addEventListener('pointerdown', function (event) {
			if (event.pointerType !== 'touch') {
				return;
			}
			const item = event.target.closest('.oasi-marquee-item');
			if (item) {
				if (activeItem && activeItem !== item) {
					activeItem.classList.remove('is-active');
				}
				activeItem = item;
				item.classList.add('is-active');
				showcase.classList.add('has-active-item');
			}
			controller.setTarget(0.3);
			windowRef.clearTimeout(touchTimer);
			touchTimer = windowRef.setTimeout(reset, 1400);
		}, { passive: true });

		return controller;
	}

	return { createRateController: createRateController, init: init };
}));
