/**
 * Dynamic team controls for ticinoWEB CMS -> Chi siamo.
 */
(function () {
	'use strict';

	function renumberMembers(team) {
		var members = Array.prototype.slice.call(team.querySelectorAll('[data-oasi-team-member]'));

		members.forEach(function (member, index) {
			var title = member.querySelector('[data-oasi-member-title]');
			var titleId = 'oasi-team-member-' + index;
			var readableTitle = 'Collaboratore ' + (index + 1);

			member.setAttribute('aria-labelledby', titleId);
			title.id = titleId;
			title.textContent = readableTitle;

			Array.prototype.slice.call(member.querySelectorAll('[data-oasi-field]')).forEach(function (input) {
				var field = input.getAttribute('data-oasi-field');
				input.name = 'ticinoweb_chi_siamo_team[' + index + '][' + field + ']';
				if (field === 'image_id') {
					input.id = 'oasi_team_image_' + index;
				}
			});

			Array.prototype.slice.call(member.querySelectorAll('.oasi-about-move-member')).forEach(function (button) {
				var direction = button.getAttribute('data-direction');
				button.disabled = (direction === 'up' && index === 0) || (direction === 'down' && index === members.length - 1);
				button.setAttribute('aria-label', direction === 'up'
					? 'Sposta ' + readableTitle + ' in alto'
					: 'Sposta ' + readableTitle + ' in basso');
			});
		});
	}

	function setEmptyPreview(preview) {
		preview.innerHTML = '';
		var emptyLabel = document.createElement('span');
		emptyLabel.textContent = preview.getAttribute('data-empty-label') || 'Nessuna foto';
		preview.appendChild(emptyLabel);
	}

	function mountFields() {
		var source = document.getElementById('oasi-about-cms-fields');
		var table = document.querySelector('#chi-siamo table.form-table');

		if (!source || !table || table.querySelector('.oasi-about-cms-row')) {
			return;
		}

		var template = source.querySelector('#oasi-about-member-template');

		Array.prototype.slice.call(source.querySelectorAll('.oasi-about-cms-row')).forEach(function (row) {
			table.querySelector('tbody').appendChild(row);
		});

		var team = table.querySelector('.oasi-about-cms-team');
		var toolbar = table.querySelector('.oasi-about-cms-toolbar');
		source.remove();
		renumberMembers(team);

		table.addEventListener('click', function (event) {
			var member = event.target.closest('[data-oasi-team-member]');
			var addButton = event.target.closest('.oasi-about-add-member');
			var removeMemberButton = event.target.closest('.oasi-about-remove-member');
			var moveButton = event.target.closest('.oasi-about-move-member');
			var mediaButton = event.target.closest('.oasi-about-media-button');
			var removeMediaButton = event.target.closest('.oasi-about-media-remove');

			if (addButton) {
				event.preventDefault();
				var fragment = template.content.cloneNode(true);
				var newMember = fragment.querySelector('[data-oasi-team-member]');
				team.appendChild(fragment);
				renumberMembers(team);
				newMember.querySelector('[data-oasi-field="name"]').focus();
				return;
			}

			if (!member) {
				return;
			}

			if (removeMemberButton) {
				event.preventDefault();
				var nextFocus = member.nextElementSibling || member.previousElementSibling || toolbar.querySelector('.oasi-about-add-member');
				member.remove();
				renumberMembers(team);
				nextFocus.focus();
				return;
			}

			if (moveButton) {
				event.preventDefault();
				var direction = moveButton.getAttribute('data-direction');
				var sibling = direction === 'up' ? member.previousElementSibling : member.nextElementSibling;
				if (sibling) {
					if (direction === 'up') {
						team.insertBefore(member, sibling);
					} else {
						team.insertBefore(sibling, member);
					}
					renumberMembers(team);
					moveButton.focus();
				}
				return;
			}

			var input = member.querySelector('[data-oasi-field="image_id"]');
			var preview = member.querySelector('[data-oasi-image-preview]');
			var matchingRemoveButton = member.querySelector('.oasi-about-media-remove');

			if (removeMediaButton) {
				event.preventDefault();
				input.value = '';
				setEmptyPreview(preview);
				removeMediaButton.disabled = true;
				return;
			}

			if (!mediaButton || !window.wp || !window.wp.media) {
				return;
			}

			event.preventDefault();
			var frame = window.wp.media({
				title: 'Seleziona la foto del collaboratore',
				button: { text: 'Usa questa foto' },
				library: { type: 'image' },
				multiple: false
			});

			frame.on('select', function () {
				var attachment = frame.state().get('selection').first().toJSON();
				var imageUrl = attachment.sizes && attachment.sizes.thumbnail
					? attachment.sizes.thumbnail.url
					: attachment.url;

				input.value = attachment.id;
				preview.innerHTML = '';
				var image = document.createElement('img');
				image.src = imageUrl;
				image.alt = '';
				preview.appendChild(image);
				matchingRemoveButton.disabled = false;
			});

			frame.open();
		});

		var form = table.closest('form');
		if (form) {
			form.addEventListener('submit', function () {
				renumberMembers(team);
			});
		}
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', mountFields);
	} else {
		mountFields();
	}
}());
