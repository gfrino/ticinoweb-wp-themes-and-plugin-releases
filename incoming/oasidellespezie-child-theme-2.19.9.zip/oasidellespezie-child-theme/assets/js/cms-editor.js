(function () {
	'use strict';

	var maximumConditions = 12;

	function refreshConditions(list) {
		if (!list) {
			return;
		}

		var rows = Array.prototype.slice.call(list.querySelectorAll('[data-oasi-condition-row]'));
		rows.forEach(function (row, index) {
			var number = row.querySelector('[data-oasi-condition-number]');
			var up = row.querySelector('[data-oasi-condition-up]');
			var down = row.querySelector('[data-oasi-condition-down]');

			if (number) {
				number.textContent = String(index + 1);
			}
			row.querySelectorAll('[name]').forEach(function (field) {
				field.name = field.name.replace(/\[conditions\]\[[^\]]+\]/, '[conditions][' + index + ']');
			});
			if (up) {
				up.disabled = index === 0;
			}
			if (down) {
				down.disabled = index === rows.length - 1;
			}
		});

		var add = document.querySelector('[data-oasi-condition-add]');
		if (add) {
			add.disabled = rows.length >= maximumConditions;
		}
	}

	function manageCondition(event) {
		var target = event.target;
		if (!(target instanceof Element)) {
			return false;
		}

		var add = target.closest('[data-oasi-condition-add]');
		var remove = target.closest('[data-oasi-condition-remove]');
		var up = target.closest('[data-oasi-condition-up]');
		var down = target.closest('[data-oasi-condition-down]');
		if (!add && !remove && !up && !down) {
			return false;
		}

		var list = document.querySelector('[data-oasi-condition-list]');
		if (!list) {
			return true;
		}

		if (add) {
			if (list.querySelectorAll('[data-oasi-condition-row]').length >= maximumConditions) {
				return true;
			}
			var template = document.querySelector('[data-oasi-condition-template]');
			if (template) {
				list.appendChild(template.content.cloneNode(true));
			}
		} else {
			var row = (remove || up || down).closest('[data-oasi-condition-row]');
			if (!row) {
				return true;
			}
			if (remove) {
				row.remove();
			} else if (up && row.previousElementSibling) {
				list.insertBefore(row, row.previousElementSibling);
			} else if (down && row.nextElementSibling) {
				list.insertBefore(row.nextElementSibling, row);
			}
		}

		refreshConditions(list);
		return true;
	}

	document.addEventListener('DOMContentLoaded', function () {
		refreshConditions(document.querySelector('[data-oasi-condition-list]'));
	});

	document.addEventListener('click', function (event) {
		if (manageCondition(event)) {
			return;
		}

		var target = event.target;
		if (!(target instanceof Element)) {
			return;
		}
		var pick = target.closest('[data-oasi-media-pick]');
		var clear = target.closest('[data-oasi-media-clear]');
		if (!pick && !clear) {
			return;
		}
		var wrapper = (pick || clear).closest('[data-oasi-media-field]');
		if (!wrapper) {
			return;
		}
		var input = wrapper.querySelector('input[type="hidden"]');
		var preview = wrapper.querySelector('[data-oasi-media-preview]');
		if (clear) {
			input.value = '';
			preview.innerHTML = '<span>' + (preview.getAttribute('data-empty-label') || 'Nessun file') + '</span>';
			return;
		}
		var type = pick.getAttribute('data-media-type') || 'image';
		var frame = wp.media({
			title: pick.getAttribute('data-title') || 'Seleziona un file',
			button: { text: pick.getAttribute('data-button') || 'Usa questo file' },
			library: { type: type },
			multiple: false
		});
		frame.on('select', function () {
			var item = frame.state().get('selection').first().toJSON();
			input.value = item.id;
			if ('image' === type) {
				preview.innerHTML = '<img src="' + (item.sizes && item.sizes.medium ? item.sizes.medium.url : item.url) + '" alt="">';
			} else {
				preview.innerHTML = '<strong>' + item.filename + '</strong>';
			}
		});
		frame.open();
	});
}());
