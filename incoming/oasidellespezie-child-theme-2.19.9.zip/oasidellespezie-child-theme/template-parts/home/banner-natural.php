<?php
/**
 * Narrative Banner 2: 100% Natural & Organic Certification.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$natural_bg = wp_get_attachment_image_url( 33456, '1536x1536' );
if ( ! $natural_bg ) {
	$natural_bg = wp_get_attachment_image_url( 33338, 'full' );
}
if ( ! $natural_bg ) {
	$natural_bg = oasi_upload_url( '2022/02/spices-ingredients-for-cooking-spices-concept-1-1.jpg' );
}

$cert_logo_url           = oasi_get_master_logo_url();
$cert_logo_attachment_id = $cert_logo_url ? attachment_url_to_postid( $cert_logo_url ) : 0;
$cert_logo_alt           = sprintf( __( 'Logo %s', 'oasidellespezie-child-theme' ), get_bloginfo( 'name' ) );
?>
<section class="oasi-narrative-banner oasi-narrative-banner--natural" style="background-image: url('<?php echo esc_url( $natural_bg ); ?>');" aria-label="<?php esc_attr_e( 'Garanzia naturale e certificazioni', 'oasidellespezie-child-theme' ); ?>">
	<div class="oasi-narrative-banner__overlay oasi-narrative-banner__overlay--warm"></div>
	<div class="oasi-container oasi-narrative-banner__inner">
		<div class="oasi-narrative-banner__content">
			<div class="oasi-narrative-banner__cert-badge">
				<?php if ( $cert_logo_url ) : ?>
					<?php if ( $cert_logo_attachment_id ) : ?>
						<?php echo wp_get_attachment_image( $cert_logo_attachment_id, 'full', false, array( 'alt' => $cert_logo_alt, 'class' => 'oasi-cert-img', 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '(max-width: 600px) 220px, 320px' ) ); ?>
					<?php else : ?>
						<img src="<?php echo esc_url( $cert_logo_url ); ?>" alt="<?php echo esc_attr( $cert_logo_alt ); ?>" width="320" height="195" class="oasi-cert-img" loading="lazy" decoding="async">
					<?php endif; ?>
				<?php endif; ?>
				<span class="oasi-cert-label">Certificazione Ufficiale Bio • CH-BIO-006</span>
			</div>

			<h2 class="oasi-narrative-banner__title">
				Tutte le nostre erbe, spezie e miscele di spezie sono naturali al 100%, senza conservanti o additivi.
			</h2>

			<p class="oasi-narrative-banner__desc">
				Rifiutiamo aromi sintetici, esaltatori di sapidità, conservanti e addensanti. Solo pura materia prima selezionata, coltivata nel rispetto della terra e lavorata con rigore svizzero.
			</p>

			<div class="oasi-narrative-banner__cta">
				<a href="<?php echo esc_url( home_url( '/chi-siamo/' ) ); ?>" class="oasi-btn oasi-btn--primary oasi-btn--lg">
					<span>Approfondisci la Nostra Filosofia</span>
					<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
				</a>
			</div>
		</div>
	</div>
</section>
