<?php
/**
 * Trust & Service Bar Template Part.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$contact = function_exists( 'oasi_get_contact_data' ) ? oasi_get_contact_data() : array();
$city    = $contact['city'] ?? 'Gudo';
$phone   = $contact['phone'] ?? '+41 91 859 05 32';
$tel     = $contact['phone_tel'] ?? '+41918590532';
$hours   = $contact['hours_short'] ?? 'Lu-Ve / Sa';
?>
<section class="oasi-trust-bar" aria-label="<?php esc_attr_e( 'Informazioni di servizio e garanzie', 'oasidellespezie-child-theme' ); ?>">
	<div class="oasi-container">
		<div class="oasi-trust-grid">
			<div class="oasi-trust-item">
				<div class="oasi-trust-item__icon" aria-hidden="true">
					<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"></rect><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon><circle cx="5.5" cy="18.5" r="2.5"></circle><circle cx="18.5" cy="18.5" r="2.5"></circle></svg>
				</div>
				<div class="oasi-trust-item__text">
					<span class="oasi-trust-item__title"><?php esc_html_e( 'SPEDIZIONE 5-10 GIORNI', 'oasidellespezie-child-theme' ); ?></span>
					<span class="oasi-trust-item__desc"><?php esc_html_e( 'Lavorativi in tutta la Svizzera', 'oasidellespezie-child-theme' ); ?></span>
				</div>
			</div>

			<div class="oasi-trust-item">
				<div class="oasi-trust-item__icon" aria-hidden="true">
					<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 12 20 22 4 22 4 12"></polyline><rect x="2" y="7" width="20" height="5"></rect><line x1="12" y1="22" x2="12" y2="7"></line><path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"></path><path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"></path></svg>
				</div>
				<div class="oasi-trust-item__text">
					<span class="oasi-trust-item__title"><?php esc_html_e( 'SPEDIZIONE GRATUITA', 'oasidellespezie-child-theme' ); ?></span>
					<span class="oasi-trust-item__desc"><?php echo esc_html( sprintf( /* translators: 1: amount in CHF, 2: city. */ __( 'Da %1$s CHF o ritiro a %2$s', 'oasidellespezie-child-theme' ), ( function_exists( 'oasi_free_shipping_threshold' ) ? oasi_free_shipping_threshold() : '' ), $city ) ); ?></span>
				</div>
			</div>

			<div class="oasi-trust-item">
				<div class="oasi-trust-item__icon" aria-hidden="true">
					<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect><line x1="1" y1="10" x2="23" y2="10"></line></svg>
				</div>
				<div class="oasi-trust-item__text">
					<span class="oasi-trust-item__title"><?php esc_html_e( 'PAGAMENTO SICURO', 'oasidellespezie-child-theme' ); ?></span>
					<span class="oasi-trust-item__desc"><?php esc_html_e( 'TWINT, PostFinance, Carte, Bonifico', 'oasidellespezie-child-theme' ); ?></span>
				</div>
			</div>

			<div class="oasi-trust-item">
				<div class="oasi-trust-item__icon" aria-hidden="true">
					<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
				</div>
				<div class="oasi-trust-item__text">
					<span class="oasi-trust-item__title"><?php esc_html_e( 'SERVIZIO CLIENTI', 'oasidellespezie-child-theme' ); ?></span>
					<span class="oasi-trust-item__desc">
						<a href="<?php echo esc_url( 'tel:' . $tel ); ?>" class="oasi-trust-item__phone-link"><?php echo esc_html( $phone ); ?></a>
						<span class="oasi-trust-item__sep">•</span>
						<span><?php echo esc_html( $hours ); ?></span>
					</span>
				</div>
			</div>
		</div>
	</div>
</section>
