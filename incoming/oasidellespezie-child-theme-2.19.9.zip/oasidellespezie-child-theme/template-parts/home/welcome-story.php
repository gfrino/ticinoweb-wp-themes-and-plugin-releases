<?php
/**
 * Welcome & Artisan Story Template Part.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$lab_img_url = wp_get_attachment_image_url( 35188, 'large' );
if ( ! $lab_img_url ) {
	$lab_img_url = wp_get_attachment_image_url( 35182, 'large' );
}
if ( ! $lab_img_url ) {
	$lab_img_url = oasi_upload_url( '2022/02/IMG_5047.jpg' );
}
?>
<section class="oasi-welcome oasi-section" aria-labelledby="oasi-welcome-title">
	<div class="oasi-container">
		<div class="oasi-welcome__grid">
			<div class="oasi-welcome__text-col">
				<span class="oasi-section-eyebrow">Passione, Purezza & Tradizione</span>
				<h2 id="oasi-welcome-title" class="oasi-section-title">
					Benvenuti nell'Oasi delle Spezie
				</h2>
				<div class="oasi-section-divider"></div>
				
				<p class="oasi-lead-text">
					Siamo una piccola azienda familiare svizzera nata con l'obiettivo di condividere la profonda conoscenza e l'amore per le spezie più pregiate del mondo.
				</p>

				<p>
					L'Oasi delle Spezie non è un negozio con vetrina su strada: <strong>è un autentico laboratorio artigianale</strong>. Qui selezioniamo spezie d'origine controllata, erbe aromatiche biologiche, pepi rari e sali incontaminati. Per preservare intatti i preziosi oli essenziali e l'intensità del bouquet olfattivo, maciniamo le singole spezie solo ed esclusivamente al momento dell'ordine.
				</p>

				<div class="oasi-welcome__badges">
					<div class="oasi-pill">
						<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
						<span>Origine 100% Controllata</span>
					</div>
					<div class="oasi-pill">
						<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
						<span>Macinazione su Ordinazione</span>
					</div>
					<div class="oasi-pill">
						<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
						<span>Qualità Svizzera & Bio</span>
					</div>
				</div>

				<div class="oasi-welcome__cta">
					<a href="<?php echo esc_url( home_url( '/chi-siamo/' ) ); ?>" class="oasi-btn oasi-btn--outline">
						<span>Scopri la nostra storia</span>
						<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
					</a>
				</div>
			</div>

			<div class="oasi-welcome__visual-col">
				<div class="oasi-welcome__image-wrapper">
					<img src="<?php echo esc_url( $lab_img_url ); ?>" alt="<?php esc_attr_e( 'Laboratorio artigianale Oasi delle Spezie', 'oasidellespezie-child-theme' ); ?>" loading="lazy" width="600" height="600" class="oasi-welcome__img">
					<div class="oasi-welcome__image-card">
						<span class="oasi-welcome__image-card-num">10+</span>
						<span class="oasi-welcome__image-card-text">Anni di eccellenza e ricerca aromatica nel Ticino</span>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
