<?php
/**
 * Visual Categories Grid Template Part - Interactive Macro-Groups.
 *
 * @package OasiDelleSpezieChild
 * @version 0.6.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$macro_groups = oasi_get_category_macro_groups();
?>
<section class="oasi-categories oasi-section" id="esplora-categorie" aria-labelledby="oasi-categories-title">
	<div class="oasi-container">
		<div class="oasi-section-header">
			<span class="oasi-section-eyebrow"><?php esc_html_e( 'Esplorazione Guidata dello Shop', 'oasidellespezie-child-theme' ); ?></span>
			<h2 id="oasi-categories-title" class="oasi-section-title">
				<?php esc_html_e( 'I Mondi Aromatici di Oasi delle Spezie', 'oasidellespezie-child-theme' ); ?>
			</h2>
			<div class="oasi-section-divider"></div>
			<p class="oasi-section-subtitle">
				<?php esc_html_e( 'Seleziona un macro-gruppo per scoprire tutte le categorie dedicate: clicca sul titolo o sul pulsante per accedere direttamente al catalogo.', 'oasidellespezie-child-theme' ); ?>
			</p>
		</div>

		<!-- Navigazione a Schede / Selettore Macro-Gruppi (Desktop & Tablet) -->
		<div class="oasi-macro-tabs-wrapper">
			<div class="oasi-macro-tabs" role="tablist" aria-label="<?php esc_attr_e( 'Macro-Gruppi Categorie', 'oasidellespezie-child-theme' ); ?>">
				<?php $idx = 0; foreach ( $macro_groups as $gid => $group ) : $idx++; $active = ( $idx === 1 ); ?>
					<button type="button"
					        class="oasi-macro-tab <?php echo $active ? 'oasi-macro-tab--active' : ''; ?>"
					        role="tab"
					        id="tab-<?php echo esc_attr( $gid ); ?>"
					        aria-selected="<?php echo $active ? 'true' : 'false'; ?>"
					        aria-controls="panel-<?php echo esc_attr( $gid ); ?>"
					        data-group="<?php echo esc_attr( $gid ); ?>">
						<span class="oasi-macro-tab__icon" aria-hidden="true"><?php echo esc_html( $group['icon'] ); ?></span>
						<span class="oasi-macro-tab__content">
							<span class="oasi-macro-tab__title"><?php echo esc_html( $group['short_name'] ); ?></span>
							<span class="oasi-macro-tab__badge" aria-label="<?php echo esc_attr( sprintf( _n( '%s categoria', '%s categorie', $group['cat_count'], 'oasidellespezie-child-theme' ), $group['cat_count'] ) ); ?>">
								<?php echo esc_html( $group['cat_count'] ); ?>
							</span>
						</span>
					</button>
				<?php endforeach; ?>
			</div>
		</div>

		<!-- Struttura Fisarmonica & Pannelli Categorie -->
		<div class="oasi-macro-accordion">
			<?php $idx = 0; foreach ( $macro_groups as $gid => $group ) : $idx++; $is_open = ( $idx === 1 ); ?>
				<div class="oasi-macro-group <?php echo $is_open ? 'oasi-macro-group--open' : ''; ?>" 
				     id="group-<?php echo esc_attr( $gid ); ?>"
				     data-group-id="<?php echo esc_attr( $gid ); ?>">

					<!-- Trigger Fisarmonica per Mobile -->
					<button type="button" 
					        class="oasi-macro-accordion__trigger <?php echo $is_open ? 'oasi-macro-accordion__trigger--active' : ''; ?>"
					        aria-expanded="<?php echo $is_open ? 'true' : 'false'; ?>"
					        aria-controls="panel-<?php echo esc_attr( $gid ); ?>"
					        data-group="<?php echo esc_attr( $gid ); ?>">
						<div class="oasi-macro-accordion__trigger-left">
							<span class="oasi-macro-accordion__icon" aria-hidden="true"><?php echo esc_html( $group['icon'] ); ?></span>
							<div class="oasi-macro-accordion__meta">
								<span class="oasi-macro-accordion__title"><?php echo esc_html( $group['name'] ); ?></span>
								<span class="oasi-macro-accordion__count">
									<?php echo esc_html( sprintf( _n( '%s categoria', '%s categorie', $group['cat_count'], 'oasidellespezie-child-theme' ), $group['cat_count'] ) ); ?>
									• <?php echo esc_html( sprintf( __( '%s prodotti', 'oasidellespezie-child-theme' ), number_format_i18n( $group['total_products'] ) ) ); ?>
								</span>
							</div>
						</div>
						<span class="oasi-macro-accordion__arrow" aria-hidden="true">
							<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
						</span>
					</button>

					<!-- Pannello Categorie (Visualizzato al click del gruppo) -->
					<div class="oasi-macro-panel <?php echo $is_open ? 'oasi-macro-panel--active' : ''; ?>"
					     id="panel-<?php echo esc_attr( $gid ); ?>"
					     role="tabpanel"
					     aria-labelledby="tab-<?php echo esc_attr( $gid ); ?>">

						<div class="oasi-macro-panel__intro">
							<div class="oasi-macro-panel__intro-header">
								<span class="oasi-macro-panel__badge"><?php echo esc_html( $group['badge'] ); ?></span>
								<span class="oasi-macro-panel__products-count">
									<?php echo esc_html( sprintf( __( '%s prodotti disponibili', 'oasidellespezie-child-theme' ), number_format_i18n( $group['total_products'] ) ) ); ?>
								</span>
							</div>
							<h3 class="oasi-macro-panel__heading"><?php echo esc_html( $group['name'] ); ?></h3>
							<p class="oasi-macro-panel__desc"><?php echo esc_html( $group['description'] ); ?></p>
						</div>

						<div class="oasi-categories-cards-grid">
							<?php foreach ( $group['categories'] as $cat ) : ?>
								<article class="oasi-cat-item" data-cat-id="<?php echo esc_attr( $cat['id'] ); ?>">
									<a href="<?php echo esc_url( $cat['url'] ); ?>" 
									   class="oasi-cat-item__thumb-wrap" 
									   tabindex="-1" 
									   aria-hidden="true">
										<?php if ( ! empty( $cat['image_url'] ) ) : ?>
											<img src="<?php echo esc_url( $cat['image_url'] ); ?>" 
											     alt="<?php echo esc_attr( $cat['name'] ); ?>" 
											     loading="lazy" 
											     width="320" 
											     height="240" 
											     class="oasi-cat-item__img">
										<?php else : ?>
											<div class="oasi-cat-item__placeholder">
												<span class="oasi-cat-item__placeholder-icon"><?php echo esc_html( $group['icon'] ); ?></span>
											</div>
										<?php endif; ?>
										<span class="oasi-cat-item__count-pill">
											<?php echo esc_html( sprintf( _n( '%s prodotto', '%s prodotti', $cat['count'], 'oasidellespezie-child-theme' ), number_format_i18n( $cat['count'] ) ) ); ?>
										</span>
									</a>

									<div class="oasi-cat-item__body">
										<h4 class="oasi-cat-item__title">
											<a href="<?php echo esc_url( $cat['url'] ); ?>">
												<?php echo esc_html( $cat['name'] ); ?>
											</a>
										</h4>

										<a href="<?php echo esc_url( $cat['url'] ); ?>" 
										   class="oasi-cat-item__cta" 
										   aria-label="<?php echo esc_attr( sprintf( __( 'Esplora la categoria %s', 'oasidellespezie-child-theme' ), $cat['name'] ) ); ?>">
											<span><?php esc_html_e( 'Esplora', 'oasidellespezie-child-theme' ); ?></span>
											<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
										</a>
									</div>
								</article>
							<?php endforeach; ?>
						</div>
					</div>

				</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>
