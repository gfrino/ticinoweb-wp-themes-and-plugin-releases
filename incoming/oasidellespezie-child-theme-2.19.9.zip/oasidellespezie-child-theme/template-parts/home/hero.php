<?php
/**
 * Hero Section Template Part (Dynamic from ticinoWEB CMS).
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$hero = oasi_get_hero_data();
?>
<section class="oasi-hero" aria-label="<?php esc_attr_e( 'Presentazione Oasi delle Spezie', 'oasidellespezie-child-theme' ); ?>">
	<div class="oasi-hero__media">
		<?php if ( $hero['is_video'] ) : ?>
			<video class="oasi-hero__video" autoplay loop muted playsinline poster="<?php echo esc_url( $hero['poster_url'] ); ?>">
				<source src="<?php echo esc_url( $hero['media_url'] ); ?>" type="video/mp4">
			</video>
		<?php else : ?>
			<img class="oasi-hero__img" src="<?php echo esc_url( $hero['media_url'] ); ?>" alt="<?php echo esc_attr( $hero['title'] ); ?>" loading="eager" width="1920" height="1080">
		<?php endif; ?>
		<div class="oasi-hero__overlay"></div>
	</div>

	<div class="oasi-container oasi-hero__inner">
		<div class="oasi-hero__content">
			<span class="oasi-hero__tagline">
				<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"/></svg>
				<?php echo esc_html( $hero['tagline'] ); ?>
			</span>

			<h1 class="oasi-hero__title">
				<?php echo esc_html( $hero['title'] ); ?>
			</h1>

			<p class="oasi-hero__desc">
				<?php echo nl2br( esc_html( $hero['description'] ) ); ?>
			</p>

			<div class="oasi-hero__cta-group">
				<a href="<?php echo esc_url( $hero['btn_link'] ); ?>" class="oasi-btn oasi-btn--primary oasi-btn--lg">
					<span><?php echo esc_html( $hero['btn_text'] ); ?></span>
					<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
				</a>

				<a href="<?php echo esc_url( home_url( '/chi-siamo/' ) ); ?>" class="oasi-btn oasi-btn--outline-light oasi-btn--lg">
					<span><?php esc_html_e( 'Il nostro laboratorio', 'oasidellespezie-child-theme' ); ?></span>
				</a>
			</div>

			<ul class="oasi-hero__features" aria-label="<?php esc_attr_e( 'Caratteristiche principali', 'oasidellespezie-child-theme' ); ?>">
				<li>
					<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
					<span>100% Naturale & Bio</span>
				</li>
				<li>
					<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
					<span>Macinato all'ordine</span>
				</li>
				<li>
					<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
					<span>Spedizioni in Svizzera</span>
				</li>
			</ul>
		</div>
	</div>
</section>
