<?php
/**
 * Narrative Banner 1: Fresh Grinding on Order.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$banner_bg = wp_get_attachment_image_url( 33435, '1536x1536' );
if ( ! $banner_bg ) {
	$banner_bg = oasi_upload_url( '2022/02/male-hands-grinding-spices-top-view.jpg' );
}

$spezie_term = get_term_by( 'slug', 'spezie-bio', 'product_cat' );
$spezie_link = $spezie_term ? get_term_link( $spezie_term ) : home_url( '/categoria-prodotto/spezie-bio/' );
?>
<section class="oasi-narrative-banner oasi-narrative-banner--grinding" style="background-image: url('<?php echo esc_url( $banner_bg ); ?>');" aria-label="<?php esc_attr_e( 'Filosofia di macinazione Oasi delle Spezie', 'oasidellespezie-child-theme' ); ?>">
	<div class="oasi-narrative-banner__overlay"></div>
	<div class="oasi-container oasi-narrative-banner__inner">
		<div class="oasi-narrative-banner__content">
			<span class="oasi-narrative-banner__badge">
				<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
				Freschezza Assoluta
			</span>

			<h2 class="oasi-narrative-banner__title">
				A l'Oasi delle Spezie, tutte le nostre singole spezie sono macinate solo quando vengono ordinate!
			</h2>

			<p class="oasi-narrative-banner__desc">
				Gli oli essenziali e i principi attivi naturali si disperdono rapidamente dopo la macinazione. Il nostro metodo artigianale garantisce che ogni grammo mantenga l'integrità del suo profilo aromatico e tutte le sue proprietà benefiche.
			</p>

			<div class="oasi-narrative-banner__cta">
				<a href="<?php echo esc_url( $spezie_link ); ?>" class="oasi-btn oasi-btn--primary oasi-btn--lg">
					<span>Scopri le nostre Spezie Pure</span>
					<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
				</a>
			</div>
		</div>
	</div>
</section>
