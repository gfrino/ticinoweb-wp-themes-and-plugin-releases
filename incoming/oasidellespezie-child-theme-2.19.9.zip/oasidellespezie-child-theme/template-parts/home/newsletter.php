<?php
/**
 * Newsletter Subscription Banner Template Part.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section class="oasi-newsletter" aria-label="<?php esc_attr_e( 'Iscrizione alla newsletter', 'oasidellespezie-child-theme' ); ?>">
	<div class="oasi-container">
		<div class="oasi-newsletter__inner">
			<div class="oasi-newsletter__brand">
				<div class="oasi-newsletter__icon" aria-hidden="true">
					<svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
						<path d="M10 2v4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V2"></path>
						<rect x="4" y="8" width="6" height="14" rx="1"></rect>
						<path d="M18 6v2a2 2 0 0 1-2 2h-2"></path>
						<rect x="14" y="10" width="6" height="12" rx="1"></rect>
					</svg>
				</div>
				<h2 class="oasi-newsletter__title">
					Scopri iscrivendoti alla newsletter
				</h2>
			</div>

			<form class="oasi-newsletter__form" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" onsubmit="event.preventDefault(); this.querySelector('.oasi-newsletter__success').style.display='block'; this.querySelector('.oasi-newsletter__fields').style.display='none';">
				<div class="oasi-newsletter__fields">
					<label for="oasi-newsletter-email" class="screen-reader-text"><?php esc_html_e( 'Il tuo indirizzo email', 'oasidellespezie-child-theme' ); ?></label>
					<input type="email" id="oasi-newsletter-email" name="email" required placeholder="<?php esc_attr_e( 'La tua email...', 'oasidellespezie-child-theme' ); ?>" class="oasi-newsletter__input">
					<button type="submit" class="oasi-newsletter__submit">
						<span><?php esc_html_e( 'Iscriviti', 'oasidellespezie-child-theme' ); ?></span>
					</button>
				</div>
				<div class="oasi-newsletter__success" style="display: none;" role="status">
					<p><?php esc_html_e( 'Grazie per esserti iscritto! Riceverai le nostre novità aromatiche e offerte riservate.', 'oasidellespezie-child-theme' ); ?></p>
				</div>
				<p class="oasi-newsletter__privacy">
					<?php esc_html_e( 'Niente spam. Puoi disiscriverti in qualsiasi momento.', 'oasidellespezie-child-theme' ); ?>
				</p>
			</form>
		</div>
	</div>
</section>
