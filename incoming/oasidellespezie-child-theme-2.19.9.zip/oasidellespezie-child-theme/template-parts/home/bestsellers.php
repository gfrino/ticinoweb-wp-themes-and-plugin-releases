<?php
/**
 * Bestsellers Product Showcase Template Part - 4 + 4 Masonry Grid.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bestseller_showcase = function_exists( 'oasi_get_home_bestseller_showcase_products' )
	? oasi_get_home_bestseller_showcase_products()
	: array( 'row1' => array(), 'row2' => array() );

$bestsellers_r1 = array_slice( $bestseller_showcase['row1'], 0, 4 );
$bestsellers_r2 = array_slice( $bestseller_showcase['row2'], 0, 4 );

if ( empty( $bestsellers_r1 ) && empty( $bestsellers_r2 ) ) {
	return;
}

$shop_url = function_exists( 'wc_get_page_id' ) && wc_get_page_id( 'shop' ) > 0
	? get_permalink( wc_get_page_id( 'shop' ) )
	: home_url( '/shop-online-oasi-delle-spezie/' );
?>
<section class="oasi-bestsellers oasi-section oasi-section--bg-light" aria-labelledby="oasi-bestsellers-title">
	<div class="oasi-container">
		<div class="oasi-section-header">
			<h2 id="oasi-bestsellers-title" class="oasi-section-title">
				<?php echo esc_html( (string) get_option( 'oasi_home_bestseller_title', 'Novità e prodotti Best-Seller' ) ); ?>
			</h2>
			<div class="oasi-section-divider"></div>
		</div>

		<!-- Bestsellers Grid: 4 prodotti riga 1 + 4 prodotti riga 2 -->
		<div class="oasi-bestsellers-grid oasi-bestsellers-masonry" aria-label="<?php esc_attr_e( 'Vetrina prodotti bestseller', 'oasidellespezie-child-theme' ); ?>">
			<?php if ( ! empty( $bestsellers_r1 ) ) : ?>
				<div class="oasi-bestsellers-row oasi-bestsellers-row--1" role="region" aria-label="<?php esc_attr_e( 'Bestseller selezione uno', 'oasidellespezie-child-theme' ); ?>">
					<?php foreach ( $bestsellers_r1 as $index => $product ) : ?>
						<div class="oasi-bestsellers-col">
							<?php oasi_render_bestseller_masonry_card( $product, (int) $index, 1 ); ?>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<?php if ( ! empty( $bestsellers_r2 ) ) : ?>
				<div class="oasi-bestsellers-row oasi-bestsellers-row--2" role="region" aria-label="<?php esc_attr_e( 'Bestseller selezione due', 'oasidellespezie-child-theme' ); ?>">
					<?php foreach ( $bestsellers_r2 as $index => $product ) : ?>
						<div class="oasi-bestsellers-col">
							<?php oasi_render_bestseller_masonry_card( $product, (int) $index, 2 ); ?>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>

		<div class="oasi-section-footer">
			<a href="<?php echo esc_url( $shop_url ); ?>" class="oasi-btn oasi-btn--primary">
				<span><?php esc_html_e( 'Esplora tutto il catalogo', 'oasidellespezie-child-theme' ); ?></span>
				<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
			</a>
		</div>
	</div>
</section>
