<?php
/**
 * Gift Boxes & Sets Template Part.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$gift_boxes = oasi_get_gift_boxes();
if ( empty( $gift_boxes ) ) {
	return;
}

$gift_term = get_term_by( 'slug', 'idee-regalo', 'product_cat' );
$gift_link = $gift_term ? get_term_link( $gift_term ) : home_url( '/categoria-prodotto/idee-regalo/' );
?>
<section class="oasi-gift-boxes oasi-section oasi-section--bg-sand" aria-labelledby="oasi-gifts-title">
	<div class="oasi-container">
		<div class="oasi-section-header">
			<span class="oasi-section-eyebrow">Cofanetti & Confezioni Artigianali</span>
			<h2 id="oasi-gifts-title" class="oasi-section-title">
				Scoprite le nostre idee regalo...
			</h2>
			<div class="oasi-section-divider"></div>
			<p class="oasi-gift-boxes__subtitle">
				Cambiamo le nostre abitudini! Un regalo originale fa sempre piacere!
			</p>
		</div>

		<div class="oasi-products-grid oasi-products-grid--5cols">
			<?php foreach ( $gift_boxes as $product ) : ?>
				<?php oasi_render_product_card( $product, 'Idea Regalo' ); ?>
			<?php endforeach; ?>
		</div>

		<div class="oasi-section-footer">
			<a href="<?php echo esc_url( $gift_link ); ?>" class="oasi-btn oasi-btn--warm">
				<span>Scopri altre nostre idee regalo</span>
				<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
			</a>
		</div>
	</div>
</section>
