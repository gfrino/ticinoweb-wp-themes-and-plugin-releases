<?php
/**
 * MIXTIS Organic Creations Template Part.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mixtis_products = oasi_get_mixtis_products();
if ( empty( $mixtis_products ) ) {
	return;
}

$mixtis_term = get_term_by( 'slug', 'miscele-di-spezie-bio', 'product_cat' );
$mixtis_link = $mixtis_term ? get_term_link( $mixtis_term ) : home_url( '/categoria-prodotto/miscele-di-spezie-bio/' );
?>
<section class="oasi-mixtis oasi-section" aria-labelledby="oasi-mixtis-title">
	<div class="oasi-container">
		<div class="oasi-section-header">
			<span class="oasi-section-eyebrow">Creazioni Esclusive Artigianali</span>
			<h2 id="oasi-mixtis-title" class="oasi-section-title">
				Nostre creazioni "MIXTIS" bio
			</h2>
			<div class="oasi-section-divider"></div>
			<p class="oasi-section-subtitle oasi-mixtis__intro">
				La macinazione de le nostre miscele di spezie della "Linea Mixtis" (interamente biologica) è fatta in piccola quantità, in modo da poter rinnovare regolarmente il nostro stock. Questo ci permette di offrirvi miscele di spezie biologiche recentemente macinate, per garantire la massima freschezza mantenendo i loro sapori, olii essenziali, vitamine e minerali!
			</p>
		</div>

		<div class="oasi-products-grid oasi-products-grid--5cols">
			<?php foreach ( $mixtis_products as $product ) : ?>
				<?php oasi_render_product_card( $product, 'MIXTIS Bio', __( 'Scegli', 'oasidellespezie-child-theme' ) ); ?>
			<?php endforeach; ?>
		</div>

		<div class="oasi-section-footer">
			<a href="<?php echo esc_url( $mixtis_link ); ?>" class="oasi-btn oasi-btn--outline">
				<span>Esplora tutte le Miscele MIXTIS</span>
				<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
			</a>
		</div>
	</div>
</section>
