<?php
/**
 * Contact form, handled by the parent theme (inc/form-handler.php).
 *
 * The page may be served from cache for days, so no nonce is printed here: the
 * script asks the parent for a fresh token (ticinoweb_form_token) right before
 * sending to ticinoweb_submit_form. The parent validates, applies honeypot,
 * rate limit and optional reCAPTCHA, stores the message in "Invii Ricevuti"
 * and emails the site's contact address.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$privacy_url = function_exists( 'oasi_contact_get_privacy_url' ) ? oasi_contact_get_privacy_url() : '';
?>
<section class="oasi-contact-form-section" aria-labelledby="oasi-contact-form-title">
	<div class="oasi-contact-form-section__intro">
		<span class="oasi-contact-eyebrow"><?php esc_html_e( 'Scrivici', 'oasidellespezie-child-theme' ); ?></span>
		<h2 id="oasi-contact-form-title" class="oasi-contact-form-section__title"><?php esc_html_e( 'Inviaci un messaggio', 'oasidellespezie-child-theme' ); ?></h2>
		<p><?php esc_html_e( 'Domande su un prodotto, un ordine o una richiesta particolare: ti rispondiamo di solito entro un giorno lavorativo.', 'oasidellespezie-child-theme' ); ?></p>
	</div>

	<form class="oasi-contact-form" data-oasi-contact-form data-ajax-url="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>" novalidate>
		<div class="oasi-contact-form__grid">
			<p class="oasi-contact-form__field">
				<label for="oasi-cf-nome"><?php esc_html_e( 'Nome e cognome', 'oasidellespezie-child-theme' ); ?> <span aria-hidden="true">*</span></label>
				<input type="text" id="oasi-cf-nome" name="nome" autocomplete="name" required maxlength="120">
				<span class="oasi-contact-form__error" data-error-for="nome" role="alert"></span>
			</p>
			<p class="oasi-contact-form__field">
				<label for="oasi-cf-email"><?php esc_html_e( 'Email', 'oasidellespezie-child-theme' ); ?> <span aria-hidden="true">*</span></label>
				<input type="email" id="oasi-cf-email" name="email" autocomplete="email" required maxlength="190">
				<span class="oasi-contact-form__error" data-error-for="email" role="alert"></span>
			</p>
			<p class="oasi-contact-form__field">
				<label for="oasi-cf-telefono"><?php esc_html_e( 'Telefono (facoltativo)', 'oasidellespezie-child-theme' ); ?></label>
				<input type="tel" id="oasi-cf-telefono" name="telefono" autocomplete="tel" maxlength="40">
			</p>
			<p class="oasi-contact-form__field">
				<label for="oasi-cf-oggetto"><?php esc_html_e( 'Oggetto (facoltativo)', 'oasidellespezie-child-theme' ); ?></label>
				<input type="text" id="oasi-cf-oggetto" name="oggetto" maxlength="150">
			</p>
			<p class="oasi-contact-form__field oasi-contact-form__field--full">
				<label for="oasi-cf-messaggio"><?php esc_html_e( 'Messaggio', 'oasidellespezie-child-theme' ); ?> <span aria-hidden="true">*</span></label>
				<textarea id="oasi-cf-messaggio" name="messaggio" rows="6" required minlength="5" maxlength="5000"></textarea>
				<span class="oasi-contact-form__error" data-error-for="messaggio" role="alert"></span>
			</p>
		</div>

		<p class="oasi-contact-form__hp" aria-hidden="true">
			<label for="oasi-cf-hp"><?php esc_html_e( 'Lascia vuoto questo campo', 'oasidellespezie-child-theme' ); ?></label>
			<input type="text" id="oasi-cf-hp" name="tw_hp" tabindex="-1" autocomplete="off">
		</p>

		<p class="oasi-contact-form__privacy">
			<label>
				<input type="checkbox" name="privacy" value="1" required>
				<span>
					<?php
					if ( $privacy_url ) {
						printf(
							/* translators: %s: privacy policy link. */
							esc_html__( 'Ho letto l’%s: i dati inviati servono solo a rispondere alla mia richiesta.', 'oasidellespezie-child-theme' ),
							'<a href="' . esc_url( $privacy_url ) . '" target="_blank" rel="noopener">' . esc_html__( 'informativa sulla privacy', 'oasidellespezie-child-theme' ) . '</a>'
						);
					} else {
						esc_html_e( 'Ho letto l’informativa sulla privacy: i dati inviati servono solo a rispondere alla mia richiesta.', 'oasidellespezie-child-theme' );
					}
					?>
				</span>
			</label>
			<span class="oasi-contact-form__error" data-error-for="privacy" role="alert"></span>
		</p>

		<div class="oasi-contact-form__actions">
			<button type="submit" class="oasi-contact-form__submit"><?php esc_html_e( 'Invia il messaggio', 'oasidellespezie-child-theme' ); ?></button>
			<p class="oasi-contact-form__status" data-oasi-contact-status role="status" aria-live="polite"></p>
		</div>
	</form>
</section>
