<?php
/**
 * Post card for blog archives and search results (News page styling).
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$post_id     = get_the_ID();
$permalink   = get_permalink( $post_id );
$primary_cat = function_exists( 'oasi_news_get_primary_category' ) ? oasi_news_get_primary_category( $post_id ) : null;
$excerpt     = function_exists( 'oasi_news_get_clean_excerpt' ) ? oasi_news_get_clean_excerpt( $post_id, 20 ) : wp_trim_words( get_the_excerpt(), 20 );
$is_post     = 'post' === get_post_type( $post_id );
?>
<article class="oasi-news-card oasi-news-card--duo" id="post-<?php echo esc_attr( (string) $post_id ); ?>">
	<?php if ( has_post_thumbnail( $post_id ) ) : ?>
		<div class="oasi-news-card__media">
			<a href="<?php echo esc_url( $permalink ); ?>" class="oasi-news-card__media-link" tabindex="-1" aria-hidden="true">
				<?php
				echo function_exists( 'oasi_news_get_featured_image_html' )
					? oasi_news_get_featured_image_html( $post_id, 'large' ) // phpcs:ignore WordPress.Security.EscapeOutput -- escaped by the helper.
					: get_the_post_thumbnail( $post_id, 'large' );
				?>
			</a>
		</div>
	<?php endif; ?>
	<div class="oasi-news-card__body">
		<?php if ( $is_post ) : ?>
			<div class="oasi-news-card__meta">
				<?php if ( $primary_cat ) : ?>
					<span class="oasi-news-card__category"><?php echo esc_html( $primary_cat->name ); ?></span>
					<span class="oasi-news-card__meta-separator" aria-hidden="true">&bull;</span>
				<?php endif; ?>
				<time class="oasi-news-card__date" datetime="<?php echo esc_attr( get_the_date( 'c', $post_id ) ); ?>"><?php echo esc_html( get_the_date( '', $post_id ) ); ?></time>
			</div>
		<?php endif; ?>
		<h2 class="oasi-news-card__title">
			<a href="<?php echo esc_url( $permalink ); ?>" class="oasi-news-card__title-link"><?php the_title(); ?></a>
		</h2>
		<?php if ( '' !== (string) $excerpt ) : ?>
			<p class="oasi-news-card__excerpt"><?php echo esc_html( $excerpt ); ?></p>
		<?php endif; ?>
		<div class="oasi-news-card__footer">
			<a href="<?php echo esc_url( $permalink ); ?>" class="oasi-news-card__action"><?php esc_html_e( 'Leggi', 'oasidellespezie-child-theme' ); ?> <span aria-hidden="true">→</span></a>
		</div>
	</div>
</article>
