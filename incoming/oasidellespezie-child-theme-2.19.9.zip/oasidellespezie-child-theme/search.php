<?php
/**
 * Site search results (blog and pages); products are searched from the shop.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$shop_url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );
?>
<div class="oasi-news-page">
	<div class="oasi-container">
		<header class="oasi-news-intro">
			<span class="oasi-news-intro__kicker"><?php esc_html_e( 'Ricerca', 'oasidellespezie-child-theme' ); ?></span>
			<h1 class="oasi-news-intro__title">
				<?php
				/* translators: %s: search terms. */
				echo esc_html( sprintf( __( 'Risultati per “%s”', 'oasidellespezie-child-theme' ), get_search_query() ) );
				?>
			</h1>
			<p class="oasi-news-intro__desc">
				<?php esc_html_e( 'Cerchi una spezia o un prodotto?', 'oasidellespezie-child-theme' ); ?>
				<a href="<?php echo esc_url( add_query_arg( 'oasi_q', get_search_query(), $shop_url ) ); ?>"><?php esc_html_e( 'Cerca nel negozio', 'oasidellespezie-child-theme' ); ?></a>
			</p>
		</header>

		<?php if ( have_posts() ) : ?>
			<div class="oasi-news-grid">
				<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/archive/post-card' );
				endwhile;
				?>
			</div>
			<?php the_posts_pagination( array( 'mid_size' => 1 ) ); ?>
		<?php else : ?>
			<p><?php esc_html_e( 'Nessun risultato. Prova con altre parole o cerca direttamente nel negozio.', 'oasidellespezie-child-theme' ); ?></p>
		<?php endif; ?>
	</div>
</div>
<?php
get_footer();
