<?php
/**
 * Single article template for Oasi delle Spezie WordPress posts.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<div class="oasi-single-post">
	<?php while ( have_posts() ) :
		the_post();
		$post_id      = get_the_ID();
		$primary_cat  = oasi_news_get_primary_category( $post_id );
		$archive_url  = oasi_single_post_get_archive_url();
		$related_news = oasi_single_post_get_related_posts( $post_id );
		?>
		<article id="post-<?php echo esc_attr( (string) $post_id ); ?>" <?php post_class( 'oasi-single-post__article' ); ?>>
			<header class="oasi-single-post__header oasi-container">
				<div class="oasi-single-post__meta">
					<?php if ( $primary_cat ) :
						$category_url = get_category_link( $primary_cat );
						?>
						<a class="oasi-single-post__category" href="<?php echo esc_url( is_wp_error( $category_url ) ? $archive_url : $category_url ); ?>">
							<?php echo esc_html( $primary_cat->name ); ?>
						</a>
						<span aria-hidden="true">·</span>
					<?php endif; ?>
					<time datetime="<?php echo esc_attr( get_the_date( 'c', $post_id ) ); ?>">
						<?php echo esc_html( oasi_news_format_date( $post_id ) ); ?>
					</time>
				</div>

				<h1 class="oasi-single-post__title"><?php the_title(); ?></h1>

				<?php if ( has_excerpt( $post_id ) ) : ?>
					<p class="oasi-single-post__excerpt"><?php echo esc_html( get_the_excerpt( $post_id ) ); ?></p>
				<?php endif; ?>
			</header>

			<?php if ( has_post_thumbnail( $post_id ) ) : ?>
				<figure class="oasi-single-post__featured oasi-container">
					<?php the_post_thumbnail( 'large', array( 'class' => 'oasi-single-post__featured-image', 'loading' => 'eager', 'fetchpriority' => 'high' ) ); ?>
					<?php if ( wp_get_attachment_caption( get_post_thumbnail_id( $post_id ) ) ) : ?>
						<figcaption><?php echo esc_html( wp_get_attachment_caption( get_post_thumbnail_id( $post_id ) ) ); ?></figcaption>
					<?php endif; ?>
				</figure>
			<?php endif; ?>

			<div class="oasi-single-post__content oasi-container">
				<?php
				the_content();
				wp_link_pages(
					array(
						'before' => '<nav class="oasi-single-post__pages" aria-label="' . esc_attr__( 'Pagine dell’articolo', 'oasidellespezie-child-theme' ) . '">',
						'after'  => '</nav>',
					)
				);
				?>
			</div>

			<footer class="oasi-single-post__footer oasi-container">
				<a class="oasi-single-post__back" href="<?php echo esc_url( $archive_url ); ?>">
					<span aria-hidden="true">←</span>
					<?php esc_html_e( 'Torna a tutte le novità', 'oasidellespezie-child-theme' ); ?>
				</a>
			</footer>
		</article>

		<?php if ( $related_news->have_posts() ) : ?>
			<section class="oasi-single-post__related" aria-labelledby="oasi-related-title">
				<div class="oasi-container">
					<header class="oasi-single-post__related-header">
						<span><?php esc_html_e( 'Continua a scoprire', 'oasidellespezie-child-theme' ); ?></span>
						<h2 id="oasi-related-title"><?php esc_html_e( 'Dal mondo di Oasi', 'oasidellespezie-child-theme' ); ?></h2>
					</header>
					<div class="oasi-single-post__related-grid">
						<?php while ( $related_news->have_posts() ) :
							$related_news->the_post();
							$related_id  = get_the_ID();
							$related_cat = oasi_news_get_primary_category( $related_id );
							?>
							<article class="oasi-single-post__related-card">
								<?php if ( has_post_thumbnail( $related_id ) ) : ?>
									<a class="oasi-single-post__related-media" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
										<?php the_post_thumbnail( 'medium_large', array( 'loading' => 'lazy' ) ); ?>
									</a>
								<?php endif; ?>
								<div class="oasi-single-post__related-copy">
									<div class="oasi-single-post__related-meta">
										<?php if ( $related_cat ) : ?><span><?php echo esc_html( $related_cat->name ); ?></span><?php endif; ?>
										<time datetime="<?php echo esc_attr( get_the_date( 'c', $related_id ) ); ?>"><?php echo esc_html( oasi_news_format_date( $related_id ) ); ?></time>
									</div>
									<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
									<a class="oasi-single-post__related-link" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Leggi', 'oasidellespezie-child-theme' ); ?> <span aria-hidden="true">→</span></a>
								</div>
							</article>
						<?php endwhile; ?>
					</div>
				</div>
			</section>
		<?php endif; ?>
		<?php wp_reset_postdata(); ?>
	<?php endwhile; ?>
</div>

<?php get_footer(); ?>
