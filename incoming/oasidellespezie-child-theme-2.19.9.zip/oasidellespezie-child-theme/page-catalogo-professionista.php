<?php
/**
 * Template Name: Oasi — Area Professionisti
 *
 * THESIS: un accesso B2B chiaro e concreto, non una seconda vetrina prodotti.
 * OWN-WORLD: carta naturale, terracotta, oro e dettagli scuri ereditati dalla Home.
 * STORY: comprendere l'offerta, verificare il proprio stato e consultare le condizioni.
 * FIRST VIEWPORT: messaggio e azioni a sinistra, fotografia reale del laboratorio a destra.
 * FORM: pagina editoriale compatta, con accesso e condizioni progressive.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$access_state = oasi_professional_get_access_state();
$contact      = oasi_get_contact_data();
$register_url = oasi_professional_get_register_url();
$account_url  = oasi_professional_get_account_url();
$shop_url     = oasi_professional_get_shop_url();
$contact_url  = oasi_professional_get_contact_url();
$application_url = function_exists( 'oasi_professional_application_get_url' ) ? oasi_professional_application_get_url() : $contact_url;
$image_html   = oasi_professional_get_image_html();
$content      = function_exists( 'oasi_get_professional_content' ) ? oasi_get_professional_content() : array(
	'kicker' => 'Area professionisti', 'title' => 'Soluzioni dedicate ai professionisti',
	'lead' => 'Una selezione di spezie, erbe, pepi e sali per ristorazione, laboratori e attività che cercano materie prime scelte con cura.',
	'intro' => 'Siamo un laboratorio artigianale, non un negozio su strada: prepariamo gli ordini con attenzione e lavoriamo con un listino riservato agli account professionali approvati.',
	'fact_access' => 'Accesso verificato', 'fact_catalog' => 'Listino nel normale Shop', 'fact_preparation' => 'Preparazione artigianale',
	'image_eyebrow' => 'Selezione Oasi', 'image_caption' => 'Materie prime scelte per il lavoro quotidiano',
	'guest_access_label' => 'Accesso da attivare', 'guest_access_title' => 'Richiedi il tuo account professionale', 'guest_access_body' => 'Registrati attraverso il modulo già predisposto. Il laboratorio verificherà la richiesta prima di abilitare il listino riservato.', 'guest_primary_cta' => 'Registrati come professionista', 'guest_secondary_cta' => 'Accedi all’area riservata',
	'customer_access_label' => 'Accesso professionale', 'customer_access_title' => 'Completa il formulario per richiedere l’accesso professionale', 'customer_access_body' => 'Il tuo account è già attivo. Clicca sul pulsante rosso “Richiedi la verifica professionale” e completa il formulario con i dati della tua attività. Esamineremo la richiesta e ti contatteremo via email.', 'customer_primary_cta' => 'Richiedi la verifica professionale',
	'professional_access_label' => 'Accesso professionale attivo', 'professional_access_title' => 'Il tuo catalogo riservato è pronto', 'professional_access_body' => 'Accedi allo Shop con questo account: prezzi e disponibilità professionali vengono applicati direttamente dal sistema wholesale esistente.', 'professional_primary_cta' => 'Accedi al catalogo professionale',
	'conditions_kicker' => 'Informazioni prima dell’ordine', 'conditions_title' => 'Condizioni per professionisti',
	'conditions_intro' => 'Le condizioni già pubblicate sono qui raccolte in un unico punto, senza cambiare il funzionamento commerciale del sito.',
	'conditions_cta_label' => 'Hai una richiesta specifica? Contattaci', 'conditions_cta_url' => '',
	'trust_territory_label' => 'Territorio', 'trust_territory_value' => 'Svizzera e Liechtenstein', 'trust_payment_label' => 'Pagamento', 'trust_payment_value' => 'Anticipato per ogni ordine', 'trust_preparation_label' => 'Preparazione', 'trust_preparation_value' => 'Artigianale, da ordinare in anticipo', 'trust_assistance_label' => 'Assistenza',
	'conditions' => array(
		array( 'title' => 'Ordini', 'body' => 'Effettuiamo ordini professionali esclusivamente in Svizzera e Liechtenstein. L’accesso al listino riservato richiede registrazione e approvazione.' ),
		array( 'title' => 'Pagamenti', 'body' => 'Per ogni ordine professionale è richiesto il pagamento anticipato.' ),
		array( 'title' => 'Preparazione ed erbe', 'body' => 'Le erbe aromatiche vengono selezionate a mano; possono rimanere alcuni rami o rametti. La lavorazione richiede tempo, quindi consigliamo di ordinare con largo anticipo.' ),
		array( 'title' => 'Spedizione', 'body' => 'Per i clienti professionali le spese di spedizione sono variabili secondo il peso della merce.' ),
	),
);
$phone        = isset( $contact['phone'] ) ? (string) $contact['phone'] : '';
$phone_tel    = isset( $contact['phone_tel'] ) ? (string) $contact['phone_tel'] : '';
$hours_short  = isset( $contact['hours_short'] ) ? (string) $contact['hours_short'] : '';

if ( 'guest' === $access_state ) {
	$access_label = $content['guest_access_label'];
	$access_title = $content['guest_access_title'];
	$access_text  = $content['guest_access_body'];
} elseif ( 'customer' === $access_state ) {
	$access_label = $content['customer_access_label'];
	$access_title = $content['customer_access_title'];
	$access_text  = $content['customer_access_body'];
} else {
	$access_label = $content['professional_access_label'];
	$access_title = $content['professional_access_title'];
	$access_text  = $content['professional_access_body'];
}

?>

<div id="primary" class="site-main oasi-professional">
	<section class="oasi-professional-intro" aria-labelledby="oasi-professional-title">
		<div class="oasi-container oasi-professional-intro__grid">
			<div class="oasi-professional-intro__copy">
				<span class="oasi-professional-kicker"><?php echo esc_html( $content['kicker'] ); ?></span>
				<h1 id="oasi-professional-title"><?php echo esc_html( $content['title'] ); ?></h1>
				<p class="oasi-professional-intro__lead"><?php echo esc_html( $content['lead'] ); ?></p>
				<p><?php echo nl2br( esc_html( $content['intro'] ) ); ?></p>

				<ul class="oasi-professional-intro__facts" aria-label="<?php esc_attr_e( 'Caratteristiche dell’offerta professionale', 'oasidellespezie-child-theme' ); ?>">
					<li>
						<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 4 7v5c0 4.7 3.2 8.6 8 10 4.8-1.4 8-5.3 8-10V7l-8-4Z"/><path d="m8.5 12 2.2 2.2 4.8-5"/></svg>
						<span><?php echo esc_html( $content['fact_access'] ); ?></span>
					</li>
					<li>
						<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16v12H4z"/><path d="M8 7V5h8v2M8 12h8"/></svg>
						<span><?php echo esc_html( $content['fact_catalog'] ); ?></span>
					</li>
					<li>
						<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s7-3.8 7-10V5l-7-2-7 2v6c0 6.2 7 10 7 10Z"/><path d="M9 12c2.5 0 4-1.5 6-4 0 4-1.5 7-5 7"/></svg>
						<span><?php echo esc_html( $content['fact_preparation'] ); ?></span>
					</li>
				</ul>
			</div>

			<?php if ( '' !== $image_html ) : ?>
				<figure class="oasi-professional-intro__visual">
					<?php echo wp_kses_post( $image_html ); ?>
					<figcaption>
						<span><?php echo esc_html( $content['image_eyebrow'] ); ?></span>
						<strong><?php echo esc_html( $content['image_caption'] ); ?></strong>
					</figcaption>
				</figure>
			<?php endif; ?>
		</div>
	</section>

	<section class="oasi-professional-access oasi-professional-access--<?php echo esc_attr( $access_state ); ?>" aria-labelledby="oasi-professional-access-title">
		<div class="oasi-container oasi-professional-access__inner">
			<div class="oasi-professional-access__copy">
				<div class="oasi-professional-access__status" aria-hidden="true">
					<span></span>
					<?php echo esc_html( $access_label ); ?>
				</div>
				<h2 id="oasi-professional-access-title"><?php echo esc_html( $access_title ); ?></h2>
				<p><?php echo esc_html( $access_text ); ?></p>
			</div>
			<div class="oasi-professional-access__actions">
				<?php if ( 'guest' === $access_state ) : ?>
					<a class="oasi-btn oasi-btn--primary" href="<?php echo esc_url( $register_url ); ?>">
						<span><?php echo esc_html( $content['guest_primary_cta'] ); ?></span>
						<span aria-hidden="true">→</span>
					</a>
					<a class="oasi-btn oasi-btn--secondary" href="<?php echo esc_url( $account_url ); ?>"><?php echo esc_html( $content['guest_secondary_cta'] ); ?></a>
				<?php elseif ( 'customer' === $access_state ) : ?>
					<a class="oasi-btn oasi-btn--primary" href="<?php echo esc_url( $application_url ); ?>">
						<span><?php echo esc_html( $content['customer_primary_cta'] ); ?></span>
						<span aria-hidden="true">→</span>
					</a>
				<?php else : ?>
					<a class="oasi-btn oasi-btn--primary" href="<?php echo esc_url( $shop_url ); ?>">
						<span><?php echo esc_html( $content['professional_primary_cta'] ); ?></span>
						<span aria-hidden="true">→</span>
					</a>
				<?php endif; ?>
			</div>
		</div>
	</section>

	<section id="condizioni" class="oasi-professional-conditions" aria-labelledby="oasi-professional-conditions-title">
		<div class="oasi-container oasi-professional-conditions__grid">
			<header class="oasi-professional-conditions__header">
				<span><?php echo esc_html( $content['conditions_kicker'] ); ?></span>
				<h2 id="oasi-professional-conditions-title"><?php echo esc_html( $content['conditions_title'] ); ?></h2>
				<p><?php echo esc_html( $content['conditions_intro'] ); ?></p>
				<a href="<?php echo esc_url( $content['conditions_cta_url'] ?: $contact_url ); ?>"><?php echo esc_html( $content['conditions_cta_label'] ); ?> <span aria-hidden="true">↗</span></a>
			</header>

			<?php if ( ! empty( $content['conditions'] ) ) : ?>
				<div class="oasi-professional-accordion" data-oasi-professional-accordion>
					<?php foreach ( $content['conditions'] as $index => $condition ) : ?>
						<?php $condition_id = 'oasi-professional-condition-' . ( $index + 1 ); ?>
						<div class="oasi-professional-accordion__item">
							<h3><button type="button" class="oasi-professional-accordion__button" id="<?php echo esc_attr( $condition_id ); ?>" aria-expanded="true" aria-controls="<?php echo esc_attr( $condition_id . '-panel' ); ?>"><span><small><?php echo esc_html( sprintf( '%02d', $index + 1 ) ); ?></small><?php echo esc_html( $condition['title'] ); ?></span><span class="oasi-professional-accordion__mark" aria-hidden="true"></span></button></h3>
							<div class="oasi-professional-accordion__panel" id="<?php echo esc_attr( $condition_id . '-panel' ); ?>" role="region" aria-labelledby="<?php echo esc_attr( $condition_id ); ?>" aria-hidden="false"><p><?php echo nl2br( esc_html( $condition['body'] ) ); ?></p></div>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
	</section>

	<section class="oasi-professional-trust" aria-label="<?php esc_attr_e( 'Servizi per clienti professionali', 'oasidellespezie-child-theme' ); ?>">
		<div class="oasi-container oasi-professional-trust__grid">
			<div><strong><?php echo esc_html( $content['trust_territory_label'] ); ?></strong><span><?php echo esc_html( $content['trust_territory_value'] ); ?></span></div>
			<div><strong><?php echo esc_html( $content['trust_payment_label'] ); ?></strong><span><?php echo esc_html( $content['trust_payment_value'] ); ?></span></div>
			<div><strong><?php echo esc_html( $content['trust_preparation_label'] ); ?></strong><span><?php echo esc_html( $content['trust_preparation_value'] ); ?></span></div>
			<div>
				<strong><?php echo esc_html( $content['trust_assistance_label'] ); ?></strong>
				<?php if ( '' !== $phone && '' !== $phone_tel ) : ?>
					<a href="tel:<?php echo esc_attr( $phone_tel ); ?>"><?php echo esc_html( $phone ); ?></a>
				<?php endif; ?>
				<?php if ( '' !== $hours_short ) : ?><span><?php echo esc_html( $hours_short ); ?></span><?php endif; ?>
			</div>
		</div>
	</section>
</div>

<?php get_footer(); ?>
