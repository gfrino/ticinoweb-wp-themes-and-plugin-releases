<?php
/**
 * Template Name: Oasi — Richiesta professionale
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$state   = oasi_professional_get_access_state();
$user    = is_user_logged_in() ? wp_get_current_user() : null;
$account = $user instanceof WP_User ? oasi_professional_application_get_account_data( $user->ID ) : array();
$pending = $user instanceof WP_User && 'pending' === get_user_meta( $user->ID, 'oasi_professional_request_status', true );
$status  = isset( $_GET['application_status'] ) ? sanitize_key( wp_unslash( (string) $_GET['application_status'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only redirect status.
$security = oasi_professional_application_security_fields();
$privacy_url = function_exists( 'oasi_legal_get_page_url' ) ? oasi_legal_get_page_url( 'privacy-policy' ) : get_privacy_policy_url();
$professional_page = get_page_by_path( 'catalogo-professionista', OBJECT, 'page' );
$professional_url  = $professional_page instanceof WP_Post ? get_permalink( $professional_page ) : home_url( '/catalogo-professionista/' );

get_header();
?>
<div id="primary" class="site-main oasi-application">
	<section class="oasi-application__hero" aria-labelledby="application-title">
		<div class="oasi-container oasi-application__hero-grid">
			<div>
				<a class="oasi-application__back" href="<?php echo esc_url( $professional_url ); ?>">← <?php esc_html_e( 'Area professionisti', 'oasidellespezie-child-theme' ); ?></a>
				<span class="oasi-application__kicker"><?php esc_html_e( 'Verifica professionale', 'oasidellespezie-child-theme' ); ?></span>
				<h1 id="application-title"><?php esc_html_e( 'Raccontaci la tua attività', 'oasidellespezie-child-theme' ); ?></h1>
				<p><?php esc_html_e( 'Una richiesta completa ci aiuta a valutare rapidamente l’accesso al catalogo e alle condizioni dedicate ai professionisti.', 'oasidellespezie-child-theme' ); ?></p>
			</div>
			<ol aria-label="<?php esc_attr_e( 'Fasi della verifica', 'oasidellespezie-child-theme' ); ?>">
				<li><span>01</span><strong><?php esc_html_e( 'Dati account', 'oasidellespezie-child-theme' ); ?></strong></li>
				<li><span>02</span><strong><?php esc_html_e( 'Profilo attività', 'oasidellespezie-child-theme' ); ?></strong></li>
				<li><span>03</span><strong><?php esc_html_e( 'Verifica manuale', 'oasidellespezie-child-theme' ); ?></strong></li>
			</ol>
		</div>
	</section>

	<div class="oasi-container oasi-application__layout" id="richiesta-professionale">
		<?php if ( 'guest' === $state ) : ?>
			<section class="oasi-application__state">
				<span><?php esc_html_e( 'Accesso richiesto', 'oasidellespezie-child-theme' ); ?></span>
				<h2><?php esc_html_e( 'Accedi prima di compilare la richiesta', 'oasidellespezie-child-theme' ); ?></h2>
				<p><?php esc_html_e( 'Il modulo riutilizza i dati del tuo account per evitare duplicati e proteggere la richiesta.', 'oasidellespezie-child-theme' ); ?></p>
				<a href="<?php echo esc_url( oasi_professional_get_account_url() ); ?>"><?php esc_html_e( 'Accedi al mio account', 'oasidellespezie-child-theme' ); ?> →</a>
			</section>
		<?php elseif ( 'professional' === $state ) : ?>
			<section class="oasi-application__state">
				<span><?php esc_html_e( 'Accesso attivo', 'oasidellespezie-child-theme' ); ?></span>
				<h2><?php esc_html_e( 'Il tuo profilo è già professionale', 'oasidellespezie-child-theme' ); ?></h2>
				<p><?php esc_html_e( 'Non serve inviare una nuova richiesta: prezzi e condizioni riservate vengono applicati nello Shop.', 'oasidellespezie-child-theme' ); ?></p>
				<a href="<?php echo esc_url( oasi_professional_get_shop_url() ); ?>"><?php esc_html_e( 'Apri lo Shop', 'oasidellespezie-child-theme' ); ?> →</a>
			</section>
		<?php elseif ( $pending || 'sent' === $status ) : ?>
			<section class="oasi-application__state oasi-application__state--success" aria-live="polite">
				<span><?php esc_html_e( 'Richiesta ricevuta', 'oasidellespezie-child-theme' ); ?></span>
				<h2><?php esc_html_e( 'La verifica è in corso', 'oasidellespezie-child-theme' ); ?></h2>
				<p><?php esc_html_e( 'Il laboratorio controllerà i dati e ti contatterà tramite l’email associata all’account. L’invio non attiva automaticamente il ruolo professionale.', 'oasidellespezie-child-theme' ); ?></p>
				<a href="<?php echo esc_url( oasi_professional_get_account_url() ); ?>"><?php esc_html_e( 'Torna al mio account', 'oasidellespezie-child-theme' ); ?> →</a>
			</section>
		<?php else : ?>
			<div class="oasi-application__main">
				<?php if ( $status ) : ?>
					<div class="oasi-application__alert" role="alert"><?php esc_html_e( 'Non è stato possibile inviare la richiesta. Controlla i campi e riprova tra qualche minuto.', 'oasidellespezie-child-theme' ); ?></div>
				<?php endif; ?>

				<section class="oasi-application__account" aria-labelledby="account-summary-title">
					<header><span>01</span><div><h2 id="account-summary-title"><?php esc_html_e( 'Dati del tuo account', 'oasidellespezie-child-theme' ); ?></h2><p><?php esc_html_e( 'Sono letti dal profilo esistente e non vengono richiesti una seconda volta.', 'oasidellespezie-child-theme' ); ?></p></div></header>
					<dl>
						<div><dt><?php esc_html_e( 'Referente', 'oasidellespezie-child-theme' ); ?></dt><dd><?php echo esc_html( $account['name'] ?: '—' ); ?></dd></div>
						<div><dt><?php esc_html_e( 'Azienda', 'oasidellespezie-child-theme' ); ?></dt><dd><?php echo esc_html( $account['company'] ?: 'Non indicata' ); ?></dd></div>
						<div><dt><?php esc_html_e( 'Email', 'oasidellespezie-child-theme' ); ?></dt><dd><?php echo esc_html( $account['email'] ?: '—' ); ?></dd></div>
						<div><dt><?php esc_html_e( 'Telefono', 'oasidellespezie-child-theme' ); ?></dt><dd><?php echo esc_html( $account['phone'] ?: 'Non indicato' ); ?></dd></div>
						<div class="oasi-application__wide"><dt><?php esc_html_e( 'Indirizzo di fatturazione', 'oasidellespezie-child-theme' ); ?></dt><dd><?php echo esc_html( $account['address'] ?: 'Non indicato' ); ?></dd></div>
					</dl>
					<a href="<?php echo esc_url( function_exists( 'wc_get_account_endpoint_url' ) ? wc_get_account_endpoint_url( 'edit-account' ) : oasi_professional_get_account_url() ); ?>"><?php esc_html_e( 'Aggiorna i dati nel mio account', 'oasidellespezie-child-theme' ); ?> ↗</a>
				</section>

				<form class="oasi-application__form" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" data-oasi-professional-form>
					<input type="hidden" name="action" value="oasi_professional_application_submit">
					<?php wp_nonce_field( 'oasi_professional_application_submit', 'oasi_professional_nonce' ); ?>
					<input type="hidden" name="oasi_professional_started_at" value="<?php echo esc_attr( $security['started_at'] ); ?>">
					<input type="hidden" name="oasi_professional_started_sig" value="<?php echo esc_attr( $security['started_sig'] ); ?>">
					<input type="hidden" name="oasi_professional_request_id" value="<?php echo esc_attr( $security['request_id'] ); ?>">
					<input type="hidden" name="oasi_professional_request_sig" value="<?php echo esc_attr( $security['request_sig'] ); ?>">
					<div class="oasi-application__trap" aria-hidden="true"><label for="company-fax">Fax</label><input id="company-fax" name="oasi_professional_company_fax" type="text" tabindex="-1" autocomplete="off"></div>

					<fieldset>
						<legend><span>02</span><strong><?php esc_html_e( 'Identità dell’attività', 'oasidellespezie-child-theme' ); ?></strong><small><?php esc_html_e( 'I campi contrassegnati sono obbligatori.', 'oasidellespezie-child-theme' ); ?></small></legend>
						<div class="oasi-application__grid">
							<label><?php esc_html_e( 'Numero UID / CHE', 'oasidellespezie-child-theme' ); ?> *<input name="company_uid" type="text" placeholder="CHE-123.456.789" maxlength="15" required autocomplete="off"></label>
							<label><?php esc_html_e( 'Forma giuridica', 'oasidellespezie-child-theme' ); ?> *<select name="legal_form" required><option value=""><?php esc_html_e( 'Seleziona', 'oasidellespezie-child-theme' ); ?></option><option value="ditta-individuale">Ditta individuale</option><option value="sagl">Sagl</option><option value="sa">SA</option><option value="associazione">Associazione</option><option value="ente-pubblico">Ente pubblico</option><option value="altra">Altra</option></select></label>
							<label><?php esc_html_e( 'Sito web', 'oasidellespezie-child-theme' ); ?><input name="website" type="url" placeholder="https://" maxlength="250" autocomplete="url"></label>
							<label><?php esc_html_e( 'Settore', 'oasidellespezie-child-theme' ); ?> *<select name="sector" required><option value=""><?php esc_html_e( 'Seleziona', 'oasidellespezie-child-theme' ); ?></option><option value="ristorazione">Ristorazione</option><option value="hotellerie">Hotellerie</option><option value="produzione">Produzione alimentare</option><option value="vendita">Commercio / vendita</option><option value="benessere">Benessere</option><option value="formazione">Formazione</option><option value="altro">Altro</option></select></label>
							<label class="oasi-application__wide"><?php esc_html_e( 'Descrivi brevemente l’attività', 'oasidellespezie-child-theme' ); ?> *<textarea name="activity" rows="5" maxlength="2000" required data-oasi-count></textarea><small><span data-oasi-count-value>0</span>/2000</small></label>
						</div>
					</fieldset>

					<fieldset>
						<legend><span>03</span><strong><?php esc_html_e( 'Esigenze commerciali', 'oasidellespezie-child-theme' ); ?></strong></legend>
						<div class="oasi-application__grid">
							<label><?php esc_html_e( 'Come utilizzerai i prodotti?', 'oasidellespezie-child-theme' ); ?> *<select name="customer_type" required><option value=""><?php esc_html_e( 'Seleziona', 'oasidellespezie-child-theme' ); ?></option><option value="utilizzatore">Uso nella mia attività</option><option value="rivenditore">Rivendita</option><option value="produttore">Produzione / trasformazione</option><option value="distributore">Distribuzione</option><option value="altro">Altro</option></select></label>
							<label><?php esc_html_e( 'Frequenza prevista', 'oasidellespezie-child-theme' ); ?> *<select name="order_frequency" required><option value=""><?php esc_html_e( 'Seleziona', 'oasidellespezie-child-theme' ); ?></option><option value="occasionale">Occasionale</option><option value="mensile">Mensile</option><option value="quindicinale">Quindicinale</option><option value="settimanale">Settimanale</option><option value="da-definire">Da definire</option></select></label>
							<label><?php esc_html_e( 'Valore indicativo per ordine', 'oasidellespezie-child-theme' ); ?><select name="order_value"><option value=""><?php esc_html_e( 'Preferisco non indicarlo', 'oasidellespezie-child-theme' ); ?></option><option value="fino-250">Fino a CHF 250</option><option value="250-500">CHF 250–500</option><option value="500-1000">CHF 500–1’000</option><option value="oltre-1000">Oltre CHF 1’000</option><option value="da-definire">Da definire</option></select></label>
							<div class="oasi-application__wide"><span class="oasi-application__label"><?php esc_html_e( 'Categorie di interesse', 'oasidellespezie-child-theme' ); ?> *</span><div class="oasi-application__choices"><?php foreach ( array( 'spezie'=>'Spezie', 'erbe'=>'Erbe aromatiche', 'peperoncini'=>'Peperoncini', 'pepi'=>'Pepi e bacche', 'sali'=>'Sali', 'miscele'=>'Miscele', 'regali'=>'Confezioni regalo' ) as $value => $label ) : ?><label><input type="checkbox" name="interests[]" value="<?php echo esc_attr( $value ); ?>"><span><?php echo esc_html( $label ); ?></span></label><?php endforeach; ?></div></div>
							<label class="oasi-application__wide"><?php esc_html_e( 'Altre informazioni utili', 'oasidellespezie-child-theme' ); ?><textarea name="message" rows="4" maxlength="2000" data-oasi-count></textarea><small><span data-oasi-count-value>0</span>/2000</small></label>
						</div>
					</fieldset>

					<div class="oasi-application__consents">
						<label><input type="checkbox" name="privacy" value="1" required><span><?php echo wp_kses_post( sprintf( __( 'Ho letto la <a href="%s" target="_blank" rel="noopener">Privacy Policy</a> e autorizzo il trattamento dei dati per valutare la richiesta.', 'oasidellespezie-child-theme' ), esc_url( $privacy_url ) ) ); ?> *</span></label>
						<label><input type="checkbox" name="truth" value="1" required><span><?php esc_html_e( 'Dichiaro che le informazioni fornite sono corrette e che sono autorizzato/a ad agire per l’attività indicata.', 'oasidellespezie-child-theme' ); ?> *</span></label>
					</div>
					<div class="oasi-application__submit"><div><strong><?php esc_html_e( 'Verifica manuale', 'oasidellespezie-child-theme' ); ?></strong><span><?php esc_html_e( 'L’invio non abilita automaticamente prezzi o ruoli professionali.', 'oasidellespezie-child-theme' ); ?></span></div><button type="submit"><?php esc_html_e( 'Invia la richiesta', 'oasidellespezie-child-theme' ); ?><span aria-hidden="true">→</span></button></div>
				</form>
			</div>

			<aside class="oasi-application__aside">
				<span><?php esc_html_e( 'Prima di inviare', 'oasidellespezie-child-theme' ); ?></span>
				<h2><?php esc_html_e( 'Cosa controlliamo', 'oasidellespezie-child-theme' ); ?></h2>
				<ul><li><?php esc_html_e( 'Coerenza tra account e attività', 'oasidellespezie-child-theme' ); ?></li><li><?php esc_html_e( 'UID e presenza professionale', 'oasidellespezie-child-theme' ); ?></li><li><?php esc_html_e( 'Tipologia d’uso e categorie richieste', 'oasidellespezie-child-theme' ); ?></li></ul>
				<p><?php esc_html_e( 'Potremo contattarti per chiarimenti. L’approvazione resta a discrezione del laboratorio e non richiede un nuovo account.', 'oasidellespezie-child-theme' ); ?></p>
			</aside>
		<?php endif; ?>
	</div>
</div>
<?php get_footer(); ?>
