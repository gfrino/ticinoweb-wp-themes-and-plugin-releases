/* Mappe di [chezhalima_map]: l'iframe di Google si crea solo al clic su «Mostra la mappa». */
(function () {
    document.querySelectorAll('.ch-map[data-src]').forEach(function (map) {
        var button = map.querySelector('.ch-map__load');
        if (!button) {
            return;
        }
        button.addEventListener('click', function () {
            var frame = document.createElement('iframe');
            frame.src = map.dataset.src;
            frame.title = map.dataset.title || '';
            frame.loading = 'lazy';
            frame.referrerPolicy = 'no-referrer-when-downgrade';
            frame.setAttribute('allowfullscreen', '');
            var consent = map.querySelector('.ch-map__consent');
            map.insertBefore(frame, consent);
            consent.remove();
            map.classList.add('is-loaded');
            frame.focus();
        });
    });
})();
