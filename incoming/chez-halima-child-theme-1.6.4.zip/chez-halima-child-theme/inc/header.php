<?php
/**
 * Pezzi di header e pagina come su chezhalima.ch: ricerca a tendina, email e orari nell'header,
 * newsletter (finestra con il modulo del parent), pulsante «torna su» e riapertura dei cookie.
 * Contatti e orari vengono dal CMS del parent (ticinoweb_contact_*), i testi della newsletter
 * da Aspetto → Personalizza → Chez Halima.
 */
defined('ABSPATH') || exit;

/** Icone (SVG in linea, niente font di icone). */
function chezhalima_icon($name)
{
    $paths = array(
        'search'   => '<circle cx="11" cy="11" r="7" fill="none" stroke="currentColor" stroke-width="2.4"/><path d="m20 20-4-4" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>',
        'envelope' => '<rect x="2.5" y="5" width="19" height="14" rx="1" fill="none" stroke="currentColor" stroke-width="2"/><path d="m3 6 9 7 9-7M3 18l7-6m11 6-7-6" fill="none" stroke="currentColor" stroke-width="2"/>',
        'clock'    => '<circle cx="12" cy="12" r="9.5" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M12 6.5V12l3.5 3.5" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>',
        'up'       => '<path d="m6 15 6-6 6 6" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>',
        'cookie'   => '<path d="M12 2.5a9.5 9.5 0 1 0 9.4 8.1 3 3 0 0 1-3.6-3.3 3 3 0 0 1-3.3-3.6A9.6 9.6 0 0 0 12 2.5z" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="8.5" cy="10" r="1.3" fill="currentColor"/><circle cx="13" cy="15.5" r="1.3" fill="currentColor"/><circle cx="8" cy="15" r="1" fill="currentColor"/>',
        'close'    => '<path d="M6 6l12 12M18 6 6 18" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>',
        'cart'     => '<path d="M3 4h2.5l2.2 10.2a1.5 1.5 0 0 0 1.5 1.2h8.4a1.5 1.5 0 0 0 1.5-1.1L21 8H6.3" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><circle cx="9.5" cy="19.5" r="1.5" fill="currentColor"/><circle cx="17.5" cy="19.5" r="1.5" fill="currentColor"/>',
    );
    return isset($paths[$name]) ? '<svg class="ch-icon" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false">' . $paths[$name] . '</svg>' : '';
}

/**
 * Selettore della lingua di tW Translate Plus come su chezhalima.ch: bandiera e lingua corrente,
 * le altre lingue in una tendina. Vuoto se il plugin non è attivo o c'è una sola lingua pubblicata.
 */
function chezhalima_language_switcher($class = '')
{
    if (!function_exists('twtr_get_languages')) {
        return '';
    }
    $languages = twtr_get_languages();
    if (count($languages) < 2) {
        return '';
    }
    $flag = function ($slug) {
        $url = class_exists('Twtr_Switcher') ? Twtr_Switcher::flag_url($slug) : '';
        return $url ? '<img class="ch-lang__flag" src="' . esc_url($url) . '" alt="" width="16" height="11">' : '';
    };
    $current = null;
    $items = '';
    foreach ($languages as $lang) {
        if ($lang['is_current']) {
            $current = $lang;
        }
        $items .= '<li><a href="' . esc_url($lang['url']) . '" hreflang="' . esc_attr(str_replace('_', '-', $lang['locale'])) . '" lang="' . esc_attr($lang['slug']) . '"'
            . ($lang['is_current'] ? ' aria-current="true"' : '') . '>' . $flag($lang['slug']) . esc_html($lang['label']) . '</a></li>';
    }
    $current = $current ?: reset($languages);
    return '<details class="ch-lang ' . esc_attr($class) . '"><summary aria-label="' . esc_attr(chezhalima_t(__('Lingua', 'chez-halima-child-theme'), 'lang:label')) . ': ' . esc_attr($current['label']) . '">'
        . $flag($current['slug']) . '<span>' . esc_html($current['label']) . '</span><span class="ch-lang__chevron" aria-hidden="true"></span></summary>'
        . '<ul>' . $items . '</ul></details>';
}

/** Testi della newsletter: se il titolo è vuoto, la newsletter non compare da nessuna parte. */
function chezhalima_newsletter()
{
    $title = trim((string) get_theme_mod('chezhalima_newsletter_title', ''));
    return $title === '' ? null : array('title' => $title, 'text' => trim((string) get_theme_mod('chezhalima_newsletter_text', '')));
}

add_action('customize_register', function ($wp_customize) {
    $wp_customize->add_setting('chezhalima_newsletter_title', array('default' => '', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('chezhalima_newsletter_title', array(
        'label'       => __('Newsletter: titolo della finestra', 'chez-halima-child-theme'),
        'description' => __('Vuoto = niente newsletter nel sito.', 'chez-halima-child-theme'),
        'section'     => 'chezhalima',
        'type'        => 'text',
    ));
    $wp_customize->add_setting('chezhalima_newsletter_text', array('default' => '', 'sanitize_callback' => 'sanitize_textarea_field'));
    $wp_customize->add_control('chezhalima_newsletter_text', array(
        'label'   => __('Newsletter: testo della finestra', 'chez-halima-child-theme'),
        'section' => 'chezhalima',
        'type'    => 'textarea',
    ));
}, 20);

/** Header: ricerca a tendina, email e orari a destra, e i pezzi per il menu da telefono. */
add_action('ticinoweb_after_primary_navigation', function () {
    $c = ticinoweb_get_contact_info();
    $hours = trim((string) ($c['opening_hours_note'] ?? ''));
    $search = '<form class="ch-hsearch__form" role="search" method="get" action="' . esc_url(home_url('/')) . '">'
        . '<input type="search" name="s" placeholder="' . esc_attr__('Cerca…', 'chez-halima-child-theme') . '" aria-label="' . esc_attr__('Cerca nel sito', 'chez-halima-child-theme') . '">'
        . '<button type="submit" aria-label="' . esc_attr__('Cerca', 'chez-halima-child-theme') . '">' . chezhalima_icon('search') . '</button></form>';

    echo chezhalima_language_switcher('ch-lang--header'); // phpcs:ignore WordPress.Security.EscapeOutput -- escape nella funzione
    echo '<details class="ch-hsearch"><summary aria-label="' . esc_attr__('Cerca', 'chez-halima-child-theme') . '">' . chezhalima_icon('search') . '</summary>' . $search . '</details>';

    $items = array();
    $cart = function_exists('chezhalima_cart_link') ? chezhalima_cart_link('ch-tip') : '';
    if ($cart !== '') {
        $items[] = '<li>' . $cart . '</li>';
    }
    if (!empty($c['email'])) {
        $items[] = '<li><a class="ch-tip" href="mailto:' . esc_attr($c['email']) . '" data-tip="' . esc_attr($c['email']) . '" aria-label="' . esc_attr(sprintf(__('Scrivici: %s', 'chez-halima-child-theme'), $c['email'])) . '">' . chezhalima_icon('envelope') . '</a></li>';
    }
    if ($hours !== '') {
        $items[] = '<li><span class="ch-tip" tabindex="0" data-tip="' . esc_attr($hours) . '" aria-label="' . esc_attr(sprintf(__('Orari: %s', 'chez-halima-child-theme'), $hours)) . '">' . chezhalima_icon('clock') . '</span></li>';
    }
    if ($items) {
        echo '<ul class="ch-hcontact">' . implode('', $items) . '</ul>';
    }

    // Nel menu da telefono (assets/js/menu.js lo sposta dentro il pannello): ricerca e newsletter, come l'originale.
    echo '<div class="ch-mobile-extra">' . $search . (function_exists('chezhalima_cart_link') ? chezhalima_cart_link('ch-cart--mobile') : '') . chezhalima_language_switcher('ch-lang--mobile');
    if (chezhalima_newsletter()) {
        echo '<button type="button" class="ch-newsletter-open">' . chezhalima_icon('envelope') . ' ' . esc_html__('Newsletter', 'chez-halima-child-theme') . '</button>';
    }
    echo '</div>';
});

/** Barra in alto, dopo i link del menu: «Newsletter» e l'email. */
add_action('chezhalima_topbar_after_links', function () {
    $c = ticinoweb_get_contact_info();
    if (chezhalima_newsletter()) {
        echo '<button type="button" class="ch-newsletter-open ch-topbar__item">' . chezhalima_icon('envelope') . ' ' . esc_html__('Newsletter', 'chez-halima-child-theme') . '</button>';
    }
    if (!empty($c['email'])) {
        echo '<a class="ch-topbar__item ch-topbar__mail" href="mailto:' . esc_attr($c['email']) . '" title="' . esc_attr__('Inviaci un\'email', 'chez-halima-child-theme') . '" aria-label="' . esc_attr__('Inviaci un\'email', 'chez-halima-child-theme') . '">' . chezhalima_icon('envelope') . '</a>';
    }
});

/** Fine pagina: finestra della newsletter, «torna su» e pulsante per riaprire le preferenze dei cookie. */
add_action('wp_footer', function () {
    $newsletter = chezhalima_newsletter();
    if ($newsletter) {
        chezhalima_form_assets();
        $bg = get_post_thumbnail_id((int) get_option('page_on_front'));
        ?>
        <dialog class="ch-newsletter" id="ch-newsletter" aria-labelledby="ch-newsletter-title">
            <?php echo $bg ? wp_get_attachment_image($bg, 'large', false, array('class' => 'ch-newsletter__bg', 'alt' => '', 'loading' => 'lazy')) : ''; ?>
            <div class="ch-newsletter__inner">
                <h2 id="ch-newsletter-title"><?php echo esc_html($newsletter['title']); ?></h2>
                <?php if ($newsletter['text'] !== '') : ?><p class="ch-newsletter__lead"><?php echo esc_html($newsletter['text']); ?></p><?php endif; ?>
                <form class="ch-form ch-form--newsletter" method="post" novalidate>
                    <input type="hidden" name="ch_form" value="newsletter">
                    <p><label for="ch-nl-email"><?php esc_html_e('La tua email', 'chez-halima-child-theme'); ?></label>
                        <input id="ch-nl-email" name="email" type="email" autocomplete="email" required></p>
                    <p class="ch-hp" aria-hidden="true"><label>Sito web <input name="tw_hp" type="text" tabindex="-1" autocomplete="off"></label></p>
                    <p><button type="submit" class="ch-btn"><?php esc_html_e('Invia', 'chez-halima-child-theme'); ?></button></p>
                    <p class="ch-form-status" role="status" aria-live="polite"></p>
                </form>
            </div>
            <form method="dialog"><button class="ch-newsletter__close" aria-label="<?php esc_attr_e('Chiudi', 'chez-halima-child-theme'); ?>"><?php echo chezhalima_icon('close'); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fisso ?></button></form>
        </dialog>
        <?php
    }
    echo '<button type="button" class="ch-totop" hidden aria-label="' . esc_attr__('Torna su', 'chez-halima-child-theme') . '">' . chezhalima_icon('up') . '</button>';
    if (get_option('tw_cookie_banner_enable')) {
        echo '<button type="button" class="ch-cookie-revisit" hidden aria-label="' . esc_attr__('Preferenze cookie', 'chez-halima-child-theme') . '" title="' . esc_attr__('Preferenze cookie', 'chez-halima-child-theme') . '">' . chezhalima_icon('cookie') . '</button>';
    }
}, 5);

/**
 * Iscrizione alla newsletter con l'invio del parent (Invii Ricevuti + e-mail del CMS): il parent
 * chiede nome e messaggio, qui si compilano per chi lascia solo l'email.
 */
add_filter('ticinoweb_form_fields', function ($fields, $post) {
    if (isset($post['ch_form']) && $post['ch_form'] === 'newsletter') {
        $fields['nome'] = $fields['email'] !== '' ? $fields['email'] : __('Newsletter', 'chez-halima-child-theme');
        $fields['oggetto'] = __('Iscrizione alla newsletter', 'chez-halima-child-theme');
        $fields['messaggio'] = __('Richiesta di iscrizione alla newsletter dal sito.', 'chez-halima-child-theme');
    }
    return $fields;
}, 10, 2);
