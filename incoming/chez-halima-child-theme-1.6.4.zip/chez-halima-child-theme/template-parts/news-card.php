<?php
/** Card di una news in home: foto con il riquadro della data, titolo ed estratto in un box sovrapposto. */
defined('ABSPATH') || exit;
?>
<article class="ch-news-card">
    <a class="ch-news-card__media" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
        <?php if (has_post_thumbnail()) : ?>
            <?php the_post_thumbnail('medium_large', array('loading' => 'lazy', 'alt' => '')); ?>
        <?php endif; ?>
        <?php echo chezhalima_date_badge(); // phpcs:ignore WordPress.Security.EscapeOutput -- escape nella funzione ?>
    </a>
    <div class="ch-news-card__box">
        <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
        <span class="ch-divider" aria-hidden="true"></span>
        <p><?php echo esc_html(wp_trim_words(get_the_excerpt(), 16, ' [...]')); ?></p>
    </div>
</article>
