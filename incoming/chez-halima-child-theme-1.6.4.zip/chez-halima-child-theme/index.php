<?php
/**
 * News (elenco, ricerca, archivi) e articolo singolo come su chezhalima.ch: colonna degli articoli
 * e barra laterale con ricerca, menu e ultime novità.
 */
defined('ABSPATH') || exit;

get_header();
$single = is_singular();
?>
<main id="ch-main" class="ch-wrap ch-blog">
    <div class="ch-blog__posts">
        <?php if (!$single) : ?>
            <h1 class="screen-reader-text"><?php echo esc_html(is_home() && get_option('page_for_posts') ? get_the_title(get_option('page_for_posts')) : wp_strip_all_tags(get_the_archive_title())); ?></h1>
        <?php endif; ?>
        <?php if (have_posts()) : ?>
            <?php while (have_posts()) : the_post(); ?>
                <article <?php post_class('ch-entry'); ?>>
                    <header class="ch-entry__head">
                        <p class="ch-entry__cat"><?php echo wp_kses_post(get_the_category_list(', ')); ?></p>
                        <?php if ($single) : ?>
                            <h1><?php the_title(); ?></h1>
                        <?php else : ?>
                            <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                        <?php endif; ?>
                        <span class="ch-divider" aria-hidden="true"></span>
                        <p class="ch-entry__meta">
                            <?php
                            printf(
                                /* translators: 1: data, 2: autore */
                                esc_html__('Pubblicato il %1$s da %2$s', 'chez-halima-child-theme'),
                                '<time datetime="' . esc_attr(get_the_date('c')) . '">' . esc_html(get_the_date()) . '</time>',
                                esc_html(get_bloginfo('name'))
                            );
                            ?>
                        </p>
                    </header>
                    <?php if (has_post_thumbnail()) : ?>
                        <div class="ch-entry__media">
                            <?php if ($single) : ?>
                                <?php the_post_thumbnail('large', array('alt' => '')); ?>
                            <?php else : ?>
                                <a href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true"><?php the_post_thumbnail('large', array('alt' => '', 'loading' => 'lazy')); ?></a>
                            <?php endif; ?>
                            <?php echo chezhalima_date_badge(); // phpcs:ignore WordPress.Security.EscapeOutput -- escape nella funzione ?>
                        </div>
                    <?php endif; ?>
                    <div class="ch-entry__body">
                        <?php if ($single) : ?>
                            <?php the_content(); ?>
                        <?php else : ?>
                            <p><?php echo esc_html(get_the_excerpt()); ?></p>
                            <p class="ch-entry__more"><a class="ch-btn-outline" href="<?php the_permalink(); ?>"><?php esc_html_e('Continua a leggere', 'chez-halima-child-theme'); ?> <span aria-hidden="true">→</span></a></p>
                        <?php endif; ?>
                    </div>
                </article>
            <?php endwhile; ?>
            <?php if ($single) : ?>
                <nav class="ch-entry__nav" aria-label="<?php esc_attr_e('Altre news', 'chez-halima-child-theme'); ?>">
                    <?php previous_post_link('%link', '<span aria-hidden="true">‹</span> %title'); ?>
                    <?php next_post_link('%link', '%title <span aria-hidden="true">›</span>'); ?>
                </nav>
            <?php else : ?>
                <?php the_posts_pagination(); ?>
            <?php endif; ?>
        <?php else : ?>
            <p><?php esc_html_e('Nessuna news trovata.', 'chez-halima-child-theme'); ?></p>
        <?php endif; ?>
    </div>

    <aside class="ch-blog__side">
        <section class="ch-widget">
            <h2 class="ch-widget__title"><?php esc_html_e('Cerca', 'chez-halima-child-theme'); ?></h2>
            <form class="ch-search" role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
                <label class="screen-reader-text" for="ch-search-field"><?php esc_html_e('Cerca nel sito', 'chez-halima-child-theme'); ?></label>
                <input id="ch-search-field" type="search" name="s" value="<?php echo esc_attr(get_search_query()); ?>" placeholder="<?php esc_attr_e('Cerca…', 'chez-halima-child-theme'); ?>">
                <button type="submit" aria-label="<?php esc_attr_e('Cerca', 'chez-halima-child-theme'); ?>"><svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg></button>
            </form>
        </section>
        <?php if (has_nav_menu('primary')) : ?>
            <nav class="ch-widget" aria-label="<?php esc_attr_e('Naviga', 'chez-halima-child-theme'); ?>">
                <h2 class="ch-widget__title"><?php esc_html_e('Naviga', 'chez-halima-child-theme'); ?></h2>
                <?php wp_nav_menu(array('theme_location' => 'primary', 'container' => false, 'menu_class' => 'ch-widget__links', 'depth' => 1, 'fallback_cb' => false)); ?>
            </nav>
        <?php endif; ?>
        <section class="ch-widget">
            <h2 class="ch-widget__title"><?php esc_html_e('Ultime novità', 'chez-halima-child-theme'); ?></h2>
            <?php echo chezhalima_recent_posts(5); // phpcs:ignore WordPress.Security.EscapeOutput -- escape nella funzione ?>
        </section>
    </aside>
</main>
<?php
get_footer();
