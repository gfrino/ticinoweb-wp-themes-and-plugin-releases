<?php
/**
 * Pagina interna come su chezhalima.ch: niente fascia con il titolo, il contenuto è fatto di sezioni
 * (classi ch-*) che decidono da sole larghezza e sfondo. Se il contenuto non ha un <h1>, il titolo
 * della pagina compare in testa, così ogni pagina ne ha uno solo.
 */
defined('ABSPATH') || exit;

get_header();
the_post();
$content = get_the_content();
?>
<main id="ch-main" class="ch-page">
    <?php if (stripos($content, '<h1') === false) : ?>
        <header class="ch-wrap ch-page__head"><h1><?php the_title(); ?></h1></header>
        <div class="ch-wrap ch-prose"><?php the_content(); ?></div>
    <?php else : ?>
        <?php the_content(); ?>
    <?php endif; ?>
</main>
<?php
get_footer();
