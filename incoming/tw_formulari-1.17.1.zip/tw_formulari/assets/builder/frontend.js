/**
 * TW Formulari — behaviour of the built-in forms: pages, show/hide rules, live totals, sending without reloading.
 *
 * The browser is a convenience only: the server validates everything again and computes every calculation itself.
 * The rules and the formula grammar mirror includes/builder/class-conditions.php and class-calculator.php.
 */
(function () {
	'use strict';

	var MAX_PASSES = 6;

	function qsa(root, sel) {
		return Array.prototype.slice.call(root.querySelectorAll(sel));
	}

	/* ------------------------------------------------------------------ values */

	function inputsOf(form, id) {
		return qsa(form, '[name^="twf_f[' + id + ']"]').filter(function (el) {
			var n = el.getAttribute('name');
			return n === 'twf_f[' + id + ']' || n === 'twf_f[' + id + '][]' || n.indexOf('twf_f[' + id + '][') === 0;
		});
	}

	/** Value of a field in the same shape the server uses (string, array, object or boolean). */
	function valueOf(form, field) {
		if (field.type === 'upload') {
			var f = form.querySelector('input[type=file][name^="twf_files[' + field.id + ']"]');
			return f && f.files ? Array.prototype.slice.call(f.files) : [];
		}
		var els = inputsOf(form, field.id);
		if (!els.length) { return null; }
		switch (field.type) {
			case 'checkbox':
				return els.filter(function (e) { return e.checked; }).map(function (e) { return e.value; });
			case 'radio':
				var r = els.filter(function (e) { return e.checked; })[0];
				return r ? r.value : '';
			case 'gdpr':
				return !!els[0].checked;
			case 'name':
			case 'address':
				var o = {};
				els.forEach(function (e) {
					var m = e.getAttribute('name').match(/\]\[([a-z]+)\]$/);
					if (m) { o[m[1]] = e.value.trim(); }
				});
				return o;
			default:
				return els[0].value.trim();
		}
	}

	function isBlank(field, value) {
		if (value === null || value === undefined) { return true; }
		switch (field.type) {
			case 'name': return !value.first && !value.last;
			case 'address': return !value.street && !value.zip && !value.city;
			case 'checkbox':
			case 'upload': return !value.length;
			case 'gdpr': return value !== true;
			default: return String(value).trim() === '';
		}
	}

	function numberOf(field, value) {
		if (value === null || value === undefined || value === '') { return 0; }
		if (field.type === 'number' || field.type === 'currency' || field.type === 'calculation') {
			var n = parseFloat(String(value).replace(/['’\s]/g, '').replace(',', '.'));
			return isFinite(n) ? n : 0;
		}
		if (field.options) {
			var list = field.type === 'checkbox' ? value : [value];
			var total = 0;
			list.forEach(function (item) {
				field.options.forEach(function (opt) {
					if (String(opt.value) === String(item)) {
						var c = opt.calc !== '' && opt.calc !== undefined ? opt.calc : opt.value;
						var v = parseFloat(c);
						total += isFinite(v) ? v : 0;
					}
				});
			});
			return total;
		}
		return 0;
	}

	function comparable(field, value) {
		if (value === null || value === undefined) { return []; }
		if (field.type === 'checkbox') { return value.map(String); }
		if (field.type === 'gdpr') { return [value === true ? '1' : '']; }
		if (field.type === 'name') { return [((value.first || '') + ' ' + (value.last || '')).trim()]; }
		if (field.type === 'address') { return [[value.street, ((value.zip || '') + ' ' + (value.city || '')).trim(), value.country].filter(Boolean).join(', ')]; }
		return [String(value).trim()];
	}

	/* -------------------------------------------------------------- conditions */

	function ruleMatches(rule, byId, values) {
		var field = byId[rule.field];
		if (!field) { return false; }
		var value = values.hasOwnProperty(rule.field) ? values[rule.field] : null;
		var parts = comparable(field, value);
		var target = String(rule.value === undefined ? '' : rule.value).trim();
		var blank = !parts.some(function (p) { return p !== ''; });
		var lc = function (s) { return s.toLowerCase(); };
		switch (rule.op) {
			case 'empty': return blank;
			case 'not_empty': return !blank;
			case 'is': return parts.indexOf(target) !== -1 || (target === '' && blank);
			case 'is_not': return parts.indexOf(target) === -1 && !(target === '' && blank);
			case 'contains': return target !== '' && parts.some(function (p) { return lc(p).indexOf(lc(target)) !== -1; });
			case 'not_contains': return !(target !== '' && parts.some(function (p) { return lc(p).indexOf(lc(target)) !== -1; }));
			case 'starts': return target !== '' && parts.some(function (p) { return lc(p).indexOf(lc(target)) === 0; });
			case 'ends': return target !== '' && parts.some(function (p) { return p.length >= target.length && lc(p).slice(-target.length) === lc(target); });
			case 'gt':
			case 'lt':
				if (blank || target === '' || isNaN(parseFloat(target))) { return false; }
				return rule.op === 'gt' ? numberOf(field, value) > parseFloat(target) : numberOf(field, value) < parseFloat(target);
		}
		return false;
	}

	function fieldVisible(field, byId, values) {
		var c = field.conditions;
		if (!c || !c.rules || !c.rules.length) { return true; }
		var any = c.match === 'any';
		var result = any ? false : true;
		for (var i = 0; i < c.rules.length; i++) {
			var ok = ruleMatches(c.rules[i], byId, values);
			if (any && ok) { result = true; break; }
			if (!any && !ok) { result = false; break; }
		}
		return c.action === 'hide' ? !result : result;
	}

	/** Mirrors Conditions::is_required(): the switch is the base, the rule set can make it required or optional. */
	function fieldRequired(field, byId, values) {
		var base = !!field.required;
		var c = field.required_conditions;
		if (!c || !c.rules || !c.rules.length) { return base; }
		var any = c.match === 'any';
		var result = any ? false : true;
		for (var i = 0; i < c.rules.length; i++) {
			var ok = ruleMatches(c.rules[i], byId, values);
			if (any && ok) { result = true; break; }
			if (!any && !ok) { result = false; break; }
		}
		return c.action === 'optional' ? base && !result : base || result;
	}

	function visibleMap(fields, byId, values) {
		var visible = {};
		fields.forEach(function (f) { visible[f.id] = true; });
		for (var pass = 0; pass < MAX_PASSES; pass++) {
			var effective = {};
			Object.keys(values).forEach(function (id) { if (visible[id] !== false) { effective[id] = values[id]; } });
			var changed = false;
			fields.forEach(function (f) {
				var now = fieldVisible(f, byId, effective);
				if (now !== visible[f.id]) { visible[f.id] = now; changed = true; }
			});
			if (!changed) { break; }
		}
		return visible;
	}

	/* -------------------------------------------------------------- calculator */

	function calculate(formula, byId, values) {
		if (!formula || formula.length > 1000) { return null; }
		var text = formula.replace(/\{([a-z0-9_]{1,40})\}/g, function (m, id) {
			var f = byId[id];
			var n = f ? numberOf(f, values[id]) : 0;
			return '(' + String(n) + ')';
		});
		var tokens = [];
		var re = /\s*(?:(\d+\.?\d*|\.\d+)|([a-zA-Z]+)|([-+*\/%(),]))/y;
		var pos = 0;
		var m;
		while (pos < text.length) {
			re.lastIndex = pos;
			m = re.exec(text);
			if (!m) { return /^\s*$/.test(text.slice(pos)) ? finish() : null; }
			pos = re.lastIndex;
			if (m[1] !== undefined) { tokens.push(['num', parseFloat(m[1])]); }
			else if (m[2] !== undefined) {
				var fn = m[2].toLowerCase();
				if (['round', 'floor', 'ceil', 'abs', 'min', 'max'].indexOf(fn) === -1) { return null; }
				tokens.push(['fn', fn]);
			} else { tokens.push(['op', m[3]]); }
		}
		return finish();

		function finish() {
			if (!tokens.length) { return null; }
			var i = 0;
			try {
				var result = expression();
				if (i !== tokens.length) { return null; }
				return isFinite(result) ? result : null;
			} catch (e) { return null; }

			function peek() { return tokens[i]; }
			function acceptOp(op) { var t = peek(); if (t && t[0] === 'op' && t[1] === op) { i++; return true; } return false; }
			function expression() {
				var v = term();
				for (;;) {
					if (acceptOp('+')) { v += term(); } else if (acceptOp('-')) { v -= term(); } else { return v; }
				}
			}
			function term() {
				var v = unary();
				for (;;) {
					if (acceptOp('*')) { v *= unary(); }
					else if (acceptOp('/')) { var d = unary(); if (d === 0) { throw new Error('div'); } v /= d; }
					else if (acceptOp('%')) { var d2 = unary(); if (d2 === 0) { throw new Error('div'); } v = v % d2; }
					else { return v; }
				}
			}
			function unary() {
				if (acceptOp('-')) { return -unary(); }
				if (acceptOp('+')) { return unary(); }
				return primary();
			}
			function primary() {
				var t = peek();
				if (!t) { throw new Error('end'); }
				if (t[0] === 'num') { i++; return t[1]; }
				if (t[0] === 'op' && t[1] === '(') { i++; var v = expression(); if (!acceptOp(')')) { throw new Error(')'); } return v; }
				if (t[0] === 'fn') {
					i++;
					if (!acceptOp('(')) { throw new Error('('); }
					var args = [expression()];
					while (acceptOp(',')) { args.push(expression()); }
					if (!acceptOp(')')) { throw new Error(')'); }
					switch (t[1]) {
						case 'round': var p = Math.pow(10, args[1] || 0); return Math.round(args[0] * p) / p;
						case 'floor': return Math.floor(args[0]);
						case 'ceil': return Math.ceil(args[0]);
						case 'abs': return Math.abs(args[0]);
						case 'min': return Math.min.apply(null, args);
						case 'max': return Math.max.apply(null, args);
					}
				}
				throw new Error('token');
			}
		}
	}

	/* -------------------------------------------------------------------- form */

	function init(root) {
		var cfgEl = root.querySelector('script.twf-config');
		var form = root.querySelector('form.twf-form__form');
		if (!cfgEl || !form) { return; }
		var cfg;
		try { cfg = JSON.parse(cfgEl.textContent); } catch (e) { return; }

		var fields = cfg.fields || [];
		var byId = {};
		fields.forEach(function (f) { byId[f.id] = f; });
		var steps = qsa(form, '.twf-step');
		var prev = form.querySelector('.twf-prev');
		var next = form.querySelector('.twf-next');
		var submit = form.querySelector('.twf-submit');
		var status = form.querySelector('.twf-status');
		var current = 0;
		var visible = {};
		var requiredNow = {};
		var lastValues = {};
		// Preview inside the visual editor: every page is shown, rules do not hide anything, nothing is sent.
		var preview = root.hasAttribute('data-twf-preview');
		if (preview) { root.classList.add('twf-is-preview'); }

		// Values passed in the address (hidden fields with a "param").
		var params = new URLSearchParams(window.location.search);
		qsa(form, 'input[type=hidden][data-param]').forEach(function (el) {
			var v = params.get(el.getAttribute('data-param'));
			if (v) { el.value = v.slice(0, 500); }
		});

		function wrapper(id) { return form.querySelector('[data-field-id="' + id + '"]'); }

		function currentValues() {
			var values = {};
			fields.forEach(function (f) {
				if (f.type === 'calculation') { return; }
				var el = wrapper(f.id);
				if (el && el.hasAttribute('hidden') && f.type !== 'hidden') {
					return; // hidden by a rule: counts as empty
				}
				var v = valueOf(form, f);
				if (v !== null) { values[f.id] = v; }
			});
			return values;
		}

		function refresh() {
			var values = currentValues();
			visible = visibleMap(fields, byId, values);
			// Calculations, in page order, so one can use the previous ones.
			fields.forEach(function (f) {
				if (f.type !== 'calculation' || visible[f.id] === false) { return; }
				var r = calculate(f.formula, byId, values);
				var out = wrapper(f.id) ? wrapper(f.id).querySelector('output') : null;
				var shown = r === null ? 0 : r;
				values[f.id] = shown.toFixed(f.decimals === undefined ? 2 : f.decimals);
				if (out) { out.textContent = values[f.id]; }
			});
			// Re-evaluate once more because a rule may depend on a calculation.
			visible = visibleMap(fields, byId, values);
			lastValues = values;
			fields.forEach(function (f) {
				var el = wrapper(f.id);
				if (!el) { return; }
				if (f.required_conditions) {
					var need = fieldRequired(f, byId, values);
					requiredNow[f.id] = need;
					var star = el.querySelector('.twf-req');
					if (star) { if (need) { star.removeAttribute('hidden'); } else { star.setAttribute('hidden', ''); } }
					var control = el.querySelector('input,select,textarea');
					if (control) { if (need) { control.setAttribute('aria-required', 'true'); } else { control.removeAttribute('aria-required'); } }
				}
				var show = preview ? true : visible[f.id] !== false;
				if (show) { el.removeAttribute('hidden'); } else { el.setAttribute('hidden', ''); }
				qsa(el, 'input,select,textarea').forEach(function (i) { i.disabled = !show; });
				if (el.tagName === 'INPUT') { el.disabled = !show; }
			});
			updatePayment();
		}

		function clearErrors() {
			qsa(form, '.twf-error').forEach(function (p) { p.textContent = ''; });
			qsa(form, '[aria-invalid]').forEach(function (e) { e.removeAttribute('aria-invalid'); });
		}

		function showError(id, message) {
			var w = wrapper(id);
			if (!w) { return null; }
			var p = w.querySelector('.twf-error');
			if (p) { p.textContent = message; }
			var first = w.querySelector('input,select,textarea');
			if (first) { first.setAttribute('aria-invalid', 'true'); }
			return first;
		}

		/** Light check of the visible required fields of a page (the server does the real validation). */
		function validateStep(index) {
			var firstBad = null;
			qsa(steps[index], '[data-field-id]').forEach(function (el) {
				var id = el.getAttribute('data-field-id');
				var f = byId[id];
				if (!f || visible[id] === false || f.type === 'calculation') { return; }
				var value = valueOf(form, f);
				var msg = '';
				var needed = requiredNow.hasOwnProperty(id) ? requiredNow[id] : f.required;
				if (needed && isBlank(f, value)) { msg = f.type === 'gdpr' ? cfg.i18n.consent : cfg.i18n.required; }
				if (!msg && f.type === 'upload' && value.length) {
					var input = el.querySelector('input[type=file]');
					var maxMb = parseInt(input.getAttribute('data-max-mb'), 10) || 5;
					var maxFiles = parseInt(input.getAttribute('data-max-files'), 10) || 1;
					if (value.length > maxFiles) { msg = cfg.i18n.tooMany; }
					value.forEach(function (file) { if (file.size > maxMb * 1048576) { msg = cfg.i18n.fileTooBig; } });
				}
				if (msg) {
					var input2 = showError(id, msg);
					firstBad = firstBad || input2;
				}
			});
			return firstBad;
		}

		function stepHasVisible(index) {
			return qsa(steps[index], '[data-field-id]').some(function (el) {
				var f = byId[el.getAttribute('data-field-id')];
				return f && f.type !== 'hidden' && visible[f.id] !== false;
			});
		}

		function showStep(index) {
			current = index;
			steps.forEach(function (s, i) { if (preview || i === index) { s.removeAttribute('hidden'); } else { s.setAttribute('hidden', ''); } });
			if (preview) { return; }
			var last = index === lastStep();
			if (prev) { prev.hidden = firstStep() === index; }
			if (next) { next.hidden = last; }
			if (submit) { submit.hidden = !last; }
			syncPayBox();
			if (steps.length > 1) { root.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
		}

		function firstStep() { for (var i = 0; i < steps.length; i++) { if (stepHasVisible(i) || i === steps.length - 1) { return i; } } return 0; }
		function lastStep() { for (var i = steps.length - 1; i >= 0; i--) { if (stepHasVisible(i)) { return i; } } return 0; }
		function stepAfter(i) { for (var k = i + 1; k < steps.length; k++) { if (stepHasVisible(k)) { return k; } } return i; }
		function stepBefore(i) { for (var k = i - 1; k >= 0; k--) { if (stepHasVisible(k)) { return k; } } return i; }

		form.addEventListener('input', refresh);
		form.addEventListener('change', refresh);
		form.addEventListener('change', function (e) { if (e.target && e.target.name === 'twf_pay_method') { syncMethodPanels(); } });
		// "Copy" next to the IBAN and the payment reference (also on the confirmation, which is added later).
		root.addEventListener('click', function (e) {
			var b = e.target && e.target.closest ? e.target.closest('[data-twf-copy]') : null;
			if (!b) { return; }
			var text = b.getAttribute('data-twf-copy') || '';
			var shown = function () { var t = b.textContent; b.textContent = b.getAttribute('data-done') || '✓'; window.setTimeout(function () { b.textContent = t; }, 1500); };
			if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(text).then(shown, function () { /* the text can still be selected by hand */ }); return; }
			var area = document.createElement('textarea');
			area.value = text; area.setAttribute('readonly', ''); area.style.position = 'fixed'; area.style.opacity = '0';
			document.body.appendChild(area); area.select();
			try { document.execCommand('copy'); shown(); } catch (err) { /* nothing to do */ }
			document.body.removeChild(area);
		});

		if (next) {
			next.addEventListener('click', function () {
				clearErrors();
				var bad = validateStep(current);
				if (bad) { bad.focus(); return; }
				showStep(stepAfter(current));
			});
		}
		if (prev) { prev.addEventListener('click', function () { clearErrors(); showStep(stepBefore(current)); }); }

		form.addEventListener('submit', function (event) {
			event.preventDefault();
			if (preview) { status.textContent = cfg.i18n.preview || ''; return; }
			if (!cfg.ajax) { return; }
			clearErrors();
			refresh();
			for (var i = 0; i < steps.length; i++) {
				var bad = validateStep(i);
				if (bad) { showStep(i); bad.focus(); return; }
			}
			if (pay) { startPayment(); } else { send(); }
		});

		function setBusy(busy) {
			if (submit) { submit.disabled = busy; }
			if (next) { next.disabled = busy; }
			status.textContent = busy ? cfg.i18n.sending : '';
		}

		// reCAPTCHA v3 of the site's CMS: a fresh token for every send; without the script the server will refuse it.
		function withCaptcha(body, go) {
			var c = cfg.captcha;
			if (!c || !window.grecaptcha || !window.grecaptcha.ready) { return go(); }
			return new Promise(function (resolve) {
				window.grecaptcha.ready(function () {
					window.grecaptcha.execute(c.key, { action: c.action }).then(function (token) { body.set('twf_recaptcha', token); resolve(go()); }, function () { resolve(go()); });
				});
			}).then(function (p) { return p; });
		}

		function send() {
			setBusy(true);
			var body = new FormData(form);
			withCaptcha(body, function () { return fetch(cfg.rest, { method: 'POST', body: body, headers: { 'Accept': 'application/json' }, credentials: 'omit' }); })
				.then(function (res) { return res.json().catch(function () { return {}; }).then(function (data) { return { status: res.status, data: data }; }); })
				.then(function (r) {
					var d = r.data || {};
					if (r.status === 200 && d.ok && d.payment && pay) {
						// Saved as "waiting for payment": now the money. The form is locked so the answers cannot drift.
						payState.secret = d.payment.client_secret;
						payState.intent = d.payment.intent;
						lockForm(true);
						confirmPay();
						return;
					}
					setBusy(false);
					if (r.status === 200 && d.ok) { done(d.confirmation || {}, d.manual); return; }
					if (d.errors) {
						var first = null;
						Object.keys(d.errors).forEach(function (id) {
							var el = showError(id, d.errors[id]);
							first = first || el;
						});
						for (var i = 0; i < steps.length; i++) {
							if (first && steps[i].contains(first)) { showStep(i); break; }
						}
						if (first) { first.focus(); }
					}
					status.textContent = d.message || cfg.i18n.error;
				})
				.catch(function () { setBusy(false); status.textContent = cfg.i18n.error; });
		}

		function done(c, manual) {
			if (payState.secret) { lockForm(false); payState.secret = ''; payState.intent = ''; if (payState.element && payState.element.clear) { payState.element.clear(); } }
			status.textContent = '';
			if (c.type === 'redirect' && c.url) {
				var ok = /^https?:\/\//i.test(c.url) || c.url.charAt(0) === '/';
				if (ok) { window.location.assign(c.url); return; }
			}
			var box = document.createElement('div');
			box.className = 'twf-confirmation';
			box.setAttribute('role', 'status');
			box.tabIndex = -1;
			box.innerHTML = c.message || '';
			if (manual && manual.html) {
				// How to pay (bank details…): built on the server with everything escaped.
				var info = document.createElement('div');
				info.className = 'twf-payinfo-wrap';
				info.innerHTML = manual.html;
				box.appendChild(info);
			}
			if (c.type === 'message_keep') {
				form.reset();
				refresh();
				showStep(firstStep());
				root.appendChild(box);
			} else {
				form.hidden = true;
				root.appendChild(box);
			}
			box.focus();
			if (c.autoclose > 0) {
				window.setTimeout(function () { box.hidden = true; if (c.type !== 'message_keep') { /* the form stays closed */ } }, c.autoclose * 1000);
			}
			root.dispatchEvent(new CustomEvent('twf:submitted', { bubbles: true, detail: { formId: cfg.formId } }));
		}

		/* ------------------------------------------------------------ payment (Stripe Payment Element) */

		function payCents() {
			if (!pay) { return 0; }
			var major = 0;
			if (pay.mode === 'fixed') { major = pay.amount; }
			else {
				var f = byId[pay.amountField];
				if (f && visible[f.id] !== false) { major = numberOf(f, lastValues[f.id]); }
			}
			return Math.round(major * pay.factor);
		}

		function payMsg(text) {
			var box = payBox ? payBox.querySelector('.twf-payment__message') : null;
			if (box) { box.textContent = text || ''; }
			status.textContent = text || '';
		}

		/** True when this answer has to be paid at all (the form's own rules may switch it off). */
		function payRequested() {
			if (!pay) { return false; }
			return !pay.conditions || fieldVisible({ conditions: pay.conditions }, byId, lastValues);
		}

		/** The way to pay the visitor chose ("stripe" or the id of a manual method such as a bank transfer). */
		function payMethod() {
			var radio = form.querySelector('input[name="twf_pay_method"]:checked');
			if (radio) { return radio.value; }
			var one = form.querySelector('input[type=hidden][name="twf_pay_method"]');
			return one ? one.value : 'stripe';
		}

		/** True when this answer is paid online now, with Stripe. */
		function payApplies() {
			return payRequested() && payMethod() === 'stripe';
		}

		/** Shows the panel of the chosen method (Stripe's fields, or the bank details) and hides the others. */
		function syncMethodPanels() {
			var chosen = payMethod();
			qsa(form, '[data-twf-method]').forEach(function (p) { p.hidden = p.getAttribute('data-twf-method') !== chosen; });
		}

		/** The payment area is shown on the last page, and only when a payment is asked. */
		function syncPayBox() {
			if (!pay || !payBox || preview) { return; }
			var show = payRequested() && current === lastStep();
			payBox.hidden = !show;
			syncMethodPanels();
			if (show && payMethod() === 'stripe') { ensureMounted(); }
			if (submit && !payState.secret) { submit.textContent = payApplies() ? pay.labelPay : pay.labelNoPay; }
		}

		function updatePayment() {
			if (!pay || !payBox || preview) { return; }
			syncPayBox();
			var cents = payCents();
			var out = payBox.querySelector('.twf-payment__amount');
			if (out) { out.textContent = cents > 0 ? (cents / pay.factor).toFixed(pay.factor === 1 ? 0 : 2) + ' ' + pay.currency.toUpperCase() : '—'; }
			if (payState.elements && cents >= 50 && cents !== payState.cents && !payState.secret) {
				payState.cents = cents;
				try { payState.elements.update({ amount: cents }); } catch (e) { /* the amount is set again at the next change */ }
			}
		}

		function loadStripe() {
			if (window.Stripe) { return Promise.resolve(window.Stripe); }
			if (window.__twfStripe) { return window.__twfStripe; }
			window.__twfStripe = new Promise(function (resolve, reject) {
				var s = document.createElement('script');
				s.src = 'https://js.stripe.com/v3/';
				s.async = true;
				s.onload = function () { if (window.Stripe) { resolve(window.Stripe); } else { reject(new Error('stripe')); } };
				s.onerror = function () { window.__twfStripe = null; reject(new Error('stripe')); };
				document.head.appendChild(s);
			});
			return window.__twfStripe;
		}

		function ensureMounted() {
			if (!pay || !pay.ready || preview || payState.mounted) { return; }
			payState.mounted = true;
			loadStripe().then(function (Stripe) {
				payState.stripe = Stripe(pay.pk, { locale: pay.locale });
				payState.cents = Math.max(payCents(), 50);
				payState.elements = payState.stripe.elements({
					mode: 'payment', amount: payState.cents, currency: pay.currency,
					appearance: { theme: 'stripe', variables: { colorPrimary: pay.accent, borderRadius: '6px' } }
				});
				payState.element = payState.elements.create('payment', { layout: 'tabs' });
				payState.element.mount(payBox.querySelector('.twf-payment__element'));
			}).catch(function () {
				payState.mounted = false;
				payMsg(cfg.i18n.stripeLoad);
			});
		}

		function lockForm(lock) {
			form.classList.toggle('twf-locked', lock);
			qsa(form, '.twf-step input, .twf-step select, .twf-step textarea, .twf-prev, .twf-next').forEach(function (el) {
				if (lock) { el.setAttribute('data-twf-locked', el.disabled ? '1' : '0'); el.disabled = true; }
				else if (el.hasAttribute('data-twf-locked')) { el.disabled = el.getAttribute('data-twf-locked') === '1'; el.removeAttribute('data-twf-locked'); }
			});
		}

		function startPayment() {
			payMsg('');
			if (payState.secret) { confirmPay(); return; } // retry of a declined payment
			if (!payApplies()) { send(); return; } // a manual way to pay (bank transfer…) or none: sent like any other form
			if (!pay.ready) { payMsg(cfg.i18n.payNotReady); return; }
			if (!payState.elements) { ensureMounted(); payMsg(cfg.i18n.stripeLoad); return; }
			if (payCents() < 50) { payMsg(cfg.i18n.payZero); return; }
			setBusy(true);
			// Stripe checks what was typed in its own fields before anything is saved.
			payState.elements.submit().then(function (r) {
				if (r.error) { setBusy(false); payMsg(r.error.message || cfg.i18n.payFailed); return; }
				send();
			}).catch(function () { setBusy(false); payMsg(cfg.i18n.payFailed); });
		}

		function confirmPay() {
			setBusy(true);
			status.textContent = cfg.i18n.paying;
			payState.stripe.confirmPayment({
				elements: payState.elements,
				clientSecret: payState.secret,
				confirmParams: { return_url: returnUrl() },
				redirect: 'if_required'
			}).then(function (result) {
				if (result.error && result.error.code !== 'payment_intent_unexpected_state') {
					setBusy(false);
					if (submit) { submit.textContent = cfg.i18n.payRetry; }
					payMsg(result.error.message || cfg.i18n.payFailed);
					return;
				}
				verifyPayment(payState.intent, false);
			}).catch(function () { setBusy(false); payMsg(cfg.i18n.payFailed); });
		}

		function returnUrl() {
			var u = new URL(window.location.href);
			u.hash = '';
			u.searchParams.delete('payment_intent');
			u.searchParams.delete('payment_intent_client_secret');
			u.searchParams.delete('redirect_status');
			u.searchParams.set('twf_form', String(cfg.formId));
			return u.toString();
		}

		/** Asks the server to read the payment back from Stripe: only then the request counts as received. */
		function verifyPayment(intent, resumed) {
			setBusy(true);
			status.textContent = cfg.i18n.payChecking;
			var body = new FormData();
			body.append('payment_intent', intent);
			fetch(pay.confirm, { method: 'POST', body: body, headers: { 'Accept': 'application/json' }, credentials: 'omit' })
				.then(function (res) { return res.json().catch(function () { return {}; }).then(function (data) { return { status: res.status, data: data }; }); })
				.then(function (r) {
					var d = r.data || {};
					if (r.status === 200 && d.ok) { setBusy(false); done(d.confirmation || {}); return; }
					setBusy(false);
					if (r.status === 202 || d.pending) { lockForm(true); payMsg(d.message || ''); if (submit) { submit.hidden = true; } return; }
					if (resumed) { payMsg((d.message || cfg.i18n.payFailed) + ' ' + cfg.i18n.payRestart); return; }
					if (submit) { submit.textContent = cfg.i18n.payRetry; }
					payMsg(d.message || cfg.i18n.payFailed);
				})
				.catch(function () { setBusy(false); payMsg(cfg.i18n.error); });
		}

		var pay = (!preview && cfg.payment) ? cfg.payment : null;
		var payBox = pay ? form.querySelector('[data-twf-payment]') : null;
		var payState = { stripe: null, elements: null, element: null, mounted: false, secret: '', intent: '', cents: 0 };

		refresh();
		showStep(firstStep());
		if (pay && params.get('payment_intent') && params.get('twf_form') === String(cfg.formId)) {
			// Back from a payment page (TWINT, 3-D Secure): check how it went and clean the address.
			var back = params.get('payment_intent');
			if (window.history && window.history.replaceState) {
				var clean = new URL(window.location.href);
				['payment_intent', 'payment_intent_client_secret', 'redirect_status', 'twf_form'].forEach(function (k) { clean.searchParams.delete(k); });
				window.history.replaceState(null, '', clean.toString());
			}
			if (payBox) { payBox.hidden = false; }
			verifyPayment(back, true);
		}
		if (preview) {
			qsa(form, '.twf-nav button').forEach(function (b) { b.hidden = b.classList.contains('twf-submit') ? false : true; });
		}
	}

	function boot() { qsa(document, '.twf-form').forEach(init); }
	if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', boot); } else { boot(); }
	window.twfInit = init;
})();
