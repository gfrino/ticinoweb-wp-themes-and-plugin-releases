<?php
/**
 * Admin controller for TW Formulari.
 *
 * @package TicinoWeb\TWFormulari
 */

namespace TicinoWeb\TWFormulari;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Admin {

	/** @var string */
	private $hook_suffix = '';

	/** @return void */
	public function init(): void {
		add_action( 'admin_menu', [ $this, 'register_admin_menu' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_assets' ] );
		add_action( 'admin_post_twf_save_settings', [ $this, 'handle_save_settings' ] );
		add_action( 'admin_post_twf_save_features', [ $this, 'handle_save_features' ] );
		add_action( 'admin_post_twf_generate_test_pdf', [ $this, 'handle_generate_test_pdf' ] );
		add_action( 'wp_ajax_twf_get_forms', [ $this, 'handle_get_forms' ] );
	}

	/** @return void */
	public function register_admin_menu(): void {
		$this->hook_suffix = add_menu_page(
			__( 'TW Formulari', 'tw-formulari' ),
			__( 'TW Formulari', 'tw-formulari' ),
			'manage_options',
			'tw-formulari',
			[ $this, 'render_page' ],
			'dashicons-media-document',
			32
		);
		// The first entry of the submenu is the same page: call it what it is.
		add_submenu_page( 'tw-formulari', __( 'Impostazioni', 'tw-formulari' ), __( 'Impostazioni', 'tw-formulari' ), 'manage_options', 'tw-formulari', [ $this, 'render_page' ] );
	}

	/**
	 * Tabs of the page: the settings are always there, the others only when their function is on.
	 *
	 * @return array<string, string> slug => label
	 */
	public static function tabs(): array {
		$tabs = [ 'features' => __( 'Impostazioni', 'tw-formulari' ) ];
		if ( Features::enabled( 'adapters' ) ) {
			$tabs['adapters'] = __( 'Moduli di altri plugin', 'tw-formulari' );
		}
		if ( Features::enabled( 'pdf' ) ) {
			$tabs['pdf'] = __( 'PDF', 'tw-formulari' );
		}
		// Only while Forminator is active: the import button is dynamic.
		if ( \TicinoWeb\TWFormulari\Builder\ForminatorImporter::detected() ) {
			$tabs['forminator'] = __( 'Importa da Forminator', 'tw-formulari' );
		}
		return $tabs;
	}

	/** The tab being shown (falls back to the settings when the requested one is off). */
	public static function current_tab(): string {
		$wanted = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'features'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return isset( self::tabs()[ $wanted ] ) ? $wanted : 'features';
	}

	public static function tab_url( string $tab, array $args = [] ): string {
		return add_query_arg( array_merge( [ 'page' => 'tw-formulari', 'tab' => $tab ], $args ), admin_url( 'admin.php' ) );
	}

	/**
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public function enqueue_admin_assets( string $hook ): void {
		if ( $hook !== $this->hook_suffix ) {
			return;
		}

		$tab = self::current_tab();
		if ( 'pdf' === $tab ) {
			wp_enqueue_media(); // the logo is chosen from the media library.
		}
		wp_enqueue_style( 'twf-admin-style', TW_FORMULARI_URL . 'admin/assets/admin.css', [], \TicinoWeb\TWFormulari\twf_asset_ver( 'admin/assets/admin.css' ) );
		wp_enqueue_script( 'twf-admin-script', TW_FORMULARI_URL . 'admin/assets/admin.js', [ 'jquery' ], \TicinoWeb\TWFormulari\twf_asset_ver( 'admin/assets/admin.js' ), true );
		if ( 'forminator' === $tab ) {
			wp_enqueue_script( 'twf-forminator-import', TW_FORMULARI_URL . 'admin/assets/forminator-import.js', [], \TicinoWeb\TWFormulari\twf_asset_ver( 'admin/assets/forminator-import.js' ), true );
			wp_localize_script( 'twf-forminator-import', 'twfFmt', [
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( \TicinoWeb\TWFormulari\Builder\ForminatorAdmin::NONCE ),
				'i18n'    => [
					'forms'       => __( 'Creo i moduli…', 'tw-formulari' ),
					'formsDone'   => __( 'Moduli creati: %1$d (già presenti: %2$d).', 'tw-formulari' ),
					'entries'     => __( '«%1$s»: copiate %2$d di %3$d compilazioni…', 'tw-formulari' ),
					'entriesDone' => __( '«%1$s»: %2$d compilazioni copiate.', 'tw-formulari' ),
					'settings'    => __( 'Porto le impostazioni…', 'tw-formulari' ),
					'keyDone'     => __( 'Importata in Pagamenti: %s', 'tw-formulari' ),
					'finished'    => __( 'Importazione finita. Aggiorno la pagina…', 'tw-formulari' ),
					'stopped'     => __( 'Importazione interrotta. Puoi riprovare: riparte da dove si era fermata.', 'tw-formulari' ),
					'badAnswer'   => __( 'Risposta inattesa dal sito. Riprova.', 'tw-formulari' ),
					'leave'       => __( 'L’importazione è in corso: se esci si ferma (potrai riprenderla).', 'tw-formulari' ),
					'confirmUndo' => __( 'Eliminare i moduli importati da Forminator, con le loro compilazioni e i loro allegati? Forminator e le impostazioni di Stripe non vengono toccati. L’operazione non si può annullare.', 'tw-formulari' ),
					'undoing'     => __( 'Elimino ciò che avevo importato…', 'tw-formulari' ),
					'undone'      => __( 'Eliminati %1$d moduli e %2$d compilazioni.', 'tw-formulari' ),
				],
			] );
		}
		if ( 'adapters' !== $tab ) {
			return; // the form picker (AJAX) is needed only on its own tab.
		}
		$form_settings = Settings::get_form_settings();
		wp_localize_script( 'twf-admin-script', 'twfAdmin', [
			'ajaxUrl'       => admin_url( 'admin-ajax.php' ),
			'nonce'         => wp_create_nonce( 'twf_discover_forms' ),
			'currentEngine' => $form_settings['active_engine'] ?? 'auto',
			'currentFormId' => $form_settings['target_form_id'] ?? '',
			'strings'       => [
				'choose'       => __( 'Seleziona un formulario', 'tw-formulari' ),
				'loading'      => __( 'Ricerca dei formulari…', 'tw-formulari' ),
				'empty'        => __( 'Nessun formulario rilevato. Puoi inserire l’ID nelle impostazioni avanzate.', 'tw-formulari' ),
				'chooseEngine' => __( 'Sono presenti più sistemi: selezionane uno per vedere i suoi formulari.', 'tw-formulari' ),
				'manual'       => __( 'Per un modulo POST personalizzato, inserisci l’ID nelle impostazioni avanzate.', 'tw-formulari' ),
				'required'     => __( 'Seleziona un formulario oppure inserisci l’ID manuale nelle impostazioni avanzate.', 'tw-formulari' ),
				'error'        => __( 'Impossibile aggiornare l’elenco. Riprova o usa l’ID manuale.', 'tw-formulari' ),
				'current'      => __( 'Configurazione attuale', 'tw-formulari' ),
				'formsFound'   => __( '%d formulari rilevati.', 'tw-formulari' ),
				'oneFormFound' => __( '1 formulario rilevato.', 'tw-formulari' ),
			],
		] );
	}

	/** @return void */
	public function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Accesso non consentito.', 'tw-formulari' ) );
		}

		$message = sanitize_key( $_GET['message'] ?? '' );
		$tab     = self::current_tab();
		?>
		<div class="wrap twf-wrap">
			<header class="twf-header">
				<div>
					<div class="twf-title-row">
						<h1>TW Formulari</h1>
						<span class="twf-version">v<?php echo esc_html( TW_FORMULARI_VERSION ); ?></span>
					</div>
					<p><?php esc_html_e( 'Moduli, pagamenti e PDF: attiva solo quello che ti serve.', 'tw-formulari' ); ?></p>
				</div>
			</header>

			<nav class="nav-tab-wrapper twf-tabs" aria-label="<?php esc_attr_e( 'Sezioni', 'tw-formulari' ); ?>">
				<?php foreach ( self::tabs() as $slug => $label ) : ?>
					<a class="nav-tab<?php echo $slug === $tab ? ' nav-tab-active' : ''; ?>" href="<?php echo esc_url( self::tab_url( $slug ) ); ?>"<?php echo $slug === $tab ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $label ); ?></a>
				<?php endforeach; ?>
			</nav>

			<?php if ( 'saved' === $message ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Impostazioni salvate.', 'tw-formulari' ); ?></p></div>
			<?php elseif ( 'missing_form' === $message ) : ?>
				<div class="notice notice-error"><p><?php esc_html_e( 'Seleziona il formulario da gestire oppure inserisci il suo ID nelle impostazioni avanzate.', 'tw-formulari' ); ?></p></div>
			<?php endif; ?>

			<?php
			$view = [ 'features' => 'features.php', 'adapters' => 'adapters.php', 'pdf' => 'pdf.php', 'forminator' => 'forminator.php' ][ $tab ];
			require TW_FORMULARI_PATH . 'admin/views/' . $view;
			?>
		</div>
		<?php
	}

	/** Saves the switches of the "Impostazioni" tab. */
	public function handle_save_features(): void {
		check_admin_referer( 'twf_save_features_action', 'twf_features_nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Permessi insufficienti.', 'tw-formulari' ) );
		}
		$posted = isset( $_POST['twf_features'] ) && is_array( $_POST['twf_features'] ) ? wp_unslash( $_POST['twf_features'] ) : [];
		Features::save( $posted );
		wp_safe_redirect( self::tab_url( 'features', [ 'message' => 'saved' ] ) );
		exit;
	}

	/** Saves the "Moduli di altri plugin" tab (form + e-mail) or the "PDF" tab (identity of the document). */
	public function handle_save_settings(): void {
		check_admin_referer( 'twf_save_settings_action', 'twf_settings_nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Permessi insufficienti.', 'tw-formulari' ) );
		}

		$tab = isset( $_POST['twf_tab'] ) && 'pdf' === sanitize_key( wp_unslash( $_POST['twf_tab'] ) ) ? 'pdf' : 'adapters';

		if ( 'adapters' === $tab ) {
			$form  = isset( $_POST['twf_form'] ) && is_array( $_POST['twf_form'] ) ? wp_unslash( $_POST['twf_form'] ) : [];
			$email = isset( $_POST['twf_email'] ) && is_array( $_POST['twf_email'] ) ? wp_unslash( $_POST['twf_email'] ) : [];

			$form['target_form_id'] = Settings::resolve_target_form_id( $form );
			if ( '' === $form['target_form_id'] ) {
				wp_safe_redirect( self::tab_url( 'adapters', [ 'message' => 'missing_form' ] ) );
				exit;
			}
			Settings::save_form_settings( $form );
			Settings::save_email_settings( $email );
		} else {
			$pdf = isset( $_POST['twf_pdf'] ) && is_array( $_POST['twf_pdf'] ) ? wp_unslash( $_POST['twf_pdf'] ) : [];
			Settings::save_pdf_settings( $pdf );
			if ( ! empty( $_POST['twf_preview'] ) ) {
				$this->stream_current_demo();
			}
		}

		wp_safe_redirect( self::tab_url( $tab, [ 'message' => 'saved' ] ) );
		exit;
	}

	/** @return void */
	public function handle_get_forms(): void {
		check_ajax_referer( 'twf_discover_forms', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => __( 'Permessi insufficienti.', 'tw-formulari' ) ], 403 );
		}

		$engine = sanitize_key( wp_unslash( $_POST['engine'] ?? '' ) );
		$force  = ! empty( $_POST['force'] );
		$manager = FormManager::get_instance();
		$resolved_engine = $manager->resolve_engine_id( $engine );
		if ( '' === $resolved_engine ) {
			wp_send_json_success( [ 'forms' => [], 'resolvedEngine' => '' ] );
			return;
		}

		$adapters = $manager->get_adapters();
		if ( ! isset( $adapters[ $resolved_engine ] ) || ( 'generic' !== $resolved_engine && ! $adapters[ $resolved_engine ]->is_available() ) ) {
			wp_send_json_error( [ 'message' => __( 'Il sistema formulario selezionato non è disponibile.', 'tw-formulari' ) ], 400 );
			return;
		}

		try {
			$forms = $manager->get_forms_for_engine( $resolved_engine, $force );
		} catch ( \Throwable ) {
			wp_send_json_error( [ 'message' => __( 'Impossibile leggere i formulari dal sistema selezionato.', 'tw-formulari' ) ], 500 );
			return;
		}

		wp_send_json_success( [
			'forms'          => $forms,
			'resolvedEngine' => $resolved_engine,
		] );
	}

	/** @return void */
	public function handle_generate_test_pdf(): void {
		check_admin_referer( 'twf_test_pdf_action' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Permessi insufficienti.', 'tw-formulari' ) );
		}
		$this->stream_current_demo();
	}

	/** @return void */
	private function stream_current_demo(): void {
		if ( ! Features::enabled( 'pdf' ) ) {
			wp_die( esc_html__( 'Il PDF è disattivato: attivalo in TW Formulari → Impostazioni.', 'tw-formulari' ) );
		}
		$settings = Settings::get_form_settings();
		$linked   = Features::enabled( 'adapters' ) && '' !== trim( (string) ( $settings['target_form_id'] ?? '' ) );

		try {
			if ( $linked ) {
				$data = FormManager::get_instance()->get_preview_data_for_form(
					(string) ( $settings['active_engine'] ?? 'auto' ),
					(string) $settings['target_form_id']
				);
			} else {
				// No form of another plugin is linked: show the document with a small sample of answers.
				$data = DataNormalizer::preview_from_schema( [
					[ 'id' => 'nome', 'label' => __( 'Nome e cognome', 'tw-formulari' ), 'type' => 'text' ],
					[ 'id' => 'email', 'label' => __( 'E-mail', 'tw-formulari' ), 'type' => 'email' ],
					[ 'id' => 'telefono', 'label' => __( 'Telefono', 'tw-formulari' ), 'type' => 'tel' ],
					[ 'id' => 'messaggio', 'label' => __( 'Messaggio', 'tw-formulari' ), 'type' => 'textarea' ],
				] );
			}
		} catch ( \Throwable $error ) {
			wp_die( esc_html__( 'Impossibile leggere i campi aggiornati del formulario selezionato. Aggiorna l’elenco dei formulari e verifica la configurazione.', 'tw-formulari' ) );
		}

		try {
			PdfGenerator::stream_to_browser( $data, 'I' );
			exit;
		} catch ( \Throwable $error ) {
			wp_die( esc_html__( 'Impossibile generare il PDF di prova. Verifica che il pacchetto del plugin e le estensioni PHP richieste siano disponibili.', 'tw-formulari' ) );
		}
	}
}
