(function ($) {
	'use strict';

	$(function () {
		var $form = $('#twf-settings-form');
		var $engine = $('#twf-active-engine');
		var $formPicker = $('#twf-target-form');
		var $manualFormId = $('#twf-target-form-manual');
		var $refreshForms = $('#twf-refresh-forms');
		var $discoveryStatus = $('#twf-form-discovery-status');
		var $submitButtons = $form.find('button[type="submit"]');
		var config = window.twfAdmin || null;
		var discoverySequence = 0;
		var $facilityToggle = $('#twf-send-facility');
		var $logoInput = $('#twf-logo-url-input');
		var $logoImage = $('#twf-logo-img');

		function updateConditionalFields() {
			$('#twf-generic-help').prop('hidden', $engine.val() !== 'generic');
			$('#twf-facility-email-row').prop('hidden', !$facilityToggle.prop('checked'));
		}

		function formOptionLabel(form) {
			var name = form.name || ('Formulario ' + form.id);
			return name + (form.location ? ' — ' + form.location : '') + ' (ID: ' + form.id + ')';
		}

		function populateForms(forms, selectedId, preserveMissing) {
			$formPicker.empty().append($('<option>', { value: '', text: config.strings.choose }));
			$.each(forms, function (_, form) {
				$formPicker.append($('<option>', { value: form.id, text: formOptionLabel(form) }));
			});
			if (selectedId && !$formPicker.find('option').filter(function () { return $(this).val() === selectedId; }).length && preserveMissing) {
				$formPicker.append($('<option>', { value: selectedId, text: config.strings.current + ' — ID: ' + selectedId }));
			}
			$formPicker.val(selectedId || '');
		}

		function loadForms(force, preserveSelection) {
			if (!config) {
				return;
			}
			var engine = $engine.val();
			var selectedId = preserveSelection ? $formPicker.val() : '';
			var requestSequence = ++discoverySequence;
			if (!selectedId && engine === config.currentEngine) {
				selectedId = config.currentFormId;
			}
			if (!preserveSelection && engine !== config.currentEngine) {
				populateForms([], '', false);
			}

			$formPicker.attr('aria-busy', 'true');
			$refreshForms.prop('disabled', true).addClass('is-loading');
			$submitButtons.prop('disabled', true);
			$discoveryStatus.removeClass('is-error is-success').text(config.strings.loading);

			$.post(config.ajaxUrl, {
				action: 'twf_get_forms',
				nonce: config.nonce,
				engine: engine,
				force: force ? 1 : 0
			}).done(function (response) {
				if (requestSequence !== discoverySequence) {
					return;
				}
				if (!response || !response.success) {
					populateForms([], selectedId, true);
					$discoveryStatus.addClass('is-error').text(config.strings.error);
					return;
				}
				var forms = response.data.forms || [];
				populateForms(forms, selectedId, engine === config.currentEngine);
				if (!forms.length) {
					if (engine === 'auto' && !response.data.resolvedEngine) {
						$discoveryStatus.text(config.strings.chooseEngine);
					} else if (engine === 'generic') {
						$discoveryStatus.text(config.strings.manual);
					} else {
						$discoveryStatus.text(config.strings.empty);
					}
				} else {
					$discoveryStatus.addClass('is-success').text(forms.length === 1 ? config.strings.oneFormFound : config.strings.formsFound.replace('%d', forms.length));
				}
			}).fail(function () {
				if (requestSequence !== discoverySequence) {
					return;
				}
				populateForms([], selectedId, true);
				$discoveryStatus.addClass('is-error').text(config.strings.error);
			}).always(function () {
				if (requestSequence !== discoverySequence) {
					return;
				}
				$formPicker.removeAttr('aria-busy');
				$refreshForms.prop('disabled', false).removeClass('is-loading');
				$submitButtons.prop('disabled', false);
			});
		}

		$engine.add($facilityToggle).on('change', updateConditionalFields);
		$engine.on('change', function () { loadForms(false, false); });
		$formPicker.on('change', function () { $manualFormId.val(''); });
		$refreshForms.on('click', function () { loadForms(true, true); });
		updateConditionalFields();
		loadForms(false, true);

		$('.twf-tab-form').on('input change', ':input', function () {
			$(this).closest('form').find('.twf-unsaved').text('Modifiche non salvate');
		});
		$('.twf-tab-form').on('submit', function () {
			$(this).find('.twf-unsaved').text('Salvataggio…');
		});
		// Only the tab that links another plugin's form needs one before saving.
		$form.on('submit', function (event) {
			if (!$.trim($formPicker.val()) && !$.trim($manualFormId.val())) {
				event.preventDefault();
				$discoveryStatus.addClass('is-error').text(config ? config.strings.required : 'Seleziona un formulario.');
				$formPicker.trigger('focus');
				$form.find('.twf-unsaved').text('');
			}
		});

		// Function switches: a function that needs another one is greyed out while that one is off.
		var $features = $('#twf-features-form');
		function syncFeatures() {
			$features.find('.twf-feat__row').each(function () {
				var requires = $(this).data('requires');
				if (!requires) { return; }
				var parentOn = $features.find('.twf-feat__row[data-feature="' + requires + '"] input[type=checkbox]').prop('checked');
				var $box = $(this).find('input[type=checkbox]');
				if (!parentOn) { $box.prop('checked', false); }
				$box.prop('disabled', !parentOn);
				$(this).toggleClass('is-blocked', !parentOn);
			});
			$features.find('.twf-feat__row').each(function () {
				var on = $(this).find('input[type=checkbox]').prop('checked');
				$(this).find('.twf-switch__text').text(on ? 'Attivo' : 'Spento');
			});
		}
		$features.on('change', 'input[type=checkbox]', syncFeatures);
		if ($features.length) { syncFeatures(); }

		$('#twf-upload-logo-btn').on('click', function (event) {
			event.preventDefault();
			var frame = wp.media({ title: 'Seleziona il logo', button: { text: 'Usa questo logo' }, library: { type: 'image' }, multiple: false });
			frame.on('select', function () {
				var attachment = frame.state().get('selection').first().toJSON();
				$logoInput.val(attachment.url).trigger('change');
				$logoImage.attr('src', attachment.url).prop('hidden', false);
			});
			frame.open();
		});

		$('#twf-reset-logo-btn').on('click', function (event) {
			event.preventDefault();
			$logoInput.val('').trigger('change');
			$logoImage.attr('src', '').prop('hidden', true);
		});
	});
})(jQuery);
