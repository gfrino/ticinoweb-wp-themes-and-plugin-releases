(function () {
	'use strict';
	var cfg = window.twfFmt;
	var box = document.getElementById('twf-fmt');
	if (!cfg || !box) { return; }

	var startBtn = document.getElementById('twf-fmt-start');
	var undoBtn = document.getElementById('twf-fmt-undo');
	var progress = document.getElementById('twf-fmt-progress');
	var bar = document.getElementById('twf-fmt-bar');
	var line = document.getElementById('twf-fmt-line');
	var log = document.getElementById('twf-fmt-log');
	var busy = false;

	function say(text, cls) {
		var li = document.createElement('li');
		li.textContent = text;
		if (cls) { li.className = cls; }
		log.appendChild(li);
	}

	/** One request to the server; resolves with the "data" of a successful answer. */
	function call(action, data) {
		var body = new FormData();
		body.append('action', action);
		body.append('nonce', cfg.nonce);
		Object.keys(data || {}).forEach(function (k) { body.append(k, data[k]); });
		return fetch(cfg.ajaxUrl, { method: 'POST', body: body, credentials: 'same-origin' })
			.then(function (r) { return r.json().catch(function () { throw new Error(cfg.i18n.badAnswer); }); })
			.then(function (j) {
				if (!j || !j.success) { throw new Error((j && j.data && j.data.message) || cfg.i18n.badAnswer); }
				return j.data;
			});
	}

	function lock(on) {
		busy = on;
		if (startBtn) { startBtn.disabled = on; }
		if (undoBtn) { undoBtn.disabled = on; }
		window.onbeforeunload = on ? function () { return cfg.i18n.leave; } : null;
	}

	function fail(err) {
		lock(false);
		line.textContent = cfg.i18n.stopped;
		say(err.message || cfg.i18n.badAnswer, 'is-error');
	}

	function start() {
		if (busy) { return; }
		lock(true);
		progress.hidden = false;
		log.innerHTML = '';
		bar.value = 0;
		line.textContent = cfg.i18n.forms;

		call('twf_fmt_step', { phase: 'forms' }).then(function (r) {
			say(cfg.i18n.formsDone.replace('%1$d', r.created).replace('%2$d', r.existing));
			var todo = r.forms.filter(function (f) { return !f.done && f.twf_id; });
			var total = todo.reduce(function (n, f) { return n + f.total; }, 0) || 1;
			var done = 0;
			var chain = Promise.resolve();

			todo.forEach(function (f) {
				chain = chain.then(function () { return copyEntries(f); });
			});
			function copyEntries(f) {
				var before = 0;
				function next() {
					return call('twf_fmt_step', { phase: 'entries', form: f.id }).then(function (b) {
						done += Math.max(0, b.imported - before);
						before = b.imported;
						bar.value = Math.min(99, Math.round(done / total * 100));
						line.textContent = cfg.i18n.entries.replace('%1$s', f.title).replace('%2$d', b.imported).replace('%3$d', f.total);
						return b.done ? b : next();
					});
				}
				return next().then(function (b) { say(cfg.i18n.entriesDone.replace('%1$s', f.title).replace('%2$d', b.imported)); });
			}
			return chain;
		}).then(function () {
			line.textContent = cfg.i18n.settings;
			return call('twf_fmt_step', { phase: 'settings' });
		}).then(function (s) {
			(s.imported || []).forEach(function (i) { say(cfg.i18n.keyDone.replace('%s', i)); });
			bar.value = 100;
			line.textContent = cfg.i18n.finished;
			lock(false);
			window.setTimeout(function () { window.location.reload(); }, 1200);
		}).catch(fail);
	}

	function undo() {
		if (busy || !window.confirm(cfg.i18n.confirmUndo)) { return; }
		lock(true);
		progress.hidden = false;
		log.innerHTML = '';
		line.textContent = cfg.i18n.undoing;
		call('twf_fmt_undo').then(function (r) {
			say(cfg.i18n.undone.replace('%1$d', r.forms).replace('%2$d', r.entries));
			lock(false);
			window.setTimeout(function () { window.location.reload(); }, 1200);
		}).catch(fail);
	}

	if (startBtn) { startBtn.addEventListener('click', start); }
	if (undoBtn) { undoBtn.addEventListener('click', undo); }
})();
