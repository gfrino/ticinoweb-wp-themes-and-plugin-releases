<?php
/**
 * "Impostazioni" tab: which functions of the plugin are on.
 *
 * @package TicinoWeb\TWFormulari
 */

use TicinoWeb\TWFormulari\Admin;
use TicinoWeb\TWFormulari\Builder\BuilderAdmin;
use TicinoWeb\TWFormulari\Builder\EntriesAdmin;
use TicinoWeb\TWFormulari\Builder\ForminatorImporter;
use TicinoWeb\TWFormulari\Builder\PaymentsAdmin;
use TicinoWeb\TWFormulari\Features;
use TicinoWeb\TWFormulari\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$stored = Features::stored();
$active = Features::all();
$form   = Settings::get_form_settings();

/** @var array<int, array{key:string, title:string, text:string, requires:string, requires_label:string, links:array<int, array{0:string,1:string}>}> $features */
$features = [
	[
		'key'            => 'builder',
		'title'          => __( 'Moduli propri', 'tw-formulari' ),
		'text'           => __( 'Crea i moduli del sito con un editor visuale (campi, condizioni, calcoli, e-mail di avviso e di conferma) e raccogli le compilazioni. Si inseriscono nelle pagine con il codice [tw_form id="N"].', 'tw-formulari' ),
		'requires'       => '',
		'requires_label' => '',
		'links'          => [
			[ __( 'Moduli', 'tw-formulari' ), BuilderAdmin::list_url() ],
			[ __( 'Compilazioni', 'tw-formulari' ), EntriesAdmin::list_url() ],
		],
	],
	[
		'key'            => 'payments',
		'title'          => __( 'Pagamenti con Stripe', 'tw-formulari' ),
		'text'           => __( 'Fai pagare online i moduli propri: carte, Apple Pay, Google Pay e TWINT. Serve un account Stripe; le chiavi si inseriscono nella scheda Pagamenti, dove si sceglie anche tra prova e reale.', 'tw-formulari' ),
		'requires'       => 'builder',
		'requires_label' => __( 'Richiede i moduli propri.', 'tw-formulari' ),
		'links'          => [ [ __( 'Pagamenti', 'tw-formulari' ), PaymentsAdmin::url() ] ],
	],
	[
		'key'            => 'pdf',
		'title'          => __( 'PDF con le risposte', 'tw-formulari' ),
		'text'           => __( 'Crea un PDF ordinato con logo e dati della tua attività. Nei moduli propri si accende modulo per modulo e allega il PDF alle e-mail. Se lo lasci spento, il PDF non viene mai creato.', 'tw-formulari' ),
		'requires'       => '',
		'requires_label' => '',
		'links'          => [ [ __( 'Scheda PDF', 'tw-formulari' ), Admin::tab_url( 'pdf' ) ] ],
	],
	[
		'key'            => 'adapters',
		'title'          => __( 'PDF dei moduli di altri plugin', 'tw-formulari' ),
		'text'           => __( 'Per il modulo di Elementor, Contact Form 7, WPForms, Gravity Forms, Fluent Forms o un modulo POST: a ogni invio crea il PDF e lo spedisce a chi ha compilato e a una copia interna. Un solo modulo per sito.', 'tw-formulari' ),
		'requires'       => 'pdf',
		'requires_label' => __( 'Richiede il PDF con le risposte.', 'tw-formulari' ),
		'links'          => [ [ __( 'Scheda Moduli di altri plugin', 'tw-formulari' ), Admin::tab_url( 'adapters' ) ] ],
	],
];
?>
<?php if ( ForminatorImporter::detected() ) : ?>
	<?php
	$fmt_forms   = count( ForminatorImporter::forms() );
	$fmt_entries = 0;
	foreach ( ForminatorImporter::forms() as $fmt_form ) {
		$fmt_entries += ForminatorImporter::entry_count( $fmt_form['id'] );
	}
	$fmt_state = ForminatorImporter::state();
	?>
	<div class="twf-tabpage" style="margin-bottom:20px">
		<section class="twf-card twf-fmt-promo">
			<div>
				<h2><?php esc_html_e( 'Forminator è sul sito', 'tw-formulari' ); ?></h2>
				<p><?php
					echo esc_html( sprintf(
						/* translators: 1: forms, 2: submissions */
						__( '%1$d moduli e %2$d compilazioni possono passare a TW Formulari, con impostazioni e allegati. Forminator non viene toccato.', 'tw-formulari' ),
						$fmt_forms,
						$fmt_entries
					) );
					echo ! empty( $fmt_state['forms'] ) ? ' ' . esc_html__( 'Una parte è già stata importata.', 'tw-formulari' ) : '';
				?></p>
			</div>
			<a class="button button-primary button-hero" href="<?php echo esc_url( Admin::tab_url( 'forminator' ) ); ?>"><?php echo ! empty( $fmt_state['forms'] ) ? esc_html__( 'Apri l’importazione', 'tw-formulari' ) : esc_html__( 'Importa da Forminator', 'tw-formulari' ); ?></a>
		</section>
	</div>
<?php endif; ?>
<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="twf-tab-form twf-tabpage" id="twf-features-form">
	<?php wp_nonce_field( 'twf_save_features_action', 'twf_features_nonce' ); ?>
	<input type="hidden" name="action" value="twf_save_features">

	<div class="twf-card">
		<h2><?php esc_html_e( 'Funzioni del plugin', 'tw-formulari' ); ?></h2>
		<p class="twf-card__lead"><?php esc_html_e( 'Attiva solo ciò che ti serve. Una funzione spenta non fa nulla: niente voci nel menu, niente elaborazioni in background.', 'tw-formulari' ); ?></p>

		<ul class="twf-feat">
			<?php foreach ( $features as $f ) : ?>
				<?php
				$key       = $f['key'];
				$on        = ! empty( $stored[ $key ] );
				$blocked   = '' !== $f['requires'] && empty( $stored[ $f['requires'] ] );
				$effective = ! empty( $active[ $key ] );
				?>
				<li class="twf-feat__row<?php echo $effective ? ' is-on' : ''; ?><?php echo $blocked ? ' is-blocked' : ''; ?>" data-feature="<?php echo esc_attr( $key ); ?>" data-requires="<?php echo esc_attr( $f['requires'] ); ?>">
					<div class="twf-feat__copy">
						<h3 id="twf-feat-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $f['title'] ); ?></h3>
						<p><?php echo esc_html( $f['text'] ); ?></p>
						<?php if ( '' !== $f['requires'] ) : ?>
							<p class="twf-feat__req"><?php echo esc_html( $f['requires_label'] ); ?></p>
						<?php endif; ?>
						<?php if ( 'adapters' === $key && $effective && '' === trim( (string) $form['target_form_id'] ) ) : ?>
							<p class="twf-feat__warn"><?php esc_html_e( 'Manca ancora il modulo da collegare.', 'tw-formulari' ); ?></p>
						<?php endif; ?>
						<?php if ( $effective ) : ?>
							<p class="twf-feat__links">
								<?php foreach ( $f['links'] as $link ) : ?>
									<a href="<?php echo esc_url( $link[1] ); ?>"><?php echo esc_html( $link[0] ); ?> →</a>
								<?php endforeach; ?>
							</p>
						<?php endif; ?>
					</div>
					<label class="twf-switch">
						<input type="checkbox" name="twf_features[<?php echo esc_attr( $key ); ?>]" value="1" aria-labelledby="twf-feat-<?php echo esc_attr( $key ); ?>" <?php checked( $on ); ?> <?php disabled( $blocked ); ?>>
						<span class="twf-switch__track" aria-hidden="true"></span>
						<span class="twf-switch__text"><?php echo $effective ? esc_html__( 'Attivo', 'tw-formulari' ) : esc_html__( 'Spento', 'tw-formulari' ); ?></span>
					</label>
				</li>
			<?php endforeach; ?>
		</ul>

		<p class="twf-card__note"><?php esc_html_e( 'Spegnere una funzione non cancella nulla: moduli, compilazioni e impostazioni restano salvati e tornano accendendola di nuovo.', 'tw-formulari' ); ?></p>
	</div>

	<footer class="twf-actions">
		<span class="twf-unsaved" aria-live="polite"></span>
		<div><button type="submit" class="button button-primary"><?php esc_html_e( 'Salva', 'tw-formulari' ); ?></button></div>
	</footer>
</form>
