<?php
/**
 * "PDF" tab: identity and fixed text of the document.
 *
 * @package TicinoWeb\TWFormulari
 */

use TicinoWeb\TWFormulari\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$pdf_settings = Settings::get_pdf_settings();
$preview_url  = wp_nonce_url( admin_url( 'admin-post.php?action=twf_generate_test_pdf' ), 'twf_test_pdf_action' );
?>
<form id="twf-pdf-form" class="twf-tab-form twf-tabpage" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
	<?php wp_nonce_field( 'twf_save_settings_action', 'twf_settings_nonce' ); ?>
	<input type="hidden" name="action" value="twf_save_settings">
	<input type="hidden" name="twf_tab" value="pdf">

	<section class="twf-card" aria-labelledby="twf-document-heading">
		<h2 id="twf-document-heading"><?php esc_html_e( 'Documento PDF', 'tw-formulari' ); ?></h2>
		<p class="twf-card__lead"><?php esc_html_e( 'Qui imposti l’identità e i testi fissi del PDF: le risposte arrivano dal modulo. Vale per i moduli propri (dove il PDF si accende modulo per modulo) e per il modulo di un altro plugin.', 'tw-formulari' ); ?></p>
		<div class="twf-fields twf-document-fields">
			<div class="twf-field"><label for="twf-facility-name">Nome azienda o struttura</label><input id="twf-facility-name" type="text" name="twf_pdf[facility_name]" value="<?php echo esc_attr( $pdf_settings['facility_name'] ); ?>" required></div>
			<div class="twf-field twf-logo-field">
				<span class="twf-field-label">Logo <span class="twf-optional">facoltativo</span></span>
				<input id="twf-logo-url-input" type="hidden" name="twf_pdf[logo_url]" value="<?php echo esc_attr( $pdf_settings['logo_url'] ); ?>">
				<div class="twf-logo-actions">
					<button type="button" id="twf-upload-logo-btn" class="button">Scegli dalla Libreria Media</button>
					<button type="button" id="twf-reset-logo-btn" class="button-link-delete">Rimuovi</button>
					<img id="twf-logo-img" src="<?php echo esc_url( $pdf_settings['logo_url'] ); ?>" alt="" <?php echo empty( $pdf_settings['logo_url'] ) ? 'hidden' : ''; ?>>
				</div>
			</div>
			<div class="twf-grid-two">
				<div class="twf-field"><label for="twf-document-title">Titolo documento</label><input id="twf-document-title" type="text" name="twf_pdf[document_title]" value="<?php echo esc_attr( $pdf_settings['document_title'] ); ?>"></div>
				<div class="twf-field"><label for="twf-document-subtitle">Sottotitolo</label><input id="twf-document-subtitle" type="text" name="twf_pdf[document_subtitle]" value="<?php echo esc_attr( $pdf_settings['document_subtitle'] ); ?>"></div>
			</div>
			<div class="twf-field"><label for="twf-mandatory-notice">Nota in fondo al documento <span class="twf-optional">facoltativa</span></label><textarea id="twf-mandatory-notice" name="twf_pdf[mandatory_notice]" rows="3"><?php echo esc_textarea( $pdf_settings['mandatory_notice'] ); ?></textarea></div>
		</div>
	</section>

	<details class="twf-advanced">
		<summary>Dati di contatto sul PDF</summary>
		<div class="twf-advanced-grid">
			<div class="twf-field"><label for="twf-address">Indirizzo</label><input id="twf-address" type="text" name="twf_pdf[address]" value="<?php echo esc_attr( $pdf_settings['address'] ); ?>"></div>
			<div class="twf-field"><label for="twf-city">CAP / Località</label><input id="twf-city" type="text" name="twf_pdf[city]" value="<?php echo esc_attr( $pdf_settings['city'] ); ?>"></div>
			<div class="twf-field"><label for="twf-phone">Telefono</label><input id="twf-phone" type="text" name="twf_pdf[phone]" value="<?php echo esc_attr( $pdf_settings['phone'] ); ?>"></div>
			<div class="twf-field"><label for="twf-contact-email">Email sul PDF</label><input id="twf-contact-email" type="email" name="twf_pdf[email]" value="<?php echo esc_attr( $pdf_settings['email'] ); ?>"></div>
		</div>
	</details>

	<p class="twf-privacy"><span class="dashicons dashicons-shield" aria-hidden="true"></span><span>Il PDF è temporaneo, ha un nome anonimo e viene eliminato dopo l’invio.</span></p>

	<footer class="twf-actions">
		<span class="twf-unsaved" aria-live="polite"></span>
		<div>
			<a href="<?php echo esc_url( $preview_url ); ?>" target="_blank" rel="noopener" class="button">Apri anteprima salvata <span class="screen-reader-text">(si apre in una nuova scheda)</span></a>
			<button type="submit" name="twf_preview" value="1" formtarget="_blank" class="button">Salva e apri anteprima <span class="screen-reader-text">(si apre in una nuova scheda)</span></button>
			<button type="submit" class="button button-primary">Salva impostazioni</button>
		</div>
	</footer>
</form>
