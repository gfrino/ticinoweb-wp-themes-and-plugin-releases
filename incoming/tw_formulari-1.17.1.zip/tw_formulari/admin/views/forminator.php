<?php
/**
 * "Importa da Forminator" tab: what would be imported, the button, and the report of what was imported.
 *
 * @package TicinoWeb\TWFormulari
 */

use TicinoWeb\TWFormulari\Admin;
use TicinoWeb\TWFormulari\Builder\BuilderAdmin;
use TicinoWeb\TWFormulari\Builder\EntriesAdmin;
use TicinoWeb\TWFormulari\Builder\ForminatorImporter;
use TicinoWeb\TWFormulari\Features;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$analysis = ForminatorImporter::analyze();
$state    = ForminatorImporter::state();
$builder  = Features::enabled( 'builder' );
$plugin   = ForminatorImporter::plugin_state();
$any_done = ! empty( $state['forms'] );
$pending  = 0; // forms or submissions still to copy.
foreach ( $analysis['forms'] as $f ) {
	if ( 0 === $f['twf_id'] || ( $f['entries'] > $f['imported'] && ! $f['done'] ) ) {
		++$pending;
	}
}
$pages = $any_done ? ForminatorImporter::pages_using() : [];
?>
<div class="twf-tabpage" id="twf-fmt" data-pending="<?php echo (int) $pending; ?>">

	<section class="twf-card">
		<div class="twf-card__head">
			<h2><?php esc_html_e( 'Importa da Forminator', 'tw-formulari' ); ?></h2>
			<span class="twf-active <?php echo 'active' === $plugin ? 'is-ready' : 'needs-setup'; ?>"><span aria-hidden="true"></span><?php
				echo esc_html( 'active' === $plugin ? __( 'Forminator attivo', 'tw-formulari' ) : ( 'inactive' === $plugin ? __( 'Forminator non attivo', 'tw-formulari' ) : __( 'Dati di Forminator trovati', 'tw-formulari' ) ) );
				$version = ForminatorImporter::version();
				echo '' !== $version ? ' · v' . esc_html( $version ) : '';
			?></span>
		</div>
		<p class="twf-card__lead"><?php
			echo esc_html( sprintf(
				/* translators: 1: number of forms, 2: number of submissions */
				__( 'Trovati %1$d moduli e %2$d compilazioni. L’importazione crea moduli nuovi in TW Formulari, copia le compilazioni con la loro data e i loro allegati, e porta con sé le chiavi di Stripe. Forminator non viene toccato: puoi tenerlo finché non hai controllato.', 'tw-formulari' ),
				count( $analysis['forms'] ),
				(int) $analysis['entries']
			) );
		?></p>

		<?php if ( ! $builder ) : ?>
			<p class="twf-feat__warn"><?php esc_html_e( 'Per importare servono i moduli propri.', 'tw-formulari' ); ?> <a href="<?php echo esc_url( Admin::tab_url( 'features' ) ); ?>"><?php esc_html_e( 'Accendili in Impostazioni', 'tw-formulari' ); ?></a>.</p>
		<?php endif; ?>

		<?php if ( $analysis['forms'] ) : ?>
			<table class="widefat striped twf-fmt__table">
				<thead><tr>
					<th><?php esc_html_e( 'Modulo', 'tw-formulari' ); ?></th>
					<th><?php esc_html_e( 'Campi', 'tw-formulari' ); ?></th>
					<th><?php esc_html_e( 'Compilazioni', 'tw-formulari' ); ?></th>
					<th><?php esc_html_e( 'Stato', 'tw-formulari' ); ?></th>
				</tr></thead>
				<tbody>
				<?php foreach ( $analysis['forms'] as $f ) : ?>
					<tr data-form="<?php echo (int) $f['id']; ?>">
						<td>
							<strong><?php echo esc_html( $f['title'] ); ?></strong>
							<span class="twf-q">#<?php echo (int) $f['id']; ?><?php echo $f['payment'] ? ' · ' . esc_html__( 'con pagamento Stripe', 'tw-formulari' ) : ''; ?><?php echo 'publish' !== $f['status'] ? ' · ' . esc_html__( 'bozza', 'tw-formulari' ) : ''; ?></span>
							<?php if ( $f['warnings'] ) : ?>
								<details class="twf-fmt__warn"><summary><?php echo esc_html( sprintf( _n( '%d nota da controllare', '%d note da controllare', count( $f['warnings'] ), 'tw-formulari' ), count( $f['warnings'] ) ) ); ?></summary>
									<ul><?php foreach ( $f['warnings'] as $w ) : ?><li><?php echo esc_html( $w ); ?></li><?php endforeach; ?></ul>
								</details>
							<?php endif; ?>
						</td>
						<td><?php echo (int) $f['fields']; ?></td>
						<td class="twf-fmt__count"><?php echo (int) $f['entries']; ?></td>
						<td class="twf-fmt__status"><?php
							if ( $f['twf_id'] > 0 ) {
								$text = $f['done'] || $f['entries'] <= $f['imported']
									? sprintf( /* translators: %d: submissions imported */ __( 'Importato (%d compilazioni)', 'tw-formulari' ), $f['imported'] )
									: sprintf( __( 'In corso: %1$d di %2$d', 'tw-formulari' ), $f['imported'], $f['entries'] );
								echo esc_html( $text ) . ' — <a href="' . esc_url( BuilderAdmin::edit_url( $f['twf_id'] ) ) . '">' . esc_html__( 'apri', 'tw-formulari' ) . '</a>';
							} else {
								esc_html_e( 'Da importare', 'tw-formulari' );
							}
						?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php else : ?>
			<p><?php esc_html_e( 'Non ci sono moduli di Forminator da importare.', 'tw-formulari' ); ?></p>
		<?php endif; ?>

		<?php if ( $analysis['stripe']['test'] || $analysis['stripe']['live'] || $analysis['notes'] ) : ?>
			<div class="twf-fmt__settings">
				<h3><?php esc_html_e( 'Impostazioni', 'tw-formulari' ); ?></h3>
				<ul class="twf-list">
					<?php if ( $analysis['stripe']['test'] || $analysis['stripe']['live'] ) : ?>
						<li><?php esc_html_e( 'Chiavi di Stripe', 'tw-formulari' ); ?>: <?php echo esc_html( implode( ', ', array_filter( [ $analysis['stripe']['test'] ? __( 'prova', 'tw-formulari' ) : '', $analysis['stripe']['live'] ? __( 'reali', 'tw-formulari' ) : '' ] ) ) ); ?> — <?php esc_html_e( 'vengono portate in Pagamenti solo se lì sono ancora vuote (non sovrascrivo nulla).', 'tw-formulari' ); ?></li>
					<?php endif; ?>
					<?php foreach ( $analysis['notes'] as $note ) : ?><li><?php echo esc_html( $note ); ?></li><?php endforeach; ?>
				</ul>
			</div>
		<?php endif; ?>

		<div class="twf-fmt__actions">
			<button type="button" class="button button-primary button-hero" id="twf-fmt-start" <?php disabled( ! $builder || ! $analysis['forms'] ); ?>>
				<?php echo esc_html( $any_done ? __( 'Importa le novità', 'tw-formulari' ) : __( 'Importa tutto da Forminator', 'tw-formulari' ) ); ?>
			</button>
			<?php if ( $any_done ) : ?>
				<button type="button" class="button twf-danger-btn" id="twf-fmt-undo"><?php esc_html_e( 'Annulla l’importazione', 'tw-formulari' ); ?></button>
			<?php endif; ?>
		</div>

		<div id="twf-fmt-progress" class="twf-fmt__progress" hidden aria-live="polite">
			<progress id="twf-fmt-bar" max="100" value="0"></progress>
			<p id="twf-fmt-line"></p>
			<ul id="twf-fmt-log"></ul>
		</div>
	</section>

	<?php if ( $any_done ) : ?>
		<section class="twf-card">
			<h2><?php esc_html_e( 'Cosa è stato importato', 'tw-formulari' ); ?></h2>
			<ul class="twf-fmt__report">
				<?php foreach ( $state['forms'] as $fid => $st ) : ?>
					<li>
						<strong><?php echo esc_html( (string) ( $st['title'] ?? '#' . $fid ) ); ?></strong>
						<?php if ( ! empty( $st['twf_id'] ) ) : ?>
							— <code>[tw_form id="<?php echo (int) $st['twf_id']; ?>"]</code>
							<a href="<?php echo esc_url( BuilderAdmin::edit_url( (int) $st['twf_id'] ) ); ?>"><?php esc_html_e( 'modifica', 'tw-formulari' ); ?></a> ·
							<a href="<?php echo esc_url( EntriesAdmin::list_url( [ 'form' => (int) $st['twf_id'] ] ) ); ?>"><?php esc_html_e( 'compilazioni', 'tw-formulari' ); ?></a>
							<br><span class="twf-q"><?php
								echo esc_html( sprintf(
									/* translators: 1: submissions, 2: files copied, 3: files missing */
									__( '%1$d compilazioni · %2$d allegati copiati · %3$d allegati non trovati', 'tw-formulari' ),
									(int) ( $st['imported'] ?? 0 ),
									(int) ( $st['files_copied'] ?? 0 ),
									(int) ( $st['files_missing'] ?? 0 )
								) );
							?></span>
						<?php else : ?>
							— <span class="twf-feat__warn"><?php echo esc_html( (string) ( $st['error'] ?? __( 'non importato', 'tw-formulari' ) ) ); ?></span>
						<?php endif; ?>
					</li>
				<?php endforeach; ?>
			</ul>

			<?php $notes = (array) ( $state['settings']['notes'] ?? [] ); $imported = (array) ( $state['settings']['imported'] ?? [] ); ?>
			<?php if ( $imported || $notes ) : ?>
				<h3><?php esc_html_e( 'Impostazioni', 'tw-formulari' ); ?></h3>
				<ul class="twf-list">
					<?php foreach ( $imported as $i ) : ?><li><?php echo esc_html( sprintf( /* translators: %s: which Stripe key */ __( 'Importata in Pagamenti: %s', 'tw-formulari' ), $i ) ); ?></li><?php endforeach; ?>
					<?php foreach ( $notes as $n ) : ?><li><?php echo esc_html( $n ); ?></li><?php endforeach; ?>
				</ul>
			<?php endif; ?>

			<p class="twf-card__note"><?php esc_html_e( 'Gli allegati sono stati copiati in una cartella privata del sito. Quelli originali di Forminator (cartella wp-content/uploads/forminator, accessibili da chiunque conosca l’indirizzo) restano dove sono: cancellali quando hai finito.', 'tw-formulari' ); ?></p>
		</section>

		<section class="twf-card">
			<h2><?php esc_html_e( 'Pagine che usano ancora Forminator', 'tw-formulari' ); ?></h2>
			<?php if ( $pages ) : ?>
				<p class="twf-card__lead"><?php esc_html_e( 'Per usare i moduli importati, in ogni pagina sostituisci il codice di Forminator con quello nuovo. Non lo faccio io: controlla prima i moduli importati.', 'tw-formulari' ); ?></p>
				<table class="widefat striped">
					<thead><tr><th><?php esc_html_e( 'Pagina', 'tw-formulari' ); ?></th><th><?php esc_html_e( 'Forminator', 'tw-formulari' ); ?></th><th><?php esc_html_e( 'Da mettere al suo posto', 'tw-formulari' ); ?></th></tr></thead>
					<tbody>
					<?php foreach ( $pages as $p ) : ?>
						<tr>
							<td><a href="<?php echo esc_url( $p['url'] ); ?>"><?php echo esc_html( '' !== $p['title'] ? $p['title'] : '#' . $p['id'] ); ?></a> <span class="twf-q"><?php echo esc_html( $p['kind'] ); ?></span></td>
							<td><?php
								$ids = implode( ', ', array_map( static function ( array $f ): string { return '#' . $f['old']; }, $p['forms'] ) );
								echo esc_html( trim( $ids . ( false !== strpos( $p['kind'], 'elementor' ) ? ( '' !== $ids ? ' · ' : '' ) . __( 'widget in Elementor', 'tw-formulari' ) : '' ) ) );
							?></td>
							<td><?php
								foreach ( $p['forms'] as $f ) {
									echo '' !== $f['new'] ? '<code>' . esc_html( $f['new'] ) . '</code> ' : '<span class="twf-q">' . esc_html__( '(modulo non importato)', 'tw-formulari' ) . '</span> ';
								}
								if ( false !== strpos( $p['kind'], 'elementor' ) ) {
									echo '<br><span class="twf-q">' . esc_html__( 'In Elementor: sostituisci il widget con uno «Shortcode».', 'tw-formulari' ) . '</span>';
								}
							?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php else : ?>
				<p><?php esc_html_e( 'Nessuna pagina usa più un modulo di Forminator.', 'tw-formulari' ); ?></p>
			<?php endif; ?>
		</section>
	<?php endif; ?>
</div>
