<?php
/**
 * Uninstallation cleanup for TW Formulari.
 *
 * @package TicinoWeb\TWFormulari
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Delete options
delete_option( 'tw_formulari_email_settings' );
delete_option( 'tw_formulari_pdf_settings' );
delete_option( 'tw_formulari_form_settings' );
delete_option( 'tw_formulari_activity_log' );
delete_option( 'tw_formulari_last_status' );
delete_option( 'tw_formulari_db_version' );

foreach ( [ 'elementor', 'cf7', 'wpforms', 'gravityforms', 'fluentforms' ] as $engine ) {
	delete_transient( 'twf_form_choices_' . $engine );
}

wp_clear_scheduled_hook( 'tw_formulari_daily_cleanup' );
wp_clear_scheduled_hook( 'tw_formulari_builder_purge' );
wp_clear_scheduled_hook( 'tw_formulari_stripe_reconcile' );

// The Stripe keys are credentials, not customer data: they never outlive the plugin.
delete_option( 'twf_stripe_settings' );
delete_option( 'twf_forminator_import' );
delete_option( 'twf_payment_methods' );
delete_option( 'twf_stripe_webhook_events' );

// Forms, entries and uploaded files of the built-in form builder are customer data: they are removed only when
// wp-config.php explicitly says so with define( 'TWF_REMOVE_DATA_ON_UNINSTALL', true );
if ( defined( 'TWF_REMOVE_DATA_ON_UNINSTALL' ) && TWF_REMOVE_DATA_ON_UNINSTALL ) {
	global $wpdb;
	foreach ( get_posts( [ 'post_type' => 'twf_form', 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids' ] ) as $twf_form_id ) {
		wp_delete_post( (int) $twf_form_id, true );
	}
	$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . 'twf_entries' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	delete_option( 'tw_formulari_entries_db' );
	$twf_private = defined( 'TWF_PRIVATE_DIR' ) && is_string( TWF_PRIVATE_DIR ) && '' !== TWF_PRIVATE_DIR
		? trailingslashit( TWF_PRIVATE_DIR )
		: trailingslashit( wp_upload_dir()['basedir'] ) . 'tw-formulari-private/';
	if ( is_dir( $twf_private ) && ! is_link( $twf_private ) ) {
		$twf_iterator = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $twf_private, FilesystemIterator::SKIP_DOTS ), RecursiveIteratorIterator::CHILD_FIRST );
		foreach ( $twf_iterator as $twf_item ) {
			$twf_item->isDir() && ! $twf_item->isLink() ? @rmdir( $twf_item->getPathname() ) : @unlink( $twf_item->getPathname() );
		}
		@rmdir( $twf_private );
	}
}

global $wpdb;
if ( isset( $wpdb ) && is_object( $wpdb ) && ! empty( $wpdb->options ) ) {
	$submission_like = $wpdb->esc_like( 'twf_submission_lock_' ) . '%';
	$rate_like       = $wpdb->esc_like( 'twf_rate_slot_' ) . '%';
	$names = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s", $submission_like, $rate_like ) );
	foreach ( $names ?: [] as $option_name ) {
		delete_option( $option_name );
	}
}

// Clean temporary directory
$temp_dir = trailingslashit( get_temp_dir() ) . 'tw-formulari-' . substr( hash( 'sha256', wp_salt( 'auth' ) . ABSPATH ), 0, 16 ) . '/';

if ( is_dir( $temp_dir ) && ! is_link( $temp_dir ) ) {
	$files = glob( $temp_dir . '*' );
	if ( ! empty( $files ) ) {
		foreach ( $files as $file ) {
			if ( is_file( $file ) ) {
				@unlink( $file );
			}
		}
	}
	@rmdir( $temp_dir );
}

$legacy_dir = trailingslashit( wp_upload_dir()['basedir'] ) . 'tw_formulari_temp/';
if ( is_dir( $legacy_dir ) && ! is_link( $legacy_dir ) ) {
	foreach ( glob( $legacy_dir . '*.pdf' ) ?: [] as $file ) {
		if ( is_file( $file ) ) {
			@unlink( $file );
		}
	}
	foreach ( [ 'index.php', '.htaccess' ] as $control_file ) {
		if ( is_file( $legacy_dir . $control_file ) ) {
			@unlink( $legacy_dir . $control_file );
		}
	}
	@rmdir( $legacy_dir );
}
