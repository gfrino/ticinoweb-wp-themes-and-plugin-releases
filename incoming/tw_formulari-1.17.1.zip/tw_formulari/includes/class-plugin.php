<?php
/**
 * Main plugin orchestrator for tw_formulari.
 *
 * @package TicinoWeb\TWFormulari
 */

namespace TicinoWeb\TWFormulari;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Plugin {

	/**
	 * Singleton instance.
	 *
	 * @var Plugin|null
	 */
	private static $instance = null;

	/**
	 * Form manager instance.
	 *
	 * @var FormManager
	 */
	public $form_manager;

	/**
	 * Admin controller instance.
	 *
	 * @var Admin|null
	 */
	public $admin = null;

	/**
	 * Retrieves the singleton instance.
	 *
	 * @return Plugin
	 */
	public static function get_instance(): Plugin {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		self::upgrade_if_needed();
		$this->init_components();
		$this->init_hooks();
	}

	/** @return void */
	public static function upgrade_if_needed(): void {
		if ( TW_FORMULARI_VERSION === get_option( 'tw_formulari_db_version' ) ) {
			return;
		}

		// Versions before 1.2.0 relied on runtime defaults even when no option had
		// ever been written. Materialize the neutral defaults once during upgrades.
		if ( null === get_option( Settings::FORM_SETTINGS_KEY, null ) ) {
			update_option( Settings::FORM_SETTINGS_KEY, Settings::get_default_form_settings(), false );
		}
		if ( null === get_option( Settings::EMAIL_SETTINGS_KEY, null ) ) {
			update_option( Settings::EMAIL_SETTINGS_KEY, Settings::get_default_email_settings(), false );
		}

		// Version 1.4.0 resolves confirmation recipients from the submitted
		// email fields, so the former manual mapping options are obsolete.
		$stored_form = get_option( Settings::FORM_SETTINGS_KEY, [] );
		if ( is_array( $stored_form ) ) {
			unset( $stored_form['profile_mode'], $stored_form['user_email_field'], $stored_form['legacy_post_id'], $stored_form['legacy_form_name'] );
			update_option( Settings::FORM_SETTINGS_KEY, $stored_form, false );
		}
		$stored_email = get_option( Settings::EMAIL_SETTINGS_KEY, [] );
		if ( is_array( $stored_email ) && ( array_key_exists( 'send_parent_1', $stored_email ) || array_key_exists( 'send_parent_2', $stored_email ) ) ) {
			unset( $stored_email['send_parent_1'], $stored_email['send_parent_2'] );
			update_option( Settings::EMAIL_SETTINGS_KEY, $stored_email, false );
		}
		if ( null === get_option( Settings::PDF_SETTINGS_KEY, null ) ) {
			update_option( Settings::PDF_SETTINGS_KEY, Settings::get_default_pdf_settings(), false );
		}

		delete_option( 'tw_formulari_activity_log' );
		clean_legacy_temp_pdfs();
		update_option( 'tw_formulari_db_version', TW_FORMULARI_VERSION, true );
	}

	/**
	 * Instantiates required plugin components.
	 *
	 * @return void
	 */
	private function init_components(): void {
		$this->form_manager = FormManager::get_instance();
		$this->form_manager->init_hooks();

		if ( is_admin() ) {
			$this->admin = new Admin();
			$this->admin->init();
		}
	}

	/**
	 * Register global hooks and scheduled cron.
	 *
	 * @return void
	 */
	private function init_hooks(): void {
		// Cron task for defensive cleanup of orphaned temporary PDF files
		add_action( 'tw_formulari_daily_cleanup', [ $this, 'run_daily_cleanup' ] );
		if ( is_admin() && ! wp_next_scheduled( 'tw_formulari_daily_cleanup' ) ) {
			wp_schedule_event( time(), 'daily', 'tw_formulari_daily_cleanup' );
		}

	}

	/**
	 * Runs defensive cleanup on orphaned temp files.
	 *
	 * @return void
	 */
	public function run_daily_cleanup(): void {
		clean_orphaned_temp_pdfs( 3600 ); // Cleans any leftover PDF older than 1 hour
		clean_legacy_temp_pdfs();
		clean_expired_security_options();
	}

	/**
	 * Plugin activation callback.
	 *
	 * @return void
	 */
	public static function activate(): void {
		get_temp_pdf_dir();
		$legacy_install = null !== get_option( 'tw_formulari_activity_log', null ) || null !== get_option( Settings::FORM_SETTINGS_KEY, null ) || null !== get_option( Settings::EMAIL_SETTINGS_KEY, null ) || null !== get_option( Settings::PDF_SETTINGS_KEY, null );
		if ( $legacy_install ) {
			self::upgrade_if_needed();
		} else {
			update_option( 'tw_formulari_db_version', TW_FORMULARI_VERSION, true );
		}

		if ( ! wp_next_scheduled( 'tw_formulari_daily_cleanup' ) ) {
			wp_schedule_event( time(), 'daily', 'tw_formulari_daily_cleanup' );
		}
	}

	/**
	 * Plugin deactivation callback.
	 *
	 * @return void
	 */
	public static function deactivate(): void {
		$timestamp = wp_next_scheduled( 'tw_formulari_daily_cleanup' );
		if ( $timestamp ) {
			wp_unschedule_event( $timestamp, 'tw_formulari_daily_cleanup' );
		}

		wp_clear_scheduled_hook( 'tw_formulari_builder_purge' );
		wp_clear_scheduled_hook( 'tw_formulari_stripe_reconcile' );

		clean_orphaned_temp_pdfs( 0 );
	}
}
