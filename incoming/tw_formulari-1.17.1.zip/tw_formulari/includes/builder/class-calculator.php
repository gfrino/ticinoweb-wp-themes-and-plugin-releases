<?php
/**
 * Safe evaluation of calculation formulas (no eval, no code from the form is ever executed).
 *
 * Grammar: numbers, {field_id} references, + - * / %, parentheses, unary minus and the functions
 * round(x[, decimals]), floor(x), ceil(x), abs(x), min(a, b, …), max(a, b, …).
 *
 * The browser has a twin of this parser (assets/builder/frontend.js) so the visitor sees the total live,
 * but the amount that counts (and the one charged by Stripe) is always the one computed here.
 *
 * @package TicinoWeb\TWFormulari\Builder
 */

namespace TicinoWeb\TWFormulari\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Calculator {

	/** A formula longer than this is refused. */
	private const MAX_LENGTH = 1000;

	/** @var array<int, array{0:string,1:mixed}> */
	private $tokens = [];

	/** @var int */
	private $pos = 0;

	/**
	 * @param string                              $formula Formula with {field_id} references.
	 * @param array<string, array<string, mixed>> $by_id   Field definitions keyed by id.
	 * @param array<string, mixed>                $values  Sanitised values keyed by field id.
	 * @return float|null Result, or null when the formula is empty, invalid or divides by zero.
	 */
	public static function evaluate( string $formula, array $by_id, array $values ): ?float {
		$formula = trim( $formula );
		if ( '' === $formula || strlen( $formula ) > self::MAX_LENGTH ) {
			return null;
		}

		// Replace every {id} with its number. Unknown references count as 0.
		$replaced = preg_replace_callback(
			'/\{([a-z0-9_]{1,40})\}/',
			static function ( array $m ) use ( $by_id, $values ): string {
				$field = $by_id[ $m[1] ] ?? null;
				$num   = null === $field ? 0.0 : FieldTypes::numeric_value( $field, $values[ $m[1] ] ?? null );
				return '(' . self::format_number( $num ) . ')';
			},
			$formula
		);
		if ( null === $replaced ) {
			return null;
		}

		$calc = new self();
		if ( ! $calc->tokenise( $replaced ) ) {
			return null;
		}
		try {
			$result = $calc->parse_expression();
			if ( $calc->pos !== count( $calc->tokens ) ) {
				return null;
			}
		} catch ( \RuntimeException $e ) {
			return null;
		}

		return is_finite( $result ) ? $result : null;
	}

	/**
	 * All the field ids a formula refers to.
	 *
	 * @return string[]
	 */
	public static function references( string $formula ): array {
		preg_match_all( '/\{([a-z0-9_]{1,40})\}/', $formula, $matches );
		return array_values( array_unique( $matches[1] ) );
	}

	private static function format_number( float $n ): string {
		$s = rtrim( rtrim( sprintf( '%.10F', $n ), '0' ), '.' );
		return '' === $s || '-' === $s ? '0' : $s;
	}

	private function tokenise( string $text ): bool {
		$this->tokens = [];
		$this->pos    = 0;
		$len          = strlen( $text );
		$i            = 0;

		while ( $i < $len ) {
			$ch = $text[ $i ];
			if ( ctype_space( $ch ) ) {
				++$i;
				continue;
			}
			if ( ctype_digit( $ch ) || '.' === $ch ) {
				$start = $i;
				while ( $i < $len && ( ctype_digit( $text[ $i ] ) || '.' === $text[ $i ] ) ) {
					++$i;
				}
				$raw = substr( $text, $start, $i - $start );
				if ( ! preg_match( '/^\d+(\.\d+)?$|^\.\d+$/', $raw ) ) {
					return false;
				}
				$this->tokens[] = [ 'num', (float) $raw ];
				continue;
			}
			if ( ctype_alpha( $ch ) ) {
				$start = $i;
				while ( $i < $len && ctype_alpha( $text[ $i ] ) ) {
					++$i;
				}
				$name = strtolower( substr( $text, $start, $i - $start ) );
				if ( ! in_array( $name, [ 'round', 'floor', 'ceil', 'abs', 'min', 'max' ], true ) ) {
					return false;
				}
				$this->tokens[] = [ 'fn', $name ];
				continue;
			}
			if ( false !== strpos( '+-*/%(),', $ch ) ) {
				$this->tokens[] = [ 'op', $ch ];
				++$i;
				continue;
			}
			return false;
		}

		return count( $this->tokens ) > 0;
	}

	private function peek(): ?array {
		return $this->tokens[ $this->pos ] ?? null;
	}

	private function accept_op( string $op ): bool {
		$t = $this->peek();
		if ( null !== $t && 'op' === $t[0] && $op === $t[1] ) {
			++$this->pos;
			return true;
		}
		return false;
	}

	private function parse_expression(): float {
		$value = $this->parse_term();
		while ( true ) {
			if ( $this->accept_op( '+' ) ) {
				$value += $this->parse_term();
			} elseif ( $this->accept_op( '-' ) ) {
				$value -= $this->parse_term();
			} else {
				return $value;
			}
		}
	}

	private function parse_term(): float {
		$value = $this->parse_unary();
		while ( true ) {
			if ( $this->accept_op( '*' ) ) {
				$value *= $this->parse_unary();
			} elseif ( $this->accept_op( '/' ) ) {
				$divisor = $this->parse_unary();
				if ( 0.0 === $divisor ) {
					throw new \RuntimeException( 'division by zero' );
				}
				$value /= $divisor;
			} elseif ( $this->accept_op( '%' ) ) {
				$divisor = $this->parse_unary();
				if ( 0.0 === $divisor ) {
					throw new \RuntimeException( 'division by zero' );
				}
				$value = fmod( $value, $divisor );
			} else {
				return $value;
			}
		}
	}

	private function parse_unary(): float {
		if ( $this->accept_op( '-' ) ) {
			return -$this->parse_unary();
		}
		if ( $this->accept_op( '+' ) ) {
			return $this->parse_unary();
		}
		return $this->parse_primary();
	}

	private function parse_primary(): float {
		$t = $this->peek();
		if ( null === $t ) {
			throw new \RuntimeException( 'unexpected end' );
		}
		if ( 'num' === $t[0] ) {
			++$this->pos;
			return (float) $t[1];
		}
		if ( 'op' === $t[0] && '(' === $t[1] ) {
			++$this->pos;
			$value = $this->parse_expression();
			if ( ! $this->accept_op( ')' ) ) {
				throw new \RuntimeException( 'missing )' );
			}
			return $value;
		}
		if ( 'fn' === $t[0] ) {
			++$this->pos;
			if ( ! $this->accept_op( '(' ) ) {
				throw new \RuntimeException( 'missing (' );
			}
			$args = [ $this->parse_expression() ];
			while ( $this->accept_op( ',' ) ) {
				$args[] = $this->parse_expression();
				if ( count( $args ) > 20 ) {
					throw new \RuntimeException( 'too many arguments' );
				}
			}
			if ( ! $this->accept_op( ')' ) ) {
				throw new \RuntimeException( 'missing )' );
			}
			return $this->call( (string) $t[1], $args );
		}
		throw new \RuntimeException( 'unexpected token' );
	}

	/**
	 * @param float[] $args
	 */
	private function call( string $fn, array $args ): float {
		switch ( $fn ) {
			case 'round':
				if ( count( $args ) > 2 ) {
					throw new \RuntimeException( 'round arguments' );
				}
				return round( $args[0], (int) ( $args[1] ?? 0 ) );
			case 'floor':
				return floor( $args[0] );
			case 'ceil':
				return ceil( $args[0] );
			case 'abs':
				return abs( $args[0] );
			case 'min':
				return min( $args );
			case 'max':
				return max( $args );
		}
		throw new \RuntimeException( 'unknown function' );
	}
}
