<?php
/**
 * Admin side of the Forminator import: the AJAX steps behind the progress bar of the "Importa da Forminator" tab.
 *
 * The import runs in small requests (forms, then submissions in blocks, then settings) so that a site with
 * thousands of submissions never hits a time limit, and can be resumed if the browser is closed.
 *
 * @package TicinoWeb\TWFormulari\Builder
 */

namespace TicinoWeb\TWFormulari\Builder;

use TicinoWeb\TWFormulari\Features;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ForminatorAdmin {

	public const NONCE = 'twf_forminator_import';

	public static function init(): void {
		add_action( 'wp_ajax_twf_fmt_step', [ self::class, 'ajax_step' ] );
		add_action( 'wp_ajax_twf_fmt_undo', [ self::class, 'ajax_undo' ] );
	}

	/** Common checks: administrator, valid nonce, the form builder switched on. */
	private static function guard(): void {
		check_ajax_referer( self::NONCE, 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => __( 'Permessi insufficienti.', 'tw-formulari' ) ], 403 );
		}
		if ( ! Features::enabled( 'builder' ) ) {
			wp_send_json_error( [ 'message' => __( 'Accendi i moduli propri in TW Formulari → Impostazioni.', 'tw-formulari' ) ], 400 );
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 120 ); // phpcs:ignore Squiz.PHP.DiscouragedFunctions.Discouraged
		}
	}

	public static function ajax_step(): void {
		self::guard();
		$phase = isset( $_POST['phase'] ) ? sanitize_key( wp_unslash( $_POST['phase'] ) ) : '';

		if ( 'forms' === $phase ) {
			$r     = ForminatorImporter::import_forms();
			$forms = [];
			foreach ( $r['forms'] as $fid => $f ) {
				$forms[] = [ 'id' => (int) $fid, 'title' => (string) ( $f['title'] ?? '' ), 'total' => (int) ( $f['entries_total'] ?? 0 ), 'done' => ! empty( $f['entries_done'] ), 'twf_id' => (int) ( $f['twf_id'] ?? 0 ) ];
			}
			wp_send_json_success( [ 'created' => $r['created'], 'existing' => $r['existing'], 'forms' => $forms ] );
		}

		if ( 'entries' === $phase ) {
			$fid = isset( $_POST['form'] ) ? absint( wp_unslash( $_POST['form'] ) ) : 0;
			wp_send_json_success( ForminatorImporter::import_entries_batch( $fid ) );
		}

		if ( 'settings' === $phase ) {
			wp_send_json_success( ForminatorImporter::import_settings() );
		}

		wp_send_json_error( [ 'message' => __( 'Passaggio non valido.', 'tw-formulari' ) ], 400 );
	}

	public static function ajax_undo(): void {
		self::guard();
		wp_send_json_success( ForminatorImporter::undo() );
	}
}
