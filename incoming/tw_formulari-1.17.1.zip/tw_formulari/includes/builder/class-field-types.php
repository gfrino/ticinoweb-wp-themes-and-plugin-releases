<?php
/**
 * Field types of the built-in form builder: sanitising, validation and display of values.
 *
 * Values are normalised to simple shapes:
 *  - text, textarea, email, phone, hidden, date, select, radio, number, currency: string
 *  - name:     [ 'first' => string, 'last' => string ]
 *  - address:  [ 'street' => string, 'zip' => string, 'city' => string, 'country' => string ]
 *  - checkbox: string[] (selected option values)
 *  - gdpr:     bool
 *  - upload:   handled by Uploads (array of stored file descriptors)
 *  - calculation: computed on the server, never taken from the visitor
 *
 * @package TicinoWeb\TWFormulari\Builder
 */

namespace TicinoWeb\TWFormulari\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class FieldTypes {

	/** Types that collect a value. */
	public const INPUT_TYPES = [ 'text', 'textarea', 'email', 'phone', 'name', 'address', 'number', 'currency', 'select', 'radio', 'checkbox', 'date', 'upload', 'hidden', 'gdpr', 'calculation' ];

	/** Types that only shape the page. */
	public const LAYOUT_TYPES = [ 'html', 'section', 'page_break' ];

	/** Hard limits that protect the server whatever the form says. */
	public const MAX_TEXT     = 500;
	public const MAX_TEXTAREA = 5000;

	/**
	 * @return array<string, string> type => human label (translated).
	 */
	public static function labels(): array {
		return [
			'text'        => __( 'Testo breve', 'tw-formulari' ),
			'textarea'    => __( 'Testo lungo', 'tw-formulari' ),
			'email'       => __( 'E-mail', 'tw-formulari' ),
			'phone'       => __( 'Telefono', 'tw-formulari' ),
			'name'        => __( 'Nome e cognome', 'tw-formulari' ),
			'address'     => __( 'Indirizzo', 'tw-formulari' ),
			'number'      => __( 'Numero', 'tw-formulari' ),
			'currency'    => __( 'Importo', 'tw-formulari' ),
			'select'      => __( 'Menu a tendina', 'tw-formulari' ),
			'radio'       => __( 'Scelta unica', 'tw-formulari' ),
			'checkbox'    => __( 'Caselle da spuntare', 'tw-formulari' ),
			'date'        => __( 'Data', 'tw-formulari' ),
			'upload'      => __( 'Allegato', 'tw-formulari' ),
			'hidden'      => __( 'Campo nascosto', 'tw-formulari' ),
			'gdpr'        => __( 'Consenso privacy', 'tw-formulari' ),
			'calculation' => __( 'Calcolo', 'tw-formulari' ),
			'html'        => __( 'Testo informativo', 'tw-formulari' ),
			'section'     => __( 'Titolo di sezione', 'tw-formulari' ),
			'page_break'  => __( 'Nuova pagina', 'tw-formulari' ),
		];
	}

	public static function is_known( string $type ): bool {
		return in_array( $type, self::INPUT_TYPES, true ) || in_array( $type, self::LAYOUT_TYPES, true );
	}

	public static function is_input( string $type ): bool {
		return in_array( $type, self::INPUT_TYPES, true );
	}

	/** Types with a list of options. */
	public static function has_options( string $type ): bool {
		return in_array( $type, [ 'select', 'radio', 'checkbox' ], true );
	}

	/**
	 * Cleans a raw value coming from the visitor. Never trusts the shape.
	 *
	 * @param array<string, mixed> $field Field definition.
	 * @param mixed                $raw   Raw value.
	 * @return mixed Normalised value (see class doc).
	 */
	public static function sanitize_value( array $field, $raw ) {
		$type = (string) ( $field['type'] ?? 'text' );

		switch ( $type ) {
			case 'name':
				$raw = is_array( $raw ) ? $raw : [];
				return [
					'first' => self::clean_line( $raw['first'] ?? '', 100 ),
					'last'  => self::clean_line( $raw['last'] ?? '', 100 ),
				];

			case 'address':
				$raw = is_array( $raw ) ? $raw : [];
				return [
					'street'  => self::clean_line( $raw['street'] ?? '', 200 ),
					'zip'     => self::clean_line( $raw['zip'] ?? '', 20 ),
					'city'    => self::clean_line( $raw['city'] ?? '', 100 ),
					'country' => self::clean_line( $raw['country'] ?? '', 100 ),
				];

			case 'checkbox':
				$list = is_array( $raw ) ? $raw : ( '' === (string) $raw ? [] : [ $raw ] );
				$out  = [];
				foreach ( $list as $item ) {
					if ( is_scalar( $item ) ) {
						$out[] = self::clean_line( $item, 200 );
					}
				}
				return array_values( array_unique( array_filter( $out, static function ( string $v ): bool {
					return '' !== $v;
				} ) ) );

			case 'gdpr':
				return in_array( $raw, [ true, 1, '1', 'on', 'true', 'yes' ], true );

			case 'textarea':
				return self::clean_multiline( $raw, self::MAX_TEXTAREA );

			case 'email':
				return is_scalar( $raw ) ? sanitize_email( self::clean_line( $raw, 254 ) ) : '';

			case 'phone':
				return self::clean_line( $raw, 40 );

			case 'number':
			case 'currency':
				return self::normalise_number( $raw, 'currency' === $type ? 2 : null );

			case 'date':
				$text = self::clean_line( $raw, 10 );
				return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $text ) ? $text : '';

			case 'select':
			case 'radio':
				return self::clean_line( $raw, 200 );

			case 'hidden':
			case 'text':
			default:
				return self::clean_line( $raw, self::MAX_TEXT );
		}
	}

	/**
	 * True when the (sanitised) value counts as "not filled in".
	 *
	 * @param array<string, mixed> $field
	 * @param mixed                $value
	 */
	public static function is_empty( array $field, $value ): bool {
		$type = (string) ( $field['type'] ?? 'text' );
		switch ( $type ) {
			case 'name':
				return empty( $value['first'] ) && empty( $value['last'] );
			case 'address':
				return empty( $value['street'] ) && empty( $value['zip'] ) && empty( $value['city'] );
			case 'checkbox':
			case 'upload':
				return ! is_array( $value ) || 0 === count( $value );
			case 'gdpr':
				return true !== $value;
			default:
				return ! is_scalar( $value ) || '' === trim( (string) $value );
		}
	}

	/**
	 * Validates one sanitised value. Layout fields and calculations always pass.
	 *
	 * @param array<string, mixed> $field
	 * @param mixed                $value
	 * @return string|null Error message (already translated) or null when valid.
	 */
	public static function validate_value( array $field, $value ): ?string {
		$type     = (string) ( $field['type'] ?? 'text' );
		$required = ! empty( $field['required'] );

		if ( 'calculation' === $type || ! self::is_input( $type ) || 'upload' === $type ) {
			return null; // Calculations are server-side; uploads are checked by Uploads.
		}
		if ( 'hidden' === $type ) {
			return null;
		}

		if ( self::is_empty( $field, $value ) ) {
			return $required ? self::required_message( $type ) : null;
		}

		switch ( $type ) {
			case 'text':
			case 'textarea':
				$min = (int) ( $field['min_length'] ?? 0 );
				$max = (int) ( $field['max_length'] ?? 0 );
				$len = function_exists( 'mb_strlen' ) ? mb_strlen( (string) $value ) : strlen( (string) $value );
				if ( $min > 0 && $len < $min ) {
					/* translators: %d: minimum number of characters */
					return sprintf( __( 'Inserisci almeno %d caratteri.', 'tw-formulari' ), $min );
				}
				if ( $max > 0 && $len > $max ) {
					/* translators: %d: maximum number of characters */
					return sprintf( __( 'Inserisci al massimo %d caratteri.', 'tw-formulari' ), $max );
				}
				return null;

			case 'email':
				return is_email( (string) $value ) ? null : __( 'Inserisci un indirizzo e-mail valido.', 'tw-formulari' );

			case 'phone':
				$digits = preg_replace( '/\D/', '', (string) $value );
				$ok     = preg_match( '/^[0-9+()\-.\/\s]{5,40}$/', (string) $value ) && strlen( (string) $digits ) >= 5;
				return $ok ? null : __( 'Inserisci un numero di telefono valido.', 'tw-formulari' );

			case 'name':
				return '' !== (string) ( $value['first'] ?? '' ) ? null : self::required_message( 'name' );

			case 'address':
				foreach ( [ 'street', 'zip', 'city' ] as $part ) {
					if ( '' === (string) ( $value[ $part ] ?? '' ) ) {
						return self::required_message( 'address' );
					}
				}
				return null;

			case 'number':
			case 'currency':
				if ( ! is_numeric( $value ) ) {
					return __( 'Inserisci un numero valido.', 'tw-formulari' );
				}
				$num = (float) $value;
				if ( isset( $field['min'] ) && '' !== (string) $field['min'] && $num < (float) $field['min'] ) {
					/* translators: %s: minimum value */
					return sprintf( __( 'Il valore minimo è %s.', 'tw-formulari' ), (string) $field['min'] );
				}
				if ( isset( $field['max'] ) && '' !== (string) $field['max'] && $num > (float) $field['max'] ) {
					/* translators: %s: maximum value */
					return sprintf( __( 'Il valore massimo è %s.', 'tw-formulari' ), (string) $field['max'] );
				}
				return null;

			case 'select':
			case 'radio':
				return in_array( (string) $value, self::option_values( $field ), true ) ? null : __( 'Scegli una delle opzioni proposte.', 'tw-formulari' );

			case 'checkbox':
				$allowed = self::option_values( $field );
				foreach ( (array) $value as $item ) {
					if ( ! in_array( (string) $item, $allowed, true ) ) {
						return __( 'Scegli solo tra le opzioni proposte.', 'tw-formulari' );
					}
				}
				return null;

			case 'date':
				$parts = explode( '-', (string) $value );
				if ( 3 !== count( $parts ) || ! checkdate( (int) $parts[1], (int) $parts[2], (int) $parts[0] ) ) {
					return __( 'Inserisci una data valida.', 'tw-formulari' );
				}
				if ( ! empty( $field['min_date'] ) && (string) $value < (string) $field['min_date'] ) {
					return __( 'La data scelta è troppo vicina nel passato.', 'tw-formulari' );
				}
				if ( ! empty( $field['max_date'] ) && (string) $value > (string) $field['max_date'] ) {
					return __( 'La data scelta è troppo lontana nel futuro.', 'tw-formulari' );
				}
				return null;

			case 'gdpr':
				return null;
		}

		return null;
	}

	/**
	 * Human readable text of a value, for e-mails, the entries list and the PDF.
	 *
	 * @param array<string, mixed> $field
	 * @param mixed                $value
	 */
	public static function display_value( array $field, $value ): string {
		$type = (string) ( $field['type'] ?? 'text' );

		switch ( $type ) {
			case 'name':
				return trim( (string) ( $value['first'] ?? '' ) . ' ' . (string) ( $value['last'] ?? '' ) );

			case 'address':
				$line1 = (string) ( $value['street'] ?? '' );
				$line2 = trim( (string) ( $value['zip'] ?? '' ) . ' ' . (string) ( $value['city'] ?? '' ) );
				$line3 = (string) ( $value['country'] ?? '' );
				return implode( ', ', array_filter( [ $line1, $line2, $line3 ], static function ( string $v ): bool {
					return '' !== $v;
				} ) );

			case 'select':
			case 'radio':
				return self::option_label( $field, (string) $value );

			case 'checkbox':
				$labels = [];
				foreach ( (array) $value as $item ) {
					$labels[] = self::option_label( $field, (string) $item );
				}
				return implode( ', ', $labels );

			case 'gdpr':
				return true === $value ? __( 'Accettato', 'tw-formulari' ) : __( 'Non accettato', 'tw-formulari' );

			case 'date':
				$parts = explode( '-', (string) $value );
				return 3 === count( $parts ) ? sprintf( '%02d/%02d/%04d', (int) $parts[2], (int) $parts[1], (int) $parts[0] ) : (string) $value;

			case 'upload':
				$names = [];
				foreach ( (array) $value as $file ) {
					if ( is_array( $file ) && isset( $file['name'] ) ) {
						$names[] = (string) $file['name'];
					}
				}
				return implode( ', ', $names );

			case 'currency':
			case 'calculation':
				return is_numeric( $value ) ? number_format( (float) $value, 2, '.', '’' ) : (string) $value;

			default:
				return is_scalar( $value ) ? (string) $value : '';
		}
	}

	/**
	 * @param array<string, mixed> $field
	 * @return string[]
	 */
	public static function option_values( array $field ): array {
		$out = [];
		foreach ( (array) ( $field['options'] ?? [] ) as $option ) {
			if ( is_array( $option ) && isset( $option['value'] ) ) {
				$out[] = (string) $option['value'];
			}
		}
		return $out;
	}

	/**
	 * @param array<string, mixed> $field
	 */
	public static function option_label( array $field, string $value ): string {
		foreach ( (array) ( $field['options'] ?? [] ) as $option ) {
			if ( is_array( $option ) && isset( $option['value'] ) && (string) $option['value'] === $value ) {
				return (string) ( $option['label'] ?? $value );
			}
		}
		return $value;
	}

	/**
	 * Numeric value a field contributes to a calculation (0 when it has none).
	 *
	 * @param array<string, mixed> $field
	 * @param mixed                $value Sanitised value.
	 */
	public static function numeric_value( array $field, $value ): float {
		$type = (string) ( $field['type'] ?? 'text' );

		if ( in_array( $type, [ 'number', 'currency', 'calculation' ], true ) ) {
			return is_numeric( $value ) ? (float) $value : 0.0;
		}
		if ( in_array( $type, [ 'select', 'radio', 'checkbox' ], true ) ) {
			$total = 0.0;
			foreach ( 'checkbox' === $type ? (array) $value : [ $value ] as $item ) {
				foreach ( (array) ( $field['options'] ?? [] ) as $option ) {
					if ( is_array( $option ) && (string) ( $option['value'] ?? '' ) === (string) $item ) {
						$calc   = $option['calc'] ?? ( is_numeric( $option['value'] ?? null ) ? $option['value'] : 0 );
						$total += is_numeric( $calc ) ? (float) $calc : 0.0;
					}
				}
			}
			return $total;
		}
		return 0.0;
	}

	/** @param mixed $raw */
	private static function clean_line( $raw, int $max ): string {
		if ( ! is_scalar( $raw ) ) {
			return '';
		}
		$text = sanitize_text_field( (string) $raw );
		if ( function_exists( 'mb_substr' ) ) {
			return mb_substr( $text, 0, $max );
		}
		return substr( $text, 0, $max );
	}

	/** @param mixed $raw */
	private static function clean_multiline( $raw, int $max ): string {
		if ( ! is_scalar( $raw ) ) {
			return '';
		}
		$text = sanitize_textarea_field( (string) $raw );
		if ( function_exists( 'mb_substr' ) ) {
			return mb_substr( $text, 0, $max );
		}
		return substr( $text, 0, $max );
	}

	/**
	 * "1'234,50", "1234.5" or "12,5" become "1234.50"; anything else becomes ''.
	 *
	 * @param mixed    $raw
	 * @param int|null $decimals Fixed decimals, or null to keep what was typed.
	 */
	public static function normalise_number( $raw, ?int $decimals ): string {
		if ( ! is_scalar( $raw ) ) {
			return '';
		}
		$text = trim( str_replace( [ "'", '’', ' ' ], '', (string) $raw ) );
		if ( '' === $text ) {
			return '';
		}
		// Both separators: the last one is the decimal separator.
		if ( false !== strpos( $text, ',' ) && false !== strpos( $text, '.' ) ) {
			$text = strrpos( $text, ',' ) > strrpos( $text, '.' )
				? str_replace( [ '.', ',' ], [ '', '.' ], $text )
				: str_replace( ',', '', $text );
		} else {
			$text = str_replace( ',', '.', $text );
		}
		if ( ! preg_match( '/^-?\d+(\.\d+)?$/', $text ) ) {
			return '';
		}
		return null === $decimals ? $text : number_format( (float) $text, $decimals, '.', '' );
	}

	private static function required_message( string $type ): string {
		switch ( $type ) {
			case 'checkbox':
				return __( 'Spunta almeno una casella.', 'tw-formulari' );
			case 'gdpr':
				return __( 'Devi accettare per proseguire.', 'tw-formulari' );
			case 'select':
			case 'radio':
				return __( 'Scegli un’opzione.', 'tw-formulari' );
			case 'upload':
				return __( 'Allega almeno un file.', 'tw-formulari' );
			default:
				return __( 'Questo campo è obbligatorio.', 'tw-formulari' );
		}
	}
}
