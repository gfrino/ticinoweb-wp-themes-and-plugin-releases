<?php
/**
 * The definition of a form (fields, notifications, confirmation, settings, payment) as stored in JSON.
 *
 * Whatever comes in (the visual builder, an import from Forminator, a hand-written JSON) goes through
 * Definition::normalize(): ids are made unique, types and options are checked, limits are applied and
 * every reference between parts (conditions, recipients, payment amount) must point to a real field.
 *
 * @package TicinoWeb\TWFormulari\Builder
 */

namespace TicinoWeb\TWFormulari\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Definition {

	public const VERSION = 1;

	public const MAX_FIELDS        = 300;
	public const MAX_OPTIONS       = 200;
	public const MAX_NOTIFICATIONS = 10;
	public const MAX_RULES         = 20;

	/** Default extensions accepted by upload fields. */
	public const DEFAULT_EXTENSIONS = [ 'pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx', 'xls', 'xlsx', 'odt', 'ods' ];

	/** Extensions that can never be accepted, whatever the form says. */
	public const FORBIDDEN_EXTENSIONS = [ 'php', 'php3', 'php4', 'php5', 'php7', 'php8', 'phtml', 'phar', 'pl', 'py', 'cgi', 'sh', 'bash', 'exe', 'bat', 'cmd', 'com', 'js', 'jsp', 'asp', 'aspx', 'htaccess', 'htpasswd', 'svg', 'html', 'htm', 'shtml' ];

	/**
	 * A definition with every part present and nothing configured.
	 *
	 * @return array<string, mixed>
	 */
	public static function defaults(): array {
		return [
			'v'             => self::VERSION,
			'title'         => '',
			'fields'        => [],
			'notifications' => [],
			'confirmation'  => [
				'type'      => 'message',
				'message'   => __( 'Grazie! Abbiamo ricevuto la tua richiesta.', 'tw-formulari' ),
				'url'       => '',
				'autoclose' => 0,
			],
			'settings'      => [
				'store_entries'  => true,
				'retention_days' => 0,
				'ajax'           => true,
				'style'          => 'default',
				'custom_css'     => '',
				'honeypot'       => true,
				'min_seconds'    => 3,
				'rate_limit'     => 10,
				'expire_at'      => '',
				'max_entries'    => 0,
				'submit_label'   => __( 'Invia', 'tw-formulari' ),
				'captcha'        => 'none',
				'accent'         => '#2563eb',
				'pdf'            => false,
				'pdf_template'   => 'summary',
				'pdf_title'      => '',
				'pdf_note'       => '',
				'pdf_color'      => '',
				'pdf_image'      => 0,
				'pdf_colors'     => [],
				'pdf_graphic'    => 'gift',
			],
			'payment'       => [
				'enabled'     => false,
				'provider'    => 'stripe',
				'currency'    => 'CHF',
				'mode'        => 'fixed',
				'amount'      => '',
				'amount_field' => '',
				'description' => '',
				'min_amount'  => '',
				'max_amount'  => '',
				'email_field' => '',
				'conditions'  => null,
				// Which ways to pay the form offers: 'stripe' and/or the ids of the manual methods of the site.
				'methods'     => [ 'stripe' ],
			],
		];
	}

	/**
	 * Cleans and completes a definition.
	 *
	 * @param array<string, mixed>|string $raw Decoded array or JSON string.
	 * @return array<string, mixed>
	 */
	public static function normalize( $raw ): array {
		if ( is_string( $raw ) ) {
			$decoded = json_decode( $raw, true );
			$raw     = is_array( $decoded ) ? $decoded : [];
		}
		if ( ! is_array( $raw ) ) {
			$raw = [];
		}

		$def           = self::defaults();
		$def['title']  = self::text( $raw['title'] ?? '', 200 );
		$def['fields'] = self::normalize_fields( (array) ( $raw['fields'] ?? [] ) );

		$ids   = array_column( $def['fields'], 'id' );
		$by_id = [];
		foreach ( $def['fields'] as $field ) {
			$by_id[ $field['id'] ] = $field;
		}

		// Conditions: drop every rule that points to a missing field or to the field itself.
		foreach ( $def['fields'] as $i => $field ) {
			$def['fields'][ $i ]['conditions'] = self::normalize_conditions( $field['conditions'] ?? null, $ids, (string) $field['id'] );
			// "Required only if…" makes sense only for fields the visitor fills in and that can be left empty.
			$def['fields'][ $i ]['required_conditions'] = FieldTypes::is_input( (string) $field['type'] ) && ! in_array( $field['type'], [ 'gdpr', 'hidden', 'calculation' ], true )
				? self::normalize_conditions( $field['required_conditions'] ?? null, $ids, (string) $field['id'], [ 'require', 'optional' ] )
				: null;
		}

		$def['notifications'] = self::normalize_notifications( (array) ( $raw['notifications'] ?? [] ), $by_id );
		$def['confirmation']  = self::normalize_confirmation( (array) ( $raw['confirmation'] ?? [] ), $def['confirmation'] );
		$def['settings']      = self::normalize_settings( (array) ( $raw['settings'] ?? [] ), $def['settings'] );
		$def['payment']       = self::normalize_payment( (array) ( $raw['payment'] ?? [] ), $def['payment'], $by_id );
		if ( $def['payment']['enabled'] ) {
			// The entry is what the payment confirms, and the payment is made without leaving the page.
			$def['settings']['store_entries'] = true;
			$def['settings']['ajax']          = true;
		}

		return $def;
	}

	/**
	 * Fields keyed by id.
	 *
	 * @param array<string, mixed> $def
	 * @return array<string, array<string, mixed>>
	 */
	public static function field_map( array $def ): array {
		$map = [];
		foreach ( (array) ( $def['fields'] ?? [] ) as $field ) {
			if ( isset( $field['id'] ) ) {
				$map[ (string) $field['id'] ] = $field;
			}
		}
		return $map;
	}

	/**
	 * Splits the fields into pages at every "page_break" field.
	 *
	 * @param array<string, mixed> $def
	 * @return array<int, array{title:string, fields:array<int, array<string, mixed>>}>
	 */
	public static function steps( array $def ): array {
		$steps   = [ [ 'title' => '', 'fields' => [] ] ];
		$current = 0;
		foreach ( (array) ( $def['fields'] ?? [] ) as $field ) {
			if ( 'page_break' === ( $field['type'] ?? '' ) ) {
				$steps[]  = [ 'title' => (string) ( $field['label'] ?? '' ), 'fields' => [] ];
				$current  = count( $steps ) - 1;
				continue;
			}
			$steps[ $current ]['fields'][] = $field;
		}
		return $steps;
	}

	// ---------------------------------------------------------------------
	// Fields
	// ---------------------------------------------------------------------

	/**
	 * @param array<int, mixed> $raw_fields
	 * @return array<int, array<string, mixed>>
	 */
	private static function normalize_fields( array $raw_fields ): array {
		$out  = [];
		$used = [];

		foreach ( array_slice( array_values( $raw_fields ), 0, self::MAX_FIELDS ) as $raw ) {
			if ( ! is_array( $raw ) ) {
				continue;
			}
			$type = (string) ( $raw['type'] ?? '' );
			if ( ! FieldTypes::is_known( $type ) ) {
				continue;
			}

			$id = preg_replace( '/[^a-z0-9_]/', '', strtolower( (string) ( $raw['id'] ?? '' ) ) );
			$id = substr( (string) $id, 0, 40 );
			if ( '' === $id || isset( $used[ $id ] ) ) {
				$n = count( $out ) + 1;
				do {
					$id = 'f' . $n;
					++$n;
				} while ( isset( $used[ $id ] ) );
			}
			$used[ $id ] = true;

			$field = [
				'id'          => $id,
				'type'        => $type,
				'label'       => self::text( $raw['label'] ?? '', 300 ),
				'description' => self::text( $raw['description'] ?? '', 500 ),
				'required'    => self::flag( $raw['required'] ?? false ),
				'placeholder' => self::text( $raw['placeholder'] ?? '', 200 ),
				'width'       => 'half' === ( $raw['width'] ?? '' ) ? 'half' : 'full',
				'css_class'   => self::css_class( $raw['css_class'] ?? '' ),
				'conditions'  => $raw['conditions'] ?? null,
				'required_conditions' => $raw['required_conditions'] ?? null,
			];

			switch ( $type ) {
				case 'text':
				case 'textarea':
					$field['min_length'] = max( 0, min( 5000, (int) ( $raw['min_length'] ?? 0 ) ) );
					$field['max_length'] = max( 0, min( 'textarea' === $type ? FieldTypes::MAX_TEXTAREA : FieldTypes::MAX_TEXT, (int) ( $raw['max_length'] ?? 0 ) ) );
					$field['default']    = self::text( $raw['default'] ?? '', 500 );
					break;

				case 'email':
				case 'phone':
					$field['default'] = self::text( $raw['default'] ?? '', 254 );
					break;

				case 'name':
					$field['last'] = ! array_key_exists( 'last', $raw ) || self::flag( $raw['last'] );
					break;

				case 'address':
					$field['country'] = self::flag( $raw['country'] ?? false );
					break;

				case 'number':
				case 'currency':
					$decimals       = 'currency' === $type ? 2 : null;
					$field['min']   = FieldTypes::normalise_number( $raw['min'] ?? '', $decimals );
					$field['max']   = FieldTypes::normalise_number( $raw['max'] ?? '', $decimals );
					$field['step']  = FieldTypes::normalise_number( $raw['step'] ?? '', null );
					$field['default'] = FieldTypes::normalise_number( $raw['default'] ?? '', $decimals );
					break;

				case 'select':
				case 'radio':
				case 'checkbox':
					$field['options'] = self::normalize_options( (array) ( $raw['options'] ?? [] ) );
					break;

				case 'date':
					$field['min_date'] = self::date_or_empty( $raw['min_date'] ?? '' );
					$field['max_date'] = self::date_or_empty( $raw['max_date'] ?? '' );
					break;

				case 'upload':
					$field['extensions']  = self::extensions( $raw['extensions'] ?? self::DEFAULT_EXTENSIONS );
					$field['max_size_mb'] = max( 1, min( 25, (int) ( $raw['max_size_mb'] ?? 5 ) ) );
					$field['max_files']   = max( 1, min( 10, (int) ( $raw['max_files'] ?? 1 ) ) );
					break;

				case 'hidden':
					$field['default'] = self::text( $raw['default'] ?? '', 500 );
					$field['param']   = preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) ( $raw['param'] ?? '' ) );
					break;

				case 'gdpr':
					$field['required'] = true;
					$field['content']  = self::limited_html( $raw['content'] ?? '' );
					break;

				case 'calculation':
					$field['formula']  = preg_replace( '/[^0-9a-z_{}+\-*\/%().,\s]/i', '', (string) ( $raw['formula'] ?? '' ) );
					$field['decimals'] = max( 0, min( 4, (int) ( $raw['decimals'] ?? 2 ) ) );
					$field['required'] = false;
					break;

				case 'html':
					$field['content']  = self::limited_html( $raw['content'] ?? '' );
					$field['required'] = false;
					break;

				case 'section':
				case 'page_break':
					$field['required'] = false;
					break;
			}

			$out[] = $field;
		}

		return $out;
	}

	/**
	 * @param array<int, mixed> $raw_options
	 * @return array<int, array{value:string,label:string,calc:string}>
	 */
	private static function normalize_options( array $raw_options ): array {
		$out  = [];
		$seen = [];
		foreach ( array_slice( array_values( $raw_options ), 0, self::MAX_OPTIONS ) as $option ) {
			if ( is_string( $option ) ) {
				$option = [ 'label' => $option ];
			}
			if ( ! is_array( $option ) ) {
				continue;
			}
			$label = self::text( $option['label'] ?? ( $option['value'] ?? '' ), 200 );
			$value = self::text( $option['value'] ?? $label, 200 );
			if ( '' === $label && '' === $value ) {
				continue;
			}
			if ( '' === $value ) {
				$value = $label;
			}
			if ( isset( $seen[ $value ] ) ) {
				continue;
			}
			$seen[ $value ] = true;
			$out[]          = [
				'value' => $value,
				'label' => '' === $label ? $value : $label,
				'calc'  => FieldTypes::normalise_number( $option['calc'] ?? '', null ),
			];
		}
		return $out;
	}

	/**
	 * @param mixed    $raw
	 * @param string[] $ids All valid field ids.
	 * @return array<string, mixed>|null
	 */
	private static function normalize_conditions( $raw, array $ids, string $own_id, array $actions = [ 'show', 'hide' ] ): ?array {
		if ( ! is_array( $raw ) || empty( $raw['rules'] ) || ! is_array( $raw['rules'] ) ) {
			return null;
		}
		$rules = [];
		foreach ( array_slice( array_values( $raw['rules'] ), 0, self::MAX_RULES ) as $rule ) {
			if ( ! is_array( $rule ) ) {
				continue;
			}
			$field = (string) ( $rule['field'] ?? '' );
			$op    = (string) ( $rule['op'] ?? 'is' );
			if ( $field === $own_id || ! in_array( $field, $ids, true ) || ! in_array( $op, Conditions::OPERATORS, true ) ) {
				continue;
			}
			$rules[] = [ 'field' => $field, 'op' => $op, 'value' => self::text( $rule['value'] ?? '', 200 ) ];
		}
		if ( ! $rules ) {
			return null;
		}
		return [
			'action' => in_array( $raw['action'] ?? '', $actions, true ) ? $raw['action'] : $actions[0],
			'match'  => 'any' === ( $raw['match'] ?? '' ) ? 'any' : 'all',
			'rules'  => $rules,
		];
	}

	// ---------------------------------------------------------------------
	// Notifications, confirmation, settings, payment
	// ---------------------------------------------------------------------

	/**
	 * @param array<int, mixed>                  $raw
	 * @param array<string, array<string, mixed>> $by_id
	 * @return array<int, array<string, mixed>>
	 */
	private static function normalize_notifications( array $raw, array $by_id ): array {
		$out  = [];
		$ids  = array_keys( $by_id );
		$used = [];

		foreach ( array_slice( array_values( $raw ), 0, self::MAX_NOTIFICATIONS ) as $n ) {
			if ( ! is_array( $n ) ) {
				continue;
			}
			$id = preg_replace( '/[^a-z0-9_]/', '', strtolower( (string) ( $n['id'] ?? '' ) ) );
			if ( '' === $id || isset( $used[ $id ] ) ) {
				$id = 'n' . ( count( $out ) + 1 );
			}
			$used[ $id ] = true;

			$to = [];
			foreach ( (array) ( $n['to'] ?? [] ) as $addr ) {
				$addr = sanitize_email( is_scalar( $addr ) ? (string) $addr : '' );
				if ( '' !== $addr && is_email( $addr ) ) {
					$to[] = $addr;
				}
			}
			$to_fields = [];
			foreach ( (array) ( $n['to_fields'] ?? [] ) as $fid ) {
				$fid = (string) $fid;
				if ( isset( $by_id[ $fid ] ) && 'email' === ( $by_id[ $fid ]['type'] ?? '' ) ) {
					$to_fields[] = $fid;
				}
			}
			$reply = (string) ( $n['reply_to_field'] ?? '' );

			$out[] = [
				'id'             => $id,
				'name'           => self::text( $n['name'] ?? '', 100 ),
				'enabled'        => ! array_key_exists( 'enabled', $n ) || self::flag( $n['enabled'] ),
				'to'             => array_values( array_unique( array_slice( $to, 0, 20 ) ) ),
				'to_fields'      => array_values( array_unique( $to_fields ) ),
				'subject'        => self::text( $n['subject'] ?? '', 300 ),
				'body'           => self::textarea( $n['body'] ?? '', 10000 ),
				'reply_to_field' => ( isset( $by_id[ $reply ] ) && 'email' === ( $by_id[ $reply ]['type'] ?? '' ) ) ? $reply : '',
				'attach_files'   => self::flag( $n['attach_files'] ?? false ),
				'attach_pdf'     => self::flag( $n['attach_pdf'] ?? false ),
				'conditions'     => self::normalize_conditions( $n['conditions'] ?? null, $ids, '' ),
			];
		}

		return $out;
	}

	/**
	 * @param array<string, mixed> $raw
	 * @param array<string, mixed> $defaults
	 * @return array<string, mixed>
	 */
	private static function normalize_confirmation( array $raw, array $defaults ): array {
		$type = (string) ( $raw['type'] ?? $defaults['type'] );
		$type = in_array( $type, [ 'message', 'message_keep', 'redirect' ], true ) ? $type : 'message';
		$url  = esc_url_raw( (string) ( $raw['url'] ?? '' ) );
		if ( '' !== $url && ! preg_match( '#^https?://#i', $url ) && 0 !== strpos( $url, '/' ) ) {
			$url = '';
		}
		if ( 'redirect' === $type && '' === $url ) {
			$type = 'message';
		}
		return [
			'type'      => $type,
			'message'   => self::limited_html( $raw['message'] ?? $defaults['message'] ),
			'url'       => $url,
			'autoclose' => max( 0, min( 600, (int) ( $raw['autoclose'] ?? 0 ) ) ),
		];
	}

	/**
	 * @param array<string, mixed> $raw
	 * @param array<string, mixed> $d Defaults.
	 * @return array<string, mixed>
	 */
	private static function normalize_settings( array $raw, array $d ): array {
		$style   = (string) ( $raw['style'] ?? $d['style'] );
		$captcha = (string) ( $raw['captcha'] ?? $d['captcha'] );
		$expire  = (string) ( $raw['expire_at'] ?? '' );

		return [
			'store_entries'  => array_key_exists( 'store_entries', $raw ) ? self::flag( $raw['store_entries'] ) : $d['store_entries'],
			'retention_days' => max( 0, min( 3650, (int) ( $raw['retention_days'] ?? 0 ) ) ),
			'ajax'           => array_key_exists( 'ajax', $raw ) ? self::flag( $raw['ajax'] ) : $d['ajax'],
			'style'          => in_array( $style, [ 'default', 'flat', 'material' ], true ) ? $style : 'default',
			'custom_css'     => self::custom_css( $raw['custom_css'] ?? '' ),
			'honeypot'       => array_key_exists( 'honeypot', $raw ) ? self::flag( $raw['honeypot'] ) : $d['honeypot'],
			'min_seconds'    => max( 0, min( 60, (int) ( $raw['min_seconds'] ?? $d['min_seconds'] ) ) ),
			'rate_limit'     => max( 0, min( 1000, (int) ( $raw['rate_limit'] ?? $d['rate_limit'] ) ) ),
			'expire_at'      => preg_match( '/^\d{4}-\d{2}-\d{2}( \d{2}:\d{2})?$/', $expire ) ? $expire : '',
			'max_entries'    => max( 0, min( 1000000, (int) ( $raw['max_entries'] ?? 0 ) ) ),
			'submit_label'   => self::text( $raw['submit_label'] ?? $d['submit_label'], 100 ) ?: $d['submit_label'],
			'captcha'        => in_array( $captcha, [ 'none', 'turnstile', 'recaptcha' ], true ) ? $captcha : 'none',
			'accent'         => preg_match( '/^#[0-9a-fA-F]{6}$/', (string) ( $raw['accent'] ?? '' ) ) ? strtolower( (string) $raw['accent'] ) : $d['accent'],
			'pdf'            => array_key_exists( 'pdf', $raw ) ? self::flag( $raw['pdf'] ) : $d['pdf'],
			// Modello del PDF: riepilogo delle risposte o buono regalo (titolo e condizioni scritti dal cliente).
			'pdf_template'   => in_array( (string) ( $raw['pdf_template'] ?? '' ), [ 'summary', 'voucher' ], true ) ? (string) $raw['pdf_template'] : $d['pdf_template'],
			'pdf_title'      => self::text( $raw['pdf_title'] ?? '', 120 ),
			'pdf_note'       => self::textarea( $raw['pdf_note'] ?? '', 600 ),
			'pdf_color'      => preg_match( '/^#[0-9a-fA-F]{6}$/', (string) ( $raw['pdf_color'] ?? '' ) ) ? strtolower( (string) $raw['pdf_color'] ) : '',
			'pdf_image'      => wp_attachment_is_image( absint( $raw['pdf_image'] ?? 0 ) ) ? absint( $raw['pdf_image'] ?? 0 ) : 0,
			'pdf_graphic'    => in_array( (string) ( $raw['pdf_graphic'] ?? '' ), [ 'gift', 'gift_light', 'flower' ], true ) ? (string) $raw['pdf_graphic'] : 'gift',
			// Colori della grafica del buono (fino a tre): cerchi e stelline, petali, petali alterni.
			'pdf_colors'     => array_slice( array_values( array_map( 'strtolower', array_filter( (array) ( $raw['pdf_colors'] ?? [] ), static function ( $hex ) {
				return is_string( $hex ) && preg_match( '/^#[0-9a-fA-F]{6}$/', $hex );
			} ) ) ), 0, 3 ),
		];
	}

	/**
	 * @param array<string, mixed>               $raw
	 * @param array<string, mixed>               $d
	 * @param array<string, array<string, mixed>> $by_id
	 * @return array<string, mixed>
	 */
	private static function normalize_payment( array $raw, array $d, array $by_id ): array {
		$mode     = (string) ( $raw['mode'] ?? 'fixed' );
		$mode     = in_array( $mode, [ 'fixed', 'field', 'calculation' ], true ) ? $mode : 'fixed';
		$currency = strtoupper( preg_replace( '/[^A-Za-z]/', '', (string) ( $raw['currency'] ?? $d['currency'] ) ) );
		$currency = 3 === strlen( (string) $currency ) ? (string) $currency : 'CHF';
		$field    = (string) ( $raw['amount_field'] ?? '' );
		$allowed  = 'calculation' === $mode ? [ 'calculation' ] : [ 'number', 'currency', 'calculation', 'select', 'radio', 'checkbox' ];
		if ( ! isset( $by_id[ $field ] ) || ! in_array( $by_id[ $field ]['type'] ?? '', $allowed, true ) ) {
			$field = '';
		}
		$email = (string) ( $raw['email_field'] ?? '' );

		return [
			'enabled'      => self::flag( $raw['enabled'] ?? false ),
			'provider'     => 'stripe',
			'currency'     => $currency,
			'mode'         => $mode,
			'amount'       => FieldTypes::normalise_number( $raw['amount'] ?? '', 2 ),
			'amount_field' => $field,
			'description'  => self::text( $raw['description'] ?? '', 200 ),
			'min_amount'   => FieldTypes::normalise_number( $raw['min_amount'] ?? '', 2 ),
			'max_amount'   => FieldTypes::normalise_number( $raw['max_amount'] ?? '', 2 ),
			'email_field'  => ( isset( $by_id[ $email ] ) && 'email' === ( $by_id[ $email ]['type'] ?? '' ) ) ? $email : '',
			// Pay online only when these rules say so (e.g. not when the visitor picks "cash"). Null = always.
			'conditions'   => self::normalize_conditions( $raw['conditions'] ?? null, array_keys( $by_id ), '' ),
			'methods'      => self::normalize_methods( $raw['methods'] ?? null ),
		];
	}

	/**
	 * @param mixed $raw
	 * @return string[] Method ids; never empty (Stripe when nothing valid is left, as before this option existed).
	 */
	private static function normalize_methods( $raw ): array {
		if ( is_array( $raw ) && in_array( '*', $raw, true ) ) {
			return [ '*' ]; // every active method of the site, now and later.
		}
		$out = [];
		foreach ( is_array( $raw ) ? array_slice( array_values( $raw ), 0, 9 ) : [] as $id ) {
			$id = is_scalar( $id ) ? substr( (string) preg_replace( '/[^a-z0-9_]/', '', strtolower( (string) $id ) ), 0, 30 ) : '';
			if ( '' !== $id && ! in_array( $id, $out, true ) ) {
				$out[] = $id;
			}
		}
		return $out ? $out : [ 'stripe' ];
	}

	// ---------------------------------------------------------------------
	// Small cleaners
	// ---------------------------------------------------------------------

	/** @param mixed $v */
	private static function flag( $v ): bool {
		return in_array( $v, [ true, 1, '1', 'true', 'on', 'yes' ], true );
	}

	/** @param mixed $v */
	private static function text( $v, int $max ): string {
		if ( ! is_scalar( $v ) ) {
			return '';
		}
		$t = sanitize_text_field( (string) $v );
		return function_exists( 'mb_substr' ) ? mb_substr( $t, 0, $max ) : substr( $t, 0, $max );
	}

	/** @param mixed $v */
	private static function textarea( $v, int $max ): string {
		if ( ! is_scalar( $v ) ) {
			return '';
		}
		$t = sanitize_textarea_field( (string) $v );
		return function_exists( 'mb_substr' ) ? mb_substr( $t, 0, $max ) : substr( $t, 0, $max );
	}

	/**
	 * Light HTML (links, bold, lists). Uses wp_kses_post when WordPress is loaded.
	 *
	 * @param mixed $v
	 */
	private static function limited_html( $v ): string {
		if ( ! is_scalar( $v ) ) {
			return '';
		}
		$html = substr( (string) $v, 0, 20000 );
		return function_exists( 'wp_kses_post' ) ? wp_kses_post( $html ) : strip_tags( $html, '<a><b><strong><em><i><br><p><ul><ol><li>' );
	}

	/** @param mixed $v */
	private static function css_class( $v ): string {
		return substr( trim( (string) preg_replace( '/[^A-Za-z0-9_\- ]/', '', is_scalar( $v ) ? (string) $v : '' ) ), 0, 100 );
	}

	/** @param mixed $v */
	private static function date_or_empty( $v ): string {
		$t = is_scalar( $v ) ? trim( (string) $v ) : '';
		return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $t ) ? $t : '';
	}

	/**
	 * Lower-case extensions without dots; the forbidden ones are removed.
	 *
	 * @param mixed $v Array or comma separated string.
	 * @return string[]
	 */
	private static function extensions( $v ): array {
		$list = is_array( $v ) ? $v : explode( ',', (string) $v );
		$out  = [];
		foreach ( $list as $ext ) {
			$ext = strtolower( ltrim( trim( (string) $ext ), '.' ) );
			if ( preg_match( '/^[a-z0-9]{1,6}$/', $ext ) && ! in_array( $ext, self::FORBIDDEN_EXTENSIONS, true ) ) {
				$out[] = $ext;
			}
		}
		$out = array_values( array_unique( $out ) );
		return $out ?: self::DEFAULT_EXTENSIONS;
	}

	/** @param mixed $v */
	private static function custom_css( $v ): string {
		if ( ! is_scalar( $v ) ) {
			return '';
		}
		$css = substr( (string) $v, 0, 10000 );
		$css = preg_replace( '/<\/?style[^>]*>/i', '', $css );
		$css = preg_replace( '/@import[^;]*;?/i', '', (string) $css );
		$css = preg_replace( '/(javascript:|expression\s*\(|behavior\s*:|-moz-binding)/i', '', (string) $css );
		return trim( (string) $css );
	}
}
