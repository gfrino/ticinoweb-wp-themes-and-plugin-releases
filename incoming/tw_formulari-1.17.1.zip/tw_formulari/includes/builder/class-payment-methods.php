<?php
/**
 * The ways to pay besides Stripe: bank transfer and other manual methods (cash, TWINT by hand…).
 *
 * The methods are defined once for the whole site (TW Formulari → Pagamenti) and each form picks which of them it
 * offers. A visitor who chooses a manual method submits the form like any other: the entry is saved as "waiting for
 * payment", the e-mails go out at once, and the payment details (beneficiary, IBAN, amount, reference) are shown on
 * the confirmation and added to the e-mail to the visitor. The site owner marks the entry as paid when the money
 * arrives. Nothing here talks to a bank: it is bookkeeping, not a payment gateway.
 *
 * @package TicinoWeb\TWFormulari\Builder
 */

namespace TicinoWeb\TWFormulari\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class PaymentMethods {

	public const OPTION            = 'twf_payment_methods';
	public const STRIPE            = 'stripe';
	public const MAX               = 8;
	/** Value of a form's methods list meaning "every method active in TW Formulari → Pagamenti", now and later. */
	public const ALL               = '*';
	public const DEFAULT_REFERENCE = '{form_title} n. {entry_id}';

	/** @var array<int, array<string, mixed>>|null */
	private static $cache = null;

	// ---------------------------------------------------------------------
	// Storage
	// ---------------------------------------------------------------------

	/** @return array<int, array<string, mixed>> */
	public static function all(): array {
		if ( null === self::$cache ) {
			self::$cache = self::normalize( get_option( self::OPTION, [] ) );
		}
		return self::$cache;
	}

	/** @return array<string, mixed>|null */
	public static function get( string $id ): ?array {
		foreach ( self::all() as $method ) {
			if ( $method['id'] === $id ) {
				return $method;
			}
		}
		return null;
	}

	/**
	 * @param mixed $raw
	 * @return array<int, array<string, mixed>> What was saved.
	 */
	public static function save( $raw ): array {
		$list = self::normalize( $raw );
		update_option( self::OPTION, $list, false );
		self::$cache = $list;
		return $list;
	}

	public static function reset_cache(): void {
		self::$cache = null;
	}

	/**
	 * Cleans a list of methods: types, unique ids, limits, bank fields.
	 *
	 * @param mixed $raw
	 * @return array<int, array<string, mixed>>
	 */
	public static function normalize( $raw ): array {
		if ( ! is_array( $raw ) ) {
			return [];
		}
		$out  = [];
		$used = [ self::STRIPE => true ];
		foreach ( array_slice( array_values( $raw ), 0, self::MAX ) as $m ) {
			if ( ! is_array( $m ) ) {
				continue;
			}
			$type = 'bank' === ( $m['type'] ?? '' ) ? 'bank' : 'custom';
			$id   = substr( (string) preg_replace( '/[^a-z0-9_]/', '', strtolower( is_scalar( $m['id'] ?? null ) ? (string) $m['id'] : '' ) ), 0, 30 );
			if ( '' === $id || isset( $used[ $id ] ) ) {
				$base = 'bank' === $type ? 'bonifico' : 'metodo';
				$n    = 1;
				do {
					$id = $base . ( $n > 1 ? '_' . $n : '' );
					++$n;
				} while ( isset( $used[ $id ] ) );
			}
			$used[ $id ] = true;

			$label = self::text( $m['label'] ?? '', 60 );
			$item  = [
				'id'      => $id,
				'type'    => $type,
				'label'   => '' !== $label ? $label : ( 'bank' === $type ? __( 'Bonifico bancario', 'tw-formulari' ) : __( 'Altro metodo', 'tw-formulari' ) ),
				'enabled' => in_array( $m['enabled'] ?? false, [ true, 1, '1', 'true', 'on', 'yes' ], true ),
				'note'    => self::textarea( $m['note'] ?? '', 1000 ),
			];
			if ( 'bank' === $type ) {
				$reference           = self::text( $m['reference'] ?? '', 140 );
				$item['beneficiary'] = self::text( $m['beneficiary'] ?? '', 120 );
				$item['address']     = self::textarea( $m['address'] ?? '', 200 );
				$item['iban']        = self::clean_iban( $m['iban'] ?? '' );
				$item['bic']         = substr( (string) preg_replace( '/[^A-Z0-9]/', '', strtoupper( is_scalar( $m['bic'] ?? null ) ? (string) $m['bic'] : '' ) ), 0, 11 );
				$item['bank']        = self::text( $m['bank'] ?? '', 80 );
				$item['reference']   = '' !== $reference ? $reference : self::DEFAULT_REFERENCE;
			}
			$out[] = $item;
		}
		return $out;
	}

	/**
	 * Applies what one form of the screen posted to the saved list: replaces the methods that were posted (their id
	 * and type stay as saved), deletes one, adds a blank one. Methods that were not posted are kept untouched.
	 *
	 * @param array<int, array<string, mixed>> $list   Saved methods.
	 * @param array<string, mixed>             $posted Posted fields keyed by method id.
	 * @return array<int, array<string, mixed>> The new list (not yet normalised).
	 */
	public static function apply_post( array $list, array $posted, string $delete = '', string $add = '' ): array {
		$out = [];
		foreach ( $list as $method ) {
			if ( '' !== $delete && $delete === $method['id'] ) {
				continue;
			}
			if ( isset( $posted[ $method['id'] ] ) && is_array( $posted[ $method['id'] ] ) ) {
				$method = array_merge( $posted[ $method['id'] ], [ 'id' => $method['id'], 'type' => $method['type'] ] );
			}
			$out[] = $method;
		}
		if ( in_array( $add, [ 'bank', 'custom' ], true ) ) {
			$out[] = self::blank( $add );
		}
		return $out;
	}

	/** A new, empty method of a type (for the "add" buttons). Its id is made unique by normalize(). */
	public static function blank( string $type ): array {
		if ( 'bank' === $type ) {
			return [
				'id' => '', 'type' => 'bank', 'label' => __( 'Bonifico bancario', 'tw-formulari' ), 'enabled' => true,
				'note' => __( 'La tua richiesta sarà confermata alla ricezione del pagamento.', 'tw-formulari' ),
				'beneficiary' => '', 'address' => '', 'iban' => '', 'bic' => '', 'bank' => '', 'reference' => self::DEFAULT_REFERENCE,
			];
		}
		return [ 'id' => '', 'type' => 'custom', 'label' => __( 'Contanti', 'tw-formulari' ), 'enabled' => true, 'note' => '' ];
	}

	// ---------------------------------------------------------------------
	// IBAN
	// ---------------------------------------------------------------------

	/** @param mixed $v */
	public static function clean_iban( $v ): string {
		return substr( (string) preg_replace( '/[^A-Z0-9]/', '', strtoupper( is_scalar( $v ) ? (string) $v : '' ) ), 0, 34 );
	}

	/** "CH8780808005752985312" → "CH87 8080 8005 7529 8531 2". */
	public static function format_iban( string $iban ): string {
		return trim( (string) preg_replace( '/(.{4})/', '$1 ', self::clean_iban( $iban ) ) );
	}

	/** ISO 13616 check (length range, country letters, mod 97). Used to warn, never to block. */
	public static function iban_valid( string $iban ): bool {
		$iban = self::clean_iban( $iban );
		if ( ! preg_match( '/^[A-Z]{2}[0-9]{2}[A-Z0-9]{11,30}$/', $iban ) ) {
			return false;
		}
		$moved   = substr( $iban, 4 ) . substr( $iban, 0, 4 );
		$numeric = '';
		foreach ( str_split( $moved ) as $char ) {
			$numeric .= ctype_alpha( $char ) ? (string) ( ord( $char ) - 55 ) : $char;
		}
		$rest = 0;
		foreach ( str_split( $numeric, 7 ) as $chunk ) {
			$rest = (int) ( $rest . $chunk ) % 97;
		}
		return 1 === $rest;
	}

	// ---------------------------------------------------------------------
	// What a form offers
	// ---------------------------------------------------------------------

	/** Label of Stripe among the choices. */
	public static function stripe_label(): string {
		return __( 'Carta, Apple Pay, Google Pay o TWINT', 'tw-formulari' );
	}

	/**
	 * The method ids a form lists. With "all active" (ALL) that is Stripe plus every method of the site, so a method added
	 * or switched on later shows up in the form by itself (offered() then drops the ones not usable).
	 *
	 * @param array<string, mixed> $def Normalised definition.
	 * @return string[]
	 */
	public static function listed( array $def ): array {
		$list = array_map( 'strval', (array) ( $def['payment']['methods'] ?? [ self::STRIPE ] ) );
		if ( ! in_array( self::ALL, $list, true ) ) {
			return $list;
		}
		$out = [ self::STRIPE ];
		foreach ( self::all() as $method ) {
			$out[] = (string) $method['id'];
		}
		return $out;
	}

	/**
	 * The method ids a form lists that can really be used now, in the form's own order: Stripe only when it is
	 * configured, manual ones only when they exist and are switched on.
	 *
	 * @param array<string, mixed> $def Normalised definition.
	 * @return string[]
	 */
	public static function offered( array $def ): array {
		if ( ! \TicinoWeb\TWFormulari\Features::enabled( 'payments' ) ) {
			return [];
		}
		$out = [];
		foreach ( self::listed( $def ) as $id ) {
			if ( self::STRIPE === $id ) {
				if ( Stripe::is_configured() ) {
					$out[] = $id;
				}
				continue;
			}
			$method = self::get( $id );
			if ( $method && ! empty( $method['enabled'] ) ) {
				$out[] = $id;
			}
		}
		return $out;
	}

	/** Label of a method id (Stripe included); empty when unknown. */
	public static function label_of( string $id ): string {
		if ( self::STRIPE === $id ) {
			return self::stripe_label();
		}
		$method = self::get( $id );
		return $method ? (string) $method['label'] : '';
	}

	/**
	 * What the form editor needs to list the choices.
	 *
	 * @return array<int, array{id:string,label:string,ready:bool,note:string}>
	 */
	public static function for_editor(): array {
		$list = [ [
			'id'    => self::STRIPE,
			'label' => self::stripe_label() . ' — Stripe',
			'ready' => Stripe::is_configured(),
			'note'  => Stripe::is_configured() ? '' : __( 'non ancora configurato', 'tw-formulari' ),
		] ];
		foreach ( self::all() as $method ) {
			$list[] = [
				'id'    => (string) $method['id'],
				'label' => (string) $method['label'],
				'ready' => ! empty( $method['enabled'] ),
				'note'  => ! empty( $method['enabled'] ) ? '' : __( 'spento', 'tw-formulari' ),
			];
		}
		return $list;
	}

	// ---------------------------------------------------------------------
	// Describing a method to the visitor
	// ---------------------------------------------------------------------

	/**
	 * The payment details to show: rows of (label, value) and a closing note.
	 *
	 * @param array<string, mixed> $method
	 * @param array{amount?:string|float|int|null, currency?:string, entry_id?:int, form_title?:string} $ctx
	 * @return array{title:string, rows:array<int, array{0:string,1:string,2?:string}>, note:string}
	 */
	public static function describe( array $method, array $ctx ): array {
		$rows = [];
		if ( 'bank' === ( $method['type'] ?? '' ) ) {
			$who = trim( (string) ( $method['beneficiary'] ?? '' ) . "\n" . (string) ( $method['address'] ?? '' ) );
			if ( '' !== $who ) {
				$rows[] = [ __( 'Beneficiario', 'tw-formulari' ), $who ];
			}
			if ( '' !== (string) ( $method['iban'] ?? '' ) ) {
				$rows[] = [ __( 'IBAN', 'tw-formulari' ), self::format_iban( (string) $method['iban'] ), 'copy' ];
			}
			if ( '' !== (string) ( $method['bic'] ?? '' ) ) {
				$rows[] = [ __( 'BIC/SWIFT', 'tw-formulari' ), (string) $method['bic'] ];
			}
			if ( '' !== (string) ( $method['bank'] ?? '' ) ) {
				$rows[] = [ __( 'Banca', 'tw-formulari' ), (string) $method['bank'] ];
			}
		}
		$amount = $ctx['amount'] ?? null;
		if ( null !== $amount && '' !== (string) $amount && (float) $amount > 0 ) {
			$rows[] = [ __( 'Importo', 'tw-formulari' ), trim( (string) ( $ctx['currency'] ?? '' ) . ' ' . number_format( (float) $amount, 2, '.', '' ) ) ];
		}
		if ( 'bank' === ( $method['type'] ?? '' ) ) {
			$entry_id  = (int) ( $ctx['entry_id'] ?? 0 );
			$reference = strtr( (string) ( $method['reference'] ?? self::DEFAULT_REFERENCE ), [
				'{entry_id}'   => $entry_id > 0 ? (string) $entry_id : '…',
				'{form_title}' => (string) ( $ctx['form_title'] ?? '' ),
				'{site_name}'  => function_exists( 'get_bloginfo' ) ? (string) get_bloginfo( 'name' ) : '',
			] );
			$reference = trim( (string) preg_replace( '/\s+/', ' ', $reference ) );
			if ( '' !== $reference ) {
				$rows[] = [ __( 'Causale', 'tw-formulari' ), $reference, $entry_id > 0 ? 'copy' : '' ];
			}
		}
		return [
			'title' => (string) ( $method['label'] ?? '' ),
			'rows'  => $rows,
			'note'  => (string) ( $method['note'] ?? '' ),
		];
	}

	/**
	 * @param array{title:string, rows:array<int, array<int,string>>, note:string} $d
	 */
	public static function as_text( array $d ): string {
		$lines = [ $d['title'] ];
		foreach ( $d['rows'] as $row ) {
			$lines[] = $row[0] . ': ' . str_replace( "\n", ', ', $row[1] );
		}
		if ( '' !== $d['note'] ) {
			$lines[] = '';
			$lines[] = $d['note'];
		}
		return implode( "\n", $lines );
	}

	/**
	 * Markup for the page (confirmation and preview). Everything is escaped; the copy buttons are wired by the form
	 * script.
	 *
	 * @param array{title:string, rows:array<int, array<int,string>>, note:string} $d
	 */
	public static function as_html( array $d, bool $copy = true ): string {
		$html = '<div class="twf-payinfo"><p class="twf-payinfo__title">' . esc_html( $d['title'] ) . '</p>';
		if ( $d['rows'] ) {
			$html .= '<dl class="twf-payinfo__rows">';
			foreach ( $d['rows'] as $row ) {
				$html .= '<dt>' . esc_html( $row[0] ) . '</dt><dd><span>' . nl2br( esc_html( $row[1] ) ) . '</span>';
				if ( $copy && 'copy' === ( $row[2] ?? '' ) ) {
					$html .= ' <button type="button" class="twf-copy" data-twf-copy="' . esc_attr( $row[1] ) . '" data-done="' . esc_attr__( 'Copiato', 'tw-formulari' ) . '">' . esc_html__( 'Copia', 'tw-formulari' ) . '</button>';
				}
				$html .= '</dd>';
			}
			$html .= '</dl>';
		}
		if ( '' !== $d['note'] ) {
			$html .= '<p class="twf-payinfo__note">' . nl2br( esc_html( $d['note'] ) ) . '</p>';
		}
		return $html . '</div>';
	}

	/**
	 * Markup for an e-mail (tables and inline styles, no scripts, no buttons).
	 *
	 * @param array{title:string, rows:array<int, array<int,string>>, note:string} $d
	 */
	public static function as_email_html( array $d ): string {
		$html = '<div style="margin:16px 0;padding:14px 16px;border:1px solid #e5e7eb;border-radius:8px;background:#f9fafb"><p style="margin:0 0 8px;font-weight:600">' . esc_html( $d['title'] ) . '</p>';
		if ( $d['rows'] ) {
			$html .= '<table role="presentation" style="border-collapse:collapse;width:100%">';
			foreach ( $d['rows'] as $row ) {
				$html .= '<tr><td style="padding:4px 12px 4px 0;color:#6b7280;vertical-align:top;white-space:nowrap">' . esc_html( $row[0] ) . '</td><td style="padding:4px 0">' . nl2br( esc_html( $row[1] ) ) . '</td></tr>';
			}
			$html .= '</table>';
		}
		if ( '' !== $d['note'] ) {
			$html .= '<p style="margin:10px 0 0">' . nl2br( esc_html( $d['note'] ) ) . '</p>';
		}
		return $html . '</div>';
	}

	// ---------------------------------------------------------------------
	// Small cleaners
	// ---------------------------------------------------------------------

	/** @param mixed $v */
	private static function text( $v, int $max ): string {
		if ( ! is_scalar( $v ) ) {
			return '';
		}
		$t = sanitize_text_field( (string) $v );
		return function_exists( 'mb_substr' ) ? mb_substr( $t, 0, $max ) : substr( $t, 0, $max );
	}

	/** @param mixed $v */
	private static function textarea( $v, int $max ): string {
		if ( ! is_scalar( $v ) ) {
			return '';
		}
		$t = sanitize_textarea_field( (string) $v );
		return function_exists( 'mb_substr' ) ? mb_substr( $t, 0, $max ) : substr( $t, 0, $max );
	}
}
