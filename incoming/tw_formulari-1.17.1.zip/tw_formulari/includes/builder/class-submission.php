<?php
/**
 * What happens when a visitor sends a form: anti-spam, limits, validation, files, storage, e-mails.
 *
 * The page may be served from a full-page cache, so the public endpoint cannot rely on a WordPress nonce.
 * Instead the form carries a signed render time (a visitor who "fills in" the form in under a second is a bot),
 * a hidden honeypot field, and a per-IP rate limit. Everything is validated again here: the browser is a convenience.
 *
 * @package TicinoWeb\TWFormulari\Builder
 */

namespace TicinoWeb\TWFormulari\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Submission {

	/** A signed render time older than this is not trusted any more (cached pages live long). */
	private const TOKEN_MAX_AGE = 30 * DAY_IN_SECONDS;

	/** The honeypot field name (never shown to people). */
	public const HONEYPOT_FIELD = 'twf_website';

	/** The signed render time field. */
	public const TOKEN_FIELD = 'twf_ts';

	/**
	 * Signed render time to embed in the form: "timestamp.signature".
	 */
	public static function make_token( int $form_id, ?int $now = null ): string {
		$now = $now ?? time();
		return $now . '.' . self::sign( $form_id, $now );
	}

	/**
	 * Seconds since the form was rendered, or null when the token is missing, forged or too old.
	 */
	public static function token_age( string $token, int $form_id, ?int $now = null ): ?int {
		$now   = $now ?? time();
		$parts = explode( '.', $token );
		if ( 2 !== count( $parts ) || ! ctype_digit( $parts[0] ) ) {
			return null;
		}
		$ts = (int) $parts[0];
		if ( ! hash_equals( self::sign( $form_id, $ts ), (string) $parts[1] ) ) {
			return null;
		}
		$age = $now - $ts;
		return ( $age < 0 || $age > self::TOKEN_MAX_AGE ) ? null : $age;
	}

	private static function sign( int $form_id, int $ts ): string {
		return substr( hash_hmac( 'sha256', $form_id . '|' . $ts, wp_salt( 'auth' ) ), 0, 32 );
	}

	/** Salted hash of the visitor's IP (never the IP itself). */
	public static function ip_hash(): string {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : '';
		return hash_hmac( 'sha256', $ip, wp_salt( 'auth' ) );
	}

	/**
	 * Counts this attempt and tells whether the visitor went over the hourly limit.
	 *
	 * @param int $limit Attempts per hour per IP and form; 0 disables the limit.
	 */
	public static function rate_limited( int $form_id, int $limit ): bool {
		if ( $limit <= 0 ) {
			return false;
		}
		$key   = 'twf_rl_' . $form_id . '_' . substr( self::ip_hash(), 0, 20 );
		$count = (int) get_transient( $key ) + 1;
		set_transient( $key, $count, HOUR_IN_SECONDS );
		return $count > $limit;
	}

	/**
	 * Runs the whole submission.
	 *
	 * @param int                  $form_id
	 * @param array<string, mixed> $def   Normalised definition.
	 * @param array<string, mixed> $post  Request body (unslashed): twf_f[...], token, honeypot.
	 * @param array<string, mixed> $files $_FILES (the "twf_files" part is used).
	 * @return array{status:int, body:array<string, mixed>}
	 */
	public static function run( int $form_id, array $def, array $post, array $files ): array {
		$settings = (array) $def['settings'];

		// Closed or full forms.
		if ( '' !== (string) $settings['expire_at'] && (string) $settings['expire_at'] < current_time( 'Y-m-d H:i' ) ) {
			return self::fail( 403, __( 'Questo modulo non accetta più risposte.', 'tw-formulari' ) );
		}
		if ( (int) $settings['max_entries'] > 0 && Entries::count( $form_id ) >= (int) $settings['max_entries'] ) {
			return self::fail( 403, __( 'Abbiamo raggiunto il numero massimo di risposte.', 'tw-formulari' ) );
		}

		// Anti-spam. A filled honeypot gets a normal-looking answer, so bots learn nothing.
		if ( ! empty( $settings['honeypot'] ) && '' !== trim( (string) ( $post[ self::HONEYPOT_FIELD ] ?? '' ) ) ) {
			return [ 'status' => 200, 'body' => self::success_body( $def ) ];
		}
		$age = self::token_age( (string) ( $post[ self::TOKEN_FIELD ] ?? '' ), $form_id );
		if ( null === $age ) {
			return self::fail( 400, __( 'La pagina è scaduta. Ricaricala e riprova.', 'tw-formulari' ) );
		}
		if ( $age < (int) $settings['min_seconds'] ) {
			return self::fail( 429, __( 'Hai inviato il modulo troppo in fretta. Riprova tra qualche secondo.', 'tw-formulari' ) );
		}
		if ( self::rate_limited( $form_id, (int) $settings['rate_limit'] ) ) {
			return self::fail( 429, __( 'Hai inviato troppe richieste. Riprova più tardi.', 'tw-formulari' ) );
		}
		if ( ! apply_filters( 'twf_captcha_valid', true, $def, $post ) ) {
			return self::fail( 400, __( 'Verifica anti-spam non superata. Riprova.', 'tw-formulari' ) );
		}

		// Values.
		$input   = isset( $post['twf_f'] ) && is_array( $post['twf_f'] ) ? $post['twf_f'] : [];
		$result  = Processor::process( $def, $input );
		$errors  = $result['errors'];
		$by_id   = Definition::field_map( $def );

		// A form that asks for a payment is never accepted as a free submission: unless its own rules switch the
		// payment off for this answer (e.g. the visitor said it is free for them).
		$wants  = Stripe::applies( $def, $result['values'] );
		$pays   = false; // pays now, online, with Stripe.
		$manual = null;  // chose a manual way to pay (bank transfer…): the method, saved as waiting for payment.
		if ( $wants ) {
			$offered = PaymentMethods::offered( $def );
			if ( ! $offered ) {
				return self::fail( 503, __( 'Il pagamento non è ancora disponibile. Riprova più tardi.', 'tw-formulari' ) );
			}
			$choice = isset( $post['twf_pay_method'] ) && is_scalar( $post['twf_pay_method'] ) ? sanitize_key( (string) $post['twf_pay_method'] ) : '';
			if ( '' === $choice && 1 === count( $offered ) ) {
				$choice = $offered[0];
			}
			if ( ! in_array( $choice, $offered, true ) ) {
				return self::fail( 422, __( 'Scegli come vuoi pagare.', 'tw-formulari' ) );
			}
			if ( PaymentMethods::STRIPE === $choice ) {
				$pays = true;
			} else {
				$manual = PaymentMethods::get( $choice );
			}
		}

		// The amount to charge comes from the answers, computed here; nothing the browser says about money counts.
		$amount = null;
		if ( $wants && ! $errors ) {
			$amount = Stripe::amount( $def, $result['values'] );
			if ( ! $amount['ok'] ) {
				return self::fail( 422, $amount['error'] );
			}
		}

		// Files of the visible upload fields.
		$stored    = [];
		$all_files = [];
		$raw_files = isset( $files['twf_files'] ) && is_array( $files['twf_files'] ) ? $files['twf_files'] : [];
		foreach ( $result['uploads'] as $field_id ) {
			$raw = self::pick_files( $raw_files, $field_id );
			$upload_field             = $by_id[ $field_id ];
			$upload_field['required'] = $result['required'][ $field_id ] ?? ! empty( $upload_field['required'] );
			$res                      = Uploads::process_field( $upload_field, $raw );
			if ( null !== $res['error'] ) {
				$errors[ $field_id ] = $res['error'];
				continue;
			}
			if ( $res['files'] ) {
				$stored[ $field_id ] = $res['files'];
				$all_files           = array_merge( $all_files, $res['files'] );
			}
		}

		if ( $errors ) {
			Uploads::delete_files( $all_files );
			return [
				'status' => 422,
				'body'   => [
					'ok'      => false,
					'message' => __( 'Controlla i campi evidenziati e riprova.', 'tw-formulari' ),
					'errors'  => $errors,
				],
			];
		}

		$values = $result['values'];
		foreach ( $stored as $field_id => $list ) {
			$values[ $field_id ] = $list;
		}

		// Storage. A form with payment always stores: the entry is what the payment will confirm.
		$entry_id = 0;
		if ( ! empty( $def['payment']['enabled'] ) || ! empty( $settings['store_entries'] ) ) {
			$entry_id = Entries::create( [
				'form_id' => $form_id,
				'status'  => $pays ? Entries::STATUS_PENDING_PAYMENT : ( $manual ? Entries::STATUS_AWAITING_PAYMENT : Entries::STATUS_NEW ),
				'lang'    => self::current_lang(),
				'data'    => $values,
				'display' => Entries::snapshot( $def, $values ),
				'files'   => $all_files,
				'payment' => $pays ? [
					'provider' => 'stripe',
					'status'   => 'pending',
					'amount'   => $amount['amount'],
					'minor'    => $amount['minor'],
					'currency' => $amount['currency'],
					'livemode' => 'live' === Stripe::mode(),
					'intent'   => '',
				] : ( $manual ? [
					'provider' => 'manual',
					'method'   => (string) $manual['id'],
					'label'    => (string) $manual['label'],
					'status'   => 'awaiting',
					'amount'   => $amount['amount'],
					'minor'    => $amount['minor'],
					'currency' => $amount['currency'],
				] : new \stdClass() ),
				'ip_hash' => self::ip_hash(),
			] );
			if ( 0 === $entry_id ) {
				Uploads::delete_files( $all_files );
				return self::fail( 500, __( 'Non siamo riusciti a salvare la tua richiesta. Riprova più tardi.', 'tw-formulari' ) );
			}
		}

		// Payment: the intent is created now, the e-mails wait for the money (see Stripe::sync_intent).
		if ( $pays ) {
			$intent = Stripe::create_intent( $form_id, $entry_id, $def, $values, $amount );
			if ( ! $intent['ok'] ) {
				error_log( 'tw_formulari: pagamento non avviato per il modulo ' . $form_id . ': ' . ( $intent['error'] ?? '' ) );
				Entries::delete( [ $entry_id ] );
				return self::fail( 502, __( 'Il sistema di pagamento non risponde. Riprova tra qualche minuto.', 'tw-formulari' ) );
			}
			$entry = Entries::get( $entry_id );
			$pay   = (array) ( $entry['payment'] ?? [] );
			$pay['intent'] = $intent['intent'];
			Entries::update( $entry_id, [ 'payment' => $pay ] );
			return [
				'status' => 200,
				'body'   => [
					'ok'      => true,
					'payment' => [
						'client_secret' => $intent['client_secret'],
						'intent'        => $intent['intent'],
						'amount'        => $amount['minor'],
						'currency'      => strtolower( $amount['currency'] ),
					],
				],
			];
		}

		// Manual way to pay: the details are shown on the confirmation and sent in the e-mail to the visitor.
		$instructions = null;
		if ( $manual ) {
			$instructions = PaymentMethods::describe( $manual, [
				'amount'     => $amount['amount'],
				'currency'   => $amount['currency'],
				'entry_id'   => $entry_id,
				'form_title' => (string) ( $def['title'] ?? '' ),
			] );
			if ( $entry_id > 0 ) {
				$pay              = (array) ( Entries::get( $entry_id )['payment'] ?? [] );
				$reference        = '';
				foreach ( $instructions['rows'] as $row ) {
					if ( __( 'Causale', 'tw-formulari' ) === $row[0] ) {
						$reference = $row[1];
					}
				}
				$pay['reference'] = $reference;
				Entries::update( $entry_id, [ 'payment' => $pay ] );
			}
		}

		// E-mails. A failed e-mail never turns a saved submission into an error for the visitor.
		$sent = Notifications::send_all( $def, $values, [
			'entry_id'       => $entry_id,
			'files'          => $all_files,
			'payment_manual' => $instructions,
			'payment'        => $manual ? [ 'amount' => $amount['amount'], 'currency' => $amount['currency'] ] : [],
		] );
		if ( $sent['failed'] > 0 ) {
			error_log( sprintf( 'tw_formulari: %d notifica/e non inviata/e per il modulo %d (compilazione %d).', $sent['failed'], $form_id, $entry_id ) );
		}
		if ( empty( $settings['store_entries'] ) ) {
			Uploads::delete_files( $all_files );
		}

		do_action( 'twf_submission_completed', $form_id, $entry_id, $values, $def );

		$body = self::success_body( $def );
		if ( $instructions ) {
			$body['manual'] = [ 'title' => $instructions['title'], 'html' => PaymentMethods::as_html( $instructions ) ];
		}
		return [ 'status' => 200, 'body' => $body ];
	}

	/**
	 * The part of $_FILES['twf_files'] that belongs to one field. PHP nests it as name[field][i].
	 *
	 * @param array<string, mixed> $raw
	 * @return array<string, mixed>|null Same shape as a single $_FILES entry (arrays for several files).
	 */
	public static function pick_files( array $raw, string $field_id ): ?array {
		if ( ! isset( $raw['name'][ $field_id ] ) ) {
			return null;
		}
		$one = [];
		foreach ( [ 'name', 'type', 'tmp_name', 'error', 'size' ] as $key ) {
			$one[ $key ] = $raw[ $key ][ $field_id ] ?? null;
		}
		return $one;
	}

	/**
	 * @param array<string, mixed> $def
	 * @return array<string, mixed>
	 */
	public static function success_body( array $def ): array {
		$c = (array) $def['confirmation'];
		return [
			'ok'           => true,
			'confirmation' => [
				'type'      => (string) $c['type'],
				'message'   => (string) $c['message'],
				'url'       => (string) $c['url'],
				'autoclose' => (int) $c['autoclose'],
			],
		];
	}

	/**
	 * @return array{status:int, body:array<string, mixed>}
	 */
	private static function fail( int $status, string $message ): array {
		return [ 'status' => $status, 'body' => [ 'ok' => false, 'message' => $message ] ];
	}

	/** Language of the visitor (WPML first, then the site locale). */
	public static function current_lang(): string {
		$wpml = apply_filters( 'wpml_current_language', null );
		if ( is_string( $wpml ) && '' !== $wpml ) {
			return $wpml;
		}
		return function_exists( 'determine_locale' ) ? (string) determine_locale() : (string) get_locale();
	}
}
