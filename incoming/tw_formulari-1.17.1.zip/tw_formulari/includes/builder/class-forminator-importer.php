<?php
/**
 * Imports forms, submissions and settings from Forminator into the built-in form builder.
 *
 * Forminator itself is only read, never changed: forms become new forms of tw_formulari (each remembers where it
 * came from), submissions are copied with their original date and attached files (copied into the private folder),
 * the Stripe keys are carried over into empty slots only. The import can be repeated (it continues where it
 * stopped and picks up new submissions) and undone (everything it created is removed; nothing else is touched).
 *
 * Forminator keeps a form as a post of type "forminator_forms" with one serialized post meta
 * ("forminator_form_meta": fields, settings, notifications, behaviors) and its submissions in two tables
 * ({prefix}frmt_form_entry and {prefix}frmt_form_entry_meta, one meta row per field, keyed by the field id).
 *
 * The conversion (convert_form, convert_entry) is pure: it works on arrays and touches no database.
 *
 * @package TicinoWeb\TWFormulari\Builder
 */

namespace TicinoWeb\TWFormulari\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ForminatorImporter {

	public const OPTION    = 'twf_forminator_import';
	public const POST_TYPE = 'forminator_forms';
	public const META_KEY  = 'forminator_form_meta';
	public const SOURCE    = '_twf_imported_from';
	/** Submissions copied per request. */
	public const BATCH     = 40;

	/** Forminator condition operators → ours. */
	private const OPERATORS = [
		'is'          => 'is',
		'is_not'      => 'is_not',
		'is_great'    => 'gt',
		'is_less'     => 'lt',
		'contains'    => 'contains',
		'does_not_contain' => 'not_contains',
		'starts'      => 'starts',
		'ends'        => 'ends',
		'is_empty'    => 'empty',
		'is_not_empty' => 'not_empty',
	];

	/** Forminator field types with no equivalent: skipped with a note. */
	private const UNSUPPORTED = [ 'password', 'rating', 'slider', 'postdata', 'paypal', 'group', 'signature' ];

	// =====================================================================
	// Detection and listing (database)
	// =====================================================================

	/** True only while Forminator is active: the import button and its tab do not exist otherwise. */
	public static function detected(): bool {
		return defined( 'FORMINATOR_VERSION' );
	}

	public static function plugin_installed(): bool {
		if ( ! function_exists( 'get_plugins' ) && defined( 'ABSPATH' ) && is_file( ABSPATH . 'wp-admin/includes/plugin.php' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		foreach ( function_exists( 'get_plugins' ) ? array_keys( (array) get_plugins() ) : [] as $file ) {
			if ( 0 === strpos( (string) $file, 'forminator' ) ) {
				return true;
			}
		}
		return false;
	}

	/** @return string "active", "inactive" or "" (not installed). */
	public static function plugin_state(): string {
		if ( defined( 'FORMINATOR_VERSION' ) ) {
			return 'active';
		}
		return self::plugin_installed() ? 'inactive' : '';
	}

	public static function version(): string {
		if ( defined( 'FORMINATOR_VERSION' ) ) {
			return (string) FORMINATOR_VERSION;
		}
		return (string) get_option( 'forminator_version', '' );
	}

	/**
	 * Forminator's forms.
	 *
	 * @return array<int, array{id:int,title:string,status:string,date:string}>
	 */
	public static function forms(): array {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_title, post_status, post_date FROM {$wpdb->posts} WHERE post_type = %s AND post_status IN ('publish','draft','private','pending') ORDER BY ID ASC", self::POST_TYPE ), ARRAY_A );
		$out  = [];
		foreach ( (array) $rows as $r ) {
			$out[] = [ 'id' => (int) $r['ID'], 'title' => (string) $r['post_title'], 'status' => (string) $r['post_status'], 'date' => (string) $r['post_date'] ];
		}
		return $out;
	}

	public static function entries_table(): string {
		global $wpdb;
		return $wpdb->prefix . 'frmt_form_entry';
	}

	public static function meta_table(): string {
		global $wpdb;
		return $wpdb->prefix . 'frmt_form_entry_meta';
	}

	public static function tables_exist(): bool {
		global $wpdb;
		return self::entries_table() === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', self::entries_table() ) )
			&& self::meta_table() === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', self::meta_table() ) );
	}

	/** Submissions worth importing: not spam, not drafts. */
	public static function entry_count( int $form_id ): int {
		global $wpdb;
		if ( ! self::tables_exist() ) {
			return 0;
		}
		$t = self::entries_table();
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE form_id = %d AND is_spam = 0 AND status = 'active'", $form_id ) );
	}

	/** @return array<string, mixed>|null */
	public static function form_meta( int $form_id ): ?array {
		$meta = get_post_meta( $form_id, self::META_KEY, true );
		return is_array( $meta ) ? $meta : null;
	}

	// =====================================================================
	// Conversion of a form (pure)
	// =====================================================================

	/**
	 * Converts a Forminator form into a tw_formulari definition.
	 *
	 * @param array<string, mixed> $meta     The "forminator_form_meta" of the form.
	 * @param string               $title    Post title (used when the form has no readable name).
	 * @param array<string, mixed> $context  currency (default currency), admin_email, home_url, site_name.
	 * @return array{definition:array<string,mixed>, map:array<string,array<string,mixed>>, warnings:string[], stripe_mode:string}
	 */
	public static function convert_form( array $meta, string $title, array $context = [] ): array {
		$warnings = [];
		$settings = (array) ( $meta['settings'] ?? [] );
		$raw      = array_values( array_filter( (array) ( $meta['fields'] ?? [] ), 'is_array' ) );
		$currency = strtoupper( (string) ( $context['currency'] ?? 'CHF' ) );

		// 1. Every Forminator field gets its id first (conditions and formulas refer to ids).
		$ids = [];
		foreach ( $raw as $f ) {
			$eid = (string) ( $f['element_id'] ?? $f['id'] ?? '' );
			if ( '' !== $eid ) {
				$ids[ $eid ] = self::id_for( $eid );
			}
		}

		// 2. Fields.
		$fields      = [];
		$map         = [];
		$pending     = []; // our id => raw field, to convert conditions once every id is known.
		$payment     = null;
		$stripe_mode = '';
		foreach ( $raw as $f ) {
			$type  = (string) ( $f['type'] ?? '' );
			$eid   = (string) ( $f['element_id'] ?? $f['id'] ?? '' );
			$label = self::plain( (string) ( $f['field_label'] ?? '' ) );
			$shown = '' !== $label ? $label : $eid;

			if ( in_array( $type, [ 'stripe', 'stripe-ocs' ], true ) ) {
				$converted = self::convert_payment( $f, $ids, $currency, $warnings );
				if ( null !== $converted ) {
					$payment     = $converted['payment'];
					$stripe_mode = $converted['mode'];
					$pending['__payment'] = $f;
				}
				continue;
			}
			if ( 'captcha' === $type ) {
				$warnings[] = 'Captcha non importato: il modulo usa l’antispam integrato (campo trappola, tempo minimo, limite per IP).';
				continue;
			}
			if ( in_array( $type, self::UNSUPPORTED, true ) ) {
				$warnings[] = sprintf( 'Campo «%s» (tipo %s) non supportato: non importato.', $shown, $type );
				continue;
			}

			$field = self::convert_field( $f, $type, $ids, $warnings );
			if ( null === $field ) {
				$warnings[] = sprintf( 'Campo «%s» (tipo %s) non riconosciuto: non importato.', $shown, $type );
				continue;
			}
			$field['id']   = $ids[ $eid ] ?? self::id_for( $eid );
			$fields[]      = $field;
			$pending[ $field['id'] ] = $f;
			$map[ $eid ]   = [
				'id'       => $field['id'],
				'type'     => $field['type'],
				'source'   => $type,
				'options'  => $field['options'] ?? [],
				'decimals' => (int) ( $field['decimals'] ?? 2 ),
				'date_format' => (string) ( $f['date_format'] ?? '' ),
				'multi'    => 'select' === $type && 'multiselect' === (string) ( $f['value_type'] ?? '' ),
			];
		}

		// 3. Conditions (now that every id exists).
		foreach ( $fields as $i => $field ) {
			$src = $pending[ $field['id'] ] ?? [];
			$cond = self::convert_conditions( $src, $map, 'Campo «' . ( $field['label'] ?: $field['id'] ) . '»', $warnings );
			if ( null !== $cond ) {
				$fields[ $i ]['conditions'] = $cond;
			}
		}
		if ( null !== $payment && isset( $pending['__payment'] ) ) {
			$cond = self::convert_conditions( $pending['__payment'], $map, 'Pagamento', $warnings );
			if ( null !== $cond ) {
				$payment['conditions'] = $cond;
			}
			$payment = self::resolve_payment_fields( $payment, $map, $warnings );
		}

		// 4. Notifications, confirmation, settings.
		$notifications = self::convert_notifications( (array) ( $meta['notifications'] ?? [] ), $map, $context, $warnings );
		$confirmation  = self::convert_confirmation( (array) ( $meta['behaviors'] ?? [] ), $settings, null !== $payment );
		$out_settings  = self::convert_settings( $settings, $warnings );

		$name = self::plain( (string) ( $settings['formName'] ?? $settings['form_name'] ?? '' ) );
		$name = '' !== $name ? $name : ucfirst( trim( str_replace( [ '-', '_' ], ' ', $title ) ) );

		$definition = [
			'title'         => $name,
			'fields'        => $fields,
			'notifications' => $notifications,
			'confirmation'  => $confirmation,
			'settings'      => $out_settings,
		];
		if ( null !== $payment ) {
			$definition['payment'] = $payment;
		}

		return [ 'definition' => $definition, 'map' => $map, 'warnings' => array_values( array_unique( $warnings ) ), 'stripe_mode' => $stripe_mode ];
	}

	/** Forminator field id → ours (letters, digits, underscore). */
	public static function id_for( string $element_id ): string {
		$id = preg_replace( '/[^a-z0-9_]/', '_', strtolower( $element_id ) );
		return substr( (string) $id, 0, 40 );
	}

	/**
	 * @param array<string, mixed>  $f
	 * @param array<string, string> $ids
	 * @param string[]              $warnings
	 * @return array<string, mixed>|null
	 */
	private static function convert_field( array $f, string $type, array $ids, array &$warnings ): ?array {
		$label = self::plain( (string) ( $f['field_label'] ?? '' ) );
		$cols  = (int) ( $f['cols'] ?? 12 );
		$field = [
			'label'       => $label,
			'description' => self::plain( (string) ( $f['description'] ?? '' ) ),
			'placeholder' => self::plain( (string) ( $f['placeholder'] ?? '' ) ),
			'required'    => self::flag( $f['required'] ?? false ),
			'width'       => ( $cols > 0 && $cols <= 6 ) ? 'half' : 'full',
		];

		switch ( $type ) {
			case 'name':
				// The fname/lname/mname/prefix flags matter only in "multiple name" mode; otherwise it is one input.
				$multiple      = self::flag( $f['multiple_name'] ?? false );
				$field['type'] = 'name';
				$field['last'] = $multiple && self::flag( $f['lname'] ?? false );
				if ( $multiple ) {
					$field['placeholder'] = self::plain( (string) ( $f['fname_placeholder'] ?? '' ) );
					if ( self::flag( $f['mname'] ?? false ) || self::flag( $f['prefix'] ?? false ) ) {
						$warnings[] = sprintf( 'Campo «%s»: secondo nome e titolo non importati.', $label );
					}
				}
				return $field;

			case 'email':
			case 'phone':
				$field['type'] = $type;
				return $field;

			case 'address':
				// Forminator labels the parts, not the field: use the street label as the title.
				$field['type']     = 'address';
				$field['label']    = '' !== $label ? $label : self::plain( (string) ( $f['street_address_label'] ?? '' ) );
				$field['label']    = '' !== $field['label'] ? $field['label'] : 'Indirizzo';
				$field['required'] = self::flag( $f['street_address_required'] ?? $f['required'] ?? false );
				$field['country']  = self::flag( $f['address_country'] ?? false );
				if ( self::flag( $f['address_state'] ?? false ) || self::flag( $f['address_line'] ?? false ) ) {
					$warnings[] = sprintf( 'Campo «%s»: provincia e seconda riga dell’indirizzo non sono campi separati (la provincia, nelle compilazioni, si aggiunge alla località).', $field['label'] );
				}
				return $field;

			case 'text':
				$paragraph          = 'paragraph' === (string) ( $f['input_type'] ?? 'line' );
				$field['type']      = $paragraph ? 'textarea' : 'text';
				$field['max_length'] = self::limit( $f );
				$field['default']   = self::plain( (string) ( $f['default'] ?? '' ) );
				return $field;

			case 'textarea':
				$field['type']       = 'textarea';
				$field['max_length'] = self::limit( $f );
				$field['default']    = self::plain( (string) ( $f['default'] ?? '' ) );
				return $field;

			case 'website':
				$field['type'] = 'text';
				$warnings[]    = sprintf( 'Campo «%s» (sito web): importato come testo breve.', $label );
				return $field;

			case 'time':
				$field['type'] = 'text';
				$warnings[]    = sprintf( 'Campo «%s» (orario): importato come testo breve (es. 14:30).', $label );
				return $field;

			case 'number':
			case 'currency':
				$field['type']    = $type;
				$field['min']     = (string) ( $f['limit_min'] ?? $f['min'] ?? '' );
				$field['max']     = (string) ( $f['limit_max'] ?? $f['max'] ?? '' );
				$field['default'] = (string) ( $f['default_value'] ?? '' );
				return $field;

			case 'select':
			case 'radio':
			case 'checkbox':
				$multi = 'select' === $type && 'multiselect' === (string) ( $f['value_type'] ?? '' );
				$field['type']    = $multi ? 'checkbox' : $type;
				$field['options'] = self::convert_options( (array) ( $f['options'] ?? [] ), self::flag( $f['calculations'] ?? false ), $label, $warnings );
				if ( $multi ) {
					$warnings[] = sprintf( 'Campo «%s»: la scelta multipla a tendina diventa un elenco di caselle.', $label );
				}
				if ( self::flag( $f['enable_custom_option'] ?? false ) ) {
					$warnings[] = sprintf( 'Campo «%s»: l’opzione libera «Altro» non è supportata.', $label );
				}
				return $field;

			case 'date':
				$field['type'] = 'date';
				return $field;

			case 'upload':
				$field['type']        = 'upload';
				$field['extensions']  = self::upload_extensions( $f );
				$size                 = (int) ( $f['upload-limit'] ?? 0 );
				$field['max_size_mb'] = $size > 0 ? min( 25, $size ) : 5;
				$multiple             = 'multiple' === (string) ( $f['file-type'] ?? 'single' );
				$limit                = (int) ( $f['file-limit-input'] ?? 0 );
				$field['max_files']   = $multiple ? ( 'specify' === (string) ( $f['file-limit'] ?? '' ) && $limit > 0 ? min( 10, $limit ) : 10 ) : 1;
				$warnings[]           = sprintf( 'Campo «%s» (allegato): controlla i formati ammessi e la dimensione massima.', $label );
				return $field;

			case 'hidden':
				$field['type']    = 'hidden';
				$source           = (string) ( $f['default_value'] ?? 'custom_value' );
				$custom           = (string) ( $f['custom_value'] ?? '' );
				$field['default'] = 'custom_value' === $source ? $custom : '';
				$field['param']   = 'query' === $source ? preg_replace( '/[^A-Za-z0-9_\-]/', '', $custom ) : '';
				if ( ! in_array( $source, [ 'custom_value', 'query' ], true ) ) {
					$warnings[] = sprintf( 'Campo nascosto «%s»: il valore automatico «%s» non è supportato.', $label, $source );
				}
				return $field;

			case 'html':
				$field['type']    = 'html';
				$field['content'] = (string) ( $f['variations'] ?? '' );
				return $field;

			case 'section':
				$field['type']        = 'section';
				$field['label']       = self::plain( (string) ( $f['section_title'] ?? $f['field_label'] ?? '' ) );
				$field['description'] = self::plain( (string) ( $f['section_subtitle'] ?? '' ) );
				return $field;

			case 'page-break':
				$field['type']  = 'page_break';
				$field['label'] = '';
				return $field;

			case 'gdprcheckbox':
				$field['type']     = 'gdpr';
				$field['required'] = true;
				$field['content']  = (string) ( $f['gdpr_description'] ?? '' );
				return $field;

			case 'consent':
				$field['type']     = 'gdpr';
				$field['required'] = self::flag( $f['required'] ?? true );
				$field['content']  = (string) ( $f['consent_description'] ?? '' );
				return $field;

			case 'calculation':
				$field['type']     = 'calculation';
				$field['formula']  = self::convert_formula( (string) ( $f['formula'] ?? '' ), $ids );
				$field['decimals'] = 2;
				$field['required'] = false;
				return $field;
		}
		return null;
	}

	/**
	 * @param array<int, mixed> $options
	 * @param string[]          $warnings
	 * @return array<int, array{value:string,label:string,calc:string}>
	 */
	private static function convert_options( array $options, bool $with_calc, string $label, array &$warnings ): array {
		$out = [];
		foreach ( $options as $o ) {
			if ( ! is_array( $o ) ) {
				continue;
			}
			$text  = self::plain( (string) ( $o['label'] ?? '' ) );
			$value = (string) ( $o['value'] ?? '' );
			$value = '' !== $value ? $value : $text;
			$calc  = $with_calc && isset( $o['calculation'] ) && '' !== (string) $o['calculation'] ? (string) $o['calculation'] : '';
			$out[] = [ 'value' => $value, 'label' => '' !== $text ? $text : $value, 'calc' => $calc ];
			if ( '' !== (string) ( $o['limit'] ?? '' ) ) {
				$warnings[] = sprintf( 'Campo «%s»: il limite di posti dell’opzione «%s» non è supportato.', $label, $text );
			}
		}
		return $out;
	}

	/**
	 * @param array<string, mixed> $f
	 * @return string[]
	 */
	private static function upload_extensions( array $f ): array {
		$groups = [
			'image'       => [ 'jpg', 'jpeg', 'png', 'gif', 'webp' ],
			'document'    => [ 'pdf', 'doc', 'docx', 'odt', 'txt' ],
			'spreadsheet' => [ 'xls', 'xlsx', 'ods', 'csv' ],
			'archive'     => [ 'zip' ],
		];
		$raw  = array_merge( (array) ( $f['filetypes'] ?? [] ), preg_split( '/[\s,;]+/', (string) ( $f['additional-type'] ?? '' ) ) ?: [] );
		$out  = [];
		foreach ( $raw as $item ) {
			$item = strtolower( ltrim( trim( (string) $item ), '.' ) );
			if ( '' === $item ) {
				continue;
			}
			foreach ( $groups[ $item ] ?? [ $item ] as $ext ) {
				$out[] = $ext;
			}
		}
		return array_values( array_unique( $out ) );
	}

	/** Maximum length: only when Forminator asked for a limit in characters. */
	private static function limit( array $f ): int {
		return ( 'characters' === (string) ( $f['limit_type'] ?? 'characters' ) && (int) ( $f['limit'] ?? 0 ) > 0 ) ? (int) $f['limit'] : 0;
	}

	/** Formula: {select-1} → {select_1}. Forminator formulas use the same + - * / ( ) as ours. */
	private static function convert_formula( string $formula, array $ids ): string {
		return (string) preg_replace_callback( '/\{([A-Za-z0-9_-]+)\}/', static function ( array $m ) use ( $ids ): string {
			return '{' . ( $ids[ $m[1] ] ?? self::id_for( $m[1] ) ) . '}';
		}, $formula );
	}

	/**
	 * Show/hide rules of a field (or of the payment).
	 *
	 * @param array<string, mixed>               $src
	 * @param array<string, array<string, mixed>> $map
	 * @param string[]                           $warnings
	 * @return array{action:string,match:string,rules:array<int,array<string,string>>}|null
	 */
	private static function convert_conditions( array $src, array $map, string $where, array &$warnings ): ?array {
		$rules = [];
		foreach ( (array) ( $src['conditions'] ?? [] ) as $c ) {
			if ( ! is_array( $c ) ) {
				continue;
			}
			$target = (string) ( $c['element_id'] ?? '' );
			if ( ! isset( $map[ $target ] ) ) {
				$warnings[] = sprintf( '%s: una condizione guarda il campo «%s», che non è stato importato: condizione ignorata.', $where, $target );
				continue;
			}
			$op = self::OPERATORS[ (string) ( $c['rule'] ?? 'is' ) ] ?? null;
			if ( null === $op ) {
				$warnings[] = sprintf( '%s: confronto «%s» non supportato: condizione ignorata.', $where, (string) ( $c['rule'] ?? '' ) );
				continue;
			}
			$rules[] = [ 'field' => $map[ $target ]['id'], 'op' => $op, 'value' => (string) ( $c['value'] ?? '' ) ];
		}
		if ( ! $rules ) {
			return null;
		}
		return [
			'action' => 'hide' === (string) ( $src['condition_action'] ?? 'show' ) ? 'hide' : 'show',
			'match'  => 'any' === (string) ( $src['condition_rule'] ?? 'all' ) ? 'any' : 'all',
			'rules'  => $rules,
		];
	}

	/**
	 * The Stripe field becomes the form's payment block.
	 *
	 * @param array<string, mixed>  $f
	 * @param array<string, string> $ids
	 * @param string[]              $warnings
	 * @return array{payment:array<string,mixed>, mode:string}|null
	 */
	private static function convert_payment( array $f, array $ids, string $default_currency, array &$warnings ): ?array {
		$plan = (array) ( ( (array) ( $f['payments'] ?? [] ) )[0] ?? [] );
		$kind = (string) ( $plan['payment_method'] ?? 'single' );
		if ( 'subscription' === $kind ) {
			$warnings[] = 'Pagamento ricorrente (abbonamento) non supportato: il modulo è importato SENZA pagamento. Va rifatto a mano.';
			return null;
		}
		$amount_type = (string) ( $plan['amount_type'] ?? $f['amount_type'] ?? 'fixed' );
		$variable    = (string) ( $plan['variable'] ?? $f['variable'] ?? '' );
		$amount      = (string) ( $plan['amount'] ?? $f['amount'] ?? '' );
		$payment     = [
			'enabled'      => true,
			'currency'     => strtoupper( (string) ( $f['currency'] ?? $default_currency ) ),
			'mode'         => 'variable' === $amount_type ? 'field' : 'fixed',
			'amount'       => 'variable' === $amount_type ? '' : $amount,
			'amount_field' => 'variable' === $amount_type ? ( $ids[ $variable ] ?? self::id_for( $variable ) ) : '',
			'description'  => self::plain( (string) ( $f['product_description'] ?? '' ) ),
			'email_field'  => (string) ( $f['billing_email'] ?? $f['customer_email'] ?? '' ),
		];
		return [ 'payment' => $payment, 'mode' => (string) ( $f['mode'] ?? '' ) ];
	}

	/**
	 * The payment points to fields by Forminator id: resolve them against the imported fields.
	 *
	 * @param array<string, mixed>               $payment
	 * @param array<string, array<string, mixed>> $map
	 * @param string[]                           $warnings
	 * @return array<string, mixed>
	 */
	private static function resolve_payment_fields( array $payment, array $map, array &$warnings ): array {
		if ( 'field' === $payment['mode'] ) {
			$by_ours = [];
			foreach ( $map as $m ) {
				$by_ours[ $m['id'] ] = $m;
			}
			$target = $by_ours[ $payment['amount_field'] ] ?? null;
			if ( null === $target ) {
				$warnings[] = 'Pagamento: il campo dell’importo non è stato importato. Scegli l’importo nella scheda Pagamento.';
				$payment['amount_field'] = '';
			} elseif ( 'calculation' === $target['type'] ) {
				$payment['mode'] = 'calculation';
			}
		}
		$email = (string) $payment['email_field'];
		if ( '' !== $email && isset( $map[ $email ] ) && 'email' === $map[ $email ]['type'] ) {
			$payment['email_field'] = $map[ $email ]['id'];
		} else {
			$payment['email_field'] = '';
		}
		return $payment;
	}

	/**
	 * @param array<int, mixed>                  $list
	 * @param array<string, array<string, mixed>> $map
	 * @param array<string, mixed>               $context
	 * @param string[]                           $warnings
	 * @return array<int, array<string, mixed>>
	 */
	private static function convert_notifications( array $list, array $map, array $context, array &$warnings ): array {
		$admin = (string) ( $context['admin_email'] ?? '' );
		$out   = [];
		foreach ( $list as $i => $n ) {
			if ( ! is_array( $n ) ) {
				continue;
			}
			$name = self::plain( (string) ( $n['label'] ?? '' ) );
			$name = '' !== $name ? $name : 'Avviso ' . ( $i + 1 );
			$to   = [];
			$to_f = [];
			foreach ( [ 'recipients', 'cc-email', 'bcc-email' ] as $key ) {
				foreach ( preg_split( '/[\s,;]+/', (string) ( $n[ $key ] ?? '' ) ) ?: [] as $addr ) {
					$addr = trim( (string) $addr );
					if ( '' === $addr ) {
						continue;
					}
					if ( preg_match( '/^\{([A-Za-z0-9_-]+)\}$/', $addr, $m ) ) {
						if ( 'admin_email' === $m[1] && '' !== $admin ) {
							$to[] = $admin;
						} elseif ( isset( $map[ $m[1] ] ) && 'email' === $map[ $m[1] ]['type'] ) {
							$to_f[] = $map[ $m[1] ]['id'];
						} else {
							$warnings[] = sprintf( 'Notifica «%s»: il destinatario %s non è un campo e-mail importato: ignorato.', $name, $addr );
						}
					} elseif ( function_exists( 'is_email' ) ? is_email( $addr ) : false !== filter_var( $addr, FILTER_VALIDATE_EMAIL ) ) {
						$to[] = $addr;
					}
				}
			}
			if ( '' !== trim( (string) ( $n['cc-email'] ?? '' ) ) . trim( (string) ( $n['bcc-email'] ?? '' ) ) ) {
				$warnings[] = sprintf( 'Notifica «%s»: copia (CC/CCN) trasformata in destinatari: ognuno riceve la sua e-mail separata.', $name );
			}
			if ( ! empty( $n['email-pdfs'] ) ) {
				$warnings[] = sprintf( 'Notifica «%s»: l’allegato PDF di Forminator non è importato (nel plugin il PDF è una funzione a parte, da accendere in Impostazioni).', $name );
			}
			if ( 'routing' === (string) ( $n['email-recipients'] ?? '' ) ) {
				$warnings[] = sprintf( 'Notifica «%s»: l’instradamento per condizioni non è supportato: controlla i destinatari.', $name );
			}

			$reply = '';
			if ( preg_match( '/^\{([A-Za-z0-9_-]+)\}$/', trim( (string) ( $n['replyto-email'] ?? '' ) ), $m ) && isset( $map[ $m[1] ] ) && 'email' === $map[ $m[1] ]['type'] ) {
				$reply = $map[ $m[1] ]['id'];
			}

			$notification = [
				'id'             => 'n' . ( $i + 1 ),
				'name'           => $name,
				'enabled'        => true,
				'to'             => array_values( array_unique( $to ) ),
				'to_fields'      => array_values( array_unique( $to_f ) ),
				'subject'        => self::convert_text( (string) ( $n['email-subject'] ?? '' ), $map, $context, false ),
				'body'           => self::convert_text( (string) ( $n['email-editor'] ?? '' ), $map, $context, true ),
				'reply_to_field' => $reply,
				'attach_files'   => self::flag( $n['email-attachment'] ?? false ),
				'attach_pdf'     => false,
			];
			$cond = self::convert_conditions( $n, $map, 'Notifica «' . $name . '»', $warnings );
			if ( null !== $cond ) {
				$notification['conditions'] = $cond;
			}
			$out[] = $notification;
		}
		return $out;
	}

	/**
	 * Subject / message: tags {name-1} → {name_1}, a few known tags renamed, HTML reduced to text.
	 *
	 * @param array<string, array<string, mixed>> $map
	 * @param array<string, mixed>               $context
	 */
	private static function convert_text( string $text, array $map, array $context, bool $html ): string {
		if ( $html ) {
			$text = (string) preg_replace( '#<\s*br\s*/?\s*>#i', "\n", $text );
			$text = (string) preg_replace( '#</\s*(p|div|li|h[1-6]|tr)\s*>#i', "\n", $text );
			$text = html_entity_decode( strip_tags( $text ), ENT_QUOTES, 'UTF-8' );
			$text = trim( (string) preg_replace( "/\n{3,}/", "\n\n", str_replace( "\r", '', $text ) ) );
		}
		$renamed = [
			'form_name'     => 'form_title',
			'submission_id' => 'entry_id',
			'site_title'    => 'site_name',
			'blog_name'     => 'site_name',
		];
		return (string) preg_replace_callback( '/\{([A-Za-z0-9_-]+)\}/', static function ( array $m ) use ( $map, $renamed, $context ): string {
			$tag = $m[1];
			if ( 'all_fields' === $tag ) {
				return '{all_fields}';
			}
			if ( isset( $map[ $tag ] ) ) {
				return '{' . $map[ $tag ]['id'] . '}';
			}
			if ( isset( $renamed[ $tag ] ) ) {
				return '{' . $renamed[ $tag ] . '}';
			}
			if ( 'site_url' === $tag ) {
				return (string) ( $context['home_url'] ?? '' );
			}
			return ''; // unknown tags would print nothing anyway.
		}, $text );
	}

	/**
	 * @param array<int, mixed>    $behaviors
	 * @param array<string, mixed> $settings
	 * @return array<string, mixed>
	 */
	private static function convert_confirmation( array $behaviors, array $settings, bool $has_payment ): array {
		$b       = (array) ( $behaviors[0] ?? [] );
		$kind    = (string) ( $b['submission-behaviour'] ?? $settings['submission-behaviour'] ?? 'behaviour-thankyou' );
		$message = (string) ( $b['thankyou-message'] ?? $settings['thankyou-message'] ?? '' );
		$url     = (string) ( $b['redirect-url'] ?? $settings['redirect-url'] ?? '' );
		$auto    = self::flag( $b['autoclose'] ?? $settings['autoclose'] ?? false ) ? (int) ( $b['autoclose-time'] ?? $settings['autoclose-time'] ?? 0 ) : 0;
		if ( 'behaviour-redirect' === $kind && '' !== $url ) {
			return [ 'type' => 'redirect', 'message' => $message, 'url' => $url, 'autoclose' => 0 ];
		}
		// "Thank you" keeps the form (reset) and "hide" hides it; with a payment the form is always replaced.
		$type = ( 'behaviour-thankyou' === $kind && ! $has_payment ) ? 'message_keep' : 'message';
		return [ 'type' => $type, 'message' => $message, 'url' => '', 'autoclose' => max( 0, min( 600, $auto ) ) ];
	}

	/**
	 * @param array<string, mixed> $s
	 * @param string[]             $warnings
	 * @return array<string, mixed>
	 */
	private static function convert_settings( array $s, array &$warnings ): array {
		$sub   = (string) ( $s['form-substyle'] ?? '' );
		$style = (string) ( $s['form-style'] ?? 'default' );
		$use   = in_array( $sub, [ 'flat', 'material' ], true ) ? $sub : ( in_array( $style, [ 'flat', 'material' ], true ) ? $style : 'default' );
		$out   = [
			'store_entries' => ! array_key_exists( 'store_submissions', $s ) || self::flag( $s['store_submissions'] ),
			'ajax'          => true,
			'style'         => $use,
			'custom_css'    => (string) ( $s['custom_css'] ?? '' ),
		];
		$submit = (array) ( $s['submitData'] ?? [] );
		if ( '' !== trim( (string) ( $submit['custom-submit-text'] ?? '' ) ) ) {
			$out['submit_label'] = (string) $submit['custom-submit-text'];
		}
		$expire = (string) ( $s['form-expire'] ?? 'no_expire' );
		if ( 'date' === $expire && '' !== (string) ( $s['expire_date'] ?? '' ) ) {
			$ts = strtotime( (string) $s['expire_date'] );
			if ( false !== $ts ) {
				$out['expire_at'] = gmdate( 'Y-m-d', $ts ) . ' 23:59';
			}
		} elseif ( in_array( $expire, [ 'submits', 'submission' ], true ) && (int) ( $s['expire_submits'] ?? 0 ) > 0 ) {
			$out['max_entries'] = (int) $s['expire_submits'];
		}
		if ( self::flag( $s['akismet-protection'] ?? false ) ) {
			$warnings[] = 'Akismet non è supportato: il modulo usa l’antispam integrato.';
		}
		return $out;
	}

	// =====================================================================
	// Conversion of a submission (pure)
	// =====================================================================

	/**
	 * @param array<string, array<string, mixed>> $map    From convert_form().
	 * @param array<string, mixed>                $meta   meta_key => value (already unserialized) of the submission.
	 * @param array<string, mixed>                $row    The row of frmt_form_entry (date_created).
	 * @return array{values:array<string,mixed>, files:array<string,array<int,array{path:string,url:string,name:string}>>, payment:array<string,mixed>|null, paid:?bool, created_gmt:string, ip:string}
	 */
	public static function convert_entry( array $map, array $meta, array $row ): array {
		$values  = [];
		$files   = [];
		$payment = null;
		$paid    = null;
		$ip      = '';

		foreach ( $meta as $key => $raw ) {
			$key = (string) $key;
			if ( '_forminator_user_ip' === $key ) {
				$ip = is_scalar( $raw ) ? (string) $raw : '';
				continue;
			}
			if ( 0 === strpos( $key, 'stripe-' ) && is_array( $raw ) ) {
				$status   = strtolower( (string) ( $raw['status'] ?? '' ) );
				$amount   = (float) str_replace( ',', '.', (string) ( $raw['amount'] ?? 0 ) );
				$currency = strtoupper( (string) ( $raw['currency'] ?? '' ) );
				$factor   = Stripe::factor( $currency );
				$payment  = [
					'provider' => 'stripe',
					'status'   => in_array( $status, [ 'succeeded', 'paid', 'success', 'complete', 'completed' ], true ) ? 'paid' : 'failed',
					'amount'   => number_format( $amount, 1 === $factor ? 0 : 2, '.', '' ),
					'minor'    => (int) round( $amount * $factor ),
					'currency' => $currency,
					'livemode' => 'live' === (string) ( $raw['mode'] ?? '' ),
					'intent'   => (string) ( $raw['transaction_id'] ?? '' ),
					'imported' => 'forminator',
				];
				$paid = 'paid' === $payment['status'];
				continue;
			}
			if ( ! isset( $map[ $key ] ) ) {
				continue;
			}
			$m = $map[ $key ];
			switch ( $m['type'] ) {
				case 'upload':
					$files[ $m['id'] ] = self::collect_files( $raw );
					break;

				case 'name':
					if ( is_array( $raw ) ) {
						$first = trim( (string) ( $raw['prefix'] ?? '' ) . ' ' . (string) ( $raw['first-name'] ?? $raw['fname'] ?? '' ) . ' ' . (string) ( $raw['middle-name'] ?? '' ) );
						$last  = (string) ( $raw['last-name'] ?? $raw['lname'] ?? '' );
					} else {
						$first = (string) $raw;
						$last  = '';
					}
					if ( '' !== trim( $first . $last ) ) {
						$values[ $m['id'] ] = [ 'first' => trim( $first ), 'last' => trim( $last ) ];
					}
					break;

				case 'address':
					if ( is_array( $raw ) ) {
						$street = trim( (string) ( $raw['street_address'] ?? '' ) . ' ' . (string) ( $raw['address_line'] ?? '' ) );
						$city   = trim( (string) ( $raw['city'] ?? '' ) . ( '' !== (string) ( $raw['state'] ?? '' ) ? ' (' . $raw['state'] . ')' : '' ) );
						$value  = [ 'street' => $street, 'zip' => (string) ( $raw['zip'] ?? '' ), 'city' => $city, 'country' => (string) ( $raw['country'] ?? '' ) ];
						if ( '' !== implode( '', $value ) ) {
							$values[ $m['id'] ] = $value;
						}
					}
					break;

				case 'checkbox':
					$list  = is_array( $raw ) ? $raw : ( '' === (string) $raw ? [] : [ $raw ] );
					$picks = [];
					foreach ( $list as $item ) {
						$picks[] = self::match_option( $m['options'], (string) $item );
					}
					$picks = array_values( array_filter( $picks, static function ( string $v ): bool { return '' !== $v; } ) );
					if ( $picks ) {
						$values[ $m['id'] ] = $picks;
					}
					break;

				case 'select':
				case 'radio':
					$one = is_array( $raw ) ? (string) reset( $raw ) : (string) $raw;
					if ( '' !== $one ) {
						$values[ $m['id'] ] = self::match_option( $m['options'], $one );
					}
					break;

				case 'calculation':
					$num = is_array( $raw ) ? ( $raw['result'] ?? '' ) : $raw;
					if ( is_numeric( $num ) ) {
						$values[ $m['id'] ] = number_format( (float) $num, (int) $m['decimals'], '.', '' );
					}
					break;

				case 'number':
				case 'currency':
					$clean = str_replace( [ "'", '’', ' ' ], '', (string) ( is_array( $raw ) ? reset( $raw ) : $raw ) );
					$clean = ( false !== strpos( $clean, ',' ) && false === strpos( $clean, '.' ) ) ? str_replace( ',', '.', $clean ) : str_replace( ',', '', $clean );
					if ( is_numeric( $clean ) ) {
						$values[ $m['id'] ] = $clean;
					}
					break;

				case 'date':
					$iso = self::iso_date( (string) ( is_array( $raw ) ? reset( $raw ) : $raw ), (string) $m['date_format'] );
					if ( '' !== $iso ) {
						$values[ $m['id'] ] = $iso;
					}
					break;

				case 'gdpr':
					if ( in_array( strtolower( (string) ( is_array( $raw ) ? reset( $raw ) : $raw ) ), [ 'checked', 'true', '1', 'on', 'yes' ], true ) ) {
						$values[ $m['id'] ] = true;
					}
					break;

				case 'html':
				case 'section':
				case 'page_break':
					break;

				default:
					$text = is_array( $raw ) ? implode( ', ', array_map( 'strval', array_filter( $raw, 'is_scalar' ) ) ) : (string) $raw;
					if ( '' !== trim( $text ) ) {
						$values[ $m['id'] ] = trim( $text );
					}
			}
		}

		$created = (string) ( $row['date_created'] ?? '' );
		$gmt     = '' !== $created && function_exists( 'get_gmt_from_date' ) ? get_gmt_from_date( $created ) : $created;
		return [ 'values' => $values, 'files' => $files, 'payment' => $payment, 'paid' => $paid, 'created_gmt' => $gmt, 'ip' => $ip ];
	}

	/** The stored answer may be an option's value or its label: always return the value. */
	private static function match_option( array $options, string $stored ): string {
		foreach ( $options as $o ) {
			if ( (string) $o['value'] === $stored ) {
				return (string) $o['value'];
			}
		}
		foreach ( $options as $o ) {
			if ( (string) $o['label'] === $stored ) {
				return (string) $o['value'];
			}
		}
		return $stored;
	}

	/** Date as Forminator printed it → YYYY-MM-DD (empty when it cannot be read). */
	public static function iso_date( string $text, string $format ): string {
		$text = trim( $text );
		if ( '' === $text ) {
			return '';
		}
		if ( preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $text, $m ) && checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) ) {
			return $text;
		}
		if ( ! preg_match( '/^(\d{1,4})[\/.\-](\d{1,2})[\/.\-](\d{1,4})$/', $text, $m ) ) {
			return '';
		}
		$format = strtolower( $format );
		// dd/mm/yy, mm/dd/yy, yy/mm/dd (and with . or -): the first letter of the format says the order.
		if ( 0 === strpos( $format, 'yy' ) ) {
			[ $y, $mo, $d ] = [ (int) $m[1], (int) $m[2], (int) $m[3] ];
		} elseif ( 0 === strpos( $format, 'mm' ) ) {
			[ $mo, $d, $y ] = [ (int) $m[1], (int) $m[2], (int) $m[3] ];
		} else {
			[ $d, $mo, $y ] = [ (int) $m[1], (int) $m[2], (int) $m[3] ];
		}
		return checkdate( $mo, $d, $y ) ? sprintf( '%04d-%02d-%02d', $y, $mo, $d ) : '';
	}

	/**
	 * Files of an upload answer. Forminator nests them: ['file' => ['file_path' => ..., 'file_url' => ...]], with lists
	 * when several files were sent.
	 *
	 * @param mixed $raw
	 * @return array<int, array{path:string,url:string,name:string}>
	 */
	private static function collect_files( $raw ): array {
		$paths = [];
		$urls  = [];
		$walk  = static function ( $node ) use ( &$walk, &$paths, &$urls ): void {
			if ( ! is_array( $node ) ) {
				return;
			}
			foreach ( $node as $k => $v ) {
				if ( 'file_path' === $k ) {
					foreach ( (array) $v as $p ) {
						if ( is_string( $p ) && '' !== $p ) {
							$paths[] = $p;
						}
					}
				} elseif ( 'file_url' === $k ) {
					foreach ( (array) $v as $u ) {
						if ( is_string( $u ) && '' !== $u ) {
							$urls[] = $u;
						}
					}
				} elseif ( is_array( $v ) ) {
					$walk( $v );
				}
			}
		};
		$walk( $raw );
		$count = max( count( $paths ), count( $urls ) );
		$out   = [];
		for ( $i = 0; $i < $count; $i++ ) {
			$path  = $paths[ $i ] ?? '';
			$url   = $urls[ $i ] ?? '';
			$name  = basename( '' !== $path ? $path : (string) parse_url( $url, PHP_URL_PATH ) );
			$out[] = [ 'path' => $path, 'url' => $url, 'name' => $name ];
		}
		return $out;
	}

	private static function flag( $v ): bool {
		return in_array( $v, [ true, 1, '1', 'true', 'on', 'yes' ], true );
	}

	/** Plain one-line text (tags removed, entities decoded). */
	private static function plain( string $text ): string {
		return trim( html_entity_decode( strip_tags( $text ), ENT_QUOTES, 'UTF-8' ) );
	}

	// =====================================================================
	// State, analysis and import (database)
	// =====================================================================

	/** @return array<string, mixed> */
	public static function state(): array {
		$s = get_option( self::OPTION, [] );
		$s = is_array( $s ) ? $s : [];
		return array_merge( [ 'forms' => [], 'settings' => [ 'done' => false, 'notes' => [] ], 'started' => 0, 'finished' => 0 ], $s );
	}

	private static function save_state( array $state ): void {
		update_option( self::OPTION, $state, false );
	}

	/** @return array<string, mixed> What conversion needs from the site. */
	public static function context(): array {
		$stripe = (array) get_option( 'forminator_stripe_configuration', [] );
		return [
			'currency'    => '' !== (string) ( $stripe['default_currency'] ?? '' ) ? (string) $stripe['default_currency'] : 'CHF',
			'admin_email' => (string) get_option( 'admin_email' ),
			'home_url'    => (string) home_url(),
			'site_name'   => (string) get_bloginfo( 'name' ),
		];
	}

	/**
	 * Dry run: what would be imported, without touching anything.
	 *
	 * @return array{forms:array<int,array<string,mixed>>, entries:int, stripe:array<string,mixed>, notes:string[]}
	 */
	public static function analyze(): array {
		$state = self::state();
		$ctx   = self::context();
		$forms = [];
		$total = 0;
		foreach ( self::forms() as $form ) {
			$meta = self::form_meta( $form['id'] );
			$conv = null !== $meta ? self::convert_form( $meta, $form['title'], $ctx ) : null;
			$n    = self::entry_count( $form['id'] );
			$total += $n;
			$st   = $state['forms'][ $form['id'] ] ?? null;
			$forms[] = [
				'id'       => $form['id'],
				'title'    => null !== $conv ? (string) $conv['definition']['title'] : $form['title'],
				'status'   => $form['status'],
				'fields'   => null !== $conv ? count( $conv['definition']['fields'] ) : 0,
				'payment'  => null !== $conv && ! empty( $conv['definition']['payment']['enabled'] ),
				'entries'  => $n,
				'warnings' => null !== $conv ? $conv['warnings'] : [ 'Il modulo non ha dati leggibili.' ],
				'twf_id'   => $st ? (int) $st['twf_id'] : 0,
				'imported' => $st ? (int) $st['imported'] : 0,
				'done'     => $st ? ! empty( $st['entries_done'] ) : false,
			];
		}
		$cfg    = (array) get_option( 'forminator_stripe_configuration', [] );
		$stripe = [
			'test' => '' !== (string) ( $cfg['test_key'] ?? '' ),
			'live' => '' !== (string) ( $cfg['live_key'] ?? '' ),
		];
		$notes = [];
		if ( '' !== (string) get_option( 'forminator_captcha_key', '' ) || '' !== (string) get_option( 'forminator_v3_captcha_key', '' ) || '' !== (string) get_option( 'forminator_hcaptcha_key', '' ) ) {
			$notes[] = 'Forminator ha un captcha configurato (reCAPTCHA/hCaptcha): nei moduli importati lo sostituisce l’antispam integrato; il captcha arriverà in una prossima versione.';
		}
		return [ 'forms' => $forms, 'entries' => $total, 'stripe' => $stripe, 'notes' => $notes ];
	}

	/**
	 * Creates the forms that are not imported yet.
	 *
	 * @return array{created:int, existing:int, forms:array<int,array<string,mixed>>}
	 */
	public static function import_forms(): array {
		$state    = self::state();
		$ctx      = self::context();
		$created  = 0;
		$existing = 0;
		if ( 0 === (int) $state['started'] ) {
			$state['started'] = time();
		}
		foreach ( self::forms() as $form ) {
			$fid = $form['id'];
			$st  = $state['forms'][ $fid ] ?? null;
			if ( $st && get_post( (int) $st['twf_id'] ) ) {
				++$existing;
				continue;
			}
			$meta = self::form_meta( $fid );
			if ( null === $meta ) {
				continue;
			}
			$conv = self::convert_form( $meta, $form['title'], $ctx );
			$id   = Builder::save_form( 0, $conv['definition'], (string) $conv['definition']['title'] );
			if ( is_wp_error( $id ) ) {
				$state['forms'][ $fid ] = [ 'twf_id' => 0, 'error' => $id->get_error_message(), 'warnings' => $conv['warnings'], 'imported' => 0, 'skipped' => 0, 'cursor' => 0, 'entries_done' => true, 'files_copied' => 0, 'files_missing' => 0, 'title' => $form['title'], 'stripe_mode' => '' ];
				continue;
			}
			if ( 'publish' !== $form['status'] ) {
				wp_update_post( [ 'ID' => (int) $id, 'post_status' => 'draft' ] );
			}
			update_post_meta( (int) $id, self::SOURCE, 'forminator:' . $fid );
			$state['forms'][ $fid ] = [
				'twf_id'        => (int) $id,
				'title'         => (string) $conv['definition']['title'],
				'warnings'      => $conv['warnings'],
				'stripe_mode'   => $conv['stripe_mode'],
				'cursor'        => 0,
				'imported'      => 0,
				'skipped'       => 0,
				'files_copied'  => 0,
				'files_missing' => 0,
				'entries_total' => self::entry_count( $fid ),
				'entries_done'  => 0 === self::entry_count( $fid ),
			];
			++$created;
		}
		self::save_state( $state );
		return [ 'created' => $created, 'existing' => $existing, 'forms' => $state['forms'] ];
	}

	/**
	 * Copies the next submissions of a form. Safe to call again and again: it continues from the last one copied.
	 *
	 * @return array{done:bool, imported:int, total:int, copied_now:int}
	 */
	public static function import_entries_batch( int $fid, int $limit = self::BATCH ): array {
		global $wpdb;
		$state = self::state();
		$st    = $state['forms'][ $fid ] ?? null;
		if ( ! $st || empty( $st['twf_id'] ) || ! self::tables_exist() ) {
			return [ 'done' => true, 'imported' => 0, 'total' => 0, 'copied_now' => 0 ];
		}
		$form = Builder::get_form( (int) $st['twf_id'] );
		$meta = self::form_meta( $fid );
		if ( ! $form || null === $meta ) {
			return [ 'done' => true, 'imported' => (int) $st['imported'], 'total' => (int) ( $st['entries_total'] ?? 0 ), 'copied_now' => 0 ];
		}
		$conv = self::convert_form( $meta, '', self::context() );
		// Entries reference our field ids and the final (normalised) options.
		$ours_by_id = Definition::field_map( $form['definition'] );
		foreach ( $conv['map'] as $k => $m ) {
			$ours = $ours_by_id[ $m['id'] ] ?? null;
			if ( $ours && isset( $ours['options'] ) ) {
				$conv['map'][ $k ]['options'] = $ours['options'];
			}
		}

		$t  = self::entries_table();
		$tm = self::meta_table();
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE form_id = %d AND is_spam = 0 AND status = 'active' AND entry_id > %d ORDER BY entry_id ASC LIMIT %d", $fid, (int) $st['cursor'], max( 1, $limit ) ), ARRAY_A );
		$ids  = array_map( 'intval', array_column( (array) $rows, 'entry_id' ) );
		$metas = [];
		if ( $ids ) {
			$in = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
			foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT entry_id, meta_key, meta_value FROM {$tm} WHERE entry_id IN ({$in})", $ids ), ARRAY_A ) as $m ) {
				$metas[ (int) $m['entry_id'] ][ (string) $m['meta_key'] ] = maybe_unserialize( $m['meta_value'] );
			}
		}

		$copied_now = 0;
		foreach ( (array) $rows as $row ) {
			$entry_id = (int) $row['entry_id'];
			$conv_e   = self::convert_entry( $conv['map'], $metas[ $entry_id ] ?? [], $row );
			$values   = $conv_e['values'];
			$stored   = [];
			$all      = [];
			foreach ( $conv_e['files'] as $field_id => $list ) {
				foreach ( $list as $file ) {
					$source = $file['path'];
					if ( '' === $source && '' !== $file['url'] ) {
						$source = self::path_from_url( $file['url'] );
					}
					$desc = '' !== $source ? Uploads::import_existing( $source, $file['name'] ) : null;
					if ( null === $desc ) {
						++$st['files_missing'];
						continue;
					}
					$stored[ $field_id ][] = $desc;
					$all[]                 = $desc;
					++$st['files_copied'];
					++$copied_now;
				}
			}
			foreach ( $stored as $field_id => $list ) {
				$values[ $field_id ] = $list;
			}

			$payment = $conv_e['payment'];
			$status  = Entries::STATUS_READ; // imported submissions are not "new": nobody has to read them again.
			if ( null !== $payment ) {
				$status = true === $conv_e['paid'] ? Entries::STATUS_PAID : Entries::STATUS_PAYMENT_FAILED;
			}
			$new_id = Entries::create( [
				'form_id'     => (int) $st['twf_id'],
				'status'      => $status,
				'lang'        => '',
				'created_gmt' => $conv_e['created_gmt'],
				'data'        => $values,
				'display'     => Entries::snapshot( $form['definition'], $values ),
				'files'       => $all,
				'payment'     => $payment ?? new \stdClass(),
				'ip_hash'     => '' !== $conv_e['ip'] ? hash_hmac( 'sha256', $conv_e['ip'], wp_salt( 'auth' ) ) : '',
			] );
			if ( $new_id > 0 ) {
				++$st['imported'];
			} else {
				++$st['skipped'];
				Uploads::delete_files( $all );
			}
			$st['cursor'] = $entry_id;
		}

		$st['entries_done'] = count( (array) $rows ) < max( 1, $limit );
		$state['forms'][ $fid ] = $st;
		if ( $st['entries_done'] && self::all_done( $state ) ) {
			$state['finished'] = time();
		}
		self::save_state( $state );
		return [ 'done' => (bool) $st['entries_done'], 'imported' => (int) $st['imported'], 'total' => (int) ( $st['entries_total'] ?? 0 ), 'copied_now' => $copied_now ];
	}

	private static function all_done( array $state ): bool {
		foreach ( (array) $state['forms'] as $f ) {
			if ( empty( $f['entries_done'] ) ) {
				return false;
			}
		}
		return true;
	}

	/** Absolute path of a file given by its public URL, when it lives in the uploads folder. */
	private static function path_from_url( string $url ): string {
		$up   = wp_upload_dir();
		$base = (string) $up['baseurl'];
		if ( '' === $base || 0 !== strpos( $url, $base ) ) {
			return '';
		}
		return (string) $up['basedir'] . rawurldecode( substr( $url, strlen( $base ) ) );
	}

	/**
	 * Carries over Stripe keys into EMPTY slots (never overwrites) and reports what else was found.
	 *
	 * @return array{notes:string[], imported:string[]}
	 */
	public static function import_settings(): array {
		$state    = self::state();
		$notes    = [];
		$imported = [];
		$cfg      = (array) get_option( 'forminator_stripe_configuration', [] );
		$keys     = [ 'test' => [ 'publishable' => (string) ( $cfg['test_key'] ?? '' ), 'secret' => '' ], 'live' => [ 'publishable' => (string) ( $cfg['live_key'] ?? '' ), 'secret' => '' ] ];

		// Secrets are stored encrypted by Forminator: only Forminator itself can read them (it must be active).
		if ( class_exists( '\Forminator_Gateway_Stripe' ) && ( '' !== $keys['test']['publishable'] || '' !== $keys['live']['publishable'] ) ) {
			try {
				$gw = new \Forminator_Gateway_Stripe();
				$keys['test']['secret'] = (string) $gw->get_test_secret( true );
				$keys['live']['secret'] = (string) $gw->get_live_secret( true );
			} catch ( \Throwable $e ) {
				$notes[] = 'Non sono riuscito a leggere le chiavi segrete di Stripe da Forminator: inseriscile in Pagamenti.';
			}
		} elseif ( '' !== $keys['test']['publishable'] . $keys['live']['publishable'] ) {
			$notes[] = 'Forminator non è attivo: le chiavi segrete di Stripe sono cifrate e non si possono leggere. Attiva Forminator e ripeti, oppure inseriscile in Pagamenti.';
		}

		$stored = Stripe::stored();
		foreach ( [ 'test', 'live' ] as $mode ) {
			foreach ( [ 'publishable', 'secret' ] as $k ) {
				$value = trim( $keys[ $mode ][ $k ] );
				if ( '' === $value || '' !== $stored[ $mode ][ $k ] ) {
					continue;
				}
				if ( Stripe::key_is_valid( $mode, $k, $value ) ) {
					$stored[ $mode ][ $k ] = $value;
					$imported[]            = ( 'test' === $mode ? 'prova' : 'reale' ) . ' · ' . ( 'publishable' === $k ? 'chiave pubblica' : 'chiave segreta' ) . ' (…' . substr( $value, -4 ) . ')';
				}
			}
		}
		if ( $imported ) {
			update_option( Stripe::OPTION, $stored, false );
		}

		$live_forms = 0;
		foreach ( (array) $state['forms'] as $f ) {
			if ( 'live' === (string) ( $f['stripe_mode'] ?? '' ) ) {
				++$live_forms;
			}
		}
		if ( $live_forms > 0 ) {
			$notes[] = sprintf( '%d moduli usavano Stripe in modalità reale. In Pagamenti la modalità resta quella attuale (%s): provala con le chiavi di prova e passa a Reale quando sei pronto. Ricorda anche di creare il webhook su Stripe.', $live_forms, 'live' === Stripe::selected_mode() ? 'reale' : 'prova' );
		}
		if ( '' !== (string) get_option( 'forminator_captcha_key', '' ) || '' !== (string) get_option( 'forminator_v3_captcha_key', '' ) || '' !== (string) get_option( 'forminator_hcaptcha_key', '' ) ) {
			$notes[] = 'Il captcha di Forminator non è stato importato: i moduli usano l’antispam integrato.';
		}
		if ( ! empty( get_option( 'forminator_form_privacy_settings', [] ) ) ) {
			$notes[] = 'Le impostazioni privacy di Forminator (conservazione delle compilazioni) non sono state importate: imposta i giorni di conservazione in ogni modulo.';
		}

		$state['settings'] = [ 'done' => true, 'notes' => $notes, 'imported' => $imported ];
		self::save_state( $state );
		return [ 'notes' => $notes, 'imported' => $imported ];
	}

	/**
	 * Removes everything this import created: the imported forms with their submissions and files.
	 * Forminator's data, Stripe keys and every other form are left alone.
	 *
	 * @return array{forms:int, entries:int}
	 */
	public static function undo(): array {
		global $wpdb;
		$state   = self::state();
		$forms   = 0;
		$entries = 0;
		foreach ( (array) $state['forms'] as $st ) {
			$twf = (int) ( $st['twf_id'] ?? 0 );
			if ( $twf <= 0 || ! get_post( $twf ) || ! get_post_meta( $twf, self::SOURCE, true ) ) {
				continue; // only forms that really came from the import.
			}
			do {
				$ids = $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM ' . Entries::table() . ' WHERE form_id = %d LIMIT 500', $twf ) );
				$gone     = Entries::delete( array_map( 'intval', (array) $ids ) );
				$entries += $gone;
			} while ( $ids && $gone > 0 );
			wp_delete_post( $twf, true );
			++$forms;
		}
		delete_option( self::OPTION );
		return [ 'forms' => $forms, 'entries' => $entries ];
	}

	/**
	 * Pages and posts that still show a Forminator form, with the new shortcode when the form was imported.
	 *
	 * @return array<int, array{id:int,title:string,url:string,kind:string,forms:array<int,array{old:int,new:string}>}>
	 */
	public static function pages_using(): array {
		global $wpdb;
		$state = self::state();
		$out   = [];
		$rows  = $wpdb->get_results( "SELECT ID, post_title, post_content, post_type FROM {$wpdb->posts} WHERE post_status IN ('publish','draft','private','pending') AND post_type NOT IN ('revision','forminator_forms','twf_form','nav_menu_item') AND ( post_content LIKE '%forminator_form%' OR post_content LIKE '%wp:forminator/forms%' ) LIMIT 200", ARRAY_A );
		foreach ( (array) $rows as $r ) {
			$found = [];
			if ( preg_match_all( '/\[forminator_form[^\]]*?\bid=["\']?(\d+)/i', (string) $r['post_content'], $m ) ) {
				$found = array_merge( $found, array_map( 'intval', $m[1] ) );
			}
			if ( preg_match_all( '/wp:forminator\/forms\s*\{[^}]*"module_id"\s*:\s*"?(\d+)/i', (string) $r['post_content'], $m2 ) ) {
				$found = array_merge( $found, array_map( 'intval', $m2[1] ) );
			}
			$forms = [];
			foreach ( array_unique( $found ) as $old ) {
				$twf     = (int) ( $state['forms'][ $old ]['twf_id'] ?? 0 );
				$forms[] = [ 'old' => $old, 'new' => $twf > 0 ? '[tw_form id="' . $twf . '"]' : '' ];
			}
			$out[] = [ 'id' => (int) $r['ID'], 'title' => (string) $r['post_title'], 'url' => (string) get_edit_post_link( (int) $r['ID'], 'raw' ), 'kind' => (string) $r['post_type'], 'forms' => $forms ];
		}
		$elementor = $wpdb->get_results( "SELECT p.ID, p.post_title, p.post_type FROM {$wpdb->postmeta} m JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE m.meta_key = '_elementor_data' AND m.meta_value LIKE '%forminator%' AND p.post_status IN ('publish','draft','private') LIMIT 100", ARRAY_A );
		foreach ( (array) $elementor as $r ) {
			$known = false;
			foreach ( $out as $i => $row ) {
				if ( $row['id'] === (int) $r['ID'] ) {
					$out[ $i ]['kind'] .= ' + elementor'; // same page: it also has the widget.
					$known              = true;
					break;
				}
			}
			if ( ! $known ) {
				$out[] = [ 'id' => (int) $r['ID'], 'title' => (string) $r['post_title'], 'url' => (string) get_edit_post_link( (int) $r['ID'], 'raw' ), 'kind' => 'elementor', 'forms' => [] ];
			}
		}
		return $out;
	}
}
