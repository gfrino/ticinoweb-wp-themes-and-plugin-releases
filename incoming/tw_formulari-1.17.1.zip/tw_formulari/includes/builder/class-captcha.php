<?php
/**
 * Anti-spam with the reCAPTCHA v3 of the site's CMS (ticinoWEB AI theme: ticinoWEB CMS → reCAPTCHA).
 *
 * The keys and the minimum score are the CMS's: they are typed once, there, and used here. A form turns it on in
 * its "Protezione dallo spam" card ("captcha" = "recaptcha"). Without keys the protection is simply not applied
 * (the form still has the hidden trap field, the minimum time and the rate limit) and the editor says so.
 *
 * @package TicinoWeb\TWFormulari\Builder
 */

namespace TicinoWeb\TWFormulari\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Captcha {

	public const FIELD  = 'twf_recaptcha';
	public const ACTION = 'twf_submit';

	public static function init(): void {
		add_filter( 'twf_captcha_valid', [ self::class, 'filter_valid' ], 10, 3 );
	}

	/** Site key of the CMS (public); empty when not set. */
	public static function site_key(): string {
		return trim( (string) apply_filters( 'twf_recaptcha_site_key', get_option( 'ticinoweb_recaptcha_site_key', '' ) ) );
	}

	private static function secret(): string {
		return trim( (string) get_option( 'ticinoweb_recaptcha_secret_key', '' ) );
	}

	/** Both keys are there: the protection can work. */
	public static function available(): bool {
		return '' !== self::site_key() && '' !== self::secret();
	}

	/**
	 * @param array<string, mixed> $def Normalised definition.
	 */
	public static function enabled( array $def ): bool {
		return 'recaptcha' === (string) ( $def['settings']['captcha'] ?? 'none' ) && self::available();
	}

	/** Where the keys are set (shown in the editor). */
	public static function settings_url(): string {
		return admin_url( 'admin.php?page=ticinoweb-cms#recaptcha' );
	}

	/**
	 * @param bool                 $valid
	 * @param array<string, mixed> $def
	 * @param array<string, mixed> $post
	 */
	public static function filter_valid( $valid, $def, $post ) {
		if ( ! $valid || ! is_array( $def ) || ! self::enabled( $def ) ) {
			return $valid;
		}
		$token = isset( $post[ self::FIELD ] ) && is_scalar( $post[ self::FIELD ] ) ? trim( (string) $post[ self::FIELD ] ) : '';
		if ( '' === $token || strlen( $token ) > 4000 ) {
			return false;
		}
		return self::verify( $token );
	}

	/** Verifies the token with the CMS's own function (same keys and threshold); a direct call when the CMS is not there. */
	private static function verify( string $token ): bool {
		if ( function_exists( 'ticinoweb_verify_recaptcha' ) ) {
			$r = ticinoweb_verify_recaptcha( $token );
			return is_array( $r ) && ! empty( $r['success'] );
		}
		$res = wp_remote_post( 'https://www.google.com/recaptcha/api/siteverify', [ 'timeout' => 10, 'body' => [ 'secret' => self::secret(), 'response' => $token ] ] );
		if ( is_wp_error( $res ) ) {
			return false;
		}
		$body = json_decode( (string) wp_remote_retrieve_body( $res ), true );
		if ( ! is_array( $body ) || empty( $body['success'] ) ) {
			return false;
		}
		return (float) ( $body['score'] ?? 0 ) >= (float) get_option( 'ticinoweb_recaptcha_threshold', 0.5 );
	}
}
