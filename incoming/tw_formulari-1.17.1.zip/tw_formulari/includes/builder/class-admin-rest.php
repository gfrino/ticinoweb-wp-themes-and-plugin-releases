<?php
/**
 * Back-office endpoints used by the visual editor (administrators only): load, save, duplicate and preview.
 *
 * The preview is rendered by the very same code that draws the form on the site, so what the editor sees is what the
 * visitor gets. Every definition is normalised on the server before it is stored or shown back.
 *
 * @package TicinoWeb\TWFormulari\Builder
 */

namespace TicinoWeb\TWFormulari\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdminRest {

	public static function init(): void {
		add_action( 'rest_api_init', [ self::class, 'register_routes' ] );
	}

	public static function register_routes(): void {
		$permission = [ self::class, 'can_edit' ];

		register_rest_route( Builder::REST_NS, '/admin/forms', [
			'methods'             => 'POST',
			'permission_callback' => $permission,
			'callback'            => [ self::class, 'save' ],
		] );
		register_rest_route( Builder::REST_NS, '/admin/forms/(?P<id>\d+)', [
			'methods'             => 'GET',
			'permission_callback' => $permission,
			'callback'            => [ self::class, 'get' ],
		] );
		register_rest_route( Builder::REST_NS, '/admin/forms/(?P<id>\d+)/duplicate', [
			'methods'             => 'POST',
			'permission_callback' => $permission,
			'callback'            => [ self::class, 'duplicate' ],
		] );
		register_rest_route( Builder::REST_NS, '/admin/preview', [
			'methods'             => 'POST',
			'permission_callback' => $permission,
			'callback'            => [ self::class, 'preview' ],
		] );
	}

	public static function can_edit(): bool {
		return current_user_can( 'manage_options' );
	}

	/**
	 * @param \WP_REST_Request $request Body: id (0 for a new form), title, definition.
	 */
	public static function save( $request ) {
		$id         = absint( $request->get_param( 'id' ) );
		$definition = $request->get_param( 'definition' );
		$title      = (string) $request->get_param( 'title' );
		if ( ! is_array( $definition ) ) {
			return new \WP_Error( 'twf_bad_definition', __( 'La struttura del modulo non è valida.', 'tw-formulari' ), [ 'status' => 400 ] );
		}
		$saved = Builder::save_form( $id, $definition, $title );
		if ( is_wp_error( $saved ) ) {
			$saved->add_data( [ 'status' => 400 ] );
			return $saved;
		}
		return self::payload( (int) $saved );
	}

	/**
	 * @param \WP_REST_Request $request
	 */
	public static function get( $request ) {
		$form = Builder::get_form( (int) $request['id'] );
		if ( ! $form ) {
			return new \WP_Error( 'twf_not_found', __( 'Modulo non trovato.', 'tw-formulari' ), [ 'status' => 404 ] );
		}
		return self::payload( $form['id'] );
	}

	/**
	 * @param \WP_REST_Request $request
	 */
	public static function duplicate( $request ) {
		$form = Builder::get_form( (int) $request['id'] );
		if ( ! $form ) {
			return new \WP_Error( 'twf_not_found', __( 'Modulo non trovato.', 'tw-formulari' ), [ 'status' => 404 ] );
		}
		/* translators: %s: title of the form that was copied */
		$title = sprintf( __( '%s (copia)', 'tw-formulari' ), $form['title'] );
		$new   = Builder::save_form( 0, $form['definition'], $title );
		if ( is_wp_error( $new ) ) {
			$new->add_data( [ 'status' => 400 ] );
			return $new;
		}
		return self::payload( (int) $new );
	}

	/**
	 * @param \WP_REST_Request $request Body: definition (not yet saved).
	 */
	public static function preview( $request ) {
		$definition = $request->get_param( 'definition' );
		if ( ! is_array( $definition ) ) {
			return new \WP_Error( 'twf_bad_definition', __( 'La struttura del modulo non è valida.', 'tw-formulari' ), [ 'status' => 400 ] );
		}
		$def = Definition::normalize( $definition );
		return [
			'html'       => Renderer::render( absint( $request->get_param( 'id' ) ), $def, [ 'preview' => true ] ),
			'definition' => $def,
		];
	}

	/**
	 * @return array<string, mixed>
	 */
	private static function payload( int $id ): array {
		$form = Builder::get_form( $id );
		return [
			'id'         => $id,
			'title'      => $form ? $form['title'] : '',
			'shortcode'  => '[tw_form id="' . $id . '"]',
			'definition' => $form ? $form['definition'] : Definition::defaults(),
		];
	}
}
