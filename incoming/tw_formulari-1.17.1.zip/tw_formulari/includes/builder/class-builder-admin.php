<?php
/**
 * Admin screens of the form builder: list of forms, choice of a starting template, and the shell that hosts the
 * visual editor (assets/builder/admin-editor.js). Saving from the editor goes through AdminRest; creating from a
 * template, duplicating and deleting are plain admin-post actions protected by a nonce.
 *
 * @package TicinoWeb\TWFormulari\Builder
 */

namespace TicinoWeb\TWFormulari\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BuilderAdmin {

	public const PAGE = 'tw-formulari-forms';

	public static function init(): void {
		add_action( 'admin_menu', [ self::class, 'register_menu' ], 20 );
		add_action( 'admin_enqueue_scripts', [ self::class, 'enqueue' ] );
		add_action( 'admin_post_twf_form_create', [ self::class, 'handle_create' ] );
		add_action( 'admin_post_twf_form_duplicate', [ self::class, 'handle_duplicate' ] );
		add_action( 'admin_post_twf_form_delete', [ self::class, 'handle_delete' ] );
	}

	public static function register_menu(): void {
		add_submenu_page( 'tw-formulari', __( 'Moduli', 'tw-formulari' ), __( 'Moduli', 'tw-formulari' ), 'manage_options', self::PAGE, [ self::class, 'render' ] );
	}

	public static function list_url( array $args = [] ): string {
		return add_query_arg( $args, admin_url( 'admin.php?page=' . self::PAGE ) );
	}

	public static function edit_url( int $id ): string {
		return self::list_url( [ 'form' => $id ] );
	}

	/** True on the editor screen (used to load its assets only there). */
	private static function is_editor_screen(): bool {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only screen selection.
		return isset( $_GET['page'], $_GET['form'] ) && self::PAGE === sanitize_key( wp_unslash( $_GET['page'] ) ) && absint( wp_unslash( $_GET['form'] ) ) > 0;
	}

	/**
	 * @param string $hook Current admin page hook.
	 */
	public static function enqueue( string $hook ): void {
		// Forms, submissions ("Compilazioni": status badges, refund panel) and payments share the same stylesheet.
		if ( false === strpos( $hook, self::PAGE ) && false === strpos( $hook, EntriesAdmin::PAGE ) && false === strpos( $hook, PaymentsAdmin::PAGE ) ) {
			return;
		}
		wp_enqueue_style( 'twf-builder-admin', TW_FORMULARI_URL . 'assets/builder/admin-editor.css', [], \TicinoWeb\TWFormulari\twf_asset_ver( 'assets/builder/admin-editor.css' ) );
		if ( ! self::is_editor_screen() ) {
			return;
		}
		// Libreria media: per scegliere la foto del buono regalo.
		wp_enqueue_media();
		wp_enqueue_script( 'twf-builder-editor', TW_FORMULARI_URL . 'assets/builder/admin-editor.js', [], \TicinoWeb\TWFormulari\twf_asset_ver( 'assets/builder/admin-editor.js' ), true );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$form = Builder::get_form( absint( wp_unslash( $_GET['form'] ) ) );
		if ( ! $form ) {
			return;
		}
		wp_add_inline_script( 'twf-builder-editor', 'window.TWF_EDITOR = ' . wp_json_encode( self::editor_data( $form ), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP ) . ';', 'before' );
	}

	/**
	 * Everything the editor needs, in one object.
	 *
	 * @param array{id:int,title:string,status:string,definition:array<string,mixed>} $form
	 * @return array<string, mixed>
	 */
	private static function editor_data( array $form ): array {
		$operators = [
			'is'           => __( 'è uguale a', 'tw-formulari' ),
			'is_not'       => __( 'è diverso da', 'tw-formulari' ),
			'contains'     => __( 'contiene', 'tw-formulari' ),
			'not_contains' => __( 'non contiene', 'tw-formulari' ),
			'starts'       => __( 'inizia con', 'tw-formulari' ),
			'ends'         => __( 'finisce con', 'tw-formulari' ),
			'gt'           => __( 'è maggiore di', 'tw-formulari' ),
			'lt'           => __( 'è minore di', 'tw-formulari' ),
			'empty'        => __( 'è vuoto', 'tw-formulari' ),
			'not_empty'    => __( 'non è vuoto', 'tw-formulari' ),
		];
		return [
			'id'         => $form['id'],
			'title'      => $form['title'],
			'definition' => $form['definition'],
			'shortcode'  => '[tw_form id="' . $form['id'] . '"]',
			'listUrl'    => self::list_url(),
			'entriesUrl' => EntriesAdmin::list_url( [ 'form' => $form['id'] ] ),
			'rest'       => [ 'base' => esc_url_raw( rest_url( Builder::REST_NS . '/admin/' ) ), 'nonce' => wp_create_nonce( 'wp_rest' ) ],
			'preview'    => [
				'css' => TW_FORMULARI_URL . 'assets/builder/frontend.css?ver=' . \TicinoWeb\TWFormulari\twf_asset_ver( 'assets/builder/frontend.css' ),
				'js'  => TW_FORMULARI_URL . 'assets/builder/frontend.js?ver=' . \TicinoWeb\TWFormulari\twf_asset_ver( 'assets/builder/frontend.js' ),
			],
			'features'   => [ 'pdf' => \TicinoWeb\TWFormulari\Features::enabled( 'pdf' ), 'payments' => \TicinoWeb\TWFormulari\Features::enabled( 'payments' ), 'url' => \TicinoWeb\TWFormulari\Admin::tab_url( 'features' ) ],
			'methods'    => [ 'list' => PaymentMethods::for_editor(), 'url' => PaymentsAdmin::url() . '#twf-methods' ],
			'captcha'    => [ 'available' => Captcha::available(), 'url' => Captcha::settings_url() ],
			'stripe'     => [ 'configured' => Stripe::is_configured(), 'mode' => Stripe::mode(), 'url' => PaymentsAdmin::url() ],
			'pdfImage'   => (string) wp_get_attachment_image_url( (int) ( $form['definition']['settings']['pdf_image'] ?? 0 ), 'medium' ),
			'types'      => FieldTypes::labels(),
			'operators'  => $operators,
			'extensions' => array_values( array_diff( [ 'pdf', 'jpg', 'jpeg', 'png', 'gif', 'webp', 'doc', 'docx', 'xls', 'xlsx', 'odt', 'ods', 'txt', 'csv', 'zip' ], Definition::FORBIDDEN_EXTENSIONS ) ),
			'i18n'       => [],
		];
	}

	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Non hai il permesso di vedere questa pagina.', 'tw-formulari' ) );
		}
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only screen selection.
		$edit = isset( $_GET['form'] ) ? absint( wp_unslash( $_GET['form'] ) ) : 0;
		$new  = isset( $_GET['new'] );
		// phpcs:enable

		echo '<div class="wrap twf-wrap">';
		if ( $edit > 0 ) {
			self::render_editor_shell( $edit );
		} elseif ( $new ) {
			self::render_templates();
		} else {
			self::render_list();
		}
		echo '</div>';
	}

	private static function render_editor_shell( int $id ): void {
		if ( ! Builder::get_form( $id ) ) {
			echo '<h1>' . esc_html__( 'Moduli', 'tw-formulari' ) . '</h1><p>' . esc_html__( 'Modulo non trovato.', 'tw-formulari' ) . ' <a href="' . esc_url( self::list_url() ) . '">' . esc_html__( 'Torna all’elenco', 'tw-formulari' ) . '</a></p>';
			return;
		}
		echo '<div id="twf-editor" class="twf-editor"><p class="twf-loading">' . esc_html__( 'Caricamento dell’editor…', 'tw-formulari' ) . '</p>'
			. '<noscript>' . esc_html__( 'L’editor dei moduli richiede JavaScript.', 'tw-formulari' ) . '</noscript></div>';
	}

	private static function notices(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- display of a result message only.
		if ( isset( $_GET['deleted'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Modulo eliminato.', 'tw-formulari' ) . '</p></div>';
		}
		if ( isset( $_GET['error'] ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['error'] ) ) ) . '</p></div>';
		}
		// phpcs:enable
	}

	private static function render_list(): void {
		$forms = get_posts( [ 'post_type' => Builder::POST_TYPE, 'post_status' => 'any', 'numberposts' => 200, 'orderby' => 'date', 'order' => 'DESC' ] );
		echo '<h1 class="wp-heading-inline">' . esc_html__( 'Moduli', 'tw-formulari' ) . '</h1> <a class="page-title-action" href="' . esc_url( self::list_url( [ 'new' => 1 ] ) ) . '">' . esc_html__( 'Nuovo modulo', 'tw-formulari' ) . '</a><hr class="wp-header-end">';
		self::notices();

		if ( ! $forms ) {
			echo '<div class="twf-empty"><h2>' . esc_html__( 'Non hai ancora nessun modulo', 'tw-formulari' ) . '</h2><p>' . esc_html__( 'Crea il primo partendo da un modello: poi cambi campi, testi e e-mail a tuo piacimento.', 'tw-formulari' ) . '</p><p><a class="button button-primary button-hero" href="' . esc_url( self::list_url( [ 'new' => 1 ] ) ) . '">' . esc_html__( 'Crea il primo modulo', 'tw-formulari' ) . '</a></p></div>';
			return;
		}

		echo '<table class="widefat striped twf-list"><thead><tr><th>' . esc_html__( 'Modulo', 'tw-formulari' ) . '</th><th>' . esc_html__( 'Da incollare nella pagina', 'tw-formulari' ) . '</th><th>' . esc_html__( 'Compilazioni', 'tw-formulari' ) . '</th><th>' . esc_html__( 'Azioni', 'tw-formulari' ) . '</th></tr></thead><tbody>';
		foreach ( $forms as $post ) {
			$id    = (int) $post->ID;
			$count = Entries::count( $id );
			echo '<tr><td><strong><a href="' . esc_url( self::edit_url( $id ) ) . '">' . esc_html( $post->post_title ) . '</a></strong></td>'
				. '<td><code class="twf-shortcode">[tw_form id="' . $id . '"]</code></td>'
				. '<td>' . ( $count > 0 ? '<a href="' . esc_url( EntriesAdmin::list_url( [ 'form' => $id ] ) ) . '">' . (int) $count . '</a>' : '0' ) . '</td>'
				. '<td><a href="' . esc_url( self::edit_url( $id ) ) . '">' . esc_html__( 'Modifica', 'tw-formulari' ) . '</a> · '
				. '<a href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=twf_form_duplicate&form=' . $id ), 'twf_form_duplicate_' . $id ) ) . '">' . esc_html__( 'Duplica', 'tw-formulari' ) . '</a> · '
				. '<a href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=twf_form_delete&form=' . $id ), 'twf_form_delete_' . $id ) ) . '" class="twf-delete" data-confirm="' . esc_attr( sprintf(
					/* translators: %d: number of entries that will be deleted */
					__( 'Eliminare il modulo e le sue %d compilazioni? L’operazione non si può annullare.', 'tw-formulari' ),
					$count
				) ) . '" onclick="return confirm(this.dataset.confirm)">' . esc_html__( 'Elimina', 'tw-formulari' ) . '</a></td></tr>';
		}
		echo '</tbody></table>';
	}

	private static function render_templates(): void {
		echo '<h1>' . esc_html__( 'Nuovo modulo', 'tw-formulari' ) . '</h1>';
		self::notices();
		echo '<p>' . esc_html__( 'Scegli da dove partire. Potrai cambiare tutto dopo.', 'tw-formulari' ) . '</p><div class="twf-templates">';
		foreach ( Templates::catalog() as $key => $item ) {
			$url = wp_nonce_url( admin_url( 'admin-post.php?action=twf_form_create&template=' . rawurlencode( $key ) ), 'twf_form_create' );
			echo '<a class="twf-template" href="' . esc_url( $url ) . '"><strong>' . esc_html( $item['label'] ) . '</strong><span>' . esc_html( $item['description'] ) . '</span></a>';
		}
		echo '</div><p><a href="' . esc_url( self::list_url() ) . '">' . esc_html__( 'Torna all’elenco', 'tw-formulari' ) . '</a></p>';
	}

	public static function handle_create(): void {
		self::guard( 'twf_form_create' );
		$key      = isset( $_GET['template'] ) ? sanitize_key( wp_unslash( $_GET['template'] ) ) : 'blank';
		$catalog  = Templates::catalog();
		$key      = isset( $catalog[ $key ] ) ? $key : 'blank';
		$title    = 'blank' === $key ? __( 'Nuovo modulo', 'tw-formulari' ) : $catalog[ $key ]['label'];
		$id       = Builder::save_form( 0, Templates::get( $key ), $title );
		if ( is_wp_error( $id ) ) {
			wp_safe_redirect( self::list_url( [ 'error' => rawurlencode( $id->get_error_message() ) ] ) );
			exit;
		}
		wp_safe_redirect( self::edit_url( (int) $id ) );
		exit;
	}

	public static function handle_duplicate(): void {
		$id = isset( $_GET['form'] ) ? absint( wp_unslash( $_GET['form'] ) ) : 0;
		self::guard( 'twf_form_duplicate_' . $id );
		$form = $id ? Builder::get_form( $id ) : null;
		if ( ! $form ) {
			wp_safe_redirect( self::list_url( [ 'error' => rawurlencode( __( 'Modulo non trovato.', 'tw-formulari' ) ) ] ) );
			exit;
		}
		/* translators: %s: title of the form that was copied */
		$new = Builder::save_form( 0, $form['definition'], sprintf( __( '%s (copia)', 'tw-formulari' ), $form['title'] ) );
		wp_safe_redirect( is_wp_error( $new ) ? self::list_url( [ 'error' => rawurlencode( $new->get_error_message() ) ] ) : self::edit_url( (int) $new ) );
		exit;
	}

	public static function handle_delete(): void {
		$id = isset( $_GET['form'] ) ? absint( wp_unslash( $_GET['form'] ) ) : 0;
		self::guard( 'twf_form_delete_' . $id );
		$post = $id ? get_post( $id ) : null;
		if ( $post && Builder::POST_TYPE === $post->post_type ) {
			global $wpdb;
			$table = Entries::table();
			$ids   = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$table} WHERE form_id = %d", $id ) );
			Entries::delete( array_map( 'intval', (array) $ids ) );
			wp_delete_post( $id, true );
		}
		wp_safe_redirect( self::list_url( [ 'deleted' => 1 ] ) );
		exit;
	}

	/** Capability and nonce check for the admin-post actions. */
	private static function guard( string $action ): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Non hai il permesso di fare questa operazione.', 'tw-formulari' ), 403 );
		}
		check_admin_referer( $action );
	}
}
