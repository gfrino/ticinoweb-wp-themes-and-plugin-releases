<?php
/**
 * Admin screens for the submissions ("Compilazioni"): list with filters, detail with files, status, delete, CSV export.
 *
 * Uploaded files are not reachable from the web: an administrator downloads them through a checked action that
 * verifies the file really belongs to the entry before streaming it as an attachment.
 *
 * @package TicinoWeb\TWFormulari\Builder
 */

namespace TicinoWeb\TWFormulari\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class EntriesAdmin {

	public const PAGE     = 'tw-formulari-entries';
	public const PER_PAGE = 20;

	public static function init(): void {
		add_action( 'admin_menu', [ self::class, 'register_menu' ], 21 );
		add_action( 'admin_post_twf_entry_status', [ self::class, 'handle_status' ] );
		add_action( 'admin_post_twf_entry_paid', [ self::class, 'handle_paid' ] );
		add_action( 'admin_post_twf_entry_refund', [ self::class, 'handle_refund' ] );
		add_action( 'admin_post_twf_entry_refund_sync', [ self::class, 'handle_refund_sync' ] );
		add_action( 'admin_post_twf_entries_bulk', [ self::class, 'handle_bulk' ] );
		add_action( 'admin_post_twf_entries_export', [ self::class, 'handle_export' ] );
		add_action( 'admin_post_twf_entry_file', [ self::class, 'handle_file' ] );
	}

	public static function register_menu(): void {
		add_submenu_page( 'tw-formulari', __( 'Compilazioni', 'tw-formulari' ), __( 'Compilazioni', 'tw-formulari' ), 'manage_options', self::PAGE, [ self::class, 'render' ] );
	}

	public static function list_url( array $args = [] ): string {
		return add_query_arg( $args, admin_url( 'admin.php?page=' . self::PAGE ) );
	}

	/** @return array<string, string> status => label */
	public static function status_labels(): array {
		return [
			Entries::STATUS_NEW             => __( 'Nuova', 'tw-formulari' ),
			Entries::STATUS_READ            => __( 'Letta', 'tw-formulari' ),
			Entries::STATUS_PENDING_PAYMENT => __( 'In attesa di pagamento', 'tw-formulari' ),
			Entries::STATUS_AWAITING_PAYMENT => __( 'In attesa del bonifico', 'tw-formulari' ),
			Entries::STATUS_PAID            => __( 'Pagata', 'tw-formulari' ),
			Entries::STATUS_PAYMENT_FAILED  => __( 'Pagamento non riuscito', 'tw-formulari' ),
			Entries::STATUS_PARTLY_REFUNDED => __( 'Rimborsata in parte', 'tw-formulari' ),
			Entries::STATUS_REFUNDED        => __( 'Rimborsata', 'tw-formulari' ),
		];
	}

	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Non hai il permesso di vedere questa pagina.', 'tw-formulari' ) );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only screen selection.
		$entry_id = isset( $_GET['entry'] ) ? absint( wp_unslash( $_GET['entry'] ) ) : 0;
		echo '<div class="wrap twf-wrap">';
		if ( $entry_id > 0 ) {
			self::render_entry( $entry_id );
		} else {
			self::render_list();
		}
		echo '</div>';
	}

	/**
	 * @return array<int, string> form id => title.
	 */
	private static function form_choices(): array {
		$out = [];
		foreach ( get_posts( [ 'post_type' => Builder::POST_TYPE, 'post_status' => 'any', 'numberposts' => 200, 'orderby' => 'title', 'order' => 'ASC' ] ) as $post ) {
			$out[ (int) $post->ID ] = (string) $post->post_title;
		}
		return $out;
	}

	private static function notices(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- display of a result message only.
		if ( isset( $_GET['deleted'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( sprintf(
				/* translators: %d: number of deleted entries */
				_n( '%d compilazione eliminata.', '%d compilazioni eliminate.', absint( wp_unslash( $_GET['deleted'] ) ), 'tw-formulari' ),
				absint( wp_unslash( $_GET['deleted'] ) )
			) ) . '</p></div>';
		}
		if ( isset( $_GET['paid'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Compilazione segnata come pagata.', 'tw-formulari' ) . '</p></div>';
		}
		if ( isset( $_GET['refund'] ) ) {
			$result = get_transient( 'twf_refund_msg_' . get_current_user_id() );
			delete_transient( 'twf_refund_msg_' . get_current_user_id() );
			if ( is_array( $result ) && '' !== (string) ( $result['message'] ?? '' ) ) {
				$tone = empty( $result['ok'] ) ? 'error' : ( 'pending' === ( $result['state'] ?? '' ) ? 'warning' : 'success' );
				echo '<div class="notice notice-' . esc_attr( $tone ) . ' is-dismissible"><p>' . esc_html( (string) $result['message'] ) . '</p></div>';
			}
		}
		if ( isset( $_GET['error'] ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['error'] ) ) ) . '</p></div>';
		}
		// phpcs:enable
	}

	private static function render_list(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- filters of a read-only list.
		$form_id = isset( $_GET['form'] ) ? absint( wp_unslash( $_GET['form'] ) ) : 0;
		$status  = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
		$search  = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		$paged   = isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( $_GET['paged'] ) ) ) : 1;
		// phpcs:enable

		$forms  = self::form_choices();
		$result = Entries::query( [ 'form_id' => $form_id, 'status' => $status, 'search' => $search, 'per_page' => self::PER_PAGE, 'page' => $paged ] );
		$labels = self::status_labels();

		echo '<h1 class="wp-heading-inline">' . esc_html__( 'Compilazioni', 'tw-formulari' ) . '</h1><hr class="wp-header-end">';
		self::notices();

		echo '<form method="get" class="twf-filters"><input type="hidden" name="page" value="' . esc_attr( self::PAGE ) . '">';
		echo '<select name="form"><option value="0">' . esc_html__( 'Tutti i moduli', 'tw-formulari' ) . '</option>';
		foreach ( $forms as $id => $title ) {
			echo '<option value="' . (int) $id . '"' . selected( $form_id, $id, false ) . '>' . esc_html( $title ) . '</option>';
		}
		echo '</select> <select name="status"><option value="">' . esc_html__( 'Tutti gli stati', 'tw-formulari' ) . '</option>';
		foreach ( $labels as $key => $label ) {
			echo '<option value="' . esc_attr( $key ) . '"' . selected( $status, $key, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select> <input type="search" name="s" value="' . esc_attr( $search ) . '" placeholder="' . esc_attr__( 'Cerca nelle risposte', 'tw-formulari' ) . '"> ';
		echo '<button class="button">' . esc_html__( 'Filtra', 'tw-formulari' ) . '</button>';
		if ( $form_id > 0 && $result['total'] > 0 ) {
			$export = wp_nonce_url( admin_url( 'admin-post.php?action=twf_entries_export&form=' . $form_id ), 'twf_entries_export_' . $form_id );
			echo ' <a class="button" href="' . esc_url( $export ) . '">' . esc_html__( 'Esporta in CSV (Excel)', 'tw-formulari' ) . '</a>';
		}
		echo '</form>';

		if ( ! $result['items'] ) {
			echo '<div class="twf-empty"><h2>' . esc_html__( 'Nessuna compilazione', 'tw-formulari' ) . '</h2><p>' . esc_html( ( $form_id || $status || '' !== $search )
				? __( 'Con questi filtri non c’è niente. Prova a toglierne qualcuno.', 'tw-formulari' )
				: __( 'Quando qualcuno compilerà un tuo modulo, lo troverai qui.', 'tw-formulari' ) ) . '</p></div>';
			return;
		}

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'twf_entries_bulk', '_twf_nonce' );
		echo '<input type="hidden" name="action" value="twf_entries_bulk"><input type="hidden" name="return" value="' . esc_attr( self::list_url( [ 'form' => $form_id ?: null, 'status' => $status ?: null, 's' => $search ?: null ] ) ) . '">';
		echo '<p><button class="button twf-delete" name="bulk" value="delete" data-confirm="' . esc_attr__( 'Eliminare le compilazioni selezionate e i loro file? L’operazione non si può annullare.', 'tw-formulari' ) . '" onclick="return confirm(this.dataset.confirm)">' . esc_html__( 'Elimina le selezionate', 'tw-formulari' ) . '</button></p>';
		echo '<table class="widefat striped twf-list"><thead><tr><td class="check-column"><input type="checkbox" onclick="document.querySelectorAll(\'.twf-pick\').forEach(function(c){c.checked=this.checked}.bind(this))"></td>'
			. '<th>' . esc_html__( 'Data', 'tw-formulari' ) . '</th><th>' . esc_html__( 'Modulo', 'tw-formulari' ) . '</th><th>' . esc_html__( 'Risposte', 'tw-formulari' ) . '</th><th>' . esc_html__( 'Stato', 'tw-formulari' ) . '</th></tr></thead><tbody>';
		foreach ( $result['items'] as $entry ) {
			$view    = self::list_url( [ 'entry' => $entry['id'] ] );
			$summary = [];
			foreach ( array_slice( (array) $entry['display'], 0, 3 ) as $row ) {
				$summary[] = '<span class="twf-q">' . esc_html( (string) $row['label'] ) . ':</span> ' . esc_html( mb_strlen( (string) $row['text'] ) > 60 ? mb_substr( (string) $row['text'], 0, 60 ) . '…' : (string) $row['text'] );
			}
			echo '<tr' . ( Entries::STATUS_NEW === $entry['status'] ? ' class="twf-new"' : '' ) . '>'
				. '<th class="check-column"><input type="checkbox" class="twf-pick" name="ids[]" value="' . (int) $entry['id'] . '"></th>'
				. '<td><a href="' . esc_url( $view ) . '"><strong>' . esc_html( get_date_from_gmt( (string) $entry['created_gmt'], 'd/m/Y H:i' ) ) . '</strong></a></td>'
				. '<td>' . esc_html( $forms[ $entry['form_id'] ] ?? '#' . $entry['form_id'] ) . '</td>'
				. '<td>' . implode( ' · ', $summary ) . '</td>'
				. '<td><span class="twf-badge twf-badge--' . esc_attr( (string) $entry['status'] ) . '">' . esc_html( $labels[ $entry['status'] ] ?? (string) $entry['status'] ) . '</span></td></tr>';
		}
		echo '</tbody></table></form>';

		$pages = (int) ceil( $result['total'] / self::PER_PAGE );
		if ( $pages > 1 ) {
			echo '<div class="tablenav"><div class="tablenav-pages">' . wp_kses_post( (string) paginate_links( [
				'base'      => add_query_arg( 'paged', '%#%' ),
				'format'    => '',
				'current'   => $paged,
				'total'     => $pages,
				'prev_text' => '‹',
				'next_text' => '›',
			] ) ) . '</div></div>';
		}
	}

	private static function render_entry( int $id ): void {
		$entry = Entries::get( $id );
		if ( ! $entry ) {
			echo '<h1>' . esc_html__( 'Compilazioni', 'tw-formulari' ) . '</h1><p>' . esc_html__( 'Compilazione non trovata.', 'tw-formulari' ) . ' <a href="' . esc_url( self::list_url() ) . '">' . esc_html__( 'Torna all’elenco', 'tw-formulari' ) . '</a></p>';
			return;
		}
		// Opening a new entry marks it as read.
		if ( Entries::STATUS_NEW === $entry['status'] ) {
			Entries::update( $id, [ 'status' => Entries::STATUS_READ ] );
			$entry['status'] = Entries::STATUS_READ;
		}
		$form   = Builder::get_form( (int) $entry['form_id'] );
		$labels = self::status_labels();

		echo '<h1>' . esc_html( sprintf(
			/* translators: %d: entry number */
			__( 'Compilazione n. %d', 'tw-formulari' ),
			$id
		) ) . '</h1>';
		echo '<p><a href="' . esc_url( self::list_url( [ 'form' => $entry['form_id'] ] ) ) . '">← ' . esc_html__( 'Torna all’elenco', 'tw-formulari' ) . '</a></p>';
		self::notices();

		echo '<table class="widefat striped twf-detail" style="max-width:820px"><tbody>';
		echo '<tr><th>' . esc_html__( 'Modulo', 'tw-formulari' ) . '</th><td>' . esc_html( $form ? $form['title'] : '#' . $entry['form_id'] ) . '</td></tr>';
		echo '<tr><th>' . esc_html__( 'Data', 'tw-formulari' ) . '</th><td>' . esc_html( get_date_from_gmt( (string) $entry['created_gmt'], 'd/m/Y H:i' ) ) . '</td></tr>';
		echo '<tr><th>' . esc_html__( 'Stato', 'tw-formulari' ) . '</th><td><span class="twf-badge twf-badge--' . esc_attr( (string) $entry['status'] ) . '">' . esc_html( $labels[ $entry['status'] ] ?? (string) $entry['status'] ) . '</span></td></tr>';
		$pay = (array) $entry['payment'];
		if ( isset( $pay['amount'] ) ) {
			$manual = 'manual' === ( $pay['provider'] ?? '' );
			$test   = ! $manual && empty( $pay['livemode'] );
			$link  = '' !== (string) ( $pay['intent'] ?? '' ) ? 'https://dashboard.stripe.com/' . ( $test ? 'test/' : '' ) . 'payments/' . rawurlencode( (string) $pay['intent'] ) : '';
			$state = [ 'awaiting' => __( 'in attesa di ricevere il pagamento', 'tw-formulari' ), 'pending' => __( 'in attesa', 'tw-formulari' ), 'paid' => __( 'pagato', 'tw-formulari' ), 'failed' => __( 'rifiutato', 'tw-formulari' ), 'canceled' => __( 'annullato', 'tw-formulari' ), 'mismatch' => __( 'importo diverso dall’atteso', 'tw-formulari' ) ];
			echo '<tr><th>' . esc_html__( 'Importo', 'tw-formulari' ) . '</th><td><strong>' . esc_html( (string) $pay['amount'] . ' ' . (string) ( $pay['currency'] ?? '' ) ) . '</strong>';
			echo ' — ' . esc_html( $state[ (string) ( $pay['status'] ?? '' ) ] ?? (string) ( $pay['status'] ?? '' ) );
			if ( $manual ) {
				echo '<br><span class="twf-q">' . esc_html( sprintf(
					/* translators: %s: payment method name, e.g. "Bonifico bancario" */
					__( 'Metodo scelto: %s', 'tw-formulari' ),
					(string) ( $pay['label'] ?? $pay['method'] ?? '' )
				) ) . ( '' !== (string) ( $pay['reference'] ?? '' ) ? ' · ' . esc_html__( 'Causale:', 'tw-formulari' ) . ' ' . esc_html( (string) $pay['reference'] ) : '' ) . '</span>';
				if ( ! empty( $pay['paid_at'] ) ) {
					echo '<br><span class="twf-q">' . esc_html( sprintf(
						/* translators: %s: date */
						__( 'Segnata come pagata il %s', 'tw-formulari' ),
						get_date_from_gmt( (string) $pay['paid_at'], 'd/m/Y H:i' )
					) ) . '</span>';
				}
			}
			if ( $test ) {
				echo ' <span class="twf-badge twf-badge--pending_payment">' . esc_html__( 'PROVA', 'tw-formulari' ) . '</span>';
			}
			if ( '' !== $link ) {
				echo ' <a href="' . esc_url( $link ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Apri su Stripe', 'tw-formulari' ) . '</a>';
			}
			if ( ! empty( $pay['note'] ) ) {
				echo '<br><span class="twf-q">' . esc_html( (string) $pay['note'] ) . '</span>';
			}
			if ( ! empty( $pay['refunded_minor'] ) ) {
				echo '<br><span class="twf-q">' . esc_html( sprintf(
					/* translators: %s: amount with currency */
					__( 'Rimborsato: %s', 'tw-formulari' ),
					Refunds::money( (int) $pay['refunded_minor'], (string) ( $pay['currency'] ?? '' ) )
				) ) . '</span>';
			}
			echo '</td></tr>';
		}
		foreach ( (array) $entry['display'] as $row ) {
			echo '<tr><th>' . esc_html( (string) $row['label'] ) . '</th><td>' . nl2br( esc_html( (string) $row['text'] ) ) . '</td></tr>';
		}
		foreach ( (array) $entry['files'] as $i => $file ) {
			$url = wp_nonce_url( admin_url( 'admin-post.php?action=twf_entry_file&entry=' . $id . '&i=' . (int) $i ), 'twf_entry_file_' . $id . '_' . (int) $i );
			echo '<tr><th>' . esc_html__( 'Allegato', 'tw-formulari' ) . '</th><td><a href="' . esc_url( $url ) . '">' . esc_html( (string) ( $file['name'] ?? __( 'file', 'tw-formulari' ) ) ) . '</a> <span class="twf-q">(' . esc_html( size_format( (int) ( $file['size'] ?? 0 ) ) ) . ')</span></td></tr>';
		}
		echo '</tbody></table>';

		self::render_refunds( $entry );

		$delete = wp_nonce_url( admin_url( 'admin-post.php?action=twf_entries_bulk&bulk=delete&ids[]=' . $id . '&return=' . rawurlencode( self::list_url( [ 'form' => $entry['form_id'] ] ) ) ), 'twf_entries_bulk', '_twf_nonce' );
		$toggle_to   = Entries::STATUS_READ === $entry['status'] ? Entries::STATUS_NEW : Entries::STATUS_READ;
		$toggle_url  = wp_nonce_url( admin_url( 'admin-post.php?action=twf_entry_status&entry=' . $id . '&status=' . $toggle_to ), 'twf_entry_status_' . $id );
		if ( in_array( $entry['status'], [ Entries::STATUS_READ, Entries::STATUS_NEW ], true ) ) {
			echo '<p style="margin-top:16px"><a class="button" href="' . esc_url( $toggle_url ) . '">' . esc_html( Entries::STATUS_READ === $entry['status'] ? __( 'Segna come da leggere', 'tw-formulari' ) : __( 'Segna come letta', 'tw-formulari' ) ) . '</a></p>';
		}
		if ( Entries::STATUS_AWAITING_PAYMENT === $entry['status'] ) {
			$paid_url = wp_nonce_url( admin_url( 'admin-post.php?action=twf_entry_paid&entry=' . $id ), 'twf_entry_paid_' . $id );
			echo '<p style="margin-top:16px"><a class="button button-primary" href="' . esc_url( $paid_url ) . '" data-confirm="' . esc_attr__( 'Confermi di aver ricevuto il pagamento? La compilazione risulterà pagata.', 'tw-formulari' ) . '" onclick="return confirm(this.dataset.confirm)">' . esc_html__( 'Segna come pagata', 'tw-formulari' ) . '</a></p>';
		}
		echo '<p style="margin-top:16px"><a class="button twf-delete" href="' . esc_url( $delete ) . '" data-confirm="' . esc_attr__( 'Eliminare questa compilazione e i suoi file? L’operazione non si può annullare.', 'tw-formulari' ) . '" onclick="return confirm(this.dataset.confirm)">' . esc_html__( 'Elimina', 'tw-formulari' ) . '</a></p>';
	}

	/**
	 * The "Rimborso" panel of a paid entry: what can be given back, the form to do it and the record of every refund.
	 *
	 * @param array<string, mixed> $entry
	 */
	private static function render_refunds( array $entry ): void {
		$pay = (array) $entry['payment'];
		if ( ! isset( $pay['amount'] ) ) {
			return;
		}
		$records = array_values( array_filter( (array) ( $pay['refunds'] ?? [] ), 'is_array' ) );
		$status  = (string) $entry['status'];
		if ( ! $records && ! in_array( $status, [ Entries::STATUS_PAID, Entries::STATUS_PARTLY_REFUNDED, Entries::STATUS_REFUNDED ], true ) ) {
			return;
		}
		$id     = (int) $entry['id'];
		$can    = Refunds::refundable( $entry );
		$stripe = 'stripe' === $can['provider'];
		$cur    = $can['currency'];

		$sync_url = '';
		if ( $stripe && '' !== (string) ( $pay['intent'] ?? '' ) ) {
			$sync_url = wp_nonce_url( admin_url( 'admin-post.php?action=twf_entry_refund_sync&entry=' . $id ), 'twf_entry_refund_sync_' . $id );
		}
		echo '<div class="twf-refund" id="twf-refund">';
		echo '<div class="twf-refund__head"><h2>' . esc_html__( 'Rimborso', 'tw-formulari' ) . '</h2>';
		if ( '' !== $sync_url ) {
			echo '<a class="button twf-refund__syncbtn" href="' . esc_url( $sync_url ) . '">' . esc_html__( 'Aggiorna da Stripe', 'tw-formulari' ) . '</a>';
		}
		echo '</div>';
		echo '<dl class="twf-refund__sum">';
		echo '<div><dt>' . esc_html__( 'Pagato', 'tw-formulari' ) . '</dt><dd>' . esc_html( Refunds::money( $can['paid'], $cur ) ) . '</dd></div>';
		echo '<div><dt>' . esc_html__( 'Rimborsato', 'tw-formulari' ) . '</dt><dd>' . esc_html( Refunds::money( $can['refunded'], $cur ) ) . '</dd></div>';
		echo '<div class="twf-refund__left"><dt>' . esc_html__( 'Si può ancora rimborsare', 'tw-formulari' ) . '</dt><dd>' . esc_html( Refunds::money( $can['left'], $cur ) ) . '</dd></div>';
		echo '</dl>';

		if ( $can['ok'] ) {
			$money_left = Refunds::decimal( $can['left'], $can['factor'] );
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="twf-refund__form" id="twf-refund-form"'
				. ' data-currency="' . esc_attr( $cur ) . '"'
				. ' data-confirm="' . esc_attr( $stripe
					/* translators: %s: amount with currency (filled in by the page) */
					? __( 'Rimborsare %s al cliente con Stripe? Il denaro torna sul metodo con cui ha pagato e l’operazione non si può annullare.', 'tw-formulari' )
					/* translators: %s: amount with currency (filled in by the page) */
					: __( 'Registrare un rimborso di %s? Ricorda di restituire tu il denaro al cliente.', 'tw-formulari' ) ) . '">';
			echo '<input type="hidden" name="action" value="twf_entry_refund"><input type="hidden" name="entry" value="' . (int) $id . '">';
			wp_nonce_field( 'twf_entry_refund_' . $id );
			if ( $stripe ) {
				echo '<p class="twf-refund__intro">' . esc_html__( 'Il denaro torna al cliente tramite Stripe, sullo stesso metodo con cui ha pagato (carta, TWINT…). Puoi rimborsare tutto o solo una parte.', 'tw-formulari' );
				if ( 'test' === $can['mode'] ) {
					echo ' <span class="twf-badge twf-badge--pending_payment">' . esc_html__( 'PROVA', 'tw-formulari' ) . '</span> ' . esc_html__( 'Pagamento di prova: non si muove denaro reale.', 'tw-formulari' );
				}
				echo '</p>';
			} else {
				echo '<p class="twf-refund__intro">' . esc_html__( 'Questo pagamento non è passato da Stripe, quindi il plugin non muove denaro: restituisci tu l’importo al cliente (per esempio con un bonifico) e registralo qui, così resta nello storico.', 'tw-formulari' ) . '</p>';
			}
			echo '<div class="twf-refund__grid">';
			echo '<p class="twf-refund__field"><label for="twf-refund-amount">' . esc_html__( 'Importo da rimborsare', 'tw-formulari' ) . '</label>'
				. '<span class="twf-refund__amount"><input type="text" inputmode="decimal" id="twf-refund-amount" name="amount" value="' . esc_attr( $money_left ) . '" autocomplete="off" required><span class="twf-refund__cur">' . esc_html( $cur ) . '</span></span>'
				. '<span class="twf-refund__help">' . esc_html( sprintf(
					/* translators: %s: amount with currency */
					__( 'Al massimo %s. Per un rimborso parziale scrivi solo la parte da restituire.', 'tw-formulari' ),
					Refunds::money( $can['left'], $cur )
				) ) . '</span></p>';
			echo '<p class="twf-refund__field"><label for="twf-refund-reason">' . esc_html__( 'Motivo', 'tw-formulari' ) . '</label><select id="twf-refund-reason" name="reason">';
			foreach ( Refunds::reason_labels() as $key => $label ) {
				echo '<option value="' . esc_attr( $key ) . '">' . esc_html( $label ) . '</option>';
			}
			echo '</select></p>';
			echo '<p class="twf-refund__field twf-refund__note"><label for="twf-refund-note">' . esc_html__( 'Nota interna (facoltativa)', 'tw-formulari' ) . '</label><textarea id="twf-refund-note" name="note" rows="2" maxlength="500" placeholder="' . esc_attr__( 'Per esempio: il cliente ha disdetto la prenotazione', 'tw-formulari' ) . '"></textarea><span class="twf-refund__help">' . esc_html__( 'Resta solo qui nello storico: il cliente non la vede.', 'tw-formulari' ) . '</span></p>';
			echo '</div>';
			echo '<p class="twf-refund__actions"><button type="submit" class="button button-primary button-hero">' . esc_html( $stripe ? __( 'Rimborsa con Stripe', 'tw-formulari' ) : __( 'Registra il rimborso', 'tw-formulari' ) ) . '</button></p>';
			echo '</form>';
			echo '<script>(function(){var f=document.getElementById("twf-refund-form");if(!f){return;}f.addEventListener("submit",function(e){var b=f.querySelector("button[type=submit]");var a=(f.querySelector("#twf-refund-amount").value||"").trim()+" "+f.getAttribute("data-currency");if(!window.confirm(f.getAttribute("data-confirm").replace("%s",a))){e.preventDefault();return;}if(b){b.disabled=true;b.textContent=' . wp_json_encode( __( 'Rimborso in corso…', 'tw-formulari' ) ) . ';}});})();</script>';
		} elseif ( '' !== $can['reason'] && Entries::STATUS_REFUNDED !== $status ) {
			echo '<p class="twf-refund__intro">' . esc_html( $can['reason'] ) . '</p>';
		}

		if ( $records ) {
			$states  = Refunds::state_labels();
			$reasons = Refunds::reason_labels();
			echo '<h3>' . esc_html__( 'Storico dei rimborsi', 'tw-formulari' ) . '</h3>';
			echo '<div class="twf-refund__logwrap"><table class="widefat striped twf-refund__log"><thead><tr><th>' . esc_html__( 'Data', 'tw-formulari' ) . '</th><th>' . esc_html__( 'Importo', 'tw-formulari' ) . '</th><th>' . esc_html__( 'Stato', 'tw-formulari' ) . '</th><th>' . esc_html__( 'Motivo', 'tw-formulari' ) . '</th><th>' . esc_html__( 'Fatto da', 'tw-formulari' ) . '</th><th>' . esc_html__( 'Nota', 'tw-formulari' ) . '</th></tr></thead><tbody>';
			foreach ( array_reverse( $records ) as $r ) {
				$state = (string) ( $r['status'] ?? '' );
				$tone  = 'succeeded' === $state ? 'paid' : ( in_array( $state, [ 'pending', 'requires_action' ], true ) ? 'pending_payment' : 'payment_failed' );
				$who   = '' !== (string) ( $r['by_name'] ?? '' ) ? (string) $r['by_name'] : ( 'stripe' === ( $r['origin'] ?? '' ) ? __( 'Dal pannello di Stripe', 'tw-formulari' ) : '—' );
				echo '<tr><td>' . esc_html( get_date_from_gmt( (string) ( $r['at'] ?? '' ), 'd/m/Y H:i' ) ) . '</td>'
					. '<td><strong>' . esc_html( Refunds::money( (int) ( $r['minor'] ?? 0 ), (string) ( $r['currency'] ?? $cur ) ) ) . '</strong>' . ( 'manual' === ( $r['provider'] ?? '' ) ? '<br><span class="twf-q">' . esc_html__( 'registrato a mano', 'tw-formulari' ) . '</span>' : '' ) . '</td>'
					. '<td><span class="twf-badge twf-badge--' . esc_attr( $tone ) . '">' . esc_html( $states[ $state ] ?? $state ) . '</span>' . ( '' !== (string) ( $r['message'] ?? '' ) ? '<br><span class="twf-q">' . esc_html( (string) $r['message'] ) . '</span>' : '' ) . '</td>'
					. '<td>' . esc_html( $reasons[ (string) ( $r['reason'] ?? '' ) ] ?? '' ) . '</td>'
					. '<td>' . esc_html( $who ) . '</td>'
					. '<td>' . nl2br( esc_html( (string) ( $r['note'] ?? '' ) ) ) . '</td></tr>';
			}
			echo '</tbody></table></div>';
		}
		if ( '' !== $sync_url ) {
			echo '<p class="twf-refund__foot">' . esc_html__( 'I rimborsi fatti direttamente sul pannello di Stripe compaiono qui da soli. Se non ne vedi uno, premi «Aggiorna da Stripe» in alto.', 'tw-formulari' ) . '</p>';
		}
		echo '</div>';
	}

	/** Gives back all or part of the money of a paid entry (Stripe) or records a refund made by hand. */
	public static function handle_refund(): void {
		$id = isset( $_POST['entry'] ) ? absint( wp_unslash( $_POST['entry'] ) ) : 0;
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Non hai il permesso di fare questa operazione.', 'tw-formulari' ), 403 );
		}
		check_admin_referer( 'twf_entry_refund_' . $id );
		$amount = isset( $_POST['amount'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['amount'] ) ) : '';
		$reason = isset( $_POST['reason'] ) ? sanitize_key( wp_unslash( (string) $_POST['reason'] ) ) : '';
		$note   = isset( $_POST['note'] ) ? sanitize_textarea_field( wp_unslash( (string) $_POST['note'] ) ) : '';
		$result = Refunds::refund( $id, $amount, $reason, $note, get_current_user_id() );
		set_transient( 'twf_refund_msg_' . get_current_user_id(), $result, 5 * MINUTE_IN_SECONDS );
		wp_safe_redirect( self::list_url( [ 'entry' => $id, 'refund' => 1 ] ) . '#twf-refund' );
		exit;
	}

	/** Reads the refunds of the payment from Stripe (e.g. one made on the Stripe dashboard). */
	public static function handle_refund_sync(): void {
		$id = isset( $_GET['entry'] ) ? absint( wp_unslash( $_GET['entry'] ) ) : 0;
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Non hai il permesso di fare questa operazione.', 'tw-formulari' ), 403 );
		}
		check_admin_referer( 'twf_entry_refund_sync_' . $id );
		$entry  = $id ? Entries::get( $id ) : null;
		$intent = $entry ? (string) ( $entry['payment']['intent'] ?? '' ) : '';
		$sync   = '' !== $intent ? Refunds::sync( $intent ) : [ 'ok' => false, 'changed' => false, 'message' => __( 'Questa compilazione non ha un pagamento Stripe.', 'tw-formulari' ) ];
		set_transient( 'twf_refund_msg_' . get_current_user_id(), [
			'ok'      => $sync['ok'],
			'state'   => '',
			'message' => $sync['ok']
				? ( $sync['changed'] ? __( 'Rimborsi aggiornati da Stripe.', 'tw-formulari' ) : __( 'Nessuna novità su Stripe: lo storico è già aggiornato.', 'tw-formulari' ) )
				: (string) $sync['message'],
		], 5 * MINUTE_IN_SECONDS );
		wp_safe_redirect( self::list_url( [ 'entry' => $id, 'refund' => 1 ] ) . '#twf-refund' );
		exit;
	}

	public static function handle_bulk(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Non hai il permesso di fare questa operazione.', 'tw-formulari' ), 403 );
		}
		check_admin_referer( 'twf_entries_bulk', '_twf_nonce' );
		$request = array_merge( $_GET, $_POST ); // phpcs:ignore WordPress.Security.NonceVerification -- verified just above.
		$ids     = isset( $request['ids'] ) && is_array( $request['ids'] ) ? array_map( 'absint', wp_unslash( $request['ids'] ) ) : [];
		$return  = isset( $request['return'] ) ? esc_url_raw( wp_unslash( (string) $request['return'] ) ) : self::list_url();
		if ( ! wp_validate_redirect( $return, '' ) ) {
			$return = self::list_url();
		}
		$deleted = 0;
		if ( 'delete' === ( $request['bulk'] ?? '' ) && $ids ) {
			$deleted = Entries::delete( $ids );
		}
		wp_safe_redirect( add_query_arg( 'deleted', $deleted, $return ) );
		exit;
	}

	/** The owner got the money (bank transfer, cash…): the entry becomes "paid". Exactly once, whoever clicks. */
	public static function handle_paid(): void {
		$id = isset( $_GET['entry'] ) ? absint( wp_unslash( $_GET['entry'] ) ) : 0;
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Non hai il permesso di fare questa operazione.', 'tw-formulari' ), 403 );
		}
		check_admin_referer( 'twf_entry_paid_' . $id );
		$entry = $id ? Entries::get( $id ) : null;
		if ( $entry && Entries::STATUS_AWAITING_PAYMENT === $entry['status'] ) {
			$pay             = (array) $entry['payment'];
			$pay['status']   = 'paid';
			$pay['paid_at']  = gmdate( 'Y-m-d H:i:s' );
			$pay['paid_by']  = get_current_user_id();
			if ( Entries::transition( $id, [ Entries::STATUS_AWAITING_PAYMENT ], Entries::STATUS_PAID, $pay ) ) {
				do_action( 'twf_payment_completed', (int) $entry['form_id'], $id, $pay );
			}
		}
		wp_safe_redirect( self::list_url( [ 'entry' => $id, 'paid' => 1 ] ) );
		exit;
	}

	public static function handle_status(): void {
		$id = isset( $_GET['entry'] ) ? absint( wp_unslash( $_GET['entry'] ) ) : 0;
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Non hai il permesso di fare questa operazione.', 'tw-formulari' ), 403 );
		}
		check_admin_referer( 'twf_entry_status_' . $id );
		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
		if ( $id && in_array( $status, [ Entries::STATUS_NEW, Entries::STATUS_READ ], true ) ) {
			Entries::update( $id, [ 'status' => $status ] );
		}
		wp_safe_redirect( self::list_url( [ 'entry' => $id ] ) );
		exit;
	}

	public static function handle_export(): void {
		$form_id = isset( $_GET['form'] ) ? absint( wp_unslash( $_GET['form'] ) ) : 0;
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Non hai il permesso di fare questa operazione.', 'tw-formulari' ), 403 );
		}
		check_admin_referer( 'twf_entries_export_' . $form_id );
		$form = $form_id ? Builder::get_form( $form_id ) : null;
		if ( ! $form ) {
			wp_die( esc_html__( 'Modulo non trovato.', 'tw-formulari' ), 404 );
		}

		nocache_headers();
		header( 'Content-Type: text/csv; charset=UTF-8' );
		header( 'X-Content-Type-Options: nosniff' );
		header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( 'compilazioni-' . $form['title'] . '-' . gmdate( 'Y-m-d' ) . '.csv' ) . '"' );
		$out = fopen( 'php://output', 'w' );
		fwrite( $out, "\xEF\xBB\xBF" ); // UTF-8 BOM so Excel reads accents correctly.

		$page = 1;
		$first = true;
		do {
			$batch = Entries::query( [ 'form_id' => $form_id, 'per_page' => 200, 'page' => $page, 'order' => 'ASC' ] );
			$rows  = Entries::csv_rows( $form['definition'], $batch['items'] );
			if ( ! $first ) {
				array_shift( $rows ); // header only once
			}
			foreach ( $rows as $row ) {
				fputcsv( $out, $row, ';', '"', '\\' );
			}
			$first = false;
			++$page;
		} while ( count( $batch['items'] ) === 200 );
		fclose( $out );
		exit;
	}

	public static function handle_file(): void {
		$id = isset( $_GET['entry'] ) ? absint( wp_unslash( $_GET['entry'] ) ) : 0;
		$i  = isset( $_GET['i'] ) ? absint( wp_unslash( $_GET['i'] ) ) : 0;
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Non hai il permesso di fare questa operazione.', 'tw-formulari' ), 403 );
		}
		check_admin_referer( 'twf_entry_file_' . $id . '_' . $i );

		$entry = $id ? Entries::get( $id ) : null;
		$file  = $entry && isset( $entry['files'][ $i ] ) && is_array( $entry['files'][ $i ] ) ? $entry['files'][ $i ] : null;
		$path  = $file ? Uploads::absolute_path( $file ) : '';
		if ( '' === $path ) {
			wp_die( esc_html__( 'File non trovato.', 'tw-formulari' ), 404 );
		}

		nocache_headers();
		header( 'Content-Type: application/octet-stream' );
		header( 'X-Content-Type-Options: nosniff' );
		header( 'Content-Disposition: attachment; filename="' . str_replace( [ '"', "\r", "\n" ], '', (string) ( $file['name'] ?? 'allegato' ) ) . '"' );
		header( 'Content-Length: ' . (string) filesize( $path ) );
		readfile( $path );
		exit;
	}
}
