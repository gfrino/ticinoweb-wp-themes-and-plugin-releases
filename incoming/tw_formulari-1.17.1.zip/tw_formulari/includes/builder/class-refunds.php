<?php
/**
 * Refunds of paid submissions, with a permanent record of each one.
 *
 *  - Paid with Stripe: the refund is made on Stripe (whole or partial) with the keys of the mode the payment was made
 *    in. Refunds made directly on the Stripe dashboard arrive through the webhook (charge.refunded, refund.updated)
 *    or the "Aggiorna da Stripe" button, through the same code (sync), so the entry always tells the truth.
 *  - Paid in another way (bank transfer, cash…): the plugin moves no money; the owner gives it back and records it.
 *
 * Every refund stays in the entry's payment details ("refunds"): amount, state, reason, internal note, who did it and
 * when. Failed attempts are recorded too (they do not count in the total). The total given back decides the status:
 * "Rimborsata" (all of it) or "Rimborsata in parte".
 *
 * @package TicinoWeb\TWFormulari\Builder
 */

namespace TicinoWeb\TWFormulari\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Refunds {

	/** Reasons offered in the screen; the first three are Stripe's own. */
	public const REASONS = [ 'requested_by_customer', 'duplicate', 'fraudulent', 'other' ];

	/** States of a refund that count as money given back (pending ones too: they cannot be refunded twice). */
	private const COUNTED = [ 'succeeded', 'pending', 'requires_action' ];

	/** Records kept per entry (the oldest failed attempts go first when there are more). */
	private const MAX_RECORDS = 50;

	/** @return array<string, string> reason => label */
	public static function reason_labels(): array {
		return [
			'requested_by_customer' => __( 'Richiesta del cliente', 'tw-formulari' ),
			'duplicate'             => __( 'Pagamento doppio', 'tw-formulari' ),
			'fraudulent'            => __( 'Pagamento fraudolento', 'tw-formulari' ),
			'other'                 => __( 'Altro motivo', 'tw-formulari' ),
		];
	}

	/** @return array<string, string> state => label */
	public static function state_labels(): array {
		return [
			'succeeded'       => __( 'Rimborsato', 'tw-formulari' ),
			'pending'         => __( 'In corso', 'tw-formulari' ),
			'requires_action' => __( 'In corso', 'tw-formulari' ),
			'failed'          => __( 'Non riuscito', 'tw-formulari' ),
			'canceled'        => __( 'Annullato', 'tw-formulari' ),
			'error'           => __( 'Non eseguito', 'tw-formulari' ),
		];
	}

	/**
	 * What can be refunded on an entry.
	 *
	 * @param array<string, mixed> $entry
	 * @return array{ok:bool, provider:string, mode:string, paid:int, refunded:int, left:int, currency:string, factor:int, reason:string}
	 */
	public static function refundable( array $entry ): array {
		$pay      = (array) ( $entry['payment'] ?? [] );
		$currency = strtoupper( (string) ( $pay['currency'] ?? '' ) );
		$factor   = Stripe::factor( $currency );
		$paid     = isset( $pay['minor'] ) ? (int) $pay['minor'] : (int) round( (float) ( $pay['amount'] ?? 0 ) * $factor );
		$refunded = self::counted_minor( $pay );
		$provider = 'stripe' === ( $pay['provider'] ?? '' ) ? 'stripe' : 'manual';
		$out      = [
			'ok'       => false,
			'provider' => $provider,
			'mode'     => empty( $pay['livemode'] ) ? 'test' : 'live',
			'paid'     => $paid,
			'refunded' => $refunded,
			'left'     => max( 0, $paid - $refunded ),
			'currency' => $currency,
			'factor'   => $factor,
			'reason'   => '',
		];
		if ( ! in_array( (string) ( $entry['status'] ?? '' ), [ Entries::STATUS_PAID, Entries::STATUS_PARTLY_REFUNDED ], true ) || $paid <= 0 ) {
			$out['reason'] = __( 'Si può rimborsare solo una compilazione pagata.', 'tw-formulari' );
			return $out;
		}
		if ( $out['left'] <= 0 ) {
			$out['reason'] = __( 'L’importo pagato è già stato rimborsato tutto.', 'tw-formulari' );
			return $out;
		}
		if ( 'stripe' === $provider ) {
			if ( '' === (string) ( $pay['intent'] ?? '' ) ) {
				$out['reason'] = __( 'Manca il riferimento del pagamento su Stripe: rimborsa direttamente dal pannello di Stripe.', 'tw-formulari' );
				return $out;
			}
			if ( ! Stripe::key_is_valid( $out['mode'], 'secret', Stripe::keys( $out['mode'] )['secret'] ) ) {
				$out['reason'] = 'live' === $out['mode']
					? __( 'Per rimborsare un pagamento reale serve la chiave segreta reale di Stripe (TW Formulari → Pagamenti).', 'tw-formulari' )
					: __( 'Per rimborsare un pagamento di prova serve la chiave segreta di prova di Stripe (TW Formulari → Pagamenti).', 'tw-formulari' );
				return $out;
			}
		}
		$out['ok'] = true;
		return $out;
	}

	/**
	 * Refunds an entry (all or part of it) and records it.
	 *
	 * @param string $amount_input What the person typed ("50", "50.00", "50,5"); empty = all that is left.
	 * @return array{ok:bool, message:string, state:string}
	 */
	public static function refund( int $entry_id, string $amount_input, string $reason, string $note, int $user_id ): array {
		$entry = Entries::get( $entry_id );
		if ( ! $entry ) {
			return self::fail( __( 'Compilazione non trovata.', 'tw-formulari' ) );
		}
		$can = self::refundable( $entry );
		if ( ! $can['ok'] ) {
			return self::fail( $can['reason'] );
		}
		$minor = '' === trim( $amount_input ) ? $can['left'] : self::parse_minor( $amount_input, $can['factor'] );
		if ( $minor <= 0 ) {
			return self::fail( __( 'Scrivi un importo valido da rimborsare, per esempio 50 oppure 25.50.', 'tw-formulari' ) );
		}
		if ( $minor > $can['left'] ) {
			return self::fail( sprintf(
				/* translators: %s: amount with currency */
				__( 'Puoi rimborsare al massimo %s: il resto è già stato rimborsato.', 'tw-formulari' ),
				self::money( $can['left'], $can['currency'] )
			) );
		}
		$reason = in_array( $reason, self::REASONS, true ) ? $reason : 'requested_by_customer';
		$note   = mb_substr( sanitize_textarea_field( $note ), 0, 500 );
		$user   = $user_id > 0 ? get_userdata( $user_id ) : null;

		// One refund at a time per entry: a double click must not give the money back twice.
		$lock = 'twf_refund_lock_' . $entry_id;
		$held = (int) get_option( $lock, 0 );
		if ( $held > 0 && $held > time() - 60 ) {
			return self::fail( __( 'Un rimborso di questa compilazione è già in corso. Attendi qualche secondo e ricarica la pagina.', 'tw-formulari' ) );
		}
		delete_option( $lock );
		if ( ! add_option( $lock, time(), '', false ) ) {
			return self::fail( __( 'Un rimborso di questa compilazione è già in corso. Attendi qualche secondo e ricarica la pagina.', 'tw-formulari' ) );
		}

		try {
			$record = [
				'id'       => '',
				'provider' => $can['provider'],
				'minor'    => $minor,
				'amount'   => self::decimal( $minor, $can['factor'] ),
				'currency' => $can['currency'],
				'status'   => 'succeeded',
				'reason'   => $reason,
				'note'     => $note,
				'by'       => $user_id,
				'by_name'  => $user ? (string) $user->display_name : '',
				'at'       => gmdate( 'Y-m-d H:i:s' ),
				'origin'   => 'admin',
			];

			if ( 'stripe' === $can['provider'] ) {
				$pay    = (array) $entry['payment'];
				$params = [
					'payment_intent'      => (string) $pay['intent'],
					'amount'              => $minor,
					'metadata[twf_entry]' => (string) $entry_id,
					'metadata[twf_form]'  => (string) $entry['form_id'],
					'metadata[wp_user]'   => (string) $user_id,
				];
				if ( 'other' !== $reason ) {
					$params['reason'] = $reason;
				}
				// Same entry, same amount already given back, same request: Stripe answers with the same refund.
				$key = 'twf-refund-' . $entry_id . '-' . $can['refunded'] . '-' . $minor . '-' . md5( (string) $pay['intent'] );
				$res = Stripe::request( 'POST', 'refunds', $params, [ 'Idempotency-Key' => $key ], $can['mode'] );
				if ( ! $res['ok'] ) {
					$message           = self::stripe_error( $res, $can['mode'] );
					$record['status']  = 'error';
					$record['message'] = mb_substr( (string) $res['error'], 0, 300 );
					self::save( $entry_id, $record );
					error_log( sprintf( 'tw_formulari: rimborso non eseguito per la compilazione %d (%s)', $entry_id, (string) $res['error'] ) );
					return self::fail( $message );
				}
				$record['id']     = (string) ( $res['body']['id'] ?? '' );
				$record['status'] = (string) ( $res['body']['status'] ?? 'pending' );
				if ( isset( $res['body']['amount'] ) ) {
					$record['minor']  = (int) $res['body']['amount'];
					$record['amount'] = self::decimal( (int) $res['body']['amount'], $can['factor'] );
				}
			} else {
				$record['id'] = 'manual-' . wp_generate_password( 12, false, false );
			}

			$payment = self::save( $entry_id, $record );
			if ( null === $payment ) {
				return self::fail( __( 'Il rimborso è stato fatto ma non sono riuscito a registrarlo: ricarica la pagina e usa «Aggiorna da Stripe».', 'tw-formulari' ) );
			}
			do_action( 'twf_payment_refunded', (int) $entry['form_id'], $entry_id, $record, $payment );

			$money = self::money( $record['minor'], $record['currency'] );
			if ( in_array( $record['status'], [ 'pending', 'requires_action' ], true ) ) {
				/* translators: %s: amount with currency */
				return [ 'ok' => true, 'state' => 'pending', 'message' => sprintf( __( 'Rimborso di %s chiesto a Stripe: è in corso, lo stato si aggiorna da solo quando Stripe lo conferma.', 'tw-formulari' ), $money ) ];
			}
			if ( 'succeeded' !== $record['status'] ) {
				/* translators: %s: amount with currency */
				return [ 'ok' => false, 'state' => $record['status'], 'message' => sprintf( __( 'Stripe non ha eseguito il rimborso di %s. Trovi il dettaglio nello storico qui sotto.', 'tw-formulari' ), $money ) ];
			}
			return [ 'ok' => true, 'state' => 'succeeded', 'message' => 'stripe' === $record['provider']
				/* translators: %s: amount with currency */
				? sprintf( __( 'Rimborso di %s eseguito su Stripe. Il cliente lo vede sul suo conto in genere entro 5–10 giorni lavorativi.', 'tw-formulari' ), $money )
				/* translators: %s: amount with currency */
				: sprintf( __( 'Rimborso di %s registrato.', 'tw-formulari' ), $money ) ];
		} finally {
			delete_option( $lock );
		}
	}

	/**
	 * Brings the refunds of a Stripe payment in line with Stripe (refunds made on the dashboard, states changed).
	 *
	 * @return array{ok:bool, retry:bool, changed:bool, message:string}
	 */
	public static function sync( string $intent_id ): array {
		if ( ! preg_match( '/^pi_[A-Za-z0-9]{8,80}$/', $intent_id ) ) {
			return [ 'ok' => false, 'retry' => false, 'changed' => false, 'message' => __( 'Pagamento non valido.', 'tw-formulari' ) ];
		}
		$entry = Entries::find_by_intent( $intent_id );
		if ( ! $entry ) {
			// Not one of ours (the same Stripe account may serve a shop too).
			return [ 'ok' => false, 'retry' => false, 'changed' => false, 'message' => __( 'Pagamento non trovato.', 'tw-formulari' ) ];
		}
		$pay  = (array) $entry['payment'];
		$mode = empty( $pay['livemode'] ) ? 'test' : 'live';
		$res  = Stripe::request( 'GET', 'refunds', [ 'payment_intent' => $intent_id, 'limit' => 100 ], [], $mode );
		if ( ! $res['ok'] ) {
			return [ 'ok' => false, 'retry' => $res['code'] >= 500 || 0 === $res['code'], 'changed' => false, 'message' => self::stripe_error( $res, $mode ) ];
		}
		$factor  = Stripe::factor( (string) ( $pay['currency'] ?? '' ) );
		$changed = false;
		foreach ( array_reverse( (array) ( $res['body']['data'] ?? [] ) ) as $r ) {
			if ( ! is_array( $r ) || empty( $r['id'] ) ) {
				continue;
			}
			$record = [
				'id'       => (string) $r['id'],
				'provider' => 'stripe',
				'minor'    => (int) ( $r['amount'] ?? 0 ),
				'amount'   => self::decimal( (int) ( $r['amount'] ?? 0 ), $factor ),
				'currency' => strtoupper( (string) ( $r['currency'] ?? ( $pay['currency'] ?? '' ) ) ),
				'status'   => (string) ( $r['status'] ?? 'pending' ),
				'reason'   => in_array( (string) ( $r['reason'] ?? '' ), self::REASONS, true ) ? (string) $r['reason'] : 'other',
				'note'     => '',
				'by'       => 0,
				'by_name'  => '',
				'at'       => isset( $r['created'] ) ? gmdate( 'Y-m-d H:i:s', (int) $r['created'] ) : gmdate( 'Y-m-d H:i:s' ),
				'origin'   => 'stripe',
			];
			if ( ! empty( $r['failure_reason'] ) ) {
				$record['message'] = mb_substr( (string) $r['failure_reason'], 0, 300 );
			}
			$before = self::find_record( (array) ( Entries::get( (int) $entry['id'] )['payment'] ?? [] ), $record['id'] );
			if ( $before && $before['status'] === $record['status'] && (int) $before['minor'] === $record['minor'] ) {
				continue;
			}
			if ( null !== self::save( (int) $entry['id'], $record ) ) {
				$changed = true;
				if ( ! $before ) {
					do_action( 'twf_payment_refunded', (int) $entry['form_id'], (int) $entry['id'], $record, (array) ( Entries::get( (int) $entry['id'] )['payment'] ?? [] ) );
				}
			}
		}
		return [ 'ok' => true, 'retry' => false, 'changed' => $changed, 'message' => '' ];
	}

	/**
	 * Adds or updates one refund record and sets the entry status from the total given back.
	 * A record that already exists keeps who did it, the reason and the note; Stripe updates amount and state.
	 *
	 * @param array<string, mixed> $record
	 * @return array<string, mixed>|null The new payment details, or null when the entry could not be written.
	 */
	private static function save( int $entry_id, array $record ): ?array {
		for ( $try = 0; $try < 3; $try++ ) {
			$entry = Entries::get( $entry_id );
			if ( ! $entry ) {
				return null;
			}
			$status = (string) $entry['status'];
			if ( ! in_array( $status, [ Entries::STATUS_PAID, Entries::STATUS_PARTLY_REFUNDED, Entries::STATUS_REFUNDED ], true ) ) {
				return null;
			}
			$pay     = (array) $entry['payment'];
			$records = array_values( array_filter( (array) ( $pay['refunds'] ?? [] ), 'is_array' ) );
			$found   = false;
			if ( '' !== (string) $record['id'] ) {
				foreach ( $records as $i => $old ) {
					if ( (string) ( $old['id'] ?? '' ) === (string) $record['id'] ) {
						$records[ $i ] = array_merge( $old, [
							'minor'   => $record['minor'],
							'amount'  => $record['amount'],
							'status'  => $record['status'],
							'message' => $record['message'] ?? ( $old['message'] ?? '' ),
						] );
						$found = true;
						break;
					}
				}
			}
			if ( ! $found ) {
				$records[] = $record;
			}
			// Keep the record short: drop the oldest failed attempts first, never a refund that counts.
			while ( count( $records ) > self::MAX_RECORDS ) {
				$drop = null;
				foreach ( $records as $i => $r ) {
					if ( ! in_array( (string) ( $r['status'] ?? '' ), self::COUNTED, true ) ) {
						$drop = $i;
						break;
					}
				}
				if ( null === $drop ) {
					break;
				}
				array_splice( $records, $drop, 1 );
			}
			$pay['refunds'] = $records;
			$counted        = self::counted_minor( $pay );
			$factor         = Stripe::factor( (string) ( $pay['currency'] ?? '' ) );
			$paid           = isset( $pay['minor'] ) ? (int) $pay['minor'] : (int) round( (float) ( $pay['amount'] ?? 0 ) * $factor );
			$pay['refunded_minor'] = $counted;
			$pay['refunded']       = $counted > 0 ? self::decimal( $counted, $factor ) : '';
			$to = $counted <= 0 ? Entries::STATUS_PAID : ( $counted >= $paid ? Entries::STATUS_REFUNDED : Entries::STATUS_PARTLY_REFUNDED );
			if ( Entries::transition( $entry_id, [ $status ], $to, $pay ) ) {
				return $pay;
			}
		}
		return null;
	}

	/** @param array<string, mixed> $pay */
	public static function counted_minor( array $pay ): int {
		$sum = 0;
		foreach ( (array) ( $pay['refunds'] ?? [] ) as $r ) {
			if ( is_array( $r ) && in_array( (string) ( $r['status'] ?? '' ), self::COUNTED, true ) ) {
				$sum += (int) ( $r['minor'] ?? 0 );
			}
		}
		return $sum;
	}

	/**
	 * @param array<string, mixed> $pay
	 * @return array<string, mixed>|null
	 */
	private static function find_record( array $pay, string $id ): ?array {
		foreach ( (array) ( $pay['refunds'] ?? [] ) as $r ) {
			if ( is_array( $r ) && (string) ( $r['id'] ?? '' ) === $id ) {
				return $r;
			}
		}
		return null;
	}

	/** "50", "50.5", "50,50", "1'000.00", "CHF 25" → minor units; 0 when it is not a usable amount. */
	public static function parse_minor( string $input, int $factor ): int {
		$v = preg_replace( '/[^0-9.,]/', '', $input );
		if ( '' === $v ) {
			return 0;
		}
		// The last . or , is the decimal separator when followed by one or two digits; the others group thousands.
		if ( preg_match( '/^(.*)[.,](\d{1,2})$/', $v, $m ) ) {
			$int  = preg_replace( '/[.,]/', '', $m[1] );
			$frac = str_pad( $m[2], 2, '0' );
		} else {
			$int  = preg_replace( '/[.,]/', '', $v );
			$frac = '00';
		}
		if ( '' === $int ) {
			$int = '0';
		}
		if ( 1 === $factor ) {
			return (int) $int;
		}
		return (int) $int * 100 + (int) $frac;
	}

	public static function decimal( int $minor, int $factor ): string {
		return 1 === $factor ? (string) $minor : number_format( $minor / 100, 2, '.', '' );
	}

	public static function money( int $minor, string $currency ): string {
		$factor = Stripe::factor( $currency );
		return number_format_i18n( $minor / $factor, 1 === $factor ? 0 : 2 ) . ' ' . strtoupper( $currency );
	}

	/** @param array{ok:bool, code:int, body:array<string,mixed>, error:string} $res */
	private static function stripe_error( array $res, string $mode ): string {
		$message = sprintf(
			/* translators: %s: error message from Stripe */
			__( 'Stripe ha risposto con un errore: %s', 'tw-formulari' ),
			(string) $res['error']
		);
		if ( 0 === (int) $res['code'] ) {
			return __( 'Non riesco a raggiungere Stripe in questo momento. Non è stato rimborsato nulla: riprova tra qualche minuto.', 'tw-formulari' );
		}
		if ( in_array( (int) $res['code'], [ 401, 403 ], true ) && Stripe::is_restricted_key( $mode ) ) {
			$message .= ' ' . __( 'La chiave segreta è «con restrizioni» (rk_…): su Stripe, in Sviluppatori → Chiavi API, modifica la chiave e imposta «Refunds» su «Scrittura» (la chiave resta la stessa), poi riprova.', 'tw-formulari' );
		}
		return $message;
	}

	/** @return array{ok:bool, message:string, state:string} */
	private static function fail( string $message ): array {
		return [ 'ok' => false, 'message' => $message, 'state' => '' ];
	}
}
