<?php
/**
 * Turns what a visitor sent into clean, validated values.
 *
 * Pure logic (no database, no files, no mail): sanitise every field, apply the show/hide rules, compute the
 * calculations, validate what is visible and drop what is hidden. The result is what gets stored and e-mailed.
 *
 * @package TicinoWeb\TWFormulari\Builder
 */

namespace TicinoWeb\TWFormulari\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Processor {

	/**
	 * @param array<string, mixed> $def   Normalised definition (see Definition::normalize()).
	 * @param array<string, mixed> $input Raw values keyed by field id (typically $_POST, already unslashed).
	 * @return array{
	 *   ok: bool,
	 *   errors: array<string, string>,
	 *   values: array<string, mixed>,
	 *   visible: array<string, bool>,
	 *   required: array<string, bool>,
	 *   uploads: string[]
	 * } `values` holds only visible fields (calculations included); `uploads` lists the visible upload field ids,
	 * which Uploads validates separately.
	 */
	public static function process( array $def, array $input ): array {
		$fields = array_values( array_filter( (array) ( $def['fields'] ?? [] ), 'is_array' ) );
		$by_id  = Definition::field_map( $def );

		// 1. Sanitise what the visitor sent. The shape is never trusted.
		$values = [];
		foreach ( $fields as $field ) {
			$type = (string) $field['type'];
			$id   = (string) $field['id'];
			if ( ! FieldTypes::is_input( $type ) || in_array( $type, [ 'upload', 'calculation' ], true ) ) {
				continue;
			}
			if ( 'hidden' === $type ) {
				$sent         = array_key_exists( $id, $input ) ? $input[ $id ] : ( $field['default'] ?? '' );
				$values[ $id ] = FieldTypes::sanitize_value( $field, $sent );
				continue;
			}
			$values[ $id ] = FieldTypes::sanitize_value( $field, $input[ $id ] ?? null );
		}

		// 2. Visibility and calculations depend on each other: settle them in two rounds.
		$visible   = Conditions::visible_map( $fields, $values );
		$effective = self::effective( $values, $visible );
		$effective = self::with_calculations( $fields, $by_id, $effective, $visible );
		$visible   = Conditions::visible_map( $fields, $effective );
		$effective = self::effective( $effective, $visible );
		$effective = self::with_calculations( $fields, $by_id, $effective, $visible );

		// 3. Validate what is visible.
		$errors   = [];
		$uploads  = [];
		$required = [];
		foreach ( $fields as $field ) {
			$id   = (string) $field['id'];
			$type = (string) $field['type'];
			if ( ! FieldTypes::is_input( $type ) || empty( $visible[ $id ] ) ) {
				continue;
			}
			// A rule can make the field required or optional depending on other answers.
			$field['required'] = Conditions::is_required( $field, $by_id, $effective );
			$required[ $id ]   = $field['required'];
			if ( 'upload' === $type ) {
				$uploads[] = $id;
				continue;
			}
			$error = FieldTypes::validate_value( $field, $effective[ $id ] ?? null );
			if ( null !== $error ) {
				$errors[ $id ] = $error;
			}
		}

		// 4. Keep only visible values.
		$clean = [];
		foreach ( $fields as $field ) {
			$id = (string) $field['id'];
			if ( ! empty( $visible[ $id ] ) && array_key_exists( $id, $effective ) && FieldTypes::is_input( (string) $field['type'] ) ) {
				$clean[ $id ] = $effective[ $id ];
			}
		}

		return [
			'ok'      => 0 === count( $errors ),
			'errors'  => $errors,
			'values'  => $clean,
			'visible' => $visible,
			'required' => $required,
			'uploads' => $uploads,
		];
	}

	/**
	 * Values with the hidden fields blanked out.
	 *
	 * @param array<string, mixed> $values
	 * @param array<string, bool>  $visible
	 * @return array<string, mixed>
	 */
	private static function effective( array $values, array $visible ): array {
		foreach ( $values as $id => $value ) {
			if ( isset( $visible[ $id ] ) && ! $visible[ $id ] ) {
				unset( $values[ $id ] );
			}
		}
		return $values;
	}

	/**
	 * Adds the result of every visible calculation field (in page order, so one can use the previous ones).
	 *
	 * @param array<int, array<string, mixed>>    $fields
	 * @param array<string, array<string, mixed>> $by_id
	 * @param array<string, mixed>                $values
	 * @param array<string, bool>                 $visible
	 * @return array<string, mixed>
	 */
	private static function with_calculations( array $fields, array $by_id, array $values, array $visible ): array {
		foreach ( $fields as $field ) {
			if ( 'calculation' !== ( $field['type'] ?? '' ) ) {
				continue;
			}
			$id = (string) $field['id'];
			if ( isset( $visible[ $id ] ) && ! $visible[ $id ] ) {
				unset( $values[ $id ] );
				continue;
			}
			$result        = Calculator::evaluate( (string) ( $field['formula'] ?? '' ), $by_id, $values );
			$values[ $id ] = null === $result ? '0' : number_format( $result, (int) ( $field['decimals'] ?? 2 ), '.', '' );
		}
		return $values;
	}
}
