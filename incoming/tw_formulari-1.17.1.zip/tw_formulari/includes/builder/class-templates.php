<?php
/**
 * Starting points offered when a new form is created ("Parti da un modello").
 *
 * Only generic content: nothing here belongs to a customer. The administrator's own e-mail address (from the site
 * settings) is used as the default recipient of the notification.
 *
 * @package TicinoWeb\TWFormulari\Builder
 */

namespace TicinoWeb\TWFormulari\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Templates {

	/**
	 * @return array<string, array{label:string, description:string}> Template key => name and short description.
	 */
	public static function catalog(): array {
		return [
			'blank'   => [ 'label' => __( 'Modulo vuoto', 'tw-formulari' ), 'description' => __( 'Parti da zero e aggiungi i campi che ti servono.', 'tw-formulari' ) ],
			'contact' => [ 'label' => __( 'Contatto', 'tw-formulari' ), 'description' => __( 'Nome, e-mail e messaggio, con avviso a te e conferma al cliente.', 'tw-formulari' ) ],
			'quote'   => [ 'label' => __( 'Richiesta di preventivo', 'tw-formulari' ), 'description' => __( 'Dati del cliente, tipo di richiesta, allegato e consenso, su due pagine.', 'tw-formulari' ) ],
			'event'   => [ 'label' => __( 'Iscrizione a un evento', 'tw-formulari' ), 'description' => __( 'Dati dei partecipanti, scelta con prezzo e totale che si calcola da solo.', 'tw-formulari' ) ],
		];
	}

	/**
	 * Definition (not yet normalised) of a template.
	 *
	 * @return array<string, mixed>
	 */
	public static function get( string $key ): array {
		$admin = (string) get_option( 'admin_email' );

		$notifications = [
			[
				'id' => 'avviso', 'name' => __( 'Avviso a te', 'tw-formulari' ), 'enabled' => true,
				'to' => [ $admin ], 'to_fields' => [],
				'subject' => __( 'Nuova richiesta dal sito', 'tw-formulari' ),
				'body' => '{all_fields}', 'reply_to_field' => 'email', 'attach_files' => true,
			],
			[
				'id' => 'conferma', 'name' => __( 'Conferma al cliente', 'tw-formulari' ), 'enabled' => true,
				'to' => [], 'to_fields' => [ 'email' ],
				'subject' => __( 'Abbiamo ricevuto la tua richiesta', 'tw-formulari' ),
				'body' => __( "Grazie, abbiamo ricevuto la tua richiesta e ti risponderemo il prima possibile.\n\nEcco un riepilogo:\n{all_fields}", 'tw-formulari' ),
			],
		];

		switch ( $key ) {
			case 'contact':
				return [
					'fields' => [
						[ 'id' => 'nome', 'type' => 'name', 'label' => __( 'Nome e cognome', 'tw-formulari' ), 'required' => true ],
						[ 'id' => 'email', 'type' => 'email', 'label' => __( 'E-mail', 'tw-formulari' ), 'required' => true, 'width' => 'half' ],
						[ 'id' => 'telefono', 'type' => 'phone', 'label' => __( 'Telefono', 'tw-formulari' ), 'width' => 'half' ],
						[ 'id' => 'messaggio', 'type' => 'textarea', 'label' => __( 'Messaggio', 'tw-formulari' ), 'required' => true ],
						[ 'id' => 'privacy', 'type' => 'gdpr', 'label' => __( 'Ho letto l’informativa sulla privacy', 'tw-formulari' ) ],
					],
					'notifications' => $notifications,
					'confirmation'  => [ 'type' => 'message', 'message' => __( 'Grazie! Abbiamo ricevuto la tua richiesta.', 'tw-formulari' ) ],
				];

			case 'quote':
				return [
					'fields' => [
						[ 'id' => 'nome', 'type' => 'name', 'label' => __( 'Nome e cognome', 'tw-formulari' ), 'required' => true ],
						[ 'id' => 'azienda', 'type' => 'text', 'label' => __( 'Azienda (se presente)', 'tw-formulari' ) ],
						[ 'id' => 'email', 'type' => 'email', 'label' => __( 'E-mail', 'tw-formulari' ), 'required' => true, 'width' => 'half' ],
						[ 'id' => 'telefono', 'type' => 'phone', 'label' => __( 'Telefono', 'tw-formulari' ), 'width' => 'half' ],
						[ 'id' => 'pagina2', 'type' => 'page_break', 'label' => __( 'La tua richiesta', 'tw-formulari' ) ],
						[ 'id' => 'tipo', 'type' => 'select', 'label' => __( 'Di cosa hai bisogno?', 'tw-formulari' ), 'required' => true, 'options' => [ __( 'Informazioni', 'tw-formulari' ), __( 'Preventivo', 'tw-formulari' ), __( 'Altro', 'tw-formulari' ) ] ],
						[ 'id' => 'descrizione', 'type' => 'textarea', 'label' => __( 'Descrivi la richiesta', 'tw-formulari' ), 'required' => true ],
						[ 'id' => 'allegato', 'type' => 'upload', 'label' => __( 'Allegato (facoltativo)', 'tw-formulari' ), 'extensions' => 'pdf,jpg,png,docx', 'max_size_mb' => 5, 'max_files' => 3 ],
						[ 'id' => 'privacy', 'type' => 'gdpr', 'label' => __( 'Ho letto l’informativa sulla privacy', 'tw-formulari' ) ],
					],
					'notifications' => $notifications,
					'confirmation'  => [ 'type' => 'message', 'message' => __( 'Grazie! Ti contatteremo con il preventivo.', 'tw-formulari' ) ],
				];

			case 'event':
				return [
					'fields' => [
						[ 'id' => 'nome', 'type' => 'name', 'label' => __( 'Nome e cognome del partecipante', 'tw-formulari' ), 'required' => true ],
						[ 'id' => 'email', 'type' => 'email', 'label' => __( 'E-mail', 'tw-formulari' ), 'required' => true, 'width' => 'half' ],
						[ 'id' => 'telefono', 'type' => 'phone', 'label' => __( 'Telefono', 'tw-formulari' ), 'width' => 'half' ],
						[ 'id' => 'quota', 'type' => 'select', 'label' => __( 'Quota di partecipazione', 'tw-formulari' ), 'required' => true, 'options' => [
							[ 'label' => __( 'Adulto (CHF 30)', 'tw-formulari' ), 'value' => 'adulto', 'calc' => '30' ],
							[ 'label' => __( 'Ragazzo (CHF 15)', 'tw-formulari' ), 'value' => 'ragazzo', 'calc' => '15' ],
						] ],
						[ 'id' => 'persone', 'type' => 'number', 'label' => __( 'Numero di persone', 'tw-formulari' ), 'required' => true, 'min' => '1', 'default' => '1' ],
						[ 'id' => 'totale', 'type' => 'calculation', 'label' => __( 'Totale (CHF)', 'tw-formulari' ), 'formula' => '{quota} * {persone}', 'decimals' => 2 ],
						[ 'id' => 'privacy', 'type' => 'gdpr', 'label' => __( 'Ho letto l’informativa sulla privacy', 'tw-formulari' ) ],
					],
					'notifications' => $notifications,
					'confirmation'  => [ 'type' => 'message', 'message' => __( 'Grazie! La tua iscrizione è stata registrata.', 'tw-formulari' ) ],
				];
		}

		return [ 'fields' => [], 'notifications' => [], 'confirmation' => [ 'type' => 'message', 'message' => __( 'Grazie! Abbiamo ricevuto la tua richiesta.', 'tw-formulari' ) ] ];
	}
}
