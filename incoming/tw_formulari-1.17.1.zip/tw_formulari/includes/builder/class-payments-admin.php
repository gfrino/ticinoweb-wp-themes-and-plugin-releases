<?php
/**
 * "Pagamenti" screen: the mode in use (test or live), the Stripe keys of each mode, the webhook address and a
 * connection test.
 *
 * Test and live keys are kept apart, so switching mode never means typing them again. Values defined in
 * wp-config.php (TWF_STRIPE_MODE and TWF_STRIPE_{TEST|LIVE}_{PUBLISHABLE_KEY|SECRET_KEY|WEBHOOK_SECRET}) win over the
 * saved ones and are shown as read-only. Saved secrets are never printed back: the field stays empty and an empty
 * value means "keep what is saved".
 *
 * @package TicinoWeb\TWFormulari\Builder
 */

namespace TicinoWeb\TWFormulari\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class PaymentsAdmin {

	public const PAGE = 'tw-formulari-payments';

	public static function init(): void {
		add_action( 'admin_menu', [ self::class, 'register_menu' ], 25 );
		add_action( 'admin_post_twf_stripe_save', [ self::class, 'handle_save' ] );
		add_action( 'admin_post_twf_stripe_webhook', [ self::class, 'handle_webhook' ] );
		add_action( 'admin_post_twf_methods_save', [ self::class, 'handle_methods' ] );
	}

	public static function register_menu(): void {
		add_submenu_page( 'tw-formulari', __( 'Pagamenti', 'tw-formulari' ), __( 'Pagamenti', 'tw-formulari' ), 'manage_options', self::PAGE, [ self::class, 'render' ] );
	}

	public static function url( array $args = [] ): string {
		return add_query_arg( $args, admin_url( 'admin.php?page=' . self::PAGE ) );
	}

	/** Shows a saved secret as "…last four" (never the whole). */
	private static function hint( string $value ): string {
		return '' === $value ? '' : '…' . substr( $value, -4 );
	}

	/** @return array<string, array{label:string, placeholder:array<string,string>, help:string, secret:bool, required:bool}> */
	private static function fields(): array {
		return [
			'publishable' => [
				'label'    => __( 'Chiave pubblica', 'tw-formulari' ),
				'help'     => __( 'Si può mostrare: serve al modulo per aprire i campi di pagamento.', 'tw-formulari' ),
				'secret'   => false,
				'required' => true,
			],
			'secret'      => [
				'label'    => __( 'Chiave segreta', 'tw-formulari' ),
				'help'     => __( 'Resta sul server, non compare mai nella pagina. Va bene anche una chiave con restrizioni (rk_…) con permessi su PaymentIntent.', 'tw-formulari' ),
				'secret'   => true,
				'required' => true,
			],
			'webhook'     => [
				'label'    => __( 'Segreto del webhook', 'tw-formulari' ),
				'help'     => __( 'Controlla che gli avvisi di pagamento arrivino davvero da Stripe. Ogni modalità ha il suo.', 'tw-formulari' ),
				'secret'   => true,
				'required' => false,
			],
		];
	}

	private static function placeholder( string $mode, string $key ): string {
		$prefix = [ 'publishable' => 'pk_', 'secret' => 'sk_', 'webhook' => 'whsec_' ][ $key ];
		return 'webhook' === $key ? 'whsec_…' : $prefix . $mode . '_…';
	}

	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Non hai il permesso di vedere questa pagina.', 'tw-formulari' ) );
		}
		$methods = PaymentMethods::all();
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- which panel to show.
		$current = isset( $_GET['method'] ) ? sanitize_key( wp_unslash( $_GET['method'] ) ) : PaymentMethods::STRIPE;
		if ( PaymentMethods::STRIPE !== $current && ! PaymentMethods::get( $current ) ) {
			$current = PaymentMethods::STRIPE;
		}

		echo '<div class="wrap twf-wrap twf-pay"><h1>' . esc_html__( 'Pagamenti', 'tw-formulari' ) . '</h1>';
		echo '<p class="twf-lead">' . esc_html__( 'Come i tuoi clienti possono pagare. Scegli un metodo a sinistra per impostarlo; ogni modulo decide quali offrire nella sua scheda Pagamento.', 'tw-formulari' ) . '</p>';
		self::notices();

		echo '<div class="twf-payhub">';
		self::overview( $current, $methods );
		echo '<section class="twf-payhub__detail">';
		if ( PaymentMethods::STRIPE === $current ) {
			self::stripe_panel();
		} else {
			self::method_panel( (array) PaymentMethods::get( $current ) );
		}
		echo '</section></div></div>';
	}

	/** Stripe: status and mode, the keys of the mode in use, the webhook, how to set it up. */
	private static function stripe_panel(): void {
		$selected = Stripe::selected_mode();
		$const    = Stripe::from_constants();
		$ready    = Stripe::is_configured();
		$active   = Stripe::keys( $selected );

		echo '<header class="twf-payhub__head">' . self::icon( 'card' ) . '<div><h2>Stripe</h2><p>' . esc_html__( 'Carte, Apple Pay, Google Pay e TWINT: il cliente paga subito, online.', 'tw-formulari' ) . '</p></div></header>';
		echo '<div class="twf-pay__cols"><div class="twf-pay__main">';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" autocomplete="off" id="twf-pay-form" data-prev="' . esc_attr( $selected ) . '" data-confirm-live="' . esc_attr__( 'Stai passando alla modalità REALE: da questo momento i pagamenti addebitano davvero i clienti. Continuare?', 'tw-formulari' ) . '">';
		echo '<input type="hidden" name="action" value="twf_stripe_save">';
		wp_nonce_field( 'twf_stripe_save' );

		// ---- Status and switch
		echo '<div class="twf-pay__hero twf-pay__hero--' . esc_attr( $ready ? $selected : 'off' ) . '">';
		echo '<div class="twf-pay__status">';
		if ( ! $ready ) {
			echo '<span class="twf-pay__pill twf-pay__pill--off">' . esc_html__( 'Non pronto', 'tw-formulari' ) . '</span>';
			echo '<p>' . esc_html( 'live' === $selected
				? __( 'È scelta la modalità reale, ma mancano la chiave pubblica o quella segreta reali. Finché non le inserisci i moduli con pagamento non accettano invii.', 'tw-formulari' )
				: __( 'È scelta la modalità di prova, ma mancano la chiave pubblica o quella segreta di prova. Finché non le inserisci i moduli con pagamento non accettano invii.', 'tw-formulari' ) ) . '</p>';
		} elseif ( 'live' === $selected ) {
			echo '<span class="twf-pay__pill twf-pay__pill--live">' . esc_html__( 'REALE', 'tw-formulari' ) . '</span>';
			echo '<p>' . esc_html__( 'I pagamenti addebitano davvero i clienti.', 'tw-formulari' ) . '</p>';
		} else {
			echo '<span class="twf-pay__pill twf-pay__pill--test">' . esc_html__( 'PROVA', 'tw-formulari' ) . '</span>';
			echo '<p>' . esc_html__( 'Nessun addebito reale: usa le carte di prova di Stripe.', 'tw-formulari' ) . '</p>';
		}
		echo '<ul class="twf-pay__checks">';
		self::check( __( 'Chiave pubblica', 'tw-formulari' ), Stripe::key_is_valid( $selected, 'publishable', $active['publishable'] ), true );
		self::check( __( 'Chiave segreta', 'tw-formulari' ), Stripe::key_is_valid( $selected, 'secret', $active['secret'] ), true );
		self::check( __( 'Webhook', 'tw-formulari' ), Stripe::key_is_valid( $selected, 'webhook', $active['webhook'] ), false );
		echo '</ul></div>';

		echo '<div class="twf-pay__switch"><span class="twf-pay__switch-label">' . esc_html__( 'Modalità in uso', 'tw-formulari' ) . '</span>';
		if ( $const['mode'] ) {
			echo '<strong>' . esc_html( 'live' === $selected ? __( 'Reale (live)', 'tw-formulari' ) : __( 'Prova (test)', 'tw-formulari' ) ) . '</strong> <span class="description">' . esc_html__( 'definita in wp-config.php (TWF_STRIPE_MODE)', 'tw-formulari' ) . '</span>';
			echo '<input type="hidden" name="twf_mode" value="' . esc_attr( $selected ) . '">';
		} else {
			echo '<div class="twf-seg" role="radiogroup" aria-label="' . esc_attr__( 'Modalità in uso', 'tw-formulari' ) . '">';
			foreach ( [ 'test' => __( 'Prova (test)', 'tw-formulari' ), 'live' => __( 'Reale (live)', 'tw-formulari' ) ] as $mode => $label ) {
				echo '<label class="twf-seg__opt twf-seg__opt--' . esc_attr( $mode ) . '"><input type="radio" name="twf_mode" value="' . esc_attr( $mode ) . '"' . checked( $selected, $mode, false ) . '><span>' . esc_html( $label ) . '</span></label>';
			}
			echo '</div>';
		}
		echo '<p class="description">' . esc_html__( 'Sotto vedi le chiavi della modalità scelta. Cambiare modalità non cancella quelle dell’altra: restano salvate. Ricordati di salvare.', 'tw-formulari' ) . '</p></div>';
		echo '</div>';

		// ---- Keys of each mode
		echo '<div class="twf-pay__grid">';
		foreach ( [ 'test' => __( 'Chiavi di prova', 'tw-formulari' ), 'live' => __( 'Chiavi reali', 'tw-formulari' ) ] as $mode => $title ) {
			self::mode_card( $mode, $title, $mode === $selected, $const[ $mode ] );
		}
		echo '</div>';

		echo '<p class="twf-pay__actions">';
		echo '<button type="submit" name="twf_do" value="save" class="button button-primary">' . esc_html__( 'Salva', 'tw-formulari' ) . '</button> ';
		echo '<button type="submit" name="twf_do" value="test" class="button">' . esc_html__( 'Salva e prova il collegamento', 'tw-formulari' ) . '</button>';
		echo '</p></form>';

		echo '</div><div class="twf-pay__side">';

		// ---- One click: create the webhook on Stripe (only when the keys of the mode in use are complete)
		if ( $ready ) {
			self::webhook_card( $selected, $const[ $selected ]['webhook'], Stripe::key_is_valid( $selected, 'webhook', $active['webhook'] ) );
		}

		// ---- What to set up on Stripe
		$url = Stripe::webhook_url();
		echo '<details class="twf-pay__card twf-pay__help"><summary>' . esc_html__( 'Come si configura Stripe, passo per passo', 'tw-formulari' ) . '</summary><ol>';
		echo '<li><strong>' . esc_html__( 'Chiavi.', 'tw-formulari' ) . '</strong> ' . esc_html__( 'In Sviluppatori → Chiavi API (una coppia per la modalità di prova, una per quella reale).', 'tw-formulari' ) . '</li>';
		echo '<li><strong>' . esc_html__( 'Webhook.', 'tw-formulari' ) . '</strong> ' . esc_html__( 'Il modo più semplice è il pulsante «Imposta il webhook su Stripe», che compare qui sopra quando le chiavi sono complete. Per farlo a mano: in Sviluppatori → Webhook aggiungi un endpoint con questo indirizzo. Stripe vuole un endpoint per modalità: crealo in Prova e di nuovo in Reale, poi incolla ciascun segreto di firma (whsec_…) nella scheda giusta.', 'tw-formulari' );
		echo '<div class="twf-pay__copy"><input type="text" readonly class="code" id="twf-webhook-url" value="' . esc_attr( $url ) . '"><button type="button" class="button" id="twf-copy-webhook" data-done="' . esc_attr__( 'Copiato', 'tw-formulari' ) . '">' . esc_html__( 'Copia', 'tw-formulari' ) . '</button></div>';
		echo '<p class="twf-pay__events">' . esc_html__( 'Eventi da scegliere:', 'tw-formulari' ) . ' <code>payment_intent.succeeded</code> <code>payment_intent.payment_failed</code> <code>payment_intent.canceled</code></p></li>';
		echo '<li><strong>' . esc_html__( 'Metodi di pagamento.', 'tw-formulari' ) . '</strong> ' . esc_html__( 'In Impostazioni → Metodi di pagamento attiva carte, Apple Pay, Google Pay e TWINT (TWINT solo in franchi svizzeri, CHF).', 'tw-formulari' ) . '</li>';
		echo '<li><strong>' . esc_html__( 'Prima la prova.', 'tw-formulari' ) . '</strong> ' . esc_html__( 'Paga con la carta di prova 4242 4242 4242 4242 (rifiutata: 4000 0000 0000 0002), controlla che la compilazione diventi «Pagata» e che arrivino le e-mail. Poi passa a Reale.', 'tw-formulari' ) . '</li>';
		echo '</ol>';
		echo '<p class="description">' . esc_html__( 'Per le chiavi in wp-config.php: TWF_STRIPE_MODE (test o live) e, per ogni modalità, TWF_STRIPE_TEST_… / TWF_STRIPE_LIVE_… con PUBLISHABLE_KEY, SECRET_KEY e WEBHOOK_SECRET. Quelle definite lì non si modificano da questa schermata.', 'tw-formulari' ) . '</p></details>';
		echo '</div></div>'; // .twf-pay__side, .twf-pay__cols

		echo '<script>(function(){var f=document.getElementById("twf-pay-form");if(!f){return;}'
			. 'f.addEventListener("submit",function(e){var c=f.querySelector("input[name=twf_mode]:checked");if(c&&c.value==="live"&&f.getAttribute("data-prev")!=="live"&&!window.confirm(f.getAttribute("data-confirm-live"))){e.preventDefault();}});'
			. 'var b=document.getElementById("twf-copy-webhook");if(b){b.addEventListener("click",function(){var i=document.getElementById("twf-webhook-url");i.select();var d=function(){var t=b.textContent;b.textContent=b.getAttribute("data-done");setTimeout(function(){b.textContent=t;},1800);};if(navigator.clipboard){navigator.clipboard.writeText(i.value).then(d);}else{document.execCommand("copy");d();}});}'
			. 'f.addEventListener("change",function(e){if(e.target.name==="twf_mode"){f.querySelectorAll(".twf-pay__card[data-mode]").forEach(function(c){c.classList.toggle("is-active",c.getAttribute("data-mode")===e.target.value);});}});'
			. '})();</script>';
	}

	/** Small line icons (inline, decorative). */
	private static function icon( string $name ): string {
		$paths = [
			'card' => '<rect x="2.5" y="5" width="19" height="14" rx="2.5"/><path d="M2.5 10h19M6.5 15h4"/>',
			'bank' => '<path d="M3 10l9-6 9 6M5 10v8M9.5 10v8M14.5 10v8M19 10v8M3 20h18"/>',
			'cash' => '<rect x="2.5" y="6" width="19" height="12" rx="2"/><circle cx="12" cy="12" r="2.7"/><path d="M6 9.5v.01M18 14.5v.01"/>',
		];
		return '<span class="twf-pm__icon" aria-hidden="true"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">' . ( $paths[ $name ] ?? $paths['cash'] ) . '</svg></span>';
	}

	/**
	 * The list on the left: every way to pay with its state, and the buttons to add one.
	 *
	 * @param array<int, array<string, mixed>> $methods
	 */
	private static function overview( string $current, array $methods ): void {
		echo '<nav class="twf-payhub__list" aria-label="' . esc_attr__( 'Metodi di pagamento', 'tw-formulari' ) . '"><p class="twf-payhub__title">' . esc_html__( 'Metodi di pagamento', 'tw-formulari' ) . '</p>';

		if ( ! Stripe::is_configured() ) {
			$tone = 'off';
			$text = __( 'Non configurato', 'tw-formulari' );
		} elseif ( 'live' === Stripe::selected_mode() ) {
			$tone = 'live';
			$text = __( 'Pronto · reale', 'tw-formulari' );
		} else {
			$tone = 'test';
			$text = __( 'Pronto · prova', 'tw-formulari' );
		}
		self::pm_card( PaymentMethods::STRIPE, 'card', 'Stripe', __( 'Carte, Apple Pay, Google Pay, TWINT', 'tw-formulari' ), $text, $tone, $current );

		foreach ( $methods as $m ) {
			$bank    = 'bank' === $m['type'];
			$missing = $bank && ( '' === (string) $m['iban'] || '' === (string) $m['beneficiary'] );
			if ( empty( $m['enabled'] ) ) {
				$tone = 'off';
				$text = __( 'Spento', 'tw-formulari' );
			} elseif ( $missing ) {
				$tone = 'warn';
				$text = __( 'Mancano i dati', 'tw-formulari' );
			} else {
				$tone = 'ok';
				$text = __( 'Attivo', 'tw-formulari' );
			}
			if ( $bank ) {
				$sub = '' !== (string) $m['iban'] ? 'IBAN ' . substr( PaymentMethods::format_iban( (string) $m['iban'] ), 0, 9 ) . '…' : __( 'Bonifico bancario', 'tw-formulari' );
			} else {
				$sub = '' !== (string) $m['note'] ? wp_html_excerpt( (string) $m['note'], 38, '…' ) : __( 'Altro metodo', 'tw-formulari' );
			}
			self::pm_card( (string) $m['id'], $bank ? 'bank' : 'cash', (string) $m['label'], $sub, $text, $tone, $current );
		}

		if ( count( $methods ) < PaymentMethods::MAX ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="twf-payhub__add"><input type="hidden" name="action" value="twf_methods_save">';
			wp_nonce_field( 'twf_methods_save' );
			echo '<p>' . esc_html__( 'Aggiungi un metodo', 'tw-formulari' ) . '</p>';
			echo '<button type="submit" name="twf_add" value="bank" class="button">' . self::icon( 'bank' ) . esc_html__( 'Bonifico bancario', 'tw-formulari' ) . '</button> ';
			echo '<button type="submit" name="twf_add" value="custom" class="button">' . self::icon( 'cash' ) . esc_html__( 'Altro metodo', 'tw-formulari' ) . '</button>';
			echo '</form>';
		}
		echo '</nav>';
	}

	private static function pm_card( string $id, string $icon, string $name, string $sub, string $status, string $tone, string $current ): void {
		$selected = $id === $current;
		echo '<a class="twf-pm twf-pm--' . esc_attr( $tone ) . ( $selected ? ' is-selected' : '' ) . '" href="' . esc_url( self::url( [ 'method' => $id ] ) ) . '"' . ( $selected ? ' aria-current="page"' : '' ) . '>';
		echo self::icon( $icon );
		echo '<span class="twf-pm__text"><strong>' . esc_html( $name ) . '</strong><small>' . esc_html( $sub ) . '</small></span>';
		echo '<span class="twf-pm__status"><i aria-hidden="true"></i>' . esc_html( $status ) . '</span></a>';
	}

	/**
	 * The settings of one manual method (bank transfer, cash…).
	 *
	 * @param array<string, mixed> $m
	 */
	private static function method_panel( array $m ): void {
		$bank = 'bank' === ( $m['type'] ?? '' );
		$id   = (string) $m['id'];
		$n    = 'twf_m[' . $id . ']';

		echo '<header class="twf-payhub__head">' . self::icon( $bank ? 'bank' : 'cash' ) . '<div><h2>' . esc_html( (string) $m['label'] ) . '</h2><p>' . esc_html( $bank
			? __( 'Il cliente riceve i dati per fare il bonifico e tu segni la compilazione come pagata quando arriva.', 'tw-formulari' )
			: __( 'Un modo di pagare senza passare dal sito: il cliente legge le tue istruzioni e tu segni la compilazione come pagata.', 'tw-formulari' ) ) . '</p></div></header>';

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" autocomplete="off" class="twf-method-form">';
		echo '<input type="hidden" name="action" value="twf_methods_save"><input type="hidden" name="twf_current" value="' . esc_attr( $id ) . '">';
		wp_nonce_field( 'twf_methods_save' );

		echo '<label class="twf-method__switch"><input type="checkbox" name="' . esc_attr( $n ) . '[enabled]" value="1"' . checked( ! empty( $m['enabled'] ), true, false ) . '> <span><strong>' . esc_html__( 'Attivo', 'tw-formulari' ) . '</strong> — ' . esc_html__( 'i moduli possono offrire questo metodo', 'tw-formulari' ) . '</span></label>';

		echo '<div class="twf-method__grid">';
		self::method_field( $n, 'label', __( 'Nome che vede il cliente', 'tw-formulari' ), (string) $m['label'] );
		if ( $bank ) {
			self::method_field( $n, 'beneficiary', __( 'Beneficiario', 'tw-formulari' ), (string) $m['beneficiary'] );
			self::method_field( $n, 'address', __( 'Indirizzo del beneficiario (una riga per riga)', 'tw-formulari' ), (string) $m['address'], 'textarea' );
			$iban_ok = '' === (string) $m['iban'] || PaymentMethods::iban_valid( (string) $m['iban'] );
			self::method_field( $n, 'iban', __( 'IBAN', 'tw-formulari' ), PaymentMethods::format_iban( (string) $m['iban'] ), 'text', $iban_ok ? '' : __( 'Questo IBAN non sembra valido: controllalo.', 'tw-formulari' ) );
			self::method_field( $n, 'bic', __( 'BIC / SWIFT', 'tw-formulari' ), (string) $m['bic'] );
			self::method_field( $n, 'bank', __( 'Banca (facoltativo)', 'tw-formulari' ), (string) $m['bank'] );
			self::method_field( $n, 'reference', __( 'Causale del bonifico', 'tw-formulari' ), (string) $m['reference'], 'text', '', __( 'Puoi usare {entry_id} (numero della compilazione), {form_title} e {site_name}.', 'tw-formulari' ) );
		}
		self::method_field( $n, 'note', $bank ? __( 'Testo sotto i dati (facoltativo)', 'tw-formulari' ) : __( 'Istruzioni per il cliente', 'tw-formulari' ), (string) $m['note'], 'textarea', '', $bank ? __( 'Per esempio: «La tua iscrizione sarà confermata alla ricezione del pagamento».', 'tw-formulari' ) : __( 'Per esempio: «Paghi in contanti al ritiro».', 'tw-formulari' ) );
		echo '</div>';

		echo '<p class="twf-pay__actions twf-method__actions">';
		echo '<button type="submit" name="twf_do" value="save" class="button button-primary">' . esc_html__( 'Salva', 'tw-formulari' ) . '</button>';
		echo '<button type="submit" name="twf_delete" value="' . esc_attr( $id ) . '" class="button twf-danger" data-confirm="' . esc_attr__( 'Eliminare questo metodo? I moduli che lo offrivano smettono di offrirlo.', 'tw-formulari' ) . '" onclick="return confirm(this.dataset.confirm)">' . esc_html__( 'Elimina questo metodo', 'tw-formulari' ) . '</button>';
		echo '</p></form>';
	}

	private static function method_field( string $name, string $key, string $label, string $value, string $type = 'text', string $warn = '', string $help = '' ): void {
		$id = 'twf-' . preg_replace( '/[^a-z0-9]+/i', '-', $name . '-' . $key );
		echo '<div class="twf-pay__field twf-method__f twf-method__f--' . esc_attr( $key ) . '"><label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label>';
		if ( 'textarea' === $type ) {
			echo '<textarea class="large-text" rows="3" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name . '[' . $key . ']' ) . '">' . esc_textarea( $value ) . '</textarea>';
		} else {
			echo '<input type="text" class="large-text' . ( 'iban' === $key ? ' code' : '' ) . '" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name . '[' . $key . ']' ) . '" value="' . esc_attr( $value ) . '" spellcheck="false">';
		}
		if ( '' !== $warn ) {
			echo '<p class="twf-method__warn">' . esc_html( $warn ) . '</p>';
		}
		if ( '' !== $help ) {
			echo '<p class="description">' . esc_html( $help ) . '</p>';
		}
		echo '</div>';
	}

	/**
	 * @param bool $locked Whether the signing secret of this mode comes from wp-config.php.
	 * @param bool $has    Whether a signing secret is already saved.
	 */
	private static function webhook_card( string $mode, bool $locked, bool $has ): void {
		$live = 'live' === $mode;
		echo '<div class="twf-pay__card twf-pay__webhook"><h2>' . esc_html( $live ? __( 'Webhook su Stripe (modalità reale)', 'tw-formulari' ) : __( 'Webhook su Stripe (modalità di prova)', 'tw-formulari' ) ) . '</h2>';
		if ( $locked ) {
			echo '<p>' . esc_html__( 'Il segreto del webhook è definito in wp-config.php: la schermata non lo cambia.', 'tw-formulari' ) . '</p></div>';
			return;
		}
		$events  = (array) get_option( Stripe::WEBHOOK_EVENTS_OPTION, [] );
		$missing = $has && array_diff( Stripe::WEBHOOK_EVENTS, (array) ( $events[ $mode ] ?? [] ) );
		if ( $missing ) {
			echo '<p class="twf-pay__warn"><strong>' . esc_html__( 'Da aggiornare:', 'tw-formulari' ) . '</strong> ' . esc_html__( 'il webhook non riceve ancora i rimborsi fatti direttamente sul pannello di Stripe. Premi «Ricrea il webhook su Stripe» qui sotto: il plugin lo sostituisce con uno che riceve anche quelli (con una chiave «con restrizioni» serve il permesso di scrittura su «Webhook Endpoints»).', 'tw-formulari' ) . '</p>';
		}
		echo '<p>' . esc_html( $has
			? __( 'Il segreto del webhook è salvato. Se hai cancellato il webhook su Stripe o vuoi cambiarlo, puoi crearne uno nuovo.', 'tw-formulari' )
			: __( 'Il webhook fa arrivare a questo sito la conferma dei pagamenti anche quando il cliente chiude la pagina (utile con TWINT). Con un clic il plugin lo crea su Stripe con gli eventi giusti e salva da solo il segreto di firma.', 'tw-formulari' ) ) . '</p>';
		echo '<p class="description">' . esc_html__( 'Usa le chiavi già salvate. Se su Stripe c’è già un webhook con questo stesso indirizzo viene sostituito (Stripe mostra il segreto solo alla creazione); gli altri webhook non si toccano.', 'tw-formulari' ) . '</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" id="twf-webhook-form" data-confirm="' . esc_attr( $live
			? __( 'Il plugin creerà il webhook su Stripe in modalità REALE e sostituirà quello che punta già a questo indirizzo. Continuare?', 'tw-formulari' )
			: __( 'Il plugin creerà il webhook su Stripe in modalità di PROVA e sostituirà quello che punta già a questo indirizzo. Continuare?', 'tw-formulari' ) ) . '">';
		echo '<input type="hidden" name="action" value="twf_stripe_webhook">';
		wp_nonce_field( 'twf_stripe_webhook' );
		echo '<p><button type="submit" class="button button-primary">' . esc_html( $has ? __( 'Ricrea il webhook su Stripe', 'tw-formulari' ) : __( 'Imposta il webhook su Stripe', 'tw-formulari' ) ) . '</button></p>';
		echo '</form>';
		echo '<script>(function(){var f=document.getElementById("twf-webhook-form");if(f){f.addEventListener("submit",function(e){if(!window.confirm(f.getAttribute("data-confirm"))){e.preventDefault();}});}})();</script>';
		echo '</div>';
	}

	private static function check( string $label, bool $ok, bool $required ): void {
		$class = $ok ? 'ok' : ( $required ? 'bad' : 'warn' );
		$icon  = $ok ? '✓' : ( $required ? '✕' : '!' );
		$note  = $ok ? '' : ( $required ? '' : ' <span>' . esc_html__( '(consigliato)', 'tw-formulari' ) . '</span>' );
		echo '<li class="twf-pay__check twf-pay__check--' . esc_attr( $class ) . '"><b aria-hidden="true">' . esc_html( $icon ) . '</b> ' . esc_html( $label ) . $note . '</li>';
	}

	/**
	 * @param array<string, bool> $locked Which values come from wp-config.php.
	 */
	private static function mode_card( string $mode, string $title, bool $is_active, array $locked ): void {
		$values = Stripe::keys( $mode );
		$done   = Stripe::key_is_valid( $mode, 'publishable', $values['publishable'] ) && Stripe::key_is_valid( $mode, 'secret', $values['secret'] );

		echo '<section class="twf-pay__card twf-pay__card--' . esc_attr( $mode ) . ( $is_active ? ' is-active' : '' ) . '" data-mode="' . esc_attr( $mode ) . '">';
		echo '<header><h2>' . esc_html( $title ) . '</h2>';
		echo '<span class="twf-pay__chip twf-pay__chip--' . ( $done ? 'ok' : 'todo' ) . '">' . esc_html( $done ? __( 'Completa', 'tw-formulari' ) : __( 'Da inserire', 'tw-formulari' ) ) . '</span>';
		echo '<span class="twf-pay__chip twf-pay__chip--use">' . esc_html__( 'In uso', 'tw-formulari' ) . '</span></header>';

		foreach ( self::fields() as $key => $f ) {
			$id    = 'twf-' . $mode . '-' . $key;
			$value = $values[ $key ];
			echo '<div class="twf-pay__field"><label for="' . esc_attr( $id ) . '">' . esc_html( $f['label'] ) . ( $f['required'] ? '' : ' <span class="twf-pay__opt">' . esc_html__( 'consigliato', 'tw-formulari' ) . '</span>' ) . '</label>';
			if ( ! empty( $locked[ $key ] ) ) {
				echo '<p><code>' . esc_html( $f['secret'] ? self::hint( $value ) : $value ) . '</code> <span class="description">' . esc_html( Stripe::constant_name( $mode, $key ) ) . ' (wp-config.php)</span></p>';
			} else {
				$ph = $f['secret'] && '' !== $value ? __( 'Salvata', 'tw-formulari' ) . ' ' . self::hint( $value ) . ' · ' . __( 'vuoto = invariata', 'tw-formulari' ) : self::placeholder( $mode, $key );
				echo '<input type="' . ( $f['secret'] ? 'password' : 'text' ) . '" class="large-text code" id="' . esc_attr( $id ) . '" name="twf_' . esc_attr( $mode . '_' . $key ) . '" value="' . esc_attr( $f['secret'] ? '' : $value ) . '" placeholder="' . esc_attr( $ph ) . '" autocomplete="off" spellcheck="false">';
			}
			echo '<p class="description">' . esc_html( $f['help'] ) . '</p></div>';
		}
		echo '<p class="twf-pay__clear"><label><input type="checkbox" name="twf_clear_' . esc_attr( $mode ) . '" value="1"> ' . esc_html__( 'Cancella le chiavi salvate di questa modalità', 'tw-formulari' ) . '</label></p>';
		echo '</section>';
	}

	private static function notices(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only messages.
		if ( isset( $_GET['saved'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Salvato.', 'tw-formulari' ) . '</p></div>';
		}
		if ( isset( $_GET['methods'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Metodi di pagamento salvati.', 'tw-formulari' ) . '</p></div>';
		}
		if ( isset( $_GET['invalid'] ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'Una chiave non ha il formato giusto o è nella scheda sbagliata (le chiavi di prova contengono _test_, quelle reali _live_; il segreto del webhook inizia con whsec_). Non è stato salvato nulla.', 'tw-formulari' ) . '</p></div>';
		}
		if ( isset( $_GET['tested'] ) ) {
			$result = get_transient( 'twf_stripe_test_' . get_current_user_id() );
			if ( is_array( $result ) ) {
				echo '<div class="notice ' . ( ! empty( $result['ok'] ) ? 'notice-success' : 'notice-error' ) . ' is-dismissible"><p>' . esc_html( (string) $result['message'] ) . '</p></div>';
			}
		}
		// phpcs:enable
	}

	public static function handle_methods(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Non hai il permesso di fare questa operazione.', 'tw-formulari' ), 403 );
		}
		check_admin_referer( 'twf_methods_save' );
		$posted = isset( $_POST['twf_m'] ) && is_array( $_POST['twf_m'] ) ? wp_unslash( $_POST['twf_m'] ) : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- cleaned by PaymentMethods::normalize().
		$delete  = isset( $_POST['twf_delete'] ) ? sanitize_key( wp_unslash( $_POST['twf_delete'] ) ) : '';
		$add     = isset( $_POST['twf_add'] ) ? sanitize_key( wp_unslash( $_POST['twf_add'] ) ) : '';
		$current = isset( $_POST['twf_current'] ) ? sanitize_key( wp_unslash( $_POST['twf_current'] ) ) : PaymentMethods::STRIPE;

		$result = PaymentMethods::apply_post( PaymentMethods::all(), (array) $posted, $delete, $add );
		$saved  = PaymentMethods::save( $result );
		$focus  = $current;
		if ( '' !== $add && $saved ) {
			$focus = (string) end( $saved )['id']; // land on the method just added.
		} elseif ( '' !== $delete || ! PaymentMethods::get( $focus ) ) {
			$focus = PaymentMethods::STRIPE;
		}
		wp_safe_redirect( self::url( [ 'methods' => 1, 'method' => $focus ] ) );
		exit;
	}

	public static function handle_webhook(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Non hai il permesso di fare questa operazione.', 'tw-formulari' ), 403 );
		}
		check_admin_referer( 'twf_stripe_webhook' );
		set_transient( 'twf_stripe_test_' . get_current_user_id(), Stripe::setup_webhook(), 60 );
		wp_safe_redirect( self::url( [ 'tested' => 1 ] ) );
		exit;
	}

	public static function handle_save(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Non hai il permesso di fare questa operazione.', 'tw-formulari' ), 403 );
		}
		check_admin_referer( 'twf_stripe_save' );
		$saved = Stripe::stored();
		$const = Stripe::from_constants();
		$new   = [ 'mode' => 'test', 'test' => $saved['test'], 'live' => $saved['live'] ];

		$mode        = isset( $_POST['twf_mode'] ) ? sanitize_key( wp_unslash( $_POST['twf_mode'] ) ) : $saved['mode'];
		$new['mode'] = 'live' === $mode ? 'live' : 'test';

		foreach ( [ 'test', 'live' ] as $m ) {
			if ( ! empty( $_POST[ 'twf_clear_' . $m ] ) ) {
				$new[ $m ] = array_fill_keys( Stripe::KEYS, '' );
				continue;
			}
			foreach ( Stripe::KEYS as $key ) {
				$posted = isset( $_POST[ 'twf_' . $m . '_' . $key ] ) ? trim( (string) wp_unslash( $_POST[ 'twf_' . $m . '_' . $key ] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- validated by the pattern below.
				if ( ! empty( $const[ $m ][ $key ] ) || '' === $posted ) {
					continue; // from wp-config.php, or left empty = keep what is saved.
				}
				if ( ! Stripe::key_is_valid( $m, $key, $posted ) ) {
					wp_safe_redirect( self::url( [ 'invalid' => 1 ] ) );
					exit;
				}
				$new[ $m ][ $key ] = $posted;
			}
		}
		update_option( Stripe::OPTION, $new, false );

		$args = [ 'saved' => 1 ];
		if ( isset( $_POST['twf_do'] ) && 'test' === sanitize_key( wp_unslash( $_POST['twf_do'] ) ) ) {
			set_transient( 'twf_stripe_test_' . get_current_user_id(), Stripe::test_connection(), 60 );
			$args = [ 'tested' => 1 ];
		}
		wp_safe_redirect( self::url( $args ) );
		exit;
	}
}
