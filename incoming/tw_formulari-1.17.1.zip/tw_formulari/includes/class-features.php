<?php
/**
 * Which functions of the plugin are switched on (TW Formulari → Impostazioni).
 *
 * Four independent-looking switches with two dependencies, enforced here and not only in the screen:
 *   - builder   Own forms: visual editor, shortcode [tw_form], entries.
 *   - payments  Stripe payments in own forms (needs builder).
 *   - pdf       The PDF of the answers: identity settings and the PDF option of the forms.
 *   - adapters  PDF + e-mail for the form of another plugin (Elementor, CF7, WPForms, Gravity, Fluent, POST); needs pdf.
 *
 * A switched-off function does nothing: no menu entries, no hooks, no scheduled events. Sites that already had a
 * form of another plugin linked before these switches existed keep that function (and so the PDF) on; every other
 * site starts with the PDF off.
 *
 * @package TicinoWeb\TWFormulari
 */

namespace TicinoWeb\TWFormulari;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Features {

	public const OPTION = 'tw_formulari_features';
	public const KEYS   = [ 'builder', 'payments', 'pdf', 'adapters' ];

	/** @var array<string, bool>|null */
	private static $cache = null;

	/**
	 * Values used when nothing was saved.
	 *
	 * @return array<string, bool>
	 */
	public static function defaults(): array {
		$form   = Settings::get_form_settings();
		$legacy = '' !== trim( (string) ( $form['target_form_id'] ?? '' ) );
		return [ 'builder' => true, 'payments' => true, 'pdf' => $legacy, 'adapters' => $legacy ];
	}

	/**
	 * What the administrator chose (dependencies not applied).
	 *
	 * @return array<string, bool>
	 */
	public static function stored(): array {
		$saved = get_option( self::OPTION, null );
		$out   = self::defaults();
		if ( is_array( $saved ) ) {
			foreach ( self::KEYS as $key ) {
				if ( array_key_exists( $key, $saved ) ) {
					$out[ $key ] = ! empty( $saved[ $key ] );
				}
			}
		}
		return $out;
	}

	/**
	 * What is really on: a function that needs another one is off when that one is off.
	 *
	 * @return array<string, bool>
	 */
	public static function all(): array {
		if ( null === self::$cache ) {
			$s                    = self::stored();
			$s['payments']        = $s['payments'] && $s['builder'];
			$s['adapters']        = $s['adapters'] && $s['pdf'];
			self::$cache          = $s;
		}
		return self::$cache;
	}

	public static function enabled( string $key ): bool {
		return ! empty( self::all()[ $key ] );
	}

	/**
	 * @param array<string, mixed> $posted Raw checkboxes (key => "1").
	 */
	public static function save( array $posted ): void {
		$new = [];
		foreach ( self::KEYS as $key ) {
			$new[ $key ] = ! empty( $posted[ $key ] );
		}
		update_option( self::OPTION, $new, true );
		self::$cache = null;
	}

	/** For tests and after a save: forget what was read. */
	public static function reset_cache(): void {
		self::$cache = null;
	}
}
