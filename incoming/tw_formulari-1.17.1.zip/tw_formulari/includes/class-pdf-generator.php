<?php
/**
 * Universal PDF generator using mPDF for tw_formulari.
 *
 * @package TicinoWeb\TWFormulari
 */

namespace TicinoWeb\TWFormulari;

use Mpdf\Mpdf;
use Mpdf\Output\Destination;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PdfGenerator {

	/**
	 * Generates a PDF file for the given normalized data and saves it in the temp directory.
	 *
	 * @param array<string, mixed> $data Normalized form data.
	 * @return string Absolute path to the generated temporary PDF file.
	 * @throws \Exception When PDF generation fails.
	 */
	public static function generate_file( array $data ): string {
		self::ensure_dependencies();
		$mpdf = self::create_mpdf_instance();

		$html = self::render_html( $data );
		$mpdf->WriteHTML( $html );

		$filename = self::build_filename( $data );
		$filepath = get_temp_pdf_dir() . $filename;

		try {
			$mpdf->Output( $filepath, Destination::FILE );
			@chmod( $filepath, 0600 );
		} catch ( \Throwable $error ) {
			if ( is_file( $filepath ) ) {
				@unlink( $filepath );
			}
			throw $error;
		}

		if ( ! file_exists( $filepath ) || filesize( $filepath ) === 0 ) {
			throw new \RuntimeException( 'Impossibile scrivere il documento PDF temporaneo.' );
		}

		return $filepath;
	}

	/**
	 * Generates the «Buono regalo» PDF (A5 landscape) and saves it in the temp directory.
	 *
	 * @param array<string, string> $voucher title, amount, number, date, from, message, note, color, image_id, site_name.
	 * @return string Absolute path to the generated temporary PDF file.
	 * @throws \Exception When PDF generation fails.
	 */
	public static function generate_voucher_file( array $voucher ): string {
		self::ensure_dependencies();
		$mpdf = new Mpdf( [
			'mode'              => 'utf-8',
			'format'            => 'A5-L',
			'default_font'      => 'dejavusans',
			'margin_left'       => 0,
			'margin_right'      => 0,
			'margin_top'        => 0,
			'margin_bottom'     => 0,
			'tempDir'           => get_temp_pdf_dir(),
			'autoPageBreak'     => false,
		] );
		$mpdf->SetTitle( (string) ( $voucher['title'] ?? '' ) );
		$mpdf->SetAuthor( (string) ( $voucher['site_name'] ?? get_bloginfo( 'name' ) ) );
		$mpdf->SetCreator( 'tw_formulari' );
		$mpdf->WriteHTML( self::render_voucher_html( $voucher ) );

		$filepath = get_temp_pdf_dir() . self::build_filename( [] );
		$mpdf->Output( $filepath, Destination::FILE );
		@chmod( $filepath, 0600 );
		if ( ! file_exists( $filepath ) || filesize( $filepath ) === 0 ) {
			throw new \RuntimeException( 'Impossibile scrivere il buono PDF temporaneo.' );
		}
		return $filepath;
	}

	/**
	 * HTML of the voucher: logo of the PDF settings, otherwise the site logo (ticinoWEB CMS or WordPress).
	 *
	 * @param array<string, string> $voucher
	 * @return string
	 */
	public static function render_voucher_html( array $voucher ): string {
		$settings = Settings::get_pdf_settings();
		$logo_src = '';
		$candidates = [ (string) ( $settings['logo_url'] ?? '' ), (string) get_option( 'ticinoweb_site_logo', '' ) ];
		$custom = (int) get_theme_mod( 'custom_logo', 0 );
		if ( $custom ) {
			$candidates[] = (string) wp_get_attachment_url( $custom );
		}
		foreach ( $candidates as $url ) {
			$path = '' !== $url ? self::resolve_local_media_path( $url ) : null;
			if ( $path ) {
				$mime = function_exists( 'mime_content_type' ) ? (string) mime_content_type( $path ) : '';
				if ( in_array( $mime, [ 'image/png', 'image/jpeg', 'image/gif' ], true ) ) {
					$logo_src = 'data:' . $mime . ';base64,' . base64_encode( (string) file_get_contents( $path ) );
					break;
				}
			}
		}
		// Foto del buono scelta nel modulo (libreria media): la versione «large» basta per un A5 e tiene leggero il PDF.
		$photo_src = '';
		$image_id  = (int) ( $voucher['image_id'] ?? 0 );
		if ( $image_id ) {
			$url  = (string) wp_get_attachment_image_url( $image_id, 'large' );
			$path = '' !== $url ? self::resolve_local_media_path( $url ) : null;
			if ( $path ) {
				$mime = function_exists( 'mime_content_type' ) ? (string) mime_content_type( $path ) : '';
				if ( in_array( $mime, [ 'image/png', 'image/jpeg' ], true ) ) {
					$photo_src = 'data:' . $mime . ';base64,' . base64_encode( (string) file_get_contents( $path ) );
				}
			}
		}
		ob_start();
		require TW_FORMULARI_PATH . 'templates/pdf/voucher.php';
		return ob_get_clean() ?: '';
	}

	/**
	 * Streams the PDF directly to the browser (for admin test preview/download).
	 *
	 * @param array<string, mixed> $data Normalized form data.
	 * @param string               $action 'D' for forced download or 'I' for inline browser view.
	 * @return void
	 * @throws \Exception When PDF generation fails.
	 */
	public static function stream_to_browser( array $data, string $action = 'I' ): void {
		self::ensure_dependencies();
		$mpdf = self::create_mpdf_instance();

		$html = self::render_html( $data );
		$mpdf->WriteHTML( $html );

		$filename = self::build_filename( $data );
		$dest     = ( $action === 'D' ) ? Destination::DOWNLOAD : Destination::INLINE;

		$mpdf->Output( $filename, $dest );
	}

	/**
	 * Creates and configures an mPDF instance.
	 *
	 * @return Mpdf Configured mPDF object.
	 */
	private static function create_mpdf_instance(): Mpdf {
		$temp_dir      = get_temp_pdf_dir();
		$pdf_settings  = Settings::get_pdf_settings();
		$facility_name = ! empty( $pdf_settings['facility_name'] ) ? $pdf_settings['facility_name'] : get_bloginfo( 'name' );

		$config = [
			'mode'                     => 'utf-8',
			'format'                   => 'A4',
			'default_font_size'        => 9.5,
			'default_font'             => 'dejavusans',
			'margin_left'              => 18,
			'margin_right'             => 18,
			'margin_top'               => 16,
			'margin_bottom'            => 18,
			'margin_header'            => 8,
			'margin_footer'            => 8,
			'orientation'              => 'P',
			'tempDir'                  => $temp_dir,
			'autoPageBreak'            => true,
			'shrink_tables_to_fit'     => 1,
			'keep_table_proportions'   => true,
			'ignore_invalid_use_subcat'=> true,
		];

		$mpdf = new Mpdf( $config );
		$mpdf->SetTitle( $pdf_settings['document_title'] ?? 'Formulario ricevuto' );
		$mpdf->SetAuthor( $facility_name );
		$mpdf->SetCreator( 'tw_formulari' );

		return $mpdf;
	}

	/**
	 * Renders the universal HTML template from normalized form fields.
	 *
	 * @param array<string, mixed> $data Normalized form data.
	 * @return string Rendered HTML.
	 */
	public static function render_html( array $data ): string {
		$settings      = Settings::get_pdf_settings();

		// Determine local path to logo and prepare base64 data URI
		$logo_path = '';
		if ( ! empty( $settings['logo_url'] ) ) {
			$custom_path = self::resolve_local_media_path( $settings['logo_url'] );
			if ( $custom_path && file_exists( $custom_path ) ) {
				$logo_path = $custom_path;
			}
		}

		$logo_src = '';
		if ( $logo_path && file_exists( $logo_path ) ) {
			$image_data = @file_get_contents( $logo_path );
			$mime_type  = function_exists( 'mime_content_type' ) ? mime_content_type( $logo_path ) : '';
			if ( $image_data && in_array( $mime_type, [ 'image/png', 'image/jpeg', 'image/gif' ], true ) ) {
				$logo_src = 'data:' . $mime_type . ';base64,' . base64_encode( $image_data );
			}
		}

		ob_start();
		$template_file = TW_FORMULARI_PATH . 'templates/pdf/generic-form.php';

		if ( file_exists( $template_file ) ) {
			require $template_file;
		}
		return ob_get_clean() ?: '';
	}

	/**
	 * Builds a clean, secure and normalized filename for the PDF.
	 *
	 * @param array<string, mixed> $data Normalized form data.
	 * @return string Generated filename.
	 */
	public static function build_filename( array $data ): string {
		$token = strtolower( preg_replace( '/[^a-zA-Z0-9-]/', '', wp_generate_password( 16, false ) ) );
		return sprintf( 'twf-%s-%s.pdf', gmdate( 'YmdHis' ), $token ?: bin2hex( random_bytes( 8 ) ) );
	}

	/**
	 * Loads the sizeable PDF dependency only when a document is requested.
	 *
	 * @return void
	 */
	private static function ensure_dependencies(): void {
		if ( ! extension_loaded( 'mbstring' ) || ! extension_loaded( 'gd' ) ) {
			throw new \RuntimeException( 'Le estensioni PHP mbstring e gd sono necessarie per generare PDF.' );
		}
		if ( class_exists( Mpdf::class ) ) {
			return;
		}

		$autoload = TW_FORMULARI_PATH . 'vendor/autoload.php';
		if ( ! file_exists( $autoload ) ) {
			throw new \RuntimeException( 'Libreria PDF non disponibile.' );
		}

		require_once $autoload;
	}

	/**
	 * Helper to convert a WordPress media URL to its local filesystem path.
	 *
	 * @param string $url URL to convert.
	 * @return string|null Local path or null.
	 */
	public static function resolve_local_media_path( string $url ): ?string {
		$upload_dir = wp_upload_dir();
		$base_url   = trailingslashit( (string) ( $upload_dir['baseurl'] ?? '' ) );
		$base_dir   = realpath( (string) ( $upload_dir['basedir'] ?? '' ) );
		if ( '' === $base_url || false === $base_dir || 0 !== strpos( $url, $base_url ) ) {
			return null;
		}

		$relative  = rawurldecode( substr( $url, strlen( $base_url ) ) );
		$candidate = realpath( trailingslashit( $base_dir ) . ltrim( $relative, '/\\' ) );
		if ( false === $candidate || 0 !== strpos( $candidate, trailingslashit( $base_dir ) ) || ! is_file( $candidate ) ) {
			return null;
		}
		return $candidate;
	}
}
