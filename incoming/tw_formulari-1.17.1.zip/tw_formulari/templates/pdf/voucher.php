<?php
/**
 * PDF «Buono regalo» (A5 orizzontale, da stampare o mostrare dal telefono).
 *
 * A sinistra la foto scelta nel modulo, oppure la grafica scelta (pacco regalo, o fiore nei colori della decorazione), a destra su fondo caldo:
 * logo, titolo, importo grande, dedica, chi lo regala, numero, data e condizioni.
 *
 * Variabili:
 * - $voucher: title, amount, number, date, from, message, note, color, graphic (gift|gift_light|flower), deco (fino a tre colori separati da virgola), site_name.
 * - $logo_src: logo incorporato (data URI) oppure ''.
 * - $photo_src: foto incorporata (data URI) oppure ''.
 *
 * mPDF: solo tabelle con stili sulle celle, colori pieni, font inclusi (DejaVu).
 *
 * @package TicinoWeb\TWFormulari
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$color   = (string) ( $voucher['color'] ?? '#b68745' );
$title   = (string) ( $voucher['title'] ?? '' );
$amount  = (string) ( $voucher['amount'] ?? '' );
$number  = (string) ( $voucher['number'] ?? '' );
$date    = (string) ( $voucher['date'] ?? '' );
$from    = (string) ( $voucher['from'] ?? '' );
$message = (string) ( $voucher['message'] ?? '' );
$note    = (string) ( $voucher['note'] ?? '' );
$site    = (string) ( $voucher['site_name'] ?? '' );
$c       = esc_attr( $color );
// Titolo in più lingue («Buono regalo · Geschenkgutschein»): va a capo solo tra una lingua e l'altra.
$title_html = implode( ' · ', array_map( static function ( $part ) {
	return str_replace( ' ', '&nbsp;', esc_html( trim( $part ) ) );
}, explode( '·', $title ) ) );

// Colori della decorazione (fino a tre, scelti nel modulo); senza, sfumature chiare del colore del buono.
$deco = array_values( array_filter( array_map( 'trim', explode( ',', (string) ( $voucher['deco'] ?? '' ) ) ), static function ( $hex ) {
	return (bool) preg_match( '/^#[0-9a-f]{6}$/i', $hex );
} ) );
$tint = static function ( string $hex, float $amount ): string {
	$rgb = sscanf( $hex, '#%02x%02x%02x' );
	return vsprintf( '#%02x%02x%02x', array_map( static function ( $v ) use ( $amount ) {
		return (int) round( $v + ( 255 - $v ) * $amount );
	}, $rgb ) );
};
$ring   = $deco[0] ?? $tint( $color, 0.55 );
$petalA = $deco[1] ?? $tint( $color, 0.35 );
$petalB = $deco[2] ?? $tint( $color, 0.7 );
$dash   = $deco[0] ?? $color; // linea tratteggiata: primo colore della decorazione, altrimenti il colore del buono

// Grafica del riquadro di sinistra quando non c'è una foto: fiore a sei petali, doppio cerchio e stelline.
$petal = 'M0 0 C 13 -18, 14 -48, 0 -74 C -14 -48, -13 -18, 0 0 Z';
$svg   = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 240" width="240" height="240">';
$svg  .= '<circle cx="120" cy="120" r="104" fill="none" stroke="' . $ring . '" stroke-width="3"/>';
$svg  .= '<circle cx="120" cy="120" r="96" fill="none" stroke="' . $ring . '" stroke-width="1"/>';
for ( $i = 0; $i < 6; $i++ ) {
	$svg .= '<path d="' . $petal . '" fill="' . ( $i % 2 ? $petalB : $petalA ) . '" transform="translate(120 120) rotate(' . ( $i * 60 ) . ')"/>';
}
$svg .= '<circle cx="120" cy="120" r="9" fill="#ffffff"/>';
foreach ( [ [ 120, 6 ], [ 222, 120 ], [ 120, 234 ], [ 18, 120 ] ] as $p ) {
	$svg .= '<path d="M0 -7 L2 -2 L7 0 L2 2 L0 7 L-2 2 L-7 0 L-2 -2 Z" fill="' . $ring . '" transform="translate(' . $p[0] . ' ' . $p[1] . ')"/>';
}
$svg  .= '</svg>';
// Pacco regalo disegnato: bianco sul colore del buono («gift») o nel colore del buono su fondo chiaro («gift_light»).
$light     = 'gift_light' === ( $voucher['graphic'] ?? 'gift' );
$panel_bg  = $light ? '#ffffff' : $color;
$gift_line = $light ? $color : '#ffffff';
$gift = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" width="120" height="120">'
	. '<g fill="none" stroke="' . $gift_line . '" stroke-width="4" stroke-linejoin="round" stroke-linecap="round">'
	. '<rect x="18" y="48" width="84" height="58" rx="4"/><rect x="12" y="34" width="96" height="16" rx="3"/>'
	. '<path d="M60 34v72"/><path d="M60 34c-6-14-26-22-30-10s20 12 30 10z"/><path d="M60 34c6-14 26-22 30-10s-20 12-30 10z"/>'
	. '</g></svg>';
$is_gift = 'flower' !== ( $voucher['graphic'] ?? 'gift' );
$graphic = 'data:image/svg+xml;base64,' . base64_encode( $is_gift ? $gift : $svg );
?>
<html>
<head>
<style>
	@page { margin: 0; }
	body { font-family: dejavusans; color: #2f2a26; }
	td { vertical-align: middle; }
</style>
</head>
<body>
<table width="100%" cellspacing="0" cellpadding="0" style="height: 148mm; border-collapse: collapse;">
	<tr>
		<?php if ( '' !== $photo_src ) : ?>
			<td width="42%" style="height: 148mm; background-color: <?php echo $c; ?>; background-image: url(<?php echo esc_attr( $photo_src ); ?>); background-image-resize: 6; background-repeat: no-repeat; background-position: center center;">&nbsp;</td>
		<?php else : ?>
			<td width="42%" style="height: 148mm; background-color: <?php echo esc_attr( $is_gift ? $panel_bg : $color ); ?>; text-align: center;">
				<img src="<?php echo esc_attr( $graphic ); ?>" style="<?php echo $is_gift ? 'width: 34mm; height: 34mm;' : 'width: 66mm; height: 66mm;'; ?>" alt="">
			</td>
			<?php if ( $is_gift && $light ) : ?>
				<?php // Tutto bianco: una sottile riga nel colore del buono divide il regalo dal testo, staccata dai bordi. ?>
				<td width="0.5%" style="height: 148mm; background-color: #ffffff;">
					<table cellspacing="0" cellpadding="0" style="height: 108mm;"><tr><td style="height: 108mm; width: 0.5mm; background-color: <?php echo $c; ?>; font-size: 1pt;">&nbsp;</td></tr></table>
				</td>
			<?php endif; ?>
		<?php endif; ?>
		<td style="height: 148mm; background-color: <?php echo ( '' === $photo_src && $is_gift && $light ) ? '#ffffff' : '#fbf6ee'; ?>; padding: 9mm 11mm 8mm 11mm; text-align: center;">

			<table width="100%" cellspacing="0" cellpadding="0">
				<?php if ( '' !== $logo_src ) : ?>
					<tr><td style="text-align: center; padding-bottom: 5mm;"><img src="<?php echo esc_attr( $logo_src ); ?>" style="height: 19mm;" alt="<?php echo esc_attr( $site ); ?>"></td></tr>
				<?php else : ?>
					<tr><td style="text-align: center; padding-bottom: 5mm; font-family: dejavuserif; font-size: 17pt;"><?php echo esc_html( $site ); ?></td></tr>
				<?php endif; ?>

				<tr><td style="text-align: center; font-size: 7.5pt; letter-spacing: 0.2mm; text-transform: uppercase; color: <?php echo $c; ?>; font-weight: bold;">
					&#9733;&nbsp;&nbsp;<?php echo $title_html; // phpcs:ignore WordPress.Security.EscapeOutput -- escape per parte qui sopra ?>&nbsp;&nbsp;&#9733;
				</td></tr>

				<?php if ( '' !== $amount ) : ?>
					<tr><td style="text-align: center; padding-top: 3mm; font-family: dejavuserif; font-size: 40pt; font-weight: bold; color: <?php echo $c; ?>;"><?php echo esc_html( $amount ); ?></td></tr>
				<?php endif; ?>

				<?php if ( '' !== $message ) : ?>
					<tr><td style="text-align: center; padding: 4mm 4mm 0 4mm; font-family: dejavuserif; font-style: italic; font-size: 12pt; line-height: 1.45; color: #4a413a;">«<?php echo nl2br( esc_html( $message ) ); ?>»</td></tr>
				<?php endif; ?>
				<?php if ( '' !== $from ) : ?>
					<tr><td style="text-align: center; padding-top: 2.5mm; font-size: 9pt; color: #7a6f66;"><?php echo esc_html( sprintf( /* translators: %s: name of who gives the voucher */ __( 'Con i migliori auguri da %s', 'tw-formulari' ), $from ) ); ?></td></tr>
				<?php endif; ?>

				<tr><td style="padding-top: 6mm;">
					<table width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td width="50%" style="text-align: center; border-top: 0.3mm dashed <?php echo esc_attr( $dash ); ?>; padding-top: 3mm; font-size: 7pt; letter-spacing: 0.4mm; text-transform: uppercase; color: #8a7d72;"><?php esc_html_e( 'Buono n.', 'tw-formulari' ); ?></td>
							<td width="50%" style="text-align: center; border-top: 0.3mm dashed <?php echo esc_attr( $dash ); ?>; padding-top: 3mm; font-size: 7pt; letter-spacing: 0.4mm; text-transform: uppercase; color: #8a7d72;"><?php esc_html_e( 'Emesso il', 'tw-formulari' ); ?></td>
						</tr>
						<tr>
							<td style="text-align: center; padding-top: 1mm; font-size: 12pt; font-weight: bold; color: #2f2a26;"><?php echo esc_html( $number ); ?></td>
							<td style="text-align: center; padding-top: 1mm; font-size: 12pt; font-weight: bold; color: #2f2a26;"><?php echo esc_html( $date ); ?></td>
						</tr>
					</table>
				</td></tr>

				<?php if ( '' !== $note ) : ?>
					<tr><td style="text-align: center; padding-top: 5mm; font-size: 7.5pt; line-height: 1.4; color: #8a7d72;"><?php echo nl2br( esc_html( $note ) ); ?></td></tr>
				<?php endif; ?>
			</table>

		</td>
	</tr>
</table>
</body>
</html>
