<?php
/**
 * Entry point of the built-in form builder: content type, shortcode, public endpoint, daily clean-up.
 *
 * A form is a non-public post of type "twf_form" whose definition lives in the post meta _twf_definition
 * (JSON, see Definition). Post meta is not filtered like post content, so the JSON survives intact.
 *
 * @package TicinoWeb\TWFormulari\Builder
 */

namespace TicinoWeb\TWFormulari\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Builder {

	public const POST_TYPE   = 'twf_form';
	public const META_DEF    = '_twf_definition';
	public const CRON_HOOK   = 'tw_formulari_builder_purge';
	public const REST_NS     = 'tw-formulari/v1';

	/** @var array<int, array<string, mixed>|null> */
	private static $cache = [];

	public static function init(): void {
		add_action( 'init', [ self::class, 'register_post_type' ] );
		add_action( 'init', [ self::class, 'maybe_install' ], 20 );
		add_action( 'rest_api_init', [ self::class, 'register_routes' ] );
		add_shortcode( 'tw_form', [ self::class, 'shortcode' ] );
		add_action( self::CRON_HOOK, [ self::class, 'purge_entries' ] );
		Stripe::init();
	}

	public static function register_post_type(): void {
		register_post_type( self::POST_TYPE, [
			'labels'              => [ 'name' => __( 'Moduli', 'tw-formulari' ), 'singular_name' => __( 'Modulo', 'tw-formulari' ) ],
			'public'              => false,
			'publicly_queryable'  => false,
			'show_ui'             => false,
			'show_in_rest'        => false,
			'exclude_from_search' => true,
			'has_archive'         => false,
			'rewrite'             => false,
			'query_var'           => false,
			'supports'            => [ 'title' ],
		] );
	}

	/** Creates the table (when the schema changed) and schedules the daily clean-up. */
	public static function maybe_install(): void {
		Entries::install();
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::CRON_HOOK );
		}
	}

	/**
	 * @return array{id:int, title:string, status:string, definition:array<string, mixed>}|null
	 */
	public static function get_form( int $id ): ?array {
		if ( array_key_exists( $id, self::$cache ) ) {
			return self::$cache[ $id ];
		}
		$post = $id > 0 ? get_post( $id ) : null;
		if ( ! $post || self::POST_TYPE !== $post->post_type || 'trash' === $post->post_status ) {
			return self::$cache[ $id ] = null;
		}
		$raw        = get_post_meta( $id, self::META_DEF, true );
		$definition = Definition::normalize( is_string( $raw ) ? $raw : [] );
		if ( '' === $definition['title'] ) {
			$definition['title'] = (string) $post->post_title;
		}
		return self::$cache[ $id ] = [
			'id'         => $id,
			'title'      => (string) $post->post_title,
			'status'     => (string) $post->post_status,
			'definition' => $definition,
		];
	}

	/**
	 * Creates or updates a form.
	 *
	 * @param int                         $id     Existing form id, or 0 to create one.
	 * @param array<string, mixed>|string $raw    Definition (array or JSON); it is normalised before saving.
	 * @param string                      $title  Form title (defaults to the definition title).
	 * @return int|\WP_Error Form id.
	 */
	public static function save_form( int $id, $raw, string $title = '' ) {
		$definition = Definition::normalize( $raw );
		$title      = '' !== trim( $title ) ? sanitize_text_field( $title ) : $definition['title'];
		if ( '' === $title ) {
			$title = __( 'Modulo senza titolo', 'tw-formulari' );
		}
		$definition['title'] = $title;

		if ( $id > 0 ) {
			$existing = get_post( $id );
			if ( ! $existing || self::POST_TYPE !== $existing->post_type ) {
				return new \WP_Error( 'twf_not_found', __( 'Modulo non trovato.', 'tw-formulari' ) );
			}
			$result = wp_update_post( [ 'ID' => $id, 'post_title' => $title ], true );
		} else {
			$result = wp_insert_post( [ 'post_type' => self::POST_TYPE, 'post_status' => 'publish', 'post_title' => $title ], true );
		}
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		$id = (int) $result;
		update_post_meta( $id, self::META_DEF, wp_slash( wp_json_encode( $definition, JSON_UNESCAPED_UNICODE ) ) );
		unset( self::$cache[ $id ] );
		return $id;
	}

	/**
	 * Shortcode [tw_form id="12"].
	 *
	 * @param array<string, mixed>|string $atts
	 */
	public static function shortcode( $atts ): string {
		$atts = shortcode_atts( [ 'id' => 0 ], is_array( $atts ) ? $atts : [], 'tw_form' );
		$form = self::get_form( (int) $atts['id'] );
		if ( ! $form || 'publish' !== $form['status'] ) {
			return current_user_can( 'manage_options' )
				? '<p class="twf-notice">' . esc_html__( 'Modulo non trovato: controlla il numero nello shortcode.', 'tw-formulari' ) . '</p>'
				: '';
		}
		return Renderer::render( $form['id'], $form['definition'] );
	}

	public static function register_routes(): void {
		register_rest_route( self::REST_NS, '/forms/(?P<id>\d+)/submit', [
			'methods'             => 'POST',
			// Public on purpose: anyone who can see the page may send the form. Abuse is handled in Submission.
			'permission_callback' => '__return_true',
			'callback'            => [ self::class, 'rest_submit' ],
			'args'                => [ 'id' => [ 'sanitize_callback' => 'absint' ] ],
		] );
	}

	/**
	 * @param \WP_REST_Request $request
	 */
	public static function rest_submit( $request ): \WP_REST_Response {
		$form_id = (int) $request['id'];
		$form    = self::get_form( $form_id );

		if ( ! $form || 'publish' !== $form['status'] ) {
			$response = new \WP_REST_Response( [ 'ok' => false, 'message' => __( 'Modulo non trovato.', 'tw-formulari' ) ], 404 );
		} else {
			$result   = Submission::run( $form_id, $form['definition'], (array) wp_unslash( $request->get_body_params() ), (array) $request->get_file_params() );
			$response = new \WP_REST_Response( $result['body'], $result['status'] );
		}
		$response->header( 'Cache-Control', 'no-store, max-age=0' );
		return $response;
	}

	/** Daily: deletes the entries older than each form's retention period. */
	public static function purge_entries(): void {
		$ids = get_posts( [ 'post_type' => self::POST_TYPE, 'post_status' => 'any', 'numberposts' => 500, 'fields' => 'ids' ] );
		foreach ( $ids as $id ) {
			$form = self::get_form( (int) $id );
			if ( $form && (int) $form['definition']['settings']['retention_days'] > 0 ) {
				Entries::purge_older_than( (int) $id, (int) $form['definition']['settings']['retention_days'] );
			}
		}
	}
}
