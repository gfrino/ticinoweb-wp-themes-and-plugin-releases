<?php
/**
 * "Pagamenti" screen: the mode in use (test or live), the Stripe keys of each mode, the webhook address and a
 * connection test.
 *
 * Test and live keys are kept apart, so switching mode never means typing them again. Values defined in
 * wp-config.php (TWF_STRIPE_MODE and TWF_STRIPE_{TEST|LIVE}_{PUBLISHABLE_KEY|SECRET_KEY|WEBHOOK_SECRET}) win over the
 * saved ones and are shown as read-only. Saved secrets are never printed back: the field stays empty and an empty
 * value means "keep what is saved".
 *
 * @package TicinoWeb\TWFormulari\Builder
 */

namespace TicinoWeb\TWFormulari\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class PaymentsAdmin {

	public const PAGE = 'tw-formulari-payments';

	public static function init(): void {
		add_action( 'admin_menu', [ self::class, 'register_menu' ], 25 );
		add_action( 'admin_post_twf_stripe_save', [ self::class, 'handle_save' ] );
	}

	public static function register_menu(): void {
		add_submenu_page( 'tw-formulari', __( 'Pagamenti', 'tw-formulari' ), __( 'Pagamenti', 'tw-formulari' ), 'manage_options', self::PAGE, [ self::class, 'render' ] );
	}

	public static function url( array $args = [] ): string {
		return add_query_arg( $args, admin_url( 'admin.php?page=' . self::PAGE ) );
	}

	/** Shows a saved secret as "…last four" (never the whole). */
	private static function hint( string $value ): string {
		return '' === $value ? '' : '…' . substr( $value, -4 );
	}

	/** @return array<string, array{label:string, placeholder:array<string,string>, help:string, secret:bool, required:bool}> */
	private static function fields(): array {
		return [
			'publishable' => [
				'label'    => __( 'Chiave pubblica', 'tw-formulari' ),
				'help'     => __( 'Si può mostrare: serve al modulo per aprire i campi di pagamento.', 'tw-formulari' ),
				'secret'   => false,
				'required' => true,
			],
			'secret'      => [
				'label'    => __( 'Chiave segreta', 'tw-formulari' ),
				'help'     => __( 'Resta sul server, non compare mai nella pagina. Va bene anche una chiave con restrizioni (rk_…) con permessi su PaymentIntent.', 'tw-formulari' ),
				'secret'   => true,
				'required' => true,
			],
			'webhook'     => [
				'label'    => __( 'Segreto del webhook', 'tw-formulari' ),
				'help'     => __( 'Controlla che gli avvisi di pagamento arrivino davvero da Stripe. Ogni modalità ha il suo.', 'tw-formulari' ),
				'secret'   => true,
				'required' => false,
			],
		];
	}

	private static function placeholder( string $mode, string $key ): string {
		$prefix = [ 'publishable' => 'pk_', 'secret' => 'sk_', 'webhook' => 'whsec_' ][ $key ];
		return 'webhook' === $key ? 'whsec_…' : $prefix . $mode . '_…';
	}

	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Non hai il permesso di vedere questa pagina.', 'tw-formulari' ) );
		}
		$selected = Stripe::selected_mode();
		$const    = Stripe::from_constants();
		$ready    = Stripe::is_configured();
		$active   = Stripe::keys( $selected );

		echo '<div class="wrap twf-wrap twf-pay"><h1>' . esc_html__( 'Pagamenti con Stripe', 'tw-formulari' ) . '</h1>';
		self::notices();

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" autocomplete="off" id="twf-pay-form" data-prev="' . esc_attr( $selected ) . '" data-confirm-live="' . esc_attr__( 'Stai passando alla modalità REALE: da questo momento i pagamenti addebitano davvero i clienti. Continuare?', 'tw-formulari' ) . '">';
		echo '<input type="hidden" name="action" value="twf_stripe_save">';
		wp_nonce_field( 'twf_stripe_save' );

		// ---- Status and switch
		echo '<div class="twf-pay__hero twf-pay__hero--' . esc_attr( $ready ? $selected : 'off' ) . '">';
		echo '<div class="twf-pay__status">';
		if ( ! $ready ) {
			echo '<span class="twf-pay__pill twf-pay__pill--off">' . esc_html__( 'Non pronto', 'tw-formulari' ) . '</span>';
			echo '<p>' . esc_html( 'live' === $selected
				? __( 'È scelta la modalità reale, ma mancano la chiave pubblica o quella segreta reali. Finché non le inserisci i moduli con pagamento non accettano invii.', 'tw-formulari' )
				: __( 'È scelta la modalità di prova, ma mancano la chiave pubblica o quella segreta di prova. Finché non le inserisci i moduli con pagamento non accettano invii.', 'tw-formulari' ) ) . '</p>';
		} elseif ( 'live' === $selected ) {
			echo '<span class="twf-pay__pill twf-pay__pill--live">' . esc_html__( 'REALE', 'tw-formulari' ) . '</span>';
			echo '<p>' . esc_html__( 'I pagamenti addebitano davvero i clienti.', 'tw-formulari' ) . '</p>';
		} else {
			echo '<span class="twf-pay__pill twf-pay__pill--test">' . esc_html__( 'PROVA', 'tw-formulari' ) . '</span>';
			echo '<p>' . esc_html__( 'Nessun addebito reale: usa le carte di prova di Stripe.', 'tw-formulari' ) . '</p>';
		}
		echo '<ul class="twf-pay__checks">';
		self::check( __( 'Chiave pubblica', 'tw-formulari' ), Stripe::key_is_valid( $selected, 'publishable', $active['publishable'] ), true );
		self::check( __( 'Chiave segreta', 'tw-formulari' ), Stripe::key_is_valid( $selected, 'secret', $active['secret'] ), true );
		self::check( __( 'Webhook', 'tw-formulari' ), Stripe::key_is_valid( $selected, 'webhook', $active['webhook'] ), false );
		echo '</ul></div>';

		echo '<div class="twf-pay__switch"><span class="twf-pay__switch-label">' . esc_html__( 'Modalità in uso', 'tw-formulari' ) . '</span>';
		if ( $const['mode'] ) {
			echo '<strong>' . esc_html( 'live' === $selected ? __( 'Reale (live)', 'tw-formulari' ) : __( 'Prova (test)', 'tw-formulari' ) ) . '</strong> <span class="description">' . esc_html__( 'definita in wp-config.php (TWF_STRIPE_MODE)', 'tw-formulari' ) . '</span>';
			echo '<input type="hidden" name="twf_mode" value="' . esc_attr( $selected ) . '">';
		} else {
			echo '<div class="twf-seg" role="radiogroup" aria-label="' . esc_attr__( 'Modalità in uso', 'tw-formulari' ) . '">';
			foreach ( [ 'test' => __( 'Prova (test)', 'tw-formulari' ), 'live' => __( 'Reale (live)', 'tw-formulari' ) ] as $mode => $label ) {
				echo '<label class="twf-seg__opt twf-seg__opt--' . esc_attr( $mode ) . '"><input type="radio" name="twf_mode" value="' . esc_attr( $mode ) . '"' . checked( $selected, $mode, false ) . '><span>' . esc_html( $label ) . '</span></label>';
			}
			echo '</div>';
		}
		echo '<p class="description">' . esc_html__( 'Sotto vedi le chiavi della modalità scelta. Cambiare modalità non cancella quelle dell’altra: restano salvate. Ricordati di salvare.', 'tw-formulari' ) . '</p></div>';
		echo '</div>';

		// ---- Keys of each mode
		echo '<div class="twf-pay__grid">';
		foreach ( [ 'test' => __( 'Chiavi di prova', 'tw-formulari' ), 'live' => __( 'Chiavi reali', 'tw-formulari' ) ] as $mode => $title ) {
			self::mode_card( $mode, $title, $mode === $selected, $const[ $mode ] );
		}
		echo '</div>';

		echo '<p class="twf-pay__actions">';
		echo '<button type="submit" name="twf_do" value="save" class="button button-primary">' . esc_html__( 'Salva', 'tw-formulari' ) . '</button> ';
		echo '<button type="submit" name="twf_do" value="test" class="button">' . esc_html__( 'Salva e prova il collegamento', 'tw-formulari' ) . '</button>';
		echo '</p></form>';

		// ---- What to set up on Stripe
		$url = Stripe::webhook_url();
		echo '<div class="twf-pay__card twf-pay__help"><h2>' . esc_html__( 'Cosa configurare su Stripe', 'tw-formulari' ) . '</h2><ol>';
		echo '<li><strong>' . esc_html__( 'Chiavi.', 'tw-formulari' ) . '</strong> ' . esc_html__( 'In Sviluppatori → Chiavi API (una coppia per la modalità di prova, una per quella reale).', 'tw-formulari' ) . '</li>';
		echo '<li><strong>' . esc_html__( 'Webhook.', 'tw-formulari' ) . '</strong> ' . esc_html__( 'In Sviluppatori → Webhook aggiungi un endpoint con questo indirizzo. Stripe vuole un endpoint per modalità: crealo in Prova e di nuovo in Reale, poi incolla ciascun segreto di firma (whsec_…) nella scheda giusta.', 'tw-formulari' );
		echo '<div class="twf-pay__copy"><input type="text" readonly class="code" id="twf-webhook-url" value="' . esc_attr( $url ) . '"><button type="button" class="button" id="twf-copy-webhook" data-done="' . esc_attr__( 'Copiato', 'tw-formulari' ) . '">' . esc_html__( 'Copia', 'tw-formulari' ) . '</button></div>';
		echo '<p class="twf-pay__events">' . esc_html__( 'Eventi da scegliere:', 'tw-formulari' ) . ' <code>payment_intent.succeeded</code> <code>payment_intent.payment_failed</code> <code>payment_intent.canceled</code></p></li>';
		echo '<li><strong>' . esc_html__( 'Metodi di pagamento.', 'tw-formulari' ) . '</strong> ' . esc_html__( 'In Impostazioni → Metodi di pagamento attiva carte, Apple Pay, Google Pay e TWINT (TWINT solo in franchi svizzeri, CHF).', 'tw-formulari' ) . '</li>';
		echo '<li><strong>' . esc_html__( 'Prima la prova.', 'tw-formulari' ) . '</strong> ' . esc_html__( 'Paga con la carta di prova 4242 4242 4242 4242 (rifiutata: 4000 0000 0000 0002), controlla che la compilazione diventi «Pagata» e che arrivino le e-mail. Poi passa a Reale.', 'tw-formulari' ) . '</li>';
		echo '</ol>';
		echo '<p class="description">' . esc_html__( 'Per le chiavi in wp-config.php: TWF_STRIPE_MODE (test o live) e, per ogni modalità, TWF_STRIPE_TEST_… / TWF_STRIPE_LIVE_… con PUBLISHABLE_KEY, SECRET_KEY e WEBHOOK_SECRET. Quelle definite lì non si modificano da questa schermata.', 'tw-formulari' ) . '</p></div>';

		echo '<script>(function(){var f=document.getElementById("twf-pay-form");if(!f){return;}'
			. 'f.addEventListener("submit",function(e){var c=f.querySelector("input[name=twf_mode]:checked");if(c&&c.value==="live"&&f.getAttribute("data-prev")!=="live"&&!window.confirm(f.getAttribute("data-confirm-live"))){e.preventDefault();}});'
			. 'var b=document.getElementById("twf-copy-webhook");if(b){b.addEventListener("click",function(){var i=document.getElementById("twf-webhook-url");i.select();var d=function(){var t=b.textContent;b.textContent=b.getAttribute("data-done");setTimeout(function(){b.textContent=t;},1800);};if(navigator.clipboard){navigator.clipboard.writeText(i.value).then(d);}else{document.execCommand("copy");d();}});}'
			. 'f.addEventListener("change",function(e){if(e.target.name==="twf_mode"){f.querySelectorAll(".twf-pay__card[data-mode]").forEach(function(c){c.classList.toggle("is-active",c.getAttribute("data-mode")===e.target.value);});}});'
			. '})();</script>';
		echo '</div>';
	}

	private static function check( string $label, bool $ok, bool $required ): void {
		$class = $ok ? 'ok' : ( $required ? 'bad' : 'warn' );
		$icon  = $ok ? '✓' : ( $required ? '✕' : '!' );
		$note  = $ok ? '' : ( $required ? '' : ' <span>' . esc_html__( '(consigliato)', 'tw-formulari' ) . '</span>' );
		echo '<li class="twf-pay__check twf-pay__check--' . esc_attr( $class ) . '"><b aria-hidden="true">' . esc_html( $icon ) . '</b> ' . esc_html( $label ) . $note . '</li>';
	}

	/**
	 * @param array<string, bool> $locked Which values come from wp-config.php.
	 */
	private static function mode_card( string $mode, string $title, bool $is_active, array $locked ): void {
		$values = Stripe::keys( $mode );
		$done   = Stripe::key_is_valid( $mode, 'publishable', $values['publishable'] ) && Stripe::key_is_valid( $mode, 'secret', $values['secret'] );

		echo '<section class="twf-pay__card twf-pay__card--' . esc_attr( $mode ) . ( $is_active ? ' is-active' : '' ) . '" data-mode="' . esc_attr( $mode ) . '">';
		echo '<header><h2>' . esc_html( $title ) . '</h2>';
		echo '<span class="twf-pay__chip twf-pay__chip--' . ( $done ? 'ok' : 'todo' ) . '">' . esc_html( $done ? __( 'Completa', 'tw-formulari' ) : __( 'Da inserire', 'tw-formulari' ) ) . '</span>';
		echo '<span class="twf-pay__chip twf-pay__chip--use">' . esc_html__( 'In uso', 'tw-formulari' ) . '</span></header>';

		foreach ( self::fields() as $key => $f ) {
			$id    = 'twf-' . $mode . '-' . $key;
			$value = $values[ $key ];
			echo '<div class="twf-pay__field"><label for="' . esc_attr( $id ) . '">' . esc_html( $f['label'] ) . ( $f['required'] ? '' : ' <span class="twf-pay__opt">' . esc_html__( 'consigliato', 'tw-formulari' ) . '</span>' ) . '</label>';
			if ( ! empty( $locked[ $key ] ) ) {
				echo '<p><code>' . esc_html( $f['secret'] ? self::hint( $value ) : $value ) . '</code> <span class="description">' . esc_html( Stripe::constant_name( $mode, $key ) ) . ' (wp-config.php)</span></p>';
			} else {
				$ph = $f['secret'] && '' !== $value ? __( 'Salvata', 'tw-formulari' ) . ' ' . self::hint( $value ) . ' · ' . __( 'vuoto = invariata', 'tw-formulari' ) : self::placeholder( $mode, $key );
				echo '<input type="' . ( $f['secret'] ? 'password' : 'text' ) . '" class="large-text code" id="' . esc_attr( $id ) . '" name="twf_' . esc_attr( $mode . '_' . $key ) . '" value="' . esc_attr( $f['secret'] ? '' : $value ) . '" placeholder="' . esc_attr( $ph ) . '" autocomplete="off" spellcheck="false">';
			}
			echo '<p class="description">' . esc_html( $f['help'] ) . '</p></div>';
		}
		echo '<p class="twf-pay__clear"><label><input type="checkbox" name="twf_clear_' . esc_attr( $mode ) . '" value="1"> ' . esc_html__( 'Cancella le chiavi salvate di questa modalità', 'tw-formulari' ) . '</label></p>';
		echo '</section>';
	}

	private static function notices(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only messages.
		if ( isset( $_GET['saved'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Salvato.', 'tw-formulari' ) . '</p></div>';
		}
		if ( isset( $_GET['invalid'] ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'Una chiave non ha il formato giusto o è nella scheda sbagliata (le chiavi di prova contengono _test_, quelle reali _live_; il segreto del webhook inizia con whsec_). Non è stato salvato nulla.', 'tw-formulari' ) . '</p></div>';
		}
		if ( isset( $_GET['tested'] ) ) {
			$result = get_transient( 'twf_stripe_test_' . get_current_user_id() );
			if ( is_array( $result ) ) {
				echo '<div class="notice ' . ( ! empty( $result['ok'] ) ? 'notice-success' : 'notice-error' ) . ' is-dismissible"><p>' . esc_html( (string) $result['message'] ) . '</p></div>';
			}
		}
		// phpcs:enable
	}

	public static function handle_save(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Non hai il permesso di fare questa operazione.', 'tw-formulari' ), 403 );
		}
		check_admin_referer( 'twf_stripe_save' );
		$saved = Stripe::stored();
		$const = Stripe::from_constants();
		$new   = [ 'mode' => 'test', 'test' => $saved['test'], 'live' => $saved['live'] ];

		$mode        = isset( $_POST['twf_mode'] ) ? sanitize_key( wp_unslash( $_POST['twf_mode'] ) ) : $saved['mode'];
		$new['mode'] = 'live' === $mode ? 'live' : 'test';

		foreach ( [ 'test', 'live' ] as $m ) {
			if ( ! empty( $_POST[ 'twf_clear_' . $m ] ) ) {
				$new[ $m ] = array_fill_keys( Stripe::KEYS, '' );
				continue;
			}
			foreach ( Stripe::KEYS as $key ) {
				$posted = isset( $_POST[ 'twf_' . $m . '_' . $key ] ) ? trim( (string) wp_unslash( $_POST[ 'twf_' . $m . '_' . $key ] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- validated by the pattern below.
				if ( ! empty( $const[ $m ][ $key ] ) || '' === $posted ) {
					continue; // from wp-config.php, or left empty = keep what is saved.
				}
				if ( ! Stripe::key_is_valid( $m, $key, $posted ) ) {
					wp_safe_redirect( self::url( [ 'invalid' => 1 ] ) );
					exit;
				}
				$new[ $m ][ $key ] = $posted;
			}
		}
		update_option( Stripe::OPTION, $new, false );

		$args = [ 'saved' => 1 ];
		if ( isset( $_POST['twf_do'] ) && 'test' === sanitize_key( wp_unslash( $_POST['twf_do'] ) ) ) {
			set_transient( 'twf_stripe_test_' . get_current_user_id(), Stripe::test_connection(), 60 );
			$args = [ 'tested' => 1 ];
		}
		wp_safe_redirect( self::url( $args ) );
		exit;
	}
}
