<?php
/**
 * Files attached by visitors.
 *
 * They never go in the public media library. Every file is checked (extension against an allow-list that can
 * never contain executable types, real content type, size, count), renamed with a random name and stored in a
 * private folder that the web server refuses to serve. Only an administrator can download them, through a
 * checked endpoint.
 *
 * @package TicinoWeb\TWFormulari\Builder
 */

namespace TicinoWeb\TWFormulari\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Uploads {

	/** Content types accepted for each extension (the file content must match one of them). */
	private const MIME_BY_EXT = [
		'pdf'  => [ 'application/pdf' ],
		'jpg'  => [ 'image/jpeg' ],
		'jpeg' => [ 'image/jpeg' ],
		'png'  => [ 'image/png' ],
		'gif'  => [ 'image/gif' ],
		'webp' => [ 'image/webp' ],
		'doc'  => [ 'application/msword', 'application/octet-stream', 'application/x-ole-storage', 'application/CDFV2' ],
		'docx' => [ 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/zip', 'application/octet-stream' ],
		'xls'  => [ 'application/vnd.ms-excel', 'application/octet-stream', 'application/x-ole-storage', 'application/CDFV2' ],
		'xlsx' => [ 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/zip', 'application/octet-stream' ],
		'odt'  => [ 'application/vnd.oasis.opendocument.text', 'application/zip', 'application/octet-stream' ],
		'ods'  => [ 'application/vnd.oasis.opendocument.spreadsheet', 'application/zip', 'application/octet-stream' ],
		'txt'  => [ 'text/plain' ],
		'csv'  => [ 'text/plain', 'text/csv', 'application/csv' ],
		'zip'  => [ 'application/zip', 'application/x-zip-compressed' ],
	];

	/**
	 * Private folder (created on demand, closed to the web).
	 */
	public static function private_dir(): string {
		if ( defined( 'TWF_PRIVATE_DIR' ) && is_string( TWF_PRIVATE_DIR ) && '' !== TWF_PRIVATE_DIR ) {
			$dir = trailingslashit( TWF_PRIVATE_DIR );
		} else {
			$uploads = wp_upload_dir();
			$dir     = trailingslashit( $uploads['basedir'] ) . 'tw-formulari-private/';
		}
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
			@file_put_contents( $dir . 'index.php', "<?php\n// Silence is golden.\n" );
			@file_put_contents( $dir . '.htaccess', "Options -Indexes\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n" );
			@file_put_contents( $dir . 'web.config', '<?xml version="1.0"?><configuration><system.webServer><authorization><deny users="*" /></authorization></system.webServer></configuration>' );
		}
		return $dir;
	}

	/**
	 * Validates and stores the files of one upload field.
	 *
	 * @param array<string, mixed>     $field Field definition (extensions, max_size_mb, max_files, required).
	 * @param array<string, mixed>|null $raw   The matching part of $_FILES, already in the "one entry per file" shape
	 *                                        (see normalise_files()).
	 * @return array{files:array<int,array<string,mixed>>, error:?string} Stored files, or a visitor-facing error
	 *         (in which case nothing is left on disk).
	 */
	public static function process_field( array $field, ?array $raw ): array {
		$files = self::normalise_files( $raw );
		if ( ! $files ) {
			return [ 'files' => [], 'error' => ! empty( $field['required'] ) ? __( 'Allega almeno un file.', 'tw-formulari' ) : null ];
		}

		$max_files = max( 1, min( 10, (int) ( $field['max_files'] ?? 1 ) ) );
		if ( count( $files ) > $max_files ) {
			/* translators: %d: maximum number of files */
			return [ 'files' => [], 'error' => sprintf( __( 'Puoi allegare al massimo %d file.', 'tw-formulari' ), $max_files ) ];
		}

		$allowed  = (array) ( $field['extensions'] ?? Definition::DEFAULT_EXTENSIONS );
		$max_size = max( 1, min( 25, (int) ( $field['max_size_mb'] ?? 5 ) ) ) * 1024 * 1024;
		$stored   = [];

		foreach ( $files as $file ) {
			$check = self::check_file( $file, $allowed, $max_size );
			if ( null !== $check['error'] ) {
				self::delete_files( $stored );
				return [ 'files' => [], 'error' => $check['error'] ];
			}

			$dir = self::private_dir() . gmdate( 'Y/m/' );
			if ( ! wp_mkdir_p( $dir ) ) {
				self::delete_files( $stored );
				return [ 'files' => [], 'error' => __( 'Non riesco a salvare il file. Riprova più tardi.', 'tw-formulari' ) ];
			}
			$stored_name = bin2hex( random_bytes( 16 ) ) . '.' . $check['ext'];
			$target      = $dir . $stored_name;
			// Test seam: lets automated tests store a file that did not come from a real HTTP upload.
			// In production nothing hooks it, and only files PHP itself received are ever moved.
			$moved = apply_filters( 'twf_uploads_move_file', null, (string) $file['tmp_name'], $target );
			if ( null === $moved ) {
				$moved = function_exists( 'is_uploaded_file' ) && is_uploaded_file( (string) $file['tmp_name'] )
					? @move_uploaded_file( (string) $file['tmp_name'], $target )
					: false;
			}
			if ( ! $moved ) {
				self::delete_files( $stored );
				return [ 'files' => [], 'error' => __( 'Non riesco a salvare il file. Riprova più tardi.', 'tw-formulari' ) ];
			}
			@chmod( $target, 0600 );

			$stored[] = [
				'name' => self::display_name( (string) $file['name'] ),
				'path' => ltrim( substr( $target, strlen( self::private_dir() ) ), '/' ),
				'size' => (int) $file['size'],
				'mime' => $check['mime'],
			];
		}

		return [ 'files' => $stored, 'error' => null ];
	}

	/**
	 * Checks one uploaded file. Pure: no file is moved.
	 *
	 * @param array<string, mixed> $file    name, tmp_name, size, error.
	 * @param string[]             $allowed Allowed extensions.
	 * @return array{ext:string, mime:string, error:?string}
	 */
	public static function check_file( array $file, array $allowed, int $max_size ): array {
		$fail = static function ( string $message ): array {
			return [ 'ext' => '', 'mime' => '', 'error' => $message ];
		};

		if ( (int) ( $file['error'] ?? UPLOAD_ERR_NO_FILE ) !== UPLOAD_ERR_OK ) {
			return $fail( UPLOAD_ERR_INI_SIZE === (int) $file['error'] || UPLOAD_ERR_FORM_SIZE === (int) $file['error']
				? __( 'Il file è troppo grande.', 'tw-formulari' )
				: __( 'Caricamento del file non riuscito. Riprova.', 'tw-formulari' ) );
		}
		if ( (int) $file['size'] <= 0 ) {
			return $fail( __( 'Il file è vuoto.', 'tw-formulari' ) );
		}
		if ( (int) $file['size'] > $max_size ) {
			/* translators: %d: maximum size in megabytes */
			return $fail( sprintf( __( 'Il file supera la dimensione massima di %d MB.', 'tw-formulari' ), (int) ( $max_size / 1048576 ) ) );
		}

		$name = (string) $file['name'];
		// Every dot-separated part must be harmless: "foto.php.jpg" is refused.
		foreach ( array_slice( explode( '.', strtolower( $name ) ), 1 ) as $part ) {
			if ( in_array( $part, Definition::FORBIDDEN_EXTENSIONS, true ) ) {
				return $fail( __( 'Questo tipo di file non è ammesso.', 'tw-formulari' ) );
			}
		}
		$ext = strtolower( (string) pathinfo( $name, PATHINFO_EXTENSION ) );
		if ( '' === $ext || ! in_array( $ext, $allowed, true ) || in_array( $ext, Definition::FORBIDDEN_EXTENSIONS, true ) || ! isset( self::MIME_BY_EXT[ $ext ] ) ) {
			/* translators: %s: list of allowed extensions */
			return $fail( sprintf( __( 'Formato non ammesso. Puoi caricare: %s.', 'tw-formulari' ), implode( ', ', array_intersect( $allowed, array_keys( self::MIME_BY_EXT ) ) ) ) );
		}

		$mime = self::detect_mime( (string) $file['tmp_name'] );
		if ( '' === $mime || ! in_array( $mime, self::MIME_BY_EXT[ $ext ], true ) ) {
			return $fail( __( 'Il contenuto del file non corrisponde al suo formato.', 'tw-formulari' ) );
		}
		if ( in_array( $ext, [ 'jpg', 'jpeg', 'png', 'gif', 'webp' ], true ) && function_exists( 'getimagesize' ) && false === @getimagesize( (string) $file['tmp_name'] ) ) {
			return $fail( __( 'L’immagine non è valida.', 'tw-formulari' ) );
		}

		return [ 'ext' => $ext, 'mime' => $mime, 'error' => null ];
	}

	/**
	 * $_FILES stores multiple files as parallel arrays. This turns them into a list of single files.
	 *
	 * @param array<string, mixed>|null $raw
	 * @return array<int, array<string, mixed>>
	 */
	public static function normalise_files( ?array $raw ): array {
		if ( ! $raw || ! isset( $raw['name'] ) ) {
			return [];
		}
		if ( ! is_array( $raw['name'] ) ) {
			return ( (int) ( $raw['error'] ?? UPLOAD_ERR_NO_FILE ) === UPLOAD_ERR_NO_FILE ) ? [] : [ $raw ];
		}
		$out = [];
		foreach ( array_keys( $raw['name'] ) as $i ) {
			if ( (int) ( $raw['error'][ $i ] ?? UPLOAD_ERR_NO_FILE ) === UPLOAD_ERR_NO_FILE ) {
				continue;
			}
			$out[] = [
				'name'     => $raw['name'][ $i ] ?? '',
				'type'     => $raw['type'][ $i ] ?? '',
				'tmp_name' => $raw['tmp_name'][ $i ] ?? '',
				'error'    => $raw['error'][ $i ] ?? UPLOAD_ERR_NO_FILE,
				'size'     => $raw['size'][ $i ] ?? 0,
			];
		}
		return $out;
	}

	/**
	 * Absolute path of a stored file, or '' when the descriptor points outside the private folder.
	 *
	 * @param array<string, mixed> $file Descriptor with a relative "path".
	 */
	public static function absolute_path( array $file ): string {
		$rel = (string) ( $file['path'] ?? '' );
		if ( '' === $rel || false !== strpos( $rel, '..' ) || 0 === strpos( $rel, '/' ) ) {
			return '';
		}
		$path = self::private_dir() . $rel;
		return is_file( $path ) ? $path : '';
	}

	/**
	 * @param array<int, array<string, mixed>> $files
	 */
	public static function delete_files( array $files ): void {
		foreach ( $files as $file ) {
			$path = is_array( $file ) ? self::absolute_path( $file ) : '';
			if ( '' !== $path ) {
				@unlink( $path );
			}
		}
	}

	private static function detect_mime( string $path ): string {
		if ( '' === $path || ! is_file( $path ) ) {
			return '';
		}
		if ( function_exists( 'finfo_open' ) ) {
			$finfo = finfo_open( FILEINFO_MIME_TYPE );
			if ( $finfo ) {
				$mime = (string) finfo_file( $finfo, $path );
				finfo_close( $finfo );
				return $mime;
			}
		}
		return function_exists( 'mime_content_type' ) ? (string) mime_content_type( $path ) : '';
	}

	/** A readable, safe version of the original name (shown in the admin and in e-mails). */
	private static function display_name( string $name ): string {
		$name = function_exists( 'sanitize_file_name' ) ? sanitize_file_name( $name ) : preg_replace( '/[^A-Za-z0-9._-]/', '_', $name );
		return substr( (string) $name, 0, 120 );
	}
}
