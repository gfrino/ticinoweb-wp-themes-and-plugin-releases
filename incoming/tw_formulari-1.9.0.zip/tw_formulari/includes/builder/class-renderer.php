<?php
/**
 * Draws a form on the page (shortcode [tw_form id="12"]).
 *
 * Accessible markup (real labels, fieldsets, live status area), no inline scripts: the behaviour (pages,
 * show/hide rules, live totals, sending without reloading) lives in assets/builder/frontend.js, which reads the
 * JSON configuration printed next to the form.
 *
 * @package TicinoWeb\TWFormulari\Builder
 */

namespace TicinoWeb\TWFormulari\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Renderer {

	public const SCRIPT_HANDLE = 'tw-formulari-form';
	public const STYLE_HANDLE  = 'tw-formulari-form';

	/** Forms drawn on this page (used to print each custom CSS once). */
	private static $drawn = [];

	/**
	 * @param int                  $form_id
	 * @param array<string, mixed> $def  Normalised definition.
	 * @return string HTML.
	 */
	public static function render( int $form_id, array $def, array $args = [] ): string {
		$preview = ! empty( $args['preview'] );
		if ( ! $preview ) {
			self::enqueue_assets();
		}

		$settings = (array) $def['settings'];
		$steps    = Definition::steps( $def );
		$dom_id   = 'twf-form-' . $form_id . '-' . ( count( self::$drawn[ $form_id ] ?? [] ) + 1 );
		self::$drawn[ $form_id ][] = $dom_id;

		$html  = '<div class="twf-form twf-style-' . esc_attr( (string) $settings['style'] ) . '" id="' . esc_attr( $dom_id ) . '" data-twf-form="' . (int) $form_id . '"' . ( $preview ? ' data-twf-preview="1"' : '' ) . ' style="--twf-accent:' . esc_attr( (string) $settings['accent'] ) . '">';
		$html .= '<form class="twf-form__form" method="post" enctype="multipart/form-data" novalidate aria-label="' . esc_attr( (string) ( $def['title'] ?? '' ) ) . '">';
		$html .= '<input type="hidden" name="' . esc_attr( Submission::TOKEN_FIELD ) . '" value="' . esc_attr( Submission::make_token( $form_id ) ) . '">';

		if ( ! empty( $settings['honeypot'] ) ) {
			$html .= '<div class="twf-hp" aria-hidden="true" style="position:absolute;left:-9999px;top:auto;width:1px;height:1px;overflow:hidden">'
				. '<label>' . esc_html__( 'Non compilare questo campo', 'tw-formulari' ) . '<input type="text" name="' . esc_attr( Submission::HONEYPOT_FIELD ) . '" value="" tabindex="-1" autocomplete="off"></label></div>';
		}

		$total = count( $steps );
		foreach ( $steps as $i => $step ) {
			$html .= '<div class="twf-step" data-step="' . (int) $i . '"' . ( $i > 0 ? ' hidden' : '' ) . '>';
			if ( $total > 1 ) {
				$html .= '<p class="twf-step__title">' . sprintf(
					/* translators: 1: current page, 2: total pages */
					esc_html__( 'Passo %1$d di %2$d', 'tw-formulari' ),
					$i + 1,
					$total
				) . ( '' !== $step['title'] ? ' — ' . esc_html( $step['title'] ) : '' ) . '</p>';
			}
			$html .= '<div class="twf-fields">';
			foreach ( $step['fields'] as $field ) {
				$html .= self::render_field( $form_id, $field );
			}
			$html .= '</div></div>';
		}

		if ( ! empty( $def['payment']['enabled'] ) ) {
			$html .= self::render_payment( $def, $preview );
		}

		$html .= '<div class="twf-nav">';
		if ( $total > 1 ) {
			$html .= '<button type="button" class="twf-btn twf-btn--secondary twf-prev" hidden>' . esc_html__( 'Indietro', 'tw-formulari' ) . '</button>';
			$html .= '<button type="button" class="twf-btn twf-next">' . esc_html__( 'Avanti', 'tw-formulari' ) . '</button>';
		}
		$html .= '<button type="submit" class="twf-btn twf-submit"' . ( $total > 1 ? ' hidden' : '' ) . '>' . esc_html( (string) $settings['submit_label'] ) . '</button>';
		$html .= '</div>';
		$html .= '<div class="twf-status" role="status" aria-live="polite"></div>';
		$html .= '</form>';
		$html .= '<noscript><p>' . esc_html__( 'Per inviare questo modulo serve JavaScript.', 'tw-formulari' ) . '</p></noscript>';
		$html .= '<script type="application/json" class="twf-config">' . self::config_json( $form_id, $def ) . '</script>';

		if ( '' !== (string) $settings['custom_css'] && ( $preview || 1 === count( self::$drawn[ $form_id ] ) ) ) {
			$html .= '<style>' . $settings['custom_css'] . '</style>';
		}
		$html .= '</div>';

		return $html;
	}

	/**
	 * The payment area (shown on the last page): the total and the place where Stripe draws its own fields.
	 * The card data never touches this site: they are typed inside Stripe's iframe.
	 *
	 * @param array<string, mixed> $def
	 */
	private static function render_payment( array $def, bool $preview ): string {
		$html  = '<div class="twf-payment" data-twf-payment' . ( $preview ? '' : ' hidden' ) . '>';
		$html .= '<h3 class="twf-payment__title">' . esc_html__( 'Pagamento', 'tw-formulari' ) . '</h3>';
		$html .= '<p class="twf-payment__total">' . esc_html__( 'Totale da pagare:', 'tw-formulari' ) . ' <strong class="twf-payment__amount">—</strong></p>';
		if ( $preview ) {
			$html .= '<div class="twf-payment__placeholder">' . esc_html__( 'Qui Stripe mostra i metodi di pagamento: carta, Apple Pay, Google Pay e TWINT.', 'tw-formulari' ) . '</div>';
		} elseif ( ! Stripe::is_configured() ) {
			$html .= '<p class="twf-notice" role="alert">' . esc_html( current_user_can( 'manage_options' )
				? __( 'Stripe non è ancora configurato: inserisci le chiavi in TW Formulari → Pagamenti. I visitatori non possono pagare finché non lo fai.', 'tw-formulari' )
				: __( 'Il pagamento online non è disponibile in questo momento.', 'tw-formulari' ) ) . '</p>';
		} else {
			$html .= '<div class="twf-payment__element"></div>';
			$html .= '<p class="twf-payment__secure">' . esc_html__( 'Pagamento sicuro gestito da Stripe: i dati della carta non passano da questo sito.', 'tw-formulari' ) . '</p>';
		}
		return $html . '<p class="twf-payment__message" role="alert"></p></div>';
	}

	/**
	 * @param array<string, mixed> $field
	 */
	public static function render_field( int $form_id, array $field ): string {
		$type = (string) $field['type'];
		$id   = (string) $field['id'];
		$dom  = 'twf-' . $form_id . '-' . $id;

		if ( 'html' === $type ) {
			return '<div class="twf-field twf-type-html' . self::extra_classes( $field ) . '" data-field-id="' . esc_attr( $id ) . '">' . (string) ( $field['content'] ?? '' ) . '</div>';
		}
		if ( 'section' === $type ) {
			$out  = '<div class="twf-field twf-type-section twf-width-full' . self::extra_classes( $field ) . '" data-field-id="' . esc_attr( $id ) . '">';
			$out .= '<h3 class="twf-section__title">' . esc_html( (string) $field['label'] ) . '</h3>';
			$out .= '' !== (string) $field['description'] ? '<p class="twf-description">' . esc_html( (string) $field['description'] ) . '</p>' : '';
			return $out . '</div>';
		}
		if ( 'hidden' === $type ) {
			return '<input type="hidden" name="twf_f[' . esc_attr( $id ) . ']" value="' . esc_attr( (string) ( $field['default'] ?? '' ) ) . '" data-field-id="' . esc_attr( $id ) . '"' . ( ! empty( $field['param'] ) ? ' data-param="' . esc_attr( (string) $field['param'] ) . '"' : '' ) . '>';
		}
		if ( 'gdpr' === $type ) {
			$content = '' !== (string) ( $field['content'] ?? '' ) ? (string) $field['content'] : esc_html( (string) $field['label'] );
			$out     = '<div class="twf-field twf-type-gdpr twf-width-full' . self::extra_classes( $field ) . '" data-field-id="' . esc_attr( $id ) . '">';
			$out    .= '<label class="twf-check" for="' . esc_attr( $dom ) . '"><input type="checkbox" id="' . esc_attr( $dom ) . '" name="twf_f[' . esc_attr( $id ) . ']" value="1" aria-required="true" aria-describedby="' . esc_attr( $dom ) . '-err"> <span>' . $content . '</span></label>';
			return $out . '<p class="twf-error" id="' . esc_attr( $dom ) . '-err" role="alert"></p></div>';
		}

		$width = 'half' === ( $field['width'] ?? '' ) ? 'half' : 'full';
		$out   = '<div class="twf-field twf-type-' . esc_attr( $type ) . ' twf-width-' . $width . self::extra_classes( $field ) . '" data-field-id="' . esc_attr( $id ) . '"' . ( ! empty( $field['conditions'] ) ? ' data-has-conditions="1" data-condition-label="' . esc_attr__( 'Con condizione', 'tw-formulari' ) . '"' : '' ) . '>';

		$grouped = in_array( $type, [ 'radio', 'checkbox', 'name', 'address' ], true );
		$label   = esc_html( (string) $field['label'] ) . ( ! empty( $field['required'] ) ? ' <span class="twf-req" aria-hidden="true">*</span>' : '' );
		if ( $grouped ) {
			$out .= '<fieldset class="twf-group"><legend class="twf-label">' . $label . '</legend>';
		} else {
			$out .= '<label class="twf-label" for="' . esc_attr( $dom ) . '">' . $label . '</label>';
		}
		if ( '' !== (string) $field['description'] ) {
			$out .= '<p class="twf-description" id="' . esc_attr( $dom ) . '-desc">' . esc_html( (string) $field['description'] ) . '</p>';
		}

		$describedby = esc_attr( $dom ) . '-err' . ( '' !== (string) $field['description'] ? ' ' . esc_attr( $dom ) . '-desc' : '' );
		$common      = ' id="' . esc_attr( $dom ) . '" name="twf_f[' . esc_attr( $id ) . ']" aria-describedby="' . $describedby . '"' . ( ! empty( $field['required'] ) ? ' aria-required="true"' : '' );
		$ph          = '' !== (string) $field['placeholder'] ? ' placeholder="' . esc_attr( (string) $field['placeholder'] ) . '"' : '';

		switch ( $type ) {
			case 'text':
				$out .= '<input type="text"' . $common . $ph . ( ! empty( $field['max_length'] ) ? ' maxlength="' . (int) $field['max_length'] . '"' : '' ) . ' value="' . esc_attr( (string) ( $field['default'] ?? '' ) ) . '">';
				break;
			case 'textarea':
				$out .= '<textarea rows="5"' . $common . $ph . ( ! empty( $field['max_length'] ) ? ' maxlength="' . (int) $field['max_length'] . '"' : '' ) . '>' . esc_textarea( (string) ( $field['default'] ?? '' ) ) . '</textarea>';
				break;
			case 'email':
				$out .= '<input type="email" autocomplete="email" inputmode="email"' . $common . $ph . '>';
				break;
			case 'phone':
				$out .= '<input type="tel" autocomplete="tel" inputmode="tel"' . $common . $ph . '>';
				break;
			case 'number':
			case 'currency':
				$step = 'currency' === $type ? '0.01' : ( '' !== (string) ( $field['step'] ?? '' ) ? (string) $field['step'] : 'any' );
				$out .= '<input type="number" inputmode="decimal" step="' . esc_attr( $step ) . '"'
					. ( '' !== (string) ( $field['min'] ?? '' ) ? ' min="' . esc_attr( (string) $field['min'] ) . '"' : '' )
					. ( '' !== (string) ( $field['max'] ?? '' ) ? ' max="' . esc_attr( (string) $field['max'] ) . '"' : '' )
					. $common . $ph . ' value="' . esc_attr( (string) ( $field['default'] ?? '' ) ) . '">';
				break;
			case 'date':
				$out .= '<input type="date"' . $common
					. ( ! empty( $field['min_date'] ) ? ' min="' . esc_attr( (string) $field['min_date'] ) . '"' : '' )
					. ( ! empty( $field['max_date'] ) ? ' max="' . esc_attr( (string) $field['max_date'] ) . '"' : '' ) . '>';
				break;
			case 'select':
				$out .= '<select' . $common . '><option value="">' . esc_html__( 'Scegli…', 'tw-formulari' ) . '</option>';
				foreach ( (array) ( $field['options'] ?? [] ) as $opt ) {
					$out .= '<option value="' . esc_attr( (string) $opt['value'] ) . '">' . esc_html( (string) $opt['label'] ) . '</option>';
				}
				$out .= '</select>';
				break;
			case 'radio':
			case 'checkbox':
				$name  = 'twf_f[' . $id . ']' . ( 'checkbox' === $type ? '[]' : '' );
				$input = 'radio' === $type ? 'radio' : 'checkbox';
				foreach ( array_values( (array) ( $field['options'] ?? [] ) ) as $n => $opt ) {
					$opt_id = $dom . '-' . $n;
					$out   .= '<label class="twf-check" for="' . esc_attr( $opt_id ) . '"><input type="' . $input . '" id="' . esc_attr( $opt_id ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( (string) $opt['value'] ) . '"> <span>' . esc_html( (string) $opt['label'] ) . '</span></label>';
				}
				break;
			case 'name':
				$out .= '<div class="twf-row"><input type="text" autocomplete="given-name" name="twf_f[' . esc_attr( $id ) . '][first]" placeholder="' . esc_attr__( 'Nome', 'tw-formulari' ) . '" aria-label="' . esc_attr__( 'Nome', 'tw-formulari' ) . '"' . ( ! empty( $field['required'] ) ? ' aria-required="true"' : '' ) . ' id="' . esc_attr( $dom ) . '">';
				if ( ! empty( $field['last'] ) ) {
					$out .= '<input type="text" autocomplete="family-name" name="twf_f[' . esc_attr( $id ) . '][last]" placeholder="' . esc_attr__( 'Cognome', 'tw-formulari' ) . '" aria-label="' . esc_attr__( 'Cognome', 'tw-formulari' ) . '">';
				}
				$out .= '</div>';
				break;
			case 'address':
				$out .= '<input type="text" autocomplete="street-address" name="twf_f[' . esc_attr( $id ) . '][street]" placeholder="' . esc_attr__( 'Via e numero', 'tw-formulari' ) . '" aria-label="' . esc_attr__( 'Via e numero', 'tw-formulari' ) . '" id="' . esc_attr( $dom ) . '">';
				$out .= '<div class="twf-row"><input type="text" autocomplete="postal-code" name="twf_f[' . esc_attr( $id ) . '][zip]" placeholder="' . esc_attr__( 'CAP', 'tw-formulari' ) . '" aria-label="' . esc_attr__( 'CAP', 'tw-formulari' ) . '"><input type="text" autocomplete="address-level2" name="twf_f[' . esc_attr( $id ) . '][city]" placeholder="' . esc_attr__( 'Località', 'tw-formulari' ) . '" aria-label="' . esc_attr__( 'Località', 'tw-formulari' ) . '"></div>';
				if ( ! empty( $field['country'] ) ) {
					$out .= '<input type="text" autocomplete="country-name" name="twf_f[' . esc_attr( $id ) . '][country]" placeholder="' . esc_attr__( 'Paese', 'tw-formulari' ) . '" aria-label="' . esc_attr__( 'Paese', 'tw-formulari' ) . '">';
				}
				break;
			case 'upload':
				$accept = '.' . implode( ',.', (array) $field['extensions'] );
				$out   .= '<input type="file" id="' . esc_attr( $dom ) . '" name="twf_files[' . esc_attr( $id ) . '][]" accept="' . esc_attr( $accept ) . '"' . ( (int) $field['max_files'] > 1 ? ' multiple' : '' ) . ' aria-describedby="' . $describedby . '"' . ( ! empty( $field['required'] ) ? ' aria-required="true"' : '' ) . ' data-max-mb="' . (int) $field['max_size_mb'] . '" data-max-files="' . (int) $field['max_files'] . '">';
				$out   .= '<p class="twf-hint">' . sprintf(
					/* translators: 1: maximum size in MB, 2: allowed extensions */
					esc_html__( 'Massimo %1$d MB per file. Formati: %2$s.', 'tw-formulari' ),
					(int) $field['max_size_mb'],
					esc_html( implode( ', ', (array) $field['extensions'] ) )
				) . '</p>';
				break;
			case 'calculation':
				$out .= '<output class="twf-calc" id="' . esc_attr( $dom ) . '" data-decimals="' . (int) $field['decimals'] . '">0</output>';
				break;
		}

		if ( $grouped ) {
			$out .= '</fieldset>';
		}
		$out .= '<p class="twf-error" id="' . esc_attr( $dom ) . '-err" role="alert"></p></div>';

		return $out;
	}

	/**
	 * Configuration read by the front-end script. Safe to print inside a script tag.
	 *
	 * @param array<string, mixed> $def
	 */
	public static function config_json( int $form_id, array $def ): string {
		$fields = [];
		foreach ( (array) $def['fields'] as $field ) {
			$item = [
				'id'         => $field['id'],
				'type'       => $field['type'],
				'required'   => ! empty( $field['required'] ),
				'conditions' => $field['conditions'],
			];
			if ( 'calculation' === $field['type'] ) {
				$item['formula']  = $field['formula'];
				$item['decimals'] = $field['decimals'];
			}
			if ( FieldTypes::has_options( (string) $field['type'] ) ) {
				$item['options'] = array_map( static function ( array $o ): array {
					return [ 'value' => $o['value'], 'calc' => $o['calc'] ];
				}, (array) $field['options'] );
			}
			$fields[] = $item;
		}

		$payment = null;
		if ( ! empty( $def['payment']['enabled'] ) ) {
			$p       = (array) $def['payment'];
			$lang    = strtolower( substr( Submission::current_lang(), 0, 2 ) );
			$payment = [
				'ready'       => Stripe::is_configured(),
				'pk'          => Stripe::is_configured() ? Stripe::publishable_key() : '',
				'currency'    => strtolower( (string) $p['currency'] ),
				'factor'      => Stripe::factor( (string) $p['currency'] ),
				'mode'        => (string) $p['mode'],
				'amount'      => '' !== (string) $p['amount'] ? (float) $p['amount'] : 0,
				'amountField' => (string) $p['amount_field'],
				'accent'      => (string) $def['settings']['accent'],
				'locale'      => in_array( $lang, [ 'it', 'de', 'fr', 'en', 'es', 'pt', 'nl' ], true ) ? $lang : 'auto',
				'confirm'     => esc_url_raw( rest_url( 'tw-formulari/v1/forms/' . $form_id . '/payment/confirm' ) ),
			];
		}

		$config = [
			'formId'  => $form_id,
			'payment' => $payment,
			'rest'   => esc_url_raw( rest_url( 'tw-formulari/v1/forms/' . $form_id . '/submit' ) ),
			'ajax'   => ! empty( $def['settings']['ajax'] ),
			'fields' => $fields,
			'i18n'   => [
				'required'   => __( 'Questo campo è obbligatorio.', 'tw-formulari' ),
				'consent'    => __( 'Devi accettare per proseguire.', 'tw-formulari' ),
				'preview'    => __( 'Anteprima: l’invio è disattivato.', 'tw-formulari' ),
				'sending'    => __( 'Invio in corso…', 'tw-formulari' ),
				'error'      => __( 'Non siamo riusciti a inviare il modulo. Controlla la connessione e riprova.', 'tw-formulari' ),
				'fileTooBig' => __( 'Il file supera la dimensione massima.', 'tw-formulari' ),
				'tooMany'    => __( 'Hai scelto troppi file.', 'tw-formulari' ),
				'payNotReady' => __( 'Il pagamento online non è disponibile in questo momento.', 'tw-formulari' ),
				'paying'     => __( 'Pagamento in corso…', 'tw-formulari' ),
				'payRetry'   => __( 'Riprova il pagamento', 'tw-formulari' ),
				'payChecking' => __( 'Verifica del pagamento…', 'tw-formulari' ),
				'payFailed'  => __( 'Il pagamento non è andato a buon fine. Riprova.', 'tw-formulari' ),
				'payRestart' => __( 'Compila di nuovo il modulo per riprovare.', 'tw-formulari' ),
				'payZero'    => __( 'Scegli almeno un’opzione a pagamento.', 'tw-formulari' ),
				'stripeLoad' => __( 'Non riusciamo a caricare il pagamento. Controlla la connessione e ricarica la pagina.', 'tw-formulari' ),
			],
		];

		return (string) wp_json_encode( $config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE );
	}

	/** Registers and loads the script and style (once per page). */
	public static function enqueue_assets(): void {
		if ( ! function_exists( 'wp_enqueue_script' ) ) {
			return;
		}
		wp_enqueue_style( self::STYLE_HANDLE, TW_FORMULARI_URL . 'assets/builder/frontend.css', [], TW_FORMULARI_VERSION );
		wp_enqueue_script( self::SCRIPT_HANDLE, TW_FORMULARI_URL . 'assets/builder/frontend.js', [], TW_FORMULARI_VERSION, true );
	}

	/** @param array<string, mixed> $field */
	private static function extra_classes( array $field ): string {
		return '' !== (string) ( $field['css_class'] ?? '' ) ? ' ' . esc_attr( (string) $field['css_class'] ) : '';
	}
}
