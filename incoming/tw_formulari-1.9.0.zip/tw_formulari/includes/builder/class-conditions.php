<?php
/**
 * Conditional logic ("show this field only if…") evaluated on the server.
 *
 * The browser applies the same rules to show and hide fields live, but the server never trusts it:
 * a field that is hidden by its rules is not validated and its value is thrown away.
 *
 * Rule set shape:
 *   [ 'action' => 'show'|'hide', 'match' => 'all'|'any',
 *     'rules'  => [ [ 'field' => 'f1', 'op' => 'is', 'value' => 'x' ], … ] ]
 *
 * @package TicinoWeb\TWFormulari\Builder
 */

namespace TicinoWeb\TWFormulari\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Conditions {

	public const OPERATORS = [ 'is', 'is_not', 'contains', 'not_contains', 'starts', 'ends', 'gt', 'lt', 'empty', 'not_empty' ];

	/** Maximum passes used to settle fields that depend on other conditional fields. */
	private const MAX_PASSES = 6;

	/**
	 * Which fields are visible for the given values.
	 *
	 * @param array<int, array<string, mixed>> $fields Field definitions in page order.
	 * @param array<string, mixed>             $values Sanitised values keyed by field id.
	 * @return array<string, bool> field id => visible.
	 */
	public static function visible_map( array $fields, array $values ): array {
		$by_id   = [];
		$visible = [];
		foreach ( $fields as $field ) {
			if ( isset( $field['id'] ) ) {
				$by_id[ (string) $field['id'] ] = $field;
				$visible[ (string) $field['id'] ] = true;
			}
		}

		for ( $pass = 0; $pass < self::MAX_PASSES; $pass++ ) {
			// A hidden field counts as empty for the rules that look at it.
			$effective = [];
			foreach ( $values as $id => $value ) {
				$effective[ $id ] = ( $visible[ $id ] ?? true ) ? $value : null;
			}

			$changed = false;
			foreach ( $fields as $field ) {
				$id = (string) ( $field['id'] ?? '' );
				if ( '' === $id ) {
					continue;
				}
				$now = self::field_is_visible( $field, $by_id, $effective );
				if ( $now !== $visible[ $id ] ) {
					$visible[ $id ] = $now;
					$changed        = true;
				}
			}
			if ( ! $changed ) {
				break;
			}
		}

		return $visible;
	}

	/**
	 * @param array<string, mixed>               $field
	 * @param array<string, array<string, mixed>> $by_id
	 * @param array<string, mixed>               $values
	 */
	public static function field_is_visible( array $field, array $by_id, array $values ): bool {
		$conditions = $field['conditions'] ?? null;
		if ( ! is_array( $conditions ) || empty( $conditions['rules'] ) ) {
			return true;
		}
		$matches = self::evaluate( $conditions, $by_id, $values );
		return 'hide' === ( $conditions['action'] ?? 'show' ) ? ! $matches : $matches;
	}

	/**
	 * Whether the rule set matches (before applying show/hide).
	 *
	 * @param array<string, mixed>               $conditions
	 * @param array<string, array<string, mixed>> $by_id
	 * @param array<string, mixed>               $values
	 */
	public static function evaluate( array $conditions, array $by_id, array $values ): bool {
		$rules = array_filter( (array) ( $conditions['rules'] ?? [] ), 'is_array' );
		if ( ! $rules ) {
			return true;
		}
		$any = 'any' === ( $conditions['match'] ?? 'all' );

		foreach ( $rules as $rule ) {
			$ok = self::rule_matches( $rule, $by_id, $values );
			if ( $any && $ok ) {
				return true;
			}
			if ( ! $any && ! $ok ) {
				return false;
			}
		}
		return ! $any;
	}

	/**
	 * @param array<string, mixed>               $rule
	 * @param array<string, array<string, mixed>> $by_id
	 * @param array<string, mixed>               $values
	 */
	private static function rule_matches( array $rule, array $by_id, array $values ): bool {
		$id    = (string) ( $rule['field'] ?? '' );
		$op    = (string) ( $rule['op'] ?? 'is' );
		$field = $by_id[ $id ] ?? null;
		if ( null === $field || ! in_array( $op, self::OPERATORS, true ) ) {
			return false;
		}

		$value   = $values[ $id ] ?? null;
		$parts   = self::comparable( $field, $value );
		$target  = trim( (string) ( $rule['value'] ?? '' ) );
		$is_blank = ! array_filter( $parts, static function ( string $p ): bool {
			return '' !== $p;
		} );

		switch ( $op ) {
			case 'empty':
				return $is_blank;
			case 'not_empty':
				return ! $is_blank;
			case 'is':
				return in_array( $target, $parts, true ) || ( '' === $target && $is_blank );
			case 'is_not':
				return ! in_array( $target, $parts, true ) && ! ( '' === $target && $is_blank );
			case 'contains':
				foreach ( $parts as $part ) {
					if ( '' !== $target && false !== stripos( $part, $target ) ) {
						return true;
					}
				}
				return false;
			case 'not_contains':
				foreach ( $parts as $part ) {
					if ( '' !== $target && false !== stripos( $part, $target ) ) {
						return false;
					}
				}
				return true;
			case 'starts':
				foreach ( $parts as $part ) {
					if ( '' !== $target && 0 === stripos( $part, $target ) ) {
						return true;
					}
				}
				return false;
			case 'ends':
				foreach ( $parts as $part ) {
					if ( '' !== $target && strlen( $part ) >= strlen( $target ) && 0 === strcasecmp( substr( $part, -strlen( $target ) ), $target ) ) {
						return true;
					}
				}
				return false;
			case 'gt':
			case 'lt':
				$number = FieldTypes::numeric_value( $field, $value );
				if ( ! is_numeric( $target ) || $is_blank ) {
					return false;
				}
				return 'gt' === $op ? $number > (float) $target : $number < (float) $target;
		}

		return false;
	}

	/**
	 * The strings a value can be compared with (several for checkboxes).
	 *
	 * @param array<string, mixed> $field
	 * @param mixed                $value
	 * @return string[]
	 */
	private static function comparable( array $field, $value ): array {
		if ( null === $value ) {
			return [];
		}
		$type = (string) ( $field['type'] ?? 'text' );
		if ( 'checkbox' === $type ) {
			return array_map( 'strval', array_values( (array) $value ) );
		}
		if ( 'gdpr' === $type ) {
			return [ true === $value ? '1' : '' ];
		}
		if ( in_array( $type, [ 'name', 'address' ], true ) ) {
			return [ FieldTypes::display_value( $field, $value ) ];
		}
		return [ is_scalar( $value ) ? trim( (string) $value ) : '' ];
	}
}
