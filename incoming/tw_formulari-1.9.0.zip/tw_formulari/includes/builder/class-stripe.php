<?php
/**
 * Payments with Stripe (Payment Element: cards, Apple Pay, Google Pay, TWINT), without the Stripe SDK.
 *
 * The rules that keep the money honest:
 *  - The amount is ALWAYS computed here, from the answers, with the same calculator used for the form. The browser
 *    only shows a preview; whatever amount it "sends" is ignored.
 *  - A submission of a form with payment is stored as "pending payment" and no e-mail is sent. It becomes "paid"
 *    (and the e-mails go out, exactly once) only after the PaymentIntent has been read back from Stripe with the
 *    secret key and found succeeded, for the same entry, amount and currency. Both the visitor coming back from the
 *    payment page and the signed webhook go through the same, idempotent code (sync_intent).
 *  - The keys live in wp-config.php constants (preferred) or in a non-autoloaded option; the secret never reaches
 *    the browser or the page source.
 *
 * @package TicinoWeb\TWFormulari\Builder
 */

namespace TicinoWeb\TWFormulari\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Stripe {

	public const OPTION         = 'twf_stripe_settings';
	public const CRON_HOOK      = 'tw_formulari_stripe_reconcile';
	public const API_BASE       = 'https://api.stripe.com/v1/';
	/** Pinned so responses keep the same shape when Stripe publishes a new version. */
	public const API_VERSION    = '2024-06-20';
	/** Stripe refuses payments below this (in major units: 0.50). */
	public const MIN_MINOR      = 50;
	/** A pending payment nobody started or finished is cancelled and removed after this many days. */
	public const PENDING_DAYS   = 3;

	/** Currencies without decimals. */
	private const ZERO_DECIMAL = [ 'BIF', 'CLP', 'DJF', 'GNF', 'JPY', 'KMF', 'KRW', 'MGA', 'PYG', 'RWF', 'UGX', 'VND', 'VUV', 'XAF', 'XOF', 'XPF' ];

	public static function init(): void {
		add_action( 'rest_api_init', [ self::class, 'register_routes' ] );
		add_action( self::CRON_HOOK, [ self::class, 'reconcile' ] );
		add_action( 'init', [ self::class, 'schedule' ], 21 );
	}

	public static function schedule(): void {
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + 15 * MINUTE_IN_SECONDS, 'hourly', self::CRON_HOOK );
		}
	}

	// ---------------------------------------------------------------------
	// Configuration
	// ---------------------------------------------------------------------

	/** The three values of one mode. */
	public const KEYS = [ 'publishable', 'secret', 'webhook' ];

	/**
	 * What is saved: the mode in use and the two sets of keys (test and live), kept apart so that switching mode
	 * never needs the keys to be typed again. An older flat layout (one set) is read as the mode its key says.
	 *
	 * @return array{mode:string, test:array<string,string>, live:array<string,string>}
	 */
	public static function stored(): array {
		$saved = (array) get_option( self::OPTION, [] );
		$out   = [
			'mode' => 'test',
			'test' => array_fill_keys( self::KEYS, '' ),
			'live' => array_fill_keys( self::KEYS, '' ),
		];
		if ( isset( $saved['publishable'] ) || isset( $saved['secret'] ) ) {
			$legacy_mode = 0 === strpos( (string) ( $saved['publishable'] ?? '' ), 'pk_live_' ) ? 'live' : 'test';
			$out['mode'] = $legacy_mode;
			foreach ( self::KEYS as $k ) {
				$out[ $legacy_mode ][ $k ] = is_string( $saved[ $k ] ?? null ) ? trim( $saved[ $k ] ) : '';
			}
			return $out;
		}
		$out['mode'] = 'live' === ( $saved['mode'] ?? '' ) ? 'live' : 'test';
		foreach ( [ 'test', 'live' ] as $m ) {
			foreach ( self::KEYS as $k ) {
				$out[ $m ][ $k ] = isset( $saved[ $m ][ $k ] ) && is_string( $saved[ $m ][ $k ] ) ? trim( $saved[ $m ][ $k ] ) : '';
			}
		}
		return $out;
	}

	/** Name of the wp-config.php constant for a value of a mode, e.g. TWF_STRIPE_TEST_SECRET_KEY. */
	public static function constant_name( string $mode, string $key ): string {
		$suffix = [ 'publishable' => 'PUBLISHABLE_KEY', 'secret' => 'SECRET_KEY', 'webhook' => 'WEBHOOK_SECRET' ][ $key ];
		return 'TWF_STRIPE_' . strtoupper( $mode ) . '_' . $suffix;
	}

	/** Mode in use: "test" or "live". TWF_STRIPE_MODE in wp-config.php wins over the saved choice. */
	public static function selected_mode(): string {
		if ( defined( 'TWF_STRIPE_MODE' ) && in_array( constant( 'TWF_STRIPE_MODE' ), [ 'test', 'live' ], true ) ) {
			return (string) constant( 'TWF_STRIPE_MODE' );
		}
		return self::stored()['mode'];
	}

	/**
	 * The three values of a mode (wp-config.php constants win over the saved ones).
	 *
	 * @return array{publishable:string, secret:string, webhook:string}
	 */
	public static function keys( string $mode ): array {
		$mode  = 'live' === $mode ? 'live' : 'test';
		$saved = self::stored()[ $mode ];
		$out   = [];
		foreach ( self::KEYS as $k ) {
			$const = self::constant_name( $mode, $k );
			$out[ $k ] = defined( $const ) && is_string( constant( $const ) ) && '' !== constant( $const ) ? trim( (string) constant( $const ) ) : $saved[ $k ];
		}
		return $out;
	}

	/**
	 * The values of the mode in use.
	 *
	 * @return array{publishable:string, secret:string, webhook:string}
	 */
	public static function settings(): array {
		return self::keys( self::selected_mode() );
	}

	/** Which values come from wp-config.php (and so cannot be changed in the screen). */
	public static function from_constants(): array {
		$out = [ 'mode' => defined( 'TWF_STRIPE_MODE' ) && in_array( constant( 'TWF_STRIPE_MODE' ), [ 'test', 'live' ], true ) ];
		foreach ( [ 'test', 'live' ] as $m ) {
			foreach ( self::KEYS as $k ) {
				$const           = self::constant_name( $m, $k );
				$out[ $m ][ $k ] = defined( $const ) && '' !== (string) constant( $const );
			}
		}
		return $out;
	}

	public static function publishable_key(): string {
		return self::settings()['publishable'];
	}

	/** Shape check of a value of a mode (e.g. a live key is refused in the test set). */
	public static function key_is_valid( string $mode, string $key, string $value ): bool {
		$mode = 'live' === $mode ? 'live' : 'test';
		$re   = [
			'publishable' => '/^pk_' . $mode . '_[A-Za-z0-9]+$/',
			'secret'      => '/^(sk|rk)_' . $mode . '_[A-Za-z0-9]+$/',
			'webhook'     => '/^whsec_[A-Za-z0-9]+$/',
		][ $key ] ?? '';
		return '' !== $re && (bool) preg_match( $re, $value );
	}

	/** True when the public and the secret key of the mode in use are both there and really of that mode. */
	public static function is_configured(): bool {
		$mode = self::selected_mode();
		$s    = self::keys( $mode );
		return self::key_is_valid( $mode, 'publishable', $s['publishable'] ) && self::key_is_valid( $mode, 'secret', $s['secret'] );
	}

	/** "test" or "live" when Stripe is ready in that mode, "" when not configured. */
	public static function mode(): string {
		return self::is_configured() ? self::selected_mode() : '';
	}

	public static function webhook_url(): string {
		return rest_url( Builder::REST_NS . '/stripe/webhook' );
	}

	// ---------------------------------------------------------------------
	// Amounts
	// ---------------------------------------------------------------------

	/** Multiplier from major to minor units (100 for CHF, 1 for JPY). */
	public static function factor( string $currency ): int {
		return in_array( strtoupper( $currency ), self::ZERO_DECIMAL, true ) ? 1 : 100;
	}

	/**
	 * The amount to charge, computed from the answers.
	 *
	 * @param array<string, mixed> $def    Normalised definition.
	 * @param array<string, mixed> $values Visible values of the submission (calculations included).
	 * @return array{ok:bool, minor:int, amount:string, currency:string, error:string}
	 */
	public static function amount( array $def, array $values ): array {
		$p        = (array) ( $def['payment'] ?? [] );
		$currency = strtoupper( (string) ( $p['currency'] ?? 'CHF' ) );
		$factor   = self::factor( $currency );
		$fail     = static function ( string $error ) use ( $currency ): array {
			return [ 'ok' => false, 'minor' => 0, 'amount' => '0.00', 'currency' => $currency, 'error' => $error ];
		};

		if ( 'fixed' === ( $p['mode'] ?? 'fixed' ) ) {
			$major = (float) ( '' !== (string) ( $p['amount'] ?? '' ) ? $p['amount'] : 0 );
		} else {
			$by_id = Definition::field_map( $def );
			$field = $by_id[ (string) ( $p['amount_field'] ?? '' ) ] ?? null;
			if ( null === $field ) {
				return $fail( __( 'L’importo da pagare non è impostato nel modulo.', 'tw-formulari' ) );
			}
			$major = FieldTypes::numeric_value( $field, $values[ $field['id'] ] ?? null );
		}

		$minor = (int) round( $major * $factor );
		if ( $minor <= 0 ) {
			return $fail( __( 'L’importo da pagare è zero: scegli almeno un’opzione a pagamento.', 'tw-formulari' ) );
		}
		$min_minor = max( (int) apply_filters( 'twf_stripe_min_minor', self::MIN_MINOR, $currency ), self::MIN_MINOR );
		if ( $minor < $min_minor ) {
			return $fail( __( 'L’importo è inferiore al minimo accettato dal pagamento online.', 'tw-formulari' ) );
		}
		if ( '' !== (string) ( $p['min_amount'] ?? '' ) && $minor < (int) round( (float) $p['min_amount'] * $factor ) ) {
			return $fail( __( 'L’importo è inferiore al minimo previsto per questo modulo.', 'tw-formulari' ) );
		}
		if ( '' !== (string) ( $p['max_amount'] ?? '' ) && (float) $p['max_amount'] > 0 && $minor > (int) round( (float) $p['max_amount'] * $factor ) ) {
			return $fail( __( 'L’importo è superiore al massimo previsto per questo modulo.', 'tw-formulari' ) );
		}
		if ( $minor > 99999999 ) {
			return $fail( __( 'L’importo è troppo alto.', 'tw-formulari' ) );
		}

		return [
			'ok'       => true,
			'minor'    => $minor,
			'amount'   => number_format( $minor / $factor, 1 === $factor ? 0 : 2, '.', '' ),
			'currency' => $currency,
			'error'    => '',
		];
	}

	// ---------------------------------------------------------------------
	// Starting a payment (called by Submission)
	// ---------------------------------------------------------------------

	/**
	 * Creates the PaymentIntent of a stored, pending entry.
	 *
	 * @param array<string, mixed> $def
	 * @param array<string, mixed> $values
	 * @param array<string, mixed> $amount Result of amount().
	 * @return array{ok:bool, client_secret?:string, intent?:string, error?:string}
	 */
	public static function create_intent( int $form_id, int $entry_id, array $def, array $values, array $amount ): array {
		$p           = (array) $def['payment'];
		$title       = (string) ( $def['title'] ?? '' );
		$description = '' !== (string) $p['description'] ? (string) $p['description'] : $title;
		$description = strtr( $description, [ '{form_title}' => $title, '{entry_id}' => (string) $entry_id, '{site_name}' => (string) get_bloginfo( 'name' ) ] );

		$params = [
			'amount'                            => $amount['minor'],
			'currency'                          => strtolower( $amount['currency'] ),
			'automatic_payment_methods[enabled]' => 'true',
			'description'                       => function_exists( 'mb_substr' ) ? mb_substr( $description, 0, 300 ) : substr( $description, 0, 300 ),
			'metadata[twf_form]'                => $form_id,
			'metadata[twf_entry]'               => $entry_id,
			'metadata[twf_site]'                => (string) wp_parse_url( home_url(), PHP_URL_HOST ),
		];
		$email = (string) ( $values[ (string) $p['email_field'] ] ?? '' );
		if ( '' !== $email && is_email( $email ) ) {
			$params['receipt_email'] = $email;
		}

		$res = self::request( 'POST', 'payment_intents', $params, [ 'Idempotency-Key' => 'twf-' . substr( md5( home_url() ), 0, 8 ) . '-' . $entry_id ] );
		if ( ! $res['ok'] || empty( $res['body']['id'] ) || empty( $res['body']['client_secret'] ) ) {
			return [ 'ok' => false, 'error' => (string) ( $res['error'] ?: 'Stripe ha risposto in modo inatteso.' ) ];
		}
		return [ 'ok' => true, 'client_secret' => (string) $res['body']['client_secret'], 'intent' => (string) $res['body']['id'] ];
	}

	// ---------------------------------------------------------------------
	// Confirming a payment (visitor coming back, webhook, clean-up)
	// ---------------------------------------------------------------------

	/**
	 * Reads the PaymentIntent from Stripe and brings the entry in line with it. Safe to call any number of times.
	 *
	 * @param string $intent_id    "pi_...".
	 * @param int    $expect_form  When > 0 the intent must belong to this form.
	 * @return array{status:int, body:array<string, mixed>}
	 */
	public static function sync_intent( string $intent_id, int $expect_form = 0 ): array {
		if ( ! preg_match( '/^pi_[A-Za-z0-9]{8,80}$/', $intent_id ) ) {
			return self::fail( 400, __( 'Pagamento non valido.', 'tw-formulari' ) );
		}
		if ( ! self::is_configured() ) {
			return self::fail( 503, __( 'Il pagamento non è disponibile in questo momento.', 'tw-formulari' ) );
		}
		$res = self::request( 'GET', 'payment_intents/' . $intent_id );
		if ( ! $res['ok'] ) {
			return self::fail( 502, __( 'Non riusciamo a verificare il pagamento in questo momento. Riprova tra poco: se è stato addebitato, la tua richiesta verrà comunque registrata.', 'tw-formulari' ) );
		}
		$pi = (array) $res['body'];

		$meta     = (array) ( $pi['metadata'] ?? [] );
		$form_id  = (int) ( $meta['twf_form'] ?? 0 );
		$entry_id = (int) ( $meta['twf_entry'] ?? 0 );
		$entry    = $entry_id > 0 ? Entries::get( $entry_id ) : null;
		$form     = $form_id > 0 ? Builder::get_form( $form_id ) : null;
		if ( ! $entry || ! $form || (int) $entry['form_id'] !== $form_id || ( $expect_form > 0 && $expect_form !== $form_id ) ) {
			return self::fail( 404, __( 'Pagamento non trovato.', 'tw-formulari' ) );
		}
		$payment = (array) $entry['payment'];
		if ( (string) ( $payment['intent'] ?? '' ) !== (string) ( $pi['id'] ?? '' ) ) {
			return self::fail( 400, __( 'Pagamento non valido.', 'tw-formulari' ) );
		}
		// A key of the other mode could never have created this intent; still, never mix test and live.
		if ( isset( $pi['livemode'] ) && ( (bool) $pi['livemode'] ? 'live' : 'test' ) !== self::mode() ) {
			return self::fail( 400, __( 'Pagamento non valido.', 'tw-formulari' ) );
		}

		$def    = $form['definition'];
		$status = (string) ( $pi['status'] ?? '' );

		if ( 'succeeded' === $status ) {
			$paid     = (int) ( $pi['amount_received'] ?? 0 );
			$currency = strtoupper( (string) ( $pi['currency'] ?? '' ) );
			if ( $paid !== (int) ( $payment['minor'] ?? -1 ) || $currency !== strtoupper( (string) ( $payment['currency'] ?? '' ) ) ) {
				// Money arrived but it is not what we asked for: never confirm silently, leave it to a person.
				$payment['status'] = 'mismatch';
				$payment['note']   = sprintf( 'Stripe: %d %s, atteso %d %s', $paid, $currency, (int) ( $payment['minor'] ?? 0 ), (string) ( $payment['currency'] ?? '' ) );
				Entries::transition( $entry_id, [ Entries::STATUS_PENDING_PAYMENT, Entries::STATUS_PAYMENT_FAILED ], Entries::STATUS_PAYMENT_FAILED, $payment );
				error_log( 'tw_formulari: importo pagato diverso da quello atteso, compilazione ' . $entry_id . ' (' . $payment['note'] . ')' );
				return self::fail( 409, __( 'Il pagamento non corrisponde a quanto richiesto. Ti contatteremo.', 'tw-formulari' ) );
			}

			$payment['status']    = 'paid';
			$payment['paid_gmt']  = gmdate( 'Y-m-d H:i:s' );
			$payment['charge']    = (string) ( $pi['latest_charge'] ?? '' );
			if ( Entries::transition( $entry_id, [ Entries::STATUS_PENDING_PAYMENT, Entries::STATUS_PAYMENT_FAILED ], Entries::STATUS_PAID, $payment ) ) {
				self::complete( $form_id, $entry_id, $entry, $def, $payment );
			}
			return [ 'status' => 200, 'body' => Submission::success_body( $def ) ];
		}

		if ( 'processing' === $status || 'requires_action' === $status || 'requires_confirmation' === $status ) {
			return [ 'status' => 202, 'body' => [ 'ok' => false, 'pending' => true, 'message' => __( 'Il pagamento è in elaborazione. Riceverai la conferma appena sarà completato.', 'tw-formulari' ) ] ];
		}

		// requires_payment_method or canceled. A declined attempt (error present) or a cancellation is a failure the
		// owner may want to see; a visitor who simply never paid leaves the entry pending, and the clean-up removes it.
		$declined = ! empty( $pi['last_payment_error'] ) || 'canceled' === $status;
		if ( $declined && Entries::STATUS_PENDING_PAYMENT === $entry['status'] ) {
			$payment['status'] = 'canceled' === $status ? 'canceled' : 'failed';
			$payment['note']   = isset( $pi['last_payment_error']['message'] ) ? substr( (string) $pi['last_payment_error']['message'], 0, 200 ) : '';
			Entries::transition( $entry_id, [ Entries::STATUS_PENDING_PAYMENT ], Entries::STATUS_PAYMENT_FAILED, $payment );
		}
		return self::fail( 402, $declined
			? __( 'Il pagamento non è andato a buon fine. Puoi riprovare con un altro metodo.', 'tw-formulari' )
			: __( 'Il pagamento non è stato completato.', 'tw-formulari' ) );
	}

	/**
	 * What happens once, when an entry turns paid: e-mails and the "completed" action.
	 *
	 * @param array<string, mixed> $entry   The entry as it was read (data, files).
	 * @param array<string, mixed> $def
	 * @param array<string, mixed> $payment
	 */
	private static function complete( int $form_id, int $entry_id, array $entry, array $def, array $payment ): void {
		$values = (array) $entry['data'];
		$files  = (array) $entry['files'];
		$sent   = Notifications::send_all( $def, $values, [
			'entry_id' => $entry_id,
			'files'    => $files,
			'payment'  => [ 'amount' => (float) ( $payment['amount'] ?? 0 ), 'currency' => (string) ( $payment['currency'] ?? '' ) ],
		] );
		if ( $sent['failed'] > 0 ) {
			error_log( sprintf( 'tw_formulari: %d notifica/e non inviata/e per il modulo %d (compilazione %d, pagata).', $sent['failed'], $form_id, $entry_id ) );
		}
		do_action( 'twf_submission_completed', $form_id, $entry_id, $values, $def );
		do_action( 'twf_payment_completed', $form_id, $entry_id, $payment );
	}

	// ---------------------------------------------------------------------
	// REST: the visitor's return and Stripe's webhook
	// ---------------------------------------------------------------------

	public static function register_routes(): void {
		register_rest_route( Builder::REST_NS, '/forms/(?P<id>\d+)/payment/confirm', [
			'methods'             => 'POST',
			// Public on purpose: the visitor is anonymous. Only a real, succeeded intent of this site changes anything.
			'permission_callback' => '__return_true',
			'callback'            => [ self::class, 'rest_confirm' ],
			'args'                => [ 'id' => [ 'sanitize_callback' => 'absint' ] ],
		] );
		register_rest_route( Builder::REST_NS, '/stripe/webhook', [
			'methods'             => 'POST',
			// Authenticated by the Stripe signature, not by a WordPress user.
			'permission_callback' => '__return_true',
			'callback'            => [ self::class, 'rest_webhook' ],
		] );
	}

	/**
	 * @param \WP_REST_Request $request
	 */
	public static function rest_confirm( $request ): \WP_REST_Response {
		$form_id = (int) $request['id'];
		$limit   = (int) apply_filters( 'twf_stripe_confirm_rate_limit', 60 );
		if ( Submission::rate_limited( $form_id + 1000000, $limit ) ) {
			$result = self::fail( 429, __( 'Troppe richieste. Riprova più tardi.', 'tw-formulari' ) );
		} else {
			$params = (array) wp_unslash( $request->get_body_params() );
			$result = self::sync_intent( (string) ( $params['payment_intent'] ?? '' ), $form_id );
		}
		$response = new \WP_REST_Response( $result['body'], $result['status'] );
		$response->header( 'Cache-Control', 'no-store, max-age=0' );
		return $response;
	}

	/**
	 * @param \WP_REST_Request $request
	 */
	public static function rest_webhook( $request ): \WP_REST_Response {
		$secrets = array_values( array_filter( [ self::keys( self::selected_mode() )['webhook'], self::keys( 'live' === self::selected_mode() ? 'test' : 'live' )['webhook'] ] ) );
		if ( ! $secrets ) {
			return new \WP_REST_Response( [ 'ok' => false, 'message' => 'Webhook secret not configured.' ], 503 );
		}
		$payload = (string) $request->get_body();
		$header  = (string) $request->get_header( 'stripe-signature' );
		$valid   = false;
		foreach ( $secrets as $secret ) {
			if ( self::verify_signature( $payload, $header, $secret ) ) {
				$valid = true;
				break;
			}
		}
		if ( ! $valid ) {
			return new \WP_REST_Response( [ 'ok' => false, 'message' => 'Invalid signature.' ], 400 );
		}
		$event = json_decode( $payload, true );
		// An event of the other mode (the test endpoint and the live one may both point here) is not ours to act on.
		if ( is_array( $event ) && ( ! empty( $event['livemode'] ) ? 'live' : 'test' ) !== self::selected_mode() ) {
			return new \WP_REST_Response( [ 'ok' => true, 'ignored' => true ], 200 );
		}
		$type  = is_array( $event ) ? (string) ( $event['type'] ?? '' ) : '';
		$id    = is_array( $event ) ? (string) ( $event['data']['object']['id'] ?? '' ) : '';

		if ( in_array( $type, [ 'payment_intent.succeeded', 'payment_intent.payment_failed', 'payment_intent.canceled' ], true ) && '' !== $id ) {
			$result = self::sync_intent( $id );
			// Events about payments that are not ours (the same Stripe account may serve other things) get a 200:
			// asking Stripe to retry them would only fill its queue.
			if ( in_array( $result['status'], [ 404, 400 ], true ) ) {
				return new \WP_REST_Response( [ 'ok' => true, 'ignored' => true ], 200 );
			}
			if ( $result['status'] >= 500 ) {
				return new \WP_REST_Response( [ 'ok' => false ], 500 );
			}
		}
		return new \WP_REST_Response( [ 'ok' => true ], 200 );
	}

	/**
	 * Checks the "Stripe-Signature" header: t=timestamp,v1=hmac_sha256("t.payload", secret). Rejects stale timestamps.
	 */
	public static function verify_signature( string $payload, string $header, string $secret, ?int $now = null, int $tolerance = 300 ): bool {
		if ( '' === $payload || '' === $header || '' === $secret ) {
			return false;
		}
		$timestamp  = 0;
		$signatures = [];
		foreach ( explode( ',', $header ) as $part ) {
			$kv = explode( '=', trim( $part ), 2 );
			if ( 2 !== count( $kv ) ) {
				continue;
			}
			if ( 't' === $kv[0] && ctype_digit( $kv[1] ) ) {
				$timestamp = (int) $kv[1];
			} elseif ( 'v1' === $kv[0] ) {
				$signatures[] = $kv[1];
			}
		}
		if ( $timestamp <= 0 || ! $signatures ) {
			return false;
		}
		if ( abs( ( $now ?? time() ) - $timestamp ) > $tolerance ) {
			return false;
		}
		$expected = hash_hmac( 'sha256', $timestamp . '.' . $payload, $secret );
		foreach ( $signatures as $sig ) {
			if ( hash_equals( $expected, $sig ) ) {
				return true;
			}
		}
		return false;
	}

	// ---------------------------------------------------------------------
	// Hourly clean-up of payments nobody finished
	// ---------------------------------------------------------------------

	/**
	 * Catches payments whose webhook never arrived, and removes the ones nobody paid.
	 */
	public static function reconcile(): void {
		if ( ! self::is_configured() ) {
			return;
		}
		// Started more than 20 minutes ago: ask Stripe how it went.
		foreach ( Entries::pending_payment_ids( 20 * MINUTE_IN_SECONDS, 50 ) as $entry_id ) {
			$entry  = Entries::get( $entry_id );
			$intent = $entry ? (string) ( $entry['payment']['intent'] ?? '' ) : '';
			if ( '' === $intent ) {
				continue;
			}
			self::sync_intent( $intent );
		}
		// Still pending after some days: nobody is going to pay. Cancel the intent and drop the entry with its files.
		$stale = Entries::pending_payment_ids( self::PENDING_DAYS * DAY_IN_SECONDS, 50 );
		foreach ( $stale as $entry_id ) {
			$entry = Entries::get( $entry_id );
			if ( ! $entry || Entries::STATUS_PENDING_PAYMENT !== $entry['status'] ) {
				continue;
			}
			$intent = (string) ( $entry['payment']['intent'] ?? '' );
			if ( '' !== $intent ) {
				self::request( 'POST', 'payment_intents/' . $intent . '/cancel' );
			}
			Entries::delete( [ $entry_id ] );
		}
	}

	// ---------------------------------------------------------------------
	// HTTP
	// ---------------------------------------------------------------------

	/**
	 * One call to the Stripe API.
	 *
	 * @param array<string, mixed>  $params  Form-encoded body (GET: query). Nested keys are written like "metadata[a]".
	 * @param array<string, string> $headers Extra headers.
	 * @return array{ok:bool, code:int, body:array<string, mixed>, error:string}
	 */
	public static function request( string $method, string $path, array $params = [], array $headers = [] ): array {
		$secret = self::settings()['secret'];
		if ( '' === $secret ) {
			return [ 'ok' => false, 'code' => 0, 'body' => [], 'error' => 'Stripe non è configurato.' ];
		}
		$url  = self::API_BASE . ltrim( $path, '/' );
		$args = [
			'method'  => $method,
			'timeout' => 25,
			'headers' => array_merge( [
				'Authorization'  => 'Bearer ' . $secret,
				'Stripe-Version' => (string) apply_filters( 'twf_stripe_api_version', self::API_VERSION ),
				'User-Agent'     => 'tw_formulari/' . ( defined( 'TW_FORMULARI_VERSION' ) ? TW_FORMULARI_VERSION : '' ),
			], $headers ),
		];
		if ( 'GET' === $method ) {
			if ( $params ) {
				$url .= '?' . http_build_query( $params, '', '&' );
			}
		} else {
			$args['body'] = http_build_query( $params, '', '&' );
		}

		$response = wp_remote_request( $url, $args );
		if ( is_wp_error( $response ) ) {
			return [ 'ok' => false, 'code' => 0, 'body' => [], 'error' => $response->get_error_message() ];
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		$body = is_array( $body ) ? $body : [];
		if ( $code < 200 || $code >= 300 ) {
			$message = isset( $body['error']['message'] ) ? (string) $body['error']['message'] : 'HTTP ' . $code;
			return [ 'ok' => false, 'code' => $code, 'body' => $body, 'error' => $message ];
		}
		return [ 'ok' => true, 'code' => $code, 'body' => $body, 'error' => '' ];
	}

	/**
	 * Checks the keys against Stripe (read of one payment): used by the "Test connection" button.
	 *
	 * @return array{ok:bool, message:string}
	 */
	public static function test_connection(): array {
		if ( ! self::is_configured() ) {
			return [ 'ok' => false, 'message' => 'live' === self::selected_mode()
				? __( 'Mancano la chiave pubblica o la chiave segreta REALI (live), oppure non sono di quel tipo.', 'tw-formulari' )
				: __( 'Mancano la chiave pubblica o la chiave segreta di PROVA (test), oppure non sono di quel tipo.', 'tw-formulari' ) ];
		}
		$res = self::request( 'GET', 'payment_intents', [ 'limit' => 1 ] );
		if ( ! $res['ok'] ) {
			return [ 'ok' => false, 'message' => sprintf(
				/* translators: %s: error message from Stripe */
				__( 'Stripe ha risposto con un errore: %s', 'tw-formulari' ),
				$res['error']
			) ];
		}
		return [ 'ok' => true, 'message' => 'live' === self::mode()
			? __( 'Collegamento riuscito (chiavi REALI: i pagamenti addebitano davvero).', 'tw-formulari' )
			: __( 'Collegamento riuscito (chiavi di PROVA: nessun addebito reale).', 'tw-formulari' ) ];
	}

	/**
	 * @return array{status:int, body:array<string, mixed>}
	 */
	private static function fail( int $status, string $message ): array {
		return [ 'status' => $status, 'body' => [ 'ok' => false, 'message' => $message ] ];
	}
}
