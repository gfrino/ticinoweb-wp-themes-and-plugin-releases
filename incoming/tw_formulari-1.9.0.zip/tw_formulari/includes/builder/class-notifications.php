<?php
/**
 * E-mail notifications of a form: who receives what, with which attachments.
 *
 * Merge tags available in subject and body: {field_id} (the readable answer), {all_fields} (a table of all
 * the answers), {form_title}, {site_name}, {entry_id}, {date} and {payment_amount}. Unknown tags become empty.
 *
 * Every recipient gets a separate e-mail, so addresses are never exposed to each other. HTML follows the
 * rules of e-mail clients: tables, solid colours, no gradients.
 *
 * @package TicinoWeb\TWFormulari\Builder
 */

namespace TicinoWeb\TWFormulari\Builder;

use TicinoWeb\TWFormulari\PdfGenerator;
use TicinoWeb\TWFormulari\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Notifications {

	/**
	 * Sends every notification of the form whose conditions match.
	 *
	 * @param array<string, mixed> $def     Normalised definition.
	 * @param array<string, mixed> $values  Visible values keyed by field id.
	 * @param array<string, mixed> $context entry_id, files (stored descriptors), payment (array) and anything else.
	 * @return array{sent:int, failed:int}
	 */
	public static function send_all( array $def, array $values, array $context ): array {
		$by_id  = Definition::field_map( $def );
		$sent   = 0;
		$failed = 0;

		foreach ( (array) ( $def['notifications'] ?? [] ) as $notification ) {
			if ( empty( $notification['enabled'] ) ) {
				continue;
			}
			if ( ! empty( $notification['conditions'] ) && ! Conditions::field_is_visible( [ 'conditions' => $notification['conditions'] ], $by_id, $values ) ) {
				continue;
			}
			$recipients = self::recipients( $notification, $values );
			if ( ! $recipients ) {
				continue;
			}

			$tags    = self::tags( $def, $values, $context );
			$subject = self::render_template( '' !== (string) $notification['subject'] ? (string) $notification['subject'] : '{form_title}', $tags, false );
			$body    = '' !== (string) $notification['body'] ? (string) $notification['body'] : "{all_fields}";
			$html    = self::build_html( self::render_template( $body, $tags, true ), (string) ( $def['title'] ?? '' ) );

			$attachments = [];
			$temp_pdf    = '';
			if ( ! empty( $notification['attach_files'] ) ) {
				foreach ( (array) ( $context['files'] ?? [] ) as $file ) {
					$path = is_array( $file ) ? Uploads::absolute_path( $file ) : '';
					if ( '' !== $path ) {
						$attachments[] = $path;
					}
				}
			}
			// The PDF is an optional extra: it exists only when the form has it switched on, and only then is the
			// generator (and its large library) loaded at all.
			if ( ! empty( $notification['attach_pdf'] ) && ! empty( $def['settings']['pdf'] ) ) {
				$temp_pdf = self::make_pdf( $def, $values, $context );
				if ( '' !== $temp_pdf ) {
					$attachments[] = $temp_pdf;
				}
			}

			$headers = self::headers( $notification, $values );
			foreach ( $recipients as $recipient ) {
				if ( wp_mail( $recipient, $subject, $html, $headers, $attachments ) ) {
					++$sent;
				} else {
					++$failed;
				}
			}
			if ( '' !== $temp_pdf && is_file( $temp_pdf ) ) {
				@unlink( $temp_pdf );
			}
		}

		return [ 'sent' => $sent, 'failed' => $failed ];
	}

	/**
	 * Valid, unique addresses: the fixed ones plus the answers of the chosen e-mail fields.
	 *
	 * @param array<string, mixed> $notification
	 * @param array<string, mixed> $values
	 * @return string[]
	 */
	public static function recipients( array $notification, array $values ): array {
		$out = [];
		foreach ( (array) ( $notification['to'] ?? [] ) as $address ) {
			$out[] = (string) $address;
		}
		foreach ( (array) ( $notification['to_fields'] ?? [] ) as $field_id ) {
			$value = $values[ (string) $field_id ] ?? '';
			if ( is_scalar( $value ) ) {
				$out[] = (string) $value;
			}
		}
		$clean = [];
		foreach ( $out as $address ) {
			$address = sanitize_email( $address );
			if ( '' !== $address && is_email( $address ) && ! in_array( strtolower( $address ), array_map( 'strtolower', $clean ), true ) ) {
				$clean[] = $address;
			}
		}
		return $clean;
	}

	/**
	 * @param array<string, mixed> $def
	 * @param array<string, mixed> $values
	 * @param array<string, mixed> $context
	 * @return array<string, array{text:string, html:string}> tag => rendering for text and HTML.
	 */
	public static function tags( array $def, array $values, array $context ): array {
		$tags = [];
		$rows = '';
		$text = '';
		foreach ( (array) ( $def['fields'] ?? [] ) as $field ) {
			$id   = (string) ( $field['id'] ?? '' );
			$type = (string) ( $field['type'] ?? '' );
			if ( '' === $id || ! FieldTypes::is_input( $type ) || 'hidden' === $type && ! array_key_exists( $id, $values ) ) {
				continue;
			}
			$display = array_key_exists( $id, $values ) ? FieldTypes::display_value( $field, $values[ $id ] ) : '';
			$tags[ $id ] = [ 'text' => $display, 'html' => nl2br( esc_html( $display ) ) ];
			if ( '' === $display ) {
				continue;
			}
			$label = '' !== (string) $field['label'] ? (string) $field['label'] : $id;
			$rows .= '<tr><td style="padding:8px 12px;border-bottom:1px solid #e5e7eb;color:#6b7280;width:35%;vertical-align:top;font-size:14px">' . esc_html( $label )
				. '</td><td style="padding:8px 12px;border-bottom:1px solid #e5e7eb;color:#111827;font-size:14px">' . nl2br( esc_html( $display ) ) . '</td></tr>';
			$text .= $label . ': ' . $display . "\n";
		}

		$files = [];
		foreach ( (array) ( $context['files'] ?? [] ) as $file ) {
			if ( is_array( $file ) && isset( $file['name'] ) ) {
				$files[] = (string) $file['name'];
			}
		}
		if ( $files ) {
			$rows .= '<tr><td style="padding:8px 12px;color:#6b7280;width:35%;vertical-align:top;font-size:14px">' . esc_html__( 'Allegati', 'tw-formulari' )
				. '</td><td style="padding:8px 12px;color:#111827;font-size:14px">' . esc_html( implode( ', ', $files ) ) . '</td></tr>';
			$text .= __( 'Allegati', 'tw-formulari' ) . ': ' . implode( ', ', $files ) . "\n";
		}

		$payment = (array) ( $context['payment'] ?? [] );
		$amount  = isset( $payment['amount'] ) ? number_format( (float) $payment['amount'], 2, '.', '’' ) . ' ' . strtoupper( (string) ( $payment['currency'] ?? '' ) ) : '';

		$tags['all_fields']     = [ 'text' => $text, 'html' => '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="border-collapse:collapse;border:1px solid #e5e7eb">' . $rows . '</table>' ];
		$tags['form_title']     = [ 'text' => (string) ( $def['title'] ?? '' ), 'html' => esc_html( (string) ( $def['title'] ?? '' ) ) ];
		$tags['site_name']      = [ 'text' => (string) get_bloginfo( 'name' ), 'html' => esc_html( (string) get_bloginfo( 'name' ) ) ];
		$tags['entry_id']       = [ 'text' => (string) ( $context['entry_id'] ?? '' ), 'html' => esc_html( (string) ( $context['entry_id'] ?? '' ) ) ];
		$tags['date']           = [ 'text' => (string) current_time( 'd/m/Y H:i' ), 'html' => esc_html( (string) current_time( 'd/m/Y H:i' ) ) ];
		$tags['payment_amount'] = [ 'text' => $amount, 'html' => esc_html( $amount ) ];

		return $tags;
	}

	/**
	 * Replaces {tags}. In HTML mode the template text is escaped first and line breaks become <br>.
	 *
	 * @param array<string, array{text:string, html:string}> $tags
	 */
	public static function render_template( string $template, array $tags, bool $html ): string {
		if ( ! $html ) {
			$out = preg_replace_callback(
				'/\{([a-z0-9_]{1,40})\}/',
				static function ( array $m ) use ( $tags ): string {
					return isset( $tags[ $m[1] ] ) ? str_replace( [ "\r", "\n" ], ' ', rtrim( $tags[ $m[1] ]['text'] ) ) : '';
				},
				$template
			);
			return trim( (string) $out );
		}

		// Escape the template, then put the already-safe HTML renderings where the tags are.
		$escaped = nl2br( esc_html( $template ) );
		$out     = preg_replace_callback(
			'/\{([a-z0-9_]{1,40})\}/',
			static function ( array $m ) use ( $tags ): string {
				return isset( $tags[ $m[1] ] ) ? $tags[ $m[1] ]['html'] : '';
			},
			$escaped
		);
		return (string) $out;
	}

	/**
	 * Wraps the body in a simple, client-safe layout.
	 */
	public static function build_html( string $body_html, string $title ): string {
		return '<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>'
			. '<body style="margin:0;padding:0;background:#f3f4f6">'
			. '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#f3f4f6"><tr><td align="center" style="padding:24px 12px">'
			. '<table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width:600px;width:100%;background:#ffffff;border-radius:8px">'
			. ( '' !== $title ? '<tr><td style="padding:20px 24px 4px;font-family:Arial,Helvetica,sans-serif;font-size:18px;font-weight:bold;color:#111827">' . esc_html( $title ) . '</td></tr>' : '' )
			. '<tr><td style="padding:16px 24px 24px;font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:1.5;color:#111827">' . $body_html . '</td></tr>'
			. '</table></td></tr></table></body></html>';
	}

	/**
	 * @param array<string, mixed> $notification
	 * @param array<string, mixed> $values
	 * @return string[]
	 */
	private static function headers( array $notification, array $values ): array {
		$email_settings = Settings::get_email_settings();
		$sender_name    = ! empty( $email_settings['sender_name'] ) ? (string) $email_settings['sender_name'] : (string) get_bloginfo( 'name' );
		$sender_email   = ! empty( $email_settings['sender_email'] ) && is_email( (string) $email_settings['sender_email'] ) ? (string) $email_settings['sender_email'] : (string) get_option( 'admin_email' );

		$headers = [
			'Content-Type: text/html; charset=UTF-8',
			sprintf( 'From: %s <%s>', str_replace( [ '"', "\r", "\n", '<', '>' ], '', $sender_name ), sanitize_email( $sender_email ) ),
		];
		$reply = (string) ( $notification['reply_to_field'] ?? '' );
		if ( '' !== $reply && isset( $values[ $reply ] ) && is_scalar( $values[ $reply ] ) && is_email( (string) $values[ $reply ] ) ) {
			$headers[] = 'Reply-To: ' . sanitize_email( (string) $values[ $reply ] );
		}
		return $headers;
	}

	/**
	 * Builds the PDF with the plugin's own generator. Returns '' when it cannot be built (the e-mail goes out anyway).
	 *
	 * @param array<string, mixed> $def
	 * @param array<string, mixed> $values
	 * @param array<string, mixed> $context
	 */
	private static function make_pdf( array $def, array $values, array $context ): string {
		if ( ! class_exists( PdfGenerator::class ) ) {
			return '';
		}
		try {
			$sections = [];
			$all      = [];
			foreach ( Definition::steps( $def ) as $step ) {
				$rows = [];
				foreach ( $step['fields'] as $field ) {
					$id = (string) $field['id'];
					if ( ! FieldTypes::is_input( (string) $field['type'] ) || ! array_key_exists( $id, $values ) ) {
						continue;
					}
					$text = FieldTypes::display_value( $field, $values[ $id ] );
					if ( '' === $text ) {
						continue;
					}
					$rows[] = [ 'key' => $id, 'label' => '' !== (string) $field['label'] ? (string) $field['label'] : $id, 'value' => $text ];
				}
				if ( $rows ) {
					$sections[] = [ 'title' => '' !== $step['title'] ? $step['title'] : (string) ( $def['title'] ?? '' ), 'fields' => $rows ];
					$all        = array_merge( $all, $rows );
				}
			}
			$data = [
				'_mode'            => 'generic_dynamic',
				'submission_date'  => current_time( 'd/m/Y H:i' ),
				'client_name'      => '',
				'client_email'     => '',
				'recipient_emails' => [],
				'client_phone'     => '',
				'fields'           => $all,
				'sections'         => $sections,
			];
			return PdfGenerator::generate_file( $data );
		} catch ( \Throwable $e ) {
			return '';
		}
	}
}
