<?php
/**
 * PDF «Buono regalo» (A5 orizzontale, da stampare o mostrare dal telefono).
 *
 * Variabili:
 * - $voucher: title, amount, number, date, from, message, note, accent, site_name.
 * - $logo_src: logo incorporato (data URI) oppure ''.
 *
 * Solo tabelle, colori pieni e font inclusi in mPDF (DejaVu): niente CSS che mPDF non capisce.
 *
 * @package TicinoWeb\TWFormulari
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$accent  = (string) ( $voucher['accent'] ?? '#2a2826' );
$title   = (string) ( $voucher['title'] ?? '' );
$amount  = (string) ( $voucher['amount'] ?? '' );
$number  = (string) ( $voucher['number'] ?? '' );
$date    = (string) ( $voucher['date'] ?? '' );
$from    = (string) ( $voucher['from'] ?? '' );
$message = (string) ( $voucher['message'] ?? '' );
$note    = (string) ( $voucher['note'] ?? '' );
$site    = (string) ( $voucher['site_name'] ?? '' );
?>
<html>
<head>
<style>
	@page { margin: 7mm; background-color: #f7f3ec; }
	body { font-family: dejavusans; color: #2a2826; }
	.frame { border: 0.6mm solid <?php echo esc_html( $accent ); ?>; padding: 1.4mm; }
	.inner { border: 0.2mm solid <?php echo esc_html( $accent ); ?>; background-color: #ffffff; height: 126mm; }
	.logo { text-align: center; padding-top: 15mm; }
	.title { text-align: center; font-family: dejavuserif; font-size: 13pt; letter-spacing: 0.7mm; text-transform: uppercase; color: <?php echo esc_html( $accent ); ?>; padding-top: 3mm; }
	.amount { text-align: center; font-family: dejavuserif; font-size: 34pt; font-weight: bold; color: #2a2826; padding-top: 2mm; }
	.rule { text-align: center; padding-top: 1mm; }
	.message { text-align: center; font-family: dejavuserif; font-style: italic; font-size: 11pt; color: #4a4643; padding: 3mm 18mm 0 18mm; line-height: 1.45; }
	.from { text-align: center; font-size: 8.5pt; color: #6f6b67; padding-top: 2mm; }
	.meta td { font-size: 7.5pt; color: #6f6b67; text-transform: uppercase; letter-spacing: 0.4mm; padding: 0 4mm; }
	.meta .value { font-size: 10pt; color: #2a2826; text-transform: none; letter-spacing: 0; font-weight: bold; padding-top: 0.8mm; }
	.note { text-align: center; font-size: 7.5pt; color: #6f6b67; padding: 5mm 14mm 0 14mm; line-height: 1.4; }
</style>
</head>
<body>
<div class="frame"><div class="inner">
	<?php if ( '' !== $logo_src ) : ?>
		<div class="logo"><img src="<?php echo esc_attr( $logo_src ); ?>" style="height: 25mm;" alt="<?php echo esc_attr( $site ); ?>"></div>
	<?php else : ?>
		<div class="logo" style="font-family: dejavuserif; font-size: 18pt;"><?php echo esc_html( $site ); ?></div>
	<?php endif; ?>

	<div class="title"><?php echo esc_html( $title ); ?></div>

	<?php if ( '' !== $amount ) : ?>
		<div class="amount"><?php echo esc_html( $amount ); ?></div>
	<?php endif; ?>

	<div class="rule">
		<table align="center" cellspacing="0" cellpadding="0"><tr><td style="width: 28mm; border-bottom: 0.3mm solid <?php echo esc_html( $accent ); ?>; font-size: 1pt;">&nbsp;</td></tr></table>
	</div>

	<?php if ( '' !== $message ) : ?>
		<div class="message">«<?php echo nl2br( esc_html( $message ) ); ?>»</div>
	<?php endif; ?>
	<?php if ( '' !== $from ) : ?>
		<div class="from"><?php echo esc_html( sprintf( /* translators: %s: name of who gives the voucher */ __( 'Con i migliori auguri da %s', 'tw-formulari' ), $from ) ); ?></div>
	<?php endif; ?>

	<table class="meta" align="center" cellspacing="0" cellpadding="0" style="margin-top: 6mm;">
		<tr>
			<td align="center"><?php esc_html_e( 'Buono n.', 'tw-formulari' ); ?></td>
			<td align="center" style="border-left: 0.2mm solid #d9d2c5;"><?php esc_html_e( 'Emesso il', 'tw-formulari' ); ?></td>
		</tr>
		<tr>
			<td align="center" class="value"><?php echo esc_html( $number ); ?></td>
			<td align="center" class="value" style="border-left: 0.2mm solid #d9d2c5;"><?php echo esc_html( $date ); ?></td>
		</tr>
	</table>

	<?php if ( '' !== $note ) : ?>
		<div class="note"><?php echo nl2br( esc_html( $note ) ); ?></div>
	<?php else : ?>
		<div class="note">&nbsp;</div>
	<?php endif; ?>
</div></div>
</body>
</html>
