<?php
/**
 * Ticino Top - Voto medio e numero di recensioni delle aziende da Google.
 *
 * Usa la chiave Google Places gia configurata nel parent (ticinoWEB CMS > Google Reviews,
 * opzione ticinoweb_google_api_key) e la stessa API Places del parent (place/details):
 * nessuna seconda chiave o impostazione nel child.
 *
 * - Lo scanner cerca l'azienda (Text Search) e verifica la corrispondenza con il dominio del sito.
 * - Il voto (_tt_voto) e il numero di recensioni (_tt_recensioni) vengono da Google, con
 *   place ID, link alla scheda Google e data di aggiornamento.
 * - Un cron giornaliero riaggiorna le aziende collegate a Google piu vecchie di 7 giorni.
 */

if (!defined('ABSPATH')) {
    exit;
}

define('TT_GOOGLE_REFRESH_AGE', 7 * DAY_IN_SECONDS);
define('TT_GOOGLE_REFRESH_BATCH', 25);

function tt_google_api_key() {
    return (string) get_option('ticinoweb_google_api_key', '');
}

function tt_google_language() {
    return function_exists('ticinoweb_google_places_language') ? ticinoweb_google_places_language() : 'it';
}

/**
 * Chiamata alla Places API (stessa API del parent). Ritorna l'array JSON oppure WP_Error.
 */
function tt_google_places_request($endpoint, $params) {
    $key = tt_google_api_key();
    if (!$key) {
        return new WP_Error('tt_google_no_key', 'Chiave Google non configurata (ticinoWEB CMS > Google Reviews).');
    }

    $params['key'] = $key;
    $params['language'] = tt_google_language();
    $url = 'https://maps.googleapis.com/maps/api/place/' . $endpoint . '/json?' . http_build_query($params, '', '&');

    $response = wp_remote_get($url, array('timeout' => 15));
    if (is_wp_error($response)) {
        return $response;
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);
    if (!is_array($data) || !isset($data['status'])) {
        return new WP_Error('tt_google_api', 'Risposta Google non valida.');
    }
    if ($data['status'] === 'ZERO_RESULTS') {
        return array('status' => 'ZERO_RESULTS', 'results' => array());
    }
    if ($data['status'] !== 'OK') {
        $msg = isset($data['error_message']) ? $data['error_message'] : $data['status'];
        return new WP_Error('tt_google_api', 'Google Places: ' . $msg);
    }
    return $data;
}

function tt_google_place_details($place_id) {
    $data = tt_google_places_request('details', array(
        'place_id' => $place_id,
        'fields'   => 'place_id,name,formatted_address,website,url,rating,user_ratings_total,business_status',
    ));
    if (is_wp_error($data)) {
        return $data;
    }
    return isset($data['result']) ? $data['result'] : new WP_Error('tt_google_api', 'Scheda Google non trovata.');
}

/**
 * Cerca l'azienda su Google. Ritorna:
 * array('status' => ok|none|no_key|error, 'message' => string, 'candidates' => array(...))
 * Ogni candidato: place_id, name, address, website, maps_url, rating, count, match (dominio uguale).
 * I candidati con il sito corrispondente vengono per primi.
 */
function tt_google_find_place($name, $localita, $website) {
    if (!tt_google_api_key()) {
        return array('status' => 'no_key', 'message' => 'Chiave Google non configurata in ticinoWEB CMS > Google Reviews: voto e recensioni non possono essere letti da Google.', 'candidates' => array());
    }

    $host = function_exists('tt_company_normalize_host') ? tt_company_normalize_host($website) : '';
    $queries = array_unique(array_filter(array(
        trim($name . ' ' . $localita),
        trim($name),
        $host,
    )));

    $place_ids = array();
    $error = '';
    foreach ($queries as $query) {
        $data = tt_google_places_request('textsearch', array('query' => $query, 'region' => 'ch'));
        if (is_wp_error($data)) {
            $error = $data->get_error_message();
            break;
        }
        foreach (array_slice($data['results'], 0, 3) as $r) {
            if (!empty($r['place_id'])) {
                $place_ids[$r['place_id']] = true;
            }
        }
        // Ogni ricerca Google ha un costo: le query successive servono solo se questa non trova nulla
        if ($place_ids) {
            break;
        }
    }

    if (!$place_ids) {
        return $error
            ? array('status' => 'error', 'message' => $error, 'candidates' => array())
            : array('status' => 'none', 'message' => 'Nessuna scheda Google trovata per questa azienda.', 'candidates' => array());
    }

    $candidates = array();
    foreach (array_slice(array_keys($place_ids), 0, 4) as $place_id) {
        $d = tt_google_place_details($place_id);
        if (is_wp_error($d)) {
            continue;
        }
        $site = isset($d['website']) ? $d['website'] : '';
        $candidates[] = array(
            'place_id' => $d['place_id'],
            'name'     => isset($d['name']) ? $d['name'] : '',
            'address'  => isset($d['formatted_address']) ? $d['formatted_address'] : '',
            'website'  => $site,
            'maps_url' => isset($d['url']) ? $d['url'] : '',
            'rating'   => isset($d['rating']) ? (float) $d['rating'] : null,
            'count'    => isset($d['user_ratings_total']) ? (int) $d['user_ratings_total'] : 0,
            'match'    => $host && $site && function_exists('tt_company_normalize_host') && tt_company_normalize_host($site) === $host,
        );
    }

    usort($candidates, function ($a, $b) {
        return (int) $b['match'] - (int) $a['match'];
    });

    return array('status' => 'ok', 'message' => '', 'candidates' => $candidates);
}

/**
 * Salva sull'azienda i dati Google di un candidato o di una scheda appena letta.
 */
function tt_google_apply_to_azienda($post_id, $place) {
    update_post_meta($post_id, '_tt_google_place_id', $place['place_id']);
    update_post_meta($post_id, '_tt_google_maps_url', esc_url_raw($place['maps_url']));
    update_post_meta($post_id, '_tt_google_synced', time());

    if ($place['rating'] !== null && $place['count'] > 0) {
        update_post_meta($post_id, '_tt_voto', number_format((float) $place['rating'], 1, '.', ''));
        update_post_meta($post_id, '_tt_recensioni', number_format_i18n((int) $place['count']));
    } else {
        // Scheda Google senza recensioni: niente voto
        update_post_meta($post_id, '_tt_voto', '');
        update_post_meta($post_id, '_tt_recensioni', '');
    }
}

/**
 * Rilegge da Google voto e recensioni di un'azienda gia collegata (place ID salvato).
 */
function tt_google_refresh_azienda($post_id) {
    $place_id = get_post_meta($post_id, '_tt_google_place_id', true);
    if (!$place_id) {
        return new WP_Error('tt_google_no_place', 'Azienda non collegata a Google.');
    }
    $d = tt_google_place_details($place_id);
    if (is_wp_error($d)) {
        return $d;
    }
    tt_google_apply_to_azienda($post_id, array(
        'place_id' => $place_id,
        'maps_url' => isset($d['url']) ? $d['url'] : '',
        'rating'   => isset($d['rating']) ? (float) $d['rating'] : null,
        'count'    => isset($d['user_ratings_total']) ? (int) $d['user_ratings_total'] : 0,
    ));
    return true;
}

// Aggiornamento periodico: ogni giorno al massimo TT_GOOGLE_REFRESH_BATCH aziende piu vecchie di 7 giorni
add_action('init', function () {
    if (!wp_next_scheduled('tt_google_refresh_ratings')) {
        wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', 'tt_google_refresh_ratings');
    }
});

add_action('tt_google_refresh_ratings', 'tt_google_refresh_ratings_run');
function tt_google_refresh_ratings_run() {
    if (!tt_google_api_key()) {
        return;
    }
    $ids = get_posts(array(
        'post_type'      => 'azienda',
        'post_status'    => array('publish', 'draft', 'private'),
        'posts_per_page' => TT_GOOGLE_REFRESH_BATCH,
        'fields'         => 'ids',
        'no_found_rows'  => true,
        'meta_query'     => array(
            'relation' => 'AND',
            array('key' => '_tt_google_place_id', 'compare' => 'EXISTS'),
            array('key' => '_tt_google_place_id', 'value' => '', 'compare' => '!='),
            array(
                'relation' => 'OR',
                array('key' => '_tt_google_synced', 'compare' => 'NOT EXISTS'),
                array('key' => '_tt_google_synced', 'value' => time() - TT_GOOGLE_REFRESH_AGE, 'compare' => '<', 'type' => 'NUMERIC'),
            ),
        ),
        'orderby'        => 'ID',
        'order'          => 'ASC',
    ));
    foreach ($ids as $id) {
        tt_google_refresh_azienda($id);
    }
}

/**
 * Riga "Fonte: Google" da mostrare accanto al voto (attribuzione richiesta da Google).
 */
function tt_google_source_html($post_id) {
    $maps = get_post_meta($post_id, '_tt_google_maps_url', true);
    if (!get_post_meta($post_id, '_tt_google_place_id', true)) {
        return '';
    }
    $synced = intval(get_post_meta($post_id, '_tt_google_synced', true));
    $label = 'Fonte: recensioni Google' . ($synced ? ', aggiornate al ' . wp_date('d.m.Y', $synced) : '');
    return $maps
        ? '<a href="' . esc_url($maps) . '" target="_blank" rel="noopener nofollow" style="color: inherit; text-decoration: underline;">' . esc_html($label) . '</a>'
        : esc_html($label);
}
