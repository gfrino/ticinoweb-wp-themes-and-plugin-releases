<?php
/**
 * Home di Chez Halima: hero (immagine in evidenza, titolo ed estratto della pagina), contenuto, ultime news.
 */
defined('ABSPATH') || exit;

get_header();
the_post();

$buy = get_page_by_path('dove-comprare');
?>
<main id="ch-main" class="ch-home">
    <section class="ch-hero">
        <?php if (has_post_thumbnail()) : ?>
            <?php the_post_thumbnail('full', array('class' => 'ch-hero-image', 'fetchpriority' => 'high', 'alt' => '')); ?>
        <?php endif; ?>
        <div class="ch-hero-text">
            <h1><?php the_title(); ?></h1>
            <?php if (has_excerpt()) : ?><p><?php echo esc_html(get_the_excerpt()); ?></p><?php endif; ?>
            <?php if ($buy) : ?>
                <a class="ch-btn" href="<?php echo esc_url(get_permalink($buy)); ?>"><?php echo esc_html(get_the_title($buy)); ?></a>
            <?php endif; ?>
        </div>
    </section>

    <div class="ch-content"><?php the_content(); ?></div>

    <?php
    $news = new WP_Query(array('posts_per_page' => 3, 'ignore_sticky_posts' => true, 'no_found_rows' => true));
    if ($news->have_posts()) :
        ?>
        <section class="ch-section ch-news">
            <h2 class="ch-title"><?php esc_html_e('Ultime news', 'chez-halima-child-theme'); ?></h2>
            <div class="ch-news-grid">
                <?php while ($news->have_posts()) : $news->the_post(); ?>
                    <?php get_template_part('template-parts/news-card'); ?>
                <?php endwhile; ?>
            </div>
        </section>
        <?php
    endif;
    wp_reset_postdata();
    ?>
</main>
<?php
get_footer();
