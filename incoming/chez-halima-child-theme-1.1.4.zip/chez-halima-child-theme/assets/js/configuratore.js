jQuery(function ($) {
    var selectedProduct = null, selectedSize = null, prices = {}, quantity = 1;
    var cfg = window.chezHalima || {};
    var msg = cfg.messages || {};

    function updateTotal() {
        if (selectedSize && prices[selectedSize]) {
            $('#total-price').text(prices[selectedSize] * quantity);
        }
    }

    function showMessage(text, type) {
        var $m = $('#cart-message');
        $m.removeClass('success error').addClass(type).text(text).prop('hidden', false);
        setTimeout(function () { $m.prop('hidden', true); }, 5000);
    }

    $('.product-card').on('click', function () {
        $('.product-card').removeClass('active');
        $(this).addClass('active');
        selectedProduct = $(this).data('product');
        prices = $(this).data('prices') || {};
        $('.size-card').each(function () {
            $(this).find('.price-value').text(prices[$(this).data('size')]);
        });
        $('#selected-product-name').text($(this).find('.product-name').text());
        $('.size-card').removeClass('active');
        selectedSize = null;
        $('#quantity-section').prop('hidden', true);
        $('#size-selection').prop('hidden', false);
    });

    $('.size-card').on('click', function () {
        if (!selectedProduct) { return; }
        $('.size-card').removeClass('active');
        $(this).addClass('active');
        selectedSize = $(this).data('size');
        $('#selected-size-name').text($(this).find('.size-name').text());
        updateTotal();
        $('#quantity-section').prop('hidden', false);
    });

    $('.qty-plus').on('click', function () {
        if (quantity < 99) { quantity++; $('#product-quantity').val(quantity); updateTotal(); }
    });
    $('.qty-minus').on('click', function () {
        if (quantity > 1) { quantity--; $('#product-quantity').val(quantity); updateTotal(); }
    });

    $('#add-to-cart-btn').on('click', function () {
        if (!selectedProduct || !selectedSize) { showMessage(msg.pick, 'error'); return; }
        var $btn = $(this).prop('disabled', true).addClass('loading');
        $.post(cfg.ajaxUrl, { action: 'chezhalima_add_to_cart', product: selectedProduct, size: selectedSize, quantity: quantity })
            .done(function (response) {
                if (response && response.success) {
                    showMessage(msg.added, 'success');
                    $(document.body).trigger('wc_fragment_refresh');
                    setTimeout(function () { window.location.href = cfg.cartUrl; }, 1000);
                } else {
                    showMessage((response && response.data) || msg.error, 'error');
                }
            })
            .fail(function () { showMessage(msg.network, 'error'); })
            .always(function () { $btn.prop('disabled', false).removeClass('loading'); });
    });

    $('#reset-configurator').on('click', function () {
        $('.product-card, .size-card').removeClass('active');
        selectedProduct = null; selectedSize = null; quantity = 1;
        $('#product-quantity').val(1);
        $('#size-selection, #quantity-section, #cart-message').prop('hidden', true);
        $('html, body').animate({ scrollTop: $('.configurator-wrapper').offset().top - 100 }, 500);
    });
});
