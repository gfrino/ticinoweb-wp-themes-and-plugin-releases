jQuery(function ($) {
    var frame, t = window.chezHalimaHero || {};
    $('#pastry_hero_upload_button').on('click', function (e) {
        e.preventDefault();
        if (!frame) {
            frame = wp.media({ title: t.title, button: { text: t.button }, multiple: false, library: { type: 'image' } });
            frame.on('select', function () {
                var a = frame.state().get('selection').first().toJSON();
                var url = (a.sizes && a.sizes.medium) ? a.sizes.medium.url : a.url;
                $('#pastry_hero_image_id').val(a.id);
                $('#pastry_hero_image_preview').empty().append($('<img>', { src: url, alt: '' }).css({ maxWidth: '100%', height: 'auto' }));
                $('#pastry_hero_upload_button').text(t.change);
                $('#pastry_hero_remove_button').prop('hidden', false);
            });
        }
        frame.open();
    });
    $('#pastry_hero_remove_button').on('click', function (e) {
        e.preventDefault();
        $('#pastry_hero_image_id').val('');
        $('#pastry_hero_image_preview').empty().append($('<p>').append($('<em>').text(t.none)));
        $('#pastry_hero_upload_button').text(t.upload);
        $(this).prop('hidden', true);
    });
});
