<?php
/**
 * Pagina interna: fascia con immagine in evidenza e titolo, poi il contenuto.
 */
defined('ABSPATH') || exit;

get_header();
the_post();
?>
<main id="ch-main" class="ch-page">
    <header class="ch-page-hero">
        <?php if (has_post_thumbnail()) : ?>
            <?php the_post_thumbnail('full', array('class' => 'ch-hero-image', 'fetchpriority' => 'high', 'alt' => '')); ?>
        <?php endif; ?>
        <h1><?php the_title(); ?></h1>
    </header>
    <div class="ch-content"><?php the_content(); ?></div>
</main>
<?php
get_footer();
