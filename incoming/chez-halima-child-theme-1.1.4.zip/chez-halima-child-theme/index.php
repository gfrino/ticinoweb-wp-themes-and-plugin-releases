<?php
/**
 * Elenco delle news e singolo articolo.
 */
defined('ABSPATH') || exit;

get_header();
?>
<main id="ch-main" class="ch-page">
    <?php if (is_singular()) : the_post(); ?>
        <header class="ch-page-hero">
            <?php if (has_post_thumbnail()) : ?>
                <?php the_post_thumbnail('full', array('class' => 'ch-hero-image', 'fetchpriority' => 'high', 'alt' => '')); ?>
            <?php endif; ?>
            <h1><?php the_title(); ?></h1>
        </header>
        <article class="ch-content ch-article">
            <time class="ch-news-date" datetime="<?php echo esc_attr(get_the_date('c')); ?>"><?php echo esc_html(get_the_date()); ?></time>
            <?php the_content(); ?>
            <p><a class="ch-btn ch-btn-outline" href="<?php echo esc_url(get_permalink(get_option('page_for_posts')) ?: home_url('/')); ?>"><?php esc_html_e('Tutte le news', 'chez-halima-child-theme'); ?></a></p>
        </article>
    <?php else : ?>
        <header class="ch-page-hero"><h1><?php echo esc_html(is_home() && get_option('page_for_posts') ? get_the_title(get_option('page_for_posts')) : get_bloginfo('name')); ?></h1></header>
        <div class="ch-content">
            <div class="ch-news-grid">
                <?php while (have_posts()) : the_post(); ?>
                    <?php get_template_part('template-parts/news-card'); ?>
                <?php endwhile; ?>
            </div>
            <?php the_posts_pagination(); ?>
        </div>
    <?php endif; ?>
</main>
<?php
get_footer();
