<?php
defined('ABSPATH') || exit;
?>
<article class="ch-news-card">
    <?php if (has_post_thumbnail()) : ?>
        <a class="ch-news-thumb" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true"><?php the_post_thumbnail('medium_large', array('loading' => 'lazy', 'alt' => '')); ?></a>
    <?php endif; ?>
    <time class="ch-news-date" datetime="<?php echo esc_attr(get_the_date('c')); ?>"><?php echo esc_html(get_the_date()); ?></time>
    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
    <p><?php echo esc_html(wp_trim_words(get_the_excerpt(), 22)); ?></p>
</article>
