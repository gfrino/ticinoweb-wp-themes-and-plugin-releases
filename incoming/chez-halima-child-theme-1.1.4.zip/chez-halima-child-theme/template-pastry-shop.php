<?php
/**
 * Template Name: Pastry Shop Configurator
 * Description: Configuratore di pasticcini con carrello WooCommerce.
 */
defined('ABSPATH') || exit;

get_header();

$catalog  = chezhalima_catalog();
$hero_id  = (int) get_post_meta(get_the_ID(), '_pastry_hero_image', true);
$currency = function_exists('get_woocommerce_currency_symbol') ? get_woocommerce_currency_symbol() : '€';
?>

<main id="pastry-shop-wrapper" class="page-wrapper">

    <section class="pastry-hero">
        <div class="hero-image-container">
            <?php if ($hero_id) : ?>
                <?php echo wp_get_attachment_image($hero_id, 'full', false, array('class' => 'pastry-hero-image', 'fetchpriority' => 'high')); ?>
            <?php endif; ?>
            <div class="hero-overlay">
                <h1 class="hero-title"><?php the_title(); ?></h1>
            </div>
        </div>
    </section>

    <section class="pastry-configurator-section">
        <div class="container">
            <div class="configurator-wrapper">

                <h2 class="section-title"><?php esc_html_e('Configura il tuo ordine', 'chez-halima-child-theme'); ?></h2>

                <div class="configurator-step">
                    <h3 class="step-title">1. <?php esc_html_e('Scegli il prodotto', 'chez-halima-child-theme'); ?></h3>
                    <div class="product-grid">
                        <?php foreach ($catalog['products'] as $slug => $product) : ?>
                            <button type="button" class="product-card" data-product="<?php echo esc_attr($slug); ?>" data-prices="<?php echo esc_attr(wp_json_encode($product['prices'])); ?>">
                                <span class="product-card-inner">
                                    <span class="product-icon">
                                        <?php if (!empty($product['icon'])) : ?>
                                            <img src="<?php echo esc_url(get_stylesheet_directory_uri() . '/assets/product-icons/NUTS-ICONS/' . rawurlencode($product['icon']) . '.svg'); ?>" alt="" width="48" height="48" loading="lazy" class="product-icon-svg">
                                        <?php else : ?>
                                            <?php echo esc_html($product['emoji']); ?>
                                        <?php endif; ?>
                                    </span>
                                    <span class="product-name"><?php echo esc_html($product['name']); ?></span>
                                    <span class="product-desc"><?php echo esc_html($product['desc']); ?></span>
                                </span>
                            </button>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="configurator-step" id="size-selection" hidden>
                    <h3 class="step-title">2. <?php esc_html_e('Scegli la dimensione', 'chez-halima-child-theme'); ?></h3>
                    <div class="size-grid">
                        <?php foreach ($catalog['sizes'] as $slug => $size) : ?>
                            <button type="button" class="size-card" data-size="<?php echo esc_attr($slug); ?>">
                                <span class="size-card-inner">
                                    <span class="size-icon"><?php echo esc_html($size['icon']); ?></span>
                                    <span class="size-name"><?php echo esc_html($size['name']); ?></span>
                                    <span class="size-quantity"><?php echo esc_html($size['quantity']); ?></span>
                                    <span class="size-price"><?php echo esc_html($currency); ?> <span class="price-value">0</span></span>
                                    <?php if (!empty($size['badge'])) : ?>
                                        <span class="luxury-badge"><?php echo esc_html($size['badge']); ?></span>
                                    <?php endif; ?>
                                </span>
                            </button>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="configurator-step" id="quantity-section" hidden>
                    <h3 class="step-title">3. <?php esc_html_e('Quantità e riepilogo', 'chez-halima-child-theme'); ?></h3>
                    <div class="order-summary">
                        <div class="summary-row">
                            <span class="summary-label"><?php esc_html_e('Prodotto:', 'chez-halima-child-theme'); ?></span>
                            <span class="summary-value" id="selected-product-name">-</span>
                        </div>
                        <div class="summary-row">
                            <span class="summary-label"><?php esc_html_e('Dimensione:', 'chez-halima-child-theme'); ?></span>
                            <span class="summary-value" id="selected-size-name">-</span>
                        </div>
                        <div class="summary-row">
                            <label class="summary-label" for="product-quantity"><?php esc_html_e('Quantità:', 'chez-halima-child-theme'); ?></label>
                            <div class="quantity-selector">
                                <button type="button" class="qty-btn qty-minus" aria-label="<?php esc_attr_e('Diminuisci', 'chez-halima-child-theme'); ?>">−</button>
                                <input type="number" id="product-quantity" value="1" min="1" max="99" readonly>
                                <button type="button" class="qty-btn qty-plus" aria-label="<?php esc_attr_e('Aumenta', 'chez-halima-child-theme'); ?>">+</button>
                            </div>
                        </div>
                        <div class="summary-row total-row">
                            <span class="summary-label"><?php esc_html_e('Totale:', 'chez-halima-child-theme'); ?></span>
                            <span class="summary-value total-price"><?php echo esc_html($currency); ?> <span id="total-price">0</span></span>
                        </div>
                    </div>

                    <div class="add-to-cart-wrapper">
                        <button type="button" id="add-to-cart-btn" class="pastry-btn pastry-btn-primary">
                            <span class="button-text"><?php esc_html_e('Aggiungi al carrello', 'chez-halima-child-theme'); ?></span>
                        </button>
                        <button type="button" id="reset-configurator" class="pastry-btn pastry-btn-secondary"><?php esc_html_e('Ricomincia', 'chez-halima-child-theme'); ?></button>
                    </div>

                    <div id="cart-message" class="cart-message" role="status" aria-live="polite" hidden></div>
                </div>

            </div>
        </div>
    </section>

    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <?php if (get_the_content()) : ?>
            <section class="pastry-page-content container"><?php the_content(); ?></section>
        <?php endif; ?>
    <?php endwhile; endif; ?>

</main>

<?php
get_footer();
