<?php
/**
 * Negozio di Chez Halima (WooCommerce): pagina del configuratore, «Acquista Online» nella home,
 * carrello nell'header e lingua dell'ordine con tW Translate Plus.
 * Prodotti e prezzi stanno in chezhalima_catalog() (functions.php); il prezzo lo calcola il server.
 */
defined('ABSPATH') || exit;

/** Pagina del configuratore: la prima pubblicata con il modello «Pastry Shop Configurator». */
function chezhalima_shop_page_id()
{
    static $id = null;
    if ($id === null) {
        $pages = get_posts(array(
            'post_type'        => 'page',
            'post_status'      => 'publish',
            'numberposts'      => 1,
            'meta_key'         => '_wp_page_template',
            'meta_value'       => 'template-pastry-shop.php',
            'fields'           => 'ids',
            'suppress_filters' => false,
        ));
        $id = $pages ? (int) $pages[0] : 0;
    }
    return $id;
}

/** Pulsante «Acquista Online» sotto il testo della foto in home (solo con WooCommerce e la pagina). */
function chezhalima_shop_button()
{
    $page = chezhalima_shop_page_id();
    if (!$page || !class_exists('WooCommerce')) {
        return '';
    }
    return '<a class="ch-btn ch-hero__btn" href="' . esc_url(get_permalink($page)) . '">' . esc_html__('Acquista Online', 'chez-halima-child-theme') . '</a>';
}

/** Carrello nell'header (accanto a email e orari) e nel menu da telefono, con il numero di articoli. */
function chezhalima_cart_link($class = '')
{
    if (!function_exists('wc_get_cart_url') || !function_exists('WC') || !WC()->cart) {
        return '';
    }
    $count = (int) WC()->cart->get_cart_contents_count();
    $label = __('Carrello', 'chez-halima-child-theme');
    return '<a class="ch-cart ' . esc_attr($class) . '" href="' . esc_url(wc_get_cart_url()) . '" data-tip="' . esc_attr(chezhalima_t($label, 'shop:cart')) . '">'
        . chezhalima_icon('cart') . '<span class="ch-cart__label">' . esc_html($label) . '</span>'
        . '<span class="ch-cart__count"' . ($count ? '' : ' hidden') . '>' . $count . '</span></a>';
}

/** Il numero nel carrello si aggiorna quando il configuratore aggiunge una scatola (frammenti di WooCommerce). */
add_filter('woocommerce_add_to_cart_fragments', function ($fragments) {
    $count = function_exists('WC') && WC()->cart ? (int) WC()->cart->get_cart_contents_count() : 0;
    $fragments['.ch-cart__count'] = '<span class="ch-cart__count"' . ($count ? '' : ' hidden') . '>' . $count . '</span>';
    return $fragments;
});

/**
 * La pagina «Negozio» di WooCommerce resterebbe vuota (il prodotto del configuratore è nascosto dal catalogo):
 * chi ci arriva, anche da «Torna al negozio» nel carrello vuoto, va alla pagina del configuratore.
 */
add_action('template_redirect', function () {
    if (function_exists('is_shop') && is_shop() && !is_search() && chezhalima_shop_page_id()) {
        wp_safe_redirect(get_permalink(chezhalima_shop_page_id()), 301);
        exit;
    }
});

add_filter('woocommerce_return_to_shop_redirect', function ($url) {
    return chezhalima_shop_page_id() ? get_permalink(chezhalima_shop_page_id()) : $url;
});

/** Dopo l'ordine la pagina di conferma resta nella lingua di chi ha ordinato. */
add_filter('woocommerce_get_checkout_order_received_url', function ($url) {
    return function_exists('twtr_get_language_url') && function_exists('twtr_get_current_language')
        ? twtr_get_language_url(twtr_get_current_language(), $url)
        : $url;
}, 20);
