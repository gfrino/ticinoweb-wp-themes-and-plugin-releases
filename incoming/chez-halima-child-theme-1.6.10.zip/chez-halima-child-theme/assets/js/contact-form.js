(function () {
    var cfg = window.chezHalimaForm || {};
    document.querySelectorAll('.ch-form').forEach(function (form) {
        var status = form.querySelector('.ch-form-status');
        var button = form.querySelector('button[type="submit"]');

        function say(text, ok) {
            status.textContent = text;
            status.className = 'ch-form-status ' + (ok ? 'is-ok' : 'is-error');
        }

        function recaptcha() {
            if (!cfg.recaptchaKey || !window.grecaptcha) { return Promise.resolve(''); }
            return new Promise(function (resolve) {
                window.grecaptcha.ready(function () {
                    window.grecaptcha.execute(cfg.recaptchaKey, { action: 'contact' }).then(resolve, function () { resolve(''); });
                });
            });
        }

        form.addEventListener('submit', function (e) {
            e.preventDefault();
            button.disabled = true;
            status.textContent = '';
            Promise.all([
                fetch(cfg.ajaxUrl + '?action=' + encodeURIComponent(cfg.tokenAction), { credentials: 'same-origin' }).then(function (r) { return r.json(); }),
                recaptcha()
            ]).then(function (res) {
                var body = new FormData(form);
                body.append('action', cfg.submitAction);
                body.append('token', res[0] && res[0].data ? res[0].data.token : '');
                if (res[1]) { body.append('recaptcha_token', res[1]); }
                return fetch(cfg.ajaxUrl, { method: 'POST', body: body, credentials: 'same-origin' }).then(function (r) { return r.json(); });
            }).then(function (r) {
                // Messaggi della pagina, non quelli del server: la richiesta AJAX non ha la lingua della pagina
                // (tW Translate traduce questi, la risposta del server resterebbe in italiano).
                if (r && r.success) {
                    form.reset();
                    say(form.classList.contains('ch-form--newsletter') ? cfg.okNewsletter : cfg.ok, true);
                } else {
                    say(r && r.data && r.data.fields ? cfg.fields : cfg.error, false);
                }
            }).catch(function () {
                say(cfg.error, false);
            }).then(function () { button.disabled = false; });
        });
    });
})();
