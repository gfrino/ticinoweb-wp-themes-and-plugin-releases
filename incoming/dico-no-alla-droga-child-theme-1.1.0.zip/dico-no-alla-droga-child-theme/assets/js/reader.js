/* Lettore sfogliabile degli opuscoli: pdf.js disegna le pagine, StPageFlip le fa girare. Le librerie si caricano solo all'apertura. */
(function () {
    'use strict';
    var cfg = window.dndReader || {};
    var i18n = cfg.i18n || {};
    var scripts = {};
    var modal, stage, flip, pdf, rendered = {}, ratio = 1.4, current = 0, lastFocus;

    function loadScript(src) {
        if (!scripts[src]) {
            scripts[src] = new Promise(function (resolve, reject) {
                var s = document.createElement('script');
                s.src = src; s.async = true; s.onload = resolve; s.onerror = reject;
                document.head.appendChild(s);
            });
        }
        return scripts[src];
    }

    function el(tag, cls, html) {
        var n = document.createElement(tag);
        if (cls) { n.className = cls; }
        if (html) { n.innerHTML = html; }
        return n;
    }

    function build() {
        if (modal) { return; }
        modal = el('div', 'dnd-reader');
        modal.setAttribute('role', 'dialog');
        modal.setAttribute('aria-modal', 'true');
        modal.setAttribute('aria-label', i18n.dialog || 'Lettore');
        modal.hidden = true;
        modal.innerHTML =
            '<div class="dnd-reader__bar">' +
                '<strong class="dnd-reader__title"></strong>' +
                '<a class="dnd-reader__dl" target="_blank" rel="noopener"></a>' +
                '<button type="button" class="dnd-reader__close" aria-label="' + (i18n.close || 'Chiudi') + '">&times;</button>' +
            '</div>' +
            '<div class="dnd-reader__body">' +
                '<button type="button" class="dnd-reader__nav dnd-reader__nav--prev" aria-label="' + (i18n.prev || 'Pagina precedente') + '">&#8249;</button>' +
                '<div class="dnd-reader__stage"><p class="dnd-reader__msg"></p></div>' +
                '<button type="button" class="dnd-reader__nav dnd-reader__nav--next" aria-label="' + (i18n.next || 'Pagina successiva') + '">&#8250;</button>' +
            '</div>' +
            '<div class="dnd-reader__foot"><span class="dnd-reader__count"></span></div>';
        document.body.appendChild(modal);
        stage = modal.querySelector('.dnd-reader__stage');
        modal.querySelector('.dnd-reader__close').addEventListener('click', close);
        modal.querySelector('.dnd-reader__nav--prev').addEventListener('click', function () { if (flip) { flip.flipPrev(); } });
        modal.querySelector('.dnd-reader__nav--next').addEventListener('click', function () { if (flip) { flip.flipNext(); } });
        modal.addEventListener('click', function (e) { if (e.target === modal) { close(); } });
        document.addEventListener('keydown', function (e) {
            if (modal.hidden) { return; }
            if (e.key === 'Escape') { close(); }
            if (e.key === 'ArrowRight' && flip) { flip.flipNext(); }
            if (e.key === 'ArrowLeft' && flip) { flip.flipPrev(); }
        });
    }

    function message(text) {
        stage.innerHTML = '';
        stage.appendChild(el('p', 'dnd-reader__msg')).textContent = text;
    }

    function open(url, title) {
        build();
        lastFocus = document.activeElement;
        modal.querySelector('.dnd-reader__title').textContent = title || '';
        var dl = modal.querySelector('.dnd-reader__dl');
        dl.href = url; dl.textContent = i18n.download || 'Scarica il PDF';
        modal.querySelector('.dnd-reader__count').textContent = '';
        modal.hidden = false;
        document.documentElement.classList.add('dnd-reader-open');
        modal.querySelector('.dnd-reader__close').focus();
        message(i18n.loading || 'Caricamento…');
        Promise.all([loadScript(cfg.pdfjs), loadScript(cfg.pageflip)])
            .then(function () {
                window.pdfjsLib.GlobalWorkerOptions.workerSrc = cfg.worker;
                return window.pdfjsLib.getDocument({ url: url }).promise;
            })
            .then(start)
            .catch(function () { message(i18n.error || 'Non riesco ad aprire l’opuscolo: scaricalo in PDF.'); });
    }

    function close() {
        if (!modal || modal.hidden) { return; }
        modal.hidden = true;
        document.documentElement.classList.remove('dnd-reader-open');
        if (flip) { try { flip.destroy(); } catch (e) { /* già distrutto */ } flip = null; }
        if (pdf) { try { pdf.destroy(); } catch (e) { /* già distrutto */ } pdf = null; }
        rendered = {};
        stage.innerHTML = '';
        if (lastFocus && lastFocus.focus) { lastFocus.focus(); }
    }

    function renderPage(n) {
        if (!pdf || rendered[n]) { return; }
        rendered[n] = 'busy';
        pdf.getPage(n + 1).then(function (page) {
            var holder = stage.querySelector('[data-page="' + n + '"]');
            if (!holder) { return; }
            var base = page.getViewport({ scale: 1 });
            var target = Math.min(1100, Math.max(600, stage.clientWidth)) * Math.min(window.devicePixelRatio || 1, 2);
            var vp = page.getViewport({ scale: target / base.width / (stage.clientWidth > 700 ? 2 : 1) });
            var canvas = document.createElement('canvas');
            canvas.width = Math.floor(vp.width); canvas.height = Math.floor(vp.height);
            return page.render({ canvasContext: canvas.getContext('2d'), viewport: vp }).promise.then(function () {
                holder.innerHTML = '';
                holder.appendChild(canvas);
                rendered[n] = true;
            });
        }).catch(function () { rendered[n] = false; });
    }

    function around(index) {
        for (var i = Math.max(0, index - 2); i <= Math.min(pdf.numPages - 1, index + 5); i++) { renderPage(i); }
        // Libera la memoria delle pagine lontane.
        Object.keys(rendered).forEach(function (k) {
            if (rendered[k] === true && Math.abs(k - index) > 8) {
                var h = stage.querySelector('[data-page="' + k + '"]');
                if (h) { h.innerHTML = ''; }
                delete rendered[k];
            }
        });
    }

    function start(doc) {
        pdf = doc;
        return doc.getPage(1).then(function (p1) {
            var v = p1.getViewport({ scale: 1 });
            ratio = v.height / v.width;
            stage.innerHTML = '';
            var body = modal.querySelector('.dnd-reader__body');
            var availH = Math.max(280, body.clientHeight - 24), availW = Math.max(260, body.clientWidth - 24);
            var single = availW < 700;
            var w = Math.min(availW, single ? availH / ratio : (availH / ratio) * 2);
            stage.style.width = Math.floor(w) + 'px';
            stage.style.height = Math.floor(single ? w * ratio : (w / 2) * ratio) + 'px';
            var pages = [];
            for (var i = 0; i < doc.numPages; i++) {
                var d = el('div', 'dnd-reader__page');
                d.setAttribute('data-page', i);
                d.appendChild(el('span', 'dnd-reader__wait', ''));
                stage.appendChild(d);
                pages.push(d);
            }
            flip = new window.St.PageFlip(stage, {
                width: 400, height: Math.round(400 * ratio), size: 'stretch',
                minWidth: 220, maxWidth: 1000, minHeight: 280, maxHeight: 1500,
                showCover: true, usePortrait: true, mobileScrollSupport: false, maxShadowOpacity: .35, flippingTime: 700
            });
            flip.loadFromHTML(pages);
            var count = modal.querySelector('.dnd-reader__count');
            function label(idx) {
                var total = doc.numPages;
                var shown = (flip.getOrientation && flip.getOrientation() === 'landscape' && idx > 0 && idx < total - 1) ? (idx + 1) + '–' + Math.min(idx + 2, total) : String(idx + 1);
                count.textContent = (i18n.page || 'Pagina') + ' ' + shown + ' / ' + total;
            }
            flip.on('flip', function (e) { current = e.data; around(current); label(current); });
            around(0); label(0);
        });
    }

    document.addEventListener('click', function (e) {
        var b = e.target.closest ? e.target.closest('[data-dnd-read]') : null;
        if (!b) { return; }
        e.preventDefault();
        open(b.getAttribute('data-dnd-read'), b.getAttribute('data-title'));
    });
})();
