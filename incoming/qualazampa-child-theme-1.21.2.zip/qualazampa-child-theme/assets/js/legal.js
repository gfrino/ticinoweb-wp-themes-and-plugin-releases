(() => {
  'use strict';
  const control = document.querySelector('[data-qz-cookie-review]');
  if (!control) return;
  control.addEventListener('click', () => {
    // Reopen the parent's original consent flow without creating another preference store.
    for (const name of ['tw_cookie_consent', 'tw_cookie_preferences']) {
      document.cookie = `${name}=; Max-Age=0; path=/; SameSite=Lax`;
    }
    window.location.reload();
  });
})();
