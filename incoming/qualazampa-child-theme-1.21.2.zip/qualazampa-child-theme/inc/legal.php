<?php
/** Native legal pages and footer navigation. Policies remain editable WordPress content. */
defined('ABSPATH') || exit;
add_action('after_setup_theme', static function () {
    register_nav_menus(['qz_legal'=>__('Pagine legali nel footer', 'qualazampa')]);
    if (function_exists('tw_seo_cookie_banner_render')) {
        remove_action('wp_footer', 'tw_seo_cookie_banner_render', 100);
        add_action('wp_footer', 'qz_legal_cookie_banner', 100);
    }
}, 120);
add_action('wp_enqueue_scripts', static function () {
    if (is_page_template('page-legal.php')) wp_enqueue_style('qz-legal', get_stylesheet_directory_uri().'/assets/css/legal.css', ['qz-site'], qz_asset_version('assets/css/legal.css'));
    wp_enqueue_script('qz-legal', get_stylesheet_directory_uri().'/assets/js/legal.js', [], qz_asset_version('assets/js/legal.js'), true);
});
function qz_legal_cookie_banner() {
    if (is_admin() || !get_option('tw_cookie_banner_enable')) return;
    ob_start();
    tw_seo_cookie_banner_render();
    $html = ob_get_clean();
    $notice = esc_html__('Utilizziamo cookie necessari per carrello, accesso e preferenze. Puoi scegliere le categorie facoltative; le informative complete sono nel footer.', 'qualazampa');
    $html = preg_replace_callback('/(<p class="tw-cookie-text">).*?(<\/p>)/s', static fn($match)=>$match[1].$notice.$match[2], $html, 1);
    // Optional categories start disabled; native buttons and consent handling are preserved.
    $html = str_replace(['id="tw-cookie-opt-analytics" checked', 'id="tw-cookie-opt-marketing" checked'], ['id="tw-cookie-opt-analytics"', 'id="tw-cookie-opt-marketing"'], $html);
    echo $html; // Native escaped output; the replacement text is escaped above.
}
// The checkout retains its mandatory acceptance checkbox; policy hyperlinks live only in the footer.
add_action('wp', static function () {
    remove_action('woocommerce_checkout_terms_and_conditions', 'wc_terms_and_conditions_page_content', 30);
});

// Both typefaces are local assets; omit the parent's unused Google Fonts preconnections.
add_action('after_setup_theme', static function () {
    add_action('wp_head', static function () { ob_start(); }, -1);
    add_action('wp_head', static function () {
        $html = ob_get_clean();
        echo preg_replace('/<link rel="preconnect" href="https:\/\/fonts\.(?:googleapis|gstatic)\.com"(?: crossorigin)?\s*\/?>\s*/', '', $html);
    }, 0);
}, 120);
