<?php
/** Launch compatibility: redirects use CMS data; optional advertising stays disabled. */
defined('ABSPATH') || exit;
// Keep catalogue integrations available without enabling optional advertising trackers.
add_filter('facebook_for_woocommerce_integration_pixel_enabled', '__return_false', PHP_INT_MAX);
add_filter('woocommerce_gla_disable_gtag_tracking', '__return_true', PHP_INT_MAX);
add_action('template_redirect', static function () {
    if (!in_array($_SERVER['REQUEST_METHOD'] ?? 'GET', ['GET', 'HEAD'], true) || is_admin() || wp_doing_ajax()) return;
    $path = wp_parse_url(wp_unslash($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH);
    if (!is_string($path)) return;
    $redirects = (array) get_option('qz_legacy_redirects', []);
    $target = $redirects[trailingslashit('/'.ltrim($path, '/'))] ?? '';
    if (!is_string($target) || !$target || wp_parse_url($target, PHP_URL_HOST) !== wp_parse_url(home_url('/'), PHP_URL_HOST)) return;
    if (untrailingslashit($target) === untrailingslashit(home_url($path))) return;
    wp_safe_redirect(esc_url_raw($target), 301, 'Qua la Zampa');
    exit;
}, 2);
