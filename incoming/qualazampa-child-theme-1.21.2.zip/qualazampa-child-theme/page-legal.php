<?php
/** Template Name: Pagina legale */
defined('ABSPATH') || exit;
get_header();
?>
<main id="main-content" class="qz-legal qz-container qz-section">
    <?php while (have_posts()): the_post(); ?>
    <article>
        <header class="qz-legal__header">
            <p class="qz-legal__date"><?php printf(esc_html__('Ultimo aggiornamento: %s', 'qualazampa'), esc_html(get_the_modified_date('j F Y'))); ?></p>
            <h1><?php the_title(); ?></h1>
            <?php if (has_excerpt()): ?><div class="qz-legal__intro"><?php the_excerpt(); ?></div><?php endif; ?>
        </header>
        <div class="qz-legal__contact">
            <strong><?php echo esc_html(get_bloginfo('name')); ?></strong>
            <?php if ($address = get_option('ticinoweb_contact_address')): ?><span><?php echo esc_html($address); ?></span><?php endif; ?>
            <?php if ($email = get_option('ticinoweb_contact_email')): ?><a href="mailto:<?php echo esc_attr($email); ?>"><?php echo esc_html($email); ?></a><?php endif; ?>
            <?php if ($phone = get_option('ticinoweb_contact_phone')): ?><a href="tel:<?php echo esc_attr(preg_replace('/[^+0-9]/', '', $phone)); ?>"><?php echo esc_html(get_option('ticinoweb_contact_phone_display') ?: $phone); ?></a><?php endif; ?>
        </div>
        <div class="qz-legal__content qz-prose"><?php the_content(); ?></div>
    </article>
    <?php endwhile; ?>
</main>
<?php get_footer(); ?>
