<?php
/**
 * Data helpers and page routing for the professional area.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return the visitor state used by the professional page.
 *
 * @param WP_User|null $user Optional user object, primarily useful to callers
 *                           that already resolved the current user.
 * @return string One of guest, customer or professional.
 */
function oasi_professional_get_access_state( ?WP_User $user = null ): string {
	if ( ! is_user_logged_in() ) {
		return 'guest';
	}

	$user = $user instanceof WP_User ? $user : wp_get_current_user();

	if ( class_exists( 'WWP_Wholesale_Roles' ) ) {
		$roles_api = WWP_Wholesale_Roles::getInstance();
		$roles     = is_object( $roles_api ) && method_exists( $roles_api, 'getUserWholesaleRole' )
			? (array) $roles_api->getUserWholesaleRole( $user )
			: array();

		if ( ! empty( $roles ) ) {
			return 'professional';
		}
	}

	return in_array( 'wholesale_customer', (array) $user->roles, true ) ? 'professional' : 'customer';
}

/**
 * Return the existing Ultimate Member professional registration URL.
 */
function oasi_professional_get_register_url(): string {
	$url = get_permalink( 33822 );
	return $url ? (string) $url : home_url( '/register/' );
}

/**
 * Return the WooCommerce account URL.
 */
function oasi_professional_get_account_url(): string {
	if ( function_exists( 'wc_get_page_permalink' ) ) {
		$url = wc_get_page_permalink( 'myaccount' );
		if ( $url ) {
			return (string) $url;
		}
	}

	return home_url( '/mio-account/' );
}

/**
 * Return the WooCommerce Shop URL.
 */
function oasi_professional_get_shop_url(): string {
	if ( function_exists( 'wc_get_page_id' ) ) {
		$shop_id = (int) wc_get_page_id( 'shop' );
		if ( $shop_id > 0 ) {
			$url = get_permalink( $shop_id );
			if ( $url ) {
				return (string) $url;
			}
		}
	}

	return home_url( '/shop-online-oasi-delle-spezie/' );
}

/**
 * Return the existing Contact page URL.
 */
function oasi_professional_get_contact_url(): string {
	$page = get_page_by_path( 'contatto' );
	if ( $page instanceof WP_Post && 'publish' === $page->post_status ) {
		$url = get_permalink( $page );
		if ( $url ) {
			return (string) $url;
		}
	}

	return home_url( '/contatto/' );
}

/**
 * Return the existing professional editorial image.
 */
function oasi_professional_get_image_html(): string {
	$content    = function_exists( 'oasi_get_professional_content' ) ? oasi_get_professional_content() : array();
	$image_id   = max( 0, (int) ( $content['image_id'] ?? 33865 ) );
	$image_alt  = trim( (string) ( $content['image_caption'] ?? __( 'Selezione di spezie per il catalogo professionale', 'oasidellespezie-child-theme' ) ) );
	if ( $image_id <= 0 ) {
		return '';
	}
	return (string) wp_get_attachment_image(
		$image_id,
		'large',
		false,
		array(
			'class'   => 'oasi-professional-intro__image',
			'loading' => 'eager',
			'alt'     => $image_alt,
		)
	);
}

/**
 * Use the native child template even when the imported page keeps legacy metadata.
 *
 * @param string $template Resolved WordPress template path.
 */
function oasi_professional_template_include( string $template ): string {
	if ( ! is_page( 'catalogo-professionista' ) ) {
		return $template;
	}

	$professional_template = get_stylesheet_directory() . '/page-catalogo-professionista.php';
	return is_file( $professional_template ) ? $professional_template : $template;
}
add_filter( 'template_include', 'oasi_professional_template_include', 99 );

/** Keep the former standalone conditions URL aligned with the single editable source. */
function oasi_professional_redirect_legacy_conditions(): void {
	if ( is_page( 'condizioni-per-professionisti' ) ) {
		wp_safe_redirect( home_url( '/catalogo-professionista/#condizioni' ), 301 );
		exit;
	}
}
if ( function_exists( 'add_action' ) ) {
	add_action( 'template_redirect', 'oasi_professional_redirect_legacy_conditions', 9 );
}
