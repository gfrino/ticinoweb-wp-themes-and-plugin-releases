<?php
/**
 * Preserve variable products while they still contain active variations.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Determine whether a product still owns at least one non-trashed variation.
 *
 * @param int $product_id Product ID.
 * @return bool
 */
function oasi_product_has_active_variations( int $product_id ): bool {
	$variation_ids = get_posts(
		array(
			'post_type'        => 'product_variation',
			'post_status'      => array( 'publish', 'private', 'draft', 'pending', 'future' ),
			'post_parent'      => $product_id,
			'posts_per_page'   => 1,
			'fields'           => 'ids',
			'no_found_rows'    => true,
			'suppress_filters' => true,
		)
	);

	return ! empty( $variation_ids );
}

/**
 * Restore a product to the variable type when its variations still exist.
 *
 * @param int  $product_id   Product ID.
 * @param bool $notify_user  Whether to show the editor notice.
 * @return bool Whether the type was restored.
 */
function oasi_restore_variable_product_type( int $product_id, bool $notify_user = false ): bool {
	static $restoring = false;

	if ( $restoring || ! $product_id || 'product' !== get_post_type( $product_id ) ) {
		return false;
	}

	$current_types = wp_get_object_terms( $product_id, 'product_type', array( 'fields' => 'slugs' ) );
	if ( is_wp_error( $current_types ) || ! oasi_product_has_active_variations( $product_id ) ) {
		return false;
	}

	$database_is_simple = in_array( 'simple', (array) $current_types, true );
	$cached_product      = wc_get_product( $product_id );
	$cache_is_stale     = in_array( 'variable', (array) $current_types, true ) && $cached_product && 'variable' !== $cached_product->get_type();
	if ( ! $database_is_simple && ! $cache_is_stale ) {
		return false;
	}

	if ( $database_is_simple ) {
		$restoring = true;
		wp_set_object_terms( $product_id, 'variable', 'product_type' );
		$restoring = false;
	}

	wc_delete_product_transients( $product_id );
	WC_Cache_Helper::invalidate_cache_group( 'product_' . $product_id );
	clean_post_cache( $product_id );

	$user_id = get_current_user_id();
	if ( $notify_user && $user_id ) {
		set_transient( 'oasi_product_type_guard_' . $user_id . '_' . $product_id, 1, MINUTE_IN_SECONDS );
	}

	return true;
}

/**
 * Restore the variable type when a background process or accidental save tries
 * to mark a product as simple while live variations still exist.
 *
 * @param int          $object_id  Object ID.
 * @param array|string $terms      Assigned terms.
 * @param array        $tt_ids     Assigned term-taxonomy IDs.
 * @param string       $taxonomy   Taxonomy name.
 * @param bool         $append     Whether terms were appended.
 * @param array        $old_tt_ids Previous term-taxonomy IDs.
 * @return void
 */
function oasi_preserve_variable_product_type( $object_id, $terms, $tt_ids, $taxonomy, $append, $old_tt_ids ): void {
	$product_id = absint( $object_id );
	if ( 'product_type' !== $taxonomy || ! $product_id ) {
		return;
	}

	oasi_restore_variable_product_type( $product_id, true );
}
add_action( 'set_object_terms', 'oasi_preserve_variable_product_type', 20, 6 );

/**
 * Re-check a product after normal WordPress and WooCommerce saves.
 *
 * @param int|WC_Product $product Product ID or product object.
 * @return void
 */
function oasi_guard_product_type_after_save( $product ): void {
	$product_id = is_object( $product ) && is_callable( array( $product, 'get_id' ) ) ? (int) $product->get_id() : absint( $product );
	if ( $product_id ) {
		oasi_restore_variable_product_type( $product_id, true );
	}
}
add_action( 'save_post_product', 'oasi_guard_product_type_after_save', 99, 3 );
add_action( 'woocommerce_after_product_object_save', 'oasi_guard_product_type_after_save', 99, 2 );

/**
 * Find products whose simple type conflicts with their live variations.
 *
 * @return int[]
 */
function oasi_find_products_with_mismatched_type(): array {
	$parents = array();
	$rows    = get_posts(
		array(
			'post_type'        => 'product_variation',
			'post_status'      => array( 'publish', 'private', 'draft', 'pending', 'future' ),
			'posts_per_page'   => -1,
			'no_found_rows'    => true,
			'suppress_filters' => true,
		)
	);

	foreach ( $rows as $row ) {
		$parent_id = isset( $row->post_parent ) ? absint( $row->post_parent ) : 0;
		if ( ! $parent_id || isset( $parents[ $parent_id ] ) ) {
			continue;
		}

		$current_types  = wp_get_object_terms( $parent_id, 'product_type', array( 'fields' => 'slugs' ) );
		$cached_product = wc_get_product( $parent_id );
		if ( ! is_wp_error( $current_types ) && ( in_array( 'simple', (array) $current_types, true ) || ( in_array( 'variable', (array) $current_types, true ) && $cached_product && 'variable' !== $cached_product->get_type() ) ) ) {
			$parents[ $parent_id ] = $parent_id;
		}
	}

	return array_values( $parents );
}

/**
 * Repair product types changed outside the normal WordPress save hooks.
 *
 * @return void
 */
function oasi_run_product_type_integrity_audit(): void {
	foreach ( oasi_find_products_with_mismatched_type() as $product_id ) {
		oasi_restore_variable_product_type( $product_id, false );
	}
}
add_action( 'oasi_product_type_integrity_audit', 'oasi_run_product_type_integrity_audit' );

/**
 * Schedule the lightweight catalogue integrity audit.
 *
 * @return void
 */
function oasi_schedule_product_type_integrity_audit(): void {
	if ( ! wp_next_scheduled( 'oasi_product_type_integrity_audit' ) ) {
		wp_schedule_event( time() + ( 5 * MINUTE_IN_SECONDS ), 'twicedaily', 'oasi_product_type_integrity_audit' );
	}
}
add_action( 'init', 'oasi_schedule_product_type_integrity_audit' );

/**
 * Whether a cart row points to a variable parent without its selected child.
 *
 * @param array $cart_item Cart row.
 * @return bool
 */
function oasi_cart_item_is_missing_variation( array $cart_item ): bool {
	$product_id   = absint( $cart_item['product_id'] ?? 0 );
	$variation_id = absint( $cart_item['variation_id'] ?? 0 );

	return $product_id && ! $variation_id && oasi_product_has_active_variations( $product_id );
}

/**
 * Customer-facing message for a missing product choice.
 *
 * @param int  $product_id Product ID.
 * @param bool $stale_cart Whether the product is already stored in the cart.
 * @return string
 */
function oasi_missing_variation_message( int $product_id, bool $stale_cart = false ): string {
	$product_name = get_the_title( $product_id );
	$product_url  = get_permalink( $product_id );

	if ( $stale_cart ) {
		/* translators: 1: product name, 2: product URL. */
		return sprintf( __( 'Per “%1$s” manca la variazione scelta. Rimuovilo dal carrello e <a href="%2$s">aggiungilo di nuovo</a> selezionando peso e confezione.', 'oasidellespezie-child-theme' ), esc_html( $product_name ), esc_url( $product_url ) );
	}

	/* translators: 1: product name, 2: product URL. */
	return sprintf( __( 'Prima di aggiungere “%1$s” devi <a href="%2$s">selezionare peso e confezione</a>.', 'oasidellespezie-child-theme' ), esc_html( $product_name ), esc_url( $product_url ) );
}

/**
 * Prevent a corrupt variable parent from entering the cart as a simple item.
 *
 * @param bool  $passed_validation Existing validation result.
 * @param int   $product_id       Product ID.
 * @param float $quantity         Quantity.
 * @param int   $variation_id     Variation ID.
 * @param array $variations       Selected attributes.
 * @param array $cart_item_data   Additional cart data.
 * @return bool
 */
function oasi_validate_add_to_cart_variation_integrity( $passed_validation, $product_id, $quantity, $variation_id = 0, $variations = array(), $cart_item_data = array() ): bool {
	unset( $quantity, $variations, $cart_item_data );

	$product_id   = absint( $product_id );
	$variation_id = absint( $variation_id );
	if ( ! $passed_validation || ! $product_id || $variation_id || ! oasi_product_has_active_variations( $product_id ) ) {
		return (bool) $passed_validation;
	}

	wc_add_notice( oasi_missing_variation_message( $product_id ), 'error' );
	return false;
}
add_filter( 'woocommerce_add_to_cart_validation', 'oasi_validate_add_to_cart_variation_integrity', 20, 6 );

/**
 * Block stale sessions that contain a variable parent without a choice.
 *
 * @return void
 */
function oasi_validate_cart_variation_integrity(): void {
	$cart = WC()->cart;
	if ( ! $cart ) {
		return;
	}

	foreach ( $cart->get_cart() as $cart_item ) {
		if ( ! oasi_cart_item_is_missing_variation( $cart_item ) ) {
			continue;
		}

		$message = oasi_missing_variation_message( absint( $cart_item['product_id'] ), true );
		if ( ! function_exists( 'wc_has_notice' ) || ! wc_has_notice( $message, 'error' ) ) {
			wc_add_notice( $message, 'error' );
		}
	}
}
add_action( 'woocommerce_check_cart_items', 'oasi_validate_cart_variation_integrity', 20 );

/**
 * Final fail-closed gate before WooCommerce persists an order line.
 *
 * @param WC_Order_Item_Product $item          New order item.
 * @param string                $cart_item_key Cart item key.
 * @param array                 $values        Cart item data.
 * @param WC_Order              $order         Order object.
 * @throws UnexpectedValueException When the variation selection is missing.
 * @return void
 */
function oasi_require_order_line_variation_integrity( $item, $cart_item_key, $values, $order ): void {
	unset( $item, $cart_item_key, $order );

	if ( oasi_cart_item_is_missing_variation( (array) $values ) ) {
		throw new UnexpectedValueException( wp_strip_all_tags( oasi_missing_variation_message( absint( $values['product_id'] ), false ) ) );
	}
}
add_action( 'woocommerce_checkout_create_order_line_item', 'oasi_require_order_line_variation_integrity', 1, 4 );

/**
 * Explain a prevented conversion to the product editor.
 *
 * @return void
 */
function oasi_product_type_guard_admin_notice(): void {
	$screen = get_current_screen();
	if ( ! $screen || 'product' !== $screen->post_type ) {
		return;
	}

	$product_id = isset( $_GET['post'] ) ? absint( wp_unslash( $_GET['post'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only notice lookup.
	$user_id    = get_current_user_id();
	if ( ! $product_id || ! $user_id ) {
		return;
	}

	$transient_key = 'oasi_product_type_guard_' . $user_id . '_' . $product_id;
	if ( ! get_transient( $transient_key ) ) {
		return;
	}

	delete_transient( $transient_key );
	?>
	<div class="notice notice-warning is-dismissible"><p><?php esc_html_e( 'Il prodotto è rimasto variabile perché contiene ancora delle variazioni. Per convertirlo intenzionalmente in prodotto semplice, elimina prima tutte le variazioni.', 'oasidellespezie-child-theme' ); ?></p></div>
	<?php
}
add_action( 'admin_notices', 'oasi_product_type_guard_admin_notice' );
