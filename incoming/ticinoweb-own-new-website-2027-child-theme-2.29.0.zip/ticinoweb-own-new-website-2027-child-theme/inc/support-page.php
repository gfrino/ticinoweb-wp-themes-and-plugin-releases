<?php
/**
 * Read-only helpers for the Support page.
 *
 * @package ticinoWEB_Child_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Checks whether the current request is the mapped Support page.
 *
 * @return bool
 */
function tw_support_is_page() {
	if ( ! function_exists( 'is_page' ) ) {
		return false;
	}

	$mapping = get_option( 'ticinoweb_page_mapping', array() );
	$page_id = isset( $mapping['page_supporto'] ) ? absint( $mapping['page_supporto'] ) : 0;

	return ( $page_id && is_page( $page_id ) ) || is_page( 'supporto' );
}

/**
 * Keeps the existing specialist recipients stored in the Support page editor.
 *
 * @param string $content        Raw Support page content.
 * @param string $service_key    Service key.
 * @param string $fallback_email CMS contact email.
 * @return string
 */
function tw_support_resolve_service_email( $content, $service_key, $fallback_email ) {
	$aliases = array(
		'odoo'      => array( 'odoo' ),
		'app'       => array( 'app', 'ios', 'android' ),
		'web'       => array( 'web' ),
		'marketing' => array( 'marketing' ),
	);
	$matches = array();
	preg_match_all( '/mailto:([^\s"\'<>?]+)/iu', (string) $content, $matches );

	foreach ( $matches[1] ?? array() as $candidate ) {
		$email = sanitize_email( rawurldecode( html_entity_decode( $candidate, ENT_QUOTES, 'UTF-8' ) ) );
		if ( ! is_email( $email ) ) {
			continue;
		}
		$local_part = strtolower( strstr( $email, '@', true ) ?: $email );
		foreach ( $aliases[ $service_key ] ?? array() as $alias ) {
			if ( str_contains( $local_part, $alias ) ) {
				return $email;
			}
		}
	}

	$fallback_email = sanitize_email( $fallback_email );
	return is_email( $fallback_email ) ? $fallback_email : '';
}

/**
 * Builds an encoded assistance email without inserting personal data.
 *
 * @param string $email   Recipient.
 * @param string $subject Subject line.
 * @param string $service Human-readable service.
 * @return string
 */
function tw_support_build_mailto( $email, $subject, $service ) {
	$email = sanitize_email( $email );
	if ( ! is_email( $email ) ) {
		return '';
	}

	$body = sprintf(
		"Buongiorno ticinoWEB,\n\navrei bisogno di assistenza per: %s.\n\nDescrizione del problema:\n\n\nNome / Azienda:\n\nTelefono:\n",
		wp_strip_all_tags( $service )
	);
	$query = http_build_query(
		array(
			'subject' => wp_strip_all_tags( $subject ),
			'body'    => $body,
		),
		'',
		'&',
		PHP_QUERY_RFC3986
	);

	return 'mailto:' . $email . '?' . $query;
}

/**
 * Extracts the useful explanatory paragraphs already stored in WordPress.
 *
 * @param string $content Raw Support page content.
 * @return string[]
 */
function tw_support_extract_description_paragraphs( $content ) {
	if ( ! class_exists( 'DOMDocument' ) || ! trim( (string) $content ) ) {
		return array();
	}

	$document = new DOMDocument();
	libxml_use_internal_errors( true );
	$document->loadHTML( '<?xml encoding="utf-8" ?><div id="tw-support-source">' . $content . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
	libxml_clear_errors();
	$xpath = new DOMXPath( $document );
	$nodes = $xpath->query( '//*[@id="tw-support-source"]//*[self::h2 or self::p]' );
	$found = false;
	$paragraphs = array();

	foreach ( $nodes as $node ) {
		$text = trim( preg_replace( '/\s+/u', ' ', $node->textContent ) );
		if ( 'h2' === strtolower( $node->nodeName ) ) {
			if ( $found ) {
				break;
			}
			$found = 0 === strcasecmp( $text, 'Supporto' );
			continue;
		}
		if ( ! $found || 'p' !== strtolower( $node->nodeName ) || ! $text ) {
			continue;
		}
		if ( str_contains( strtolower( $text ), 'puoi contare su di noi' ) || $node->getElementsByTagName( 'a' )->length ) {
			continue;
		}
		$paragraphs[] = $text;
		if ( 3 === count( $paragraphs ) ) {
			break;
		}
	}

	return $paragraphs;
}
