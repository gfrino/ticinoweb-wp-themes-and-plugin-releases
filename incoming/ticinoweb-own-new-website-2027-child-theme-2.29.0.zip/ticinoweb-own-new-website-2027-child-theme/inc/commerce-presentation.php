<?php
/** Native WooCommerce presentation, without commerce or persistence overrides. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Include commerce endpoints and service pages embedding native purchase forms. */
function tw_commerce_is_context() {
	if ( ! function_exists( 'is_woocommerce' ) ) { return false; }
	if ( is_woocommerce() || is_cart() || is_checkout() || is_account_page() ) { return true; }
	if ( is_singular( 'page' ) && function_exists( 'tw_service_enabled' ) && tw_service_enabled() ) {
		$data = (array) get_post_meta( get_queried_object_id(), '_tw_service_content', true );
		return 'purchase' === ( $data['mode'] ?? 'info' ) && ! empty( $data['product_id'] );
	}
	return false;
}

/** The existing service renderer remains authoritative for enabled services. */
function tw_commerce_template( $template ) {
	if ( ! tw_commerce_is_context() ) { return $template; }
	if ( function_exists( 'tw_service_enabled' ) && tw_service_enabled() && ( is_singular( 'product' ) || is_singular( 'page' ) ) ) { return $template; }
	return get_stylesheet_directory() . '/woocommerce.php';
}
add_filter( 'template_include', 'tw_commerce_template', 110 );

function tw_commerce_body_class( $classes ) {
	if ( tw_commerce_is_context() ) { $classes[] = 'tw-commerce-context'; }
	return $classes;
}
add_filter( 'body_class', 'tw_commerce_body_class' );

/** Run before do_blocks/wpautop/do_shortcode; leave all native endpoint handling to WC. */
function tw_commerce_checkout_content( $content ) {
	if ( ! function_exists( 'wc_get_page_id' ) || is_admin() || ! is_checkout() || ! is_main_query() || ! in_the_loop() ) { return $content; }
	$page_id = (int) wc_get_page_id( 'checkout' );
	if ( $page_id < 1 || $page_id !== (int) get_queried_object_id() || $page_id !== (int) get_the_ID() ) { return $content; }
	if ( has_shortcode( $content, 'woocommerce_checkout' ) || has_block( 'woocommerce/checkout', $content ) ) { return $content; }
	return '[woocommerce_checkout]';
}
add_filter( 'the_content', 'tw_commerce_checkout_content', 8 );

function tw_commerce_enqueue() {
	if ( ! tw_commerce_is_context() ) { return; }
	wp_enqueue_style( 'tw-commerce-presentation', get_stylesheet_directory_uri() . '/assets/css/commerce.css', array( 'ticinoweb-child-site' ), wp_get_theme()->get( 'Version' ) );
}
add_action( 'wp_enqueue_scripts', 'tw_commerce_enqueue', 40 );
