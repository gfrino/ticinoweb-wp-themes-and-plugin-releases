<?php
/** Native editorial classifications. No title inference, term seeds or archive routes. */
if (!defined('ABSPATH')) exit;

function tw_home_register_project_sectors() {
 if (!post_type_exists('tw_project')) register_post_type('tw_project',[
  'labels'=>['name'=>__('Progetti','ticinoweb-child-theme'),'singular_name'=>__('Progetto','ticinoweb-child-theme')],
  'public'=>true,'show_in_rest'=>true,'has_archive'=>false,'rewrite'=>false,
  'menu_icon'=>'dashicons-portfolio','supports'=>['title','editor','thumbnail','excerpt','revisions'],
 ]);
 foreach(['tw_project_sector'=>__('Settori','ticinoweb-child-theme'),'tw_odoo_sector'=>__('Settori Odoo','ticinoweb-child-theme')] as $tax=>$label) {
  if(taxonomy_exists($tax)){register_taxonomy_for_object_type($tax,'tw_project');register_taxonomy_for_object_type($tax,'post');continue;}
  register_taxonomy($tax,['tw_project','post'],[
   'labels'=>['name'=>$label,'singular_name'=>$label,'menu_name'=>$label],
   'hierarchical'=>true,'public'=>false,'publicly_queryable'=>false,'show_ui'=>true,
   'show_admin_column'=>true,'show_in_rest'=>true,'show_in_nav_menus'=>false,'rewrite'=>false,'query_var'=>false,
   'capabilities'=>['manage_terms'=>'manage_categories','edit_terms'=>'manage_categories','delete_terms'=>'manage_categories','assign_terms'=>'edit_posts'],
  ]);
 }
}
add_action('init','tw_home_register_project_sectors',30);

function tw_home_project_query_args($taxonomy,$term_id,$page=1,$per_page=6) {
 if(!in_array($taxonomy,['category','tw_project_sector','tw_odoo_sector'],true)||!term_exists(absint($term_id),$taxonomy))return [];
 $args=['post_type'=>['tw_project','post'],'post_status'=>'publish','posts_per_page'=>min(6,max(1,absint($per_page))),
  'paged'=>min(10000,max(1,absint($page))),'orderby'=>['date'=>'DESC','ID'=>'DESC'],'ignore_sticky_posts'=>true,
  'tax_query'=>[['taxonomy'=>$taxonomy,'field'=>'term_id','terms'=>[absint($term_id)],'include_children'=>false]],
 ];
 if($taxonomy==='category'){$args['post_type']='post';$args['meta_query']=[['key'=>'tw_home_project_featured','value'=>'1','compare'=>'=']];}
 return $args;
}

function tw_home_sector_terms($taxonomy) {
 $terms=get_terms(['taxonomy'=>$taxonomy,'hide_empty'=>false,'orderby'=>'name','order'=>'ASC']);
 if(is_wp_error($terms))return [];
 return array_map(static fn($t)=>['id'=>(int)$t->term_id,'name'=>$t->name,'slug'=>$t->slug,'count'=>(int)$t->count],$terms);
}

/** Extra context on the existing portfolio endpoint; its archive response is untouched. */
function tw_home_projects_rest_request($request) {
 $tax=sanitize_key($request->get_param('taxonomy'));
 $term=absint($request->get_param('term_id'));
 if(!tw_home_project_query_args($tax,$term))return new WP_Error('tw_invalid_project_filter',__('Filtro non valido.','ticinoweb-child-theme'),['status'=>400]);
 return rest_ensure_response(tw_home_get_projects_for_term($tax,$term,absint($request->get_param('page')),6));
}
