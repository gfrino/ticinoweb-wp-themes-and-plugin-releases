<?php
/**
 * Small, read-only helpers for the tBlog single-article template.
 *
 * @package ticinoWEB_Child_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Calculates a human reading time from the rendered post content.
 *
 * @param string $content          Article content.
 * @param int    $words_per_minute Reading pace.
 * @return int
 */
function tw_single_reading_time( $content, $words_per_minute = 220 ) {
	$content = html_entity_decode( wp_strip_all_tags( strip_shortcodes( (string) $content ) ), ENT_QUOTES, 'UTF-8' );
	$words   = preg_split( '/\s+/u', trim( $content ), -1, PREG_SPLIT_NO_EMPTY );
	$count   = is_array( $words ) ? count( $words ) : 0;
	$pace    = max( 1, (int) $words_per_minute );

	return max( 1, (int) ceil( $count / $pace ) );
}

/**
 * Chooses the most useful editorial category for the article label.
 *
 * Web Design is the broad project category and therefore takes precedence
 * when present; otherwise WordPress' first assigned category is retained.
 *
 * @param int $post_id Post ID.
 * @return WP_Term|null
 */
function tw_single_get_primary_category( $post_id ) {
	$categories = get_the_category( $post_id );
	if ( ! $categories ) {
		return null;
	}

	foreach ( $categories as $category ) {
		if ( 'web-design' === $category->slug ) {
			return $category;
		}
	}

	return $categories[0];
}

/**
 * Gets related article IDs, prioritising shared categories and then recency.
 *
 * Only articles with a featured image are returned so the related grid never
 * needs to invent a placeholder.
 *
 * @param int $post_id Current post ID.
 * @param int $limit   Number of posts requested.
 * @return int[]
 */
function tw_single_get_related_post_ids( $post_id, $limit = 3 ) {
	$post_id    = (int) $post_id;
	$limit      = max( 1, (int) $limit );
	$categories = get_the_category( $post_id );
	$category_ids = $categories ? array_map( 'intval', wp_list_pluck( $categories, 'term_id' ) ) : array();
	$common_args = array(
		'post_type'           => 'post',
		'post_status'         => 'publish',
		'posts_per_page'      => $limit,
		'post__not_in'        => array( $post_id ),
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
		'fields'              => 'ids',
		'meta_query'          => array(
			array(
				'key'     => '_thumbnail_id',
				'compare' => 'EXISTS',
			),
		),
	);
	$related = array();

	if ( $category_ids ) {
		$category_query = new WP_Query(
			wp_parse_args(
				array( 'category__in' => $category_ids ),
				$common_args
			)
		);
		$related = array_map( 'intval', $category_query->posts );
	}

	if ( count( $related ) < $limit ) {
		$recent_query = new WP_Query(
			wp_parse_args(
				array(
					'posts_per_page' => $limit - count( $related ),
					'post__not_in'   => array_merge( array( $post_id ), $related ),
				),
				$common_args
			)
		);
		$related = array_merge( $related, array_map( 'intval', $recent_query->posts ) );
	}

	return array_slice( array_values( array_unique( $related ) ), 0, $limit );
}
