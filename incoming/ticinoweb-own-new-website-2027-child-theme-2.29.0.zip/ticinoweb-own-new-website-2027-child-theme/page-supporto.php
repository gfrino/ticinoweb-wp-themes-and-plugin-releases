<?php
/**
 * Simple Support page.
 *
 * THESIS: one clear path from problem to the right human support channel.
 * OWN-WORLD: warm paper, Ink type, fine rules and restrained blue details.
 * STORY: orient, request remote access, choose a service, understand the care.
 * FIRST VIEWPORT: compact promise followed immediately by the remote-access path.
 * FORM: calm service desk, not a campaign landing page.
 *
 * @package ticinoWEB_Child_Theme
 */

get_header();

while ( have_posts() ) :
	the_post();
	$tw_support_post_id          = get_the_ID();
	$tw_support_raw_content      = (string) get_post_field( 'post_content', $tw_support_post_id );
	$tw_support_rendered_content = (string) apply_filters( 'the_content', $tw_support_raw_content );
	$tw_support_contact          = function_exists( 'ticinoweb_get_contact_info' ) ? ticinoweb_get_contact_info() : array();
	$tw_support_email            = sanitize_email( (string) ( $tw_support_contact['email'] ?? get_option( 'admin_email', '' ) ) );
	$tw_support_phone            = trim( (string) ( $tw_support_contact['phone'] ?? '' ) );
	$tw_support_phone_label      = trim( (string) get_option( 'ticinoweb_contact_phone_display', '' ) ) ?: $tw_support_phone;
	$tw_support_phone_href       = preg_replace( '/[^0-9+]/', '', $tw_support_phone );
	$tw_support_paragraphs       = tw_support_extract_description_paragraphs( $tw_support_rendered_content );
	$tw_support_remote_href      = tw_support_build_mailto( $tw_support_email, __( 'Richiesta accesso remoto', 'ticinoweb-child-theme' ), __( 'Accesso remoto', 'ticinoweb-child-theme' ) );
	$tw_support_contact_href = tw_support_build_mailto( $tw_support_email, __( 'Richiesta assistenza', 'ticinoweb-child-theme' ), __( 'Assistenza generale', 'ticinoweb-child-theme' ) );
	$tw_support_services = array(
		'odoo' => array(
			'number'      => '01',
			'title'       => __( 'Odoo', 'ticinoweb-child-theme' ),
			'description' => __( 'Assistenza sul tuo gestionale Odoo.', 'ticinoweb-child-theme' ),
			'subject'     => __( 'Richiesta assistenza Odoo', 'ticinoweb-child-theme' ),
			'service'     => __( 'Odoo', 'ticinoweb-child-theme' ),
		),
		'app' => array(
			'number'      => '02',
			'title'       => __( 'App iOS / Android', 'ticinoweb-child-theme' ),
			'description' => __( 'Supporto per applicazioni e servizi mobile.', 'ticinoweb-child-theme' ),
			'subject'     => __( 'Richiesta assistenza App iOS/Android', 'ticinoweb-child-theme' ),
			'service'     => __( 'App iOS/Android', 'ticinoweb-child-theme' ),
		),
		'web' => array(
			'number'      => '03',
			'title'       => __( 'Siti Web', 'ticinoweb-child-theme' ),
			'description' => __( 'Problemi, modifiche o assistenza sul tuo sito web.', 'ticinoweb-child-theme' ),
			'subject'     => __( 'Richiesta assistenza Web', 'ticinoweb-child-theme' ),
			'service'     => __( 'Web', 'ticinoweb-child-theme' ),
		),
		'marketing' => array(
			'number'      => '04',
			'title'       => __( 'Marketing', 'ticinoweb-child-theme' ),
			'description' => __( 'Supporto per campagne e servizi di marketing digitale.', 'ticinoweb-child-theme' ),
			'subject'     => __( 'Richiesta assistenza Marketing', 'ticinoweb-child-theme' ),
			'service'     => __( 'Marketing', 'ticinoweb-child-theme' ),
		),
	);
	?>
	<main class="tw-support-page">
		<header class="tw-support-hero">
			<div class="tw-shell tw-support-measure">
				<p class="tw-kicker"><?php esc_html_e( 'Supporto ticinoWEB', 'ticinoweb-child-theme' ); ?></p>
				<h1><?php esc_html_e( 'Come possiamo aiutarti?', 'ticinoweb-child-theme' ); ?></h1>
				<p class="tw-support-lead"><?php esc_html_e( 'Scegli l’area per cui hai bisogno di assistenza oppure richiedi l’accesso remoto con uno dei nostri tecnici.', 'ticinoweb-child-theme' ); ?></p>
			</div>
		</header>

		<section class="tw-support-remote" aria-labelledby="tw-support-remote-title">
			<div class="tw-shell tw-support-remote__inner">
				<div>
					<p class="tw-kicker"><?php esc_html_e( 'Assistenza tecnica', 'ticinoweb-child-theme' ); ?></p>
					<h2 id="tw-support-remote-title"><?php esc_html_e( 'Accesso remoto', 'ticinoweb-child-theme' ); ?></h2>
				</div>
				<div>
					<p><?php esc_html_e( 'Hai già parlato con un nostro tecnico? Utilizza il codice ricevuto per consentire l’accesso remoto al tuo computer.', 'ticinoweb-child-theme' ); ?></p>
					<form class="tw-support-session" action="https://assist.zoho.eu/join" method="get" target="_blank" rel="noopener noreferrer" data-support-session>
						<label for="tw-support-session-id"><?php esc_html_e( 'ID sessione', 'ticinoweb-child-theme' ); ?></label>
						<div class="tw-support-session__controls">
							<input id="tw-support-session-id" name="key" type="text" inputmode="numeric" autocomplete="off" spellcheck="false" required maxlength="15" pattern="[0-9]{3}[ -]?[0-9]{3}[ -]?[0-9]{3}" aria-describedby="tw-support-session-help" data-invalid-message="<?php esc_attr_e( 'Inserisci le 9 cifre del codice ricevuto dal tecnico.', 'ticinoweb-child-theme' ); ?>">
							<button class="tw-button tw-button--primary" type="submit"><?php esc_html_e( 'Collega', 'ticinoweb-child-theme' ); ?><span aria-hidden="true">↗</span></button>
						</div>
						<input type="hidden" name="join_source" value="CUSTOMER_WIDGET">
						<p id="tw-support-session-help" class="tw-support-session__help"><?php esc_html_e( 'Inserisci il codice di 9 cifre ricevuto dal tecnico. Il collegamento si apre in una nuova scheda su Zoho Assist.', 'ticinoweb-child-theme' ); ?></p>
						<p class="tw-support-session__provider"><?php esc_html_e( 'Con il supporto di Zoho Assist', 'ticinoweb-child-theme' ); ?></p>
					</form>
					<?php if ( $tw_support_remote_href ) : ?>
						<a class="tw-text-link" href="<?php echo esc_url( $tw_support_remote_href ); ?>"><?php esc_html_e( 'Non hai il codice? Richiedilo al nostro tecnico', 'ticinoweb-child-theme' ); ?><span aria-hidden="true">↗</span></a>
					<?php endif; ?>
				</div>
			</div>
		</section>

		<section class="tw-support-services" aria-labelledby="tw-support-services-title">
			<div class="tw-shell">
				<div class="tw-support-section-heading">
					<p class="tw-kicker"><?php esc_html_e( 'Assistenza dedicata', 'ticinoweb-child-theme' ); ?></p>
					<h2 id="tw-support-services-title"><?php esc_html_e( 'Richiedi assistenza', 'ticinoweb-child-theme' ); ?></h2>
					<p><?php esc_html_e( 'Seleziona il servizio per cui hai bisogno di supporto.', 'ticinoweb-child-theme' ); ?></p>
				</div>
				<div class="tw-support-grid">
					<?php foreach ( $tw_support_services as $tw_service_key => $tw_service ) : ?>
						<?php
						$tw_service_email = tw_support_resolve_service_email( $tw_support_raw_content, $tw_service_key, $tw_support_email );
						$tw_service_href  = tw_support_build_mailto( $tw_service_email, $tw_service['subject'], $tw_service['service'] );
						?>
						<?php if ( $tw_service_href ) : ?>
							<a class="tw-support-card" href="<?php echo esc_url( $tw_service_href ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Richiedi assistenza per %s', 'ticinoweb-child-theme' ), $tw_service['service'] ) ); ?>">
								<span class="tw-support-card__number"><?php echo esc_html( $tw_service['number'] ); ?></span>
								<h3><?php echo esc_html( $tw_service['title'] ); ?></h3>
								<p><?php echo esc_html( $tw_service['description'] ); ?></p>
								<span class="tw-support-card__action"><?php esc_html_e( 'Richiedi assistenza', 'ticinoweb-child-theme' ); ?><span aria-hidden="true">↗</span></span>
							</a>
						<?php endif; ?>
					<?php endforeach; ?>
				</div>
			</div>
		</section>

		<section class="tw-support-story" aria-labelledby="tw-support-story-title">
			<div class="tw-shell tw-support-story__inner">
				<p class="tw-kicker"><?php esc_html_e( 'Il nostro supporto', 'ticinoweb-child-theme' ); ?></p>
				<h2 id="tw-support-story-title"><?php esc_html_e( 'Ci siamo anche dopo la consegna.', 'ticinoweb-child-theme' ); ?></h2>
				<div class="tw-support-story__copy">
					<?php foreach ( $tw_support_paragraphs as $tw_support_paragraph ) : ?>
						<p><?php echo esc_html( $tw_support_paragraph ); ?></p>
					<?php endforeach; ?>
				</div>
				<p class="tw-support-promise"><?php esc_html_e( 'Puoi contare su di noi, quando c’è bisogno noi ci siamo.', 'ticinoweb-child-theme' ); ?></p>
			</div>
		</section>

		<section class="tw-support-contact" aria-labelledby="tw-support-contact-title">
			<div class="tw-shell tw-support-contact__inner">
				<div>
					<p class="tw-kicker"><?php esc_html_e( 'Contatto diretto', 'ticinoweb-child-theme' ); ?></p>
					<h2 id="tw-support-contact-title"><?php esc_html_e( 'Non sai quale assistenza scegliere?', 'ticinoweb-child-theme' ); ?></h2>
				</div>
				<div class="tw-support-contact__details">
					<p><?php esc_html_e( 'Contattaci direttamente e ti indirizzeremo alla persona giusta.', 'ticinoweb-child-theme' ); ?></p>
					<?php if ( $tw_support_phone_href && $tw_support_phone_label ) : ?><a href="tel:<?php echo esc_attr( $tw_support_phone_href ); ?>"><?php echo esc_html( $tw_support_phone_label ); ?></a><?php endif; ?>
					<?php if ( $tw_support_email ) : ?><a href="mailto:<?php echo esc_attr( antispambot( $tw_support_email ) ); ?>"><?php echo esc_html( antispambot( $tw_support_email ) ); ?></a><?php endif; ?>
					<?php if ( $tw_support_contact_href ) : ?><a class="tw-text-link" href="<?php echo esc_url( $tw_support_contact_href ); ?>"><?php esc_html_e( 'Contattaci', 'ticinoweb-child-theme' ); ?><span aria-hidden="true">↗</span></a><?php endif; ?>
				</div>
			</div>
		</section>
	</main>
	<?php
endwhile;

get_footer();
