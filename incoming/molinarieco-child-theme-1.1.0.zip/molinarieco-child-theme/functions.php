<?php
/**
 * Garage Molinari child theme setup.
 *
 * @package Molinarieco
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
add_action( 'wp_enqueue_scripts', function () {
    wp_enqueue_style( 'molinarieco-parent', get_template_directory_uri() . '/style.css', array(), wp_get_theme( get_template() )->get( 'Version' ) );
}, 9 );

// The parent registers Google Fonts; use the system font on this site to avoid a third-party request.
add_action( 'wp_enqueue_scripts', function () {
    wp_dequeue_style( 'ticinoweb-ai-style' );
    wp_deregister_style( 'ticinoweb-ai-style' );
    wp_dequeue_style( 'poppins-font' );
    wp_deregister_style( 'poppins-font' );
    wp_register_style( 'poppins-font', false );
    wp_enqueue_style( 'ticinoweb-ai-style', get_stylesheet_uri(), array( 'molinarieco-parent' ), wp_get_theme()->get( 'Version' ) );
}, 11 );

// The parent prints Google Fonts preconnects even when its font is disabled.
// Remove only that closure for this child so a public visit does not contact Google.
add_action( 'after_setup_theme', function () {
    global $wp_filter;

    if ( empty( $wp_filter['wp_head']->callbacks[0] ) ) {
        return;
    }

    foreach ( $wp_filter['wp_head']->callbacks[0] as $entry ) {
        $callback = $entry['function'];
        if ( ! $callback instanceof Closure ) {
            continue;
        }

        $reflection = new ReflectionFunction( $callback );
        if ( $reflection->getFileName() !== get_template_directory() . '/functions.php' ) {
            continue;
        }

        $source = file( $reflection->getFileName() );
        $body   = implode( '', array_slice( $source, $reflection->getStartLine() - 1, $reflection->getEndLine() - $reflection->getStartLine() + 1 ) );
        if ( str_contains( $body, 'fonts.googleapis.com' ) && str_contains( $body, 'fonts.gstatic.com' ) ) {
            remove_action( 'wp_head', $callback, 0 );
        }
    }
}, 20 );

add_action( 'after_setup_theme', function () {
    register_nav_menus( array( 'molinarieco-footer-services' => __( 'Servizi nel footer', 'molinarieco-child-theme' ) ) );
} );

add_action( 'ticinoweb_footer_links', function () {
    if ( has_nav_menu( 'molinarieco-footer-services' ) ) {
        wp_nav_menu( array(
            'theme_location' => 'molinarieco-footer-services',
            'container'      => false,
            'items_wrap'     => '%3$s',
            'depth'          => 1,
        ) );
        return;
    }
    $services = get_page_by_path( 'servizi' );
    if ( $services ) {
        echo '<li><a href="' . esc_url( get_permalink( $services ) ) . '">' . esc_html( get_the_title( $services ) ) . '</a></li>';
    }
} );

add_action( 'ticinoweb_footer_brand_description', function () {
    $pages = array(
        'cookie-policy-ue' => __( 'Cookie Policy', 'molinarieco-child-theme' ),
        'impressum'        => __( 'Impressum', 'molinarieco-child-theme' ),
    );
    $links = array();

    foreach ( $pages as $slug => $label ) {
        $page = get_page_by_path( $slug );
        if ( $page && 'publish' === $page->post_status ) {
            $links[] = '<a href="' . esc_url( get_permalink( $page ) ) . '">' . esc_html( $label ) . '</a>';
        }
    }

    if ( $links ) {
        echo '<nav class="mol-legal-links" aria-label="' . esc_attr__( 'Informazioni legali', 'molinarieco-child-theme' ) . '">' . implode( '', $links ) . '</nav>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Links are built with escaped URLs and labels.
    }
    $hours = trim( (string) get_option( 'ticinoweb_contact_opening_hours' ) );
    $map_url = trim( (string) get_option( 'ticinoweb_contact_map_url' ) );
    if ( $hours ) {
        echo '<p class="mol-footer-hours">' . esc_html( $hours ) . '</p>';
    }
    if ( $map_url ) {
        echo '<p><a href="' . esc_url( $map_url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Indicazioni stradali', 'molinarieco-child-theme' ) . '</a></p>';
    }
} );

add_filter( 'ticinoweb_frontend_text_theme:footer:copyright', static function ( $text ) {
    return preg_replace( '/\.\.(?=\s)/u', '.', $text );
} );

add_filter( 'ticinoweb_seo_jsonld_org_schema', static function ( $schema ) {
    if ( 'LocalBusiness' !== ( $schema['@type'] ?? '' ) ) {
        return $schema;
    }
    $address = trim( (string) get_option( 'ticinoweb_contact_address' ) );
    if ( preg_match( '/^(.+),\s*(\d{4})\s+(.+)$/u', $address, $parts ) ) {
        $schema['address'] = array(
            '@type'           => 'PostalAddress',
            'streetAddress'   => trim( $parts[1] ),
            'postalCode'      => $parts[2],
            'addressLocality' => trim( $parts[3] ),
            'addressCountry'  => 'CH',
        );
    }
    return $schema;
} );

// The homepage video is page-specific content, selected from this site's Media Library.
add_action( 'add_meta_boxes_page', function ( $post ) {
    if ( (int) get_option( 'page_on_front' ) !== (int) $post->ID ) {
        return;
    }
    add_meta_box( 'mol-home-video', __( 'Video della home', 'molinarieco-child-theme' ), function ( $post ) {
        wp_nonce_field( 'mol_home_video_save', 'mol_home_video_nonce' );
        $selected = (int) get_post_meta( $post->ID, 'mol_hero_video_id', true );
        $videos = get_posts( array(
            'post_type'      => 'attachment',
            'post_status'    => 'inherit',
            'post_mime_type' => 'video',
            'posts_per_page' => 100,
        ) );
        echo '<p><label for="mol-hero-video-id">' . esc_html__( 'Scegli un video dalla Libreria media', 'molinarieco-child-theme' ) . '</label></p>';
        echo '<select id="mol-hero-video-id" name="mol_hero_video_id">';
        echo '<option value="0">' . esc_html__( 'Nessun video', 'molinarieco-child-theme' ) . '</option>';
        foreach ( $videos as $video ) {
            echo '<option value="' . esc_attr( $video->ID ) . '"' . selected( $selected, $video->ID, false ) . '>' . esc_html( get_the_title( $video ) ) . '</option>';
        }
        echo '</select>';
        echo '<p class="description">' . esc_html__( 'La copertina usa l’immagine in evidenza della pagina.', 'molinarieco-child-theme' ) . '</p>';
    }, 'page', 'side' );
} );

add_action( 'save_post_page', function ( $post_id ) {
    if ( (int) get_option( 'page_on_front' ) !== (int) $post_id || ! isset( $_POST['mol_home_video_nonce'] ) ) {
        return;
    }
    if ( ! is_string( $_POST['mol_home_video_nonce'] ) ) {
        return;
    }
    $nonce = sanitize_text_field( wp_unslash( $_POST['mol_home_video_nonce'] ) );
    if ( ! wp_verify_nonce( $nonce, 'mol_home_video_save' ) || ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }
    $video_id = isset( $_POST['mol_hero_video_id'] ) && is_scalar( $_POST['mol_hero_video_id'] ) ? absint( wp_unslash( $_POST['mol_hero_video_id'] ) ) : 0;
    if ( $video_id && wp_attachment_is( 'video', $video_id ) ) {
        update_post_meta( $post_id, 'mol_hero_video_id', $video_id );
    } else {
        delete_post_meta( $post_id, 'mol_hero_video_id' );
    }
} );

// The parent owns gallery membership and photo order; this only renders a named gallery.
add_shortcode( 'mol_gallery', function ( $attributes ) {
    $attributes = shortcode_atts( array( 'slug' => '' ), $attributes, 'mol_gallery' );
    $slug = sanitize_title( $attributes['slug'] );
    $term = $slug ? get_term_by( 'slug', $slug, 'ticinoweb_media_gallery' ) : false;
    if ( ! $term ) {
        return '';
    }
    $ids = get_posts( array(
        'post_type'      => 'attachment',
        'post_status'    => 'inherit',
        'post_mime_type' => 'image',
        'posts_per_page' => 30,
        'fields'         => 'ids',
        'tax_query'      => array( array(
            'taxonomy' => 'ticinoweb_media_gallery',
            'field'    => 'term_id',
            'terms'    => (int) $term->term_id,
        ) ),
    ) );
    $order = array_map( 'intval', (array) get_term_meta( $term->term_id, '_ticinoweb_gallery_order', true ) );
    $positions = array_flip( $order );
    usort( $ids, static function ( $a, $b ) use ( $positions ) {
        return ( $positions[ $a ] ?? PHP_INT_MAX ) <=> ( $positions[ $b ] ?? PHP_INT_MAX ) ?: $a <=> $b;
    } );
    if ( ! $ids ) {
        return '';
    }
    $output = '<div class="mol-gallery" aria-label="' . esc_attr( $term->name ) . '">';
    foreach ( $ids as $id ) {
        $alt = get_post_meta( $id, '_wp_attachment_image_alt', true ) ?: get_the_title( $id );
        $image = wp_get_attachment_image( $id, 'medium_large', false, array( 'loading' => 'lazy', 'alt' => $alt ) );
        if ( $image ) {
            $output .= '<a href="' . esc_url( wp_get_attachment_url( $id ) ) . '" aria-label="' . esc_attr( sprintf( __( 'Apri foto: %s', 'molinarieco-child-theme' ), $alt ) ) . '">' . $image . '</a>';
        }
    }
    return $output . '</div>';
} );
