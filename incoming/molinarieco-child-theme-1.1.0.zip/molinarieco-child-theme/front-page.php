<?php
/** Front page. */
get_header();
$front_id = (int) get_option( 'page_on_front' );
$hero_id  = $front_id ? get_post_thumbnail_id( $front_id ) : 0;
$video_id = $front_id ? (int) get_post_meta( $front_id, 'mol_hero_video_id', true ) : 0;
$video_url = $video_id && wp_attachment_is( 'video', $video_id ) ? wp_get_attachment_url( $video_id ) : '';
$poster_url = $hero_id ? wp_get_attachment_image_url( $hero_id, 'full' ) : '';
?>
<main id="main" class="mol-container">
<section class="mol-hero" aria-labelledby="mol-hero-title">
<?php if ( $video_url ) : ?>
<video class="mol-hero-video" controls playsinline preload="none"<?php if ( $poster_url ) : ?> poster="<?php echo esc_url( $poster_url ); ?>"<?php endif; ?> aria-label="<?php esc_attr_e( 'Video di presentazione', 'molinarieco-child-theme' ); ?>">
<source src="<?php echo esc_url( $video_url ); ?>" type="<?php echo esc_attr( get_post_mime_type( $video_id ) ); ?>">
<?php esc_html_e( 'Il tuo browser non supporta la riproduzione video.', 'molinarieco-child-theme' ); ?>
</video>
<?php elseif ( $hero_id ) : echo wp_get_attachment_image( $hero_id, 'full', false, array( 'fetchpriority' => 'high', 'loading' => 'eager' ) ); endif; ?>
<div class="mol-hero-content"><h1 id="mol-hero-title"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></h1><p><?php echo esc_html( get_bloginfo( 'description' ) ); ?></p><a class="mol-button" href="<?php echo esc_url( home_url( '/servizi/' ) ); ?>"><?php esc_html_e( 'Scopri i servizi', 'molinarieco-child-theme' ); ?></a></div>
</section>
<?php if ( $front_id ) : $front = get_post( $front_id ); if ( $front ) : ?><div class="mol-home-sections"><?php echo apply_filters( 'the_content', $front->post_content ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><?php endif; endif; ?>
</main>
<?php get_footer(); ?>
