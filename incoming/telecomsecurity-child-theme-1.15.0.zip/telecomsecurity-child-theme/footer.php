<?php
/**
 * Institutional contact footer — Telecom Security Child Theme.
 */
defined( 'ABSPATH' ) || exit;

$contacts = telecomsecurity_get_contact_data();
$cms_contacts = function_exists( 'ticinoweb_get_contact_info' ) ? ticinoweb_get_contact_info() : array();
if ( ! empty( $cms_contacts['address'] ) ) {
	$contacts['address'] = trim( (string) $cms_contacts['address'] );
}
$contacts['email'] = sanitize_email( $cms_contacts['email'] ?? '' ) ?: $contacts['email'];

// Keep every distinct telephone value supplied by the CMS, prioritizing the
// dedicated landline field over the generic legacy telephone field.
$phone_entries = array();
$seen_phone_numbers = array();
$add_phone_entry = static function ( string $label, string $number ) use ( &$phone_entries, &$seen_phone_numbers ): void {
	$number = trim( $number );
	$normalized = preg_replace( '/\D+/', '', $number ) ?: '';
	if ( '' === $normalized || isset( $seen_phone_numbers[ $normalized ] ) ) {
		return;
	}

	$seen_phone_numbers[ $normalized ] = true;
	$phone_entries[] = array(
		'label'  => $label,
		'number' => $number,
		'href'   => telecomsecurity_contact_phone_href( $number ),
	);
};

$primary_phone = trim( (string) ( $cms_contacts['phone_landline'] ?? '' ) ) ?: $contacts['phone'];
$mobile_phone = trim( (string) ( $cms_contacts['phone_mobile'] ?? '' ) );
$cms_phone = trim( (string) ( $cms_contacts['phone'] ?? '' ) );

$add_phone_entry( __( 'Telefono principale', 'telecomsecurity-child-theme' ), $primary_phone );
$add_phone_entry( __( 'Cellulare', 'telecomsecurity-child-theme' ), $mobile_phone );
$add_phone_entry( __( 'Telefono', 'telecomsecurity-child-theme' ), $cms_phone );

// Include future telephone fields returned by the parent CMS without template changes.
foreach ( $cms_contacts as $contact_key => $contact_value ) {
	if ( ! is_scalar( $contact_value ) || ! preg_match( '/(?:phone|telefono|mobile|cell)/i', (string) $contact_key ) ) {
		continue;
	}
	$add_phone_entry( __( 'Altro numero', 'telecomsecurity-child-theme' ), (string) $contact_value );
}

// Reuse a supplied map URL only; never generate coordinates or a search link.
$map_url = esc_url_raw( $cms_contacts['map_url'] ?? $contacts['map_url'] ?? '', array( 'https', 'http' ) );
$footer_menu_location = has_nav_menu( 'footer' ) ? 'footer' : 'primary';
$site_logo = function_exists( 'ticinoweb_get_site_logo' ) ? ticinoweb_get_site_logo() : '';
$site_logo_id = $site_logo ? attachment_url_to_postid( $site_logo ) : 0;
$logo_meta = $site_logo_id ? wp_get_attachment_metadata( $site_logo_id ) : array();
$horizontal_logo = ! empty( $logo_meta['height'] ) && ( $logo_meta['width'] / $logo_meta['height'] ) >= 1.8;
$privacy_url = function_exists( 'get_privacy_policy_url' ) ? get_privacy_policy_url() : '';
$terms_page = get_page_by_path( 'termini-condizioni', OBJECT, 'page' );
$terms_url = $terms_page instanceof WP_Post && 'publish' === $terms_page->post_status ? get_permalink( $terms_page ) : '';

$swisscom_partner = array();
$footer_partners = function_exists( 'telecomsecurity_get_partners_list' ) ? telecomsecurity_get_partners_list() : array();
foreach ( $footer_partners as $partner ) {
	$partner_search = implode( ' ', array( $partner['alt'] ?? '', $partner['logo'] ?? '', $partner['link'] ?? '' ) );
	if ( false !== stripos( $partner_search, 'swisscom' ) ) {
		$swisscom_partner = $partner;
		break;
	}
}
$iso_gallery_ids = function_exists( 'telecomsecurity_get_media_gallery_attachment_ids' )
	? telecomsecurity_get_media_gallery_attachment_ids( 15 )
	: array();
$iso_badge_id = ! empty( $iso_gallery_ids ) ? absint( $iso_gallery_ids[0] ) : 0;
$footer_icon_url = function_exists( 'telecomsecurity_get_intro_icon_url' ) ? telecomsecurity_get_intro_icon_url() : '';
?>

<footer class="ts-footer" data-signal-theme="dark" data-footer-reveal>
	<?php if ( $footer_icon_url ) : ?>
		<div class="ts-footer__watermark" aria-hidden="true">
			<img class="ts-footer__watermark-image" src="<?php echo esc_url( $footer_icon_url ); ?>" alt="" loading="lazy" decoding="async">
		</div>
	<?php endif; ?>
	<div class="ts-container ts-footer__container">
		<div class="ts-footer__perimeter" aria-hidden="true"><span></span></div>
		<div class="ts-footer__main">
			<div class="ts-footer__identity">
				<a class="ts-footer__brand<?php echo $horizontal_logo ? ' has-horizontal-logo' : ''; ?>" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" aria-label="<?php esc_attr_e( 'Telecom Security — Home', 'telecomsecurity-child-theme' ); ?>">
					<?php if ( $site_logo ) : ?>
						<?php
						if ( $site_logo_id ) {
							echo wp_get_attachment_image( $site_logo_id, 'full', false, array( 'class' => 'ts-footer__logo', 'alt' => '', 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '290px' ) );
						} else {
							?>
							<img class="ts-footer__logo" src="<?php echo esc_url( $site_logo ); ?>" alt="" loading="lazy" decoding="async">
							<?php
						}
						?>
					<?php endif; ?>
					<span class="ts-footer__brand-name" aria-hidden="true">TELECOM <strong>SECURITY</strong></span>
				</a>
				<h2 class="ts-footer__heading"><?php esc_html_e( 'Sicurezza integrata dal 1975.', 'telecomsecurity-child-theme' ); ?></h2>
				<p class="ts-footer__tagline"><?php echo esc_html( telecomsecurity_identity( 'footer_text' ) ); ?></p>
			</div>

			<div class="ts-footer__contacts">
				<h3 class="ts-footer__contact-title"><?php esc_html_e( 'Contatto diretto', 'telecomsecurity-child-theme' ); ?></h3>
				<address class="ts-footer__contact-list">
					<div class="ts-footer__contact-row ts-footer__contact-row--phones">
						<span class="ts-footer__contact-label"><?php esc_html_e( 'Recapiti', 'telecomsecurity-child-theme' ); ?></span>
						<span class="ts-footer__contact-copy">
							<span class="ts-footer__phone-list">
								<?php foreach ( $phone_entries as $phone_entry ) : ?>
									<a class="ts-footer__phone-item" href="tel:<?php echo esc_attr( $phone_entry['href'] ); ?>">
										<span class="ts-footer__phone-kind"><?php echo esc_html( $phone_entry['label'] ); ?></span>
										<span class="ts-footer__value"><?php echo esc_html( $phone_entry['number'] ); ?></span>
										<span class="ts-footer__phone-arrow" aria-hidden="true">↗</span>
									</a>
								<?php endforeach; ?>
							</span>
						</span>
					</div>
					<a class="ts-footer__contact-row" href="mailto:<?php echo esc_attr( $contacts['email'] ); ?>">
						<span class="ts-footer__contact-label"><?php esc_html_e( 'E-mail', 'telecomsecurity-child-theme' ); ?></span>
						<span class="ts-footer__contact-copy"><span class="ts-footer__value"><?php echo esc_html( $contacts['email'] ); ?></span></span>
						<span class="ts-footer__arrow" aria-hidden="true">↗</span>
					</a>
					<?php if ( $map_url ) : ?>
					<a class="ts-footer__contact-row" href="<?php echo esc_url( $map_url ); ?>">
					<?php else : ?>
					<div class="ts-footer__contact-row">
					<?php endif; ?>
						<span class="ts-footer__contact-label"><?php esc_html_e( 'Sede', 'telecomsecurity-child-theme' ); ?></span>
						<span class="ts-footer__contact-copy"><span class="ts-footer__value"><?php echo esc_html( $contacts['address'] ); ?></span></span>
						<?php if ( $map_url ) : ?><span class="ts-footer__arrow" aria-hidden="true">↗</span><?php endif; ?>
					<?php if ( $map_url ) : ?></a><?php else : ?></div><?php endif; ?>
				</address>
			</div>
		</div>

		<section class="ts-footer__credentials" aria-labelledby="ts-footer-credentials-title">
			<header class="ts-footer__credentials-heading">
				<p class="ts-footer__credentials-kicker"><?php esc_html_e( 'Partner e standard', 'telecomsecurity-child-theme' ); ?></p>
				<h2 id="ts-footer-credentials-title"><?php esc_html_e( 'Affidabilità riconosciuta.', 'telecomsecurity-child-theme' ); ?></h2>
				<p><?php esc_html_e( 'Tecnologia svizzera e qualità verificata accompagnano ogni progetto.', 'telecomsecurity-child-theme' ); ?></p>
			</header>

			<div class="ts-footer__credential-grid">
				<?php if ( ! empty( $swisscom_partner['logo'] ) ) : ?>
					<?php if ( ! empty( $swisscom_partner['link'] ) ) : ?>
					<a class="ts-footer__credential-card ts-footer__credential-card--swisscom" href="<?php echo esc_url( $swisscom_partner['link'] ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr( sprintf( __( 'Visita il sito di %s', 'telecomsecurity-child-theme' ), $swisscom_partner['alt'] ) ); ?>">
					<?php else : ?>
					<div class="ts-footer__credential-card ts-footer__credential-card--swisscom">
					<?php endif; ?>
						<span class="ts-footer__credential-copy">
							<span class="ts-footer__credential-label"><?php esc_html_e( 'Partner tecnologico', 'telecomsecurity-child-theme' ); ?></span>
							<strong>Swisscom</strong>
						</span>
						<img src="<?php echo esc_url( $swisscom_partner['logo'] ); ?>" alt="" class="ts-footer__credential-logo ts-footer__credential-logo--swisscom" loading="lazy" decoding="async">
						<?php if ( ! empty( $swisscom_partner['link'] ) ) : ?><span class="ts-footer__credential-arrow" aria-hidden="true">↗</span><?php endif; ?>
					<?php if ( ! empty( $swisscom_partner['link'] ) ) : ?></a><?php else : ?></div><?php endif; ?>
				<?php endif; ?>

				<div class="ts-footer__credential-card ts-footer__credential-card--iso">
					<span class="ts-footer__credential-copy">
						<span class="ts-footer__credential-label"><?php esc_html_e( 'Certificazione', 'telecomsecurity-child-theme' ); ?></span>
						<strong>ISO 9001:2015</strong>
						<small><?php esc_html_e( 'Sistema di gestione della qualità', 'telecomsecurity-child-theme' ); ?></small>
					</span>
					<?php
					if ( $iso_badge_id ) {
						echo wp_get_attachment_image(
							$iso_badge_id,
							'medium',
							false,
							array(
								'class'    => 'ts-footer__credential-logo ts-footer__credential-logo--iso',
								'alt'      => __( 'Certificazione ISO 9001:2015', 'telecomsecurity-child-theme' ),
								'loading'  => 'lazy',
								'decoding' => 'async',
								'sizes'    => '106px',
							)
						);
					}
					?>
				</div>
			</div>
		</section>

		<nav class="ts-footer__navigation" aria-label="<?php esc_attr_e( 'Navigazione nel footer', 'telecomsecurity-child-theme' ); ?>">
			<?php
			if ( has_nav_menu( $footer_menu_location ) ) {
				wp_nav_menu( array(
					'theme_location' => $footer_menu_location,
					'container' => false,
					'menu_class' => 'ts-footer__menu',
					'fallback_cb' => false,
					'depth' => 1,
					'items_wrap' => '<ul id="%1$s" class="%2$s">%3$s</ul>',
				) );
			} else {
				echo '<ul class="ts-footer__menu"></ul>';
			}
			?>
		</nav>

		<div class="ts-footer__legal">
			<p>© <?php echo esc_html( wp_date( 'Y' ) ); ?> Telecom Security SA · <?php esc_html_e( 'Tutti i diritti riservati.', 'telecomsecurity-child-theme' ); ?></p>
			<div class="ts-footer__legal-links">
				<?php if ( $privacy_url ) : ?><a href="<?php echo esc_url( $privacy_url ); ?>"><?php esc_html_e( 'Privacy Policy', 'telecomsecurity-child-theme' ); ?></a><?php endif; ?>
				<?php if ( $terms_url ) : ?><a href="<?php echo esc_url( $terms_url ); ?>"><?php esc_html_e( 'Termini & Condizioni', 'telecomsecurity-child-theme' ); ?></a><?php endif; ?>
				<a class="ts-footer__admin-link" href="<?php echo esc_url( admin_url() ); ?>"><?php esc_html_e( 'Area riservata', 'telecomsecurity-child-theme' ); ?></a>
				<span><?php esc_html_e( 'Design & Realizzazione:', 'telecomsecurity-child-theme' ); ?> <a href="https://ticinoweb.ch" target="_blank" rel="noopener">ticinoWEB</a></span>
			</div>
		</div>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
