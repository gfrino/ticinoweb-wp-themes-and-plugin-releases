<?php
/**
 * The header for Telecom Security Child Theme.
 *
 * Header dinamico con transizione da trasparente a solido compatto su scroll,
 * logo dal CMS e menu nativo WordPress gestibile da Aspetto -> Menu.
 *
 * @package TelecomSecurityChild
 * @version 1.11.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<?php if ( is_front_page() ) : ?>
	<?php
	$preloader = telecomsecurity_get_preloader_data();
	$preloader_logo_id = $preloader['logo_url'] ? attachment_url_to_postid( $preloader['logo_url'] ) : 0;
	?>
	<div class="ts-preloader" id="ts-preloader" aria-hidden="true">
		<div class="ts-preloader__panel ts-preloader__panel--left" aria-hidden="true"></div>
		<div class="ts-preloader__panel ts-preloader__panel--right" aria-hidden="true"></div>
		<div class="ts-preloader__content">
			<div class="ts-preloader__emblem" aria-hidden="true">
				<svg class="ts-preloader__shield" viewBox="0 0 240 270" focusable="false">
					<path d="M120 10 220 48v78c0 64-42 106-100 134C62 232 20 190 20 126V48Z" />
				</svg>
				<div class="ts-preloader__mark">
					<?php if ( $preloader_logo_id ) : ?>
						<?php echo wp_get_attachment_image( $preloader_logo_id, 'medium', false, array( 'alt' => '', 'fetchpriority' => 'high', 'decoding' => 'async', 'data-preload-critical' => 'true', 'sizes' => '112px' ) ); ?>
					<?php elseif ( $preloader['logo_url'] ) : ?>
						<img src="<?php echo esc_url( $preloader['logo_url'] ); ?>" alt="" fetchpriority="high" decoding="async" data-preload-critical>
					<?php else : ?>
						<span>TS</span>
					<?php endif; ?>
				</div>
				<span class="ts-preloader__scanner"></span>
			</div>
			<p class="ts-preloader__status" data-preloader-status aria-live="polite" aria-atomic="true"><?php echo esc_html( $preloader['loading_text'] ); ?></p>
		</div>
	</div>
<?php endif; ?>

<a class="skip-link screen-reader-text" href="#primary-content">
	<?php esc_html_e( 'Salta al contenuto principale', 'telecomsecurity-child-theme' ); ?>
</a>

<header class="ts-header<?php echo is_front_page() ? ' ts-header--hero' : ''; ?>" id="site-header" role="banner">
	<div class="ts-container ts-header__inner">
		
		<!-- Brand / Logo Dinamico -->
		<div class="ts-header__branding">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="ts-brand" rel="home">
				<?php
				$custom_logo = function_exists( 'ticinoweb_get_site_logo' ) ? ticinoweb_get_site_logo() : '';
				if ( ! empty( $custom_logo ) ) :
					?>
					<img src="<?php echo esc_url( $custom_logo ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" class="ts-brand__logo-img" data-preload-critical>
				<?php else : ?>
					<span class="ts-brand__text">
						<span class="ts-brand__main">TELECOM <strong>SECURITY</strong></span>
						<span class="ts-brand__signal-dot" aria-hidden="true"></span>
					</span>
					<span class="ts-brand__meta">TICINO · SEMENTINA · DAL 1975</span>
				<?php endif; ?>
			</a>
		</div>

		<nav class="ts-header-nav" id="ts-header-nav" aria-label="<?php esc_attr_e( 'Menu principale', 'telecomsecurity-child-theme' ); ?>">
			<div class="ts-mobile-main-panel">
				<?php wp_nav_menu(array('theme_location' => 'primary', 'container' => false, 'menu_class' => 'ts-header-menu', 'fallback_cb' => false, 'depth' => 0, 'walker' => new TelecomSecurity_Header_Walker())); ?>
				<a class="ts-nav-contact" href="<?php echo esc_url(home_url('/contatti/')); ?>">Richiedi consulenza <span aria-hidden="true">→</span></a>
			</div>
        </nav>

		<!-- Azioni Header: CTA & Hamburger Toggle -->
		<div class="ts-header__actions">
			<a href="<?php echo esc_url( home_url( '/contatti/' ) ); ?>" class="ts-btn ts-btn--header">
				<span>Richiedi consulenza</span>
			</a>

			<button type="button" class="ts-burger" id="ts-burger-btn" aria-label="<?php esc_attr_e( 'Apri menu di navigazione', 'telecomsecurity-child-theme' ); ?>" aria-expanded="false" aria-controls="ts-header-nav">
				<span class="ts-burger__bar"></span>
				<span class="ts-burger__bar"></span>
				<span class="ts-burger__bar"></span>
			</button>
		</div>

	</div>

</header>
