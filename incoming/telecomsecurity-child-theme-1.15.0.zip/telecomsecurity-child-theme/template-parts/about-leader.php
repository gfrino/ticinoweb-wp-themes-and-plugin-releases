<?php
/**
 * Company leader profile and dynamic Media Gallery.
 *
 * @package TelecomSecurityChild
 */

defined( 'ABSPATH' ) || exit;

$leader = telecomsecurity_get_about_leader_data();
if ( empty( $leader['is_visible'] ) ) {
	return;
}
?>

<section class="ts-about-leader" data-signal-label="<?php echo esc_attr( $leader['name'] ); ?>" data-signal-theme="light" aria-labelledby="ts-about-leader-title">
	<div class="ts-container ts-about-leader__inner">
		<div class="ts-about-leader__profile">
			<figure class="ts-about-leader__portrait">
				<?php
				echo wp_get_attachment_image(
					$leader['portrait_id'],
					'large',
					false,
					array(
						'class'    => 'ts-about-leader__portrait-image',
						'alt'      => $leader['portrait_alt'],
						'loading'  => 'lazy',
						'decoding' => 'async',
						'sizes'    => '(max-width: 767px) calc(100vw - 40px), (max-width: 1023px) 42vw, 430px',
					)
				);
				?>
			</figure>

			<header class="ts-about-leader__identity">
				<?php if ( '' !== $leader['role'] ) : ?>
					<p class="ts-about-leader__role"><?php echo esc_html( $leader['role'] ); ?></p>
				<?php endif; ?>
				<h2 id="ts-about-leader-title"><?php echo esc_html( $leader['name'] ); ?></h2>
				<span class="ts-about-leader__signal" aria-hidden="true"></span>
			</header>
		</div>

		<?php if ( ! empty( $leader['gallery_ids'] ) ) : ?>
			<div class="ts-about-leader__gallery" role="list" aria-label="<?php esc_attr_e( 'Galleria fotografica', 'telecomsecurity-child-theme' ); ?>">
				<?php foreach ( $leader['gallery_ids'] as $attachment_id ) : ?>
					<figure class="ts-about-leader__gallery-item" role="listitem">
						<?php
						echo wp_get_attachment_image(
							$attachment_id,
							'medium_large',
							false,
							array(
								'class'    => 'ts-about-leader__gallery-image',
								'alt'      => $leader['gallery_alt'][ $attachment_id ] ?? '',
								'loading'  => 'lazy',
								'decoding' => 'async',
								'sizes'    => '(max-width: 639px) 78vw, (max-width: 1023px) 42vw, 29vw',
							)
						);
						?>
					</figure>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</div>
</section>
