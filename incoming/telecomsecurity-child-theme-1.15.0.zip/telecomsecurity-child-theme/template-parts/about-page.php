<?php
/**
 * Template editoriale dinamico per la pagina Chi siamo.
 *
 * @package TelecomSecurityChild
 */

defined( 'ABSPATH' ) || exit;

$about           = telecomsecurity_get_about_page_data( get_the_ID() );
$has_media       = '' !== $about['image'];
$has_credentials = ! empty( $about['credentials'] ) && '' !== $about['credentials_context'];
$has_story       = '' !== $about['text'] || $has_credentials;
$has_cta         = '' !== $about['cta_title'] && '' !== $about['cta_button'] && '' !== $about['cta_link'];
$company_name    = trim( (string) get_bloginfo( 'name' ) );
$hero_class      = $has_media ? 'ts-about-hero' : 'ts-about-hero ts-about-hero--text-only';
$story_label     = '' !== $company_name ? $company_name : $about['label'];
?>

<main id="primary-content" class="ts-about">
	<section class="<?php echo esc_attr( $hero_class ); ?>" data-signal-label="<?php echo esc_attr( $about['label'] ); ?>" data-signal-theme="light" aria-labelledby="ts-about-title">
		<div class="ts-container ts-about-hero__layout">
			<div class="ts-about-hero__copy">
				<?php if ( '' !== $about['label'] ) : ?>
					<p class="ts-about-hero__label"><?php echo esc_html( $about['label'] ); ?></p>
				<?php endif; ?>

				<?php if ( '' !== $about['title'] ) : ?>
					<h1 id="ts-about-title"><?php echo esc_html( $about['title'] ); ?></h1>
				<?php endif; ?>

				<?php if ( '' !== $about['intro'] ) : ?>
					<p class="ts-about-hero__intro"><?php echo esc_html( $about['intro'] ); ?></p>
				<?php endif; ?>

				<span class="ts-about-hero__signal" aria-hidden="true"></span>
			</div>

			<?php if ( $has_media ) : ?>
				<figure class="ts-about-hero__media">
					<?php
					if ( $about['image_id'] ) {
						echo wp_get_attachment_image(
							$about['image_id'],
							'large',
							false,
							array(
								'class'         => 'ts-about-hero__image',
								'alt'           => $about['image_alt'],
								'loading'       => 'eager',
								'fetchpriority' => 'high',
								'decoding'      => 'async',
								'sizes'         => '(max-width: 767px) calc(100vw - 40px), (max-width: 1023px) calc(100vw - 80px), 620px',
							)
						);
					} else {
						printf(
							'<img class="ts-about-hero__image" src="%1$s" alt="%2$s" loading="eager" fetchpriority="high" decoding="async">',
							esc_url( $about['image'] ),
							esc_attr( $about['image_alt'] )
						);
					}
					?>
				</figure>
			<?php endif; ?>
		</div>
	</section>

	<?php if ( $has_story ) : ?>
		<section class="ts-about-story" data-signal-label="<?php echo esc_attr( $story_label ); ?>" data-signal-theme="light" aria-label="<?php echo esc_attr( $story_label ); ?>">
			<div class="ts-container ts-about-story__layout">
				<?php if ( '' !== $about['text'] ) : ?>
					<div class="ts-about-story__content">
						<?php echo wp_kses_post( wpautop( $about['text'] ) ); ?>
					</div>
				<?php endif; ?>

				<?php if ( $has_credentials ) : ?>
					<aside class="ts-about-story__credentials" data-about-credentials aria-labelledby="ts-about-credentials-title">
						<?php if ( '' !== $about['credentials_label'] ) : ?>
							<p class="ts-about-story__credentials-label"><?php echo esc_html( $about['credentials_label'] ); ?></p>
						<?php endif; ?>
						<h2 id="ts-about-credentials-title"><?php esc_html_e( 'Affidabilità certificata', 'telecomsecurity-child-theme' ); ?></h2>
						<span class="ts-about-story__credentials-signal" aria-hidden="true"></span>
						<div class="ts-about-story__credentials-list" role="list">
							<?php foreach ( $about['credentials'] as $credential ) : ?>
								<div class="ts-about-story__credential" role="listitem">
									<span aria-hidden="true"></span>
									<strong><?php echo esc_html( $credential ); ?></strong>
								</div>
							<?php endforeach; ?>
						</div>
						<p class="ts-about-story__credentials-context"><?php echo esc_html( $about['credentials_context'] ); ?></p>
					</aside>
				<?php else : ?>
					<div class="ts-about-story__rail" aria-hidden="true">
						<span></span>
						<strong><?php echo esc_html( $story_label ); ?></strong>
					</div>
				<?php endif; ?>
			</div>
		</section>
	<?php endif; ?>

	<?php get_template_part( 'template-parts/about-leader' ); ?>

	<?php get_template_part( 'template-parts/partners' ); ?>

	<?php if ( $has_cta ) : ?>
		<section class="ts-about-cta" data-signal-label="<?php echo esc_attr( $about['cta_label'] ); ?>" data-signal-theme="dark" aria-labelledby="ts-about-cta-title">
			<div class="ts-container ts-about-cta__layout">
				<div class="ts-about-cta__copy">
					<?php if ( '' !== $about['cta_label'] ) : ?>
						<p class="ts-about-cta__label"><?php echo esc_html( $about['cta_label'] ); ?></p>
					<?php endif; ?>
					<h2 id="ts-about-cta-title"><?php echo esc_html( $about['cta_title'] ); ?></h2>
					<?php if ( '' !== $about['cta_text'] ) : ?>
						<p class="ts-about-cta__text"><?php echo esc_html( $about['cta_text'] ); ?></p>
					<?php endif; ?>
				</div>
				<a class="ts-about-cta__button" href="<?php echo esc_url( $about['cta_link'] ); ?>">
					<span><?php echo esc_html( $about['cta_button'] ); ?></span>
					<span aria-hidden="true">→</span>
				</a>
			</div>
		</section>
	<?php endif; ?>
</main>
