<?php
/** Dynamic single-service view shared by every CMS-linked service page. */
defined( 'ABSPATH' ) || exit;

$service_context = isset( $args['service_context'] ) && is_array( $args['service_context'] ) ? $args['service_context'] : array();
$page_id         = get_the_ID();
$service         = $service_context['current'];
$content         = telecomsecurity_get_service_content( $page_id );
$related         = telecomsecurity_get_related_services( $page_id, $service_context );
$lead            = trim( (string) get_the_excerpt() );
$lead            = $lead ?: trim( wp_strip_all_tags( $service['description'] ?? '' ) );
$image_id        = get_post_thumbnail_id( $page_id );
$image_position  = $service['image_position'] ?? '50% 50%';
$archive_url     = ! empty( $service_context['archive_id'] ) ? get_permalink( $service_context['archive_id'] ) : '';
$title_length    = function_exists( 'mb_strlen' ) ? mb_strlen( get_the_title() ) : strlen( get_the_title() );
$hero_class      = $title_length >= 56 ? ' is-long-title' : '';
$hero_class     .= $title_length >= 17 ? ' is-responsive-title' : '';
$hero_class     .= $image_id ? '' : ' has-no-image';
$has_contact     = ! empty( $content['faqs'] ) || $content['cta_title'] || $content['cta_text'];
$has_final_nav   = ! empty( $service_context['previous'] ) || $archive_url || ! empty( $service_context['next'] );
$information_groups = array();

if ( ! empty( $content['faqs'] ) && function_exists( 'ticinoweb_faq_schema_add' ) ) {
	ticinoweb_faq_schema_add( $content['faqs'] );
}

if ( ! empty( $content['includes'] ) ) {
	$information_groups['includes'] = array( 'label' => __( 'Cosa comprende', 'telecomsecurity-child-theme' ), 'items' => $content['includes'] );
}
if ( ! empty( $content['applications'] ) ) {
	$information_groups['applications'] = array( 'label' => __( 'Dove trova applicazione', 'telecomsecurity-child-theme' ), 'items' => $content['applications'] );
}
if ( ! empty( $content['benefits'] ) ) {
	$information_groups['benefits'] = array( 'label' => __( 'Vantaggi concreti', 'telecomsecurity-child-theme' ), 'items' => $content['benefits'] );
}
?>
<main id="primary-content" class="ts-service-single" data-signal-theme="light">
	<article <?php post_class( 'ts-service-single__article' ); ?>>
		<header id="service-hero" class="ts-service-hero<?php echo esc_attr( $hero_class ); ?>" data-signal-label="<?php echo esc_attr( get_the_title() ); ?>">
			<div class="ts-service-shell ts-service-hero__layout">
				<div class="ts-service-hero__copy">
					<div class="ts-service-hero__mark"><?php echo telecomsecurity_geometry( $service['geometry'] ?? 'shield' ); ?><p class="ts-service-code"><?php echo esc_html( ( $service['index'] ?? '01' ) . ' / ' . ( $service['total'] ?? '11' ) ); ?></p></div>
					<h1><?php the_title(); ?></h1>
					<?php if ( $lead ) : ?><div class="ts-service-lead"><?php echo wp_kses_post( telecomsecurity_service_text( $lead ) ); ?></div><?php endif; ?>
					<?php if ( ! empty( $content['cta_url'] ) ) : ?><a class="ts-service-link" href="<?php echo esc_url( $content['cta_url'] ); ?>"><?php esc_html_e( 'Richiedi una consulenza', 'telecomsecurity-child-theme' ); ?><span aria-hidden="true">→</span></a><?php endif; ?>
				</div>
				<?php if ( $image_id ) : ?>
					<figure class="ts-service-hero__media" style="--ts-service-image-position:<?php echo esc_attr( $image_position ); ?>"><?php echo wp_get_attachment_image( $image_id, 'large', false, array( 'class' => 'ts-service-hero__image', 'loading' => 'eager', 'fetchpriority' => 'high', 'decoding' => 'async', 'sizes' => '(max-width: 767px) calc(100vw - 40px), (max-width: 1300px) 47vw, 600px' ) ); ?></figure>
				<?php endif; ?>
			</div>
		</header>

		<?php if ( $content['overview_title'] || $content['overview'] || $information_groups ) : ?>
		<section id="service-details" class="ts-service-info ts-service-section" aria-labelledby="ts-service-info-title" data-signal-label="<?php esc_attr_e( 'Panoramica', 'telecomsecurity-child-theme' ); ?>">
			<div class="ts-service-shell">
				<svg class="ts-service-perimeter" data-service-perimeter viewBox="0 0 1200 560" preserveAspectRatio="xMidYMid slice" aria-hidden="true" focusable="false">
					<path d="M82 428 L82 125 L315 52 L608 118 L852 58 L1115 158 L1115 432 L884 505 L598 438 L315 510 Z" />
					<path d="M82 266 L315 215 L598 282 L852 205 L1115 270" />
					<circle cx="82" cy="125" r="6" /><circle cx="315" cy="52" r="5" /><circle cx="608" cy="118" r="7" /><circle cx="852" cy="58" r="5" /><circle cx="1115" cy="158" r="6" /><circle cx="598" cy="438" r="5" />
					<circle class="ts-service-perimeter__beacon" r="7"><animateMotion data-service-perimeter-motion dur="21s" repeatCount="indefinite" begin="indefinite" path="M82 428 L82 125 L315 52 L608 118 L852 58 L1115 158 L1115 432 L884 505 L598 438 L315 510 Z" /></circle>
				</svg>
				<?php if ( $content['overview_title'] || $content['overview'] ) : ?>
					<div class="ts-service-info__overview ts-service-reveal" data-service-reveal>
						<p class="ts-service-section__number" aria-hidden="true">01</p>
						<?php if ( $content['overview_title'] ) : ?><h2 id="ts-service-info-title"><?php echo esc_html( $content['overview_title'] ); ?></h2><?php else : ?><h2 id="ts-service-info-title"><?php esc_html_e( 'Panoramica', 'telecomsecurity-child-theme' ); ?></h2><?php endif; ?>
						<?php if ( $content['overview'] ) : ?><div class="ts-service-body-copy"><?php echo wp_kses_post( telecomsecurity_service_text( $content['overview'] ) ); ?></div><?php endif; ?>
					</div>
				<?php else : ?>
					<h2 id="ts-service-info-title" class="screen-reader-text"><?php esc_html_e( 'Informazioni sul servizio', 'telecomsecurity-child-theme' ); ?></h2>
				<?php endif; ?>

				<?php if ( $information_groups ) : ?>
					<div class="ts-service-tabs ts-service-reveal" data-service-tabs data-service-reveal>
						<div class="ts-service-tabs__list" role="tablist" aria-label="<?php esc_attr_e( 'Informazioni sul servizio', 'telecomsecurity-child-theme' ); ?>">
							<?php foreach ( $information_groups as $group_key => $group ) : $is_first = array_key_first( $information_groups ) === $group_key; ?>
								<button id="ts-service-tab-<?php echo esc_attr( $group_key ); ?>" class="ts-service-tabs__tab<?php echo $is_first ? ' is-active' : ''; ?>" type="button" role="tab" aria-selected="<?php echo $is_first ? 'true' : 'false'; ?>" aria-controls="ts-service-panel-<?php echo esc_attr( $group_key ); ?>" tabindex="<?php echo $is_first ? '0' : '-1'; ?>" data-service-tab="<?php echo esc_attr( $group_key ); ?>"><?php echo esc_html( $group['label'] ); ?></button>
							<?php endforeach; ?>
						</div>
						<div class="ts-service-tabs__panels">
							<?php foreach ( $information_groups as $group_key => $group ) : $is_first = array_key_first( $information_groups ) === $group_key; ?>
								<section id="ts-service-panel-<?php echo esc_attr( $group_key ); ?>" class="ts-service-tabs__panel ts-service-tabs__panel--<?php echo esc_attr( $group_key ); ?><?php echo $is_first ? ' is-active' : ''; ?>" role="tabpanel" aria-labelledby="ts-service-tab-<?php echo esc_attr( $group_key ); ?>" aria-hidden="<?php echo $is_first ? 'false' : 'true'; ?>" data-service-panel="<?php echo esc_attr( $group_key ); ?>">
									<button id="ts-service-accordion-<?php echo esc_attr( $group_key ); ?>" class="ts-service-tabs__accordion" type="button" aria-expanded="<?php echo $is_first ? 'true' : 'false'; ?>" aria-controls="ts-service-panel-content-<?php echo esc_attr( $group_key ); ?>" data-service-accordion="<?php echo esc_attr( $group_key ); ?>"><span><?php echo esc_html( $group['label'] ); ?></span><span aria-hidden="true"></span></button>
									<div id="ts-service-panel-content-<?php echo esc_attr( $group_key ); ?>" class="ts-service-tabs__panel-content">
										<ol class="ts-service-info-list">
											<?php foreach ( $group['items'] as $index => $item ) : ?>
												<li><span class="ts-service-info-list__number" aria-hidden="true"><?php echo esc_html( sprintf( '%02d', $index + 1 ) ); ?></span><div><h3><?php echo esc_html( $item['title'] ); ?></h3><?php if ( $item['description'] ) : ?><p><?php echo esc_html( $item['description'] ); ?></p><?php endif; ?></div></li>
											<?php endforeach; ?>
										</ol>
									</div>
								</section>
							<?php endforeach; ?>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</section>
		<?php endif; ?>

		<?php if ( ! empty( $content['process'] ) ) : ?>
		<section id="service-process" class="ts-service-process ts-service-section" aria-labelledby="ts-service-process-title" data-signal-label="<?php esc_attr_e( 'Metodo', 'telecomsecurity-child-theme' ); ?>" data-signal-theme="dark">
			<div class="ts-service-shell">
				<div class="ts-service-section__heading"><p class="ts-service-section__number" aria-hidden="true">02</p><h2 id="ts-service-process-title"><?php esc_html_e( 'Come lavoriamo', 'telecomsecurity-child-theme' ); ?></h2></div>
				<ol class="ts-service-process__steps ts-service-reveal" data-service-reveal><?php foreach ( $content['process'] as $index => $item ) : ?><li><span><?php echo esc_html( sprintf( '%02d', $index + 1 ) ); ?></span><h3><?php echo esc_html( $item['title'] ); ?></h3><?php if ( $item['description'] ) : ?><p><?php echo esc_html( $item['description'] ); ?></p><?php endif; ?></li><?php endforeach; ?></ol>
			</div>
		</section>
		<?php endif; ?>

		<?php if ( $has_contact ) : ?>
		<section id="service-contact" class="ts-service-contact ts-service-section" data-signal-label="<?php esc_attr_e( 'FAQ e contatto', 'telecomsecurity-child-theme' ); ?>">
			<div class="ts-service-shell ts-service-contact__layout ts-service-reveal" data-service-reveal>
				<?php if ( ! empty( $content['faqs'] ) ) : ?>
					<div class="ts-service-faq">
						<div class="ts-service-section__heading"><p class="ts-service-section__number" aria-hidden="true">03</p><h2 id="ts-service-faq-title"><?php esc_html_e( 'Domande frequenti', 'telecomsecurity-child-theme' ); ?></h2></div>
						<div class="ts-service-faq__items"><?php foreach ( array_slice( $content['faqs'], 0, 3 ) as $index => $faq ) : ?><details class="ts-service-faq__item"<?php echo 0 === $index ? ' open' : ''; ?>><summary><span><?php echo esc_html( $faq['question'] ); ?></span><span class="ts-service-faq__icon" aria-hidden="true"></span></summary><div><?php echo wp_kses_post( telecomsecurity_service_text( $faq['answer'] ) ); ?></div></details><?php endforeach; ?></div>
					</div>
				<?php endif; ?>
				<?php if ( $content['cta_title'] || $content['cta_text'] ) : ?>
					<aside class="ts-service-cta" aria-label="<?php esc_attr_e( 'Parliamo del progetto', 'telecomsecurity-child-theme' ); ?>">
						<p class="ts-service-kicker"><?php esc_html_e( 'Parliamo del progetto', 'telecomsecurity-child-theme' ); ?></p>
						<?php if ( $content['cta_title'] ) : ?><h2 id="ts-service-cta-title"><?php echo esc_html( $content['cta_title'] ); ?></h2><?php endif; ?>
						<?php if ( $content['cta_text'] ) : ?><div class="ts-service-cta__text"><?php echo wp_kses_post( telecomsecurity_service_text( $content['cta_text'] ) ); ?></div><?php endif; ?>
						<?php if ( $content['cta_url'] ) : ?><a class="ts-service-link ts-service-link--light" href="<?php echo esc_url( $content['cta_url'] ); ?>"><?php esc_html_e( 'Richiedi una consulenza', 'telecomsecurity-child-theme' ); ?><span aria-hidden="true">→</span></a><?php endif; ?>
					</aside>
				<?php endif; ?>
			</div>
		</section>
		<?php endif; ?>

		<?php if ( ! empty( $related ) || $has_final_nav ) : ?>
		<section id="service-related" class="ts-service-related ts-service-section" aria-labelledby="ts-service-related-title" data-signal-label="<?php esc_attr_e( 'Servizi correlati', 'telecomsecurity-child-theme' ); ?>">
			<div class="ts-service-shell ts-service-reveal" data-service-reveal>
				<?php if ( ! empty( $related ) ) : ?>
					<div class="ts-service-related__heading"><h2 id="ts-service-related-title"><?php esc_html_e( 'Servizi correlati', 'telecomsecurity-child-theme' ); ?></h2><?php if ( $archive_url ) : ?><a href="<?php echo esc_url( $archive_url ); ?>"><?php esc_html_e( 'Tutti i servizi', 'telecomsecurity-child-theme' ); ?> <span aria-hidden="true">→</span></a><?php endif; ?></div>
					<ul class="ts-service-related__list"><?php foreach ( $related as $item ) : $related_image = absint( $item['image_id'] ?? 0 ); ?><li><a href="<?php echo esc_url( $item['url'] ); ?>"><?php if ( $related_image ) : ?><span class="ts-service-related__media"><?php echo wp_get_attachment_image( $related_image, 'medium_large', false, array( 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '(max-width: 767px) calc(100vw - 40px), 31vw' ) ); ?></span><?php endif; ?><span class="ts-service-related__meta"><span class="ts-service-code"><?php echo esc_html( $item['index'] . ' / ' . $item['total'] ); ?></span><strong><?php echo esc_html( $item['title'] ); ?></strong><span aria-hidden="true">↗</span></span></a></li><?php endforeach; ?></ul>
				<?php else : ?><h2 id="ts-service-related-title" class="screen-reader-text"><?php esc_html_e( 'Navigazione servizi', 'telecomsecurity-child-theme' ); ?></h2><?php endif; ?>

				<?php if ( $has_final_nav ) : ?>
				<nav class="ts-service-pagination" aria-label="<?php esc_attr_e( 'Navigazione tra i servizi', 'telecomsecurity-child-theme' ); ?>">
					<?php if ( ! empty( $service_context['previous'] ) ) : ?><a class="is-previous" href="<?php echo esc_url( $service_context['previous']['url'] ); ?>"><span aria-hidden="true">←</span><span><small><?php esc_html_e( 'Servizio precedente', 'telecomsecurity-child-theme' ); ?></small><strong><?php echo esc_html( $service_context['previous']['title'] ); ?></strong></span></a><?php else : ?><span></span><?php endif; ?>
					<?php if ( $archive_url ) : ?><a class="ts-service-pagination__archive" href="<?php echo esc_url( $archive_url ); ?>"><?php esc_html_e( 'Indice servizi', 'telecomsecurity-child-theme' ); ?></a><?php endif; ?>
					<?php if ( ! empty( $service_context['next'] ) ) : ?><a class="is-next" href="<?php echo esc_url( $service_context['next']['url'] ); ?>"><span><small><?php esc_html_e( 'Servizio successivo', 'telecomsecurity-child-theme' ); ?></small><strong><?php echo esc_html( $service_context['next']['title'] ); ?></strong></span><span aria-hidden="true">→</span></a><?php else : ?><span></span><?php endif; ?>
				</nav>
				<?php endif; ?>
			</div>
		</section>
		<?php endif; ?>
	</article>
</main>
