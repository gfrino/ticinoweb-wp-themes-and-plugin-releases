<?php
/**
 * Dedicated contact page.
 *
 * @package TelecomSecurityChild
 */

defined( 'ABSPATH' ) || exit;

$contact       = telecomsecurity_contact_data();
$request_types = telecomsecurity_contact_request_types();
$properties    = telecomsecurity_contact_property_types();
$services      = telecomsecurity_contact_services();
$result        = telecomsecurity_contact_submission_result();
$source        = telecomsecurity_contact_submission_source();
$success       = is_array( $result ) && ! empty( $result['sent'] );
$error_data    = is_wp_error( $result ) && is_array( $result->get_error_data() ) ? $result->get_error_data() : array();
$field_errors  = is_array( $error_data['fields'] ?? null ) ? $error_data['fields'] : array();
$selected_type = isset( $source['ts_contact_request_type'] ) && is_scalar( $source['ts_contact_request_type'] ) ? (string) $source['ts_contact_request_type'] : '';
$security      = telecomsecurity_contact_security_fields();

$old = static function ( string $name ) use ( $source ): string {
	$key = 'ts_contact_' . $name;
	return isset( $source[ $key ] ) && is_scalar( $source[ $key ] ) ? (string) $source[ $key ] : '';
};
$error = static function ( string $name ) use ( $field_errors ): string {
	return isset( $field_errors[ $name ] ) && is_scalar( $field_errors[ $name ] ) ? (string) $field_errors[ $name ] : '';
};
$group_active = static function ( string $group ) use ( $selected_type ): bool {
	$groups = array(
		'new_system'  => array( 'service', 'property', 'location', 'attachment' ),
		'support'     => array( 'customer', 'service', 'location', 'attachment' ),
		'maintenance' => array( 'customer', 'service', 'location', 'attachment' ),
		'general'     => array(),
	);
	return in_array( $group, $groups[ $selected_type ] ?? array(), true );
};
$technical_type = in_array( $selected_type, array( 'new_system', 'support', 'maintenance' ), true );
?>
<main id="primary-content" class="ts-contact">
	<section class="ts-contact-hero" aria-labelledby="ts-contact-title">
		<div class="ts-container ts-contact-hero__inner">
			<p class="ts-contact-hero__label"><?php echo esc_html( $contact['hero_label'] ); ?></p>
			<h1 id="ts-contact-title"><?php echo esc_html( $contact['hero_title'] ); ?></h1>
			<p class="ts-contact-hero__intro"><?php echo esc_html( $contact['hero_text'] ); ?></p>
			<span class="ts-contact-hero__signal" aria-hidden="true"></span>
		</div>
	</section>

	<section class="ts-contact-workspace" aria-labelledby="ts-contact-form-title">
		<div class="ts-container ts-contact-workspace__grid">
			<div class="ts-contact-form-shell" data-contact-form-shell>
				<header class="ts-contact-form-shell__header">
					<p class="ts-contact-kicker"><?php esc_html_e( 'RICHIESTA', 'telecomsecurity-child-theme' ); ?></p>
					<h2 id="ts-contact-form-title"><?php esc_html_e( 'Come possiamo aiutarti?', 'telecomsecurity-child-theme' ); ?></h2>
					<p><?php esc_html_e( 'Seleziona il tipo di richiesta e compila solamente le informazioni necessarie.', 'telecomsecurity-child-theme' ); ?></p>
				</header>

				<div class="ts-contact-success" data-contact-success aria-live="polite" tabindex="-1"<?php echo $success ? '' : ' hidden'; ?>>
					<p class="ts-contact-kicker"><?php esc_html_e( 'INVIO COMPLETATO', 'telecomsecurity-child-theme' ); ?></p>
					<h2><?php esc_html_e( 'Richiesta ricevuta.', 'telecomsecurity-child-theme' ); ?></h2>
					<p><?php esc_html_e( 'Grazie per averci contattato. Le informazioni sono state inoltrate al referente più adatto.', 'telecomsecurity-child-theme' ); ?></p>
					<dl class="ts-contact-success__summary">
						<div><dt><?php esc_html_e( 'Richiesta', 'telecomsecurity-child-theme' ); ?></dt><dd data-contact-success-type><?php echo esc_html( $success ? $result['request_type_label'] : '' ); ?></dd></div>
						<div data-contact-success-service-row<?php echo $success && ! empty( $result['service_label'] ) ? '' : ' hidden'; ?>><dt><?php esc_html_e( 'Servizio', 'telecomsecurity-child-theme' ); ?></dt><dd data-contact-success-service><?php echo esc_html( $success ? $result['service_label'] : '' ); ?></dd></div>
						<div><dt><?php esc_html_e( 'Email', 'telecomsecurity-child-theme' ); ?></dt><dd data-contact-success-email><?php echo esc_html( $success ? $result['email'] : '' ); ?></dd></div>
					</dl>
					<div class="ts-contact-success__actions">
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Torna alla Home', 'telecomsecurity-child-theme' ); ?></a>
						<button type="button" data-contact-new-request><?php esc_html_e( 'Invia una nuova richiesta', 'telecomsecurity-child-theme' ); ?></button>
						<noscript><a href="<?php echo esc_url( get_permalink() ); ?>"><?php esc_html_e( 'Invia una nuova richiesta', 'telecomsecurity-child-theme' ); ?></a></noscript>
					</div>
				</div>

				<form class="ts-contact-form" data-ts-contact-form action="<?php echo esc_url( get_permalink() ); ?>" method="post" enctype="multipart/form-data" novalidate<?php echo $success ? ' hidden' : ''; ?>>
					<div class="ts-contact-error-summary" data-contact-error-summary role="alert" tabindex="-1"<?php echo is_wp_error( $result ) ? '' : ' hidden'; ?>>
						<strong><?php esc_html_e( 'Controlla la richiesta', 'telecomsecurity-child-theme' ); ?></strong>
						<p data-contact-error-summary-text><?php echo is_wp_error( $result ) ? esc_html( $result->get_error_message() ) : ''; ?></p>
						<?php if ( is_wp_error( $result ) && 'mail' === $result->get_error_code() ) : ?>
							<p><?php esc_html_e( 'Puoi usare i recapiti nel pannello Contatto diretto per raggiungerci subito.', 'telecomsecurity-child-theme' ); ?></p>
						<?php endif; ?>
					</div>

					<fieldset class="ts-contact-request-types">
						<legend tabindex="-1"><?php esc_html_e( 'Di cosa hai bisogno?', 'telecomsecurity-child-theme' ); ?> <span aria-hidden="true">*</span></legend>
						<div class="ts-contact-request-types__grid">
							<?php foreach ( $request_types as $value => $type ) : ?>
								<label class="ts-contact-request-option" for="ts-contact-type-<?php echo esc_attr( $value ); ?>">
									<input id="ts-contact-type-<?php echo esc_attr( $value ); ?>" type="radio" name="ts_contact_request_type" value="<?php echo esc_attr( $value ); ?>" aria-describedby="ts-contact-error-request-type"<?php checked( $selected_type, $value ); ?> required>
									<span aria-hidden="true"></span>
									<strong><?php echo esc_html( $type['label'] ); ?></strong>
								</label>
							<?php endforeach; ?>
						</div>
						<span id="ts-contact-error-request-type" class="ts-contact-field-error" data-contact-error="request_type"<?php echo $error( 'request_type' ) ? '' : ' hidden'; ?>><?php echo esc_html( $error( 'request_type' ) ); ?></span>
					</fieldset>

					<div class="ts-contact-form__grid">
						<div class="ts-contact-field">
							<label for="ts-contact-name"><?php esc_html_e( 'Nome e cognome', 'telecomsecurity-child-theme' ); ?> <span aria-hidden="true">*</span></label>
							<input id="ts-contact-name" name="ts_contact_name" type="text" autocomplete="name" maxlength="120" value="<?php echo esc_attr( $old( 'name' ) ); ?>" aria-describedby="ts-contact-error-name"<?php echo $error( 'name' ) ? ' aria-invalid="true"' : ''; ?> required>
							<span id="ts-contact-error-name" class="ts-contact-field-error" data-contact-error="name"<?php echo $error( 'name' ) ? '' : ' hidden'; ?>><?php echo esc_html( $error( 'name' ) ); ?></span>
						</div>
						<div class="ts-contact-field">
							<label for="ts-contact-company"><?php esc_html_e( 'Azienda', 'telecomsecurity-child-theme' ); ?> <small><?php esc_html_e( 'facoltativo', 'telecomsecurity-child-theme' ); ?></small></label>
							<input id="ts-contact-company" name="ts_contact_company" type="text" autocomplete="organization" maxlength="160" value="<?php echo esc_attr( $old( 'company' ) ); ?>" aria-describedby="ts-contact-error-company"<?php echo $error( 'company' ) ? ' aria-invalid="true"' : ''; ?>>
							<span id="ts-contact-error-company" class="ts-contact-field-error" data-contact-error="company"<?php echo $error( 'company' ) ? '' : ' hidden'; ?>><?php echo esc_html( $error( 'company' ) ); ?></span>
						</div>
						<div class="ts-contact-field">
							<label for="ts-contact-email"><?php esc_html_e( 'Email', 'telecomsecurity-child-theme' ); ?> <span aria-hidden="true">*</span></label>
							<input id="ts-contact-email" name="ts_contact_email" type="email" autocomplete="email" maxlength="190" value="<?php echo esc_attr( $old( 'email' ) ); ?>" aria-describedby="ts-contact-error-email"<?php echo $error( 'email' ) ? ' aria-invalid="true"' : ''; ?> required>
							<span id="ts-contact-error-email" class="ts-contact-field-error" data-contact-error="email"<?php echo $error( 'email' ) ? '' : ' hidden'; ?>><?php echo esc_html( $error( 'email' ) ); ?></span>
						</div>
						<div class="ts-contact-field">
							<label for="ts-contact-phone"><?php esc_html_e( 'Telefono', 'telecomsecurity-child-theme' ); ?> <small><?php esc_html_e( 'obbligatorio per richieste tecniche', 'telecomsecurity-child-theme' ); ?></small></label>
							<input id="ts-contact-phone" name="ts_contact_phone" type="tel" autocomplete="tel" maxlength="50" value="<?php echo esc_attr( $old( 'phone' ) ); ?>" aria-describedby="ts-contact-error-phone" aria-required="<?php echo $technical_type ? 'true' : 'false'; ?>"<?php echo $technical_type ? ' required' : ''; ?><?php echo $error( 'phone' ) ? ' aria-invalid="true"' : ''; ?>>
							<span id="ts-contact-error-phone" class="ts-contact-field-error" data-contact-error="phone"<?php echo $error( 'phone' ) ? '' : ' hidden'; ?>><?php echo esc_html( $error( 'phone' ) ); ?></span>
						</div>
					</div>

					<fieldset class="ts-contact-conditional ts-contact-customer" data-contact-group="customer" aria-hidden="<?php echo $group_active( 'customer' ) ? 'false' : 'true'; ?>"<?php echo $group_active( 'customer' ) ? '' : ' hidden'; ?>>
						<legend><?php esc_html_e( 'Sei già cliente?', 'telecomsecurity-child-theme' ); ?> <span aria-hidden="true">*</span></legend>
						<div class="ts-contact-inline-options">
							<label for="ts-contact-customer-yes"><input id="ts-contact-customer-yes" type="radio" name="ts_contact_existing_customer" value="yes" aria-describedby="ts-contact-error-existing-customer"<?php checked( $old( 'existing_customer' ), 'yes' ); ?><?php echo $group_active( 'customer' ) ? '' : ' disabled'; ?> required> <?php esc_html_e( 'Sì', 'telecomsecurity-child-theme' ); ?></label>
							<label for="ts-contact-customer-no"><input id="ts-contact-customer-no" type="radio" name="ts_contact_existing_customer" value="no" aria-describedby="ts-contact-error-existing-customer"<?php checked( $old( 'existing_customer' ), 'no' ); ?><?php echo $group_active( 'customer' ) ? '' : ' disabled'; ?> required> <?php esc_html_e( 'No', 'telecomsecurity-child-theme' ); ?></label>
						</div>
						<span id="ts-contact-error-existing-customer" class="ts-contact-field-error" data-contact-error="existing_customer"<?php echo $error( 'existing_customer' ) ? '' : ' hidden'; ?>><?php echo esc_html( $error( 'existing_customer' ) ); ?></span>
					</fieldset>

					<div class="ts-contact-conditional ts-contact-field" data-contact-group="service" aria-hidden="<?php echo $group_active( 'service' ) ? 'false' : 'true'; ?>"<?php echo $group_active( 'service' ) ? '' : ' hidden'; ?>>
						<label for="ts-contact-service"><?php esc_html_e( 'Servizio o impianto interessato', 'telecomsecurity-child-theme' ); ?> <span aria-hidden="true">*</span></label>
						<select id="ts-contact-service" name="ts_contact_service" aria-describedby="ts-contact-error-service"<?php echo $group_active( 'service' ) ? ' required' : ' disabled'; ?><?php echo $error( 'service' ) ? ' aria-invalid="true"' : ''; ?>>
							<option value=""><?php esc_html_e( 'Seleziona', 'telecomsecurity-child-theme' ); ?></option>
							<option value="advice"<?php selected( $old( 'service' ), 'advice' ); ?>><?php esc_html_e( 'Non sono sicuro / Vorrei un consiglio', 'telecomsecurity-child-theme' ); ?></option>
							<?php foreach ( $services as $service ) : ?>
								<option value="<?php echo esc_attr( $service['id'] ); ?>"<?php selected( $old( 'service' ), $service['id'] ); ?>><?php echo esc_html( $service['title'] ); ?></option>
							<?php endforeach; ?>
						</select>
						<span id="ts-contact-error-service" class="ts-contact-field-error" data-contact-error="service"<?php echo $error( 'service' ) ? '' : ' hidden'; ?>><?php echo esc_html( $error( 'service' ) ); ?></span>
					</div>

					<div class="ts-contact-conditional ts-contact-field" data-contact-group="property" aria-hidden="<?php echo $group_active( 'property' ) ? 'false' : 'true'; ?>"<?php echo $group_active( 'property' ) ? '' : ' hidden'; ?>>
						<label for="ts-contact-property"><?php esc_html_e( 'Tipo di immobile', 'telecomsecurity-child-theme' ); ?> <span aria-hidden="true">*</span></label>
						<select id="ts-contact-property" name="ts_contact_property_type" aria-describedby="ts-contact-error-property-type"<?php echo $group_active( 'property' ) ? ' required' : ' disabled'; ?><?php echo $error( 'property_type' ) ? ' aria-invalid="true"' : ''; ?>>
							<option value=""><?php esc_html_e( 'Seleziona', 'telecomsecurity-child-theme' ); ?></option>
							<?php foreach ( $properties as $value => $label ) : ?>
								<option value="<?php echo esc_attr( $value ); ?>"<?php selected( $old( 'property_type' ), $value ); ?>><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select>
						<span id="ts-contact-error-property-type" class="ts-contact-field-error" data-contact-error="property_type"<?php echo $error( 'property_type' ) ? '' : ' hidden'; ?>><?php echo esc_html( $error( 'property_type' ) ); ?></span>
					</div>

					<div class="ts-contact-conditional ts-contact-field" data-contact-group="location" aria-hidden="<?php echo $group_active( 'location' ) ? 'false' : 'true'; ?>"<?php echo $group_active( 'location' ) ? '' : ' hidden'; ?>>
						<label for="ts-contact-location"><?php esc_html_e( 'Località dell’intervento', 'telecomsecurity-child-theme' ); ?> <span aria-hidden="true">*</span></label>
						<input id="ts-contact-location" name="ts_contact_location" type="text" maxlength="160" value="<?php echo esc_attr( $old( 'location' ) ); ?>" aria-describedby="ts-contact-error-location"<?php echo $group_active( 'location' ) ? ' required' : ' disabled'; ?><?php echo $error( 'location' ) ? ' aria-invalid="true"' : ''; ?>>
						<span id="ts-contact-error-location" class="ts-contact-field-error" data-contact-error="location"<?php echo $error( 'location' ) ? '' : ' hidden'; ?>><?php echo esc_html( $error( 'location' ) ); ?></span>
					</div>

					<div class="ts-contact-field ts-contact-field--full">
						<label for="ts-contact-message"><?php esc_html_e( 'Messaggio', 'telecomsecurity-child-theme' ); ?> <span aria-hidden="true">*</span></label>
						<textarea id="ts-contact-message" name="ts_contact_message" rows="7" maxlength="5000" aria-describedby="ts-contact-message-note ts-contact-error-message"<?php echo $error( 'message' ) ? ' aria-invalid="true"' : ''; ?> required><?php echo esc_textarea( $old( 'message' ) ); ?></textarea>
						<p id="ts-contact-message-note" class="ts-contact-field-note"><?php esc_html_e( 'Per la tua sicurezza, non inserire password, codici di accesso o altre informazioni riservate relative all’impianto.', 'telecomsecurity-child-theme' ); ?></p>
						<span id="ts-contact-error-message" class="ts-contact-field-error" data-contact-error="message"<?php echo $error( 'message' ) ? '' : ' hidden'; ?>><?php echo esc_html( $error( 'message' ) ); ?></span>
					</div>

					<div class="ts-contact-conditional ts-contact-field ts-contact-upload" data-contact-group="attachment" aria-hidden="<?php echo $group_active( 'attachment' ) ? 'false' : 'true'; ?>"<?php echo $group_active( 'attachment' ) ? '' : ' hidden'; ?>>
						<label for="ts-contact-attachment"><?php esc_html_e( 'Allegato', 'telecomsecurity-child-theme' ); ?> <small><?php esc_html_e( 'facoltativo · massimo 8 MB', 'telecomsecurity-child-theme' ); ?></small></label>
						<input id="ts-contact-attachment" name="ts_contact_attachment" type="file" accept="application/pdf,image/jpeg,image/png,.pdf,.jpg,.jpeg,.png" aria-describedby="ts-contact-attachment-note ts-contact-error-attachment"<?php echo $group_active( 'attachment' ) ? '' : ' disabled'; ?>>
						<p id="ts-contact-attachment-note" class="ts-contact-field-note"><?php esc_html_e( 'Allega eventualmente una fotografia o un documento utile. Non caricare password, codici o informazioni sensibili.', 'telecomsecurity-child-theme' ); ?></p>
						<span id="ts-contact-error-attachment" class="ts-contact-field-error" data-contact-error="attachment"<?php echo $error( 'attachment' ) ? '' : ' hidden'; ?>><?php echo esc_html( $error( 'attachment' ) ); ?></span>
					</div>

					<div class="ts-contact-privacy">
						<input id="ts-contact-privacy" name="ts_contact_privacy" type="checkbox" value="1" aria-describedby="ts-contact-error-privacy"<?php checked( $old( 'privacy' ), '1' ); ?><?php echo $error( 'privacy' ) ? ' aria-invalid="true"' : ''; ?> required>
						<label for="ts-contact-privacy">
							<?php esc_html_e( 'Ho letto l’informativa sulla privacy e acconsento al trattamento dei dati necessari per rispondere alla richiesta.', 'telecomsecurity-child-theme' ); ?>
							<?php if ( ! empty( $contact['privacy_url'] ) ) : ?><a href="<?php echo esc_url( $contact['privacy_url'] ); ?>"><?php esc_html_e( 'Leggi l’informativa', 'telecomsecurity-child-theme' ); ?></a><?php endif; ?>
						</label>
						<span id="ts-contact-error-privacy" class="ts-contact-field-error" data-contact-error="privacy"<?php echo $error( 'privacy' ) ? '' : ' hidden'; ?>><?php echo esc_html( $error( 'privacy' ) ); ?></span>
					</div>

					<div class="ts-contact-honeypot" aria-hidden="true">
						<label for="ts-contact-website"><?php esc_html_e( 'Lascia vuoto questo campo', 'telecomsecurity-child-theme' ); ?></label>
						<input id="ts-contact-website" name="ts_contact_website" type="text" tabindex="-1" autocomplete="off" value="">
					</div>
					<input type="hidden" name="ts_contact_submit" value="1">
					<input type="hidden" name="ts_contact_nonce" value="<?php echo esc_attr( wp_create_nonce( 'telecomsecurity_contact_submit' ) ); ?>">
					<input type="hidden" name="ts_contact_started" value="<?php echo esc_attr( $security['ts_contact_started'] ); ?>">
					<input type="hidden" name="ts_contact_started_signature" value="<?php echo esc_attr( $security['ts_contact_started_signature'] ); ?>">

					<button class="ts-contact-submit" type="submit" data-contact-submit data-default-label="<?php esc_attr_e( 'Invia la richiesta', 'telecomsecurity-child-theme' ); ?>" data-loading-label="<?php esc_attr_e( 'Invio in corso…', 'telecomsecurity-child-theme' ); ?>" aria-busy="false">
						<span data-contact-submit-label><?php esc_html_e( 'Invia la richiesta', 'telecomsecurity-child-theme' ); ?></span>
						<span aria-hidden="true">→</span>
					</button>
				</form>
			</div>

			<aside class="ts-contact-panel" aria-labelledby="ts-contact-direct-title">
				<p class="ts-contact-kicker"><?php esc_html_e( 'SEMENTINA', 'telecomsecurity-child-theme' ); ?></p>
				<h2 id="ts-contact-direct-title"><?php esc_html_e( 'Contatto diretto', 'telecomsecurity-child-theme' ); ?></h2>
				<p class="ts-contact-panel__intro"><?php esc_html_e( 'Per parlare direttamente con la nostra sede, utilizza uno dei recapiti qui sotto.', 'telecomsecurity-child-theme' ); ?></p>
				<address class="ts-contact-panel__details">
					<div><span><?php esc_html_e( 'Sede', 'telecomsecurity-child-theme' ); ?></span><strong><?php echo esc_html( $contact['company'] ); ?></strong><p><?php echo esc_html( $contact['address'] ); ?></p></div>
					<?php if ( ! empty( $contact['phone'] ) ) : ?><div><span><?php esc_html_e( 'Telefono', 'telecomsecurity-child-theme' ); ?></span><a href="tel:<?php echo esc_attr( $contact['phone_href'] ); ?>"><?php echo esc_html( $contact['phone'] ); ?></a></div><?php endif; ?>
					<?php if ( ! empty( $contact['email'] ) ) : ?><div><span><?php esc_html_e( 'Email', 'telecomsecurity-child-theme' ); ?></span><a href="mailto:<?php echo esc_attr( antispambot( $contact['email'] ) ); ?>"><?php echo esc_html( antispambot( $contact['email'] ) ); ?></a></div><?php endif; ?>
					<?php if ( ! empty( $contact['hours'] ) || ! empty( $contact['hours_note'] ) ) : ?>
						<div><span><?php esc_html_e( 'Orari', 'telecomsecurity-child-theme' ); ?></span>
							<?php foreach ( (array) $contact['hours'] as $day => $day_data ) : ?>
								<?php $formatted = function_exists( 'ticinoweb_format_day_hours' ) ? ticinoweb_format_day_hours( $day_data ) : ''; ?>
								<?php if ( '' !== $formatted ) : ?><p><?php echo esc_html( ucfirst( (string) $day ) . ': ' . $formatted ); ?></p><?php endif; ?>
							<?php endforeach; ?>
							<?php if ( ! empty( $contact['hours_note'] ) ) : ?><p><?php echo esc_html( $contact['hours_note'] ); ?></p><?php endif; ?>
						</div>
					<?php endif; ?>
				</address>
				<?php if ( ! empty( $contact['directions_url'] ) ) : ?>
					<a class="ts-contact-panel__directions" href="<?php echo esc_url( $contact['directions_url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Apri le indicazioni', 'telecomsecurity-child-theme' ); ?> <span aria-hidden="true">↗</span></a>
				<?php endif; ?>
			</aside>
		</div>
	</section>
</main>
