<?php
/**
 * Editorial TeleNews archive backed by standard WordPress posts.
 *
 * @package TelecomSecurityChild
 */

defined( 'ABSPATH' ) || exit;

$paged = max( 1, absint( get_query_var( 'paged' ) ), absint( get_query_var( 'page' ) ) );
$news_query = new WP_Query(
	array(
		'post_type'      => 'post',
		'post_status'    => 'publish',
		'posts_per_page' => 6,
		'paged'          => $paged,
		'orderby'        => 'date',
		'order'          => 'DESC',
		'ignore_sticky_posts' => true,
	)
);
?>
<main id="primary-content" class="ts-telenews" data-telenews-root>
	<section class="ts-telenews-hero" data-signal-label="<?php esc_attr_e( 'TeleNews', 'telecomsecurity-child-theme' ); ?>" data-signal-theme="light" aria-labelledby="ts-telenews-title">
		<div class="ts-container ts-telenews-hero__inner">
			<p class="ts-telenews-kicker"><span aria-hidden="true"></span><?php esc_html_e( 'TELENEWS', 'telecomsecurity-child-theme' ); ?></p>
			<h1 id="ts-telenews-title"><?php esc_html_e( 'Progetti, soluzioni e aggiornamenti', 'telecomsecurity-child-theme' ); ?></h1>
			<p><?php esc_html_e( 'Uno spazio dedicato agli interventi, alle tecnologie e alle soluzioni sviluppate da Telecom Security per proteggere persone, edifici e attività.', 'telecomsecurity-child-theme' ); ?></p>
		</div>
	</section>

	<section class="ts-telenews-feed" aria-labelledby="ts-telenews-feed-title">
		<div class="ts-container">
			<header class="ts-telenews-feed__header">
				<h2 id="ts-telenews-feed-title"><?php esc_html_e( 'Dal progetto al lavoro sul campo.', 'telecomsecurity-child-theme' ); ?></h2>
				<p><?php esc_html_e( 'Approfondimenti tecnici raccontati con chiarezza, partendo dalle esigenze reali degli spazi.', 'telecomsecurity-child-theme' ); ?></p>
			</header>

			<?php if ( $news_query->have_posts() ) : ?>
				<div class="ts-telenews-list">
					<?php $position = 0; ?>
					<?php while ( $news_query->have_posts() ) : $news_query->the_post(); ?>
						<?php
						$post_id       = get_the_ID();
						$is_featured   = 0 === $position;
						$is_medium     = $position >= 1 && $position <= 2;
						$is_compact    = $position >= 3;
						$show_excerpt  = ! $is_compact;
						$layout_class  = $is_featured ? ' is-featured' : ( $is_medium ? ' is-medium' : ' is-compact' );
						$image_sizes   = $is_featured
							? '(max-width: 899px) calc(100vw - 40px), (max-width: 1379px) 55vw, 720px'
							: ( $is_medium
								? '(max-width: 767px) calc(100vw - 40px), (max-width: 1379px) calc(50vw - 44px), 620px'
								: '(max-width: 767px) calc(100vw - 40px), (max-width: 899px) calc(50vw - 44px), 410px' );
						?>
						<article <?php post_class( 'ts-telenews-card' . $layout_class ); ?> data-telenews-reveal>
							<a class="ts-telenews-card__media" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
								<?php telecomsecurity_render_post_cover( $post_id, 'ts-telenews-card__image', $image_sizes, $is_featured ); ?>
							</a>
							<div class="ts-telenews-card__body">
								<?php if ( $is_featured ) : ?>
									<span class="ts-telenews-card__eyebrow"><?php esc_html_e( 'In evidenza', 'telecomsecurity-child-theme' ); ?></span>
								<?php endif; ?>
								<div class="ts-telenews-card__meta">
									<span><?php echo esc_html( telecomsecurity_get_post_category_label( $post_id ) ); ?></span>
									<time datetime="<?php echo esc_attr( get_the_date( DATE_W3C ) ); ?>"><?php echo esc_html( get_the_date( 'j F Y' ) ); ?></time>
								</div>
								<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
								<?php if ( $show_excerpt ) : ?>
									<p><?php echo esc_html( telecomsecurity_get_post_summary( $post_id ) ); ?></p>
								<?php endif; ?>
								<a class="ts-telenews-card__link" href="<?php the_permalink(); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Approfondisci: %s', 'telecomsecurity-child-theme' ), get_the_title() ) ); ?>">
									<span><?php esc_html_e( 'Approfondisci', 'telecomsecurity-child-theme' ); ?></span><span aria-hidden="true">→</span>
								</a>
							</div>
						</article>
						<?php ++$position; ?>
					<?php endwhile; ?>
				</div>

				<?php if ( $news_query->max_num_pages > 1 ) : ?>
					<nav class="ts-telenews-pagination" aria-label="<?php esc_attr_e( 'Pagine TeleNews', 'telecomsecurity-child-theme' ); ?>">
						<?php
						echo wp_kses_post(
							paginate_links(
								array(
									'current'   => $paged,
									'total'     => (int) $news_query->max_num_pages,
									'mid_size'  => 1,
									'prev_text' => '<span aria-hidden="true">←</span> ' . __( 'Precedente', 'telecomsecurity-child-theme' ),
									'next_text' => __( 'Successiva', 'telecomsecurity-child-theme' ) . ' <span aria-hidden="true">→</span>',
									'type'      => 'list',
								)
							)
						);
						?>
					</nav>
				<?php endif; ?>
			<?php else : ?>
				<div class="ts-telenews-empty" role="status">
					<span aria-hidden="true">TS</span>
					<h2><?php esc_html_e( 'I prossimi aggiornamenti sono in preparazione.', 'telecomsecurity-child-theme' ); ?></h2>
					<p><?php esc_html_e( 'Stiamo raccogliendo progetti e approfondimenti da condividere in questa sezione.', 'telecomsecurity-child-theme' ); ?></p>
					<a href="<?php echo esc_url( telecomsecurity_get_consultation_url() ); ?>"><?php esc_html_e( 'Parlateci della vostra esigenza', 'telecomsecurity-child-theme' ); ?> <span aria-hidden="true">→</span></a>
				</div>
			<?php endif; ?>
			<?php wp_reset_postdata(); ?>
		</div>
	</section>
</main>
