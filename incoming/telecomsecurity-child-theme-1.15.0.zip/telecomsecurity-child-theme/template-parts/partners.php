<?php
/**
 * Sezione partner condivisa tra Home e Chi siamo.
 *
 * I loghi, l'ordine e i link provengono dall'unica configurazione partner del
 * CMS ticinoWEB. I gruppi aggiuntivi servono esclusivamente al loop visivo.
 *
 * @package TelecomSecurityChild
 */

defined( 'ABSPATH' ) || exit;

$partners = telecomsecurity_get_partners_list();
if ( empty( $partners ) ) {
	return;
}
?>

<section class="ts-partners" id="partner" data-signal-label="PARTNER" data-signal-theme="light" aria-labelledby="ts-partners-heading">
	<div class="ts-container">
		<div class="ts-partners__intro">
			<div class="ts-section-tag">
				<span class="ts-signal-line" aria-hidden="true"></span>
				<span><?php esc_html_e( 'Collaborazioni Tecnologiche', 'telecomsecurity-child-theme' ); ?></span>
			</div>
			<h2 id="ts-partners-heading" class="ts-partners__headline"><?php esc_html_e( 'Tecnologie e partner', 'telecomsecurity-child-theme' ); ?></h2>
			<p class="ts-partners__sub">
				<?php esc_html_e( 'Selezioniamo componentistica e soluzioni dei marchi leader a livello svizzero e internazionale per garantire standard elevati di affidabilità.', 'telecomsecurity-child-theme' ); ?>
			</p>
		</div>
	</div>

	<div class="ts-partners__marquee" id="ts-partners-marquee">
		<div class="ts-partners__marquee-track">
			<?php for ( $group = 0; $group < 3; $group++ ) : ?>
				<div class="ts-partners__marquee-group"<?php echo $group > 0 ? ' aria-hidden="true"' : ''; ?>>
					<?php foreach ( $partners as $partner ) : ?>
						<div class="ts-partner-card">
							<?php if ( ! empty( $partner['link'] ) ) : ?>
								<a href="<?php echo esc_url( $partner['link'] ); ?>" class="ts-partner-card__link" target="_blank" rel="noopener noreferrer"<?php echo $group > 0 ? ' tabindex="-1"' : ''; ?> aria-label="<?php echo esc_attr( sprintf( __( 'Visita il sito di %s', 'telecomsecurity-child-theme' ), $partner['alt'] ) ); ?>">
									<img src="<?php echo esc_url( $partner['logo'] ); ?>" alt="<?php echo 0 === $group ? esc_attr( $partner['alt'] ) : ''; ?>" class="ts-partner-card__logo" loading="lazy" decoding="async">
								</a>
							<?php else : ?>
								<div class="ts-partner-card__view">
									<img src="<?php echo esc_url( $partner['logo'] ); ?>" alt="<?php echo 0 === $group ? esc_attr( $partner['alt'] ) : ''; ?>" class="ts-partner-card__logo" loading="lazy" decoding="async">
								</div>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endfor; ?>
		</div>
	</div>
</section>
