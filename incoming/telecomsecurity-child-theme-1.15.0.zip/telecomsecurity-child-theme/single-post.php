<?php
/**
 * Single standard post — TeleNews project story.
 *
 * @package TelecomSecurityChild
 */

defined( 'ABSPATH' ) || exit;
get_header();
?>
<main id="primary-content" class="ts-news-single" data-news-single>
	<?php while ( have_posts() ) : the_post(); ?>
		<?php $post_id = get_the_ID(); ?>
		<article <?php post_class( 'ts-news-article' ); ?>>
			<header class="ts-news-article__header" data-signal-label="<?php esc_attr_e( 'TeleNews', 'telecomsecurity-child-theme' ); ?>" data-signal-theme="light">
				<div class="ts-container ts-news-article__header-inner">
					<a class="ts-news-back" href="<?php echo esc_url( telecomsecurity_get_telenews_url() ); ?>"><span aria-hidden="true">←</span> <?php esc_html_e( 'Torna a TeleNews', 'telecomsecurity-child-theme' ); ?></a>
					<p class="ts-news-article__category"><?php echo esc_html( telecomsecurity_get_post_category_label( $post_id ) ); ?></p>
					<h1><?php the_title(); ?></h1>
					<?php $summary = telecomsecurity_get_post_summary( $post_id ); ?>
					<?php if ( $summary ) : ?><p class="ts-news-article__summary"><?php echo esc_html( $summary ); ?></p><?php endif; ?>
					<time datetime="<?php echo esc_attr( get_the_date( DATE_W3C ) ); ?>"><?php echo esc_html( get_the_date( 'j F Y' ) ); ?></time>
				</div>
			</header>

			<figure class="ts-container ts-news-article__cover">
				<?php telecomsecurity_render_post_cover( $post_id, 'ts-news-article__cover-image', '(max-width: 767px) calc(100vw - 40px), (max-width: 1440px) calc(100vw - 80px), 1300px', true ); ?>
			</figure>

			<div class="ts-news-article__content entry-content">
				<?php the_content(); ?>
			</div>

			<section class="ts-news-cta" aria-labelledby="ts-news-cta-title" data-signal-theme="dark">
				<div class="ts-container ts-news-cta__inner">
					<div>
						<p><?php esc_html_e( 'PARLIAMO DEL VOSTRO PROGETTO', 'telecomsecurity-child-theme' ); ?></p>
						<h2 id="ts-news-cta-title"><?php esc_html_e( 'Avete un’esigenza simile?', 'telecomsecurity-child-theme' ); ?></h2>
						<span><?php esc_html_e( 'Partiamo dagli spazi, dalle modalità di utilizzo e dalle necessità reali per progettare una soluzione su misura.', 'telecomsecurity-child-theme' ); ?></span>
					</div>
					<a href="<?php echo esc_url( telecomsecurity_get_consultation_url() ); ?>"><?php esc_html_e( 'Richiedi una consulenza', 'telecomsecurity-child-theme' ); ?> <span aria-hidden="true">→</span></a>
				</div>
			</section>

			<?php
			$previous = get_previous_post();
			$next     = get_next_post();
			?>
			<?php if ( $previous instanceof WP_Post || $next instanceof WP_Post ) : ?>
				<nav class="ts-container ts-news-adjacent" aria-label="<?php esc_attr_e( 'Altri articoli TeleNews', 'telecomsecurity-child-theme' ); ?>">
					<?php if ( $previous instanceof WP_Post ) : ?>
						<a class="ts-news-adjacent__previous" href="<?php echo esc_url( get_permalink( $previous ) ); ?>"><small><span aria-hidden="true">←</span> <?php esc_html_e( 'Articolo precedente', 'telecomsecurity-child-theme' ); ?></small><strong><?php echo esc_html( get_the_title( $previous ) ); ?></strong></a>
					<?php else : ?><span></span><?php endif; ?>
					<?php if ( $next instanceof WP_Post ) : ?>
						<a class="ts-news-adjacent__next" href="<?php echo esc_url( get_permalink( $next ) ); ?>"><small><?php esc_html_e( 'Articolo successivo', 'telecomsecurity-child-theme' ); ?> <span aria-hidden="true">→</span></small><strong><?php echo esc_html( get_the_title( $next ) ); ?></strong></a>
					<?php endif; ?>
				</nav>
			<?php endif; ?>
		</article>
	<?php endwhile; ?>
</main>
<?php get_footer(); ?>

