<?php
/** Shared internal pages, preserving native WordPress content and CMS records. */
defined('ABSPATH') || exit;
$service_context = function_exists( 'telecomsecurity_get_service_context' ) ? telecomsecurity_get_service_context( get_queried_object_id() ) : array();
get_header();

if ( ! empty( $service_context ) ) {
	while ( have_posts() ) {
		the_post();
		get_template_part( 'template-parts/service-single', null, array( 'service_context' => $service_context ) );
	}
	get_footer();
	return;
}

if ( is_page( 'chi-siamo' ) ) {
	while ( have_posts() ) {
		the_post();
		get_template_part( 'template-parts/about-page' );
	}
	get_footer();
	return;
}

if ( is_page( 'contatti' ) ) {
	while ( have_posts() ) {
		the_post();
		get_template_part( 'template-parts/contact-page' );
	}
	get_footer();
	return;
}

if ( is_page( 'telenews' ) ) {
	while ( have_posts() ) {
		the_post();
		get_template_part( 'template-parts/telenews-page' );
	}
	get_footer();
	return;
}

$services = telecomsecurity_get_services_explorer_data();
$current = null;
$service_parent_ids = array();
foreach ($services as $service) {
    if ((int) $service['page_id'] === get_queried_object_id()) $current = $service;
    $parent = wp_get_post_parent_id($service['page_id']);
    if ($parent) $service_parent_ids[] = $parent;
}
$is_services = in_array(get_queried_object_id(), $service_parent_ids, true);
$is_legal = is_page(array('privacy-policy', 'termini-condizioni'));
?>
<main id="primary-content" class="ts-page ts-container<?php echo $is_legal ? ' ts-legal-page' : ''; ?><?php echo $is_services ? ' ts-services-page' : ''; ?>"<?php echo $is_services ? ' data-services-archive' : ''; ?>>
<?php while (have_posts()) : the_post(); ?>
    <article <?php post_class('ts-page-article'); ?>>
        <header class="ts-page-heading">
            <?php echo telecomsecurity_geometry($current ? $current['geometry'] : 'shield'); ?>
            <?php if ($current) : ?><p class="ts-code"><?php echo esc_html($current['index'] . ' / ' . $current['total']); ?></p><?php endif; ?>
            <h1><?php the_title(); ?></h1>
        </header>
        <div class="<?php echo ($current || has_post_thumbnail()) ? 'ts-page-lead' : ''; ?>">
            <div class="entry-content">
                <?php the_content(); ?>
                <?php if ($current) : ?>
                    <div class="ts-service-description"><?php echo wp_kses_post(wpautop($current['description'])); ?></div>
                    <?php $cta = telecomsecurity_get_method_section_data()['final_panel']; ?>
                    <a class="ts-page-link" href="<?php echo esc_url($cta['url']); ?>"><?php echo esc_html($cta['btn_text']); ?> <span aria-hidden="true">→</span></a>
                <?php endif; ?>
            </div>
            <?php if ($current && $current['image']) : ?>
                <figure class="ts-page-photo ts-corners"><?php telecomsecurity_render_service_media($current, 'ts-page-img', true); ?></figure>
            <?php elseif (has_post_thumbnail()) : ?>
                <figure class="ts-page-photo ts-corners"><?php the_post_thumbnail('large'); ?></figure>
            <?php endif; ?>
        </div>
		<?php if ($is_services) : ?>
			<div class="ts-service-viewer" data-services-viewer data-service-total="<?php echo esc_attr(count($services)); ?>" aria-label="<?php esc_attr_e('Visualizzatore dei servizi', 'telecomsecurity-child-theme'); ?>">
				<p class="screen-reader-text" aria-live="polite" aria-atomic="true" data-service-status></p>
				<div class="ts-service-viewer__panels">
			<?php foreach ($services as $service) : ?>
				<?php
				$anchor_id = 'service-' . $service['id'];
				$title_id = 'service-viewer-title-' . $service['id'];
				$is_first = '01' === $service['index'];
				$summary = telecomsecurity_service_summary($service['description']);
				$image_id = absint($service['image_id'] ?? 0);
				$title_length = function_exists('mb_strlen') ? mb_strlen($service['title'], 'UTF-8') : strlen($service['title']);
				$title_class = $title_length >= 56 ? ' is-long-title' : '';
				$image_position = $service['image_position'] ?? '50% 50%';
				?>
				<section id="<?php echo esc_attr($anchor_id); ?>" class="ts-service-viewer__panel<?php echo $is_first ? ' is-active' : ''; ?>" data-service-key="<?php echo esc_attr($service['id']); ?>" data-service-number="<?php echo esc_attr($service['index']); ?>" data-service-total="<?php echo esc_attr($service['total']); ?>" role="region" aria-labelledby="<?php echo esc_attr($title_id); ?>" aria-hidden="<?php echo $is_first ? 'false' : 'true'; ?>"<?php echo $is_first ? '' : ' hidden'; ?>>
					<figure class="ts-service-viewer__media" style="--ts-media-position:<?php echo esc_attr($image_position); ?>">
						<?php if ($service['image']) : ?>
								<?php
								if ($image_id) {
									$image_alt = trim((string) get_post_meta($image_id, '_wp_attachment_image_alt', true));
									echo wp_get_attachment_image($image_id, 'large', false, array('class' => 'ts-service-viewer__image', 'loading' => $is_first ? 'eager' : 'lazy', 'fetchpriority' => $is_first ? 'high' : 'auto', 'decoding' => 'async', 'alt' => $image_alt ?: $service['title'], 'sizes' => '(max-width: 767px) calc(100vw - 40px), (max-width: 1300px) calc(100vw - 80px), 1220px'));
								} else {
									telecomsecurity_render_service_media($service, 'ts-service-viewer__image', $is_first);
								}
								?>
						<?php else : ?>
							<?php telecomsecurity_render_service_media($service, 'ts-service-viewer__image', $is_first); ?>
						<?php endif; ?>
					</figure>
					<div class="ts-service-viewer__info">
						<p class="ts-service-viewer__number"><?php echo esc_html($service['index'] . ' / ' . $service['total']); ?></p>
						<h2 id="<?php echo esc_attr($title_id); ?>" class="ts-service-viewer__title<?php echo esc_attr($title_class); ?>"><?php echo esc_html($service['title']); ?></h2>
						<div class="ts-service-viewer__copy">
							<?php if ($summary) : ?><p><?php echo esc_html($summary); ?></p><?php endif; ?>
							<?php if ($service['url']) : ?><a class="ts-page-link" href="<?php echo esc_url($service['url']); ?>" aria-label="<?php echo esc_attr(sprintf(__('Scopri il servizio: %s', 'telecomsecurity-child-theme'), $service['title'])); ?>"><?php esc_html_e('Scopri il servizio', 'telecomsecurity-child-theme'); ?> <span aria-hidden="true">→</span></a><?php endif; ?>
						</div>
					</div>
				</section>
			<?php endforeach; ?>
				</div>
			</div>
        <?php endif; ?>
        <?php if ($current) : ?>
            <nav class="ts-page-nav" aria-label="<?php esc_attr_e('Altri servizi', 'telecomsecurity-child-theme'); ?>">
                <ul><?php foreach ($services as $service) : if ($service['id'] === $current['id']) continue; ?>
                    <li><a href="<?php echo esc_url($service['url']); ?>"><span class="ts-code"><?php echo esc_html($service['index']); ?></span><?php echo esc_html($service['title']); ?><?php echo telecomsecurity_geometry($service['geometry']); ?></a></li>
                <?php endforeach; ?></ul>
            </nav>
        <?php endif; ?>
    </article>
<?php endwhile; ?>
</main>
<?php get_footer(); ?>
