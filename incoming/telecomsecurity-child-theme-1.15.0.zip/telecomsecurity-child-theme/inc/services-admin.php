<?php
/** Extend the parent services editor without introducing another content store. */
defined('ABSPATH') || exit;

add_filter('sanitize_option_ticinoweb_services', 'telecomsecurity_sanitize_service_metadata', 20, 3);

function telecomsecurity_sanitize_service_metadata($value, $option, $original_value) {
    if ($original_value === null) {
        return get_option('ticinoweb_services', array());
    }
    if (!is_array($original_value) || !function_exists('ticinoweb_sanitize_services')) {
        return $value;
    }

    $saved_by_id = array();
    foreach ((array) get_option('ticinoweb_services', array()) as $saved) {
        if (is_array($saved) && !empty($saved['id'])) {
            $saved_by_id[$saved['id']] = $saved;
        }
    }
    $result = array();
    $seen = array();
    foreach ($original_value as $raw) {
        if (!is_array($raw) || !isset($raw['title']) || !is_string($raw['title'])) {
            continue;
        }
        // Sanitize each original row separately: blank rows may be removed by the parent.
        $clean = ticinoweb_sanitize_services(array($raw));
        if (empty($clean)) {
            continue;
        }
        $row = reset($clean);
        $id = isset($raw['id']) && is_string($raw['id']) ? sanitize_key($raw['id']) : '';
        $duplicate = $id !== '' && isset($seen[$id]);
        if ($id === '' || $duplicate) {
            $id = wp_generate_uuid4();
        }
        $saved = isset($saved_by_id[$id]) ? $saved_by_id[$id] : array();
        $row['id'] = $id;
        $row['page_id'] = $duplicate ? 0 : absint($raw['page_id'] ?? $saved['page_id'] ?? 0);
        if (!$duplicate && !$row['page_id']) {
            // Resolve once by an exact page title, then retain the page ID on later edits.
            $pages = get_posts(array(
                'post_type' => 'page',
                'post_status' => 'publish',
                'title' => $row['title'],
                'numberposts' => 2,
                'fields' => 'ids',
                'no_found_rows' => true,
            ));
            if (count($pages) === 1) {
                $row['page_id'] = absint($pages[0]);
            }
        }
        $area = $raw['area'] ?? $saved['area'] ?? 'security';
        $row['area'] = in_array($area, array('security', 'infrastructure'), true) ? $area : 'security';
        $geometry = $raw['geometry'] ?? $saved['geometry'] ?? '';
        if (is_string($geometry) && isset(telecomsecurity_geometry_paths()[$geometry])) $row['geometry'] = $geometry;
        $seen[$id] = true;
        $result[] = $row;
    }
    return $result;
}

add_action('admin_init', function () {
    register_setting('ticinoweb_settings_group', 'ts_services_editorial', array(
        'type' => 'array',
        'sanitize_callback' => 'telecomsecurity_sanitize_services_editorial',
    ));
});

function telecomsecurity_sanitize_services_editorial($input) {
    $saved = get_option('ts_services_editorial', array());
    if (!is_array($input)) {
        return $saved;
    }
    $result = is_array($saved) ? $saved : array();
    foreach (array('chapter_1_title', 'chapter_1_text', 'chapter_2_title', 'chapter_2_text', 'transition_title', 'transition_text') as $key) {
        if (array_key_exists($key, $input) && is_string($input[$key])) {
            $result[$key] = substr($key, -5) === '_text' ? sanitize_textarea_field($input[$key]) : sanitize_text_field($input[$key]);
        }
    }
    return $result;
}

add_action('admin_enqueue_scripts', function ($hook) {
    if ($hook !== 'toplevel_page_ticinoweb-cms' || !current_user_can('edit_pages')) {
        return;
    }
    $relative = '/assets/js/services-admin.js';
    wp_enqueue_script('telecomsecurity-services-admin', get_stylesheet_directory_uri() . $relative, array('jquery'), filemtime(get_stylesheet_directory() . $relative), true);
    $config = array(
        'services' => array_values((array) get_option('ticinoweb_services', array())),
        'editorial' => telecomsecurity_get_services_editorial_data(),
        'symbols' => array_keys(telecomsecurity_geometry_paths()),
        'symbolDefaults' => array_column(array_map(static function ($row) { return array('id'=>$row['id'] ?? '', 'symbol'=>telecomsecurity_service_symbol($row)); }, (array) get_option('ticinoweb_services', array())), 'symbol', 'id'),
        'labels' => array(
            'area' => __('Area', 'telecomsecurity-child-theme'),
            'security' => __('Sicurezza', 'telecomsecurity-child-theme'),
            'infrastructure' => __('Infrastrutture', 'telecomsecurity-child-theme'),
            'up' => __('Sposta su', 'telecomsecurity-child-theme'),
            'down' => __('Sposta giù', 'telecomsecurity-child-theme'),
            'heading' => __('Testi della sezione Servizi', 'telecomsecurity-child-theme'),
            'chapter_1_title' => __('Titolo capitolo Sicurezza', 'telecomsecurity-child-theme'),
            'chapter_1_text' => __('Introduzione capitolo Sicurezza', 'telecomsecurity-child-theme'),
            'chapter_2_title' => __('Titolo capitolo Infrastrutture', 'telecomsecurity-child-theme'),
            'chapter_2_text' => __('Introduzione capitolo Infrastrutture', 'telecomsecurity-child-theme'),
            'transition_title' => __('Titolo di transizione', 'telecomsecurity-child-theme'),
            'transition_text' => __('Testo di transizione', 'telecomsecurity-child-theme'),
        ),
    );
    wp_add_inline_script('telecomsecurity-services-admin', 'window.telecomsecurityServicesAdmin = ' . wp_json_encode($config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) . ';', 'before');
});
