<?php
/**
 * Telecom Security SA — Security Signal Rail Component
 *
 * Barra laterale contestuale minimale fissa sulla fascia destra dello schermo:
 * - Linea verticale sottile con indicatore di avanzamento reale nello scroll
 * - Punto arancione del segnale con impulso discreto al cambio di sezione
 * - Label contestuale verticale dinamica (sezioni Home o titolo pagina WordPress)
 * - Freccia direzionale per scorrimento rapido alla sezione successiva o top
 * - Adattamento cromatico automatico a sfondi chiari e scuri
 *
 * @package TelecomSecurityChild
 * @version 1.5.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Recupera la label iniziale del Signal Rail in base al contesto WordPress.
 *
 * @return string Etichetta in maiuscolo ripulita.
 */
function telecomsecurity_get_signal_rail_label(): string {
	if ( is_front_page() || is_home() ) {
		return 'HOME';
	}

	$title = '';

	if ( is_singular() ) {
		$title = get_the_title();
	} elseif ( is_archive() ) {
		$title = get_the_archive_title();
	} elseif ( is_search() ) {
		$title = sprintf( __( 'Ricerca: %s', 'telecomsecurity-child-theme' ), get_search_query() );
	} elseif ( is_404() ) {
		$title = __( 'Pagina non trovata', 'telecomsecurity-child-theme' );
	} else {
		$title = wp_get_document_title();
	}

	// Decodifica le entità del titolo prima dell'escape finale della label.
	$title = html_entity_decode( (string) $title, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
	$title = wp_strip_all_tags( $title );
	$title = preg_replace( '/\s*[\-\|].*$/', '', $title );
	$title = trim( $title );

	if ( empty( $title ) ) {
		$title = 'TELECOM SECURITY';
	}

	return mb_strtoupper( $title, 'UTF-8' );
}

/**
 * Renderizza il markup HTML del Security Signal Rail nel footer frontend.
 */
function telecomsecurity_render_signal_rail(): void {
	if ( is_admin() ) {
		return;
	}

	$initial_label = telecomsecurity_get_signal_rail_label();
	$initial_theme = is_front_page() ? 'dark' : 'light';
	$is_services_archive = function_exists( 'telecomsecurity_is_services_archive' ) && telecomsecurity_is_services_archive();
	?>
	<!-- ==========================================================================
	     SECURITY SIGNAL RAIL — Barra laterale contestuale minimale
	     ========================================================================== -->
	<aside class="ts-signal-rail" id="ts-signal-rail" aria-label="<?php esc_attr_e( 'Navigazione rapida e stato della pagina', 'telecomsecurity-child-theme' ); ?>" data-signal-theme="<?php echo esc_attr( $initial_theme ); ?>">
		<div class="ts-signal-rail__inner">
			
			<!-- Colonna Sinistra: Label contestuale verticale indipendente -->
			<div class="ts-signal-rail__label-wrap">
				<span class="ts-signal-rail__label" id="ts-signal-rail-label"><?php echo esc_html( $initial_label ); ?></span>
			</div>

			<!-- Colonna Destra: Asse del segnale con linea a lunghezza costante e freccia -->
			<div class="ts-signal-rail__axis">
				<?php if ( $is_services_archive ) : ?>
				<button type="button" class="ts-signal-rail__arrow-btn ts-signal-rail__arrow-btn--prev" id="ts-signal-rail-prev" aria-label="<?php esc_attr_e( 'Servizio precedente', 'telecomsecurity-child-theme' ); ?>">
					<svg class="ts-signal-rail__arrow-icon" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
						<polyline points="6 9 12 15 18 9"></polyline>
					</svg>
				</button>
				<?php endif; ?>
				<div class="ts-signal-rail__track-container">
					<div class="ts-signal-rail__track" id="ts-signal-rail-track">
						<div class="ts-signal-rail__progress" id="ts-signal-rail-progress"></div>
						<div class="ts-signal-rail__dot" id="ts-signal-rail-dot"></div>
					</div>
				</div>

				<!-- Freccia direzionale verso la sezione successiva / top -->
				<button type="button" class="ts-signal-rail__arrow-btn" id="ts-signal-rail-arrow" aria-label="<?php echo esc_attr( $is_services_archive ? __( 'Servizio successivo', 'telecomsecurity-child-theme' ) : __( 'Scorri alla sezione successiva', 'telecomsecurity-child-theme' ) ); ?>" tabindex="0">
					<svg class="ts-signal-rail__arrow-icon" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
						<polyline points="6 9 12 15 18 9"></polyline>
					</svg>
				</button>
			</div>

		</div>
	</aside>
	<?php
}
add_action( 'wp_footer', 'telecomsecurity_render_signal_rail', 5 );
