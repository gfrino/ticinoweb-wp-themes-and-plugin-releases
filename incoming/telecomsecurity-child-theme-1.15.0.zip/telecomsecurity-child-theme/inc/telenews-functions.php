<?php
/**
 * Public helpers for the TeleNews archive and standard posts.
 *
 * @package TelecomSecurityChild
 */

defined( 'ABSPATH' ) || exit;

/** Return the public TeleNews page URL. */
function telecomsecurity_get_telenews_url(): string {
	$page = get_page_by_path( 'telenews', OBJECT, 'page' );
	return $page instanceof WP_Post && 'publish' === $page->post_status
		? (string) get_permalink( $page )
		: home_url( '/telenews/' );
}

/** Return the published contact page URL. */
function telecomsecurity_get_consultation_url(): string {
	$page = get_page_by_path( 'contatti', OBJECT, 'page' );
	return $page instanceof WP_Post && 'publish' === $page->post_status
		? (string) get_permalink( $page )
		: home_url( '/contatti/' );
}

/** Return the first assigned category label, avoiding the WordPress default. */
function telecomsecurity_get_post_category_label( int $post_id ): string {
	$categories = get_the_category( $post_id );
	foreach ( $categories as $category ) {
		if ( 'uncategorized' !== $category->slug ) {
			return $category->name;
		}
	}
	return __( 'TeleNews', 'telecomsecurity-child-theme' );
}

/** Return a controlled editorial excerpt even when no manual excerpt exists. */
function telecomsecurity_get_post_summary( int $post_id, int $words = 30 ): string {
	$manual = trim( (string) get_post_field( 'post_excerpt', $post_id ) );
	if ( '' !== $manual ) {
		return wp_trim_words( wp_strip_all_tags( strip_shortcodes( $manual ) ), $words, '…' );
	}

	$content = (string) get_post_field( 'post_content', $post_id );
	$content = preg_replace( '/<!--.*?-->/s', '', $content );
	return wp_trim_words( wp_strip_all_tags( strip_shortcodes( $content ) ), $words, '…' );
}

/** Render a responsive featured image or a stable, accessible fallback. */
function telecomsecurity_render_post_cover( int $post_id, string $class, string $sizes, bool $eager = false ): void {
	$image_id = get_post_thumbnail_id( $post_id );
	if ( $image_id ) {
		$alt = trim( (string) get_post_meta( $image_id, '_wp_attachment_image_alt', true ) );
		echo wp_get_attachment_image(
			$image_id,
			'large',
			false,
			array(
				'class'         => $class,
				'alt'           => '' !== $alt ? $alt : get_the_title( $post_id ),
				'loading'       => $eager ? 'eager' : 'lazy',
				'fetchpriority' => $eager ? 'high' : 'auto',
				'decoding'      => 'async',
				'sizes'         => $sizes,
			)
		);
		return;
	}
	?>
	<span class="ts-telenews-media-fallback <?php echo esc_attr( $class ); ?>" role="img" aria-label="<?php esc_attr_e( 'Immagine in aggiornamento', 'telecomsecurity-child-theme' ); ?>">
		<span aria-hidden="true">TS</span>
		<small><?php esc_html_e( 'Immagine in aggiornamento', 'telecomsecurity-child-theme' ); ?></small>
	</span>
	<?php
}

