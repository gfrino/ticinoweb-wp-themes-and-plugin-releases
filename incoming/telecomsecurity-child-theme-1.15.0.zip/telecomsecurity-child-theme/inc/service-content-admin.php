<?php
/** Service page editing interface. */

defined( 'ABSPATH' ) || exit;

/** Disable Gutenberg only for existing CMS-linked service pages. */
function telecomsecurity_service_use_block_editor( bool $use_block_editor, WP_Post $post ): bool {
	return telecomsecurity_is_service_page( $post->ID ) ? false : $use_block_editor;
}
add_filter( 'use_block_editor_for_post', 'telecomsecurity_service_use_block_editor', 20, 2 );

/** Register the service-content metabox only on linked pages. */
function telecomsecurity_add_service_content_metabox( WP_Post $post ): void {
	if ( ! telecomsecurity_is_service_page( $post->ID ) ) {
		return;
	}
	add_meta_box(
		'telecomsecurity-service-content',
		__( 'Contenuto servizio', 'telecomsecurity-child-theme' ),
		'telecomsecurity_render_service_content_metabox',
		'page',
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes_page', 'telecomsecurity_add_service_content_metabox' );

/** Print one generic repeater row. */
function telecomsecurity_service_admin_row( string $group, int|string $index, array $row = array(), bool $faq = false ): void {
	$title_key       = $faq ? 'question' : 'title';
	$description_key = $faq ? 'answer' : 'description';
	$title_label     = $faq ? __( 'Domanda', 'telecomsecurity-child-theme' ) : __( 'Titolo', 'telecomsecurity-child-theme' );
	$description_label = $faq ? __( 'Risposta', 'telecomsecurity-child-theme' ) : __( 'Descrizione', 'telecomsecurity-child-theme' );
	?>
	<div class="ts-service-admin__row" data-ts-row>
		<div class="ts-service-admin__row-toolbar">
			<button type="button" class="button-link ts-service-admin__drag" data-ts-drag aria-label="<?php esc_attr_e( 'Trascina per riordinare', 'telecomsecurity-child-theme' ); ?>">↕</button>
			<button type="button" class="button-link-delete" data-ts-remove><?php esc_html_e( 'Rimuovi', 'telecomsecurity-child-theme' ); ?></button>
		</div>
		<label>
			<span><?php echo esc_html( $title_label ); ?></span>
			<input type="text" name="<?php echo esc_attr( TELECOMSECURITY_SERVICE_META_KEY . '[' . $group . '][' . $index . '][' . $title_key . ']' ); ?>" value="<?php echo esc_attr( $row[ $title_key ] ?? '' ); ?>">
		</label>
		<label>
			<span><?php echo esc_html( $description_label ); ?></span>
			<textarea rows="3" name="<?php echo esc_attr( TELECOMSECURITY_SERVICE_META_KEY . '[' . $group . '][' . $index . '][' . $description_key . ']' ); ?>"><?php echo esc_textarea( $row[ $description_key ] ?? '' ); ?></textarea>
		</label>
	</div>
	<?php
}

/** Build the stable ID used to connect an editor tab to its panel. */
function telecomsecurity_service_admin_panel_id( string $section ): string {
	return 'ts-service-admin-panel-' . sanitize_html_class( $section );
}

/** Return the localized item count displayed in the section navigator. */
function telecomsecurity_service_admin_item_count( int $count ): string {
	return sprintf(
		/* translators: %s: number of entries in the service editor section. */
		_n( '%s voce', '%s voci', $count, 'telecomsecurity-child-theme' ),
		number_format_i18n( $count )
	);
}

/** Print a repeatable group and its inert template. */
function telecomsecurity_service_admin_repeater( string $group, string $title, array $rows, bool $faq = false, string $help = '' ): void {
	?>
	<section class="ts-service-admin__section ts-service-admin__panel" id="<?php echo esc_attr( telecomsecurity_service_admin_panel_id( $group ) ); ?>" data-ts-section-panel="<?php echo esc_attr( $group ); ?>">
		<div class="ts-service-admin__section-heading">
			<div><h3><?php echo esc_html( $title ); ?></h3><?php if ( $help ) : ?><p><?php echo esc_html( $help ); ?></p><?php endif; ?></div>
			<button type="button" class="button" data-ts-add><?php esc_html_e( 'Aggiungi voce', 'telecomsecurity-child-theme' ); ?></button>
		</div>
		<div class="ts-service-admin__repeater" data-ts-repeater="<?php echo esc_attr( $group ); ?>">
			<div data-ts-rows>
				<?php foreach ( $rows as $index => $row ) : telecomsecurity_service_admin_row( $group, $index, $row, $faq ); endforeach; ?>
			</div>
			<template data-ts-template><?php telecomsecurity_service_admin_row( $group, '__INDEX__', array(), $faq ); ?></template>
		</div>
	</section>
	<?php
}

/** Render the complete editor UI. */
function telecomsecurity_render_service_content_metabox( WP_Post $post ): void {
	$data    = telecomsecurity_get_service_content( $post->ID );
	$context = telecomsecurity_get_service_context( $post->ID );
	wp_nonce_field( 'telecomsecurity_save_service_content', 'telecomsecurity_service_content_nonce' );
	?>
	<div class="ts-service-admin" data-ts-service-editor data-post-id="<?php echo esc_attr( $post->ID ); ?>">
		<section class="ts-service-admin__section ts-service-admin__native">
			<h3><?php esc_html_e( 'Hero', 'telecomsecurity-child-theme' ); ?></h3>
			<p><?php esc_html_e( 'Il titolo, l’introduzione breve e la fotografia principale usano i campi WordPress nativi: Titolo, Riassunto e Immagine in evidenza. La stessa immagine viene riutilizzata automaticamente nell’archivio e nei servizi correlati.', 'telecomsecurity-child-theme' ); ?></p>
		</section>

		<section class="ts-service-admin__section">
			<h3><?php esc_html_e( 'Panoramica', 'telecomsecurity-child-theme' ); ?></h3>
			<div class="ts-service-admin__grid">
				<label><span><?php esc_html_e( 'Titolo della panoramica', 'telecomsecurity-child-theme' ); ?></span><input type="text" name="<?php echo esc_attr( TELECOMSECURITY_SERVICE_META_KEY ); ?>[overview_title]" value="<?php echo esc_attr( $data['overview_title'] ); ?>"></label>
				<label class="is-wide"><span><?php esc_html_e( 'Testo', 'telecomsecurity-child-theme' ); ?></span><textarea rows="8" name="<?php echo esc_attr( TELECOMSECURITY_SERVICE_META_KEY ); ?>[overview]"><?php echo esc_textarea( $data['overview'] ); ?></textarea></label>
			</div>
		</section>

		<?php
		$section_tabs = array(
			'includes'     => array(
				'label' => __( 'Cosa comprende', 'telecomsecurity-child-theme' ),
				'meta'  => telecomsecurity_service_admin_item_count( count( $data['includes'] ) ),
			),
			'applications' => array(
				'label' => __( 'Ambiti di applicazione', 'telecomsecurity-child-theme' ),
				'meta'  => telecomsecurity_service_admin_item_count( count( $data['applications'] ) ),
			),
			'benefits'     => array(
				'label' => __( 'Vantaggi', 'telecomsecurity-child-theme' ),
				'meta'  => telecomsecurity_service_admin_item_count( count( $data['benefits'] ) ),
			),
			'process'      => array(
				'label' => __( 'Metodo', 'telecomsecurity-child-theme' ),
				'meta'  => telecomsecurity_service_admin_item_count( count( $data['process'] ) ),
			),
			'faqs'         => array(
				'label' => __( 'FAQ', 'telecomsecurity-child-theme' ),
				'meta'  => telecomsecurity_service_admin_item_count( count( $data['faqs'] ) ),
			),
			'cta'          => array(
				'label' => __( 'Contatto / CTA', 'telecomsecurity-child-theme' ),
				'meta'  => __( '3 campi', 'telecomsecurity-child-theme' ),
			),
			'related'      => array(
				'label' => __( 'Servizi correlati', 'telecomsecurity-child-theme' ),
				'meta'  => $data['related_ids'] ? telecomsecurity_service_admin_item_count( count( $data['related_ids'] ) ) : __( 'Automatici', 'telecomsecurity-child-theme' ),
			),
		);
		?>
		<div class="ts-service-admin__section-switcher" data-ts-section-tabs>
			<div class="ts-service-admin__switcher-heading">
				<div>
					<h3><?php esc_html_e( 'Modifica una sezione', 'telecomsecurity-child-theme' ); ?></h3>
					<p><?php esc_html_e( 'Seleziona la scheda che vuoi aggiornare: verrà mostrato soltanto il relativo contenuto.', 'telecomsecurity-child-theme' ); ?></p>
				</div>
				<span class="ts-service-admin__switcher-count"><?php echo esc_html( sprintf( __( '%s sezioni', 'telecomsecurity-child-theme' ), number_format_i18n( count( $section_tabs ) ) ) ); ?></span>
			</div>
			<div class="ts-service-admin__tablist" aria-label="<?php esc_attr_e( 'Sezioni del contenuto servizio', 'telecomsecurity-child-theme' ); ?>">
				<?php
				$tab_number = 0;
				foreach ( $section_tabs as $section_key => $tab ) :
					++$tab_number;
					?>
					<button type="button" class="ts-service-admin__tab<?php echo 1 === $tab_number ? ' is-active' : ''; ?>" id="ts-service-admin-tab-<?php echo esc_attr( $section_key ); ?>" aria-controls="<?php echo esc_attr( telecomsecurity_service_admin_panel_id( $section_key ) ); ?>" data-ts-section-tab="<?php echo esc_attr( $section_key ); ?>">
						<span class="ts-service-admin__tab-number" aria-hidden="true"><?php echo esc_html( str_pad( (string) $tab_number, 2, '0', STR_PAD_LEFT ) ); ?></span>
						<span class="ts-service-admin__tab-copy"><strong><?php echo esc_html( $tab['label'] ); ?></strong><small data-ts-tab-meta<?php if ( 'related' === $section_key ) : ?> data-ts-empty-label="<?php esc_attr_e( 'Automatici', 'telecomsecurity-child-theme' ); ?>"<?php endif; ?>><?php echo esc_html( $tab['meta'] ); ?></small></span>
						<span class="ts-service-admin__tab-arrow" aria-hidden="true">→</span>
					</button>
				<?php endforeach; ?>
			</div>
		</div>

		<?php
		telecomsecurity_service_admin_repeater( 'includes', __( 'Cosa comprende', 'telecomsecurity-child-theme' ), $data['includes'], false, __( 'Da quattro a sei elementi concreti del servizio.', 'telecomsecurity-child-theme' ) );
		telecomsecurity_service_admin_repeater( 'applications', __( 'Ambiti di applicazione', 'telecomsecurity-child-theme' ), $data['applications'] );
		telecomsecurity_service_admin_repeater( 'benefits', __( 'Vantaggi', 'telecomsecurity-child-theme' ), $data['benefits'] );
		telecomsecurity_service_admin_repeater( 'process', __( 'Metodo', 'telecomsecurity-child-theme' ), $data['process'], false, __( 'Le fasi operative specifiche di questo servizio.', 'telecomsecurity-child-theme' ) );
		telecomsecurity_service_admin_repeater( 'faqs', __( 'FAQ', 'telecomsecurity-child-theme' ), $data['faqs'], true, __( 'Risposte utili e prudenti, senza dettagli sensibili sull’impianto.', 'telecomsecurity-child-theme' ) );
		?>

		<section class="ts-service-admin__section ts-service-admin__panel" id="<?php echo esc_attr( telecomsecurity_service_admin_panel_id( 'cta' ) ); ?>" data-ts-section-panel="cta">
			<h3><?php esc_html_e( 'CTA', 'telecomsecurity-child-theme' ); ?></h3>
			<div class="ts-service-admin__grid">
				<label><span><?php esc_html_e( 'Titolo', 'telecomsecurity-child-theme' ); ?></span><input type="text" name="<?php echo esc_attr( TELECOMSECURITY_SERVICE_META_KEY ); ?>[cta_title]" value="<?php echo esc_attr( $data['cta_title'] ); ?>"></label>
				<label><span><?php esc_html_e( 'URL', 'telecomsecurity-child-theme' ); ?></span><input type="url" name="<?php echo esc_attr( TELECOMSECURITY_SERVICE_META_KEY ); ?>[cta_url]" value="<?php echo esc_attr( $data['cta_url'] ); ?>"></label>
				<label class="is-wide"><span><?php esc_html_e( 'Testo', 'telecomsecurity-child-theme' ); ?></span><textarea rows="4" name="<?php echo esc_attr( TELECOMSECURITY_SERVICE_META_KEY ); ?>[cta_text]"><?php echo esc_textarea( $data['cta_text'] ); ?></textarea></label>
			</div>
		</section>

		<section class="ts-service-admin__section ts-service-admin__panel" id="<?php echo esc_attr( telecomsecurity_service_admin_panel_id( 'related' ) ); ?>" data-ts-section-panel="related">
			<h3><?php esc_html_e( 'Servizi correlati', 'telecomsecurity-child-theme' ); ?></h3>
			<p><?php esc_html_e( 'Se non selezioni nulla, il sito propone automaticamente servizi della stessa area.', 'telecomsecurity-child-theme' ); ?></p>
			<div class="ts-service-admin__checks">
				<?php foreach ( $context['services'] ?? array() as $service ) : $related_id = absint( $service['page_id'] ?? 0 ); if ( $related_id === $post->ID ) { continue; } ?>
					<label><input type="checkbox" name="<?php echo esc_attr( TELECOMSECURITY_SERVICE_META_KEY ); ?>[related_ids][]" value="<?php echo esc_attr( $related_id ); ?>" <?php checked( in_array( $related_id, $data['related_ids'], true ) ); ?>> <span><?php echo esc_html( $service['title'] ); ?></span></label>
				<?php endforeach; ?>
			</div>
		</section>
	</div>
	<?php
}

/** Save one complete service payload. */
function telecomsecurity_save_service_content( int $post_id, WP_Post $post ): void {
	if ( 'page' !== $post->post_type || ! telecomsecurity_is_service_page( $post_id ) ) {
		return;
	}
	if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
		return;
	}
	$nonce = isset( $_POST['telecomsecurity_service_content_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['telecomsecurity_service_content_nonce'] ) ) : '';
	if ( ! wp_verify_nonce( $nonce, 'telecomsecurity_save_service_content' ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$raw = isset( $_POST[ TELECOMSECURITY_SERVICE_META_KEY ] ) ? wp_unslash( $_POST[ TELECOMSECURITY_SERVICE_META_KEY ] ) : array();
	$data = telecomsecurity_sanitize_service_content( is_array( $raw ) ? $raw : array() );
	$data['related_ids'] = array_values( array_filter( $data['related_ids'], static function ( int $related_id ) use ( $post_id ): bool {
		return $related_id !== $post_id && telecomsecurity_is_service_page( $related_id );
	} ) );
	update_post_meta( $post_id, TELECOMSECURITY_SERVICE_META_KEY, $data );
}
add_action( 'save_post_page', 'telecomsecurity_save_service_content', 20, 2 );

/** Load scoped editor assets and hide the unused classic content editor. */
function telecomsecurity_service_admin_assets( string $hook ): void {
	if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
		return;
	}
	$post_id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0;
	if ( ! $post_id || ! telecomsecurity_is_service_page( $post_id ) ) {
		return;
	}
	wp_enqueue_script( 'jquery-ui-sortable' );
	wp_enqueue_style( 'telecomsecurity-service-admin', get_stylesheet_directory_uri() . '/assets/css/service-content-admin.css', array(), (string) filemtime( get_stylesheet_directory() . '/assets/css/service-content-admin.css' ) );
	wp_enqueue_script( 'telecomsecurity-service-admin', get_stylesheet_directory_uri() . '/assets/js/service-content-admin.js', array( 'jquery', 'jquery-ui-sortable' ), (string) filemtime( get_stylesheet_directory() . '/assets/js/service-content-admin.js' ), true );
}
add_action( 'admin_enqueue_scripts', 'telecomsecurity_service_admin_assets' );

/** Keep the legacy free-content editor out of the structured service workflow. */
function telecomsecurity_service_admin_head(): void {
	$post_id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0;
	if ( $post_id && telecomsecurity_is_service_page( $post_id ) ) {
		echo '<style>#postdivrich{display:none}</style>';
	}
}
add_action( 'admin_head-post.php', 'telecomsecurity_service_admin_head' );
