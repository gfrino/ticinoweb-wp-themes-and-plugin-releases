<?php
/**
 * Telecom Security — Metodo di Lavoro Helper Functions
 *
 * Gestione dinamica dei dati editoriali per la sezione "Il nostro metodo"
 * nella Homepage di Telecom Security SA.
 *
 * @package TelecomSecurityChild
 * @version 1.8.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Restituisce la struttura predefinita con i contenuti iniziali approvati.
 *
 * @return array Struttura dati iniziale completa.
 */
function telecomsecurity_get_method_section_defaults(): array {
	// Risolvi ID della pagina Contatti se disponibile
	$contatti_page = get_page_by_path( 'contatti' );
	if ( ! $contatti_page ) {
		$contatti_page = get_page_by_title( 'Contatti' );
	}
	$contatti_id = $contatti_page ? (int) $contatti_page->ID : 8;

	return array(
		'enabled'      => true,
		'eyebrow'      => 'IL NOSTRO METODO',
		'title'        => 'Ogni sistema nasce da una sequenza precisa.',
		'introduction' => 'Cinque passaggi che trasformano esigenze diverse in una soluzione coordinata.',
		'items'        => array(
			array(
				'id'        => 'step_comprendere',
				'active'    => true,
				'title'     => 'Comprendere',
				'text'      => 'Ogni progetto parte dagli spazi, dalle abitudini e dalle esigenze reali. Prima della tecnologia viene il contesto.',
				'image_id'  => 0,
				'image_pos' => 'center',
			),
			array(
				'id'        => 'step_progettare',
				'active'    => true,
				'title'     => 'Progettare',
				'text'      => 'Definiamo funzioni, priorità e collegamenti, costruendo una soluzione proporzionata all’ambiente e al suo utilizzo.',
				'image_id'  => 0,
				'image_pos' => 'center',
			),
			array(
				'id'        => 'step_integrare',
				'active'    => true,
				'title'     => 'Integrare',
				'text'      => 'Video, allarmi, accessi, comunicazioni e automazioni vengono coordinati perché lavorino come parti dello stesso sistema.',
				'image_id'  => 0,
				'image_pos' => 'center',
			),
			array(
				'id'        => 'step_mettere_in_funzione',
				'active'    => true,
				'title'     => 'Mettere in funzione',
				'text'      => 'Installazione e configurazione trasformano il progetto in uno strumento concreto, chiaro da utilizzare e adatto allo spazio.',
				'image_id'  => 0,
				'image_pos' => 'center',
			),
			array(
				'id'        => 'step_assistere',
				'active'    => true,
				'title'     => 'Assistere',
				'text'      => 'Anche dopo l’avvio, Telecom Security rimane un riferimento tecnico per accompagnare il sistema nel tempo.',
				'image_id'  => 0,
				'image_pos' => 'center',
			),
		),
		'final_panel'  => array(
			'title'    => 'Il tuo sistema comincia da qui.',
			'text'     => 'Raccontaci ciò che vuoi proteggere.',
			'btn_text' => 'Richiedi una consulenza',
			'page_id'  => $contatti_id,
		),
	);
}

/**
 * Recupera e normalizza i dati completi per il frontend della sezione "Il nostro metodo".
 *
 * @return array Dati elaborati con attachment risolti, conteggio e permalink dinamici.
 */
function telecomsecurity_get_method_section_data(): array {
	$saved_option = get_option( 'ts_home_method_section', null );

	// Inizializza i valori solo se l'opzione non esiste nel DB
	if ( null === $saved_option || false === $saved_option ) {
		$defaults = telecomsecurity_get_method_section_defaults();
		update_option( 'ts_home_method_section', $defaults );
		$saved_option = $defaults;
	}

	$defaults = telecomsecurity_get_method_section_defaults();

	$enabled      = isset( $saved_option['enabled'] ) ? (bool) $saved_option['enabled'] : true;
	$eyebrow      = ! empty( $saved_option['eyebrow'] ) ? $saved_option['eyebrow'] : $defaults['eyebrow'];
	$title        = ! empty( $saved_option['title'] ) ? $saved_option['title'] : $defaults['title'];
	$introduction = ! empty( $saved_option['introduction'] ) ? $saved_option['introduction'] : $defaults['introduction'];

	// Normalizzazione dei passaggi
	$raw_items = isset( $saved_option['items'] ) && is_array( $saved_option['items'] ) ? $saved_option['items'] : $defaults['items'];

	$active_items = array();
	$item_order   = 1;

	foreach ( $raw_items as $item ) {
		// Rispetta il toggle attivo/disattivo
		if ( isset( $item['active'] ) && ! $item['active'] ) {
			continue;
		}

		$item_title = isset( $item['title'] ) ? trim( (string) $item['title'] ) : '';
		if ( empty( $item_title ) ) {
			continue;
		}

		$item_text = isset( $item['text'] ) ? trim( (string) $item['text'] ) : '';
		$image_id  = isset( $item['image_id'] ) ? absint( $item['image_id'] ) : 0;
		$image_pos = isset( $item['image_pos'] ) && in_array( $item['image_pos'], array( 'center', 'left', 'right' ), true ) ? $item['image_pos'] : 'center';

		$image_url    = '';
		$image_alt    = '';
		$image_srcset = '';
		$image_sizes  = '(max-width: 767px) 100vw, (max-width: 1024px) 84vw, (max-width: 1187px) 760px, (max-width: 1843px) 64vw, 1180px';

		if ( $image_id > 0 ) {
			$img_src = wp_get_attachment_image_src( $image_id, 'full' );
			if ( $img_src ) {
				$image_url    = $img_src[0];
				$image_alt    = get_post_meta( $image_id, '_wp_attachment_image_alt', true );
				$image_srcset = wp_get_attachment_image_srcset( $image_id, 'full' );
			}
		}

		$active_items[] = array(
			'id'           => ! empty( $item['id'] ) ? sanitize_key( $item['id'] ) : 'step_' . $item_order,
			'order'        => $item_order,
			'title'        => $item_title,
			'text'         => $item_text,
			'url'          => ! empty( $item['url'] ) ? esc_url_raw( $item['url'] ) : '',
			'image_id'     => $image_id,
			'image_url'    => $image_url,
			'image_alt'    => ! empty( $image_alt ) ? $image_alt : $item_title,
			'image_srcset' => $image_srcset,
			'image_sizes'  => $image_sizes,
			'image_pos'    => $image_pos,
		);

		$item_order++;
	}

	$total_items = count( $active_items );

	// Arricchisci ogni elemento con la numerazione dinamica (es. 01/05) e identificatore centrale
	$central_index = $total_items > 0 ? (int) floor( $total_items / 2 ) : 0;

	foreach ( $active_items as $k => $it ) {
		$active_items[ $k ]['formatted_index'] = sprintf( '%02d', $it['order'] );
		$active_items[ $k ]['total_formatted'] = sprintf( '%02d', $total_items );
		$active_items[ $k ]['display_number']  = sprintf( '%02d / %02d', $it['order'], $total_items );
		$active_items[ $k ]['is_central']      = ( $k === $central_index );
	}

	// Normalizzazione pannello finale CTA
	$raw_final = isset( $saved_option['final_panel'] ) && is_array( $saved_option['final_panel'] ) ? $saved_option['final_panel'] : $defaults['final_panel'];

	$final_title    = ! empty( $raw_final['title'] ) ? $raw_final['title'] : $defaults['final_panel']['title'];
	$final_text     = ! empty( $raw_final['text'] ) ? $raw_final['text'] : $defaults['final_panel']['text'];
	$final_btn_text = ! empty( $raw_final['btn_text'] ) ? $raw_final['btn_text'] : $defaults['final_panel']['btn_text'];
	$final_page_id  = isset( $raw_final['page_id'] ) ? absint( $raw_final['page_id'] ) : $defaults['final_panel']['page_id'];

	$final_url = $final_page_id > 0 ? get_permalink( $final_page_id ) : '';
	if ( empty( $final_url ) ) {
		$final_url = home_url( '/contatti/' );
	}

	return array(
		'enabled'      => $enabled,
		'eyebrow'      => $eyebrow,
		'title'        => $title,
		'introduction' => $introduction,
		'items'        => $active_items,
		'total_items'  => $total_items,
		'final_panel'  => array(
			'title'    => $final_title,
			'text'     => $final_text,
			'btn_text' => $final_btn_text,
			'page_id'  => $final_page_id,
			'url'      => $final_url,
		),
	);
}
