<?php
/**
 * CMS data for the company leader section on the About page.
 *
 * @package TelecomSecurityChild
 */

defined( 'ABSPATH' ) || exit;

/**
 * Sanitize the child-specific leader settings.
 *
 * @param mixed $input Submitted option value.
 * @return array{name:string,role:string,portrait_id:int,gallery_id:int}
 */
function telecomsecurity_sanitize_about_leader( $input ): array {
	if ( null === $input ) {
		$input = get_option( 'ts_about_leader', array() );
	}
	$input       = is_array( $input ) ? $input : array();
	$portrait_id = absint( $input['portrait_id'] ?? 0 );
	$gallery_id  = absint( $input['gallery_id'] ?? 0 );

	if ( $portrait_id && ! wp_attachment_is_image( $portrait_id ) ) {
		$portrait_id = 0;
	}

	if ( $gallery_id && ! term_exists( $gallery_id, 'ticinoweb_media_gallery' ) ) {
		$gallery_id = 0;
	}

	return array(
		'name'        => isset( $input['name'] ) && is_string( $input['name'] ) ? sanitize_text_field( $input['name'] ) : '',
		'role'        => isset( $input['role'] ) && is_string( $input['role'] ) ? sanitize_text_field( $input['role'] ) : '',
		'portrait_id' => $portrait_id,
		'gallery_id'  => $gallery_id,
	);
}

/**
 * Register the fields in the existing ticinoWEB CMS settings form.
 */
function telecomsecurity_register_about_leader_setting(): void {
	register_setting(
		'ticinoweb_settings_group',
		'ts_about_leader',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'telecomsecurity_sanitize_about_leader',
			'default'           => array(),
		)
	);

	if ( function_exists( 'icl_register_string' ) || defined( 'ICL_SITEPRESS_VERSION' ) ) {
		$saved = telecomsecurity_sanitize_about_leader( get_option( 'ts_about_leader', array() ) );
		$source_lang = apply_filters( 'wpml_default_language', null );
		$source_lang = is_string( $source_lang ) ? $source_lang : '';
		do_action( 'wpml_register_single_string', 'Telecom Security — Chi siamo', 'Leader name', $saved['name'], false, $source_lang );
		do_action( 'wpml_register_single_string', 'Telecom Security — Chi siamo', 'Leader role', $saved['role'], false, $source_lang );
	}
}
add_action( 'admin_init', 'telecomsecurity_register_about_leader_setting' );

/**
 * Resolve an accessible alternative description for a Media Library image.
 *
 * @param int $attachment_id Attachment ID.
 * @return string
 */
function telecomsecurity_about_leader_image_alt( int $attachment_id ): string {
	return trim( (string) get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ) );
}

/**
 * Build the data used by the child UI inside ticinoWEB CMS -> Chi siamo.
 *
 * @return array{saved:array,portrait_url:string,galleries:array,manager_url:string}
 */
function telecomsecurity_get_about_leader_admin_data(): array {
	$saved          = telecomsecurity_sanitize_about_leader( get_option( 'ts_about_leader', array() ) );
	$portrait_url   = $saved['portrait_id'] ? wp_get_attachment_image_url( $saved['portrait_id'], 'medium' ) : '';
	$manager_url    = add_query_arg( array( 'page' => 'ticinoweb-media-galleries-manager' ), admin_url( 'upload.php' ) );
	$gallery_terms = get_terms(
		array(
			'taxonomy'   => 'ticinoweb_media_gallery',
			'hide_empty' => false,
		)
	);
	$galleries = array();

	if ( ! is_wp_error( $gallery_terms ) ) {
		foreach ( $gallery_terms as $term ) {
			$gallery_id = absint( $term->term_id ?? 0 );
			if ( ! $gallery_id ) {
				continue;
			}
			$attachment_ids = function_exists( 'telecomsecurity_get_media_gallery_attachment_ids' )
				? array_slice( telecomsecurity_get_media_gallery_attachment_ids( $gallery_id ), 0, 6 )
				: array();
			$preview_urls = array();
			foreach ( $attachment_ids as $attachment_id ) {
				$url = wp_get_attachment_image_url( absint( $attachment_id ), 'thumbnail' );
				if ( $url ) {
					$preview_urls[] = $url;
				}
			}
			$galleries[] = array(
				'id'           => $gallery_id,
				'name'         => (string) ( $term->name ?? '' ),
				'count'        => absint( $term->count ?? 0 ),
				'preview_urls' => $preview_urls,
				'manage_url'   => add_query_arg(
					array(
						'page'    => 'ticinoweb-media-galleries-manager',
						'gallery' => $gallery_id,
					),
					admin_url( 'upload.php' )
				),
			);
		}
	}

	return array(
		'saved'        => $saved,
		'portrait_url' => (string) $portrait_url,
		'galleries'    => $galleries,
		'manager_url'  => $manager_url,
	);
}

/**
 * Load the child UI only on ticinoWEB CMS, where it extends Chi siamo.
 *
 * @param string $hook Current admin screen hook.
 */
function telecomsecurity_enqueue_about_leader_admin( string $hook ): void {
	if ( 'toplevel_page_ticinoweb-cms' !== $hook || ! current_user_can( 'edit_pages' ) ) {
		return;
	}

	$script_path = get_stylesheet_directory() . '/assets/js/about-leader-admin.js';
	$style_path  = get_stylesheet_directory() . '/assets/css/about-leader-admin.css';
	$admin_data  = telecomsecurity_get_about_leader_admin_data();

	wp_enqueue_media();
	wp_enqueue_style(
		'telecomsecurity-about-leader-admin',
		get_stylesheet_directory_uri() . '/assets/css/about-leader-admin.css',
		array(),
		(string) filemtime( $style_path )
	);
	wp_enqueue_script(
		'telecomsecurity-about-leader-admin',
		get_stylesheet_directory_uri() . '/assets/js/about-leader-admin.js',
		array( 'jquery' ),
		(string) filemtime( $script_path ),
		true
	);
	wp_add_inline_script(
		'telecomsecurity-about-leader-admin',
		'window.telecomsecurityAboutLeaderAdmin=' . wp_json_encode(
			array_merge(
				$admin_data,
				array(
					'canManageGalleries' => current_user_can( 'manage_options' ),
					'labels'             => array(
						'heading'          => __( 'Direzione e galleria', 'telecomsecurity-child-theme' ),
						'description'      => __( 'Presenta il responsabile dell’azienda e collega una galleria della Libreria Media.', 'telecomsecurity-child-theme' ),
						'name'             => __( 'Nome', 'telecomsecurity-child-theme' ),
						'nameHelp'         => __( 'Nome mostrato nella pagina Chi siamo.', 'telecomsecurity-child-theme' ),
						'role'             => __( 'Qualifica', 'telecomsecurity-child-theme' ),
						'roleHelp'         => __( 'Per esempio: Fondatore e direttore tecnico.', 'telecomsecurity-child-theme' ),
						'portrait'         => __( 'Foto principale', 'telecomsecurity-child-theme' ),
						'selectPortrait'   => __( 'Scegli foto', 'telecomsecurity-child-theme' ),
						'changePortrait'   => __( 'Cambia foto', 'telecomsecurity-child-theme' ),
						'removePortrait'   => __( 'Rimuovi', 'telecomsecurity-child-theme' ),
						'portraitDialog'   => __( 'Seleziona la foto del responsabile', 'telecomsecurity-child-theme' ),
						'usePortrait'      => __( 'Usa questa foto', 'telecomsecurity-child-theme' ),
						'gallery'          => __( 'Piccola galleria', 'telecomsecurity-child-theme' ),
						'galleryEmpty'     => __( 'Nessuna galleria selezionata', 'telecomsecurity-child-theme' ),
						'galleryHelp'      => __( 'Le foto e il loro ordine si gestiscono con il sistema Gallerie media del CMS.', 'telecomsecurity-child-theme' ),
						'manageGallery'    => __( 'Aggiungi, rimuovi o riordina le foto', 'telecomsecurity-child-theme' ),
						'createGallery'    => __( 'Crea una galleria media', 'telecomsecurity-child-theme' ),
						'permissionNotice' => __( 'Per modificare le gallerie serve un account amministratore.', 'telecomsecurity-child-theme' ),
						'previewEmpty'     => __( 'La galleria non contiene ancora immagini.', 'telecomsecurity-child-theme' ),
					),
				)
			),
			JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
		) . ';',
		'before'
	);
}
add_action( 'admin_enqueue_scripts', 'telecomsecurity_enqueue_about_leader_admin' );

/**
 * Return normalized frontend data for the leader portrait and gallery.
 *
 * @return array{name:string,role:string,portrait_id:int,portrait_alt:string,gallery_id:int,gallery_ids:int[],gallery_alt:array<int,string>,is_visible:bool}
 */
function telecomsecurity_get_about_leader_data(): array {
	$saved       = (array) get_option( 'ts_about_leader', array() );
	$name        = trim( (string) ( $saved['name'] ?? '' ) );
	$role        = trim( (string) ( $saved['role'] ?? '' ) );
	$portrait_id = absint( $saved['portrait_id'] ?? 0 );
	$gallery_id  = absint( $saved['gallery_id'] ?? 0 );
	if ( $portrait_id && function_exists( 'apply_filters' ) ) {
		$portrait_id = absint( apply_filters( 'wpml_object_id', $portrait_id, 'attachment', true ) );
	}
	if ( $portrait_id && ! wp_attachment_is_image( $portrait_id ) ) {
		$portrait_id = 0;
	}

	if ( function_exists( 'icl_t' ) ) {
		$name = (string) apply_filters( 'wpml_translate_single_string', $name, 'Telecom Security — Chi siamo', 'Leader name' );
		$role = (string) apply_filters( 'wpml_translate_single_string', $role, 'Telecom Security — Chi siamo', 'Leader role' );
	} elseif ( function_exists( 'ticinoweb_frontend_text' ) ) {
		$name = (string) ticinoweb_frontend_text( $name, 'theme:about:leader_name' );
		$role = (string) ticinoweb_frontend_text( $role, 'theme:about:leader_role' );
	}

	$source_gallery_ids = $gallery_id && function_exists( 'telecomsecurity_get_media_gallery_attachment_ids' )
		? telecomsecurity_get_media_gallery_attachment_ids( $gallery_id )
		: array();
	$gallery_ids = array();
	foreach ( $source_gallery_ids as $attachment_id ) {
		$attachment_id = absint( $attachment_id );
		if ( function_exists( 'apply_filters' ) ) {
			$attachment_id = absint( apply_filters( 'wpml_object_id', $attachment_id, 'attachment', true ) );
		}
		if ( $attachment_id === $portrait_id || in_array( $attachment_id, $gallery_ids, true ) || ! wp_attachment_is_image( $attachment_id ) ) {
			continue;
		}
		$gallery_ids[] = $attachment_id;
		if ( 6 === count( $gallery_ids ) ) {
			break;
		}
	}
	$gallery_alt = array();
	foreach ( $gallery_ids as $attachment_id ) {
		$gallery_alt[ $attachment_id ] = telecomsecurity_about_leader_image_alt( $attachment_id );
	}

	return array(
		'name'         => $name,
		'role'         => $role,
		'portrait_id'  => $portrait_id,
		'portrait_alt' => $portrait_id ? telecomsecurity_about_leader_image_alt( $portrait_id ) : '',
		'gallery_id'   => $gallery_id,
		'gallery_ids'  => $gallery_ids,
		'gallery_alt'  => $gallery_alt,
		'is_visible'   => '' !== $name && $portrait_id > 0,
	);
}
