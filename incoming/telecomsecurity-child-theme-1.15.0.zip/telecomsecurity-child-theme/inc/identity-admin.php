<?php
/** Editable institutional copy; defaults preserve the existing site text. */
defined('ABSPATH') || exit;
function telecomsecurity_identity_fields(): array {
    return array(
        'hero_label_1' => array('Microetichetta messaggio 1', 'SICUREZZA INTEGRATA · SEMENTINA · DAL 1975'),
        'hero_label_2' => array('Microetichetta messaggio 2', 'SISTEMI INTEGRATI · TICINO'),
        'hero_label_3' => array('Microetichetta messaggio 3', 'DAL 1975 · SEMENTINA'),
        'intro_label' => array('Etichetta introduzione', 'Visione Integrata'),
        'intro_title' => array('Titolo introduzione', 'Proteggere uno spazio significa mettere ogni tecnologia nella condizione di lavorare insieme.'),
        'intro_text' => array('Testo introduzione', 'Telecom Security SA progetta e coordina impianti su misura per abitazioni, aziende ed enti pubblici in tutto il Canton Ticino, fondendo videosorveglianza, antintrusione, reti radio, antincendio e automazioni in un unico ecosistema affidabile e controllato.'),
        'fact_1_title' => array('Dato aziendale 1', 'Dal 1975'),
        'fact_1_text' => array('Descrizione dato 1', 'Oltre cinquant’anni di presenza costante sul territorio ticinese'),
        'fact_1_label' => array('Microetichetta dato 1', '01 / ESPERIENZA'),
        'fact_2_title' => array('Dato aziendale 2', 'Sementina'),
        'fact_2_text' => array('Descrizione dato 2', 'Sede operativa, laboratorio e assistenza nella Zona Industriale'),
        'fact_2_label' => array('Microetichetta dato 2', '02 / PRESENZA'),
        'fact_3_title' => array('Dato aziendale 3', 'Sicurezza Integrata'),
        'fact_3_text' => array('Descrizione dato 3', 'Sistemi coordinati con certificazione ISO 9001:2015 e omologazione VKF'),
        'fact_3_label' => array('Microetichetta dato 3', '03 / STANDARD'),
        'fact_3_badge_1' => array('Etichetta standard 1', 'ISO 9001:2015'),
        'fact_3_badge_2' => array('Etichetta standard 2', 'OMOLOGAZIONE VKF'),
        'cta_label' => array('Etichetta contatti', 'Parla con un Tecnico'),
        'cta_title' => array('Titolo contatti', 'Pronti a proteggere i vostri spazi con tecnologie d’avanguardia?'),
        'cta_text' => array('Introduzione contatti', 'I nostri tecnici a Sementina sono a disposizione per analizzare la vostra proprietà e sviluppare una soluzione di sicurezza integrata personalizzata.'),
        'cta_button' => array('Pulsante contatti', 'Richiedi un sopralluogo preliminare'),
        'footer_text' => array('Testo footer', 'Sicurezza integrata, telecomunicazioni e automazioni professionali in Ticino. Qualità svizzera ed esperienza sul campo dal 1975.'),
        'footer_cert' => array('Qualifiche footer', 'Certificazione ISO 9001:2015 · Omologazione VKF'),
    );
}
function telecomsecurity_identity(string $key): string {
    $saved = get_option('ts_security_identity', array());
    return (string) ($saved[$key] ?? telecomsecurity_identity_fields()[$key][1] ?? '');
}
add_action('admin_init', function () {
    register_setting('ts_identity', 'ts_security_identity', array('type'=>'array', 'sanitize_callback'=>function ($input) {
        $saved = (array) get_option('ts_security_identity', array());
        if (!is_array($input)) return $saved;
        foreach (telecomsecurity_identity_fields() as $key => $field) {
            if (isset($input[$key]) && is_string($input[$key])) $saved[$key] = sanitize_textarea_field($input[$key]);
        }
        return $saved;
    }));
});
add_action('admin_menu', function () {
    add_theme_page('Identità Telecom Security', 'Identità Telecom Security', 'manage_options', 'ts-security-identity', function () {
        if (!current_user_can('manage_options')) return;
        echo '<div class="wrap"><h1>Identità Telecom Security</h1><p>Testi istituzionali e dati aziendali. Inserire solamente informazioni aziendali documentate.</p><form method="post" action="options.php">';
        settings_fields('ts_identity');
        echo '<table class="form-table">';
        foreach (telecomsecurity_identity_fields() as $key => $field) {
            echo '<tr><th><label for="ts-' . esc_attr($key) . '">' . esc_html($field[0]) . '</label></th><td><textarea class="large-text" rows="2" id="ts-' . esc_attr($key) . '" name="ts_security_identity[' . esc_attr($key) . ']">' . esc_textarea(telecomsecurity_identity($key)) . '</textarea></td></tr>';
        }
        echo '</table>'; submit_button(); echo '</form></div>';
    });
});
