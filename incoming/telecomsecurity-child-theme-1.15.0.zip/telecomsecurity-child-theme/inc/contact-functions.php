<?php
/**
 * Contact page data, validation, abuse protection and mail delivery.
 *
 * @package TelecomSecurityChild
 */

defined( 'ABSPATH' ) || exit;

/** Return whether the dedicated contact page is being rendered. */
function telecomsecurity_contact_is_page(): bool {
	return is_page( 'contatti' );
}

/** Canonical request types and their server-owned requirements. */
function telecomsecurity_contact_request_types(): array {
	return array(
		'new_system'  => array(
			'label'             => __( 'Nuovo impianto o sopralluogo', 'telecomsecurity-child-theme' ),
			'requires_phone'    => true,
			'requires_service'  => true,
			'requires_location' => true,
			'attachment'        => true,
		),
		'support'     => array(
			'label'             => __( 'Assistenza su un impianto esistente', 'telecomsecurity-child-theme' ),
			'requires_phone'    => true,
			'requires_service'  => true,
			'requires_location' => true,
			'attachment'        => true,
		),
		'maintenance' => array(
			'label'             => __( 'Manutenzione o ampliamento', 'telecomsecurity-child-theme' ),
			'requires_phone'    => true,
			'requires_service'  => true,
			'requires_location' => true,
			'attachment'        => true,
		),
		'general'     => array(
			'label'             => __( 'Informazioni generali', 'telecomsecurity-child-theme' ),
			'requires_phone'    => false,
			'requires_service'  => false,
			'requires_location' => false,
			'attachment'        => false,
		),
	);
}

/** Canonical property types for new installations. */
function telecomsecurity_contact_property_types(): array {
	return array(
		'home'       => __( 'Abitazione', 'telecomsecurity-child-theme' ),
		'condo'      => __( 'Condominio', 'telecomsecurity-child-theme' ),
		'office'     => __( 'Ufficio o studio', 'telecomsecurity-child-theme' ),
		'shop'       => __( 'Negozio o attività', 'telecomsecurity-child-theme' ),
		'industrial' => __( 'Stabile produttivo', 'telecomsecurity-child-theme' ),
		'public'     => __( 'Ente pubblico', 'telecomsecurity-child-theme' ),
		'other'      => __( 'Altro', 'telecomsecurity-child-theme' ),
	);
}

/** Published services from the existing CMS collection, in its canonical order. */
function telecomsecurity_contact_services(): array {
	if ( ! function_exists( 'telecomsecurity_get_services_explorer_data' ) ) {
		return array();
	}

	$published = array();
	foreach ( (array) telecomsecurity_get_services_explorer_data() as $service ) {
		$page_id = absint( $service['page_id'] ?? 0 );
		$title   = trim( wp_strip_all_tags( (string) ( $service['title'] ?? '' ) ) );
		$id      = sanitize_key( (string) ( $service['id'] ?? '' ) );
		if ( ! $page_id || 'publish' !== get_post_status( $page_id ) || '' === $title || '' === $id ) {
			continue;
		}
		$published[] = array(
			'id'      => $id,
			'page_id' => $page_id,
			'title'   => $title,
			'url'     => esc_url_raw( (string) ( $service['url'] ?? '' ) ),
		);
	}

	return $published;
}

/** Convert a Swiss display number into a safe tel: value. */
function telecomsecurity_contact_phone_href( string $phone ): string {
	$phone = preg_replace( '/[^0-9+]/', '', $phone ) ?: '';
	if ( str_starts_with( $phone, '00' ) ) {
		$phone = '+' . substr( $phone, 2 );
	} elseif ( str_starts_with( $phone, '0' ) ) {
		$phone = '+41' . substr( $phone, 1 );
	}
	return $phone;
}

/** True when configured opening hours contain actual public information. */
function telecomsecurity_contact_has_meaningful_hours( array $hours, string $note ): bool {
	if ( '' !== trim( $note ) ) {
		return true;
	}
	foreach ( $hours as $day ) {
		if ( ! is_array( $day ) || ! empty( $day['closed'] ) ) {
			continue;
		}
		if ( ! empty( $day['open_24h'] ) || ! empty( $day['slots'] ) ) {
			return true;
		}
	}
	return false;
}

/** Dynamic company and contact data from the existing ticinoWEB CMS. */
function telecomsecurity_contact_data(): array {
	$cms       = function_exists( 'ticinoweb_get_contact_info' ) ? (array) ticinoweb_get_contact_info() : array();
	$site_name = trim( (string) get_bloginfo( 'name' ) );
	$company   = preg_match( '/\bSA$/i', $site_name ) ? $site_name : sprintf( __( '%s SA', 'telecomsecurity-child-theme' ), $site_name );
	$email     = sanitize_email( (string) ( $cms['email'] ?? get_option( 'ticinoweb_contact_email', '' ) ) );
	$recipient = is_email( $email ) ? $email : sanitize_email( (string) get_option( 'admin_email', '' ) );
	$phone     = trim( (string) ( $cms['phone_landline'] ?? '' ) );
	if ( '' === $phone ) {
		$phone = trim( (string) ( $cms['phone'] ?? get_option( 'ticinoweb_contact_phone_landline', '' ) ) );
	}
	$address    = trim( (string) ( $cms['address'] ?? get_option( 'ticinoweb_contact_address', '' ) ) );
	$hours      = is_array( $cms['opening_hours'] ?? null ) ? $cms['opening_hours'] : array();
	$hours_note = trim( (string) ( $cms['opening_hours_note'] ?? '' ) );
	if ( ! telecomsecurity_contact_has_meaningful_hours( $hours, $hours_note ) ) {
		$hours      = array();
		$hours_note = '';
	}
	$directions = esc_url_raw( (string) get_option( 'ticinoweb_google_business_link', '' ) );
	if ( '' === $directions && '' !== $address ) {
		$directions = 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $address );
	}

	return array(
		'company'        => '' !== $company ? $company : __( 'Telecom Security SA', 'telecomsecurity-child-theme' ),
		'address'        => $address,
		'phone'          => $phone,
		'phone_href'     => telecomsecurity_contact_phone_href( $phone ),
		'email'          => $email,
		'recipient'      => $recipient,
		'hours'          => $hours,
		'hours_note'     => $hours_note,
		'directions_url' => $directions,
		'privacy_url'    => esc_url_raw( (string) get_privacy_policy_url() ),
		'hero_label'     => __( 'CONTATTI', 'telecomsecurity-child-theme' ),
		'hero_title'     => __( 'Parliamo del tuo progetto.', 'telecomsecurity-child-theme' ),
		'hero_text'      => __( 'Raccontaci cosa desideri proteggere o quale impianto necessita assistenza. Ti indirizzeremo verso il tecnico più adatto.', 'telecomsecurity-child-theme' ),
	);
}

/** Timestamp fields used by the minimum-completion-time check. */
function telecomsecurity_contact_security_fields( ?int $timestamp = null ): array {
	$timestamp = $timestamp ?? time();
	return array(
		'ts_contact_started'           => (string) $timestamp,
		'ts_contact_started_signature' => wp_hash( $timestamp . '|telecomsecurity_contact_started', 'nonce' ),
	);
}

/** Unicode-safe string length. */
function telecomsecurity_contact_text_length( string $value ): int {
	return function_exists( 'mb_strlen' ) ? mb_strlen( $value, 'UTF-8' ) : strlen( $value );
}

/** Build a validation error with per-field details. */
function telecomsecurity_contact_error( string $code, string $message, array $fields = array(), array $values = array() ): WP_Error {
	return new WP_Error(
		$code,
		$message,
		array(
			'fields' => $fields,
			'values' => $values,
		)
	);
}

/** Normalize submitted scalar text without trusting hidden browser state. */
function telecomsecurity_contact_source_text( array $source, string $key, bool $textarea = false ): string {
	$value = isset( $source[ $key ] ) && is_scalar( $source[ $key ] ) ? wp_unslash( (string) $source[ $key ] ) : '';
	return $textarea ? sanitize_textarea_field( $value ) : sanitize_text_field( $value );
}

/**
 * Derive the source page on the server and accept only same-site referers.
 *
 * A browser-submitted hidden URL is deliberately ignored because hidden fields
 * are user-controlled input too.
 */
function telecomsecurity_contact_source_url(): string {
	$fallback      = home_url( '/contatti/' );
	$referer       = esc_url_raw( (string) wp_get_referer() );
	$referer_host  = strtolower( (string) wp_parse_url( $referer, PHP_URL_HOST ) );
	$site_host     = strtolower( (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) );

	return $referer && $referer_host && hash_equals( $site_host, $referer_host ) ? $referer : $fallback;
}

/** Validate and normalize a contact request. */
function telecomsecurity_contact_validate( array $source, array $files = array() ) {
	$nonce = telecomsecurity_contact_source_text( $source, 'ts_contact_nonce' );
	if ( ! wp_verify_nonce( $nonce, 'telecomsecurity_contact_submit' ) ) {
		return telecomsecurity_contact_error( 'security', __( 'La sessione è scaduta. Ricarica la pagina e riprova.', 'telecomsecurity-child-theme' ) );
	}

	if ( '' !== telecomsecurity_contact_source_text( $source, 'ts_contact_website' ) ) {
		return telecomsecurity_contact_error( 'spam', __( 'La richiesta non ha superato il controllo antispam.', 'telecomsecurity-child-theme' ) );
	}

	$started   = absint( $source['ts_contact_started'] ?? 0 );
	$signature = telecomsecurity_contact_source_text( $source, 'ts_contact_started_signature' );
	$expected  = wp_hash( $started . '|telecomsecurity_contact_started', 'nonce' );
	if ( ! $started || ! hash_equals( $expected, $signature ) ) {
		return telecomsecurity_contact_error( 'security', __( 'La sessione del modulo non è valida. Ricarica la pagina e riprova.', 'telecomsecurity-child-theme' ) );
	}
	$elapsed = time() - $started;
	if ( $elapsed < 3 ) {
		return telecomsecurity_contact_error( 'timing', __( 'Attendi qualche secondo prima di inviare la richiesta.', 'telecomsecurity-child-theme' ) );
	}
	if ( $elapsed > 2 * HOUR_IN_SECONDS ) {
		return telecomsecurity_contact_error( 'security', __( 'Il modulo è scaduto. Ricarica la pagina e riprova.', 'telecomsecurity-child-theme' ) );
	}

	$request_types = telecomsecurity_contact_request_types();
	$request_type  = sanitize_key( telecomsecurity_contact_source_text( $source, 'ts_contact_request_type' ) );
	$name          = telecomsecurity_contact_source_text( $source, 'ts_contact_name' );
	$company       = telecomsecurity_contact_source_text( $source, 'ts_contact_company' );
	$email         = sanitize_email( telecomsecurity_contact_source_text( $source, 'ts_contact_email' ) );
	$phone         = telecomsecurity_contact_source_text( $source, 'ts_contact_phone' );
	$message       = telecomsecurity_contact_source_text( $source, 'ts_contact_message', true );
	$privacy       = telecomsecurity_contact_source_text( $source, 'ts_contact_privacy' );
	$errors        = array();

	if ( ! isset( $request_types[ $request_type ] ) ) {
		$errors['request_type'] = __( 'Seleziona il tipo di richiesta.', 'telecomsecurity-child-theme' );
	}
	if ( telecomsecurity_contact_text_length( $name ) < 2 || telecomsecurity_contact_text_length( $name ) > 120 ) {
		$errors['name'] = __( 'Inserisci nome e cognome.', 'telecomsecurity-child-theme' );
	}
	if ( telecomsecurity_contact_text_length( $company ) > 160 ) {
		$errors['company'] = __( 'Il nome dell’azienda è troppo lungo.', 'telecomsecurity-child-theme' );
	}
	if ( ! is_email( $email ) || telecomsecurity_contact_text_length( $email ) > 190 ) {
		$errors['email'] = __( 'Inserisci un indirizzo email valido.', 'telecomsecurity-child-theme' );
	}
	if ( telecomsecurity_contact_text_length( $phone ) > 50 ) {
		$errors['phone'] = __( 'Inserisci un numero di telefono valido.', 'telecomsecurity-child-theme' );
	}
	if ( telecomsecurity_contact_text_length( $message ) < 10 ) {
		$errors['message'] = __( 'Descrivi brevemente la tua richiesta.', 'telecomsecurity-child-theme' );
	} elseif ( telecomsecurity_contact_text_length( $message ) > 5000 ) {
		$errors['message'] = __( 'Il messaggio è troppo lungo: massimo 5000 caratteri.', 'telecomsecurity-child-theme' );
	}
	if ( '1' !== $privacy && 'on' !== $privacy ) {
		$errors['privacy'] = __( 'Devi accettare l’informativa sulla privacy.', 'telecomsecurity-child-theme' );
	}

	$service           = '';
	$service_label     = '';
	$property_type     = '';
	$property_label    = '';
	$existing_customer = '';
	$location          = '';
	if ( isset( $request_types[ $request_type ] ) && 'general' !== $request_type ) {
		$phone = trim( $phone );
		if ( '' === $phone ) {
			$errors['phone'] = __( 'Inserisci un numero di telefono.', 'telecomsecurity-child-theme' );
		}

		$location = telecomsecurity_contact_source_text( $source, 'ts_contact_location' );
		if ( '' === $location || telecomsecurity_contact_text_length( $location ) > 160 ) {
			$errors['location'] = __( 'Inserisci la località dell’intervento.', 'telecomsecurity-child-theme' );
		}

		$service = sanitize_key( telecomsecurity_contact_source_text( $source, 'ts_contact_service' ) );
		if ( 'advice' === $service ) {
			$service_label = __( 'Non sono sicuro / Vorrei un consiglio', 'telecomsecurity-child-theme' );
		} else {
			foreach ( telecomsecurity_contact_services() as $candidate ) {
				if ( $candidate['id'] === $service ) {
					$service_label = $candidate['title'];
					break;
				}
			}
		}
		if ( '' === $service_label ) {
			$errors['service'] = __( 'Seleziona il servizio o chiedi un consiglio.', 'telecomsecurity-child-theme' );
		}

		if ( 'new_system' === $request_type ) {
			$property_type = sanitize_key( telecomsecurity_contact_source_text( $source, 'ts_contact_property_type' ) );
			$properties    = telecomsecurity_contact_property_types();
			if ( ! isset( $properties[ $property_type ] ) ) {
				$errors['property_type'] = __( 'Seleziona il tipo di immobile.', 'telecomsecurity-child-theme' );
			} else {
				$property_label = $properties[ $property_type ];
			}
		}

		if ( in_array( $request_type, array( 'support', 'maintenance' ), true ) ) {
			$existing_customer = sanitize_key( telecomsecurity_contact_source_text( $source, 'ts_contact_existing_customer' ) );
			if ( ! in_array( $existing_customer, array( 'yes', 'no' ), true ) ) {
				$errors['existing_customer'] = __( 'Indica se sei già cliente.', 'telecomsecurity-child-theme' );
			}
		}
	}

	$values = array(
		'request_type'              => $request_type,
		'request_type_label'        => $request_types[ $request_type ]['label'] ?? '',
		'name'                      => $name,
		'company'                   => $company,
		'email'                     => $email,
		'phone'                     => $phone,
		'message'                   => $message,
		'privacy'                   => in_array( $privacy, array( '1', 'on' ), true ),
		'service'                   => $service,
		'service_label'             => $service_label,
		'property_type'             => $property_type,
		'property_label'            => $property_label,
		'existing_customer'         => $existing_customer,
		'existing_customer_label'   => 'yes' === $existing_customer ? __( 'Sì', 'telecomsecurity-child-theme' ) : ( 'no' === $existing_customer ? __( 'No', 'telecomsecurity-child-theme' ) : '' ),
		'location'                  => $location,
		'source_url'                => telecomsecurity_contact_source_url(),
	);

	if ( $errors ) {
		return telecomsecurity_contact_error( 'invalid', __( 'Controlla i campi indicati e riprova.', 'telecomsecurity-child-theme' ), $errors, $values );
	}

	return $values;
}

/** Hashed rate-limit keys. No raw IP address or email is stored. */
function telecomsecurity_contact_rate_keys( string $email ): array {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( (string) $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
	return array(
		'ts_contact_rate_ip_' . substr( wp_hash( $ip . '|ts-contact-ip' ), 0, 32 ),
		'ts_contact_rate_email_' . substr( wp_hash( strtolower( $email ) . '|ts-contact-email' ), 0, 32 ),
	);
}

/** Increment request counters or return a rate-limit error. */
function telecomsecurity_contact_reserve_rate( string $email ) {
	$keys = telecomsecurity_contact_rate_keys( $email );
	foreach ( $keys as $key ) {
		if ( (int) get_transient( $key ) >= 3 ) {
			return new WP_Error( 'rate_limited', __( 'Hai effettuato troppi invii in poco tempo. Attendi qualche minuto e riprova.', 'telecomsecurity-child-theme' ) );
		}
	}
	foreach ( $keys as $key ) {
		set_transient( $key, (int) get_transient( $key ) + 1, 15 * MINUTE_IN_SECONDS );
	}
	return true;
}

/** Reserve a short-lived fingerprint to prevent accidental duplicate sends. */
function telecomsecurity_contact_reserve_duplicate( array $data ) {
	$fingerprint = array(
		$data['request_type'],
		strtolower( $data['email'] ),
		$data['phone'],
		$data['service'],
		$data['location'],
		$data['message'],
	);
	$key = 'ts_contact_duplicate_' . substr( wp_hash( implode( '|', $fingerprint ) ), 0, 40 );
	if ( get_transient( $key ) ) {
		return new WP_Error( 'duplicate', __( 'Questa richiesta risulta già inviata. Attendi qualche minuto prima di riprovare.', 'telecomsecurity-child-theme' ) );
	}
	set_transient( $key, 1, 10 * MINUTE_IN_SECONDS );
	return $key;
}

/** Validate an optional upload without persisting it in the Media Library. */
function telecomsecurity_contact_validate_attachment( array $file, string $request_type ) {
	if ( ! isset( $file['error'] ) || UPLOAD_ERR_NO_FILE === (int) $file['error'] ) {
		return null;
	}
	$request_types = telecomsecurity_contact_request_types();
	if ( empty( $request_types[ $request_type ]['attachment'] ) ) {
		return new WP_Error( 'attachment_type', __( 'Gli allegati non sono previsti per questo tipo di richiesta.', 'telecomsecurity-child-theme' ) );
	}
	if ( UPLOAD_ERR_OK !== (int) $file['error'] ) {
		return new WP_Error( 'attachment_upload', __( 'Non è stato possibile caricare l’allegato. Riprova.', 'telecomsecurity-child-theme' ) );
	}
	$tmp_name = isset( $file['tmp_name'] ) ? (string) $file['tmp_name'] : '';
	$name     = sanitize_file_name( (string) ( $file['name'] ?? '' ) );
	if ( '' === $tmp_name || '' === $name || ! is_file( $tmp_name ) ) {
		return new WP_Error( 'attachment_upload', __( 'L’allegato non è valido.', 'telecomsecurity-child-theme' ) );
	}
	$is_uploaded = (bool) apply_filters( 'telecomsecurity_contact_is_uploaded_file', is_uploaded_file( $tmp_name ), $tmp_name );
	if ( ! $is_uploaded ) {
		return new WP_Error( 'attachment_upload', __( 'L’allegato non proviene da un caricamento valido.', 'telecomsecurity-child-theme' ) );
	}
	$actual_size = filesize( $tmp_name );
	$given_size  = absint( $file['size'] ?? 0 );
	$size        = max( false === $actual_size ? 0 : (int) $actual_size, $given_size );
	if ( $size <= 0 || $size > 8 * MB_IN_BYTES ) {
		return new WP_Error( 'attachment_size', __( 'L’allegato deve avere una dimensione massima di 8 MB.', 'telecomsecurity-child-theme' ) );
	}

	$allowed = array(
		'pdf'          => 'application/pdf',
		'jpg|jpeg|jpe' => 'image/jpeg',
		'png'          => 'image/png',
	);
	$checked = wp_check_filetype_and_ext( $tmp_name, $name, $allowed );
	$type    = (string) ( $checked['type'] ?? '' );
	$ext     = (string) ( $checked['ext'] ?? '' );
	if ( '' === $type || '' === $ext || ! in_array( $type, array_values( $allowed ), true ) ) {
		return new WP_Error( 'attachment_type', __( 'Formato non consentito. Usa PDF, JPG, JPEG o PNG.', 'telecomsecurity-child-theme' ) );
	}

	if ( class_exists( 'finfo' ) ) {
		$finfo     = new finfo( FILEINFO_MIME_TYPE );
		$real_type = (string) $finfo->file( $tmp_name );
		$aliases   = array(
			'application/pdf' => array( 'application/pdf' ),
			'image/jpeg'      => array( 'image/jpeg', 'image/pjpeg' ),
			'image/png'       => array( 'image/png' ),
		);
		if ( ! in_array( $real_type, $aliases[ $type ] ?? array(), true ) ) {
			return new WP_Error( 'attachment_type', __( 'Il contenuto del file non corrisponde al formato dichiarato.', 'telecomsecurity-child-theme' ) );
		}
	}

	return array(
		'name'     => $name,
		'tmp_name' => $tmp_name,
		'type'     => $type,
		'size'     => $size,
	);
}

/** Copy a validated upload to a private temporary mail attachment. */
function telecomsecurity_contact_prepare_attachment( array $attachment ) {
	$temp_path = wp_tempnam( $attachment['name'] );
	if ( ! $temp_path || ! copy( $attachment['tmp_name'], $temp_path ) ) {
		if ( $temp_path && is_file( $temp_path ) ) {
			unlink( $temp_path );
		}
		return new WP_Error( 'attachment_upload', __( 'Non è stato possibile preparare l’allegato per l’invio.', 'telecomsecurity-child-theme' ) );
	}
	@chmod( $temp_path, 0600 );
	return array(
		'name' => $attachment['name'],
		'path' => $temp_path,
	);
}

/** Derive a domain-owned From address without trusting user input. */
function telecomsecurity_contact_from_email( string $recipient ): string {
	$method = sanitize_key( (string) get_option( 'ticinoweb_email_method', 'default' ) );
	if ( 'smtp' === $method ) {
		$configured = sanitize_email( (string) get_option( 'ticinoweb_smtp_from_email', '' ) );
		if ( is_email( $configured ) ) {
			return $configured;
		}
	}
	if ( 'sendgrid' === $method ) {
		$configured = sanitize_email( (string) get_option( 'ticinoweb_sendgrid_from_email', '' ) );
		if ( is_email( $configured ) ) {
			return $configured;
		}
	}
	$parts = explode( '@', $recipient );
	$from  = 2 === count( $parts ) ? 'wordpress@' . strtolower( $parts[1] ) : '';
	return is_email( $from ) ? $from : sanitize_email( (string) get_option( 'admin_email', '' ) );
}

/** Send one validated request through the existing WordPress mail transport. */
function telecomsecurity_contact_send( array $data, ?array $attachment = null ): bool {
	$contact   = telecomsecurity_contact_data();
	$recipient = sanitize_email( (string) $contact['recipient'] );
	if ( ! is_email( $recipient ) ) {
		return false;
	}

	$subject = sprintf( '[Telecom Security] %s', $data['request_type_label'] );
	if ( '' !== $data['service_label'] ) {
		$subject .= ' – ' . $data['service_label'];
	}
	$lines = array(
		__( 'Data e ora', 'telecomsecurity-child-theme' ) . ': ' . wp_date( 'Y-m-d H:i:s' ),
		__( 'Tipo di richiesta', 'telecomsecurity-child-theme' ) . ': ' . $data['request_type_label'],
		__( 'Nome e cognome', 'telecomsecurity-child-theme' ) . ': ' . $data['name'],
	);
	$optional = array(
		__( 'Azienda', 'telecomsecurity-child-theme' )              => $data['company'],
		__( 'Email', 'telecomsecurity-child-theme' )                => $data['email'],
		__( 'Telefono', 'telecomsecurity-child-theme' )             => $data['phone'],
		__( 'Già cliente', 'telecomsecurity-child-theme' )          => $data['existing_customer_label'],
		__( 'Servizio', 'telecomsecurity-child-theme' )             => $data['service_label'],
		__( 'Tipo di immobile', 'telecomsecurity-child-theme' )     => $data['property_label'],
		__( 'Località intervento', 'telecomsecurity-child-theme' )  => $data['location'],
	);
	foreach ( $optional as $label => $value ) {
		if ( '' !== trim( (string) $value ) ) {
			$lines[] = $label . ': ' . $value;
		}
	}
	if ( $attachment ) {
		$lines[] = __( 'Allegato', 'telecomsecurity-child-theme' ) . ': ' . $attachment['name'];
	}
	$lines[] = '';
	$lines[] = __( 'Messaggio', 'telecomsecurity-child-theme' ) . ':';
	$lines[] = $data['message'];
	$lines[] = '';
	$lines[] = __( 'Pagina di provenienza', 'telecomsecurity-child-theme' ) . ': ' . $data['source_url'];

	$from_email = telecomsecurity_contact_from_email( $recipient );
	$from_name  = trim( preg_replace( '/[\r\n]+/', ' ', (string) get_bloginfo( 'name' ) ) ?: 'Telecom Security' );
	$headers    = array(
		'Content-Type: text/plain; charset=UTF-8',
		'From: ' . $from_name . ' <' . $from_email . '>',
		'Reply-To: ' . $data['email'],
	);
	$attachments = $attachment ? array( $attachment['path'] ) : array();

	return (bool) wp_mail( $recipient, $subject, implode( "\n", $lines ), $headers, $attachments );
}

/** Validate, reserve abuse guards, prepare the attachment and send. */
function telecomsecurity_contact_process( array $source, array $files = array() ) {
	$data = telecomsecurity_contact_validate( $source, $files );
	if ( is_wp_error( $data ) ) {
		return $data;
	}

	$file      = isset( $files['ts_contact_attachment'] ) && is_array( $files['ts_contact_attachment'] ) ? $files['ts_contact_attachment'] : array( 'error' => UPLOAD_ERR_NO_FILE );
	$validated = telecomsecurity_contact_validate_attachment( $file, $data['request_type'] );
	if ( is_wp_error( $validated ) ) {
		return telecomsecurity_contact_error( $validated->get_error_code(), $validated->get_error_message(), array( 'attachment' => $validated->get_error_message() ), $data );
	}

	$rate = telecomsecurity_contact_reserve_rate( $data['email'] );
	if ( is_wp_error( $rate ) ) {
		return $rate;
	}
	$duplicate_key = telecomsecurity_contact_reserve_duplicate( $data );
	if ( is_wp_error( $duplicate_key ) ) {
		return $duplicate_key;
	}

	$prepared = null;
	if ( is_array( $validated ) ) {
		$prepared = telecomsecurity_contact_prepare_attachment( $validated );
		if ( is_wp_error( $prepared ) ) {
			delete_transient( $duplicate_key );
			return telecomsecurity_contact_error( $prepared->get_error_code(), $prepared->get_error_message(), array( 'attachment' => $prepared->get_error_message() ), $data );
		}
	}

	$sent = false;
	try {
		$sent = telecomsecurity_contact_send( $data, $prepared );
	} finally {
		if ( is_array( $prepared ) && ! empty( $prepared['path'] ) && is_file( $prepared['path'] ) ) {
			unlink( $prepared['path'] );
		}
	}

	if ( ! $sent ) {
		delete_transient( $duplicate_key );
		$request_id = substr( wp_hash( $data['email'] . '|' . $data['request_type'] . '|' . time() ), 0, 12 );
		error_log( 'Telecom Security contact mail failed [request=' . $request_id . ']' );
		return telecomsecurity_contact_error( 'mail', __( 'Non è stato possibile inviare la richiesta. Riprova oppure contattaci telefonicamente.', 'telecomsecurity-child-theme' ), array(), $data );
	}

	return array(
		'sent'               => true,
		'request_type'       => $data['request_type'],
		'request_type_label' => $data['request_type_label'],
		'service_label'      => $data['service_label'],
		'email'              => $data['email'],
	);
}

/** Request-local result for the no-JavaScript same-page POST fallback. */
function telecomsecurity_contact_submission_result() {
	return $GLOBALS['telecomsecurity_contact_submission_result'] ?? null;
}

/** Request-local values used to repopulate a failed same-page POST. */
function telecomsecurity_contact_submission_source(): array {
	return isset( $GLOBALS['telecomsecurity_contact_submission_source'] ) && is_array( $GLOBALS['telecomsecurity_contact_submission_source'] )
		? $GLOBALS['telecomsecurity_contact_submission_source']
		: array();
}

/** Process a traditional same-page submission before template rendering. */
function telecomsecurity_contact_handle_page_post(): void {
	if ( ! telecomsecurity_contact_is_page() || wp_doing_ajax() || 'POST' !== strtoupper( (string) ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) || ! isset( $_POST['ts_contact_submit'] ) ) {
		return;
	}
	$GLOBALS['telecomsecurity_contact_submission_source'] = wp_unslash( $_POST );
	$GLOBALS['telecomsecurity_contact_submission_result'] = telecomsecurity_contact_process( $_POST, $_FILES );
}
add_action( 'template_redirect', 'telecomsecurity_contact_handle_page_post', 5 );

/** Return a fresh nonce and signed start time for cached-page-safe AJAX use. */
function telecomsecurity_contact_ajax_token(): void {
	nocache_headers();
	wp_send_json_success(
		array_merge(
			array( 'nonce' => wp_create_nonce( 'telecomsecurity_contact_submit' ) ),
			telecomsecurity_contact_security_fields()
		)
	);
}
add_action( 'wp_ajax_nopriv_telecomsecurity_contact_token', 'telecomsecurity_contact_ajax_token' );
add_action( 'wp_ajax_telecomsecurity_contact_token', 'telecomsecurity_contact_ajax_token' );

/** AJAX transport over the same processing service as the no-JS path. */
function telecomsecurity_contact_ajax_submit(): void {
	nocache_headers();
	if ( 'POST' !== strtoupper( (string) ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) ) {
		wp_send_json_error( array( 'message' => __( 'Metodo non consentito.', 'telecomsecurity-child-theme' ) ), 405 );
	}
	$result = telecomsecurity_contact_process( $_POST, $_FILES );
	if ( is_wp_error( $result ) ) {
		$status = match ( $result->get_error_code() ) {
			'security', 'spam', 'timing' => 403,
			'rate_limited'                => 429,
			'mail'                        => 500,
			default                       => 422,
		};
		$data            = is_array( $result->get_error_data() ) ? $result->get_error_data() : array();
		$data['message'] = $result->get_error_message();
		$data['code']    = $result->get_error_code();
		wp_send_json_error( $data, $status );
	}
	wp_send_json_success( $result );
}
add_action( 'wp_ajax_nopriv_telecomsecurity_contact_submit', 'telecomsecurity_contact_ajax_submit' );
add_action( 'wp_ajax_telecomsecurity_contact_submit', 'telecomsecurity_contact_ajax_submit' );
