<?php
/**
 * Structured data and helpers for the existing service pages.
 *
 * @package TelecomSecurityChild
 */

defined( 'ABSPATH' ) || exit;

const TELECOMSECURITY_SERVICE_META_KEY = '_ts_service_content';

/**
 * Return the service context derived from the existing CMS relationship.
 *
 * @param int $page_id Page ID. Defaults to the queried object.
 * @return array<string,mixed>
 */
function telecomsecurity_get_service_context( int $page_id = 0 ): array {
	$page_id = $page_id ?: get_queried_object_id();
	if ( ! $page_id || ! function_exists( 'telecomsecurity_get_services_explorer_data' ) ) {
		return array();
	}

	$services = telecomsecurity_get_services_explorer_data();
	foreach ( $services as $position => $service ) {
		if ( $page_id !== absint( $service['page_id'] ?? 0 ) ) {
			continue;
		}

		return array(
			'current'    => $service,
			'services'   => $services,
			'position'   => $position,
			'previous'   => $position > 0 ? $services[ $position - 1 ] : null,
			'next'       => isset( $services[ $position + 1 ] ) ? $services[ $position + 1 ] : null,
			'archive_id' => wp_get_post_parent_id( $page_id ),
		);
	}

	return array();
}

/** Determine whether a page is one of the 11 CMS-linked services. */
function telecomsecurity_is_service_page( int $page_id = 0 ): bool {
	return ! empty( telecomsecurity_get_service_context( $page_id ) );
}

/** Empty shape used by the editor and renderer. */
function telecomsecurity_service_content_defaults(): array {
	return array(
		'overview_title' => '',
		'overview'       => '',
		'includes'       => array(),
		'applications'   => array(),
		'benefits'       => array(),
		'process'        => array(),
		'faqs'           => array(),
		'cta_title'      => '',
		'cta_text'       => '',
		'cta_url'        => '',
		'related_ids'    => array(),
	);
}

/** Sanitize title/description repeater rows and discard empty items. */
function telecomsecurity_sanitize_service_rows( $rows, int $limit = 8 ): array {
	$clean = array();
	foreach ( array_slice( is_array( $rows ) ? $rows : array(), 0, $limit ) as $row ) {
		if ( ! is_array( $row ) ) {
			continue;
		}
		$title       = sanitize_text_field( $row['title'] ?? '' );
		$description = sanitize_textarea_field( $row['description'] ?? '' );
		if ( '' === $title && '' === $description ) {
			continue;
		}
		$clean[] = array(
			'title'       => $title,
			'description' => $description,
		);
	}
	return $clean;
}

/** Sanitize FAQ rows and discard empty items. */
function telecomsecurity_sanitize_service_faqs( $rows ): array {
	$clean = array();
	foreach ( array_slice( is_array( $rows ) ? $rows : array(), 0, 8 ) as $row ) {
		if ( ! is_array( $row ) ) {
			continue;
		}
		$question = sanitize_text_field( $row['question'] ?? '' );
		$answer   = sanitize_textarea_field( $row['answer'] ?? '' );
		if ( '' === $question && '' === $answer ) {
			continue;
		}
		$clean[] = array(
			'question' => $question,
			'answer'   => $answer,
		);
	}
	return $clean;
}

/** Sanitize the single structured service payload. */
function telecomsecurity_sanitize_service_content( $value ): array {
	$value = is_array( $value ) ? $value : array();
	$clean = array(
		'overview_title' => sanitize_text_field( $value['overview_title'] ?? '' ),
		'overview'       => sanitize_textarea_field( $value['overview'] ?? '' ),
		'includes'       => telecomsecurity_sanitize_service_rows( $value['includes'] ?? array(), 6 ),
		'applications'   => telecomsecurity_sanitize_service_rows( $value['applications'] ?? array(), 6 ),
		'benefits'       => telecomsecurity_sanitize_service_rows( $value['benefits'] ?? array(), 6 ),
		'process'        => telecomsecurity_sanitize_service_rows( $value['process'] ?? array(), 6 ),
		'faqs'           => telecomsecurity_sanitize_service_faqs( $value['faqs'] ?? array() ),
		'cta_title'      => sanitize_text_field( $value['cta_title'] ?? '' ),
		'cta_text'       => sanitize_textarea_field( $value['cta_text'] ?? '' ),
		'cta_url'        => esc_url_raw( $value['cta_url'] ?? '' ),
		'related_ids'    => array_values( array_unique( array_filter( array_map( 'absint', (array) ( $value['related_ids'] ?? array() ) ) ) ) ),
	);

	return $clean;
}

/** Register service meta for revisions and the block-editor REST API. */
function telecomsecurity_register_service_content_meta(): void {
	add_post_type_support( 'page', 'excerpt' );

	$row_schema = array(
		'type'       => 'object',
		'properties' => array(
			'title'       => array( 'type' => 'string' ),
			'description' => array( 'type' => 'string' ),
		),
	);
	$faq_schema = array(
		'type'       => 'object',
		'properties' => array(
			'question' => array( 'type' => 'string' ),
			'answer'   => array( 'type' => 'string' ),
		),
	);

	register_post_meta(
		'page',
		TELECOMSECURITY_SERVICE_META_KEY,
		array(
			'type'              => 'object',
			'single'            => true,
			'default'           => telecomsecurity_service_content_defaults(),
			'sanitize_callback' => 'telecomsecurity_sanitize_service_content',
			'auth_callback'     => static function ( $allowed, $meta_key, $object_id ): bool {
				return current_user_can( 'edit_post', (int) $object_id );
			},
			'show_in_rest'      => array(
				'schema' => array(
					'type'       => 'object',
					'properties' => array(
						'overview_title' => array( 'type' => 'string' ),
						'overview'       => array( 'type' => 'string' ),
						'includes'       => array( 'type' => 'array', 'items' => $row_schema ),
						'applications'   => array( 'type' => 'array', 'items' => $row_schema ),
						'benefits'       => array( 'type' => 'array', 'items' => $row_schema ),
						'process'        => array( 'type' => 'array', 'items' => $row_schema ),
						'faqs'           => array( 'type' => 'array', 'items' => $faq_schema ),
						'cta_title'      => array( 'type' => 'string' ),
						'cta_text'       => array( 'type' => 'string' ),
						'cta_url'        => array( 'type' => 'string', 'format' => 'uri' ),
						'related_ids'    => array( 'type' => 'array', 'items' => array( 'type' => 'integer' ) ),
					),
				),
			),
			'revisions_enabled' => true,
		)
	);
}
add_action( 'init', 'telecomsecurity_register_service_content_meta', 20 );

/** Return normalized structured data for a service page. */
function telecomsecurity_get_service_content( int $page_id ): array {
	$saved = get_post_meta( $page_id, TELECOMSECURITY_SERVICE_META_KEY, true );
	return wp_parse_args( is_array( $saved ) ? $saved : array(), telecomsecurity_service_content_defaults() );
}

/** Return selected related services, or derive a small deterministic fallback. */
function telecomsecurity_get_related_services( int $page_id, array $context, int $limit = 3 ): array {
	$data      = telecomsecurity_get_service_content( $page_id );
	$services  = $context['services'] ?? array();
	$by_page   = array();
	$current   = $context['current'] ?? array();
	$preferred = array_values( array_unique( array_map( 'absint', $data['related_ids'] ?? array() ) ) );

	foreach ( $services as $service ) {
		$service_page_id = absint( $service['page_id'] ?? 0 );
		if ( $service_page_id && $service_page_id !== $page_id ) {
			$by_page[ $service_page_id ] = $service;
		}
	}

	if ( empty( $preferred ) ) {
		foreach ( $services as $service ) {
			if ( ( $service['area'] ?? '' ) === ( $current['area'] ?? '' ) ) {
				$preferred[] = absint( $service['page_id'] ?? 0 );
			}
		}
	}

	$related = array();
	foreach ( $preferred as $related_id ) {
		if ( isset( $by_page[ $related_id ] ) ) {
			$related[] = $by_page[ $related_id ];
		}
		if ( count( $related ) >= $limit ) {
			break;
		}
	}

	return $related;
}

/** Output editor-authored plain text as safe paragraphs. */
function telecomsecurity_service_text( string $text ): string {
	return wpautop( esc_html( trim( $text ) ) );
}

/** Count readable words for reports and automated verification. */
function telecomsecurity_service_word_count( int $page_id ): int {
	$data = telecomsecurity_get_service_content( $page_id );
	$text = array( get_post_field( 'post_excerpt', $page_id ), $data['overview'], $data['cta_title'], $data['cta_text'] );
	foreach ( array( 'includes', 'applications', 'benefits', 'process' ) as $group ) {
		foreach ( $data[ $group ] as $row ) {
			$text[] = $row['title'];
			$text[] = $row['description'];
		}
	}
	foreach ( $data['faqs'] as $faq ) {
		$text[] = $faq['question'];
		$text[] = $faq['answer'];
	}
	$plain = wp_strip_all_tags( implode( ' ', $text ) );
	return preg_match_all( "/[\p{L}\p{N}]+(?:[’'-][\p{L}\p{N}]+)*/u", $plain ) ?: 0;
}
