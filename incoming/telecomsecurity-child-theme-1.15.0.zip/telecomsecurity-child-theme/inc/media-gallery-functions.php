<?php
/**
 * Read ordered image attachments from the parent theme media galleries.
 *
 * @package TelecomSecurityChild
 */

defined( 'ABSPATH' ) || exit;

/**
 * Return valid image attachment IDs assigned to a CMS gallery.
 *
 * The gallery manager stores membership in the `ticinoweb_media_gallery`
 * taxonomy and its manual sequence in `_ticinoweb_gallery_order` term meta.
 * IDs missing from the saved sequence are appended in their query order.
 *
 * @param int $gallery_id Gallery term ID.
 * @return int[]
 */
function telecomsecurity_get_media_gallery_attachment_ids( int $gallery_id ): array {
	if ( $gallery_id < 1 || ! taxonomy_exists( 'ticinoweb_media_gallery' ) ) {
		return array();
	}

	$attachment_ids = get_posts(
		array(
			'post_type'              => 'attachment',
			'post_status'            => 'inherit',
			'post_mime_type'         => 'image',
			'posts_per_page'         => 500,
			'fields'                 => 'ids',
			'orderby'                => 'ID',
			'order'                  => 'ASC',
			'no_found_rows'          => true,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
			'tax_query'              => array(
				array(
					'taxonomy' => 'ticinoweb_media_gallery',
					'field'    => 'term_id',
					'terms'    => $gallery_id,
				),
			),
		)
	);

	$attachment_ids = array_values( array_filter( array_map( 'absint', $attachment_ids ) ) );
	if ( empty( $attachment_ids ) ) {
		return array();
	}

	$saved_order = get_term_meta( $gallery_id, '_ticinoweb_gallery_order', true );
	if ( ! is_array( $saved_order ) || empty( $saved_order ) ) {
		return $attachment_ids;
	}

	$saved_order = array_values( array_filter( array_map( 'absint', $saved_order ) ) );
	$ordered     = array_values( array_intersect( $saved_order, $attachment_ids ) );
	$remaining   = array_values( array_diff( $attachment_ids, $ordered ) );

	return array_merge( $ordered, $remaining );
}
