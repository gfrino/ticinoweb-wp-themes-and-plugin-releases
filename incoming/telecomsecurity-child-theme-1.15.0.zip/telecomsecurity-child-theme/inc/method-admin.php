<?php
/**
 * Telecom Security — Gestione Backend Sezione "Il nostro metodo"
 *
 * Interfaccia amministrativa intuitiva con repeater riordinabile,
 * integrazione nativa con la Media Library e salvataggio sicuro in opzione unica.
 *
 * @package TelecomSecurityChild
 * @version 1.8.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registra il menu e la pagina amministrativa per Telecom Security.
 */
function telecomsecurity_method_admin_menu(): void {
	// Menu Principale "Telecom Security"
	$hook = add_menu_page(
		__( 'Telecom Security', 'telecomsecurity-child-theme' ),
		__( 'Telecom Security', 'telecomsecurity-child-theme' ),
		'manage_options',
		'telecom-security-admin',
		'telecomsecurity_render_method_admin_page',
		'dashicons-shield',
		31
	);

	// Sottomenu "Metodo di lavoro"
	add_submenu_page(
		'telecom-security-admin',
		__( 'Metodo di lavoro', 'telecomsecurity-child-theme' ),
		__( 'Metodo di lavoro', 'telecomsecurity-child-theme' ),
		'manage_options',
		'telecom-security-admin',
		'telecomsecurity_render_method_admin_page'
	);

	// Carica gli asset solo in questa pagina amministrativa
	add_action( 'admin_enqueue_scripts', function ( $admin_hook ) use ( $hook ) {
		if ( $admin_hook !== $hook && $admin_hook !== 'toplevel_page_telecom-security-admin' ) {
			return;
		}

		wp_enqueue_media();
		wp_enqueue_script( 'jquery-ui-sortable' );
	} );
}
add_action( 'admin_menu', 'telecomsecurity_method_admin_menu' );

/**
 * Salva i dati della sezione su invio del form POST.
 */
function telecomsecurity_method_admin_save(): void {
	if ( ! isset( $_POST['ts_method_save_action'] ) ) {
		return;
	}

	if ( ! check_admin_referer( 'ts_method_save_nonce_action', 'ts_method_save_nonce' ) ) {
		wp_die( esc_html__( 'Verifica di sicurezza non riuscita. Ricarica la pagina e riprova.', 'telecomsecurity-child-theme' ) );
	}

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Permessi insufficienti per eseguire questa operazione.', 'telecomsecurity-child-theme' ) );
	}

	$enabled      = isset( $_POST['ts_method_enabled'] ) ? 1 : 0;
	$eyebrow      = isset( $_POST['ts_method_eyebrow'] ) ? sanitize_text_field( wp_unslash( $_POST['ts_method_eyebrow'] ) ) : 'IL NOSTRO METODO';
	$title        = isset( $_POST['ts_method_title'] ) ? sanitize_text_field( wp_unslash( $_POST['ts_method_title'] ) ) : '';
	$introduction = isset( $_POST['ts_method_introduction'] ) ? sanitize_textarea_field( wp_unslash( $_POST['ts_method_introduction'] ) ) : '';

	// Sanitizzazione passaggi repeater
	$raw_items = isset( $_POST['ts_method_items'] ) && is_array( $_POST['ts_method_items'] ) ? $_POST['ts_method_items'] : array();
	$sanitized_items = array();

	foreach ( $raw_items as $index => $item ) {
		$item_title = isset( $item['title'] ) ? sanitize_text_field( wp_unslash( $item['title'] ) ) : '';
		$item_text  = isset( $item['text'] ) ? sanitize_textarea_field( wp_unslash( $item['text'] ) ) : '';
		$image_id   = isset( $item['image_id'] ) ? absint( $item['image_id'] ) : 0;
		$image_pos  = isset( $item['image_pos'] ) && in_array( $item['image_pos'], array( 'center', 'left', 'right' ), true ) ? $item['image_pos'] : 'center';
		$is_active  = isset( $item['active'] ) ? 1 : 0;
		$stable_id  = isset( $item['id'] ) && ! empty( $item['id'] ) ? sanitize_key( $item['id'] ) : 'step_' . ( $index + 1 ) . '_' . wp_generate_password( 4, false );

		// Se titolo e testo sono vuoti, salta la riga vuota
		if ( empty( $item_title ) && empty( $item_text ) ) {
			continue;
		}

		$sanitized_items[] = array(
			'id'        => $stable_id,
			'active'    => $is_active,
			'title'     => $item_title,
			'text'      => $item_text,
			'url'       => isset( $item['url'] ) ? esc_url_raw( wp_unslash( $item['url'] ) ) : '',
			'image_id'  => $image_id,
			'image_pos' => $image_pos,
		);
	}

	// Sanitizzazione pannello finale
	$final_title    = isset( $_POST['ts_method_final_title'] ) ? sanitize_text_field( wp_unslash( $_POST['ts_method_final_title'] ) ) : '';
	$final_text     = isset( $_POST['ts_method_final_text'] ) ? sanitize_textarea_field( wp_unslash( $_POST['ts_method_final_text'] ) ) : '';
	$final_btn_text = isset( $_POST['ts_method_final_btn_text'] ) ? sanitize_text_field( wp_unslash( $_POST['ts_method_final_btn_text'] ) ) : '';
	$final_page_id  = isset( $_POST['ts_method_final_page_id'] ) ? absint( $_POST['ts_method_final_page_id'] ) : 0;

	$data_to_save = array(
		'enabled'      => $enabled,
		'eyebrow'      => $eyebrow,
		'title'        => $title,
		'introduction' => $introduction,
		'items'        => $sanitized_items,
		'final_panel'  => array(
			'title'    => $final_title,
			'text'     => $final_text,
			'btn_text' => $final_btn_text,
			'page_id'  => $final_page_id,
		),
	);

	update_option( 'ts_home_method_section', $data_to_save );

	// Redirect per evitare doppio invio POST con messaggio di conferma
	wp_safe_redirect( add_query_arg( array( 'page' => 'telecom-security-admin', 'updated' => 'true' ), admin_url( 'admin.php' ) ) );
	exit;
}
add_action( 'admin_init', 'telecomsecurity_method_admin_save' );

/**
 * Renderizza la pagina di gestione nel backend.
 */
function telecomsecurity_render_method_admin_page(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$data     = telecomsecurity_get_method_section_data();
	$items    = $data['items'];
	$defaults = telecomsecurity_get_method_section_defaults();

	// Se items è vuoto (es. prima volta o eliminati tutti), usa default
	if ( empty( $items ) ) {
		$items = $defaults['items'];
	}

	// Elenco pagine per il selettore
	$published_pages = get_pages( array( 'post_status' => 'publish', 'sort_column' => 'post_title' ) );
	?>
	<div class="wrap ts-admin-wrap">
		
		<div class="ts-admin-header">
			<div class="ts-admin-header__brand">
				<span class="ts-admin-badge"><?php esc_html_e( 'TELECOM SECURITY SA', 'telecomsecurity-child-theme' ); ?></span>
				<h1 class="ts-admin-title"><?php esc_html_e( 'Gestione Sezione: Il nostro metodo', 'telecomsecurity-child-theme' ); ?></h1>
			</div>
			<div class="ts-admin-header__meta">
				<span class="ts-admin-pill"><?php esc_html_e( 'Homepage Dynamic Track', 'telecomsecurity-child-theme' ); ?></span>
			</div>
		</div>

		<?php if ( isset( $_GET['updated'] ) && 'true' === $_GET['updated'] ) : ?>
			<div class="notice notice-success is-dismissible ts-admin-notice">
				<p><strong><?php esc_html_e( 'Impostazioni aggiornate con successo!', 'telecomsecurity-child-theme' ); ?></strong> <?php esc_html_e( 'La sezione nella Homepage è ora sincronizzata.', 'telecomsecurity-child-theme' ); ?></p>
			</div>
		<?php endif; ?>

		<div class="ts-admin-notice-bar">
			<span class="dashicons dashicons-info" aria-hidden="true"></span>
			<span><?php esc_html_e( 'Per una visualizzazione ottimale si consigliano da 4 a 7 passaggi.', 'telecomsecurity-child-theme' ); ?></span>
		</div>

		<form method="post" action="" id="ts-method-form" class="ts-method-form">
			<?php wp_nonce_field( 'ts_method_save_nonce_action', 'ts_method_save_nonce' ); ?>
			<input type="hidden" name="ts_method_save_action" value="1">

			<!-- ==========================================================
			     1. IMPOSTAZIONI GENERALI SEZIONE
			     ========================================================== -->
			<div class="ts-admin-card">
				<div class="ts-admin-card__header">
					<h2 class="ts-admin-card__title"><?php esc_html_e( 'Impostazioni Generali della Sezione', 'telecomsecurity-child-theme' ); ?></h2>
					<label class="ts-toggle-wrap">
						<input type="checkbox" name="ts_method_enabled" value="1" <?php checked( $data['enabled'], true ); ?>>
						<span class="ts-toggle-slider"></span>
						<span class="ts-toggle-label"><?php esc_html_e( 'Sezione Attiva in Homepage', 'telecomsecurity-child-theme' ); ?></span>
					</label>
				</div>
				<div class="ts-admin-card__body">
					<div class="ts-form-row ts-form-row--split">
						<div class="ts-form-group">
							<label for="ts_method_eyebrow" class="ts-label"><?php esc_html_e( 'Etichetta Superiore (Eyebrow)', 'telecomsecurity-child-theme' ); ?></label>
							<input type="text" id="ts_method_eyebrow" name="ts_method_eyebrow" value="<?php echo esc_attr( $data['eyebrow'] ); ?>" class="ts-input regular-text" placeholder="IL NOSTRO METODO">
							<span class="ts-field-hint"><?php esc_html_e( 'Piccola dicitura sopra il titolo principale con accento arancione.', 'telecomsecurity-child-theme' ); ?></span>
						</div>
						<div class="ts-form-group">
							<label for="ts_method_title" class="ts-label"><?php esc_html_e( 'Titolo Principale Sezione', 'telecomsecurity-child-theme' ); ?></label>
							<input type="text" id="ts_method_title" name="ts_method_title" value="<?php echo esc_attr( $data['title'] ); ?>" class="ts-input regular-text" placeholder="Ogni sistema nasce da una sequenza precisa.">
							<span class="ts-field-hint"><?php esc_html_e( 'Titolo autorevole che introduce la sequenza di lavoro.', 'telecomsecurity-child-theme' ); ?></span>
						</div>
					</div>
					<div class="ts-form-group ts-form-group--full">
						<label for="ts_method_introduction" class="ts-label"><?php esc_html_e( 'Testo Introduttivo', 'telecomsecurity-child-theme' ); ?></label>
						<textarea id="ts_method_introduction" name="ts_method_introduction" rows="2" class="ts-textarea large-text" placeholder="Cinque passaggi che trasformano esigenze diverse in una soluzione coordinata."><?php echo esc_textarea( $data['introduction'] ); ?></textarea>
						<span class="ts-field-hint"><?php esc_html_e( 'Descrizione breve prima dell’inizio del movimento orizzontale.', 'telecomsecurity-child-theme' ); ?></span>
					</div>
				</div>
			</div>

			<!-- ==========================================================
			     2. REPEATER DEI PASSAGGI DEL METODO
			     ========================================================== -->
			<div class="ts-admin-card ts-admin-card--repeater">
				<div class="ts-admin-card__header">
					<div>
						<h2 class="ts-admin-card__title"><?php esc_html_e( 'Sequenza dei Passaggi', 'telecomsecurity-child-theme' ); ?></h2>
						<p class="ts-admin-card__desc"><?php esc_html_e( 'Trascina le schede per riordinare la sequenza. La numerazione (01, 02...) si aggiorna automaticamente.', 'telecomsecurity-child-theme' ); ?></p>
					</div>
					<button type="button" class="button button-primary ts-btn-add-step" id="ts-add-step-btn">
						<span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span>
						<span><?php esc_html_e( 'Aggiungi Passaggio', 'telecomsecurity-child-theme' ); ?></span>
					</button>
				</div>

				<div class="ts-steps-container" id="ts-steps-container">
					<?php foreach ( $items as $idx => $item ) :
						$step_num = sprintf( '%02d', $idx + 1 );
						$step_id  = ! empty( $item['id'] ) ? $item['id'] : 'step_' . ( $idx + 1 );
						$active   = isset( $item['active'] ) ? (bool) $item['active'] : true;
						$img_id   = isset( $item['image_id'] ) ? absint( $item['image_id'] ) : 0;
						$img_url  = '';
						if ( $img_id > 0 ) {
							$thumb = wp_get_attachment_image_src( $img_id, 'medium' );
							if ( $thumb ) {
								$img_url = $thumb[0];
							}
						}
						$img_pos = isset( $item['image_pos'] ) ? $item['image_pos'] : 'center';
					?>
						<div class="ts-step-card <?php echo ! $active ? 'is-disabled' : ''; ?>" data-step-id="<?php echo esc_attr( $step_id ); ?>">
							
							<div class="ts-step-card__header">
								<div class="ts-step-card__meta">
									<span class="ts-drag-handle dashicons dashicons-menu" title="<?php esc_attr_e( 'Trascina per riordinare', 'telecomsecurity-child-theme' ); ?>"></span>
									<span class="ts-step-badge"><span class="ts-step-badge__num"><?php echo esc_html( $step_num ); ?></span></span>
									<strong class="ts-step-header-title"><?php echo esc_html( ! empty( $item['title'] ) ? $item['title'] : 'Passaggio ' . $step_num ); ?></strong>
								</div>
								
								<div class="ts-step-card__actions">
									<label class="ts-step-toggle" title="<?php esc_attr_e( 'Attiva o disattiva questo passaggio', 'telecomsecurity-child-theme' ); ?>">
										<input type="checkbox" name="ts_method_items[<?php echo esc_attr( $idx ); ?>][active]" value="1" <?php checked( $active, true ); ?> class="ts-step-active-check">
										<span class="ts-step-toggle-text"><?php echo $active ? esc_html__( 'Attivo', 'telecomsecurity-child-theme' ) : esc_html__( 'Disattivo', 'telecomsecurity-child-theme' ); ?></span>
									</label>
									<button type="button" class="button-link-delete ts-btn-remove-step" title="<?php esc_attr_e( 'Elimina questo passaggio', 'telecomsecurity-child-theme' ); ?>">
										<span class="dashicons dashicons-trash"></span>
									</button>
								</div>
							</div>

							<div class="ts-step-card__body">
								<input type="hidden" name="ts_method_items[<?php echo esc_attr( $idx ); ?>][id]" value="<?php echo esc_attr( $step_id ); ?>" class="ts-step-id-input">

								<div class="ts-step-grid">
									<!-- Colonna Testi -->
									<div class="ts-step-col ts-step-col--text">
										<div class="ts-form-group">
											<label class="ts-label"><?php esc_html_e( 'Titolo del Passaggio', 'telecomsecurity-child-theme' ); ?></label>
											<input type="text" name="ts_method_items[<?php echo esc_attr( $idx ); ?>][title]" value="<?php echo esc_attr( $item['title'] ); ?>" class="ts-input ts-step-title-input widefat" placeholder="Es. Comprendere">
										</div>
										<div class="ts-form-group">
											<label class="ts-label"><?php esc_html_e( 'Testo Descrittivo', 'telecomsecurity-child-theme' ); ?></label>
											<textarea name="ts_method_items[<?php echo esc_attr( $idx ); ?>][text]" rows="3" class="ts-textarea widefat" placeholder="Descrizione del metodo di lavoro..."><?php echo esc_textarea( $item['text'] ); ?></textarea>
										<label class="ts-label"><?php esc_html_e( 'Link facoltativo', 'telecomsecurity-child-theme' ); ?><input type="url" name="ts_method_items[<?php echo esc_attr( $idx ); ?>][url]" value="<?php echo esc_attr( $item['url'] ?? '' ); ?>" class="ts-input widefat" placeholder="https://"></label>
										</div>
									</div>

									<!-- Colonna Immagine -->
									<div class="ts-step-col ts-step-col--image">
										<label class="ts-label"><?php esc_html_e( 'Immagine di Fase (Media Library)', 'telecomsecurity-child-theme' ); ?></label>
										
										<div class="ts-media-box">
											<div class="ts-media-preview-wrap <?php echo $img_url ? 'has-image' : 'is-empty'; ?>">
												<img src="<?php echo esc_url( $img_url ); ?>" alt="" class="ts-media-preview-img" style="<?php echo $img_url ? '' : 'display:none;'; ?>">
												<div class="ts-media-empty-cue" style="<?php echo $img_url ? 'display:none;' : ''; ?>">
													<span class="dashicons dashicons-format-image"></span>
													<span><?php esc_html_e( 'Nessuna immagine (usa placeholder grafico)', 'telecomsecurity-child-theme' ); ?></span>
												</div>
											</div>
											
											<input type="hidden" name="ts_method_items[<?php echo esc_attr( $idx ); ?>][image_id]" value="<?php echo esc_attr( $img_id ); ?>" class="ts-step-image-id">
											
											<div class="ts-media-controls">
												<button type="button" class="button ts-btn-select-media">
													<span class="dashicons dashicons-upload"></span>
													<span class="ts-btn-select-label"><?php echo $img_id ? esc_html__( 'Sostituisci immagine', 'telecomsecurity-child-theme' ) : esc_html__( 'Seleziona immagine', 'telecomsecurity-child-theme' ); ?></span>
												</button>
												<button type="button" class="button-link-delete ts-btn-remove-media" style="<?php echo $img_id ? '' : 'display:none;'; ?>">
													<?php esc_html_e( 'Rimuovi', 'telecomsecurity-child-theme' ); ?>
												</button>
											</div>
										</div>

										<div class="ts-form-group ts-form-group--pos">
											<label class="ts-label-sub"><?php esc_html_e( 'Posizione / Inquadratura Immagine', 'telecomsecurity-child-theme' ); ?></label>
											<select name="ts_method_items[<?php echo esc_attr( $idx ); ?>][image_pos]" class="ts-select">
												<option value="center" <?php selected( $img_pos, 'center' ); ?>><?php esc_html_e( 'Centro (Standard)', 'telecomsecurity-child-theme' ); ?></option>
												<option value="left" <?php selected( $img_pos, 'left' ); ?>><?php esc_html_e( 'Sinistra', 'telecomsecurity-child-theme' ); ?></option>
												<option value="right" <?php selected( $img_pos, 'right' ); ?>><?php esc_html_e( 'Destra', 'telecomsecurity-child-theme' ); ?></option>
											</select>
										</div>

									</div>
								</div>

							</div>
						</div>
					<?php endforeach; ?>
				</div>

				<div class="ts-admin-card__footer">
					<button type="button" class="button button-secondary ts-btn-add-step" id="ts-add-step-btn-bottom">
						<span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span>
						<span><?php esc_html_e( 'Aggiungi Passaggio', 'telecomsecurity-child-theme' ); ?></span>
					</button>
				</div>
			</div>

			<!-- ==========================================================
			     3. PANNELLO FINALE CTA (Grafite)
			     ========================================================== -->
			<div class="ts-admin-card ts-admin-card--final">
				<div class="ts-admin-card__header">
					<div>
						<h2 class="ts-admin-card__title"><?php esc_html_e( 'Pannello Finale CTA (Conclusione del Track)', 'telecomsecurity-child-theme' ); ?></h2>
						<p class="ts-admin-card__desc"><?php esc_html_e( 'Pannello a contrasto grafite scuro posizionato al termine della sequenza orizzontale.', 'telecomsecurity-child-theme' ); ?></p>
					</div>
				</div>
				<div class="ts-admin-card__body">
					<div class="ts-form-row ts-form-row--split">
						<div class="ts-form-group">
							<label for="ts_method_final_title" class="ts-label"><?php esc_html_e( 'Titolo Finale CTA', 'telecomsecurity-child-theme' ); ?></label>
							<input type="text" id="ts_method_final_title" name="ts_method_final_title" value="<?php echo esc_attr( $data['final_panel']['title'] ); ?>" class="ts-input regular-text" placeholder="Il tuo sistema comincia da qui.">
						</div>
						<div class="ts-form-group">
							<label for="ts_method_final_btn_text" class="ts-label"><?php esc_html_e( 'Testo Pulsante CTA', 'telecomsecurity-child-theme' ); ?></label>
							<input type="text" id="ts_method_final_btn_text" name="ts_method_final_btn_text" value="<?php echo esc_attr( $data['final_panel']['btn_text'] ); ?>" class="ts-input regular-text" placeholder="Richiedi una consulenza">
						</div>
					</div>

					<div class="ts-form-row ts-form-row--split">
						<div class="ts-form-group">
							<label for="ts_method_final_text" class="ts-label"><?php esc_html_e( 'Testo Descrittivo Finale', 'telecomsecurity-child-theme' ); ?></label>
							<textarea id="ts_method_final_text" name="ts_method_final_text" rows="2" class="ts-textarea regular-text" placeholder="Raccontaci ciò che vuoi proteggere."><?php echo esc_textarea( $data['final_panel']['text'] ); ?></textarea>
						</div>
						<div class="ts-form-group">
							<label for="ts_method_final_page_id" class="ts-label"><?php esc_html_e( 'Pagina di Destinazione Pulsante', 'telecomsecurity-child-theme' ); ?></label>
							<select id="ts_method_final_page_id" name="ts_method_final_page_id" class="ts-select widefat">
								<option value="0"><?php esc_html_e( '— Seleziona una pagina WordPress —', 'telecomsecurity-child-theme' ); ?></option>
								<?php foreach ( $published_pages as $page ) : ?>
									<option value="<?php echo esc_attr( $page->ID ); ?>" <?php selected( $data['final_panel']['page_id'], $page->ID ); ?>>
										<?php echo esc_html( $page->post_title ); ?> (<?php echo esc_html( $page->post_name ); ?>)
									</option>
								<?php endforeach; ?>
							</select>
							<span class="ts-field-hint"><?php esc_html_e( 'Il link viene generato dinamicamente con get_permalink() dal relativo ID pagina.', 'telecomsecurity-child-theme' ); ?></span>
						</div>
					</div>
				</div>
			</div>

			<!-- Barra di Salvataggio Sticky -->
			<div class="ts-admin-submit-bar">
				<button type="submit" class="button button-primary button-large ts-btn-save">
					<span class="dashicons dashicons-saved" aria-hidden="true"></span>
					<span><?php esc_html_e( 'Salva Modifiche Metodo', 'telecomsecurity-child-theme' ); ?></span>
				</button>
				<span class="ts-submit-info"><?php esc_html_e( 'Le modifiche saranno immediatamente visibili sul frontend.', 'telecomsecurity-child-theme' ); ?></span>
			</div>

		</form>

		<!-- Modello Template per Nuovo Passaggio (JavaScript Clone) -->
		<template id="ts-step-template">
			<div class="ts-step-card" data-step-id="__STEP_ID__">
				<div class="ts-step-card__header">
					<div class="ts-step-card__meta">
						<span class="ts-drag-handle dashicons dashicons-menu" title="<?php esc_attr_e( 'Trascina per riordinare', 'telecomsecurity-child-theme' ); ?>"></span>
						<span class="ts-step-badge"><span class="ts-step-badge__num">__NUM__</span></span>
						<strong class="ts-step-header-title"><?php esc_html_e( 'Nuovo Passaggio', 'telecomsecurity-child-theme' ); ?></strong>
					</div>
					<div class="ts-step-card__actions">
						<label class="ts-step-toggle" title="<?php esc_attr_e( 'Attiva o disattiva questo passaggio', 'telecomsecurity-child-theme' ); ?>">
							<input type="checkbox" name="ts_method_items[__INDEX__][active]" value="1" checked class="ts-step-active-check">
							<span class="ts-step-toggle-text"><?php esc_html_e( 'Attivo', 'telecomsecurity-child-theme' ); ?></span>
						</label>
						<button type="button" class="button-link-delete ts-btn-remove-step" title="<?php esc_attr_e( 'Elimina questo passaggio', 'telecomsecurity-child-theme' ); ?>">
							<span class="dashicons dashicons-trash"></span>
						</button>
					</div>
				</div>
				<div class="ts-step-card__body">
					<input type="hidden" name="ts_method_items[__INDEX__][id]" value="__STEP_ID__" class="ts-step-id-input">
					<div class="ts-step-grid">
						<div class="ts-step-col ts-step-col--text">
							<div class="ts-form-group">
								<label class="ts-label"><?php esc_html_e( 'Titolo del Passaggio', 'telecomsecurity-child-theme' ); ?></label>
								<input type="text" name="ts_method_items[__INDEX__][title]" value="" class="ts-input ts-step-title-input widefat" placeholder="Es. Nuova Fase">
							</div>
							<div class="ts-form-group">
								<label class="ts-label"><?php esc_html_e( 'Testo Descrittivo', 'telecomsecurity-child-theme' ); ?></label>
								<textarea name="ts_method_items[__INDEX__][text]" rows="3" class="ts-textarea widefat" placeholder="Descrizione del passaggio..."></textarea>
										<label class="ts-label"><?php esc_html_e( 'Link facoltativo', 'telecomsecurity-child-theme' ); ?><input type="url" name="ts_method_items[__INDEX__][url]" value="" class="ts-input widefat" placeholder="https://"></label>
							</div>
						</div>
						<div class="ts-step-col ts-step-col--image">
							<label class="ts-label"><?php esc_html_e( 'Immagine di Fase (Media Library)', 'telecomsecurity-child-theme' ); ?></label>
							<div class="ts-media-box">
								<div class="ts-media-preview-wrap is-empty">
									<img src="" alt="" class="ts-media-preview-img" style="display:none;">
									<div class="ts-media-empty-cue">
										<span class="dashicons dashicons-format-image"></span>
										<span><?php esc_html_e( 'Nessuna immagine (usa placeholder grafico)', 'telecomsecurity-child-theme' ); ?></span>
									</div>
								</div>
								<input type="hidden" name="ts_method_items[__INDEX__][image_id]" value="0" class="ts-step-image-id">
								<div class="ts-media-controls">
									<button type="button" class="button ts-btn-select-media">
										<span class="dashicons dashicons-upload"></span>
										<span class="ts-btn-select-label"><?php esc_html_e( 'Seleziona immagine', 'telecomsecurity-child-theme' ); ?></span>
									</button>
									<button type="button" class="button-link-delete ts-btn-remove-media" style="display:none;">
										<?php esc_html_e( 'Rimuovi', 'telecomsecurity-child-theme' ); ?>
									</button>
								</div>
							</div>
							<div class="ts-form-group ts-form-group--pos">
								<label class="ts-label-sub"><?php esc_html_e( 'Posizione / Inquadratura Immagine', 'telecomsecurity-child-theme' ); ?></label>
								<select name="ts_method_items[__INDEX__][image_pos]" class="ts-select">
									<option value="center"><?php esc_html_e( 'Centro (Standard)', 'telecomsecurity-child-theme' ); ?></option>
									<option value="left"><?php esc_html_e( 'Sinistra', 'telecomsecurity-child-theme' ); ?></option>
									<option value="right"><?php esc_html_e( 'Destra', 'telecomsecurity-child-theme' ); ?></option>
								</select>
							</div>
						</div>
					</div>
				</div>
			</div>
		</template>

	</div>

	<!-- Stili Admin dedicati -->
	<style>
		.ts-admin-wrap {
			max-width: 1100px;
			margin: 20px 20px 40px 0;
			font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
		}
		.ts-admin-header {
			display: flex;
			justify-content: space-between;
			align-items: flex-end;
			margin-bottom: 20px;
			padding-bottom: 16px;
			border-bottom: 1px solid #cbd5e1;
		}
		.ts-admin-badge {
			display: inline-block;
			font-size: 11px;
			font-weight: 700;
			letter-spacing: 0.1em;
			text-transform: uppercase;
			color: #ea580c;
			background: #fff7ed;
			border: 1px solid #fed7aa;
			padding: 3px 8px;
			border-radius: 4px;
			margin-bottom: 6px;
		}
		.ts-admin-title {
			font-size: 24px;
			font-weight: 700;
			color: #0f172a;
			margin: 0;
		}
		.ts-admin-pill {
			font-size: 12px;
			color: #64748b;
			background: #f1f5f9;
			padding: 4px 10px;
			border-radius: 9999px;
			border: 1px solid #e2e8f0;
		}
		.ts-admin-notice-bar {
			display: flex;
			align-items: center;
			gap: 8px;
			background: #eff6ff;
			border-left: 4px solid #3b82f6;
			color: #1e40af;
			padding: 10px 14px;
			border-radius: 4px;
			margin-bottom: 24px;
			font-size: 13px;
		}
		.ts-admin-notice-bar .dashicons {
			color: #3b82f6;
			font-size: 18px;
		}
		.ts-admin-card {
			background: #ffffff;
			border: 1px solid #e2e8f0;
			border-radius: 8px;
			box-shadow: 0 1px 3px rgba(0,0,0,0.04);
			margin-bottom: 24px;
			overflow: hidden;
		}
		.ts-admin-card__header {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 16px 20px;
			background: #f8fafc;
			border-bottom: 1px solid #e2e8f0;
		}
		.ts-admin-card__title {
			font-size: 16px;
			font-weight: 600;
			color: #0f172a;
			margin: 0;
		}
		.ts-admin-card__desc {
			font-size: 13px;
			color: #64748b;
			margin: 4px 0 0 0;
		}
		.ts-admin-card__body {
			padding: 20px;
		}
		.ts-admin-card__footer {
			padding: 12px 20px;
			background: #f8fafc;
			border-top: 1px solid #e2e8f0;
			display: flex;
			justify-content: flex-end;
		}
		.ts-form-row--split {
			display: grid;
			grid-template-columns: 1fr 1fr;
			gap: 20px;
			margin-bottom: 16px;
		}
		.ts-form-group {
			display: flex;
			flex-direction: column;
			gap: 6px;
		}
		.ts-form-group--full {
			margin-bottom: 12px;
		}
		.ts-label {
			font-weight: 600;
			font-size: 13px;
			color: #334155;
		}
		.ts-label-sub {
			font-size: 12px;
			color: #64748b;
		}
		.ts-field-hint {
			font-size: 12px;
			color: #64748b;
		}
		.ts-input, .ts-textarea, .ts-select {
			border: 1px solid #cbd5e1;
			border-radius: 4px;
			padding: 8px 12px;
			font-size: 14px;
			transition: border-color 0.2s;
		}
		.ts-input:focus, .ts-textarea:focus, .ts-select:focus {
			border-color: #ea580c;
			outline: none;
			box-shadow: 0 0 0 1px #ea580c;
		}
		/* Toggle Switch */
		.ts-toggle-wrap {
			display: flex;
			align-items: center;
			gap: 10px;
			cursor: pointer;
		}
		.ts-toggle-wrap input {
			display: none;
		}
		.ts-toggle-slider {
			position: relative;
			width: 40px;
			height: 22px;
			background: #cbd5e1;
			border-radius: 22px;
			transition: background 0.2s;
		}
		.ts-toggle-slider::after {
			content: '';
			position: absolute;
			top: 3px;
			left: 3px;
			width: 16px;
			height: 16px;
			background: #fff;
			border-radius: 50%;
			transition: transform 0.2s;
		}
		.ts-toggle-wrap input:checked + .ts-toggle-slider {
			background: #ea580c;
		}
		.ts-toggle-wrap input:checked + .ts-toggle-slider::after {
			transform: translateX(18px);
		}
		.ts-toggle-label {
			font-weight: 600;
			font-size: 13px;
			color: #0f172a;
		}
		/* Repeater Steps */
		.ts-steps-container {
			padding: 16px 20px;
			display: flex;
			flex-direction: column;
			gap: 16px;
		}
		.ts-step-card {
			background: #ffffff;
			border: 1px solid #cbd5e1;
			border-radius: 6px;
			box-shadow: 0 1px 2px rgba(0,0,0,0.03);
			transition: all 0.2s ease;
		}
		.ts-step-card.is-disabled {
			opacity: 0.6;
			background: #f8fafc;
		}
		.ts-step-card.ui-sortable-helper {
			box-shadow: 0 10px 20px rgba(0,0,0,0.12);
			border-color: #ea580c;
		}
		.ts-step-card__header {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 10px 16px;
			background: #f1f5f9;
			border-bottom: 1px solid #e2e8f0;
			border-radius: 5px 5px 0 0;
		}
		.ts-step-card__meta {
			display: flex;
			align-items: center;
			gap: 12px;
		}
		.ts-drag-handle {
			cursor: grab;
			color: #94a3b8;
			font-size: 20px;
		}
		.ts-drag-handle:active {
			cursor: grabbing;
		}
		.ts-step-badge {
			background: #0f172a;
			color: #ffffff;
			font-weight: 700;
			font-size: 12px;
			padding: 2px 8px;
			border-radius: 4px;
		}
		.ts-step-header-title {
			font-size: 14px;
			color: #0f172a;
		}
		.ts-step-card__actions {
			display: flex;
			align-items: center;
			gap: 16px;
		}
		.ts-step-toggle {
			display: flex;
			align-items: center;
			gap: 6px;
			font-size: 12px;
			color: #475569;
			cursor: pointer;
		}
		.ts-btn-remove-step {
			color: #dc2626;
			border: none;
			background: transparent;
			cursor: pointer;
			padding: 4px;
		}
		.ts-btn-remove-step:hover {
			color: #991b1b;
		}
		.ts-step-card__body {
			padding: 16px;
		}
		.ts-step-grid {
			display: grid;
			grid-template-columns: 1.5fr 1fr;
			gap: 24px;
		}
		/* Media Box */
		.ts-media-box {
			background: #f8fafc;
			border: 1px dashed #cbd5e1;
			border-radius: 6px;
			padding: 12px;
			margin-bottom: 12px;
		}
		.ts-media-preview-wrap {
			width: 100%;
			height: 120px;
			background: #f1f5f9;
			border-radius: 4px;
			overflow: hidden;
			display: flex;
			align-items: center;
			justify-content: center;
			margin-bottom: 10px;
		}
		.ts-media-preview-img {
			width: 100%;
			height: 100%;
			object-fit: cover;
		}
		.ts-media-empty-cue {
			display: flex;
			flex-direction: column;
			align-items: center;
			gap: 4px;
			color: #94a3b8;
			font-size: 11px;
			text-align: center;
			padding: 0 10px;
		}
		.ts-media-empty-cue .dashicons {
			font-size: 28px;
			width: 28px;
			height: 28px;
		}
		.ts-media-controls {
			display: flex;
			align-items: center;
			gap: 10px;
		}
		.ts-form-group--pos {
			margin-top: 8px;
		}
		/* Sticky Submit Bar */
		.ts-admin-submit-bar {
			position: sticky;
			bottom: 20px;
			background: #ffffff;
			border: 1px solid #cbd5e1;
			border-radius: 8px;
			padding: 14px 20px;
			display: flex;
			align-items: center;
			gap: 16px;
			box-shadow: 0 4px 12px rgba(0,0,0,0.08);
			z-index: 99;
		}
		.ts-btn-save {
			background: #ea580c !important;
			border-color: #ea580c !important;
			color: #ffffff !important;
			font-weight: 600 !important;
			padding: 4px 24px !important;
			height: auto !important;
			line-height: 2 !important;
			display: inline-flex !important;
			align-items: center !important;
			gap: 6px !important;
		}
		.ts-btn-save:hover {
			background: #c2410c !important;
			border-color: #c2410c !important;
		}
		.ts-submit-info {
			font-size: 13px;
			color: #64748b;
		}
		@media (max-width: 782px) {
			.ts-form-row--split, .ts-step-grid {
				grid-template-columns: 1fr;
			}
		}
	</style>

	<!-- Script interattività Repeater e Media Picker -->
	<script>
	jQuery(document).ready(function($) {
		'use strict';

		const container = $('#ts-steps-container');
		const template = $('#ts-step-template').html();

		// 1. Inizializzazione Sortable Drag & Drop
		container.sortable({
			handle: '.ts-drag-handle',
			placeholder: 'ts-step-card-placeholder',
			axis: 'y',
			opacity: 0.8,
			update: function() {
				reindexSteps();
			}
		});

		// 2. Ricalcolo indici e numerazione
		function reindexSteps() {
			container.children('.ts-step-card').each(function(index) {
				const card = $(this);
				const num = String(index + 1).padStart(2, '0');
				card.find('.ts-step-badge__num').text(num);

				// Aggiorna name degli input
				card.find('input, textarea, select').each(function() {
					const name = $(this).attr('name');
					if (name) {
						const updatedName = name.replace(/ts_method_items\[\d+\]/, 'ts_method_items[' + index + ']');
						$(this).attr('name', updatedName);
					}
				});
			});
		}

		// 3. Sincronizzazione titolo nell'header della card
		container.on('input', '.ts-step-title-input', function() {
			const val = $(this).val().trim();
			const headerTitle = $(this).closest('.ts-step-card').find('.ts-step-header-title');
			const badgeNum = $(this).closest('.ts-step-card').find('.ts-step-badge__num').text();
			headerTitle.text(val.length > 0 ? val : 'Passaggio ' + badgeNum);
		});

		// 4. Toggle Attivo / Disattivo card
		container.on('change', '.ts-step-active-check', function() {
			const card = $(this).closest('.ts-step-card');
			const label = $(this).siblings('.ts-step-toggle-text');
			if ($(this).is(':checked')) {
				card.removeClass('is-disabled');
				label.text('Attivo');
			} else {
				card.addClass('is-disabled');
				label.text('Disattivo');
			}
		});

		// 5. Apertura Media Library WordPress
		container.on('click', '.ts-btn-select-media', function(e) {
			e.preventDefault();
			const btn = $(this);
			const box = btn.closest('.ts-media-box');
			const idInput = box.find('.ts-step-image-id');
			const previewImg = box.find('.ts-media-preview-img');
			const emptyCue = box.find('.ts-media-empty-cue');
			const removeBtn = box.find('.ts-btn-remove-media');
			const selectLabel = btn.find('.ts-btn-select-label');

			const frame = wp.media({
				title: 'Seleziona immagine per il passaggio',
				button: { text: 'Usa questa immagine' },
				multiple: false,
				library: { type: 'image' }
			});

			frame.on('select', function() {
				const attachment = frame.state().get('selection').first().toJSON();
				idInput.val(attachment.id);

				const url = (attachment.sizes && attachment.sizes.medium) ? attachment.sizes.medium.url : attachment.url;
				previewImg.attr('src', url).show();
				emptyCue.hide();
				box.find('.ts-media-preview-wrap').removeClass('is-empty').addClass('has-image');
				removeBtn.show();
				selectLabel.text('Sostituisci immagine');
			});

			frame.open();
		});

		// 6. Rimozione Immagine
		container.on('click', '.ts-btn-remove-media', function(e) {
			e.preventDefault();
			const btn = $(this);
			const box = btn.closest('.ts-media-box');
			box.find('.ts-step-image-id').val('0');
			box.find('.ts-media-preview-img').attr('src', '').hide();
			box.find('.ts-media-empty-cue').show();
			box.find('.ts-media-preview-wrap').removeClass('has-image').addClass('is-empty');
			box.find('.ts-btn-select-label').text('Seleziona immagine');
			btn.hide();
		});

		// 7. Aggiunta Passaggio
		function addStep() {
			const count = container.children('.ts-step-card').length;
			const newNum = String(count + 1).padStart(2, '0');
			const uniqueId = 'step_' + Date.now();

			let html = template
				.replace(/__INDEX__/g, count)
				.replace(/__NUM__/g, newNum)
				.replace(/__STEP_ID__/g, uniqueId);

			const newRow = $(html).hide();
			container.append(newRow);
			newRow.slideDown(200);
			reindexSteps();
			$('html, body').animate({ scrollTop: newRow.offset().top - 100 }, 300);
		}

		$('#ts-add-step-btn, #ts-add-step-btn-bottom').on('click', function(e) {
			e.preventDefault();
			addStep();
		});

		// 8. Eliminazione Passaggio con Conferma
		container.on('click', '.ts-btn-remove-step', function(e) {
			e.preventDefault();
			if (container.children('.ts-step-card').length <= 1) {
				alert('La sezione richiede almeno un passaggio.');
				return;
			}
			if (confirm('Sei sicuro di voler eliminare questo passaggio dal metodo?')) {
				const card = $(this).closest('.ts-step-card');
				card.slideUp(200, function() {
					card.remove();
					reindexSteps();
				});
			}
		});

	});
	</script>
	<?php
}
