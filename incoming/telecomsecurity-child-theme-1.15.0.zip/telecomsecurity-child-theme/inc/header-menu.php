<?php
/** Native menu hierarchy with CMS/page images; no second navigation data source. */
defined('ABSPATH') || exit;

class TelecomSecurity_Header_Walker extends Walker_Nav_Menu {
    private $services = array();
    private $images = array();
    private $mega_id = 0;
    private $root;
    private $parents = array();
    private $initial_item;
    private $numbers = array();
    private $count = 0;
    private $ordinal = 0;

    private function media($item) {
        $page_id = $item->object === 'page' ? (int) $item->object_id : url_to_postid($item->url);
        $attachment = get_post_thumbnail_id($page_id);
        $src = $attachment ? wp_get_attachment_image_url($attachment, 'large') : '';
        if (!$src) {
            $src = $this->services[$page_id]['image'] ?? '';
            $attachment = $src ? attachment_url_to_postid($src) : 0;
        }
        if ($attachment) $src = wp_get_attachment_image_url($attachment, 'large') ?: $src;
        if (!$src) $src = get_stylesheet_directory_uri() . '/assets/images/menu-fallback.svg';
        return array('src' => $src, 'srcset' => $attachment ? (wp_get_attachment_image_srcset($attachment, 'large') ?: '') : '');
    }

    public function walk($elements, $max_depth, ...$args) {
        foreach ((array) get_option('ticinoweb_services', array()) as $service) {
            if (!empty($service['page_id'])) $this->services[(int) $service['page_id']] = $service;
        }
        $service_parents = array();
        foreach (array_keys($this->services) as $page_id) {
            $parent_id = wp_get_post_parent_id($page_id);
            if ($parent_id) $service_parents[$parent_id] = true;
        }
        foreach ($elements as $item) {
            $page_id = $item->object === 'page' ? (int) $item->object_id : url_to_postid($item->url);
            if (!$item->menu_item_parent && isset($service_parents[$page_id])) { $this->mega_id = (int) $item->ID; break; }
        }
        $by_id = array(); $scores = array();
        foreach ($elements as $item) $by_id[$item->ID] = $item;
        foreach ($elements as $item) {
            $page_id = $item->object === 'page' ? (int) $item->object_id : url_to_postid($item->url);
            if (!isset($this->services[$page_id]) || !$item->menu_item_parent) continue;
            $ancestor = $item; $seen = array();
            while ($ancestor->menu_item_parent && isset($by_id[$ancestor->menu_item_parent]) && !isset($seen[$ancestor->ID])) {
                $seen[$ancestor->ID] = true;
                $ancestor = $by_id[$ancestor->menu_item_parent];
            }
            $scores[$ancestor->ID] = ($scores[$ancestor->ID] ?? 0) + 1;
        }
        if (!$this->mega_id && $scores) { arsort($scores); $this->mega_id = (int) array_key_first($scores); }
        foreach ($elements as $item) {
            if ((int) $item->menu_item_parent === $this->mega_id && $this->mega_id) {
                $this->images[$item->ID] = $this->media($item);
                $this->numbers[$item->ID] = ++$this->count;
                if (!$this->initial_item || in_array('current-menu-item', (array) $item->classes, true)) $this->initial_item = $item;
            }
        }
        return parent::walk($elements, $max_depth, ...$args);
    }

    public function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
        $this->parents[$depth] = $item;
        if ($depth === 0) { $this->root = $item; $this->ordinal = 0; }
        $html = '';
        parent::start_el($html, $item, $depth, $args, $id);
        if ($depth === 1 && (int) $this->root->ID === $this->mega_id) {
            $media = $this->images[$item->ID];
            $page_id = $item->object === 'page' ? (int) $item->object_id : url_to_postid($item->url);
            $symbol = telecomsecurity_service_symbol($this->services[$page_id] ?? array());
            $attrs = ' data-preview-symbol="' . esc_attr($symbol) . '" data-preview-key="' . esc_attr($item->ID) . '" data-preview-initial="' . ($item->ID === $this->initial_item->ID ? 'true' : 'false') . '" data-preview-active="' . ($item->ID === $this->initial_item->ID ? 'true' : 'false') . '" data-preview-src="' . esc_url($media['src']) . '" data-preview-srcset="' . esc_attr($media['srcset']) . '"';
            $html = preg_replace_callback('/<a\s/', static fn() => '<a' . $attrs . ' ', $html, 1);
            $number = '<span class="ts-mega-number" aria-hidden="true">' . esc_html(sprintf('%02d', ++$this->ordinal)) . '</span><span class="ts-mega-name">';
            $html = preg_replace('/(<a\b[^>]*>)/', '$1' . $number, $html, 1);
            $html = str_replace('</a>', '</span><span class="ts-mega-arrow" aria-hidden="true"><span class="ts-mega-arrow__desktop">↗</span><span class="ts-mega-arrow__mobile">→</span></span></a>', $html);
        }
        if (in_array('menu-item-has-children', (array) $item->classes, true)) {
            $html .= '<button type="button" class="ts-submenu-toggle" aria-expanded="false" aria-controls="ts-submenu-' . esc_attr($item->ID) . '" aria-label="' . esc_attr(sprintf(__('Apri sottomenu: %s', 'telecomsecurity-child-theme'), wp_strip_all_tags($item->title))) . '"><span aria-hidden="true"></span></button>';
        }
        $output .= $html;
    }

    public function start_lvl(&$output, $depth = 0, $args = null) {
        $parent = $this->parents[$depth];
        if ($depth === 0 && (int) $parent->ID === $this->mega_id) {
            $item = $this->initial_item;
            $image = $this->images[$item->ID];
            $pixel = 'data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=';
            $sizes = '(min-width: 1300px) 480px, (min-width: 1200px) 42vw, 1px';
            $output .= '<div class="ts-mega ts-submenu" id="ts-submenu-' . esc_attr($parent->ID) . '" data-preview-fallback="' . esc_url(get_stylesheet_directory_uri() . '/assets/images/menu-fallback.svg') . '" aria-hidden="true">';
            $output .= '<div class="ts-mobile-drill-header"><button type="button" class="ts-mobile-drill-back" aria-label="' . esc_attr__('Torna al menu principale', 'telecomsecurity-child-theme') . '"><span aria-hidden="true">←</span><span>' . esc_html__('Menu', 'telecomsecurity-child-theme') . '</span></button><strong class="ts-mobile-drill-title">' . esc_html(wp_strip_all_tags($parent->title)) . '</strong><button type="button" class="ts-mobile-drill-close" aria-label="' . esc_attr__('Chiudi menu di navigazione', 'telecomsecurity-child-theme') . '"><span aria-hidden="true">×</span></button></div>';
            $output .= '<div class="ts-mega-inner">';
            $page_id = $item->object === 'page' ? (int) $item->object_id : url_to_postid($item->url);
            $output .= '<div class="ts-mega-visual ts-corners"><div class="ts-mega-symbol">';
            foreach (telecomsecurity_geometry_paths() as $key => $path) {
                $output .= '<span data-symbol="' . esc_attr($key) . '"' . (telecomsecurity_service_symbol($this->services[$page_id] ?? array()) === $key ? '' : ' hidden') . '>' . telecomsecurity_geometry($key) . '</span>';
            }
            $output .= '</div><div class="ts-mega-photo">';
            $output .= '<picture><source media="(min-width: 1200px)" srcset="' . esc_attr($image['srcset'] ?: $image['src']) . '" sizes="' . esc_attr($sizes) . '"><img class="is-current" src="' . esc_attr($pixel) . '" data-image-key="' . esc_attr($item->ID) . '" alt="" decoding="async" width="960" height="960"></picture>';
            $output .= '<picture><source media="(min-width: 1200px)" srcset="' . esc_attr($pixel) . '" sizes="' . esc_attr($sizes) . '"><img src="' . esc_attr($pixel) . '" alt="" decoding="async" width="960" height="960"></picture>';
            $output .= '</div><a class="ts-mega-overlay" href="' . esc_url($item->url) . '"><span class="ts-mega-overlay-number">' . esc_html(sprintf('%02d', $this->numbers[$item->ID])) . '</span><span class="ts-mega-overlay-title">' . esc_html(wp_strip_all_tags($item->title)) . '</span><span class="ts-mega-overlay-cta">Scopri il servizio <span aria-hidden="true">→</span></span></a></div>';
            $output .= '<div class="ts-mega-services"><ul class="ts-mega-links">';
        } else {
            $output .= '<ul class="ts-submenu ts-plain-submenu" id="ts-submenu-' . esc_attr($parent->ID) . '">';
        }
    }

    public function end_lvl(&$output, $depth = 0, $args = null) {
        if ($depth === 0 && (int) $this->root->ID === $this->mega_id) {
            $output .= '</ul><div class="ts-mega-footer"><p>' . esc_html(sprintf(__('%d soluzioni. Un unico interlocutore.', 'telecomsecurity-child-theme'), $this->count)) . '</p><a class="ts-mega-all" href="' . esc_url($this->root->url) . '"><span class="ts-mega-all__desktop">' . esc_html__('Scopri tutti i servizi', 'telecomsecurity-child-theme') . '</span><span class="ts-mega-all__mobile">' . esc_html__('Tutti i servizi', 'telecomsecurity-child-theme') . '</span><span class="ts-mega-all__arrow" aria-hidden="true">→</span></a></div></div></div></div>';
        } else $output .= '</ul>';
    }
}
