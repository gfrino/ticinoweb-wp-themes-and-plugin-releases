<?php
/** Secure Geometry: shared visual primitives, local assets and CMS associations. */
defined('ABSPATH') || exit;

function telecomsecurity_geometry_paths(): array {
    return array(
        'shield' => '<path d="M32 5 54 14v18c0 13-12 22-22 27C22 54 10 45 10 32V14Z"/><path d="M20 23v10c0 7 6 13 12 17"/>',
        'signal' => '<circle cx="32" cy="32" r="5"/><path d="M20 20a17 17 0 0 0 0 24m24-24a17 17 0 0 1 0 24M12 12a28 28 0 0 0 0 40m40-40a28 28 0 0 1 0 40"/>',
        'fire' => '<path d="M33 5c4 16 19 19 19 34a20 20 0 0 1-40 0c0-10 7-17 12-23 0 9 3 13 7 16 5-9 5-17 2-27Z"/><path d="M26 43c0 8 12 8 12 0"/>',
        'camera' => '<path d="m9 18 31-6 15 18-29 8Z M24 39l-4 12H8m28-15 5 9h13"/><circle cx="43" cy="26" r="4"/>',
        'intercom' => '<rect x="18" y="7" width="28" height="50" rx="2"/><circle cx="32" cy="19" r="5"/><path d="M25 34h14m-14 5h14"/><circle cx="32" cy="48" r="2"/>',
        'access' => '<path d="M12 56V9h33v47M7 56h44M21 56V19l16-4v41"/><circle cx="31" cy="37" r="2"/><path d="M48 26h10m-5-5 5 5-5 5"/>',
        'gas' => '<path d="M32 6C26 19 14 30 14 40a18 18 0 0 0 36 0C50 30 38 19 32 6Z"/><path d="M23 39c0 6 4 10 9 10"/><circle cx="43" cy="16" r="3"/>',
        'radio' => '<path d="m22 57 10-35 10 35M19 57h26M26 43h12M18 12a20 20 0 0 0 0 28m28-28a20 20 0 0 1 0 28"/><circle cx="32" cy="21" r="4"/>',
        'mobile' => '<rect x="19" y="5" width="26" height="54" rx="4"/><path d="M26 12h12m-12 39h12"/><circle cx="32" cy="31" r="7"/>',
        'automation' => '<path d="M8 55V19l24-12 24 12v36M18 55V25h28v30M18 34h28M18 44h28M32 25v30"/>',
        'media' => '<rect x="7" y="10" width="50" height="34" rx="2"/><path d="m27 19 13 8-13 8ZM32 44v10m-14 0h28"/>',
        'survey' => '<path d="M15 8h27l8 8v40H15ZM42 8v10h8M23 28h19M23 37h19M23 46h10"/><circle cx="45" cy="46" r="10"/>',
        'ring' => '<circle cx="32" cy="32" r="25"/><circle cx="32" cy="32" r="18"/><path d="M32 7v8m25 17h-8M32 57v-8M7 32h8M32 20v12l9 6"/>',
        'lock' => '<rect x="15" y="27" width="34" height="29" rx="2"/><path d="M22 27V17a10 10 0 0 1 20 0v10M32 38v8"/>',
    );
}
function telecomsecurity_geometry(string $key = 'shield', string $class = ''): string {
    $paths = telecomsecurity_geometry_paths();
    return '<svg class="ts-geometry ' . esc_attr($class) . '" viewBox="0 0 64 64" width="64" height="64" fill="none" stroke="currentColor" stroke-width="1.25" stroke-linecap="square" stroke-linejoin="miter" aria-hidden="true" focusable="false">' . ($paths[$key] ?? $paths['shield']) . '</svg>';
}
function telecomsecurity_service_symbol(array $service): string {
    $saved = $service['geometry'] ?? '';
    if (isset(telecomsecurity_geometry_paths()[$saved])) return $saved;
    // Existing stable CMS IDs; titles, order and URLs remain freely editable.
    $legacy = array('page_13'=>'shield','page_15'=>'fire','page_14'=>'camera','page_41'=>'intercom','page_46'=>'access','page_12'=>'gas','page_9'=>'radio','page_44'=>'mobile','page_11'=>'automation','page_10'=>'media','page_47'=>'survey');
    return $legacy[$service['id'] ?? ''] ?? 'shield';
}
add_action('wp_enqueue_scripts', function () {
    wp_dequeue_style('poppins-font');
    $dir = get_stylesheet_directory(); $url = get_stylesheet_directory_uri();
    wp_enqueue_style('ts-secure-geometry', $url . '/assets/css/secure-geometry.css', array('telecomsecurity-header'), filemtime($dir . '/assets/css/secure-geometry.css'));
    wp_enqueue_script('ts-secure-geometry', $url . '/assets/js/secure-geometry.js', array('telecomsecurity-header'), filemtime($dir . '/assets/js/secure-geometry.js'), true);
}, 40);
add_action('wp_head', function () {
    foreach (array('sora','geist') as $font) echo '<link rel="preload" as="font" type="font/woff2" crossorigin href="' . esc_url(get_stylesheet_directory_uri() . '/assets/fonts/' . $font . '-variable.woff2') . '">';
}, 2);
// Repair only the legacy literal separators between block markup, never prose.
add_filter('the_content', function ($content) {
    if (!is_admin() && is_page()) $content = preg_replace('/(?<=>)n+(?=<(?:!--|\/?(?:h[1-6]|p|ul|ol|li)\b))/', "\n", $content);
    return $content;
}, 8);

// Replace the legacy, malformed services list with the current CMS collection.
// Editorial paragraphs and any correctly authored lists are left untouched.
add_filter('the_content', function ($content) {
    if (is_admin() || !is_page() || !is_main_query() || !in_the_loop()) return $content;
    // Suppress only an exact duplicate of the native page H1 in the first block.
    $content = preg_replace_callback('/\A\s*<h2\b[^>]*>(.*?)<\/h2>/s', static function ($match) {
        return trim(wp_strip_all_tags(html_entity_decode($match[1], ENT_QUOTES, 'UTF-8'))) === trim(get_the_title()) ? '' : $match[0];
    }, $content, 1);
    $services = telecomsecurity_get_services_explorer_data();
    $parents = array_filter(array_map(static fn($row) => wp_get_post_parent_id($row['page_id']), $services));
    if (in_array(get_queried_object_id(), $parents, true) && str_contains((string) get_post_field('post_content', get_the_ID()), 'n<li>')) {
        $links = '<ul class="ts-services-index">';
        foreach ($services as $row) $links .= '<li><a href="#service-' . esc_attr($row['id']) . '"><span class="ts-code">' . esc_html($row['index']) . '</span><span class="ts-services-index__title">' . esc_html($row['title']) . '</span></a></li>';
        $links .= '</ul>';
        $content = preg_replace_callback('/<ul class="wp-block-list">.*?<\/ul>/s', static fn() => $links, $content, 1);
    }
    return $content;
}, 12);

/** Decorative searchlight contained inside the hero's visual column. */
function telecomsecurity_hero_searchlight(): string {
    return '<div class="ts-hero-searchlight" data-hero-searchlight aria-hidden="true">'
        . '<div class="ts-searchlight__scanner">'
        . '<span class="ts-searchlight__falloff"></span>'
        . '<span class="ts-searchlight__beam"></span>'
        . '<span class="ts-searchlight__hotspot"></span>'
        . '<span class="ts-searchlight__source"></span>'
        . '</div>'
        . '</div>';
}
