<?php
/**
 * Telecom Security — Home Helper Functions
 *
 * Estrae e normalizza in modo dinamico e sicuro tutti i dati configurati
 * nel ticinoWEB CMS per la homepage, senza alcuna dipendenza hardcoded.
 *
 * @package TelecomSecurityChild
 * @version 1.12.14
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Recupera la favicon configurata nel CMS per il watermark della Home.
 *
 * @return string URL della favicon o stringa vuota se non configurata.
 */
function telecomsecurity_get_intro_icon_url(): string {
	if ( ! function_exists( 'ticinoweb_get_site_icon' ) ) {
		return '';
	}

	return trim( (string) ticinoweb_get_site_icon() );
}

/**
 * Recupera i dati del preloader della Home dal branding CMS esistente.
 *
 * @return array{logo_url:string,loading_text:string,ready_text:string,session_key:string}
 */
function telecomsecurity_get_preloader_data(): array {
	$logo_url = function_exists( 'ticinoweb_get_site_icon' ) ? trim( (string) ticinoweb_get_site_icon() ) : '';
	if ( '' === $logo_url && function_exists( 'ticinoweb_get_site_logo' ) ) {
		$logo_url = trim( (string) ticinoweb_get_site_logo() );
	}

	return array(
		'logo_url'     => $logo_url,
		'loading_text' => __( 'Preparazione del sistema', 'telecomsecurity-child-theme' ),
		'ready_text'   => __( 'Sistema pronto', 'telecomsecurity-child-theme' ),
		'session_key'  => 'ts-preloader:v1.12.14',
	);
}

/**
 * Restituisce le sorgenti video ottimizzate incluse nel child theme.
 *
 * @param string $fallback_url URL originale configurato nel CMS.
 * @return array<int,array{url:string,type:string,media:string}>
 */
function telecomsecurity_get_hero_video_sources( string $fallback_url ): array {
	$fallback_path = (string) parse_url( $fallback_url, PHP_URL_PATH );
	$fallback_name = strtolower( rawurldecode( basename( $fallback_path ) ) );
	if ( 'telecom-video-intro.mp4' !== $fallback_name ) {
		return '' !== $fallback_url
			? array( array( 'url' => $fallback_url, 'type' => 'video/mp4', 'media' => '' ) )
			: array();
	}

	$video_dir = get_stylesheet_directory() . '/assets/video/';
	$video_uri = get_stylesheet_directory_uri() . '/assets/video/';
	$variants  = array(
		array( 'file' => 'telecom-hero-mobile.webm', 'type' => 'video/webm', 'media' => '(max-width: 767px)' ),
		array( 'file' => 'telecom-hero-mobile.mp4', 'type' => 'video/mp4', 'media' => '(max-width: 767px)' ),
		array( 'file' => 'telecom-hero-desktop.webm', 'type' => 'video/webm', 'media' => '(min-width: 768px)' ),
		array( 'file' => 'telecom-hero-desktop.mp4', 'type' => 'video/mp4', 'media' => '(min-width: 768px)' ),
	);

	foreach ( $variants as $variant ) {
		if ( ! is_readable( $video_dir . $variant['file'] ) ) {
			return '' !== $fallback_url
				? array( array( 'url' => $fallback_url, 'type' => 'video/mp4', 'media' => '' ) )
				: array();
		}
	}

	return array_map(
		static fn( array $variant ): array => array(
			'url'   => $video_uri . $variant['file'],
			'type'  => $variant['type'],
			'media' => $variant['media'],
		),
		$variants
	);
}

/**
 * Recupera i dati della Hero Video (Video unico di sfondo + 3 stati testuali).
 *
 * @return array Dati della hero con sorgenti video responsive e stati di testo.
 */
function telecomsecurity_get_hero_data(): array {
	$slider_count = (int) get_option( 'ticinoweb_slider_count', 3 );
	$slider_count = max( 1, min( 5, $slider_count ) );

	$raw_video = get_option( 'ticinoweb_slider_image_1', '' );
	$video_url = '';
	$is_video  = false;

	if ( ! empty( $raw_video ) ) {
		$ext = strtolower( pathinfo( parse_url( $raw_video, PHP_URL_PATH ), PATHINFO_EXTENSION ) );
		if ( in_array( $ext, array( 'mp4', 'webm', 'ogg', 'mov' ), true ) ) {
			$video_url = $raw_video;
			$is_video  = true;
		}
	}

	// Stati testuali (default veritieri dal CMS se presenti)
	$default_slides = array(
		1 => array(
			'title'    => 'Ogni segnale conta',
			'desc'     => 'Dati, immagini, accessi e allarmi. Tecnologie diverse, coordinate per offrirti una visione più completa della sicurezza.',
			'btn_text' => 'Esplora le soluzioni',
			'btn_link' => '#servizi',
		),
		2 => array(
			'title'    => 'La sicurezza non è un dispositivo',
			'desc'     => 'È un sistema progettato perché persone, spazi e tecnologie lavorino insieme, senza lasciare nulla al caso.',
			'btn_text' => 'Scopri il metodo',
			'btn_link' => '#metodo',
		),
		3 => array(
			'title'    => 'Dal 1975 nessuno ci ferma',
			'desc'     => 'Cinquant’anni di esperienza tecnica in Ticino, con lo sguardo costantemente rivolto alle tecnologie di domani.',
			'btn_text' => 'Conosci Telecom Security',
			'btn_link' => esc_url( home_url( '/chi-siamo/' ) ),
		),
	);

	$slides = array();
	for ( $i = 1; $i <= $slider_count; $i++ ) {
		$def = isset( $default_slides[ $i ] ) ? $default_slides[ $i ] : array(
			'title'    => 'Telecom Security SA',
			'desc'     => 'Sistemi di sicurezza e telecomunicazioni avanzate in Ticino.',
			'btn_text' => 'Contattaci',
			'btn_link' => esc_url( home_url( '/contatti/' ) ),
		);

		$title    = get_option( "ticinoweb_slider_title_{$i}" ) ?: $def['title'];
		$desc     = get_option( "ticinoweb_slider_desc_{$i}" ) ?: $def['desc'];
		$btn_text = get_option( "ticinoweb_slider_btn_text_{$i}" ) ?: $def['btn_text'];
		$btn_link = get_option( "ticinoweb_slider_btn_link_{$i}" ) ?: $def['btn_link'];

		if ( function_exists( 'ticinoweb_frontend_text' ) ) {
			$title    = ticinoweb_frontend_text( $title, "theme:slider:{$i}:title" );
			$desc     = ticinoweb_frontend_text( $desc, "theme:slider:{$i}:description" );
			$btn_text = ticinoweb_frontend_text( $btn_text, "theme:slider:{$i}:btn_text" );
		}
		if ( function_exists( 'ticinoweb_frontend_url' ) ) {
			$btn_link = ticinoweb_frontend_url( $btn_link, "theme:slider:{$i}:btn_link" );
		}

		if ( ! empty( $title ) ) {
			$slides[] = array(
				'index'    => $i,
				'title'    => $title,
				'desc'     => $desc,
				'btn_text' => $btn_text,
				'btn_link' => $btn_link,
			);
		}
	}

	return array(
		'video_url'     => $video_url,
		'video_sources' => $is_video ? telecomsecurity_get_hero_video_sources( $video_url ) : array(),
		'is_video'      => $is_video,
		'slides'        => $slides,
	);
}

/** Resolve CMS image URLs reliably, including multisite upload paths. */
function telecomsecurity_attachment_id_from_url( string $url ): int {
	if ( '' === $url ) {
		return 0;
	}

	$attachment_id = attachment_url_to_postid( $url );
	if ( $attachment_id ) {
		return $attachment_id;
	}

	$path = (string) wp_parse_url( $url, PHP_URL_PATH );
	$relative_path = preg_replace( '#^.*?/uploads/(?:sites/\d+/)?#', '', $path );
	if ( ! $relative_path || $relative_path === $path ) {
		return 0;
	}

	$matches = get_posts(
		array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'meta_key'       => '_wp_attached_file',
			'meta_value'     => sanitize_text_field( rawurldecode( $relative_path ) ),
		)
	);

	return $matches ? absint( $matches[0] ) : 0;
}

/** Return an attachment focal point, with a safe crop correction for the existing audio-studio asset. */
function telecomsecurity_service_image_position( int $attachment_id, string $url ): string {
	foreach ( array( '_wp_attachment_image_position', 'focal_point', '_focal_point' ) as $meta_key ) {
		$focal = $attachment_id ? get_post_meta( $attachment_id, $meta_key, true ) : '';
		if ( is_array( $focal ) && isset( $focal['x'], $focal['y'] ) ) {
			$x = (float) $focal['x'];
			$y = (float) $focal['y'];
			$x = $x <= 1 ? $x * 100 : $x;
			$y = $y <= 1 ? $y * 100 : $y;
			return sprintf( '%s%% %s%%', max( 0, min( 100, $x ) ), max( 0, min( 100, $y ) ) );
		}
		if ( is_string( $focal ) && preg_match( '/^\s*(\d{1,3}(?:\.\d+)?)%?\s+(\d{1,3}(?:\.\d+)?)%?\s*$/', $focal, $point ) ) {
			return sprintf( '%s%% %s%%', min( 100, (float) $point[1] ), min( 100, (float) $point[2] ) );
		}
	}

	$filename = strtolower( wp_basename( (string) wp_parse_url( $url, PHP_URL_PATH ) ) );
	if ( 'side-view-musician-working-in-studio.png' === $filename ) {
		return '50% 88%';
	}
	if ( 'cctv-camera-in-front-of-building.png' === $filename ) {
		return '50% 30%';
	}

	return '50% 50%';
}

/** Services retain the image, page and area stored in their own CMS row. */
function telecomsecurity_get_services_explorer_data(): array {
	if ( ! function_exists( 'ticinoweb_get_services' ) ) {
		return array();
	}
	$groups = array( 'security' => array(), 'infrastructure' => array() );
	foreach ( ticinoweb_get_services() as $srv ) {
		$title = trim( wp_strip_all_tags( $srv['title'] ?? '' ) );
		if ( '' === $title ) {
			continue;
		}
		$page_id = absint( $srv['page_id'] ?? 0 );
		$id = sanitize_key( $srv['id'] ?? '' );
		// Compatibility with pre-migration rows; new/edited rows persist their ID in the CMS.
		if ( ! $id ) {
			$id = $page_id ? 'page_' . $page_id : sanitize_title( $title );
		}
		$area = ( $srv['area'] ?? '' ) === 'infrastructure' ? 'infrastructure' : 'security';
		$featured_id  = $page_id ? get_post_thumbnail_id( $page_id ) : 0;
		$fallback_url = esc_url_raw( $srv['image'] ?? '' );
		$attachment_id = $featured_id ?: ( $fallback_url ? telecomsecurity_attachment_id_from_url( $fallback_url ) : 0 );
		$image = $featured_id ? ( wp_get_attachment_image_url( $featured_id, 'full' ) ?: $fallback_url ) : $fallback_url;
		$page_title = $page_id ? trim( (string) get_the_title( $page_id ) ) : '';
		$groups[ $area ][] = array(
			'id' => $id,
			'geometry' => telecomsecurity_service_symbol($srv),
			'page_id' => $page_id,
			'area' => $area,
			'title' => $page_title ?: $title,
			'description' => wp_kses_post( $srv['description'] ?? '' ),
			'image' => $image,
			'image_id' => $attachment_id,
			'image_srcset' => $attachment_id ? wp_get_attachment_image_srcset( $attachment_id, 'full' ) : '',
			'image_position' => telecomsecurity_service_image_position( $attachment_id, $image ),
			'url' => $page_id ? get_permalink( $page_id ) : '',
		);
	}
	$services = array_merge( $groups['security'], $groups['infrastructure'] );
	foreach ( $services as $index => &$service ) {
		$service['index'] = sprintf( '%02d', $index + 1 );
		$service['total'] = sprintf( '%02d', count( $services ) );
	}
	unset( $service );
	return $services;
}

/** Detect the native services archive page from the current CMS relationships. */
function telecomsecurity_is_services_archive(): bool {
	if ( ! is_page() || ! function_exists( 'ticinoweb_get_services' ) ) {
		return false;
	}

	$current_id = get_queried_object_id();
	foreach ( (array) ticinoweb_get_services() as $service ) {
		$page_id = absint( $service['page_id'] ?? 0 );
		if ( $page_id && wp_get_post_parent_id( $page_id ) === $current_id ) {
			return true;
		}
	}

	return false;
}

/** Return a concise, complete CMS sentence without truncating editorial copy. */
function telecomsecurity_service_summary( string $description ): string {
	$plain = trim( (string) preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $description ) ) );
	if ( '' === $plain ) {
		return '';
	}

	$sentences = preg_split( '/(?<=[.!?])\s+/u', $plain, -1, PREG_SPLIT_NO_EMPTY );
	if ( ! $sentences ) {
		return $plain;
	}

	$word_count = static function ( string $sentence ): int {
		return preg_match_all( "/[\p{L}\p{N}]+(?:[’'-][\p{L}\p{N}]+)*/u", $sentence ) ?: 0;
	};

	foreach ( $sentences as $sentence ) {
		$count = $word_count( $sentence );
		if ( $count >= 18 && $count <= 28 ) {
			return trim( $sentence );
		}
	}

	foreach ( $sentences as $sentence ) {
		$count = $word_count( $sentence );
		if ( $count >= 14 && $count <= 32 ) {
			return trim( $sentence );
		}
	}

	$summary = '';
	foreach ( $sentences as $sentence ) {
		$summary = trim( $summary . ' ' . $sentence );
		if ( $word_count( $summary ) >= 18 ) {
			return $summary;
		}
	}

	return trim( $sentences[0] );
}

/** Editable in the existing Services tab, alongside the existing repeater. */
function telecomsecurity_get_services_editorial_data(): array {
	$defaults = array(
		'chapter_1_title' => 'Tecnologie coordinate per prevenire, rilevare e controllare.',
		'chapter_1_text' => 'Sei sistemi dedicati alla protezione di persone, accessi e ambienti, progettati per lavorare insieme.',
		'chapter_2_title' => 'Tecnologie che collegano persone, spazi e informazioni.',
		'chapter_2_text' => 'Telecomunicazioni, automazioni e competenze tecniche al servizio del funzionamento quotidiano degli ambienti.',
		'transition_title' => 'Proteggere. Connettere. Coordinare.',
		'transition_text' => 'Due aree di competenza. Un unico sistema integrato.',
	);
	$saved = get_option( 'ts_services_editorial', array() );
	return wp_parse_args( is_array( $saved ) ? $saved : array(), $defaults );
}

/** Same row and image renderer for sticky, inline and transition views. */
function telecomsecurity_render_service_media( array $service, string $class, bool $eager = false ): void {
	if ( empty( $service['image'] ) ) {
		printf( '<div class="ts-service-placeholder" role="img" aria-label="%1$s"><span>%2$s</span></div>', esc_attr__( 'Immagine del servizio non disponibile', 'telecomsecurity-child-theme' ), esc_html( $service['title'] ) );
		return;
	}
	?>
	<img src="<?php echo esc_url( $service['image'] ); ?>" alt="<?php echo esc_attr( $service['title'] ); ?>" class="<?php echo esc_attr( $class ); ?>" loading="<?php echo $eager ? 'eager' : 'lazy'; ?>" decoding="async"<?php if ( ! empty( $service['image_srcset'] ) ) : ?> srcset="<?php echo esc_attr( $service['image_srcset'] ); ?>" sizes="(max-width: 1024px) 92vw, 620px"<?php endif; ?>>
	<?php
}

/** Decorative propagation, behind the photo; no canvas or extra dependency. */
function telecomsecurity_render_services_signal(): void {
	?>
	<svg class="ts-services-signal" viewBox="0 0 600 720" fill="none" aria-hidden="true" focusable="false">
		<g class="ts-services-signal__arcs" stroke="currentColor" stroke-width="1">
			<path d="M480 80 A280 280 0 0 0 480 640"/><path d="M480 130 A230 230 0 0 0 480 590"/><path d="M480 180 A180 180 0 0 0 480 540"/>
		</g>
		<path d="M100 620 H510" stroke="currentColor" stroke-width="1"/>
		<circle class="ts-services-signal__dot" cx="100" cy="620" r="3" fill="currentColor"/>
	</svg>
	<?php
}

/**
 * Normalizza una credenziale per confrontarla con il testo editoriale del CMS.
 *
 * @param string $value Valore da normalizzare.
 * @return string Valore minuscolo senza accenti o punteggiatura.
 */
function telecomsecurity_normalize_about_reference( string $value ): string {
	$value = remove_accents( wp_strip_all_tags( $value ) );
	$value = function_exists( 'mb_strtolower' ) ? mb_strtolower( $value, 'UTF-8' ) : strtolower( $value );
	$value = (string) preg_replace( '/[^\p{L}\p{N}]+/u', ' ', $value );

	return trim( (string) preg_replace( '/\s+/u', ' ', $value ) );
}

/**
 * Separa il paragrafo delle credenziali soltanto quando contiene tutti i
 * riferimenti strutturati già disponibili nel CMS globale.
 *
 * Il riconoscimento è semantico e non dipende dalla posizione del paragrafo.
 * Se la corrispondenza non è completa, il testo originale rimane intatto.
 *
 * @param string $text        Testo istituzionale della pagina.
 * @param array  $credentials Credenziali strutturate del CMS.
 * @return array Testo principale e paragrafo credenziali separato.
 */
function telecomsecurity_split_about_credentials( string $text, array $credentials ): array {
	$markers = array_values(
		array_unique(
			array_filter(
				array_map( 'telecomsecurity_normalize_about_reference', $credentials ),
				static fn( string $marker ): bool => strlen( $marker ) >= 3
			)
		)
	);

	$paragraphs = preg_split( '/\R[ \t]*\R+/u', trim( $text ), -1, PREG_SPLIT_NO_EMPTY );
	if ( count( $markers ) < 2 || ! is_array( $paragraphs ) || count( $paragraphs ) < 2 ) {
		return array( 'text' => $text, 'context' => '' );
	}

	foreach ( $paragraphs as $index => $paragraph ) {
		$normalized = telecomsecurity_normalize_about_reference( $paragraph );
		$matches    = array_filter(
			$markers,
			static fn( string $marker ): bool => str_contains( $normalized, $marker )
		);

		if ( count( $matches ) !== count( $markers ) ) {
			continue;
		}

		unset( $paragraphs[ $index ] );
		return array(
			'text'    => trim( implode( "\n\n", $paragraphs ) ),
			'context' => trim( $paragraph ),
		);
	}

	return array( 'text' => $text, 'context' => '' );
}

/**
 * Recupera i dati univoci della pagina Chi siamo.
 *
 * I quattro campi del CMS ticinoWEB restano la sorgente canonica. L'estratto
 * nativo della pagina viene utilizzato soltanto quando è stato compilato
 * esplicitamente, senza ricavarlo dal testo istituzionale.
 *
 * @param int $post_id ID della pagina Chi siamo.
 * @return array Dati normalizzati per il template.
 */
function telecomsecurity_get_about_page_data( int $post_id = 0 ): array {
	$post_id = $post_id > 0 ? $post_id : get_queried_object_id();
	$title   = trim( (string) get_option( 'ticinoweb_chi_siamo_title', '' ) );
	$text    = trim( (string) get_option( 'ticinoweb_chi_siamo_text', '' ) );
	$image   = trim( (string) get_option( 'ticinoweb_chi_siamo_image', '' ) );
	$link    = trim( (string) get_option( 'ticinoweb_chi_siamo_link', '' ) );

	if ( function_exists( 'ticinoweb_frontend_text' ) ) {
		$title = (string) ticinoweb_frontend_text( $title, 'theme:about:title' );
		$text  = (string) ticinoweb_frontend_text( $text, 'theme:about:text' );
	}
	if ( function_exists( 'ticinoweb_frontend_url' ) ) {
		$link = (string) ticinoweb_frontend_url( $link, 'theme:about:link' );
	}

	$page_title = $post_id > 0 ? trim( (string) get_the_title( $post_id ) ) : '';
	$intro      = $post_id > 0 && has_excerpt( $post_id )
		? trim( (string) get_post_field( 'post_excerpt', $post_id ) )
		: '';
	$image_id        = $image ? attachment_url_to_postid( $image ) : 0;
	$image_alt       = $image_id ? trim( (string) get_post_meta( $image_id, '_wp_attachment_image_alt', true ) ) : '';
	$credentials     = array();
	$credential_label = '';
	if ( function_exists( 'telecomsecurity_identity' ) ) {
		$credentials = array_values(
			array_filter(
				array(
					trim( (string) telecomsecurity_identity( 'fact_3_badge_1' ) ),
					trim( (string) telecomsecurity_identity( 'fact_3_badge_2' ) ),
				)
			)
		);
		$credential_label = trim( (string) telecomsecurity_identity( 'fact_3_label' ) );
	}
	$story = telecomsecurity_split_about_credentials( $text, $credentials );
	if ( '' === $story['context'] ) {
		$credentials = array();
	}

	if ( '' === $link && function_exists( 'ticinoweb_get_mapped_page_url' ) ) {
		$link = (string) ticinoweb_get_mapped_page_url( 'page_contatti' );
	}
	if ( '' === $link ) {
		$contact_page = get_page_by_path( 'contatti' );
		$link         = $contact_page instanceof WP_Post ? (string) get_permalink( $contact_page ) : '';
	}

	return array(
		'label'               => $page_title,
		'title'               => '' !== $title ? $title : $page_title,
		'intro'               => $intro,
		'text'                => $story['text'],
		'credentials'         => $credentials,
		'credentials_context' => $story['context'],
		'credentials_label'   => $credential_label,
		'image'               => $image,
		'image_id'            => $image_id,
		'image_alt'           => '' !== $image_alt ? $image_alt : ( '' !== $title ? $title : $page_title ),
		'cta_label'           => function_exists( 'telecomsecurity_identity' ) ? trim( telecomsecurity_identity( 'cta_label' ) ) : '',
		'cta_title'           => function_exists( 'telecomsecurity_identity' ) ? trim( telecomsecurity_identity( 'cta_title' ) ) : '',
		'cta_text'            => function_exists( 'telecomsecurity_identity' ) ? trim( telecomsecurity_identity( 'cta_text' ) ) : '',
		'cta_button'          => function_exists( 'telecomsecurity_identity' ) ? trim( telecomsecurity_identity( 'cta_button' ) ) : '',
		'cta_link'            => $link,
	);
}

/**
 * Recupera l'elenco dinamico dei Partner / Tecnologie configurati nel CMS.
 *
 * @return array Elenco loghi e link partner (o array vuoto se non presenti).
 */
function telecomsecurity_get_partners_list(): array {
	$partner_count = (int) get_option( 'ticinoweb_partner_count', 0 );
	if ( $partner_count <= 0 ) {
		return array();
	}

	$partners = array();
	for ( $i = 1; $i <= $partner_count; $i++ ) {
		$logo = get_option( "ticinoweb_partner_logo_{$i}", '' );
		$link = get_option( "ticinoweb_partner_link_{$i}", '' );

		if ( ! empty( $logo ) ) {
			$attachment_id = telecomsecurity_attachment_id_from_url( (string) $logo );
			$alt           = $attachment_id ? trim( (string) get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ) ) : '';
			if ( '' === $alt && $attachment_id ) {
				$alt = trim( (string) get_the_title( $attachment_id ) );
			}
			if ( '' === $alt ) {
				$filename = pathinfo( (string) wp_parse_url( $logo, PHP_URL_PATH ), PATHINFO_FILENAME );
				$alt      = trim( ucwords( str_replace( array( '-', '_' ), ' ', $filename ) ) );
			}
			if ( '' === $alt ) {
				$alt = trim( (string) get_bloginfo( 'name' ) );
			}
			$partners[] = array(
				'index' => $i,
				'logo'  => esc_url( $logo ),
				'link'  => ! empty( $link ) ? esc_url( $link ) : '',
				'alt'   => $alt,
			);
		}
	}

	return $partners;
}

/**
 * Recupera i recapiti aziendali verificati di Telecom Security SA.
 *
 * @return array Dati di contatto pubblici verificati.
 */
function telecomsecurity_get_contact_data(): array {
	return array(
		'phone'     => '091 857 68 55',
		'phone_raw' => '+41918576855',
		'email'     => 'info@telecomsecurity.ch',
		'address'   => '6514 Sementina, Zona Industriale',
		'city'      => 'Sementina',
		'canton'    => 'Ticino',
	);
}
