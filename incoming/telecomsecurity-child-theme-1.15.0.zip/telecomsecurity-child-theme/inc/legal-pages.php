<?php
/**
 * Managed legal pages for Telecom Security SA.
 *
 * The pages remain native WordPress content. This installer only creates or
 * refreshes pages carrying its own management marker, so editorial pages with
 * the same slug are never overwritten accidentally.
 */
defined( 'ABSPATH' ) || exit;

/**
 * Return the approved legal page definitions.
 *
 * @return array<string,array{title:string,content:string}>
 */
function telecomsecurity_legal_page_specs(): array {
	$privacy = <<<'HTML'
<p class="ts-legal-meta"><strong>Ultimo aggiornamento:</strong> 23 settembre 2026</p>
<p>Questa informativa descrive come Telecom Security SA tratta i dati personali raccolti attraverso il presente sito web e in occasione delle richieste di contatto. È redatta secondo la Legge federale sulla protezione dei dati (LPD) e la relativa ordinanza.</p>

<h2>1. Titolare del trattamento</h2>
<p><strong>Telecom Security SA</strong><br>Zona Industriale, 6514 Sementina, Svizzera<br>E-mail: <a href="mailto:info@telecomsecurity.ch">info@telecomsecurity.ch</a><br>Telefono: <a href="tel:+41918576855">091 857 68 55</a></p>

<h2>2. Dati trattati e modalità di raccolta</h2>
<p>Possiamo trattare le seguenti categorie di dati:</p>
<ul>
<li><strong>dati tecnici di navigazione</strong>, come indirizzo IP, data e ora della richiesta, pagina richiesta, browser, sistema operativo e informazioni tecniche necessarie alla trasmissione e alla sicurezza del sito, normalmente registrati nei log del server;</li>
<li><strong>dati di contatto e contenuto delle comunicazioni</strong> forniti volontariamente tramite e-mail, telefono o altri canali indicati sul sito;</li>
<li><strong>dati relativi a richieste, offerte e rapporti contrattuali</strong>, quando necessari per preparare una consulenza, un sopralluogo, un'offerta o per eseguire un incarico;</li>
<li><strong>dati relativi ai cookie tecnici</strong> descritti nella sezione seguente.</li>
</ul>

<h2>3. Finalità del trattamento</h2>
<p>I dati vengono trattati per rendere disponibile e proteggere il sito, diagnosticare problemi tecnici, rispondere alle richieste, preparare offerte, organizzare sopralluoghi, eseguire misure precontrattuali o contrattuali, adempiere obblighi legali e tutelare eventuali pretese giuridiche. Non utilizziamo i dati raccolti dal sito per decisioni individuali automatizzate o profilazione.</p>

<h2>4. Cookie e misurazione delle visite</h2>
<p>Il sito utilizza soltanto funzioni proprietarie e tecniche nella configurazione attuale:</p>
<ul>
<li><code>ticinoweb_visit_AAAAMMGG</code>: cookie tecnico di prima parte, valido per 24 ore, usato per evitare di conteggiare più volte la stessa visita nella giornata. Il sistema conserva unicamente totali giornalieri aggregati, senza creare profili individuali;</li>
<li>cookie tecnici di WordPress: utilizzati solo quando una persona autorizzata accede all'area amministrativa o quando sono necessari per le funzioni di sessione e sicurezza.</li>
</ul>
<p>Nella configurazione attuale non sono attivi Google Analytics, pixel pubblicitari, font remoti, mappe incorporate o video ospitati da piattaforme esterne. Se in futuro fossero introdotti strumenti non strettamente necessari, questa informativa e gli eventuali meccanismi di consenso verranno aggiornati prima dell'attivazione.</p>

<h2>5. Destinatari e responsabili del trattamento</h2>
<p>I dati possono essere accessibili al personale autorizzato e, quando necessario, a fornitori che gestiscono hosting, manutenzione informatica, comunicazioni o servizi professionali per conto di Telecom Security SA. Questi soggetti possono trattare i dati soltanto per le finalità affidate e con adeguati obblighi di riservatezza e sicurezza. I dati possono inoltre essere comunicati ad autorità o terzi quando ciò è imposto dalla legge o necessario per accertare, esercitare o difendere un diritto. I dati personali non vengono venduti.</p>

<h2>6. Comunicazioni all'estero</h2>
<p>Il sito non integra attualmente servizi di analisi o marketing che comportino una comunicazione automatica di dati a fornitori esteri. Qualora un fornitore operativo trattasse dati fuori dalla Svizzera, Telecom Security SA verificherà l'esistenza di un livello di protezione adeguato oppure adotterà le garanzie richieste dalla LPD e informerà le persone interessate quando necessario.</p>

<h2>7. Conservazione</h2>
<p>I dati vengono conservati per il tempo necessario alle finalità indicate e successivamente cancellati o anonimizzati, salvo obblighi legali di conservazione o necessità di tutela di pretese. I conteggi giornalieri delle visite sono aggregati e mantenuti per un massimo di circa 400 giorni; il relativo cookie scade dopo 24 ore. I tempi dei log tecnici dipendono dalle impostazioni di sicurezza e manutenzione dell'infrastruttura. Le comunicazioni e i documenti relativi a offerte o incarichi vengono conservati per la durata del rapporto e per i successivi termini legali applicabili.</p>

<h2>8. Sicurezza</h2>
<p>Adottiamo misure tecniche e organizzative adeguate al rischio per proteggere i dati da accessi non autorizzati, perdita, alterazione o divulgazione. Nessuna trasmissione via Internet può tuttavia essere garantita come assolutamente sicura.</p>

<h2>9. Diritti delle persone interessate</h2>
<p>Nei limiti previsti dalla LPD, è possibile chiedere informazioni sui propri dati, ottenerne la rettifica o la cancellazione, opporsi a determinati trattamenti e richiedere la consegna o la trasmissione dei dati quando ne ricorrono i presupposti. La richiesta può essere inviata a <a href="mailto:info@telecomsecurity.ch">info@telecomsecurity.ch</a>. Per proteggere i dati potremo richiedere elementi utili a verificare l'identità della persona richiedente.</p>

<h2>10. Collegamenti esterni e aggiornamenti</h2>
<p>Il sito può contenere collegamenti a siti di terzi, che operano sotto la propria responsabilità e secondo informative autonome. La presente informativa può essere aggiornata in caso di modifiche normative, organizzative o tecniche; la versione pubblicata su questa pagina è quella applicabile.</p>
HTML;

	$terms = <<<'HTML'
<p class="ts-legal-meta"><strong>Ultimo aggiornamento:</strong> 23 settembre 2026</p>
<p>I presenti Termini &amp; Condizioni disciplinano l'accesso e l'utilizzo del sito web di Telecom Security SA. Utilizzando il sito, l'utente accetta le condizioni qui riportate e si impegna a farne un uso conforme alla legge.</p>

<h2>1. Titolare del sito</h2>
<p><strong>Telecom Security SA</strong><br>Zona Industriale, 6514 Sementina, Svizzera<br>E-mail: <a href="mailto:info@telecomsecurity.ch">info@telecomsecurity.ch</a><br>Telefono: <a href="tel:+41918576855">091 857 68 55</a></p>

<h2>2. Scopo informativo</h2>
<p>Il sito presenta l'azienda, le aree di competenza e i servizi offerti. Testi, fotografie, esempi e descrizioni hanno carattere generale e informativo. Salvo indicazione espressa, non costituiscono un'offerta vincolante, una garanzia di disponibilità, una specifica tecnica definitiva o una consulenza professionale riferita a un caso concreto.</p>

<h2>3. Richieste, sopralluoghi e conclusione dei contratti</h2>
<p>L'invio di un'e-mail, una telefonata o una richiesta di consulenza non conclude automaticamente un contratto. Prestazioni, configurazioni tecniche, prezzi, scadenze e responsabilità vengono definiti nella singola offerta, conferma d'ordine o contratto. In caso di contrasto, le condizioni concordate per iscritto nel rapporto specifico prevalgono sui presenti termini d'uso del sito.</p>

<h2>4. Uso consentito del sito</h2>
<p>È vietato utilizzare il sito in modo da comprometterne sicurezza, disponibilità o integrità, tentare accessi non autorizzati, introdurre codice dannoso, raccogliere dati con strumenti automatizzati in modo abusivo o usare contenuti e segni distintivi per finalità illecite o ingannevoli.</p>

<h2>5. Proprietà intellettuale</h2>
<p>Struttura, testi, elementi grafici, fotografie, marchi, loghi e altri contenuti del sito sono protetti dalle norme applicabili e appartengono a Telecom Security SA o ai rispettivi titolari. La consultazione e la stampa per uso personale sono consentite. Ogni riproduzione, modifica, distribuzione o utilizzo commerciale ulteriore richiede il consenso preventivo del titolare dei relativi diritti.</p>

<h2>6. Accuratezza e aggiornamento</h2>
<p>Telecom Security SA cura i contenuti con attenzione e può aggiornarli in qualsiasi momento. Non è tuttavia garantito che ogni informazione sia sempre completa, priva di errori o aggiornata in tempo reale. Per decisioni tecniche, economiche o di sicurezza è necessario richiedere una valutazione riferita al caso concreto.</p>

<h2>7. Disponibilità e sicurezza</h2>
<p>Il sito può essere temporaneamente sospeso o limitato per manutenzione, aggiornamenti, guasti o eventi fuori dal ragionevole controllo dell'azienda. Telecom Security SA adotta misure adeguate per la sicurezza del servizio, ma non può garantire un funzionamento ininterrotto o l'assenza assoluta di vulnerabilità.</p>

<h2>8. Collegamenti a siti di terzi</h2>
<p>I collegamenti esterni sono forniti per comodità. Telecom Security SA non controlla contenuti, disponibilità o pratiche di protezione dei dati dei siti di terzi e non ne assume la responsabilità. L'accesso avviene sotto la responsabilità dell'utente.</p>

<h2>9. Responsabilità</h2>
<p>Nei limiti consentiti dal diritto applicabile, Telecom Security SA non risponde di danni derivanti dall'affidamento esclusivo su informazioni generali del sito, da interruzioni non imputabili all'azienda o dall'uso improprio del sito. Restano integralmente salve le responsabilità che non possono essere escluse o limitate per legge.</p>

<h2>10. Protezione dei dati</h2>
<p>Il trattamento dei dati personali connesso all'uso del sito è descritto nella <a href="{{privacy_url}}">Privacy Policy</a>, che costituisce parte integrante delle informazioni rese agli utenti.</p>

<h2>11. Diritto applicabile</h2>
<p>I presenti termini sono disciplinati dal diritto svizzero. Foro competente e modalità di tutela sono determinati dalle norme applicabili; restano riservati i fori imperativi previsti a protezione dei consumatori e ogni altra disposizione inderogabile.</p>

<h2>12. Modifiche e contatti</h2>
<p>Telecom Security SA può aggiornare questi termini per adeguarli a modifiche del sito, dei servizi o della normativa. La versione pubblicata su questa pagina è quella applicabile. Per domande: <a href="mailto:info@telecomsecurity.ch">info@telecomsecurity.ch</a>.</p>
HTML;

	return array(
		'privacy-policy' => array(
			'title'   => 'Privacy Policy',
			'content' => $privacy,
		),
		'termini-condizioni' => array(
			'title'   => 'Termini & Condizioni',
			'content' => $terms,
		),
	);
}

/**
 * Create or refresh the managed legal pages.
 *
 * @param bool $force Run even when the installed content version is current.
 * @return array<string,int|WP_Error>
 */
function telecomsecurity_ensure_legal_pages( bool $force = false ): array {
	$content_version = '1.0.0';
	if ( ! $force && get_option( 'ts_legal_pages_version' ) === $content_version ) {
		return array();
	}

	$results = array();
	foreach ( telecomsecurity_legal_page_specs() as $slug => $spec ) {
		$page = get_page_by_path( $slug, OBJECT, 'page' );
		if ( $page instanceof WP_Post && '1' !== get_post_meta( $page->ID, '_ts_managed_legal_page', true ) ) {
			$results[ $slug ] = $page->ID;
			continue;
		}

		$post_data = array(
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_name'    => $slug,
			'post_title'   => $spec['title'],
			'post_content' => wp_slash( str_replace( '{{privacy_url}}', esc_url( home_url( '/privacy-policy/' ) ), $spec['content'] ) ),
			'meta_input'   => array( '_ts_managed_legal_page' => '1' ),
		);
		if ( $page instanceof WP_Post ) {
			$post_data['ID'] = $page->ID;
		}

		$results[ $slug ] = wp_insert_post( $post_data, true );
	}

	$privacy_id = $results['privacy-policy'] ?? 0;
	if ( is_int( $privacy_id ) && $privacy_id > 0 ) {
		update_option( 'wp_page_for_privacy_policy', $privacy_id );
	}

	if ( ! array_filter( $results, 'is_wp_error' ) ) {
		update_option( 'ts_legal_pages_version', $content_version, false );
		flush_rewrite_rules( false );
	}

	return $results;
}

add_action( 'after_switch_theme', 'telecomsecurity_ensure_legal_pages' );
add_action( 'admin_init', 'telecomsecurity_ensure_legal_pages' );
