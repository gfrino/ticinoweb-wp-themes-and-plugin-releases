<?php
/**
 * The template for displaying the Front Page (Home).
 *
 * Revisione editoriale e moderna di Telecom Security SA:
 * 1. Allineamento rigoroso della sezione Visione Integrata con l'header e il container a 1300px.
 * 2. Tecnologie e partner subito dopo la visione aziendale, con marquee continuo.
 * 3. Sezione Servizi Sticky con stage fotografico esteso in altezza (cover totale),
 *    immagini 100% dinamiche dal CMS, ed elemento di sfondo discreto in loop continuo.
 * 4. Bottoni e CTA bilanciati con spaziatura calibrata e testo perfettamente centrato.
 * 5. Metodo di lavoro potenziato con card architettoniche a timeline, badge di fase e nodi pulsanti.
 * 6. Sezione contatti riequilibrata e luminosa, senza blocchi scuri invasivi.
 *
 * @package TelecomSecurityChild
 * @version 1.12.14
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

// Dati dinamici dal CMS
$hero_data     = telecomsecurity_get_hero_data();
$services_data = telecomsecurity_get_services_explorer_data();
$method_data   = telecomsecurity_get_method_section_data();
$contacts_data = telecomsecurity_get_contact_data();
?>

<main id="primary-content" class="ts-home-main" role="main">

	<!-- ==========================================================================
	     1. HERO VIDEO — Loop Continuo Indipendente & Titolo Monoriga
	     ========================================================================== -->
	<section class="ts-hero is-searchlight-pending" id="ts-hero" data-signal-label="HOME" data-signal-theme="dark" aria-label="<?php esc_attr_e( 'Presentazione aziendale Telecom Security', 'telecomsecurity-child-theme' ); ?>">
		<noscript><style>.ts-hero.is-searchlight-pending .ts-hero__content-box{opacity:1;visibility:visible;transform:none;filter:none;pointer-events:auto}</style></noscript>

		<div class="ts-hero__media-wrapper">
			<?php if ( ! empty( $hero_data['is_video'] ) && ! empty( $hero_data['video_sources'] ) ) : ?>
				<video class="ts-hero__video is-active" id="ts-hero-video-a" autoplay muted playsinline loop preload="auto">
					<?php foreach ( $hero_data['video_sources'] as $source ) : ?>
						<source src="<?php echo esc_url( $source['url'] ); ?>" type="<?php echo esc_attr( $source['type'] ); ?>"<?php echo $source['media'] ? ' media="' . esc_attr( $source['media'] ) . '"' : ''; ?>>
					<?php endforeach; ?>
				</video>
			<?php else : ?>
				<div class="ts-hero__video-fallback" aria-hidden="true"></div>
			<?php endif; ?>
			<div class="ts-hero__overlay" aria-hidden="true"></div>
		</div>
		<?php if ( ! empty( $hero_data['is_video'] ) ) : ?>
			<button class="ts-hero__video-play" type="button" data-hero-video-play hidden>
				<span aria-hidden="true">▶</span>
				<?php esc_html_e( 'Avvia il video', 'telecomsecurity-child-theme' ); ?>
			</button>
		<?php endif; ?>

		<div class="ts-container ts-hero__container">
			<div class="ts-hero__layout">
				<div class="ts-hero__content-box ts-corners">

					<div class="ts-hero__badge">
						<span class="ts-signal-pulse" aria-hidden="true"></span>
						<span class="ts-hero__badge-text"><?php echo esc_html(telecomsecurity_identity('hero_label_1')); ?></span>
					</div>

					<div class="ts-hero__text-track" id="ts-hero-text-track">
						<?php foreach ( $hero_data['slides'] as $s_idx => $slide ) : ?>
							<article class="ts-hero__slide-text <?php echo 0 === $s_idx ? 'is-active' : ''; ?>" data-security-label="<?php echo esc_attr(telecomsecurity_identity('hero_label_' . ($s_idx + 1)) ?: telecomsecurity_identity('hero_label_1')); ?>" data-slide="<?php echo esc_attr( $s_idx ); ?>" aria-hidden="<?php echo 0 === $s_idx ? 'false' : 'true'; ?>">
								<h1 class="ts-hero__title" data-hero-title><?php echo esc_html( trim( strip_tags( $slide['title'] ) ) ); ?></h1>
								<p class="ts-hero__description"><?php echo esc_html( $slide['desc'] ); ?></p>
								<div class="ts-hero__cta-group">
									<a href="<?php echo esc_url( ! empty( $slide['btn_link'] ) ? $slide['btn_link'] : '#servizi' ); ?>" class="ts-btn ts-btn--hero">
										<span><?php echo esc_html( $slide['btn_text'] ); ?></span>
										<span class="ts-btn__arrow" aria-hidden="true">→</span>
									</a>
								</div>
							</article>
						<?php endforeach; ?>
					</div>

				</div>
				<div class="ts-hero__visual">
					<?php echo telecomsecurity_hero_searchlight(); ?>
				</div>
			</div>
		</div>

		<a href="#intro" class="ts-hero__scroll-cue" aria-label="<?php esc_attr_e( 'Scorri alla sezione successiva', 'telecomsecurity-child-theme' ); ?>">
			<span class="ts-hero__scroll-text"><?php esc_html_e( 'Scorri', 'telecomsecurity-child-theme' ); ?></span>
			<span class="ts-hero__scroll-line" aria-hidden="true"></span>
		</a>

	</section>

	<?php
	$proof_labels = array();
	for ( $proof_index = 1; $proof_index <= 3; $proof_index++ ) {
		$proof_label_parts = preg_split( '/\s*\/\s*/u', telecomsecurity_identity( 'fact_' . $proof_index . '_label' ), 2 );
		$proof_labels[ $proof_index ] = array(
			'number' => isset( $proof_label_parts[1] ) ? $proof_label_parts[0] : '',
			'label'  => $proof_label_parts[1] ?? $proof_label_parts[0] ?? '',
		);
	}
	?>
	<!-- ==========================================================================
	     2. TRANSIZIONE EDITORIALE — Allineata con il Container e l'Header
	     ========================================================================== -->
	<section class="ts-intro" id="intro" data-signal-label="VISIONE INTEGRATA" data-signal-theme="light" aria-label="<?php esc_attr_e( 'Visione aziendale', 'telecomsecurity-child-theme' ); ?>">
		<?php $intro_icon = telecomsecurity_get_intro_icon_url(); ?>
		<?php if ( $intro_icon ) : ?>
			<div class="ts-intro__watermark" aria-hidden="true">
				<?php
				$intro_icon_id = attachment_url_to_postid( $intro_icon );
				if ( $intro_icon_id ) {
					echo wp_get_attachment_image(
						$intro_icon_id,
						'full',
						false,
						array(
							'alt'      => '',
							'loading'  => 'lazy',
							'decoding' => 'async',
							'sizes'    => '(max-width: 767px) 400px, (max-width: 1199px) 560px, 900px',
						)
					);
				} else {
					?>
					<img src="<?php echo esc_url( $intro_icon ); ?>" alt="" loading="lazy" decoding="async">
					<?php
				}
				?>
			</div>
		<?php endif; ?>
		<div class="ts-container">

			<div class="ts-intro__editorial">
				<div class="ts-section-tag">
					<span class="ts-signal-line" aria-hidden="true"></span>
					<span><?php echo esc_html(telecomsecurity_identity('intro_label')); ?></span>
				</div>

				<h2 class="ts-intro__statement" data-reveal-line>
					<?php echo esc_html(telecomsecurity_identity('intro_title')); ?>
				</h2>

				<p class="ts-intro__subtext">
					<?php echo esc_html(telecomsecurity_identity('intro_text')); ?>
				</p>

				<div class="ts-intro__facts" data-proof-bar aria-label="<?php esc_attr_e( 'Esperienza, presenza e standard', 'telecomsecurity-child-theme' ); ?>">
					<article class="ts-intro-fact" data-proof-step="1">
						<p class="ts-intro-fact__label"><?php if ( $proof_labels[1]['number'] ) : ?><span><?php echo esc_html( $proof_labels[1]['number'] ); ?></span><b aria-hidden="true">/</b><?php endif; ?><?php echo esc_html( $proof_labels[1]['label'] ); ?></p>
						<h3 class="ts-intro-fact__title"><?php echo esc_html( telecomsecurity_identity( 'fact_1_title' ) ); ?></h3>
						<p class="ts-intro-fact__text"><?php echo esc_html( telecomsecurity_identity( 'fact_1_text' ) ); ?></p>
					</article>
					<article class="ts-intro-fact" data-proof-step="2">
						<p class="ts-intro-fact__label"><?php if ( $proof_labels[2]['number'] ) : ?><span><?php echo esc_html( $proof_labels[2]['number'] ); ?></span><b aria-hidden="true">/</b><?php endif; ?><?php echo esc_html( $proof_labels[2]['label'] ); ?></p>
						<h3 class="ts-intro-fact__title"><?php echo esc_html( telecomsecurity_identity( 'fact_2_title' ) ); ?></h3>
						<p class="ts-intro-fact__text"><?php echo esc_html( telecomsecurity_identity( 'fact_2_text' ) ); ?></p>
					</article>
					<article class="ts-intro-fact" data-proof-step="3">
						<p class="ts-intro-fact__label"><?php if ( $proof_labels[3]['number'] ) : ?><span><?php echo esc_html( $proof_labels[3]['number'] ); ?></span><b aria-hidden="true">/</b><?php endif; ?><?php echo esc_html( $proof_labels[3]['label'] ); ?></p>
						<h3 class="ts-intro-fact__title"><span><?php echo esc_html( telecomsecurity_identity( 'fact_3_badge_1' ) ); ?></span><b aria-hidden="true">·</b><span><?php echo esc_html( telecomsecurity_identity( 'fact_3_badge_2' ) ); ?></span></h3>
						<p class="ts-intro-fact__text"><?php echo esc_html( telecomsecurity_identity( 'fact_3_text' ) ); ?></p>
					</article>
				</div>

			</div>

		</div>
	</section>


	<!-- 3. TECNOLOGIE & PARTNER — componente condiviso con Chi siamo. -->
	<?php get_template_part( 'template-parts/partners' ); ?>

	<!-- ==========================================================================
	     4. SERVIZI — DUE CAPITOLI VISIVI CON TRANSIZIONE CENTRALE IMMERSIVA
	     Capitolo 1: Sicurezza e Controllo (01-06) | Capitolo 2: Tecnologie e Infrastrutture (07-11)
	     ========================================================================== -->
	<?php
	if ( ! empty( $services_data ) ) :
		$chapter_1_services = array_values( array_filter( $services_data, static fn( $service ) => 'security' === $service['area'] ) );
		$chapter_2_services = array_values( array_filter( $services_data, static fn( $service ) => 'infrastructure' === $service['area'] ) );
		$services_editorial = telecomsecurity_get_services_editorial_data();
		$transition_service = $chapter_1_services ? end( $chapter_1_services ) : null;
		$arrival_service = $chapter_2_services ? reset( $chapter_2_services ) : null;
	?>
	<section class="ts-services" id="servizi" aria-labelledby="ts-services-heading">

		<!-- ======================================================================
		     CAPITOLO 1 — SICUREZZA E CONTROLLO (6 Servizi)
		     Layout: Testi a Sinistra, Foto Sticky a Destra
		     ====================================================================== -->
		<div class="ts-services-chapter ts-services-chapter--1" id="ts-services-ch1" data-signal-label="PROTEZIONE" data-signal-theme="light">
			<div class="ts-container ts-services__container">

				<!-- Intestazione Tecnica Capitolo 1 -->
				<div class="ts-chapter-tag">
					<span class="ts-chapter-num">01</span>
					<span class="ts-chapter-sep">/</span>
					<span class="ts-chapter-name">SICUREZZA E CONTROLLO</span>
				</div>

				<div class="ts-services__intro">
					<div class="ts-section-tag">
						<span class="ts-signal-line" aria-hidden="true"></span>
						<span>Soluzioni Tecnologiche</span>
					</div>
					<h2 id="ts-services-heading" class="ts-services__headline">
						<?php echo esc_html( $services_editorial['chapter_1_title'] ); ?>
					</h2>
					<p class="ts-services__lead">
						<?php echo esc_html( $services_editorial['chapter_1_text'] ); ?>
					</p>
				</div>

				<div class="ts-services-layout ts-layout--ch1" id="ts-services-wrap-ch1">

					<!-- Flusso Servizi Sinistra (01 - 06) -->
					<div class="ts-services-flow" id="ts-services-flow-ch1">
						<?php foreach ( $chapter_1_services as $s_idx => $service ) : ?>
							<article class="ts-service-flow-item <?php echo 0 === $s_idx ? 'is-active' : ''; ?>" data-service-key="<?php echo esc_attr( $service['id'] ); ?>" data-service-number="<?php echo esc_attr( $service['index'] ); ?>" data-service-total="<?php echo esc_attr( $service['total'] ); ?>" data-chapter="1" id="ts-service-<?php echo esc_attr( $service['id'] ); ?>">

								<header class="ts-service-flow-header">
									<div class="ts-service-flow-meta">
										<span class="ts-service-flow-num"><?php echo esc_html( $service['index'] ); ?></span>
										<?php echo telecomsecurity_geometry($service['geometry'], 'ts-service-symbol'); ?>
									</div>
									<h3 class="ts-service-flow-title"><?php echo esc_html( $service['title'] ); ?></h3>
								</header>

								<div class="ts-service-flow-body">
									<div class="ts-service-flow-desc">
										<?php echo wp_kses_post( wpautop( $service['description'] ) ); ?>
									</div>
									<?php if ( ! empty( $service['url'] ) ) : ?>
									<div class="ts-service-flow-cta">
										<a href="<?php echo esc_url( $service['url'] ); ?>" class="ts-link-arrow ts-link-arrow--service" aria-label="<?php echo esc_attr( sprintf( __( 'Scopri il servizio: %s', 'telecomsecurity-child-theme' ), $service['title'] ) ); ?>">
											<span><?php esc_html_e( 'Scopri il servizio', 'telecomsecurity-child-theme' ); ?></span>
											<span class="ts-link-arrow__icon" aria-hidden="true">→</span>
										</a>
									</div>
									<?php endif; ?>
								</div>

								<div class="ts-service-flow-mobile-media">
									<?php telecomsecurity_render_service_media( $service, 'ts-service-flow-mobile-img' ); ?>
								</div>
							</article>
						<?php endforeach; ?>
					</div>

					<!-- Stage Fotografico Sticky a Destra (Desktop) -->
					<div class="ts-services-sticky-stage ts-stage--right" id="ts-services-stage-ch1" aria-hidden="true">
						<?php telecomsecurity_render_services_signal(); ?>
						<div class="ts-services-sticky-frame ts-corners">
							<?php foreach ( $chapter_1_services as $s_idx => $service ) : ?>
								<div class="ts-sticky-panel <?php echo 0 === $s_idx ? 'is-active' : ''; ?>" data-service-key="<?php echo esc_attr( $service['id'] ); ?>">
									<?php telecomsecurity_render_service_media( $service, 'ts-sticky-img', 0 === $s_idx ); ?>

									<div class="ts-sticky-meta">
										<span class="ts-sticky-meta__num"><?php echo esc_html( $service['index'] ); ?></span>
										<span class="ts-sticky-meta__divider" aria-hidden="true">/</span>
										<span class="ts-sticky-meta__tag">TELECOM SECURITY · PROTEZIONE</span>
									</div>
								</div>
							<?php endforeach; ?>
						</div>
					</div>

				</div>

			</div>
		</div>

		<!-- ======================================================================
		     TRANSIZIONE CENTRALE IMMERSIVA (Tra Capitolo 1 e Capitolo 2)
		     ====================================================================== -->
		<?php if ( $transition_service && $arrival_service ) : ?>
		<div class="ts-services-transition" id="ts-services-trans" data-signal-label="TECNOLOGIE" data-signal-theme="dark" aria-labelledby="ts-trans-title">
			<div class="ts-trans-backdrop" aria-hidden="true"></div>
			<div class="ts-trans-inner ts-container">
				<div class="ts-trans-visual" aria-hidden="true">
					<div class="ts-trans-card">
						<div class="ts-trans-source"><?php telecomsecurity_render_service_media( $transition_service, 'ts-trans-img' ); ?></div>
						<div class="ts-trans-arrival"><?php telecomsecurity_render_service_media( $arrival_service, 'ts-trans-img' ); ?></div>
						<div class="ts-trans-shade"></div>
					</div>
				</div>
				<div class="ts-trans-content">
					<span class="ts-trans-count"><?php echo esc_html( $transition_service['index'] . ' / ' . $transition_service['total'] ); ?></span>
					<h3 class="ts-trans-statement" id="ts-trans-title"><?php echo esc_html( $services_editorial['transition_title'] ); ?></h3>
					<p class="ts-trans-text"><?php echo esc_html( $services_editorial['transition_text'] ); ?></p>
				</div>
			</div>
		</div>
		<?php endif; ?>

		<!-- ======================================================================
		     CAPITOLO 2 — TECNOLOGIE E INFRASTRUTTURE (5 Servizi - Layout Invertito)
		     Layout: Foto Sticky a Sinistra, Testi a Destra
		     ====================================================================== -->
		<div class="ts-services-chapter ts-services-chapter--2" id="ts-services-ch2" data-signal-label="TECNOLOGIE" data-signal-theme="light">
			<div class="ts-container ts-services__container">

				<!-- Layout Invertito: Stage Sticky a Sinistra, Flusso a Destra -->
				<div class="ts-services-layout ts-layout--ch2" id="ts-services-wrap-ch2">

					<!-- Stage Fotografico Sticky a Sinistra (Desktop) -->
					<div class="ts-services-sticky-stage ts-stage--left" id="ts-services-stage-ch2" aria-hidden="true">
						<?php telecomsecurity_render_services_signal(); ?>
						<div class="ts-services-sticky-frame ts-corners">
							<?php foreach ( $chapter_2_services as $s_idx => $service ) : ?>
								<div class="ts-sticky-panel <?php echo 0 === $s_idx ? 'is-active' : ''; ?>" data-service-key="<?php echo esc_attr( $service['id'] ); ?>">
									<?php telecomsecurity_render_service_media( $service, 'ts-sticky-img', 0 === $s_idx ); ?>

									<div class="ts-sticky-meta">
										<span class="ts-sticky-meta__num"><?php echo esc_html( $service['index'] ); ?></span>
										<span class="ts-sticky-meta__divider" aria-hidden="true">/</span>
										<span class="ts-sticky-meta__tag">TELECOM SECURITY · TECNOLOGIE</span>
									</div>
								</div>
							<?php endforeach; ?>
						</div>
					</div>

					<!-- Flusso Servizi Destra (07 - 11) -->
					<div class="ts-services-flow ts-flow--right" id="ts-services-flow-ch2">
				<!-- Intestazione Tecnica Capitolo 2 -->
				<div class="ts-chapter-tag ts-chapter-tag--ch2">
					<span class="ts-chapter-num">02</span>
					<span class="ts-chapter-sep">/</span>
					<span class="ts-chapter-name">TECNOLOGIE E INFRASTRUTTURE</span>
				</div>

				<div class="ts-services__intro">
					<h2 class="ts-services__headline"><?php echo esc_html( $services_editorial['chapter_2_title'] ); ?></h2>
					<p class="ts-services__lead"><?php echo esc_html( $services_editorial['chapter_2_text'] ); ?></p>
				</div>


						<?php foreach ( $chapter_2_services as $s_idx => $service ) : ?>
							<article class="ts-service-flow-item <?php echo 0 === $s_idx ? 'is-active' : ''; ?>" data-service-key="<?php echo esc_attr( $service['id'] ); ?>" data-service-number="<?php echo esc_attr( $service['index'] ); ?>" data-service-total="<?php echo esc_attr( $service['total'] ); ?>" data-chapter="2" id="ts-service-<?php echo esc_attr( $service['id'] ); ?>">

								<header class="ts-service-flow-header">
									<div class="ts-service-flow-meta">
										<span class="ts-service-flow-num"><?php echo esc_html( $service['index'] ); ?></span>
										<?php echo telecomsecurity_geometry($service['geometry'], 'ts-service-symbol'); ?>
									</div>
									<h3 class="ts-service-flow-title"><?php echo esc_html( $service['title'] ); ?></h3>
								</header>

								<div class="ts-service-flow-body">
									<div class="ts-service-flow-desc">
										<?php echo wp_kses_post( wpautop( $service['description'] ) ); ?>
									</div>
									<?php if ( ! empty( $service['url'] ) ) : ?>
									<div class="ts-service-flow-cta">
										<a href="<?php echo esc_url( $service['url'] ); ?>" class="ts-link-arrow ts-link-arrow--service" aria-label="<?php echo esc_attr( sprintf( __( 'Scopri il servizio: %s', 'telecomsecurity-child-theme' ), $service['title'] ) ); ?>">
											<span><?php esc_html_e( 'Scopri il servizio', 'telecomsecurity-child-theme' ); ?></span>
											<span class="ts-link-arrow__icon" aria-hidden="true">→</span>
										</a>
									</div>
									<?php endif; ?>
								</div>

								<div class="ts-service-flow-mobile-media">
									<?php telecomsecurity_render_service_media( $service, 'ts-service-flow-mobile-img' ); ?>
								</div>
							</article>
						<?php endforeach; ?>
					</div>

				</div>

			</div>
		</div>

	</section>
	<?php endif; ?>


	<!-- 5. METODO — Introduzione e pannelli nella stessa viewport; CTA nel flusso verticale. -->
	<?php if ( ! empty( $method_data['enabled'] ) && ! empty( $method_data['items'] ) ) : ?>
	<section class="ts-method-section" id="metodo" data-signal-label="METODO" data-signal-theme="light" aria-labelledby="ts-method-heading">
		<div class="ts-method__sticky-viewport" id="ts-method-sticky-viewport">
			<div class="ts-container ts-method__intro-container">
				<div class="ts-section-tag"><span class="ts-signal-line" aria-hidden="true"></span><span><?php echo esc_html( $method_data['eyebrow'] ); ?></span></div>
				<div class="ts-method__intro-copy">
					<h2 id="ts-method-heading" class="ts-method__title"><?php echo esc_html( $method_data['title'] ); ?></h2>
					<p class="ts-method__intro-desc"><?php echo esc_html( $method_data['introduction'] ); ?></p>
				</div>
			</div>
			<div class="ts-container ts-method__progress" aria-hidden="true">
				<span class="ts-method__count" id="ts-method-count"><?php echo esc_html( $method_data['items'][0]['display_number'] ); ?></span>
				<div class="ts-method__signal-rail">
					<div class="ts-method__signal-progress" id="ts-method-signal-progress"></div>
					<span class="ts-method__signal-dot" id="ts-method-signal-dot"></span>
				</div>
				<span class="ts-method__active-name" id="ts-method-active-name"><?php echo esc_html( $method_data['items'][0]['title'] ); ?></span>
			</div>
			<div class="ts-method__window" id="ts-method-window" tabindex="0" role="region" aria-label="<?php echo esc_attr( $method_data['eyebrow'] ); ?>">
				<div class="ts-method__track" id="ts-method-track" role="list">
					<?php foreach ( $method_data['items'] as $step_index => $item ) : ?>
						<article class="ts-method-card <?php echo 0 === $step_index ? 'is-active' : ''; ?>" data-step-id="<?php echo esc_attr( $item['id'] ); ?>" role="listitem">
							<div class="ts-method-card__media ts-media-pos--<?php echo esc_attr( $item['image_pos'] ); ?>">
								<?php if ( ! empty( $item['image_url'] ) ) : ?>
									<img src="<?php echo esc_url( $item['image_url'] ); ?>"
										 <?php if ( ! empty( $item['image_srcset'] ) ) : ?>srcset="<?php echo esc_attr( $item['image_srcset'] ); ?>" sizes="<?php echo esc_attr( $item['image_sizes'] ); ?>"<?php endif; ?>
										 alt="<?php echo esc_attr( $item['image_alt'] ); ?>"
										 class="ts-method-card__img"
										 loading="<?php echo 0 === $step_index ? 'eager' : 'lazy'; ?>" decoding="async">
								<?php else : ?>
									<div class="ts-method-card__placeholder" aria-hidden="true">
										<div class="ts-placeholder-grid"></div>
										<div class="ts-placeholder-blueprint">
											<span class="ts-blueprint-tag"><?php echo esc_html( $item['formatted_index'] ); ?></span>
											<span class="ts-blueprint-label"><?php echo esc_html( $item['title'] ); ?></span>
											<span class="ts-blueprint-coord">FASE TECNICA · TELECOM SECURITY</span>
										</div>
									</div>
								<?php endif; ?>
							</div>
							<div class="ts-method-card__body">
								<div class="ts-method-card__heading">
									<?php echo telecomsecurity_geometry('shield', 'ts-method-node'); ?><span class="ts-method-card__num"><?php echo esc_html( $item['display_number'] ); ?></span>
									<h3 class="ts-method-card__title"><?php echo esc_html( $item['title'] ); ?></h3>
								</div>
								<p class="ts-method-card__text"><?php echo esc_html( $item['text'] ); ?></p>
								<?php if ( ! empty( $item['url'] ) ) : ?>
									<a class="ts-method-card__link" href="<?php echo esc_url( $item['url'] ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Approfondisci: %s', 'telecomsecurity-child-theme' ), $item['title'] ) ); ?>"><span aria-hidden="true">→</span></a>
								<?php endif; ?>
							</div>
						</article>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
		<div class="ts-method-cta">
			<div class="ts-container ts-method-cta__inner">
				<div>
					<h3 class="ts-method-cta__title"><?php echo esc_html( $method_data['final_panel']['title'] ); ?></h3>
					<p class="ts-method-cta__desc"><?php echo esc_html( $method_data['final_panel']['text'] ); ?></p>
				</div>
				<a href="<?php echo esc_url( $method_data['final_panel']['url'] ); ?>" class="ts-btn ts-btn--hero"><span><?php echo esc_html( $method_data['final_panel']['btn_text'] ); ?></span><span class="ts-btn__arrow" aria-hidden="true">→</span></a>
			</div>
		</div>
	</section>
	<?php endif; ?>


	<!-- ==========================================================================
	     6. CTA FINALE & CONTATTI — Riequilibrata, Luminosa e Armonica
	     ========================================================================== -->
	<section class="ts-contact-hub" id="contatti-rapidi" data-signal-label="CONTATTI" data-signal-theme="light" aria-labelledby="ts-cta-heading">
		<div class="ts-container">

			<div class="ts-contact-hub__wrapper"><?php echo telecomsecurity_geometry('ring', 'ts-cta-perimeter'); ?>

				<!-- Colonna Principale con Invito all'Azione -->
				<div class="ts-contact-hub__main">
					<div class="ts-section-tag">
						<span class="ts-signal-line" aria-hidden="true"></span>
						<span><?php echo esc_html(telecomsecurity_identity('cta_label')); ?></span>
					</div>

					<h2 id="ts-cta-heading" class="ts-contact-hub__title">
						<?php echo esc_html(telecomsecurity_identity('cta_title')); ?>
					</h2>

					<p class="ts-contact-hub__desc">
						<?php echo esc_html(telecomsecurity_identity('cta_text')); ?>
					</p>

					<div class="ts-contact-hub__btn-wrap">
						<a href="<?php echo esc_url( home_url( '/contatti/' ) ); ?>" class="ts-btn ts-btn--hero">
							<span><?php echo esc_html(telecomsecurity_identity('cta_button')); ?></span>
							<span class="ts-btn__arrow" aria-hidden="true">→</span>
						</a>
					</div>
				</div>

				<!-- Riquadro Recapiti Verificati Sementina -->
				<div class="ts-contact-hub__card">
					<h3 class="ts-contact-hub__card-title">Recapiti Diretti Sementina</h3>

					<ul class="ts-contact-hub__list">
						<li class="ts-hub-row">
							<span class="ts-hub-row__icon" aria-hidden="true">
								<svg class="ts-hub-row__svg" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
									<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
								</svg>
							</span>
							<div class="ts-hub-row__data">
								<span class="ts-hub-row__label">Telefono Principale</span>
								<a href="tel:<?php echo esc_attr( $contacts_data['phone_raw'] ); ?>" class="ts-hub-row__val"><?php echo esc_html( $contacts_data['phone'] ); ?></a>
							</div>
						</li>
						<li class="ts-hub-row">
							<span class="ts-hub-row__icon" aria-hidden="true">
								<svg class="ts-hub-row__svg" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
									<rect x="2" y="4" width="20" height="16" rx="2"></rect>
									<path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"></path>
								</svg>
							</span>
							<div class="ts-hub-row__data">
								<span class="ts-hub-row__label">Posta Elettronica</span>
								<a href="mailto:<?php echo esc_attr( $contacts_data['email'] ); ?>" class="ts-hub-row__val"><?php echo esc_html( $contacts_data['email'] ); ?></a>
							</div>
						</li>
						<li class="ts-hub-row">
							<span class="ts-hub-row__icon" aria-hidden="true">
								<svg class="ts-hub-row__svg" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
									<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"></path>
									<circle cx="12" cy="10" r="3"></circle>
								</svg>
							</span>
							<div class="ts-hub-row__data">
								<span class="ts-hub-row__label">Sede e Laboratorio</span>
								<span class="ts-hub-row__val"><?php echo esc_html( $contacts_data['address'] ); ?></span>
							</div>
						</li>
					</ul>
				</div>

			</div>

		</div>
	</section>

</main>

<?php
get_footer();
