/**
 * Telecom Security SA — Home Interactions & Motion UI (v1.12.14)
 *
 * Funzionalità ad alta precisione:
 * 1. Header scroll transformation (trasparente su hero -> compatto chiaro con ombra)
 * 2. Hero Video Loop continuo e indipendente dalla rotazione dei testi
 * 3. Hero Automatic Text Cycler (5.5s per messaggio, dissolvenza e reveal verticale morbido)
 * 4. Hero Title Monoriga Autoscaling (riduzione automatica della dimensione del font per evitare wrapping e overflow)
 * 5. Esploratore Servizi a Due Capitoli Visivi con Transizione Centrale Immersiva:
 *    - Capitolo 1: Sicurezza e Controllo (01-06) con testi a sinistra e stage sticky a destra
 *    - Transizione Centrale a tutto schermo con espansione panoramica e messaggio identitario
 *    - Capitolo 2: Tecnologie e Infrastrutture (07-11) con composizione speculare (stage a sinistra, testi a destra)
 * 6. Il nostro metodo — Sequenza dinamica a scorrimento orizzontale guidato dallo scroll verticale (Tenconi motion principle)
 * 7. Rivelazione editoriale degli elementi allo scroll (IntersectionObserver)
 * 8. Mobile drawer menu accessibile
 * 9. Smooth scroll anchors interni
 *
 * @version 1.12.14
 */

document.addEventListener('DOMContentLoaded', () => {
	'use strict';

	const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

	/* ==========================================================================
	   1. HEADER SCROLL STATE
	   ========================================================================== */
	const header = document.getElementById('site-header');

	/* ==========================================================================
	   3. HERO VIDEO LOOP — UN SOLO PLAYER, INDIPENDENTE DALLE SLIDE
	   ========================================================================== */
	const videoA = document.getElementById('ts-hero-video-a');
	if (videoA) {
		// Il browser gestisce il loop nativo; al rientro nella scheda si riprende
		// dalla posizione corrente senza mai collegare il player al timer dei testi.
		document.addEventListener('visibilitychange', () => {
			if (!document.hidden && videoA.paused && !videoA.ended) {
				videoA.play().catch(() => {});
			}
		});
	}

	/* ==========================================================================
	   4. HERO TITLE MONORIGA AUTOSCALING (Nessun ritorno a capo, nessun overflow)
	   ========================================================================== */
	const fitHeroTitles = () => {
		const titleElements = document.querySelectorAll('[data-hero-title]');
		titleElements.forEach((title) => {
			const container = title.closest('.ts-hero__content-box') || title.parentElement;
			if (!container) return;

			// Reset font-size per misurare la larghezza naturale
			title.style.fontSize = '';
			const availableWidth = container.clientWidth;
			const textWidth = title.scrollWidth;

			if (textWidth > availableWidth && availableWidth > 0) {
				const computed = window.getComputedStyle(title);
				const currentFontSize = parseFloat(computed.fontSize);
				const scale = (availableWidth / textWidth) * 0.97;
				const fittedFontSize = Math.max(16, Math.floor(currentFontSize * scale));
				title.style.fontSize = `${fittedFontSize}px`;
			}
		});
	};

	window.addEventListener('resize', fitHeroTitles, { passive: true });
	window.addEventListener('orientationchange', fitHeroTitles);
	if (document.fonts) document.fonts.ready.then(fitHeroTitles);
	fitHeroTitles();

	/* ==========================================================================
	   5. HERO AUTOMATIC TEXT CYCLER (3 Messaggi continui, nessun indicatore)
	   ========================================================================== */
	const heroTextTrack = document.getElementById('ts-hero-text-track');
	if (heroTextTrack) {
		const slides = Array.from(heroTextTrack.querySelectorAll('.ts-hero__slide-text'));
		const totalSlides = slides.length;
		let currentSlideIndex = 0;
		let slideTimer = null;
		let heroCopyReady = prefersReducedMotion;
		const slideDuration = 5500; // 5.5 secondi di permanenza perfetta per la lettura

		const showSlide = (targetIndex) => {
			if (targetIndex < 0 || targetIndex >= totalSlides) return;
			currentSlideIndex = targetIndex;
			const securityLabel = document.querySelector('.ts-hero__badge-text');
			if (securityLabel && slides[targetIndex].dataset.securityLabel) securityLabel.textContent = slides[targetIndex].dataset.securityLabel;

			slides.forEach((slide, idx) => {
				const isActive = idx === targetIndex;
				slide.classList.toggle('is-active', isActive);
				slide.setAttribute('aria-hidden', isActive ? 'false' : 'true');
			});

			// Ricalcola il fitting del titolo per la slide attiva
			requestAnimationFrame(fitHeroTitles);
		};

		const nextSlide = () => {
			const nextIdx = (currentSlideIndex + 1) % totalSlides;
			showSlide(nextIdx);
		};

		const startSlideLoop = () => {
			if (!heroCopyReady || prefersReducedMotion || totalSlides <= 1) return;
			clearInterval(slideTimer);
			slideTimer = setInterval(nextSlide, slideDuration);
		};

		const stopSlideLoop = () => {
			clearInterval(slideTimer);
		};

		// Pausa quando l'utente passa il cursore o interagisce con il testo
		const heroSection = document.getElementById('ts-hero');
		if (heroSection) {
			heroCopyReady = heroCopyReady || heroSection.classList.contains('is-searchlight-ready');
			heroSection.addEventListener('ts:searchlight-ready', () => {
				heroCopyReady = true;
				startSlideLoop();
			}, { once: true });
			heroSection.addEventListener('mouseenter', stopSlideLoop);
			heroSection.addEventListener('mouseleave', startSlideLoop);
			heroSection.addEventListener('focusin', stopSlideLoop);
			heroSection.addEventListener('focusout', startSlideLoop);
		}

		// Gestione cambio scheda
		document.addEventListener('visibilitychange', () => {
			if (document.hidden) {
				stopSlideLoop();
			} else {
				startSlideLoop();
			}
		});

		startSlideLoop();
	}

	/* Services v1.1: the CMS ID binds text, photo and active state. */
	const servicesSection = document.getElementById('servizi');
	if (servicesSection) {
		let servicesFrame = 0;
		const managers = [];
		const serviceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
		const serviceTop = () => (header?.getBoundingClientRect().height || 0) + (document.getElementById('wpadminbar')?.getBoundingClientRect().height || 0) + 24;
		const measureServiceTop = () => servicesSection.style.setProperty('--services-top', `${serviceTop()}px`);
		for (const chapter of servicesSection.querySelectorAll('.ts-services-chapter')) {
			const items = Array.from(chapter.querySelectorAll('.ts-service-flow-item'));
			const panels = new Map(Array.from(chapter.querySelectorAll('.ts-sticky-panel')).map(panel => [panel.dataset.serviceKey, panel]));
			if (!items.length) continue;
			let activeKey = '';
			const setActive = (item) => {
				if (!item || item.dataset.serviceKey === activeKey) return;
				activeKey = item.dataset.serviceKey;
				items.forEach(candidate => candidate.classList.toggle('is-active', candidate.dataset.serviceKey === activeKey));
				panels.forEach((panel, key) => panel.classList.toggle('is-active', key === activeKey));
				window.dispatchEvent(new CustomEvent('ts-service-active', { detail: { key: activeKey } }));
			};
			const update = () => {
				const focal = window.innerHeight * .45;
				let closest = items[0], distance = Infinity;
				items.forEach(item => {
					const rect = item.getBoundingClientRect();
					const next = Math.abs(rect.top + rect.height * .4 - focal);
					if (next < distance) { distance = next; closest = item; }
				});
				setActive(closest);
			};
			items.forEach(item => {
				item.addEventListener('focusin', () => setActive(item));
				item.addEventListener('mouseenter', () => { if (window.innerWidth > 1024) setActive(item); });
			});
			managers.push({ update, setActive, items });
			setActive(items[0]);
		}
		const updateServices = () => {
			servicesFrame = 0;
			managers.forEach(manager => manager.update());
		};
		const scheduleServices = () => {
			if (!servicesFrame) servicesFrame = requestAnimationFrame(updateServices);
		};
		window.addEventListener('scroll', scheduleServices, { passive: true });
		window.addEventListener('resize', () => { measureServiceTop(); scheduleServices(); }, { passive: true });
		window.addEventListener('pageshow', scheduleServices);
		measureServiceTop();
		if ('ResizeObserver' in window && header) new ResizeObserver(measureServiceTop).observe(header);
		scheduleServices();

		const bridge = document.getElementById('ts-services-trans');
		if (bridge && window.gsap && window.ScrollTrigger && managers.length === 2) {
			const gsap = window.gsap;
			const ScrollTrigger = window.ScrollTrigger;
			gsap.registerPlugin(ScrollTrigger);
			const media = gsap.matchMedia();
			media.add('(min-width: 1025px) and (prefers-reduced-motion: no-preference)', () => {
				const source = document.getElementById('ts-services-stage-ch1');
				const target = document.getElementById('ts-services-stage-ch2');
				const lastItem = managers[0].items.at(-1);
				const firstItem = managers[1].items[0];
				const visual = bridge.querySelector('.ts-trans-visual');
				const sourceFrame = source.querySelector('.ts-services-sticky-frame');
				const targetFrame = target.querySelector('.ts-services-sticky-frame');
				const content = bridge.querySelector('.ts-trans-content');
				const backdrop = bridge.querySelector('.ts-trans-backdrop');
				const shade = bridge.querySelector('.ts-trans-shade');
				const sourceLayer = bridge.querySelector('.ts-trans-source');
				const arrivalLayer = bridge.querySelector('.ts-trans-arrival');
				let geometry;
				const measure = () => {
					measureServiceTop();
					const inset = serviceTop();
					bridge.style.setProperty('--bridge-space', '0px');
					const preferredStart = window.scrollY + lastItem.getBoundingClientRect().top + lastItem.offsetHeight * .4 - window.innerHeight * .45;
					const sourceLayout = source.parentElement.getBoundingClientRect();
					const targetLayout = target.parentElement.getBoundingClientRect();
					// Include the chapter tails in the 78vh journey instead of adding another hero.
					const duration = window.innerHeight * .78;
					const naturalEnd = window.scrollY + targetLayout.top - inset;
					const start = Math.max(preferredStart, naturalEnd - duration);
					const end = start + duration;
					bridge.style.setProperty('--bridge-space', `${Math.max(0, end - naturalEnd)}px`);
					const width = bridge.querySelector('.ts-container').clientWidth * .78;
					const height = window.innerHeight - inset - 36;
					const centerY = inset + 8;
					geometry = {
						start, end: Math.max(start + 1, end),
						sx: source.getBoundingClientRect().left,
						sy: Math.min(Math.max(sourceLayout.top + window.scrollY - start, inset), sourceLayout.bottom + window.scrollY - start - source.offsetHeight),
						sw: source.offsetWidth, sh: source.offsetHeight,
						cx: (window.innerWidth - width) / 2, cy: centerY, cw: width, ch: height,
						tx: target.getBoundingClientRect().left, ty: inset, tw: target.offsetWidth, th: target.offsetHeight
					};
					bridge.style.setProperty('--bridge-copy-left', `${(window.innerWidth - width) / 2 + 48}px`);
					bridge.style.setProperty('--bridge-copy-width', `${width - 96}px`);
					content.style.top = `${centerY + Math.max(20, (height - content.offsetHeight) / 2)}px`;
				};
				servicesSection.classList.add('is-bridge-ready');
				measure();
				const sync = (timeline) => {
					const p = timeline.progress();
					const active = p > .001 && p < .999;
					if (active) {
						servicesSection.dataset.bridgeService = (p < .72 ? lastItem : firstItem).dataset.serviceKey;
						servicesSection.dataset.bridgeDark = 'false';
					} else {
						delete servicesSection.dataset.bridgeService;
						delete servicesSection.dataset.bridgeDark;
					}
					window.dispatchEvent(new Event('ts-service-active'));
				};
				const timeline = gsap.timeline({
					onUpdate() { sync(this); },
					scrollTrigger: {
						id: 'ts-services-bridge', trigger: bridge,
						start: () => geometry.start, end: () => geometry.end,
						scrub: true, invalidateOnRefresh: true,
						onRefreshInit: measure,
						onRefresh: scheduleServices,
						onToggle: self => { if (self.animation) sync(self.animation); }
					}
				});
				timeline.fromTo(visual, {
					x: () => geometry.sx, y: () => geometry.sy, width: () => geometry.sw, height: () => geometry.sh
				}, {
					x: () => geometry.cx, y: () => geometry.cy, width: () => geometry.cw, height: () => geometry.ch, duration: .45, ease: 'none'
				}, 0).to(visual, {
					x: () => geometry.tx, y: () => geometry.ty, width: () => geometry.tw, height: () => geometry.th, duration: .45, ease: 'none'
				}, .55)
					// The duplicate and the real stages overlap during handoff. This keeps
					// the image continuous at both chapter boundaries, even on fast scroll.
					.fromTo(visual, { autoAlpha: 0 }, { autoAlpha: 1, duration: .08, ease: 'none' }, 0)
					.fromTo(sourceFrame, { opacity: 1 }, { opacity: 0, duration: .08, ease: 'none' }, 0)
					.fromTo(targetFrame, { opacity: 0 }, { opacity: 1, duration: .08, ease: 'none' }, .92)
					.to(visual, { autoAlpha: 0, duration: .08, ease: 'none' }, .92)
					.fromTo(backdrop, { autoAlpha: 0 }, { autoAlpha: 1, duration: .3, ease: 'none' }, .05)
					.to(backdrop, { autoAlpha: 0, duration: .25, ease: 'none' }, .75)
					.fromTo(content, { autoAlpha: 0, y: 12 }, { autoAlpha: 1, y: 0, duration: .15 }, .30)
					.to(content, { autoAlpha: 0, y: -8, duration: .15 }, .67)
					.fromTo(shade, { opacity: 0 }, { opacity: 1, duration: .18 }, .22)
					.to(shade, { opacity: 0, duration: .18 }, .72)
					.fromTo(arrivalLayer, { opacity: 0 }, { opacity: 1, duration: .28, ease: 'none' }, .30)
					.fromTo(sourceLayer, { opacity: 1 }, { opacity: 0, duration: .28, ease: 'none' }, .30);
				return () => {
					servicesSection.classList.remove('is-bridge-ready');
					gsap.set([visual, sourceFrame, targetFrame, backdrop, content, shade, sourceLayer, arrivalLayer], { clearProps: 'all' });
					content.style.top = '';
					bridge.style.removeProperty('--bridge-space');
					bridge.style.removeProperty('--bridge-copy-left');
					bridge.style.removeProperty('--bridge-copy-width');
					delete servicesSection.dataset.bridgeService; delete servicesSection.dataset.bridgeDark;
				};
			});
			serviceMotion.addEventListener('change', scheduleServices);
		}
	}

		/* Metodo owns one GSAP context. No global ticker, smooth scroller or killAll. */
	const methodSection = document.getElementById('metodo');
	if (methodSection) {
		const viewport = document.getElementById('ts-method-sticky-viewport');
		const windowEl = document.getElementById('ts-method-window');
		const track = document.getElementById('ts-method-track');
		const cards = Array.from(track.querySelectorAll('.ts-method-card'));
		const count = document.getElementById('ts-method-count');
		const name = document.getElementById('ts-method-active-name');
		const progressLine = document.getElementById('ts-method-signal-progress');
		const dot = document.getElementById('ts-method-signal-dot');
		const adminBar = document.getElementById('wpadminbar');
		let distance = 0;
		let offsets = [];
		let topInset = 0;
		let timeline = null;
		let active = -1;
		let refreshTimer;
		const gsap = window.gsap;
		const ScrollTrigger = window.ScrollTrigger;
		const motion = window.matchMedia('(prefers-reduced-motion: reduce)');

		const setActive = (index) => {
			if (index === active) return;
			active = index;
			cards.forEach((card, i) => card.classList.toggle('is-active', i === index));
			count.textContent = cards[index].querySelector('.ts-method-card__num').textContent;
			name.textContent = cards[index].querySelector('.ts-method-card__title').textContent;
		};
		const update = (travel) => {
			const last = offsets.length - 1;
			const end = offsets[last] || 0;
			const ratio = end ? Math.min(1, Math.max(0, travel / end)) : 0;
			let index = 0;
			if (travel >= end && end > 0) index = last;
			else if (travel > 0) {
				index = offsets.reduce((best, offset, i) => Math.abs(offset - travel) < Math.abs(offsets[best] - travel) ? i : best, 0);
			}
			setActive(index);
			progressLine.style.transform = `scaleX(${ratio})`;
			dot.style.left = `${ratio * 100}%`;
		};
		const measure = () => {
			const adminHeight = adminBar ? adminBar.getBoundingClientRect().height : 0;
			const headerHeight = header ? header.getBoundingClientRect().height : 0;
			// Reserve both bars even when the existing fixed header overlaps the admin bar.
			topInset = headerHeight + adminHeight;
			methodSection.style.setProperty('--method-height', `${Math.max(0, window.innerHeight - topInset)}px`);
			const gutter = parseFloat(getComputedStyle(track).paddingLeft);
			const last = cards[cards.length - 1];
			track.style.setProperty('--method-end', `${Math.max(0, windowEl.clientWidth - gutter - last.offsetWidth)}px`);
			offsets = cards.map(card => card.offsetLeft - cards[0].offsetLeft);
			distance = Math.max(0, track.scrollWidth - windowEl.clientWidth);
		};
		setActive(0);
		measure();

		windowEl.addEventListener('scroll', () => {
			if (!timeline) update(windowEl.scrollLeft);
		}, { passive: true });

		if (gsap && ScrollTrigger) {
			gsap.registerPlugin(ScrollTrigger);
			const media = gsap.matchMedia();
			media.add('(min-width: 1025px) and (prefers-reduced-motion: no-preference)', () => {
				methodSection.classList.add('is-pinned');
				windowEl.scrollLeft = 0;
				gsap.set(track, { x: 0 });
				measure();
				update(0);
				// 88% movement, 12% stationary reading time on the final phase.
				timeline = gsap.timeline({
					onUpdate: () => update(-Number(gsap.getProperty(track, 'x'))),
					scrollTrigger: {
						id: 'ts-method', trigger: viewport, pin: viewport,
						start: () => `top top+=${topInset}`,
						end: () => `+=${Math.max(distance, window.innerHeight - topInset) / .88}`,
						scrub: .45, anticipatePin: 1, invalidateOnRefresh: true,
						onRefreshInit: measure,
						onRefresh: () => update(-Number(gsap.getProperty(track, 'x'))),
					}
				});
				timeline.to(track, { x: () => -distance, duration: .88, ease: 'none' })
					.to({}, { duration: .12 });
				return () => {
					timeline = null;
					methodSection.classList.remove('is-pinned');
					windowEl.scrollLeft = 0;
					update(0);
				};
			});
			// CTA stays in normal document flow and only moves slightly vertically.
			media.add('(prefers-reduced-motion: no-preference)', () => {
				gsap.fromTo(methodSection.querySelector('.ts-method-cta__inner'), { y: 16 }, {
					y: 0, duration: .6, ease: 'power2.out',
					scrollTrigger: { trigger: '.ts-method-cta', start: 'top 95%', toggleActions: 'play none none reverse' }
				});
			});
		}
		const refresh = () => {
			clearTimeout(refreshTimer);
			refreshTimer = setTimeout(() => {
				measure();
				if (ScrollTrigger) ScrollTrigger.refresh();
				if (!timeline) update(windowEl.scrollLeft);
			}, 200);
		};
		// Image boxes have fixed geometry: lazy images cannot cause later layout shifts.
		const imagesReady = Promise.all(Array.from(track.querySelectorAll('img[loading="eager"]')).map(img => img.complete ? Promise.resolve() : new Promise(resolve => {
			img.addEventListener('load', resolve, { once: true });
			img.addEventListener('error', resolve, { once: true });
		})));
		Promise.all([imagesReady, document.fonts ? document.fonts.ready : Promise.resolve()]).then(refresh);
		window.addEventListener('resize', refresh, { passive: true });
		window.addEventListener('orientationchange', refresh, { passive: true });
		window.addEventListener('pageshow', refresh);
		motion.addEventListener('change', refresh);
		if ('ResizeObserver' in window) {
			const headerObserver = new ResizeObserver(refresh);
			if (header) headerObserver.observe(header);
			if (adminBar) headerObserver.observe(adminBar);
		}
		// Keyboard navigation reaches every phase; tabbing to a CMS link reveals its panel.
		const revealCard = (index) => {
			index = Math.max(0, Math.min(cards.length - 1, index));
			if (timeline) {
				// Browser focus scrolling must not add a second horizontal offset.
				windowEl.scrollLeft = 0;
				const st = timeline.scrollTrigger;
				window.scrollTo({ top: st.start + (distance ? offsets[index] / distance : 0) * (st.end - st.start) * .88, behavior: 'instant' });
			} else if (!motion.matches && window.innerWidth >= 768) {
				windowEl.scrollTo({ left: offsets[index], behavior: 'smooth' });
			}
		};
		windowEl.addEventListener('keydown', event => {
			if (motion.matches || window.innerWidth < 768) return;
			const actions = { ArrowRight: active + 1, ArrowLeft: active - 1, Home: 0, End: cards.length - 1 };
			if (!(event.key in actions)) return;
			event.preventDefault();
			revealCard(actions[event.key]);
		});
		track.addEventListener('focusin', event => {
			const index = cards.findIndex(card => card.contains(event.target));
			if (index >= 0) revealCard(index);
		});
	}

/* ==========================================================================
	   7. RIVELAZIONE EDITORIALE ALLO SCROLL (IntersectionObserver)
	   ========================================================================== */
	if ('IntersectionObserver' in window && !prefersReducedMotion) {
		const revealObserver = new IntersectionObserver((entries, observer) => {
			entries.forEach((entry) => {
				if (entry.isIntersecting) {
					entry.target.classList.add('is-revealed');
					observer.unobserve(entry.target);
				}
			});
		}, {
			root: null,
			threshold: 0.15,
			rootMargin: '0px 0px -40px 0px',
		});

		const revealElements = document.querySelectorAll(
			'[data-reveal-line], [data-reveal-mask], .ts-partners__slot, .ts-fullbleed-cta__inner'
		);
		revealElements.forEach((el) => revealObserver.observe(el));
	}

	/* ==========================================================================
	   8. SMOOTH SCROLL ANCHORS INTERNI
	   ========================================================================== */
	const internalLinks = document.querySelectorAll('a[href^="#"]:not([href="#"])');
	internalLinks.forEach((link) => {
		link.addEventListener('click', (e) => {
			const targetId = link.getAttribute('href').substring(1);
			const targetEl = document.getElementById(targetId);
			if (targetEl) {
				e.preventDefault();
				closeDrawer();
				const headerOffset = 70;
				const elementPosition = targetEl.getBoundingClientRect().top;
				const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

				window.scrollTo({
					top: offsetPosition,
					behavior: prefersReducedMotion ? 'auto' : 'smooth',
				});
			}
		});
	});
});
