(() => {
 'use strict';
 const hero = document.querySelector('.ts-hero');
 const heroSearchlight = hero ? hero.querySelector('[data-hero-searchlight]') : null;
 if (hero && heroSearchlight) {
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
  let sequenceStarted = false;
  let ignitionStarted = false;
  let contentRevealStarted = false;
  let ignitionCompleted = false;
  let contentRevealTimer = 0;
  let ignitionStartTimer = 0;
  let ignitionTimer = 0;

  const revealContent = () => {
   if (contentRevealStarted) return;
   contentRevealStarted = true;
   clearTimeout(contentRevealTimer);
   hero.classList.remove('is-searchlight-pending');
   hero.classList.add('is-searchlight-revealing');
   contentRevealTimer = window.setTimeout(() => {
    hero.classList.remove('is-searchlight-revealing');
    hero.classList.add('is-searchlight-copy-ready');
    ignitionStartTimer = window.setTimeout(ignite, 120);
   }, 500);
  };

  const completeIgnition = () => {
   if (ignitionCompleted) return;
   ignitionCompleted = true;
   clearTimeout(ignitionTimer);
   hero.classList.add('is-searchlight-ready');
   hero.dispatchEvent(new CustomEvent('ts:searchlight-ready'));
  };

  const ignite = () => {
   if (ignitionStarted) return;
   ignitionStarted = true;
   hero.classList.add('is-searchlight-ignited');
   ignitionTimer = window.setTimeout(completeIgnition, 1000);
  };

  const startSequence = () => {
   if (sequenceStarted) return;
   sequenceStarted = true;
   contentRevealTimer = window.setTimeout(revealContent, 80);
  };

  const setVisible = (visible) => {
   if (visible) startSequence();
   hero.classList.toggle('is-geometry-visible', visible);
  };

  if (reducedMotion.matches) {
   hero.classList.add('is-searchlight-ignited', 'is-searchlight-copy-ready', 'is-geometry-visible');
   sequenceStarted = true;
   ignitionStarted = true;
   contentRevealStarted = true;
   completeIgnition();
  } else {
   if ('IntersectionObserver' in window) {
    const visibility = new IntersectionObserver((entries) => {
     entries.forEach((entry) => setVisible(entry.isIntersecting && !document.hidden));
    }, { threshold: 0.12 });
    visibility.observe(hero);
   } else {
    setVisible(true);
   }

   document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
     setVisible(false);
     return;
    }
    const bounds = hero.getBoundingClientRect();
    setVisible(bounds.bottom > 0 && bounds.top < window.innerHeight);
   });
  }
 }
 const cards = [...document.querySelectorAll('.ts-method-card')];
 if (cards.length) {
  const update = () => {
   const active = cards.findIndex(card => card.classList.contains('is-active'));
   cards.forEach((card, index) => card.classList.toggle('is-complete', active >= 0 && index < active));
  };
  // Observe the existing phase state, without creating another scroll controller.
  const observer = new MutationObserver(records => {
   if (records.some(record => (record.oldValue || '').includes('is-active') !== record.target.classList.contains('is-active'))) update();
  });
  cards.forEach(card => observer.observe(card, { attributes: true, attributeFilter: ['class'], attributeOldValue: true }));
  update();
 }
 document.querySelectorAll('.ts-page input[type="checkbox"]').forEach(input => {
  const label = input.closest('label');
  if (label && /privacy/i.test(label.textContent)) label.classList.add('ts-privacy');
 });

 const proofBar = document.querySelector('[data-proof-bar]');
 if (proofBar) {
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
  if (!reducedMotion.matches && 'IntersectionObserver' in window) {
   proofBar.classList.add('is-motion-ready');
   const reveal = new IntersectionObserver(entries => {
    if (!entries.some(entry => entry.isIntersecting)) return;
    proofBar.classList.add('is-revealed');
    reveal.disconnect();
   }, { threshold: 0.28 });
   reveal.observe(proofBar);
  } else {
   proofBar.classList.add('is-revealed');
  }
 }

 const aboutCredentials = document.querySelector('[data-about-credentials]');
 if (aboutCredentials) {
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
  if (!reducedMotion.matches && 'IntersectionObserver' in window) {
   aboutCredentials.classList.add('is-motion-ready');
   const revealCredentials = new IntersectionObserver(entries => {
    if (!entries.some(entry => entry.isIntersecting)) return;
    aboutCredentials.classList.add('is-revealed');
    revealCredentials.disconnect();
   }, { threshold: 0.25 });
   revealCredentials.observe(aboutCredentials);
  } else {
   aboutCredentials.classList.add('is-revealed');
  }
 }

 const footer = document.querySelector('[data-footer-reveal]');
 if (footer) {
  const logo = footer.querySelector('.ts-footer__logo');
  if (logo) {
   const syncLogo = () => {
    if (logo.naturalWidth && logo.naturalHeight) {
     logo.closest('.ts-footer__brand').classList.toggle('has-horizontal-logo', logo.naturalWidth / logo.naturalHeight >= 1.8);
    }
   };
   if (logo.complete) syncLogo();
   else logo.addEventListener('load', syncLogo, { once: true });
  }
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
  if (!reducedMotion.matches && 'IntersectionObserver' in window) {
   footer.classList.add('is-motion-ready');
   const revealFooter = new IntersectionObserver(entries => {
    if (!entries.some(entry => entry.isIntersecting)) return;
    footer.classList.add('is-revealed');
    revealFooter.disconnect();
   }, { threshold: 0, rootMargin: '0px 0px -24px 0px' });
   revealFooter.observe(footer);
   reducedMotion.addEventListener('change', event => {
    if (event.matches) {
     footer.classList.add('is-revealed');
     revealFooter.disconnect();
    }
   });
  } else {
   footer.classList.add('is-revealed');
  }
 }

 const servicesArchive = document.querySelector('[data-services-archive]');
 const serviceViewer = servicesArchive?.querySelector('[data-services-viewer]');
 if (servicesArchive && serviceViewer) {
  const panels = [...serviceViewer.querySelectorAll('.ts-service-viewer__panel')];
  const indexLinks = [...servicesArchive.querySelectorAll('.ts-services-index a[href^="#"]')];
  const status = serviceViewer.querySelector('[data-service-status]');
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
  let activePanel = panels.find(panel => !panel.hidden) || panels[0] || null;
  let locationFrame = 0;
  let transitionToken = 0;

  const decodeHash = (hash = location.hash) => {
   try { return decodeURIComponent(hash.replace(/^#/, '')); }
   catch (error) { return hash.replace(/^#/, ''); }
  };
  const panelFromHash = (hash = location.hash) => {
   const id = decodeHash(hash);
   return id ? panels.find(panel => panel.id === id) || null : null;
  };
  const headerOffset = () => {
   const header = document.getElementById('site-header');
   const adminBar = document.getElementById('wpadminbar');
   return (header?.getBoundingClientRect().height || 0) + (adminBar?.getBoundingClientRect().height || 0) + 16;
  };
  const scrollToViewer = (highlight = false) => {
   const top = Math.max(0, window.scrollY + serviceViewer.getBoundingClientRect().top - headerOffset());
   window.scrollTo({ top, behavior: reducedMotion.matches ? 'auto' : 'smooth' });
   if (!highlight) return;
   serviceViewer.classList.remove('is-targeted');
   void serviceViewer.offsetWidth;
   serviceViewer.classList.add('is-targeted');
   window.setTimeout(() => serviceViewer.classList.remove('is-targeted'), 1100);
  };
  const setHash = (panel, method = 'pushState') => {
   const url = `${location.pathname}${location.search}#${encodeURIComponent(panel.id)}`;
   history[method]({ service: panel.id }, '', url);
  };
  const setPanelAccessibility = (panel, active) => {
   panel.classList.toggle('is-active', active);
   panel.setAttribute('aria-hidden', String(!active));
   if (active) panel.removeAttribute('hidden');
   else panel.hidden = true;
  };
  const syncIndex = panel => {
   indexLinks.forEach(link => {
    const controls = decodeHash(link.hash);
    const current = controls === panel.id;
    link.setAttribute('aria-controls', controls);
    link.classList.toggle('is-active', current);
    if (current) link.setAttribute('aria-current', 'true');
    else link.removeAttribute('aria-current');
   });
  };
  const preloadNeighbours = panel => {
   const index = panels.indexOf(panel);
   [panels[index - 1], panel, panels[index + 1]].forEach(candidate => {
    const image = candidate?.querySelector('img');
    if (image) image.loading = 'eager';
   });
  };
  const announce = panel => {
   const index = panels.indexOf(panel);
   if (status) status.textContent = `Servizio ${index + 1} di ${panels.length}: ${panel.querySelector('.ts-service-viewer__title')?.textContent.trim() || ''}`;
   window.dispatchEvent(new CustomEvent('ts-service-active', {
    detail: { key: panel.dataset.serviceKey, index, total: panels.length }
   }));
  };
  const finishTransition = (panel, token) => {
   if (token !== transitionToken) return;
   panels.forEach(candidate => setPanelAccessibility(candidate, candidate === panel));
   serviceViewer.classList.remove('is-transitioning');
  };
  const activate = (panel, options = {}) => {
   if (!panel) return;
   const { animate = true, updateHash = false, historyMethod = 'pushState', scroll = false, highlight = false } = options;
   const previous = activePanel;
   const token = ++transitionToken;
   panels.forEach(candidate => candidate.getAnimations?.({ subtree: true }).forEach(animation => animation.cancel()));
   panels.forEach(candidate => {
    if (candidate !== previous && candidate !== panel) setPanelAccessibility(candidate, false);
   });
   setPanelAccessibility(panel, true);
   activePanel = panel;
   syncIndex(panel);
   preloadNeighbours(panel);
   announce(panel);
   if (updateHash && decodeHash() !== panel.id) setHash(panel, historyMethod);

   if (previous && previous !== panel && animate && !reducedMotion.matches && panel.animate) {
    serviceViewer.classList.add('is-transitioning');
    setPanelAccessibility(previous, true);
    previous.classList.remove('is-active');
    const previousMedia = previous.querySelector('.ts-service-viewer__media');
    const previousInfo = previous.querySelector('.ts-service-viewer__info');
    const nextMedia = panel.querySelector('.ts-service-viewer__media');
    const nextInfo = panel.querySelector('.ts-service-viewer__info');
    const animations = [
     previousMedia?.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 150, easing: 'ease-in', fill: 'both' }),
     previousInfo?.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 130, easing: 'ease-in', fill: 'both' }),
     nextMedia?.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 250, delay: 90, easing: 'cubic-bezier(.2,.7,.2,1)', fill: 'both' }),
     nextInfo?.animate(
      [{ opacity: 0, transform: 'translateY(9px)' }, { opacity: 1, transform: 'translateY(0)' }],
      { duration: 280, delay: 110, easing: 'cubic-bezier(.2,.7,.2,1)', fill: 'both' }
     )
    ].filter(Boolean);
    Promise.allSettled(animations.map(animation => animation.finished)).then(() => {
     animations.forEach(animation => animation.cancel());
     finishTransition(panel, token);
    });
   } else {
    finishTransition(panel, token);
   }
   if (scroll) requestAnimationFrame(() => scrollToViewer(highlight));
  };

  indexLinks.forEach(link => {
   const panel = panelFromHash(link.hash);
   if (!panel) return;
   link.addEventListener('click', event => {
    event.preventDefault();
    activate(panel, { updateHash: true, scroll: true, highlight: true });
   });
  });
  window.addEventListener('ts-service-navigate', event => {
   const index = panels.indexOf(activePanel);
   const delta = Number(event.detail?.delta) || 0;
   const target = panels[Math.max(0, Math.min(panels.length - 1, index + delta))];
   if (target && target !== activePanel) activate(target, { updateHash: true, scroll: true });
  });
  const syncLocation = (initial = false) => {
   const target = panelFromHash();
   const panel = target || panels[0];
   if (!panel) return;
   activate(panel, { animate: false });
   if (target) requestAnimationFrame(() => requestAnimationFrame(() => scrollToViewer(initial)));
  };
  const scheduleLocationSync = () => {
   cancelAnimationFrame(locationFrame);
   locationFrame = requestAnimationFrame(() => syncLocation(false));
  };
  window.addEventListener('popstate', scheduleLocationSync);
  window.addEventListener('hashchange', scheduleLocationSync);
  syncLocation(true);
 }
})();
