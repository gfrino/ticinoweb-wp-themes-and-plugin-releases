(function ($) {
	'use strict';

	function reindex($repeater) {
		var group = $repeater.data('ts-repeater');
		$repeater.find('[data-ts-row]').each(function (index) {
			$(this).find('[name]').each(function () {
				this.name = this.name.replace(new RegExp('\\[' + group + '\\]\\[[^\\]]+\\]'), '[' + group + '][' + index + ']');
			});
		});
	}

	function updateSectionCount($editor, section, count) {
		var $meta = $editor.find('[data-ts-section-tab="' + section + '"] [data-ts-tab-meta]');
		var emptyLabel = $meta.data('ts-empty-label');
		var label = 0 === count && emptyLabel ? emptyLabel : count + (1 === count ? ' voce' : ' voci');
		$meta.text(label);
	}

	function initSectionTabs() {
		$('[data-ts-service-editor]').each(function () {
			var $editor = $(this);
			var $tablist = $editor.find('[data-ts-section-tabs]');
			var $tabs = $tablist.find('[data-ts-section-tab]');
			var $panels = $editor.find('[data-ts-section-panel]');
			var storageKey = 'ts-service-editor-tab-' + ($editor.data('post-id') || 'new');
			var storedSection = '';

			if (!$tabs.length || !$panels.length) {
				return;
			}

			try {
				storedSection = window.sessionStorage.getItem(storageKey) || '';
			} catch (error) {
				storedSection = '';
			}

			$tablist.find('.ts-service-admin__tablist').attr('role', 'tablist');
			$tabs.attr('role', 'tab');
			$panels.each(function () {
				var section = $(this).data('ts-section-panel');
				$(this).attr({
					role: 'tabpanel',
					tabindex: '0',
					'aria-labelledby': 'ts-service-admin-tab-' + section
				});
			});

			function activate(section, moveFocus) {
				var $nextTab = $tabs.filter('[data-ts-section-tab="' + section + '"]');
				var $nextPanel = $panels.filter('[data-ts-section-panel="' + section + '"]');

				if (!$nextTab.length || !$nextPanel.length) {
					$nextTab = $tabs.first();
					section = $nextTab.data('ts-section-tab');
					$nextPanel = $panels.filter('[data-ts-section-panel="' + section + '"]');
				}

				$tabs.removeClass('is-active').attr({ 'aria-selected': 'false', tabindex: '-1' });
				$nextTab.addClass('is-active').attr({ 'aria-selected': 'true', tabindex: '0' });
				$panels.attr('hidden', 'hidden');
				$nextPanel.removeAttr('hidden');

				try {
					window.sessionStorage.setItem(storageKey, section);
				} catch (error) {
					// Storage can be disabled without affecting the editor.
				}

				if (moveFocus) {
					$nextTab.trigger('focus');
				}
			}

			$tabs.on('click', function () {
				activate($(this).data('ts-section-tab'), false);
			});

			$tabs.on('keydown', function (event) {
				var currentIndex = $tabs.index(this);
				var nextIndex = currentIndex;

				if ('ArrowRight' === event.key || 'ArrowDown' === event.key) {
					nextIndex = (currentIndex + 1) % $tabs.length;
				} else if ('ArrowLeft' === event.key || 'ArrowUp' === event.key) {
					nextIndex = (currentIndex - 1 + $tabs.length) % $tabs.length;
				} else if ('Home' === event.key) {
					nextIndex = 0;
				} else if ('End' === event.key) {
					nextIndex = $tabs.length - 1;
				} else {
					return;
				}

				event.preventDefault();
				activate($tabs.eq(nextIndex).data('ts-section-tab'), true);
			});

			$editor.addClass('is-tabs-ready');
			activate(storedSection || $tabs.first().data('ts-section-tab'), false);
		});
	}

	initSectionTabs();

	$('[data-ts-repeater]').each(function () {
		var $repeater = $(this);
		var $editor = $repeater.closest('[data-ts-service-editor]');
		var $section = $repeater.closest('.ts-service-admin__section');
		var $rows = $repeater.find('[data-ts-rows]');
		var group = $repeater.data('ts-repeater');

		$rows.sortable({
			handle: '[data-ts-drag]',
			axis: 'y',
			items: '> [data-ts-row]',
			placeholder: 'ts-service-admin__placeholder',
			update: function () { reindex($repeater); }
		});

		$section.on('click', '[data-ts-add]', function () {
			var template = $repeater.find('[data-ts-template]').html();
			var index = $rows.children('[data-ts-row]').length;
			$rows.append(template.replace(/__INDEX__/g, index));
			reindex($repeater);
			updateSectionCount($editor, group, $rows.children('[data-ts-row]').length);
		});

		$repeater.on('click', '[data-ts-remove]', function () {
			$(this).closest('[data-ts-row]').remove();
			reindex($repeater);
			updateSectionCount($editor, group, $rows.children('[data-ts-row]').length);
		});
	});

	$('[data-ts-section-panel="related"] input[type="checkbox"]').on('change', function () {
		var $panel = $(this).closest('[data-ts-section-panel]');
		var $editor = $panel.closest('[data-ts-service-editor]');
		var count = $panel.find('input[type="checkbox"]:checked').length;
		updateSectionCount($editor, 'related', count);
	});
})(jQuery);
