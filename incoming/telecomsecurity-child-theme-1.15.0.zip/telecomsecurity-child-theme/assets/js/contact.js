(function (root, factory) {
	'use strict';
	var api = factory(root);
	if (typeof module === 'object' && module.exports) {
		module.exports = api;
	} else {
		root.TelecomSecurityContact = api;
	}
})(typeof window !== 'undefined' ? window : globalThis, function (root) {
	'use strict';

	var MODES = {
		new_system: {
			groups: ['service', 'property', 'location', 'attachment'],
			phoneRequired: true
		},
		support: {
			groups: ['customer', 'service', 'location', 'attachment'],
			phoneRequired: true
		},
		maintenance: {
			groups: ['customer', 'service', 'location', 'attachment'],
			phoneRequired: true
		},
		general: {
			groups: [],
			phoneRequired: false
		}
	};

	function getRequestMode(type) {
		var mode = MODES[type] || MODES.general;
		return {
			groups: mode.groups.slice(),
			phoneRequired: mode.phoneRequired
		};
	}

	function applyRequestType(form, type) {
		var mode = getRequestMode(type);
		var activeGroups = new Set(mode.groups);
		form.querySelectorAll('[data-contact-group]').forEach(function (section) {
			var active = activeGroups.has(section.dataset.contactGroup);
			section.hidden = !active;
			section.setAttribute('aria-hidden', active ? 'false' : 'true');
			section.querySelectorAll('input, select, textarea, button').forEach(function (control) {
				control.disabled = !active;
			});
		});
		var phone = form.querySelector('[name="ts_contact_phone"]');
		if (phone) {
			phone.required = mode.phoneRequired;
			phone.setAttribute('aria-required', mode.phoneRequired ? 'true' : 'false');
		}
		return mode;
	}

	function setFieldError(form, field, message) {
		var control = field === 'request_type'
			? form.querySelector('[name="ts_contact_request_type"]')
			: form.querySelector('[name="ts_contact_' + field + '"]');
		var error = form.querySelector('[data-contact-error="' + field + '"]');
		if (control) {
			control.setAttribute('aria-invalid', 'true');
		}
		if (error) {
			error.textContent = message;
			error.hidden = false;
		}
	}

	function clearErrors(form) {
		form.querySelectorAll('[aria-invalid="true"]').forEach(function (field) {
			field.removeAttribute('aria-invalid');
		});
		form.querySelectorAll('[data-contact-error]').forEach(function (error) {
			error.textContent = '';
			error.hidden = true;
		});
		var summary = form.querySelector('[data-contact-error-summary]');
		if (summary) {
			summary.hidden = true;
			summary.querySelector('[data-contact-error-summary-text]').textContent = '';
		}
	}

	function showErrorSummary(form, message, fields) {
		var summary = form.querySelector('[data-contact-error-summary]');
		if (!summary) {
			return;
		}
		summary.querySelector('[data-contact-error-summary-text]').textContent = message;
		summary.hidden = false;
		Object.entries(fields || {}).forEach(function (entry) {
			setFieldError(form, entry[0], entry[1]);
		});
		summary.focus();
		var firstInvalid = form.querySelector('[aria-invalid="true"]');
		if (firstInvalid) {
			firstInvalid.focus({ preventScroll: true });
			var reducedMotion = root.matchMedia && root.matchMedia('(prefers-reduced-motion: reduce)').matches;
			firstInvalid.scrollIntoView({ behavior: reducedMotion ? 'auto' : 'smooth', block: 'center' });
		}
	}

	function setBusy(form, busy) {
		var button = form.querySelector('[data-contact-submit]');
		if (!button) {
			return;
		}
		button.disabled = busy;
		button.setAttribute('aria-busy', busy ? 'true' : 'false');
		var label = button.querySelector('[data-contact-submit-label]');
		if (label) {
			label.textContent = busy
				? (button.dataset.loadingLabel || 'Invio in corso…')
				: (button.dataset.defaultLabel || 'Invia la richiesta');
		}
	}

	function updateSecurityFields(form, payload) {
		var map = {
			nonce: 'ts_contact_nonce',
			ts_contact_started: 'ts_contact_started',
			ts_contact_started_signature: 'ts_contact_started_signature'
		};
		Object.entries(map).forEach(function (entry) {
			var input = form.querySelector('[name="' + entry[1] + '"]');
			if (input && payload[entry[0]]) {
				input.value = payload[entry[0]];
			}
		});
	}

	async function refreshSecurity(form, config) {
		var body = new URLSearchParams({ action: config.tokenAction });
		var response = await root.fetch(config.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body.toString()
		});
		var json = await response.json();
		if (!response.ok || !json.success || !json.data) {
			throw new Error('token');
		}
		updateSecurityFields(form, json.data);
		return json.data;
	}

	function showSuccess(form, result) {
		var shell = form.closest('[data-contact-form-shell]');
		var success = shell ? shell.querySelector('[data-contact-success]') : null;
		if (!success) {
			return;
		}
		var requestType = success.querySelector('[data-contact-success-type]');
		var service = success.querySelector('[data-contact-success-service]');
		var email = success.querySelector('[data-contact-success-email]');
		if (requestType) requestType.textContent = result.request_type_label || '';
		if (email) email.textContent = result.email || '';
		if (service) {
			service.closest('[data-contact-success-service-row]').hidden = !result.service_label;
			service.textContent = result.service_label || '';
		}
		form.hidden = true;
		success.hidden = false;
		success.focus();
	}

	function resetForm(form, config) {
		var shell = form.closest('[data-contact-form-shell]');
		var success = shell ? shell.querySelector('[data-contact-success]') : null;
		form.reset();
		clearErrors(form);
		applyRequestType(form, 'general');
		if (success) success.hidden = true;
		form.hidden = false;
		refreshSecurity(form, config).catch(function () {});
		var legend = form.querySelector('legend');
		if (legend) legend.focus();
	}

	function initialize(form, config) {
		var selected = form.querySelector('[name="ts_contact_request_type"]:checked');
		applyRequestType(form, selected ? selected.value : 'general');
		form.querySelectorAll('[name="ts_contact_request_type"]').forEach(function (radio) {
			radio.addEventListener('change', function () {
				applyRequestType(form, radio.value);
			});
		});

		var tokenReady = refreshSecurity(form, config).catch(function () {
			return null;
		});

		var reset = form.closest('[data-contact-form-shell]')?.querySelector('[data-contact-new-request]');
		if (reset) {
			reset.addEventListener('click', function () { resetForm(form, config); });
		}

		if (!root.fetch || !root.FormData) {
			return;
		}
		form.addEventListener('submit', async function (event) {
			event.preventDefault();
			clearErrors(form);
			var selectedType = form.querySelector('[name="ts_contact_request_type"]:checked');
			applyRequestType(form, selectedType ? selectedType.value : 'general');
			setBusy(form, true);
			await tokenReady;
			try {
				var data = new root.FormData(form);
				data.set('action', config.submitAction);
				var response = await root.fetch(config.ajaxUrl, {
					method: 'POST',
					credentials: 'same-origin',
					body: data
				});
				var json = await response.json();
				if (!response.ok || !json.success) {
					var payload = json.data || {};
					showErrorSummary(form, payload.message || config.genericError, payload.fields || {});
					return;
				}
				showSuccess(form, json.data || {});
			} catch (error) {
				showErrorSummary(form, config.networkError || config.genericError, {});
			} finally {
				setBusy(form, false);
			}
		});
	}

	function boot() {
		var config = root.telecomsecurityContactConfig;
		if (!config || !root.document) {
			return;
		}
		root.document.querySelectorAll('[data-ts-contact-form]').forEach(function (form) {
			initialize(form, config);
		});
	}

	if (root.document) {
		if (root.document.readyState === 'loading') {
			root.document.addEventListener('DOMContentLoaded', boot, { once: true });
		} else {
			boot();
		}
	}

	return {
		getRequestMode: getRequestMode,
		applyRequestType: applyRequestType,
		initialize: initialize
	};
});
