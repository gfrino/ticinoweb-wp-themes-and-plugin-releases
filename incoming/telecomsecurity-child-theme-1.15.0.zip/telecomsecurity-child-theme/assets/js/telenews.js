(() => {
	const root = document.querySelector('[data-telenews-root]');
	if (!root || !('IntersectionObserver' in window) || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

	root.classList.add('is-motion-ready');
	const observer = new IntersectionObserver((entries) => {
		entries.forEach((entry) => {
			if (!entry.isIntersecting) return;
			entry.target.classList.add('is-visible');
			observer.unobserve(entry.target);
		});
	}, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });

	root.querySelectorAll('[data-telenews-reveal]').forEach((card) => observer.observe(card));
})();
