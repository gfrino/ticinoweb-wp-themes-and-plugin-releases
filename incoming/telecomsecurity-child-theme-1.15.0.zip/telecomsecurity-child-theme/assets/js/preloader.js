/**
 * Telecom Security — System-ready preloader.
 *
 * The browser controller is dependency-free. Pure policy helpers are exported
 * through CommonJS as well, so readiness and session behaviour can be tested.
 */
(function (root, factory) {
	'use strict';

	const api = factory();
	if (typeof module === 'object' && module.exports) {
		module.exports = api;
	}
	if (root) {
		root.TelecomSecurityPreloader = api;
		if (root.document) {
			api.bootstrapEarly(root);
		}
	}
})(typeof window !== 'undefined' ? window : null, function () {
	'use strict';

	const DEFAULT_MINIMUM_MS = 1600;
	const ADVANCE_THRESHOLD = 0.08;
	const BUFFER_THRESHOLD = 0.2;

	const resolveMode = ({ isHome, forced, seen, reloaded }) => {
		if (!isHome) return 'none';
		if (forced || reloaded || !seen) return 'full';
		return 'technical';
	};

	const minimumDuration = (reducedMotion) => reducedMotion ? 0 : DEFAULT_MINIMUM_MS;

	const bufferedAhead = (video) => {
		if (!video || !video.buffered || !video.buffered.length) return 0;
		for (let index = 0; index < video.buffered.length; index += 1) {
			try {
				if (video.buffered.start(index) <= video.currentTime + 0.05 && video.buffered.end(index) >= video.currentTime) {
					return video.buffered.end(index) - video.currentTime;
				}
			} catch (error) {
				return 0;
			}
		}
		return 0;
	};

	const isVideoAdvancing = (video, baseline) => {
		if (!video || video.paused || video.ended || video.readyState < 3) return false;
		if ((Number(video.currentTime) || 0) - (Number(baseline) || 0) < ADVANCE_THRESHOLD) return false;
		return bufferedAhead(video) >= BUFFER_THRESHOLD || video.readyState >= 4;
	};

	const delay = (milliseconds) => new Promise((resolve) => {
		setTimeout(resolve, Math.max(0, milliseconds));
	});

	const waitForImage = (image, signal) => {
		if (!image) return Promise.resolve();
		if (image.complete) {
			if (typeof image.decode === 'function') return image.decode().catch(() => {});
			return Promise.resolve();
		}
		return new Promise((resolve) => {
			const finish = () => {
				image.removeEventListener('load', finish);
				image.removeEventListener('error', finish);
				signal?.removeEventListener('abort', finish);
				resolve();
			};
			image.addEventListener('load', finish, { once: true });
			image.addEventListener('error', finish, { once: true });
			signal?.addEventListener('abort', finish, { once: true });
		});
	};

	const waitForVideo = (video, signal) => new Promise((resolve, reject) => {
		if (!video) {
			resolve({ ok: true, reason: 'no-video' });
			return;
		}

		const baseline = Number(video.currentTime) || 0;
		let interval = 0;
		let settled = false;
		const clean = () => {
			if (interval) clearInterval(interval);
			video.removeEventListener('error', onError);
			signal?.removeEventListener('abort', onAbort);
		};
		const finish = (result) => {
			if (settled) return;
			settled = true;
			clean();
			resolve(result);
		};
		const onError = () => finish({ ok: false, reason: 'error' });
		const onAbort = () => {
			clean();
			reject(new DOMException('Aborted', 'AbortError'));
		};
		const inspect = () => {
			if (isVideoAdvancing(video, baseline)) finish({ ok: true, reason: 'playing' });
		};

		video.addEventListener('error', onError, { once: true });
		signal?.addEventListener('abort', onAbort, { once: true });
		interval = setInterval(inspect, 60);
		inspect();

		try {
			video.muted = true;
			const playRequest = video.play();
			if (playRequest && typeof playRequest.catch === 'function') {
				playRequest.catch(() => finish({ ok: false, reason: 'blocked' }));
			}
		} catch (error) {
			finish({ ok: false, reason: 'blocked' });
		}
	});

	const configureVideoFallback = (windowObject, hero, video, button) => {
		if (!hero || !button || !video) return;
		button.hidden = false;
		const handlePlay = () => {
			video.muted = true;
			const request = video.play();
			if (!request || typeof request.then !== 'function') return;
			request.then(() => {
				hero.classList.remove('is-video-blocked', 'is-video-error', 'is-video-pending');
				hero.classList.add('is-video-playing');
				button.hidden = true;
				button.removeEventListener('click', handlePlay);
				windowObject.document.dispatchEvent(new CustomEvent('ts:hero-primary-ready'));
			}).catch(() => {});
		};
		button.addEventListener('click', handlePlay);
	};

	const dismiss = async (windowObject, mode, reducedMotion) => {
		const documentObject = windowObject.document;
		const overlay = documentObject.getElementById('ts-preloader');
		const status = overlay?.querySelector('[data-preloader-status]');
		const config = windowObject.telecomsecurityPreloaderConfig || {};

		if (mode === 'full' && status) {
			status.textContent = config.readyText || 'Sistema pronto';
			overlay.classList.add('is-ready');
			await delay(reducedMotion ? 0 : 240);
		}

		overlay?.classList.add('is-opening');
		await delay(reducedMotion ? 160 : (mode === 'full' ? 960 : 260));

		overlay?.remove();
		documentObject.documentElement.classList.remove('ts-preloader-js', 'ts-preloader-active', 'ts-preloader-technical');
		documentObject.documentElement.removeAttribute('data-ts-preloader-mode');
		documentObject.documentElement.removeAttribute('aria-busy');
		documentObject.body?.classList.remove('ts-preloader-scroll-lock');
		documentObject.body?.removeAttribute('aria-busy');
		documentObject.dispatchEvent(new CustomEvent('ts:preloader-dismissed', { detail: { mode } }));
	};

	const initialize = async (windowObject, mode) => {
		if (mode === 'none') return;
		const documentObject = windowObject.document;
		const config = windowObject.telecomsecurityPreloaderConfig || {};
		const overlay = documentObject.getElementById('ts-preloader');
		const hero = documentObject.getElementById('ts-hero');
		const video = documentObject.getElementById('ts-hero-video-a');
		const playButton = documentObject.querySelector('[data-hero-video-play]');
		const reducedMotion = windowObject.matchMedia?.('(prefers-reduced-motion: reduce)').matches === true;
		const startedAt = Date.now();

		if (!overlay) {
			documentObject.documentElement.classList.remove('ts-preloader-js', 'ts-preloader-active', 'ts-preloader-technical');
			documentObject.documentElement.removeAttribute('data-ts-preloader-mode');
			return;
		}

		overlay.setAttribute('aria-hidden', 'false');
		documentObject.documentElement.setAttribute('aria-busy', 'true');
		documentObject.body?.setAttribute('aria-busy', 'true');
		documentObject.body?.classList.add('ts-preloader-scroll-lock');
		hero?.classList.add('is-video-pending');

		const criticalImages = Array.from(documentObject.querySelectorAll('[data-preload-critical]'));
		const fontsReady = documentObject.fonts?.ready || Promise.resolve();
		const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
		const videoReady = waitForVideo(video, controller?.signal).catch(() => ({ ok: false, reason: 'aborted' }));
		const assetsReady = Promise.all([
			fontsReady.catch?.(() => {}) || fontsReady,
			...criticalImages.map((image) => waitForImage(image, controller?.signal)),
			videoReady,
		]).then((results) => results[results.length - 1]);
		const maximumMs = mode === 'technical'
			? Math.max(400, Number(config.technicalMs) || 1800)
			: Math.max(1000, Number(config.maximumMs) || 6000);
		const readiness = await Promise.race([
			assetsReady,
			delay(maximumMs).then(() => ({ ok: false, reason: 'timeout' })),
		]);
		controller?.abort();

		if (readiness?.ok) {
			hero?.classList.remove('is-video-pending', 'is-video-blocked', 'is-video-error');
			hero?.classList.add('is-video-playing');
			documentObject.dispatchEvent(new CustomEvent('ts:hero-primary-ready'));
		} else {
			hero?.classList.remove('is-video-pending');
			hero?.classList.add(readiness?.reason === 'error' ? 'is-video-error' : 'is-video-blocked');
			configureVideoFallback(windowObject, hero, video, playButton);
		}

		const configuredMinimum = mode === 'technical' || reducedMotion
			? 0
			: Math.max(0, Number(config.minimumMs) || minimumDuration(false));
		await delay(Math.max(0, configuredMinimum - (Date.now() - startedAt)));
		await dismiss(windowObject, mode, reducedMotion);
	};

	const bootstrapEarly = (windowObject) => {
		const config = windowObject.telecomsecurityPreloaderConfig || {};
		const documentObject = windowObject.document;
		let forced = false;
		let seen = false;
		let reloaded = false;
		try {
			forced = new URLSearchParams(windowObject.location.search).get('ts_preloader') === '1';
			seen = windowObject.sessionStorage.getItem(config.sessionKey) === '1';
			const navigationEntry = windowObject.performance?.getEntriesByType?.('navigation')?.[0];
			reloaded = navigationEntry?.type === 'reload' || windowObject.performance?.navigation?.type === 1;
		} catch (error) {}

		const mode = resolveMode({ isHome: config.isHome === true, forced, seen, reloaded });
		if (mode === 'none') return mode;
		try {
			windowObject.sessionStorage.setItem(config.sessionKey, '1');
		} catch (error) {}

		documentObject.documentElement.classList.add('ts-preloader-js', mode === 'full' ? 'ts-preloader-active' : 'ts-preloader-technical');
		documentObject.documentElement.setAttribute('data-ts-preloader-mode', mode);
		const start = () => initialize(windowObject, mode).catch(() => dismiss(windowObject, mode, true));
		if (documentObject.readyState === 'loading') {
			documentObject.addEventListener('DOMContentLoaded', start, { once: true });
		} else {
			start();
		}
		return mode;
	};

	return {
		resolveMode,
		minimumDuration,
		isVideoAdvancing,
		bootstrapEarly,
	};
});
