/* Native navigation disclosures: one DOM for desktop and mobile. */
function telecomsecurityGetAdminOffset(rect, compact, visible) {
 if (!visible || !rect) return 0;
 if (compact) return Math.max(0, Math.min(rect.height, rect.bottom));
 return Math.max(0, rect.height);
}

document.addEventListener('DOMContentLoaded', () => {
 'use strict';
 const header = document.getElementById('site-header');
 if (!header) return;
 const nav = document.getElementById('ts-header-nav');
 const burger = document.getElementById('ts-burger-btn');
 const desktop = matchMedia('(min-width: 1200px)');
 const mobileDrill = matchMedia('(max-width: 767px)');
 const compactAdminBar = matchMedia('(max-width: 600px)');
 const adminBar = document.getElementById('wpadminbar');
 const disclosures = [...nav.querySelectorAll('.ts-submenu-toggle')];
 const mainPanel = nav.querySelector('.ts-mobile-main-panel');
 const megaPanel = nav.querySelector('.ts-mega');
 const megaButton = megaPanel ? disclosures.find(button => button.getAttribute('aria-controls') === megaPanel.id) : null;
 const megaItem = megaButton?.parentElement || null;
 const megaLink = megaItem?.querySelector(':scope > a') || null;
 const drillBack = megaPanel?.querySelector('.ts-mobile-drill-back') || null;
 const drillClose = megaPanel?.querySelector('.ts-mobile-drill-close') || null;
 const mobilePanelHome = megaPanel?.parentNode || null;
 const mobilePanelNext = megaPanel?.nextSibling || null;
 let mobileOpen = false, lockedScrollY = 0, bodyStyleBackup = null;
 const previews = new Map();
 const timers = new Map();
 const topButtons = disclosures.filter(button => button.parentElement.parentElement.classList.contains('ts-header-menu'));
 const syncAdminOffset = () => {
  const styles = adminBar ? getComputedStyle(adminBar) : null;
  const visible = Boolean(adminBar && styles.display !== 'none' && styles.visibility !== 'hidden');
  const rect = visible ? adminBar.getBoundingClientRect() : null;
  const offset = telecomsecurityGetAdminOffset(rect, compactAdminBar.matches, visible);
  header.style.setProperty('--admin-offset', `${Math.round(offset)}px`);
 };
 const setExpanded = (button, open) => {
  const li = button.parentElement;
  const wasOpen = button.getAttribute('aria-expanded') === 'true';
  const panel = document.getElementById(button.getAttribute('aria-controls'));
  if (open && topButtons.includes(button)) topButtons.forEach(other => { if (other !== button) setExpanded(other, false); });
  button.setAttribute('aria-expanded', String(open));
  li.classList.toggle('is-expanded', open);
  if (panel) {
   panel.inert = !open;
   panel.setAttribute('aria-hidden', String(!open));
  }
  if (open !== wasOpen) previews.get(panel)?.[open ? 'open' : 'close']();
  if (!open) li.querySelectorAll('.ts-submenu-toggle').forEach(child => { if (child !== button) setExpanded(child, false); });
  header.classList.toggle('is-nav-open', desktop.matches && topButtons.some(b => b.getAttribute('aria-expanded') === 'true'));
 };
 const closeAll = () => { timers.forEach(clearTimeout); timers.clear(); topButtons.forEach(button => setExpanded(button, false)); };
 const lockPageScroll = () => {
  if (bodyStyleBackup) return;
  lockedScrollY = window.scrollY;
  bodyStyleBackup = {
   overflow: document.body.style.overflow,
   position: document.body.style.position,
   top: document.body.style.top,
   left: document.body.style.left,
   right: document.body.style.right,
   width: document.body.style.width
  };
  document.body.classList.add('ts-mobile-nav-locked');
  document.body.style.overflow = 'hidden';
  document.body.style.position = 'fixed';
  document.body.style.top = `-${lockedScrollY}px`;
  document.body.style.left = '0';
  document.body.style.right = '0';
  document.body.style.width = '100%';
 };
 const unlockPageScroll = () => {
  if (!bodyStyleBackup) return;
  const previous = bodyStyleBackup;
  bodyStyleBackup = null;
  document.body.classList.remove('ts-mobile-nav-locked');
  document.body.style.overflow = previous.overflow;
  document.body.style.position = previous.position;
  document.body.style.top = previous.top;
  document.body.style.left = previous.left;
  document.body.style.right = previous.right;
  document.body.style.width = previous.width;
  window.scrollTo(0, lockedScrollY);
 };
 const closeMobileDrill = (restoreFocus = false) => {
  header.classList.remove('is-mobile-drill');
  if (mainPanel) {
   mainPanel.inert = false;
   mainPanel.setAttribute('aria-hidden', 'false');
  }
  if (megaButton) setExpanded(megaButton, false);
  if (megaPanel) {
   megaPanel.inert = true;
   megaPanel.setAttribute('aria-hidden', 'true');
  }
  if (restoreFocus) requestAnimationFrame(() => megaLink?.focus());
 };
 const openMobileDrill = () => {
  if (!mobileOpen || !mobileDrill.matches || !megaPanel || !megaButton) return;
  setExpanded(megaButton, true);
  header.classList.add('is-mobile-drill');
  if (mainPanel) {
   mainPanel.inert = true;
   mainPanel.setAttribute('aria-hidden', 'true');
  }
  megaPanel.inert = false;
  megaPanel.setAttribute('aria-hidden', 'false');
  requestAnimationFrame(() => drillBack?.focus());
 };
 const configureMobileDrill = () => {
  if (!megaPanel || !mobilePanelHome) return;
  closeMobileDrill(false);
  if (mobileDrill.matches) {
   if (megaPanel.parentNode !== nav) nav.appendChild(megaPanel);
   nav.classList.add('has-mobile-drill');
   megaPanel.inert = true;
   megaPanel.setAttribute('aria-hidden', 'true');
  } else {
   nav.classList.remove('has-mobile-drill');
   if (megaPanel.parentNode !== mobilePanelHome) mobilePanelHome.insertBefore(megaPanel, mobilePanelNext);
  }
 };
 const setMobile = open => {
  if (mobileOpen === open) return;
  mobileOpen = open;
  header.classList.toggle('is-mobile-open', open);
  burger.setAttribute('aria-expanded', String(open));
  burger.setAttribute('aria-label', open ? 'Chiudi menu di navigazione' : 'Apri menu di navigazione');
  nav.inert = !desktop.matches && !open;
  if (open) {
   closeMobileDrill(false);
   lockPageScroll();
  } else {
   closeMobileDrill(false);
   closeAll();
   unlockPageScroll();
  }
 };
 disclosures.forEach(button => {
  const li = button.parentElement;
  setExpanded(button, false);
  button.addEventListener('click', () => {
   clearTimeout(timers.get(button));
   if (button === megaButton && mobileDrill.matches) { openMobileDrill(); return; }
   setExpanded(button, button.getAttribute('aria-expanded') !== 'true');
  });
  li.addEventListener('pointerenter', event => {
   if (!desktop.matches || event.pointerType !== 'mouse') return;
   clearTimeout(timers.get(button)); timers.set(button, setTimeout(() => setExpanded(button, true), 130));
  });
  li.addEventListener('pointerleave', event => {
   if (!desktop.matches || event.pointerType !== 'mouse') return;
   clearTimeout(timers.get(button)); timers.set(button, setTimeout(() => {
    const focused = document.activeElement;
    const keyboardInside = li.contains(focused) && (!li.querySelector(':scope > .ts-mega') || focused.matches(':focus-visible'));
    if (!keyboardInside) setExpanded(button, false);
   }, 170));
  });
  li.addEventListener('focusin', event => {
   clearTimeout(timers.get(button));
   if (desktop.matches && event.target === li.querySelector(':scope > a')) setExpanded(button, true);
  });
  li.addEventListener('focusout', () => setTimeout(() => { if (desktop.matches && !li.contains(document.activeElement)) setExpanded(button, false); }, 0));
 });
 nav.querySelectorAll('.ts-mega').forEach(panel => {
  const list = panel.querySelector('.ts-mega-links');
  const links = [...list.querySelectorAll(':scope > li > a[data-preview-key]')];
  if (!links.length) return;
  list.style.setProperty('--mega-rows', Math.ceil(links.length / 2));
  const initial = links.find(link => link.dataset.previewInitial === 'true') || links[0];
  const photo = panel.querySelector('.ts-mega-photo');
  const overlay = panel.querySelector('.ts-mega-overlay');
  const sizes = '(min-width: 1300px) 480px, (min-width: 1200px) 42vw, 1px';
  const cache = new Map();
  let opened = false, serial = 0, generation = 0, intent = 0, warmTimer = 0;
  const record = link => ({ src: link.dataset.previewSrc, srcset: link.dataset.previewSrcset || '' });
  const load = link => {
   const media = record(link);
   if (!cache.has(media.src)) {
    const ready = [...photo.querySelectorAll('img')].find(img => img.dataset.imageKey === link.dataset.previewKey && img.complete && img.naturalWidth > 1);
    if (ready) cache.set(media.src, Promise.resolve(media));
    else {
     const image = new Image(); image.sizes = sizes; image.srcset = media.srcset; image.src = media.src;
     cache.set(media.src, image.decode().then(() => media).catch(() => ({ src: panel.dataset.previewFallback, srcset: '' })));
    }
   }
   return cache.get(media.src);
  };
  const commit = (link, media, instant = false) => {
   const current = photo.querySelector('img.is-current');
   if (instant) panel.classList.add('is-preview-reset');
   if (current.dataset.imageKey !== link.dataset.previewKey) {
    const next = [...photo.querySelectorAll('img')].find(img => img !== current);
    const source = next.parentElement.querySelector('source');
    source.sizes = sizes; source.srcset = media.srcset || media.src;
    next.dataset.imageKey = link.dataset.previewKey;
    next.classList.add('is-current'); current.classList.remove('is-current');
   }
   links.forEach(item => { item.dataset.previewActive = String(item === link); });
   overlay.querySelector('.ts-mega-overlay-number').textContent = link.querySelector('.ts-mega-number').textContent;
   overlay.querySelector('.ts-mega-overlay-title').textContent = link.querySelector('.ts-mega-name').textContent;
   overlay.href = link.href;
   ['target', 'rel'].forEach(name => { if (link.hasAttribute(name)) overlay.setAttribute(name, link.getAttribute(name)); else overlay.removeAttribute(name); });
   panel.dataset.activePreview = link.dataset.previewKey;
   panel.querySelectorAll('[data-symbol]').forEach(symbol => { symbol.hidden = symbol.dataset.symbol !== link.dataset.previewSymbol; });
   if (instant) requestAnimationFrame(() => requestAnimationFrame(() => panel.classList.remove('is-preview-reset')));
  };
  const select = async link => {
   if (!desktop.matches || !opened) return;
   const request = ++serial;
   const media = await load(link);
   if (request !== serial || !opened || !desktop.matches) return;
   commit(link, media);
  };
  const warm = (index, run) => {
   if (!opened || !desktop.matches || run !== generation || index >= links.length || navigator.connection?.saveData) return;
   warmTimer = setTimeout(async () => {
    if (!opened || !desktop.matches || run !== generation) return;
    await load(links[index]);
    warm(index + 1, run);
   }, index === 0 ? 400 : 160);
  };
  previews.set(panel, {
   open() {
    if (!desktop.matches) return;
    opened = true; ++serial; ++generation; clearTimeout(intent); clearTimeout(warmTimer);
    commit(initial, record(initial), true);
    warm(0, generation);
   },
   close() { opened = false; ++serial; ++generation; clearTimeout(intent); clearTimeout(warmTimer); }
  });
  links.forEach(link => {
   link.addEventListener('pointerenter', event => {
    if (!desktop.matches || event.pointerType !== 'mouse') return;
    clearTimeout(intent); ++serial;
    intent = setTimeout(() => { intent = 0; select(link); }, 100);
   });
   link.addEventListener('pointerleave', () => { if (intent) { clearTimeout(intent); intent = 0; ++serial; } });
   link.addEventListener('focusin', () => { clearTimeout(intent); intent = 0; select(link); });
  });
 });
 megaLink?.addEventListener('click', event => {
  if (!mobileOpen || !mobileDrill.matches) return;
  event.preventDefault();
  openMobileDrill();
 });
 drillBack?.addEventListener('click', () => closeMobileDrill(true));
 drillClose?.addEventListener('click', () => { setMobile(false); burger.focus(); });
 burger.addEventListener('click', () => { setMobile(!mobileOpen); if (mobileOpen) mainPanel?.querySelector('a')?.focus(); });
 document.addEventListener('click', event => { if (!header.contains(event.target)) { closeAll(); setMobile(false); } });
 document.addEventListener('keydown', event => {
  if (event.key === 'Escape') {
   timers.forEach(clearTimeout); timers.clear();
   if (mobileOpen && mobileDrill.matches) { event.preventDefault(); setMobile(false); burger.focus(); return; }
   const expanded = [...disclosures].reverse().find(button => button.getAttribute('aria-expanded') === 'true' && button.parentElement.contains(document.activeElement)) || topButtons.find(button => button.getAttribute('aria-expanded') === 'true');
   if (expanded) { event.preventDefault(); setExpanded(expanded, false); expanded.focus(); }
   else if (mobileOpen) { event.preventDefault(); setMobile(false); burger.focus(); }
  }
  if (event.key === 'Tab' && mobileOpen) {
   const focusable = [...header.querySelectorAll('a,button')].filter(el => el.getClientRects().length && getComputedStyle(el).visibility !== 'hidden' && !el.closest('[inert]'));
   const first = focusable[0], last = focusable.at(-1);
   if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
   else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  }
 });
 nav.addEventListener('click', event => { if (!event.defaultPrevented && event.target.closest('a') && mobileOpen) setMobile(false); });
 const reset = () => {
  setMobile(false);
  closeAll();
  configureMobileDrill();
  nav.inert = !desktop.matches;
  if (nav.contains(document.activeElement) && !desktop.matches) burger.focus();
 };
 desktop.addEventListener('change', reset);
 mobileDrill.addEventListener('change', reset);
 reset();
 const updateScroll = () => { syncAdminOffset(); header.classList.toggle('is-scrolled', (bodyStyleBackup ? lockedScrollY : window.scrollY) > 40); };
 window.addEventListener('scroll', updateScroll, { passive: true });
 window.addEventListener('resize', syncAdminOffset, { passive: true });
 window.addEventListener('pageshow', event => { if (event.persisted) reset(); updateScroll(); });
 updateScroll();
});
