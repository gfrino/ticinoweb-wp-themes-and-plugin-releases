/**
 * Telecom Security — continuous page progress and persistent contextual rail.
 * One scroll measurement drives both line and dot, including GSAP pin spacing.
 */
(function () {
	'use strict';

	function initSignalRail() {
		const rail = document.getElementById('ts-signal-rail');
		if (!rail) return;
		const label = document.getElementById('ts-signal-rail-label');
		const track = document.getElementById('ts-signal-rail-track');
		const progress = document.getElementById('ts-signal-rail-progress');
		const dot = document.getElementById('ts-signal-rail-dot');
		const arrow = document.getElementById('ts-signal-rail-arrow');
		const previousArrow = document.getElementById('ts-signal-rail-prev');
		const footer = document.querySelector('footer.ts-footer');
		if (!label || !track || !progress || !dot || !arrow) return;

		const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
		const servicesArchive = document.body.classList.contains('ts-services-archive');
		const servicePanels = servicesArchive ? Array.from(document.querySelectorAll('[data-services-viewer] .ts-service-viewer__panel')) : [];
		const visible = window.matchMedia(servicesArchive ? '(min-width: 768px)' : '(min-width: 1366px) and (hover: hover)');
		const initialLabel = label.textContent.trim();
		const initialTheme = rail.dataset.signalTheme || 'light';
		const contextualPage = document.querySelector('[data-signal-label]');
		const sections = Array.from(document.querySelectorAll(contextualPage
			? '[data-signal-label], .ts-method-cta, footer.ts-footer'
			: 'main section, main article, footer'));
		const contexts = sections.map((element, index) => {
			const parent = element.parentElement.closest('[data-signal-label]');
			const next = sections.slice(index + 1).find(section => section.dataset.signalLabel);
			const previous = sections.slice(0, index).reverse().find(section => section.dataset.signalLabel);
			return {
				element,
				label: element.dataset.signalLabel || parent?.dataset.signalLabel || next?.dataset.signalLabel || previous?.dataset.signalLabel || initialLabel,
				theme: element.dataset.signalTheme || (element.matches('.ts-method-cta, footer.ts-footer') ? 'dark' : 'light')
			};
		});
		let frame = 0;
		let atBottom = false;
		let activeServiceIndex = Math.max(0, servicePanels.findIndex(panel => panel.getAttribute('aria-hidden') === 'false'));

		function update() {
			frame = 0;
			if (!visible.matches) return;
			const footerBounds = footer ? footer.getBoundingClientRect() : null;
			const footerVisible = Boolean(footerBounds && footerBounds.top < window.innerHeight && footerBounds.bottom > 0);
			rail.classList.toggle('is-footer-hidden', footerVisible);
			rail.inert = footerVisible;
			rail.setAttribute('aria-hidden', String(footerVisible));
			if (servicesArchive && servicePanels.length) {
				const ratio = servicePanels.length > 1 ? activeServiceIndex / (servicePanels.length - 1) : 0;
				progress.style.transform = `scaleY(${ratio})`;
				dot.style.transform = `translate(-50%, ${ratio * track.clientHeight}px)`;
				if (label.textContent !== initialLabel) label.textContent = initialLabel;
				if (rail.dataset.signalTheme !== initialTheme) rail.dataset.signalTheme = initialTheme;
				if (previousArrow) previousArrow.disabled = activeServiceIndex <= 0;
				arrow.disabled = activeServiceIndex >= servicePanels.length - 1;
				arrow.classList.remove('is-at-bottom');
				arrow.setAttribute('aria-label', 'Servizio successivo');
				return;
			}
			const scrollY = window.scrollY;
			const maxScroll = Math.max(0, document.documentElement.scrollHeight - window.innerHeight);
			const ratio = maxScroll ? Math.min(1, Math.max(0, scrollY / maxScroll)) : 0;
			// No chapter resets or pulse animations competing with this transform.
			progress.style.transform = `scaleY(${ratio})`;
			dot.style.transform = `translate(-50%, ${ratio * track.clientHeight}px)`;
			atBottom = maxScroll > 0 && maxScroll - scrollY <= 2;
			arrow.classList.toggle('is-at-bottom', atBottom);
			arrow.setAttribute('aria-label', atBottom ? "Torna all'inizio della pagina" : 'Scorri alla sezione successiva');

			// Deterministic in both directions, even after jumping over several sections.
			// The last containing element wins, so Metodo's dark CTA overrides its parent.
			const reference = window.innerHeight / 2;
			let current = { label: initialLabel, theme: initialTheme };
			for (const context of contexts) {
				if (context.element.getBoundingClientRect().top <= reference) current = context;
			}
			// Services add their CMS-derived ordinal while page progress stays continuous.
			const services = document.getElementById('servizi');
			if (current?.element && services?.contains(current.element)) {
				const key = services.dataset.bridgeService;
				const chapter = current.element.closest('.ts-services-chapter');
				const item = key
					? Array.from(services.querySelectorAll('.ts-service-flow-item')).find(item => item.dataset.serviceKey === key)
					: chapter?.querySelector('.ts-service-flow-item.is-active') || (current.element.id === 'ts-services-trans' ? document.querySelector('#ts-services-flow-ch1 .ts-service-flow-item:last-child') : null);
				if (item) {
					const chapterName = item.closest('.ts-services-chapter').querySelector('.ts-chapter-name').textContent.trim();
					current = { ...current, label: `${chapterName} · ${item.dataset.serviceNumber} / ${item.dataset.serviceTotal}` };
				}
				if (key) current = { ...current, theme: services.dataset.bridgeDark === 'true' ? 'dark' : 'light' };
			}
			if (current) {
				if (label.textContent !== current.label) label.textContent = current.label;
				if (rail.dataset.signalTheme !== current.theme) rail.dataset.signalTheme = current.theme;
			}
		}
		function schedule() {
			if (!frame) frame = window.requestAnimationFrame(update);
		}
		window.addEventListener('scroll', schedule, { passive: true });
		window.addEventListener('ts-service-active', event => {
			if (servicesArchive && Number.isInteger(event.detail?.index)) activeServiceIndex = event.detail.index;
			schedule();
		});
		window.addEventListener('resize', schedule, { passive: true });
		window.addEventListener('pageshow', schedule);
		window.addEventListener('load', schedule, { once: true });
		visible.addEventListener('change', schedule);
		if (document.fonts) document.fonts.ready.then(schedule);
		if ('ResizeObserver' in window) new ResizeObserver(schedule).observe(document.body);
		if (window.ScrollTrigger) window.ScrollTrigger.addEventListener('refresh', schedule);
		schedule();

		arrow.addEventListener('click', () => {
			if (servicesArchive) {
				window.dispatchEvent(new CustomEvent('ts-service-navigate', { detail: { delta: 1 } }));
				return;
			}
			const behavior = reducedMotion.matches ? 'instant' : 'smooth';
			if (atBottom) {
				window.scrollTo({ top: 0, behavior });
				return;
			}
			const header = document.getElementById('site-header');
			const adminBar = document.getElementById('wpadminbar');
			const inset = (header?.getBoundingClientRect().height || 0) + (adminBar?.getBoundingClientRect().height || 0);
			const next = sections.find(section => section.getBoundingClientRect().top > inset + 2);
			const top = next ? window.scrollY + next.getBoundingClientRect().top - inset : document.documentElement.scrollHeight - window.innerHeight;
			window.scrollTo({ top, behavior });
		});
		previousArrow?.addEventListener('click', () => {
			window.dispatchEvent(new CustomEvent('ts-service-navigate', { detail: { delta: -1 } }));
		});
	}

	if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initSignalRail);
	else initSignalRail();
})();
