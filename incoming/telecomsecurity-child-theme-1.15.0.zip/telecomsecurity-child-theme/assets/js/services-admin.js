(function ($) {
    'use strict';
    $(function () {
        var config = window.telecomsecurityServicesAdmin;
        var container = document.getElementById('services-container');
        if (!config || !container) return;
        var records = config.services || [];
        var labels = config.labels;

        function uuid() {
            if (window.crypto && window.crypto.randomUUID) return window.crypto.randomUUID();
            return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                var n = Math.floor(Math.random() * 16);
                return (c === 'x' ? n : (n & 3) | 8).toString(16);
            });
        }
        function field(item, key) {
            return item.querySelector('[name$="[' + key + ']"]');
        }
        function hidden(item, key, value) {
            var input = field(item, key);
            if (!input) {
                input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'ticinoweb_services[' + item.dataset.index + '][' + key + ']';
                item.appendChild(input);
            }
            input.value = value;
        }
        function hydrate(item, initial) {
            if (item.dataset.tsServicesReady) return;
            item.dataset.tsServicesReady = '1';
            var existingId = field(item, 'id');
            var matches = existingId && existingId.value ? records.filter(function (row) {
                return row.id === existingId.value;
            }) : [];
            // Older parents render no ID. Match the complete rendered record once,
            // before edits; never infer a page association from the row position.
            if (!matches.length && initial) {
                matches = records.filter(function (row) {
                    return ['title', 'description', 'image', 'icon', 'icon_svg'].every(function (key) {
                        var input = field(item, key);
                        return String(row[key] || '').replace(/\r\n/g, '\n') === (input ? input.value : '').replace(/\r\n/g, '\n');
                    });
                });
            }
            var record = matches.length === 1 ? matches[0] : {};
            var id = record.id || (existingId && existingId.value) || uuid();
            hidden(item, 'id', id);
            hidden(item, 'page_id', record.page_id || 0);
            var symbolId = 'ts-symbol-' + uuid();
            var symbolRow = $('<tr>');
            $('<th scope="row">').append($('<label>').attr('for', symbolId).text('Simbolo Secure Geometry')).appendTo(symbolRow);
            var symbolSelect = $('<select>').attr({id: symbolId, name: 'ticinoweb_services[' + item.dataset.index + '][geometry]'});
            (config.symbols || []).forEach(function (key) { $('<option>').val(key).text(key).appendTo(symbolSelect); });
            symbolSelect.val(record.geometry || config.symbolDefaults[id] || 'shield');
            $('<td>').append(symbolSelect).appendTo(symbolRow);
            $(item).find('.service-fields .form-table').first().prepend(symbolRow);

            var selectId = 'ts-service-area-' + uuid();
            var row = $('<tr>');
            $('<th scope="row">').append($('<label>').attr('for', selectId).text(labels.area)).appendTo(row);
            var select = $('<select>').attr({ id: selectId, name: 'ticinoweb_services[' + item.dataset.index + '][area]' });
            ['security', 'infrastructure'].forEach(function (area) {
                $('<option>').val(area).text(labels[area]).appendTo(select);
            });
            select.val(record.area === 'infrastructure' ? 'infrastructure' : 'security');
            $('<td>').append(select).appendTo(row);
            $(item).find('.service-fields .form-table').first().prepend(row);
            ['up', 'down'].forEach(function (direction) {
                $('<button type="button" class="button">').attr({ 'data-ts-move': direction, 'aria-label': labels[direction] }).text(direction === 'up' ? '↑' : '↓').insertBefore($(item).find('.remove-service').first());
            });
        }
        container.querySelectorAll('.service-item').forEach(function (item) { hydrate(item, true); });
        new MutationObserver(function () {
            container.querySelectorAll('.service-item').forEach(function (item) { hydrate(item, false); });
        }).observe(container, { childList: true });
        $(container).on('click', '[data-ts-move]', function () {
            var item = $(this).closest('.service-item');
            var sibling = this.dataset.tsMove === 'up' ? item.prev('.service-item') : item.next('.service-item');
            if (sibling.length) {
                if (this.dataset.tsMove === 'up') item.insertBefore(sibling);
                else item.insertAfter(sibling);
                this.focus();
            }
        });

        var editorial = $('<section>').attr('aria-labelledby', 'ts-services-editorial-heading');
        $('<h2 id="ts-services-editorial-heading">').text(labels.heading).appendTo(editorial);
        var table = $('<table class="form-table">').appendTo(editorial);
        ['chapter_1_title', 'chapter_1_text', 'chapter_2_title', 'chapter_2_text', 'transition_title', 'transition_text'].forEach(function (key) {
            var row = $('<tr>').appendTo(table);
            var id = 'ts-services-' + key;
            $('<th scope="row">').append($('<label>').attr('for', id).text(labels[key])).appendTo(row);
            var input = /_text$/.test(key) ? $('<textarea rows="3" class="large-text">') : $('<input type="text" class="large-text">');
            input.attr({ id: id, name: 'ts_services_editorial[' + key + ']' }).val(config.editorial[key] || '');
            $('<td>').append(input).appendTo(row);
        });
        editorial.insertBefore(container);

        // Window receives the bubbling submit after the parent's form handlers.
        window.addEventListener('submit', function (event) {
            if (event.target !== container.closest('form')) return;
            $(container).find('[data-ts-empty-services]').remove();
            if (!container.querySelector('.service-item')) {
                // An explicit empty row distinguishes deleting every service from
                // saving another settings screen where this option is absent.
                $('<input type="hidden" data-ts-empty-services="1">').attr('name', 'ticinoweb_services[0][title]').val('').appendTo(container);
            }
            container.querySelectorAll('.service-item').forEach(function (item, index) {
                hydrate(item, false);
                item.dataset.index = index;
                item.querySelectorAll('[name^="ticinoweb_services["]').forEach(function (input) {
                    input.name = input.name.replace(/^ticinoweb_services\[[^\]]*\]/, 'ticinoweb_services[' + index + ']');
                });
            });
        });
    });
})(jQuery);
