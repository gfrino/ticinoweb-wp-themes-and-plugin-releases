(function ($) {
	'use strict';

	$(function () {
		var config = window.telecomsecurityAboutLeaderAdmin;
		var tab = document.getElementById('chi-siamo');
		var sourceTable = tab ? tab.querySelector('.form-table') : null;
		if (!config || !tab || !sourceTable || tab.querySelector('.ts-about-leader-admin')) {
			return;
		}

		var saved = config.saved || {};
		var labels = config.labels || {};
		var galleries = Array.isArray(config.galleries) ? config.galleries : [];
		var panel = $('<section class="ts-about-leader-admin" aria-labelledby="ts-about-leader-admin-title">');
		var heading = $('<header class="ts-about-leader-admin__heading">').appendTo(panel);
		$('<h2 id="ts-about-leader-admin-title">').text(labels.heading || '').appendTo(heading);
		$('<p>').text(labels.description || '').appendTo(heading);
		var table = $('<table class="form-table" role="presentation">').appendTo(panel);

		function addTextRow(key, label, help) {
			var id = 'ts-about-leader-' + key;
			var row = $('<tr>').appendTo(table);
			$('<th scope="row">').append($('<label>').attr('for', id).text(label)).appendTo(row);
			var cell = $('<td>').appendTo(row);
			$('<input type="text" class="regular-text">')
				.attr({ id: id, name: 'ts_about_leader[' + key + ']' })
				.val(saved[key] || '')
				.appendTo(cell);
			$('<p class="description">').text(help).appendTo(cell);
		}

		addTextRow('name', labels.name || '', labels.nameHelp || '');
		addTextRow('role', labels.role || '', labels.roleHelp || '');

		var portraitRow = $('<tr>').appendTo(table);
		$('<th scope="row">').text(labels.portrait || '').appendTo(portraitRow);
		var portraitCell = $('<td>').appendTo(portraitRow);
		var portraitInput = $('<input type="hidden" name="ts_about_leader[portrait_id]">')
			.val(saved.portrait_id || 0)
			.appendTo(portraitCell);
		var portraitPreview = $('<div class="ts-about-leader-admin__portrait-preview" aria-live="polite">').appendTo(portraitCell);
		var portraitActions = $('<div class="ts-about-leader-admin__actions">').appendTo(portraitCell);
		var portraitButton = $('<button type="button" class="button button-secondary">').appendTo(portraitActions);
		var portraitRemove = $('<button type="button" class="button-link-delete">')
			.text(labels.removePortrait || '')
			.appendTo(portraitActions);

		function updatePortrait(url, attachmentId) {
			portraitInput.val(attachmentId || 0);
			portraitPreview.empty();
			if (url) {
				$('<img>').attr({ src: url, alt: '' }).appendTo(portraitPreview);
			}
			portraitButton.text(url ? labels.changePortrait : labels.selectPortrait);
			portraitRemove.toggle(Boolean(url));
		}

		updatePortrait(config.portrait_url || '', saved.portrait_id || 0);
		portraitButton.on('click', function () {
			var frame = wp.media({
				title: labels.portraitDialog || '',
				button: { text: labels.usePortrait || '' },
				library: { type: 'image' },
				multiple: false
			});
			frame.on('select', function () {
				var image = frame.state().get('selection').first().toJSON();
				var previewUrl = image.sizes && image.sizes.medium ? image.sizes.medium.url : image.url;
				updatePortrait(previewUrl, image.id);
			});
			frame.open();
		});
		portraitRemove.on('click', function () {
			updatePortrait('', 0);
		});

		var galleryRow = $('<tr>').appendTo(table);
		$('<th scope="row">').append($('<label for="ts-about-leader-gallery">').text(labels.gallery || '')).appendTo(galleryRow);
		var galleryCell = $('<td>').appendTo(galleryRow);
		var gallerySelect = $('<select id="ts-about-leader-gallery" name="ts_about_leader[gallery_id]">').appendTo(galleryCell);
		$('<option value="0">').text(labels.galleryEmpty || '').appendTo(gallerySelect);
		galleries.forEach(function (gallery) {
			$('<option>')
				.val(gallery.id)
				.text(gallery.name + ' (' + gallery.count + ')')
				.appendTo(gallerySelect);
		});
		gallerySelect.val(String(saved.gallery_id || 0));
		$('<p class="description">').text(labels.galleryHelp || '').appendTo(galleryCell);
		var galleryPreview = $('<div class="ts-about-leader-admin__gallery-preview" aria-live="polite">').appendTo(galleryCell);
		var galleryActions = $('<div class="ts-about-leader-admin__gallery-actions">').appendTo(galleryCell);
		var galleryManage = $('<a class="button button-secondary" target="_blank" rel="noopener noreferrer">').appendTo(galleryActions);
		var permissionNotice = $('<p class="description">').text(labels.permissionNotice || '').appendTo(galleryActions);

		function selectedGallery() {
			var selectedId = Number(gallerySelect.val() || 0);
			return galleries.find(function (gallery) { return Number(gallery.id) === selectedId; }) || null;
		}

		function updateGallery() {
			var gallery = selectedGallery();
			galleryPreview.empty();
			if (gallery && gallery.preview_urls && gallery.preview_urls.length) {
				gallery.preview_urls.forEach(function (url) {
					$('<img>').attr({ src: url, alt: '' }).appendTo(galleryPreview);
				});
			} else {
				$('<span>').text(labels.previewEmpty || '').appendTo(galleryPreview);
			}
			galleryManage
				.attr('href', gallery ? gallery.manage_url : config.manager_url)
				.text(gallery ? labels.manageGallery : labels.createGallery)
				.toggle(Boolean(config.canManageGalleries));
			permissionNotice.toggle(!config.canManageGalleries);
		}

		gallerySelect.on('change', updateGallery);
		updateGallery();
		$(sourceTable).after(panel);
	});
})(jQuery);
