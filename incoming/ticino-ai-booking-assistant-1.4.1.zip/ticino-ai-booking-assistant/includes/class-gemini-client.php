<?php

/**
 * Motore conversazionale del chatbot.
 *
 * Nonostante il nome storico, dalla 1.0.18 la classe e' provider-agnostic:
 * intent detection, system prompt e fallback locale sono condivisi, mentre la
 * chiamata HTTP viene smistata da call_llm() verso Gemini oppure OpenAI in base
 * all'opzione `ticino_ai_provider`.
 */
class Ticino_AI_Booking_Gemini_Client {

    private $api_key;
    private $model;
    private $provider;
    private $endpoint = 'https://generativelanguage.googleapis.com/v1beta/models/';
    
    // Variabili per debug/logging
    public $last_intent = 'unknown';
    public $used_fallback = false;
    public $gemini_error = ''; // nome storico: contiene l'ultimo errore del provider attivo
    public $last_latency_ms = 0;
    private $reply_language = '';

    /**
     * Lingua in cui rispondere (nome in italiano, '' se non si capisce). Prompt e contenuti
     * sono quasi sempre in italiano e il modello tende a seguirli: nominare la lingua tiene
     * la risposta nella lingua del visitatore. Conta le parole del messaggio; se non bastano,
     * vale la lingua della pagina (<html lang>, impostata da WPML e da tW Translate Plus).
     */
    public static function reply_language($message, $page_lang = '') {
        $names = array('it' => 'italiano', 'en' => 'inglese', 'de' => 'tedesco', 'fr' => 'francese');
        $words = array(
            'it' => 'il lo la le gli di che chi non per con una sono come cosa dove quando quanto perché anche ha hanno avete potete vorrei posso del della ciao grazie buongiorno',
            'en' => 'the and what when where who how why is are was were did does do you your can could would please with from this that have has she he hello thanks',
            'de' => 'der die das und ist sind wie was wer wo wann warum ich sie wir ihr haben hat nicht mit für ein eine kann können bitte danke hallo gibt es',
            'fr' => 'le la les et est sont comment quoi qui où quand pourquoi je vous nous avez avoir pas avec pour une un peut pouvez merci bonjour des du',
        );
        $tokens = preg_split('/[^\p{L}]+/u', mb_strtolower((string) $message), -1, PREG_SPLIT_NO_EMPTY);
        $scores = array();
        foreach ($words as $code => $list) {
            $set = array_flip(explode(' ', $list));
            $scores[$code] = 0;
            foreach ($tokens as $t) {
                if (isset($set[$t])) $scores[$code]++;
            }
        }
        arsort($scores);
        $top = array_slice($scores, 0, 2, true);
        $codes = array_keys($top);
        if ($top[$codes[0]] >= 1 && $top[$codes[0]] > $top[$codes[1]]) {
            return $names[$codes[0]];
        }
        $page = strtolower(substr(preg_replace('/[^a-zA-Z]/', '', (string) $page_lang), 0, 2));
        return isset($names[$page]) ? $names[$page] : '';
    }

    public function __construct() {
        $this->provider = self::get_active_provider();
        $this->api_key = get_option('ticino_ai_gemini_api_key');
        
        $model = get_option('ticino_ai_gemini_model', 'gemini-2.0-flash');
        if ($model === 'custom') {
            $model = get_option('ticino_ai_gemini_model_custom', 'gemini-2.0-flash');
        }
        $this->model = $model;
    }

    private function get_company_name() {
        $name = get_option('ticino_ai_company_name');
        return !empty($name) ? $name : get_bloginfo('name');
    }

    /** 'gemini' (default) oppure 'openai'. */
    public static function get_active_provider() {
        $provider = get_option('ticino_ai_provider', 'gemini');
        return in_array($provider, array('gemini', 'openai'), true) ? $provider : 'gemini';
    }

    public function get_provider() {
        return $this->provider;
    }

    public function get_provider_label() {
        return $this->provider === 'openai' ? 'OpenAI' : 'Gemini';
    }

    /** Chiave API del provider attivo presente? */
    public static function is_configured() {
        if (self::get_active_provider() === 'openai') {
            return !empty(get_option('ticino_ai_openai_api_key'));
        }
        return !empty(get_option('ticino_ai_gemini_api_key'));
    }

    /**
     * Smista la richiesta al provider attivo.
     *
     * @param string $system_instruction
     * @param array  $messages   ['role' => 'user'|'model', 'content' => string]
     * @return string|WP_Error
     */
    private function call_llm($system_instruction, $messages, $temperature, $max_tokens, $timeout) {
        $attempts = 0;
        $max_attempts = 2; // 1 tentativo + 1 retry sui soli errori transitori (rete, DNS, timeout, 429, 5xx)
        do {
            $attempts++;
            $started = microtime(true);
            if ($this->provider === 'openai') {
                $openai = new Ticino_AI_Booking_OpenAI_Client();
                $result = $openai->chat($system_instruction, $messages, $temperature, $max_tokens, $timeout);
            } else {
                $result = $this->call_gemini($system_instruction, $messages, $temperature, $max_tokens, $timeout);
            }
            $this->last_latency_ms = (int) round((microtime(true) - $started) * 1000);

            if (!is_wp_error($result)) {
                return $result;
            }
            $transient = self::is_transient_error($result);
            Ticino_AI_Booking_Chatbot::log_error(sprintf(
                '%s tentativo %d/%d fallito in %d ms: %s%s',
                $this->get_provider_label(), $attempts, $max_attempts, $this->last_latency_ms,
                $result->get_error_message(), $transient && $attempts < $max_attempts ? ' (riprovo)' : ''
            ));
        } while ($transient && $attempts < $max_attempts);

        return $result;
    }

    /** Errori per cui ha senso un secondo tentativo: rete/DNS/timeout, rate limit, errori 5xx del provider. */
    private static function is_transient_error($err) {
        $msg = mb_strtolower($err->get_error_message());
        $code = (string) $err->get_error_code();
        if ($code === 'http_request_failed') return true; // cURL: timeout, DNS, connessione
        if (preg_match('/timed? ?out|getaddrinfo|resolve|connection|reset by peer|rate limit|overloaded|temporarily|try again|server error|bad gateway|unavailable|\b(429|500|502|503|504)\b/', $msg)) return true;
        return false;
    }

    private function call_gemini($system_instruction, $messages, $temperature, $max_tokens, $timeout) {
        if (empty($this->api_key)) {
            return new WP_Error('no_api_key', 'Gemini API key non configurata.');
        }

        $url = $this->endpoint . $this->model . ':generateContent?key=' . $this->api_key;

        $contents = array();
        foreach ($messages as $msg) {
            $contents[] = array(
                'role' => $msg['role'] === 'user' ? 'user' : 'model',
                'parts' => array(
                    array('text' => (string) $msg['content'])
                )
            );
        }

        $body = array(
            'system_instruction' => array(
                'parts' => array(
                    array('text' => $system_instruction)
                )
            ),
            'contents' => $contents,
            'generationConfig' => array(
                'temperature' => $temperature,
                'maxOutputTokens' => $max_tokens,
            )
        );

        $api_resp = wp_remote_post($url, array(
            'headers' => array('Content-Type' => 'application/json'),
            'body'    => wp_json_encode($body),
            'timeout' => $timeout
        ));

        if (is_wp_error($api_resp)) {
            return $api_resp;
        }

        $code = wp_remote_retrieve_response_code($api_resp);
        $body_response = json_decode(wp_remote_retrieve_body($api_resp), true);

        if ($code !== 200) {
            $err_msg = isset($body_response['error']['message']) ? $body_response['error']['message'] : 'Errore sconosciuto Gemini API';
            return new WP_Error('api_error', $err_msg);
        }
        if (isset($body_response['candidates'][0]['content']['parts'][0]['text'])) {
            return $body_response['candidates'][0]['content']['parts'][0]['text'];
        }
        return new WP_Error('api_error', 'Risposta inattesa da Gemini API.');
    }

    public function generate_response($messages, $page_lang = '') {
        // Estrai l'ultimo messaggio dell'utente per l'intent
        $last_user_message = '';
        foreach (array_reverse($messages) as $msg) {
            if ($msg['role'] === 'user') {
                $last_user_message = sanitize_text_field($msg['content']);
                break;
            }
        }

        // Rileva l'intento
        $this->last_intent = $this->detect_user_intent($last_user_message);

        // Domanda per la ricerca nei PDF: ultima domanda + la precedente (domande di seguito come "e quanto costa?")
        $user_turns = array();
        foreach (array_reverse($messages) as $msg) {
            if (($msg['role'] ?? '') === 'user') {
                $user_turns[] = mb_substr(sanitize_text_field($msg['content']), 0, 500);
                if (count($user_turns) === 2) break;
            }
        }

        // Chiamata al provider attivo (Gemini o OpenAI)
        $this->reply_language = self::reply_language(isset($user_turns[0]) ? $user_turns[0] : '', $page_lang);
        $system_instruction = $this->build_system_prompt($this->last_intent, implode("\n", $user_turns));
        // Solo gli ultimi 10 messaggi: la conoscenza del sito e' gia' nel prompt, lo storico lungo costa token e tempo
        $messages = array_slice(array_values($messages), -10);
        $clean_messages = array();
        foreach ($messages as $msg) {
            $content = mb_substr(sanitize_text_field($msg['content']), 0, 2000);
            if ($content === '') continue;
            $clean_messages[] = array(
                'role'    => $msg['role'] === 'user' ? 'user' : 'model',
                'content' => $content,
            );
        }
        $style = self::get_response_style();
        $response = $this->call_llm($system_instruction, $clean_messages, 0.3, $style['max_tokens'], 20);

        // Se il provider ha fallito o manca l'API Key, utilizziamo SEMPRE il fallback locale intelligente
        if (is_wp_error($response)) {
            $this->gemini_error = $response->get_error_message();
            $fallback = $this->get_local_fallback($this->last_intent, $last_user_message);
            
            if (!empty($fallback)) {
                $this->used_fallback = true;
                return $fallback;
            } else {
                return $response;
            }
        }

        return $response;
    }

    /**
     * Rilevamento dell'intento, neutro rispetto al settore: serve a scegliere il
     * fallback locale quando l'AI non risponde e a loggare. Le parole chiave di
     * settore non stanno qui: le mette il sito stesso nella conoscenza dinamica.
     */
    public function detect_user_intent($message) {
        $msg = mb_strtolower(trim((string) $message));
        if ($msg === '') return 'generic';

        $intents = apply_filters('ticino_ai_intent_patterns', array(
            'team'      => '/\bteam\b|chi lavora|chi siete|chi sei|personale|collaborator|staff|titolare|responsabil/u',
            'booking'   => '/prenot|appuntamento|fissare|riservar|disponibilit|preventivo|sopralluogo|consulenza|richiesta/u',
            'orari'     => '/orar|apert|chius|quando siete|che ore|sabato|domenica|festiv/u',
            'sede'      => '/\bdove\b|indirizzo|sede|come arriv|come raggiung|parcheggi|mappa|vi trov/u',
            'contatti'  => '/telefon|chiam|contatt|whatsapp|numero|scriver|mail|e-mail/u',
            'prezzi'    => '/prezz|\bcost|tariff|quanto viene|listino|quanto spendo|quanto costa|preventiv/u',
            'promozioni'=> '/promozion|offert|sconto|promo|pacchett/u',
            'servizi'   => '/serviz|cosa offrite|cosa fate|di cosa vi occupate|trattament|prestazion|attivit|catalogo|cosa proponete/u',
            'prodotti'  => '/prodott|brand|marc|articol|vendete|shop|negozio/u',
        ));
        foreach ($intents as $intent => $pattern) {
            if (preg_match($pattern, $msg)) {
                return $intent;
            }
        }
        return 'generic';
    }

    /** Modalita' lead attiva? (vedi Ticino_AI_Booking_Chatbot::get_mode) */
    private static function lead_mode() {
        return class_exists('Ticino_AI_Booking_Chatbot') ? Ticino_AI_Booking_Chatbot::is_lead_mode() : (get_option('ticino_ai_mode', 'booking') === 'lead');
    }

    /** Stili di risposta selezionabili (Impostazioni > Modello AI > Stile di risposta). */
    public static function response_styles() {
        return array(
            'breve' => array(
                'label'      => 'Breve e conversazionale (consigliato)',
                'max_tokens' => 350,
                'rule'       => "Rispondi in modo BREVE e conversazionale, come in una chat: massimo 3-4 frasi (circa 60-80 parole). Vai dritto al punto, niente introduzioni, niente riepiloghi, niente formattazione pesante. Se l'utente chiede un elenco, massimo 5 voci di una riga. Se ci sarebbe molto da dire, dai l'essenziale e chiudi con UNA domanda per capire cosa interessa. Gli avvisi lunghi (es. informative) vanno riportati solo quando la regola che li prevede si applica esattamente, mai per domande generiche.",
            ),
            'normale' => array(
                'label'      => 'Normale',
                'max_tokens' => 600,
                'rule'       => "Rispondi in modo chiaro e completo ma senza prolissita': massimo 6-8 frasi o un elenco di massimo 8 voci. Niente introduzioni e niente ripetizioni della domanda.",
            ),
            'dettagliata' => array(
                'label'      => 'Dettagliata',
                'max_tokens' => 1200,
                'rule'       => "Puoi rispondere in modo articolato e completo quando la domanda lo richiede, mantenendo comunque struttura e leggibilita'.",
            ),
        );
    }

    public static function get_response_style() {
        $styles = self::response_styles();
        $key = get_option('ticino_ai_response_style', 'breve');
        return isset($styles[$key]) ? $styles[$key] : $styles['breve'];
    }

    /** Testo di default delle regole comportamentali (neutro, modificabile in Impostazioni > Modello AI). */
    public static function default_behavior_rules() {
        $closing = self::lead_mode()
            ? "5. CHIUSURA: quando ha senso, invita a lasciare una richiesta di informazioni o di preventivo qui in chat (bottone dedicato o frase «Vorrei informazioni») oppure a contattare l'azienda. Non proporre mai di fissare un appuntamento in chat e non promettere date o tempi di risposta."
            : "5. CHIUSURA: quando ha senso, invita a richiedere un appuntamento, un preventivo o un contatto.";
        return "1. FEDELTA' AI CONTENUTI: rispondi basandoti SOLO sulle informazioni del sito e delle impostazioni riportate sopra. Non inventare dati, prezzi, orari, nomi o servizi non presenti.\n"
             . "2. SE L'INFORMAZIONE MANCA: dillo con cortesia e invita a contattare l'azienda con i recapiti indicati, oppure a lasciare una richiesta in chat. Non dire mai 'assistente non disponibile'.\n"
             . "3. RISPOSTE CHIARE: quando l'utente chiede di un servizio o prodotto, riporta cio' che il sito dice: in cosa consiste, durata e prezzo se indicati.\n"
             . "4. TONO: professionale, cordiale e conciso, nella lingua dell'utente (di default italiano). Niente consigli medici, legali o finanziari personalizzati: rimanda a un professionista.\n"
             . $closing;
    }

    /** Prompt di sistema di default (neutro): usa i dati aziendali del sito e la modalita' scelta. */
    public static function default_system_prompt() {
        $company = class_exists('Ticino_AI_Booking_Dynamic_Site_Knowledge') ? Ticino_AI_Booking_Dynamic_Site_Knowledge::get_company_info() : array('name' => get_bloginfo('name'));
        $name = !empty($company['name']) ? $company['name'] : get_bloginfo('name');
        if (self::lead_mode()) {
            return "Sei l'assistente virtuale di {$name}. Il tuo compito e' aiutare i visitatori del sito a conoscere l'azienda, i suoi prodotti, servizi e lavorazioni, le sedi e i contatti, e ad aprire un contatto commerciale lasciando una richiesta di informazioni o di preventivo.\n\n"
                 . "--- REGOLE DI RISPOSTA ---\n"
                 . "* Rispondi nella lingua dell'utente (di default in italiano), con tono gentile e professionale.\n"
                 . "* Usa solo le informazioni fornite: se qualcosa non e' indicato, invita a contattare l'azienda.\n"
                 . "* Non dare consigli medici, legali o finanziari personalizzati.\n"
                 . "* Non fissi appuntamenti e non prometti date: raccogli la richiesta di contatto (nome, telefono, email, esigenza) e sara' l'azienda a ricontattare il visitatore.\n"
                 . "* Non fornire prezzi o preventivi: per ogni richiesta di costo invita a lasciare una richiesta di preventivo.";
        }
        return "Sei l'assistente virtuale di {$name}. Il tuo compito e' aiutare i visitatori del sito a conoscere l'azienda, i suoi servizi e prodotti, gli orari, i contatti e le modalita' per richiedere un appuntamento o un preventivo.\n\n"
             . "--- REGOLE DI RISPOSTA ---\n"
             . "* Rispondi nella lingua dell'utente (di default in italiano), con tono gentile e professionale.\n"
             . "* Usa solo le informazioni fornite: se qualcosa non e' indicato, invita a contattare l'azienda.\n"
             . "* Non dare consigli medici, legali o finanziari personalizzati.\n"
             . "* Puoi raccogliere richieste di appuntamento, ma non confermarle: la conferma arriva dall'azienda.";
    }

    private function build_system_prompt($intent, $pdf_query = '') {
        $base_prompt = get_option('ticino_ai_gemini_system_prompt');
        if (trim((string) $base_prompt) === '') {
            $base_prompt = self::default_system_prompt();
        }
        $kb_source   = get_option('ticino_ai_kb_source', 'site_auto');
        
        $prompt = $base_prompt . "\n\n";

        if ($kb_source === 'custom') {
            // === MODALITÀ 1: KNOWLEDGE BASE PERSONALIZZATA (MANUALE) ===
            $company_desc = get_option('ticino_ai_kb_company_desc', '');
            if (!empty($company_desc)) {
                $prompt .= "=== INFORMAZIONI AZIENDALI & DESCRIZIONE ===\n" . $company_desc . "\n\n";
            }

            $services_json = get_option('ticino_ai_kb_services', '[]');
            $services = json_decode($services_json, true) ?: array();
            if (!empty($services)) {
                $prompt .= "=== SERVIZI OFFERTI ===\n";
                foreach ($services as $s) {
                    $s_title = $s['title'] ?? '';
                    $s_cat = $s['category'] ?? '';
                    $s_dur = !empty($s['duration']) ? " (Durata: {$s['duration']})" : '';
                    $s_desc = $s['description'] ?? '';
                    $prompt .= "• {$s_title} [{$s_cat}]{$s_dur}: {$s_desc}\n";
                }
                $prompt .= "\n";
            }

            $techs_json = get_option('ticino_ai_kb_techs', '[]');
            $techs = json_decode($techs_json, true) ?: array();
            if (!empty($techs)) {
                $prompt .= "=== TECNOLOGIE UTILIZZATE ===\n";
                foreach ($techs as $t) {
                    $prompt .= "- {$t}\n";
                }
                $prompt .= "\n";
            }

            $products_json = get_option('ticino_ai_kb_products', '[]');
            $products = json_decode($products_json, true) ?: array();
            if (!empty($products)) {
                $prompt .= "=== PRODOTTI E BRAND PROFESSIONALI ===\n";
                foreach ($products as $p) {
                    $prompt .= "- {$p}\n";
                }
                $prompt .= "\n";
            }

            $faq_json = get_option('ticino_ai_kb_faq', '[]');
            $faqs = json_decode($faq_json, true) ?: array();
            if (!empty($faqs)) {
                $prompt .= "=== DOMANDE FREQUENTI (FAQ) ===\n";
                foreach ($faqs as $f) {
                    $prompt .= "Q: {$f['q']}\nA: {$f['a']}\n\n";
                }
            }

        } else {
            // === MODALITÀ 2: ANALISI AUTOMATICA & DINAMICA DELL'INTERO SITO WEB (CONSIGLIATA) ===
            $site_context = Ticino_AI_Booking_Dynamic_Site_Knowledge::get_full_site_knowledge_context();
            $prompt .= $site_context . "\n\n";
        }

        // Conoscenza aggiuntiva anche in modalita' manuale
        if ($kb_source === 'custom') {
            $extra = trim((string) get_option('ticino_ai_kb_extra_context', ''));
            if ($extra !== '') {
                $prompt .= "=== CONOSCENZA AGGIUNTIVA ===\n" . $extra . "\n\n";
            }
        }

        // Documenti PDF della Knowledge Base, in entrambe le modalita': solo i passaggi pertinenti alla domanda
        $pdf_context = class_exists('Ticino_AI_Booking_PDF_Knowledge') ? Ticino_AI_Booking_PDF_Knowledge::get_prompt_context($pdf_query) : '';
        $prompt .= $pdf_context;

        // REGOLE COMPORTAMENTALI (modificabili in Impostazioni > Modello AI)
        $rules = get_option('ticino_ai_behavior_rules');
        if (trim((string) $rules) === '') {
            $rules = self::default_behavior_rules();
        }
        $prompt .= "=== REGOLE COMPORTAMENTALI ===\n" . trim($rules) . "\n\n";

        // FORMATO DELLA RISPOSTA: ha la precedenza su qualsiasi regola precedente sulla lunghezza
        $style = self::get_response_style();
        $prompt .= "=== FORMATO DELLA RISPOSTA (PRIORITA' MASSIMA) ===\n" . $style['rule'] . "\n";
        // Lingua e fonte qui in fondo: le informazioni sopra sono spesso in un'altra lingua e il modello tende a seguirle
        if ($pdf_context !== '') {
            $prompt .= "FONTE: se la risposta usa informazioni dei DOCUMENTI PDF, nomina il documento fra virgolette in modo naturale, con parole nella lingua dell'utente.\n";
        }
        // Citare il messaggio fa riconoscere la lingua al modello meglio di una regola astratta (prompt e contenuti sono in italiano)
        $last_msg = $pdf_query !== '' ? mb_substr((string) strtok($pdf_query, "\n"), 0, 200) : '';
        $prompt .= "LINGUA: scrivi TUTTA la risposta, ogni frase compresa la citazione della fonte e la domanda finale, nella lingua dell'ultimo messaggio dell'utente"
                 . ($last_msg !== '' ? " (\"" . str_replace('"', "'", $last_msg) . "\")" : '')
                 . ($this->reply_language !== '' ? ", cioe' in " . $this->reply_language : '')
                 . ", anche quando le informazioni sopra sono in un'altra lingua. Non mescolare le lingue.\n";

        return $prompt;
    }

    /**
     * Fallback locale quando l'AI non e' configurata o fallisce. Neutro rispetto al
     * settore: usa solo dati del sito e delle impostazioni (FAQ, servizi, team,
     * recapiti). Restituisce '' se non ha nulla di sensato da dire.
     */
    public function get_local_fallback($intent, $message = '') {
        $msg  = mb_strtolower(trim((string) $message));
        $co   = Ticino_AI_Booking_Dynamic_Site_Knowledge::get_company_info();
        $name = $co['name'] !== '' ? $co['name'] : get_bloginfo('name');

        $contacts = $this->contacts_line($co);

        // 1. Dati strutturati delle impostazioni: hanno la precedenza sulle FAQ
        if ($intent === 'team') {
            $team = Ticino_AI_Booking_Dynamic_Site_Knowledge::get_team_members();
            if (!empty($team)) {
                $res = "Il team di {$name} è composto da:\n";
                foreach ($team as $m) {
                    $details = array_filter(array($m['role'], $m['title']));
                    $res .= "• **{$m['name']}**" . (!empty($details) ? " - " . implode(', ', $details) : '') . "\n";
                }
                return $res . "Siamo a tua disposizione: chiedi pure qui in chat o contattaci.";
            }
        }
        if ($intent === 'orari' && $co['hours'] !== '') {
            return "Gli orari di {$name}: {$co['hours']}" . ($co['hours_note'] !== '' ? " ({$co['hours_note']})" : '');
        }
        if ($intent === 'sede' && $co['address'] !== '') {
            return "{$name} si trova in {$co['address']}." . ($contacts !== '' ? "\n" . $contacts : '');
        }
        if ($intent === 'contatti' && $contacts !== '') {
            return "Puoi contattare {$name} così:\n" . $contacts;
        }

        // 2. FAQ della Knowledge Base (almeno due parole chiave in comune)
        $faq_answer = $this->match_faq($msg);
        if ($faq_answer !== '') {
            return $faq_answer;
        }

        switch ($intent) {
            case 'team':
                return "Il team di {$name} è a tua disposizione. " . $contacts;

            case 'orari':
                return "Non ho gli orari aggiornati a disposizione. " . $contacts;

            case 'sede':
                return "Non ho l'indirizzo a disposizione. " . $contacts;

            case 'contatti':
                return "Puoi contattarci tramite il modulo del sito o lasciando una richiesta qui in chat.";

            case 'prezzi':
            case 'servizi':
                $services = Ticino_AI_Booking_Dynamic_Site_Knowledge::get_services();
                if (!empty($services)) {
                    $matched = array();
                    foreach ($services as $sv) {
                        if ($msg !== '' && mb_stripos($msg, mb_strtolower($sv['name'])) !== false) {
                            $matched[] = $sv;
                        }
                    }
                    $list = !empty($matched) ? $matched : array_slice($services, 0, 12);
                    $res  = !empty($matched) ? "Ecco cosa posso dirti:\n" : "Questi sono alcuni dei servizi di {$name}:\n";
                    foreach ($list as $sv) {
                        $bits = array_filter(array($sv['duration'], $sv['price']));
                        $res .= "• **{$sv['name']}**" . (!empty($bits) ? " (" . implode(', ', $bits) . ")" : '') . "\n";
                        if (!empty($matched) && $sv['description'] !== '') {
                            $res .= "  " . wp_trim_words($sv['description'], 45) . "\n";
                        }
                    }
                    if (empty($matched) && count($services) > 12) {
                        $res .= "...e altri " . (count($services) - 12) . ". Chiedimi pure di uno in particolare.\n";
                    }
                    return $res . (self::lead_mode() ? "Vuoi lasciare una richiesta di informazioni o di preventivo?" : "Vuoi richiedere un appuntamento o maggiori informazioni?");
                }
                return "Per informazioni dettagliate su servizi e prezzi ti invito a consultare il sito o a contattarci. " . $contacts;

            case 'booking':
                if (self::lead_mode()) {
                    return "Posso raccogliere la tua richiesta: scrivi \"Vorrei informazioni\" oppure usa il bottone qui sotto e ti farò alcune brevi domande. {$name} ti ricontatterà al più presto.";
                }
                return "Posso raccogliere la tua richiesta: scrivi \"Vorrei prenotare\" oppure usa il bottone qui sotto e ti farò alcune brevi domande. {$name} ti ricontatterà per confermare.";

            case 'promozioni':
                $promo_t = get_option('ticinoweb_promozioni_title', '');
                $promo_x = get_option('ticinoweb_promozioni_text', '');
                if (!get_option('ticinoweb_disable_promozioni') && ($promo_t !== '' || $promo_x !== '')) {
                    return trim("Promozione attiva: **{$promo_t}**\n" . wp_strip_all_tags($promo_x));
                }
                return "Al momento non ho informazioni su promozioni attive. " . $contacts;
        }

        // generic / prodotti
        if (self::lead_mode()) {
            return "In questo momento non riesco a consultare l'assistente intelligente. Posso comunque raccogliere la tua richiesta di informazioni o preventivo (scrivi \"Vorrei informazioni\") oppure puoi contattare direttamente {$name}." . ($contacts !== '' ? "\n" . $contacts : '');
        }
        return "In questo momento non riesco a consultare l'assistente intelligente. Posso comunque raccogliere una richiesta di appuntamento (scrivi \"Vorrei prenotare\") oppure puoi contattare direttamente {$name}." . ($contacts !== '' ? "\n" . $contacts : '');
    }

    /** Cerca nella FAQ della Knowledge Base la domanda piu' simile al messaggio (parole chiave >= 4 lettere). */
    private function match_faq($msg) {
        if ($msg === '') return '';
        $faqs = json_decode(get_option('ticino_ai_kb_faq', '[]'), true);
        if (empty($faqs) || !is_array($faqs)) return '';
        $stop  = array('come','cosa','quale','quali','dove','quando','posso','sono','della','delle','degli','nella','nelle','anche','avete','fate','siete','vorrei','voglio','sapere','info','informazioni');
        $words = array_diff(array_filter(preg_split('/[^\p{L}\p{N}]+/u', $msg), function ($w) { return mb_strlen($w) >= 4; }), $stop);
        if (count($words) === 0) return '';
        $best = ''; $best_score = 0;
        foreach ($faqs as $f) {
            $q = mb_strtolower((string) ($f['q'] ?? ''));
            $a = (string) ($f['a'] ?? '');
            if ($q === '' || $a === '') continue;
            $score = 0;
            foreach ($words as $w) {
                if (mb_strpos($q, $w) !== false) $score++;
            }
            if ($score > $best_score) { $best_score = $score; $best = $a; }
        }
        return $best_score >= 2 ? $best : '';
    }

    private function contacts_line($co) {
        $parts = array();
        if ($co['phone'] !== '') $parts[] = "Telefono: {$co['phone']}";
        if ($co['email'] !== '') $parts[] = "Email: {$co['email']}";
        if ($co['address'] !== '') $parts[] = "Indirizzo: {$co['address']}";
        return implode("\n", $parts);
    }

    public function generate_content_raw($system_instruction, $user_prompt) {
        return $this->call_llm(
            $system_instruction,
            array(array('role' => 'user', 'content' => (string) $user_prompt)),
            0.7,
            2048,
            45
        );
    }
}
