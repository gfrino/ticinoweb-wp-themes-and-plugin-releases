<?php
/**
 * Documenti PDF nella Knowledge Base (1.4.0).
 *
 * L'amministratore sceglie un PDF dalla libreria media (o lo carica da li').
 * Il testo viene estratto UNA volta (libreria smalot/pdfparser, inclusa in
 * lib/pdfparser, LGPL-3.0), diviso in pezzi di circa 1200 caratteri pagina per
 * pagina e salvato nella tabella {prefix}ticino_ai_kb_chunks del sito corrente.
 * Se il provider AI ha una chiave, ogni pezzo riceve anche un embedding
 * (Gemini o OpenAI) per la ricerca semantica, che funziona anche quando la
 * domanda e' in una lingua diversa da quella del PDF.
 *
 * A ogni domanda: se tutti i documenti insieme sono corti entrano interi nel
 * prompt (nessuna chiamata extra); altrimenti si scelgono i pezzi piu'
 * pertinenti (embedding se disponibili, altrimenti parole chiave). Ogni pezzo
 * porta nome del documento e pagina, cosi' l'AI puo' citare la fonte.
 *
 * @package Ticino_AI_Booking
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Ticino_AI_Booking_PDF_Knowledge {

    const DB_VERSION        = '1';
    const DB_VERSION_OPTION = 'ticino_ai_pdf_db_version';
    const DOCS_OPTION       = 'ticino_ai_kb_documents';
    const TABLE             = 'ticino_ai_kb_chunks';

    const CHUNK_CHARS   = 1200;  // lunghezza indicativa di un pezzo
    const CHUNK_OVERLAP = 150;   // sovrapposizione fra pezzi consecutivi della stessa pagina
    const FULL_BUDGET   = 16000; // sotto questa soglia (tutti i documenti) il testo va intero nel prompt
    const SEARCH_BUDGET = 9000;  // caratteri di pezzi pertinenti passati al modello per domanda
    const MAX_DOC_CHARS = 600000;
    const MAX_CHUNKS    = 2000;  // tetto per sito: tiene leggera la ricerca a ogni domanda
    const MIN_TEXT      = 80;    // meno di cosi' = PDF senza testo (scansione)
    const EMBED_DIMS    = 768;

    /** Limite di dimensione del file, modificabile con il filtro `ticino_ai_pdf_max_bytes`. */
    public static function max_bytes() {
        return (int) apply_filters('ticino_ai_pdf_max_bytes', 20 * MB_IN_BYTES);
    }

    public static function table() {
        global $wpdb;
        return $wpdb->prefix . self::TABLE;
    }

    /**
     * Crea/aggiorna la tabella del sito corrente. Gira all'attivazione e, per i
     * siti gia' attivi o attivati in rete, al primo caricamento dopo l'aggiornamento.
     */
    public static function install() {
        global $wpdb;
        $table = self::table();
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE $table (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            attachment_id bigint(20) unsigned NOT NULL,
            chunk_index int(11) unsigned NOT NULL,
            page int(11) unsigned NOT NULL DEFAULT 0,
            content mediumtext NOT NULL,
            embedding mediumtext NULL,
            PRIMARY KEY  (id),
            KEY attachment_id (attachment_id)
        ) $charset_collate;";
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
        update_option(self::DB_VERSION_OPTION, self::DB_VERSION, true);
    }

    public static function maybe_upgrade() {
        if (get_option(self::DB_VERSION_OPTION) !== self::DB_VERSION) {
            self::install();
        }
    }

    /** @return array<int, array> documenti indicizzati, chiave = ID allegato */
    public static function get_documents() {
        $docs = get_option(self::DOCS_OPTION, array());
        return is_array($docs) ? $docs : array();
    }

    private static function save_documents($docs) {
        // Non autoload: serve solo nella pagina Knowledge Base e nelle risposte del chatbot
        update_option(self::DOCS_OPTION, $docs, false);
    }

    /* ------------------------------------------------------------------ */
    /*  AJAX (Knowledge Base)                                              */
    /* ------------------------------------------------------------------ */

    private static function check_request() {
        check_ajax_referer('ticino_ai_admin_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Non hai i permessi per modificare la Knowledge Base.', 'ticino-ai-booking')), 403);
        }
        return isset($_POST['attachment_id']) ? absint($_POST['attachment_id']) : 0;
    }

    /** Aggiunge (o rilegge) un PDF della libreria media. */
    public function ajax_add() {
        $attachment_id = self::check_request();
        $result = self::index_attachment($attachment_id);
        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()));
        }
        wp_send_json_success(array(
            'document' => self::document_for_js($attachment_id, $result),
            'message'  => sprintf(
                /* translators: 1: nome del documento, 2: numero di pagine */
                _n('«%1$s» è stato letto: %2$d pagina. L\'assistente ora può usarlo per rispondere.', '«%1$s» è stato letto: %2$d pagine. L\'assistente ora può usarlo per rispondere.', (int) $result['pages'], 'ticino-ai-booking'),
                $result['title'], $result['pages']
            ),
            'summary'  => self::summary(),
        ));
    }

    /** Toglie un PDF dalla Knowledge Base (il file resta nella libreria media). */
    public function ajax_remove() {
        $attachment_id = self::check_request();
        $docs = self::get_documents();
        $title = isset($docs[$attachment_id]['title']) ? $docs[$attachment_id]['title'] : '';
        self::remove_document($attachment_id);
        wp_send_json_success(array(
            'message' => sprintf(
                /* translators: %s: nome del documento */
                __('«%s» è stato tolto dalla Knowledge Base. Il file resta nella libreria media.', 'ticino-ai-booking'),
                $title
            ),
            'summary' => self::summary(),
        ));
    }

    /** Anteprima: quali passaggi userebbe l'assistente per una domanda. */
    public function ajax_search() {
        check_ajax_referer('ticino_ai_admin_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Non hai i permessi per modificare la Knowledge Base.', 'ticino-ai-booking')), 403);
        }
        $q = isset($_POST['q']) ? sanitize_text_field(wp_unslash($_POST['q'])) : '';
        if ($q === '') {
            wp_send_json_error(array('message' => __('Scrivi una domanda da provare.', 'ticino-ai-booking')));
        }
        $found = self::search($q, 3, true);
        $out = array();
        foreach ($found['chunks'] as $c) {
            $out[] = array(
                'title' => $c['title'],
                'page'  => (int) $c['page'],
                'text'  => mb_substr($c['content'], 0, 420) . (mb_strlen($c['content']) > 420 ? '…' : ''),
            );
        }
        wp_send_json_success(array('results' => $out, 'method' => $found['method']));
    }

    /** Un allegato cancellato dalla libreria media esce anche dalla Knowledge Base. */
    public static function on_delete_attachment($post_id) {
        $docs = self::get_documents();
        if (isset($docs[(int) $post_id])) {
            self::remove_document((int) $post_id);
        }
    }

    public static function remove_document($attachment_id) {
        global $wpdb;
        $wpdb->delete(self::table(), array('attachment_id' => (int) $attachment_id), array('%d'));
        $docs = self::get_documents();
        unset($docs[(int) $attachment_id]);
        self::save_documents($docs);
    }

    /* ------------------------------------------------------------------ */
    /*  Indicizzazione                                                     */
    /* ------------------------------------------------------------------ */

    /**
     * Controlla il file, estrae il testo, lo divide in pezzi e lo salva.
     *
     * @return array|WP_Error metadati del documento
     */
    public static function index_attachment($attachment_id) {
        global $wpdb;

        $post = $attachment_id ? get_post($attachment_id) : null;
        if (!$post || $post->post_type !== 'attachment') {
            return new WP_Error('not_found', __('Il file scelto non esiste più nella libreria media.', 'ticino-ai-booking'));
        }
        $file = get_attached_file($attachment_id);
        $ext  = strtolower(pathinfo((string) $file, PATHINFO_EXTENSION));
        if ($post->post_mime_type !== 'application/pdf' || $ext !== 'pdf') {
            return new WP_Error('not_pdf', __('Si possono aggiungere solo file PDF.', 'ticino-ai-booking'));
        }
        if (!$file || !is_readable($file)) {
            return new WP_Error('missing_file', __('Il file PDF non si trova sul server: caricalo di nuovo nella libreria media.', 'ticino-ai-booking'));
        }
        $size = (int) filesize($file);
        if ($size > self::max_bytes()) {
            return new WP_Error('too_big', sprintf(
                /* translators: 1: dimensione del file, 2: dimensione massima */
                __('Il PDF pesa %1$s: il massimo è %2$s. Dividilo in più file o comprimilo e riprova.', 'ticino-ai-booking'),
                size_format($size), size_format(self::max_bytes())
            ));
        }
        $fh = fopen($file, 'rb');
        $head = $fh ? fread($fh, 1024) : '';
        if ($fh) fclose($fh);
        if (strpos((string) $head, '%PDF-') === false) {
            return new WP_Error('not_pdf', __('Il file ha estensione .pdf ma non è un PDF valido.', 'ticino-ai-booking'));
        }

        $pages = self::extract_pages($file);
        if (is_wp_error($pages)) {
            return $pages;
        }
        $total_chars = 0;
        foreach ($pages as $p) $total_chars += mb_strlen($p);
        $all_text = implode(' ', $pages);
        if ($total_chars < self::MIN_TEXT || !self::looks_readable($all_text)) {
            return new WP_Error('no_text', __('Questo PDF non contiene testo leggibile: probabilmente è una scansione o un\'immagine. L\'assistente non può leggerlo. Esporta il documento dal programma originale (Word, InDesign…) come PDF con testo, oppure passalo in un programma di riconoscimento del testo (OCR) e caricalo di nuovo.', 'ticino-ai-booking'));
        }

        $chunks = self::chunk_pages($pages);
        $existing = 0;
        foreach (self::get_documents() as $id => $d) {
            if ((int) $id !== (int) $attachment_id) $existing += (int) ($d['chunks'] ?? 0);
        }
        if ($existing + count($chunks) > self::MAX_CHUNKS) {
            return new WP_Error('too_much', __('La Knowledge Base ha raggiunto il limite di testo dai PDF. Togli un documento che non serve più e riprova.', 'ticino-ai-booking'));
        }

        // Embedding (facoltativi): se falliscono la ricerca usa le parole chiave
        $embed_model = '';
        $vectors = self::embed(wp_list_pluck($chunks, 'content'), 'document', $embed_model);
        if (is_wp_error($vectors)) {
            if ($vectors->get_error_code() !== 'no_key') Ticino_AI_Booking_Chatbot::log_error('PDF: embedding non disponibili (' . $vectors->get_error_message() . '), ricerca per parole chiave.');
            $vectors = array();
            $embed_model = '';
        }

        $table = self::table();
        $wpdb->delete($table, array('attachment_id' => (int) $attachment_id), array('%d'));
        foreach ($chunks as $i => $c) {
            $wpdb->insert($table, array(
                'attachment_id' => (int) $attachment_id,
                'chunk_index'   => $i,
                'page'          => (int) $c['page'],
                'content'       => $c['content'],
                'embedding'     => isset($vectors[$i]) ? self::pack_vector($vectors[$i]) : null,
            ), array('%d', '%d', '%d', '%s', '%s'));
        }

        $title = trim(wp_strip_all_tags($post->post_title)); // grezzo: get_the_title() aggiunge entita' HTML (&#8211;)
        if ($title === '') $title = wp_basename($file);
        $doc = array(
            'title'       => $title,
            'file'        => wp_basename($file),
            'size'        => $size,
            'pages'       => count($pages),
            'chars'       => min($total_chars, self::MAX_DOC_CHARS),
            'chunks'      => count($chunks),
            'embed_model' => $embed_model,
            'indexed_at'  => current_time('mysql'),
        );
        $docs = self::get_documents();
        $docs[(int) $attachment_id] = $doc;
        self::save_documents($docs);
        return $doc;
    }

    /** @return string[]|WP_Error testo di ogni pagina */
    private static function extract_pages($file) {
        self::load_parser();
        if (function_exists('wp_raise_memory_limit')) wp_raise_memory_limit('admin');
        if (function_exists('set_time_limit')) @set_time_limit(300);
        try {
            $config = new \Smalot\PdfParser\Config();
            $config->setRetainImageContent(false); // le immagini non servono e pesano in memoria
            $parser = new \Smalot\PdfParser\Parser(array(), $config);
            $pdf = $parser->parseFile($file);
            $pages = array();
            $total = 0;
            foreach ($pdf->getPages() as $page) {
                $text = self::clean_text($page->getText());
                $total += mb_strlen($text);
                if ($total > self::MAX_DOC_CHARS) break;
                $pages[] = $text;
            }
            return $pages;
        } catch (\Throwable $e) {
            $msg = $e->getMessage();
            Ticino_AI_Booking_Chatbot::log_error('PDF non leggibile (' . wp_basename($file) . '): ' . $msg);
            if (stripos($msg, 'secured') !== false || stripos($msg, 'encrypt') !== false) {
                return new WP_Error('encrypted', __('Il PDF è protetto da password o cifrato. Salvane una copia senza protezione e caricala di nuovo.', 'ticino-ai-booking'));
            }
            return new WP_Error('parse_error', __('Non è stato possibile leggere questo PDF (file danneggiato o formato non supportato). Prova a salvarlo di nuovo come PDF e a ricaricarlo.', 'ticino-ai-booking'));
        }
    }

    private static function load_parser() {
        if (class_exists('\Smalot\PdfParser\Parser')) {
            return; // gia' caricata da un altro plugin
        }
        spl_autoload_register(function ($class) {
            if (strpos($class, 'Smalot\\PdfParser\\') !== 0) return;
            $path = TICINO_AI_BOOKING_PLUGIN_DIR . 'lib/pdfparser/src/' . str_replace('\\', '/', $class) . '.php';
            if (is_readable($path)) require_once $path;
        });
    }

    private static function clean_text($text) {
        $text = (string) $text;
        if (!mb_check_encoding($text, 'UTF-8')) {
            $text = mb_convert_encoding($text, 'UTF-8', 'UTF-8');
        }
        $text = preg_replace('/[^\P{C}\n\t]/u', ' ', $text);   // caratteri di controllo
        $text = preg_replace('/(\p{L})-\s*\n\s*(\p{Ll})/u', '$1$2', $text); // parole spezzate a fine riga
        $text = preg_replace('/[ \t\x{00A0}]+/u', ' ', $text);
        $text = preg_replace('/\s*\n\s*/u', "\n", $text);
        $text = preg_replace('/\n{3,}/', "\n\n", $text);
        return trim((string) $text);
    }

    /** Testo vero o simboli senza senso (font senza mappa dei caratteri)? */
    private static function looks_readable($text) {
        $sample = mb_substr(preg_replace('/\s+/u', '', $text), 0, 5000);
        $len = mb_strlen($sample);
        if ($len === 0) return false;
        $letters = preg_match_all('/[\p{L}\p{N}]/u', $sample);
        return ($letters / $len) > 0.5;
    }

    /** @return array<int, array{page:int, content:string}> */
    private static function chunk_pages($pages) {
        $chunks = array();
        foreach ($pages as $i => $text) {
            if ($text === '') continue;
            $page = $i + 1;
            $len = mb_strlen($text);
            $start = 0;
            while ($start < $len) {
                $piece = mb_substr($text, $start, self::CHUNK_CHARS);
                $end = $start + mb_strlen($piece);
                if ($end < $len) {
                    // chiudi su fine paragrafo o frase, se ce n'e' una nella seconda meta' del pezzo
                    $cut = max(mb_strrpos($piece, "\n") ?: 0, mb_strrpos($piece, '. ') ?: 0);
                    if ($cut > self::CHUNK_CHARS / 2) {
                        $piece = mb_substr($piece, 0, $cut + 1);
                        $end = $start + $cut + 1;
                    }
                }
                $piece = trim($piece);
                if (mb_strlen($piece) >= 20) {
                    $chunks[] = array('page' => $page, 'content' => $piece);
                }
                if ($end >= $len) break;
                $start = max($end - self::CHUNK_OVERLAP, $start + 1);
                // il pezzo successivo parte da inizio parola, non a meta'
                $space = mb_strpos(mb_substr($text, $start, 40), ' ');
                if ($space !== false && $start + $space + 1 < $end) $start += $space + 1;
            }
        }
        return $chunks;
    }

    /* ------------------------------------------------------------------ */
    /*  Embedding (Gemini / OpenAI, provider attivo)                       */
    /* ------------------------------------------------------------------ */

    /** Modello di embedding del provider attivo, '' se manca la chiave. */
    public static function active_embed_model() {
        if (Ticino_AI_Booking_Gemini_Client::get_active_provider() === 'openai') {
            return get_option('ticino_ai_openai_api_key') ? 'openai:text-embedding-3-small' : '';
        }
        return get_option('ticino_ai_gemini_api_key') ? 'gemini:gemini-embedding-001' : '';
    }

    /**
     * @param string[] $texts
     * @param string   $kind 'document' | 'query'
     * @param string   $model_out modello usato
     * @return array<int, float[]>|WP_Error
     */
    private static function embed($texts, $kind, &$model_out) {
        $model_out = self::active_embed_model();
        if ($model_out === '' || empty($texts)) {
            return new WP_Error('no_key', 'chiave API assente');
        }
        $vectors = array();
        foreach (array_chunk($texts, 90) as $batch) {
            $res = strpos($model_out, 'openai:') === 0
                ? self::embed_openai($batch)
                : self::embed_gemini($batch, $kind);
            if (is_wp_error($res)) return $res;
            foreach ($res as $v) $vectors[] = self::normalize($v);
        }
        return count($vectors) === count($texts) ? $vectors : new WP_Error('embed_count', 'risposta incompleta');
    }

    private static function embed_gemini($batch, $kind) {
        $requests = array();
        foreach ($batch as $t) {
            $requests[] = array(
                'model'                => 'models/gemini-embedding-001',
                'content'              => array('parts' => array(array('text' => $t))),
                'taskType'             => $kind === 'query' ? 'RETRIEVAL_QUERY' : 'RETRIEVAL_DOCUMENT',
                'outputDimensionality' => self::EMBED_DIMS,
            );
        }
        $resp = wp_remote_post('https://generativelanguage.googleapis.com/v1beta/models/gemini-embedding-001:batchEmbedContents', array(
            'headers' => array('Content-Type' => 'application/json', 'x-goog-api-key' => (string) get_option('ticino_ai_gemini_api_key')),
            'body'    => wp_json_encode(array('requests' => $requests)),
            'timeout' => $kind === 'query' ? 5 : 60, // a ogni domanda: se tarda si ripiega sulle parole chiave
        ));
        if (is_wp_error($resp)) return $resp;
        $body = json_decode(wp_remote_retrieve_body($resp), true);
        if (wp_remote_retrieve_response_code($resp) !== 200 || empty($body['embeddings'])) {
            return new WP_Error('embed_error', $body['error']['message'] ?? ('HTTP ' . wp_remote_retrieve_response_code($resp)));
        }
        return wp_list_pluck($body['embeddings'], 'values');
    }

    private static function embed_openai($batch) {
        $resp = wp_remote_post('https://api.openai.com/v1/embeddings', array(
            'headers' => array('Content-Type' => 'application/json', 'Authorization' => 'Bearer ' . get_option('ticino_ai_openai_api_key')),
            'body'    => wp_json_encode(array('model' => 'text-embedding-3-small', 'input' => array_values($batch), 'dimensions' => self::EMBED_DIMS)),
            'timeout' => count($batch) === 1 ? 5 : 60,
        ));
        if (is_wp_error($resp)) return $resp;
        $body = json_decode(wp_remote_retrieve_body($resp), true);
        if (wp_remote_retrieve_response_code($resp) !== 200 || empty($body['data'])) {
            return new WP_Error('embed_error', $body['error']['message'] ?? ('HTTP ' . wp_remote_retrieve_response_code($resp)));
        }
        return wp_list_pluck($body['data'], 'embedding');
    }

    private static function normalize($v) {
        $norm = 0.0;
        foreach ($v as $x) $norm += $x * $x;
        $norm = sqrt($norm) ?: 1.0;
        return array_map(function ($x) use ($norm) { return $x / $norm; }, $v);
    }

    private static function pack_vector($v) {
        return base64_encode(pack('g*', ...$v));
    }

    private static function unpack_vector($s) {
        $bin = base64_decode((string) $s, true);
        return $bin ? array_values(unpack('g*', $bin)) : array();
    }

    /* ------------------------------------------------------------------ */
    /*  Ricerca e contesto per il prompt                                   */
    /* ------------------------------------------------------------------ */

    /** Totali per l'intestazione della sezione in bacheca. */
    public static function summary() {
        $docs = self::get_documents();
        return array(
            'documents' => count($docs),
            'pages'     => array_sum(wp_list_pluck($docs, 'pages')),
            'chunks'    => array_sum(wp_list_pluck($docs, 'chunks')),
        );
    }

    /**
     * Pezzi pertinenti a una domanda.
     *
     * @param bool $force_search true = sempre ricerca (anteprima in bacheca), anche se tutto starebbe nel prompt
     * @return array{chunks: array, method: string} method: all|semantic|keyword|none
     */
    public static function search($query, $limit = 0, $force_search = false) {
        global $wpdb;
        $docs = self::get_documents();
        if (empty($docs)) return array('chunks' => array(), 'method' => 'none');

        $table = self::table();
        $total_chars = array_sum(wp_list_pluck($docs, 'chars'));
        $with_title = function ($rows) use ($docs) {
            foreach ($rows as &$r) {
                $r['title'] = $docs[(int) $r['attachment_id']]['title'] ?? '';
            }
            return $rows;
        };

        // Documenti corti: tutto il testo, nessuna chiamata di embedding
        if (!$force_search && $total_chars <= self::FULL_BUDGET) {
            $rows = $wpdb->get_results("SELECT attachment_id, chunk_index, page, content FROM $table ORDER BY attachment_id, chunk_index", ARRAY_A);
            return array('chunks' => $with_title(self::dedupe_overlap($rows ?: array())), 'method' => 'all');
        }

        $scores = array();
        $rows = array();
        $method = 'keyword';

        // Semantica solo se tutti i documenti hanno gli embedding del provider attivo.
        // Prima solo i vettori (niente testo), poi il testo dei soli candidati migliori.
        $model = self::active_embed_model();
        $models = array_values(array_unique(wp_list_pluck($docs, 'embed_model')));
        if ($model !== '' && $models === array($model)) {
            $used = '';
            $qv = self::embed(array($query), 'query', $used);
            if (!is_wp_error($qv)) {
                $qv = $qv[0];
                $vectors = $wpdb->get_results("SELECT id, embedding FROM $table WHERE embedding IS NOT NULL", ARRAY_A) ?: array();
                $sem = array();
                foreach ($vectors as $r) {
                    $v = self::unpack_vector($r['embedding']);
                    if (count($v) !== count($qv)) continue;
                    $dot = 0.0;
                    foreach ($qv as $k => $x) $dot += $x * $v[$k];
                    $sem[(int) $r['id']] = $dot;
                }
                unset($vectors);
                if ($sem) {
                    arsort($sem);
                    $ids = array_slice(array_keys($sem), 0, 24);
                    $rows = $wpdb->get_results("SELECT id, attachment_id, chunk_index, page, content FROM $table WHERE id IN (" . implode(',', array_map('intval', $ids)) . ")", ARRAY_A) ?: array();
                    $kw = self::keyword_scores($query, $rows, $docs);
                    $max_kw = max($kw ?: array(0)) ?: 1;
                    foreach ($rows as $i => $r) {
                        $scores[$i] = $sem[(int) $r['id']] + 0.15 * ($kw[$i] / $max_kw);
                    }
                    $method = 'semantic';
                }
            }
        }

        if ($method === 'keyword') {
            $rows = $wpdb->get_results("SELECT id, attachment_id, chunk_index, page, content FROM $table", ARRAY_A) ?: array();
            if (empty($rows)) return array('chunks' => array(), 'method' => 'none');
            $scores = self::keyword_scores($query, $rows, $docs);
        }

        arsort($scores);
        $picked = array();
        $chars = 0;
        foreach ($scores as $i => $score) {
            if ($method === 'keyword' && $score <= 0) break;
            $len = mb_strlen($rows[$i]['content']);
            if ($chars + $len > self::SEARCH_BUDGET && !empty($picked)) break;
            $picked[] = $rows[$i];
            $chars += $len;
            if ($limit && count($picked) >= $limit) break;
        }
        return array('chunks' => $with_title($picked), 'method' => $method);
    }

    /** Toglie la sovrapposizione fra pezzi consecutivi quando li si passa tutti. */
    private static function dedupe_overlap($rows) {
        $prev = null;
        foreach ($rows as &$r) {
            if ($prev && $prev['attachment_id'] === $r['attachment_id'] && $prev['page'] === $r['page']) {
                $tail = mb_substr($prev['content'], -self::CHUNK_OVERLAP);
                $pos = mb_strpos($r['content'], mb_substr($tail, -60));
                if ($pos !== false && $pos < self::CHUNK_OVERLAP + 20) {
                    $r['content'] = ltrim(mb_substr($r['content'], $pos + 60));
                }
            }
            $prev = $r;
        }
        return $rows;
    }

    private static function tokens($text) {
        static $stop = null;
        if ($stop === null) {
            $stop = array_flip(explode(' ', 'che chi con per una uno del della delle dei degli alla alle allo nel nella nelle sul sulla come cosa sono siete avete potete posso quale quali quando dove anche non più the and for are you your what which when where how can does with from that this have des les une pour est que qui dans avec sur pas sont vous der die das und ist ein eine mit für wie was wer wo ich sie nicht'));
        }
        $words = preg_split('/[^\p{L}\p{N}]+/u', mb_strtolower((string) $text), -1, PREG_SPLIT_NO_EMPTY);
        $out = array();
        foreach ($words as $w) {
            if (mb_strlen($w) < 3 || isset($stop[$w])) continue;
            $out[] = mb_strlen($w) > 5 ? mb_substr($w, 0, 5) : $w; // radice grezza: prezzo/prezzi, orario/orari
        }
        return $out;
    }

    /** Punteggio TF-IDF semplice; il nome del documento conta come parte del testo. */
    private static function keyword_scores($query, $rows, $docs) {
        $q = array_unique(self::tokens($query));
        $scores = array_fill_keys(array_keys($rows), 0.0);
        if (empty($q)) return $scores;
        $n = count($rows);
        $df = array_fill_keys($q, 0);
        $tf = array();
        foreach ($rows as $i => $r) {
            $title = $docs[(int) $r['attachment_id']]['title'] ?? '';
            $counts = array_count_values(self::tokens($title . ' ' . $r['content']));
            $tf[$i] = $counts;
            foreach ($q as $t) if (isset($counts[$t])) $df[$t]++;
        }
        foreach ($rows as $i => $r) {
            $s = 0.0;
            foreach ($q as $t) {
                if (empty($tf[$i][$t])) continue;
                $s += (1 + log($tf[$i][$t])) * log(1 + $n / $df[$t]);
            }
            $scores[$i] = $s;
        }
        return $scores;
    }

    /**
     * Sezione del prompt con i passaggi dei PDF pertinenti alla domanda ('' se nessun PDF).
     *
     * @param string $query ultima domanda dell'utente (con quella precedente, per le domande di seguito)
     */
    public static function get_prompt_context($query) {
        $found = self::search($query);
        if (empty($found['chunks'])) {
            return '';
        }
        $out = "=== DOCUMENTI PDF DELL'AZIENDA ===\n"
             . ($found['method'] === 'all'
                ? "Testo dei documenti PDF caricati dall'azienda.\n"
                : "Passaggi dei documenti PDF dell'azienda piu' pertinenti alla domanda.\n")
             . "Quando usi un'informazione da questi documenti, indica da quale documento viene (es. «secondo il documento \"Nome\"»), senza citare numeri di pezzo. "
             . "I documenti possono essere in un'altra lingua: rispondi sempre nella lingua dell'utente. "
             . "Se i documenti non contengono la risposta, non inventarla.\n\n";
        $last = null;
        foreach ($found['chunks'] as $c) {
            $label = '[Documento: "' . $c['title'] . '"' . ($c['page'] ? ', pagina ' . (int) $c['page'] : '') . ']';
            if ($label !== $last) {
                $out .= "\n" . $label . "\n";
                $last = $label;
            }
            $out .= $c['content'] . "\n";
        }
        return $out . "\n";
    }

    /** Dati di una riga dell'elenco in bacheca. */
    public static function document_for_js($attachment_id, $doc) {
        $current = self::active_embed_model();
        return array(
            'id'         => (int) $attachment_id,
            'title'      => $doc['title'],
            'file'       => $doc['file'],
            'url'        => wp_get_attachment_url($attachment_id),
            'size'       => size_format((int) $doc['size']),
            'pages'      => (int) $doc['pages'],
            'chunks'     => (int) $doc['chunks'],
            'indexed_at' => mysql2date(get_option('date_format') . ' H:i', $doc['indexed_at']),
            'smart'      => $current !== '' && $doc['embed_model'] === $current,
        );
    }
}
