<?php

class Ticino_AI_Booking_Admin {

	private $plugin_name;
	private $version;

	public function __construct( $plugin_name, $version ) {
		$this->plugin_name = $plugin_name;
		$this->version = $version;
        add_action('wp_ajax_ticino_test_gemini_key', array($this, 'ajax_test_gemini_key'));
        add_action('wp_ajax_ticino_list_gemini_models', array($this, 'ajax_list_gemini_models'));
        add_action('wp_ajax_ticino_test_openai_key', array($this, 'ajax_test_openai_key'));
        add_action('admin_head', array($this, 'print_menu_icon_css'));
        add_action('wp_ajax_ticino_list_openai_models', array($this, 'ajax_list_openai_models'));
	}

	public function enqueue_styles( $hook ) {
		// Carichiamo gli stili solo sulle nostre pagine
        if ( !isset($_GET['page']) || strpos($_GET['page'], 'ticino-ai-booking') === false ) {
            return;
        }
		wp_enqueue_style( $this->plugin_name, TICINO_AI_BOOKING_PLUGIN_URL . 'assets/css/admin.css', array(), filemtime( TICINO_AI_BOOKING_PLUGIN_DIR . 'assets/css/admin.css' ), 'all' );
	}

	public function enqueue_scripts( $hook ) {
        if ( !isset($_GET['page']) || strpos($_GET['page'], 'ticino-ai-booking') === false ) {
            return;
        }
		wp_enqueue_script( $this->plugin_name, TICINO_AI_BOOKING_PLUGIN_URL . 'assets/js/admin.js', array( 'jquery', 'wp-util' ), filemtime( TICINO_AI_BOOKING_PLUGIN_DIR . 'assets/js/admin.js' ), false );
        
        $qr_defaults = array();
        foreach ( Ticino_AI_Booking_Chatbot::default_quick_replies() as $qr ) {
            $qr_defaults[] = array( $qr['label'], $qr['value'], $qr['action'] );
        }
        wp_localize_script( $this->plugin_name, 'ticino_ai_admin', array(
            'ajax_url'    => admin_url( 'admin-ajax.php' ),
            'nonce'       => wp_create_nonce( 'ticino_ai_admin_nonce' ),
            'qr_defaults' => $qr_defaults,
        ) );
        // Libreria media per scegliere o caricare i PDF della Knowledge Base (1.4.0)
        if ( $_GET['page'] === 'ticino-ai-booking-kb' ) {
            wp_enqueue_media();
        }
	}

	/**
	 * Icona multicolore del menu admin come SVG inline (base64).
	 *
	 * WordPress ripassa le icone SVG del menu con svg-painter.js sostituendo
	 * gli attributi fill e style e le dichiarazioni "fill:...;" con il colore
	 * dello schema admin. Il file usa quindi solo classi CSS senza punto e
	 * virgola e gradienti via stop-color, cosi' i colori restano intatti.
	 */
	private function get_menu_icon() {
		$file = TICINO_AI_BOOKING_PLUGIN_DIR . 'assets/img/menu-icon.svg';
		if ( ! is_readable( $file ) ) {
			return 'dashicons-format-chat';
		}
		$svg = file_get_contents( $file );
		if ( empty( $svg ) ) {
			return 'dashicons-format-chat';
		}
		return 'data:image/svg+xml;base64,' . base64_encode( $svg );
	}

	/** Piena opacita' e resa a 22px per l'icona del menu (core la rende a 20px). */
	public function print_menu_icon_css() {
		echo '<style id="ticino-ai-menu-icon">#adminmenu #toplevel_page_ticino-ai-booking div.wp-menu-image.svg{background-size:22px auto;opacity:1}</style>' . "\n";
	}

	public function add_plugin_admin_menu() {
        // Main Menu (Dashboard)
		add_menu_page(
			'AI WEB Agent',
			'AI WEB Agent',
			'manage_options',
			'ticino-ai-booking',
			array( $this, 'display_dashboard_page' ),
			$this->get_menu_icon(),
			25
		);

        // Submenus
        add_submenu_page(
            'ticino-ai-booking',
            'Dashboard',
            'Dashboard',
            'manage_options',
            'ticino-ai-booking',
            array( $this, 'display_dashboard_page' )
        );

        $requests_label = Ticino_AI_Booking_Chatbot::is_lead_mode() ? 'Richieste' : 'Appuntamenti';
        add_submenu_page(
            'ticino-ai-booking',
            $requests_label,
            $requests_label,
            'manage_options',
            'ticino-ai-booking-appointments',
            array( $this, 'display_appointments_page' )
        );

        add_submenu_page(
            'ticino-ai-booking',
            'Knowledge Base',
            'Knowledge Base',
            'manage_options',
            'ticino-ai-booking-kb',
            array( $this, 'display_kb_page' )
        );

        add_submenu_page(
            'ticino-ai-booking',
            'Email',
            'Email',
            'manage_options',
            'ticino-ai-booking-email',
            array( $this, 'display_email_page' )
        );

        add_submenu_page(
            'ticino-ai-booking',
            'Impostazioni',
            'Impostazioni',
            'manage_options',
            'ticino-ai-booking-settings',
            array( $this, 'display_settings_page' )
        );
	}

    public function register_settings() {
        // 1. Gruppo Impostazioni Generali (templates/admin-settings.php)
        $general_settings = array(
            'ticino_ai_company_name', 'ticino_ai_company_email', 'ticino_ai_company_phone', 'ticino_ai_company_address',
            'ticino_ai_bot_name', 'ticino_ai_bot_greeting', 'ticino_ai_bot_color_main', 'ticino_ai_bot_color_accent', 'ticino_ai_auto_show',
            'ticino_ai_gemini_system_prompt', 'ticino_ai_gemini_api_key', 'ticino_ai_gemini_model', 'ticino_ai_gemini_model_custom',
            'ticino_ai_provider', 'ticino_ai_openai_api_key', 'ticino_ai_openai_model', 'ticino_ai_openai_model_custom',
            'ticino_ai_quick_replies_enabled', 'ticino_ai_booking_intro', 'ticino_ai_company_hours', 'ticino_ai_behavior_rules', 'ticino_ai_currency', 'ticino_ai_response_style',
            'ticino_ai_caldav_enabled', 'ticino_ai_caldav_url', 'ticino_ai_caldav_user', 'ticino_ai_caldav_pass', 'ticino_ai_caldav_calendar_id',
            'ticino_ai_privacy_save_conv', 'ticino_ai_privacy_retention', 'ticino_ai_privacy_text', 'ticino_ai_privacy_link'
        );

        foreach ($general_settings as $setting) {
            register_setting('ticino_ai_booking_settings_group', $setting);
        }
        register_setting('ticino_ai_booking_settings_group', 'ticino_ai_quick_replies', array(
            'type'              => 'string',
            'sanitize_callback' => array('Ticino_AI_Booking_Chatbot', 'sanitize_quick_replies'),
        ));
        // Modalita' (appuntamenti / lead) e messaggio di conferma invio del form (1.2.0)
        register_setting('ticino_ai_booking_settings_group', 'ticino_ai_mode', array(
            'type'              => 'string',
            'default'           => 'booking',
            'sanitize_callback' => array('Ticino_AI_Booking_Chatbot', 'sanitize_mode'),
        ));
        register_setting('ticino_ai_booking_settings_group', 'ticino_ai_booking_success', array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_textarea_field',
        ));

        // 2. Gruppo Knowledge Base (templates/admin-knowledge-base.php)
        $kb_settings = array(
            'ticino_ai_kb_source', 'ticino_ai_kb_company_desc', 'ticino_ai_kb_extra_context', 'ticino_ai_kb_services',
            'ticino_ai_kb_techs', 'ticino_ai_kb_products', 'ticino_ai_kb_faq'
        );

        foreach ($kb_settings as $setting) {
            register_setting('ticino_ai_booking_kb_group', $setting);
        }
        // Post type personalizzati da includere nell'indice dinamico (1.2.0)
        register_setting('ticino_ai_booking_kb_group', 'ticino_ai_kb_post_types', array(
            'type'              => 'array',
            'default'           => array(),
            'sanitize_callback' => array('Ticino_AI_Booking_Dynamic_Site_Knowledge', 'sanitize_post_types'),
        ));

        // 3. Gruppo Email Templates (templates/admin-email.php)
        $email_settings = array(
            'ticino_ai_email_req_subject', 'ticino_ai_email_req_body',
            'ticino_ai_email_conf_subject', 'ticino_ai_email_conf_body',
            'ticino_ai_email_rej_subject', 'ticino_ai_email_rej_body'
        );

        foreach ($email_settings as $setting) {
            register_setting('ticino_ai_booking_email_group', $setting);
        }

        // Auto-heal / Ripristino intelligente se i campi essenziali risultano vuoti
        $this->ensure_default_settings_populated();
    }

    private function ensure_default_settings_populated() {
        // Ripristino se i campi essenziali sono vuoti: solo dati del sito, nessun valore di settore
        if (!get_option('ticino_ai_company_name')) {
            update_option('ticino_ai_company_name', get_option('ticinoweb_site_name', get_bloginfo('name')));
        }
        if (!get_option('ticino_ai_company_email')) {
            update_option('ticino_ai_company_email', get_option('ticinoweb_contact_email', get_option('admin_email')));
        }
        if (!get_option('ticino_ai_bot_name')) {
            update_option('ticino_ai_bot_name', 'Assistente virtuale');
        }
        if (!get_option('ticino_ai_bot_greeting')) {
            update_option('ticino_ai_bot_greeting', Ticino_AI_Booking_Chatbot::default_greeting());
        }
        if (!get_option('ticino_ai_bot_color_main')) {
            update_option('ticino_ai_bot_color_main', '#1a1a1a');
        }
        if (!get_option('ticino_ai_bot_color_accent')) {
            update_option('ticino_ai_bot_color_accent', '#cebdad');
        }
        if (!get_option('ticino_ai_gemini_model')) {
            update_option('ticino_ai_gemini_model', 'gemini-2.0-flash');
        }
        if (!get_option('ticino_ai_provider')) {
            update_option('ticino_ai_provider', 'gemini');
        }
        if (!get_option('ticino_ai_openai_model')) {
            update_option('ticino_ai_openai_model', 'gpt-4.1-mini');
        }
        if (!get_option('ticino_ai_gemini_system_prompt')) {
            update_option('ticino_ai_gemini_system_prompt', Ticino_AI_Booking_Gemini_Client::default_system_prompt());
        }
    }

    public function display_dashboard_page() {
        require_once TICINO_AI_BOOKING_PLUGIN_DIR . 'templates/admin-dashboard.php';
    }

	public function display_appointments_page() {
		require_once TICINO_AI_BOOKING_PLUGIN_DIR . 'templates/admin-appointments.php';
	}

    public function display_kb_page() {
        require_once TICINO_AI_BOOKING_PLUGIN_DIR . 'templates/admin-knowledge-base.php';
    }

    public function display_email_page() {
        require_once TICINO_AI_BOOKING_PLUGIN_DIR . 'templates/admin-email.php';
    }

    public function display_settings_page() {
        require_once TICINO_AI_BOOKING_PLUGIN_DIR . 'templates/admin-settings.php';
    }

	public function ajax_test_gemini_key() {
		check_ajax_referer( 'ticino_ai_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Permessi insufficienti.' );
		}

		$api_key = isset( $_POST['api_key'] ) ? sanitize_text_field( $_POST['api_key'] ) : '';
		if ( empty( $api_key ) ) {
			wp_send_json_error( 'Chiave API mancante.' );
		}

        $model = isset( $_POST['model'] ) ? sanitize_text_field( $_POST['model'] ) : 'gemini-2.0-flash';
        if ( empty( $model ) ) {
            $model = 'gemini-2.0-flash';
        }

		$url = 'https://generativelanguage.googleapis.com/v1beta/models/' . $model . ':generateContent?key=' . $api_key;
		$body = wp_json_encode( array(
			'contents' => array(
				array( 'parts' => array( array( 'text' => 'Rispondi solo con OK' ) ) )
			)
		) );

		$response = wp_remote_post( $url, array(
			'body'    => $body,
			'headers' => array( 'Content-Type' => 'application/json' ),
			'timeout' => 15
		) );

		if ( is_wp_error( $response ) ) {
			wp_send_json_error( 'Errore HTTP: ' . $response->get_error_message() );
		}

		$status = wp_remote_retrieve_response_code( $response );
		$body_json = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( $status === 200 && isset( $body_json['candidates'] ) ) {
			wp_send_json_success( 'Connessione riuscita con il modello ' . $model );
		} else {
			$error_msg = isset( $body_json['error']['message'] ) ? $body_json['error']['message'] : 'Errore sconosciuto (' . $status . ')';
            
            if (stripos($error_msg, 'are blocked') !== false) {
                $error_msg = "<br><br><strong>La richiesta verso Gemini API è bloccata.</strong> La chiave API potrebbe avere restrizioni errate, non essere autorizzata alla Generative Language API, appartenere a un progetto senza API abilitata oppure essere stata bloccata da Google. Controlla in Google Cloud Console: API Key restrictions, Generative Language API abilitata, progetto corretto e billing attivo.<br><br><strong>Checklist per risolvere:</strong><ol style=\"margin-top:5px; margin-left:20px;\"><li>Genera una nuova API Key da Google AI Studio.</li><li>Verifica che sia nel progetto corretto.</li><li>Abilita Generative Language API.</li><li>Rimuovi temporaneamente restrizioni della chiave per test.</li><li>Usa modello gemini-2.5-flash.</li></ol>";
            }
            
			wp_send_json_error( 'Errore API (Modello: ' . $model . '): ' . $error_msg );
		}
	}

    public function ajax_list_gemini_models() {
		check_ajax_referer( 'ticino_ai_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Permessi insufficienti.' );
		}

		$api_key = isset( $_POST['api_key'] ) ? sanitize_text_field( $_POST['api_key'] ) : '';
		if ( empty( $api_key ) ) {
			wp_send_json_error( 'Chiave API mancante.' );
		}

        $url = 'https://generativelanguage.googleapis.com/v1beta/models?key=' . $api_key;
        
        $response = wp_remote_get( $url, array(
			'timeout' => 15
		) );

        if ( is_wp_error( $response ) ) {
			wp_send_json_error( 'Errore HTTP: ' . $response->get_error_message() );
		}

        $status = wp_remote_retrieve_response_code( $response );
		$body_json = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $status === 200 && isset( $body_json['models'] ) ) {
            $supported_models = array();
            foreach ($body_json['models'] as $m) {
                if (isset($m['supportedGenerationMethods']) && in_array('generateContent', $m['supportedGenerationMethods'])) {
                    $supported_models[] = str_replace('models/', '', $m['name']);
                }
            }
            if (empty($supported_models)) {
                wp_send_json_error( 'Nessun modello compatibile con generateContent trovato.' );
            }
            wp_send_json_success( $supported_models );
        } else {
            $error_msg = isset( $body_json['error']['message'] ) ? $body_json['error']['message'] : 'Errore sconosciuto (' . $status . ')';
            
            if (stripos($error_msg, 'are blocked') !== false) {
                $error_msg = "<br><br><strong>La richiesta verso Gemini API è bloccata.</strong> La chiave API potrebbe avere restrizioni errate, non essere autorizzata alla Generative Language API, appartenere a un progetto senza API abilitata oppure essere stata bloccata da Google. Controlla in Google Cloud Console: API Key restrictions, Generative Language API abilitata, progetto corretto e billing attivo.<br><br><strong>Checklist per risolvere:</strong><ol style=\"margin-top:5px; margin-left:20px;\"><li>Genera una nuova API Key da Google AI Studio.</li><li>Verifica che sia nel progetto corretto.</li><li>Abilita Generative Language API.</li><li>Rimuovi temporaneamente restrizioni della chiave per test.</li><li>Usa modello gemini-2.5-flash.</li></ol>";
            }
            
			wp_send_json_error( 'Errore API: ' . $error_msg );
        }
    }

    public function ajax_test_openai_key() {
        check_ajax_referer( 'ticino_ai_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Permessi insufficienti.' );
        }

        $api_key = isset( $_POST['api_key'] ) ? sanitize_text_field( wp_unslash( $_POST['api_key'] ) ) : '';
        if ( empty( $api_key ) ) {
            wp_send_json_error( 'Chiave API mancante.' );
        }
        $model = isset( $_POST['model'] ) ? sanitize_text_field( wp_unslash( $_POST['model'] ) ) : '';
        if ( empty( $model ) ) {
            $model = Ticino_AI_Booking_OpenAI_Client::DEFAULT_MODEL;
        }

        $result = Ticino_AI_Booking_OpenAI_Client::test_key( $api_key, $model );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( 'Errore API (Modello: ' . esc_html( $model ) . '): ' . esc_html( $result->get_error_message() ) );
        }
        wp_send_json_success( 'Connessione riuscita con il modello ' . esc_html( $model ) );
    }

    public function ajax_list_openai_models() {
        check_ajax_referer( 'ticino_ai_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Permessi insufficienti.' );
        }

        $api_key = isset( $_POST['api_key'] ) ? sanitize_text_field( wp_unslash( $_POST['api_key'] ) ) : '';
        if ( empty( $api_key ) ) {
            wp_send_json_error( 'Chiave API mancante.' );
        }

        $models = Ticino_AI_Booking_OpenAI_Client::list_models( $api_key );
        if ( is_wp_error( $models ) ) {
            wp_send_json_error( 'Errore API: ' . esc_html( $models->get_error_message() ) );
        }
        if ( empty( $models ) ) {
            wp_send_json_error( 'Nessun modello chat trovato per questa chiave.' );
        }
        wp_send_json_success( array_map( 'esc_html', $models ) );
    }

}
