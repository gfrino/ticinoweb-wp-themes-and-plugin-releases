<div class="wrap ticino-wrap">
    <div class="ticino-header">
        <div>
            <h1>Impostazioni</h1>
            <p>Configura dati aziendali, chatbot, provider AI (Gemini o OpenAI), notifiche e sincronizzazione Apple Calendar.</p>
        </div>
    </div>
    
    <?php settings_errors(); ?>

    <?php
    $company_name = get_option('ticino_ai_company_name') ?: get_option('ticinoweb_site_name', get_bloginfo('name'));
    $company_email = get_option('ticino_ai_company_email') ?: get_option('ticinoweb_contact_email', get_option('admin_email'));
    $company_phone = get_option('ticino_ai_company_phone') ?: get_option('ticinoweb_contact_phone', '');
    $company_address = get_option('ticino_ai_company_address') ?: wp_strip_all_tags((string) get_option('ticinoweb_contact_address', ''));
    $system_prompt = get_option('ticino_ai_gemini_system_prompt') ?: Ticino_AI_Booking_Gemini_Client::default_system_prompt();
    $behavior_rules = get_option('ticino_ai_behavior_rules') ?: Ticino_AI_Booking_Gemini_Client::default_behavior_rules();
    $mode    = Ticino_AI_Booking_Chatbot::get_mode();
    $is_lead = $mode === 'lead';
    ?>

    <form method="post" action="options.php">
        <?php settings_fields('ticino_ai_booking_settings_group'); ?>
        
        <div class="ticino-tabs-nav">
            <a href="#tab-general" class="ticino-tab-link active">Generale</a>
            <a href="#tab-gemini" class="ticino-tab-link">Modello AI</a>
            <a href="#tab-chatbot" class="ticino-tab-link">Chatbot UI</a>
            <a href="#tab-caldav" class="ticino-tab-link">Apple Calendar</a>
            <a href="#tab-privacy" class="ticino-tab-link">Privacy</a>
        </div>

        <!-- TAB GENERALE -->
        <div id="tab-general" class="ticino-tab-pane active">
            <div class="ticino-card" style="max-width: 800px; margin-bottom: 24px;">
                <div class="ticino-card-title">
                    <span class="dashicons dashicons-randomize"></span> Modalità di funzionamento
                </div>
                <div class="ticino-form-group">
                    <div style="display:flex; flex-direction:column; gap: 10px; margin-top:4px;">
                        <label style="font-weight: normal;">
                            <input type="radio" name="ticino_ai_mode" value="booking" <?php checked($mode, 'booking'); ?>>
                            <strong>Appuntamenti</strong> — il form chiede anche giorno e fascia oraria preferiti; le richieste si confermano o annullano dal pannello e possono essere sincronizzate con Apple Calendar.
                        </label>
                        <label style="font-weight: normal;">
                            <input type="radio" name="ticino_ai_mode" value="lead" <?php checked($mode, 'lead'); ?>>
                            <strong>Generazione contatti (lead)</strong> — il form raccoglie nome, telefono, email, esigenza e note, senza alcuna data. Le richieste si gestiscono come contatti da richiamare («Segna come contattata»); l'assistente non propone appuntamenti né prezzi.
                        </label>
                    </div>
                    <span class="ticino-helper-text">Cambia testi predefiniti (benvenuto, bottoni rapidi, intro e conferma del form, prompt di sistema), il flusso del form in chat e le voci del pannello. I testi già personalizzati nei campi qui sotto restano invariati: svuota un campo per tornare al predefinito della modalità.</span>
                </div>
            </div>
            <div class="ticino-card" style="max-width: 800px;">
                <div class="ticino-card-title">
                    <span class="dashicons dashicons-store"></span> Dati Azienda
                </div>
                <div class="ticino-form-group">
                    <label>Nome Azienda</label>
                    <input type="text" name="ticino_ai_company_name" value="<?php echo esc_attr($company_name); ?>">
                    <span class="ticino-helper-text">Usato nelle email automatiche e come riferimento principale.</span>
                </div>
                <div class="ticino-form-group">
                    <label>Email Notifiche (Admin)</label>
                    <input type="email" name="ticino_ai_company_email" value="<?php echo esc_attr($company_email); ?>">
                    <span class="ticino-helper-text">Indirizzo a cui inviare le notifiche di nuove richieste raccolte dal chatbot; è anche l'email di contatto che l'assistente comunica ai visitatori.</span>
                </div>
                <div class="ticino-form-group">
                    <label>Telefono Azienda</label>
                    <input type="text" name="ticino_ai_company_phone" value="<?php echo esc_attr($company_phone); ?>">
                    <span class="ticino-helper-text">Mostrato al cliente in fase di conferma.</span>
                </div>
                <div class="ticino-form-group">
                    <label>Indirizzo</label>
                    <input type="text" name="ticino_ai_company_address" value="<?php echo esc_attr($company_address); ?>">
                    <span class="ticino-helper-text">Indirizzo fisico del centro per guidare il cliente.</span>
                </div>
                <div class="ticino-form-group">
                    <label>Orari di apertura</label>
                    <input type="text" name="ticino_ai_company_hours" value="<?php echo esc_attr(get_option('ticino_ai_company_hours', '')); ?>" placeholder="Es. Lun-Ven 8:00-12:00 / 13:30-17:30, Sabato chiuso">
                    <span class="ticino-helper-text">Usati dall'assistente per rispondere sugli orari. Se vuoto, l'assistente dirà di non averli e inviterà a contattarvi.</span>
                </div>
                <div class="ticino-form-group">
                    <label>Valuta dei prezzi</label>
                    <input type="text" name="ticino_ai_currency" value="<?php echo esc_attr(get_option('ticino_ai_currency', 'CHF')); ?>" maxlength="5" style="max-width:120px;">
                    <span class="ticino-helper-text">Con WooCommerce attivo vale la valuta del negozio.</span>
                </div>
            </div>
        </div>

        <!-- TAB MODELLO AI (Gemini / OpenAI) -->
        <div id="tab-gemini" class="ticino-tab-pane">
            <div class="ticino-card" style="max-width: 800px;">
                <div class="ticino-card-title">
                    <span class="dashicons dashicons-rest-api"></span> Configurazione Modello AI
                </div>

                <?php
                $provider        = get_option('ticino_ai_provider', 'gemini');
                $provider        = in_array($provider, array('gemini', 'openai'), true) ? $provider : 'gemini';
                $api_key         = get_option('ticino_ai_gemini_api_key');
                $current_model   = get_option('ticino_ai_gemini_model', 'gemini-2.0-flash');
                $openai_key      = get_option('ticino_ai_openai_api_key');
                $openai_model    = get_option('ticino_ai_openai_model', 'gpt-4.1-mini');
                $active_key      = $provider === 'openai' ? $openai_key : $api_key;
                $active_label    = $provider === 'openai' ? 'OpenAI' : 'Gemini';
                ?>

                <div class="ticino-form-group">
                    <label>Provider AI</label>
                    <div style="display:flex; gap: 20px; align-items:center; margin-top:8px;">
                        <label style="font-weight: normal;"><input type="radio" name="ticino_ai_provider" value="gemini" class="ticino-ai-provider-radio" <?php checked($provider, 'gemini'); ?>> Google Gemini</label>
                        <label style="font-weight: normal;"><input type="radio" name="ticino_ai_provider" value="openai" class="ticino-ai-provider-radio" <?php checked($provider, 'openai'); ?>> OpenAI (ChatGPT)</label>
                    </div>
                    <span class="ticino-helper-text">Il provider selezionato viene usato dal chatbot e dagli strumenti AI dell'editor. Le chiavi di entrambi restano salvate: puoi cambiare provider in qualsiasi momento.</span>
                </div>

                <div style="margin-bottom: 20px;">
                    Stato (<?php echo esc_html($active_label); ?>):
                    <span class="ticino-badge <?php echo empty($active_key) ? 'ticino-badge-danger' : 'ticino-badge-success'; ?>">
                        <?php echo empty($active_key) ? 'Non Configurato' : 'Configurato'; ?>
                    </span>
                </div>

                <!-- ===== GEMINI ===== -->
                <div id="ticino-provider-gemini" class="ticino-provider-pane" style="<?php echo $provider === 'gemini' ? '' : 'display:none;'; ?>">
                <?php if ($current_model === 'gemini-1.5-flash') : ?>
                <div class="ticino-alert ticino-alert-warning" style="margin-bottom: 20px; padding: 15px; border-left: 4px solid var(--ticino-warning); background: #fff8e1;">
                    <strong>Attenzione:</strong> Il modello gemini-1.5-flash non sembra più disponibile o aggiornato. Ti consigliamo di usare gemini-2.0-flash.
                    <button type="button" id="update-gemini-2" class="button button-primary" style="margin-left: 15px;">Aggiorna a Gemini 2.0 Flash</button>
                </div>
                <?php endif; ?>

                <div class="ticino-form-group">
                    <label>Gemini API Key</label>
                    <input type="password" name="ticino_ai_gemini_api_key" value="<?php echo esc_attr($api_key); ?>" autocomplete="off">
                    <span class="ticino-helper-text">Non verrà mostrata sul frontend. <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener">Ottieni una chiave qui</a>.</span>
                    <div style="margin-top: 10px; display: flex; align-items: center;">
                        <button type="button" id="test-gemini-key" class="button button-secondary">Test API Key</button>
                        <span id="test-gemini-result" style="margin-left:12px; font-size:13px;"></span>
                    </div>
                </div>
                <div class="ticino-form-group">
                    <label>Modello Gemini</label>
                    <select name="ticino_ai_gemini_model" id="ticino-ai-model-select">
                        <option value="gemini-2.0-flash" <?php selected($current_model, 'gemini-2.0-flash'); ?>>Gemini 2.0 Flash (Consigliato, più veloce)</option>
                        <option value="gemini-2.0-flash-lite" <?php selected($current_model, 'gemini-2.0-flash-lite'); ?>>Gemini 2.0 Flash Lite (Più leggero)</option>
                        <option value="gemini-1.5-flash" <?php selected($current_model, 'gemini-1.5-flash'); ?> style="display:none;">Gemini 1.5 Flash (Deprecato)</option>
                        <option value="gemini-1.5-pro" <?php selected($current_model, 'gemini-1.5-pro'); ?>>Gemini 1.5 Pro (Per ragionamenti complessi)</option>
                        <option value="custom" <?php selected($current_model, 'custom'); ?>>Modello personalizzato</option>
                    </select>
                </div>
                
                <div class="ticino-form-group" id="ticino-ai-custom-model-wrapper" style="<?php echo $current_model === 'custom' ? '' : 'display:none;'; ?>">
                    <label>Nome Modello Personalizzato</label>
                    <input type="text" name="ticino_ai_gemini_model_custom" id="ticino-ai-custom-model" value="<?php echo esc_attr(get_option('ticino_ai_gemini_model_custom')); ?>">
                    <span class="ticino-helper-text">Inserisci il nome esatto del modello (es. gemini-2.5-pro).</span>
                </div>
                
                <div style="margin-bottom: 20px;">
                    <button type="button" id="check-gemini-models" class="button button-secondary">Verifica modelli disponibili</button>
                    <div id="check-gemini-models-result" style="margin-top: 10px;"></div>
                </div>
                </div><!-- /gemini -->

                <!-- ===== OPENAI ===== -->
                <div id="ticino-provider-openai" class="ticino-provider-pane" style="<?php echo $provider === 'openai' ? '' : 'display:none;'; ?>">
                <div class="ticino-form-group">
                    <label>OpenAI API Key</label>
                    <input type="password" name="ticino_ai_openai_api_key" value="<?php echo esc_attr($openai_key); ?>" autocomplete="off">
                    <span class="ticino-helper-text">Non verrà mostrata sul frontend. <a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener">Ottieni una chiave qui</a>.</span>
                    <div style="margin-top: 10px; display: flex; align-items: center;">
                        <button type="button" id="test-openai-key" class="button button-secondary">Test API Key</button>
                        <span id="test-openai-result" style="margin-left:12px; font-size:13px;"></span>
                    </div>
                </div>
                <div class="ticino-form-group">
                    <label>Modello OpenAI</label>
                    <select name="ticino_ai_openai_model" id="ticino-ai-openai-model-select">
                        <option value="gpt-4.1-mini" <?php selected($openai_model, 'gpt-4.1-mini'); ?>>GPT-4.1 mini (Consigliato: veloce ed economico)</option>
                        <option value="gpt-4.1" <?php selected($openai_model, 'gpt-4.1'); ?>>GPT-4.1 (Più preciso)</option>
                        <option value="gpt-4o-mini" <?php selected($openai_model, 'gpt-4o-mini'); ?>>GPT-4o mini</option>
                        <option value="gpt-4o" <?php selected($openai_model, 'gpt-4o'); ?>>GPT-4o</option>
                        <option value="gpt-5-mini" <?php selected($openai_model, 'gpt-5-mini'); ?>>GPT-5 mini (Ragionamento, più lento)</option>
                        <option value="gpt-5" <?php selected($openai_model, 'gpt-5'); ?>>GPT-5 (Ragionamento, più costoso)</option>
                        <option value="custom" <?php selected($openai_model, 'custom'); ?>>Modello personalizzato</option>
                    </select>
                    <span class="ticino-helper-text">Per una chat di assistenza bastano i modelli "mini": rispondono in 1-2 secondi. I modelli GPT-5 ignorano la temperatura e possono impiegare più tempo.</span>
                </div>

                <div class="ticino-form-group" id="ticino-ai-openai-custom-model-wrapper" style="<?php echo $openai_model === 'custom' ? '' : 'display:none;'; ?>">
                    <label>Nome Modello Personalizzato</label>
                    <input type="text" name="ticino_ai_openai_model_custom" id="ticino-ai-openai-custom-model" value="<?php echo esc_attr(get_option('ticino_ai_openai_model_custom')); ?>">
                    <span class="ticino-helper-text">Inserisci l'ID esatto del modello (es. gpt-4.1-nano). Usa "Verifica modelli disponibili" per l'elenco.</span>
                </div>

                <div style="margin-bottom: 20px;">
                    <button type="button" id="check-openai-models" class="button button-secondary">Verifica modelli disponibili</button>
                    <div id="check-openai-models-result" style="margin-top: 10px;"></div>
                </div>
                </div><!-- /openai -->

                <div class="ticino-form-group">
                    <label>System Prompt (Tono di voce e Istruzioni Base, comune a Gemini e OpenAI)</label>
                    <textarea name="ticino_ai_gemini_system_prompt" rows="12"><?php echo esc_textarea($system_prompt); ?></textarea>
                    <span class="ticino-helper-text">Chi è l'assistente e come deve rispondere. Le informazioni su azienda, servizi, team e pagine vengono aggiunte automaticamente dalla Knowledge Base (il sito stesso).</span>
                </div>
                <div class="ticino-form-group">
                    <label>Stile di risposta</label>
                    <?php $cur_style = get_option('ticino_ai_response_style', 'breve'); ?>
                    <select name="ticino_ai_response_style">
                        <?php foreach (Ticino_AI_Booking_Gemini_Client::response_styles() as $k => $st) : ?>
                            <option value="<?php echo esc_attr($k); ?>" <?php selected($cur_style, $k); ?>><?php echo esc_html($st['label']); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <span class="ticino-helper-text">Controlla lunghezza e tono delle risposte. Ha la precedenza sulle regole sotto: con «Breve» l'assistente risponde in 3-4 frasi e limita i token generati, quindi risponde anche più in fretta.</span>
                </div>
                <div class="ticino-form-group">
                    <label>Regole di comportamento</label>
                    <textarea name="ticino_ai_behavior_rules" rows="10"><?php echo esc_textarea($behavior_rules); ?></textarea>
                    <span class="ticino-helper-text">Aggiunte in coda al prompt dopo la conoscenza del sito: fedeltà ai contenuti, cosa fare se manca un'informazione, tono, avvisi obbligatori (es. politica di cancellazione), servizi che NON offrite. Una regola per riga.</span>
                </div>
            </div>
        </div>

        <!-- TAB CHATBOT UI -->
        <div id="tab-chatbot" class="ticino-tab-pane">
            <div class="ticino-card" style="max-width: 800px;">
                <div class="ticino-card-title">
                    <span class="dashicons dashicons-format-chat"></span> Aspetto del Chatbot
                </div>
                
                <div class="ticino-form-group">
                    <label>Mostra il widget flottante su tutte le pagine</label>
                    <span class="ticino-helper-text">La chat si apre solo al click sull'icona.</span>
                    <div style="display:flex; gap: 20px; align-items:center; margin-top:8px;">
                        <label style="font-weight: normal;"><input type="radio" name="ticino_ai_auto_show" value="yes" <?php checked(get_option('ticino_ai_auto_show'), 'yes'); ?>> Sì (In basso a destra)</label>
                        <label style="font-weight: normal;"><input type="radio" name="ticino_ai_auto_show" value="no" <?php checked(get_option('ticino_ai_auto_show'), 'no'); ?>> No (Usa lo shortcode <code>[ticino_ai_booking_chatbot]</code>)</label>
                    </div>
                </div>
                <hr style="border: 0; border-top: 1px solid var(--ticino-border); margin: 24px 0;">
                
                <div class="ticino-form-group">
                    <label>Nome Assistente</label>
                    <input type="text" name="ticino_ai_bot_name" value="<?php echo esc_attr(get_option('ticino_ai_bot_name')); ?>">
                    <span class="ticino-helper-text">Nome visualizzato nell'header della chat.</span>
                </div>
                <div class="ticino-form-group">
                    <label>Messaggio di Benvenuto</label>
                    <textarea name="ticino_ai_bot_greeting" rows="3"><?php echo esc_textarea(get_option('ticino_ai_bot_greeting')); ?></textarea>
                    <span class="ticino-helper-text">Il primissimo messaggio mostrato all'apertura della chat.</span>
                </div>
                
                <div style="display:flex; gap: 24px;">
                    <div class="ticino-form-group">
                        <label>Colore Principale</label>
                        <input type="color" name="ticino_ai_bot_color_main" value="<?php echo esc_attr(get_option('ticino_ai_bot_color_main', '#1a1a1a')); ?>" style="height: 40px; padding: 2px;">
                    </div>
                    <div class="ticino-form-group">
                        <label>Colore Accento (Pulsanti)</label>
                        <input type="color" name="ticino_ai_bot_color_accent" value="<?php echo esc_attr(get_option('ticino_ai_bot_color_accent', '#cebdad')); ?>" style="height: 40px; padding: 2px;">
                    </div>
                </div>
            </div>

            <!-- BOTTONI RAPIDI -->
            <?php
            $qr_enabled = get_option('ticino_ai_quick_replies_enabled', 'yes') !== 'no';
            $qr_list    = Ticino_AI_Booking_Chatbot::get_quick_replies();
            ?>
            <div class="ticino-card" style="max-width: 800px; margin-top: 24px;">
                <div class="ticino-card-title">
                    <span class="dashicons dashicons-button"></span> Bottoni Rapidi
                </div>
                <div class="ticino-form-group">
                    <label>Mostra i bottoni rapidi sotto la chat</label>
                    <div style="display:flex; gap: 20px; align-items:center; margin-top:8px;">
                        <label style="font-weight: normal;"><input type="radio" name="ticino_ai_quick_replies_enabled" value="yes" <?php checked($qr_enabled); ?>> Sì</label>
                        <label style="font-weight: normal;"><input type="radio" name="ticino_ai_quick_replies_enabled" value="no" <?php checked(!$qr_enabled); ?>> No (nascondi tutti)</label>
                    </div>
                    <span class="ticino-helper-text">Sono i suggerimenti cliccabili mostrati quando la chat è in attesa (es. «<?php echo $is_lead ? 'Richiedi informazioni o un preventivo' : 'Vorrei prenotare un appuntamento'; ?>»). I bottoni interni al form (<?php echo $is_lead ? 'note, conferma' : 'giorno, fascia oraria, conferma'; ?>) restano sempre attivi perché fanno parte del form.</span>
                </div>

                <?php $qr_actions = Ticino_AI_Booking_Chatbot::quick_reply_actions(); ?>
                <div class="ticino-form-group">
                    <label>Elenco bottoni</label>
                    <span class="ticino-helper-text">Spunta «Attivo» per mostrarlo. «Testo» è quello che l'utente vede. «Azione» decide cosa succede al click: <em>Invia all'AI</em> manda il messaggio al modello; <em>Avvia il form</em> apre la raccolta dati per l'appuntamento; <em>Risposta fissa</em> mostra un testo predefinito senza chiamare l'AI; <em>Apri un link</em> apre una pagina in una nuova scheda. Massimo 8.</span>
                    <table class="widefat striped" id="ticino-ai-qr-table" style="margin-top:10px;">
                        <thead>
                            <tr>
                                <th style="width:60px;">Attivo</th>
                                <th style="width:24%;">Testo del bottone</th>
                                <th style="width:20%;">Azione</th>
                                <th>Dettaglio</th>
                                <th style="width:40px;"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($qr_list as $i => $qr) : $act = isset($qr['action']) ? $qr['action'] : 'ai'; ?>
                            <tr class="ticino-ai-qr-row">
                                <td style="text-align:center;"><input type="checkbox" name="ticino_ai_quick_replies[<?php echo (int) $i; ?>][enabled]" value="1" <?php checked(!empty($qr['enabled'])); ?>></td>
                                <td><input type="text" name="ticino_ai_quick_replies[<?php echo (int) $i; ?>][label]" value="<?php echo esc_attr($qr['label']); ?>" maxlength="60" style="width:100%;"></td>
                                <td>
                                    <select name="ticino_ai_quick_replies[<?php echo (int) $i; ?>][action]" class="ticino-ai-qr-action" style="width:100%;">
                                        <?php foreach ($qr_actions as $key => $lab) : ?>
                                            <option value="<?php echo esc_attr($key); ?>" <?php selected($act, $key); ?>><?php echo esc_html($lab); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                                <td>
                                    <input type="text" class="ticino-ai-qr-detail" data-for="ai" name="ticino_ai_quick_replies[<?php echo (int) $i; ?>][value]" value="<?php echo esc_attr($qr['value']); ?>" maxlength="200" style="width:100%;" placeholder="Messaggio inviato all'AI (vuoto = usa il testo)">
                                    <textarea class="ticino-ai-qr-detail" data-for="reply" name="ticino_ai_quick_replies[<?php echo (int) $i; ?>][reply]" rows="2" maxlength="1000" style="width:100%;" placeholder="Testo della risposta fissa"><?php echo esc_textarea(isset($qr['reply']) ? $qr['reply'] : ''); ?></textarea>
                                    <input type="url" class="ticino-ai-qr-detail" data-for="link" name="ticino_ai_quick_replies[<?php echo (int) $i; ?>][url]" value="<?php echo esc_attr(isset($qr['url']) ? $qr['url'] : ''); ?>" style="width:100%;" placeholder="https://...">
                                    <span class="ticino-ai-qr-detail ticino-helper-text" data-for="booking">Apre il form: <?php echo $is_lead ? 'nome, telefono, email, richiesta, note (nessuna data)' : 'nome, telefono, email, servizio, giorno, fascia oraria, note'; ?>.</span>
                                </td>
                                <td style="text-align:center;"><button type="button" class="button-link-delete ticino-ai-qr-remove" title="Rimuovi">&times;</button></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <p style="margin-top:10px;">
                        <button type="button" class="button button-secondary" id="ticino-ai-qr-add">+ Aggiungi bottone</button>
                        <button type="button" class="button-link" id="ticino-ai-qr-reset" style="margin-left:12px;">Ripristina i predefiniti</button>
                    </p>
                    <script type="text/template" id="ticino-ai-qr-row-template">
                        <tr class="ticino-ai-qr-row">
                            <td style="text-align:center;"><input type="checkbox" name="ticino_ai_quick_replies[__i__][enabled]" value="1" checked></td>
                            <td><input type="text" name="ticino_ai_quick_replies[__i__][label]" value="" maxlength="60" style="width:100%;" placeholder="Es. Dove siete?"></td>
                            <td>
                                <select name="ticino_ai_quick_replies[__i__][action]" class="ticino-ai-qr-action" style="width:100%;">
                                    <?php foreach ($qr_actions as $key => $lab) : ?>
                                        <option value="<?php echo esc_attr($key); ?>"><?php echo esc_html($lab); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" class="ticino-ai-qr-detail" data-for="ai" name="ticino_ai_quick_replies[__i__][value]" value="" maxlength="200" style="width:100%;" placeholder="Messaggio inviato all'AI (vuoto = usa il testo)">
                                <textarea class="ticino-ai-qr-detail" data-for="reply" name="ticino_ai_quick_replies[__i__][reply]" rows="2" maxlength="1000" style="width:100%;" placeholder="Testo della risposta fissa"></textarea>
                                <input type="url" class="ticino-ai-qr-detail" data-for="link" name="ticino_ai_quick_replies[__i__][url]" value="" style="width:100%;" placeholder="https://...">
                                <span class="ticino-ai-qr-detail ticino-helper-text" data-for="booking">Apre il form: <?php echo $is_lead ? 'nome, telefono, email, richiesta, note (nessuna data)' : 'nome, telefono, email, servizio, giorno, fascia oraria, note'; ?>.</span>
                            </td>
                            <td style="text-align:center;"><button type="button" class="button-link-delete ticino-ai-qr-remove" title="Rimuovi">&times;</button></td>
                        </tr>
                    </script>
                </div>

                <div class="ticino-form-group">
                    <label>Messaggio introduttivo del form <?php echo $is_lead ? 'di contatto' : 'di prenotazione'; ?></label>
                    <textarea name="ticino_ai_booking_intro" rows="4" maxlength="1000"><?php echo esc_textarea(get_option('ticino_ai_booking_intro', '')); ?></textarea>
                    <span class="ticino-helper-text">Mostrato quando parte il form (bottone «Avvia il form» oppure frase digitata come «<?php echo $is_lead ? 'vorrei informazioni' : 'vorrei prenotare'; ?>»). Deve terminare chiedendo nome e cognome, perché è la prima domanda del form. Vuoto = testo predefinito: <em><?php echo esc_html(str_replace("\n", ' ', Ticino_AI_Booking_Chatbot::default_booking_intro())); ?></em></span>
                </div>

                <div class="ticino-form-group">
                    <label>Messaggio di conferma invio</label>
                    <textarea name="ticino_ai_booking_success" rows="4" maxlength="1500"><?php echo esc_textarea(get_option('ticino_ai_booking_success', '')); ?></textarea>
                    <span class="ticino-helper-text">Mostrato in chat dopo l'invio riuscito della richiesta (supporta **grassetto** e a capo). È il posto giusto per avvisi come condizioni di disdetta. Vuoto = testo predefinito: <em><?php echo esc_html(str_replace("\n", ' ', Ticino_AI_Booking_Chatbot::default_success_message())); ?></em></span>
                </div>
            </div>
        </div>

        <!-- TAB APPLE CALENDAR -->
        <div id="tab-caldav" class="ticino-tab-pane">
            <div class="ticino-card" style="max-width: 800px;">
                <div class="ticino-card-title">
                    <span class="dashicons dashicons-calendar"></span> Sincronizzazione Apple Calendar
                </div>
                <p class="ticino-helper-text" style="margin-bottom: 20px;">
                    Apple Calendar viene sincronizzato <strong>solo dopo la conferma manuale</strong> di un appuntamento. Per collegare Apple Calendar è necessario usare una <a href="https://appleid.apple.com/" target="_blank">password specifica per app generata da iCloud</a>.
                </p>
                
                <div class="ticino-form-group">
                    <label>
                        <input type="checkbox" name="ticino_ai_caldav_enabled" value="1" <?php checked(get_option('ticino_ai_caldav_enabled'), 1); ?>> 
                        <strong>Abilita Sincronizzazione CalDAV</strong>
                    </label>
                </div>
                
                <div class="ticino-form-group">
                    <label>CalDAV Server URL</label>
                    <input type="url" name="ticino_ai_caldav_url" value="<?php echo esc_attr(get_option('ticino_ai_caldav_url', 'https://caldav.icloud.com')); ?>">
                </div>
                <div class="ticino-form-group">
                    <label>Apple ID (Email)</label>
                    <input type="email" name="ticino_ai_caldav_user" value="<?php echo esc_attr(get_option('ticino_ai_caldav_user')); ?>">
                </div>
                <div class="ticino-form-group">
                    <label>Password Specifica per l'App</label>
                    <input type="password" name="ticino_ai_caldav_pass" value="<?php echo esc_attr(get_option('ticino_ai_caldav_pass')); ?>">
                    <span class="ticino-helper-text">Esempio formato: <code>abcd-efgh-ijkl-mnop</code></span>
                </div>
                <div class="ticino-form-group">
                    <label>ID Calendario (URL finale o href)</label>
                    <input type="text" name="ticino_ai_caldav_calendar_id" value="<?php echo esc_attr(get_option('ticino_ai_caldav_calendar_id')); ?>">
                    <span class="ticino-helper-text">Spesso visibile negli header della richiesta o calcolato dal principal path. Es. <code>/1234567/calendars/work/</code></span>
                </div>
            </div>
        </div>

        <!-- TAB PRIVACY -->
        <div id="tab-privacy" class="ticino-tab-pane">
            <div class="ticino-card" style="max-width: 800px;">
                <div class="ticino-card-title">
                    <span class="dashicons dashicons-lock"></span> Impostazioni Privacy e Dati
                </div>
                <p class="ticino-helper-text" style="margin-bottom: 20px;">
                    Per impostazione predefinita, il plugin non salva conversazioni inutili ma solo per il contesto attivo, e richiede il consenso prima di inviare dati sensibili di contatto.
                </p>
                
                <div class="ticino-form-group">
                    <label>
                        <input type="checkbox" name="ticino_ai_privacy_save_conv" value="1" <?php checked(get_option('ticino_ai_privacy_save_conv'), 1); ?>> 
                        <strong>Salva log conversazioni nel database</strong>
                    </label>
                </div>
                <div class="ticino-form-group">
                    <label>Giorni conservazione log</label>
                    <input type="number" name="ticino_ai_privacy_retention" value="<?php echo esc_attr(get_option('ticino_ai_privacy_retention', '30')); ?>" style="max-width: 150px;">
                </div>
                <hr style="border: 0; border-top: 1px solid var(--ticino-border); margin: 24px 0;">
                
                <div class="ticino-form-group">
                    <label>Testo Consenso Privacy Form</label>
                    <textarea name="ticino_ai_privacy_text" rows="2"><?php echo esc_textarea(get_option('ticino_ai_privacy_text')); ?></textarea>
                    <span class="ticino-helper-text">Testo mostrato all'utente vicino alla checkbox obbligatoria prima di prenotare.</span>
                </div>
                <div class="ticino-form-group">
                    <label>Link Privacy Policy</label>
                    <input type="text" name="ticino_ai_privacy_link" value="<?php echo esc_attr(get_option('ticino_ai_privacy_link')); ?>">
                    <span class="ticino-helper-text">URL relativo o assoluto (es. <code>/privacy-policy</code>)</span>
                </div>
            </div>
        </div>

        <p class="submit" style="margin-top: 30px;">
            <?php submit_button('Salva Impostazioni', 'primary', 'submit', false); ?>
        </p>
    </form>
</div>
