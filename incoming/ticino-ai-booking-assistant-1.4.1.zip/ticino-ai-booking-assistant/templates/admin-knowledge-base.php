<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$kb_source = get_option('ticino_ai_kb_source', 'site_auto');

$kb_services_json = get_option('ticino_ai_kb_services', '[]');
$kb_techs_json = get_option('ticino_ai_kb_techs', '[]');
$kb_products_json = get_option('ticino_ai_kb_products', '[]');
$kb_faq_json = get_option('ticino_ai_kb_faq', '[]');

$services_arr = json_decode($kb_services_json, true) ?: [];
$techs_arr = json_decode($kb_techs_json, true) ?: [];
$products_arr = json_decode($kb_products_json, true) ?: [];
$faqs_arr = json_decode($kb_faq_json, true) ?: [];

// Dati scansione automatica del sito
$site_stats = class_exists('Ticino_AI_Booking_Dynamic_Site_Knowledge') ? Ticino_AI_Booking_Dynamic_Site_Knowledge::get_site_stats() : array(
    'pages_count' => 0, 'services_count' => 0, 'products_count' => 0, 'posts_count' => 0, 'techs_count' => 0, 'team_count' => 0, 'last_indexed' => '', 'total_items' => 0
);
?>

<div class="wrap ticino-wrap">
    <div class="ticino-header">
        <div>
            <h1>Knowledge Base AI</h1>
            <p>Scegli la modalità di apprendimento del chatbot: scansionare e analizzare automaticamente tutto il sito web oppure usare una Knowledge Base personalizzata a mano.</p>
        </div>
    </div>
    
    <?php settings_errors(); ?>

    <form method="post" action="options.php" id="ticino-kb-form">
        <?php settings_fields('ticino_ai_booking_kb_group'); ?>

        <!-- SELETTORE DEI DUE PULSANTI / MODALITÀ DI APPRENDIMENTO -->
        <div class="ticino-kb-mode-grid">
            
            <!-- OPZIONE 1: USA LE INFORMAZIONI DEL SITO (AUTOMATICA & DINAMICA) -->
            <label class="ticino-kb-mode-card <?php echo ($kb_source === 'site_auto') ? 'is-selected' : ''; ?>" id="card-mode-site-auto">
                <div class="ticino-kb-mode-header">
                    <div class="ticino-kb-mode-icon-title">
                        <div class="ticino-kb-mode-icon icon-site">
                            <span class="dashicons dashicons-admin-site-alt3"></span>
                        </div>
                        <div class="ticino-kb-mode-title">
                            <h3>Usa le informazioni del sito</h3>
                            <p>Scansione Dinamica Continua</p>
                        </div>
                    </div>
                    <input type="radio" name="ticino_ai_kb_source" value="site_auto" class="ticino-kb-mode-radio" <?php checked($kb_source, 'site_auto'); ?>>
                </div>
                <p class="ticino-kb-mode-desc">
                    L'AI analizza in tempo reale ogni elemento del sito (Pagine, Servizi e Listino, Prodotti WooCommerce, Tecnologie, Team, Blog, Orari e CMS). 
                    <strong>Risponde a qualsiasi domanda dei clienti senza mai restituire errori o rifiuti di risposta.</strong>
                </p>
                <div class="ticino-kb-mode-badge">
                    <span class="dashicons dashicons-yes-alt" style="font-size:14px; width:14px; height:14px;"></span>
                    <span>Consigliato • Zero Errori</span>
                </div>
            </label>

            <!-- OPZIONE 2: KNOWLEDGE BASE PERSONALIZZATA (MANUALE) -->
            <label class="ticino-kb-mode-card <?php echo ($kb_source === 'custom') ? 'is-selected' : ''; ?>" id="card-mode-custom">
                <div class="ticino-kb-mode-header">
                    <div class="ticino-kb-mode-icon-title">
                        <div class="ticino-kb-mode-icon icon-custom">
                            <span class="dashicons dashicons-database"></span>
                        </div>
                        <div class="ticino-kb-mode-title">
                            <h3>Knowledge Base Custom</h3>
                            <p>Configurazione Manuale</p>
                        </div>
                    </div>
                    <input type="radio" name="ticino_ai_kb_source" value="custom" class="ticino-kb-mode-radio" <?php checked($kb_source, 'custom'); ?>>
                </div>
                <p class="ticino-kb-mode-desc">
                    Utilizza esclusivamente le informazioni, i servizi, le tecnologie, i brand e le FAQ inserite manualmente nelle tabelle sottostanti per istruire l'AI.
                </p>
                <div class="ticino-kb-mode-badge" style="background:#f1f5f9; color:#475569;">
                    <span>Modalità Manuale</span>
                </div>
            </label>

        </div>

        <?php
        // DOCUMENTI PDF (1.4.0): valgono in entrambe le modalità
        $pdf_docs = array();
        foreach (Ticino_AI_Booking_PDF_Knowledge::get_documents() as $pdf_id => $pdf_doc) {
            $pdf_docs[] = Ticino_AI_Booking_PDF_Knowledge::document_for_js($pdf_id, $pdf_doc);
        }
        $pdf_summary = Ticino_AI_Booking_PDF_Knowledge::summary();
        ?>
        <div class="ticino-card ticino-pdf-card" id="ticino-pdf-card">
            <div class="ticino-pdf-head">
                <div>
                    <div class="ticino-card-title" style="margin-bottom:4px;"><span class="dashicons dashicons-media-document"></span> <?php esc_html_e('Documenti PDF', 'ticino-ai-booking'); ?></div>
                    <p class="ticino-helper-text" style="margin:0;"><?php esc_html_e('Listini, cataloghi, regolamenti, schede tecniche: l\'assistente legge il testo dei PDF e lo usa per rispondere, indicando da quale documento viene l\'informazione. Vale in entrambe le modalità.', 'ticino-ai-booking'); ?></p>
                </div>
                <button type="button" class="button button-primary" id="ticino-pdf-add">
                    <span class="dashicons dashicons-plus-alt2" style="margin-top:3px;"></span> <?php esc_html_e('Aggiungi PDF', 'ticino-ai-booking'); ?>
                </button>
            </div>

            <div id="ticino-pdf-notices" role="status" aria-live="polite"></div>

            <div id="ticino-pdf-empty" class="ticino-pdf-empty" <?php echo $pdf_docs ? 'hidden' : ''; ?>>
                <span class="dashicons dashicons-media-document"></span>
                <div>
                    <strong><?php esc_html_e('Nessun documento ancora.', 'ticino-ai-booking'); ?></strong>
                    <ol>
                        <li><?php esc_html_e('Premi «Aggiungi PDF».', 'ticino-ai-booking'); ?></li>
                        <li><?php esc_html_e('Scegli un PDF dalla libreria media, oppure trascinalo nella finestra per caricarlo.', 'ticino-ai-booking'); ?></li>
                        <li><?php esc_html_e('Attendi qualche secondo: il documento viene letto una volta sola e compare qui sotto.', 'ticino-ai-booking'); ?></li>
                    </ol>
                    <span class="ticino-helper-text"><?php
                        printf(
                            /* translators: %s: dimensione massima */
                            esc_html__('Solo PDF con testo (non scansioni), massimo %s per file. Se cambi un PDF, caricalo di nuovo e premi «Rileggi».', 'ticino-ai-booking'),
                            esc_html(size_format(Ticino_AI_Booking_PDF_Knowledge::max_bytes()))
                        );
                    ?></span>
                </div>
            </div>

            <table class="ticino-pdf-table" id="ticino-pdf-table" <?php echo $pdf_docs ? '' : 'hidden'; ?>>
                <thead>
                    <tr>
                        <th><?php esc_html_e('Documento', 'ticino-ai-booking'); ?></th>
                        <th><?php esc_html_e('Contenuto letto', 'ticino-ai-booking'); ?></th>
                        <th><?php esc_html_e('Letto il', 'ticino-ai-booking'); ?></th>
                        <th><span class="screen-reader-text"><?php esc_html_e('Azioni', 'ticino-ai-booking'); ?></span></th>
                    </tr>
                </thead>
                <tbody id="ticino-pdf-rows"></tbody>
            </table>
            <p class="ticino-helper-text" id="ticino-pdf-upgrade" hidden></p>

            <div class="ticino-pdf-try" id="ticino-pdf-try" <?php echo $pdf_docs ? '' : 'hidden'; ?>>
                <label for="ticino-pdf-q"><strong><?php esc_html_e('Prova una domanda', 'ticino-ai-booking'); ?></strong> — <?php esc_html_e('vedi quali passaggi dei PDF userebbe l\'assistente.', 'ticino-ai-booking'); ?></label>
                <div class="ticino-pdf-try-row">
                    <input type="search" id="ticino-pdf-q" placeholder="<?php esc_attr_e('Es. Quali sono gli orari di apertura?', 'ticino-ai-booking'); ?>" autocomplete="off">
                    <button type="button" class="button" id="ticino-pdf-try-btn"><?php esc_html_e('Cerca nei PDF', 'ticino-ai-booking'); ?></button>
                </div>
                <div id="ticino-pdf-try-results"></div>
            </div>
        </div>
        <script>
        window.ticinoPdf = <?php echo wp_json_encode(array(
            'docs'    => $pdf_docs,
            'summary' => $pdf_summary,
            'hasKey'  => Ticino_AI_Booking_PDF_Knowledge::active_embed_model() !== '',
            'i18n'    => array(
                'frameTitle'  => __('Scegli o carica i PDF per l\'assistente', 'ticino-ai-booking'),
                'frameButton' => __('Aggiungi alla Knowledge Base', 'ticino-ai-booking'),
                'reading'     => /* translators: %s: nome del documento */ __('Sto leggendo «%s»…', 'ticino-ai-booking'),
                'onlyPdf'     => /* translators: %s: nome del file */ __('«%s» non è un PDF: si possono aggiungere solo file PDF.', 'ticino-ai-booking'),
                'pages'       => /* translators: %d: numero di pagine */ __('%d pagine', 'ticino-ai-booking'),
                'page1'       => __('1 pagina', 'ticino-ai-booking'),
                'smart'       => __('Ricerca intelligente', 'ticino-ai-booking'),
                'smartHelp'   => __('Trova le risposte anche se la domanda è in un\'altra lingua o con parole diverse.', 'ticino-ai-booking'),
                'basic'       => __('Ricerca per parole', 'ticino-ai-booking'),
                'basicHelp'   => __('Senza chiave API attiva la ricerca usa le parole della domanda. Con la chiave configurata in Impostazioni › Modello AI, premi «Rileggi» per la ricerca intelligente.', 'ticino-ai-booking'),
                'reread'      => __('Rileggi', 'ticino-ai-booking'),
                'remove'      => __('Togli', 'ticino-ai-booking'),
                'confirm'     => /* translators: %s: nome del documento */ __('Togliere «%s» dalla Knowledge Base? L\'assistente non userà più questo documento. Il file resta nella libreria media.', 'ticino-ai-booking'),
                'removing'    => /* translators: %s: nome del documento */ __('Sto togliendo «%s»…', 'ticino-ai-booking'),
                'searching'   => __('Sto cercando…', 'ticino-ai-booking'),
                'noResults'   => __('Nessun passaggio dei PDF risponde a questa domanda: l\'assistente userà le altre informazioni del sito.', 'ticino-ai-booking'),
                'pageLbl'     => /* translators: %d: numero di pagina */ __('pagina %d', 'ticino-ai-booking'),
                'netError'    => __('Il server non ha risposto. Controlla la connessione e riprova; se il PDF è molto grande, prova a dividerlo in più file.', 'ticino-ai-booking'),
                'open'        => __('Apri il PDF', 'ticino-ai-booking'),
                'upgradeHint' => __('Alcuni documenti usano ancora la ricerca per parole perché sono stati letti prima di configurare la chiave API o con un altro provider. Premi «Rileggi» su quei documenti per attivare la ricerca intelligente.', 'ticino-ai-booking'),
            ),
        ), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
        </script>

        <!-- PANNELLO MODALITÀ 1: STATO SCANSIONE SITO WEB DINAMICO -->
        <div id="section-site-auto-panel" style="<?php echo ($kb_source === 'site_auto') ? 'display:block;' : 'display:none;'; ?>">
            <div class="ticino-card" style="margin-bottom: 20px;">
                <div class="ticino-card-title"><span class="dashicons dashicons-welcome-write-blog"></span> Conoscenza aggiuntiva</div>
                <div class="ticino-form-group">
                    <textarea name="ticino_ai_kb_extra_context" rows="8" style="max-width:100%;" placeholder="Es. brand utilizzati e come si applicano, politiche di cancellazione, informazioni che sul sito non ci sono..."><?php echo esc_textarea(get_option('ticino_ai_kb_extra_context', '')); ?></textarea>
                    <span class="ticino-helper-text">Testo libero aggiunto alla conoscenza del sito in entrambe le modalità. Serve per tutto ciò che il sito non dice esplicitamente. Nessuna informazione di settore è scritta nel plugin: ciò che l'assistente sa arriva dal sito e da qui.</span>
                </div>
            </div>

            <?php
            // Post type personalizzati del tema (lavorazioni, macchine, referenze, posizioni aperte...)
            $kb_available_types = Ticino_AI_Booking_Dynamic_Site_Knowledge::get_available_post_types();
            $kb_chosen_types    = Ticino_AI_Booking_Dynamic_Site_Knowledge::get_indexed_post_types();
            ?>
            <div class="ticino-card" style="margin-bottom: 20px;">
                <div class="ticino-card-title"><span class="dashicons dashicons-portfolio"></span> Contenuti personalizzati da includere</div>
                <div class="ticino-form-group">
                    <?php if (empty($kb_available_types)) : ?>
                        <span class="ticino-helper-text">Il tema attivo non registra tipi di contenuto personalizzati: l'indice comprende pagine, articoli e, se presente, il catalogo WooCommerce.</span>
                    <?php else : ?>
                        <div style="display:flex; flex-wrap:wrap; gap: 10px 24px; margin-top:4px;">
                            <?php foreach ($kb_available_types as $pt_slug => $pt_obj) :
                                $pt_count = wp_count_posts($pt_slug);
                                $pt_published = isset($pt_count->publish) ? (int) $pt_count->publish : 0;
                            ?>
                                <label style="font-weight: normal;">
                                    <input type="checkbox" name="ticino_ai_kb_post_types[]" value="<?php echo esc_attr($pt_slug); ?>" <?php checked(in_array($pt_slug, $kb_chosen_types, true)); ?>>
                                    <?php echo esc_html($pt_obj->labels->name); ?>
                                    <span class="ticino-badge ticino-badge-neutral" style="margin-left:4px;"><?php echo $pt_published; ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                        <span class="ticino-helper-text">Oltre a pagine e articoli, l'assistente legge titolo, categorie e un estratto (max 60 elementi per tipo) dei contenuti spuntati. Utile per lavorazioni, parco macchine, referenze o posizioni aperte registrati dal tema.</span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="ticino-site-index-panel">
                <div class="ticino-index-header">
                    <h3>
                        <span class="dashicons dashicons-search" style="color:var(--ticino-primary);"></span>
                        Indice Dinamico dei Contenuti del Sito
                    </h3>
                    <div style="display:flex; align-items:center; gap:12px;">
                        <span id="site-last-indexed-text" style="font-size:13px; color:#64748b;">
                            Ultima scansione: <strong><?php echo esc_html($site_stats['last_indexed'] ?: 'Attiva in tempo reale'); ?></strong>
                        </span>
                        <button type="button" class="button button-secondary" id="btn-reindex-site" style="display:inline-flex; align-items:center; gap:6px;">
                            <span class="dashicons dashicons-update" style="font-size:16px; width:16px; height:16px; margin-top:2px;"></span>
                            <span>Aggiorna Indice del Sito</span>
                        </button>
                    </div>
                </div>

                <!-- Griglia Statistiche Scansionate -->
                <div class="ticino-index-stats-grid">
                    <div class="ticino-index-stat-item">
                        <div class="ticino-index-stat-num" id="stat-pages"><?php echo esc_html($site_stats['pages_count']); ?></div>
                        <div class="ticino-index-stat-lbl">Pagine Web</div>
                    </div>
                    <div class="ticino-index-stat-item">
                        <div class="ticino-index-stat-num" id="stat-services"><?php echo esc_html($site_stats['services_count']); ?></div>
                        <div class="ticino-index-stat-lbl">Servizi & Listino</div>
                    </div>
                    <div class="ticino-index-stat-item">
                        <div class="ticino-index-stat-num" id="stat-products"><?php echo esc_html($site_stats['products_count']); ?></div>
                        <div class="ticino-index-stat-lbl">Prodotti Shop</div>
                    </div>
                    <div class="ticino-index-stat-item">
                        <div class="ticino-index-stat-num" id="stat-techs"><?php echo esc_html($site_stats['techs_count']); ?></div>
                        <div class="ticino-index-stat-lbl">Tecnologie & Brand</div>
                    </div>
                    <div class="ticino-index-stat-item">
                        <div class="ticino-index-stat-num" id="stat-posts"><?php echo esc_html($site_stats['posts_count']); ?></div>
                        <div class="ticino-index-stat-lbl">Articoli Blog</div>
                    </div>
                    <div class="ticino-index-stat-item">
                        <div class="ticino-index-stat-num" id="stat-team"><?php echo esc_html($site_stats['team_count']); ?></div>
                        <div class="ticino-index-stat-lbl">Professioniste Team</div>
                    </div>
                </div>

                <!-- Box Informativo di Garanzia Risposta -->
                <div class="ticino-site-index-info">
                    <span class="dashicons dashicons-shield"></span>
                    <div>
                        <strong>Integrazione Completa & Zero Rifiuti di Risposta:</strong>
                        <p style="margin: 4px 0 0;">
                            L'assistente è istruito per analizzare a fondo ogni contenuto del sito. Qualsiasi domanda il cliente formuli (orari, indirizzo, cosa si fa in un trattamento, differenze tra macchinari, prezzi in CHF, consigli sui prodotti o come prenotare), l'AI fornirà una risposta completa, ricca e professionale con invito all'azione.
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <!-- PANNELLO MODALITÀ 2: KNOWLEDGE BASE MANUALE (ACCORDION) -->
        <div id="section-custom-kb-panel" style="<?php echo ($kb_source === 'custom') ? 'display:block;' : 'display:none;'; ?>">

            <!-- Statistiche Manuali -->
            <div class="ticino-grid ticino-grid-cols-4" style="margin-bottom: 24px;">
                <div class="ticino-card ticino-stat-card ticino-card-sm">
                    <div class="ticino-stat-icon" style="background:#e0f2fe; color:#0284c7; width: 36px; height: 36px; font-size: 16px;">
                        <span class="dashicons dashicons-clipboard"></span>
                    </div>
                    <div class="ticino-stat-content">
                        <h3 style="font-size: 20px;"><?php echo count($services_arr); ?></h3>
                        <p>Servizi Offerti</p>
                    </div>
                </div>
                <div class="ticino-card ticino-stat-card ticino-card-sm">
                    <div class="ticino-stat-icon" style="background:#fef08a; color:#a16207; width: 36px; height: 36px; font-size: 16px;">
                        <span class="dashicons dashicons-admin-tools"></span>
                    </div>
                    <div class="ticino-stat-content">
                        <h3 style="font-size: 20px;"><?php echo count($techs_arr); ?></h3>
                        <p>Tecnologie</p>
                    </div>
                </div>
                <div class="ticino-card ticino-stat-card ticino-card-sm">
                    <div class="ticino-stat-icon" style="background:#fce7f3; color:#be185d; width: 36px; height: 36px; font-size: 16px;">
                        <span class="dashicons dashicons-heart"></span>
                    </div>
                    <div class="ticino-stat-content">
                        <h3 style="font-size: 20px;"><?php echo count($products_arr); ?></h3>
                        <p>Prodotti / Brand</p>
                    </div>
                </div>
                <div class="ticino-card ticino-stat-card ticino-card-sm">
                    <div class="ticino-stat-icon" style="background:#dcfce7; color:#15803d; width: 36px; height: 36px; font-size: 16px;">
                        <span class="dashicons dashicons-editor-help"></span>
                    </div>
                    <div class="ticino-stat-content">
                        <h3 style="font-size: 20px;"><?php echo count($faqs_arr); ?></h3>
                        <p>FAQ</p>
                    </div>
                </div>
            </div>

            <!-- Regole AI -->
            <div class="ticino-card" style="margin-bottom: 24px; background: #fffbeb; border-color: #fde68a;">
                <div class="ticino-card-title" style="color: #b45309; margin-bottom: 8px;">
                    <span class="dashicons dashicons-warning"></span> Regole dell'assistente AI
                </div>
                <div style="color: #92400e; font-size: 14px; line-height: 1.6;">
                    <ul style="margin:0; padding-left: 20px;">
                        <li>Non fa <strong>mai</strong> diagnosi mediche o promette risultati garantiti.</li>
                        <li>Non conferma appuntamenti definitivamente (invita l'amministratore a farlo dal backend).</li>
                        <li>Per dubbi specifici su patologie o gravidanze, invita a prenotare una consulenza in salone.</li>
                    </ul>
                </div>
            </div>

            <!-- Dati Azienda -->
            <div class="ticino-kb-accordion">
                <div class="ticino-kb-header">
                    <div class="ticino-kb-header-left">
                        <div class="ticino-kb-icon"><span class="dashicons dashicons-store"></span></div>
                        <div class="ticino-kb-title">
                            <h3>Descrizione Azienda</h3>
                            <p>Dati principali del centro, tono di voce e regole dell’assistente.</p>
                        </div>
                    </div>
                    <div class="ticino-kb-meta">
                        <span class="dashicons dashicons-arrow-down-alt2"></span>
                    </div>
                </div>
                <div class="ticino-kb-body">
                    <div class="ticino-form-group">
                        <label>Chi Siamo / Descrizione Generale</label>
                        <textarea name="ticino_ai_kb_company_desc" rows="6" style="max-width:100%;"><?php echo esc_textarea(get_option('ticino_ai_kb_company_desc')); ?></textarea>
                        <span class="ticino-helper-text">Presentazione dell'azienda, filosofia e approccio.</span>
                    </div>
                </div>
            </div>

            <!-- Servizi Offerti -->
            <div class="ticino-kb-accordion">
                <div class="ticino-kb-header">
                    <div class="ticino-kb-header-left">
                        <div class="ticino-kb-icon"><span class="dashicons dashicons-clipboard"></span></div>
                        <div class="ticino-kb-title">
                            <h3>Servizi Offerti</h3>
                            <p><?php echo count($services_arr); ?> servizi configurati usati per rispondere alle domande dei clienti.</p>
                        </div>
                    </div>
                    <div class="ticino-kb-meta">
                        <span class="ticino-badge ticino-badge-neutral"><?php echo count($services_arr); ?> Elementi</span>
                        <span class="dashicons dashicons-arrow-down-alt2"></span>
                    </div>
                </div>
                <div class="ticino-kb-body">
                    <textarea id="raw-services" name="ticino_ai_kb_services" style="display:none;"><?php echo esc_textarea($kb_services_json); ?></textarea>
                    <div id="ui-services"></div>
                    <button type="button" class="button button-secondary" onclick="kbAddService()">+ Aggiungi Servizio</button>
                </div>
            </div>

            <!-- Tecnologie -->
            <div class="ticino-kb-accordion">
                <div class="ticino-kb-header">
                    <div class="ticino-kb-header-left">
                        <div class="ticino-kb-icon"><span class="dashicons dashicons-admin-tools"></span></div>
                        <div class="ticino-kb-title">
                            <h3>Tecnologie</h3>
                            <p><?php echo count($techs_arr); ?> tecnologie configurate.</p>
                        </div>
                    </div>
                    <div class="ticino-kb-meta">
                        <span class="ticino-badge ticino-badge-neutral"><?php echo count($techs_arr); ?> Elementi</span>
                        <span class="dashicons dashicons-arrow-down-alt2"></span>
                    </div>
                </div>
                <div class="ticino-kb-body">
                    <textarea id="raw-techs" name="ticino_ai_kb_techs" style="display:none;"><?php echo esc_textarea($kb_techs_json); ?></textarea>
                    <div id="ui-techs"></div>
                    <button type="button" class="button button-secondary" onclick="kbAddTech()">+ Aggiungi Tecnologia</button>
                </div>
            </div>

            <!-- Prodotti / Brand -->
            <div class="ticino-kb-accordion">
                <div class="ticino-kb-header">
                    <div class="ticino-kb-header-left">
                        <div class="ticino-kb-icon"><span class="dashicons dashicons-heart"></span></div>
                        <div class="ticino-kb-title">
                            <h3>Prodotti / Brand</h3>
                            <p><?php echo count($products_arr); ?> brand professionali configurati.</p>
                        </div>
                    </div>
                    <div class="ticino-kb-meta">
                        <span class="ticino-badge ticino-badge-neutral"><?php echo count($products_arr); ?> Elementi</span>
                        <span class="dashicons dashicons-arrow-down-alt2"></span>
                    </div>
                </div>
                <div class="ticino-kb-body">
                    <textarea id="raw-products" name="ticino_ai_kb_products" style="display:none;"><?php echo esc_textarea($kb_products_json); ?></textarea>
                    <div id="ui-products"></div>
                    <button type="button" class="button button-secondary" onclick="kbAddProduct()">+ Aggiungi Brand/Prodotto</button>
                </div>
            </div>

            <!-- FAQ -->
            <div class="ticino-kb-accordion">
                <div class="ticino-kb-header">
                    <div class="ticino-kb-header-left">
                        <div class="ticino-kb-icon"><span class="dashicons dashicons-editor-help"></span></div>
                        <div class="ticino-kb-title">
                            <h3>Domande Frequenti (FAQ)</h3>
                            <p><?php echo count($faqs_arr); ?> FAQ configurate.</p>
                        </div>
                    </div>
                    <div class="ticino-kb-meta">
                        <span class="ticino-badge ticino-badge-neutral"><?php echo count($faqs_arr); ?> Elementi</span>
                        <span class="dashicons dashicons-arrow-down-alt2"></span>
                    </div>
                </div>
                <div class="ticino-kb-body">
                    <textarea id="raw-faqs" name="ticino_ai_kb_faq" style="display:none;"><?php echo esc_textarea($kb_faq_json); ?></textarea>
                    <div id="ui-faqs"></div>
                    <button type="button" class="button button-secondary" onclick="kbAddFaq()">+ Aggiungi FAQ</button>
                </div>
            </div>

        </div>

        <p class="submit" style="margin-top: 30px; position: sticky; bottom: 20px; background: rgba(255,255,255,0.95); padding: 16px 20px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.08); backdrop-filter: blur(8px); z-index: 10; display:flex; justify-content:space-between; align-items:center;">
            <?php submit_button('Salva Configurazione Knowledge Base', 'primary', 'submit', false); ?>
            <span style="font-size:13px; color:#64748b;">Le modifiche hanno effetto immediato sul chatbot.</span>
        </p>
    </form>
</div>

<script>
jQuery(document).ready(function($) {
    // --- Switch Mode Selector (Due Pulsanti) ---
    $('input[name="ticino_ai_kb_source"]').on('change', function() {
        var mode = $(this).val();
        if (mode === 'site_auto') {
            $('#card-mode-site-auto').addClass('is-selected');
            $('#card-mode-custom').removeClass('is-selected');
            $('#section-site-auto-panel').slideDown(250);
            $('#section-custom-kb-panel').slideUp(250);
        } else {
            $('#card-mode-custom').addClass('is-selected');
            $('#card-mode-site-auto').removeClass('is-selected');
            $('#section-custom-kb-panel').slideDown(250);
            $('#section-site-auto-panel').slideUp(250);
        }
    });

    $('#card-mode-site-auto').on('click', function(e) {
        if (!$(e.target).is('input[type="radio"]')) {
            $(this).find('input[type="radio"]').prop('checked', true).trigger('change');
        }
    });

    $('#card-mode-custom').on('click', function(e) {
        if (!$(e.target).is('input[type="radio"]')) {
            $(this).find('input[type="radio"]').prop('checked', true).trigger('change');
        }
    });

    // --- AJAX Reindex Button ---
    $('#btn-reindex-site').on('click', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var originalHtml = $btn.html();
        
        $btn.prop('disabled', true).html('<span class="dashicons dashicons-update" style="animation: spin 1s infinite linear; font-size:16px; width:16px; height:16px;"></span> Scansione in corso...');

        $.ajax({
            url: ticino_ai_admin.ajax_url,
            method: 'POST',
            data: {
                action: 'ticino_ai_reindex_site',
                _ajax_nonce: ticino_ai_admin.nonce
            },
            success: function(response) {
                $btn.prop('disabled', false).html(originalHtml);
                if (response.success && response.data) {
                    var d = response.data;
                    $('#stat-pages').text(d.pages_count || 0);
                    $('#stat-services').text(d.services_count || 0);
                    $('#stat-products').text(d.products_count || 0);
                    $('#stat-techs').text(d.techs_count || 0);
                    $('#stat-posts').text(d.posts_count || 0);
                    $('#stat-team').text(d.team_count || 0);
                    $('#site-last-indexed-text').html('Ultima scansione: <strong>' + (d.last_indexed || 'Adesso') + '</strong>');
                    alert('Indice del sito aggiornato con successo!');
                }
            },
            error: function() {
                $btn.prop('disabled', false).html(originalHtml);
                alert('Errore durante la scansione del sito.');
            }
        });
    });
});

// --- Documenti PDF (1.4.0) ---
jQuery(function($) {
    var cfg = window.ticinoPdf || {docs: [], i18n: {}};
    var t = cfg.i18n;
    var docs = cfg.docs.slice();
    var queue = [];
    var busy = false;
    var frame = null;

    function fmt(str, val) { return String(str).replace(/%[sd]/, val); }
    function esc(s) { return escapeHtml(String(s == null ? '' : s)); }

    // Un messaggio per file: con più PDF scelti insieme si vede l'esito di ognuno
    function notice(type, text) {
        $('#ticino-pdf-notices .is-working').remove();
        $('<div class="ticino-pdf-notice"></div>').addClass('is-' + type).text(text).appendTo('#ticino-pdf-notices');
    }
    function clearNotices() { $('#ticino-pdf-notices').empty(); }

    function render() {
        var html = '';
        docs.forEach(function(d) {
            html += '<tr data-id="' + d.id + '">'
                + '<td><span class="dashicons dashicons-pdf ticino-pdf-ico"></span><div><strong>' + esc(d.title) + '</strong>'
                + '<div class="ticino-pdf-sub"><a href="' + esc(d.url) + '" target="_blank" rel="noopener">' + esc(t.open) + '</a> · ' + esc(d.file) + ' · ' + esc(d.size) + '</div></div></td>'
                + '<td>' + esc(d.pages === 1 ? t.page1 : fmt(t.pages, d.pages)) + '<br>'
                + (d.smart
                    ? '<span class="ticino-badge ticino-badge-success" title="' + esc(t.smartHelp) + '">' + esc(t.smart) + '</span>'
                    : '<span class="ticino-badge ticino-badge-neutral" title="' + esc(t.basicHelp) + '">' + esc(t.basic) + '</span>')
                + '</td>'
                + '<td>' + esc(d.indexed_at) + '</td>'
                + '<td class="ticino-pdf-actions">'
                + '<button type="button" class="button button-small ticino-pdf-reread">' + esc(t.reread) + '</button> '
                + '<button type="button" class="button button-small button-link-delete ticino-pdf-remove">' + esc(t.remove) + '</button>'
                + '</td></tr>';
        });
        $('#ticino-pdf-rows').html(html);
        var has = docs.length > 0;
        $('#ticino-pdf-table, #ticino-pdf-try').prop('hidden', !has);
        $('#ticino-pdf-empty').prop('hidden', has);
        var needsReread = cfg.hasKey && docs.some(function(d) { return !d.smart; });
        $('#ticino-pdf-upgrade').text(t.upgradeHint).prop('hidden', !needsReread);
    }

    function upsert(doc) {
        var i = docs.findIndex(function(d) { return d.id === doc.id; });
        if (i >= 0) { docs[i] = doc; } else { docs.unshift(doc); }
        render();
    }

    function post(action, data) {
        return $.post(ticino_ai_admin.ajax_url, $.extend({action: action, nonce: ticino_ai_admin.nonce}, data));
    }

    function next() {
        if (busy || !queue.length) return;
        busy = true;
        var item = queue.shift();
        $('#ticino-pdf-add').prop('disabled', true);
        notice('working', fmt(t.reading, item.title));
        post('ticino_ai_pdf_add', {attachment_id: item.id}).done(function(r) {
            if (r && r.success) {
                upsert(r.data.document);
                notice('success', r.data.message);
            } else {
                notice('error', item.title + ': ' + ((r && r.data && r.data.message) || t.netError));
            }
        }).fail(function(xhr) {
            var msg = xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message;
            notice('error', item.title + ': ' + (msg || t.netError));
        }).always(function() {
            busy = false;
            $('#ticino-pdf-add').prop('disabled', false);
            next();
        });
    }

    $('#ticino-pdf-add').on('click', function() {
        if (!frame) {
            frame = wp.media({
                title: t.frameTitle,
                button: {text: t.frameButton},
                library: {type: 'application/pdf'},
                multiple: true
            });
            frame.on('select', function() {
                if (!busy) clearNotices();
                frame.state().get('selection').each(function(att) {
                    var a = att.toJSON();
                    if (a.mime !== 'application/pdf') {
                        notice('error', fmt(t.onlyPdf, a.title || a.filename));
                        return;
                    }
                    queue.push({id: a.id, title: a.title || a.filename});
                });
                next();
            });
        }
        frame.open();
    });

    $('#ticino-pdf-rows').on('click', '.ticino-pdf-reread', function() {
        var id = parseInt($(this).closest('tr').data('id'), 10);
        var d = docs.find(function(x) { return x.id === id; });
        if (!busy) clearNotices();
        queue.push({id: id, title: d ? d.title : ''});
        next();
    }).on('click', '.ticino-pdf-remove', function() {
        var $btn = $(this);
        var id = parseInt($btn.closest('tr').data('id'), 10);
        var d = docs.find(function(x) { return x.id === id; });
        if (!d || !window.confirm(fmt(t.confirm, d.title))) return;
        $btn.prop('disabled', true);
        if (!busy) clearNotices();
        notice('working', fmt(t.removing, d.title));
        post('ticino_ai_pdf_remove', {attachment_id: id}).done(function(r) {
            if (r && r.success) {
                docs = docs.filter(function(x) { return x.id !== id; });
                render();
                notice('success', r.data.message);
            } else {
                $btn.prop('disabled', false);
                notice('error', (r && r.data && r.data.message) || t.netError);
            }
        }).fail(function() {
            $btn.prop('disabled', false);
            notice('error', t.netError);
        });
    });

    function trySearch() {
        var q = $.trim($('#ticino-pdf-q').val());
        var $out = $('#ticino-pdf-try-results');
        if (!q) return;
        $out.html('<p class="ticino-helper-text">' + esc(t.searching) + '</p>');
        post('ticino_ai_pdf_search', {q: q}).done(function(r) {
            if (!r || !r.success) {
                $out.html('<p class="ticino-pdf-notice is-error">' + esc((r && r.data && r.data.message) || t.netError) + '</p>');
                return;
            }
            if (!r.data.results.length) {
                $out.html('<p class="ticino-helper-text">' + esc(t.noResults) + '</p>');
                return;
            }
            var html = '';
            r.data.results.forEach(function(x) {
                html += '<blockquote class="ticino-pdf-hit"><div class="ticino-pdf-sub"><strong>' + esc(x.title) + '</strong>'
                    + (x.page ? ' · ' + esc(fmt(t.pageLbl, x.page)) : '') + '</div>' + esc(x.text) + '</blockquote>';
            });
            $out.html(html);
        }).fail(function() {
            $out.html('<p class="ticino-pdf-notice is-error">' + esc(t.netError) + '</p>');
        });
    }
    $('#ticino-pdf-try-btn').on('click', trySearch);
    // Invio nel campo di prova: cerca, senza inviare il modulo delle impostazioni
    $('#ticino-pdf-q').on('keydown', function(e) {
        if (e.key === 'Enter') { e.preventDefault(); trySearch(); }
    });

    render();
});

// --- UI per Services (Array of Objects) ---
let servicesData = [];
try { servicesData = JSON.parse(document.getElementById('raw-services').value || '[]'); } catch(e){}

function renderServices() {
    let html = '';
    servicesData.forEach((s, index) => {
        html += `
        <div style="background:#fff; border:1px solid #e5e7eb; padding:15px; margin-bottom:10px; border-radius:8px;">
            <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:10px;">
                <div style="flex-grow:1; display:flex; gap:10px;">
                    <input type="text" value="${escapeHtml(s.title || '')}" onchange="updateService(${index}, 'title', this.value)" placeholder="Titolo Servizio" style="flex:2;">
                    <input type="text" value="${escapeHtml(s.category || '')}" onchange="updateService(${index}, 'category', this.value)" placeholder="Categoria" style="flex:1;">
                </div>
                <button type="button" onclick="kbRemoveService(${index})" class="button button-link-delete" style="color:#dc2626; margin-left:10px;"><span class="dashicons dashicons-trash"></span></button>
            </div>
            <textarea rows="3" style="width:100%; font-size:13px;" onchange="updateService(${index}, 'description', this.value)" placeholder="Descrizione e linee guida per l'AI...">${escapeHtml(s.description || '')}</textarea>
        </div>`;
    });
    document.getElementById('ui-services').innerHTML = html;
    document.getElementById('raw-services').value = JSON.stringify(servicesData);
}

function updateService(i, key, val) { servicesData[i][key] = val; renderServices(); }
function kbAddService() { servicesData.push({id: crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(), title:'', category:'', description:''}); renderServices(); }
function kbRemoveService(i) { if(confirm('Rimuovere?')){ servicesData.splice(i, 1); renderServices(); } }

// --- UI per Techs (Array of Strings) ---
let techsData = [];
try { techsData = JSON.parse(document.getElementById('raw-techs').value || '[]'); } catch(e){}

function renderTechs() {
    let html = '';
    techsData.forEach((t, index) => {
        html += `
        <div style="display:flex; gap:10px; margin-bottom:8px;">
            <input type="text" value="${escapeHtml(t || '')}" onchange="updateTech(${index}, this.value)" placeholder="Nome e Descrizione Tecnologia" style="flex:1;">
            <button type="button" onclick="kbRemoveTech(${index})" class="button button-link-delete" style="color:#dc2626;"><span class="dashicons dashicons-trash"></span></button>
        </div>`;
    });
    document.getElementById('ui-techs').innerHTML = html;
    document.getElementById('raw-techs').value = JSON.stringify(techsData);
}

function updateTech(i, val) { techsData[i] = val; renderTechs(); }
function kbAddTech() { techsData.push(''); renderTechs(); }
function kbRemoveTech(i) { techsData.splice(i, 1); renderTechs(); }

// --- UI per Products (Array of Strings) ---
let productsData = [];
try { productsData = JSON.parse(document.getElementById('raw-products').value || '[]'); } catch(e){}

function renderProducts() {
    let html = '';
    productsData.forEach((p, index) => {
        html += `
        <div style="display:flex; gap:10px; margin-bottom:8px;">
            <input type="text" value="${escapeHtml(p || '')}" onchange="updateProduct(${index}, this.value)" placeholder="Nome Brand e Prodotti" style="flex:1;">
            <button type="button" onclick="kbRemoveProduct(${index})" class="button button-link-delete" style="color:#dc2626;"><span class="dashicons dashicons-trash"></span></button>
        </div>`;
    });
    document.getElementById('ui-products').innerHTML = html;
    document.getElementById('raw-products').value = JSON.stringify(productsData);
}
function updateProduct(i, val) { productsData[i] = val; renderProducts(); }
function kbAddProduct() { productsData.push(''); renderProducts(); }
function kbRemoveProduct(i) { productsData.splice(i, 1); renderProducts(); }

// --- UI per FAQ (Array of Objects) ---
let faqsData = [];
try { faqsData = JSON.parse(document.getElementById('raw-faqs').value || '[]'); } catch(e){}

function renderFaqs() {
    let html = '';
    faqsData.forEach((f, index) => {
        html += `
        <div style="background:#fff; border:1px solid #e5e7eb; padding:15px; margin-bottom:10px; border-radius:8px;">
            <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:10px;">
                <input type="text" value="${escapeHtml(f.q || '')}" onchange="updateFaq(${index}, 'q', this.value)" placeholder="Domanda Frequente (Es: Quali orari fate?)" style="flex:1; font-weight:600;">
                <button type="button" onclick="kbRemoveFaq(${index})" class="button button-link-delete" style="color:#dc2626; margin-left:10px;"><span class="dashicons dashicons-trash"></span></button>
            </div>
            <textarea rows="2" style="width:100%; font-size:13px;" onchange="updateFaq(${index}, 'a', this.value)" placeholder="Risposta...">${escapeHtml(f.a || '')}</textarea>
        </div>`;
    });
    document.getElementById('ui-faqs').innerHTML = html;
    document.getElementById('raw-faqs').value = JSON.stringify(faqsData);
}

function updateFaq(i, key, val) { faqsData[i][key] = val; renderFaqs(); }
function kbAddFaq() { faqsData.push({q:'', a:''}); renderFaqs(); }
function kbRemoveFaq(i) { if(confirm('Rimuovere?')){ faqsData.splice(i, 1); renderFaqs(); } }

function escapeHtml(unsafe) {
    return unsafe
         .replace(/&/g, "&amp;")
         .replace(/</g, "&lt;")
         .replace(/>/g, "&gt;")
         .replace(/"/g, "&quot;")
         .replace(/'/g, "&#039;");
}

// Inizializza tutto
document.addEventListener('DOMContentLoaded', function() {
    renderServices();
    renderTechs();
    renderProducts();
    renderFaqs();
});
</script>
