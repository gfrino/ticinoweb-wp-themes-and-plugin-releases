<div id="ticino-ai-chatbot-container" class="ticino-ai-chatbot-closed">
    <!-- Overlay Mobile -->
    <div id="ticino-ai-chatbot-overlay"></div>

    <!-- Pulsante Flottante -->
    <button id="ticino-ai-chatbot-trigger" aria-label="Apri assistente virtuale">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon-chat"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon-close" style="display:none;"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
    </button>

    <!-- Finestra Chat -->
    <div id="ticino-ai-chatbot-window">
        <div class="ticino-ai-chatbot-header">
            <div class="ticino-ai-header-info">
                <span class="ticino-ai-bot-avatar">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2a10 10 0 1 0 10 10H12V2z"></path><path d="M12 12 2.1 7.1"></path><path d="M12 12l9.9 4.9"></path></svg>
                </span>
                <div>
                    <strong><?php echo esc_html(get_option('ticino_ai_bot_name', 'Assistente virtuale')); ?></strong>
                    <span class="ticino-ai-status">Online</span>
                </div>
            </div>
            <button id="ticino-ai-chatbot-minimize" aria-label="Minimizza">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
            </button>
        </div>

        <div id="ticino-ai-chatbot-messages">
            <!-- Messaggio di benvenuto generato via JS -->
        </div>

        <!-- Bottoni rapidi: popolati via JS da Impostazioni > Chatbot UI -->
        <div id="ticino-ai-chatbot-quick-replies"></div>

        <!-- Form guidato per appuntamenti rimosso in favore del flusso conversazionale -->
        <div class="ticino-ai-chatbot-input">
            <input type="text" id="ticino-ai-user-input" placeholder="Scrivi un messaggio..." autocomplete="off">
            <button id="ticino-ai-send-btn" aria-label="Invia messaggio">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
            </button>
        </div>
    </div>
</div>
