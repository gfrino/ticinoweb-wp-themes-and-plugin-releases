/* Showroom Lock — Promo online form */
(function () {
    'use strict';

    var form = document.getElementById('anp-form');
    if (!form || !window.aslPromo) {
        return;
    }

    var btn   = form.querySelector('.anp__submit');
    var label = btn.querySelector('.anp__submit-text');
    var busy  = btn.querySelector('.anp__submit-busy');
    var error = document.getElementById('anp-error');
    var done  = document.getElementById('anp-done');

    function setBusy(on) {
        btn.disabled = on;
        btn.setAttribute('aria-busy', on ? 'true' : 'false');
        label.hidden = on;
        busy.hidden  = !on;
    }

    function showError(msg) {
        error.textContent = msg;
        error.hidden = false;
    }

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        error.hidden = true;

        if (!form.reportValidity()) {
            return;
        }

        var data = new FormData(form);
        data.append('action', 'asl_promo_submit');
        data.append('nonce', window.aslPromo.nonce);

        setBusy(true);

        fetch(window.aslPromo.ajax_url, { method: 'POST', body: data, credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (res) {
                if (!res || !res.success) {
                    setBusy(false);
                    showError(res && res.data && res.data.message ? res.data.message : window.aslPromo.error);
                    return;
                }
                document.getElementById('anp-done-email').textContent = res.data.email || '';
                form.hidden = true;
                done.hidden = false;
                done.focus();
                done.scrollIntoView({ behavior: 'smooth', block: 'center' });
            })
            .catch(function () {
                setBusy(false);
                showError(window.aslPromo.error);
            });
    });
})();
