<?php
/**
 * Promo online: booking form with discount on a page without header and footer.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ASL_Promo {

    /** Option key used in wp_options */
    const OPTION = 'asl_promo_settings';

    /** Requests table (without prefix) */
    const TABLE = 'asl_promo_requests';

    /** Bump when the table schema changes */
    const DB_VERSION = '1';

    /** Page template slug registered by the plugin */
    const TEMPLATE = 'asl-promo-blank.php';

    const SHORTCODE = 'autonec_promo';

    /** Max submissions per IP in RATE_WINDOW seconds */
    const RATE_LIMIT  = 5;
    const RATE_WINDOW = 900;

    /* -------------------------------------------------------------- */
    /*  Bootstrap                                                      */
    /* -------------------------------------------------------------- */

    public function init(): void {
        add_shortcode( self::SHORTCODE, [ $this, 'render_shortcode' ] );
        add_filter( 'theme_page_templates', [ $this, 'register_template' ] );
        add_filter( 'template_include',     [ $this, 'load_template' ], 99 );
        add_action( 'template_redirect',    [ $this, 'disable_cache' ] );
        add_action( 'wp_enqueue_scripts',   [ $this, 'enqueue' ] );
        add_action( 'wp_ajax_asl_promo_submit',        [ $this, 'handle_ajax' ] );
        add_action( 'wp_ajax_nopriv_asl_promo_submit', [ $this, 'handle_ajax' ] );
        add_action( 'admin_init', [ __CLASS__, 'maybe_create_table' ] );
    }

    /* -------------------------------------------------------------- */
    /*  Settings                                                       */
    /* -------------------------------------------------------------- */

    public static function defaults(): array {
        return [
            'page_id'        => 0,
            'discount'       => 5,
            'logo_id'        => 0,
            'logo_suffix'    => '',
            'recipients'     => '',
            'privacy_url'    => '',
            'email_subject'  => __( '{sito} — Abbiamo ricevuto la tua prenotazione', 'autonec-showroom-lock' ),
            'email_template' => self::default_email(),
        ];
    }

    public static function default_email(): string {
        return __( "Gentile {nome} {cognome},\n\ngrazie per aver prenotato l'acquisto online.\n\nAbbiamo riservato per te lo sconto del {sconto}% sull'auto che hai scelto:\n\n🚗  Auto n.: {numero_auto}\n🏷  Modello: {modello}\n💳  Pagamento: {pagamento}\n\nTi contatteremo al più presto. La promozione è confermata con la firma del contratto; in caso di leasing l'acquisto è da intendersi salvo concessione del credito.\n\nCordiali saluti,\n{sito}", 'autonec-showroom-lock' );
    }

    public static function get( string $key = '' ) {
        $opts = wp_parse_args( (array) get_option( self::OPTION, [] ), self::defaults() );
        if ( '' === $key ) {
            return $opts;
        }
        return $opts[ $key ] ?? null;
    }

    public static function discount(): int {
        return max( 1, min( 50, absint( self::get( 'discount' ) ) ) );
    }

    public static function payment_labels(): array {
        return [
            'leasing' => __( 'Leasing', 'autonec-showroom-lock' ),
            'cash'    => __( 'Cash', 'autonec-showroom-lock' ),
        ];
    }

    /** Notification recipients: promo setting, else Showroom Lock e-mails, else site admin. */
    public static function recipients(): array {
        foreach ( [ self::get( 'recipients' ), ASL_Admin::get( 'notification_emails', '' ) ] as $raw ) {
            $list = array_filter( array_map( 'trim', preg_split( '/[,;\s]+/', (string) $raw, -1, PREG_SPLIT_NO_EMPTY ) ), 'is_email' );
            if ( $list ) {
                return array_values( $list );
            }
        }
        return [ get_option( 'admin_email' ) ];
    }

    public static function logo_url(): string {
        $id = absint( self::get( 'logo_id' ) ) ?: absint( get_theme_mod( 'custom_logo' ) );
        return $id ? (string) wp_get_attachment_image_url( $id, 'medium_large' ) : '';
    }

    public static function privacy_url(): string {
        return (string) ( self::get( 'privacy_url' ) ?: get_privacy_policy_url() );
    }

    /* -------------------------------------------------------------- */
    /*  Table                                                          */
    /* -------------------------------------------------------------- */

    public static function table(): string {
        global $wpdb;
        return $wpdb->prefix . self::TABLE;
    }

    public static function maybe_create_table(): void {
        if ( get_option( 'asl_promo_db_version' ) === self::DB_VERSION ) {
            return;
        }
        self::create_table();
    }

    public static function create_table(): void {
        global $wpdb;
        $table   = self::table();
        $charset = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table} (
            id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            first_name  VARCHAR(100) NOT NULL DEFAULT '',
            last_name   VARCHAR(100) NOT NULL DEFAULT '',
            address     VARCHAR(255) NOT NULL DEFAULT '',
            email       VARCHAR(100) NOT NULL DEFAULT '',
            phone       VARCHAR(50)  NOT NULL DEFAULT '',
            car_number  VARCHAR(50)  NOT NULL DEFAULT '',
            model       VARCHAR(150) NOT NULL DEFAULT '',
            payment     VARCHAR(20)  NOT NULL DEFAULT '',
            discount    TINYINT UNSIGNED NOT NULL DEFAULT 0,
            locale      VARCHAR(20)  NOT NULL DEFAULT '',
            ip_address  VARCHAR(45)  NOT NULL DEFAULT '',
            created_gmt DATETIME     NOT NULL,
            PRIMARY KEY  (id),
            KEY idx_created (created_gmt)
        ) {$charset};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
        update_option( 'asl_promo_db_version', self::DB_VERSION );
    }

    public static function insert( array $data ): int {
        global $wpdb;
        $wpdb->insert( self::table(), [
            'first_name'  => $data['first_name'],
            'last_name'   => $data['last_name'],
            'address'     => $data['address'],
            'email'       => $data['email'],
            'phone'       => $data['phone'],
            'car_number'  => $data['car_number'],
            'model'       => $data['model'],
            'payment'     => $data['payment'],
            'discount'    => $data['discount'],
            'locale'      => $data['locale'],
            'ip_address'  => $data['ip_address'],
            'created_gmt' => current_time( 'mysql', true ),
        ], [ '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s' ] );

        return (int) $wpdb->insert_id;
    }

    public static function get_all( int $limit = 500 ): array {
        global $wpdb;
        $table = self::table();
        return (array) $wpdb->get_results(
            $wpdb->prepare( "SELECT * FROM {$table} ORDER BY id DESC LIMIT %d", $limit )
        );
    }

    public static function delete_by_ids( array $ids ): int {
        global $wpdb;
        $ids = array_filter( array_map( 'absint', $ids ) );
        if ( empty( $ids ) ) {
            return 0;
        }
        $table        = self::table();
        $placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
        return (int) $wpdb->query(
            $wpdb->prepare( "DELETE FROM {$table} WHERE id IN ({$placeholders})", ...$ids )
        );
    }

    /* -------------------------------------------------------------- */
    /*  Page without header and footer                                 */
    /* -------------------------------------------------------------- */

    public function register_template( array $templates ): array {
        $templates[ self::TEMPLATE ] = __( 'Pagina vuota (senza header e footer)', 'autonec-showroom-lock' );
        return $templates;
    }

    public static function is_blank_page(): bool {
        return is_page() && self::TEMPLATE === get_page_template_slug( get_queried_object_id() );
    }

    public function load_template( string $template ): string {
        return self::is_blank_page() ? ASL_PLUGIN_DIR . 'templates/promo-blank.php' : $template;
    }

    /** The form carries a nonce: never serve it from page cache. */
    public function disable_cache(): void {
        if ( ! $this->page_has_form() ) {
            return;
        }
        if ( ! defined( 'DONOTCACHEPAGE' ) ) {
            define( 'DONOTCACHEPAGE', true );
        }
        do_action( 'litespeed_control_set_nocache', 'autonec promo form' );
        nocache_headers();
    }

    private function page_has_form(): bool {
        if ( ! is_singular() ) {
            return false;
        }
        $post = get_queried_object();
        return self::is_blank_page() || has_shortcode( $post->post_content ?? '', self::SHORTCODE );
    }

    /* -------------------------------------------------------------- */
    /*  Assets                                                         */
    /* -------------------------------------------------------------- */

    public function enqueue(): void {
        if ( ! $this->page_has_form() ) {
            return;
        }

        wp_enqueue_style( 'asl-promo', ASL_PLUGIN_URL . 'assets/css/promo.css', [], ASL_VERSION );
        wp_enqueue_script( 'asl-promo', ASL_PLUGIN_URL . 'assets/js/promo.js', [], ASL_VERSION, true );
        wp_localize_script( 'asl-promo', 'aslPromo', [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'asl_promo' ),
            'error'    => __( 'Invio non riuscito. Controlla la connessione e riprova.', 'autonec-showroom-lock' ),
        ] );
    }

    /* -------------------------------------------------------------- */
    /*  Shortcode                                                      */
    /* -------------------------------------------------------------- */

    public function render_shortcode(): string {
        $discount = self::discount();
        $logo     = self::logo_url();
        $suffix   = (string) self::get( 'logo_suffix' );
        $privacy  = self::privacy_url();
        $company  = get_bloginfo( 'name' );

        $fields = [
            'first_name' => [ __( 'Nome', 'autonec-showroom-lock' ), 'text', 'given-name' ],
            'last_name'  => [ __( 'Cognome', 'autonec-showroom-lock' ), 'text', 'family-name' ],
            'address'    => [ __( 'Indirizzo', 'autonec-showroom-lock' ), 'text', 'street-address' ],
            'email'      => [ __( 'E-mail', 'autonec-showroom-lock' ), 'email', 'email' ],
            'phone'      => [ __( 'Numero di telefono', 'autonec-showroom-lock' ), 'tel', 'tel' ],
            'car_number' => [ __( 'Numero dell’auto scelta', 'autonec-showroom-lock' ), 'text', 'off' ],
            'model'      => [ __( 'Modello', 'autonec-showroom-lock' ), 'text', 'off' ],
        ];

        $consent = sprintf(
            /* translators: %s: privacy policy link with the company name */
            __( 'Acconsento al trattamento dei dati personali inseriti nel presente modulo a scopi commerciali, in conformità all’informativa privacy di %s.', 'autonec-showroom-lock' ),
            $privacy
                ? '<a href="' . esc_url( $privacy ) . '" target="_blank" rel="noopener">' . esc_html( $company ) . '</a>'
                : esc_html( $company )
        );

        ob_start();
        ?>
        <div class="anp">
            <div class="anp__sheet">
                <header class="anp__hero">
                    <?php if ( $logo || '' !== $suffix ) : ?>
                        <div class="anp__logo">
                            <?php if ( $logo ) : ?>
                                <img src="<?php echo esc_url( $logo ); ?>" alt="<?php echo esc_attr( $company ); ?>" decoding="async">
                            <?php endif; ?>
                            <?php if ( '' !== $suffix ) : ?>
                                <span class="anp__logo-suffix"><?php echo esc_html( $suffix ); ?></span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <h1 class="anp__title">
                        <span class="anp__title-top"><?php esc_html_e( 'La tua prossima auto', 'autonec-showroom-lock' ); ?></span>
                        <span class="anp__title-accent"><?php esc_html_e( 'ti aspetta!', 'autonec-showroom-lock' ); ?></span>
                    </h1>

                    <div class="anp__promo">
                        <span class="anp__promo-icon" aria-hidden="true">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M17 7 7 17"/><circle cx="8" cy="8" r="2.2"/><circle cx="16" cy="16" r="2.2"/></svg>
                        </span>
                        <p class="anp__promo-text">
                            <strong class="anp__promo-head"><?php esc_html_e( 'Promo online:', 'autonec-showroom-lock' ); ?></strong>
                            <span class="anp__promo-line"><?php esc_html_e( 'Assicurati ora il tuo sconto del', 'autonec-showroom-lock' ); ?></span>
                            <span class="anp__promo-sub"><?php esc_html_e( 'prenotando l’acquisto.', 'autonec-showroom-lock' ); ?></span>
                        </p>
                        <span class="anp__promo-value"><?php echo esc_html( $discount ); ?>%</span>
                    </div>
                </header>

                <section class="anp__card" aria-labelledby="anp-card-title">
                    <h2 class="anp__card-head" id="anp-card-title">
                        <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h7"/><path d="M14 2v5h5"/><path d="M8 11h7M8 15h4"/><path d="m19.5 12.5 2 2L15 21h-2v-2z"/></svg>
                        <?php esc_html_e( 'Compila il modulo', 'autonec-showroom-lock' ); ?>
                    </h2>

                    <form class="anp__form" id="anp-form" method="post">
                        <?php foreach ( $fields as $name => [ $label, $type, $autocomplete ] ) : ?>
                            <div class="anp__field">
                                <label class="anp__label" for="anp-<?php echo esc_attr( $name ); ?>"><?php echo esc_html( $label ); ?> <span class="anp__req" aria-hidden="true">*</span></label>
                                <input class="anp__input" type="<?php echo esc_attr( $type ); ?>" id="anp-<?php echo esc_attr( $name ); ?>"
                                       name="<?php echo esc_attr( $name ); ?>" autocomplete="<?php echo esc_attr( $autocomplete ); ?>"
                                       maxlength="<?php echo 'address' === $name ? 200 : 100; ?>" required>
                            </div>
                        <?php endforeach; ?>

                        <fieldset class="anp__choice">
                            <legend class="anp__choice-legend"><?php esc_html_e( 'Modalità di pagamento', 'autonec-showroom-lock' ); ?> <span class="anp__req" aria-hidden="true">*</span></legend>
                            <div class="anp__choice-options">
                                <?php foreach ( self::payment_labels() as $value => $label ) : ?>
                                    <label class="anp__option">
                                        <input type="radio" name="payment" value="<?php echo esc_attr( $value ); ?>" required>
                                        <span class="anp__box" aria-hidden="true"></span>
                                        <span><?php echo esc_html( $label ); ?></span>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        </fieldset>

                        <label class="anp__consent">
                            <input type="checkbox" name="consent" value="1" required>
                            <span class="anp__box" aria-hidden="true"></span>
                            <span class="anp__consent-text"><?php echo wp_kses( $consent, [ 'a' => [ 'href' => [], 'target' => [], 'rel' => [] ] ] ); ?></span>
                        </label>

                        <div class="anp__hp" aria-hidden="true">
                            <label for="anp-website">Website</label>
                            <input type="text" id="anp-website" name="website" tabindex="-1" autocomplete="off">
                        </div>

                        <p class="anp__error" id="anp-error" role="alert" hidden></p>

                        <button type="submit" class="anp__submit">
                            <span class="anp__submit-text">
                                <?php
                                /* translators: %d: discount percentage */
                                echo esc_html( sprintf( __( 'Prenota il mio sconto del %d%%', 'autonec-showroom-lock' ), $discount ) );
                                ?>
                            </span>
                            <span class="anp__submit-busy" hidden><?php esc_html_e( 'Invio in corso…', 'autonec-showroom-lock' ); ?></span>
                        </button>
                    </form>

                    <div class="anp__done" id="anp-done" tabindex="-1" hidden>
                        <svg class="anp__done-icon" aria-hidden="true" viewBox="0 0 52 52"><circle cx="26" cy="26" r="24" fill="none" stroke="currentColor" stroke-width="3"/><path fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" d="m15 27 7 7 15-15"/></svg>
                        <h2 class="anp__done-title"><?php esc_html_e( 'Prenotazione ricevuta!', 'autonec-showroom-lock' ); ?></h2>
                        <p class="anp__done-text">
                            <?php
                            /* translators: %d: discount percentage */
                            echo esc_html( sprintf( __( 'Il tuo sconto del %d%% è riservato. Ti contatteremo al più presto per confermare l’acquisto.', 'autonec-showroom-lock' ), $discount ) );
                            ?>
                        </p>
                        <p class="anp__done-mail"><?php esc_html_e( 'Ti abbiamo inviato un riepilogo a:', 'autonec-showroom-lock' ); ?> <strong id="anp-done-email"></strong></p>
                    </div>
                </section>

                <ul class="anp__trust">
                    <li class="anp__trust-item">
                        <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/></svg>
                        <span><?php esc_html_e( 'Auto selezionate e controllate', 'autonec-showroom-lock' ); ?></span>
                    </li>
                    <li class="anp__trust-item">
                        <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>
                        <span><?php esc_html_e( 'Garanzia', 'autonec-showroom-lock' ); ?></span>
                    </li>
                    <li class="anp__trust-item">
                        <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m11 17 2 2a1 1 0 1 0 3-3"/><path d="m14 14 2.5 2.5a1 1 0 1 0 3-3l-3.88-3.88a3 3 0 0 0-4.24 0l-.88.88a1 1 0 1 1-3-3l2.81-2.81a5.79 5.79 0 0 1 7.06-.87l.47.28a2 2 0 0 0 1.42.25L21 4"/><path d="m21 3 1 11h-2"/><path d="M3 3 2 14l6.5 6.5a1 1 0 1 0 3-3"/><path d="M3 4h8"/></svg>
                        <span><?php esc_html_e( 'Soluzioni di finanziamento', 'autonec-showroom-lock' ); ?></span>
                    </li>
                    <li class="anp__trust-item">
                        <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m21 8-2 2-1.5-3.7A2 2 0 0 0 15.646 5H8.4a2 2 0 0 0-1.903 1.257L5 10 3 8"/><path d="M7 14h.01"/><path d="M17 14h.01"/><rect width="18" height="8" x="3" y="10" rx="2"/><path d="M5 18v2"/><path d="M19 18v2"/></svg>
                        <span><?php esc_html_e( 'Assistenza post-vendita', 'autonec-showroom-lock' ); ?></span>
                    </li>
                </ul>

                <p class="anp__note"><?php esc_html_e( 'In caso di leasing l’acquisto è da intendersi salvo concessione del credito. Promo da confermarsi mediante firma contrattuale.', 'autonec-showroom-lock' ); ?></p>
            </div>
        </div>
        <?php
        return (string) ob_get_clean();
    }

    /* -------------------------------------------------------------- */
    /*  AJAX handler                                                   */
    /* -------------------------------------------------------------- */

    public function handle_ajax(): void {
        if ( ! check_ajax_referer( 'asl_promo', 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => __( 'La pagina è scaduta: ricaricala e invia di nuovo il modulo.', 'autonec-showroom-lock' ) ] );
        }

        /* Honeypot: bots fill every field. Pretend success, store nothing. */
        if ( '' !== trim( (string) wp_unslash( $_POST['website'] ?? '' ) ) ) {
            wp_send_json_success( [ 'email' => '' ] );
        }

        $ip      = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ?? '' ) );
        $rl_key  = 'asl_promo_rl_' . md5( $ip );
        $attempt = (int) get_transient( $rl_key );
        if ( $attempt >= self::RATE_LIMIT ) {
            wp_send_json_error( [ 'message' => __( 'Hai inviato troppe richieste. Riprova tra qualche minuto.', 'autonec-showroom-lock' ) ] );
        }

        $data = [];
        foreach ( [ 'first_name', 'last_name', 'address', 'email', 'phone', 'car_number', 'model' ] as $f ) {
            $data[ $f ] = mb_substr( trim( sanitize_text_field( wp_unslash( $_POST[ $f ] ?? '' ) ) ), 0, 'address' === $f ? 200 : 100 );
            if ( '' === $data[ $f ] ) {
                wp_send_json_error( [ 'message' => __( 'Compila tutti i campi obbligatori.', 'autonec-showroom-lock' ) ] );
            }
        }

        $data['email'] = sanitize_email( $data['email'] );
        if ( ! is_email( $data['email'] ) ) {
            wp_send_json_error( [ 'message' => __( 'Indirizzo e-mail non valido.', 'autonec-showroom-lock' ) ] );
        }

        $data['payment'] = sanitize_key( wp_unslash( $_POST['payment'] ?? '' ) );
        if ( ! isset( self::payment_labels()[ $data['payment'] ] ) ) {
            wp_send_json_error( [ 'message' => __( 'Scegli la modalità di pagamento.', 'autonec-showroom-lock' ) ] );
        }

        if ( empty( $_POST['consent'] ) ) {
            wp_send_json_error( [ 'message' => __( 'Per inviare il modulo serve il consenso al trattamento dei dati.', 'autonec-showroom-lock' ) ] );
        }

        set_transient( $rl_key, $attempt + 1, self::RATE_WINDOW );

        $data['phone']      = ASL_Frontend::normalize_phone( $data['phone'] );
        $data['discount']   = self::discount();
        $data['locale']     = determine_locale();
        $data['ip_address'] = $ip;

        self::maybe_create_table();
        self::insert( $data );

        $this->notify_admins( $data );
        $this->send_confirmation( $data );

        wp_send_json_success( [ 'email' => $data['email'] ] );
    }

    /* -------------------------------------------------------------- */
    /*  E-mails                                                        */
    /* -------------------------------------------------------------- */

    private function notify_admins( array $data ): void {
        $payment = self::payment_labels()[ $data['payment'] ];

        $subject = sprintf(
            /* translators: 1: site name, 2: customer full name */
            __( '[%1$s] Nuova prenotazione promo online — %2$s', 'autonec-showroom-lock' ),
            get_bloginfo( 'name' ),
            $data['first_name'] . ' ' . $data['last_name']
        );

        $rows = [
            __( 'Data/Ora', 'autonec-showroom-lock' )            => wp_date( 'd/m/Y H:i' ),
            __( 'Nome', 'autonec-showroom-lock' )                => $data['first_name'],
            __( 'Cognome', 'autonec-showroom-lock' )             => $data['last_name'],
            __( 'Indirizzo', 'autonec-showroom-lock' )           => $data['address'],
            __( 'E-mail', 'autonec-showroom-lock' )              => $data['email'],
            __( 'Telefono', 'autonec-showroom-lock' )            => $data['phone'],
            __( 'Numero auto', 'autonec-showroom-lock' )         => $data['car_number'],
            __( 'Modello', 'autonec-showroom-lock' )             => $data['model'],
            __( 'Pagamento', 'autonec-showroom-lock' )           => $payment,
            __( 'Sconto riservato', 'autonec-showroom-lock' )    => $data['discount'] . '%',
        ];

        $body = __( 'Un cliente ha prenotato l’acquisto con la promo online.', 'autonec-showroom-lock' ) . "\n\n";
        foreach ( $rows as $label => $value ) {
            $body .= $label . ': ' . $value . "\n";
        }
        $body .= "\n" . __( 'Il cliente ha dato il consenso al trattamento dei dati a scopi commerciali.', 'autonec-showroom-lock' ) . "\n";

        $headers = [
            'Content-Type: text/plain; charset=UTF-8',
            'Reply-To: ' . $data['email'],
        ];

        foreach ( self::recipients() as $to ) {
            wp_mail( $to, $subject, $body, $headers );
        }
    }

    private function send_confirmation( array $data ): void {
        $placeholders = [
            '{nome}'        => $data['first_name'],
            '{cognome}'     => $data['last_name'],
            '{numero_auto}' => $data['car_number'],
            '{modello}'     => $data['model'],
            '{pagamento}'   => self::payment_labels()[ $data['payment'] ],
            '{sconto}'      => (string) $data['discount'],
            '{sito}'        => get_bloginfo( 'name' ),
        ];

        $subject = trim( (string) self::get( 'email_subject' ) ) ?: self::defaults()['email_subject'];
        $body    = trim( (string) self::get( 'email_template' ) ) ?: self::default_email();

        wp_mail(
            $data['email'],
            strtr( $subject, $placeholders ),
            strtr( $body, $placeholders ),
            [ 'Content-Type: text/plain; charset=UTF-8' ]
        );
    }

    public static function placeholders(): array {
        return [
            '{nome}'        => __( 'Nome del cliente', 'autonec-showroom-lock' ),
            '{cognome}'     => __( 'Cognome del cliente', 'autonec-showroom-lock' ),
            '{numero_auto}' => __( 'Numero dell’auto scelta', 'autonec-showroom-lock' ),
            '{modello}'     => __( 'Modello', 'autonec-showroom-lock' ),
            '{pagamento}'   => __( 'Leasing o Cash', 'autonec-showroom-lock' ),
            '{sconto}'      => __( 'Percentuale di sconto', 'autonec-showroom-lock' ),
            '{sito}'        => __( 'Nome del sito', 'autonec-showroom-lock' ),
        ];
    }
}
