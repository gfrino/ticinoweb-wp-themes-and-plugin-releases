<?php
/**
 * Plugin Name: Autonec Showroom Lock
 * Plugin URI:  https://github.com/gfrino/wp-plugins
 * Description: Showroom self-service: il visitatore compila un modulo e riceve il codice della porta per e-mail e SMS. In più una pagina «Promo online» senza header né footer, dove il cliente prenota l'acquisto dell'auto con lo sconto.
 * Version:     1.2.0
 * Author:      ticinoWEB
 * Author URI:  https://ticinoweb.com
 * License:     GPL-2.0+
 * Text Domain: autonec-showroom-lock
 * Requires PHP: 8.0
 * Update URI:  https://github.com/gfrino/ticinoweb-wp-themes-and-plugin-releases
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'ASL_VERSION', '1.2.0' );
define( 'ASL_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'ASL_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
// Version of the bundled includes/tw-release-updater.php (keep in sync with its header).
define( 'ASL_RELEASE_UPDATER_VERSION', '1.2.0' );

/* ------------------------------------------------------------------ */
/*  Updates from the ticinoWEB releases repo (see Update URI header).   */
/*  The loader is also installed as a mu-plugin; if that is already    */
/*  loaded this include is a no-op.                                    */
/* ------------------------------------------------------------------ */
require_once ASL_PLUGIN_DIR . 'includes/tw-release-updater.php';

function asl_install_release_updater(): void {
    if ( ! class_exists( 'TW_Release_Updater' ) || TW_Release_Updater::mu_is_current( ASL_RELEASE_UPDATER_VERSION ) ) {
        return;
    }
    if ( get_site_transient( 'asl_release_updater_failed' ) ) {
        return;
    }
    $result = TW_Release_Updater::install_mu( ASL_PLUGIN_DIR . 'includes/tw-release-updater.php' );
    if ( is_wp_error( $result ) ) {
        set_site_transient( 'asl_release_updater_failed', $result->get_error_message(), 12 * HOUR_IN_SECONDS );
    }
}
add_action( 'admin_init', function (): void {
    if ( current_user_can( is_multisite() ? 'manage_network_plugins' : 'activate_plugins' ) ) {
        asl_install_release_updater();
    }
}, 20 );

/* ------------------------------------------------------------------ */
/*  Autoload includes                                                  */
/* ------------------------------------------------------------------ */
require_once ASL_PLUGIN_DIR . 'includes/class-admin.php';
require_once ASL_PLUGIN_DIR . 'includes/class-frontend.php';
require_once ASL_PLUGIN_DIR . 'includes/class-visitors.php';
require_once ASL_PLUGIN_DIR . 'includes/class-twilio.php';
require_once ASL_PLUGIN_DIR . 'includes/class-promo.php';
require_once ASL_PLUGIN_DIR . 'includes/class-promo-admin.php';

/* ------------------------------------------------------------------ */
/*  Activation – create visitors table + seed default options          */
/* ------------------------------------------------------------------ */
register_activation_hook( __FILE__, function (): void {
    ASL_Visitors::create_table();
    ASL_Promo::create_table();
    ASL_Admin::seed_defaults();
    asl_install_release_updater();
} );

/* ------------------------------------------------------------------ */
/*  Boot                                                               */
/* ------------------------------------------------------------------ */
add_action( 'plugins_loaded', function (): void {
    load_plugin_textdomain( 'autonec-showroom-lock', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
    ( new ASL_Admin() )->init();
    ( new ASL_Frontend() )->init();
    ( new ASL_Promo() )->init();
    ( new ASL_Promo_Admin() )->init();
} );

/* ------------------------------------------------------------------ */
/*  AJAX – Twilio test connection (admin only)                         */
/* ------------------------------------------------------------------ */
add_action( 'wp_ajax_asl_twilio_test', function (): void {
    check_ajax_referer( 'asl_twilio_test', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => 'Permesso negato.' ] );
    }

    $result = ASL_Twilio::test_connection();

    if ( $result['success'] ) {
        wp_send_json_success( [
            'message' => sprintf( '✅ Connessione riuscita! Account: %s', $result['friendly_name'] ),
        ] );
    } else {
        wp_send_json_error( [
            'message' => '❌ ' . ( $result['error'] ?? 'Errore sconosciuto' ),
        ] );
    }
} );

/* ------------------------------------------------------------------ */
/*  AJAX – Delete visitors (admin only)                                */
/* ------------------------------------------------------------------ */
add_action( 'wp_ajax_asl_delete_visitors', function (): void {
    check_ajax_referer( 'asl_visitors_action', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => 'Permesso negato.' ] );
    }

    $ids = array_map( 'absint', (array) ( $_POST['ids'] ?? [] ) );

    if ( empty( $ids ) ) {
        wp_send_json_error( [ 'message' => 'Nessun visitatore selezionato.' ] );
    }

    $deleted = ASL_Visitors::delete_by_ids( $ids );

    wp_send_json_success( [
        'message' => sprintf( '%d visitator%s eliminat%s.', $deleted, $deleted === 1 ? 'e' : 'i', $deleted === 1 ? 'o' : 'i' ),
        'deleted' => $deleted,
    ] );
} );

/* ------------------------------------------------------------------ */
/*  AJAX – Export visitors CSV (admin only)                            */
/* ------------------------------------------------------------------ */
add_action( 'wp_ajax_asl_export_csv', function (): void {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( 'Permesso negato.' );
    }

    check_admin_referer( 'asl_export_csv' );

    $visitors = ASL_Visitors::get_all( 10000 );

    header( 'Content-Type: text/csv; charset=UTF-8' );
    header( 'Content-Disposition: attachment; filename="visitatori-showroom-' . wp_date( 'Y-m-d' ) . '.csv"' );
    header( 'Pragma: no-cache' );
    header( 'Expires: 0' );

    $out = fopen( 'php://output', 'w' );

    /* BOM for Excel UTF-8 compatibility */
    fwrite( $out, "\xEF\xBB\xBF" );

    /* Header row */
    fputcsv( $out, [ 'ID', 'Data/Ora', 'Nome', 'Cognome', 'Indirizzo', 'Telefono', 'E-mail', 'Codice', 'IP' ], ';' );

    foreach ( $visitors as $v ) {
        fputcsv( $out, [
            $v->id,
            wp_date( 'd/m/Y H:i', strtotime( $v->created_at ) ),
            $v->first_name,
            $v->last_name,
            $v->address,
            $v->phone,
            $v->email,
            $v->code_shown,
            $v->ip_address,
        ], ';' );
    }

    fclose( $out );
    exit;
} );
