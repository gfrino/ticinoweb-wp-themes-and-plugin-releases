<?php
/** Client-only secret game; catalog data remains owned by WooCommerce. */
defined('ABSPATH') || exit;

function adb_vineyard_wine() {
    $key = 'adb_vigna_' . substr(adb_search_rate_key(), -32);
    $bucket = get_transient($key);
    if (!is_array($bucket) || ($bucket['until'] ?? 0) <= time()) { $bucket = ['count' => 0, 'until' => time() + 60]; }
    if ($bucket['count'] >= 10) { return new WP_Error('adb_vigna_limit', __('Attendi un momento e riprova.', 'amicidibacco'), ['status' => 429]); }
    $bucket['count']++;
    set_transient($key, $bucket, max(1, $bucket['until'] - time()));
    $pool = adb_hero_wine_pool();
    $product = $pool ? $pool[wp_rand(0, count($pool) - 1)] : null;
    $item = null;
    if ($product) {
        $item = ['name' => wp_strip_all_tags($product->get_name()), 'winery' => wp_strip_all_tags($product->get_attribute('pa_cantina')),
            'url' => $product->get_permalink(), 'image' => wp_get_attachment_image_url($product->get_image_id(), 'woocommerce_thumbnail'),
            'price' => wp_kses($product->get_price_html(), ['span' => ['class' => true, 'aria-hidden' => true], 'bdi' => [], 'del' => ['aria-hidden' => true], 'ins' => ['aria-hidden' => true], 'small' => ['class' => true]])];
    }
    $response = new WP_REST_Response(['wine' => $item, 'catalog' => adb_catalog_url()]);
    $response->header('Cache-Control', 'no-store, max-age=0');
    return $response;
}
add_action('rest_api_init', static function () {
    register_rest_route('amicidibacco/v1', '/vineyard-wine', ['methods' => WP_REST_Server::READABLE, 'permission_callback' => '__return_true', 'callback' => 'adb_vineyard_wine']);
});

add_action('wp_enqueue_scripts', static function () {
    $base = get_stylesheet_directory_uri();
    wp_enqueue_script('adb-vigna-loader', $base . '/assets/js/vigna-loader.js', ['adb-search'], ADB_VERSION, true);
    wp_localize_script('adb-vigna-loader', 'adbVigna', [
        'module' => $base . '/assets/js/vigna-game.mjs?ver=' . ADB_VERSION, 'css' => $base . '/assets/css/vigna.css?ver=' . ADB_VERSION,
        'wineEndpoint' => rest_url('amicidibacco/v1/vineyard-wine'), 'catalog' => adb_catalog_url(),
        'strings' => [
            'title' => __('La vigna impossibile', 'amicidibacco'),
            'discover' => __('Continua la scoperta in enoteca', 'amicidibacco'),
            'loading' => __('Il paesaggio sta prendendo forma…', 'amicidibacco'),
            'failure' => __('Il paesaggio non si è caricato. Riprova oppure torna alla ricerca.', 'amicidibacco'),
            'rotate' => __('Ruota le terrazze e ricomponi i filari.', 'amicidibacco'),
            'view' => __('I filari sono pronti. Cambia prospettiva per unirli.', 'amicidibacco'),
            'matched' => __('Filari allineati: %d/3', 'amicidibacco'),
            'near' => __('I passaggi si stanno avvicinando…', 'amicidibacco'),
            'complete' => __('La vite ha trovato la sua strada.', 'amicidibacco'),
            'final' => __('La tua vigna è viva.', 'amicidibacco'),
            'finishText' => __('Hai ricomposto tre paesaggi. La scoperta continua tra le etichette della nostra enoteca.', 'amicidibacco'),
            'hint' => __('Un passaggio è stato allineato. Continua da qui.', 'amicidibacco'),
            'chapters' => [__('La prima luce', 'amicidibacco'), __('Tra le colline', 'amicidibacco'), __('L’ultimo filare', 'amicidibacco')],
            'terrace' => __('Terrazza %d', 'amicidibacco'),
            'simple' => __('Vista essenziale attiva: usa gli stessi comandi per completare la vigna.', 'amicidibacco'),
            'roundDone' => __('Paesaggio completato', 'amicidibacco'),
        ],
    ]);
}, 35);

add_action('wp_footer', static function () { ?>
<dialog class="adb-vigna" data-vigna aria-labelledby="adb-vigna-title" aria-describedby="adb-vigna-description">
    <div class="vigna-world" data-vigna-world></div>
    <div class="vigna-shade" aria-hidden="true"></div>
    <header class="vigna-header"><span class="vigna-signature"><?php echo esc_html(get_bloginfo('name')); ?></span><button type="button" class="vigna-exit" data-vigna-exit><?php esc_html_e('Esci', 'amicidibacco'); ?><?php echo adb_icon('close'); ?></button></header>
    <div class="vigna-heading"><h2 id="adb-vigna-title"><?php esc_html_e('La vigna', 'amicidibacco'); ?><em><?php esc_html_e('impossibile.', 'amicidibacco'); ?></em></h2><p id="adb-vigna-description"><?php esc_html_e('Tre terrazze, un punto di vista. Ricomponi i filari e lascia crescere la vite.', 'amicidibacco'); ?></p><button type="button" class="vigna-help" data-vigna-help aria-expanded="false" aria-controls="vigna-instructions"><?php esc_html_e('Come si gioca', 'amicidibacco'); ?><?php echo adb_icon('plus'); ?></button><div id="vigna-instructions" class="vigna-instructions" hidden><p><?php esc_html_e('Scegli una terrazza e ruotala con le frecce o trascinandola. Quando i tre filari si illuminano, trascina lo sfondo o sposta Prospettiva: i passaggi si uniranno solo dal punto giusto.', 'amicidibacco'); ?></p><p><?php esc_html_e('Da tastiera: 1, 2 e 3 scelgono la terrazza; frecce sinistra e destra la ruotano. Tutti i comandi sono disponibili anche qui sotto. Nessuna fretta: non c’è un conto alla rovescia.', 'amicidibacco'); ?></p><button type="button" data-vigna-simple><?php esc_html_e('Usa la vista essenziale', 'amicidibacco'); ?></button></div></div>
    <div class="vigna-loading" data-vigna-loading role="status"><?php esc_html_e('Il paesaggio sta prendendo forma…', 'amicidibacco'); ?></div>
    <div class="vigna-markers" data-vigna-markers aria-hidden="true"><span>1</span><span>2</span><span>3</span></div>
    <div class="vigna-plain" data-vigna-plain hidden aria-hidden="true"></div>
    <div class="vigna-controls" data-vigna-controls hidden>
        <div class="vigna-progress"><span data-vigna-chapter></span><span data-vigna-count></span><button type="button" data-vigna-hint><?php esc_html_e('Un indizio', 'amicidibacco'); ?></button></div>
        <p class="vigna-status" data-vigna-status role="status" aria-live="polite"></p>
        <div class="vigna-tools"><div class="vigna-turn"><div class="vigna-tabs" role="group" aria-label="<?php esc_attr_e('Scegli la terrazza', 'amicidibacco'); ?>"><?php for ($i=1;$i<=3;$i++) : ?><button type="button" data-vigna-select="<?php echo esc_attr($i-1); ?>" aria-pressed="<?php echo 1===$i?'true':'false'; ?>"><?php echo esc_html(sprintf(__('Terrazza %d', 'amicidibacco'),$i)); ?></button><?php endfor; ?></div><div class="vigna-arrows"><button type="button" data-vigna-turn="-1" aria-label="<?php esc_attr_e('Ruota la terrazza a sinistra', 'amicidibacco'); ?>"><?php echo adb_icon('arrow'); ?></button><button type="button" data-vigna-turn="1" aria-label="<?php esc_attr_e('Ruota la terrazza a destra', 'amicidibacco'); ?>"><?php echo adb_icon('arrow'); ?></button></div></div><label class="vigna-perspective"><span><?php esc_html_e('Prospettiva', 'amicidibacco'); ?><small data-vigna-view-state></small></span><input type="range" min="-55" max="55" step="1" value="0" data-vigna-view aria-label="<?php esc_attr_e('Cambia il punto di vista', 'amicidibacco'); ?>"></label></div>
        <button type="button" class="vigna-new" data-vigna-new><?php esc_html_e('Nuova vigna', 'amicidibacco'); ?></button>
    </div>
    <section class="vigna-finish" data-vigna-finish hidden aria-labelledby="vigna-finish-title"><h3 id="vigna-finish-title" tabindex="-1" data-vigna-finish-title></h3><p data-vigna-finish-text></p><div data-vigna-wine></div><button type="button" class="adb-button adb-button--light" data-vigna-next><?php esc_html_e('Il prossimo paesaggio', 'amicidibacco'); ?><?php echo adb_icon(); ?></button><button type="button" class="vigna-replay" data-vigna-replay hidden><?php esc_html_e('Gioca ancora', 'amicidibacco'); ?></button></section>
</dialog>
<?php }, 10);
