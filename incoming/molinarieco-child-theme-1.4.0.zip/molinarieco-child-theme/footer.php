<?php
/**
 * Garage Molinari footer. Content comes from the parent CMS and WordPress menus.
 *
 * @package Molinarieco
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$contact     = ticinoweb_get_contact_info();
$site_name   = ticinoweb_frontend_text( get_bloginfo( 'name' ), 'theme:branding:site_name' );
$site_description = ticinoweb_frontend_text( get_bloginfo( 'description' ), 'theme:branding:site_description' );
$logo_url    = ticinoweb_get_site_logo();
$logo_id     = $logo_url ? attachment_url_to_postid( $logo_url ) : 0;
$map_url     = trim( (string) get_option( 'ticinoweb_contact_map_url', '' ) );
$photo_url   = get_option( 'ticinoweb_page_bg_image', '' );
$photo_id    = $photo_url ? attachment_url_to_postid( $photo_url ) : 0;
$hours       = trim( (string) get_option( 'ticinoweb_contact_opening_hours', '' ) );
$phone       = ! empty( $contact['phone_display'] ) ? $contact['phone_display'] : ( $contact['phone'] ?? '' );
$phone_href  = preg_replace( '/[^0-9+]/', '', (string) $phone );
$legal_pages = array(
    'cookie-policy-ue' => __( 'Cookie Policy', 'molinarieco-child-theme' ),
    'impressum'        => __( 'Impressum', 'molinarieco-child-theme' ),
);
$published_legal = array();
foreach ( $legal_pages as $slug => $label ) {
    $page = get_page_by_path( $slug );
    if ( $page && 'publish' === $page->post_status ) {
        $published_legal[] = array( 'url' => get_permalink( $page ), 'label' => $label );
    }
}
$privacy_url = get_privacy_policy_url();
$social_links = array();
foreach ( array( 'instagram' => 'Instagram', 'facebook' => 'Facebook', 'linkedin' => 'LinkedIn' ) as $network => $label ) {
    if ( ! empty( $contact[ $network ] ) ) {
        $social_links[] = array( 'url' => $contact[ $network ], 'label' => $label );
    }
}
?>
<footer class="site-footer mol-footer" id="contatti">
    <div class="footer-container">
        <div class="footer-main">
            <div class="footer-brand">
                <a class="mol-footer-logo" href="<?php echo esc_url( ticinoweb_frontend_url( home_url( '/' ), 'theme:url:home' ) ); ?>" rel="home" aria-label="<?php echo esc_attr( $site_name ); ?>">
                    <?php if ( $logo_id ) : ?>
                        <?php echo wp_get_attachment_image( $logo_id, 'medium', false, array( 'alt' => $site_name, 'loading' => 'lazy' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WordPress escapes attachment markup. ?>
                    <?php elseif ( $logo_url ) : ?>
                        <img src="<?php echo esc_url( $logo_url ); ?>" alt="<?php echo esc_attr( $site_name ); ?>" width="300" height="104" loading="lazy">
                    <?php else : ?>
                        <span><?php echo esc_html( $site_name ); ?></span>
                    <?php endif; ?>
                </a>
                <?php if ( $site_description ) : ?>
                    <p class="footer-tagline"><?php echo esc_html( $site_description ); ?></p>
                <?php endif; ?>
                <?php if ( $social_links ) : ?>
                    <nav class="footer-social" aria-label="<?php esc_attr_e( 'Social', 'molinarieco-child-theme' ); ?>">
                        <?php foreach ( $social_links as $social ) : ?>
                            <a href="<?php echo esc_url( $social['url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $social['label'] ); ?></a>
                        <?php endforeach; ?>
                    </nav>
                <?php endif; ?>
            </div>

            <div class="footer-contact">
                <h2><?php esc_html_e( 'Contatti', 'molinarieco-child-theme' ); ?></h2>
                <address>
                    <?php if ( ! empty( $contact['address'] ) ) : ?>
                        <p><?php echo esc_html( $contact['address'] ); ?></p>
                    <?php endif; ?>
                    <?php if ( $phone ) : ?>
                        <p><a href="tel:<?php echo esc_attr( $phone_href ); ?>"><?php echo esc_html( $phone ); ?></a></p>
                    <?php endif; ?>
                    <?php if ( ! empty( $contact['email'] ) ) : ?>
                        <p><a href="mailto:<?php echo esc_attr( $contact['email'] ); ?>"><?php echo esc_html( $contact['email'] ); ?></a></p>
                    <?php endif; ?>
                    <?php if ( $hours ) : ?>
                        <p class="mol-footer-hours"><?php echo esc_html( $hours ); ?></p>
                    <?php endif; ?>
                </address>
                <?php if ( $privacy_url || $published_legal ) : ?>
                    <nav class="mol-footer-legal" aria-label="<?php esc_attr_e( 'Informazioni legali', 'molinarieco-child-theme' ); ?>">
                        <h3><?php esc_html_e( 'Legale', 'molinarieco-child-theme' ); ?></h3>
                        <ul>
                            <?php if ( $privacy_url ) : ?>
                                <li><a href="<?php echo esc_url( ticinoweb_frontend_url( $privacy_url, 'theme:url:privacy_policy' ) ); ?>"><?php esc_html_e( 'Privacy Policy', 'molinarieco-child-theme' ); ?></a></li>
                            <?php endif; ?>
                            <?php foreach ( $published_legal as $legal ) : ?>
                                <li><a href="<?php echo esc_url( $legal['url'] ); ?>"><?php echo esc_html( $legal['label'] ); ?></a></li>
                            <?php endforeach; ?>
                        </ul>
                    </nav>
                <?php endif; ?>
            </div>

            <nav class="footer-links" aria-label="<?php esc_attr_e( 'Servizi', 'molinarieco-child-theme' ); ?>">
                <h2><?php esc_html_e( 'Servizi', 'molinarieco-child-theme' ); ?></h2>
                <ul><?php do_action( 'ticinoweb_footer_links' ); ?></ul>
            </nav>

            <?php if ( has_nav_menu( 'primary' ) ) : ?>
                <nav class="footer-site" aria-label="<?php esc_attr_e( 'Sito', 'molinarieco-child-theme' ); ?>">
                    <h2><?php esc_html_e( 'Sito', 'molinarieco-child-theme' ); ?></h2>
                    <ul>
                        <?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'items_wrap' => '%3$s', 'depth' => 1 ) ); ?>
                    </ul>
                </nav>
            <?php endif; ?>

            <?php if ( $map_url ) : ?>
                <a class="footer-location" href="<?php echo esc_url( $map_url ); ?>" target="_blank" rel="noopener noreferrer">
                    <?php if ( $photo_id ) : ?>
                        <?php echo wp_get_attachment_image( $photo_id, 'medium_large', false, array( 'alt' => '', 'loading' => 'lazy' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WordPress escapes attachment markup. ?>
                    <?php elseif ( $photo_url ) : ?>
                        <img src="<?php echo esc_url( $photo_url ); ?>" alt="" width="1920" height="1245" loading="lazy" decoding="async">
                    <?php endif; ?>
                    <span class="footer-location-text"><strong><?php esc_html_e( 'Dove siamo', 'molinarieco-child-theme' ); ?></strong><span><?php esc_html_e( 'Indicazioni stradali', 'molinarieco-child-theme' ); ?> ↗</span></span>
                </a>
            <?php endif; ?>
        </div>

        <div class="footer-bottom">
            <p><?php echo esc_html( sprintf( __( '© %1$s %2$s. Tutti i diritti riservati.', 'molinarieco-child-theme' ), wp_date( 'Y' ), $site_name ) ); ?></p>
            <div class="footer-bottom-links">
                <a href="<?php echo esc_url( wp_login_url( admin_url() ) ); ?>"><?php esc_html_e( 'Area riservata', 'molinarieco-child-theme' ); ?></a>
                <span><?php esc_html_e( 'Design by', 'molinarieco-child-theme' ); ?> <a href="https://ticinoweb.com" target="_blank" rel="noopener noreferrer">ticinoWEB</a></span>
            </div>
        </div>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
