document.addEventListener('DOMContentLoaded', () => {
  const video = document.querySelector('.mol-hero-loop');
  const toggle = document.querySelector('[data-loop-toggle]');
  if (!video || !toggle) return;

  const motion = window.matchMedia('(prefers-reduced-motion: reduce)');

  function updateToggle() {
    const paused = video.paused;
    toggle.textContent = paused ? toggle.dataset.resumeText : toggle.dataset.pauseText;
    toggle.setAttribute('aria-label', paused ? toggle.dataset.resumeLabel : toggle.dataset.pauseLabel);
  }

  video.controls = false;
  toggle.hidden = false;
  video.addEventListener('play', updateToggle);
  video.addEventListener('pause', updateToggle);
  toggle.addEventListener('click', () => {
    if (video.paused) video.play().catch(() => { video.controls = true; });
    else video.pause();
    updateToggle();
  });
  motion.addEventListener('change', event => {
    if (event.matches) video.pause();
  });
  if (!motion.matches) video.play().catch(() => { video.controls = true; });
  updateToggle();
});
