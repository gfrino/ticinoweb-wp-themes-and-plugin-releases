<?php
/**
 * Header — LEGACY PARITY.
 *
 * Ricostruito sullo screenshot legacy, non reinterpretato. Dall'alto in basso:
 * una pastiglia con la lingua corrente allineata a destra, poi la riga con il logo
 * dentro una cornice sottile a sinistra e le cinque voci in maiuscoletto blu a
 * destra. Nessun filetto sotto l'header: nel legacy non c'e', verificato scorrendo
 * i pixel in cerca di una banda larga fra y=300 e y=420.
 *
 * COSA E' STATO RIMOSSO rispetto alla fase Legacy-Modernized, perche' non esiste
 * nello screenshot legacy: il pulsante blu CONTATTI, i chevron accanto alle voci,
 * il filetto animato sotto la voce al passaggio del puntatore, e il filetto
 * inferiore dell'header. Contatti resta raggiungibile dal footer, come nel legacy.
 *
 * LE CINQUE VOCI SONO SEMPRE VISIBILI, anche quando i figli non sono ancora
 * pubblicabili: e' la struttura del sito e non dipende dallo stato dei contenuti.
 * Un figlio non pubblicabile resta al suo posto e diventa non cliccabile, senza
 * href="#" e senza portare a una pagina vuota.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$tl_nav = tenconi_nav_mega();
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
	<?php if ( is_front_page() ) : ?>
		<script>
		/*
		 * In <head> e non in coda: la decisione deve essere presa PRIMA del primo
		 * disegno, altrimenti si vede la pagina e poi il velo.
		 *
		 * UNA VOLTA PER SESSIONE. Rivederla a ogni ritorno in home sarebbe una
		 * punizione da 13,78 MB e dieci secondi, non un'introduzione.
		 *
		 * try/catch perche' in navigazione privata sessionStorage puo' lanciare: in
		 * quel caso l'intro parte, che e' il male minore.
		 */
		try {
			if ( ! sessionStorage.getItem( 'tlIntro' ) ) {
				document.documentElement.setAttribute( 'data-tl-intro', '' );
			}
		} catch ( e ) {
			document.documentElement.setAttribute( 'data-tl-intro', '' );
		}
		</script>
	<?php endif; ?>
</head>
<body <?php body_class( 'tl' ); ?>>
<?php
/*
 * LO SPRITE DELLE ICONE, una volta sola per pagina. I diciassette glifi servono
 * nelle schede, nelle righe compatte e nel menu mobile — lo stesso puo' comparire
 * tre volte nella stessa pagina — quindi il tracciato sta scritto una volta e il
 * resto sono richiami con <use>.
 */
tenconi_mega_sprite();
?>
<?php
/*
 * IL FILTRO GELATINOSO del componente di riferimento, riprodotto tale e quale:
 * si sfoca la forma, si alza il contrasto dell'alfa con una matrice cosi' che la
 * sfocatura torni un bordo netto, e le forme vicine si fondono. La regione e'
 * allargata perche' un filtro taglia al proprio riquadro e il pannello sporge
 * sotto il campo.
 */
?>
<svg class="tl-sprite" aria-hidden="true" focusable="false" width="0" height="0">
	<defs>
		<filter id="tl-goo" x="-25%" y="-25%" width="150%" height="150%" color-interpolation-filters="sRGB">
			<feGaussianBlur in="SourceGraphic" stdDeviation="7" result="sfoca"/>
			<feColorMatrix in="sfoca" type="matrix" result="gelo"
				values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 19 -9"/>
			<feComposite in="SourceGraphic" in2="gelo" operator="atop"/>
		</filter>
	</defs>
</svg>
<?php wp_body_open(); ?>

<?php
/*
 * INTRO. Compare al primo caricamento della sessione e si puo' saltare.
 *
 * IL MARKUP E' QUI, lato server, e non creato dal JavaScript: creandolo dopo il
 * caricamento si vedrebbe per un istante la pagina, poi il velo — un lampo che
 * fa sembrare il sito rotto. Cosi' invece il velo c'e' gia' al primo disegno.
 *
 * E' NASCOSTO PER DIFETTO. Si accende solo se lo script in <head> ha messo
 * data-tl-intro su <html>, e quello script lo mette solo quando la sessione non
 * ha ancora visto l'intro. Senza JavaScript il velo non compare mai: il sito
 * resta usabile e nessuno resta chiuso fuori da un velo che non sa chiudere.
 *
 * SI VEDE UNA VOLTA PER SESSIONE. Rivederla a ogni pagina sarebbe una punizione,
 * non un'introduzione.
 */
$tl_intro = tenconi_media_da_nome( 'video-intro', 'video' );
$tl_intro_src = $tl_intro ? wp_get_attachment_url( $tl_intro ) : '';
$tl_intro_src = $tl_intro_src ? set_url_scheme( $tl_intro_src, 'relative' ) : '';

if ( is_front_page() && '' !== $tl_intro_src ) :
	?>
	<div class="tl-intro" data-tl-intro-velo hidden>
		<video
			class="tl-intro__v"
			data-src="<?php echo esc_url( $tl_intro_src ); ?>"
			muted
			playsinline
			preload="auto"
			aria-hidden="true"
			tabindex="-1"
		></video>

		<?php
		/*
		 * Il comando per saltare e' un <button>, non un link: non porta a un altro
		 * indirizzo, chiude una cosa. Ed e' il primo elemento raggiungibile da
		 * tastiera, cosi' chi non vede il filmato non deve cercarlo.
		 */
		?>
		<button class="tl-intro__salta" type="button" data-tl-intro-salta>
			Salta l’intro
		</button>
	</div>
	<?php
endif;
?>

<a class="tl-skip" href="#main"><?php echo esc_html( function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( 'Vai al contenuto principale', 'tenconi:ui:skip-link' ) : 'Vai al contenuto principale' ); ?></a>

<header class="tl-hd">

	<?php
	/*
	 * LA LINGUA. twtr_get_languages() e' calcolata qui, in cima al template, ma
	 * stampata piu' sotto DENTRO .tl-hd__bar e non in questa striscia — vedi il
	 * commento sulla ricerca poco piu' avanti per il motivo: sulla home la
	 * striscia chiude ad altezza zero scorrendo, e un selettore che sparisce non
	 * e' un selettore.
	 */
	$tl_lingue = function_exists( 'twtr_get_languages' ) ? twtr_get_languages() : array();
	?>
	<div class="tl-hd__top"></div>

	<div class="tl-hd__bar">

		<a class="tl-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
<?php
			/*
			 * IL LOGO E' IL PNG CON TRASPARENZA, attachment 839 (1661x334).
			 *
			 * Prima era logo-tenconi.jpg: marchio blu su fondo bianco OPACO. Su un
			 * filmato scuro quel fondo si vedeva come un rettangolo bianco, e per
			 * renderlo accettabile serviva una piastra dichiarata. Con il canale alfa
			 * la piastra non serve piu' e il marchio galleggia davvero.
			 *
			 * RIPIEGO SUL FILE DEL TEMA se l'allegato non c'e'. Non e' prudenza
			 * astratta: l'allegato 837 del filmato hero e' stato cancellato dalla
			 * libreria e la hero e' rimasta senza video. L'header e' su ogni pagina
			 * del sito e non puo' dipendere da un ID che puo' sparire.
			 */
			/*
			 * 'medium_large' (768x154, ~66 KB) e non 'full' (1661x334, ~197 KB): il
			 * marchio qui non supera mai 249px di larghezza CSS (vedi
			 * .tl-brand__i in legacy.css), quindi 768px coprono anche il caso
			 * peggiore — schermo 3x — con margine. Scaricare il PNG intero per
			 * mostrarne un settimo era peso puro, su ogni pagina del sito.
			 */
			$tl_logo = wp_get_attachment_image_url( tenconi_media_da_nome( 'logotenconinobg', 'image' ), 'medium_large' );
			$tl_logo = $tl_logo ? set_url_scheme( $tl_logo, 'relative' ) : '';
			?>
			<?php if ( '' !== $tl_logo ) : ?>
				<img
					class="tl-brand__i"
					src="<?php echo esc_url( $tl_logo ); ?>"
					alt="Tenconi SA, dal 1871"
					width="1661" height="334"
					decoding="async" fetchpriority="high"
				/>
			<?php else : ?>
				<img
					class="tl-brand__i tl-brand__i--jpg"
					src="<?php echo esc_url( tenconi_asset_uri( 'assets/img/logo-tenconi.jpg' ) ); ?>"
					alt="Tenconi SA, dal 1871"
					width="1896" height="682"
					decoding="async" fetchpriority="high"
				/>
			<?php endif; ?>
		</a>

		<?php
		/*
		 * MEGA MENU. Ricostruito sul comportamento di un componente Radix
		 * NavigationMenu, senza React, Radix, Tailwind ne' alcuna dipendenza: PHP per
		 * il markup, CSS per la forma e le transizioni, un file di JavaScript per
		 * l'intenzione del puntatore e la direzione dello scorrimento.
		 *
		 * COSA E' STATO RIPRODOTTO, e in che modo:
		 *
		 *   UN SOLO PANNELLO CHE SI RIDIMENSIONA. Nel riferimento c'e' un "viewport"
		 *   condiviso la cui altezza e larghezza si animano fra un pannello e
		 *   l'altro. Qui i pannelli restano ognuno nel proprio elemento — serve alla
		 *   tabulazione e al funzionamento senza JavaScript — ma dietro di loro c'e'
		 *   un unico fondo bianco che misura il pannello aperto e ci si adatta. Lo
		 *   stesso effetto, con l'ordine del documento intatto.
		 *
		 *   LA DIREZIONE DELLO SCORRIMENTO. Passando da una voce all'altra il
		 *   contenuto entra dal lato da cui si arriva, come fa data-motion in Radix.
		 *
		 *   IL CHEVRON che ruota di 180 gradi quando il pannello e' aperto.
		 *
		 *   LE SCHEDE con immagine, titolo e descrizione, e la colonna di destra con
		 *   le voci compatte e la freccia che entra al passaggio del mouse.
		 *
		 * IL CHEVRON E' UNA DEROGA DICHIARATA: il sito legacy non aveva chevron
		 * accanto alle voci, e questo foglio lo diceva. Ma una voce che apre un
		 * pannello grande e una che porta a una pagina non possono sembrare la stessa
		 * cosa, e Jobs non ne ha — quindi il segno distingue, non decora.
		 *
		 * NIENTE ICONE, FOTOGRAFIE. Il riferimento usa pittogrammi lucide. Per
		 * un'azienda che lavora metallo valgono di piu' le fotografie di officina che
		 * il sito ha gia' verificate, e sono le stesse che si trovano arrivando a
		 * destinazione: il pannello anticipa la pagina invece di illustrarla.
		 */
		?>
		<nav class="tl-nav" aria-label="<?php echo esc_attr( function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( 'Navigazione principale', 'tenconi:ui:nav-aria' ) : 'Navigazione principale' ); ?>" data-tl-nav>

			<?php
			/*
			 * IL FONDO CONDIVISO, uno per tutta la navigazione. Sta prima dei pannelli
			 * nel documento perche' deve stare sotto senza bisogno di z-index in
			 * salita, ed e' aria-hidden: non porta informazione, e' la superficie.
			 */
			?>
			<span class="tl-mega__fondo" data-tl-mega-fondo aria-hidden="true"></span>

			<?php foreach ( $tl_nav as $tl_v ) : ?>
				<?php if ( 'gruppo' === $tl_v['tipo'] ) : ?>
					<?php $tl_id = 'tl-dd-' . sanitize_html_class( $tl_v['key'] ); ?>
					<div class="tl-nav__i" data-tl-group data-tl-key="<?php echo esc_attr( $tl_v['key'] ); ?>">

						<button class="tl-nav__b" type="button"
							aria-expanded="false" aria-controls="<?php echo esc_attr( $tl_id ); ?>">
							<?php echo esc_html( $tl_v['label'] ); ?>
							<svg class="tl-nav__chev" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
								<path d="M6 9.5l6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
							</svg>
						</button>

						<div class="tl-mega" id="<?php echo esc_attr( $tl_id ); ?>" data-tl-mega>
							<?php
							/*
							 * QUANTE SCHEDE CI SONO LO DICE IL PHP, non un selettore CSS
							 * che conta i figli. La griglia si serve del numero per
							 * decidere quante colonne fare: cinque schede nella stessa
							 * colonna del sito sono cinque schede piu' strette, non una
							 * seconda riga spaiata.
							 */
							$tl_n = count( $tl_v['schede'] );
							?>
							<div class="tl-mega__in">

								<?php if ( $tl_v['schede'] ) : ?>
									<ul class="tl-mega__schede" style="--tl-schede: <?php echo (int) $tl_n; ?>">
										<?php foreach ( $tl_v['schede'] as $tl_c ) : ?>
											<li>
												<?php
												/*
												 * Una destinazione non pubblicabile resta visibile e non
												 * cliccabile, come nel resto del sito: non diventa un
												 * href="#" e non porta a una pagina vuota.
												 */
												$tl_tag = $tl_c['attiva'] ? 'a' : 'div';
												?>
												<<?php echo esc_attr( $tl_tag ); ?> class="tl-sch tl-sch--<?php echo sanitize_html_class( $tl_c['key'] ); ?><?php echo $tl_c['attiva'] ? '' : ' tl-sch--inerte'; ?>"
													<?php echo $tl_c['attiva'] ? ' href="' . esc_url( $tl_c['url'] ) . '"' : ' aria-disabled="true"'; ?>>

													<?php if ( $tl_c['img'] ) : ?>
														<figure class="tl-sch__f">
															<?php
															echo wp_get_attachment_image(
																(int) $tl_c['img'],
																'medium_large',
																false,
																array(
																	/*
																	 * Alt vuoto: il titolo della scheda dice
																	 * dove porta, e ripeterlo nell'immagine
																	 * farebbe annunciare due volte la stessa
																	 * voce a chi usa uno screen reader.
																	 */
																	'alt'      => '',
																	'loading'  => 'lazy',
																	'decoding' => 'async',
																	'sizes'    => '(max-width: 1200px) 30vw, 260px',
																)
															);
															?>
														</figure>
													<?php else : ?>
														<?php
														/*
														 * NIENTE FOTOGRAFIA: oggi non capita — tutte e diciassette le
														 * voci ne hanno una, verificato — ma un'immagine si puo'
														 * cancellare dalla libreria senza sapere che il menu la usa. In
														 * quel caso la cornice mostra l'icona in grande invece di
														 * sparire: tiene la sua misura, le schede vicine non si
														 * spostano, e nessuno ci mette una foto di officina a caso pur
														 * di riempire il buco.
														 */
														?>
														<figure class="tl-sch__f tl-sch__f--ico">
															<?php echo tenconi_mega_icona( $tl_c['key'], 'tl-ico--grande' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
														</figure>
													<?php endif; ?>

													<span class="tl-sch__t">
														<?php echo tenconi_mega_icona( $tl_c['key'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
														<span><?php echo esc_html( $tl_c['label'] ); ?></span>
													</span>
													<?php if ( '' !== $tl_c['frase'] ) : ?>
														<span class="tl-sch__d"><?php echo esc_html( $tl_c['frase'] ); ?></span>
													<?php endif; ?>
												</<?php echo esc_attr( $tl_tag ); ?>>
											</li>
										<?php endforeach; ?>
									</ul>
								<?php endif; ?>

							</div>
						</div>
					</div>
				<?php elseif ( 'link' === $tl_v['tipo'] ) : ?>
					<div class="tl-nav__i">
						<a class="tl-nav__l" href="<?php echo esc_url( $tl_v['url'] ); ?>"><?php echo esc_html( $tl_v['label'] ); ?></a>
					</div>
				<?php else : ?>
					<div class="tl-nav__i">
						<span class="tl-nav__l" aria-disabled="true"><?php echo esc_html( $tl_v['label'] ); ?></span>
					</div>
				<?php endif; ?>
			<?php endforeach; ?>
		</nav>

		<?php
		/*
		 * LA LINGUA, ORA UN SELETTORE VERO. Fino a ieri era dichiarativa — "WPML e'
		 * inattivo e EN, DE, FR non esistono come URL, un elenco sarebbe un comando
		 * che non fa niente" — e quel commento era corretto quando e' stato scritto.
		 * Con tW Translate Plus attivo quelle URL esistono davvero, quindi la
		 * pastiglia diventa un pulsante che apre l'elenco.
		 *
		 * STA QUI, NELLA BARRA, PER LO STESSO MOTIVO DELLA RICERCA POCO SOTTO: sulla
		 * home la striscia sopra la barra (.tl-hd__top) chiude ad altezza zero
		 * scorrendo — lo fa hero.js col suo stato compatto — e un selettore che
		 * sparisce non e' un selettore. La barra resta sempre, in ogni stato
		 * dell'header, quindi il controllo vive qui.
		 *
		 * SI SPEGNE DA SOLA finche' serve. twtr_get_languages() (calcolata in cima al
		 * template) oggi restituisce la sola lingua predefinita finche' non viene
		 * pubblicata una seconda lingua dal pannello del plugin, e con una sola voce
		 * un menu a tendina sarebbe un comando vuoto: questo ramo stampa allora la
		 * stessa pastiglia dichiarativa di sempre, non un pulsante.
		 *
		 * NESSUNA BANDIERA. Il plugin le fornisce (emoji a colori), ma questo sito
		 * non usa mai un colore fuori dalla sua palette ne' un pittogrammo importato:
		 * il mega menu usa icone disegnate a tratto blu proprio per questo. Resta il
		 * codice lingua in maiuscolo; il nome esteso compare nel pannello.
		 */
		?>
		<?php if ( count( $tl_lingue ) > 1 ) : ?>
			<?php
			$tl_corr = null;
			foreach ( $tl_lingue as $tl_l ) {
				if ( ! empty( $tl_l['is_current'] ) ) {
					$tl_corr = $tl_l;
					break;
				}
			}
			if ( ! $tl_corr ) {
				$tl_corr = reset( $tl_lingue );
			}
			?>
			<div class="tl-lingue" data-tl-lingue>
				<button class="tl-lang tl-lang--b" type="button"
					aria-expanded="false" aria-controls="tl-lingue-lista">
					<?php echo esc_html( strtoupper( $tl_corr['slug'] ) ); ?>
					<i class="tl-lang__chev" aria-hidden="true"></i>
				</button>
				<ul class="tl-lingue__lista" id="tl-lingue-lista" role="listbox" aria-label="<?php echo esc_attr( function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( 'Scegli la lingua', 'tenconi:ui:lingua-aria' ) : 'Scegli la lingua' ); ?>">
					<?php foreach ( $tl_lingue as $tl_l ) : ?>
						<li role="presentation">
							<a
								role="option"
								class="tl-lingue__v<?php echo ! empty( $tl_l['is_current'] ) ? ' is-current' : ''; ?>"
								href="<?php echo esc_url( $tl_l['url'] ); ?>"
								hreflang="<?php echo esc_attr( str_replace( '_', '-', $tl_l['locale'] ) ); ?>"
								aria-selected="<?php echo ! empty( $tl_l['is_current'] ) ? 'true' : 'false'; ?>"
								<?php echo ! empty( $tl_l['is_current'] ) ? ' aria-current="page"' : ''; ?>
							>
								<span class="tl-lingue__et"><?php echo esc_html( $tl_l['label'] ); ?></span>
								<?php if ( ! empty( $tl_l['is_current'] ) ) : ?>
									<svg class="tl-lingue__spunta" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
										<path d="m5 12.5 4.5 4.5L19 7" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
									</svg>
								<?php endif; ?>
							</a>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
		<?php else : ?>
			<span class="tl-lang">
				<?php echo esc_html( strtoupper( substr( determine_locale(), 0, 2 ) ) ); ?>
				<i class="tl-lang__chev" aria-hidden="true"></i>
			</span>
		<?php endif; ?>

		<?php
		/*
		 * RICERCA. Ricostruzione dell'interazione di un componente React con Framer
		 * Motion, senza React e senza Framer Motion: un guscio la cui larghezza si
		 * anima, un campo, un pannello di risultati, e un file di JavaScript.
		 *
		 * STA NELLA BARRA e non nella striscia della lingua, per un motivo
		 * verificabile: sulla home, scorrendo, la striscia si chiude in altezza zero
		 * — lo fa hero.js col suo stato compatto — e una ricerca che sparisce appena
		 * si scorre non e' una ricerca. La barra resta sempre.
		 *
		 * IL GUSCIO E' UNO SOLO. Non un pulsante che scompare e un campo che appare:
		 * la stessa scatola passa da 104 a 320 px e dentro cambia il contenuto. E'
		 * cio' che fa sembrare la transizione fluida invece di uno scambio.
		 */
		?>
		<div class="tl-cerca" data-tl-cerca
			data-tl-cerca-url="<?php echo esc_url( rest_url( 'tenconi/v1/cerca' ) ); ?>"
			data-tl-cerca-pagina="<?php echo esc_url( home_url( '/' ) ); ?>">

			<div class="tl-cerca__guscio">
				<span class="tl-cerca__ico" data-tl-cerca-ico aria-hidden="true">
					<svg class="tl-cerca__lente" viewBox="0 0 24 24" focusable="false">
						<circle cx="10.5" cy="10.5" r="6.4" fill="none" stroke="currentColor" stroke-width="1.7"/>
						<path d="m15.3 15.3 4.4 4.4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>
					</svg>
					<svg class="tl-cerca__rotella" viewBox="0 0 24 24" focusable="false">
						<circle cx="12" cy="12" r="7.6" fill="none" stroke="currentColor" stroke-width="1.8"
							stroke-linecap="round" stroke-dasharray="12 36"/>
					</svg>
				</span>

				<button class="tl-cerca__b" type="button"
					aria-expanded="false" aria-controls="tl-cerca-lista" aria-label="<?php echo esc_attr( function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( 'Cerca nel sito', 'tenconi:ui:cerca-aria' ) : 'Cerca nel sito' ); ?>">
					<svg class="tl-cerca__bl" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
						<circle cx="10.5" cy="10.5" r="6.4" fill="none" stroke="currentColor" stroke-width="1.7"/>
						<path d="m15.3 15.3 4.4 4.4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>
					</svg>
					<span class="tl-cerca__et tl-solo-lettori"><?php echo esc_html( function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( 'Cerca', 'tenconi:ui:cerca-parola' ) : 'Cerca' ); ?></span>
				</button>

				<?php
				/*
				 * role="combobox" con aria-expanded e aria-controls: e' il contratto che
				 * dice a uno screen reader che questo campo comanda un elenco che si
				 * apre. Senza, i risultati compaiono e nessuno li annuncia.
				 *
				 * tabindex -1 da chiuso, perche' un campo invisibile che raccoglie il
				 * focus tabulando e' una trappola: il cursore sparisce e non si capisce
				 * dove sia finito. Lo rimette a zero il JavaScript quando apre.
				 */
				?>
				<input class="tl-cerca__in" type="search" tabindex="-1"
					placeholder="<?php echo esc_attr( function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( 'Cerca nel sito…', 'tenconi:ui:cerca-placeholder' ) : 'Cerca nel sito…' ); ?>" aria-label="<?php echo esc_attr( function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( 'Cerca nel sito', 'tenconi:ui:cerca-aria' ) : 'Cerca nel sito' ); ?>"
					role="combobox" aria-expanded="false" aria-controls="tl-cerca-lista"
					aria-autocomplete="list" autocomplete="off" spellcheck="false" />

				<button class="tl-cerca__x" type="button" tabindex="-1" aria-label="<?php echo esc_attr( function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( 'Chiudi la ricerca', 'tenconi:ui:cerca-chiudi-aria' ) : 'Chiudi la ricerca' ); ?>">
					<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
						<path d="M7 7l10 10M17 7 7 17" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>
					</svg>
				</button>
			</div>

			<div class="tl-cerca__p" data-tl-cerca-p>
				<?php
				/*
				 * LO STRATO GELATINOSO sta sotto, e' decorativo e non contiene testo: il
				 * filtro SVG sfoca e ricompatta le forme, e passarci dentro le parole
				 * vorrebbe dire sfocare le parole. Il telaio e i testi stanno sopra,
				 * senza filtro, quindi restano nitidi.
				 */
				?>
				<span class="tl-cerca__gelo" aria-hidden="true"></span>
				<ul class="tl-cerca__lista" id="tl-cerca-lista" role="listbox" aria-label="<?php echo esc_attr( function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( 'Risultati della ricerca', 'tenconi:ui:cerca-risultati-aria' ) : 'Risultati della ricerca' ); ?>"></ul>
				<p class="tl-cerca__vuoto" hidden><?php echo esc_html( function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( 'Nessun risultato', 'tenconi:ui:cerca-vuoto' ) : 'Nessun risultato' ); ?></p>
			</div>

			<span class="tl-solo-lettori" role="status" aria-live="polite" data-tl-cerca-stato></span>
		</div>

		<button class="tl-burger" type="button"
			aria-expanded="false" aria-controls="tl-mnav" aria-label="<?php echo esc_attr( function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( 'Apri il menu', 'tenconi:ui:burger-apri-aria' ) : 'Apri il menu' ); ?>" data-tl-burger>
			<span></span><span></span><span></span>
		</button>
	</div>
</header>

<?php
/*
 * IL GUSCIO DI SCROLLSMOOTHER, e l'header sta FUORI di proposito.
 *
 * ScrollSmoother scorre la pagina con una transform su #smooth-content. Una
 * transform crea un blocco di contenimento per gli elementi in position: fixed:
 * se l'header finisse dentro, smetterebbe di stare fermo in cima e scorrerebbe
 * col resto. Per questo il guscio si apre qui, sotto l'header, e non attorno a
 * tutta la pagina.
 *
 * I due div sono sempre presenti, anche quando lo scorrimento morbido e' spento:
 * senza smoother non fanno niente e non cambiano il layout.
 */
?>
<div id="smooth-wrapper">
<div id="smooth-content">


<nav class="tl-mnav" id="tl-mnav" aria-label="<?php echo esc_attr( function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( 'Navigazione principale, mobile', 'tenconi:ui:nav-mobile-aria' ) : 'Navigazione principale, mobile' ); ?>">
	<ul>
		<?php foreach ( $tl_nav as $tl_v ) : ?>
			<?php if ( 'gruppo' === $tl_v['tipo'] ) : ?>
				<?php $tl_mid = 'tl-macc-' . sanitize_html_class( $tl_v['key'] ); ?>
				<li class="tl-mnav__i" data-tl-acc>
					<button class="tl-mnav__b" type="button"
						aria-expanded="false" aria-controls="<?php echo esc_attr( $tl_mid ); ?>">
						<?php echo esc_html( $tl_v['label'] ); ?>
						<i class="tl-chev" aria-hidden="true"></i>
					</button>
					<?php
					/*
					 * LE RIGHE MOBILI prendono dal riferimento la forma con la miniatura
					 * a sinistra e l'etichetta accanto: su un telefono un bersaglio alto
					 * quaranta pixel con un'immagine si prende meglio di una riga di
					 * testo, e le fotografie sono le stesse del pannello desktop.
					 *
					 * Dove la fotografia non c'e' il riquadro non resta vuoto: si
					 * riempie di un blu tenue, cosi' le righe restano allineate e la
					 * colonna del testo non salta.
					 */
					?>
					<div class="tl-mnav__s" id="<?php echo esc_attr( $tl_mid ); ?>">
						<?php foreach ( $tl_v['children'] as $tl_c ) : ?>
							<?php
							$tl_im  = tenconi_mega_immagine( $tl_c['key'], $tl_c['url'] );
							$tl_tag = $tl_c['attiva'] ? 'a' : 'span';
							?>
							<<?php echo esc_attr( $tl_tag ); ?> class="tl-mrow tl-mrow--<?php echo sanitize_html_class( $tl_c['key'] ); ?><?php echo $tl_c['attiva'] ? '' : ' tl-mrow--inerte'; ?>"
								<?php echo $tl_c['attiva'] ? ' href="' . esc_url( $tl_c['url'] ) . '"' : ' aria-disabled="true"'; ?>>
								<span class="tl-mrow__f">
									<?php
									if ( $tl_im['img'] ) {
										/*
										 * 'medium' e NON 'thumbnail': thumbnail e' un
										 * ritaglio quadrato fatto da WordPress, e su un
										 * disegno largo — il 150esimo — buttava via le
										 * cifre ai due lati prima ancora che il CSS lo
										 * vedesse. 'medium' conserva le proporzioni e
										 * lascia decidere al riquadro.
										 */
										echo wp_get_attachment_image(
											(int) $tl_im['img'],
											'medium',
											false,
											array(
												'alt'      => '',
												'loading'  => 'lazy',
												'decoding' => 'async',
											)
										);
									} else {
										echo tenconi_mega_icona( $tl_c['key'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
									}
									?>
								</span>
								<span class="tl-mrow__t"><?php echo esc_html( $tl_c['label'] ); ?></span>
							</<?php echo esc_attr( $tl_tag ); ?>>
						<?php endforeach; ?>
					</div>
				</li>
			<?php elseif ( 'link' === $tl_v['tipo'] ) : ?>
				<li class="tl-mnav__i">
					<a class="tl-mnav__l" href="<?php echo esc_url( $tl_v['url'] ); ?>"><?php echo esc_html( $tl_v['label'] ); ?></a>
				</li>
			<?php else : ?>
				<li class="tl-mnav__i">
					<span class="tl-mnav__l" aria-disabled="true"><?php echo esc_html( $tl_v['label'] ); ?></span>
				</li>
			<?php endif; ?>
		<?php endforeach; ?>
	</ul>
</nav>
