<?php
/**
 * Involucro degli elenchi di documenti. Selezionato dal filtro template_include.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$GLOBALS['tenconi_interne'] = true;
get_header();

$tl_p = get_queried_object();
set_query_var( 'tl_slug', $tl_p ? $tl_p->post_name : '' );
get_template_part( 'template-parts/interne/documenti' );

get_footer();
