<?php
/**
 * Involucro delle pagine del menu ricostruite dal legacy.
 *
 * Selezionato dal filtro template_include in functions.php, non dalla gerarchia
 * dei template: le cinque pagine condividono un layout e non serve un file per
 * ciascuna.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$GLOBALS['tenconi_interne'] = true;
get_header();

$tl_p = get_queried_object();
set_query_var( 'tl_slug', $tl_p ? $tl_p->post_name : '' );
get_template_part( 'template-parts/interne/pagina' );

get_footer();
