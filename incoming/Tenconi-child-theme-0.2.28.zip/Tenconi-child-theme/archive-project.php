<?php
/**
 * PROGETTI E REFERENZE — l'archivio del tipo "project" nel nuovo sistema delle
 * pagine interne (inc/interne.php).
 *
 * URL: /referenze/
 *
 * Prima passava da archive.php: fascia scura, elenco paginato a dieci voci e,
 * sotto, una griglia di fotografie di misure diverse. Qui: testata del sistema,
 * l'elenco di TUTTI i progetti in una volta (sono quindici, una pagina 2 era
 * solo un ostacolo), poi le fotografie in galleria.
 *
 * I progetti non hanno un'immagine propria: le fotografie sono quelle che la
 * pagina legacy mostrava, salvate nell'opzione tenconi_archive_media_project.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$GLOBALS['tenconi_interne'] = true;
get_header();

$tl_voce     = tenconi_int_voce( 'referenze' );
$tl_progetti = get_posts(
	array(
		'post_type'        => 'project',
		'post_status'      => 'publish',
		'numberposts'      => -1,
		'orderby'          => array(
			'menu_order' => 'ASC',
			'date'       => 'DESC',
		),
		'suppress_filters' => false,
	)
);
$tl_foto = array();
if ( function_exists( 'tenconi_ids_from' ) ) {
	foreach ( tenconi_ids_from( get_option( 'tenconi_archive_media_project', '' ) ) as $tl_id ) {
		$tl_foto[] = array( (int) $tl_id, '' );
	}
}
$tl_nfoto = tenconi_int_conta( $tl_foto );

$tl_indice = array();
if ( $tl_progetti ) {
	$tl_indice[] = array( 'tl-sez-progetti', tenconi_int_t( 'Progetti', 'tenconi:interne:sez-progetti' ), count( $tl_progetti ) );
}
if ( $tl_nfoto ) {
	$tl_indice[] = array( 'tl-sez-foto', tenconi_int_t( 'Fotografie', 'tenconi:interne:sez-foto' ), $tl_nfoto );
}
$tl_sn = 0;
?>
<main id="main" class="tl-main tl-int" tabindex="-1">
	<?php
	tenconi_int_testa(
		array(
			'gruppo' => $tl_voce['gruppo'],
			'titolo' => '' !== $tl_voce['titolo'] ? $tl_voce['titolo'] : post_type_archive_title( '', false ),
			'hero'   => tenconi_mega_immagine( 'referenze', (string) get_post_type_archive_link( 'project' ) )['img'],
			'indice' => $tl_indice,
		)
	);
	?>

	<?php if ( $tl_progetti ) : ?>
		<section class="tl-int__sez" id="tl-sez-progetti" aria-labelledby="tl-sez-progetti-t">
			<div class="tl-wrap">
				<?php tenconi_int_sez_testa( 'tl-sez-progetti', ++$tl_sn, $tl_indice[0][1] ); ?>
				<div class="tl-int__testo">
					<ol class="tl-int__elenco-pr">
						<?php foreach ( $tl_progetti as $tl_pr ) : ?>
							<li>
								<a href="<?php echo esc_url( get_permalink( $tl_pr ) ); ?>">
									<span><?php echo esc_html( get_the_title( $tl_pr ) ); ?></span>
									<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M5 12h13m0 0-5-5m5 5-5 5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>
								</a>
							</li>
						<?php endforeach; ?>
					</ol>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<?php
	if ( $tl_nfoto ) {
		tenconi_int_galleria(
			array(
				'id'     => 'tl-sez-foto',
				'num'    => ++$tl_sn,
				'titolo' => tenconi_int_t( 'Fotografie', 'tenconi:interne:sez-foto' ),
				'img'    => $tl_foto,
				'alt'    => $tl_voce['titolo'],
			)
		);
	}

	tenconi_int_cta();
	?>
</main>
<?php
get_footer();
