<?php
/**
 * Template generico di OGNI archivio. PROVVISORIO.
 *
 * L'introduzione editoriale di ciascun archivio vive in una option
 * `tenconi_archive_intro_<post_type>`, non in una pagina fantasma che
 * collidereb be con lo slug dell'archivio.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$tc_pt = get_query_var( 'post_type' );
if ( is_array( $tc_pt ) ) {
	$tc_pt = reset( $tc_pt );
}
if ( ! $tc_pt ) {
	$tc_pt = get_post_type();
}
$tc_obj   = $tc_pt ? get_post_type_object( $tc_pt ) : null;
$tc_intro = $tc_pt ? (string) get_option( 'tenconi_archive_intro_' . $tc_pt, '' ) : '';
$tc_tot   = (int) $GLOBALS['wp_query']->found_posts;
?>
<main id="main" class="tc-main" tabindex="-1">
	<section class="tc-section tc-section--tight tc-field--navy">
		<div class="tc-container">
			<div class="tc-section__grid">
				<?php
				tenconi_ref_column(
					array(
						array( 'label' => 'Archivio', 'value' => (string) $tc_tot ),
					),
					''
				);
				?>
				<div class="tc-content tc-density--editorial">
					<h1 class="tc-display"><?php echo esc_html( get_the_archive_title() ); ?></h1>
					<?php if ( '' !== trim( $tc_intro ) ) : ?>
						<p class="tc-lead"><?php echo esc_html( $tc_intro ); ?></p>
					<?php else : ?>
						<p><?php tenconi_placeholder( 'introduzione dell archivio non ancora redatta' ); ?></p>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</section>

	<section class="tc-section tc-field--offwhite">
		<div class="tc-container">
			<?php if ( have_posts() ) : ?>
				<ul class="tc-list">
					<?php
					while ( have_posts() ) :
						the_post();
						$tc_stato = tenconi_text_state();
						?>
						<li class="tc-list__item">
							<a class="tc-list__link" href="<?php the_permalink(); ?>">
								<span class="tc-list__title"><?php the_title(); ?></span>
								<?php if ( has_excerpt() ) : ?>
									<span class="tc-list__note"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 18 ) ); ?></span>
								<?php endif; ?>
								<?php if ( 'partial' === $tc_stato || 'placeholder' === $tc_stato ) : ?>
									<span class="tc-list__state tc-tech"><?php
										echo esc_html( 'partial' === $tc_stato ? 'contenuto parziale' : 'segnaposto' );
									?></span>
								<?php endif; ?>
							</a>
						</li>
					<?php endwhile; ?>
				</ul>
				<?php
				the_posts_pagination( array(
					'mid_size'  => 2,
					'prev_text' => 'Precedente',
					'next_text' => 'Successiva',
				) );
				?>
			<?php else : ?>
				<p><?php tenconi_placeholder( 'nessun record ancora inserito' ); ?></p>
			<?php endif; ?>

			<?php
			/*
			 * CF-4: immagini e documenti che il sito legacy mostrava sulla pagina
			 * hub corrispondente a questo archivio. La sorgente e' un'opzione,
			 * perche' un archivio non e' un post e non ha meta.
			 */
			if ( $tc_pt ) {
				tenconi_gallery_from_ids(
					tenconi_ids_from( get_option( 'tenconi_archive_media_' . $tc_pt, '' ) )
				);
				tenconi_documents_from_ids(
					tenconi_ids_from( get_option( 'tenconi_archive_documents_' . $tc_pt, '' ) )
				);
			}
			?>
		</div>
	</section>

	<?php tenconi_cta_band(); ?>
</main>
<?php
get_footer();
