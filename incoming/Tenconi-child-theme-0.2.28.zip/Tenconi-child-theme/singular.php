<?php
/**
 * Template generico di OGNI record di CPT. PROVVISORIO.
 *
 * Un solo file per tutti e sette i CPT: WordPress usa singular.php quando non
 * trova un single-<type>.php. I sette template quasi identici sono deliberatamente
 * evitati. Le differenze fra i tipi si esprimono con i termini di tassonomia
 * elencati nella colonna di riferimento, non con sette file.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>
<main id="main" class="tc-main" tabindex="-1">
	<?php
	while ( have_posts() ) :
		the_post();
		?>
		<article class="tc-section tc-section--tight tc-field--navy">
			<div class="tc-container">
				<div class="tc-section__grid">
					<?php
					$tc_refs = array();
					$tc_tipo = tenconi_type_label();
					if ( $tc_tipo ) {
						$tc_refs[] = array( 'label' => 'Tipo', 'value' => $tc_tipo );
					}
					// Le norme sono la prova: se ci sono, stanno nella colonna di riferimento.
					$tc_std = get_the_terms( get_the_ID(), 'standard' );
					if ( $tc_std && ! is_wp_error( $tc_std ) ) {
						foreach ( array_slice( $tc_std, 0, 3 ) as $tc_t ) {
							$tc_refs[] = array( 'label' => '', 'value' => $tc_t->name );
						}
					}
					tenconi_ref_column( $tc_refs, '' );
					?>
					<div class="tc-content tc-density--editorial">
						<h1 class="tc-display"><?php the_title(); ?></h1>
						<?php if ( has_excerpt() ) : ?>
							<p class="tc-lead"><?php echo esc_html( get_the_excerpt() ); ?></p>
						<?php endif; ?>
						<?php tenconi_text_state_badge(); ?>
					</div>
				</div>
			</div>
		</article>

		<section class="tc-section tc-field--offwhite">
			<div class="tc-container">
				<div class="tc-section__grid">
					<div class="tc-refcol">
						<?php
						if ( has_post_thumbnail() ) {
							the_post_thumbnail( 'tenconi_plate_sm', array( 'class' => 'tc-plate' ) );
						}
						/*
						 * Tutte le tassonomie del tipo, in un unico elenco di definizioni.
						 * Nessun dato inventato: si stampa solo cio' che e' assegnato.
						 */
						$tc_taxes = get_object_taxonomies( get_post_type(), 'objects' );
						$tc_righe = array();
						foreach ( $tc_taxes as $tc_tax ) {
							$tc_terms = get_the_terms( get_the_ID(), $tc_tax->name );
							if ( ! $tc_terms || is_wp_error( $tc_terms ) ) {
								continue;
							}
							$tc_righe[ $tc_tax->labels->singular_name ] = $tc_terms;
						}
						if ( $tc_righe ) {
							echo '<dl class="tc-meta">';
							foreach ( $tc_righe as $tc_lab => $tc_terms ) {
								echo '<dt class="tc-tech">' . esc_html( $tc_lab ) . '</dt>';
								echo '<dd>';
								$tc_out = array();
								foreach ( $tc_terms as $tc_t ) {
									$tc_link = get_term_link( $tc_t );
									if ( ! is_wp_error( $tc_link ) && $tc_t->taxonomy === 'market' ) {
										$tc_out[] = '<a href="' . esc_url( $tc_link ) . '">' . esc_html( $tc_t->name ) . '</a>';
									} else {
										$tc_out[] = esc_html( $tc_t->name );
									}
								}
								echo wp_kses_post( implode( ', ', $tc_out ) );
								echo '</dd>';
							}
							echo '</dl>';
						}
						tenconi_documents_list();
						?>
					</div>
					<div class="tc-content tc-prose tc-entry">
						<?php
						the_content();
						if ( '' === trim( wp_strip_all_tags( get_the_content() ) ) ) {
							tenconi_placeholder( 'scheda non ancora redatta' );
						}
						tenconi_gallery_grid();
						tenconi_rights_note();
						tenconi_source_note();
						?>
					</div>
				</div>
			</div>
		</section>

		<?php tenconi_cta_band(); ?>
	<?php endwhile; ?>
</main>
<?php
get_footer();
