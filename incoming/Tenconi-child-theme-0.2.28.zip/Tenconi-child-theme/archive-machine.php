<?php
/**
 * PARCO MACCHINE — l'archivio del CPT machine, reso come la pagina legacy.
 *
 * URL: /parco-macchine/
 *
 * SOSTITUISCE archive.php della fase Legacy-Modernized, che rendeva questa pagina
 * come un elenco di titoli su campo scuro con una fascia CTA finale. Nel legacy
 * era sei gruppi etichettati di fotografie, ognuno con la griglia a 3 colonne
 * della homepage e la didascalia col nome del macchinario.
 *
 * PERCHE' LEGGE LA MAPPA E NON I 34 RECORD. I 34 macchinari esistono in WordPress
 * ed e' giusto che ci siano, ma il legacy non li elencava per titolo: mostrava una
 * selezione redazionale di 33 fotografie divise in sei gruppi, con nomi di
 * macchinario come didascalia. Prendere i record e ordinarli darebbe una pagina
 * plausibile e diversa. La selezione e l'ordine sono quelli del legacy.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$GLOBALS['tenconi_interne'] = true;
get_header();

/*
 * NUOVO SISTEMA DELLE PAGINE INTERNE (inc/interne.php): testata con indice dei
 * gruppi, poi un gruppo per sezione. Selezione, ordine e didascalie restano
 * quelli della mappa legacy.
 */
$tl_gruppi = tenconi_legacy_parco_macchine();
$tl_voce   = tenconi_int_voce( 'parco-macchine' );
$tl_indice = array();
foreach ( $tl_gruppi as $tl_i => $tl_g ) {
	$tl_n = empty( $tl_g['img'] ) ? 0 : tenconi_int_conta( $tl_g['img'] );
	if ( $tl_n ) {
		$tl_indice[] = array( 'tl-grp-' . (int) $tl_i, $tl_g['etichetta'], $tl_n );
	}
}
?>
<main id="main" class="tl-main tl-int" tabindex="-1">
	<?php
	tenconi_int_testa(
		array(
			'gruppo' => $tl_voce['gruppo'],
			'titolo' => '' !== $tl_voce['titolo'] ? $tl_voce['titolo'] : post_type_archive_title( '', false ),
			'hero'   => tenconi_mega_immagine( 'parco-macchine', (string) get_post_type_archive_link( 'machine' ) )['img'],
			'indice' => $tl_indice,
		)
	);

	$tl_k = 0;
	foreach ( $tl_gruppi as $tl_i => $tl_g ) {
		if ( empty( $tl_g['img'] ) ) {
			continue;
		}
		/* "MANDELLI&nbsp; 7U HP": le didascalie arrivano dal legacy con entita' HTML. */
		$tl_img = array();
		foreach ( $tl_g['img'] as $tl_x ) {
			$tl_img[] = array( $tl_x[0], trim( preg_replace( '/\s+/u', ' ', html_entity_decode( $tl_x[1], ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) ) );
		}
		$tl_fatte = tenconi_int_galleria(
			array(
				'id'     => 'tl-grp-' . (int) $tl_i,
				'num'    => $tl_k + 1,
				'titolo' => $tl_g['etichetta'],
				'img'    => $tl_img,
				'alt'    => $tl_g['etichetta'],
			)
		);
		if ( $tl_fatte ) {
			++$tl_k;
		}
	}

	tenconi_int_cta();
	?>
</main>
<?php
get_footer();
