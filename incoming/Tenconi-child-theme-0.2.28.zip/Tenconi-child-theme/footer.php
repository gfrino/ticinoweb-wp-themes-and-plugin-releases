<?php
/**
 * FOOTER — minimale.
 *
 * TRE VERSIONI, e vale dire perche' siamo qui. La prima era la ricostruzione del
 * legacy: nome centrato, icona LinkedIn, tre link sottolineati. La seconda era una
 * mappa del sito su cinque colonne in campo blu: diversa dal legacy, ma pesante —
 * un elenco di diciannove voci in fondo a ogni pagina e' un archivio, non una
 * chiusura. Questa e' la terza: il minimo che serve davvero.
 *
 * COSA RESTA, e niente altro:
 *   il nome, grande
 *   l'indirizzo e i due recapiti generali, premibili
 *   tre destinazioni: Contatti, Jobs, Protezione dati
 *   LinkedIn
 *   una riga di chiusura
 *
 * PERCHE' NON SOMIGLIA AL LEGACY pur essendo anche lui bianco e sobrio: il legacy
 * era una pila CENTRATA di elementi piccoli. Questo e' una composizione
 * ASIMMETRICA con il nome a scala tipografica grande a sinistra e gli essenziali
 * a destra. Cambia l'impianto, non solo il contenuto.
 *
 * NIENTE E' SCRITTO A MANO: indirizzo e recapiti vengono dalla pagina Contatti
 * pubblicata, le tre destinazioni passano dal cancello del menu. Se una non e'
 * pubblicabile non compare, e footer e navigazione non possono contraddirsi.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * I recapiti dalla pagina pubblicata: il primo blocco e' la sede, il secondo i
 * numeri generali. Se la pagina cambia, cambia il footer, senza toccare questo
 * file.
 */
$tl_sede  = array();
$tl_num   = array();
$tl_c     = get_page_by_path( 'contatti' );
if ( $tl_c ) {
	$tl_raw = preg_replace( '#<br\s*/?>#i', "\n", (string) $tl_c->post_content );
	$tl_raw = preg_replace( '#</(p|div)>#i', "\n\n", $tl_raw );
	$tl_bl  = array();
	foreach ( preg_split( '/\n\s*\n+/u', trim( wp_strip_all_tags( $tl_raw ) ) ) as $tl_b ) {
		$tl_r = array();
		foreach ( preg_split( '/\n/u', $tl_b ) as $tl_x ) {
			$tl_x = trim( html_entity_decode( $tl_x, ENT_QUOTES, 'UTF-8' ) );
			if ( '' !== $tl_x ) {
				$tl_r[] = $tl_x;
			}
		}
		if ( $tl_r ) {
			$tl_bl[] = $tl_r;
		}
	}
	$tl_sede = isset( $tl_bl[0] ) ? $tl_bl[0] : array();
	$tl_num  = isset( $tl_bl[1] ) ? $tl_bl[1] : array();
}

/*
 * TRE DESTINAZIONI, scelte perche' sono quelle che si cercano in un footer: come
 * parlare con l'azienda, come lavorarci, come sono trattati i propri dati.
 */
$tl_link = array();
foreach ( array(
	/*
	 * "Contatti" riusa lo stesso contesto della voce utility del menu
	 * (tenconi:nav:contatti-utility): e' la stessa identica parola nello
	 * stesso significato, e una sola riga in coda serve entrambi i punti.
	 */
	array( 'Contatti', 'page', 'contatti', 'tenconi:nav:contatti-utility' ),
	array( 'Jobs', 'cpt_archive', 'job', 'tenconi:footer:link-jobs' ),
	array( 'Protezione dati', 'page', 'privacy', 'tenconi:footer:link-privacy' ),
) as $tl_l ) {
	$tl_u = tenconi_dest_url( $tl_l[1], $tl_l[2] );
	if ( $tl_u ) {
		$tl_et = function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( $tl_l[0], $tl_l[3] ) : $tl_l[0];
		$tl_link[] = array( $tl_et, $tl_u );
	}
}
?>
<footer class="tl-fo" role="contentinfo">
	<div class="tl-fo__in">

		<?php
		/*
		 * LA LARGHEZZA VA USATA. La versione precedente era una bandiera a sinistra
		 * e lasciava vuoti i due terzi destri dei 1400 px: leggeva come una pagina
		 * non finita. Quella prima faceva l'errore opposto, un grumo nell'angolo
		 * destro. Qui la colonna e' occupata per intero da due cose:
		 *
		 *   - una FASCIA DI TRE COLONNE con le sole informazioni che servono,
		 *     ognuna sotto la sua etichetta tecnica;
		 *   - il NOME a piena colonna, dimensionato in cqw perche' arrivi esatto
		 *     da bordo a bordo a qualunque larghezza.
		 *
		 * Non e' la mappa del sito bocciata prima: quella erano diciannove voci su
		 * cinque colonne. Qui sono tre colonne con tre, quattro voci.
		 */
		?>
		<div class="tl-fo__griglia">

			<?php if ( $tl_sede ) : ?>
				<div class="tl-fo__col">
					<p class="tl-fo__et"><?php echo esc_html( function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( 'Sede', 'tenconi:footer:etichetta-sede' ) : 'Sede' ); ?></p>
					<p class="tl-fo__ind">
						<?php
						/* Il nome dell'azienda e' il wordmark qui sotto: nella sede non si ripete. */
						$tl_righe = ( 0 === stripos( $tl_sede[0], 'tenconi' ) ) ? array_slice( $tl_sede, 1 ) : $tl_sede;
						echo wp_kses_post( implode( '<br />', array_map( 'esc_html', $tl_righe ) ) );
						?>
					</p>
				</div>
			<?php endif; ?>

			<?php if ( $tl_num ) : ?>
				<div class="tl-fo__col">
					<p class="tl-fo__et"><?php echo esc_html( function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( 'Recapiti', 'tenconi:footer:etichetta-recapiti' ) : 'Recapiti' ); ?></p>
					<p class="tl-fo__num">
						<?php
						$tl_out = array();
						foreach ( $tl_num as $tl_x ) {
							/*
							 * L'ETICHETTA RESTA SEMPRE. Una prima versione catturava solo il
							 * numero e stampava "<numero> / Fax: <numero>":
							 * teneva "Fax:" e perdeva "Tel:", e due recapiti accostati con
							 * criteri diversi si leggono come una sbadataggine.
							 */
							if ( preg_match( '/^(.*?)([\w.\-]+@[\w.\-]+\.\w+)$/u', $tl_x, $tl_m ) ) {
								$tl_out[] = esc_html( trim( $tl_m[1] ) ) . ' <a href="' . esc_attr( 'mailto:' . $tl_m[2] ) . '">' . esc_html( $tl_m[2] ) . '</a>';
							} elseif ( preg_match( '/^(.*?)(\+[\d\s()\/]{9,})$/u', $tl_x, $tl_m ) ) {
								$tl_et = trim( $tl_m[1] );
								$tl_nr = trim( $tl_m[2] );
								/*
								 * IL FAX RESTA TESTO: non esiste un protocollo per il fax, e un
								 * link che non fa niente e' peggio di nessun link.
								 */
								if ( 0 === stripos( $tl_et, 'fax' ) ) {
									$tl_out[] = esc_html( $tl_x );
								} else {
									$tl_out[] = ( '' !== $tl_et ? esc_html( $tl_et ) . ' ' : '' )
										. '<a href="' . esc_attr( 'tel:' . preg_replace( '/[^\d+]/', '', $tl_nr ) ) . '">' . esc_html( $tl_nr ) . '</a>';
								}
							} else {
								$tl_out[] = esc_html( $tl_x );
							}
						}
						/* Impilati, uno per riga: in colonna stanno larghi e si leggono meglio. */
						echo wp_kses_post( implode( '<br />', $tl_out ) );
						?>
					</p>
				</div>
			<?php endif; ?>

			<?php if ( $tl_link ) : ?>
				<div class="tl-fo__col">
					<p class="tl-fo__et"><?php echo esc_html( function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( 'Collegamenti', 'tenconi:footer:etichetta-collegamenti' ) : 'Collegamenti' ); ?></p>
					<ul class="tl-fo__nav">
						<?php foreach ( $tl_link as $tl_l ) : ?>
							<li><a href="<?php echo esc_url( $tl_l[1] ); ?>"><?php echo esc_html( $tl_l[0] ); ?></a></li>
						<?php endforeach; ?>
						<li><a href="https://it.linkedin.com/company/tenconi" rel="noopener external">LinkedIn</a></li>
					</ul>
				</div>
			<?php endif; ?>

		</div>

		<?php
		/*
		 * BANDA DI CHIUSURA: il marchio a sinistra, la riga di copyright a filo
		 * destro. Prima qui c'era il nome scritto a piena colonna, a 238 px di corpo:
		 * troppo. Il logo dice la stessa cosa con l'identita' vera dell'azienda, e la
		 * banda tiene comunque la larghezza perche' il copyright chiude a destra —
		 * sulla stessa verticale della fascia qui sopra.
		 *
		 * RIPIEGO SUL FILE DEL TEMA come nell'header, e per lo stesso motivo concreto:
		 * l'allegato del filmato hero e' stato cancellato dalla libreria una volta e
		 * la hero e' rimasta muta. Il footer sta su ogni pagina del sito.
		 */
		/*
		 * 'large' (1024x206, ~99 KB) e non 'full' (1661x334, ~197 KB): qui il
		 * marchio arriva al massimo a 336px CSS (.tl-fo__logo, clamp fino a
		 * 336px), quindi 1024px reali coprono anche 3x con margine — stesso
		 * ragionamento dell'header, taglia diversa perche' qui il logo e' piu'
		 * grande in pagina.
		 */
		$tl_logo = wp_get_attachment_image_url( tenconi_media_da_nome( 'logotenconinobg', 'image' ), 'large' );
		$tl_logo = $tl_logo ? set_url_scheme( $tl_logo, 'relative' ) : '';
		?>
		<div class="tl-fo__fine">

			<a class="tl-fo__marchio" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"
				<?php echo '' !== $tl_logo ? ' style="--tl-marchio: url(\'' . esc_url( $tl_logo ) . '\')"' : ''; ?>>
				<?php if ( '' !== $tl_logo ) : ?>
					<img
						class="tl-fo__logo"
						src="<?php echo esc_url( $tl_logo ); ?>"
						alt="Tenconi SA, dal 1871"
						width="1661" height="334"
						loading="lazy" decoding="async"
					/>
					<?php
					/*
					 * IL RIEMPIMENTO LIQUIDO, e sta qui dentro per un motivo preciso.
					 *
					 * Il committente ha chiesto il componente Liquid Text di 21st.dev:
					 * quello e' React piu' uno shader WebGL (@paper-design/shaders-react)
					 * che riempie un TESTO di fumo in movimento. Un testo qui non c'e'
					 * piu' — al suo posto c'e' il marchio, come richiesto poco prima — e
					 * uno shader WebGL nel footer di ogni pagina di un tema WordPress
					 * sarebbe sproporzionato.
					 *
					 * Quindi il liquido scorre DENTRO IL MARCHIO: il canale alfa del PNG
					 * fa da maschera, e sotto passa il movimento. Nessun testo duplicato,
					 * nessuna libreria, e il logo resta il logo.
					 *
					 * SOLO CON IL PNG: il ripiego e' un JPG con fondo opaco, e mascherare
					 * con quello darebbe un rettangolo colorato invece del marchio.
					 *
					 * L'immagine sotto resta al suo posto: se le maschere CSS non ci sono,
					 * questo strato non si vede e si vede il logo normale.
					 */
					?>
					<span class="tl-fo__liquido" aria-hidden="true"></span>

					<?php
					/*
					 * IL BERSAGLIO DELLO SHADER, vuoto: marchio.js ci monta dentro una
					 * tela WebGL soltanto quando il footer entra in vista, e solo se
					 * WebGL c'e' e il movimento e' gradito. Se non monta, questo span
					 * resta vuoto e trasparente e si vede lo strato liquido in CSS.
					 *
					 * TRE LIVELLI, dal migliore al minimo: shader, liquido in CSS,
					 * immagine. Il piu' basso e' il logo e basta.
					 */
					?>
					<span class="tl-fo__fumo" data-tl-fumo aria-hidden="true"
						data-tl-fumo-src="<?php echo esc_url( $tl_logo ); ?>"></span>
				<?php else : ?>
					<img
						class="tl-fo__logo tl-fo__logo--jpg"
						src="<?php echo esc_url( tenconi_asset_uri( 'assets/img/logo-tenconi.jpg' ) ); ?>"
						alt="Tenconi SA, dal 1871"
						width="1896" height="682"
						loading="lazy" decoding="async"
					/>
				<?php endif; ?>
			</a>

			<?php
			/*
			 * NIENTE "DAL 1871" QUI: il marchio accanto porta gia' scritto "SINCE
			 * 1871". Erano la stessa affermazione a pochi centimetri di distanza.
			 */
			?>
			<p class="tl-fo__cop">
				&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> Tenconi SA
			</p>
		</div>

	</div>
</footer>
</div><!-- #smooth-content -->
</div><!-- #smooth-wrapper -->

<?php wp_footer(); ?>
</body>
</html>
