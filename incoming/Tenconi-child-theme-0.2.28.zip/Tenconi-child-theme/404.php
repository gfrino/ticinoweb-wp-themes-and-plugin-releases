<?php
/**
 * Template 404.
 *
 * Prerequisito della neutralizzazione di ticinoweb_redirect_404_to_home():
 * senza un 404 reale, rimuovere l'hook del parent lascerebbe una pagina vuota.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>
<main id="main" class="tc-main" tabindex="-1">
	<section class="tc-section tc-field--navy">
		<div class="tc-container">
			<div class="tc-section__grid">
				<?php
				tenconi_ref_column(
					array(
						array(
							'label' => 'Errore',
							'value' => '404',
						),
					),
					'404'
				);
				?>
				<div class="tc-content tc-density--editorial">
					<h1 class="tc-display">Pagina non trovata</h1>
					<p class="tc-prose">
						L'indirizzo richiesto non corrisponde a nessuna pagina di questo sito.
						Potrebbe essere stato spostato, oppure il collegamento potrebbe contenere un errore.
					</p>
					<p class="tc-cta-row">
						<?php tenconi_cta_primary( 'Torna alla pagina iniziale', home_url( '/' ) ); ?>
						<?php tenconi_cta_secondary( 'Contatti', home_url( '/contatti/' ) ); ?>
					</p>
				</div>
			</div>
		</div>
	</section>
</main>
<?php
get_footer();
