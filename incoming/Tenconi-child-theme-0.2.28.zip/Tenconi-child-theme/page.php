<?php
/**
 * Template generico delle pagine. PROVVISORIO.
 *
 * Nessun redesign: riusa i campi, i filetti e i token del sistema esistente.
 * Serve a rendere il contenuto leggibile, responsive e accessibile, e a dichiarare
 * lo stato del testo. La direzione artistica resta quella del Lotto 1.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>
<main id="main" class="tc-main" tabindex="-1">
	<?php
	while ( have_posts() ) :
		the_post();
		$tc_stato = tenconi_text_state();
		?>
		<article class="tc-section tc-section--tight tc-field--navy">
			<div class="tc-container">
				<div class="tc-section__grid">
					<?php
					tenconi_ref_column(
						array( array( 'label' => 'Pagina', 'value' => get_the_title() ) ),
						''
					);
					?>
					<div class="tc-content tc-density--editorial">
						<h1 class="tc-display"><?php the_title(); ?></h1>
						<?php if ( has_excerpt() ) : ?>
							<p class="tc-lead"><?php echo esc_html( get_the_excerpt() ); ?></p>
						<?php endif; ?>
						<?php tenconi_text_state_badge(); ?>
					</div>
				</div>
			</div>
		</article>

		<section class="tc-section tc-field--offwhite">
			<div class="tc-container">
				<div class="tc-section__grid">
					<div class="tc-refcol">
						<?php
						if ( has_post_thumbnail() ) {
							the_post_thumbnail( 'tenconi_plate_sm', array( 'class' => 'tc-plate' ) );
						}
						tenconi_documents_list();
						?>
					</div>
					<div class="tc-content tc-prose tc-entry">
						<?php
						the_content();
						if ( '' === trim( wp_strip_all_tags( get_the_content() ) ) ) {
							tenconi_placeholder( 'contenuto non ancora redatto' );
						}
						tenconi_gallery_grid();
						tenconi_rights_note();
						tenconi_source_note();
						?>
					</div>
				</div>
			</div>
		</section>

		<?php tenconi_cta_band(); ?>
	<?php endwhile; ?>
</main>
<?php
get_footer();
