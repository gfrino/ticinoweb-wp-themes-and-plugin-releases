/*
 * IL MARCHIO CHE RESPIRA — shader gemSmoke di Paper Shaders dentro la sagoma del
 * logo Tenconi.
 *
 * DA DOVE VIENE. Il committente ha chiesto il componente Liquid Text di
 * 21st.dev. Il suo sorgente e' dietro autenticazione (il registro risponde 403),
 * ma non serve: quel componente e' un involucro React attorno a
 * @paper-design/shaders, che e' vanilla JS, Apache-2.0 e senza dipendenze. Il
 * motore e' quindi esattamente quello, non un'imitazione — solo senza React.
 *
 * PERCHE' gemSmoke E NON UN ALTRO. La libreria lo descrive cosi': "campi di
 * colore animati posti sopra la forma di un logo caricato". Prende una immagine
 * come sagoma, che e' precisamente il nostro caso: il marchio, non un testo.
 *
 * IL COSTO E' PAGATO SOLO DA CHI GUARDA. Il footer sta su ogni pagina del sito,
 * e un contesto WebGL su ogni pagina per un effetto in fondo sarebbe uno spreco.
 * Quindi lo shader si monta soltanto quando il marchio entra in vista, e chi non
 * arriva in fondo non scarica nemmeno la texture.
 *
 * SE QUALCOSA MANCA non succede niente: senza WebGL, senza la libreria o con il
 * movimento non gradito resta lo strato liquido in CSS, e sotto quello il logo.
 * Tre livelli, e il piu' basso e' una semplice immagine.
 */
( function () {
	'use strict';

	var el = document.querySelector( '[data-tl-fumo]' );
	if ( ! el ) {
		return;
	}

	/* chi chiede di non vedere movimento non vuole un movimento piu' lento */
	if ( window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) {
		return;
	}

	var src = el.getAttribute( 'data-tl-fumo-src' );
	if ( ! src ) {
		return;
	}

	/*
	 * Il controllo su WebGL va fatto prima di montare: la libreria non fallisce
	 * in modo silenzioso, e una tela nera sopra il marchio sarebbe il logo
	 * cancellato.
	 */
	function haWebGL() {
		try {
			var c = document.createElement( 'canvas' );
			return !! ( c.getContext( 'webgl2' ) || c.getContext( 'webgl' ) );
		} catch ( e ) {
			return false;
		}
	}
	if ( ! haWebGL() ) {
		return;
	}

	var fatto = false;

	function monta() {
		if ( fatto || ! window.TLGemSmoke ) {
			return;
		}
		fatto = true;
		window.TLGemSmoke.monta( el, {
			image: src,
			fit: 'contain',
			/*
			 * 1 e non 0,97: adesso che l'immagine sotto si nasconde, la tela e' la
			 * sola cosa che si vede, e deve occupare lo stesso spazio che occupava
			 * il logo — altrimenti il marchio rimpicciolisce quando lo shader parte.
			 */
			scale: 1,
			/* il fondo trasparente: sotto c'e' il bianco del footer, non un rettangolo */
			colorBack: 'rgba(0,0,0,0)',
			/*
			 * IL MARCHIO RESTA PIENO nel blu di casa, e il fumo e' chiaro e passa
			 * DENTRO la sagoma. Le impostazioni originali della libreria fanno
			 * l'opposto — sagoma pallida e pennacchio che esce dai bordi — e per un
			 * logo aziendale e' inaccettabile: il marchio deve essere sempre
			 * leggibile, l'effetto e' l'ospite.
			 */
			colorInner: '#1c385c',
			/*
			 * CINQUE COLORI E NON DUE, ed e' questo che fa "scuro con tocchi di
			 * chiaro" invece di "chiaro".
			 *
			 * Con due stop — un blu medio e un azzurro — il campo di fumo era chiaro
			 * da parte a parte: misurato, il marchio stava a 134 di luminosita' media
			 * contro i 66 dell'originale, cioe' schiarito del doppio. E abbassare
			 * innerGlow non risolveva: schiarisce o scurisce TUTTO insieme, quindi si
			 * otteneva un marchio scuro e piatto, senza piu' nessun tocco.
			 *
			 * La libreria accetta fino a sei colori. Quattro dei cinque qui sono il
			 * blu di casa o piu' scuri, e uno solo, in mezzo, e' quasi bianco: il
			 * campo resta scuro e la luce e' una lama stretta che lo attraversa.
			 * Misurato: luminosita' da 134 a 106, e il tocco di luce da 17 a 58.
			 */
			colors: [ '#16304f', '#1c385c', '#f2f8ff', '#1c385c', '#16304f' ],
			outerGlow: 0,
			innerGlow: 0.6,
			/*
			 * 0,06 E NON 0,7, che e' il valore d'origine della libreria. Lo shader
			 * tratta la sagoma come un corpo di vetro e ne rifrange i bordi: a 0,7
			 * il marchio veniva SFIGURATO — "SINCE 1871" raddoppiato e illeggibile,
			 * il tondino FTA sdoppiato — perche' a 68 px di altezza quelle scritte
			 * sono spesse otto pixel e la rifrazione le mangia. Misurato a schermo,
			 * non stimato.
			 *
			 * A 0,06 il marchio e' fedele all'originale e la luce scorre ancora.
			 * outerDistortion a 0 perche' qualunque valore sopra lo zero fa uscire
			 * il pennacchio dalla sagoma, e un fumo che esce dal logo su un footer
			 * bianco e' una macchia.
			 */
			innerDistortion: 0.06,
			outerDistortion: 0,
			/*
			 * 1,15 e non 0,8: e' la scala del campo di fumo, non del marchio, e con
			 * un campo piu' largo il disegno attraversa la sagoma invece di
			 * ristagnarci. Misurato: il movimento fra due fotogrammi a un secondo di
			 * distanza passa da 0,47 a 1,21 su 255, senza toccare i bordi.
			 */
			size: 1.15,
			/*
			 * 1,5 e non 1: con la rifrazione abbassata a 0,06 il movimento si era
			 * quasi spento — misurato, lo scarto fra fotogrammi a un secondo di
			 * distanza era crollato da 4,3 a 0,35 su 255. La distorsione era quello
			 * che portava il movimento; togliendola servono piu' velocita' e un
			 * campo di fumo piu' largo.
			 *
			 * VALE DIRE IL COMPROMESSO, perche' e' strutturale e non si aggira con i
			 * numeri: in questo shader il movimento visibile E' la rifrazione, ed e'
			 * la rifrazione che sfigura le scritte da otto pixel. Con questo marchio
			 * a 68 px di altezza si puo' avere fedele e discreto, oppure vivace e
			 * sfigurato. Ho scelto fedele. Per averlo piu' vivo servirebbe il logo
			 * piu' grande nel footer, e quella e' una decisione di disegno.
			 */
			speed: 2.2
		} ).then( function () {
			/* il marcatore sta sull'ancora: lo strato liquido in CSS si ritira */
			if ( el.parentNode && el.parentNode.setAttribute ) {
				el.parentNode.setAttribute( 'data-tl-fumo-attivo', '' );
			}
		} ).catch( function () {
			/* niente da fare: resta il liquido in CSS, e sotto il logo */
		} );
	}

	if ( 'IntersectionObserver' in window ) {
		var oss = new IntersectionObserver( function ( voci ) {
			for ( var i = 0; i < voci.length; i++ ) {
				if ( voci[ i ].isIntersecting ) {
					oss.disconnect();
					monta();
					return;
				}
			}
		}, { rootMargin: '250px' } );
		oss.observe( el );
	} else {
		monta();
	}
}() );
