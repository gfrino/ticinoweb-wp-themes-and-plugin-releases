/*
 * Galleria a scorrimento delle fotografie d'archivio.
 *
 * MIGLIORAMENTO PROGRESSIVO, come nav.js. Il markup arriva completo dal PHP e
 * senza questo file resta una pila di fotografie leggibile. Qui si aggiunge la
 * marca `data-tl-car-js`, ed e' solo da quella marca che il CSS si permette di
 * nascondere tutte le diapositive tranne una: se lo script non parte, non c'e'
 * il momento in cui la pagina sembra vuota.
 *
 * PERCHE' role=tablist E NON UN ELENCO DI LINK: la striscia non porta altrove,
 * cambia quale fotografia e' visibile qui. Il modello a schede lo descrive
 * esattamente, e porta con se' la convenzione di tastiera che la gente si
 * aspetta: frecce per scorrere, Home e Fine per gli estremi, e UN SOLO pulsante
 * raggiungibile con Tab (tabindex mobile) invece di dieci fermate inutili.
 */
( function () {
	'use strict';

	var gallerie = document.querySelectorAll( '[data-tl-car]' );
	if ( ! gallerie.length ) {
		return;
	}

	/* Sotto questa distanza il gesto e' un tocco, non una passata. */
	var SOGLIA_GESTO = 40;

	Array.prototype.forEach.call( gallerie, function ( gal ) {

		var diapo = gal.querySelectorAll( '[data-tl-car-d]' );
		var mini  = gal.querySelector( '[data-tl-car-mini]' );
		var prec  = gal.querySelector( '[data-tl-car-prec]' );
		var succ  = gal.querySelector( '[data-tl-car-succ]' );
		var bott  = mini ? mini.querySelectorAll( '[data-tl-car-va]' ) : [];

		if ( diapo.length < 2 ) {
			return;
		}

		var corrente = 0;

		/*
		 * Da qui in poi il CSS sa che puo' collassare la pila: i comandi
		 * esistono e funzionano, quindi nascondere le altre diapositive non
		 * toglie niente a nessuno.
		 */
		gal.setAttribute( 'data-tl-car-js', '' );

		if ( prec ) {
			prec.hidden = false;
		}
		if ( succ ) {
			succ.hidden = false;
		}
		if ( mini ) {
			mini.hidden = false;
		}

		/**
		 * Porta la galleria su una fotografia.
		 *
		 * @param {number}  i      Indice voluto; viene riportato dentro i limiti girando.
		 * @param {boolean} fuoco  Se spostare anche il focus sulla miniatura scelta.
		 */
		function vaiA( i, fuoco ) {
			var n = diapo.length;
			/* Il doppio modulo tiene buono anche -1, che e' "torna in fondo". */
			corrente = ( ( i % n ) + n ) % n;

			Array.prototype.forEach.call( diapo, function ( d, k ) {
				if ( k === corrente ) {
					d.setAttribute( 'data-tl-car-attiva', '' );
				} else {
					d.removeAttribute( 'data-tl-car-attiva' );
				}
			} );

			Array.prototype.forEach.call( bott, function ( b, k ) {
				var scelto = k === corrente;
				b.setAttribute( 'aria-selected', scelto ? 'true' : 'false' );
				/*
				 * Un solo pulsante nell'ordine di tabulazione: e' la convenzione
				 * del modello a schede, e risparmia a chi naviga da tastiera
				 * dieci fermate per attraversare una striscia di miniature.
				 */
				b.setAttribute( 'tabindex', scelto ? '0' : '-1' );
				if ( scelto && fuoco ) {
					b.focus();
				}
			} );
		}

		if ( prec ) {
			prec.addEventListener( 'click', function () {
				vaiA( corrente - 1, false );
			} );
		}
		if ( succ ) {
			succ.addEventListener( 'click', function () {
				vaiA( corrente + 1, false );
			} );
		}

		Array.prototype.forEach.call( bott, function ( b, k ) {
			b.addEventListener( 'click', function () {
				vaiA( k, false );
			} );
		} );

		/*
		 * Tastiera sulla striscia. Il focus resta dov'e' l'occhio: chi preme la
		 * freccia si aspetta di trovarsi sulla miniatura nuova, non di dover
		 * ritabulare, quindi qui `fuoco` e' vero.
		 */
		if ( mini ) {
			mini.addEventListener( 'keydown', function ( e ) {
				var passi = { ArrowLeft: -1, ArrowRight: 1 };
				if ( Object.prototype.hasOwnProperty.call( passi, e.key ) ) {
					e.preventDefault();
					vaiA( corrente + passi[ e.key ], true );
					return;
				}
				if ( 'Home' === e.key ) {
					e.preventDefault();
					vaiA( 0, true );
					return;
				}
				if ( 'End' === e.key ) {
					e.preventDefault();
					vaiA( diapo.length - 1, true );
				}
			} );
		}

		/*
		 * Passata col dito. Si ascolta solo l'asse orizzontale: se il movimento
		 * verticale prevale la persona sta scorrendo la pagina, e rubarle quel
		 * gesto per cambiare fotografia sarebbe un dispetto.
		 */
		var x0 = null;
		var y0 = null;
		var palco = gal.querySelector( '.tl-car__palco' );

		if ( palco ) {
			palco.addEventListener( 'touchstart', function ( e ) {
				x0 = e.changedTouches[ 0 ].clientX;
				y0 = e.changedTouches[ 0 ].clientY;
			}, { passive: true } );

			palco.addEventListener( 'touchend', function ( e ) {
				if ( null === x0 ) {
					return;
				}
				var dx = e.changedTouches[ 0 ].clientX - x0;
				var dy = e.changedTouches[ 0 ].clientY - y0;
				x0 = null;
				y0 = null;

				if ( Math.abs( dx ) < SOGLIA_GESTO || Math.abs( dy ) > Math.abs( dx ) ) {
					return;
				}
				vaiA( dx < 0 ? corrente + 1 : corrente - 1, false );
			}, { passive: true } );
		}

		vaiA( 0, false );
	} );
}() );
