/*
 * RICERCA DAL VIVO nell'header.
 *
 * Ricostruzione dell'interazione di un componente React con Framer Motion, senza
 * React e senza Framer Motion. Qui dentro sta solo cio' che il CSS non puo' fare:
 * il fuoco, l'attesa prima di interrogare, la chiamata, il disegno dei risultati
 * e la tastiera. Tutto il movimento — l'apertura elastica, la lente che si
 * sfoca, i risultati sfalsati — e' CSS, e resta anche se questo file non arriva.
 *
 * SENZA JAVASCRIPT il pulsante non fa niente: e' una scelta, non una mancanza.
 * L'alternativa sarebbe un form che invia a /?s=, ma questo tema non ha un
 * template di ricerca — verificato, search.php non esiste — quindi manderebbe il
 * visitatore su una pagina non progettata. Meglio un comando che non c'e' che un
 * comando che porta in un posto sbagliato.
 *
 * PER LO STESSO MOTIVO Invio non invia da nessuna parte: apre il primo risultato
 * se c'e', altrimenti non fa nulla.
 */
( function () {
	'use strict';

	var box = document.querySelector( '[data-tl-cerca]' );
	if ( ! box ) {
		return;
	}

	var url     = box.getAttribute( 'data-tl-cerca-url' );
	var guscio  = box.querySelector( '.tl-cerca__guscio' );
	var bottone = box.querySelector( '.tl-cerca__b' );
	var campo   = box.querySelector( '.tl-cerca__in' );
	var chiudiX = box.querySelector( '.tl-cerca__x' );
	var lista   = box.querySelector( '.tl-cerca__lista' );
	var vuoto   = box.querySelector( '.tl-cerca__vuoto' );
	var stato   = box.querySelector( '[data-tl-cerca-stato]' );
	if ( ! url || ! campo || ! lista ) {
		return;
	}

	/* 450 ms: sotto, si interroga a ogni lettera; sopra, si sente il ritardo. */
	var ATTESA = 450;

	/*
	 * ARRIVANO GIA' TRADOTTE da wp_localize_script (inc/setup.php): l'annuncio dei
	 * risultati lo scrive questo file lettera per lettera, senza mai tornare al
	 * server — un testo cosi' non passerebbe mai dal filtro di traduzione del
	 * tema. I letterali italiani restano solo come ripiego.
	 */
	var i18nCerca      = window.tlCercaI18n || {};
	var txNessuno      = i18nCerca.nessunRisultato || 'Nessun risultato';
	var txSingolare    = i18nCerca.risultato       || 'risultato';
	var txPlurale      = i18nCerca.risultati       || 'risultati';

	var timer   = null;
	var inVolo  = null;   // AbortController della chiamata in corso
	var voci    = [];     // i nodi dei risultati, per la tastiera
	var attivo  = -1;     // indice selezionato con le frecce

	function annuncia( testo ) {
		if ( stato ) {
			stato.textContent = testo;
		}
	}

	/* ------------------------------------------------------------------
	   Apertura e chiusura
	   ------------------------------------------------------------------ */

	function apri() {
		if ( box.hasAttribute( 'data-aperta' ) ) {
			return;
		}
		box.setAttribute( 'data-aperta', '' );
		/*
		 * Il marcatore sul body serve alla home: sopra il filmato le voci e la
		 * pastiglia sono bianche, e con il campo aperto l'header deve diventare
		 * solido — altrimenti si scriverebbe bianco su bianco.
		 */
		document.body.setAttribute( 'data-tl-cerca-on', '' );
		bottone.setAttribute( 'aria-expanded', 'true' );
		campo.setAttribute( 'aria-expanded', 'false' );
		/*
		 * tabindex torna a zero solo adesso: da chiuso il campo e' invisibile, e un
		 * campo invisibile che raccoglie il focus tabulando fa sparire il cursore.
		 */
		campo.tabIndex = 0;
		if ( chiudiX ) {
			chiudiX.tabIndex = 0;
		}
		campo.focus();
	}

	function chiudi( riportaFocus ) {
		svuota();
		box.removeAttribute( 'data-aperta' );
		document.body.removeAttribute( 'data-tl-cerca-on' );
		bottone.setAttribute( 'aria-expanded', 'false' );
		campo.value    = '';
		campo.tabIndex = -1;
		if ( chiudiX ) {
			chiudiX.tabIndex = -1;
		}
		if ( riportaFocus ) {
			bottone.focus();
		}
	}

	function svuota() {
		if ( timer ) {
			window.clearTimeout( timer );
			timer = null;
		}
		if ( inVolo ) {
			inVolo.abort();
			inVolo = null;
		}
		box.removeAttribute( 'data-carico' );
		box.removeAttribute( 'data-risultati' );
		campo.setAttribute( 'aria-expanded', 'false' );
		campo.removeAttribute( 'aria-activedescendant' );
		lista.textContent = '';
		if ( vuoto ) {
			vuoto.hidden = true;
		}
		voci   = [];
		attivo = -1;
	}

	/* ------------------------------------------------------------------
	   Disegno dei risultati
	   ------------------------------------------------------------------ */

	function disegna( dati ) {
		lista.textContent = '';
		voci   = [];
		attivo = -1;
		campo.removeAttribute( 'aria-activedescendant' );

		var elenco = ( dati && dati.risultati ) || [];

		if ( ! elenco.length ) {
			if ( vuoto ) {
				vuoto.hidden = false;
			}
			box.setAttribute( 'data-risultati', '' );
			campo.setAttribute( 'aria-expanded', 'true' );
			annuncia( txNessuno );
			return;
		}

		if ( vuoto ) {
			vuoto.hidden = true;
		}

		elenco.forEach( function ( r, i ) {
			var li = document.createElement( 'li' );
			var a  = document.createElement( 'a' );
			a.className = 'tl-cerca__r';
			a.href      = r.url;
			a.id        = 'tl-cerca-r-' + i;
			a.setAttribute( 'role', 'option' );
			a.setAttribute( 'aria-selected', 'false' );
			/* l'indice serve al CSS per lo sfalsamento: il ritardo lo calcola la' */
			a.style.setProperty( '--i', String( i ) );

			var t = document.createElement( 'span' );
			t.className = 'tl-cerca__t';
			t.textContent = r.titolo;
			a.appendChild( t );

			if ( r.tipo ) {
				var p = document.createElement( 'span' );
				p.className = 'tl-cerca__tipo';
				p.textContent = r.tipo;
				a.appendChild( p );
			}

			li.appendChild( a );
			lista.appendChild( li );
			voci.push( a );
		} );

		box.setAttribute( 'data-risultati', '' );
		campo.setAttribute( 'aria-expanded', 'true' );
		annuncia( elenco.length + ' ' + ( 1 === elenco.length ? txSingolare : txPlurale ) );
	}

	/* ------------------------------------------------------------------
	   La chiamata
	   ------------------------------------------------------------------ */

	function cerca( q ) {
		if ( inVolo ) {
			/*
			 * Si annulla la precedente: senza, scrivendo in fretta le risposte
			 * tornano in ordine sparso e l'ultima a arrivare puo' essere quella di
			 * due lettere prima.
			 */
			inVolo.abort();
		}
		inVolo = ( 'undefined' !== typeof AbortController ) ? new AbortController() : null;

		box.setAttribute( 'data-carico', '' );

		window.fetch( url + '?q=' + encodeURIComponent( q ), {
			credentials: 'same-origin',
			signal: inVolo ? inVolo.signal : undefined
		} ).then( function ( r ) {
			return r.ok ? r.json() : Promise.reject( new Error( String( r.status ) ) );
		} ).then( function ( dati ) {
			box.removeAttribute( 'data-carico' );
			inVolo = null;
			disegna( dati );
		} ).catch( function ( e ) {
			if ( e && 'AbortError' === e.name ) {
				return;
			}
			box.removeAttribute( 'data-carico' );
			inVolo = null;
			/* un errore di rete non si racconta con un pannello vuoto */
			disegna( { risultati: [] } );
		} );
	}

	/* ------------------------------------------------------------------
	   Eventi
	   ------------------------------------------------------------------ */

	/*
	 * DA MOUSE O DA TASTIERA: si distingue per marcare l'anello di fuoco solo
	 * quando serve. Un CAMPO DI TESTO, a differenza di un pulsante, riceve
	 * SEMPRE :focus-visible quando il fuoco arriva — anche da un clic diretto,
	 * anche da .focus() chiamato via JavaScript dopo un clic. E' per questo che
	 * l'anello blu comparve a ogni apertura, non solo navigando da tastiera:
	 * :focus-visible qui non basta a distinguere i due casi, serve tracciarlo a
	 * mano.
	 *
	 * event.detail e' il modo standard per farlo: su un clic generato dal mouse
	 * vale 1 (o piu' per doppio/triplo clic), su un'attivazione da tastiera
	 * (Invio o Spazio su un pulsante attivo) vale 0.
	 */
	bottone.addEventListener( 'click', function ( e ) {
		if ( 0 === e.detail ) {
			box.setAttribute( 'data-tl-cerca-tastiera', '' );
		} else {
			box.removeAttribute( 'data-tl-cerca-tastiera' );
		}
		apri();
	} );

	if ( chiudiX ) {
		chiudiX.addEventListener( 'click', function () {
			chiudi( true );
		} );
	}

	campo.addEventListener( 'input', function () {
		var q = campo.value.trim();
		if ( timer ) {
			window.clearTimeout( timer );
		}
		if ( q.length < 2 ) {
			svuota();
			return;
		}
		timer = window.setTimeout( function () {
			cerca( q );
		}, ATTESA );
	} );

	function muovi( passo ) {
		if ( ! voci.length ) {
			return;
		}
		if ( attivo >= 0 && voci[ attivo ] ) {
			voci[ attivo ].removeAttribute( 'data-attiva' );
			voci[ attivo ].setAttribute( 'aria-selected', 'false' );
		}
		attivo += passo;
		if ( attivo < 0 ) {
			attivo = voci.length - 1;
		}
		if ( attivo >= voci.length ) {
			attivo = 0;
		}
		var v = voci[ attivo ];
		v.setAttribute( 'data-attiva', '' );
		v.setAttribute( 'aria-selected', 'true' );
		/*
		 * Il fuoco resta nel campo e l'elemento selezionato lo dice
		 * aria-activedescendant: e' il modo previsto per un combobox, e permette di
		 * continuare a scrivere mentre si scorre l'elenco con le frecce.
		 */
		campo.setAttribute( 'aria-activedescendant', v.id );
	}

	campo.addEventListener( 'keydown', function ( e ) {
		if ( 'ArrowDown' === e.key ) {
			e.preventDefault();
			muovi( 1 );
			return;
		}
		if ( 'ArrowUp' === e.key ) {
			e.preventDefault();
			muovi( -1 );
			return;
		}
		if ( 'Enter' === e.key ) {
			var meta = ( attivo >= 0 && voci[ attivo ] ) ? voci[ attivo ] : voci[ 0 ];
			if ( meta ) {
				e.preventDefault();
				window.location.href = meta.href;
			}
		}
	} );

	/*
	 * ESCAPE A DUE STADI, come si aspetta chi usa la tastiera: la prima volta
	 * chiude l'elenco e lascia il testo, cosi' si puo' correggere; la seconda
	 * chiude la ricerca e riporta il fuoco al pulsante.
	 */
	document.addEventListener( 'keydown', function ( e ) {
		if ( 'Escape' !== e.key && 'Esc' !== e.key ) {
			return;
		}
		if ( ! box.hasAttribute( 'data-aperta' ) ) {
			return;
		}
		if ( box.hasAttribute( 'data-risultati' ) ) {
			e.stopPropagation();
			svuota();
			campo.focus();
			return;
		}
		e.stopPropagation();
		chiudi( true );
	}, true );

	document.addEventListener( 'click', function ( e ) {
		if ( box.hasAttribute( 'data-aperta' ) && ! box.contains( e.target ) ) {
			chiudi( false );
		}
	} );
}() );
