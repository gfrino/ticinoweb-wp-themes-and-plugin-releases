/**
 * Selettore "Immagine nel menu": apre la libreria media di WordPress e scrive
 * l'ID scelto nel campo nascosto, con l'anteprima accanto.
 */
( function ( $ ) {
	'use strict';

	$( document ).on( 'click', '[data-tenconi-menu-img-scegli]', function ( e ) {
		e.preventDefault();
		var $box = $( this ).closest( '[data-tenconi-menu-img]' );
		var frame = wp.media( {
			title: tenconiMenuImg.titolo,
			button: { text: tenconiMenuImg.pulsante },
			library: { type: 'image' },
			multiple: false
		} );
		frame.on( 'select', function () {
			var img = frame.state().get( 'selection' ).first().toJSON();
			var src = ( img.sizes && img.sizes.medium ) ? img.sizes.medium.url : img.url;
			$box.find( '[data-tenconi-menu-img-campo]' ).val( img.id );
			$box.find( '.tenconi-menu-img__anteprima' ).empty().append(
				$( '<img>', { src: src, alt: '' } ).css( { maxWidth: '300px', height: 'auto', display: 'block' } )
			);
			$box.find( '[data-tenconi-menu-img-rimuovi]' ).prop( 'hidden', false );
		} );
		frame.open();
	} );

	$( document ).on( 'click', '[data-tenconi-menu-img-rimuovi]', function ( e ) {
		e.preventDefault();
		var $box = $( this ).closest( '[data-tenconi-menu-img]' );
		$box.find( '[data-tenconi-menu-img-campo]' ).val( '' );
		$box.find( '.tenconi-menu-img__anteprima' ).empty();
		$( this ).prop( 'hidden', true );
	} );
}( jQuery ) );
