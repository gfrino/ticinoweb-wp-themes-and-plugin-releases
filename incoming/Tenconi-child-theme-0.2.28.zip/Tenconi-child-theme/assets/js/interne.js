/*
 * Pagine interne: "Mostra tutte le fotografie".
 *
 * Senza questo file si vedono tutte, ed e' giusto cosi': il CSS nasconde le
 * fotografie in piu' solo quando html ha data-tl-js, e il pulsante nasce con
 * hidden e si accende solo qui.
 */
( function () {
	'use strict';
	var bottoni = document.querySelectorAll( '[data-tl-int-tutte]' );
	Array.prototype.forEach.call( bottoni, function ( b ) {
		var sez = b.closest( '[data-tl-int-sez]' );
		if ( ! sez ) {
			return;
		}
		b.hidden = false;
		b.setAttribute( 'aria-expanded', 'false' );
		b.addEventListener( 'click', function () {
			sez.setAttribute( 'data-aperta', '' );
			b.setAttribute( 'aria-expanded', 'true' );
			b.parentNode.hidden = true;
			var prima = sez.querySelector( '.tl-int__i--extra a, .tl-int__i--extra img' );
			if ( prima && prima.focus ) {
				prima.setAttribute( 'tabindex', '-1' );
				prima.focus( { preventScroll: true } );
			}
		} );
	} );
}() );
