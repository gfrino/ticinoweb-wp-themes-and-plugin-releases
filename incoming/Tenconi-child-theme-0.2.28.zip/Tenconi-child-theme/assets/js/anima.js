/*
 * ANIMAZIONI DELLA HOME: intro, scorrimento morbido, comparse allo scroll.
 *
 * GSAP 3.15 con ScrollTrigger e ScrollSmoother (licenza standard, vedi
 * assets/vendor). Se per qualche ragione le librerie non arrivano, la pagina
 * resta intera: ogni pezzo qui sotto controlla prima di agire, e il CSS mostra
 * tutto per difetto — le comparse si attivano solo dopo che questo file ha messo
 * il suo marcatore.
 *
 * PREFERS-REDUCED-MOTION SPEGNE TUTTO: niente scorrimento morbido, niente
 * comparse, niente intro. Non una versione ridotta: spento. Chi chiede di non
 * vedere movimento non vuole un movimento piu' lento.
 */
( function () {
	'use strict';

	var doc   = document.documentElement;
	var fermo = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
	var G     = window.gsap;

	/* ==================================================================
	   1. INTRO
	   ================================================================== */

	var velo = document.querySelector( '[data-tl-intro-velo]' );

	function chiudiIntro() {
		if ( ! velo || velo.hidden ) {
			return;
		}
		try {
			sessionStorage.setItem( 'tlIntro', '1' );
		} catch ( e ) {}

		doc.removeAttribute( 'data-tl-intro' );
		velo.setAttribute( 'data-uscita', '' );

		var v = velo.querySelector( 'video' );
		if ( v ) {
			v.pause();
		}

		/*
		 * Si aspetta la fine della dissolvenza prima di togliere il velo dal
		 * documento: rimuoverlo subito farebbe sparire l'immagine di colpo.
		 * transitionend piu' un tempo di sicurezza, perche' se la transizione non
		 * parte l'evento non arriva mai e il velo resterebbe li' per sempre.
		 */
		var via = function () {
			velo.hidden = true;
			velo.removeAttribute( 'data-uscita' );
			doc.removeAttribute( 'data-tl-bloccato' );
			if ( window.__tlSmoother ) {
				window.__tlSmoother.paused( false );
			}
			/* Le posizioni cambiano quando il velo esce dal flusso. */
			if ( window.ScrollTrigger ) {
				window.ScrollTrigger.refresh();
			}

			/*
			 * ANNUNCIA LA CHIUSURA. hero.js aspetta questo evento per far partire il
			 * filmato di fondo: prima girava dietro al velo, cioe' consumava rete e
			 * batteria per mostrare niente, e arrivava alla hero gia' a meta'.
			 * Un evento e non una chiamata diretta: i due file restano indipendenti
			 * e ognuno funziona anche senza l'altro.
			 */
			document.dispatchEvent( new CustomEvent( 'tl:intro-chiusa' ) );
		};
		velo.addEventListener( 'transitionend', via, { once: true } );
		window.setTimeout( via, 900 );
	}

	if ( velo ) {
		if ( fermo || ! doc.hasAttribute( 'data-tl-intro' ) ) {
			/* Mai vista in questa sessione, o moto non gradito: si salta del tutto. */
			velo.hidden = true;
		} else {
			velo.hidden = false;
			doc.setAttribute( 'data-tl-bloccato', '' );

			var vi = velo.querySelector( 'video' );
			if ( vi ) {
				vi.muted = true;
				var src = vi.getAttribute( 'data-src' );
				if ( src ) {
					vi.setAttribute( 'src', src );
				}
				/* Finito il filmato, il velo se ne va da solo. */
				vi.addEventListener( 'ended', chiudiIntro, { once: true } );
				/*
				 * Se il filmato non parte — rete, formato, avvio automatico negato —
				 * non si resta chiusi dietro un velo nero: si chiude e si va avanti.
				 */
				vi.addEventListener( 'error', chiudiIntro, { once: true } );
				var pr = vi.play();
				if ( pr && pr.catch ) {
					pr.catch( chiudiIntro );
				}
			} else {
				chiudiIntro();
			}

			var salta = velo.querySelector( '[data-tl-intro-salta]' );
			if ( salta ) {
				salta.addEventListener( 'click', chiudiIntro );
			}
			/* Escape salta l'intro: e' il gesto che tutti provano. */
			document.addEventListener( 'keydown', function ( e ) {
				if ( 'Escape' === e.key || 'Esc' === e.key ) {
					chiudiIntro();
				}
			} );
		}
	}

	/* ==================================================================
	   2. SCORRIMENTO MORBIDO
	   ================================================================== */

	if ( ! G || fermo ) {
		/* Senza GSAP o con il moto non gradito si mostra tutto e si esce. */
		doc.setAttribute( 'data-tl-anima-off', '' );
		return;
	}

	if ( window.ScrollTrigger ) {
		G.registerPlugin( window.ScrollTrigger );
	}
	if ( window.ScrollSmoother ) {
		G.registerPlugin( window.ScrollSmoother );
	}

	if ( window.ScrollSmoother && document.getElementById( 'smooth-content' ) ) {
		/*
		 * smooth: 1 e' un secondo di inerzia — presente ma sobrio. Oltre 1,5 il
		 * sito sembra scorrere sott'acqua, che su un sito industriale stona.
		 * smoothTouch resta FALSO: sul telefono lo scorrimento nativo e' migliore
		 * di qualunque emulazione, e toglierlo fa arrabbiare la gente.
		 */
		window.__tlSmoother = window.ScrollSmoother.create( {
			wrapper:     '#smooth-wrapper',
			content:     '#smooth-content',
			smooth:      1,
			smoothTouch: false,
			effects:     true,
			normalizeScroll: false
		} );

		if ( velo && ! velo.hidden ) {
			window.__tlSmoother.paused( true );
		}
	}

	/* ==================================================================
	   3. COMPARSE ALLO SCROLL
	   ================================================================== */

	doc.setAttribute( 'data-tl-anima', '' );

	if ( ! window.ScrollTrigger ) {
		doc.setAttribute( 'data-tl-anima-off', '' );
		return;
	}

	/*
	 * UN SOLO MOVIMENTO, ripetuto: opacita' piu' 28 px dal basso. Nessun volo dai
	 * lati, nessun rimbalzo, nessuna rotazione. Sulle immagini si aggiunge una
	 * scala da 1,04 a 1: si legge come un assestamento, non come un effetto, e
	 * resta dentro il riquadro perche' e' una transform — il layout non si muove.
	 */
	function comparsa( sel, opzioni ) {
		var el = Array.prototype.slice.call( document.querySelectorAll( sel ) );
		if ( ! el.length ) {
			return;
		}
		var o = opzioni || {};
		el.forEach( function ( gruppo ) {
			var figli = o.figli
				? Array.prototype.slice.call( gruppo.querySelectorAll( o.figli ) )
				: [ gruppo ];
			if ( ! figli.length ) {
				return;
			}
			G.from( figli, {
				opacity: 0,
				y: o.y || 28,
				duration: 0.9,
				ease: 'power2.out',
				stagger: figli.length > 1 ? 0.09 : 0,
				scrollTrigger: {
					trigger: gruppo,
					start: 'top 84%',
					once: true
				}
			} );
		} );
	}

	/* i titoli e il testo delle fasce finali */
	comparsa( '.tl-titolo', { y: 20 } );
	comparsa( '.tl-oriz__t', { y: 22 } );
	/*
	 * IL TITOLO E' ESCLUSO dalla comparsa generica: ha la sua, che sale da dietro
	 * un bordo. Due animazioni sullo stesso elemento non si sommano, si pestano i
	 * piedi — la seconda registrata vince e la prima resta a meta'.
	 */
	comparsa( '.tl-fascia__testo', { figli: ':scope > *:not(.tl-fascia__l)' } );

	/* il titolo delle fasce: sale da dietro il bordo del suo contenitore */
	Array.prototype.slice.call( document.querySelectorAll( '.tl-fascia__l-i' ) ).forEach( function ( sp ) {
		G.from( sp, {
			yPercent: 115,
			duration: 1.05,
			ease: 'power3.out',
			scrollTrigger: { trigger: sp.parentNode, start: 'top 88%', once: true }
		} );
	} );

	/*
	 * LE MIRE si stringono in posizione: opacita' piu' una scala da 1,07 a 1.
	 * L'animazione lavora sul CONTENITORE e non sui quattro angoli, perche' gli
	 * angoli hanno una rotazione nel CSS e la scala e' la stessa proprieta':
	 * toccarla li' vorrebbe dire cancellare la rotazione.
	 */
	Array.prototype.slice.call( document.querySelectorAll( '[data-tl-mire]' ) ).forEach( function ( m ) {
		G.from( m, {
			opacity: 0,
			scale: 1.07,
			duration: 1.1,
			ease: 'power3.out',
			scrollTrigger: { trigger: m.parentNode, start: 'top 82%', once: true }
		} );
	} );

	/*
	 * LA CIFRA CHE SI CONTA. L'idea e' il Number Ticker di MagicUI — che e' un
	 * componente React, quindi qui e' riscritto in GSAP: un oggetto finto che va
	 * da 0 al valore e scrive il testo a ogni fotogramma.
	 *
	 * LA LARGHEZZA SI BLOCCA PRIMA DI AZZERARE, e non e' pignoleria: da "0" a
	 * "34" la cifra cambia larghezza, e senza un minimo misurato tutta la frase
	 * si riflusserebbe a ogni fotogramma della salita.
	 */
	Array.prototype.slice.call( document.querySelectorAll( '[data-tl-cifra]' ) ).forEach( function ( el ) {
		var fine = parseInt( el.getAttribute( 'data-tl-cifra' ), 10 );
		if ( ! isFinite( fine ) ) {
			return;
		}
		el.style.minWidth = Math.ceil( el.getBoundingClientRect().width ) + 'px';
		el.textContent = '0';
		var v = { n: 0 };
		G.to( v, {
			n: fine,
			duration: 1.5,
			ease: 'power2.out',
			onUpdate: function () {
				el.textContent = String( Math.round( v.n ) );
			},
			onComplete: function () {
				/* il valore esatto, non l'arrotondamento dell'ultimo fotogramma */
				el.textContent = String( fine );
			},
			scrollTrigger: { trigger: el, start: 'top 90%', once: true }
		} );
	} );
	/*
	 * PARALLASSE SULLE FASCE FINALI. L'immagine e' piu' alta della sua cornice e
	 * si muove al contrario dello scorrimento: la fotografia sembra ferma nello
	 * spazio mentre la pagina le passa davanti.
	 *
	 * yPercent e non top o margin: e' una transform, quindi il browser non
	 * ricalcola niente, e il movimento resta dentro la cornice che ha overflow
	 * hidden. Il 12% e' volutamente poco — un parallasse che si nota e' un
	 * parallasse sbagliato.
	 */
	Array.prototype.slice.call( document.querySelectorAll( '[data-tl-fascia]' ) ).forEach( function ( f ) {
		var img = f.querySelector( '.tl-fascia__i' );
		if ( ! img ) {
			return;
		}
		G.set( img, { scale: 1.14 } );
		G.fromTo(
			img,
			{ yPercent: -6 },
			{
				yPercent: 6,
				ease: 'none',
				scrollTrigger: {
					trigger: f,
					start: 'top bottom',
					end: 'bottom top',
					scrub: true
				}
			}
		);
	} );

	/* ==================================================================
	   4. LE AREE: sequenza orizzontale ancorata
	   ==================================================================
	   La sezione si ferma sullo schermo e la pista scorre di lato per una
	   distanza pari a quanto sporge oltre la finestra. Non un valore inventato:
	   si misura, cosi' l'ultimo pannello si fermq esattamente al bordo destro e
	   non resta ne' spazio vuoto ne' contenuto tagliato.

	   NON SI ACCENDE SOTTO I 900 px ne' con il moto non gradito: la' la colonna
	   verticale del CSS e' migliore, e il marcatore data-tl-oriz-on non viene
	   messo affatto. */

	var sez   = document.querySelector( '[data-tl-oriz]' );
	var pista = document.querySelector( '[data-tl-oriz-pista]' );

	if ( sez && pista && window.matchMedia( '(min-width: 901px)' ).matches ) {

		doc.setAttribute( 'data-tl-oriz-on', '' );

		/* Si misura DOPO che il CSS ha reso la pista una riga. */
		requestAnimationFrame( function () {

			var corsa = function () {
				return Math.max( 0, pista.scrollWidth - window.innerWidth );
			};

			if ( corsa() <= 0 ) {
				/* Ci sta tutto: niente da ancorare, e ancorare sarebbe una finta. */
				doc.removeAttribute( 'data-tl-oriz-on' );
				return;
			}

			/*
			 * CODA FINALE. Senza, l'ultimo pannello — ENERGIA — arrivava a fine
			 * corsa e la pagina riprendeva subito a scorrere in verticale: si
			 * affacciava e sparva nello stesso istante, mentre gli altri quattro
			 * avevano avuto una schermata intera per farsi guardare.
			 *
			 * COME E' FATTA. Una timeline in due tempi invece di un solo tween:
			 * prima la pista si muove, poi un tratto VUOTO in cui non si muove
			 * niente ma l'ancoraggio regge. Lo scorrimento continua a consumare
			 * corsa, la sezione resta ferma sullo schermo, e ENERGIA rimane in
			 * vista finche' la coda non e' esaurita.
			 *
			 * IL 8% E' UNA FRAZIONE, non un valore in pixel, e la ragione conta:
			 * cosi' la coda e la corsa scalano insieme quando la finestra cambia
			 * dimensione, e su uno schermo largo non diventa una pausa infinita.
			 *
			 * Era 0,15 (circa 470 px di pausa): troppo lunga, la sezione sembrava
			 * incastrata. A 0,08 la pausa e' circa 250 px — abbastanza per accorgersi
			 * di ENERGIA, non tanto da chiedersi se lo scorrimento si e' rotto.
			 */
			var CODA = 0.08;

			var tl = G.timeline( {
				scrollTrigger: {
					trigger: sez,
					start: 'top top',
					end: function () {
						return '+=' + Math.round( corsa() * ( 1 + CODA ) );
					},
					pin: true,
					scrub: 1,
					anticipatePin: 1,
					invalidateOnRefresh: true
				}
			} );

			/* 1. la pista scorre: durata 1, cioe' tutta la corsa laterale */
			tl.to( pista, {
				x: function () {
					return -corsa();
				},
				ease: 'none',
				duration: 1
			} );

			/* 2. la coda: niente si muove, l'ancoraggio tiene ENERGIA sullo schermo */
			tl.to( {}, { duration: CODA } );

			/*
			 * LE ICONE, a velocita' leggermente diversa dalla loro fotografia — un
			 * parallasse dentro un parallasse: la SEZIONE gia' scorre in orizzontale
			 * per conto suo (la pista sopra), e ogni icona si muove UN PO' PIU' 0 UN
			 * PO' MENO di quel movimento, cosi' sembra scivolare sopra l'immagine
			 * invece di essere incollata.
			 *
			 * containerAnimation: tl e' la tecnica che GSAP prevede apposta per
			 * questo — animare un elemento DENTRO uno scroller orizzontale pinnato.
			 * Senza, ogni ScrollTrigger qui sotto misurerebbe lo scorrimento
			 * VERTICALE della pagina (che durante il pin non si muove: la sezione
			 * e' ferma sullo schermo), e non succederebbe mai niente. Con
			 * containerAnimation, "start"/"end" si misurano sulla posizione
			 * ORIZZONTALE del pannello DENTRO la pista, non sulla pagina.
			 *
			 * 19 A 38 PX TOTALI, non un valore a caso: e' un centimetro CSS (96dpi),
			 * diviso a meta' fra il lato "prima" e il lato "dopo" — l'icona parte un
			 * po' piu' a destra di dove sta a riposo e finisce un po' piu' a
			 * sinistra, mentre il suo pannello attraversa lo schermo.
			 */
			Array.prototype.slice.call( document.querySelectorAll( '[data-tl-pan-ico]' ) ).forEach( function ( ico ) {
				var pannello = ico.closest( '.tl-pan' );
				if ( ! pannello ) {
					return;
				}
				G.fromTo(
					ico,
					{ x: 19 },
					{
						x: -19,
						ease: 'none',
						scrollTrigger: {
							trigger: pannello,
							containerAnimation: tl,
							start: 'left right',
							end: 'right left',
							scrub: true
						}
					}
				);
			} );
		} );
	}

	/* ==================================================================
	   5. L'INVITO A SCORRERE
	   ================================================================== */

	var giu = document.querySelector( '[data-tl-giu]' );
	if ( giu ) {

		/*
		 * IL CLIC PASSA DA SCROLLSMOOTHER, non dal salto nativo. Con lo
		 * scorrimento morbido attivo un'ancora nativa fa saltare la pagina e poi
		 * lo smoother la rincorre: si vede uno scatto. Con smoother.scrollTo il
		 * movimento e' uno solo. Senza smoother resta scrollIntoView, e senza
		 * JavaScript l'href fa il suo lavoro da solo.
		 */
		giu.addEventListener( 'click', function ( e ) {
			var id  = giu.getAttribute( 'href' );
			var dst = id && '#' !== id ? document.querySelector( id ) : null;
			if ( ! dst ) {
				return;
			}
			e.preventDefault();
			if ( window.__tlSmoother ) {
				window.__tlSmoother.scrollTo( dst, true );
			} else {
				dst.scrollIntoView( { behavior: 'smooth', block: 'start' } );
			}
		} );

		/*
		 * Sparisce al primo scorrimento: ha detto quello che doveva dire. Insieme
		 * all'opacita' si toglie anche dalla tabulazione, perche' un comando
		 * invisibile che riceve il fuoco e' una trappola.
		 */
		G.to( giu, {
			opacity: 0,
			duration: 0.4,
			onComplete: function () {
				giu.setAttribute( 'tabindex', '-1' );
				giu.setAttribute( 'aria-hidden', 'true' );
			},
			onReverseComplete: function () {
				giu.removeAttribute( 'tabindex' );
				giu.removeAttribute( 'aria-hidden' );
			},
			scrollTrigger: {
				trigger: '.tl-hero',
				start: 'top+=80 top',
				toggleActions: 'play none none reverse'
			}
		} );
	}

	/*
	 * Il titolo della hero entra al caricamento, non allo scroll: e' gia' in vista.
	 * Se c'e' l'intro si aspetta che il velo esca, altrimenti l'animazione parte
	 * dietro al filmato e nessuno la vede.
	 */
	function entrataHero() {
		var pezzi = document.querySelectorAll( '.tl-hero__sopra, .tl-hero__t, .tl-hero__sotto' );
		if ( ! pezzi.length ) {
			return;
		}
		G.from( pezzi, {
			opacity: 0,
			y: 26,
			duration: 1,
			ease: 'power3.out',
			stagger: 0.12,
			delay: 0.15
		} );
	}

	if ( velo && ! velo.hidden ) {
		velo.addEventListener( 'transitionend', entrataHero, { once: true } );
		window.setTimeout( entrataHero, 12000 );
	} else {
		entrataHero();
	}
}() );
