/*
 * HERO: header trasparente in cima, solido allo scroll, e il filmato di fondo.
 *
 * PERCHE' INTERSECTIONOBSERVER E NON UN LISTENER SU SCROLL. Un listener su
 * scroll gira decine di volte al secondo e legge il layout a ogni colpo, che e'
 * il modo classico di far scattare lo scorrimento. Qui basta sapere UNA cosa:
 * se un sensore alto un pixel, messo in fondo alla hero, e' ancora in vista. Il
 * browser la calcola da se' e ci avvisa due volte in tutta la pagina.
 *
 * IL FILMATO SI CARICA QUI, non nel markup: cosi' i 19,85 MB non partono se il
 * moto non e' gradito o se la connessione e' a consumo, e la fotografia sotto
 * resta il contenuto vero.
 */
( function () {
	'use strict';

	var doc = document.documentElement;

	/* ------------------------------------------------------------------
	   1. Stato dell'header
	   ------------------------------------------------------------------ */

	var sensore = document.querySelector( '[data-tl-sensore]' );

	if ( sensore && 'IntersectionObserver' in window ) {
		new IntersectionObserver(
			function ( voci ) {
				/*
				 * Il sensore in vista significa "siamo ancora sulla hero", quindi
				 * header trasparente. Appena esce, header solido.
				 */
				doc.toggleAttribute( 'data-tl-hd-solido', ! voci[ 0 ].isIntersecting );
			},
			{ threshold: 0 }
		).observe( sensore );
	} else if ( sensore ) {
		/* Senza IntersectionObserver l'header resta solido: leggibile sempre. */
		doc.setAttribute( 'data-tl-hd-solido', '' );
	}

	/* ------------------------------------------------------------------
	   2. Il filmato di fondo
	   ------------------------------------------------------------------ */

	var cassa = document.querySelector( '[data-tl-hero-video]' );
	var video = cassa && cassa.querySelector( 'video' );
	if ( ! video ) {
		return;
	}

	var fermo = window.matchMedia( '(prefers-reduced-motion: reduce)' );

	/**
	 * La connessione permette 20 MB di fondale?
	 *
	 * Non e' pignoleria: il filmato pesa 19,85 MB e su una rete a consumo sarebbe
	 * un regalo che nessuno ha chiesto. Dove l'informazione non c'e' — Safari e
	 * Firefox non espongono navigator.connection — si procede: meglio un dubbio
	 * che spegnere il fondale a tutti.
	 */
	function reteAdatta() {
		var c = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
		if ( ! c ) {
			return true;
		}
		if ( c.saveData ) {
			return false;
		}
		return ! /(^|\W)(slow-)?2g($|\W)/.test( String( c.effectiveType || '' ) );
	}

	/**
	 * Comincia a SCARICARE, e mostra il primo fotogramma.
	 *
	 * Separato dal far suonare, ed e' la chiave: il caricamento parte subito, a
	 * ogni visita, mentre la riproduzione aspetta il momento giusto. Cosi' la
	 * finestra fra poster e filmato non esiste piu' — quando arriva il momento di
	 * suonare il video e' gia' decodificato e sta gia' mostrando il suo primo
	 * fotogramma, identico al poster.
	 */
	function carica() {
		if ( video.dataset.caricato || fermo.matches || ! reteAdatta() ) {
			return;
		}
		var src = video.getAttribute( 'data-src' );
		if ( ! src ) {
			return;
		}
		video.muted = true;
		video.setAttribute( 'src', src );
		video.dataset.caricato = '1';

		/*
		 * loadeddata e non canplay: a loadeddata c'e' gia' un fotogramma
		 * disponibile, e il fotogramma e' tutto quello che serve per scoprire il
		 * video sopra il poster. Aspettare canplay ritarderebbe senza motivo.
		 */
		video.addEventListener( 'loadeddata', function () {
			cassa.setAttribute( 'data-acceso', '' );
		}, { once: true } );
	}

	/** Fa suonare, se e' stato caricato. */
	function suona() {
		if ( ! video.dataset.caricato || fermo.matches ) {
			return;
		}
		var p = video.play();
		if ( p && p.catch ) {
			/*
			 * Se il browser rifiuta non si insiste e non si stampa un errore: resta
			 * il primo fotogramma, che e' identico al poster e non sembra un guasto.
			 */
			p.catch( function () {} );
		}
	}

	function spegni() {
		video.pause();
		video.removeAttribute( 'src' );
		video.load();
		delete video.dataset.caricato;
		cassa.removeAttribute( 'data-acceso' );
	}

	/*
	 * SI ASPETTA CHE L'INTRO ESCA. Se il velo e' aperto il filmato non parte:
	 * girerebbe dietro a uno schermo nero, spendendo rete e batteria per mostrare
	 * niente, e quando il velo si toglie sarebbe gia' a meta'. Cosi' invece la
	 * hero comincia dal primo fotogramma nel momento in cui la si vede.
	 *
	 * Il velo lo cerca qui e non lo assume: anima.js gira prima di questo file e
	 * ha gia' deciso se mostrarlo, quindi lo stato letto adesso e' quello vero.
	 */
	var velo   = document.querySelector( '[data-tl-intro-velo]' );
	var attesa = velo && ! velo.hidden;

	if ( fermo.matches ) {
		cassa.setAttribute( 'data-fermo', '' );
	} else {
		/*
		 * SI CARICA SEMPRE E SUBITO, con o senza intro. L'intro copriva il
		 * caricamento solo alla PRIMA visita della sessione: dalla seconda non
		 * c'era piu' niente a coprirlo. Ora il caricamento non ha bisogno di essere
		 * coperto, perche' quello che si vede intanto e' il primo fotogramma del
		 * filmato stesso.
		 */
		carica();

		if ( attesa ) {
			/* Suona quando il velo esce: non deve girare dietro a uno schermo nero. */
			document.addEventListener( 'tl:intro-chiusa', suona, { once: true } );
			window.setTimeout( suona, 14000 );
		} else {
			suona();
		}
	}

	/* Se l'utente cambia idea nelle preferenze di sistema, si adegua subito. */
	if ( fermo.addEventListener ) {
		fermo.addEventListener( 'change', function () {
			if ( fermo.matches ) {
				spegni();
				cassa.setAttribute( 'data-fermo', '' );
			} else {
				cassa.removeAttribute( 'data-fermo' );
				carica();
				suona();
			}
		} );
	}

	/*
	 * Fuori dalla vista si mette in pausa: un filmato che gira dietro tre schermate
	 * di contenuto consuma batteria e banda per niente.
	 */
	if ( 'IntersectionObserver' in window ) {
		new IntersectionObserver( function ( v ) {
			if ( ! video.dataset.caricato ) {
				return;
			}
			if ( v[ 0 ].isIntersecting ) {
				video.play().catch( function () {} );
			} else {
				video.pause();
			}
		}, { threshold: 0 } ).observe( cassa );
	}
}() );
