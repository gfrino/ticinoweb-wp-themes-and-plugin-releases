/*
 * Navigazione Legacy-Modernized.
 *
 * MIGLIORAMENTO PROGRESSIVO. Senza JavaScript la navigazione resta usabile: su
 * desktop le tendine si aprono con :hover e :focus-within, che sono CSS puro; su
 * mobile il pannello e' nel documento e i sottomenu sono chiusi, quindi l'unica
 * cosa che smette di funzionare e' il pulsante. Questo file aggiunge il clic, la
 * chiusura con Escape e il ritorno del focus al comando che aveva aperto.
 *
 * PERCHE' aria-expanded VIENE AGGIORNATO ANCHE SU HOVER E FOCUS: se l'attributo
 * dicesse "false" mentre il pannello e' visibile sullo schermo, uno screen reader
 * annuncerebbe l'opposto di quello che c'e'. Il CSS non puo' toccare un
 * attributo, quindi lo allinea il JavaScript.
 */
( function () {
	'use strict';

	var body = document.body;

	/*
	 * Marca il documento: da qui il CSS sa che il pannello mobile puo' essere
	 * chiuso, perche' esiste un pulsante che lo riapre. Senza questa marca il
	 * pannello resta in flusso e la navigazione funziona comunque.
	 */
	document.documentElement.setAttribute( 'data-tl-js', '' );

	/* ----------------------------------------------------------------------
	   Lo skip link deve spostare il FOCUS, non solo scorrere.
	   Senza questo, premendo Tab dopo lo skip la navigazione riparte
	   dall'inizio dell'header e il salto non e' servito a niente.
	   ---------------------------------------------------------------------- */

	var skip = document.querySelector( '.tl-skip' );
	if ( skip ) {
		skip.addEventListener( 'click', function () {
			var target = document.getElementById( 'main' );
			if ( ! target ) {
				return;
			}
			if ( ! target.hasAttribute( 'tabindex' ) ) {
				target.setAttribute( 'tabindex', '-1' );
			}
			window.requestAnimationFrame( function () {
				target.focus( { preventScroll: true } );
			} );
		} );
	}

	/* ======================================================================
	   MEGA MENU — desktop
	   ======================================================================
	   Ricostruzione del comportamento di un Radix NavigationMenu senza React ne'
	   Radix. Quello che questo file deve fare, e che il CSS da solo non puo':

	     MISURARE il pannello aperto, perche' la superficie condivisa dietro i
	     pannelli si adatta al contenuto e una misura non si scrive a mano.

	     DECIDERE LA DIREZIONE con cui il contenuto entra, che dipende da quale
	     voce era aperta prima.

	     L'INTENZIONE DEL PUNTATORE: aprire dopo una pausa breve e chiudere dopo
	     una piu' lunga. Senza le pause, attraversare la navigazione per arrivare
	     al logo aprirebbe e chiuderebbe quattro pannelli, e scendere dalla voce al
	     pannello lo chiuderebbe a metta' strada.

	   Con :hover puro — cioe' senza questo file — i pannelli funzionano comunque:
	   il CSS li apre, ognuno con la propria superficie. Quello che si perde e' la
	   superficie unica che si ridimensiona, non la navigazione.
	   ====================================================================== */

	var nav    = document.querySelector( '[data-tl-nav]' );
	var gruppi = Array.prototype.slice.call( document.querySelectorAll( '[data-tl-group]' ) );

	/* Pause misurate sull'uso, non prese da una libreria. */
	var ATTESA_APRE  = 110;
	var ATTESA_CHIUDE = 220;

	var timerApre   = null;
	var timerChiude = null;
	var corrente    = null;   // il gruppo aperto adesso
	var fissato     = null;   // aperto col clic: il puntatore che esce non lo chiude
	var zittito     = null;   // gruppo appena chiuso con Escape: il focus non lo riapre

	function triggerDi( gruppo ) {
		return gruppo.querySelector( '.tl-nav__b' );
	}

	function indiceDi( gruppo ) {
		return gruppi.indexOf( gruppo );
	}

	/*
	 * LA MISURA VIENE DAL CONTENUTO, non dal pannello: il pannello e' a zero per
	 * zero e taglia: chiedergli le sue dimensioni restituirebbe zero. Il contenuto
	 * dentro e' a larghezza naturale, quindi ha una misura anche mentre e' nascosto.
	 *
	 * Le fotografie sono differite e possono non essere ancora arrivate: l'altezza
	 * resta comunque stabile perche' la cornice della scheda ha un aspect-ratio
	 * dichiarato, quindi occupa il suo spazio prima di avere l'immagine.
	 */
	function misura( gruppo ) {
		var pannello = gruppo.querySelector( '[data-tl-mega]' );
		if ( ! pannello || ! nav ) {
			return;
		}
		var dentro = pannello.querySelector( '.tl-mega__in' );
		if ( ! dentro ) {
			return;
		}
		nav.style.setProperty( '--tl-fw', Math.ceil( dentro.offsetWidth ) + 'px' );
		nav.style.setProperty( '--tl-fh', Math.ceil( dentro.offsetHeight ) + 'px' );
	}

	function apri( gruppo ) {
		if ( ! gruppo || corrente === gruppo ) {
			return;
		}

		var pannello = gruppo.querySelector( '[data-tl-mega]' );
		var da       = corrente;

		/* la direzione: da destra se si arriva da una voce piu' a destra */
		if ( pannello ) {
			var verso = 'prima';
			if ( da ) {
				verso = indiceDi( gruppo ) > indiceDi( da ) ? 'da-destra' : 'da-sinistra';
			}
			pannello.removeAttribute( 'data-motion' );
			/*
			 * Il reflow forzato serve: riassegnare lo stesso valore non fa ripartire
			 * un'animazione CSS, e passando avanti e indietro fra due voci la
			 * direzione resterebbe ferma alla prima volta.
			 */
			void pannello.offsetWidth;
			pannello.setAttribute( 'data-motion', verso );
		}

		if ( da ) {
			da.removeAttribute( 'data-hover' );
			da.removeAttribute( 'data-open' );
			var tb = triggerDi( da );
			if ( tb ) {
				tb.setAttribute( 'aria-expanded', 'false' );
			}
		}

		misura( gruppo );
		gruppo.setAttribute( 'data-hover', '' );
		if ( nav ) {
			nav.setAttribute( 'data-tl-aperta', '' );
		}
		/*
		 * Il marcatore sul body serve alla home: sopra il filmato le voci sono
		 * bianche, e con un pannello bianco aperto sotto sarebbero illeggibili. Il
		 * CSS usa questo attributo per rendere solido l'header, come fa gia' quando
		 * si apre il pannello mobile.
		 */
		body.setAttribute( 'data-tl-mega', '' );
		var t = triggerDi( gruppo );
		if ( t ) {
			t.setAttribute( 'aria-expanded', 'true' );
		}
		corrente = gruppo;
	}

	function chiudi( riportaFocus ) {
		if ( ! corrente ) {
			return;
		}
		var g = corrente;
		g.removeAttribute( 'data-hover' );
		g.removeAttribute( 'data-open' );
		var t = triggerDi( g );
		if ( t ) {
			t.setAttribute( 'aria-expanded', 'false' );
			if ( riportaFocus ) {
				t.focus();
			}
		}
		body.removeAttribute( 'data-tl-mega' );
		if ( nav ) {
			nav.removeAttribute( 'data-tl-aperta' );
			/* le misure tornano a zero: la superficie si richiude su se stessa */
			nav.style.setProperty( '--tl-fw', '0px' );
			nav.style.setProperty( '--tl-fh', '0px' );
		}
		corrente = null;
		fissato  = null;
		return g;
	}

	function annullaTimer() {
		window.clearTimeout( timerApre );
		window.clearTimeout( timerChiude );
	}

	gruppi.forEach( function ( gruppo ) {
		var trigger = triggerDi( gruppo );
		if ( ! trigger ) {
			return;
		}

		gruppo.addEventListener( 'mouseenter', function () {
			annullaTimer();
			zittito = null;
			/* fra un pannello aperto e l'altro non si aspetta: si passa */
			if ( corrente ) {
				apri( gruppo );
			} else {
				timerApre = window.setTimeout( function () {
					apri( gruppo );
				}, ATTESA_APRE );
			}
		} );

		gruppo.addEventListener( 'mouseleave', function () {
			annullaTimer();
			if ( fissato === gruppo ) {
				return;
			}
			timerChiude = window.setTimeout( function () {
				/* non si chiude se nel frattempo il focus e' entrato nel pannello */
				if ( ! gruppo.contains( document.activeElement ) ) {
					chiudi( false );
				}
			}, ATTESA_CHIUDE );
		} );

		/* Il clic fissa il pannello: utile col puntatore e indispensabile col tocco. */
		trigger.addEventListener( 'click', function () {
			annullaTimer();
			if ( corrente === gruppo && fissato === gruppo ) {
				chiudi( false );
				return;
			}
			apri( gruppo );
			fissato = gruppo;
			gruppo.setAttribute( 'data-open', '' );
		} );

		/*
		 * TABULAZIONE: entrando col focus il pannello si apre, altrimenti i suoi
		 * collegamenti sarebbero raggiungibili ma invisibili. Dopo Escape no: il
		 * focus torna sul trigger e riaprirebbe nello stesso istante quello che si
		 * e' appena chiuso.
		 */
		gruppo.addEventListener( 'focusin', function () {
			if ( zittito === gruppo ) {
				return;
			}
			annullaTimer();
			apri( gruppo );
		} );

		gruppo.addEventListener( 'focusout', function () {
			/*
			 * focusout scatta anche passando da un collegamento all'altro dentro lo
			 * stesso pannello: si rimanda di un tick e si guarda dove e' finito il
			 * focus davvero.
			 */
			window.setTimeout( function () {
				if ( gruppo.contains( document.activeElement ) ) {
					return;
				}
				zittito = null;
				if ( fissato === gruppo ) {
					return;
				}
				/* col puntatore ancora sopra non si chiude: comanda il mouse */
				if ( gruppo.matches( ':hover' ) ) {
					return;
				}
				if ( corrente === gruppo ) {
					chiudi( false );
				}
			}, 0 );
		} );
	} );

	/* Un clic fuori chiude quello che era stato fissato col clic. */
	document.addEventListener( 'click', function ( e ) {
		if ( corrente && ! corrente.contains( e.target ) ) {
			chiudi( false );
		}
	} );

	/*
	 * AL RIDIMENSIONAMENTO si rimisura: il pannello cambia forma sotto i 1360 px —
	 * due schede invece di tre e la colonna sotto invece che a lato — e la
	 * superficie resterebbe della misura di prima.
	 */
	window.addEventListener( 'resize', function () {
		if ( corrente ) {
			misura( corrente );
		}
	} );

	/* ----------------------------------------------------------------------
	   Pannello mobile e accordion
	   ---------------------------------------------------------------------- */

	var burger = document.querySelector( '[data-tl-burger]' );
	/*
	 * Le due frasi arrivano gia' tradotte da wp_localize_script, in inc/setup.php:
	 * un'etichetta scritta qui in JavaScript non torna mai al server, quindi non
	 * passerebbe mai dal filtro di traduzione del tema. L'oggetto puo' mancare se
	 * lo script e' stato accodato diversamente altrove: i due letterali italiani
	 * restano come ripiego, non come fonte primaria.
	 */
	var i18nMenu = window.tlNavI18n || {};
	var txApriMenu   = i18nMenu.apriMenu   || 'Apri il menu';
	var txChiudiMenu = i18nMenu.chiudiMenu || 'Chiudi il menu';

	function chiudiMenu( riportaFocus ) {
		body.removeAttribute( 'data-tl-menu' );
		if ( burger ) {
			burger.setAttribute( 'aria-expanded', 'false' );
			burger.setAttribute( 'aria-label', txApriMenu );
			if ( riportaFocus ) {
				burger.focus();
			}
		}
	}

	if ( burger ) {
		burger.addEventListener( 'click', function () {
			if ( body.hasAttribute( 'data-tl-menu' ) ) {
				chiudiMenu( false );
			} else {
				body.setAttribute( 'data-tl-menu', '' );
				burger.setAttribute( 'aria-expanded', 'true' );
				burger.setAttribute( 'aria-label', txChiudiMenu );
			}
		} );
	}

	Array.prototype.forEach.call(
		document.querySelectorAll( '[data-tl-acc] > .tl-mnav__b' ),
		function ( b ) {
			b.addEventListener( 'click', function () {
				var li     = b.parentElement;
				var aperto = li.hasAttribute( 'data-open' );
				if ( aperto ) {
					li.removeAttribute( 'data-open' );
				} else {
					li.setAttribute( 'data-open', '' );
				}
				b.setAttribute( 'aria-expanded', aperto ? 'false' : 'true' );
			} );
		}
	);

	/* ----------------------------------------------------------------------
	   Escape chiude cio' che e' aperto e riporta sempre il focus al comando.
	   Ordine: prima una tendina aperta, poi una in cui sta il focus, poi il
	   pannello mobile.
	   ---------------------------------------------------------------------- */

	document.addEventListener( 'keydown', function ( e ) {
		if ( 'Escape' !== e.key && 'Esc' !== e.key ) {
			return;
		}

		if ( corrente ) {
			annullaTimer();
			/*
			 * Si ricorda quale gruppo era: il focus sta per tornare sul suo trigger, e
			 * senza questa memoria focusin lo riaprirebbe nello stesso istante. La
			 * memoria si cancella appena il focus o il puntatore lasciano il gruppo.
			 */
			var g   = corrente;
			var era = g.contains( document.activeElement );
			chiudi( era );
			zittito = g;
			return;
		}

		if ( body.hasAttribute( 'data-tl-menu' ) ) {
			chiudiMenu( true );
		}
	} );

	/* ======================================================================
	   IL SELETTORE DI LINGUA
	   ======================================================================
	   Indipendente dal mega menu di sopra: qui il pannello ha una misura fissa
	   e poche righe, quindi non serve ne' misurarlo ne' calcolare una direzione
	   di ingresso — bastano le stesse tre cose dei vecchi dropdown di questo
	   tema, prima del mega menu: hover/focus aprono via CSS, il clic rende
	   l'apertura persistente per chi usa il tocco, Escape chiude e riporta il
	   focus al pulsante.

	   NON C'E' SE C'E' UNA SOLA LINGUA: il PHP non stampa nemmeno il markup del
	   pulsante finche' il pannello del plugin non ne pubblica una seconda,
	   quindi qui sotto tutto e' condizionato all'esistenza dell'elemento.
	   ====================================================================== */

	var lingue = document.querySelector( '[data-tl-lingue]' );
	if ( lingue ) {
		var linguaB = lingue.querySelector( '.tl-lang--b' );

		function chiudiLingue( riportaFocus ) {
			lingue.removeAttribute( 'data-open' );
			lingue.setAttribute( 'data-closed', '' );
			linguaB.setAttribute( 'aria-expanded', 'false' );
			if ( riportaFocus ) {
				linguaB.focus();
			}
		}

		linguaB.addEventListener( 'click', function () {
			var aperto = lingue.hasAttribute( 'data-open' );
			if ( aperto ) {
				chiudiLingue( false );
			} else {
				lingue.removeAttribute( 'data-closed' );
				lingue.setAttribute( 'data-open', '' );
				linguaB.setAttribute( 'aria-expanded', 'true' );
			}
		} );

		lingue.addEventListener( 'mouseenter', function () {
			lingue.removeAttribute( 'data-closed' );
			linguaB.setAttribute( 'aria-expanded', 'true' );
		} );
		lingue.addEventListener( 'mouseleave', function () {
			lingue.removeAttribute( 'data-closed' );
			if ( ! lingue.hasAttribute( 'data-open' ) ) {
				linguaB.setAttribute( 'aria-expanded', 'false' );
			}
		} );
		lingue.addEventListener( 'focusout', function () {
			window.setTimeout( function () {
				if ( ! lingue.contains( document.activeElement ) ) {
					lingue.removeAttribute( 'data-closed' );
					if ( ! lingue.hasAttribute( 'data-open' ) ) {
						linguaB.setAttribute( 'aria-expanded', 'false' );
					}
				}
			}, 0 );
		} );

		document.addEventListener( 'click', function ( e ) {
			if ( lingue.hasAttribute( 'data-open' ) && ! lingue.contains( e.target ) ) {
				chiudiLingue( false );
			}
		} );

		document.addEventListener( 'keydown', function ( e ) {
			if ( 'Escape' !== e.key && 'Esc' !== e.key ) {
				return;
			}
			if ( lingue.hasAttribute( 'data-open' ) || lingue.contains( document.activeElement ) ) {
				chiudiLingue( true );
			}
		} );
	}

}() );
