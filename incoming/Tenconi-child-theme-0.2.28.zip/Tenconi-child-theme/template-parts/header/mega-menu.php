<?php
/**
 * Mega menu a 7 voci, accessibile e funzionante senza JavaScript.
 *
 * Senza JS i pannelli si aprono su :hover e :focus-within via CSS: la
 * navigazione e completa. Con JS i bottoni acquisiscono aria-expanded e la
 * chiusura con Esc. Nessuna trappola di focus.
 *
 * "Settori" non e voce principale: e una colonna dentro Prodotti e Lavorazioni.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * Sorgente dei link: il MENU WORDPRESS REALE assegnato a tenconi_primary, letto
 * da inc/nav-menus.php. Non una seconda sitemap scritta a mano: le voci sono
 * oggetti WordPress, modificabili da Aspetto > Menu.
 *
 * La catena di ripiego, in ordine: menu reale, risolutore CF-2, array del Lotto 1.
 * Cambia la sorgente dei dati, non il markup.
 */
$tc_nav = function_exists( 'tenconi_primary_nav' ) ? tenconi_primary_nav() : array();
if ( empty( $tc_nav ) && function_exists( 'tenconi_nav_resolved' ) ) {
	$tc_nav = tenconi_nav_resolved();
}
if ( empty( $tc_nav ) && function_exists( 'tenconi_nav' ) ) {
	$tc_nav = tenconi_nav();
}
if ( empty( $tc_nav ) ) {
	return;
}
?>
<nav class="tc-nav" id="tc-primary-nav" aria-label="Menu principale">
	<ul class="tc-nav__list">
		<?php foreach ( $tc_nav as $tc_i => $tc_item ) : ?>
			<?php $tc_has_panel = ! empty( $tc_item['cols'] ); ?>
			<li class="tc-nav__item<?php echo $tc_has_panel ? ' tc-nav__item--has-panel' : ''; ?>">
				<?php if ( $tc_has_panel ) : ?>
					<?php $tc_panel_id = 'tc-panel-' . (int) $tc_i; ?>
					<span class="tc-nav__group">
						<a class="tc-nav__link" href="<?php echo esc_url( tenconi_href( $tc_item['url'] ) ); ?>">
							<?php echo esc_html( $tc_item['label'] ); ?>
						</a>
						<button
							class="tc-nav__toggle"
							type="button"
							aria-expanded="false"
							aria-controls="<?php echo esc_attr( $tc_panel_id ); ?>"
						>
							<span class="screen-reader-text">
								Apri il sottomenu di <?php echo esc_html( $tc_item['label'] ); ?>
							</span>
							<span class="tc-nav__chevron" aria-hidden="true"></span>
						</button>
					</span>
					<div class="tc-nav__panel" id="<?php echo esc_attr( $tc_panel_id ); ?>">
						<div class="tc-nav__panel-inner">
							<?php foreach ( $tc_item['cols'] as $tc_col ) : ?>
								<div class="tc-nav__col">
									<p class="tc-nav__col-title tc-tech"><?php echo esc_html( $tc_col['title'] ); ?></p>
									<ul class="tc-nav__sublist">
										<?php foreach ( $tc_col['items'] as $tc_sub ) : ?>
											<li>
												<a
													class="tc-nav__sublink<?php echo ! empty( $tc_sub['feature'] ) ? ' tc-nav__sublink--feature' : ''; ?>"
													href="<?php echo esc_url( tenconi_href( $tc_sub['url'] ) ); ?>"
												>
													<?php echo esc_html( $tc_sub['label'] ); ?>
												</a>
											</li>
										<?php endforeach; ?>
									</ul>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				<?php else : ?>
					<a class="tc-nav__link" href="<?php echo esc_url( tenconi_href( $tc_item['url'] ) ); ?>">
						<?php echo esc_html( $tc_item['label'] ); ?>
					</a>
				<?php endif; ?>
			</li>
		<?php endforeach; ?>
	</ul>
</nav>
