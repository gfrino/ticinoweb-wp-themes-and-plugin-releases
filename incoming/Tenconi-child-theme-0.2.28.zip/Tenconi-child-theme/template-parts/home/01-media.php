<?php
/**
 * 1 — La riga di apertura del legacy: due video YouTube e una figura al centro.
 *
 * COSA E' CAMBIATO E PERCHE'. La fase precedente metteva qui tre fotografie
 * dell'archivio, perche' l'incorporamento di YouTube era stato rinviato in attesa
 * di una decisione sul consenso ai cookie. Il confronto affiancato ha mostrato che
 * era la divergenza piu' evidente della pagina: nel legacy questa riga e' due
 * filmati e la copertina di un opuscolo, con tre didascalie precise.
 * I video sono quindi ripristinati.
 *
 * UNA SOLA DEVIAZIONE DAL LEGACY, dichiarata: il dominio dell'incorporamento e'
 * youtube-nocookie.com invece di youtube.com. Rende lo stesso lettore, identico
 * all'occhio, ma non deposita cookie di profilazione prima che l'utente prema
 * play. Su un sito aziendale svizzero e' la scelta prudente mentre il banner e'
 * ancora da definire. Per tornare esatti al legacy basta togliere "-nocookie".
 *
 * LE PROPORZIONI SONO MISURATE: il blocco legacy dichiara
 * data-aspect-ratio="56,532%", cioe' 1,769 di larghezza su altezza, non 16:9
 * esatto. Le didascalie sono link, e nel legacy sono sottolineate.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$tl_m = tenconi_home_media();
if ( ! $tl_m ) {
	return;
}
?>
<section class="tl-media" aria-label="<?php echo esc_attr( function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( 'In evidenza', 'tenconi:home:media-aria' ) : 'In evidenza' ); ?>">
	<div class="tl-wrap">
		<div class="tl-griglia">
			<?php foreach ( $tl_m as $tl_i ) : ?>
				<figure class="tl-media__f">

					<?php if ( 'video' === $tl_i['tipo'] ) : ?>
						<div class="tl-video">
							<iframe
								src="https://www.youtube-nocookie.com/embed/<?php echo esc_attr( $tl_i['youtube'] ); ?>?rel=0"
								title="<?php echo esc_attr( $tl_i['titolo'] ); ?>"
								loading="lazy"
								allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
								allowfullscreen
								referrerpolicy="strict-origin-when-cross-origin"></iframe>
						</div>

					<?php elseif ( 'immagine' === $tl_i['tipo'] && tenconi_home_img_ok( $tl_i['img'] ) ) : ?>
						<?php
						/*
						 * Nel legacy questa figura e' cliccabile e porta al PDF dei giunti.
						 * Il link avvolge l'immagine, come nel sorgente legacy.
						 */
						$tl_pdf = ! empty( $tl_i['pdf_url'] ) ? $tl_i['pdf_url'] : '';
						if ( '' !== $tl_pdf ) {
							printf( '<a href="%s" rel="noopener">', esc_url( $tl_pdf ) );
						}
						echo wp_get_attachment_image(
							$tl_i['img'],
							'full',
							false,
							array(
								'alt'      => $tl_i['alt'],
								'class'    => 'tl-media__img tl-media__img--giunti',
								'loading'  => 'eager',
								'decoding' => 'async',
								'sizes'    => '(max-width: 900px) 100vw, 33vw',
							)
						);
						if ( '' !== $tl_pdf ) {
							echo '</a>';
						}
						?>

					<?php elseif ( 'mancante' === $tl_i['tipo'] ) : ?>
						<?php
						/*
						 * LEGACY ASSET MISSING. Lo slot resta vuoto e lo dice. Non viene
						 * riempito con una fotografia simile: la parita' visiva non si
						 * ottiene mettendo un'altra immagine al posto giusto.
						 */
						?>
						<div class="tl-vuoto" role="img"
							aria-label="Immagine legacy non disponibile: <?php echo esc_attr( $tl_i['legacy'] ); ?>">
							<span class="tl-vuoto__t">Asset legacy non disponibile</span>
							<span class="tl-vuoto__n"><?php echo esc_html( $tl_i['legacy'] ); ?></span>
						</div>
					<?php endif; ?>

					<figcaption class="tl-media__cap">
						<?php if ( 'video' === $tl_i['tipo'] ) : ?>
							<a class="tl-cap__a" href="https://youtu.be/<?php echo esc_attr( $tl_i['youtube'] ); ?>"
								rel="noopener external"><?php echo esc_html( $tl_i['didascalia'] ); ?></a>
						<?php elseif ( ! empty( $tl_i['pdf_url'] ) ) : ?>
							<?php /* Nel legacy la didascalia centrale e' un link al PDF dei giunti. */ ?>
							<a class="tl-cap__a" href="<?php echo esc_url( $tl_i['pdf_url'] ); ?>"
								rel="noopener"><?php echo esc_html( $tl_i['didascalia'] ); ?></a>
						<?php else : ?>
							<?php echo esc_html( $tl_i['didascalia'] ); ?>
						<?php endif; ?>
					</figcaption>
				</figure>
			<?php endforeach; ?>
		</div>
	</div>
</section>
