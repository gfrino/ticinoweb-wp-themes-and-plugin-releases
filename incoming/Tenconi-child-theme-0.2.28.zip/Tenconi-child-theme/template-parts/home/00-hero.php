<?php
/**
 * HERO — il filmato aziendale a tutto schermo, senza lettore visibile.
 *
 * IL FILMATO E' UN FILE LOCALE, non piu' un incorporamento YouTube. La differenza
 * non e' di gusto: con un <video> nostro il lettore NON ESISTE, quindi non c'e'
 * niente da nascondere. Con YouTube servivano tre accorgimenti insieme —
 * parametri, una scala che spingesse titolo e watermark fuori dal ritaglio, e
 * pointer-events: none per impedire che i comandi comparissero al passaggio del
 * mouse — e nessuno dei tre era una garanzia: bastava che l'avvio automatico non
 * partisse per rivedere il pulsante centrale in mezzo alla pagina.
 *
 * In piu' spariscono il terzo che traccia, la richiesta di rete verso un altro
 * dominio e la dipendenza da un servizio esterno per la pagina d'ingresso.
 *
 * L'ASSET: Hero-video-compressed.mp4, 1920x1080, 31 secondi, 19,85 MB, con
 * traccia audio AAC che viene silenziata. Risolto per nome file, vedi sotto.
 *
 * URL RELATIVO E NON wp_get_attachment_url(). Su questa installazione quella
 * funzione restituisce https mentre siteurl e home sono http: il browser
 * chiederebbe https sulla porta 8000, che non e' servita, e il filmato non
 * partirebbe. set_url_scheme( ..., 'relative' ) da' /tenconi/wp-content/... che
 * funziona su entrambi gli schemi e sopravvive al passaggio a https in
 * produzione.
 *
 * MUTO PER FORZA. L'avvio automatico funziona solo su un video silenzioso: e' la
 * regola dei browser, non una scelta. Ed e' anche giusto — un fondale che parla
 * non lo vuole nessuno.
 *
 * FALLBACK. Sotto il filmato c'e' sempre una fotografia reale: si vede prima che
 * il video sia pronto, se la rete e' lenta, e con prefers-reduced-motion, dove il
 * filmato non viene nemmeno scaricato.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * Il filmato e la fotografia di ripiego. L'attachment 500 e' 1O0A0429.jpg, la
 * struttura in acciaio al crepuscolo col treno in filé: scura e larga, quindi il
 * testo bianco sopra si legge senza doverla annerire.
 */
/*
 * PER NOME E NON PER ID. L'allegato 837 e' stato cancellato e ricaricato come
 * 841: un numero scritto a mano si rompe al primo ricaricamento del media, e la
 * hero resta muta senza dirlo a nessuno.
 */
$tl_video   = tenconi_media_da_nome( 'Hero-video-compressed', 'video' );
$tl_sopratit = 'Dal 1871';
$tl_titolo  = 'Meccanica di precisione per la ferrovia e l’industria';
$tl_sotto   = 'Due stabilimenti in Ticino, ad Airolo e Cadenazzo.';

$tl_src = wp_get_attachment_url( $tl_video );
$tl_src = $tl_src ? set_url_scheme( $tl_src, 'relative' ) : '';
?>
<section class="tl-hero" aria-labelledby="tl-hero-t">

	<div class="tl-hero__sfondo">
		<?php
		/*
		 * IL POSTER E' IL PRIMO FOTOGRAMMA DEL FILMATO STESSO, ed e' il punto di
		 * tutta la soluzione.
		 *
		 * Prima qui c'era l'attachment 500, la struttura in acciaio col treno: una
		 * fotografia diversa dal filmato, quindi il passaggio da poster a video era
		 * un CAMBIO DI IMMAGINE — si vedeva, e infatti dava fastidio.
		 *
		 * Ora il poster e' hero-frame0.jpg, estratto dal filmato stesso al secondo
		 * 0,08 (non a zero: il fotogramma zero di molti file e' nero). Poster e
		 * primo fotogramma del video sono la STESSA immagine, con la stessa
		 * proporzione 1920x1080 e lo stesso object-fit: cover. Il passaggio non e'
		 * piu' un cambio di immagine, e' la stessa immagine che comincia a
		 * muoversi. Non c'e' niente da notare, e questo vale a OGNI visita — non
		 * solo alla prima, dove c'era il velo dell'intro a coprire.
		 *
		 * E' un file del tema e non un allegato: il filmato hero e' gia' stato
		 * cancellato e ricaricato una volta, e il poster non deve dipendere da un
		 * ID che puo' sparire.
		 */
		?>
		<img
			class="tl-hero__poster"
			src="<?php echo esc_url( tenconi_asset_uri( 'assets/img/hero-frame0.jpg' ) ); ?>"
			alt=""
			aria-hidden="true"
			<?php
			/*
			 * NESSUN width/height qui. Con height: 100% in conflitto il browser
			 * risolve sul rapporto d'aspetto e il poster veniva 1440x810 contro i
			 * 1440x900 del video: due riquadri diversi, due ritagli diversi, e il
			 * salto che si vedeva. Il riquadro lo detta il CSS.
			 */
			?>
			fetchpriority="high" decoding="async"
		/>

		<?php
		/*
		 * Il <source> NON e' nel markup: lo mette hero.js. Cosi' i 19,85 MB non
		 * partono se il moto non e' gradito o se la connessione e' a consumo, e la
		 * fotografia sotto resta il contenuto vero.
		 */
		?>
		<div class="tl-hero__v" data-tl-hero-video>
			<video
				data-src="<?php echo esc_url( $tl_src ); ?>"
				muted
				loop
				playsinline
				<?php /* auto e non none: si comincia a scaricare subito, senza aspettare. */ ?>
				preload="auto"
				aria-hidden="true"
				tabindex="-1"
			></video>
		</div>

		<?php /* Velo minimo: alza il contrasto del testo senza spegnere il filmato. */ ?>
		<div class="tl-hero__velo" aria-hidden="true"></div>
	</div>

	<div class="tl-hero__c">
		<div class="tl-wrap">
			<p class="tl-hero__sopra"><?php echo esc_html( $tl_sopratit ); ?></p>
			<h1 class="tl-hero__t" id="tl-hero-t"><?php echo esc_html( $tl_titolo ); ?></h1>
			<p class="tl-hero__sotto"><?php echo esc_html( $tl_sotto ); ?></p>
		</div>
	</div>

	<?php
	/*
	 * L'INVITO A SCORRERE, ed e' un COMANDO, non una decorazione.
	 *
	 * E' un <a> verso la prima sezione e non un <button>: funziona anche senza
	 * JavaScript, dove il salto e' istantaneo ma la destinazione e' giusta. Con il
	 * JavaScript diventa uno scorrimento morbido, coerente con ScrollSmoother.
	 *
	 * Prima era aria-hidden e pointer-events: none — corretto per una freccia
	 * muta, sbagliato ora che si preme: ha un'etichetta leggibile e sta
	 * nell'ordine di tabulazione.
	 *
	 * Il chevron non c'e' piu': e' solo una riga con un segmento che scende.
	 */
	?>
	<a class="tl-giu" href="#tl-aree" data-tl-giu>
		<span class="tl-solo-lettori"><?php echo esc_html( function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( 'Scorri al contenuto', 'tenconi:home:hero-scorri' ) : 'Scorri al contenuto' ); ?></span>
		<span class="tl-giu__pista" aria-hidden="true"><span class="tl-giu__seg"></span></span>
	</a>

	<?php /* Il sensore: quando esce dalla vista, l'header diventa solido. */ ?>
	<span class="tl-hero__sensore" data-tl-sensore aria-hidden="true"></span>
</section>
