<?php
/**
 * PAGINA INTERNA, NUOVO SISTEMA — le cinque aree di attivita'
 * (tre settori e due lavorazioni). I pezzi stanno in inc/interne.php.
 *
 * Titolo e gruppo vengono dalla voce di menu (chi clicca "Energia" arriva su
 * "Energia"), le gallerie dalla mappa delle aree, l'introduzione dal riassunto
 * o dalla descrizione del settore, l'immagine grande dalla scheda del menu.
 *
 * Variabili attese: $tl_slug (chiave nella mappa delle aree).
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$tl_mappa = tenconi_legacy_aree_media();
$tl_slug  = isset( $tl_slug ) ? $tl_slug : '';
if ( ! isset( $tl_mappa[ $tl_slug ] ) ) {
	return;
}
$tl_p = $tl_mappa[ $tl_slug ];

$tl_ogg = get_queried_object();
if ( $tl_ogg instanceof WP_Term ) {
	$tl_intro = wp_strip_all_tags( term_description( $tl_ogg ) );
	$tl_url   = get_term_link( $tl_ogg );
	$tl_url   = is_wp_error( $tl_url ) ? '' : $tl_url;
	$tl_nome  = $tl_ogg->name;
} else {
	$tl_intro = has_excerpt() ? get_the_excerpt() : '';
	$tl_url   = get_permalink();
	$tl_nome  = get_the_title();
}

$tl_voce   = tenconi_int_voce( $tl_slug );
$tl_titolo = '' !== $tl_voce['titolo'] ? $tl_voce['titolo'] : $tl_nome;

$tl_sezioni = array();
foreach ( array( 'g1', 'g2' ) as $tl_g ) {
	if ( ! empty( $tl_p[ $tl_g ]['img'] ) && tenconi_int_conta( $tl_p[ $tl_g ]['img'] ) ) {
		$tl_sezioni[ $tl_g ] = mb_convert_case( mb_strtolower( $tl_p[ $tl_g ]['etichetta'] ), MB_CASE_TITLE );
	}
}
$tl_indice = array();
foreach ( $tl_sezioni as $tl_g => $tl_t ) {
	$tl_indice[] = array( 'tl-sez-' . $tl_g, $tl_t, tenconi_int_conta( $tl_p[ $tl_g ]['img'] ) );
}
?>
<main id="main" class="tl-main tl-int" tabindex="-1">
	<?php
	tenconi_int_testa(
		array(
			'gruppo' => $tl_voce['gruppo'],
			'titolo' => $tl_titolo,
			'intro'  => $tl_intro,
			'hero'   => tenconi_mega_immagine( $tl_slug, $tl_url )['img'],
			'indice' => $tl_indice,
		)
	);

	$tl_n = 0;
	foreach ( $tl_sezioni as $tl_g => $tl_t ) {
		tenconi_int_galleria(
			array(
				'id'     => 'tl-sez-' . $tl_g,
				'num'    => ++$tl_n,
				'titolo' => $tl_t,
				'elenco' => $tl_p[ $tl_g ]['elenco'],
				'img'    => $tl_p[ $tl_g ]['img'],
				'alt'    => $tl_titolo . ' — ' . mb_strtolower( $tl_t ),
			)
		);
	}

	tenconi_int_cta();
	?>
</main>
