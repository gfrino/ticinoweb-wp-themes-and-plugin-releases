<?php
/**
 * PAGINA INTERNA, NUOVO SISTEMA — le pagine del menu (Chi siamo, Storia,
 * Direzione, Team, 150esimo, Supporto, Sostenibilita', Condizioni di vendita).
 *
 * Il contenuto e' lo stesso di prima, dalle stesse fonti: il testo della pagina
 * nel CMS oppure i blocchi della mappa legacy, il carosello d'archivio, la
 * griglia di fotografie, la carta delle sedi. Cambia la forma, che e' quella
 * delle aree di attivita' (inc/interne.php).
 *
 * Variabili attese: $tl_slug (lo slug della pagina).
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$tl_slug = isset( $tl_slug ) ? (string) $tl_slug : '';
$tl_map  = tenconi_legacy_menu_media();
$tl_post = get_queried_object();

$tl_p = isset( $tl_map[ $tl_slug ] )
	? $tl_map[ $tl_slug ]
	: array(
		'titolo' => $tl_post ? get_the_title( $tl_post ) : '',
		'testo'  => array(),
		'img'    => array(),
		'cms'    => true,
	);

/* Lo slug della pagina e la chiave del menu coincidono, tranne una. */
$tl_chiave = '150esimo' === $tl_slug ? 'centocinquantesimo' : $tl_slug;
$tl_voce   = tenconi_int_voce( $tl_chiave );
$tl_titolo = '' !== $tl_voce['titolo'] ? $tl_voce['titolo'] : $tl_p['titolo'];
$tl_intro  = ( $tl_post && has_excerpt( $tl_post ) ) ? get_the_excerpt( $tl_post ) : '';
$tl_hero   = tenconi_mega_immagine( $tl_chiave, $tl_post ? get_permalink( $tl_post ) : '' )['img'];

$tl_cms   = ! empty( $tl_p['cms'] ) && $tl_post ? trim( (string) $tl_post->post_content ) : '';
$tl_testo = ! empty( $tl_p['testo'] ) ? $tl_p['testo'] : array();
$tl_foto  = ! empty( $tl_p['img'] ) ? tenconi_int_conta( $tl_p['img'] ) : 0;
$tl_ritr  = in_array( $tl_slug, array( 'direzione', 'team' ), true );

/* Indice: solo le sezioni che ci sono davvero. */
$tl_indice = array();
if ( '' !== $tl_cms || $tl_testo ) {
	$tl_indice[] = array( 'tl-sez-testo', tenconi_int_t( 'Presentazione', 'tenconi:interne:sez-testo' ), '' );
}
if ( $tl_foto ) {
	$tl_indice[] = array(
		'tl-sez-foto',
		! empty( $tl_p['galleria'] ) ? rtrim( $tl_p['galleria'], '. ' ) : tenconi_int_t( 'Fotografie', 'tenconi:interne:sez-foto' ),
		$tl_foto,
	);
}
if ( ! empty( $tl_p['sedi'] ) && tenconi_home_img_ok( $tl_p['sedi']['att'] ) ) {
	$tl_indice[] = array( 'tl-sez-sedi', $tl_p['sedi']['titolo'], '' );
}
?>
<main id="main" class="tl-main tl-int" tabindex="-1">
	<?php
	tenconi_int_testa(
		array(
			'gruppo' => $tl_voce['gruppo'],
			'titolo' => $tl_titolo,
			'intro'  => $tl_intro,
			'hero'   => $tl_hero,
			'indice' => $tl_indice,
		)
	);
	$tl_sn = 0;
	?>

	<?php if ( '' !== $tl_cms || $tl_testo ) : ?>
		<section class="tl-int__sez tl-int__sez--testo" id="tl-sez-testo">
			<?php if ( count( $tl_indice ) > 1 ) : ?>
				<div class="tl-wrap"><?php tenconi_int_sez_testa( 'tl-sez-testo', ++$tl_sn, $tl_indice[0][1] ); ?></div>
			<?php endif; ?>
			<div class="tl-wrap tl-int__testo">
				<div class="tl-int__corpo">
					<?php
					if ( '' !== $tl_cms ) {
						echo wp_kses_post( apply_filters( 'the_content', $tl_post->post_content ) );
					}
					foreach ( $tl_testo as $tl_b ) {
						list( $tl_tag, $tl_t ) = $tl_b;
						if ( 'h2' === $tl_tag || 'h3' === $tl_tag ) {
							printf( '<h2>%s</h2>', nl2br( esc_html( $tl_t ) ) );
						} elseif ( 'li' === $tl_tag ) {
							printf( '<p class="tl-int__li">%s</p>', esc_html( $tl_t ) );
						} else {
							printf( '<p>%s</p>', esc_html( $tl_t ) );
						}
					}
					?>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( $tl_foto && ! empty( $tl_p['galleria'] ) ) : ?>
		<?php /* L'archivio fotografico resta un carosello: e' una storia da sfogliare, non un catalogo. */ ?>
		<section class="tl-int__sez" id="tl-sez-foto">
			<div class="tl-wrap">
				<?php tenconi_int_sez_testa( 'tl-sez-foto', ++$tl_sn, rtrim( $tl_p['galleria'], '. ' ) ); ?>
			</div>
			<div class="tl-int__carosello">
				<?php
				$tl_gal_titolo = '';
				$tl_gal_img    = $tl_p['img'];
				require TENCONI_DIR . '/template-parts/pagine/galleria.php';
				?>
			</div>
		</section>
	<?php elseif ( $tl_foto ) : ?>
		<?php
		tenconi_int_galleria(
			array(
				'id'       => 'tl-sez-foto',
				'num'      => count( $tl_indice ) > 1 ? ++$tl_sn : 0,
				'titolo'   => count( $tl_indice ) > 1 ? tenconi_int_t( 'Fotografie', 'tenconi:interne:sez-foto' ) : '',
				'img'      => $tl_p['img'],
				'alt'      => $tl_titolo,
				'formato'  => $tl_ritr ? 'ritratto' : 'paesaggio',
				'visibili' => $tl_ritr ? 0 : 9,
			)
		);
		?>
	<?php endif; ?>

	<?php if ( ! empty( $tl_p['sedi'] ) && tenconi_home_img_ok( $tl_p['sedi']['att'] ) ) : ?>
		<section class="tl-int__sez" id="tl-sez-sedi" aria-labelledby="tl-sez-sedi-t">
			<div class="tl-wrap">
				<?php tenconi_int_sez_testa( 'tl-sez-sedi', ++$tl_sn, $tl_p['sedi']['titolo'] ); ?>
				<figure class="tl-int__carta">
					<?php
					echo wp_get_attachment_image(
						$tl_p['sedi']['att'],
						'large',
						false,
						array(
							'alt'      => tenconi_int_t( 'Le sedi Tenconi in Svizzera: Airolo e Cadenazzo', 'tenconi:interne:sedi-alt' ),
							'loading'  => 'lazy',
							'decoding' => 'async',
							'sizes'    => '(max-width: 900px) 100vw, 820px',
						)
					);
					?>
				</figure>
			</div>
		</section>
	<?php endif; ?>

	<?php tenconi_int_cta(); ?>
</main>
