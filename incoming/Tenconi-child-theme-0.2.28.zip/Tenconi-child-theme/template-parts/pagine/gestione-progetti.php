<?php
/**
 * GESTIONE PROGETTI SPECIALI — la pagina legacy: due colonne e un pulsante.
 *
 * MISURE, dai pixel di tenconi.ch:gestione-progetti.png (2240 x 1358 CSS):
 *   H1                cassa 42,5, cima a y 280, centrato maiuscolo blu
 *   due colonne       682 ciascuna con gap 35 (682 + 35 + 683 = 1400)
 *   immagine          a sinistra, y 368..933,5 -> rapporto 1,204
 *   testo             a destra: paragrafo, riga in grassetto, elenco puntato
 *   pulsante          centrato sotto, y ~1038
 *
 * IL TITOLO E' "GESTIONE PROGETTI SPECIALI", con l'aggettivo. Nella homepage il
 * blocco si chiama solo "Gestione progetti": sono due etichette diverse nel
 * legacy e restano diverse.
 *
 * L'IMMAGINE E' L'ATTACHMENT 491. Su questa pagina e' l'asset legacy corretto,
 * mentre nel blocco della homepage il legacy usava un altro fotogramma della
 * stessa riunione. Non e' una contraddizione con l'audit di ieri: sono due pagine
 * diverse con due scelte redazionali diverse, ed e' esattamente il motivo per cui
 * un automatismo "usa l'immagine associata" sbaglia.
 *
 * IL PARAGRAFO VIENE DAL CONTENUTO PUBBLICATO, non riscritto. L'elenco viene
 * verbatim dal sorgente legacy in cache.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$tl_post = get_queried_object();
$tl_img  = 491;

$tl_voci = array(
	'Tecnologie',
	'Know-how',
	'Reverse engineering',
	'Stampa 3D',
	'Vasta rete di fornitori per gestire tutte le necessità del cliente',
	'Miglioramento continuo: voglia e curiosità di rendere i prodotti più concorrenziali',
	'Ufficio tecnico',
);

$tl_txt = $tl_post ? wp_strip_all_tags( (string) $tl_post->post_content ) : '';
$tl_txt = trim( preg_replace( '/\s+/u', ' ', html_entity_decode( $tl_txt, ENT_QUOTES, 'UTF-8' ) ) );
$tl_par = '';
if ( preg_match( '/^.*?\./u', $tl_txt, $tl_m ) && mb_strlen( $tl_m[0] ) > 40 ) {
	$tl_par = $tl_m[0];
}

$tl_contatti = tenconi_dest_url( 'page', 'contatti' );
?>
<main id="main" class="tl-main" tabindex="-1">
	<div class="tl-wrap">

		<h1 class="tl-titolo tl-titolo--pagina">Gestione progetti speciali</h1>

		<div class="tl-due tl-due--gp">
			<figure class="tl-gp__f">
				<?php
				if ( tenconi_home_img_ok( $tl_img ) ) {
					echo wp_get_attachment_image(
						$tl_img,
						'large',
						false,
						array(
							'alt'      => 'Riunione di lavoro attorno a un tavolo, con computer portatili.',
							'loading'  => 'eager',
							'decoding' => 'async',
							'sizes'    => '(max-width: 900px) 100vw, 50vw',
						)
					);
				}
				?>
			</figure>

			<div class="tl-gp__t">
				<?php if ( '' !== $tl_par ) : ?>
					<p><?php echo esc_html( $tl_par ); ?></p>
				<?php endif; ?>

				<p class="tl-gp__forte">Mettiamo a disposizione</p>

				<ul class="tl-gp__el">
					<?php foreach ( $tl_voci as $tl_v ) : ?>
						<li><?php echo esc_html( $tl_v ); ?></li>
					<?php endforeach; ?>
				</ul>
			</div>
		</div>

		<?php if ( $tl_contatti ) : ?>
			<p class="tl-gp__cta">
				<a class="tl-bottone" href="<?php echo esc_url( $tl_contatti ); ?>">Contattaci</a>
			</p>
		<?php endif; ?>
	</div>
</main>
