<?php
/**
 * GALLERIA A SCORRIMENTO delle fotografie d'archivio.
 *
 * Il legacy mostrava una fotografia alla volta, grande, con sotto la striscia
 * delle miniature e due frecce ai lati. Le storiche vanno da verticali a
 * panoramiche, quindi non si ritagliano: l'immagine sta INTERA dentro un
 * riquadro di altezza fissa. L'altezza fissa non e' un vezzo, e' quello che
 * impedisce alla pagina di saltare a ogni cambio di diapositiva.
 *
 * MIGLIORAMENTO PROGRESSIVO. Il markup nasce completo: senza JavaScript restano
 * tutte le fotografie una sotto l'altra, navigabili e leggibili. Il CSS collassa
 * la pila in una sola diapositiva soltanto quando trova la marca `data-tl-js`
 * che il JavaScript mette sul documento, quindi non esiste il momento in cui la
 * pagina e' vuota perche' lo script non e' ancora arrivato.
 *
 * Variabili attese dal chiamante:
 *   $tl_gal_titolo  string  intestazione della sezione
 *   $tl_gal_img     array   lista di array( id_allegato, didascalia )
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$tl_gal_img = array_values(
	array_filter(
		(array) $tl_gal_img,
		static function ( $tl_v ) {
			return tenconi_home_img_ok( $tl_v[0] );
		}
	)
);

if ( empty( $tl_gal_img ) ) {
	return;
}

/* Un identificativo per pagina: serve ad aria-controls, che vuole un id vero. */
$tl_gal_id = 'tl-car-' . get_the_ID();
?>
<section class="tl-car" data-tl-car>

	<?php if ( '' !== $tl_gal_titolo ) : ?>
		<?php if ( '' !== (string) $tl_gal_titolo ) : /* vuoto: il titolo lo stampa gia' la sezione che lo contiene */ ?>
			<h2 class="tl-car__t"><?php echo esc_html( $tl_gal_titolo ); ?></h2>
		<?php endif; ?>
	<?php endif; ?>

	<div class="tl-car__palco">

		<?php
		/*
		 * Le frecce nascono con hidden: senza JavaScript non farebbero niente, e
		 * un comando che non fa niente e' peggio di un comando assente. Il
		 * JavaScript le scopre appena si accende.
		 */
		?>
		<button type="button" class="tl-car__f tl-car__f--prec" data-tl-car-prec hidden
			aria-label="Fotografia precedente" aria-controls="<?php echo esc_attr( $tl_gal_id ); ?>">
			<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M15 4 7 12l8 8" fill="none" stroke="currentColor" stroke-width="1.6" /></svg>
		</button>

		<ul class="tl-car__pila" id="<?php echo esc_attr( $tl_gal_id ); ?>" data-tl-car-pila>
			<?php foreach ( $tl_gal_img as $tl_k => $tl_i ) : ?>
				<?php list( $tl_att, $tl_cap ) = $tl_i; ?>
				<li class="tl-car__d" data-tl-car-d<?php echo 0 === $tl_k ? ' data-tl-car-attiva' : ''; ?>>
					<figure class="tl-car__fig">
						<?php
						echo wp_get_attachment_image(
							$tl_att,
							'large',
							false,
							array(
								'alt' => '' !== $tl_cap ? $tl_cap : '',
								/*
								 * La PRIMA non e' lazy: e' quella che si vede subito, e
								 * rimandarla ritarderebbe l'unica immagine che conta per
								 * la resa percepita della pagina.
								 */
								'loading'  => 0 === $tl_k ? 'eager' : 'lazy',
								'decoding' => 'async',
								'sizes'    => '(max-width: 900px) 100vw, 900px',
							)
						);
						?>
						<?php if ( '' !== $tl_cap ) : ?>
							<figcaption class="tl-car__c"><?php echo esc_html( $tl_cap ); ?></figcaption>
						<?php endif; ?>
					</figure>
				</li>
			<?php endforeach; ?>
		</ul>

		<button type="button" class="tl-car__f tl-car__f--succ" data-tl-car-succ hidden
			aria-label="Fotografia successiva" aria-controls="<?php echo esc_attr( $tl_gal_id ); ?>">
			<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M9 4l8 8-8 8" fill="none" stroke="currentColor" stroke-width="1.6" /></svg>
		</button>

	</div>

	<?php
	/*
	 * LA STRISCIA e' un elenco di pulsanti, non di collegamenti: non porta da
	 * nessuna parte, cambia lo stato di questa sezione. Nasce hidden per lo
	 * stesso motivo delle frecce. `role=tablist` con aria-selected e' il modello
	 * che descrive esattamente questo: piu' schede, una sola visibile.
	 */
	?>
	<ul class="tl-car__mini" role="tablist" aria-label="Scegli la fotografia" data-tl-car-mini hidden>
		<?php foreach ( $tl_gal_img as $tl_k => $tl_i ) : ?>
			<?php
			list( $tl_att, $tl_cap ) = $tl_i;
			$tl_n = $tl_k + 1;
			?>
			<li class="tl-car__mini-v" role="presentation">
				<button type="button" class="tl-car__mini-b" role="tab" data-tl-car-va="<?php echo esc_attr( $tl_k ); ?>"
					aria-selected="<?php echo 0 === $tl_k ? 'true' : 'false'; ?>"
					aria-controls="<?php echo esc_attr( $tl_gal_id ); ?>"
					tabindex="<?php echo 0 === $tl_k ? '0' : '-1'; ?>">
					<?php
					echo wp_get_attachment_image(
						$tl_att,
						'thumbnail',
						false,
						array(
							/*
							 * La miniatura ripete la fotografia che c'e' gia' accanto:
							 * per chi ascolta conta il NUMERO, non una seconda
							 * descrizione della stessa immagine.
							 */
							'alt'      => '',
							'loading'  => 'lazy',
							'decoding' => 'async',
							'sizes'    => '150px',
						)
					);
					?>
					<span class="tl-car__mini-n"><?php echo esc_html( sprintf( 'Fotografia %d', $tl_n ) ); ?></span>
				</button>
			</li>
		<?php endforeach; ?>
	</ul>

</section>
