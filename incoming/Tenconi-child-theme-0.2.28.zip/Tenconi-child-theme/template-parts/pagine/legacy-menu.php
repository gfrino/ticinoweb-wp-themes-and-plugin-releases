<?php
/**
 * RENDERER CONDIVISO delle pagine del menu ricostruite dal legacy.
 *
 * Una sola vista per cinque pagine, perche' nel legacy erano lo stesso sistema
 * con quantita' diverse di testo e fotografie:
 *
 *   Direzione e CdA    sole fotografie, didascalia "nome, ruolo"
 *   Team               sole fotografie, didascalia "nome, ruolo"
 *   Tecnologia e servizi di supporto   due paragrafi, gruppi, fotografie
 *   150esimo           pagina editoriale lunga, testo e fotografie
 *   Condizioni di vendita             soli collegamenti a documenti
 *
 * GRIGLIA. Tre colonne da 444 con gap 34: la stessa della homepage e di Parco
 * macchine, gia' misurata sui pixel. Le fotografie sono in 4:3 come quelle di
 * Parco macchine, che e' la famiglia a cui queste pagine appartengono.
 *
 * NON SI AGGIUNGE TESTO per riempire Direzione e Team: nel legacy non c'era, e
 * le didascalie con nome e ruolo sono tutto il contenuto della pagina.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$tl_slug = get_query_var( 'tl_slug' );
$tl_map  = tenconi_legacy_menu_media();
$tl_post = get_queried_object();

/*
 * DUE MODI DI RIEMPIRE LA STESSA PAGINA, e la differenza e' il principio del
 * progetto: grafica legacy, dati WordPress.
 *
 *   con mappa    le pagine che il legacy costruiva con fotografie e didascalie
 *                (Direzione, Team, 150esimo, Supporto, Certificazioni): testo e
 *                media vengono dal sorgente legacy, perche' in WordPress non
 *                c'erano.
 *   senza mappa  le pagine il cui testo E' GIA' nel CMS, corretto e completo
 *                (Chi siamo, La nostra storia, Sostenibilita'): si rende
 *                the_content(), e il legacy da' solo la veste. Ricopiarle nella
 *                mappa sarebbe congelare in PHP contenuto che il committente
 *                deve poter modificare da WordPress.
 */
$tl_p = isset( $tl_map[ $tl_slug ] )
	? $tl_map[ $tl_slug ]
	: array(
		'titolo' => $tl_post ? get_the_title( $tl_post ) : '',
		'testo'  => array(),
		'img'    => array(),
		'cms'    => true,
	);
?>
<main id="main" class="tl-main" tabindex="-1">
	<div class="tl-wrap">

		<h1 class="tl-titolo tl-titolo--pagina"><?php echo esc_html( $tl_p['titolo'] ); ?></h1>

		<?php if ( ! empty( $tl_p['cms'] ) ) : ?>
			<div class="tl-corpo tl-corpo--cms">
				<?php
				/* Il contenuto pubblicato, con la tipografia legacy. */
				echo wp_kses_post( apply_filters( 'the_content', $tl_post ? $tl_post->post_content : '' ) );
				?>
			</div>
		<?php endif; ?>

		<?php if ( ! empty( $tl_p['testo'] ) ) : ?>
			<div class="tl-corpo">
				<?php
				foreach ( $tl_p['testo'] as $tl_b ) :
					list( $tl_tag, $tl_t ) = $tl_b;
					if ( 'h2' === $tl_tag || 'h3' === $tl_tag ) {
						printf( '<h2 class="tl-grp__t">%s</h2>', esc_html( $tl_t ) );
					} elseif ( 'li' === $tl_tag ) {
						printf( '<p class="tl-corpo__li">%s</p>', esc_html( $tl_t ) );
					} else {
						printf( '<p>%s</p>', esc_html( $tl_t ) );
					}
				endforeach;
				?>
			</div>
		<?php endif; ?>

		<?php
		/*
		 * GALLERIA O GRIGLIA. Chi siamo aveva nel legacy un carosello con la
		 * striscia di miniature, non una griglia: dieci fotografie d'archivio si
		 * guardano una alla volta e grandi. Le altre pagine restano a griglia,
		 * che e' il loro impianto originale.
		 */
		if ( ! empty( $tl_p['galleria'] ) && ! empty( $tl_p['img'] ) ) :
			$tl_gal_titolo = $tl_p['galleria'];
			$tl_gal_img    = $tl_p['img'];
			require TENCONI_DIR . '/template-parts/pagine/galleria.php';
		endif;
		?>

		<?php if ( empty( $tl_p['galleria'] ) && ! empty( $tl_p['img'] ) ) : ?>
			<?php
			/*
			 * Direzione e Team mostrano RITRATTI di proporzioni diverse fra loro: un
			 * unico 4:3 con object-fit cover tagliava le persone. Su queste due la
			 * griglia lascia a ogni fotografia il suo rapporto.
			 */
			$tl_intere = in_array( $tl_slug, array( 'direzione', 'team' ), true );
			?>
			<ul class="tl-griglia tl-grp__g<?php echo $tl_intere ? ' tl-grp__g--intere' : ''; ?>">
				<?php
				foreach ( $tl_p['img'] as $tl_i ) :
					list( $tl_att, $tl_cap ) = $tl_i;
					if ( ! tenconi_home_img_ok( $tl_att ) ) {
						continue;
					}
					?>
					<li>
						<figure class="tl-grp__f">
							<?php
							echo wp_get_attachment_image(
								$tl_att,
								'large',
								false,
								array(
									/* La didascalia legacy e' nome e ruolo: descrive davvero
									   la fotografia, quindi va bene anche come alt. */
									'alt'      => '' !== $tl_cap ? $tl_cap : $tl_p['titolo'],
									'loading'  => 'lazy',
									'decoding' => 'async',
									'sizes'    => '(max-width: 560px) 100vw, (max-width: 900px) 50vw, 33vw',
								)
							);
							?>
							<?php if ( '' !== $tl_cap ) : ?>
								<figcaption class="tl-grp__c"><?php echo esc_html( $tl_cap ); ?></figcaption>
							<?php endif; ?>
						</figure>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>

		<?php
		/*
		 * LE SEDI. La carta della Svizzera non e' una fotografia d'archivio: in
		 * mezzo alle altre diventava una piastrella piccola, senza titolo e con
		 * Airolo e Cadenazzo illeggibili. Qui e' una sezione sua, larga.
		 */
		if ( ! empty( $tl_p['sedi'] ) && tenconi_home_img_ok( $tl_p['sedi']['att'] ) ) :
			?>
			<section class="tl-sedi">
				<h2 class="tl-sedi__t"><?php echo esc_html( $tl_p['sedi']['titolo'] ); ?></h2>
				<?php
				echo wp_get_attachment_image(
					$tl_p['sedi']['att'],
					'large',
					false,
					array(
						'alt'      => 'Le sedi Tenconi in Svizzera: Airolo e Cadenazzo',
						'loading'  => 'lazy',
						'decoding' => 'async',
						'sizes'    => '(max-width: 900px) 100vw, 820px',
					)
				);
				?>
			</section>
		<?php endif; ?>
	</div>
</main>
