<?php
/**
 * ELENCHI DI DOCUMENTI — Jobs, Certificazioni, Condizioni di vendita.
 *
 * Nel legacy sono la stessa pagina tre volte: titolo, gruppi etichettati, righe
 * con il nome del documento e i collegamenti al PDF, spesso lo stesso documento
 * in piu' lingue sulla stessa riga.
 *
 * Nessuna card, nessuna CTA, nessun campo colorato: filetti sottili e testo, che
 * e' il linguaggio del resto del sito.
 *
 * I PDF vengono risolti sulla libreria media cercando il nome del file legacy.
 * Se un documento non e' stato importato, la riga resta TESTO: nessun link finto,
 * nessun 404.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$tl_slug = get_query_var( 'tl_slug' );
$tl_map  = tenconi_legacy_documenti();
if ( ! isset( $tl_map[ $tl_slug ] ) ) {
	return;
}
$tl_p = $tl_map[ $tl_slug ];

/**
 * Trova l'URL di un PDF nella libreria a partire dal nome del file legacy.
 *
 * @param string $file Nome del file legacy.
 * @return string URL, o '' se il documento non e' in libreria.
 */
function tenconi_pdf_url( $file ) {

	static $cache = array();
	$file = (string) $file;
	if ( '' === $file ) {
		return '';
	}
	if ( isset( $cache[ $file ] ) ) {
		return $cache[ $file ];
	}

	global $wpdb;
	$base = preg_replace( '/\.pdf$/i', '', $file );
	$id   = $wpdb->get_var(
		$wpdb->prepare(
			"SELECT p.ID FROM {$wpdb->posts} p
			 INNER JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = '_wp_attached_file'
			 WHERE p.post_type = 'attachment' AND p.post_mime_type = 'application/pdf'
			   AND m.meta_value LIKE %s LIMIT 1",
			'%' . $wpdb->esc_like( $base ) . '%'
		)
	);

	$cache[ $file ] = $id ? (string) wp_get_attachment_url( (int) $id ) : '';
	return $cache[ $file ];
}
?>
<main id="main" class="tl-main" tabindex="-1">
	<div class="tl-wrap">

		<h1 class="tl-titolo tl-titolo--pagina"><?php echo esc_html( $tl_p['titolo'] ); ?></h1>

		<div class="tl-doc">
			<?php
			foreach ( $tl_p['voci'] as $tl_v ) :
				list( $tl_tag, $tl_testo, $tl_link ) = $tl_v;

				if ( 'h2' === $tl_tag || 'h3' === $tl_tag ) {
					printf( '<h2 class="tl-doc__t">%s</h2>', esc_html( $tl_testo ) );
					continue;
				}

				/* Riga senza collegamenti: e' una frase introduttiva, non un documento. */
				if ( empty( $tl_link ) ) {
					printf( '<p class="tl-doc__p">%s</p>', esc_html( $tl_testo ) );
					continue;
				}
				?>
				<p class="tl-doc__r">
					<?php
					$tl_fatti = array();
					foreach ( $tl_link as $tl_l ) {
						list( $tl_et, $tl_file ) = $tl_l;
						$tl_u = tenconi_pdf_url( $tl_file );
						$tl_fatti[] = '' !== $tl_u
							? sprintf(
								'<a class="tl-link" href="%s" rel="noopener">%s</a>',
								esc_url( $tl_u ),
								esc_html( $tl_et )
							)
							: esc_html( $tl_et );
					}
					echo wp_kses_post( implode( '<span class="tl-doc__sep"> · </span>', $tl_fatti ) );
					?>
				</p>
			<?php endforeach; ?>
		</div>
	</div>
</main>
