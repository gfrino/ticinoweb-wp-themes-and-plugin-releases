<?php
/**
 * LA FAMIGLIA "AREA DI ATTIVITA'", un solo renderer per cinque pagine.
 *
 * Le cinque pagine area del legacy non sono cinque layout: sono lo stesso
 * sistema cinque volte. Verificato su tutti e cinque gli screenshot e su tutti e
 * cinque i sorgenti in cache. Quindi un template, non cinque.
 *
 * STRUTTURA, misurata sui pixel di
 * _project-context/03-old-site-screenshots/tenconi.ch:ferroviario-rotabile.png:
 *
 *   H1 centrato, maiuscolo, blu, altezza di cassa 42,5 a y 279,5
 *   riga "PRODOTTI: <elenco>" centrata, cassa 14,5 a y 445
 *   galleria: 4 colonne da 334,5 con gap 20,5 (4*334,5 + 3*20,5 = 1400)
 *   immagini QUADRATE: 334,5 x 335, rapporto 0,999
 *   didascalia centrata sotto ogni immagine
 *   riga "LAVORAZIONE: <elenco>" e seconda galleria, identica
 *   filetto, footer
 *
 * NON C'E' UN ARCHIVIO. Nel legacy queste pagine non elencavano altri contenuti:
 * mostravano due gallerie di fotografie con didascalia. Il template quindi non
 * interroga il database per costruire elenchi: legge la mappa legacy. E' la
 * ragione per cui il cancello di pubblicazione, che le dichiarava vuote perche'
 * nessun record era assegnato al termine, andava corretto e non aggirato.
 *
 * Variabili attese: $tl_slug (la chiave nella mappa legacy).
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$tl_mappa = tenconi_legacy_aree_media();
$tl_slug  = isset( $tl_slug ) ? $tl_slug : '';

if ( ! isset( $tl_mappa[ $tl_slug ] ) ) {
	return;
}
$tl_p = $tl_mappa[ $tl_slug ];
?>
<main id="main" class="tl-main" tabindex="-1">
	<div class="tl-wrap">

		<h1 class="tl-titolo tl-titolo--area"><?php echo esc_html( $tl_p['h1'] ); ?></h1>

		<?php
		foreach ( array( 'g1', 'g2' ) as $tl_g ) :
			$tl_b = $tl_p[ $tl_g ];
			if ( empty( $tl_b['img'] ) ) {
				continue;
			}

			/*
			 * NEL LEGACY SOLO LA PRIMA GALLERIA HA DIDASCALIE. Nella seconda
			 * Squarespace aveva riempito l'attributo alt col nome del file, e
			 * stamparlo avrebbe messo "_SAB0399.jpg" sotto una fotografia. La mappa
			 * scarta gli alt che sono nomi di file, quindi qui basta contarli: se
			 * nessuno ne ha, la griglia stringe lo stacco fra le righe, perche' non
			 * deve lasciare posto a una riga di testo che non c'e'.
			 */
			$tl_ndid = 0;
			foreach ( $tl_b['img'] as $tl_x ) {
				if ( '' !== $tl_x[1] ) {
					++$tl_ndid;
				}
			}
			$tl_cls = $tl_ndid ? 'tl-gal__g' : 'tl-gal__g tl-gal__g--nudo';
			?>
			<section class="tl-gal" aria-labelledby="tl-<?php echo esc_attr( $tl_slug . '-' . $tl_g ); ?>">

				<?php /* "PRODOTTI:" in grassetto, l'elenco in tondo: e' cosi' nel legacy. */ ?>
				<h2 class="tl-gal__t" id="tl-<?php echo esc_attr( $tl_slug . '-' . $tl_g ); ?>">
					<span class="tl-gal__et"><?php echo esc_html( $tl_b['etichetta'] ); ?>:</span>
					<span class="tl-gal__el"><?php echo esc_html( $tl_b['elenco'] ); ?></span>
				</h2>

				<ul class="<?php echo esc_attr( $tl_cls ); ?>">
					<?php
					foreach ( $tl_b['img'] as $tl_i ) :
						list( $tl_att, $tl_cap ) = $tl_i;
						if ( ! tenconi_home_img_ok( $tl_att ) ) {
							continue;
						}

						/*
						 * Senza didascalia serve comunque un alt, e non lo si inventa
						 * descrivendo la fotografia: si dichiara il CONTESTO, che e'
						 * vero e verificabile — la pagina e la galleria a cui appartiene.
						 */
						$tl_alt = '' !== $tl_cap
							? $tl_cap
							: $tl_p['h1'] . ' — ' . mb_strtolower( $tl_b['etichetta'] );
						?>
						<li class="tl-gal__i">
							<figure class="tl-gal__f">
								<?php
								/*
								 * Le immagini sono quadrate nel legacy mentre gli originali no:
								 * il ritaglio e' quindi inevitabile e va al centro, come faceva
								 * Squarespace. La dimensione richiesta e' quella piena perche'
								 * a 4 colonne su 2240 servono 669 px reali per lato.
								 */
								echo wp_get_attachment_image(
									$tl_att,
									'large',
									false,
									array(
										'alt'      => $tl_alt,
										'loading'  => 'lazy',
										'decoding' => 'async',
										'sizes'    => '(max-width: 600px) 100vw, (max-width: 1023px) 50vw, 25vw',
									)
								);
								?>
								<?php if ( '' !== $tl_cap ) : ?>
									<figcaption class="tl-gal__c"><?php echo esc_html( $tl_cap ); ?></figcaption>
								<?php endif; ?>
							</figure>
						</li>
					<?php endforeach; ?>
				</ul>
			</section>
		<?php endforeach; ?>
	</div>
</main>
