<?php
/**
 * Helper di rendering dei componenti riutilizzabili.
 *
 * DEVIAZIONE PRAGMATICA dal piano: il lotto 1 implementa solo i cinque helper
 * effettivamente usati nel primo viewport. tenconi_kpi() e tenconi_plate()
 * nasceranno nel lotto 2, quando serviranno alle sezioni 5-9.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Targhetta di riferimento: l'unita atomica del dossier.
 *
 * Con $mark['stamp'] = true riceve il timbro di conformita (lime). Il timbro
 * porta SEMPRE anche testo: nessuna informazione e affidata al solo colore.
 * Il lime e ammesso solo su campo navy o graphite: il CSS lo garantisce.
 *
 * @param array $mark ['label' => string, 'value' => string, 'stamp' => bool].
 * @return void
 */
function tenconi_ref_mark( array $mark ) {
	$label = isset( $mark['label'] ) ? $mark['label'] : '';
	$value = isset( $mark['value'] ) ? $mark['value'] : '';
	$stamp = ! empty( $mark['stamp'] );
	$class = 'tc-ref-mark' . ( $stamp ? ' tc-ref-mark--stamp' : '' );
	?>
	<span class="<?php echo esc_attr( $class ); ?>">
		<?php if ( '' !== $label ) : ?>
			<span class="tc-ref-mark__label"><?php echo esc_html( $label ); ?></span>
		<?php endif; ?>
		<span class="tc-ref-mark__value"><?php echo esc_html( $value ); ?></span>
		<?php if ( $stamp ) : ?>
			<span class="tc-ref-mark__stamp-text">conforme</span>
		<?php endif; ?>
	</span>
	<?php
}

/**
 * Colonna di riferimento di una sezione.
 *
 * The Reference Column Rule: una colonna vuota e un difetto di contenuto.
 * Se $marks e vuoto la funzione non stampa nulla e registra un avviso in debug.
 *
 * @param array  $marks      Elenco di targhette.
 * @param string $section_no Numero di sezione del dossier, es. '02'.
 * @return void
 */
function tenconi_ref_column( array $marks, $section_no = '' ) {
	if ( empty( $marks ) ) {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			error_log( 'Tenconi: colonna di riferimento vuota, sezione ' . $section_no );
		}
		return;
	}
	?>
	<div class="tc-refcol">
		<?php if ( '' !== $section_no ) : ?>
			<p class="tc-refcol__no" aria-hidden="true"><?php echo esc_html( $section_no ); ?></p>
		<?php endif; ?>
		<ul class="tc-refcol__list">
			<?php foreach ( $marks as $mark ) : ?>
				<li class="tc-refcol__item"><?php tenconi_ref_mark( $mark ); ?></li>
			<?php endforeach; ?>
		</ul>
	</div>
	<?php
}

/**
 * CTA primaria. Una sola per viewport, piena. Non usa mai il lime.
 *
 * @param string $label Etichetta.
 * @param string $url   Destinazione.
 * @return void
 */
function tenconi_cta_primary( $label, $url ) {
	?>
	<a class="tc-cta tc-cta--primary" href="<?php echo esc_url( $url ); ?>">
		<?php echo esc_html( $label ); ?>
	</a>
	<?php
}

/**
 * CTA secondaria: solo filetto, nessun riempimento.
 *
 * @param string $label Etichetta.
 * @param string $url   Destinazione.
 * @return void
 */
function tenconi_cta_secondary( $label, $url ) {
	?>
	<a class="tc-cta tc-cta--secondary" href="<?php echo esc_url( $url ); ?>">
		<?php echo esc_html( $label ); ?>
	</a>
	<?php
}

/**
 * Badge di placeholder, visibile. Mai testo tecnico verosimile al suo posto.
 *
 * @param string $what Cosa manca.
 * @return void
 */
function tenconi_placeholder( $what ) {
	?>
	<span class="tc-placeholder" role="note">
		<span class="tc-placeholder__tag">Placeholder</span>
		<span class="tc-placeholder__what"><?php echo esc_html( $what ); ?></span>
	</span>
	<?php
}

/* ==========================================================================
   Content Foundation: helper dei template generici. PROVVISORI.
   ========================================================================== */

/**
 * Elenco di ID da un meta o da un'opzione a valori separati da virgola.
 *
 * @param string $valore Valore grezzo.
 * @return array
 */
function tenconi_ids_from( $valore ) {
	$valore = trim( (string) $valore );
	if ( '' === $valore ) {
		return array();
	}
	return array_values( array_filter( array_map( 'absint', explode( ',', $valore ) ) ) );
}

/**
 * True se l'immagine e' bloccata in attesa di verifica dei diritti.
 *
 * Le nove immagini con copyright o credit EXIF non si mostrano nel frontend
 * finche' la titolarita' non e' confermata. Il filtro sta QUI, non solo nel dato:
 * anche se un ID finisse per errore in una lista pubblica, non verrebbe stampato.
 *
 * @param int $id Attachment ID.
 * @return bool
 */
function tenconi_media_rights_hold( $id ) {
	return 'review_required' === get_post_meta( (int) $id, '_tcm_rights_state', true );
}

/**
 * Griglia della galleria, dai media associati in CF-4.
 *
 * Sorgente: `_tcm_gallery_ids`, che CF-4 riempie nell'ordine della pagina legacy.
 * Le immagini con diritti da verificare sono gia' escluse dal dato e vengono
 * ricontrollate qui.
 *
 * @param int|null $post_id Post ID.
 * @return void
 */
function tenconi_gallery_grid( $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$ids     = tenconi_ids_from( get_post_meta( $post_id, '_tcm_gallery_ids', true ) );
	tenconi_gallery_from_ids( $ids );
}

/**
 * Griglia della galleria da un elenco di ID. Usata anche da archivi e settori,
 * dove la sorgente e' un'opzione o un meta di termine invece di un meta di post.
 *
 * @param array $ids Attachment ID.
 * @return void
 */
function tenconi_gallery_from_ids( array $ids ) {
	$ids = array_values( array_filter( $ids, function ( $id ) {
		return ! tenconi_media_rights_hold( $id );
	} ) );
	if ( ! $ids ) {
		return;
	}
	echo '<ul class="tc-gallery" aria-label="Galleria immagini">';
	foreach ( $ids as $id ) {
		$img = wp_get_attachment_image( $id, 'tenconi_plate_sm', false, array( 'loading' => 'lazy' ) );
		if ( ! $img ) {
			continue;
		}
		echo '<li class="tc-gallery__item">' . $img . '</li>';
	}
	echo '</ul>';
}

/**
 * Nota amministrativa sui media trattenuti per diritti.
 *
 * Visibile SOLO a chi puo' modificare i contenuti: al pubblico non si dichiara
 * nulla, e le immagini restano invisibili in ogni caso.
 *
 * @param int|null $post_id Post ID.
 * @return void
 */
function tenconi_rights_note( $post_id = null ) {
	if ( ! current_user_can( 'edit_posts' ) ) {
		return;
	}
	$post_id = $post_id ? $post_id : get_the_ID();
	$ids     = tenconi_ids_from( get_post_meta( $post_id, '_tcm_rights_hold_ids', true ) );
	if ( ! $ids ) {
		return;
	}
	$autori = array();
	foreach ( $ids as $id ) {
		$a = get_post_meta( $id, '_tcm_exif_credit', true );
		if ( ! $a ) {
			$a = get_post_meta( $id, '_tcm_exif_copyright', true );
		}
		if ( $a ) {
			$autori[ $a ] = true;
		}
	}
	printf(
		'<p class="tc-admin-note"><span class="tc-admin-note__tag">Diritti da verificare</span> %d %s con attribuzione fotografica%s: non pubblicate finche i diritti non sono confermati.</p>',
		count( $ids ),
		1 === count( $ids ) ? 'immagine' : 'immagini',
		$autori ? ' (' . esc_html( implode( ', ', array_keys( $autori ) ) ) . ')' : ''
	);
}

/**
 * True se un PDF si puo' esporre pubblicamente.
 *
 * Nessuno stato lo consente oggi: `da verificare` e `sconosciuto` sono i soli
 * stati presenti, e presentare come valido un certificato la cui validita' non e'
 * confermata sarebbe un'affermazione falsa. La regola sta nel dato
 * (_tcm_document_public, scritto da CF-4) e si ricontrolla qui.
 *
 * @param int $id Attachment ID.
 * @return bool
 */
function tenconi_document_is_public( $id ) {
	return '1' === (string) get_post_meta( (int) $id, '_tcm_document_public', true );
}

/**
 * Elenco dei documenti associati.
 *
 * Sorgente: `_tcm_document_ids`, che CF-4 riempie con i PDF che il sito legacy
 * collegava a quel contenuto. I documenti non pubblicabili si mostrano ai soli
 * amministratori, con lo stato dichiarato accanto al nome.
 *
 * @param int|null $post_id Post ID.
 * @return void
 */
function tenconi_documents_list( $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$ids     = tenconi_ids_from( get_post_meta( $post_id, '_tcm_document_ids', true ) );
	// Compatibilita' col segnaposto di CF-2, se qualche contenuto lo porta ancora.
	$file = (int) get_post_meta( $post_id, '_tcm_file', true );
	if ( $file && ! in_array( $file, $ids, true ) ) {
		$ids[] = $file;
	}
	tenconi_documents_from_ids( $ids );
}

/**
 * Elenco documenti da un elenco di ID. Usata anche dagli archivi.
 *
 * @param array $ids Attachment ID.
 * @return void
 */
function tenconi_documents_from_ids( array $ids ) {
	if ( ! $ids ) {
		return;
	}
	$admin     = current_user_can( 'edit_posts' );
	$pubblici  = array();
	$riservati = array();
	foreach ( $ids as $id ) {
		if ( ! wp_get_attachment_url( $id ) ) {
			continue;
		}
		if ( tenconi_document_is_public( $id ) ) {
			$pubblici[] = $id;
		} else {
			$riservati[] = $id;
		}
	}
	$mostrati = $admin ? array_merge( $pubblici, $riservati ) : $pubblici;
	if ( ! $mostrati ) {
		return;
	}

	echo '<ul class="tc-docs" aria-label="Documenti">';
	foreach ( $mostrati as $id ) {
		$url  = wp_get_attachment_url( $id );
		$path = get_attached_file( $id );
		$size = ( $path && file_exists( $path ) ) ? size_format( (int) filesize( $path ) ) : '';
		$stato = (string) get_post_meta( $id, '_tcm_document_status', true );
		$lang  = strtoupper( (string) get_post_meta( $id, '_tcm_document_language', true ) );
		$pub   = tenconi_document_is_public( $id );
		printf(
			'<li class="tc-docs__item"><a class="tc-docs__link" href="%s" download><span class="tc-docs__name">%s</span> <span class="tc-tech tc-docs__meta">PDF%s%s%s</span></a></li>',
			esc_url( $url ),
			esc_html( get_the_title( $id ) ),
			$size ? ' ' . esc_html( $size ) : '',
			$lang ? ' · ' . esc_html( $lang ) : '',
			$pub ? '' : ' · ' . esc_html( $stato ? $stato : 'da verificare' )
		);
	}
	echo '</ul>';

	if ( $admin && $riservati ) {
		printf(
			'<p class="tc-admin-note"><span class="tc-admin-note__tag">Documenti da verificare</span> %d %s non %s pubblicamente: la validita non e confermata e un certificato non confermato non va presentato come valido. %s</p>',
			count( $riservati ),
			1 === count( $riservati ) ? 'documento' : 'documenti',
			1 === count( $riservati ) ? 'esposto' : 'esposti',
			esc_html( (string) get_post_meta( $riservati[0], '_tcm_document_public_reason', true ) )
		);
	}
}

/**
 * Banda con la CTA provvisoria verso la richiesta di offerta.
 *
 * L'URL si risolve contro la pagina Contatti reale, non e' scritto a mano.
 *
 * @return void
 */
function tenconi_cta_band() {
	$url = function_exists( 'tenconi_cta_url' ) ? tenconi_cta_url() : home_url( '/' );
	?>
	<section class="tc-section tc-section--tight tc-field--navy tc-ctaband" aria-labelledby="tc-ctaband-title">
		<div class="tc-container">
			<div class="tc-section__grid">
				<div class="tc-refcol"></div>
				<div class="tc-content tc-density--editorial">
					<h2 class="tc-h3" id="tc-ctaband-title">Serve un'offerta su disegno?</h2>
					<p class="tc-prose">Inviaci il disegno o la specifica: rispondiamo con una valutazione tecnica.</p>
					<p class="tc-cta-row">
						<?php tenconi_cta_primary( 'Richiedi un\'offerta tecnica', $url ); ?>
					</p>
				</div>
			</div>
		</div>
	</section>
	<?php
}

/**
 * Etichetta del tipo di contenuto, per l'intestazione dei template.
 *
 * @param int|null $post_id Post ID.
 * @return string
 */
function tenconi_type_label( $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$obj     = get_post_type_object( get_post_type( $post_id ) );
	if ( ! $obj ) {
		return '';
	}
	return (string) $obj->labels->singular_name;
}
