<?php
/**
 * Setup del tema ed enqueue degli asset.
 *
 * DEVIAZIONE PRAGMATICA dal piano: il piano prevedeva inc/setup.php e
 * inc/assets.php separati. Per il lotto 1 sono un unico file: entrambi
 * agiscono sul ciclo di bootstrap del tema e insieme restano sotto le 150
 * righe, quindi la separazione non offriva un beneficio reale.
 *
 * Il parent dichiara gia title-tag, post-thumbnails e il supporto html5:
 * non vanno ridichiarati.
 *
 * IMPORTANTE sull'enqueue. Il parent accoda gia:
 *   wp_enqueue_style( 'ticinoweb-ai-style', get_stylesheet_uri(), array('poppins-font'), TICINOWEB_THEME_VERSION );
 * Con un tema figlio attivo, get_stylesheet_uri() risolve allo style.css DI
 * QUESTO TEMA. Quel foglio e quindi gia caricato, con handle e versione del
 * parent (verificato: ?ver=3.1.9). NON va ri-accodato: sarebbe caricato due
 * volte. I fogli del child hanno handle e versione propri, e il cache busting
 * dipende da filemtime invece che dai bump del parent.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registra le posizioni di menu del child.
 *
 * register_nav_menus() e additivo: non rimuove la posizione 'primary'
 * dichiarata dal parent.
 *
 * @return void
 */
function tenconi_setup() {

	register_nav_menus(
		array(
			'tenconi_primary' => __( 'Menu principale Tenconi', 'tenconi-child-theme' ),
			'tenconi_utility' => __( 'Utility bar', 'tenconi-child-theme' ),
			'tenconi_footer'  => __( 'Footer', 'tenconi-child-theme' ),
			'tenconi_legal'   => __( 'Footer legale', 'tenconi-child-theme' ),
		)
	);

	/*
	 * Tavola documentale: larghezza massima utile dato il tetto di 2500 px
	 * dell'archivio. Non ritagliata, per preservare le proporzioni originali.
	 */
	add_image_size( 'tenconi_plate', 1200, 0, false );
	add_image_size( 'tenconi_plate_sm', 720, 0, false );
}
add_action( 'after_setup_theme', 'tenconi_setup' );

/**
 * Versione di un asset, basata su filemtime.
 *
 * Rende il cache busting del child indipendente da TICINOWEB_THEME_VERSION.
 *
 * @param string $relative_path Percorso relativo alla root del tema figlio.
 * @return string Versione utilizzabile in wp_enqueue_*.
 */
function tenconi_asset_version( $relative_path ) {
	$file = TENCONI_DIR . '/' . ltrim( $relative_path, '/' );
	if ( file_exists( $file ) ) {
		return (string) filemtime( $file );
	}
	return TENCONI_VERSION;
}

/**
 * URI di un asset del child.
 *
 * @param string $relative_path Percorso relativo alla root del tema figlio.
 * @return string URI assoluto.
 */
function tenconi_asset_uri( $relative_path ) {
	return TENCONI_URI . '/' . ltrim( $relative_path, '/' );
}

/**
 * Accoda i fogli di stile e gli script del child.
 *
 * Priorita 20: dopo l'enqueue del parent (10), cosi la dipendenza dichiarata su
 * 'ticinoweb-ai-style' e sempre risolvibile e l'ordine di cascata e
 * deterministico.
 *
 * DEVIAZIONE PRAGMATICA: il lotto 1 usa tre soli fogli invece degli otto del
 * piano. base.css raccoglie token, reset, tipografia, layout e i componenti
 * effettivamente usati nel primo viewport; header.css la navigazione;
 * home.css la homepage. I fogli per le sezioni 2-9 nasceranno nel lotto 2.
 *
 * @return void
 */
function tenconi_enqueue_assets() {

	/*
	 * LEGACY-MODERNIZED. legacy.css e' il foglio del nuovo sistema: token, header,
	 * navigazione, homepage, footer. Usa il prefisso tl- e non tocca nessuna classe
	 * tc-, quindi i due livelli non si combattono nella cascata.
	 *
	 * base.css e header.css e home.css appartengono al livello dossier. header.css e
	 * home.css NON vengono piu' accodati: nessun markup usa piu' quelle classi.
	 * base.css resta, ma soltanto dove serve ancora - le pagine interne, che sono
	 * ancora tc- e vanno rifatte in un lotto successivo - e viene accodato PRIMA di
	 * legacy.css, cosi l'header e il footer nuovi vincono comunque.
	 */
	if ( ! is_front_page() ) {
		wp_enqueue_style(
			'tenconi-base',
			tenconi_asset_uri( 'assets/css/base.css' ),
			array( 'ticinoweb-ai-style' ),
			tenconi_asset_version( 'assets/css/base.css' )
		);
		wp_enqueue_style(
			'tenconi-content',
			tenconi_asset_uri( 'assets/css/content.css' ),
			array( 'tenconi-base' ),
			tenconi_asset_version( 'assets/css/content.css' )
		);
	}

	wp_enqueue_style(
		'tenconi-legacy',
		tenconi_asset_uri( 'assets/css/legacy.css' ),
		array( 'ticinoweb-ai-style' ),
		tenconi_asset_version( 'assets/css/legacy.css' )
	);

	/*
	 * PAGINE INTERNE, nuovo sistema: foglio e script solo dove il modello e'
	 * attivo (tenconi_interne_attive()).
	 */
	if ( tenconi_interne_attive() ) {
		wp_enqueue_style(
			'tenconi-interne',
			tenconi_asset_uri( 'assets/css/interne.css' ),
			array( 'tenconi-legacy' ),
			tenconi_asset_version( 'assets/css/interne.css' )
		);
		wp_enqueue_script(
			'tenconi-interne',
			tenconi_asset_uri( 'assets/js/interne.js' ),
			array(),
			tenconi_asset_version( 'assets/js/interne.js' ),
			true
		);
	}

	// Mega menu: progressive enhancement. La navigazione funziona senza.
	wp_enqueue_script(
		'tenconi-nav',
		tenconi_asset_uri( 'assets/js/nav.js' ),
		array(),
		tenconi_asset_version( 'assets/js/nav.js' ),
		true
	);
	/*
	 * DUE STRINGHE CHE IL JS SCRIVE DA SOLO, e che per questo il filtro di
	 * traduzione non vedrebbe mai: "Apri il menu"/"Chiudi il menu" cambiano
	 * sull'aria-label del pulsante quando si apre e si chiude il pannello
	 * mobile, un evento che avviene TUTTO nel browser, senza mai tornare al
	 * server. Un testo che nasce in JavaScript non passa mai da PHP, quindi
	 * non passa mai da ticinoweb_frontend_text() — a meno di non tradurlo
	 * PRIMA, qui, e consegnarlo gia' pronto.
	 */
	wp_localize_script(
		'tenconi-nav',
		'tlNavI18n',
		array(
			'apriMenu'   => function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( 'Apri il menu', 'tenconi:ui:burger-apri-aria' ) : 'Apri il menu',
			'chiudiMenu' => function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( 'Chiudi il menu', 'tenconi:ui:burger-chiudi-aria' ) : 'Chiudi il menu',
		)
	);

	/*
	 * Ricerca dal vivo: su tutte le pagine, perche' il campo sta nell'header. Il
	 * movimento e' tutto nel CSS, quindi questo file porta solo il comportamento —
	 * fuoco, attesa, chiamata, tastiera — e la pagina resta intera senza di lui.
	 */
	wp_enqueue_script(
		'tenconi-cerca',
		tenconi_asset_uri( 'assets/js/cerca.js' ),
		array(),
		tenconi_asset_version( 'assets/js/cerca.js' ),
		true
	);
	/*
	 * L'ANNUNCIO DEI RISULTATI ("3 risultati", "Nessun risultato") lo compone
	 * cerca.js da solo, a ogni lettera digitata: non puo' tornare al server per
	 * ogni annuncio senza reintrodurre il ritardo che l'attesa doveva evitare.
	 * Le TRE forme fisse (nessuno, singolare, plurale) arrivano gia' tradotte;
	 * il numero che le precede resta un numero, non serve tradurlo.
	 */
	wp_localize_script(
		'tenconi-cerca',
		'tlCercaI18n',
		array(
			'nessunRisultato' => function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( 'Nessun risultato', 'tenconi:ui:cerca-vuoto' ) : 'Nessun risultato',
			'risultato'       => function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( 'risultato', 'tenconi:ui:cerca-conteggio-singolare' ) : 'risultato',
			'risultati'       => function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( 'risultati', 'tenconi:ui:cerca-conteggio-plurale' ) : 'risultati',
		)
	);

	/*
	 * IL MARCHIO DEL FOOTER: LO SHADER E' FERMO, e vale scrivere perche'.
	 *
	 * Era il gemSmoke di Paper Shaders — il motore vero del Liquid Text di
	 * 21st.dev, non un'imitazione — e funzionava. E' stato spento su richiesta,
	 * dopo aver chiesto "meno bordo sulle lettere e piu' grande la luce che si
	 * muove": due cose che quello shader non puo' dare insieme.
	 *
	 * MISURATO DA TRE DIREZIONI, non supposto. In gemSmoke la luce che si muove E'
	 * il riflesso sul bordo del corpo vetroso: azzerando la rifrazione il
	 * movimento crolla da 55 a 1, azzerando il glow da 54 a 1, allargando il campo
	 * da 53 a 2. E la luce resta sempre una macchia localizzata, mai una fascia.
	 *
	 * Il marchio usa quindi lo strato in CSS: maschera piu' gradiente, che non ha
	 * bordi da rifrangere e puo' avere la fascia larga quanto si vuole. Costa zero
	 * kB e funziona anche senza WebGL.
	 *
	 * PER TORNARE INDIETRO bastano queste due accodate: assets/js/marchio.js e
	 * assets/vendor/paper-gemsmoke.min.js sono ancora al loro posto, con la
	 * licenza Apache-2.0 accanto.
	 *
	 * wp_enqueue_script( 'paper-gemsmoke', tenconi_asset_uri( 'assets/vendor/paper-gemsmoke.min.js' ), array(), '0.0.80', true );
	 * wp_enqueue_script( 'tenconi-marchio', tenconi_asset_uri( 'assets/js/marchio.js' ), array( 'paper-gemsmoke' ), tenconi_asset_version( 'assets/js/marchio.js' ), true );
	 */

	/*
	 * Hero: solo in home, dove esiste. Porta lo stato dell'header allo scroll e
	 * il caricamento differito del filmato di fondo.
	 */
	if ( is_front_page() ) {

		/*
		 * GSAP, ScrollTrigger, ScrollSmoother. L'ORDINE CONTA: ScrollSmoother
		 * dipende da ScrollTrigger, che dipende da gsap. Le dipendenze sono
		 * dichiarate, cosi' e' WordPress a garantire l'ordine e non la fortuna.
		 *
		 * In coda e non in testa: niente qui serve prima del primo disegno. La
		 * decisione sull'intro la prende uno script inline in <head>, che e'
		 * l'unica cosa che deve arrivare prima.
		 */
		wp_enqueue_script( 'gsap', tenconi_asset_uri( 'assets/vendor/gsap.min.js' ), array(), '3.15.0', true );
		wp_enqueue_script( 'gsap-scrolltrigger', tenconi_asset_uri( 'assets/vendor/ScrollTrigger.min.js' ), array( 'gsap' ), '3.15.0', true );
		wp_enqueue_script( 'gsap-scrollsmoother', tenconi_asset_uri( 'assets/vendor/ScrollSmoother.min.js' ), array( 'gsap-scrolltrigger' ), '3.15.0', true );

		wp_enqueue_script(
			'tenconi-anima',
			tenconi_asset_uri( 'assets/js/anima.js' ),
			array( 'gsap-scrollsmoother' ),
			tenconi_asset_version( 'assets/js/anima.js' ),
			true
		);

		wp_enqueue_script(
			'tenconi-hero',
			tenconi_asset_uri( 'assets/js/hero.js' ),
			array(),
			tenconi_asset_version( 'assets/js/hero.js' ),
			true
		);
	}

	/*
	 * Galleria: solo dove c'e' davvero. La chiave `galleria` nella mappa dei
	 * media e' l'unica fonte di verita', cosi accendere il carosello su un'altra
	 * pagina resta una riga sola e lo script non viaggia dove non serve.
	 */
	if ( is_page() ) {
		$tl_o    = get_queried_object();
		$tl_mm   = tenconi_legacy_menu_media();
		$tl_slug = ( $tl_o && isset( $tl_o->post_name ) ) ? $tl_o->post_name : '';

		if ( '' !== $tl_slug && ! empty( $tl_mm[ $tl_slug ]['galleria'] ) ) {
			wp_enqueue_script(
				'tenconi-galleria',
				tenconi_asset_uri( 'assets/js/galleria.js' ),
				array(),
				tenconi_asset_version( 'assets/js/galleria.js' ),
				true
			);
		}
	}
}
add_action( 'wp_enqueue_scripts', 'tenconi_enqueue_assets', 20 );

/**
 * La pagina corrente usa il nuovo sistema delle pagine interne?
 *
 * Le cinque aree di attivita' (tre settori e due lavorazioni) qui sotto; le
 * pagine del menu, i documenti e il parco macchine dal loro modello.
 *
 * @return bool
 */
function tenconi_interne_attive() {
	/* Le pagine del menu, i documenti e il parco macchine lo dichiarano nel loro modello. */
	if ( ! empty( $GLOBALS['tenconi_interne'] ) ) {
		return true;
	}
	if ( is_tax( 'market' ) ) {
		$t = get_queried_object();
		return $t && '' !== tenconi_legacy_area_chiave( $t->slug );
	}
	if ( is_singular( 'capability' ) ) {
		return '' !== tenconi_legacy_area_chiave( (string) get_post_field( 'post_name', get_queried_object_id() ) );
	}
	return false;
}
