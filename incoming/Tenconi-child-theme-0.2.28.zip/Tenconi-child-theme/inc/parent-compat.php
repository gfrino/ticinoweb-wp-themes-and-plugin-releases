<?php
/**
 * Compatibilita con il parent theme ticinoweb-ai-theme.
 *
 * Il parent e READ-ONLY in modo assoluto. Tutto cio che va neutralizzato,
 * va neutralizzato da qui.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Rimuove gli hook del parent che confliggono con il child.
 *
 * TIMING CRITICO. WordPress carica functions.php del CHILD prima di quello del
 * PARENT. Un remove_action() eseguito nel body di questo file girerebbe prima
 * che il parent registri l'hook, e non avrebbe alcun effetto pur sembrando
 * corretto in code review. Va quindi eseguito su after_setup_theme, che scatta
 * dopo il caricamento di entrambi i functions.php. Gli hook bersaglio scattano
 * molto piu tardi (template_redirect, wp_head), quindi il margine e ampio.
 *
 * @return void
 */
function tenconi_neutralize_parent_hooks() {

	/*
	 * 1. Il parent fa un 301 PERMANENTE di tutti i 404 verso la home.
	 *    Verificato sul subsite prima dell'intervento: anche robots.txt e
	 *    sitemap.xml rispondevano 301 -> home, quindi il sito non era
	 *    indicizzabile e la migrazione non era verificabile.
	 *    Il child fornisce un 404.php reale.
	 */
	remove_action( 'template_redirect', 'ticinoweb_redirect_404_to_home' );

	/*
	 * 2. Il parent inietta uno stile di background image su wp_head che
	 *    confligge con i campi di sezione pieni del child.
	 */
	remove_action( 'wp_head', 'ticinoweb_apply_page_background_image' );
}
add_action( 'after_setup_theme', 'tenconi_neutralize_parent_hooks' );

/**
 * Rimuove Poppins da Google Fonts, accodato dal parent a priorita 10.
 *
 * Il child non introduce dipendenze definitive da CDN di terze parti, anche per
 * ragioni LPD. Poiche il foglio 'ticinoweb-ai-style' dichiara 'poppins-font'
 * come dipendenza, WordPress tratta la dipendenza mancante come semplice
 * vincolo d'ordine e non la reintroduce.
 *
 * I due <link rel="preconnect"> verso Google che il parent stampa a parte sono
 * rimossi da tenconi_remove_parent_font_preconnect().
 *
 * @return void
 */
function tenconi_dequeue_parent_fonts() {

	/*
	 * TRAPPOLA VERIFICATA. Il parent dichiara 'poppins-font' come DIPENDENZA di
	 * 'ticinoweb-ai-style'. Deregistrare la dipendenza senza prima rimuovere il
	 * riferimento fa fallire WP_Dependencies::all_deps() per
	 * 'ticinoweb-ai-style', che quindi non viene stampato; e poiche i fogli del
	 * child dipendono in catena da esso, spariscono tutti dall'HTML.
	 * Osservato in questo progetto: la homepage serviva solo nav.js e nessun CSS.
	 *
	 * Rimuoviamo quindi il riferimento dalla dichiarazione di dipendenza PRIMA
	 * di deregistrare il font.
	 */
	$tc_styles = wp_styles();
	if ( isset( $tc_styles->registered['ticinoweb-ai-style'] ) ) {
		$tc_styles->registered['ticinoweb-ai-style']->deps = array_values(
			array_diff(
				(array) $tc_styles->registered['ticinoweb-ai-style']->deps,
				array( 'poppins-font' )
			)
		);
	}

	wp_dequeue_style( 'poppins-font' );
	wp_deregister_style( 'poppins-font' );
}
add_action( 'wp_enqueue_scripts', 'tenconi_dequeue_parent_fonts', 20 );

/**
 * Rimuove i due <link rel="preconnect"> verso Google Fonts stampati dal parent.
 *
 * Il parent li emette da una closure ANONIMA su wp_head a priorita 0, quindi non
 * esiste un nome da passare a remove_action(). La closure e comunque
 * raggiungibile: WP_Hook espone la proprieta pubblica $callbacks, e
 * ReflectionFunction dice da quale file la closure proviene. Si rimuove quella
 * dichiarata nel functions.php del parent, passando a remove_action() l'oggetto
 * closure stesso.
 *
 * Motivo dell'intervento: il child non carica alcun font da Google, quindi i due
 * preconnect aprono connessioni verso terze parti che non servono nulla. Su un
 * sito aziendale svizzero e un contatto verso terzi da dichiarare senza avere
 * nessun beneficio in cambio.
 *
 * PORTATA. Il filtro e "closure a priorita 0 dichiarata nel functions.php del
 * parent": oggi ce n'e esattamente una, ed e questa. Se un aggiornamento del
 * parent ne aggiungesse un'altra nello stesso punto, verrebbe rimossa anche
 * quella. Il controllo in tools/verify.sh sull'assenza di googleapis nell'HTML
 * intercetta la regressione opposta, cioe il preconnect che ricompare.
 *
 * @return void
 */
function tenconi_remove_parent_font_preconnect() {
	global $wp_filter;

	if ( ! isset( $wp_filter['wp_head'] ) || ! $wp_filter['wp_head'] instanceof WP_Hook ) {
		return;
	}

	$tc_hook = $wp_filter['wp_head'];

	if ( empty( $tc_hook->callbacks[0] ) ) {
		return;
	}

	$tc_parent_file = wp_normalize_path( get_template_directory() . '/functions.php' );

	foreach ( $tc_hook->callbacks[0] as $tc_cb ) {
		if ( empty( $tc_cb['function'] ) || ! $tc_cb['function'] instanceof Closure ) {
			continue;
		}

		try {
			$tc_ref = new ReflectionFunction( $tc_cb['function'] );
		} catch ( ReflectionException $tc_e ) {
			continue;
		}

		if ( wp_normalize_path( (string) $tc_ref->getFileName() ) === $tc_parent_file ) {
			remove_action( 'wp_head', $tc_cb['function'], 0 );
		}
	}
}
add_action( 'after_setup_theme', 'tenconi_remove_parent_font_preconnect' );

/**
 * Rimuove il main.js del parent.
 *
 * Il child sostituisce integralmente header e footer, quindi gli handler del
 * parent agirebbero su un DOM che non esiste piu. Il child porta il proprio
 * nav.js come progressive enhancement.
 *
 * @return void
 */
function tenconi_dequeue_parent_js() {
	wp_dequeue_script( 'ticinoweb-ai-main' );
	wp_deregister_script( 'ticinoweb-ai-main' );
}
add_action( 'wp_enqueue_scripts', 'tenconi_dequeue_parent_js', 20 );
