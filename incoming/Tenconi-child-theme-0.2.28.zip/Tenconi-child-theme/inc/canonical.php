<?php
/**
 * Canonical corretto, senza toccare il parent theme.
 *
 * IL DIFETTO. ticinoweb-ai-theme/inc/seo.php:1550, dentro tw_seo_inject_metadata()
 * agganciata a wp_head con priorita' 1, stampa:
 *
 *     echo '<link rel="canonical" href="' . esc_url(get_permalink()) . '" />';
 *
 * senza alcun is_singular(), a differenza del blocco robots otto righe sopra.
 * get_permalink() senza argomento usa $post globale, quindi:
 *   - sui 7 archivi CPT punta all'ULTIMO contenuto del loop;
 *   - sulle 5 viste di market restituisce '' e stampa href vuoto;
 *   - su ogni singolo e sulla homepage DUPLICA quello di rel_canonical() di core.
 *
 * PERCHE' NON SI PUO' SEMPLICEMENTE RIMUOVERE IL CALLBACK. Quella funzione e' lunga
 * 116 righe e stampa anche la verifica Google e Bing, l'override di robots, la meta
 * description, Open Graph e Twitter Card. Non ha filtri, non ha opzioni, e il
 * canonical non e' separabile. Un remove_action() secco cancellerebbe tutta la
 * metadata SEO del sito per rimuovere una riga.
 *
 * LA SOLUZIONE. Si sostituisce il callback con un wrapper del CHILD che chiama la
 * funzione del parent, ne cattura l'output e rimuove SOLO il tag canonical. Tutto
 * il resto arriva identico. Il parent non viene modificato.
 *
 * PERCHE' NON BASTA LASCIARE LAVORARE IL CORE. rel_canonical() di WordPress emette
 * il canonical soltanto su query singolari: senza un'aggiunta, i 7 archivi CPT e le
 * 5 viste di market resterebbero senza canonical. Il child ne emette uno per loro,
 * e soltanto per loro.
 *
 * DIVISIONE DELLE RESPONSABILITA'
 *   core, rel_canonical()      pagine, homepage statica, singoli CPT, altri singolari
 *   child, questo modulo       i 7 archivi CPT Tenconi e la tassonomia market
 *   nessuno dei due            404, ricerca, feed, e ogni altra vista
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Il canonical del parent, riconosciuto per come lo stampa.
 *
 * Si cerca il tag con rel="canonical", in qualunque ordine di attributi, e si
 * rimuove insieme allo spazio bianco che lo circonda.
 */
const TENCONI_CANONICAL_RE = '#[ \t]*<link[^>]*\brel=(["\'])canonical\1[^>]*>[ \t]*\r?\n?#i';

/**
 * Sostituisce il callback SEO del parent con il wrapper del child.
 *
 * Va eseguito su after_setup_theme: il functions.php del CHILD viene caricato
 * PRIMA di quello del parent, quindi un remove_action() nel body di questo file
 * girerebbe quando il parent non ha ancora agganciato nulla. E' lo stesso motivo
 * documentato in inc/parent-compat.php.
 *
 * @return void
 */
function tenconi_replace_parent_seo_metadata() {
	// Se il parent cambia e la funzione non c'e' piu', non si fa nulla.
	if ( ! function_exists( 'tw_seo_inject_metadata' ) ) {
		return;
	}
	if ( ! has_action( 'wp_head', 'tw_seo_inject_metadata' ) ) {
		return;
	}
	remove_action( 'wp_head', 'tw_seo_inject_metadata', 1 );
	add_action( 'wp_head', 'tenconi_seo_metadata_without_canonical', 1 );
}
add_action( 'after_setup_theme', 'tenconi_replace_parent_seo_metadata' );

/**
 * Chiama la metadata SEO del parent e ne rimuove solo il canonical.
 *
 * Il buffer si apre e si chiude nella stessa funzione: non resta mai aperto fra
 * due hook, quindi non puo' interferire con altri buffer.
 *
 * @return void
 */
function tenconi_seo_metadata_without_canonical() {
	ob_start();
	tw_seo_inject_metadata();
	$out = (string) ob_get_clean();

	$pulito = preg_replace( TENCONI_CANONICAL_RE, '', $out );
	// Se la sostituzione fallisce, preg_replace restituisce null: si stampa
	// l'originale, perche' perdere la metadata SEO e' peggio di un canonical in piu'.
	echo ( null === $pulito ) ? $out : $pulito; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- output del parent, gia' escapato da lui
}

/**
 * I post type i cui archivi ricevono il canonical dal child.
 *
 * Solo quelli registrati da questo tema e con un archivio: sugli archivi del core
 * (categorie, date, autore) non si interviene.
 *
 * @return array
 */
function tenconi_canonical_archive_types() {
	return array( 'product', 'capability', 'machine', 'project', 'certification', 'document', 'job' );
}

/**
 * Aggiunge il numero di pagina a un URL di archivio, con le API di WordPress.
 *
 * Una pagina 2 deve dichiarare come canonico se stessa, non la pagina 1: riportare
 * tutte le pagine alla prima direbbe ai motori che sono duplicati, e nasconderebbe
 * i contenuti dalla seconda pagina in poi.
 *
 * @param string $url   URL base dell'archivio.
 * @param int    $paged Numero di pagina.
 * @return string
 */
function tenconi_canonical_paged( $url, $paged ) {
	$paged = (int) $paged;
	if ( $paged < 2 ) {
		return $url;
	}
	global $wp_rewrite;
	if ( $wp_rewrite instanceof WP_Rewrite && $wp_rewrite->using_permalinks() && $wp_rewrite->pagination_base ) {
		return user_trailingslashit(
			trailingslashit( $url ) . $wp_rewrite->pagination_base . '/' . $paged,
			'paged'
		);
	}
	return add_query_arg( 'paged', $paged, $url );
}

/**
 * URL canonico della vista corrente, o '' se al child non tocca emetterlo.
 *
 * @return string
 */
function tenconi_canonical_url() {
	// Viste su cui non si stampa mai: non sono indicizzabili, o non sono nostre.
	if ( is_admin() || is_feed() || is_embed() || is_404() || is_search() || is_preview() ) {
		return '';
	}
	// Le query singolari le copre rel_canonical() di core: non si duplica.
	if ( is_singular() || is_front_page() || is_home() ) {
		return '';
	}

	$url   = '';
	$paged = max( 1, (int) get_query_var( 'paged' ) );

	if ( is_post_type_archive( tenconi_canonical_archive_types() ) ) {
		$pt = get_query_var( 'post_type' );
		if ( is_array( $pt ) ) {
			$pt = reset( $pt );
		}
		if ( $pt && post_type_exists( $pt ) ) {
			$url = (string) get_post_type_archive_link( $pt );
		}
	} elseif ( is_tax( 'market' ) ) {
		$t = get_queried_object();
		if ( $t instanceof WP_Term ) {
			$link = get_term_link( $t );
			if ( ! is_wp_error( $link ) ) {
				$url = (string) $link;
			}
		}
	}

	if ( '' === $url ) {
		return '';
	}
	return tenconi_canonical_paged( $url, $paged );
}

/**
 * Stampa il canonical degli archivi e di market.
 *
 * Priorita' 10, la stessa di rel_canonical(): le due non si sovrappongono mai
 * perche' le condizioni sono disgiunte, ed entrambe tacciono dove non tocca loro.
 *
 * @return void
 */
function tenconi_print_canonical() {
	$url = tenconi_canonical_url();
	if ( '' === $url ) {
		return;
	}
	echo '<link rel="canonical" href="' . esc_url( $url ) . '" />' . "\n";
}
add_action( 'wp_head', 'tenconi_print_canonical', 10 );

/**
 * Stato del canonical per la vista corrente. Serve alla verifica, non al rendering.
 *
 * @return array
 */
function tenconi_canonical_status() {
	return array(
		'parent_rimosso'  => ! has_action( 'wp_head', 'tw_seo_inject_metadata' ),
		'wrapper_attivo'  => (bool) has_action( 'wp_head', 'tenconi_seo_metadata_without_canonical' ),
		'core_attivo'     => (bool) has_action( 'wp_head', 'rel_canonical' ),
		'child_attivo'    => (bool) has_action( 'wp_head', 'tenconi_print_canonical' ),
		'url_del_child'   => tenconi_canonical_url(),
	);
}
