<?php
/**
 * RICERCA DAL VIVO: l'endpoint che alimenta il campo nell'header.
 *
 * NON C'ERA NIENTE DA RIUSARE. Verificato: il tema non ha search.php, non ha un
 * form di ricerca, non registra rotte REST e non ha azioni AJAX. Quindi si
 * costruisce, e si costruisce sul contenuto vero del sito: pagine piu' i sette
 * tipi personalizzati pubblici, non un elenco scritto a mano.
 *
 * IL PUNTO IMPORTANTE E' IL CANCELLO, e non e' un dettaglio tecnico.
 *
 * Questo tema ha una dottrina dichiarata in nav-config.php: non si porta il
 * visitatore su contenuti non pubblicabili — testi marcati segnaposto, materiale
 * che il committente ha messo in attesa di riautorizzazione. Il menu la rispetta,
 * il footer la rispetta, la home la rispetta.
 *
 * Una ricerca ingenua — un WP_Query con "s" e via — l'avrebbe aggirata in un
 * colpo: avrebbe restituito cookie-policy e termini-uso, che hanno cinquantaquattro
 * caratteri di segnaposto, e i progetti marcati "Da riautorizzare". Il cancello
 * chiuso davanti e la porta di servizio aperta dietro.
 *
 * Quindi ogni risultato passa da tenconi_testo_pubblicabile(), la stessa funzione
 * che decide se una voce del menu si accende. Una sola regola, un solo posto.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Quanti risultati si mostrano, e quanti se ne pescano per arrivarci.
 *
 * Si pesca largo perche' il cancello scarta: chiedendone sei si rischiava di
 * mostrarne due perche' gli altri quattro erano da riautorizzare.
 */
const TENCONI_CERCA_MOSTRA = 6;
const TENCONI_CERCA_PESCA  = 40;

/**
 * I tipi di contenuto in cui si cerca.
 *
 * @return array<int,string>
 */
function tenconi_cerca_tipi() {
	return array( 'page', 'product', 'capability', 'machine', 'project', 'certification', 'document', 'job' );
}

/**
 * L'etichetta del tipo, come la vede il visitatore.
 *
 * Si legge dall'oggetto del tipo registrato invece di scriverla qui: se un domani
 * "Lavorazione" diventa "Lavorazione meccanica", il risultato lo dice da solo.
 *
 * @param string $tipo Nome del tipo di contenuto.
 * @return string
 */
function tenconi_cerca_etichetta( $tipo ) {
	if ( 'page' === $tipo ) {
		return 'Pagina';
	}
	$o = get_post_type_object( $tipo );
	if ( $o && ! empty( $o->labels->singular_name ) ) {
		return (string) $o->labels->singular_name;
	}
	return '';
}

/**
 * La ricerca.
 *
 * @param string $q Testo cercato.
 * @return array{risultati:array<int,array<string,string>>,totale:int}
 */
function tenconi_cerca( $q ) {

	$q = trim( wp_strip_all_tags( (string) $q ) );
	if ( mb_strlen( $q ) < 2 ) {
		return array(
			'risultati' => array(),
			'totale'    => 0,
		);
	}

	$query = new WP_Query(
		array(
			's'                   => $q,
			'post_type'           => tenconi_cerca_tipi(),
			'post_status'         => 'publish',
			'posts_per_page'      => TENCONI_CERCA_PESCA,
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
			/*
			 * Nessun filtro soppresso: i redirect e le regole del tema devono
			 * valere anche qui, altrimenti la ricerca vedrebbe un sito diverso da
			 * quello che il visitatore naviga.
			 */
			'suppress_filters'    => false,
		)
	);

	$fuori = array();
	$out   = array();

	foreach ( $query->posts as $post ) {

		if ( count( $out ) >= TENCONI_CERCA_MOSTRA ) {
			break;
		}

		/* IL CANCELLO, lo stesso del menu e del footer. */
		$v = tenconi_testo_pubblicabile( $post );
		if ( ! $v['ok'] ) {
			$fuori[] = $post->post_title;
			continue;
		}

		$url = get_permalink( $post );
		if ( ! $url ) {
			continue;
		}

		$out[] = array(
			'titolo' => html_entity_decode( wp_strip_all_tags( get_the_title( $post ) ), ENT_QUOTES, 'UTF-8' ),
			'tipo'   => tenconi_cerca_etichetta( $post->post_type ),
			'url'    => (string) $url,
		);
	}

	return array(
		'risultati' => $out,
		'totale'    => count( $out ),
		/*
		 * Quanti sono stati scartati dal cancello. Non si mostra al visitatore: e'
		 * per chi verifica, perche' "zero risultati" e "sei risultati tutti
		 * trattenuti" sono due cose molto diverse da diagnosticare.
		 */
		'esclusi'   => count( $fuori ),
	);
}

/**
 * La rotta REST.
 *
 * PUBBLICA E IN SOLA LETTURA, quindi nessun nonce: legge soltanto contenuti che
 * sono gia' pubblicati e visibili a chiunque, e chiedere un token per una ricerca
 * pubblica significherebbe romperla per chi arriva con la cache di una pagina.
 */
function tenconi_cerca_rotta() {
	register_rest_route(
		'tenconi/v1',
		'/cerca',
		array(
			'methods'             => WP_REST_Server::READABLE,
			'permission_callback' => '__return_true',
			'args'                => array(
				'q' => array(
					'required'          => true,
					'type'              => 'string',
					'sanitize_callback' => 'sanitize_text_field',
				),
			),
			'callback'            => function ( WP_REST_Request $req ) {
				return rest_ensure_response( tenconi_cerca( (string) $req->get_param( 'q' ) ) );
			},
		)
	);
}
add_action( 'rest_api_init', 'tenconi_cerca_rotta' );
