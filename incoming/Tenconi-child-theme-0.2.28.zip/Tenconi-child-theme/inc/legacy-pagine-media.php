<?php
/**
 * MAPPA DEI MEDIA di due pagine interne con screenshot legacy.
 *
 * PARCO MACCHINE. Sei gruppi etichettati, ciascuno con una griglia di 3 colonne
 * da 444 con gap 34: e' LA STESSA GRIGLIA DELLA HOMEPAGE, non una nuova. Le
 * immagini sono in rapporto 4:3 (444 x 333, misurato 1,333), non 3:2 come nella
 * home. Le didascalie sono i nomi dei macchinari e vengono dall'attributo alt del
 * legacy. 33 immagini, tutte risolte su un attachment.
 *
 * GESTIONE PROGETTI SPECIALI. Due colonne da 682 con gap 35: immagine a
 * sinistra in rapporto 1,204, testo a destra, e un pulsante centrato sotto.
 * L'immagine e' l'attachment 491, cioe' Untitled+design+(3).png: su QUESTA
 * pagina e' l'asset legacy giusto, mentre nel blocco della homepage il legacy
 * usava un altro fotogramma della stessa riunione. Non e' una contraddizione:
 * sono due pagine diverse con due scelte diverse.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function tenconi_legacy_parco_macchine() {

	return array(

		array(
			'etichetta' => 'Meccanica',
			'img'       => array(
				array( 580, 'PARPAS XS' ),  // _SAB0399-parpas.jpg
				array( 554, 'MANDELLI&nbsp; 7U HP' ),  // DSC_0019.png
				array( 552, 'Mandelli Storm 1400' ),  // Centro+di+lavoro+orizzontale++verticale+U+8000+CNC+MANDELLI+STORM+1400+6+pallets+800x1000mm.jpg
				array( 515, 'Mandelli SAMU 1500 U50 Regent' ),  // Centro+di+lavoro+verticale-orizzontale+CNC+Mandelli+SAMU+REGENT+1500+3+pallets.jpg
				array( 555, 'SIGMA ZENIT 3P' ),  // DSC_0024.png
				array( 570, 'SIGMA MISSION 5' ),  // Sigma+Mission+5.png
				array( 487, 'FRAZER OPEN-XL' ),  // FRAZER+OPEN-XL.png
				array( 557, 'TIGER TFA 5' ),  // Fresatrice+universale+CNC+TIGER.jpg
				array( 560, 'MCM TANK TH1300' ),  // MCM%252BTANK.jpg
				array( 292, '&nbsp;CARNAGHI TG 25' ),  // _SAB1158-Carnaghi.jpg
				array( 566, 'SAMSUNG PL-45XLM' ),  // SAMSUNG+PL-45XLM.png
				array( 563, 'RETTIFICA PER TONDI KELLENBERGER' ),  // Rettifica+per+tondi.png
				array( 565, 'RULLATRICE ORT RP30 U CN' ),  // Rullatrice+ORT+RP30+U.png
				array( 518, 'MCM ATL HEAVY PLUS 800' ),  // Tornio+CNC+MCM+ATL+HEAVY+PLUS+800.jpg
				array( 562, 'RETTIFICA PIANA BLOHM' ),  // RETTIFICA+PIANA+BLOHM.jpg
			),
		),

		array(
			'etichetta' => 'Carpenteria',
			'img'       => array(
				array( 571, 'TIESSE FA06E-FD40 / KAWASAKI' ),  // Sistema+robotizzato+di+saldatura+TIESSE+FA06E-FD40+KAWASAKI.jpg
				array( 572, 'TIESSE FA10L-FD40 / KAWASAKI' ),  // Sistema+robotizzato+di+saldatura+TIESSE+FA10L-FD40+KAWASAKI.png
				array( 264, 'OSSITAGLIO CNC MESSER 260 A' ),  // _SAB0769.jpg
				array( 575, 'PRESSA SCHARRINGHAUSEN' ),  // _SAB2746-scharringauser.jpg
				array( 576, 'PRESSA CNC GASPARINI' ),  // _SAB4032.jpg
				array( 568, 'SEGATRICE SHARK 652 SXI H 5.0' ),  // SEGATRICE+SHARK+652+SXI+H+5.0.png
			),
		),

		array(
			'etichetta' => 'Forgia e Preparazione',
			'img'       => array(
				array( 512, 'MAGLIO BANNING GOA 4000' ),  // DSC_0053.jpg
				array( 577, 'GRANIGLIATRICE OMSG CWB 850 4/FAC' ),  // granigliatrice+.jpg
				array( 569, 'SEGA A NASTRO ISTECH 431NCL' ),  // Sega+a+nastro+ISTECH+431NCL.png
				array( 567, 'SEGA A NASTRO ISTECH 350SA' ),  // SEGA+A+NASTRO+ISTECH+350SA.png
			),
		),

		array(
			'etichetta' => 'Alluminio',
			'img'       => array(
				array( 517, 'MANIPOLATORE DI SALDATURA' ),  // Manipolatore+di+saldatura+2.jpg
				array( 564, 'ROBOT DI SALDATURA' ),  // Robot+di+saldatura+1.jpg
				array( 506, 'KAWASAKI FA 10L FRONIUS' ),  // Kawasaki+FRONIUS+3.png
				array( 337, 'DEUMA FANUC ARC MATE 50 IC' ),  // _SAB4587-deuma.jpg
				array( 558, 'FRONIUS' ),  // Fronius.jpg
			),
		),

		array(
			'etichetta' => 'Controllo qualità',
			'img'       => array(
				array( 561, 'Macchina di misura HERA SP' ),  // Macchina+di+misura+HERA+SP.jpg
				array( 509, 'MACCHINA DI MISURA ATHENA' ),  // _SAB0118-athena.jpg
			),
		),

		array(
			'etichetta' => 'Logistica',
			'img'       => array(
				array( 551, 'AUTOCARRO RENAULT PREMIUM 370' ),  // Autocarro%2BRENAULT%2BPremium%2B370%2B6x2.jpg
			),
		),
	);
}

