<?php
/**
 * Risoluzione dei link di navigazione verso contenuti REALI.
 *
 * Il menu del Lotto 1 portava URL scritti a mano in inc/content.php, molti dei
 * quali non corrispondevano a nulla. Ora i contenuti esistono: questo modulo
 * risolve ogni voce contro il database e scarta quelle che non hanno destinazione,
 * invece di lasciare 404 nel menu.
 *
 * Il menu WordPress definitivo, con le 57 voci, resta in CF-4. Qui si garantisce
 * solo che le sette destinazioni principali e le voci mostrate siano raggiungibili.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Le sette destinazioni principali, nell'ordine approvato.
 *
 * Ogni voce dichiara COME si risolve, non un URL letterale:
 *   page     -> permalink della pagina con quello slug
 *   archive  -> archivio del CPT
 *   term     -> archivio del termine di tassonomia
 *
 * @return array
 */
function tenconi_primary_destinations() {
	return array(
		array( 'label' => 'Azienda',               'kind' => 'page',    'ref' => 'azienda' ),
		array( 'label' => 'Prodotti',              'kind' => 'archive', 'ref' => 'product' ),
		array( 'label' => 'Lavorazioni',           'kind' => 'archive', 'ref' => 'capability' ),
		array( 'label' => 'Progetti e referenze',  'kind' => 'archive', 'ref' => 'project' ),
		array( 'label' => 'Qualità',               'kind' => 'page',    'ref' => 'qualita' ),
		array( 'label' => 'Lavora con noi',        'kind' => 'archive', 'ref' => 'job' ),
		array( 'label' => 'Contatti',              'kind' => 'page',    'ref' => 'contatti' ),
	);
}

/**
 * Risolve una destinazione in un URL reale, o '' se non esiste.
 *
 * @param string $kind page|archive|term|cpt.
 * @param string $ref  slug della pagina, nome del post type, oppure 'tax/slug'.
 * @return string URL, o stringa vuota.
 */
function tenconi_resolve( $kind, $ref ) {
	switch ( $kind ) {
		case 'page':
			$p = get_page_by_path( $ref, OBJECT, 'page' );
			return ( $p && 'publish' === $p->post_status ) ? (string) get_permalink( $p ) : '';

		case 'archive':
			if ( ! post_type_exists( $ref ) ) {
				return '';
			}
			$url = get_post_type_archive_link( $ref );
			return $url ? (string) $url : '';

		case 'term':
			list( $tax, $slug ) = array_pad( explode( '/', $ref, 2 ), 2, '' );
			if ( ! $tax || ! $slug || ! taxonomy_exists( $tax ) ) {
				return '';
			}
			$t = get_term_by( 'slug', $slug, $tax );
			if ( ! $t || is_wp_error( $t ) ) {
				return '';
			}
			$url = get_term_link( $t );
			return is_wp_error( $url ) ? '' : (string) $url;

		case 'cpt':
			list( $pt, $slug ) = array_pad( explode( '/', $ref, 2 ), 2, '' );
			if ( ! $pt || ! $slug || ! post_type_exists( $pt ) ) {
				return '';
			}
			$p = get_page_by_path( $slug, OBJECT, $pt );
			return ( $p && 'publish' === $p->post_status ) ? (string) get_permalink( $p ) : '';
	}
	return '';
}

/**
 * Struttura del menu principale, con ogni URL risolto contro il database.
 *
 * Le voci non risolvibili vengono SCARTATE, non lasciate a 404. Se una voce di
 * primo livello non si risolve, resta nel menu ma senza link e con un attributo
 * che la dichiara: nasconderla renderebbe invisibile un problema.
 *
 * @return array Struttura compatibile con il template del mega menu.
 */
function tenconi_nav_resolved() {
	static $cache = null;
	if ( null !== $cache ) {
		return $cache;
	}

	// I cinque settori, come colonna condivisa fra Prodotti e Lavorazioni.
	$settori = array();
	foreach ( array(
		'ferroviario-infrastruttura' => 'Infrastruttura ferroviaria',
		'ferroviario-rotabile'       => 'Materiale rotabile',
		'energia'                    => 'Energia e idroelettrico',
		'telecomunicazioni'          => 'Telecomunicazioni',
		'genio-civile'               => 'Genio civile',
	) as $slug => $label ) {
		$url = tenconi_resolve( 'term', 'market/' . $slug );
		if ( $url ) {
			$settori[] = array( 'label' => $label, 'url' => $url );
		}
	}

	/**
	 * Costruisce una colonna di sottovoci, scartando quelle non risolvibili.
	 *
	 * @param string $titolo Titolo della colonna.
	 * @param array  $voci   Elenco di array( label, kind, ref, feature ).
	 * @return array|null
	 */
	$colonna = function ( $titolo, array $voci ) {
		$out = array();
		foreach ( $voci as $v ) {
			$url = tenconi_resolve( $v['kind'], $v['ref'] );
			if ( ! $url ) {
				continue;
			}
			$item = array( 'label' => $v['label'], 'url' => $url );
			if ( ! empty( $v['feature'] ) ) {
				$item['feature'] = true;
			}
			$out[] = $item;
		}
		return $out ? array( 'title' => $titolo, 'items' => $out ) : null;
	};

	$nav = array();

	// 1. Azienda
	$cols = array_filter( array(
		$colonna( 'Azienda', array(
			array( 'label' => 'Chi siamo',          'kind' => 'page', 'ref' => 'chi-siamo' ),
			array( 'label' => 'La nostra storia',   'kind' => 'page', 'ref' => 'storia' ),
			array( 'label' => 'Airolo e Cadenazzo', 'kind' => 'page', 'ref' => 'sedi' ),
		) ),
	) );
	$nav[] = array(
		'label' => 'Azienda',
		'url'   => tenconi_resolve( 'page', 'azienda' ),
		'cols'  => array_values( $cols ),
	);

	// 2. Prodotti
	$cols = array_filter( array(
		$colonna( 'Catalogo', array(
			array( 'label' => 'Giunti isolanti per rotaie',  'kind' => 'cpt', 'ref' => 'product/giunti-isolanti' ),
			array( 'label' => 'Piastre isolanti e speciali', 'kind' => 'cpt', 'ref' => 'product/piastre-isolanti' ),
			array( 'label' => 'Giunti meccanici',            'kind' => 'cpt', 'ref' => 'product/giunti-meccanici' ),
			array( 'label' => 'Traverse cave in acciaio',    'kind' => 'cpt', 'ref' => 'product/traverse' ),
			array( 'label' => 'Pali tubolari e sostegni',    'kind' => 'cpt', 'ref' => 'product/pali-tubolari' ),
			array( 'label' => 'C-Clamp e Joggle fishplate',  'kind' => 'cpt', 'ref' => 'product/dispositivi-fissaggio' ),
		) ),
		$settori ? array( 'title' => 'Settori', 'items' => $settori ) : null,
	) );
	$nav[] = array(
		'label' => 'Prodotti',
		'url'   => tenconi_resolve( 'archive', 'product' ),
		'cols'  => array_values( $cols ),
	);

	// 3. Lavorazioni
	$cols = array_filter( array(
		$colonna( 'Competenze', array(
			array( 'label' => 'Lavorazioni meccaniche',   'kind' => 'cpt', 'ref' => 'capability/lavorazioni-meccaniche' ),
			array( 'label' => 'Forgiatura e stampaggio',  'kind' => 'cpt', 'ref' => 'capability/forgiatura-stampaggio' ),
			array( 'label' => 'Saldatura acciaio',        'kind' => 'cpt', 'ref' => 'capability/saldatura-acciaio' ),
			array( 'label' => 'Lavorazione alluminio',    'kind' => 'cpt', 'ref' => 'capability/lavorazione-alluminio' ),
			array( 'label' => 'Plastificazione',          'kind' => 'cpt', 'ref' => 'capability/plastificazione' ),
			array( 'label' => 'Carpenteria metallica',    'kind' => 'cpt', 'ref' => 'capability/carpenteria-metallica' ),
		) ),
		$colonna( 'Servizi', array(
			array( 'label' => 'Revisione carri merce',    'kind' => 'cpt', 'ref' => 'capability/revisione-carri-merce' ),
			array( 'label' => 'Manutenzione centrali',    'kind' => 'cpt', 'ref' => 'capability/manutenzione-centrali' ),
			array( 'label' => 'Revisioni idromeccaniche', 'kind' => 'cpt', 'ref' => 'capability/revisioni-idromeccaniche' ),
			array( 'label' => 'Parco macchine',           'kind' => 'archive', 'ref' => 'machine', 'feature' => true ),
		) ),
		$settori ? array( 'title' => 'Settori', 'items' => $settori ) : null,
	) );
	$nav[] = array(
		'label' => 'Lavorazioni',
		'url'   => tenconi_resolve( 'archive', 'capability' ),
		'cols'  => array_values( $cols ),
	);

	// 4. Progetti e referenze
	$nav[] = array(
		'label' => 'Progetti',
		'url'   => tenconi_resolve( 'archive', 'project' ),
	);

	// 5. Qualita
	$cols = array_filter( array(
		$colonna( 'Qualità', array(
			array( 'label' => 'Certificazioni',  'kind' => 'archive', 'ref' => 'certification' ),
			array( 'label' => 'Sostenibilità',   'kind' => 'page',    'ref' => 'sostenibilita' ),
			array( 'label' => 'Documenti',       'kind' => 'archive', 'ref' => 'document' ),
		) ),
	) );
	$nav[] = array(
		'label' => 'Qualità',
		'url'   => tenconi_resolve( 'page', 'qualita' ),
		'cols'  => array_values( $cols ),
	);

	// 6. Lavora con noi
	$cols = array_filter( array(
		$colonna( 'Carriere', array(
			array( 'label' => 'Posizioni aperte',   'kind' => 'archive', 'ref' => 'job' ),
			array( 'label' => 'La vita in Tenconi', 'kind' => 'page',    'ref' => 'vita-in-tenconi' ),
		) ),
	) );
	$nav[] = array(
		'label' => 'Lavora con noi',
		'url'   => tenconi_resolve( 'archive', 'job' ),
		'cols'  => array_values( $cols ),
	);

	// 7. Contatti
	$nav[] = array(
		'label' => 'Contatti',
		'url'   => tenconi_resolve( 'page', 'contatti' ),
	);

	// Le voci senza URL restano visibili ma dichiarate: un menu che nasconde un
	// problema e' peggio di un menu che lo mostra.
	foreach ( $nav as $i => $voce ) {
		if ( empty( $voce['url'] ) ) {
			$nav[ $i ]['unresolved'] = true;
			$nav[ $i ]['url']        = '';
		}
	}

	$cache = $nav;
	return $cache;
}

/**
 * Elenco delle sette destinazioni con il loro stato di risoluzione.
 * Serve alla verifica, non al rendering.
 *
 * @return array
 */
function tenconi_primary_status() {
	$out = array();
	foreach ( tenconi_primary_destinations() as $d ) {
		$url        = tenconi_resolve( $d['kind'], $d['ref'] );
		$out[]      = array(
			'label'   => $d['label'],
			'kind'    => $d['kind'],
			'ref'     => $d['ref'],
			'url'     => $url,
			'risolta' => (bool) $url,
		);
	}
	return $out;
}

/**
 * Voci del footer, risolte. Solo quelle che esistono.
 *
 * @return array
 */
function tenconi_footer_resolved() {
	$gruppi = array(
		'Prodotti'    => array(
			array( 'label' => 'Giunti isolanti',    'kind' => 'cpt',     'ref' => 'product/giunti-isolanti' ),
			array( 'label' => 'Traverse in acciaio', 'kind' => 'cpt',    'ref' => 'product/traverse' ),
			array( 'label' => 'Tutti i prodotti',   'kind' => 'archive', 'ref' => 'product' ),
		),
		'Lavorazioni' => array(
			array( 'label' => 'Lavorazioni meccaniche', 'kind' => 'cpt',     'ref' => 'capability/lavorazioni-meccaniche' ),
			array( 'label' => 'Parco macchine',         'kind' => 'archive', 'ref' => 'machine' ),
			array( 'label' => 'Tutte le lavorazioni',   'kind' => 'archive', 'ref' => 'capability' ),
		),
		'Settori'     => array(
			array( 'label' => 'Infrastruttura ferroviaria', 'kind' => 'term', 'ref' => 'market/ferroviario-infrastruttura' ),
			array( 'label' => 'Materiale rotabile',         'kind' => 'term', 'ref' => 'market/ferroviario-rotabile' ),
			array( 'label' => 'Energia e idroelettrico',    'kind' => 'term', 'ref' => 'market/energia' ),
			array( 'label' => 'Telecomunicazioni',          'kind' => 'term', 'ref' => 'market/telecomunicazioni' ),
			array( 'label' => 'Genio civile',               'kind' => 'term', 'ref' => 'market/genio-civile' ),
		),
		'Qualità'     => array(
			array( 'label' => 'Certificazioni', 'kind' => 'archive', 'ref' => 'certification' ),
			array( 'label' => 'Sostenibilità',  'kind' => 'page',    'ref' => 'sostenibilita' ),
			array( 'label' => 'Documenti',      'kind' => 'archive', 'ref' => 'document' ),
		),
		'Azienda'     => array(
			array( 'label' => 'Chi siamo',      'kind' => 'page',    'ref' => 'chi-siamo' ),
			array( 'label' => 'Lavora con noi', 'kind' => 'archive', 'ref' => 'job' ),
			array( 'label' => 'Contatti',       'kind' => 'page',    'ref' => 'contatti' ),
		),
	);

	$out = array();
	foreach ( $gruppi as $titolo => $voci ) {
		$items = array();
		foreach ( $voci as $v ) {
			$url = tenconi_resolve( $v['kind'], $v['ref'] );
			if ( $url ) {
				$items[] = array( 'label' => $v['label'], 'url' => $url );
			}
		}
		if ( $items ) {
			$out[] = array( 'title' => $titolo, 'items' => $items );
		}
	}
	return $out;
}

/**
 * Link legali del footer, risolti.
 *
 * @return array
 */
function tenconi_legal_resolved() {
	$out = array();
	foreach ( array(
		'privacy'      => 'Privacy',
		'cookie-policy' => 'Cookie',
		'termini-uso'  => "Termini d'uso",
	) as $slug => $label ) {
		$url = tenconi_resolve( 'page', $slug );
		if ( $url ) {
			$out[] = array( 'label' => $label, 'url' => $url );
		}
	}
	return $out;
}

/**
 * URL della CTA principale: la pagina Contatti, se esiste.
 *
 * @return string
 */
function tenconi_cta_url() {
	$url = tenconi_resolve( 'page', 'contatti' );
	return $url ? $url : home_url( '/' );
}

/**
 * Href finale di una voce di navigazione.
 *
 * Il risolutore restituisce URL ASSOLUTI (get_permalink, get_post_type_archive_link),
 * mentre l'array statico di inc/content.php porta path relativi. Passare un URL
 * assoluto a home_url() produce un indirizzo rotto: questo helper distingue i due
 * casi e restituisce sempre un href valido.
 *
 * @param string $url URL assoluto o path relativo.
 * @return string Href pronto per esc_url(), o '' se la voce non e' risolta.
 */
function tenconi_href( $url ) {
	$url = (string) $url;
	if ( '' === trim( $url ) ) {
		return '';
	}
	if ( preg_match( '#^(https?:)?//#i', $url ) || 0 === strpos( $url, 'mailto:' ) || 0 === strpos( $url, 'tel:' ) ) {
		return $url;
	}
	return home_url( $url );
}
