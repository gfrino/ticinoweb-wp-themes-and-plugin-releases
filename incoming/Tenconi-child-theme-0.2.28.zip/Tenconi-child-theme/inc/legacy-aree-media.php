<?php
/**
 * MAPPA DEI MEDIA DELLE PAGINE AREA DI ATTIVITA', ricavata dal legacy.
 *
 * LE CINQUE PAGINE AREA SONO UNA SOLA FAMIGLIA. Struttura verificata su tutti e
 * cinque gli screenshot e su tutti e cinque i sorgenti in cache:
 *   H1 centrato, maiuscolo, blu, altezza di cassa 42,5
 *   riga "PRODOTTI: ..." centrata, cassa 14,5
 *   galleria di immagini QUADRATE, 4 colonne da 334,5 con gap 20,5 (= 1400)
 *   didascalia centrata sotto ogni immagine
 *   riga "LAVORAZIONE: ..." e seconda galleria uguale
 *   filetto, footer
 *
 * LE DIDASCALIE VENGONO DALL'ATTRIBUTO alt del legacy, non inventate: nel sorgente
 * Squarespace la didascalia della galleria e' scritta la'. Ogni immagine compare due
 * volte nell'HTML (versione pigra piu' fallback) e viene deduplicata per
 * identificativo Squarespace, non per nome file, perche' i nomi si ripetono.
 *
 * Gli attachment sono scelti preferendo la copia importata dalla CARTELLA DELLA
 * PAGINA STESSA, che e' la copia che il committente ha consegnato per quella pagina.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function tenconi_legacy_aree_media() {

	return array(

		'ferroviario-infrastruttura' => array(
			'h1'   => 'FERROVIARIO - INFRASTRUTTURA',
			'dest' => 'market:ferroviario-infrastruttura',
			'g1'   => array(
				'etichetta' => 'PRODOTTI',
				'elenco'    => 'traverse, giunti, pioche, morsetti, piastre plastificate',
				'img'       => array(
					array( 269, 'Traversa grezza' ),  // _SAB2778.jpg
					array( 270, 'Traversa pitturata' ),  // _SAB2797.jpg
					array( 271, 'Traversa con piastre' ),  // _SAB2808.jpg
					array( 272, 'Traversa completa' ),  // _SAB2814.jpg
					array( 273, 'Giunto ferroviario' ),  // _SAB2995.jpg
					array( 288, 'Giunto plastificato' ),  // giunto+plastificato.PNG
					array( 289, 'Giunto plastificato' ),  // giunto+plastificato2.jpg
					array( 287, 'Giunto plastificato' ),  // giunto+plastificato+3.jpg
					array( 274, 'Pioche' ),  // _SAB3125.jpg
					array( 290, 'Piastra isolata' ),  // piastra+isolata.jpg
					array( 291, 'Piastre isolate' ),  // piastra+isolata2.jpg
					array( 277, 'Traversa' ),  // _SAB4232.jpg
					array( 275, 'Traversa' ),  // _SAB4191.jpg
					array( 276, 'Traversa' ),  // _SAB4197.jpg
				),
			),
			'g2'   => array(
				'etichetta' => 'LAVORAZIONE',
				'elenco'    => 'forgia, ossitaglio, saldatura, preparazione, meccanica',
				'img'       => array(
					array( 260, '' ),  // _SAB0286.jpg
					array( 262, '' ),  // _SAB0617.jpg
					array( 261, '' ),  // _SAB0601.jpg
					array( 259, '' ),  // _SAB0203.jpg
					array( 264, '' ),  // _SAB0769.jpg
					array( 263, '' ),  // _SAB0741.jpg
					array( 268, '' ),  // _SAB2697.jpg
					array( 286, '' ),  // _SAB9994.jpg
					array( 284, '' ),  // _SAB9935.jpg
					array( 285, '' ),  // _SAB9980.jpg
					array( 258, '' ),  // _SAB0047.jpg
					array( 266, '' ),  // _SAB1148.jpg
					array( 267, '' ),  // _SAB1158.jpg
					array( 265, '' ),  // _SAB1139.jpg
					array( 282, '' ),  // _SAB5592.jpg
					array( 278, '' ),  // _SAB5572.jpg
					array( 279, '' ),  // _SAB5579.jpg
					array( 280, '' ),  // _SAB5584.jpg
					array( 281, '' ),  // _SAB5587.jpg
					array( 283, '' ),  // _SAB5594.jpg
				),
			),
		),

		'ferroviario-rotabile' => array(
			'h1'   => 'FERROVIARIO - ROTABILE',
			'dest' => 'market:ferroviario-rotabile',
			'g1'   => array(
				'etichetta' => 'PRODOTTI',
				'elenco'    => 'assemblaggio e saldatura di carrozze ferroviarie',
				'img'       => array(
					array( 400, 'Tetto carrozza' ),  // _SAB0353.jpg
					array( 401, 'Dettaglio tetto' ),  // _SAB0386.jpg
					array( 402, 'Dettaglio tetto' ),  // _SAB0392.jpg
					array( 406, 'Tetto carrozza' ),  // _SAB4624.jpg
					array( 407, 'Tetto carrozza' ),  // _SAB4631.jpg
					array( 410, 'Respingenti locomotiva' ),  // _SAB4665.jpg
					array( 413, 'Dima d\'assiemaggio' ),  // _SAB4699.jpg
				),
			),
			'g2'   => array(
				'etichetta' => 'LAVORAZIONE',
				'elenco'    => 'meccanica, carpenteria, saldatura',
				'img'       => array(
					array( 403, '' ),  // _SAB0399.jpg
					array( 404, '' ),  // _SAB0409.jpg
					array( 405, '' ),  // _SAB4587.jpg
					array( 409, '' ),  // _SAB4651.jpg
					array( 411, '' ),  // _SAB4668.jpg
					array( 408, '' ),  // _SAB4633.jpg
					array( 412, '' ),  // _SAB4691.jpg
					array( 414, '' ),  // _SAB4705.jpg
					array( 398, '' ),  // TELAIO+IN+PRODUZIONE.jpg
					array( 399, '' ),  // TELAIO+IN+SPEDIZIONE.jpg
				),
			),
		),

		'metalmeccanica' => array(
			'h1'   => 'METALMECCANICA',
			'dest' => 'capability:lavorazioni-meccaniche',
			'g1'   => array(
				'etichetta' => 'PRODOTTI',
				'elenco'    => 'statori, componenti settore ferroviario (p.es. assili, giunti, piastre), componenti settore energia',
				'img'       => array(
					array( 527, 'Statore' ),  // _SAB4256.jpg
					array( 526, 'Statore' ),  // _SAB4253.jpg
					array( 525, 'Frästeil' ),  // _SAB3999.jpg
					array( 524, 'Riegel Linke' ),  // _SAB3977.jpg
					array( 528, 'Ciabatta' ),  // _SAB4274.jpg
					array( 529, 'Piastra' ),  // _SAB4288.jpg
				),
			),
			'g2'   => array(
				'etichetta' => 'LAVORAZIONE',
				'elenco'    => 'tornitura, fresatura',
				'img'       => array(
					array( 258, '' ),  // _SAB0047.jpg
					array( 520, '' ),  // _SAB0054.jpg
					array( 267, '' ),  // _SAB1158.jpg
					array( 521, '' ),  // _SAB1139.jpg
					array( 522, '' ),  // _SAB3945.jpg
					array( 523, '' ),  // _SAB3960.jpg
				),
			),
		),

		'carpenteria-metallica' => array(
			'h1'   => 'CARPENTERIA METALLICA',
			'dest' => 'capability:carpenteria-metallica',
			'g1'   => array(
				'etichetta' => 'PRODOTTI',
				'elenco'    => 'pali tubolari, dime d’assiemaggio, strutture portanti (p.es. ponti, passerelle), portali segnaletici, servizi di manutenzione, stoccaggio e logistica',
				'img'       => array(
					array( 296, 'Palo tubolare' ),  // _SAB2636.jpg
					array( 297, 'Palo tubolare' ),  // _SAB2650.jpg
					array( 301, 'Palo tubolare' ),  // _SAB2963.jpg
					array( 300, 'Dima meccanica' ),  // _SAB2705.jpg
					array( 295, 'Lavorazioni di carpenteria' ),  // IMG_6315.jpg
					array( 294, 'Ponte ferroviario' ),  // IMG_20200914_082247.jpg
					array( 293, 'Ponte ferroviario' ),  // 1O0A0467.jpg
					array( 305, 'Antenna 5G' ),  // _SAB4056.jpg
					array( 306, 'Antenna 5G' ),  // _SAB4064.jpg
					array( 309, 'Componente idroelettrico' ),  // _SAB4106.jpg
					array( 310, 'Componente idroelettrico' ),  // _SAB4109.jpg
				),
			),
			'g2'   => array(
				'etichetta' => 'LAVORAZIONE',
				'elenco'    => 'carpenteria, saldatura, ossitaglio, piegatura',
				'img'       => array(
					array( 298, '' ),  // _SAB2654.jpg
					array( 299, '' ),  // _SAB2661.jpg
					array( 268, '' ),  // _SAB2697.jpg
					array( 263, '' ),  // _SAB0741.jpg
					array( 264, '' ),  // _SAB0769.jpg
					array( 302, '' ),  // _SAB4034.jpg
					array( 303, '' ),  // _SAB4040.jpg
					array( 304, '' ),  // _SAB4051.jpg
					array( 307, '' ),  // _SAB4081.jpg
					array( 308, '' ),  // _SAB4085.jpg
					array( 312, '' ),  // _SAB4130.jpg
					array( 313, '' ),  // _SAB4131.jpg
					array( 311, '' ),  // _SAB4125.jpg
					array( 314, '' ),  // _SAB4137.jpg
					array( 315, '' ),  // _SAB4139.jpg
				),
			),
		),

		'energia' => array(
			'h1'   => 'ENERGIA',
			'dest' => 'market:energia',
			'g1'   => array(
				'etichetta' => 'PRODOTTI',
				'elenco'    => 'ruota Pelton, valvole',
				'img'       => array(
					array( 389, 'Ruota Pelton' ),  // _SAB1104.jpg
					array( 388, 'Ruota Pelton' ),  // _SAB1101.jpg
					array( 390, 'Ruota Pelton' ),  // _SAB1110.jpg
					array( 395, 'Valvola a Farfalla VF1' ),  // valvola+a+farfalla+vf1.PNG
					array( 396, 'Valvola a Farfalla VF2' ),  // valvola+a+farfalla+vf2.PNG
					array( 397, 'Valvola Sferica' ),  // valvola+sferica.PNG
				),
			),
			'g2'   => array(
				'etichetta' => 'LAVORAZIONE',
				'elenco'    => 'revisione',
				'img'       => array(
					array( 391, '' ),  // _SAB1113.jpg
					array( 392, '' ),  // _SAB1117.jpg
					array( 393, '' ),  // _SAB1120.jpg
					array( 394, '' ),  // _SAB1194.jpg
					array( 387, '' ),  // _SAB0054.jpg
				),
			),
		),
	);
}

/**
 * Dallo slug WordPress alla chiave della mappa legacy.
 *
 * Quattro slug su cinque coincidono. UNO DIVERGE: la pagina legacy
 * "metalmeccanica" e' ospitata in WordPress su una capability che si chiama
 * "lavorazioni-meccaniche". La corrispondenza si dichiara qui, una volta, invece
 * di lasciarla indovinare a chi legge — o peggio, di rinominare uno slug
 * pubblico per far combaciare il codice.
 *
 * @param string $slug Slug WordPress.
 * @return string Chiave nella mappa legacy, o '' se non e' una pagina area.
 */
function tenconi_legacy_area_chiave( $slug ) {

	$alias = array(
		'lavorazioni-meccaniche' => 'metalmeccanica',
	);

	$slug = isset( $alias[ $slug ] ) ? $alias[ $slug ] : (string) $slug;

	return array_key_exists( $slug, tenconi_legacy_aree_media() ) ? $slug : '';
}
