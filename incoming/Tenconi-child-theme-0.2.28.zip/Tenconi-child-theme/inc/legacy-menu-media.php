<?php
/**
 * MAPPA LEGACY delle pagine del menu ricostruite in questa fase.
 *
 * Generata dal sorgente in cache, un'immagine per identificativo Squarespace e non
 * per nome file. Le didascalie vengono dall'attributo alt del legacy e gli alt che
 * sono nomi di file vengono scartati: nella seconda galleria di alcune pagine
 * Squarespace ci aveva messo il filename.
 *
 * DIREZIONE E TEAM sono pagine di sole fotografie, senza testo: le didascalie
 * portano nome e ruolo, ed e' tutto il contenuto che il legacy aveva. Non si
 * aggiunge testo per riempirle.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function tenconi_legacy_menu_media() {

	return array(

		'direzione' => array(
			'titolo' => 'Direzione e CdA',
			'testo'  => array(
			),
			'img'    => array(
				array( 385, 'Michele Beffa, CEO' ),  // michele.jpg
				array( 339, 'Fabrizio Lucchini, Sales' ),  // _SAB3102.jpg
				array( 381, 'Radovan Grebic, COO' ),  // _09A1346-mod.jpg
				array( 384, 'Giovanni Leonardi, Presidente CdA' ),  // _SAB5877.jpg
				array( 383, 'Silvano Beffa, Vice Presidente CdA' ),  // _SAB5858.JPG
				array( 382, 'Avvocato Mario Molo, Membro CdA' ),  // _SAB5838.jpg
			),
		),

		'team' => array(
			'titolo' => 'Team',
			'testo'  => array(
			),
			'img'    => array(
				array( 668, 'Rossana Tomasetti Giacomelli, Vendita' ),  // _SAB3240.jpg
				array( 670, 'Angelo Baglioni, Offerte e Acquisiti' ),  // _SAB5616.jpg
				array( 669, 'Flavio Beresini, Ufficio Tecnico' ),  // _SAB3283.jpg
				array( 666, 'Francesco Prudente, Risorse Umane' ),  // _SAB3198.jpg
				array( 667, 'Marco Brocco, Responsabile Alluminio' ),  // _SAB3222.jpg
				array( 671, 'Mirco Panigada, Produzione Airolo' ),  // _SAB5679.jpg
				array( 672, 'Stefano Borghese, Qualità Produzione' ),  // _SAB5714.jpg
			),
		),

		'150esimo' => array(
			'titolo' => '150esimo',
			'testo'  => array(
				array( 'h2', '“Tenconi centocinquant’anni in Leventina”
Libro commemorativo per i 150 anni dalla fondazione' ),
				array( 'p', 'Il libro è in vendita al prezzo di favore di CHF 20.- e può essere richiesto presso l’editore Salvioni Edizioni (www.salvioni.ch / 091 821 11 11), oppure acquistato direttamente presso la Ditta Tenconi o nelle migliori librerie ticinesi.' ),
				array( 'li', 'Anteprima libro' ),
				array( 'p', 'Ambrogio Tenconi (al centro), Airolo 1871' ),
				array( 'p', 'Per festeggiare il 150esimo anniversario della Ditta, la TENCONI SA ha previsto, nel corso dei mesi di settembre e ottobre, le seguenti manifestazioni:' ),
				array( 'p', 'Gita aziendale con tutti i collaboratori sul Monte Generoso (3 settembre)' ),
				array( 'p', 'Porte aperte presso le sedi di Airolo (25 settembre) e Cadenazzo (9 ottobre)' ),
				array( 'p', 'Sabato 25 settembre e sabato 9 ottobre abbiamo avuto il piacere di aprire le porte delle nostre sedi di Airolo e Cadenazzo alla popolazione.
Un evento unico nel suo genere, che ha richiamato diverse persone interessate alle attività e alla storia della TENCONI. 
Un ringraziamento speciale va a tutti coloro che sono venuti a trovarci (grandi e piccini) e si sono calati per un giorno nella realtà TENCONI e a tutti i collaboratori che si sono messi a disposizione per la buona riuscita dell’evento.' ),
				array( 'p', 'Serata commemorativa (30 settembre)' ),
				array( 'p', 'La Tenconi SA è nata ad Airolo nel 1871 dalla passione di Ambrogio Tenconi che, consapevole delle opportunità di lavoro legate al traforo ferroviario del San Gottardo, si era trasferito in Leventina dalla allora lontana Menzago di Sumirago (in terra Lombarda a suo tempo sotto la dominazione austriaca). 
Questa passione, abbinata a diversi decenni di forte crescita economica in Leventina, ha permesso alla Tenconi SA di svilupparsi nel tempo e di espandere le proprie attività ben oltre quelle iniziali di fabbro-ferraio e notevolmente al di là dei confini della Valle.' ),
				array( 'p', 'Ambrogio Tenconi sposò Angela Tubino nel luglio del 1855. La coppia ebbe sei figli maschi e due femmine: Camillo (1856-1923), Domenico (1859-1929), Faustino (1871-1948), Guglielmo (1880-1951), Emilio (1885-1961), Enrico, emigrato in Argentina e di cui non si conoscono i dati personali, Amalia (morta nel 1914) e Lisa, ambedue sposate e residenti pure in Argentina.' ),
				array( 'p', 'Lisa Tenconi e figli in Argentina' ),
				array( 'p', 'Guglielmo e Giuseppina Tenconi a Venezia' ),
				array( 'p', 'Fausto (1912-1986) ed Edoardo Tenconi (1905-1992), figli di Guglielmo (1880-1951) e nipoti del fondatore Ambrogio Tenconi, rilevano l’azienda paterna nel 1943 e la dirigono per mezzo secolo favorendone l’espansione con diversi importanti investimenti in macchinari e stabili di produzione nonché amministrativi. È durante la loro conduzione che nasce il logo FTA (Fratelli Tenconi Airolo) ancor’oggi utilizzato per la marchiatura dei prodotti. Con la scomparsa di Fausto e Edoardo, la ragione sociale cambia nel 1992 in TENCONI SA.' ),
				array( 'p', 'Fausto Tenconi' ),
				array( 'p', 'Edoardo Tenconi' ),
				array( 'p', 'Oggi la Tenconi SA, che festeggia il suo 150esimo anniversario, raggruppa delle attività metalmeccaniche suddivise in quattro distinti settori economici (ferrovia, carpenteria metallica, industria metalmeccanica ed energia) con un’espansione in 19 nazioni su quattro continenti. La Tenconi SA è orgogliosa di aver potuto offrire un notevole contributo allo sviluppo del paese di Airolo e della Leventina, assicurando nei decenni posti di lavoro e sostentamento a centinaia di famiglie.' ),
				array( 'p', 'La seconda sede della Ditta Tenconi' ),
				array( 'p', 'Realizzazione delle nuove strutture produttive ad Airolo negli anni Cinquanta' ),
				array( 'p', 'I nuovi stabilimenti produttivi realizzati ad Airolo negli anni Cinquanta' ),
				array( 'p', 'Non sono ovviamente mancate le sfide dettate da cicli economici, malattie/pandemie, guerre, intemperie e alcune rivalità di paese; ma con tenacia e perseveranza la Tenconi SA è rimasta una ditta di famiglia e ancor oggi annovera rappresentanti della quinta generazione nella sua conduzione.' ),
				array( 'p', 'Matrimonio di Lina e Fausto Tenconi' ),
				array( 'p', 'Famiglia Lina e Fausto Tenconi' ),
				array( 'p', 'La gestione famigliare, legata ai solidi principi del rispetto reciproco, alla generosità, alla tenacia, alla perseveranza e non da ultimo a un’attenzione particolare alla qualità dei propri prodotti, ha dimostrato nel tempo di essere una carta vincente e un punto di differenziazione rispetto a ad altre ditte. A questo si aggiunge un elemento imprenditoriale, trasferito da generazione in generazione, che ha spinto la Tenconi SA a reinvestire regolarmente in competenze interne e diversificare la produzione in settori similari o adiacenti al proprio e a espandersi geograficamente, sia con la produzione, sia con la vendita.' ),
				array( 'p', 'Eredi Tenconi' ),
				array( 'p', 'La Tenconi SA continua anche a distinguersi per il suo operato a favore del singolo e della comunità. Da sempre la ditta offre condizioni di favore per i suoi collaboratori a livello salariale, pensionistico, di formazione professionale, di vitto e di alloggio. Inoltre, fornisce a livello locale un regolare supporto a società sportive o con un indirizzo sociale e culturale.' ),
				array( 'p', 'Fausto Tenconi con i rappresentanti delle FFS 20° circondario ad Airolo, 1972' ),
				array( 'p', 'Fausto Tenconi nel 30° della gestione dei fratelli Edoardo e Fausto Tenconi' ),
				array( 'p', 'Per il prossimo futuro si intravede una continuazione dell’espansione e della diversificazione produttiva, sempre restando fedeli a riconosciute competenze tecnico/operative e alla cultura aziendale di stampo familiare. Nello specifico:' ),
				array( 'li', 'Competenze che includono le forti conoscenze dei materiali ferrosi e plastici, delle lavorazioni meccaniche, dei processi di saldatura e di assiemaggio di opere di metal costruzione;' ),
				array( 'li', 'Una cultura interna caratterizzata da una gestione familiare, impostata sui principi del rispetto reciproco, della qualità, dell’affidabilità e del servizio.' ),
				array( 'p', 'Nelle sfide dettate dalla globalizzazione, dall’innovazione tecnologica e dalla digitalizzazione, la Tenconi SA rimarrà fedele anche nella rinnovata struttura societaria di “Gruppo Tenconi” al proprio obiettivo, finalizzato a creare valore aggiunto per i nostri partner commerciali con prodotti di nicchia innovativi e di alta qualità, coadiuvato da un costante dialogo tecnico e innovativo.' ),
				array( 'p', 'Da sinistra a destra: Silvano Beffa, Cristina Beffa, Matteo Lunini, Francesco Lunini, Elena Lunini, Fausta Forni, Paola Gabutti (Forni), Giovanna Forni Favini, Fabio Lucchini, Michele Beffa' ),
				array( 'p', 'Direzione' ),
				array( 'p', 'Dal documento emerge anche la difficile situazione della Ditta Tenconi durante la crisi economica degli anni Trenta.' ),
			),
			'img'    => array(
				array( 198, '' ),  // 9R3A1856OK.JPG
				array( 178, 'Ambrogio Tenconi (al centro), Airolo 1871' ),  // 1.jpg
				array( 204, '' ),  // DSC_0067.JPG
				array( 203, '' ),  // DSC_0066.JPG
				array( 205, '' ),  // DSC_0071_1.JPG
				array( 206, '' ),  // DSC_0075.JPG
				array( 207, '' ),  // DSC_0077.JPG
				array( 208, '' ),  // DSC_0079.JPG
				array( 209, '' ),  // DSC_0084.JPG
				array( 210, '' ),  // DSC_0092.JPG
				array( 211, '' ),  // DSC_0093.JPG
				array( 212, '' ),  // DSC_0095.JPG
				array( 213, '' ),  // DSC_0097.JPG
				array( 214, '' ),  // DSC_0102.JPG
				array( 215, '' ),  // DSC_0104.JPG
				array( 216, '' ),  // DSC_0107.JPG
				array( 217, '' ),  // DSC_0111.JPG
				array( 218, '' ),  // DSC_0117.JPG
				array( 219, '' ),  // DSC_0171.jpg
				array( 220, '' ),  // DSC_0172.jpg
				array( 221, '' ),  // DSC_0174.jpg
				array( 222, '' ),  // DSC_0180.jpg
				array( 223, '' ),  // DSC_0182.jpg
				array( 224, '' ),  // DSC_0185.jpg
				array( 225, '' ),  // DSC_0187.jpg
				array( 226, '' ),  // DSC_0188.jpg
				array( 227, '' ),  // DSC_0191.jpg
				array( 228, '' ),  // DSC_0193.jpg
				array( 229, '' ),  // DSC_0194.jpg
				array( 230, '' ),  // DSC_0197.jpg
				array( 231, '' ),  // DSC_0200.jpg
				array( 232, '' ),  // DSC_0209.jpg
				array( 187, '' ),  // 9R3A1291OK.JPG
				array( 188, '' ),  // 9R3A1298OK.JPG
				array( 189, '' ),  // 9R3A1323OK.JPG
				array( 190, '' ),  // 9R3A1354OK.JPG
				array( 191, '' ),  // 9R3A1368OK.JPG
				array( 192, '' ),  // 9R3A1491OK.JPG
				array( 193, '' ),  // 9R3A1526OK.JPG
				array( 194, '' ),  // 9R3A1573OK.JPG
				array( 195, '' ),  // 9R3A1580OK.JPG
				array( 196, '' ),  // 9R3A1610OK.JPG
				array( 197, '' ),  // 9R3A1621OK.JPG
				array( 198, '' ),  // 9R3A1856OK.JPG
				array( 199, '' ),  // 9R3A1876OK.JPG
				array( 200, '' ),  // 9R3A1885OK.JPG
				array( 201, '' ),  // 9R3A1900OK.JPG
				array( 202, '' ),  // 9R3A1909OK.JPG
				array( 182, 'Lisa Tenconi e figli in Argentina' ),  // 4.jpg
				array( 184, 'Guglielmo e Giuseppina Tenconi a Venezia' ),  // 6.jpg
				array( 255, 'Fausto Tenconi' ),  // foto+Faustino.jpg
				array( 185, 'Edoardo Tenconi' ),  // 7.jpg
				array( 183, 'La seconda sede della Ditta Tenconi' ),  // 5.jpg
				array( 186, 'Realizzazione delle nuove strutture produttive ad Airolo negli anni Cinquanta' ),  // 9.jpg
				array( 179, 'I nuovi stabilimenti produttivi realizzati ad Airolo negli anni Cinquanta' ),  // 10.jpg
				array( 234, 'Matrimonio di Lina e Fausto Tenconi' ),  // MATRIMONIO.jpg
				array( 235, 'Famiglia Lina e Fausto Tenconi' ),  // MEDEA%2B1%2B%25281%2529.jpg
				array( 236, 'Eredi Tenconi' ),  // MEDEA%2B2.jpg
				array( 180, 'Fausto Tenconi con i rappresentanti delle FFS 20° circondario ad Airolo, 1972' ),  // 11.jpg
				array( 181, 'Fausto Tenconi nel 30° della gestione dei fratelli Edoardo e Fausto Tenconi' ),  // 12.jpg
				array( 237, 'Da sinistra a destra: Silvano Beffa, Cristina Beffa, Matteo Lunini, Francesco Lunini, Elena Lunini, Fausta Forni, Paola Gabutti (Forni), Giovanna Forni Favini, Fabio Lucchini, Michele Beffa' ),  // SAZ_2946ook.jpg
				array( 256, 'Direzione' ),  // foto+dir.PNG
				array( 238, 'Raccolta della segale a Villa (Valle Bedretto).' ),  // doc16211820210412132827_002.jpg
				array( 239, 'Cappella situata lungo la strada che conduce al Dazio Grande.' ),  // doc16212020210412132907_002.jpg
				array( 240, 'Guglielmo Tenconi.' ),  // doc16212920210412133407_001.jpg
				array( 241, 'Il garage della Ditta Tenconi.' ),  // doc16213120210412133541_001.jpg
				array( 242, 'Negli anni successivi alla Prima guerra mondiale, la Ditta Tenconi offriva ai turisti anche un "servizio taxi con vetture di lusso".' ),  // doc16213220210412133558_001.jpg
				array( 243, 'L\'Officina.' ),  // doc16213320210412133614_001.jpg
				array( 244, 'Contratto di locazione dei terreni in prossimità della stazione FFS, 30 dicembre 1938.' ),  // doc16213420210412133845_001.jpg
				array( 245, 'Pubblicità dei "Campani del Gottardo", brevettati nel 1948.' ),  // doc16215120210412160953_001.jpg
				array( 246, 'Piantina delle proprietà ad Airolo della Ditta Fratelli Tenconi negli anni Sessanta.' ),  // doc16215520210412161213_001.jpg
				array( 247, 'Realizzazione delle nuove strutture produttive ad Airolo negli anni Cinquanta.' ),  // doc16215720210412161250_001.jpg
				array( 248, 'I nuovi stabilimenti produttivi realizzati ad Airolo negli anni Cinquanta.' ),  // doc16216020210412161335_001.jpg
				array( 249, '' ),  // doc16216320210412161428_001.jpg
				array( 250, 'Fausto Tenconi con i rappresentanti delle FFS 20° circondario ad Airolo, 1972' ),  // doc16216420210412161513_001.jpg
				array( 251, 'Fausto Tenconi con i rappresentanti delle FFS ad Airolo, 1972.' ),  // doc16216520210412161531_001.jpg
				array( 253, 'La banda sfila in prossimità dei capannoni della Ditta. Anni Settanta.' ),  // doc16216720210412161619_001.jpg
				array( 252, 'Fausto Tenconi nel 30° della gestione dei fratelli Edoardo e Fausto Tenconi' ),  // doc16216620210412161601_001.jpg
				array( 254, 'Seduta del Consiglio di Amministrazione, 18 marzo 2005.' ),  // doc16216820210412161735_001.jpg
			),
		),

		'supporto' => array(
			'titolo' => 'Tecnologia e servizi di supporto',
			'testo'  => array(
				array( 'p', 'La Tenconi SA mantiene un Sistema di Gestione Integrato (SGI) aggiornato, che rispetta i requisiti e le disposizioni delle norme ISO 9001 / ISO 14001, assicurando il miglioramento continuo delle prestazioni aziendali, dei processi e dei prodotti.' ),
				array( 'p', 'Le certificazioni specifiche di saldatura (ISO 3834-2, EN 1090-1, EN 1090-2, EN 15085-2) e le omologazioni dei vari prodotti nel settore ferroviario presso le più rinomate ferrovie nazionali, ne attestano l’alto livello di qualità e di conformità.' ),
				array( 'h2', 'UFFICIO TECNICO' ),
				array( 'h2', 'CONTROLLO QUALITÀ' ),
				array( 'h2', 'MENSA' ),
				array( 'p', 'Da oltre 60 anni Tenconi SA offre ai suoi collaboratori la possibilità, durante i giorni lavorativi, di consumare i pasti principali nella mensa aziendale, a prezzi di favore. Il team è composto dallo chef Manfred Schalbetter che con l’aiuto di Monica e Lourdes preparano menu e pasti equilibrati, ponendo particolare attenzione alla genuinità, provenienza locale e stagionalità dei prodotti. Una saletta dedicata ai nostri invitati permette di gustare menu speciali, pur restando in azienda.' ),
			),
			'img'    => array(
				array( 683, '' ),  // _SAB9900.jpg
				array( 682, '' ),  // _SAB9891.jpg
				array( 681, '' ),  // _SAB9884.jpg
				array( 685, '' ),  // _SAB9905.jpg
				array( 686, '' ),  // _SAB9915.jpg
				array( 684, '' ),  // _SAB9903.jpg
				array( 676, '' ),  // _SAB0118.jpg
				array( 674, '' ),  // _SAB0110.jpg
				array( 675, '' ),  // _SAB0113.jpg
				array( 677, '' ),  // _SAB0143.jpg
				array( 673, '' ),  // _SAB0084.jpg
				array( 678, '' ),  // _SAB5558.jpg
				array( 679, '' ),  // _SAB5726.jpg
				array( 680, '' ),  // _SAB5733.jpg
			),
		),

		'condizioni-di-vendita' => array(
			'titolo' => 'Condizioni di vendita',
			'testo'  => array(
				array( 'p', 'Condizioni generali di fornitura della TENCONI SA' ),
				array( 'p', 'General conditions of contract for the supply of TENCONI SA' ),
				array( 'p', 'Allgemeine Lieferbedingungen der TENCONI SA' ),
				array( 'p', 'Conditions générales de livraison de la TENCONI SA' ),
			),
			'img'    => array(
			),
		),

		'certificazioni' => array(
			'titolo' => 'Certificazioni',
			'testo'  => array(
				array( 'p', 'Certificati di qualità e ambiente:' ),
				array( 'p', 'IQNET ISO 9001 / 14001 (English)' ),
				array( 'p', 'ISO 9001 / 14001 (Italiano)
ISO 9001 / 14001 (English)
ISO 9001 / 14001 (Deutsch)
ISO 9001 / 14001 (Français)' ),
				array( 'p', 'Certificati di saldatura:' ),
				array( 'p', 'ISO 3834-2 (Italiano)
ISO 3834-2 (English)' ),
				array( 'p', 'EN 1090-1 (Italiano)
EN 1090-1 (English)' ),
				array( 'p', 'EN 1090-2 (Italiano)
EN 1090-2 (English)' ),
				array( 'p', 'EN 15085-2 CL1 Airolo (Italiano)
EN 15085-2 CL1 Airolo (English)' ),
				array( 'p', 'EN 15085-2 CL1 Cadenazzo (Italiano)
EN 15085-2 CL1 Cadenazzo (English)' ),
				array( 'p', 'DB Zulassung HPQ' ),
				array( 'p', 'DUN&BRADSTREET Rating Certificate' ),
			),
			'img'    => array(
				array( 321, '' ),  // logo_0.png
				array( 321, '' ),  // logo_0.png
				array( 322, '' ),  // svs+x+ass.PNG
				array( 322, '' ),  // svs+x+ass.PNG
				array( 322, '' ),  // svs+x+ass.PNG
				array( 322, '' ),  // svs+x+ass.PNG
				array( 330, '' ),  // download.png
				array( 329, '' ),  // download+(1).png
				array( 318, '' ),  // Immagine+2025-12-02+145200.gif
				array( 328, '' ),  // EcoVadis2025.png
				array( 317, '' ),  // FondazionePremioSwissEngineeringTicino_page-0001.jpg
			),
		),

		/*
		 * CHI SIAMO e' un caso misto e va detto: il TESTO e' gia' corretto nel CMS
		 * (1237 caratteri) e resta li', modificabile dal committente; le IMMAGINI
		 * invece nel database non c'erano affatto, mentre il legacy ne aveva undici.
		 * Quindi 'cms' => true per il testo e la lista qui sotto per le fotografie.
		 *
		 * Sono fotografie storiche di formati diversi — cartoline, ritratti d'epoca,
		 * la carta della Svizzera — quindi niente ritaglio comune: ognuna tiene il
		 * proprio rapporto, come su Direzione e Team.
		 */
		/*
		 * CHI SIAMO e' l'unica pagina con la galleria a scorrimento: nel legacy
		 * le dieci fotografie d'archivio stavano in un carosello con la striscia
		 * di miniature, non in griglia. La carta delle sedi invece NON e' una
		 * fotografia storica ed e' sempre stata una sezione a se': in mezzo alle
		 * altre diventava una piastrella piccola e senza titolo.
		 */
		'chi-siamo' => array(
			'titolo'   => 'Chi siamo',
			'cms'      => true,
			'testo'    => array(),
			'galleria' => 'Un po\' della nostra storia...',
			'img'      => array(
				array( 334, '' ),  // Pittura FTA_parete TPF_P0004714.JPG
				array( 323, '' ),  // 1973.jpg
				array( 325, '' ),  // Ambr.1131.jpg
				array( 336, '' ),  // cart. Airolo 1957.JPG
				array( 331, '' ),  // P0004715.JPG
				array( 327, '' ),  // DSC06784.JPG
				array( 333, '' ),  // P0004720.JPG
				array( 326, '' ),  // DSC06772.JPG
				array( 332, '' ),  // P0004717.JPG
				array( 324, '' ),  // 1986.jpg
			),
			'sedi'     => array(
				'titolo' => 'Le nostre sedi',
				'att'    => 335,  // Svizzera1ok.png — la carta con Airolo e Cadenazzo
			),
		),
	);
}

