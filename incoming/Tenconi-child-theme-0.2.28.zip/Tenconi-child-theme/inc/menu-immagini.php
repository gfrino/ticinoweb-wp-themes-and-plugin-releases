<?php
/**
 * IMMAGINI DEL MEGA MENU, MODIFICABILI DAL BACKEND.
 *
 * Ogni scheda del menu prende la sua immagine da un posto che il cliente trova
 * da solo, e il posto e' quello della cosa a cui la voce porta:
 *
 *   pagina      -> "Immagine in evidenza" della pagina (editor di WordPress)
 *   settore     -> campo "Immagine nel menu" nella scheda del settore
 *                  (Settori -> modifica)
 *   archivio    -> voce "Immagine nel menu" nel menu laterale di quel tipo di
 *                  contenuto (Parco macchine, Progetti e referenze,
 *                  Certificazioni)
 *
 * Se il posto e' vuoto la scheda usa l'immagine scelta finora
 * (tenconi_mega_sorgenti): togliere un'immagine non lascia mai un buco.
 *
 * I valori sono ID di allegati salvati nel database (term meta e opzioni), mai
 * nel codice.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** La tassonomia dei settori. */
const TENCONI_MENU_IMG_TAX = 'market';

/** La chiave dell'immagine, nel term meta dei settori. */
const TENCONI_MENU_IMG_META = 'tenconi_menu_img';

/**
 * I tipi di contenuto il cui archivio e' una voce del menu.
 *
 * @return string[]
 */
function tenconi_menu_img_archivi() {
	return array( 'machine', 'project', 'certification' );
}

/**
 * L'opzione che tiene l'immagine dell'archivio di un tipo di contenuto.
 *
 * @param string $tipo Tipo di contenuto.
 * @return string
 */
function tenconi_menu_img_opzione( $tipo ) {
	return 'tenconi_menu_img_' . sanitize_key( $tipo );
}

/**
 * L'immagine scelta nel backend per la destinazione di una voce, oppure 0.
 *
 * Pagina, settore o archivio, nell'ordine. Il risultato si tiene per tutta la
 * richiesta: le stesse diciassette voci passano dal menu desktop e da quello
 * del telefono.
 *
 * @param string $url Indirizzo della destinazione.
 * @return int
 */
function tenconi_menu_img_da_backend( $url ) {

	static $cache = array();
	$url = (string) $url;
	if ( '' === $url ) {
		return 0;
	}
	if ( isset( $cache[ $url ] ) ) {
		return $cache[ $url ];
	}

	$id      = 0;
	$post_id = url_to_postid( $url );
	if ( $post_id && 'publish' === get_post_status( $post_id ) ) {
		$id = (int) get_post_thumbnail_id( $post_id );
	} else {
		$percorso = trim( (string) wp_parse_url( $url, PHP_URL_PATH ), '/' );

		$tax = get_taxonomy( TENCONI_MENU_IMG_TAX );
		if ( $tax && ! empty( $tax->rewrite['slug'] ) ) {
			/* "settori/energia" anche dentro un sito in sottocartella: "tenconi/settori/energia". */
			$base = '/' . trim( $tax->rewrite['slug'], '/' ) . '/';
			if ( false !== strpos( '/' . $percorso . '/', $base ) ) {
				$termine = get_term_by( 'slug', basename( $percorso ), TENCONI_MENU_IMG_TAX );
				if ( $termine ) {
					$id = (int) get_term_meta( $termine->term_id, TENCONI_MENU_IMG_META, true );
				}
			}
		}

		if ( ! $id ) {
			foreach ( tenconi_menu_img_archivi() as $tipo ) {
				$archivio = get_post_type_archive_link( $tipo );
				if ( ! $archivio ) {
					continue;
				}
				$p_archivio = trim( (string) wp_parse_url( $archivio, PHP_URL_PATH ), '/' );
				if ( '' !== $p_archivio && $p_archivio === $percorso ) {
					$id = (int) get_option( tenconi_menu_img_opzione( $tipo ), 0 );
					break;
				}
			}
		}
	}

	if ( $id && ! wp_attachment_is_image( $id ) ) {
		$id = 0;
	}

	$cache[ $url ] = $id;
	return $id;
}

/* --------------------------------------------------------------------------
   BACKEND: il selettore d'immagine, uguale nei due posti
   -------------------------------------------------------------------------- */

/**
 * Il selettore: anteprima, "Scegli immagine", "Rimuovi".
 *
 * @param string $nome   Nome del campo nascosto.
 * @param int    $img_id Allegato attuale.
 */
function tenconi_menu_img_selettore( $nome, $img_id ) {
	$img_id = (int) $img_id;
	?>
	<div class="tenconi-menu-img" data-tenconi-menu-img>
		<div class="tenconi-menu-img__anteprima" style="margin-bottom:8px;">
			<?php
			if ( $img_id ) {
				echo wp_get_attachment_image( $img_id, 'medium', false, array( 'style' => 'max-width:300px;height:auto;display:block;' ) );
			}
			?>
		</div>
		<input type="hidden" name="<?php echo esc_attr( $nome ); ?>" value="<?php echo esc_attr( $img_id ? $img_id : '' ); ?>" data-tenconi-menu-img-campo />
		<button type="button" class="button" data-tenconi-menu-img-scegli><?php esc_html_e( 'Scegli immagine', 'tenconi-child-theme' ); ?></button>
		<button type="button" class="button-link button-link-delete" data-tenconi-menu-img-rimuovi<?php echo $img_id ? '' : ' hidden'; ?> style="margin-left:8px;"><?php esc_html_e( 'Rimuovi', 'tenconi-child-theme' ); ?></button>
		<p class="description"><?php esc_html_e( "È l'immagine della scheda nel menu principale. Se la togli, la scheda torna all'immagine predefinita.", 'tenconi-child-theme' ); ?></p>
	</div>
	<?php
}

/**
 * Lo script del selettore, solo nelle schermate dove serve.
 *
 * @param string $hook Schermata dell'amministrazione.
 */
function tenconi_menu_img_script( $hook ) {
	$schermo = get_current_screen();
	$serve   = ( $schermo && TENCONI_MENU_IMG_TAX === $schermo->taxonomy && in_array( $hook, array( 'edit-tags.php', 'term.php' ), true ) )
		|| false !== strpos( (string) $hook, 'tenconi-menu-img' );
	if ( ! $serve ) {
		return;
	}
	wp_enqueue_media();
	wp_enqueue_script(
		'tenconi-menu-img',
		tenconi_asset_uri( 'assets/js/admin-menu-img.js' ),
		array( 'jquery' ),
		tenconi_asset_version( 'assets/js/admin-menu-img.js' ),
		true
	);
	wp_localize_script(
		'tenconi-menu-img',
		'tenconiMenuImg',
		array(
			'titolo'   => __( "Immagine nel menu", 'tenconi-child-theme' ),
			'pulsante' => __( 'Usa questa immagine', 'tenconi-child-theme' ),
		)
	);
}
add_action( 'admin_enqueue_scripts', 'tenconi_menu_img_script' );

/* --------------------------------------------------------------------------
   SETTORI: il campo nella scheda del settore
   -------------------------------------------------------------------------- */

/**
 * Il campo nella schermata "Modifica settore".
 *
 * @param WP_Term $termine Settore.
 */
function tenconi_menu_img_campo_settore( $termine ) {
	?>
	<tr class="form-field">
		<th scope="row"><?php esc_html_e( 'Immagine nel menu', 'tenconi-child-theme' ); ?></th>
		<td>
			<?php wp_nonce_field( 'tenconi_menu_img_settore', 'tenconi_menu_img_nonce' ); ?>
			<?php tenconi_menu_img_selettore( 'tenconi_menu_img', (int) get_term_meta( $termine->term_id, TENCONI_MENU_IMG_META, true ) ); ?>
		</td>
	</tr>
	<?php
}
add_action( TENCONI_MENU_IMG_TAX . '_edit_form_fields', 'tenconi_menu_img_campo_settore' );

/**
 * Salva l'immagine del settore.
 *
 * @param int $term_id Settore.
 */
function tenconi_menu_img_salva_settore( $term_id ) {
	if ( ! isset( $_POST['tenconi_menu_img_nonce'] )
		|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['tenconi_menu_img_nonce'] ) ), 'tenconi_menu_img_settore' )
		|| ! current_user_can( 'edit_term', $term_id ) ) {
		return;
	}
	$img = isset( $_POST['tenconi_menu_img'] ) ? absint( $_POST['tenconi_menu_img'] ) : 0;
	if ( $img && wp_attachment_is_image( $img ) ) {
		update_term_meta( $term_id, TENCONI_MENU_IMG_META, $img );
	} else {
		delete_term_meta( $term_id, TENCONI_MENU_IMG_META );
	}
}
add_action( 'edited_' . TENCONI_MENU_IMG_TAX, 'tenconi_menu_img_salva_settore' );

/* --------------------------------------------------------------------------
   ARCHIVI: "Immagine nel menu" sotto ogni tipo di contenuto
   -------------------------------------------------------------------------- */

/** Le pagine "Immagine nel menu", una per tipo di contenuto. */
function tenconi_menu_img_pagine() {
	foreach ( tenconi_menu_img_archivi() as $tipo ) {
		$oggetto = get_post_type_object( $tipo );
		if ( ! $oggetto ) {
			continue;
		}
		add_submenu_page(
			'edit.php?post_type=' . $tipo,
			__( 'Immagine nel menu', 'tenconi-child-theme' ),
			__( 'Immagine nel menu', 'tenconi-child-theme' ),
			$oggetto->cap->edit_others_posts,
			'tenconi-menu-img-' . $tipo,
			function () use ( $tipo ) {
				tenconi_menu_img_pagina( $tipo );
			}
		);
	}
}
add_action( 'admin_menu', 'tenconi_menu_img_pagine' );

/**
 * La pagina "Immagine nel menu" di un tipo di contenuto.
 *
 * @param string $tipo Tipo di contenuto.
 */
function tenconi_menu_img_pagina( $tipo ) {
	$oggetto = get_post_type_object( $tipo );
	if ( ! $oggetto || ! current_user_can( $oggetto->cap->edit_others_posts ) ) {
		return;
	}
	$salvato = false;
	if ( isset( $_POST['tenconi_menu_img_nonce'] )
		&& wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['tenconi_menu_img_nonce'] ) ), 'tenconi_menu_img_' . $tipo ) ) {
		$img = isset( $_POST['tenconi_menu_img'] ) ? absint( $_POST['tenconi_menu_img'] ) : 0;
		if ( $img && wp_attachment_is_image( $img ) ) {
			update_option( tenconi_menu_img_opzione( $tipo ), $img, false );
		} else {
			delete_option( tenconi_menu_img_opzione( $tipo ) );
		}
		$salvato = true;
	}
	?>
	<div class="wrap">
		<h1>
			<?php
			/* translators: %s: nome del tipo di contenuto, es. "Parco macchine". */
			echo esc_html( sprintf( __( '%s: immagine nel menu', 'tenconi-child-theme' ), $oggetto->labels->name ) );
			?>
		</h1>
		<?php if ( $salvato ) : ?>
			<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Immagine salvata. Se online non la vedi subito, svuota la cache.', 'tenconi-child-theme' ); ?></p></div>
		<?php endif; ?>
		<p>
			<?php
			/* translators: %s: nome del tipo di contenuto. */
			echo esc_html( sprintf( __( 'Questa immagine compare nella scheda "%s" del menu principale.', 'tenconi-child-theme' ), $oggetto->labels->name ) );
			?>
		</p>
		<form method="post">
			<?php wp_nonce_field( 'tenconi_menu_img_' . $tipo, 'tenconi_menu_img_nonce' ); ?>
			<?php tenconi_menu_img_selettore( 'tenconi_menu_img', (int) get_option( tenconi_menu_img_opzione( $tipo ), 0 ) ); ?>
			<?php submit_button( __( 'Salva', 'tenconi-child-theme' ) ); ?>
		</form>
	</div>
	<?php
}
