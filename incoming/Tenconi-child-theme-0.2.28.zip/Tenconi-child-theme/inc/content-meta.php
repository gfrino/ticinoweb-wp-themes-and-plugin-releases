<?php
/**
 * Meta della migrazione: registrazione, helper di lettura, badge di stato.
 *
 * Nessuna dipendenza da ACF. Le chiavi sono piatte e con prefisso `_tcm_`, cosi'
 * che ACF, quando verra' attivato, possa adottarle senza migrare i dati.
 *
 * Le chiavi sono protette (prefisso underscore): non compaiono nel pannello
 * "Campi personalizzati" e non sono modificabili per errore dall'editor. Sono
 * invece esposte a REST in sola lettura per gli amministratori, cosi' che
 * Gutenberg e gli strumenti di verifica possano leggerle.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Gli stati del testo. Tre valori, nessun altro ammesso.
 *
 * @return array
 */
function tenconi_text_states() {
	return array(
		'complete'    => 'Completo',
		'partial'     => 'Parziale — da completare',
		'placeholder' => 'Segnaposto — da redigere',
	);
}

/**
 * I tipi di contenuto che portano i meta della migrazione.
 *
 * @return array
 */
function tenconi_migrated_types() {
	return array( 'page', 'product', 'capability', 'machine', 'project', 'certification', 'document', 'job' );
}

/**
 * Registra i meta della migrazione.
 *
 * @return void
 */
function tenconi_register_meta() {
	$campi = array(
		'_tcm_key'             => 'string',
		'_tcm_source_url'      => 'string',
		'_tcm_source_language' => 'string',
		'_tcm_text_state'      => 'string',
		'_tcm_legacy_text'     => 'string',
		'_tcm_migrated_at'     => 'string',
		'_tcm_run_id'          => 'string',
		'_tcm_legacy_slug'     => 'string',
		'_tcm_text_chars'      => 'integer',
		'_tcm_completeness'    => 'integer',
		'_tcm_conflicts'       => 'string',
		'_tcm_source_url_en'   => 'string',
		'_tcm_source_url_de'   => 'string',
		'_tcm_source_url_fr'   => 'string',
		'_tcm_doc_status'      => 'string',
		'_tcm_gallery'         => 'string',
	);

	foreach ( tenconi_migrated_types() as $tipo ) {
		foreach ( $campi as $chiave => $tipo_dato ) {
			register_post_meta( $tipo, $chiave, array(
				'type'          => $tipo_dato,
				'single'        => true,
				'show_in_rest'  => true,
				'auth_callback' => function () {
					// Solo chi puo' modificare i contenuti vede i meta via REST.
					return current_user_can( 'edit_posts' );
				},
			) );
		}
	}
}
add_action( 'init', 'tenconi_register_meta', 7 );

/**
 * Stato del testo di un contenuto, con fallback prudente.
 *
 * @param int|null $post_id Post ID, o null per quello corrente.
 * @return string complete|partial|placeholder|''
 */
function tenconi_text_state( $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$stato   = (string) get_post_meta( $post_id, '_tcm_text_state', true );
	return array_key_exists( $stato, tenconi_text_states() ) ? $stato : '';
}

/**
 * True se il contenuto proviene dalla migrazione.
 *
 * @param int|null $post_id Post ID.
 * @return bool
 */
function tenconi_is_migrated( $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	return (bool) get_post_meta( $post_id, '_tcm_key', true );
}

/**
 * Badge di stato del contenuto. Visibile a tutti per `partial` e `placeholder`,
 * perche' dichiarare l'incompletezza e' una regola del progetto.
 *
 * Il badge e' rimovibile in futuro: basta cambiare `_tcm_text_state` a `complete`.
 *
 * @param int|null $post_id Post ID.
 * @return void
 */
function tenconi_text_state_badge( $post_id = null ) {
	$stato = tenconi_text_state( $post_id );
	if ( 'partial' === $stato ) {
		printf(
			'<p class="tc-state tc-state--partial"><span class="tc-state__tag">Contenuto parziale</span> <span>da completare</span></p>'
		);
		return;
	}
	if ( 'placeholder' === $stato ) {
		printf(
			'<p class="tc-state tc-state--placeholder"><span class="tc-state__tag">Segnaposto</span> <span>contenuto da redigere</span></p>'
		);
	}
}

/**
 * Riga di provenienza, visibile SOLO agli amministratori.
 *
 * Mostra la source URL legacy e lo stato. Non e' contenuto pubblico: e' uno
 * strumento di verifica per la revisione editoriale.
 *
 * @param int|null $post_id Post ID.
 * @return void
 */
function tenconi_source_note( $post_id = null ) {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$post_id = $post_id ? $post_id : get_the_ID();
	$url     = (string) get_post_meta( $post_id, '_tcm_source_url', true );
	$key     = (string) get_post_meta( $post_id, '_tcm_key', true );
	$stato   = tenconi_text_state( $post_id );
	$chars   = (int) get_post_meta( $post_id, '_tcm_text_chars', true );
	if ( ! $key ) {
		return;
	}
	$stati = tenconi_text_states();
	echo '<aside class="tc-admin-note tc-tech" aria-label="Informazioni di migrazione, visibili solo agli amministratori">';
	echo '<span class="tc-admin-note__tag">Solo admin</span> ';
	echo 'chiave <code>' . esc_html( $key ) . '</code>';
	echo ' · stato <code>' . esc_html( $stato ? $stati[ $stato ] : 'non impostato' ) . '</code>';
	if ( $chars ) {
		echo ' · ' . esc_html( (string) $chars ) . ' caratteri legacy';
	}
	if ( $url ) {
		echo ' · <a href="' . esc_url( $url ) . '" rel="nofollow noopener">sorgente legacy</a>';
	}
	echo '</aside>';
}

/**
 * Colonna di stato nelle liste di amministrazione, per vedere subito cosa manca.
 *
 * @param array $colonne Colonne esistenti.
 * @return array
 */
function tenconi_admin_columns( $colonne ) {
	$colonne['tcm_state'] = 'Stato testo';
	return $colonne;
}

/**
 * Contenuto della colonna di stato.
 *
 * @param string $colonna Nome della colonna.
 * @param int    $post_id Post ID.
 * @return void
 */
function tenconi_admin_column_content( $colonna, $post_id ) {
	if ( 'tcm_state' !== $colonna ) {
		return;
	}
	$stato = tenconi_text_state( $post_id );
	if ( ! $stato ) {
		echo '—';
		return;
	}
	$stati = tenconi_text_states();
	echo esc_html( $stati[ $stato ] );
}

/**
 * Aggancia la colonna a tutti i tipi migrati.
 *
 * @return void
 */
function tenconi_admin_columns_init() {
	foreach ( tenconi_migrated_types() as $tipo ) {
		$suffisso = ( 'page' === $tipo ) ? 'pages' : 'posts_' . $tipo;
		add_filter( "manage_{$suffisso}_columns", 'tenconi_admin_columns' );
		add_action( "manage_{$suffisso}_custom_column", 'tenconi_admin_column_content', 10, 2 );
	}
}
add_action( 'admin_init', 'tenconi_admin_columns_init' );
