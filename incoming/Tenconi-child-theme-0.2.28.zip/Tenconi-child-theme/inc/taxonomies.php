<?php
/**
 * Tassonomie della Content Foundation.
 *
 * DECISIONE APPROVATA (NUOVA-21, opzione A): `market` ha rewrite `/settori/<slug>/`.
 * Questa scelta SOSTITUISCE il rewrite flat indicato come esito preferito dalla
 * Foundation V2 §6. Conseguenza registrata: i KEEP scendono da 12 a 9, perche'
 * `ferroviario-infrastruttura`, `ferroviario-rotabile` ed `energia` prendono il
 * prefisso e richiedono un 301. Il costo e' accettato: le tre pagine legacy hanno
 * 10 caratteri di testo ciascuna e sono gallerie, non contenuto con equity.
 *
 * `market` e' l'unica tassonomia PUBBLICA con viste editoriali proprie: le 5 viste
 * settore sono termini, non un CPT `solution`.
 *
 * Le altre tassonomie sono di servizio: `public => false`, quindi nessun archivio
 * pubblico e nessun rewrite, ma `show_ui` e `show_in_rest` attivi per l'admin e
 * per Gutenberg.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Argomenti comuni delle tassonomie.
 *
 * @param string $singolare Etichetta singolare.
 * @param string $plurale   Etichetta plurale.
 * @param bool   $pubblica  Se ha archivio pubblico e rewrite.
 * @param string $slug      Slug di rewrite, usato solo se pubblica.
 * @param array  $extra     Sovrascritture.
 * @return array
 */
function tenconi_tax_args( $singolare, $plurale, $pubblica, $slug, array $extra = array() ) {
	$labels = array(
		'name'              => $plurale,
		'singular_name'     => $singolare,
		'menu_name'         => $plurale,
		'all_items'         => sprintf( 'Tutti: %s', $plurale ),
		'edit_item'         => sprintf( 'Modifica %s', $singolare ),
		'view_item'         => sprintf( 'Vedi %s', $singolare ),
		'add_new_item'      => sprintf( 'Aggiungi %s', $singolare ),
		'new_item_name'     => sprintf( 'Nome del nuovo: %s', $singolare ),
		'search_items'      => sprintf( 'Cerca in %s', $plurale ),
		'not_found'         => 'Nessun elemento trovato.',
		'no_terms'          => sprintf( 'Nessun elemento in %s', $plurale ),
		'back_to_items'     => sprintf( 'Torna a %s', $plurale ),
		'parent_item'       => 'Elemento padre',
		'parent_item_colon' => 'Elemento padre:',
	);

	return array_merge(
		array(
			'labels'            => $labels,
			'public'            => $pubblica,
			'publicly_queryable' => $pubblica,
			'show_ui'           => true,
			'show_in_menu'      => true,
			'show_in_nav_menus' => $pubblica,
			'show_admin_column' => true,
			'show_in_rest'      => true, // compatibilita Gutenberg
			'hierarchical'      => false,
			'rewrite'           => $pubblica
				? array( 'slug' => $slug, 'with_front' => false )
				: false,
		),
		$extra
	);
}

/**
 * Registra le tassonomie.
 *
 * @return void
 */
function tenconi_register_taxonomies() {

	/*
	 * NUOVA-21 opzione A: prefisso /settori/.
	 * Un namespace riservato elimina strutturalmente la classe di collisioni piu'
	 * probabile del progetto, e da' un segmento base traducibile quando WPML
	 * verra' attivato.
	 */
	register_taxonomy(
		'market',
		array( 'product', 'capability', 'project', 'machine' ),
		tenconi_tax_args( 'Settore', 'Settori', true, 'settori', array(
			'hierarchical' => true, // consente una gerarchia di settori in futuro
			'description'  => 'I settori di mercato serviti. Le 5 viste settore sono termini di questa tassonomia.',
		) )
	);

	register_taxonomy( 'location', array( 'machine', 'certification', 'job', 'project' ),
		tenconi_tax_args( 'Sede', 'Sedi', false, 'sede' ) );

	register_taxonomy( 'tipo_offerta', array( 'capability' ),
		tenconi_tax_args( 'Tipo di offerta', 'Tipi di offerta', false, 'tipo-offerta' ) );

	register_taxonomy( 'product_family', array( 'product' ),
		tenconi_tax_args( 'Famiglia di prodotto', 'Famiglie di prodotto', false, 'famiglia' ) );

	register_taxonomy( 'process', array( 'capability', 'machine' ),
		tenconi_tax_args( 'Processo', 'Processi', false, 'processo' ) );

	register_taxonomy( 'material', array( 'capability' ),
		tenconi_tax_args( 'Materiale', 'Materiali', false, 'materiale' ) );

	register_taxonomy( 'machine_category', array( 'machine' ),
		tenconi_tax_args( 'Categoria macchina', 'Categorie macchina', false, 'categoria-macchina' ) );

	register_taxonomy( 'standard', array( 'product', 'capability', 'certification' ),
		tenconi_tax_args( 'Norma', 'Norme', false, 'norma' ) );

	register_taxonomy( 'cert_type', array( 'certification' ),
		tenconi_tax_args( 'Tipo di certificato', 'Tipi di certificato', false, 'tipo-certificato' ) );

	register_taxonomy( 'document_type', array( 'document' ),
		tenconi_tax_args( 'Tipo di documento', 'Tipi di documento', false, 'tipo-documento' ) );

	register_taxonomy( 'year', array( 'project' ),
		tenconi_tax_args( 'Anno', 'Anni', false, 'anno' ) );

	register_taxonomy( 'confidentiality', array( 'project', 'document' ),
		tenconi_tax_args( 'Riservatezza', 'Riservatezza', false, 'riservatezza' ) );

	register_taxonomy( 'department', array( 'job' ),
		tenconi_tax_args( 'Reparto', 'Reparti', false, 'reparto' ) );
}
add_action( 'init', 'tenconi_register_taxonomies', 6 );
