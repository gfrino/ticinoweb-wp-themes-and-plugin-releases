<?php
/**
 * Sorgente dati unica dei contenuti del tema.
 *
 * REGOLA: nessun dato aziendale nei template. Tutto qui, con marcatura di stato.
 * In una fase successiva questi valori diventano campi ACF; le firme delle
 * funzioni non cambiano.
 *
 * DEVIAZIONE PRAGMATICA dal piano: il lotto 1 contiene solo i dati del primo
 * viewport, del menu e del footer. Le sezioni 2-9 arriveranno nel lotto 2.
 *
 * VIETATI in V1: numero collaboratori (3 valori in conflitto nelle fonti),
 * numero paesi (3 valori), capacita numeriche del documento storico Xerox,
 * elenco definitivo macchinari, validita dei certificati, KPI CSR senza anno,
 * nomi cliente non riconfermati, indirizzo di Cadenazzo.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Contenuto della homepage. Lotto 1: solo la sezione 1.
 *
 * @return array
 */
function tenconi_home() {
	static $data = null;
	if ( null !== $data ) {
		return $data;
	}

	$data = array(

		// SEZIONE 1 - Hero istituzionale. Campo navy. NESSUNA fotografia.
		'hero' => array(
			'field'      => 'navy',
			'no'         => '01',
			'h1'         => 'Componenti ferroviari. Lavorazioni industriali su disegno.',
			'h1_status'  => 'provisional',
			'sub'        => 'Dal 1871, ad Airolo e Cadenazzo. Entrambi gli stabilimenti qualificati EN 15085-2 CL1.',
			'sub_status' => 'provisional',

			/*
			 * MASSIMO 4 riferimenti prioritari. L'elenco completo delle 11
			 * certificazioni sta nella sezione 3, che arriva nel lotto 2.
			 */
			'refs'       => array(
				array(
					'label' => '',
					'value' => 'Since 1871',
				),
				array(
					'label' => '',
					'value' => 'Airolo + Cadenazzo',
				),
				array(
					'label' => '',
					'value' => 'EN 15085-2 CL1 x2',
				),
				array(
					'label' => '',
					'value' => 'DB Zulassung HPQ',
				),
			),

			'cta'        => array(
				'label' => 'Richiedi un\'offerta tecnica',
				'url'   => '/contatti/',
			),

			// Le due porte: peso identico, separate da UN SOLO filetto.
			'doors'      => array(
				array(
					'label' => 'Prodotti',
					'url'   => '/prodotti/',
					'note'  => 'Catalogo proprietario',
				),
				array(
					'label' => 'Lavorazioni',
					'url'   => '/lavorazioni/',
					'note'  => 'Su disegno del cliente',
				),
			),
		),
	);

	return $data;
}

/**
 * Struttura del menu principale: 7 voci.
 *
 * "Settori" NON e voce principale: e una colonna dentro i pannelli Prodotti e
 * Lavorazioni. Le 5 viste settore restano indicizzabili e raggiungibili da otto
 * punti d'ingresso, come da surface brief.
 *
 * @return array
 */
function tenconi_nav() {
	$sectors = array(
		array(
			'label' => 'Infrastruttura ferroviaria',
			'url'   => '/ferroviario-infrastruttura/',
		),
		array(
			'label' => 'Materiale rotabile',
			'url'   => '/ferroviario-rotabile/',
		),
		array(
			'label' => 'Energia e idroelettrico',
			'url'   => '/energia/',
		),
		array(
			'label' => 'Telecomunicazioni',
			'url'   => '/settori/telecomunicazioni/',
		),
		array(
			'label' => 'Genio civile',
			'url'   => '/settori/genio-civile/',
		),
	);

	return array(
		array(
			'label' => 'Azienda',
			'url'   => '/azienda/',
			'cols'  => array(
				array(
					'title' => 'Azienda',
					'items' => array(
						array(
							'label' => 'Chi siamo',
							'url'   => '/chi-siamo/',
						),
						array(
							'label' => 'La nostra storia',
							'url'   => '/storia/',
						),
						array(
							'label' => 'Airolo e Cadenazzo',
							'url'   => '/sedi/',
						),
					),
				),
			),
		),
		array(
			'label' => 'Prodotti',
			'url'   => '/prodotti/',
			'cols'  => array(
				array(
					'title' => 'Catalogo',
					'items' => array(
						array(
							'label' => 'Giunti isolanti per rotaie',
							'url'   => '/prodotti/giunti-isolanti/',
						),
						array(
							'label' => 'Piastre isolanti e speciali',
							'url'   => '/prodotti/piastre-isolanti/',
						),
						array(
							'label' => 'Giunti meccanici',
							'url'   => '/prodotti/giunti-meccanici/',
						),
						array(
							'label' => 'Traverse cave in acciaio',
							'url'   => '/prodotti/traverse/',
						),
						array(
							'label' => 'Pali tubolari e sostegni',
							'url'   => '/prodotti/pali-tubolari/',
						),
						array(
							'label' => 'C-Clamp e Joggle fishplate',
							'url'   => '/prodotti/dispositivi-fissaggio/',
						),
					),
				),
				array(
					'title' => 'Settori',
					'items' => $sectors,
				),
			),
		),
		array(
			'label' => 'Lavorazioni',
			'url'   => '/lavorazioni/',
			'cols'  => array(
				array(
					'title' => 'Competenze',
					'items' => array(
						array(
							'label' => 'Lavorazioni meccaniche',
							'url'   => '/lavorazioni/lavorazioni-meccaniche/',
						),
						array(
							'label' => 'Forgiatura e stampaggio',
							'url'   => '/lavorazioni/forgiatura-stampaggio/',
						),
						array(
							'label' => 'Saldatura acciaio',
							'url'   => '/lavorazioni/saldatura-acciaio/',
						),
						array(
							'label' => 'Lavorazione alluminio',
							'url'   => '/lavorazioni/lavorazione-alluminio/',
						),
						array(
							'label' => 'Plastificazione e rivestimento',
							'url'   => '/lavorazioni/plastificazione/',
						),
						array(
							'label' => 'Carpenteria metallica',
							'url'   => '/lavorazioni/carpenteria-metallica/',
						),
					),
				),
				array(
					'title' => 'Servizi',
					'items' => array(
						array(
							'label' => 'Revisione carri merce',
							'url'   => '/lavorazioni/revisione-carri-merce/',
						),
						array(
							'label' => 'Manutenzione centrali',
							'url'   => '/lavorazioni/manutenzione-centrali/',
						),
						array(
							'label' => 'Revisioni idromeccaniche',
							'url'   => '/lavorazioni/revisioni-idromeccaniche/',
						),
						array(
							'label'   => 'Parco macchine',
							'url'     => '/parco-macchine/',
							'feature' => true,
						),
					),
				),
				array(
					'title' => 'Settori',
					'items' => $sectors,
				),
			),
		),
		array(
			'label' => 'Progetti',
			'url'   => '/referenze/',
		),
		array(
			'label' => 'Qualità',
			'url'   => '/qualita/',
			'cols'  => array(
				array(
					'title' => 'Qualità',
					'items' => array(
						array(
							'label' => 'Certificazioni',
							'url'   => '/certificazioni/',
						),
						array(
							'label' => 'Sostenibilità',
							'url'   => '/sostenibilita/',
						),
						array(
							'label' => 'Documenti',
							'url'   => '/documenti/',
						),
					),
				),
			),
		),
		array(
			'label' => 'Lavora con noi',
			'url'   => '/jobs/',
			'cols'  => array(
				array(
					'title' => 'Carriere',
					'items' => array(
						array(
							'label' => 'Posizioni aperte',
							'url'   => '/jobs/',
						),
						array(
							'label' => 'La vita in Tenconi',
							'url'   => '/vita-in-tenconi/',
						),
					),
				),
			),
		),
		array(
			'label' => 'Contatti',
			'url'   => '/contatti/',
		),
	);
}
