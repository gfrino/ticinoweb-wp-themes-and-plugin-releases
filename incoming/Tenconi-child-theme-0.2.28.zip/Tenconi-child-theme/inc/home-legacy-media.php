<?php
/**
 * LA MAPPA ASSET LEGACY -> SLOT DELLA HOMEPAGE.
 *
 * Questo file esiste per una ragione precisa: la homepage legacy ha una SCELTA
 * REDAZIONALE, non un automatismo. Prendere "l'immagine in evidenza della pagina"
 * o "la prima della galleria" produce immagini plausibili e sbagliate. Qui ogni
 * slot dichiara ESPLICITAMENTE quale asset legacy gli appartiene.
 *
 * COME E' STATA RICAVATA, e non indovinata:
 *
 * 1. Dal sorgente in cache tools/migration/cache/legacy/pages/it/home.html sono
 *    stati estratti, IN ORDINE DI DOCUMENTO, gli 8 media e i 2 identificativi
 *    YouTube, con l'URL CDN completo di ciascuno. L'URL completo era necessario
 *    perche' TRE slot diversi usano un file chiamato "Cattura.PNG": si
 *    distinguono solo per l'identificativo Squarespace.
 *
 * 2. Ogni slot e' stato ritagliato dallo screenshot legacy
 *    _project-context/03-old-site-screenshots/home.png alle coordinate misurate,
 *    e confrontato con TUTTI i 647 originali consegnati. Il registro
 *    tools/migration/output/media-import-report.csv dimostra che tutti i 647
 *    attachment importati provengono esclusivamente da quella cartella: la
 *    ricerca copre quindi l'intera libreria, non un campione.
 *
 * 3. Il candidato migliore e' stato riscalato alla larghezza dello slot e fatto
 *    scorrere verticalmente per trovare l'allineamento di minimo residuo. Il
 *    residuo medio per pixel e' riportato slot per slot qui sotto: sotto ~18 su
 *    255 e' la stessa immagine, sopra ~55 e' un'altra fotografia.
 *
 * TRE STATI POSSIBILI, e nessuna sostituzione:
 *
 *   ok        l'asset legacy esatto esiste ed e' pubblicabile.
 *   mancante  l'asset legacy NON esiste fra gli attachment importati. Lo slot
 *             resta vuoto e dichiarato. Non viene riempito con un'immagine
 *             simile: sarebbe una parita' finta.
 *   diritti   l'asset esiste ma porta il copyright di un terzo nei metadati.
 *             Resta trattenuto finche' la licenza non e' a registro.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * La prima riga della home legacy: due video YouTube e un'immagine al centro.
 *
 * NEL LEGACY SONO DAVVERO DUE VIDEO E UNA FIGURA, non tre fotografie. La fase
 * precedente aveva messo tre fotografie perche' l'incorporamento di YouTube era
 * stato rinviato: era una divergenza visibile e viene disfatta.
 *
 * L'immagine centrale e' la copertina di un opuscolo e nel legacy E' UN LINK al
 * PDF Tenconi_RAIL_Joints_Technology.pdf, che in WordPress e' l'allegato 740.
 * Anche la didascalia e' un link allo stesso PDF.
 *
 * @return array<int,array<string,mixed>>
 */
function tenconi_legacy_home_media() {

	$slot = array(

		/*
		 * SINISTRA. Video, non fotografia.
		 * legacy: youtube.com/embed/_7zUyVQlHRE
		 */
		array(
			'tipo'      => 'video',
			'youtube'   => '_7zUyVQlHRE',
			'titolo'    => 'Tenconi SA — Klein Matterhorn Testa Grigia',
			'didascalia' => 'Klein Matterhorn Testa Grigia',
		),

		/*
		 * CENTRO. RITROVATO il 2026-08-07.
		 * legacy: .../4fa2236f-2c9f-44bd-ae8b-bc1128bc3b85/Fascicolo+Giunti+isolati
		 *
		 * Il render del giunto isolato su fondo sfumato non era nel lotto originale
		 * dei 647 ed era stato dichiarato assente, con la prova per esclusione. Il
		 * committente lo ha consegnato: attachment 828, 1134x576 WebP, AST-0647.
		 *
		 * IDENTIFICATO PER CONTENUTO, non per nome: residuo 6,84 su 255 con un
		 * ritaglio orizzontale di 60 px. Quel ritaglio spiega anche perche' il file
		 * sta a 1,969 mentre il blocco legacy dichiarava 1,769: Squarespace lo
		 * mostrava tagliato ai lati.
		 *
		 * L'immagine E' UN LINK al PDF Tenconi_RAIL_Joints_Technology.pdf, come nel
		 * legacy, e anche la didascalia porta allo stesso PDF.
		 */
		array(
			'tipo'       => 'immagine',
			'img'        => 828,
			'alt'        => 'Render di un giunto isolato per rotaia con elementi isolanti bianchi.',
			'didascalia' => 'Giunti rotaie',
			'pdf'        => 740,
		),

		/*
		 * DESTRA. Video, non fotografia.
		 * legacy: youtube.com/embed/HuAqfYAZmlA
		 */
		array(
			'tipo'      => 'video',
			'youtube'   => 'HuAqfYAZmlA',
			'titolo'    => 'Tenconi SA — Panoramica aziendale',
			'didascalia' => 'La nostra azienda',
		),
	);

	foreach ( $slot as $i => $s ) {
		if ( isset( $s['pdf'] ) ) {
			$url = wp_get_attachment_url( (int) $s['pdf'] );
			$slot[ $i ]['pdf_url'] = $url ? $url : '';
		}
	}
	return $slot;
}

/**
 * Le cinque aree, NELL'ORDINE DEL LEGACY.
 *
 * L'ordine e' quello del sorgente legacy e dello screenshot, e non e'
 * alfabetico ne' arbitrario: Carpenteria metallica sta in terza posizione, non in
 * quarta. La fase precedente aveva invertito Carpenteria e Metalmeccanica.
 *
 * @return array<int,array<string,mixed>>
 */
function tenconi_legacy_home_aree() {

	return array(

		/*
		 * 1. legacy: .../1616754637173-5VHBCTHYVZT1FYCZQXIB/Cattura.PNG
		 * Su Squarespace era salvata come "Cattura.PNG"; il file consegnato dal
		 * committente e' lo stesso contenuto con il suo nome vero,
		 * giunto+plastificato.png. Residuo di allineamento 6,5 su 255.
		 * Giunto con calzature plastificate verdi su acciaio.
		 */
		array(
			'label' => 'Ferroviario - Infrastruttura',
			'img'   => 288,
			'alt'   => 'Giunto per rotaia con elementi isolanti plastificati verdi.',
			'dest'  => array( 'term_archive', 'market:ferroviario-infrastruttura' ),
		),

		/*
		 * 2. legacy: .../1625667762242-VHNXR4F5Q9CJ4YJSZEP7/IMG_5576+copia.jpg
		 * Residuo 1,0 su 255: corrispondenza esatta.
		 * Automotrice TILO di fronte, con "TENCONI" sull'indicatore di percorso.
		 */
		array(
			'label' => 'Ferroviario - Rotabile',
			'img'   => 502,
			'alt'   => 'Automotrice ferroviaria vista frontalmente in officina.',
			'dest'  => array( 'term_archive', 'market:ferroviario-rotabile' ),
		),

		/*
		 * 3. legacy: .../1624345084624-4BMKFKO2MRNDQLI6EGUB/1O0A0429.jpg
		 * Residuo 4,2 su 255: corrispondenza esatta.
		 *
		 * DIRITTI CONFERMATI IL 2026-08-07. L'attachment 500 porta nei metadati
		 * autore "MASSIMO PEDRAZZINI" e copyright "(C)FOTOPEDRAZZINI.CH", ed era
		 * fra le nove immagini in revisione diritti. Il committente ha dichiarato
		 * esplicitamente di avere i diritti d'uso sul sito Tenconi, e quella
		 * dichiarazione e' l'approvazione editoriale del progetto. Lo stato dei
		 * nove allegati e' passato da "review_required" a "cleared", conservando
		 * il valore precedente in "_tcm_rights_state_prima" perche' la modifica
		 * resti reversibile. Questo file non e' cambiato per sbloccare la tavola:
		 * il cancello si e' aperto da solo, che era il suo scopo.
		 */
		array(
			'label' => 'Carpenteria metallica',
			'img'   => 500,
			'alt'   => 'Struttura in acciaio con passaggio ferroviario al crepuscolo.',
			'dest'  => array( 'cpt_single', 'capability:carpenteria-metallica' ),
		),

		/*
		 * 4. legacy: .../1624608399425-8JNJFG5SP6F74FMVOHCP/_SAB4001.jpg
		 * Residuo 16,0 su 255: corrispondenza. Il residuo non e' piu' basso perche'
		 * Squarespace ne ritoccava il contrasto.
		 * Componente in alluminio lavorato a controllo numerico.
		 */
		array(
			'label' => 'Metalmeccanica',
			'img'   => 504,
			'alt'   => 'Componente in alluminio lavorato a controllo numerico.',
			'dest'  => array( 'cpt_single', 'capability:lavorazioni-meccaniche' ),
		),

		/*
		 * 5. legacy: .../1614932856918-J8OV556NMXPFPUNTOY49/Cattura.PNG
		 * Residuo 3,5 su 255 con ritaglio verticale di 15 px: corrispondenza.
		 * ATTENZIONE: e' il secondo dei tre "Cattura.PNG" del legacy, ed e' il solo
		 * che il committente ha consegnato. Girante Pelton con operatore.
		 */
		array(
			'label' => 'Energia',
			'img'   => 501,
			'alt'   => 'Girante di turbina Pelton in officina, con operatore.',
			'dest'  => array( 'term_archive', 'market:energia' ),
		),
	);
}

/**
 * I due blocchi che chiudono la home legacy.
 *
 * @return array<int,array<string,mixed>>
 */
function tenconi_legacy_home_blocchi() {

	return array(

		/*
		 * legacy: .../1620715440423-HEK3PZDA6OWSLDFOCHXC/_SAB1158-Carnaghi.jpg
		 * Residuo 18,2 su 255: corrispondenza. Lo stesso file era stato importato
		 * tre volte da tre cartelle diverse (attachment 292, 503, 574): si usa il
		 * 503, quello importato dalla cartella "home", cioe' la copia che il
		 * committente ha consegnato PER QUESTA PAGINA.
		 * Centro di lavoro Mario Carnaghi con operatore.
		 */
		array(
			'label' => 'Parco macchine',
			'img'   => 503,
			'alt'   => 'Centro di lavoro Mario Carnaghi con operatore in officina.',
			'inizio' => 'Nelle due sedi',
			/*
			 * NEL LEGACY IL LINK STA DENTRO LA FRASE, e la frase finisce col punto:
			 * "Scoprite il nostro parco macchine." con sottolineato soltanto
			 * "parco macchine". Prima il link era una riga a se', senza punto.
			 */
			'prefisso' => 'Scoprite il nostro ',
			'link'     => 'parco macchine',
			'dest'  => array( 'cpt_archive', 'machine' ),
		),

		/*
		 * legacy: .../1614933041902-PNN5FE2OA2808BG3KSEG/Cattura.PNG
		 * RITROVATO il 2026-08-07: attachment 829, 1088x725, AST-0648.
		 *
		 * E' il terzo "Cattura.PNG": la riunione attorno al tavolo. Non era nel
		 * lotto dei 647 e la ricerca lo aveva escluso correttamente. La sessione
		 * fotografica c'era — quattordici scatti in supporto/, sei della stessa
		 * riunione, tre perfino con il rapporto 1,498 identico allo slot — ma
		 * nessuno era QUEL fotogramma: il migliore stava a residuo 53,9 contro
		 * l'1..18 dei riscontri veri, e all'occhio la posa era diversa.
		 *
		 * QUELLO CONSEGNATO ORA COMBACIA: residuo 2,46 su 255, praticamente
		 * sovrapponibile, e il rapporto 1,501 contro l'1,498 dello slot. Era
		 * davvero un altro scatto, non un ritaglio di quelli che avevamo.
		 *
		 * Nota per chi legge dopo: l'attachment 491 (Untitled+design+(3).png) che
		 * la prima versione usava qui NON e' questo, e non va rimesso.
		 */
		array(
			'label'  => 'Gestione progetti',
			'img'    => 829,
			'legacy' => '',
			'alt'    => 'Riunione di lavoro attorno a un tavolo, con computer portatili.',
			'inizio' => 'La ditta Tenconi SA',
			'prefisso' => 'Maggiori informazioni sulla ',
			'link'     => 'gestione dei progetti',
			'dest'   => array( 'cpt_single', 'capability:gestione-progetti' ),
		),
	);
}

/**
 * Lo stato di uno slot immagine: pubblicabile, trattenuto o mancante.
 *
 * Distingue i due motivi per cui un'immagine non esce, perche' non sono la stessa
 * cosa e non si risolvono nello stesso modo: "mancante" chiede un file al
 * committente, "diritti" chiede una licenza.
 *
 * @param int $id Attachment.
 * @return string ok|diritti|mancante
 */
function tenconi_legacy_stato_img( $id ) {

	$id = (int) $id;
	if ( ! $id ) {
		return 'mancante';
	}
	if ( 'review_required' === get_post_meta( $id, '_tcm_rights_state', true ) ) {
		return 'diritti';
	}
	return tenconi_home_img_ok( $id ) ? 'ok' : 'mancante';
}

/**
 * Trova un allegato dal NOME DEL FILE, non dall'ID.
 *
 * PERCHE' NON L'ID. Il filmato della hero era l'allegato 837; e' stato cancellato
 * dalla libreria e ricaricato, e WordPress gli ha dato il numero 841. Il template
 * puntava a 837 e la hero e' rimasta senza video, senza che niente segnalasse
 * l'errore. Il nome del file invece sopravvive al ricaricamento, che e' la cosa
 * che accade davvero quando si sostituisce un media.
 *
 * @param string $nome Frammento del nome del file, senza estensione.
 * @param string $mime Prefisso del tipo, per esempio 'video'.
 * @return int ID dell'allegato, 0 se non c'e'.
 */
function tenconi_media_da_nome( $nome, $mime = '' ) {

	static $cache = array();
	$chiave = $nome . '|' . $mime;
	if ( isset( $cache[ $chiave ] ) ) {
		return $cache[ $chiave ];
	}

	global $wpdb;
	$sql = "SELECT p.ID FROM {$wpdb->posts} p
			INNER JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = '_wp_attached_file'
			WHERE p.post_type = 'attachment' AND m.meta_value LIKE %s";
	$arg = array( '%' . $wpdb->esc_like( $nome ) . '%' );

	if ( '' !== $mime ) {
		$sql  .= ' AND p.post_mime_type LIKE %s';
		$arg[] = $wpdb->esc_like( $mime ) . '/%';
	}
	/* Il piu' recente: se ne esistono due copie vince quella caricata dopo. */
	$sql .= ' ORDER BY p.ID DESC LIMIT 1';

	$id = (int) $wpdb->get_var( $wpdb->prepare( $sql, $arg ) );

	$cache[ $chiave ] = $id;
	return $id;
}
