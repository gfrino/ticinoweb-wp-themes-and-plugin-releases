<?php
/**
 * Lettura dei menu WordPress reali.
 *
 * Da CF-4 la navigazione non e' piu' un array in codice: e' un menu WordPress,
 * modificabile da Aspetto > Menu, con voci che puntano a oggetti reali. Questo
 * modulo lo legge e ne ricava la struttura che il mega menu e il footer
 * consumavano gia', senza cambiare il markup.
 *
 * PERCHE' NON wp_nav_menu(). Il mega menu ha una forma sua (pannelli, colonne,
 * titoli di colonna che non sono link) e il template la stampa gia' bene. Serviva
 * cambiare la SORGENTE dei dati, non il markup: cosi' non si duplica una seconda
 * sitemap scritta a mano e non si tocca la direzione artistica.
 *
 * MAPPATURA DEI LIVELLI, per il menu principale:
 *   livello 1  voce di primo livello, con il suo link
 *   livello 2  titolo di colonna (voce custom senza URL) oppure voce diretta
 *   livello 3  voci della colonna
 * Per il footer i livelli sono due: intestazione di gruppo e voci.
 *
 * Se una posizione non ha menu assegnato si torna al risolutore di CF-2, cosi'
 * il sito resta navigabile anche prima che i menu esistano.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Albero annidato delle voci di una posizione di menu.
 *
 * @param string $location Posizione registrata.
 * @return array Elenco di array( id, label, url, feature, kind, children ).
 */
function tenconi_menu_tree( $location ) {
	static $cache = array();
	if ( isset( $cache[ $location ] ) ) {
		return $cache[ $location ];
	}

	$loc = (array) get_theme_mod( 'nav_menu_locations', array() );
	if ( empty( $loc[ $location ] ) ) {
		$cache[ $location ] = array();
		return $cache[ $location ];
	}
	$items = wp_get_nav_menu_items( (int) $loc[ $location ] );
	if ( ! $items ) {
		$cache[ $location ] = array();
		return $cache[ $location ];
	}

	$per_id = array();
	foreach ( $items as $it ) {
		// Una voce custom senza URL e' un'intestazione, non un link: e' voluto.
		$url = ( 'custom' === $it->type && '' === trim( (string) $it->url ) ) ? '' : (string) $it->url;
		$per_id[ (int) $it->ID ] = array(
			'id'       => (int) $it->ID,
			'label'    => (string) $it->title,
			'url'      => $url,
			'kind'     => (string) $it->type,
			'object'   => (string) $it->object,
			'feature'  => in_array( 'tc-menu-feature', (array) $it->classes, true ),
			'children' => array(),
		);
	}
	$radici = array();
	foreach ( $items as $it ) {
		$id     = (int) $it->ID;
		$parent = (int) $it->menu_item_parent;
		if ( $parent && isset( $per_id[ $parent ] ) ) {
			$per_id[ $parent ]['children'][] = &$per_id[ $id ];
		} else {
			$radici[] = &$per_id[ $id ];
		}
	}
	unset( $per_id );

	$cache[ $location ] = $radici;
	return $radici;
}

/**
 * Struttura del mega menu, letta dal menu WordPress reale.
 *
 * Restituisce array vuoto se il menu non c'e': il chiamante decide il ripiego.
 *
 * @return array
 */
function tenconi_nav_from_menu() {
	$tree = tenconi_menu_tree( 'tenconi_primary' );
	if ( ! $tree ) {
		return array();
	}

	$nav = array();
	foreach ( $tree as $top ) {
		$voce = array( 'label' => $top['label'], 'url' => $top['url'] );
		$cols = array();

		foreach ( $top['children'] as $figlio ) {
			if ( $figlio['children'] ) {
				// Ha figli: e' un titolo di colonna.
				$items = array();
				foreach ( $figlio['children'] as $n ) {
					if ( '' === $n['url'] ) {
						continue;
					}
					$items[] = array( 'label' => $n['label'], 'url' => $n['url'], 'feature' => $n['feature'] );
				}
				if ( $items ) {
					$cols[] = array( 'title' => $figlio['label'], 'items' => $items );
				}
				continue;
			}
			// Senza figli e con URL: voce diretta, raccolta in una colonna implicita.
			if ( '' !== $figlio['url'] ) {
				$cols['__diretti']['title'] = $top['label'];
				$cols['__diretti']['items'][] = array(
					'label' => $figlio['label'], 'url' => $figlio['url'], 'feature' => $figlio['feature'],
				);
			}
		}
		if ( isset( $cols['__diretti'] ) ) {
			$diretti = $cols['__diretti'];
			unset( $cols['__diretti'] );
			$cols[] = $diretti;
		}
		$cols = array_values( $cols );
		if ( $cols ) {
			$voce['cols'] = $cols;
		}
		if ( '' === $voce['url'] ) {
			$voce['unresolved'] = true;
		}
		$nav[] = $voce;
	}
	return $nav;
}

/**
 * Gruppi del footer, letti dal menu WordPress reale.
 *
 * @return array
 */
function tenconi_footer_from_menu() {
	$tree = tenconi_menu_tree( 'tenconi_footer' );
	if ( ! $tree ) {
		return array();
	}
	$out = array();
	foreach ( $tree as $gruppo ) {
		$items = array();
		foreach ( $gruppo['children'] as $n ) {
			// Un gruppo del footer e' piatto: se ci fossero nipoti, si appiattiscono.
			$candidati = $n['children'] ? $n['children'] : array( $n );
			foreach ( $candidati as $c ) {
				if ( '' !== $c['url'] ) {
					$items[] = array( 'label' => $c['label'], 'url' => $c['url'] );
				}
			}
		}
		if ( $items ) {
			$out[] = array( 'title' => $gruppo['label'], 'items' => $items );
		}
	}
	return $out;
}

/**
 * Link legali, letti dal menu WordPress reale.
 *
 * @return array
 */
function tenconi_legal_from_menu() {
	$out = array();
	foreach ( tenconi_menu_tree( 'tenconi_legal' ) as $n ) {
		if ( '' !== $n['url'] ) {
			$out[] = array( 'label' => $n['label'], 'url' => $n['url'] );
		}
	}
	return $out;
}

/**
 * Navigazione principale: il menu WordPress se c'e', il risolutore altrimenti.
 *
 * Il nome NON e' tenconi_nav(): quella esiste gia' in inc/content.php col menu
 * scritto a mano del Lotto 1, e ridefinirla sarebbe un errore fatale. Qui la
 * catena di ripiego e' esplicita: menu reale, poi risolutore CF-2, poi l'array
 * del Lotto 1 come ultima difesa.
 *
 * @return array
 */
function tenconi_primary_nav() {
	$da_menu = tenconi_nav_from_menu();
	if ( $da_menu ) {
		return $da_menu;
	}
	if ( function_exists( 'tenconi_nav_resolved' ) ) {
		$risolto = tenconi_nav_resolved();
		if ( $risolto ) {
			return $risolto;
		}
	}
	return function_exists( 'tenconi_nav' ) ? tenconi_nav() : array();
}

/**
 * Gruppi del footer: il menu WordPress se c'e', il risolutore altrimenti.
 *
 * @return array
 */
function tenconi_footer_nav() {
	$da_menu = tenconi_footer_from_menu();
	if ( $da_menu ) {
		return $da_menu;
	}
	return function_exists( 'tenconi_footer_resolved' ) ? tenconi_footer_resolved() : array();
}

/**
 * Link legali: il menu WordPress se c'e', il risolutore altrimenti.
 *
 * @return array
 */
function tenconi_legal_nav() {
	$da_menu = tenconi_legal_from_menu();
	if ( $da_menu ) {
		return $da_menu;
	}
	return function_exists( 'tenconi_legal_resolved' ) ? tenconi_legal_resolved() : array();
}

/**
 * Conteggio delle voci per posizione. Serve alla verifica, non al rendering.
 *
 * @return array
 */
function tenconi_menu_counts() {
	$out = array();
	foreach ( array( 'tenconi_primary', 'tenconi_footer', 'tenconi_legal' ) as $l ) {
		$loc = (array) get_theme_mod( 'nav_menu_locations', array() );
		$n   = 0;
		if ( ! empty( $loc[ $l ] ) ) {
			$n = count( (array) wp_get_nav_menu_items( (int) $loc[ $l ] ) );
		}
		$out[ $l ] = array( 'menu_id' => (int) ( $loc[ $l ] ?? 0 ), 'voci' => $n );
	}
	return $out;
}
