<?php
/**
 * IL MODULO CONTATTI, funzionante e senza plugin.
 *
 * Il legacy aveva un modulo Squarespace. Qui non c'e' nessun gestore di moduli,
 * e un modulo che SEMBRA funzionante getta via le richieste dei clienti: su una
 * pagina contatti di un'azienda manifatturiera e' il guasto peggiore possibile.
 * Quindi il modulo e' vero, con WordPress puro.
 *
 * ARCHITETTURA. Invio a admin-post.php, elaborazione lato server, poi redirect
 * alla pagina con un esito in query string (pattern POST-redirect-GET, cosi' il
 * ricaricamento non reinvia). Nessuna dipendenza aggiunta.
 *
 * SICUREZZA, in ordine di verifica:
 *   nonce            blocca il CSRF
 *   honeypot         un campo che gli umani non vedono; se e' pieno, e' un bot
 *   tempo minimo     un invio in meno di 3 secondi non e' umano
 *   rate limiting    un invio ogni 60 secondi per indirizzo IP, via transient
 *   validazione      lato SERVER, non solo con l'attributo required
 *   sanitizzazione   ogni campo col filtro adatto al suo tipo
 *
 * NIENTE NEL DATABASE. Le richieste non vengono salvate: sono dati personali di
 * clienti e conservarli senza necessita' e' un rischio, non una comodita'. Vanno
 * per posta e basta. L'unica cosa che tocca il database e' il transient del rate
 * limiting, che contiene un hash dell'IP e scade da solo.
 *
 * DESTINATARIO. Nessun indirizzo scritto nel codice (regola ticinoWEB dei dati
 * dinamici): si legge dalle impostazioni del sito, vedi tenconi_form_destinatario().
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** L'azione di admin-post. */
const TENCONI_FORM_AZIONE = 'tenconi_contatti';

/**
 * Il destinatario, sempre dal database e mai dal codice. In ordine:
 *
 *   1. "Email di Ricezione Form" del parent (ticinoWEB CMS -> Contatti,
 *      ticinoweb_contact_email): il posto ovvio dove un cliente la cambia;
 *   2. l'indirizzo dopo "Mail:" nella pagina Contatti pubblicata, come prima;
 *   3. l'email dell'amministratore del sito, perche' una richiesta di un cliente
 *      non deve mai finire nel vuoto.
 *
 * @return string
 */
function tenconi_form_destinatario() {

	$impostata = sanitize_email( (string) get_option( 'ticinoweb_contact_email', '' ) );
	if ( is_email( $impostata ) ) {
		return $impostata;
	}

	$pagina = get_page_by_path( 'contatti' );
	if ( $pagina && preg_match( '/Mail:\s*([\w.\-]+@[\w.\-]+\.\w+)/u', (string) $pagina->post_content, $m ) ) {
		$mail = sanitize_email( $m[1] );
		if ( is_email( $mail ) ) {
			return $mail;
		}
	}
	return (string) get_option( 'admin_email' );
}

/**
 * I campi del modulo, nell'ordine e con gli obblighi del legacy.
 *
 * @return array<string,array<string,mixed>>
 */
function tenconi_form_campi() {

	return array(
		'ditta'     => array( 'label' => 'Ditta', 'tipo' => 'text', 'obbl' => true, 'largo' => true ),
		'nome'      => array( 'label' => 'Nome', 'tipo' => 'text', 'obbl' => false, 'largo' => false ),
		'cognome'   => array( 'label' => 'Cognome', 'tipo' => 'text', 'obbl' => false, 'largo' => false ),
		'indirizzo' => array( 'label' => 'Indirizzo', 'tipo' => 'text', 'obbl' => true, 'largo' => true ),
		'paese'     => array( 'label' => 'Paese', 'tipo' => 'text', 'obbl' => true, 'largo' => true ),
		'email'     => array( 'label' => 'Email', 'tipo' => 'email', 'obbl' => true, 'largo' => true ),
		'messaggio' => array( 'label' => 'Messaggio', 'tipo' => 'textarea', 'obbl' => true, 'largo' => true ),
	);
}

/**
 * Riceve l'invio, verifica, spedisce, torna alla pagina con l'esito.
 *
 * @return void
 */
function tenconi_form_gestisci() {

	$ritorno = wp_get_referer();
	if ( ! $ritorno ) {
		$pagina  = get_page_by_path( 'contatti' );
		$ritorno = $pagina ? get_permalink( $pagina ) : home_url( '/' );
	}
	$ritorno = remove_query_arg( array( 'tl_esito', 'tl_errore' ), $ritorno );

	$fine = function ( $esito, $errore = '' ) use ( $ritorno ) {
		$arg = array( 'tl_esito' => $esito );
		if ( '' !== $errore ) {
			$arg['tl_errore'] = $errore;
		}
		wp_safe_redirect( add_query_arg( $arg, $ritorno ) . '#tl-modulo' );
		exit;
	};

	// 1. nonce
	if ( ! isset( $_POST['tl_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['tl_nonce'] ) ), TENCONI_FORM_AZIONE ) ) {
		$fine( 'ko', 'sessione' );
	}

	/*
	 * 2. honeypot e 3. tempo minimo. Ai bot si risponde "ok": dire la verita'
	 * insegnerebbe loro come passare. All'utente vero non capita mai.
	 */
	if ( ! empty( $_POST['tl_sito'] ) ) {
		$fine( 'ok' );
	}
	$aperto = isset( $_POST['tl_t'] ) ? (int) $_POST['tl_t'] : 0;
	if ( $aperto && ( time() - $aperto ) < 3 ) {
		$fine( 'ok' );
	}

	// 4. rate limiting: un invio al minuto per IP, senza conservare l'IP in chiaro
	$ip    = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$firma = 'tl_form_' . md5( $ip . wp_salt() );
	if ( get_transient( $firma ) ) {
		$fine( 'ko', 'troppo-veloce' );
	}

	// 5. validazione e 6. sanitizzazione, lato server
	$dati    = array();
	$mancano = array();
	foreach ( tenconi_form_campi() as $chiave => $c ) {
		$grezzo = isset( $_POST[ $chiave ] ) ? wp_unslash( $_POST[ $chiave ] ) : '';
		if ( 'email' === $c['tipo'] ) {
			/*
			 * Si guarda il valore GREZZO prima di sanificare: sanitize_email()
			 * restituisce stringa vuota su un indirizzo malformato, e il campo
			 * finirebbe fra quelli "vuoti" con un messaggio d'errore sbagliato.
			 */
			$val = sanitize_email( $grezzo );
			if ( '' !== trim( (string) $grezzo ) && ! is_email( $val ) ) {
				$fine( 'ko', 'email' );
			}
		} elseif ( 'textarea' === $c['tipo'] ) {
			$val = sanitize_textarea_field( $grezzo );
		} else {
			$val = sanitize_text_field( $grezzo );
		}
		$val = trim( $val );
		if ( $c['obbl'] && '' === $val ) {
			$mancano[] = $c['label'];
		}
		if ( mb_strlen( $val ) > 4000 ) {
			$val = mb_substr( $val, 0, 4000 );
		}
		$dati[ $chiave ] = $val;
	}
	if ( $mancano ) {
		$fine( 'ko', 'campi' );
	}

	// 7. spedizione
	$righe = array();
	foreach ( tenconi_form_campi() as $chiave => $c ) {
		if ( '' !== $dati[ $chiave ] ) {
			$righe[] = $c['label'] . ': ' . $dati[ $chiave ];
		}
	}
	$corpo = implode( "\n", $righe ) . "\n\n--\nInviato dal modulo contatti di " . home_url( '/' );

	$ok = wp_mail(
		tenconi_form_destinatario(),
		'Richiesta dal sito: ' . ( '' !== $dati['ditta'] ? $dati['ditta'] : $dati['email'] ),
		$corpo,
		array(
			'Content-Type: text/plain; charset=UTF-8',
			/* Reply-To e non From: cambiare il From fa finire il messaggio nello spam. */
			'Reply-To: ' . $dati['email'],
		)
	);

	set_transient( $firma, 1, MINUTE_IN_SECONDS );

	$fine( $ok ? 'ok' : 'ko', $ok ? '' : 'invio' );
}
add_action( 'admin_post_nopriv_' . TENCONI_FORM_AZIONE, 'tenconi_form_gestisci' );
add_action( 'admin_post_' . TENCONI_FORM_AZIONE, 'tenconi_form_gestisci' );

/**
 * Il messaggio di esito, leggibile da uno screen reader.
 *
 * @return string HTML.
 */
function tenconi_form_esito() {

	$esito = isset( $_GET['tl_esito'] ) ? sanitize_key( wp_unslash( $_GET['tl_esito'] ) ) : '';
	if ( '' === $esito ) {
		return '';
	}
	$errore = isset( $_GET['tl_errore'] ) ? sanitize_key( wp_unslash( $_GET['tl_errore'] ) ) : '';

	if ( 'ok' === $esito ) {
		$testo = 'Grazie, la richiesta è stata inviata. Vi risponderemo al più presto.';
		$cls   = 'tl-esito--ok';
	} else {
		$mappa = array(
			'campi'         => 'Alcuni campi obbligatori sono vuoti: completateli e riprovate.',
			'email'         => 'L’indirizzo email non è valido: controllatelo e riprovate.',
			'troppo-veloce' => 'Una richiesta è già stata inviata da poco. Attendete un minuto e riprovate.',
			'sessione'      => 'La sessione è scaduta. Ricaricate la pagina e riprovate.',
			'invio'         => 'Non è stato possibile inviare la richiesta. Scriveteci a ' . esc_html( tenconi_form_destinatario() ) . '.',
		);
		$testo = isset( $mappa[ $errore ] ) ? $mappa[ $errore ] : $mappa['invio'];
		$cls   = 'tl-esito--ko';
	}

	return sprintf(
		'<p class="tl-esito %1$s" role="status" tabindex="-1">%2$s</p>',
		esc_attr( $cls ),
		esc_html( $testo )
	);
}
