<?php
/**
 * Redirect legacy, in un solo posto.
 *
 * DOVE AGISCE. Solo su una richiesta che WordPress ha gia' dichiarato 404. Un
 * percorso che il sito serve davvero non passa mai da qui: e' la garanzia
 * strutturale che un redirect non possa oscurare una pagina viva, e la ragione
 * per cui /documenti resta l'archivio dei documenti invece di essere rediretto.
 *
 * PERCHE' UN SOLO SALTO, PER COSTRUZIONE. La destinazione non e' un altro slug
 * legacy: e' il permalink canonico, calcolato da tenconi_resolve() contro il
 * database. Una catena richiederebbe che il permalink canonico fosse a sua volta
 * un 404, cosa che non puo' essere. Per la stessa ragione non esistono cicli.
 *
 * PERCHE' NON PUO' PUNTARE A UN URL INESISTENTE. Se tenconi_resolve() non trova
 * l'oggetto, non si redirige: la richiesta resta un 404 onesto.
 *
 * NESSUN REDIRECT PER EN, DE, FR. WPML e' inattivo e quegli URL non esistono: un
 * redirect verso di essi sarebbe un redirect verso il nulla.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/redirect-map.php';

/**
 * Percorso richiesto, relativo alla radice del sito, senza query e senza slash.
 *
 * In Multisite sottocartella la home e' /tenconi/: il prefisso va tolto, altrimenti
 * nessuna chiave della mappa combacerebbe.
 *
 * @return string
 */
function tenconi_requested_path() {
	$uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
	$uri = (string) wp_parse_url( $uri, PHP_URL_PATH );
	$base = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
	if ( '' !== $base && '/' !== $base && 0 === strpos( $uri, $base ) ) {
		$uri = substr( $uri, strlen( $base ) );
	}
	return trim( rawurldecode( $uri ), '/' );
}

/**
 * Destinazione di un percorso legacy, o '' se non c'e' o non si risolve.
 *
 * @param string $path Percorso relativo.
 * @return string URL assoluto, o ''.
 */
function tenconi_redirect_target( $path ) {
	$path = trim( (string) $path, '/' );
	if ( '' === $path ) {
		return '';
	}
	$mappa = tenconi_redirect_map();
	// Confronto esatto, poi senza distinzione di maiuscole: gli URL legacy erano
	// minuscoli, ma un link esterno puo' arrivare con maiuscole diverse.
	$voce = null;
	if ( isset( $mappa[ $path ] ) ) {
		$voce = $mappa[ $path ];
	} else {
		$basso = strtolower( $path );
		foreach ( $mappa as $k => $v ) {
			if ( strtolower( $k ) === $basso ) {
				$voce = $v;
				break;
			}
		}
	}
	if ( ! $voce || ! function_exists( 'tenconi_resolve' ) ) {
		return '';
	}
	$url = tenconi_resolve( $voce[0], $voce[1] );
	if ( ! $url ) {
		return '';
	}
	// Mai redirigere verso se stessi: sarebbe un ciclo.
	$dest = trim( (string) wp_parse_url( $url, PHP_URL_PATH ), '/' );
	$base = trim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
	if ( '' !== $base && 0 === strpos( $dest, $base . '/' ) ) {
		$dest = substr( $dest, strlen( $base ) + 1 );
	}
	if ( $dest === $path ) {
		return '';
	}
	return $url;
}

/**
 * Applica il redirect, se serve.
 *
 * PRIORITA' 5, PRIMA DI redirect_canonical(). Il gestore girava a priorita' 20 e
 * solo su is_404(), e /energia non arrivava mai a essere servito: esiste un
 * allegato con post_name 'energia' (Energia.png, id 348), il cui permalink
 * secondo WordPress e' proprio /energia/. La richiesta era quindi un SINGOLARE
 * VIVO, non un 404, e redirect_canonical() a priorita' 10 la mandava al file
 * .png prima che il gestore legacy potesse dire la sua.
 *
 * PERCHE' NON SI PUO' USCIRE SU is_singular(). Sarebbe il guard ovvio, e
 * bloccherebbe la correzione: /energia E' un singolare, l'allegato. La collisione
 * fra lo slug di un allegato e uno slug legacy va risolta in favore della mappa,
 * ed e' esattamente il caso che questa funzione deve gestire.
 *
 * COSA RENDE SICURO ANTICIPARLA. Il gate e' la corrispondenza ESATTA con una
 * chiave della mappa, e nessuna delle 76 chiavi e' un percorso vivo: verificato
 * contro i 99 permalink reali del sito, 0 collisioni. In piu' si esce comunque
 * se la query corrente ha trovato una pagina, un singolo CPT, un archivio o una
 * tassonomia: quei quattro non vanno mai oscurati. Gli allegati sono esclusi da
 * quell'elenco di proposito, per la ragione appena detta.
 *
 * Nessun accostamento per slug simili: solo isset() sulla chiave esatta.
 *
 * @return void
 */
function tenconi_do_legacy_redirect() {
	// Contesti in cui non si redirige mai.
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron()
		|| ( defined( 'REST_REQUEST' ) && REST_REQUEST )
		|| ( defined( 'WP_CLI' ) && WP_CLI )
		|| ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) ) {
		return;
	}
	// Solo letture: un POST non si redirige con un 301.
	$metodo = isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( sanitize_key( $_SERVER['REQUEST_METHOD'] ) ) : 'GET';
	if ( 'GET' !== $metodo && 'HEAD' !== $metodo ) {
		return;
	}

	// Corrispondenza ESATTA con una chiave della mappa, e nient'altro.
	$path  = tenconi_requested_path();
	$mappa = tenconi_redirect_map();
	if ( '' === $path || ! isset( $mappa[ $path ] ) ) {
		return;
	}

	// Difesa in profondita': se la query ha trovato un contenuto reale, la
	// richiesta e' legittima e non si tocca. L'unica eccezione e' l'allegato,
	// perche' e' proprio la collisione fra il suo slug e uno slug legacy il caso
	// da risolvere: un allegato non e' una destinazione editoriale.
	if ( ( is_singular() && ! is_attachment() )
		|| is_post_type_archive() || is_tax() || is_category() || is_tag()
		|| is_front_page() || is_home() ) {
		return;
	}

	// La destinazione deve risolversi contro un oggetto WordPress esistente, ed
	// essere diversa dall'URL richiesto. Se no, si lascia la richiesta com'e'.
	$url = tenconi_redirect_target( $path );
	if ( ! $url ) {
		return;
	}

	wp_safe_redirect( $url, 301, 'Tenconi legacy' );
	exit;
}
add_action( 'template_redirect', 'tenconi_do_legacy_redirect', 5 );

/**
 * Stato della mappa: quante voci, quante risolvibili, quali no.
 * Serve alla verifica, non al rendering.
 *
 * @return array
 */
function tenconi_redirect_status() {
	$out = array( 'totale' => 0, 'risolti' => 0, 'non_risolti' => array(), 'voci' => array() );
	foreach ( tenconi_redirect_map() as $da => $v ) {
		$out['totale']++;
		$url = function_exists( 'tenconi_resolve' ) ? tenconi_resolve( $v[0], $v[1] ) : '';
		if ( $url ) {
			$out['risolti']++;
		} else {
			$out['non_risolti'][] = $da;
		}
		$out['voci'][ $da ] = $url;
	}
	return $out;
}
