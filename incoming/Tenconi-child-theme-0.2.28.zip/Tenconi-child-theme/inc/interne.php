<?php
/**
 * PAGINE INTERNE — i pezzi del nuovo sistema, uguali su tutte le pagine.
 *
 * Testata, sezione con galleria, sezione di testo, invito al contatto. Le
 * pagine (aree di attivita', pagine del menu, parco macchine, documenti) li
 * compongono: il disegno vive qui e in assets/css/interne.css, una volta sola.
 *
 * Nessun testo inventato: titoli e gruppi vengono dal menu, introduzioni dal
 * riassunto della pagina, l'immagine grande dalla scheda del menu (che si
 * cambia dal backend, vedi inc/menu-immagini.php).
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Testo dell'interfaccia passato dal sistema di traduzione del sito.
 *
 * @param string $testo  Testo italiano.
 * @param string $chiave Chiave di traduzione.
 * @return string
 */
function tenconi_int_t( $testo, $chiave ) {
	return function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( $testo, $chiave ) : $testo;
}

/**
 * La voce del menu principale con quella chiave: gruppo, titolo, indirizzo.
 *
 * @param string $chiave Chiave di navigazione (es. "team", "parco-macchine").
 * @return array{gruppo:string,titolo:string,url:string}
 */
function tenconi_int_voce( $chiave ) {
	foreach ( tenconi_nav_legacy() as $v ) {
		if ( 'gruppo' !== $v['tipo'] ) {
			continue;
		}
		foreach ( $v['children'] as $f ) {
			if ( $f['key'] === $chiave ) {
				return array(
					'gruppo' => (string) $v['label'],
					'titolo' => (string) $f['label'],
					'url'    => (string) $f['url'],
				);
			}
		}
	}
	return array(
		'gruppo' => '',
		'titolo' => '',
		'url'    => '',
	);
}

/**
 * La testata: etichetta del gruppo, titolo, introduzione, indice, immagine.
 *
 * @param array $a {
 *     @type string $gruppo Etichetta sopra il titolo.
 *     @type string $titolo H1.
 *     @type string $intro  Introduzione (vuota = nessuna).
 *     @type int    $hero   Allegato dell'immagine grande (0 = nessuna).
 *     @type array  $indice Elenco di array( id, titolo, conta ), mostrato se ha almeno due voci.
 * }
 */
function tenconi_int_testa( $a ) {
	$a = wp_parse_args(
		$a,
		array(
			'gruppo' => '',
			'titolo' => '',
			'intro'  => '',
			'hero'   => 0,
			'indice' => array(),
		)
	);
	?>
	<header class="tl-int__testa<?php echo $a['hero'] ? '' : ' tl-int__testa--senza'; ?>">
		<div class="tl-wrap tl-int__testa-in">
			<div class="tl-int__testa-t">
				<?php if ( '' !== $a['gruppo'] ) : ?>
					<p class="tl-int__et"><?php echo esc_html( $a['gruppo'] ); ?></p>
				<?php endif; ?>
				<h1 class="tl-int__h1"><?php echo esc_html( $a['titolo'] ); ?></h1>
				<?php if ( '' !== trim( (string) $a['intro'] ) ) : ?>
					<p class="tl-int__intro"><?php echo esc_html( $a['intro'] ); ?></p>
				<?php endif; ?>

				<?php if ( count( $a['indice'] ) > 1 ) : ?>
					<ol class="tl-int__indice">
						<?php foreach ( array_values( $a['indice'] ) as $n => $v ) : ?>
							<li>
								<a href="#<?php echo esc_attr( $v[0] ); ?>">
									<span><?php echo esc_html( $v[1] ); ?></span>
									<span class="tl-int__conta"><?php echo isset( $v[2] ) && '' !== (string) $v[2] ? esc_html( $v[2] ) : ''; ?></span>
								</a>
							</li>
						<?php endforeach; ?>
					</ol>
				<?php endif; ?>
			</div>

			<?php if ( $a['hero'] ) : ?>
				<figure class="tl-int__hero">
					<?php
					echo wp_get_attachment_image(
						(int) $a['hero'],
						'large',
						false,
						array(
							'alt'           => '',
							'fetchpriority' => 'high',
							'sizes'         => '(max-width: 900px) 100vw, 55vw',
						)
					);
					?>
				</figure>
			<?php endif; ?>
		</div>
	</header>
	<?php
}

/**
 * L'apertura di una sezione: titolo e testo di accompagnamento. Niente numeri
 * d'ordine (tolti su richiesta del cliente: "troppo AI"); $num resta per
 * compatibilita' con chi chiama e non viene stampato.
 *
 * @param string $id     Ancora della sezione.
 * @param int    $num    Numero d'ordine (0 = senza numero).
 * @param string $titolo Titolo della sezione.
 * @param string $elenco Riga di accompagnamento (vuota = nessuna).
 */
function tenconi_int_sez_testa( $id, $num, $titolo, $elenco = '' ) {
	?>
	<div class="tl-int__sez-testa">
		<h2 class="tl-int__h2" id="<?php echo esc_attr( $id ); ?>-t"><?php echo esc_html( $titolo ); ?></h2>
		<?php if ( '' !== trim( (string) $elenco ) ) : ?>
			<p class="tl-int__elenco"><?php echo esc_html( $elenco ); ?></p>
		<?php endif; ?>
	</div>
	<?php
}

/**
 * Una sezione con galleria.
 *
 * @param array $a {
 *     @type string $id       Ancora.
 *     @type int    $num      Numero d'ordine.
 *     @type string $titolo   Titolo della sezione (vuoto = sezione senza testa).
 *     @type string $elenco   Riga di accompagnamento.
 *     @type array  $img      Elenco di array( allegato, didascalia ).
 *     @type string $alt      Testo alternativo di ripiego per le foto senza didascalia.
 *     @type string $formato  "paesaggio" (16:10) o "ritratto" (4:5, per le persone).
 *     @type int    $visibili Quante prima di "Mostra tutte" (0 = tutte).
 * }
 * @return int Fotografie stampate.
 */
function tenconi_int_galleria( $a ) {
	$a = wp_parse_args(
		$a,
		array(
			'id'       => '',
			'num'      => 0,
			'titolo'   => '',
			'elenco'   => '',
			'img'      => array(),
			'alt'      => '',
			'formato'  => 'paesaggio',
			'visibili' => 6,
		)
	);

	$img = array();
	foreach ( (array) $a['img'] as $i ) {
		if ( ! empty( $i[0] ) && tenconi_home_img_ok( (int) $i[0] ) ) {
			$img[] = array( (int) $i[0], isset( $i[1] ) ? (string) $i[1] : '' );
		}
	}
	if ( ! $img ) {
		return 0;
	}
	$extra = $a['visibili'] ? count( $img ) - (int) $a['visibili'] : 0;
	$cls   = 'ritratto' === $a['formato'] ? ' tl-int__gal--ritratto' : '';
	?>
	<section class="tl-int__sez" id="<?php echo esc_attr( $a['id'] ); ?>"<?php echo '' !== $a['titolo'] ? ' aria-labelledby="' . esc_attr( $a['id'] ) . '-t"' : ''; ?> data-tl-int-sez>
		<div class="tl-wrap">
			<?php
			if ( '' !== $a['titolo'] ) {
				tenconi_int_sez_testa( $a['id'], (int) $a['num'], $a['titolo'], $a['elenco'] );
			}
			?>
			<ul class="tl-int__gal<?php echo esc_attr( $cls ); ?>">
				<?php foreach ( $img as $k => $i ) : ?>
					<?php list( $att, $cap ) = $i; ?>
					<li class="tl-int__i<?php echo $a['visibili'] && $k >= $a['visibili'] ? ' tl-int__i--extra' : ''; ?>">
						<figure class="tl-int__f">
							<div class="tl-int__cornice">
								<?php
								echo wp_get_attachment_image(
									$att,
									'medium_large',
									false,
									array(
										'alt'      => '' !== $cap ? $cap : $a['alt'],
										'loading'  => 'lazy',
										'decoding' => 'async',
										'sizes'    => '(max-width: 600px) 100vw, (max-width: 1023px) 50vw, 440px',
									)
								);
								?>
							</div>
							<?php if ( '' !== $cap ) : ?>
								<figcaption class="tl-int__c"><?php echo esc_html( $cap ); ?></figcaption>
							<?php endif; ?>
						</figure>
					</li>
				<?php endforeach; ?>
			</ul>
			<?php if ( $extra > 0 ) : ?>
				<p class="tl-int__altre">
					<button type="button" class="tl-int__btn" data-tl-int-tutte hidden>
						<?php
						/* translators: %d: numero di fotografie in tutto. */
						echo esc_html( sprintf( tenconi_int_t( 'Mostra tutte le %d fotografie', 'tenconi:interne:mostra-tutte' ), count( $img ) ) );
						?>
					</button>
				</p>
			<?php endif; ?>
		</div>
	</section>
	<?php
	return count( $img );
}

/**
 * Quante fotografie pubblicabili ci sono in un elenco.
 *
 * @param array $img Elenco di array( allegato, didascalia ).
 * @return int
 */
function tenconi_int_conta( $img ) {
	$n = 0;
	foreach ( (array) $img as $i ) {
		if ( ! empty( $i[0] ) && tenconi_home_img_ok( (int) $i[0] ) ) {
			++$n;
		}
	}
	return $n;
}

/** L'invito al contatto in fondo alla pagina. */
function tenconi_int_cta() {
	$contatti = get_page_by_path( 'contatti' );
	if ( ! $contatti ) {
		return;
	}
	?>
	<aside class="tl-int__cta">
		<div class="tl-wrap tl-int__cta-in">
			<div>
				<p class="tl-int__et"><?php echo esc_html( tenconi_int_t( 'Contatti', 'tenconi:interne:cta-etichetta' ) ); ?></p>
				<p class="tl-int__cta-t"><?php echo esc_html( tenconi_int_t( 'Parliamo del vostro progetto', 'tenconi:interne:cta-titolo' ) ); ?></p>
			</div>
			<a class="tl-int__btn tl-int__btn--pieno" href="<?php echo esc_url( get_permalink( $contatti ) ); ?>">
				<?php echo esc_html( tenconi_int_t( 'Scriveteci', 'tenconi:interne:cta-pulsante' ) ); ?>
			</a>
		</div>
	</aside>
	<?php
}
