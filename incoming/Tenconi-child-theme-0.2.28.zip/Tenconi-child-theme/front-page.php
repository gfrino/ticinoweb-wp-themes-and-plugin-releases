<?php
/**
 * Homepage — LEGACY PARITY.
 *
 * La struttura E' quella dello screenshot legacy, nell'ordine in cui la si vede:
 *
 *   1  riga di tre media 16:9, con didascalie
 *   2  filetto
 *   3  titolo "LE NOSTRE AREE DI ATTIVITA" e le cinque tavole, 3 + 2
 *   4  filetto
 *   5  due blocchi: PARCO MACCHINE e GESTIONE PROGETTI
 *   6  filetto, poi il footer
 *
 * Nel legacy NON ci sono: eroe, sezione Chi siamo, sezione Qualita, fascia di
 * contatto finale, pulsanti. Erano tutte aggiunte della fase precedente e sono
 * state rimosse. La pagina e' corta perche' il legacy e' corto: 2541 px CSS a
 * viewport 2240, misurati sullo screenshot.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>
<?php
/*
 * L'HERO STA FUORI DA <main>, e non e' un dettaglio: e' il fondale della pagina,
 * l'header ci galleggia sopra, e lo skip link deve portare al contenuto vero —
 * cioe' dopo il filmato, non dentro.
 */
get_template_part( 'template-parts/home/00-hero' );
?>
<main id="main" class="tl-main" tabindex="-1">
	<?php
	/*
	 * LA RIGA DEI TRE MEDIA E' STATA TOLTA su richiesta (27/08/2026): i due
	 * incorporamenti YouTube e il render dei giunti non stanno piu' in home.
	 *
	 * IL TEMPLATE PART NON E' STATO CANCELLATO, ed e' voluto: dentro
	 * template-parts/home/01-media.php c'e' la mappa verificata degli asset legacy
	 * di quella riga — i due identificativi dei filmati, il render ritrovato, il
	 * collegamento al PDF dei giunti — piu' le misure prese dai pixel. Rimetterla
	 * e' una riga; ricostruire quel lavoro sarebbero giorni.
	 *
	 * get_template_part( 'template-parts/home/01-media' );
	 */
	get_template_part( 'template-parts/home/02-aree' );
	get_template_part( 'template-parts/home/03-blocchi' );
	?>
</main>
<?php
get_footer();
