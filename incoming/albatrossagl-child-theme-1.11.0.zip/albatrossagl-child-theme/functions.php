<?php
/** Albatros: presentazione e integrazione dei dati del parent. */
defined('ABSPATH') || exit;

define('ALBATROS_VERSION', '1.11.0');

// A shortcut to the existing parent input, not another image setting.
add_action('admin_bar_menu', function ($bar) {
    if (is_admin() || !is_front_page() || !current_user_can('edit_pages')) {
        return;
    }
    $bar->add_node(array(
        'id' => 'albatros-hero-image',
        'title' => __('Immagine di apertura', 'albatrossagl-child-theme'),
        'href' => admin_url('admin.php?page=ticinoweb-cms#slider'),
    ));
}, 90);

add_action('wp_head', function () {
    if (is_front_page()) {
        printf('<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>', esc_url(get_stylesheet_directory_uri() . '/assets/fonts/manrope-latin.woff2'));
    }
}, 2);

add_action('after_setup_theme', function () {
    load_child_theme_textdomain('albatrossagl-child-theme', get_stylesheet_directory() . '/languages');
    register_nav_menus(array('albatros_primary' => __('Navigazione principale', 'albatrossagl-child-theme')));
    add_theme_support('editor-styles');
    add_editor_style('assets/css/editor.css');
});

add_action('wp_enqueue_scripts', function () {
    // Il parent usa get_stylesheet_uri(): il suo handle carica già style.css del child.
    wp_dequeue_style('poppins-font');
    wp_deregister_style('poppins-font');
    wp_deregister_style('ticinoweb-ai-style');
    wp_enqueue_style('ticinoweb-ai-style', get_stylesheet_uri(), array(), ALBATROS_VERSION);
    wp_enqueue_style('albatros-site', get_stylesheet_directory_uri() . '/assets/css/site.css', array('ticinoweb-ai-style'), ALBATROS_VERSION);
    wp_enqueue_script('albatros-site', get_stylesheet_directory_uri() . '/assets/js/site.js', array(), ALBATROS_VERSION, true);
    if (is_front_page()) {
        wp_enqueue_style('albatros-daylight', get_stylesheet_directory_uri() . '/assets/css/daylight.css', array('albatros-site'), ALBATROS_VERSION);
        wp_enqueue_style('albatros-subscription', get_stylesheet_directory_uri() . '/assets/css/subscription.css', array('albatros-site'), ALBATROS_VERSION);
        wp_enqueue_style('albatros-motion', get_stylesheet_directory_uri() . '/assets/css/motion.css', array('albatros-site'), ALBATROS_VERSION);
        wp_enqueue_style('albatros-hero-stage', get_stylesheet_directory_uri() . '/assets/css/hero-stage.css', array('albatros-motion'), ALBATROS_VERSION);
        wp_enqueue_script('albatros-motion', get_stylesheet_directory_uri() . '/assets/js/motion.js', array('albatros-site'), ALBATROS_VERSION, true);
    }
    wp_enqueue_style('albatros-deck', get_stylesheet_directory_uri() . '/assets/css/service-deck.css', array(is_front_page() ? 'albatros-motion' : 'albatros-site'), ALBATROS_VERSION);
    wp_enqueue_style('albatros-paths', get_stylesheet_directory_uri() . '/assets/css/audience-paths.css', array('albatros-site'), ALBATROS_VERSION);
    wp_enqueue_style('albatros-contact', get_stylesheet_directory_uri() . '/assets/css/contact.css', array('albatros-site'), ALBATROS_VERSION);
    if (is_front_page()) {
        wp_enqueue_style('albatros-journey', get_stylesheet_directory_uri() . '/assets/css/journey.css', array('albatros-hero-stage', 'albatros-paths', 'albatros-contact', 'albatros-deck'), ALBATROS_VERSION);
    }

}, 30);

/** Translation bridge for CMS data; escaping belongs at the output boundary. */
function albatros_text($text, $context) {
    return function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text((string) $text, 'albatros:' . $context) : (string) $text;
}

function albatros_url($fragment = '') {
    $url = home_url('/') . ($fragment !== '' ? '#' . sanitize_title($fragment) : '');
    return function_exists('ticinoweb_frontend_url') ? ticinoweb_frontend_url($url, 'albatros:url:' . $fragment) : $url;
}

function albatros_contact() {
    $contact = function_exists('ticinoweb_get_contact_info') ? ticinoweb_get_contact_info() : array();
    // Older installed parents omit optional CMS fields from their helper.
    foreach (array('phone', 'phone_display', 'email', 'address', 'address_label', 'map_url', 'opening_hours_note', 'vat') as $key) {
        if (empty($contact[$key])) {
            $contact[$key] = get_option('ticinoweb_contact_' . $key, '');
        }
    }
    return $contact;
}

/** Render only Media Library attachments: responsive sizes and no remote hotlinks. */
function albatros_image($url, $size = 'large', $attributes = array()) {
    static $ids = array();
    if (!$url) {
        return '';
    }
    if (!isset($ids[$url])) {
        $ids[$url] = attachment_url_to_postid($url);
    }
    return $ids[$url] ? wp_get_attachment_image($ids[$url], $size, false, $attributes) : '';
}

// The parent CMS documents these tags but this version does not register all of them.
// Supply presentation adapters only when missing; data remain in the parent.
add_action('init', function () {
    foreach (array('ticinoweb_slider' => 'hero', 'ticinoweb_chi_siamo' => 'about', 'ticinoweb_contatti' => 'contact') as $tag => $template) {
        if (!shortcode_exists($tag)) {
            add_shortcode($tag, function () use ($template) {
                ob_start();
                get_template_part('template-parts/' . $template);
                return ob_get_clean();
            });
        }
    }
}, 20);

/** Expand the parent shortcodes with this child's presentation, preserving their inputs. */
add_filter('pre_do_shortcode_tag', function ($output, $tag, $attributes) {
    if ($output !== false) {
        return $output;
    }
    $templates = array(
        'ticinoweb_slider' => 'hero',
        'ticinoweb_services' => 'services',
        'ticinoweb_servizi' => 'services',
        'ticinoweb_chi_siamo' => 'about',
        'ticinoweb_contatti' => 'contact',
    );
    if (!isset($templates[$tag])) {
        return $output;
    }
    ob_start();
    get_template_part('template-parts/' . $templates[$tag]);
    return ob_get_clean();
}, 10, 3);
