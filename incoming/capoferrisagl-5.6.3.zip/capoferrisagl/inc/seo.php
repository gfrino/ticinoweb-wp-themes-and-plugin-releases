<?php
/**
 * Livello SEO del child theme.
 *
 * Il motore SEO (title, description, Open Graph, canonical, schema
 * Organization) è quello del parent: qui non si duplicano i tag, ma si
 * alimentano i campi che il parent già legge (_tw_seo_*) e si aggiunge
 * ciò che manca: breadcrumb e dati strutturati Service.
 *
 * @package Capoferrisagl
 */

if (!defined('ABSPATH')) {
    exit;
}

/* ─────────────────────────────────────────────
   PONTE VERSO IL SEO DEL PARENT
   ───────────────────────────────────────────── */

/**
 * I campi SEO del servizio alimentano i meta letti dal parent.
 */
add_action('save_post_cfs_servizio', 'cfs_sync_service_seo', 20, 2);
function cfs_sync_service_seo($post_id, $post)
{
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    $title = cfs_service_meta($post_id, 'seo_title', '');
    $desc  = cfs_service_meta($post_id, 'seo_desc', '');
    if ($desc === '') {
        $desc = cfs_service_meta($post_id, 'excerpt', '');
    }

    update_post_meta($post_id, '_tw_seo_title', $title !== '' ? $title : $post->post_title);
    update_post_meta($post_id, '_tw_seo_description', wp_strip_all_tags($desc));
    update_post_meta($post_id, '_tw_seo_robots', cfs_service_meta($post_id, 'seo_noindex', '') === '1' ? 'noindex, follow' : 'index, follow');

    $og = (int) cfs_service_meta($post_id, 'seo_image', 0);
    if (!$og) {
        $og = cfs_service_cover($post_id);
    }
    if ($og) {
        update_post_meta($post_id, '_tw_seo_social_image', wp_get_attachment_url($og));
    }
}

/**
 * I campi SEO delle pagine gestite dalle option alimentano i meta della
 * pagina WordPress corrispondente.
 */
add_action('update_option_cfs_home', 'cfs_sync_page_seo', 10, 0);
add_action('update_option_cfs_about', 'cfs_sync_page_seo', 10, 0);
add_action('update_option_cfs_contact', 'cfs_sync_page_seo', 10, 0);
function cfs_sync_page_seo()
{
    $map = array(
        'cfs_home'    => 'home',
        'cfs_about'   => 'chi-siamo',
        'cfs_contact' => 'contatti',
    );

    foreach ($map as $option_key => $slug) {
        $page_id = cfs_page_id($slug);
        if (!$page_id) {
            continue;
        }
        $seo = get_option($option_key, array());
        $seo = is_array($seo) && isset($seo['seo']) ? $seo['seo'] : array();

        if (!empty($seo['title'])) {
            update_post_meta($page_id, '_tw_seo_title', $seo['title']);
        }
        if (!empty($seo['desc'])) {
            update_post_meta($page_id, '_tw_seo_description', wp_strip_all_tags($seo['desc']));
        }
        if (!empty($seo['image'])) {
            update_post_meta($page_id, '_tw_seo_social_image', wp_get_attachment_url((int) $seo['image']));
        }

        // La Home è anche il SEO globale del sito (tW SEO → Generali): un solo input, due destinazioni.
        if ($slug === 'home') {
            if (!empty($seo['title'])) {
                update_option('tw_seo_home_title', $seo['title']);
            }
            if (!empty($seo['desc'])) {
                update_option('tw_seo_description', wp_strip_all_tags($seo['desc']));
            }
        }
    }
}

/**
 * ID delle pagine create dal tema (home, servizi, chi-siamo, contatti…).
 */
function cfs_page_id($slug)
{
    $ids = get_option('cfs_page_ids', array());
    if (!empty($ids[$slug])) {
        return (int) $ids[$slug];
    }
    $page = get_page_by_path($slug);
    return $page ? (int) $page->ID : 0;
}

/**
 * URL di una pagina del tema, con fallback alla home.
 */
function cfs_page_url($slug)
{
    $id = cfs_page_id($slug);
    return $id ? get_permalink($id) : home_url('/');
}

/**
 * Il parent stampa già il canonical: rimuoviamo quello del core per non
 * avere il tag due volte nella stessa pagina.
 */
add_action('after_setup_theme', 'cfs_dedupe_canonical', 99);
function cfs_dedupe_canonical()
{
    if (has_action('wp_head', 'tw_seo_inject_metadata')) {
        remove_action('wp_head', 'rel_canonical');
    }
}

/* ─────────────────────────────────────────────
   BREADCRUMB
   ───────────────────────────────────────────── */

/**
 * Breadcrumb accessibile + dati strutturati BreadcrumbList.
 *
 * @param array $trail Coppie array('label' => ..., 'url' => ...). L'ultimo è la pagina corrente.
 */
function cfs_the_breadcrumb($trail)
{
    $home_label = cfs_settings('breadcrumb_home', __('Home', 'capoferrisagl'));
    array_unshift($trail, array('label' => $home_label, 'url' => home_url('/')));

    $items = array();
    echo '<nav class="cfs-breadcrumb" aria-label="' . esc_attr__('Percorso di navigazione', 'capoferrisagl') . '"><ol>';
    $total = count($trail);
    foreach ($trail as $index => $crumb) {
        $is_last = ($index === $total - 1);
        echo '<li>';
        if (!$is_last && !empty($crumb['url'])) {
            printf('<a href="%s">%s</a>', esc_url($crumb['url']), esc_html($crumb['label']));
        } else {
            printf('<span aria-current="page">%s</span>', esc_html($crumb['label']));
        }
        echo '</li>';

        $items[] = array(
            '@type'    => 'ListItem',
            'position' => $index + 1,
            'name'     => $crumb['label'],
            'item'     => !empty($crumb['url']) ? $crumb['url'] : get_permalink(),
        );
    }
    echo '</ol></nav>';

    echo '<script type="application/ld+json">' . wp_json_encode(array(
        '@context'        => 'https://schema.org',
        '@type'           => 'BreadcrumbList',
        'itemListElement' => $items,
    )) . '</script>';
}

/* ─────────────────────────────────────────────
   DATI STRUTTURATI SERVIZI
   ───────────────────────────────────────────── */

add_action('wp_footer', 'cfs_service_schema', 20);
function cfs_service_schema()
{
    if (!is_singular('cfs_servizio')) {
        return;
    }

    $post_id = get_the_ID();
    $company = cfs_company();
    $cover   = cfs_service_cover($post_id);

    $data = array(
        '@context'    => 'https://schema.org',
        '@type'       => 'Service',
        'name'        => get_the_title($post_id),
        'description' => wp_strip_all_tags(cfs_service_meta($post_id, 'excerpt', '')),
        'url'         => get_permalink($post_id),
        'provider'    => array(
            '@type'     => 'LocalBusiness',
            'name'      => $company['name'],
            'telephone' => $company['phone'],
            'email'     => $company['email'],
            'address'   => array_filter(array(
                '@type'           => 'PostalAddress',
                'streetAddress'   => $company['street'],
                'postalCode'      => $company['postal_code'],
                'addressLocality' => $company['city'],
                'addressCountry'  => $company['country'],
            )),
        ),
    );

    if ($cover) {
        $data['image'] = wp_get_attachment_url($cover);
    }

    echo '<script type="application/ld+json">' . wp_json_encode(array_filter($data)) . '</script>';
}

/* ─────────────────────────────────────────────
   ANTEPRIMA DELLE BOZZE
   ───────────────────────────────────────────── */

/** Le anteprime non devono finire nei motori di ricerca. */
add_action('wp_head', 'cfs_noindex_preview', 0);
function cfs_noindex_preview()
{
    if (is_preview() || is_404() || is_search()) {
        echo '<meta name="robots" content="noindex, nofollow">' . "\n";
    }
}
