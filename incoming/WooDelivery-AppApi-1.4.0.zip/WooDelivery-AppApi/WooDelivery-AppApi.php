<?php

/**
 * Plugin Name: WooDelivery App API
 * Plugin URI: https://ticinoweb.com/
 * Description: Collega l'app mobile al plugin di consegna e ritiro CodeRockz: orari, metodi di spedizione e punti di ritiro. Aggiunge ai punti di ritiro la foto e l'orario, che i clienti vedono nell'app, e li si compila direttamente dalle impostazioni di CodeRockz.
 * Version: 1.4.0
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Author: Giovanni Frino
 * Author URI: https://ticinoweb.com/
 * Company: ticinoWEB
 * Text Domain: woodelivery-appapi
 * Domain Path: /languages
 * License: Proprietary — Licenza d'uso esclusiva ticinoWEB
 * Update URI: https://github.com/gfrino/ticinoweb-wp-themes-and-plugin-releases
 */

if (!defined('ABSPATH')) {
    exit;
}

define('WDAAPI_VERSION', '1.4.0');
define('WDAAPI_FILE', __FILE__);
// Version of the bundled includes/tw-release-updater.php (keep in sync with its header).
define('WDAAPI_RELEASE_UPDATER_VERSION', '1.2.0');

require_once __DIR__ . '/includes/tw-release-updater.php';
require_once __DIR__ . '/includes/class-wdaapi-pickup-details.php';
WDAApi_Pickup_Details::init();

/** Install/refresh the shared release updater as a mu-plugin (same as the other ticinoWEB plugins). */
function wdaapi_install_release_updater() {
    if (!class_exists('TW_Release_Updater') || TW_Release_Updater::mu_is_current(WDAAPI_RELEASE_UPDATER_VERSION)) {
        return;
    }
    if (get_site_transient('wdaapi_release_updater_failed')) {
        return;
    }
    $result = TW_Release_Updater::install_mu(__DIR__ . '/includes/tw-release-updater.php');
    if (is_wp_error($result)) {
        set_site_transient('wdaapi_release_updater_failed', $result->get_error_message(), 12 * HOUR_IN_SECONDS);
    }
}
add_action('admin_init', function () {
    if (current_user_can(is_multisite() ? 'manage_network_plugins' : 'activate_plugins')) {
        wdaapi_install_release_updater();
    }
}, 20);


// require plugin_dir_path(__DIR__) . "/coderockz-woocommerce-delivery-date-time-pro/coderockz-woo-delivery.php";
class WDAApi
{

    protected $WooD = NULL;
    protected $settings = [];
    protected $return, $post, $current_time;
    public function __construct()
    {
        // $this->WDP = new Coderockz_Woo_Delivery_Public();

        // $this->WooD = new Coderockz_Woo_Delivery();
        // $this->WooD->plugin_public = new Coderockz_Woo_Delivery_Public($this->WooD->get_plugin_name(), $this->WooD->get_version());
        $option = [];

        $option['delivery_option_settings'] = get_option('coderockz_woo_delivery_option_delivery_settings');
        $option['delivery_date_settings'] = get_option('coderockz_woo_delivery_date_settings');
        $option['pickup_date_settings'] = get_option('coderockz_woo_delivery_pickup_date_settings');
        $option['delivery_time_settings'] = get_option('coderockz_woo_delivery_time_settings');
        $option['pickup_time_settings'] = get_option('coderockz_woo_delivery_pickup_settings');
        $option['delivery_pickup_settings'] = get_option('coderockz_woo_delivery_pickup_location_settings');
        $option['additional_field_settings'] = get_option('coderockz_woo_delivery_additional_field_settings');
        $option['processing_time_settings'] = get_option('coderockz_woo_delivery_processing_time_settings');
        $option['delivery_custom_time_slot_fee'] = get_option('coderockz_woo_delivery_time_slot_settings');
        $option['delivery_custom_pickup_time_slot_fee'] = get_option('coderockz_woo_delivery_pickup_slot_settings');



        // print_r($option['delivery_custom_time_slot_fee']);

        // $option['custom_time_slot_settings'] = get_option('coderockz_woo_delivery_time_slot_settings');
        // coderockz_woo_delivery_process_custom_time_slot_settings


        // $option = get_option('coderockz_woo_delivery_option_delivery_settings');
        // $option = array_merge(get_option('coderockz_woo_delivery_date_settings'),$option);
        // $option = array_merge(get_option('coderockz_woo_delivery_pickup_date_settings'),$option);
        // $option = array_merge(get_option('coderockz_woo_delivery_time_settings'),$option);
        // $option = array_merge(get_option('coderockz_woo_delivery_pickup_settings'),$option);

        // $option = array_merge(get_option('coderockz_woo_delivery_option_time_pickup'),$option);
        add_filter(
            'jwt_auth_expire',
            function ($expire, $issued_at) {
                // Set $expire to 2 years.
                $expire = time() + (30 * 24 * 60 * 60);

                return $expire;
            },
            10,
            2
        );

        $this->settings = $option;

        add_action('rest_api_init', function () {
            register_rest_route('wdapi/v1', '/get-pickup-time', array(
                'methods' => 'POST',
                'callback' => [$this, 'getPickupTime']
            ));
        });

        add_action('rest_api_init', function () {
            register_rest_route('wdapi/v1', '/get-delivery-time', array(
                'methods' => 'POST',
                'callback' => [$this, 'getDeliveryTime']
            ));
        });

        add_action('rest_api_init', function () {
            register_rest_route('wdapi/v1', '/settings', array(
                'methods' => 'GET',
                'callback' => [$this, 'settings']
            ));
        });

        add_action('rest_api_init', function () {
            register_rest_route('wdapi/v1', '/get-shipping-methods', array(
                'methods' => 'GET',
                'callback' => [$this, 'get_shipping_methods']
            ));
        });

        add_action('rest_api_init', function () {
            register_rest_route('wdapi/v1', '/delivery-restriction', array(
                'methods' => 'GET',
                'callback' => [$this, 'getDeliveryRestriction']
            ));
        });
    }

    public function settings()
    {
        return wp_send_json($this->settings);
    }

    public function getDeliveryRestriction()
    {
        $deliverySettings = $this->settings['delivery_option_settings'];
        $response = array(
            'enabled' => isset($deliverySettings['enable_delivery_restriction']) ? (bool)$deliverySettings['enable_delivery_restriction'] : false,
            'minimum_amount' => isset($deliverySettings['minimum_amount_cart_restriction']) ? $deliverySettings['minimum_amount_cart_restriction'] : '0',
            'include_discount' => isset($deliverySettings['calculating_include_discount']) ? (bool)$deliverySettings['calculating_include_discount'] : false,
            'include_tax' => isset($deliverySettings['calculating_include_tax']) ? (bool)$deliverySettings['calculating_include_tax'] : false,
            'notice' => isset($deliverySettings['delivery_restriction_notice']) ? $deliverySettings['delivery_restriction_notice'] : '',
        );
        return wp_send_json($response);
    }

    public function get_shipping_methods(){
      

        $zones = WC_Shipping_Zones::get_zones();
        $selected = [] ;
        foreach ($zones as $zone) {
            foreach ($zone['zone_locations'] as $pin) {
                    foreach ($zone['shipping_methods'] as $row) {
                        $selected[$row->id][] = $row->instance_settings;
                    }
                
            }
        }
        return $selected;
    }
    
    public function addFilter()
    {
        if (!$this->checkIsDayActive()) {

            $this->return = [];
        }
        $this->removeTimeBlockIfDateIsToday();
        $this->sortTiming();
    }
    public function sortTiming()
    {
        $return = [];
        $returns = [];
        foreach ($this->return as $index => $row) {
            $return[(int)implode("", explode(":", $row[0]))] = $row;
        }
        //         print_r($return);
        $dd = array_keys($return);
        sort($dd);
        foreach ($dd as $row) {
            $returns[$row] = $return[$row];
        }
        $this->return = array_values($returns);
    }

    public function removeTimeBlockIfDateIsToday()
    {
        $tz = $this->settings['delivery_time_settings']['store_location_timezone'];
        $timestamp = time();
        // echo $this->current_time;
        $time = (int)strtotime($this->post['date']) + (int)$this->current_time;
        // echo date('d-m-y H:i:s', $time);
        // echo (int)$this->current_time;
        $dt = new DateTime('now', new DateTimeZone($tz)); //first argument "must" be a string
        // echo $dt->format('d.m.Y H:i:s');
        $dt->setTimestamp($timestamp);

        if (strtotime($this->post['date']) === strtotime($dt->format('d.m.Y'))) {

            // echo $dt->format('d.m.Y, H:i');
            $Hour = $dt->format('H');
            $Minutes = $dt->format('i');
            // print_r($this->return);
            foreach ($this->return as $index => $row) {
                // echo $Hour . " >= " . (int)substr($row[0], 0, 2);
                // echo $Minutes . " >= " . (int)substr($row[0], 4, 5);
                if ($Hour >= (int)substr($row[0], 0, 2) && $Minutes >= (int)substr($row[0], 4, 5) && $Hour >= (int)substr($row[1], 0, 2) && $Minutes >= (int)substr($row[1], 4, 5)) {
                    unset($this->return[$index]);
                }
                // 				echo "<br>";
                // 				echo $Hour." >= ".(int)substr($row[1],0,2);
                if ($Hour >= (int)substr($row[1], 0, 2) && $Minutes >= (int)substr($row[1], 5, 5)) {
                    unset($this->return[$index]);
                }
                // 				echo "<br>";
            }
            $this->return = array_values($this->return);
        } elseif (strtotime($this->post['date']) < strtotime($dt->format('d.m.Y'))) {
            $this->return = [];
        }
    }

    public function checkIsDayActive()
    {
        if ($this->post['type'] == "getPickupTime" && in_array(date('w', strtotime($this->post['date'])), explode(",", $this->settings['pickup_date_settings']['pickup_days']))) {
            return true;
        } elseif ($this->post['type'] == "getDeliveryTime" && in_array(date('w', strtotime($this->post['date'])), explode(",", $this->settings['delivery_date_settings']['delivery_days']))) {
            return true;
        }
        return false;
    }

    public function getDeliveryTime()
    {
        $data = $_POST;
        $data['type'] = 'getDeliveryTime';
        $data['_ajax_nonce'] = wp_create_nonce('coderockz_woo_delivery_nonce');
        $data['action'] = 'coderockz_woo_delivery_get_orders';
        $this->post = $data;
        // 		print_r($this->post);
        // print_r($this->settings);
        $pickup = $this->checkTimeSlot($data);
        $pickup = json_decode($pickup['data'], true);
        $this->current_time = $pickup['current_time'];
        // print_r($pickup);
        //         $array_diff = array_diff($pickup['no_state_zip_disable_timeslot_all']['nostatezip'], $pickup['delivery_times']);
        //         $this->return = $this->modifyArray($array_diff);
        $deliveryTime = [];
        $daynum = date('w', strtotime($this->post['date']));
        foreach ($pickup['slot_disable_for'] as $key => $value) {
            if (!in_array($daynum, $value)) {
                $deliveryTime[] = $key;
            }
        }
        // print_r($deliveryTime);
        // print_r($pickup);
        if (!empty($pickup['state_zip_disable_timeslot_all']['postcode'])) {
            $array_diff = array_diff($deliveryTime, $pickup['state_zip_disable_timeslot_all']['postcode']);
        } else {
            $array_diff = $deliveryTime;
        }

        $this->return = $this->modifyArray($array_diff);
        // 		print_r($this->return);
        // 		echo "===";
        //         $this->return = $deliveryTime;
        $this->addFilter();
        return $this->return;
    }

    public function getPickupTime()
    {
        $data = $_POST;
        $data['type'] = 'getPickupTime';
        $data['_ajax_nonce'] = wp_create_nonce('coderockz_woo_delivery_nonce');
        $data['action'] = 'coderockz_woo_delivery_get_orders_pickup';
        $this->post = $data;
        $pickup = $this->checkTimeSlot($data);

        $pickup = json_decode($pickup['data'], true);
        // print_r($pickup);
        $this->current_time = $pickup['current_time'];
        //         $this->return = $this->modifyArray($array_diff);
        $deliveryTime = [];
        $daynum = date('w', strtotime($this->post['date']));
        foreach ($pickup['pickup_slot_disable_for'] as $key => $value) {
            if (!in_array($daynum, $value)) {
                $deliveryTime[] = $key;
            }
        }
        
        $array_diff = $deliveryTime; // FIX: removed buggy array_diff with pickup_delivery_times
        
        $this->return = $this->modifyArray($array_diff);
        $this->addFilter();
        return $this->return;
    }

    function modifyArray($array)
    {
        $return = [];
        foreach ($array as $row) {
            $return[] = explode(" - ", $row);
        }
        return $return;
    }

    public function checkTimeSlot($data)
    {
        $cache_key = 'wood_slots_cache_' . md5(json_encode($data));
        $cached_response = get_transient($cache_key);
        if (false !== $cached_response && !empty($cached_response)) {
            return $cached_response;
        }

        $curl = curl_init();
        $host = parse_url(home_url(), PHP_URL_HOST);
        
        // Ensure the ajax_url hits localhost, but some environments redirect 127.0.0.1.
        // To be safe, we use the actual home_url() + /wp-admin/admin-ajax.php
        $ajax_url = home_url('/wp-admin/admin-ajax.php');
        
        curl_setopt_array($curl, array(
            CURLOPT_URL => $ajax_url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 3,
            CURLOPT_TIMEOUT => 25, // Increased timeout to 25s
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => http_build_query($data),
            // Adding SSL verify false just in case local resolution has certificate issues
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_SSL_VERIFYPEER => false,
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        
        $parsed = json_decode($response, true);
        
        // If cURL failed or returned invalid JSON, return a safe fallback to prevent fatal errors
        if (!$parsed || !isset($parsed['data'])) {
            $fallback = array('data' => json_encode(array(
                "disable_for_max_delivery_dates" => [],
                "disable_for_max_pickup_dates" => [],
                "disable_delivery_date_passed_time" => [],
                "disable_pickup_date_passed_time" => [],
                "slot_disable_for" => [],
                "pickup_slot_disable_for" => [],
                "state_zip_disable_timeslot_all" => [],
                "no_state_zip_disable_timeslot_all" => [],
                "pickup_delivery_times" => [],
                "delivery_times" => [],
                "current_time" => (wp_date("G")*60)+wp_date("i")
            )));
            return $fallback;
        }

        // Cache the successful response for 3 minutes (180 seconds)
        set_transient($cache_key, $parsed, 180);

        return $parsed;
    }
}

// if (class_exists('Coderockz_Woo_Delivery')) {
$WDAApi = new WDAApi();

// }


// echo json_encode(get_declared_classes());