<?php

class coderokz_overload
{

    protected $helper, $chosen_methods;
    public function __construct()
    {
        $this->helper = new Coderockz_Woo_Delivery_Helper();
        $this->chosen_methods = "flat:14";
        WC()->frontend_includes();
        WC()->session = new WC_Session_Handler();
        WC()->session->set('_chosen_shipping_methods', array(
            'local_pickup: 26'
        ));
    }
    public function coderockz_woo_delivery_get_orders()
    {

        // check_ajax_referer('coderockz_woo_delivery_nonce');

        $delivery_time_settings = get_option('coderockz_woo_delivery_time_settings');

        // if any timezone data is saved, set default timezone with the data
        $timezone = $this->helper->get_the_timezone();
        date_default_timezone_set($timezone);
        $order_status_keys = array_keys(wc_get_order_statuses());
        $order_status = ['partially-paid'];
        foreach ($order_status_keys as $order_status_key) {
            $order_status[] = substr($order_status_key, 3);
        }
        $order_status = array_diff($order_status, ['cancelled', 'failed', 'refunded']);

        $disabled_current_time_slot = (isset($delivery_time_settings['disabled_current_time_slot']) && !empty($delivery_time_settings['disabled_current_time_slot'])) ? $delivery_time_settings['disabled_current_time_slot'] : false;

        $custom_time_slot_settings = get_option('coderockz_woo_delivery_time_slot_settings');
        $enable_custom_time_slot = (isset($custom_time_slot_settings['enable_custom_time_slot']) && !empty($custom_time_slot_settings['enable_custom_time_slot'])) ? $custom_time_slot_settings['enable_custom_time_slot'] : false;

        $formated_selected_date = date("Y-m-d", strtotime($this->helper->weekday_conversion($this->helper->date_conversion(sanitize_text_field($_POST['date']), "delivery"), "delivery")));

        if (isset($_POST['onlyDeliveryTime']) && $_POST['onlyDeliveryTime']) {
            $order_date = date("Y-m-d", strtotime(sanitize_text_field($formated_selected_date)));
            $args = array(
                'limit' => -1,
                'date_created' => $order_date,
                'delivery_type' => 'delivery',
                'status' => $order_status,
                'return' => 'ids'
            );
        } else {
            $delivery_date = date("Y-m-d", strtotime(sanitize_text_field($formated_selected_date)));
            $args = array(
                'limit' => -1,
                'delivery_date' => $delivery_date,
                'status' => $order_status,
                'return' => 'ids'
            );
        }

        $order_ids = wc_get_orders($args);

        $given_state = (isset($_POST['givenState']) && $_POST['givenState'] != "") ? sanitize_text_field($_POST['givenState']) : "";
        $given_zip = (isset($_POST['givenZip']) && $_POST['givenZip'] != "") ? sanitize_text_field($_POST['givenZip']) : "";
        $response_delivery = [];
        $delivery_times = [];
        $max_order_per_slot = [];
        $slot_disable_for = [];
        $slot_disable_for_sameday = [];
        $slot_disable_for_excceed = [];
        $slot_open_specific_date = [];
        $slot_close_specific_date = [];
        $disable_timeslot = [];
        $state_zip_disable_timeslot_all = [];
        $no_state_zip_disable_timeslot_all = [];
        if ($enable_custom_time_slot && isset($custom_time_slot_settings['time_slot']) && count($custom_time_slot_settings['time_slot']) > 0) {
            foreach ($custom_time_slot_settings['time_slot'] as $key => $individual_time_slot) {

                if ($individual_time_slot['enable']) {
                    $times = explode('-', $key);
                    if ($individual_time_slot['enable_split']) {
                        $times = explode('-', $key);
                        $x = $times[0];
                        while ($times[1] > $x) {
                            $second_time = $x + $individual_time_slot['split_slot_duration'];
                            if ($second_time > $times[1]) {
                                $second_time = $times[1];
                            }
                            $disable = $individual_time_slot['disable_for'];
                            if ($individual_time_slot['enable_single_splited_slot']) {
                                $slot_disable_for[date("H:i", mktime(0, (int)$x))] = $disable;
                            } else {
                                $slot_disable_for[date("H:i", mktime(0, (int)$x)) . ' - ' . date("H:i", mktime(0, (int)$second_time))] = $disable;
                            }

                            $x = $second_time;
                        }
                    } else {
                        $times = explode('-', $key);
                        $disable = $individual_time_slot['disable_for'];
                        if ($individual_time_slot['enable_single_slot']) {
                            $slot_disable_for[date("H:i", mktime(0, (int)$times[0]))] = $disable;
                        } else {
                            $slot_disable_for[date("H:i", mktime(0, (int)$times[0])) . ' - ' . date("H:i", mktime(0, (int)$times[1]))] = $disable;
                        }
                    }

                    if (isset($individual_time_slot['hide_time_slot_current_date']) && $individual_time_slot['hide_time_slot_current_date'] != "") {

                        $times = explode('-', $key);
                        if ($individual_time_slot['enable_split']) {
                            $times = explode('-', $key);
                            $x = $times[0];
                            while ($times[1] > $x) {
                                $second_time = $x + $individual_time_slot['split_slot_duration'];
                                if ($second_time > $times[1]) {
                                    $second_time = $times[1];
                                }
                                if ($individual_time_slot['enable_single_splited_slot']) {
                                    $slot_disable_for_sameday[] = date("H:i", mktime(0, (int)$x));
                                } else {
                                    $slot_disable_for_sameday[] = date("H:i", mktime(0, (int)$x)) . ' - ' . date("H:i", mktime(0, (int)$second_time));
                                }

                                $x = $second_time;
                            }
                        } else {
                            $times = explode('-', $key);
                            if ($individual_time_slot['enable_single_slot']) {
                                $slot_disable_for_sameday[] = date("H:i", mktime(0, (int)$times[0]));
                            } else {
                                $slot_disable_for_sameday[] = date("H:i", mktime(0, (int)$times[0])) . ' - ' . date("H:i", mktime(0, (int)$times[1]));
                            }
                        }
                    }

                    $current_time = (date("G") * 60) + date("i");

                    if (isset($individual_time_slot['timeslot_closing_time']) && $individual_time_slot['timeslot_closing_time'] != "") {

                        if ($current_time >= $individual_time_slot['timeslot_closing_time']) {

                            $times = explode('-', $key);
                            if ($individual_time_slot['enable_split']) {
                                $times = explode('-', $key);
                                $x = $times[0];
                                while ($times[1] > $x) {
                                    $second_time = $x + $individual_time_slot['split_slot_duration'];
                                    if ($second_time > $times[1]) {
                                        $second_time = $times[1];
                                    }
                                    if ($individual_time_slot['enable_single_splited_slot']) {
                                        $slot_disable_for_excceed[] = date("H:i", mktime(0, (int)$x));
                                    } else {
                                        $slot_disable_for_excceed[] = date("H:i", mktime(0, (int)$x)) . ' - ' . date("H:i", mktime(0, (int)$second_time));
                                    }

                                    $x = $second_time;
                                }
                            } else {
                                $times = explode('-', $key);
                                if ($individual_time_slot['enable_single_slot']) {
                                    $slot_disable_for_excceed[] = date("H:i", mktime(0, (int)$times[0]));
                                } else {
                                    $slot_disable_for_excceed[] = date("H:i", mktime(0, (int)$times[0])) . ' - ' . date("H:i", mktime(0, (int)$times[1]));
                                }
                            }
                        }
                    }


                    if (isset($individual_time_slot['only_specific_date']) && $individual_time_slot['only_specific_date'] != "") {

                        $times = explode('-', $key);
                        if ($individual_time_slot['enable_split']) {
                            $times = explode('-', $key);
                            $x = $times[0];
                            while ($times[1] > $x) {
                                $second_time = $x + $individual_time_slot['split_slot_duration'];
                                if ($second_time > $times[1]) {
                                    $second_time = $times[1];
                                }
                                if ($individual_time_slot['enable_single_splited_slot']) {
                                    $slot_open_specific_date[date("H:i", mktime(0, (int)$x))][] = explode(",", $individual_time_slot['only_specific_date']);
                                } else {
                                    $slot_open_specific_date[date("H:i", mktime(0, (int)$x)) . ' - ' . date("H:i", mktime(0, (int)$second_time))][] = explode(",", $individual_time_slot['only_specific_date']);
                                }

                                $x = $second_time;
                            }
                        } else {
                            $times = explode('-', $key);
                            if ($individual_time_slot['enable_single_slot']) {
                                $slot_open_specific_date[date("H:i", mktime(0, (int)$times[0]))][] = explode(",", $individual_time_slot['only_specific_date']);
                            } else {
                                $slot_open_specific_date[date("H:i", mktime(0, (int)$times[0])) . ' - ' . date("H:i", mktime(0, (int)$times[1]))][] = explode(",", $individual_time_slot['only_specific_date']);
                            }
                        }
                    }

                    if (isset($individual_time_slot['only_specific_date_close']) && $individual_time_slot['only_specific_date_close'] != "") {

                        $times = explode('-', $key);
                        if ($individual_time_slot['enable_split']) {
                            $times = explode('-', $key);
                            $x = $times[0];
                            while ($times[1] > $x) {
                                $second_time = $x + $individual_time_slot['split_slot_duration'];
                                if ($second_time > $times[1]) {
                                    $second_time = $times[1];
                                }
                                if ($individual_time_slot['enable_single_splited_slot']) {
                                    $slot_close_specific_date[date("H:i", mktime(0, (int)$x))][] = explode(",", $individual_time_slot['only_specific_date_close']);
                                } else {
                                    $slot_close_specific_date[date("H:i", mktime(0, (int)$x)) . ' - ' . date("H:i", mktime(0, (int)$second_time))][] = explode(",", $individual_time_slot['only_specific_date_close']);
                                }

                                $x = $second_time;
                            }
                        } else {
                            $times = explode('-', $key);
                            if ($individual_time_slot['enable_single_slot']) {
                                $slot_close_specific_date[date("H:i", mktime(0, (int)$times[0]))][] = explode(",", $individual_time_slot['only_specific_date_close']);
                            } else {
                                $slot_close_specific_date[date("H:i", mktime(0, (int)$times[0])) . ' - ' . date("H:i", mktime(0, (int)$times[1]))][] = explode(",", $individual_time_slot['only_specific_date_close']);
                            }
                        }
                    }

                    if (isset($individual_time_slot['more_settings']) && !empty($individual_time_slot['more_settings']) && $individual_time_slot['more_settings'] == 'zone') {


                        if (isset($individual_time_slot['disable_zone']) && !empty($individual_time_slot['disable_zone'])) {

                            global $woocommerce;

                            $current_zone_id = '';

                            $chosen_methods = $this->chosen_methods;
                            if (isset($chosen_methods)) {
                                $shipping_id = $chosen_methods[0];
                                $packages    = $woocommerce->cart->get_shipping_packages();
                                foreach ($packages as $i => $package) {
                                    if (isset($package['rates']) && isset($package['rates'][$shipping_id])) {
                                        $package = $package;
                                        break;
                                    }
                                }
                                $shipping_zone = WC_Shipping_Zones::get_zone_matching_package($package);
                                $current_zone_id = (int)$shipping_zone->get_id();
                            }

                            foreach ($individual_time_slot['disable_zone'] as $zone_key => $zone_id) {

                                if ($zone_id == $current_zone_id) {
                                    $times = explode('-', $key);
                                    if ($individual_time_slot['enable_split']) {
                                        $x = $times[0];
                                        while ($times[1] > $x) {
                                            $second_time = $x + $individual_time_slot['split_slot_duration'];
                                            if ($second_time > $times[1]) {
                                                $second_time = $times[1];
                                            }
                                            $disable = $individual_time_slot['disable_for'];
                                            if ($individual_time_slot['enable_single_splited_slot']) {
                                                $disable_timeslot['postcode'][] = date("H:i", mktime(0, (int)$x));
                                            } else {
                                                $disable_timeslot['postcode'][] = date("H:i", mktime(0, (int)$x)) . ' - ' . date("H:i", mktime(0, (int)$second_time));
                                            }

                                            $x = $second_time;
                                        }
                                    } else {
                                        if ($individual_time_slot['enable_single_slot']) {
                                            $disable_timeslot['postcode'][] = date("H:i", mktime(0, (int)$times[0]));
                                        } else {
                                            $disable_timeslot['postcode'][] = date("H:i", mktime(0, (int)$times[0])) . ' - ' . date("H:i", mktime(0, (int)$times[1]));
                                        }
                                    }

                                    break;
                                }
                            }
                        }

                        /*if(isset($individual_time_slot['disable_postcode']) && !empty($individual_time_slot['disable_postcode'])) {

                          foreach($individual_time_slot['disable_postcode'] as $postcode_value) {
                              $multistep_postal_code = false;
                              $between_postal_code = false;
                            if (stripos($postcode_value,'...') !== false) {
                                $range = explode('...', $postcode_value);
                                if(stripos($given_zip,'-') !== false && stripos($range[0],'-') !== false && stripos($range[1],'-') !== false) {

                                    $sub_range_one = (int)str_replace("-", "", $range[0]);
                                    $sub_range_two = (int)str_replace("-", "", $range[1]);

                                    $given_zip_range = (int)str_replace("-", "", $given_zip);

                                    if($this->helper->number_between($given_zip_range, $sub_range_two, $sub_range_one)) {
                                        $multistep_postal_code = true;
                                    }

                                } elseif(stripos($range[0],'*') !== false && stripos($range[1],'*') !== false) {

                                    $sub_range_one = (int)str_replace("*", "", $range[0]);
                                    $sub_range_two = (int)str_replace("*", "", $range[1]);

                                    if($this->helper->number_between($this->helper->starts_with_starting_numeric($given_zip), $sub_range_two, $sub_range_one)) {
                                        $multistep_postal_code = true;
                                    }

                                } elseif(stripos($given_zip,'-') === false && stripos($range[0],'-') === false && stripos($range[1],'-') === false) {
                                    $alphabet_code = preg_replace("/[^a-zA-Z]+/", "", $range[0]);
                                    $range[0] = preg_replace("/[^0-9]+/", "", $range[0]);
                                    $range[1] = preg_replace("/[^0-9]+/", "", $range[1]);
                                    if($alphabet_code != "" && $this->helper->starts_with(strtolower($given_zip), strtolower($alphabet_code)) && $this->helper->number_between(preg_replace("/[^0-9]/", "", $given_zip ), $range[1], $range[0])) {
                                        $between_postal_code = true;
                                    } elseif($alphabet_code == "" && $this->helper->number_between($given_zip, $range[1], $range[0])) {
                                        $between_postal_code = true;
                                    }
                                }
                            }

                            if (substr($postcode_value, -1) == '*' && stripos($postcode_value,'...') == "") {
                                if($this->helper->starts_with($given_zip,substr($postcode_value, 0, -1)) || $this->helper->starts_with(strtolower($given_zip),substr(strtolower($postcode_value), 0, -1)) || $this->helper->starts_with(strtoupper($given_zip),substr(strtoupper($postcode_value), 0, -1))) {
                                    $times = explode('-', $key);
                                    if($individual_time_slot['enable_split']) {
                                        $x = $times[0];
                                        while($times[1]>$x) {
                                            $second_time = $x+$individual_time_slot['split_slot_duration'];
                                            if($second_time > $times[1]) {
                                                $second_time = $times[1];
                                            }
                                            $disable = $individual_time_slot['disable_for'];
                                            if($individual_time_slot['enable_single_splited_slot']) {
                                                $disable_timeslot['postcode'][] = date("H:i", mktime(0, (int)$x));
                                            } else {
                                                $disable_timeslot['postcode'][] = date("H:i", mktime(0, (int)$x)) . ' - ' . date("H:i", mktime(0, (int)$second_time));
                                            }

                                            $x = $second_time;
                                        }
                                    } else {
                                        if($individual_time_slot['enable_single_slot']) {
                                            $disable_timeslot['postcode'][] = date("H:i", mktime(0, (int)$times[0]));
                                        } else {
                                            $disable_timeslot['postcode'][] = date("H:i", mktime(0, (int)$times[0])) . ' - ' . date("H:i", mktime(0, (int)$times[1]));
                                        }
                                    }
                                }
                            } elseif($multistep_postal_code || $between_postal_code || ($postcode_value == $given_zip || str_replace(" ","",$postcode_value) == $given_zip || strtolower($postcode_value) == strtolower($given_zip) || str_replace(" ","",strtolower($postcode_value)) == strtolower($given_zip) )) {

                                $times = explode('-', $key);
                                if($individual_time_slot['enable_split']) {
                                    $x = $times[0];
                                    while($times[1]>$x) {
                                        $second_time = $x+$individual_time_slot['split_slot_duration'];
                                        if($second_time > $times[1]) {
                                            $second_time = $times[1];
                                        }
                                        $disable = $individual_time_slot['disable_for'];
                                        if($individual_time_slot['enable_single_splited_slot']) {
                                            $disable_timeslot['postcode'][] = date("H:i", mktime(0, (int)$x));
                                        } else {
                                            $disable_timeslot['postcode'][] = date("H:i", mktime(0, (int)$x)) . ' - ' . date("H:i", mktime(0, (int)$second_time));
                                        }

                                        $x = $second_time;
                                    }
                                } else {
                                    if($individual_time_slot['enable_single_slot']) {
                                        $disable_timeslot['postcode'][] = date("H:i", mktime(0, (int)$times[0]));
                                    } else {
                                        $disable_timeslot['postcode'][] = date("H:i", mktime(0, (int)$times[0])) . ' - ' . date("H:i", mktime(0, (int)$times[1]));
                                    }
                                }
                            }
                        }
                      } else {
                          if((isset($individual_time_slot['disable_state']) && !empty($individual_time_slot['disable_state']) && in_array($given_state,$individual_time_slot['disable_state']))){
                              $times = explode('-', $key);

                            if($individual_time_slot['enable_split']) {

                                $x = $times[0];
                                while($times[1]>$x) {
                                    $second_time = $x+$individual_time_slot['split_slot_duration'];
                                    if($second_time > $times[1]) {
                                        $second_time = $times[1];
                                    }
                                    $disable = $individual_time_slot['disable_for'];
                                    if($individual_time_slot['enable_single_splited_slot']) {
                                        $disable_timeslot['state'][] = date("H:i", mktime(0, (int)$x));
                                    } else {
                                        $disable_timeslot['state'][] = date("H:i", mktime(0, (int)$x)) . ' - ' . date("H:i", mktime(0, (int)$second_time));
                                    }

                                    $x = $second_time;
                                }
                            } else {

                                if($individual_time_slot['enable_single_slot']) {
                                    $disable_timeslot['state'][] = date("H:i", mktime(0, (int)$times[0]));
                                } else {
                                    $disable_timeslot['state'][] = date("H:i", mktime(0, (int)$times[0])) . ' - ' . date("H:i", mktime(0, (int)$times[1]));
                                }

                            }
                          }
                      }*/
                    } else {


                        if ((isset($individual_time_slot['disable_state']) && !empty($individual_time_slot['disable_state']) && in_array($given_state, $individual_time_slot['disable_state']))) {
                            $times = explode('-', $key);

                            if ($individual_time_slot['enable_split']) {

                                $x = $times[0];
                                while ($times[1] > $x) {
                                    $second_time = $x + $individual_time_slot['split_slot_duration'];
                                    if ($second_time > $times[1]) {
                                        $second_time = $times[1];
                                    }
                                    $disable = $individual_time_slot['disable_for'];
                                    if ($individual_time_slot['enable_single_splited_slot']) {
                                        $disable_timeslot['state'][] = date("H:i", mktime(0, (int)$x));
                                    } else {
                                        $disable_timeslot['state'][] = date("H:i", mktime(0, (int)$x)) . ' - ' . date("H:i", mktime(0, (int)$second_time));
                                    }

                                    $x = $second_time;
                                }
                            } else {

                                if ($individual_time_slot['enable_single_slot']) {
                                    $disable_timeslot['state'][] = date("H:i", mktime(0, (int)$times[0]));
                                } else {
                                    $disable_timeslot['state'][] = date("H:i", mktime(0, (int)$times[0])) . ' - ' . date("H:i", mktime(0, (int)$times[1]));
                                }
                            }
                        }

                        if (isset($individual_time_slot['disable_postcode']) && !empty($individual_time_slot['disable_postcode'])) {

                            foreach ($individual_time_slot['disable_postcode'] as $postcode_value) {
                                $multistep_postal_code = false;
                                $between_postal_code = false;
                                /*$postcode_range = [];*/
                                if (stripos($postcode_value, '...') !== false) {
                                    $range = explode('...', $postcode_value);
                                    if (stripos($given_zip, '-') !== false && stripos($range[0], '-') !== false && stripos($range[1], '-') !== false) {

                                        $sub_range_one = (int)str_replace("-", "", $range[0]);
                                        $sub_range_two = (int)str_replace("-", "", $range[1]);

                                        $given_zip_range = (int)str_replace("-", "", $given_zip);

                                        if ($this->helper->number_between($given_zip_range, $sub_range_two, $sub_range_one)) {
                                            $multistep_postal_code = true;
                                        }
                                    } elseif (stripos($range[0], '*') !== false && stripos($range[1], '*') !== false) {

                                        $sub_range_one = (int)str_replace("*", "", $range[0]);
                                        $sub_range_two = (int)str_replace("*", "", $range[1]);

                                        if ($this->helper->number_between($this->helper->starts_with_starting_numeric($given_zip), $sub_range_two, $sub_range_one)) {
                                            $multistep_postal_code = true;
                                        }
                                    } elseif (stripos($given_zip, '-') === false && stripos($range[0], '-') === false && stripos($range[1], '-') === false) {
                                        $alphabet_code = preg_replace("/[^a-zA-Z]+/", "", $range[0]);
                                        $range[0] = preg_replace("/[^0-9]+/", "", $range[0]);
                                        $range[1] = preg_replace("/[^0-9]+/", "", $range[1]);
                                        if ($alphabet_code != "" && $this->helper->starts_with(strtolower($given_zip), strtolower($alphabet_code)) && $this->helper->number_between(preg_replace("/[^0-9]/", "", $given_zip), $range[1], $range[0])) {
                                            $between_postal_code = true;
                                        } elseif ($alphabet_code == "" /*&& is_numeric($given_zip)*/ && $this->helper->number_between($given_zip, $range[1], $range[0])) {
                                            $between_postal_code = true;
                                        }
                                    }
                                }
                                if (substr($postcode_value, -1) == '*' && stripos($postcode_value, '...') == "") {
                                    if ($this->helper->starts_with($given_zip, substr($postcode_value, 0, -1)) || $this->helper->starts_with(strtolower($given_zip), substr(strtolower($postcode_value), 0, -1)) || $this->helper->starts_with(strtoupper($given_zip), substr(strtoupper($postcode_value), 0, -1))) {
                                        $times = explode('-', $key);
                                        if ($individual_time_slot['enable_split']) {
                                            $x = $times[0];
                                            while ($times[1] > $x) {
                                                $second_time = $x + $individual_time_slot['split_slot_duration'];
                                                if ($second_time > $times[1]) {
                                                    $second_time = $times[1];
                                                }
                                                $disable = $individual_time_slot['disable_for'];
                                                if ($individual_time_slot['enable_single_splited_slot']) {
                                                    $disable_timeslot['postcode'][] = date("H:i", mktime(0, (int)$x));
                                                } else {
                                                    $disable_timeslot['postcode'][] = date("H:i", mktime(0, (int)$x)) . ' - ' . date("H:i", mktime(0, (int)$second_time));
                                                }

                                                $x = $second_time;
                                            }
                                        } else {
                                            if ($individual_time_slot['enable_single_slot']) {
                                                $disable_timeslot['postcode'][] = date("H:i", mktime(0, (int)$times[0]));
                                            } else {
                                                $disable_timeslot['postcode'][] = date("H:i", mktime(0, (int)$times[0])) . ' - ' . date("H:i", mktime(0, (int)$times[1]));
                                            }
                                        }
                                    }
                                } elseif ($multistep_postal_code || $between_postal_code || ($postcode_value == $given_zip || str_replace(" ", "", $postcode_value) == $given_zip || strtolower($postcode_value) == strtolower($given_zip) || str_replace(" ", "", strtolower($postcode_value)) == strtolower($given_zip))) {
                                    $times = explode('-', $key);
                                    if ($individual_time_slot['enable_split']) {
                                        $x = $times[0];
                                        while ($times[1] > $x) {
                                            $second_time = $x + $individual_time_slot['split_slot_duration'];
                                            if ($second_time > $times[1]) {
                                                $second_time = $times[1];
                                            }
                                            $disable = $individual_time_slot['disable_for'];
                                            if ($individual_time_slot['enable_single_splited_slot']) {
                                                $disable_timeslot['postcode'][] = date("H:i", mktime(0, (int)$x));
                                            } else {
                                                $disable_timeslot['postcode'][] = date("H:i", mktime(0, (int)$x)) . ' - ' . date("H:i", mktime(0, (int)$second_time));
                                            }

                                            $x = $second_time;
                                        }
                                    } else {
                                        if ($individual_time_slot['enable_single_slot']) {
                                            $disable_timeslot['postcode'][] = date("H:i", mktime(0, (int)$times[0]));
                                        } else {
                                            $disable_timeslot['postcode'][] = date("H:i", mktime(0, (int)$times[0])) . ' - ' . date("H:i", mktime(0, (int)$times[1]));
                                        }
                                    }
                                }
                            }
                        }
                    }


                    if ((isset($individual_time_slot['disable_state']) && !empty($individual_time_slot['disable_state']))) {
                        $times = explode('-', $key);
                        if ($individual_time_slot['enable_split']) {
                            $x = $times[0];
                            while ($times[1] > $x) {
                                $second_time = $x + $individual_time_slot['split_slot_duration'];
                                if ($second_time > $times[1]) {
                                    $second_time = $times[1];
                                }
                                $disable = $individual_time_slot['disable_for'];
                                if ($individual_time_slot['enable_single_splited_slot']) {
                                    $state_zip_disable_timeslot_all['state'][] = date("H:i", mktime(0, (int)$x));
                                } else {
                                    $state_zip_disable_timeslot_all['state'][] = date("H:i", mktime(0, (int)$x)) . ' - ' . date("H:i", mktime(0, (int)$second_time));
                                }

                                $x = $second_time;
                            }
                        } else {
                            if ($individual_time_slot['enable_single_slot']) {
                                $state_zip_disable_timeslot_all['state'][] = date("H:i", mktime(0, (int)$times[0]));
                            } else {
                                $state_zip_disable_timeslot_all['state'][] = date("H:i", mktime(0, (int)$times[0])) . ' - ' . date("H:i", mktime(0, (int)$times[1]));
                            }
                        }
                    }

                    if ((isset($individual_time_slot['disable_postcode']) && !empty($individual_time_slot['disable_postcode']))) {
                        $times = explode('-', $key);
                        if ($individual_time_slot['enable_split']) {
                            $x = $times[0];
                            while ($times[1] > $x) {
                                $second_time = $x + $individual_time_slot['split_slot_duration'];
                                if ($second_time > $times[1]) {
                                    $second_time = $times[1];
                                }
                                $disable = $individual_time_slot['disable_for'];
                                if ($individual_time_slot['enable_single_splited_slot']) {
                                    $state_zip_disable_timeslot_all['postcode'][] = date("H:i", mktime(0, (int)$x));
                                } else {
                                    $state_zip_disable_timeslot_all['postcode'][] = date("H:i", mktime(0, (int)$x)) . ' - ' . date("H:i", mktime(0, (int)$second_time));
                                }

                                $x = $second_time;
                            }
                        } else {
                            if ($individual_time_slot['enable_single_slot']) {
                                $state_zip_disable_timeslot_all['postcode'][] = date("H:i", mktime(0, (int)$times[0]));
                            } else {
                                $state_zip_disable_timeslot_all['postcode'][] = date("H:i", mktime(0, (int)$times[0])) . ' - ' . date("H:i", mktime(0, (int)$times[1]));
                            }
                        }
                    } else {
                        $times = explode('-', $key);
                        if ($individual_time_slot['enable_split']) {
                            $x = $times[0];
                            while ($times[1] > $x) {
                                $second_time = $x + $individual_time_slot['split_slot_duration'];
                                if ($second_time > $times[1]) {
                                    $second_time = $times[1];
                                }
                                $disable = $individual_time_slot['disable_for'];
                                if ($individual_time_slot['enable_single_splited_slot']) {
                                    $no_state_zip_disable_timeslot_all['nostatezip'][] = date("H:i", mktime(0, (int)$x));
                                } else {
                                    $no_state_zip_disable_timeslot_all['nostatezip'][] = date("H:i", mktime(0, (int)$x)) . ' - ' . date("H:i", mktime(0, (int)$second_time));
                                }

                                $x = $second_time;
                            }
                        } else {
                            if ($individual_time_slot['enable_single_slot']) {
                                $no_state_zip_disable_timeslot_all['nostatezip'][] = date("H:i", mktime(0, (int)$times[0]));
                            } else {
                                $no_state_zip_disable_timeslot_all['nostatezip'][] = date("H:i", mktime(0, (int)$times[0])) . ' - ' . date("H:i", mktime(0, (int)$times[1]));
                            }
                        }
                    }
                }
            }
        } else {
            $time_settings = get_option('coderockz_woo_delivery_time_settings');
            $enable_delivery_time = (isset($time_settings['enable_delivery_time']) && !empty($time_settings['enable_delivery_time'])) ? $time_settings['enable_delivery_time'] : false;
            if ($enable_delivery_time) {
                $x = (int)$time_settings['delivery_time_starts'];
                $each_time_slot = (isset($time_settings['each_time_slot']) && !empty($time_settings['each_time_slot'])) ? (int)$time_settings['each_time_slot'] : (int)$time_settings['delivery_time_ends'] - (int)$time_settings['delivery_time_starts'];
                while ((int)$time_settings['delivery_time_ends'] > $x) {
                    $second_time = $x + $each_time_slot;
                    if ($second_time > (int)$time_settings['delivery_time_ends']) {
                        $second_time = (int)$time_settings['delivery_time_ends'];
                    }
                    $no_state_zip_disable_timeslot_all['nostatezip'][] = date("H:i", mktime(0, (int)$x)) . ' - ' . date("H:i", mktime(0, (int)$second_time));
                    $x = $second_time;
                }
            }
        }

        $free_up_slot_for_delivery_completed = (isset($delivery_time_settings['free_up_slot_for_delivery_completed']) && !empty($delivery_time_settings['free_up_slot_for_delivery_completed'])) ? $delivery_time_settings['free_up_slot_for_delivery_completed'] : false;


        foreach ($order_ids as $order) {
            $date = get_post_meta($order, "delivery_date", true);
            $time = get_post_meta($order, "delivery_time", true);

            if ((isset($date) && isset($time)) || isset($time)) {
                if ($time != "as-soon-as-possible") {

                    if (!$free_up_slot_for_delivery_completed) {
                        $delivery_times[] = $time;
                    } else {
                        if (!metadata_exists('post', $order, 'delivery_status')) {
                            $delivery_times[] = $time;
                        }
                    }
                }
            }
        }

        $unique_delivery_times = array_unique($delivery_times, false);
        $unique_delivery_times = array_values($unique_delivery_times);

        if ($enable_custom_time_slot) {
            if (isset($custom_time_slot_settings['time_slot']) && count($custom_time_slot_settings['time_slot']) > 0) {

                foreach ($custom_time_slot_settings['time_slot'] as $key => $individual_time_slot) {

                    if ($individual_time_slot['enable']) {
                        $key = preg_replace('/-/', ',', $key);

                        $key_array = explode(",", $key);

                        $max_order = (isset($individual_time_slot['max_order']) && $individual_time_slot['max_order'] != "") ? sanitize_text_field($individual_time_slot['max_order']) : "";

                        if ($individual_time_slot['enable_split']) {
                            $x = $key_array[0];
                            while ($key_array[1] > $x) {
                                $second_time = $x + $individual_time_slot['split_slot_duration'];
                                if ($second_time > $key_array[1]) {
                                    $second_time = $key_array[1];
                                }
                                if ($individual_time_slot['enable_single_splited_slot']) {
                                    if (in_array(date("H:i", mktime(0, (int)$x)), $unique_delivery_times)) {
                                        $max_order_per_slot[date("H:i", mktime(0, (int)$x))] = (int)$max_order;
                                    }
                                } else {
                                    if (in_array(date("H:i", mktime(0, (int)$x)) . ' - ' . date("H:i", mktime(0, (int)$second_time)), $unique_delivery_times)) {
                                        $max_order_per_slot[date("H:i", mktime(0, (int)$x)) . ' - ' . date("H:i", mktime(0, (int)$second_time))] = (int)$max_order;
                                    }
                                }

                                $x = $second_time;
                            }
                        } else {
                            if ($individual_time_slot['enable_single_slot']) {

                                if (in_array(date("H:i", mktime(0, (int)$key_array[0])), $unique_delivery_times)) {
                                    $max_order_per_slot[date("H:i", mktime(0, (int)$key_array[0]))] = (int)$max_order;
                                }
                            } else {
                                if (in_array(date("H:i", mktime(0, (int)$key_array[0])) . ' - ' . date("H:i", mktime(0, (int)$key_array[1])), $unique_delivery_times)) {
                                    $max_order_per_slot[date("H:i", mktime(0, (int)$key_array[0])) . ' - ' . date("H:i", mktime(0, (int)$key_array[1]))] = (int)$max_order;
                                }
                            }
                        }
                    }
                }
            }
        } else {

            $time_settings = get_option('coderockz_woo_delivery_time_settings');
            $enable_delivery_time = (isset($time_settings['enable_delivery_time']) && !empty($time_settings['enable_delivery_time'])) ? $time_settings['enable_delivery_time'] : false;
            if ($enable_delivery_time) {
                $max_order = (isset($time_settings['max_order_per_slot']) && $time_settings['max_order_per_slot'] != "") ? sanitize_text_field($time_settings['max_order_per_slot']) : "";
                $x = (int)$time_settings['delivery_time_starts'];
                $each_delivery_slot = (isset($time_settings['each_time_slot']) && !empty($time_settings['each_time_slot'])) ? (int)$time_settings['each_time_slot'] : (int)$time_settings['delivery_time_ends'] - (int)$time_settings['delivery_time_starts'];
                while ((int)$time_settings['delivery_time_ends'] > $x) {
                    $second_time = $x + $each_delivery_slot;
                    if ($second_time > (int)$time_settings['delivery_time_ends']) {
                        $second_time = (int)$time_settings['delivery_time_ends'];
                    }
                    if (in_array(date("H:i", mktime(0, (int)$x)) . ' - ' . date("H:i", mktime(0, (int)$second_time)), $unique_delivery_times)) {
                        $max_order_per_slot[date("H:i", mktime(0, (int)$x)) . ' - ' . date("H:i", mktime(0, (int)$second_time))] = (int)$max_order;
                    }
                    $x = $second_time;
                }
            }
        }

        $response_delivery = [
            "delivery_times" => $delivery_times,
            "max_order_per_slot" => $max_order_per_slot,
            "slot_disable_for" => $slot_disable_for,
            'disabled_current_time_slot' => $disabled_current_time_slot,
            'disable_timeslot' => $disable_timeslot,
            'state_zip_disable_timeslot_all' => $state_zip_disable_timeslot_all,
            'no_state_zip_disable_timeslot_all' => $no_state_zip_disable_timeslot_all,
            'slot_disable_for_sameday' => $slot_disable_for_sameday,
            'slot_disable_for_excceed' => $slot_disable_for_excceed,
            'slot_open_specific_date' => $slot_open_specific_date,
            'slot_close_specific_date' => $slot_close_specific_date
        ];

        $formated_date = date('Y-m-d H:i:s', strtotime(sanitize_text_field($formated_selected_date)));
        $formated_date = new DateTime($formated_date);
        $formated_date = $formated_date->format("w");

        $current_time = (date("G") * 60) + date("i");

        $delivery_fee_settings = get_option('coderockz_woo_delivery_fee_settings');

        $enable_conditional_delivery_fee = isset($delivery_fee_settings['enable_conditional_delivery_fee']) && !empty($delivery_fee_settings['enable_conditional_delivery_fee']) ? $delivery_fee_settings['enable_conditional_delivery_fee'] : false;
        $have_conditional_delivery = false;
        $only_conditional_delivery_for_fee = false;
        $conditional_delivery_fee_duration = "";
        $disable_inter_timeslot_conditional = false;
        $have_conditional_delivery_with_shipping_method = false;
        if ($enable_conditional_delivery_fee && (isset($delivery_fee_settings['conditional_delivery_time_starts']) && ($delivery_fee_settings['conditional_delivery_time_starts'] != '' || $delivery_fee_settings['conditional_delivery_time_starts'] == 0)) && (isset($delivery_fee_settings['conditional_delivery_time_ends']) && $delivery_fee_settings['conditional_delivery_time_ends'] != '') && ($current_time >= (int)$delivery_fee_settings['conditional_delivery_time_starts'] && (int)$delivery_fee_settings['conditional_delivery_time_ends'] >= $current_time) && (isset($delivery_fee_settings['conditional_delivery_fee_duration']) && !empty($delivery_fee_settings['conditional_delivery_fee_duration'])) && ((isset($delivery_fee_settings['conditional_delivery_fee']) && !empty($delivery_fee_settings['conditional_delivery_fee'])) || (isset($delivery_fee_settings['conditional_delivery_shipping_method']) && !empty($delivery_fee_settings['conditional_delivery_shipping_method'])))) {
            $have_conditional_delivery = true;
            $conditional_delivery_fee_duration = (int)$delivery_fee_settings['conditional_delivery_fee_duration'];
            $disable_inter_timeslot_conditional = (isset($delivery_fee_settings['disable_inter_timeslot_conditional']) && !empty($delivery_fee_settings['disable_inter_timeslot_conditional'])) ? $delivery_fee_settings['disable_inter_timeslot_conditional'] : false;
        }

        if ($enable_conditional_delivery_fee && (isset($delivery_fee_settings['conditional_delivery_time_starts']) && ($delivery_fee_settings['conditional_delivery_time_starts'] != '' || $delivery_fee_settings['conditional_delivery_time_starts'] == 0)) && (isset($delivery_fee_settings['conditional_delivery_time_ends']) && $delivery_fee_settings['conditional_delivery_time_ends'] != '') && ($current_time >= (int)$delivery_fee_settings['conditional_delivery_time_starts'] && (int)$delivery_fee_settings['conditional_delivery_time_ends'] >= $current_time) && (isset($delivery_fee_settings['conditional_delivery_fee_duration']) && !empty($delivery_fee_settings['conditional_delivery_fee_duration'])) && (isset($delivery_fee_settings['conditional_delivery_fee']) && !empty($delivery_fee_settings['conditional_delivery_fee'])) && date('Y-m-d', strtotime(sanitize_text_field($formated_selected_date))) == date('Y-m-d', time())) {
            $only_conditional_delivery_for_fee = true;
        }

        if ($enable_conditional_delivery_fee && (isset($delivery_fee_settings['conditional_delivery_time_starts']) && ($delivery_fee_settings['conditional_delivery_time_starts'] != '' || $delivery_fee_settings['conditional_delivery_time_starts'] == 0)) && (isset($delivery_fee_settings['conditional_delivery_time_ends']) && $delivery_fee_settings['conditional_delivery_time_ends'] != '') && ($current_time >= (int)$delivery_fee_settings['conditional_delivery_time_starts'] && (int)$delivery_fee_settings['conditional_delivery_time_ends'] >= $current_time) && (isset($delivery_fee_settings['conditional_delivery_fee_duration']) && !empty($delivery_fee_settings['conditional_delivery_fee_duration'])) && isset($delivery_fee_settings['conditional_delivery_shipping_method']) && !empty($delivery_fee_settings['conditional_delivery_shipping_method'])) {
            $have_conditional_delivery_with_shipping_method = true;
        }



        $response_for_all = [
            "formated_selected_date" => $formated_selected_date,
            "formated_date" => $formated_date,
            "current_time" => $current_time,
            "have_conditional_delivery" => $have_conditional_delivery,
            "conditional_delivery_fee_duration" => $conditional_delivery_fee_duration,
            "disable_inter_timeslot_conditional" => $disable_inter_timeslot_conditional,
            'only_conditional_delivery_for_fee' => $only_conditional_delivery_for_fee,
            'have_conditional_delivery_with_shipping_method' => $have_conditional_delivery_with_shipping_method
        ];

        return $response = array_merge($response_delivery, $response_for_all);

        // $response = json_encode($response);
        // wp_send_json_success($response);
    }
}
