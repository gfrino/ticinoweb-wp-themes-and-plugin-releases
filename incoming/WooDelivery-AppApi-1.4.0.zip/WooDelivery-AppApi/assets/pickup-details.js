/**
 * Adds "Pickup time" and "Photo" to every pickup point of the CodeRockz settings
 * page, with a live preview of how the point looks in the app. The values travel
 * with CodeRockz' own save request (same buttons, same page).
 */
(function ($) {
    'use strict';

    var cfg = window.twWdapiPld;
    if (!cfg) {
        return;
    }
    var t = cfg.i18n;
    var NAME = '.coderockz-woo-delivery-pickup-location-name';
    var URL_FIELD = '.coderockz-woo-delivery-pickup-location-url';
    var SAVE_BTN = '.coderockz-woo-delivery-custom-pickup-location-saving';

    function esc(s) {
        return $('<div>').text(s == null ? '' : String(s)).html();
    }

    function blockHtml() {
        return '' +
            '<div class="tw-pld">' +
            '  <div class="tw-pld__head">' +
            '    <span class="dashicons dashicons-smartphone"></span>' +
            '    <strong>' + esc(t.heading) + '</strong>' +
            '    <span class="tw-pld__sub">' + esc(t.headingHelp) + '</span>' +
            '  </div>' +
            '  <div class="tw-pld__grid">' +
            '    <div class="tw-pld__fields">' +
            '      <div class="coderockz-woo-delivery-form-group">' +
            '        <label class="coderockz-woo-delivery-form-label">' + esc(t.timeLabel) + '</label>' +
            '        <input type="text" class="tw-pld__time coderockz-woo-delivery-input-field" maxlength="' + cfg.maxTime + '" placeholder="' + esc(t.timePlaceholder) + '">' +
            '        <p class="tw-pld__help">' + esc(t.timeHelp) + '</p>' +
            '      </div>' +
            '      <div class="coderockz-woo-delivery-form-group">' +
            '        <label class="coderockz-woo-delivery-form-label">' + esc(t.photoLabel) + '</label>' +
            '        <div class="tw-pld__photo">' +
            '          <button type="button" class="tw-pld__drop" aria-label="' + esc(t.choosePhoto) + '">' +
            '            <img class="tw-pld__thumb" alt="" hidden>' +
            '            <span class="tw-pld__empty"><span class="dashicons dashicons-format-image"></span>' + esc(t.choosePhoto) + '</span>' +
            '          </button>' +
            '          <div class="tw-pld__photo-actions">' +
            '            <button type="button" class="button tw-pld__change">' + esc(t.choosePhoto) + '</button>' +
            '            <a href="#" class="tw-pld__remove" hidden>' + esc(t.removePhoto) + '</a>' +
            '          </div>' +
            '        </div>' +
            '        <input type="hidden" class="tw-pld__image-id" value="0">' +
            '      </div>' +
            '    </div>' +
            '    <div class="tw-pld__preview-col">' +
            '      <span class="tw-pld__preview-label">' + esc(t.previewLabel) + '</span>' +
            '      <div class="tw-pld__card">' +
            '        <div class="tw-pld__card-img"><img alt="" hidden><span class="dashicons dashicons-format-image"></span></div>' +
            '        <div class="tw-pld__card-body">' +
            '          <div class="tw-pld__card-name"></div>' +
            '          <div class="tw-pld__card-time" hidden><span class="dashicons dashicons-clock"></span><span></span></div>' +
            '          <div class="tw-pld__card-map" hidden><span class="dashicons dashicons-location"></span>' + esc(t.showOnMap) + '</div>' +
            '        </div>' +
            '      </div>' +
            '    </div>' +
            '  </div>' +
            '  <p class="tw-pld__saved">' + esc(t.savedHint) + '</p>' +
            '</div>';
    }

    function panelName(panel) {
        return $.trim(panel.find(NAME).first().val() || '');
    }

    function refresh($b) {
        var panel = $b.parent();
        var name = panelName(panel);
        var time = $.trim($b.find('.tw-pld__time').val());
        var url = $b.data('imageUrl') || '';
        var hasMap = $.trim(panel.find(URL_FIELD).first().val() || '') !== '';

        var $thumb = $b.find('.tw-pld__thumb');
        var $empty = $b.find('.tw-pld__empty');
        var $cardImg = $b.find('.tw-pld__card-img img');
        var $cardIcon = $b.find('.tw-pld__card-img .dashicons');
        if (url) {
            $thumb.attr('src', url).prop('hidden', false);
            $empty.hide();
            $cardImg.attr('src', url).prop('hidden', false);
            $cardIcon.hide();
            $b.find('.tw-pld__remove').prop('hidden', false);
            $b.find('.tw-pld__change').text(t.changePhoto);
        } else {
            $thumb.prop('hidden', true).removeAttr('src');
            $empty.show();
            $cardImg.prop('hidden', true).removeAttr('src');
            $cardIcon.show();
            $b.find('.tw-pld__remove').prop('hidden', true);
            $b.find('.tw-pld__change').text(t.choosePhoto);
        }
        $b.find('.tw-pld__card-name').text(name || t.namePlaceholder).toggleClass('is-placeholder', !name);
        $b.find('.tw-pld__card-time').prop('hidden', !time).find('span:last').text(time);
        $b.find('.tw-pld__card-map').prop('hidden', !hasMap);
    }

    function openMedia($b) {
        var frame = wp.media({
            title: t.mediaTitle,
            button: { text: t.mediaButton },
            library: { type: 'image' },
            multiple: false
        });
        frame.on('select', function () {
            var a = frame.state().get('selection').first().toJSON();
            var size = a.sizes && (a.sizes.medium || a.sizes.thumbnail || a.sizes.full);
            $b.find('.tw-pld__image-id').val(a.id);
            $b.data('imageUrl', size ? size.url : a.url);
            refresh($b);
        });
        frame.open();
    }

    function init() {
        $(SAVE_BTN).each(function () {
            var btn = $(this);
            var panel = btn.parent();
            if (panel.children('.tw-pld').length) {
                return;
            }
            var $b = $(blockHtml());
            btn.before($b);

            var saved = cfg.details[panelName(panel)] || { time_slot: '', image_id: 0, image_url: '' };
            $b.find('.tw-pld__time').val(saved.time_slot);
            $b.find('.tw-pld__image-id').val(saved.image_id || 0);
            $b.data('imageUrl', saved.image_url || '');
            refresh($b);

            $b.on('input', '.tw-pld__time', function () { refresh($b); });
            panel.on('input', NAME + ',' + URL_FIELD, function () { refresh($b); });
            $b.on('click', '.tw-pld__drop, .tw-pld__change', function (e) {
                e.preventDefault();
                openMedia($b);
            });
            $b.on('click', '.tw-pld__remove', function (e) {
                e.preventDefault();
                $b.find('.tw-pld__image-id').val(0);
                $b.data('imageUrl', '');
                refresh($b);
            });
        });
    }

    // Our values ride on CodeRockz' own save requests (Save Changes and the
    // enable switch), so there is only ever one Save for the person to press.
    $.ajaxPrefilter(function (options) {
        if (typeof options.data !== 'string' || options.data.indexOf('action=coderockz_woo_delivery_enable_and_save_pickup_location') === -1) {
            return;
        }
        var params = new URLSearchParams(options.data);
        var name = $.trim(params.get('pickupLocationName') || '');
        var $match = $();
        $('.tw-pld').each(function () {
            if (panelName($(this).parent()) === name) {
                $match = $(this);
                return false;
            }
        });
        if (!$match.length) {
            return;
        }
        options.data += '&tw_pld_present=1' +
            '&tw_pld_time_slot=' + encodeURIComponent($.trim($match.find('.tw-pld__time').val())) +
            '&tw_pld_image_id=' + encodeURIComponent($match.find('.tw-pld__image-id').val() || 0);
    });

    $(init);
})(jQuery);
