<?php
/**
 * Pickup point details (photo + pickup time) shown in the mobile app.
 *
 * The two extra fields are injected into the existing CodeRockz "Pickup Location"
 * settings page, next to the fields people already know, and are saved by the
 * very same buttons (no second page, no second Save). They live in an option of
 * our own, so CodeRockz updates never touch them, and they are merged into the
 * response of /wp-json/getPickupLocations/allLocations that the app reads.
 *
 * Renaming a point in CodeRockz moves its extra data with it; deleting a point
 * removes its extra data. Nothing is ever lost silently.
 *
 * @package woodelivery-appapi
 */

if (!defined('ABSPATH')) {
    exit;
}

class WDAApi_Pickup_Details
{
    const OPTION = 'tw_wdapi_pickup_location_details';
    const PAGE = 'coderockz-woo-delivery-settings';
    const SAVE_ACTION = 'coderockz_woo_delivery_enable_and_save_pickup_location';
    const DELETE_ACTION = 'coderockz_woo_delivery_delete_pickup_location';
    const MAX_TIME_LENGTH = 80;

    public static function init()
    {
        // Priority 1: run before CodeRockz' own handler, which ends the request.
        add_action('wp_ajax_' . self::SAVE_ACTION, [__CLASS__, 'on_save'], 1);
        add_action('wp_ajax_' . self::DELETE_ACTION, [__CLASS__, 'on_delete'], 1);
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue']);
        add_filter('rest_post_dispatch', [__CLASS__, 'merge_into_rest'], 10, 3);
        add_action('init', [__CLASS__, 'load_textdomain']);
    }

    public static function load_textdomain()
    {
        load_plugin_textdomain('woodelivery-appapi', false, dirname(plugin_basename(WDAAPI_FILE)) . '/languages');
    }

    /** All saved details, keyed exactly like CodeRockz keys its locations. */
    private static function all()
    {
        $all = get_option(self::OPTION, []);
        return is_array($all) ? $all : [];
    }

    private static function can_edit()
    {
        return current_user_can('manage_woocommerce') || current_user_can('manage_options');
    }

    private static function nonce_ok()
    {
        return false !== check_ajax_referer('coderockz_woo_delivery_nonce', '_ajax_nonce', false);
    }

    /** Same sanitizing CodeRockz applies to the key, so both sides always agree. */
    private static function key_from_post($field)
    {
        return isset($_POST[$field]) && '' !== $_POST[$field]
            ? sanitize_text_field($_POST[$field]) // phpcs:ignore WordPress.Security.NonceVerification -- checked in on_save()
            : '';
    }

    private static function clean_details($time, $image_id)
    {
        $time = sanitize_text_field(wp_unslash($time));
        if (function_exists('mb_substr')) {
            $time = mb_substr($time, 0, self::MAX_TIME_LENGTH);
        }
        $image_id = absint($image_id);
        if ($image_id && !wp_attachment_is_image($image_id)) {
            $image_id = 0;
        }
        return ['time_slot' => $time, 'image_id' => $image_id];
    }

    /** Save (and rename) hook: runs on the "Save Changes" and "enable" buttons. */
    public static function on_save()
    {
        if (!self::can_edit() || !self::nonce_ok()) {
            return; // let CodeRockz answer (and refuse) as usual
        }
        $name = self::key_from_post('pickupLocationName');
        $old = self::key_from_post('pickupOldLocation');
        if ('' === $name) {
            return;
        }

        $all = self::all();

        // Renamed: the details follow the point to its new name.
        if ('' !== $old && $old !== $name && isset($all[$old])) {
            if (!isset($all[$name])) {
                $all[$name] = $all[$old];
            }
            unset($all[$old]);
        }

        if (isset($_POST['tw_pld_present'])) { // phpcs:ignore WordPress.Security.NonceVerification
            $time = isset($_POST['tw_pld_time_slot']) ? $_POST['tw_pld_time_slot'] : ''; // phpcs:ignore
            $image = isset($_POST['tw_pld_image_id']) ? $_POST['tw_pld_image_id'] : 0; // phpcs:ignore
            $details = self::clean_details($time, $image);
            if ('' === $details['time_slot'] && !$details['image_id']) {
                unset($all[$name]);
            } else {
                $all[$name] = $details;
            }
        }

        update_option(self::OPTION, $all, false);
    }

    /** Delete hook: a removed point takes its details with it. */
    public static function on_delete()
    {
        if (!self::can_edit() || !self::nonce_ok()) {
            return;
        }
        $name = self::key_from_post('pickupLocation');
        $all = self::all();
        if ('' !== $name && isset($all[$name])) {
            unset($all[$name]);
            update_option(self::OPTION, $all, false);
        }
    }

    /** Add the two fields to what the app reads. */
    public static function merge_into_rest($result, $server, $request)
    {
        if (!($result instanceof WP_REST_Response) || '/getPickupLocations/allLocations' !== $request->get_route()) {
            return $result;
        }
        $data = $result->get_data();
        if (!is_array($data) || empty($data['pickup_location']) || !is_array($data['pickup_location'])) {
            return $result;
        }
        $all = self::all();
        foreach ($data['pickup_location'] as $key => $location) {
            if (!is_array($location)) {
                continue;
            }
            $details = isset($all[$key]) ? $all[$key] : [];
            $image_id = !empty($details['image_id']) ? (int) $details['image_id'] : 0;
            $data['pickup_location'][$key]['time_slot'] = isset($details['time_slot']) ? (string) $details['time_slot'] : '';
            $data['pickup_location'][$key]['image_id'] = $image_id;
            $data['pickup_location'][$key]['image_url'] = $image_id ? (string) wp_get_attachment_image_url($image_id, 'medium_large') : '';
        }
        $result->set_data($data);
        return $result;
    }

    /** Load our script only on the CodeRockz settings page. */
    public static function enqueue()
    {
        if (!isset($_GET['page']) || self::PAGE !== sanitize_key(wp_unslash($_GET['page']))) { // phpcs:ignore WordPress.Security.NonceVerification
            return;
        }
        if (!self::can_edit()) {
            return;
        }
        wp_enqueue_media();
        $base = plugin_dir_url(WDAAPI_FILE);
        wp_enqueue_style('tw-wdapi-pickup-details', $base . 'assets/pickup-details.css', [], WDAAPI_VERSION);
        wp_enqueue_script('tw-wdapi-pickup-details', $base . 'assets/pickup-details.js', ['jquery'], WDAAPI_VERSION, true);

        $details = [];
        foreach (self::all() as $key => $row) {
            $image_id = !empty($row['image_id']) ? (int) $row['image_id'] : 0;
            // JS matches by what is typed in the name field (unslashed).
            $details[wp_unslash($key)] = [
                'time_slot' => isset($row['time_slot']) ? (string) $row['time_slot'] : '',
                'image_id' => $image_id,
                'image_url' => $image_id ? (string) wp_get_attachment_image_url($image_id, 'medium') : '',
            ];
        }
        wp_localize_script('tw-wdapi-pickup-details', 'twWdapiPld', [
            'details' => $details,
            'maxTime' => self::MAX_TIME_LENGTH,
            'i18n' => [
                'heading' => __('Shown in the app', 'woodelivery-appapi'),
                'headingHelp' => __('Photo and pickup time that customers see when they choose this pickup point in the app.', 'woodelivery-appapi'),
                'timeLabel' => __('Pickup time', 'woodelivery-appapi'),
                'timePlaceholder' => __('e.g. Mon–Fri 11:25–11:50', 'woodelivery-appapi'),
                'timeHelp' => __('Free text: write it the way you want customers to read it.', 'woodelivery-appapi'),
                'photoLabel' => __('Photo', 'woodelivery-appapi'),
                'choosePhoto' => __('Choose photo', 'woodelivery-appapi'),
                'changePhoto' => __('Change photo', 'woodelivery-appapi'),
                'removePhoto' => __('Remove photo', 'woodelivery-appapi'),
                'mediaTitle' => __('Choose a photo for this pickup point', 'woodelivery-appapi'),
                'mediaButton' => __('Use this photo', 'woodelivery-appapi'),
                'previewLabel' => __('How it looks in the app', 'woodelivery-appapi'),
                'namePlaceholder' => __('Pickup point name', 'woodelivery-appapi'),
                'showOnMap' => __('Show on map', 'woodelivery-appapi'),
                'savedHint' => __('Saved together with the other fields when you press Save Changes.', 'woodelivery-appapi'),
            ],
        ]);
    }
}
