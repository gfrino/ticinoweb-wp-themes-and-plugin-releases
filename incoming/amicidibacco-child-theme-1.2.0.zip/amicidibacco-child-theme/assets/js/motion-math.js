/* Pure geometry shared by the homepage controller and its continuity tests. */
(function (root, factory) {
    if (typeof module === 'object' && module.exports) module.exports = factory();
    else root.ADBMotion = factory();
})(typeof window !== 'undefined' ? window : this, function () {
    'use strict';
    const clamp = value => Math.max(0, Math.min(1, value));
    const smooth = value => { const p=clamp(value); return p*p*(3-2*p); };
    const api={
        wineStack(count,elapsed) {
            if(!count)return {active:0,moving:false,slides:[]};
            const current=count===1?0:Math.floor(Math.max(0,elapsed)/7000)%count;
            const p=count===1?0:clamp(((Math.max(0,elapsed)%7000)-5600)/1400),e=smooth(p);
            const slots=[{x:0,y:0,scale:1,opacity:1},{x:88,y:-36,scale:.78,opacity:.25},{x:142,y:-70,scale:.61,opacity:.1},{x:142,y:-70,scale:.61,opacity:0}];
            const mix=(a,b,t)=>Object.fromEntries(Object.keys(a).map(key=>[key,a[key]+(b[key]-a[key])*t]));
            const slides=Array.from({length:count},(_,index)=>{
                const relative=(index-current+count)%count;
                let point;
                if(!relative){
                    const leave=smooth(p/.65),returning=smooth((p-.65)/.35);
                    const end=slots[Math.min(count-1,3)];
                    point={x:-80*leave+(80+end.x)*returning,y:end.y*e,scale:1+(end.scale-1)*e,opacity:1-smooth(p/.6)+end.opacity*returning};
                }else point=mix(slots[Math.min(relative,3)],slots[Math.min(relative-1,3)],e);
                return {...point,info:relative===0?1-smooth(p/.3):relative===1?smooth((p-.5)/.5):0,z:relative===0?(p<.5?30:5):relative===1?25:relative===2?15:1};
            });
            return {active:p<.5?current:(current+1)%count,moving:p>0&&p<1,slides};
        },
        counterAperture(rgba,width,height,target) {
            if(!rgba.some((value,index)=>index%4===3&&value>=250))return {...target,radius:0};
            const pixels=new Uint8ClampedArray(width*height*4);
            for(let y=1;y<height-1;y++)for(let x=1;x<width-1;x++){
                const i=y*width+x;if(rgba[i*4+3]<16)pixels[i*4+3]=255;
            }
            // Calligraphic counters can be open. Search locally around the requested B,
            // rather than substituting a closed counter belonging to another letter.
            return api.inkAperture(pixels,width,height,{...target,reach:Math.min(width,height)*.18});
        },
        passage(top, height, y, viewport) { return clamp((y+viewport-top)/Math.max(1,height+viewport)); },
        // Conservative radius, shared by the ink/counter sampling and viewport coverage.
        inkAperture(rgba,width,height,search=null) {
            const distance=new Float32Array(width*height);
            for(let i=0;i<distance.length;i++)distance[i]=rgba[i*4+3]>=250?Math.max(width,height):0;
            for(let y=1;y<height-1;y++)for(let x=1;x<width-1;x++){
                const i=y*width+x;if(distance[i])distance[i]=Math.min(distance[i],1+Math.min(distance[i-1],distance[i-width],distance[i-width-1],distance[i-width+1]));
            }
            for(let y=height-2;y>0;y--)for(let x=width-2;x>0;x--){
                const i=y*width+x;if(distance[i])distance[i]=Math.min(distance[i],1+Math.min(distance[i+1],distance[i+width],distance[i+width-1],distance[i+width+1]));
            }
            let best={x:Math.floor(width/2),y:Math.floor(height/2),radius:0},bestScore=-Infinity;
            for(let y=1;y<height-1;y++)for(let x=1;x<width-1;x++){
                const radius=Math.max(0,distance[y*width+x]-1)*.9;
                const focusDistance=search?Math.hypot(x-search.x,y-search.y):0;
                if(search&&focusDistance>search.reach)continue;
                const score=radius-focusDistance*.25;
                if(radius>0&&score>bestScore){best={x,y,radius};bestScore=score;}
            }
            return best;
        },
        coverZoom(point,radius,width,height) {
            return Math.max(80,Math.hypot(Math.max(point.x,width-point.x),Math.max(point.y,height-point.y))/Math.max(.5,radius)*1.15);
        },
        portal(progress,maxZoom=80) {
            const p=clamp(progress);
            return {zoom:Math.exp(smooth(p/.84)*Math.log(maxZoom)),rise:smooth(p),introOpacity:smooth((p-.64)/.2),ink:1,sceneBlend:smooth((p-.26)/.3),heroOpacity:1-smooth(p/.42)};
        },
        clamp,
    };
    return api;
});
