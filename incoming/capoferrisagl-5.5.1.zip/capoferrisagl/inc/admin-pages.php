<?php
/**
 * Pagine del backend: Home, Chi siamo, Contatti, Impostazioni globali,
 * Galleria lavori e Ordine dei servizi.
 *
 * Registrate in un menu top-level dedicato "Capoferri", separato dal
 * ticinoWEB CMS che resta originale e intatto.
 *
 * @package Capoferrisagl
 */

if (!defined('ABSPATH')) {
    exit;
}

/** Slug del menu top-level dedicato ai contenuti del sito Capoferri. */
if (!defined('CFS_MENU')) {
    define('CFS_MENU', 'capoferri');
}

add_action('admin_menu', 'cfs_register_admin_pages', 20);
function cfs_register_admin_pages()
{
    // Menu top-level proprio: non tocca il ticinoWEB CMS.
    add_menu_page(
        __('Contenuti Capoferri', 'capoferrisagl'),
        __('Capoferri', 'capoferrisagl'),
        'edit_pages',
        CFS_MENU,
        'cfs_page_home',
        'dashicons-admin-multisite',
        26
    );

    $parent = CFS_MENU;

    // La prima voce riusa lo slug del menu per evitare il duplicato "Capoferri".
    add_submenu_page($parent, __('Home', 'capoferrisagl'), __('Home', 'capoferrisagl'), 'edit_pages', CFS_MENU, 'cfs_page_home');
    add_submenu_page($parent, __('Pagina Servizi', 'capoferrisagl'), __('Pagina Servizi', 'capoferrisagl'), 'edit_pages', 'cfs-servizi', 'cfs_page_servizi');
    add_submenu_page($parent, __('Chi siamo', 'capoferrisagl'), __('Chi siamo', 'capoferrisagl'), 'edit_pages', 'cfs-about', 'cfs_page_about');
    add_submenu_page($parent, __('Contatti', 'capoferrisagl'), __('Contatti', 'capoferrisagl'), 'edit_pages', 'cfs-contact', 'cfs_page_contact');
    add_submenu_page($parent, __('Galleria lavori', 'capoferrisagl'), __('Galleria lavori', 'capoferrisagl'), 'edit_pages', 'cfs-gallery', 'cfs_page_gallery');
    add_submenu_page($parent, __('Ordine dei servizi', 'capoferrisagl'), __('Ordine dei servizi', 'capoferrisagl'), 'edit_pages', 'cfs-order', 'cfs_page_order');
    add_submenu_page($parent, __('Impostazioni sito', 'capoferrisagl'), __('Impostazioni sito', 'capoferrisagl'), 'edit_pages', 'cfs-settings', 'cfs_page_settings');
}

/* ─────────────────────────────────────────────
   HOME
   ───────────────────────────────────────────── */

function cfs_page_home()
{
    cfs_render_options_page(
        'cfs_home',
        __('Home', 'capoferrisagl'),
        __('Tutti i testi e le immagini della home page. Le sezioni disattivate non vengono mostrate nel sito.', 'capoferrisagl'),
        array(

            'hero' => array(
                'label'  => __('Hero', 'capoferrisagl'),
                'desc'   => __('La prima schermata del sito: deve far capire subito chi è Capoferri e cosa fa.', 'capoferrisagl'),
                'fields' => array(
                    'hero' => array(
                        'type'   => 'group',
                        'label'  => __('Contenuti dell\'hero', 'capoferrisagl'),
                        'fields' => array(
                            'label'        => array('type' => 'text', 'label' => __('Etichetta', 'capoferrisagl'), 'desc' => __('Testo breve sopra il titolo (facoltativo).', 'capoferrisagl')),
                            'title'        => array('type' => 'textarea', 'label' => __('Titolo', 'capoferrisagl'), 'rows' => 2, 'desc' => __('Vai a capo per spezzare il titolo su più righe.', 'capoferrisagl')),
                            'subtitle'     => array('type' => 'text', 'label' => __('Sottotitolo', 'capoferrisagl')),
                            'text'         => array('type' => 'textarea', 'label' => __('Testo', 'capoferrisagl'), 'rows' => 3),
                            'btn1_text'    => array('type' => 'text', 'label' => __('Pulsante principale — testo', 'capoferrisagl')),
                            'btn1_url'     => array('type' => 'url', 'label' => __('Pulsante principale — link', 'capoferrisagl')),
                            'btn2_text'    => array('type' => 'text', 'label' => __('Pulsante secondario — testo', 'capoferrisagl')),
                            'btn2_url'     => array('type' => 'url', 'label' => __('Pulsante secondario — link', 'capoferrisagl')),
                            'image'        => array('type' => 'image', 'label' => __('Immagine desktop', 'capoferrisagl')),
                            'image_mobile' => array('type' => 'image', 'label' => __('Immagine mobile', 'capoferrisagl'), 'desc' => __('Facoltativa: se vuota si usa quella desktop.', 'capoferrisagl')),
                            'alt'          => array('type' => 'text', 'label' => __('Testo alternativo dell\'immagine', 'capoferrisagl')),
                            'caption'      => array('type' => 'text', 'label' => __('Didascalia', 'capoferrisagl')),
                            'focal'        => array('type' => 'focal', 'label' => __('Punto focale dell\'immagine', 'capoferrisagl')),
                            'video_enabled'=> array('type' => 'checkbox', 'label' => __('Video di sfondo', 'capoferrisagl'), 'checkbox_label' => __('Usa un video al posto dell\'immagine', 'capoferrisagl')),
                            'video'        => array('type' => 'video', 'label' => __('Video di sfondo (mp4)', 'capoferrisagl')),
                            'video_poster' => array('type' => 'image', 'label' => __('Poster del video', 'capoferrisagl')),
                            'badge'        => array('type' => 'text', 'label' => __('Pillola luccicante', 'capoferrisagl'), 'desc' => __('Etichetta in basso a destra dell\'hero (es. servizio di picchetto). Lascia vuoto per nasconderla.', 'capoferrisagl')),
                            'scroll_hint'  => array('type' => 'text', 'label' => __('Indicatore di scroll', 'capoferrisagl'), 'desc' => __('Testo breve accanto alla freccia. Lascia vuoto per nascondere l\'indicatore.', 'capoferrisagl')),
                        ),
                    ),
                ),
            ),

            'promo' => array(
                'label'  => __('Banner in evidenza', 'capoferrisagl'),
                'fields' => array(
                    'promo' => array(
                        'type'   => 'group',
                        'label'  => __('Messaggio in evidenza', 'capoferrisagl'),
                        'desc'   => __('Banner pubblicitario mostrato subito sotto l\'hero, per mettere in primo piano un servizio.', 'capoferrisagl'),
                        'fields' => array(
                            'enabled'  => array('type' => 'checkbox', 'label' => __('Attivo', 'capoferrisagl'), 'checkbox_label' => __('Mostra il banner', 'capoferrisagl'), 'default' => '1'),
                            'label'    => array('type' => 'text', 'label' => __('Etichetta', 'capoferrisagl')),
                            'title'    => array('type' => 'text', 'label' => __('Titolo', 'capoferrisagl')),
                            'text'     => array('type' => 'textarea', 'label' => __('Testo', 'capoferrisagl'), 'rows' => 3),
                            'btn_text' => array('type' => 'text', 'label' => __('Pulsante — testo', 'capoferrisagl')),
                            'btn_url'  => array('type' => 'url', 'label' => __('Pulsante — link', 'capoferrisagl')),
                        ),
                    ),
                ),
            ),

            'intro' => array(
                'label'  => __('Presentazione', 'capoferrisagl'),
                'fields' => array(
                    'intro' => array(
                        'type'   => 'group',
                        'label'  => __('Introduzione aziendale', 'capoferrisagl'),
                        'fields' => array(
                            'enabled'   => array('type' => 'checkbox', 'label' => __('Sezione attiva', 'capoferrisagl'), 'checkbox_label' => __('Mostra questa sezione', 'capoferrisagl'), 'default' => '1'),
                            'label'     => array('type' => 'text', 'label' => __('Etichetta', 'capoferrisagl')),
                            'title'     => array('type' => 'text', 'label' => __('Titolo', 'capoferrisagl')),
                            'text'      => array('type' => 'textarea', 'label' => __('Testo', 'capoferrisagl'), 'rows' => 6),
                            'image'     => array('type' => 'image', 'label' => __('Immagine', 'capoferrisagl')),
                            'alt'       => array('type' => 'text', 'label' => __('Testo alternativo', 'capoferrisagl')),
                            'caption'   => array('type' => 'text', 'label' => __('Didascalia', 'capoferrisagl')),
                            'btn_text'  => array('type' => 'text', 'label' => __('Pulsante — testo', 'capoferrisagl')),
                            'btn_url'   => array('type' => 'url', 'label' => __('Pulsante — link', 'capoferrisagl')),
                            'strengths' => array(
                                'type'      => 'repeater',
                                'label'     => __('Punti di forza', 'capoferrisagl'),
                                'add_label' => __('Aggiungi punto di forza', 'capoferrisagl'),
                                'row_title' => 'title',
                                'row_label' => __('Punto di forza', 'capoferrisagl'),
                                'empty'     => __('Nessun punto di forza inserito.', 'capoferrisagl'),
                                'fields'    => array(
                                    'title' => array('type' => 'text', 'label' => __('Titolo', 'capoferrisagl')),
                                    'text'  => array('type' => 'textarea', 'label' => __('Descrizione', 'capoferrisagl'), 'rows' => 2),
                                ),
                            ),
                        ),
                    ),
                ),
            ),

            'services' => array(
                'label'  => __('Servizi in evidenza', 'capoferrisagl'),
                'desc'   => __('Le immagini delle card vengono prese automaticamente dalla copertina di ogni servizio.', 'capoferrisagl'),
                'fields' => array(
                    'services' => array(
                        'type'   => 'group',
                        'label'  => __('Sezione servizi', 'capoferrisagl'),
                        'fields' => array(
                            'enabled'  => array('type' => 'checkbox', 'label' => __('Sezione attiva', 'capoferrisagl'), 'checkbox_label' => __('Mostra questa sezione', 'capoferrisagl'), 'default' => '1'),
                            'label'    => array('type' => 'text', 'label' => __('Etichetta', 'capoferrisagl')),
                            'title'    => array('type' => 'text', 'label' => __('Titolo della sezione', 'capoferrisagl')),
                            'text'     => array('type' => 'textarea', 'label' => __('Testo introduttivo', 'capoferrisagl'), 'rows' => 3),
                            'items'    => array('type' => 'service_picker', 'label' => __('Servizi da mostrare', 'capoferrisagl')),
                            'limit'    => array('type' => 'number', 'label' => __('Quantità massima', 'capoferrisagl'), 'desc' => __('0 = mostra tutti quelli selezionati.', 'capoferrisagl'), 'default' => '0'),
                            'btn_text' => array('type' => 'text', 'label' => __('Pulsante — testo', 'capoferrisagl')),
                            'btn_url'  => array('type' => 'url', 'label' => __('Pulsante — link', 'capoferrisagl')),
                        ),
                    ),
                ),
            ),

            'method' => array(
                'label'  => __('Metodo di lavoro', 'capoferrisagl'),
                'fields' => array(
                    'method' => array(
                        'type'   => 'group',
                        'label'  => __('Come lavoriamo', 'capoferrisagl'),
                        'fields' => array(
                            'enabled' => array('type' => 'checkbox', 'label' => __('Sezione attiva', 'capoferrisagl'), 'checkbox_label' => __('Mostra questa sezione', 'capoferrisagl'), 'default' => '1'),
                            'label'   => array('type' => 'text', 'label' => __('Etichetta', 'capoferrisagl')),
                            'title'   => array('type' => 'text', 'label' => __('Titolo', 'capoferrisagl')),
                            'text'    => array('type' => 'textarea', 'label' => __('Introduzione', 'capoferrisagl'), 'rows' => 3),
                            'steps'   => array(
                                'type'      => 'repeater',
                                'label'     => __('Passaggi', 'capoferrisagl'),
                                'add_label' => __('Aggiungi passaggio', 'capoferrisagl'),
                                'row_title' => 'title',
                                'row_label' => __('Passaggio', 'capoferrisagl'),
                                'empty'     => __('Aggiungi il primo passaggio del metodo di lavoro.', 'capoferrisagl'),
                                'fields'    => array(
                                    'title' => array('type' => 'text', 'label' => __('Titolo del passaggio', 'capoferrisagl')),
                                    'text'  => array('type' => 'textarea', 'label' => __('Descrizione', 'capoferrisagl'), 'rows' => 3),
                                    'icon'  => array('type' => 'image', 'label' => __('Icona', 'capoferrisagl'), 'desc' => __('Facoltativa.', 'capoferrisagl')),
                                ),
                            ),
                        ),
                    ),
                ),
            ),

            'gallery' => array(
                'label'  => __('Galleria lavori', 'capoferrisagl'),
                'desc'   => __('Le immagini si gestiscono nella pagina “Galleria lavori”. Qui imposti testi e visibilità.', 'capoferrisagl'),
                'fields' => array(
                    'gallery' => array(
                        'type'   => 'group',
                        'label'  => __('Sezione galleria', 'capoferrisagl'),
                        'fields' => array(
                            'enabled'  => array('type' => 'checkbox', 'label' => __('Sezione attiva', 'capoferrisagl'), 'checkbox_label' => __('Mostra questa sezione', 'capoferrisagl'), 'default' => '1'),
                            'label'    => array('type' => 'text', 'label' => __('Etichetta', 'capoferrisagl')),
                            'title'    => array('type' => 'text', 'label' => __('Titolo', 'capoferrisagl')),
                            'text'     => array('type' => 'textarea', 'label' => __('Testo', 'capoferrisagl'), 'rows' => 3),
                            'btn_text' => array('type' => 'text', 'label' => __('Pulsante — testo', 'capoferrisagl')),
                            'btn_url'  => array('type' => 'url', 'label' => __('Pulsante — link', 'capoferrisagl')),
                        ),
                    ),
                ),
            ),

            'cta' => array(
                'label'  => __('Call to action', 'capoferrisagl'),
                'fields' => array(
                    'cta' => array(
                        'type'   => 'group',
                        'label'  => __('Call to action finale', 'capoferrisagl'),
                        'fields' => array(
                            'enabled'   => array('type' => 'checkbox', 'label' => __('Sezione attiva', 'capoferrisagl'), 'checkbox_label' => __('Mostra questa sezione', 'capoferrisagl'), 'default' => '1'),
                            'label'     => array('type' => 'text', 'label' => __('Etichetta', 'capoferrisagl')),
                            'title'     => array('type' => 'text', 'label' => __('Titolo', 'capoferrisagl')),
                            'text'      => array('type' => 'textarea', 'label' => __('Testo', 'capoferrisagl'), 'rows' => 3),
                            'btn1_text' => array('type' => 'text', 'label' => __('Pulsante principale — testo', 'capoferrisagl')),
                            'btn1_url'  => array('type' => 'url', 'label' => __('Pulsante principale — link', 'capoferrisagl')),
                            'btn2_text' => array('type' => 'text', 'label' => __('Pulsante secondario — testo', 'capoferrisagl')),
                            'btn2_url'  => array('type' => 'url', 'label' => __('Pulsante secondario — link', 'capoferrisagl')),
                            'phone_label' => array('type' => 'text', 'label' => __('Etichetta del telefono', 'capoferrisagl'), 'desc' => __('Il numero arriva dalle Impostazioni sito.', 'capoferrisagl')),
                            'image'     => array('type' => 'image', 'label' => __('Immagine di sfondo', 'capoferrisagl')),
                        ),
                    ),
                ),
            ),

            'seo' => array(
                'label'  => __('SEO', 'capoferrisagl'),
                'fields' => array(
                    'seo' => array(
                        'type'   => 'group',
                        'label'  => __('SEO della home', 'capoferrisagl'),
                        'fields' => array(
                            'title' => array('type' => 'text', 'label' => __('SEO title', 'capoferrisagl'), 'counter' => 60),
                            'desc'  => array('type' => 'textarea', 'label' => __('Meta description', 'capoferrisagl'), 'rows' => 3, 'counter' => 160),
                            'image' => array('type' => 'image', 'label' => __('Immagine Open Graph', 'capoferrisagl')),
                        ),
                    ),
                ),
            ),
        )
    );
}

/* ─────────────────────────────────────────────
   CHI SIAMO
   ───────────────────────────────────────────── */

function cfs_page_servizi()
{
    cfs_render_options_page(
        'cfs_servizi',
        __('Pagina Servizi', 'capoferrisagl'),
        __('Banner e introduzione della pagina "Servizi". L\'elenco e l\'ordine dei singoli servizi si gestiscono in "Servizi".', 'capoferrisagl'),
        array(
            'page' => array(
                'label'  => __('Pagina', 'capoferrisagl'),
                'fields' => array(
                    'hero' => array(
                        'type'   => 'group',
                        'label'  => __('Banner della pagina', 'capoferrisagl'),
                        'fields' => array(
                            'label'        => array('type' => 'text', 'label' => __('Etichetta', 'capoferrisagl')),
                            'title'        => array('type' => 'text', 'label' => __('Titolo', 'capoferrisagl')),
                            'intro'        => array('type' => 'textarea', 'label' => __('Testo del banner', 'capoferrisagl'), 'rows' => 3),
                            'image'        => array('type' => 'image', 'label' => __('Immagine di sfondo (desktop)', 'capoferrisagl')),
                            'image_mobile' => array('type' => 'image', 'label' => __('Immagine mobile', 'capoferrisagl'), 'desc' => __('Facoltativa.', 'capoferrisagl')),
                            'focal'        => array('type' => 'focal', 'label' => __('Punto focale dell\'immagine', 'capoferrisagl')),
                            'alt'          => array('type' => 'text', 'label' => __('Testo alternativo dell\'immagine', 'capoferrisagl')),
                        ),
                    ),
                    'intro' => array(
                        'type'   => 'group',
                        'label'  => __('Introduzione (sopra l\'elenco)', 'capoferrisagl'),
                        'fields' => array(
                            'text' => array('type' => 'textarea', 'label' => __('Testo introduttivo', 'capoferrisagl'), 'rows' => 5, 'desc' => __('Facoltativo: appare sopra l\'elenco dei servizi.', 'capoferrisagl')),
                        ),
                    ),
                ),
            ),
            'seo' => array(
                'label'  => __('SEO', 'capoferrisagl'),
                'fields' => array(
                    'seo' => array(
                        'type'   => 'group',
                        'label'  => __('SEO della pagina', 'capoferrisagl'),
                        'fields' => array(
                            'title' => array('type' => 'text', 'label' => __('SEO title', 'capoferrisagl'), 'counter' => 60),
                            'desc'  => array('type' => 'textarea', 'label' => __('Meta description', 'capoferrisagl'), 'rows' => 3, 'counter' => 160),
                            'image' => array('type' => 'image', 'label' => __('Immagine Open Graph', 'capoferrisagl')),
                        ),
                    ),
                ),
            ),
        )
    );
}

function cfs_page_about()
{
    cfs_render_options_page(
        'cfs_about',
        __('Chi siamo', 'capoferrisagl'),
        __('Contenuti della pagina Chi siamo.', 'capoferrisagl'),
        array(

            'hero' => array(
                'label'  => __('Hero', 'capoferrisagl'),
                'fields' => array(
                    'hero' => array(
                        'type'   => 'group',
                        'label'  => __('Hero della pagina', 'capoferrisagl'),
                        'fields' => array(
                            'label'        => array('type' => 'text', 'label' => __('Etichetta', 'capoferrisagl')),
                            'title'        => array('type' => 'text', 'label' => __('Titolo', 'capoferrisagl')),
                            'intro'        => array('type' => 'textarea', 'label' => __('Introduzione', 'capoferrisagl'), 'rows' => 3),
                            'image'        => array('type' => 'image', 'label' => __('Immagine desktop', 'capoferrisagl')),
                            'image_mobile' => array('type' => 'image', 'label' => __('Immagine mobile', 'capoferrisagl')),
                            'alt'          => array('type' => 'text', 'label' => __('Testo alternativo', 'capoferrisagl')),
                            'focal'        => array('type' => 'focal', 'label' => __('Punto focale', 'capoferrisagl')),
                        ),
                    ),
                ),
            ),

            'intro' => array(
                'label'  => __('Introduzione', 'capoferrisagl'),
                'fields' => array(
                    'intro' => array(
                        'type'   => 'group',
                        'label'  => __('Introduzione', 'capoferrisagl'),
                        'fields' => array(
                            'enabled' => array('type' => 'checkbox', 'label' => __('Sezione attiva', 'capoferrisagl'), 'checkbox_label' => __('Mostra questa sezione', 'capoferrisagl'), 'default' => '1'),
                            'title'   => array('type' => 'text', 'label' => __('Titolo', 'capoferrisagl')),
                            'text'    => array('type' => 'textarea', 'label' => __('Testo', 'capoferrisagl'), 'rows' => 8),
                            'image'   => array('type' => 'image', 'label' => __('Immagine', 'capoferrisagl')),
                            'alt'     => array('type' => 'text', 'label' => __('Testo alternativo', 'capoferrisagl')),
                            'caption' => array('type' => 'text', 'label' => __('Didascalia', 'capoferrisagl')),
                        ),
                    ),
                ),
            ),

            'story' => array(
                'label'  => __('Storia', 'capoferrisagl'),
                'fields' => array(
                    'story' => array(
                        'type'   => 'group',
                        'label'  => __('La nostra storia', 'capoferrisagl'),
                        'fields' => array(
                            'enabled' => array('type' => 'checkbox', 'label' => __('Sezione attiva', 'capoferrisagl'), 'checkbox_label' => __('Mostra questa sezione', 'capoferrisagl'), 'default' => '1'),
                            'label'   => array('type' => 'text', 'label' => __('Etichetta', 'capoferrisagl')),
                            'title'   => array('type' => 'text', 'label' => __('Titolo', 'capoferrisagl')),
                            'text'    => array('type' => 'textarea', 'label' => __('Testo', 'capoferrisagl'), 'rows' => 10),
                            'gallery' => array('type' => 'image', 'label' => __('Immagine', 'capoferrisagl')),
                        ),
                    ),
                ),
            ),

            'timeline' => array(
                'label'  => __('Timeline', 'capoferrisagl'),
                'fields' => array(
                    'timeline' => array(
                        'type'   => 'group',
                        'label'  => __('Tappe', 'capoferrisagl'),
                        'fields' => array(
                            'enabled' => array('type' => 'checkbox', 'label' => __('Sezione attiva', 'capoferrisagl'), 'checkbox_label' => __('Mostra questa sezione', 'capoferrisagl'), 'default' => '1'),
                            'title'   => array('type' => 'text', 'label' => __('Titolo', 'capoferrisagl')),
                            'text'    => array('type' => 'textarea', 'label' => __('Introduzione', 'capoferrisagl'), 'rows' => 3),
                            'items'   => array(
                                'type'      => 'repeater',
                                'label'     => __('Elementi della timeline', 'capoferrisagl'),
                                'add_label' => __('Aggiungi tappa', 'capoferrisagl'),
                                'row_title' => 'year',
                                'row_label' => __('Tappa', 'capoferrisagl'),
                                'empty'     => __('Aggiungi il primo elemento della timeline.', 'capoferrisagl'),
                                'fields'    => array(
                                    'year'  => array('type' => 'text', 'label' => __('Anno o periodo', 'capoferrisagl')),
                                    'title' => array('type' => 'text', 'label' => __('Titolo', 'capoferrisagl')),
                                    'text'  => array('type' => 'textarea', 'label' => __('Descrizione', 'capoferrisagl'), 'rows' => 3),
                                    'image' => array('type' => 'image', 'label' => __('Immagine', 'capoferrisagl')),
                                    'alt'   => array('type' => 'text', 'label' => __('Testo alternativo', 'capoferrisagl')),
                                ),
                            ),
                        ),
                    ),
                ),
            ),

            'values' => array(
                'label'  => __('Valori', 'capoferrisagl'),
                'fields' => array(
                    'values' => array(
                        'type'   => 'group',
                        'label'  => __('I nostri valori', 'capoferrisagl'),
                        'fields' => array(
                            'enabled' => array('type' => 'checkbox', 'label' => __('Sezione attiva', 'capoferrisagl'), 'checkbox_label' => __('Mostra questa sezione', 'capoferrisagl'), 'default' => '1'),
                            'title'   => array('type' => 'text', 'label' => __('Titolo', 'capoferrisagl')),
                            'text'    => array('type' => 'textarea', 'label' => __('Introduzione', 'capoferrisagl'), 'rows' => 3),
                            'items'   => array(
                                'type'      => 'repeater',
                                'label'     => __('Valori', 'capoferrisagl'),
                                'add_label' => __('Aggiungi valore', 'capoferrisagl'),
                                'row_title' => 'title',
                                'row_label' => __('Valore', 'capoferrisagl'),
                                'empty'     => __('Nessun valore inserito.', 'capoferrisagl'),
                                'fields'    => array(
                                    'title' => array('type' => 'text', 'label' => __('Nome del valore', 'capoferrisagl')),
                                    'text'  => array('type' => 'textarea', 'label' => __('Descrizione', 'capoferrisagl'), 'rows' => 3),
                                    'icon'  => array('type' => 'image', 'label' => __('Icona', 'capoferrisagl')),
                                ),
                            ),
                        ),
                    ),
                ),
            ),

            'quote' => array(
                'label'  => __('Citazione e CTA', 'capoferrisagl'),
                'fields' => array(
                    'quote' => array(
                        'type'   => 'group',
                        'label'  => __('Citazione', 'capoferrisagl'),
                        'fields' => array(
                            'enabled' => array('type' => 'checkbox', 'label' => __('Sezione attiva', 'capoferrisagl'), 'checkbox_label' => __('Mostra questa sezione', 'capoferrisagl'), 'default' => '1'),
                            'text'    => array('type' => 'textarea', 'label' => __('Testo della citazione', 'capoferrisagl'), 'rows' => 3),
                            'author'  => array('type' => 'text', 'label' => __('Autore', 'capoferrisagl')),
                            'role'    => array('type' => 'text', 'label' => __('Ruolo', 'capoferrisagl')),
                            'image'   => array('type' => 'image', 'label' => __('Immagine', 'capoferrisagl')),
                        ),
                    ),
                    'cta' => array(
                        'type'   => 'group',
                        'label'  => __('Call to action finale', 'capoferrisagl'),
                        'fields' => array(
                            'enabled'   => array('type' => 'checkbox', 'label' => __('Sezione attiva', 'capoferrisagl'), 'checkbox_label' => __('Mostra questa sezione', 'capoferrisagl'), 'default' => '1'),
                            'title'     => array('type' => 'text', 'label' => __('Titolo', 'capoferrisagl')),
                            'text'      => array('type' => 'textarea', 'label' => __('Testo', 'capoferrisagl'), 'rows' => 3),
                            'btn1_text' => array('type' => 'text', 'label' => __('Pulsante principale — testo', 'capoferrisagl')),
                            'btn1_url'  => array('type' => 'url', 'label' => __('Pulsante principale — link', 'capoferrisagl')),
                            'btn2_text' => array('type' => 'text', 'label' => __('Pulsante secondario — testo', 'capoferrisagl')),
                            'btn2_url'  => array('type' => 'url', 'label' => __('Pulsante secondario — link', 'capoferrisagl')),
                            'image'     => array('type' => 'image', 'label' => __('Immagine di sfondo', 'capoferrisagl')),
                        ),
                    ),
                ),
            ),

            'seo' => array(
                'label'  => __('SEO', 'capoferrisagl'),
                'fields' => array(
                    'seo' => array(
                        'type'   => 'group',
                        'label'  => __('SEO della pagina', 'capoferrisagl'),
                        'fields' => array(
                            'title' => array('type' => 'text', 'label' => __('SEO title', 'capoferrisagl'), 'counter' => 60),
                            'desc'  => array('type' => 'textarea', 'label' => __('Meta description', 'capoferrisagl'), 'rows' => 3, 'counter' => 160),
                            'image' => array('type' => 'image', 'label' => __('Immagine Open Graph', 'capoferrisagl')),
                        ),
                    ),
                ),
            ),
        )
    );
}

/* ─────────────────────────────────────────────
   CONTATTI
   ───────────────────────────────────────────── */

function cfs_page_contact()
{
    cfs_render_options_page(
        'cfs_contact',
        __('Contatti', 'capoferrisagl'),
        __('Contenuti della pagina Contatti e configurazione del modulo. I dati aziendali (indirizzo, telefono, email) si modificano in “Impostazioni sito” e vengono usati in tutto il sito.', 'capoferrisagl'),
        array(

            'page' => array(
                'label'  => __('Pagina', 'capoferrisagl'),
                'fields' => array(
                    'hero' => array(
                        'type'   => 'group',
                        'label'  => __('Banner della pagina', 'capoferrisagl'),
                        'desc'   => __('L\'immagine di sfondo, il titolo e i testi del banner in cima alla pagina Contatti.', 'capoferrisagl'),
                        'fields' => array(
                            'label'        => array('type' => 'text', 'label' => __('Etichetta', 'capoferrisagl'), 'desc' => __('Testo breve sopra il titolo (facoltativo).', 'capoferrisagl')),
                            'title'        => array('type' => 'text', 'label' => __('Titolo', 'capoferrisagl')),
                            'intro'        => array('type' => 'textarea', 'label' => __('Introduzione', 'capoferrisagl'), 'rows' => 3),
                            'image'        => array('type' => 'image', 'label' => __('Immagine di sfondo (desktop)', 'capoferrisagl')),
                            'image_mobile' => array('type' => 'image', 'label' => __('Immagine mobile', 'capoferrisagl'), 'desc' => __('Facoltativa: se vuota si usa quella desktop.', 'capoferrisagl')),
                            'focal'        => array('type' => 'focal', 'label' => __('Punto focale dell\'immagine', 'capoferrisagl')),
                            'alt'          => array('type' => 'text', 'label' => __('Testo alternativo dell\'immagine', 'capoferrisagl')),
                        ),
                    ),
                    'info' => array(
                        'type'   => 'group',
                        'label'  => __('Informazioni', 'capoferrisagl'),
                        'fields' => array(
                            'hours_title' => array('type' => 'text', 'label' => __('Titolo degli orari', 'capoferrisagl')),
                            'note'        => array('type' => 'textarea', 'label' => __('Testo informativo', 'capoferrisagl'), 'rows' => 3),
                        ),
                    ),
                    'map' => array(
                        'type'   => 'group',
                        'label'  => __('Mappa', 'capoferrisagl'),
                        'fields' => array(
                            'enabled' => array('type' => 'checkbox', 'label' => __('Mostra la mappa', 'capoferrisagl'), 'checkbox_label' => __('Mostra la mappa nella pagina', 'capoferrisagl'), 'default' => '1'),
                            'embed'   => array('type' => 'url', 'label' => __('URL di incorporamento della mappa', 'capoferrisagl'), 'desc' => __('Indirizzo “embed” di OpenStreetMap o Google Maps.', 'capoferrisagl')),
                            'title'   => array('type' => 'text', 'label' => __('Titolo della mappa', 'capoferrisagl'), 'desc' => __('Descrizione per screen reader.', 'capoferrisagl')),
                        ),
                    ),
                ),
            ),

            'form' => array(
                'label'  => __('Modulo', 'capoferrisagl'),
                'desc'   => __('Testi ed etichette del modulo di contatto.', 'capoferrisagl'),
                'fields' => array(
                    'form' => array(
                        'type'   => 'group',
                        'label'  => __('Modulo di contatto', 'capoferrisagl'),
                        'fields' => array(
                            'title'          => array('type' => 'text', 'label' => __('Titolo del modulo', 'capoferrisagl')),
                            'text'           => array('type' => 'textarea', 'label' => __('Testo introduttivo', 'capoferrisagl'), 'rows' => 2),
                            'label_name'     => array('type' => 'text', 'label' => __('Etichetta — Nome e cognome', 'capoferrisagl')),
                            'label_email'    => array('type' => 'text', 'label' => __('Etichetta — Email', 'capoferrisagl')),
                            'label_phone'    => array('type' => 'text', 'label' => __('Etichetta — Telefono', 'capoferrisagl')),
                            'label_service'  => array('type' => 'text', 'label' => __('Etichetta — Servizio di interesse', 'capoferrisagl')),
                            'label_message'  => array('type' => 'text', 'label' => __('Etichetta — Messaggio', 'capoferrisagl')),
                            'label_privacy'  => array('type' => 'textarea', 'label' => __('Testo del consenso privacy', 'capoferrisagl'), 'rows' => 2),
                            'submit'         => array('type' => 'text', 'label' => __('Testo del pulsante di invio', 'capoferrisagl')),
                            'sending'        => array('type' => 'text', 'label' => __('Testo durante l\'invio', 'capoferrisagl')),
                            'success'        => array('type' => 'textarea', 'label' => __('Messaggio di conferma', 'capoferrisagl'), 'rows' => 2),
                            'error'          => array('type' => 'textarea', 'label' => __('Messaggio di errore', 'capoferrisagl'), 'rows' => 2),
                        ),
                    ),
                    'mail' => array(
                        'type'   => 'group',
                        'label'  => __('Invio delle richieste', 'capoferrisagl'),
                        'desc'   => __('Gli indirizzi non compaiono mai nel sito pubblico.', 'capoferrisagl'),
                        'fields' => array(
                            'to'      => array('type' => 'email', 'label' => __('Destinatario', 'capoferrisagl'), 'desc' => __('Se vuoto viene usata l\'email aziendale delle Impostazioni sito.', 'capoferrisagl')),
                            'cc'      => array('type' => 'text', 'label' => __('Destinatari in copia', 'capoferrisagl'), 'desc' => __('Più indirizzi separati da virgola.', 'capoferrisagl')),
                            'subject' => array('type' => 'text', 'label' => __('Oggetto dell\'email', 'capoferrisagl')),
                        ),
                    ),
                ),
            ),

            'seo' => array(
                'label'  => __('SEO', 'capoferrisagl'),
                'fields' => array(
                    'seo' => array(
                        'type'   => 'group',
                        'label'  => __('SEO della pagina', 'capoferrisagl'),
                        'fields' => array(
                            'title' => array('type' => 'text', 'label' => __('SEO title', 'capoferrisagl'), 'counter' => 60),
                            'desc'  => array('type' => 'textarea', 'label' => __('Meta description', 'capoferrisagl'), 'rows' => 3, 'counter' => 160),
                            'image' => array('type' => 'image', 'label' => __('Immagine Open Graph', 'capoferrisagl')),
                        ),
                    ),
                ),
            ),
        )
    );
}

/* ─────────────────────────────────────────────
   IMPOSTAZIONI GLOBALI
   ───────────────────────────────────────────── */

function cfs_page_settings()
{
    cfs_render_options_page(
        'cfs_settings',
        __('Impostazioni sito', 'capoferrisagl'),
        __('Dati aziendali, logo, footer e testi di sistema. Sono la fonte unica usata da tutte le pagine.', 'capoferrisagl'),
        array(

            'company' => array(
                'label'  => __('Azienda', 'capoferrisagl'),
                'fields' => array(
                    'company_name'        => array('type' => 'text', 'label' => __('Nome azienda', 'capoferrisagl')),
                    'legal_name'          => array('type' => 'text', 'label' => __('Ragione sociale', 'capoferrisagl')),
                    'legal_address_label' => array('type' => 'text', 'label' => __('Etichetta Sede Legale', 'capoferrisagl'), 'default' => 'Sede legale / Corrispondenza'),
                    'street'              => array('type' => 'text', 'label' => __('Sede Legale — Indirizzo', 'capoferrisagl')),
                    'po_box'              => array('type' => 'text', 'label' => __('Sede Legale — Casella postale', 'capoferrisagl')),
                    'postal_code'         => array('type' => 'text', 'label' => __('Sede Legale — CAP', 'capoferrisagl')),
                    'city'                => array('type' => 'text', 'label' => __('Sede Legale — Località', 'capoferrisagl')),
                    'op_address_label'    => array('type' => 'text', 'label' => __('Etichetta Sede Operativa', 'capoferrisagl'), 'default' => 'Sede operativa'),
                    'op_street'           => array('type' => 'text', 'label' => __('Sede Operativa — Indirizzo', 'capoferrisagl')),
                    'op_postal_code'      => array('type' => 'text', 'label' => __('Sede Operativa — CAP', 'capoferrisagl')),
                    'op_city'             => array('type' => 'text', 'label' => __('Sede Operativa — Località', 'capoferrisagl')),
                    'country'             => array('type' => 'text', 'label' => __('Paese', 'capoferrisagl')),
                    'phone'               => array('type' => 'text', 'label' => __('Telefono visualizzato', 'capoferrisagl')),
                    'phone_raw'           => array('type' => 'tel', 'label' => __('Numero per il link telefonico', 'capoferrisagl'), 'desc' => __('Formato internazionale, es. +41916822338.', 'capoferrisagl')),
                    'email'               => array('type' => 'email', 'label' => __('Email', 'capoferrisagl')),
                    'vat'                 => array('type' => 'text', 'label' => __('Dati fiscali', 'capoferrisagl'), 'desc' => __('Facoltativo.', 'capoferrisagl')),
                    'hours'               => array('type' => 'textarea', 'label' => __('Orari', 'capoferrisagl'), 'rows' => 4, 'desc' => __('Una riga per fascia oraria.', 'capoferrisagl')),
                    'map_url'             => array('type' => 'url', 'label' => __('Link alla mappa', 'capoferrisagl')),
                    'latitude'            => array('type' => 'text', 'label' => __('Latitudine', 'capoferrisagl')),
                    'longitude'           => array('type' => 'text', 'label' => __('Longitudine', 'capoferrisagl')),
                ),
            ),

            'brand' => array(
                'label'  => __('Logo e immagini', 'capoferrisagl'),
                'fields' => array(
                    'logo'        => array('type' => 'image', 'label' => __('Logo principale', 'capoferrisagl')),
                    'logo_alt'    => array('type' => 'image', 'label' => __('Logo alternativo', 'capoferrisagl'), 'desc' => __('Versione per sfondi chiari o scuri.', 'capoferrisagl')),
                    'favicon'     => array('type' => 'image', 'label' => __('Favicon', 'capoferrisagl')),
                    'og_default'  => array('type' => 'image', 'label' => __('Immagine Open Graph predefinita', 'capoferrisagl')),
                    'placeholder' => array('type' => 'image', 'label' => __('Immagine predefinita', 'capoferrisagl'), 'desc' => __('Usata quando un contenuto non ha immagine propria.', 'capoferrisagl')),
                ),
            ),

            'header' => array(
                'label'  => __('Header e menu', 'capoferrisagl'),
                'fields' => array(
                    'cta_text'      => array('type' => 'text', 'label' => __('Call to action dell\'header — testo', 'capoferrisagl')),
                    'cta_url'       => array('type' => 'url', 'label' => __('Call to action dell\'header — link', 'capoferrisagl')),
                    'mobile_bar'    => array('type' => 'checkbox', 'label' => __('Barra contatti su mobile', 'capoferrisagl'), 'checkbox_label' => __('Mostra la barra fissa con telefono ed email su smartphone', 'capoferrisagl'), 'default' => '1'),
                    'menu_note'     => array('type' => 'note', 'text' => __('<strong>Voci di menu:</strong> si gestiscono in <em>Aspetto → Menu</em>, assegnando il menu alla posizione “Menu Principale”.', 'capoferrisagl')),
                ),
            ),

            'footer' => array(
                'label'  => __('Footer', 'capoferrisagl'),
                'fields' => array(
                    'footer_text'      => array('type' => 'textarea', 'label' => __('Testo del footer', 'capoferrisagl'), 'rows' => 3),
                    'footer_services'  => array('type' => 'text', 'label' => __('Titolo colonna servizi', 'capoferrisagl')),
                    'footer_contacts'  => array('type' => 'text', 'label' => __('Titolo colonna contatti', 'capoferrisagl')),
                    'copyright'        => array('type' => 'text', 'label' => __('Copyright', 'capoferrisagl'), 'desc' => __('Usa %s per inserire l\'anno corrente.', 'capoferrisagl')),
                    'legal_links'      => array(
                        'type'      => 'repeater',
                        'label'     => __('Collegamenti legali', 'capoferrisagl'),
                        'add_label' => __('Aggiungi collegamento', 'capoferrisagl'),
                        'row_title' => 'text',
                        'row_label' => __('Collegamento', 'capoferrisagl'),
                        'empty'     => __('Nessun collegamento inserito.', 'capoferrisagl'),
                        'fields'    => array(
                            'text' => array('type' => 'text', 'label' => __('Testo', 'capoferrisagl')),
                            'url'  => array('type' => 'url', 'label' => __('Link', 'capoferrisagl')),
                        ),
                    ),
                    'facebook'  => array('type' => 'url', 'label' => __('Facebook', 'capoferrisagl')),
                    'linkedin'  => array('type' => 'url', 'label' => __('LinkedIn', 'capoferrisagl')),
                    'instagram' => array('type' => 'url', 'label' => __('Instagram', 'capoferrisagl')),
                ),
            ),

            'system' => array(
                'label'  => __('Testi di sistema e 404', 'capoferrisagl'),
                'fields' => array(
                    'e404_title' => array('type' => 'text', 'label' => __('404 — Titolo', 'capoferrisagl')),
                    'e404_text'  => array('type' => 'textarea', 'label' => __('404 — Testo', 'capoferrisagl'), 'rows' => 3),
                    'e404_btn'   => array('type' => 'text', 'label' => __('404 — Testo del pulsante', 'capoferrisagl')),
                    'e404_url'   => array('type' => 'url', 'label' => __('404 — Link del pulsante', 'capoferrisagl')),
                    'cta_title'  => array('type' => 'text', 'label' => __('Call to action globale — titolo', 'capoferrisagl'), 'desc' => __('Usata nelle pagine servizio che non hanno una CTA propria.', 'capoferrisagl')),
                    'cta_text'   => array('type' => 'textarea', 'label' => __('Call to action globale — testo', 'capoferrisagl'), 'rows' => 2),
                    'cta_btn1_text' => array('type' => 'text', 'label' => __('CTA globale — pulsante principale', 'capoferrisagl')),
                    'cta_btn1_url'  => array('type' => 'url', 'label' => __('CTA globale — link principale', 'capoferrisagl')),
                    'cta_btn2_text' => array('type' => 'text', 'label' => __('CTA globale — pulsante secondario', 'capoferrisagl')),
                    'cta_btn2_url'  => array('type' => 'url', 'label' => __('CTA globale — link secondario', 'capoferrisagl')),
                    'breadcrumb_home' => array('type' => 'text', 'label' => __('Breadcrumb — etichetta home', 'capoferrisagl')),
                    'related_title'   => array('type' => 'text', 'label' => __('Titolo “Altri servizi”', 'capoferrisagl'), 'desc' => __('Mostrato in fondo alle pagine dei servizi. Lascia vuoto per nascondere la sezione.', 'capoferrisagl')),
                ),
            ),
        )
    );
}

/* ─────────────────────────────────────────────
   GALLERIA LAVORI
   ───────────────────────────────────────────── */

function cfs_page_gallery()
{
    if (!current_user_can('edit_pages')) {
        wp_die(esc_html__('Permessi insufficienti.', 'capoferrisagl'));
    }

    $services = get_posts(array(
        'post_type'      => 'cfs_servizio',
        'post_status'    => array('publish', 'draft'),
        'posts_per_page' => -1,
        'orderby'        => 'menu_order title',
        'order'          => 'ASC',
    ));
    ?>
    <div class="wrap cfs-admin">
        <h1 class="cfs-admin__title"><?php esc_html_e('Galleria lavori', 'capoferrisagl'); ?></h1>
        <p class="cfs-admin__intro">
            <?php esc_html_e('Le immagini dei lavori sono organizzate per servizio. La galleria della home mostra tutte le immagini dei servizi pubblicati, nell\'ordine impostato qui.', 'capoferrisagl'); ?>
        </p>

        <?php if (!$services) : ?>
            <div class="cfs-empty-state cfs-empty-state--big">
                <p><?php esc_html_e('Non hai ancora creato nessun servizio: crea prima un servizio, poi potrai assegnargli le immagini.', 'capoferrisagl'); ?></p>
                <a class="button button-primary" href="<?php echo esc_url(admin_url('post-new.php?post_type=cfs_servizio')); ?>"><?php esc_html_e('Aggiungi servizio', 'capoferrisagl'); ?></a>
            </div>
        <?php else : ?>
            <div class="cfs-gallery-grid">
                <?php foreach ($services as $service) :
                    $gallery = cfs_service_gallery($service->ID);
                    $cover   = cfs_service_cover($service->ID); ?>
                    <article class="cfs-gallery-card">
                        <header>
                            <h2><?php echo esc_html($service->post_title); ?></h2>
                            <?php if ($service->post_status !== 'publish') : ?>
                                <span class="cfs-badge cfs-badge--draft"><?php esc_html_e('bozza', 'capoferrisagl'); ?></span>
                            <?php endif; ?>
                        </header>
                        <div class="cfs-gallery-card__cover">
                            <?php if ($cover) : ?>
                                <?php echo wp_get_attachment_image($cover, 'thumbnail'); ?>
                                <span><?php esc_html_e('Copertina', 'capoferrisagl'); ?></span>
                            <?php else : ?>
                                <p class="cfs-empty-state"><?php esc_html_e('Seleziona un\'immagine di copertina.', 'capoferrisagl'); ?></p>
                            <?php endif; ?>
                        </div>
                        <p class="cfs-gallery-card__count">
                            <?php
                            printf(
                                esc_html(_n('%d immagine in galleria', '%d immagini in galleria', count($gallery), 'capoferrisagl')),
                                count($gallery)
                            );
                            ?>
                        </p>
                        <?php if ($gallery) : ?>
                            <ul class="cfs-gallery-card__thumbs">
                                <?php foreach (array_slice($gallery, 0, 8) as $image_id) : ?>
                                    <li><?php echo wp_get_attachment_image($image_id, 'thumbnail'); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        <?php else : ?>
                            <p class="cfs-empty-state"><?php esc_html_e('Non hai ancora aggiunto immagini a questo servizio.', 'capoferrisagl'); ?></p>
                        <?php endif; ?>
                        <a class="button button-secondary" href="<?php echo esc_url(get_edit_post_link($service->ID) . '#cfs_service_data'); ?>">
                            <?php esc_html_e('Gestisci galleria e copertina', 'capoferrisagl'); ?>
                        </a>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    <?php
}

/* ─────────────────────────────────────────────
   ORDINE DEI SERVIZI (drag & drop)
   ───────────────────────────────────────────── */

function cfs_page_order()
{
    if (!current_user_can('edit_posts')) {
        wp_die(esc_html__('Permessi insufficienti.', 'capoferrisagl'));
    }

    $services = get_posts(array(
        'post_type'      => 'cfs_servizio',
        'post_status'    => array('publish', 'draft'),
        'posts_per_page' => -1,
        'orderby'        => 'menu_order title',
        'order'          => 'ASC',
    ));
    ?>
    <div class="wrap cfs-admin">
        <h1 class="cfs-admin__title"><?php esc_html_e('Ordine dei servizi', 'capoferrisagl'); ?></h1>
        <p class="cfs-admin__intro"><?php esc_html_e('Trascina i servizi per definire l\'ordine con cui appaiono nel sito. L\'ordine viene salvato subito.', 'capoferrisagl'); ?></p>

        <?php if (!$services) : ?>
            <p class="cfs-empty-state"><?php esc_html_e('Non hai ancora creato nessun servizio.', 'capoferrisagl'); ?></p>
        <?php else : ?>
            <ul class="cfs-order-list" data-cfs-order data-nonce="<?php echo esc_attr(wp_create_nonce('cfs_reorder')); ?>">
                <?php foreach ($services as $service) :
                    $cover = cfs_service_cover($service->ID); ?>
                    <li data-id="<?php echo esc_attr($service->ID); ?>">
                        <span class="cfs-drag" aria-hidden="true">⋮⋮</span>
                        <?php if ($cover) : ?>
                            <?php echo wp_get_attachment_image($cover, array(60, 45)); ?>
                        <?php endif; ?>
                        <strong><?php echo esc_html($service->post_title); ?></strong>
                        <?php if ($service->post_status !== 'publish') : ?>
                            <span class="cfs-badge cfs-badge--draft"><?php esc_html_e('bozza', 'capoferrisagl'); ?></span>
                        <?php endif; ?>
                        <a href="<?php echo esc_url(get_edit_post_link($service->ID)); ?>"><?php esc_html_e('Modifica', 'capoferrisagl'); ?></a>
                    </li>
                <?php endforeach; ?>
            </ul>
            <p class="cfs-order-feedback" data-feedback aria-live="polite"></p>
        <?php endif; ?>
    </div>
    <?php
}
