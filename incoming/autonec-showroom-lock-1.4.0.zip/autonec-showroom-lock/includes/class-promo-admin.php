<?php
/**
 * Admin pages for the online promo: settings and booking requests.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ASL_Promo_Admin {

    const HOOK_SETTINGS = 'showroom-lock_page_asl-promo';
    const HOOK_REQUESTS = 'showroom-lock_page_asl-promo-requests';

    public function init(): void {
        add_action( 'admin_menu',            [ $this, 'add_menu' ], 20 );
        add_action( 'admin_init',            [ $this, 'register_settings' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue' ] );
        add_action( 'admin_post_asl_promo_create_page', [ $this, 'create_page' ] );
        add_action( 'wp_ajax_asl_promo_delete',         [ $this, 'ajax_delete' ] );
        add_action( 'wp_ajax_asl_promo_export',         [ $this, 'export_csv' ] );
        add_action( 'wp_ajax_asl_promo_photo',          [ $this, 'serve_photo' ] );
    }

    /* -------------------------------------------------------------- */
    /*  Menu & assets                                                  */
    /* -------------------------------------------------------------- */

    public function add_menu(): void {
        add_submenu_page(
            'asl-email',
            __( 'Promo online', 'autonec-showroom-lock' ),
            __( 'Promo online', 'autonec-showroom-lock' ),
            'manage_options',
            'asl-promo',
            [ $this, 'render_settings_page' ]
        );

        add_submenu_page(
            'asl-email',
            __( 'Prenotazioni promo', 'autonec-showroom-lock' ),
            __( 'Prenotazioni promo', 'autonec-showroom-lock' ),
            'manage_options',
            'asl-promo-requests',
            [ $this, 'render_requests_page' ]
        );
    }

    public function enqueue( string $hook ): void {
        if ( ! in_array( $hook, [ self::HOOK_SETTINGS, self::HOOK_REQUESTS ], true ) ) {
            return;
        }
        wp_enqueue_style( 'asl-admin', ASL_PLUGIN_URL . 'assets/css/admin.css', [], ASL_VERSION );
        if ( self::HOOK_SETTINGS === $hook ) {
            wp_enqueue_media();
        }
        wp_enqueue_script( 'asl-promo-admin', ASL_PLUGIN_URL . 'assets/js/promo-admin.js', [ 'jquery' ], ASL_VERSION, true );
        wp_localize_script( 'asl-promo-admin', 'aslPromoAdmin', [
            'chooseLogo' => __( 'Scegli il logo', 'autonec-showroom-lock' ),
            'chooseFile' => __( 'Scegli l’allegato per il cliente', 'autonec-showroom-lock' ),
            'useFile'    => __( 'Allega questo file', 'autonec-showroom-lock' ),
            'noFile'     => __( 'Nessun allegato', 'autonec-showroom-lock' ),
            'useLogo'    => __( 'Usa questo logo', 'autonec-showroom-lock' ),
            /* translators: %d: number of selected requests */
            'confirm'    => __( 'Eliminare %d prenotazioni? L’azione è irreversibile.', 'autonec-showroom-lock' ),
            'deleting'   => __( 'Eliminazione in corso…', 'autonec-showroom-lock' ),
            'netError'   => __( 'Errore di connessione.', 'autonec-showroom-lock' ),
        ] );
    }

    /* -------------------------------------------------------------- */
    /*  Settings                                                       */
    /* -------------------------------------------------------------- */

    public function register_settings(): void {
        register_setting( 'asl_promo_group', ASL_Promo::OPTION, [
            'type'              => 'array',
            'sanitize_callback' => [ $this, 'sanitize' ],
        ] );
    }

    public function sanitize( $input ): array {
        $input = (array) $input;
        $clean = ASL_Promo::get();

        /* The settings form has no page_id: only create_page() sets it. */
        $clean['page_id']  = absint( $input['page_id'] ?? $clean['page_id'] );
        $clean['discount'] = max( 1, min( 50, absint( $input['discount'] ?? 5 ) ) );
        $clean['logo_id']  = absint( $input['logo_id'] ?? 0 );
        $clean['logo_suffix'] = mb_substr( sanitize_text_field( $input['logo_suffix'] ?? '' ), 0, 20 );

        $emails              = preg_split( '/[,;\s]+/', sanitize_textarea_field( $input['recipients'] ?? '' ), -1, PREG_SPLIT_NO_EMPTY );
        $clean['recipients'] = implode( ', ', array_filter( array_map( 'trim', $emails ), 'is_email' ) );

        $clean['privacy_url']    = esc_url_raw( trim( $input['privacy_url'] ?? '' ) );
        $clean['email_subject']  = sanitize_text_field( $input['email_subject'] ?? '' ) ?: ASL_Promo::defaults()['email_subject'];
        $clean['email_template'] = sanitize_textarea_field( $input['email_template'] ?? '' ) ?: ASL_Promo::default_email();

        $file_id                         = absint( $input['customer_attachment_id'] ?? 0 );
        $clean['customer_attachment_id'] = $file_id && 'attachment' === get_post_type( $file_id ) ? $file_id : 0;

        return $clean;
    }

    /* -------------------------------------------------------------- */
    /*  Create the promo page                                          */
    /* -------------------------------------------------------------- */

    public function create_page(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Permesso negato.', 'autonec-showroom-lock' ) );
        }
        check_admin_referer( 'asl_promo_create_page' );

        $page_id = wp_insert_post( [
            'post_type'    => 'page',
            'post_status'  => 'publish',
            'post_title'   => __( 'Promo online', 'autonec-showroom-lock' ),
            'post_name'    => 'promo-online',
            'post_content' => '<!-- wp:shortcode -->[' . ASL_Promo::SHORTCODE . ']<!-- /wp:shortcode -->',
            'meta_input'   => [ '_wp_page_template' => ASL_Promo::TEMPLATE ],
        ], true );

        if ( ! is_wp_error( $page_id ) ) {
            $opts            = ASL_Promo::get();
            $opts['page_id'] = $page_id;
            update_option( ASL_Promo::OPTION, $opts, false );
        }

        wp_safe_redirect( admin_url( 'admin.php?page=asl-promo&created=' . ( is_wp_error( $page_id ) ? 0 : 1 ) ) );
        exit;
    }

    /** The configured page, or the first page using the shortcode. */
    private function promo_page_id(): int {
        $page_id = absint( ASL_Promo::get( 'page_id' ) );
        if ( $page_id && 'trash' !== get_post_status( $page_id ) && get_post( $page_id ) ) {
            return $page_id;
        }
        $found = get_posts( [
            'post_type'      => 'page',
            'post_status'    => [ 'publish', 'draft', 'private' ],
            's'              => '[' . ASL_Promo::SHORTCODE,
            'posts_per_page' => 1,
            'fields'         => 'ids',
        ] );
        return $found ? (int) $found[0] : 0;
    }

    /* -------------------------------------------------------------- */
    /*  Settings page                                                  */
    /* -------------------------------------------------------------- */

    public function render_settings_page(): void {
        $opts     = ASL_Promo::get();
        $name     = ASL_Promo::OPTION;
        $page_id  = $this->promo_page_id();
        $logo_url = ASL_Promo::logo_url();
        ?>
        <div class="wrap asl-wrap">
            <h1><span class="dashicons dashicons-tag"></span> <?php esc_html_e( 'Showroom Lock — Promo online', 'autonec-showroom-lock' ); ?></h1>
            <?php settings_errors(); ?>

            <?php if ( isset( $_GET['created'] ) ) : ?>
                <div class="notice <?php echo '1' === $_GET['created'] ? 'notice-success' : 'notice-error'; ?> is-dismissible">
                    <p><?php echo '1' === $_GET['created'] ? esc_html__( 'Pagina della promo creata.', 'autonec-showroom-lock' ) : esc_html__( 'Non è stato possibile creare la pagina.', 'autonec-showroom-lock' ); ?></p>
                </div>
            <?php endif; ?>

            <!-- Page -->
            <div class="asl-card">
                <h2>📄 <?php esc_html_e( 'Pagina del modulo', 'autonec-showroom-lock' ); ?></h2>
                <?php if ( $page_id ) : ?>
                    <p class="description"><?php esc_html_e( 'Usa questo indirizzo per il QR code e per i link alla promo. La pagina si apre senza header e footer del sito.', 'autonec-showroom-lock' ); ?></p>
                    <table class="asl-time-table">
                        <tr>
                            <th><?php esc_html_e( 'Indirizzo pubblico', 'autonec-showroom-lock' ); ?></th>
                            <td><a href="<?php echo esc_url( get_permalink( $page_id ) ); ?>" target="_blank" class="asl-page-url">🔗 <?php echo esc_html( get_permalink( $page_id ) ); ?></a></td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Modifica pagina', 'autonec-showroom-lock' ); ?></th>
                            <td><a href="<?php echo esc_url( get_edit_post_link( $page_id ) ); ?>" class="asl-page-url">✏️ <?php echo esc_html( get_the_title( $page_id ) ); ?></a></td>
                        </tr>
                    </table>
                    <?php if ( ASL_Promo::TEMPLATE !== get_page_template_slug( $page_id ) ) : ?>
                        <p class="asl-notice-warn">⚠️ <?php esc_html_e( 'Questa pagina mostra ancora header e footer. Nella modifica della pagina scegli il modello «Pagina vuota (senza header e footer)».', 'autonec-showroom-lock' ); ?></p>
                    <?php endif; ?>
                <?php else : ?>
                    <p class="description"><?php esc_html_e( 'La pagina della promo non esiste ancora. Creala con un clic: avrà il modulo e nessun header né footer.', 'autonec-showroom-lock' ); ?></p>
                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                        <input type="hidden" name="action" value="asl_promo_create_page">
                        <?php wp_nonce_field( 'asl_promo_create_page' ); ?>
                        <?php submit_button( __( 'Crea la pagina della promo', 'autonec-showroom-lock' ), 'primary', 'submit', false ); ?>
                    </form>
                <?php endif; ?>
            </div>

            <form method="post" action="options.php">
                <?php settings_fields( 'asl_promo_group' ); ?>

                <!-- Discount & logo -->
                <div class="asl-card">
                    <h2>🏷 <?php esc_html_e( 'Sconto e logo', 'autonec-showroom-lock' ); ?></h2>
                    <table class="asl-time-table">
                        <tr>
                            <th><label for="asl-promo-discount"><?php esc_html_e( 'Sconto promo', 'autonec-showroom-lock' ); ?></label></th>
                            <td><input type="number" id="asl-promo-discount" name="<?php echo esc_attr( $name ); ?>[discount]" min="1" max="50" step="1" value="<?php echo esc_attr( ASL_Promo::discount() ); ?>" style="width:5rem"> %</td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Logo in alto', 'autonec-showroom-lock' ); ?></th>
                            <td>
                                <div class="asl-promo-logo">
                                    <img id="asl-promo-logo-preview" src="<?php echo esc_url( $logo_url ); ?>" alt="" style="max-height:60px;<?php echo $logo_url ? '' : 'display:none;'; ?>">
                                    <input type="hidden" id="asl-promo-logo-id" name="<?php echo esc_attr( $name ); ?>[logo_id]" value="<?php echo esc_attr( absint( $opts['logo_id'] ) ); ?>">
                                    <button type="button" class="button" id="asl-promo-logo-pick"><?php esc_html_e( 'Scegli logo', 'autonec-showroom-lock' ); ?></button>
                                    <button type="button" class="button-link" id="asl-promo-logo-reset" <?php echo absint( $opts['logo_id'] ) ? '' : 'hidden'; ?>><?php esc_html_e( 'Usa il logo del sito', 'autonec-showroom-lock' ); ?></button>
                                </div>
                                <p class="description"><?php esc_html_e( 'Se non scegli nulla viene usato il logo del sito. Meglio un logo a sfondo trasparente con scritte scure.', 'autonec-showroom-lock' ); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="asl-promo-suffix"><?php esc_html_e( 'Testo accanto al logo', 'autonec-showroom-lock' ); ?></label></th>
                            <td>
                                <input type="text" id="asl-promo-suffix" name="<?php echo esc_attr( $name ); ?>[logo_suffix]" value="<?php echo esc_attr( $opts['logo_suffix'] ); ?>" maxlength="20" style="width:8rem" placeholder="365">
                                <p class="description"><?php esc_html_e( 'Facoltativo, in rosso dopo il logo (es. 365).', 'autonec-showroom-lock' ); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Notifications -->
                <div class="asl-card">
                    <h2>📧 <?php esc_html_e( 'Chi riceve le prenotazioni', 'autonec-showroom-lock' ); ?></h2>
                    <p class="description"><?php esc_html_e( 'Indirizzi e-mail avvisati a ogni prenotazione, separati da virgola. Se lasci vuoto vengono usati gli indirizzi della pagina Email di Showroom Lock.', 'autonec-showroom-lock' ); ?></p>
                    <textarea name="<?php echo esc_attr( $name ); ?>[recipients]" rows="2" class="large-text" placeholder="<?php echo esc_attr( implode( ', ', ASL_Promo::recipients() ) ); ?>"><?php echo esc_textarea( $opts['recipients'] ); ?></textarea>
                </div>

                <!-- Privacy -->
                <div class="asl-card">
                    <h2>🔒 <?php esc_html_e( 'Informativa privacy', 'autonec-showroom-lock' ); ?></h2>
                    <p class="description"><?php esc_html_e( 'Pagina aperta dal link nel consenso del modulo. Se lasci vuoto viene usata la pagina privacy del sito.', 'autonec-showroom-lock' ); ?></p>
                    <input type="url" name="<?php echo esc_attr( $name ); ?>[privacy_url]" value="<?php echo esc_attr( $opts['privacy_url'] ); ?>" class="large-text" placeholder="<?php echo esc_attr( get_privacy_policy_url() ?: home_url( '/privacy/' ) ); ?>">
                </div>

                <!-- Customer e-mail -->
                <div class="asl-card">
                    <h2>✉️ <?php esc_html_e( 'E-mail di conferma al cliente', 'autonec-showroom-lock' ); ?></h2>
                    <p class="description"><?php esc_html_e( 'Il cliente la riceve subito dopo aver inviato il modulo.', 'autonec-showroom-lock' ); ?></p>
                    <div class="asl-placeholders">
                        <span class="asl-placeholder-label"><?php esc_html_e( 'Segnaposto disponibili — clicca per inserire nel testo', 'autonec-showroom-lock' ); ?></span>
                        <?php foreach ( ASL_Promo::placeholders() as $ph => $desc ) : ?>
                            <button type="button" class="asl-pill" data-ph="<?php echo esc_attr( $ph ); ?>">
                                <?php echo esc_html( $ph ); ?> <span class="asl-pill-desc">— <?php echo esc_html( $desc ); ?></span>
                            </button>
                        <?php endforeach; ?>
                    </div>
                    <?php $file = ASL_Promo::customer_attachment(); ?>
                    <p style="margin-top:1.25rem; margin-bottom:0.35rem; font-weight:600; font-size:0.875rem; color:#334155;"><?php esc_html_e( 'Allegato per il cliente', 'autonec-showroom-lock' ); ?></p>
                    <div class="asl-promo-file">
                        <input type="hidden" id="asl-promo-file-id" name="<?php echo esc_attr( $name ); ?>[customer_attachment_id]" value="<?php echo esc_attr( $file ? absint( $opts['customer_attachment_id'] ) : 0 ); ?>">
                        <span id="asl-promo-file-name" style="margin-right:.75rem;">
                            <?php if ( $file ) : ?>
                                📎 <a href="<?php echo esc_url( wp_get_attachment_url( absint( $opts['customer_attachment_id'] ) ) ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $file['title'] ); ?></a>
                            <?php else : ?>
                                <?php esc_html_e( 'Nessun allegato', 'autonec-showroom-lock' ); ?>
                            <?php endif; ?>
                        </span>
                        <button type="button" class="button" id="asl-promo-file-pick"><?php esc_html_e( 'Scegli file', 'autonec-showroom-lock' ); ?></button>
                        <button type="button" class="button-link" id="asl-promo-file-remove" <?php echo $file ? '' : 'hidden'; ?>><?php esc_html_e( 'Rimuovi', 'autonec-showroom-lock' ); ?></button>
                    </div>
                    <p class="description"><?php esc_html_e( 'Facoltativo: un PDF o un’immagine dalla libreria media (es. la cedola di pagamento), allegato a ogni e-mail di conferma. Nel testo il segnaposto {allegato} lo annuncia al cliente.', 'autonec-showroom-lock' ); ?></p>

                    <p style="margin-top:1.25rem; margin-bottom:0.35rem; font-weight:600; font-size:0.875rem; color:#334155;"><?php esc_html_e( 'Oggetto dell’e-mail', 'autonec-showroom-lock' ); ?></p>
                    <input type="text" name="<?php echo esc_attr( $name ); ?>[email_subject]" value="<?php echo esc_attr( $opts['email_subject'] ); ?>" class="large-text" style="margin-bottom:1.25rem;">
                    <p style="margin-bottom:0.35rem; font-weight:600; font-size:0.875rem; color:#334155;"><?php esc_html_e( 'Testo del messaggio', 'autonec-showroom-lock' ); ?></p>
                    <textarea name="<?php echo esc_attr( $name ); ?>[email_template]" rows="14" class="large-text"><?php echo esc_textarea( $opts['email_template'] ); ?></textarea>
                </div>

                <?php submit_button( __( 'Salva impostazioni promo', 'autonec-showroom-lock' ) ); ?>
            </form>
        </div>
        <?php
    }

    /* -------------------------------------------------------------- */
    /*  Requests page                                                  */
    /* -------------------------------------------------------------- */

    public function render_requests_page(): void {
        ASL_Promo::maybe_create_table();

        /* Links from the CSV: admin.php?page=asl-promo-requests&photo=ID */
        if ( isset( $_GET['photo'] ) ) {
            $url = ASL_Promo::photo_admin_url( absint( $_GET['photo'] ) );
            echo '<script>location.replace(' . wp_json_encode( $url ) . ');</script>';
            return;
        }
        $rows     = ASL_Promo::get_all();
        $count    = count( $rows );
        $payments = ASL_Promo::payment_labels();
        $csv_url  = wp_nonce_url( admin_url( 'admin-ajax.php?action=asl_promo_export' ), 'asl_promo_export' );
        ?>
        <div class="wrap asl-wrap asl-wrap-wide">
            <h1><span class="dashicons dashicons-cart"></span> <?php esc_html_e( 'Showroom Lock — Prenotazioni promo', 'autonec-showroom-lock' ); ?></h1>

            <?php if ( ! $rows ) : ?>
                <div class="asl-card">
                    <p style="color:#64748b; margin:0;">
                        <?php esc_html_e( 'Nessuna prenotazione per ora. Quando un cliente compila il modulo della promo online la trovi qui e ricevi un’e-mail.', 'autonec-showroom-lock' ); ?>
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=asl-promo' ) ); ?>"><?php esc_html_e( 'Impostazioni della promo', 'autonec-showroom-lock' ); ?></a>
                    </p>
                </div>
            <?php else : ?>
                <div class="asl-visitors-toolbar">
                    <div class="asl-toolbar-left">
                        <span class="asl-visitor-count">
                            <?php
                            /* translators: %d: number of booking requests */
                            echo esc_html( sprintf( _n( '%d prenotazione', '%d prenotazioni', $count, 'autonec-showroom-lock' ), $count ) );
                            ?>
                        </span>
                        <button type="button" id="asl-promo-delete" class="button asl-btn-delete" disabled>
                            🗑 <?php esc_html_e( 'Elimina selezionate', 'autonec-showroom-lock' ); ?> (<span id="asl-promo-sel-count">0</span>)
                        </button>
                        <span id="asl-promo-msg" class="asl-delete-msg"></span>
                    </div>
                    <div class="asl-toolbar-right">
                        <a href="<?php echo esc_url( $csv_url ); ?>" class="button asl-btn-export">📥 <?php esc_html_e( 'Esporta CSV', 'autonec-showroom-lock' ); ?></a>
                    </div>
                </div>

                <div class="asl-card asl-card-table">
                    <div class="asl-table-scroll">
                        <table class="widefat asl-visitors-table">
                            <thead>
                                <tr>
                                    <th class="asl-col-check"><input type="checkbox" id="asl-promo-check-all" aria-label="<?php esc_attr_e( 'Seleziona tutte', 'autonec-showroom-lock' ); ?>"></th>
                                    <th class="asl-col-date"><?php esc_html_e( 'Data / Ora', 'autonec-showroom-lock' ); ?></th>
                                    <th><?php esc_html_e( 'Foto', 'autonec-showroom-lock' ); ?></th>
                                    <th><?php esc_html_e( 'Nome', 'autonec-showroom-lock' ); ?></th>
                                    <th><?php esc_html_e( 'Cognome', 'autonec-showroom-lock' ); ?></th>
                                    <th><?php esc_html_e( 'N. auto', 'autonec-showroom-lock' ); ?></th>
                                    <th><?php esc_html_e( 'Modello', 'autonec-showroom-lock' ); ?></th>
                                    <th><?php esc_html_e( 'Pagamento', 'autonec-showroom-lock' ); ?></th>
                                    <th><?php esc_html_e( 'Sconto', 'autonec-showroom-lock' ); ?></th>
                                    <th><?php esc_html_e( 'Telefono', 'autonec-showroom-lock' ); ?></th>
                                    <th><?php esc_html_e( 'E-mail', 'autonec-showroom-lock' ); ?></th>
                                    <th><?php esc_html_e( 'Indirizzo', 'autonec-showroom-lock' ); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ( $rows as $r ) : ?>
                                    <tr data-id="<?php echo esc_attr( $r->id ); ?>">
                                        <td><input type="checkbox" class="asl-promo-row" value="<?php echo esc_attr( $r->id ); ?>"></td>
                                        <td class="asl-nowrap"><?php echo esc_html( self::local_date( $r->created_gmt ) ); ?></td>
                                        <td>
                                            <?php if ( ASL_Promo::photo_path( (string) ( $r->photo ?? '' ) ) ) : ?>
                                                <a href="<?php echo esc_url( ASL_Promo::photo_admin_url( (int) $r->id ) ); ?>" target="_blank" rel="noopener" title="<?php esc_attr_e( 'Apri la foto', 'autonec-showroom-lock' ); ?>">
                                                    <img src="<?php echo esc_url( ASL_Promo::photo_admin_url( (int) $r->id, true ) ); ?>" alt="<?php echo esc_attr( sprintf( /* translators: %s: car model */ __( 'Foto: %s', 'autonec-showroom-lock' ), $r->model ) ); ?>" width="72" height="54" loading="lazy" style="display:block;width:72px;height:54px;object-fit:cover;border-radius:6px;">
                                                </a>
                                            <?php else : ?>
                                                —
                                            <?php endif; ?>
                                        </td>
                                        <td class="asl-nowrap"><?php echo esc_html( $r->first_name ); ?></td>
                                        <td class="asl-nowrap"><?php echo esc_html( $r->last_name ); ?></td>
                                        <td class="asl-nowrap"><strong><?php echo esc_html( $r->car_number ); ?></strong></td>
                                        <td class="asl-nowrap"><?php echo esc_html( $r->model ); ?></td>
                                        <td class="asl-nowrap"><?php echo esc_html( $payments[ $r->payment ] ?? $r->payment ); ?></td>
                                        <td><?php echo esc_html( $r->discount ); ?>%</td>
                                        <td class="asl-nowrap"><a href="tel:<?php echo esc_attr( $r->phone ); ?>"><?php echo esc_html( $r->phone ); ?></a></td>
                                        <td class="asl-nowrap"><a href="mailto:<?php echo esc_attr( $r->email ); ?>"><?php echo esc_html( $r->email ); ?></a></td>
                                        <td class="asl-nowrap"><?php echo esc_html( $r->address ); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php wp_nonce_field( 'asl_promo_delete', 'asl-promo-nonce', false ); ?>
            <?php endif; ?>
        </div>
        <?php
    }

    /** Streams a car photo to logged-in managers (the folder is closed to the public). */
    public function serve_photo(): void {
        $id = absint( $_GET['id'] ?? 0 );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Permesso negato.', 'autonec-showroom-lock' ), '', 403 );
        }
        check_admin_referer( 'asl_promo_photo_' . $id );

        $row  = ASL_Promo::get_row( $id );
        $path = $row ? ASL_Promo::photo_path( (string) $row->photo ) : '';
        if ( ! $path ) {
            wp_die( esc_html__( 'Foto non trovata.', 'autonec-showroom-lock' ), '', 404 );
        }

        if ( 'thumb' === ( $_GET['size'] ?? '' ) && is_file( ASL_Promo::thumb_of( $path ) ) ) {
            $path = ASL_Promo::thumb_of( $path );
        }

        $type = wp_check_filetype( $path )['type'] ?: 'application/octet-stream';
        nocache_headers();
        header( 'Content-Type: ' . $type );
        header( 'Content-Length: ' . filesize( $path ) );
        header( 'Content-Disposition: inline; filename="auto-' . $id . '.' . pathinfo( $path, PATHINFO_EXTENSION ) . '"' );
        header( 'X-Content-Type-Options: nosniff' );
        readfile( $path );
        exit;
    }

    private static function local_date( string $gmt ): string {
        return wp_date( 'd/m/Y H:i', strtotime( $gmt . ' UTC' ) );
    }

    /* -------------------------------------------------------------- */
    /*  AJAX: delete, export                                           */
    /* -------------------------------------------------------------- */

    public function ajax_delete(): void {
        check_ajax_referer( 'asl_promo_delete', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => __( 'Permesso negato.', 'autonec-showroom-lock' ) ] );
        }

        $deleted = ASL_Promo::delete_by_ids( (array) ( $_POST['ids'] ?? [] ) );

        wp_send_json_success( [
            /* translators: %d: number of deleted requests */
            'message' => sprintf( _n( '%d prenotazione eliminata.', '%d prenotazioni eliminate.', $deleted, 'autonec-showroom-lock' ), $deleted ),
        ] );
    }

    public function export_csv(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Permesso negato.', 'autonec-showroom-lock' ) );
        }
        check_admin_referer( 'asl_promo_export' );

        $payments = ASL_Promo::payment_labels();

        header( 'Content-Type: text/csv; charset=UTF-8' );
        header( 'Content-Disposition: attachment; filename="prenotazioni-promo-' . wp_date( 'Y-m-d' ) . '.csv"' );
        nocache_headers();

        $out = fopen( 'php://output', 'w' );
        fwrite( $out, "\xEF\xBB\xBF" );
        fputcsv( $out, [ 'ID', 'Data/Ora', 'Nome', 'Cognome', 'Indirizzo', 'E-mail', 'Telefono', 'Numero auto', 'Modello', 'Pagamento', 'Sconto %', 'Foto', 'IP' ], ';' );

        foreach ( ASL_Promo::get_all( 10000 ) as $r ) {
            fputcsv( $out, array_map( [ __CLASS__, 'csv_cell' ], [
                $r->id,
                self::local_date( $r->created_gmt ),
                $r->first_name,
                $r->last_name,
                $r->address,
                $r->email,
                $r->phone,
                $r->car_number,
                $r->model,
                $payments[ $r->payment ] ?? $r->payment,
                $r->discount,
                ASL_Promo::photo_path( (string) ( $r->photo ?? '' ) ) ? add_query_arg( [ 'page' => 'asl-promo-requests', 'photo' => $r->id ], admin_url( 'admin.php' ) ) : '',
                $r->ip_address,
            ] ), ';' );
        }

        fclose( $out );
        exit;
    }

    /** Neutralise spreadsheet formulas typed into public form fields (plain numbers like +41… stay as they are). */
    private static function csv_cell( $value ): string {
        $value = (string) $value;
        return preg_match( '/^(?:[=@\t\r]|[+\-](?![\d\s]+$))/', $value ) ? "'" . $value : $value;
    }
}
