<?php
/**
 * Promo online: booking form with discount on a page without header and footer.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ASL_Promo {

    /** Option key used in wp_options */
    const OPTION = 'asl_promo_settings';

    /** Requests table (without prefix) */
    const TABLE = 'asl_promo_requests';

    /** Bump when the table schema changes */
    const DB_VERSION = '2';

    /** Page template slug registered by the plugin */
    const TEMPLATE = 'asl-promo-blank.php';

    const SHORTCODE = 'autonec_promo';

    /** Car photos: folder inside uploads, not public (see protect_photo_dir) */
    const PHOTO_DIR = 'autonec-promo';

    /** Max photo size in bytes (the browser already shrinks it to ~2000px) */
    const PHOTO_MAX = 20 * MB_IN_BYTES;

    /** Max submissions per IP in RATE_WINDOW seconds */
    const RATE_LIMIT  = 5;
    const RATE_WINDOW = 900;

    /* -------------------------------------------------------------- */
    /*  Bootstrap                                                      */
    /* -------------------------------------------------------------- */

    public function init(): void {
        add_shortcode( self::SHORTCODE, [ $this, 'render_shortcode' ] );
        add_filter( 'theme_page_templates', [ $this, 'register_template' ] );
        add_filter( 'template_include',     [ $this, 'load_template' ], 99 );
        add_action( 'template_redirect',    [ $this, 'disable_cache' ] );
        add_action( 'wp_enqueue_scripts',   [ $this, 'enqueue' ] );
        add_action( 'wp_ajax_asl_promo_submit',        [ $this, 'handle_ajax' ] );
        add_action( 'wp_ajax_nopriv_asl_promo_submit', [ $this, 'handle_ajax' ] );
        add_action( 'admin_init', [ __CLASS__, 'maybe_create_table' ] );
    }

    /* -------------------------------------------------------------- */
    /*  Settings                                                       */
    /* -------------------------------------------------------------- */

    public static function defaults(): array {
        return [
            'page_id'        => 0,
            'discount'       => 5,
            'logo_id'        => 0,
            'logo_suffix'    => '',
            'recipients'     => '',
            'privacy_url'    => '',
            'email_subject'  => __( '{sito} — Abbiamo ricevuto la tua prenotazione', 'autonec-showroom-lock' ),
            'email_template' => self::default_email(),
            'customer_attachment_id' => 0,
        ];
    }

    public static function default_email(): string {
        return __( "Gentile {nome} {cognome},\n\ngrazie per aver prenotato l'acquisto online.\n\nAbbiamo riservato per te lo sconto del {sconto}% sull'auto che hai scelto:\n\n🚗  Auto n.: {numero_auto}\n🏷  Modello: {modello}\n💳  Pagamento: {pagamento}\n\nTi contatteremo al più presto. La promozione è confermata con la firma del contratto; in caso di leasing l'acquisto è da intendersi salvo concessione del credito.\n\n{allegato}\n\nCordiali saluti,\n{sito}", 'autonec-showroom-lock' );
    }

    public static function get( string $key = '' ) {
        $opts = wp_parse_args( (array) get_option( self::OPTION, [] ), self::defaults() );
        if ( '' === $key ) {
            return $opts;
        }
        return $opts[ $key ] ?? null;
    }

    public static function discount(): int {
        return max( 1, min( 50, absint( self::get( 'discount' ) ) ) );
    }

    public static function payment_labels(): array {
        return [
            'leasing' => __( 'Leasing', 'autonec-showroom-lock' ),
            'cash'    => __( 'Cash', 'autonec-showroom-lock' ),
        ];
    }

    /** Notification recipients: promo setting, else Showroom Lock e-mails, else site admin. */
    public static function recipients(): array {
        foreach ( [ self::get( 'recipients' ), ASL_Admin::get( 'notification_emails', '' ) ] as $raw ) {
            $list = array_filter( array_map( 'trim', preg_split( '/[,;\s]+/', (string) $raw, -1, PREG_SPLIT_NO_EMPTY ) ), 'is_email' );
            if ( $list ) {
                return array_values( $list );
            }
        }
        return [ get_option( 'admin_email' ) ];
    }

    public static function logo_url(): string {
        $id = absint( self::get( 'logo_id' ) ) ?: absint( get_theme_mod( 'custom_logo' ) );
        return $id ? (string) wp_get_attachment_image_url( $id, 'medium_large' ) : '';
    }

    public static function privacy_url(): string {
        return (string) ( self::get( 'privacy_url' ) ?: get_privacy_policy_url() );
    }

    /* -------------------------------------------------------------- */
    /*  Table                                                          */
    /* -------------------------------------------------------------- */

    public static function table(): string {
        global $wpdb;
        return $wpdb->prefix . self::TABLE;
    }

    public static function maybe_create_table(): void {
        if ( get_option( 'asl_promo_db_version' ) === self::DB_VERSION ) {
            return;
        }
        self::create_table();
    }

    public static function create_table(): void {
        global $wpdb;
        $table   = self::table();
        $charset = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table} (
            id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            first_name  VARCHAR(100) NOT NULL DEFAULT '',
            last_name   VARCHAR(100) NOT NULL DEFAULT '',
            address     VARCHAR(255) NOT NULL DEFAULT '',
            email       VARCHAR(100) NOT NULL DEFAULT '',
            phone       VARCHAR(50)  NOT NULL DEFAULT '',
            car_number  VARCHAR(50)  NOT NULL DEFAULT '',
            model       VARCHAR(150) NOT NULL DEFAULT '',
            payment     VARCHAR(20)  NOT NULL DEFAULT '',
            photo       VARCHAR(255) NOT NULL DEFAULT '',
            discount    TINYINT UNSIGNED NOT NULL DEFAULT 0,
            locale      VARCHAR(20)  NOT NULL DEFAULT '',
            ip_address  VARCHAR(45)  NOT NULL DEFAULT '',
            created_gmt DATETIME     NOT NULL,
            PRIMARY KEY  (id),
            KEY idx_created (created_gmt)
        ) {$charset};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
        update_option( 'asl_promo_db_version', self::DB_VERSION );
    }

    public static function insert( array $data ): int {
        global $wpdb;
        $wpdb->insert( self::table(), [
            'first_name'  => $data['first_name'],
            'last_name'   => $data['last_name'],
            'address'     => $data['address'],
            'email'       => $data['email'],
            'phone'       => $data['phone'],
            'car_number'  => $data['car_number'],
            'model'       => $data['model'],
            'payment'     => $data['payment'],
            'photo'       => $data['photo'],
            'discount'    => $data['discount'],
            'locale'      => $data['locale'],
            'ip_address'  => $data['ip_address'],
            'created_gmt' => current_time( 'mysql', true ),
        ], [ '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s' ] );

        return (int) $wpdb->insert_id;
    }

    public static function get_all( int $limit = 500 ): array {
        global $wpdb;
        $table = self::table();
        return (array) $wpdb->get_results(
            $wpdb->prepare( "SELECT * FROM {$table} ORDER BY id DESC LIMIT %d", $limit )
        );
    }

    public static function delete_by_ids( array $ids ): int {
        global $wpdb;
        $ids = array_filter( array_map( 'absint', $ids ) );
        if ( empty( $ids ) ) {
            return 0;
        }
        $table        = self::table();
        $placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );

        $photos = $wpdb->get_col( $wpdb->prepare( "SELECT photo FROM {$table} WHERE id IN ({$placeholders})", ...$ids ) );
        foreach ( $photos as $photo ) {
            $path = self::photo_path( (string) $photo );
            if ( $path ) {
                wp_delete_file( $path );
                wp_delete_file( self::thumb_of( $path ) );
            }
        }

        return (int) $wpdb->query(
            $wpdb->prepare( "DELETE FROM {$table} WHERE id IN ({$placeholders})", ...$ids )
        );
    }

    public static function get_row( int $id ): ?object {
        global $wpdb;
        $table = self::table();
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ) ) ?: null;
    }

    /* -------------------------------------------------------------- */
    /*  Car photos                                                     */
    /* -------------------------------------------------------------- */

    private static function photo_base(): string {
        return trailingslashit( wp_upload_dir( null, false )['basedir'] ) . self::PHOTO_DIR;
    }

    /** Absolute path of a stored photo, or '' if missing / outside the photo folder. */
    public static function photo_path( string $relative ): string {
        if ( '' === $relative || str_contains( $relative, '..' ) ) {
            return '';
        }
        $path = self::photo_base() . '/' . ltrim( $relative, '/' );
        return is_file( $path ) ? $path : '';
    }

    /** Small JPEG next to the photo, for the admin list. */
    public static function thumb_of( string $path ): string {
        return (string) preg_replace( '/\.[a-z0-9]+$/i', '-thumb.jpg', $path );
    }

    /** Customer photos are personal data: no direct access, only via the admin. */
    private static function protect_photo_dir(): void {
        $base = self::photo_base();
        wp_mkdir_p( $base );
        if ( ! file_exists( $base . '/.htaccess' ) ) {
            file_put_contents( $base . '/.htaccess', "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n" );
        }
        if ( ! file_exists( $base . '/index.php' ) ) {
            file_put_contents( $base . '/index.php', "<?php // Silence is golden.\n" );
        }
    }

    /**
     * Validate and store the uploaded car photo.
     *
     * @return string|WP_Error Path relative to the photo folder.
     */
    private static function store_photo( $file ) {
        $invalid = new WP_Error( 'photo', __( 'Carica una foto dell’auto (JPG, PNG, WEBP o HEIC).', 'autonec-showroom-lock' ) );

        if ( ! is_array( $file ) || ( $file['error'] ?? UPLOAD_ERR_NO_FILE ) !== UPLOAD_ERR_OK || ! is_uploaded_file( $file['tmp_name'] ) ) {
            return $invalid;
        }
        if ( (int) $file['size'] > self::PHOTO_MAX ) {
            return new WP_Error( 'photo', __( 'La foto è troppo grande (massimo 20 MB).', 'autonec-showroom-lock' ) );
        }

        $mimes = [
            'jpg|jpeg|jpe' => 'image/jpeg',
            'png'          => 'image/png',
            'webp'         => 'image/webp',
            'heic'         => 'image/heic',
        ];
        $check = wp_check_filetype_and_ext( $file['tmp_name'], sanitize_file_name( (string) $file['name'] ), $mimes );
        if ( empty( $check['ext'] ) ) {
            return $invalid;
        }

        self::protect_photo_dir();
        $sub = gmdate( 'Y/m' );
        $dir = self::photo_base() . '/' . $sub;
        wp_mkdir_p( $dir );

        $name = strtolower( wp_generate_password( 24, false ) ) . '.' . $check['ext'];
        if ( ! move_uploaded_file( $file['tmp_name'], $dir . '/' . $name ) ) {
            return new WP_Error( 'photo', __( 'Non è stato possibile salvare la foto. Riprova.', 'autonec-showroom-lock' ) );
        }
        chmod( $dir . '/' . $name, 0644 );

        /* Safety net if the browser did not shrink it. */
        if ( 'heic' !== $check['ext'] ) {
            $editor = wp_get_image_editor( $dir . '/' . $name );
            if ( ! is_wp_error( $editor ) ) {
                $size = $editor->get_size();
                if ( max( $size['width'], $size['height'] ) > 2000 ) {
                    $editor->resize( 2000, 2000 );
                    $editor->save( $dir . '/' . $name );
                }
                $editor->resize( 240, 180, true );
                $editor->set_quality( 80 );
                $editor->save( self::thumb_of( $dir . '/' . $name ), 'image/jpeg' );
            }
        }

        return $sub . '/' . $name;
    }

    /** Admin-only URL that streams a stored photo. */
    public static function photo_admin_url( int $id, bool $thumb = false ): string {
        return add_query_arg( [
            'action'   => 'asl_promo_photo',
            'id'       => $id,
            'size'     => $thumb ? 'thumb' : false,
            '_wpnonce' => wp_create_nonce( 'asl_promo_photo_' . $id ),
        ], admin_url( 'admin-ajax.php' ) );
    }

    /* -------------------------------------------------------------- */
    /*  Page without header and footer                                 */
    /* -------------------------------------------------------------- */

    public function register_template( array $templates ): array {
        $templates[ self::TEMPLATE ] = __( 'Pagina vuota (senza header e footer)', 'autonec-showroom-lock' );
        return $templates;
    }

    public static function is_blank_page(): bool {
        return is_page() && self::TEMPLATE === get_page_template_slug( get_queried_object_id() );
    }

    public function load_template( string $template ): string {
        return self::is_blank_page() ? ASL_PLUGIN_DIR . 'templates/promo-blank.php' : $template;
    }

    /** The form carries a nonce: never serve it from page cache. */
    public function disable_cache(): void {
        if ( ! $this->page_has_form() ) {
            return;
        }
        if ( ! defined( 'DONOTCACHEPAGE' ) ) {
            define( 'DONOTCACHEPAGE', true );
        }
        do_action( 'litespeed_control_set_nocache', 'autonec promo form' );
        nocache_headers();
    }

    private function page_has_form(): bool {
        if ( ! is_singular() ) {
            return false;
        }
        $post = get_queried_object();
        return self::is_blank_page() || has_shortcode( $post->post_content ?? '', self::SHORTCODE );
    }

    /* -------------------------------------------------------------- */
    /*  Assets                                                         */
    /* -------------------------------------------------------------- */

    public function enqueue(): void {
        if ( ! $this->page_has_form() ) {
            return;
        }

        wp_enqueue_style( 'asl-promo', ASL_PLUGIN_URL . 'assets/css/promo.css', [], ASL_VERSION );
        wp_enqueue_script( 'asl-promo', ASL_PLUGIN_URL . 'assets/js/promo.js', [], ASL_VERSION, true );
        wp_localize_script( 'asl-promo', 'aslPromo', [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'asl_promo' ),
            'error'    => __( 'Invio non riuscito. Controlla la connessione e riprova.', 'autonec-showroom-lock' ),
        ] );
    }

    /* -------------------------------------------------------------- */
    /*  Shortcode                                                      */
    /* -------------------------------------------------------------- */

    public function render_shortcode(): string {
        $discount = self::discount();
        $logo     = self::logo_url();
        $suffix   = (string) self::get( 'logo_suffix' );
        $privacy  = self::privacy_url();
        $company  = get_bloginfo( 'name' );

        $fields = [
            'first_name' => [ __( 'Nome', 'autonec-showroom-lock' ), 'text', 'given-name' ],
            'last_name'  => [ __( 'Cognome', 'autonec-showroom-lock' ), 'text', 'family-name' ],
            'address'    => [ __( 'Indirizzo', 'autonec-showroom-lock' ), 'text', 'street-address' ],
            'email'      => [ __( 'E-mail', 'autonec-showroom-lock' ), 'email', 'email' ],
            'phone'      => [ __( 'Numero di telefono', 'autonec-showroom-lock' ), 'tel', 'tel' ],
            'car_number' => [ __( 'Numero dell’auto scelta', 'autonec-showroom-lock' ), 'text', 'off' ],
            'model'      => [ __( 'Modello', 'autonec-showroom-lock' ), 'text', 'off' ],
        ];

        $consent = sprintf(
            /* translators: %s: privacy policy link with the company name */
            __( 'Acconsento al trattamento dei dati personali inseriti nel presente modulo a scopi commerciali, in conformità all’informativa privacy di %s.', 'autonec-showroom-lock' ),
            $privacy
                ? '<a href="' . esc_url( $privacy ) . '" target="_blank" rel="noopener">' . esc_html( $company ) . '</a>'
                : esc_html( $company )
        );

        ob_start();
        ?>
        <div class="anp">
            <div class="anp__sheet">
                <div class="anp__main">
                <header class="anp__hero">
                    <?php if ( $logo || '' !== $suffix ) : ?>
                        <div class="anp__logo">
                            <?php if ( $logo ) : ?>
                                <img src="<?php echo esc_url( $logo ); ?>" alt="<?php echo esc_attr( $company ); ?>" decoding="async">
                            <?php endif; ?>
                            <?php if ( '' !== $suffix ) : ?>
                                <span class="anp__logo-suffix"><?php echo esc_html( $suffix ); ?></span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <h1 class="anp__title">
                        <span class="anp__title-top"><?php esc_html_e( 'La tua prossima auto', 'autonec-showroom-lock' ); ?></span>
                        <span class="anp__title-accent"><?php esc_html_e( 'ti aspetta!', 'autonec-showroom-lock' ); ?></span>
                    </h1>

                    <div class="anp__promo">
                        <span class="anp__promo-icon" aria-hidden="true">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M17 7 7 17"/><circle cx="8" cy="8" r="2.2"/><circle cx="16" cy="16" r="2.2"/></svg>
                        </span>
                        <p class="anp__promo-text">
                            <strong class="anp__promo-head"><?php esc_html_e( 'Promo online:', 'autonec-showroom-lock' ); ?></strong>
                            <span class="anp__promo-line"><?php esc_html_e( 'Assicurati ora il tuo sconto del', 'autonec-showroom-lock' ); ?></span>
                            <span class="anp__promo-sub"><?php esc_html_e( 'prenotando l’acquisto.', 'autonec-showroom-lock' ); ?></span>
                        </p>
                        <span class="anp__promo-value"><?php echo esc_html( $discount ); ?>%</span>
                    </div>
                </header>

                <section class="anp__card" aria-labelledby="anp-card-title">
                    <h2 class="anp__card-head" id="anp-card-title">
                        <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h7"/><path d="M14 2v5h5"/><path d="M8 11h7M8 15h4"/><path d="m19.5 12.5 2 2L15 21h-2v-2z"/></svg>
                        <?php esc_html_e( 'Compila il modulo', 'autonec-showroom-lock' ); ?>
                    </h2>

                    <form class="anp__form" id="anp-form" method="post">
                        <?php foreach ( $fields as $name => [ $label, $type, $autocomplete ] ) : ?>
                            <div class="anp__field">
                                <label class="anp__label" for="anp-<?php echo esc_attr( $name ); ?>"><?php echo esc_html( $label ); ?> <span class="anp__req" aria-hidden="true">*</span></label>
                                <input class="anp__input" type="<?php echo esc_attr( $type ); ?>" id="anp-<?php echo esc_attr( $name ); ?>"
                                       name="<?php echo esc_attr( $name ); ?>" autocomplete="<?php echo esc_attr( $autocomplete ); ?>"
                                       maxlength="<?php echo 'address' === $name ? 200 : 100; ?>" required>
                            </div>
                        <?php endforeach; ?>

                        <div class="anp__photo">
                            <span class="anp__label" id="anp-photo-label"><?php esc_html_e( 'Foto dell’auto', 'autonec-showroom-lock' ); ?> <span class="anp__req" aria-hidden="true">*</span></span>
                            <label class="anp__photo-drop">
                                <input class="anp__photo-input" type="file" id="anp-photo" name="photo" accept="image/*" required
                                       aria-labelledby="anp-photo-label" aria-describedby="anp-photo-hint">
                                <span class="anp__photo-empty">
                                    <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3z"/><circle cx="12" cy="13" r="3"/></svg>
                                    <span class="anp__photo-cta"><?php esc_html_e( 'Scatta o carica una foto', 'autonec-showroom-lock' ); ?></span>
                                    <span class="anp__photo-hint" id="anp-photo-hint"><?php esc_html_e( 'Dal telefono puoi fotografare l’auto direttamente.', 'autonec-showroom-lock' ); ?></span>
                                </span>
                                <span class="anp__photo-filled" hidden>
                                    <img class="anp__photo-preview" id="anp-photo-preview" alt="">
                                    <span class="anp__photo-change"><?php esc_html_e( 'Cambia foto', 'autonec-showroom-lock' ); ?></span>
                                </span>
                            </label>
                        </div>

                        <fieldset class="anp__choice">
                            <legend class="anp__choice-legend"><?php esc_html_e( 'Modalità di pagamento', 'autonec-showroom-lock' ); ?> <span class="anp__req" aria-hidden="true">*</span></legend>
                            <div class="anp__choice-options">
                                <?php foreach ( self::payment_labels() as $value => $label ) : ?>
                                    <label class="anp__option">
                                        <input type="radio" name="payment" value="<?php echo esc_attr( $value ); ?>" required>
                                        <span class="anp__box" aria-hidden="true"></span>
                                        <span><?php echo esc_html( $label ); ?></span>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        </fieldset>

                        <label class="anp__consent">
                            <input type="checkbox" name="consent" value="1" required>
                            <span class="anp__box" aria-hidden="true"></span>
                            <span class="anp__consent-text"><?php echo wp_kses( $consent, [ 'a' => [ 'href' => [], 'target' => [], 'rel' => [] ] ] ); ?></span>
                        </label>

                        <div class="anp__hp" aria-hidden="true">
                            <label for="anp-website">Website</label>
                            <input type="text" id="anp-website" name="website" tabindex="-1" autocomplete="off">
                        </div>

                        <p class="anp__error" id="anp-error" role="alert" hidden></p>

                        <button type="submit" class="anp__submit">
                            <span class="anp__submit-text">
                                <?php
                                /* translators: %d: discount percentage */
                                echo esc_html( sprintf( __( 'Prenota il mio sconto del %d%%', 'autonec-showroom-lock' ), $discount ) );
                                ?>
                            </span>
                            <span class="anp__submit-busy" hidden><?php esc_html_e( 'Invio in corso…', 'autonec-showroom-lock' ); ?></span>
                        </button>
                    </form>

                    <div class="anp__done" id="anp-done" tabindex="-1" hidden>
                        <svg class="anp__done-icon" aria-hidden="true" viewBox="0 0 52 52"><circle cx="26" cy="26" r="24" fill="none" stroke="currentColor" stroke-width="3"/><path fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" d="m15 27 7 7 15-15"/></svg>
                        <h2 class="anp__done-title"><?php esc_html_e( 'Prenotazione ricevuta!', 'autonec-showroom-lock' ); ?></h2>
                        <p class="anp__done-text">
                            <?php
                            /* translators: %d: discount percentage */
                            echo esc_html( sprintf( __( 'Il tuo sconto del %d%% è riservato. Ti contatteremo al più presto per confermare l’acquisto.', 'autonec-showroom-lock' ), $discount ) );
                            ?>
                        </p>
                        <p class="anp__done-mail"><?php esc_html_e( 'Ti abbiamo inviato un riepilogo a:', 'autonec-showroom-lock' ); ?> <strong id="anp-done-email"></strong></p>
                    </div>
                </section>
                </div>

                <ul class="anp__trust">
                    <li class="anp__trust-item">
                        <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/></svg>
                        <span><?php esc_html_e( 'Auto selezionate e controllate', 'autonec-showroom-lock' ); ?></span>
                    </li>
                    <li class="anp__trust-item">
                        <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>
                        <span><?php esc_html_e( 'Garanzia', 'autonec-showroom-lock' ); ?></span>
                    </li>
                    <li class="anp__trust-item">
                        <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m11 17 2 2a1 1 0 1 0 3-3"/><path d="m14 14 2.5 2.5a1 1 0 1 0 3-3l-3.88-3.88a3 3 0 0 0-4.24 0l-.88.88a1 1 0 1 1-3-3l2.81-2.81a5.79 5.79 0 0 1 7.06-.87l.47.28a2 2 0 0 0 1.42.25L21 4"/><path d="m21 3 1 11h-2"/><path d="M3 3 2 14l6.5 6.5a1 1 0 1 0 3-3"/><path d="M3 4h8"/></svg>
                        <span><?php esc_html_e( 'Soluzioni di finanziamento', 'autonec-showroom-lock' ); ?></span>
                    </li>
                    <li class="anp__trust-item">
                        <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m21 8-2 2-1.5-3.7A2 2 0 0 0 15.646 5H8.4a2 2 0 0 0-1.903 1.257L5 10 3 8"/><path d="M7 14h.01"/><path d="M17 14h.01"/><rect width="18" height="8" x="3" y="10" rx="2"/><path d="M5 18v2"/><path d="M19 18v2"/></svg>
                        <span><?php esc_html_e( 'Assistenza post-vendita', 'autonec-showroom-lock' ); ?></span>
                    </li>
                </ul>

                <p class="anp__note"><?php esc_html_e( 'In caso di leasing l’acquisto è da intendersi salvo concessione del credito. Promo da confermarsi mediante firma contrattuale.', 'autonec-showroom-lock' ); ?></p>
            </div>
        </div>
        <?php
        return (string) ob_get_clean();
    }

    /* -------------------------------------------------------------- */
    /*  AJAX handler                                                   */
    /* -------------------------------------------------------------- */

    public function handle_ajax(): void {
        if ( ! check_ajax_referer( 'asl_promo', 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => __( 'La pagina è scaduta: ricaricala e invia di nuovo il modulo.', 'autonec-showroom-lock' ) ] );
        }

        /* Honeypot: bots fill every field. Pretend success, store nothing. */
        if ( '' !== trim( (string) wp_unslash( $_POST['website'] ?? '' ) ) ) {
            wp_send_json_success( [ 'email' => '' ] );
        }

        $ip      = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ?? '' ) );
        $rl_key  = 'asl_promo_rl_' . md5( $ip );
        $attempt = (int) get_transient( $rl_key );
        if ( $attempt >= self::RATE_LIMIT ) {
            wp_send_json_error( [ 'message' => __( 'Hai inviato troppe richieste. Riprova tra qualche minuto.', 'autonec-showroom-lock' ) ] );
        }

        $data = [];
        foreach ( [ 'first_name', 'last_name', 'address', 'email', 'phone', 'car_number', 'model' ] as $f ) {
            $data[ $f ] = mb_substr( trim( sanitize_text_field( wp_unslash( $_POST[ $f ] ?? '' ) ) ), 0, 'address' === $f ? 200 : 100 );
            if ( '' === $data[ $f ] ) {
                wp_send_json_error( [ 'message' => __( 'Compila tutti i campi obbligatori.', 'autonec-showroom-lock' ) ] );
            }
        }

        $data['email'] = sanitize_email( $data['email'] );
        if ( ! is_email( $data['email'] ) ) {
            wp_send_json_error( [ 'message' => __( 'Indirizzo e-mail non valido.', 'autonec-showroom-lock' ) ] );
        }

        $data['payment'] = sanitize_key( wp_unslash( $_POST['payment'] ?? '' ) );
        if ( ! isset( self::payment_labels()[ $data['payment'] ] ) ) {
            wp_send_json_error( [ 'message' => __( 'Scegli la modalità di pagamento.', 'autonec-showroom-lock' ) ] );
        }

        if ( empty( $_POST['consent'] ) ) {
            wp_send_json_error( [ 'message' => __( 'Per inviare il modulo serve il consenso al trattamento dei dati.', 'autonec-showroom-lock' ) ] );
        }

        set_transient( $rl_key, $attempt + 1, self::RATE_WINDOW );

        $photo = self::store_photo( $_FILES['photo'] ?? null );
        if ( is_wp_error( $photo ) ) {
            wp_send_json_error( [ 'message' => $photo->get_error_message() ] );
        }
        $data['photo'] = $photo;

        $data['phone']      = ASL_Frontend::normalize_phone( $data['phone'] );
        $data['discount']   = self::discount();
        $data['locale']     = determine_locale();
        $data['ip_address'] = $ip;

        self::maybe_create_table();
        $data['id'] = self::insert( $data );

        $this->notify_admins( $data );
        $this->send_confirmation( $data );

        wp_send_json_success( [ 'email' => $data['email'] ] );
    }

    /* -------------------------------------------------------------- */
    /*  E-mails                                                        */
    /* -------------------------------------------------------------- */

    private function notify_admins( array $data ): void {
        $payment = self::payment_labels()[ $data['payment'] ];

        $subject = sprintf(
            /* translators: 1: site name, 2: customer full name */
            __( '[%1$s] Nuova prenotazione promo online — %2$s', 'autonec-showroom-lock' ),
            get_bloginfo( 'name' ),
            $data['first_name'] . ' ' . $data['last_name']
        );

        $rows = [
            __( 'Data/Ora', 'autonec-showroom-lock' )            => wp_date( 'd/m/Y H:i' ),
            __( 'Nome', 'autonec-showroom-lock' )                => $data['first_name'],
            __( 'Cognome', 'autonec-showroom-lock' )             => $data['last_name'],
            __( 'Indirizzo', 'autonec-showroom-lock' )           => $data['address'],
            __( 'E-mail', 'autonec-showroom-lock' )              => $data['email'],
            __( 'Telefono', 'autonec-showroom-lock' )            => $data['phone'],
            __( 'Numero auto', 'autonec-showroom-lock' )         => $data['car_number'],
            __( 'Modello', 'autonec-showroom-lock' )             => $data['model'],
            __( 'Pagamento', 'autonec-showroom-lock' )           => $payment,
            __( 'Sconto riservato', 'autonec-showroom-lock' )    => $data['discount'] . '%',
        ];

        $body = __( 'Un cliente ha prenotato l’acquisto con la promo online.', 'autonec-showroom-lock' ) . "\n\n";
        foreach ( $rows as $label => $value ) {
            $body .= $label . ': ' . $value . "\n";
        }
        $body .= "\n" . __( 'La foto dell’auto è allegata. Tutte le prenotazioni:', 'autonec-showroom-lock' ) . ' ' . admin_url( 'admin.php?page=asl-promo-requests' ) . "\n";
        $body .= "\n" . __( 'Il cliente ha dato il consenso al trattamento dei dati a scopi commerciali.', 'autonec-showroom-lock' ) . "\n";

        $headers = [
            'Content-Type: text/plain; charset=UTF-8',
            'Reply-To: ' . $data['email'],
        ];

        $photo       = self::photo_path( $data['photo'] );
        /* String key = file name shown in the e-mail (WordPress 6.2+). */
        $attachments = $photo ? [ sanitize_file_name( 'foto-auto-' . $data['car_number'] . '.' . pathinfo( $photo, PATHINFO_EXTENSION ) ) => $photo ] : [];

        foreach ( self::recipients() as $to ) {
            wp_mail( $to, $subject, $body, $headers, $attachments );
        }
    }

    /**
     * File from the media library attached to the customer e-mail (e.g. a payment slip).
     *
     * @return array{title: string, path: string}|null
     */
    public static function customer_attachment(): ?array {
        $id   = absint( self::get( 'customer_attachment_id' ) );
        $path = $id ? get_attached_file( $id ) : '';
        if ( ! $path || ! is_file( $path ) ) {
            return null;
        }
        return [ 'title' => get_the_title( $id ) ?: wp_basename( $path ), 'path' => $path ];
    }

    private function send_confirmation( array $data ): void {
        $file = self::customer_attachment();

        $placeholders = [
            '{nome}'        => $data['first_name'],
            '{cognome}'     => $data['last_name'],
            '{numero_auto}' => $data['car_number'],
            '{modello}'     => $data['model'],
            '{pagamento}'   => self::payment_labels()[ $data['payment'] ],
            '{sconto}'      => (string) $data['discount'],
            '{sito}'        => get_bloginfo( 'name' ),
            /* translators: %s: title of the attached file */
            '{allegato}'    => $file ? sprintf( __( 'In allegato trovi: %s.', 'autonec-showroom-lock' ), $file['title'] ) : '',
        ];

        $subject = trim( (string) self::get( 'email_subject' ) ) ?: self::defaults()['email_subject'];
        $body    = trim( (string) self::get( 'email_template' ) ) ?: self::default_email();

        /* An empty {allegato} must not leave a hole in the text. */
        $body = (string) preg_replace( "/\n{3,}/", "\n\n", strtr( $body, $placeholders ) );

        /* String key = file name shown in the e-mail (WordPress 6.2+). */
        $attachments = $file
            ? [ sanitize_file_name( $file['title'] . '.' . pathinfo( $file['path'], PATHINFO_EXTENSION ) ) => $file['path'] ]
            : [];

        wp_mail(
            $data['email'],
            strtr( $subject, $placeholders ),
            $body,
            [ 'Content-Type: text/plain; charset=UTF-8' ],
            $attachments
        );
    }

    public static function placeholders(): array {
        return [
            '{nome}'        => __( 'Nome del cliente', 'autonec-showroom-lock' ),
            '{cognome}'     => __( 'Cognome del cliente', 'autonec-showroom-lock' ),
            '{numero_auto}' => __( 'Numero dell’auto scelta', 'autonec-showroom-lock' ),
            '{modello}'     => __( 'Modello', 'autonec-showroom-lock' ),
            '{pagamento}'   => __( 'Leasing o Cash', 'autonec-showroom-lock' ),
            '{sconto}'      => __( 'Percentuale di sconto', 'autonec-showroom-lock' ),
            '{sito}'        => __( 'Nome del sito', 'autonec-showroom-lock' ),
            '{allegato}'    => __( 'Frase sull’allegato (vuota se non c’è)', 'autonec-showroom-lock' ),
        ];
    }
}
