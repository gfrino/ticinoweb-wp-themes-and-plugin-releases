<?php
/** Editable content for the Professional page. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Current public copy, used only until the editor saves its first revision. */
function oasi_professional_content_defaults(): array {
	return array(
		'kicker' => 'Area professionisti',
		'title' => 'Soluzioni dedicate ai professionisti',
		'lead' => 'Una selezione di spezie, erbe, pepi e sali per ristorazione, laboratori e attività che cercano materie prime scelte con cura.',
		'intro' => 'Siamo un laboratorio artigianale, non un negozio su strada: prepariamo gli ordini con attenzione e lavoriamo con un listino riservato agli account professionali approvati.',
		'fact_access' => 'Accesso verificato',
		'fact_catalog' => 'Listino nel normale Shop',
		'fact_preparation' => 'Preparazione artigianale',
		'image_id' => 33865,
		'image_caption' => 'Materie prime scelte per il lavoro quotidiano',
		'guest_access_label' => 'Accesso da attivare',
		'guest_access_title' => 'Richiedi il tuo account professionale',
		'guest_access_body' => 'Registrati attraverso il modulo già predisposto. Il laboratorio verificherà la richiesta prima di abilitare il listino riservato.',
		'guest_primary_cta' => 'Registrati come professionista',
		'guest_secondary_cta' => 'Accedi all’area riservata',
		'customer_access_label' => 'Accesso professionale',
		'customer_access_title' => 'Completa il formulario per richiedere l’accesso professionale',
		'customer_access_body' => 'Il tuo account è già attivo. Clicca sul pulsante rosso “Richiedi la verifica professionale” e completa il formulario con i dati della tua attività. Esamineremo la richiesta e ti contatteremo via email.',
		'customer_primary_cta' => 'Richiedi la verifica professionale',
		'customer_secondary_cta' => 'Vai al mio account',
		'professional_access_label' => 'Accesso professionale attivo',
		'professional_access_title' => 'Il tuo catalogo riservato è pronto',
		'professional_access_body' => 'Accedi allo Shop con questo account: prezzi e disponibilità professionali vengono applicati direttamente dal sistema wholesale esistente.',
		'professional_primary_cta' => 'Accedi al catalogo professionale',
		'conditions_kicker' => 'Informazioni prima dell’ordine',
		'conditions_title' => 'Condizioni per professionisti',
		'conditions_intro' => 'Le condizioni già pubblicate sono qui raccolte in un unico punto, senza cambiare il funzionamento commerciale del sito.',
		'conditions_cta_label' => 'Hai una richiesta specifica? Contattaci',
		'conditions_cta_url' => '',
		'trust_territory_label' => 'Territorio',
		'trust_territory_value' => 'Svizzera e Liechtenstein',
		'trust_payment_label' => 'Pagamento',
		'trust_payment_value' => 'Anticipato per ogni ordine',
		'trust_preparation_label' => 'Preparazione',
		'trust_preparation_value' => 'Artigianale, da ordinare in anticipo',
		'trust_assistance_label' => 'Assistenza',
		'conditions' => array(
			array( 'title' => 'Ordini', 'body' => 'Effettuiamo ordini professionali esclusivamente in Svizzera e Liechtenstein. L’accesso al listino riservato richiede registrazione e approvazione.' ),
			array( 'title' => 'Pagamenti', 'body' => 'Per ogni ordine professionale è richiesto il pagamento anticipato.' ),
			array( 'title' => 'Preparazione ed erbe', 'body' => 'Le erbe aromatiche vengono selezionate a mano; possono rimanere alcuni rami o rametti. La lavorazione richiede tempo, quindi consigliamo di ordinare con largo anticipo.' ),
			array( 'title' => 'Spedizione', 'body' => 'Per i clienti professionali le spese di spedizione sono variabili secondo il peso della merce.' ),
		),
	);
}

/** Sanitize every editable professional field. */
function oasi_professional_sanitize_content( $value ): array {
	$value    = is_array( $value ) ? $value : array();
	$defaults = oasi_professional_content_defaults();
	$result   = array();
	$textareas = array( 'lead', 'intro', 'guest_access_body', 'customer_access_body', 'professional_access_body', 'conditions_intro' );
	$urls      = array( 'conditions_cta_url' );

	foreach ( $defaults as $key => $default ) {
		if ( 'conditions' === $key ) {
			$conditions = is_array( $value['conditions'] ?? null ) ? $value['conditions'] : array();
			$result['conditions'] = array();
			foreach ( $default as $index => $condition_default ) {
				$row = is_array( $conditions[ $index ] ?? null ) ? $conditions[ $index ] : array();
				$result['conditions'][] = array(
					'title' => sanitize_text_field( $row['title'] ?? $condition_default['title'] ),
					'body'  => sanitize_textarea_field( $row['body'] ?? $condition_default['body'] ),
				);
			}
		} elseif ( 'image_id' === $key ) {
			$result[ $key ] = absint( $value[ $key ] ?? $default );
		} elseif ( in_array( $key, $urls, true ) ) {
			$result[ $key ] = esc_url_raw( $value[ $key ] ?? '' );
		} elseif ( in_array( $key, $textareas, true ) ) {
			$result[ $key ] = sanitize_textarea_field( $value[ $key ] ?? $default );
		} else {
			$result[ $key ] = sanitize_text_field( $value[ $key ] ?? $default );
		}
	}

	return $result;
}

/** Merged professional data for frontend and editor. */
function oasi_get_professional_content(): array {
	$saved = get_option( 'oasi_professional_content', array() );
	return oasi_professional_sanitize_content( is_array( $saved ) ? array_replace_recursive( oasi_professional_content_defaults(), $saved ) : array() );
}

function oasi_professional_cms_register_setting(): void {
	register_setting( 'oasi_professional_settings', 'oasi_professional_content', array( 'type' => 'array', 'default' => oasi_professional_content_defaults(), 'sanitize_callback' => 'oasi_professional_sanitize_content' ) );
}
add_action( 'admin_init', 'oasi_professional_cms_register_setting' );

function oasi_professional_cms_option_capability(): string {
	return 'edit_pages';
}
add_filter( 'option_page_capability_oasi_professional_settings', 'oasi_professional_cms_option_capability' );

function oasi_professional_cms_menu(): void {
	add_submenu_page( 'ticinoweb-cms', __( 'Professionisti', 'oasidellespezie-child-theme' ), __( 'Professionisti', 'oasidellespezie-child-theme' ), 'edit_pages', 'oasi-professional-settings', 'oasi_professional_cms_render_page' );
}
add_action( 'admin_menu', 'oasi_professional_cms_menu', 41 );

function oasi_professional_cms_assets( string $hook ): void {
	if ( 'ticinoweb-cms_page_oasi-professional-settings' !== $hook ) {
		return;
	}
	wp_enqueue_media();
	wp_enqueue_style( 'oasi-cms-editor', get_stylesheet_directory_uri() . '/assets/css/cms-editor.css', array(), wp_get_theme()->get( 'Version' ) );
	wp_enqueue_script( 'oasi-cms-editor', get_stylesheet_directory_uri() . '/assets/js/cms-editor.js', array(), wp_get_theme()->get( 'Version' ), true );
}
add_action( 'admin_enqueue_scripts', 'oasi_professional_cms_assets' );

/** Small field renderer for a deliberately simple backend. */
function oasi_professional_cms_field( array $data, string $key, string $label, bool $textarea = false ): void {
	?>
	<label class="oasi-cms-editor__field"><span><?php echo esc_html( $label ); ?></span>
		<?php if ( $textarea ) : ?><textarea class="large-text" rows="4" name="oasi_professional_content[<?php echo esc_attr( $key ); ?>]"><?php echo esc_textarea( (string) $data[ $key ] ); ?></textarea><?php else : ?><input type="text" class="large-text" name="oasi_professional_content[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( (string) $data[ $key ] ); ?>"><?php endif; ?>
	</label>
	<?php
}

function oasi_professional_cms_render_page(): void {
	if ( ! current_user_can( 'edit_pages' ) ) {
		wp_die( esc_html__( 'Non hai i permessi per modificare questa sezione.', 'oasidellespezie-child-theme' ) );
	}
	$data    = oasi_get_professional_content();
	$preview = $data['image_id'] ? wp_get_attachment_image_url( $data['image_id'], 'medium' ) : '';
	?>
	<div class="wrap oasi-cms-editor"><h1><?php esc_html_e( 'Pagina Professionisti', 'oasidellespezie-child-theme' ); ?></h1><p class="oasi-cms-editor__lead"><?php esc_html_e( 'Tutti i testi pubblici della pagina sono raccolti qui. Modifica solo ciò che è cambiato e salva: catalogo, account e prezzi WooCommerce restano separati e invariati.', 'oasidellespezie-child-theme' ); ?></p><?php settings_errors(); ?>
	<form method="post" action="options.php"><?php settings_fields( 'oasi_professional_settings' ); ?>
		<section class="oasi-cms-editor__section"><div class="oasi-cms-editor__section-heading"><div><span>01</span><h2><?php esc_html_e( 'Introduzione', 'oasidellespezie-child-theme' ); ?></h2></div><p><?php esc_html_e( 'Titolo, presentazione e immagine iniziale.', 'oasidellespezie-child-theme' ); ?></p></div>
			<div class="oasi-cms-editor__grid"><?php oasi_professional_cms_field( $data, 'kicker', 'Etichetta breve' ); ?><?php oasi_professional_cms_field( $data, 'title', 'Titolo principale' ); ?><?php oasi_professional_cms_field( $data, 'lead', 'Testo introduttivo', true ); ?><?php oasi_professional_cms_field( $data, 'intro', 'Descrizione', true ); ?></div>
			<div class="oasi-cms-editor__field" data-oasi-media-field><span><?php esc_html_e( 'Immagine', 'oasidellespezie-child-theme' ); ?></span><div class="oasi-cms-editor__media"><div class="oasi-cms-editor__preview" data-oasi-media-preview data-empty-label="Nessuna immagine"><?php if ( $preview ) : ?><img src="<?php echo esc_url( $preview ); ?>" alt=""><?php else : ?><span><?php esc_html_e( 'Nessuna immagine', 'oasidellespezie-child-theme' ); ?></span><?php endif; ?></div><div class="oasi-cms-editor__media-actions"><input type="hidden" name="oasi_professional_content[image_id]" value="<?php echo esc_attr( (string) $data['image_id'] ); ?>"><button type="button" class="button" data-oasi-media-pick data-media-type="image"><?php esc_html_e( 'Scegli immagine', 'oasidellespezie-child-theme' ); ?></button><button type="button" class="button-link-delete" data-oasi-media-clear><?php esc_html_e( 'Rimuovi', 'oasidellespezie-child-theme' ); ?></button></div></div></div>
			<?php oasi_professional_cms_field( $data, 'image_caption', 'Didascalia immagine' ); ?>
		</section>
		<section class="oasi-cms-editor__section"><div class="oasi-cms-editor__section-heading"><div><span>02</span><h2><?php esc_html_e( 'Condizioni', 'oasidellespezie-child-theme' ); ?></h2></div><p><?php esc_html_e( 'Queste informazioni appaiono sia nella pagina Professionisti sia dal link Condizioni del menu.', 'oasidellespezie-child-theme' ); ?></p></div><div class="oasi-cms-editor__grid"><?php oasi_professional_cms_field( $data, 'conditions_kicker', 'Etichetta' ); ?><?php oasi_professional_cms_field( $data, 'conditions_title', 'Titolo' ); ?><?php oasi_professional_cms_field( $data, 'conditions_intro', 'Introduzione', true ); ?><?php oasi_professional_cms_field( $data, 'conditions_cta_label', 'Testo CTA' ); ?><label class="oasi-cms-editor__field"><span><?php esc_html_e( 'URL CTA (facoltativo)', 'oasidellespezie-child-theme' ); ?></span><input type="url" class="large-text" name="oasi_professional_content[conditions_cta_url]" value="<?php echo esc_attr( (string) $data['conditions_cta_url'] ); ?>"></label></div><div class="oasi-cms-editor__conditions">
		<?php foreach ( $data['conditions'] as $index => $condition ) : ?><section class="oasi-cms-editor__condition"><h3><?php echo esc_html( sprintf( __( 'Condizione %d', 'oasidellespezie-child-theme' ), $index + 1 ) ); ?></h3><label class="oasi-cms-editor__field"><span><?php esc_html_e( 'Titolo', 'oasidellespezie-child-theme' ); ?></span><input type="text" class="large-text" name="oasi_professional_content[conditions][<?php echo esc_attr( (string) $index ); ?>][title]" value="<?php echo esc_attr( $condition['title'] ); ?>"></label><label class="oasi-cms-editor__field"><span><?php esc_html_e( 'Descrizione', 'oasidellespezie-child-theme' ); ?></span><textarea class="large-text" rows="4" name="oasi_professional_content[conditions][<?php echo esc_attr( (string) $index ); ?>][body]"><?php echo esc_textarea( $condition['body'] ); ?></textarea></label></section><?php endforeach; ?>
		</div></section>
		<section class="oasi-cms-editor__section"><div class="oasi-cms-editor__section-heading"><div><span>03</span><h2><?php esc_html_e( 'Accesso e informazioni finali', 'oasidellespezie-child-theme' ); ?></h2></div><p><?php esc_html_e( 'I collegamenti restano automatici; qui puoi cambiare le etichette mostrate ai diversi tipi di utente.', 'oasidellespezie-child-theme' ); ?></p></div>
			<div class="oasi-cms-editor__grid">
				<?php foreach ( array( 'fact_access' => 'Punto chiave 1', 'fact_catalog' => 'Punto chiave 2', 'fact_preparation' => 'Punto chiave 3', 'guest_access_label' => 'Stato — visitatore', 'guest_access_title' => 'Titolo — visitatore', 'guest_primary_cta' => 'CTA principale — visitatore', 'guest_secondary_cta' => 'CTA secondaria — visitatore', 'customer_access_label' => 'Stato — cliente', 'customer_access_title' => 'Titolo — cliente', 'customer_primary_cta' => 'CTA principale — cliente', 'customer_secondary_cta' => 'CTA secondaria — cliente', 'professional_access_label' => 'Stato — professionista', 'professional_access_title' => 'Titolo — professionista', 'professional_primary_cta' => 'CTA — professionista', 'trust_territory_label' => 'Etichetta territorio', 'trust_territory_value' => 'Valore territorio', 'trust_payment_label' => 'Etichetta pagamento', 'trust_payment_value' => 'Valore pagamento', 'trust_preparation_label' => 'Etichetta preparazione', 'trust_preparation_value' => 'Valore preparazione', 'trust_assistance_label' => 'Etichetta assistenza' ) as $key => $label ) : ?><?php oasi_professional_cms_field( $data, $key, $label ); ?><?php endforeach; ?>
				<?php oasi_professional_cms_field( $data, 'guest_access_body', 'Descrizione — visitatore', true ); ?><?php oasi_professional_cms_field( $data, 'customer_access_body', 'Descrizione — cliente', true ); ?><?php oasi_professional_cms_field( $data, 'professional_access_body', 'Descrizione — professionista', true ); ?>
			</div>
		</section><?php submit_button( __( 'Salva pagina Professionisti', 'oasidellespezie-child-theme' ) ); ?></form></div>
	<?php
}
