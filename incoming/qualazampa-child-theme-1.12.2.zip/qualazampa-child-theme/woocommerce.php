<?php defined('ABSPATH') || exit;get_header(); ?>
<main id="main-content" class="qz-shop qz-container qz-section<?php if(!is_product())echo ' qz-catalog'; ?>"><?php woocommerce_content(); ?></main><?php get_footer(); ?>
