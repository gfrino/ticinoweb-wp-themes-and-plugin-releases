<?php defined('ABSPATH') || exit; ?><!doctype html>
<html <?php language_attributes(); ?>><head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width,initial-scale=1"><?php wp_head(); ?></head>
<body <?php body_class(); ?>>
<!-- THESIS: A caring animal world that opens into a real shop. OWN-WORLD: orange logo, oat and lilac, rounded lettering and animal photography. STORY: meet them, choose their department, buy what they need. FIRST VIEWPORT: logo/search/basket above a split animal scene and clear shop action. FORM: affectionate photographic family album; brief-led, eb0399f8. FINISH: unreviewed and undocumented is unfinished; this build ends with the finish review, the verdict, and DESIGN.md -->
<?php wp_body_open(); ?>
<a class="qz-skip" href="#main-content"><?php esc_html_e('Vai al contenuto','qualazampa'); ?></a>
<header class="qz-header" data-header>
    <div class="qz-header__main qz-container">
        <a class="qz-logo" href="<?php echo esc_url(home_url('/')); ?>" aria-label="<?php echo esc_attr(get_bloginfo('name')); ?>">
            <?php $logo=ticinoweb_get_site_logo(); if($logo): ?><img src="<?php echo esc_url($logo); ?>" width="280" height="56" alt="<?php echo esc_attr(get_bloginfo('name')); ?>"><?php else: echo esc_html(get_bloginfo('name')); endif; ?>
        </a>
        <form class="qz-search" method="get" role="search" action="<?php echo esc_url(home_url('/')); ?>">
            <label class="screen-reader-text" for="qz-search"><?php esc_html_e('Cerca nel negozio','qualazampa'); ?></label>
            <input id="qz-search" type="search" name="s" value="<?php echo esc_attr(get_search_query()); ?>" placeholder="<?php esc_attr_e('Cosa serve al tuo piccolo amico?','qualazampa'); ?>"><input type="hidden" name="post_type" value="product">
            <button aria-label="<?php esc_attr_e('Cerca prodotti','qualazampa'); ?>"><?php echo qz_icon('search'); ?></button>
        </form>
        <div class="qz-header__tools"><a class="qz-account" href="<?php echo esc_url(wc_get_page_permalink('myaccount')); ?>" aria-label="<?php esc_attr_e('Il mio account','qualazampa'); ?>"><?php echo qz_icon('user'); ?><span><?php esc_html_e('Account','qualazampa'); ?></span></a><?php qz_cart_link(); ?><button class="qz-menu-toggle" aria-controls="qz-navigation" aria-expanded="false" aria-label="<?php esc_attr_e('Apri il menu','qualazampa'); ?>"><?php echo qz_icon('menu'); ?></button></div>
    </div>
    <div class="qz-header__nav qz-container" id="qz-navigation">
        <nav aria-label="<?php esc_attr_e('Menu principale','qualazampa'); ?>"><?php wp_nav_menu(['theme_location'=>'primary','container'=>false,'menu_class'=>'qz-menu','fallback_cb'=>false,'walker'=>new QZ_Navigation_Walker()]); ?></nav>
        <?php $address=qz_option('ticinoweb_contact_address_label');if($address): ?><span class="qz-local-note"><?php echo qz_icon('pin'); ?><?php echo esc_html($address); ?></span><?php endif; ?>
    </div>
</header>

<div class="qz-menu-scrim" data-menu-scrim aria-hidden="true"></div>
