<?php defined('ABSPATH') || exit;get_header(); ?>
<main id="main-content" class="qz-page qz-container qz-section"><?php while(have_posts()):the_post(); ?><h1><?php the_title(); ?></h1><div class="qz-prose"><?php the_content(); ?></div><?php endwhile; ?></main><?php get_footer(); ?>
