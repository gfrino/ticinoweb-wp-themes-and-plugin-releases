(() => {
  'use strict';
  const opening=document.querySelector('[data-opening]');
  if(!opening)return;
  const reduced=matchMedia('(prefers-reduced-motion:reduce)');
  const desktop=matchMedia('(min-width:1101px) and (min-height:800px)');
  const clamp=v=>Math.max(0,Math.min(1,v));
  const range=(a,b,v)=>clamp((v-a)/(b-a));
  const smooth=(a,b,v)=>{const n=range(a,b,v);return n*n*(3-2*n);};
  const round=v=>Number(v.toFixed(3));

  // A continuous shop window, timed only while visible and never while being read.
  const feature=document.querySelector('[data-feature]');
  if(feature){
    const track=feature.querySelector('[data-feature-track]');
    const slides=[...feature.querySelectorAll('[data-feature-slide]')];
    const controls=feature.querySelector('[data-feature-controls]');
    const previous=feature.querySelector('[data-feature-prev]'),next=feature.querySelector('[data-feature-next]');
    const counter=feature.querySelector('[data-feature-count]'),pause=feature.querySelector('[data-feature-pause]');
    let index=0,width=track.clientWidth,timer=0,settle=0,visible=false,hovered=false,focused=false,paused=false;
    const before=slides[slides.length-1].cloneNode(true),after=slides[0].cloneNode(true);
    [before,after].forEach(clone=>{clone.inert=true;clone.setAttribute('aria-hidden','true');clone.removeAttribute('data-feature-slide');clone.querySelectorAll('[id]').forEach(el=>el.removeAttribute('id'));});
    track.prepend(before);track.append(after);
    function stop(){clearTimeout(timer);timer=0;feature.removeAttribute('data-auto');}
    function arm(){
      stop();
      if(slides.length<2||paused||hovered||focused||!visible||document.hidden||reduced.matches)return;
      feature.setAttribute('data-auto','playing');timer=setTimeout(()=>go(index+1),5500);
    }
    function showState(){
      const current=track.clientWidth;
      if(current!==width){width=current;track.scrollTo({left:(index+1)*width,behavior:'instant'});}
      const physical=Math.round(track.scrollLeft/Math.max(1,width));
      index=((physical-1)%slides.length+slides.length)%slides.length;
      if(physical===0||physical===slides.length+1)track.scrollTo({left:(index+1)*width,behavior:'instant'});
      counter.textContent=`${index+1} / ${slides.length}`;
      slides.forEach((slide,i)=>{slide.inert=i!==index;});
      arm();
    }
    function go(target){stop();track.scrollTo({left:(target+1)*width,behavior:reduced.matches?'instant':'smooth'});}
    previous.addEventListener('click',()=>go(index-1));next.addEventListener('click',()=>go(index+1));
    pause.addEventListener('click',()=>{paused=!paused;pause.setAttribute('aria-pressed',String(paused));pause.setAttribute('aria-label',paused?pause.dataset.playLabel:pause.dataset.pauseLabel);arm();});
    feature.addEventListener('pointerenter',()=>{hovered=true;stop();});feature.addEventListener('pointerleave',()=>{hovered=false;arm();});
    feature.addEventListener('focusin',()=>{focused=true;stop();});feature.addEventListener('focusout',()=>{focused=false;requestAnimationFrame(()=>{focused=feature.contains(document.activeElement);arm();});});
    track.addEventListener('pointerdown',stop,{passive:true});
    track.addEventListener('scroll',()=>{stop();clearTimeout(settle);settle=setTimeout(showState,140);},{passive:true});
    track.addEventListener('keydown',event=>{if(event.target===track&&['ArrowLeft','ArrowRight'].includes(event.key)){event.preventDefault();go(index+(event.key==='ArrowLeft'?-1:1));}});
    if(typeof ResizeObserver==='function')new ResizeObserver(()=>{width=track.clientWidth;track.scrollTo({left:(index+1)*width,behavior:'instant'});}).observe(track);
    if(typeof IntersectionObserver==='function')new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;arm();},{threshold:.3}).observe(feature);
    document.addEventListener('visibilitychange',arm);reduced.addEventListener('change',arm);
    controls.hidden=false;feature.setAttribute('data-ready','');track.scrollTo({left:width,behavior:'instant'});showState();
  }

  const departments=document.querySelector('[data-worlds]');
  const worldsStage=document.querySelector('[data-worlds-stage]');
  const animalLandscape=departments?.querySelector('.qz-animals');
  const animals=[...document.querySelectorAll('[data-animal]')].map(link=>({link,image:link.querySelector('.qz-animal__image'),photo:link.querySelector('.qz-animal__image img'),label:link.querySelector('.qz-animal__label'),story:link.querySelector('.qz-animal__story')}));
  const controls=departments?.querySelector('[data-world-controls]');
  const previous=departments?.querySelector('[data-world-prev]');
  const next=departments?.querySelector('[data-world-next]');
  const counter=departments?.querySelector('[data-world-count]');
  const cuddle=document.querySelector('[data-cuddle]');
  const story=document.querySelector('[data-chapter="story"]');
  let lenis=null,frame=0,dirty=true,immersive=false,lastY=-1,geometry=null,animalIndex=0;
  const placed=el=>{const r=el.getBoundingClientRect();return {top:r.top+scrollY,height:r.height};};
  function measure(){
    const header=document.querySelector('[data-header]')?.offsetHeight||0;
    const marker=document.querySelector('[data-flow-marker="story"]');
    geometry={header,viewport:innerHeight,opening:placed(opening),departments:departments?placed(departments):null,
      worldWidth:animalLandscape?.offsetWidth||1,animalWidth:animals[0]?.link.offsetWidth||1,worldStageHeight:worldsStage?.offsetHeight||1,selection:placed(document.querySelector('[data-chapter="selection"]')),
      cuddle:cuddle?placed(cuddle):null,story:story?{top:marker?marker.getBoundingClientRect().top+scrollY:placed(story).top,height:story.offsetHeight}:null};
    const storyFits=story&&story.offsetHeight<=innerHeight-header;
    story?.toggleAttribute('data-stack-fit',!!storyFits);
    dirty=false;
  }
  function reset(){
    [opening,departments,cuddle,story,document.querySelector('[data-chapter="selection"]')].forEach(el=>el?.removeAttribute('style'));
    story?.removeAttribute('data-stack-fit');
    animals.forEach(a=>{[a.link,a.image,a.photo,a.label,a.story].forEach(el=>el?.removeAttribute('style'));a.link.inert=false;});
    if(controls)controls.hidden=!immersive;
  }
  function configure(){
    lenis?.destroy();lenis=null;
    immersive=desktop.matches&&!reduced.matches;
    document.documentElement.toggleAttribute('data-qz-motion',immersive);
    reset();dirty=true;lastY=-1;
    if(immersive&&typeof Lenis==='function')lenis=new Lenis({lerp:.085,smoothWheel:true,syncTouch:false,autoRaf:false,anchors:false});
    wake();
  }
  function goAnimal(i){
    if(!immersive||!geometry||!animals.length)return;
    const target=Math.max(0,Math.min(animals.length-1,i));
    const travel=Math.max(1,geometry.departments.height-geometry.worldStageHeight);
    const progress=(target/(animals.length-1))*.82;
    const y=geometry.departments.top-geometry.header+travel*progress;
    if(lenis)lenis.scrollTo(y);else window.scrollTo({top:y,behavior:reduced.matches?'instant':'smooth'});
    wake();
  }
  previous?.addEventListener('click',()=>goAnimal(animalIndex-1));
  next?.addEventListener('click',()=>goAnimal(animalIndex+1));
  function paint(y){
    const g=geometry;
    if(g.departments&&animals.length){
      const wp=clamp((y+g.header-g.departments.top)/Math.max(1,g.departments.height-g.worldStageHeight));
      const raw=range(0,.82,wp)*(animals.length-1);
      const base=Math.floor(raw),fraction=raw-base;
      // Photographs form one masked vertical reel. Copy leaves before its successor enters.
      const tour=base+smooth(.28,1,fraction),resolve=smooth(.85,.985,wp);
      const mainX=g.worldWidth*.24-g.animalWidth/2;
      const gap=(g.worldWidth-animals.length*g.animalWidth)/Math.max(1,animals.length-1);
      const portraitScale=Math.min(440,g.worldStageHeight*.52)/g.animalWidth;
      const textLeft=g.animalWidth+(portraitScale-1)*g.animalWidth/2+(g.worldWidth<1200?80:100);
      const previousIndex=animalIndex;
      animalIndex=Math.min(animals.length-1,Math.round(tour));
      if(previousIndex!==animalIndex&&resolve<.2)animals[animalIndex].story.animate?.([
        {clipPath:'inset(0 0 100% 0)',transform:`translateY(${animalIndex>previousIndex?22:-22}px)`},
        {clipPath:'inset(0)',transform:'translateY(0)'}
      ],{duration:450,easing:'cubic-bezier(.16,1,.3,1)'});
      if(previous){previous.disabled=animalIndex===0;next.disabled=animalIndex===animals.length-1;counter.textContent=`${animalIndex+1} / ${animals.length}`;}
      if(controls){controls.style.opacity=1-resolve;controls.inert=resolve>.5;}
      animals.forEach((animal,i)=>{
        const delta=i-tour,visible=Math.abs(delta)<1;
        const copy=i===animalIndex?1:0;
        const x=mainX*(1-resolve)+i*(g.animalWidth+gap)*resolve;
        animal.link.style.transform=`translate3d(${round(x)}px,${round(150*(1-resolve)+125*resolve)}px,0)`;
        animal.link.style.opacity=visible?1:resolve;animal.link.style.zIndex=String(i+1);animal.link.inert=resolve<.75&&i!==animalIndex;
        animal.image.style.transform=`scale(${round(portraitScale*(1-resolve)+resolve)})`;
        if(animal.photo)animal.photo.style.transform=`translate3d(0,${round(resolve>0?0:delta*100)}%,0)`;
        animal.label.style.opacity=resolve;
        animal.story.style.left=`${round(textLeft)}px`;
        animal.story.style.opacity=round(copy*(1-resolve));
        animal.story.style.transform='none';
        animal.story.style.visibility=copy*(1-resolve)<.02?'hidden':'visible';
      });
    }
    if(g.opening){const p=clamp(y/(g.opening.top+g.opening.height));opening.style.setProperty('--hero-y',`${round(p*42)}px`);opening.style.setProperty('--hero-scale',round(1.025+p*.035));}
    if(g.selection){const p=smooth(0,1,(y+g.viewport-g.selection.top)/(g.viewport*.65));document.querySelector('[data-chapter="selection"]').style.setProperty('--selection-y',`${round(65*(1-p))}px`);}
    if(g.cuddle){const c=clamp((y+g.viewport-g.cuddle.top)/(g.cuddle.height+g.viewport));cuddle.style.setProperty('--cuddle-inset',`${round(6*(1-smooth(.05,.5,c)))}%`);cuddle.style.setProperty('--cuddle-y',`${round(45*(.5-c))}px`);cuddle.style.setProperty('--cuddle-scale',round(1.035+.025*c));cuddle.style.setProperty('--cuddle-x',`${round(35*(1-smooth(.08,.45,c)))}px`);}
    if(g.story){const s=smooth(0,1,(y+g.viewport-g.story.top)/(g.story.height+g.viewport*.4));story.style.setProperty('--story-photo-y',`${round(25*(1-s))}px`);story.style.setProperty('--story-copy-y',`${round(-15*(1-s))}px`);}
  }
  function render(time){
    frame=0;if(document.hidden)return;
    lenis?.raf(time);
    if(immersive){if(dirty)measure();const y=window.scrollY;if(y!==lastY){paint(y);lastY=y;}}
    if(lenis?.isScrolling)wake();
  }
  function wake(){if(!frame&&!document.hidden)frame=requestAnimationFrame(render);}
  addEventListener('scroll',wake,{passive:true});addEventListener('wheel',wake,{passive:true});
  document.addEventListener('click',event=>{
    if(!lenis||event.defaultPrevented||event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;
    const link=event.target.closest('a[href]');if(!link||link.target==='_blank')return;
    const url=new URL(link.href,location.href);if(url.origin!==location.origin||url.pathname!==location.pathname||url.search!==location.search||!url.hash)return;
    let target;try{target=document.getElementById(decodeURIComponent(url.hash.slice(1)));}catch{return;}if(!target)return;
    event.preventDefault();const padding=parseFloat(getComputedStyle(document.documentElement).scrollPaddingTop)||0;
    history.pushState(history.state,'',url.hash);lenis.scrollTo(target.getBoundingClientRect().top+window.scrollY-padding);wake();
  });
  document.addEventListener('keydown',event=>{if(event.key==='Tab'){document.documentElement.setAttribute('data-qz-keyboard','');dirty=true;lastY=-1;wake();}});
  document.addEventListener('pointerdown',()=>{document.documentElement.removeAttribute('data-qz-keyboard');dirty=true;lastY=-1;wake();},{passive:true});
  addEventListener('resize',()=>{dirty=true;lastY=-1;wake();},{passive:true});
  reduced.addEventListener('change',configure);desktop.addEventListener('change',configure);
  document.addEventListener('visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(frame);frame=0;}else{dirty=true;lastY=-1;wake();}});
  if(typeof ResizeObserver==='function'){const observer=new ResizeObserver(()=>{dirty=true;lastY=-1;wake();});[opening,document.querySelector('[data-header]'),departments,cuddle,story].filter(Boolean).forEach(el=>observer.observe(el));}
  document.fonts?.ready.then(()=>{dirty=true;lastY=-1;wake();});
  configure();
})();
