<?php
defined('ABSPATH') || exit;
get_header();
$departments=qz_departments();$products=qz_product_list((array)get_post_meta(get_queried_object_id(),'_qz_selection_ids',true),8);
$faq_id=get_post_meta(get_queried_object_id(),defined('TICINOWEB_FAQ_META_PAGE')?TICINOWEB_FAQ_META_PAGE:'_tw_faq_page_set',true);
?>
<main id="main-content">
<section class="qz-opening" data-opening>
    <div class="qz-container qz-opening__stage" data-opening-stage>
        <div class="qz-hero__story">
            <div class="qz-hero__copy" data-hero-copy>
                <?php qz_title(qz_option('ticinoweb_slider_title_1'),'h1','qz-hero__title'); ?>
                <p class="qz-hero__text"><?php echo esc_html(qz_option('ticinoweb_slider_desc_1')); ?></p>
                <div class="qz-actions"><a class="qz-button" href="<?php echo esc_url(ticinoweb_get_shop_url()); ?>"><?php echo esc_html(qz_option('ticinoweb_slider_btn_text_1')); ?><?php echo qz_icon(); ?></a><a class="qz-text-link" href="#i-loro-mondi"><?php esc_html_e('Trova il suo mondo','qualazampa'); ?><?php echo qz_icon('paw'); ?></a></div>
            </div>
            <p class="qz-hero__note"><?php echo qz_icon('heart'); ?><?php echo esc_html(qz_home('hero_note')); ?></p>
        </div>
        <div class="qz-hero__visual"><div class="qz-hero__photo" data-hero-photo><?php qz_photo(get_option('ticinoweb_slider_image_1'),'full',['loading'=>'eager','fetchpriority'=>'high','sizes'=>'(max-width: 760px) 100vw, 58vw']); ?></div>
        <?php $featured=array_values(array_filter(array_slice($products,0,3),static fn($p)=>(bool)$p->get_image_id())); if($featured): ?>
        <div class="qz-feature" data-feature aria-label="<?php esc_attr_e('Idee dal negozio','qualazampa'); ?>">
            <div class="qz-feature__track" data-feature-track tabindex="0" aria-label="<?php esc_attr_e('Prodotti in evidenza','qualazampa'); ?>">
                <?php foreach($featured as $index=>$hero_product): ?>
                <article class="qz-feature__slide" data-feature-slide>
                    <a class="qz-feature__image" data-hero-product href="<?php echo esc_url($hero_product->get_permalink()); ?>" aria-label="<?php echo esc_attr($hero_product->get_name()); ?>"><?php echo wp_get_attachment_image($hero_product->get_image_id(),'full',false,['alt'=>'','loading'=>'eager','sizes'=>'(max-width: 760px) 80vw, 30vw']); ?></a>
                    <div class="qz-feature__information"><h2><a href="<?php echo esc_url($hero_product->get_permalink()); ?>"><?php echo esc_html(preg_replace('/\s*\[[^\]]*\]\s*$/','',$hero_product->get_name())); ?></a></h2><div class="qz-feature__purchase"><span class="qz-feature__price"><?php echo wp_kses_post($hero_product->get_price_html()); ?></span><a class="qz-text-link" href="<?php echo esc_url($hero_product->get_permalink()); ?>"><?php esc_html_e('Scopri il prodotto','qualazampa'); ?><?php echo qz_icon(); ?></a></div></div>
                </article>
                <?php endforeach; ?>
            </div>
            <div class="qz-feature__controls" data-feature-controls hidden><button type="button" data-feature-prev aria-label="<?php esc_attr_e('Prodotto precedente','qualazampa'); ?>"><?php echo qz_icon(); ?></button><span data-feature-count>1 / <?php echo esc_html(count($featured)); ?></span><button type="button" data-feature-next aria-label="<?php esc_attr_e('Prodotto successivo','qualazampa'); ?>"><?php echo qz_icon(); ?></button><button class="qz-feature__pause" type="button" data-feature-pause aria-pressed="false" aria-label="<?php esc_attr_e('Metti in pausa i prodotti','qualazampa'); ?>" data-pause-label="<?php esc_attr_e('Metti in pausa i prodotti','qualazampa'); ?>" data-play-label="<?php esc_attr_e('Riprendi i prodotti','qualazampa'); ?>"><?php echo qz_icon('pause').qz_icon('play'); ?></button><span class="qz-feature__meter" aria-hidden="true"></span></div>
        </div>
        <?php endif; ?></div>
    </div>
</section>
<section class="qz-departments qz-section" id="i-loro-mondi" data-chapter="departments" data-worlds>
    <span class="qz-worlds__overview-anchor" id="reparti-completi" aria-hidden="true"></span>
    <div class="qz-worlds__stage" data-worlds-stage><div class="qz-container">
    <div class="qz-section-heading"><?php qz_title(qz_home('categories_title')); ?><p><?php echo esc_html(qz_home('categories_text')); ?></p></div><a class="qz-worlds__skip qz-text-link" href="#reparti-completi"><?php esc_html_e('Vedi tutti i reparti','qualazampa'); ?><?php echo qz_icon(); ?></a>
    <div class="qz-worlds__controls" data-world-controls hidden><button type="button" data-world-prev aria-label="<?php esc_attr_e('Reparto precedente','qualazampa'); ?>"><?php echo qz_icon(); ?></button><span data-world-count>1 / <?php echo esc_html(is_wp_error($departments)?0:count($departments)); ?></span><button type="button" data-world-next aria-label="<?php esc_attr_e('Reparto successivo','qualazampa'); ?>"><?php echo qz_icon(); ?></button></div>
    <div class="qz-animals"><?php if(!is_wp_error($departments))foreach($departments as $term): ?>
        <a class="qz-animal" data-animal href="<?php echo esc_url(get_term_link($term)); ?>">
            <span class="qz-animal__image" aria-hidden="true"><?php $id=get_term_meta($term->term_id,'thumbnail_id',true);if($id)qz_photo($id,'large',['alt'=>'','loading'=>'eager','sizes'=>'(min-width: 1101px) 440px, (min-width: 761px) 20vw, 25vw']);else echo qz_icon(get_term_meta($term->term_id,'_qz_icon',true)?:'paw'); ?></span>
            <span class="qz-animal__label"><span class="qz-animal__name"><?php echo esc_html($term->name); ?><?php echo qz_icon(); ?></span><span class="qz-animal__count"><?php /* translators: %s: Number of products in this department. */ echo esc_html(sprintf(_n('%s prodotto','%s prodotti',$term->count,'qualazampa'),number_format_i18n($term->count))); ?></span></span>
            <span class="qz-animal__story"><strong><?php echo esc_html(ucfirst(strtolower($term->name))); ?></strong><span class="qz-animal__description"><?php echo esc_html(wp_trim_words(wp_strip_all_tags($term->description),26)); ?></span><span class="qz-text-link"><?php esc_html_e('Scopri il reparto','qualazampa'); ?><?php echo qz_icon(); ?></span></span>
        </a>
    <?php endforeach; ?></div>
    </div></div>
</section>
<span data-flow-marker="selection" aria-hidden="true"></span><section class="qz-selection qz-section" data-chapter="selection"><div class="qz-container"><div class="qz-section-heading qz-section-heading--split"><div><?php qz_title(qz_home('selection_title')); ?><p><?php echo esc_html(qz_home('selection_text')); ?></p></div><a class="qz-text-link" href="<?php echo esc_url(ticinoweb_get_shop_url()); ?>"><?php esc_html_e('Tutti i prodotti','qualazampa'); ?><?php echo qz_icon(); ?></a></div><?php qz_product_grid($products); ?></div></section>
<section class="qz-cuddle" data-cuddle><div class="qz-cuddle__stage"><div class="qz-cuddle__photo"><?php qz_photo(get_option('ticinoweb_slider_image_2'),'full',['sizes'=>'100vw']); ?></div><div class="qz-cuddle__copy"><?php echo qz_icon('heart'); qz_title(qz_home('scene_title')); ?><p><?php echo esc_html(qz_home('scene_text')); ?></p><a class="qz-button qz-button--light" href="<?php echo esc_url(qz_home('scene_link')); ?>"><?php esc_html_e('Scopri i prodotti per gatti','qualazampa'); ?><?php echo qz_icon(); ?></a></div></div></section>
<section class="qz-brands qz-section"><div class="qz-container"><div class="qz-section-heading qz-section-heading--split"><?php qz_title(qz_home('brands_title')); ?><a class="qz-text-link" href="<?php echo esc_url(qz_home('brands_url')); ?>"><?php esc_html_e('Esplora le marche','qualazampa'); ?><?php echo qz_icon(); ?></a></div><div class="qz-brand-line"><?php foreach(qz_home_brands(18) as $entry): ?><a aria-label="<?php echo esc_attr($entry['term']->name); ?>" href="<?php echo esc_url(add_query_arg('qz_brand',$entry['term']->term_id,ticinoweb_get_shop_url())); ?>"><?php if($entry['logo'])qz_photo($entry['logo'],'medium',['alt'=>'']);else echo '<span>'.esc_html($entry['term']->name).'</span>'; ?></a><?php endforeach; ?></div></div></section>
<span data-flow-marker="story" aria-hidden="true"></span><section class="qz-story qz-section" data-chapter="story"><div class="qz-container qz-story__layout"><div class="qz-story__photo"><?php qz_photo(get_option('ticinoweb_chi_siamo_image'),'large'); ?><span class="qz-story__heart" aria-hidden="true"><?php echo qz_icon('heart'); ?></span></div><div class="qz-story__copy"><?php qz_title(qz_option('ticinoweb_chi_siamo_title')); ?><p><?php echo nl2br(esc_html(qz_option('ticinoweb_chi_siamo_text'))); ?></p><a class="qz-text-link" href="<?php echo esc_url(get_option('ticinoweb_chi_siamo_link')); ?>"><?php esc_html_e('Facciamo conoscenza','qualazampa'); ?><?php echo qz_icon(); ?></a></div></div></section>
<?php $news=get_posts(['post_type'=>'post','post_status'=>'publish','numberposts'=>3]);if($news): ?><section class="qz-news qz-section" data-chapter="news"><div class="qz-container"><div class="qz-section-heading"><?php qz_title(qz_home('news_title')); ?></div><div class="qz-news__grid"><?php foreach($news as $item): ?><article><a class="qz-news__photo" href="<?php echo esc_url(get_permalink($item)); ?>"><?php echo get_the_post_thumbnail($item,'large',['loading'=>'lazy']); ?></a><p class="qz-news__date"><?php echo esc_html(get_the_date('', $item)); ?></p><h3><a href="<?php echo esc_url(get_permalink($item)); ?>"><?php echo esc_html(get_the_title($item)); ?></a></h3><a class="qz-text-link" href="<?php echo esc_url(get_permalink($item)); ?>"><?php esc_html_e('Scopri di più','qualazampa'); ?><?php echo qz_icon(); ?></a></article><?php endforeach; ?></div></div></section><?php endif; ?>
<section class="qz-store qz-section" data-chapter="store"><div class="qz-container qz-store__layout"><div><?php echo qz_icon('pin'); qz_title(qz_home('store_title')); ?><p><?php echo esc_html(qz_home('store_text')); ?></p><address><?php echo esc_html(qz_option('ticinoweb_contact_address')); ?></address><a class="qz-button" href="<?php echo esc_url(qz_home('contact_url')); ?>"><?php esc_html_e('Vieni a trovarci','qualazampa'); ?><?php echo qz_icon(); ?></a></div><div><h3><?php esc_html_e('Quando ci trovi','qualazampa'); ?></h3><?php qz_hours(); ?></div></div></section>
<?php if($faq_id): ?><section class="qz-faq qz-section"><div class="qz-container"><?php echo ticinoweb_faq_render($faq_id); ?></div></section><?php endif; ?>
</main><?php get_footer(); ?>
