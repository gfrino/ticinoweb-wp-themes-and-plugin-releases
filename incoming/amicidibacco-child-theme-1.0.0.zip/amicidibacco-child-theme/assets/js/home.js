(() => {
    'use strict';
    const reduced = matchMedia('(prefers-reduced-motion: reduce)');
    const fine = matchMedia('(min-width: 901px) and (pointer: fine)');
    const hero = document.querySelector('[data-hero]');
    const landscape = document.querySelector('[data-hero-landscape]');
    const bottle = document.querySelector('[data-hero-bottle]');
    const journey = document.querySelector('[data-journey]');
    const journeyPhoto = document.querySelector('[data-journey-photo] img');
    const journeyPhotos = [...document.querySelectorAll('[data-journey-photo]')];
    const journeyWords = [...document.querySelectorAll('.adb-journey__words span')];
    const journeyCopy = document.querySelector('.adb-journey__copy');
    let lenis = null;
    let raf = 0;
    let dirty = true;
    let bounds = {};
    const clamp = value => Math.max(0, Math.min(1, value));
    const ease = value => 1 - Math.pow(1 - value, 3);
    function paint() {
        if (reduced.matches) return;
        const y = window.scrollY;
        const heroProgress = clamp(y / Math.max(1, bounds.heroHeight));
        if (landscape && y < bounds.heroHeight + innerHeight) {
            landscape.style.transform = 'translate3d(0,' + (heroProgress * -38) + 'px,0) scale(' + (1 + heroProgress * .055) + ')';
            if (bottle) bottle.style.transform = 'translate3d(-50%,' + (heroProgress * 72) + 'px,0) rotate(' + (9 - heroProgress * 12) + 'deg)';
        }
        if (journey && y + innerHeight > bounds.journeyTop && y < bounds.journeyBottom) {
            const progress = clamp((y - bounds.journeyTop) / Math.max(1, bounds.journeyHeight - innerHeight));
            const aperture = ease(clamp((progress - .05) / .72));
            journey.style.setProperty('--journey-progress', String(progress));
            journey.style.setProperty('--journey-shift', (-aperture * 22) + 'vw');
            if (journeyPhoto) journeyPhoto.style.transform = 'scale(' + (1.15 - aperture * .11) + ') translate3d(0,' + (-aperture * 2) + '%,0)';
            journeyPhotos.forEach((photo, index) => {
                if (!index) return;
                const amount = ease(clamp(progress * 2.5 - (index - 1) - .2));
                photo.style.opacity = String(amount);
                photo.style.clipPath = 'inset(0 ' + ((1 - amount) * 100) + '% 0 0)';
                const image = photo.querySelector('img');
                if (image) image.style.transform = 'scale(' + (1.13 - .1 * amount) + ')';
            });
            journeyWords.forEach((word, index) => { word.style.opacity = String(.3 + .7 * (1 - Math.min(1, Math.abs(index - progress * 2)))); });
            if (journeyCopy && fine.matches) {
                journeyCopy.style.transform = 'translate3d(' + (aperture * 28) + 'px,calc(-50% - ' + (aperture * 15) + 'px),0)';
            }
        }
    }
    function frame(time) {
        raf = 0;
        if (document.hidden) return;
        if (lenis) lenis.raf(time);
        if (dirty || lenis?.isScrolling) { paint(); dirty = false; }
        if (lenis) requestFrame();
    }
    function requestFrame() { if (!raf && !document.hidden) raf = requestAnimationFrame(frame); }
    function measure() {
        const wantsSmooth = fine.matches && !reduced.matches && !navigator.connection?.saveData && typeof window.Lenis === 'function';
        if (wantsSmooth && !lenis) {
            lenis = new window.Lenis({autoRaf:false,lerp:.1,smoothWheel:true,syncTouch:false,anchors:false,prevent:node => !!node.closest?.('dialog,textarea,select,.woocommerce-product-details__short-description,[data-lenis-prevent]')});
            window.adbSmoothScroll = lenis;
        } else if (!wantsSmooth && lenis) { lenis.destroy(); lenis = null; window.adbSmoothScroll = null; }
        bounds = {heroHeight:hero?.offsetHeight || 700,journeyTop:journey ? journey.getBoundingClientRect().top + scrollY : 0,journeyHeight:journey?.offsetHeight || 1};
        bounds.journeyBottom = bounds.journeyTop + bounds.journeyHeight;
        if (reduced.matches) {
            landscape?.style.removeProperty('transform'); bottle?.style.removeProperty('transform');
            journeyPhoto?.style.removeProperty('transform'); journeyCopy?.style.removeProperty('transform');
            journeyPhotos.forEach((photo, index) => { photo.style.removeProperty('opacity'); photo.style.removeProperty('clip-path'); if (index) photo.querySelector('img')?.style.removeProperty('transform'); });
            journeyWords.forEach(word => word.style.removeProperty('opacity'));
            journey?.style.removeProperty('--journey-shift');
        }
        lenis?.resize(); dirty = true; requestFrame();
    }
    document.querySelectorAll('a[href^="#"]').forEach(link => link.addEventListener('click', event => {
        const hash = link.getAttribute('href');
        if (!hash || hash.length < 2) return;
        const target = document.getElementById(decodeURIComponent(hash.slice(1)));
        if (!target) return;
        event.preventDefault();
        const top = target.getBoundingClientRect().top + scrollY - 30;
        if (lenis && !reduced.matches) lenis.scrollTo(top, {duration:1.15,easing:ease});
        else scrollTo({top,behavior:reduced.matches ? 'instant' : 'smooth'});
        history.replaceState(null, '', hash);
        target.setAttribute('tabindex','-1'); target.focus({preventScroll:true});
    }));
    addEventListener('scroll', () => { dirty = true; requestFrame(); }, {passive:true});
    addEventListener('resize', measure, {passive:true});
    addEventListener('pageshow', measure);
    document.addEventListener('visibilitychange', () => { if (document.hidden) { if (raf) cancelAnimationFrame(raf); raf = 0; } else { dirty = true; requestFrame(); } });
    reduced.addEventListener('change', measure); fine.addEventListener('change', measure);
    document.fonts?.ready.then(measure);
    addEventListener('load', measure, {once:true});
    measure();
})();
