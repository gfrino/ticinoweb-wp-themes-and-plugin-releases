(() => {
    'use strict';
    const menuButton = document.querySelector('[data-menu-toggle]');
    const menu = document.querySelector('#adb-main-nav');
    const closeMenu = () => { menu?.classList.remove('is-open'); menuButton?.setAttribute('aria-expanded', 'false'); };
    menuButton?.addEventListener('click', () => {
        const open = menuButton.getAttribute('aria-expanded') !== 'true';
        menuButton.setAttribute('aria-expanded', String(open));
        menu?.classList.toggle('is-open', open);
    });
    menu?.addEventListener('click', event => { if (event.target.closest('a')) closeMenu(); });
    document.addEventListener('keydown', event => { if (event.key === 'Escape') { closeMenu(); } });
    document.addEventListener('click', event => { if (!event.target.closest('.adb-header')) closeMenu(); });
    const dialog = document.querySelector('[data-search-dialog]');
    const openSearch = document.querySelector('[data-search-open]');
    openSearch?.addEventListener('click', () => {
        closeMenu();
        if (dialog?.showModal) { dialog.showModal(); window.adbSmoothScroll?.stop(); }
    });
    dialog?.querySelector('[data-search-close]')?.addEventListener('click', () => dialog.close());
    dialog?.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
    dialog?.addEventListener('close', () => { window.adbSmoothScroll?.start(); openSearch?.focus(); });
})();
