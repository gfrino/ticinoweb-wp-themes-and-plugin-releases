(() => {
    'use strict';
    const form = document.querySelector('[data-contact-form]');
    if (!form || !window.adbContact) return;
    const status = form.querySelector('[data-contact-status]');
    const button = form.querySelector('[type="submit"]');
    const original = button.innerHTML;
    let recaptchaPromise;
    async function recaptcha() {
        const key = adbContact.recaptchaKey;
        if (!key) return '';
        if (!window.grecaptcha) {
            recaptchaPromise ||= new Promise((resolve, reject) => { const script = document.createElement('script'); script.src = 'https://www.google.com/recaptcha/api.js?render=' + encodeURIComponent(key); script.onload = resolve; script.onerror = reject; script.async = true; document.head.append(script); });
            await recaptchaPromise;
        }
        await new Promise(resolve => grecaptcha.ready(resolve));
        return grecaptcha.execute(key, {action:'submit'});
    }
    form.addEventListener('submit', async event => {
        event.preventDefault();
        if (!form.reportValidity()) return;
        form.querySelectorAll('[aria-invalid]').forEach(field => { field.removeAttribute('aria-invalid'); if (field.getAttribute('aria-describedby')?.startsWith('adb-error-')) field.removeAttribute('aria-describedby'); });
        form.querySelectorAll('.adb-field-error').forEach(error => error.remove());
        button.disabled = true; button.textContent = adbContact.loading; form.setAttribute('aria-busy','true'); status.textContent = '';
        try {
            const tokenResponse = await fetch(adbContact.ajaxUrl + '?action=ticinoweb_form_token', {cache:'no-store',credentials:'same-origin',signal:AbortSignal.timeout(15000)});
            const token = await tokenResponse.json();
            if (!token.success || !token.data?.token) throw new Error(adbContact.error);
            const data = new FormData(form); data.set('action','ticinoweb_submit_form'); data.set('token',token.data.token);
            const challenge = await recaptcha(); if (challenge) data.set('recaptcha_token',challenge);
            const response = await fetch(adbContact.ajaxUrl,{method:'POST',body:data,credentials:'same-origin',signal:AbortSignal.timeout(20000)});
            const result = await response.json();
            if (!response.ok || !result.success) {
                Object.entries(result.data?.fields || {}).forEach(([name,message]) => {
                    const field = form.elements.namedItem(name);
                    if (!(field instanceof HTMLElement)) return;
                    field.setAttribute('aria-invalid','true');
                    const error = document.createElement('span'); error.className = 'adb-field-error'; error.textContent = message; error.id = 'adb-error-' + name;
                    field.setAttribute('aria-describedby',error.id);
                    field.closest('label')?.append(error);
                });
                form.querySelector('[aria-invalid="true"]')?.focus();
                throw new Error(result.data?.message || adbContact.error);
            }
            status.textContent = result.data.message; form.reset();
        } catch (error) { status.textContent = error.message || adbContact.error; }
        finally { button.disabled = false; button.innerHTML = original; form.removeAttribute('aria-busy'); }
    });
})();
