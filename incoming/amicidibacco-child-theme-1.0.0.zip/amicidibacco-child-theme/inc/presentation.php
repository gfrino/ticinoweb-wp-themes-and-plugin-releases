<?php
defined('ABSPATH') || exit;

function adb_icon($name = 'arrow') {
    $paths = [
        'arrow' => '<path d="M4 12h15m-6-6 6 6-6 6"/>',
        'search' => '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
        'bag' => '<path d="M5 7h14l1 14H4L5 7Z"/><path d="M8 8V6a4 4 0 0 1 8 0v2"/>',
        'close' => '<path d="m5 5 14 14M19 5 5 19"/>',
        'menu' => '<path d="M3 8h18M3 16h18"/>',
        'down' => '<path d="M12 3v18m-6-6 6 6 6-6"/>',
        'account' => '<circle cx="12" cy="7" r="4"/><path d="M4 22v-3a8 8 0 0 1 16 0v3"/>',
    ];
    return '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" aria-hidden="true" focusable="false">' . ($paths[$name] ?? $paths['arrow']) . '</svg>';
}

function adb_cart_link() {
    $count = function_exists('ticinoweb_get_cart_count') ? ticinoweb_get_cart_count() : 0;
    $url = function_exists('wc_get_cart_url') ? wc_get_cart_url() : home_url('/');
    ?><a class="adb-cart" href="<?php echo esc_url($url); ?>" aria-label="<?php echo esc_attr(sprintf(__('Carrello, %d articoli', 'amicidibacco'), $count)); ?>"><?php echo adb_icon('bag'); ?><span class="adb-cart__count"><?php echo esc_html($count); ?></span></a><?php
}

function adb_heading($text, $tag = 'h2', $class = '') {
    $tag = in_array($tag, ['h1', 'h2', 'h3'], true) ? $tag : 'h2';
    $lines = explode('|', (string) $text);
    echo '<' . $tag . ' class="' . esc_attr($class) . '">';
    foreach ($lines as $i => $line) {
        if ($i) { echo '<br>'; }
        echo $i === count($lines) - 1 && count($lines) > 1 ? '<em>' . esc_html($line) . '</em>' : esc_html($line);
    }
    echo '</' . $tag . '>';
}

function adb_photo($id, $size = 'large', $attrs = []) {
    if (!$id) { return; }
    // Cover crops need enough pixels for their height, including panoramic originals.
    $attrs = array_merge(['sizes' => '(max-width:600px) 850px, (max-width:1000px) 700px, 900px', 'data-adb-cover' => '1'], $attrs);
    echo wp_get_attachment_image(absint($id), $size, false, $attrs);
}

add_filter('wp_get_attachment_image_attributes', function ($attrs) {
    if (isset($attrs['data-adb-cover'])) {
        $attrs['sizes'] = preg_replace('/^auto,\s*/', '', $attrs['sizes'] ?? '100vw');
        unset($attrs['data-adb-cover']);
    }
    return $attrs;
}, 100);

// Imported excerpts can contain the entire technical sheet. Keep buying controls near the introduction.
add_filter('woocommerce_short_description', function ($description) {
    global $product;
    if (!is_product() || !$product instanceof WC_Product) { return $description; }
    $intro = get_post_meta($product->get_id(), 'descrizione_etichetta', true);
    if (!is_string($intro) || !trim($intro)) { return $description; }
    $label = get_post_meta($product->get_id(), 'etichetta', true);
    return ($label ? '<p class="adb-product-denomination">' . esc_html($label) . '</p>' : '') . wpautop(wp_kses_post($intro));
}, 20);

// Keep every imported detail visible even when the original excerpt was the only full description.
add_filter('woocommerce_product_tabs', function ($tabs) {
    global $product;
    if (!$product instanceof WC_Product || !trim((string) get_post_meta($product->get_id(), 'descrizione_etichetta', true))) { return $tabs; }
    $original = $product->get_short_description();
    $long = $product->get_description();
    $plain = static function ($text) { return trim(preg_replace('/\s+/u', ' ', html_entity_decode(wp_strip_all_tags($text), ENT_QUOTES, 'UTF-8'))); };
    $excerpt_text = $plain($original);
    if (!$excerpt_text || strpos($plain($long), $excerpt_text) !== false) { return $tabs; }
    $tabs['description'] = ['title' => __('Descrizione', 'woocommerce'), 'priority' => 10, 'callback' => static function () use ($long, $original) {
        echo '<h2>' . esc_html__('Descrizione', 'woocommerce') . '</h2>';
        echo wpautop(wp_kses_post($long));
        echo wpautop(wp_kses_post($original));
    }];
    return $tabs;
}, 25);

function adb_product_card($product, $class = '') {
    if (!$product instanceof WC_Product || !$product->is_visible()) { return; }
    $id = $product->get_id();
    $region = wc_get_product_terms($id, 'pa_regione', ['fields' => 'names']);
    $label = $product->get_name();
    ?>
    <article class="adb-product <?php echo esc_attr($class); ?>">
        <a class="adb-product__photo" href="<?php echo esc_url($product->get_permalink()); ?>" aria-label="<?php echo esc_attr($product->get_name()); ?>">
            <?php if ($product->is_on_sale()) : ?><span class="adb-product__badge"><?php esc_html_e('In offerta', 'amicidibacco'); ?></span><?php endif; ?>
            <?php echo $product->get_image('medium_large', ['loading' => 'lazy', 'decoding' => 'async']); ?>
            <span class="adb-product__discover"><?php esc_html_e('Scopri il vino', 'amicidibacco'); ?> <?php echo adb_icon(); ?></span>
        </a>
        <div class="adb-product__info">
            <?php if ($region) : ?><span class="adb-product__origin"><?php echo esc_html(implode(' · ', $region)); ?></span><?php endif; ?>
            <h3><a href="<?php echo esc_url($product->get_permalink()); ?>"><?php echo esc_html($label ?: $product->get_name()); ?></a></h3>
            <p><?php echo esc_html(get_post_meta($id, 'etichetta', true)); ?></p>
            <div class="adb-product__buy"><span class="adb-product__price"><?php echo wp_kses_post($product->get_price_html()); ?></span><a href="<?php echo esc_url($product->get_permalink()); ?>" class="adb-product__action" aria-label="<?php echo esc_attr(sprintf(__('Scegli %s', 'amicidibacco'), $product->get_name())); ?>"><?php echo adb_icon(); ?></a></div>
        </div>
    </article>
    <?php
}

function adb_page_link($key, $fallback = '') {
    $mapping = ['wineries_page_id' => 'archive_produttore', 'story_page_id' => 'page_chi_siamo', 'contact_page_id' => 'page_contatti'];
    if (isset($mapping[$key]) && function_exists('ticinoweb_get_mapped_page_url')) {
        $mapped = ticinoweb_get_mapped_page_url($mapping[$key]);
        if ($mapped) { return $mapped; }
    }
    $id = absint(get_post_meta((int) get_option('page_on_front'), '_adb_' . $key, true));
    return $id ? get_permalink($id) : ($fallback ? home_url($fallback) : home_url('/'));
}

/** Reuse the parent Media Gallery taxonomy and its saved order. */
function adb_journey_images() {
    $term = absint(adb_home('journey_gallery_id'));
    if (!$term) { return array_filter([absint(adb_home('journey_image_id'))]); }
    // Only IDs are fetched: apply the editor's full gallery order before limiting.
    $ids = get_objects_in_term($term, 'ticinoweb_media_gallery');
    if (is_wp_error($ids)) { return []; }
    $ids = array_map('absint', $ids);
    $order = array_map('absint', (array) get_term_meta($term, '_ticinoweb_gallery_order', true));
    return array_slice(array_values(array_unique(array_merge(array_intersect($order, $ids), $ids))), 0, 3);
}

function adb_winery_card($winery) {
    $image = absint(get_post_meta($winery->ID, 'immagine_di_sfondo_sulla_pagina_del_produttore', true)) ?: get_post_thumbnail_id($winery->ID);
    ?><a class="adb-winery" href="<?php echo esc_url(get_permalink($winery)); ?>"><div><?php adb_photo($image, 'large', ['loading' => 'lazy']); ?></div><h2><?php echo esc_html($winery->post_title); ?> <?php echo adb_icon(); ?></h2></a><?php
}

add_shortcode('adb_wineries', function () {
    ob_start(); ?><div class="adb-directory"><?php foreach (adb_wineries([], 80) as $winery) { adb_winery_card($winery); } ?></div><?php return ob_get_clean();
});

add_shortcode('adb_collection', function ($atts) {
    $atts = shortcode_atts(['kind' => 'selections'], $atts, 'adb_collection');
    $args = ['post_type' => 'product', 'post_status' => 'publish', 'posts_per_page' => 24, 'adb_language' => 'it', 'paged' => max(1, get_query_var('paged'), get_query_var('page'))];
    if ($atts['kind'] === 'offers') { $args['post__in'] = array_merge([0], wc_get_product_ids_on_sale()); }
    else { $args['tax_query'] = [['taxonomy' => 'product_cat', 'field' => 'slug', 'terms' => ['le-selezioni', 'le-selezioni-grappa']]]; }
    $query = new WP_Query($args);
    ob_start(); ?><div class="adb-product-grid"><?php foreach ($query->posts as $post) { adb_product_card(wc_get_product($post->ID)); } ?></div><?php
    echo wp_kses_post(paginate_links(['total' => $query->max_num_pages, 'current' => $args['paged']]));
    return ob_get_clean();
});
