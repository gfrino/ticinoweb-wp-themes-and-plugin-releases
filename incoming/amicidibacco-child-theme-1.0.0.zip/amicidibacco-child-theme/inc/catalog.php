<?php
/** Catalog presentation. Original records and WooCommerce purchasing remain untouched. */
defined( 'ABSPATH' ) || exit;

/** Null means WPML owns language selection, or no legacy language map exists. */
function adb_language_table() {
    global $wpdb;
    if ( defined( 'ICL_SITEPRESS_VERSION' ) || class_exists( 'SitePress' ) ) { return null; }
    static $tables = array();
    $table = $wpdb->prefix . 'icl_translations';
    if ( ! array_key_exists( $table, $tables ) ) {
        $tables[ $table ] = $table === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) ) ? $table : null;
    }
    return $tables[ $table ];
}

/** Include new untranslated records, but never include a known foreign translation. */
function adb_language_predicate( $element_id, $element_type ) {
    global $wpdb;
    $table = adb_language_table();
    if ( ! $table ) { return ''; }
    // Both SQL expressions are supplied internally, never from a request.
    return $wpdb->prepare(
        " AND (NOT EXISTS (SELECT 1 FROM `$table` adb_language_any WHERE adb_language_any.element_id=$element_id AND adb_language_any.element_type=$element_type) OR EXISTS (SELECT 1 FROM `$table` adb_language_it WHERE adb_language_it.element_id=$element_id AND adb_language_it.element_type=$element_type AND adb_language_it.language_code=%s))",
        'it'
    );
}

function adb_language_where( $where, $query ) {
    global $wpdb;
    if ( is_admin() || 'it' !== $query->get( 'adb_language' ) ) { return $where; }
    $types = (array) $query->get( 'post_type' );
    if ( ! $types || array_diff( $types, array( 'product', 'produttore' ) ) ) { return $where; }
    return $where . adb_language_predicate( "{$wpdb->posts}.ID", "CONCAT('post_', {$wpdb->posts}.post_type)" );
}
add_filter( 'posts_where', 'adb_language_where', 20, 2 );

function adb_language_terms( $clauses, $taxonomies, $args ) {
    if ( is_admin() || 'it' !== ( $args['adb_language'] ?? '' ) ) { return $clauses; }
    if ( array_diff( $taxonomies, get_object_taxonomies( 'product' ) ) ) { return $clauses; }
    $clauses['where'] .= adb_language_predicate( 'tt.term_taxonomy_id', "CONCAT('tax_', tt.taxonomy)" );
    return $clauses;
}
add_filter( 'terms_clauses', 'adb_language_terms', 20, 3 );

function adb_catalog_filter_definitions() {
    return array(
        array( 'taxonomy' => 'product_cat', 'param' => 'adb_category', 'label' => __( 'Tipologia', 'amicidibacco' ) ),
        array( 'taxonomy' => 'pa_cantina', 'param' => 'adb_winery', 'label' => __( 'Cantina', 'amicidibacco' ) ),
        array( 'taxonomy' => 'pa_nazione', 'param' => 'adb_country', 'label' => __( 'Nazione', 'amicidibacco' ) ),
        array( 'taxonomy' => 'pa_regione', 'param' => 'adb_region', 'label' => __( 'Regione', 'amicidibacco' ) ),
        array( 'taxonomy' => 'pa_anno', 'param' => 'adb_year', 'label' => __( 'Annata', 'amicidibacco' ) ),
    );
}

/** Return only bounded, scalar, whitelisted taxonomy selections. */
function adb_catalog_tax_query( $input = null ) {
    $input = null === $input ? wp_unslash( $_GET ) : $input; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- public read-only filters.
    $tax_query = array();
    foreach ( adb_catalog_filter_definitions() as $filter ) {
        $raw = $input[ $filter['param'] ] ?? '';
        if ( ! is_scalar( $raw ) || '' === (string) $raw || ! taxonomy_exists( $filter['taxonomy'] ) ) { continue; }
        $slug = sanitize_title( substr( (string) $raw, 0, 200 ) );
        if ( '' !== $slug ) { $tax_query[] = array( 'taxonomy' => $filter['taxonomy'], 'field' => 'slug', 'terms' => array( $slug ) ); }
    }
    return $tax_query;
}

function adb_catalog_filters() {
    $filters = adb_catalog_filter_definitions();
    foreach ( $filters as &$filter ) {
        $terms = taxonomy_exists( $filter['taxonomy'] ) ? get_terms( array( 'taxonomy' => $filter['taxonomy'], 'hide_empty' => true, 'adb_language' => 'it', 'orderby' => 'name' ) ) : array();
        $filter['terms'] = is_wp_error( $terms ) ? array() : $terms;
    }
    unset( $filter );
    return $filters;
}

/** Mark only public catalog queries. Direct WC IDs, sessions, admin and variations are unaltered. */
function adb_catalog_query( $query ) {
    if ( is_admin() || ! $query->is_main_query() || ( function_exists( 'is_cart' ) && ( is_cart() || is_checkout() ) ) ) { return; }
    $types = (array) $query->get( 'post_type' );
    $taxonomies = get_object_taxonomies( 'product' );
    $catalog = $query->is_post_type_archive( 'product' ) || $query->is_tax( $taxonomies ) || ( $query->is_search() && in_array( 'product', $types, true ) );
    $winery = $query->is_post_type_archive( 'produttore' ) || $query->is_singular( 'produttore' );
    if ( $catalog ) {
        $query->set( 'post_type', 'product' );
        $existing = (array) $query->get( 'tax_query' );
        $selected = adb_catalog_tax_query();
        if ( $selected ) { $query->set( 'tax_query', $existing ? array_merge( array( 'relation' => 'AND', $existing ), $selected ) : $selected ); }
    }
    if ( $catalog || $winery || $query->is_singular( 'product' ) ) {
        if ( $query->is_singular( 'produttore' ) ) { $query->set( 'post_type', 'produttore' ); }
        if ( $query->is_singular( 'product' ) ) { $query->set( 'post_type', 'product' ); }
        $query->set( 'adb_language', 'it' );
    }
}
add_action( 'pre_get_posts', 'adb_catalog_query', 20 );

/** Bounded editorial queries prime post, meta and term caches before WC object hydration. */
function adb_products( $args = array() ) {
    if ( ! function_exists( 'wc_get_product' ) ) { return array(); }
    $query = array( 'post_type' => 'product', 'post_status' => 'publish', 'posts_per_page' => min( 100, max( 1, (int) ( $args['limit'] ?? 4 ) ) ), 'no_found_rows' => true, 'ignore_sticky_posts' => true, 'suppress_filters' => false, 'adb_language' => 'it', 'orderby' => 'date', 'order' => 'DESC' );
    if ( array_key_exists( 'ids', $args ) ) {
        $ids = wp_parse_id_list( $args['ids'] );
        if ( ! $ids ) { return array(); }
        $query['post__in'] = $ids;
        $query['orderby'] = 'post__in';
        if ( ! isset( $args['limit'] ) ) { $query['posts_per_page'] = min( 100, count( $ids ) ); }
    } elseif ( isset( $args['orderby'] ) && in_array( $args['orderby'], array( 'date', 'title', 'menu_order', 'modified' ), true ) ) {
        $query['orderby'] = $args['orderby'];
    }
    if ( isset( $args['order'] ) && 'ASC' === strtoupper( $args['order'] ) ) { $query['order'] = 'ASC'; }
    $tax = isset( $args['filters'] ) && is_array( $args['filters'] ) ? adb_catalog_tax_query( $args['filters'] ) : array();
    if ( ! empty( $args['category'] ) && is_scalar( $args['category'] ) ) { $tax[] = array( 'taxonomy' => 'product_cat', 'field' => 'slug', 'terms' => array( sanitize_title( $args['category'] ) ) ); }
    if ( $tax ) { $query['tax_query'] = $tax; }
    // Respect WooCommerce's catalog visibility without changing stock, price or variation rules.
    if ( function_exists( 'wc_get_product_visibility_term_ids' ) ) {
        $visibility = wc_get_product_visibility_term_ids();
        if ( ! empty( $visibility['exclude-from-catalog'] ) ) { $query['tax_query'][] = array( 'taxonomy' => 'product_visibility', 'field' => 'term_taxonomy_id', 'terms' => array( $visibility['exclude-from-catalog'] ), 'operator' => 'NOT IN' ); }
    }
    $posts = get_posts( $query );
    if ( function_exists( 'wp_prime_option_caches' ) && ! wp_using_ext_object_cache() ) {
        $options = array();
        foreach ( $posts as $post ) {
            foreach ( array( 'wc_var_prices_', 'wc_product_children_', 'wc_child_has_weight_', 'wc_child_has_dimensions_', 'wc_related_' ) as $transient ) {
                $options[] = '_transient_' . $transient . $post->ID;
                $options[] = '_transient_timeout_' . $transient . $post->ID;
            }
        }
        if ( $options ) { wp_prime_option_caches( $options ); }
    }
    $images = array_filter( array_map( 'get_post_thumbnail_id', $posts ) );
    if ( $images ) { _prime_post_caches( $images, false, true ); }
    return array_values( array_filter( array_map( static function ( $post ) { return wc_get_product( $post->ID ); }, $posts ) ) );
}

function adb_wineries( $ids = array(), $limit = 3 ) {
    $query = array( 'post_type' => 'produttore', 'post_status' => 'publish', 'posts_per_page' => min( 100, max( 1, (int) $limit ) ), 'no_found_rows' => true, 'orderby' => 'title', 'order' => 'ASC', 'suppress_filters' => false, 'adb_language' => 'it' );
    if ( $ids ) { $query['post__in'] = wp_parse_id_list( $ids ); $query['orderby'] = 'post__in'; }
    $posts = get_posts( $query );
    $images = array();
    foreach ( $posts as $post ) {
        $images[] = absint( get_post_meta( $post->ID, 'immagine_di_sfondo_sulla_pagina_del_produttore', true ) );
        $images[] = get_post_thumbnail_id( $post->ID );
    }
    $images = array_values( array_unique( array_filter( $images ) ) );
    if ( $images ) { _prime_post_caches( $images, false, true ); }
    return $posts;
}

function adb_catalog_url( $args = array() ) {
    $url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : get_post_type_archive_link( 'product' );
    return add_query_arg( $args, $url ?: home_url( '/' ) );
}

function adb_term_url( $taxonomy, $slug ) {
    $term = get_term_by( 'slug', sanitize_title( $slug ), sanitize_key( $taxonomy ) );
    if ( $term ) { $url = get_term_link( $term ); if ( ! is_wp_error( $url ) ) { return $url; } }
    foreach ( adb_catalog_filter_definitions() as $filter ) {
        if ( $filter['taxonomy'] === $taxonomy ) { return adb_catalog_url( array( $filter['param'] => sanitize_title( $slug ) ) ); }
    }
    return adb_catalog_url();
}

/** Keep only Italian related products; one batch lookup, no record changes. */
function adb_related_products( $ids ) {
    global $wpdb;
    if ( is_admin() || ! $ids || ! adb_language_table() || ( function_exists( 'is_cart' ) && ( is_cart() || is_checkout() ) ) ) { return $ids; }
    $ids = wp_parse_id_list( $ids );
    if ( ! $ids ) { return array(); }
    $where = adb_language_predicate( 'p.ID', "'post_product'" );
    $allowed = $wpdb->get_col( "SELECT p.ID FROM {$wpdb->posts} p WHERE p.ID IN (" . implode( ',', $ids ) . ") $where" ); // IDs have been normalized to positive integers.
    return array_values( array_intersect( $ids, array_map( 'intval', $allowed ) ) );
}
add_filter( 'woocommerce_related_products', 'adb_related_products', 20 );

function adb_product_fields() {
    return array(
        'etichetta' => __( 'Denominazione breve', 'amicidibacco' ), 'descrizione_etichetta' => __( 'Descrizione introduttiva', 'amicidibacco' ), 'tipo_di_prodotto' => __( 'Tipo di scheda', 'amicidibacco' ),
        'vitigno' => __( 'Vitigno', 'amicidibacco' ), 'vinificazione' => __( 'Vinificazione', 'amicidibacco' ), 'colore' => __( 'Colore', 'amicidibacco' ), 'al_naso' => __( 'Al naso', 'amicidibacco' ), 'al_palato' => __( 'Al palato', 'amicidibacco' ), 'abbinamenti_gastronomici' => __( 'Abbinamenti gastronomici', 'amicidibacco' ), 'gradazione_alcolica' => __( 'Gradazione alcolica', 'amicidibacco' ), 'temperatura_di_servizio' => __( 'Temperatura di servizio', 'amicidibacco' ),
        'vitigni_disponibili:' => __( 'Vitigni disponibili', 'amicidibacco' ), 'provenienza_vinaccia:' => __( 'Provenienza vinaccia', 'amicidibacco' ), 'sistema_di_distillazione:' => __( 'Sistema di distillazione', 'amicidibacco' ), 'periodo_di_distillazione:' => __( 'Periodo di distillazione', 'amicidibacco' ), 'tipologia_di_invecchiamento:' => __( 'Invecchiamento', 'amicidibacco' ), 'profumo:' => __( 'Profumo', 'amicidibacco' ), 'sapore:' => __( 'Sapore', 'amicidibacco' ), 'grado_alcolico:' => __( 'Grado alcolico', 'amicidibacco' ), 'colore:' => __( 'Colore grappa', 'amicidibacco' ),
        'etichetta_descrizione_1' => __( 'Etichetta vino 1', 'amicidibacco' ), 'descrizione_1' => __( 'Vino 1', 'amicidibacco' ), 'etichetta_descrizione_2' => __( 'Etichetta vino 2', 'amicidibacco' ), 'descrizione_2' => __( 'Vino 2', 'amicidibacco' ), 'etichetta_descrizione_3' => __( 'Etichetta vino 3', 'amicidibacco' ), 'descrizione_3' => __( 'Vino 3', 'amicidibacco' ),
        'etichetta_descrizione_1_grappa' => __( 'Etichetta grappa 1', 'amicidibacco' ), 'descrizione_1_grappa' => __( 'Grappa 1', 'amicidibacco' ), 'etichetta_descrizione_2_grappa' => __( 'Etichetta grappa 2', 'amicidibacco' ), 'descrizione_2_grappa' => __( 'Grappa 2', 'amicidibacco' ),
        'stilebirra' => __( 'Stile birra', 'amicidibacco' ), 'ingredientibirra' => __( 'Ingredienti', 'amicidibacco' ), 'gradazione_alcolicabirre' => __( 'Gradazione birra', 'amicidibacco' ), 'colorebirre' => __( 'Colore birra', 'amicidibacco' ), 'al_palatobirre' => __( 'Al palato birra', 'amicidibacco' ), 'al_nasobirre' => __( 'Al naso birra', 'amicidibacco' ), 'temperatura_di_serviziobirre' => __( 'Temperatura birra', 'amicidibacco' ),
    );
}

/** Duplicate values already printed by WooCommerce remain in their original text only. */
function adb_product_technical_rows( $product ) {
    $rows = array();
    if ( ! $product instanceof WC_Product ) { return $rows; }
    $normalize = static function ( $text ) { return trim( preg_replace( '/\s+/u', ' ', html_entity_decode( wp_strip_all_tags( $text ), ENT_QUOTES, 'UTF-8' ) ) ); };
    $existing = $normalize( $product->get_description() . ' ' . $product->get_short_description() );
    foreach ( adb_product_fields() as $key => $label ) {
        if ( in_array( $key, array( 'etichetta', 'descrizione_etichetta', 'tipo_di_prodotto' ), true ) || 0 === strpos( $key, 'etichetta_descrizione_' ) ) { continue; }
        $value = get_post_meta( $product->get_id(), $key, true );
        if ( ! is_scalar( $value ) || '' === trim( (string) $value ) ) { continue; }
        $plain = $normalize( (string) $value );
        if ( '' === $plain || false !== strpos( $existing, $plain ) ) { continue; }
        if ( preg_match( '/^descrizione_([1-3])(_grappa)?$/', $key, $match ) ) {
            $editorial_label = get_post_meta( $product->get_id(), 'etichetta_descrizione_' . $match[1] . ( $match[2] ?? '' ), true );
            if ( is_string( $editorial_label ) && '' !== $editorial_label ) { $label = $editorial_label; }
        }
        $rows[] = array( 'label' => $label, 'value' => (string) $value );
    }
    return $rows;
}

function adb_product_tabs( $tabs ) {
    global $product;
    if ( adb_product_technical_rows( $product ) ) { $tabs['adb_technical'] = array( 'title' => __( 'Scheda tecnica', 'amicidibacco' ), 'priority' => 15, 'callback' => 'adb_product_technical_tab' ); }
    return $tabs;
}
add_filter( 'woocommerce_product_tabs', 'adb_product_tabs' );

function adb_product_technical_tab() {
    global $product;
    echo '<dl class="adb-technical">';
    foreach ( adb_product_technical_rows( $product ) as $row ) { echo '<div><dt>' . esc_html( $row['label'] ) . '</dt><dd>' . wp_kses_post( wpautop( $row['value'] ) ) . '</dd></div>'; }
    echo '</dl>';
}
