<?php defined('ABSPATH') || exit; get_header(); ?>
<main id="main-content" class="adb-page adb-wrap"><?php while (have_posts()) : the_post(); ?><header class="adb-page__heading"><h1><?php the_title(); ?></h1></header><div class="adb-page__content"><?php the_content(); ?></div><?php endwhile; ?></main>
<?php get_footer(); ?>
