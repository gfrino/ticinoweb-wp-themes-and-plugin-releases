<?php defined('ABSPATH') || exit; get_header(); ?>
<main id="main-content" class="adb-page adb-wrap"><header class="adb-page__heading"><p class="adb-kicker"><?php echo esc_html(get_bloginfo('name')); ?></p><h1><?php post_type_archive_title(); ?></h1></header><div class="adb-directory"><?php while (have_posts()) { the_post(); adb_winery_card(get_post()); } ?></div><?php the_posts_pagination(); ?></main>
<?php get_footer(); ?>
