<?php defined('ABSPATH') || exit; ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width, initial-scale=1"><?php wp_head(); ?></head>
<body <?php body_class(); ?>><?php wp_body_open(); ?>
<a class="adb-skip" href="#main-content"><?php esc_html_e('Vai al contenuto', 'amicidibacco'); ?></a>
<header class="adb-header" data-header>
    <div class="adb-header__inner">
        <a class="adb-brand" href="<?php echo esc_url(home_url('/')); ?>" aria-label="<?php echo esc_attr(get_bloginfo('name') . ' — ' . __('Home', 'amicidibacco')); ?>">
            <?php $logo = function_exists('ticinoweb_get_site_logo') ? ticinoweb_get_site_logo() : ''; if ($logo) : ?>
            <img src="<?php echo esc_url($logo); ?>" width="210" height="68" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" fetchpriority="high">
            <?php else : ?><span><?php bloginfo('name'); ?></span><?php endif; ?>
        </a>
        <nav class="adb-nav" id="adb-main-nav" aria-label="<?php esc_attr_e('Menu principale', 'amicidibacco'); ?>"><?php wp_nav_menu(['theme_location' => 'primary', 'container' => false, 'fallback_cb' => false, 'depth' => 1]); ?></nav>
        <div class="adb-header__actions">
            <button class="adb-icon-button" data-search-open aria-label="<?php esc_attr_e('Cerca un vino', 'amicidibacco'); ?>"><?php echo adb_icon('search'); ?></button>
            <?php adb_cart_link(); ?>
            <a class="adb-header__shop" href="<?php echo esc_url(adb_catalog_url()); ?>"><?php esc_html_e('Entra in enoteca', 'amicidibacco'); ?> <?php echo adb_icon(); ?></a>
            <button class="adb-icon-button adb-menu-toggle" aria-expanded="false" aria-controls="adb-main-nav" data-menu-toggle aria-label="<?php esc_attr_e('Apri il menu', 'amicidibacco'); ?>"><?php echo adb_icon('menu'); ?></button>
        </div>
    </div>
</header>
<dialog class="adb-search-dialog" data-search-dialog aria-labelledby="adb-search-title">
    <button class="adb-icon-button adb-search-dialog__close" data-search-close aria-label="<?php esc_attr_e('Chiudi ricerca', 'amicidibacco'); ?>"><?php echo adb_icon('close'); ?></button>
    <h2 id="adb-search-title"><?php esc_html_e('Il prossimo vino da scoprire.', 'amicidibacco'); ?></h2>
    <form role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>"><label for="adb-search"><?php esc_html_e('Nome del vino', 'amicidibacco'); ?></label><div><input id="adb-search" name="s" type="search" placeholder="<?php esc_attr_e('Cerca nel catalogo…', 'amicidibacco'); ?>" required><input type="hidden" name="post_type" value="product"><button type="submit" class="adb-button"><?php esc_html_e('Cerca', 'amicidibacco'); ?> <?php echo adb_icon(); ?></button></div></form>
</dialog>
