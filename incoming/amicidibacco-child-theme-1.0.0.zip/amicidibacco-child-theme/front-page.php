<?php
defined('ABSPATH') || exit;
get_header();
$hero_products = adb_products(['ids' => [absint(adb_home('hero_product_id'))], 'limit' => 1]);
$hero = $hero_products[0] ?? null;
$selected_ids = (array) adb_home('selection_ids', []);
$selected = adb_products(['ids' => $selected_ids, 'limit' => 4]);
$wineries = adb_wineries((array) adb_home('winery_ids', []), 3);
?>
<main id="main-content" class="adb-home">
    <section class="adb-hero" data-hero>
        <div class="adb-hero__copy">
            <p class="adb-hero__eyebrow"><?php echo esc_html(adb_home('hero_eyebrow')); ?></p>
            <?php adb_heading(adb_home('hero_title'), 'h1', 'adb-hero__title'); ?>
            <p class="adb-hero__text"><?php echo esc_html(adb_home('hero_text')); ?></p>
            <div class="adb-hero__links"><a class="adb-button" href="<?php echo esc_url(adb_catalog_url()); ?>"><?php echo esc_html(adb_home('hero_link_label') ?: __('Scopri i vini', 'amicidibacco')); ?> <?php echo adb_icon(); ?></a><a class="adb-text-link" href="#il-nostro-mondo"><?php esc_html_e('Il nostro mondo', 'amicidibacco'); ?> <?php echo adb_icon('down'); ?></a></div>
            <div class="adb-hero__note"><span class="adb-hero__note-line"></span><?php echo esc_html(adb_home('hero_note')); ?></div>
        </div>
        <div class="adb-hero__scene">
            <div class="adb-hero__landscape" data-hero-landscape><?php adb_photo(adb_home('hero_image_id'), 'full', ['loading' => 'eager', 'fetchpriority' => 'high', 'decoding' => 'async', 'sizes' => '(max-width: 760px) 100vw, 55vw']); ?></div>
            <span class="adb-hero__script" aria-hidden="true"><?php echo esc_html(adb_home('hero_scene_word')); ?></span>
            <span class="adb-hero__caption"><?php echo esc_html(adb_home('hero_image_caption')); ?></span>
            <?php if ($hero) : ?>
                <a class="adb-hero__bottle" data-hero-bottle href="<?php echo esc_url($hero->get_permalink()); ?>" aria-label="<?php echo esc_attr($hero->get_name()); ?>"><?php echo $hero->get_image('full', ['loading' => 'eager', 'fetchpriority' => 'high', 'decoding' => 'async']); ?></a>
                <a class="adb-hero__wine" href="<?php echo esc_url($hero->get_permalink()); ?>"><span><?php esc_html_e('Un vino da scoprire', 'amicidibacco'); ?></span><strong><?php echo esc_html($hero->get_name()); ?></strong><span><?php echo wp_kses_post($hero->get_price_html()); ?> <?php echo adb_icon(); ?></span></a>
            <?php endif; ?>
        </div>
        <a class="adb-hero__scroll" href="#il-nostro-mondo" aria-label="<?php esc_attr_e('Scopri la nostra selezione', 'amicidibacco'); ?>"><?php echo adb_icon('down'); ?></a>
    </section>

    <nav class="adb-categories adb-wrap" aria-label="<?php esc_attr_e('Esplora per tipologia', 'amicidibacco'); ?>">
        <span><?php esc_html_e('Cosa ti va di scoprire?', 'amicidibacco'); ?></span>
        <?php foreach ((array) adb_home('category_ids', []) as $term_id) : $term = get_term(absint($term_id), 'product_cat'); if (!$term || is_wp_error($term)) { continue; } ?><a href="<?php echo esc_url(get_term_link($term)); ?>"><?php echo esc_html($term->name); ?> <span>↗</span></a><?php endforeach; ?>
    </nav>

    <section id="il-nostro-mondo" class="adb-intro adb-wrap" data-reveal>
        <p class="adb-kicker"><?php echo esc_html(adb_home('intro_eyebrow')); ?></p>
        <?php adb_heading(adb_home('intro_title'), 'h2', 'adb-intro__title'); ?>
        <p><?php echo esc_html(adb_home('intro_text')); ?></p>
    </section>

    <?php if ($selected) : ?>
    <section class="adb-selection adb-wrap" aria-labelledby="adb-selection-title">
        <div class="adb-section-heading"><div><p class="adb-kicker"><?php echo esc_html(adb_home('selection_eyebrow')); ?></p><h2 id="adb-selection-title"><?php echo esc_html(adb_home('selection_title')); ?></h2></div><a class="adb-link" href="<?php echo esc_url(adb_catalog_url()); ?>"><?php esc_html_e('Tutti i vini', 'amicidibacco'); ?> <?php echo adb_icon(); ?></a></div>
        <p class="adb-selection__text"><?php echo esc_html(adb_home('selection_text')); ?></p>
        <div class="adb-product-grid"><?php foreach ($selected as $product) { adb_product_card($product); } ?></div>
    </section>
    <?php endif; ?>

    <section class="adb-journey" data-journey aria-labelledby="adb-journey-title">
        <div class="adb-journey__stage">
            <?php foreach (array_slice(adb_journey_images(), 0, 3) as $index => $image_id) : ?><div class="adb-journey__photo <?php echo $index ? 'adb-journey__photo--next' : ''; ?>" data-journey-photo="<?php echo esc_attr($index); ?>"><?php adb_photo($image_id, 'full', ['loading' => 'lazy', 'sizes' => '(max-width:900px) 1050px, 110vw']); ?></div><?php endforeach; ?>
            <div class="adb-journey__shade"></div>
            <div class="adb-journey__copy"><p class="adb-kicker"><?php echo esc_html(adb_home('journey_eyebrow')); ?></p><?php adb_heading(adb_home('journey_title'), 'h2', 'adb-journey__title'); ?><p><?php echo esc_html(adb_home('journey_text')); ?></p><a class="adb-button adb-button--light" href="<?php echo esc_url(adb_page_link('wineries_page_id', '/produttori/')); ?>"><?php esc_html_e('Incontra le cantine', 'amicidibacco'); ?> <?php echo adb_icon(); ?></a></div>
            <div class="adb-journey__words" aria-hidden="true"><span><?php echo esc_html(adb_home('journey_word_one')); ?></span><span><?php echo esc_html(adb_home('journey_word_two')); ?></span><span><?php echo esc_html(adb_home('journey_word_three')); ?></span></div>
            <div class="adb-journey__progress" aria-hidden="true"><span></span></div>
            <p class="adb-journey__caption"><?php echo esc_html(adb_home('journey_caption')); ?></p>
        </div>
    </section>

    <section class="adb-territories adb-wrap" aria-labelledby="adb-territory-title">
        <div class="adb-section-heading"><div><p class="adb-kicker"><?php echo esc_html(adb_home('territory_eyebrow')); ?></p><h2 id="adb-territory-title"><?php echo esc_html(adb_home('territory_title')); ?></h2></div><p><?php echo esc_html(adb_home('territory_text')); ?></p></div>
        <div class="adb-territories__grid">
            <?php foreach (['ticino', 'italia'] as $place) : $term_id = absint(adb_home($place . '_term_id')); $tax = $place === 'ticino' ? 'pa_regione' : 'pa_nazione'; $term = get_term($term_id, $tax); if (!$term || is_wp_error($term)) { continue; } ?>
            <a class="adb-territory adb-territory--<?php echo esc_attr($place); ?>" href="<?php echo esc_url(get_term_link($term)); ?>"><div class="adb-territory__photo"><?php adb_photo(adb_home($place . '_image_id'), 'large', ['loading' => 'lazy', 'sizes' => '(max-width: 760px) 800px, 60vw']); ?></div><div class="adb-territory__text"><span><?php echo esc_html(adb_home($place . '_subtitle')); ?></span><h3><?php echo esc_html($term->name); ?></h3><p><?php echo esc_html(adb_home($place . '_text')); ?></p><span class="adb-territory__action"><?php esc_html_e('Scopri i vini', 'amicidibacco'); ?> <?php echo adb_icon(); ?></span></div></a>
            <?php endforeach; ?>
        </div>
    </section>

    <?php if ($wineries) : ?>
    <section class="adb-wineries adb-wrap" aria-labelledby="adb-wineries-title">
        <div class="adb-section-heading"><div><p class="adb-kicker"><?php echo esc_html(adb_home('winery_eyebrow')); ?></p><h2 id="adb-wineries-title"><?php echo esc_html(adb_home('winery_title')); ?></h2></div><a class="adb-link" href="<?php echo esc_url(adb_page_link('wineries_page_id', '/produttori/')); ?>"><?php esc_html_e('Tutte le cantine', 'amicidibacco'); ?> <?php echo adb_icon(); ?></a></div>
        <p class="adb-selection__text"><?php echo esc_html(adb_home('winery_text')); ?></p>
        <div class="adb-winery-grid"><?php foreach ($wineries as $winery) : $image = absint(get_post_meta($winery->ID, 'immagine_di_sfondo_sulla_pagina_del_produttore', true)) ?: get_post_thumbnail_id($winery->ID); ?><a class="adb-winery" href="<?php echo esc_url(get_permalink($winery)); ?>"><div><?php adb_photo($image, 'large', ['loading' => 'lazy']); ?></div><h3><?php echo esc_html($winery->post_title); ?> <?php echo adb_icon(); ?></h3></a><?php endforeach; ?></div>
    </section>
    <?php endif; ?>

    <section class="adb-story adb-wrap" data-reveal><div class="adb-story__photo"><?php adb_photo(adb_home('story_image_id'), 'large', ['loading' => 'lazy']); ?></div><div class="adb-story__copy"><p class="adb-kicker"><?php echo esc_html(adb_home('story_eyebrow')); ?></p><?php adb_heading(adb_home('story_title')); ?><p><?php echo esc_html(adb_home('story_text')); ?></p><a class="adb-link" href="<?php echo esc_url(adb_page_link('story_page_id', '/storia/')); ?>"><?php esc_html_e('La nostra storia', 'amicidibacco'); ?> <?php echo adb_icon(); ?></a></div></section>

    <section class="adb-professional"><div class="adb-wrap adb-professional__inner"><div><p class="adb-kicker"><?php echo esc_html(adb_home('professional_eyebrow')); ?></p><?php adb_heading(adb_home('professional_title')); ?><p><?php echo esc_html(adb_home('professional_text')); ?></p></div><a class="adb-button adb-button--light" href="<?php echo esc_url(adb_page_link('contact_page_id', '/contatti/')); ?>"><?php esc_html_e('Parliamone insieme', 'amicidibacco'); ?> <?php echo adb_icon(); ?></a></div></section>

    <?php $faq_id = absint(adb_home('faq_id')); if ($faq_id && function_exists('ticinoweb_faq_render')) : ?><section class="adb-faq adb-wrap"><h2><?php echo esc_html(adb_home('faq_title') ?: __('Prima del prossimo brindisi', 'amicidibacco')); ?></h2><?php echo ticinoweb_faq_render($faq_id, ['show_title' => false, 'heading_level' => 3]); ?></section><?php endif; ?>
</main>
<?php get_footer(); ?>
