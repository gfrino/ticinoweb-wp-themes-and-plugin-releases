<?php
defined('ABSPATH') || exit;
define('ADB_VERSION', wp_get_theme()->get('Version'));
require_once __DIR__ . '/inc/catalog.php';
require_once __DIR__ . '/inc/cms.php';
require_once __DIR__ . '/inc/presentation.php';

add_action('after_setup_theme', function () {
    load_child_theme_textdomain('amicidibacco', get_stylesheet_directory() . '/languages');
    register_nav_menus(['adb_footer' => __('Menu del piè di pagina', 'amicidibacco')]);
    add_post_type_support('page', 'excerpt');
    remove_action('wp_enqueue_scripts', 'ticinoweb_ai_assets');
}, 100);

add_action('wp_enqueue_scripts', function () {
    $uri = get_stylesheet_directory_uri();
    wp_enqueue_style('adb-site', $uri . '/assets/css/site.css', [], ADB_VERSION);
    wp_enqueue_script('adb-navigation', $uri . '/assets/js/navigation.js', [], ADB_VERSION, true);
    if (is_front_page()) {
        wp_enqueue_style('adb-home', $uri . '/assets/css/home.css', ['adb-site'], ADB_VERSION);
        wp_enqueue_script('adb-lenis', $uri . '/assets/vendor/lenis.min.js', [], ADB_VERSION, true);
        wp_enqueue_script('adb-home', $uri . '/assets/js/home.js', ['adb-lenis'], ADB_VERSION, true);
    }
    if (function_exists('WC')) {
        wp_enqueue_script('wc-cart-fragments');
    }
    if (is_page_template('page-contatti.php') || is_page('contatti')) {
        wp_enqueue_script('adb-contact', $uri . '/assets/js/contact.js', [], ADB_VERSION, true);
        wp_localize_script('adb-contact', 'adbContact', ['ajaxUrl' => admin_url('admin-ajax.php'), 'recaptchaKey' => (string) get_option('ticinoweb_recaptcha_site_key', ''), 'error' => __('Invio non riuscito. Riprova o contattaci via email.', 'amicidibacco'), 'loading' => __('Invio in corso…', 'amicidibacco')]);
    }
}, 30);

add_action('wp_head', function () {
    $uri = get_stylesheet_directory_uri();
    echo '<link rel="preload" href="' . esc_url($uri . '/assets/fonts/cormorant-regular.ttf') . '" as="font" type="font/ttf" crossorigin>' . "\n";
    echo '<link rel="preload" href="' . esc_url($uri . '/assets/fonts/manrope-latin.woff2') . '" as="font" type="font/woff2" crossorigin>' . "\n";
}, 2);

add_filter('woocommerce_add_to_cart_fragments', function ($fragments) {
    ob_start(); adb_cart_link(); $fragments['a.adb-cart'] = ob_get_clean();
    return $fragments;
});
add_filter('body_class', function ($classes) { $classes[] = 'adb-site'; return $classes; });
add_filter('woocommerce_show_page_title', '__return_false');
add_filter('wp_sitemaps_posts_query_args', function ($args, $post_type) {
    if (in_array($post_type, ['product', 'produttore'], true)) { $args['adb_language'] = 'it'; $args['suppress_filters'] = false; }
    return $args;
}, 20, 2);
add_filter('wp_sitemaps_taxonomies_query_args', function ($args, $taxonomy) {
    if (in_array($taxonomy, ['product_cat', 'product_tag'], true) || strpos($taxonomy, 'pa_') === 0) { $args['adb_language'] = 'it'; }
    return $args;
}, 20, 2);
add_filter('ticinoweb_seo_canonical_url', function ($url) {
    $page = max((int) get_query_var('paged'), (int) get_query_var('page'));
    if ($page > 1 && !is_front_page()) {
        return remove_query_arg(array_merge(['orderby', 'min_price', 'max_price'], array_column(adb_catalog_filter_definitions(), 'param')), get_pagenum_link($page, false));
    }
    return $url;
});
// Local development must never send messages to real customers or the merchant.
add_filter('pre_wp_mail', function ($result) { return wp_get_environment_type() === 'local' ? false : $result; });
add_filter('ticinoweb_form_errors', function ($errors, $fields, $raw) {
    if (isset($raw['adb_contact']) && empty($raw['privacy'])) { $errors['privacy'] = __('Conferma di aver letto l’informativa sulla privacy.', 'amicidibacco'); }
    return $errors;
}, 10, 3);
add_action('woocommerce_review_order_before_submit', function () {
    woocommerce_form_field('adb_age', ['type' => 'checkbox', 'required' => true, 'label' => __('Confermo di avere almeno 18 anni.', 'amicidibacco')]);
});
add_action('woocommerce_checkout_process', function () {
    if (empty($_POST['adb_age'])) { wc_add_notice(__('Per acquistare devi confermare di avere almeno 18 anni.', 'amicidibacco'), 'error'); }
});
