<?php defined('ABSPATH') || exit; $contact = function_exists('ticinoweb_get_contact_info') ? ticinoweb_get_contact_info() : []; ?>
<footer class="adb-footer">
    <div class="adb-wrap adb-footer__top"><div><a class="adb-footer__name" href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a><p><?php echo esc_html(get_bloginfo('description')); ?></p></div><a class="adb-link" href="<?php echo esc_url(adb_catalog_url()); ?>"><?php esc_html_e('Trova il tuo prossimo vino', 'amicidibacco'); ?> <?php echo adb_icon(); ?></a></div>
    <div class="adb-wrap adb-footer__main">
        <div><h2><?php esc_html_e('Ci trovi a', 'amicidibacco'); ?></h2><p><?php echo nl2br(esc_html($contact['address'] ?? '')); ?></p><p><?php echo esc_html($contact['opening_hours_note'] ?? ''); ?></p></div>
        <div><h2><?php esc_html_e('Parliamo di vino', 'amicidibacco'); ?></h2><?php if (!empty($contact['email'])) : ?><a href="<?php echo esc_url('mailto:' . $contact['email']); ?>"><?php echo esc_html($contact['email']); ?></a><?php endif; ?><?php if (!empty($contact['phone'])) : ?><a href="<?php echo esc_url('tel:' . preg_replace('/[^+0-9]/', '', $contact['phone'])); ?>"><?php echo esc_html($contact['phone_display'] ?: $contact['phone']); ?></a><?php endif; ?></div>
        <nav aria-label="<?php esc_attr_e('Informazioni e condizioni', 'amicidibacco'); ?>"><?php wp_nav_menu(['theme_location' => 'adb_footer', 'container' => false, 'fallback_cb' => false, 'depth' => 1]); ?></nav>
        <div class="adb-footer__account"><h2><?php esc_html_e('La tua enoteca', 'amicidibacco'); ?></h2><a href="<?php echo esc_url(wc_get_page_permalink('myaccount')); ?>"><?php esc_html_e('Il mio account', 'amicidibacco'); ?></a><a href="<?php echo esc_url(wc_get_cart_url()); ?>"><?php esc_html_e('Il mio carrello', 'amicidibacco'); ?></a><span><?php echo esc_html(get_woocommerce_currency()); ?> · <?php esc_html_e('Vendita ai maggiorenni', 'amicidibacco'); ?></span></div>
    </div>
    <div class="adb-wrap adb-footer__bottom"><span>© <?php echo esc_html(wp_date('Y')); ?> <?php echo esc_html(get_option('tw_seo_org_name') ?: get_bloginfo('name')); ?></span><a href="https://ticinoweb.com/" target="_blank" rel="noopener">ticinoWEB</a></div>
</footer>
<?php wp_footer(); ?></body></html>
