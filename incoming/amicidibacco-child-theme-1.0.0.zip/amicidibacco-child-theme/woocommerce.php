<?php defined('ABSPATH') || exit; get_header(); ?>
<main id="main-content" class="adb-commerce adb-wrap">
<?php if (!is_product()) : ?>
    <header class="adb-catalog-heading"><p class="adb-kicker"><?php echo esc_html(get_bloginfo('name')); ?></p><h1><?php woocommerce_page_title(); ?></h1><p><?php echo esc_html(get_post_field('post_excerpt', wc_get_page_id('shop'))); ?></p></header>
    <form class="adb-filters" method="get" action="<?php echo esc_url(adb_catalog_url()); ?>" aria-label="<?php esc_attr_e('Filtra il catalogo', 'amicidibacco'); ?>">
        <?php foreach (adb_catalog_filters() as $filter) : $param = $filter['param']; $current = isset($_GET[$param]) && is_scalar($_GET[$param]) ? sanitize_title(wp_unslash($_GET[$param])) : ''; ?>
        <label><span><?php echo esc_html($filter['label']); ?></span><select name="<?php echo esc_attr($param); ?>"><option value=""><?php esc_html_e('Tutti', 'amicidibacco'); ?></option><?php foreach ($filter['terms'] as $term) : ?><option value="<?php echo esc_attr($term->slug); ?>" <?php selected($current, $term->slug); ?>><?php echo esc_html($term->name); ?></option><?php endforeach; ?></select></label>
        <?php endforeach; ?>
        <button type="submit" class="adb-button"><?php esc_html_e('Filtra', 'amicidibacco'); ?> <?php echo adb_icon(); ?></button><a class="adb-filter-reset" href="<?php echo esc_url(adb_catalog_url()); ?>"><?php esc_html_e('Azzera', 'amicidibacco'); ?></a>
    </form>
<?php endif; ?>
<?php woocommerce_content(); ?>
</main>
<?php get_footer(); ?>
