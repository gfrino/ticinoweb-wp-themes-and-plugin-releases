<?php defined('ABSPATH') || exit; global $product; if (!$product || !$product->is_visible()) { return; } ?>
<li <?php wc_product_class('', $product); ?>><?php adb_product_card($product); ?></li>
