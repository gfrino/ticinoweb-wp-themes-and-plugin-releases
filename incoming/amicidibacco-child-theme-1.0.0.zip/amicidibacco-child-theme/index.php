<?php defined('ABSPATH') || exit; get_header(); ?>
<main id="main-content" class="adb-page adb-wrap"><h1><?php echo esc_html(is_search() ? sprintf(__('Risultati per “%s”', 'amicidibacco'), get_search_query()) : get_bloginfo('name')); ?></h1><?php while (have_posts()) : the_post(); ?><article><h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2><?php the_excerpt(); ?></article><?php endwhile; ?><?php the_posts_pagination(); ?></main>
<?php get_footer(); ?>
