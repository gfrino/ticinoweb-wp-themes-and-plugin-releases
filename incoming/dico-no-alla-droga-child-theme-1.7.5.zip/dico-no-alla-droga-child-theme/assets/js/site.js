/* Header: menu a tendina su telefono, ombra allo scroll. Nessuna dipendenza. */
(function () {
    'use strict';
    var header = document.querySelector('.dnd-header');
    var toggle = document.querySelector('.dnd-nav-toggle');
    if (!header) { return; }

    function onScroll() { header.classList.toggle('is-scrolled', window.scrollY > 8); }
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });

    if (toggle) {
        toggle.addEventListener('click', function () {
            var open = header.classList.toggle('is-open');
            toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
        header.addEventListener('click', function (e) {
            if (e.target.closest && e.target.closest('.dnd-nav a')) {
                header.classList.remove('is-open');
                toggle.setAttribute('aria-expanded', 'false');
            }
        });
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') {
                header.classList.remove('is-open');
                toggle.setAttribute('aria-expanded', 'false');
            }
        });
    }
})();

/* Riquadri con i prezzi (Membership): un clic sceglie la tessera nel modulo sotto. */
(function () {
    var form = document.querySelector('.twf-form');
    if (!form) return;
    var radios = [].slice.call(form.querySelectorAll('input[type="radio"]'));
    if (!radios.length) return;
    function labelOf(r) {
        var l = r.closest('label');
        return (l ? l.textContent : '').replace(/\s+/g, ' ').trim().toLowerCase();
    }
    var cards = document.querySelectorAll('.dnd-grid-3 > .dnd-card');
    [].forEach.call(cards, function (card) {
        var h = card.querySelector('h3');
        if (!h) return;
        var name = h.textContent.replace(/\s+/g, ' ').trim().toLowerCase();
        var radio = radios.filter(function (r) { return labelOf(r).indexOf(name) === 0; })[0];
        if (!radio) return;
        card.classList.add('dnd-card--pick');
        card.setAttribute('role', 'button');
        card.setAttribute('tabindex', '0');
        card.setAttribute('aria-label', h.textContent.trim());
        function pick() {
            radio.click();
            var target = form.closest('form') || form;
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            setTimeout(function () { try { radio.focus({ preventScroll: true }); } catch (e) {} }, 500);
        }
        card.addEventListener('click', pick);
        card.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pick(); }
        });
    });
})();
