<?php
/**
 * Site admin UI: one page, three tabs (Lingue / Traduzioni / Stato).
 * Inline editing via admin-ajax; assets loaded only on this page.
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Admin {

    const CAP  = 'twtr_manage_translations';
    const SLUG = 'tw-translate-plus';

    /**
     * Register menu, assets and AJAX endpoints.
     */
    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'menu'));
        add_action('admin_enqueue_scripts', array(__CLASS__, 'assets'));
        add_action('admin_post_twtr_save_languages', array(__CLASS__, 'handle_save_languages'));
        add_action('wp_ajax_twtr_save_entry', array(__CLASS__, 'ajax_save_entry'));
        add_action('wp_ajax_twtr_restore_google', array(__CLASS__, 'ajax_restore_google'));
        add_action('wp_ajax_twtr_recover_previous', array(__CLASS__, 'ajax_recover_previous'));
        add_action('wp_ajax_twtr_process_now', array(__CLASS__, 'ajax_process_now'));
        add_action('wp_ajax_twtr_retry_errors', array(__CLASS__, 'ajax_retry_errors'));
        add_action('wp_ajax_twtr_index_site', array(__CLASS__, 'ajax_index_site'));
        add_action('wp_ajax_twtr_wpml_step', array(__CLASS__, 'ajax_wpml_step'));
        add_action('wp_ajax_twtr_wpml_undo', array(__CLASS__, 'ajax_wpml_undo'));
        add_action('admin_notices', array(__CLASS__, 'wpml_standby_notice'));
    }

    /** @return bool WPML data present (the migration tab is shown). */
    private static function wpml_tab_available() {
        require_once TWTR_DIR . 'includes/class-twtr-wpml.php';
        return Twtr_Wpml::available();
    }

    /**
     * While WPML is active tW Translate does not serve the front end: say so,
     * with the way forward.
     */
    public static function wpml_standby_notice() {
        if (!Twtr_Router::wpml_active() || !current_user_can(self::CAP)) {
            return;
        }
        $url = add_query_arg(array('page' => self::SLUG, 'tab' => 'wpml'), admin_url('admin.php'));
        printf(
            '<div class="notice notice-info"><p><strong>tW Translate Plus</strong> — %s <a href="%s">%s</a></p></div>',
            esc_html__('WPML è ancora attivo: tW Translate è in attesa e non modifica il sito pubblico. Importa le traduzioni di WPML, poi disattiva WPML.', 'tw-translate-plus'),
            esc_url($url),
            esc_html__('Apri la migrazione da WPML', 'tw-translate-plus')
        );
    }

    public static function menu() {
        add_menu_page(
            'tW Translate Plus',
            'tW Translate',
            self::CAP,
            self::SLUG,
            array(__CLASS__, 'render'),
            'dashicons-translation',
            61
        );
    }

    /**
     * Enqueue admin assets only on the plugin pages.
     *
     * @param string $hook
     */
    public static function assets($hook) {
        if (strpos((string) $hook, self::SLUG) === false) {
            return;
        }
        wp_enqueue_style('twtr-admin', TWTR_URL . 'admin/assets/admin.css', array(), TWTR_VERSION);
        wp_enqueue_script('twtr-admin', TWTR_URL . 'admin/assets/admin.js', array('jquery'), TWTR_VERSION, true);
        wp_localize_script('twtr-admin', 'twtrAdmin', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('twtr_admin'),
            'i18n'    => array(
                'saved'   => __('Salvato', 'tw-translate-plus'),
                'error'   => __('Errore durante il salvataggio', 'tw-translate-plus'),
                'working' => __('Elaborazione…', 'tw-translate-plus'),
                'indexProgress' => __('Indicizzati %1$d di %2$d elementi…', 'tw-translate-plus'),
                'indexDone'     => __('Indicizzazione completata: %1$d elementi esaminati, %2$d nuove stringhe in coda.', 'tw-translate-plus'),
                'wpmlSteps'     => array(
                    'configure' => __('Lingue', 'tw-translate-plus'),
                    'posts'     => __('Pagine, prodotti, modelli Elementor', 'tw-translate-plus'),
                    'terms'     => __('Categorie e attributi', 'tw-translate-plus'),
                    'media'     => __('Media', 'tw-translate-plus'),
                    'strings'   => __('Stringhe', 'tw-translate-plus'),
                    'redirects' => __('Indirizzi e redirect', 'tw-translate-plus'),
                ),
                'wpmlProgress'  => __('%1$s: %2$d di %3$d', 'tw-translate-plus'),
                'wpmlDone'      => __('Import completato. Ora puoi disattivare WPML: tW Translate prenderà il suo posto.', 'tw-translate-plus'),
                'wpmlConfirm'   => __('Importare ora le traduzioni da WPML? Le lingue di tW Translate verranno impostate come in WPML. Il sito pubblico non cambia finché WPML è attivo.', 'tw-translate-plus'),
                'wpmlUndo'      => __('Eliminare tutte le traduzioni importate da WPML, gli indirizzi tradotti e i redirect?', 'tw-translate-plus'),
            ),
        ));
    }

    /**
     * ticinoWEB branding block: logo top-left with the plugin version below.
     * Shared by every plugin admin page.
     */
    public static function branding_header() {
        ?>
        <div class="twtr-branding">
            <img class="twtr-logo" src="<?php echo esc_url(TWTR_URL . 'admin/assets/images/logo-ticinoweb.png'); ?>" alt="ticinoWEB" width="300" height="99" />
            <p class="twtr-version-line">tW Translate Plus <code>v<?php echo esc_html(TWTR_VERSION); ?></code></p>
        </div>
        <?php
    }

    /**
     * ticinoWEB software license notice, shown at the bottom of every
     * plugin admin page.
     */
    public static function license_footer() {
        ?>
        <p class="twtr-license">
            © <?php echo esc_html(date('Y')); ?> <a href="https://ticinoweb.net" target="_blank" rel="noopener">ticinoWEB</a> —
            <?php esc_html_e('Questo software è concesso in licenza d\'uso esclusiva per questo sito. È vietata la ridistribuzione, la rivendita o l\'uso non autorizzato del codice sorgente.', 'tw-translate-plus'); ?>
        </p>
        <?php
    }

    /**
     * Page router.
     */
    public static function render() {
        if (!current_user_can(self::CAP)) {
            wp_die(esc_html__('Permessi insufficienti.', 'tw-translate-plus'));
        }
        $tab = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : 'languages'; // phpcs:ignore WordPress.Security.NonceVerification -- read-only tab switch.
        ?>
        <div class="wrap twtr-wrap">
            <?php self::branding_header(); ?>
            <h1>tW Translate Plus</h1>
            <?php settings_errors('twtr'); ?>
            <nav class="nav-tab-wrapper">
                <?php
                $tabs = array(
                    'languages'    => __('Lingue', 'tw-translate-plus'),
                    'translations' => __('Traduzioni', 'tw-translate-plus'),
                    'status'       => __('Stato', 'tw-translate-plus'),
                );
                if (self::wpml_tab_available()) {
                    $tabs['wpml'] = __('Migrazione WPML', 'tw-translate-plus');
                }
                foreach ($tabs as $key => $label) {
                    printf(
                        '<a href="%s" class="nav-tab %s">%s</a>',
                        esc_url(add_query_arg(array('page' => self::SLUG, 'tab' => $key), admin_url('admin.php'))),
                        $tab === $key ? 'nav-tab-active' : '',
                        esc_html($label)
                    );
                }
                ?>
            </nav>
            <?php
            if ($tab === 'translations') {
                self::render_translations();
            } elseif ($tab === 'status') {
                self::render_status();
            } elseif ($tab === 'wpml' && self::wpml_tab_available()) {
                self::render_wpml();
            } else {
                self::render_languages();
            }
            self::license_footer();
            ?>
        </div>
        <?php
    }

    /* ---------------------------------------------------------------- Tab: Lingue */

    /**
     * Icona "?" con un pannello di spiegazione, mostrato al passaggio del mouse
     * o al fuoco da tastiera (tabindex="0" la rende raggiungibile senza mouse).
     *
     * @param string $testo Spiegazione completa.
     */
    private static function help($testo) {
        ?>
        <span class="twtr-help" tabindex="0">
            <span aria-hidden="true">?</span>
            <span class="twtr-help__testo" role="tooltip"><?php echo esc_html($testo); ?></span>
        </span>
        <?php
    }

    /**
     * Un checkbox nativo vestito da interruttore (verde acceso, grigio spento),
     * per restare rapidamente distinguibile da "attiva/spenta" a colpo d'occhio
     * in una tabella con piu' righe. Il controllo resta un vero <input
     * type="checkbox">: nessun JavaScript necessario, il salvataggio del form
     * funziona esattamente come prima.
     *
     * @param string $name    Attributo name del checkbox.
     * @param bool   $checked Stato attuale.
     * @param string $sr      Etichetta per chi usa uno screen reader.
     */
    private static function toggle($name, $checked, $sr) {
        ?>
        <label class="twtr-switch">
            <input type="checkbox" name="<?php echo esc_attr($name); ?>" value="1" <?php checked($checked); ?> />
            <span class="twtr-switch__pista"><span class="twtr-switch__pallino"></span></span>
            <span class="screen-reader-text"><?php echo esc_html($sr); ?></span>
        </label>
        <?php
    }

    private static function render_languages() {
        $catalog  = Twtr_Settings::catalog();
        $settings = Twtr_Settings::site();
        $counts   = Twtr_Storage::status_counts();
        ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="twtr-card">
            <input type="hidden" name="action" value="twtr_save_languages" />
            <?php wp_nonce_field('twtr_save_languages'); ?>

            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><label for="twtr_default_lang"><?php esc_html_e('Lingua principale', 'tw-translate-plus'); ?></label></th>
                    <td>
                        <select name="default_lang" id="twtr_default_lang">
                            <?php foreach ($catalog as $slug => $info) : ?>
                                <option value="<?php echo esc_attr($slug); ?>" <?php selected($settings['default_lang'], $slug); ?>>
                                    <?php echo esc_html(Twtr_Settings::flag($slug) . ' ' . $info['label'] . ' (' . $slug . ')'); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <p class="description"><?php esc_html_e('La lingua principale resta senza prefisso URL.', 'tw-translate-plus'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <?php esc_html_e('Traduzione automatica', 'tw-translate-plus'); ?>
                        <?php self::help(__("Quando è ACCESA (comportamento di sempre): appena una lingua è attiva qui sotto, salvare qualunque pagina o articolo — o anche solo la prima visita a quella lingua da parte di un visitatore — mette subito in coda le stringhe mancanti e avvia la traduzione automatica con il motore configurato, consumando la quota giornaliera di caratteri. Quando è SPENTA: una lingua attivata resta visitabile per configurarla o farne un'anteprima, ma nessun salvataggio e nessuna visita avviano la traduzione da soli. Puoi comunque tradurre quando decidi tu, dal tab Traduzioni con «Processa ora», oppure da WP-CLI con «wp twtr queue». Utile per attivare una lingua senza consumare quota mentre stai ancora preparando i contenuti.", 'tw-translate-plus')); ?>
                    </th>
                    <td>
                        <?php self::toggle('auto_translate', $settings['auto_translate'], __('Traduci automaticamente le lingue attive', 'tw-translate-plus')); ?>
                        <span class="twtr-switch-label"><?php esc_html_e('Traduci automaticamente le lingue attive', 'tw-translate-plus'); ?></span>
                    </td>
                </tr>
            </table>

            <h2><?php esc_html_e('Lingue aggiuntive', 'tw-translate-plus'); ?></h2>
            <table class="widefat striped twtr-langs-table">
                <thead>
                    <tr>
                        <th>
                            <?php esc_html_e('Attiva', 'tw-translate-plus'); ?>
                            <?php self::help(__("La lingua diventa raggiungibile all'indirizzo mostrato nella colonna URL (per esempio /tenconi/en/) e il router inizia a servirla. Da sola non basta a mostrarla al pubblico: senza spuntare anche «Pubblicata», resta esclusa dal selettore di lingua, dall'hreflang e dalla sitemap — è visitabile solo da chi conosce l'indirizzo diretto, utile per controllarla prima di renderla ufficiale.", 'tw-translate-plus')); ?>
                        </th>
                        <th><?php esc_html_e('Lingua', 'tw-translate-plus'); ?></th>
                        <th><?php esc_html_e('URL', 'tw-translate-plus'); ?></th>
                        <th><?php esc_html_e('Stato traduzioni', 'tw-translate-plus'); ?></th>
                        <th>
                            <?php esc_html_e('Pubblicata', 'tw-translate-plus'); ?>
                            <?php self::help(__("Rende la lingua ufficiale e visibile al pubblico: compare nel selettore di lingua del sito, riceve i tag hreflang reciproci verso le altre lingue e viene inclusa nella sitemap. Richiede che la lingua sia anche «Attiva»: pubblicare una lingua non attiva non ha effetto, perché non esisterebbe nessuna pagina da mostrare a quell'indirizzo.", 'tw-translate-plus')); ?>
                        </th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($catalog as $slug => $info) :
                    if ($slug === $settings['default_lang']) {
                        continue;
                    }
                    $enabled   = isset($settings['languages'][$slug]);
                    $published = $enabled && !empty($settings['languages'][$slug]['published']);
                    $c         = isset($counts[$slug]) ? $counts[$slug] : array();
                    $pending   = (isset($c['pending']) ? $c['pending'] : 0) + (isset($c['error']) ? $c['error'] : 0);
                    ?>
                    <tr>
                        <td><?php self::toggle("languages[{$slug}][enabled]", $enabled, sprintf(__('Attiva %s', 'tw-translate-plus'), $info['label'])); ?></td>
                        <td><span class="twtr-flag"><?php echo esc_html(Twtr_Settings::flag($slug)); ?></span> <strong><?php echo esc_html($info['label']); ?></strong> <code><?php echo esc_html($slug); ?></code></td>
                        <td><code><?php echo esc_html(rtrim((string) parse_url(home_url(), PHP_URL_PATH), '/') . '/' . $slug . '/'); ?></code></td>
                        <td>
                            <?php if (!$enabled) : ?>
                                <span class="twtr-badge">—</span>
                            <?php else :
                                $progress = Twtr_Storage::language_progress($slug); ?>
                                <div class="twtr-progress" role="progressbar" aria-valuenow="<?php echo esc_attr($progress['percent']); ?>" aria-valuemin="0" aria-valuemax="100" title="<?php echo esc_attr(sprintf(__('%1$s di %2$s testi tradotti', 'tw-translate-plus'), number_format_i18n($progress['ready']), number_format_i18n($progress['total']))); ?>">
                                    <span class="twtr-progress-fill <?php echo $progress['percent'] >= 100 ? 'is-complete' : ''; ?>" style="width: <?php echo esc_attr($progress['percent']); ?>%;"></span>
                                    <span class="twtr-progress-label"><?php echo esc_html($progress['percent']); ?>%</span>
                                </div>
                                <?php if (isset($c['error']) && $c['error'] > 0) : ?>
                                    <span class="twtr-badge twtr-badge-error"><?php echo esc_html(sprintf(__('%d errori', 'tw-translate-plus'), $c['error'])); ?></span>
                                <?php elseif ($pending > 0) : ?>
                                    <?php
                                    /*
                                     * "IN ELABORAZIONE" E' VERO SOLO SE IL CRON GIRA. Le righe pending
                                     * esistono appena una lingua viene attivata — l'estrattore le crea
                                     * subito — ma restano ferme finche' nessuno le processa, ne' il cron
                                     * (spento) ne' "Processa ora". Dirle "in elaborazione" mentre la
                                     * traduzione automatica e' spenta e' una bugia innocente ma confusa:
                                     * sembra che qualcosa stia lavorando quando invece e' tutto fermo.
                                     */
                                    ?>
                                    <span class="twtr-badge twtr-badge-pending">
                                        <?php
                                        echo esc_html(
                                            Twtr_Settings::auto_translate()
                                                ? sprintf(__('%d in elaborazione', 'tw-translate-plus'), $pending)
                                                : sprintf(__('%d in coda — traduzione automatica spenta', 'tw-translate-plus'), $pending)
                                        );
                                        ?>
                                    </span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td><input type="checkbox" name="languages[<?php echo esc_attr($slug); ?>][published]" value="1" <?php checked($published); ?> /></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <p class="description"><?php esc_html_e('Una lingua attiva ma non pubblicata è visitabile (con noindex) per anteprima, ma esclusa da selettore, hreflang e sitemap.', 'tw-translate-plus'); ?></p>
            <p class="description">
                <?php
                printf(
                    /* translators: %s: link to the Stato tab */
                    esc_html__('La percentuale conta anche i contenuti pubblicati mai indicizzati: per includere tutto il sito usa «%s» nel tab Stato.', 'tw-translate-plus'),
                    '<a href="' . esc_url(add_query_arg(array('page' => self::SLUG, 'tab' => 'status'), admin_url('admin.php'))) . '">' . esc_html__('Indicizza tutto il sito', 'tw-translate-plus') . '</a>'
                );
                ?>
            </p>
            <?php submit_button(__('Salva lingue', 'tw-translate-plus')); ?>
        </form>
        <?php self::render_switcher_help(); ?>
        <?php
    }

    /**
     * «Bandierine sul sito»: ready-to-copy shortcodes for any theme or page
     * builder (Elementor: «Shortcode» widget), with a live preview.
     */
    private static function render_switcher_help() {
        $variants = array(
            '[tw_language_switcher]'                       => __('Solo bandierine (consigliato per l\'header)', 'tw-translate-plus'),
            '[tw_language_switcher style="flags-names"]'   => __('Bandierina e nome della lingua', 'tw-translate-plus'),
            '[tw_language_switcher style="dropdown"]'      => __('Menu a tendina (lingua attuale, si apre con un clic)', 'tw-translate-plus'),
            '[tw_language_switcher style="codes"]'         => __('Sigle: IT · DE · FR', 'tw-translate-plus'),
            '[tw_language_switcher current="hide"]'        => __('Senza la lingua che si sta già guardando', 'tw-translate-plus'),
            '[tw_language_switcher flags="en:us" size="24"]' => __('Bandiera USA per l\'inglese, bandierine più grandi', 'tw-translate-plus'),
        );
        ?>
        <div class="twtr-card twtr-switcher-help">
            <h2><?php esc_html_e('Bandierine sul sito (selettore lingue)', 'tw-translate-plus'); ?></h2>
            <p><?php esc_html_e('Con i temi ticinoWEB il selettore è già nel menu. Con qualsiasi altro tema o page builder copia uno di questi shortcode e incollalo dove vuoi le bandierine: in Elementor usa il widget «Shortcode» (anche nell\'header di Elementor Pro), in Gutenberg il blocco «Shortcode», oppure in un widget di testo. Compaiono solo le lingue pubblicate; con una sola lingua non si vede nulla.', 'tw-translate-plus'); ?></p>
            <?php echo Twtr_Switcher::css(); // phpcs:ignore WordPress.Security.EscapeOutput -- static stylesheet. ?>
            <?php if (!Twtr_Switcher::has_languages()) : ?>
                <p class="twtr-warning"><?php esc_html_e('Pubblica almeno una lingua aggiuntiva (colonna «Pubblicata» qui sopra): finché c\'è una sola lingua il selettore non viene mostrato e le anteprime restano vuote.', 'tw-translate-plus'); ?></p>
            <?php endif; ?>
            <table class="widefat striped twtr-shortcodes">
                <tbody>
                <?php foreach ($variants as $code => $label) : ?>
                    <tr>
                        <td><code class="twtr-sc"><?php echo esc_html($code); ?></code><br /><span class="description"><?php echo esc_html($label); ?></span></td>
                        <td class="twtr-sc-preview" aria-hidden="true"><?php echo do_shortcode($code); // phpcs:ignore WordPress.Security.EscapeOutput -- shortcode output escaped in Twtr_Switcher::render(). ?></td>
                        <td><button type="button" class="button twtr-copy" data-copy="<?php echo esc_attr($code); ?>"><?php esc_html_e('Copia', 'tw-translate-plus'); ?></button></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <details class="twtr-advanced">
                <summary><?php esc_html_e('Per sviluppatori', 'tw-translate-plus'); ?></summary>
                <p><?php esc_html_e('Nel tema (PHP):', 'tw-translate-plus'); ?> <code>&lt;?php if (function_exists('twtr_language_switcher')) twtr_language_switcher(array('style' =&gt; 'flags')); ?&gt;</code></p>
                <p><?php echo esc_html(sprintf(
                    /* translators: %s: list of flag codes. */
                    __('Opzioni: style = flags | flags-names | names | codes | dropdown; current = show | hide; size = altezza in px; flags = bandiera diversa per una lingua (codici disponibili: %s); class = classe CSS aggiuntiva. Lo stile si personalizza dal tema con le classi .twtr-ls, .twtr-ls-link, .twtr-ls-flag, .is-current.', 'tw-translate-plus'),
                    implode(', ', Twtr_Switcher::flag_codes())
                )); ?></p>
            </details>
        </div>
        <?php
    }

    public static function handle_save_languages() {
        if (!current_user_can(self::CAP)) {
            wp_die(esc_html__('Permessi insufficienti.', 'tw-translate-plus'));
        }
        check_admin_referer('twtr_save_languages');

        $default        = isset($_POST['default_lang']) ? sanitize_key($_POST['default_lang']) : 'it';
        $auto_translate = !empty($_POST['auto_translate']);
        $languages      = array();
        $raw       = isset($_POST['languages']) && is_array($_POST['languages']) ? wp_unslash($_POST['languages']) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- keys/values sanitized below.

        foreach ($raw as $slug => $cfg) {
            $slug = sanitize_key($slug);
            if (empty($cfg['enabled'])) {
                continue;
            }
            if (Twtr_Router::slug_collides($slug)) {
                add_settings_error('twtr', 'twtr_collision_' . $slug, sprintf(
                    __('La lingua "%s" non è stata attivata: esiste già un contenuto con slug "/%s/".', 'tw-translate-plus'),
                    $slug, $slug
                ));
                continue;
            }
            $languages[$slug] = array('published' => !empty($cfg['published']));
        }

        Twtr_Settings::update_site(array('default_lang' => $default, 'languages' => $languages, 'auto_translate' => $auto_translate));

        // A newly enabled language needs the content published before it:
        // index the site in the background (no-op when nothing was added).
        Twtr_Extractor::maybe_auto_index();

        // Install the official language packs so WP/Woo UI strings follow.
        require_once ABSPATH . 'wp-admin/includes/translation-install.php';
        foreach (array_keys($languages) as $slug) {
            $locale = Twtr_Settings::wp_locale($slug);
            if ($locale !== 'en_US' && function_exists('wp_download_language_pack') && current_user_can('install_languages')) {
                wp_download_language_pack($locale);
            }
        }

        Twtr_Cache::purge_all();
        add_settings_error('twtr', 'twtr_saved', __('Impostazioni lingue salvate.', 'tw-translate-plus'), 'success');
        set_transient('settings_errors', get_settings_errors(), 30);
        wp_safe_redirect(add_query_arg(array('page' => self::SLUG, 'tab' => 'languages', 'settings-updated' => '1'), admin_url('admin.php')));
        exit;
    }

    /* ------------------------------------------------------------ Tab: Traduzioni */

    private static function render_translations() {
        // phpcs:disable WordPress.Security.NonceVerification -- read-only filters.
        $search = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
        $locale = isset($_GET['lang']) ? sanitize_key($_GET['lang']) : '';
        $status = isset($_GET['status']) ? sanitize_key($_GET['status']) : '';
        $page   = isset($_GET['paged']) ? max(1, (int) $_GET['paged']) : 1;
        // phpcs:enable

        $result = Twtr_Storage::search(array(
            'search' => $search, 'locale' => $locale, 'status' => $status,
            'page' => $page, 'per_page' => 50,
        ));
        $total_pages = (int) ceil($result['total'] / 50);
        $langs = Twtr_Settings::extra_languages();
        ?>
        <form method="get" class="twtr-filters">
            <input type="hidden" name="page" value="<?php echo esc_attr(self::SLUG); ?>" />
            <input type="hidden" name="tab" value="translations" />
            <input type="search" name="s" value="<?php echo esc_attr($search); ?>" placeholder="<?php esc_attr_e('Cerca testo…', 'tw-translate-plus'); ?>" />
            <select name="lang">
                <option value=""><?php esc_html_e('Tutte le lingue', 'tw-translate-plus'); ?></option>
                <?php foreach ($langs as $slug) : ?>
                    <option value="<?php echo esc_attr($slug); ?>" <?php selected($locale, $slug); ?>><?php echo esc_html(Twtr_Settings::flag($slug) . ' ' . strtoupper($slug)); ?></option>
                <?php endforeach; ?>
            </select>
            <select name="status">
                <option value=""><?php esc_html_e('Tutti gli stati', 'tw-translate-plus'); ?></option>
                <option value="ready" <?php selected($status, 'ready'); ?>><?php esc_html_e('Pronte', 'tw-translate-plus'); ?></option>
                <option value="pending" <?php selected($status, 'pending'); ?>><?php esc_html_e('In elaborazione', 'tw-translate-plus'); ?></option>
                <option value="stale" <?php selected($status, 'stale'); ?>><?php esc_html_e('Da rivedere', 'tw-translate-plus'); ?></option>
                <option value="error" <?php selected($status, 'error'); ?>><?php esc_html_e('Errore', 'tw-translate-plus'); ?></option>
                <option value="manual" <?php selected($status, 'manual'); ?>><?php esc_html_e('Manuali', 'tw-translate-plus'); ?></option>
            </select>
            <?php submit_button(__('Filtra', 'tw-translate-plus'), 'secondary', '', false); ?>
            <span class="twtr-total"><?php echo esc_html(sprintf(_n('%d voce', '%d voci', $result['total'], 'tw-translate-plus'), $result['total'])); ?></span>
        </form>

        <table class="widefat striped twtr-entries">
            <thead>
                <tr>
                    <th class="twtr-col-lang"><?php esc_html_e('Lingua', 'tw-translate-plus'); ?></th>
                    <th><?php esc_html_e('Originale', 'tw-translate-plus'); ?></th>
                    <th><?php esc_html_e('Traduzione', 'tw-translate-plus'); ?></th>
                    <th class="twtr-col-state"><?php esc_html_e('Stato', 'tw-translate-plus'); ?></th>
                </tr>
            </thead>
            <tbody>
            <?php if (!$result['rows']) : ?>
                <tr><td colspan="4"><?php esc_html_e('Nessuna voce trovata. Le stringhe vengono registrate al salvataggio dei contenuti o alla prima visita delle pagine tradotte.', 'tw-translate-plus'); ?></td></tr>
            <?php endif; ?>
            <?php foreach ($result['rows'] as $row) : ?>
                <tr data-entry="<?php echo esc_attr($row->id); ?>">
                    <td><span class="twtr-flag"><?php echo esc_html(Twtr_Settings::flag($row->target_locale)); ?></span> <code><?php echo esc_html(strtoupper($row->target_locale)); ?></code></td>
                    <td class="twtr-source">
                        <div class="twtr-text"><?php echo esc_html(wp_html_excerpt(wp_strip_all_tags($row->source_text), 160, '…')); ?></div>
                        <div class="twtr-context"><code><?php echo esc_html($row->context_key); ?></code></div>
                    </td>
                    <td class="twtr-target">
                        <div class="twtr-view" tabindex="0" role="button" aria-label="<?php esc_attr_e('Modifica traduzione', 'tw-translate-plus'); ?>">
                            <?php echo esc_html(wp_html_excerpt(wp_strip_all_tags((string) $row->translated_text), 160, '…')); ?>
                            <span class="twtr-edit-hint dashicons dashicons-edit"></span>
                        </div>
                        <div class="twtr-editor" hidden>
                            <textarea rows="4"><?php echo esc_textarea((string) $row->translated_text); ?></textarea>
                            <div class="twtr-editor-actions">
                                <button type="button" class="button button-primary twtr-save"><?php esc_html_e('Salva', 'tw-translate-plus'); ?></button>
                                <button type="button" class="button twtr-cancel"><?php esc_html_e('Annulla', 'tw-translate-plus'); ?></button>
                                <?php if ($row->origin === 'manual') : ?>
                                    <button type="button" class="button-link twtr-restore"><?php echo esc_html(sprintf(
                                        /* translators: %s: translation engine name. */
                                        __('Ripristina traduzione %s', 'tw-translate-plus'),
                                        Twtr_Settings::provider_short_label()
                                    )); ?></button>
                                <?php endif; ?>
                                <?php if ($row->origin !== 'manual' || $row->status === 'stale') : ?>
                                    <button type="button" class="button-link twtr-recover"><?php esc_html_e('Recupera manuale precedente', 'tw-translate-plus'); ?></button>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php if ($row->error_message) : ?>
                            <div class="twtr-error-msg"><?php echo esc_html($row->error_message); ?></div>
                        <?php endif; ?>
                    </td>
                    <td><?php self::status_badge($row); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

        <?php if ($total_pages > 1) : ?>
            <div class="tablenav"><div class="tablenav-pages">
                <?php
                echo paginate_links(array( // phpcs:ignore WordPress.Security.EscapeOutput -- paginate_links escapes internally.
                    'base'    => add_query_arg('paged', '%#%'),
                    'format'  => '',
                    'current' => $page,
                    'total'   => $total_pages,
                ));
                ?>
            </div></div>
        <?php endif;
    }

    /**
     * @param object $row
     */
    private static function status_badge($row) {
        if ($row->origin === 'manual' && $row->status === 'stale') {
            echo '<span class="twtr-badge twtr-badge-stale">' . esc_html__('Da rivedere', 'tw-translate-plus') . '</span>';
        } elseif ($row->origin === 'manual') {
            echo '<span class="twtr-badge twtr-badge-manual">' . esc_html__('Manuale', 'tw-translate-plus') . '</span>';
        } elseif ($row->status === 'ready') {
            echo '<span class="twtr-badge twtr-badge-ready">' . esc_html(Twtr_Settings::provider_short_label($row->origin)) . '</span>';
        } elseif ($row->status === 'error') {
            echo '<span class="twtr-badge twtr-badge-error">' . esc_html__('Errore', 'tw-translate-plus') . '</span>';
        } elseif ($row->status === 'stale') {
            echo '<span class="twtr-badge twtr-badge-stale">' . esc_html__('Da rivedere', 'tw-translate-plus') . '</span>';
        } elseif (Twtr_Settings::auto_translate()) {
            echo '<span class="twtr-badge twtr-badge-pending">' . esc_html__('In elaborazione', 'tw-translate-plus') . '</span>';
        } else {
            echo '<span class="twtr-badge twtr-badge-pending">' . esc_html__('In coda — automatica spenta', 'tw-translate-plus') . '</span>';
        }
    }

    /* ----------------------------------------------------------------- Tab: Stato */

    private static function render_status() {
        global $wpdb;
        twtr_queue(); // Load the lazy queue class before referencing Twtr_Queue::HOOK.
        $counts    = Twtr_Storage::status_counts();
        $remaining = 0;
        foreach ($counts as $statuses) {
            $remaining += isset($statuses['pending']) ? $statuses['pending'] : 0;
        }
        $errors = $wpdb->get_results($wpdb->prepare(
            'SELECT target_locale, context_key, error_message, updated_at FROM ' . Twtr_Storage::entries_table() .
            " WHERE blog_id = %d AND status = 'error' ORDER BY updated_at DESC LIMIT 5",
            get_current_blog_id()
        ));
        $next_run = wp_next_scheduled(Twtr_Queue::HOOK);
        ?>
        <div class="twtr-card">
            <h2><?php esc_html_e('Coda di traduzione', 'tw-translate-plus'); ?></h2>
            <p>
                <strong><?php echo esc_html(number_format_i18n($remaining)); ?></strong>
                <?php esc_html_e('stringhe in attesa di traduzione.', 'tw-translate-plus'); ?>
                <?php if ($next_run) : ?>
                    <?php echo esc_html(sprintf(__('Prossima elaborazione: %s.', 'tw-translate-plus'), wp_date('H:i:s', $next_run))); ?>
                <?php endif; ?>
            </p>
            <p>
                <button type="button" class="button button-primary" id="twtr-process-now" <?php disabled($remaining === 0); ?>><?php esc_html_e('Processa ora', 'tw-translate-plus'); ?></button>
                <button type="button" class="button" id="twtr-retry-errors"><?php esc_html_e('Riprova gli errori', 'tw-translate-plus'); ?></button>
                <span id="twtr-status-feedback" role="status"></span>
            </p>
            <?php $missing = Twtr_Settings::engine_missing_reason(); ?>
            <?php if ($missing !== '') : ?>
                <p class="twtr-warning"><?php echo esc_html($missing); ?></p>
            <?php endif; ?>
            <?php $ws = Twtr_Worker::state(); ?>
            <p class="description">
                <?php
                if ($ws['heartbeat'] > time() - Twtr_Worker::STALE_SECONDS) {
                    esc_html_e('Traduzione in background attiva in questo momento.', 'tw-translate-plus');
                } elseif ($ws['paused_until'] > time()) {
                    echo esc_html(sprintf(
                        /* translators: %s: date and time. */
                        __('Traduzione in background in pausa fino a %s (limite giornaliero o motore in errore: riprende da sola).', 'tw-translate-plus'),
                        wp_date(get_option('date_format') . ' H:i', $ws['paused_until'])
                    ));
                } else {
                    esc_html_e('Traduzione in background in attesa di nuovo lavoro: riparte da sola quando ci sono testi in coda.', 'tw-translate-plus');
                }
                if (!empty($ws['last_run']['at'])) {
                    echo ' ' . esc_html(sprintf(
                        /* translators: 1: date and time, 2: strings translated. */
                        __('Ultimo ciclo: %1$s, %2$s testi tradotti.', 'tw-translate-plus'),
                        wp_date('H:i', (int) $ws['last_run']['at']),
                        number_format_i18n((int) $ws['last_run']['processed'])
                    ));
                }
                ?>
            </p>
            <?php $mem = get_option('twtr_memory_stats', array()); ?>
            <?php if (!empty($mem['reused'])) : ?>
                <p class="description"><?php echo esc_html(sprintf(
                    /* translators: 1: texts reused, 2: characters saved. */
                    __('Memoria di traduzione: %1$s testi identici riusati senza pagarli di nuovo (%2$s caratteri risparmiati).', 'tw-translate-plus'),
                    number_format_i18n((int) $mem['reused']),
                    number_format_i18n((int) $mem['chars'])
                )); ?></p>
            <?php endif; ?>
            <?php if ($ws['loopback'] === 'broken') : ?>
                <p class="twtr-warning"><?php esc_html_e('Il server blocca le richieste del sito verso sé stesso: la coda avanza solo durante le visite al sito, più lentamente. Se possibile, chiedi all\'hosting di consentire le richieste "loopback" (le usa anche WordPress per il cron e lo Stato di salute del sito).', 'tw-translate-plus'); ?></p>
            <?php endif; ?>
            <p class="description">
                <?php
                $limit = Twtr_Settings::daily_char_limit();
                echo esc_html(sprintf(
                    /* translators: 1: character count, 2: daily limit, 3: translation engine name. */
                    __('Caratteri inviati oggi dalla chiave di questo sito: %1$s su un limite di %2$s. Motore di questo sito: %3$s.', 'tw-translate-plus'),
                    number_format_i18n(Twtr_Settings::usage_today()),
                    $limit > 0 ? number_format_i18n($limit) : __('nessun limite', 'tw-translate-plus'),
                    Twtr_Settings::provider_label()
                )); ?>
            </p>
        </div>

        <?php $totals = Twtr_Extractor::index_totals(); $extra = Twtr_Settings::extra_languages(); ?>
        <div class="twtr-card">
            <h2><?php esc_html_e('Indicizzazione del sito', 'tw-translate-plus'); ?></h2>
            <p><?php esc_html_e('L\'indicizzazione è automatica: i contenuti nuovi o modificati entrano in coda quando vengono salvati, e il sito intero viene riletto in background quando attivi una lingua e poi una volta a settimana (per i contenuti pubblicati prima, importati o modificati senza passare dal salvataggio). Titoli, testi, estratti, descrizioni SEO e termini vengono letti e le stringhe mancanti messe in coda. Le stringhe del tema vengono scoperte alla prima visita. Il pulsante serve solo se vuoi rileggere tutto subito.', 'tw-translate-plus'); ?></p>
            <?php $istate = Twtr_Extractor::index_state(); ?>
            <p>
                <?php if ($istate['running']) : ?>
                    <span class="twtr-badge twtr-badge-pending"><?php esc_html_e('Indicizzazione automatica in corso', 'tw-translate-plus'); ?></span>
                    <?php echo esc_html(sprintf(
                        /* translators: 1: phase (contenuti/termini), 2: items read so far. */
                        __('%1$s: %2$s letti finora.', 'tw-translate-plus'),
                        $istate['phase'] === 'terms' ? __('Termini', 'tw-translate-plus') : __('Contenuti', 'tw-translate-plus'),
                        number_format_i18n((int) $istate['offset'])
                    )); ?>
                <?php elseif ($istate['finished']) : ?>
                    <span class="twtr-badge twtr-badge-ready"><?php esc_html_e('Indicizzato', 'tw-translate-plus'); ?></span>
                    <?php echo esc_html(sprintf(
                        /* translators: %s: date and time. */
                        __('Ultima lettura completa del sito: %s.', 'tw-translate-plus'),
                        wp_date(get_option('date_format') . ' H:i', (int) $istate['finished'])
                    )); ?>
                <?php endif; ?>
            </p>
            <p>
                <button type="button" class="button button-primary" id="twtr-index-site" <?php disabled(!$extra); ?>><?php esc_html_e('Indicizza tutto il sito', 'tw-translate-plus'); ?></button>
                <span id="twtr-index-feedback" role="status"></span>
            </p>
            <p class="description">
                <?php echo esc_html(sprintf(__('%1$s contenuti pubblicati e %2$s termini da esaminare.', 'tw-translate-plus'), number_format_i18n($totals['posts']), number_format_i18n($totals['terms']))); ?>
                <?php if (!$extra) : ?>
                    <?php esc_html_e('Nessuna lingua aggiuntiva attiva.', 'tw-translate-plus'); ?>
                <?php elseif (!Twtr_Settings::auto_translate()) : ?>
                    <?php esc_html_e('Traduzione automatica spenta: le stringhe indicizzate restano in coda finché non premi «Processa ora».', 'tw-translate-plus'); ?>
                <?php else : ?>
                    <?php esc_html_e('Le stringhe in coda vengono tradotte in background dal cron, a blocchi, entro il limite giornaliero di caratteri.', 'tw-translate-plus'); ?>
                <?php endif; ?>
            </p>
        </div>

        <?php if ($errors) : ?>
        <div class="twtr-card">
            <h2><?php esc_html_e('Ultimi errori', 'tw-translate-plus'); ?></h2>
            <table class="widefat striped">
                <thead><tr><th><?php esc_html_e('Lingua', 'tw-translate-plus'); ?></th><th><?php esc_html_e('Contesto', 'tw-translate-plus'); ?></th><th><?php esc_html_e('Errore', 'tw-translate-plus'); ?></th><th><?php esc_html_e('Quando', 'tw-translate-plus'); ?></th></tr></thead>
                <tbody>
                <?php foreach ($errors as $err) : ?>
                    <tr>
                        <td><code><?php echo esc_html(strtoupper($err->target_locale)); ?></code></td>
                        <td><code><?php echo esc_html($err->context_key); ?></code></td>
                        <td><?php echo esc_html($err->error_message); ?></td>
                        <td><?php echo esc_html($err->updated_at); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif;
    }

    /* ---------------------------------------------------------------------- AJAX */

    /**
     * Common AJAX guard.
     */
    /* ---------------------------------------------------------------- Tab: Migrazione WPML */

    private static function render_wpml() {
        $sum      = Twtr_Wpml::summary();
        $labels   = array(
            'post_page' => __('Pagine', 'tw-translate-plus'), 'post_post' => __('Articoli', 'tw-translate-plus'), 'post_product' => __('Prodotti', 'tw-translate-plus'),
            'post_product_variation' => __('Varianti prodotto', 'tw-translate-plus'), 'post_elementor_library' => __('Modelli Elementor (header, footer…)', 'tw-translate-plus'),
            'post_nav_menu_item' => __('Voci di menu', 'tw-translate-plus'), 'post_attachment' => __('Media', 'tw-translate-plus'), 'tax_product_cat' => __('Categorie prodotto', 'tw-translate-plus'),
            'tax_category' => __('Categorie', 'tw-translate-plus'),
        );
        $state    = (array) $sum['state'];
        $wpml_on  = Twtr_Router::wpml_active();
        ?>
        <div class="twtr-card twtr-wpml">
            <h2><?php esc_html_e('Migrazione da WPML', 'tw-translate-plus'); ?></h2>
            <p><?php esc_html_e('Porta in tW Translate tutte le traduzioni già fatte e corrette in WPML: nessuna viene rifatta dal motore di traduzione. Gli indirizzi tradotti di WPML restano uguali, quindi il posizionamento su Google non cambia.', 'tw-translate-plus'); ?></p>
            <ol class="twtr-steps">
                <li><?php esc_html_e('Lascia WPML attivo e premi «Importa da WPML». Le lingue di tW Translate vengono impostate come in WPML.', 'tw-translate-plus'); ?></li>
                <li><?php esc_html_e('A import finito disattiva WPML (e WooCommerce Multilingual, String Translation, Media Translation). Da quel momento tW Translate serve le lingue.', 'tw-translate-plus'); ?></li>
                <li><?php esc_html_e('Controlla le pagine nelle varie lingue. Solo dopo elimina le pagine, i prodotti e le categorie duplicate create da WPML.', 'tw-translate-plus'); ?></li>
            </ol>

            <table class="widefat striped twtr-wpml-table">
                <tbody>
                    <tr><th><?php esc_html_e('Lingua principale', 'tw-translate-plus'); ?></th><td><code><?php echo esc_html($sum['default']); ?></code></td></tr>
                    <tr><th><?php esc_html_e('Lingue', 'tw-translate-plus'); ?></th><td><?php echo esc_html(implode(', ', $sum['languages'])); ?>
                        <?php if ($sum['unsupported']) : ?><br><span class="twtr-warn"><?php echo esc_html(sprintf(__('Non disponibili in tW Translate (saltate): %s', 'tw-translate-plus'), implode(', ', $sum['unsupported']))); ?></span><?php endif; ?></td></tr>
                    <?php foreach ((array) $sum['types'] as $t) :
                        if ((int) $t['translations'] === 0 || !isset($labels[$t['element_type']])) {
                            continue;
                        } ?>
                        <tr><th><?php echo esc_html($labels[$t['element_type']]); ?></th><td><?php echo esc_html(sprintf(__('%1$d originali, %2$d traduzioni', 'tw-translate-plus'), $t['originals'], $t['translations'])); ?></td></tr>
                    <?php endforeach; ?>
                    <tr><th><?php esc_html_e('Stringhe tradotte (String Translation)', 'tw-translate-plus'); ?></th><td><?php echo esc_html(number_format_i18n($sum['strings'])); ?></td></tr>
                    <tr><th><?php esc_html_e('Già importate in tW Translate', 'tw-translate-plus'); ?></th><td id="twtr-wpml-imported"><?php echo esc_html(number_format_i18n($sum['imported_entries'])); ?></td></tr>
                </tbody>
            </table>

            <p class="twtr-wpml-actions">
                <button type="button" class="button button-primary button-hero" id="twtr-wpml-start" <?php disabled(!$wpml_on); ?>><?php echo esc_html($sum['imported_entries'] ? __('Importa di nuovo da WPML', 'tw-translate-plus') : __('Importa da WPML', 'tw-translate-plus')); ?></button>
                <?php if ($sum['imported_entries']) : ?>
                    <button type="button" class="button button-link-delete" id="twtr-wpml-undo"><?php esc_html_e('Annulla l\'import', 'tw-translate-plus'); ?></button>
                <?php endif; ?>
            </p>
            <?php if (!$wpml_on) : ?>
                <p class="description"><?php esc_html_e('WPML non è attivo: l\'import va fatto con WPML ancora attivo (serve per calcolare gli indirizzi).', 'tw-translate-plus'); ?></p>
            <?php endif; ?>

            <div id="twtr-wpml-progress" hidden>
                <div class="twtr-bar"><span style="width:0%"></span></div>
                <p id="twtr-wpml-status"></p>
            </div>
            <div id="twtr-wpml-report">
                <?php if (!empty($state['stats'])) : self::render_wpml_report($state); endif; ?>
            </div>
        </div>
        <?php
    }

    /** Result of the last import. */
    private static function render_wpml_report($state) {
        $names = array('posts' => __('Contenuti', 'tw-translate-plus'), 'terms' => __('Categorie e attributi', 'tw-translate-plus'), 'media' => __('Media', 'tw-translate-plus'), 'strings' => __('Stringhe', 'tw-translate-plus'), 'redirects' => __('Indirizzi', 'tw-translate-plus'));
        echo '<h3>' . esc_html__('Risultato dell\'ultimo import', 'tw-translate-plus') . '</h3><ul class="twtr-wpml-result">';
        foreach ($names as $k => $label) {
            $s = (array) ($state['stats'][$k] ?? array());
            if (!$s) {
                continue;
            }
            if ('redirects' === $k) {
                $txt = sprintf(__('%1$d indirizzi controllati, %2$d uguali a WPML, %3$d redirect 301 creati', 'tw-translate-plus'), $s['checked'] ?? 0, $s['same'] ?? 0, $s['redirects'] ?? 0);
            } else {
                $txt = sprintf(__('%1$d traduzioni importate', 'tw-translate-plus'), $s['entries'] ?? 0) . (!empty($s['slugs']) ? ' · ' . sprintf(__('%d indirizzi tradotti', 'tw-translate-plus'), $s['slugs']) : '');
            }
            echo '<li><strong>' . esc_html($label) . ':</strong> ' . esc_html($txt) . '</li>';
        }
        echo '</ul>';
        $warn = array_merge((array) ($state['stats']['posts']['no_default_list'] ?? array()), (array) ($state['stats']['posts']['mismatch_list'] ?? array()));
        if ($warn) {
            echo '<details><summary>' . esc_html(sprintf(__('%d note da controllare', 'tw-translate-plus'), count($warn))) . '</summary><ul class="twtr-wpml-notes">';
            foreach ($warn as $w) {
                echo '<li>' . esc_html($w) . '</li>';
            }
            echo '</ul><p class="description">' . esc_html__('«no original»: contenuto che esiste solo in un\'altra lingua, non importato. «whole text kept»: la traduzione ha paragrafi diversi dall\'originale ed è stata tenuta intera.', 'tw-translate-plus') . '</p></details>';
        }
    }

    public static function ajax_wpml_step() {
        self::ajax_guard();
        require_once TWTR_DIR . 'includes/class-twtr-wpml.php';
        $step   = isset($_POST['step']) ? sanitize_key(wp_unslash($_POST['step'])) : '';
        $offset = isset($_POST['offset']) ? max(0, (int) $_POST['offset']) : 0;
        if ($step === 'configure') {
            $c = Twtr_Wpml::configure_languages();
            wp_send_json_success(array('done' => true, 'next' => 0, 'total' => 1, 'message' => sprintf(__('Lingue impostate: %1$s principale, poi %2$s', 'tw-translate-plus'), $c['default'], implode(', ', $c['extra']))));
        }
        if (!in_array($step, Twtr_Wpml::steps(), true)) {
            wp_send_json_error(array('message' => __('Passo sconosciuto.', 'tw-translate-plus')), 400);
        }
        if (function_exists('set_time_limit')) {
            @set_time_limit(120); // phpcs:ignore WordPress.PHP.NoSilencedErrors
        }
        $res = Twtr_Wpml::run_step($step, $offset, false);
        if ($res['done']) {
            ob_start();
            self::render_wpml_report((array) get_option(Twtr_Wpml::STATE_OPTION, array()));
            $res['report']   = ob_get_clean();
            $res['imported'] = number_format_i18n(Twtr_Storage::origin_entries(Twtr_Wpml::ORIGIN));
        }
        wp_send_json_success($res);
    }

    public static function ajax_wpml_undo() {
        self::ajax_guard();
        require_once TWTR_DIR . 'includes/class-twtr-wpml.php';
        $n = Twtr_Wpml::undo();
        wp_send_json_success(array('message' => sprintf(__('Rimosse %d traduzioni importate da WPML.', 'tw-translate-plus'), $n)));
    }

    private static function ajax_guard() {
        check_ajax_referer('twtr_admin');
        if (!current_user_can(self::CAP)) {
            wp_send_json_error(array('message' => __('Permessi insufficienti.', 'tw-translate-plus')), 403);
        }
    }

    public static function ajax_save_entry() {
        self::ajax_guard();
        $id   = isset($_POST['entry_id']) ? (int) $_POST['entry_id'] : 0;
        $text = isset($_POST['text']) ? wp_kses_post(wp_unslash($_POST['text'])) : '';
        $entry = $id ? Twtr_Storage::get_entry($id) : null;
        if (!$entry) {
            wp_send_json_error(array('message' => __('Voce non trovata.', 'tw-translate-plus')), 404);
        }
        Twtr_Storage::save_manual($id, $text);
        Twtr_Resolver::flush_group($entry->target_locale, $entry->context_key);
        Twtr_Cache::purge_for_context($entry->context_key, $entry->target_locale);
        wp_send_json_success(array('message' => __('Traduzione manuale salvata.', 'tw-translate-plus')));
    }

    public static function ajax_restore_google() {
        self::ajax_guard();
        $id    = isset($_POST['entry_id']) ? (int) $_POST['entry_id'] : 0;
        $entry = $id ? Twtr_Storage::get_entry($id) : null;
        if (!$entry) {
            wp_send_json_error(array('message' => __('Voce non trovata.', 'tw-translate-plus')), 404);
        }
        Twtr_Storage::restore_machine($id);
        Twtr_Resolver::flush_group($entry->target_locale, $entry->context_key);
        twtr_queue();
        Twtr_Queue::schedule();
        wp_send_json_success(array('message' => sprintf(
            /* translators: %s: translation engine name. */
            __('La traduzione %s verrà rigenerata a breve.', 'tw-translate-plus'),
            Twtr_Settings::provider_short_label()
        )));
    }

    public static function ajax_recover_previous() {
        self::ajax_guard();
        $id    = isset($_POST['entry_id']) ? (int) $_POST['entry_id'] : 0;
        $entry = $id ? Twtr_Storage::get_entry($id) : null;
        if (!$entry) {
            wp_send_json_error(array('message' => __('Voce non trovata.', 'tw-translate-plus')), 404);
        }
        $previous = Twtr_Storage::previous_manual($entry);
        if (!$previous || $previous->translated_text === null) {
            wp_send_json_error(array('message' => __('Nessuna traduzione manuale precedente disponibile.', 'tw-translate-plus')), 404);
        }
        wp_send_json_success(array('text' => $previous->translated_text));
    }

    public static function ajax_process_now() {
        self::ajax_guard();
        twtr_queue();
        $result = Twtr_Queue::process();
        wp_send_json_success(array(
            'message' => sprintf(
                __('%1$d tradotte, %2$d errori, %3$d rimanenti. %4$s', 'tw-translate-plus'),
                $result['processed'], $result['errors'], $result['remaining'], $result['message']
            ),
        ));
    }

    /**
     * One step of the full-site indexing loop (see Twtr_Extractor::index_batch).
     */
    public static function ajax_index_site() {
        self::ajax_guard();
        if (!Twtr_Settings::extra_languages()) {
            wp_send_json_error(array('message' => __('Nessuna lingua aggiuntiva attiva: attivane una nel tab Lingue prima di indicizzare.', 'tw-translate-plus')), 400);
        }
        $phase  = (isset($_POST['phase']) && $_POST['phase'] === 'terms') ? 'terms' : 'posts';
        $offset = isset($_POST['offset']) ? max(0, (int) $_POST['offset']) : 0;
        twtr_queue();
        $before = Twtr_Queue::remaining();
        $result = Twtr_Extractor::index_batch($phase, $offset, 20);
        $result['queued'] = max(0, Twtr_Queue::remaining() - $before);
        wp_send_json_success($result);
    }

    public static function ajax_retry_errors() {
        self::ajax_guard();
        $reset = Twtr_Storage::retry_errors();
        if ($reset > 0) {
            twtr_queue();
            Twtr_Queue::schedule();
        }
        wp_send_json_success(array(
            'message' => sprintf(__('%d voci rimesse in coda.', 'tw-translate-plus'), $reset),
        ));
    }
}
