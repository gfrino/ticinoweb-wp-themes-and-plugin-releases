<?php
/**
 * Modello dei contenuti: tutto cio' che e' del cliente sta nel database.
 *
 * Testi, collegamenti, icone e simbolo del gruppo sono theme_mod del sottosito,
 * modificabili in Aspetto → Personalizza → Tenconi Group con l'anteprima
 * accanto. Nel codice ci sono solo le chiavi: con un database vuoto i blocchi
 * restano nascosti e l'amministratore vede un invito a compilarli.
 *
 * Ogni testo passa da ticinoweb_frontend_text() del parent, cosi' tW Translate
 * (o WPML) lo puo' tradurre se un giorno il sito diventa multilingua.
 *
 * @package tenconigroup
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Gruppi di societa' e numero di posti disponibili in ciascuno.
 *
 * @return array<string,int>
 */
function tg_company_groups() {
	return array(
		'home' => 2, // Homepage: le due societa' con sito proprio.
		'soc'  => 4, // Pagina «Le societa'»: oggi due, posti liberi per il futuro.
	);
}

/**
 * Icone disponibili per una societa' (chiave => etichetta nel Personalizza).
 *
 * @return array<string,string>
 */
function tg_icon_choices() {
	return array(
		''              => __( 'Nessuna icona', 'tenconigroup' ),
		'simbolo'       => __( 'Simbolo del gruppo (dal campo «Simbolo»)', 'tenconigroup' ),
		'idromeccanica' => __( 'Turbina – energia idroelettrica', 'tenconigroup' ),
		'immobiliare'   => __( 'Edificio – immobili', 'tenconigroup' ),
		'rail'          => __( 'Binari – infrastruttura ferroviaria', 'tenconigroup' ),
	);
}

/**
 * Testo dal Personalizza, passato al filtro di traduzione del parent.
 *
 * @param string $key Nome del theme_mod.
 * @return string Testo grezzo (da escapare al momento della stampa).
 */
function tg_text( $key ) {
	$value = trim( (string) get_theme_mod( $key, '' ) );
	if ( '' === $value ) {
		return '';
	}
	return function_exists( 'ticinoweb_frontend_text' ) ? (string) ticinoweb_frontend_text( $value, 'tenconigroup:' . $key ) : $value;
}

/**
 * URL dal Personalizza, passato al filtro URL del parent (lingua corrente).
 *
 * @param string $key Nome del theme_mod.
 * @return string
 */
function tg_url( $key ) {
	$value = trim( (string) get_theme_mod( $key, '' ) );
	if ( '' === $value ) {
		return '';
	}
	return function_exists( 'ticinoweb_frontend_url' ) ? (string) ticinoweb_frontend_url( $value, 'tenconigroup:' . $key ) : $value;
}

/**
 * Le societa' compilate di un gruppo, nell'ordine dei posti.
 *
 * Un posto senza nome non esiste: si svuota il nome per togliere una societa'.
 *
 * @param string $group 'home' oppure 'soc'.
 * @return array<int,array<string,mixed>>
 */
function tg_companies( $group ) {
	$groups = tg_company_groups();
	if ( ! isset( $groups[ $group ] ) ) {
		return array();
	}
	$out = array();
	for ( $i = 1; $i <= $groups[ $group ]; $i++ ) {
		$p    = "tg_{$group}_{$i}_";
		$name = tg_text( $p . 'name' );
		if ( '' === $name ) {
			continue;
		}
		$out[] = array(
			'slot'  => $i,
			'name'  => $name,
			'meta'  => tg_text( $p . 'meta' ),
			'desc'  => tg_text( $p . 'desc' ),
			'url'   => tg_url( $p . 'url' ),
			'icon'  => (string) get_theme_mod( $p . 'icon', '' ),
			'image' => absint( get_theme_mod( $p . 'image', 0 ) ),
		);
	}
	return $out;
}

/**
 * Dominio leggibile di un indirizzo, per la riga «esempio.ch» del riquadro.
 *
 * @param string $url Indirizzo completo.
 * @return string
 */
function tg_url_label( $url ) {
	$host = (string) wp_parse_url( $url, PHP_URL_HOST );
	return preg_replace( '/^www\./i', '', $host );
}

/**
 * Indirizzo del Personalizza per un pannello o una sezione.
 *
 * @param string $section ID della sezione del Personalizza.
 * @return string
 */
function tg_customize_link( $section ) {
	global $wp;
	$current = ( $wp instanceof WP && is_string( $wp->request ) ) ? home_url( user_trailingslashit( $wp->request ) ) : home_url( '/' );
	return add_query_arg(
		array(
			'autofocus[section]' => $section,
			'url'                => rawurlencode( $current ),
		),
		admin_url( 'customize.php' )
	);
}

/**
 * Avviso visibile solo agli amministratori quando un blocco e' vuoto.
 *
 * Il visitatore non vede nulla; chi gestisce il sito vede dove compilare.
 *
 * @param string $what    Cosa manca, in parole semplici.
 * @param string $section Sezione del Personalizza da aprire.
 */
function tg_admin_hint( $what, $section ) {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		return;
	}
	printf(
		'<p class="tg-hint">%1$s <a href="%2$s">%3$s</a></p>',
		esc_html( $what ),
		esc_url( tg_customize_link( $section ) ),
		esc_html__( 'Compila in Aspetto → Personalizza → Tenconi Group', 'tenconigroup' )
	);
}
