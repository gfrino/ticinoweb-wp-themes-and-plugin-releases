<?php
/**
 * Impostazioni del tema, asset e convivenza con il parent.
 *
 * @package tenconigroup
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Supporti del tema e posizione del menu.
 *
 * Un solo menu, «Navigazione principale»: le voci si scelgono in
 * Aspetto → Menu, quindi aggiungere o rinominare una pagina non richiede codice.
 */
function tg_setup() {
	load_child_theme_textdomain( 'tenconigroup', TG_DIR . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' ) );
	register_nav_menus(
		array(
			'tg-principale' => __( 'Navigazione principale', 'tenconigroup' ),
		)
	);
}
add_action( 'after_setup_theme', 'tg_setup' );

/**
 * Hook del parent che su questo sito non servono.
 *
 * - Il rinvio delle pagine inesistenti alla home nasconderebbe gli errori di
 *   collegamento e confonde i motori di ricerca: qui una pagina inesistente
 *   risponde 404 con la sua pagina.
 * - Lo sfondo di pagina del parent non fa parte di questo design.
 */
function tg_neutralize_parent_hooks() {
	remove_action( 'template_redirect', 'ticinoweb_redirect_404_to_home' );
	remove_action( 'wp_head', 'ticinoweb_apply_page_background_image' );
}
add_action( 'after_setup_theme', 'tg_neutralize_parent_hooks' );

/**
 * Asset del child; via il font Poppins e lo script generico del parent.
 *
 * Il sito usa lo stesso stack di sistema del sito Tenconi SA (Helvetica Neue
 * dove c'e'): nessun font scaricato da terzi, nessun ritardo di caricamento.
 * Il CSS e' versionato con la versione del child, cosi' a ogni rilascio il
 * browser prende il foglio nuovo.
 */
function tg_enqueue_assets() {
	$styles = wp_styles();
	if ( isset( $styles->registered['ticinoweb-ai-style'] ) ) {
		$styles->registered['ticinoweb-ai-style']->deps = array_values(
			array_diff( (array) $styles->registered['ticinoweb-ai-style']->deps, array( 'poppins-font' ) )
		);
	}
	wp_dequeue_style( 'poppins-font' );
	wp_deregister_style( 'poppins-font' );
	wp_dequeue_script( 'ticinoweb-ai-main' );
	wp_deregister_script( 'ticinoweb-ai-main' );

	wp_enqueue_style( 'tenconigroup', TG_URI . '/assets/css/group.css', array(), TG_VERSION );
}
add_action( 'wp_enqueue_scripts', 'tg_enqueue_assets', 20 );

/**
 * Toglie il preconnect a Google Fonts che il parent stampa in wp_head con una
 * closure (non rimovibile per nome): il font non si usa piu', il collegamento
 * anticipato sarebbe una richiesta inutile verso terzi.
 */
function tg_remove_parent_font_preconnect() {
	global $wp_filter;
	if ( empty( $wp_filter['wp_head'] ) || ! $wp_filter['wp_head'] instanceof WP_Hook || empty( $wp_filter['wp_head']->callbacks[0] ) ) {
		return;
	}
	$parent_file = wp_normalize_path( get_template_directory() . '/functions.php' );
	foreach ( $wp_filter['wp_head']->callbacks[0] as $cb ) {
		if ( empty( $cb['function'] ) || ! $cb['function'] instanceof Closure ) {
			continue;
		}
		try {
			$ref = new ReflectionFunction( $cb['function'] );
		} catch ( ReflectionException $e ) {
			continue;
		}
		if ( wp_normalize_path( (string) $ref->getFileName() ) === $parent_file ) {
			remove_action( 'wp_head', $cb['function'], 0 );
		}
	}
}
add_action( 'after_setup_theme', 'tg_remove_parent_font_preconnect' );

/*
 * Rilevatore di emoji del core: 14 KB in <head> per una funzione che i browser
 * attuali fanno da soli. Le emoji nei testi restano visibili.
 */
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
remove_action( 'admin_print_styles', 'print_emoji_styles' );

/*
 * sizes="auto" del core: con la sua regola contain-intrinsic-size 3000x1500 le
 * immagini lazy in contenitori senza proporzione fissa si piantano a 1500 px.
 */
add_filter( 'wp_img_tag_add_auto_sizes', '__return_false' );

/**
 * Classe sul body per il CSS del tema (tutto il foglio e' sotto .tg).
 *
 * @param string[] $classes Classi del body.
 * @return string[]
 */
function tg_body_class( $classes ) {
	$classes[] = 'tg';
	return $classes;
}
add_filter( 'body_class', 'tg_body_class' );
