<?php
/**
 * Template Name: Le società
 *
 * Pagina delle altre societa' del gruppo. Stessa grammatica dei riquadri della
 * homepage (segno, nome, descrizione, un filetto che separa) ma su campo chiaro
 * e senza essere cliccabile, perche' queste societa' non hanno un sito: e' una
 * scheda, non un pulsante. Societa' e testi vengono dal Personalizza; il
 * titolo e' quello della pagina.
 *
 * @package tenconigroup
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$tg_intro     = tg_text( 'tg_soc_intro' );
$tg_companies = tg_companies( 'soc' );
$tg_label     = tg_text( 'tg_hero_label' );
?>

<?php while ( have_posts() ) : ?>
	<?php the_post(); ?>
	<section class="tg-page-hd" aria-labelledby="tg-page-title">
		<div class="tg-wrap tg-page-hd__in">
			<?php if ( '' !== $tg_label ) : ?>
				<p class="tg-label"><?php echo esc_html( $tg_label ); ?></p>
			<?php endif; ?>
			<h1 id="tg-page-title" class="tg-page-hd__title"><?php the_title(); ?></h1>
			<?php if ( '' !== $tg_intro ) : ?>
				<p class="tg-page-hd__text"><?php echo nl2br( esc_html( $tg_intro ) ); ?></p>
			<?php endif; ?>
		</div>
	</section>
<?php endwhile; ?>

<section class="tg-sheets-wrap" aria-label="<?php esc_attr_e( 'Società', 'tenconigroup' ); ?>">
	<div class="tg-wrap">
		<?php if ( empty( $tg_companies ) ) : ?>
			<?php tg_admin_hint( __( 'Nessuna società in questa pagina.', 'tenconigroup' ), 'tg_sec_soc' ); ?>
		<?php else : ?>
			<ul class="tg-sheets tg-sheets--<?php echo (int) min( 2, count( $tg_companies ) ); ?>">
				<?php foreach ( $tg_companies as $tg_c ) : ?>
					<li class="tg-sheet">
						<span class="tg-sheet__mark"><?php tg_the_company_mark( $tg_c, 'medium' ); ?></span>
						<h2 class="tg-sheet__name"><?php echo esc_html( $tg_c['name'] ); ?></h2>
						<?php if ( '' !== $tg_c['meta'] ) : ?>
							<p class="tg-sheet__meta"><?php echo esc_html( $tg_c['meta'] ); ?></p>
						<?php endif; ?>
						<?php if ( '' !== $tg_c['desc'] ) : ?>
							<p class="tg-sheet__desc"><?php echo nl2br( esc_html( $tg_c['desc'] ) ); ?></p>
						<?php endif; ?>
						<?php if ( '' !== $tg_c['url'] ) : ?>
							<p class="tg-sheet__link"><a href="<?php echo esc_url( $tg_c['url'] ); ?>"><?php echo esc_html( tg_url_label( $tg_c['url'] ) ); ?></a></p>
						<?php endif; ?>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</div>
</section>

<?php
get_footer();
