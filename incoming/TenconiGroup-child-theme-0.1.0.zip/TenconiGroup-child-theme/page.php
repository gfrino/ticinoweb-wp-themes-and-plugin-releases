<?php
/**
 * Pagina generica (es. protezione dei dati, se un giorno verra' aggiunta).
 *
 * @package tenconigroup
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();
	?>
	<section class="tg-page-hd" aria-labelledby="tg-page-title">
		<div class="tg-wrap tg-page-hd__in">
			<h1 id="tg-page-title" class="tg-page-hd__title"><?php the_title(); ?></h1>
		</div>
	</section>
	<div class="tg-wrap">
		<div class="tg-prose"><?php the_content(); ?></div>
	</div>
	<?php
endwhile;

get_footer();
