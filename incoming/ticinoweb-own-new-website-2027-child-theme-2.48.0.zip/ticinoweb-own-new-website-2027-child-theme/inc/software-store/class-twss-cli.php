<?php
if (!defined('ABSPATH')) {
    exit;
}

/** wp tw-store sync|list|link|license|license-test */
class Twss_Cli {
    /**
     * Sincronizza le release con i prodotti.
     *
     * ## OPTIONS
     * [<slug>]
     * : Solo questo plugin.
     * [--dry-run]
     * : Mostra cosa farebbe, senza scrivere.
     * [--force]
     * : Rilegge tutte le release e rielabora anche le versioni già viste.
     */
    public function sync($args, $assoc) {
        $rows = Twss_Sync::run(array(
            'dry' => isset($assoc['dry-run']), 'force' => isset($assoc['force']), 'reprocess' => isset($assoc['force']),
            'slug' => isset($args[0]) ? $args[0] : '',
        ));
        if (is_wp_error($rows)) {
            WP_CLI::error($rows->get_error_message());
        }
        $rows ? WP_CLI\Utils\format_items('table', $rows, array('slug', 'version', 'action', 'notes')) : WP_CLI::success('Nulla da fare.');
    }

    /** Aggiorna banner e storico delle versioni di tutti i prodotti (senza toccare testi e prezzi). */
    public function refresh() {
        $rows = Twss_Sync::refresh();
        is_wp_error($rows) ? WP_CLI::error($rows->get_error_message()) : WP_CLI\Utils\format_items('table', $rows, array('slug', 'versions', 'banner'));
    }

    /** Elenca i plugin noti e il loro prodotto. */
    public function list_() {
        $rows = array();
        foreach (Twss_Settings::state() as $slug => $st) {
            $rows[] = array('slug' => $slug, 'type' => $st['type'], 'version' => $st['version'] ?? '', 'product' => $st['product_id'] ?? '');
        }
        WP_CLI\Utils\format_items('table', $rows, array('slug', 'type', 'version', 'product'));
    }

    /**
     * Collega un prodotto esistente a uno slug (testi e prezzo restano a mano).
     *
     * ## OPTIONS
     * <slug>
     * <product_id>
     */
    public function link($args) {
        Twss_Product::link($args[0], (int) $args[1]) ? WP_CLI::success('Collegato.') : WP_CLI::error('Prodotto non trovato.');
    }

    /**
     * Chiede a Odoo le chiavi di licenza mancanti di un ordine completato (es. dopo che i tentativi automatici
     * sono finiti) e le manda al cliente con una nota dell'ordine.
     *
     * ## OPTIONS
     * <order>
     * : ID o numero dell'ordine.
     */
    public function license($args) {
        $order = wc_get_order((int) $args[0]);
        if (!$order) {
            WP_CLI::error('Ordine non trovato.');
        }
        if (!Twss_Licenses::plugin_items($order)) {
            WP_CLI::error('Nell\'ordine non ci sono plugin in vendita.');
        }
        $res = Twss_Licenses::issue($order);
        if (is_wp_error($res)) {
            WP_CLI::error($res->get_error_message());
        }
        if (!$res) {
            WP_CLI::success('Le chiavi c\'erano già.');
            return;
        }
        $order->add_order_note(__('Ecco la chiave di licenza del tuo acquisto:', 'ticinoweb-child-theme') . "\n" . implode("\n", $res) . "\n"
            . __('Incollala nelle impostazioni del plugin: il sito si attiva da solo. La trovi anche in Il mio account → Ordini.', 'ticinoweb-child-theme'), 1);
        WP_CLI::success(sprintf('%d chiavi create e mandate al cliente.', count($res)));
    }

    /**
     * Manda a Odoo l'elenco dei plugin in vendita (GestaClient → Plugin WordPress → Plugin).
     *
     * @subcommand license-catalog
     */
    public function license_catalog() {
        $res = Twss_Licenses::push_catalog();
        is_wp_error($res) ? WP_CLI::error($res->get_error_message()) : WP_CLI::success(sprintf('%d nuovi, %d aggiornati, %d non più in vendita.', $res['created'] ?? 0, $res['updated'] ?? 0, $res['archived'] ?? 0));
    }

    /**
     * Prova il collegamento firmato con Odoo (nessun effetto).
     *
     * @subcommand license-test
     */
    public function license_test() {
        $res = Twss_Licenses::test();
        is_wp_error($res) ? WP_CLI::error($res->get_error_message()) : WP_CLI::success('Odoo risponde e accetta la firma.');
    }
}
WP_CLI::add_command('tw-store', 'Twss_Cli', array('shortdesc' => 'tW Software Store'));
