<?php
/**
 * printf-style placeholders (%s, %d, %1$s…) inside translatable strings.
 *
 * Themes and plugins hand the translated text to sprintf(): a translation
 * that loses or alters a placeholder ("%d min" → "%д мин", the Cyrillic
 * letter) makes PHP stop with a fatal error and the whole page answers 500.
 * This class keeps placeholders out of the engine's reach, repairs the
 * manglings engines are known to produce and tells when a translation can
 * no longer be used.
 *
 * Pure functions, no WordPress dependency (see tests/placeholders-test.php).
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Placeholders {

    /**
     * A placeholder: %s, %d, %f, %u, optionally numbered (%1$s).
     * Deliberately strict: "100%", "10% di sconto" and "100%sicuro" are
     * ordinary text, not placeholders.
     */
    const RE = '/(?<![%\p{L}\p{N}])%(?:\d+\$)?[sdfu](?![\p{L}\p{N}])/u';

    /** Class of the wrapper that tells the engine "leave this alone". */
    const SHIELD_CLASS = 'twtr-ph';

    /**
     * Whether a text contains at least one placeholder.
     *
     * @param mixed $text
     * @return bool
     */
    public static function has($text) {
        return is_string($text) && strpos($text, '%') !== false && (bool) preg_match(self::RE, $text);
    }

    /**
     * Placeholders of a text, sorted (their order in the sentence may
     * change from one language to another).
     *
     * @param mixed $text
     * @return string[]
     */
    public static function find($text) {
        if (!is_string($text) || strpos($text, '%') === false) {
            return array();
        }
        preg_match_all(self::RE, $text, $m);
        $list = $m[0];
        sort($list);
        return $list;
    }

    /**
     * Whether a translation carries exactly the placeholders of its source.
     *
     * @param string $source
     * @param string $translation
     * @return bool
     */
    public static function same($source, $translation) {
        return self::find($source) === self::find($translation);
    }

    /**
     * Wrap every placeholder that sits in the text (never inside a tag) in
     * a "do not translate" span, for engines that read HTML.
     *
     * @param string $text
     * @return string
     */
    public static function shield($text) {
        if (!self::has($text)) {
            return $text;
        }
        $open  = '<span translate="no" class="' . self::SHIELD_CLASS . '">';
        $parts = preg_split('/(<[^>]*>)/', $text, -1, PREG_SPLIT_DELIM_CAPTURE);
        foreach ($parts as $i => $part) {
            if ($i % 2 === 0 && $part !== '') {
                $parts[$i] = preg_replace(self::RE, $open . '$0</span>', $part);
            }
        }
        return implode('', $parts);
    }

    /**
     * Remove the wrappers added by shield() from an engine answer.
     *
     * @param string $text
     * @return string
     */
    public static function unshield($text) {
        if (!is_string($text) || strpos($text, self::SHIELD_CLASS) === false) {
            return $text;
        }
        return preg_replace('#<span\b[^>]*\b' . self::SHIELD_CLASS . '\b[^>]*>\s*(.*?)\s*</span>#us', '$1', $text);
    }

    /**
     * A translation with the placeholders of its source, or null when it
     * cannot be trusted.
     *
     * Returns the translation untouched when it is already right; otherwise
     * undoes what engines are known to do (a translated letter: "%д", a
     * space: "% d", "%1 $ s", an upper-case or full-width form) and checks
     * again.
     *
     * @param string $source
     * @param string $translation
     * @return string|null
     */
    public static function repair($source, $translation) {
        if (!is_string($translation)) {
            return null;
        }
        $wanted = self::find($source);
        if ($wanted === self::find($translation)) {
            return $translation;
        }
        if (!$wanted) {
            // The source has none: the engine wrote something that only looks
            // like one ("100 %s"). Nothing will be filled in, so it is harmless.
            return $translation;
        }
        static $letters = array(
            'S' => 's', 'D' => 'd', 'F' => 'f', 'U' => 'u',
            "\u{0441}" => 's', "\u{0421}" => 's', // Cyrillic es
            "\u{0434}" => 'd', "\u{0414}" => 'd', // Cyrillic de
            "\u{0444}" => 'f', "\u{0424}" => 'f', // Cyrillic ef
            "\u{FF53}" => 's', "\u{FF44}" => 'd', // full-width
        );
        $fixed = str_replace("\u{FF05}", '%', $translation); // full-width percent sign
        $fixed = preg_replace_callback(
            '/(?<![%\p{L}\p{N}])%\s*(?:(\d+)\s*\$\s*)?([sdfuSDFU\x{0441}\x{0421}\x{0434}\x{0414}\x{0444}\x{0424}\x{FF53}\x{FF44}])(?![\p{L}\p{N}])/u',
            function ($m) use ($letters) {
                $letter = isset($letters[$m[2]]) ? $letters[$m[2]] : $m[2];
                return '%' . ($m[1] !== '' ? $m[1] . '$' : '') . $letter;
            },
            $fixed
        );
        return (is_string($fixed) && $wanted === self::find($fixed)) ? $fixed : null;
    }

    /**
     * Regular expression that recognises a translation after its
     * placeholders were filled in ("%d мин чтения" → "1 мин чтения"), or
     * null when the fixed part is too short to tell anything.
     *
     * @param string $translation
     * @return string|null
     */
    public static function pattern($translation) {
        if (!self::has($translation)) {
            return null;
        }
        // Only with numbers: a "%s" stands for any text, and a pattern like
        // "anything + Logo" would also swallow real sentences still to translate.
        foreach (self::find($translation) as $placeholder) {
            if (substr($placeholder, -1) === 's') {
                return null;
            }
        }
        $plain = trim(html_entity_decode(strip_tags($translation), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
        $fixed = preg_replace(self::RE, '', $plain);
        if (!preg_match('/\p{L}{2}/u', $fixed)) {
            return null; // "%s" alone, "%d %s": would match any text
        }
        $re = '';
        foreach (preg_split('/(' . substr(self::RE, 1, -2) . ')/u', $plain, -1, PREG_SPLIT_DELIM_CAPTURE) as $i => $part) {
            if ($i % 2 === 1) {
                $re .= '[-+]?\d[\d.,\x{2019}\x{00A0}\' ]*';
            } elseif ($part !== '') {
                $re .= preg_replace('/\s+/u', '\\s+', preg_quote($part, '/'));
            }
        }
        return '/^' . $re . '$/us';
    }

    /**
     * Fixed pieces of a translation around its placeholders ("Найдено %s
     * товаров" → "Найдено", "товаров"): when the value filled in is HTML,
     * the page shows them as separate text nodes.
     *
     * @param string $translation
     * @return string[]
     */
    public static function literals($translation) {
        if (!self::has($translation)) {
            return array();
        }
        $out = array();
        foreach (preg_split(self::RE, strip_tags($translation)) as $part) {
            $part = trim($part);
            if (preg_match('/\p{L}{2}/u', $part)) {
                $out[] = $part;
            }
        }
        return $out;
    }

    /** Writing systems of the languages that do not use the Latin alphabet. */
    private static $scripts = array(
        'ru' => 'Cyrillic', 'uk' => 'Cyrillic', 'bg' => 'Cyrillic', 'sr' => 'Cyrillic', 'mk' => 'Cyrillic',
        'be' => 'Cyrillic', 'kk' => 'Cyrillic',
        'el' => 'Greek', 'he' => 'Hebrew', 'ar' => 'Arabic', 'fa' => 'Arabic', 'ur' => 'Arabic',
        'hi' => 'Devanagari', 'th' => 'Thai', 'ko' => 'Hangul', 'ka' => 'Georgian', 'hy' => 'Armenian',
        'zh' => 'Han', 'ja' => 'Han|Hiragana|Katakana',
    );

    /**
     * Whether a language is written in an alphabet of its own (not Latin).
     *
     * @param string $lang Language slug.
     * @return bool
     */
    public static function has_own_script($lang) {
        return isset(self::$scripts[strtolower(substr((string) $lang, 0, 2))]);
    }

    /**
     * Whether a text is already written in the alphabet of the target
     * language while the site's own language uses another one: Russian text
     * on an Italian site is a translation that came back, not a source.
     * Sending it to the engine as Italian gives nonsense.
     *
     * @param string $text        Plain text.
     * @param string $target_lang Language slug (e.g. "ru").
     * @param string $source_lang Language slug of the site (e.g. "it").
     * @return bool
     */
    public static function in_target_script($text, $target_lang, $source_lang) {
        $target = strtolower(substr((string) $target_lang, 0, 2));
        $source = strtolower(substr((string) $source_lang, 0, 2));
        if (!isset(self::$scripts[$target]) || !is_string($text) || $text === '') {
            return false;
        }
        if (isset(self::$scripts[$source]) && self::$scripts[$source] === self::$scripts[$target]) {
            return false; // same alphabet on both sides: nothing to tell apart
        }
        $letters = preg_match_all('/\p{L}/u', $text);
        if (!$letters || $letters < 2) {
            return false;
        }
        $class = '';
        foreach (explode('|', self::$scripts[$target]) as $script) {
            $class .= '\p{' . $script . '}';
        }
        $own = preg_match_all('/[' . $class . ']/u', $text);
        return $own && $own * 2 >= $letters;
    }
}
