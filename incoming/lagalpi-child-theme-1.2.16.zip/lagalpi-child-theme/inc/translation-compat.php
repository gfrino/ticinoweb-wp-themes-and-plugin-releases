<?php
/** Compatibility for existing WPML query-string URLs after migration. */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/** Keep bookmarked and indexed ?lang= URLs in the requested language. */
function lagalpi_redirect_legacy_language_url() {
    if ( defined( 'ICL_SITEPRESS_VERSION' ) || ! function_exists( 'twtr_get_language_url' )
        || is_admin() || wp_doing_ajax() || wp_doing_cron()
        || ! isset( $_GET['lang'] ) || ! is_string( $_GET['lang'] )
        || ! isset( $_SERVER['REQUEST_METHOD'] ) || $_SERVER['REQUEST_METHOD'] !== 'GET'
        || isset( $_GET['wc-ajax'] ) || isset( $_GET['add-to-cart'] ) || isset( $_GET['lsesi'] ) ) {
        return;
    }
    $lang = sanitize_key( wp_unslash( $_GET['lang'] ) );
    $languages = twtr_get_languages( true );
    if ( ! isset( $languages[ $lang ] ) ) {
        return;
    }
    $uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
    // Use the configured host, never a client-supplied Host header.
    $url = rtrim( get_option( 'home' ), '/' ) . '/' . ltrim( $uri, '/' );
    $target = twtr_get_language_url( $lang, remove_query_arg( 'lang', $url ) );
    if ( wp_safe_redirect( $target, 301, 'lagAlpi language migration' ) ) {
        exit;
    }
}
add_action( 'template_redirect', 'lagalpi_redirect_legacy_language_url', 1 );

/** Translate the final title after the parent has generated its SEO fallback. */
function lagalpi_translate_document_title_parts( $parts ) {
    if ( defined( 'ICL_SITEPRESS_VERSION' ) || ! function_exists( 'twtr_translate' ) || empty( $parts['title'] ) ) {
        return $parts;
    }
    if ( is_singular() && ! is_front_page() ) {
        $id = get_queried_object_id();
        $raw_title = get_post_field( 'post_title', $id, 'raw' );
        // Custom SEO titles remain under the existing SEO translation context.
        if ( html_entity_decode( $parts['title'], ENT_QUOTES, 'UTF-8' ) === html_entity_decode( $raw_title, ENT_QUOTES, 'UTF-8' ) ) {
            // The title may already have been emitted in another context. A ready lookup
            // avoids treating its original spelling as a previously translated brand.
            $ready = class_exists( 'Twtr_Resolver' ) ? Twtr_Resolver::find( $raw_title, 'post:' . $id . ':title' ) : null;
            $parts['title'] = $ready !== null ? $ready : twtr_translate( $raw_title, 'post:' . $id . ':title' );
        }
    }
    return $parts;
}
add_filter( 'document_title_parts', 'lagalpi_translate_document_title_parts', 99 );

/** Keep session-dependent commerce forms out of whole-content translation. */
function lagalpi_keep_commerce_forms_dynamic() {
    if ( ! defined( 'ICL_SITEPRESS_VERSION' ) && class_exists( 'Twtr_Content' )
        && function_exists( 'is_cart' ) && ( is_cart() || is_checkout() || is_account_page() ) ) {
        // WooCommerce localizes its fields; the tW HTML layer handles theme text.
        // Never cache or queue a rendered form with session values and nonces.
        remove_filter( 'the_content', array( 'Twtr_Content', 'content' ), 20 );
    }
}
add_action( 'wp', 'lagalpi_keep_commerce_forms_dynamic', 20 );
