/*
 * SAM SWEET LAB — Ice Cream Tower
 *
 * Il gioco segreto del sito: si apre cercando «samsweetlab» (site.js carica questo file solo
 * allora, le pagine normali non lo scaricano). Un cono raccoglie le palline che cadono e la
 * torre deve restare in equilibrio.
 *
 * Tutto qui dentro: grafica su canvas 2D (palline e cono disegnati una volta in immagini
 * pronte, poi solo spostati), fisica arcade propria, suoni sintetizzati con Web Audio (partono
 * solo dopo un clic), interfaccia in HTML sopra il canvas. Nessuna libreria esterna.
 *
 * La fisica della torre è un pendolo rovesciato: rigidità (la «colla» del gelato) che cala
 * con l'altezza, tendenza a cadere che cresce, centro di massa spostato dalle palline prese
 * di lato, inerzia rispetto ai movimenti del cono, smorzamento sempre più debole. Le costanti
 * sono tarate con un giocatore simulato con riflessi umani: fino a ~12 palline si regge con
 * attenzione, a 15 per pochi secondi senza correggere bene, oltre è una sfida vera. Un solo
 * scatto da un bordo all'altro (la torre sente una mano veloce ma umana) fa oscillare una torre
 * di 10-12 e la mette in pericolo da 15 in su. Le palline nascono sempre a una distanza che si
 * copre con calma.
 * Tre palline lasciate cadere e la partita finisce. La vista si allontana un poco e poi sale
 * con la torre, così sopra la cima resta sempre più di metà schermo (CHANGELOG 2.6.0).
 */
(() => {
  'use strict';
  if (window.SweetIceCreamTower) return;

  /* ---------- Testi (arrivano da PHP nella lingua della pagina) ---------- */
  const STRINGS = {
    label: 'Gioco segreto: Ice Cream Tower', tagline: 'Sovrapponi. Bilancia. Batti il record.', play: 'Gioca ora',
    howMouse: 'Muovi il cono con il mouse o con le frecce.', howTouch: 'Trascina il dito per muovere il cono.',
    howGoal: 'Prendi le palline e tieni la torre in equilibrio: più sale, più oscilla.',
    mouse: 'Mouse', keys: 'Frecce · A D', drag: 'Trascina',
    scoops: 'Palline', best: 'Record', balance: 'Equilibrio', pause: 'Pausa', paused: 'In pausa', resume: 'Riprendi',
    retry: 'Riprova', back: 'Torna al sito', exit: 'Esci dal gioco', soundOn: 'Suono acceso', soundOff: 'Suono spento',
    ohNo: 'Oh no!', fell: 'Il gelato è caduto!', caught: 'Palline raccolte', newRecord: 'Nuovo record!',
    beatRecord: 'Hai battuto il tuo record!', almost: 'Così vicino al record!',
    m10: 'Che equilibrio!', m20: 'Torre da maestro gelatiere!', m30: 'Leggendario!',
    missed: 'Palline cadute', tooMany: 'Tre palline a terra!', howLives: 'Tre palline a terra e la partita finisce.',
  };

  /* ---------- Memoria locale (può mancare: finestra privata, archivio bloccato) ---------- */
  const BEST_KEY = 'samsweetlab-tower-best', MUTE_KEY = 'samsweetlab-tower-muted';
  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, String(v)); } catch (e) { /* niente memoria: pazienza */ } },
  };

  /* ---------- Gusti: colori dal chiaro al profondo, e i «pezzetti» dentro ---------- */
  const FLAVOURS = [
    { light: '#ffe3ea', base: '#f6a9bc', shade: '#e47b97', deep: '#c45a79', bit: '#b03a5b', kind: 'seed' },      // fragola
    { light: '#f0f6da', base: '#c6d998', shade: '#9fb66b', deep: '#7e9550', bit: '#5e7a32', kind: 'nut' },       // pistacchio
    { light: '#fffcf3', base: '#f9eed0', shade: '#ead4a2', deep: '#d4b57c', bit: '#3a2a1c', kind: 'speck' },     // vaniglia
    { light: '#c8977a', base: '#925f41', shade: '#6d422a', deep: '#4f2d1b', bit: '#2c180e', kind: 'chip' },      // cioccolato
    { light: '#fff1cc', base: '#ffc761', shade: '#f4a43c', deep: '#df8626', bit: '#fff7e2', kind: 'gloss' },     // mango
    { light: '#f3dfc6', base: '#d2a476', shade: '#b07e51', deep: '#8e603a', bit: '#6c4425', kind: 'nut' },       // nocciola
    { light: '#fffbe2', base: '#f9e993', shade: '#e9d15b', deep: '#d0b43e', bit: '#c3a31c', kind: 'speck' },     // limone
    { light: '#f1dbf2', base: '#c893cb', shade: '#a56aa2', deep: '#824b82', bit: '#5a2a5e', kind: 'swirl' },     // frutti di bosco
    { light: '#e8f8f0', base: '#c0e7d5', shade: '#92ceb3', deep: '#70b295', bit: '#2c221c', kind: 'chip' },      // menta
  ];
  const SPRINKLES = ['#fffdf8', '#f2d44c', '#e8607a', '#a3b86c', '#8fd3ff', '#f6a9bc'];

  /* ---------- Fisica (unità: il raggio di una pallina; tempo in secondi) ---------- */
  const STEP = 1 / 120;
  const GAP = 1.3, SEAT = 0.55;                 // distanza tra le palline, appoggio della prima nel cono
  const CONE_TOP = 3.3, CONE_TIP = 0.35;         // bocca e punta del cono
  // Taratura 2.7.4: prima, da 14 palline la tendenza a cadere superava la rigidità e oltre i 17
  // era quasi impossibile andare avanti. Ora il punto di svolta è verso le 25: si sale di più, e la
  // fatica cresce piano (simulazione con riflessi umani: metà delle partite oltre 26, prima 17).
  const K = n => 26 * Math.exp(-n / 6) + 4.3;    // rigidità
  const G = n => 5.8 * (1 - Math.exp(-n / 11));  // tendenza a cadere
  const D = n => 2.8 * Math.exp(-n / 8) + 1.05;  // smorzamento
  const M = (comY, n) => 0.078 * (0.25 + 0.75 * (1 - Math.exp(-n / 7))) / (1 + comY / 12); // spinta del cono
  const CRIT = n => 0.58 + 0.27 * Math.exp(-n / 5); // inclinazione oltre la quale si cade
  const NOISE = n => 1.0 * (1 - Math.exp(-n / 14));
  const LIVES = 3;                               // palline che si possono lasciar cadere
  const HEAD = 0.42;                             // la cima resta al 42% dell'altezza: sopra, il 58% per vedere arrivare le palline
  const S_MIN = 0.78;                            // quanto può allontanarsi la vista prima di salire
  // Il cono che si vede segue il comando quasi subito (FAST); la torre sente il movimento
  // attraverso un cono «fantasma» più morbido (SPRING, MAX_ACC), su cui è tarata la fisica.
  const SPRING = 18, MAX_ACC = 90, MAX_FELT_SPEED = 16, FAST = 110, KEY_SPEED = 13;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const rand = (a = 0, b = 1) => a + Math.random() * (b - a);

  const reduceMotion = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const coarse = () => window.matchMedia('(pointer: coarse)').matches;

  /* =====================================================================
     Suoni: brevi, morbidi, sintetizzati. Nessun file, nessun suono prima di un clic.
     ===================================================================== */
  const audio = {
    ctx: null, master: null, muted: store.get(MUTE_KEY, '0') === '1',
    ensure() {
      if (!this.ctx) {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return null;
        try { this.ctx = new AC(); } catch (e) { return null; }
        this.master = this.ctx.createGain();
        this.master.gain.value = this.muted ? 0 : 0.5;
        const comp = this.ctx.createDynamicsCompressor();
        this.master.connect(comp); comp.connect(this.ctx.destination);
      }
      if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
      return this.ctx;
    },
    setMuted(m) {
      this.muted = m; store.set(MUTE_KEY, m ? '1' : '0');
      if (this.master) this.master.gain.setTargetAtTime(m ? 0 : 0.5, this.ctx.currentTime, 0.03);
    },
    tone(f0, f1, dur, type = 'sine', vol = 0.3, delay = 0) {
      const c = this.ctx; if (!c || this.muted) return;
      const t = c.currentTime + delay, o = c.createOscillator(), g = c.createGain();
      o.type = type; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(g); g.connect(this.master); o.start(t); o.stop(t + dur + 0.02);
    },
    noise(dur, f0, f1, vol = 0.1, delay = 0, q = 0.8) {
      const c = this.ctx; if (!c || this.muted) return;
      const t = c.currentTime + delay, len = Math.max(1, Math.floor(c.sampleRate * dur));
      const buf = c.createBuffer(1, len, c.sampleRate), d = buf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
      const s = c.createBufferSource(), fl = c.createBiquadFilter(), g = c.createGain();
      s.buffer = buf; fl.type = 'bandpass'; fl.Q.value = q;
      fl.frequency.setValueAtTime(f0, t); fl.frequency.exponentialRampToValueAtTime(Math.max(40, f1), t + dur);
      g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      s.connect(fl); fl.connect(g); g.connect(this.master); s.start(t); s.stop(t + dur + 0.02);
    },
    // ogni pallina presa suona la nota successiva di una scala pentatonica: la torre «canta»
    catch(n) {
      const scale = [523.25, 587.33, 659.25, 783.99, 880, 1046.5, 1174.66, 1318.5, 1567.98, 1760];
      const f = scale[n % scale.length] * (n >= scale.length * 2 ? 1.5 : 1);
      this.tone(f * 1.32, f, 0.16, 'sine', 0.32); this.tone(f * 2, f * 1.5, 0.09, 'triangle', 0.06); this.noise(0.06, 2600, 1400, 0.05);
    },
    bounce() { this.tone(280, 420, 0.09, 'triangle', 0.14); },
    splat() { this.noise(0.14, 900, 300, 0.12); this.tone(190, 90, 0.13, 'sine', 0.12); },
    record() { [784, 988, 1175, 1568].forEach((f, i) => this.tone(f, f * 1.01, 0.22, 'triangle', 0.16, i * 0.075)); this.noise(0.35, 6000, 3000, 0.03, 0.2, 2); },
    fall() { this.noise(0.6, 1800, 160, 0.16); this.tone(240, 62, 0.7, 'sine', 0.3); [0.18, 0.32, 0.47].forEach((d, i) => this.tone(360 - i * 60, 140, 0.12, 'sine', 0.12, d)); },
    lose() { [660, 523, 392, 262].forEach((f, i) => this.tone(f, f * 0.97, 0.26, 'triangle', 0.15, i * 0.13)); },
    click() { this.tone(880, 720, 0.05, 'triangle', 0.06); },
    start() { this.tone(659, 662, 0.12, 'triangle', 0.14); this.tone(988, 990, 0.18, 'triangle', 0.12, 0.09); },
  };

  /* =====================================================================
     Disegni pronti: palline (una per gusto) e cono, rifatti solo al cambio di misura
     ===================================================================== */
  // ripiego per i browser che non disegnano ancora i rettangoli arrotondati
  if (!CanvasRenderingContext2D.prototype.roundRect) {
    CanvasRenderingContext2D.prototype.roundRect = function (x, y, w, h, r) {
      r = Math.min(Math.abs(r) || 0, Math.abs(w) / 2, Math.abs(h) / 2);
      this.moveTo(x + r, y); this.arcTo(x + w, y, x + w, y + h, r); this.arcTo(x + w, y + h, x, y + h, r);
      this.arcTo(x, y + h, x, y, r); this.arcTo(x, y, x + w, y, r); this.closePath();
    };
  }
  const mkCanvas = (w, h) => { const c = document.createElement('canvas'); c.width = Math.max(1, Math.ceil(w)); c.height = Math.max(1, Math.ceil(h)); return c; };
  const seeded = seed => { let s = seed >>> 0; return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296); };

  function drawScoop(fl, px, seed) {
    const side = Math.ceil(px * 3.1), c = mkCanvas(side, side), g = c.getContext('2d');
    const cx = side / 2, cy = side / 2 - px * 0.08, r = px, rnd = seeded(seed);
    // il bordo arricciato in basso, come quando la paletta stacca la pallina
    g.beginPath();
    const steps = 48;
    for (let i = 0; i <= steps; i++) {
      const a = -0.18 + (Math.PI + 0.36) * (i / steps);
      const wave = 1.07 + 0.075 * Math.sin(a * 9 + seed);
      const x = cx + Math.cos(a) * r * wave, y = cy + r * 0.2 + Math.sin(a) * r * 0.86 * wave;
      if (i === 0) g.moveTo(x, y); else g.lineTo(x, y);
    }
    g.closePath();
    let gr = g.createLinearGradient(0, cy, 0, cy + r * 1.2);
    gr.addColorStop(0, fl.shade); gr.addColorStop(1, fl.deep);
    g.fillStyle = gr; g.fill();
    // la pallina
    gr = g.createRadialGradient(cx - r * 0.36, cy - r * 0.42, r * 0.08, cx, cy, r * 1.08);
    gr.addColorStop(0, fl.light); gr.addColorStop(0.38, fl.base); gr.addColorStop(0.84, fl.shade); gr.addColorStop(1, fl.deep);
    g.beginPath(); g.arc(cx, cy, r, 0, Math.PI * 2); g.fillStyle = gr; g.fill();
    // ombra morbida in basso, dentro la pallina
    g.save(); g.beginPath(); g.arc(cx, cy, r, 0, Math.PI * 2); g.clip();
    gr = g.createLinearGradient(0, cy - r * 0.2, 0, cy + r);
    gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(60,25,10,0.16)');
    g.fillStyle = gr; g.fillRect(cx - r, cy - r, r * 2, r * 2);
    // le «creste» lasciate dalla paletta
    g.strokeStyle = 'rgba(255,255,255,0.22)'; g.lineWidth = r * 0.07; g.lineCap = 'round';
    for (let k = 0; k < 3; k++) {
      g.beginPath(); g.arc(cx + r * (0.25 - k * 0.1), cy + r * (0.15 + k * 0.08), r * (0.55 + k * 0.17), Math.PI * (1.12 + k * 0.05), Math.PI * (1.5 + k * 0.04)); g.stroke();
    }
    g.strokeStyle = 'rgba(80,30,10,0.08)'; g.lineWidth = r * 0.06;
    g.beginPath(); g.arc(cx - r * 0.1, cy + r * 0.05, r * 0.72, Math.PI * 0.05, Math.PI * 0.55); g.stroke();
    // i pezzetti del gusto
    const bits = fl.kind === 'gloss' ? 0 : fl.kind === 'swirl' ? 3 : 13;
    for (let i = 0; i < bits; i++) {
      const a = rnd() * Math.PI * 2, d = Math.sqrt(rnd()) * r * 0.82;
      const x = cx + Math.cos(a) * d, y = cy + Math.sin(a) * d;
      if (Math.hypot(x - (cx - r * 0.38), y - (cy - r * 0.45)) < r * 0.3) continue; // non sul riflesso
      g.save(); g.translate(x, y); g.rotate(rnd() * Math.PI);
      g.fillStyle = fl.bit; g.globalAlpha = 0.55 + rnd() * 0.35;
      if (fl.kind === 'seed') { g.beginPath(); g.ellipse(0, 0, r * 0.035, r * 0.06, 0, 0, Math.PI * 2); g.fill(); }
      else if (fl.kind === 'speck') { g.beginPath(); g.arc(0, 0, r * (0.018 + rnd() * 0.02), 0, Math.PI * 2); g.fill(); }
      else if (fl.kind === 'nut') { g.beginPath(); g.moveTo(-r * 0.07, -r * 0.03); g.lineTo(r * 0.05, -r * 0.06); g.lineTo(r * 0.08, r * 0.04); g.lineTo(-r * 0.03, r * 0.07); g.closePath(); g.fill(); }
      else if (fl.kind === 'chip') { g.beginPath(); g.moveTo(-r * 0.06, -r * 0.05); g.lineTo(r * 0.07, -r * 0.03); g.lineTo(r * 0.03, r * 0.06); g.lineTo(-r * 0.07, r * 0.03); g.closePath(); g.fill(); }
      else if (fl.kind === 'swirl') { g.globalAlpha = 0.35; g.strokeStyle = fl.bit; g.lineWidth = r * 0.12; g.beginPath(); g.arc(0, 0, r * 0.35, 0, Math.PI * 0.9); g.stroke(); }
      g.restore();
    }
    g.restore();
    // riflesso lucido e luce di bordo
    gr = g.createRadialGradient(cx - r * 0.4, cy - r * 0.46, 0, cx - r * 0.4, cy - r * 0.46, r * 0.36);
    gr.addColorStop(0, 'rgba(255,255,255,0.85)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr; g.beginPath(); g.ellipse(cx - r * 0.4, cy - r * 0.46, r * 0.36, r * 0.24, -0.55, 0, Math.PI * 2); g.fill();
    g.strokeStyle = 'rgba(255,255,255,0.28)'; g.lineWidth = r * 0.05;
    g.beginPath(); g.arc(cx, cy, r * 0.93, Math.PI * 0.08, Math.PI * 0.42); g.stroke();
    return { c, side, cy };
  }

  function drawCone(px) {
    const w = px * 2.7, h = px * (CONE_TOP - CONE_TIP + 0.5), c = mkCanvas(w, h + px * 0.3), g = c.getContext('2d');
    const cx = w / 2, top = px * 0.42, tipY = h;
    const half = px * 1.08;
    // corpo
    g.beginPath(); g.moveTo(cx - half, top); g.lineTo(cx + half, top);
    g.quadraticCurveTo(cx + half * 0.08, tipY - px * 0.05, cx, tipY); g.quadraticCurveTo(cx - half * 0.08, tipY - px * 0.05, cx - half, top); g.closePath();
    let gr = g.createLinearGradient(cx - half, 0, cx + half, 0);
    gr.addColorStop(0, '#c9883f'); gr.addColorStop(0.32, '#ecbb74'); gr.addColorStop(0.62, '#d79a52'); gr.addColorStop(1, '#a96a30');
    g.fillStyle = gr; g.fill();
    // la cialda: due ordini di righe incrociate, una scura e una chiara spostata (rilievo)
    g.save(); g.clip();
    const step = px * 0.42;
    for (let d = -h * 2; d < w + h * 2; d += step) {
      g.strokeStyle = 'rgba(120,64,22,0.5)'; g.lineWidth = px * 0.085;
      g.beginPath(); g.moveTo(d, top); g.lineTo(d + h, top + h); g.stroke();
      g.beginPath(); g.moveTo(d, top); g.lineTo(d - h, top + h); g.stroke();
      g.strokeStyle = 'rgba(255,232,185,0.42)'; g.lineWidth = px * 0.035;
      g.beginPath(); g.moveTo(d + px * 0.06, top); g.lineTo(d + h + px * 0.06, top + h); g.stroke();
      g.beginPath(); g.moveTo(d + px * 0.06, top); g.lineTo(d - h + px * 0.06, top + h); g.stroke();
    }
    gr = g.createLinearGradient(0, top, 0, top + px * 0.9);
    gr.addColorStop(0, 'rgba(70,35,10,0.35)'); gr.addColorStop(1, 'rgba(70,35,10,0)');
    g.fillStyle = gr; g.fillRect(0, top, w, px * 0.9);
    g.restore();
    // bordo arrotolato della bocca
    const rw = px * 1.22, rh = px * 0.5;
    g.beginPath(); g.roundRect(cx - rw, top - rh * 0.55, rw * 2, rh, rh * 0.5);
    gr = g.createLinearGradient(0, top - rh * 0.55, 0, top + rh * 0.45);
    gr.addColorStop(0, '#f3c887'); gr.addColorStop(0.55, '#d79a52'); gr.addColorStop(1, '#b0712f');
    g.fillStyle = gr; g.fill();
    g.strokeStyle = 'rgba(255,240,205,0.6)'; g.lineWidth = px * 0.05;
    g.beginPath(); g.moveTo(cx - rw + rh * 0.4, top - rh * 0.4); g.lineTo(cx + rw - rh * 0.4, top - rh * 0.4); g.stroke();
    g.strokeStyle = 'rgba(110,60,20,0.35)'; g.lineWidth = px * 0.04;
    for (let x = cx - rw + px * 0.3; x < cx + rw - px * 0.2; x += px * 0.34) { g.beginPath(); g.moveTo(x, top - rh * 0.3); g.lineTo(x + px * 0.12, top + rh * 0.3); g.stroke(); }
    return { c, w: c.width, h: c.height, mouthY: top, cx };
  }

  /* =====================================================================
     Il gioco
     ===================================================================== */
  let dlg = null, ui = null, canvas = null, ctx = null, raf = 0, last = 0, acc = 0;
  let savedScroll = 0;
  let state = 'intro', returnFocus = null, opts = {}, best = Number(store.get(BEST_KEY, '0')) || 0, recordAnnounced = false, prevBest = 0;
  const view = { W: 0, H: 0, dpr: 1, bp: 30, s: 1, camY: 0, half: 6, floorY: 0, topPad: 90, cx: 0 };
  const ctl = { target: 0, x: 0, v: 0, a: 0, va: 0, gx: 0, gv: 0, keyV: 0, left: false, right: false, touchId: null, lastX: 0 };
  const tower = { n: 0, th: 0, om: 0, alpha: 0, scoops: [], comX: 0, comY: SEAT, noise: 0 };
  let balls = [], debris = [], particles = [], decals = [], spawnT = 0, lastSpawnX = 0, collapseT = 0, overShown = false, t0 = 0, shake = 0;
  let misses = 0, finalCount = 0, endReason = 'fall';
  let sprites = null, cone = null, bg = null;
  const P = { x: 0, y: 0 };

  const toX = x => view.cx + x * view.bp * view.s;
  // fin dove va il cono: fino al bordo dello schermo, a qualsiasi zoom. Le palline restano nella
  // fascia centrale (view.half), ma con la torre inclinata la cima deve poter arrivare sopra
  // quelle che cadono vicino al bordo della fascia: il cono va oltre.
  const coneLim = () => Math.max(view.half, view.cx / (view.bp * view.s)) - 1.2;
  const toY = y => view.floorY - (y - view.camY) * view.bp * view.s;

  /* ---------- Struttura HTML ---------- */
  const icon = {
    pause: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="6.5" y="5" width="3.6" height="14" rx="1.6"/><rect x="13.9" y="5" width="3.6" height="14" rx="1.6"/></svg>',
    play: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5.5v13a1 1 0 0 0 1.5.86l10.4-6.5a1 1 0 0 0 0-1.72L9.5 4.64A1 1 0 0 0 8 5.5Z"/></svg>',
    close: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg>',
    sound: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path class="sit-wave" d="M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path class="sit-mute" d="M15.5 9.5l5 5M20.5 9.5l-5 5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
    mouse: '<svg viewBox="0 0 32 32" aria-hidden="true"><rect x="9" y="4" width="14" height="24" rx="7" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M16 9v5" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>',
    keys: '<svg viewBox="0 0 44 32" aria-hidden="true"><rect x="2" y="7" width="18" height="18" rx="5" fill="none" stroke="currentColor" stroke-width="2.2"/><rect x="24" y="7" width="18" height="18" rx="5" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M14 16H8m0 0 3-3m-3 3 3 3M30 16h6m0 0-3-3m3 3-3 3" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    drag: '<svg viewBox="0 0 40 32" aria-hidden="true"><path d="M17 19V8.5a2.5 2.5 0 0 1 5 0V16l5.6 1.2a3 3 0 0 1 2.3 3.4L29 27H17.5L12 20.5a2.2 2.2 0 0 1 3.2-3L17 19" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linejoin="round"/><path d="M4 9h7M4 9l2.5-2.5M4 9l2.5 2.5M36 9h-7m7 0-2.5-2.5M36 9l-2.5 2.5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
  };

  function build() {
    const S = Object.assign({}, STRINGS, opts.strings || {});
    dlg = document.createElement('dialog');
    dlg.className = 'sit';
    dlg.setAttribute('aria-label', S.label);
    dlg.setAttribute('data-lenis-prevent', '');
    const touch = coarse();
    dlg.innerHTML = `
      <canvas class="sit-canvas" tabindex="-1" aria-hidden="true"></canvas>
      <div class="sit-vignette" aria-hidden="true"></div>
      <div class="sit-hud" hidden>
        <div class="sit-score"><span class="sit-label">${S.scoops}</span><span class="sit-num" data-score>0</span><span class="sit-best">${S.best} <b data-best>${best}</b></span><span class="sit-lives" data-lives role="img" aria-label="${S.missed}: 0 / ${LIVES}">${'<i></i>'.repeat(LIVES)}</span></div>
        <div class="sit-meter" role="img" aria-label="${S.balance}">
          <svg viewBox="0 0 120 66" aria-hidden="true"><path class="sit-meter-track" d="M10 60a50 50 0 0 1 100 0"/><path class="sit-meter-safe" d="M38 16.5a50 50 0 0 1 44 0"/><g class="sit-needle"><path d="M60 60 60 18"/><circle cx="60" cy="60" r="6"/></g></svg>
          <span class="sit-label">${S.balance}</span>
        </div>
        <div class="sit-tools">
          <button type="button" class="sit-icon" data-sound aria-pressed="false" aria-label="${S.soundOn}">${icon.sound}</button>
          <button type="button" class="sit-icon" data-pause aria-label="${S.pause}">${icon.pause}</button>
          <button type="button" class="sit-icon" data-exit aria-label="${S.exit}">${icon.close}</button>
        </div>
      </div>
      <div class="sit-corner"><button type="button" class="sit-icon" data-sound aria-pressed="false" aria-label="${S.soundOn}">${icon.sound}</button><button type="button" class="sit-icon" data-exit aria-label="${S.exit}">${icon.close}</button></div>
      <section class="sit-screen sit-start" data-screen="start">
        <p class="sit-eyebrow">SAM SWEET LAB</p>
        <h2 class="sit-title"><span>Ice Cream</span><span>Tower</span></h2>
        <p class="sit-tagline">${S.tagline}</p>
        <button type="button" class="sit-button" data-play autofocus>${S.play}</button>
        <p class="sit-best-line" data-best-line ${best ? '' : 'hidden'}>${S.best}: <b data-best>${best}</b></p>
        <ul class="sit-how">
          ${touch ? `<li>${icon.drag}<span>${S.drag}</span></li>` : `<li>${icon.mouse}<span>${S.mouse}</span></li><li>${icon.keys}<span>${S.keys}</span></li>`}
        </ul>
        <p class="sit-hint">${touch ? S.howTouch : S.howMouse} ${S.howGoal} ${S.howLives}</p>
      </section>
      <section class="sit-screen sit-card" data-screen="pause" hidden>
        <h2 class="sit-card-title">${S.paused}</h2>
        <div class="sit-actions"><button type="button" class="sit-button" data-resume>${S.resume}</button><button type="button" class="sit-button sit-ghost" data-exit>${S.back}</button></div>
      </section>
      <section class="sit-screen sit-card" data-screen="over" hidden>
        <p class="sit-badge" data-record hidden>${S.newRecord}</p>
        <h2 class="sit-card-title"><span>${S.ohNo}</span><span>${S.fell}</span></h2>
        <p class="sit-message" data-message></p>
        <dl class="sit-stats"><div><dt>${S.caught}</dt><dd data-final>0</dd></div><div><dt>${S.best}</dt><dd data-best>${best}</dd></div></dl>
        <div class="sit-actions"><button type="button" class="sit-button" data-retry>${S.retry}</button><button type="button" class="sit-button sit-ghost" data-exit>${S.back}</button></div>
      </section>
      <p class="sit-toast" data-toast aria-live="polite"></p>`;
    document.body.append(dlg);
    canvas = dlg.querySelector('canvas');
    ctx = canvas.getContext('2d', { alpha: false, desynchronized: true }) || canvas.getContext('2d');
    ui = {
      S, hud: dlg.querySelector('.sit-hud'), corner: dlg.querySelector('.sit-corner'), score: dlg.querySelector('[data-score]'),
      bests: [...dlg.querySelectorAll('[data-best]')], bestLine: dlg.querySelector('[data-best-line]'),
      needle: dlg.querySelector('.sit-needle'), meter: dlg.querySelector('.sit-meter'), vignette: dlg.querySelector('.sit-vignette'),
      sound: [...dlg.querySelectorAll('[data-sound]')], toast: dlg.querySelector('[data-toast]'), final: dlg.querySelector('[data-final]'),
      record: dlg.querySelector('[data-record]'), message: dlg.querySelector('[data-message]'), lives: dlg.querySelector('[data-lives]'),
      screens: Object.fromEntries([...dlg.querySelectorAll('[data-screen]')].map(el => [el.dataset.screen, el])),
    };
    updateSoundButton();
    dlg.addEventListener('click', onClick);
    dlg.addEventListener('cancel', onCancel);
    dlg.addEventListener('pointermove', onPointerMove);
    if ('onpointerrawupdate' in window) dlg.addEventListener('pointerrawupdate', onPointerMove);
    dlg.addEventListener('pointerdown', onPointerDown);
    dlg.addEventListener('pointerup', onPointerUp);
    dlg.addEventListener('pointercancel', onPointerUp);
    dlg.addEventListener('wheel', e => e.preventDefault(), { passive: false });
    dlg.addEventListener('touchmove', e => { if (e.target === canvas || state === 'playing') e.preventDefault(); }, { passive: false });
    dlg.addEventListener('contextmenu', e => { if (state === 'playing') e.preventDefault(); });
  }

  /* ---------- Misure e disegni pronti ---------- */
  function layout() {
    const W = dlg.clientWidth || innerWidth, H = dlg.clientHeight || innerHeight;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    view.W = W; view.H = H; view.dpr = dpr; view.cx = W / 2;
    view.bp = clamp(Math.min(H * 0.043, W * 0.08), 17, 36);
    view.half = clamp(W / view.bp / 2 - 0.6, 4.6, 12.5);
    view.floorY = H - Math.max(28, H * 0.075);
    view.topPad = Math.max(86, H * 0.1);
    canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr);
    const px = view.bp * dpr;
    sprites = FLAVOURS.map((f, i) => drawScoop(f, px, 7 + i * 13));
    cone = drawCone(px);
    bg = drawBackground(W, H, dpr);
    const lim = coneLim();
    ctl.x = clamp(ctl.x, -lim, lim);
    ctl.target = clamp(ctl.target, -lim, lim);
  }

  function drawBackground(W, H, dpr) {
    const c = mkCanvas(W * dpr, H * dpr), g = c.getContext('2d');
    g.scale(dpr, dpr);
    let gr = g.createLinearGradient(0, 0, 0, H);
    gr.addColorStop(0, '#fcf7ee'); gr.addColorStop(0.7, '#f7eee0'); gr.addColorStop(1, '#f0e3cf');
    g.fillStyle = gr; g.fillRect(0, 0, W, H);
    const blob = (x, y, r, col, a) => { const b = g.createRadialGradient(x, y, 0, x, y, r); b.addColorStop(0, col.replace('A', a)); b.addColorStop(1, col.replace('A', 0)); g.fillStyle = b; g.fillRect(0, 0, W, H); };
    blob(W * 0.86, H * 0.12, Math.max(W, H) * 0.42, 'rgba(246,169,188,A)', 0.34);
    blob(W * 0.1, H * 0.78, Math.max(W, H) * 0.46, 'rgba(198,217,152,A)', 0.36);
    blob(W * 0.22, H * 0.18, Math.max(W, H) * 0.3, 'rgba(249,233,147,A)', 0.28);
    blob(W * 0.78, H * 0.86, Math.max(W, H) * 0.32, 'rgba(192,231,213,A)', 0.26);
    // grana leggerissima, perché non sembri plastica
    const n = mkCanvas(96, 96), ng = n.getContext('2d'), id = ng.createImageData(96, 96);
    for (let i = 0; i < id.data.length; i += 4) { const v = Math.random() * 255; id.data[i] = id.data[i + 1] = id.data[i + 2] = v; id.data[i + 3] = 10; }
    ng.putImageData(id, 0, 0);
    g.fillStyle = g.createPattern(n, 'repeat'); g.fillRect(0, 0, W, H);
    return c;
  }

  /* ---------- Partita ---------- */
  function resetGame() {
    tower.n = 0; tower.th = 0; tower.om = 0; tower.alpha = 0; tower.scoops = []; tower.comX = 0; tower.comY = SEAT; tower.noise = 0;
    balls = []; debris = []; particles = []; decals = []; spawnT = 0.6; collapseT = 0; overShown = false; shake = 0;
    ctl.v = 0; ctl.a = 0; ctl.va = 0; ctl.gx = ctl.x; ctl.gv = 0; ctl.keyV = 0; recordAnnounced = false; prevBest = best;
    view.s = 1; view.camY = 0; misses = 0; finalCount = 0; endReason = 'fall';
    setScore(0, false); setLives();
  }

  function startGame() {
    audio.ensure(); audio.start();
    resetGame();
    showScreen(null);
    ui.hud.hidden = false; ui.corner.hidden = true;
    state = 'playing';
    dlg.classList.add('is-playing');
    t0 = performance.now();
  }

  function setScore(n, bump = true) {
    ui.score.textContent = n;
    if (bump && !reduceMotion()) ui.score.animate([{ transform: 'scale(1.42) rotate(-4deg)', color: '#e8607a' }, { transform: 'scale(1)', color: 'inherit' }], { duration: 420, easing: 'cubic-bezier(.2,1.6,.4,1)' });
  }
  function setLives(animate = false) {
    if (!ui || !ui.lives) return;
    const icons = ui.lives.children;
    for (let i = 0; i < icons.length; i++) {
      const lost = i >= LIVES - misses;
      if (lost && !icons[i].classList.contains('is-lost') && animate && !reduceMotion()) icons[i].animate([{ transform: 'scale(1.5) rotate(-20deg)' }, { transform: 'scale(1)' }], { duration: 420, easing: 'cubic-bezier(.2,1.6,.4,1)' });
      icons[i].classList.toggle('is-lost', lost);
    }
    ui.lives.setAttribute('aria-label', `${ui.S.missed}: ${misses} / ${LIVES}`);
    if (animate && !reduceMotion()) { ui.vignette.animate([{ opacity: 0.9 }, { opacity: 0 }], { duration: 520, easing: 'ease-out' }); }
  }
  function setBest(v) { ui.bests.forEach(el => { el.textContent = v; }); if (ui.bestLine) ui.bestLine.hidden = !v; }

  function toast(text) {
    const el = ui.toast;
    el.textContent = text;
    el.getAnimations().forEach(a => a.cancel());
    el.animate([
      { opacity: 0, transform: 'translate(-50%, -14px) scale(.9) rotate(-3deg)' },
      { opacity: 1, transform: 'translate(-50%, 0) scale(1.04) rotate(-2deg)', offset: 0.12 },
      { opacity: 1, transform: 'translate(-50%, 0) scale(1) rotate(-2deg)', offset: 0.82 },
      { opacity: 0, transform: 'translate(-50%, -8px) scale(.96) rotate(-2deg)' },
    ], { duration: 1900, easing: 'ease-out', fill: 'forwards' });
  }

  function spawnBall() {
    const n = tower.n, h = view.half - 1.1;
    const top = n ? scoopPos(n - 1, { x: 0, y: 0 }) : { x: ctl.x, y: CONE_TOP };
    const y = view.camY + view.floorY / (view.bp * view.s) + 1.4;
    const speed = view.H * (0.32 + 0.18 * (1 - Math.exp(-n / 18))) / (view.bp * view.s);
    // dove sarà il cono: sotto la pallina che sta già cadendo, altrimenti dov'è la cima adesso
    let prev = null;
    for (const b of balls) if (!b.bounced && (!prev || b.y > prev.y)) prev = b;
    const anchor = clamp(prev ? prev.x : top.x, -h, h); // col cono oltre la fascia si parte dal suo bordo
    const time = prev ? Math.max(0.7, (y - prev.y) / speed) : Math.max(0.8, (y - top.y - 2) / speed);
    const comfy = 7 - 2.7 * (1 - Math.exp(-n / 18)); // velocità comoda del cono (raggi al secondo)
    const reach = clamp(comfy * time * 0.75, 2.2, h * 1.2);
    const x = clamp(anchor + rand(-reach, reach), -h, h);
    lastSpawnX = x;
    const kind = Math.random();
    balls.push({
      x, y, vx: kind < 0.2 ? rand(0.4, 1.1) * (Math.random() < 0.5 ? -1 : 1) : 0, speed, t: 0,
      sway: kind > 0.78 ? rand(0.4, 0.8) : 0, freq: rand(1.3, 2.1), phase: rand(0, 6.28),
      f: Math.floor(Math.random() * FLAVOURS.length), rot: rand(-0.3, 0.3), spin: rand(-0.6, 0.6), bounced: false,
    });
  }

  function scoopPos(i, out) {
    const sc = tower.scoops[i], c = Math.cos(tower.th), s = Math.sin(tower.th);
    const lx = sc.cum + sc.bend + sc.lx, ly = SEAT + i * GAP + sc.ly;
    out.x = ctl.x + lx * c + ly * s; out.y = CONE_TOP - lx * s + ly * c;
    return out;
  }

  function burst(x, y, count, colors, power = 1) {
    if (reduceMotion()) count = Math.ceil(count / 3);
    for (let i = 0; i < count && particles.length < 120; i++) {
      const a = rand(0.15, Math.PI - 0.15), sp = rand(4, 9) * power;
      particles.push({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: rand(0.5, 0.85), t: 0, rot: rand(0, 6), spin: rand(-9, 9), len: rand(0.14, 0.24), col: colors[i % colors.length] });
    }
  }

  function catchBall(b) {
    const n = tower.n, top = n ? scoopPos(n - 1, P) : { x: ctl.x, y: CONE_TOP + 0.1 };
    const dx = b.x - top.x, dy = b.y - top.y, c = Math.cos(tower.th), s = Math.sin(tower.th);
    const local = dx * c - dy * s, localY = dx * s + dy * c;
    const off = n ? clamp(local * 0.75, -0.5, 0.5) : clamp(local * 0.35, -0.2, 0.2);
    const prevCum = n ? tower.scoops[n - 1].cum : 0;
    const cum = clamp(prevCum + off, -1.35, 1.35);
    tower.scoops.push({
      f: b.f, off, cum, bend: 0, bendV: 0, sq: 0.66, sqV: 0, tilt: rand(-0.12, 0.12),
      lx: prevCum + local - cum, ly: (n ? localY - GAP : localY - SEAT), lvx: 0, lvy: 0,
    });
    tower.n = n + 1;
    // il peso nuovo: la torre si sposta verso dove la pallina è atterrata
    let sum = 0; for (const sc of tower.scoops) sum += sc.cum;
    tower.comX = sum / tower.n; tower.comY = SEAT + (tower.n - 1) * GAP / 2;
    tower.om += (off * 0.9 + b.vx * 0.05) / (tower.comY + 1.2);
    for (let k = 1; k <= 3 && n - k >= 0; k++) tower.scoops[n - k].sqV -= 2.4 * Math.pow(0.55, k);
    burst(b.x, b.y - 0.7, 9, [FLAVOURS[b.f].light, ...SPRINKLES]);
    audio.catch(n);
    setScore(tower.n);
    if (tower.n > best) { best = tower.n; store.set(BEST_KEY, best); setBest(best); }
    if (tower.n === 10) toast(ui.S.m10); else if (tower.n === 20) toast(ui.S.m20); else if (tower.n === 30) toast(ui.S.m30);
    if (prevBest > 0 && tower.n > prevBest && !recordAnnounced) {
      recordAnnounced = true; audio.record();
      if (tower.n !== 10 && tower.n !== 20 && tower.n !== 30) toast(ui.S.newRecord);
      burst(b.x, b.y, 18, SPRINKLES, 1.3);
    }
  }

  function miss() {
    misses++;
    setLives(true);
    if (misses >= LIVES) {
      // terza pallina a terra: la torre resta in piedi, la partita finisce
      state = 'ending'; collapseT = 0; finalCount = tower.n; endReason = 'misses';
      for (const b of balls) { b.bounced = true; b.vy = 1; b.sway = 0; }
      audio.lose();
    }
  }

  function collapse() {
    state = 'collapse'; collapseT = 0; shake = reduceMotion() ? 0 : 0.5; finalCount = tower.n; endReason = 'fall';
    const s = Math.sin(tower.th) >= 0 ? 1 : -1;
    for (let i = 0; i < tower.n; i++) {
      const p = scoopPos(i, { x: 0, y: 0 }), sc = tower.scoops[i];
      const ox = p.x - ctl.x, oy = p.y - CONE_TOP;
      debris.push({
        x: p.x, y: p.y, vx: ctl.v + tower.om * oy + s * rand(0.6, 1.4) * (1 + i * 0.08), vy: -tower.om * ox + rand(0.5, 2.5),
        rot: tower.th + sc.tilt, spin: s * rand(1.5, 4.5), f: sc.f, sq: 1, sqV: 0, landed: false,
      });
    }
    tower.n = 0; tower.scoops = []; tower.th = 0; tower.om = 0;
    for (const b of balls) { b.bounced = true; b.vy = 1; b.sway = 0; }
    audio.fall();
    if (navigator.vibrate && coarse()) { try { navigator.vibrate(60); } catch (e) {} }
  }

  function gameOver() {
    overShown = true; state = 'over';
    const caught = finalCount;
    const isRecord = caught > prevBest;
    if (caught > best) { best = caught; store.set(BEST_KEY, best); }
    setBest(best);
    ui.final.textContent = caught;
    ui.record.hidden = !isRecord || caught === 0;
    ui.message.textContent = isRecord && caught ? ui.S.beatRecord : endReason === 'misses' ? ui.S.tooMany : (prevBest - caught <= 2 && caught > 0 ? ui.S.almost : '');
    ui.message.hidden = !ui.message.textContent;
    ui.hud.hidden = true; ui.corner.hidden = false;
    dlg.classList.remove('is-playing');
    showScreen('over');
    if (isRecord && caught) { audio.record(); burst(ctl.x, CONE_TOP + 3, 26, SPRINKLES, 1.5); }
  }

  /* ---------- Un passo di simulazione ---------- */
  function step(dt) {
    // il cono: una molla veloce verso il punto voluto (mouse, dito o tasti)
    if (ctl.left !== ctl.right) {
      const want = (ctl.right ? 1 : -1) * KEY_SPEED / Math.pow(view.s, 0.5);
      ctl.keyV += (want - ctl.keyV) * Math.min(1, dt * 12);
    } else ctl.keyV += (0 - ctl.keyV) * Math.min(1, dt * 16);
    if (Math.abs(ctl.keyV) > 0.01) ctl.target += ctl.keyV * dt;
    const lim = coneLim();
    ctl.target = clamp(ctl.target, -lim, lim);
    // cono visibile: arriva in un paio di fotogrammi. Molla critica risolta in modo esatto
    // (stabile a qualsiasi rigidità, niente vibrazioni)
    const e = ctl.x - ctl.target, decay = Math.exp(-FAST * dt), j = ctl.v + FAST * e;
    const v0 = ctl.v;
    ctl.x = ctl.target + (e + j * dt) * decay;
    ctl.v = (ctl.v - FAST * j * dt) * decay;
    if (ctl.x < -lim || ctl.x > lim) { ctl.x = clamp(ctl.x, -lim, lim); ctl.v = 0; }
    ctl.va = (ctl.v - v0) / dt;
    // cono «fantasma»: insegue quello visibile con l'inerzia della mano; la torre sente questo
    // la torre sente una mano veloce ma umana: velocità massima e accelerazione che cresce
    // in modo morbido. Correre da un bordo all'altro la fa ondeggiare, non crollare (fino a ~12).
    let a = SPRING * SPRING * (ctl.x - ctl.gx) - 2 * SPRING * ctl.gv;
    a = MAX_ACC * Math.tanh(a / MAX_ACC);
    const gv = clamp(ctl.gv + a * dt, -MAX_FELT_SPEED, MAX_FELT_SPEED);
    a = (gv - ctl.gv) / dt;
    ctl.gv = gv; ctl.gx += ctl.gv * dt;
    ctl.a = a;

    if (state === 'playing') {
      const n = tower.n;
      if (n) {
        tower.noise += ((Math.random() * 2 - 1) * NOISE(n) - tower.noise) * 0.02;
        const al = G(n) * (Math.sin(tower.th) + (tower.comX / (tower.comY + 0.6)) * Math.cos(tower.th)) - K(n) * tower.th - D(n) * tower.om - M(tower.comY, n) * a * Math.cos(tower.th) + tower.noise * 6;
        tower.om += al * dt; tower.th += tower.om * dt; tower.alpha = al;
        if (Math.abs(tower.th) > CRIT(n)) { collapse(); return; }
      }
      // spinte e rimbalzi di ogni pallina: la parte «gelatina» (solo disegno)
      for (let i = 0; i < tower.n; i++) {
        const sc = tower.scoops[i], frac = (i + 1) / tower.n, h = SEAT + i * GAP;
        const drive = -(clamp(ctl.va, -400, 400) * 0.018 + a * 0.03 + tower.alpha * h * 0.14) * frac * frac;
        sc.bendV += (drive - 110 * sc.bend - 9 * sc.bendV) * dt; sc.bend = clamp(sc.bend + sc.bendV * dt, -0.45 * frac, 0.45 * frac);
        sc.sqV += (-170 * (sc.sq - 1) - 13 * sc.sqV) * dt; sc.sq += sc.sqV * dt;
        sc.lvx += (-260 * sc.lx - 26 * sc.lvx) * dt; sc.lx += sc.lvx * dt;
        sc.lvy += (-260 * sc.ly - 26 * sc.lvy) * dt; sc.ly += sc.lvy * dt;
      }
      // nuove palline
      spawnT -= dt;
      const every = 1.35 - 0.45 * (1 - Math.exp(-tower.n / 20));
      if (spawnT <= 0 && balls.length < 3) { spawnBall(); spawnT = every * rand(0.85, 1.15); }
      stepBalls(dt);
    }
    if (state === 'collapse' || state === 'over') { stepBalls(dt); stepDebris(dt); }
    if (state === 'ending') { stepBalls(dt); collapseT += dt; if (collapseT > 1.1 && !overShown) gameOver(); }
    stepParticles(dt);
  }

  function stepBalls(dt) {
    const n = tower.n, lim = view.half - 0.6;
    for (let i = balls.length - 1; i >= 0; i--) {
      const b = balls[i];
      b.t += dt;
      const ease = Math.min(1, 0.35 + b.t * 1.6);
      b.y -= b.speed * ease * dt;
      if (b.bounced) { b.vy = (b.vy || 0) - 30 * dt; b.y += b.vy * dt; }
      b.x += (b.vx + (b.sway ? b.sway * b.freq * Math.cos(b.t * b.freq + b.phase) : 0)) * dt;
      if (b.x < -lim || b.x > lim) { b.x = clamp(b.x, -lim, lim); b.vx = -b.vx; b.sway = 0; }
      b.rot += b.spin * dt;
      // la cima della torre (o la bocca del cono)
      if (!b.bounced) {
        const top = n ? scoopPos(n - 1, P) : { x: ctl.x, y: CONE_TOP + 0.1 };
        const dx = b.x - top.x, dy = b.y - top.y;
        // presa: la pallina tocca dall'alto la cima (due raggi = si toccano)
        const reach = n ? 1.55 : 1.3, contact = n ? 2.0 : 1.0;
        // aiuto: a poca distanza dalla cima la pallina scivola un poco verso il centro
        // (mai oltre la fascia delle palline, anche se la cima è più in là)
        if (dy < 3.4 && dy > 0 && Math.abs(dx) < 2.1) b.x += (clamp(top.x, -lim, lim) - b.x) * (1 - Math.exp(-dt * 2.4));
        if (dy <= contact && dy > -0.7 && Math.abs(dx) < reach) { balls.splice(i, 1); catchBall(b); continue; }
        // urto contro il fianco della torre (non dall'alto): rimbalza via e la spinge un poco
        let hit = false;
        for (let j = n - 1; j >= 0 && !hit; j--) {
          const p = scoopPos(j, P), ddx = b.x - p.x, ddy = b.y - p.y, d = Math.hypot(ddx, ddy);
          if (j === n - 1 && ddy > 0.4 && Math.abs(ddx) < reach) continue; // sopra la cima: è una presa, non un urto
          if (d < 1.9 && d > 0.001) {
            hit = true; b.bounced = true; b.vx = (ddx / d) * 5 + ctl.v * 0.3; b.vy = 3; b.sway = 0;
            b.x = p.x + (ddx / d) * 1.95;
            tower.om += -(ddx / d) * 0.22 / (tower.comY + 1);
            audio.bounce();
          }
        }
        // contro il cono
        if (!hit && b.y < CONE_TOP + 0.6 && b.y > CONE_TIP) {
          const halfW = 1.1 * (b.y - CONE_TIP) / (CONE_TOP - CONE_TIP) + 1;
          if (Math.abs(b.x - ctl.x) < halfW) { b.bounced = true; b.vx = Math.sign(b.x - ctl.x || 1) * 5; b.vy = 2.5; audio.bounce(); }
        }
      }
      // a terra, o uscita dal fondo dello schermo quando la vista è salita
      if (b.y < 1 || toY(b.y) > view.H + view.bp * view.s * 1.5) {
        balls.splice(i, 1);
        if (b.y < 1) { decals.push({ x: b.x, f: b.f, t: 0 }); if (decals.length > 8) decals.shift(); }
        audio.splat();
        if (state === 'playing') miss();
      }
    }
  }

  function stepDebris(dt) {
    collapseT += dt;
    const lim = Math.max(view.half + 1.5, view.cx / (view.bp * view.s) - 0.9); // i bordi dello schermo
    for (const d of debris) {
      if (!d.landed) {
        d.vy -= 26 * dt; d.x += d.vx * dt; d.y += d.vy * dt; d.rot += d.spin * dt;
        if (d.x < -lim || d.x > lim) { d.x = clamp(d.x, -lim, lim); d.vx *= -0.5; }
        if (d.y < 1) {
          d.y = 1;
          if (Math.abs(d.vy) < 3.2) { d.landed = true; d.vy = 0; d.vx *= 0.3; d.sqV -= 3; }
          else { d.vy = -d.vy * 0.32; d.vx *= 0.72; d.spin *= 0.55; d.sqV -= 2.5; }
        }
      } else {
        d.x += d.vx * dt; d.vx *= Math.pow(0.02, dt); d.spin *= Math.pow(0.05, dt); d.rot += d.spin * dt;
      }
      d.sqV += (-150 * (d.sq - (d.landed ? 0.78 : 1)) - 12 * d.sqV) * dt; d.sq += d.sqV * dt;
    }
    // le palline a terra non si compenetrano
    for (let i = 0; i < debris.length; i++) for (let j = i + 1; j < debris.length; j++) {
      const a = debris[i], b = debris[j], dx = b.x - a.x, dy = b.y - a.y, d = Math.hypot(dx, dy);
      if (d < 1.75 && d > 0.0001) { const push = (1.75 - d) / 2, nx = dx / d, ny = dy / d; a.x -= nx * push; b.x += nx * push; if (!a.landed) a.y -= ny * push; if (!b.landed) b.y += ny * push; if (a.y < 1) a.y = 1; if (b.y < 1) b.y = 1; }
    }
    if (state === 'collapse' && collapseT > 1.7 && !overShown) gameOver();
  }

  function stepParticles(dt) {
    for (let i = particles.length - 1; i >= 0; i--) {
      const p = particles[i];
      p.t += dt; if (p.t > p.life) { particles.splice(i, 1); continue; }
      p.vy -= 26 * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.rot += p.spin * dt;
    }
    for (const d of decals) d.t += dt;
    if (shake > 0) shake = Math.max(0, shake - dt);
  }

  /* ---------- Disegno ---------- */
  function drawSprite(sp, x, y, rot, sx, sy) {
    const sc = view.s / view.dpr, side = sp.side * sc, R = view.bp * view.s;
    ctx.save();
    ctx.translate(toX(x), toY(y)); ctx.rotate(rot);
    ctx.translate(0, R); ctx.scale(sx, sy); ctx.translate(0, -R);
    ctx.drawImage(sp.c, -side / 2, -sp.cy * sc, side, side);
    ctx.restore();
  }

  function render(time) {
    const { W, H, dpr } = view;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.drawImage(bg, 0, 0, W, H);
    if (shake > 0) ctx.translate(rand(-1, 1) * shake * 8, rand(-1, 1) * shake * 5);

    const R = view.bp * view.s;
    // il banco su cui sta tutto: una fascia appena più calda, che scende quando la vista sale
    const fy = toY(0);
    if (fy < H) {
      const gr = ctx.createLinearGradient(0, fy - 6, 0, fy + Math.max(40, H * 0.12));
      gr.addColorStop(0, 'rgba(226,203,170,0)'); gr.addColorStop(0.08, 'rgba(226,203,170,0.55)'); gr.addColorStop(1, 'rgba(214,186,150,0.72)');
      ctx.fillStyle = gr; ctx.fillRect(0, fy - 6, W, H - fy + 6);
      ctx.fillStyle = 'rgba(255,255,255,0.5)'; ctx.fillRect(0, fy - 6, W, 1.5);
    }
    // ombra a terra (si sposta con la torre)
    const lean = Math.sin(tower.th) * (tower.n * GAP * 0.35);
    ctx.fillStyle = 'rgba(90,55,25,0.16)';
    if (fy < H + R) ctx.beginPath(), ctx.ellipse(toX(ctl.x + lean * 0.5), fy - 2, R * (1.5 + Math.min(tower.n, 20) * 0.04), R * 0.28, 0, 0, Math.PI * 2), ctx.fill();
    // gelato caduto a terra
    for (const d of decals) {
      const a = Math.max(0, 1 - d.t / 2.2); if (!a) continue;
      ctx.globalAlpha = a * 0.85; ctx.fillStyle = FLAVOURS[d.f].shade;
      ctx.beginPath(); ctx.ellipse(toX(d.x), fy - R * 0.12, R * (0.9 + d.t * 0.12), R * 0.22, 0, 0, Math.PI * 2); ctx.fill();
      ctx.globalAlpha = 1;
    }
    // cono (si inclina appena con la torre)
    const cs = view.s / dpr;
    ctx.save();
    ctx.translate(toX(ctl.x), toY(CONE_TOP)); ctx.rotate(tower.th * 0.12 + clamp(ctl.v * 0.004, -0.05, 0.05));
    ctx.drawImage(cone.c, -cone.cx * cs, -cone.mouthY * cs, cone.w * cs, cone.h * cs);
    ctx.restore();
    // torre
    if (state === 'intro') drawDemo(time);
    else {
      const risk = tower.n ? Math.abs(tower.th) / CRIT(tower.n) : 0;
      const shiver = risk > 0.75 && !reduceMotion() ? (risk - 0.75) * 0.06 : 0;
      for (let i = 0; i < tower.n; i++) {
        const sc = tower.scoops[i], p = scoopPos(i, P);
        const sq = clamp(sc.sq, 0.55, 1.35), sx = 1 / Math.sqrt(sq);
        const slope = i ? (sc.bend - tower.scoops[i - 1].bend) * 0.5 : sc.bend * 0.4;
        drawSprite(sprites[sc.f], p.x + (shiver ? rand(-shiver, shiver) : 0), p.y, tower.th + sc.tilt * 0.5 + slope, sx, sq);
      }
      updateMeter(risk);
    }
    // il cono è sceso sotto lo schermo: un segnale in basso dice dov'è
    if (toY(CONE_TOP) > H - R * 0.6) drawConeMarker(toX(ctl.x), H);
    for (const b of balls) {
      const stretch = b.bounced ? 1 : 1.05;
      drawSprite(sprites[b.f], b.x, b.y, b.rot, 1 / Math.sqrt(stretch), stretch);
    }
    for (const d of debris) drawSprite(sprites[d.f], d.x, d.y, d.rot, 1 / Math.sqrt(clamp(d.sq, 0.6, 1.3)), clamp(d.sq, 0.6, 1.3));
    for (const p of particles) {
      const a = 1 - p.t / p.life;
      ctx.save(); ctx.globalAlpha = a; ctx.translate(toX(p.x), toY(p.y)); ctx.rotate(p.rot);
      ctx.fillStyle = p.col; const l = p.len * R, w = l * 0.32;
      ctx.beginPath(); ctx.roundRect(-l / 2, -w / 2, l, w, w / 2); ctx.fill();
      ctx.restore();
    }
  }

  function drawConeMarker(x, H) {
    const y = H - 18;
    ctx.save();
    ctx.translate(x, y);
    ctx.fillStyle = 'rgba(31,21,16,0.82)';
    ctx.beginPath(); ctx.roundRect(-26, -15, 52, 26, 13); ctx.fill();
    ctx.fillStyle = '#e2a75c';
    ctx.beginPath(); ctx.moveTo(-8, -8); ctx.lineTo(8, -8); ctx.lineTo(0, 7); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#f6a9bc'; ctx.beginPath(); ctx.arc(0, -9, 6, Math.PI, 0); ctx.fill();
    ctx.strokeStyle = '#fffdf8'; ctx.lineWidth = 2; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(14, -3); ctx.lineTo(18, 1); ctx.lineTo(22, -3); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(-22, -3); ctx.lineTo(-18, 1); ctx.lineTo(-14, -3); ctx.stroke();
    ctx.restore();
  }

  // nella schermata iniziale: una torre di tre palline che dondola piano
  function drawDemo(time) {
    const t = time / 1000;
    ctl.target = Math.sin(t * 0.45) * Math.min(2.2, view.half - 2);
    const th = Math.sin(t * 1.25) * 0.07;
    const f = [1, 0, 2];
    for (let i = 0; i < 3; i++) {
      const h = SEAT + i * GAP, wob = Math.sin(t * 2.4 - i * 0.7) * 0.06 * (i + 1) / 3;
      const lx = wob, x = ctl.x + lx * Math.cos(th) + h * Math.sin(th), y = CONE_TOP - lx * Math.sin(th) + h * Math.cos(th);
      const sq = 1 + Math.sin(t * 2.4 - i * 0.9) * 0.025;
      drawSprite(sprites[f[i]], x, y, th + wob * 0.4, 1 / Math.sqrt(sq), sq);
    }
  }

  let meterAngle = 0, meterDanger = false, lastVignette = '';
  function updateMeter(risk) {
    const ang = clamp(tower.n ? tower.th / CRIT(tower.n) : 0, -1, 1) * 78;
    if (Math.abs(ang - meterAngle) > 0.4) { meterAngle = ang; ui.needle.style.transform = `rotate(${ang.toFixed(1)}deg)`; }
    const danger = risk > 0.62;
    if (danger !== meterDanger) { meterDanger = danger; ui.meter.classList.toggle('is-danger', danger); }
    const v = risk > 0.55 ? Math.min(1, (risk - 0.55) / 0.45) : 0;
    const op = v ? (v * (0.75 + 0.25 * Math.sin(performance.now() / 90))).toFixed(2) : '0';
    if (op !== lastVignette) { lastVignette = op; ui.vignette.style.opacity = op; }
  }

  /* ---------- Telecamera ----------
     In partita la cima della torre resta al 42% dell'altezza utile: la vista prima si
     allontana un poco (fino a 0,78), poi sale con la torre. Così sopra la cima c'è sempre
     più di metà schermo per vedere arrivare la pallina. Al crollo torna giù a terra. */
  function updateCamera(dt) {
    const area = view.floorY - view.topPad;
    let sT, cT;
    if (state === 'collapse' || (state === 'over' && endReason === 'fall')) {
      let hi = CONE_TOP + 2;
      for (const d of debris) hi = Math.max(hi, d.y + 1.4);
      sT = clamp(area / (view.bp * (hi + 3)), 0.55, 1); cT = 0;
    } else {
      let top = CONE_TOP + 1.2;
      if (state === 'intro') top = CONE_TOP + SEAT + 2 * GAP + 1.2;
      else if (tower.n) top = CONE_TOP + SEAT + (tower.n - 1) * GAP + 1.2;
      sT = clamp(HEAD * area / (view.bp * top), S_MIN, 1);
      cT = Math.max(0, top - HEAD * area / (view.bp * sT));
    }
    const k = 1 - Math.exp(-dt * 2.6);
    view.s += (sT - view.s) * k;
    view.camY += (cT - view.camY) * k;
  }

  /* ---------- Ciclo ---------- */
  function frame(time) {
    raf = requestAnimationFrame(frame);
    const dt = Math.min(0.05, last ? (time - last) / 1000 : 0);
    last = time;
    if (state === 'paused') { render(time); return; }
    updateCamera(dt);
    acc += dt;
    let guard = 0;
    while (acc >= STEP && guard++ < 12) { step(STEP); acc -= STEP; }
    if (guard >= 12) acc = 0;
    render(time);
  }

  /* ---------- Comandi ---------- */
  function onPointerMove(e) {
    if (state !== 'playing' && state !== 'collapse') return;
    if (e.pointerType === 'mouse' || e.pointerType === 'pen') {
      ctl.target = clamp((e.clientX - view.cx) / (view.bp * view.s), -coneLim(), coneLim());
    } else if (e.pointerId === ctl.touchId) {
      const dx = e.clientX - ctl.lastX; ctl.lastX = e.clientX;
      ctl.target = clamp(ctl.target + dx / (view.bp * view.s) * 1.12, -coneLim(), coneLim());
    }
  }
  function onPointerDown(e) {
    if (e.target.closest('button')) return;
    if (e.pointerType !== 'mouse' && state === 'playing') {
      ctl.touchId = e.pointerId; ctl.lastX = e.clientX;
      try { canvas.setPointerCapture(e.pointerId); } catch (err) {}
    }
  }
  function onPointerUp(e) { if (e.pointerId === ctl.touchId) ctl.touchId = null; }
  function onKey(e) {
    if (!dlg || !dlg.open) return;
    const k = e.key;
    if (k === 'ArrowLeft' || k === 'a' || k === 'A') { ctl.left = true; e.preventDefault(); }
    else if (k === 'ArrowRight' || k === 'd' || k === 'D') { ctl.right = true; e.preventDefault(); }
    else if ((k === 'p' || k === 'P') && (state === 'playing' || state === 'paused')) { state === 'playing' ? pause() : resume(); }
    else if ((k === ' ' || k === 'Enter') && state === 'intro' && !(e.target.closest && e.target.closest('button'))) { e.preventDefault(); startGame(); }
  }
  function onKeyUp(e) {
    const k = e.key;
    if (k === 'ArrowLeft' || k === 'a' || k === 'A') ctl.left = false;
    if (k === 'ArrowRight' || k === 'd' || k === 'D') ctl.right = false;
  }
  function onCancel(e) {
    // Esc: in partita mette in pausa, altrimenti torna al sito
    e.preventDefault();
    if (state === 'playing') pause(); else close();
  }
  function onClick(e) {
    const b = e.target.closest('button');
    if (!b) return;
    audio.ensure();
    if (b.hasAttribute('data-play')) startGame();
    else if (b.hasAttribute('data-retry')) startGame();
    else if (b.hasAttribute('data-pause')) { audio.click(); pause(); }
    else if (b.hasAttribute('data-resume')) { audio.click(); resume(); }
    else if (b.hasAttribute('data-exit')) { audio.click(); close(); }
    else if (b.hasAttribute('data-sound')) { audio.setMuted(!audio.muted); updateSoundButton(); if (!audio.muted) audio.click(); }
  }
  function updateSoundButton() {
    for (const b of ui.sound) {
      b.setAttribute('aria-pressed', String(audio.muted));
      b.setAttribute('aria-label', audio.muted ? ui.S.soundOff : ui.S.soundOn);
      b.classList.toggle('is-muted', audio.muted);
    }
  }
  function pause() {
    if (state !== 'playing') return;
    state = 'paused'; ctl.left = ctl.right = false; ctl.touchId = null;
    dlg.classList.remove('is-playing');
    showScreen('pause');
  }
  function resume() {
    if (state !== 'paused') return;
    showScreen(null); state = 'playing'; last = 0; acc = 0;
    dlg.classList.add('is-playing');
  }
  const onVisibility = () => { if (document.hidden) pause(); };
  const onBlur = () => pause();
  let resizeT = 0;
  const onResize = () => { clearTimeout(resizeT); resizeT = setTimeout(() => { if (dlg) layout(); }, 90); };

  function showScreen(name) {
    for (const [key, el] of Object.entries(ui.screens)) {
      const on = key === name;
      if (on && el.hidden) {
        el.hidden = false;
        // translate e scale, non transform: transform cancellerebbe il centraggio del CSS
        // (translate(-50%, -50%)) e il riquadro comparirebbe più in basso per poi saltare al centro.
        if (!reduceMotion()) el.animate([{ opacity: 0, translate: '0 18px', scale: '.97' }, { opacity: 1, translate: '0 0', scale: '1' }], { duration: 420, easing: 'cubic-bezier(.2,.9,.25,1.15)' });
        const first = el.querySelector('[data-play], [data-resume], [data-retry]');
        if (first) setTimeout(() => first.focus({ preventScroll: true }), 30);
      } else if (!on && !el.hidden) el.hidden = true;
    }
    if (!name) canvas.focus({ preventScroll: true });
  }

  /* ---------- Il sito sotto: fermo mentre si gioca ----------
     Le animazioni del sito (GSAP: nastro, prodotti dell'apertura, scorrimento morbido) si
     fermano e la pagina sotto smette di essere disegnata: tutta la macchina lavora per il
     gioco. All'uscita tutto riparte da dove era. */
  let sitePaused = false;
  function pauseSite() {
    if (sitePaused) return;
    sitePaused = true;
    const g = window.gsap;
    if (g) { try { g.globalTimeline.pause(); g.ticker.sleep(); } catch (e) {} }
    document.documentElement.classList.add('sit-covered');
    document.dispatchEvent(new CustomEvent('sweet:site-pause', { detail: true }));
  }
  function resumeSite() {
    if (!sitePaused) return;
    sitePaused = false;
    document.documentElement.classList.remove('sit-covered');
    const g = window.gsap;
    if (g) { try { g.ticker.wake(); g.globalTimeline.resume(); } catch (e) {} }
    document.dispatchEvent(new CustomEvent('sweet:site-pause', { detail: false }));
  }

  /* ---------- Apertura e chiusura ---------- */
  function open(o = {}) {
    if (dlg && dlg.open) return;
    opts = o;
    returnFocus = o.returnFocus || document.activeElement;
    savedScroll = window.scrollY;
    build();
    state = 'intro';
    resetGame();
    ui.hud.hidden = true; ui.corner.hidden = false;
    dlg.showModal();
    layout();
    document.documentElement.classList.add('sit-lock');
    addEventListener('resize', onResize);
    document.addEventListener('keydown', onKey, true);
    document.addEventListener('keyup', onKeyUp, true);
    document.addEventListener('visibilitychange', onVisibility);
    addEventListener('blur', onBlur);
    last = 0; acc = 0; raf = requestAnimationFrame(frame);
    // l'ingresso: un cerchio che si apre dal punto della ricerca, poi il titolo che «cade» come le palline
    const ox = o.origin ? o.origin.x : view.W / 2, oy = o.origin ? o.origin.y : view.H * 0.2;
    const r = Math.hypot(Math.max(ox, view.W - ox), Math.max(oy, view.H - oy));
    if (reduceMotion()) dlg.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 220 }).finished.then(pauseSite, pauseSite);
    else {
      dlg.animate([{ clipPath: `circle(0px at ${ox}px ${oy}px)` }, { clipPath: `circle(${r}px at ${ox}px ${oy}px)` }], { duration: 780, easing: 'cubic-bezier(.7,0,.2,1)' }).finished.then(pauseSite, pauseSite);
      const start = ui.screens.start;
      const parts = [start.querySelector('.sit-eyebrow'), ...start.querySelectorAll('.sit-title span'), start.querySelector('.sit-tagline'), start.querySelector('.sit-button'), start.querySelector('.sit-how'), start.querySelector('.sit-hint')].filter(Boolean);
      parts.forEach((el, i) => el.animate([
        { opacity: 0, transform: 'translateY(-46px) rotate(-5deg) scale(.92)' },
        { opacity: 1, transform: 'translateY(6px) rotate(1deg) scale(1.02)', offset: 0.7 },
        { opacity: 1, transform: 'none' },
      ], { duration: 640, delay: 380 + i * 70, easing: 'cubic-bezier(.2,.8,.3,1)', fill: 'backwards' }));
    }
  }

  function close() {
    if (!dlg) return;
    const d = dlg, o = opts;
    state = 'closing';
    resumeSite(); // la pagina deve riapparire mentre il cerchio si chiude
    const finish = () => {
      cancelAnimationFrame(raf); raf = 0;
      removeEventListener('resize', onResize);
      document.removeEventListener('keydown', onKey, true);
      document.removeEventListener('keyup', onKeyUp, true);
      document.removeEventListener('visibilitychange', onVisibility);
      removeEventListener('blur', onBlur);
      document.documentElement.classList.remove('sit-lock');
      if (d.open) d.close();
      d.remove();
      // chiudendo una finestra il browser può riportare il fuoco dov'era scorrendo la pagina:
      // la si rimette esattamente dove si trovava all'apertura del gioco
      if (Math.abs(window.scrollY - savedScroll) > 1) window.scrollTo({ top: savedScroll, behavior: 'instant' });
      if (dlg === d) { dlg = null; ui = null; canvas = null; ctx = null; }
      if (audio.ctx && audio.ctx.state === 'running') audio.ctx.suspend().catch(() => {});
      if (returnFocus && document.contains(returnFocus) && returnFocus.focus) returnFocus.focus({ preventScroll: true });
      if (typeof o.onClose === 'function') o.onClose();
    };
    if (reduceMotion()) { finish(); return; }
    const ox = o.origin ? o.origin.x : view.W / 2, oy = o.origin ? o.origin.y : view.H * 0.2;
    const r = Math.hypot(Math.max(ox, view.W - ox), Math.max(oy, view.H - oy));
    const anim = d.animate([{ clipPath: `circle(${r}px at ${ox}px ${oy}px)` }, { clipPath: `circle(0px at ${ox}px ${oy}px)` }], { duration: 520, easing: 'cubic-bezier(.7,0,.3,1)', fill: 'forwards' });
    anim.finished.then(finish, finish);
  }

  /* ---------- Stile (solo quando il gioco si apre) ---------- */
  const css = `
  .sit-lock, .sit-lock body { overflow: hidden !important }
  .sit-covered body > :not(.sit) { visibility: hidden !important }
  .sit { position: fixed; inset: 0; width: 100%; height: 100%; max-width: none; max-height: none; margin: 0; padding: 0; border: 0; background: #f7efe2; color: #1f1510; overflow: hidden; touch-action: none; overscroll-behavior: contain; -webkit-user-select: none; user-select: none; font-family: var(--sans, system-ui, sans-serif); -webkit-tap-highlight-color: transparent }
  .sit::backdrop { background: transparent }
  .sit[open] { display: block }
  .sit.is-playing { cursor: none }
  .sit-canvas { position: absolute; inset: 0; width: 100%; height: 100%; display: block }
  .sit-vignette { position: absolute; inset: 0; pointer-events: none; opacity: 0; background: radial-gradient(120% 90% at 50% 60%, transparent 55%, rgba(232,96,122,.42) 100%) }
  .sit-hud { position: absolute; inset: 0 0 auto; display: grid; grid-template-columns: 1fr auto 1fr; align-items: start; gap: 10px; padding: calc(14px + env(safe-area-inset-top)) calc(16px + env(safe-area-inset-right)) 0 calc(16px + env(safe-area-inset-left)); pointer-events: none }
  .sit-hud[hidden], .sit-screen[hidden], .sit-corner[hidden], .sit-badge[hidden], .sit-message[hidden], .sit-best-line[hidden] { display: none }
  .sit-score { display: grid; justify-items: start; line-height: 1 }
  .sit-label { font-family: var(--xc, sans-serif); font-weight: 800; font-size: 12px; letter-spacing: .14em; text-transform: uppercase; opacity: .72 }
  .sit-num { font-family: var(--display, Georgia, serif); font-size: clamp(40px, 6vw, 60px); font-weight: 800; line-height: .95; margin-top: 4px; display: inline-block; transform-origin: 30% 70% }
  .sit-best { font-family: var(--xc, sans-serif); font-weight: 700; font-size: 13px; letter-spacing: .1em; text-transform: uppercase; margin-top: 6px; opacity: .78 }
  .sit-best b { font-weight: 800 }
  .sit-lives { display: flex; gap: 5px; margin-top: 8px }
  .sit-lives i { width: 15px; height: 15px; border-radius: 50%; background: radial-gradient(circle at 35% 30%, #ffe3ea, #f6a9bc 45%, #d9668a); box-shadow: 0 2px 0 rgba(31,21,16,.18); transition: background .25s, opacity .25s, transform .25s }
  .sit-lives i.is-lost { background: none; box-shadow: inset 0 0 0 2px rgba(31,21,16,.28); opacity: .7 }
  .sit-meter { display: grid; justify-items: center; gap: 2px; padding-top: 4px }
  .sit-meter svg { width: clamp(84px, 11vw, 124px); height: auto; overflow: visible }
  .sit-meter-track { fill: none; stroke: rgba(31,21,16,.14); stroke-width: 9; stroke-linecap: round }
  .sit-meter-safe { fill: none; stroke: #a3b86c; stroke-width: 9; stroke-linecap: round; opacity: .9 }
  .sit-needle { transform-origin: 60px 60px; transition: none }
  .sit-needle path { stroke: #1f1510; stroke-width: 4.5; stroke-linecap: round }
  .sit-needle circle { fill: #1f1510 }
  .sit-meter.is-danger .sit-needle path { stroke: #e8607a }
  .sit-meter.is-danger .sit-needle circle { fill: #e8607a }
  .sit-meter.is-danger .sit-label { color: #c03a58; opacity: 1 }
  .sit-tools { display: flex; justify-content: flex-end; gap: 8px; pointer-events: auto }
  .sit-icon { display: grid; place-items: center; width: 46px; height: 46px; padding: 0; border: 2.5px solid #1f1510; border-radius: 50%; background: rgba(255,253,248,.86); color: #1f1510; cursor: pointer; transition: background-color .2s, transform .2s cubic-bezier(.2,1.4,.4,1) }
  .sit-icon:hover { background: #f2d44c; transform: scale(1.06) }
  .sit-icon:focus-visible, .sit-button:focus-visible { outline: 3px solid #1f1510; outline-offset: 3px }
  .sit-icon svg { width: 22px; height: 22px; fill: currentColor }
  .sit-icon .sit-mute { display: none }
  .sit-icon.is-muted .sit-mute { display: inline } .sit-icon.is-muted .sit-wave { display: none }
  .sit-corner { position: absolute; top: calc(14px + env(safe-area-inset-top)); right: calc(16px + env(safe-area-inset-right)); z-index: 2; display: flex; gap: 8px }
  .sit-screen { position: absolute; left: 50%; transform: translateX(-50%); width: min(560px, calc(100% - 32px)); display: flex; flex-direction: column; align-items: center; text-align: center }
  .sit-start { top: max(7vh, calc(60px + env(safe-area-inset-top))) }
  .sit-eyebrow { margin: 0 0 14px; padding: 7px 14px 6px; border-radius: 999px; background: #1f1510; color: #f2d44c; font-family: var(--xc, sans-serif); font-weight: 800; font-size: 13px; letter-spacing: .16em; rotate: -2deg }
  .sit-title { margin: 0; display: grid; font-family: var(--display, Georgia, serif); font-weight: 800; font-size: clamp(46px, 8.4vw, 104px); line-height: .9; letter-spacing: 0; text-transform: uppercase; color: #1f1510 }
  .sit-title span:last-child { color: #e8607a }
  .sit-tagline { margin: 16px 0 26px; font-family: var(--xc, sans-serif); font-weight: 800; font-size: clamp(17px, 2vw, 22px); letter-spacing: .06em; text-transform: uppercase }
  .sit-button { display: inline-flex; align-items: center; justify-content: center; min-height: 62px; padding: 14px 34px; border: 3px solid #1f1510; border-radius: 999px; background: #1f1510; color: #fffdf8; font-family: var(--xc, sans-serif); font-weight: 800; font-size: 20px; letter-spacing: .08em; text-transform: uppercase; cursor: pointer; box-shadow: 0 10px 24px -12px rgba(31,21,16,.6); transition: background-color .2s, color .2s, transform .25s cubic-bezier(.2,1.5,.4,1) }
  .sit-button:hover { background: #f2d44c; color: #1f1510; transform: translateY(-2px) scale(1.03) }
  .sit-button:active { transform: scale(.97) }
  .sit-ghost { background: rgba(255,253,248,.7); color: #1f1510; box-shadow: none }
  .sit-best-line { margin: 14px 0 0; font-family: var(--xc, sans-serif); font-weight: 700; font-size: 14px; letter-spacing: .1em; text-transform: uppercase }
  .sit-how { list-style: none; display: flex; gap: 10px; justify-content: center; margin: 26px 0 10px; padding: 0 }
  .sit-how li { display: flex; align-items: center; gap: 8px; padding: 8px 14px 8px 10px; border-radius: 999px; background: rgba(255,253,248,.78); border: 2px solid rgba(31,21,16,.12); font-family: var(--xc, sans-serif); font-weight: 800; font-size: 13px; letter-spacing: .08em; text-transform: uppercase }
  .sit-how svg { height: 24px; width: auto }
  .sit-hint { margin: 6px 0 0; max-width: 40ch; font-size: 15px; line-height: 1.45; opacity: .8 }
  .sit-card { top: 50%; transform: translate(-50%, -50%); padding: 30px 28px 28px; border-radius: 30px; background: rgba(255,253,248,.84); -webkit-backdrop-filter: blur(10px); backdrop-filter: blur(10px); box-shadow: 0 30px 70px -30px rgba(31,21,16,.45), 0 0 0 2px rgba(31,21,16,.06) }
  .sit-card-title { margin: 0; display: grid; gap: 6px; font-family: var(--display, Georgia, serif); font-weight: 800; font-size: clamp(34px, 5.4vw, 58px); line-height: .95; text-transform: uppercase }
  .sit-card-title span:last-child:not(:first-child) { font-size: .62em; color: #e8607a }
  .sit-badge { margin: 0 0 14px; padding: 8px 16px 7px; border-radius: 999px; background: #f2d44c; color: #1f1510; font-family: var(--xc, sans-serif); font-weight: 800; font-size: 15px; letter-spacing: .14em; text-transform: uppercase; rotate: -3deg; box-shadow: 0 6px 0 rgba(31,21,16,.12) }
  .sit-message { margin: 14px 0 0; font-family: var(--xc, sans-serif); font-weight: 800; font-size: 17px; letter-spacing: .06em; text-transform: uppercase; color: #6a4a18 }
  .sit-stats { display: flex; gap: 14px; justify-content: center; margin: 20px 0 24px }
  .sit-stats div { min-width: 132px; padding: 12px 18px; border-radius: 20px; background: #fffdf8; border: 2px solid rgba(31,21,16,.1) }
  .sit-stats dt { font-family: var(--xc, sans-serif); font-weight: 800; font-size: 12px; letter-spacing: .12em; text-transform: uppercase; opacity: .7 }
  .sit-stats dd { margin: 4px 0 0; font-family: var(--display, Georgia, serif); font-weight: 800; font-size: 44px; line-height: 1 }
  .sit-actions { display: flex; flex-wrap: wrap; gap: 12px; justify-content: center }
  .sit-toast { position: absolute; left: 50%; top: calc(108px + env(safe-area-inset-top)); margin: 0; padding: 10px 20px 9px; border-radius: 999px; background: #1f1510; color: #f2d44c; font-family: var(--display, Georgia, serif); font-weight: 800; font-size: clamp(18px, 2.4vw, 26px); text-transform: uppercase; white-space: nowrap; opacity: 0; pointer-events: none; transform: translateX(-50%) }
  @media (max-width: 560px) {
    .sit-hud { grid-template-columns: auto 1fr auto; gap: 6px }
    .sit-icon { width: 40px; height: 40px } .sit-icon svg { width: 19px; height: 19px }
    .sit-tools { gap: 6px }
    .sit-how { margin-top: 20px }
    .sit-stats div { min-width: 0; flex: 1 }
    .sit-card { padding: 24px 18px 20px }
    .sit-button { min-height: 56px; padding: 12px 26px; font-size: 18px }
  }
  @media (max-height: 560px) { .sit-start { top: 16px } .sit-title { font-size: clamp(36px, 7vw, 64px) } .sit-how, .sit-hint { display: none } }
  `;
  const style = document.createElement('style');
  style.textContent = css;
  document.head.append(style);

  window.SweetIceCreamTower = {
    open, close,
    isOpen: () => !!(dlg && dlg.open),
    // per i test automatici: lo stato della partita, in sola lettura
    debug: () => ({
      state, n: tower.n, th: tower.th, crit: CRIT(Math.max(1, tower.n)), coneX: ctl.x, target: ctl.target, half: view.half, coneLim: coneLim(), s: view.s, camY: view.camY, best, debris: debris.length, misses, finalCount,
      balls: balls.map(b => ({ x: b.x, y: b.y, sx: toX(b.x), sy: toY(b.y), bounced: b.bounced })),
      top: tower.n ? (() => { const p = scoopPos(tower.n - 1, { x: 0, y: 0 }); return { x: p.x, y: p.y, sx: toX(p.x), sy: toY(p.y) }; })() : { x: ctl.x, y: CONE_TOP, sx: toX(ctl.x), sy: toY(CONE_TOP) },
      toScreenX: x => toX(x),
    }),
  };
})();
