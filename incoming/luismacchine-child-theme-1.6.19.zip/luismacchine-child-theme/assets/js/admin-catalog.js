( function ( $ ) {
	'use strict';

	const description = document.querySelector( '#luismacchine-catalog-descrizione textarea' );
	if ( description ) {
		const resizeDescription = function () {
			if ( ! description.getClientRects().length ) { return; }
			description.style.height = 'auto';
			description.style.height = description.scrollHeight + 2 + 'px';
		};
		description.addEventListener( 'input', resizeDescription );
		window.addEventListener( 'resize', resizeDescription );
		if ( window.ResizeObserver ) {
			new ResizeObserver( resizeDescription ).observe( description.parentElement );
		}
		resizeDescription();
	}

	const input = $( '#_lm_gallery_ids' );
	const preview = $( '[data-gallery-preview]' );

	if ( ! input.length ) {
		return;
	}

	function renderPreview( attachments, append ) {
		if ( ! append ) {
			preview.empty();
		}
		preview.find( '.lm-admin-gallery-empty' ).remove();
		if ( ! attachments.length ) {
			$( '<p>', { class: 'lm-admin-gallery-empty', text: luismacchineCatalogAdmin.emptyGallery } ).appendTo( preview );
			return;
		}
		attachments.forEach( function ( attachment ) {
			const source = attachment.sizes && attachment.sizes.thumbnail ? attachment.sizes.thumbnail.url : attachment.url;
			const item = $( '<div>', { class: 'lm-admin-gallery-item', 'data-gallery-item': '', 'data-attachment-id': attachment.id } );
			$( '<img>', { src: source, alt: '', loading: 'lazy' } ).appendTo( item );
			$( '<button>', {
				class: 'button',
				type: 'button',
				text: luismacchineCatalogAdmin.removeImage,
				'aria-label': luismacchineCatalogAdmin.removeImage + ' ' + ( attachment.title || '' ),
				'data-gallery-remove': '',
			} ).appendTo( item );
			item.appendTo( preview );
		} );
	}

	function galleryIds() {
		return input.val().split( ',' ).filter( Boolean ).map( Number );
	}

	$( '[data-gallery-select]' ).on( 'click', function () {
		const frame = wp.media( {
			title: luismacchineCatalogAdmin.frameTitle,
			button: { text: luismacchineCatalogAdmin.frameButton },
			library: { type: 'image' },
			multiple: 'add',
		} );
		frame.on( 'select', function () {
			// Adding a selection must never replace photos already in the gallery.
			const ids = galleryIds();
			const attachments = frame.state().get( 'selection' ).toJSON().filter( function ( attachment ) {
				const id = Number( attachment.id );
				if ( ! Number.isInteger( id ) || id <= 0 || ids.includes( id ) ) {
					return false;
				}
				ids.push( id );
				return true;
			} );
			if ( ! attachments.length ) {
				return;
			}
			input.val( ids.join( ',' ) );
			renderPreview( attachments, true );
		} );
		frame.open();
	} );

	preview.on( 'click', '[data-gallery-remove]', function () {
		const removedId = Number( $( this ).closest( '[data-gallery-item]' ).data( 'attachment-id' ) );
		const remainingIds = galleryIds().filter( function ( id ) { return id !== removedId; } );
		input.val( remainingIds.join( ',' ) );
		$( this ).closest( '[data-gallery-item]' ).remove();
		if ( ! remainingIds.length ) {
			$( '<p>', { class: 'lm-admin-gallery-empty', text: luismacchineCatalogAdmin.emptyGallery } ).appendTo( preview );
		}
	} );

	$( '[data-gallery-clear]' ).on( 'click', function () {
		if ( input.val() && ! window.confirm( luismacchineCatalogAdmin.confirmGalleryClear ) ) {
			return;
		}
		input.val( '' );
		renderPreview( [] );
	} );
} )( jQuery );
