( function () {
	'use strict';

	// Move the actual card, not a duplicate: keyboard and reading order follow mobile layout.
	const detailTop = document.querySelector( '.lm-detail__top' );
	const visualColumn = document.querySelector( '.lm-detail__visual-column' );
	const summaryCard = document.querySelector( '.lm-detail__summary' );
	if ( detailTop && visualColumn && summaryCard ) {
		const stackedDetail = window.matchMedia( '(max-width: 820px)' );
		const syncDetailOrder = function () {
			if ( stackedDetail.matches ) {
				const sections = visualColumn.querySelector( '.lm-detail__description, .lm-detail__accordions' );
				visualColumn.insertBefore( summaryCard, sections );
			} else {
				detailTop.appendChild( summaryCard );
			}
		};
		syncDetailOrder();
		stackedDetail.addEventListener( 'change', syncDetailOrder );
	}

	const dialog = document.querySelector( '[data-gallery-dialog]' );
	if ( ! dialog || typeof dialog.showModal !== 'function' ) {
		return;
	}

	const slides = Array.from( dialog.querySelectorAll( '[data-gallery-slide]' ) );
	const openers = Array.from( document.querySelectorAll( '[data-gallery-open]' ) );
	const counter = dialog.querySelector( '[data-gallery-counter]' );
	const closeButton = dialog.querySelector( '[data-gallery-close]' );
	const previousButton = dialog.querySelector( '[data-gallery-previous]' );
	const nextButton = dialog.querySelector( '[data-gallery-next]' );
	let currentIndex = 0;
	let activeTrigger = null;

	if ( ! slides.length || ! openers.length ) {
		return;
	}

	function showSlide( index ) {
		currentIndex = ( index + slides.length ) % slides.length;
		slides.forEach( function ( slide, slideIndex ) {
			slide.hidden = slideIndex !== currentIndex;
		} );
		counter.textContent = ( currentIndex + 1 ) + ' / ' + slides.length;
		previousButton.disabled = slides.length < 2;
		nextButton.disabled = slides.length < 2;
	}

	openers.forEach( function ( opener ) {
		opener.addEventListener( 'click', function ( event ) {
			event.preventDefault();
			activeTrigger = opener;
			showSlide( Number( opener.dataset.galleryIndex ) || 0 );
			dialog.showModal();
			closeButton.focus();
		} );
	} );

	closeButton.addEventListener( 'click', function () {
		dialog.close();
	} );
	previousButton.addEventListener( 'click', function () {
		showSlide( currentIndex - 1 );
	} );
	nextButton.addEventListener( 'click', function () {
		showSlide( currentIndex + 1 );
	} );
	dialog.addEventListener( 'click', function ( event ) {
		if ( event.target === dialog ) {
			dialog.close();
		}
	} );
	dialog.addEventListener( 'close', function () {
		if ( activeTrigger ) {
			activeTrigger.focus();
		}
	} );
	document.addEventListener( 'keydown', function ( event ) {
		if ( ! dialog.open ) {
			return;
		}
		if ( 'ArrowLeft' === event.key ) {
			event.preventDefault();
			showSlide( currentIndex - 1 );
		} else if ( 'ArrowRight' === event.key ) {
			event.preventDefault();
			showSlide( currentIndex + 1 );
		}
	} );
} )();
