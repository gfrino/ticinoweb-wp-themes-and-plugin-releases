(() => {
	'use strict';

	const schedule = document.querySelector('[data-hours-timezone]');
	if (!schedule) return;

	let formatter;
	try {
		formatter = new Intl.DateTimeFormat('en-US', {
			weekday: 'long',
			timeZone: schedule.dataset.hoursTimezone,
		});
	} catch (_) {
		// Keep the server-rendered day when this browser cannot use the site timezone.
		return;
	}

	const rows = schedule.querySelectorAll('[data-day]');
	const updateToday = () => {
		const today = formatter.format(new Date()).toLowerCase();
		rows.forEach((row) => {
			const active = row.dataset.day === today;
			row.classList.toggle('is-today', active);
			row.querySelector('.lm-opening-hours__today').hidden = !active;
			if (active) row.setAttribute('aria-current', 'date');
			else row.removeAttribute('aria-current');
		});
	};

	updateToday();
	// Refresh cached HTML and handle midnight without reloading the page.
	window.setInterval(() => {
		if (!document.hidden) updateToday();
	}, 30000);
	document.addEventListener('visibilitychange', () => {
		if (!document.hidden) updateToday();
	});
	window.addEventListener('pageshow', updateToday);
})();
