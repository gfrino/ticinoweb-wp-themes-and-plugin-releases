/* Parent cookie names/markup remain authoritative. No optional execution before consent. */
document.addEventListener('DOMContentLoaded', function () {
    'use strict';
    var banner = document.getElementById('tw-cookie-banner');
    var modal = document.getElementById('tw-cookie-modal');
    if (!banner || !modal) return;
    var analytics = document.getElementById('tw-cookie-opt-analytics');
    var opener = null, started = false;
    function read(name) {
        var item = document.cookie.split('; ').find(function (v) { return v.indexOf(name + '=') === 0; });
        try { return item ? decodeURIComponent(item.slice(name.length + 1)) : ''; } catch (e) { return ''; }
    }
    function preferences() {
        try { return JSON.parse(read('tw_cookie_preferences')) || {}; } catch (e) { return {}; }
    }
    function write(name, value) {
        document.cookie = name + '=' + encodeURIComponent(value) + '; Max-Age=31536000; Path=/; SameSite=Lax' + (location.protocol === 'https:' ? '; Secure' : '');
    }
    function clearStats() {
        try { localStorage.removeItem('tw_stats'); } catch (e) { /* Storage may be disabled. */ }
    }
    function startStats() {
        if (started || !read('tw_cookie_consent') || preferences().analytics !== true) return;
        var template = document.getElementById('lm-consented-statistics');
        if (!template) return;
        template.content.querySelectorAll('script').forEach(function (source) {
            var script = document.createElement('script');
            script.textContent = source.textContent;
            document.body.appendChild(script);
        });
        started = true;
    }
    function close() {
        modal.classList.remove('show');
        modal.setAttribute('aria-hidden', 'true');
        if (opener) opener.focus();
    }
    function open(event) {
        opener = event.currentTarget;
        var prefs = preferences();
        analytics.checked = prefs.analytics === true;
        modal.classList.add('show');
        modal.setAttribute('aria-hidden', 'false');
        document.getElementById('tw-cookie-modal-close').focus();
    }
    function save(prefs, choice) {
        var old = preferences();
        write('tw_cookie_preferences', JSON.stringify(prefs));
        write('tw_cookie_consent', choice);
        banner.classList.remove('show');
        banner.hidden = true;
        close();
        if (!prefs.analytics) clearStats();
        // Stop previously installed listeners/GA immediately after revocation.
        // The server guard rejects pending statistics requests with the new cookie.
        if ((old.analytics && !prefs.analytics) || (old.marketing && !prefs.marketing)) {
            location.reload();
            return;
        }
        startStats();
        if (prefs.analytics && typeof window.twLoadGA === 'function') window.twLoadGA();
    }
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');
    modal.setAttribute('aria-hidden', 'true');
    var title = modal.querySelector('h3');
    title.id = 'lm-cookie-title';
    modal.setAttribute('aria-labelledby', title.id);
    document.getElementById('tw-cookie-modal-close').setAttribute('aria-label', lmConsentLabels.close);
    analytics.checked = false;
    // Retire a previously stored marketing opt-in without changing analytics.
    if (preferences().marketing === true) {
        var existing = preferences();
        existing.marketing = false;
        write('tw_cookie_preferences', JSON.stringify(existing));
    }
    banner.hidden = !!read('tw_cookie_consent');
    if (!banner.hidden) banner.classList.add('show');
    if (read('tw_cookie_consent') && preferences().analytics === true) startStats(); else clearStats();
    document.getElementById('tw-cookie-customize').addEventListener('click', open);
    document.querySelectorAll('[data-lm-cookie-preferences]').forEach(function (button) { button.addEventListener('click', open); });
    document.getElementById('tw-cookie-modal-close').addEventListener('click', close);
    document.getElementById('tw-cookie-modal-overlay').addEventListener('click', close);
    document.getElementById('tw-cookie-accept').addEventListener('click', function () { save({ analytics: true, marketing: false }, 'accepted'); });
    ['tw-cookie-decline', 'tw-cookie-save-necessary'].forEach(function (id) {
        document.getElementById(id).addEventListener('click', function () { save({ analytics: false, marketing: false }, 'declined'); });
    });
    document.getElementById('tw-cookie-save-preferences').addEventListener('click', function () {
        save({ analytics: analytics.checked, marketing: false }, 'custom');
    });
    modal.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') { event.preventDefault(); close(); }
        if (event.key !== 'Tab') return;
        var items = Array.from(modal.querySelectorAll('button, input:not(:disabled), a[href]')).filter(function (el) { return el.getClientRects().length; });
        var first = items[0], last = items[items.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    });
});
