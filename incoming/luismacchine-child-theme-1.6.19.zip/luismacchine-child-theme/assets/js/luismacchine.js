( function () {
	'use strict';
	document.documentElement.classList.add( 'js' );

	if ( window.gsap && window.ScrollTrigger ) {
		window.gsap.registerPlugin( window.ScrollTrigger );
		document.documentElement.classList.add( 'gsap-ready' );
	}

	const menuToggle = document.querySelector( '[data-menu-toggle]' );
	const menu = document.querySelector( '[data-menu]' );
	const header = document.querySelector( '[data-header]' );
	const adminToolbar = document.getElementById( 'wpadminbar' );
	let headerFramePending = false;

	const updateHeader = function () {
		if ( ! header ) { return; }
		const currentScrollY = Math.max( window.scrollY, 0 );
		const menuOpen = document.body.classList.contains( 'lm-menu-open' );
		// WordPress scrolls its toolbar away below 601px; reserve only its visible height.
		if ( adminToolbar ) {
			header.style.top = Math.max( 0, adminToolbar.getBoundingClientRect().bottom ) + 'px';
		}

		header.classList.toggle( 'is-scrolled', currentScrollY > 18 || menuOpen );
		headerFramePending = false;
	};

	if ( header ) {
		updateHeader();
		window.addEventListener( 'resize', updateHeader, { passive: true } );
		window.addEventListener( 'scroll', function () {
			if ( headerFramePending ) { return; }
			headerFramePending = true;
			window.requestAnimationFrame( updateHeader );
		}, { passive: true } );
	}

	if ( menuToggle && menu ) {
		const desktopMenu = window.matchMedia( '(min-width: 821px)' );
		const syncMenuAccess = function () {
			menu.inert = ! desktopMenu.matches && ! menu.classList.contains( 'is-open' );
		};
		const menuFocusable = function () { return [ menuToggle ].concat( Array.from( menu.querySelectorAll( 'a[href]' ) ) ); };
		const closeMenu = function () {
			menu.classList.remove( 'is-open' );
			menuToggle.setAttribute( 'aria-expanded', 'false' );
			document.body.classList.remove( 'lm-menu-open' );
			syncMenuAccess();
			updateHeader();
			const label = menuToggle.querySelector( '.screen-reader-text' );
			if ( label && window.luismacchineTheme ) { label.textContent = window.luismacchineTheme.strings.menuOpen; }
		};
		menuToggle.addEventListener( 'click', function () {
			const open = 'true' !== menuToggle.getAttribute( 'aria-expanded' );
			menu.classList.toggle( 'is-open', open );
			menuToggle.setAttribute( 'aria-expanded', String( open ) );
			document.body.classList.toggle( 'lm-menu-open', open );
			syncMenuAccess();
			updateHeader();
			const label = menuToggle.querySelector( '.screen-reader-text' );
			if ( label && window.luismacchineTheme ) { label.textContent = open ? window.luismacchineTheme.strings.menuClose : window.luismacchineTheme.strings.menuOpen; }
			if ( open ) {
				const firstLink = menu.querySelector( 'a' );
				if ( firstLink ) { firstLink.focus(); }
			}
		} );
		document.addEventListener( 'keydown', function ( event ) {
			if ( 'Escape' === event.key && menu.classList.contains( 'is-open' ) ) {
				closeMenu();
				menuToggle.focus();
			}
			if ( 'Tab' === event.key && menu.classList.contains( 'is-open' ) ) {
				const items = menuFocusable();
				const first = items[ 0 ];
				const last = items[ items.length - 1 ];
				if ( event.shiftKey && document.activeElement === first ) { event.preventDefault(); last.focus(); }
				else if ( ! event.shiftKey && document.activeElement === last ) { event.preventDefault(); first.focus(); }
			}
		} );
		menu.addEventListener( 'click', function ( event ) { if ( event.target.closest( 'a' ) ) { closeMenu(); } } );
		const closeAtDesktop = function ( event ) { if ( event.matches ) { closeMenu(); } syncMenuAccess(); };
		if ( desktopMenu.addEventListener ) { desktopMenu.addEventListener( 'change', closeAtDesktop ); }
		else { desktopMenu.addListener( closeAtDesktop ); }
		syncMenuAccess();
	}

	const intro = document.querySelector( '[data-intro]' );
	const hero = document.querySelector( '[data-hero]' );
	const heroMedia = document.querySelector( '[data-hero-media]' );
	const reduceMotion = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
	const gsap = window.gsap;
	let introSeen = false;

	try { introSeen = '1' === sessionStorage.getItem( 'lmIntroSeen' ); } catch ( error ) { introSeen = false; }

	const rememberIntro = function () {
		try { sessionStorage.setItem( 'lmIntroSeen', '1' ); } catch ( error ) {}
	};

	if ( intro && ! reduceMotion && ! introSeen ) {
		intro.hidden = false;
		document.body.classList.add( 'lm-intro-open' );
		const obscured = document.querySelectorAll( '.lm-header, main, .lm-footer' );
		obscured.forEach( function ( element ) { element.inert = true; } );
		let closing = false;
		let autoClose;
		let introTimeline;

		const close = function () {
			if ( closing ) { return; }
			closing = true;
			clearTimeout( autoClose );
			if ( introTimeline ) { introTimeline.kill(); }
			rememberIntro();

			const finish = function () {
				intro.hidden = true;
				document.body.classList.remove( 'lm-intro-open' );
				obscured.forEach( function ( element ) { element.inert = false; } );
			};

			if ( gsap && hero ) {
				const heroElements = hero.querySelectorAll( '.lm-hero__content > *, .lm-hero__scroll' );
				gsap.timeline( { defaults: { ease: 'power3.inOut' }, onComplete: finish } )
					.to( '.lm-intro__signature, .lm-intro__progress', { autoAlpha: 0, y: 8, duration: 0.22, stagger: 0.02 } )
					.to( '.lm-intro__logo', { scale: 0.94, autoAlpha: 0, filter: 'blur(7px)', duration: 0.5 }, 0.08 )
					.to( '.lm-intro__light', { scale: 1.35, autoAlpha: 0, duration: 0.5 }, 0.08 )
					.to( intro, { autoAlpha: 0, duration: 0.62, ease: 'power2.inOut' }, 0.2 )
					.fromTo( heroMedia, { scale: 1.065 }, { scale: 1.015, duration: 1.05, ease: 'power3.out' }, 0.22 )
					.from( heroElements, { autoAlpha: 0, y: 22, stagger: 0.075, duration: 0.6, ease: 'power3.out' }, 0.48 );
			} else {
				intro.classList.add( 'is-leaving' );
				setTimeout( finish, 650 );
			}
		};

		if ( gsap ) {
			introTimeline = gsap.timeline( { defaults: { ease: 'power3.out' } } )
				.from( '.lm-intro__light', { autoAlpha: 0, scale: 0.7, duration: 0.65 } )
				.from( '.lm-intro__logo', { autoAlpha: 0, scale: 0.88, y: 10, filter: 'blur(8px)', duration: 0.75 }, 0.12 )
				.from( '.lm-intro__signature', { autoAlpha: 0, y: 8, duration: 0.4 }, 0.62 )
				.from( '.lm-intro__progress', { autoAlpha: 0, duration: 0.3 }, 0.78 )
				.to( '[data-intro-progress-bar]', { scaleX: 1, duration: 2.25, ease: 'power1.inOut' }, 0.82 );
		}

		autoClose = setTimeout( close, 3150 );
		document.addEventListener( 'keydown', function ( event ) {
			if ( 'Escape' === event.key && ! intro.hidden ) { close(); }
		} );
	}

	if ( gsap && window.ScrollTrigger && heroMedia && ! reduceMotion ) {
		gsap.to( heroMedia, {
			scale: 1.075,
			ease: 'none',
			scrollTrigger: {
				trigger: hero,
				start: 'top top',
				end: 'bottom top',
				scrub: 0.65,
			},
		} );
	}

	if ( gsap && window.ScrollTrigger && ! reduceMotion && document.querySelector( '.lm-home' ) ) {
		const serviceRows = document.querySelectorAll( '[data-home-service]' );
		const story = document.querySelector( '[data-home-story]' );
		const storyMedia = story ? story.querySelector( '.lm-home-story__media' ) : null;
		const storyLight = story ? story.querySelector( '.lm-home-story__light' ) : null;

		if ( serviceRows.length ) {
			gsap.from( serviceRows, {
				x: 54,
				autoAlpha: 0,
				filter: 'blur(7px)',
				duration: 0.72,
				stagger: 0.09,
				ease: 'power3.out',
				scrollTrigger: { trigger: '.lm-home-services__list', start: 'top 78%', once: true },
			} );
		}

		if ( story && storyMedia ) {
			gsap.to( storyMedia, {
				scale: 1.14,
				ease: 'none',
				scrollTrigger: { trigger: story, start: 'top bottom', end: 'bottom top', scrub: 0.7 },
			} );
			gsap.from( story.querySelectorAll( '.lm-home-story__statement, h2, .lm-home-story__copy' ), {
				y: 45,
				autoAlpha: 0,
				filter: 'blur(8px)',
				duration: 0.8,
				stagger: 0.1,
				ease: 'power3.out',
				scrollTrigger: { trigger: story, start: 'top 62%', once: true },
			} );

			if ( storyLight ) {
				gsap.timeline( {
					scrollTrigger: { trigger: story, start: 'top 72%', once: true },
				} )
					.set( storyLight, { xPercent: -155, skewX: -12, autoAlpha: 0 } )
					.to( storyLight, { autoAlpha: 0.82, duration: 0.18, ease: 'power2.out' }, 0 )
					.to( storyLight, { xPercent: 335, duration: 1.3, ease: 'power2.inOut' }, 0 )
					.to( storyLight, { autoAlpha: 0, duration: 0.28, ease: 'power2.in' }, 0.98 );
			}
		}

		const marketDoors = document.querySelectorAll( '.lm-home-market__door' );
		if ( marketDoors.length ) {
			gsap.from( marketDoors, {
				clipPath: 'inset(0 100% 0 0)',
				duration: 0.95,
				stagger: 0.12,
				ease: 'power3.inOut',
				scrollTrigger: { trigger: '.lm-home-market__doors', start: 'top 78%', once: true },
			} );
		}

		const proofLines = document.querySelectorAll( '.lm-home-proof p' );
		if ( proofLines.length ) {
			gsap.from( proofLines, {
				x: function ( index ) { return 0 === index % 2 ? -75 : 75; },
				autoAlpha: 0,
				duration: 0.78,
				stagger: 0.1,
				ease: 'power3.out',
				scrollTrigger: { trigger: '.lm-home-proof', start: 'top 72%', once: true },
			} );
		}
	}

	const revealItems = document.querySelectorAll( '[data-reveal]' );
	if ( 'IntersectionObserver' in window && ! reduceMotion ) {
		const observer = new IntersectionObserver( function ( entries ) {
			entries.forEach( function ( entry ) { if ( entry.isIntersecting ) { entry.target.classList.add( 'is-visible' ); observer.unobserve( entry.target ); } } );
		}, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 } );
		revealItems.forEach( function ( item ) { observer.observe( item ); } );
	} else { revealItems.forEach( function ( item ) { item.classList.add( 'is-visible' ); } ); }

	const filterToggle = document.querySelector( '[data-filter-toggle]' );
	const filters = document.querySelector( '[data-filters]' );
	if ( filterToggle && filters ) {
		filterToggle.addEventListener( 'click', function () {
			const open = ! filters.classList.contains( 'is-open' );
			filters.classList.toggle( 'is-open', open );
			filterToggle.setAttribute( 'aria-expanded', String( open ) );
		} );
	}

	const customSelects = document.querySelectorAll( '[data-custom-select]' );
	const closeCustomSelects = function ( except ) {
		customSelects.forEach( function ( control ) {
			if ( control === except ) { return; }
			const trigger = control.querySelector( '[data-select-trigger]' );
			const menu = control.querySelector( '[data-select-menu]' );
			control.classList.remove( 'is-open' );
			if ( trigger ) { trigger.setAttribute( 'aria-expanded', 'false' ); trigger.removeAttribute( 'aria-activedescendant' ); }
			if ( menu ) { menu.hidden = true; }
		} );
	};

	customSelects.forEach( function ( control ) {
		const select = control.querySelector( 'select' );
		const trigger = control.querySelector( '[data-select-trigger]' );
		const value = control.querySelector( '[data-select-value]' );
		const menu = control.querySelector( '[data-select-menu]' );
		if ( ! select || ! trigger || ! value || ! menu ) { return; }

		const options = Array.from( select.options );
		const optionElements = options.map( function ( option, index ) {
			const item = document.createElement( 'div' );
			item.className = 'lm-select__option';
			item.id = menu.id + '-option-' + index;
			item.setAttribute( 'role', 'option' );
			item.setAttribute( 'aria-selected', 'false' );
			item.dataset.optionIndex = String( index );
			item.textContent = option.textContent;
			if ( option.disabled ) { item.setAttribute( 'aria-disabled', 'true' ); }
			menu.appendChild( item );
			return item;
		} );
		let activeIndex = select.selectedIndex;
		let typeahead = '';
		let typeaheadTimer;

		const enabledIndex = function ( start, direction ) {
			if ( ! options.length ) { return -1; }
			let index = ( start + options.length ) % options.length;
			for ( let attempts = 0; attempts < options.length; attempts++ ) {
				if ( ! options[ index ].disabled ) { return index; }
				index = ( index + direction + options.length ) % options.length;
			}
			return -1;
		};
		const syncValue = function () {
			value.textContent = options[ select.selectedIndex ] ? options[ select.selectedIndex ].textContent : '';
			trigger.setAttribute( 'aria-valuetext', value.textContent );
			optionElements.forEach( function ( item, index ) { item.setAttribute( 'aria-selected', String( index === select.selectedIndex ) ); } );
		};
		const setActive = function ( index ) {
			const next = enabledIndex( index, index >= activeIndex ? 1 : -1 );
			if ( -1 === next ) { return; }
			activeIndex = next;
			optionElements.forEach( function ( item, itemIndex ) { item.classList.toggle( 'is-active', itemIndex === activeIndex ); } );
			trigger.setAttribute( 'aria-activedescendant', optionElements[ activeIndex ].id );
			optionElements[ activeIndex ].scrollIntoView( { block: 'nearest' } );
		};
		const open = function ( initialIndex ) {
			closeCustomSelects( control );
			control.classList.add( 'is-open' );
			menu.hidden = false;
			trigger.setAttribute( 'aria-expanded', 'true' );
			activeIndex = select.selectedIndex;
			setActive( 'number' === typeof initialIndex ? initialIndex : activeIndex );
		};
		const close = function ( returnFocus ) {
			control.classList.remove( 'is-open' );
			menu.hidden = true;
			trigger.setAttribute( 'aria-expanded', 'false' );
			trigger.removeAttribute( 'aria-activedescendant' );
			optionElements.forEach( function ( item ) { item.classList.remove( 'is-active' ); } );
			if ( returnFocus ) { trigger.focus(); }
		};
		const choose = function ( index ) {
			if ( ! options[ index ] || options[ index ].disabled ) { return; }
			select.selectedIndex = index;
			syncValue();
			close( true );
			select.dispatchEvent( new Event( 'change', { bubbles: true } ) );
		};

		control.classList.add( 'is-enhanced' );
		select.setAttribute( 'aria-hidden', 'true' );
		select.tabIndex = -1;
		trigger.hidden = false;
		syncValue();
		trigger.addEventListener( 'click', function () {
			if ( 'true' === trigger.getAttribute( 'aria-expanded' ) ) { close( false ); }
			else { open(); }
		} );
		trigger.addEventListener( 'keydown', function ( event ) {
			const isOpen = 'true' === trigger.getAttribute( 'aria-expanded' );
			if ( 'ArrowDown' === event.key || 'ArrowUp' === event.key ) {
				event.preventDefault();
				const direction = 'ArrowDown' === event.key ? 1 : -1;
				if ( ! isOpen ) { open( enabledIndex( select.selectedIndex + direction, direction ) ); }
				else { setActive( enabledIndex( activeIndex + direction, direction ) ); }
			} else if ( 'Home' === event.key || 'End' === event.key ) {
				event.preventDefault();
				if ( ! isOpen ) { open( 'Home' === event.key ? 0 : options.length - 1 ); }
				else { setActive( 'Home' === event.key ? 0 : options.length - 1 ); }
			} else if ( 'Escape' === event.key && isOpen ) {
				event.preventDefault();
				close( false );
			} else if ( 'Tab' === event.key && isOpen ) {
				close( false );
			} else if ( 'Enter' === event.key || ' ' === event.key ) {
				event.preventDefault();
				if ( isOpen ) { choose( activeIndex ); }
				else { open(); }
			} else if ( event.key.length === 1 && ! event.altKey && ! event.ctrlKey && ! event.metaKey ) {
				typeahead += event.key.toLocaleLowerCase();
				clearTimeout( typeaheadTimer );
				typeaheadTimer = setTimeout( function () { typeahead = ''; }, 650 );
				const start = isOpen ? activeIndex + 1 : select.selectedIndex + 1;
				const match = options.findIndex( function ( option, offset ) {
					const index = ( start + offset ) % options.length;
					return ! options[ index ].disabled && options[ index ].textContent.trim().toLocaleLowerCase().startsWith( typeahead );
				} );
				if ( -1 !== match ) {
					if ( ! isOpen ) { open( match ); }
					else { setActive( match ); }
				}
			}
		} );
		optionElements.forEach( function ( item, index ) {
			item.addEventListener( 'click', function () { choose( index ); } );
			item.addEventListener( 'pointermove', function () { setActive( index ); } );
		} );
		select.addEventListener( 'change', syncValue );
		const form = control.closest( 'form' );
		if ( form ) { form.addEventListener( 'reset', function () { window.setTimeout( syncValue, 0 ); } ); }
	} );

	if ( customSelects.length ) {
		document.addEventListener( 'pointerdown', function ( event ) {
			if ( ! event.target.closest( '[data-custom-select]' ) ) { closeCustomSelects(); }
		} );
		document.addEventListener( 'keydown', function ( event ) {
			if ( 'Escape' !== event.key ) { return; }
			customSelects.forEach( function ( control ) {
				if ( control.classList.contains( 'is-open' ) ) {
					const trigger = control.querySelector( '[data-select-trigger]' );
					control.classList.remove( 'is-open' );
					control.querySelector( '[data-select-menu]' ).hidden = true;
					trigger.setAttribute( 'aria-expanded', 'false' );
					trigger.removeAttribute( 'aria-activedescendant' );
					trigger.focus();
				}
			} );
		} );
	}
} )();
