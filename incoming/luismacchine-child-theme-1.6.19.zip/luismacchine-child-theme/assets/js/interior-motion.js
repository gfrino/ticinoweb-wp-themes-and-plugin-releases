/* Small, once-only entrances. Content stays visible if JS or motion APIs fail. */
( function () {
	'use strict';
	const preference = window.matchMedia( '(prefers-reduced-motion: reduce)' );
	const main = document.querySelector( 'main' );
	if ( ! main || preference.matches || ! Element.prototype.animate ) { return; }
	const running = new Map();
	const pending = new Set();
	let observer;
	const stop = function () {
		if ( observer ) { observer.disconnect(); }
		running.forEach( function ( animation ) { animation.cancel(); } );
		running.clear();
		pending.forEach( function ( element ) { element.classList.remove( 'lm-motion-wait' ); } );
		pending.clear();
	};
	const arrive = function ( element, delay ) {
		element.classList.remove( 'lm-motion-wait' );
		pending.delete( element );
		if ( preference.matches || element.contains( document.activeElement ) ) { return; }
		const animation = element.animate( [
			{ opacity: 0, transform: 'translateY(22px)' },
			{ opacity: 1, transform: 'translateY(0)' },
		], { duration: 900, delay: delay, fill: 'backwards', easing: 'cubic-bezier(0.22, 0.61, 0.36, 1)' } );
		running.set( element, animation );
		animation.onfinish = function () { running.delete( element ); };
	};
	if ( 'IntersectionObserver' in window ) {
		observer = new IntersectionObserver( function ( entries ) {
			entries.forEach( function ( entry ) {
				if ( ! entry.isIntersecting ) { return; }
				observer.unobserve( entry.target );
				const siblings = Array.from( entry.target.parentElement.children );
				arrive( entry.target, Math.min( siblings.indexOf( entry.target ), 2 ) * 100 );
			} );
		}, { threshold: 0, rootMargin: '0px 0px -32px 0px' } );
		const candidates = Array.from( main.querySelectorAll( '.lm-story__grid > div, .lm-contact-page__grid > article, .lm-contact-hours > .lm-container, .lm-product-grid > article, .lm-service-explorer > .lm-container' ) );
		// Only prepare offscreen content: never hide something the visitor already sees.
		const offscreen = candidates.filter( function ( element ) { return element.getBoundingClientRect().top >= window.innerHeight; } );
		offscreen.forEach( function ( element ) {
			pending.add( element );
			element.classList.add( 'lm-motion-wait' );
			observer.observe( element );
		} );
	}
	// Keyboard navigation must never chase a moving control.
	main.addEventListener( 'focusin', function ( event ) {
		pending.forEach( function ( element ) {
			if ( element.contains( event.target ) ) {
				element.classList.remove( 'lm-motion-wait' ); pending.delete( element ); observer.unobserve( element );
			}
		} );
		running.forEach( function ( animation, element ) {
			if ( element.contains( event.target ) ) { animation.cancel(); running.delete( element ); }
		} );
	} );
	preference.addEventListener( 'change', stop );
	window.addEventListener( 'pagehide', stop, { once: true } );
}() );
