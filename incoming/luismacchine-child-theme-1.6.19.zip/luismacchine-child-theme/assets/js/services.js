( function () {
	'use strict';

	const explorer = document.querySelector( '[data-service-explorer]' );
	if ( ! explorer ) { return; }

	const panels = Array.from( explorer.querySelectorAll( '[data-service-panel]' ) );
	const previousButtons = Array.from( explorer.querySelectorAll( '[data-service-previous]' ) );
	const nextButtons = Array.from( explorer.querySelectorAll( '[data-service-next]' ) );
	const stage = explorer.querySelector( '.lm-service-carousel__slides' );
	const status = explorer.querySelector( '[data-service-status]' );
	let activeIndex = panels.findIndex( function ( panel ) {
		return ! panel.hidden;
	} );
	let entrySequence = 0;

	if ( ! panels.length ) { return; }
	if ( activeIndex < 0 ) { activeIndex = 0; }

	const update = function ( requestedIndex ) {
		activeIndex = ( requestedIndex + panels.length ) % panels.length;

		panels.forEach( function ( panel, index ) {
			const isActive = index === activeIndex;
			panel.hidden = ! isActive;
			panel.classList.toggle( 'is-active', isActive );
			panel.classList.remove( 'is-entering' );
			if ( isActive ) {
				const sequence = ++entrySequence;
				window.requestAnimationFrame( function () {
					if ( sequence === entrySequence && ! panel.hidden ) {
						panel.classList.add( 'is-entering' );
					}
				} );
			}
		} );

		previousButtons.forEach( function ( button ) {
			button.disabled = 1 === panels.length;
		} );
		nextButtons.forEach( function ( button ) {
			button.disabled = 1 === panels.length;
		} );

		if ( status ) {
			const title = panels[ activeIndex ].querySelector( 'h3' );
			const format = status.dataset.serviceStatusFormat || '%1$s, %2$s / %3$s';
			status.textContent = title ? format
				.replace( '%1$s', title.textContent )
				.replace( '%2$s', String( activeIndex + 1 ).padStart( 2, '0' ) )
				.replace( '%3$s', String( panels.length ).padStart( 2, '0' ) ) : '';
		}
	};

	previousButtons.forEach( function ( button ) {
		button.addEventListener( 'click', function () {
			update( activeIndex - 1 );
		} );
	} );
	nextButtons.forEach( function ( button ) {
		button.addEventListener( 'click', function () {
			update( activeIndex + 1 );
		} );
	} );

	if ( stage ) {
		let touchStartX = 0;
		let touchStartY = 0;
		let touchStarted = false;
		stage.addEventListener( 'touchstart', function ( event ) {
			if ( event.target instanceof Element && event.target.closest( 'a, button' ) ) {
				touchStarted = false;
				return;
			}
			if ( event.changedTouches.length ) {
				touchStartX = event.changedTouches[ 0 ].clientX;
				touchStartY = event.changedTouches[ 0 ].clientY;
				touchStarted = true;
			}
		}, { passive: true } );
		stage.addEventListener( 'touchend', function ( event ) {
			if ( ! touchStarted || ! event.changedTouches.length ) { return; }
			touchStarted = false;
			const deltaX = event.changedTouches[ 0 ].clientX - touchStartX;
			const deltaY = event.changedTouches[ 0 ].clientY - touchStartY;
			if ( Math.abs( deltaX ) > 55 && Math.abs( deltaX ) > Math.abs( deltaY ) ) {
				update( activeIndex + ( deltaX < 0 ? 1 : -1 ) );
			}
		}, { passive: true } );
	}

	update( activeIndex );
}() );
