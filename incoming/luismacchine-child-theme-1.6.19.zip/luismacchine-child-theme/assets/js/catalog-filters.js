( function () {
	'use strict';

	const form = document.querySelector( '[data-filters]' );
	const results = document.querySelector( '[data-catalog-results]' );
	const status = document.querySelector( '[data-catalog-status]' );
	if ( ! form || ! results || ! status || ! window.fetch || ! window.AbortController ) { return; }

	const button = form.querySelector( '[type="submit"]' );
	const archive = new URL( form.action );
	let activeRequest;
	let renderedUrl = window.location.pathname + window.location.search;

	const updateResults = async function ( url, fromHistory ) {
		if ( activeRequest ) { activeRequest.abort(); }
		const request = new AbortController();
		activeRequest = request;
		const restoreButtonFocus = document.activeElement === button;
		const timeout = window.setTimeout( function () { request.abort(); }, 15000 );
		form.setAttribute( 'aria-busy', 'true' );
		results.setAttribute( 'aria-busy', 'true' );
		button.disabled = true;
		status.classList.add( 'screen-reader-text' );
		status.textContent = form.dataset.loading;

		try {
			const response = await fetch( url.href, { signal: request.signal, credentials: 'same-origin' } );
			if ( ! response.ok || new URL( response.url ).origin !== archive.origin ) { throw new Error( 'Invalid response' ); }
			const page = new DOMParser().parseFromString( await response.text(), 'text/html' );
			const next = page.querySelector( '[data-catalog-results]' );
			const nextForm = page.querySelector( '[data-filters]' );
			if ( ! next || ! nextForm ) { throw new Error( 'Missing catalog' ); }
			if ( activeRequest !== request ) { return; }
			if ( request.signal.aborted ) { throw new Error( 'Request timed out' ); }

			// Retain enough page height even when the new selection has no results.
			// No scroll command: the existing form, focus and mobile panel stay in place.
			results.style.minHeight = Math.max( 0, window.innerHeight - results.getBoundingClientRect().top ) + 'px';
			results.replaceChildren( ...Array.from( next.childNodes ) );
			document.title = page.title;
			if ( fromHistory ) {
				Array.from( form.elements ).forEach( function ( field ) {
					const source = field.name && nextForm.elements.namedItem( field.name );
					if ( source ) {
						field.value = source.value;
						field.dispatchEvent( new Event( 'change', { bubbles: true } ) );
					}
				} );
			} else if ( url.pathname + url.search !== renderedUrl ) {
				window.history.pushState( null, '', url.href );
			}
			renderedUrl = url.pathname + url.search;
			status.textContent = form.dataset.updated;
		} catch ( error ) {
			if ( activeRequest !== request ) { return; }
			// Keep the old results and the user's selections; Applica retries in place.
			status.classList.remove( 'screen-reader-text' );
			status.textContent = form.dataset.error;
		} finally {
			window.clearTimeout( timeout );
			if ( activeRequest === request ) {
				activeRequest = null;
				form.removeAttribute( 'aria-busy' );
				results.removeAttribute( 'aria-busy' );
				button.disabled = false;
				if ( restoreButtonFocus && document.activeElement === document.body ) {
					button.focus( { preventScroll: true } );
				}
			}
		}
	};

	form.addEventListener( 'submit', function ( event ) {
		event.preventDefault();
		const url = new URL( archive.href );
		url.hash = '';
		url.search = new URLSearchParams( new FormData( form ) ).toString();
		updateResults( url, false );
	} );

	window.addEventListener( 'popstate', function () {
		const url = new URL( window.location.href );
		if ( url.pathname + url.search === renderedUrl ) { return; }
		updateResults( url, true );
	} );
} )();
