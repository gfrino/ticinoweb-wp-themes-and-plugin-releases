(function ($) {
	'use strict';
	$(function () {
		Object.entries(lmDesignSettings.fields).forEach(function ([key, field]) {
			const input = document.getElementById(key);
			if (!input) { return; }
			if (input.tagName === 'SELECT') {
				input.replaceChildren();
				lmDesignSettings.fonts.forEach(function (font) {
					input.add(new Option(font, font, false, font === field.value));
				});
			} else {
				const label = document.createElement('label');
				label.htmlFor = key;
				label.textContent = field.label;
				label.style.display = 'block';
				$(input).closest('.wp-picker-container').before(label);
				$(input).val(field.value).wpColorPicker('color', field.value);
				$(input).closest('.wp-picker-container').find('.wp-color-result').css('background-color', field.value);
				$(input).closest('.wp-picker-container').siblings('[id^="palette-swatch-"]').hide();
			}
		});
		$('#ticinoweb_font_body').closest('td').append($('<p>', { class: 'description', text: lmDesignSettings.fontHelp }));
		const paletteRow = $('#ticinoweb_palette_suggested_1').closest('tr');
		paletteRow.find('th').text(lmDesignSettings.paletteLabel);
		paletteRow.find('td > .description').first().text(lmDesignSettings.paletteHelp);
		paletteRow.find('td > .description').slice(1).remove();
		const accentHelp = $('#ticinoweb_palette_primary').closest('td').find('p.description');
		accentHelp.first().text(lmDesignSettings.accentHelp);
		accentHelp.slice(1).remove();
		// The generic generator treats the secondary values as accent suggestions,
		// which is incompatible with their explicit background/surface/text roles.
		$('#generate-palette-btn, #apply-palette-btn').hide();
	});
})(jQuery);
