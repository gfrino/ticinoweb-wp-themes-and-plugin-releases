(function ($) {
	'use strict';

	$(function () {
		const frames = Object.create(null);
		let currentButton;

		$('[data-media-select]').on('click', function (event) {
			event.preventDefault();
			currentButton = $(this);
			const key = currentButton.data('media-key');

			if (!frames[key]) {
				frames[key] = wp.media({
					title: currentButton.data('media-title'),
					button: { text: luismacchineHomeCms.buttonText },
					library: { type: 'image' },
					multiple: false
				});

				frames[key].on('select', function () {
					const attachment = frames[key].state().get('selection').first().toJSON();
					const field = currentButton.closest('.lm-home-cms__picker');
					const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/avif'];
					if (!allowedTypes.includes(attachment.mime)) {
						const preview = field.find('[data-media-preview]');
						const message = luismacchineHomeCms.unsupportedImage;
						preview.empty().append($('<span>').text(message));
						return;
					}
					field.find('[data-media-id]').val(attachment.id);

					const previewUrl = (attachment.sizes && attachment.sizes.medium) ? attachment.sizes.medium.url : attachment.url;
					$('<img>', { src: previewUrl, alt: '' }).appendTo(field.find('[data-media-preview]').empty());
				});
			}

			frames[key].open();
		});

		$('[data-media-clear]').on('click', function () {
			const field = $(this).closest('.lm-home-cms__picker');
			field.find('[data-media-id]').val('0');
			const preview = field.find('[data-media-preview]');
			const defaultUrl = preview.data('default-preview');
			preview.empty().append(defaultUrl ? $('<img>', { src: defaultUrl, alt: '' }) : $('<span>').text(preview.data('empty-text')));
		});
	});
})(jQuery);
