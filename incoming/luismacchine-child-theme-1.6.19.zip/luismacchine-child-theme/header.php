<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="lm-skip-link" href="#contenuto"><?php esc_html_e( 'Vai al contenuto', 'luismacchine-child-theme' ); ?></a>
<header class="lm-header" data-header>
	<div class="lm-container lm-header__inner">
		<a class="lm-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php esc_attr_e( 'Luismacchine — Home', 'luismacchine-child-theme' ); ?>">
			<img src="<?php echo esc_url( luismacchine_logo_url() ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" width="180" height="127" translate="no">
		</a>
		<button class="lm-menu-toggle" type="button" aria-expanded="false" aria-controls="lm-primary-menu" data-menu-toggle>
			<span class="screen-reader-text"><?php esc_html_e( 'Apri il menu', 'luismacchine-child-theme' ); ?></span>
			<?php echo luismacchine_icon( 'menu', 'lm-menu-toggle__icon lm-menu-toggle__icon--menu' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php echo luismacchine_icon( 'close', 'lm-menu-toggle__icon lm-menu-toggle__icon--close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</button>
		<nav class="lm-nav" id="lm-primary-menu" aria-label="<?php esc_attr_e( 'Navigazione principale', 'luismacchine-child-theme' ); ?>" data-menu>
			<?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'menu_class' => 'lm-nav__list', 'fallback_cb' => 'luismacchine_navigation_fallback', 'depth' => 1 ) ); ?>
		</nav>
		<?php $contact = luismacchine_contact_info(); ?>
		<?php if ( $contact['phone'] ) : ?>
			<a class="lm-header__call" href="tel:<?php echo esc_attr( luismacchine_phone_href( $contact['phone'] ) ); ?>"><?php echo luismacchine_icon( 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span><?php esc_html_e( 'Chiama ora', 'luismacchine-child-theme' ); ?></span></a>
		<?php endif; ?>
	</div>
</header>
