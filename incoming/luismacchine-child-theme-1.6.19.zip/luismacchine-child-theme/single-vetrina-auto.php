<?php
get_header();
while ( have_posts() ) : the_post();
	$gallery = luismacchine_catalog_gallery_ids( get_the_ID() );
	$contact = luismacchine_contact_info();
	$post_id = get_the_ID();
	$meta    = static function ( $key ) use ( $post_id ) {
		return get_post_meta( $post_id, $key, true );
	};
	$labels  = array(
		'_lm_fuel'                => array( 'benzina' => __( 'Benzina', 'luismacchine-child-theme' ), 'diesel' => __( 'Diesel', 'luismacchine-child-theme' ), 'ibrida' => __( 'Ibrida', 'luismacchine-child-theme' ), 'elettrica' => __( 'Elettrica', 'luismacchine-child-theme' ), 'gpl' => 'GPL', 'metano' => __( 'Metano', 'luismacchine-child-theme' ), 'altro' => __( 'Altro', 'luismacchine-child-theme' ) ),
		'_lm_transmission'        => array( 'automatico' => __( 'Automatico', 'luismacchine-child-theme' ), 'manuale' => __( 'Manuale', 'luismacchine-child-theme' ), 'manuale-robotizzato' => __( 'Manuale robotizzato', 'luismacchine-child-theme' ), 'altro' => __( 'Altro', 'luismacchine-child-theme' ) ),
		'_lm_traction'            => array( 'anteriore' => __( 'Anteriore', 'luismacchine-child-theme' ), 'posteriore' => __( 'Posteriore', 'luismacchine-child-theme' ), 'integrale' => __( 'Integrale', 'luismacchine-child-theme' ) ),
		'_lm_vehicle_condition'   => array( 'occasione' => __( 'Occasione', 'luismacchine-child-theme' ), 'nuovo' => __( 'Nuovo', 'luismacchine-child-theme' ), 'dimostrativo' => __( 'Dimostrativo', 'luismacchine-child-theme' ) ),
		'_lm_importation'         => array( 'si' => __( 'Sì', 'luismacchine-child-theme' ), 'no' => __( 'No', 'luismacchine-child-theme' ) ),
	);
	$value = static function ( $key ) use ( $meta, $labels ) {
		$raw = $meta( $key );
		return isset( $labels[ $key ][ $raw ] ) ? $labels[ $key ][ $raw ] : $raw;
	};
	$format_price = static function ( $amount ) {
		return is_numeric( $amount ) ? sprintf( 'CHF %s.–', number_format_i18n( (float) $amount, 0 ) ) : '';
	};
	$lease_monthly = $meta( '_lm_lease_monthly' );
	$power_parts = array_filter(
		array(
			$meta( '_lm_power_ps' ) ? $meta( '_lm_power_ps' ) . ' PS' : '',
			$meta( '_lm_power_kw' ) ? $meta( '_lm_power_kw' ) . ' kW' : '',
		)
	);
	$specs   = array(
		__( 'Immatricolazione', 'luismacchine-child-theme' ) => $meta( '_lm_year' ),
		__( 'Chilometri', 'luismacchine-child-theme' ) => $meta( '_lm_mileage' ) !== '' ? number_format_i18n( (int) $meta( '_lm_mileage' ) ) . ' km' : '',
		__( 'Carburante', 'luismacchine-child-theme' ) => $value( '_lm_fuel' ),
		__( 'Cambio', 'luismacchine-child-theme' ) => $value( '_lm_transmission' ),
		__( 'Potenza', 'luismacchine-child-theme' ) => implode( ' / ', $power_parts ),
		__( 'Trazione', 'luismacchine-child-theme' ) => $value( '_lm_traction' ),
	);
	$brands = get_the_terms( $post_id, 'marca-veicolo' );
	if ( $brands && ! is_wp_error( $brands ) ) {
		$specs = array( __( 'Marca', 'luismacchine-child-theme' ) => implode( ', ', wp_list_pluck( $brands, 'name' ) ) ) + $specs;
	}
	$technical_sections = array(
		__( 'Carrozzeria e omologazione', 'luismacchine-child-theme' ) => array(
			__( 'Tipo di carrozzeria', 'luismacchine-child-theme' ) => $meta( '_lm_body_type' ),
			__( 'Condizioni del veicolo', 'luismacchine-child-theme' ) => $value( '_lm_vehicle_condition' ),
			__( 'Porte', 'luismacchine-child-theme' ) => $meta( '_lm_doors' ),
			__( 'Patente richiesta', 'luismacchine-child-theme' ) => $meta( '_lm_license_category' ),
		),
		__( 'Motore e prestazioni', 'luismacchine-child-theme' ) => array(
			__( 'Tipo di motore', 'luismacchine-child-theme' ) => $meta( '_lm_engine_type' ),
			__( 'Cilindrata', 'luismacchine-child-theme' ) => $meta( '_lm_displacement_cc' ) !== '' ? number_format_i18n( (int) $meta( '_lm_displacement_cc' ) ) . ' cm³' : '',
			__( 'Cilindri', 'luismacchine-child-theme' ) => $meta( '_lm_cylinders' ),
			__( 'Marce', 'luismacchine-child-theme' ) => $meta( '_lm_gears' ),
			__( 'Autonomia', 'luismacchine-child-theme' ) => $meta( '_lm_range' ) !== '' ? number_format_i18n( (int) $meta( '_lm_range' ) ) . ' km' : '',
		),
		__( 'Prezzo e provenienza', 'luismacchine-child-theme' ) => array(
			__( 'Prezzo da nuovo', 'luismacchine-child-theme' ) => $format_price( $meta( '_lm_new_price' ) ),
			__( 'Importazione diretta/parallela', 'luismacchine-child-theme' ) => $value( '_lm_importation' ),
		),
	);
	$technical_sections = array_filter(
		array_map(
			static function ( $fields ) {
				return array_filter( $fields, static function ( $item ) {
					return '' !== $item && null !== $item;
				} );
			},
			$technical_sections
		)
	);
	$equipment = array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', (string) $meta( '_lm_equipment' ) ) ) );
	$inspection = $meta( '_lm_inspection' );
	$warranty   = $meta( '_lm_warranty' );
	$has_description = '' !== trim( wp_strip_all_tags( get_the_content() ) );
	$has_other  = $has_description || ! empty( $technical_sections ) || ! empty( $equipment ) || '' !== $inspection || '' !== $warranty;
?>
<main id="contenuto"><article class="lm-detail">
	<div class="lm-container"><a class="lm-back-link" href="<?php echo esc_url( get_post_type_archive_link( LUISMACCHINE_VEHICLE_POST_TYPE ) ); ?>">← <?php esc_html_e( 'Torna alla vetrina', 'luismacchine-child-theme' ); ?></a></div>
	<div class="lm-container lm-detail__top">
		<div class="lm-detail__visual-column">
			<?php if ( ! luismacchine_render_detail_gallery( $gallery ) ) : ?><div class="lm-detail__gallery"><div class="lm-product-card__placeholder"><?php echo luismacchine_icon( 'car' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div></div><?php endif; ?>
			<?php if ( $has_other ) : ?>
				<div class="lm-detail__accordions">
					<?php if ( $has_description ) : ?>
						<details class="lm-detail__accordion">
							<summary><h2><?php esc_html_e( 'Descrizione', 'luismacchine-child-theme' ); ?></h2><span class="lm-detail__accordion-icon" aria-hidden="true"></span></summary>
							<div class="lm-detail__accordion-content lm-detail__description-content"><?php echo wp_kses_post( wpautop( get_the_content() ) ); ?></div>
						</details>
					<?php endif; ?>
					<?php if ( ! empty( $technical_sections ) ) : ?>
						<details class="lm-detail__accordion">
							<summary><h2><?php esc_html_e( 'Dati tecnici', 'luismacchine-child-theme' ); ?></h2><span class="lm-detail__accordion-icon" aria-hidden="true"></span></summary>
							<div class="lm-detail__accordion-content">
							<?php foreach ( $technical_sections as $section_label => $fields ) : ?>
								<section class="lm-detail__technical-group">
									<h3><?php echo esc_html( $section_label ); ?></h3>
									<dl class="lm-detail__data-grid"><?php foreach ( $fields as $label => $item ) : ?><div><dt><?php echo esc_html( $label ); ?></dt><dd><?php echo esc_html( $item ); ?></dd></div><?php endforeach; ?></dl>
								</section>
							<?php endforeach; ?>
							</div>
						</details>
					<?php endif; ?>
					<?php if ( ! empty( $equipment ) || '' !== $inspection || '' !== $warranty ) : ?>
						<details class="lm-detail__accordion">
							<summary><h2><?php esc_html_e( 'Dotazioni, collaudo e garanzia', 'luismacchine-child-theme' ); ?></h2><span class="lm-detail__accordion-icon" aria-hidden="true"></span></summary>
							<div class="lm-detail__accordion-content">
							<?php if ( ! empty( $equipment ) ) : ?><div class="lm-detail__equipment"><ul><?php foreach ( $equipment as $item ) : ?><li><?php echo esc_html( $item ); ?></li><?php endforeach; ?></ul></div><?php endif; ?>
							<?php if ( '' !== $inspection || '' !== $warranty ) : ?><dl class="lm-detail__data-grid lm-detail__data-grid--compact"><?php if ( '' !== $inspection ) : ?><div><dt><?php esc_html_e( 'Collaudo tecnico (CVM)', 'luismacchine-child-theme' ); ?></dt><dd><?php echo esc_html( 'si' === $inspection ? __( 'Sì', 'luismacchine-child-theme' ) : __( 'No', 'luismacchine-child-theme' ) ); ?></dd></div><?php endif; ?><?php if ( '' !== $warranty ) : ?><div><dt><?php esc_html_e( 'Garanzia', 'luismacchine-child-theme' ); ?></dt><dd><?php echo esc_html( $warranty ); ?></dd></div><?php endif; ?></dl><?php endif; ?>
							</div>
						</details>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</div>
		<div class="lm-detail__summary">
			<span class="lm-status lm-status--<?php echo esc_attr( $meta( '_lm_status' ) ?: 'disponibile' ); ?>"><?php echo esc_html( luismacchine_catalog_status( $post_id ) ); ?></span>
			<h1><?php the_title(); ?></h1>
			<div class="lm-detail__commercial">
				<strong class="lm-detail__price"><?php echo esc_html( luismacchine_catalog_price( $post_id ) ); ?></strong>
				<?php if ( '' !== $lease_monthly && is_numeric( $lease_monthly ) ) : ?><p class="lm-detail__leasing"><span><?php esc_html_e( 'Leasing da', 'luismacchine-child-theme' ); ?></span><strong><?php echo esc_html( $format_price( $lease_monthly ) ); ?> <?php esc_html_e( '/mese', 'luismacchine-child-theme' ); ?></strong></p><?php endif; ?>
			</div>
			<dl class="lm-detail__key-specs"><?php foreach ( $specs as $label => $item ) : if ( $item ) : ?><div><dt><?php echo esc_html( $label ); ?></dt><dd><?php echo esc_html( $item ); ?></dd></div><?php endif; endforeach; ?></dl>
			<div class="lm-actions"><?php if ( $contact['phone'] ) : ?><a class="lm-button lm-button--gold" href="tel:<?php echo esc_attr( luismacchine_phone_href( $contact['phone'] ) ); ?>"><?php esc_html_e( 'Chiama per questo veicolo', 'luismacchine-child-theme' ); ?></a><?php endif; ?><a class="lm-button lm-button--ghost" href="mailto:<?php echo esc_attr( antispambot( $contact['email'] ) ); ?>?subject=<?php echo esc_attr( rawurlencode( sprintf( __( 'Informazioni su %s', 'luismacchine-child-theme' ), get_the_title() ) ) ); ?>"><?php esc_html_e( 'Scrivi una email', 'luismacchine-child-theme' ); ?></a></div>
		</div>
	</div>
</article></main>
<?php endwhile; get_footer(); ?>
