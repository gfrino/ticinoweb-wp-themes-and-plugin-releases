<?php
get_header();
while ( have_posts() ) : the_post();
	$gallery = luismacchine_catalog_gallery_ids( get_the_ID() );
	$contact = luismacchine_contact_info();
	$part_id = get_the_ID();
	$compatibility = get_post_meta( $part_id, '_lm_compatibility', true );
	$condition = get_post_meta( $part_id, '_lm_condition', true );
	$categories = get_the_terms( $part_id, 'categoria-ricambio' );
	$category_names = $categories && ! is_wp_error( $categories ) ? implode( ', ', wp_list_pluck( $categories, 'name' ) ) : '';
	$specs = array_filter(
		array(
			__( 'Categoria', 'luismacchine-child-theme' ) => $category_names,
			__( 'Condizione', 'luismacchine-child-theme' ) => $condition,
		),
		static function ( $value ) { return '' !== $value; }
	);
?>
<main id="contenuto"><article class="lm-detail">
	<div class="lm-container"><a class="lm-back-link" href="<?php echo esc_url( get_post_type_archive_link( LUISMACCHINE_PART_POST_TYPE ) ); ?>">← <?php esc_html_e( 'Torna ai ricambi', 'luismacchine-child-theme' ); ?></a></div>
	<div class="lm-container lm-detail__top">
		<div class="lm-detail__visual-column">
			<?php if ( ! luismacchine_render_detail_gallery( $gallery ) ) : ?><div class="lm-detail__gallery"><div class="lm-product-card__placeholder"><?php echo luismacchine_icon( 'gear' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div></div><?php endif; ?>
			<?php if ( '' !== trim( get_the_content() ) ) : ?>
				<section class="lm-detail__description" aria-labelledby="lm-part-description-title">
					<h2 id="lm-part-description-title"><?php esc_html_e( 'Descrizione', 'luismacchine-child-theme' ); ?></h2>
					<div class="lm-detail__description-content"><?php the_content(); ?></div>
				</section>
			<?php endif; ?>
			<?php if ( '' !== $compatibility ) : ?>
				<div class="lm-detail__accordions">
					<details class="lm-detail__accordion">
						<summary><h2><?php esc_html_e( 'Compatibilità del ricambio', 'luismacchine-child-theme' ); ?></h2><span class="lm-detail__accordion-icon" aria-hidden="true"></span></summary>
						<div class="lm-detail__accordion-content">
							<dl class="lm-detail__data-grid">
								<div><dt><?php esc_html_e( 'Compatibilità', 'luismacchine-child-theme' ); ?></dt><dd><?php echo esc_html( $compatibility ); ?></dd></div>
							</dl>
						</div>
					</details>
				</div>
			<?php endif; ?>
		</div>
		<div class="lm-detail__summary">
			<span class="lm-status lm-status--<?php echo esc_attr( get_post_meta( $part_id, '_lm_status', true ) ?: 'disponibile' ); ?>"><?php echo esc_html( luismacchine_catalog_status( $part_id ) ); ?></span>
			<h1><?php the_title(); ?></h1>
			<div class="lm-detail__commercial">
				<strong class="lm-detail__price"><?php echo esc_html( luismacchine_catalog_price( $part_id ) ); ?></strong>
			</div>
			<?php if ( $specs ) : ?>
				<dl class="lm-detail__key-specs">
					<?php foreach ( $specs as $label => $value ) : ?><div><dt><?php echo esc_html( $label ); ?></dt><dd><?php echo esc_html( $value ); ?></dd></div><?php endforeach; ?>
				</dl>
			<?php endif; ?>
			<div class="lm-actions">
				<?php if ( $contact['phone'] ) : ?><a class="lm-button lm-button--gold" href="tel:<?php echo esc_attr( luismacchine_phone_href( $contact['phone'] ) ); ?>"><?php esc_html_e( 'Chiama per questo ricambio', 'luismacchine-child-theme' ); ?></a><?php endif; ?>
				<?php if ( $contact['email'] ) : ?><a class="lm-button lm-button--ghost" href="mailto:<?php echo esc_attr( antispambot( $contact['email'] ) ); ?>?subject=<?php echo esc_attr( rawurlencode( sprintf( __( 'Informazioni su %s', 'luismacchine-child-theme' ), get_the_title() ) ) ); ?>"><?php esc_html_e( 'Scrivi una email', 'luismacchine-child-theme' ); ?></a><?php endif; ?>
			</div>
		</div>
	</div>
</article></main>
<?php endwhile; get_footer(); ?>
