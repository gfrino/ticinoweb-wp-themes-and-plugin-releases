<?php
/**
 * Cinematic home page.
 *
 * @package LuismacchineChildTheme
 */

get_header();

$contact     = luismacchine_contact_info();
$services    = luismacchine_services();
$about_title = get_option( 'ticinoweb_chi_siamo_title', __( 'Una storia di motori, lavoro e fiducia', 'luismacchine-child-theme' ) );
$about_text  = get_option( 'ticinoweb_chi_siamo_text', '' );
$hero_poster = luismacchine_home_image_url( 'hero_poster', luismacchine_asset_url( 'assets/images/hero-clean-plate.jpg' ) );
$marquee_items = array(
	__( 'Officina', 'luismacchine-child-theme' ),
	__( 'Vendita auto', 'luismacchine-child-theme' ),
	__( 'Recupero', 'luismacchine-child-theme' ),
	__( 'Ricambi', 'luismacchine-child-theme' ),
	__( 'Riciclaggio', 'luismacchine-child-theme' ),
);
?>
<div class="lm-intro" data-intro role="region" aria-label="<?php esc_attr_e( 'Introduzione Luismacchine', 'luismacchine-child-theme' ); ?>" hidden>
	<div class="lm-intro__ambient" aria-hidden="true"></div>
	<div class="lm-intro__stage">
		<div class="lm-intro__light" aria-hidden="true"></div>
		<div class="lm-intro__logo">
			<img src="<?php echo esc_url( luismacchine_logo_url() ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" width="320" height="226" translate="no">
		</div>
		<p class="lm-intro__signature"><?php echo esc_html( get_bloginfo( 'description' ) ); ?></p>
		<div class="lm-intro__progress" aria-hidden="true"><span data-intro-progress-bar></span></div>
	</div>
</div>

<main id="contenuto" class="lm-home">
	<section class="lm-hero lm-home-hero" data-hero>
		<div class="lm-hero__media" data-hero-media aria-hidden="true">
			<?php if ( luismacchine_home_image_id( 'hero_poster' ) ) : ?>
				<?php echo wp_get_attachment_image( luismacchine_home_image_id( 'hero_poster' ), 'full', false, array( 'class' => 'lm-hero__poster', 'alt' => '', 'fetchpriority' => 'high', 'decoding' => 'async', 'loading' => 'eager' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php else : ?>
				<img class="lm-hero__poster" src="<?php echo esc_url( $hero_poster ); ?>" alt="" width="1671" height="941" fetchpriority="high" decoding="async">
			<?php endif; ?>
			<div class="lm-hero__shade"></div>
		</div>

		<div class="lm-container lm-hero__content">
			<h1>
				<span><?php echo esc_html( luismacchine_page_title( 'home_line_one' ) ); ?></span>
				<span><?php echo esc_html( luismacchine_page_title( 'home_line_two' ) ); ?></span>
				<strong><?php echo esc_html( luismacchine_page_title( 'home_line_three' ) ); ?></strong>
			</h1>
			<div class="lm-home-hero__footer">
				<p><?php esc_html_e( 'Officina, recupero, vendita, ricambi e riciclaggio. Un unico referente per ogni fase.', 'luismacchine-child-theme' ); ?></p>
				<div class="lm-actions">
					<?php if ( $contact['phone'] ) : ?>
						<a class="lm-button lm-button--gold" href="tel:<?php echo esc_attr( luismacchine_phone_href( $contact['phone'] ) ); ?>"><?php esc_html_e( 'Parla con noi', 'luismacchine-child-theme' ); ?><?php echo luismacchine_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
					<?php endif; ?>
					<a class="lm-home-link" href="<?php echo esc_url( luismacchine_page_url( 'servizi' ) ); ?>"><?php esc_html_e( 'Scopri cosa facciamo', 'luismacchine-child-theme' ); ?></a>
				</div>
			</div>
		</div>

		<div class="lm-home-hero__rail" aria-hidden="true">
			<span><?php echo esc_html( get_bloginfo( 'name' ) ); ?></span>
			<i></i>
		</div>
		<a class="lm-hero__scroll" href="#servizi"><span><?php esc_html_e( 'Esplora', 'luismacchine-child-theme' ); ?></span><i aria-hidden="true"></i></a>
	</section>

	<div class="lm-home-marquee" aria-hidden="true">
		<div class="lm-home-marquee__track">
			<?php for ( $group_index = 0; $group_index < 2; $group_index++ ) : ?>
				<div class="lm-home-marquee__group">
					<?php for ( $sequence_index = 0; $sequence_index < 2; $sequence_index++ ) : ?>
						<?php foreach ( $marquee_items as $marquee_item ) : ?>
							<i></i><span class="lm-home-marquee__item"><b><?php echo esc_html( $marquee_item ); ?></b></span>
						<?php endforeach; ?>
					<?php endfor; ?>
				</div>
			<?php endfor; ?>
		</div>
	</div>

	<section class="lm-home-services" id="servizi" data-home-scene>
		<div class="lm-container lm-home-services__layout">
			<header class="lm-home-services__header">
				<h2><?php echo esc_html( luismacchine_page_title( 'home_services' ) ); ?></h2>
				<p><?php esc_html_e( 'Seguiamo il veicolo dalla strada all’officina, fino alla vendita, ai ricambi o al recupero dei componenti.', 'luismacchine-child-theme' ); ?></p>
				<a class="lm-home-link" href="<?php echo esc_url( luismacchine_page_url( 'servizi' ) ); ?>"><?php esc_html_e( 'Tutti i servizi', 'luismacchine-child-theme' ); ?><?php echo luismacchine_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
			</header>

			<div class="lm-home-services__list">
				<?php foreach ( $services as $service ) : ?>
					<article class="lm-home-service" data-home-service>
						<h3><?php echo esc_html( $service['title'] ); ?></h3>
						<p><?php echo esc_html( wp_strip_all_tags( $service['description'] ) ); ?></p>
						<span aria-hidden="true"><?php echo luismacchine_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					</article>
				<?php endforeach; ?>
			</div>
		</div>
	</section>

	<section class="lm-home-story" data-home-story>
		<div class="lm-home-story__media" aria-hidden="true">
			<?php if ( luismacchine_home_image_id( 'story_image' ) ) : ?>
				<?php echo wp_get_attachment_image( luismacchine_home_image_id( 'story_image' ), 'large', false, array( 'alt' => '', 'loading' => 'lazy', 'decoding' => 'async' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php else : ?>
				<img src="<?php echo esc_url( luismacchine_asset_url( 'assets/images/garage-detail.jpg' ) ); ?>" alt="" width="1920" height="1080" loading="lazy" decoding="async">
			<?php endif; ?>
		</div>
		<div class="lm-home-story__shade" aria-hidden="true"></div>
		<div class="lm-home-story__light" aria-hidden="true"></div>
		<div class="lm-container lm-home-story__content">
			<p class="lm-home-story__statement"><?php esc_html_e( 'Qui le auto non sono numeri.', 'luismacchine-child-theme' ); ?></p>
			<h2><?php echo esc_html( $about_title ); ?></h2>
			<div class="lm-home-story__copy">
				<p><?php echo esc_html( wp_trim_words( wp_strip_all_tags( $about_text ), 46 ) ); ?></p>
				<a class="lm-home-link" href="<?php echo esc_url( luismacchine_page_url( 'chi-siamo' ) ); ?>"><?php esc_html_e( 'Scopri chi siamo', 'luismacchine-child-theme' ); ?><?php echo luismacchine_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
			</div>
		</div>
	</section>

	<section class="lm-home-market" data-home-scene>
		<div class="lm-container">
			<header class="lm-home-market__header">
				<h2><?php echo esc_html( luismacchine_page_title( 'home_market' ) ); ?></h2>
				<p><?php esc_html_e( 'Un’auto selezionata o il ricambio giusto: due cataloghi distinti, gestiti direttamente dalla nostra officina.', 'luismacchine-child-theme' ); ?></p>
			</header>

			<div class="lm-home-market__doors">
				<a class="lm-home-market__door lm-home-market__door--vehicles" href="<?php echo esc_url( get_post_type_archive_link( LUISMACCHINE_VEHICLE_POST_TYPE ) ); ?>" style="--lm-door-image:url('<?php echo esc_url( luismacchine_home_image_url( 'vehicle_door_image', luismacchine_asset_url( 'assets/images/hero-final-frame.jpg' ), 'large' ) ); ?>')">
					<span><?php esc_html_e( 'Veicoli', 'luismacchine-child-theme' ); ?></span>
					<strong><?php esc_html_e( 'Vetrina auto', 'luismacchine-child-theme' ); ?></strong>
					<small><?php esc_html_e( 'Guarda le disponibilità', 'luismacchine-child-theme' ); ?><?php echo luismacchine_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></small>
				</a>
				<a class="lm-home-market__door lm-home-market__door--parts" href="<?php echo esc_url( get_post_type_archive_link( LUISMACCHINE_PART_POST_TYPE ) ); ?>">
					<span><?php esc_html_e( 'Componenti', 'luismacchine-child-theme' ); ?></span>
					<strong><?php esc_html_e( 'Ricambi', 'luismacchine-child-theme' ); ?></strong>
					<small><?php esc_html_e( 'Trova il pezzo giusto', 'luismacchine-child-theme' ); ?><?php echo luismacchine_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></small>
				</a>
			</div>

		</div>
	</section>

	<section class="lm-home-proof" data-home-scene>
		<div class="lm-container lm-home-proof__inner">
			<p><?php esc_html_e( 'Competenza concreta.', 'luismacchine-child-theme' ); ?></p>
			<p><?php esc_html_e( 'Un referente diretto.', 'luismacchine-child-theme' ); ?></p>
			<p><?php esc_html_e( 'Il veicolo seguito fino in fondo.', 'luismacchine-child-theme' ); ?></p>
		</div>
	</section>

	<section class="lm-home-contact">
		<div class="lm-container lm-home-contact__inner">
			<h2><?php echo esc_html( luismacchine_page_title( 'home_contact' ) ); ?></h2>
			<div class="lm-home-contact__details">
				<?php if ( $contact['address'] ) : ?><p><?php echo esc_html( $contact['address'] ); ?></p><?php endif; ?>
				<div class="lm-actions">
					<a class="lm-button lm-button--dark" href="<?php echo esc_url( luismacchine_page_url( 'contatti' ) ); ?>"><?php esc_html_e( 'Contattaci', 'luismacchine-child-theme' ); ?></a>
					<a class="lm-home-link lm-home-link--dark" href="<?php echo esc_url( luismacchine_page_url( 'contatti' ) ); ?>"><?php esc_html_e( 'Tutti i contatti', 'luismacchine-child-theme' ); ?><?php echo luismacchine_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
				</div>
			</div>
		</div>
	</section>
	<?php get_template_part( 'template-parts/home-faq' ); ?>
</main>

<?php get_footer(); ?>
