<?php get_header(); ?>
<main id="contenuto">
	<?php while ( have_posts() ) : the_post(); ?>
	<header class="lm-page-hero"><div class="lm-container"><p class="lm-eyebrow"><?php bloginfo( 'name' ); ?></p><h1><?php the_title(); ?></h1></div></header>
	<div class="lm-container lm-prose"><?php the_content(); ?></div>
	<?php endwhile; ?>
</main>
<?php get_footer(); ?>
