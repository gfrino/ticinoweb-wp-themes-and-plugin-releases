<?php
get_header();
$title = get_option( 'ticinoweb_chi_siamo_title', get_the_title() );
$text  = get_option( 'ticinoweb_chi_siamo_text', '' );
$about_image = get_option( 'ticinoweb_chi_siamo_image', '' );
$title_parts = explode( ',', $title, 2 );
?>
<main id="contenuto">
	<header class="lm-page-hero lm-page-hero--about lm-page-hero--compact"><div class="lm-container"><p class="lm-eyebrow"><?php esc_html_e( 'Luismacchine Sagl', 'luismacchine-child-theme' ); ?></p><h1><?php if ( 2 === count( $title_parts ) ) : ?><?php echo esc_html( trim( $title_parts[0] ) ); ?>,<br><?php echo esc_html( trim( $title_parts[1] ) ); ?><?php else : ?><?php echo esc_html( $title ); ?><?php endif; ?></h1><p><?php esc_html_e( 'Una realtà locale costruita sul lavoro, sulla conoscenza dei motori e sul rapporto diretto con il cliente.', 'luismacchine-child-theme' ); ?></p></div></header>
	<section class="lm-section lm-story"><div class="lm-container lm-story__grid">
		<?php if ( $about_image ) : ?>
		<div class="lm-story__photo">
			<?php $about_image_id = attachment_url_to_postid( $about_image ); ?>
			<?php if ( $about_image_id ) : ?>
				<?php echo wp_get_attachment_image( $about_image_id, 'large', false, array( 'loading' => 'lazy' ) ); ?>
			<?php else : ?>
				<img src="<?php echo esc_url( $about_image ); ?>" alt="<?php echo esc_attr( $title ); ?>" width="800" height="1000" loading="lazy" decoding="async">
			<?php endif; ?>
		</div>
		<?php else : ?>
		<div class="lm-story__mark lm-story__placeholder">
			<svg width="56" height="56" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8" cy="8" r="1.5"/><path d="m3 17 5-5 4 4 4-6 5 7"/></svg>
			<p><?php esc_html_e( 'Foto da inserire', 'luismacchine-child-theme' ); ?></p>
		</div>
		<?php endif; ?>
		<div><p class="lm-eyebrow"><?php esc_html_e( 'La nostra storia', 'luismacchine-child-theme' ); ?></p><div class="lm-story__text"><?php echo wp_kses_post( wpautop( $text ) ); ?></div></div>
	</div></section>
	<section class="lm-contact-band"><div class="lm-container lm-contact-band__inner"><div><p class="lm-eyebrow"><?php esc_html_e( 'Vieni a conoscerci', 'luismacchine-child-theme' ); ?></p><h2><?php echo esc_html( luismacchine_page_title( 'about_contact' ) ); ?></h2></div><a class="lm-button lm-button--gold" href="<?php echo esc_url( luismacchine_page_url( 'contatti' ) ); ?>"><?php esc_html_e( 'Contatti e indicazioni', 'luismacchine-child-theme' ); ?></a></div></section>
</main>
<?php get_footer(); ?>
