<?php
/** Readable legal document, with content managed in the native page editor. */
get_header();
?>
<main id="contenuto" class="lm-privacy">
	<?php while ( have_posts() ) : the_post(); ?>
	<article class="lm-container lm-privacy__document">
		<header class="lm-privacy__header"><h1><?php the_title(); ?></h1></header>
		<div class="lm-privacy__content"><?php the_content(); ?></div>
	</article>
	<?php endwhile; ?>
</main>
<?php get_footer(); ?>
