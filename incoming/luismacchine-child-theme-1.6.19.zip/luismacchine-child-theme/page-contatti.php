<?php get_header(); $contact = luismacchine_contact_info(); ?>
<main id="contenuto">
	<header class="lm-page-hero lm-page-hero--compact"><div class="lm-container"><p class="lm-eyebrow"><?php esc_html_e( 'Contatti', 'luismacchine-child-theme' ); ?></p><h1><?php echo esc_html( luismacchine_page_title( 'contacts' ) ); ?></h1><p><?php esc_html_e( 'Chiamaci, scrivici o vieni a trovarci a Cadenazzo.', 'luismacchine-child-theme' ); ?></p></div></header>
	<section class="lm-section lm-contact-page"><div class="lm-container lm-contact-page__grid">
		<article><div class="lm-contact-page__icon"><?php echo luismacchine_icon( 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><p class="lm-eyebrow"><?php esc_html_e( 'Telefono', 'luismacchine-child-theme' ); ?></p><h2><?php echo esc_html( $contact['phone'] ); ?></h2><a class="lm-button lm-button--gold" href="tel:<?php echo esc_attr( luismacchine_phone_href( $contact['phone'] ) ); ?>"><?php esc_html_e( 'Chiama ora', 'luismacchine-child-theme' ); ?></a></article>
		<article><div class="lm-contact-page__icon">@</div><p class="lm-eyebrow"><?php esc_html_e( 'Email', 'luismacchine-child-theme' ); ?></p><h2><?php echo esc_html( antispambot( $contact['email'] ) ); ?></h2><a class="lm-button lm-button--ghost" href="mailto:<?php echo esc_attr( antispambot( $contact['email'] ) ); ?>"><?php esc_html_e( 'Scrivi una email', 'luismacchine-child-theme' ); ?></a></article>
		<article><div class="lm-contact-page__icon"><?php echo luismacchine_icon( 'pin' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><p class="lm-eyebrow"><?php esc_html_e( 'Sede', 'luismacchine-child-theme' ); ?></p><h2><?php echo esc_html( $contact['address'] ); ?></h2><a class="lm-text-link" href="https://www.google.com/maps/search/?api=1&amp;query=<?php echo esc_attr( rawurlencode( $contact['address'] ) ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Apri le indicazioni', 'luismacchine-child-theme' ); ?><?php echo luismacchine_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a></article>
	</div></section>
	<?php
	$hours = get_option( 'ticinoweb_contact_opening_hours', array() );
	$days  = array(
		'monday'    => __( 'Lunedì', 'luismacchine-child-theme' ),
		'tuesday'   => __( 'Martedì', 'luismacchine-child-theme' ),
		'wednesday' => __( 'Mercoledì', 'luismacchine-child-theme' ),
		'thursday'  => __( 'Giovedì', 'luismacchine-child-theme' ),
		'friday'    => __( 'Venerdì', 'luismacchine-child-theme' ),
		'saturday'  => __( 'Sabato', 'luismacchine-child-theme' ),
		'sunday'    => __( 'Domenica', 'luismacchine-child-theme' ),
	);
	$hour_rows = array();
	foreach ( $days as $key => $label ) {
		$value = is_array( $hours ) && isset( $hours[ $key ] ) ? ticinoweb_format_day_hours( $hours[ $key ] ) : '';
		if ( '' !== $value ) {
			$hour_rows[ $key ] = array( 'label' => $label, 'value' => $value );
		}
	}
	$today = strtolower( current_datetime()->format( 'l' ) );
	?>
	<section class="lm-section lm-contact-note lm-contact-hours" aria-labelledby="lm-hours-title">
		<div class="lm-container">
			<h2 id="lm-hours-title"><?php echo esc_html( luismacchine_page_title( 'hours' ) ); ?></h2>
			<?php if ( $hour_rows ) : ?>
				<dl class="lm-opening-hours" data-hours-timezone="<?php echo esc_attr( wp_timezone_string() ); ?>" aria-labelledby="lm-hours-title">
					<?php foreach ( $hour_rows as $key => $row ) : ?>
						<div class="lm-opening-hours__day<?php echo $key === $today ? ' is-today' : ''; ?>" data-day="<?php echo esc_attr( $key ); ?>"<?php if ( $key === $today ) : ?> aria-current="date"<?php endif; ?>>
							<dt><?php echo esc_html( $row['label'] ); ?><span class="lm-opening-hours__today"<?php if ( $key !== $today ) : ?> hidden<?php endif; ?>><?php esc_html_e( 'Oggi', 'luismacchine-child-theme' ); ?></span></dt>
							<dd><?php echo esc_html( $row['value'] ); ?></dd>
						</div>
					<?php endforeach; ?>
				</dl>
				<?php $hours_note = get_option( 'ticinoweb_contact_opening_hours_note', '' ); ?>
				<?php if ( is_string( $hours_note ) && '' !== trim( $hours_note ) ) : ?>
					<p class="lm-opening-hours__note"><?php echo esc_html( $hours_note ); ?></p>
				<?php endif; ?>
			<?php else : ?>
				<p><?php esc_html_e( 'Per conoscere gli orari, chiamaci prima della visita.', 'luismacchine-child-theme' ); ?></p>
			<?php endif; ?>
		</div>
	</section>
</main>
<?php get_footer(); ?>
