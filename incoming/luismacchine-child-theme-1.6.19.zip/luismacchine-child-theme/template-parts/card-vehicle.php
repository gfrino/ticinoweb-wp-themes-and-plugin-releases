<?php
$vehicle_id   = get_the_ID();
$year         = get_post_meta( $vehicle_id, '_lm_year', true );
$mileage      = get_post_meta( $vehicle_id, '_lm_mileage', true );
$power_ps     = get_post_meta( $vehicle_id, '_lm_power_ps', true );
$transmission = get_post_meta( $vehicle_id, '_lm_transmission', true );
$transmission_labels = array(
	'automatico'          => __( 'Automatico', 'luismacchine-child-theme' ),
	'manuale'             => __( 'Manuale', 'luismacchine-child-theme' ),
	'manuale-robotizzato' => __( 'Robotizzato', 'luismacchine-child-theme' ),
	'altro'              => __( 'Altro', 'luismacchine-child-theme' ),
);
$vehicle_specs = array(
	array( 'icon' => 'calendar', 'label' => __( 'Immatricolazione', 'luismacchine-child-theme' ), 'value' => $year ),
	array( 'icon' => 'road', 'label' => __( 'Chilometri', 'luismacchine-child-theme' ), 'value' => is_numeric( $mileage ) ? number_format_i18n( (int) $mileage ) . ' km' : '' ),
	array( 'icon' => 'gauge', 'label' => __( 'Potenza', 'luismacchine-child-theme' ), 'value' => is_numeric( $power_ps ) && (float) $power_ps > 0 ? number_format_i18n( (float) $power_ps, 0 ) . ' PS' : '' ),
	array( 'icon' => 'transmission', 'label' => __( 'Cambio', 'luismacchine-child-theme' ), 'value' => $transmission_labels[ $transmission ] ?? $transmission ),
);
$vehicle_specs = array_filter( $vehicle_specs, static function ( $spec ) { return '' !== $spec['value']; } );
?>
<article <?php post_class( 'lm-product-card lm-product-card--vehicle' ); ?>>
	<a class="lm-product-card__link" href="<?php the_permalink(); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Vedi %s', 'luismacchine-child-theme' ), get_the_title() ) ); ?>"></a>
	<div class="lm-product-card__media">
		<?php if ( has_post_thumbnail() ) : the_post_thumbnail( 'luismacchine-card', array( 'loading' => 'lazy' ) ); else : ?><div class="lm-product-card__placeholder"><?php echo luismacchine_icon( 'car' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><?php endif; ?>
		<span class="lm-status lm-status--<?php echo esc_attr( get_post_meta( get_the_ID(), '_lm_status', true ) ?: 'disponibile' ); ?>"><?php echo esc_html( luismacchine_catalog_status( get_the_ID() ) ); ?></span>
	</div>
	<div class="lm-product-card__body">
		<?php $terms = get_the_terms( get_the_ID(), 'marca-veicolo' ); if ( $terms && ! is_wp_error( $terms ) ) : ?><p class="lm-product-card__meta"><?php echo esc_html( $terms[0]->name ); ?></p><?php endif; ?>
		<h2 class="lm-product-card__title"><?php echo esc_html( get_the_title() ); ?></h2>
		<strong class="lm-product-card__price"><?php echo esc_html( luismacchine_catalog_price( get_the_ID() ) ); ?></strong>
		<?php $lease_monthly = get_post_meta( get_the_ID(), '_lm_lease_monthly', true ); if ( '' !== $lease_monthly && is_numeric( $lease_monthly ) ) : ?>
			<p class="lm-product-card__leasing"><span><?php esc_html_e( 'Leasing da', 'luismacchine-child-theme' ); ?></span><strong><?php echo esc_html( sprintf( 'CHF %s.–', number_format_i18n( (float) $lease_monthly, 0 ) ) ); ?> <span><?php esc_html_e( '/mese', 'luismacchine-child-theme' ); ?></span></strong></p>
		<?php endif; ?>
		<?php if ( $vehicle_specs ) : ?>
			<ul class="lm-product-card__specs lm-product-card__specs--icons">
				<?php foreach ( $vehicle_specs as $spec ) : ?>
					<li>
						<?php echo luismacchine_icon( $spec['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG from the theme icon registry. ?>
						<span class="screen-reader-text"><?php echo esc_html( $spec['label'] ); ?>: </span>
						<span class="lm-product-card__spec-value"><?php echo esc_html( $spec['value'] ); ?></span>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</div>
</article>
