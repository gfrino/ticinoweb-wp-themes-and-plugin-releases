<article <?php post_class( 'lm-product-card lm-product-card--part' ); ?>>
	<a class="lm-product-card__link" href="<?php the_permalink(); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Vedi %s', 'luismacchine-child-theme' ), get_the_title() ) ); ?>"></a>
	<div class="lm-product-card__media">
		<?php if ( has_post_thumbnail() ) : the_post_thumbnail( 'luismacchine-card', array( 'loading' => 'lazy' ) ); else : ?><div class="lm-product-card__placeholder"><?php echo luismacchine_icon( 'gear' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><?php endif; ?>
		<span class="lm-status lm-status--<?php echo esc_attr( get_post_meta( get_the_ID(), '_lm_status', true ) ?: 'disponibile' ); ?>"><?php echo esc_html( luismacchine_catalog_status( get_the_ID() ) ); ?></span>
	</div>
	<div class="lm-product-card__body">
		<?php $terms = get_the_terms( get_the_ID(), 'categoria-ricambio' ); if ( $terms && ! is_wp_error( $terms ) ) : ?><p class="lm-product-card__meta"><?php echo esc_html( $terms[0]->name ); ?></p><?php endif; ?>
		<h2 class="lm-product-card__title"><?php echo esc_html( get_the_title() ); ?></h2>
		<strong class="lm-product-card__price"><?php echo esc_html( luismacchine_catalog_price( get_the_ID() ) ); ?></strong>
		<?php if ( get_post_meta( get_the_ID(), '_lm_compatibility', true ) ) : ?><p class="lm-product-card__compatibility"><?php echo esc_html( get_post_meta( get_the_ID(), '_lm_compatibility', true ) ); ?></p><?php endif; ?>
	</div>
</article>
