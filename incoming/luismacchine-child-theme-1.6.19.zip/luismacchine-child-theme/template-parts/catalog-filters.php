<?php
$taxonomy = isset( $args['taxonomy'] ) ? $args['taxonomy'] : '';
$terms    = $taxonomy ? get_terms( array( 'taxonomy' => $taxonomy, 'hide_empty' => true ) ) : array();
$archive_url = get_post_type_archive_link( 'marca-veicolo' === $taxonomy ? LUISMACCHINE_VEHICLE_POST_TYPE : LUISMACCHINE_PART_POST_TYPE );
?>
<button class="lm-filter-toggle" type="button" aria-expanded="false" aria-controls="catalog-filters" data-filter-toggle><?php echo luismacchine_icon( 'filter' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php esc_html_e( 'Filtri e ordinamento', 'luismacchine-child-theme' ); ?></button>
<form class="lm-filters" id="catalog-filters" method="get" action="<?php echo esc_url( $archive_url . '#catalog-filters' ); ?>" data-filters data-loading="<?php esc_attr_e( 'Aggiornamento risultati…', 'luismacchine-child-theme' ); ?>" data-updated="<?php esc_attr_e( 'Risultati aggiornati.', 'luismacchine-child-theme' ); ?>" data-error="<?php esc_attr_e( 'Non è stato possibile aggiornare i risultati. Premi Applica per riprovare.', 'luismacchine-child-theme' ); ?>">
	<label><span><?php esc_html_e( 'Cerca', 'luismacchine-child-theme' ); ?></span><input type="search" name="cerca" value="<?php echo esc_attr( isset( $_GET['cerca'] ) && is_string( $_GET['cerca'] ) ? sanitize_text_field( wp_unslash( $_GET['cerca'] ) ) : '' ); ?>" placeholder="<?php esc_attr_e( 'Marca, modello o componente…', 'luismacchine-child-theme' ); ?>" autocomplete="off"></label>
	<div class="lm-filter-field">
		<span class="lm-filter-label" id="lm-filter-category-label"><?php esc_html_e( 'Categoria', 'luismacchine-child-theme' ); ?></span>
		<div class="lm-select" data-custom-select>
			<select class="lm-select__native" name="categoria" aria-labelledby="lm-filter-category-label"><option value=""><?php esc_html_e( 'Tutte', 'luismacchine-child-theme' ); ?></option><?php if ( ! is_wp_error( $terms ) ) : foreach ( $terms as $term ) : ?><option value="<?php echo esc_attr( $term->slug ); ?>" <?php selected( isset( $_GET['categoria'] ) && is_string( $_GET['categoria'] ) ? sanitize_title( wp_unslash( $_GET['categoria'] ) ) : '', $term->slug ); ?>><?php echo esc_html( $term->name ); ?></option><?php endforeach; endif; ?></select>
			<button class="lm-select__trigger" type="button" role="combobox" aria-haspopup="listbox" aria-expanded="false" aria-controls="lm-filter-category-options" aria-labelledby="lm-filter-category-label" data-select-trigger hidden><span data-select-value></span><span class="lm-select__chevron" aria-hidden="true"></span></button>
			<div class="lm-select__menu" id="lm-filter-category-options" role="listbox" aria-labelledby="lm-filter-category-label" data-select-menu hidden></div>
		</div>
	</div>
	<div class="lm-filter-field">
		<span class="lm-filter-label" id="lm-filter-sort-label"><?php esc_html_e( 'Ordina', 'luismacchine-child-theme' ); ?></span>
		<div class="lm-select" data-custom-select>
			<select class="lm-select__native" name="ordina" aria-labelledby="lm-filter-sort-label"><option value="recenti"><?php esc_html_e( 'Più recenti', 'luismacchine-child-theme' ); ?></option><option value="prezzo-asc" <?php selected( isset( $_GET['ordina'] ) && is_string( $_GET['ordina'] ) ? sanitize_key( wp_unslash( $_GET['ordina'] ) ) : '', 'prezzo-asc' ); ?>><?php esc_html_e( 'Prezzo crescente', 'luismacchine-child-theme' ); ?></option><option value="prezzo-desc" <?php selected( isset( $_GET['ordina'] ) && is_string( $_GET['ordina'] ) ? sanitize_key( wp_unslash( $_GET['ordina'] ) ) : '', 'prezzo-desc' ); ?>><?php esc_html_e( 'Prezzo decrescente', 'luismacchine-child-theme' ); ?></option></select>
			<button class="lm-select__trigger" type="button" role="combobox" aria-haspopup="listbox" aria-expanded="false" aria-controls="lm-filter-sort-options" aria-labelledby="lm-filter-sort-label" data-select-trigger hidden><span data-select-value></span><span class="lm-select__chevron" aria-hidden="true"></span></button>
			<div class="lm-select__menu" id="lm-filter-sort-options" role="listbox" aria-labelledby="lm-filter-sort-label" data-select-menu hidden></div>
		</div>
	</div>
	<button class="lm-button lm-button--gold" type="submit"><?php esc_html_e( 'Applica', 'luismacchine-child-theme' ); ?></button>
</form>
<p class="screen-reader-text" data-catalog-status role="status" aria-live="polite" aria-atomic="true"></p>
