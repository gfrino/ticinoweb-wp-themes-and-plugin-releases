<?php
/** Home FAQ: uses the native FAQ set assigned to the homepage. */
if ( ! defined( 'ABSPATH' ) || ! function_exists( 'ticinoweb_faq_get_set' ) ) {
	return;
}
$faq_ref = get_post_meta( get_queried_object_id(), TICINOWEB_FAQ_META_PAGE, true );
$faq_set = $faq_ref ? ticinoweb_faq_get_set( $faq_ref ) : null;
if ( ! $faq_set || empty( $faq_set['items'] ) ) {
	return;
}
$faq_items = array_values( array_filter( $faq_set['items'], static function ( $item ) {
	return '' !== trim( wp_strip_all_tags( $item['question'] ) ) && '' !== trim( wp_strip_all_tags( $item['answer'] ) );
} ) );
if ( ! $faq_items ) {
	return;
}
ticinoweb_faq_schema_add( $faq_items );
?>
<section class="lm-home-faq" aria-labelledby="lm-faq-title" id="domande-frequenti">
	<div class="lm-container">
		<p class="lm-eyebrow"><?php esc_html_e( 'Informazioni utili', 'luismacchine-child-theme' ); ?></p>
		<h2 id="lm-faq-title"><?php echo esc_html( $faq_set['title'] ); ?></h2>
		<?php if ( ! empty( $faq_set['intro'] ) ) : ?>
			<div class="lm-home-faq__intro"><?php echo wp_kses_post( wpautop( $faq_set['intro'] ) ); ?></div>
		<?php endif; ?>
		<div class="lm-home-faq__list">
			<?php foreach ( $faq_items as $index => $item ) : ?>
				<details class="lm-home-faq__item"<?php echo 0 === $index ? ' open' : ''; ?>>
					<summary><span><?php echo esc_html( $item['question'] ); ?></span><svg class="lm-home-faq__toggle" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true" focusable="false"><path d="M3 12h18"/><path class="lm-home-faq__vertical" d="M12 3v18"/></svg></summary>
					<div class="lm-home-faq__answer"><?php echo wp_kses_post( wpautop( $item['answer'] ) ); ?></div>
				</details>
			<?php endforeach; ?>
		</div>
	</div>
</section>
