<?php
$type    = isset( $args['type'] ) ? $args['type'] : 'vehicle';
$is_part = 'part' === $type;
$search  = isset( $_GET['cerca'] ) && is_string( $_GET['cerca'] ) ? sanitize_text_field( wp_unslash( $_GET['cerca'] ) ) : '';
$category = isset( $_GET['categoria'] ) && is_string( $_GET['categoria'] ) ? sanitize_title( wp_unslash( $_GET['categoria'] ) ) : '';
$filtered = '' !== $search || '' !== $category;
$title = $is_part ? __( 'Nessun ricambio disponibile al momento', 'luismacchine-child-theme' ) : __( 'Nessun veicolo disponibile al momento', 'luismacchine-child-theme' );
if ( $filtered ) {
	$title = __( 'Nessun risultato per la tua ricerca', 'luismacchine-child-theme' );
}
?>
<div class="lm-empty-state">
	<div class="lm-empty-state__icon"><?php echo luismacchine_icon( 'catalog-empty' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
	<div class="lm-empty-state__copy">
		<h3><?php echo esc_html( $title ); ?></h3>
		<p><?php echo esc_html( $filtered ? __( 'Prova a modificare i filtri oppure contattaci per indicarci cosa stai cercando.', 'luismacchine-child-theme' ) : __( 'Torna a trovarci per scoprire le prossime disponibilità. Nel frattempo, contattaci per indicarci cosa stai cercando.', 'luismacchine-child-theme' ) ); ?></p>
	</div>
	<a class="lm-text-link" href="<?php echo esc_url( luismacchine_page_url( 'contatti' ) ); ?>"><?php esc_html_e( 'Chiedi informazioni', 'luismacchine-child-theme' ); ?><?php echo luismacchine_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
</div>
