<?php get_header(); ?>
<main id="contenuto" style="<?php echo esc_attr( luismacchine_hero_media_style( 'part_hero' ) ); ?>">
	<header class="lm-page-hero lm-page-hero--catalog"><div class="lm-container"><p class="lm-eyebrow"><?php esc_html_e( 'Ricambi', 'luismacchine-child-theme' ); ?></p><h1><?php echo esc_html( luismacchine_page_title( 'parts' ) ); ?></h1><p><?php esc_html_e( 'Cerca per categoria o descrivi il componente che ti serve.', 'luismacchine-child-theme' ); ?></p></div></header>
	<section class="lm-section lm-archive"><div class="lm-container">
		<?php get_template_part( 'template-parts/catalog', 'filters', array( 'taxonomy' => 'categoria-ricambio' ) ); ?>
		<div data-catalog-results>
		<?php if ( have_posts() ) : ?><div class="lm-product-grid"><?php while ( have_posts() ) : the_post(); get_template_part( 'template-parts/card', 'part' ); endwhile; ?></div><?php the_posts_pagination( array( 'mid_size' => 1, 'prev_text' => __( 'Precedenti', 'luismacchine-child-theme' ), 'next_text' => __( 'Successivi', 'luismacchine-child-theme' ) ) ); else : get_template_part( 'template-parts/catalog', 'empty', array( 'type' => 'part' ) ); endif; ?>
		</div>
	</div></section>
</main>
<?php get_footer(); ?>
