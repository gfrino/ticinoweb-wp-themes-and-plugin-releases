<?php
/**
 * Services index and CMS-backed service detail pages.
 *
 * @package LuismacchineChildTheme
 */

get_header();

$services        = luismacchine_services();
$current_service = luismacchine_current_service();
$service_count   = count( $services );
$service_index   = $current_service && isset( $current_service['_index'] ) ? (int) $current_service['_index'] : 0;
$previous        = $current_service && $service_count > 1 ? $services[ ( $service_index - 1 + $service_count ) % $service_count ] : null;
$next            = $current_service && $service_count > 1 ? $services[ ( $service_index + 1 ) % $service_count ] : null;
$contact_url     = luismacchine_page_url( 'contatti' );
$contact         = luismacchine_contact_info();
$phone           = isset( $contact['phone'] ) ? trim( (string) $contact['phone'] ) : '';
$service_cta_url = $phone ? 'tel:' . luismacchine_phone_href( $phone ) : $contact_url;

if ( $current_service ) :
	$service_image = luismacchine_service_image_url( $current_service );
	?>
	<main id="contenuto" class="lm-services lm-service-detail">
		<section class="lm-services-hero lm-services-hero--detail<?php echo $service_image ? ' has-service-image' : ''; ?>">
			<?php if ( $service_image ) : ?><img class="lm-services-hero__image" src="<?php echo esc_url( $service_image ); ?>" width="1600" height="900" alt="" fetchpriority="high" decoding="async"><?php endif; ?>
			<div class="lm-container lm-services-hero__inner">
				<div class="lm-services-hero__copy">
					<a class="lm-services-hero__back" href="<?php echo esc_url( luismacchine_services_url() ); ?>">
						<?php echo luismacchine_icon( 'arrow', 'lm-services-hero__back-icon' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<?php esc_html_e( 'Tutti i servizi', 'luismacchine-child-theme' ); ?>
					</a>
					<h1><?php echo esc_html( $current_service['title'] ); ?></h1>
					<p class="lm-services-hero__lead"><?php echo esc_html( wp_strip_all_tags( $current_service['description'] ) ); ?></p>
					<div class="lm-services-hero__actions">
						<a class="lm-button lm-button--gold" href="<?php echo esc_url( $contact_url ); ?>">
							<?php esc_html_e( 'Parla con noi', 'luismacchine-child-theme' ); ?>
							<?php echo luismacchine_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</a>
						<?php if ( 'vendita' === sanitize_key( $current_service['id'] ) ) : ?>
							<a class="lm-button lm-button--ghost" href="<?php echo esc_url( get_post_type_archive_link( LUISMACCHINE_VEHICLE_POST_TYPE ) ); ?>"><?php esc_html_e( 'Vedi la vetrina auto', 'luismacchine-child-theme' ); ?></a>
						<?php elseif ( 'ricambi' === sanitize_key( $current_service['id'] ) ) : ?>
							<a class="lm-button lm-button--ghost" href="<?php echo esc_url( get_post_type_archive_link( LUISMACCHINE_PART_POST_TYPE ) ); ?>"><?php esc_html_e( 'Esplora i ricambi', 'luismacchine-child-theme' ); ?></a>
						<?php endif; ?>
					</div>
				</div>
				<div class="lm-services-hero__signature" aria-hidden="true"><span><?php echo esc_html( str_pad( (string) ( $service_index + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span><i></i><span><?php echo esc_html( str_pad( (string) $service_count, 2, '0', STR_PAD_LEFT ) ); ?></span></div>
			</div>
		</section>

		<?php if ( $service_count > 1 ) : ?>
			<nav class="lm-service-switcher" aria-label="<?php esc_attr_e( 'Naviga tra i servizi', 'luismacchine-child-theme' ); ?>">
				<div class="lm-container lm-service-switcher__inner">
					<?php if ( $previous ) : ?>
						<a class="lm-service-switcher__link lm-service-switcher__link--previous" href="<?php echo esc_url( luismacchine_service_url( $previous ) ); ?>">
							<span><?php esc_html_e( 'Servizio precedente', 'luismacchine-child-theme' ); ?></span>
							<strong><?php echo esc_html( $previous['title'] ); ?></strong>
						</a>
					<?php endif; ?>
					<a class="lm-service-switcher__all" href="<?php echo esc_url( luismacchine_services_url() ); ?>"><?php esc_html_e( 'Tutti i servizi', 'luismacchine-child-theme' ); ?></a>
					<?php if ( $next ) : ?>
						<a class="lm-service-switcher__link lm-service-switcher__link--next" href="<?php echo esc_url( luismacchine_service_url( $next ) ); ?>">
							<span><?php esc_html_e( 'Servizio successivo', 'luismacchine-child-theme' ); ?></span>
							<strong><?php echo esc_html( $next['title'] ); ?></strong>
						</a>
					<?php endif; ?>
				</div>
			</nav>
		<?php endif; ?>
	</main>
	<?php
else :
	?>
	<main id="contenuto" class="lm-services lm-services-index" style="<?php echo esc_attr( luismacchine_hero_media_style( 'services_hero' ) ); ?>">
		<section class="lm-services-hero" aria-labelledby="lm-services-title">
			<div class="lm-container lm-services-hero__inner">
				<div class="lm-services-hero__copy">
					<p class="lm-services-hero__eyebrow"><?php esc_html_e( 'Servizi', 'luismacchine-child-theme' ); ?></p>
					<h1 id="lm-services-title"><?php echo esc_html( luismacchine_page_title( 'services' ) ); ?></h1>
					<p class="lm-services-hero__lead"><?php esc_html_e( 'Officina, recupero, vendita, ricambi e riciclaggio. Un unico referente per ogni fase.', 'luismacchine-child-theme' ); ?></p>
				</div>
			</div>
		</section>

		<section class="lm-service-explorer" id="lm-service-carousel" aria-labelledby="lm-service-explorer-title" data-service-explorer>
			<div class="lm-container">
				<div class="lm-service-explorer__heading">
					<h2 id="lm-service-explorer-title"><?php echo esc_html( luismacchine_page_title( 'services_explorer' ) ); ?></h2>
				</div>

				<?php if ( $services ) : ?>
					<div class="lm-service-carousel" role="region" aria-roledescription="<?php esc_attr_e( 'Carosello', 'luismacchine-child-theme' ); ?>" aria-labelledby="lm-service-explorer-title">
						<div class="lm-service-carousel__slides" data-service-panels>
							<?php foreach ( $services as $index => $service ) :
								$image_url = luismacchine_service_image_url( $service );
								?>
								<article class="lm-service-slide<?php echo 0 === $index ? ' is-active' : ''; ?>" id="lm-service-panel-<?php echo esc_attr( (string) $index ); ?>" role="group" aria-roledescription="<?php esc_attr_e( 'Diapositiva', 'luismacchine-child-theme' ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Servizio %1$s di %2$s: %3$s', 'luismacchine-child-theme' ), str_pad( (string) ( $index + 1 ), 2, '0', STR_PAD_LEFT ), str_pad( (string) $service_count, 2, '0', STR_PAD_LEFT ), $service['title'] ) ); ?>" data-service-panel="<?php echo esc_attr( (string) $index ); ?>"<?php echo 0 === $index ? '' : ' hidden'; ?>>
									<div class="lm-service-slide__media">
										<?php if ( $image_url ) : ?>
											<img src="<?php echo esc_url( $image_url ); ?>" width="1200" height="900" alt="" loading="lazy" decoding="async">
										<?php else : ?>
											<div class="lm-service-slide__placeholder" aria-hidden="true"><span><?php esc_html_e( 'Immagine da inserire', 'luismacchine-child-theme' ); ?></span></div>
										<?php endif; ?>
									</div>
									<div class="lm-service-slide__content">
										<h3><?php echo esc_html( $service['title'] ); ?></h3>
										<p class="lm-service-slide__description"><?php echo esc_html( wp_strip_all_tags( $service['description'] ) ); ?></p>
										<a class="lm-service-slide__link" href="<?php echo esc_url( $service_cta_url ); ?>">
											<?php if ( $phone ) : ?>
												<?php esc_html_e( 'Parliamone al telefono', 'luismacchine-child-theme' ); ?>
												<?php echo luismacchine_icon( 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
											<?php else : ?>
												<?php esc_html_e( 'Contattaci', 'luismacchine-child-theme' ); ?>
												<?php echo luismacchine_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
											<?php endif; ?>
										</a>
										<div class="lm-service-slide__navigation">
											<div class="lm-service-slide__controls" aria-label="<?php esc_attr_e( 'Naviga tra i servizi', 'luismacchine-child-theme' ); ?>">
												<button type="button" data-service-previous aria-controls="lm-service-carousel" aria-label="<?php esc_attr_e( 'Servizio precedente', 'luismacchine-child-theme' ); ?>"<?php disabled( 1 === $service_count ); ?>><?php echo luismacchine_icon( 'arrow', 'is-reversed' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button>
												<button type="button" data-service-next aria-controls="lm-service-carousel" aria-label="<?php esc_attr_e( 'Servizio successivo', 'luismacchine-child-theme' ); ?>"<?php disabled( 1 === $service_count ); ?>><?php echo luismacchine_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button>
											</div>
										</div>
									</div>
								</article>
							<?php endforeach; ?>
						</div>
						<p class="screen-reader-text" role="status" aria-live="polite" data-service-status data-service-status-format="<?php echo esc_attr__( '%1$s, servizio %2$s di %3$s', 'luismacchine-child-theme' ); ?>"></p>
					</div>
					<noscript>
						<ul class="lm-service-fallback">
							<?php foreach ( $services as $service ) : ?>
								<li><a href="<?php echo esc_url( luismacchine_service_url( $service ) ); ?>"><?php echo esc_html( $service['title'] ); ?> <span>— <?php esc_html_e( 'Scopri il servizio', 'luismacchine-child-theme' ); ?></span></a></li>
							<?php endforeach; ?>
						</ul>
					</noscript>
				<?php else : ?>
					<p class="lm-service-explorer__empty"><?php esc_html_e( 'I servizi saranno presto disponibili. Nel frattempo, contattaci: ti aiuteremo a trovare la soluzione giusta.', 'luismacchine-child-theme' ); ?></p>
				<?php endif; ?>
			</div>
		</section>

		<section class="lm-service-contact">
			<div class="lm-container lm-service-contact__inner"><p><?php esc_html_e( 'Hai già in mente cosa ti serve?', 'luismacchine-child-theme' ); ?></p><a class="lm-button lm-button--gold" href="<?php echo esc_url( $contact_url ); ?>"><?php esc_html_e( 'Contattaci', 'luismacchine-child-theme' ); ?><?php echo luismacchine_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a></div>
		</section>
	</main>
	<?php
endif;

get_footer();
