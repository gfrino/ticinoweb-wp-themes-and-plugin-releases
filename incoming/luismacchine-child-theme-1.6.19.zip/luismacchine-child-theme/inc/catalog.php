<?php
/**
 * Catalog fields and filters for vehicles and spare parts.
 *
 * @package LuismacchineChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register the catalog taxonomies after the parent has registered its configurable CPTs.
 *
 * @return void
 */
function luismacchine_register_catalog_taxonomies() {
	register_taxonomy(
		'marca-veicolo',
		LUISMACCHINE_VEHICLE_POST_TYPE,
		array(
			'labels'            => array(
				'name'          => __( 'Marche', 'luismacchine-child-theme' ),
				'singular_name' => __( 'Marca', 'luismacchine-child-theme' ),
			),
			'public'            => true,
			'show_admin_column' => true,
			'show_in_rest'      => true,
			'hierarchical'      => false,
			'rewrite'           => array( 'slug' => 'marca' ),
		)
	);

	register_taxonomy(
		'categoria-ricambio',
		LUISMACCHINE_PART_POST_TYPE,
		array(
			'labels'            => array(
				'name'          => __( 'Categorie ricambi', 'luismacchine-child-theme' ),
				'singular_name' => __( 'Categoria ricambio', 'luismacchine-child-theme' ),
			),
			'public'            => true,
			'show_admin_column' => true,
			'show_in_rest'      => true,
			'hierarchical'      => true,
			'rewrite'           => array( 'slug' => 'categoria-ricambio' ),
		)
	);
}
add_action( 'init', 'luismacchine_register_catalog_taxonomies', 25 );

/**
 * Use the familiar WordPress editor for catalog entries so their fields are
 * not buried in the block editor's collapsed legacy-metabox area.
 *
 * @param bool   $use_block_editor Whether the block editor should be used.
 * @param string $post_type        Post type being edited.
 * @return bool
 */
function luismacchine_catalog_use_block_editor( $use_block_editor, $post_type ) {
	if ( in_array( $post_type, array( LUISMACCHINE_VEHICLE_POST_TYPE, LUISMACCHINE_PART_POST_TYPE ), true ) ) {
		return false;
	}

	return $use_block_editor;
}
add_filter( 'use_block_editor_for_post_type', 'luismacchine_catalog_use_block_editor', 10, 2 );

/**
 * Add a clear route back to the catalog list at the top of the editor.
 *
 * @param WP_Post $post Current post.
 * @return void
 */
function luismacchine_catalog_back_link( $post ) {
	if ( ! $post instanceof WP_Post || ! in_array( $post->post_type, array( LUISMACCHINE_VEHICLE_POST_TYPE, LUISMACCHINE_PART_POST_TYPE ), true ) ) {
		return;
	}

	$back_label = LUISMACCHINE_PART_POST_TYPE === $post->post_type
		? __( 'Torna a tutti i ricambi', 'luismacchine-child-theme' )
		: __( 'Torna a tutti i veicoli', 'luismacchine-child-theme' );
	$list_url   = add_query_arg( 'post_type', $post->post_type, admin_url( 'edit.php' ) );

	printf(
		'<a class="lm-catalog-back-link" href="%1$s"><span aria-hidden="true">←</span> %2$s</a>',
		esc_url( $list_url ),
		esc_html( $back_label )
	);
}
add_action( 'edit_form_top', 'luismacchine_catalog_back_link' );

/**
 * Catalog field definitions grouped for the WordPress editor.
 *
 * @param string $post_type Post type.
 * @return array
 */
function luismacchine_catalog_field_groups( $post_type ) {
	$common = array(
		'vendita' => array(
			'title'       => __( 'Prezzo e disponibilità', 'luismacchine-child-theme' ),
			'description' => __( 'Compila i dati essenziali per l’annuncio. Il prezzo è espresso in franchi svizzeri.', 'luismacchine-child-theme' ),
			'fields'      => array(
				'_lm_price'    => array( 'label' => __( 'Prezzo di vendita (CHF)', 'luismacchine-child-theme' ), 'type' => 'number', 'step' => '0.01', 'min' => '0', 'placeholder' => '48900', 'help' => __( 'Lascia vuoto se il prezzo è su richiesta.', 'luismacchine-child-theme' ) ),
				'_lm_status'   => array( 'label' => __( 'Stato dell’annuncio', 'luismacchine-child-theme' ), 'type' => 'select', 'default' => 'disponibile', 'options' => array( 'disponibile' => __( 'Disponibile', 'luismacchine-child-theme' ), 'riservato' => __( 'Riservato', 'luismacchine-child-theme' ), 'venduto' => __( 'Venduto', 'luismacchine-child-theme' ) ) ),
			),
		),
		'immagini' => array(
			'title'       => LUISMACCHINE_PART_POST_TYPE === $post_type ? __( 'Foto del ricambio', 'luismacchine-child-theme' ) : __( 'Foto del veicolo', 'luismacchine-child-theme' ),
			'description' => __( 'Imposta la foto principale dal riquadro “Immagine in evidenza” e aggiungi qui le altre foto. Per un risultato uniforme, consigliamo foto orizzontali 4:3, circa 1600 × 1200 px. Gli altri formati sono supportati e non vengono ritagliati.', 'luismacchine-child-theme' ),
			'fields'      => array(
				'_lm_gallery_ids' => array( 'label' => __( 'Galleria fotografica', 'luismacchine-child-theme' ), 'type' => 'gallery' ),
			),
		),
	);

	if ( LUISMACCHINE_VEHICLE_POST_TYPE === $post_type ) {
		$vehicle = array(
			'dati-principali' => array(
				'title'       => __( 'Dati principali', 'luismacchine-child-theme' ),
				'description' => __( 'Questi dati vengono usati nel riepilogo del veicolo. Inserisci solo valori verificati.', 'luismacchine-child-theme' ),
				'fields'      => array(
					'_lm_year'               => array( 'label' => __( 'Immatricolazione', 'luismacchine-child-theme' ), 'type' => 'text', 'placeholder' => '03.2020', 'help' => __( 'Formato mese.anno, per esempio 03.2020.', 'luismacchine-child-theme' ) ),
					'_lm_mileage'            => array( 'label' => __( 'Chilometri', 'luismacchine-child-theme' ), 'type' => 'number', 'step' => '1', 'min' => '0', 'placeholder' => '72000' ),
					'_lm_fuel'               => array( 'label' => __( 'Carburante', 'luismacchine-child-theme' ), 'type' => 'select', 'options' => array( 'benzina' => __( 'Benzina', 'luismacchine-child-theme' ), 'diesel' => __( 'Diesel', 'luismacchine-child-theme' ), 'ibrida' => __( 'Ibrida', 'luismacchine-child-theme' ), 'elettrica' => __( 'Elettrica', 'luismacchine-child-theme' ), 'gpl' => 'GPL', 'metano' => __( 'Metano', 'luismacchine-child-theme' ), 'altro' => __( 'Altro', 'luismacchine-child-theme' ) ), 'allow_empty' => true ),
					'_lm_transmission'       => array( 'label' => __( 'Cambio', 'luismacchine-child-theme' ), 'type' => 'select', 'options' => array( 'automatico' => __( 'Automatico', 'luismacchine-child-theme' ), 'manuale' => __( 'Manuale', 'luismacchine-child-theme' ), 'manuale-robotizzato' => __( 'Manuale robotizzato', 'luismacchine-child-theme' ), 'altro' => __( 'Altro', 'luismacchine-child-theme' ) ), 'allow_empty' => true ),
					'_lm_power_ps'           => array( 'label' => __( 'Potenza (PS)', 'luismacchine-child-theme' ), 'type' => 'number', 'step' => '1', 'min' => '0', 'placeholder' => '410' ),
					'_lm_power_kw'           => array( 'label' => __( 'Potenza (kW)', 'luismacchine-child-theme' ), 'type' => 'number', 'step' => '1', 'min' => '0', 'placeholder' => '302' ),
					'_lm_traction'           => array( 'label' => __( 'Trazione', 'luismacchine-child-theme' ), 'type' => 'select', 'options' => array( 'anteriore' => __( 'Anteriore', 'luismacchine-child-theme' ), 'posteriore' => __( 'Posteriore', 'luismacchine-child-theme' ), 'integrale' => __( 'Integrale', 'luismacchine-child-theme' ) ), 'allow_empty' => true ),
					'_lm_lease_monthly'      => array( 'label' => __( 'Rata leasing mensile (CHF)', 'luismacchine-child-theme' ), 'type' => 'number', 'step' => '0.01', 'min' => '0', 'placeholder' => '599', 'help' => __( 'Facoltativa. Inserisci la rata pubblicata per questo veicolo.', 'luismacchine-child-theme' ) ),
				),
			),
			'scheda-tecnica' => array(
				'title'       => __( 'Scheda tecnica', 'luismacchine-child-theme' ),
				'description' => __( 'Dettagli aggiuntivi mostrati nella scheda completa. Puoi lasciare vuoti i dati non disponibili.', 'luismacchine-child-theme' ),
				'fields'      => array(
					'_lm_body_type'       => array( 'label' => __( 'Tipo di carrozzeria', 'luismacchine-child-theme' ), 'type' => 'text', 'placeholder' => __( 'Berlina, coupé, SUV…', 'luismacchine-child-theme' ) ),
					'_lm_displacement_cc' => array( 'label' => __( 'Cilindrata (cm³)', 'luismacchine-child-theme' ), 'type' => 'number', 'step' => '1', 'min' => '0', 'placeholder' => '2979' ),
					'_lm_cylinders'       => array( 'label' => __( 'Cilindri', 'luismacchine-child-theme' ), 'type' => 'number', 'step' => '1', 'min' => '0' ),
					'_lm_engine_type'     => array( 'label' => __( 'Tipo di motore', 'luismacchine-child-theme' ), 'type' => 'text', 'placeholder' => __( 'Per esempio: in linea', 'luismacchine-child-theme' ) ),
					'_lm_gears'           => array( 'label' => __( 'Marce', 'luismacchine-child-theme' ), 'type' => 'number', 'step' => '1', 'min' => '0' ),
					'_lm_license_category'=> array( 'label' => __( 'Patente richiesta', 'luismacchine-child-theme' ), 'type' => 'text', 'placeholder' => 'B' ),
					'_lm_vehicle_condition'=> array( 'label' => __( 'Condizioni del veicolo', 'luismacchine-child-theme' ), 'type' => 'select', 'options' => array( 'occasione' => __( 'Occasione', 'luismacchine-child-theme' ), 'nuovo' => __( 'Nuovo', 'luismacchine-child-theme' ), 'dimostrativo' => __( 'Dimostrativo', 'luismacchine-child-theme' ) ), 'allow_empty' => true ),
					'_lm_new_price'        => array( 'label' => __( 'Prezzo da nuovo (CHF)', 'luismacchine-child-theme' ), 'type' => 'number', 'step' => '0.01', 'min' => '0' ),
					'_lm_importation'      => array( 'label' => __( 'Importazione diretta/parallela', 'luismacchine-child-theme' ), 'type' => 'select', 'options' => array( 'no' => __( 'No', 'luismacchine-child-theme' ), 'si' => __( 'Sì', 'luismacchine-child-theme' ) ), 'allow_empty' => true ),
					'_lm_doors'            => array( 'label' => __( 'Porte', 'luismacchine-child-theme' ), 'type' => 'number', 'step' => '1', 'min' => '0' ),
					'_lm_range'            => array( 'label' => __( 'Autonomia (km)', 'luismacchine-child-theme' ), 'type' => 'number', 'step' => '1', 'min' => '0', 'help' => __( 'Soprattutto per veicoli elettrici o ibridi plug-in.', 'luismacchine-child-theme' ) ),
				),
			),
			'dotazioni' => array(
				'title'       => __( 'Dotazioni, collaudo e garanzia', 'luismacchine-child-theme' ),
				'description' => __( 'Inserisci una dotazione per riga. Il testo verrà mostrato nella scheda del veicolo.', 'luismacchine-child-theme' ),
				'fields'      => array(
					'_lm_equipment' => array( 'label' => __( 'Dotazioni', 'luismacchine-child-theme' ), 'type' => 'textarea', 'rows' => 8, 'placeholder' => __( "Navigazione\nSensori di parcheggio\nSedili riscaldati", 'luismacchine-child-theme' ) ),
					'_lm_inspection'=> array( 'label' => __( 'Collaudo tecnico (CVM)', 'luismacchine-child-theme' ), 'type' => 'select', 'options' => array( 'si' => __( 'Sì', 'luismacchine-child-theme' ), 'no' => __( 'No', 'luismacchine-child-theme' ) ), 'allow_empty' => true ),
					'_lm_warranty'  => array( 'label' => __( 'Garanzia', 'luismacchine-child-theme' ), 'type' => 'text', 'placeholder' => __( 'Per esempio: 12 mesi', 'luismacchine-child-theme' ) ),
				),
			),
		);

		$images = $common['immagini'];
		unset( $common['immagini'] );
		$technical = $vehicle['scheda-tecnica'];
		unset( $vehicle['scheda-tecnica'] );
		$description = array(
			'title'  => __( 'Descrizione del veicolo', 'luismacchine-child-theme' ),
			'fields' => array(
				'content' => array(
					'label' => __( 'Descrizione (facoltativa)', 'luismacchine-child-theme' ),
					'type'  => 'textarea',
					'rows'  => 4,
					'help'  => __( 'Se lasci il campo vuoto, il pannello Descrizione non viene mostrato nella pagina del veicolo.', 'luismacchine-child-theme' ),
				),
			),
		);
		return array_merge( array( 'immagini' => $images, 'descrizione' => $description ), $common, $vehicle, array( 'scheda-tecnica' => $technical ) );
	}

	$common['vendita']['fields']['_lm_price']['placeholder'] = '1700';
	$common['vendita']['fields']['_lm_condition'] = array(
		'label' => __( 'Condizione', 'luismacchine-child-theme' ),
		'type' => 'select',
		'allow_empty' => true,
		'preserve_existing' => true,
		'options' => array(
			'Nuovo' => __( 'Nuovo', 'luismacchine-child-theme' ),
			'Usato' => __( 'Usato', 'luismacchine-child-theme' ),
			'Ricondizionato' => __( 'Ricondizionato', 'luismacchine-child-theme' ),
		),
		'help' => __( 'Aggiungi nella descrizione eventuali precisazioni, per esempio “mai montato”.', 'luismacchine-child-theme' ),
	);
	$common['dati-ricambio'] = array(
		'title'       => __( 'Informazioni sul ricambio', 'luismacchine-child-theme' ),
		'description' => __( 'Aggiungi i dati utili a identificare il pezzo e verificarne la compatibilità.', 'luismacchine-child-theme' ),
		'fields'      => array(
			'_lm_compatibility' => array( 'label' => __( 'Compatibilità', 'luismacchine-child-theme' ), 'type' => 'text', 'placeholder' => __( 'Marca, modello, versione e anni compatibili', 'luismacchine-child-theme' ), 'help' => __( 'Facoltativa. Inserisci solo compatibilità verificate; se non la conosci, lascia vuoto.', 'luismacchine-child-theme' ) ),
		),
	);
	$images = $common['immagini'];
	unset( $common['immagini'] );
	return array_merge( array( 'immagini' => $images ), $common );
}

/**
 * Explain the native description editor without creating a duplicate data field.
 */
function luismacchine_part_description_help( $post ) {
	if ( LUISMACCHINE_PART_POST_TYPE !== $post->post_type ) {
		return;
	}
	echo '<h2>' . esc_html__( 'Descrizione del ricambio', 'luismacchine-child-theme' ) . '</h2>';
	echo '<p class="lm-admin-intro">' . esc_html__( 'Descrivi il pezzo, la marca e le caratteristiche utili. Inserisci qui dettagli come “200 celle”, “mai montato” ed eventuali informazioni verificate sull’omologazione. Usa il riquadro Categoria per classificare il ricambio.', 'luismacchine-child-theme' ) . '</p>';
}
add_action( 'edit_form_after_title', 'luismacchine_part_description_help', 20 );

/**
 * Keep media management in the dedicated photo controls, not the description.
 *
 * @param array  $settings  Native editor settings.
 * @param string $editor_id Editor identifier.
 * @return array
 */
function luismacchine_part_description_editor_settings( $settings, $editor_id ) {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( 'content' === $editor_id && $screen && LUISMACCHINE_PART_POST_TYPE === $screen->post_type ) {
		$settings['media_buttons']     = false;
		$settings['drag_drop_upload']  = false;
	}
	return $settings;
}
add_filter( 'wp_editor_settings', 'luismacchine_part_description_editor_settings', 10, 2 );

/**
 * Add the catalog details metabox.
 *
 * @return void
 */
function luismacchine_add_catalog_metaboxes() {
	foreach ( array( LUISMACCHINE_VEHICLE_POST_TYPE, LUISMACCHINE_PART_POST_TYPE ) as $post_type ) {
		foreach ( luismacchine_catalog_field_groups( $post_type ) as $group_id => $group ) {
			add_meta_box( 'luismacchine-catalog-' . $group_id, $group['title'], 'luismacchine_render_catalog_metabox', $post_type, 'normal', 'high', array( 'group_id' => $group_id, 'group' => $group ) );
		}
	}
}
add_action( 'add_meta_boxes', 'luismacchine_add_catalog_metaboxes' );

/**
 * Use the full editor for catalog entries; leave other post types unchanged.
 *
 * @param bool   $enabled   Whether Quick Edit is enabled.
 * @param string $post_type Post type name.
 * @return bool
 */
function luismacchine_vehicle_quick_edit_enabled( $enabled, $post_type ) {
	return in_array( $post_type, array( LUISMACCHINE_VEHICLE_POST_TYPE, LUISMACCHINE_PART_POST_TYPE ), true ) ? false : $enabled;
}
add_filter( 'quick_edit_enabled_for_post_type', 'luismacchine_vehicle_quick_edit_enabled', 10, 2 );

/**
 * Keep the catalog field groups in a predictable order for every editor.
 *
 * @param mixed        $order  Saved meta-box order.
 * @param string       $option User option name.
 * @return mixed
 */
function luismacchine_catalog_fixed_metabox_order( $order, $option ) {
	$post_type = str_replace( 'meta-box-order_', '', $option );
	if ( ! in_array( $post_type, array( LUISMACCHINE_VEHICLE_POST_TYPE, LUISMACCHINE_PART_POST_TYPE ), true ) ) {
		return $order;
	}

	if ( ! is_array( $order ) ) {
		$order = array();
	}

	$group_ids = array();
	foreach ( array_keys( luismacchine_catalog_field_groups( $post_type ) ) as $group_id ) {
		$group_ids[] = 'luismacchine-catalog-' . $group_id;
	}
	$order['normal'] = implode( ',', $group_ids );
	foreach ( array( 'side', 'advanced' ) as $context ) {
		if ( isset( $order[ $context ] ) ) {
			$order[ $context ] = implode( ',', array_diff( explode( ',', (string) $order[ $context ] ), $group_ids ) );
		}
	}

	return $order;
}
add_filter( 'get_user_option_meta-box-order_vetrina-auto', 'luismacchine_catalog_fixed_metabox_order', 10, 2 );
add_filter( 'get_user_option_meta-box-order_ricambio', 'luismacchine_catalog_fixed_metabox_order', 10, 2 );

/**
 * Render catalog inputs.
 *
 * @param WP_Post $post Current post.
 * @return void
 */
function luismacchine_render_catalog_metabox( $post, $box ) {
	$group = isset( $box['args']['group'] ) ? $box['args']['group'] : array();
	if ( empty( $group['fields'] ) ) {
		return;
	}
	if ( 'vendita' === $box['args']['group_id'] ) {
		wp_nonce_field( 'luismacchine_save_catalog', 'luismacchine_catalog_nonce' );
	}
	if ( ! empty( $group['description'] ) ) {
		printf( '<p class="lm-admin-intro">%s</p>', esc_html( $group['description'] ) );
	}

	echo '<div class="lm-admin-fields">';
	foreach ( $group['fields'] as $key => $field ) {
		// The native content field is saved by WordPress, not as duplicate metadata.
		$value       = 'content' === $key ? $post->post_content : get_post_meta( $post->ID, $key, true );
		if ( '' === $value && isset( $field['default'] ) ) {
			$value = $field['default'];
		}
		$field_class = 'lm-admin-field';
		if ( 'textarea' === $field['type'] || 'gallery' === $field['type'] ) {
			$field_class .= ' lm-admin-field--wide';
		}
		printf( '<div class="%1$s">', esc_attr( $field_class ) );
		if ( 'checkbox' === $field['type'] ) {
			printf( '<label class="lm-admin-check" for="%1$s"><input id="%1$s" name="%1$s" type="checkbox" value="1" %2$s><span><strong>%3$s</strong>%4$s</span></label>', esc_attr( $key ), checked( $value, '1', false ), esc_html( $field['label'] ), empty( $field['help'] ) ? '' : '<small>' . esc_html( $field['help'] ) . '</small>' );
		} else {
			printf( '<label for="%1$s"><strong>%2$s</strong></label>', esc_attr( $key ), esc_html( $field['label'] ) );
			if ( 'select' === $field['type'] ) {
				printf( '<select class="widefat" id="%1$s" name="%1$s">', esc_attr( $key ) );
				if ( ! empty( $field['allow_empty'] ) ) {
					printf( '<option value="">%s</option>', esc_html__( 'Seleziona…', 'luismacchine-child-theme' ) );
				}
				// Keep legacy free-text conditions selectable until explicitly replaced.
				if ( ! empty( $field['preserve_existing'] ) && '' !== $value && ! isset( $field['options'][ $value ] ) ) {
					printf( '<option value="%1$s" selected>%2$s</option>', esc_attr( $value ), esc_html( $value ) );
				}
				foreach ( $field['options'] as $option_value => $option_label ) {
					printf( '<option value="%1$s" %2$s>%3$s</option>', esc_attr( $option_value ), selected( $value, $option_value, false ), esc_html( $option_label ) );
				}
				echo '</select>';
			} elseif ( 'gallery' === $field['type'] ) {
				$gallery_ids = array_filter( array_unique( array_map( 'absint', explode( ',', (string) $value ) ) ) );
				printf( '<input id="%1$s" name="%1$s" type="hidden" value="%2$s"><div class="lm-admin-gallery" data-gallery-preview aria-live="polite">', esc_attr( $key ), esc_attr( $value ) );
				foreach ( $gallery_ids as $gallery_id ) {
					$attachment = get_post( $gallery_id );
					if ( ! $attachment || 'attachment' !== $attachment->post_type || ! wp_attachment_is_image( $gallery_id ) ) {
						continue;
					}
					$image_label = sprintf( __( 'Rimuovi la foto “%s”', 'luismacchine-child-theme' ), get_the_title( $gallery_id ) );
					printf( '<div class="lm-admin-gallery-item" data-gallery-item data-attachment-id="%1$d">%2$s<button class="button" type="button" data-gallery-remove aria-label="%3$s">%4$s</button></div>', absint( $gallery_id ), wp_get_attachment_image( $gallery_id, 'thumbnail', false, array( 'alt' => '', 'loading' => 'lazy' ) ), esc_attr( $image_label ), esc_html__( 'Rimuovi', 'luismacchine-child-theme' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				}
				if ( empty( $gallery_ids ) ) {
					echo '<p class="lm-admin-gallery-empty">' . esc_html__( 'Non hai ancora aggiunto foto alla galleria.', 'luismacchine-child-theme' ) . '</p>';
				}
				echo '</div>';
				printf( '<div class="lm-admin-gallery-actions"><button class="button button-primary" type="button" data-gallery-select>%1$s</button><button class="button" type="button" data-gallery-clear>%2$s</button></div>', esc_html__( 'Aggiungi foto', 'luismacchine-child-theme' ), esc_html__( 'Rimuovi tutte', 'luismacchine-child-theme' ) );
				echo '<p class="description">' . esc_html__( 'Puoi aggiungere una foto alla volta oppure selezionarne più insieme. Le foto già inserite vengono mantenute.', 'luismacchine-child-theme' ) . '</p>';
			} elseif ( 'textarea' === $field['type'] ) {
				printf( '<textarea class="widefat" id="%1$s" name="%1$s" rows="%2$d" placeholder="%3$s">%4$s</textarea>', esc_attr( $key ), isset( $field['rows'] ) ? absint( $field['rows'] ) : 5, isset( $field['placeholder'] ) ? esc_attr( $field['placeholder'] ) : '', esc_textarea( $value ) );
			} else {
				$numeric_attributes = 'number' === $field['type'] ? sprintf( ' step="%1$s" min="%2$s"', isset( $field['step'] ) ? esc_attr( $field['step'] ) : 'any', isset( $field['min'] ) ? esc_attr( $field['min'] ) : '' ) : '';
				printf( '<input class="widefat" id="%1$s" name="%1$s" type="%2$s"%3$s value="%4$s" placeholder="%5$s">', esc_attr( $key ), esc_attr( $field['type'] ), $numeric_attributes, esc_attr( $value ), isset( $field['placeholder'] ) ? esc_attr( $field['placeholder'] ) : '' );
			}
			if ( ! empty( $field['help'] ) ) {
				printf( '<p class="description">%s</p>', esc_html( $field['help'] ) );
			}
		}
		echo '</div>';
	}
	echo '</div>';
}

/**
 * Save sanitized catalog data.
 *
 * @param int $post_id Post ID.
 * @return void
 */
function luismacchine_save_catalog_meta( $post_id ) {
	if ( ! isset( $_POST['luismacchine_catalog_nonce'] ) || ! is_string( $_POST['luismacchine_catalog_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['luismacchine_catalog_nonce'] ) ), 'luismacchine_save_catalog' ) ) {
		return;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || wp_is_post_revision( $post_id ) ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$post_type = get_post_type( $post_id );
	if ( ! in_array( $post_type, array( LUISMACCHINE_VEHICLE_POST_TYPE, LUISMACCHINE_PART_POST_TYPE ), true ) ) {
		return;
	}

	foreach ( luismacchine_catalog_field_groups( $post_type ) as $group ) {
		foreach ( $group['fields'] as $key => $field ) {
			if ( 'content' === $key ) {
				continue;
			}
			if ( 'checkbox' === $field['type'] ) {
				$value = isset( $_POST[ $key ] ) ? '1' : '';
			} elseif ( ! isset( $_POST[ $key ] ) ) {
				continue;
			} elseif ( ! is_string( $_POST[ $key ] ) ) {
				continue;
			} elseif ( 'number' === $field['type'] ) {
				$raw   = str_replace( ',', '.', sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) );
				$value = is_numeric( $raw ) && (float) $raw >= 0 ? $raw : '';
			} elseif ( 'gallery' === $field['type'] ) {
				$ids   = array_filter( array_map( 'absint', explode( ',', sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) ) ) );
				$ids   = array_filter( $ids, function ( $id ) { return 'attachment' === get_post_type( $id ) && wp_attachment_is_image( $id ); } );
				$value = implode( ',', array_unique( $ids ) );
			} elseif ( 'textarea' === $field['type'] ) {
				$value = sanitize_textarea_field( wp_unslash( $_POST[ $key ] ) );
			} elseif ( 'select' === $field['type'] ) {
				$raw   = sanitize_text_field( wp_unslash( $_POST[ $key ] ) );
				$value = isset( $field['options'][ $raw ] ) ? $raw : '';
				if ( ! empty( $field['preserve_existing'] ) && $raw === get_post_meta( $post_id, $key, true ) ) {
					$value = $raw;
				}
			} else {
				$value = sanitize_text_field( wp_unslash( $_POST[ $key ] ) );
			}

			if ( '' === $value ) {
				delete_post_meta( $post_id, $key );
			} else {
				update_post_meta( $post_id, $key, $value );
			}
		}
	}
}
add_action( 'save_post', 'luismacchine_save_catalog_meta' );

/**
 * Load media tools only on catalog edit screens.
 *
 * @param string $hook_suffix Current admin hook.
 * @return void
 */
function luismacchine_catalog_admin_assets( $hook_suffix ) {
	if ( ! in_array( $hook_suffix, array( 'post.php', 'post-new.php' ), true ) ) {
		return;
	}
	$screen = get_current_screen();
	if ( ! $screen || ! in_array( $screen->post_type, array( LUISMACCHINE_VEHICLE_POST_TYPE, LUISMACCHINE_PART_POST_TYPE ), true ) ) {
		return;
	}
	wp_enqueue_media();
	wp_enqueue_script( 'luismacchine-catalog-admin', luismacchine_asset_url( 'assets/js/admin-catalog.js' ), array( 'jquery' ), LUISMACCHINE_THEME_VERSION, true );
	wp_enqueue_style( 'luismacchine-catalog-admin', luismacchine_asset_url( 'assets/css/admin-catalog.css' ), array(), LUISMACCHINE_THEME_VERSION );
	wp_localize_script(
		'luismacchine-catalog-admin',
		'luismacchineCatalogAdmin',
		array(
			'frameTitle'  => __( 'Scegli le foto', 'luismacchine-child-theme' ),
			'frameButton' => __( 'Aggiungi alla galleria', 'luismacchine-child-theme' ),
			'emptyGallery' => __( 'Non hai ancora aggiunto foto alla galleria.', 'luismacchine-child-theme' ),
			'removeImage'  => __( 'Rimuovi', 'luismacchine-child-theme' ),
			'confirmGalleryClear' => __( 'Vuoi rimuovere tutte le foto dalla galleria? La modifica sarà salvata solo quando aggiorni il veicolo.', 'luismacchine-child-theme' ),
		)
	);
}
add_action( 'admin_enqueue_scripts', 'luismacchine_catalog_admin_assets' );

/**
 * Make the catalog overview scannable for a non-technical editor.
 *
 * @param array  $columns Existing columns.
 * @param string $post_type Current post type.
 * @return array
 */
function luismacchine_catalog_admin_columns( $columns, $post_type = '' ) {
	if ( ! $post_type ) {
		$screen    = get_current_screen();
		$post_type = $screen ? $screen->post_type : '';
	}
	if ( ! in_array( $post_type, array( LUISMACCHINE_VEHICLE_POST_TYPE, LUISMACCHINE_PART_POST_TYPE ), true ) ) {
		return $columns;
	}
	$custom = array();
	foreach ( $columns as $key => $label ) {
		if ( 'cb' === $key ) {
			$custom[ $key ] = $label;
			$custom['lm_thumbnail'] = __( 'Foto', 'luismacchine-child-theme' );
			continue;
		}
		$custom[ $key ] = $label;
		if ( 'title' === $key ) {
			$custom['lm_price'] = __( 'Prezzo', 'luismacchine-child-theme' );
			$custom['lm_status'] = __( 'Disponibilità', 'luismacchine-child-theme' );
		}
	}
	return $custom;
}
add_filter( 'manage_posts_columns', 'luismacchine_catalog_admin_columns', 20, 2 );
add_filter( 'manage_' . LUISMACCHINE_VEHICLE_POST_TYPE . '_posts_columns', 'luismacchine_catalog_admin_columns', 20, 2 );
add_filter( 'manage_' . LUISMACCHINE_PART_POST_TYPE . '_posts_columns', 'luismacchine_catalog_admin_columns', 20, 2 );

/**
 * Render catalog overview columns.
 *
 * @param string $column Column key.
 * @param int    $post_id Post ID.
 * @return void
 */
function luismacchine_catalog_admin_column_content( $column, $post_id ) {
	if ( 'lm_thumbnail' === $column ) {
		if ( has_post_thumbnail( $post_id ) ) {
			echo wp_kses_post( get_the_post_thumbnail( $post_id, array( 72, 54 ), array( 'class' => 'lm-admin-list-thumb', 'alt' => '' ) ) );
		} else {
			echo '<span class="lm-admin-list-thumb lm-admin-list-thumb--empty" aria-label="' . esc_attr__( 'Nessuna foto', 'luismacchine-child-theme' ) . '">—</span>';
		}
	} elseif ( 'lm_price' === $column ) {
		echo esc_html( luismacchine_catalog_price( $post_id ) );
	} elseif ( 'lm_status' === $column ) {
		echo esc_html( luismacchine_catalog_status( $post_id ) );
	}
}
add_action( 'manage_' . LUISMACCHINE_VEHICLE_POST_TYPE . '_posts_custom_column', 'luismacchine_catalog_admin_column_content', 10, 2 );
add_action( 'manage_' . LUISMACCHINE_PART_POST_TYPE . '_posts_custom_column', 'luismacchine_catalog_admin_column_content', 10, 2 );

/**
 * Allow sorting the catalog list by its CHF price.
 *
 * @param array $columns Sortable columns.
 * @return array
 */
function luismacchine_catalog_admin_sortable_columns( $columns ) {
	$columns['lm_price'] = 'lm_price';
	return $columns;
}
add_filter( 'manage_edit-' . LUISMACCHINE_VEHICLE_POST_TYPE . '_sortable_columns', 'luismacchine_catalog_admin_sortable_columns' );
add_filter( 'manage_edit-' . LUISMACCHINE_PART_POST_TYPE . '_sortable_columns', 'luismacchine_catalog_admin_sortable_columns' );

/**
 * Apply sorting by CHF price in the catalog list.
 *
 * @param WP_Query $query Admin query.
 * @return void
 */
function luismacchine_catalog_admin_orderby( $query ) {
	if ( ! is_admin() || ! $query->is_main_query() || 'lm_price' !== $query->get( 'orderby' ) ) {
		return;
	}
	$post_type = $query->get( 'post_type' );
	if ( ! in_array( $post_type, array( LUISMACCHINE_VEHICLE_POST_TYPE, LUISMACCHINE_PART_POST_TYPE ), true ) ) {
		return;
	}
	$query->set( 'meta_key', '_lm_price' );
	$query->set( 'orderby', 'meta_value_num' );
}
add_action( 'pre_get_posts', 'luismacchine_catalog_admin_orderby' );

/**
 * Apply public archive filters.
 *
 * @param WP_Query $query Query object.
 * @return void
 */
function luismacchine_catalog_archive_query( $query ) {
	if ( is_admin() || ! $query->is_main_query() || ! $query->is_post_type_archive( array( LUISMACCHINE_VEHICLE_POST_TYPE, LUISMACCHINE_PART_POST_TYPE ) ) ) {
		return;
	}
	$query->set( 'posts_per_page', 12 );

	$search = isset( $_GET['cerca'] ) && is_string( $_GET['cerca'] ) ? sanitize_text_field( wp_unslash( $_GET['cerca'] ) ) : '';
	if ( $search ) {
		$query->set( 's', $search );
	}

	$taxonomy = $query->is_post_type_archive( LUISMACCHINE_VEHICLE_POST_TYPE ) ? 'marca-veicolo' : 'categoria-ricambio';
	$term     = isset( $_GET['categoria'] ) && is_string( $_GET['categoria'] ) ? sanitize_title( wp_unslash( $_GET['categoria'] ) ) : '';
	if ( $term ) {
		$query->set( 'tax_query', array( array( 'taxonomy' => $taxonomy, 'field' => 'slug', 'terms' => $term ) ) );
	}

	$sort = isset( $_GET['ordina'] ) && is_string( $_GET['ordina'] ) ? sanitize_key( wp_unslash( $_GET['ordina'] ) ) : 'recenti';
	if ( in_array( $sort, array( 'prezzo-asc', 'prezzo-desc' ), true ) ) {
		$query->set( 'meta_key', '_lm_price' );
		$query->set( 'orderby', 'meta_value_num' );
		$query->set( 'order', 'prezzo-asc' === $sort ? 'ASC' : 'DESC' );
	}
}
add_action( 'pre_get_posts', 'luismacchine_catalog_archive_query' );

/**
 * Format a CHF price.
 *
 * @param int $post_id Post ID.
 * @return string
 */
function luismacchine_catalog_price( $post_id ) {
	$price = get_post_meta( $post_id, '_lm_price', true );
	return is_numeric( $price ) ? sprintf( 'CHF %s.–', number_format_i18n( (float) $price, 0 ) ) : __( 'Prezzo su richiesta', 'luismacchine-child-theme' );
}

/**
 * Human readable availability.
 *
 * @param int $post_id Post ID.
 * @return string
 */
function luismacchine_catalog_status( $post_id ) {
	$status = get_post_meta( $post_id, '_lm_status', true );
	$labels = array( 'disponibile' => __( 'Disponibile', 'luismacchine-child-theme' ), 'riservato' => __( 'Riservato', 'luismacchine-child-theme' ), 'venduto' => __( 'Venduto', 'luismacchine-child-theme' ) );
	return isset( $labels[ $status ] ) ? $labels[ $status ] : $labels['disponibile'];
}

/**
 * Return gallery attachment IDs, with the featured image first.
 *
 * @param int $post_id Post ID.
 * @return int[]
 */
function luismacchine_catalog_gallery_ids( $post_id ) {
	$ids      = array_filter( array_map( 'absint', explode( ',', (string) get_post_meta( $post_id, '_lm_gallery_ids', true ) ) ) );
	$featured = get_post_thumbnail_id( $post_id );
	if ( $featured ) {
		array_unshift( $ids, $featured );
	}
	$ids = array_values( array_unique( $ids ) );
	return array_values(
		array_filter(
			$ids,
			function ( $image_id ) {
				return 'attachment' === get_post_type( $image_id ) && wp_attachment_is_image( $image_id );
			}
		)
	);
}

/**
 * Return useful alternative text for a catalog image.
 *
 * @param int $image_id Attachment ID.
 * @return string
 */
function luismacchine_catalog_image_alt( $image_id ) {
	$alt = trim( (string) get_post_meta( $image_id, '_wp_attachment_image_alt', true ) );
	return '' !== $alt ? $alt : get_the_title( $image_id );
}

/**
 * Render a compact product gallery and its accessible image viewer.
 *
 * @param int[] $gallery Ordered attachment IDs, with the featured image first.
 * @return bool Whether a gallery was rendered.
 */
function luismacchine_render_detail_gallery( $gallery ) {
	$gallery = array_values( array_filter( array_unique( array_map( 'absint', (array) $gallery ) ) ) );
	$gallery = array_values(
		array_filter(
			$gallery,
			function ( $image_id ) {
				return 'attachment' === get_post_type( $image_id ) && wp_attachment_is_image( $image_id );
			}
		)
	);

	if ( empty( $gallery ) ) {
		return false;
	}

	$total         = count( $gallery );
	$visible_count = min( 3, $total - 1 );
	$overflow      = max( 0, $total - 3 );

	echo '<div class="lm-detail__gallery">';
	$main_url = wp_get_attachment_image_url( $gallery[0], 'full' );
	printf(
		'<a class="lm-detail__photo lm-detail__photo--main" href="%1$s" data-gallery-open data-gallery-index="0" aria-label="%2$s">%3$s</a>',
		esc_url( $main_url ),
		esc_attr( sprintf( __( 'Apri foto 1 di %s', 'luismacchine-child-theme' ), number_format_i18n( $total ) ) ),
		wp_get_attachment_image( $gallery[0], 'luismacchine-gallery', false, array( 'alt' => luismacchine_catalog_image_alt( $gallery[0] ), 'loading' => 'eager', 'fetchpriority' => 'high', 'decoding' => 'async' ) ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	);

	if ( $visible_count > 0 ) {
		$thumbnail_class = $visible_count < 3 ? ' lm-detail__thumbnails--few' : '';
		printf( '<div class="lm-detail__thumbnails%1$s" style="--lm-gallery-thumbs:%2$d">', esc_attr( $thumbnail_class ), absint( $visible_count ) );
		for ( $index = 1; $index <= $visible_count; $index++ ) {
			$image_id = $gallery[ $index ];
			$image_url = wp_get_attachment_image_url( $image_id, 'full' );
			$is_overflow = 3 === $index && $total > 3;
			$classes = 'lm-detail__photo lm-detail__photo--thumb';
			if ( $is_overflow ) {
				$classes .= ' lm-detail__photo--overflow';
			}

			printf(
				'<a class="%1$s" href="%2$s" data-gallery-open data-gallery-index="%3$d" aria-label="%4$s">%5$s%6$s</a>',
				esc_attr( $classes ),
				esc_url( $image_url ),
				absint( $index ),
				esc_attr( $is_overflow ? sprintf( __( 'Apri tutte le foto: %s immagini', 'luismacchine-child-theme' ), number_format_i18n( $overflow ) ) : sprintf( __( 'Apri foto %1$s di %2$s', 'luismacchine-child-theme' ), number_format_i18n( $index + 1 ), number_format_i18n( $total ) ) ),
				wp_get_attachment_image( $image_id, 'medium_large', false, array( 'alt' => luismacchine_catalog_image_alt( $image_id ), 'loading' => 'lazy', 'decoding' => 'async' ) ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				$is_overflow ? '<span class="lm-detail__photo-count">' . esc_html( sprintf( _n( '+ %s immagine', '+ %s immagini', $overflow, 'luismacchine-child-theme' ), number_format_i18n( $overflow ) ) ) . '</span>' : ''
			);
		}
		echo '</div>';
	}
	echo '</div>';

	printf( '<dialog class="lm-gallery-viewer" data-gallery-dialog aria-label="%s">', esc_attr__( 'Galleria fotografica', 'luismacchine-child-theme' ) );
	echo '<div class="lm-gallery-viewer__bar">';
	echo '<span class="lm-gallery-viewer__title">' . esc_html__( 'Galleria fotografica', 'luismacchine-child-theme' ) . '</span>';
	echo '<button class="lm-gallery-viewer__close" type="button" data-gallery-close aria-label="' . esc_attr__( 'Chiudi la galleria', 'luismacchine-child-theme' ) . '"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18"/></svg></button>';
	echo '</div><div class="lm-gallery-viewer__stage">';
	foreach ( $gallery as $index => $image_id ) {
		$image_url = wp_get_attachment_image_url( $image_id, 'full' );
		printf(
			'<figure data-gallery-slide="%1$d"%2$s>%3$s</figure>',
			absint( $index ),
			0 === $index ? '' : ' hidden',
			wp_get_attachment_image( $image_id, 'full', false, array( 'alt' => luismacchine_catalog_image_alt( $image_id ), 'loading' => 0 === $index ? 'eager' : 'lazy', 'decoding' => 'async' ) ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		);
	}
	echo '</div><div class="lm-gallery-viewer__controls">';
	echo '<button class="lm-gallery-viewer__step" type="button" data-gallery-previous aria-label="' . esc_attr__( 'Foto precedente', 'luismacchine-child-theme' ) . '"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m15 18-6-6 6-6"/></svg></button>';
	printf( '<span data-gallery-counter aria-live="polite">1 / %s</span>', esc_html( number_format_i18n( $total ) ) );
	echo '<button class="lm-gallery-viewer__step" type="button" data-gallery-next aria-label="' . esc_attr__( 'Foto successiva', 'luismacchine-child-theme' ) . '"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg></button>';
	echo '</div></dialog>';

	return true;
}
