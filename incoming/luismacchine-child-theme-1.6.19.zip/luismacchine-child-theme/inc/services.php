<?php
/**
 * Public service routes and CMS-backed service helpers.
 *
 * @package LuismacchineChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Allow the child route variable through WordPress' public query parser.
 *
 * @param array $vars Public query variables.
 * @return array
 */
function luismacchine_service_query_vars( $vars ) {
	$vars[] = 'lm_service';
	return $vars;
}
add_filter( 'query_vars', 'luismacchine_service_query_vars' );

/**
 * Resolve the requested CMS service by its stable ID.
 *
 * @return array|null
 */
function luismacchine_current_service() {
	$query_value = get_query_var( 'lm_service' );
	$requested = is_string( $query_value ) ? sanitize_title( $query_value ) : '';
	if ( '' === $requested ) {
		return null;
	}

	foreach ( luismacchine_services() as $index => $service ) {
		$id = isset( $service['id'] ) ? sanitize_title( $service['id'] ) : '';
		if ( $id === $requested ) {
			$service['_index'] = $index;
			return $service;
		}
	}

	return null;
}

/**
 * Return the public URL for a service detail page.
 *
 * @param array $service CMS service.
 * @return string
 */
function luismacchine_service_url( $service ) {
	$base = luismacchine_services_url();
	$id   = isset( $service['id'] ) ? sanitize_title( $service['id'] ) : '';

	if ( $id && ! get_option( 'permalink_structure' ) ) {
		return add_query_arg( 'lm_service', $id, $base );
	}
	return $id ? trailingslashit( $base ) . rawurlencode( $id ) . '/' : $base;
}

/**
 * Return the permalink of the existing Services page.
 *
 * @return string
 */
function luismacchine_services_url() {
	return luismacchine_page_url( 'servizi' );
}

/**
 * Return an approved same-site service image URL from the parent CMS.
 *
 * @param array $service CMS service.
 * @return string
 */
function luismacchine_service_image_url( $service ) {
	if ( empty( $service['image'] ) ) {
		return '';
	}

	$url       = esc_url_raw( $service['image'] );
	$host      = wp_parse_url( $url, PHP_URL_HOST );
	$site_host = wp_parse_url( home_url(), PHP_URL_HOST );

	if ( ! $url || ! $host || ! $site_host || strtolower( $host ) !== strtolower( $site_host ) ) {
		return '';
	}

	return $url;
}

/**
 * Redirect malformed or stale service detail URLs to the services index.
 *
 * @return void
 */
function luismacchine_validate_service_route() {
	if ( ! luismacchine_is_page( 'servizi' ) || ! get_query_var( 'lm_service' ) || luismacchine_current_service() ) {
		return;
	}

	wp_safe_redirect( luismacchine_services_url(), 302, 'Luismacchine service route' );
	exit;
}
add_action( 'template_redirect', 'luismacchine_validate_service_route', 1 );

/**
 * Use the selected service detail URL as canonical instead of the index URL.
 *
 * @param string $canonical Parent-generated canonical URL.
 * @return string
 */
function luismacchine_service_canonical( $canonical ) {
	$service = luismacchine_is_page( 'servizi' ) ? luismacchine_current_service() : null;
	return $service ? luismacchine_service_url( $service ) : $canonical;
}
add_filter( 'ticinoweb_seo_canonical_url', 'luismacchine_service_canonical' );

/**
 * Make the document title specific to the selected service detail.
 *
 * @param array $parts Document title parts.
 * @return array
 */
function luismacchine_service_document_title( $parts ) {
	$service = luismacchine_is_page( 'servizi' ) ? luismacchine_current_service() : null;
	if ( ! $service ) {
		return $parts;
	}

	$parts['title'] = sprintf(
		/* translators: %s: service name. */
		__( '%s | Servizi', 'luismacchine-child-theme' ),
		sanitize_text_field( $service['title'] )
	);
	unset( $parts['site'], $parts['tagline'] );
	return $parts;
}
add_filter( 'ticinoweb_seo_document_title_parts', 'luismacchine_service_document_title' );

/**
 * Reuse the CMS description for service-level search and social summaries.
 *
 * @param string $description Existing description.
 * @return string
 */
function luismacchine_service_meta_description( $description ) {
	$service = luismacchine_is_page( 'servizi' ) ? luismacchine_current_service() : null;
	if ( ! $service || empty( $service['description'] ) ) {
		return $description;
	}

	return wp_trim_words( wp_strip_all_tags( $service['description'] ), 28, '…' );
}
add_filter( 'ticinoweb_seo_meta_description', 'luismacchine_service_meta_description' );

/**
 * Keep the Open Graph title aligned with the selected service.
 *
 * @param string $title Existing social title.
 * @return string
 */
function luismacchine_service_og_title( $title ) {
	$service = luismacchine_is_page( 'servizi' ) ? luismacchine_current_service() : null;
	return $service ? sanitize_text_field( $service['title'] ) : $title;
}
add_filter( 'ticinoweb_seo_og_title', 'luismacchine_service_og_title' );

/**
 * Set the Open Graph URL to the selected service detail route.
 *
 * @param string $url Existing social URL.
 * @return string
 */
function luismacchine_service_og_url( $url ) {
	$service = luismacchine_is_page( 'servizi' ) ? luismacchine_current_service() : null;
	return $service ? luismacchine_service_url( $service ) : $url;
}
add_filter( 'ticinoweb_seo_og_url', 'luismacchine_service_og_url' );

