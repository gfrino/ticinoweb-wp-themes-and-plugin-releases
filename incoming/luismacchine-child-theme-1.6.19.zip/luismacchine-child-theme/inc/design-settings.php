<?php
/** Look & Feel integration: existing parent options remain authoritative. */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Only bundled or system fonts: no remote font requests or implied downloads. */
function luismacchine_available_fonts() {
	return array(
		'Barlow' => 'Barlow, sans-serif',
		'Barlow Condensed' => '"Barlow Condensed", sans-serif',
		'Arial' => 'Arial, Helvetica, sans-serif',
		'Verdana' => 'Verdana, sans-serif',
		'Georgia' => 'Georgia, serif',
	);
}

function luismacchine_design_fields() {
	return array(
		'ticinoweb_font_headings' => array( 'token' => '--lm-display', 'default' => 'Barlow Condensed' ),
		'ticinoweb_font_subheadings' => array( 'token' => '--lm-subheadings', 'default' => 'Barlow Condensed' ),
		'ticinoweb_font_body' => array( 'token' => '--lm-body', 'default' => 'Barlow' ),
		'ticinoweb_palette_suggested_1' => array( 'token' => '--lm-ink', 'default' => '#070709', 'label' => __( 'Sfondo principale', 'luismacchine-child-theme' ) ),
		'ticinoweb_palette_suggested_2' => array( 'token' => '--lm-surface', 'default' => '#101114', 'label' => __( 'Superfici e schede', 'luismacchine-child-theme' ) ),
		'ticinoweb_palette_suggested_3' => array( 'token' => '--lm-text', 'default' => '#f5f3ec', 'label' => __( 'Testo principale', 'luismacchine-child-theme' ) ),
	);
}

function luismacchine_design_value( $key, $value = null ) {
	$fields = luismacchine_design_fields();
	if ( ! isset( $fields[ $key ] ) ) {
		return '';
	}
	if ( null === $value ) {
		$value = get_option( $key, $fields[ $key ]['default'] );
	}
	$valid = is_string( $value ) && ( isset( $fields[ $key ]['label'] ) ? sanitize_hex_color( $value ) : isset( luismacchine_available_fonts()[ $value ] ) );
	return $valid ? $value : $fields[ $key ]['default'];
}

/** Preserve current valid fonts if the parent submits an unsupported font. */
function luismacchine_validate_design_fonts() {
	foreach ( array( 'headings', 'subheadings', 'body' ) as $role ) {
		$key = 'ticinoweb_font_' . $role;
		add_filter( 'sanitize_option_' . $key, static function ( $value ) use ( $key ) {
			if ( is_string( $value ) && isset( luismacchine_available_fonts()[ $value ] ) ) {
				return $value;
			}
			return luismacchine_design_value( $key );
		}, 20 );
	}
}
add_action( 'admin_init', 'luismacchine_validate_design_fonts', 30 );

function luismacchine_enqueue_design_settings() {
	$fonts = luismacchine_available_fonts();
	$css = ':root{';
	foreach ( luismacchine_design_fields() as $key => $field ) {
		$value = luismacchine_design_value( $key );
		$css .= $field['token'] . ':' . ( isset( $field['label'] ) ? $value : $fonts[ $value ] ) . ';';
	}
	$css .= '} .lm-site h3,.lm-site h4,.lm-site h5,.lm-site h6{font-family:var(--lm-subheadings)}';
	wp_add_inline_style( 'luismacchine-site', $css );
}
add_action( 'wp_enqueue_scripts', 'luismacchine_enqueue_design_settings', 35 );

/** Adapt the parent's existing controls; no second form or option namespace. */
function luismacchine_admin_design_settings( $hook ) {
	if ( 'toplevel_page_ticinoweb-cms' !== $hook ) {
		return;
	}
	$fields = luismacchine_design_fields();
	foreach ( $fields as $key => &$field ) {
		$field['value'] = luismacchine_design_value( $key );
	}
	unset( $field );
	wp_enqueue_script( 'luismacchine-design-settings', luismacchine_asset_url( 'assets/js/admin-design-settings.js' ), array( 'jquery', 'wp-color-picker' ), LUISMACCHINE_THEME_VERSION, true );
	wp_localize_script( 'luismacchine-design-settings', 'lmDesignSettings', array(
		'fields' => $fields,
		'fonts' => array_keys( luismacchine_available_fonts() ),
		'paletteLabel' => __( 'Colori del sito', 'luismacchine-child-theme' ),
		'paletteHelp' => __( 'Questi colori controllano sfondo, superfici e testo. Gli oscuramenti delle foto e i colori degli stati restano dedicati. Verifica sempre la leggibilità dopo una modifica.', 'luismacchine-child-theme' ),
		'accentHelp' => __( 'Colore di accento per pulsanti, link e dettagli. Le tonalità chiare e scure vengono derivate automaticamente.', 'luismacchine-child-theme' ),
		'fontHelp' => __( 'Font locali o di sistema, senza caricamenti da Google. Base del design: Barlow Condensed per titoli e sottotitoli, Barlow per i testi.', 'luismacchine-child-theme' ),
	) );
}
add_action( 'admin_enqueue_scripts', 'luismacchine_admin_design_settings', 30 );
