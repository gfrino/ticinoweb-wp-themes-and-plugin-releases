<?php
/** CMS page roles, using the parent's mapping as the only source. */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function luismacchine_page_roles() {
	return array( 'servizi' => 'page_servizi', 'chi-siamo' => 'page_chi_siamo', 'contatti' => 'page_contatti' );
}

function luismacchine_page_id( $role ) {
	$roles = luismacchine_page_roles();
	if ( ! isset( $roles[ $role ] ) ) {
		return 0;
	}
	$id = function_exists( 'ticinoweb_get_mapped_page_id' ) ? ticinoweb_get_mapped_page_id( $roles[ $role ] ) : 0;
	$page = $id ? get_post( $id ) : null;
	if ( ! $page || 'page' !== $page->post_type || 'publish' !== $page->post_status ) {
		$page = get_page_by_path( $role );
	}
	return $page && 'publish' === $page->post_status ? (int) $page->ID : 0;
}

function luismacchine_page_url( $role ) {
	$id = luismacchine_page_id( $role );
	if ( ! $id ) {
		return home_url( '/' );
	}
	$url = get_permalink( $id );
	return function_exists( 'ticinoweb_frontend_url' ) ? ticinoweb_frontend_url( $url, 'theme:url:page_mapping_' . luismacchine_page_roles()[ $role ] ) : $url;
}

function luismacchine_is_page( $role ) {
	$id = luismacchine_page_id( $role );
	return $id && is_page( $id );
}

/** A newly selected page must receive the same layout, not just a new link. */
function luismacchine_mapped_template( $template ) {
	foreach ( luismacchine_page_roles() as $role => $key ) {
		if ( luismacchine_is_page( $role ) ) {
			return get_stylesheet_directory() . '/page-' . $role . '.php';
		}
	}
	return $template;
}
add_filter( 'template_include', 'luismacchine_mapped_template', 99 );

/** Keep the existing custom menu links in sync without rewriting menu records. */
function luismacchine_mapped_menu( $items, $args ) {
	if ( 'primary' !== $args->theme_location ) {
		return $items;
	}
	foreach ( $items as $item ) {
		foreach ( luismacchine_page_roles() as $role => $key ) {
			if ( untrailingslashit( $item->url ) === untrailingslashit( home_url( '/' . $role . '/' ) ) ) {
				$item->url = luismacchine_page_url( $role );
				$item->current = luismacchine_is_page( $role );
				$item->classes = array_diff( $item->classes, array( 'current-menu-item', 'current_page_item' ) );
				if ( $item->current ) {
					$item->classes[] = 'current-menu-item';
				}
				break;
			}
		}
	}
	return $items;
}
add_filter( 'wp_nav_menu_objects', 'luismacchine_mapped_menu', 20, 2 );

/** Build service routes from the actual page URI, including nested pages. */
function luismacchine_service_rewrite_rules( $rules ) {
	$rules = is_array( $rules ) ? $rules : array();
	foreach ( $rules as $pattern => $query ) {
		if ( preg_match( '/^index\\.php\\?(?:page_id=\\d+|pagename=servizi)&lm_service=\\$matches\\[1\\]$/', $query ) ) {
			unset( $rules[ $pattern ] );
		}
	}
	$id = luismacchine_page_id( 'servizi' );
	$uri = $id ? get_page_uri( $id ) : '';
	if ( $uri && get_option( 'permalink_structure' ) ) {
		$rules = array( '^' . preg_quote( $uri, '#' ) . '/([^/]+)/?$' => 'index.php?page_id=' . $id . '&lm_service=$matches[1]' ) + $rules;
	}
	return $rules;
}
// Apply in memory as well: mapping/slug edits work immediately without global flushes.
add_filter( 'option_rewrite_rules', 'luismacchine_service_rewrite_rules' );
add_filter( 'rewrite_rules_array', 'luismacchine_service_rewrite_rules' );
