<?php
/**
 * Page-specific content. Global identity, services and about content stay in the parent CMS.
 *
 * @package LuismacchineChildTheme
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function luismacchine_page_title_fields() {
	return array(
		'home_line_one' => array( __( 'Home — titolo, prima riga', 'luismacchine-child-theme' ), __( 'Passione per', 'luismacchine-child-theme' ) ),
		'home_line_two' => array( __( 'Home — titolo, seconda riga', 'luismacchine-child-theme' ), __( 'i motori.', 'luismacchine-child-theme' ) ),
		'home_line_three' => array( __( 'Home — titolo, riga evidenziata', 'luismacchine-child-theme' ), __( 'Soluzioni concrete.', 'luismacchine-child-theme' ) ),
		'home_services' => array( __( 'Home — sezione servizi', 'luismacchine-child-theme' ), __( 'Ogni fase. Una sola officina.', 'luismacchine-child-theme' ) ),
		'home_market' => array( __( 'Home — sezione cataloghi', 'luismacchine-child-theme' ), __( 'Rimettersi in strada.', 'luismacchine-child-theme' ) ),
		'home_contact' => array( __( 'Home — invito al contatto', 'luismacchine-child-theme' ), __( 'Parliamo della tua auto.', 'luismacchine-child-theme' ) ),
		'services' => array( __( 'Servizi — titolo principale', 'luismacchine-child-theme' ), __( 'Un riferimento. Ogni fase.', 'luismacchine-child-theme' ) ),
		'services_explorer' => array( __( 'Servizi — elenco servizi', 'luismacchine-child-theme' ), __( 'Di cosa hai bisogno?', 'luismacchine-child-theme' ) ),
		'vehicles' => array( __( 'Vetrina auto — titolo principale', 'luismacchine-child-theme' ), __( 'Veicoli disponibili', 'luismacchine-child-theme' ) ),
		'parts' => array( __( 'Ricambi — titolo principale', 'luismacchine-child-theme' ), __( 'Catalogo ricambi', 'luismacchine-child-theme' ) ),
		'contacts' => array( __( 'Contatti — titolo principale', 'luismacchine-child-theme' ), __( 'Parliamo del tuo veicolo', 'luismacchine-child-theme' ) ),
		'hours' => array( __( 'Contatti — orari', 'luismacchine-child-theme' ), __( 'Orari di apertura', 'luismacchine-child-theme' ) ),
		'about_contact' => array( __( 'Chi siamo — invito al contatto', 'luismacchine-child-theme' ), __( 'La fiducia comincia da una conversazione.', 'luismacchine-child-theme' ) ),
	);
}

function luismacchine_sanitize_page_titles( $input ) {
	$input = is_array( $input ) ? $input : array();
	$clean = array();
	foreach ( luismacchine_page_title_fields() as $key => $field ) {
		$clean[ $key ] = isset( $input[ $key ] ) && is_string( $input[ $key ] ) ? sanitize_text_field( $input[ $key ] ) : '';
	}
	return $clean;
}

function luismacchine_page_title( $key ) {
	$fields = luismacchine_page_title_fields();
	$saved  = get_option( 'luismacchine_page_titles', array() );
	if ( ! isset( $fields[ $key ] ) ) {
		return '';
	}
	$title = isset( $saved[ $key ] ) && is_string( $saved[ $key ] ) && '' !== trim( $saved[ $key ] ) ? $saved[ $key ] : $fields[ $key ][1];
	return function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( $title, 'theme:luismacchine:title:' . $key ) : $title;
}

/** Output an escaped CSS custom property; the existing shade stays untouched. */
function luismacchine_hero_media_style( $key ) {
	$id  = luismacchine_home_image_id( $key );
	$url = $id ? wp_get_attachment_image_url( $id, 'full' ) : '';
	return $url ? '--lm-cms-hero-image:url(' . wp_json_encode( esc_url_raw( $url ), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ) . ')' : '';
}

/** Respect explicit per-page SEO; repair the empty static-home fallback only. */
function luismacchine_complete_meta_description( $description ) {
	if ( is_front_page() && '' === trim( (string) $description ) ) {
		$description = sanitize_text_field( get_option( 'tw_seo_description', '' ) );
	}
	if ( is_post_type_archive( LUISMACCHINE_VEHICLE_POST_TYPE ) ) {
		$description = luismacchine_page_title( 'vehicles' ) . '. ' . __( 'Consulta foto, prezzi e dati tecnici delle auto. Contattaci per maggiori dettagli o per fissare un incontro.', 'luismacchine-child-theme' );
	} elseif ( is_post_type_archive( LUISMACCHINE_PART_POST_TYPE ) ) {
		$description = luismacchine_page_title( 'parts' ) . '. ' . __( 'Cerca il componente per la tua auto, consulta foto, prezzi e compatibilità e contattaci per informazioni.', 'luismacchine-child-theme' );
	}
	return mb_strlen( $description ) > 160 ? mb_substr( $description, 0, 157 ) . '…' : $description;
}
add_filter( 'ticinoweb_seo_meta_description', 'luismacchine_complete_meta_description' );

/** Replace the parent's Article for catalog records rather than adding duplicate schema. */
function luismacchine_catalog_product_schema( $schema, $post ) {
	if ( ! in_array( $post->post_type, array( LUISMACCHINE_VEHICLE_POST_TYPE, LUISMACCHINE_PART_POST_TYPE ), true ) ) {
		return $schema;
	}
	$product = array(
		'@context' => 'https://schema.org',
		'@type'    => 'Product',
		'name'     => wp_strip_all_tags( get_the_title( $post ) ),
		'url'      => get_permalink( $post ),
	);
	$description = trim( wp_strip_all_tags( strip_shortcodes( $post->post_content ) ) );
	if ( $description ) {
		$product['description'] = $description;
	}
	$images = array();
	foreach ( luismacchine_catalog_gallery_ids( $post->ID ) as $id ) {
		$url = wp_get_attachment_image_url( $id, 'full' );
		if ( $url ) {
			$images[] = $url;
		}
	}
	if ( $images ) {
		$product['image'] = array_values( array_unique( $images ) );
	}
	$price = get_post_meta( $post->ID, '_lm_price', true );
	if ( is_numeric( $price ) && (float) $price >= 0 ) {
		$status = get_post_meta( $post->ID, '_lm_status', true );
		$availability = array( 'disponibile' => 'InStock', 'riservato' => 'OutOfStock', 'venduto' => 'SoldOut' );
		$product['offers'] = array(
			'@type' => 'Offer',
			'url' => get_permalink( $post ),
			'priceCurrency' => 'CHF',
			'price' => number_format( (float) $price, 2, '.', '' ),
			'availability' => 'https://schema.org/' . ( isset( $availability[ $status ] ) ? $availability[ $status ] : 'InStock' ),
		);
	}
	return $product;
}
add_filter( 'ticinoweb_seo_jsonld_article_schema', 'luismacchine_catalog_product_schema', 10, 2 );
