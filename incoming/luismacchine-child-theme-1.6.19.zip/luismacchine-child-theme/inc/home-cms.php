<?php
/**
 * Homepage media settings for Luismacchine.
 *
 * @package LuismacchineChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sanitize selected media attachment IDs.
 *
 * @param mixed $value Submitted settings.
 * @return array<string,int>
 */
function luismacchine_sanitize_home_media( $value ) {
	$value  = is_array( $value ) ? $value : array();
	$fields = array(
		'hero_poster'        => 'image',
		'story_image'        => 'image',
		'vehicle_door_image' => 'image',
		'vehicle_hero'       => 'image',
		'part_hero'          => 'image',
		'services_hero'      => 'image',
	);
	$clean  = array();

	foreach ( $fields as $key => $type ) {
		$id   = isset( $value[ $key ] ) && is_scalar( $value[ $key ] ) ? absint( $value[ $key ] ) : 0;
		$mime = $id ? get_post_mime_type( $id ) : '';
		if ( $id && 'attachment' !== get_post_type( $id ) ) {
			$mime = '';
		}

		if ( 'image' === $type && luismacchine_home_image_mime_allowed( $mime ) ) {
			$clean[ $key ] = $id;
		} else {
			$clean[ $key ] = 0;
		}
	}

	return $clean;
}

/**
 * Register the child-specific media option and CMS submenu.
 *
 * @return void
 */
function luismacchine_register_content_settings() {
	register_setting(
		'luismacchine_home_media_group',
		'luismacchine_home_media',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'luismacchine_sanitize_home_media',
			'default'           => array(),
			'show_in_rest'      => false,
		)
	);
	register_setting( 'luismacchine_home_media_group', 'luismacchine_page_titles', array( 'type' => 'array', 'sanitize_callback' => 'luismacchine_sanitize_page_titles', 'default' => array(), 'show_in_rest' => false ) );
}
add_action( 'admin_init', 'luismacchine_register_content_settings' );
function luismacchine_register_home_cms() {
	add_submenu_page(
		'ticinoweb-cms',
		__( 'Contenuti pagine', 'luismacchine-child-theme' ),
		__( 'Contenuti pagine', 'luismacchine-child-theme' ),
		'edit_pages',
		'luismacchine-home',
		'luismacchine_render_home_cms'
	);
}
add_action( 'admin_menu', 'luismacchine_register_home_cms', 20 );
add_filter( 'option_page_capability_luismacchine_home_media_group', 'luismacchine_home_media_capability' );

/**
 * Let the same editors who can access the parent CMS save homepage media.
 *
 * @param string $capability Required capability.
 * @return string
 */
function luismacchine_home_media_capability( $capability ) {
	return 'edit_pages';
}

/**
 * Render one homepage media selector.
 *
 * @param string $key         Option key.
 * @param string $label       Field label.
 * @param string $description Help text.
 * @param string $type        Media type.
 * @param int    $id          Selected attachment ID.
 * @return void
 */
function luismacchine_render_home_media_field( $key, $label, $description, $type, $id ) {
	$defaults = array(
		'hero_poster'        => 'hero-clean-plate.jpg',
		'story_image'        => 'garage-detail.jpg',
		'vehicle_door_image' => 'hero-final-frame.jpg',
		'vehicle_hero'       => 'hero-garage.jpg',
		'part_hero'          => 'hero-ricambi.jpg',
		'services_hero'      => 'garage-detail.jpg',
	);
	$default_preview = isset( $defaults[ $key ] ) ? luismacchine_asset_url( 'assets/images/' . $defaults[ $key ] ) : '';
	$preview = luismacchine_home_image_url( $key, $default_preview, 'medium' );
	$empty_text = __( 'Nessuna immagine disponibile.', 'luismacchine-child-theme' );
	$wide_hero = in_array( $key, array( 'vehicle_hero', 'part_hero' ), true );
	$image_advice = $wide_hero
		? __( 'Dimensioni consigliate: 2048 × 768 px, formato panoramico (8:3).', 'luismacchine-child-theme' )
		: __( 'Dimensioni consigliate: 1920 × 1080 px, formato orizzontale (16:9).', 'luismacchine-child-theme' );
	?>
	<div class="lm-home-cms__field">
		<div>
			<strong><?php echo esc_html( $label ); ?></strong>
			<p class="description"><?php echo esc_html( $description ); ?></p>
			<p class="description"><?php echo esc_html( $image_advice ); ?></p>
		</div>
		<div class="lm-home-cms__picker">
			<input type="hidden" name="luismacchine_home_media[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $id ); ?>" data-media-id>
			<div class="lm-home-cms__preview" data-media-preview data-default-preview="<?php echo esc_url( $default_preview ); ?>" data-empty-text="<?php echo esc_attr( $empty_text ); ?>">
				<?php if ( $preview ) : ?>
					<img src="<?php echo esc_url( $preview ); ?>" alt="" loading="lazy" decoding="async">
				<?php else : ?>
					<span><?php echo esc_html( $empty_text ); ?></span>
				<?php endif; ?>
			</div>
			<button class="button button-secondary" type="button" data-media-select data-media-key="<?php echo esc_attr( $key ); ?>" data-media-type="<?php echo esc_attr( $type ); ?>" data-media-title="<?php echo esc_attr( $label ); ?>"><?php esc_html_e( 'Scegli dalla Libreria media', 'luismacchine-child-theme' ); ?></button>
			<button class="button-link-delete" type="button" data-media-clear><?php esc_html_e( 'Ripristina predefinita', 'luismacchine-child-theme' ); ?></button>
		</div>
	</div>
	<?php
}

/**
 * Render the Luismacchine homepage media administration screen.
 *
 * @return void
 */
function luismacchine_render_home_cms() {
	if ( ! current_user_can( 'edit_pages' ) ) {
		return;
	}
	$media = wp_parse_args(
		get_option( 'luismacchine_home_media', array() ),
		array(
			'hero_poster'        => 0,
			'story_image'        => 0,
			'vehicle_door_image' => 0,
		)
	);
	?>
	<div class="wrap lm-home-cms">
		<h1><?php esc_html_e( 'Contenuti pagine', 'luismacchine-child-theme' ); ?></h1>
		<p><?php esc_html_e( 'Gestisci i titoli e le immagini principali. Titolo, testo e foto di Chi siamo, singoli servizi, contatti e logo restano nelle rispettive sezioni del CMS. Le foto e i titoli dei prodotti si modificano nelle singole schede.', 'luismacchine-child-theme' ); ?></p>
		<p class="description"><?php esc_html_e( 'Le misure sono consigliate, non obbligatorie. Usa JPG o WebP ottimizzati, preferibilmente sotto 500 KB. Il ritaglio può cambiare su mobile: lascia margine attorno al soggetto e non inserire testi nella foto. Dove previsto, l’oscuramento viene applicato dal sito: non serve scurire l’immagine prima di caricarla.', 'luismacchine-child-theme' ); ?></p>
		<form action="options.php" method="post">
			<?php settings_fields( 'luismacchine_home_media_group' ); ?>
			<h2><?php esc_html_e( 'Hero cinematografica', 'luismacchine-child-theme' ); ?></h2>
			<div class="lm-home-cms__grid">
				<?php
				luismacchine_render_home_media_field( 'hero_poster', __( 'Immagine di copertina', 'luismacchine-child-theme' ), __( 'Immagine di sfondo della sezione iniziale della home.', 'luismacchine-child-theme' ), 'image', $media['hero_poster'] );
				?>
			</div>
			<h2><?php esc_html_e( 'Immagini delle sezioni', 'luismacchine-child-theme' ); ?></h2>
			<div class="lm-home-cms__grid">
				<?php
				luismacchine_render_home_media_field( 'story_image', __( '“Qui le auto non sono numeri”', 'luismacchine-child-theme' ), __( 'Immagine narrativa della sezione dedicata alla storia e all’approccio dell’azienda.', 'luismacchine-child-theme' ), 'image', $media['story_image'] );
				luismacchine_render_home_media_field( 'vehicle_door_image', __( 'Vetrina auto', 'luismacchine-child-theme' ), __( 'Immagine di sfondo del collegamento al catalogo Veicoli.', 'luismacchine-child-theme' ), 'image', $media['vehicle_door_image'] );
				?>
			</div>
			<h2><?php esc_html_e( 'Sfondi delle pagine', 'luismacchine-child-theme' ); ?></h2>
			<p><?php esc_html_e( 'L’oscuramento rimane applicato dal sito a qualsiasi foto selezionata. Consigliate immagini orizzontali con spazio libero per il testo.', 'luismacchine-child-theme' ); ?></p>
			<div class="lm-home-cms__grid">
				<?php foreach ( array( 'vehicle_hero' => __( 'Vetrina auto', 'luismacchine-child-theme' ), 'part_hero' => __( 'Ricambi', 'luismacchine-child-theme' ), 'services_hero' => __( 'Servizi', 'luismacchine-child-theme' ) ) as $key => $label ) {
					luismacchine_render_home_media_field( $key, $label, __( 'Immagine della hero. Lascia vuoto per mantenere la foto approvata.', 'luismacchine-child-theme' ), 'image', isset( $media[ $key ] ) ? absint( $media[ $key ] ) : 0 );
				} ?>
			</div>
			<h2><?php esc_html_e( 'Titoli delle pagine e delle sezioni', 'luismacchine-child-theme' ); ?></h2>
			<p><?php esc_html_e( 'Lascia un campo vuoto per usare il testo originale. I titoli visibili non sostituiscono le impostazioni SEO.', 'luismacchine-child-theme' ); ?></p>
			<?php $titles = get_option( 'luismacchine_page_titles', array() ); ?>
			<?php foreach ( luismacchine_page_title_fields() as $key => $field ) : ?>
				<p><label for="lm-title-<?php echo esc_attr( $key ); ?>"><strong><?php echo esc_html( $field[0] ); ?></strong></label><br>
				<input class="large-text" id="lm-title-<?php echo esc_attr( $key ); ?>" name="luismacchine_page_titles[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( isset( $titles[ $key ] ) ? $titles[ $key ] : '' ); ?>" placeholder="<?php echo esc_attr( $field[1] ); ?>" type="text"></p>
			<?php endforeach; ?>
			<?php submit_button( __( 'Salva contenuti', 'luismacchine-child-theme' ) ); ?>
		</form>
		<hr>
		<p><a href="<?php echo esc_url( admin_url( 'admin.php?page=ticinoweb-cms#theme-images' ) ); ?>"><?php esc_html_e( 'Apri Look & Feel per logo e palette', 'luismacchine-child-theme' ); ?></a></p>
	</div>
	<?php
}

/**
 * Load the media picker only on the homepage settings screen.
 *
 * @param string $hook_suffix Current admin hook.
 * @return void
 */
function luismacchine_home_cms_assets( $hook_suffix ) {
	if ( 'ticinoweb-cms_page_luismacchine-home' !== $hook_suffix ) {
		return;
	}

	wp_enqueue_media();
	wp_enqueue_script( 'luismacchine-home-cms', luismacchine_asset_url( 'assets/js/admin-home-cms.js' ), array( 'jquery' ), LUISMACCHINE_THEME_VERSION, true );
	wp_localize_script(
		'luismacchine-home-cms',
		'luismacchineHomeCms',
		array(
			'buttonText'       => __( 'Usa questo file', 'luismacchine-child-theme' ),
			'unsupportedImage' => __( 'Seleziona un’immagine JPG, PNG, WebP o AVIF.', 'luismacchine-child-theme' ),
		)
	);
	wp_register_style( 'luismacchine-home-cms', false, array(), LUISMACCHINE_THEME_VERSION );
	wp_enqueue_style( 'luismacchine-home-cms' );
	wp_add_inline_style( 'luismacchine-home-cms', '.lm-home-cms__grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:20px;margin:20px 0 38px}.lm-home-cms__field{display:grid;gap:14px;padding:20px;border:1px solid #c3c4c7;background:#fff}.lm-home-cms__field p{max-width:60ch}.lm-home-cms__picker{display:flex;align-items:center;flex-wrap:wrap;gap:10px}.lm-home-cms__preview{display:flex;width:180px;max-width:100%;height:110px;flex:0 0 auto;align-items:center;justify-content:center;overflow:hidden;background:#f0f0f1}.lm-home-cms__preview img{display:block;max-width:100%;max-height:110px;object-fit:contain}.lm-home-cms__preview span{padding:20px;color:#646970}@media(max-width:900px){.lm-home-cms__grid{grid-template-columns:1fr}}' );
}
add_action( 'admin_enqueue_scripts', 'luismacchine_home_cms_assets' );
