<?php
/** Consent integration: reuse parent markup and statistics, never start them implicitly. */
defined( 'ABSPATH' ) || exit;

function luismacchine_statistics_consent() {
	$raw = isset( $_COOKIE['tw_cookie_preferences'] ) ? wp_unslash( $_COOKIE['tw_cookie_preferences'] ) : '';
	$prefs = is_string( $raw ) ? json_decode( $raw, true ) : null;
	return ! empty( $_COOKIE['tw_cookie_consent'] ) && is_array( $prefs ) && isset( $prefs['analytics'] ) && true === $prefs['analytics'];
}

function luismacchine_guard_statistics() {
	if ( ! luismacchine_statistics_consent() ) {
		wp_send_json_success( array( 'counted' => false, 'reason' => 'consent_required' ) );
	}
}
add_action( 'wp_ajax_nopriv_ticinoweb_track_visit', 'luismacchine_guard_statistics', 0 );
add_action( 'wp_ajax_ticinoweb_track_visit', 'luismacchine_guard_statistics', 0 );

// Remove the parent's HttpOnly daily counter cookie on an uncached request after revocation.
add_action( 'init', function () {
	if ( luismacchine_statistics_consent() || headers_sent() ) {
		return;
	}
	foreach ( array_keys( $_COOKIE ) as $name ) {
		if ( preg_match( '/^ticinoweb_visit_[0-9]{8}$/D', $name ) ) {
			setcookie( $name, '', array( 'expires' => time() - DAY_IN_SECONDS, 'path' => COOKIEPATH, 'domain' => COOKIE_DOMAIN, 'secure' => is_ssl(), 'httponly' => true, 'samesite' => 'Lax' ) );
		}
	}
} );

function luismacchine_configure_consent() {
	remove_action( 'wp_footer', 'ticinoweb_print_visit_beacon', 99 );
	remove_action( 'wp_footer', 'tw_seo_cookie_banner_render', 100 );
	add_action( 'wp_footer', 'luismacchine_render_consent', 100 );
}
add_action( 'after_setup_theme', 'luismacchine_configure_consent', 100 );

function luismacchine_render_consent() {
	if ( ! get_option( 'tw_cookie_banner_enable' ) || ! function_exists( 'tw_seo_cookie_banner_render' ) ) {
		return; // No consent UI: optional statistics remain off.
	}
	ob_start();
	tw_seo_cookie_banner_render();
	$markup = ob_get_clean();
	// The parent removes its dialog after a choice. Retain its UI and replace only
	// the controller so preferences can reopen and revocation is effective.
	$markup = preg_replace( '#<script\b[^>]*>.*?</script>#si', '', $markup );
	// No advertising tools on this site: omit the parent's marketing category.
	// Keep the enclosing modal body/footer and the translated remaining categories.
	$markup = preg_replace( '#<!-- Category 3: Marketing -->.*?(?=\s*</div>\s*<div class="tw-cookie-modal-footer">)#s', '', $markup );
	echo $markup; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- trusted parent renderer escapes its values.
	if ( function_exists( 'ticinoweb_print_visit_beacon' ) ) {
		echo '<template id="lm-consented-statistics">';
		ticinoweb_print_visit_beacon();
		echo '</template>';
	}
}

add_action( 'wp_enqueue_scripts', function () {
	if ( get_option( 'tw_cookie_banner_enable' ) ) {
		wp_enqueue_script( 'lm-consent', get_stylesheet_directory_uri() . '/assets/js/consent.js', array(), wp_get_theme()->get( 'Version' ), true );
		wp_localize_script( 'lm-consent', 'lmConsentLabels', array( 'close' => __( 'Chiudi preferenze cookie', 'luismacchine-child-theme' ) ) );
	}
} );
