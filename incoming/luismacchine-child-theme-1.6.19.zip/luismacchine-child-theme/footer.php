<?php
$contact  = luismacchine_contact_info();
$facebook = get_option( 'ticinoweb_contact_facebook', '' );
$facebook = is_string( $facebook ) ? esc_url( $facebook, array( 'https', 'http' ) ) : '';
?>
<footer class="lm-footer">
	<div class="lm-container lm-footer__grid">
		<div class="lm-footer__brand">
			<img src="<?php echo esc_url( luismacchine_logo_url() ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" width="190" height="134" loading="lazy" translate="no">
			<p><?php esc_html_e( 'Officina, veicoli e ricambi a Cadenazzo.', 'luismacchine-child-theme' ); ?></p>
		</div>
		<div>
			<h2><?php esc_html_e( 'Esplora', 'luismacchine-child-theme' ); ?></h2>
			<ul>
				<li><a href="<?php echo esc_url( luismacchine_page_url( 'servizi' ) ); ?>"><?php esc_html_e( 'Servizi', 'luismacchine-child-theme' ); ?></a></li>
				<li><a href="<?php echo esc_url( get_post_type_archive_link( LUISMACCHINE_VEHICLE_POST_TYPE ) ); ?>"><?php esc_html_e( 'Vetrina auto', 'luismacchine-child-theme' ); ?></a></li>
				<li><a href="<?php echo esc_url( get_post_type_archive_link( LUISMACCHINE_PART_POST_TYPE ) ); ?>"><?php esc_html_e( 'Ricambi', 'luismacchine-child-theme' ); ?></a></li>
				<li><a href="<?php echo esc_url( luismacchine_page_url( 'chi-siamo' ) ); ?>"><?php esc_html_e( 'Chi siamo', 'luismacchine-child-theme' ); ?></a></li>
			</ul>
		</div>
		<div>
			<h2><?php esc_html_e( 'Contatti', 'luismacchine-child-theme' ); ?></h2>
			<?php if ( $contact['address'] ) : ?><p><?php echo esc_html( $contact['address'] ); ?></p><?php endif; ?>
			<?php if ( $contact['phone'] ) : ?><p><a href="tel:<?php echo esc_attr( luismacchine_phone_href( $contact['phone'] ) ); ?>"><?php echo esc_html( $contact['phone'] ); ?></a></p><?php endif; ?>
			<?php if ( $contact['email'] ) : ?><p><a href="mailto:<?php echo esc_attr( antispambot( $contact['email'] ) ); ?>"><?php echo esc_html( antispambot( $contact['email'] ) ); ?></a></p><?php endif; ?>
			<?php if ( $facebook ) : ?>
				<a class="lm-footer__social" href="<?php echo esc_url( $facebook ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php esc_attr_e( 'Seguici su Facebook (si apre in una nuova scheda)', 'luismacchine-child-theme' ); ?>">
					<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false"><path d="M24 12.073C24 5.405 18.627 0 12 0S0 5.405 0 12.073C0 18.1 4.388 23.094 10.125 24v-8.437H7.078v-3.49h3.047V9.413c0-3.025 1.792-4.697 4.533-4.697 1.313 0 2.686.236 2.686.236v2.971h-1.513c-1.491 0-1.956.931-1.956 1.887v2.263h3.328l-.532 3.49h-2.796V24C19.612 23.094 24 18.1 24 12.073Z"/></svg>
				</a>
			<?php endif; ?>
		</div>
	</div>
	<div class="lm-container lm-footer__bottom">
		<p>&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php echo esc_html( get_bloginfo( 'name' ) ); ?>. <?php esc_html_e( 'Tutti i diritti riservati.', 'luismacchine-child-theme' ); ?></p>
		<div class="lm-footer__legal">
			<?php if ( get_privacy_policy_url() ) : ?><a href="<?php echo esc_url( get_privacy_policy_url() ); ?>"><?php esc_html_e( 'Privacy', 'luismacchine-child-theme' ); ?></a><?php endif; ?>
			<?php if ( get_option( 'tw_cookie_banner_enable' ) ) : ?><button type="button" class="lm-cookie-preferences" data-lm-cookie-preferences><?php esc_html_e( 'Preferenze cookie', 'luismacchine-child-theme' ); ?></button><?php endif; ?>
		</div>
		<p class="lm-footer__credit"><?php esc_html_e( 'Design by', 'luismacchine-child-theme' ); ?> <a href="https://ticinoweb.com" target="_blank" rel="noopener noreferrer" translate="no">ticinoWEB</a></p>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
