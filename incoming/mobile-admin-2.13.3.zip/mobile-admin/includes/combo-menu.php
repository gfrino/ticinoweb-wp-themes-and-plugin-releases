<?php
/**
 * Menù combinati dell'app (v2.13.0)
 *
 * When the cart holds a poké and no drink/dessert, the app offers a menu
 * before checkout ("Crea Menù": poké + acqua / + dessert / + acqua e dessert,
 * each a fixed surcharge) and, if the customer skips it, a quick "Aggiungi una
 * bibita" page. Everything shown there is managed here:
 *
 *  - Admin page  Gestione App → Menù combinati (brand hub only, like Metodi di
 *                Pagamento). One configuration for every sede: products are
 *                chosen BY NAME, so each sede shows the ones it actually sells.
 *  - Storage     NETWORK option `ard_app_combo_menu`.
 *  - REST        GET mobile-admin/v1/combo-menu?site=<sede host>: the config
 *                with the products resolved in that sede (id, price, image),
 *                plus the category ids the app needs to recognise a poké and
 *                a drink/dessert already in the cart.
 */

defined( 'ABSPATH' ) || exit;

const ARD_COMBO_OPTION = 'ard_app_combo_menu';

/** The three menu offers, in the order the app shows them. */
function ARD_combo_offers_catalog() {
	return array(
		'water'         => array( 'label' => 'Pokè + Acqua', 'price' => 1.0, 'parts' => array( 'water' ) ),
		'dessert'       => array( 'label' => 'Pokè + Dessert', 'price' => 3.0, 'parts' => array( 'dessert' ) ),
		'water_dessert' => array( 'label' => 'Pokè + Acqua + Dessert', 'price' => 4.0, 'parts' => array( 'water', 'dessert' ) ),
	);
}

function ARD_combo_defaults() {
	$offers = array();
	foreach ( ARD_combo_offers_catalog() as $key => $offer ) {
		$offers[ $key ] = array( 'enabled' => true, 'price' => $offer['price'] );
	}
	return array(
		'enabled'        => false,
		'offers'         => $offers,
		'waters'         => array(),
		'desserts'       => array(),
		'drinks_enabled' => false,
		'drinks'         => array(),
	);
}

function ARD_combo_settings() {
	$saved    = (array) get_site_option( ARD_COMBO_OPTION, array() );
	$defaults = ARD_combo_defaults();
	$settings = array_merge( $defaults, array_intersect_key( $saved, $defaults ) );
	foreach ( $defaults['offers'] as $key => $offer ) {
		$settings['offers'][ $key ] = array_merge( $offer, (array) ( $settings['offers'][ $key ] ?? array() ) );
	}
	foreach ( array( 'waters', 'desserts', 'drinks' ) as $list ) {
		$settings[ $list ] = array_values( array_filter( array_map( 'strval', (array) $settings[ $list ] ) ) );
	}
	return $settings;
}

/** Product names are matched case- and accent-insensitively across sedi. */
function ARD_combo_name_key( $name ) {
	$name = wp_strip_all_tags( html_entity_decode( (string) $name, ENT_QUOTES, 'UTF-8' ) );
	return strtolower( remove_accents( trim( preg_replace( '/\s+/', ' ', $name ) ) ) );
}

/** blog_id for a sede host, 0 if unknown. */
function ARD_combo_blog_id( $host ) {
	if ( ! is_multisite() ) {
		return get_current_blog_id();
	}
	$site = get_site_by_path( ARD_payment_methods_normalize_host( $host ), '/' );
	return $site ? (int) $site->blog_id : 0;
}

/**
 * Published products of the current blog: [ name_key => data ].
 * Must run inside switch_to_blog() for a sede. Reads the tables directly: the
 * brand hub (where this runs) has no WooCommerce, so `product` and
 * `product_cat` are not registered there and the WP query API returns nothing.
 */
function ARD_combo_blog_products() {
	global $wpdb;
	$rows = $wpdb->get_results(
		"SELECT p.ID, p.post_title,
			MAX(CASE WHEN m.meta_key = '_price' THEN m.meta_value END) AS price,
			MAX(CASE WHEN m.meta_key = '_stock_status' THEN m.meta_value END) AS stock,
			MAX(CASE WHEN m.meta_key = '_thumbnail_id' THEN m.meta_value END) AS thumb
		FROM {$wpdb->posts} p
		LEFT JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key IN ('_price','_stock_status','_thumbnail_id')
		WHERE p.post_type = 'product' AND p.post_status = 'publish'
		GROUP BY p.ID
		ORDER BY p.menu_order, p.ID"
	);
	if ( ! $rows ) {
		return array();
	}

	$cats = array();
	foreach ( (array) $wpdb->get_results(
		"SELECT tr.object_id, t.term_id, t.name
		FROM {$wpdb->term_relationships} tr
		JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id AND tt.taxonomy = 'product_cat'
		JOIN {$wpdb->terms} t ON t.term_id = tt.term_id"
	) as $c ) {
		$cats[ (int) $c->object_id ][] = array( 'id' => (int) $c->term_id, 'name' => html_entity_decode( $c->name, ENT_QUOTES, 'UTF-8' ) );
	}

	$products = array();
	foreach ( $rows as $row ) {
		$key = ARD_combo_name_key( $row->post_title );
		if ( '' === $key || isset( $products[ $key ] ) ) {
			continue;
		}
		$thumb = (int) $row->thumb;
		$products[ $key ] = array(
			'id'         => (int) $row->ID,
			'name'       => html_entity_decode( $row->post_title, ENT_QUOTES, 'UTF-8' ),
			'price'      => ( null === $row->price || '' === $row->price ) ? null : (float) $row->price,
			'image'      => $thumb ? (string) wp_get_attachment_image_url( $thumb, 'thumbnail' ) : '',
			'in_stock'   => 'outofstock' !== $row->stock,
			'categories' => $cats[ (int) $row->ID ] ?? array(),
		);
	}
	return $products;
}

/** product_cat terms of the current blog whose name or slug mentions poké. */
function ARD_combo_blog_poke_categories() {
	global $wpdb;
	$ids = array();
	foreach ( (array) $wpdb->get_results(
		"SELECT t.term_id, t.name, t.slug FROM {$wpdb->terms} t
		JOIN {$wpdb->term_taxonomy} tt ON tt.term_id = t.term_id AND tt.taxonomy = 'product_cat'"
	) as $t ) {
		if ( false !== strpos( ARD_combo_name_key( $t->name . ' ' . $t->slug ), 'pok' ) ) {
			$ids[] = (int) $t->term_id;
		}
	}
	return $ids;
}

/**
 * Catalog for the admin pickers: every product name sold in at least one sede,
 * with the sedi that sell it. Cached for 30 minutes, flushed on save.
 */
function ARD_combo_catalog() {
	$cached = get_site_transient( 'ard_combo_catalog' );
	if ( is_array( $cached ) ) {
		return $cached;
	}
	$catalog = array();
	foreach ( ARD_payment_methods_sites() as $host => $label ) {
		$blog_id = ARD_combo_blog_id( $host );
		if ( ! $blog_id ) {
			continue;
		}
		switch_to_blog( $blog_id );
		foreach ( ARD_combo_blog_products() as $key => $product ) {
			if ( ! isset( $catalog[ $key ] ) ) {
				$catalog[ $key ] = array(
					'name'     => $product['name'],
					'image'    => $product['image'],
					'price'    => $product['price'],
					'category' => $product['categories'][0]['name'] ?? '',
					'sedi'     => array(),
				);
			}
			$catalog[ $key ]['sedi'][] = $label;
		}
		restore_current_blog();
	}
	uasort( $catalog, static function ( $a, $b ) {
		return strcasecmp( $a['category'] . ' ' . $a['name'], $b['category'] . ' ' . $b['name'] );
	} );
	set_site_transient( 'ard_combo_catalog', $catalog, 30 * MINUTE_IN_SECONDS );
	return $catalog;
}

function ARD_combo_flush_cache() {
	delete_site_transient( 'ard_combo_catalog' );
	foreach ( array_keys( ARD_payment_methods_sites() ) as $host ) {
		delete_site_transient( 'ard_combo_' . md5( $host ) );
	}
	do_action( 'litespeed_purge_all' );
}

/* ------------------------------------------------------------------ admin */

add_action( 'admin_menu', 'ARD_combo_menu', 21 );
function ARD_combo_menu() {
	if ( ! ARD_payment_methods_is_hub() ) {
		return;
	}
	add_submenu_page( 'ard_stato_app', 'Menù combinati', 'Menù combinati', 'manage_options', 'ard_combo_menu', 'ARD_combo_render_page' );
}

function ARD_combo_handle_save() {
	if ( ! isset( $_POST['ard_combo_nonce'] )
		|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ard_combo_nonce'] ) ), 'ard_save_combo_menu' ) ) {
		return null;
	}
	$posted   = wp_unslash( $_POST );
	$catalog  = ARD_combo_catalog();
	$settings = ARD_combo_defaults();

	$settings['enabled']        = ! empty( $posted['ard_combo_enabled'] );
	$settings['drinks_enabled'] = ! empty( $posted['ard_combo_drinks_enabled'] );
	foreach ( ARD_combo_offers_catalog() as $key => $offer ) {
		$price = isset( $posted['ard_combo_offer'][ $key ]['price'] ) ? str_replace( ',', '.', (string) $posted['ard_combo_offer'][ $key ]['price'] ) : $offer['price'];
		$settings['offers'][ $key ] = array(
			'enabled' => ! empty( $posted['ard_combo_offer'][ $key ]['enabled'] ),
			'price'   => max( 0, round( (float) $price, 2 ) ),
		);
	}
	// Only names that exist in the catalog are kept (no free text).
	foreach ( array( 'waters', 'desserts', 'drinks' ) as $list ) {
		$names = isset( $posted[ 'ard_combo_' . $list ] ) ? (array) $posted[ 'ard_combo_' . $list ] : array();
		$keep  = array();
		foreach ( $names as $key ) {
			$key = sanitize_text_field( (string) $key );
			if ( isset( $catalog[ $key ] ) ) {
				$keep[] = $key;
			}
		}
		$settings[ $list ] = array_values( array_unique( $keep ) );
	}

	$problems = array();
	if ( $settings['enabled'] ) {
		if ( ! array_filter( wp_list_pluck( $settings['offers'], 'enabled' ) ) ) {
			$problems[] = 'accendi almeno un\'offerta del menù';
		}
		$needs_water   = $settings['offers']['water']['enabled'] || $settings['offers']['water_dessert']['enabled'];
		$needs_dessert = $settings['offers']['dessert']['enabled'] || $settings['offers']['water_dessert']['enabled'];
		if ( $needs_water && ! $settings['waters'] ) {
			$problems[] = 'scegli almeno un\'acqua';
		}
		if ( $needs_dessert && ! $settings['desserts'] ) {
			$problems[] = 'scegli almeno un dessert';
		}
	}
	if ( $settings['drinks_enabled'] && ! $settings['drinks'] ) {
		$problems[] = 'scegli almeno una bibita da proporre';
	}

	update_site_option( ARD_COMBO_OPTION, $settings );
	ARD_combo_flush_cache();
	return $problems;
}

function ARD_combo_render_page() {
	if ( ! ARD_payment_methods_is_hub() || ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Pagina disponibile solo sul sito principale del brand.' );
	}
	if ( isset( $_GET['ard_combo_refresh'] ) && check_admin_referer( 'ard_combo_refresh' ) ) {
		delete_site_transient( 'ard_combo_catalog' );
	}
	$problems = ARD_combo_handle_save();
	$settings = ARD_combo_settings();
	$catalog  = ARD_combo_catalog();
	$offers   = ARD_combo_offers_catalog();
	$n_sites  = count( ARD_payment_methods_sites() );

	// Compact catalog for the pickers: only what the UI needs.
	$js_catalog = array();
	foreach ( $catalog as $key => $p ) {
		$js_catalog[ $key ] = array(
			'n' => $p['name'],
			'i' => $p['image'],
			'p' => $p['price'],
			'c' => $p['category'],
			's' => count( $p['sedi'] ) === $n_sites ? '' : implode( ', ', $p['sedi'] ),
		);
	}

	if ( is_array( $problems ) ) {
		if ( $problems ) {
			echo '<div class="notice notice-warning"><p>Salvato, ma l\'app non mostrerà la pagina finché non ' . esc_html( implode( ', ', $problems ) ) . '.</p></div>';
		} else {
			echo '<div class="notice notice-success"><p>Menù combinati salvati. L\'app li usa dal prossimo carrello.</p></div>';
		}
	}
	$refresh_url = wp_nonce_url( add_query_arg( 'ard_combo_refresh', 1 ), 'ard_combo_refresh' );
	$icons       = array( 'water' => '💧', 'dessert' => '🍡' );
	?>
	<style>
		.ard-cm { max-width: 1180px; margin-top: 10px; }
		.ard-cm * { box-sizing: border-box; }
		.ard-cm-top { display: flex; align-items: flex-end; justify-content: space-between; gap: 16px; margin-bottom: 16px; }
		.ard-cm-top h1 { margin: 0 0 4px; }
		.ard-cm-top p { margin: 0; color: #50575e; max-width: 640px; }
		.ard-cm-grid { display: grid; grid-template-columns: minmax(0, 1fr) 320px; gap: 24px; align-items: start; }
		.ard-cm-main { min-width: 0; display: flex; flex-direction: column; gap: 16px; }
		.ard-cm-card { background: #fff; border: 1px solid #dcdcde; border-radius: 14px; padding: 20px 22px; }
		.ard-cm-card.is-off .ard-cm-body { opacity: .45; pointer-events: none; }
		.ard-cm-head { display: flex; align-items: center; justify-content: space-between; gap: 12px; }
		.ard-cm-head h2 { margin: 0; font-size: 17px; }
		.ard-cm-head p { margin: 4px 0 0; color: #646970; font-size: 13px; }
		.ard-cm-body { margin-top: 18px; display: flex; flex-direction: column; gap: 22px; }
		.ard-cm-sw { position: relative; display: inline-flex; align-items: center; gap: 8px; cursor: pointer; font-weight: 600; font-size: 13px; color: #1d2327; white-space: nowrap; }
		.ard-cm-sw input { position: absolute; opacity: 0; width: 0; height: 0; }
		.ard-cm-sw .knob { width: 38px; height: 22px; border-radius: 999px; background: #c3c4c7; position: relative; transition: background .15s; flex: none; }
		.ard-cm-sw .knob::after { content: ""; position: absolute; top: 3px; left: 3px; width: 16px; height: 16px; border-radius: 50%; background: #fff; box-shadow: 0 1px 2px rgba(0,0,0,.25); transition: left .15s; }
		.ard-cm-sw input:checked + .knob { background: #1ca5a8; }
		.ard-cm-sw input:checked + .knob::after { left: 19px; }
		.ard-cm-sw input:focus-visible + .knob { outline: 2px solid #1ca5a8; outline-offset: 2px; }
		.ard-cm-offers { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 12px; }
		.ard-cm-offer { border: 1.5px solid #dcdcde; border-radius: 12px; padding: 14px; display: flex; flex-direction: column; gap: 12px; transition: border-color .15s, background .15s; }
		.ard-cm-offer.is-on { border-color: #1ca5a8; background: #f4fbfb; }
		.ard-cm-offer:not(.is-on) .ard-cm-offer-name, .ard-cm-offer:not(.is-on) .ard-cm-price { opacity: .5; }
		.ard-cm-offer-top { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
		.ard-cm-offer-name { font-size: 14px; font-weight: 700; line-height: 1.3; }
		.ard-cm-offer-name .em { display: block; font-size: 18px; margin-bottom: 4px; }
		.ard-cm-price { margin: 0; display: flex; flex-wrap: nowrap; align-items: center; border: 1px solid #8c8f94; border-radius: 8px; overflow: hidden; background: #fff; }
		.ard-cm-price span { display: flex; align-items: center; flex: none; white-space: nowrap; height: 36px; padding: 0 10px; color: #50575e; font-size: 13px; background: #f6f7f7; border-right: 1px solid #dcdcde; }
		.ard-cm-price input { border: 0 !important; box-shadow: none !important; width: 100%; min-width: 0; text-align: right; font-size: 16px; font-weight: 700; padding: 0 10px; height: 36px; }
		.ard-cm-pickers { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 18px; }
		.ard-cm-pickers.one { grid-template-columns: minmax(0, 1fr); }
		.ard-cm-picker { min-width: 0; }
		.ard-cm-picker h3 { margin: 0 0 8px; font-size: 14px; }
		.ard-cm-picker h3 small { font-weight: 400; color: #646970; }
		.ard-cm-chips { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 8px; }
		.ard-cm-chip { display: inline-flex; align-items: center; gap: 6px; max-width: 100%; background: #e7f6f6; border: 1px solid #a6dcdd; border-radius: 999px; padding: 3px 4px 3px 4px; font-size: 12px; font-weight: 600; color: #1d2327; }
		.ard-cm-chip img, .ard-cm-chip .ph { width: 22px; height: 22px; border-radius: 50%; object-fit: cover; background: #dcdcde; flex: none; }
		.ard-cm-chip .t { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
		.ard-cm-chip button { border: 0; background: transparent; cursor: pointer; color: #50575e; width: 20px; height: 20px; border-radius: 50%; font-size: 14px; line-height: 1; flex: none; }
		.ard-cm-chip button:hover { background: #c5e9ea; }
		.ard-cm-empty { color: #8c8f94; font-size: 12px; padding: 4px 0; }
		.ard-cm-add { position: relative; }
		.ard-cm-add input[type=search] { width: 100%; height: 38px; border-radius: 8px; padding-left: 34px; }
		.ard-cm-add .dashicons { position: absolute; left: 9px; top: 9px; color: #8c8f94; }
		.ard-cm-drop { display: none; position: absolute; z-index: 20; left: 0; right: 0; top: 42px; background: #fff; border: 1px solid #dcdcde; border-radius: 10px; box-shadow: 0 8px 24px rgba(0,0,0,.12); max-height: 280px; overflow: auto; }
		.ard-cm-add.is-open .ard-cm-drop { display: block; }
		.ard-cm-opt { display: flex; align-items: center; gap: 10px; padding: 7px 10px; cursor: pointer; }
		.ard-cm-opt:hover, .ard-cm-opt.is-active { background: #f0f6fc; }
		.ard-cm-opt img, .ard-cm-opt .ph { width: 32px; height: 32px; border-radius: 6px; object-fit: cover; background: #f0f0f1; flex: none; }
		.ard-cm-opt .t { flex: 1; min-width: 0; }
		.ard-cm-opt .t b { display: block; font-size: 13px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
		.ard-cm-opt .t span { display: block; font-size: 11px; color: #646970; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
		.ard-cm-opt .pr { font-size: 12px; color: #1d2327; font-weight: 600; white-space: nowrap; }
		.ard-cm-opt .badge { font-size: 10px; background: #fcf0e3; color: #8a4b00; border-radius: 4px; padding: 1px 5px; margin-left: 4px; }
		.ard-cm-group { font-size: 11px; text-transform: uppercase; letter-spacing: .04em; color: #8c8f94; padding: 8px 10px 4px; }
		.ard-cm-none { padding: 12px; color: #8c8f94; font-size: 12px; }
		.ard-cm-aside { position: sticky; top: 46px; }
		.ard-cm-phone { background: #1d2327; border-radius: 34px; padding: 10px; box-shadow: 0 10px 30px rgba(0,0,0,.18); }
		.ard-cm-screen { background: #f7f7f7; border-radius: 26px; padding: 16px 14px; min-height: 440px; }
		.ard-cm-tabs { display: flex; background: #e9ecef; border-radius: 999px; padding: 3px; margin-bottom: 14px; }
		.ard-cm-tabs button { flex: 1; border: 0; background: transparent; border-radius: 999px; padding: 6px; font-size: 12px; font-weight: 600; color: #50575e; cursor: pointer; }
		.ard-cm-tabs button.is-on { background: #fff; color: #1ca5a8; box-shadow: 0 1px 2px rgba(0,0,0,.1); }
		.ard-cm-screen h4 { margin: 0; color: #1ca5a8; font-size: 18px; font-weight: 800; }
		.ard-cm-screen .sub { color: #646970; font-size: 12px; margin: 2px 0 12px; }
		.ard-cm-prow { background: #fff; border-radius: 12px; padding: 11px 12px; margin-bottom: 8px; display: flex; align-items: center; gap: 10px; box-shadow: 0 1px 3px rgba(0,0,0,.06); font-size: 13px; font-weight: 600; }
		.ard-cm-prow .em { font-size: 15px; white-space: nowrap; }
		.ard-cm-prow .nm { flex: 1; min-width: 0; }
		.ard-cm-prow .pc { background: #e7f6f6; color: #1ca5a8; border-radius: 999px; padding: 3px 8px; font-weight: 800; font-size: 12px; white-space: nowrap; }
		.ard-cm-prow img, .ard-cm-prow .ph { width: 34px; height: 34px; border-radius: 8px; object-fit: cover; background: #e9ecef; }
		.ard-cm-prow .plus { width: 26px; height: 26px; border-radius: 50%; background: #1ca5a8; color: #fff; display: inline-flex; align-items: center; justify-content: center; font-weight: 700; }
		.ard-cm-pbtn { margin-top: 12px; border: 1.5px solid #c3c4c7; border-radius: 999px; text-align: center; padding: 9px; font-weight: 700; font-size: 13px; color: #3c434a; background: #fff; }
		.ard-cm-pnote { color: #8c8f94; font-size: 12px; text-align: center; padding: 30px 10px; }
		.ard-cm-asidenote { color: #646970; font-size: 12px; text-align: center; margin-top: 10px; }
		.ard-cm-bar { position: sticky; bottom: 0; z-index: 30; display: flex; align-items: center; gap: 14px; background: rgba(255,255,255,.96); border: 1px solid #dcdcde; border-radius: 14px; padding: 12px 18px; box-shadow: 0 -4px 16px rgba(0,0,0,.06); }
		.ard-cm-bar .button-primary { background: #1ca5a8; border-color: #1ca5a8; padding: 4px 24px; font-size: 14px; }
		.ard-cm-bar .button-primary:hover { background: #178a8d; border-color: #178a8d; }
		.ard-cm-dirty { color: #996800; font-size: 13px; font-weight: 600; visibility: hidden; }
		.ard-cm-dirty.is-on { visibility: visible; }
		@media (max-width: 1100px) { .ard-cm-grid { grid-template-columns: minmax(0, 1fr); } .ard-cm-aside { position: static; max-width: 340px; } }
		@media (max-width: 782px) { .ard-cm-offers, .ard-cm-pickers { grid-template-columns: minmax(0, 1fr); } .ard-cm-top { flex-direction: column; align-items: flex-start; } }
	</style>

	<div class="wrap ard-cm">
		<div class="ard-cm-top">
			<div>
				<h1>Menù combinati</h1>
				<p>Quando nel carrello dell'app c'è una poké senza bibite né dessert, prima del pagamento l'app propone il menù; se il cliente lo salta, propone una bibita. Valgono per tutte le sedi: ognuna mostra solo i prodotti che vende.</p>
			</div>
			<a class="button" href="<?php echo esc_url( $refresh_url ); ?>"><span class="dashicons dashicons-update" style="margin-top:4px"></span> Aggiorna elenco prodotti</a>
		</div>

		<form method="post" id="ard-cm-form">
			<?php wp_nonce_field( 'ard_save_combo_menu', 'ard_combo_nonce' ); ?>
			<div class="ard-cm-grid">
				<div class="ard-cm-main">

					<section class="ard-cm-card<?php echo $settings['enabled'] ? '' : ' is-off'; ?>" data-card="combo">
						<div class="ard-cm-head">
							<div>
								<h2>Pagina «Crea il tuo Menù»</h2>
								<p>Il prezzo è quanto si aggiunge alla poké.</p>
							</div>
							<label class="ard-cm-sw"><input type="checkbox" name="ard_combo_enabled" value="1" data-card-toggle="combo" <?php checked( $settings['enabled'] ); ?>><span class="knob"></span><span class="lbl"><?php echo $settings['enabled'] ? 'Attiva' : 'Spenta'; ?></span></label>
						</div>
						<div class="ard-cm-body">
							<div class="ard-cm-offers">
								<?php foreach ( $offers as $key => $offer ) :
									$o  = $settings['offers'][ $key ];
									$em = '🥗' . implode( '', array_map( static function ( $part ) use ( $icons ) { return $icons[ $part ]; }, $offer['parts'] ) ); ?>
									<div class="ard-cm-offer<?php echo $o['enabled'] ? ' is-on' : ''; ?>" data-offer="<?php echo esc_attr( $key ); ?>">
										<div class="ard-cm-offer-top">
											<span class="ard-cm-offer-name"><span class="em"><?php echo esc_html( $em ); ?></span><?php echo esc_html( $offer['label'] ); ?></span>
											<label class="ard-cm-sw" title="Mostra questa offerta"><input type="checkbox" name="ard_combo_offer[<?php echo esc_attr( $key ); ?>][enabled]" value="1" <?php checked( $o['enabled'] ); ?>><span class="knob"></span></label>
										</div>
										<label class="ard-cm-price"><span>+ CHF</span><input type="number" min="0" step="0.05" inputmode="decimal" name="ard_combo_offer[<?php echo esc_attr( $key ); ?>][price]" value="<?php echo esc_attr( number_format( (float) $o['price'], 2, '.', '' ) ); ?>" aria-label="Supplemento <?php echo esc_attr( $offer['label'] ); ?>"></label>
									</div>
								<?php endforeach; ?>
							</div>
							<div class="ard-cm-pickers">
								<?php ARD_combo_render_picker( 'waters', 'Acque', 'il cliente sceglie quale', $settings['waters'], 'bibit|bevand|acqua|drink' ); ?>
								<?php ARD_combo_render_picker( 'desserts', 'Dessert', 'il cliente sceglie quale', $settings['desserts'], 'dessert|dolc|mochi' ); ?>
							</div>
						</div>
					</section>

					<section class="ard-cm-card<?php echo $settings['drinks_enabled'] ? '' : ' is-off'; ?>" data-card="drinks">
						<div class="ard-cm-head">
							<div>
								<h2>Pagina «Aggiungi una bibita»</h2>
								<p>Solo se il cliente salta il menù. Le bibite costano il loro prezzo normale.</p>
							</div>
							<label class="ard-cm-sw"><input type="checkbox" name="ard_combo_drinks_enabled" value="1" data-card-toggle="drinks" <?php checked( $settings['drinks_enabled'] ); ?>><span class="knob"></span><span class="lbl"><?php echo $settings['drinks_enabled'] ? 'Attiva' : 'Spenta'; ?></span></label>
						</div>
						<div class="ard-cm-body">
							<div class="ard-cm-pickers one">
								<?php ARD_combo_render_picker( 'drinks', 'Bibite proposte', 'nell\'ordine in cui le aggiungi', $settings['drinks'], 'bibit|bevand|acqua|drink' ); ?>
							</div>
						</div>
					</section>

					<div class="ard-cm-bar">
						<?php submit_button( 'Salva', 'primary', 'submit', false ); ?>
						<span class="ard-cm-dirty" id="ard-cm-dirty">● Modifiche non salvate</span>
					</div>
				</div>

				<aside class="ard-cm-aside" aria-label="Anteprima nell'app">
					<div class="ard-cm-phone">
						<div class="ard-cm-screen">
							<div class="ard-cm-tabs" role="tablist">
								<button type="button" class="is-on" data-tab="combo">Crea Menù</button>
								<button type="button" data-tab="drinks">Bibita</button>
							</div>
							<div id="ard-cm-pv"></div>
						</div>
					</div>
					<p class="ard-cm-asidenote">Anteprima di come appare nell'app</p>
				</aside>
			</div>
		</form>
	</div>

	<script>
	(function () {
		var form = document.getElementById('ard-cm-form');
		var catalog = <?php echo wp_json_encode( $js_catalog ); ?>;
		var labels = <?php echo wp_json_encode( wp_list_pluck( $offers, 'label' ) ); ?>;
		var tab = 'combo';
		function esc(s) { var d = document.createElement('div'); d.textContent = s == null ? '' : String(s); return d.innerHTML; }
		function money(v) { return 'CHF ' + Number(v || 0).toFixed(2); }
		function norm(s) { return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, ''); }
		function img(p, cls) { return p && p.i ? '<img src="' + esc(p.i) + '" alt="" loading="lazy">' : '<span class="ph"></span>'; }
		function chosen(list) { return Array.prototype.map.call(form.querySelectorAll('input[name="ard_combo_' + list + '[]"]'), function (i) { return i.value; }); }
		function dirty() { document.getElementById('ard-cm-dirty').classList.add('is-on'); }

		function renderChips(picker) {
			var list = picker.dataset.list, keys = chosen(list), box = picker.querySelector('.ard-cm-chips');
			box.innerHTML = keys.length ? '' : '<span class="ard-cm-empty">Nessun prodotto: cercalo qui sotto e aggiungilo</span>';
			keys.forEach(function (k) {
				var p = catalog[k] || { n: k };
				box.insertAdjacentHTML('beforeend', '<span class="ard-cm-chip">' + img(p) + '<span class="t">' + esc(p.n) + '</span><button type="button" data-remove="' + esc(k) + '" aria-label="Togli ' + esc(p.n) + '">×</button></span>');
			});
		}
		function renderDrop(picker) {
			var q = norm(picker.querySelector('input[type=search]').value).trim(), keys = chosen(picker.dataset.list);
			var re = new RegExp(picker.dataset.prefer, 'i'), pref = [], rest = [];
			Object.keys(catalog).forEach(function (k) {
				if (keys.indexOf(k) !== -1) return;
				var p = catalog[k], hay = norm(p.n + ' ' + p.c);
				if (q && hay.indexOf(q) === -1) return;
				(re.test(p.c) || re.test(p.n) ? pref : rest).push(k);
			});
			function opt(k) {
				var p = catalog[k];
				return '<div class="ard-cm-opt" role="option" data-key="' + esc(k) + '">' + img(p) + '<span class="t"><b>' + esc(p.n) + (p.s ? '<span class="badge">solo ' + esc(p.s) + '</span>' : '') + '</b><span>' + esc(p.c) + '</span></span><span class="pr">' + (p.p != null ? money(p.p) : '') + '</span></div>';
			}
			var html = '';
			if (pref.length) html += '<div class="ard-cm-group">Suggeriti</div>' + pref.slice(0, 40).map(opt).join('');
			if (q && rest.length) html += '<div class="ard-cm-group">Altri prodotti</div>' + rest.slice(0, 40).map(opt).join('');
			if (!q && !pref.length) html += rest.slice(0, 40).map(opt).join('');
			picker.querySelector('.ard-cm-drop').innerHTML = html || '<div class="ard-cm-none">Nessun prodotto trovato</div>';
		}
		function toggle(picker, key) {
			var list = picker.dataset.list, existing = form.querySelector('input[name="ard_combo_' + list + '[]"][value="' + CSS.escape(key) + '"]');
			if (existing) { existing.remove(); } else { picker.querySelector('.ard-cm-hidden').insertAdjacentHTML('beforeend', '<input type="hidden" name="ard_combo_' + list + '[]" value="' + esc(key) + '">'); }
			renderChips(picker); renderDrop(picker); preview(); dirty();
		}

		function preview() {
			var box = document.getElementById('ard-cm-pv'), html = '';
			form.querySelectorAll('.ard-cm-tabs button').forEach(function () {});
			document.querySelectorAll('.ard-cm-tabs button').forEach(function (b) { b.classList.toggle('is-on', b.dataset.tab === tab); });
			if (tab === 'combo') {
				var on = form.querySelector('[data-card-toggle=combo]').checked;
				html += '<h4>Crea il tuo Menù</h4><div class="sub">Completa la tua poké a un prezzo speciale</div>';
				var rows = '';
				form.querySelectorAll('.ard-cm-offer').forEach(function (row) {
					if (!row.querySelector('input[type=checkbox]').checked) return;
					rows += '<div class="ard-cm-prow"><span class="em">' + esc(row.querySelector('.em').textContent) + '</span><span class="nm">' + esc(labels[row.dataset.offer]) + '</span><span class="pc">+ ' + money(row.querySelector('input[type=number]').value) + '</span></div>';
				});
				html += on ? (rows || '<div class="ard-cm-pnote">Nessuna offerta accesa</div>') : '<div class="ard-cm-pnote">Pagina spenta: l\'app va diretta al pagamento</div>';
				html += '<div class="ard-cm-pbtn">Salta</div>';
			} else {
				var don = form.querySelector('[data-card-toggle=drinks]').checked, drinks = chosen('drinks');
				html += '<h4>Aggiungi una bibita?</h4><div class="sub">Un tocco ed è nel tuo ordine</div>';
				if (!don) html += '<div class="ard-cm-pnote">Pagina spenta</div>';
				else if (!drinks.length) html += '<div class="ard-cm-pnote">Nessuna bibita scelta</div>';
				else drinks.slice(0, 5).forEach(function (k) { var p = catalog[k] || { n: k }; html += '<div class="ard-cm-prow">' + img(p) + '<span class="nm">' + esc(p.n) + '<br><span style="color:#1ca5a8;font-size:12px">' + (p.p != null ? money(p.p) : '') + '</span></span><span class="plus">+</span></div>'; });
				html += '<div class="ard-cm-pbtn">No grazie</div>';
			}
			box.innerHTML = html;
		}
		function cards() {
			form.querySelectorAll('[data-card-toggle]').forEach(function (sw) {
				form.querySelector('[data-card="' + sw.dataset.cardToggle + '"]').classList.toggle('is-off', !sw.checked);
				sw.parentNode.querySelector('.lbl').textContent = sw.checked ? 'Attiva' : 'Spenta';
			});
			form.querySelectorAll('.ard-cm-offer').forEach(function (row) { row.classList.toggle('is-on', row.querySelector('input[type=checkbox]').checked); });
		}

		form.querySelectorAll('.ard-cm-picker').forEach(function (picker) {
			var add = picker.querySelector('.ard-cm-add'), search = add.querySelector('input[type=search]');
			renderChips(picker);
			picker.addEventListener('click', function (e) {
				var rm = e.target.closest('[data-remove]'); if (rm) { toggle(picker, rm.dataset.remove); return; }
				var opt = e.target.closest('.ard-cm-opt'); if (opt) { toggle(picker, opt.dataset.key); search.focus(); }
			});
			search.addEventListener('focus', function () { renderDrop(picker); add.classList.add('is-open'); });
			search.addEventListener('input', function () { renderDrop(picker); add.classList.add('is-open'); });
			search.addEventListener('keydown', function (e) {
				if (e.key === 'Escape') { add.classList.remove('is-open'); search.blur(); }
				if (e.key === 'Enter') { e.preventDefault(); var first = add.querySelector('.ard-cm-opt'); if (first) toggle(picker, first.dataset.key); }
			});
			document.addEventListener('click', function (e) { if (!add.contains(e.target)) add.classList.remove('is-open'); });
			// Picking a product must not mark "Attiva"/prices as touched twice.
			search.addEventListener('change', function (e) { e.stopPropagation(); });
			search.addEventListener('input', function (e) { e.stopPropagation(); });
		});
		document.querySelectorAll('.ard-cm-tabs button').forEach(function (b) { b.addEventListener('click', function () { tab = b.dataset.tab; preview(); }); });
		form.querySelector('[data-card="drinks"]').addEventListener('focusin', function () { if (tab !== 'drinks') { tab = 'drinks'; preview(); } });
		form.querySelector('[data-card="combo"]').addEventListener('focusin', function () { if (tab !== 'combo') { tab = 'combo'; preview(); } });
		form.addEventListener('input', function () { cards(); preview(); dirty(); });
		form.addEventListener('change', function () { cards(); preview(); dirty(); });
		window.addEventListener('beforeunload', function (e) { if (document.getElementById('ard-cm-dirty').classList.contains('is-on')) { e.preventDefault(); e.returnValue = ''; } });
		form.addEventListener('submit', function () { document.getElementById('ard-cm-dirty').classList.remove('is-on'); });
		cards(); preview();
	})();
	</script>
	<?php
}

function ARD_combo_render_picker( $list, $title, $hint, array $selected, $prefer ) {
	?>
	<div class="ard-cm-picker" data-list="<?php echo esc_attr( $list ); ?>" data-prefer="<?php echo esc_attr( $prefer ); ?>">
		<h3><?php echo esc_html( $title ); ?> <small>· <?php echo esc_html( $hint ); ?></small></h3>
		<div class="ard-cm-chips"></div>
		<div class="ard-cm-hidden">
			<?php foreach ( $selected as $key ) : ?>
				<input type="hidden" name="ard_combo_<?php echo esc_attr( $list ); ?>[]" value="<?php echo esc_attr( $key ); ?>">
			<?php endforeach; ?>
		</div>
		<div class="ard-cm-add">
			<span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span>
			<input type="search" placeholder="Aggiungi un prodotto…" autocomplete="off" aria-label="Aggiungi un prodotto a <?php echo esc_attr( $title ); ?>">
			<div class="ard-cm-drop" role="listbox"></div>
		</div>
	</div>
	<?php
}

/* ------------------------------------------------------------------- REST */

add_action( 'rest_api_init', function () {
	register_rest_route( 'mobile-admin/v1', '/combo-menu', array(
		'methods'             => 'GET',
		'callback'            => 'ARD_rest_get_combo_menu',
		'permission_callback' => '__return_true',
		'args'                => array(
			'site' => array( 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ),
		),
	) );
} );

/**
 * GET /wp-json/mobile-admin/v1/combo-menu?site=biasca.littleinka.ch
 *   → { enabled, offers: [ { key, label, price, parts: [water|dessert] } ],
 *       waters: [product], desserts: [product], drinks_enabled, drinks: [product],
 *       poke_category_ids: [int], skip_category_ids: [int], skip_product_ids: [int] }
 * product = { id, name, price, image }. Only products this sede sells and has
 * in stock. "enabled" is false when the sede could not show a usable page.
 */
function ARD_rest_get_combo_menu( WP_REST_Request $request ) {
	$host = ARD_payment_methods_normalize_host( $request->get_param( 'site' ) );
	if ( ! array_key_exists( $host, ARD_payment_methods_sites() ) ) {
		return new WP_Error( 'ard_unknown_site', 'Sede sconosciuta', array( 'status' => 404 ) );
	}

	$cache_key = 'ard_combo_' . md5( $host );
	$data      = get_site_transient( $cache_key );
	if ( ! is_array( $data ) ) {
		$data = ARD_combo_build_for_host( $host );
		set_site_transient( $cache_key, $data, 5 * MINUTE_IN_SECONDS );
	}

	$response = rest_ensure_response( $data );
	$response->header( 'Cache-Control', 'no-cache, no-store, must-revalidate' );
	$response->header( 'X-LiteSpeed-Cache-Control', 'no-cache' );
	return $response;
}

function ARD_combo_build_for_host( $host ) {
	$settings = ARD_combo_settings();
	$empty    = array(
		'enabled'           => false,
		'offers'            => array(),
		'waters'            => array(),
		'desserts'          => array(),
		'drinks_enabled'    => false,
		'drinks'            => array(),
		'poke_category_ids' => array(),
		'skip_category_ids' => array(),
		'skip_product_ids'  => array(),
	);
	$blog_id = ARD_combo_blog_id( $host );
	if ( ! $blog_id ) {
		return $empty;
	}

	switch_to_blog( $blog_id );
	$products = ARD_combo_blog_products();
	$poke_ids = ARD_combo_blog_poke_categories();
	restore_current_blog();

	$skip_categories = array();
	$skip_products   = array();
	$resolve         = static function ( array $keys ) use ( $products, &$skip_categories, &$skip_products ) {
		$out = array();
		foreach ( $keys as $key ) {
			if ( ! isset( $products[ $key ] ) ) {
				continue;
			}
			$p = $products[ $key ];
			// A drink/dessert already in the cart (even out of stock now) means no offer.
			$skip_products[] = $p['id'];
			foreach ( $p['categories'] as $cat ) {
				$skip_categories[] = $cat['id'];
			}
			if ( ! $p['in_stock'] || null === $p['price'] ) {
				continue;
			}
			$out[] = array( 'id' => $p['id'], 'name' => $p['name'], 'price' => $p['price'], 'image' => $p['image'] );
		}
		return $out;
	};

	$data             = $empty;
	$data['waters']   = $resolve( $settings['waters'] );
	$data['desserts'] = $resolve( $settings['desserts'] );
	$data['drinks']   = $resolve( $settings['drinks'] );

	foreach ( ARD_combo_offers_catalog() as $key => $offer ) {
		$o = $settings['offers'][ $key ];
		if ( ! $o['enabled'] ) {
			continue;
		}
		// An offer is shown only if this sede has something for every part.
		foreach ( $offer['parts'] as $part ) {
			if ( empty( $data[ $part . 's' ] ) ) {
				continue 2;
			}
		}
		$data['offers'][] = array( 'key' => $key, 'label' => $offer['label'], 'price' => (float) $o['price'], 'parts' => $offer['parts'] );
	}

	$data['enabled']           = $settings['enabled'] && ! empty( $data['offers'] );
	$data['drinks_enabled']    = $settings['drinks_enabled'] && ! empty( $data['drinks'] );
	$data['poke_category_ids'] = array_values( array_unique( $poke_ids ) );
	// Poké categories never count as "drink/dessert" even if a chosen product sits in one.
	$data['skip_category_ids'] = array_values( array_diff( array_unique( $skip_categories ), $data['poke_category_ids'] ) );
	$data['skip_product_ids']  = array_values( array_unique( $skip_products ) );
	return $data;
}
