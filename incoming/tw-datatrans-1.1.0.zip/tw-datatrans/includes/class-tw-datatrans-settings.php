<?php
/**
 * Shared Datatrans settings (one place for the whole account): merchant
 * credentials for production and sandbox, webhook signing key, settlement,
 * logging. The four payment methods are WooCommerce gateways that only hold
 * their own title/description/enabled flag and link back here.
 */

defined( 'ABSPATH' ) || exit;

class TW_Datatrans_Settings {

	const OPTION = 'tw_datatrans_settings';
	const PAGE   = 'tw-datatrans';

	public static function defaults() {
		return array(
			'merchant_id'         => '',
			'password'            => '',
			'sandbox'             => 'no',
			'sandbox_merchant_id' => '',
			'sandbox_password'    => '',
			'sign_key'            => '',
			'autosettle'          => 'yes',
			'log'                 => 'no',
			'webhook_token'       => '',
			'remove_on_uninstall' => 'no',
		);
	}

	/** @var array|null */
	private static $cache = null;

	public static function reset() {
		self::$cache = null;
	}

	/** Network option (multisite): the brand hub can manage one account for every site. */
	const NETWORK_OPTION = 'tw_datatrans_network_settings';
	const NETWORK_KEYS   = array( 'merchant_id', 'password', 'sandbox', 'sandbox_merchant_id', 'sandbox_password', 'sign_key', 'autosettle' );

	public static function network() {
		if ( ! is_multisite() ) {
			return array();
		}
		$n = get_site_option( self::NETWORK_OPTION, array() );
		return is_array( $n ) ? $n : array();
	}

	/** True when the network settings carry the credentials for every site. */
	public static function is_network_managed() {
		$n = self::network();
		return ( $n['managed'] ?? 'no' ) === 'yes';
	}

	public static function all() {
		$cache = &self::$cache;
		if ( null === $cache ) {
			$saved = get_option( self::OPTION, array() );
			$cache = array_merge( self::defaults(), is_array( $saved ) ? $saved : array() );
			if ( self::is_network_managed() ) {
				foreach ( self::NETWORK_KEYS as $k ) {
					if ( array_key_exists( $k, self::network() ) ) {
						$cache[ $k ] = (string) self::network()[ $k ];
					}
				}
			}
			// Constants in wp-config.php win over the database (secrets out of the DB if wanted).
			foreach ( array( 'merchant_id', 'password', 'sandbox_merchant_id', 'sandbox_password', 'sign_key' ) as $k ) {
				$const = 'TW_DATATRANS_' . strtoupper( $k );
				if ( defined( $const ) && constant( $const ) !== '' ) {
					$cache[ $k ] = (string) constant( $const );
				}
			}
			if ( '' === $cache['webhook_token'] ) {
				$cache['webhook_token'] = wp_generate_password( 32, false, false );
				$saved['webhook_token'] = $cache['webhook_token'];
				update_option( self::OPTION, is_array( $saved ) ? $saved : array( 'webhook_token' => $cache['webhook_token'] ), false );
			}
		}
		return $cache;
	}

	public static function get( $key ) {
		$all = self::all();
		return $all[ $key ] ?? '';
	}

	public static function is_sandbox() {
		return 'yes' === self::get( 'sandbox' );
	}

	/** Credentials of the active environment. */
	public static function credentials() {
		if ( self::is_sandbox() ) {
			return array( self::get( 'sandbox_merchant_id' ), self::get( 'sandbox_password' ) );
		}
		return array( self::get( 'merchant_id' ), self::get( 'password' ) );
	}

	public static function is_configured() {
		list( $id, $pw ) = self::credentials();
		return '' !== $id && '' !== $pw;
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 60 );
		add_action( 'admin_notices', array( __CLASS__, 'notice_unconfigured' ) );
	}

	public static function menu() {
		add_submenu_page(
			'woocommerce',
			__( 'Datatrans', 'tw-datatrans' ),
			__( 'Datatrans', 'tw-datatrans' ),
			'manage_woocommerce',
			self::PAGE,
			array( __CLASS__, 'render' )
		);
	}

	public static function notice_unconfigured() {
		if ( self::is_configured() || ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		if ( isset( $_GET['page'] ) && self::PAGE === $_GET['page'] ) {
			return;
		}
		$enabled = false;
		foreach ( TW_Datatrans_Gateway::methods() as $id => $class ) {
			$opt = get_option( 'woocommerce_' . $id . '_settings', array() );
			if ( is_array( $opt ) && ( $opt['enabled'] ?? 'no' ) === 'yes' ) {
				$enabled = true;
			}
		}
		if ( ! $enabled ) {
			return;
		}
		echo '<div class="notice notice-warning"><p><strong>Datatrans:</strong> '
			. esc_html__( 'a Datatrans payment method is enabled but the merchant credentials are missing: customers cannot pay.', 'tw-datatrans' )
			. ' <a href="' . esc_url( admin_url( 'admin.php?page=' . self::PAGE ) ) . '">' . esc_html__( 'Enter the credentials', 'tw-datatrans' ) . '</a></p></div>';
	}

	/** POST handling + page. */
	public static function render() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You are not allowed to manage these settings.', 'tw-datatrans' ) );
		}
		$notices = array();

		if ( ! self::is_network_managed() && isset( $_POST['tw_datatrans_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['tw_datatrans_nonce'] ) ), 'tw_datatrans_save' ) ) {
			$in    = isset( $_POST['tw_datatrans'] ) && is_array( $_POST['tw_datatrans'] ) ? wp_unslash( $_POST['tw_datatrans'] ) : array();
			$saved = get_option( self::OPTION, array() );
			$saved = is_array( $saved ) ? $saved : array();
			$text  = function ( $k ) use ( $in ) {
				return sanitize_text_field( trim( (string) ( $in[ $k ] ?? '' ) ) );
			};
			$saved['merchant_id']         = preg_replace( '/\D/', '', $text( 'merchant_id' ) );
			$saved['sandbox_merchant_id'] = preg_replace( '/\D/', '', $text( 'sandbox_merchant_id' ) );
			// Passwords: an empty field keeps the stored value (never shown in the HTML).
			foreach ( array( 'password', 'sandbox_password', 'sign_key' ) as $secret ) {
				$v = trim( (string) ( $in[ $secret ] ?? '' ) );
				if ( '' !== $v ) {
					$saved[ $secret ] = 'sign_key' === $secret ? strtolower( preg_replace( '/[^0-9a-fA-F]/', '', $v ) ) : $v;
				} elseif ( ! empty( $in[ $secret . '_clear' ] ) ) {
					$saved[ $secret ] = '';
				}
			}
			$saved['sandbox']             = ! empty( $in['sandbox'] ) ? 'yes' : 'no';
			$saved['autosettle']          = ! empty( $in['autosettle'] ) ? 'yes' : 'no';
			$saved['log']                 = ! empty( $in['log'] ) ? 'yes' : 'no';
			$saved['remove_on_uninstall'] = ! empty( $in['remove_on_uninstall'] ) ? 'yes' : 'no';
			update_option( self::OPTION, $saved, false );
			self::reset();
			wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE, 'saved' => 1 ), admin_url( 'admin.php' ) ) );
			exit;
		}
		if ( isset( $_GET['saved'] ) ) {
			$notices[] = array( 'success', __( 'Settings saved.', 'tw-datatrans' ) );
		}

		$check = null;
		if ( isset( $_POST['tw_datatrans_check_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['tw_datatrans_check_nonce'] ) ), 'tw_datatrans_check' ) ) {
			$check = TW_Datatrans_API::check_credentials();
		}

		$s          = self::all();
		$sandbox    = self::is_sandbox();
		$configured = self::is_configured();
		$webhook    = TW_Datatrans_Handlers::webhook_url();
		?>
		<div class="wrap tw-datatrans-wrap">
			<h1>Datatrans by ticinoWEB</h1>
			<p class="description" style="max-width:780px;">
				<?php esc_html_e( 'One Datatrans account for every payment method. Enter the merchant credentials here once; then switch TWINT, cards, Apple Pay and Google Pay on or off from WooCommerce → Settings → Payments, like any other payment method.', 'tw-datatrans' ); ?>
			</p>
			<?php foreach ( $notices as $n ) : ?>
				<div class="notice notice-<?php echo esc_attr( $n[0] ); ?> is-dismissible"><p><?php echo esc_html( $n[1] ); ?></p></div>
			<?php endforeach; ?>
			<?php if ( self::is_network_managed() ) : ?>
				<div class="notice notice-info"><p><?php esc_html_e( 'The Datatrans account (mode, credentials, signing key, settlement) is managed centrally from the main site of this network: the fields below are read-only here.', 'tw-datatrans' ); ?></p></div>
			<?php endif; ?>

			<div style="display:flex;gap:24px;flex-wrap:wrap;align-items:flex-start;">
			<form method="post" style="flex:1 1 560px;max-width:760px;<?php echo self::is_network_managed() ? 'pointer-events:none;opacity:.6;' : ''; ?>">
				<?php wp_nonce_field( 'tw_datatrans_save', 'tw_datatrans_nonce' ); ?>
				<h2 class="title"><?php esc_html_e( 'Environment', 'tw-datatrans' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><?php esc_html_e( 'Mode', 'tw-datatrans' ); ?></th>
						<td>
							<label style="display:block;margin-bottom:6px;"><input type="radio" name="tw_datatrans[sandbox]" value="" <?php checked( ! $sandbox ); ?> /> <strong><?php esc_html_e( 'Live', 'tw-datatrans' ); ?></strong> — <?php esc_html_e( 'real payments', 'tw-datatrans' ); ?></label>
							<label style="display:block;"><input type="radio" name="tw_datatrans[sandbox]" value="1" <?php checked( $sandbox ); ?> /> <strong><?php esc_html_e( 'Test (sandbox)', 'tw-datatrans' ); ?></strong> — <?php esc_html_e( 'no money moves, Datatrans test cards', 'tw-datatrans' ); ?></label>
							<?php if ( $sandbox ) : ?>
								<p class="description" style="color:#b00020;"><?php esc_html_e( 'Test mode is on: customers see the payment methods but no real payment is taken.', 'tw-datatrans' ); ?></p>
							<?php endif; ?>
						</td>
					</tr>
				</table>

				<h2 class="title"><?php esc_html_e( 'Live credentials', 'tw-datatrans' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Datatrans Webadmin → UPP Administration → Security: merchant ID and server-to-server password.', 'tw-datatrans' ); ?></p>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="tw-dt-merchant"><?php esc_html_e( 'Merchant ID', 'tw-datatrans' ); ?></label></th>
						<td><input type="text" id="tw-dt-merchant" name="tw_datatrans[merchant_id]" value="<?php echo esc_attr( $s['merchant_id'] ); ?>" class="regular-text" style="font-family:monospace;width:200px;" placeholder="3000012345" inputmode="numeric" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="tw-dt-password"><?php esc_html_e( 'Server-to-server password', 'tw-datatrans' ); ?></label></th>
						<td>
							<input type="password" id="tw-dt-password" name="tw_datatrans[password]" value="" class="regular-text" autocomplete="new-password" placeholder="<?php echo '' !== $s['password'] ? esc_attr__( '•••••••• (saved, leave empty to keep)', 'tw-datatrans' ) : ''; ?>" />
							<?php if ( '' !== $s['password'] ) : ?>
								<label style="margin-left:8px;"><input type="checkbox" name="tw_datatrans[password_clear]" value="1" /> <?php esc_html_e( 'remove', 'tw-datatrans' ); ?></label>
							<?php endif; ?>
						</td>
					</tr>
				</table>

				<h2 class="title"><?php esc_html_e( 'Test credentials (sandbox)', 'tw-datatrans' ); ?></h2>
				<p class="description"><?php esc_html_e( 'From the Datatrans sandbox account (admin.sandbox.datatrans.com). Only used while Test mode is on.', 'tw-datatrans' ); ?></p>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="tw-dt-smerchant"><?php esc_html_e( 'Sandbox merchant ID', 'tw-datatrans' ); ?></label></th>
						<td><input type="text" id="tw-dt-smerchant" name="tw_datatrans[sandbox_merchant_id]" value="<?php echo esc_attr( $s['sandbox_merchant_id'] ); ?>" class="regular-text" style="font-family:monospace;width:200px;" placeholder="1100012345" inputmode="numeric" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="tw-dt-spassword"><?php esc_html_e( 'Sandbox password', 'tw-datatrans' ); ?></label></th>
						<td>
							<input type="password" id="tw-dt-spassword" name="tw_datatrans[sandbox_password]" value="" class="regular-text" autocomplete="new-password" placeholder="<?php echo '' !== $s['sandbox_password'] ? esc_attr__( '•••••••• (saved, leave empty to keep)', 'tw-datatrans' ) : ''; ?>" />
							<?php if ( '' !== $s['sandbox_password'] ) : ?>
								<label style="margin-left:8px;"><input type="checkbox" name="tw_datatrans[sandbox_password_clear]" value="1" /> <?php esc_html_e( 'remove', 'tw-datatrans' ); ?></label>
							<?php endif; ?>
						</td>
					</tr>
				</table>

				<h2 class="title"><?php esc_html_e( 'Security and settlement', 'tw-datatrans' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="tw-dt-sign"><?php esc_html_e( 'Webhook signing key (HMAC)', 'tw-datatrans' ); ?></label></th>
						<td>
							<input type="password" id="tw-dt-sign" name="tw_datatrans[sign_key]" value="" class="regular-text" autocomplete="new-password" style="font-family:monospace;" placeholder="<?php echo '' !== $s['sign_key'] ? esc_attr__( '•••••••• (saved, leave empty to keep)', 'tw-datatrans' ) : esc_attr__( 'hex key from Webadmin → Security', 'tw-datatrans' ); ?>" />
							<?php if ( '' !== $s['sign_key'] ) : ?>
								<label style="margin-left:8px;"><input type="checkbox" name="tw_datatrans[sign_key_clear]" value="1" /> <?php esc_html_e( 'remove', 'tw-datatrans' ); ?></label>
							<?php endif; ?>
							<p class="description"><?php esc_html_e( 'Recommended. Webadmin → UPP Administration → Security → "Important parameters will be digitally signed (HMAC-SHA256)": paste the hexadecimal key. With it, only notifications really sent by Datatrans are accepted. Every notification is in any case re-checked against the Datatrans API before an order is marked paid.', 'tw-datatrans' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Settlement', 'tw-datatrans' ); ?></th>
						<td>
							<label><input type="checkbox" name="tw_datatrans[autosettle]" value="1" <?php checked( 'yes', $s['autosettle'] ); ?> /> <?php esc_html_e( 'Charge immediately (automatic settlement)', 'tw-datatrans' ); ?></label>
							<p class="description"><?php esc_html_e( 'Recommended for shops that ship or serve right away. Unchecked, the amount is only reserved and must be settled in the Datatrans Webadmin.', 'tw-datatrans' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Log', 'tw-datatrans' ); ?></th>
						<td>
							<label><input type="checkbox" name="tw_datatrans[log]" value="1" <?php checked( 'yes', $s['log'] ); ?> /> <?php esc_html_e( 'Write a detailed log (WooCommerce → Status → Logs, source "tw-datatrans")', 'tw-datatrans' ); ?></label>
							<p class="description"><?php esc_html_e( 'Errors are always logged. Turn this on when something needs to be checked, off afterwards.', 'tw-datatrans' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Uninstall', 'tw-datatrans' ); ?></th>
						<td><label><input type="checkbox" name="tw_datatrans[remove_on_uninstall]" value="1" <?php checked( 'yes', $s['remove_on_uninstall'] ); ?> /> <?php esc_html_e( 'Delete these settings when the plugin is deleted', 'tw-datatrans' ); ?></label></td>
					</tr>
				</table>
				<?php submit_button( __( 'Save settings', 'tw-datatrans' ) ); ?>
			</form>

			<div style="flex:0 1 360px;">
				<div class="card" style="margin-top:0;padding:16px 20px;">
					<h2 style="margin-top:0;"><?php esc_html_e( 'Connection', 'tw-datatrans' ); ?></h2>
					<?php if ( ! $configured ) : ?>
						<p><span style="color:#b00020;font-weight:600;">⚠️ <?php esc_html_e( 'Credentials missing', 'tw-datatrans' ); ?></span><br/><span class="description"><?php echo esc_html( $sandbox ? __( 'Enter the sandbox merchant ID and password.', 'tw-datatrans' ) : __( 'Enter the live merchant ID and password.', 'tw-datatrans' ) ); ?></span></p>
					<?php else : ?>
						<p><?php echo esc_html( sprintf( $sandbox ? __( 'Sandbox merchant %s', 'tw-datatrans' ) : __( 'Live merchant %s', 'tw-datatrans' ), self::credentials()[0] ) ); ?></p>
						<?php if ( null !== $check ) : ?>
							<p style="font-weight:600;color:<?php echo $check['ok'] ? '#2e7d32' : '#b00020'; ?>;"><?php echo esc_html( ( $check['ok'] ? '✅ ' : '❌ ' ) . $check['message'] ); ?></p>
						<?php endif; ?>
						<form method="post">
							<?php wp_nonce_field( 'tw_datatrans_check', 'tw_datatrans_check_nonce' ); ?>
							<button type="submit" class="button"><?php esc_html_e( 'Check the credentials', 'tw-datatrans' ); ?></button>
						</form>
					<?php endif; ?>
				</div>

				<div class="card" style="padding:16px 20px;">
					<h2 style="margin-top:0;"><?php esc_html_e( 'Payment methods', 'tw-datatrans' ); ?></h2>
					<table class="widefat striped" style="margin-bottom:10px;">
						<tbody>
						<?php foreach ( TW_Datatrans_Gateway::methods() as $id => $class ) :
							$opt = get_option( 'woocommerce_' . $id . '_settings', array() );
							$on  = is_array( $opt ) && ( $opt['enabled'] ?? 'no' ) === 'yes';
							?>
							<tr>
								<td><?php echo esc_html( $class::LABEL ); ?></td>
								<td style="width:90px;"><?php echo $on ? '<span style="color:#2e7d32;font-weight:600;">' . esc_html__( 'On', 'tw-datatrans' ) . '</span>' : '<span style="color:#646970;">' . esc_html__( 'Off', 'tw-datatrans' ) . '</span>'; ?></td>
								<td style="width:90px;"><a href="<?php echo esc_url( admin_url( 'admin.php?page=wc-settings&tab=checkout&section=' . $id ) ); ?>"><?php esc_html_e( 'Manage', 'tw-datatrans' ); ?></a></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
					<p class="description"><?php esc_html_e( 'Each method must also be active in the Datatrans Webadmin (UPP Administration → Payment methods). Apple Pay: accept the Apple Pay web terms there and set the name shown on the payment sheet.', 'tw-datatrans' ); ?></p>
				</div>

				<div class="card" style="padding:16px 20px;">
					<h2 style="margin-top:0;"><?php esc_html_e( 'Notifications (webhook)', 'tw-datatrans' ); ?></h2>
					<p class="description"><?php esc_html_e( 'The plugin tells Datatrans where to send the payment notification with every payment: nothing to configure in the Webadmin.', 'tw-datatrans' ); ?></p>
					<code style="display:block;word-break:break-all;font-size:11px;"><?php echo esc_html( $webhook ); ?></code>
				</div>
			</div>
			</div>
		</div>
		<?php
	}
}
