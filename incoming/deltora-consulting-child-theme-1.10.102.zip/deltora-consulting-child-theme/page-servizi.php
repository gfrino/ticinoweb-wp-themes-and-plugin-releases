<?php
/**
 * Services page template.
 *
 * @package DeltoraConsultingChildTheme
 */

$deltora_contact_url = deltora_consulting_get_page_url( 'contatti' );
$deltora_services    = deltora_consulting_get_services();

get_header();
?>

<main id="main-content" class="site-main deltora-services-page">
	<section class="deltora-services-hero" aria-labelledby="deltora-services-title">
		<div class="deltora-container deltora-services-hero__grid">
			<div class="deltora-services-hero__content" data-motion="page-heading">
				<h1 id="deltora-services-title">
					<span><?php esc_html_e( 'Servizi alle aziende', 'deltora-consulting-child-theme' ); ?></span>
					<em><?php esc_html_e( 'Una visione completa, un supporto concreto', 'deltora-consulting-child-theme' ); ?></em>
				</h1>
				<p><?php esc_html_e( 'L’approccio multidisciplinare consente di supportare il cliente nelle decisioni strategiche, nell’organizzazione aziendale e nelle operazioni di carattere straordinario, fornendo soluzioni personalizzate in funzione delle specifiche esigenze dell’impresa.', 'deltora-consulting-child-theme' ); ?></p>
			</div>

			<nav class="deltora-services-index" data-motion="route-index" data-motion-delay="80" aria-label="<?php esc_attr_e( 'Aree di competenza', 'deltora-consulting-child-theme' ); ?>">
				<ul>
					<?php foreach ( $deltora_services as $deltora_service ) : ?>
						<li>
						<a href="#servizio-<?php echo esc_attr( $deltora_service['slug'] ); ?>">
								<span><?php echo esc_html( $deltora_service['title'] ); ?></span>
								<svg aria-hidden="true" viewBox="0 0 24 24" fill="none">
									<path d="M5 12H19M14 7L19 12L14 17" />
								</svg>
							</a>
						</li>
					<?php endforeach; ?>
				</ul>
			</nav>
		</div>
	</section>

	<div class="deltora-services-chapters">
		<?php foreach ( $deltora_services as $deltora_service_index => $deltora_service ) : ?>
			<?php
			$deltora_service_image       = $deltora_service['image'];
			$deltora_service_contact_url = add_query_arg( 'argomento', $deltora_service['slug'], $deltora_contact_url );

			$deltora_image_side = 0 === $deltora_service_index % 2 ? 'right' : 'left';
			$deltora_image_alt  = sprintf(
				/* translators: %s: service name. */
				__( 'Immagine per %s', 'deltora-consulting-child-theme' ),
				$deltora_service['title']
			);
			?>
			<section id="servizio-<?php echo esc_attr( $deltora_service['slug'] ); ?>" class="deltora-services-chapter deltora-services-chapter--image-<?php echo esc_attr( $deltora_image_side ); ?>" aria-labelledby="servizio-<?php echo esc_attr( $deltora_service['slug'] ); ?>-title">
				<div class="deltora-container deltora-services-chapter__grid">
					<div class="deltora-services-chapter__copy" data-motion="chapter-copy">
					<h2 id="servizio-<?php echo esc_attr( $deltora_service['slug'] ); ?>-title"><?php echo esc_html( $deltora_service['title'] ); ?></h2>
					<div class="deltora-services-chapter__intro"><?php echo wp_kses_post( wpautop( $deltora_service['description'] ) ); ?></div>
					<?php if ( $deltora_service['details'] ) : ?>
						<ul class="deltora-services-chapter__details">
							<?php foreach ( $deltora_service['details'] as $deltora_service_detail ) : ?>
								<li><?php echo esc_html( $deltora_service_detail ); ?></li>
							<?php endforeach; ?>
						</ul>
					<?php endif; ?>
						<a class="deltora-services-chapter__link" href="<?php echo esc_url( $deltora_service_contact_url ); ?>"><?php esc_html_e( 'Parliamone', 'deltora-consulting-child-theme' ); ?><span class="deltora-direction-icon deltora-direction-icon--right" aria-hidden="true"></span></a>
					</div>

				<div class="deltora-services-chapter__media" data-motion="chapter-media" data-motion-delay="70" data-service-media="<?php echo esc_attr( $deltora_service['slug'] ); ?>" data-image-state="<?php echo $deltora_service_image ? 'ready' : 'empty'; ?>">
						<?php if ( $deltora_service_image ) : ?>
							<img src="<?php echo esc_url( $deltora_service_image ); ?>" alt="<?php echo esc_attr( $deltora_image_alt ); ?>" loading="lazy" decoding="async">
						<?php else : ?>
							<div class="deltora-services-chapter__placeholder" role="img" aria-label="<?php echo esc_attr( $deltora_image_alt ); ?>">
								<span><?php esc_html_e( 'Immagine del servizio', 'deltora-consulting-child-theme' ); ?></span>
							</div>
						<?php endif; ?>
					</div>
				</div>
			</section>
		<?php endforeach; ?>
	</div>

</main>

<?php
get_footer();
