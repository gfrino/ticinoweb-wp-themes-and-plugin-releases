<?php
/**
 * Company lookup and local sector-classification boundary.
 *
 * The extension point named `deltora_ai_sector_classifier` is intentionally
 * reserved for a possible future provider. It is not invoked in this version.
 *
 * @package DeltoraConsultingChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return private lookup settings with explicit scalar types.
 *
 * Credentials remain server-side and are never included in localized data.
 *
 * @return array{enabled:bool,zefix_username:string,zefix_password:string}
 */
function deltora_consulting_get_company_lookup_settings() {
	$enabled  = defined( 'DELTORA_COMPANY_LOOKUP_ENABLED' ) ? DELTORA_COMPANY_LOOKUP_ENABLED : false;
	$settings = array(
		'enabled'        => (bool) filter_var( $enabled, FILTER_VALIDATE_BOOLEAN ),
		'zefix_username' => defined( 'DELTORA_ZEFIX_USERNAME' ) ? trim( (string) DELTORA_ZEFIX_USERNAME ) : '',
		'zefix_password' => defined( 'DELTORA_ZEFIX_PASSWORD' ) ? (string) DELTORA_ZEFIX_PASSWORD : '',
	);

	$filtered = apply_filters( 'deltora_company_lookup_settings', $settings );
	$filtered = is_array( $filtered ) ? $filtered : $settings;

	return array(
		'enabled'        => (bool) filter_var( $filtered['enabled'] ?? false, FILTER_VALIDATE_BOOLEAN ),
		'zefix_username' => trim( (string) ( $filtered['zefix_username'] ?? '' ) ),
		'zefix_password' => (string) ( $filtered['zefix_password'] ?? '' ),
	);
}

/** Return public capability flags without exposing secrets. */
function deltora_consulting_get_company_lookup_capabilities() {
	$settings = deltora_consulting_get_company_lookup_settings();
	$provider = apply_filters( 'deltora_company_lookup_provider', null );

	return array(
		'enabled'          => $settings['enabled']
			&& '' !== $settings['zefix_username']
			&& '' !== $settings['zefix_password']
			&& is_callable( $provider ),
		'local_classifier' => true,
		'ai_enabled'       => false,
	);
}

/**
 * Normalize text used only for local keyword matching.
 *
 * @param string $purpose Company purpose.
 * @return string
 */
function deltora_consulting_normalize_company_purpose( $purpose ) {
	$text = sanitize_textarea_field( (string) $purpose );
	$text = function_exists( 'remove_accents' ) ? remove_accents( $text ) : $text;
	$text = function_exists( 'mb_strtolower' ) ? mb_strtolower( $text, 'UTF-8' ) : strtolower( $text );
	$text = preg_replace( "/[’'`´‐‑‒–—-]+/u", ' ', $text );
	return trim( (string) preg_replace( '/\s+/', ' ', $text ) );
}

/**
 * Remove legal and trade-language ambiguities before local classification.
 *
 * Some ordinary Italian registry phrases contain words that look like sector
 * evidence but describe only the legal entity or a building trade. Replacing
 * those fixed contexts avoids health-sector false positives without weakening
 * genuine phrases such as "assistenza sanitaria".
 *
 * @param string $purpose Company purpose.
 * @return string
 */
function deltora_consulting_prepare_company_purpose_for_classification( $purpose ) {
	$purpose = deltora_consulting_normalize_company_purpose( $purpose );
	$purpose = str_replace(
		array( 'scopo sociale', 'oggetto sociale', 'capitale sociale', 'ragione sociale', 'sede sociale', 'sviluppo economico' ),
		array( 'scopo societario', 'oggetto societario', 'capitale societario', 'ragione societaria', 'sede societaria', 'crescita economica' ),
		$purpose
	);
	$purpose = preg_replace( '/impianti? idraulici? e sanitari?/u', 'impianti idraulici', $purpose );
	$purpose = preg_replace( '/impianti? sanitari?/u', 'impianti idraulici', (string) $purpose );

	return trim( (string) preg_replace( '/\s+/', ' ', (string) $purpose ) );
}

/**
 * Split a normalized company purpose into weighted semantic segments.
 *
 * @param string $purpose Prepared company purpose.
 * @return array<int,string>
 */
function deltora_consulting_split_company_purpose_for_classification( $purpose ) {
	$segments = preg_split( '/(?<=[.!?;])\s+/u', $purpose );
	$segments = array_values( array_filter( array_map( 'trim', (array) $segments ) ) );

	return ! empty( $segments ) ? $segments : array( $purpose );
}

/**
 * Weight an operative sentence above ancillary corporate powers.
 *
 * Registry purposes normally describe the core activity first, followed by
 * broad legal powers. Explicit own-account limitations must never create a
 * customer-facing sector suggestion.
 *
 * @param string $segment Prepared purpose segment.
 * @param int    $index   Zero-based segment position.
 * @return float
 */
function deltora_consulting_company_purpose_segment_weight( $segment, $index ) {
	if (
		deltora_consulting_company_purpose_contains_term( $segment, 'non e rivolta a terzi' )
		|| deltora_consulting_company_purpose_contains_term( $segment, 'esclusivamente per proprio conto' )
		|| deltora_consulting_company_purpose_contains_term( $segment, 'limitata a beni immobili per proprio conto' )
		|| deltora_consulting_company_purpose_contains_term( $segment, 'per proprio conto e non a titolo fiduciario' )
	) {
		return 0.0;
	}

	$boilerplate_patterns = array(
		'/\bla societa potra inoltre\b/u',
		'/\bla societa infine potra\b/u',
		'/^la societa (?:puo|potra) (?:inoltre )?(?:partecipare|costituire|aprire|acquistare|detenere|amministrare|gravare|vendere beni immobili|concedere prestiti|prestare garanzie|compiere operazioni)\b/u',
		'/\b(?:tutte|qualsiasi|qualunque) (?:le |altra )?(?:operazioni|attivita)\b/u',
		'/\b(?:costituire|aprire) (?:succursali|filiali)\b/u',
		'/\bpartecipazioni in altre societa\b/u',
		'/^die gesellschaft kann (?:im in und ausland )?(?:zweigniederlassungen|tochtergesellschaften|grundstucke|darlehen|garantien|alle geschafte)\b/u',
		'/^la societe peut (?:en suisse et a l etranger )?(?:creer des succursales|constituer des filiales|acquerir des immeubles|accorder des prets|effectuer toutes operations)\b/u',
	);
	foreach ( $boilerplate_patterns as $pattern ) {
		if ( 1 === preg_match( $pattern, $segment ) ) {
			return 0.15;
		}
	}

	if ( 1 === preg_match( '/^il commercio.*\bimportazione\b.*\besportazione\b.*\bogni bene\b/u', $segment ) ) {
		return 0.25;
	}

	if ( 1 === preg_match( '/\bla societa potra pertanto\b/u', $segment ) ) {
		return 1.5;
	}

	if ( 0 === $index ) {
		return 3.0;
	}

	return 1 === $index ? 2.0 : 1.0;
}

/**
 * Return the strongest segment position in which a term appears.
 *
 * @param array<int,string> $segments Purpose segments.
 * @param string            $term     Normalized evidence term.
 * @return float
 */
function deltora_consulting_company_term_segment_weight( $segments, $term ) {
	$maximum = 0.0;
	foreach ( $segments as $index => $segment ) {
		if ( deltora_consulting_company_purpose_contains_term( $segment, $term ) ) {
			$maximum = max( $maximum, deltora_consulting_company_purpose_segment_weight( $segment, (int) $index ) );
		}
	}

	return $maximum;
}

/**
 * Return words that are useful only when paired with a concrete activity.
 *
 * These broad CMS keywords must not classify a company on their own. For
 * example, "sviluppo economico" is not evidence of a technology company and
 * "formazione del personale" does not necessarily describe a school.
 *
 * @return array<int,string>
 */
function deltora_consulting_get_ambiguous_company_keywords() {
	return array(
		'sviluppo',
		'assistenza',
		'supporto',
		'gestione',
		'amministrazione',
		'agenzia',
		'impianti',
		'manutenzione',
		'ricerca',
		'laboratorio',
		'tecnico',
		'personale',
		'formazione',
		'consulenza',
		'riparazione',
		'merci',
	);
}

/**
 * Return contextual activity rules that join an action to its object.
 *
 * A registry purpose often mentions the same product in several capacities.
 * These rules distinguish making a product, selling it and providing a
 * related service without relying on the company name or an external model.
 *
 * @return array<int,array{sector_id:string,weight:float,actions:array<int,string>,objects:array<int,string>}>
 */
function deltora_consulting_get_company_activity_context_rules() {
	return array(
		array(
			'sector_id' => 'manufacturing',
			'weight'    => 6.0,
			'actions'   => array( 'produzione', 'fabbricazione', 'lavorazione', 'assemblaggio', 'confezionamento', 'herstellung', 'fabrikation', 'produktion', 'fabrication', 'manufacture', 'assemblage', 'usinage' ),
			'objects'   => array( 'prodotti medicinali', 'specialita medicinali', 'medicamenti', 'prodotti farmaceutici', 'prodotti chimici', 'dispositivi medici', 'cosmetici', 'diagnostici', 'macchine', 'macchinari', 'utensili', 'componenti', 'prodotti alimentari', 'derrate alimentari', 'carni', 'bevande', 'abbigliamento', 'calzature', 'orologi', 'montres' ),
		),
		array(
			'sector_id' => 'trade-ecommerce',
			'weight'    => 4.0,
			'actions'   => array( 'commercio all ingrosso', 'commercio al dettaglio', 'vendita al dettaglio', 'vendita all ingrosso', 'commercializzazione', 'distribuzione', 'smercio', 'grosshandel', 'einzelhandel', 'verkauf', 'vertrieb', 'commerce de gros', 'commerce de detail', 'commercialisation', 'vente', 'distribution' ),
			'objects'   => array( 'prodotti medicinali', 'specialita medicinali', 'medicamenti', 'prodotti farmaceutici', 'prodotti chimici', 'dispositivi medici', 'cosmetici', 'diagnostici', 'prodotti alimentari', 'derrate alimentari', 'bevande', 'abbigliamento', 'calzature', 'beni di consumo', 'merci', 'marchandises' ),
		),
		array(
			'sector_id' => 'trade-ecommerce',
			'weight'    => 7.0,
			'actions'   => array( 'gestione di una farmacia', 'gestione d una farmacia', 'esercizio di una farmacia', 'pharmacie', 'apotheke' ),
			'objects'   => array( 'farmacia', 'medicinali', 'farmaceutiche', 'medicaments', 'medikamente' ),
		),
		array(
			'sector_id' => 'health-social-veterinary',
			'weight'    => 6.0,
			'actions'   => array( 'prestazioni sanitarie', 'assistenza sanitaria', 'servizi medici', 'direzione e gestione di ospedali', 'gestione di ospedali', 'studio medico', 'clinica', 'cure mediche', 'soins de sante', 'services medicaux', 'medizinische dienstleistungen', 'gesundheitsversorgung' ),
			'objects'   => array( 'pazienti', 'popolazione', 'ospedali', 'clinica', 'studio medico', 'servizi medici', 'cure', 'soins', 'patienten', 'krankenhaus' ),
		),
		array(
			'sector_id' => 'technology',
			'weight'    => 5.0,
			'actions'   => array( 'sviluppo', 'creazione', 'programmazione', 'migrazione', 'softwareentwicklung', 'programmierung', 'developpement', 'migration' ),
			'objects'   => array( 'software', 'applicazioni', 'sistemi informatici', 'cloud', 'piattaforme digitali', 'datenverarbeitung', 'logiciels', 'informatique' ),
		),
		array(
			'sector_id' => 'business-support',
			'weight'    => 6.0,
			'actions'   => array( 'messa a disposizione di personale', 'gestione del personale su mandato', 'selezione del personale', 'personalvermittlung', 'personalverleih', 'placement de personnel', 'mise a disposition de personnel' ),
			'objects'   => array( 'personale', 'posti fissi', 'posti temporanei', 'lavoro temporaneo', 'outsourcing', 'salari', 'personal', 'personnel' ),
		),
	);
}

/** Return whether a segment contains at least one term from a set. */
function deltora_consulting_company_segment_contains_any( $segment, $terms ) {
	foreach ( $terms as $term ) {
		$term = deltora_consulting_normalize_company_purpose( $term );
		if ( '' !== $term && deltora_consulting_company_purpose_contains_term( $segment, $term ) ) {
			return true;
		}
	}

	return false;
}

/**
 * Score contextual action-object pairs by the importance of their sentence.
 *
 * @param array<int,string> $segments Prepared purpose segments.
 * @return array<string,float>
 */
function deltora_consulting_score_company_activity_contexts( $segments ) {
	$scores = array();

	foreach ( deltora_consulting_get_company_activity_context_rules() as $rule ) {
		$sector_id = sanitize_key( (string) $rule['sector_id'] );
		foreach ( $segments as $index => $segment ) {
			if (
				! deltora_consulting_company_segment_contains_any( $segment, $rule['actions'] )
				|| ! deltora_consulting_company_segment_contains_any( $segment, $rule['objects'] )
			) {
				continue;
			}

			$segment_weight       = deltora_consulting_company_purpose_segment_weight( $segment, (int) $index );
			$scores[ $sector_id ] = ( $scores[ $sector_id ] ?? 0.0 ) + (float) $rule['weight'] * $segment_weight;
		}
	}

	return $scores;
}

/**
 * Return conservative multilingual evidence used for Zefix purposes.
 *
 * Zefix commonly supplies the legal purpose in German or French. Strong terms
 * can identify a sector on their own; supporting terms require at least two
 * independent matches. Keywords configured in the CMS continue to be honored
 * and are merged with this conservative language bridge at classification time.
 *
 * @return array<string,array{strong:array<int,string>,supporting:array<int,string>}>
 */
function deltora_consulting_get_company_sector_lexicon() {
	$lexicon = array(
		'agriculture-energy-environment' => array(
			'strong'     => array( 'settore dell energia', 'energia elettrica', 'energie rinnovabili', 'produzione di energia', 'gas naturale', 'prodotti petroliferi', 'distribuzione di carburanti', 'forze idriche', 'fonti rinnovabili', 'gestione dei rifiuti', 'trattamento delle acque', 'landwirtschaft', 'forstwirtschaft', 'fischerei', 'energieversorgung', 'wasseraufbereitung', 'abfallentsorgung', 'recycling', 'agriculture', 'sylviculture', 'peche', 'production d energie', 'traitement des eaux', 'gestion des dechets' ),
			'supporting' => array( 'energie', 'energie renouvelable', 'umwelt', 'environnement', 'abfall', 'dechets' ),
		),
		'manufacturing' => array(
			'strong'     => array( 'produzione alimentare', 'industria alimentare', 'lavorazione carni', 'produzione di macchinari', 'produzione industriale', 'fabbricazione di', 'officina meccanica', 'herstellung', 'fabrikation', 'produktion', 'maschinenbau', 'nahrungsmittel', 'lebensmittel', 'industrie manufacturiere', 'industrie alimentaire', 'fabrication', 'manufacture', 'assemblage', 'usinage', 'horlogerie', 'montres' ),
			'supporting' => array( 'verarbeitung', 'montage', 'industrie', 'industriel', 'composants' ),
		),
		'construction' => array(
			'strong'     => array( 'general contractor', 'settore delle costruzioni', 'direzione lavori', 'ristrutturazione edilizia', 'progettazione edile', 'lattoniere', 'lattoneria', 'impermeabilizzazione', 'impianto idraulico', 'impianti idraulici', 'opere edili', 'lavori edili', 'falegnameria', 'elettricista', 'muratore', 'coperture', 'bauunternehmen', 'bauleistungen', 'baubereich', 'bauarbeiten', 'hochbau', 'tiefbau', 'gebaudeinstallation', 'travaux de construction', 'construction de batiments', 'genie civil', 'installation electrique' ),
			'supporting' => array( 'edilizia', 'idraulico', 'idraulici', 'artigianato', 'cantiere', 'bauwesen', 'baubranche', 'batiment', 'chantier' ),
		),
		'trade-ecommerce' => array(
			'strong'     => array( 'commercio al dettaglio', 'commercio all ingrosso', 'commercio elettronico', 'vendita al dettaglio', 'vendita all ingrosso', 'grosshandel', 'einzelhandel', 'commerce de gros', 'commerce de detail', 'commerce electronique', 'e-commerce' ),
			'supporting' => array( 'handel', 'verkauf', 'vertrieb', 'import', 'export', 'achat', 'vente', 'commercialisation', 'distribution', 'importation', 'exportation' ),
		),
		'transport-logistics' => array(
			'strong'     => array( 'trasporto merci', 'trasporto di merci', 'trasporto persone', 'trasporto di persone', 'servizi logistici', 'spedizioni internazionali', 'casa di spedizioni', 'spedizioni e trasporti', 'gestione magazzini', 'logistik', 'spedition', 'gutertransport', 'personentransport', 'lagerung', 'logistique', 'transport de marchandises', 'transport de personnes', 'entreposage' ),
			'supporting' => array( 'trasporti', 'spedizioni', 'transport', 'kurier', 'expedition', 'courrier' ),
		),
		'hospitality-tourism' => array(
			'strong'     => array( 'esercizio pubblico', 'attivita alberghiera', 'industria alberghiera', 'esercizio dell hotel', 'servizi di ristorazione', 'gestione di ristoranti', 'gestione di alberghi', 'agenzia di viaggi', 'gastronomie', 'hotellerie', 'beherbergung', 'gastgewerbe', 'restauration', 'hebergement', 'tourisme' ),
			'supporting' => array( 'restaurant', 'hotel', 'catering', 'traiteur', 'reisen', 'voyages' ),
		),
		'technology' => array(
			'strong'     => array( 'elettronica industriale', 'sistemi informatici', 'creazione di software', 'telefonia mobile', 'telefonia fissa', 'impianti di sorveglianza', 'impianti di allarme', 'sito web', 'siti web', 'servizi web', 'servizi digitali', 'sviluppo software', 'consulenza informatica', 'servizi informatici', 'gestionale aziendale', 'gestionali aziendali', 'applicazione web', 'applicazioni web', 'sviluppo di applicazioni', 'domini web', 'email aziendali', 'softwareentwicklung', 'entwicklung von software', 'informatik', 'telekommunikation', 'fernmelde', 'fernmeldedienste', 'datenverarbeitung', 'programmierung', 'developpement de logiciels', 'informatique', 'telecommunications', 'traitement de donnees', 'programmation' ),
			'supporting' => array( 'it', 'software', 'digitale', 'digitali', 'digital', 'tecnologia', 'technologie', 'technologies', 'hosting', 'dati', 'donnees' ),
		),
		'media-creative' => array(
			'strong'     => array( 'agenzia pubblicitaria', 'produzione audiovisiva', 'prodotti editoriali', 'comunicazione integrata', 'creazione di contenuti', 'marketing digitale', 'werbeagentur', 'verlagswesen', 'filmproduktion', 'agence de publicite', 'edition de livres', 'production audiovisuelle' ),
			'supporting' => array( 'werbung', 'marketing', 'verlag', 'medien', 'kommunikation', 'publicite', 'edition', 'medias', 'communication', 'design' ),
		),
		'finance-insurance' => array(
			'strong'     => array( 'attivita bancaria', 'operazioni bancarie', 'raccolta del risparmio', 'suoi risparmi', 'attivita fiduciaria', 'carattere fiduciario', 'gestione patrimoniale', 'consulenza finanziaria', 'intermediazione assicurativa', 'servizi fiduciari', 'finanzdienstleistungen', 'vermogensverwaltung', 'anlageberatung', 'versicherungsvermittlung', 'services financiers', 'gestion de fortune', 'conseil en placement', 'courtage en assurance' ),
			'supporting' => array( 'risparmi', 'versicherung', 'treuhand', 'kredit', 'assurance', 'fiduciaire', 'credit', 'courtage' ),
		),
		'real-estate' => array(
			'strong'     => array( 'gestione immobiliare', 'promozione immobiliare', 'intermediazione immobiliare', 'compravendita di immobili', 'amministrazione di stabili', 'immobilienverwaltung', 'immobilienvermittlung', 'liegenschaftsverwaltung', 'gestion immobiliere', 'courtage immobilier', 'promotion immobiliere' ),
			'supporting' => array( 'immobilien', 'grundstucke', 'liegenschaften', 'immobilier', 'immeubles', 'location' ),
		),
		'professional-services' => array(
			'strong'     => array( 'ambito legale', 'ambiti legali', 'assistenza legale', 'supporto legale', 'servizi legali', 'consulenza legale', 'consulenza aziendale', 'consulenza fiscale', 'studio legale', 'revisione contabile', 'progettazione ingegneristica', 'studio di architettura', 'unternehmensberatung', 'steuerberatung', 'wirtschaftsprufung', 'rechtsberatung', 'conseil aux entreprises', 'conseil fiscal', 'conseil juridique', 'expertise comptable' ),
			'supporting' => array( 'buchhaltung', 'ingenieurwesen', 'architektur', 'labor', 'comptabilite', 'audit', 'ingenierie', 'architecture', 'laboratoire' ),
		),
		'business-support' => array(
			'strong'     => array( 'pulizia di edifici', 'collocamento del personale', 'selezione del personale', 'messa a disposizione di personale', 'lavoro temporaneo', 'gestione del personale su mandato', 'servizi amministrativi', 'sicurezza privata', 'facility services', 'facility management', 'cleaning services', 'property services', 'support services', 'personalvermittlung', 'gebaudereinigung', 'sicherheitsdienst', 'placement de personnel', 'mise a disposition de personnel', 'travail temporaire', 'nettoyage de batiments', 'service de securite' ),
			'supporting' => array( 'gestione dei salari', 'personalverleih', 'sekretariat', 'secretariat', 'reinigung', 'nettoyage' ),
		),
		'education-training' => array(
			'strong'     => array( 'formazione professionale', 'corsi di formazione', 'scuola privata', 'servizi educativi', 'berufsbildung', 'weiterbildung', 'enseignement', 'formation professionnelle' ),
			'supporting' => array( 'ausbildung', 'schule', 'unterricht', 'bildung', 'formation', 'ecole', 'education', 'coaching' ),
		),
		'health-social-veterinary' => array(
			'strong'     => array( 'prodotti medicinali', 'specialita medicinali', 'dispositivi medici', 'ricerca farmaceutica', 'analisi medica', 'assistenza sanitaria', 'struttura sanitaria', 'prestazioni sanitarie', 'studio medico', 'servizi medici', 'assistenza sociale', 'servizi sociali', 'casa anziani', 'clinica veterinaria', 'studio veterinario', 'gesundheit', 'gesundheits', 'gesundheitswesen', 'pharmazeutisch', 'medizintechnik', 'biotechnologie', 'krankenpflege', 'veterinarmedizin', 'sante', 'soins de sante', 'pharmaceutique', 'technologie medicale', 'soins infirmiers', 'medecine veterinaire', 'life sciences' ),
			'supporting' => array( 'ernahrung', 'medizin', 'klinik', 'therapie', 'nutrition', 'medecine', 'clinique', 'therapie', 'soins' ),
		),
		'personal-sport-entertainment' => array(
			'strong'     => array( 'casa da gioco', 'gestione di casino', 'salone di parrucchiere', 'centro estetico', 'centro fitness', 'riparazione di veicoli', 'fitnessstudio', 'korperpflege', 'coiffeursalon', 'salle de sport', 'soins corporels', 'salon de coiffure' ),
			'supporting' => array( 'sport', 'fitness', 'unterhaltung', 'kultur', 'kosmetik', 'divertissement', 'culture', 'esthetique', 'reparation' ),
		),
	);

	$filtered = apply_filters( 'deltora_company_sector_lexicon', $lexicon );
	return is_array( $filtered ) ? $filtered : $lexicon;
}

/**
 * Test a normalized term as a whole word or phrase, never as a substring.
 *
 * @param string $purpose Normalized company purpose.
 * @param string $term    Normalized word or phrase.
 * @return bool
 */
function deltora_consulting_company_purpose_contains_term( $purpose, $term ) {
	if ( '' === $purpose || '' === $term ) {
		return false;
	}

	$pattern = '/(?<![\p{L}\p{N}])' . preg_quote( $term, '/' ) . '(?![\p{L}\p{N}])/u';
	return 1 === preg_match( $pattern, $purpose );
}

/**
 * Associate a company purpose with an active configured sector.
 *
 * A sector is proposed only when local rules produce a unique winner. Ties,
 * missing keywords and disabled sectors always return the manual fallback.
 *
 * @param string                         $purpose Company purpose.
 * @param array<int,array<string,mixed>> $sectors Optional active sectors.
 * @return array{sector_id:string,source:string,confidence:float}
 */
function deltora_consulting_classify_company_purpose( $purpose, $sectors = array() ) {
	$sectors = ! empty( $sectors ) ? $sectors : deltora_consulting_get_active_sectors();
	$purpose = deltora_consulting_prepare_company_purpose_for_classification( $purpose );
	$segments = deltora_consulting_split_company_purpose_for_classification( $purpose );
	$scores   = array();
	$lexicon  = deltora_consulting_get_company_sector_lexicon();
	$contexts = deltora_consulting_score_company_activity_contexts( $segments );
	$ambiguous_keywords = array_fill_keys( deltora_consulting_get_ambiguous_company_keywords(), true );

	foreach ( $sectors as $sector ) {
		$sector_id = sanitize_key( (string) ( $sector['id'] ?? '' ) );
		if ( '' === $sector_id || 'other' === $sector_id || empty( $sector['enabled'] ) ) {
			continue;
		}

		$terms = array();
		foreach ( (array) ( $sector['keywords'] ?? array() ) as $keyword ) {
			$keyword = deltora_consulting_normalize_company_purpose( $keyword );
			if ( '' !== $keyword && ! isset( $ambiguous_keywords[ $keyword ] ) ) {
				$terms[ $keyword ] = array( 'weight' => 1, 'configured' => true );
			}
		}

		foreach ( array( 'strong' => 3, 'supporting' => 1 ) as $evidence_type => $weight ) {
			foreach ( (array) ( $lexicon[ $sector_id ][ $evidence_type ] ?? array() ) as $term ) {
				$term = deltora_consulting_normalize_company_purpose( $term );
				if ( '' === $term ) {
					continue;
				}

				$existing = $terms[ $term ] ?? array( 'weight' => 0, 'configured' => false );
				$terms[ $term ] = array(
					'weight'     => max( (int) $existing['weight'], $weight ),
					'configured' => ! empty( $existing['configured'] ),
				);
			}
		}

		$score            = 0;
		$evidence_count   = 0;
		$has_strong       = false;
		$has_configured   = false;
		foreach ( $terms as $term => $evidence ) {
			$segment_weight = deltora_consulting_company_term_segment_weight( $segments, $term );
			if ( $segment_weight <= 0 ) {
				continue;
			}

			$weight          = (int) $evidence['weight'];
			$score          += $weight * $segment_weight;
			++$evidence_count;
			$has_strong     = $has_strong || $weight >= 3;
			$has_configured = $has_configured || ! empty( $evidence['configured'] );
		}

		if ( ! $has_configured && ! $has_strong && $evidence_count < 2 ) {
			$score = 0;
		}
		$scores[ $sector_id ] = $score + (float) ( $contexts[ $sector_id ] ?? 0.0 );
	}

	arsort( $scores );
	$ids          = array_keys( $scores );
	$winning_id   = $ids[0] ?? '';
	$winning      = $scores[ $winning_id ] ?? 0;
	$second_score = isset( $ids[1] ) ? $scores[ $ids[1] ] : 0;
	$total        = array_sum( $scores );
	$confidence   = $total > 0 ? $winning / $total : 0.0;
	$clear_margin = $second_score <= 0 || ( $winning - $second_score >= 3 && $winning / $second_score >= 1.25 );
	$clear_signal = $second_score <= 0 || $confidence >= 0.45;

	if ( $winning >= 3 && $clear_margin && $clear_signal ) {
		return array(
			'sector_id'  => $winning_id,
			'source'     => 'local',
			'confidence' => round( $confidence, 3 ),
		);
	}

	return array(
		'sector_id'  => 'other',
		'source'     => 'manual',
		'confidence' => 0.0,
	);
}

/**
 * Supply the built-in Zefix search provider unless another provider is set.
 *
 * @param callable|null $provider Existing provider.
 * @return callable|string|null
 */
function deltora_consulting_default_company_lookup_provider( $provider ) {
	return null === $provider ? 'deltora_consulting_zefix_search_companies' : $provider;
}
add_filter( 'deltora_company_lookup_provider', 'deltora_consulting_default_company_lookup_provider' );

/**
 * Supply the built-in Zefix detail provider unless another provider is set.
 *
 * @param callable|null $provider Existing provider.
 * @return callable|string|null
 */
function deltora_consulting_default_company_detail_provider( $provider ) {
	return null === $provider ? 'deltora_consulting_zefix_get_company' : $provider;
}
add_filter( 'deltora_company_detail_provider', 'deltora_consulting_default_company_detail_provider' );

/**
 * Search Zefix through the configured server-side provider.
 *
 * @param string $query Company name or UID.
 * @return array<int,array<string,mixed>>|WP_Error
 */
function deltora_consulting_search_companies( $query ) {
	$capabilities = deltora_consulting_get_company_lookup_capabilities();
	if ( ! $capabilities['enabled'] ) {
		return new WP_Error( 'company_lookup_disabled', deltora_consulting_t( 'La ricerca automatica non è ancora disponibile.', 'configurator' ) );
	}

	$provider = apply_filters( 'deltora_company_lookup_provider', null );
	$result   = is_callable( $provider ) ? call_user_func( $provider, $query ) : null;

	if ( is_wp_error( $result ) ) {
		return $result;
	}

	return is_array( $result )
		? $result
		: new WP_Error( 'company_lookup_response', deltora_consulting_t( 'La ricerca automatica non ha restituito una risposta valida.', 'configurator' ) );
}

/**
 * Retrieve one company through the configured server-side detail provider.
 *
 * @param string|int $identifier UID or EHRA-ID.
 * @param string     $type       Identifier type: `uid` or `ehraid`.
 * @return array<string,mixed>|WP_Error
 */
function deltora_consulting_get_company_details( $identifier, $type = 'ehraid' ) {
	$capabilities = deltora_consulting_get_company_lookup_capabilities();
	if ( ! $capabilities['enabled'] ) {
		return new WP_Error( 'company_lookup_disabled', deltora_consulting_t( 'La ricerca automatica non è ancora disponibile.', 'configurator' ) );
	}

	$provider = apply_filters( 'deltora_company_detail_provider', null );
	$result   = is_callable( $provider ) ? call_user_func( $provider, $identifier, $type ) : null;

	if ( is_wp_error( $result ) ) {
		return $result;
	}

	return is_array( $result )
		? $result
		: new WP_Error( 'company_lookup_response', deltora_consulting_t( 'I dati aziendali non sono disponibili.', 'configurator' ) );
}
