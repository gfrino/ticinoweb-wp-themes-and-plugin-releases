<?php
/**
 * One-time, conservative maintenance for approved site copy.
 *
 * @package DeltoraConsultingChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Remove or replace the approved redundant About-page passages.
 *
 * @param string $content Existing page content.
 * @return string
 */
function deltora_consulting_refresh_about_copy( $content ) {
	$content = preg_replace(
		'#<p class="deltora-about-statement">\s*Fondata dal Dott\. Paolo Della Giovanna, Deltora unisce esperienza professionale, competenze multidisciplinari e una conoscenza consolidata del contesto svizzero e italiano\.\s*</p>#u',
		'',
		(string) $content
	);

	$replacements = array(
		'Competenze che lavorano insieme.' => 'Una rete costruita attorno all’incarico.',
		'Deltora collabora con specialisti in ambito legale, revisione contabile e gestione delle risorse umane. Questa rete consente di coordinare competenze complementari e offrire all’impresa un supporto integrato, mantenendo un unico filo conduttore nelle decisioni.' => 'Quando un incarico richiede competenze complementari, Deltora coinvolge specialisti dedicati mantenendo continuità e chiarezza nel rapporto con l’impresa.',
		'Deltora collabora con specialisti in ambito legale, revisione contabile e gestione delle risorse umane. La rete permette di attivare competenze complementari secondo le esigenze dell’incarico, mantenendo continuità e chiarezza nel rapporto con l’impresa.' => 'Quando un incarico richiede competenze complementari, Deltora coinvolge specialisti dedicati mantenendo continuità e chiarezza nel rapporto con l’impresa.',
	);

	return str_replace( array_keys( $replacements ), array_values( $replacements ), $content );
}

/**
 * Determine whether a page is still the untouched WordPress sample page.
 *
 * @param WP_Post $post Candidate page.
 * @return bool
 */
function deltora_consulting_is_default_sample_page( WP_Post $post ) {
	return 'sample-page' === $post->post_name
		&& 'Sample Page' === $post->post_title
		&& false !== strpos( $post->post_content, "This is an example page. It's different from a blog post" );
}

/**
 * Apply the approved editorial maintenance once on the current site.
 *
 * @return void
 */
function deltora_consulting_maybe_refresh_site_content() {
	$schema_version = (int) get_option( 'deltora_content_schema_version', 0 );

	if ( 2 <= $schema_version || ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$about = get_page_by_path( 'chi-siamo' );
	if ( $about instanceof WP_Post ) {
		$updated_content = deltora_consulting_refresh_about_copy( $about->post_content );
		if ( $updated_content !== $about->post_content ) {
			wp_update_post(
				array(
					'ID'           => $about->ID,
					'post_content' => $updated_content,
				)
			);
		}
	}

	if ( 1 > $schema_version ) {
		$sample = get_page_by_path( 'sample-page', OBJECT, 'page' );
		if ( $sample instanceof WP_Post && deltora_consulting_is_default_sample_page( $sample ) ) {
			wp_update_post(
				array(
					'ID'          => $sample->ID,
					'post_status' => 'draft',
				)
			);
		}
	}

	update_option( 'deltora_content_schema_version', 2, false );
}
add_action( 'admin_init', 'deltora_consulting_maybe_refresh_site_content', 6 );
