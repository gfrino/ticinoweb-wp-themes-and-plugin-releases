<?php
/**
 * Editable Privacy policy content and presentation helpers.
 *
 * @package DeltoraConsultingChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return the default lead used when the Privacy page has no excerpt yet.
 *
 * @return string
 */
function deltora_consulting_get_default_privacy_excerpt() {
	return 'La presente informativa spiega in modo trasparente quali dati personali possono essere trattati durante l’utilizzo del sito e come vengono protetti.';
}

/**
 * Return the initial policy body stored in the native WordPress page editor.
 *
 * The setup routine only inserts this copy when the Privacy page is empty, so
 * later edits made by an administrator are never overwritten.
 *
 * @return string
 */
function deltora_consulting_get_default_privacy_content() {
	$contact = deltora_consulting_get_contact_details();
	$email   = sanitize_email( $contact['email'] );
	$phone   = preg_replace( '/[^0-9+]/', '', $contact['phone'] );

	return sprintf(
		'<section id="titolare">
<h2 id="titolare">Titolare del trattamento</h2>
<p>Il titolare del trattamento dei dati personali è:</p>
<address><strong>DELTORA LEGAL &amp; TAX SA</strong><br>UID CHE-449.716.366<br>%1$s<br><a href="mailto:%2$s">%2$s</a><br><a href="tel:%3$s">%4$s</a></address>
</section>
<section id="dati">
<h2 id="dati">Dati che possono essere trattati</h2>
<p>A seconda dell’utilizzo del sito, possono essere trattate le seguenti categorie di dati:</p>
<ul>
<li>dati identificativi e di contatto, come nome, azienda, indirizzo email e numero di telefono;</li>
<li>contenuto delle richieste inviate attraverso il modulo di contatto;</li>
<li>dati economici inseriti volontariamente nel configuratore, inclusi gli EBITDA dei tre esercizi, il settore selezionato e l’eventuale presenza di componenti straordinarie;</li>
<li>dati tecnici necessari al funzionamento e alla sicurezza del sito, come indirizzo IP, data e ora della richiesta, browser, dispositivo e log del server.</li>
</ul>
<p>Non vengono richiesti dati personali non necessari rispetto alle funzionalità offerte.</p>
</section>
<section id="finalita">
<h2 id="finalita">Finalità del trattamento</h2>
<p>I dati vengono trattati esclusivamente per:</p>
<ul>
<li>rispondere alle richieste e ricontattare l’utente;</li>
<li>elaborare la stima indicativa richiesta e inviarne il riepilogo via email;</li>
<li>gestire eventuali rapporti professionali o attività precontrattuali richieste dall’utente;</li>
<li>garantire sicurezza, disponibilità e corretto funzionamento del sito;</li>
<li>adempiere a obblighi legali applicabili.</li>
</ul>
<p>Eventuali comunicazioni informative vengono inviate soltanto quando l’utente manifesta separatamente il proprio consenso, revocabile in qualsiasi momento.</p>
</section>
<section id="moduli">
<h2 id="moduli">Moduli di contatto e configuratore EBITDA</h2>
<p>Quando viene inviato il modulo di contatto, i dati inseriti vengono trasmessi a Deltora per gestire la richiesta. I campi contrassegnati come obbligatori sono necessari per poter rispondere.</p>
<p>Il calcolo del configuratore EBITDA avviene durante la sessione di navigazione. Se l’utente richiede il riepilogo via email, l’indirizzo indicato e i dati della stima vengono trasmessi al server esclusivamente per preparare e inviare il messaggio richiesto.</p>
<p>I dati del calcolo non vengono conservati direttamente nel database del sito. Se l’utente decide di contattare Deltora, il riepilogo predisposto viene trasferito al modulo di contatto e inviato soltanto dopo un’azione esplicita dell’utente.</p>
</section>
<section id="cookie">
<h2 id="cookie">Cookie e dati tecnici</h2>
<p>Il sito utilizza strumenti tecnici necessari al funzionamento, alla sicurezza e alla continuità della navigazione. Una memoria temporanea del browser può essere utilizzata per trasferire all’interno della stessa sessione il riepilogo del configuratore verso il modulo di contatto.</p>
<p>Un cookie tecnico giornaliero consente di evitare il conteggio ripetuto della stessa visita nelle statistiche aggregate interne. Il cookie non contiene nome, email o dati del configuratore.</p>
<p>Al momento non è attivo un servizio di analisi web di terzi e non vengono utilizzati cookie pubblicitari. Qualora in futuro venissero introdotti strumenti non strettamente necessari, la presente informativa e le relative scelte di consenso saranno aggiornate prima della loro attivazione.</p>
</section>
<section id="destinatari">
<h2 id="destinatari">Destinatari e trasferimenti</h2>
<p>I dati sono accessibili esclusivamente alle persone autorizzate da Deltora e ai fornitori tecnici necessari al funzionamento del sito, dell’hosting e del servizio email, che operano secondo istruzioni e obblighi adeguati di riservatezza e sicurezza.</p>
<p>I dati non vengono venduti. Qualora un fornitore trattasse dati al di fuori della Svizzera, Deltora adotterà le garanzie richieste dalla normativa applicabile e ne darà conto nella presente informativa.</p>
</section>
<section id="conservazione">
<h2 id="conservazione">Tempi di conservazione</h2>
<p>I dati non vengono conservati direttamente nel database del sito oltre quanto tecnicamente necessario. Le richieste trasmesse tramite i moduli e i relativi messaggi email vengono conservati per il tempo necessario a gestire la richiesta e gli eventuali rapporti conseguenti, nel rispetto degli obblighi legali applicabili.</p>
<p>I log tecnici e di sicurezza vengono conservati per il periodo strettamente necessario alle finalità per cui sono raccolti, salvo esigenze di accertamento o obblighi di legge.</p>
</section>
<section id="diritti">
<h2 id="diritti">Diritti dell’interessato</h2>
<p>Nei limiti previsti dalla normativa applicabile, l’interessato può esercitare:</p>
<ul>
<li>il diritto di accesso ai propri dati personali e alle informazioni sul loro trattamento;</li>
<li>il diritto di rettifica dei dati inesatti o incompleti;</li>
<li>il diritto di cancellazione o distruzione dei dati quando ne ricorrono i presupposti;</li>
<li>il diritto di limitazione o opposizione al trattamento, ove applicabile;</li>
<li>il diritto di revocare in qualsiasi momento un consenso precedentemente prestato, senza pregiudicare i trattamenti già effettuati legittimamente.</li>
</ul>
<p>Le richieste possono essere inviate a <a href="mailto:%2$s">%2$s</a>. L’interessato può inoltre rivolgersi all’<a href="https://www.edoeb.admin.ch/it" rel="external">Incaricato federale della protezione dei dati e della trasparenza</a>.</p>
</section>
<section id="sicurezza">
<h2 id="sicurezza">Sicurezza e aggiornamenti</h2>
<p>Deltora adotta misure tecniche e organizzative adeguate per proteggere i dati da accessi non autorizzati, perdita, alterazione o divulgazione indebita. Nessun sistema può tuttavia garantire una sicurezza assoluta.</p>
<p>La presente informativa potrà essere aggiornata quando cambieranno le funzionalità del sito, i fornitori tecnici o la normativa applicabile. La versione corrente sarà sempre pubblicata in questa pagina con la relativa data di aggiornamento.</p>
</section>',
		esc_html( $contact['address'] ),
		esc_attr( $email ),
		esc_attr( $phone ),
		esc_html( $contact['phone'] )
	);
}

/**
 * Ensure every editable level-two heading has a stable unique anchor.
 *
 * @param string $content Filtered WordPress page content.
 * @return string
 */
function deltora_consulting_prepare_privacy_content( $content ) {
	$used_ids = array();

	return (string) preg_replace_callback(
		'/<h2\b([^>]*)>(.*?)<\/h2>/is',
		static function ( $matches ) use ( &$used_ids ) {
			$attributes = $matches[1];
			$heading    = $matches[2];
			$id         = '';

			if ( preg_match( '/\bid=["\']([^"\']+)["\']/i', $attributes, $id_match ) ) {
				$id = sanitize_title( $id_match[1] );
			}

			if ( '' === $id ) {
				$id = sanitize_title( wp_strip_all_tags( $heading ) );
			}

			$id = $id ?: 'sezione';
			$base_id = $id;
			$suffix  = 2;

			while ( isset( $used_ids[ $id ] ) ) {
				$id = $base_id . '-' . $suffix;
				++$suffix;
			}

			$used_ids[ $id ] = true;
			$attributes      = preg_replace( '/\s+id=["\'][^"\']+["\']/i', '', $attributes );

			return '<h2 id="' . esc_attr( $id ) . '"' . $attributes . '>' . $heading . '</h2>';
		},
		$content
	);
}

/**
 * Build the page index from headings authored in the WordPress editor.
 *
 * @param string $content Prepared Privacy page content.
 * @return array<int,array{id:string,label:string}>
 */
function deltora_consulting_get_privacy_sections( $content ) {
	$sections = array();

	if ( preg_match_all( '/<h2\b[^>]*\bid=["\']([^"\']+)["\'][^>]*>(.*?)<\/h2>/is', $content, $matches, PREG_SET_ORDER ) ) {
		foreach ( $matches as $match ) {
			$sections[] = array(
				'id'    => sanitize_title( $match[1] ),
				'label' => trim( wp_strip_all_tags( $match[2] ) ),
			);
		}
	}

	return $sections;
}

/**
 * Expose the excerpt panel for pages so the Privacy hero lead is editable.
 *
 * @return void
 */
function deltora_consulting_enable_page_excerpts() {
	add_post_type_support( 'page', 'excerpt' );
}
add_action( 'init', 'deltora_consulting_enable_page_excerpts' );
