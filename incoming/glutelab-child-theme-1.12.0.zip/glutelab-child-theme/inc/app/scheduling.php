<?php
/** Pure scheduling helpers. @package GluteLabChildTheme */
if ( ! defined( 'ABSPATH' ) ) exit;

function glutelab_app_timezone() {
	try { return new DateTimeZone( function_exists( 'wp_timezone_string' ) ? wp_timezone_string() : 'Europe/Zurich' ); }
	catch ( Exception $e ) { return new DateTimeZone( 'Europe/Zurich' ); }
}

function glutelab_app_week_of_month( DateTimeImmutable $date ) {
	$first_day = $date->setDate( (int) $date->format( 'Y' ), (int) $date->format( 'm' ), 1 );
	$leading_days = (int) $first_day->format( 'N' ) - 1;
	return intdiv( $leading_days + (int) $date->format( 'j' ) - 1, 7 ) + 1;
}

function glutelab_app_week_pattern_for_date( DateTimeImmutable $date ) {
	return 1 === glutelab_app_week_of_month( $date ) % 2 ? 'a' : 'b';
}

function glutelab_app_month_week_preview( DateTimeImmutable $month ) {
	$cursor = $month->setDate( (int) $month->format( 'Y' ), (int) $month->format( 'm' ), 1 )->setTime( 0, 0 );
	$last_day = $cursor->modify( 'last day of this month' );
	$weeks = array();
	while ( $cursor <= $last_day ) {
		$days_to_sunday = 7 - (int) $cursor->format( 'N' );
		$end = $cursor->modify( '+' . $days_to_sunday . ' days' );
		if ( $end > $last_day ) $end = $last_day;
		$weeks[] = array(
			'number' => glutelab_app_week_of_month( $cursor ),
			'pattern' => glutelab_app_week_pattern_for_date( $cursor ),
			'start' => $cursor,
			'end' => $end,
		);
		$cursor = $end->modify( '+1 day' );
	}
	return $weeks;
}

function glutelab_app_generate_slots( DateTimeImmutable $date, array $intervals, $duration_minutes, DateTimeImmutable $now, $notice_hours ) {
	$duration_minutes = max( 1, (int) $duration_minutes );
	$timezone = $date->getTimezone();
	$threshold = $now->setTimezone( $timezone )->modify( '+' . max( 0, (int) $notice_hours ) . ' hours' );
	$slots = array();
	foreach ( $intervals as $interval ) {
		$open = $interval['open'] ?? ''; $close = $interval['close'] ?? '';
		if ( ! preg_match( '/^\d{2}:\d{2}$/', $open ) || ! preg_match( '/^\d{2}:\d{2}$/', $close ) ) continue;
		$cursor = new DateTimeImmutable( $date->format( 'Y-m-d' ) . ' ' . $open, $timezone );
		$end = new DateTimeImmutable( $date->format( 'Y-m-d' ) . ' ' . $close, $timezone );
		while ( $cursor->modify( '+' . $duration_minutes . ' minutes' ) <= $end ) {
			$slot_end = $cursor->modify( '+' . $duration_minutes . ' minutes' );
			if ( $cursor >= $threshold ) $slots[] = array(
				'local' => $cursor->format( DATE_ATOM ),
				'utc' => $cursor->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' ),
				'end_utc' => $slot_end->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' ),
				'label' => $cursor->format( 'H:i' ) . '–' . $slot_end->format( 'H:i' ),
				'duration_minutes' => $duration_minutes,
			);
			$cursor = $slot_end;
		}
	}
	return $slots;
}

function glutelab_app_duration_label( $duration_minutes ) {
	$duration_minutes = max( 0, (int) $duration_minutes );
	$hours = intdiv( $duration_minutes, 60 );
	$minutes = $duration_minutes % 60;
	if ( $hours && $minutes ) return sprintf( 1 === $hours ? __( '%1$d ora e %2$d minuti', 'glutelab-child-theme' ) : __( '%1$d ore e %2$d minuti', 'glutelab-child-theme' ), $hours, $minutes );
	if ( 1 === $hours ) return __( '1 ora', 'glutelab-child-theme' );
	if ( $hours > 1 ) return sprintf( __( '%d ore', 'glutelab-child-theme' ), $hours );
	return sprintf( __( '%d minuti', 'glutelab-child-theme' ), $duration_minutes );
}

/** Return whether two half-open UTC lesson intervals overlap. */
function glutelab_app_intervals_overlap( $start_a, $end_a, $start_b, $end_b ) {
	return (string) $start_a < (string) $end_b && (string) $end_a > (string) $start_b;
}

/** Return the highest occupied seat count at any instant inside an interval. */
function glutelab_app_interval_peak_seats( array $bookings, $start_utc, $end_utc ) {
	$points = array( (string) $start_utc );
	foreach ( $bookings as $booking ) {
		$booking_start = (string) ( $booking['start_at_utc'] ?? '' ); $booking_end = (string) ( $booking['end_at_utc'] ?? '' );
		if ( ! glutelab_app_intervals_overlap( $start_utc, $end_utc, $booking_start, $booking_end ) ) continue;
		if ( $booking_start > $start_utc && $booking_start < $end_utc ) $points[] = $booking_start;
	}
	$peak = 0;
	foreach ( array_unique( $points ) as $point ) {
		$occupied = 0;
		foreach ( $bookings as $booking ) {
			if ( (string) ( $booking['start_at_utc'] ?? '' ) <= $point && (string) ( $booking['end_at_utc'] ?? '' ) > $point ) $occupied += max( 1, (int) ( $booking['seats'] ?? 1 ) );
		}
		$peak = max( $peak, $occupied );
	}
	return $peak;
}

/** Format a saved UTC lesson as local date, full interval and duration. */
function glutelab_app_booking_interval_label( $start_utc, $end_utc ) {
	if ( ! $start_utc || ! $end_utc ) return '';
	try {
		$utc = new DateTimeZone( 'UTC' ); $local = glutelab_app_timezone();
		$start = new DateTimeImmutable( (string) $start_utc, $utc );
		$end = new DateTimeImmutable( (string) $end_utc, $utc );
		$minutes = max( 0, (int) round( ( $end->getTimestamp() - $start->getTimestamp() ) / 60 ) );
		$start = $start->setTimezone( $local ); $end = $end->setTimezone( $local );
		return $start->format( 'd.m.Y · H:i' ) . '–' . $end->format( 'H:i' ) . ' · ' . glutelab_app_duration_label( $minutes );
	} catch ( Exception $error ) {
		return '';
	}
}

function glutelab_app_preferred_date_label( $preferred_date ) {
	if ( ! $preferred_date ) return '';
	try {
		$date = DateTimeImmutable::createFromFormat( '!Y-m-d', (string) $preferred_date, glutelab_app_timezone() );
		return $date && $date->format( 'Y-m-d' ) === $preferred_date ? $date->format( 'd.m.Y' ) : '';
	} catch ( Exception $error ) {
		return '';
	}
}

function glutelab_app_upcoming_schedule_dates( $package, $now = null, $limit = 366, $require_public_enabled = true ) {
	$settings = glutelab_app_get_settings();
	if ( ( $require_public_enabled && empty( $settings['enabled'] ) ) || empty( $settings['booking_enabled'] ) || empty( $package['session_minutes'] ) ) return array();
	$tz = glutelab_app_timezone();
	$now = $now instanceof DateTimeImmutable ? $now->setTimezone( $tz ) : new DateTimeImmutable( 'now', $tz );
	$cursor = $now->setTime( 0, 0 );
	$last = $cursor->modify( '+' . (int) $settings['booking_horizon_days'] . ' days' );
	$dates = array();
	while ( $cursor <= $last && count( $dates ) < max( 1, (int) $limit ) ) {
		$value = $cursor->format( 'Y-m-d' );
		if ( ! in_array( $value, $settings['closure_dates'], true ) ) {
			$pattern = glutelab_app_week_pattern_for_date( $cursor );
			$day = strtolower( $cursor->format( 'l' ) );
			$slots = glutelab_app_generate_slots( $cursor, $settings['weekly_patterns'][ $pattern ][ $day ] ?? array(), (int) $package['session_minutes'], $now, $settings['min_notice_hours'] );
			if ( $slots ) $dates[] = array( 'value' => $value, 'pattern' => $pattern );
		}
		$cursor = $cursor->modify( '+1 day' );
	}
	return $dates;
}

/**
 * Return upcoming dates that have an A/B availability window, independently
 * from an offer duration. This lets the public form present the day first and
 * explain precisely when only the package duration is still missing.
 */
function glutelab_app_upcoming_open_dates( $now = null, $limit = 366, $require_public_enabled = true ) {
	$settings = glutelab_app_get_settings();
	if ( ( $require_public_enabled && empty( $settings['enabled'] ) ) || empty( $settings['booking_enabled'] ) ) return array();
	$tz = glutelab_app_timezone();
	$now = $now instanceof DateTimeImmutable ? $now->setTimezone( $tz ) : new DateTimeImmutable( 'now', $tz );
	$threshold = $now->modify( '+' . max( 0, (int) $settings['min_notice_hours'] ) . ' hours' );
	$cursor = $now->setTime( 0, 0 );
	$last = $cursor->modify( '+' . (int) $settings['booking_horizon_days'] . ' days' );
	$dates = array();
	while ( $cursor <= $last && count( $dates ) < max( 1, (int) $limit ) ) {
		$value = $cursor->format( 'Y-m-d' );
		$pattern = glutelab_app_week_pattern_for_date( $cursor );
		$day = strtolower( $cursor->format( 'l' ) );
		$is_open = false;
		if ( ! in_array( $value, $settings['closure_dates'], true ) ) {
			foreach ( $settings['weekly_patterns'][ $pattern ][ $day ] ?? array() as $interval ) {
				$open = $interval['open'] ?? ''; $close = $interval['close'] ?? '';
				if ( ! preg_match( '/^\d{2}:\d{2}$/', $open ) || ! preg_match( '/^\d{2}:\d{2}$/', $close ) || $open >= $close ) continue;
				$end = new DateTimeImmutable( $value . ' ' . $close, $tz );
				if ( $end > $threshold ) { $is_open = true; break; }
			}
		}
		if ( $is_open ) $dates[] = array( 'value' => $value, 'pattern' => $pattern );
		$cursor = $cursor->modify( '+1 day' );
	}
	return $dates;
}

function glutelab_app_slots_for_date( $date_string, $package, $now = null ) {
	$settings = glutelab_app_get_settings();
	if ( empty( $settings['enabled'] ) || empty( $settings['booking_enabled'] ) || empty( $package['session_minutes'] ) ) return array();
	$tz = glutelab_app_timezone();
	$date = DateTimeImmutable::createFromFormat( '!Y-m-d', sanitize_text_field( $date_string ), $tz );
	if ( ! $date || $date->format( 'Y-m-d' ) !== $date_string || in_array( $date_string, $settings['closure_dates'], true ) ) return array();
	$now = $now instanceof DateTimeImmutable ? $now : new DateTimeImmutable( 'now', $tz );
	if ( $date > $now->modify( '+' . $settings['booking_horizon_days'] . ' days' ) ) return array();
	$day = strtolower( $date->format( 'l' ) );
	$pattern = glutelab_app_week_pattern_for_date( $date );
	return glutelab_app_generate_slots( $date, $settings['weekly_patterns'][ $pattern ][ $day ] ?? array(), (int) $package['session_minutes'], $now, $settings['min_notice_hours'] );
}
