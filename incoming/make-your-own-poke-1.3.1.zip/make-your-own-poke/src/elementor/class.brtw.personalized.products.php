<?php
/**
 * Widget Elementor «Crea la tua poké» (nome tecnico brtw-personalized, lo stesso delle pagine esistenti).
 * Il markup è quello di brtw_render_configurator(): il widget sceglie categoria, quantità e ordine
 * e regola i colori tramite le variabili --brtw-* del CSS del plugin.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use Elementor\Controls_Manager;

class Brtw_Personalized_Products extends \Elementor\Widget_Base {

    public function get_name() {
        return 'brtw-personalized';
    }

    public function get_title() {
        return __( 'Crea la tua poké', 'ticinoweb' );
    }

    public function get_icon() {
        return 'brtw-icon-som';
    }

    public function get_categories() {
        return array( 'brtw' );
    }

    public function get_keywords() {
        return array( 'poke', 'pokè', 'configuratore', 'woocommerce', 'add-ons' );
    }

    public function get_style_depends() {
        return array( 'brtw-utilities-base' );
    }

    public function get_script_depends() {
        return array( 'brtw-frontend' );
    }

    protected function register_controls() {
        $categories = array();
        if ( class_exists( 'WooCommerce' ) ) {
            foreach ( brtw_get_terms( 'product_cat', 0 ) as $term ) {
                $categories[ $term->slug ] = $term->name;
            }
        }
        $defaults = brtw_configurator_default_args();

        $this->start_controls_section( 'brtw_product_list_query_section', array(
            'label' => __( 'Misure', 'ticinoweb' ),
        ) );

        $this->add_control( 'brtw_taxonomy', array(
            'label'       => __( 'Categoria dei prodotti', 'ticinoweb' ),
            'description' => __( 'I prodotti di questa categoria sono le misure tra cui il cliente sceglie.', 'ticinoweb' ),
            'type'        => Controls_Manager::SELECT,
            'options'     => $categories,
            'default'     => isset( $categories[ $defaults['categoria'] ] ) ? $defaults['categoria'] : '',
        ) );

        $this->add_control( 'brtw_per_page', array(
            'label'   => __( 'Quante misure mostrare', 'ticinoweb' ),
            'type'    => Controls_Manager::NUMBER,
            'min'     => 1,
            'max'     => 20,
            'step'    => 1,
            'default' => (int) $defaults['per_pagina'],
        ) );

        $this->add_control( 'brtw_orderby', array(
            'label'   => __( 'Ordina per', 'ticinoweb' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'price',
            'options' => array(
                'price'      => __( 'Prezzo', 'ticinoweb' ),
                'title'      => __( 'Nome', 'ticinoweb' ),
                'menu_order' => __( 'Ordine del menu', 'ticinoweb' ),
                'date'       => __( 'Data', 'ticinoweb' ),
            ),
        ) );

        $this->add_control( 'brtw_order', array(
            'label'   => __( 'Verso', 'ticinoweb' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'ASC',
            'options' => array(
                'ASC'  => __( 'Crescente', 'ticinoweb' ),
                'DESC' => __( 'Decrescente', 'ticinoweb' ),
            ),
        ) );

        $this->end_controls_section();

        $this->start_controls_section( 'brtw_style_section', array(
            'label' => __( 'Colori', 'ticinoweb' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ) );

        $this->add_control( 'brtw_accent', array(
            'label'     => __( 'Colore principale (misura scelta, spunte, bottone)', 'ticinoweb' ),
            'type'      => Controls_Manager::COLOR,
            'selectors' => array( '{{WRAPPER}} .brtw-configurator' => '--brtw-accent: {{VALUE}};' ),
        ) );
        $this->add_control( 'brtw_accent_ink', array(
            'label'     => __( 'Testo sul bottone', 'ticinoweb' ),
            'type'      => Controls_Manager::COLOR,
            'selectors' => array( '{{WRAPPER}} .brtw-configurator' => '--brtw-accent-ink: {{VALUE}};' ),
        ) );
        $this->add_control( 'brtw_surface_selected', array(
            'label'     => __( 'Fondo della misura scelta', 'ticinoweb' ),
            'type'      => Controls_Manager::COLOR,
            'selectors' => array( '{{WRAPPER}} .brtw-configurator' => '--brtw-surface-selected: {{VALUE}};' ),
        ) );
        $this->add_control( 'brtw_line', array(
            'label'     => __( 'Bordi', 'ticinoweb' ),
            'type'      => Controls_Manager::COLOR,
            'selectors' => array( '{{WRAPPER}} .brtw-configurator' => '--brtw-line: {{VALUE}};' ),
        ) );
        $this->add_control( 'brtw_muted', array(
            'label'     => __( 'Testi secondari', 'ticinoweb' ),
            'type'      => Controls_Manager::COLOR,
            'selectors' => array( '{{WRAPPER}} .brtw-configurator' => '--brtw-muted: {{VALUE}};' ),
        ) );
        $this->add_control( 'brtw_radius', array(
            'label'      => __( 'Angoli arrotondati', 'ticinoweb' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => array( 'px' ),
            'range'      => array( 'px' => array( 'min' => 0, 'max' => 32 ) ),
            'selectors'  => array( '{{WRAPPER}} .brtw-configurator' => '--brtw-radius: {{SIZE}}{{UNIT}};' ),
        ) );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $defaults = brtw_configurator_default_args();

        echo brtw_render_configurator( array( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escapato nella funzione
            'categoria'  => ! empty( $settings['brtw_taxonomy'] ) ? sanitize_title( $settings['brtw_taxonomy'] ) : $defaults['categoria'],
            'per_pagina' => ! empty( $settings['brtw_per_page'] ) ? (int) $settings['brtw_per_page'] : $defaults['per_pagina'],
            'orderby'    => ! empty( $settings['brtw_orderby'] ) ? sanitize_key( $settings['brtw_orderby'] ) : $defaults['orderby'],
            'order'      => ! empty( $settings['brtw_order'] ) ? strtoupper( sanitize_key( $settings['brtw_order'] ) ) : $defaults['order'],
        ) );
    }
}
