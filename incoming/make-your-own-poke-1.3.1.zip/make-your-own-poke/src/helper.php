<?php
/**
 * Make your own Pokè: regole di prezzo lato server.
 *
 * I prodotti del configuratore (categorie in brtw_settings['categorie']) hanno gruppi di
 * Product Add-ons; i primi N ingredienti di ogni gruppo sono inclusi nel prezzo, gli altri si pagano.
 * N si legge dal secondo numero della descrizione del gruppo («Minimo 1, dopo 2 si paga un extra» → 2),
 * salvo le eccezioni impostate in Impostazioni → Make your own Pokè o imposte dal filtro brtw_included_count.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* -------------------------------------------------------------------------
 * Impostazioni
 * ---------------------------------------------------------------------- */

/** Impostazioni di default del plugin. */
function brtw_default_settings() {
    return array(
        'categorie' => array( 'crea-la-tua-poke' ), // slug delle categorie prodotto del configuratore
        'inclusi'   => array(),                      // «nome gruppo (minuscolo)» → numero di inclusi, vince sulla descrizione
        'porzioni'  => array( 'proteine' => 2 ),     // «nome gruppo (minuscolo)» → porzioni massime dello stesso ingrediente (1 = niente +/−)
    );
}

/** Impostazioni del plugin (opzione brtw_settings) unite ai default. */
function brtw_settings() {
    $saved = get_option( 'brtw_settings', array() );
    if ( ! is_array( $saved ) ) {
        $saved = array();
    }
    $settings = array_merge( brtw_default_settings(), $saved );
    if ( empty( $settings['categorie'] ) || ! is_array( $settings['categorie'] ) ) {
        $settings['categorie'] = brtw_default_settings()['categorie'];
    }
    if ( ! is_array( $settings['inclusi'] ) ) {
        $settings['inclusi'] = array();
    }
    if ( ! is_array( $settings['porzioni'] ) ) {
        $settings['porzioni'] = brtw_default_settings()['porzioni'];
    }
    return $settings;
}

/**
 * Slug delle categorie prodotto che il configuratore gestisce.
 * Filtro brtw_configurator_categories per aggiungerne o toglierne da tema o altri plugin.
 */
function brtw_configurator_categories() {
    $slugs = array_values( array_filter( array_map( 'sanitize_title', (array) brtw_settings()['categorie'] ) ) );
    $slugs = apply_filters( 'brtw_configurator_categories', $slugs );
    return array_values( array_unique( array_filter( array_map( 'sanitize_title', (array) $slugs ) ) ) );
}

/** True se il prodotto (o il padre della variazione) sta in una categoria del configuratore. */
function brtw_is_configurator_product( $product_id ) {
    static $cache = array();
    $product_id = (int) $product_id;
    if ( ! $product_id ) {
        return false;
    }
    if ( ! isset( $cache[ $product_id ] ) ) {
        $parent_id = (int) wp_get_post_parent_id( $product_id );
        $check_id  = $parent_id ? $parent_id : $product_id;
        $slugs     = brtw_configurator_categories();
        $cache[ $product_id ] = $slugs ? has_term( $slugs, 'product_cat', $check_id ) : false;
    }
    return $cache[ $product_id ];
}

/* -------------------------------------------------------------------------
 * Inclusi nel prezzo
 * ---------------------------------------------------------------------- */

/** Chiave normalizzata del nome di un gruppo (per la mappa delle eccezioni). */
function brtw_group_key( $name ) {
    $name = trim( wp_strip_all_tags( (string) $name ) );
    return function_exists( 'mb_strtolower' ) ? mb_strtolower( $name, 'UTF-8' ) : strtolower( $name );
}

/**
 * Numero di inclusi letto dalla descrizione di un gruppo: il secondo numero
 * («Minimo 1, dopo 2 si paga un extra» → 2); se c'è un numero solo, quello; altrimenti 0.
 */
function brtw_included_from_description( $description ) {
    $description = wp_strip_all_tags( (string) $description );
    if ( ! preg_match_all( '/\d+/', $description, $matches ) || empty( $matches[0] ) ) {
        return 0;
    }
    return isset( $matches[0][1] ) ? (int) $matches[0][1] : (int) $matches[0][0];
}

/**
 * Quanti ingredienti del gruppo sono inclusi nel prezzo del prodotto.
 *
 * Ordine: 1) eccezione impostata in admin per nome del gruppo, 2) secondo numero della descrizione.
 * Il filtro brtw_included_count( $count, $addon, $product_id ) permette eccezioni dal tema.
 *
 * @param array $addon_group Gruppo come lo restituisce WC_Product_Addons_Helper::get_product_addons().
 * @param int   $product_id  Prodotto (misura) a cui il gruppo è applicato.
 * @return int
 */
function brtw_included_count( $addon_group, $product_id ) {
    $addon_group = is_array( $addon_group ) ? $addon_group : array();
    $settings    = brtw_settings();
    $key         = brtw_group_key( isset( $addon_group['name'] ) ? $addon_group['name'] : '' );
    $count       = null;

    if ( $key !== '' && isset( $settings['inclusi'][ $key ] ) && $settings['inclusi'][ $key ] !== '' ) {
        $count = max( 0, (int) $settings['inclusi'][ $key ] );
    }
    if ( $count === null ) {
        $count = brtw_included_from_description( isset( $addon_group['description'] ) ? $addon_group['description'] : '' );
    }

    return max( 0, (int) apply_filters( 'brtw_included_count', $count, $addon_group, (int) $product_id ) );
}

/**
 * Quante porzioni dello stesso ingrediente si possono prendere nel gruppo (es. Proteine: salmone ×2).
 * 1 = una sola, come una casella normale. Impostazione per nome del gruppo, filtro brtw_max_portions.
 */
function brtw_max_portions( $addon_group, $product_id ) {
    $addon_group = is_array( $addon_group ) ? $addon_group : array();
    $settings    = brtw_settings();
    $key         = brtw_group_key( isset( $addon_group['name'] ) ? $addon_group['name'] : '' );
    $count       = ( $key !== '' && isset( $settings['porzioni'][ $key ] ) ) ? (int) $settings['porzioni'][ $key ] : 1;
    // Solo le caselle possono ripetere un ingrediente; massimo 5 per non fare righe infinite.
    if ( isset( $addon_group['type'] ) && 'checkbox' !== $addon_group['type'] ) {
        $count = 1;
    }
    return min( 5, max( 1, (int) apply_filters( 'brtw_max_portions', $count, $addon_group, (int) $product_id ) ) );
}

/** Nome della porzione in più nel carrello e sullo scontrino: «Salmone – 2ª porzione». */
function brtw_portion_label( $label, $number ) {
    /* translators: 1: ingrediente, 2: numero della porzione (2, 3…) */
    return sprintf( __( '%1$s – %2$dª porzione', 'ticinoweb' ), $label, (int) $number );
}

/**
 * Testo «2 incluse» / «1 incluso» accordato (alla buona) al nome del gruppo:
 * nomi che finiscono in -e o -a (Proteine, Base, Salse) al femminile, gli altri al maschile.
 */
function brtw_included_label( $count, $group_name ) {
    $count    = (int) $count;
    $name     = brtw_group_key( $group_name );
    $last     = function_exists( 'mb_substr' ) ? mb_substr( $name, -1, 1, 'UTF-8' ) : substr( $name, -1 );
    $feminine = in_array( $last, array( 'e', 'a' ), true );
    if ( $count === 1 ) {
        /* translators: %d: numero (1) */
        $text = $feminine ? __( '%d inclusa', 'ticinoweb' ) : __( '%d incluso', 'ticinoweb' );
    } else {
        /* translators: %d: numero */
        $text = $feminine ? __( '%d incluse', 'ticinoweb' ) : __( '%d inclusi', 'ticinoweb' );
    }
    return sprintf( $text, $count );
}

/**
 * Opzione «nessuno» del gruppo («Senza proteine», «Senza topping»…): è gratis, non occupa
 * un incluso ed esclude le altre opzioni del gruppo. Si riconosce dal nome; filtro brtw_is_none_option.
 */
function brtw_is_none_option( $label ) {
    $label = trim( wp_strip_all_tags( (string) $label ) );
    $none  = (bool) preg_match( '/^(senza|nessun[oa]?|niente|without|no|ohne|kein[e]?|sans|aucun[e]?)(\s|$)/iu', $label );
    return (bool) apply_filters( 'brtw_is_none_option', $none, $label );
}

/** Prezzo dell'extra di un gruppo: il prezzo della prima opzione vera, non «Senza …» (float, 0 se gratis). */
function brtw_addon_extra_price( $addon_group ) {
    if ( empty( $addon_group['options'] ) || ! is_array( $addon_group['options'] ) ) {
        return 0.0;
    }
    foreach ( $addon_group['options'] as $option ) {
        if ( brtw_is_none_option( isset( $option['label'] ) ? $option['label'] : '' ) ) {
            continue;
        }
        return isset( $option['price'] ) && $option['price'] !== '' ? (float) $option['price'] : 0.0;
    }
    return 0.0;
}

/**
 * Valore che il modulo invia per un'opzione: lo stesso che Product Add-ons si aspetta
 * (checkbox e scelta singola a pulsanti: slug dell'etichetta; menu a tendina: «slug-N»).
 */
function brtw_option_value( $addon_group, $index, $option ) {
    $label = isset( $option['label'] ) ? (string) $option['label'] : '';
    $type  = isset( $addon_group['type'] ) ? $addon_group['type'] : 'checkbox';
    if ( 'multiple_choice' === $type && isset( $addon_group['display'] ) && in_array( $addon_group['display'], array( 'select', 'images' ), true ) ) {
        return sanitize_title( $label ) . '-' . ( (int) $index + 1 );
    }
    return sanitize_title( $label );
}

/**
 * I gruppi di Product Add-ons di un prodotto che il configuratore sa mostrare
 * (caselle e scelta singola con opzioni), con le regole già calcolate:
 * brtw_included, brtw_extra, brtw_min, brtw_max, brtw_input_name, brtw_multiple.
 *
 * @return array[] indicizzati per field_name (es. «1081-1716043068»).
 */
function brtw_product_addon_groups( $product_id ) {
    static $cache = array();
    $product_id = (int) $product_id;
    if ( isset( $cache[ $product_id ] ) ) {
        return $cache[ $product_id ];
    }
    $groups = array();
    if ( $product_id && class_exists( 'WC_Product_Addons_Helper' ) ) {
        $addons = WC_Product_Addons_Helper::get_product_addons( $product_id );
        foreach ( (array) $addons as $addon ) {
            if ( ! is_array( $addon ) || empty( $addon['options'] ) || ! is_array( $addon['options'] ) ) {
                continue;
            }
            $type = isset( $addon['type'] ) ? $addon['type'] : '';
            if ( ! in_array( $type, array( 'checkbox', 'multiple_choice' ), true ) || empty( $addon['field_name'] ) ) {
                continue;
            }
            // Opzioni nascoste dal commerciante (visibility 0) non si mostrano.
            $options = array();
            foreach ( $addon['options'] as $index => $option ) {
                if ( isset( $option['visibility'] ) && 0 === (int) $option['visibility'] ) {
                    continue;
                }
                $options[ $index ] = $option;
            }
            if ( ! $options ) {
                continue;
            }
            $addon['options']        = $options;
            $required                = WC_Product_Addons_Helper::is_addon_required( $addon );
            $restrictions            = ! empty( $addon['restrictions'] );
            $addon['brtw_multiple']  = ( 'checkbox' === $type );
            $addon['brtw_included']  = brtw_included_count( $addon, $product_id );
            $addon['brtw_portions']  = brtw_max_portions( $addon, $product_id );
            $addon['brtw_extra']     = brtw_addon_extra_price( $addon );
            $addon['brtw_min']       = $restrictions && isset( $addon['min'] ) && $addon['min'] !== '' ? max( 0, (int) $addon['min'] ) : 0;
            $addon['brtw_max']       = $restrictions && isset( $addon['max'] ) && $addon['max'] !== '' ? max( 0, (int) $addon['max'] ) : 0;
            if ( $required && $addon['brtw_min'] < 1 ) {
                $addon['brtw_min'] = 1;
            }
            if ( ! $addon['brtw_multiple'] ) {
                $addon['brtw_max'] = 1;
            }
            $addon['brtw_input_name'] = 'addon-' . sanitize_title( $addon['field_name'] ) . ( $addon['brtw_multiple'] ? '[]' : '' );
            $groups[ (string) $addon['field_name'] ] = $addon;
        }
    }
    $cache[ $product_id ] = $groups;
    return $groups;
}

/* -------------------------------------------------------------------------
 * Carrello: ordine delle scelte e sconto degli inclusi
 * ---------------------------------------------------------------------- */

/**
 * Costo unitario di un add-on nel carrello, con le stesse regole di Product Add-ons:
 * per quantità → prezzo per pezzo; tariffa fissa → prezzo diviso la quantità; percentuale → sul prezzo base.
 */
function brtw_addon_unit_cost( $addon, $base_price, $quantity ) {
    $price = isset( $addon['price'] ) ? (float) $addon['price'] : 0.0;
    $type  = isset( $addon['price_type'] ) ? $addon['price_type'] : 'quantity_based';
    switch ( $type ) {
        case 'percentage_based':
            return (float) $base_price * ( $price / 100 );
        case 'flat_fee':
            return $quantity > 0 ? $price / $quantity : 0.0;
        default:
            return $price;
    }
}

/**
 * Mette gli add-on appena aggiunti al carrello nell'ordine in cui il cliente li ha scelti
 * (il modulo li invia in quell'ordine): così «i primi N inclusi» sono i primi che ha cliccato.
 * Product Add-ons li salva nell'ordine delle opzioni del gruppo e tiene una riga per ingrediente:
 * qui si rimettono in fila e, nei gruppi con le porzioni (es. Proteine), ogni porzione in più
 * diventa una riga sua («Salmone – 2ª porzione») con il suo prezzo. Il modulo la invia ripetendo il valore.
 */
function brtw_order_addons_as_chosen( $cart_item_data, $product_id ) {
    if ( empty( $cart_item_data['addons'] ) || ! is_array( $cart_item_data['addons'] ) || ! brtw_is_configurator_product( $product_id ) ) {
        return $cart_item_data;
    }
    // Lettura dei campi che WooCommerce ha appena ricevuto per aggiungere al carrello (azione pubblica, nessuna scrittura).
    // phpcs:ignore WordPress.Security.NonceVerification.Missing
    $posted     = wp_unslash( $_POST );
    $add_groups = brtw_product_addon_groups( (int) $product_id );

    // Le righe di Product Add-ons per gruppo, nell'ordine dei gruppi.
    $by_field = array();
    foreach ( $cart_item_data['addons'] as $addon ) {
        $field = isset( $addon['field_name'] ) ? (string) $addon['field_name'] : '';
        $by_field[ $field ][] = $addon;
    }

    $ordered = array();
    foreach ( $by_field as $field => $rows ) {
        // «Senza …» è gratis ed esclude il resto: se arriva insieme ad altri ingredienti, vale solo il resto.
        $real = array();
        foreach ( $rows as $r => $row ) {
            if ( brtw_is_none_option( isset( $row['value'] ) ? $row['value'] : '' ) ) {
                $rows[ $r ]['price'] = 0;
            } else {
                $real[] = $row;
            }
        }
        if ( $real && count( $real ) < count( $rows ) ) {
            $rows = $real;
        }
        $rows = array_values( $rows );
        $values   = isset( $posted[ 'addon-' . $field ] ) ? (array) $posted[ 'addon-' . $field ] : array();
        $values   = array_values( array_map( 'sanitize_title', array_map( 'sanitize_text_field', $values ) ) );
        $portions = isset( $add_groups[ $field ]['brtw_portions'] ) ? (int) $add_groups[ $field ]['brtw_portions'] : 1;
        $used     = array_fill( 0, count( $rows ), 0 ); // porzioni già messe in fila per ogni riga

        foreach ( $values as $value ) {
            foreach ( $rows as $r => $row ) {
                $slug = sanitize_title( isset( $row['value'] ) ? $row['value'] : '' );
                // Stesso ingrediente: slug identico, o «slug-N» dei menu a tendina (mai «salmone» per «salmone-spicy»).
                if ( $value !== $slug && ! preg_match( '/^' . preg_quote( $slug, '/' ) . '-\d+$/', $value ) ) {
                    continue;
                }
                if ( 0 === $used[ $r ] ) {
                    $ordered[] = $row;
                } elseif ( $used[ $r ] < $portions ) {
                    $extra          = $row;
                    $extra['value'] = brtw_portion_label( $row['value'], $used[ $r ] + 1 );
                    $ordered[]      = $extra;
                } else {
                    break; // oltre il massimo di porzioni: si ignora
                }
                $used[ $r ]++;
                break;
            }
        }
        // Righe che il modulo non ha elencato (invio senza script): in coda, come le dà Product Add-ons.
        foreach ( $rows as $r => $row ) {
            if ( 0 === $used[ $r ] ) {
                $ordered[] = $row;
            }
        }
    }
    $cart_item_data['addons'] = $ordered;
    return $cart_item_data;
}
add_filter( 'woocommerce_add_cart_item_data', 'brtw_order_addons_as_chosen', 20, 2 );

/**
 * Sconto unitario degli inclusi e totale unitario degli add-on di una riga del carrello.
 *
 * @return array ['discount' => float, 'addons_total' => float]
 */
function brtw_cart_item_addon_totals( $cart_item, $base_price ) {
    $result   = array( 'discount' => 0.0, 'addons_total' => 0.0 );
    $quantity = isset( $cart_item['quantity'] ) ? max( 1, (int) $cart_item['quantity'] ) : 1;
    $groups   = brtw_product_addon_groups( (int) $cart_item['product_id'] );
    $seen     = array();
    foreach ( (array) $cart_item['addons'] as $addon ) {
        if ( ! is_array( $addon ) ) {
            continue;
        }
        $field = isset( $addon['field_name'] ) ? (string) $addon['field_name'] : '';
        $unit  = brtw_addon_unit_cost( $addon, $base_price, $quantity );
        $result['addons_total'] += $unit;
        if ( ! isset( $groups[ $field ] ) ) {
            continue; // gruppo che il configuratore non gestisce: si paga come dice Product Add-ons
        }
        if ( brtw_is_none_option( isset( $addon['value'] ) ? $addon['value'] : '' ) ) {
            $result['discount'] += $unit; // «Senza …»: gratis e non occupa un incluso
            continue;
        }
        $seen[ $field ] = isset( $seen[ $field ] ) ? $seen[ $field ] + 1 : 1;
        if ( $seen[ $field ] <= (int) $groups[ $field ]['brtw_included'] ) {
            $result['discount'] += $unit;
        }
    }
    return $result;
}

/**
 * Applica lo sconto degli inclusi alle righe del carrello con prodotti del configuratore.
 * Il prezzo si ricalcola da zero (base + add-on − inclusi), quindi può girare più volte senza sommarsi.
 */
function brtw_apply_included_discount( $cart ) {
    if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
        return;
    }
    if ( ! is_object( $cart ) || ! method_exists( $cart, 'get_cart' ) ) {
        return;
    }
    static $done = array();
    foreach ( $cart->get_cart() as $key => $cart_item ) {
        if ( empty( $cart_item['addons'] ) || empty( $cart_item['product_id'] ) || ! brtw_is_configurator_product( $cart_item['product_id'] ) ) {
            continue;
        }
        if ( ! isset( $cart_item['data'] ) || ! is_object( $cart_item['data'] ) ) {
            continue;
        }
        if ( isset( $cart_item['addons_price_before_calc'] ) ) {
            // Product Add-ons ha salvato il prezzo base: si ricalcola tutto, in modo idempotente.
            $base   = (float) $cart_item['addons_price_before_calc'];
            $totals = brtw_cart_item_addon_totals( $cart_item, $base );
            $price  = $base + $totals['addons_total'] - $totals['discount'];
        } else {
            // Versioni vecchie di Product Add-ons: una sola sottrazione per richiesta.
            if ( isset( $done[ $key ] ) ) {
                continue;
            }
            $done[ $key ] = true;
            $current = (float) $cart_item['data']->get_price( 'edit' );
            $totals  = brtw_cart_item_addon_totals( $cart_item, $current );
            $price   = $current - $totals['discount'];
        }
        if ( $totals['discount'] > 0 ) {
            $cart_item['data']->set_price( max( 0, round( $price, wc_get_price_decimals() ) ) );
        }
    }
}
add_action( 'woocommerce_before_calculate_totals', 'brtw_apply_included_discount', 20 );

/* -------------------------------------------------------------------------
 * Dati per lo script
 * ---------------------------------------------------------------------- */

/**
 * Testo che finisce in un attributo o nello script (dove il traduttore della pagina non arriva):
 * passa dal livello di traduzione di ticinoWEB CMS o di tW Translate se ci sono, altrimenti resta com'è.
 */
function brtw_text( $text, $context ) {
    if ( function_exists( 'ticinoweb_frontend_text' ) ) {
        return ticinoweb_frontend_text( $text, 'brtw:' . $context );
    }
    return $text;
}

/** Indirizzo del carrello nella lingua della pagina (con tW Translate il prefisso della lingua). */
function brtw_cart_url() {
    if ( ! function_exists( 'wc_get_cart_url' ) ) {
        return '';
    }
    $url = wc_get_cart_url();
    if ( function_exists( 'ticinoweb_frontend_url' ) ) {
        return ticinoweb_frontend_url( $url, 'brtw:url:cart' );
    }
    return $url;
}

/** Impostazioni passate a frontend.js: endpoint, formato del prezzo e testi (traducibili). */
function brtw_frontend_settings() {
    $has_wc = function_exists( 'WC' ) && class_exists( 'WC_AJAX' );
    return array(
        'ajaxUrl'   => $has_wc ? WC_AJAX::get_endpoint( 'add_to_cart' ) : '',
        'cartUrl'   => brtw_cart_url(),
        'redirect'  => 'yes' === get_option( 'woocommerce_cart_redirect_after_add', 'no' ),
        'currency'  => array(
            'symbol'   => $has_wc ? html_entity_decode( get_woocommerce_currency_symbol(), ENT_QUOTES, 'UTF-8' ) : 'CHF',
            'position' => get_option( 'woocommerce_currency_pos', 'left_space' ),
            'decimals' => $has_wc ? wc_get_price_decimals() : 2,
            'decimal'  => $has_wc ? wc_get_price_decimal_separator() : '.',
            'thousand' => $has_wc ? wc_get_price_thousand_separator() : '\'',
        ),
        'i18n'      => array(
            /* translators: 1: numero minimo, 2: nome del gruppo */
            'chooseAtLeast' => __( 'Scegli almeno %1$s in «%2$s».', 'ticinoweb' ),
            /* translators: 1: numero massimo, 2: nome del gruppo */
            'maxReached'    => __( 'Puoi scegliere al massimo %1$s in «%2$s».', 'ticinoweb' ),
            'adding'        => __( 'Aggiungo al carrello…', 'ticinoweb' ),
            'added'         => __( 'Aggiunto al carrello.', 'ticinoweb' ),
            'viewCart'      => __( 'Vai al carrello', 'ticinoweb' ),
            'error'         => __( 'Non è stato possibile aggiungere il piatto al carrello. Controlla le scelte e riprova.', 'ticinoweb' ),
            'openProduct'   => __( 'Apri la scheda del prodotto', 'ticinoweb' ),
            'extra'         => __( 'extra', 'ticinoweb' ),
            /* translators: 1: numero di porzioni, 2: ingrediente */
            'portionsOf'    => __( '%1$s porzioni di %2$s', 'ticinoweb' ),
            /* translators: %s: ingrediente */
            'portionOne'    => __( '1 porzione di %s', 'ticinoweb' ),
        ),
    );
}

/* -------------------------------------------------------------------------
 * Utilità
 * ---------------------------------------------------------------------- */

/** Termini di una tassonomia (usato dal widget Elementor per l'elenco delle categorie). */
function brtw_get_terms( $taxonomy, $parent_id = 0 ) {
    $terms = get_terms( array(
        'taxonomy'   => $taxonomy,
        'hide_empty' => false,
        'parent'     => (int) $parent_id,
    ) );
    return is_wp_error( $terms ) ? array() : $terms;
}
