<?php
/**
 * Make your own Pokè: Impostazioni → «Make your own Pokè».
 *
 * Due cose sole, in italiano semplice: quali categorie di prodotti sono «misure» del configuratore
 * e, per ogni gruppo di ingredienti, quanti sono inclusi nel prezzo quando la descrizione del gruppo
 * non basta (eccezione per nome del gruppo, es. TOPPING = 1).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function brtw_admin_menu() {
    add_options_page(
        __( 'Make your own Pokè', 'ticinoweb' ),
        __( 'Make your own Pokè', 'ticinoweb' ),
        'manage_options',
        'brtw-settings',
        'brtw_render_settings_page'
    );
}
add_action( 'admin_menu', 'brtw_admin_menu' );

function brtw_register_settings() {
    register_setting( 'brtw_settings_group', 'brtw_settings', array(
        'type'              => 'array',
        'sanitize_callback' => 'brtw_sanitize_settings',
        'default'           => brtw_default_settings(),
    ) );
}
add_action( 'admin_init', 'brtw_register_settings' );

/** Pulisce quello che arriva dal modulo: slug di categorie esistenti e numeri interi per le eccezioni. */
function brtw_sanitize_settings( $input ) {
    $clean = brtw_default_settings();
    $input = is_array( $input ) ? $input : array();

    $slugs = array();
    foreach ( (array) ( isset( $input['categorie'] ) ? $input['categorie'] : array() ) as $slug ) {
        $slug = sanitize_title( $slug );
        if ( $slug !== '' && term_exists( $slug, 'product_cat' ) ) {
            $slugs[] = $slug;
        }
    }
    if ( $slugs ) {
        $clean['categorie'] = array_values( array_unique( $slugs ) );
    } else {
        add_settings_error( 'brtw_settings', 'brtw_no_categories', __( 'Scegli almeno una categoria: senza, il configuratore non sa quali prodotti mostrare. È rimasta quella di prima.', 'ticinoweb' ) );
        $previous = get_option( 'brtw_settings', array() );
        if ( ! empty( $previous['categorie'] ) ) {
            $clean['categorie'] = array_values( array_map( 'sanitize_title', (array) $previous['categorie'] ) );
        }
    }

    $inclusi = array();
    $names   = isset( $input['inclusi_nome'] ) ? (array) $input['inclusi_nome'] : array();
    $values  = isset( $input['inclusi_valore'] ) ? (array) $input['inclusi_valore'] : array();
    foreach ( $names as $i => $name ) {
        $key   = brtw_group_key( sanitize_text_field( $name ) );
        $value = isset( $values[ $i ] ) ? trim( (string) $values[ $i ] ) : '';
        if ( $key === '' || $value === '' || ! is_numeric( $value ) ) {
            continue; // vuoto = vale la descrizione
        }
        $inclusi[ $key ] = max( 0, (int) $value );
    }
    $clean['inclusi'] = $inclusi;

    // Porzioni per ingrediente: si salvano tutte (anche 1), così il default «Proteine = 2» non torna da solo.
    $porzioni = array();
    $p_values = isset( $input['porzioni_valore'] ) ? (array) $input['porzioni_valore'] : array();
    foreach ( $names as $i => $name ) {
        $key   = brtw_group_key( sanitize_text_field( $name ) );
        $value = isset( $p_values[ $i ] ) ? trim( (string) $p_values[ $i ] ) : '';
        if ( $key === '' || $value === '' || ! is_numeric( $value ) ) {
            continue;
        }
        $porzioni[ $key ] = min( 5, max( 1, (int) $value ) );
    }
    $clean['porzioni'] = $porzioni;

    return $clean;
}

/**
 * I gruppi di ingredienti che il configuratore incontra oggi (per nome), con il numero letto dalla descrizione
 * e il prezzo dell'extra: serve alla tabella delle eccezioni, così il cliente sceglie per nome e vede il risultato.
 */
function brtw_admin_known_groups() {
    $groups = array();
    if ( ! function_exists( 'wc_get_products' ) || ! class_exists( 'WC_Product_Addons_Helper' ) ) {
        return $groups;
    }
    $categories = brtw_configurator_categories();
    if ( ! $categories ) {
        return $groups;
    }
    $products = wc_get_products( array( 'status' => 'publish', 'limit' => 20, 'category' => $categories ) );
    foreach ( (array) $products as $product ) {
        if ( ! $product instanceof WC_Product ) {
            continue;
        }
        foreach ( brtw_product_addon_groups( $product->get_id() ) as $group ) {
            $key = brtw_group_key( $group['name'] );
            if ( ! isset( $groups[ $key ] ) ) {
                $groups[ $key ] = array(
                    'name'        => $group['name'],
                    'from_desc'   => array(),
                    'extra'       => (float) $group['brtw_extra'],
                    'products'    => array(),
                );
            }
            $groups[ $key ]['from_desc'][] = brtw_included_from_description( isset( $group['description'] ) ? $group['description'] : '' );
            $groups[ $key ]['products'][]  = $product->get_name();
        }
    }
    return $groups;
}

function brtw_render_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    $settings   = brtw_settings();
    $terms      = brtw_get_terms( 'product_cat', 0 );
    $all_terms  = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
    $all_terms  = is_wp_error( $all_terms ) ? $terms : $all_terms;
    $known      = brtw_admin_known_groups();
    $exceptions = $settings['inclusi'];
    // Eccezioni salvate per gruppi che oggi non esistono più: si mostrano lo stesso, così si possono togliere.
    foreach ( $exceptions as $key => $value ) {
        if ( ! isset( $known[ $key ] ) ) {
            $known[ $key ] = array( 'name' => $key, 'from_desc' => array(), 'extra' => 0, 'products' => array() );
        }
    }
    ?>
    <div class="wrap brtw-settings">
        <h1><?php esc_html_e( 'Make your own Pokè', 'ticinoweb' ); ?></h1>
        <p><?php esc_html_e( 'Il configuratore mostra i prodotti delle categorie qui sotto come «misure»; gli ingredienti sono i gruppi di WooCommerce Product Add-ons assegnati a quelle categorie. I primi ingredienti di ogni gruppo sono inclusi nel prezzo: quanti, lo dice il secondo numero della descrizione del gruppo (es. «Minimo 1, dopo 2 si paga un extra» → 2 inclusi), oppure l\'eccezione che imposti qui.', 'ticinoweb' ); ?></p>

        <?php settings_errors( 'brtw_settings' ); ?>

        <form method="post" action="options.php">
            <?php settings_fields( 'brtw_settings_group' ); ?>

            <h2><?php esc_html_e( 'Categorie del configuratore', 'ticinoweb' ); ?></h2>
            <p class="description"><?php esc_html_e( 'I prodotti di queste categorie sono le misure tra cui il cliente sceglie (es. Poké Kids, M, L, XL).', 'ticinoweb' ); ?></p>
            <?php if ( $all_terms ) : ?>
                <ul class="brtw-settings__categories">
                    <?php foreach ( $all_terms as $term ) : ?>
                        <li>
                            <label>
                                <input type="checkbox" name="brtw_settings[categorie][]" value="<?php echo esc_attr( $term->slug ); ?>"<?php checked( in_array( $term->slug, $settings['categorie'], true ) ); ?>>
                                <?php echo esc_html( $term->name ); ?>
                                <span class="description">(<?php echo esc_html( sprintf( /* translators: %d: numero di prodotti */ _n( '%d prodotto', '%d prodotti', (int) $term->count, 'ticinoweb' ), (int) $term->count ) ); ?>)</span>
                            </label>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else : ?>
                <p><?php esc_html_e( 'Non ci sono ancora categorie di prodotti: creale in Prodotti → Categorie.', 'ticinoweb' ); ?></p>
            <?php endif; ?>

            <h2><?php esc_html_e( 'Ingredienti inclusi nel prezzo', 'ticinoweb' ); ?></h2>
            <p class="description"><?php esc_html_e( 'Per ogni gruppo vedi quanti ingredienti risultano inclusi dalla descrizione. Se vuoi un numero diverso, scrivilo nella colonna «Forza a»: vale per quel gruppo in tutte le misure. Lascia vuoto per usare la descrizione.', 'ticinoweb' ); ?></p>
            <?php if ( $known ) : ?>
                <table class="widefat striped brtw-settings__groups" style="max-width: 900px;">
                    <thead>
                        <tr>
                            <th><?php esc_html_e( 'Gruppo', 'ticinoweb' ); ?></th>
                            <th><?php esc_html_e( 'Dalla descrizione', 'ticinoweb' ); ?></th>
                            <th><?php esc_html_e( 'Prezzo dell\'extra', 'ticinoweb' ); ?></th>
                            <th><?php esc_html_e( 'Forza a', 'ticinoweb' ); ?></th>
                            <th><?php esc_html_e( 'Risultato', 'ticinoweb' ); ?></th>
                            <th><?php esc_html_e( 'Porzioni per ingrediente', 'ticinoweb' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $i = 0; foreach ( $known as $key => $group ) : ?>
                        <?php
                        $desc_values = array_values( array_unique( $group['from_desc'] ) );
                        $forced      = isset( $exceptions[ $key ] ) ? (int) $exceptions[ $key ] : '';
                        $result      = $forced !== '' ? array( $forced ) : $desc_values;
                        ?>
                        <tr>
                            <td>
                                <strong><?php echo esc_html( $group['name'] ); ?></strong>
                                <input type="hidden" name="brtw_settings[inclusi_nome][<?php echo (int) $i; ?>]" value="<?php echo esc_attr( $group['name'] ); ?>">
                                <?php if ( $group['products'] ) : ?>
                                    <br><span class="description"><?php echo esc_html( implode( ', ', array_unique( $group['products'] ) ) ); ?></span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo $desc_values ? esc_html( implode( ' / ', $desc_values ) ) : '—'; ?></td>
                            <td><?php echo $group['extra'] > 0 ? wp_kses_post( wc_price( $group['extra'] ) ) : esc_html__( 'gratis', 'ticinoweb' ); ?></td>
                            <td><input type="number" min="0" step="1" class="small-text" name="brtw_settings[inclusi_valore][<?php echo (int) $i; ?>]" value="<?php echo esc_attr( $forced ); ?>" placeholder="—"></td>
                            <td><?php echo $result ? esc_html( implode( ' / ', array_map( function ( $n ) use ( $group ) { return brtw_included_label( $n, $group['name'] ); }, $result ) ) ) : '—'; ?></td>
                            <td><input type="number" min="1" max="5" step="1" class="small-text" name="brtw_settings[porzioni_valore][<?php echo (int) $i; ?>]" value="<?php echo esc_attr( isset( $settings['porzioni'][ $key ] ) ? (int) $settings['porzioni'][ $key ] : 1 ); ?>"></td>
                        </tr>
                    <?php $i++; endforeach; ?>
                    </tbody>
                </table>
                <p class="description"><?php esc_html_e( '«Porzioni per ingrediente»: 1 = si sceglie una volta sola; 2 o più = accanto all\'ingrediente scelto compare «− 1 +» e il cliente può prenderne una porzione in più (es. salmone ×2). Ogni porzione conta come un ingrediente: rientra negli inclusi o si paga come extra, e sullo scontrino appare come «Salmone – 2ª porzione».', 'ticinoweb' ); ?></p>
                <p class="description"><?php esc_html_e( 'Quando due misure hanno numeri diversi nella descrizione (es. la Kids), qui li vedi separati da «/»: la regola «Forza a» li sostituisce entrambi; per numeri diversi per misura, scrivili nelle descrizioni dei rispettivi gruppi.', 'ticinoweb' ); ?></p>
            <?php else : ?>
                <p><?php esc_html_e( 'Nessun gruppo di ingredienti trovato: controlla che WooCommerce Product Add-ons sia attivo e che un gruppo globale sia assegnato alle categorie scelte sopra.', 'ticinoweb' ); ?></p>
            <?php endif; ?>

            <?php submit_button( __( 'Salva le impostazioni', 'ticinoweb' ) ); ?>
        </form>

        <h2><?php esc_html_e( 'Come si mette in pagina', 'ticinoweb' ); ?></h2>
        <p><?php esc_html_e( 'Inserisci lo shortcode in una pagina:', 'ticinoweb' ); ?> <code>[make_your_own_poke]</code></p>
        <p class="description"><?php esc_html_e( 'Parametri facoltativi: categoria="crea-la-tua-poke" (slug della categoria), per_pagina="4" (quante misure), orderby="price" (price, title, menu_order, date), ordine="ASC" (ASC o DESC). Con Elementor c\'è anche il widget «Crea la tua poké» nella categoria TicinoWeb.', 'ticinoweb' ); ?></p>
    </div>
    <?php
}
