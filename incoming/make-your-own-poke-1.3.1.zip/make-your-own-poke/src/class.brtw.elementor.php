<?php
/**
 * Make your own Pokè: integrazione con Elementor (caricata solo se Elementor è attivo).
 * Registra la categoria «TicinoWeb» e il widget «Crea la tua poké», che usa brtw_render_configurator().
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Brtw_Uts_Elementor {

    public function __construct() {
        add_action( 'elementor/editor/before_enqueue_scripts', array( $this, 'brtw_preview_enqueue_scripts' ) );
        add_action( 'elementor/widgets/register', array( $this, 'brtw_register_widgets' ) );
        add_action( 'elementor/elements/categories_registered', array( $this, 'brtw_create_custom_categories' ) );
    }

    public function brtw_preview_enqueue_scripts() {
        wp_enqueue_style( 'brtw-uts-elementor', BRTW_URI . 'assets/css/elementor.css', array(), BRTW_VERSION );
    }

    public function brtw_register_widgets( $widgets_manager ) {
        require_once BRTW_PATH . 'src/elementor/class.brtw.personalized.products.php';
        $widgets_manager->register( new Brtw_Personalized_Products() );
    }

    public function brtw_create_custom_categories( $elements_manager ) {
        $elements_manager->add_category( 'brtw', array(
            'title' => __( 'TicinoWeb', 'ticinoweb' ),
            'icon'  => 'fas fa-location-arrow',
        ) );
    }
}

new Brtw_Uts_Elementor();
