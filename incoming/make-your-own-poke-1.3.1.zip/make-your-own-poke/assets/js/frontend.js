/**
 * Make your own Pokè: configuratore lato browser.
 *
 * Il browser mostra il totale e invia le scelte; il prezzo vero lo calcola il server (src/helper.php),
 * con la stessa regola: i primi N ingredienti di ogni gruppo sono inclusi, nell'ordine in cui il cliente
 * li ha scelti, gli altri si pagano. Nessuna dipendenza da jQuery (se c'è, si avvisa WooCommerce
 * dell'aggiunta al carrello con l'evento «added_to_cart», così i frammenti del carrello si aggiornano).
 */
(function () {
	'use strict';

	var settings = window.brtwConfigurator || {};
	var i18n = settings.i18n || {};
	var currency = settings.currency || {};

	function text(key, fallback) {
		return typeof i18n[key] === 'string' ? i18n[key] : fallback;
	}

	function sprintf(format) {
		var args = Array.prototype.slice.call(arguments, 1);
		var i = 0;
		return String(format).replace(/%(\d+\$)?s/g, function (match, pos) {
			var index = pos ? parseInt(pos, 10) - 1 : i++;
			return typeof args[index] === 'undefined' ? '' : args[index];
		});
	}

	function formatPrice(amount) {
		var decimals = typeof currency.decimals === 'number' ? currency.decimals : 2;
		var fixed = (Math.round(amount * Math.pow(10, decimals)) / Math.pow(10, decimals)).toFixed(decimals);
		var parts = fixed.split('.');
		parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, currency.thousand || '\'');
		var number = parts.join(currency.decimal || '.');
		var symbol = currency.symbol || 'CHF';
		switch (currency.position) {
			case 'left': return symbol + number;
			case 'right': return number + symbol;
			case 'right_space': return number + ' ' + symbol;
			default: return symbol + ' ' + number;
		}
	}

	function toNumber(value) {
		var n = parseFloat(String(value || '0').replace(',', '.'));
		return isNaN(n) ? 0 : n;
	}

	/** Le porzioni di un ingrediente scelto: l'ordine (seq) in cui ognuna è stata aggiunta. */
	function getSeqs(input) {
		var raw = input.getAttribute('data-seqs');
		if (!raw) {
			return [];
		}
		return raw.split(',').map(function (n) { return parseInt(n, 10); }).filter(function (n) { return !isNaN(n); });
	}

	function setSeqs(input, seqs) {
		if (seqs.length) {
			input.setAttribute('data-seqs', seqs.join(','));
		} else {
			input.removeAttribute('data-seqs');
		}
	}

	/** Opzione «Senza …» (es. «Senza proteine»): gratis, non occupa un incluso, esclude le altre del gruppo. */
	function isNone(input) {
		return input.getAttribute('data-none') === '1';
	}

	function Configurator(root) {
		this.root = root;
		this.form = root.querySelector('[data-brtw-form]');
		this.qty = root.querySelector('[data-brtw-qty]');
		this.total = root.querySelector('[data-brtw-total]');
		this.submit = root.querySelector('[data-brtw-submit]');
		this.notice = root.querySelector('[data-brtw-notice]');
		this.addToCart = root.querySelector('[data-brtw-add-to-cart]');
		this.seq = 0;
		this.busy = false;
		if (!this.form) {
			return;
		}
		this.bind();
		this.setActiveBlock(this.selectedSize(), false);
		this.recalc();
	}

	Configurator.prototype.bind = function () {
		var self = this;
		this.form.addEventListener('change', function (event) {
			var target = event.target;
			if (!(target instanceof HTMLInputElement)) {
				return;
			}
			if (target.name === 'brtw_product') {
				self.setActiveBlock(target, true);
				self.recalc();
			} else if (target.classList.contains('brtw-option__input')) {
				self.onOptionChange(target);
			} else if (target === self.qty) {
				if (toNumber(self.qty.value) < 1) {
					self.qty.value = 1;
				}
				self.recalc();
			}
		});
		this.form.addEventListener('submit', function (event) {
			self.onSubmit(event);
		});
		this.form.addEventListener('click', function (event) {
			var button = event.target instanceof Element ? event.target.closest('[data-brtw-portion]') : null;
			if (button && self.form.contains(button)) {
				event.preventDefault();
				self.onPortion(button);
			}
		});
	};

	Configurator.prototype.selectedSize = function () {
		return this.form.querySelector('input[name="brtw_product"]:checked') || this.form.querySelector('input[name="brtw_product"]');
	};

	Configurator.prototype.blocks = function () {
		return Array.prototype.slice.call(this.form.querySelectorAll('.brtw-product-addons'));
	};

	Configurator.prototype.activeBlock = function () {
		return this.form.querySelector('.brtw-product-addons:not([hidden])');
	};

	/** Mostra il blocco di add-on della misura scelta; le scelte già fatte passano alla nuova misura quando l'opzione esiste. */
	Configurator.prototype.setActiveBlock = function (sizeInput, carryOver) {
		if (!sizeInput) {
			return;
		}
		var productId = sizeInput.value;
		var previous = this.activeBlock();
		var chosen = [];
		if (carryOver && previous) {
			Array.prototype.forEach.call(previous.querySelectorAll('.brtw-option__input:checked'), function (input) {
				var group = input.closest('[data-brtw-group]');
				chosen.push({ group: group ? group.getAttribute('data-name') : '', value: input.value, seqs: getSeqs(input) });
			});
		}
		this.blocks().forEach(function (block) {
			var active = block.getAttribute('data-product') === productId;
			block.hidden = !active;
			Array.prototype.forEach.call(block.querySelectorAll('input'), function (input) {
				input.disabled = !active;
				if (!active) {
					input.checked = false;
					input.removeAttribute('data-seqs');
				}
			});
		});
		var current = this.activeBlock();
		if (current && chosen.length) {
			chosen.forEach(function (item) {
				var group = current.querySelector('[data-brtw-group][data-name="' + item.group.replace(/"/g, '\\"') + '"]');
				if (!group) {
					return;
				}
				var input = Array.prototype.filter.call(group.querySelectorAll('.brtw-option__input'), function (candidate) {
					return candidate.value === item.value || candidate.value.indexOf(item.value.replace(/-\d+$/, '') + '-') === 0;
				})[0];
				if (input) {
					var maxPortions = parseInt(group.getAttribute('data-portions') || '1', 10);
					input.checked = true;
					setSeqs(input, item.seqs.length ? item.seqs.slice(0, Math.max(1, maxPortions)) : [0]);
				}
			});
		}
		Array.prototype.forEach.call(this.form.querySelectorAll('[data-brtw-size]'), function (label) {
			label.classList.toggle('is-selected', label.getAttribute('data-brtw-size') === productId);
		});
		if (this.addToCart) {
			this.addToCart.value = productId;
		}
		var permalink = sizeInput.getAttribute('data-permalink');
		if (permalink) {
			this.form.setAttribute('action', permalink);
		}
		this.hideNotice();
	};

	Configurator.prototype.onOptionChange = function (input) {
		var group = input.closest('[data-brtw-group]');
		if (input.type === 'radio' && group) {
			Array.prototype.forEach.call(group.querySelectorAll('.brtw-option__input'), function (other) {
				if (other !== input) {
					other.removeAttribute('data-seqs');
				}
			});
		}
		if (input.checked && group && input.type === 'checkbox') {
			// «Senza …» toglie gli altri ingredienti del gruppo; un ingrediente vero toglie «Senza …».
			var none = isNone(input);
			Array.prototype.forEach.call(group.querySelectorAll('.brtw-option__input:checked'), function (other) {
				if (other !== input && (none || isNone(other))) {
					other.checked = false;
					other.removeAttribute('data-seqs');
				}
			});
		}
		if (input.checked) {
			this.seq += 1;
			setSeqs(input, [this.seq]);
		} else {
			input.removeAttribute('data-seqs');
		}
		if (group) {
			group.classList.remove('is-invalid');
		}
		this.hideNotice();
		this.recalc();
	};

	/** «+» aggiunge una porzione dello stesso ingrediente, «−» la toglie (sotto 1 l'ingrediente si toglie). */
	Configurator.prototype.onPortion = function (button) {
		var li = button.closest('.brtw-option');
		var group = button.closest('[data-brtw-group]');
		var input = li ? li.querySelector('.brtw-option__input') : null;
		if (!input || !group || !input.checked) {
			return;
		}
		var step = parseInt(button.getAttribute('data-brtw-portion') || '0', 10);
		var maxPortions = parseInt(group.getAttribute('data-portions') || '1', 10);
		var maxGroup = parseInt(group.getAttribute('data-max') || '0', 10);
		var seqs = getSeqs(input);
		if (step > 0) {
			if (seqs.length >= maxPortions || (maxGroup > 0 && this.unitsInGroup(group).length >= maxGroup)) {
				return;
			}
			this.seq += 1;
			seqs.push(this.seq);
			setSeqs(input, seqs);
		} else if (seqs.length > 1) {
			seqs.pop();
			setSeqs(input, seqs);
		} else {
			input.checked = false;
			input.removeAttribute('data-seqs');
			input.focus({ preventScroll: true });
		}
		group.classList.remove('is-invalid');
		this.hideNotice();
		this.recalc();
	};

	/**
	 * Le porzioni scelte in un gruppo, nell'ordine in cui il cliente le ha aggiunte:
	 * [{ input, seq }], un elemento per porzione (salmone ×2 = due elementi).
	 */
	Configurator.prototype.unitsInGroup = function (group) {
		var units = [];
		Array.prototype.forEach.call(group.querySelectorAll('.brtw-option__input:checked'), function (input) {
			var seqs = getSeqs(input);
			if (!seqs.length) {
				seqs = [0];
			}
			seqs.forEach(function (seq) {
				units.push({ input: input, seq: seq });
			});
		});
		return units.sort(function (a, b) { return a.seq - b.seq; });
	};

	Configurator.prototype.recalc = function () {
		var size = this.selectedSize();
		var block = this.activeBlock();
		var base = size ? toNumber(size.getAttribute('data-price')) : 0;
		var qty = this.qty ? Math.max(1, Math.floor(toNumber(this.qty.value))) : 1;
		var perUnit = base;
		var flat = 0;

		if (block) {
			Array.prototype.forEach.call(block.querySelectorAll('[data-brtw-group]'), function (group) {
				var included = parseInt(group.getAttribute('data-included') || '0', 10);
				var max = parseInt(group.getAttribute('data-max') || '0', 10);
				var maxPortions = parseInt(group.getAttribute('data-portions') || '1', 10);
				// «Senza …» non conta: né tra gli inclusi né tra gli extra.
				var chosen = this.unitsInGroup(group).filter(function (unit) { return !isNone(unit.input); });
				var noneChosen = !!group.querySelector('.brtw-option__input[data-none="1"]:checked');
				var extras = 0;

				Array.prototype.forEach.call(group.querySelectorAll('.brtw-option'), function (li) {
					li.classList.remove('is-included', 'is-extra');
				});
				chosen.forEach(function (unit, index) {
					var input = unit.input;
					var li = input.closest('.brtw-option');
					var free = index < included;
					// Un ingrediente con una porzione che si paga è «extra» (mostra il prezzo), altrimenti «incluso».
					if (li) {
						if (!free) {
							li.classList.remove('is-included');
							li.classList.add('is-extra');
						} else if (!li.classList.contains('is-extra')) {
							li.classList.add('is-included');
						}
					}
					if (free) {
						return;
					}
					extras += 1;
					var price = toNumber(input.getAttribute('data-price'));
					switch (input.getAttribute('data-price-type')) {
						case 'flat_fee': flat += price; break;
						case 'percentage_based': perUnit += base * price / 100; break;
						default: perUnit += price;
					}
				});

				group.classList.toggle('has-free-slots', chosen.length < included);
				group.classList.toggle('has-extras', extras > 0);
				var maxed = max > 0 && chosen.length >= max;
				var groupName = group.getAttribute('data-name') || '';
				Array.prototype.forEach.call(group.querySelectorAll('.brtw-option__input'), function (input) {
					var li = input.closest('.brtw-option');
					if (!input.checked && input.type === 'checkbox') {
						var off = noneChosen && !isNone(input);
						input.disabled = maxed || off;
						if (li) {
							li.classList.toggle('is-maxed', maxed && !off);
							li.classList.toggle('is-off', off);
						}
					}
					// Il controllo «− 1 +» compare solo quando l'ingrediente è scelto.
					var stepper = li ? li.querySelector('[data-brtw-portions]') : null;
					if (!stepper) {
						return;
					}
					var count = input.checked ? Math.max(1, getSeqs(input).length) : 0;
					stepper.hidden = !input.checked;
					li.classList.toggle('is-chosen', input.checked);
					li.classList.toggle('has-double', count > 1);
					var countEl = stepper.querySelector('[data-brtw-portion-count]');
					if (countEl) {
						var nameEl = li.querySelector('.brtw-option__name');
						var label = nameEl ? nameEl.textContent : groupName;
						countEl.textContent = String(count);
						countEl.setAttribute('aria-label', count === 1 ? sprintf(text('portionOne', '1 porzione di %s'), label) : sprintf(text('portionsOf', '%1$s porzioni di %2$s'), count, label));
					}
					var plus = stepper.querySelector('[data-brtw-portion="1"]');
					if (plus) {
						plus.disabled = count >= maxPortions || maxed;
					}
				});

				var counter = group.querySelector('[data-brtw-count]');
				var countText = group.getAttribute('data-count-text');
				if (counter && countText) {
					var label = sprintf(countText, Math.min(chosen.length, included));
					if (extras > 0) {
						label += ', ' + extras + ' ' + text('extra', 'extra');
					}
					counter.textContent = label;
				}
			}, this);
		}

		if (this.total) {
			this.total.textContent = formatPrice(perUnit * qty + flat);
		}
	};

	Configurator.prototype.validate = function () {
		var block = this.activeBlock();
		if (!block) {
			return true;
		}
		var groups = Array.prototype.slice.call(block.querySelectorAll('[data-brtw-group]'));
		for (var i = 0; i < groups.length; i++) {
			var group = groups[i];
			var min = parseInt(group.getAttribute('data-min') || '0', 10);
			var count = group.querySelectorAll('.brtw-option__input:checked').length;
			group.classList.remove('is-invalid');
			if (min > 0 && count < min) {
				group.classList.add('is-invalid');
				this.showNotice(sprintf(text('chooseAtLeast', 'Scegli almeno %1$s in «%2$s».'), min, group.getAttribute('data-name') || ''), 'error');
				group.scrollIntoView({ behavior: 'smooth', block: 'center' });
				var first = group.querySelector('.brtw-option__input');
				if (first) {
					first.focus({ preventScroll: true });
				}
				return false;
			}
		}
		return true;
	};

	Configurator.prototype.showNotice = function (message, type, link) {
		if (!this.notice) {
			return;
		}
		this.notice.textContent = '';
		this.notice.appendChild(document.createTextNode(message));
		if (link && link.href) {
			this.notice.appendChild(document.createTextNode(' '));
			var a = document.createElement('a');
			a.href = link.href;
			a.className = 'brtw-notice__link';
			a.textContent = link.label;
			this.notice.appendChild(a);
		}
		this.notice.className = 'brtw-notice brtw-notice--' + (type || 'info');
		this.notice.hidden = false;
	};

	Configurator.prototype.hideNotice = function () {
		if (this.notice) {
			this.notice.hidden = true;
			this.notice.textContent = '';
		}
	};

	Configurator.prototype.setBusy = function (busy) {
		this.busy = busy;
		if (this.submit) {
			this.submit.disabled = busy;
			this.submit.classList.toggle('is-busy', busy);
		}
		this.root.classList.toggle('is-busy', busy);
	};

	/** Invio: lo stesso endpoint di WooCommerce (wc-ajax add_to_cart), con i campi addon-* di Product Add-ons. */
	Configurator.prototype.onSubmit = function (event) {
		if (this.busy) {
			event.preventDefault();
			return;
		}
		if (!this.validate()) {
			event.preventDefault();
			return;
		}
		if (!settings.ajaxUrl || typeof window.fetch !== 'function' || typeof window.FormData !== 'function') {
			return; // invio classico del modulo al permalink del prodotto
		}
		event.preventDefault();

		var self = this;
		var size = this.selectedSize();
		var block = this.activeBlock();
		var body = new FormData();
		body.append('product_id', size ? size.value : '');
		body.append('quantity', this.qty ? String(Math.max(1, Math.floor(toNumber(this.qty.value)))) : '1');
		if (block) {
			Array.prototype.forEach.call(block.querySelectorAll('[data-brtw-group]'), function (group) {
				// Un valore per porzione: salmone ×2 si invia due volte (il server ne fa due righe).
				self.unitsInGroup(group).forEach(function (unit) {
					body.append(unit.input.name, unit.input.value);
				});
			});
		}

		this.setBusy(true);
		this.showNotice(text('adding', 'Aggiungo al carrello…'), 'info');

		window.fetch(settings.ajaxUrl, { method: 'POST', body: body, credentials: 'same-origin' })
			.then(function (response) { return response.json(); })
			.then(function (data) {
				self.setBusy(false);
				if (!data || data.error) {
					self.showNotice(text('error', 'Non è stato possibile aggiungere il piatto al carrello.'), 'error', data && data.product_url ? { href: data.product_url, label: text('openProduct', 'Apri la scheda del prodotto') } : null);
					return;
				}
				if (data.fragments) {
					Object.keys(data.fragments).forEach(function (selector) {
						Array.prototype.forEach.call(document.querySelectorAll(selector), function (el) {
							el.outerHTML = data.fragments[selector];
						});
					});
				}
				if (window.jQuery) {
					window.jQuery(document.body).trigger('added_to_cart', [data.fragments, data.cart_hash, window.jQuery(self.submit)]);
				}
				document.dispatchEvent(new CustomEvent('brtw:added_to_cart', { detail: data }));
				if (settings.redirect && settings.cartUrl) {
					window.location.href = settings.cartUrl;
					return;
				}
				self.showNotice(text('added', 'Aggiunto al carrello.'), 'success', settings.cartUrl ? { href: settings.cartUrl, label: text('viewCart', 'Vai al carrello') } : null);
			})
			.catch(function () {
				self.setBusy(false);
				self.showNotice(text('error', 'Non è stato possibile aggiungere il piatto al carrello.'), 'error');
			});
	};

	function init() {
		Array.prototype.forEach.call(document.querySelectorAll('[data-brtw-configurator]'), function (root) {
			if (!root.brtwConfigurator) {
				root.brtwConfigurator = new Configurator(root);
			}
		});
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
	// Elementor: dopo il render nell'editor o nei contenuti caricati dopo.
	if (window.jQuery) {
		window.jQuery(window).on('elementor/frontend/init', function () {
			if (window.elementorFrontend && window.elementorFrontend.hooks) {
				window.elementorFrontend.hooks.addAction('frontend/element_ready/brtw-personalized.default', init);
			}
		});
	}
})();
