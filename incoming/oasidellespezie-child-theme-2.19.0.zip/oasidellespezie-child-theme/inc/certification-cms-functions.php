<?php
/** Editable certification content below ticinoWEB CMS. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function oasi_certification_content_defaults(): array {
	return array(
		'kicker' => 'Controllo indipendente',
		'title' => 'Certificazione biologica',
		'summary' => 'Il certificato bio.inspecta 2026 e cosa significa per i prodotti espressamente contrassegnati come biologici.',
		'certificate_code' => 'CH-BIO-006',
		'certificate_number' => 'BVH-62064',
		'validity' => 'Valido fino al 31.12.2026',
		'section_title' => 'Certificato 2026',
		'section_body' => 'Numero BVH-62064, azienda n. 34698, rilasciato da bio.inspecta AG (CH-BIO-006) per L’Oasi delle spezie di Jaunin.\n\nCampo: Ordinanza federale sull’agricoltura biologica (CH-Bio). Attività certificate: preparazione, distribuzione/immissione sul mercato e importazione. Gruppi: piante e prodotti vegetali non trasformati; prodotti alimentari trasformati.',
		'meaning_title' => 'Cosa significa',
		'meaning_body' => 'La certificazione attesta i processi e i prodotti inclusi nel campo certificato alla data di emissione. Non significa che ogni articolo dell’assortimento sia biologico: fa fede la dicitura BIO, il riferimento di controllo e l’etichetta del singolo prodotto.',
		'updates_title' => 'Verifica e aggiornamenti',
		'updates_body' => 'Il PDF pubblicato è il documento di riferimento corrente. Certificati e assortimento possono essere aggiornati; per una verifica relativa a un lotto o articolo specifico contatta il laboratorio prima dell’acquisto.',
		'certificate_image_id' => 0,
		'certificate_pdf_id' => 0,
		'cta_label' => 'Apri il certificato PDF',
		'footer_title' => 'Certificazione biologica',
		'footer_body' => 'Controllo indipendente dei processi certificati.',
		'home_label' => 'Certificazione Ufficiale Bio • CH-BIO-006',
		'home_title' => 'Tutte le nostre erbe, spezie e miscele di spezie sono naturali al 100%, senza conservanti o additivi.',
		'home_body' => 'Rifiutiamo aromi sintetici, esaltatori di sapidità, conservanti e addensanti. Solo pura materia prima selezionata, coltivata nel rispetto della terra e lavorata con rigore svizzero.',
		'home_cta_label' => 'Approfondisci la certificazione',
	);
}

function oasi_certification_sanitize_content( $value ): array {
	$value    = is_array( $value ) ? $value : array();
	$defaults = oasi_certification_content_defaults();
	$result   = array();
	$textareas = array( 'summary', 'section_body', 'meaning_body', 'updates_body', 'footer_body', 'home_title', 'home_body' );
	foreach ( $defaults as $key => $default ) {
		if ( in_array( $key, array( 'certificate_image_id', 'certificate_pdf_id' ), true ) ) {
			$result[ $key ] = absint( $value[ $key ] ?? $default );
		} elseif ( in_array( $key, $textareas, true ) ) {
			$result[ $key ] = sanitize_textarea_field( $value[ $key ] ?? $default );
		} else {
			$result[ $key ] = sanitize_text_field( $value[ $key ] ?? $default );
		}
	}
	return $result;
}

function oasi_get_certification_content(): array {
	$saved = get_option( 'oasi_certification_content', array() );
	return oasi_certification_sanitize_content( is_array( $saved ) ? array_replace( oasi_certification_content_defaults(), $saved ) : array() );
}

/** Prefer the editable Media Library PDF, then preserve the verified legacy PDF. */
function oasi_certification_get_pdf_url(): string {
	$data = oasi_get_certification_content();
	$url  = $data['certificate_pdf_id'] ? wp_get_attachment_url( $data['certificate_pdf_id'] ) : '';
	return $url ? (string) $url : ( function_exists( 'oasi_legal_get_certificate_url' ) ? oasi_legal_get_certificate_url() : '' );
}

function oasi_certification_cms_register_setting(): void {
	register_setting( 'oasi_certification_settings', 'oasi_certification_content', array( 'type' => 'array', 'default' => oasi_certification_content_defaults(), 'sanitize_callback' => 'oasi_certification_sanitize_content' ) );
}
add_action( 'admin_init', 'oasi_certification_cms_register_setting' );

function oasi_certification_cms_option_capability(): string {
	return 'edit_pages';
}
add_filter( 'option_page_capability_oasi_certification_settings', 'oasi_certification_cms_option_capability' );

function oasi_certification_cms_menu(): void {
	add_submenu_page( 'ticinoweb-cms', __( 'Certificazioni', 'oasidellespezie-child-theme' ), __( 'Certificazioni', 'oasidellespezie-child-theme' ), 'edit_pages', 'oasi-certification-settings', 'oasi_certification_cms_render_page' );
}
add_action( 'admin_menu', 'oasi_certification_cms_menu', 42 );

function oasi_certification_cms_assets( string $hook ): void {
	if ( 'ticinoweb-cms_page_oasi-certification-settings' !== $hook ) {
		return;
	}
	wp_enqueue_media();
	wp_enqueue_style( 'oasi-cms-editor', get_stylesheet_directory_uri() . '/assets/css/cms-editor.css', array(), wp_get_theme()->get( 'Version' ) );
	wp_enqueue_script( 'oasi-cms-editor', get_stylesheet_directory_uri() . '/assets/js/cms-editor.js', array(), wp_get_theme()->get( 'Version' ), true );
}
add_action( 'admin_enqueue_scripts', 'oasi_certification_cms_assets' );

function oasi_certification_cms_field( array $data, string $key, string $label, bool $textarea = false ): void {
	?><label class="oasi-cms-editor__field"><span><?php echo esc_html( $label ); ?></span><?php if ( $textarea ) : ?><textarea class="large-text" rows="4" name="oasi_certification_content[<?php echo esc_attr( $key ); ?>]"><?php echo esc_textarea( (string) $data[ $key ] ); ?></textarea><?php else : ?><input type="text" class="large-text" name="oasi_certification_content[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( (string) $data[ $key ] ); ?>"><?php endif; ?></label><?php
}

function oasi_certification_cms_media( array $data, string $key, string $label, string $type ): void {
	$id      = (int) $data[ $key ];
	$preview = 'image' === $type && $id ? wp_get_attachment_image_url( $id, 'medium' ) : '';
	$filename = 'application/pdf' === $type && $id ? basename( (string) get_attached_file( $id ) ) : '';
	?><div class="oasi-cms-editor__field" data-oasi-media-field><span><?php echo esc_html( $label ); ?></span><div class="oasi-cms-editor__media"><div class="oasi-cms-editor__preview<?php echo 'image' === $type ? '' : ' oasi-cms-editor__preview--document'; ?>" data-oasi-media-preview data-empty-label="Nessun file"><?php if ( $preview ) : ?><img src="<?php echo esc_url( $preview ); ?>" alt=""><?php elseif ( $filename ) : ?><strong><?php echo esc_html( $filename ); ?></strong><?php else : ?><span><?php esc_html_e( 'Nessun file', 'oasidellespezie-child-theme' ); ?></span><?php endif; ?></div><div class="oasi-cms-editor__media-actions"><input type="hidden" name="oasi_certification_content[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( (string) $id ); ?>"><button type="button" class="button" data-oasi-media-pick data-media-type="<?php echo esc_attr( $type ); ?>"><?php esc_html_e( 'Scegli dalla Libreria Media', 'oasidellespezie-child-theme' ); ?></button><button type="button" class="button-link-delete" data-oasi-media-clear><?php esc_html_e( 'Rimuovi', 'oasidellespezie-child-theme' ); ?></button></div></div></div><?php
}

function oasi_certification_cms_render_page(): void {
	if ( ! current_user_can( 'edit_pages' ) ) {
		wp_die( esc_html__( 'Non hai i permessi per modificare questa sezione.', 'oasidellespezie-child-theme' ) );
	}
	$data = oasi_get_certification_content();
	?>
	<div class="wrap oasi-cms-editor"><h1><?php esc_html_e( 'Certificazioni', 'oasidellespezie-child-theme' ); ?></h1><p class="oasi-cms-editor__lead"><?php esc_html_e( 'Aggiorna testi, immagine e PDF in un solo punto. La stessa fonte alimenta pagina, Home e riquadro del footer.', 'oasidellespezie-child-theme' ); ?></p><?php settings_errors(); ?><form method="post" action="options.php"><?php settings_fields( 'oasi_certification_settings' ); ?>
	<section class="oasi-cms-editor__section"><div class="oasi-cms-editor__section-heading"><div><span>01</span><h2><?php esc_html_e( 'Pagina Certificazione', 'oasidellespezie-child-theme' ); ?></h2></div></div><div class="oasi-cms-editor__grid"><?php oasi_certification_cms_field( $data, 'kicker', 'Etichetta breve' ); ?><?php oasi_certification_cms_field( $data, 'title', 'Titolo principale' ); ?><?php oasi_certification_cms_field( $data, 'summary', 'Introduzione', true ); ?><?php oasi_certification_cms_field( $data, 'certificate_code', 'Codice organismo' ); ?><?php oasi_certification_cms_field( $data, 'certificate_number', 'Numero certificato' ); ?><?php oasi_certification_cms_field( $data, 'validity', 'Validità' ); ?></div><?php oasi_certification_cms_media( $data, 'certificate_image_id', 'Immagine del nuovo certificato', 'image' ); ?><?php oasi_certification_cms_media( $data, 'certificate_pdf_id', 'PDF ufficiale', 'application/pdf' ); ?><?php oasi_certification_cms_field( $data, 'cta_label', 'Testo pulsante PDF' ); ?></section>
	<section class="oasi-cms-editor__section"><div class="oasi-cms-editor__section-heading"><div><span>02</span><h2><?php esc_html_e( 'Testi del certificato', 'oasidellespezie-child-theme' ); ?></h2></div></div><div class="oasi-cms-editor__grid"><?php oasi_certification_cms_field( $data, 'section_title', 'Titolo certificato' ); ?><?php oasi_certification_cms_field( $data, 'section_body', 'Descrizione certificato', true ); ?><?php oasi_certification_cms_field( $data, 'meaning_title', 'Titolo significato' ); ?><?php oasi_certification_cms_field( $data, 'meaning_body', 'Spiegazione', true ); ?><?php oasi_certification_cms_field( $data, 'updates_title', 'Titolo aggiornamenti' ); ?><?php oasi_certification_cms_field( $data, 'updates_body', 'Testo aggiornamenti', true ); ?></div></section>
	<section class="oasi-cms-editor__section"><div class="oasi-cms-editor__section-heading"><div><span>03</span><h2><?php esc_html_e( 'Home e footer', 'oasidellespezie-child-theme' ); ?></h2></div><p><?php esc_html_e( 'Testi sintetici collegati alla certificazione.', 'oasidellespezie-child-theme' ); ?></p></div><div class="oasi-cms-editor__grid"><?php oasi_certification_cms_field( $data, 'footer_title', 'Titolo footer' ); ?><?php oasi_certification_cms_field( $data, 'footer_body', 'Testo footer', true ); ?><?php oasi_certification_cms_field( $data, 'home_label', 'Etichetta Home' ); ?><?php oasi_certification_cms_field( $data, 'home_title', 'Titolo Home', true ); ?><?php oasi_certification_cms_field( $data, 'home_body', 'Descrizione Home', true ); ?><?php oasi_certification_cms_field( $data, 'home_cta_label', 'Testo pulsante Home' ); ?></div></section><?php submit_button( __( 'Salva certificazioni', 'oasidellespezie-child-theme' ) ); ?></form></div>
	<?php
}
