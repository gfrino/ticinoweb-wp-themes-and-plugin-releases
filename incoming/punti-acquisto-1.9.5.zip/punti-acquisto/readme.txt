=== Simple Point System for WooCommerce ===
Contributors: gfrino
Tags: woocommerce, points, loyalty, rewards, checkout
Requires at least: 5.0
Tested up to: 6.5
Requires PHP: 7.2
Stable tag: 1.9.5
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Lightweight loyalty points for WooCommerce: customers earn points on completed orders and redeem them as credit at checkout.

== Description ==
- Configure spend-based or fixed-per-order earning, point value, redemption cap and redemption step.
- Custom point naming (singular/plural) to match your brand or language.
- Automatic earning on completed orders (only on actual paid amount, excluding point discount).
- Redemption at checkout with dynamically updated totals.
- Hides payment methods if points fully cover the order.
- Points balance visible in My Account; admins can edit user balances.

== Installation ==
1. Upload the `punti-acquisto` folder to `/wp-content/plugins/`.
2. Activate the plugin from "Plugins" in WordPress.
3. Go to "Simple Point System" in the admin menu to configure earning and redemption rules.

== Frequently Asked Questions ==
= Are points deducted immediately? =
Yes. At checkout, the used points are deducted from the user's balance and stored on the order.

= When are points awarded? =
When the order status becomes "Completed". Points are stored in order meta `_pa_points_awarded` to prevent duplicates.

== Changelog ==
= 1.9.4 =
* Feature: added a fixed-points-per-completed-order earning mode while preserving spend-based behavior as the default for existing sites.
* Feature: added configurable maximum points per redemption and redemption step.
* Improvement: exposed the active earning and redemption rules through the REST configuration endpoints.

= 1.9.3 =
* Feature: `GET /wp-json/punti-acquisto/v1/config` (public) now also returns
  the configured loyalty tier names and point thresholds (`tiers`), so
  client apps can render an accurate, always-up-to-date tier legend instead
  of hardcoding tier names.

= 1.9.2 =
* Fix: on multisite networks that host more than one independent loyalty
  "hub" on the same installation (e.g. Mache Pizza and Little Inka sharing
  a server), every stats/report/admin-table function was scanning every
  site and every user on the whole network instead of just the current
  hub's own linked sites. Mache Pizza's admin was showing Little Inka's
  branches (and vice versa) in the per-site breakdown table, and the
  network-wide point totals mixed both networks' balances together.
  Everything is now scoped to the current hub's `wc_schedule_linked_sites`
  group (same "Gestione Woo" config used elsewhere in this plugin).

= 1.9.1 =
* Fix: management "hub" site (where settings/API secret are stored and the
  full dashboard renders) is no longer a hardcoded blog ID. It's now
  determined dynamically from mobile-admin's "Gestione Woo" site-linking
  config (`wc_schedule_linked_sites`), so the same plugin file works
  correctly on every multisite network that shares it, each with its own
  independently-configured hub (e.g. Mr Joe & Da Me, Little Inka).
* Improvement: the "centrally managed" notice on non-hub sites now links to
  the actual hub site instead of a hardcoded domain name.

= 1.9.0 =
* Feature: clickable user history modal in points breakdown (admin report).

= 1.7.3 =
* Feature: Added WooCommerce High-Performance Order Storage (HPOS) compatibility.

= 1.2.0 - 2025-12-25 =
* Feature: configurable singular/plural point labels (e.g., Point/Points, Punto/Punti).
* Improvement: clarified settings use the WooCommerce store currency.

= 1.1.0 - 2025-12-25 =
* Fix: checkout totals update correctly when applying points via WooCommerce AJAX (`post_data`). Rebranded as "Simple Point System for WooCommerce".

= 1.0.0 - 2025-12-24 =
* Initial release with earning, redemption at checkout, admin balance editing, and My Account display.

== Upgrade Notice ==
= 1.1.0 =
Update to ensure the checkout total updates when applying points via AJAX.
