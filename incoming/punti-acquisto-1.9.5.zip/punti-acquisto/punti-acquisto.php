<?php
/**
 * Plugin Name: Simple Point System for WooCommerce
 * Plugin URI: https://ticinoweb.com/
 * Description: Programma fedeltà a punti per il tuo negozio WooCommerce: i clienti guadagnano punti con gli ordini completati e li usano come sconto al pagamento. Tu decidi quanto vale un punto, i livelli (Argento, Oro, Platino) e vedi saldi e storico dei clienti.
 * Version: 1.9.5
 * Update URI: https://github.com/gfrino/ticinoweb-wp-themes-and-plugin-releases
 * Author: Giovanni Frino
 * Author URI: https://ticinoweb.com/
 * Text-Domain: punti-acquisto
 * Requires at least: 5.0
 * Requires PHP: 7.2
 * WC requires at least: 3.0
 * WC tested up to: 8.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/includes/loyalty-rules.php';
require_once __DIR__ . '/includes/tw-release-updater.php';

// Versione dell'aggiornatore standard ticinoWEB (mu-plugin) incluso in questo plugin.
define( 'PA_RELEASE_UPDATER_VERSION', '1.2.0' );

/**
 * Installa o aggiorna il mu-plugin dell'aggiornatore dalla copia inclusa.
 */
function PA_install_release_updater() {
	if ( ! class_exists( 'TW_Release_Updater' ) || TW_Release_Updater::mu_is_current( PA_RELEASE_UPDATER_VERSION ) ) {
		return;
	}
	if ( get_site_transient( 'pa_release_updater_failed' ) ) {
		return;
	}
	$result = TW_Release_Updater::install_mu( __DIR__ . '/includes/tw-release-updater.php' );
	if ( is_wp_error( $result ) ) {
		set_site_transient( 'pa_release_updater_failed', $result->get_error_message(), 12 * HOUR_IN_SECONDS );
	}
}

add_action( 'admin_init', function () {
	if ( current_user_can( is_multisite() ? 'manage_network_plugins' : 'activate_plugins' ) ) {
		PA_install_release_updater();
	}
}, 20 );

// API Secret default (used if not set in Settings page)
if ( ! defined( 'PA_API_SECRET_DEFAULT' ) ) {
	define( 'PA_API_SECRET_DEFAULT', 'jwt-machepizza-ch-s3cur3-k3y-2026' );
}

/**
 * Determine which blog is the "management hub" for punti-acquisto settings
 * in a multisite network, using mobile-admin's "Gestione Woo" site-linking
 * config (`wc_schedule_linked_sites`) as the single source of truth instead
 * of a hardcoded blog ID -- each network deployment (Mr Joe & Da Me, Little
 * Inka, ...) configures its own hub there, so this works unmodified across
 * every install that shares this plugin.
 *
 * A site is the hub if it holds a non-empty `wc_schedule_linked_sites` list.
 * If the current site isn't a hub itself, we look for a site whose list
 * includes the current blog -- that's our hub. Falls back to the current
 * blog on single-site installs or sites with no configured group.
 */
function PA_get_management_hub_blog_id() {
	if ( ! is_multisite() ) {
		return get_current_blog_id();
	}

	static $cached = null;
	if ( $cached !== null ) {
		return $cached;
	}

	$current_id = get_current_blog_id();

	$own_links = (array) get_option( 'wc_schedule_linked_sites', array() );
	if ( ! empty( $own_links ) ) {
		$cached = $current_id;
		return $cached;
	}

	$transient_key = 'pa_management_hub_' . $current_id;
	$hub = get_transient( $transient_key );
	if ( false !== $hub ) {
		$cached = (int) $hub;
		return $cached;
	}

	$hub = $current_id; // Fallback: no configured group, manage locally.
	foreach ( get_sites( array( 'number' => 0 ) ) as $site ) {
		$blog_id = (int) $site->blog_id;
		if ( $blog_id === $current_id ) {
			continue;
		}
		switch_to_blog( $blog_id );
		$links = (array) get_option( 'wc_schedule_linked_sites', array() );
		restore_current_blog();
		if ( in_array( (string) $current_id, array_map( 'strval', $links ), true ) ) {
			$hub = $blog_id;
			break;
		}
	}

	set_transient( $transient_key, $hub, 10 * MINUTE_IN_SECONDS );
	$cached = $hub;
	return $cached;
}

/**
 * Helper to fetch options from the management hub site in multisite networks.
 */
function PA_get_option( $option, $default = false ) {
	if ( is_multisite() ) {
		return get_blog_option( PA_get_management_hub_blog_id(), $option, $default );
	}
	return get_option( $option, $default );
}

/**
 * Blog IDs that belong to the current hub's own loyalty network: the hub
 * itself plus every site listed in its `wc_schedule_linked_sites` (the same
 * config mobile-admin's "Gestione Woo" uses to group branches together).
 * Different hubs on the same multisite installation (e.g. Mache Pizza and
 * Little Inka) are unrelated networks and must never see each other's data
 * -- this is what scopes every stats/report/table function below to just
 * the sites the current site's owner actually manages.
 */
function PA_get_linked_site_ids() {
	if ( ! is_multisite() ) {
		return array( get_current_blog_id() );
	}

	static $cached = null;
	if ( $cached !== null ) {
		return $cached;
	}

	$hub_id = PA_get_management_hub_blog_id();
	$links  = (array) get_blog_option( $hub_id, 'wc_schedule_linked_sites', array() );
	$ids    = array_map( 'intval', $links );
	$ids[]  = $hub_id;

	$cached = array_values( array_unique( $ids ) );
	return $cached;
}

// Declare WooCommerce HPOS compatibility
add_action( 'before_woocommerce_init', function() {
    if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
    }
} );

// Create points history table on activation
register_activation_hook( __FILE__, 'PA_create_history_table' );
function PA_create_history_table() {
	global $wpdb;
	$table_name = $wpdb->prefix . 'pa_points_history';
	$charset_collate = $wpdb->get_charset_collate();
	
	$sql = "CREATE TABLE IF NOT EXISTS $table_name (
		id bigint(20) NOT NULL AUTO_INCREMENT,
		user_id bigint(20) NOT NULL,
		points decimal(10,2) NOT NULL,
		type varchar(20) NOT NULL,
		description text NOT NULL,
		order_id bigint(20) DEFAULT NULL,
		date_created datetime NOT NULL,
		PRIMARY KEY  (id),
		KEY user_id (user_id),
		KEY date_created (date_created)
	) $charset_collate;";
	
	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta( $sql );
	
	// Flush rewrite rules for the points-history endpoint
	flush_rewrite_rules();
}

// Flush rewrite rules on deactivation
register_deactivation_hook( __FILE__, 'PA_deactivation' );
function PA_deactivation() {
	flush_rewrite_rules();
}

// Load translations (with Multisite support)
add_action( 'plugins_loaded', 'PA_load_textdomain' );
function PA_load_textdomain() {
	$locale = apply_filters( 'plugin_locale', get_locale(), 'punti-acquisto' );
	$mofile = dirname( __FILE__ ) . '/languages/punti-acquisto-' . $locale . '.mo';
	
	// Direct load for Multisite compatibility
	if ( file_exists( $mofile ) ) {
		load_textdomain( 'punti-acquisto', $mofile );
	} else {
		// Fallback: try standard WordPress location
		$plugin_rel_path = dirname( plugin_basename( __FILE__ ) ) . '/languages/';
		load_plugin_textdomain( 'punti-acquisto', false, $plugin_rel_path );
	}
}

// Admin menu
add_action( 'admin_menu', 'PA_admin_menu' );
function PA_admin_menu() {
	add_menu_page(
		esc_html__( 'Simple Point System', 'punti-acquisto' ),
		esc_html__( 'Simple Point System', 'punti-acquisto' ),
		'manage_options',
		'punti-acquisto-settings',
		'PA_settings_page',
		'dashicons-star-filled',
		58
	);
}

// Register settings
add_action( 'admin_init', 'PA_register_settings' );
function PA_register_settings() {
	register_setting( 'pa-settings-group', 'pa_point_value', [ 'default' => 1 ] );
	register_setting( 'pa-settings-group', 'pa_point_cost', [ 'default' => 10 ] );
	register_setting( 'pa-settings-group', 'pa_earning_mode', [ 'default' => 'spend_based', 'sanitize_callback' => 'PA_sanitize_earning_mode' ] );
	register_setting( 'pa-settings-group', 'pa_fixed_points_per_order', [ 'default' => 10, 'type' => 'integer', 'sanitize_callback' => 'PA_sanitize_nonnegative_int' ] );
	register_setting( 'pa-settings-group', 'pa_redemption_max_points', [ 'default' => 0, 'type' => 'integer', 'sanitize_callback' => 'PA_sanitize_nonnegative_int' ] );
	register_setting( 'pa-settings-group', 'pa_redemption_step', [ 'default' => 1, 'type' => 'integer', 'sanitize_callback' => 'PA_sanitize_positive_int' ] );
	register_setting( 'pa-settings-group', 'pa_point_label_singular', [ 'default' => 'Point' ] );
	register_setting( 'pa-settings-group', 'pa_point_label_plural', [ 'default' => 'Points' ] );
	register_setting( 'pa-settings-group', 'pa_api_secret', [ 'sanitize_callback' => 'sanitize_text_field' ] );
	register_setting( 'pa-settings-group', 'pa_tier_silver_min', [ 'default' => 101, 'type' => 'integer' ] );
	register_setting( 'pa-settings-group', 'pa_tier_gold_min', [ 'default' => 501, 'type' => 'integer' ] );
	register_setting( 'pa-settings-group', 'pa_tier_platinum_min', [ 'default' => 1501, 'type' => 'integer' ] );
	register_setting( 'pa-settings-group', 'pa_tier_base_name', [ 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ] );
	register_setting( 'pa-settings-group', 'pa_tier_silver_name', [ 'default' => 'Argento', 'sanitize_callback' => 'sanitize_text_field' ] );
	register_setting( 'pa-settings-group', 'pa_tier_gold_name', [ 'default' => 'Oro', 'sanitize_callback' => 'sanitize_text_field' ] );
	register_setting( 'pa-settings-group', 'pa_tier_platinum_name', [ 'default' => 'Platino', 'sanitize_callback' => 'sanitize_text_field' ] );
}

// AJAX handler: test REST API secret
add_action( 'wp_ajax_pa_test_api_secret', 'PA_ajax_test_api_secret' );
function PA_ajax_test_api_secret() {
	check_ajax_referer( 'pa_test_secret_nonce', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( 'Unauthorized' );
	}

	$secret   = PA_get_option( 'pa_api_secret', PA_API_SECRET_DEFAULT );
	$user_id  = get_current_user_id();
	$endpoint = rest_url( 'punti-acquisto/v1/points/' . $user_id );

	$response = wp_remote_get( $endpoint, [
		'headers' => [ 'X-API-Key' => $secret ],
		'timeout' => 10,
		'sslverify' => false,
	] );

	if ( is_wp_error( $response ) ) {
		wp_send_json_error( $response->get_error_message() );
	}

	$code = wp_remote_retrieve_response_code( $response );
	$body = json_decode( wp_remote_retrieve_body( $response ), true );

	if ( $code === 200 && isset( $body['balance'] ) ) {
		wp_send_json_success( [
			'message' => '✅ Connessione OK — saldo: ' . intval( $body['balance'] ) . ' punti',
			'balance' => $body['balance'],
		] );
	} else {
		$err = isset( $body['message'] ) ? $body['message'] : 'Risposta inattesa (HTTP ' . $code . ')';
		wp_send_json_error( '❌ ' . $err . ' — Verifica che il secret corrisponda al JWT_SECRET di Firebase.' );
	}
}

// AJAX handler: reset all user points to zero
add_action( 'wp_ajax_pa_reset_all_points', 'PA_ajax_reset_all_points' );
function PA_ajax_reset_all_points() {
	check_ajax_referer( 'pa_reset_all_points_nonce', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( 'Non autorizzato.' );
	}

	global $wpdb;

	// Count users with points > 0
	$users_with_points = $wpdb->get_var(
		"SELECT COUNT(DISTINCT user_id) FROM {$wpdb->usermeta} WHERE meta_key = 'pa_points_balance' AND CAST(meta_value AS DECIMAL(10,2)) > 0"
	);

	// Reset all point balances to 0
	$updated = $wpdb->update(
		$wpdb->usermeta,
		array( 'meta_value' => '0' ),
		array( 'meta_key' => 'pa_points_balance' ),
		array( '%s' ),
		array( '%s' )
	);

	// Log the reset in history table
	$table_name = $wpdb->prefix . 'pa_points_history';
	$table_exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table_name ) );

	if ( $table_exists ) {
		// Get all users who had points
		$users = $wpdb->get_col(
			"SELECT DISTINCT user_id FROM {$wpdb->usermeta} WHERE meta_key = 'pa_points_balance'"
		);

		$admin_user = wp_get_current_user();
		$description = sprintf( 'Azzeramento punti effettuato da %s', $admin_user->user_login );

		foreach ( $users as $uid ) {
			$wpdb->insert(
				$table_name,
				array(
					'user_id'      => $uid,
					'points'       => 0,
					'type'         => 'admin_reset',
					'description'  => $description,
					'date_created' => current_time( 'mysql' ),
				),
				array( '%d', '%s', '%s', '%s', '%s' )
			);
		}
	}

	wp_send_json_success( array(
		'message' => sprintf( '✅ Punti azzerati per %d utenti.', intval( $users_with_points ) ),
		'count'   => intval( $users_with_points ),
	) );
}

// AJAX handler: fetch a single user's points history across every network site
add_action( 'wp_ajax_pa_get_user_history', 'PA_ajax_get_user_history' );
function PA_ajax_get_user_history() {
	check_ajax_referer( 'pa_get_user_history_nonce', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( 'Non autorizzato.' );
	}

	$user_id = isset( $_POST['user_id'] ) ? intval( $_POST['user_id'] ) : 0;
	$user    = $user_id ? get_userdata( $user_id ) : false;
	if ( ! $user ) {
		wp_send_json_error( 'Utente non trovato.' );
	}

	$history    = PA_get_user_history_network( $user_id, 200 );
	$has_multi  = count( PA_get_network_history_sites() ) > 1;
	$date_fmt   = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );

	$rows = array_map( function( $entry ) use ( $date_fmt ) {
		return array(
			'date'        => date_i18n( $date_fmt, strtotime( $entry->date_created ) ),
			'site_name'   => isset( $entry->site_name ) ? $entry->site_name : '',
			'description' => $entry->description,
			'points'      => (float) $entry->points,
			'type'        => $entry->type,
			'order_id'    => $entry->order_id ? intval( $entry->order_id ) : null,
			'order_url'   => $entry->order_id ? admin_url( 'post.php?post=' . intval( $entry->order_id ) . '&action=edit' ) : null,
		);
	}, $history );

	wp_send_json_success( array(
		'name'        => $user->display_name,
		'email'       => $user->user_email,
		'balance'     => (float) get_user_meta( $user_id, 'pa_points_balance', true ),
		'has_multi'   => $has_multi,
		'rows'        => $rows,
	) );
}

// Get points statistics report
/**
 * Returns every network site whose own `pa_points_history` table exists
 * (i.e. actually has activity), tagged with its blog_id/name/table prefix.
 * On a single-site install this is just the current site.
 *
 * Point balances live in the network-wide (shared) wp_usermeta table, but
 * history rows are written per-site -- each branch's WordPress install logs
 * its own earn/redeem events into its own `{prefix}pa_points_history` table.
 * Any stat/report that needs "earned" or "used" totals must therefore loop
 * over every site in the network rather than only the current one, or it
 * will silently miss all activity that happened on other sites (this is
 * exactly what caused the dashboard to show 0 earned/used while the total
 * balance was correct).
 */
function PA_get_network_history_sites() {
	global $wpdb;

	if ( ! is_multisite() ) {
		$table  = $wpdb->prefix . 'pa_points_history';
		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		if ( ! $exists ) {
			return array();
		}
		return array(
			array(
				'blog_id' => get_current_blog_id(),
				'name'    => get_bloginfo( 'name' ),
				'table'   => $table,
			),
		);
	}

	$sites       = array();
	$linked_ids  = PA_get_linked_site_ids();
	$all_ms      = get_sites( array( 'number' => 0 ) );
	foreach ( $all_ms as $ms_site ) {
		$blog_id = (int) $ms_site->blog_id;
		if ( ! in_array( $blog_id, $linked_ids, true ) ) {
			continue;
		}
		switch_to_blog( $blog_id );
		$table  = $wpdb->prefix . 'pa_points_history';
		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		if ( $exists ) {
			$sites[] = array(
				'blog_id' => $blog_id,
				'name'    => get_bloginfo( 'name' ),
				'table'   => $table,
			);
		}
		restore_current_blog();
	}
	return $sites;
}

/**
 * Distinct user IDs that have at least one points-history row on any of the
 * given (already hub-filtered) sites. Used to scope "which users belong to
 * this loyalty network" everywhere a report would otherwise fall back to
 * every user on the shared multisite `wp_usermeta` table -- balances live
 * network-wide, but only users with real activity on THIS hub's sites should
 * ever show up in THIS hub's admin.
 */
function PA_get_relevant_user_ids( $sites ) {
	global $wpdb;
	$is_ms = is_multisite();
	$ids   = array();

	foreach ( $sites as $site ) {
		if ( $is_ms ) {
			switch_to_blog( $site['blog_id'] );
		}
		$table = $site['table'];
		$rows  = $wpdb->get_col( "SELECT DISTINCT user_id FROM $table" );
		if ( $is_ms ) {
			restore_current_blog();
		}
		foreach ( $rows as $uid ) {
			$ids[ (int) $uid ] = true;
		}
	}

	return array_keys( $ids );
}

function PA_get_points_stats() {
	global $wpdb;

	$sites             = PA_get_network_history_sites();
	$relevant_user_ids = PA_get_relevant_user_ids( $sites );

	// 1. Total points currently in credit -- only for users with activity on
	// this hub's own linked sites (pa_points_balance is a shared usermeta
	// value across the whole multisite network, so an unscoped SUM() here
	// would silently include every other hub's users too).
	$total_active_points = 0.0;
	if ( ! empty( $relevant_user_ids ) ) {
		$placeholders         = implode( ',', array_fill( 0, count( $relevant_user_ids ), '%d' ) );
		$total_active_points  = (float) $wpdb->get_var( $wpdb->prepare(
			"SELECT SUM(CAST(meta_value AS DECIMAL(10,2))) FROM {$wpdb->usermeta}
			 WHERE meta_key = 'pa_points_balance' AND user_id IN ($placeholders)",
			$relevant_user_ids
		) );
	}

	$stats = array(
		'active_credit' => $total_active_points,
		'earned_month'  => 0,
		'earned_year'   => 0,
		'used_month'    => 0,
		'used_year'     => 0,
	);

	if ( empty( $sites ) ) {
		return $stats;
	}

	$current_month = date( 'Y-m-01 00:00:00' );
	$current_year  = date( 'Y-01-01 00:00:00' );
	$is_ms         = is_multisite();

	foreach ( $sites as $site ) {
		if ( $is_ms ) {
			switch_to_blog( $site['blog_id'] );
		}
		$history_table = $site['table'];

		$stats['earned_month'] += (float) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT SUM(points) FROM $history_table WHERE type = 'earned' AND date_created >= %s",
				$current_month
			)
		);
		$stats['earned_year'] += (float) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT SUM(points) FROM $history_table WHERE type = 'earned' AND date_created >= %s",
				$current_year
			)
		);
		$stats['used_month'] += abs( (float) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT SUM(points) FROM $history_table WHERE type = 'redeemed' AND date_created >= %s",
				$current_month
			)
		) );
		$stats['used_year'] += abs( (float) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT SUM(points) FROM $history_table WHERE type = 'redeemed' AND date_created >= %s",
				$current_year
			)
		) );

		if ( $is_ms ) {
			restore_current_blog();
		}
	}

	return $stats;
}

/**
 * Builds the per-user points breakdown shown when a dashboard stat card is
 * clicked: current balance, plus earned/used totals per network site (only
 * meaningful -- and only computed -- when more than one site has history).
 * Capped to the top N users by balance to keep the admin page responsive.
 */
function PA_get_points_breakdown_data( $limit = 500 ) {
	global $wpdb;

	$sites = PA_get_network_history_sites();
	$is_ms = is_multisite();

	$users = array();

	// Seed only with users who actually have activity on THIS hub's linked
	// sites -- pa_points_balance is shared network-wide usermeta, so without
	// this restriction every other hub's users (e.g. Mache Pizza users showing
	// up in Little Inka's admin, or vice versa) would leak into the table.
	$relevant_user_ids = PA_get_relevant_user_ids( $sites );
	if ( ! empty( $relevant_user_ids ) ) {
		$placeholders = implode( ',', array_fill( 0, count( $relevant_user_ids ), '%d' ) );
		$balance_rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT user_id, meta_value AS balance FROM {$wpdb->usermeta}
			 WHERE meta_key = 'pa_points_balance' AND user_id IN ($placeholders)
			 ORDER BY CAST(meta_value AS DECIMAL(10,2)) DESC
			 LIMIT " . (int) $limit,
			$relevant_user_ids
		) );
		foreach ( $balance_rows as $row ) {
			$uid                      = (int) $row->user_id;
			$users[ $uid ]['balance'] = (float) $row->balance;
		}
	}

	foreach ( $sites as $site ) {
		if ( $is_ms ) {
			switch_to_blog( $site['blog_id'] );
		}
		$table = $site['table'];
		$rows  = $wpdb->get_results(
			"SELECT user_id,
			        SUM(CASE WHEN type = 'earned' THEN points ELSE 0 END) AS earned,
			        SUM(CASE WHEN type = 'redeemed' THEN ABS(points) ELSE 0 END) AS used
			 FROM $table
			 GROUP BY user_id"
		);
		if ( $is_ms ) {
			restore_current_blog();
		}

		foreach ( $rows as $row ) {
			$uid = (int) $row->user_id;
			if ( ! isset( $users[ $uid ] ) ) {
				// Only pull in users outside the balance-seeded top N if
				// they actually have history activity worth showing.
				if ( count( $users ) >= $limit && (float) $row->earned === 0.0 && (float) $row->used === 0.0 ) {
					continue;
				}
				$users[ $uid ]['balance'] = (float) get_user_meta( $uid, 'pa_points_balance', true );
			}
			$users[ $uid ]['sites'][ $site['blog_id'] ] = array(
				'earned' => (float) $row->earned,
				'used'   => (float) $row->used,
			);
		}
	}

	$result = array();
	foreach ( $users as $uid => $data ) {
		$user = get_userdata( $uid );
		if ( ! $user ) {
			continue;
		}
		$total_earned = 0.0;
		$total_used   = 0.0;
		$per_site     = array();
		foreach ( $sites as $site ) {
			$earned = isset( $data['sites'][ $site['blog_id'] ]['earned'] ) ? $data['sites'][ $site['blog_id'] ]['earned'] : 0.0;
			$used   = isset( $data['sites'][ $site['blog_id'] ]['used'] ) ? $data['sites'][ $site['blog_id'] ]['used'] : 0.0;
			$total_earned += $earned;
			$total_used   += $used;
			$per_site[]    = array(
				'blog_id' => $site['blog_id'],
				'name'    => $site['name'],
				'earned'  => $earned,
				'used'    => $used,
			);
		}
		$result[] = array(
			'user_id'      => $uid,
			'name'         => $user->display_name,
			'email'        => $user->user_email,
			'balance'      => $data['balance'],
			'total_earned' => $total_earned,
			'total_used'   => $total_used,
			'sites'        => $per_site,
		);
	}

	return array(
		'sites' => $sites,
		'users' => $result,
	);
}

// ============================================
// Users list: add Points Balance column
// ============================================
add_filter( 'manage_users_columns', 'PA_add_user_points_column' );
function PA_add_user_points_column( $columns ) {
	$columns['pa_points'] = __( '💎 Punti', 'punti-acquisto' );
	return $columns;
}

add_filter( 'manage_users_custom_column', 'PA_show_user_points_column', 10, 3 );
function PA_show_user_points_column( $output, $column_name, $user_id ) {
	if ( $column_name === 'pa_points' ) {
		$balance = (float) get_user_meta( $user_id, 'pa_points_balance', true );
		if ( $balance > 0 ) {
			return '<strong style="color: #2e7d32;">' . number_format( $balance, 0, '.', "'" ) . '</strong>';
		}
		return '<span style="color: #999;">0</span>';
	}
	return $output;
}

add_filter( 'manage_users_sortable_columns', 'PA_sortable_points_column' );
function PA_sortable_points_column( $columns ) {
	$columns['pa_points'] = 'pa_points';
	return $columns;
}

add_action( 'pre_get_users', 'PA_sort_by_points' );
function PA_sort_by_points( $query ) {
	if ( ! is_admin() ) return;
	if ( $query->get( 'orderby' ) === 'pa_points' ) {
		$query->set( 'meta_key', 'pa_points_balance' );
		$query->set( 'orderby', 'meta_value_num' );
	}
}

// Point labels helper
function PA_get_point_labels() {
	$singular = PA_get_option( 'pa_point_label_singular', 'Point' );
	$plural   = PA_get_option( 'pa_point_label_plural', 'Points' );

	$singular = $singular ? $singular : 'Point';
	$plural   = $plural ? $plural : 'Points';

	return [
		'singular' => $singular,
		'plural'   => $plural,
	];
}

function PA_format_point_label( $amount ) {
	$labels = PA_get_point_labels();
	return ( abs( (float) $amount ) === 1.0 ) ? $labels['singular'] : $labels['plural'];
}

// Money helper (WooCommerce currency)
function PA_money( $amount ) {
	if ( function_exists( 'wc_price' ) ) {
		return wc_price( $amount );
	}
	return number_format( (float) $amount, 2, '.', "'" );
}

// Settings page
function PA_settings_page() {
	$hub_blog_id = PA_get_management_hub_blog_id();
	if ( is_multisite() && get_current_blog_id() !== $hub_blog_id ) {
		$hub_name = get_blog_option( $hub_blog_id, 'blogname' );
		$hub_url  = get_blog_option( $hub_blog_id, 'siteurl' );
		?>
		<div class="wrap">
			<div style="display:flex; align-items:center; gap: 15px; margin-bottom: 20px; margin-top: 15px;">
				<img src="<?php echo esc_url( plugin_dir_url( __FILE__ ) . 'assets/logo-ticinoweb-2025.png' ); ?>" alt="TicinoWEB" style="max-height: 50px;" />
				<div>
					<h2 style="margin: 0; padding: 0; font-size: 23px; font-weight: 400; line-height: 1.3;"><?php esc_html_e( 'Simple Point System Settings', 'punti-acquisto' ); ?></h2>
					<p style="margin: 0; color: #666;"><small>Versione 1.9.5</small></p>
				</div>
			</div>
			<div class="notice notice-info">
				<p>ℹ️ <strong>Gestione Centralizzata:</strong> Le impostazioni del sistema punti sono gestite centralmente sul sito principale di management (<a href="<?php echo esc_url( $hub_url ); ?>" target="_blank"><?php echo esc_html( $hub_name ?: $hub_url ); ?></a>) e sono condivise su tutto il network.</p>
			</div>
		</div>
		<?php
		return;
	}

	$point_value = (float) PA_get_option( 'pa_point_value', 1 );
	$point_cost  = (float) PA_get_option( 'pa_point_cost', 10 );
	$earning_mode = PA_sanitize_earning_mode( PA_get_option( 'pa_earning_mode', 'spend_based' ) );
	$fixed_points = PA_sanitize_nonnegative_int( PA_get_option( 'pa_fixed_points_per_order', 10 ) );
	$redemption_max = PA_sanitize_nonnegative_int( PA_get_option( 'pa_redemption_max_points', 0 ) );
	$redemption_step = PA_sanitize_positive_int( PA_get_option( 'pa_redemption_step', 1 ) );
	$labels      = PA_get_point_labels();
	$api_secret  = PA_get_option( 'pa_api_secret', PA_API_SECRET_DEFAULT );
	$stats       = PA_get_points_stats();
	$breakdown   = PA_get_points_breakdown_data();
	$bd_sites    = $breakdown['sites'];
	$bd_users    = $breakdown['users'];
	$has_multi_sites = count( $bd_sites ) > 1;
	?>
	<div class="wrap">
		<h1 style="display:none;"><?php esc_html_e( 'Simple Point System Settings', 'punti-acquisto' ); ?></h1>
		<div style="display:flex; align-items:center; gap: 15px; margin-bottom: 20px; margin-top: 15px;">
			<img src="<?php echo esc_url( plugin_dir_url( __FILE__ ) . 'assets/logo-ticinoweb-2025.png' ); ?>" alt="TicinoWEB" style="max-height: 50px;" />
			<div>
				<h2 style="margin: 0; padding: 0; font-size: 23px; font-weight: 400; line-height: 1.3;"><?php esc_html_e( 'Simple Point System Settings', 'punti-acquisto' ); ?></h2>
				<p style="margin: 0; color: #666;"><small>Versione 1.9.5</small></p>
			</div>
		</div>

		<!-- Dashboard Resoconto Statistiche -->
		<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 15px; margin-bottom: 10px; max-width: 1000px;">
			<div class="pa-stat-card" data-pa-sort="balance" style="cursor: pointer; background: #fff; border: 1px solid #ccd0d4; border-radius: 6px; padding: 15px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); border-left: 4px solid #2271b1;">
				<h4 style="margin: 0 0 8px 0; color: #646970; font-size: 13px; font-weight: 600; text-transform: uppercase;"><?php esc_html_e( 'Punti in Circolazione', 'punti-acquisto' ); ?></h4>
				<div style="font-size: 24px; font-weight: bold; color: #1d2327;">
					<?php echo number_format( $stats['active_credit'], 0, '.', "'" ); ?>
				</div>
				<p style="margin: 5px 0 0 0; color: #646970; font-size: 12px;"><?php esc_html_e( 'Totale credito residuo nei conti utenti', 'punti-acquisto' ); ?> &middot; <span style="color:#2271b1;">clicca per dettagli ▾</span></p>
			</div>

			<div class="pa-stat-card" data-pa-sort="earned" style="cursor: pointer; background: #fff; border: 1px solid #ccd0d4; border-radius: 6px; padding: 15px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); border-left: 4px solid #46b450;">
				<h4 style="margin: 0 0 8px 0; color: #646970; font-size: 13px; font-weight: 600; text-transform: uppercase;"><?php esc_html_e( 'Punti Guadagnati', 'punti-acquisto' ); ?></h4>
				<div style="font-size: 20px; font-weight: bold; color: #1d2327;">
					Mese: <span style="color: #46b450;"><?php echo number_format( $stats['earned_month'], 0, '.', "'" ); ?></span>
				</div>
				<div style="font-size: 15px; color: #646970; margin-top: 3px;">
					Anno: <strong><?php echo number_format( $stats['earned_year'], 0, '.', "'" ); ?></strong>
				</div>
				<p style="margin: 5px 0 0 0; font-size: 12px;"><span style="color:#2271b1;">clicca per dettagli ▾</span></p>
			</div>

			<div class="pa-stat-card" data-pa-sort="used" style="cursor: pointer; background: #fff; border: 1px solid #ccd0d4; border-radius: 6px; padding: 15px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); border-left: 4px solid #ffb900;">
				<h4 style="margin: 0 0 8px 0; color: #646970; font-size: 13px; font-weight: 600; text-transform: uppercase;"><?php esc_html_e( 'Punti Usati (Sconto)', 'punti-acquisto' ); ?></h4>
				<div style="font-size: 20px; font-weight: bold; color: #1d2327;">
					Mese: <span style="color: #ffb900;"><?php echo number_format( $stats['used_month'], 0, '.', "'" ); ?></span>
				</div>
				<div style="font-size: 15px; color: #646970; margin-top: 3px;">
					Anno: <strong><?php echo number_format( $stats['used_year'], 0, '.', "'" ); ?></strong>
				</div>
				<p style="margin: 5px 0 0 0; font-size: 12px;"><span style="color:#2271b1;">clicca per dettagli ▾</span></p>
			</div>
		</div>

		<!-- Dettaglio utenti punti (mostrato al click di una delle card sopra) -->
		<div id="pa-user-breakdown-wrap" style="display:none; margin-bottom: 25px; max-width: 100%;">
			<div style="background:#fff; border:1px solid #ccd0d4; border-radius:6px; padding:15px 20px 20px;">
				<div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:10px;">
					<h3 style="margin:0;" id="pa-user-breakdown-title"><?php esc_html_e( 'Dettaglio utenti', 'punti-acquisto' ); ?></h3>
					<button type="button" class="button" id="pa-user-breakdown-close">✕ <?php esc_html_e( 'Chiudi', 'punti-acquisto' ); ?></button>
				</div>
				<?php if ( empty( $bd_users ) ) : ?>
					<p><?php esc_html_e( 'Nessun utente con attività punti al momento.', 'punti-acquisto' ); ?></p>
				<?php else : ?>
					<div style="overflow-x:auto;">
					<table class="widefat striped" id="pa-user-breakdown-table">
						<thead>
							<tr>
								<th rowspan="2" style="vertical-align:bottom;"><?php esc_html_e( 'Utente', 'punti-acquisto' ); ?></th>
								<th rowspan="2" style="vertical-align:bottom;"><?php esc_html_e( 'Saldo Attuale', 'punti-acquisto' ); ?></th>
								<?php if ( $has_multi_sites ) : ?>
									<?php foreach ( $bd_sites as $site ) : ?>
										<th colspan="2" style="text-align:center; border-left:1px solid #dcdcde;"><?php echo esc_html( $site['name'] ); ?></th>
									<?php endforeach; ?>
									<th colspan="2" style="text-align:center; border-left:2px solid #ccd0d4;"><?php esc_html_e( 'Totale (tutte le filiali)', 'punti-acquisto' ); ?></th>
								<?php else : ?>
									<th rowspan="2" style="vertical-align:bottom;"><?php esc_html_e( 'Guadagnati', 'punti-acquisto' ); ?></th>
									<th rowspan="2" style="vertical-align:bottom;"><?php esc_html_e( 'Usati', 'punti-acquisto' ); ?></th>
								<?php endif; ?>
							</tr>
							<?php if ( $has_multi_sites ) : ?>
								<tr>
									<?php foreach ( $bd_sites as $site ) : ?>
										<th style="border-left:1px solid #dcdcde; color:#46b450;"><?php esc_html_e( 'Guad.', 'punti-acquisto' ); ?></th>
										<th style="color:#b8860b;"><?php esc_html_e( 'Usati', 'punti-acquisto' ); ?></th>
									<?php endforeach; ?>
									<th style="border-left:2px solid #ccd0d4; color:#46b450;"><?php esc_html_e( 'Guad.', 'punti-acquisto' ); ?></th>
									<th style="color:#b8860b;"><?php esc_html_e( 'Usati', 'punti-acquisto' ); ?></th>
								</tr>
							<?php endif; ?>
						</thead>
						<tbody>
							<?php foreach ( $bd_users as $u ) : ?>
								<tr data-balance="<?php echo esc_attr( $u['balance'] ); ?>" data-earned="<?php echo esc_attr( $u['total_earned'] ); ?>" data-used="<?php echo esc_attr( $u['total_used'] ); ?>">
									<td>
										<a href="#" class="pa-user-history-link" data-user-id="<?php echo esc_attr( $u['user_id'] ); ?>" style="text-decoration:none;">
											<strong style="color:#2271b1;"><?php echo esc_html( $u['name'] ); ?></strong><br />
											<span style="color:#646970; font-size:12px;"><?php echo esc_html( $u['email'] ); ?></span>
										</a>
									</td>
									<td><strong><?php echo number_format( $u['balance'], 0, '.', "'" ); ?></strong></td>
									<?php if ( $has_multi_sites ) : ?>
										<?php foreach ( $u['sites'] as $s ) : ?>
											<td style="border-left:1px solid #dcdcde; color:#2e7d32;"><?php echo number_format( $s['earned'], 0, '.', "'" ); ?></td>
											<td style="color:#8a6d00;"><?php echo number_format( $s['used'], 0, '.', "'" ); ?></td>
										<?php endforeach; ?>
										<td style="border-left:2px solid #ccd0d4; color:#2e7d32;"><strong><?php echo number_format( $u['total_earned'], 0, '.', "'" ); ?></strong></td>
										<td style="color:#8a6d00;"><strong><?php echo number_format( $u['total_used'], 0, '.', "'" ); ?></strong></td>
									<?php else : ?>
										<td style="color:#2e7d32;"><?php echo number_format( $u['total_earned'], 0, '.', "'" ); ?></td>
										<td style="color:#8a6d00;"><?php echo number_format( $u['total_used'], 0, '.', "'" ); ?></td>
									<?php endif; ?>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
					</div>
					<p style="margin-top:10px; color:#646970; font-size:12px;"><?php echo esc_html( sprintf( __( 'Mostrati %d utenti.', 'punti-acquisto' ), count( $bd_users ) ) ); ?></p>
				<?php endif; ?>
			</div>
		</div>

		<!-- Modal: cronologia punti per singolo utente -->
		<div id="pa-user-history-overlay" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.5); z-index:100000;">
			<div style="background:#fff; border-radius:6px; max-width:900px; width:90%; max-height:80vh; overflow-y:auto; margin:5vh auto; padding:20px 25px;">
				<div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:5px;">
					<h2 style="margin:0;" id="pa-user-history-name">&nbsp;</h2>
					<button type="button" class="button" id="pa-user-history-close">✕ <?php esc_html_e( 'Chiudi', 'punti-acquisto' ); ?></button>
				</div>
				<p style="color:#646970; margin-top:0;" id="pa-user-history-email">&nbsp;</p>
				<div id="pa-user-history-body">
					<p><?php esc_html_e( 'Caricamento…', 'punti-acquisto' ); ?></p>
				</div>
			</div>
		</div>

		<script>
		(function($) {
			var titles = {
				balance: '<?php echo esc_js( __( 'Utenti per Saldo Attuale', 'punti-acquisto' ) ); ?>',
				earned:  '<?php echo esc_js( __( 'Utenti per Punti Guadagnati', 'punti-acquisto' ) ); ?>',
				used:    '<?php echo esc_js( __( 'Utenti per Punti Usati', 'punti-acquisto' ) ); ?>'
			};

			function sortBreakdownTable(sortKey) {
				var $tbody = $('#pa-user-breakdown-table tbody');
				var $rows = $tbody.find('tr').get();
				$rows.sort(function(a, b) {
					var av = parseFloat($(a).data(sortKey)) || 0;
					var bv = parseFloat($(b).data(sortKey)) || 0;
					return bv - av;
				});
				$.each($rows, function(i, row) {
					$tbody.append(row);
				});
			}

			$('.pa-stat-card').on('click', function() {
				var sortKey = $(this).data('pa-sort');
				$('#pa-user-breakdown-title').text(titles[sortKey] || titles.balance);
				sortBreakdownTable(sortKey);
				$('#pa-user-breakdown-wrap').slideDown(150);
				$('html, body').animate({
					scrollTop: $('#pa-user-breakdown-wrap').offset().top - 40
				}, 300);
			});

			$('#pa-user-breakdown-close').on('click', function() {
				$('#pa-user-breakdown-wrap').slideUp(150);
			});

			// Per-user points history modal
			function escapeHtml(str) {
				return $('<div>').text(str == null ? '' : str).html();
			}

			function renderHistoryRows(data) {
				if (!data.rows || data.rows.length === 0) {
					return '<p><?php echo esc_js( __( 'Nessuna attività punti per questo utente.', 'punti-acquisto' ) ); ?></p>';
				}
				var cols = '<th><?php echo esc_js( __( 'Data', 'punti-acquisto' ) ); ?></th>';
				if (data.has_multi) {
					cols += '<th><?php echo esc_js( __( 'Filiale', 'punti-acquisto' ) ); ?></th>';
				}
				cols += '<th><?php echo esc_js( __( 'Descrizione', 'punti-acquisto' ) ); ?></th>' +
					'<th><?php echo esc_js( __( 'Punti', 'punti-acquisto' ) ); ?></th>' +
					'<th><?php echo esc_js( __( 'Tipo', 'punti-acquisto' ) ); ?></th>' +
					'<th><?php echo esc_js( __( 'Ordine', 'punti-acquisto' ) ); ?></th>';

				var rows = data.rows.map(function(r) {
					var pointsColor = r.points > 0 ? '#2e7d32' : '#c62828';
					var pointsSign = r.points > 0 ? '+' : '';
					var typeLabel = r.type === 'earned'
						? '<span style="color:#2e7d32;">✓ <?php echo esc_js( __( 'Guadagnati', 'punti-acquisto' ) ); ?></span>'
						: (r.type === 'redeemed'
							? '<span style="color:#c62828;">⤷ <?php echo esc_js( __( 'Usati', 'punti-acquisto' ) ); ?></span>'
							: escapeHtml(r.type));
					var orderCell = r.order_id
						? '<a href="' + r.order_url + '">#' + r.order_id + '</a>'
						: '—';
					var siteCell = data.has_multi ? ('<td>' + escapeHtml(r.site_name) + '</td>') : '';

					return '<tr>' +
						'<td>' + escapeHtml(r.date) + '</td>' +
						siteCell +
						'<td>' + escapeHtml(r.description) + '</td>' +
						'<td><strong style="color:' + pointsColor + ';">' + pointsSign + Math.round(r.points) + '</strong></td>' +
						'<td>' + typeLabel + '</td>' +
						'<td>' + orderCell + '</td>' +
						'</tr>';
				}).join('');

				return '<table class="widefat striped"><thead><tr>' + cols + '</tr></thead><tbody>' + rows + '</tbody></table>';
			}

			$(document).on('click', '.pa-user-history-link', function(e) {
				e.preventDefault();
				var userId = $(this).data('user-id');

				$('#pa-user-history-name').text('<?php echo esc_js( __( 'Cronologia Punti', 'punti-acquisto' ) ); ?>');
				$('#pa-user-history-email').text('');
				$('#pa-user-history-body').html('<p><?php echo esc_js( __( 'Caricamento…', 'punti-acquisto' ) ); ?></p>');
				$('#pa-user-history-overlay').css('display', 'block');

				$.post(ajaxurl, {
					action: 'pa_get_user_history',
					nonce: '<?php echo wp_create_nonce( 'pa_get_user_history_nonce' ); ?>',
					user_id: userId
				}, function(resp) {
					if (resp.success) {
						$('#pa-user-history-name').text(resp.data.name);
						$('#pa-user-history-email').text(resp.data.email + ' · <?php echo esc_js( __( 'Saldo attuale', 'punti-acquisto' ) ); ?>: ' + Math.round(resp.data.balance));
						$('#pa-user-history-body').html(renderHistoryRows(resp.data));
					} else {
						$('#pa-user-history-body').html('<p style="color:#c62828;">' + escapeHtml(resp.data) + '</p>');
					}
				}).fail(function() {
					$('#pa-user-history-body').html('<p style="color:#c62828;"><?php echo esc_js( __( 'Errore di rete.', 'punti-acquisto' ) ); ?></p>');
				});
			});

			$('#pa-user-history-close').on('click', function() {
				$('#pa-user-history-overlay').css('display', 'none');
			});
			$('#pa-user-history-overlay').on('click', function(e) {
				if (e.target === this) {
					$(this).css('display', 'none');
				}
			});
		}(jQuery));
		</script>

		<p><?php esc_html_e( 'Configure the loyalty points system for your customers.', 'punti-acquisto' ); ?></p>
		
		<form method="post" action="options.php">
			<?php settings_fields( 'pa-settings-group' ); ?>
			<table class="form-table">
				<tr valign="top">
					<th scope="row"><?php esc_html_e( 'Earning mode', 'punti-acquisto' ); ?></th>
					<td>
						<select name="pa_earning_mode">
							<option value="spend_based" <?php selected( $earning_mode, 'spend_based' ); ?>><?php esc_html_e( 'Based on amount spent', 'punti-acquisto' ); ?></option>
							<option value="fixed_order" <?php selected( $earning_mode, 'fixed_order' ); ?>><?php esc_html_e( 'Fixed points per completed order', 'punti-acquisto' ); ?></option>
						</select>
						<p class="description"><?php esc_html_e( 'Choose whether completed orders earn points from their paid total or a fixed amount.', 'punti-acquisto' ); ?></p>
					</td>
				</tr>
				<tr valign="top">
					<th scope="row"><?php esc_html_e( 'Fixed points per order', 'punti-acquisto' ); ?></th>
					<td>
						<input type="number" step="1" min="0" name="pa_fixed_points_per_order" value="<?php echo esc_attr( $fixed_points ); ?>" />
						<p class="description"><?php esc_html_e( 'Used only when fixed points per completed order is selected.', 'punti-acquisto' ); ?></p>
					</td>
				</tr>
				<tr valign="top">
					<th scope="row"><?php esc_html_e( 'Point value', 'punti-acquisto' ); ?></th>
					<td>
						<input type="number" step="0.01" min="0.01" name="pa_point_value" value="<?php echo esc_attr( $point_value ); ?>" />
						<p class="description"><?php esc_html_e( 'How much 1 point is worth when used as credit (uses your WooCommerce store currency).', 'punti-acquisto' ); ?></p>
					</td>
				</tr>
				<tr valign="top">
					<th scope="row"><?php esc_html_e( 'Point earning cost', 'punti-acquisto' ); ?></th>
					<td>
						<input type="number" step="0.01" min="0.01" name="pa_point_cost" value="<?php echo esc_attr( $point_cost ); ?>" />
						<p class="description"><?php esc_html_e( 'How much a customer must spend to earn 1 point (uses your WooCommerce store currency).', 'punti-acquisto' ); ?></p>
					</td>
				</tr>
				<tr valign="top">
					<th scope="row"><?php esc_html_e( 'Maximum points per redemption', 'punti-acquisto' ); ?></th>
					<td>
						<input type="number" step="1" min="0" name="pa_redemption_max_points" value="<?php echo esc_attr( $redemption_max ); ?>" />
						<p class="description"><?php esc_html_e( 'Maximum points usable in one order. Use 0 for no configured cap.', 'punti-acquisto' ); ?></p>
					</td>
				</tr>
				<tr valign="top">
					<th scope="row"><?php esc_html_e( 'Redemption step', 'punti-acquisto' ); ?></th>
					<td>
						<input type="number" step="1" min="1" name="pa_redemption_step" value="<?php echo esc_attr( $redemption_step ); ?>" />
						<p class="description"><?php esc_html_e( 'Points can be redeemed only in multiples of this value.', 'punti-acquisto' ); ?></p>
					</td>
				</tr>
				<tr valign="top">
					<th scope="row"><?php esc_html_e( 'Point label (singular)', 'punti-acquisto' ); ?></th>
					<td>
						<input type="text" name="pa_point_label_singular" value="<?php echo esc_attr( $labels['singular'] ); ?>" />
						<p class="description"><?php esc_html_e( 'Example: Point, Punteggio, Credit.', 'punti-acquisto' ); ?></p>
					</td>
				</tr>
				<tr valign="top">
					<th scope="row"><?php esc_html_e( 'Point label (plural)', 'punti-acquisto' ); ?></th>
					<td>
						<input type="text" name="pa_point_label_plural" value="<?php echo esc_attr( $labels['plural'] ); ?>" />
						<p class="description"><?php esc_html_e( 'Example: Points, Punti, Credits.', 'punti-acquisto' ); ?></p>
					</td>
				</tr>
				<tr valign="top">
					<th scope="row">
						<?php esc_html_e( 'REST API Secret', 'punti-acquisto' ); ?>
						<p class="description" style="margin-top: 5px; font-weight: normal; font-size: 12px; color: #666;">
							(Opzionale: questa sezione serve per poter integrare applicazioni esterne)
						</p>
					</th>
					<td>
						<div style="display:flex; align-items:center; gap:8px;">
							<input type="password" id="pa_api_secret_input" name="pa_api_secret" value="<?php echo esc_attr( $api_secret ); ?>" class="regular-text" autocomplete="new-password" />
							<button type="button" id="pa_toggle_secret" class="button" style="white-space:nowrap;">👁 Mostra</button>
						</div>
						<p class="description"><?php esc_html_e( 'Chiave segreta usata dalle Cloud Functions per autenticare le chiamate REST (header X-API-Key). Deve corrispondere al JWT_SECRET nell\'ambiente Firebase.', 'punti-acquisto' ); ?></p>
					</td>
				</tr>
				<tr valign="top" style="border-top: 1px solid #ccc;">
					<th scope="row" style="padding-top:20px; font-weight:bold; font-size:14px;">
						🏆 Livelli Fedeltà (Gamification)
					</th>
					<td style="padding-top:20px;">
						<p class="description" style="margin-bottom:10px;">Configura i nomi e le soglie di punti per ciascun livello fedeltà del cliente.</p>
					</td>
				</tr>
				<tr valign="top">
					<th scope="row">Livello Base (sotto la prima soglia)</th>
					<td>
						<input type="text" name="pa_tier_base_name" value="<?php echo esc_attr( get_option('pa_tier_base_name', '') ); ?>" placeholder="Es. Nessun livello" class="regular-text" />
						<p class="description">Nome visualizzato quando il cliente ha 0 o pochi punti (lascia vuoto per non mostrare nessuno status fino al livello 1).</p>
					</td>
				</tr>
				<tr valign="top">
					<th scope="row">Primo livello (es. Argento)</th>
					<td>
						<div style="display:flex; align-items:center; gap:10px;">
							<label>Nome: </label>
							<input type="text" name="pa_tier_silver_name" value="<?php echo esc_attr( get_option('pa_tier_silver_name', 'Argento') ); ?>" class="regular-text" style="width:200px;" />
							<label style="margin-left:15px;">Soglia punti: </label>
							<input type="number" min="1" name="pa_tier_silver_min" value="<?php echo esc_attr( get_option('pa_tier_silver_min', 101) ); ?>" style="width:100px;" />
						</div>
						<p class="description">Il livello base si applica da 0 a questa soglia meno 1.</p>
					</td>
				</tr>
				<tr valign="top">
					<th scope="row">Secondo livello (es. Oro)</th>
					<td>
						<div style="display:flex; align-items:center; gap:10px;">
							<label>Nome: </label>
							<input type="text" name="pa_tier_gold_name" value="<?php echo esc_attr( get_option('pa_tier_gold_name', 'Oro') ); ?>" class="regular-text" style="width:200px;" />
							<label style="margin-left:15px;">Soglia punti: </label>
							<input type="number" min="1" name="pa_tier_gold_min" value="<?php echo esc_attr( get_option('pa_tier_gold_min', 501) ); ?>" style="width:100px;" />
						</div>
						<p class="description">Questo livello copre i punti compresi tra il Primo livello e questa soglia meno 1.</p>
					</td>
				</tr>
				<tr valign="top">
					<th scope="row">Terzo livello (es. Platino)</th>
					<td>
						<div style="display:flex; align-items:center; gap:10px;">
							<label>Nome: </label>
							<input type="text" name="pa_tier_platinum_name" value="<?php echo esc_attr( get_option('pa_tier_platinum_name', 'Platino') ); ?>" class="regular-text" style="width:200px;" />
							<label style="margin-left:15px;">Soglia punti: </label>
							<input type="number" min="1" name="pa_tier_platinum_min" value="<?php echo esc_attr( get_option('pa_tier_platinum_min', 1501) ); ?>" style="width:100px;" />
						</div>
						<p class="description">Questo livello copre i punti a partire da questa soglia in poi.</p>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>

		<hr />
		<h2><?php esc_html_e( 'Test Connessione Firebase', 'punti-acquisto' ); ?></h2>
		<p><?php esc_html_e( 'Verifica che il secret salvato corrisponda al JWT_SECRET configurato nelle Cloud Functions.', 'punti-acquisto' ); ?></p>
		<button id="pa_test_secret" class="button button-secondary"><?php esc_html_e( '🔌 Testa connessione', 'punti-acquisto' ); ?></button>
		<span id="pa_test_result" style="margin-left:12px; font-weight:600;"></span>

		<script>
		(function($) {
			// Toggle password visibility
			$('#pa_toggle_secret').on('click', function() {
				var inp = $('#pa_api_secret_input');
				if (inp.attr('type') === 'password') {
					inp.attr('type', 'text');
					$(this).text('🙈 Nascondi');
				} else {
					inp.attr('type', 'password');
					$(this).text('👁 Mostra');
				}
			});

			// Test connection
			$('#pa_test_secret').on('click', function() {
				var btn = $(this);
				var result = $('#pa_test_result');
				btn.prop('disabled', true).text('⏳ Test in corso...');
				result.text('').css('color', '');

				$.post(ajaxurl, {
					action: 'pa_test_api_secret',
					nonce: '<?php echo wp_create_nonce( 'pa_test_secret_nonce' ); ?>'
				}, function(resp) {
					if (resp.success) {
						result.text(resp.data.message).css('color', '#2e7d32');
					} else {
						result.text(resp.data).css('color', '#c62828');
					}
				}).fail(function() {
					result.text('❌ Errore di rete').css('color', '#c62828');
				}).always(function() {
					btn.prop('disabled', false).text('🔌 Testa connessione');
				});
			});
		}(jQuery));
		</script>
		
		<hr />
		<h2><?php esc_html_e( 'How it works', 'punti-acquisto' ); ?></h2>
		<ul>
			<li><strong><?php esc_html_e( 'Earn points:', 'punti-acquisto' ); ?></strong>
				<?php if ( 'fixed_order' === $earning_mode ) : ?>
					<?php esc_html_e( 'On each completed order, the customer earns the configured fixed number of points.', 'punti-acquisto' ); ?>
				<?php else : ?>
					<?php esc_html_e( 'On each completed order, the customer earns points based on total spent ÷ point cost.', 'punti-acquisto' ); ?>
				<?php endif; ?>
			</li>
			<li><strong><?php esc_html_e( 'Redeem points:', 'punti-acquisto' ); ?></strong> <?php esc_html_e( 'At checkout, the customer can redeem points as credit. Each point uses the configured value.', 'punti-acquisto' ); ?></li>
			<li><strong><?php esc_html_e( 'Visibility:', 'punti-acquisto' ); ?></strong> <?php esc_html_e( 'At checkout the customer sees available points, points to be earned, and point value.', 'punti-acquisto' ); ?></li>
		</ul>

		<hr />
		<h2 style="color: #c62828;">⚠️ Zona Pericolosa</h2>
		<div style="border: 2px solid #c62828; border-radius: 8px; padding: 20px; background: #fff5f5; max-width: 600px;">
			<h3 style="margin-top: 0; color: #c62828;">🗑️ Azzera Tutti i Punti</h3>
			<p style="color: #555;">Questa azione imposterà il saldo punti di <strong>tutti gli utenti</strong> a zero. L'operazione viene registrata nella cronologia punti. <strong>Non può essere annullata.</strong></p>
			<button id="pa_reset_all_points" class="button" style="background: #c62828; border-color: #b71c1c; color: #fff; font-weight: bold; padding: 6px 20px;">
				🗑️ Azzera Tutti i Punti
			</button>
			<span id="pa_reset_result" style="margin-left: 12px; font-weight: 600;"></span>
		</div>

		<script>
		(function($) {
			$('#pa_reset_all_points').on('click', function() {
				var confirmed = confirm('⚠️ ATTENZIONE!\n\nStai per azzerare TUTTI i punti di TUTTI gli utenti.\n\nQuesta operazione NON può essere annullata.\n\nSei sicuro di voler procedere?');
				if (!confirmed) return;

				var confirmed2 = confirm('🔴 ULTIMA CONFERMA\n\nTutti i saldi punti verranno portati a ZERO.\n\nConfermi definitivamente?');
				if (!confirmed2) return;

				var btn = $(this);
				var result = $('#pa_reset_result');
				btn.prop('disabled', true).text('⏳ Azzeramento in corso...');
				result.text('').css('color', '');

				$.post(ajaxurl, {
					action: 'pa_reset_all_points',
					nonce: '<?php echo wp_create_nonce( 'pa_reset_all_points_nonce' ); ?>'
				}, function(resp) {
					if (resp.success) {
						result.text(resp.data.message).css('color', '#2e7d32');
					} else {
						result.text('❌ ' + resp.data).css('color', '#c62828');
					}
				}).fail(function() {
					result.text('❌ Errore di rete').css('color', '#c62828');
				}).always(function() {
					btn.prop('disabled', false).text('🗑️ Azzera Tutti i Punti');
				});
			});
		}(jQuery));
		</script>

	</div>
	<?php
}

// Get user points
function PA_get_user_points( $user_id = 0 ) {
	if ( ! $user_id ) {
		$user_id = get_current_user_id();
	}
	if ( ! $user_id ) {
		return 0;
	}
	return (float) get_user_meta( $user_id, 'pa_points_balance', true );
}

// Add points to user
function PA_add_user_points( $user_id, $points ) {
	if ( ! $user_id || $points <= 0 ) {
		return false;
	}
	return PA_credit_user_points_atomic( $user_id, $points );
}

// Deduct points from user
function PA_deduct_user_points( $user_id, $points ) {
	if ( ! $user_id || $points <= 0 ) {
		return false;
	}
	return PA_claim_user_points( $user_id, $points );
}

// Add points history entry
function PA_add_history_entry( $user_id, $points, $type, $description, $order_id = null ) {
	global $wpdb;
	$table_name = $wpdb->prefix . 'pa_points_history';
	
	$wpdb->insert(
		$table_name,
		array(
			'user_id' => $user_id,
			'points' => $points,
			'type' => $type,
			'description' => $description,
			'order_id' => $order_id,
			'date_created' => current_time( 'mysql' )
		),
		array( '%d', '%f', '%s', '%s', '%d', '%s' )
	);
}

// Get user points history
function PA_get_user_history( $user_id, $limit = 50 ) {
	global $wpdb;
	$table_name = $wpdb->prefix . 'pa_points_history';

	return $wpdb->get_results( $wpdb->prepare(
		"SELECT * FROM $table_name WHERE user_id = %d ORDER BY date_created DESC LIMIT %d",
		$user_id,
		$limit
	) );
}

/**
 * Same as PA_get_user_history(), but aggregates across every network site
 * that has a pa_points_history table -- needed because on multisite each
 * branch logs its own history in its own table. Each row is tagged with
 * the site it came from. On a single-site install this just returns that
 * site's own history (same as PA_get_user_history).
 */
function PA_get_user_history_network( $user_id, $limit = 200 ) {
	global $wpdb;
	$sites = PA_get_network_history_sites();
	$is_ms = is_multisite();

	$rows = array();
	foreach ( $sites as $site ) {
		if ( $is_ms ) {
			switch_to_blog( $site['blog_id'] );
		}
		$table = $site['table'];
		$site_rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM $table WHERE user_id = %d ORDER BY date_created DESC LIMIT %d",
			$user_id,
			$limit
		) );
		if ( $is_ms ) {
			restore_current_blog();
		}
		foreach ( $site_rows as $row ) {
			$row->site_name = $site['name'];
			$rows[] = $row;
		}
	}

	usort( $rows, function( $a, $b ) {
		return strtotime( $b->date_created ) - strtotime( $a->date_created );
	} );

	return array_slice( $rows, 0, $limit );
}

// Award points when order is completed
add_action( 'woocommerce_order_status_completed', 'PA_award_points_on_order_complete' );
function PA_award_points_on_order_complete( $order_id ) {
	$order = wc_get_order( $order_id );
	if ( ! $order ) {
		return;
	}
	
	// Check if points already awarded
	if ( $order->get_meta( '_pa_points_awarded' ) ) {
		return;
	}
	
	$user_id = $order->get_user_id();
	if ( ! $user_id ) {
		return;
	}
	
	$total = (float) $order->get_total();
	// Calculate points only on amount actually paid (the total already includes the points discount).
	$paid_amount = $total; // total is already after discount
	$amount_for_points = max( 0, $paid_amount ); // only paid amount generates points
	$points_earned = PA_calculate_order_points( $amount_for_points );
	
	if ( $points_earned > 0 ) {
		PA_add_user_points( $user_id, $points_earned );
		$order->update_meta_data( '_pa_points_awarded', $points_earned );
		$labels = PA_get_point_labels();
		$order->add_order_note( sprintf( 'Customer earned %d %s from this order.', $points_earned, PA_format_point_label( $points_earned ) ) );
		$order->save();
		
		// Add history entry
		PA_add_history_entry(
			$user_id,
			$points_earned,
			'earned',
			sprintf( 'Earned %d %s from order #%d', $points_earned, PA_format_point_label( $points_earned ), $order_id ),
			$order_id
		);
	}
}

// Restore points if order is cancelled, failed, refunded or trashed
add_action( 'woocommerce_order_status_changed', 'PA_restore_points_on_status_change', 10, 3 );
function PA_restore_points_on_status_change( $order_id, $old_status, $new_status ) {
	$order = wc_get_order( $order_id );
	if ( ! $order ) {
		return;
	}

	$target_statuses = array( 'cancelled', 'failed', 'refunded', 'trash' );
	if ( ! in_array( $new_status, $target_statuses, true ) ) {
		return;
	}

	$user_id = $order->get_user_id();
	if ( ! $user_id ) {
		return;
	}

	$points_used = (int) $order->get_meta( '_pa_points_used', true );
	if ( $points_used <= 0 ) {
		return;
	}

	// Only completed checkout claims may be restored on later status changes.
	// A claim rolled back by woocommerce_checkout_order_exception was never spent.
	if ( 'yes' !== $order->get_meta( '_pa_points_redemption_recorded', true ) ) {
		return;
	}

	// Check if already restored
	if ( $order->get_meta( '_pa_points_restored' ) === 'yes' ) {
		return;
	}

	// Restore the points
	PA_add_user_points( $user_id, $points_used );

	// Flag order to prevent double-restoration
	$order->update_meta_data( '_pa_points_restored', 'yes' );
	$order->add_order_note( sprintf( 'Restored %d %s to customer account (Order status changed to %s).', $points_used, PA_format_point_label( $points_used ), $new_status ) );
	$order->save();

	// Add history entry
	PA_add_history_entry(
		$user_id,
		$points_used,
		'restored',
		sprintf( 'Punti riaccreditati per l\'ordine #%d (Stato: %s)', $order_id, $new_status ),
		$order_id
	);
}

// Display points info in checkout
add_action( 'woocommerce_review_order_before_payment', 'PA_display_points_info' );
function PA_display_points_info() {
	if ( ! is_user_logged_in() ) {
		return;
	}
	
	$user_id = get_current_user_id();
	$available_points = PA_get_user_points( $user_id );
	$point_value = (float) PA_get_option( 'pa_point_value', 1 );
	$labels = PA_get_point_labels();
	
	$points_to_use = PA_get_applied_redeem_points();
	$point_value = (float) PA_get_option( 'pa_point_value', 1 );
	
	// Get the FINAL cart total (already includes discount fee from woocommerce_cart_calculate_fees)
	$cart_total_after_discount = WC()->cart->total;
	$discount_applied = $points_to_use * $point_value;
	$points_to_earn = PA_calculate_order_points( max( 0, $cart_total_after_discount ) );
	
	echo '<div class="pa-points-info" style="background:#f9f9f9; padding:15px; margin:15px 0; border-radius:4px;">';
	echo '<h3 style="margin-top:0;">💎 ' . esc_html__( 'Your Loyalty Points', 'punti-acquisto' ) . '</h3>';
	
	if ( $available_points > 0 ) {
		$credit_value = $available_points * $point_value;
		$label_available = PA_format_point_label( $available_points );
		echo '<p><strong>' . esc_html__( 'Available', 'punti-acquisto' ) . ' ' . esc_html( $label_available ) . ':</strong> ' . number_format( $available_points, 0, ',', "'" ) . ' ' . esc_html( $label_available ) . ' (' . esc_html__( 'value', 'punti-acquisto' ) . ': ' . PA_money( $credit_value ) . ')</p>';
	} else {
		echo '<p><strong>' . esc_html__( 'Available', 'punti-acquisto' ) . ' ' . esc_html( $labels['plural'] ) . ':</strong> 0</p>';
	}
	
	if ( $points_to_use > 0 ) {
		$label_redeem = PA_format_point_label( $points_to_use );
		echo '<p><strong>' . esc_html( $labels['plural'] ) . ' ' . esc_html__( 'discount applied', 'punti-acquisto' ) . ':</strong> -' . PA_money( $discount_applied ) . ' (' . number_format( $points_to_use, 0, ',', "'" ) . ' ' . esc_html( $label_redeem ) . ')</p>';
		if ( $cart_total_after_discount > 0 ) {
			echo '<p><strong>' . esc_html__( 'Amount to pay', 'punti-acquisto' ) . ':</strong> ' . PA_money( $cart_total_after_discount ) . '</p>';
		} else {
			echo '<p style="color:#2e7d32; font-weight:bold;">✓ ' . esc_html__( 'Order fully covered by your points', 'punti-acquisto' ) . '!</p>';
		}
	}
	
	if ( $points_to_earn > 0 ) {
		$label_earn = PA_format_point_label( $points_to_earn );
		echo '<p><strong>' . esc_html( $labels['plural'] ) . ' ' . esc_html__( 'you will earn from this order', 'punti-acquisto' ) . ':</strong> ' . number_format( $points_to_earn, 0, ',', "'" ) . ' ' . esc_html( $label_earn ) . '</p>';
	} else {
		echo '<p><strong>' . esc_html( $labels['plural'] ) . ' ' . esc_html__( 'you will earn', 'punti-acquisto' ) . ':</strong> 0 (' . esc_html__( 'payment covered by points', 'punti-acquisto' ) . ')</p>';
	}
	
	if ( 'fixed_order' === PA_sanitize_earning_mode( PA_get_option( 'pa_earning_mode', 'spend_based' ) ) ) {
		echo '<p class="description" style="font-size:12px; margin:5px 0 0 0;">1 ' . esc_html( $labels['singular'] ) . ' = ' . PA_money( $point_value ) . ' | ' . number_format_i18n( PA_calculate_order_points( $cart_total_after_discount ), 0 ) . ' ' . esc_html( $labels['plural'] ) . ' ' . esc_html__( 'for each completed order', 'punti-acquisto' ) . '</p>';
	} else {
		$point_cost = (float) PA_get_option( 'pa_point_cost', 10 );
		echo '<p class="description" style="font-size:12px; margin:5px 0 0 0;">1 ' . esc_html( $labels['singular'] ) . ' = ' . PA_money( $point_value ) . ' | ' . esc_html__( 'Earn 1', 'punti-acquisto' ) . ' ' . esc_html( $labels['singular'] ) . ' ' . esc_html__( 'every', 'punti-acquisto' ) . ' ' . PA_money( $point_cost ) . ' ' . esc_html__( 'of effective spend', 'punti-acquisto' ) . '</p>';
	}
	echo '</div>';
}

// Add points redemption field
add_action( 'woocommerce_review_order_before_payment', 'PA_redemption_field' );
function PA_redemption_field() {
	if ( ! is_user_logged_in() ) {
		return;
	}
	
	$user_id = get_current_user_id();
	$available_points = PA_get_user_points( $user_id );
	
	if ( $available_points <= 0 ) {
		return;
	}
	
	$point_value = (float) PA_get_option( 'pa_point_value', 1 );
	$cart_total = PA_get_cart_total_before_points( WC()->cart );
	$max_points = PA_get_max_redeemable_points( $available_points, $cart_total );
	$max_redeemable = $max_points * $point_value;
	$redemption_step = PA_sanitize_positive_int( PA_get_option( 'pa_redemption_step', 1 ) );
	$labels = PA_get_point_labels();
	
	if ( $max_points <= 0 ) {
		return;
	}
	
	?>
	<div class="pa-redeem-points" style="background:#e7f7e7; padding:15px; margin:15px 0; border-radius:4px; border:1px solid #4caf50;">
		<h3 style="margin-top:0; color:#2e7d32;">✨ <?php esc_html_e( 'Redeem Your Points', 'punti-acquisto' ); ?></h3>
		<p style="margin:0;">
			<label for="pa_points_to_use" style="display:block; margin-bottom:12px;">
				<strong><?php esc_html_e( 'How many', 'punti-acquisto' ); ?> <?php echo esc_html( PA_format_point_label( 2 ) ); ?> <?php esc_html_e( 'do you want to use', 'punti-acquisto' ); ?>?</strong> (<?php esc_html_e( 'max', 'punti-acquisto' ); ?> <?php echo number_format( $max_points, 0, ',', "'" ); ?> <?php echo esc_html( PA_format_point_label( $max_points ) ); ?> = <?php echo PA_money( $max_redeemable ); ?>)
			</label>
			<div style="display:flex; gap:2mm; align-items:center;">
				<input type="number" id="pa_points_to_use" name="pa_points_to_use" min="0" max="<?php echo esc_attr( $max_points ); ?>" step="<?php echo esc_attr( $redemption_step ); ?>" value="0" style="width:120px;" />
				<button type="button" id="pa_apply_points" class="button" style="color:#fff; background:#2e7d32; border-color:#2e7d32; font-weight:600;"><?php esc_html_e( 'Apply', 'punti-acquisto' ); ?> <?php echo esc_html( $labels['plural'] ); ?></button>
			</div>
		</p>
		<p class="description" style="font-size:12px; margin:8px 0 0 0;"><?php esc_html_e( 'Enter the number of', 'punti-acquisto' ); ?> <?php echo esc_html( $labels['plural'] ); ?> <?php esc_html_e( 'to use as credit and click', 'punti-acquisto' ); ?> "<?php esc_html_e( 'Apply', 'punti-acquisto' ); ?> <?php echo esc_html( $labels['plural'] ); ?>" <?php esc_html_e( 'to refresh the total', 'punti-acquisto' ); ?>.</p>
	</div>
	<script>
	jQuery(function($){
		$(document).on('click', '#pa_apply_points', function(e){
			e.preventDefault();
			// Ensure WooCommerce has the value when updating checkout
			$('body').trigger('update_checkout');
		});
		$(document).on('change', '#pa_points_to_use', function(){
			$('body').trigger('update_checkout');
		});
	});
	</script>
	<?php
}

// Apply points discount
add_action( 'woocommerce_cart_calculate_fees', 'PA_apply_points_discount', 99 );
function PA_apply_points_discount() {
	if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
		return;
	}
	
	if ( ! is_user_logged_in() ) {
		return;
	}
	
	// Try to get the value from direct POST first (direct form submission)
	$points_to_use = isset( $_POST['pa_points_to_use'] ) ? (int) $_POST['pa_points_to_use'] : 0;
	
	// If empty, try to get from WooCommerce's serialized post_data (AJAX update_checkout)
	if ( $points_to_use === 0 && isset( $_POST['post_data'] ) ) {
		$post_data = [];
		parse_str( sanitize_text_field( wp_unslash( $_POST['post_data'] ) ), $post_data );
		$points_to_use = isset( $post_data['pa_points_to_use'] ) ? (int) $post_data['pa_points_to_use'] : 0;
	}
	
	if ( $points_to_use <= 0 ) {
		PA_set_applied_redeem_points( 0 );
		return;
	}
	
	$user_id = get_current_user_id();
	$available_points = PA_get_user_points( $user_id );
	$cart_total = PA_get_cart_total_before_points( WC()->cart );
	$points_to_use = PA_normalize_redeem_points( $points_to_use, $available_points, $cart_total );
	PA_set_applied_redeem_points( $points_to_use );

	$point_value = (float) PA_get_option( 'pa_point_value', 1 );
	$discount = $points_to_use * $point_value;
	
	if ( $discount > 0 ) {
		WC()->cart->add_fee( sprintf( '%s Discount (-%d %s)', PA_get_point_labels()['plural'], $points_to_use, PA_format_point_label( $points_to_use ) ), -$discount );
	}
}

// Ensure pa_points_to_use is captured in checkout data
add_filter( 'woocommerce_checkout_posted_data', 'PA_add_points_to_checkout_data' );
function PA_add_points_to_checkout_data( $data ) {
	if ( isset( $_POST['pa_points_to_use'] ) ) {
		$data['pa_points_to_use'] = (int) $_POST['pa_points_to_use'];
	}
	return $data;
}

// Store the exact points amount applied by the fee calculation on the order.
add_action( 'woocommerce_checkout_create_order', 'PA_store_applied_points_on_order', 10, 2 );
function PA_store_applied_points_on_order( $order, $checkout_data ) {
	$user_id = $order->get_user_id();
	if ( ! $user_id ) {
		return;
	}

	$points_to_use = PA_normalize_applied_points(
		PA_get_applied_redeem_points(),
		PA_get_user_points( $user_id )
	);

	if ( $points_to_use > 0 ) {
		if ( ! PA_claim_user_points( $user_id, $points_to_use ) ) {
			throw new Exception( esc_html__( 'Your points balance changed. Please review the order and try again.', 'punti-acquisto' ) );
		}
		$order->update_meta_data( '_pa_points_used', $points_to_use );
		$order->update_meta_data( '_pa_points_claimed', 'yes' );
	}
}

// Restore an atomic claim when WooCommerce cannot persist the new order.
add_action( 'woocommerce_checkout_order_exception', 'PA_restore_points_after_checkout_exception', 10, 1 );
function PA_restore_points_after_checkout_exception( $order ) {
	if ( ! is_object( $order ) || 'yes' !== $order->get_meta( '_pa_points_claimed', true ) ) {
		return;
	}

	$user_id = (int) $order->get_user_id();
	$points  = (float) $order->get_meta( '_pa_points_used', true );
	if ( $user_id > 0 && $points > 0 ) {
		PA_credit_user_points_atomic( $user_id, $points );
	}

	$order->delete_meta_data( '_pa_points_claimed' );
	$order->update_meta_data( '_pa_points_claim_rolled_back', 'yes' );
	if ( method_exists( $order, 'get_id' ) && $order->get_id() > 0 ) {
		try {
			$order->save_meta_data();
		} catch ( Throwable $error ) {
			// The redemption-recorded guard above still prevents a later double credit.
		}
	}
	PA_set_applied_redeem_points( 0 );
}

// Hide payment methods if points cover full amount
add_filter( 'woocommerce_available_payment_gateways', 'PA_hide_payment_if_fully_covered' );
function PA_hide_payment_if_fully_covered( $gateways ) {
	if ( is_admin() || ! is_checkout() ) {
		return $gateways;
	}
	
	if ( ! is_user_logged_in() ) {
		return $gateways;
	}
	
	// Check the total AFTER fees have been applied
	$cart_total = WC()->cart->get_total( 'edit' );
	
	// If total is 0 or negative (fully covered by points), hide payment gateways
	if ( $cart_total <= 0 ) {
		return [];
	}
	
	return $gateways;
}

// Deduct points after order completion
add_action( 'woocommerce_checkout_order_processed', 'PA_deduct_points_on_checkout', 10, 1 );
function PA_deduct_points_on_checkout( $order_id ) {
	$order = wc_get_order( $order_id );
	if ( ! $order ) {
		return;
	}
	
	$user_id = $order->get_user_id();
	if ( ! $user_id ) {
		return;
	}
	
	if ( 'yes' === $order->get_meta( '_pa_points_redemption_recorded', true ) ) {
		PA_set_applied_redeem_points( 0 );
		return;
	}

	$points_to_use = (int) $order->get_meta( '_pa_points_used', true );
	
	if ( $points_to_use > 0 && 'yes' === $order->get_meta( '_pa_points_claimed', true ) ) {
		$order->update_meta_data( '_pa_points_redemption_recorded', 'yes' );
		$order->add_order_note( sprintf( 'Customer used %d %s for this order.', $points_to_use, PA_format_point_label( $points_to_use ) ) );
		$order->save();
		
		// Add history entry
		PA_add_history_entry(
			$user_id,
			-$points_to_use,
			'redeemed',
			sprintf( 'Redeemed %d %s for order #%d', $points_to_use, PA_format_point_label( $points_to_use ), $order_id ),
			$order_id
		);
	}

	PA_set_applied_redeem_points( 0 );
}

// Admin: Show and edit points in user profile
add_action( 'show_user_profile', 'PA_show_user_points_field' );
add_action( 'edit_user_profile', 'PA_show_user_points_field' );
function PA_show_user_points_field( $user ) {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	
	$points = PA_get_user_points( $user->ID );
	$point_value = (float) PA_get_option( 'pa_point_value', 1 );
	$credit_value = $points * $point_value;
	$history = PA_get_user_history( $user->ID, 50 );
	?>
	<h3>💎 <?php echo esc_html( PA_get_point_labels()['plural'] ); ?></h3>
	<table class="form-table">
		<tr>
			<th><label for="pa_user_points"><?php echo esc_html( PA_get_point_labels()['singular'] ); ?> Balance</label></th>
			<td>
				<input type="number" step="0.01" min="0" id="pa_user_points" name="pa_user_points" value="<?php echo esc_attr( $points ); ?>" class="regular-text" />
				<p class="description">
					Available <?php echo esc_html( PA_format_point_label( $points ) ); ?>: <strong><?php echo number_format( $points, 2, '.', "'" ); ?></strong> |
					Credit value: <strong><?php echo PA_money( $credit_value ); ?></strong><br />
					<em>Only administrators can edit the <?php echo esc_html( PA_get_point_labels()['plural'] ); ?> balance.</em>
				</p>
			</td>
		</tr>
	</table>
	
	<h3><?php esc_html_e( 'Points History', 'punti-acquisto' ); ?></h3>
	<?php if ( empty( $history ) ) : ?>
		<p><?php esc_html_e( 'No points activity yet.', 'punti-acquisto' ); ?></p>
	<?php else : ?>
		<table class="widefat striped">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Date', 'punti-acquisto' ); ?></th>
					<th><?php esc_html_e( 'Description', 'punti-acquisto' ); ?></th>
					<th><?php esc_html_e( 'Points', 'punti-acquisto' ); ?></th>
					<th><?php esc_html_e( 'Type', 'punti-acquisto' ); ?></th>
					<th><?php esc_html_e( 'Order', 'punti-acquisto' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $history as $entry ) : ?>
					<tr>
						<td><?php echo date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $entry->date_created ) ); ?></td>
						<td><?php echo esc_html( $entry->description ); ?></td>
						<td>
							<strong style="color:<?php echo $entry->points > 0 ? '#2e7d32' : '#c62828'; ?>;">
								<?php echo $entry->points > 0 ? '+' : ''; ?><?php echo number_format( $entry->points, 0, ',', "'" ); ?>
							</strong>
						</td>
						<td>
							<?php if ( $entry->type === 'earned' ) : ?>
								<span style="color:#2e7d32;">✓ <?php esc_html_e( 'Earned', 'punti-acquisto' ); ?></span>
							<?php else : ?>
								<span style="color:#c62828;">⤷ <?php esc_html_e( 'Redeemed', 'punti-acquisto' ); ?></span>
							<?php endif; ?>
						</td>
						<td>
							<?php if ( $entry->order_id ) : ?>
								<a href="<?php echo admin_url( 'post.php?post=' . $entry->order_id . '&action=edit' ); ?>">
									#<?php echo $entry->order_id; ?>
								</a>
							<?php else : ?>
								—
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>
	<?php
}

// Admin: Save points field
add_action( 'personal_options_update', 'PA_save_user_points_field' );
add_action( 'edit_user_profile_update', 'PA_save_user_points_field' );
function PA_save_user_points_field( $user_id ) {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	
	if ( isset( $_POST['pa_user_points'] ) ) {
		$new_points = (float) $_POST['pa_user_points'];
		if ( $new_points < 0 ) {
			$new_points = 0;
		}
		update_user_meta( $user_id, 'pa_points_balance', $new_points );
	}
}

// Show points in My Account
add_action( 'woocommerce_account_dashboard', 'PA_show_points_in_account' );
function PA_show_points_in_account() {
	if ( ! is_user_logged_in() ) {
		return;
	}
	
	$user_id = get_current_user_id();
	$points = PA_get_user_points( $user_id );
	$point_value = (float) PA_get_option( 'pa_point_value', 1 );
	$credit_value = $points * $point_value;
	
	?>
	<div class="pa-account-points" style="background:#f0f8ff; padding:20px; margin:20px 0; border-radius:6px; border:2px solid #2196f3;">
		<h2 style="margin-top:0; color:#1976d2;">💎 <?php esc_html_e( 'Your', 'punti-acquisto' ); ?> <?php echo esc_html( PA_get_point_labels()['plural'] ); ?></h2>
		<p style="font-size:18px; margin:10px 0;">
			<strong><?php echo esc_html( PA_get_point_labels()['singular'] ); ?> <?php esc_html_e( 'balance', 'punti-acquisto' ); ?>:</strong> <?php echo number_format( $points, 0, ',', "'" ); ?> <?php echo esc_html( PA_format_point_label( $points ) ); ?>
		</p>
		<p style="font-size:16px; margin:10px 0;">
			<strong><?php esc_html_e( 'Credit value', 'punti-acquisto' ); ?>:</strong> <?php echo PA_money( $credit_value ); ?>
		</p>
		<p class="description" style="font-size:13px; margin:10px 0 0 0;">
			<?php esc_html_e( 'Use your', 'punti-acquisto' ); ?> <?php echo esc_html( PA_get_point_labels()['plural'] ); ?> <?php esc_html_e( 'at checkout as credit. 1', 'punti-acquisto' ); ?> <?php echo esc_html( PA_get_point_labels()['singular'] ); ?> = <?php echo PA_money( $point_value ); ?>.
		</p>
	</div>
	<?php
}

// Add Points History endpoint
add_action( 'init', 'PA_add_history_endpoint' );
function PA_add_history_endpoint() {
	add_rewrite_endpoint( 'points-history', EP_ROOT | EP_PAGES );
}

// Add Points History to My Account menu
add_filter( 'woocommerce_account_menu_items', 'PA_add_history_menu_item' );
function PA_add_history_menu_item( $items ) {
	$new_items = array();
	foreach ( $items as $key => $item ) {
		$new_items[ $key ] = $item;
		if ( $key === 'dashboard' ) {
			$new_items['points-history'] = __( 'Points History', 'punti-acquisto' );
		}
	}
	return $new_items;
}

// Points History page content
add_action( 'woocommerce_account_points-history_endpoint', 'PA_history_endpoint_content' );
function PA_history_endpoint_content() {
	if ( ! is_user_logged_in() ) {
		return;
	}
	
	$user_id = get_current_user_id();
	$history = PA_get_user_history( $user_id, 100 );
	$labels = PA_get_point_labels();
	
	?>
	<h2><?php esc_html_e( 'Points History', 'punti-acquisto' ); ?></h2>
	<?php if ( empty( $history ) ) : ?>
		<p><?php esc_html_e( 'No points activity yet.', 'punti-acquisto' ); ?></p>
	<?php else : ?>
		<table class="woocommerce-orders-table woocommerce-MyAccount-orders shop_table shop_table_responsive my_account_orders account-orders-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Date', 'punti-acquisto' ); ?></th>
					<th><?php esc_html_e( 'Description', 'punti-acquisto' ); ?></th>
					<th><?php esc_html_e( 'Points', 'punti-acquisto' ); ?></th>
					<th><?php esc_html_e( 'Type', 'punti-acquisto' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $history as $entry ) : ?>
					<tr>
						<td data-title="<?php esc_attr_e( 'Date', 'punti-acquisto' ); ?>">
							<?php echo date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $entry->date_created ) ); ?>
						</td>
						<td data-title="<?php esc_attr_e( 'Description', 'punti-acquisto' ); ?>">
							<?php echo esc_html( $entry->description ); ?>
						</td>
						<td data-title="<?php esc_attr_e( 'Points', 'punti-acquisto' ); ?>">
							<span style="color:<?php echo $entry->points > 0 ? '#2e7d32' : '#c62828'; ?>; font-weight:bold;">
								<?php echo $entry->points > 0 ? '+' : ''; ?><?php echo number_format( $entry->points, 0, ',', "'" ); ?>
							</span>
						</td>
						<td data-title="<?php esc_attr_e( 'Type', 'punti-acquisto' ); ?>">
							<?php if ( $entry->type === 'earned' ) : ?>
								<span style="color:#2e7d32;">✓ <?php esc_html_e( 'Earned', 'punti-acquisto' ); ?></span>
							<?php else : ?>
								<span style="color:#c62828;">⤷ <?php esc_html_e( 'Redeemed', 'punti-acquisto' ); ?></span>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>
	<?php
}

// ==============================
// REST API Endpoints (v1.4.0)
// ==============================

add_action( 'rest_api_init', 'PA_register_rest_routes' );
function PA_register_rest_routes() {
	// GET /wp-json/punti-acquisto/v1/points/{user_id}
	register_rest_route( 'punti-acquisto/v1', '/points/(?P<user_id>\d+)', array(
		'methods'  => 'GET',
		'callback' => 'PA_rest_get_points',
		'permission_callback' => 'PA_rest_permission_check',
		'args' => array(
			'user_id' => array(
				'required' => true,
				'validate_callback' => function( $param ) {
					return is_numeric( $param );
				},
			),
		),
	) );

	// POST /wp-json/punti-acquisto/v1/points/{user_id}/add
	register_rest_route( 'punti-acquisto/v1', '/points/(?P<user_id>\d+)/add', array(
		'methods'  => 'POST',
		'callback' => 'PA_rest_add_points',
		'permission_callback' => 'PA_rest_permission_check',
		'args' => array(
			'user_id' => array(
				'required' => true,
				'validate_callback' => function( $param ) {
					return is_numeric( $param );
				},
			),
		),
	) );

	// POST /wp-json/punti-acquisto/v1/points/{user_id}/deduct
	register_rest_route( 'punti-acquisto/v1', '/points/(?P<user_id>\d+)/deduct', array(
		'methods'  => 'POST',
		'callback' => 'PA_rest_deduct_points',
		'permission_callback' => 'PA_rest_permission_check',
		'args' => array(
			'user_id' => array(
				'required' => true,
				'validate_callback' => function( $param ) {
					return is_numeric( $param );
				},
			),
		),
	) );

	// GET /wp-json/punti-acquisto/v1/config
	register_rest_route( 'punti-acquisto/v1', '/config', array(
		'methods'  => 'GET',
		'callback' => 'PA_rest_get_config',
		'permission_callback' => '__return_true', // Public endpoint
	) );
}

/**
 * Permission check: requires WooCommerce consumer key/secret (Basic Auth),
 * X-API-Key header (shared secret), or admin user.
 */
function PA_rest_permission_check( $request ) {
	// Allow if user is admin
	if ( current_user_can( 'manage_options' ) ) {
		return true;
	}

	// Allow via X-API-Key header (server-to-server from Cloud Functions)
	$api_key      = $request->get_header( 'X-API-Key' );
	$expected_key = PA_get_option( 'pa_api_secret', PA_API_SECRET_DEFAULT );
	if ( ! empty( $api_key ) && ! empty( $expected_key ) && hash_equals( $expected_key, $api_key ) ) {
		return true;
	}

	// Allow if WooCommerce consumer key auth is present (server-to-server)
	if ( ! empty( $_SERVER['PHP_AUTH_USER'] ) && ! empty( $_SERVER['PHP_AUTH_PW'] ) ) {
		$consumer_key    = sanitize_text_field( $_SERVER['PHP_AUTH_USER'] );
		$consumer_secret = sanitize_text_field( $_SERVER['PHP_AUTH_PW'] );

		global $wpdb;
		// Support both single-site and multisite table prefixes
		$tables_to_check = array( $wpdb->prefix . 'woocommerce_api_keys' );
		if ( is_multisite() ) {
			$tables_to_check[] = $wpdb->base_prefix . 'woocommerce_api_keys';
		}

		foreach ( $tables_to_check as $table ) {
			$key = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT consumer_secret FROM {$table} WHERE consumer_key = %s",
					wc_api_hash( $consumer_key )
				)
			);
			if ( $key && hash_equals( $key->consumer_secret, $consumer_secret ) ) {
				return true;
			}
		}
	}

	return new WP_Error(
		'rest_forbidden',
		__( 'Authentication required.', 'punti-acquisto' ),
		array( 'status' => 401 )
	);
}

/**
 * Helper to calculate user loyalty tier and gamification status.
 */
function PA_get_user_tier( $points ) {
	$pts = (int) $points;
	
	// Names (using central option router)
	$base_name = PA_get_option( 'pa_tier_base_name', '' );
	$silver_name = PA_get_option( 'pa_tier_silver_name', 'Argento' );
	$gold_name = PA_get_option( 'pa_tier_gold_name', 'Oro' );
	$platinum_name = PA_get_option( 'pa_tier_platinum_name', 'Platino' );

	// Thresholds (using central option router)
	$silver_min = (int) PA_get_option( 'pa_tier_silver_min', 101 );
	$gold_min = (int) PA_get_option( 'pa_tier_gold_min', 501 );
	$platinum_min = (int) PA_get_option( 'pa_tier_platinum_min', 1501 );

	// Ranges
	$bronze_max = $silver_min - 1;
	$silver_max = $gold_min - 1;
	$gold_max = $platinum_min - 1;

	if ( $pts <= $bronze_max ) {
		return array(
			'name'         => $base_name ? $base_name : null,
			'nextTier'     => $silver_name,
			'pointsNeeded' => $silver_min - $pts,
			'progress'     => $silver_min > 0 ? round( $pts / $silver_min, 2 ) : 1.0
		);
	} elseif ( $pts <= $silver_max ) {
		$range = $gold_min - $silver_min;
		return array(
			'name'         => $silver_name,
			'nextTier'     => $gold_name,
			'pointsNeeded' => $gold_min - $pts,
			'progress'     => $range > 0 ? round( ( $pts - $silver_min ) / $range, 2 ) : 1.0
		);
	} elseif ( $pts <= $gold_max ) {
		$range = $platinum_min - $gold_min;
		return array(
			'name'         => $gold_name,
			'nextTier'     => $platinum_name,
			'pointsNeeded' => $platinum_min - $pts,
			'progress'     => $range > 0 ? round( ( $pts - $gold_min ) / $range, 2 ) : 1.0
		);
	} else {
		return array(
			'name'         => $platinum_name,
			'nextTier'     => null,
			'pointsNeeded' => 0,
			'progress'     => 1.0
		);
	}
}

/**
 * GET /wp-json/punti-acquisto/v1/points/{user_id}
 * Returns the user's point balance, point value, and point cost.
 */
function PA_rest_get_points( $request ) {
	// Disable LiteSpeed cache for this endpoint (balance changes per user)
	if ( ! headers_sent() ) {
		header( 'X-LiteSpeed-Cache-Control: no-cache, no-store' );
		header( 'Cache-Control: no-store, no-cache, must-revalidate' );
	}

	$user_id = (int) $request['user_id'];
	$user    = get_userdata( $user_id );

	if ( ! $user ) {
		return new WP_Error( 'invalid_user', __( 'User not found.', 'punti-acquisto' ), array( 'status' => 404 ) );
	}

	$balance     = PA_get_user_points( $user_id );
	$point_value = (float) PA_get_option( 'pa_point_value', 1 );
	$point_cost  = (float) PA_get_option( 'pa_point_cost', 10 );
	$earning_mode = PA_sanitize_earning_mode( PA_get_option( 'pa_earning_mode', 'spend_based' ) );
	$fixed_points = PA_sanitize_nonnegative_int( PA_get_option( 'pa_fixed_points_per_order', 10 ) );
	$labels      = PA_get_point_labels();

	return rest_ensure_response( array(
		'balance'    => $balance,
		'pointValue' => $point_value,
		'pointCost'  => $point_cost,
		'earningMode' => $earning_mode,
		'fixedPointsPerOrder' => $fixed_points,
		'labels'     => $labels,
		'tier'       => PA_get_user_tier( $balance ),
	) );
}

/**
 * POST /wp-json/punti-acquisto/v1/points/{user_id}/add
 * Adds points to the user's balance.
 * Body: { amount: number, description?: string, order_id?: number }
 */
function PA_rest_add_points( $request ) {
	$user_id = (int) $request['user_id'];
	$user = get_userdata( $user_id );

	if ( ! $user ) {
		return new WP_Error( 'invalid_user', __( 'User not found.', 'punti-acquisto' ), array( 'status' => 404 ) );
	}

	$body = $request->get_json_params();
	$amount      = isset( $body['amount'] ) ? (float) $body['amount'] : 0;
	$description = isset( $body['description'] ) ? sanitize_text_field( $body['description'] ) : '';
	$order_id    = isset( $body['order_id'] ) ? (int) $body['order_id'] : null;

	if ( $amount <= 0 ) {
		return new WP_Error( 'invalid_amount', __( 'Amount must be greater than 0.', 'punti-acquisto' ), array( 'status' => 400 ) );
	}

	PA_add_user_points( $user_id, $amount );

	if ( ! empty( $description ) ) {
		PA_add_history_entry( $user_id, $amount, 'earned', $description, $order_id );
	}

	$new_balance = PA_get_user_points( $user_id );

	return rest_ensure_response( array(
		'newBalance' => $new_balance,
	) );
}

/**
 * POST /wp-json/punti-acquisto/v1/points/{user_id}/deduct
 * Deducts points from the user's balance.
 * Body: { amount: number, description?: string, order_id?: number }
 */
function PA_rest_deduct_points( $request ) {
	$user_id = (int) $request['user_id'];
	$user = get_userdata( $user_id );

	if ( ! $user ) {
		return new WP_Error( 'invalid_user', __( 'User not found.', 'punti-acquisto' ), array( 'status' => 404 ) );
	}

	$body = $request->get_json_params();
	$amount      = isset( $body['amount'] ) ? (float) $body['amount'] : 0;
	$description = isset( $body['description'] ) ? sanitize_text_field( $body['description'] ) : '';
	$order_id    = isset( $body['order_id'] ) ? (int) $body['order_id'] : null;

	if ( $amount <= 0 ) {
		return new WP_Error( 'invalid_amount', __( 'Amount must be greater than 0.', 'punti-acquisto' ), array( 'status' => 400 ) );
	}

	$current_balance = PA_get_user_points( $user_id );
	if ( $amount > $current_balance ) {
		return new WP_Error( 'insufficient_points', __( 'Not enough points.', 'punti-acquisto' ), array( 'status' => 400 ) );
	}

	if ( ! PA_deduct_user_points( $user_id, $amount ) ) {
		return new WP_Error( 'insufficient_points', __( 'Not enough points.', 'punti-acquisto' ), array( 'status' => 409 ) );
	}

	if ( ! empty( $description ) ) {
		PA_add_history_entry( $user_id, -$amount, 'redeemed', $description, $order_id );
	}

	$new_balance = PA_get_user_points( $user_id );

	return rest_ensure_response( array(
		'newBalance' => $new_balance,
	) );
}

/**
 * GET /wp-json/punti-acquisto/v1/config
 * Returns the public points configuration.
 */
function PA_rest_get_config( $request ) {
	$point_value = (float) PA_get_option( 'pa_point_value', 1 );
	$point_cost  = (float) PA_get_option( 'pa_point_cost', 10 );
	$earning_mode = PA_sanitize_earning_mode( PA_get_option( 'pa_earning_mode', 'spend_based' ) );
	$fixed_points = PA_sanitize_nonnegative_int( PA_get_option( 'pa_fixed_points_per_order', 10 ) );
	$redemption_max = PA_sanitize_nonnegative_int( PA_get_option( 'pa_redemption_max_points', 0 ) );
	$redemption_step = PA_sanitize_positive_int( PA_get_option( 'pa_redemption_step', 1 ) );
	$labels      = PA_get_point_labels();

	$base_name     = PA_get_option( 'pa_tier_base_name', '' );
	$silver_name   = PA_get_option( 'pa_tier_silver_name', 'Argento' );
	$gold_name     = PA_get_option( 'pa_tier_gold_name', 'Oro' );
	$platinum_name = PA_get_option( 'pa_tier_platinum_name', 'Platino' );
	$silver_min    = (int) PA_get_option( 'pa_tier_silver_min', 101 );
	$gold_min      = (int) PA_get_option( 'pa_tier_gold_min', 501 );
	$platinum_min  = (int) PA_get_option( 'pa_tier_platinum_min', 1501 );

	$tiers = array();
	if ( $base_name ) {
		$tiers[] = array( 'name' => $base_name, 'minPoints' => 0 );
	}
	$tiers[] = array( 'name' => $silver_name, 'minPoints' => $silver_min );
	$tiers[] = array( 'name' => $gold_name, 'minPoints' => $gold_min );
	$tiers[] = array( 'name' => $platinum_name, 'minPoints' => $platinum_min );

	return rest_ensure_response( array(
		'pointValue'    => $point_value,
		'pointCost'     => $point_cost,
		'earningMode'   => $earning_mode,
		'fixedPointsPerOrder' => $fixed_points,
		'redemptionMaxPoints' => $redemption_max,
		'redemptionStep' => $redemption_step,
		'labelSingular' => $labels['singular'],
		'labelPlural'   => $labels['plural'],
		'tiers'         => $tiers,
	) );
}
