<?php
/**
 * Configurable loyalty earning and redemption rules.
 *
 * @package PuntiAcquisto
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sanitize the earning mode while preserving spend-based behavior by default.
 *
 * @param mixed $mode Candidate earning mode.
 * @return string
 */
function PA_sanitize_earning_mode( $mode ) {
	return 'fixed_order' === $mode ? 'fixed_order' : 'spend_based';
}

/**
 * Sanitize a non-negative integer setting.
 *
 * @param mixed $value Candidate value.
 * @return int
 */
function PA_sanitize_nonnegative_int( $value ) {
	return max( 0, (int) $value );
}

/**
 * Sanitize a positive integer setting.
 *
 * @param mixed $value Candidate value.
 * @return int
 */
function PA_sanitize_positive_int( $value ) {
	return max( 1, (int) $value );
}

/**
 * Calculate points earned by a completed order using the site's configured mode.
 *
 * @param float $paid_amount Amount paid for the order.
 * @return float
 */
function PA_calculate_order_points( $paid_amount ) {
	$mode = PA_sanitize_earning_mode( PA_get_option( 'pa_earning_mode', 'spend_based' ) );

	if ( 'fixed_order' === $mode ) {
		return (float) PA_sanitize_nonnegative_int( PA_get_option( 'pa_fixed_points_per_order', 10 ) );
	}

	$point_cost = (float) PA_get_option( 'pa_point_cost', 10 );
	if ( $point_cost <= 0 ) {
		return 0.0;
	}

	return (float) floor( max( 0, (float) $paid_amount ) / $point_cost );
}

/**
 * Return the largest redeemable amount after balance, cart, cap and step limits.
 *
 * A configured cap of zero keeps the historical unlimited behavior.
 *
 * @param float $available_points User balance.
 * @param float $cart_total       Cart total before the points discount.
 * @return int
 */
function PA_get_max_redeemable_points( $available_points, $cart_total ) {
	$point_value = (float) PA_get_option( 'pa_point_value', 1 );
	if ( $point_value <= 0 ) {
		return 0;
	}

	$step      = PA_sanitize_positive_int( PA_get_option( 'pa_redemption_step', 1 ) );
	$available = max( 0, (int) floor( (float) $available_points ) );
	$by_cart   = max( 0, (int) floor( ( (float) $cart_total + 0.0000001 ) / $point_value ) );
	$maximum   = min( $available, $by_cart );
	$cap       = PA_sanitize_nonnegative_int( PA_get_option( 'pa_redemption_max_points', 0 ) );

	if ( $cap > 0 ) {
		$maximum = min( $maximum, $cap );
	}

	return (int) ( floor( $maximum / $step ) * $step );
}

/**
 * Normalize a requested redemption to the site's allowed range and increment.
 *
 * @param mixed $requested        Requested points.
 * @param float $available_points User balance.
 * @param float $cart_total       Cart total before the points discount.
 * @return int
 */
function PA_normalize_redeem_points( $requested, $available_points, $cart_total ) {
	$step    = PA_sanitize_positive_int( PA_get_option( 'pa_redemption_step', 1 ) );
	$maximum = PA_get_max_redeemable_points( $available_points, $cart_total );
	$points  = min( max( 0, (int) $requested ), $maximum );

	return (int) ( floor( $points / $step ) * $step );
}

/**
 * Normalize an already-applied redemption against balance, cap and step.
 *
 * @param mixed $requested        Applied points.
 * @param float $available_points User balance.
 * @return int
 */
function PA_normalize_applied_points( $requested, $available_points ) {
	$step    = PA_sanitize_positive_int( PA_get_option( 'pa_redemption_step', 1 ) );
	$maximum = max( 0, (int) floor( (float) $available_points ) );
	$cap     = PA_sanitize_nonnegative_int( PA_get_option( 'pa_redemption_max_points', 0 ) );

	if ( $cap > 0 ) {
		$maximum = min( $maximum, $cap );
	}

	$points = min( max( 0, (int) $requested ), $maximum );
	return (int) ( floor( $points / $step ) * $step );
}

/**
 * Build a stable cart total before this plugin adds its points discount fee.
 *
 * @param object $cart WooCommerce cart instance.
 * @return float
 */
function PA_get_cart_total_before_points( $cart ) {
	if ( ! is_object( $cart ) ) {
		return 0.0;
	}

	$total = 0.0;
	$components = array(
		'get_cart_contents_total',
		'get_shipping_total',
		'get_cart_contents_tax',
		'get_shipping_tax',
	);

	foreach ( $components as $method ) {
		if ( method_exists( $cart, $method ) ) {
			$total += (float) $cart->{$method}();
		}
	}

	if ( method_exists( $cart, 'get_fees' ) ) {
		foreach ( (array) $cart->get_fees() as $fee ) {
			$total += isset( $fee->amount ) ? (float) $fee->amount : 0.0;
			$total += isset( $fee->total_tax ) ? (float) $fee->total_tax : 0.0;
		}
	}

	return max( 0.0, $total );
}

/**
 * Persist the exact normalized redemption in the WooCommerce session.
 *
 * @param int $points Applied points.
 * @return void
 */
function PA_set_applied_redeem_points( $points ) {
	if ( function_exists( 'WC' ) && WC() && WC()->session ) {
		WC()->session->set( 'pa_applied_redeem_points', max( 0, (int) $points ) );
	}
}

/**
 * Get the exact normalized redemption stored during fee calculation.
 *
 * @return int
 */
function PA_get_applied_redeem_points() {
	if ( function_exists( 'WC' ) && WC() && WC()->session ) {
		return max( 0, (int) WC()->session->get( 'pa_applied_redeem_points', 0 ) );
	}

	return 0;
}

/**
 * Atomically reserve points for a checkout.
 *
 * The conditional update prevents two simultaneous orders from spending the
 * same balance. A false return means the current balance is insufficient or
 * the balance row could not be updated.
 *
 * @param int   $user_id User ID.
 * @param float $points  Points to reserve.
 * @return bool
 */
function PA_claim_user_points( $user_id, $points ) {
	global $wpdb;

	$user_id = (int) $user_id;
	$points  = (float) $points;
	if ( $user_id <= 0 || $points <= 0 || ! isset( $wpdb->usermeta ) ) {
		return false;
	}

	$updated = $wpdb->query(
		$wpdb->prepare(
			"UPDATE {$wpdb->usermeta}
			 SET meta_value = CAST(meta_value AS DECIMAL(18,2)) - %f
			 WHERE user_id = %d
			   AND meta_key = %s
			   AND CAST(meta_value AS DECIMAL(18,2)) >= %f
			 LIMIT 1",
			$points,
			$user_id,
			'pa_points_balance',
			$points
		)
	);

	if ( 1 === $updated ) {
		wp_cache_delete( $user_id, 'user_meta' );
		return true;
	}

	return false;
}

/**
 * Atomically credit an existing balance, creating it when needed.
 *
 * @param int   $user_id User ID.
 * @param float $points  Points to credit.
 * @return bool
 */
function PA_credit_user_points_atomic( $user_id, $points ) {
	global $wpdb;

	$user_id = (int) $user_id;
	$points  = (float) $points;
	if ( $user_id <= 0 || $points <= 0 || ! isset( $wpdb->usermeta ) ) {
		return false;
	}

	$updated = $wpdb->query(
		$wpdb->prepare(
			"UPDATE {$wpdb->usermeta}
			 SET meta_value = CAST(meta_value AS DECIMAL(18,2)) + %f
			 WHERE user_id = %d
			   AND meta_key = %s
			 LIMIT 1",
			$points,
			$user_id,
			'pa_points_balance'
		)
	);

	if ( 1 === $updated ) {
		wp_cache_delete( $user_id, 'user_meta' );
		return true;
	}

	if ( 0 === $updated && function_exists( 'add_user_meta' ) ) {
		$added = add_user_meta( $user_id, 'pa_points_balance', $points, true );
		if ( false !== $added ) {
			wp_cache_delete( $user_id, 'user_meta' );
			return true;
		}
	}

	return false;
}
