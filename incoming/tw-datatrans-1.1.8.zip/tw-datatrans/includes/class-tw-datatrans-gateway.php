<?php
/**
 * One WooCommerce gateway per Datatrans payment method, all sharing the
 * account configured in WooCommerce → Datatrans. At checkout the customer
 * picks the method; the Datatrans page then opens straight on it (a single
 * `paymentMethods` entry skips the method selection).
 */

defined( 'ABSPATH' ) || exit;

abstract class TW_Datatrans_Gateway extends WC_Payment_Gateway {

	const LABEL = '';
	/** Datatrans shortnames sent in `paymentMethods`. */
	const CODES = array();
	const ICON  = '';
	/** Square 72×72 icon for WooCommerce → Settings → Payments (same format as WooCommerce's own). */
	const TILE  = '';

	/** Asset URL with the plugin version, so browsers drop old cached logos after an update. */
	public static function icon_url( $file ) {
		return $file ? TW_DATATRANS_URL . 'assets/img/' . $file . '?ver=' . TW_DATATRANS_VERSION : '';
	}

	/**
	 * True while WooCommerce builds its Payments settings list (the React page
	 * and the REST call behind it), which draws icons in 48–72 px squares.
	 */
	public static function is_payments_admin_list() {
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		if ( false !== strpos( $uri, 'wc-admin/settings/payments' ) || false !== strpos( $uri, 'wc-admin%2Fsettings%2Fpayments' ) ) {
			return true;
		}
		return is_admin() && isset( $_GET['page'], $_GET['tab'] ) && 'wc-settings' === $_GET['page'] && 'checkout' === $_GET['tab'] && empty( $_GET['section'] );
	}

	/** id => class, in checkout order. */
	public static function methods() {
		return array(
			'tw_datatrans_twint'     => 'TW_Datatrans_Gateway_TWINT',
			'tw_datatrans_card'      => 'TW_Datatrans_Gateway_Card',
			'tw_datatrans_applepay'  => 'TW_Datatrans_Gateway_ApplePay',
			'tw_datatrans_googlepay' => 'TW_Datatrans_Gateway_GooglePay',
		);
	}

	public function __construct() {
		$this->method_title       = sprintf( 'Datatrans — %s', static::LABEL );
		$this->method_description = sprintf(
			/* translators: %s: link to the Datatrans settings page */
			__( 'Paid on the secure Datatrans page with the account set up under %s.', 'tw-datatrans' ),
			'<a href="' . esc_url( admin_url( 'admin.php?page=tw-datatrans' ) ) . '">WooCommerce → Datatrans</a>'
		);
		$this->has_fields = false;
		$this->supports   = array( 'products', 'refunds' );
		$this->icon       = static::icon_url( self::is_payments_admin_list() ? static::TILE : static::ICON );

		$this->init_form_fields();
		$this->init_settings();
		$this->title       = $this->translated( 'title', $this->get_option( 'title', static::LABEL ) );
		$this->description = $this->translated( 'description', $this->get_option( 'description', '' ) );

		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'register_strings' ), 20 );
	}

	public function init_form_fields() {
		$this->form_fields = array(
			'enabled'     => array(
				'title'   => __( 'Enable', 'tw-datatrans' ),
				'type'    => 'checkbox',
				'label'   => sprintf( __( 'Offer %s at checkout', 'tw-datatrans' ), static::LABEL ),
				'default' => 'no',
			),
			'title'       => array(
				'title'       => __( 'Name at checkout', 'tw-datatrans' ),
				'type'        => 'text',
				'default'     => static::LABEL,
				'description' => __( 'What the customer sees in the list of payment methods.', 'tw-datatrans' ),
				'desc_tip'    => true,
			),
			'description' => array(
				'title'       => __( 'Short text', 'tw-datatrans' ),
				'type'        => 'textarea',
				'default'     => static::default_description(),
				'description' => __( 'Shown under the name when the method is selected. Leave empty for none.', 'tw-datatrans' ),
				'desc_tip'    => true,
			),
		);
	}

	protected static function default_description() {
		return __( 'You will be taken to the secure Datatrans page to complete the payment, then back to the shop.', 'tw-datatrans' );
	}

	/** Texts typed by the admin, translated by WPML / tW Translate Plus when present. */
	protected function translated( $field, $value ) {
		$name = 'tw_datatrans_' . $this->id . '_' . $field;
		if ( function_exists( 'ticinoweb_frontend_text' ) && ! is_admin() ) {
			return ticinoweb_frontend_text( $value );
		}
		return apply_filters( 'wpml_translate_single_string', $value, 'tw-datatrans', $name );
	}

	public function register_strings() {
		foreach ( array( 'title', 'description' ) as $field ) {
			do_action( 'wpml_register_single_string', 'tw-datatrans', 'tw_datatrans_' . $this->id . '_' . $field, $this->get_option( $field ) );
		}
	}

	public function is_available() {
		if ( ! parent::is_available() || ! TW_Datatrans_Settings::is_configured() ) {
			return false;
		}
		return $this->device_supported();
	}

	/** Apple Pay needs Safari; the others work everywhere. */
	protected function device_supported() {
		return true;
	}

	/** 2-letter language for the Datatrans page, from the current locale (WPML / tW Translate switch it). */
	protected function language() {
		$lang = strtolower( substr( (string) get_locale(), 0, 2 ) );
		return in_array( $lang, array( 'de', 'en', 'fr', 'it', 'es', 'nl', 'pt' ), true ) ? $lang : 'en';
	}

	/** Datatrans refno (max 40 chars, unique): order number plus an attempt counter. */
	protected function refno( WC_Order $order ) {
		$attempt = (int) $order->get_meta( '_tw_datatrans_attempts' ) + 1;
		$order->update_meta_data( '_tw_datatrans_attempts', $attempt );
		$ref = (string) $order->get_order_number();
		return substr( $ref, 0, 34 ) . '-' . $attempt;
	}

	public function process_payment( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return array( 'result' => 'failure' );
		}
		$amount = (int) round( (float) $order->get_total() * 100 );
		if ( $amount <= 0 ) {
			// Nothing to charge: WooCommerce handles free orders itself.
			$order->payment_complete();
			return array( 'result' => 'success', 'redirect' => $this->get_return_url( $order ) );
		}

		$refno = $this->refno( $order );
		$body  = array(
			'currency'       => $order->get_currency(),
			'refno'          => $refno,
			'amount'         => $amount,
			'paymentMethods' => static::CODES,
			'language'       => $this->language(),
			'option'         => array(
				'autoSettle'  => 'yes' === TW_Datatrans_Settings::get( 'autosettle' ),
				'createAlias' => false,
			),
			'redirect'       => array(
				'successUrl' => TW_Datatrans_Handlers::return_url( $order, 'success' ),
				'errorUrl'   => TW_Datatrans_Handlers::return_url( $order, 'error' ),
				'cancelUrl'  => TW_Datatrans_Handlers::return_url( $order, 'cancel' ),
				'method'     => 'GET',
			),
			'webhook'        => array( 'url' => TW_Datatrans_Handlers::webhook_url( $order ) ),
		);
		$body = apply_filters( 'tw_datatrans_init_request', $body, $order, $this );

		$result = TW_Datatrans_API::init( $body );
		if ( is_wp_error( $result ) || empty( $result['transactionId'] ) ) {
			$message = is_wp_error( $result ) ? $result->get_error_message() : __( 'no transaction id returned', 'tw-datatrans' );
			$order->add_order_note( sprintf( __( 'Datatrans: payment could not be started (%s).', 'tw-datatrans' ), $message ) );
			$order->save();
			wc_add_notice( __( 'The payment could not be started. Please try again or choose another payment method.', 'tw-datatrans' ), 'error' );
			return array( 'result' => 'failure' );
		}

		$transaction_id = (string) $result['transactionId'];
		$order->update_meta_data( '_tw_datatrans_transaction_id', $transaction_id );
		$order->update_meta_data( '_tw_datatrans_refno', $refno );
		$order->update_meta_data( '_tw_datatrans_env', TW_Datatrans_Settings::is_sandbox() ? 'sandbox' : 'live' );
		$order->update_meta_data( '_tw_datatrans_method', $this->id );
		$order->update_status( 'pending', sprintf( __( 'Datatrans: customer sent to the payment page (%1$s, transaction %2$s).', 'tw-datatrans' ), static::LABEL, $transaction_id ) );
		$order->save();

		$redirect = ! empty( $result['_location'] ) ? $result['_location'] : TW_Datatrans_API::start_url( $transaction_id );
		return array( 'result' => 'success', 'redirect' => $redirect );
	}

	public function can_refund_order( $order ) {
		return $order instanceof WC_Order && '' !== (string) $order->get_meta( '_tw_datatrans_transaction_id' ) && $order->is_paid();
	}

	public function process_refund( $order_id, $amount = null, $reason = '' ) {
		$order          = wc_get_order( $order_id );
		$transaction_id = $order ? (string) $order->get_meta( '_tw_datatrans_transaction_id' ) : '';
		if ( '' === $transaction_id ) {
			return new WP_Error( 'tw_datatrans_no_tx', __( 'No Datatrans transaction on this order.', 'tw-datatrans' ) );
		}
		$env = (string) $order->get_meta( '_tw_datatrans_env' );
		if ( '' !== $env && ( 'sandbox' === $env ) !== TW_Datatrans_Settings::is_sandbox() ) {
			return new WP_Error( 'tw_datatrans_env', sprintf( __( 'This payment was made in %s mode; switch the plugin to that mode to refund it.', 'tw-datatrans' ), 'sandbox' === $env ? __( 'test', 'tw-datatrans' ) : __( 'live', 'tw-datatrans' ) ) );
		}
		$cents = (int) round( (float) $amount * 100 );
		if ( $cents <= 0 ) {
			return new WP_Error( 'tw_datatrans_amount', __( 'Invalid refund amount.', 'tw-datatrans' ) );
		}
		// Never ask Datatrans for more than it collected minus what it already
		// refunded (WooCommerce caps at the order total, Datatrans refuses too:
		// this check just gives the shop a clear message first).
		$status = TW_Datatrans_API::status( $transaction_id );
		if ( ! is_wp_error( $status ) ) {
			$state = (string) ( $status['status'] ?? '' );
			if ( ! in_array( $state, array( 'settled', 'transmitted' ), true ) ) {
				return new WP_Error( 'tw_datatrans_not_settled', sprintf( __( 'The payment is "%s" on Datatrans: only a settled payment can be refunded. Try again later.', 'tw-datatrans' ), $state ) );
			}
			$collected = (int) ( $status['settledAmount'] ?? $status['authorizedAmount'] ?? 0 );
			$available = $collected - (int) ( $status['refundedAmount'] ?? 0 );
			if ( $cents > $available ) {
				return new WP_Error( 'tw_datatrans_over', sprintf( __( 'Datatrans can still refund at most %s for this payment.', 'tw-datatrans' ), wc_price( $available / 100, array( 'currency' => $order->get_currency() ) ) ) );
			}
		}
		$refno  = substr( (string) $order->get_order_number(), 0, 24 ) . '-r' . substr( (string) time(), -8 );
		$result = TW_Datatrans_API::credit( $transaction_id, $cents, $order->get_currency(), $refno );
		if ( is_wp_error( $result ) ) {
			$order->add_order_note( sprintf( __( 'Datatrans refund NOT done: %s', 'tw-datatrans' ), $result->get_error_message() ) );
			return new WP_Error( 'tw_datatrans_refund', sprintf( __( 'Datatrans refused the refund: %s', 'tw-datatrans' ), $result->get_error_message() ) );
		}
		$order->add_order_note( sprintf(
			__( 'Refund of %1$s done on Datatrans (transaction %2$s%3$s).', 'tw-datatrans' ),
			wc_price( $cents / 100, array( 'currency' => $order->get_currency() ) ),
			$transaction_id,
			! empty( $result['transactionId'] ) && $result['transactionId'] !== $transaction_id ? ', ' . __( 'refund id', 'tw-datatrans' ) . ' ' . $result['transactionId'] : ''
		) );
		return true;
	}
}

class TW_Datatrans_Gateway_TWINT extends TW_Datatrans_Gateway {
	const LABEL = 'TWINT';
	const CODES = array( 'TWI' );
	const ICON  = 'twint.svg';
	const TILE  = 'tile-twint.svg';
	public function __construct() {
		$this->id = 'tw_datatrans_twint';
		parent::__construct();
	}
	protected static function default_description() {
		return __( 'Pay with the TWINT app: scan the code or confirm on your phone.', 'tw-datatrans' );
	}
}

class TW_Datatrans_Gateway_Card extends TW_Datatrans_Gateway {
	const LABEL = 'Carta di credito o debito';
	const CODES = array( 'VIS', 'ECA' );
	const ICON  = 'cards.svg';
	const TILE  = 'tile-cards.svg';
	public function __construct() {
		$this->id = 'tw_datatrans_card';
		parent::__construct();
	}
	public function init_form_fields() {
		parent::init_form_fields();
		$this->form_fields['title']['default'] = __( 'Credit or debit card', 'tw-datatrans' );
		$this->form_fields['brands'] = array(
			'title'   => __( 'Accepted cards', 'tw-datatrans' ),
			'type'    => 'multiselect',
			'class'   => 'wc-enhanced-select',
			'default' => array( 'VIS', 'ECA' ),
			'options' => array(
				'VIS' => 'Visa',
				'ECA' => 'Mastercard',
				'AMX' => 'American Express',
				'DIN' => 'Diners Club',
				'DIS' => 'Discover',
				'JCB' => 'JCB',
				'PFC' => 'PostFinance Card',
			),
			'description' => __( 'Only brands active on your Datatrans contract work. Visa and Mastercard are the usual ones.', 'tw-datatrans' ),
			'desc_tip'    => true,
		);
	}
	public function process_payment( $order_id ) {
		$brands = (array) $this->get_option( 'brands', array( 'VIS', 'ECA' ) );
		$brands = array_values( array_intersect( array( 'VIS', 'ECA', 'AMX', 'DIN', 'DIS', 'JCB', 'PFC' ), $brands ) );
		add_filter( 'tw_datatrans_init_request', function ( $body ) use ( $brands ) {
			if ( $brands ) {
				$body['paymentMethods'] = $brands;
			}
			return $body;
		} );
		return parent::process_payment( $order_id );
	}
	protected static function default_description() {
		return __( 'Visa, Mastercard and other cards, with 3-D Secure verification by your bank.', 'tw-datatrans' );
	}
}

class TW_Datatrans_Gateway_ApplePay extends TW_Datatrans_Gateway {
	const LABEL = 'Apple Pay';
	// Apple Pay on the Datatrans page needs at least one card brand next to it.
	const CODES = array( 'APL', 'VIS', 'ECA' );
	const ICON  = 'applepay.svg';
	const TILE  = 'tile-applepay.svg';
	public function __construct() {
		$this->id = 'tw_datatrans_applepay';
		parent::__construct();
	}
	/** Apple Pay exists only in Safari (macOS, iPhone, iPad): hide it elsewhere. */
	protected function device_supported() {
		if ( is_admin() ) {
			return true;
		}
		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) $_SERVER['HTTP_USER_AGENT'] : '';
		if ( '' === $ua ) {
			return true;
		}
		return false !== stripos( $ua, 'Safari' ) && ! preg_match( '/Chrome|CriOS|Chromium|Edg|OPR|FxiOS|Android|SamsungBrowser/i', $ua );
	}
	protected static function default_description() {
		return __( 'Confirm with Face ID or Touch ID. Available in Safari on iPhone, iPad and Mac.', 'tw-datatrans' );
	}
}

class TW_Datatrans_Gateway_GooglePay extends TW_Datatrans_Gateway {
	const LABEL = 'Google Pay';
	// Google Pay on the Datatrans page needs at least one card brand next to it.
	const CODES = array( 'PAY', 'VIS', 'ECA' );
	const ICON  = 'googlepay.svg';
	const TILE  = 'tile-googlepay.svg';
	public function __construct() {
		$this->id = 'tw_datatrans_googlepay';
		parent::__construct();
	}
	protected static function default_description() {
		return __( 'Pay with the cards saved in your Google account.', 'tw-datatrans' );
	}
}
