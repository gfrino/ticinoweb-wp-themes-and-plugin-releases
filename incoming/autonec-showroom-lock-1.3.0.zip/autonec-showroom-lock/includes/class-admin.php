<?php
/**
 * Admin settings page for Showroom Lock codes.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ASL_Admin {

    /** Option key used in wp_options */
    const OPTION = 'asl_settings';

    /** Days of the week (PHP day number => Italian label) */
    const DAYS = [
        1 => 'Lunedì',
        2 => 'Martedì',
        3 => 'Mercoledì',
        4 => 'Giovedì',
        5 => 'Venerdì',
        6 => 'Sabato',
        0 => 'Domenica',
    ];

    /** Default visitor email template */
    const DEFAULT_VISITOR_EMAIL = "Gentile {nome} {cognome},\n\nGrazie per aver compilato il formulario di accesso.\n\nEcco il tuo codice per accedere allo showroom:\n\n🔑  Codice: {codice}\n📆  Valido: {giorno} — {fascia}\n\nDigita questo codice sulla tastiera della porta d'ingresso dello showroom.\n\nCordiali saluti,\n{sito}";

    /** Default SMS template sent to the visitor */
    const DEFAULT_VISITOR_SMS = "Showroom {sito}: il tuo codice di accesso è {codice}. Valido {giorno} {fascia}. Digita il codice sulla tastiera della porta.";

    /* -------------------------------------------------------------- */
    /*  Bootstrap                                                      */
    /* -------------------------------------------------------------- */

    public function init(): void {
        add_action( 'admin_menu',            [ $this, 'add_menu' ] );
        add_action( 'admin_init',            [ $this, 'register_settings' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue' ] );
    }

    /* -------------------------------------------------------------- */
    /*  Menu                                                           */
    /* -------------------------------------------------------------- */

    public function add_menu(): void {
        add_menu_page(
            'Showroom Lock',
            'Showroom Lock',
            'manage_options',
            'asl-email',
            [ $this, 'render_email_page' ],
            'dashicons-lock',
            80
        );

        add_submenu_page(
            'asl-email',
            'Email',
            'Email',
            'manage_options',
            'asl-email',
            [ $this, 'render_email_page' ]
        );

        add_submenu_page(
            'asl-email',
            'Twilio SMS',
            'Twilio SMS',
            'manage_options',
            'asl-twilio',
            [ $this, 'render_twilio_page' ]
        );

        add_submenu_page(
            'asl-email',
            'Codici di Accesso',
            'Codici di Accesso',
            'manage_options',
            'asl-codes',
            [ $this, 'render_codes_page' ]
        );

        add_submenu_page(
            'asl-email',
            'Visitatori',
            'Visitatori',
            'manage_options',
            'asl-visitors',
            [ $this, 'render_visitors_page' ]
        );
    }

    /* -------------------------------------------------------------- */
    /*  Assets                                                         */
    /* -------------------------------------------------------------- */

    public function enqueue( string $hook ): void {
        $our_pages = [
            'toplevel_page_asl-email',
            'showroom-lock_page_asl-twilio',
            'showroom-lock_page_asl-codes',
            'showroom-lock_page_asl-visitors',
        ];
        if ( ! in_array( $hook, $our_pages, true ) ) {
            return;
        }
        wp_enqueue_style( 'asl-admin', ASL_PLUGIN_URL . 'assets/css/admin.css', [], ASL_VERSION );

        /* Inline JS — placeholder pills (email page) */
        if ( 'toplevel_page_asl-email' === $hook ) {
            wp_add_inline_script( 'jquery', '
jQuery(function($){
    $(".asl-pill[data-ph]").on("click", function(){
        var ph      = $(this).data("ph");
        var $parent = $(this).closest(".asl-card");
        var $ta     = $parent.find("textarea").last();
        if ( ! $ta.length ) $ta = $("#asl-visitor-email-template");
        if ( ! $ta.length ) return;
        var pos  = $ta[0].selectionStart;
        var val  = $ta.val();
        $ta.val( val.slice(0, pos) + ph + val.slice(pos) );
        $ta[0].setSelectionRange(pos + ph.length, pos + ph.length);
        $ta.focus();
        $(this).css("background","#bbf7d0").delay(400).queue(function(n){ $(this).css("background",""); n(); });
    });
});
' );
        }

        /* Inline JS — Twilio page (toggle, test, pills) */
        if ( 'showroom-lock_page_asl-twilio' === $hook ) {
            wp_add_inline_script( 'jquery', '
jQuery(function($){
    $(".asl-pill[data-ph]").on("click", function(){
        var ph      = $(this).data("ph");
        var $parent = $(this).closest(".asl-card");
        var $ta     = $parent.find("textarea").last();
        if ( ! $ta.length ) return;
        var pos  = $ta[0].selectionStart;
        var val  = $ta.val();
        $ta.val( val.slice(0, pos) + ph + val.slice(pos) );
        $ta[0].setSelectionRange(pos + ph.length, pos + ph.length);
        $ta.focus();
        $(this).css("background","#bbf7d0").delay(400).queue(function(n){ $(this).css("background",""); n(); });
    });
    $("#asl-twilio-test-btn").on("click", function(){
        var $btn  = $(this);
        var $msg  = $("#asl-twilio-test-result");
        $btn.prop("disabled", true).text("Verifica in corso\u2026");
        $msg.html("").removeClass("asl-test-ok asl-test-fail");
        $.post(ajaxurl, {
            action: "asl_twilio_test",
            nonce:  $("#asl-twilio-test-nonce").val()
        }, function(res){
            $btn.prop("disabled", false).text("\ud83d\udd0c Testa connessione");
            if (res.success) {
                $msg.addClass("asl-test-ok").html(res.data.message);
            } else {
                $msg.addClass("asl-test-fail").html(res.data.message);
            }
        }).fail(function(){
            $btn.prop("disabled", false).text("\ud83d\udd0c Testa connessione");
            $msg.addClass("asl-test-fail").html("\u274c Errore di connessione.");
        });
    });
    $("#asl-twilio-toggle").on("change", function(){
        $(".asl-twilio-fields").toggle( $(this).is(":checked") );
    }).trigger("change");
});
' );
        }

        /* Inline JS — Visitors page (select, delete) */
        if ( 'showroom-lock_page_asl-visitors' === $hook ) {
            wp_add_inline_script( 'jquery', '
jQuery(function($){
    function updateCount(){
        var c = $(".asl-row-check:checked").length;
        $("#asl-sel-count").text(c);
        $("#asl-delete-selected").prop("disabled", c === 0);
    }
    $("#asl-check-all").on("change", function(){
        $(".asl-row-check").prop("checked", this.checked);
        updateCount();
    });
    $(document).on("change", ".asl-row-check", function(){
        updateCount();
        if(!this.checked) $("#asl-check-all").prop("checked", false);
        if($(".asl-row-check:checked").length === $(".asl-row-check").length)
            $("#asl-check-all").prop("checked", true);
    });
    $("#asl-delete-selected").on("click", function(){
        var ids = $(".asl-row-check:checked").map(function(){ return this.value; }).get();
        if(!ids.length) return;
        if(!confirm("Eliminare " + ids.length + " visitator" + (ids.length===1?"e":"i") + "? L\\u0027azione \\u00e8 irreversibile.")) return;
        var $btn = $(this).prop("disabled", true);
        var $msg = $("#asl-delete-msg").text("Eliminazione in corso...").css("color","#64748b");
        $.post(ajaxurl, {
            action: "asl_delete_visitors",
            nonce: $("#asl-visitors-nonce").val(),
            ids: ids
        }, function(res){
            if(res.success){
                ids.forEach(function(id){ $("tr[data-id=\\""+id+"\\"]").fadeOut(300, function(){ $(this).remove(); }); });
                $msg.text(res.data.message).css("color","#16a34a");
                $("#asl-check-all").prop("checked", false);
                setTimeout(function(){ $msg.text(""); }, 3000);
            } else {
                $msg.text(res.data.message).css("color","#dc2626");
            }
            $btn.prop("disabled", false);
            updateCount();
        }).fail(function(){
            $msg.text("Errore di connessione.").css("color","#dc2626");
            $btn.prop("disabled", false);
        });
    });
});
' );
        }
    }

    public function register_settings(): void {
        register_setting( 'asl_general_group', self::OPTION, [
            'type'              => 'array',
            'sanitize_callback' => [ $this, 'sanitize' ],
        ] );
        /* Additional groups share the same option — no duplicate sanitize */
        register_setting( 'asl_twilio_group', self::OPTION, [ 'type' => 'array' ] );
        register_setting( 'asl_codes_group',  self::OPTION, [ 'type' => 'array' ] );
    }

    /**
     * Single sanitize callback for all pages.
     * A hidden field '_asl_page' tells us which page is submitting.
     */
    public function sanitize( $input ): array {
        $existing = get_option( self::OPTION, [] );
        $page     = $input['_asl_page'] ?? 'email';
        $clean    = [];

        if ( 'twilio' === $page ) {
            /* ── Twilio page ── */
            $clean['twilio_enabled']      = ! empty( $input['twilio_enabled'] ) ? 1 : 0;
            $clean['twilio_account_sid']  = sanitize_text_field( $input['twilio_account_sid']  ?? '' );
            $clean['twilio_auth_token']   = sanitize_text_field( $input['twilio_auth_token']   ?? '' );
            $clean['twilio_from_number']  = sanitize_text_field( $input['twilio_from_number']  ?? '' );
            $clean['visitor_sms_template'] = wp_kses( $input['visitor_sms_template'] ?? self::DEFAULT_VISITOR_SMS, [] );
            if ( '' === trim( $clean['visitor_sms_template'] ) ) {
                $clean['visitor_sms_template'] = self::DEFAULT_VISITOR_SMS;
            }
        } elseif ( 'codici' === $page ) {
            /* ── Codici di Accesso page ── */
            $clean['page_id']         = absint( $input['page_id'] ?? 0 );
            $clean['morning_start']   = sanitize_text_field( $input['morning_start']   ?? '08:00' );
            $clean['morning_end']     = sanitize_text_field( $input['morning_end']     ?? '12:00' );
            $clean['afternoon_start'] = sanitize_text_field( $input['afternoon_start'] ?? '13:00' );
            $clean['afternoon_end']   = sanitize_text_field( $input['afternoon_end']   ?? '18:00' );
            foreach ( array_keys( self::DAYS ) as $d ) {
                $clean['code_' . $d . '_am'] = sanitize_text_field( $input['code_' . $d . '_am'] ?? '' );
                $clean['code_' . $d . '_pm'] = sanitize_text_field( $input['code_' . $d . '_pm'] ?? '' );
            }
        } else {
            /* ── Email page (default) ── */
            $raw_emails = sanitize_textarea_field( $input['notification_emails'] ?? '' );
            $emails     = preg_split( '/[,;\s]+/', $raw_emails, -1, PREG_SPLIT_NO_EMPTY );
            $valid      = array_filter( array_map( 'trim', $emails ), 'is_email' );
            $clean['notification_emails'] = implode( ', ', $valid );

            $clean['visitor_email_template'] = wp_kses( $input['visitor_email_template'] ?? self::DEFAULT_VISITOR_EMAIL, [] );
            if ( '' === trim( $clean['visitor_email_template'] ) ) {
                $clean['visitor_email_template'] = self::DEFAULT_VISITOR_EMAIL;
            }
            $clean['visitor_email_subject'] = sanitize_text_field( $input['visitor_email_subject'] ?? '' );
            if ( '' === trim( $clean['visitor_email_subject'] ) ) {
                $clean['visitor_email_subject'] = '{sito} — Il tuo codice di accesso allo showroom';
            }
        }

        return array_merge( $existing, $clean );
    }

    /* -------------------------------------------------------------- */
    /*  Seed defaults on activation                                    */
    /* -------------------------------------------------------------- */

    public static function seed_defaults(): void {
        if ( get_option( self::OPTION ) ) {
            return;
        }

        $defaults = [
            'morning_start'          => '08:00',
            'morning_end'            => '12:00',
            'afternoon_start'        => '13:00',
            'afternoon_end'          => '18:00',
            'page_id'                => 0,
            'notification_emails'    => '',
            'visitor_email_subject'  => '{sito} — Il tuo codice di accesso allo showroom',
            'visitor_email_template' => self::DEFAULT_VISITOR_EMAIL,
            'twilio_enabled'         => 0,
            'twilio_account_sid'     => '',
            'twilio_auth_token'      => '',
            'twilio_from_number'     => '',
            'visitor_sms_template'   => self::DEFAULT_VISITOR_SMS,
        ];

        $sample_codes = [
            1 => [ '987654', '158473' ],
            2 => [ '779581', '889347' ],
            3 => [ '334521', '667832' ],
            4 => [ '112944', '558123' ],
            5 => [ '443290', '776501' ],
            6 => [ '990187', '223456' ],
            0 => [ '554321', '887654' ],
        ];

        foreach ( $sample_codes as $d => [ $am, $pm ] ) {
            $defaults[ 'code_' . $d . '_am' ] = $am;
            $defaults[ 'code_' . $d . '_pm' ] = $pm;
        }

        update_option( self::OPTION, $defaults );
    }

    /* -------------------------------------------------------------- */
    /*  Helpers                                                        */
    /* -------------------------------------------------------------- */

    public static function get( string $key = '', $fallback = '' ) {
        $opts = get_option( self::OPTION, [] );
        if ( '' === $key ) {
            return $opts;
        }
        return $opts[ $key ] ?? $fallback;
    }

    /* -------------------------------------------------------------- */
    /*  Email page                                                     */
    /* -------------------------------------------------------------- */

    public function render_email_page(): void {
        $opts = self::get();
        ?>
        <div class="wrap asl-wrap">
            <h1><span class="dashicons dashicons-lock"></span> Showroom Lock — Email</h1>

            <form method="post" action="options.php">
                <?php settings_fields( 'asl_general_group' ); ?>
                <input type="hidden" name="<?php echo self::OPTION; ?>[_asl_page]" value="email">

                <!-- ═══════════════════════════════════════════════ -->
                <!-- Notification emails                            -->
                <!-- ═══════════════════════════════════════════════ -->
                <div class="asl-card">
                    <h2>📧 Notifiche e-mail (admin)</h2>
                    <p class="description">Indirizzi e-mail che riceveranno una notifica ogni volta che un visitatore richiede un codice. Separa più indirizzi con una virgola o a capo riga.</p>
                    <textarea name="<?php echo self::OPTION; ?>[notification_emails]"
                              rows="3"
                              class="large-text"
                              placeholder="info@autonec.ch, direzione@autonec.ch"><?php echo esc_textarea( $opts['notification_emails'] ?? '' ); ?></textarea>
                </div>

                <!-- ═══════════════════════════════════════════════ -->
                <!-- Visitor email template                         -->
                <!-- ═══════════════════════════════════════════════ -->
                <div class="asl-card">
                    <h2>✉️ E-mail inviata al visitatore</h2>
                    <p class="description">Personalizza l'oggetto e il testo dell'e-mail che viene inviata al visitatore con il codice di accesso. Usa i <strong>segnaposto</strong> qui sotto per inserire i dati dinamici.</p>

                    <!-- Placeholder pills -->
                    <div class="asl-placeholders">
                        <span class="asl-placeholder-label">Segnaposto disponibili — clicca per inserire nel testo</span>
                        <?php
                        $placeholders = [
                            '{nome}'    => 'Nome del visitatore',
                            '{cognome}' => 'Cognome del visitatore',
                            '{codice}'  => 'Codice di accesso',
                            '{giorno}'  => 'Giorno (es. Lunedì)',
                            '{fascia}'  => 'Fascia oraria (mattina / pomeriggio)',
                            '{sito}'    => 'Nome del sito WordPress',
                        ];
                        foreach ( $placeholders as $ph => $desc ) :
                        ?>
                            <button type="button" class="asl-pill" data-ph="<?php echo esc_attr( $ph ); ?>">
                                <?php echo esc_html( $ph ); ?> <span class="asl-pill-desc">— <?php echo esc_html( $desc ); ?></span>
                            </button>
                        <?php endforeach; ?>
                    </div>

                    <!-- Subject -->
                    <p style="margin-top:1.25rem; margin-bottom:0.35rem; font-weight:600; font-size:0.875rem; color:#334155;">Oggetto dell'e-mail</p>
                    <input type="text"
                           name="<?php echo self::OPTION; ?>[visitor_email_subject]"
                           value="<?php echo esc_attr( $opts['visitor_email_subject'] ?? '{sito} — Il tuo codice di accesso allo showroom' ); ?>"
                           class="large-text"
                           style="margin-bottom:1.25rem;"
                           placeholder="{sito} — Il tuo codice di accesso allo showroom">

                    <!-- Body -->
                    <p style="margin-bottom:0.35rem; font-weight:600; font-size:0.875rem; color:#334155;">Corpo del messaggio (testo semplice)</p>
                    <div class="asl-email-template-wrap">
                        <textarea id="asl-visitor-email-template"
                                  name="<?php echo self::OPTION; ?>[visitor_email_template]"
                                  rows="12"
                                  class="large-text"><?php echo esc_textarea( $opts['visitor_email_template'] ?? self::DEFAULT_VISITOR_EMAIL ); ?></textarea>
                    </div>
                </div>

                <?php submit_button( 'Salva impostazioni email' ); ?>
            </form>
        </div>
        <?php
    }

    /* -------------------------------------------------------------- */
    /*  Codici di Accesso page                                         */
    /* -------------------------------------------------------------- */

    public function render_codes_page(): void {
        $opts = self::get();
        ?>
        <div class="wrap asl-wrap">
            <h1><span class="dashicons dashicons-lock"></span> Showroom Lock — Codici di Accesso</h1>

            <form method="post" action="options.php">
                <?php settings_fields( 'asl_codes_group' ); ?>
                <input type="hidden" name="<?php echo self::OPTION; ?>[_asl_page]" value="codici">

                <!-- ═══════════════════════════════════════════════ -->
                <!-- Shortcode & Page URL                           -->
                <!-- ═══════════════════════════════════════════════ -->
                <div class="asl-card">
                    <h2>📄 Pagina Showroom</h2>
                    <p class="description">Usa lo shortcode <code>[showroom_lock]</code> in una pagina per mostrare il formulario di accesso.</p>
                    <?php
                    $page_id = absint( $opts['page_id'] ?? 0 );
                    if ( ! $page_id ) {
                        $found = get_posts( [
                            'post_type'      => 'page',
                            'post_status'    => 'publish',
                            's'              => '[showroom_lock',
                            'posts_per_page' => 1,
                            'fields'         => 'ids',
                        ] );
                        if ( $found ) {
                            $page_id         = $found[0];
                            $opts['page_id'] = $page_id;
                            update_option( self::OPTION, $opts );
                        }
                    }
                    if ( $page_id && get_post( $page_id ) ) :
                        $page_url  = get_permalink( $page_id );
                        $page_edit = get_edit_post_link( $page_id );
                    ?>
                        <table class="asl-time-table">
                            <tr>
                                <th>URL pubblico</th>
                                <td>
                                    <a href="<?php echo esc_url( $page_url ); ?>" target="_blank" class="asl-page-url">
                                        🔗 <?php echo esc_html( $page_url ); ?>
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <th>Modifica pagina</th>
                                <td>
                                    <a href="<?php echo esc_url( $page_edit ); ?>" class="asl-page-url">
                                        ✏️ <?php echo esc_html( get_the_title( $page_id ) ); ?>
                                    </a>
                                </td>
                            </tr>
                        </table>
                    <?php else : ?>
                        <p class="asl-notice-warn">⚠️ Nessuna pagina trovata con lo shortcode <code>[showroom_lock]</code>. Crea una pagina e inserisci lo shortcode.</p>
                    <?php endif; ?>
                    <input type="hidden"
                           name="<?php echo self::OPTION; ?>[page_id]"
                           value="<?php echo esc_attr( $page_id ); ?>">
                </div>

                <!-- ═══════════════════════════════════════════════ -->
                <!-- Time ranges                                    -->
                <!-- ═══════════════════════════════════════════════ -->
                <div class="asl-card">
                    <h2>⏰ Fasce orarie</h2>
                    <p class="description">Definisci gli orari per la fascia <strong>mattina</strong> e <strong>pomeriggio</strong>.</p>

                    <table class="asl-time-table">
                        <tr>
                            <th>Mattina</th>
                            <td>
                                dalle <input type="time" name="<?php echo self::OPTION; ?>[morning_start]"
                                             value="<?php echo esc_attr( $opts['morning_start'] ?? '08:00' ); ?>">
                                alle  <input type="time" name="<?php echo self::OPTION; ?>[morning_end]"
                                             value="<?php echo esc_attr( $opts['morning_end'] ?? '12:00' ); ?>">
                            </td>
                        </tr>
                        <tr>
                            <th>Pomeriggio</th>
                            <td>
                                dalle <input type="time" name="<?php echo self::OPTION; ?>[afternoon_start]"
                                             value="<?php echo esc_attr( $opts['afternoon_start'] ?? '13:00' ); ?>">
                                alle  <input type="time" name="<?php echo self::OPTION; ?>[afternoon_end]"
                                             value="<?php echo esc_attr( $opts['afternoon_end'] ?? '18:00' ); ?>">
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- ═══════════════════════════════════════════════ -->
                <!-- Per-day codes                                  -->
                <!-- ═══════════════════════════════════════════════ -->
                <div class="asl-card">
                    <h2>🔐 Codici di accesso</h2>
                    <p class="description">Inserisci il codice per ogni giorno e fascia oraria.</p>

                    <table class="widefat asl-codes-table">
                        <thead>
                            <tr>
                                <th>Giorno</th>
                                <th>☀️ Codice Mattina</th>
                                <th>🌤 Codice Pomeriggio</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ( self::DAYS as $d => $label ) : ?>
                                <tr>
                                    <td class="asl-day-label"><?php echo esc_html( $label ); ?></td>
                                    <td>
                                        <input type="text"
                                               name="<?php echo self::OPTION; ?>[code_<?php echo $d; ?>_am]"
                                               value="<?php echo esc_attr( $opts[ 'code_' . $d . '_am' ] ?? '' ); ?>"
                                               placeholder="es. 123456"
                                               class="asl-code-input">
                                    </td>
                                    <td>
                                        <input type="text"
                                               name="<?php echo self::OPTION; ?>[code_<?php echo $d; ?>_pm]"
                                               value="<?php echo esc_attr( $opts[ 'code_' . $d . '_pm' ] ?? '' ); ?>"
                                               placeholder="es. 654321"
                                               class="asl-code-input">
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <?php submit_button( 'Salva codici di accesso' ); ?>
            </form>
        </div>
        <?php
    }

    /* -------------------------------------------------------------- */
    /*  Twilio SMS page                                                */
    /* -------------------------------------------------------------- */

    public function render_twilio_page(): void {
        $opts = self::get();
        ?>
        <div class="wrap asl-wrap">
            <h1><span class="dashicons dashicons-lock"></span> Showroom Lock — Twilio SMS</h1>

            <form method="post" action="options.php">
                <?php settings_fields( 'asl_twilio_group' ); ?>
                <input type="hidden" name="<?php echo self::OPTION; ?>[_asl_page]" value="twilio">

                <div class="asl-card asl-twilio-card">
                    <h2>📱 Invio SMS tramite Twilio</h2>
                    <p class="description">Attiva l'invio di un SMS con il codice di accesso al visitatore tramite <a href="https://www.twilio.com" target="_blank" rel="noopener">Twilio</a>. L'SMS viene inviato insieme all'e-mail quando il visitatore compila il formulario.</p>

                    <!-- Enable toggle -->
                    <label class="asl-toggle-label">
                        <input type="checkbox"
                               id="asl-twilio-toggle"
                               name="<?php echo self::OPTION; ?>[twilio_enabled]"
                               value="1"
                               <?php checked( ! empty( $opts['twilio_enabled'] ) ); ?>>
                        <span class="asl-toggle-switch"></span>
                        <span class="asl-toggle-text">Invio SMS attivo</span>
                    </label>

                    <!-- Twilio credential fields (shown/hidden by toggle) -->
                    <div class="asl-twilio-fields" <?php echo empty( $opts['twilio_enabled'] ) ? 'style="display:none;"' : ''; ?>>

                        <!-- Help box -->
                        <div class="asl-help-box">
                            <h4>📖 Dove trovare i dati Twilio</h4>
                            <ol>
                                <li>Accedi alla <a href="https://console.twilio.com/" target="_blank" rel="noopener">Twilio Console</a></li>
                                <li><strong>Account SID</strong> e <strong>Auth Token</strong>: visibili nella dashboard principale → <a href="https://console.twilio.com/us1/account/keys-credentials/api-keys" target="_blank" rel="noopener">Account &gt; API Keys</a></li>
                                <li><strong>Numero mittente</strong>: vai a <a href="https://console.twilio.com/us1/develop/phone-numbers/manage/incoming" target="_blank" rel="noopener">Phone Numbers &gt; Manage &gt; Active Numbers</a> e copia il numero in formato internazionale (es. <code>+41xxxxxxxxx</code>)</li>
                                <li>Per i test puoi usare un <a href="https://www.twilio.com/docs/messaging/guides/how-to-use-your-free-trial-account" target="_blank" rel="noopener">account trial gratuito</a></li>
                            </ol>
                        </div>

                        <table class="asl-time-table asl-twilio-table">
                            <tr>
                                <th><label for="asl-twilio-sid">Account SID</label></th>
                                <td>
                                    <input type="text"
                                           id="asl-twilio-sid"
                                           name="<?php echo self::OPTION; ?>[twilio_account_sid]"
                                           value="<?php echo esc_attr( $opts['twilio_account_sid'] ?? '' ); ?>"
                                           class="large-text asl-secret-field"
                                           placeholder="ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                                           autocomplete="off"
                                           spellcheck="false">
                                    <p class="description">Inizia con <code>AC</code> — trovalo nella <a href="https://console.twilio.com/" target="_blank" rel="noopener">Dashboard Twilio</a></p>
                                </td>
                            </tr>
                            <tr>
                                <th><label for="asl-twilio-token">Auth Token</label></th>
                                <td>
                                    <input type="password"
                                           id="asl-twilio-token"
                                           name="<?php echo self::OPTION; ?>[twilio_auth_token]"
                                           value="<?php echo esc_attr( $opts['twilio_auth_token'] ?? '' ); ?>"
                                           class="large-text asl-secret-field"
                                           placeholder="••••••••••••••••••••••••••••••••"
                                           autocomplete="new-password"
                                           spellcheck="false">
                                    <p class="description">Token segreto — <strong>non condividerlo mai</strong></p>
                                </td>
                            </tr>
                            <tr>
                                <th><label for="asl-twilio-from">N° Mittente</label></th>
                                <td>
                                    <input type="tel"
                                           id="asl-twilio-from"
                                           name="<?php echo self::OPTION; ?>[twilio_from_number]"
                                           value="<?php echo esc_attr( $opts['twilio_from_number'] ?? '' ); ?>"
                                           class="asl-code-input"
                                           style="width:220px; text-align:left;"
                                           placeholder="+41 xx xxx xx xx"
                                           autocomplete="off">
                                    <p class="description">Numero Twilio in formato internazionale — <a href="https://console.twilio.com/us1/develop/phone-numbers/manage/incoming" target="_blank" rel="noopener">Active Numbers</a></p>
                                </td>
                            </tr>
                        </table>

                        <!-- Test connection button -->
                        <div class="asl-twilio-test-area">
                            <button type="button" id="asl-twilio-test-btn" class="button button-secondary">🔌 Testa connessione</button>
                            <span id="asl-twilio-test-result"></span>
                            <?php wp_nonce_field( 'asl_twilio_test', 'asl-twilio-test-nonce', false ); ?>
                        </div>

                        <!-- SMS Template -->
                        <div class="asl-sms-template-section">
                            <p style="margin-bottom:0.35rem; font-weight:600; font-size:0.875rem; color:#334155;">Testo dell'SMS (max 160 caratteri consigliati)</p>

                            <!-- Placeholder pills for SMS -->
                            <div class="asl-placeholders">
                                <span class="asl-placeholder-label">Segnaposto disponibili — clicca per inserire nel testo</span>
                                <?php
                                $sms_placeholders = [
                                    '{nome}'    => 'Nome',
                                    '{cognome}' => 'Cognome',
                                    '{codice}'  => 'Codice',
                                    '{giorno}'  => 'Giorno',
                                    '{fascia}'  => 'Fascia oraria',
                                    '{sito}'    => 'Nome sito',
                                ];
                                foreach ( $sms_placeholders as $ph => $desc ) :
                                ?>
                                    <button type="button" class="asl-pill" data-ph="<?php echo esc_attr( $ph ); ?>">
                                        <?php echo esc_html( $ph ); ?> <span class="asl-pill-desc">— <?php echo esc_html( $desc ); ?></span>
                                    </button>
                                <?php endforeach; ?>
                            </div>

                            <textarea id="asl-visitor-sms-template"
                                      name="<?php echo self::OPTION; ?>[visitor_sms_template]"
                                      rows="4"
                                      class="large-text"
                                      maxlength="320"><?php echo esc_textarea( $opts['visitor_sms_template'] ?? self::DEFAULT_VISITOR_SMS ); ?></textarea>
                            <p class="description" style="margin-top:0.4rem;">💡 Un SMS standard contiene max 160 caratteri. Oltre 160 verrà inviato come SMS multiplo (costi superiori).</p>
                        </div>
                    </div>
                </div>

                <?php submit_button( 'Salva impostazioni Twilio' ); ?>
            </form>
        </div>
        <?php
    }

    /* -------------------------------------------------------------- */
    /*  Visitors page                                                  */
    /* -------------------------------------------------------------- */

    public function render_visitors_page(): void {
        $visitors = ASL_Visitors::get_all();
        $count    = count( $visitors );
        $csv_url  = wp_nonce_url( admin_url( 'admin-ajax.php?action=asl_export_csv' ), 'asl_export_csv' );
        ?>
        <div class="wrap asl-wrap asl-wrap-wide">
            <h1><span class="dashicons dashicons-groups"></span> Showroom Lock — Visitatori</h1>

            <?php if ( empty( $visitors ) ) : ?>
                <div class="asl-card">
                    <p style="color:#64748b; margin:0;">Nessun visitatore registrato.</p>
                </div>
            <?php else : ?>

                <!-- Toolbar -->
                <div class="asl-visitors-toolbar">
                    <div class="asl-toolbar-left">
                        <span class="asl-visitor-count"><?php echo $count; ?> visitator<?php echo $count === 1 ? 'e' : 'i'; ?></span>
                        <button type="button" id="asl-delete-selected" class="button asl-btn-delete" disabled>
                            🗑 Elimina selezionati (<span id="asl-sel-count">0</span>)
                        </button>
                        <span id="asl-delete-msg" class="asl-delete-msg"></span>
                    </div>
                    <div class="asl-toolbar-right">
                        <a href="<?php echo esc_url( $csv_url ); ?>" class="button asl-btn-export">
                            📥 Esporta CSV
                        </a>
                    </div>
                </div>

                <!-- Table -->
                <div class="asl-card asl-card-table">
                    <div class="asl-table-scroll">
                        <table class="widefat asl-visitors-table">
                            <thead>
                                <tr>
                                    <th class="asl-col-check"><input type="checkbox" id="asl-check-all"></th>
                                    <th class="asl-col-id">#</th>
                                    <th class="asl-col-date">Data / Ora</th>
                                    <th class="asl-col-name">Nome</th>
                                    <th class="asl-col-name">Cognome</th>
                                    <th class="asl-col-addr">Indirizzo</th>
                                    <th class="asl-col-phone">Telefono</th>
                                    <th class="asl-col-email">E-mail</th>
                                    <th class="asl-col-code">Codice</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ( $visitors as $v ) : ?>
                                    <tr data-id="<?php echo esc_attr( $v->id ); ?>">
                                        <td><input type="checkbox" class="asl-row-check" value="<?php echo esc_attr( $v->id ); ?>"></td>
                                        <td><?php echo esc_html( $v->id ); ?></td>
                                        <td class="asl-nowrap"><?php echo esc_html( wp_date( 'd/m/Y H:i', strtotime( $v->created_at ) ) ); ?></td>
                                        <td class="asl-nowrap"><?php echo esc_html( $v->first_name ); ?></td>
                                        <td class="asl-nowrap"><?php echo esc_html( $v->last_name ); ?></td>
                                        <td class="asl-nowrap"><?php echo esc_html( $v->address ); ?></td>
                                        <td class="asl-nowrap"><?php echo esc_html( $v->phone ); ?></td>
                                        <td class="asl-nowrap"><?php echo esc_html( $v->email ); ?></td>
                                        <td><code><?php echo esc_html( $v->code_shown ); ?></code></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <?php wp_nonce_field( 'asl_visitors_action', 'asl-visitors-nonce', false ); ?>

            <?php endif; ?>
        </div>
        <?php
    }
}
