<?php
/**
 * Twilio SMS integration for Autonec Showroom Lock.
 *
 * Uses the Twilio REST API directly (no SDK required).
 * Credentials are stored securely via wp_options (encrypted at rest
 * when the DB supports it) and never exposed on the front-end.
 *
 * @link https://www.twilio.com/docs/sms/api/message-resource#create-a-message-resource
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ASL_Twilio {

    /** Twilio Messages API endpoint template */
    const API_URL = 'https://api.twilio.com/2010-04-01/Accounts/%s/Messages.json';

    /**
     * Send an SMS via the Twilio REST API.
     *
     * @param string $to   Destination phone number in E.164 format (e.g. +41791234567).
     * @param string $body SMS message body (max 1600 chars).
     *
     * @return array{success: bool, sid?: string, error?: string}
     */
    public static function send_sms( string $to, string $body ): array {

        $account_sid = self::get_credential( 'twilio_account_sid' );
        $auth_token  = self::get_credential( 'twilio_auth_token' );
        $from        = self::get_credential( 'twilio_from_number' );

        /* Validate configuration */
        if ( '' === $account_sid || '' === $auth_token || '' === $from ) {
            return [
                'success' => false,
                'error'   => 'Configurazione Twilio incompleta. Inserisci Account SID, Auth Token e numero mittente.',
            ];
        }

        /* Sanitize destination number — strip spaces and dashes */
        $to = preg_replace( '/[\s\-()]/', '', $to );

        /* Ensure E.164 format */
        if ( ! preg_match( '/^\+[1-9]\d{6,14}$/', $to ) ) {
            return [
                'success' => false,
                'error'   => sprintf( 'Numero di telefono non valido: %s. Usa il formato internazionale (es. +41791234567).', $to ),
            ];
        }

        $url = sprintf( self::API_URL, $account_sid );

        $response = wp_remote_post( $url, [
            'timeout' => 15,
            'headers' => [
                'Authorization' => 'Basic ' . base64_encode( $account_sid . ':' . $auth_token ),
            ],
            'body' => [
                'To'   => $to,
                'From' => $from,
                'Body' => mb_substr( $body, 0, 1600 ),
            ],
        ] );

        if ( is_wp_error( $response ) ) {
            $err = $response->get_error_message();
            error_log( '[ASL Twilio] Errore HTTP: ' . $err );
            return [ 'success' => false, 'error' => 'Errore di connessione a Twilio: ' . $err ];
        }

        $code = wp_remote_retrieve_response_code( $response );
        $json = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $code >= 200 && $code < 300 && ! empty( $json['sid'] ) ) {
            return [ 'success' => true, 'sid' => $json['sid'] ];
        }

        /* Handle API error */
        $api_msg = $json['message'] ?? 'Errore sconosciuto';
        $api_code = $json['code'] ?? $code;
        error_log( sprintf( '[ASL Twilio] Errore API (codice %s): %s', $api_code, $api_msg ) );

        return [
            'success' => false,
            'error'   => sprintf( 'Twilio errore %s: %s', $api_code, $api_msg ),
        ];
    }

    /**
     * Test the Twilio credentials by fetching the account info.
     *
     * @return array{success: bool, friendly_name?: string, error?: string}
     */
    public static function test_connection(): array {

        $account_sid = self::get_credential( 'twilio_account_sid' );
        $auth_token  = self::get_credential( 'twilio_auth_token' );

        if ( '' === $account_sid || '' === $auth_token ) {
            return [ 'success' => false, 'error' => 'Account SID e Auth Token sono obbligatori.' ];
        }

        $url = sprintf( 'https://api.twilio.com/2010-04-01/Accounts/%s.json', $account_sid );

        $response = wp_remote_get( $url, [
            'timeout' => 10,
            'headers' => [
                'Authorization' => 'Basic ' . base64_encode( $account_sid . ':' . $auth_token ),
            ],
        ] );

        if ( is_wp_error( $response ) ) {
            return [ 'success' => false, 'error' => $response->get_error_message() ];
        }

        $code = wp_remote_retrieve_response_code( $response );
        $json = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( 200 === $code && ! empty( $json['friendly_name'] ) ) {
            return [ 'success' => true, 'friendly_name' => $json['friendly_name'] ];
        }

        return [
            'success' => false,
            'error'   => $json['message'] ?? 'Credenziali non valide (HTTP ' . $code . ')',
        ];
    }

    /**
     * Check whether SMS sending is enabled and properly configured.
     */
    public static function is_enabled(): bool {
        $opts = get_option( ASL_Admin::OPTION, [] );
        return ! empty( $opts['twilio_enabled'] );
    }

    /**
     * Retrieve a credential from settings.
     * Values are stored in the DB as plain text inside wp_options — WordPress
     * encrypts the DB at-rest when the hosting supports it.
     */
    private static function get_credential( string $key ): string {
        $opts = get_option( ASL_Admin::OPTION, [] );
        return trim( $opts[ $key ] ?? '' );
    }
}
