<?php
/**
 * Frontend shortcode and AJAX handler.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ASL_Frontend {

    public function init(): void {
        add_shortcode( 'showroom_lock', [ $this, 'render_shortcode' ] );
        add_action( 'wp_enqueue_scripts',        [ $this, 'enqueue' ] );
        add_action( 'wp_ajax_asl_submit',        [ $this, 'handle_ajax' ] );
        add_action( 'wp_ajax_nopriv_asl_submit', [ $this, 'handle_ajax' ] );
    }

    /* -------------------------------------------------------------- */
    /*  Assets                                                         */
    /* -------------------------------------------------------------- */

    public function enqueue(): void {
        if ( ! is_singular() ) {
            return;
        }

        global $post;
        if ( ! has_shortcode( $post->post_content ?? '', 'showroom_lock' ) ) {
            return;
        }

        wp_enqueue_style(
            'asl-frontend',
            ASL_PLUGIN_URL . 'assets/css/frontend.css',
            [],
            ASL_VERSION
        );

        wp_enqueue_script(
            'asl-frontend',
            ASL_PLUGIN_URL . 'assets/js/frontend.js',
            [],
            ASL_VERSION,
            true
        );

        wp_localize_script( 'asl-frontend', 'asl', [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'asl_nonce' ),
        ] );
    }

    /* -------------------------------------------------------------- */
    /*  Shortcode                                                      */
    /* -------------------------------------------------------------- */

    public function render_shortcode(): string {
        ob_start();
        ?>
        <div class="asl-page-bg">
        <div id="asl-container" class="asl-container">
            <!-- FORM -->
            <div id="asl-form-wrap" class="asl-card-front">
                <div class="asl-header">
                    <div class="asl-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none"
                             stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                            <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                        </svg>
                    </div>
                    <h2>Accesso Showroom</h2>
                    <p>Compila il formulario per ricevere il codice di accesso</p>
                </div>

                <form id="asl-form" class="asl-form" autocomplete="off">
                    <div class="asl-field">
                        <label for="asl-first-name">Nome <span class="asl-req">*</span></label>
                        <input type="text" id="asl-first-name" name="first_name" required
                               placeholder="Il tuo nome">
                    </div>

                    <div class="asl-field">
                        <label for="asl-last-name">Cognome <span class="asl-req">*</span></label>
                        <input type="text" id="asl-last-name" name="last_name" required
                               placeholder="Il tuo cognome">
                    </div>

                    <div class="asl-field">
                        <label for="asl-address">Indirizzo <span class="asl-req">*</span></label>
                        <input type="text" id="asl-address" name="address" required
                               placeholder="Via, numero, città">
                    </div>

                    <div class="asl-field">
                        <label for="asl-phone">Telefono <span class="asl-req">*</span></label>
                        <input type="tel" id="asl-phone" name="phone" required
                               placeholder="+41 79 123 45 67">
                    </div>

                    <div class="asl-field">
                        <label for="asl-email">E-mail <span class="asl-req">*</span></label>
                        <input type="email" id="asl-email" name="email" required
                               placeholder="nome@esempio.com">
                    </div>

                    <div id="asl-error" class="asl-error" style="display:none;"></div>

                    <button type="submit" id="asl-submit" class="asl-btn">
                        <span class="asl-btn-text">Ottieni codice di accesso</span>
                        <span class="asl-btn-loading" style="display:none;">
                            <svg class="asl-spinner" viewBox="0 0 24 24">
                                <circle cx="12" cy="12" r="10" stroke="currentColor"
                                        stroke-width="3" fill="none" stroke-dasharray="31 31"/>
                            </svg>
                            Verifica in corso…
                        </span>
                    </button>
                </form>
            </div>

            <!-- EMAIL CONFIRMATION (hidden by default) -->
            <div id="asl-result-wrap" class="asl-card-result" style="display:none;">
                <div class="asl-header">
                    <div class="asl-icon asl-icon-email">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none"
                             stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="2" y="4" width="20" height="16" rx="2"/>
                            <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>
                        </svg>
                    </div>
                    <h2 id="asl-result-title">E-mail inviata!</h2>
                    <p id="asl-time-label"></p>
                </div>

                <div class="asl-email-confirm">
                    <div class="asl-check-anim">
                        <svg viewBox="0 0 52 52" class="asl-checkmark">
                            <circle cx="26" cy="26" r="25" fill="none" stroke="currentColor" stroke-width="2"/>
                            <path fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" d="M14.1 27.2l7.1 7.2 16.7-16.8"/>
                        </svg>
                    </div>
                    <p class="asl-email-sent-to">Le istruzioni sono state inviate via e-mail a:</p>
                    <p id="asl-sent-email" class="asl-email-address"></p>
                    <p id="asl-sent-sms" class="asl-sms-address" style="display:none;"></p>
                </div>

                <p class="asl-instruction">
                    Controlla la tua casella di posta (anche lo spam) per le istruzioni. Il codice di accesso viene inviato esclusivamente via SMS.
                </p>
            </div>
        </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /* -------------------------------------------------------------- */
    /*  AJAX handler                                                   */
    /* -------------------------------------------------------------- */

    public function handle_ajax(): void {
        check_ajax_referer( 'asl_nonce', 'nonce' );

        $fields = [ 'first_name', 'last_name', 'address', 'phone', 'email' ];
        $data   = [];

        foreach ( $fields as $f ) {
            $val = trim( sanitize_text_field( wp_unslash( $_POST[ $f ] ?? '' ) ) );
            if ( '' === $val ) {
                wp_send_json_error( [ 'message' => 'Tutti i campi sono obbligatori.' ] );
            }
            $data[ $f ] = $val;
        }

        $data['phone'] = self::normalize_phone( $data['phone'] );

        if ( ! is_email( $data['email'] ) ) {
            wp_send_json_error( [ 'message' => 'Indirizzo e-mail non valido.' ] );
        }

        /* Determine current code */
        $opts    = ASL_Admin::get();
        $now     = current_time( 'H:i' );
        $day_num = (int) current_time( 'w' ); // 0=Sunday … 6=Saturday

        $morning_start   = $opts['morning_start']   ?? '08:00';
        $morning_end     = $opts['morning_end']     ?? '12:00';
        $afternoon_start = $opts['afternoon_start'] ?? '13:00';
        $afternoon_end   = $opts['afternoon_end']   ?? '18:00';

        $code  = '';
        $slot  = '';

        if ( $now >= $morning_start && $now < $morning_end ) {
            $code = $opts[ 'code_' . $day_num . '_am' ] ?? '';
            $slot = 'mattina';
        } elseif ( $now >= $afternoon_start && $now < $afternoon_end ) {
            $code = $opts[ 'code_' . $day_num . '_pm' ] ?? '';
            $slot = 'pomeriggio';
        }

        if ( '' === $code ) {
            wp_send_json_error( [
                'message' => 'Lo showroom è attualmente chiuso. Non è disponibile nessun codice in questo momento.',
            ] );
        }

        /* Day label in Italian */
        $day_labels = ASL_Admin::DAYS;
        $day_label  = $day_labels[ $day_num ] ?? '';

        /* Log visitor */
        $data['code_shown'] = $code;
        $data['ip_address'] = sanitize_text_field( $_SERVER['REMOTE_ADDR'] ?? '' );
        ASL_Visitors::insert( $data );

        /* Send email notifications to admins */
        $this->send_notifications( $data, $day_label, $slot );

        /* Send code to visitor via email */
        $this->send_code_to_visitor( $data, $code, $day_label, $slot );

        /* Send code to visitor via SMS (if Twilio is enabled) */
        $sms_sent  = false;
        $sms_error = '';
        if ( ASL_Twilio::is_enabled() ) {
            $sms_result = $this->send_sms_to_visitor( $data, $code, $day_label, $slot );
            $sms_sent   = $sms_result['success'];
            if ( ! $sms_sent ) {
                $sms_error = $sms_result['error'] ?? '';
            }
        }

        $time_label = $day_label . ' ' . $slot . ' (' . $morning_start . '–' . ( $slot === 'mattina' ? $morning_end : $afternoon_end ) . ')';

        wp_send_json_success( [
            'email'    => $data['email'],
            'label'    => $time_label,
            'sms_sent' => $sms_sent,
            'phone'    => $sms_sent ? $data['phone'] : '',
        ] );
    }

    /* -------------------------------------------------------------- */
    /*  Phone number: strip separators, Swiss numbers to +41           */
    /* -------------------------------------------------------------- */

    public static function normalize_phone( string $phone ): string {
        $phone_clean = preg_replace( '/[\s\-\.\(\)]/', '', $phone );
        if ( str_starts_with( $phone_clean, '00' ) ) {
            $phone_clean = '+' . substr( $phone_clean, 2 );
        }

        if ( str_starts_with( $phone_clean, '+' ) ) {
            return $phone_clean;
        }
        if ( str_starts_with( $phone_clean, '0' ) ) {
            return '+41' . substr( $phone_clean, 1 );
        }
        return '+41' . $phone_clean;
    }

    /* -------------------------------------------------------------- */
    /*  Email notifications                                            */
    /* -------------------------------------------------------------- */

    private function send_notifications( array $data, string $day_label, string $slot ): void {
        $emails_raw = ASL_Admin::get( 'notification_emails', '' );
        if ( '' === $emails_raw ) {
            return;
        }

        $recipients = array_filter( array_map( 'trim', explode( ',', $emails_raw ) ), 'is_email' );
        if ( empty( $recipients ) ) {
            return;
        }

        $site_name = get_bloginfo( 'name' );
        $now       = wp_date( 'd/m/Y H:i' );

        $subject = sprintf(
            '[%s] Nuovo accesso showroom — %s %s',
            $site_name,
            $data['first_name'],
            $data['last_name']
        );

        $body = sprintf(
            "Un visitatore ha richiesto il codice di accesso allo showroom.\n\n" .
            "📅  Data/Ora: %s\n" .
            "📆  Giorno:   %s %s\n\n" .
            "👤  Nome:      %s\n" .
            "👤  Cognome:   %s\n" .
            "📍  Indirizzo: %s\n" .
            "📞  Telefono:  %s\n" .
            "📧  E-mail:    %s\n\n" .
            "🔑  Codice mostrato: %s\n" .
            "🌐  IP: %s\n",
            $now,
            $day_label,
            $slot,
            $data['first_name'],
            $data['last_name'],
            $data['address'],
            $data['phone'],
            $data['email'],
            $data['code_shown'],
            $data['ip_address']
        );

        $headers = [ 'Content-Type: text/plain; charset=UTF-8' ];

        foreach ( $recipients as $to ) {
            wp_mail( $to, $subject, $body, $headers );
        }
    }

    /* -------------------------------------------------------------- */
    /*  Send code to visitor                                           */
    /* -------------------------------------------------------------- */

    private function send_code_to_visitor( array $data, string $code, string $day_label, string $slot ): void {
        $to = sanitize_email( $data['email'] ?? '' );
        if ( ! is_email( $to ) ) {
            return;
        }

        $site_name = get_bloginfo( 'name' );

        /* Placeholder map */
        $placeholders = [
            '{nome}'    => $data['first_name'],
            '{cognome}' => $data['last_name'],
            '{codice}'  => $code,
            '{giorno}'  => $day_label,
            '{fascia}'  => $slot,
            '{sito}'    => $site_name,
        ];

        /* Subject — use saved setting or fall back to default */
        $raw_subject = ASL_Admin::get( 'visitor_email_subject', '' );
        if ( '' === trim( $raw_subject ) ) {
            $raw_subject = '{sito} — Il tuo codice di accesso allo showroom';
        }
        $subject = str_replace( array_keys( $placeholders ), array_values( $placeholders ), $raw_subject );

        /* Body — use saved template or fall back to class constant */
        $raw_template = ASL_Admin::get( 'visitor_email_template', '' );
        if ( '' === trim( $raw_template ) ) {
            $raw_template = ASL_Admin::DEFAULT_VISITOR_EMAIL;
        }
        $body = str_replace( array_keys( $placeholders ), array_values( $placeholders ), $raw_template );

        $headers = [ 'Content-Type: text/plain; charset=UTF-8' ];

        wp_mail( $to, $subject, $body, $headers );
    }

    /* -------------------------------------------------------------- */
    /*  Send code to visitor via SMS (Twilio)                           */
    /* -------------------------------------------------------------- */

    private function send_sms_to_visitor( array $data, string $code, string $day_label, string $slot ): array {
        $phone = trim( $data['phone'] ?? '' );
        if ( '' === $phone ) {
            return [ 'success' => false, 'error' => 'Nessun numero di telefono fornito.' ];
        }

        $site_name = get_bloginfo( 'name' );

        /* Placeholder map (same as email) */
        $placeholders = [
            '{nome}'    => $data['first_name'],
            '{cognome}' => $data['last_name'],
            '{codice}'  => $code,
            '{giorno}'  => $day_label,
            '{fascia}'  => $slot,
            '{sito}'    => $site_name,
        ];

        /* Build SMS body from template */
        $raw_template = ASL_Admin::get( 'visitor_sms_template', '' );
        if ( '' === trim( $raw_template ) ) {
            $raw_template = ASL_Admin::DEFAULT_VISITOR_SMS;
        }
        $body = str_replace( array_keys( $placeholders ), array_values( $placeholders ), $raw_template );

        return ASL_Twilio::send_sms( $phone, $body );
    }
}
