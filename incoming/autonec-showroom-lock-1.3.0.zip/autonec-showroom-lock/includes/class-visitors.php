<?php
/**
 * Visitors database table helper.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ASL_Visitors {

    /**
     * Table name (without prefix).
     */
    const TABLE = 'asl_visitors';

    /**
     * Full table name with prefix.
     */
    private static function table(): string {
        global $wpdb;
        return $wpdb->prefix . self::TABLE;
    }

    /**
     * Create the visitors table on activation.
     */
    public static function create_table(): void {
        global $wpdb;
        $table   = self::table();
        $charset = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS {$table} (
            id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            first_name  VARCHAR(100) NOT NULL DEFAULT '',
            last_name   VARCHAR(100) NOT NULL DEFAULT '',
            address     VARCHAR(255) NOT NULL DEFAULT '',
            phone       VARCHAR(50)  NOT NULL DEFAULT '',
            email       VARCHAR(100) NOT NULL DEFAULT '',
            code_shown  VARCHAR(20)  NOT NULL DEFAULT '',
            ip_address  VARCHAR(45)  NOT NULL DEFAULT '',
            created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_email (email),
            KEY idx_created (created_at)
        ) {$charset};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }

    /**
     * Insert a visitor record.
     */
    public static function insert( array $data ): int {
        global $wpdb;
        $wpdb->insert( self::table(), [
            'first_name' => sanitize_text_field( $data['first_name'] ?? '' ),
            'last_name'  => sanitize_text_field( $data['last_name']  ?? '' ),
            'address'    => sanitize_text_field( $data['address']    ?? '' ),
            'phone'      => sanitize_text_field( $data['phone']      ?? '' ),
            'email'      => sanitize_email( $data['email']           ?? '' ),
            'code_shown' => sanitize_text_field( $data['code_shown'] ?? '' ),
            'ip_address' => sanitize_text_field( $data['ip_address'] ?? '' ),
        ], [ '%s', '%s', '%s', '%s', '%s', '%s', '%s' ] );

        return (int) $wpdb->insert_id;
    }

    /**
     * Get all visitors ordered by newest first.
     */
    public static function get_all( int $limit = 500 ): array {
        global $wpdb;
        $table = self::table();
        return $wpdb->get_results(
            $wpdb->prepare( "SELECT * FROM {$table} ORDER BY created_at DESC LIMIT %d", $limit )
        );
    }

    /**
     * Delete visitors by an array of IDs.
     *
     * @return int Number of deleted rows.
     */
    public static function delete_by_ids( array $ids ): int {
        global $wpdb;
        $table = self::table();
        $ids   = array_map( 'absint', $ids );
        $ids   = array_filter( $ids );
        if ( empty( $ids ) ) {
            return 0;
        }
        $placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
        return (int) $wpdb->query(
            $wpdb->prepare( "DELETE FROM {$table} WHERE id IN ({$placeholders})", ...$ids )
        );
    }
}
