<?php
/**
 * Page template without header and footer ("Pagina vuota").
 * Selected in the page editor or set by Showroom Lock → Promo online.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class( 'asl-blank' ); ?>>
<?php wp_body_open(); ?>
<main id="content" class="asl-blank__main">
    <?php
    while ( have_posts() ) {
        the_post();
        the_content();
    }
    ?>
</main>
<?php wp_footer(); ?>
</body>
</html>
