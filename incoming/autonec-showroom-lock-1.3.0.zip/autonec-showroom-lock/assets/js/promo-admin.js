/* Showroom Lock — Promo online admin: logo picker, placeholder pills, delete requests. */
jQuery(function ($) {
    var i18n = window.aslPromoAdmin || {};

    /* Logo picker */
    var frame;
    $('#asl-promo-logo-pick').on('click', function () {
        if (!frame) {
            frame = wp.media({ title: i18n.chooseLogo, button: { text: i18n.useLogo }, library: { type: 'image' }, multiple: false });
            frame.on('select', function () {
                var img = frame.state().get('selection').first().toJSON();
                $('#asl-promo-logo-id').val(img.id);
                $('#asl-promo-logo-preview').attr('src', (img.sizes && img.sizes.medium ? img.sizes.medium.url : img.url)).show();
                $('#asl-promo-logo-reset').prop('hidden', false);
            });
        }
        frame.open();
    });
    $('#asl-promo-logo-reset').on('click', function () {
        $('#asl-promo-logo-id').val(0);
        $('#asl-promo-logo-preview').hide();
        $(this).prop('hidden', true);
    });

    /* Placeholder pills */
    $('.asl-pill[data-ph]').on('click', function () {
        var ph = $(this).data('ph');
        var $ta = $(this).closest('.asl-card').find('textarea').last();
        if (!$ta.length) return;
        var pos = $ta[0].selectionStart;
        var val = $ta.val();
        $ta.val(val.slice(0, pos) + ph + val.slice(pos));
        $ta[0].setSelectionRange(pos + ph.length, pos + ph.length);
        $ta.trigger('focus');
    });

    /* Requests: select & delete */
    function updateCount() {
        var c = $('.asl-promo-row:checked').length;
        $('#asl-promo-sel-count').text(c);
        $('#asl-promo-delete').prop('disabled', c === 0);
        $('#asl-promo-check-all').prop('checked', c > 0 && c === $('.asl-promo-row').length);
    }
    $('#asl-promo-check-all').on('change', function () {
        $('.asl-promo-row').prop('checked', this.checked);
        updateCount();
    });
    $(document).on('change', '.asl-promo-row', updateCount);

    $('#asl-promo-delete').on('click', function () {
        var ids = $('.asl-promo-row:checked').map(function () { return this.value; }).get();
        if (!ids.length || !window.confirm((i18n.confirm || '').replace('%d', ids.length))) return;
        var $btn = $(this).prop('disabled', true);
        var $msg = $('#asl-promo-msg').text(i18n.deleting).css('color', '#64748b');
        $.post(ajaxurl, { action: 'asl_promo_delete', nonce: $('#asl-promo-nonce').val(), ids: ids }, function (res) {
            if (res.success) {
                ids.forEach(function (id) { $('tr[data-id="' + id + '"]').remove(); });
                $msg.text(res.data.message).css('color', '#16a34a');
            } else {
                $msg.text(res.data.message).css('color', '#dc2626');
            }
            updateCount();
        }).fail(function () {
            $msg.text(i18n.netError).css('color', '#dc2626');
            $btn.prop('disabled', false);
        });
    });
});
