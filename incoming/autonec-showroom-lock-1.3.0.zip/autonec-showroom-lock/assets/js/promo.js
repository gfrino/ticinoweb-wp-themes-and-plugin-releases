/* Showroom Lock — Promo online form */
(function () {
    'use strict';

    var form = document.getElementById('anp-form');
    if (!form || !window.aslPromo) {
        return;
    }

    var btn   = form.querySelector('.anp__submit');
    var label = btn.querySelector('.anp__submit-text');
    var busy  = btn.querySelector('.anp__submit-busy');
    var error = document.getElementById('anp-error');
    var done  = document.getElementById('anp-done');

    /* Car photo: preview + shrink in the browser (phone photos are 3–8 MB) */
    var photoInput  = document.getElementById('anp-photo');
    var photoEmpty  = form.querySelector('.anp__photo-empty');
    var photoFilled = form.querySelector('.anp__photo-filled');
    var photoImg    = document.getElementById('anp-photo-preview');
    var photoBlob   = null;
    var photoReady  = Promise.resolve();
    var MAX_SIDE    = 2000;

    function shrink(file) {
        if (!window.createImageBitmap || !file.type || file.type.indexOf('image/') !== 0) {
            return Promise.resolve(null);
        }
        return createImageBitmap(file, { imageOrientation: 'from-image' }).then(function (bmp) {
            var scale = Math.min(1, MAX_SIDE / Math.max(bmp.width, bmp.height));
            var canvas = document.createElement('canvas');
            canvas.width  = Math.round(bmp.width * scale);
            canvas.height = Math.round(bmp.height * scale);
            canvas.getContext('2d').drawImage(bmp, 0, 0, canvas.width, canvas.height);
            if (bmp.close) { bmp.close(); }
            return new Promise(function (resolve) {
                canvas.toBlob(function (blob) {
                    resolve(blob && blob.size < file.size ? blob : null);
                }, 'image/jpeg', 0.85);
            });
        }).catch(function () { return null; });
    }

    if (photoInput) {
        photoInput.addEventListener('change', function () {
            var file = photoInput.files && photoInput.files[0];
            photoBlob = null;
            if (photoImg.src) { URL.revokeObjectURL(photoImg.src); }
            if (!file) {
                photoEmpty.hidden  = false;
                photoFilled.hidden = true;
                photoReady = Promise.resolve();
                return;
            }
            photoImg.src       = URL.createObjectURL(file);
            photoEmpty.hidden  = true;
            photoFilled.hidden = false;
            photoReady = shrink(file).then(function (blob) { photoBlob = blob; });
        });
    }

    function setBusy(on) {
        btn.disabled = on;
        btn.setAttribute('aria-busy', on ? 'true' : 'false');
        label.hidden = on;
        busy.hidden  = !on;
    }

    function showError(msg) {
        error.textContent = msg;
        error.hidden = false;
    }

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        error.hidden = true;

        if (!form.reportValidity()) {
            return;
        }

        setBusy(true);

        photoReady.then(function () {
            var data = new FormData(form);
            data.append('action', 'asl_promo_submit');
            data.append('nonce', window.aslPromo.nonce);
            if (photoBlob) {
                data.set('photo', photoBlob, 'foto-auto.jpg');
            }
            return fetch(window.aslPromo.ajax_url, { method: 'POST', body: data, credentials: 'same-origin' });
        })
            .then(function (r) { return r.json(); })
            .then(function (res) {
                if (!res || !res.success) {
                    setBusy(false);
                    showError(res && res.data && res.data.message ? res.data.message : window.aslPromo.error);
                    return;
                }
                document.getElementById('anp-done-email').textContent = res.data.email || '';
                form.hidden = true;
                done.hidden = false;
                done.focus();
                done.scrollIntoView({ behavior: 'smooth', block: 'center' });
            })
            .catch(function () {
                setBusy(false);
                showError(window.aslPromo.error);
            });
    });
})();
