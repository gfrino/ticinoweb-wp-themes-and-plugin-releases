/**
 * Frontend – Autonec Showroom Lock
 */
(function () {
    "use strict";

    document.addEventListener("DOMContentLoaded", function () {
        var form       = document.getElementById("asl-form");
        var formWrap   = document.getElementById("asl-form-wrap");
        var resultWrap = document.getElementById("asl-result-wrap");
        var errorBox   = document.getElementById("asl-error");
        var btnText    = form ? form.querySelector(".asl-btn-text") : null;
        var btnLoading = form ? form.querySelector(".asl-btn-loading") : null;

        var phoneInput = document.getElementById("asl-phone");

        function formatPhone() {
            if (!phoneInput) return;
            var val = phoneInput.value.trim();
            if (!val) return;

            // Strip spaces, dashes, dots, parentheses
            var clean = val.replace(/[\s\-\.\(\)]/g, "");

            // Convert 00 prefix to +
            if (clean.indexOf("00") === 0) {
                clean = "+" + clean.substring(2);
            }

            if (clean.indexOf("+") === 0) {
                phoneInput.value = clean;
            } else {
                // Default to Swiss (+41)
                if (clean.indexOf("0") === 0) {
                    phoneInput.value = "+41" + clean.substring(1);
                } else {
                    phoneInput.value = "+41" + clean;
                }
            }
        }

        if (phoneInput) {
            phoneInput.addEventListener("blur", formatPhone);
        }

        if (!form) return;

        form.addEventListener("submit", function (e) {
            e.preventDefault();
            formatPhone();
            errorBox.style.display = "none";
            btnText.style.display = "none";
            btnLoading.style.display = "inline-flex";

            var fd = new FormData(form);
            fd.append("action", "asl_submit");
            fd.append("nonce", asl.nonce);

            fetch(asl.ajax_url, { method: "POST", body: fd })
                .then(function (r) { return r.json(); })
                .then(function (res) {
                    btnText.style.display = "";
                    btnLoading.style.display = "none";

                    if (res.success) {
                        /* Hide form, show confirmation */
                        formWrap.classList.add("asl-fade-out");
                        setTimeout(function () {
                            formWrap.style.display = "none";
                            resultWrap.style.display = "";
                            resultWrap.classList.add("asl-fade-in");

                            document.getElementById("asl-time-label").textContent = res.data.label;
                            document.getElementById("asl-sent-email").textContent = res.data.email;

                            /* Show SMS confirmation if sent */
                            var titleEl = document.getElementById("asl-result-title");
                            var smsEl   = document.getElementById("asl-sent-sms");
                            if (res.data.sms_sent && smsEl) {
                                titleEl.textContent = "E-mail e SMS inviati!";
                                smsEl.textContent = "📱 SMS inviato a: " + res.data.phone;
                                smsEl.style.display = "";
                            }
                        }, 400);
                    } else {
                        errorBox.textContent = res.data.message;
                        errorBox.style.display = "";
                        shakeForm();
                    }
                })
                .catch(function () {
                    btnText.style.display = "";
                    btnLoading.style.display = "none";
                    errorBox.textContent = "Errore di connessione. Riprova.";
                    errorBox.style.display = "";
                });
        });

        /* Shake animation on error */
        function shakeForm() {
            form.classList.add("asl-shake");
            setTimeout(function () {
                form.classList.remove("asl-shake");
            }, 600);
        }
    });
})();
