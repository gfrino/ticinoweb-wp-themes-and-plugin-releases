<?php
/**
 * Show the imported homepage while its Elementor content is retained.
 *
 * @package WistariaChildTheme
 */

get_header();
?>
<main id="content" class="wistaria-home">
	<?php
	while ( have_posts() ) :
		the_post();
		the_content();
	endwhile;
	?>
</main>
<?php
get_footer();
