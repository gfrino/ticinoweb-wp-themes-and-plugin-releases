<?php
/**
 * Wistaria child theme bootstrap.
 *
 * @package WistariaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The parent's legacy stylesheet hides Elementor content site-wide. Keep the
 * parent PHP features while the imported pages still depend on Elementor.
 */
function wistaria_enqueue_styles() {
	wp_dequeue_style( 'ticinoweb-ai-style' );
	wp_deregister_style( 'ticinoweb-ai-style' );

	$child = wp_get_theme();

	wp_enqueue_style(
		'wistaria-child-style',
		get_stylesheet_uri(),
		array(),
		$child->get( 'Version' )
	);
}
add_action( 'wp_enqueue_scripts', 'wistaria_enqueue_styles', 20 );
