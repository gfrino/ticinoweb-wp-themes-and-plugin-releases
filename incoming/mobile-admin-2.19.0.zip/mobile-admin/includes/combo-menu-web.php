<?php
/**
 * Menù combinati sul sito web delle sedi (v2.15.0)
 *
 * Same offer as the app, same data: when the cart holds a poké and no drink or
 * dessert, the cart and checkout pages open a popup «Fai il tuo menù» (the menus
 * of Gestione App → Menù combinati, with the products this sede sells) and, if
 * the customer skips it, «Aggiungi una bibita». Nothing to set up per sede: the
 * popup follows the hub switches, prices and products.
 *
 *  - The chosen products go in the cart with the menu price split among them
 *    (proportional to their normal prices), the line shows «Menù: …» in cart,
 *    order, e-mails and kitchen ticket.
 *  - A menu is valid only next to a poké: one menu per poké in the cart, a menu
 *    line counts once (quantity fixed to 1), otherwise the normal price applies.
 *  - Prices are always computed on the server from the hub settings; the browser
 *    only sends which menu and which products.
 */

defined( 'ABSPATH' ) || exit;

/** Is the current site a sede of the brand (WooCommerce, not the hub)? Cached per site for an hour. */
function ARD_combo_web_is_sede() {
	static $is = null;
	if ( null !== $is ) {
		return $is;
	}
	if ( ! function_exists( 'WC' ) || ! is_multisite() || ARD_payment_methods_is_hub() ) {
		return $is = false;
	}
	$key    = 'ard_combo_web_sede_' . get_current_blog_id();
	$cached = get_site_transient( $key );
	if ( false === $cached ) {
		$ids    = array_map( 'ARD_combo_blog_id', array_keys( ARD_payment_methods_sites() ) );
		$cached = in_array( get_current_blog_id(), $ids, true ) ? 'yes' : 'no';
		set_site_transient( $key, $cached, HOUR_IN_SECONDS );
	}
	return $is = ( 'yes' === $cached );
}

/** The combo data of this sede (same as REST combo-menu), cached 5 minutes and flushed when the hub saves. */
function ARD_combo_web_data() {
	static $data = null;
	if ( null !== $data ) {
		return $data;
	}
	$key  = 'ard_combo_web_' . get_current_blog_id();
	$data = get_site_transient( $key );
	if ( ! is_array( $data ) ) {
		$data = ARD_combo_build_for_blog( get_current_blog_id() );
		set_site_transient( $key, $data, 5 * MINUTE_IN_SECONDS );
	}
	$data['groups'] = (array) $data['groups'];
	return $data;
}

/**
 * What the cart holds: poké units, whether a drink/dessert is already there, the menus in it.
 *
 * @return array{poke:int, blocked:bool, combos:array<string,bool>}
 */
function ARD_combo_web_cart_state() {
	$state = array( 'poke' => 0, 'blocked' => false, 'combos' => array() );
	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		return $state;
	}
	$data = ARD_combo_web_data();
	foreach ( WC()->cart->get_cart() as $item ) {
		if ( ! empty( $item['ard_combo']['id'] ) ) {
			$state['combos'][ $item['ard_combo']['id'] ] = true;
			continue;
		}
		$cats = wc_get_product_cat_ids( (int) $item['product_id'] );
		if ( array_intersect( $cats, $data['poke_category_ids'] ) ) {
			$state['poke'] += (int) $item['quantity'];
		} elseif ( in_array( (int) $item['product_id'], $data['skip_product_ids'], true ) || array_intersect( $cats, $data['skip_category_ids'] ) ) {
			$state['blocked'] = true;
		}
	}
	return $state;
}

/** Popup due on this page view? */
function ARD_combo_web_should_offer() {
	if ( ! ARD_combo_web_is_sede() || ! function_exists( 'is_cart' ) || ! ( is_cart() || is_checkout() ) || is_wc_endpoint_url() ) {
		return false;
	}
	if ( WC()->session && WC()->session->get( 'ard_combo_done' ) ) {
		return false;
	}
	$data = ARD_combo_web_data();
	if ( empty( $data['enabled'] ) && empty( $data['drinks_enabled'] ) ) {
		return false;
	}
	return ARD_combo_web_offer_menus() || ARD_combo_web_offer_upsell_only();
}

/** The menu page applies: a poké (base product) without drink/dessert and no menu yet. */
function ARD_combo_web_offer_menus() {
	$state = ARD_combo_web_cart_state();
	return $state['poke'] > 0 && ! $state['blocked'] && ! $state['combos'];
}

/** Upsell set to «Sempre» (2.19.0): offered before every payment, also without a poké. */
function ARD_combo_web_offer_upsell_only() {
	$data = ARD_combo_web_data();
	return ! empty( $data['drinks_always'] ) && ! empty( $data['drinks_enabled'] ) && ! empty( $data['drinks'] )
		&& WC()->cart && ! WC()->cart->is_empty();
}

/** Price as plain text, e.g. «CHF 4.00». */
function ARD_combo_web_money( $amount ) {
	return html_entity_decode( wp_strip_all_tags( wc_price( (float) $amount ) ), ENT_QUOTES, 'UTF-8' );
}

/* ------------------------------------------------------------- the popup */

add_action( 'wp_enqueue_scripts', function () {
	if ( ! ARD_combo_web_should_offer() ) {
		return;
	}
	$data   = ARD_combo_web_data();
	$groups = array();
	foreach ( $data['groups'] as $key => $group ) {
		$groups[ $key ] = array(
			'label'    => $group['label'],
			'emoji'    => $group['emoji'],
			'products' => array_map( static function ( $p ) {
				return array( 'id' => $p['id'], 'name' => $p['name'], 'image' => $p['image'] );
			}, $group['products'] ),
		);
	}
	$version = '2.15.0'; // cache-buster of the two files below: raise with every change to them
	wp_enqueue_style( 'ard-combo-web', WPADR_URL . 'assets/combo-web.css', array(), $version );
	wp_enqueue_script( 'ard-combo-web', WPADR_URL . 'assets/combo-web.js', array(), $version, array( 'in_footer' => true, 'strategy' => 'defer' ) );
	wp_localize_script( 'ard-combo-web', 'ardComboWeb', array(
		'ajax'   => array(
			'menu'  => WC_AJAX::get_endpoint( 'ard_combo_menu' ),
			'drink' => WC_AJAX::get_endpoint( 'ard_combo_drink' ),
			'skip'  => WC_AJAX::get_endpoint( 'ard_combo_skip' ),
		),
		'nonce'  => wp_create_nonce( 'ard_combo_web' ),
		// Without the menu case (e.g. only sushi, «Sempre») the popup opens on the Upsell page.
		'menus'  => ! empty( $data['enabled'] ) && ARD_combo_web_offer_menus() ? array_map( static function ( $m ) use ( $data ) {
			$emoji = '';
			foreach ( $m['groups'] as $g ) {
				$emoji .= $data['groups'][ $g ]['emoji'] ?? '';
			}
			return array( 'key' => $m['key'], 'label' => $m['label'], 'emoji' => $emoji, 'price' => '+ ' . ARD_combo_web_money( $m['price'] ), 'groups' => $m['groups'] );
		}, $data['menus'] ) : array(),
		'groups' => $groups,
		'drinks' => ! empty( $data['drinks_enabled'] ) ? array_map( static function ( $p ) {
			return array( 'id' => $p['id'], 'name' => $p['name'], 'image' => $p['image'], 'price' => ARD_combo_web_money( $p['price'] ) );
		}, $data['drinks'] ) : array(),
		'i18n'   => array(
			'menuTitle'   => __( 'Fai il tuo menù', 'wp-app-dashboard' ),
			// Poké wording only while the base categories are the automatic (poké) ones.
			'menuText'    => ! isset( $data['base_auto'] ) || $data['base_auto'] ? __( 'Completa la tua poké con un menù a prezzo speciale.', 'wp-app-dashboard' ) : __( 'Completa il tuo ordine con un menù a prezzo speciale.', 'wp-app-dashboard' ),
			'choose'      => __( 'Scegli', 'wp-app-dashboard' ),
			'addMenu'     => __( 'Aggiungi il menù', 'wp-app-dashboard' ),
			'noThanks'    => __( 'No, grazie', 'wp-app-dashboard' ),
			'drinkTitle'  => ARD_combo_web_text( $data, 'drinks_title' ) ?: __( 'Aggiungi una bibita?', 'wp-app-dashboard' ),
			'drinkText'   => ARD_combo_web_text( $data, 'drinks_subtitle' ) ?: ( ( ! isset( $data['base_auto'] ) || $data['base_auto'] ) && ARD_combo_web_offer_menus() ? __( 'Da bere con la tua poké.', 'wp-app-dashboard' ) : __( 'Qualcosa da bere?', 'wp-app-dashboard' ) ),
			'add'         => __( 'Aggiungi', 'wp-app-dashboard' ),
			'continue'    => __( 'Continua senza', 'wp-app-dashboard' ),
			'close'       => __( 'Chiudi', 'wp-app-dashboard' ),
			'error'       => __( 'Non è stato possibile aggiungerlo. Riprova.', 'wp-app-dashboard' ),
		),
	) );
} );

/** Text written in Menù combinati for the site's language (it, en, de, fr), '' if none. */
function ARD_combo_web_text( array $data, $field ) {
	$texts = (array) ( $data[ $field ] ?? array() );
	$lang  = substr( determine_locale(), 0, 2 );
	return (string) ( $texts[ $lang ] ?? '' );
}

/* ---------------------------------------------------------- AJAX actions */

/** Common checks of the three actions: nonce and sede. Ends the request on failure. */
function ARD_combo_web_check_request() {
	if ( ! check_ajax_referer( 'ard_combo_web', 'nonce', false ) || ! ARD_combo_web_is_sede() ) {
		wp_send_json_error( array( 'message' => __( 'Sessione scaduta: ricarica la pagina.', 'wp-app-dashboard' ) ), 403 );
	}
}

/** Index of a product list by id. */
function ARD_combo_web_by_id( array $products ) {
	$out = array();
	foreach ( $products as $p ) {
		$out[ (int) $p['id'] ] = $p;
	}
	return $out;
}

add_action( 'wc_ajax_ard_combo_menu', function () {
	ARD_combo_web_check_request();
	$data  = ARD_combo_web_data();
	$key   = sanitize_key( wp_unslash( $_POST['menu'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification -- checked above
	$picks = array_map( 'absint', (array) wp_unslash( $_POST['picks'] ?? array() ) ); // phpcs:ignore WordPress.Security.NonceVerification,WordPress.Security.ValidatedSanitizedInput -- checked above, cast to int
	$menu  = null;
	foreach ( $data['enabled'] ? $data['menus'] : array() as $m ) {
		if ( $m['key'] === $key ) {
			$menu = $m;
		}
	}
	$state = ARD_combo_web_cart_state();
	if ( ! $menu || $state['poke'] < 1 || count( $state['combos'] ) >= $state['poke'] ) {
		wp_send_json_error( array( 'message' => __( 'Questo menù non è disponibile.', 'wp-app-dashboard' ) ), 400 );
	}

	// One product per component, chosen among the ones this sede sells.
	$chosen = array();
	foreach ( $menu['groups'] as $g ) {
		$list = ARD_combo_web_by_id( $data['groups'][ $g ]['products'] ?? array() );
		$id   = (int) ( $picks[ $g ] ?? 0 );
		if ( ! isset( $list[ $id ] ) ) {
			wp_send_json_error( array( 'message' => __( 'Scegli un prodotto per ogni parte del menù.', 'wp-app-dashboard' ) ), 400 );
		}
		$chosen[] = $list[ $id ];
	}

	// Menu price split among the products, proportional to their prices; the rest on the last one.
	$total  = array_sum( array_map( static function ( $p ) { return (float) $p['price']; }, $chosen ) );
	$left   = (float) $menu['price'];
	$combo  = strtolower( wp_generate_password( 10, false, false ) );
	$count  = count( $chosen );
	foreach ( $chosen as $i => $p ) {
		$share = $i === $count - 1 ? $left : round( $total > 0 ? $menu['price'] * $p['price'] / $total : $menu['price'] / $count, 2 );
		$left  = round( $left - $share, 2 );
		$added = WC()->cart->add_to_cart( (int) $p['id'], 1, 0, array(), array(
			'ard_combo' => array( 'id' => $combo, 'key' => $menu['key'], 'label' => $menu['label'], 'price' => max( 0, $share ) ),
		) );
		if ( ! $added ) {
			foreach ( WC()->cart->get_cart() as $cart_key => $item ) {
				if ( ( $item['ard_combo']['id'] ?? '' ) === $combo ) {
					WC()->cart->remove_cart_item( $cart_key );
				}
			}
			wp_send_json_error( array( 'message' => __( 'Non è stato possibile aggiungerlo. Riprova.', 'wp-app-dashboard' ) ), 400 );
		}
	}
	WC()->session->set( 'ard_combo_done', 1 );
	wp_send_json_success();
} );

add_action( 'wc_ajax_ard_combo_drink', function () {
	ARD_combo_web_check_request();
	$data   = ARD_combo_web_data();
	$drinks = $data['drinks_enabled'] ? ARD_combo_web_by_id( $data['drinks'] ) : array();
	$id     = absint( wp_unslash( $_POST['product'] ?? 0 ) ); // phpcs:ignore WordPress.Security.NonceVerification -- checked above
	if ( ! isset( $drinks[ $id ] ) || ! WC()->cart->add_to_cart( $id, 1 ) ) {
		wp_send_json_error( array( 'message' => __( 'Non è stato possibile aggiungerlo. Riprova.', 'wp-app-dashboard' ) ), 400 );
	}
	WC()->session->set( 'ard_combo_done', 1 );
	wp_send_json_success();
} );

add_action( 'wc_ajax_ard_combo_skip', function () {
	ARD_combo_web_check_request();
	WC()->session->set( 'ard_combo_done', 1 );
	wp_send_json_success();
} );

// A new order starts a new offer: cart emptied (order placed) or its last product removed.
function ARD_combo_web_reset_offer() {
	if ( WC()->session && ( ! WC()->cart || WC()->cart->is_empty() ) ) {
		WC()->session->set( 'ard_combo_done', null );
	}
}
add_action( 'woocommerce_cart_emptied', 'ARD_combo_web_reset_offer' );
add_action( 'woocommerce_cart_item_removed', 'ARD_combo_web_reset_offer' );

/* ------------------------------------------------- price, cart and order */

/**
 * Menu price on its products: one menu per poké, a menu line counts once (more units: the others at the normal
 * price). Without a poké the menu no longer applies and the normal prices come back.
 */
add_action( 'woocommerce_before_calculate_totals', function ( $cart ) {
	$combos = array();
	foreach ( $cart->get_cart() as $key => $item ) {
		if ( ! empty( $item['ard_combo']['id'] ) ) {
			$combos[ $item['ard_combo']['id'] ][] = $key;
		}
	}
	if ( ! $combos || ! ARD_combo_web_is_sede() ) {
		return;
	}
	$allowed = ARD_combo_web_cart_state()['poke'];
	foreach ( $combos as $keys ) {
		$active = $allowed-- > 0;
		foreach ( $keys as $key ) {
			$item = $cart->cart_contents[ $key ];
			$cart->cart_contents[ $key ]['ard_combo']['active'] = $active;
			if ( ! $active ) {
				continue;
			}
			$qty    = max( 1, (int) $item['quantity'] );
			$normal = 1 === $qty ? 0.0 : (float) wc_get_product( $item['data']->get_id() )->get_price( 'edit' ); // fresh: totals may run more than once
			$item['data']->set_price( round( ( (float) $item['ard_combo']['price'] + ( $qty - 1 ) * $normal ) / $qty, 4 ) );
		}
	}
}, 20 );

// Menu lines: quantity fixed to 1 in the cart.
add_filter( 'woocommerce_cart_item_quantity', function ( $html, $key, $item ) {
	return ! empty( $item['ard_combo']['id'] ) ? sprintf( '1 <input type="hidden" name="cart[%s][qty]" value="1" />', esc_attr( $key ) ) : $html;
}, 10, 3 );

add_filter( 'woocommerce_get_item_data', function ( $rows, $item ) {
	if ( ! empty( $item['ard_combo']['id'] ) && ( $item['ard_combo']['active'] ?? true ) ) {
		$rows[] = array( 'key' => __( 'Menù', 'wp-app-dashboard' ), 'value' => $item['ard_combo']['label'] );
	}
	return $rows;
}, 10, 2 );

// In the order (admin, e-mails, kitchen ticket): «Menù: Pokè + Acqua».
add_action( 'woocommerce_checkout_create_order_line_item', function ( $line, $key, $values ) {
	if ( ! empty( $values['ard_combo']['id'] ) && ( $values['ard_combo']['active'] ?? true ) ) {
		$line->add_meta_data( __( 'Menù', 'wp-app-dashboard' ), $values['ard_combo']['label'], true );
		$line->add_meta_data( '_ard_combo', $values['ard_combo']['key'] . ':' . $values['ard_combo']['id'], true );
	}
}, 10, 3 );
