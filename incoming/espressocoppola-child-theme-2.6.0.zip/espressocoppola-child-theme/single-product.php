<?php
/**
 * THESIS: The product is encountered as a coffee ritual, not a stock WooCommerce split-card.
 * OWN-WORLD: Warm cream stage, espresso typography, champagne data drawing and restrained orbital lines.
 * STORY: Identify, choose, buy, then discover the product's real sensory signature and details.
 * FIRST VIEWPORT: Editorial purchase copy and controls orbit a large responsive product image.
 * FORM: An immersive commerce stage extending the established Espresso Coppola visual system.
 *
 * @package EspressoCoppolaChildTheme
 */

defined( 'ABSPATH' ) || exit;

get_header();

while ( have_posts() ) :
	the_post();
	global $product;
	$product = wc_get_product( get_the_ID() );
	if ( ! $product instanceof WC_Product ) {
		continue;
	}

	$context = espressocoppola_get_single_product_context( $product );
	do_action( 'woocommerce_before_single_product' );
	if ( post_password_required() ) {
		echo get_the_password_form(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		continue;
	}
	$main_image_id = ! empty( $context['image_ids'][0] ) ? (int) $context['image_ids'][0] : 0;
	?>
	<main id="primary" class="ec-product" data-product-page>
		<article id="product-<?php the_ID(); ?>" <?php wc_product_class( 'ec-product__article', $product ); ?>>
			<section class="ec-product-stage" data-product-stage>
				<div class="ec-product-stage__atmosphere" aria-hidden="true">
					<span class="ec-product-stage__orbit"></span><span class="ec-product-stage__bean"></span>
					<?php if ( $context['stage_word'] ) : ?><span class="ec-product-stage__word"><?php echo esc_html( $context['stage_word'] ); ?></span><?php endif; ?>
				</div>
				<div class="ec-product-stage__inner">
					<header class="ec-product-stage__intro">
						<div class="ec-product-stage__top-meta">
							<nav class="ec-product-stage__breadcrumb" aria-label="<?php esc_attr_e( 'Percorso prodotto', 'espressocoppola-child-theme' ); ?>">
								<a href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>"><?php esc_html_e( 'Collezione', 'espressocoppola-child-theme' ); ?></a><span aria-hidden="true">/</span><span><?php echo esc_html( $context['types'][0]['name'] ?? __( 'Espresso Coppola', 'espressocoppola-child-theme' ) ); ?></span>
							</nav>
							<div class="ec-product-stage__stock<?php echo $product->is_in_stock() ? ' is-in-stock' : ' is-out-of-stock'; ?>" data-product-stock role="status"><span aria-hidden="true"></span><?php echo esc_html( $product->is_in_stock() ? __( 'Disponibile', 'espressocoppola-child-theme' ) : __( 'Non disponibile', 'espressocoppola-child-theme' ) ); ?></div>
						</div>
						<?php if ( $context['classification'] ) : ?><p class="ec-product-stage__classification"><?php echo esc_html( $context['classification'] ); ?></p><?php endif; ?>
						<h1><?php the_title(); ?></h1>
						<?php if ( $context['short_description'] ) : ?><div class="ec-product-stage__summary"><?php echo $context['short_description']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><?php endif; ?>
					</header>
					<div class="ec-product-stage__visual" data-product-visual>
						<div class="ec-product-stage__halo" aria-hidden="true"></div>
						<div class="ec-product-stage__image-wrap">
							<?php
							if ( $main_image_id ) {
								echo wp_get_attachment_image(
									$main_image_id,
									'woocommerce_single',
									false,
									array(
										'class'         => 'ec-product-stage__image',
										'loading'       => 'eager',
										'fetchpriority' => 'high',
										'decoding'      => 'async',
										'sizes'         => '(max-width: 780px) 92vw, (max-width: 1280px) 54vw, 48vw',
										'data-product-main-image' => '',
									)
								); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							} else {
								echo wc_placeholder_img( 'woocommerce_single', array( 'class' => 'ec-product-stage__image', 'data-product-main-image' => '' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							}
							?>
						</div>
						<?php if ( count( $context['image_ids'] ) > 1 ) : ?>
							<div class="ec-product-stage__gallery" aria-label="<?php esc_attr_e( 'Galleria prodotto', 'espressocoppola-child-theme' ); ?>">
								<?php foreach ( $context['image_ids'] as $index => $image_id ) :
									$src    = wp_get_attachment_image_src( $image_id, 'woocommerce_single' );
									$srcset = wp_get_attachment_image_srcset( $image_id, 'woocommerce_single' );
									$alt    = get_post_meta( $image_id, '_wp_attachment_image_alt', true );
									?>
									<button type="button" class="<?php echo 0 === $index ? 'is-active' : ''; ?>" aria-pressed="<?php echo 0 === $index ? 'true' : 'false'; ?>" data-product-gallery-thumb data-src="<?php echo esc_url( $src ? $src[0] : '' ); ?>" data-srcset="<?php echo esc_attr( $srcset ); ?>" data-alt="<?php echo esc_attr( $alt ); ?>">
										<?php echo wp_get_attachment_image( $image_id, 'woocommerce_gallery_thumbnail', false, array( 'loading' => 'lazy', 'decoding' => 'async' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
										<span class="screen-reader-text"><?php echo esc_html( sprintf( __( 'Mostra immagine %d', 'espressocoppola-child-theme' ), $index + 1 ) ); ?></span>
									</button>
								<?php endforeach; ?>
							</div>
						<?php endif; ?>
					</div>

					<div class="ec-product-stage__purchase">
						<?php if ( $context['quick_facts'] ) : ?>
							<dl class="ec-product-stage__quick-facts">
								<?php foreach ( $context['quick_facts'] as $fact ) : ?><div><dt><?php echo esc_html( $fact['label'] ); ?></dt><dd><?php echo esc_html( $fact['value'] ); ?></dd></div><?php endforeach; ?>
							</dl>
						<?php endif; ?>
						<div class="ec-product-stage__price" data-product-price><?php woocommerce_template_single_price(); ?></div>
						<div class="ec-product-stage__cart"><?php woocommerce_template_single_add_to_cart(); ?></div>
						<?php if ( $context['has_profile'] ) : ?>
							<a class="ec-product-stage__sensory-teaser" href="#profilo-sensoriale" data-sensory-jump>
								<svg viewBox="0 0 520 520" aria-hidden="true" data-product-mini-radar data-values="<?php echo esc_attr( wp_json_encode( $context['profile']['values'] ) ); ?>" data-color="<?php echo esc_attr( $context['profile']['color'] ); ?>"></svg>
								<span><strong><?php esc_html_e( 'Profilo sensoriale', 'espressocoppola-child-theme' ); ?></strong><small><?php esc_html_e( 'Scopri i sette tratti di questa miscela', 'espressocoppola-child-theme' ); ?></small></span><i aria-hidden="true">↘</i>
							</a>
						<?php endif; ?>
					</div>
				</div>
			</section>

			<?php get_template_part( 'template-parts/product/experience', null, array( 'context' => $context ) ); ?>
		</article>
	</main>
	<?php do_action( 'woocommerce_after_single_product' ); ?>
	<?php
endwhile;

get_footer();
