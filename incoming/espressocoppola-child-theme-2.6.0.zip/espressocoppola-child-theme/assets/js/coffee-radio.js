(function (global) {
	'use strict';

	function formatTime(value) {
		const seconds = Number.isFinite(value) && value > 0 ? Math.floor(value) : 0;
		return Math.floor(seconds / 60) + ':' + String(seconds % 60).padStart(2, '0');
	}

	function formatProgressText(currentTime, duration) {
		return formatTime(currentTime) + ' / ' + formatTime(duration);
	}

	function shouldDestroyOnPageHide(event) {
		return !(event && event.persisted);
	}

	function createAudioVisualizer(media, AudioContext) {
		let analyser = null;
		let context = null;
		let source = null;

		async function prime() {
			if (!AudioContext) {
				return null;
			}

			if (!context) {
				context = new AudioContext();
			}
			if (context.state === 'suspended') {
				await context.resume();
			}
			if (context.state !== 'running') {
				return null;
			}

			if (!source) {
				source = context.createMediaElementSource(media);
				analyser = context.createAnalyser();
				analyser.fftSize = 64;
				analyser.smoothingTimeConstant = 0.82;
				source.connect(analyser);
				analyser.connect(context.destination);
			}

			return analyser;
		}

		function destroy() {
			if (source) {
				source.disconnect();
			}
			if (analyser) {
				analyser.disconnect();
			}
			if (context && context.state !== 'closed') {
				context.close();
			}
		}

		return {
			destroy,
			getAnalyser: function () { return analyser; },
			prime,
		};
	}

	function createMediaController(media, render) {
		let playRequest = null;
		let playGeneration = 0;
		const state = {
			currentTime: 0,
			duration: 0,
			status: 'idle',
		};

		function update(status) {
			if (status) {
				state.status = status;
			}
			state.currentTime = Number.isFinite(media.currentTime) ? media.currentTime : 0;
			state.duration = Number.isFinite(media.duration) ? media.duration : 0;
			render({ ...state });
		}

		media.addEventListener('play', function () {
			update('playing');
		});
		media.addEventListener('pause', function () {
			update(media.ended ? 'ended' : 'paused');
		});
		media.addEventListener('waiting', function () {
			update('loading');
		});
		media.addEventListener('playing', function () {
			update('playing');
		});
		media.addEventListener('timeupdate', function () {
			update();
		});
		media.addEventListener('loadedmetadata', function () {
			update();
		});
		media.addEventListener('ended', function () {
			update('ended');
		});
		media.addEventListener('error', function () {
			state.error = media.error && media.error.message ? media.error.message : 'Media unavailable';
			update('error');
		});

		async function toggle() {
			if (playRequest) {
				return playRequest;
			}
			if (media.paused || media.ended) {
				const requestGeneration = ++playGeneration;
				playRequest = (async function () {
					try {
						await media.play();
						if (requestGeneration !== playGeneration && !media.paused) {
							media.pause();
						}
					} catch (error) {
						if (requestGeneration === playGeneration) {
							state.error = error && error.message ? error.message : String(error);
							update('error');
						}
					} finally {
						playRequest = null;
					}
				})();
				return playRequest;
			}
			pause();
		}

		function pause() {
			playGeneration += 1;
			media.pause();
		}

		function seekToRatio(value) {
			const ratio = Math.min(1, Math.max(0, Number(value) || 0));
			if (Number.isFinite(media.duration) && media.duration > 0) {
				media.currentTime = media.duration * ratio;
				update();
			}
		}

		return { pause, seekToRatio, toggle };
	}

	global.EspressoCoffeeRadioCore = {
		createAudioVisualizer,
		createMediaController,
		formatProgressText,
		formatTime,
		shouldDestroyOnPageHide,
	};

	if (!global.document) {
		return;
	}

	global.document.querySelectorAll('[data-coffee-radio]').forEach(function (shell) {
		const media = shell.querySelector('[data-radio-media]');
		const pill = shell.querySelector('[data-radio-open]');
		const player = shell.querySelector('.ec-radio-player');
		const closeButton = shell.querySelector('[data-radio-close]');
		const toggleButton = shell.querySelector('[data-radio-toggle]');
		const toggleLabel = shell.querySelector('[data-radio-toggle-label]');
		const progress = shell.querySelector('[data-radio-progress]');
		const current = shell.querySelector('[data-radio-current]');
		const duration = shell.querySelector('[data-radio-duration]');
		const status = shell.querySelector('[data-radio-status]');
		const bars = Array.from(shell.querySelectorAll('[data-radio-visualizer] i'));
		const reduceMotion = global.matchMedia('(prefers-reduced-motion: reduce)');
		let closeTimer = 0;
		let previousStatus = 'idle';
		let frequencyData = null;
		let visualizerFrame = 0;

		if (!media || !pill || !player || !closeButton || !toggleButton || !toggleLabel || !progress || !current || !duration) {
			return;
		}

		function messageFor(state) {
			const messages = {
				ended: shell.dataset.radioMessageEnded,
				error: shell.dataset.radioMessageError,
				idle: shell.dataset.radioMessageIdle,
				loading: shell.dataset.radioMessageLoading,
				paused: shell.dataset.radioMessagePaused,
				playing: shell.dataset.radioMessagePlaying,
			};
			return messages[state.status] || '';
		}

		function render(state) {
			const isPlaying = state.status === 'playing';
			const ratio = state.duration > 0 ? state.currentTime / state.duration : 0;
			shell.dataset.state = state.status;
			shell.classList.toggle('is-playing', isPlaying);
			toggleLabel.textContent = isPlaying ? shell.dataset.radioPauseLabel : shell.dataset.radioPlayLabel;
			toggleButton.setAttribute(
				'aria-label',
				isPlaying ? shell.dataset.radioPauseAria : shell.dataset.radioPlayAria
			);
			progress.value = String(Math.round(ratio * 1000));
			progress.style.setProperty('--ec-radio-progress', String(Math.max(0, Math.min(1, ratio))));
			progress.setAttribute('aria-valuetext', formatProgressText(state.currentTime, state.duration));
			current.textContent = formatTime(state.currentTime);
			duration.textContent = formatTime(state.duration);
			if (status && previousStatus !== state.status) {
				status.textContent = messageFor(state);
			}
			previousStatus = state.status;
		}

		const controller = createMediaController(media, render);
		const AudioContext = global.AudioContext || global.webkitAudioContext;
		const visualizer = createAudioVisualizer(media, AudioContext);

		function drawVisualizer() {
			const analyser = visualizer.getAnalyser();
			if (!analyser || media.paused || reduceMotion.matches) {
				visualizerFrame = 0;
				return;
			}
			analyser.getByteFrequencyData(frequencyData);
			bars.forEach(function (bar, index) {
				const bucket = Math.floor((index / bars.length) * frequencyData.length * 0.7);
				const level = Math.max(0.12, frequencyData[bucket] / 255);
				bar.style.setProperty('--bar-level', level.toFixed(3));
			});
			visualizerFrame = global.requestAnimationFrame(drawVisualizer);
		}

		async function primeVisualizer() {
			if (reduceMotion.matches) {
				return;
			}
			try {
				const analyser = await visualizer.prime();
				if (analyser && !frequencyData) {
					frequencyData = new Uint8Array(analyser.frequencyBinCount);
				}
			} catch (error) {
				return;
			}
			if (!media.paused && !visualizerFrame) {
				visualizerFrame = global.requestAnimationFrame(drawVisualizer);
			}
		}

		async function openPlayer() {
			global.clearTimeout(closeTimer);
			player.hidden = false;
			pill.setAttribute('aria-expanded', 'true');
			pill.setAttribute('tabindex', '-1');
			pill.inert = true;
			global.requestAnimationFrame(function () {
				shell.classList.add('is-open');
				toggleButton.focus({ preventScroll: true });
			});
			if (media.paused || media.ended) {
				const visualizerReady = primeVisualizer();
				await controller.toggle();
				await visualizerReady;
			}
		}

		function closePlayer() {
			controller.pause();
			if (!shell.classList.contains('is-open')) {
				return;
			}
			shell.classList.remove('is-open');
			pill.setAttribute('aria-expanded', 'false');
			pill.inert = false;
			pill.removeAttribute('tabindex');
			pill.focus({ preventScroll: true });
			closeTimer = global.setTimeout(function () {
				player.hidden = true;
			}, reduceMotion.matches ? 0 : 460);
		}

		pill.addEventListener('click', openPlayer);
		closeButton.addEventListener('click', closePlayer);
		toggleButton.addEventListener('click', async function () {
			const visualizerReady = primeVisualizer();
			await controller.toggle();
			await visualizerReady;
		});
		progress.addEventListener('input', function () {
			controller.seekToRatio(Number(progress.value) / 1000);
		});

		global.document.addEventListener('keydown', function (event) {
			if (event.key === 'Escape' && shell.classList.contains('is-open')) {
				event.preventDefault();
				closePlayer();
			}
		});

		const footer = global.document.querySelector('.site-footer');
		if (footer && 'IntersectionObserver' in global) {
			const observer = new global.IntersectionObserver(function (entries) {
				shell.classList.toggle('is-footer-near', entries[0].isIntersecting);
			}, { threshold: 0.01 });
			observer.observe(footer);
		}

		global.addEventListener('pagehide', function (event) {
			controller.pause();
			if (visualizerFrame) {
				global.cancelAnimationFrame(visualizerFrame);
				visualizerFrame = 0;
			}
			if (shouldDestroyOnPageHide(event)) {
				visualizer.destroy();
			}
		});
	});
})(typeof window !== 'undefined' ? window : globalThis);
