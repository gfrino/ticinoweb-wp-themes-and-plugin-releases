(function () {
	'use strict';

	function initialize(root) {
		if (root.dataset.sensoryInitialized === 'true' || !window.EspressoSensoryRadar) return;

		const dataNode = root.querySelector('[data-sensory-data]');
		let catalog;
		try {
			catalog = JSON.parse(dataNode?.textContent || '{}');
		} catch (error) {
			root.dataset.sensoryError = 'invalid-data';
			return;
		}

		if (!Array.isArray(catalog.products) || !catalog.products.length || !Array.isArray(catalog.axes) || catalog.axes.length !== 7) return;

		root.dataset.sensoryInitialized = 'true';
		const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
		const compactRadar = window.matchMedia('(max-width: 520px)').matches;
		root.dataset.sensoryReducedMotion = String(reducedMotion);

		const products = new Map(catalog.products.map((product) => [String(product.id), product]));
		const categoryButtons = [...root.querySelectorAll('[data-sensory-category]')];
		const productButtons = [...root.querySelectorAll('[data-sensory-product]')];
		const panel = root.querySelector('[data-sensory-product-panel]');
		const productName = root.querySelector('[data-sensory-product-name]');
		const categoryName = root.querySelector('[data-sensory-category-name]');
		const blend = root.querySelector('[data-sensory-blend]');
		const note = root.querySelector('[data-sensory-note]');
		const link = root.querySelector('[data-sensory-link]');
		const imageStage = root.querySelector('[data-sensory-image-stage]');
		const image = root.querySelector('[data-sensory-image]');
		const valuesList = root.querySelector('[data-sensory-values]');
		const tooltip = root.querySelector('[data-sensory-tooltip]');
		const svg = root.querySelector('[data-sensory-radar]');
		let activeProduct = catalog.products[0];
		let activeCategory = String(activeProduct.category.id);
		let contentTimer = 0;

		const radar = window.EspressoSensoryRadar.create(svg, {
			labels: catalog.axes,
			values: reducedMotion ? activeProduct.values : Array(7).fill(0),
			name: activeProduct.name,
			color: activeProduct.color,
			radius: compactRadar ? 145 : 166,
			labelRadius: compactRadar ? 180 : 198,
			compactLabels: compactRadar,
			reducedMotion,
		});

		function renderValues(product) {
			valuesList.replaceChildren();
			catalog.axes.forEach((label, index) => {
				const item = document.createElement('li');
				const name = document.createElement('span');
				const value = document.createElement('strong');
				name.textContent = label;
				value.textContent = `${product.values[index]} / 5`;
				item.append(name, value);
				valuesList.append(item);
			});
		}

		function renderProduct(product, animate) {
			activeProduct = product;
			root.style.setProperty('--ec-sensory-accent', product.color || '#d6b77a');
			productName.textContent = product.name;
			categoryName.textContent = product.category.name;
			blend.textContent = product.blend || product.category.name;
			blend.hidden = !product.blend;
			note.textContent = product.note || '';
			note.hidden = !product.note;
			link.href = product.url;
			link.setAttribute('aria-label', `Scopri ${product.name}`);

			if (product.image) {
				image.src = product.image;
				image.alt = product.name;
				if (product.imageSrcset) image.srcset = product.imageSrcset;
				else image.removeAttribute('srcset');
				if (product.imageSizes) image.sizes = product.imageSizes;
				image.hidden = false;
				imageStage.classList.remove('has-no-image');
			} else {
				image.removeAttribute('src');
				image.removeAttribute('srcset');
				image.hidden = true;
				imageStage.classList.add('has-no-image');
			}

			renderValues(product);
			productButtons.forEach((button) => {
				const selected = button.dataset.sensoryProduct === String(product.id);
				button.setAttribute('aria-selected', String(selected));
				button.tabIndex = selected ? 0 : -1;
			});

			if (animate && !reducedMotion) {
				panel.classList.add('is-changing');
				window.clearTimeout(contentTimer);
				contentTimer = window.setTimeout(() => panel.classList.remove('is-changing'), 360);
			}

			radar.update(product, { immediate: reducedMotion || !animate, duration: 600 });
		}

		function updateCategory(categoryId) {
			activeCategory = String(categoryId);
			categoryButtons.forEach((button) => {
				const selected = button.dataset.sensoryCategory === activeCategory;
				button.setAttribute('aria-selected', String(selected));
				button.tabIndex = selected ? 0 : -1;
			});
			productButtons.forEach((button) => {
				button.hidden = button.dataset.sensoryProductCategory !== activeCategory;
			});
		}

		function selectProduct(productId, animate = true) {
			const product = products.get(String(productId));
			if (!product) return;
			if (String(product.category.id) !== activeCategory) updateCategory(product.category.id);
			renderProduct(product, animate);
		}

		function selectCategory(categoryId) {
			updateCategory(categoryId);
			const first = productButtons.find((button) => !button.hidden);
			if (first) selectProduct(first.dataset.sensoryProduct, true);
		}

		categoryButtons.forEach((button) => button.addEventListener('click', () => selectCategory(button.dataset.sensoryCategory)));
		productButtons.forEach((button) => button.addEventListener('click', () => selectProduct(button.dataset.sensoryProduct, true)));

		function bindRailKeyboard(buttons) {
			buttons.forEach((button) => {
				button.addEventListener('keydown', (event) => {
					if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
					const available = buttons.filter((candidate) => !candidate.hidden);
					const current = available.indexOf(button);
					let next = current;
					if (event.key === 'Home') next = 0;
					else if (event.key === 'End') next = available.length - 1;
					else if (event.key === 'ArrowRight') next = (current + 1) % available.length;
					else next = (current - 1 + available.length) % available.length;
					event.preventDefault();
					available[next].click();
					available[next].focus();
				});
			});
		}

		bindRailKeyboard(categoryButtons);
		bindRailKeyboard(productButtons);

		function showTooltip(point) {
			const index = Number(point.dataset.radarPoint);
			if (!Number.isInteger(index)) return;
			tooltip.innerHTML = `<strong>${catalog.axes[index]}</strong><span>${activeProduct.values[index]} / 5</span>`;
			tooltip.hidden = false;
			tooltip.dataset.axis = String(index);
		}

		function hideTooltip() {
			tooltip.hidden = true;
			delete tooltip.dataset.axis;
		}

		svg.querySelectorAll('[data-radar-point]').forEach((point) => {
			point.addEventListener('pointerenter', () => showTooltip(point));
			point.addEventListener('pointerleave', hideTooltip);
			point.addEventListener('focus', () => showTooltip(point));
			point.addEventListener('blur', hideTooltip);
			point.addEventListener('click', () => showTooltip(point));
			point.addEventListener('keydown', (event) => {
				if (event.key !== 'Enter' && event.key !== ' ') return;
				event.preventDefault();
				showTooltip(point);
			});
		});

		root.addEventListener('keydown', (event) => {
			if (event.key === 'Escape') hideTooltip();
		});

		updateCategory(activeCategory);
		renderProduct(activeProduct, false);

		const reveal = () => {
			root.classList.add('is-sensory-visible');
			radar.update(activeProduct, { immediate: reducedMotion, duration: 850 });
		};
		if ('IntersectionObserver' in window && !reducedMotion) {
			const observer = new IntersectionObserver((entries) => {
				if (!entries.some((entry) => entry.isIntersecting)) return;
				observer.disconnect();
				reveal();
			}, { threshold: 0.18 });
			observer.observe(root);
		} else {
			reveal();
		}
	}

	const explorers = document.querySelectorAll('[data-sensory-explorer]');
	if (explorers.length) explorers.forEach(initialize);
	else document.addEventListener('DOMContentLoaded', () => document.querySelectorAll('[data-sensory-explorer]').forEach(initialize), { once: true });
})();
