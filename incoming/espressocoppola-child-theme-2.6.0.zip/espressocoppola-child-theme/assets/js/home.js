(function () {
	'use strict';

	function initProductStage(main, desktop) {
		const stage = main.querySelector('[data-product-stage]');
		if (!stage) {
			return;
		}

		const items = Array.from(stage.querySelectorAll('[data-product-item]'));
		const steps = Array.from(stage.querySelectorAll('[data-product-step]'));
		const targets = Array.from(stage.querySelectorAll('[data-product-target]'));
		const current = stage.querySelector('[data-product-current]');
		const sticky = stage.querySelector('.ec-product-stage__sticky');
		let stepObserver = null;
		let activeIndex = 0;

		if (!items.length || items.length !== targets.length) {
			return;
		}

		stage.classList.add('is-enhanced');

		function setActive(nextIndex) {
			const index = Math.max(0, Math.min(items.length - 1, Number(nextIndex) || 0));
			const nextItem = items[index];
			activeIndex = index;

			stage.dataset.activeIndex = String(index);
			stage.dataset.tone = nextItem.dataset.tone || 'crema';

			items.forEach(function (item, itemIndex) {
				const isActive = itemIndex === index;
				item.classList.toggle('is-active', isActive);
				item.setAttribute('aria-hidden', isActive ? 'false' : 'true');
				if (isActive) {
					item.removeAttribute('inert');
				} else {
					item.setAttribute('inert', '');
				}
			});

			targets.forEach(function (target, targetIndex) {
				const isActive = targetIndex === index;
				target.classList.toggle('is-active', isActive);
				if (isActive) {
					target.setAttribute('aria-current', 'true');
				} else {
					target.removeAttribute('aria-current');
				}
			});

			if (current) {
				current.textContent = String(index + 1).padStart(2, '0');
			}
		}

		function scrollToProduct(index) {
			setActive(index);
			if (!desktop.matches || !sticky) {
				return;
			}

			const stageTop = window.scrollY + stage.getBoundingClientRect().top;
			const maximumOffset = Math.max(0, stage.offsetHeight - sticky.offsetHeight);
			const progress = items.length > 1 ? index / (items.length - 1) : 0;

			window.scrollTo({
				top: stageTop + (maximumOffset * progress),
				behavior: 'auto'
			});
		}

		targets.forEach(function (target, index) {
			target.addEventListener('click', function () {
				scrollToProduct(index);
			});

			target.addEventListener('keydown', function (event) {
				let nextIndex = null;
				if (event.key === 'ArrowRight' || event.key === 'ArrowDown') {
					nextIndex = (index + 1) % targets.length;
				} else if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') {
					nextIndex = (index - 1 + targets.length) % targets.length;
				} else if (event.key === 'Home') {
					nextIndex = 0;
				} else if (event.key === 'End') {
					nextIndex = targets.length - 1;
				}

				if (nextIndex === null) {
					return;
				}

				event.preventDefault();
				targets[nextIndex].focus({ preventScroll: true });
				scrollToProduct(nextIndex);
				if (!desktop.matches) {
					const navigation = targets[nextIndex].closest('.ec-product-stage__navigation');
					if (navigation) {
						navigation.scrollTo({
							left: targets[nextIndex].offsetLeft - ((navigation.clientWidth - targets[nextIndex].offsetWidth) / 2),
							behavior: 'auto'
						});
					}
				}
			});
		});

		function observeSteps() {
			if (stepObserver) {
				stepObserver.disconnect();
				stepObserver = null;
			}

			if (!desktop.matches || !('IntersectionObserver' in window) || steps.length !== items.length) {
				return;
			}

			stepObserver = new IntersectionObserver(function (entries) {
				const viewportCenter = window.innerHeight / 2;
				const visible = entries.filter(function (entry) {
					return entry.isIntersecting;
				}).sort(function (left, right) {
					const leftCenter = left.boundingClientRect.top + (left.boundingClientRect.height / 2);
					const rightCenter = right.boundingClientRect.top + (right.boundingClientRect.height / 2);
					return Math.abs(leftCenter - viewportCenter) - Math.abs(rightCenter - viewportCenter);
				});

				if (visible.length) {
					setActive(steps.indexOf(visible[0].target));
				}
			}, {
				rootMargin: '-42% 0px -42% 0px',
				threshold: 0
			});

			steps.forEach(function (step) {
				stepObserver.observe(step);
			});
		}

		setActive(activeIndex);
		observeSteps();

		if (typeof desktop.addEventListener === 'function') {
			desktop.addEventListener('change', observeSteps);
		}
	}

	function initHomeMotion() {
		const main = document.querySelector('.ec-home-main');
		if (!main) {
			return;
		}

		const desktop = window.matchMedia('(min-width: 781px)');
		const observed = Array.from(main.querySelectorAll('[data-home-observe]'));

		document.documentElement.classList.add('ec-motion-ready');
		initProductStage(main, desktop);

		function revealEntries(entries) {
			entries.forEach(function (entry) {
				if (entry.isIntersecting) {
					entry.target.classList.add('is-in-view');
				}
				if (entry.target.matches('[data-product-stage]')) {
					entry.target.classList.toggle('is-stage-visible', entry.isIntersecting);
				}
			});
		}

		if ('IntersectionObserver' in window) {
			const revealObserver = new IntersectionObserver(revealEntries, {
				rootMargin: '0px 0px -10% 0px',
				threshold: 0.12
			});
			observed.forEach(function (section) {
				revealObserver.observe(section);
			});
		} else {
			observed.forEach(function (section) {
				section.classList.add('is-in-view');
			});
		}

	}

	document.addEventListener('DOMContentLoaded', initHomeMotion);
})();
