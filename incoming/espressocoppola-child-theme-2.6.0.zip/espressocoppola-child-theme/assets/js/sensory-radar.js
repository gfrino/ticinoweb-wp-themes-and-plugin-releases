(function (root, factory) {
	'use strict';

	root.EspressoSensoryRadar = factory(root);
})(typeof window !== 'undefined' ? window : globalThis, function (root) {
	'use strict';

	const SVG_NS = 'http://www.w3.org/2000/svg';
	const AXIS_COUNT = 7;
	const MAX_VALUE = 5;
	const DEFAULTS = Object.freeze({
		center: 260,
		radius: 172,
		labelRadius: 220,
		duration: 600,
		color: '#d6b77a',
	});

	function number(value, fallback) {
		const parsed = Number(value);
		return Number.isFinite(parsed) ? parsed : fallback;
	}

	function drawingValue(value) {
		const parsed = Number(value);
		return Number.isInteger(parsed) && parsed >= 1 && parsed <= MAX_VALUE ? parsed : 0;
	}

	function getPoint(index, value, options = {}) {
		const center = number(options.center, DEFAULTS.center);
		const radius = number(options.radius, DEFAULTS.radius);
		const angle = -Math.PI / 2 + index * (Math.PI * 2 / AXIS_COUNT);
		const distance = radius * drawingValue(value) / MAX_VALUE;

		return {
			x: center + Math.cos(angle) * distance,
			y: center + Math.sin(angle) * distance,
		};
	}

	function getPoints(values, options = {}) {
		return Array.from({ length: AXIS_COUNT }, (_, index) => getPoint(index, values[index], options));
	}

	function pointString(points) {
		return points.map((point) => `${point.x.toFixed(3)},${point.y.toFixed(3)}`).join(' ');
	}

	function node(name, attributes = {}) {
		const element = root.document.createElementNS(SVG_NS, name);
		Object.entries(attributes).forEach(([key, value]) => element.setAttribute(key, String(value)));
		return element;
	}

	function setPointPosition(element, point) {
		element.setAttribute('cx', point.x.toFixed(3));
		element.setAttribute('cy', point.y.toFixed(3));
	}

	function accessibleDescription(name, labels, values) {
		const details = labels.map((label, index) => `${label} ${drawingValue(values[index])} su 5`).join(', ');
		return `Profilo sensoriale ${name}: ${details}.`;
	}

	function create(svg, options = {}) {
		if (!svg || !root.document) throw new TypeError('A valid SVG element is required.');

		const settings = { ...DEFAULTS, ...options };
		const labels = Array.from({ length: AXIS_COUNT }, (_, index) => String((settings.labels || [])[index] || `Asse ${index + 1}`));
		let currentValues = Array.from({ length: AXIS_COUNT }, (_, index) => drawingValue((settings.values || [])[index]));
		let frame = 0;
		let destroyed = false;

		svg.replaceChildren();
		svg.classList.add('ec-sensory-radar');
		svg.setAttribute('viewBox', '0 0 520 520');
		svg.style.setProperty('--ec-radar-color', settings.color || DEFAULTS.color);

		const title = node('title');
		const desc = node('desc');
		const grid = node('g', { class: 'ec-sensory-radar__grid', 'aria-hidden': 'true' });
		const axes = node('g', { class: 'ec-sensory-radar__axes', 'aria-hidden': 'true' });
		const labelsGroup = node('g', { class: 'ec-sensory-radar__labels', 'aria-hidden': 'true' });
		const profileGroup = node('g', { class: 'ec-sensory-radar__profile' });
		const polygon = node('polygon', { class: 'ec-sensory-radar__shape', 'data-radar-profile': '' });
		const pointsGroup = node('g', { class: 'ec-sensory-radar__points' });
		const pointNodes = [];

		for (let level = 1; level <= MAX_VALUE; level += 1) {
			const ringValues = Array(AXIS_COUNT).fill(level);
			grid.append(node('polygon', {
				points: pointString(getPoints(ringValues, settings)),
				'data-radar-ring': level,
			}));
		}

		for (let index = 0; index < AXIS_COUNT; index += 1) {
			const edge = getPoint(index, MAX_VALUE, settings);
			axes.append(node('line', {
				x1: settings.center,
				y1: settings.center,
				x2: edge.x.toFixed(3),
				y2: edge.y.toFixed(3),
				'data-radar-axis': index,
			}));

			const labelPoint = getPoint(index, MAX_VALUE, { center: settings.center, radius: settings.labelRadius });
			const isCenteredLabel = Math.abs(labelPoint.x - settings.center) < 8;
			const labelAnchor = isCenteredLabel
				? 'middle'
				: (settings.compactLabels
					? (labelPoint.x > settings.center ? 'end' : 'start')
					: (labelPoint.x > settings.center ? 'start' : 'end'));
			const label = node('text', {
				x: labelPoint.x.toFixed(3),
				y: labelPoint.y.toFixed(3),
				'data-radar-label': index,
				'text-anchor': labelAnchor,
			});
			if (settings.compactLabels && labels[index].length > 14 && labels[index].includes(' ')) {
				const words = labels[index].split(' ');
				const firstLine = node('tspan', { x: labelPoint.x.toFixed(3), dy: '-0.45em' });
				const secondLine = node('tspan', { x: labelPoint.x.toFixed(3), dy: '1.15em' });
				firstLine.textContent = words.shift();
				secondLine.textContent = words.join(' ');
				label.append(firstLine, secondLine);
			} else {
				label.textContent = labels[index];
			}
			labelsGroup.append(label);

			const point = node('circle', {
				r: 6,
				tabindex: 0,
				role: 'button',
				'data-radar-point': index,
				'data-radar-axis-key': (settings.axisKeys || [])[index] || String(index),
			});
			pointNodes.push(point);
			pointsGroup.append(point);
		}

		profileGroup.append(polygon, pointsGroup);
		svg.append(title, desc, grid, axes, labelsGroup, profileGroup);

		function render(values, profile = {}) {
			const exactValues = Array.from({ length: AXIS_COUNT }, (_, index) => drawingValue(values[index]));
			const plotted = getPoints(exactValues, settings);
			const name = String(profile.name || settings.name || 'Espresso Coppola');

			polygon.setAttribute('points', pointString(plotted));
			pointNodes.forEach((point, index) => {
				setPointPosition(point, plotted[index]);
				point.setAttribute('aria-label', `${labels[index]}: ${exactValues[index]} su 5`);
				point.dataset.radarValue = String(exactValues[index]);
			});
			title.textContent = `Profilo sensoriale ${name}`;
			desc.textContent = accessibleDescription(name, labels, exactValues);
			if (profile.color) svg.style.setProperty('--ec-radar-color', profile.color);
		}

		function update(profile = {}, updateOptions = {}) {
			if (destroyed) return;
			if (frame) root.cancelAnimationFrame(frame);

			const target = Array.from({ length: AXIS_COUNT }, (_, index) => drawingValue((profile.values || currentValues)[index]));
			const start = currentValues.slice();
			const immediate = Boolean(updateOptions.immediate || settings.reducedMotion || root.matchMedia?.('(prefers-reduced-motion: reduce)').matches);
			const duration = Math.max(0, number(updateOptions.duration, settings.duration));
			const startedAt = root.performance ? root.performance.now() : Date.now();

			if (profile.color) svg.style.setProperty('--ec-radar-color', profile.color);
			settings.name = profile.name || settings.name;
			const accessibleName = String(settings.name || 'Espresso Coppola');
			title.textContent = `Profilo sensoriale ${accessibleName}`;
			desc.textContent = accessibleDescription(accessibleName, labels, target);
			pointNodes.forEach((point, index) => {
				point.setAttribute('aria-label', `${labels[index]}: ${target[index]} su 5`);
				point.dataset.radarValue = String(target[index]);
			});

			if (immediate || duration === 0) {
				currentValues = target;
				render(currentValues, profile);
				return;
			}

			function tick(timestamp) {
				const progress = Math.min(1, (timestamp - startedAt) / duration);
				const eased = 1 - Math.pow(1 - progress, 3);
				const values = start.map((value, index) => value + (target[index] - value) * eased);

				const plotted = values.map((value, index) => {
					const angle = -Math.PI / 2 + index * (Math.PI * 2 / AXIS_COUNT);
					const distance = settings.radius * value / MAX_VALUE;
					return {
						x: settings.center + Math.cos(angle) * distance,
						y: settings.center + Math.sin(angle) * distance,
					};
				});

				polygon.setAttribute('points', pointString(plotted));
				pointNodes.forEach((point, index) => setPointPosition(point, plotted[index]));

				if (progress < 1) {
					frame = root.requestAnimationFrame(tick);
				} else {
					frame = 0;
					currentValues = target;
					render(currentValues, profile);
				}
			}

			frame = root.requestAnimationFrame(tick);
		}

		render(currentValues, settings);

		return {
			update,
			destroy() {
				destroyed = true;
				if (frame) root.cancelAnimationFrame(frame);
			},
		};
	}

	return Object.freeze({ getPoint, getPoints, create });
});
