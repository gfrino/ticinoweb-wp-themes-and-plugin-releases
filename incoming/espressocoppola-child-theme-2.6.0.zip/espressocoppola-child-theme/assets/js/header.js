(function() {
	'use strict';

	let submenuIndex = 0;

	function getBagQuantity(bag) {
		const count = bag ? bag.querySelector('[data-header-bag-count]') : null;
		const quantity = count ? Number.parseInt(count.textContent, 10) : NaN;

		return Number.isFinite(quantity) ? quantity : null;
	}

	function initializeHeader(header) {
		if (header.dataset.headerInitialized === 'true') {
			return;
		}

		const trigger = header.querySelector('[data-header-menu-trigger]');
		const panelId = trigger ? trigger.getAttribute('aria-controls') : '';
		const panel = panelId ? document.getElementById(panelId) : document.querySelector('[data-header-panel]');
		const backdrop = document.querySelector('[data-header-backdrop]');
		const closeButton = panel ? panel.querySelector('[data-header-close]') : null;

		if (!trigger || !panel || !backdrop || !closeButton) {
			return;
		}

		header.dataset.headerInitialized = 'true';

		const focusableSelector = 'a[href],button:not([disabled]),[tabindex]:not([tabindex="-1"])';
		const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
		const mobileMenu = window.matchMedia('(max-width: 780px)');
		const backgroundWord = panel.querySelector('[data-header-background-word]');
		let lastFocused = null;
		let closingTimer = 0;
		let scrollFrame = 0;
		const isolatedRegions = new Map();

		function setExpanded(button, expanded) {
			button.setAttribute('aria-expanded', expanded ? 'true' : 'false');
		}

		function getFocusable() {
			return Array.from(panel.querySelectorAll(focusableSelector)).filter(function(element) {
				return !element.hidden && element.getClientRects().length > 0;
			});
		}

		function setSubmenuState(item, button, submenu, expanded) {
			setExpanded(button, expanded);
			item.classList.toggle('is-active', expanded && !mobileMenu.matches);
			item.classList.toggle('is-submenu-open', expanded && mobileMenu.matches);
			submenu.hidden = mobileMenu.matches && !expanded;
		}

		function synchronizeSubmenu(control) {
			const desktopExpanded = control.manualExpanded ||
				control.pointerActive ||
				control.focusActive ||
				control.item.classList.contains('current-menu-ancestor');
			const expanded = mobileMenu.matches ? control.manualExpanded : desktopExpanded;

			setSubmenuState(control.item, control.button, control.submenu, expanded);
		}

		const submenuControls = Array.from(panel.querySelectorAll('.ec-morph-menu > .menu-item-has-children')).map(function(item) {
			const children = Array.from(item.children);
			const anchor = children.find(function(child) {
				return child.matches('a');
			});
			const submenu = children.find(function(child) {
				return child.matches('.sub-menu');
			});

			if (!anchor || !submenu) {
				return null;
			}

			let button = children.find(function(child) {
				return child.matches('[data-header-submenu-toggle]');
			});

			if (!submenu.id) {
				do {
					submenuIndex += 1;
					submenu.id = 'ec-header-submenu-' + submenuIndex;
				} while (document.getElementById(submenu.id) !== submenu);
			}

			if (!button) {
				button = document.createElement('button');
				button.type = 'button';
				button.className = 'ec-header__submenu-toggle';
				button.dataset.headerSubmenuToggle = '';
				button.textContent = '+';
				item.insertBefore(button, submenu);
			}

			button.setAttribute('aria-controls', submenu.id);
			button.setAttribute('aria-label', anchor.textContent.trim());
			setExpanded(button, false);

			const control = {
				item: item,
				button: button,
				submenu: submenu,
				manualExpanded: false,
				pointerActive: false,
				focusActive: false,
			};

			button.addEventListener('click', function() {
				control.manualExpanded = !control.manualExpanded;
				synchronizeSubmenu(control);
			});
			item.addEventListener('pointerenter', function() {
				control.pointerActive = true;
				synchronizeSubmenu(control);
			});
			item.addEventListener('pointerleave', function() {
				control.pointerActive = false;
				synchronizeSubmenu(control);
			});
			item.addEventListener('focusin', function() {
				control.focusActive = true;
				synchronizeSubmenu(control);
			});
			item.addEventListener('focusout', function(event) {
				if (event.relatedTarget && item.contains(event.relatedTarget)) {
					return;
				}

				control.focusActive = false;
				synchronizeSubmenu(control);
			});

			return control;
		}).filter(Boolean);

		const menuAnchors = Array.from(panel.querySelectorAll('.ec-morph-menu > .menu-item > a'));
		const currentActiveAnchor = panel.querySelector('.ec-morph-menu > .current-menu-item > a') ||
			panel.querySelector('.ec-morph-menu > .current-menu-ancestor > a') ||
			menuAnchors[0];

		let activeWordTimer = 0;

		function setBackgroundWord(text) {
			if (!backgroundWord) {
				return;
			}
			const clean = (text || '').trim();
			if (!clean) {
				backgroundWord.classList.remove('is-visible');
				return;
			}
			if (backgroundWord.textContent !== clean) {
				backgroundWord.classList.remove('is-visible');
				window.clearTimeout(activeWordTimer);
				activeWordTimer = window.setTimeout(function() {
					backgroundWord.textContent = clean;
					backgroundWord.classList.add('is-visible');
				}, reduceMotion.matches ? 0 : 40);
			} else {
				backgroundWord.classList.add('is-visible');
			}
		}

		function restoreDefaultBackgroundWord() {
			if (currentActiveAnchor) {
				setBackgroundWord(currentActiveAnchor.textContent);
			} else {
				setBackgroundWord('');
			}
		}

		menuAnchors.forEach(function(anchor) {
			anchor.addEventListener('pointerenter', function() {
				setBackgroundWord(anchor.textContent);
			});
			anchor.addEventListener('focusin', function() {
				setBackgroundWord(anchor.textContent);
			});
		});

		function synchronizeSubmenus() {
			submenuControls.forEach(function(control) {
				synchronizeSubmenu(control);
			});
		}

		function setPageIsolation(isolated) {
			if (isolated) {
				Array.from(document.body.children).forEach(function(element) {
					if (element === panel || element === backdrop || element.matches('script,style,link,noscript,template')) {
						return;
					}

					if (!isolatedRegions.has(element)) {
						isolatedRegions.set(element, element.hasAttribute('inert'));
					}

					element.setAttribute('inert', '');
				});
				return;
			}

			isolatedRegions.forEach(function(wasInert, element) {
				if (!wasInert) {
					element.removeAttribute('inert');
				}
			});
			isolatedRegions.clear();
		}

		function restoreFocus() {
			const focusTarget = lastFocused && typeof lastFocused.focus === 'function' ? lastFocused : trigger;
			focusTarget.focus();

			if (panel.contains(document.activeElement)) {
				trigger.focus();
			}
		}

		function openMenu() {
			window.clearTimeout(closingTimer);
			closingTimer = 0;
			lastFocused = trigger;
			panel.hidden = false;
			backdrop.hidden = false;
			panel.classList.remove('is-closing');
			setExpanded(trigger, true);
			panel.setAttribute('aria-hidden', 'false');
			panel.setAttribute('aria-modal', 'true');
			document.documentElement.style.setProperty(
				'--ec-scrollbar-width',
				Math.max(0, window.innerWidth - document.documentElement.clientWidth) + 'px'
			);
			document.body.classList.add('ec-header-open');
			panel.getBoundingClientRect();
			panel.classList.add('is-opening');
			closeButton.getBoundingClientRect();
			setPageIsolation(true);
			restoreDefaultBackgroundWord();
			closeButton.focus({ preventScroll: true });

			window.requestAnimationFrame(function() {
				if (panel.getAttribute('aria-hidden') === 'true') {
					return;
				}

				panel.classList.add('is-open');
				panel.classList.remove('is-opening');
				if (document.activeElement !== closeButton) {
					closeButton.focus({ preventScroll: true });
				}
			});
		}

		function finishClosing() {
			panel.hidden = true;
			backdrop.hidden = true;
			panel.classList.remove('is-closing');
			closingTimer = 0;
		}

		function closeMenu() {
			if (panel.hidden) {
				return;
			}

			window.clearTimeout(closingTimer);
			panel.classList.remove('is-opening', 'is-open');
			panel.classList.add('is-closing');
			setExpanded(trigger, false);
			panel.removeAttribute('aria-modal');
			setPageIsolation(false);
			restoreFocus();
			panel.setAttribute('aria-hidden', 'true');
			document.body.classList.remove('ec-header-open');
			document.documentElement.style.removeProperty('--ec-scrollbar-width');
			closingTimer = window.setTimeout(finishClosing, reduceMotion.matches ? 0 : 360);
		}

		function handleKeydown(event) {
			if (panel.hidden || panel.getAttribute('aria-hidden') === 'true') {
				return;
			}

			if (event.key === 'Escape') {
				event.preventDefault();
				closeMenu();
				return;
			}

			if (event.key !== 'Tab') {
				return;
			}

			const focusable = getFocusable();
			if (!focusable.length) {
				event.preventDefault();
				return;
			}

			const first = focusable[0];
			const last = focusable[focusable.length - 1];
			if (event.shiftKey && (document.activeElement === first || !panel.contains(document.activeElement))) {
				event.preventDefault();
				last.focus();
			} else if (!event.shiftKey && (document.activeElement === last || !panel.contains(document.activeElement))) {
				event.preventDefault();
				first.focus();
			}
		}

		function updateCompactState() {
			header.classList.toggle('is-compact', window.scrollY > 100);
			scrollFrame = 0;
		}

		function scheduleCompactUpdate() {
			if (scrollFrame) {
				return;
			}

			scrollFrame = window.requestAnimationFrame(updateCompactState);
		}

		panel.setAttribute('role', 'dialog');
		panel.removeAttribute('aria-modal');
		panel.hidden = true;
		backdrop.hidden = true;
		panel.setAttribute('aria-hidden', 'true');
		panel.classList.remove('is-opening', 'is-open', 'is-closing');
		setExpanded(trigger, false);
		document.body.classList.remove('ec-header-open');
		document.documentElement.style.removeProperty('--ec-scrollbar-width');
		synchronizeSubmenus();
		scheduleCompactUpdate();

		trigger.addEventListener('click', function() {
			if (trigger.getAttribute('aria-expanded') === 'true') {
				closeMenu();
			} else {
				openMenu();
			}
		});
		closeButton.addEventListener('click', closeMenu);
		backdrop.addEventListener('click', closeMenu);
		document.addEventListener('keydown', handleKeydown);
		panel.addEventListener('pointerleave', restoreDefaultBackgroundWord);
		window.addEventListener('scroll', scheduleCompactUpdate, { passive: true });

		if (typeof mobileMenu.addEventListener === 'function') {
			mobileMenu.addEventListener('change', synchronizeSubmenus);
		} else {
			mobileMenu.addListener(synchronizeSubmenus);
		}
	}

	const BAG_ICON_SVG = '<svg class="ec-header__bag-icon" width="16" height="17" viewBox="0 0 20 22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3.5 6.5H16.5L18 20.5H2L3.5 6.5Z"/><path d="M6.5 9V4.5C6.5 2.567 8.067 1 10 1C11.933 1 13.5 2.567 13.5 4.5V9"/></svg>';

	function ensureBagIcons() {
		const bags = document.querySelectorAll('.ec-header__bag');
		bags.forEach(function(bag) {
			if (!bag.querySelector('.ec-header__bag-icon')) {
				Array.from(bag.childNodes).forEach(function(node) {
					if (node.nodeType === Node.TEXT_NODE && /bag/i.test(node.textContent)) {
						node.textContent = '';
					} else if (node.nodeType === Node.ELEMENT_NODE && !node.matches('.ec-header__bag-count') && !node.querySelector('[data-header-bag-count]')) {
						if (/bag/i.test(node.textContent)) {
							node.remove();
						}
					}
				});
				bag.insertAdjacentHTML('afterbegin', BAG_ICON_SVG);
			}

			Array.from(bag.childNodes).forEach(function(node) {
				if (node.nodeType === Node.TEXT_NODE) {
					node.textContent = node.textContent.replace(/[()]/g, '').trim();
				}
			});

			const quantity = getBagQuantity(bag);
			const badge = bag.querySelector('.ec-header__bag-count');
			if (badge && quantity !== null) {
				badge.classList.toggle('is-zero', quantity === 0);
			}
		});
	}

	function initialize() {
		try {
			if (window.sessionStorage) {
				for (let i = sessionStorage.length - 1; i >= 0; i--) {
					const key = sessionStorage.key(i);
					if (key && key.indexOf('wc_fragments_') === 0) {
						sessionStorage.removeItem(key);
					}
				}
			}
		} catch (e) {}

		ensureBagIcons();
		document.querySelectorAll('[data-floating-header]').forEach(initializeHeader);

		function setupNoticesClose() {
			const notices = document.querySelectorAll('.woocommerce-message, .woocommerce-info, .woocommerce-error');
			notices.forEach(function(notice) {
				if (notice.querySelector('.ec-notice-close')) {
					return;
				}
				const closeBtn = document.createElement('button');
				closeBtn.type = 'button';
				closeBtn.className = 'ec-notice-close';
				closeBtn.setAttribute('aria-label', 'Chiudi');
				closeBtn.innerHTML = '&times;';
				closeBtn.addEventListener('click', function(e) {
					e.preventDefault();
					e.stopPropagation();
					notice.style.transition = 'opacity 0.24s ease, transform 0.24s ease';
					notice.style.opacity = '0';
					notice.style.transform = 'translateY(-12px) scale(0.96)';
					setTimeout(function() {
						notice.remove();
					}, 250);
				});
				notice.appendChild(closeBtn);
			});
		}

		setupNoticesClose();

		if (window.jQuery) {
			const initialBag = document.querySelector('.ec-header__bag');
			let previousBagQuantity = getBagQuantity(initialBag);

			window.jQuery(document.body).on('wc_fragments_refreshed wc_fragments_loaded added_to_cart', function() {
				ensureBagIcons();
				setupNoticesClose();
				const bags = Array.from(document.querySelectorAll('.ec-header__bag'));
				const quantity = getBagQuantity(bags[0]);

				if (!bags.length || quantity === null || quantity === previousBagQuantity) {
					return;
				}

				previousBagQuantity = quantity;
				bags.forEach(function(bag) {
					const count = bag.querySelector('[data-header-bag-count]');
					if (count) count.textContent = String(quantity);
					const badge = bag.querySelector('.ec-header__bag-count');
					if (badge) {
						badge.classList.toggle('is-zero', quantity === 0);
					}
					bag.classList.remove('is-updated');
				});
				requestAnimationFrame(function() {
					bags.forEach(function(bag) { bag.classList.add('is-updated'); });
				});
			});
		}
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', initialize, { once: true });
	} else {
		initialize();
	}
}());
