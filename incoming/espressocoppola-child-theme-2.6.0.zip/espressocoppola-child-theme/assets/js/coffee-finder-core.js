(function (root, factory) {
	'use strict';

	const api = factory();

	if (typeof module === 'object' && module.exports) {
		module.exports = api;
	}

	root.EspressoFinderCore = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
	'use strict';

	function isAvailable(product) {
		return product && product.published !== false && product.inStock !== false;
	}

	function filterProducts(products, selection) {
		const current = selection || {};
		const preparation = current.preparation || current.category;

		return (products || []).filter(function (product) {
			if (!isAvailable(product)) {
				return false;
			}

			if (preparation && !(product.preparations || product.categories || []).includes(preparation)) {
				return false;
			}

			if (current.system && !(product.systems || []).some(function (system) {
				return system.slug === current.system;
			})) {
				return false;
			}

			if (current.blend && !(product.blends || []).some(function (blend) {
				return blend.slug === current.blend;
			})) {
				return false;
			}

			if (current.format && !(product.formats || []).some(function (format) {
				return format.key === current.format;
			})) {
				return false;
			}

			return true;
		});
	}

	function uniqueOptions(products, key, identity) {
		const options = new Map();

		products.forEach(function (product) {
			(product[key] || []).forEach(function (option) {
				options.set(option[identity], option);
			});
		});

		return Array.from(options.values());
	}

	function getBlendOptions(catalog, selection) {
		const products = filterProducts(catalog.products, {
			preparation: selection && (selection.preparation || selection.category),
			system: selection && selection.system,
		});

		return uniqueOptions(products, 'blends', 'slug');
	}

	function getFormatOptions(catalog, selection) {
		const products = filterProducts(catalog.products, {
			preparation: selection && (selection.preparation || selection.category),
			system: selection && selection.system,
			blend: selection && selection.blend,
		});

		return uniqueOptions(products, 'formats', 'key');
	}

	function getResults(catalog, selection) {
		return filterProducts(catalog.products, selection).slice(0, 3);
	}

	function getSystemOptions(catalog, selection) {
		const products = filterProducts(catalog.products, {
			preparation: selection && selection.preparation,
		});

		return uniqueOptions(products, 'systems', 'slug');
	}

	function getStepSequence(catalog, selection) {
		const steps = ['preparation'];
		if (getSystemOptions(catalog, selection).length > 1) {
			steps.push('system');
		}
		steps.push('blend', 'format', 'results');
		return steps;
	}

	return {
		filterProducts: filterProducts,
		getBlendOptions: getBlendOptions,
		getFormatOptions: getFormatOptions,
		getSystemOptions: getSystemOptions,
		getStepSequence: getStepSequence,
		getResults: getResults,
	};
});
