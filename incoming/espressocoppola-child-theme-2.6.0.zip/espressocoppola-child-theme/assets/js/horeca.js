/**
 * Frontend JavaScript for the Ho.Re.Ca. template.
 *
 * Handles 3-step form progression, client validation, blend preselection, and AJAX submission.
 *
 * @package EspressoCoppolaChildTheme
 */

(function() {
	'use strict';

	document.addEventListener('DOMContentLoaded', function() {

		/**
		 * =====================================================================
		 * 01 — FISARMONICA / ACCORDION MISCELE HO.RE.CA.
		 * =====================================================================
		 */
		const accordionContainer = document.querySelector('[data-accordion-blends]');
		if (accordionContainer) {
			const cards = Array.from(accordionContainer.querySelectorAll('[data-accordion-item]'));
			let hoverTimeout = null;

			function activateAccordionCard(targetCard) {
				if (!targetCard || targetCard.classList.contains('is-active')) {
					return;
				}
				cards.forEach(function(card) {
					const isActive = (card === targetCard);
					card.classList.toggle('is-active', isActive);
					card.setAttribute('aria-expanded', isActive ? 'true' : 'false');
				});
			}

			cards.forEach(function(card) {
				// Smooth hover expansion on desktop (>= 900px)
				card.addEventListener('mouseenter', function() {
					if (window.innerWidth >= 900) {
						if (hoverTimeout) {
							clearTimeout(hoverTimeout);
						}
						hoverTimeout = setTimeout(function() {
							activateAccordionCard(card);
						}, 35);
					}
				});

				// Click / Tap expansion (Desktop and Mobile)
				card.addEventListener('click', function(e) {
					if (hoverTimeout) {
						clearTimeout(hoverTimeout);
					}

					// Do not prevent standard link behavior for the CTA button inside
					if (e.target.closest('.ec-horeca-choose-sample-btn')) {
						return;
					}

					if (window.innerWidth < 900 && card.classList.contains('is-active')) {
						card.classList.remove('is-active');
						card.setAttribute('aria-expanded', 'false');
					} else {
						activateAccordionCard(card);
					}
				});

				// Accessible keyboard navigation
				card.addEventListener('keydown', function(e) {
					if (e.key === 'Enter' || e.key === ' ') {
						if (!e.target.closest('.ec-horeca-choose-sample-btn')) {
							e.preventDefault();
							activateAccordionCard(card);
						}
					}
				});
			});
		}

		/**
		 * =====================================================================
		 * 02 — FORMULARIO GUIDATO CAMPIONATURA (3-STEP)
		 * =====================================================================
		 */
		const form = document.getElementById('ec-horeca-sample-form');
		if (!form) {
			return;
		}

		const steps = Array.from(form.querySelectorAll('[data-form-step]'));
		const indicators = Array.from(document.querySelectorAll('[data-step-indicator]'));
		const errorAlert = document.getElementById('ec-horeca-form-errors');
		const successBox = document.getElementById('ec-horeca-success-box');
		const submitBtn = document.getElementById('ec-horeca-submit-btn');
		const activityOtherWrap = document.getElementById('ec-activity-other-wrap');
		const activityRadios = form.querySelectorAll('input[name="activity_type"]');
		const blendRadios = form.querySelectorAll('input[name="sample_blend"]');
		const sampleProdIdInput = document.getElementById('ec_sample_product_id');

		let currentStepIndex = 1;

		/**
		 * Toggle "Altro" activity detail field
		 */
		function updateActivityOther() {
			const checked = form.querySelector('input[name="activity_type"]:checked');
			if (checked && checked.value === 'Altro') {
				if (activityOtherWrap) {
					activityOtherWrap.style.display = 'flex';
					const input = activityOtherWrap.querySelector('input');
					if (input) input.required = true;
				}
			} else if (activityOtherWrap) {
				activityOtherWrap.style.display = 'none';
				const input = activityOtherWrap.querySelector('input');
				if (input) {
					input.required = false;
					input.value = '';
				}
			}
		}

		activityRadios.forEach(function(radio) {
			radio.addEventListener('change', updateActivityOther);
		});
		updateActivityOther();

		/**
		 * Synchronize sample product ID when blend radio changes
		 */
		blendRadios.forEach(function(radio) {
			radio.addEventListener('change', function() {
				if (sampleProdIdInput) {
					sampleProdIdInput.value = radio.dataset.productId || '0';
				}
			});
		});

		/**
		 * Preselect blend from Section 03 cards
		 */
		const preselectButtons = document.querySelectorAll('[data-preselect-blend]');
		preselectButtons.forEach(function(btn) {
			btn.addEventListener('click', function(e) {
				const blendSlug = btn.getAttribute('data-preselect-blend');
				if (blendSlug) {
					const matchingRadio = form.querySelector('input[name="sample_blend"][data-blend-slug="' + blendSlug + '"]');
					if (matchingRadio) {
						matchingRadio.checked = true;
						if (sampleProdIdInput) {
							sampleProdIdInput.value = matchingRadio.dataset.productId || '0';
						}
					}
				}
			});
		});

		/**
		 * Validate fields inside a specific step
		 */
		function validateStep(stepNumber) {
			const stepEl = form.querySelector('[data-form-step="' + stepNumber + '"]');
			if (!stepEl) return true;

			let isValid = true;
			const fields = Array.from(stepEl.querySelectorAll('input, textarea, select'));

			// Clear previous field errors
			stepEl.querySelectorAll('.has-error').forEach(function(el) {
				el.classList.remove('has-error');
			});
			if (errorAlert) {
				errorAlert.hidden = true;
				errorAlert.textContent = '';
			}

			fields.forEach(function(field) {
				if (field.type === 'radio') {
					const groupName = field.name;
					const checked = stepEl.querySelector('input[name="' + groupName + '"]:checked');
					if (field.required && !checked) {
						isValid = false;
						const fieldParent = field.closest('.ec-horeca-field');
						if (fieldParent) fieldParent.classList.add('has-error');
					}
				} else if (field.type === 'checkbox') {
					if (field.required && !field.checked) {
						isValid = false;
						const fieldParent = field.closest('.ec-horeca-field');
						if (fieldParent) fieldParent.classList.add('has-error');
					}
				} else if (field.required && !field.value.trim()) {
					isValid = false;
					const fieldParent = field.closest('.ec-horeca-field');
					if (fieldParent) fieldParent.classList.add('has-error');
				} else if (field.type === 'email' && field.value.trim()) {
					const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
					if (!emailRegex.test(field.value.trim())) {
						isValid = false;
						const fieldParent = field.closest('.ec-horeca-field');
						if (fieldParent) fieldParent.classList.add('has-error');
					}
				}
			});

			if (!isValid && errorAlert) {
				errorAlert.hidden = false;
				errorAlert.textContent = 'Compila tutti i campi obbligatori per proseguire.';
			}

			return isValid;
		}

		/**
		 * Switch active form step
		 */
		function goToStep(stepNumber) {
			steps.forEach(function(stepEl) {
				const num = parseInt(stepEl.getAttribute('data-form-step'), 10);
				if (num === stepNumber) {
					stepEl.hidden = false;
					stepEl.classList.add('is-active');
				} else {
					stepEl.hidden = true;
					stepEl.classList.remove('is-active');
				}
			});

			indicators.forEach(function(indEl) {
				const num = parseInt(indEl.getAttribute('data-step-indicator'), 10);
				indEl.classList.remove('is-active', 'is-completed');
				if (num === stepNumber) {
					indEl.classList.add('is-active');
				} else if (num < stepNumber) {
					indEl.classList.add('is-completed');
				}
			});

			currentStepIndex = stepNumber;

			// Scroll softly to the form header
			const sampleSection = document.getElementById('richiedi-campione');
			if (sampleSection) {
				sampleSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
			}
		}

		// Next Step Buttons
		form.querySelectorAll('[data-next-step]').forEach(function(btn) {
			btn.addEventListener('click', function() {
				const targetStep = parseInt(btn.getAttribute('data-next-step'), 10);
				if (validateStep(currentStepIndex)) {
					goToStep(targetStep);
				}
			});
		});

		// Previous Step Buttons
		form.querySelectorAll('[data-prev-step]').forEach(function(btn) {
			btn.addEventListener('click', function() {
				const targetStep = parseInt(btn.getAttribute('data-prev-step'), 10);
				goToStep(targetStep);
			});
		});

		/**
		 * AJAX Form Submission
		 */
		form.addEventListener('submit', function(e) {
			e.preventDefault();

			if (!validateStep(3)) {
				return;
			}

			// UI loading state
			if (submitBtn) {
				submitBtn.disabled = true;
				const textSpan = submitBtn.querySelector('.ec-btn-text');
				const loadingSpan = submitBtn.querySelector('.ec-btn-loading');
				if (textSpan) textSpan.style.display = 'none';
				if (loadingSpan) loadingSpan.style.display = 'inline-flex';
			}

			if (errorAlert) {
				errorAlert.hidden = true;
				errorAlert.textContent = '';
			}

			const formData = new FormData(form);
			const ajaxUrl = (window.espressoHorecaConfig && window.espressoHorecaConfig.ajaxUrl) ? window.espressoHorecaConfig.ajaxUrl : '/wp-admin/admin-ajax.php';

			fetch(ajaxUrl, {
				method: 'POST',
				body: formData,
			})
			.then(function(response) {
				return response.json();
			})
			.then(function(result) {
				if (result.success) {
					form.style.display = 'none';
					if (successBox) {
						successBox.hidden = false;
						const sampleSection = document.getElementById('richiedi-campione');
						if (sampleSection) {
							sampleSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
						}
					}
				} else {
					if (submitBtn) {
						submitBtn.disabled = false;
						const textSpan = submitBtn.querySelector('.ec-btn-text');
						const loadingSpan = submitBtn.querySelector('.ec-btn-loading');
						if (textSpan) textSpan.style.display = 'inline-flex';
						if (loadingSpan) loadingSpan.style.display = 'none';
					}

					if (errorAlert) {
						errorAlert.hidden = false;
						errorAlert.textContent = result.data && result.data.message ? result.data.message : 'Si è verificato un errore durante l\'invio. Verifica i dati e riprova.';
					}
				}
			})
			.catch(function(error) {
				console.error('Ho.Re.Ca. submission error:', error);
				if (submitBtn) {
					submitBtn.disabled = false;
					const textSpan = submitBtn.querySelector('.ec-btn-text');
					const loadingSpan = submitBtn.querySelector('.ec-btn-loading');
					if (textSpan) textSpan.style.display = 'inline-flex';
					if (loadingSpan) loadingSpan.style.display = 'none';
				}

				if (errorAlert) {
					errorAlert.hidden = false;
					errorAlert.textContent = 'Errore di connessione. Controlla la rete o riprova più tardi.';
				}
			});
		});

	});
})();
