(function () {
	'use strict';

	const gateway = document.querySelector('[data-coffee-gateway]');
	const core = window.EspressoFinderCore;

	if (!gateway || !core) {
		return;
	}

	const dataNode = document.getElementById('espresso-coppola-catalog');
	const buttons = Array.from(gateway.querySelectorAll('[data-gateway-choice]'));
	const choiceList = gateway.querySelector('[data-gateway-choice-list]');
	const productsNode = gateway.querySelector('[data-gateway-products]');
	const paginationNode = gateway.querySelector('[data-gateway-pagination]');
	const ambientNode = gateway.querySelector('[data-gateway-ambient]');
	const statusNode = gateway.querySelector('[data-gateway-status]');
	const form = gateway.querySelector('[data-gateway-form]');
	const messages = window.espressoGatewayI18n || {};
	const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
	let catalog = { products: [] };
	let activeButton = buttons.find(function (button) {
		return button.getAttribute('aria-pressed') === 'true';
	}) || buttons[0];
	let windowStart = 0;
	let renderToken = 0;

	if (!dataNode || !buttons.length || !productsNode) {
		return;
	}

	try {
		catalog = JSON.parse(dataNode.textContent);
	} catch (error) {
		catalog = { products: [] };
	}

	function element(tag, className, text) {
		const node = document.createElement(tag);
		if (className) {
			node.className = className;
		}
		if (typeof text === 'string') {
			node.textContent = text;
		}
		return node;
	}

	function selectionFor(button) {
		try {
			return JSON.parse(button.getAttribute('data-selection') || '{}');
		} catch (error) {
			return {};
		}
	}

	function labelFor(button) {
		const label = button.querySelector('strong');
		return label ? label.textContent.trim() : button.value;
	}

	function compatibleProducts(button) {
		return core.filterProducts(catalog.products || [], selectionFor(button));
	}

	function blendLabel(product) {
		return product.blends && product.blends[0] ? product.blends[0].name : '';
	}

	function productCard(product, index) {
		const card = element('article', 'ec-coffee-gateway__product' + (index === 0 ? ' is-primary' : ''));
		card.dataset.gatewayProductId = String(product.id);

		if (product.image) {
			const media = element('a', 'ec-coffee-gateway__product-media');
			const image = element('img');
			media.href = product.url;
			media.tabIndex = -1;
			media.setAttribute('aria-hidden', 'true');
			image.src = product.image;
			image.alt = '';
			image.loading = 'lazy';
			image.decoding = 'async';
			if (product.imageSrcset) {
				image.srcset = product.imageSrcset;
				image.sizes = product.imageSizes || '(max-width: 640px) 78vw, 360px';
			}
			media.append(image);
			card.append(media);
		}

		const blend = blendLabel(product);
		if (blend) {
			const badge = element('span', 'ec-coffee-gateway__product-badge', blend);
			card.append(badge);
		}

		// Hover Bubble / Nuvoletta con il nome del prodotto
		const bubble = element('div', 'ec-coffee-gateway__product-bubble');
		bubble.setAttribute('aria-hidden', 'true');
		if (blend) {
			bubble.append(element('span', 'ec-coffee-gateway__product-blend', blend));
		}
		bubble.append(element('p', 'ec-coffee-gateway__product-title', product.name || 'Espresso Coppola'));
		card.append(bubble);

		// Overlay in sovraimpressione con Prezzo e Tasto Acquista
		const overlay = element('div', 'ec-coffee-gateway__product-overlay');
		if (product.priceHtml) {
			const price = element('span', 'ec-coffee-gateway__product-price');
			price.innerHTML = product.priceHtml;
			overlay.append(price);
		}
		const buyBtn = element('a', 'ec-coffee-gateway__product-cta', (messages.discover || 'Acquista') + ' ');
		buyBtn.href = product.url;
		buyBtn.setAttribute('aria-label', (messages.discoverLabel || 'Acquista %s').replace('%s', product.name || 'Espresso Coppola'));
		const arrow = element('span', '', '↗');
		arrow.setAttribute('aria-hidden', 'true');
		buyBtn.append(arrow);
		overlay.append(buyBtn);
		card.append(overlay);

		return card;
	}

	function companionCard() {
		const card = element('article', 'ec-coffee-gateway__companion');
		const inner = element('div', 'ec-coffee-gateway__companion-inner');
		const top = element('div');
		top.append(element('span', 'ec-coffee-gateway__companion-badge', 'Boutique Coppola'));
		top.append(element('h3', '', 'L’autentico espresso napoletano.'));
		top.append(element('p', '', 'Miscele selezionate e tostatura artigianale lenta per una crema vellutata e un aroma inconfondibile.'));
		const list = element('ul', 'ec-coffee-gateway__companion-list');
		const li1 = element('li');
		li1.innerHTML = '<span aria-hidden="true">✓</span> Freschezza e fragranza garantite';
		const li2 = element('li');
		li2.innerHTML = '<span aria-hidden="true">✓</span> Spedizione rapida in tutta la Svizzera';
		list.append(li1, li2);
		top.append(list);
		inner.append(top);

		const shopLink = element('a', 'ec-coffee-gateway__companion-link', 'Esplora tutte le miscele ');
		shopLink.href = messages.shopUrl || '/shop/';
		const arrow = element('span', '', '↗');
		arrow.setAttribute('aria-hidden', 'true');
		shopLink.append(arrow);
		inner.append(shopLink);
		card.append(inner);
		return card;
	}

	function renderPagination(products) {
		paginationNode.replaceChildren();
		if (products.length <= 3) {
			return;
		}

		const previous = element('button', 'ec-coffee-gateway__page-button', '←');
		previous.type = 'button';
		previous.dataset.gatewayPrevious = '';
		previous.setAttribute('aria-label', messages.previousWindow || 'Indietro');
		previous.disabled = windowStart === 0;

		const position = element(
			'span',
			'ec-coffee-gateway__page-position',
			String(windowStart + 1).padStart(2, '0') + ' / ' + String(products.length).padStart(2, '0')
		);

		const next = element('button', 'ec-coffee-gateway__page-button', '→');
		next.type = 'button';
		next.dataset.gatewayNext = '';
		next.setAttribute('aria-label', messages.nextWindow || 'Avanti');
		next.disabled = windowStart >= products.length - 3;

		paginationNode.append(previous, position, next);
	}

	function commitRender(button, products, token) {
		if (token !== renderToken) {
			return;
		}

		const visibleProducts = products.slice(windowStart, windowStart + 3);
		productsNode.replaceChildren();
		visibleProducts.forEach(function (product, index) {
			productsNode.append(productCard(product, index));
		});
		if (visibleProducts.length === 1) {
			productsNode.append(companionCard());
		}
		renderPagination(products);
		productsNode.classList.remove('is-switching');

		const label = labelFor(button);
		if (statusNode) {
			statusNode.textContent = (messages.statusTemplate || '%1$s, %2$d caffè disponibili.')
				.replace('%1$s', label)
				.replace('%2$d', String(products.length));
		}
	}

	function updateUrl(button) {
		if (!window.history || typeof window.history.replaceState !== 'function') {
			return;
		}
		const url = new URL(window.location.href);
		url.searchParams.set('coffee_system', button.dataset.gatewayChoice);
		window.history.replaceState({}, '', url.href);
	}

	function activate(button, options) {
		if (!button) {
			return;
		}

		const settings = options || {};
		activeButton = button;
		windowStart = settings.keepWindow ? windowStart : 0;
		buttons.forEach(function (candidate) {
			const active = candidate === button;
			candidate.classList.toggle('is-active', active);
			candidate.setAttribute('aria-pressed', active ? 'true' : 'false');
			candidate.tabIndex = active ? 0 : -1;
		});

		if (ambientNode) {
			ambientNode.classList.remove('is-visible');
			ambientNode.textContent = labelFor(button);
			window.requestAnimationFrame(function () {
				ambientNode.classList.add('is-visible');
			});
		}

		if (settings.updateUrl !== false) {
			updateUrl(button);
		}

		const products = compatibleProducts(button);
		const token = ++renderToken;
		productsNode.classList.add('is-switching');
		window.setTimeout(function () {
			commitRender(button, products, token);
		}, reduceMotion.matches ? 0 : 60);
	}

	function moveWindow(direction) {
		const products = compatibleProducts(activeButton);
		windowStart = Math.max(0, Math.min(products.length - 3, windowStart + direction));
		commitRender(activeButton, products, ++renderToken);
	}

	function revealChoice(button) {
		if (!button || !choiceList || choiceList.scrollWidth <= choiceList.clientWidth) {
			return;
		}

		const targetLeft = button.offsetLeft - ((choiceList.clientWidth - button.offsetWidth) / 2);
		choiceList.scrollTo({
			left: Math.max(0, targetLeft),
			behavior: reduceMotion.matches ? 'auto' : 'smooth',
		});
	}

	function focusByKey(event, index) {
		let target = index;
		if (event.key === 'ArrowRight' || event.key === 'ArrowDown') {
			target = (index + 1) % buttons.length;
		} else if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') {
			target = (index - 1 + buttons.length) % buttons.length;
		} else if (event.key === 'Home') {
			target = 0;
		} else if (event.key === 'End') {
			target = buttons.length - 1;
		} else {
			return;
		}
		event.preventDefault();
		buttons[target].focus({ preventScroll: true });
		revealChoice(buttons[target]);
	}

	if (form) {
		form.addEventListener('submit', function (event) {
			event.preventDefault();
		});
	}

	buttons.forEach(function (button, index) {
		button.addEventListener('click', function (event) {
			event.preventDefault();
			activate(button);
			revealChoice(button);
		});
		button.addEventListener('keydown', function (event) {
			focusByKey(event, index);
		});
	});

	paginationNode.addEventListener('click', function (event) {
		if (event.target.closest('[data-gateway-next]')) {
			moveWindow(1);
		} else if (event.target.closest('[data-gateway-previous]')) {
			moveWindow(-1);
		}
	});

	const requested = new URLSearchParams(window.location.search).get('coffee_system');
	const requestedButton = requested ? buttons.find(function (button) {
		return button.dataset.gatewayChoice === requested;
	}) : null;

	gateway.classList.add('is-enhanced');
	activate(requestedButton || activeButton || buttons[0], { updateUrl: !!requestedButton });

	window.EspressoCoffeeGateway = {
		focusActiveChoice: function () {
			(activeButton || buttons[0]).focus({ preventScroll: true });
		},
		scrollToGateway: function () {
			gateway.scrollIntoView({
				block: 'start',
				behavior: reduceMotion.matches ? 'auto' : 'smooth',
			});
			window.setTimeout(function () {
				(activeButton || buttons[0]).focus({ preventScroll: true });
			}, reduceMotion.matches ? 0 : 360);
		},
	};
})();
