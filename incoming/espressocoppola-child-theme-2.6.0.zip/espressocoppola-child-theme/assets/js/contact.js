(function () {
	'use strict';

	var root = document.querySelector('[data-contact-page]');
	if (!root) {
		return;
	}

	var reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
	var reveals = Array.prototype.slice.call(root.querySelectorAll('[data-contact-reveal]'));
	var orbit = root.querySelector('[data-contact-orbit]');

	if (reducedMotion || !('IntersectionObserver' in window)) {
		reveals.forEach(function (element) {
			element.classList.add('is-visible');
		});
		if (orbit) {
			orbit.dataset.contactInView = 'false';
		}
		return;
	}

	root.classList.add('is-contact-motion-ready');

	var revealObserver = new IntersectionObserver(function (entries, observer) {
		entries.forEach(function (entry) {
			if (!entry.isIntersecting) {
				return;
			}

			entry.target.classList.add('is-visible');
			observer.unobserve(entry.target);
		});
	}, {
		rootMargin: '0px 0px -8% 0px',
		threshold: 0.12
	});

	reveals.forEach(function (element) {
		revealObserver.observe(element);
	});

	if (orbit) {
		var orbitIsVisible = false;
		var orbitObserver = new IntersectionObserver(function (entries) {
			entries.forEach(function (entry) {
				orbitIsVisible = entry.isIntersecting;
				entry.target.dataset.contactInView = orbitIsVisible && !document.hidden ? 'true' : 'false';
			});
		}, { threshold: 0.08 });

		orbitObserver.observe(orbit);
		document.addEventListener('visibilitychange', function () {
			orbit.dataset.contactInView = orbitIsVisible && !document.hidden ? 'true' : 'false';
		});
	}
}());
