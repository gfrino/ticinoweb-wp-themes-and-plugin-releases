(function () {
	'use strict';

	function init() {
		const root = document.querySelector('[data-dna-page]');
		if (!root || !window.EspressoSensoryRadar) return;

		const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
		const labels = window.espressoDnaConfig?.axes || [];
		const makeRadar = (svg, values, color, name) => window.EspressoSensoryRadar.create(svg, {
			labels,
			values,
			color,
			name,
			compactLabels: true,
			reducedMotion: reduced,
		});

		const compare = root.querySelector('[data-dna-compare]');
		if (compare) {
			const data = JSON.parse(compare.querySelector('[data-dna-data]')?.textContent || '{"products":[]}');
			const products = new Map(data.products.map((product) => [String(product.id), product]));
			const selectA = compare.querySelector('[data-dna-select-a]');
			const selectB = compare.querySelector('[data-dna-select-b]');
			const legendNameA = compare.querySelector('[data-dna-legend-name-a]');
			const legendNameB = compare.querySelector('[data-dna-legend-name-b]');
			const productA = products.get(selectA?.value);
			const productB = products.get(selectB?.value);

			if (selectA && selectB && productA && productB) {
				const radarSvgA = compare.querySelector('[data-dna-radar-a]');
				const radarSvgB = compare.querySelector('[data-dna-radar-b]');
				const radarA = makeRadar(radarSvgA, productA.values, productA.color || '#7b3137', productA.name);
				const radarB = makeRadar(radarSvgB, productB.values, productB.color || '#c8861e', productB.name);

				const updateComparison = () => {
					const nextA = products.get(selectA.value);
					const nextB = products.get(selectB.value);
					if (!nextA || !nextB) return;

					const colorA = '#7b3137'; // High-contrast rich espresso/bordeaux for Product A
					const colorB = '#c8861e'; // High-contrast radiant warm gold for Product B

					compare.style.setProperty('--dna-a', colorA);
					compare.style.setProperty('--dna-b', colorB);

					if (legendNameA) legendNameA.textContent = nextA.name;
					if (legendNameB) legendNameB.textContent = nextB.name;

					radarA.update(nextA, { immediate: reduced, duration: 550 });
					radarB.update(nextB, { immediate: reduced, duration: 550 });

					compare.querySelectorAll('[data-dna-differences] li').forEach((row, index) => {
						const valA = nextA.values[index] ?? 0;
						const valB = nextB.values[index] ?? 0;

						const fillA = row.querySelector('[data-fill-a]');
						const fillB = row.querySelector('[data-fill-b]');
						const markerA = row.querySelector('[data-marker-a]');
						const markerB = row.querySelector('[data-marker-b]');
						const scoreA = row.querySelector('[data-score-a]');
						const scoreB = row.querySelector('[data-score-b]');

						if (fillA) fillA.style.width = `${valA * 20}%`;
						if (fillB) fillB.style.width = `${valB * 20}%`;
						if (markerA) markerA.style.left = `${valA * 20}%`;
						if (markerB) markerB.style.left = `${valB * 20}%`;
						if (scoreA) scoreA.textContent = String(valA);
						if (scoreB) scoreB.textContent = String(valB);
					});
				};

				selectA.addEventListener('change', updateComparison);
				selectB.addEventListener('change', updateComparison);
				updateComparison();
			}
		}

		if (!reduced && 'IntersectionObserver' in window) {
			const observer = new IntersectionObserver((entries) => {
				entries.forEach((entry) => entry.target.classList.toggle('is-paused', !entry.isIntersecting));
			}, { rootMargin: '100px' });
			root.querySelectorAll('[data-dna-loop]').forEach((element) => observer.observe(element));
		}
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init, { once: true });
	} else {
		init();
	}
}());
