(function (root, factory) {
	'use strict';
	const api = factory();
	if (typeof module === 'object' && module.exports) module.exports = api;
	if (root) root.EspressoShop = api;
})(typeof window !== 'undefined' ? window : globalThis, function () {
	'use strict';

	const AXES = ['aromatic_intensity', 'olfactory_intensity', 'acidity', 'persistence', 'roast', 'body', 'sweetness'];
	const ORDERS = ['menu_order', 'date-desc', 'price-asc', 'price-desc'];

	function parseState(input) {
		const params = input instanceof URLSearchParams ? input : new URLSearchParams(String(input || '').replace(/^\?/, ''));
		const sensory = {};
		AXES.forEach((axis) => {
			const value = Number(params.get(`sensor_${axis}`));
			if (Number.isInteger(value) && value >= 1 && value <= 5) sensory[axis] = value;
		});
		const order = params.get('order');
		return {
			types: [...new Set(params.getAll('type').filter(Boolean))],
			blends: [...new Set(params.getAll('blend').filter(Boolean))],
			sensory,
			order: ORDERS.includes(order) ? order : 'menu_order',
		};
	}

	function serializeState(state) {
		const params = new URLSearchParams();
		(state.types || []).forEach((value) => params.append('type', value));
		(state.blends || []).forEach((value) => params.append('blend', value));
		AXES.forEach((axis) => {
			const value = Number(state.sensory?.[axis]);
			if (Number.isInteger(value) && value >= 1 && value <= 5) params.set(`sensor_${axis}`, String(value));
		});
		if (ORDERS.includes(state.order) && state.order !== 'menu_order') params.set('order', state.order);
		return params;
	}

	function initialize() {
		const root = document.querySelector('[data-shop-root]');
		if (!root || root.dataset.shopInitialized === 'true') return;
		root.dataset.shopInitialized = 'true';
		const config = window.espressoShopConfig || {};
		const form = root.querySelector('[data-shop-filter-form]');
		const grid = root.querySelector('[data-shop-grid]');
		const count = root.querySelector('[data-shop-count]');
		const countLabel = root.querySelector('[data-shop-count-label]');
		const chips = root.querySelector('[data-shop-chips]');
		const order = root.querySelector('[data-shop-order]');
		const loader = root.querySelector('[data-shop-loading]');
		const status = root.querySelector('[data-shop-status]');
		const panel = root.querySelector('[data-shop-filters]');
		const backdrop = root.querySelector('[data-shop-filter-backdrop]');
		const openButton = root.querySelector('[data-shop-filter-open]');
		const closeButton = root.querySelector('[data-shop-filter-close]');
		const applyButton = root.querySelector('[data-shop-filter-apply]');
		const activeCount = root.querySelector('[data-shop-active-count]');
		let controller = null;
		let lastFocused = null;
		let timer = null;

		function readForm() {
			const data = new FormData(form);
			const sensory = {};
			AXES.forEach((axis) => {
				const value = Number(data.get(`sensory[${axis}]`));
				if (value > 0) sensory[axis] = value;
			});
			return { types: data.getAll('types[]'), blends: data.getAll('blends[]'), sensory, order: order.value };
		}

		function applyState(state) {
			form.querySelectorAll('input[type="checkbox"]').forEach((input) => {
				input.checked = input.name === 'types[]' ? state.types.includes(input.value) : state.blends.includes(input.value);
			});
			form.querySelectorAll('[data-shop-sensory]').forEach((input) => {
				input.value = String(state.sensory[input.name.match(/\[([^\]]+)\]/)?.[1]] || 0);
				input.closest('label')?.querySelector('output').replaceChildren(input.value);
			});
			order.value = state.order;
		}

		function labelFor(input) {
			return input.closest('label')?.querySelector('span')?.textContent.trim() || input.value;
		}

		function renderChips(state) {
			chips.replaceChildren();
			const entries = [];
			form.querySelectorAll('input[type="checkbox"]:checked').forEach((input) => entries.push({ key: input.name, value: input.value, label: labelFor(input) }));
			form.querySelectorAll('[data-shop-sensory]').forEach((input) => {
				if (Number(input.value) > 0) entries.push({ key: input.name, value: '0', label: `${labelFor(input)} ≥ ${input.value}` });
			});
			entries.forEach((entry) => {
				const button = document.createElement('button');
				button.type = 'button'; button.textContent = `${entry.label} ×`; button.dataset.filterName = entry.key; button.dataset.filterValue = entry.value;
				chips.append(button);
			});
			activeCount.textContent = String(entries.length);
			activeCount.hidden = entries.length === 0;
			return state;
		}

		function initializeRadars(scope) {
			if (!window.EspressoSensoryRadar) return;
			scope.querySelectorAll('[data-shop-mini-radar]').forEach((svg) => {
				if (svg.dataset.radarReady) return;
				svg.dataset.radarReady = 'true';
				window.EspressoSensoryRadar.create(svg, { labels: config.axes || [], values: JSON.parse(svg.dataset.values || '[]'), color: svg.dataset.color || '#d6b77a', compactLabels: true, showLabels: false, name: config.radarName || 'Profilo sensoriale', reducedMotion: true });
				svg.setAttribute('aria-hidden', 'true');
				svg.querySelectorAll('[data-radar-point]').forEach((point) => point.setAttribute('tabindex', '-1'));
			});
		}

		function updateUrl(state) {
			const query = serializeState(state).toString();
			window.history.replaceState({ ecShop: true }, '', `${window.location.pathname}${query ? `?${query}` : ''}${window.location.hash}`);
		}

		async function update() {
			const state = renderChips(readForm());
			updateUrl(state);
			controller?.abort(); controller = new AbortController();
			loader.hidden = false; grid.classList.add('is-updating'); root.setAttribute('aria-busy', 'true');
			const body = new FormData(); body.append('action', 'espressocoppola_filter_shop'); body.append('nonce', config.nonce || '');
			state.types.forEach((value) => body.append('filters[types][]', value));
			state.blends.forEach((value) => body.append('filters[blends][]', value));
			Object.entries(state.sensory).forEach(([axis, value]) => body.append(`filters[sensory][${axis}]`, value));
			body.append('filters[order]', state.order);
			try {
				const response = await fetch(config.ajaxUrl, { method: 'POST', body, credentials: 'same-origin', signal: controller.signal });
				const payload = await response.json();
				if (!response.ok || !payload.success) throw new Error(config.error || 'Impossibile aggiornare il catalogo.');
				grid.innerHTML = payload.data.html; count.textContent = String(payload.data.count); countLabel.textContent = payload.data.count === 1 ? (config.product || 'prodotto') : (config.products || 'prodotti');
				status.textContent = (config.updated || '%d prodotti mostrati').replace('%d', String(payload.data.count));
				initializeRadars(grid);
			} catch (error) {
				if (error.name !== 'AbortError') status.textContent = error.message;
			} finally {
				loader.hidden = true; grid.classList.remove('is-updating'); root.removeAttribute('aria-busy');
			}
		}

		function scheduleUpdate() { window.clearTimeout(timer); timer = window.setTimeout(update, 180); }
		function openFilters() { lastFocused = document.activeElement; panel.classList.add('is-open'); panel.setAttribute('role', 'dialog'); panel.setAttribute('aria-modal', 'true'); backdrop.hidden = false; openButton.setAttribute('aria-expanded', 'true'); document.body.classList.add('ec-shop-filter-open'); closeButton.focus(); }
		function closeFilters() { panel.classList.remove('is-open'); panel.removeAttribute('role'); panel.removeAttribute('aria-modal'); backdrop.hidden = true; openButton.setAttribute('aria-expanded', 'false'); document.body.classList.remove('ec-shop-filter-open'); lastFocused?.focus(); }

		form.addEventListener('input', (event) => { if (event.target.matches('[data-shop-sensory]')) event.target.closest('label').querySelector('output').textContent = event.target.value; scheduleUpdate(); });
		form.addEventListener('change', scheduleUpdate);
		form.addEventListener('reset', () => window.setTimeout(() => { form.querySelectorAll('[data-shop-sensory]').forEach((input) => { input.closest('label').querySelector('output').textContent = '0'; }); order.value = 'menu_order'; update(); }, 0));
		order.addEventListener('change', update);
		chips.addEventListener('click', (event) => { const button = event.target.closest('button'); if (!button) return; const input = [...form.elements].find((element) => element.name === button.dataset.filterName && (element.value === button.dataset.filterValue || button.dataset.filterValue === '0')); if (input) { if (input.type === 'checkbox') input.checked = false; else input.value = '0'; update(); } });
		grid.addEventListener('click', (event) => {
			const button = event.target.closest('[data-shop-sensory-toggle]');
			if (!button) return;
			const card = button.closest('[data-shop-card]');
			const expanded = button.getAttribute('aria-expanded') === 'true';
			grid.querySelectorAll('.is-sensory-open').forEach((openCard) => {
				if (openCard === card) return;
				openCard.classList.remove('is-sensory-open');
				const openButton = openCard.querySelector('[data-shop-sensory-toggle]');
				openButton?.setAttribute('aria-expanded', 'false');
				openButton?.setAttribute('aria-label', openButton.dataset.openLabel || '');
				openCard.querySelector('[data-shop-sensory-panel]')?.setAttribute('aria-hidden', 'true');
			});
			button.setAttribute('aria-expanded', String(!expanded));
			button.setAttribute('aria-label', expanded ? button.dataset.openLabel : button.dataset.closeLabel);
			card.classList.toggle('is-sensory-open', !expanded);
			card.querySelector('[data-shop-sensory-panel]')?.setAttribute('aria-hidden', String(expanded));
		});
		openButton.addEventListener('click', openFilters); closeButton.addEventListener('click', closeFilters); backdrop.addEventListener('click', closeFilters); applyButton.addEventListener('click', closeFilters);
		document.addEventListener('keydown', (event) => {
			if (!panel.classList.contains('is-open')) return;
			if (event.key === 'Escape') { closeFilters(); return; }
			if (event.key !== 'Tab') return;
			const focusable = [...panel.querySelectorAll('button,input,select,summary,[href],[tabindex]:not([tabindex="-1"])')].filter((element) => !element.disabled && element.offsetParent !== null);
			if (!focusable.length) return;
			const first = focusable[0]; const last = focusable[focusable.length - 1];
			if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
			else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
		});
		window.addEventListener('popstate', () => { applyState(parseState(window.location.search)); update(); });

		applyState(parseState(window.location.search)); renderChips(readForm()); initializeRadars(grid);
		if (window.location.search) update();
	}

	if (typeof document !== 'undefined') {
		if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initialize, { once: true }); else initialize();
	}
	return { parseState, serializeState, initialize };
});
