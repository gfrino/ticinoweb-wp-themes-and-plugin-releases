/**
 * Espresso Coppola — FAQ / Answer Atlas Interaction Script
 *
 * Handles:
 * 1. IntersectionObserver for active category tracking in the Question Map
 * 2. Natural smooth anchor scrolling with header offset calculation
 * 3. Deep-link handling on initial page load (e.g. /faq/#faq-le-capsule-...)
 * 4. Respects prefers-reduced-motion
 *
 * @package EspressoCoppolaChildTheme
 */

(function() {
	'use strict';

	document.addEventListener('DOMContentLoaded', function() {
		const atlasPage = document.querySelector('[data-faq-atlas]');
		if (!atlasPage) {
			return;
		}

		const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
		const header = document.querySelector('.site-header') || document.querySelector('.ec-header');

		function getHeaderOffset() {
			if (!header) {
				return 90;
			}
			const rect = header.getBoundingClientRect();
			return rect.height > 0 ? rect.height + 24 : 90;
		}

		/**
		 * Smooth scroll to an element taking floating header into account.
		 */
		function scrollToTarget(target) {
			if (!target) {
				return;
			}

			const headerOffset = getHeaderOffset();
			const targetPosition = target.getBoundingClientRect().top + window.pageYOffset - headerOffset;

			window.scrollTo({
				top: targetPosition,
				behavior: prefersReducedMotion ? 'auto' : 'smooth'
			});

			// Add a subtle focus pulse to the targeted element
			target.classList.add('is-targeted');
			setTimeout(function() {
				target.classList.remove('is-targeted');
			}, 1800);
		}

		/**
		 * Handle anchor clicks (Question Map & Conversational Queries)
		 */
		const anchorLinks = atlasPage.querySelectorAll('a[href^="#"]');
		anchorLinks.forEach(function(link) {
			link.addEventListener('click', function(e) {
				const href = link.getAttribute('href');
				if (!href || href === '#') {
					return;
				}

				const targetId = href.substring(1);
				const targetElement = document.getElementById(targetId);

				if (targetElement) {
					e.preventDefault();
					history.pushState(null, null, href);
					scrollToTarget(targetElement);
				}
			});
		});

		/**
		 * Handle initial URL hash on page load
		 */
		if (window.location.hash) {
			const initialTarget = document.getElementById(window.location.hash.substring(1));
			if (initialTarget) {
				setTimeout(function() {
					scrollToTarget(initialTarget);
				}, 250);
			}
		}

		/**
		 * IntersectionObserver: Highlight category node in Question Map when category block is visible
		 */
		if ('IntersectionObserver' in window && !prefersReducedMotion) {
			const catBlocks = document.querySelectorAll('.ec-atlas-cat-block');
			const starLinks = document.querySelectorAll('.ec-atlas-star');

			if (catBlocks.length > 0 && starLinks.length > 0) {
				const catObserver = new IntersectionObserver(function(entries) {
					entries.forEach(function(entry) {
						if (entry.isIntersecting) {
							const blockSlug = entry.target.getAttribute('data-cat-block');

							starLinks.forEach(function(star) {
								if (star.getAttribute('data-cat-link') === blockSlug) {
									star.classList.add('is-active');
								} else {
									star.classList.remove('is-active');
								}
							});
						}
					});
				}, {
					root: null,
					rootMargin: '-15% 0px -65% 0px',
					threshold: 0
				});

				catBlocks.forEach(function(block) {
					catObserver.observe(block);
				});
			}

			// Subtle scroll focus tracking for individual answer cards
			const streamCards = document.querySelectorAll('.ec-atlas-card');
			if (streamCards.length > 0) {
				const cardObserver = new IntersectionObserver(function(entries) {
					entries.forEach(function(entry) {
						if (entry.isIntersecting) {
							entry.target.classList.add('is-focused');
						} else {
							entry.target.classList.remove('is-focused');
						}
					});
				}, {
					root: null,
					rootMargin: '-25% 0px -35% 0px',
					threshold: 0.1
				});

				streamCards.forEach(function(card) {
					cardObserver.observe(card);
				});
			}
		}
	});
})();
