(function () {
	'use strict';

	function initStage(stage) {
		const slides = Array.from(stage.querySelectorAll('.espresso-stage__slide'));
		const controls = Array.from(stage.querySelectorAll('[data-stage-target]'));
		const sticky = stage.querySelector('.espresso-stage__sticky');
		const currentLabel = stage.querySelector('[data-stage-current]');
		const status = stage.querySelector('[data-stage-status]');
		const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
		const finePointer = window.matchMedia('(hover: hover) and (pointer: fine) and (min-width: 781px)');
		let activeIndex = -1;
		let isVisible = true;
		let scrollFrame = 0;
		let pointerFrame = 0;

		if (!slides.length || !sticky) {
			return;
		}

		if (slides.length < 2) {
			return;
		}

		stage.classList.add('is-scroll-driven');

		function resetPointer() {
			window.cancelAnimationFrame(pointerFrame);
			pointerFrame = 0;
			stage.style.setProperty('--product-x', '0px');
			stage.style.setProperty('--product-y', '0px');
			stage.style.setProperty('--aura-x', '0px');
			stage.style.setProperty('--aura-y', '0px');
			stage.style.setProperty('--ambient-x', '0px');
			stage.style.setProperty('--ambient-y', '0px');
		}

		function setActive(nextIndex) {
			const index = Math.max(0, Math.min(slides.length - 1, Number(nextIndex) || 0));
			if (index === activeIndex) {
				return;
			}

			activeIndex = index;

			slides.forEach(function (slide, slideIndex) {
				const active = slideIndex === index;
				slide.classList.toggle('is-active', active);
				slide.setAttribute('aria-hidden', active ? 'false' : 'true');
				if (active) {
					slide.removeAttribute('inert');
				} else {
					slide.setAttribute('inert', '');
				}
			});

			controls.forEach(function (control, controlIndex) {
				const active = controlIndex === index;
				control.classList.toggle('is-active', active);
				if (active) {
					control.setAttribute('aria-current', 'true');
				} else {
					control.removeAttribute('aria-current');
				}
			});

			stage.dataset.tone = slides[index].dataset.tone || 'crema';
			if (currentLabel) {
				currentLabel.textContent = String(index + 1).padStart(2, '0');
			}

		}

		function getMetrics() {
			const stageTop = window.scrollY + stage.getBoundingClientRect().top;
			const stickyTop = parseFloat(window.getComputedStyle(sticky).top) || 0;
			const maximumOffset = Math.max(1, stage.offsetHeight - sticky.offsetHeight);
			return { scrollStart: stageTop - stickyTop, maximumOffset: maximumOffset };
		}

		function renderScroll() {
			scrollFrame = 0;
			if (!isVisible) {
				return;
			}

			const metrics = getMetrics();
			const rawProgress = (window.scrollY - metrics.scrollStart) / metrics.maximumOffset;
			const progress = Math.max(0, Math.min(1, rawProgress));
			const scenePosition = progress * Math.max(0, slides.length - 1);
			const index = Math.round(scenePosition);

			stage.style.setProperty('--stage-progress', progress.toFixed(4));
			setActive(index);
		}

		function requestScrollFrame() {
			if (!scrollFrame) {
				scrollFrame = window.requestAnimationFrame(renderScroll);
			}
		}

		function scrollToScene(index) {
			const boundedIndex = Math.max(0, Math.min(slides.length - 1, index));
			const metrics = getMetrics();
			const progress = slides.length > 1 ? boundedIndex / (slides.length - 1) : 0;
			if (status) {
				const title = slides[boundedIndex].querySelector('.espresso-stage__title');
				status.textContent = title ? title.textContent.trim() : slides[boundedIndex].textContent.trim();
			}
			window.scrollTo({
				top: metrics.scrollStart + (metrics.maximumOffset * progress),
				behavior: 'auto'
			});
		}

		controls.forEach(function (control, index) {
			control.addEventListener('click', function () {
				scrollToScene(index);
			});

			control.addEventListener('keydown', function (event) {
				let nextIndex = null;
				if (event.key === 'ArrowRight' || event.key === 'ArrowDown') {
					nextIndex = Math.min(slides.length - 1, index + 1);
				} else if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') {
					nextIndex = Math.max(0, index - 1);
				} else if (event.key === 'Home') {
					nextIndex = 0;
				} else if (event.key === 'End') {
					nextIndex = slides.length - 1;
				}

				if (nextIndex === null) {
					return;
				}

				event.preventDefault();
				controls[nextIndex].focus({ preventScroll: true });
				scrollToScene(nextIndex);
			});
		});

		stage.addEventListener('pointermove', function (event) {
			if (!finePointer.matches || reducedMotion.matches || !isVisible) {
				return;
			}

			const bounds = sticky.getBoundingClientRect();
			const normalizedX = ((event.clientX - bounds.left) / bounds.width) * 2 - 1;
			const normalizedY = ((event.clientY - bounds.top) / bounds.height) * 2 - 1;

			window.cancelAnimationFrame(pointerFrame);
			pointerFrame = window.requestAnimationFrame(function () {
				stage.style.setProperty('--product-x', (normalizedX * 9).toFixed(2) + 'px');
				stage.style.setProperty('--product-y', (normalizedY * 7).toFixed(2) + 'px');
				stage.style.setProperty('--aura-x', (normalizedX * -18).toFixed(2) + 'px');
				stage.style.setProperty('--aura-y', (normalizedY * -15).toFixed(2) + 'px');
				stage.style.setProperty('--ambient-x', (normalizedX * 22).toFixed(2) + 'px');
				stage.style.setProperty('--ambient-y', (normalizedY * 19).toFixed(2) + 'px');
			});
		});

		stage.addEventListener('pointerleave', resetPointer);

		if ('IntersectionObserver' in window) {
			const observer = new IntersectionObserver(function (entries) {
				isVisible = entries[0].isIntersecting;
				if (isVisible) {
					window.addEventListener('scroll', requestScrollFrame, { passive: true });
					requestScrollFrame();
				} else {
					window.removeEventListener('scroll', requestScrollFrame);
				}
			}, { threshold: 0 });
			observer.observe(stage);
		} else {
			window.addEventListener('scroll', requestScrollFrame, { passive: true });
		}

		window.addEventListener('resize', requestScrollFrame, { passive: true });
		if (typeof reducedMotion.addEventListener === 'function') {
			reducedMotion.addEventListener('change', function () {
				resetPointer();
				requestScrollFrame();
			});
			finePointer.addEventListener('change', resetPointer);
		}

		setActive(0);
		requestScrollFrame();
	}

	document.addEventListener('DOMContentLoaded', function () {
		document.querySelectorAll('[data-stage-scroll]').forEach(initStage);
	});
})();
