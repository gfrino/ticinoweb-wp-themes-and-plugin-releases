(() => {
	'use strict';

	const root = document.querySelector('[data-exhibition-root]');
	if (!root) return;

	document.documentElement.classList.add('ec-js');
	const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
	const desktop = window.matchMedia('(min-width: 1025px) and (hover: hover) and (pointer: fine)');
	const openers = Array.from(root.querySelectorAll('[data-exhibition-open]'))
		.sort((a, b) => Number(a.dataset.index) - Number(b.dataset.index));

	const revealItems = Array.from(root.querySelectorAll('.ec-exhibition-reveal'));
	if (reducedMotion.matches || !('IntersectionObserver' in window)) {
		revealItems.forEach((item) => item.classList.add('is-visible'));
	} else {
		const revealObserver = new IntersectionObserver((entries, observer) => {
			entries.forEach((entry) => {
				if (!entry.isIntersecting) return;
				entry.target.classList.add('is-visible');
				observer.unobserve(entry.target);
			});
		}, { rootMargin: '0px 0px -8%', threshold: 0.08 });
		revealItems.forEach((item) => revealObserver.observe(item));
	}

	const lightbox = root.querySelector('[data-exhibition-lightbox]');
	if (lightbox && openers.length) {
		const imageSlot = lightbox.querySelector('[data-lightbox-image-slot]');
		const image = new Image();
		image.className = 'ec-exhibition-lightbox__image';
		image.decoding = 'async';
		imageSlot.append(image);
		const counter = lightbox.querySelector('[data-lightbox-counter]');
		const closeButton = lightbox.querySelector('[data-lightbox-close]');
		const previousButton = lightbox.querySelector('[data-lightbox-prev]');
		const nextButton = lightbox.querySelector('[data-lightbox-next]');
		let activeIndex = 0;
		let returnFocus = null;
		let swipeStartX = null;

		const setImage = (index) => {
			activeIndex = (index + openers.length) % openers.length;
			const opener = openers[activeIndex];
			image.src = opener.dataset.fullSrc || '';
			image.srcset = opener.dataset.fullSrcset || '';
			image.alt = opener.dataset.alt || '';
			counter.textContent = `${String(activeIndex + 1).padStart(2, '0')} / ${String(openers.length).padStart(2, '0')}`;
		};

		const close = () => {
			if (lightbox.hidden) return;
			lightbox.hidden = true;
			document.body.classList.remove('ec-exhibition-lightbox-open');
			image.removeAttribute('src');
			image.removeAttribute('srcset');
			if (returnFocus && document.contains(returnFocus)) returnFocus.focus();
		};

		const open = (opener) => {
			returnFocus = opener;
			setImage(openers.indexOf(opener));
			lightbox.hidden = false;
			document.body.classList.add('ec-exhibition-lightbox-open');
			closeButton.focus();
		};

		openers.forEach((opener) => opener.addEventListener('click', () => open(opener)));
		closeButton.addEventListener('click', close);
		previousButton.addEventListener('click', () => setImage(activeIndex - 1));
		nextButton.addEventListener('click', () => setImage(activeIndex + 1));
		lightbox.addEventListener('click', (event) => {
			if (event.target === lightbox) close();
		});

		lightbox.addEventListener('pointerdown', (event) => {
			if (event.pointerType !== 'mouse') swipeStartX = event.clientX;
		}, { passive: true });
		lightbox.addEventListener('pointerup', (event) => {
			if (swipeStartX === null) return;
			const distance = event.clientX - swipeStartX;
			swipeStartX = null;
			if (Math.abs(distance) < 48) return;
			setImage(activeIndex + (distance < 0 ? 1 : -1));
		}, { passive: true });

		document.addEventListener('keydown', (event) => {
			if (lightbox.hidden) return;
			if (event.key === 'Escape') close();
			if (event.key === 'ArrowLeft') setImage(activeIndex - 1);
			if (event.key === 'ArrowRight') setImage(activeIndex + 1);
			if (event.key !== 'Tab') return;

			const controls = Array.from(lightbox.querySelectorAll('button:not([disabled])'));
			const first = controls[0];
			const last = controls[controls.length - 1];
			if (event.shiftKey && document.activeElement === first) {
				event.preventDefault();
				last.focus();
			} else if (!event.shiftKey && document.activeElement === last) {
				event.preventDefault();
				first.focus();
			}
		});
	}

	const sticky = root.querySelector('[data-exhibition-sticky]');
	let stickyTicking = false;
	const updateSticky = () => {
		stickyTicking = false;
		if (!sticky || !sticky.classList.contains('is-enhanced')) return;
		const frames = Array.from(sticky.querySelectorAll('[data-sticky-frame]'));
		const rect = sticky.getBoundingClientRect();
		const available = Math.max(1, rect.height - window.innerHeight);
		const progress = Math.min(1, Math.max(0, -rect.top / available));
		const active = Math.min(frames.length - 1, Math.floor(progress * frames.length));
		frames.forEach((frame, index) => frame.classList.toggle('is-active', index === active));
	};

	const requestSticky = () => {
		if (stickyTicking) return;
		stickyTicking = true;
		window.requestAnimationFrame(updateSticky);
	};

	const configureSticky = () => {
		if (!sticky) return;
		const enhance = desktop.matches && !reducedMotion.matches;
		sticky.classList.toggle('is-enhanced', enhance);
		sticky.querySelectorAll('[data-sticky-frame]').forEach((frame, index) => {
			frame.classList.toggle('is-active', !enhance || index === 0);
		});
		requestSticky();
	};

	configureSticky();
	desktop.addEventListener('change', configureSticky);
	reducedMotion.addEventListener('change', configureSticky);
	window.addEventListener('scroll', requestSticky, { passive: true });
	window.addEventListener('resize', requestSticky, { passive: true });

	const parallaxItems = Array.from(root.querySelectorAll('[data-exhibition-parallax]'));
	let visibleParallax = new Set();
	let parallaxTicking = false;
	const updateParallax = () => {
		parallaxTicking = false;
		if (!desktop.matches || reducedMotion.matches) {
			parallaxItems.forEach((item) => item.style.removeProperty('--ec-parallax-y'));
			return;
		}
		visibleParallax.forEach((item) => {
			const rect = item.getBoundingClientRect();
			const strength = Number(item.dataset.exhibitionParallax) || 0.02;
			const offset = Math.max(-20, Math.min(20, (window.innerHeight / 2 - (rect.top + rect.height / 2)) * strength));
			item.style.setProperty('--ec-parallax-y', `${offset.toFixed(2)}px`);
		});
	};
	const requestParallax = () => {
		if (parallaxTicking) return;
		parallaxTicking = true;
		window.requestAnimationFrame(updateParallax);
	};

	if ('IntersectionObserver' in window) {
		const parallaxObserver = new IntersectionObserver((entries) => {
			entries.forEach((entry) => {
				if (entry.isIntersecting) visibleParallax.add(entry.target);
				else visibleParallax.delete(entry.target);
			});
			requestParallax();
		}, { rootMargin: '15%' });
		parallaxItems.forEach((item) => parallaxObserver.observe(item));
	}
	window.addEventListener('scroll', requestParallax, { passive: true });
	window.addEventListener('resize', requestParallax, { passive: true });
})();
