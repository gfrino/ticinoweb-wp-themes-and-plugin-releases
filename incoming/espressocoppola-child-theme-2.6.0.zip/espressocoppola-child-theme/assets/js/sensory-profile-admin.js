(function () {
	'use strict';

	const AXIS_LABELS = {
		aromatic_intensity: 'Intensità aromatica',
		olfactory_intensity: 'Intensità olfattiva',
		acidity: 'Acido',
		persistence: 'Persistente',
		roast: 'Tostato',
		body: 'Corpo',
		sweetness: 'Dolce',
	};
	const i18n = window.espressoSensoryAdminI18n || {};

	function validValue(value) {
		const parsed = Number(value);
		return Number.isInteger(parsed) && parsed >= 1 && parsed <= 5 ? parsed : null;
	}

	function initialize(panel) {
		if (panel.dataset.sensoryInitialized === 'true' || !window.EspressoSensoryRadar) return;
		panel.dataset.sensoryInitialized = 'true';

		const numberInputs = [...panel.querySelectorAll('[data-sensory-number]')];
		const ranges = [...panel.querySelectorAll('[data-sensory-range]')];
		const outputs = [...panel.querySelectorAll('[data-sensory-output]')];
		const status = panel.querySelector('[data-sensory-status]');
		const progress = panel.querySelector('[data-sensory-progress]');
		const svg = panel.querySelector('[data-sensory-radar]');
		const colorField = panel.querySelector('.ec-sensory-color-field');
		const labels = numberInputs.map((input) => input.dataset.sensoryLabel || AXIS_LABELS[input.dataset.sensoryAxis] || input.dataset.sensoryAxis);
		const readValues = () => numberInputs.map((input) => validValue(input.value));
		const radar = window.EspressoSensoryRadar.create(svg, {
			labels,
			axisKeys: numberInputs.map((input) => input.dataset.sensoryAxis),
			values: readValues(),
			name: i18n.previewName || 'Preview prodotto',
			color: colorField?.value || '#d6b77a',
			reducedMotion: true,
		});

		function update() {
			const values = readValues();
			const missing = values.filter((value) => value === null).length;
			const completed = values.length - missing;
			outputs.forEach((output) => {
				const input = numberInputs.find((candidate) => candidate.dataset.sensoryAxis === output.dataset.sensoryAxis);
				const value = input ? validValue(input.value) : null;
				output.textContent = value === null ? '— / 5' : `${value} / 5`;
			});
			if (progress) {
				progress.textContent = (i18n.progress || '%1$d / %2$d valori compilati')
					.replace('%1$d', String(completed))
					.replace('%2$d', String(values.length));
			}
			status.classList.toggle('is-complete', missing === 0);
			status.textContent = missing === 0
				? (i18n.complete || 'Profilo completo ✓')
				: (missing === 1
					? (i18n.missingOne || 'Profilo incompleto — manca 1 valore')
					: (i18n.missingMany || 'Profilo incompleto — mancano %d valori').replace('%d', String(missing)));
			radar.update({
				name: i18n.previewName || 'Preview prodotto',
				values,
				color: colorField?.value || '#d6b77a',
			}, { immediate: true });
		}

		ranges.forEach((range) => {
			range.addEventListener('input', () => {
				const numberInput = numberInputs.find((input) => input.dataset.sensoryAxis === range.dataset.sensoryAxis);
				if (numberInput) numberInput.value = range.value;
				update();
			});
		});

		numberInputs.forEach((input) => {
			input.addEventListener('input', () => {
				const range = ranges.find((candidate) => candidate.dataset.sensoryAxis === input.dataset.sensoryAxis);
				if (range && validValue(input.value) !== null) range.value = input.value;
				update();
			});
		});

		if (colorField) {
			colorField.addEventListener('input', update);
			colorField.addEventListener('change', update);
			if (window.jQuery && window.jQuery.fn && window.jQuery.fn.wpColorPicker) {
				window.jQuery(colorField).wpColorPicker({ change: update, clear: update });
			}
		}

		const selectButton = panel.querySelector('[data-sensory-reference-select]');
		const removeButton = panel.querySelector('[data-sensory-reference-remove]');
		const referenceId = panel.querySelector('[data-sensory-reference-id]');
		const referencePreview = panel.querySelector('[data-sensory-reference-preview]');
		const referenceFilename = panel.querySelector('[data-sensory-reference-filename]');
		const referenceDetails = panel.querySelector('[data-sensory-reference-details]');
		const referenceToggle = panel.querySelector('[data-sensory-reference-toggle]');

		const updateDisclosureLabel = () => {
			if (referenceToggle && referenceDetails) {
				referenceToggle.textContent = referenceDetails.open ? (i18n.close || 'Chiudi') : (i18n.open || 'Apri');
			}
		};
		referenceDetails?.addEventListener('toggle', updateDisclosureLabel);
		updateDisclosureLabel();

		selectButton?.addEventListener('click', () => {
			if (!window.wp || typeof window.wp.media !== 'function') return;
			const frame = window.wp.media({
				title: i18n.mediaTitle || 'Grafico originale di riferimento',
				button: { text: i18n.mediaButton || 'Usa questa immagine' },
				library: { type: 'image' },
				multiple: false,
			});
			frame.on('select', () => {
				const attachment = frame.state().get('selection').first().toJSON();
				referenceId.value = String(attachment.id || '');
				referencePreview.replaceChildren();
				const image = document.createElement('img');
				image.src = attachment.sizes?.medium?.url || attachment.url;
				image.alt = attachment.alt || i18n.referenceAlt || 'Grafico originale di riferimento';
				referencePreview.append(image);
				if (referenceFilename) referenceFilename.textContent = attachment.filename || i18n.fileSelected || 'Immagine selezionata';
				selectButton.textContent = i18n.replace || 'Sostituisci immagine';
				removeButton.hidden = false;
			});
			frame.open();
		});

		removeButton?.addEventListener('click', () => {
			referenceId.value = '';
			referencePreview.innerHTML = `<p>${i18n.noReference || 'Nessuna immagine di riferimento.'}</p>`;
			if (referenceFilename) referenceFilename.textContent = i18n.noFile || 'Nessun file selezionato';
			selectButton.textContent = i18n.select || 'Scegli immagine';
			removeButton.hidden = true;
		});

		update();
	}

	const panels = document.querySelectorAll('[data-sensory-admin]');
	if (panels.length) panels.forEach(initialize);
	else document.addEventListener('DOMContentLoaded', () => document.querySelectorAll('[data-sensory-admin]').forEach(initialize), { once: true });
})();
