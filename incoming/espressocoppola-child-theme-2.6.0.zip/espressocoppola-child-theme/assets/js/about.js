(function () {
	'use strict';

	function initialize() {
		const root = document.querySelector('[data-about-page]');
		if (!root || root.dataset.aboutReady === 'true') return;
		root.dataset.aboutReady = 'true';
		const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
		const config = window.espressoAboutConfig || {};

		root.querySelectorAll('[data-about-radar], [data-shop-mini-radar]').forEach((svg) => {
			if (!window.EspressoSensoryRadar || svg.dataset.radarReady) return;
			svg.dataset.radarReady = 'true';
			window.EspressoSensoryRadar.create(svg, {
				labels: config.axes || [],
				values: JSON.parse(svg.dataset.values || '[]'),
				color: svg.dataset.color || '#d6b77a',
				compactLabels: true,
				showLabels: false,
				name: config.radarName || 'Profilo sensoriale',
				reducedMotion: true,
			});
			svg.setAttribute('aria-hidden', 'true');
		});

		root.querySelector('[data-about-product-grid]')?.addEventListener('click', (event) => {
			const button = event.target.closest('[data-shop-sensory-toggle]');
			if (!button) return;
			const card = button.closest('[data-shop-card]');
			const expanded = button.getAttribute('aria-expanded') === 'true';
			button.setAttribute('aria-expanded', String(!expanded));
			button.setAttribute('aria-label', expanded ? button.dataset.openLabel : button.dataset.closeLabel);
			card.classList.toggle('is-sensory-open', !expanded);
			card.querySelector('[data-shop-sensory-panel]')?.setAttribute('aria-hidden', String(expanded));
		});

		if (reduced || !('IntersectionObserver' in window)) {
			root.querySelectorAll('[data-about-reveal]').forEach((element) => element.classList.add('is-visible'));
			return;
		}

		const revealObserver = new IntersectionObserver((entries, observer) => {
			entries.forEach((entry) => {
				if (!entry.isIntersecting) return;
				entry.target.classList.add('is-visible');
				observer.unobserve(entry.target);
			});
		}, { threshold: 0.12 });
		root.querySelectorAll('[data-about-reveal]').forEach((element) => revealObserver.observe(element));

		const loopObserver = new IntersectionObserver((entries) => {
			entries.forEach((entry) => entry.target.classList.toggle('is-paused', !entry.isIntersecting));
		}, { rootMargin: '120px' });
		root.querySelectorAll('[data-about-loop]').forEach((element) => loopObserver.observe(element));
	}

	if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initialize, { once: true });
	else initialize();
})();
