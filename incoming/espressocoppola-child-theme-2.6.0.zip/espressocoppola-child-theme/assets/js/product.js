(function () {
	'use strict';

	function initialize() {
		const root = document.querySelector('[data-product-page]');
		if (!root || root.dataset.productInitialized === 'true') return;
		root.dataset.productInitialized = 'true';
		if (window.history && window.history.replaceState) {
			window.history.replaceState(null, null, window.location.href);
		}
		const config = window.espressoProductConfig || {};
		const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
		const mainImage = root.querySelector('[data-product-main-image]');
		const stock = root.querySelector('[data-product-stock]');
		const originalImage = mainImage ? {
			src: mainImage.currentSrc || mainImage.src,
			srcset: mainImage.getAttribute('srcset') || '',
			sizes: mainImage.getAttribute('sizes') || '',
			alt: mainImage.alt || '',
		} : null;

		function createRadar(svg, values, animate) {
			if (!svg || !window.EspressoSensoryRadar) return null;
			const profile = { values, color: svg.dataset.color || '#d6b77a', name: svg.dataset.name || document.title };
			const radar = window.EspressoSensoryRadar.create(svg, {
				labels: config.axes || [], values: animate && !reducedMotion ? Array(7).fill(0) : values,
				color: profile.color, name: profile.name, compactLabels: false, reducedMotion,
			});
			if (!animate || reducedMotion) return radar;
			const observer = new IntersectionObserver((entries) => {
				if (!entries[0].isIntersecting) return;
				radar.update(profile, { duration: 850 }); observer.disconnect();
			}, { threshold: 0.35 });
			observer.observe(svg);
			return radar;
		}

		root.querySelectorAll('[data-product-mini-radar]').forEach((svg) => {
			createRadar(svg, JSON.parse(svg.dataset.values || '[]'), false);
			svg.setAttribute('aria-hidden', 'true');
			svg.querySelectorAll('[data-radar-point]').forEach((point) => point.setAttribute('tabindex', '-1'));
		});
		root.querySelectorAll('[data-product-radar]').forEach((svg) => createRadar(svg, JSON.parse(svg.dataset.values || '[]'), true));

		const stageSection = root.querySelector('[data-product-stage]');
		if (stageSection && 'IntersectionObserver' in window) {
			const stageObserver = new IntersectionObserver((entries) => {
				document.body.classList.toggle('ec-product-stage-visible', entries[0].isIntersecting);
			}, { threshold: 0.05, rootMargin: '0px 0px -30% 0px' });
			stageObserver.observe(stageSection);
		}

		const sensorySection = root.querySelector('[data-product-sensory]');
		if (sensorySection && 'IntersectionObserver' in window) {
			const sensoryObserver = new IntersectionObserver((entries) => {
				document.body.classList.toggle('ec-product-sensory-visible', entries[0].isIntersecting);
			}, { threshold: 0.08 });
			sensoryObserver.observe(sensorySection);
		}

		root.querySelectorAll('[data-shop-mini-radar]').forEach((svg) => {
			createRadar(svg, JSON.parse(svg.dataset.values || '[]'), false);
			svg.setAttribute('aria-hidden', 'true');
			svg.querySelectorAll('[data-radar-point]').forEach((point) => point.setAttribute('tabindex', '-1'));
		});

		root.querySelectorAll('[data-product-gallery-thumb]').forEach((button) => {
			button.addEventListener('click', () => {
				if (!mainImage) return;
				mainImage.src = button.dataset.src || mainImage.src;
				if (button.dataset.srcset) mainImage.srcset = button.dataset.srcset;
				mainImage.alt = button.dataset.alt || '';
				root.querySelectorAll('[data-product-gallery-thumb]').forEach((candidate) => {
					const active = candidate === button;
					candidate.classList.toggle('is-active', active);
					candidate.setAttribute('aria-pressed', String(active));
				});
			});
		});

		const variationForm = root.querySelector('form.variations_form');
		if (variationForm && window.jQuery) {
			variationForm.querySelectorAll('select').forEach((select) => {
				const cell = select.closest('td.value') || select.parentElement;
				const chips = document.createElement('div');
				chips.className = 'ec-product-variation-chips';
				chips.dataset.variationChips = select.dataset.attribute_name || select.name;
				[...select.options].filter((option) => option.value).forEach((option) => {
					const chip = document.createElement('button');
					chip.type = 'button'; chip.className = 'ec-product-variation-chip';
					chip.dataset.variationChip = option.value; chip.textContent = option.textContent.trim();
					chip.setAttribute('aria-pressed', String(select.value === option.value));
					chip.disabled = option.disabled;
					chip.addEventListener('click', () => {
						select.value = option.value;
						window.jQuery(select).trigger('change');
					});
					chips.append(chip);
				});
				cell.insertBefore(chips, select);
				cell.classList.add('is-enhanced');
				window.jQuery(select).on('change', () => {
					chips.querySelectorAll('[data-variation-chip]').forEach((chip) => {
						const option = [...select.options].find((candidate) => candidate.value === chip.dataset.variationChip);
						chip.classList.toggle('is-selected', select.value === chip.dataset.variationChip);
						chip.setAttribute('aria-pressed', String(select.value === chip.dataset.variationChip));
						chip.disabled = Boolean(option?.disabled);
					});
				});
			});

			window.jQuery(variationForm).on('found_variation', function (_event, variation) {
				if (stock) {
					stock.classList.toggle('is-in-stock', Boolean(variation.is_in_stock));
					stock.classList.toggle('is-out-of-stock', !variation.is_in_stock);
					stock.lastChild.textContent = variation.is_in_stock ? (config.inStock || 'Disponibile') : (config.outOfStock || 'Non disponibile');
				}
				if (mainImage && variation.image?.src) {
					mainImage.src = variation.image.src;
					mainImage.srcset = variation.image.srcset || '';
					mainImage.sizes = variation.image.sizes || originalImage?.sizes || '';
					mainImage.alt = variation.image.alt || originalImage?.alt || '';
				}
			});
			window.jQuery(variationForm).on('reset_data hide_variation', function () {
				if (mainImage && originalImage) {
					mainImage.src = originalImage.src; mainImage.srcset = originalImage.srcset;
					mainImage.sizes = originalImage.sizes; mainImage.alt = originalImage.alt;
				}
			});
		}

		root.querySelectorAll('[data-product-accordion] button[aria-controls]').forEach((button) => {
			button.addEventListener('click', () => {
				const panel = document.getElementById(button.getAttribute('aria-controls'));
				if (!panel) return;
				const expanded = button.getAttribute('aria-expanded') === 'true';
				button.setAttribute('aria-expanded', String(!expanded));
				button.querySelector('i').textContent = expanded ? '+' : '−';
				panel.hidden = expanded;
			});
		});

		root.querySelectorAll('[data-shop-sensory-toggle]').forEach((button) => {
			button.addEventListener('click', () => {
				const card = button.closest('[data-shop-card]');
				const expanded = button.getAttribute('aria-expanded') === 'true';
				button.setAttribute('aria-expanded', String(!expanded));
				button.setAttribute('aria-label', expanded ? button.dataset.openLabel : button.dataset.closeLabel);
				card.classList.toggle('is-sensory-open', !expanded);
				card.querySelector('[data-shop-sensory-panel]')?.setAttribute('aria-hidden', String(expanded));
			});
		});

		if (!reducedMotion && window.matchMedia('(pointer:fine)').matches) {
			const visual = root.querySelector('[data-product-visual]');
			visual?.addEventListener('pointermove', (event) => {
				const rect = visual.getBoundingClientRect();
				const x = ((event.clientX - rect.left) / rect.width - 0.5) * 10;
				const y = ((event.clientY - rect.top) / rect.height - 0.5) * 8;
				visual.style.setProperty('--ec-product-shift-x', `${x.toFixed(2)}px`);
				visual.style.setProperty('--ec-product-shift-y', `${y.toFixed(2)}px`);
			});
			visual?.addEventListener('pointerleave', () => {
				visual.style.setProperty('--ec-product-shift-x', '0px'); visual.style.setProperty('--ec-product-shift-y', '0px');
			});
		}

		function escapeHtml(str) {
			if (!str) return '';
			const div = document.createElement('div');
			div.textContent = String(str);
			return div.innerHTML;
		}

		function getNoticeWrapper() {
			let wrapper = document.querySelector('.woocommerce-notices-wrapper');
			if (!wrapper) {
				wrapper = document.createElement('div');
				wrapper.className = 'woocommerce-notices-wrapper';
				const primary = document.getElementById('primary') || document.body;
				primary.prepend(wrapper);
			}
			return wrapper;
		}

		function showCartNotice(productName, cartUrl) {
			const wrapper = getNoticeWrapper();
			wrapper.querySelectorAll('.ec-toast-notice').forEach((el) => el.remove());

			const toast = document.createElement('div');
			toast.className = 'woocommerce-message ec-toast-notice';
			toast.setAttribute('role', 'status');

			const strongName = productName ? `&ldquo;<strong>${escapeHtml(productName)}</strong>&rdquo;` : '';
			const noticeText = `${strongName} ${escapeHtml(config.addedNotice || 'è stato aggiunto al carrello.')}`.trim();
			const viewCartText = escapeHtml(config.viewCart || 'Visualizza carrello');
			const targetCartUrl = escapeHtml(cartUrl || config.cartUrl || '/carrello/');

			toast.innerHTML = `
				<button type="button" class="ec-notice-close" aria-label="Chiudi notifica">&times;</button>
				<div class="ec-notice-body">${noticeText}</div>
				<a href="${targetCartUrl}" class="button wc-forward">${viewCartText}</a>
			`;

			function dismiss() {
				if (toast.classList.contains('is-dismissing')) return;
				toast.classList.add('is-dismissing');
				window.setTimeout(() => toast.remove(), 280);
			}

			toast.querySelector('.ec-notice-close')?.addEventListener('click', (e) => {
				e.preventDefault();
				dismiss();
			});

			wrapper.appendChild(toast);
			window.setTimeout(dismiss, 4500);
		}

		function showErrorNotice(errorMessage) {
			const wrapper = getNoticeWrapper();
			wrapper.querySelectorAll('.ec-toast-notice').forEach((el) => el.remove());

			const toast = document.createElement('div');
			toast.className = 'woocommerce-error ec-toast-notice';
			toast.setAttribute('role', 'alert');
			toast.innerHTML = `
				<button type="button" class="ec-notice-close" aria-label="Chiudi notifica">&times;</button>
				<div class="ec-notice-body">${escapeHtml(errorMessage)}</div>
			`;

			function dismiss() {
				if (toast.classList.contains('is-dismissing')) return;
				toast.classList.add('is-dismissing');
				window.setTimeout(() => toast.remove(), 280);
			}

			toast.querySelector('.ec-notice-close')?.addEventListener('click', (e) => {
				e.preventDefault();
				dismiss();
			});

			wrapper.appendChild(toast);
			window.setTimeout(dismiss, 5000);
		}

		const cartForms = root.querySelectorAll('form.cart');
		cartForms.forEach((form) => {
			form.addEventListener('submit', async (e) => {
				const button = form.querySelector('.single_add_to_cart_button');
				if (!button || button.disabled || button.classList.contains('is-loading')) {
					return;
				}

				if (form.classList.contains('variations_form')) {
					const varInput = form.querySelector('input[name="variation_id"]');
					const variationId = varInput ? parseInt(varInput.value, 10) : 0;
					if (!variationId || variationId <= 0) {
						button.classList.add('is-error');
						window.setTimeout(() => button.classList.remove('is-error'), 800);
						showErrorNotice('Seleziona le opzioni desiderate prima di acquistare.');
						e.preventDefault();
						return;
					}
				}

				if (typeof form.checkValidity === 'function' && !form.checkValidity()) {
					return;
				}

				e.preventDefault();

				if (!button.dataset.originalHtml) {
					button.dataset.originalHtml = button.innerHTML;
				}

				button.classList.remove('is-error', 'is-success');
				button.classList.add('is-loading');

				const formData = new FormData(form);
				formData.append('action', 'espressocoppola_add_to_cart');
				if (config.nonce) {
					formData.append('nonce', config.nonce);
				}

				if (!formData.get('product_id')) {
					const submitBtn = form.querySelector('[name="add-to-cart"]');
					if (submitBtn && submitBtn.value) {
						formData.append('product_id', submitBtn.value);
					}
				}

				button.innerHTML = `
					<span class="ec-btn-spinner" aria-hidden="true"></span>
					<span class="ec-btn-text">${escapeHtml(config.adding || 'Aggiunta in corso...')}</span>
				`;

				try {
					const res = await fetch(config.ajaxUrl || '/wp-admin/admin-ajax.php', {
						method: 'POST',
						body: formData,
					});

					const response = await res.json();

					if (response && response.success) {
						window.requestAnimationFrame(() => {
							button.classList.remove('is-loading');
							button.classList.add('is-success');
							button.innerHTML = `
								<span class="ec-btn-text">${escapeHtml(config.added || 'Nel carrello')}</span>
							`;

							const qtyInput = form.querySelector('input.qty');
							const qtyVal = qtyInput ? (parseInt(qtyInput.value, 10) || 1) : 1;
							const floatBadge = document.createElement('span');
							floatBadge.className = 'ec-btn-float-badge';
							floatBadge.textContent = `+${qtyVal}`;
							button.appendChild(floatBadge);
							window.setTimeout(() => floatBadge.remove(), 850);
						});

						const pName = response.data?.product_name || root.querySelector('h1')?.textContent.trim() || '';
						const cUrl = response.data?.cart_url || config.cartUrl;

						showCartNotice(pName, cUrl);

						if (response.data?.cart_count !== undefined) {
							document.querySelectorAll('[data-header-bag-count]').forEach((countEl) => {
								countEl.textContent = String(response.data.cart_count);
							});
							document.querySelectorAll('.ec-header__bag').forEach((bag) => {
								bag.classList.remove('is-updated');
								window.requestAnimationFrame(() => {
									bag.classList.add('is-updated');
								});
							});
						}

						if (window.jQuery) {
							if (response.data?.fragments) {
								window.jQuery(document.body).trigger('added_to_cart', [response.data.fragments, response.data.cart_hash]);
							}
							window.jQuery(document.body).trigger('wc_fragment_refresh');
						}

						// Clean up any WooCommerce default injected link or classes
						form.querySelectorAll('.added_to_cart').forEach((link) => link.remove());
						button.classList.remove('added');

						window.setTimeout(() => {
							const textSpan = button.querySelector('.ec-btn-text');
							if (textSpan) {
								textSpan.style.opacity = '0';
								textSpan.style.transform = 'translateY(3px)';
							}
							window.setTimeout(() => {
								button.classList.remove('is-success');
								button.innerHTML = button.dataset.originalHtml || 'ACQUISTA';
								delete button.dataset.originalHtml;
							}, 160);
						}, 2100);

					} else {
						const errMessage = response?.data?.message || 'Impossibile aggiungere il prodotto al carrello.';
						throw new Error(errMessage);
					}
				} catch (err) {
					button.classList.remove('is-loading');
					button.classList.add('is-error');
					button.innerHTML = button.dataset.originalHtml || 'ACQUISTA';
					delete button.dataset.originalHtml;
					showErrorNotice(err.message || 'Si è verificato un errore.');
					window.setTimeout(() => button.classList.remove('is-error'), 1800);
				}
			});
		});

		// Continuously remove any raw inline "Visualizza carrello" link injected by WooCommerce
		function purgeInlineCartLinks() {
			root.querySelectorAll('.ec-product-stage__cart .added_to_cart, form.cart .added_to_cart, .single_add_to_cart_button + .added_to_cart, a.added_to_cart').forEach((link) => link.remove());
		}
		purgeInlineCartLinks();

		const cartContainer = root.querySelector('.ec-product-stage__cart') || root;
		if ('MutationObserver' in window) {
			const linkObserver = new MutationObserver(() => {
				purgeInlineCartLinks();
			});
			linkObserver.observe(cartContainer, { childList: true, subtree: true });
		}

		if (document.querySelector('.woocommerce-message:not(.ec-toast-notice)')) {
			const button = root.querySelector('.single_add_to_cart_button');
			if (button && !button.disabled) {
				const label = button.textContent; button.textContent = config.added || 'Nel carrello';
				window.setTimeout(() => { button.textContent = label || config.addToCart || 'Aggiungi al carrello'; }, 2200);
			}
		}
	}

	if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initialize, { once: true });
	else initialize();
})();
