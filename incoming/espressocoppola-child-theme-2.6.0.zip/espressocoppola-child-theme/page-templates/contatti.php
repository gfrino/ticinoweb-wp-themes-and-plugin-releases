<?php
/**
 * Template Name: Contatti
 * Template Post Type: page
 *
 * THESIS: contattare Espresso Coppola deve sembrare una conversazione, non un modulo.
 * OWN-WORLD: carta crema, inchiostro espresso, linee champagne e grandi righe editoriali.
 * STORY: invito, riferimenti diretti, luogo, canali disponibili e ritorno alle miscele.
 * FIRST VIEWPORT: manifesto tipografico immobile attraversato da un'orbita lenta.
 * FORM: contact ledger dinamico dal ticinoWEB CMS, senza card corporate né formulari.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$contact      = espressocoppola_get_contact_page_context( get_the_ID() );
$ledger_index = 0;
?>
<main id="primary" class="ec-contact" data-contact-page>
	<section class="ec-contact-hero" aria-labelledby="ec-contact-title">
		<div class="ec-contact-shell ec-contact-hero__inner">
			<div class="ec-contact-hero__copy" data-contact-reveal>
				<p class="ec-contact-kicker"><?php esc_html_e( 'Contatti', 'espressocoppola-child-theme' ); ?></p>
				<h1 id="ec-contact-title">
					<span><?php esc_html_e( 'Parliamo davanti', 'espressocoppola-child-theme' ); ?></span>
					<span><?php esc_html_e( 'a un caffè.', 'espressocoppola-child-theme' ); ?></span>
				</h1>
				<p class="ec-contact-hero__intro"><?php esc_html_e( 'Per informazioni sui prodotti, sugli ordini o sulle collaborazioni, qui trovi i riferimenti diretti di Espresso Coppola.', 'espressocoppola-child-theme' ); ?></p>
				<a class="ec-contact-text-link" href="#riferimenti"><?php esc_html_e( 'Tutti i riferimenti', 'espressocoppola-child-theme' ); ?> <span aria-hidden="true">↓</span></a>
			</div>

			<div class="ec-contact-hero__instrument" data-contact-orbit aria-hidden="true">
				<span class="ec-contact-orbit ec-contact-orbit--outer"></span>
				<span class="ec-contact-orbit ec-contact-orbit--inner"></span>
				<span class="ec-contact-orbit__node"></span>
				<span class="ec-contact-steam"><i></i><i></i><i></i></span>
				<span class="ec-contact-hero__mark">EC</span>
				<span class="ec-contact-hero__micro"><?php echo esc_html( $contact['companyName'] ); ?></span>
			</div>
		</div>
	</section>

	<?php if ( $contact['channels'] || $contact['address'] ) : ?>
		<section id="riferimenti" class="ec-contact-core" aria-labelledby="ec-contact-core-title">
			<div class="ec-contact-shell">
				<header class="ec-contact-section-heading" data-contact-reveal>
					<p class="ec-contact-kicker"><?php esc_html_e( 'Canali diretti', 'espressocoppola-child-theme' ); ?></p>
					<h2 id="ec-contact-core-title"><?php esc_html_e( 'Qui, senza giri di parole.', 'espressocoppola-child-theme' ); ?></h2>
				</header>

				<div class="ec-contact-ledger">
					<?php foreach ( $contact['channels'] as $channel ) : ?>
						<?php $ledger_index++; ?>
						<a class="ec-contact-row" href="<?php echo esc_url( $channel['url'] ); ?>" data-contact-reveal>
							<span class="ec-contact-row__index"><?php echo esc_html( sprintf( '%02d', $ledger_index ) ); ?></span>
							<span class="ec-contact-row__label"><?php echo esc_html( $channel['label'] ); ?></span>
							<strong class="ec-contact-row__value ec-contact-row__value--<?php echo esc_attr( $channel['type'] ); ?>"><?php echo esc_html( $channel['value'] ); ?></strong>
							<span class="ec-contact-row__arrow" aria-hidden="true">↗</span>
						</a>
					<?php endforeach; ?>

					<?php if ( $contact['address'] ) : ?>
						<?php $ledger_index++; ?>
						<a class="ec-contact-row" href="<?php echo esc_url( $contact['mapUrl'] ); ?>" target="_blank" rel="noopener noreferrer" data-contact-reveal>
							<span class="ec-contact-row__index"><?php echo esc_html( sprintf( '%02d', $ledger_index ) ); ?></span>
							<span class="ec-contact-row__label"><?php esc_html_e( 'Sede', 'espressocoppola-child-theme' ); ?></span>
							<strong class="ec-contact-row__value ec-contact-row__value--address"><?php echo esc_html( $contact['address'] ); ?></strong>
							<span class="ec-contact-row__arrow" aria-hidden="true">↗</span>
						</a>
					<?php endif; ?>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( $contact['address'] ) : ?>
		<section class="ec-contact-location" aria-labelledby="ec-contact-location-title">
			<div class="ec-contact-shell ec-contact-location__inner">
				<div class="ec-contact-location__copy" data-contact-reveal>
					<p class="ec-contact-kicker"><?php esc_html_e( 'Dove trovarci', 'espressocoppola-child-theme' ); ?></p>
					<h2 id="ec-contact-location-title"><?php esc_html_e( 'Da qui, verso ogni tazza.', 'espressocoppola-child-theme' ); ?></h2>
				</div>
				<div class="ec-contact-location__address" data-contact-reveal>
					<address><?php echo esc_html( $contact['address'] ); ?></address>
					<a class="ec-contact-button" href="<?php echo esc_url( $contact['mapUrl'] ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Apri in Maps', 'espressocoppola-child-theme' ); ?> <span aria-hidden="true">↗</span></a>
				</div>
				<div class="ec-contact-location__signal" aria-hidden="true">
					<span></span><i></i>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( $contact['socials'] || $contact['hours'] || $contact['hoursNote'] ) : ?>
		<section class="ec-contact-details" aria-labelledby="ec-contact-details-title">
			<div class="ec-contact-shell ec-contact-details__grid">
				<div data-contact-reveal>
					<p class="ec-contact-kicker"><?php esc_html_e( 'Altri riferimenti', 'espressocoppola-child-theme' ); ?></p>
					<h2 id="ec-contact-details-title"><?php esc_html_e( 'Sempre dalla parte giusta della conversazione.', 'espressocoppola-child-theme' ); ?></h2>
				</div>

				<?php if ( $contact['socials'] ) : ?>
					<nav class="ec-contact-socials" aria-label="<?php esc_attr_e( 'Canali social', 'espressocoppola-child-theme' ); ?>" data-contact-reveal>
						<?php foreach ( $contact['socials'] as $social ) : ?>
							<a href="<?php echo esc_url( $social['url'] ); ?>" target="_blank" rel="noopener noreferrer"><span><?php echo esc_html( $social['label'] ); ?></span><i aria-hidden="true">↗</i></a>
						<?php endforeach; ?>
					</nav>
				<?php endif; ?>

				<?php if ( $contact['hours'] || $contact['hoursNote'] ) : ?>
					<div class="ec-contact-hours" data-contact-hours data-contact-reveal>
						<h3><?php esc_html_e( 'Orari', 'espressocoppola-child-theme' ); ?></h3>
						<?php foreach ( $contact['hours'] as $row ) : ?>
							<p><span><?php echo esc_html( $row['label'] ); ?></span><strong><?php echo esc_html( $row['value'] ); ?></strong></p>
						<?php endforeach; ?>
						<?php if ( $contact['hoursNote'] ) : ?><small><?php echo esc_html( $contact['hoursNote'] ); ?></small><?php endif; ?>
					</div>
				<?php endif; ?>
			</div>
		</section>
	<?php endif; ?>

	<section class="ec-contact-closing" aria-labelledby="ec-contact-closing-title">
		<div class="ec-contact-shell ec-contact-closing__inner">
			<div data-contact-reveal>
				<p class="ec-contact-kicker"><?php esc_html_e( 'Essenza Napoletana', 'espressocoppola-child-theme' ); ?></p>
				<h2 id="ec-contact-closing-title"><?php esc_html_e( 'Una miscela inizia da un chicco. Un rapporto, da una conversazione.', 'espressocoppola-child-theme' ); ?></h2>
			</div>
			<div class="ec-contact-closing__actions" data-contact-reveal>
				<?php if ( $contact['shopUrl'] ) : ?><a class="ec-contact-button ec-contact-button--light" href="<?php echo esc_url( $contact['shopUrl'] ); ?>"><?php esc_html_e( 'Scopri i nostri caffè', 'espressocoppola-child-theme' ); ?> <span aria-hidden="true">→</span></a><?php endif; ?>
				<?php if ( $contact['dnaUrl'] ) : ?><a class="ec-contact-text-link ec-contact-text-link--light" href="<?php echo esc_url( $contact['dnaUrl'] ); ?>"><?php esc_html_e( 'Scopri il DNA delle miscele', 'espressocoppola-child-theme' ); ?> <span aria-hidden="true">↗</span></a><?php endif; ?>
			</div>
			<span class="ec-contact-closing__word" aria-hidden="true">ESSENZA</span>
		</div>
	</section>
</main>
<?php get_footer(); ?>
