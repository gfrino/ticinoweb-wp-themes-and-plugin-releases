<?php
/**
 * Template Name: Coffee Exhibition
 * Template Post Type: page
 *
 * THESIS: una galleria CMS diventa un percorso fotografico, non una griglia.
 * OWN-WORLD: carta, espresso, grandi pause e immagini senza cornici decorative.
 * STORY: ingresso, capitoli irregolari, momento sticky, panorama e congedo.
 * FIRST VIEWPORT: titolo essenziale e prima fotografia LCP.
 * FORM: sequenza editoriale server-side, lightbox accessibile come enhancement.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$page_id = get_queried_object_id();
$context = espressocoppola_get_exhibition_page_context( $page_id );
$total   = (int) $context['total'];

/**
 * Render an exhibition image as an accessible lightbox control.
 *
 * @param array<string,mixed> $image Image data.
 * @param string              $role  Visual role.
 * @param bool                $eager Whether this is the LCP image.
 * @return void
 */
$render_image = static function ( $image, $role = 'standard', $eager = false ) {
	$attachment_id = (int) $image['id'];
	$number        = (int) $image['number'];
	$total_images  = (int) $image['total'];
	$size          = in_array( $role, array( 'hero', 'panorama', 'closing' ), true ) ? '2048x2048' : 'large';
	$sizes         = in_array( $role, array( 'hero', 'panorama', 'closing' ), true )
		? '(max-width: 767px) 94vw, (max-width: 1400px) 92vw, 1440px'
		: '(max-width: 767px) 88vw, (max-width: 1100px) 44vw, 680px';
	$attributes    = array(
		'class'    => 'ec-exhibition-photo__image',
		'loading'  => $eager ? 'eager' : 'lazy',
		'decoding' => 'async',
		'sizes'    => $sizes,
	);

	if ( $eager ) {
		$attributes['fetchpriority'] = 'high';
	}
	?>
	<button
		type="button"
		class="ec-exhibition-photo ec-exhibition-photo--<?php echo esc_attr( $role ); ?>"
		data-exhibition-open
		data-index="<?php echo esc_attr( (string) ( $number - 1 ) ); ?>"
		data-full-src="<?php echo esc_url( $image['lightboxUrl'] ); ?>"
		data-full-srcset="<?php echo esc_attr( $image['lightboxSet'] ); ?>"
		data-alt="<?php echo esc_attr( $image['alt'] ); ?>"
		aria-label="<?php echo esc_attr( sprintf( __( 'Apri immagine %1$d di %2$d', 'espressocoppola-child-theme' ), $number, $total_images ) ); ?>"
	>
		<?php echo wp_get_attachment_image( $attachment_id, $size, false, $attributes ); ?>
		<span class="ec-exhibition-photo__number" aria-hidden="true"><?php echo esc_html( sprintf( '%02d', $number ) ); ?></span>
	</button>
	<?php
};
?>

<main id="primary" class="ec-exhibition" data-exhibition-root data-gallery-id="<?php echo esc_attr( (string) $context['galleryId'] ); ?>">
	<?php if ( $context['isEmpty'] ) : ?>
		<section class="ec-exhibition-empty" aria-labelledby="coffee-exhibition-title">
			<p class="ec-exhibition-eyebrow"><?php esc_html_e( 'Espresso Coppola — Essenza Napoletana', 'espressocoppola-child-theme' ); ?></p>
			<h1 id="coffee-exhibition-title"><?php echo esc_html( $context['title'] ); ?></h1>
			<p><?php echo esc_html( $context['intro'] ); ?></p>
			<?php if ( current_user_can( 'upload_files' ) ) : ?>
				<p class="ec-exhibition-empty__admin"><?php esc_html_e( 'La galleria ticinoWEB 58 non contiene immagini valide. Aggiungile o riordinale dal gestore Media Galleries.', 'espressocoppola-child-theme' ); ?></p>
			<?php endif; ?>
			<a class="ec-exhibition-link" href="<?php echo esc_url( $context['shopUrl'] ); ?>"><?php esc_html_e( 'Esplora i caffè', 'espressocoppola-child-theme' ); ?> <span aria-hidden="true">↗</span></a>
		</section>
	<?php else : ?>
		<?php foreach ( $context['sequence'] as $sequence_index => $moment ) : ?>
			<?php
			$type   = sanitize_html_class( $moment['type'] );
			$images = $moment['images'];
			?>
			<?php if ( 'hero' === $type ) : ?>
				<section class="ec-exhibition-hero" aria-labelledby="coffee-exhibition-title">
					<div class="ec-exhibition-hero__copy ec-exhibition-reveal">
						<p class="ec-exhibition-eyebrow"><?php esc_html_e( 'Espresso Coppola — Essenza Napoletana', 'espressocoppola-child-theme' ); ?></p>
						<h1 id="coffee-exhibition-title"><?php echo esc_html( $context['title'] ); ?></h1>
						<p class="ec-exhibition-hero__intro"><?php echo esc_html( $context['intro'] ); ?></p>
						<p class="ec-exhibition-hero__count"><?php echo esc_html( sprintf( _n( '%d immagine', '%d immagini', $total, 'espressocoppola-child-theme' ), $total ) ); ?></p>
					</div>
					<div class="ec-exhibition-hero__visual ec-exhibition-reveal" data-exhibition-parallax="0.035">
						<?php $render_image( $images[0], 'hero', true ); ?>
					</div>
					<a class="ec-exhibition-scroll" href="#percorso"><?php esc_html_e( 'Scorri per esplorare', 'espressocoppola-child-theme' ); ?> <span aria-hidden="true">↓</span></a>
				</section>
				<div id="percorso" class="ec-exhibition-anchor" aria-hidden="true"></div>
			<?php elseif ( 'pause' === $type ) : ?>
				<section class="ec-exhibition-pause ec-exhibition-reveal" aria-label="<?php echo esc_attr( $moment['copy']['eyebrow'] ); ?>">
					<p class="ec-exhibition-eyebrow"><?php echo esc_html( $moment['copy']['eyebrow'] ); ?></p>
					<h2><?php echo esc_html( $moment['copy']['title'] ); ?></h2>
				</section>
			<?php elseif ( 'sticky' === $type ) : ?>
				<section class="ec-exhibition-sticky" data-exhibition-sticky>
					<div class="ec-exhibition-sticky__copy ec-exhibition-reveal">
						<p class="ec-exhibition-eyebrow"><?php esc_html_e( 'Tre istanti', 'espressocoppola-child-theme' ); ?></p>
						<h2><?php esc_html_e( 'Il rituale cambia prospettiva.', 'espressocoppola-child-theme' ); ?></h2>
					</div>
					<div class="ec-exhibition-sticky__stage">
						<?php foreach ( $images as $image_index => $image ) : ?>
							<div class="ec-exhibition-sticky__frame" data-sticky-frame="<?php echo esc_attr( (string) $image_index ); ?>">
								<?php $render_image( $image, 'sticky' ); ?>
							</div>
						<?php endforeach; ?>
					</div>
				</section>
			<?php elseif ( 'closing' === $type ) : ?>
				<section class="ec-exhibition-closing">
					<div class="ec-exhibition-closing__visual ec-exhibition-reveal">
						<?php $render_image( $images[0], 'closing' ); ?>
					</div>
					<div class="ec-exhibition-closing__copy ec-exhibition-reveal">
						<p class="ec-exhibition-eyebrow"><?php esc_html_e( 'Continua il viaggio', 'espressocoppola-child-theme' ); ?></p>
						<h2><?php esc_html_e( 'Dalla visione alla tazza.', 'espressocoppola-child-theme' ); ?></h2>
						<div class="ec-exhibition-closing__links">
							<a class="ec-exhibition-link" href="<?php echo esc_url( $context['shopUrl'] ); ?>"><?php esc_html_e( 'Scopri la collezione', 'espressocoppola-child-theme' ); ?> <span aria-hidden="true">↗</span></a>
							<?php if ( $context['dnaUrl'] ) : ?>
								<a class="ec-exhibition-link ec-exhibition-link--quiet" href="<?php echo esc_url( $context['dnaUrl'] ); ?>"><?php esc_html_e( 'Esplora il DNA', 'espressocoppola-child-theme' ); ?> <span aria-hidden="true">→</span></a>
							<?php endif; ?>
						</div>
					</div>
				</section>
			<?php else : ?>
				<section class="ec-exhibition-moment ec-exhibition-moment--<?php echo esc_attr( $type ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Capitolo fotografico %d', 'espressocoppola-child-theme' ), $sequence_index ) ); ?>">
					<?php foreach ( $images as $image_index => $image ) : ?>
						<div class="ec-exhibition-moment__item ec-exhibition-reveal"<?php echo 0 === $image_index && in_array( $type, array( 'solo', 'suspended', 'panorama', 'cinematic' ), true ) ? ' data-exhibition-parallax="0.022"' : ''; ?>>
							<?php $render_image( $image, $type ); ?>
						</div>
					<?php endforeach; ?>
				</section>
			<?php endif; ?>
		<?php endforeach; ?>
	<?php endif; ?>

	<?php if ( ! $context['isEmpty'] ) : ?>
		<div class="ec-exhibition-lightbox" data-exhibition-lightbox role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( 'Visualizzatore immagini', 'espressocoppola-child-theme' ); ?>" hidden>
			<button type="button" class="ec-exhibition-lightbox__close" data-lightbox-close aria-label="<?php esc_attr_e( 'Chiudi visualizzatore', 'espressocoppola-child-theme' ); ?>">×</button>
			<button type="button" class="ec-exhibition-lightbox__nav ec-exhibition-lightbox__nav--prev" data-lightbox-prev aria-label="<?php esc_attr_e( 'Immagine precedente', 'espressocoppola-child-theme' ); ?>">←</button>
			<figure class="ec-exhibition-lightbox__figure">
				<span class="ec-exhibition-lightbox__image-slot" data-lightbox-image-slot></span>
				<figcaption class="ec-exhibition-lightbox__counter" data-lightbox-counter aria-live="polite"></figcaption>
			</figure>
			<button type="button" class="ec-exhibition-lightbox__nav ec-exhibition-lightbox__nav--next" data-lightbox-next aria-label="<?php esc_attr_e( 'Immagine successiva', 'espressocoppola-child-theme' ); ?>">→</button>
		</div>
	<?php endif; ?>
</main>

<?php get_footer(); ?>
