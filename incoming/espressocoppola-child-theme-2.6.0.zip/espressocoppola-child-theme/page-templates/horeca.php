<?php
/**
 * Template Name: Ho.Re.Ca.
 * Template Post Type: page
 *
 * THESIS: Soluzioni commerciali e fornitura professionale di torrefazione napoletana.
 * MOOD: Espresso Scuro, Crema, Champagne, Tipografia Editoriale, Micro Radar e Form Multi-Step.
 * SECTIONS: Hero, Per chi è pensato, Miscele, Formati, Perché Espresso Coppola, Form 3 Step, Contatti Commerciali.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
$horeca = espressocoppola_get_horeca_page_context( get_the_ID() );
?>
<main id="primary" class="ec-horeca-page" data-horeca-page>

	<!-- =======================================================================
	     01 — HERO HO.RE.CA.
	     ======================================================================= -->
	<section class="ec-horeca-hero" aria-labelledby="ec-horeca-hero-title">
		<div class="ec-horeca-shell ec-horeca-hero__inner">
			<div class="ec-horeca-hero__copy">
				<span class="ec-horeca-kicker">
					<span class="ec-horeca-kicker__dot"></span>
					<?php esc_html_e( 'Ho.Re.Ca. & Canale Professionale', 'espressocoppola-child-theme' ); ?>
				</span>
				<h1 id="ec-horeca-hero-title" class="ec-horeca-hero__title">
					<?php esc_html_e( 'Il caffè Espresso Coppola,', 'espressocoppola-child-theme' ); ?>
					<span><?php esc_html_e( 'per il tuo locale.', 'espressocoppola-child-theme' ); ?></span>
				</h1>
				<p class="ec-horeca-hero__lead">
					<?php esc_html_e( 'Dalla caffetteria tradizionale al ristorante e all\'ospitalità alberghiera: miscele di torrefazione napoletana artigianale calibrate per garantire estrazioni costanti, aroma inconfondibile e crema impeccabile in ogni tazza.', 'espressocoppola-child-theme' ); ?>
				</p>
				<div class="ec-horeca-hero__actions">
					<a href="#richiedi-campione" class="ec-horeca-btn is-primary">
						<?php esc_html_e( 'Richiedi un campione di prova', 'espressocoppola-child-theme' ); ?>
						<span class="ec-arrow" aria-hidden="true">↓</span>
					</a>
					<a href="#miscele" class="ec-horeca-btn is-secondary">
						<?php esc_html_e( 'Esplora le miscele', 'espressocoppola-child-theme' ); ?>
						<span class="ec-arrow" aria-hidden="true">→</span>
					</a>
				</div>
			</div>

			<div class="ec-horeca-hero__visual" aria-hidden="true">
				<div class="ec-horeca-hero__orbit"></div>
				<div class="ec-horeca-hero__badge-card">
					<span class="ec-horeca-badge-tag"><?php esc_html_e( 'Qualità Professionale', 'espressocoppola-child-theme' ); ?></span>
					<strong><?php esc_html_e( '100% Torrefazione Napoletana', 'espressocoppola-child-theme' ); ?></strong>
					<small><?php esc_html_e( 'Curve di tostatura a caldo uniforme', 'espressocoppola-child-theme' ); ?></small>
				</div>
				<div class="ec-horeca-hero__pill-stat">
					<span class="ec-horeca-pill-num">6+</span>
					<span class="ec-horeca-pill-lbl"><?php esc_html_e( 'Sistemi & Formati compatibili', 'espressocoppola-child-theme' ); ?></span>
				</div>
			</div>
		</div>
	</section>

	<!-- =======================================================================
	     02 — PER CHI È PENSATO
	     ======================================================================= -->
	<section class="ec-horeca-audiences" aria-labelledby="ec-audiences-title">
		<div class="ec-horeca-shell">
			<div class="ec-horeca-section-header">
				<span class="ec-horeca-section-eyebrow"><?php esc_html_e( 'Settori & Attività', 'espressocoppola-child-theme' ); ?></span>
				<h2 id="ec-audiences-title" class="ec-horeca-section-title">
					<?php esc_html_e( 'Pensato per chi serve caffè ogni giorno.', 'espressocoppola-child-theme' ); ?>
				</h2>
				<p class="ec-horeca-section-subtitle">
					<?php esc_html_e( 'Che tu gestisca un banco bar ad alta rotazione, una sala ristorante raffinata o una struttura ricettiva, offriamo la miscela e il formato ideale per il tuo ritmo operativo.', 'espressocoppola-child-theme' ); ?>
				</p>
			</div>

			<div class="ec-horeca-audiences__grid">
				<?php foreach ( $horeca['audiences'] as $aud ) : ?>
					<article class="ec-horeca-aud-card">
						<div class="ec-horeca-aud-card__top">
							<span class="ec-horeca-aud-card__num"><?php echo esc_html( $aud['num'] ); ?></span>
							<span class="ec-horeca-aud-card__tag"><?php echo esc_html( $aud['tag'] ); ?></span>
						</div>
						<h3 class="ec-horeca-aud-card__title"><?php echo esc_html( $aud['title'] ); ?></h3>
						<h4 class="ec-horeca-aud-card__subtitle"><?php echo esc_html( $aud['subtitle'] ); ?></h4>
						<p class="ec-horeca-aud-card__desc"><?php echo esc_html( $aud['desc'] ); ?></p>
					</article>
				<?php endforeach; ?>
			</div>
		</div>
	</section>

	<!-- =======================================================================
	     03 — MISCELE PER IL PROFESSIONALE
	     ======================================================================= -->
	<section id="miscele" class="ec-horeca-blends" aria-labelledby="ec-blends-title">
		<div class="ec-horeca-shell">
			<div class="ec-horeca-section-header">
				<span class="ec-horeca-section-eyebrow"><?php esc_html_e( 'Il Cuore del Nostro Caffè', 'espressocoppola-child-theme' ); ?></span>
				<h2 id="ec-blends-title" class="ec-horeca-section-title">
					<?php esc_html_e( 'Le miscele per il tuo servizio.', 'espressocoppola-child-theme' ); ?>
				</h2>
				<p class="ec-horeca-section-subtitle">
					<?php esc_html_e( 'Profili sensoriali equilibrati, note tostate armoniose e cremosità densa: scopri il carattere di ciascuna miscela prima di richiedere il campione.', 'espressocoppola-child-theme' ); ?>
				</p>
			</div>

			<div class="ec-horeca-blends-accordion" data-accordion-blends>
				<?php foreach ( $horeca['sampleBlends'] as $b_idx => $blend ) : ?>
					<div class="ec-horeca-accordion-card <?php echo 0 === $b_idx ? 'is-active' : ''; ?>" data-accordion-item="<?php echo esc_attr( $blend['slug'] ); ?>" tabindex="0" role="button" aria-expanded="<?php echo 0 === $b_idx ? 'true' : 'false'; ?>" aria-label="<?php echo esc_attr( $blend['name'] ); ?>">

						<!-- COLLAPSED SPINE (Visible on compact state / desktop, header on mobile) -->
						<div class="ec-accordion-spine">
							<span class="ec-accordion-spine__index">0<?php echo (int) ( $b_idx + 1 ); ?></span>
							<div class="ec-accordion-spine__meta">
								<span class="ec-accordion-spine__kicker"><?php echo esc_html( ! empty( $blend['kicker'] ) ? $blend['kicker'] : __( 'Miscela Espresso', 'espressocoppola-child-theme' ) ); ?></span>
								<h3 class="ec-accordion-spine__name"><?php echo esc_html( $blend['name'] ); ?></h3>
							</div>
							<div class="ec-accordion-spine__toggle">
								<span class="ec-accordion-icon" aria-hidden="true">+</span>
							</div>
						</div>

						<!-- EXPANDED CONTENT PANEL -->
						<div class="ec-accordion-body">
							<div class="ec-accordion-body__inner">
								<div class="ec-accordion-body__top">
									<div class="ec-accordion-body__headings">
										<span class="ec-horeca-blend-card__kicker"><?php echo esc_html( ! empty( $blend['kicker'] ) ? $blend['kicker'] : __( 'Miscela Espresso', 'espressocoppola-child-theme' ) ); ?></span>
										<h3 class="ec-accordion-body__title"><?php echo esc_html( $blend['name'] ); ?></h3>
									</div>
									<div class="ec-horeca-blend-card__intensity" title="<?php printf( esc_attr__( 'Intensità aromatica: %d su 5', 'espressocoppola-child-theme' ), $blend['intensity'] ); ?>">
										<span class="ec-horeca-intensity-lbl"><?php esc_html_e( 'Intensità', 'espressocoppola-child-theme' ); ?></span>
										<div class="ec-horeca-intensity-dots">
											<?php for ( $i = 1; $i <= 5; $i++ ) : ?>
												<span class="ec-dot <?php echo $i <= $blend['intensity'] ? 'is-active' : ''; ?>"></span>
											<?php endfor; ?>
										</div>
									</div>
								</div>

								<p class="ec-accordion-body__desc"><?php echo esc_html( $blend['description'] ); ?></p>

								<?php if ( ! empty( $blend['sensory'] ) ) : ?>
									<div class="ec-horeca-blend-card__sensory-bar">
										<?php
										$axes_labels = array(
											'body'        => __( 'Corpo', 'espressocoppola-child-theme' ),
											'persistence' => __( 'Persistenza', 'espressocoppola-child-theme' ),
											'roast'       => __( 'Tostato', 'espressocoppola-child-theme' ),
											'sweetness'   => __( 'Dolcezza', 'espressocoppola-child-theme' ),
										);
										foreach ( $axes_labels as $axis_key => $axis_name ) :
											$score = isset( $blend['sensory'][ $axis_key ] ) ? (int) $blend['sensory'][ $axis_key ] : 3;
											?>
											<div class="ec-horeca-sensory-pill">
												<span class="ec-sensory-name"><?php echo esc_html( $axis_name ); ?></span>
												<span class="ec-sensory-val"><?php echo esc_html( $score ); ?>/5</span>
											</div>
										<?php endforeach; ?>
									</div>
								<?php endif; ?>

								<div class="ec-accordion-body__footer">
									<a href="#richiedi-campione" class="ec-horeca-choose-sample-btn" data-preselect-blend="<?php echo esc_attr( $blend['slug'] ); ?>">
										<?php esc_html_e( 'Richiedi questo campione', 'espressocoppola-child-theme' ); ?> <span>→</span>
									</a>
								</div>
							</div>
						</div>

					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</section>

	<!-- =======================================================================
	     04 — RICHIEDI UN CAMPIONE & CONTATTI DIRETTI (2-COLUMN GRID)
	     ======================================================================= -->
	<section id="richiedi-campione" class="ec-horeca-sample-section" aria-labelledby="ec-sample-form-title">

		<!-- Animated Ambient Aurora Mesh & Glowing Filaments (Gemini / Apple Luxury Effect) -->
		<div class="ec-horeca-ambient-layer" aria-hidden="true">
			<!-- Glowing top divider beam / filament -->
			<div class="ec-ambient-beam"></div>
			<div class="ec-ambient-beam-glow"></div>

			<!-- Floating Aurora Glow Orbs (8 halos distributed across screen) -->
			<div class="ec-ambient-orb is-bordeaux is-bordeaux-top"></div>
			<div class="ec-ambient-orb is-gold is-gold-top"></div>
			<div class="ec-ambient-orb is-amber is-amber-mid"></div>
			<div class="ec-ambient-orb is-bordeaux is-bordeaux-mid"></div>
			<div class="ec-ambient-orb is-terracotta is-terracotta-low"></div>
			<div class="ec-ambient-orb is-gold is-gold-bottom"></div>
			<div class="ec-ambient-orb is-amber is-amber-bottom"></div>
			<div class="ec-ambient-orb is-champagne-center"></div>

			<!-- Ethereal flowing filament waves (distributed across top, middle, and bottom) -->
			<svg class="ec-ambient-filaments" viewBox="0 0 1440 1000" fill="none" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none">
				<!-- Upper filaments -->
				<path class="ec-filament ec-filament-1" d="M-100 130 C 300 290, 700 -30, 1100 190 C 1300 300, 1500 160, 1600 210" stroke="url(#coppola-grad-1)" stroke-width="2.5" stroke-linecap="round" />
				<path class="ec-filament ec-filament-2" d="M-100 270 C 250 90, 650 370, 1050 150 C 1300 50, 1500 230, 1600 190" stroke="url(#coppola-grad-2)" stroke-width="2" stroke-linecap="round" />
				<!-- Middle filaments -->
				<path class="ec-filament ec-filament-3" d="M-100 420 C 360 240, 760 500, 1160 280 C 1360 190, 1500 340, 1600 320" stroke="url(#coppola-grad-3)" stroke-width="2.2" stroke-linecap="round" />
				<path class="ec-filament ec-filament-4" d="M-100 560 C 280 720, 680 430, 1080 620 C 1280 710, 1480 540, 1600 590" stroke="url(#coppola-grad-4)" stroke-width="2.4" stroke-linecap="round" />
				<!-- Lower & Bottom filaments -->
				<path class="ec-filament ec-filament-5" d="M-100 710 C 260 540, 660 830, 1060 610 C 1280 500, 1480 690, 1600 660" stroke="url(#coppola-grad-1)" stroke-width="2.2" stroke-linecap="round" />
				<path class="ec-filament ec-filament-6" d="M-100 840 C 340 690, 740 930, 1140 750 C 1340 660, 1500 820, 1600 790" stroke="url(#coppola-grad-2)" stroke-width="2.6" stroke-linecap="round" />
				<path class="ec-filament ec-filament-7" d="M-100 930 C 290 810, 690 970, 1090 850 C 1300 770, 1500 910, 1600 880" stroke="url(#coppola-grad-5)" stroke-width="2" stroke-linecap="round" />
				<defs>
					<linearGradient id="coppola-grad-1" x1="0%" y1="0%" x2="100%" y2="0%">
						<stop offset="0%" stop-color="#c89d54" stop-opacity="0" />
						<stop offset="25%" stop-color="#c89d54" stop-opacity="0.65" />
						<stop offset="60%" stop-color="#8B263E" stop-opacity="0.8" />
						<stop offset="85%" stop-color="#e0b870" stop-opacity="0.55" />
						<stop offset="100%" stop-color="#8B263E" stop-opacity="0" />
					</linearGradient>
					<linearGradient id="coppola-grad-2" x1="0%" y1="0%" x2="100%" y2="0%">
						<stop offset="0%" stop-color="#8B263E" stop-opacity="0" />
						<stop offset="30%" stop-color="#8B263E" stop-opacity="0.6" />
						<stop offset="70%" stop-color="#c89d54" stop-opacity="0.7" />
						<stop offset="100%" stop-color="#c89d54" stop-opacity="0" />
					</linearGradient>
					<linearGradient id="coppola-grad-3" x1="0%" y1="0%" x2="100%" y2="0%">
						<stop offset="0%" stop-color="#c89d54" stop-opacity="0" />
						<stop offset="45%" stop-color="#c89d54" stop-opacity="0.5" />
						<stop offset="80%" stop-color="#8B263E" stop-opacity="0.5" />
						<stop offset="100%" stop-color="#8B263E" stop-opacity="0" />
					</linearGradient>
					<linearGradient id="coppola-grad-4" x1="0%" y1="0%" x2="100%" y2="0%">
						<stop offset="0%" stop-color="#a8402d" stop-opacity="0" />
						<stop offset="35%" stop-color="#a8402d" stop-opacity="0.6" />
						<stop offset="65%" stop-color="#c89d54" stop-opacity="0.65" />
						<stop offset="100%" stop-color="#8B263E" stop-opacity="0" />
					</linearGradient>
					<linearGradient id="coppola-grad-5" x1="0%" y1="0%" x2="100%" y2="0%">
						<stop offset="0%" stop-color="#c89d54" stop-opacity="0" />
						<stop offset="30%" stop-color="#e0b870" stop-opacity="0.6" />
						<stop offset="75%" stop-color="#8B263E" stop-opacity="0.55" />
						<stop offset="100%" stop-color="#c89d54" stop-opacity="0" />
					</linearGradient>
				</defs>
			</svg>
		</div>

		<div class="ec-horeca-shell">
			<div class="ec-horeca-interactive-grid">

				<!-- LEFT / MAIN COLUMN: FORMULARIO GUIDATO 3-STEP (75%) -->
				<div class="ec-horeca-sample-box">

					<!-- Form Header -->
					<div class="ec-horeca-sample-header">
						<span class="ec-horeca-section-eyebrow"><?php esc_html_e( 'Campionatura Professionale', 'espressocoppola-child-theme' ); ?></span>
						<h2 id="ec-sample-form-title" class="ec-horeca-sample-title">
							<?php esc_html_e( 'Richiedi un campione.', 'espressocoppola-child-theme' ); ?>
						</h2>
						<p class="ec-horeca-sample-subtitle">
							<?php esc_html_e( 'Compila il formulario guidato in 3 rapidi passaggi per ricevere la campionatura adatta alla tua attività e provarla direttamente nel tuo locale.', 'espressocoppola-child-theme' ); ?>
						</p>

						<!-- Progress Indicator -->
						<div class="ec-horeca-progress" role="progressbar" aria-valuenow="1" aria-valuemin="1" aria-valuemax="3" aria-label="<?php esc_attr_e( 'Avanzamento formulario', 'espressocoppola-child-theme' ); ?>">
							<div class="ec-horeca-progress-step is-active" data-step-indicator="1">
								<span class="ec-progress-badge">01</span>
								<span class="ec-progress-label"><?php esc_html_e( 'La tua attività', 'espressocoppola-child-theme' ); ?></span>
							</div>
							<div class="ec-horeca-progress-line"></div>
							<div class="ec-horeca-progress-step" data-step-indicator="2">
								<span class="ec-progress-badge">02</span>
								<span class="ec-progress-label"><?php esc_html_e( 'Il tuo consumo', 'espressocoppola-child-theme' ); ?></span>
							</div>
							<div class="ec-horeca-progress-line"></div>
							<div class="ec-horeca-progress-step" data-step-indicator="3">
								<span class="ec-progress-badge">03</span>
								<span class="ec-progress-label"><?php esc_html_e( 'Il campione & recapito', 'espressocoppola-child-theme' ); ?></span>
							</div>
						</div>
					</div>

					<!-- Multi-step Form -->
					<form id="ec-horeca-sample-form" class="ec-horeca-form" novalidate>
						<input type="hidden" name="action" value="espressocoppola_submit_horeca_sample">
						<input type="hidden" name="nonce" value="<?php echo esc_attr( $horeca['nonce'] ); ?>">

						<!-- Invisible Honeypot field for bots -->
						<div class="ec-horeca-hp" aria-hidden="true" style="display: none !important; opacity: 0; position: absolute; left: -9999px;">
							<label for="hp_coppola_field">Non compilare questo campo</label>
							<input type="text" name="hp_coppola_field" id="hp_coppola_field" tabindex="-1" autocomplete="off">
						</div>

						<!-- Error Alert Box -->
						<div id="ec-horeca-form-errors" class="ec-horeca-form-alert is-error" hidden role="alert"></div>

						<!-- STEP 01: LA TUA ATTIVITÀ -->
						<div class="ec-horeca-step is-active" data-form-step="1">
							<div class="ec-horeca-step__heading">
								<h3><?php esc_html_e( '01 / 03 — Dati dell\'attività', 'espressocoppola-child-theme' ); ?></h3>
								<p><?php esc_html_e( 'Indica i riferimenti della tua struttura o azienda.', 'espressocoppola-child-theme' ); ?></p>
							</div>

							<div class="ec-horeca-fields-grid">
								<div class="ec-horeca-field is-full">
									<label for="ec_company"><?php esc_html_e( 'Ragione Sociale / Denominazione *', 'espressocoppola-child-theme' ); ?></label>
									<input type="text" name="company" id="ec_company" required placeholder="<?php esc_attr_e( 'Es. Bar Caffè Centrale S.r.l.', 'espressocoppola-child-theme' ); ?>">
								</div>

								<div class="ec-horeca-field">
									<label for="ec_first_name"><?php esc_html_e( 'Nome referente *', 'espressocoppola-child-theme' ); ?></label>
									<input type="text" name="first_name" id="ec_first_name" required placeholder="<?php esc_attr_e( 'Mario', 'espressocoppola-child-theme' ); ?>">
								</div>

								<div class="ec-horeca-field">
									<label for="ec_last_name"><?php esc_html_e( 'Cognome referente *', 'espressocoppola-child-theme' ); ?></label>
									<input type="text" name="last_name" id="ec_last_name" required placeholder="<?php esc_attr_e( 'Rossi', 'espressocoppola-child-theme' ); ?>">
								</div>

								<div class="ec-horeca-field is-full">
									<label class="ec-label-selector"><?php esc_html_e( 'Tipologia attività *', 'espressocoppola-child-theme' ); ?></label>
									<div class="ec-horeca-pills-selector" role="radiogroup" aria-label="<?php esc_attr_e( 'Tipologia attività', 'espressocoppola-child-theme' ); ?>">
										<?php
										$types = array( 'Bar', 'Ristorante', 'Hotel', 'B&B', 'Catering', 'Ufficio', 'Altro' );
										foreach ( $types as $i => $type_item ) :
											?>
											<label class="ec-pill-option">
												<input type="radio" name="activity_type" value="<?php echo esc_attr( $type_item ); ?>" <?php checked( $i, 0 ); ?> required>
												<span class="ec-pill-box"><?php echo esc_html( $type_item ); ?></span>
											</label>
										<?php endforeach; ?>
									</div>
								</div>

								<div id="ec-activity-other-wrap" class="ec-horeca-field is-full" style="display: none;">
									<label for="ec_activity_other"><?php esc_html_e( 'Specifica tipologia attività *', 'espressocoppola-child-theme' ); ?></label>
									<input type="text" name="activity_other" id="ec_activity_other" placeholder="<?php esc_attr_e( 'Es. Coworking, Pasticceria, Stabilimento balneare...', 'espressocoppola-child-theme' ); ?>">
								</div>

								<div class="ec-horeca-field">
									<label for="ec_city"><?php esc_html_e( 'Città sede *', 'espressocoppola-child-theme' ); ?></label>
									<input type="text" name="city" id="ec_city" required placeholder="<?php esc_attr_e( 'Milano', 'espressocoppola-child-theme' ); ?>">
								</div>

								<div class="ec-horeca-field">
									<label for="ec_postal_code"><?php esc_html_e( 'CAP *', 'espressocoppola-child-theme' ); ?></label>
									<input type="text" name="postal_code" id="ec_postal_code" required placeholder="<?php esc_attr_e( '20121', 'espressocoppola-child-theme' ); ?>">
								</div>

								<div class="ec-horeca-field is-full">
									<label for="ec_website"><?php esc_html_e( 'Sito web / Pagina social (facoltativo)', 'espressocoppola-child-theme' ); ?></label>
									<input type="text" name="website" id="ec_website" placeholder="<?php esc_attr_e( 'https://www.tuolocale.it', 'espressocoppola-child-theme' ); ?>">
								</div>
							</div>

							<div class="ec-horeca-step__actions is-end">
								<button type="button" class="ec-horeca-btn is-primary" data-next-step="2">
									<?php esc_html_e( 'Continua al passo 2', 'espressocoppola-child-theme' ); ?>
									<span class="ec-arrow" aria-hidden="true">→</span>
								</button>
							</div>
						</div>

						<!-- STEP 02: IL TUO CONSUMO & SISTEMA -->
						<div class="ec-horeca-step" data-form-step="2" hidden>
							<div class="ec-horeca-step__heading">
								<h3><?php esc_html_e( '02 / 03 — Consumo e Sistema di preparazione', 'espressocoppola-child-theme' ); ?></h3>
								<p><?php esc_html_e( 'Aiutaci a dimensionare l\'offerta ideale per la tua struttura.', 'espressocoppola-child-theme' ); ?></p>
							</div>

							<div class="ec-horeca-fields-grid">
								<div class="ec-horeca-field is-full">
									<label class="ec-label-selector"><?php esc_html_e( 'Quantitativo medio mensile stimato *', 'espressocoppola-child-theme' ); ?></label>
									<div class="ec-horeca-pills-selector is-grid" role="radiogroup" aria-label="<?php esc_attr_e( 'Quantitativo mensile', 'espressocoppola-child-theme' ); ?>">
										<?php
										$volumes = array(
											'< 5 kg / mese (Piccoli uffici o B&B)',
											'5 – 15 kg / mese (Uffici medi, bistrot)',
											'15 – 30 kg / mese (Bar, ristoranti attivi)',
											'30 – 50 kg / mese (Locali ad alto passaggio)',
											'> 50 kg / mese (Grandi strutture, hotel, catering)',
										);
										foreach ( $volumes as $v_i => $vol_item ) :
											?>
											<label class="ec-pill-option is-block">
												<input type="radio" name="monthly_volume" value="<?php echo esc_attr( $vol_item ); ?>" <?php checked( $v_i, 1 ); ?> required>
												<span class="ec-pill-box"><?php echo esc_html( $vol_item ); ?></span>
											</label>
										<?php endforeach; ?>
									</div>
								</div>

								<div class="ec-horeca-field is-full">
									<label class="ec-label-selector"><?php esc_html_e( 'Sistema caffè utilizzato o desiderato *', 'espressocoppola-child-theme' ); ?></label>
									<div class="ec-horeca-pills-selector is-grid" role="radiogroup" aria-label="<?php esc_attr_e( 'Sistema caffè', 'espressocoppola-child-theme' ); ?>">
										<?php
										$systems_options = array(
											'Caffè in grani (Macchina bar / Macinacaffè professionale)',
											'Cialde in carta ESE 44 mm compostabili',
											'Capsule compatibili Nespresso®*',
											'Capsule compatibili Nescafé® Dolce Gusto®*',
											'Capsule compatibili Lavazza® A Modo Mio®*',
											'Caffè macinato per Moka / Filtro',
											'Valuto una nuova macchina professionale in comodato',
										);
										foreach ( $systems_options as $s_i => $sys_item ) :
											?>
											<label class="ec-pill-option is-block">
												<input type="radio" name="coffee_system" value="<?php echo esc_attr( $sys_item ); ?>" <?php checked( $s_i, 0 ); ?> required>
												<span class="ec-pill-box"><?php echo esc_html( $sys_item ); ?></span>
											</label>
										<?php endforeach; ?>
									</div>
								</div>
							</div>

							<div class="ec-horeca-step__actions">
								<button type="button" class="ec-horeca-btn is-secondary" data-prev-step="1">
									<span class="ec-arrow" aria-hidden="true">←</span>
									<?php esc_html_e( 'Torna indietro', 'espressocoppola-child-theme' ); ?>
								</button>
								<button type="button" class="ec-horeca-btn is-primary" data-next-step="3">
									<?php esc_html_e( 'Continua al passo 3', 'espressocoppola-child-theme' ); ?>
									<span class="ec-arrow" aria-hidden="true">→</span>
								</button>
							</div>
						</div>

						<!-- STEP 03: SCELTA CAMPIONE & SPEDIZIONE -->
						<div class="ec-horeca-step" data-form-step="3" hidden>
							<div class="ec-horeca-step__heading">
								<h3><?php esc_html_e( '03 / 03 — Miscela campione e indirizzo di prova', 'espressocoppola-child-theme' ); ?></h3>
								<p><?php esc_html_e( 'Scegli la miscela che desideri testare e inserisci i recapiti per la spedizione del campione.', 'espressocoppola-child-theme' ); ?></p>
							</div>

							<!-- Selection of sample blend -->
							<div class="ec-horeca-field is-full ec-horeca-sample-blend-field">
								<label class="ec-label-selector"><?php esc_html_e( 'Seleziona la miscela da provare *', 'espressocoppola-child-theme' ); ?></label>
								<div class="ec-horeca-sample-selector-grid" role="radiogroup" aria-label="<?php esc_attr_e( 'Miscela campione', 'espressocoppola-child-theme' ); ?>">
									<?php foreach ( $horeca['sampleBlends'] as $b_idx => $b_opt ) : ?>
										<label class="ec-sample-radio-card">
											<input type="radio" name="sample_blend" value="<?php echo esc_attr( $b_opt['name'] ); ?>" data-blend-slug="<?php echo esc_attr( $b_opt['slug'] ); ?>" data-product-id="<?php echo esc_attr( $b_opt['productId'] ); ?>" <?php checked( $b_idx, 0 ); ?> required>
											<span class="ec-sample-radio-inner">
												<span class="ec-sample-radio-title"><?php echo esc_html( $b_opt['name'] ); ?></span>
												<span class="ec-sample-radio-intensity"><?php printf( esc_html__( 'Intensità: %d/5', 'espressocoppola-child-theme' ), $b_opt['intensity'] ); ?></span>
											</span>
										</label>
									<?php endforeach; ?>
								</div>
								<input type="hidden" name="sample_product_id" id="ec_sample_product_id" value="<?php echo esc_attr( $horeca['sampleBlends'][0]['productId'] ?? 0 ); ?>">
							</div>

							<div class="ec-horeca-fields-grid">
								<div class="ec-horeca-field">
									<label for="ec_email"><?php esc_html_e( 'Email aziendale di contatto *', 'espressocoppola-child-theme' ); ?></label>
									<input type="email" name="email" id="ec_email" required placeholder="<?php esc_attr_e( 'info@tuolocale.it', 'espressocoppola-child-theme' ); ?>">
								</div>

								<div class="ec-horeca-field">
									<label for="ec_phone"><?php esc_html_e( 'Telefono referente / locale *', 'espressocoppola-child-theme' ); ?></label>
									<input type="tel" name="phone" id="ec_phone" required placeholder="<?php esc_attr_e( '+39 02 1234567', 'espressocoppola-child-theme' ); ?>">
								</div>

								<div class="ec-horeca-field is-full">
									<label for="ec_shipping_address"><?php esc_html_e( 'Indirizzo completo per la consegna del campione *', 'espressocoppola-child-theme' ); ?></label>
									<input type="text" name="shipping_address" id="ec_shipping_address" required placeholder="<?php esc_attr_e( 'Via / Piazza, Civico', 'espressocoppola-child-theme' ); ?>">
								</div>

								<div class="ec-horeca-field">
									<label for="ec_shipping_postal_code"><?php esc_html_e( 'CAP Consegna *', 'espressocoppola-child-theme' ); ?></label>
									<input type="text" name="shipping_postal_code" id="ec_shipping_postal_code" required placeholder="<?php esc_attr_e( '20121', 'espressocoppola-child-theme' ); ?>">
								</div>

								<div class="ec-horeca-field">
									<label for="ec_shipping_city"><?php esc_html_e( 'Città Consegna *', 'espressocoppola-child-theme' ); ?></label>
									<input type="text" name="shipping_city" id="ec_shipping_city" required placeholder="<?php esc_attr_e( 'Milano', 'espressocoppola-child-theme' ); ?>">
								</div>

								<div class="ec-horeca-field is-full">
									<label for="ec_shipping_country"><?php esc_html_e( 'Nazione *', 'espressocoppola-child-theme' ); ?></label>
									<input type="text" name="shipping_country" id="ec_shipping_country" value="Italia" required>
								</div>

								<div class="ec-horeca-field is-full">
									<label for="ec_notes"><?php esc_html_e( 'Note o richieste specifiche (facoltativo)', 'espressocoppola-child-theme' ); ?></label>
									<textarea name="notes" id="ec_notes" rows="3" placeholder="<?php esc_attr_e( 'Es. Richiesta fornitura mista, tipo di macina utilizzata, preferenze orario consegna...', 'espressocoppola-child-theme' ); ?>"></textarea>
								</div>

								<div class="ec-horeca-field is-full">
									<label class="ec-checkbox-label">
										<input type="checkbox" name="privacy_consent" id="ec_privacy_consent" value="1" required>
										<span>
											<?php
											printf(
												/* translators: %s: privacy policy URL */
												__( 'Ho letto e accetto l\'<a href="%s" target="_blank" rel="noopener">Informativa sulla Privacy</a> e acconsento al trattamento dei dati per la gestione della richiesta di campionatura professionale.', 'espressocoppola-child-theme' ),
												esc_url( $horeca['privacyUrl'] )
											);
											?>
										</span>
									</label>
								</div>
							</div>

							<div class="ec-horeca-step__actions">
								<button type="button" class="ec-horeca-btn is-secondary" data-prev-step="2">
									<span class="ec-arrow" aria-hidden="true">←</span>
									<?php esc_html_e( 'Torna indietro', 'espressocoppola-child-theme' ); ?>
								</button>
								<button type="submit" id="ec-horeca-submit-btn" class="ec-horeca-btn is-primary">
									<span class="ec-btn-text"><?php esc_html_e( 'Invia richiesta campione gratuito', 'espressocoppola-child-theme' ); ?></span>
									<span class="ec-btn-loading" style="display: none;"><span class="ec-spinner" aria-hidden="true"></span> <?php esc_html_e( 'Elaborazione in corso...', 'espressocoppola-child-theme' ); ?></span>
									<span class="ec-arrow" aria-hidden="true">↗</span>
								</button>
							</div>
						</div>

					</form>

					<!-- Success Message Box (Inline, accessible, elegant) -->
					<div id="ec-horeca-success-box" class="ec-horeca-success-box" hidden>
						<div class="ec-horeca-success-icon" aria-hidden="true">✓</div>
						<h3 class="ec-horeca-success-title"><?php esc_html_e( 'Richiesta ricevuta con successo.', 'espressocoppola-child-theme' ); ?></h3>
						<p class="ec-horeca-success-message">
							<?php esc_html_e( 'Grazie. Abbiamo registrato la tua richiesta di campione per il canale Ho.Re.Ca. Il nostro team commerciale esaminerà i dati indicati e si metterà in contatto con te per organizzare la prova.', 'espressocoppola-child-theme' ); ?>
						</p>
						<div class="ec-horeca-success-actions">
							<a href="<?php echo esc_url( $horeca['shopUrl'] ); ?>" class="ec-horeca-btn is-primary">
								<?php esc_html_e( 'Scopri la collezione completa', 'espressocoppola-child-theme' ); ?>
								<span class="ec-arrow" aria-hidden="true">↗</span>
							</a>
						</div>
					</div>

				</div>

				<!-- RIGHT / SIDEBAR COLUMN: CONTATTI COMMERCIALI DIRETTI (25%) -->
				<aside class="ec-horeca-sidebar-contact" aria-labelledby="ec-direct-contact-title">
					<div class="ec-horeca-sidebar-card">
						<div class="ec-horeca-sidebar-card__header">
							<span class="ec-horeca-kicker">
								<span class="ec-horeca-kicker__dot"></span>
								<?php esc_html_e( 'Canale Diretto', 'espressocoppola-child-theme' ); ?>
							</span>
							<h2 id="ec-direct-contact-title" class="ec-horeca-sidebar-card__title">
								<?php esc_html_e( 'Preferisci un contatto commerciale diretto?', 'espressocoppola-child-theme' ); ?>
							</h2>
							<p class="ec-horeca-sidebar-card__desc">
								<?php esc_html_e( 'Se desideri una consulenza immediata per forniture speciali, accordi continuativi o informazioni tecniche, siamo a tua completa disposizione.', 'espressocoppola-child-theme' ); ?>
							</p>
						</div>

						<div class="ec-horeca-sidebar-card__items">
							<?php if ( ! empty( $horeca['contact']['phone'] ) ) : ?>
								<a href="<?php echo esc_url( 'tel:' . $horeca['contact']['phone'] ); ?>" class="ec-horeca-contact-card is-phone">
									<span class="ec-contact-card__label"><?php esc_html_e( 'Telefono Commerciale', 'espressocoppola-child-theme' ); ?></span>
									<strong class="ec-contact-card__value"><?php echo esc_html( $horeca['contact']['phone'] ); ?></strong>
									<span class="ec-contact-card__action"><?php esc_html_e( 'Chiama ora', 'espressocoppola-child-theme' ); ?> ↗</span>
								</a>
							<?php endif; ?>

							<?php if ( ! empty( $horeca['contact']['email'] ) ) : ?>
								<a href="<?php echo esc_url( 'mailto:' . $horeca['contact']['email'] ); ?>" class="ec-horeca-contact-card is-email">
									<span class="ec-contact-card__label"><?php esc_html_e( 'Email Ho.Re.Ca.', 'espressocoppola-child-theme' ); ?></span>
									<strong class="ec-contact-card__value"><?php echo esc_html( $horeca['contact']['email'] ); ?></strong>
									<span class="ec-contact-card__action"><?php esc_html_e( 'Scrivi un messaggio', 'espressocoppola-child-theme' ); ?> ↗</span>
								</a>
							<?php endif; ?>
						</div>

						<div class="ec-horeca-sidebar-guarantee">
							<span class="ec-guarantee-dot"></span>
							<p class="ec-guarantee-text"><?php esc_html_e( 'Risposta rapida garantita entro 24 ore dal nostro team commerciale dedicato.', 'espressocoppola-child-theme' ); ?></p>
						</div>
					</div>
				</aside>

			</div>
		</div>
	</section>

</main>

<?php
get_footer();
