<?php
/**
 * Template Name: DNA delle miscele
 * Template Post Type: page
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$dna   = espressocoppola_get_dna_page_context( get_the_ID() );
$axes  = array_values( wp_list_pluck( espressocoppola_get_sensory_axes(), 'label' ) );
$first = $dna['first'];
?>
<main class="ec-dna" data-dna-page style="--ec-dna-accent:<?php echo esc_attr( $first['color'] ?? '#c89d54' ); ?>">

	<!-- Ambient continuous background sensory lines & watermark -->
	<div class="ec-dna-ambient-canvas" aria-hidden="true">
		<div class="ec-dna-ambient-grid"></div>
		<div class="ec-dna-ambient-rings"></div>
	</div>

	<!-- 01: SENSORY CORE (Le 7 Dimensioni) -->
	<section class="ec-dna-core" aria-labelledby="ec-dna-core-title">
		<div class="ec-dna-shell">
			<header class="ec-dna-core__header">
				<div class="ec-dna-meta-tag">
					<span class="ec-dna-dot-live"></span>
					<span><?php esc_html_e( 'Profilo Sensoriale · 7 Dimensioni', 'espressocoppola-child-theme' ); ?></span>
				</div>
				<h1 id="ec-dna-core-title"><?php esc_html_e( '7 dimensioni. Un solo carattere.', 'espressocoppola-child-theme' ); ?></h1>
			</header>

			<div class="ec-dna-core__matrix">
				<ol class="ec-dna-core__list">
					<?php foreach ( $axes as $index => $axis ) : ?>
						<li class="ec-dna-core__item" data-axis-index="<?php echo esc_attr( $index ); ?>">
							<div class="ec-dna-core__item-top">
								<span class="ec-dna-core__axis-idx"><?php echo esc_html( str_pad( (string) ( $index + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span>
								<span class="ec-dna-core__node" aria-hidden="true"><i class="ec-dna-core__node-pulse"></i></span>
							</div>
							<div class="ec-dna-core__item-body">
								<strong class="ec-dna-core__axis-label"><?php echo esc_html( $axis ); ?></strong>
								<span class="ec-dna-core__axis-scale">Scala 1 — 5</span>
							</div>
						</li>
					<?php endforeach; ?>
				</ol>
			</div>
		</div>
	</section>

	<!-- Continuous Section Bridge Divider -->
	<div class="ec-dna-bridge" aria-hidden="true">
		<div class="ec-dna-shell">
			<div class="ec-dna-bridge__line">
				<span class="ec-dna-bridge__dot"></span>
				<span class="ec-dna-bridge__label"><?php esc_html_e( 'Geometric Comparison Mode', 'espressocoppola-child-theme' ); ?></span>
				<span class="ec-dna-bridge__dot"></span>
			</div>
		</div>
	</div>

	<!-- 02: CONFRONTO SENSORIALE -->
	<?php if ( ! empty( $dna['explorer']['products'] ) && count( $dna['explorer']['products'] ) >= 2 ) : ?>
		<?php
		$a = $dna['explorer']['products'][0];
		$b = $dna['explorer']['products'][1];
		?>
		<section class="ec-dna-compare" aria-labelledby="ec-dna-compare-title" data-dna-compare>
			<div class="ec-dna-shell">
				<header class="ec-dna-compare__header">
					<div class="ec-dna-meta-tag">
						<span class="ec-dna-dot-live"></span>
						<span><?php esc_html_e( 'Confronto Sensoriale // Dual Profile', 'espressocoppola-child-theme' ); ?></span>
					</div>
					<h2 id="ec-dna-compare-title"><?php esc_html_e( 'Due firme. Una sola geometria.', 'espressocoppola-child-theme' ); ?></h2>
				</header>

				<div class="ec-dna-compare__stage">
					<!-- Left: Selectors -->
					<div class="ec-dna-compare__selectors">
						<div class="ec-dna-select-group is-a">
							<div class="ec-dna-select-header">
								<span class="ec-dna-badge is-a" aria-hidden="true">A</span>
								<span class="ec-dna-select-hint"><?php esc_html_e( 'Miscela Principale', 'espressocoppola-child-theme' ); ?></span>
							</div>
							<label class="ec-dna-select-label" for="ec-dna-select-a">
								<span class="screen-reader-text"><?php esc_html_e( 'Seleziona prima miscela (A)', 'espressocoppola-child-theme' ); ?></span>
								<select id="ec-dna-select-a" data-dna-select-a>
									<?php foreach ( $dna['explorer']['products'] as $i => $product ) : ?>
										<option value="<?php echo esc_attr( $product['id'] ); ?>"<?php selected( $i, 0 ); ?>><?php echo esc_html( $product['name'] ); ?></option>
									<?php endforeach; ?>
								</select>
								<i class="ec-dna-select-chevron" aria-hidden="true"></i>
							</label>
						</div>

						<div class="ec-dna-vs" aria-hidden="true">
							<span class="ec-dna-vs__wire"></span>
							<span class="ec-dna-vs__pill">VS</span>
							<span class="ec-dna-vs__wire"></span>
						</div>

						<div class="ec-dna-select-group is-b">
							<div class="ec-dna-select-header">
								<span class="ec-dna-badge is-b" aria-hidden="true">B</span>
								<span class="ec-dna-select-hint"><?php esc_html_e( 'Miscela di Confronto', 'espressocoppola-child-theme' ); ?></span>
							</div>
							<label class="ec-dna-select-label" for="ec-dna-select-b">
								<span class="screen-reader-text"><?php esc_html_e( 'Seleziona seconda miscela (B)', 'espressocoppola-child-theme' ); ?></span>
								<select id="ec-dna-select-b" data-dna-select-b>
									<?php foreach ( $dna['explorer']['products'] as $i => $product ) : ?>
										<option value="<?php echo esc_attr( $product['id'] ); ?>"<?php selected( $i, 1 ); ?>><?php echo esc_html( $product['name'] ); ?></option>
									<?php endforeach; ?>
								</select>
								<i class="ec-dna-select-chevron" aria-hidden="true"></i>
							</label>
						</div>
					</div>

					<!-- Center: Enlarged Radar Stage -->
					<div class="ec-dna-compare__radar-wrapper" aria-hidden="true">
						<div class="ec-dna-compare__radar-backdrop"></div>
						<div class="ec-dna-compare__radars">
							<svg viewBox="0 0 520 520" data-dna-radar-a class="is-radar-a"></svg>
							<svg viewBox="0 0 520 520" data-dna-radar-b class="is-radar-b"></svg>
						</div>
					</div>

					<!-- Right: Comparative Values List -->
					<div class="ec-dna-compare__values-col">
						<div class="ec-dna-compare__legend" aria-hidden="true">
							<span class="ec-dna-legend-pill is-a">
								<i class="ec-dna-dot-a"></i>
								<strong data-dna-legend-name-a><?php echo esc_html( $a['name'] ); ?></strong>
							</span>
							<span class="ec-dna-legend-pill is-b">
								<i class="ec-dna-dot-b"></i>
								<strong data-dna-legend-name-b><?php echo esc_html( $b['name'] ); ?></strong>
							</span>
						</div>

						<ol data-dna-differences class="ec-dna-differences" aria-label="<?php esc_attr_e( 'Confronto valori assi sensoriali', 'espressocoppola-child-theme' ); ?>">
							<?php foreach ( $axes as $i => $axis ) : ?>
								<li class="ec-dna-diff-row" data-axis-index="<?php echo esc_attr( $i ); ?>">
									<div class="ec-dna-diff-header">
										<span class="ec-dna-axis-name"><?php echo esc_html( $axis ); ?></span>
										<div class="ec-dna-diff-scores">
											<span class="ec-dna-score-val is-a" data-score-a><?php echo esc_html( $a['values'][ $i ] ?? 0 ); ?></span>
											<span class="ec-dna-score-divider">/</span>
											<span class="ec-dna-score-val is-b" data-score-b><?php echo esc_html( $b['values'][ $i ] ?? 0 ); ?></span>
										</div>
									</div>
									<div class="ec-dna-dual-tracks" aria-hidden="true">
										<div class="ec-dna-track is-a">
											<span class="ec-dna-track-badge is-a">A</span>
											<div class="ec-dna-track-line">
												<span class="ec-dna-track-fill is-a" data-fill-a style="width:<?php echo esc_attr( ( $a['values'][ $i ] ?? 0 ) * 20 ); ?>%"></span>
												<b class="ec-dna-track-pin is-a" data-marker-a style="left:<?php echo esc_attr( ( $a['values'][ $i ] ?? 0 ) * 20 ); ?>%"></b>
											</div>
										</div>
										<div class="ec-dna-track is-b">
											<span class="ec-dna-track-badge is-b">B</span>
											<div class="ec-dna-track-line">
												<span class="ec-dna-track-fill is-b" data-fill-b style="width:<?php echo esc_attr( ( $b['values'][ $i ] ?? 0 ) * 20 ); ?>%"></span>
												<b class="ec-dna-track-pin is-b" data-marker-b style="left:<?php echo esc_attr( ( $b['values'][ $i ] ?? 0 ) * 20 ); ?>%"></b>
											</div>
										</div>
									</div>
								</li>
							<?php endforeach; ?>
						</ol>
					</div>
				</div>
				<script type="application/json" data-dna-data><?php echo wp_json_encode( array( 'axes' => $axes, 'products' => $dna['explorer']['products'] ), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ); ?></script>
			</div>
		</section>
	<?php endif; ?>

	<!-- Continuous Section Bridge Divider 2 -->
	<div class="ec-dna-bridge" aria-hidden="true">
		<div class="ec-dna-shell">
			<div class="ec-dna-bridge__line">
				<span class="ec-dna-bridge__dot"></span>
				<span class="ec-dna-bridge__label"><?php esc_html_e( 'Physical Expression // Catalog Formats', 'espressocoppola-child-theme' ); ?></span>
				<span class="ec-dna-bridge__dot"></span>
			</div>
		</div>
	</div>

	<!-- 03: DAL DNA AL FORMATO -->
	<?php if ( ! empty( $dna['formats'] ) ) : ?>
		<section class="ec-dna-formats" aria-labelledby="ec-dna-formats-title">
			<div class="ec-dna-shell">
				<header class="ec-dna-formats__header">
					<div class="ec-dna-meta-tag">
						<span class="ec-dna-dot-live"></span>
						<span><?php esc_html_e( 'Dal DNA al Formato // Selezione', 'espressocoppola-child-theme' ); ?></span>
					</div>
					<h2 id="ec-dna-formats-title"><?php esc_html_e( 'Un carattere. Tanti modi di viverlo.', 'espressocoppola-child-theme' ); ?></h2>
				</header>
				<nav class="ec-dna-formats__nav" aria-label="<?php esc_attr_e( 'Formati disponibili', 'espressocoppola-child-theme' ); ?>">
					<?php foreach ( $dna['formats'] as $idx => $format ) : ?>
						<a class="ec-dna-format-row" href="<?php echo esc_url( $format['url'] ); ?>">
							<span class="ec-dna-format-idx"><?php echo esc_html( str_pad( (string) ( $idx + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span>
							<span class="ec-dna-format-name"><?php echo esc_html( $format['name'] ); ?></span>
							<span class="ec-dna-format-count">
								<strong><?php echo esc_html( $format['count'] ); ?></strong>
								<small><?php echo ( (int) $format['count'] === 1 ) ? esc_html__( 'miscela', 'espressocoppola-child-theme' ) : esc_html__( 'miscele', 'espressocoppola-child-theme' ); ?></small>
							</span>
							<span class="ec-dna-format-arrow" aria-hidden="true">↗</span>
						</a>
					<?php endforeach; ?>
				</nav>
			</div>
		</section>
	<?php endif; ?>

</main>
<?php
get_footer();
