<?php
/**
 * Template Name: Chi siamo
 * Template Post Type: page
 *
 * THESIS: raccontare Espresso Coppola attraverso il rito, non una cronologia inventata.
 * OWN-WORLD: panna, espresso e champagne; immagini ampie, orbite sottili, tipografia netta.
 * STORY: essenza, miscele, lavorazione, formati e accesso naturale alla collezione.
 * FIRST VIEWPORT: manifesto a sinistra, immagine CMS sospesa a destra, CTA shop visibile.
 * FORM: racconto editoriale immersivo dentro il sistema visivo già stabilito dal sito.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
$about = espressocoppola_get_about_page_context( get_the_ID() );
?>
<main id="primary" class="ec-about" data-about-page>
	<section class="ec-about-hero" aria-labelledby="ec-about-title">
		<div class="ec-about-shell ec-about-hero__inner">
			<div class="ec-about-hero__copy" data-about-reveal>
				<p class="ec-about-kicker"><?php esc_html_e( 'Espresso Coppola — Essenza Napoletana', 'espressocoppola-child-theme' ); ?></p>
				<h1 id="ec-about-title"><?php echo esc_html( $about['title'] ); ?><span><?php esc_html_e( 'Il caffè, nella sua espressione più autentica.', 'espressocoppola-child-theme' ); ?></span></h1>
				<p><?php echo esc_html( $about['intro'] ); ?></p>
				<a class="ec-about-button" href="<?php echo esc_url( $about['shopUrl'] ); ?>"><?php esc_html_e( 'Scopri le miscele', 'espressocoppola-child-theme' ); ?> <span aria-hidden="true">↗</span></a>
			</div>
			<div class="ec-about-hero__visual" data-about-loop aria-hidden="true">
				<span class="ec-about-orbit"></span>
				<?php if ( $about['heroImageId'] ) : ?>
					<?php echo wp_get_attachment_image( $about['heroImageId'], 'full', false, array( 'class' => 'ec-about-hero__image', 'loading' => 'eager', 'fetchpriority' => 'high', 'decoding' => 'async', 'sizes' => '(max-width: 760px) 92vw, 52vw', 'alt' => '' ) ); ?>
				<?php else : ?><span class="ec-about-hero__monogram">EC</span><?php endif; ?>
			</div>
		</div>
	</section>

	<section class="ec-about-manifesto" aria-labelledby="ec-manifesto-title">
		<div class="ec-about-shell ec-about-manifesto__grid<?php echo ! empty( $about['manifestoImage'] ) ? ' has-image' : ''; ?>">
			<div class="ec-about-manifesto__aside">
				<p class="ec-about-kicker"><?php esc_html_e( 'Il nostro manifesto', 'espressocoppola-child-theme' ); ?></p>
				<?php if ( ! empty( $about['manifestoImage'] ) ) : ?>
					<div class="ec-about-manifesto__media" data-about-reveal>
						<img src="<?php echo esc_url( $about['manifestoImage'] ); ?>" alt="<?php echo esc_attr( $about['manifestoTitle'] ); ?>" class="ec-about-manifesto__image" loading="lazy" decoding="async">
					</div>
				<?php endif; ?>
			</div>
			<div class="ec-about-manifesto__main" data-about-reveal>
				<h2 id="ec-manifesto-title"><?php echo esc_html( $about['manifestoTitle'] ); ?></h2>
				<div class="ec-about-manifesto__text">
					<?php echo wp_kses_post( wpautop( $about['manifestoText'] ) ); ?>
				</div>
				<div class="ec-about-values" data-about-reveal>
					<span><?php esc_html_e( 'Qualità', 'espressocoppola-child-theme' ); ?></span><span><?php esc_html_e( 'Affidabilità', 'espressocoppola-child-theme' ); ?></span><span><?php esc_html_e( 'Ascolto', 'espressocoppola-child-theme' ); ?></span>
				</div>
			</div>
		</div>
	</section>

	<section class="ec-about-process" aria-labelledby="ec-process-title">
		<div class="ec-about-shell">
			<header class="ec-about-process__header" data-about-reveal>
				<p class="ec-about-kicker"><?php esc_html_e( 'Dal chicco alla tazza', 'espressocoppola-child-theme' ); ?></p>
				<h2 id="ec-process-title"><?php esc_html_e( 'Il gusto prende forma, un gesto alla volta.', 'espressocoppola-child-theme' ); ?></h2>
				<p class="ec-about-process__lead"><?php esc_html_e( 'Tre passaggi essenziali guidati da passione artigianale, cura del dettaglio e rispetto per la materia prima.', 'espressocoppola-child-theme' ); ?></p>
			</header>
			<ol class="ec-about-process__list">
				<li class="ec-about-process__item" data-about-reveal>
					<div class="ec-about-process__badge">
						<span class="ec-about-process__number">01</span>
						<span class="ec-about-process__tag"><?php esc_html_e( 'Fase 1', 'espressocoppola-child-theme' ); ?></span>
					</div>
					<h3 class="ec-about-process__title"><?php esc_html_e( 'Selezione', 'espressocoppola-child-theme' ); ?></h3>
					<p class="ec-about-process__desc"><?php esc_html_e( 'Origini pregiate e caratteri scelti con cura meticolosa per dare armonia ed equilibrio a ogni miscela.', 'espressocoppola-child-theme' ); ?></p>
				</li>
				<li class="ec-about-process__item" data-about-reveal>
					<div class="ec-about-process__badge">
						<span class="ec-about-process__number">02</span>
						<span class="ec-about-process__tag"><?php esc_html_e( 'Fase 2', 'espressocoppola-child-theme' ); ?></span>
					</div>
					<h3 class="ec-about-process__title"><?php esc_html_e( 'Tostatura', 'espressocoppola-child-theme' ); ?></h3>
					<p class="ec-about-process__desc"><?php esc_html_e( 'Calore costante e tempi calibrati accompagnano e sviluppano la pienezza di ogni singolo profilo aromatico.', 'espressocoppola-child-theme' ); ?></p>
				</li>
				<li class="ec-about-process__item" data-about-reveal>
					<div class="ec-about-process__badge">
						<span class="ec-about-process__number">03</span>
						<span class="ec-about-process__tag"><?php esc_html_e( 'Fase 3', 'espressocoppola-child-theme' ); ?></span>
					</div>
					<h3 class="ec-about-process__title"><?php esc_html_e( 'Preparazione', 'espressocoppola-child-theme' ); ?></h3>
					<p class="ec-about-process__desc"><?php esc_html_e( 'Il formato giusto per ogni sistema di estrazione rende semplice, cremoso e perfetto il tuo rito quotidiano.', 'espressocoppola-child-theme' ); ?></p>
				</li>
			</ol>
		</div>
	</section>

	<?php if ( ! empty( $about['blends'] ) ) : ?>
	<section class="ec-about-blends" aria-labelledby="ec-blends-title">
		<div class="ec-about-shell">
			<header class="ec-about-heading" data-about-reveal>
				<p class="ec-about-kicker"><?php esc_html_e( 'Le nostre miscele', 'espressocoppola-child-theme' ); ?></p>
				<h2 id="ec-blends-title"><?php esc_html_e( 'Ogni espresso ha una firma.', 'espressocoppola-child-theme' ); ?></h2>
			</header>
			<div class="ec-about-blends__grid">
				<?php foreach ( $about['blends'] as $index => $blend ) : ?>
					<a class="ec-about-blend" href="<?php echo esc_url( $blend['url'] ); ?>" data-about-reveal>
						<div class="ec-about-blend__top">
							<span class="ec-about-blend__index"><?php echo esc_html( str_pad( (string) ( $index + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span>
							<span class="ec-about-blend__arrow" aria-hidden="true">↗</span>
						</div>
						<div class="ec-about-blend__visual">
							<?php if ( ! empty( $blend['imageId'] ) ) : ?>
								<?php echo wp_get_attachment_image( $blend['imageId'], 'medium', false, array( 'class' => 'ec-about-blend__image', 'loading' => 'lazy', 'decoding' => 'async', 'alt' => esc_attr( $blend['name'] ) ) ); ?>
							<?php endif; ?>
						</div>
						<div class="ec-about-blend__body">
							<strong class="ec-about-blend__name"><?php echo esc_html( $blend['name'] ); ?></strong>
							<small class="ec-about-blend__copy"><?php echo esc_html( $blend['copy'] ); ?></small>
						</div>
						<div class="ec-about-blend__bottom">
							<?php if ( ! empty( $blend['sensory'] ) ) : ?>
								<div class="ec-about-blend__radar" title="<?php esc_attr_e( 'Profilo sensoriale', 'espressocoppola-child-theme' ); ?>">
									<svg viewBox="0 0 520 520" aria-hidden="true" data-about-radar data-values="<?php echo esc_attr( wp_json_encode( $blend['sensory']['values'] ) ); ?>" data-color="<?php echo esc_attr( $blend['sensory']['color'] ); ?>"></svg>
								</div>
							<?php endif; ?>
							<span class="ec-about-blend__cta"><?php esc_html_e( 'Scopri', 'espressocoppola-child-theme' ); ?> <i aria-hidden="true">→</i></span>
						</div>
					</a>
				<?php endforeach; ?>
			</div>
		</div>
	</section>
	<?php endif; ?>

	<?php if ( $about['formats'] ) : ?>
	<section class="ec-about-formats" aria-labelledby="ec-formats-title">
		<div class="ec-about-shell"><header data-about-reveal><p class="ec-about-kicker"><?php esc_html_e( 'Il caffè, come lo preferisci', 'espressocoppola-child-theme' ); ?></p><h2 id="ec-formats-title"><?php esc_html_e( 'Una sola essenza. Il tuo modo di viverla.', 'espressocoppola-child-theme' ); ?></h2></header><nav aria-label="<?php esc_attr_e( 'Formati di caffè', 'espressocoppola-child-theme' ); ?>"><?php foreach ( $about['formats'] as $format ) : ?><a href="<?php echo esc_url( $format['url'] ); ?>"><span><?php echo esc_html( $format['name'] ); ?></span><small><?php echo esc_html( sprintf( _n( '%d caffè', '%d caffè', $format['count'], 'espressocoppola-child-theme' ), $format['count'] ) ); ?></small><i aria-hidden="true">↗</i></a><?php endforeach; ?></nav></div>
	</section>
	<?php endif; ?>

	<?php if ( $about['products'] ) : ?>
	<section class="ec-about-products" aria-labelledby="ec-products-title"><div class="ec-about-shell"><header class="ec-about-heading" data-about-reveal><p class="ec-about-kicker"><?php esc_html_e( 'Più di un prodotto', 'espressocoppola-child-theme' ); ?></p><h2 id="ec-products-title"><?php esc_html_e( 'Tre modi per iniziare.', 'espressocoppola-child-theme' ); ?></h2></header><div class="ec-about-products__grid" data-about-product-grid><?php foreach ( $about['products'] as $product ) { get_template_part( 'template-parts/shop/product-card', null, array( 'product' => $product ) ); } ?></div></div></section>
	<?php endif; ?>
</main>
<?php get_footer(); ?>
