<?php
/**
 * Template Name: FAQ / Answer Atlas
 * Template Post Type: page
 *
 * CONCEPT: Answer Atlas & Knowledge Experience di Espresso Coppola.
 * MOOD: Crema, panna, champagne, espresso profondo, micro-orbite e nodi di costellazione.
 *
 * ARCHITETTURA (Ogni domanda appare ESATTAMENTE UNA VOLTA):
 * 01 — HERO / ANSWER ATLAS
 * 02 — QUESTION MAP (Costellazione editoriale delle categorie con ancore)
 * 03 — CHIEDILO COME LO CHIEDERESTI A NOI (Spotlight query conversazionali con anchor scroll)
 * 04 — THE ANSWER ATLAS STREAM (L'unico archivio completo, ordinato per categoria, immersivo e setoso)
 * 05 — RELATED KNOWLEDGE (Collegamenti reali Shop, DNA, Ho.Re.Ca., Contatti)
 * 06 — FOOTER
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$faq_context = espressocoppola_get_faq_page_context( get_the_ID() );
$total_faqs  = $faq_context['total_count'];
?>

<main id="primary" class="ec-atlas-page" data-faq-atlas>

	<?php if ( ! empty( $faq_context['all_faqs'] ) ) : ?>
		<!-- Schema.org JSON-LD FAQPage (100% server-rendered, coerente con il DOM visibile) -->
		<?php echo espressocoppola_get_faq_json_ld( $faq_context['all_faqs'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	<?php endif; ?>

	<!-- ==========================================================================
	     01 — HERO / ANSWER ATLAS
	     ========================================================================== -->
	<header class="ec-atlas-hero" aria-labelledby="ec-atlas-title">
		<div class="ec-atlas-shell ec-atlas-hero__inner">

			<!-- Elementi grafici cosmici / orbitali -->
			<div class="ec-atlas-hero__ambient" aria-hidden="true">
				<span class="ec-atlas-orbit ec-atlas-orbit--outer"></span>
				<span class="ec-atlas-orbit ec-atlas-orbit--inner"></span>
				<span class="ec-atlas-node-pulse ec-atlas-node-pulse--1"></span>
				<span class="ec-atlas-node-pulse ec-atlas-node-pulse--2"></span>
			</div>

			<div class="ec-atlas-hero__copy">
				<div class="ec-atlas-hero__meta">
					<span class="ec-atlas-kicker"><?php esc_html_e( 'FAQ / ANSWER ATLAS', 'espressocoppola-child-theme' ); ?></span>
					<span class="ec-atlas-coords" aria-hidden="true">NAPOLI 40.8518° N • 14.2681° E</span>
				</div>

				<h1 id="ec-atlas-title" class="ec-atlas-hero__title">
					<span><?php esc_html_e( 'Tutto quello', 'espressocoppola-child-theme' ); ?></span>
					<span><?php esc_html_e( 'che vuoi sapere', 'espressocoppola-child-theme' ); ?></span>
					<span class="ec-atlas-hero__title-accent"><?php esc_html_e( 'sul nostro caffè.', 'espressocoppola-child-theme' ); ?></span>
				</h1>

				<p class="ec-atlas-hero__intro">
					<?php esc_html_e( 'Una raccolta ordinata di risposte su miscele, compatibilità, formati, acquisti, mondo Ho.Re.Ca. ed Espresso Coppola. Esplora la mappa tematica o scorri liberamente il flusso della conoscenza.', 'espressocoppola-child-theme' ); ?>
				</p>

				<div class="ec-atlas-hero__stats">
					<div class="ec-atlas-stat">
						<span class="ec-atlas-stat__num"><?php echo esc_html( sprintf( '%02d', count( $faq_context['question_map'] ) ) ); ?></span>
						<span class="ec-atlas-stat__lbl"><?php esc_html_e( 'Aree Tematiche', 'espressocoppola-child-theme' ); ?></span>
					</div>
					<span class="ec-atlas-stat__sep" aria-hidden="true">/</span>
					<div class="ec-atlas-stat">
						<span class="ec-atlas-stat__num"><?php echo esc_html( sprintf( '%02d', $total_faqs ) ); ?></span>
						<span class="ec-atlas-stat__lbl"><?php esc_html_e( 'Risposte Certificate', 'espressocoppola-child-theme' ); ?></span>
					</div>
				</div>
			</div>

		</div>
	</header>

	<?php if ( empty( $faq_context['all_faqs'] ) ) : ?>
		<!-- Empty State Graceful Degradation -->
		<section class="ec-atlas-empty ec-atlas-shell">
			<div class="ec-atlas-empty__card">
				<span class="ec-atlas-empty__icon" aria-hidden="true">☕</span>
				<h2><?php esc_html_e( 'L\'Answer Atlas è in fase di aggiornamento', 'espressocoppola-child-theme' ); ?></h2>
				<p><?php esc_html_e( 'Stiamo organizzando le risposte della torrefazione. Nel frattempo puoi visitare il nostro Shop o contattarci per qualsiasi informazione.', 'espressocoppola-child-theme' ); ?></p>
				<a href="<?php echo esc_url( home_url( '/shop/' ) ); ?>" class="ec-atlas-btn is-primary">
					<span><?php esc_html_e( 'Visita lo Shop Online', 'espressocoppola-child-theme' ); ?></span>
					<span class="ec-atlas-btn__arrow" aria-hidden="true">→</span>
				</a>
			</div>
		</section>
	<?php else : ?>

		<!-- ==========================================================================
		     02 — QUESTION MAP (COSTELLAZIONE DELLE CATEGORIE)
		     ========================================================================== -->
		<section class="ec-atlas-map" aria-label="<?php esc_attr_e( 'Mappa delle Aree Tematiche', 'espressocoppola-child-theme' ); ?>">
			<div class="ec-atlas-shell">
				<div class="ec-atlas-map__header">
					<span class="ec-atlas-eyebrow"><?php esc_html_e( 'Costellazione della Conoscenza', 'espressocoppola-child-theme' ); ?></span>
					<h2 class="ec-atlas-map__heading"><?php esc_html_e( 'Scegli la rotta tematica', 'espressocoppola-child-theme' ); ?></h2>
				</div>

				<div class="ec-atlas-constellation" role="list">
					<?php foreach ( $faq_context['question_map'] as $cat_item ) : ?>
						<a href="#<?php echo esc_attr( $cat_item['anchor'] ); ?>" class="ec-atlas-star" role="listitem" data-cat-link="<?php echo esc_attr( $cat_item['slug'] ); ?>">
							<div class="ec-atlas-star__node" aria-hidden="true">
								<span class="ec-atlas-star__dot"></span>
								<span class="ec-atlas-star__ring"></span>
							</div>
							<div class="ec-atlas-star__info">
								<span class="ec-atlas-star__index"><?php echo esc_html( $cat_item['index'] ); ?></span>
								<h3 class="ec-atlas-star__name"><?php echo esc_html( $cat_item['name'] ); ?></h3>
								<span class="ec-atlas-star__count"><?php echo esc_html( $cat_item['count_label'] ); ?></span>
							</div>
							<span class="ec-atlas-star__line" aria-hidden="true"></span>
						</a>
					<?php endforeach; ?>
				</div>
			</div>
		</section>

		<!-- ==========================================================================
		     03 — CHIEDILO COME LO CHIEDERESTI A NOI (RICERCA CONVERSAZIONALE)
		     ========================================================================== -->
		<?php if ( ! empty( $faq_context['conversational_queries'] ) ) : ?>
			<section class="ec-atlas-dialogue" aria-labelledby="ec-dialogue-title">
				<div class="ec-atlas-shell">
					<div class="ec-atlas-dialogue__intro">
						<span class="ec-atlas-eyebrow is-gold"><?php esc_html_e( 'Domande Dirette', 'espressocoppola-child-theme' ); ?></span>
						<h2 id="ec-dialogue-title" class="ec-atlas-dialogue__title">
							<span><?php esc_html_e( 'Chiedilo', 'espressocoppola-child-theme' ); ?></span>
							<span><?php esc_html_e( 'come lo chiederesti a noi.', 'espressocoppola-child-theme' ); ?></span>
						</h2>
						<p class="ec-atlas-dialogue__desc">
							<?php esc_html_e( 'Domande semplici, risposte chiare. Seleziona il quesito che hai in mente per raggiungere istantaneamente la risposta approfondita.', 'espressocoppola-child-theme' ); ?>
						</p>
					</div>

					<div class="ec-atlas-dialogue__grid">
						<?php foreach ( $faq_context['conversational_queries'] as $cquery ) : ?>
							<a href="#<?php echo esc_attr( $cquery['anchor'] ); ?>" class="ec-atlas-query-card" data-query-link>
								<span class="ec-atlas-query-card__cat"><?php echo esc_html( $cquery['category_name'] ); ?></span>
								<p class="ec-atlas-query-card__text">“<?php echo esc_html( $cquery['query'] ); ?>”</p>
								<div class="ec-atlas-query-card__footer">
									<span class="ec-atlas-query-card__cta"><?php esc_html_e( 'Leggi la risposta', 'espressocoppola-child-theme' ); ?></span>
									<span class="ec-atlas-query-card__arrow" aria-hidden="true">→</span>
								</div>
							</a>
						<?php endforeach; ?>
					</div>
				</div>
			</section>
		<?php endif; ?>

		<!-- ==========================================================================
		     04 — THE ANSWER ATLAS STREAM (UNICO FLUSSO ORDINATO PER CATEGORIA)
		     ========================================================================== -->
		<section class="ec-atlas-stream" id="answer-stream" aria-label="<?php esc_attr_e( 'Answer Atlas Stream', 'espressocoppola-child-theme' ); ?>">
			<div class="ec-atlas-shell">
				
				<div class="ec-atlas-stream__lead">
					<span class="ec-atlas-eyebrow"><?php esc_html_e( 'Answer Atlas • Conoscenza Certificata', 'espressocoppola-child-theme' ); ?></span>
					<h2 class="ec-atlas-stream__lead-title"><?php esc_html_e( 'L\'archivio risposte della torrefazione', 'espressocoppola-child-theme' ); ?></h2>
					<p class="ec-atlas-stream__lead-desc">
						<?php esc_html_e( 'Tutte le risposte ufficiali ordinate organicamente per ambito tematico, presentate in una lettura continua e approfondita.', 'espressocoppola-child-theme' ); ?>
					</p>
				</div>

				<div class="ec-atlas-stream__categories">
					<?php foreach ( $faq_context['category_groups'] as $cat_group ) : ?>
						
						<div class="ec-atlas-cat-block" id="<?php echo esc_attr( $cat_group['anchor'] ); ?>" data-cat-block="<?php echo esc_attr( $cat_group['slug'] ); ?>">
							
							<!-- Header della Categoria -->
							<div class="ec-atlas-cat-header">
								<div class="ec-atlas-cat-header__meta">
									<span class="ec-atlas-cat-header__kicker">
										<?php echo esc_html( sprintf( __( 'AREA TEMATICA %s / %s', 'espressocoppola-child-theme' ), $cat_group['index'], sprintf( '%02d', count( $faq_context['category_groups'] ) ) ) ); ?>
									</span>
									<span class="ec-atlas-cat-header__count"><?php echo esc_html( $cat_group['count_label'] ); ?></span>
								</div>
								<h3 class="ec-atlas-cat-header__title"><?php echo esc_html( $cat_group['name'] ); ?></h3>
								<div class="ec-atlas-cat-header__line" aria-hidden="true">
									<span class="ec-atlas-cat-header__dot"></span>
								</div>
							</div>

							<!-- Lista Card Domanda/Risposta della Categoria -->
							<div class="ec-atlas-cat-flow">
								<?php foreach ( $cat_group['items'] as $faq ) : ?>
									<article class="ec-atlas-card" id="<?php echo esc_attr( $faq['anchor'] ); ?>" data-stream-card>
										
										<!-- Colonna Meta Sticky Progressiva -->
										<div class="ec-atlas-card__meta">
											<div class="ec-atlas-card__badge">
												<span class="ec-atlas-card__prefix"><?php esc_html_e( 'QUERY', 'espressocoppola-child-theme' ); ?></span>
												<span class="ec-atlas-card__idx"><?php echo esc_html( sprintf( '%02d', $faq['global_index'] ) ); ?></span>
												<span class="ec-atlas-card__slash">/</span>
												<span class="ec-atlas-card__total"><?php echo esc_html( sprintf( '%02d', $total_faqs ) ); ?></span>
											</div>
											<span class="ec-atlas-card__cat"><?php echo esc_html( $faq['category_name'] ); ?></span>
											
											<!-- Indicatore visivo di scorrimento -->
											<div class="ec-atlas-card__indicator" aria-hidden="true">
												<span class="ec-atlas-card__dot"></span>
												<span class="ec-atlas-card__bar"></span>
											</div>
										</div>

										<!-- Colonna Contenuto -->
										<div class="ec-atlas-card__body">
											<h4 class="ec-atlas-card__question">
												<a href="#<?php echo esc_attr( $faq['anchor'] ); ?>" class="ec-atlas-card__anchor-link" title="<?php esc_attr_e( 'Link permanente a questa risposta', 'espressocoppola-child-theme' ); ?>">
													<?php echo esc_html( $faq['title'] ); ?>
												</a>
											</h4>

											<div class="ec-atlas-card__answer">
												<?php echo $faq['content']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
											</div>

											<?php if ( ! empty( $faq['related_url'] ) ) : ?>
												<div class="ec-atlas-card__action">
													<a href="<?php echo esc_url( $faq['related_url'] ); ?>" class="ec-atlas-pill-btn">
														<span><?php echo esc_html( $faq['related_label'] ); ?></span>
													</a>
												</div>
											<?php endif; ?>
										</div>

									</article>
								<?php endforeach; ?>
							</div>

						</div>

					<?php endforeach; ?>
				</div>

			</div>
		</section>

		<!-- ==========================================================================
		     05 — RELATED KNOWLEDGE / CANALI
		     ========================================================================== -->
		<section class="ec-atlas-related" aria-labelledby="ec-related-title">
			<div class="ec-atlas-shell">
				<div class="ec-atlas-related__header">
					<span class="ec-atlas-eyebrow is-gold"><?php esc_html_e( 'Approfondimenti & Canali', 'espressocoppola-child-theme' ); ?></span>
					<h2 id="ec-related-title" class="ec-atlas-related__title"><?php esc_html_e( 'Continua a esplorare l’universo Espresso Coppola', 'espressocoppola-child-theme' ); ?></h2>
				</div>

				<div class="ec-atlas-related__grid">
					<?php foreach ( $faq_context['related_links'] as $rel ) : ?>
						<div class="ec-atlas-rel-card">
							<span class="ec-atlas-rel-card__kicker"><?php echo esc_html( $rel['kicker'] ); ?></span>
							<h3 class="ec-atlas-rel-card__title"><?php echo esc_html( $rel['title'] ); ?></h3>
							<p class="ec-atlas-rel-card__desc"><?php echo esc_html( $rel['desc'] ); ?></p>
							<a href="<?php echo esc_url( $rel['url'] ); ?>" class="ec-atlas-rel-card__btn">
								<span><?php echo esc_html( $rel['label'] ); ?></span>
							</a>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		</section>

	<?php endif; ?>

</main>

<?php
get_footer();
