<?php
/**
 * Homepage sensory profile Explorer.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$explorer   = isset( $args['explorer'] ) && is_array( $args['explorer'] ) ? $args['explorer'] : array();
$products   = isset( $explorer['products'] ) && is_array( $explorer['products'] ) ? $explorer['products'] : array();
$categories = isset( $explorer['categories'] ) && is_array( $explorer['categories'] ) ? $explorer['categories'] : array();

if ( empty( $products ) || empty( $categories ) ) {
	return;
}

$first_product      = $products[0];
$active_category_id = (int) $first_product['category']['id'];
$axis_labels        = array_values( wp_list_pluck( espressocoppola_get_sensory_axes(), 'label' ) );
$json_payload       = array(
	'axes'       => $axis_labels,
	'categories' => $categories,
	'products'   => $products,
);
$has_image          = ! empty( $first_product['image'] );
?>
<section
	id="espresso-sensory-explorer"
	class="ec-sensory-explorer"
	aria-labelledby="ec-sensory-title"
	data-sensory-explorer
	data-home-observe
	style="--ec-sensory-accent: <?php echo esc_attr( $first_product['color'] ); ?>"
>
	<div class="ec-sensory-explorer__atmosphere" aria-hidden="true">
		<span class="ec-sensory-explorer__orbit ec-sensory-explorer__orbit--outer"></span>
		<span class="ec-sensory-explorer__orbit ec-sensory-explorer__orbit--inner"></span>
		<span class="ec-sensory-explorer__pulse"></span>
	</div>

	<div class="ec-home-container ec-sensory-explorer__inner">
		<header class="ec-sensory-explorer__header">
			<div>
				<p class="ec-sensory-explorer__eyebrow"><?php esc_html_e( 'Profilo sensoriale', 'espressocoppola-child-theme' ); ?></p>
				<h2 id="ec-sensory-title">
					<span><?php esc_html_e( 'Scopri il carattere', 'espressocoppola-child-theme' ); ?></span>
					<span><?php esc_html_e( 'del tuo Espresso.', 'espressocoppola-child-theme' ); ?></span>
				</h2>
			</div>
			<p class="ec-sensory-explorer__lede"><?php esc_html_e( 'Sette tratti, una firma precisa. Esplora la forma aromatica di ogni miscela Espresso Coppola.', 'espressocoppola-child-theme' ); ?></p>
		</header>

		<div class="ec-sensory-explorer__stage">
			<div id="ec-sensory-product-panel" class="ec-sensory-explorer__profile" role="tabpanel" tabindex="0" aria-live="polite" data-sensory-product-panel>
				<p class="ec-sensory-explorer__classification">
					<span data-sensory-category-name><?php echo esc_html( $first_product['category']['name'] ); ?></span>
					<span aria-hidden="true">—</span>
					<span data-sensory-blend<?php echo $first_product['blend'] ? '' : ' hidden'; ?>><?php echo esc_html( $first_product['blend'] ); ?></span>
				</p>
				<h3 data-sensory-product-name><?php echo esc_html( $first_product['name'] ); ?></h3>
				<p class="ec-sensory-explorer__note" data-sensory-note<?php echo $first_product['note'] ? '' : ' hidden'; ?>><?php echo esc_html( $first_product['note'] ); ?></p>
				<a class="ec-sensory-explorer__link" href="<?php echo esc_url( $first_product['url'] ); ?>" data-sensory-link aria-label="<?php echo esc_attr( sprintf( __( 'Scopri %s', 'espressocoppola-child-theme' ), $first_product['name'] ) ); ?>">
					<?php esc_html_e( 'Scopri il prodotto', 'espressocoppola-child-theme' ); ?> <span aria-hidden="true">↗</span>
				</a>

				<ol class="ec-screen-reader-text" data-sensory-values>
					<?php foreach ( $axis_labels as $axis_index => $axis_label ) : ?>
						<li><span><?php echo esc_html( $axis_label ); ?></span> <strong><?php echo esc_html( $first_product['values'][ $axis_index ] ); ?> / 5</strong></li>
					<?php endforeach; ?>
				</ol>
			</div>

			<div class="ec-sensory-explorer__chart" data-sensory-chart>
				<p class="ec-sensory-explorer__scale" aria-hidden="true"><span>01</span><i></i><span>05</span></p>
				<svg class="ec-sensory-explorer__radar" viewBox="0 0 520 520" role="img" data-sensory-radar></svg>
				<div class="ec-sensory-explorer__tooltip" role="status" data-sensory-tooltip hidden></div>
			</div>

			<div class="ec-sensory-explorer__visual<?php echo $has_image ? '' : ' has-no-image'; ?>" data-sensory-image-stage aria-hidden="true">
				<span class="ec-sensory-explorer__image-aura"></span>
				<img
					data-sensory-image
					<?php if ( $has_image ) : ?>
						src="<?php echo esc_url( $first_product['image'] ); ?>"
						<?php if ( $first_product['imageSrcset'] ) : ?>srcset="<?php echo esc_attr( $first_product['imageSrcset'] ); ?>"<?php endif; ?>
						sizes="<?php echo esc_attr( $first_product['imageSizes'] ); ?>"
						alt="<?php echo esc_attr( $first_product['name'] ); ?>"
					<?php else : ?>
						hidden
						alt=""
					<?php endif; ?>
					loading="lazy"
					decoding="async"
				>
			</div>
		</div>

		<div class="ec-sensory-explorer__controls">
			<nav class="ec-sensory-explorer__rail ec-sensory-explorer__rail--categories" aria-label="<?php esc_attr_e( 'Categorie sensoriali', 'espressocoppola-child-theme' ); ?>">
				<p><?php esc_html_e( 'Scegli la famiglia', 'espressocoppola-child-theme' ); ?></p>
				<div role="tablist" aria-label="<?php esc_attr_e( 'Categoria prodotto', 'espressocoppola-child-theme' ); ?>" data-sensory-category-rail>
					<?php foreach ( $categories as $category ) : ?>
						<?php $is_active_category = (int) $category['id'] === $active_category_id; ?>
						<button
							type="button"
							role="tab"
							aria-selected="<?php echo $is_active_category ? 'true' : 'false'; ?>"
							aria-controls="ec-sensory-product-panel"
							tabindex="<?php echo $is_active_category ? '0' : '-1'; ?>"
							data-sensory-category="<?php echo esc_attr( $category['id'] ); ?>"
						>
							<span><?php echo esc_html( $category['name'] ); ?></span>
							<small><?php echo esc_html( $category['count'] ); ?></small>
						</button>
					<?php endforeach; ?>
				</div>
			</nav>

			<nav class="ec-sensory-explorer__rail ec-sensory-explorer__rail--products" aria-label="<?php esc_attr_e( 'Prodotti con profilo sensoriale', 'espressocoppola-child-theme' ); ?>">
				<p><?php esc_html_e( 'Seleziona il prodotto', 'espressocoppola-child-theme' ); ?></p>
				<div role="tablist" aria-label="<?php esc_attr_e( 'Prodotto', 'espressocoppola-child-theme' ); ?>" data-sensory-product-rail>
					<?php foreach ( $products as $product_index => $product ) : ?>
						<?php
						$is_active_product = 0 === $product_index;
						$is_visible_product = (int) $product['category']['id'] === $active_category_id;
						?>
						<button
							type="button"
							role="tab"
							aria-selected="<?php echo $is_active_product ? 'true' : 'false'; ?>"
							aria-controls="ec-sensory-product-panel"
							tabindex="<?php echo $is_active_product ? '0' : '-1'; ?>"
							data-sensory-product="<?php echo esc_attr( $product['id'] ); ?>"
							data-sensory-product-category="<?php echo esc_attr( $product['category']['id'] ); ?>"
							<?php echo $is_visible_product ? '' : 'hidden'; ?>
						>
							<span><?php echo esc_html( $product['name'] ); ?></span>
							<i aria-hidden="true"></i>
						</button>
					<?php endforeach; ?>
				</div>
			</nav>
		</div>

		<script type="application/json" data-sensory-data><?php echo wp_json_encode( $json_payload, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></script>
	</div>
</section>
