<?php
/**
 * Homepage Coffee Gateway.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$catalog     = isset( $args['catalog'] ) && is_array( $args['catalog'] ) ? $args['catalog'] : array();
$choices     = isset( $args['choices'] ) && is_array( $args['choices'] ) ? $args['choices'] : array();
$active_slug = isset( $args['active_slug'] ) ? sanitize_title( (string) $args['active_slug'] ) : '';
$shop_url    = function_exists( 'ticinoweb_get_shop_url' ) ? ticinoweb_get_shop_url() : '';

if ( '' === $shop_url && function_exists( 'wc_get_page_permalink' ) ) {
	$shop_url = wc_get_page_permalink( 'shop' );
}

$active_choice = array();

foreach ( $choices as $choice ) {
	if ( isset( $choice['slug'] ) && sanitize_title( (string) $choice['slug'] ) === $active_slug ) {
		$active_choice = $choice;
		break;
	}
}

if ( empty( $active_choice ) && ! empty( $choices[0] ) && is_array( $choices[0] ) ) {
	$active_choice = $choices[0];
}

$matches_choice = static function ( $product, $choice ) {
	if ( ! is_array( $product ) || ! is_array( $choice ) ) {
		return false;
	}

	$is_published = ! array_key_exists( 'published', $product ) || ! empty( $product['published'] );
	$is_available = array_key_exists( 'available', $product )
		? ! empty( $product['available'] )
		: ( ! array_key_exists( 'inStock', $product ) || ! empty( $product['inStock'] ) );

	if ( ! $is_published || ! $is_available ) {
		return false;
	}

	$selection   = isset( $choice['selection'] ) && is_array( $choice['selection'] ) ? $choice['selection'] : array();
	$preparation = sanitize_title( (string) ( $selection['preparation'] ?? '' ) );
	$system      = sanitize_title( (string) ( $selection['system'] ?? '' ) );

	if ( '' === $preparation ) {
		return false;
	}

	$product_preparations = array_filter(
		array_map(
			'sanitize_title',
			array_map( 'strval', (array) ( $product['preparations'] ?? array() ) )
		)
	);

	if ( ! in_array( $preparation, $product_preparations, true ) ) {
		return false;
	}

	if ( '' === $system ) {
		return true;
	}

	$product_systems = array();

	foreach ( (array) ( $product['systems'] ?? array() ) as $product_system ) {
		$product_systems[] = sanitize_title( (string) ( $product_system['slug'] ?? '' ) );
	}

	return in_array( $system, array_filter( $product_systems ), true );
};

$active_products = array();

if ( ! empty( $active_choice ) ) {
	foreach ( (array) ( $catalog['products'] ?? array() ) as $product ) {
		if ( $matches_choice( $product, $active_choice ) ) {
			$active_products[] = $product;
		}
	}
}

$active_products = array_slice( $active_products, 0, 3 );
$active_label    = isset( $active_choice['label'] ) ? (string) $active_choice['label'] : __( 'Il tuo rituale', 'espressocoppola-child-theme' );
$active_count    = isset( $active_choice['count'] ) ? (int) $active_choice['count'] : count( $active_products );
$ambient_label   = isset( $active_choice['ambient'] ) ? (string) $active_choice['ambient'] : $active_label;
?>
<section
	id="coffee-gateway"
	class="ec-coffee-gateway"
	aria-labelledby="coffee-gateway-title"
	data-coffee-gateway
>
	<div class="ec-home-container ec-coffee-gateway__inner">
		<div class="ec-coffee-gateway__intro">
			<p class="ec-coffee-gateway__eyebrow"><?php esc_html_e( 'Boutique Espresso Coppola', 'espressocoppola-child-theme' ); ?></p>
			<h2 id="coffee-gateway-title">
				<span><?php esc_html_e( 'Scegli la tua', 'espressocoppola-child-theme' ); ?></span>
				<span><?php esc_html_e( 'essenza napoletana', 'espressocoppola-child-theme' ); ?></span>
			</h2>
			<p class="ec-coffee-gateway__description"><?php esc_html_e( 'Seleziona la tua macchina e ordina subito le miscele artigianali compatibili.', 'espressocoppola-child-theme' ); ?></p>
		</div>

		<?php if ( ! empty( $choices ) ) : ?>
			<div class="ec-coffee-gateway__content">
				<form class="ec-coffee-gateway__selector" method="get" data-gateway-form>
					<?php foreach ( $_GET as $query_key => $query_value ) : ?>
						<?php if ( 'coffee_system' === $query_key ) : ?>
							<?php continue; ?>
						<?php endif; ?>
						<?php if ( is_scalar( $query_value ) ) : ?>
							<input type="hidden" name="<?php echo esc_attr( (string) $query_key ); ?>" value="<?php echo esc_attr( wp_unslash( (string) $query_value ) ); ?>">
						<?php endif; ?>
					<?php endforeach; ?>

					<fieldset class="ec-coffee-gateway__fieldset">
						<legend class="ec-screen-reader-text"><?php esc_html_e( 'Scegli il tuo sistema di preparazione', 'espressocoppola-child-theme' ); ?></legend>

						<div class="ec-coffee-gateway__choices" role="group" aria-label="<?php esc_attr_e( 'Selettore Coffee Gateway', 'espressocoppola-child-theme' ); ?>" data-gateway-choice-list>
							<?php foreach ( $choices as $choice ) : ?>
								<?php
								$choice_slug  = isset( $choice['slug'] ) ? sanitize_title( (string) $choice['slug'] ) : '';
								$is_active    = '' !== $choice_slug && $choice_slug === $active_slug;
								$selection    = isset( $choice['selection'] ) && is_array( $choice['selection'] ) ? $choice['selection'] : array();
								$presentation = sanitize_title( (string) ( $selection['preparation'] ?? '' ) );

								if ( 'capsule' === $presentation && ! empty( $selection['system'] ) ) {
									$presentation = 'capsule-system';
								}
								?>
								<button
									type="submit"
									class="ec-coffee-gateway__choice<?php echo $is_active ? ' is-active' : ''; ?>"
									name="coffee_system"
									value="<?php echo esc_attr( $choice_slug ); ?>"
									data-gateway-choice="<?php echo esc_attr( $choice_slug ); ?>"
									data-selection="<?php echo esc_attr( wp_json_encode( $selection ) ); ?>"
									aria-pressed="<?php echo $is_active ? 'true' : 'false'; ?>"
									aria-controls="coffee-gateway-products"
								>
									<span class="ec-coffee-gateway__choice-icon" aria-hidden="true">
										<?php if ( 'cialde' === $choice_slug ) : ?>
											<!-- Cialda ESE 44 con linguetta e trama filtro -->
											<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
												<circle cx="11" cy="12" r="7"></circle>
												<circle cx="11" cy="12" r="4" stroke-dasharray="2 2"></circle>
												<path d="M17.2 9.2C19.2 9.2 21 10.4 21 12s-1.8 2.8-3.8 2.8"></path>
											</svg>
										<?php elseif ( 'nespresso' === $choice_slug ) : ?>
											<!-- Capsula Nespresso con colletto e corpo tronco-conico -->
											<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
												<path d="M4 8h16"></path>
												<path d="M5.5 8l2.5 10.5h8l2.5-10.5"></path>
												<path d="M8 18.5h8"></path>
												<path d="M7 8c0-1.8 2.2-3 5-3s5 1.2 5 3"></path>
											</svg>
										<?php elseif ( 'dolce-gusto' === $choice_slug ) : ?>
											<!-- Capsula Dolce Gusto con cupola superiore e vaschetta bombata -->
											<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
												<path d="M3.5 7.5h17"></path>
												<path d="M5 7.5v2c0 5 3.1 9 7 9s7-4 7-9v-2"></path>
												<circle cx="12" cy="12" r="1.5" fill="currentColor"></circle>
												<path d="M6.5 7.5c0-1.7 2.5-3 5.5-3s5.5 1.3 5.5 3"></path>
											</svg>
										<?php elseif ( 'a-modo-mio' === $choice_slug ) : ?>
											<!-- Capsula A Modo Mio con bordo pronunciato e base sagomata -->
											<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
												<path d="M4.5 9h15"></path>
												<path d="M6 9l1.8 9h8.4l1.8-9"></path>
												<path d="M9 18h6"></path>
												<path d="M7 9V7.5c0-1.4 2.2-2.5 5-2.5s5 1.1 5 2.5V9"></path>
											</svg>
										<?php elseif ( 'chicchi' === $choice_slug ) : ?>
											<!-- Chicco di Caffè Artigianale con spacco curvo aromatico -->
											<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
												<path d="M12 3C7 3 4 7 4 12s3 9 8 9 8-4 8-9-3-9-8-9z"></path>
												<path d="M12 3.5c-2.5 4-2.5 13 0 17"></path>
												<path d="M12 9c1.5 1.5 1.5 4.5 0 6"></path>
											</svg>
										<?php else : ?>
											<!-- Caffettiera Moka Napoletana per Macinato -->
											<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
												<circle cx="11" cy="3.5" r="1" fill="currentColor"></circle>
												<path d="M8 5.5h6l1 1.5H7l1-1.5z"></path>
												<path d="M7 7l-1 5.5h10L15 7H7z"></path>
												<path d="M6 12.5h10"></path>
												<path d="M6 12.5l1.5 7h7l1.5-7"></path>
												<path d="M15.5 8.5c2.5 0 3.5 1.5 3.5 3.5s-1 3.5-3.5 3.5"></path>
											</svg>
										<?php endif; ?>
									</span>
									<span class="ec-coffee-gateway__choice-copy">
										<strong><?php echo esc_html( (string) ( $choice['label'] ?? '' ) ); ?></strong>
										<small><?php echo esc_html( sprintf( _n( '%d caffè', '%d caffè', (int) ( $choice['count'] ?? 0 ), 'espressocoppola-child-theme' ), (int) ( $choice['count'] ?? 0 ) ) ); ?></small>
									</span>
								</button>
							<?php endforeach; ?>
						</div>
					</fieldset>
				</form>

				<div class="ec-coffee-gateway__stage" data-gateway-stage>
					<p class="ec-coffee-gateway__ambient" aria-hidden="true" data-gateway-ambient><?php echo esc_html( $ambient_label ); ?></p>
					<p class="ec-screen-reader-text" role="status" aria-live="polite" aria-atomic="true" data-gateway-status>
						<?php
						echo esc_html(
							sprintf(
								_n( '%1$s, %2$d caffe disponibile.', '%1$s, %2$d caffe disponibili.', $active_count, 'espressocoppola-child-theme' ),
								$active_label,
								$active_count
							)
						);
						?>
					</p>

					<div class="ec-coffee-gateway__products" id="coffee-gateway-products" data-gateway-products>
						<?php foreach ( $active_products as $product_index => $product ) : ?>
							<?php
							$product_blends = isset( $product['blends'] ) && is_array( $product['blends'] ) ? $product['blends'] : array();
							$product_blend  = isset( $product_blends[0]['name'] ) ? (string) $product_blends[0]['name'] : '';
							?>
							<article class="ec-coffee-gateway__product<?php echo 0 === $product_index ? ' is-primary' : ''; ?>" data-gateway-product-id="<?php echo esc_attr( (string) ( $product['id'] ?? '' ) ); ?>">
								<?php if ( ! empty( $product['image'] ) ) : ?>
									<a class="ec-coffee-gateway__product-media" href="<?php echo esc_url( (string) $product['url'] ); ?>" tabindex="-1" aria-hidden="true">
										<img
											src="<?php echo esc_url( (string) $product['image'] ); ?>"
											alt="<?php echo esc_attr( (string) $product['name'] ); ?>"
											loading="<?php echo 0 === $product_index ? 'eager' : 'lazy'; ?>"
											decoding="async"
											fetchpriority="<?php echo 0 === $product_index ? 'high' : 'low'; ?>"
											<?php if ( ! empty( $product['imageSrcset'] ) ) : ?>
												srcset="<?php echo esc_attr( (string) $product['imageSrcset'] ); ?>"
											<?php endif; ?>
											<?php if ( ! empty( $product['imageSizes'] ) ) : ?>
												sizes="<?php echo esc_attr( (string) $product['imageSizes'] ); ?>"
											<?php endif; ?>
										>
									</a>
								<?php endif; ?>

								<?php if ( '' !== $product_blend ) : ?>
									<span class="ec-coffee-gateway__product-badge"><?php echo esc_html( $product_blend ); ?></span>
								<?php endif; ?>

								<div class="ec-coffee-gateway__product-bubble" aria-hidden="true">
									<?php if ( '' !== $product_blend ) : ?>
										<span class="ec-coffee-gateway__product-blend"><?php echo esc_html( $product_blend ); ?></span>
									<?php endif; ?>
									<p class="ec-coffee-gateway__product-title"><?php echo esc_html( (string) $product['name'] ); ?></p>
								</div>

								<div class="ec-coffee-gateway__product-overlay">
									<span class="ec-coffee-gateway__product-price"><?php echo wp_kses_post( (string) $product['priceHtml'] ); ?></span>
									<a class="ec-coffee-gateway__product-cta" href="<?php echo esc_url( (string) $product['url'] ); ?>">
										<?php esc_html_e( 'Acquista', 'espressocoppola-child-theme' ); ?>
										<span aria-hidden="true">↗</span>
									</a>
								</div>
							</article>
						<?php endforeach; ?>
						<?php if ( 1 === count( $active_products ) && ! empty( $shop_url ) ) : ?>
							<article class="ec-coffee-gateway__companion">
								<div class="ec-coffee-gateway__companion-inner">
									<div>
										<span class="ec-coffee-gateway__companion-badge"><?php esc_html_e( 'Boutique Coppola', 'espressocoppola-child-theme' ); ?></span>
										<h3><?php esc_html_e( 'L’autentico espresso napoletano.', 'espressocoppola-child-theme' ); ?></h3>
										<p><?php esc_html_e( 'Miscele selezionate e tostatura artigianale lenta per una crema vellutata e un aroma inconfondibile.', 'espressocoppola-child-theme' ); ?></p>
										<ul class="ec-coffee-gateway__companion-list">
											<li><span aria-hidden="true">✓</span> <?php esc_html_e( 'Freschezza e fragranza garantite', 'espressocoppola-child-theme' ); ?></li>
											<li><span aria-hidden="true">✓</span> <?php esc_html_e( 'Spedizione rapida in tutta la Svizzera', 'espressocoppola-child-theme' ); ?></li>
										</ul>
									</div>
									<a class="ec-coffee-gateway__companion-link" href="<?php echo esc_url( $shop_url ); ?>">
										<?php esc_html_e( 'Esplora tutte le miscele', 'espressocoppola-child-theme' ); ?>
										<span aria-hidden="true">↗</span>
									</a>
								</div>
							</article>
						<?php endif; ?>
					</div>
					<div class="ec-coffee-gateway__pagination" data-gateway-pagination></div>
				</div>
			</div>
		<?php else : ?>
			<div class="ec-coffee-gateway__empty">
				<p><?php esc_html_e( 'La prossima degustazione è in arrivo.', 'espressocoppola-child-theme' ); ?></p>
				<h3><?php esc_html_e( 'Lo shop resta aperto per scoprire tutte le miscele.', 'espressocoppola-child-theme' ); ?></h3>
				<?php if ( '' !== $shop_url ) : ?>
					<a class="ec-button ec-button--light" href="<?php echo esc_url( $shop_url ); ?>" data-gateway-shop-fallback>
						<?php esc_html_e( 'Visita lo shop', 'espressocoppola-child-theme' ); ?>
						<span aria-hidden="true">↗</span>
					</a>
				<?php endif; ?>
			</div>
		<?php endif; ?>
	</div>
</section>
