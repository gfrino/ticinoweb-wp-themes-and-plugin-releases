<?php
/** Product card for the custom Shop archive. */
if ( ! defined( 'ABSPATH' ) || empty( $args['product'] ) ) exit;
$item = $args['product'];
$sensory = $item['sensory'];
$type = $item['types'][0] ?? array( 'name' => '' );
$blend = $item['blends'][0] ?? null;
$quick = array_slice( $item['formats'], 0, 2 );
$sensory_axes = array();
if ( $sensory ) {
	$labels = array_values( wp_list_pluck( espressocoppola_get_sensory_axes(), 'label' ) );
	foreach ( $sensory['values'] as $index => $value ) {
		$sensory_axes[] = array(
			'label' => $labels[ $index ],
			'value' => (int) $value,
		);
	}
}
?>
<article class="ec-shop-card<?php echo $item['isAccessory'] ? ' is-accessory' : ''; ?>" data-shop-card>
	<div class="ec-shop-card__visual">
		<a class="ec-shop-card__media" href="<?php echo esc_url( $item['url'] ); ?>" tabindex="-1" aria-hidden="true">
			<?php if ( $item['imageId'] ) : echo wp_get_attachment_image( $item['imageId'], 'woocommerce_thumbnail', false, array( 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '(max-width: 760px) 86vw, (max-width: 1180px) 40vw, 28vw' ) ); else : ?><img src="<?php echo esc_url( $item['image'] ); ?>" alt="" loading="lazy" decoding="async"><?php endif; ?>
			<span class="ec-shop-card__index" aria-hidden="true">EC</span>
		</a>
		<?php if ( $sensory ) : ?>
			<button
				type="button"
				class="ec-shop-card__sensory-trigger"
				aria-expanded="false"
				aria-label="<?php echo esc_attr( sprintf( __( 'Mostra il profilo sensoriale di %s', 'espressocoppola-child-theme' ), $item['name'] ) ); ?>"
				data-open-label="<?php echo esc_attr( sprintf( __( 'Mostra il profilo sensoriale di %s', 'espressocoppola-child-theme' ), $item['name'] ) ); ?>"
				data-close-label="<?php echo esc_attr( sprintf( __( 'Torna all’immagine di %s', 'espressocoppola-child-theme' ), $item['name'] ) ); ?>"
				data-shop-sensory-toggle
			><span aria-hidden="true">✦</span><span class="ec-shop-card__sensory-label ec-shop-card__sensory-label--closed"><?php esc_html_e( 'Profilo', 'espressocoppola-child-theme' ); ?></span><span class="ec-shop-card__sensory-label ec-shop-card__sensory-label--open"><?php esc_html_e( 'Prodotto', 'espressocoppola-child-theme' ); ?></span></button>
			<div class="ec-shop-card__sensory" aria-hidden="true" data-shop-sensory-panel style="--ec-card-accent:<?php echo esc_attr( $sensory['color'] ); ?>">
				<div class="ec-shop-card__sensory-heading"><p><?php esc_html_e( 'Firma sensoriale', 'espressocoppola-child-theme' ); ?></p><span><?php esc_html_e( 'Sette tratti, una miscela', 'espressocoppola-child-theme' ); ?></span></div>
				<div class="ec-shop-card__sensory-chart"><svg viewBox="0 0 520 520" role="img" data-shop-mini-radar data-values="<?php echo esc_attr( wp_json_encode( $sensory['values'] ) ); ?>" data-color="<?php echo esc_attr( $sensory['color'] ); ?>"></svg></div>
				<ul><?php foreach ( $sensory_axes as $axis ) : ?><li><span><?php echo esc_html( $axis['label'] ); ?></span><i aria-hidden="true"><b style="width:<?php echo esc_attr( $axis['value'] * 20 ); ?>%"></b></i><strong><?php echo esc_html( $axis['value'] ); ?>/5</strong></li><?php endforeach; ?></ul>
			</div>
		<?php endif; ?>
	</div>
	<div class="ec-shop-card__body">
		<p class="ec-shop-card__meta"><span><?php echo esc_html( $type['name'] ); ?></span><?php if ( $blend ) : ?><span><?php echo esc_html( $blend['name'] ); ?></span><?php endif; ?></p>
		<h2><a href="<?php echo esc_url( $item['url'] ); ?>"><?php echo esc_html( $item['name'] ); ?></a></h2>
		<?php if ( $item['summary'] ) : ?><p class="ec-shop-card__summary"><?php echo esc_html( $item['summary'] ); ?></p><?php endif; ?>
		<?php if ( $quick ) : ?><p class="ec-shop-card__quick"><?php echo esc_html( implode( ' · ', wp_list_pluck( $quick, 'name' ) ) ); ?></p><?php endif; ?>
		<div class="ec-shop-card__footer"><span class="ec-shop-card__price"><?php echo wp_kses_post( $item['priceHtml'] ); ?></span><a href="<?php echo esc_url( $item['url'] ); ?>"><?php esc_html_e( 'Scopri', 'espressocoppola-child-theme' ); ?> <span aria-hidden="true">↗</span></a></div>
	</div>
</article>
