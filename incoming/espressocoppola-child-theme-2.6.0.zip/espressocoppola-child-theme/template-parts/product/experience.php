<?php
/** Product detail sections below the initial purchase stage. */
defined( 'ABSPATH' ) || exit;
if ( empty( $args['context']['product'] ) ) return;
$context = $args['context'];
$product = $context['product'];
$axes    = espressocoppola_get_sensory_axes();
$facts   = array_values( array_filter( $context['attributes'], static function ( $attribute ) { return $attribute['visible'] && ! $attribute['variation']; } ) );
$gateway_count = count( $context['gateway_names'] );
$payment_copy  = $gateway_count
	? sprintf( _n( '%d metodo attivo al checkout', '%d metodi attivi al checkout', $gateway_count, 'espressocoppola-child-theme' ), $gateway_count )
	: __( 'Checkout protetto', 'espressocoppola-child-theme' );
?>
<aside class="ec-product-trust" aria-label="<?php esc_attr_e( 'Informazioni acquisto', 'espressocoppola-child-theme' ); ?>">
	<div class="ec-product-trust__inner">
		<div><span aria-hidden="true">◇</span><p><strong><?php esc_html_e( 'Pagamento sicuro', 'espressocoppola-child-theme' ); ?></strong><small><?php echo esc_html( $payment_copy ); ?></small></p></div>
		<div><span aria-hidden="true">↗</span><p><strong><?php esc_html_e( 'Spedizione', 'espressocoppola-child-theme' ); ?></strong><small><?php esc_html_e( 'Calcolata al checkout', 'espressocoppola-child-theme' ); ?></small></p></div>
		<div><span aria-hidden="true">◎</span><p><strong><?php esc_html_e( 'Acquisto consapevole', 'espressocoppola-child-theme' ); ?></strong><small><?php esc_html_e( 'Dati prodotto reali', 'espressocoppola-child-theme' ); ?></small></p></div>
		<div><span aria-hidden="true">○</span><p><strong><?php esc_html_e( 'Assistenza', 'espressocoppola-child-theme' ); ?></strong><small><?php esc_html_e( 'Prima e dopo l’ordine', 'espressocoppola-child-theme' ); ?></small></p></div>
	</div>
</aside>

<?php if ( $context['has_profile'] ) : ?>
	<section id="profilo-sensoriale" class="ec-product-sensory" data-product-sensory style="--ec-product-accent:<?php echo esc_attr( $context['profile']['color'] ); ?>">
		<div class="ec-product-sensory__orbit" aria-hidden="true"></div>
		<div class="ec-product-sensory__inner">
			<header>
				<p><?php esc_html_e( 'Profilo sensoriale', 'espressocoppola-child-theme' ); ?></p>
				<h2><?php esc_html_e( 'Il carattere di questo Espresso.', 'espressocoppola-child-theme' ); ?></h2>
				<?php if ( $context['display_blend'] ) : ?><strong><?php echo esc_html( $context['display_blend'] ); ?></strong><?php endif; ?>
				<?php if ( $context['profile']['note'] ) : ?><blockquote><?php echo esc_html( $context['profile']['note'] ); ?></blockquote><?php endif; ?>
			</header>
			<div class="ec-product-sensory__chart">
				<svg viewBox="0 0 520 520" role="img" data-product-radar data-values="<?php echo esc_attr( wp_json_encode( $context['profile']['values'] ) ); ?>" data-color="<?php echo esc_attr( $context['profile']['color'] ); ?>" data-name="<?php echo esc_attr( $product->get_name() ); ?>"></svg>
			</div>
			<ol class="ec-product-sensory__values">
				<?php foreach ( array_values( $axes ) as $index => $axis ) : ?><li><span><?php echo esc_html( $axis['label'] ); ?></span><i aria-hidden="true"><b style="width:<?php echo esc_attr( (int) $context['profile']['values'][ $index ] * 20 ); ?>%"></b></i><strong><?php echo esc_html( (int) $context['profile']['values'][ $index ] ); ?>/5</strong></li><?php endforeach; ?>
			</ol>
		</div>
	</section>
<?php endif; ?>

<section class="ec-product-details" id="dettagli-prodotto" data-product-accordion>
	<div class="ec-product-details__inner">
		<div class="ec-product-details__story">
			<header>
				<p class="ec-product-details__eyebrow"><?php esc_html_e( 'Dentro il prodotto', 'espressocoppola-child-theme' ); ?></p>
				<h2><?php echo esc_html( $context['display_blend'] ?: $product->get_name() ); ?></h2>
			</header>

			<?php if ( $context['description'] ) : ?>
				<div class="ec-product-details__copy">
					<?php echo $context['description']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
			<?php endif; ?>

			<div class="ec-product-details__facts">
				<div class="ec-product-details__fact">
					<dt><?php esc_html_e( 'Tipologia', 'espressocoppola-child-theme' ); ?></dt>
					<dd><?php echo esc_html( implode( ', ', wp_list_pluck( $context['types'], 'name' ) ) ?: __( 'Caffè Artigianale', 'espressocoppola-child-theme' ) ); ?></dd>
				</div>
				<?php if ( $context['display_blend'] ) : ?>
					<div class="ec-product-details__fact">
						<dt><?php esc_html_e( 'Miscela', 'espressocoppola-child-theme' ); ?></dt>
						<dd><?php echo esc_html( $context['display_blend'] ); ?></dd>
					</div>
				<?php endif; ?>
				<?php foreach ( $facts as $fact ) : ?>
					<div class="ec-product-details__fact">
						<dt><?php echo esc_html( $fact['name'] ); ?></dt>
						<dd><?php echo esc_html( implode( ' · ', $fact['values'] ) ); ?></dd>
					</div>
				<?php endforeach; ?>
				<?php if ( $product->get_sku() ) : ?>
					<div class="ec-product-details__fact">
						<dt><?php esc_html_e( 'Codice', 'espressocoppola-child-theme' ); ?></dt>
						<dd><?php echo esc_html( $product->get_sku() ); ?></dd>
					</div>
				<?php endif; ?>
			</div>
		</div>

		<div class="ec-product-details__aside">
			<div class="ec-product-details__aside-header">
				<p class="ec-product-details__eyebrow"><?php esc_html_e( 'Informazioni', 'espressocoppola-child-theme' ); ?></p>
				<h3><?php esc_html_e( 'Scheda tecnica & Servizi', 'espressocoppola-child-theme' ); ?></h3>
			</div>

			<div class="ec-product-details__items">
				<div class="ec-product-details__item">
					<h3>
						<button type="button" aria-expanded="true" aria-controls="ec-product-detail-general">
							<span><?php esc_html_e( 'Dettagli e Compatibilità', 'espressocoppola-child-theme' ); ?></span>
							<i aria-hidden="true">−</i>
						</button>
					</h3>
					<div id="ec-product-detail-general" data-accordion-panel>
						<dl>
							<div>
								<dt><?php esc_html_e( 'Tipologia', 'espressocoppola-child-theme' ); ?></dt>
								<dd><?php echo esc_html( implode( ', ', wp_list_pluck( $context['types'], 'name' ) ) ); ?></dd>
							</div>
							<?php if ( $product->get_sku() ) : ?>
								<div>
									<dt><?php esc_html_e( 'Codice SKU', 'espressocoppola-child-theme' ); ?></dt>
									<dd><?php echo esc_html( $product->get_sku() ); ?></dd>
								</div>
							<?php endif; ?>
							<div>
								<dt><?php esc_html_e( 'Disponibilità', 'espressocoppola-child-theme' ); ?></dt>
								<dd><?php echo esc_html( $product->is_in_stock() ? __( 'Disponibile in pronta consegna', 'espressocoppola-child-theme' ) : __( 'Non disponibile', 'espressocoppola-child-theme' ) ); ?></dd>
							</div>
							<div>
								<dt><?php esc_html_e( 'Conservazione', 'espressocoppola-child-theme' ); ?></dt>
								<dd><?php esc_html_e( 'In luogo fresco e asciutto, lontano da fonti di calore.', 'espressocoppola-child-theme' ); ?></dd>
							</div>
						</dl>
					</div>
				</div>

				<?php if ( $context['attributes'] ) : ?>
					<div class="ec-product-details__item">
						<h3>
							<button type="button" aria-expanded="false" aria-controls="ec-product-detail-format">
								<span><?php esc_html_e( 'Formato e Caratteristiche', 'espressocoppola-child-theme' ); ?></span>
								<i aria-hidden="true">+</i>
							</button>
						</h3>
						<div id="ec-product-detail-format" data-accordion-panel hidden>
							<dl>
								<?php foreach ( $context['attributes'] as $attribute ) : ?>
									<div>
										<dt><?php echo esc_html( $attribute['name'] ); ?></dt>
										<dd><?php echo esc_html( implode( ', ', $attribute['values'] ) ); ?></dd>
									</div>
								<?php endforeach; ?>
							</dl>
						</div>
					</div>
				<?php endif; ?>

				<div class="ec-product-details__item">
					<h3>
						<button type="button" aria-expanded="false" aria-controls="ec-product-detail-order">
							<span><?php esc_html_e( 'Spedizione e Consegna', 'espressocoppola-child-theme' ); ?></span>
							<i aria-hidden="true">+</i>
						</button>
					</h3>
					<div id="ec-product-detail-order" data-accordion-panel hidden>
						<p><?php esc_html_e( 'Spediamo con corriere espresso in tutta la Svizzera. I costi e i tempi esatti di consegna vengono calcolati al checkout in base al volume dell’ordine.', 'espressocoppola-child-theme' ); ?></p>
					</div>
				</div>

				<div class="ec-product-details__item">
					<h3>
						<button type="button" aria-expanded="false" aria-controls="ec-product-detail-quality">
							<span><?php esc_html_e( 'Qualità & Garanzia Coppola', 'espressocoppola-child-theme' ); ?></span>
							<i aria-hidden="true">+</i>
						</button>
					</h3>
					<div id="ec-product-detail-quality" data-accordion-panel hidden>
						<p><?php esc_html_e( 'Tostatura artigianale e confezionamento in atmosfera protettiva per preservare intatti gli aromi e la fragranza del vero espresso napoletano fino alla tazzina.', 'espressocoppola-child-theme' ); ?></p>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<?php if ( $context['related'] ) : ?>
	<section class="ec-product-related" data-product-related>
		<div class="ec-product-related__inner">
			<header>
				<p><?php esc_html_e( 'La collezione', 'espressocoppola-child-theme' ); ?></p>
				<h2><?php esc_html_e( 'Potrebbe piacerti anche', 'espressocoppola-child-theme' ); ?></h2>
			</header>
			<div class="ec-product-related__grid">
				<?php foreach ( $context['related'] as $related ) { get_template_part( 'template-parts/shop/product-card', null, array( 'product' => $related ) ); } ?>
			</div>
		</div>
	</section>
<?php endif; ?>
