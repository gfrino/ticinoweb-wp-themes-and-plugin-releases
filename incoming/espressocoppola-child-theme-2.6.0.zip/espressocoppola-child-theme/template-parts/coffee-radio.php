<?php
/**
 * Global floating player for the Espresso Coppola listening ritual.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$audio_url = get_stylesheet_directory_uri() . '/assets/audio/na-tazzulella-e-cafe.m4a';
?>
<div
	class="ec-radio-shell"
	data-coffee-radio
	data-state="idle"
	data-radio-play-label="<?php esc_attr_e( 'Riproduci', 'espressocoppola-child-theme' ); ?>"
	data-radio-pause-label="<?php esc_attr_e( 'Pausa', 'espressocoppola-child-theme' ); ?>"
	data-radio-play-aria="<?php esc_attr_e( 'Riproduci Na tazzulella ’e cafè', 'espressocoppola-child-theme' ); ?>"
	data-radio-pause-aria="<?php esc_attr_e( 'Metti in pausa Na tazzulella ’e cafè', 'espressocoppola-child-theme' ); ?>"
	data-radio-message-idle="<?php esc_attr_e( 'Premi play e prenditi il tempo di un caffè.', 'espressocoppola-child-theme' ); ?>"
	data-radio-message-loading="<?php esc_attr_e( 'La puntina sta cercando il solco…', 'espressocoppola-child-theme' ); ?>"
	data-radio-message-playing="<?php esc_attr_e( 'In riproduzione · Pino Daniele, 1977', 'espressocoppola-child-theme' ); ?>"
	data-radio-message-paused="<?php esc_attr_e( 'In pausa. Il caffè può aspettare un momento.', 'espressocoppola-child-theme' ); ?>"
	data-radio-message-ended="<?php esc_attr_e( 'Il disco è finito. Puoi rimetterlo su quando vuoi.', 'espressocoppola-child-theme' ); ?>"
	data-radio-message-error="<?php esc_attr_e( 'Il brano non è disponibile. Controlla la connessione e riprova.', 'espressocoppola-child-theme' ); ?>"
>
	<button
		class="ec-radio-pill"
		type="button"
		data-radio-open
		aria-expanded="false"
		aria-controls="espresso-coppola-radio"
	>
		<span class="ec-radio-pill__disc" aria-hidden="true"><span></span></span>
		<span class="ec-radio-pill__copy">
			<small><?php esc_html_e( 'Coppola Radio', 'espressocoppola-child-theme' ); ?></small>
			<strong><?php esc_html_e( 'Ascolta Napoli', 'espressocoppola-child-theme' ); ?></strong>
		</span>
		<span class="ec-radio-pill__signal" aria-hidden="true">
			<i></i><i></i><i></i>
		</span>
	</button>

	<section
		id="espresso-coppola-radio"
		class="ec-radio-player"
		aria-labelledby="ec-radio-title"
		hidden
	>
		<audio class="ec-radio-media" data-radio-media preload="none" hidden>
			<source src="<?php echo esc_url( $audio_url ); ?>" type="audio/mp4">
		</audio>

		<header class="ec-radio-player__header">
			<div>
				<p><?php esc_html_e( 'Coppola Radio', 'espressocoppola-child-theme' ); ?></p>
				<span><?php esc_html_e( 'Napoli, 1977', 'espressocoppola-child-theme' ); ?></span>
			</div>
			<button class="ec-radio-close" type="button" data-radio-close aria-label="<?php esc_attr_e( 'Chiudi e metti in pausa', 'espressocoppola-child-theme' ); ?>">×</button>
		</header>

		<div class="ec-radio-player__stage">
			<div class="ec-radio-record" aria-hidden="true">
				<span class="ec-radio-record__saucer"></span>
				<span class="ec-radio-record__grooves"></span>
				<span class="ec-radio-record__cup">
					<span class="ec-radio-record__coffee"></span>
					<span class="ec-radio-record__shine"></span>
				</span>
				<span class="ec-radio-record__handle"></span>
			</div>

			<div class="ec-radio-steam" aria-hidden="true" data-radio-visualizer>
				<?php for ( $bar = 0; $bar < 11; $bar++ ) : ?>
					<i style="--bar-index: <?php echo esc_attr( $bar ); ?>"></i>
				<?php endfor; ?>
			</div>
		</div>

		<div class="ec-radio-player__copy">
			<p><?php esc_html_e( 'Un espresso da ascoltare', 'espressocoppola-child-theme' ); ?></p>
			<h2 id="ec-radio-title">Na tazzulella <em>’e cafè</em></h2>
			<span><?php esc_html_e( 'Pino Daniele', 'espressocoppola-child-theme' ); ?></span>
		</div>

		<div class="ec-radio-controls">
			<button class="ec-radio-play" type="button" data-radio-toggle aria-label="<?php esc_attr_e( 'Riproduci Na tazzulella ’e cafè', 'espressocoppola-child-theme' ); ?>">
				<span class="ec-radio-play__icon" aria-hidden="true"></span>
				<span data-radio-toggle-label><?php esc_html_e( 'Riproduci', 'espressocoppola-child-theme' ); ?></span>
			</button>

			<div class="ec-radio-timeline">
				<input
					type="range"
					min="0"
					max="1000"
					value="0"
					step="1"
					data-radio-progress
					aria-label="<?php esc_attr_e( 'Posizione del brano', 'espressocoppola-child-theme' ); ?>"
				>
				<div class="ec-radio-time" aria-hidden="true">
					<span data-radio-current>0:00</span>
					<span data-radio-duration>0:00</span>
				</div>
			</div>
		</div>

		<p class="ec-radio-status" data-radio-status role="status" aria-live="polite">
			<?php esc_html_e( 'Premi play e prenditi il tempo di un caffè.', 'espressocoppola-child-theme' ); ?>
		</p>
	</section>
</div>
