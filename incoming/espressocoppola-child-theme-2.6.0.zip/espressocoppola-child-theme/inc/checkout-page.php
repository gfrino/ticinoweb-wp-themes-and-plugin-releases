<?php
/**
 * Data adapter and page helpers for the WooCommerce Checkout page.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Whether the current page is the WooCommerce Checkout page.
 * Detects standard WooCommerce checkout, Gutenberg block checkout, shortcode, and checkout slugs.
 *
 * @return bool
 */
function espressocoppola_is_checkout_page() {
	if ( function_exists( 'is_checkout' ) && is_checkout() && ! is_order_received_page() ) {
		return true;
	}

	global $post;
	if ( $post instanceof WP_Post ) {
		if ( has_block( 'woocommerce/checkout', $post ) || has_shortcode( $post->post_content, 'woocommerce_checkout' ) ) {
			return true;
		}
		if ( 'cassa' === $post->post_name || 'checkout' === $post->post_name ) {
			return true;
		}
	}

	return false;
}

/**
 * Add a stable body class for checkout styling.
 *
 * @param string[] $classes Body classes.
 * @return string[]
 */
function espressocoppola_checkout_body_class( $classes ) {
	if ( espressocoppola_is_checkout_page() ) {
		$classes[] = 'espresso-coppola-checkout';
	}

	return $classes;
}
add_filter( 'body_class', 'espressocoppola_checkout_body_class' );
