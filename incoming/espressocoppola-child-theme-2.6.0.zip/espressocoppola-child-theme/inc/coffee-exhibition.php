<?php
/**
 * Data adapter and dynamic composition engine for the Coffee Exhibition page.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Gallery managed by ticinoWEB Media Galleries Manager. */
const ESPRESSOCOPPOLA_EXHIBITION_GALLERY_ID = 58;

/**
 * Whether the current page uses the Coffee Exhibition template.
 *
 * @return bool
 */
function espressocoppola_is_exhibition_page() {
	return is_page_template( 'page-templates/coffee-exhibition.php' );
}

/**
 * Return valid image attachment IDs in the exact order saved by ticinoWEB.
 *
 * Attachments that are associated with the gallery but not yet present in the
 * saved order are appended using the same query order used by the CMS manager.
 *
 * @param int $gallery_id ticinoWEB media gallery term ID.
 * @return array<int,int>
 */
function espressocoppola_get_exhibition_gallery_image_ids( $gallery_id = ESPRESSOCOPPOLA_EXHIBITION_GALLERY_ID ) {
	$gallery_id = absint( $gallery_id );
	if ( ! $gallery_id || ! taxonomy_exists( 'ticinoweb_media_gallery' ) ) {
		return array();
	}

	$term = get_term( $gallery_id, 'ticinoweb_media_gallery' );
	if ( ! $term || is_wp_error( $term ) ) {
		return array();
	}

	$queried_ids = get_posts(
		array(
			'post_type'              => 'attachment',
			'post_status'            => 'inherit',
			'post_mime_type'         => 'image',
			'posts_per_page'         => 500,
			'fields'                 => 'ids',
			'no_found_rows'          => true,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
			'tax_query'              => array(
				array(
					'taxonomy' => 'ticinoweb_media_gallery',
					'field'    => 'term_id',
					'terms'    => $gallery_id,
				),
			),
		)
	);

	$queried_ids = array_values( array_unique( array_map( 'absint', $queried_ids ) ) );
	$saved_order = get_term_meta( $gallery_id, '_ticinoweb_gallery_order', true );
	$saved_order = is_array( $saved_order ) ? array_values( array_unique( array_map( 'absint', $saved_order ) ) ) : array();
	$ordered_ids = array_values( array_intersect( $saved_order, $queried_ids ) );

	foreach ( $queried_ids as $attachment_id ) {
		if ( ! in_array( $attachment_id, $ordered_ids, true ) ) {
			$ordered_ids[] = $attachment_id;
		}
	}

	return $ordered_ids;
}

/**
 * Serialize one attachment without inventing editorial metadata.
 *
 * @param int $attachment_id Attachment ID.
 * @param int $index         Zero-based position in the CMS gallery.
 * @param int $total         Total valid gallery images.
 * @return array<string,mixed>|null
 */
function espressocoppola_serialize_exhibition_image( $attachment_id, $index, $total ) {
	$attachment_id = absint( $attachment_id );
	$metadata      = wp_get_attachment_metadata( $attachment_id );
	$full          = wp_get_attachment_image_src( $attachment_id, 'full' );

	if ( ! $attachment_id || ! is_array( $metadata ) || ! $full ) {
		return null;
	}

	$width  = max( 1, (int) ( $metadata['width'] ?? $full[1] ) );
	$height = max( 1, (int) ( $metadata['height'] ?? $full[2] ) );
	$alt    = trim( (string) get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ) );

	return array(
		'id'          => $attachment_id,
		'index'       => (int) $index,
		'number'      => (int) $index + 1,
		'total'       => (int) $total,
		'alt'         => $alt,
		'title'       => get_the_title( $attachment_id ),
		'width'       => $width,
		'height'      => $height,
		'ratio'       => round( $width / $height, 3 ),
		'orientation' => $width > $height * 1.2 ? 'landscape' : ( $height > $width * 1.2 ? 'portrait' : 'square' ),
		'lightboxUrl' => wp_get_attachment_image_url( $attachment_id, '1536x1536' ) ?: $full[0],
		'lightboxSet' => wp_get_attachment_image_srcset( $attachment_id, '1536x1536' ) ?: '',
	);
}

/**
 * Return all valid gallery images in CMS order.
 *
 * @param int $gallery_id ticinoWEB media gallery term ID.
 * @return array<int,array<string,mixed>>
 */
function espressocoppola_get_exhibition_gallery_images( $gallery_id = ESPRESSOCOPPOLA_EXHIBITION_GALLERY_ID ) {
	$ids    = espressocoppola_get_exhibition_gallery_image_ids( $gallery_id );
	$total  = count( $ids );
	$images = array();

	foreach ( $ids as $index => $attachment_id ) {
		$image = espressocoppola_serialize_exhibition_image( $attachment_id, $index, $total );
		if ( $image ) {
			$images[] = $image;
		}
	}

	// Recalculate positions if an invalid attachment was filtered out.
	$total = count( $images );
	foreach ( $images as $index => &$image ) {
		$image['index']  = $index;
		$image['number'] = $index + 1;
		$image['total']  = $total;
	}
	unset( $image );

	return $images;
}

/**
 * Build an ordered exhibition sequence without duplicating gallery images.
 *
 * @param array<int,array<string,mixed>> $images Serialized gallery images.
 * @return array<int,array<string,mixed>>
 */
function espressocoppola_build_exhibition_sequence( $images ) {
	$images = array_values( $images );
	if ( ! $images ) {
		return array();
	}

	$sequence = array(
		array(
			'type'   => 'hero',
			'images' => array( array_shift( $images ) ),
		),
	);

	if ( ! $images ) {
		return $sequence;
	}

	$closing = count( $images ) > 1 ? array_pop( $images ) : null;
	$patterns = array(
		array( 'type' => 'solo', 'size' => 1 ),
		array( 'type' => 'duo', 'size' => 2 ),
		array( 'type' => 'triptych', 'size' => 3 ),
		array( 'type' => 'suspended', 'size' => 1 ),
		array( 'type' => 'stack', 'size' => 3 ),
		array( 'type' => 'double', 'size' => 2 ),
		array( 'type' => 'cinematic', 'size' => 1 ),
	);
	$pauses = array(
		array( 'eyebrow' => 'Essenza Napoletana', 'title' => 'Il caffè, in ogni sua forma.' ),
		array( 'eyebrow' => 'Espresso Coppola', 'title' => 'Un rituale. Molte espressioni.' ),
		array( 'eyebrow' => 'Dal chicco alla tazza', 'title' => 'Il gusto prende forma.' ),
	);

	$cursor          = 0;
	$pattern_index   = 0;
	$pause_index     = 0;
	$since_pause     = 0;
	$content_total   = count( $images );
	$sticky_at       = max( 3, (int) floor( $content_total * 0.25 ) );
	$panorama_at     = max( $sticky_at + 3, (int) floor( $content_total * 0.5 ) );
	$sticky_inserted = false;
	$panorama_inserted = false;

	while ( $cursor < $content_total ) {
		$remaining = $content_total - $cursor;

		if ( ! $sticky_inserted && $cursor >= $sticky_at && $remaining >= 3 ) {
			$sequence[] = array( 'type' => 'sticky', 'images' => array_slice( $images, $cursor, 3 ) );
			$cursor += 3;
			$since_pause += 3;
			$sticky_inserted = true;
		} elseif ( ! $panorama_inserted && $cursor >= $panorama_at ) {
			$sequence[] = array( 'type' => 'panorama', 'images' => array( $images[ $cursor ] ) );
			++$cursor;
			++$since_pause;
			$panorama_inserted = true;
		} else {
			$pattern = $patterns[ $pattern_index % count( $patterns ) ];
			$size    = min( $pattern['size'], $remaining );
			$type    = $size < $pattern['size'] ? ( 1 === $size ? 'solo' : 'duo' ) : $pattern['type'];
			$sequence[] = array( 'type' => $type, 'images' => array_slice( $images, $cursor, $size ) );
			$cursor += $size;
			$since_pause += $size;
			++$pattern_index;
		}

		if ( $since_pause >= 5 && $cursor < $content_total ) {
			$sequence[] = array(
				'type'   => 'pause',
				'images' => array(),
				'copy'   => $pauses[ $pause_index % count( $pauses ) ],
			);
			$since_pause = 0;
			++$pause_index;
		}
	}

	if ( $closing ) {
		$sequence[] = array( 'type' => 'closing', 'images' => array( $closing ) );
	}

	return $sequence;
}

/**
 * Assemble page data from CMS gallery, page content and WooCommerce routes.
 *
 * @param int $page_id Current page ID.
 * @return array<string,mixed>
 */
function espressocoppola_get_exhibition_page_context( $page_id ) {
	$images   = espressocoppola_get_exhibition_gallery_images();
	$sequence = espressocoppola_build_exhibition_sequence( $images );
	$shop_url = function_exists( 'espressocoppola_get_header_shop_url' ) ? espressocoppola_get_header_shop_url() : home_url( '/shop/' );
	$dna_page = get_posts(
		array(
			'post_type'      => 'page',
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			'meta_key'       => '_wp_page_template',
			'meta_value'     => 'page-templates/dna-delle-miscele.php',
			'fields'         => 'ids',
		)
	);

	return array(
		'title'       => get_the_title( $page_id ) ?: __( 'Coffee Exhibition', 'espressocoppola-child-theme' ),
		'intro'       => trim( get_the_excerpt( $page_id ) ) ?: __( 'Un viaggio visivo tra miscele, rituali e diverse forme di vivere il caffè.', 'espressocoppola-child-theme' ),
		'galleryId'   => ESPRESSOCOPPOLA_EXHIBITION_GALLERY_ID,
		'images'      => $images,
		'sequence'    => $sequence,
		'total'       => count( $images ),
		'shopUrl'     => $shop_url,
		'dnaUrl'      => $dna_page ? get_permalink( $dna_page[0] ) : '',
		'isEmpty'     => empty( $images ),
	);
}
