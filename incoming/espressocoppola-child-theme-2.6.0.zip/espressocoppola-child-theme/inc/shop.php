<?php
/**
 * Premium WooCommerce shop adapters and AJAX filtering.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return whether the current request is the main WooCommerce shop archive.
 *
 * @return bool
 */
function espressocoppola_is_shop_page() {
	return function_exists( 'is_shop' ) && is_shop();
}

/**
 * Use the child-theme shop template without affecting taxonomy archives.
 *
 * @param string $template Located template.
 * @return string
 */
function espressocoppola_shop_template( $template ) {
	if ( ! espressocoppola_is_shop_page() ) {
		return $template;
	}

	$child_template = get_stylesheet_directory() . '/shop.php';
	return file_exists( $child_template ) ? $child_template : $template;
}
add_filter( 'template_include', 'espressocoppola_shop_template', 99 );

/**
 * Redirect standard WooCommerce category archives to the custom shop with the corresponding type filter.
 *
 * @return void
 */
function espressocoppola_redirect_taxonomy_archives() {
	if ( is_admin() || wp_doing_ajax() ) {
		return;
	}

	if ( function_exists( 'is_product_category' ) && is_product_category() ) {
		$term = get_queried_object();
		if ( $term && is_a( $term, 'WP_Term' ) ) {
			$slug = $term->slug;
			$type_map = array(
				'cialde'        => 'cialde-ese-44',
				'cialde-ese-44' => 'cialde-ese-44',
				'capsule'       => 'capsule',
				'dolce-gusto'   => 'dolce-gusto',
				'nespresso'     => 'nespresso',
				'a-modo-mio'    => 'a-modo-mio',
				'chicchi'       => 'chicchi',
				'macinato'      => 'macinato',
				'accessori'     => 'accessori',
				'buste'         => 'buste',
			);

			$target_type = isset( $type_map[ $slug ] ) ? $type_map[ $slug ] : $slug;
			$shop_url    = function_exists( 'espressocoppola_get_header_shop_url' ) ? espressocoppola_get_header_shop_url() : home_url( '/shop/' );
			$redirect    = add_query_arg( 'type', $target_type, $shop_url );

			wp_safe_redirect( $redirect, 301 );
			exit;
		}
	}
}
add_action( 'template_redirect', 'espressocoppola_redirect_taxonomy_archives' );

/**
 * Convert one product's real categories into editorial shop filters.
 *
 * @param WC_Product $product Product instance.
 * @return array<int,array{slug:string,name:string}>
 */
function espressocoppola_get_shop_product_types( $product ) {
	$preparation = espressocoppola_get_product_preparation_data( $product );
	$types       = array();

	foreach ( $preparation['preparations'] as $preparation_key ) {
		if ( 'capsule' === $preparation_key && ! empty( $preparation['systems'] ) ) {
			foreach ( $preparation['systems'] as $system ) {
				$haystack = sanitize_title( remove_accents( $system['slug'] . '-' . $system['name'] ) );
				if ( false !== strpos( $haystack, 'dolce-gusto' ) ) {
					$slug = 'dolce-gusto';
					$name = __( 'Capsule Dolce Gusto', 'espressocoppola-child-theme' );
				} elseif ( false !== strpos( $haystack, 'modo-mio' ) ) {
					$slug = 'a-modo-mio';
					$name = __( 'Capsule A Modo Mio', 'espressocoppola-child-theme' );
				} elseif ( false !== strpos( $haystack, 'nespresso' ) ) {
					$slug = 'nespresso';
					$name = __( 'Capsule Nespresso', 'espressocoppola-child-theme' );
				} else {
					$slug = sanitize_title( $system['slug'] );
					$name = sprintf( __( 'Capsule %s', 'espressocoppola-child-theme' ), $system['name'] );
				}
				$types[ $slug ] = array( 'slug' => $slug, 'name' => $name );
			}
			continue;
		}

		$labels = array(
			'cialde'   => __( 'Cialde ESE 44', 'espressocoppola-child-theme' ),
			'capsule'  => __( 'Capsule', 'espressocoppola-child-theme' ),
			'chicchi'  => __( 'Caffè in grani', 'espressocoppola-child-theme' ),
			'macinato' => __( 'Caffè macinato Moka', 'espressocoppola-child-theme' ),
		);
		$slug = 'cialde' === $preparation_key ? 'cialde-ese-44' : $preparation_key;
		if ( isset( $labels[ $preparation_key ] ) ) {
			$types[ $slug ] = array( 'slug' => $slug, 'name' => $labels[ $preparation_key ] );
		}
	}

	if ( empty( $types ) ) {
		$types['accessori'] = array(
			'slug' => 'accessori',
			'name' => __( 'Accessori', 'espressocoppola-child-theme' ),
		);
	}

	return array_values( $types );
}

/**
 * Return normalized blends assigned to one product.
 *
 * @param WC_Product $product Product instance.
 * @param string     $taxonomy Existing blend taxonomy.
 * @return array<int,array<string,string>>
 */
function espressocoppola_get_shop_product_blends( $product, $taxonomy ) {
	$blends = array();
	if ( $taxonomy && taxonomy_exists( $taxonomy ) ) {
		$terms = wc_get_product_terms( $product->get_id(), $taxonomy, array( 'fields' => 'all' ) );
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $term ) {
				$data = espressocoppola_get_blend_editorial_data( $term->slug, $term->name );
				$blends[ $data['slug'] ] = $data;
			}
		}
	}

	if ( empty( $blends ) ) {
		foreach ( espressocoppola_get_product_fallback_blends( $product ) as $blend ) {
			$blends[ $blend['slug'] ] = $blend;
		}
	}

	return array_values( $blends );
}

/**
 * Serialize a published catalog product for the shop UI.
 *
 * @param WC_Product $product Product instance.
 * @param string     $blend_taxonomy Blend taxonomy.
 * @return array<string,mixed>
 */
function espressocoppola_serialize_shop_product( $product, $blend_taxonomy ) {
	$types   = espressocoppola_get_shop_product_types( $product );
	$blends  = espressocoppola_get_shop_product_blends( $product, $blend_taxonomy );
	$profile = espressocoppola_get_product_sensory_profile( $product );
	$status  = espressocoppola_get_sensory_profile_status( $profile );
	$image_id = $product->get_image_id();
	$formats  = espressocoppola_get_product_formats( $product, $blend_taxonomy );
	$summary  = wp_trim_words( wp_strip_all_tags( $product->get_short_description() ), 15 );

	return array(
		'id'          => $product->get_id(),
		'name'        => $product->get_name(),
		'url'         => get_permalink( $product->get_id() ),
		'imageId'     => $image_id,
		'image'       => $image_id ? wp_get_attachment_image_url( $image_id, 'woocommerce_thumbnail' ) : wc_placeholder_img_src( 'woocommerce_thumbnail' ),
		'priceHtml'   => $product->get_price_html(),
		'priceValue'  => (float) wc_get_price_to_display( $product ),
		'summary'     => $summary,
		'types'       => $types,
		'blends'      => $blends,
		'formats'     => $formats,
		'sensory'     => $status['complete'] && $profile['enabled'] ? array(
			'values' => array_values( $profile['values'] ),
			'note'   => $profile['note'],
			'color'  => $profile['color'],
		) : null,
		'isAccessory' => 1 === count( $types ) && 'accessori' === $types[0]['slug'],
	);
}

/**
 * Return request-cached, real WooCommerce products for the shop.
 *
 * @return array<int,array<string,mixed>>
 */
function espressocoppola_get_shop_catalog() {
	if ( isset( $GLOBALS['espressocoppola_shop_catalog'] ) ) {
		return $GLOBALS['espressocoppola_shop_catalog'];
	}

	$objects = wc_get_products(
		array(
			'status'     => 'publish',
			'visibility' => 'visible',
			'limit'      => 200,
			'orderby'    => array( 'menu_order' => 'ASC', 'title' => 'ASC' ),
			'return'     => 'objects',
		)
	);
	$taxonomy = espressocoppola_get_blend_taxonomy();
	$catalog  = array();
	foreach ( $objects as $product ) {
		if ( $product instanceof WC_Product && $product->is_visible() ) {
			$catalog[] = espressocoppola_serialize_shop_product( $product, $taxonomy );
		}
	}
	$GLOBALS['espressocoppola_shop_catalog'] = $catalog;
	return $catalog;
}

/**
 * Build non-empty filter options from the serialized catalog.
 *
 * @param array<int,array<string,mixed>> $catalog Shop catalog.
 * @return array<string,array<int,array<string,mixed>>>
 */
function espressocoppola_get_shop_filter_options( $catalog ) {
	$types = array();
	$blends = array();
	foreach ( $catalog as $product ) {
		foreach ( $product['types'] as $type ) {
			if ( ! isset( $types[ $type['slug'] ] ) ) {
				$types[ $type['slug'] ] = $type + array( 'count' => 0 );
			}
			++$types[ $type['slug'] ]['count'];
		}
		foreach ( $product['blends'] as $blend ) {
			if ( ! isset( $blends[ $blend['slug'] ] ) ) {
				$blends[ $blend['slug'] ] = $blend + array( 'count' => 0 );
			}
			++$blends[ $blend['slug'] ]['count'];
		}
	}
	return array( 'types' => array_values( $types ), 'blends' => array_values( $blends ) );
}

/**
 * Sanitize public shop filter state.
 *
 * @param array<string,mixed> $raw Raw request data.
 * @return array<string,mixed>
 */
function espressocoppola_sanitize_shop_filters( $raw ) {
	$axes = array_keys( espressocoppola_get_sensory_axes() );
	$sensory = array();
	foreach ( $axes as $axis ) {
		$value = isset( $raw['sensory'][ $axis ] ) ? absint( $raw['sensory'][ $axis ] ) : 0;
		if ( $value >= 1 && $value <= 5 ) {
			$sensory[ $axis ] = $value;
		}
	}
	$order = isset( $raw['order'] ) ? sanitize_key( $raw['order'] ) : 'menu_order';
	if ( ! in_array( $order, array( 'menu_order', 'date-desc', 'price-asc', 'price-desc' ), true ) ) {
		$order = 'menu_order';
	}
	return array(
		'types'   => array_values( array_unique( array_filter( array_map( 'sanitize_title', (array) ( $raw['types'] ?? array() ) ) ) ) ),
		'blends'  => array_values( array_unique( array_filter( array_map( 'sanitize_title', (array) ( $raw['blends'] ?? array() ) ) ) ) ),
		'sensory' => $sensory,
		'order'   => $order,
	);
}

/**
 * Filter and sort the small in-memory catalog.
 *
 * @param array<int,array<string,mixed>> $catalog Catalog.
 * @param array<string,mixed>            $filters Sanitized filters.
 * @return array<int,array<string,mixed>>
 */
function espressocoppola_filter_shop_catalog( $catalog, $filters ) {
	$filtered = array_filter(
		$catalog,
		static function ( $product ) use ( $filters ) {
			$type_slugs = wp_list_pluck( $product['types'], 'slug' );
			$blend_slugs = wp_list_pluck( $product['blends'], 'slug' );
			if ( $filters['types'] && ! array_intersect( $filters['types'], $type_slugs ) ) {
				return false;
			}
			if ( $filters['blends'] && ! array_intersect( $filters['blends'], $blend_slugs ) ) {
				return false;
			}
			if ( $filters['sensory'] ) {
				if ( empty( $product['sensory']['values'] ) ) {
					return false;
				}
				$axis_keys = array_keys( espressocoppola_get_sensory_axes() );
				foreach ( $filters['sensory'] as $axis => $minimum ) {
					$index = array_search( $axis, $axis_keys, true );
					if ( false === $index || (int) $product['sensory']['values'][ $index ] < $minimum ) {
						return false;
					}
				}
			}
			return true;
		}
	);
	if ( 'menu_order' !== $filters['order'] ) {
		usort(
			$filtered,
			static function ( $left, $right ) use ( $filters ) {
				if ( 'price-asc' === $filters['order'] ) return $left['priceValue'] <=> $right['priceValue'];
				if ( 'price-desc' === $filters['order'] ) return $right['priceValue'] <=> $left['priceValue'];
				return $right['id'] <=> $left['id'];
			}
		);
	}
	return array_values( $filtered );
}

/**
 * Render product cards for initial and AJAX requests.
 *
 * @param array<int,array<string,mixed>> $products Products.
 * @return string
 */
function espressocoppola_render_shop_cards( $products ) {
	ob_start();
	if ( empty( $products ) ) {
		?><div class="ec-shop__empty"><h2><?php esc_html_e( 'Nessun caffè trovato', 'espressocoppola-child-theme' ); ?></h2><p><?php esc_html_e( 'Riduci uno o più filtri per ritrovare la selezione.', 'espressocoppola-child-theme' ); ?></p></div><?php
	} else {
		foreach ( $products as $product ) {
			get_template_part( 'template-parts/shop/product-card', null, array( 'product' => $product ) );
		}
	}
	return (string) ob_get_clean();
}

/**
 * AJAX endpoint for public shop filters.
 *
 * @return void
 */
function espressocoppola_ajax_filter_shop() {
	check_ajax_referer( 'espressocoppola_shop_filter', 'nonce' );
	$raw = isset( $_POST['filters'] ) && is_array( $_POST['filters'] ) ? wp_unslash( $_POST['filters'] ) : array();
	$filters = espressocoppola_sanitize_shop_filters( $raw );
	$products = espressocoppola_filter_shop_catalog( espressocoppola_get_shop_catalog(), $filters );
	wp_send_json_success( array( 'count' => count( $products ), 'html' => espressocoppola_render_shop_cards( $products ) ) );
}
add_action( 'wp_ajax_espressocoppola_filter_shop', 'espressocoppola_ajax_filter_shop' );
add_action( 'wp_ajax_nopriv_espressocoppola_filter_shop', 'espressocoppola_ajax_filter_shop' );
