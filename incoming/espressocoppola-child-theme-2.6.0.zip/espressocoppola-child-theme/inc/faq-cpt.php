<?php
/**
 * Custom Post Type and Taxonomy registration for FAQ / Answer Atlas.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register the private, non-public Custom Post Type for FAQs.
 *
 * @return void
 */
function espressocoppola_register_faq_cpt() {
	$labels = array(
		'name'                  => _x( 'FAQ', 'Post Type General Name', 'espressocoppola-child-theme' ),
		'singular_name'         => _x( 'FAQ', 'Post Type Singular Name', 'espressocoppola-child-theme' ),
		'menu_name'             => __( 'FAQ', 'espressocoppola-child-theme' ),
		'name_admin_bar'        => __( 'FAQ', 'espressocoppola-child-theme' ),
		'all_items'             => __( 'Tutte le FAQ', 'espressocoppola-child-theme' ),
		'add_new_item'          => __( 'Aggiungi nuova FAQ', 'espressocoppola-child-theme' ),
		'add_new'               => __( 'Nuova FAQ', 'espressocoppola-child-theme' ),
		'new_item'              => __( 'Nuova FAQ', 'espressocoppola-child-theme' ),
		'edit_item'             => __( 'Modifica FAQ', 'espressocoppola-child-theme' ),
		'update_item'           => __( 'Aggiorna FAQ', 'espressocoppola-child-theme' ),
		'view_item'             => __( 'Visualizza FAQ', 'espressocoppola-child-theme' ),
		'search_items'          => __( 'Cerca tra le FAQ', 'espressocoppola-child-theme' ),
		'not_found'             => __( 'Nessuna FAQ trovata', 'espressocoppola-child-theme' ),
		'not_found_in_trash'    => __( 'Nessuna FAQ nel cestino', 'espressocoppola-child-theme' ),
	);

	$args = array(
		'label'                 => __( 'FAQ', 'espressocoppola-child-theme' ),
		'description'           => __( 'Archivio delle risposte e conoscenza Espresso Coppola (Answer Atlas).', 'espressocoppola-child-theme' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'page-attributes' ),
		'hierarchical'          => false,
		'public'                => false,
		'show_ui'               => ! espressocoppola_faq_on_parent(), // dopo la migrazione si modifica in Bacheca → FAQ
		'show_in_menu'          => true,
		'menu_position'         => 32,
		'menu_icon'             => 'dashicons-format-chat',
		'show_in_admin_bar'     => false,
		'show_in_nav_menus'     => false,
		'can_export'            => true,
		'has_archive'           => false,
		'exclude_from_search'   => true,
		'publicly_queryable'    => false,
		'query_var'             => false,
		'rewrite'               => false,
		'capability_type'       => 'post',
		'map_meta_cap'          => true,
		'show_in_rest'          => false,
	);

	register_post_type( 'ec_faq', $args );
}
add_action( 'init', 'espressocoppola_register_faq_cpt' );

/**
 * Register the hierarchical taxonomy for FAQ categories.
 *
 * @return void
 */
function espressocoppola_register_faq_taxonomy() {
	$labels = array(
		'name'                       => _x( 'Categorie FAQ', 'Taxonomy General Name', 'espressocoppola-child-theme' ),
		'singular_name'              => _x( 'Categoria FAQ', 'Taxonomy Singular Name', 'espressocoppola-child-theme' ),
		'menu_name'                  => __( 'Categorie', 'espressocoppola-child-theme' ),
		'all_items'                  => __( 'Tutte le Categorie', 'espressocoppola-child-theme' ),
		'parent_item'                => __( 'Categoria Genitore', 'espressocoppola-child-theme' ),
		'parent_item_colon'          => __( 'Categoria Genitore:', 'espressocoppola-child-theme' ),
		'new_item_name'              => __( 'Nuovo nome categoria', 'espressocoppola-child-theme' ),
		'add_new_item'               => __( 'Aggiungi nuova categoria', 'espressocoppola-child-theme' ),
		'edit_item'                  => __( 'Modifica categoria', 'espressocoppola-child-theme' ),
		'update_item'                => __( 'Aggiorna categoria', 'espressocoppola-child-theme' ),
		'view_item'                  => __( 'Visualizza categoria', 'espressocoppola-child-theme' ),
		'search_items'               => __( 'Cerca categorie', 'espressocoppola-child-theme' ),
		'not_found'                  => __( 'Nessuna categoria trovata', 'espressocoppola-child-theme' ),
	);

	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => true,
		'public'                     => false,
		'show_ui'                    => ! espressocoppola_faq_on_parent(),
		'show_admin_column'          => true,
		'show_in_nav_menus'          => false,
		'show_tagcloud'              => false,
		'rewrite'                    => false,
		'show_in_rest'               => false,
	);

	register_taxonomy( 'ec_faq_category', array( 'ec_faq' ), $args );
}
add_action( 'init', 'espressocoppola_register_faq_taxonomy' );
