<?php
/**
 * Custom Post Type registration and metadata schemas for Ho.Re.Ca. requests.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register the private, non-public Custom Post Type for Ho.Re.Ca. sample requests.
 *
 * @return void
 */
function espressocoppola_register_horeca_cpt() {
	$labels = array(
		'name'                  => _x( 'Ho.Re.Ca.', 'Post Type General Name', 'espressocoppola-child-theme' ),
		'singular_name'         => _x( 'Richiesta Ho.Re.Ca.', 'Post Type Singular Name', 'espressocoppola-child-theme' ),
		'menu_name'             => __( 'Ho.Re.Ca.', 'espressocoppola-child-theme' ),
		'name_admin_bar'        => __( 'Richiesta Ho.Re.Ca.', 'espressocoppola-child-theme' ),
		'all_items'             => __( 'Richieste', 'espressocoppola-child-theme' ),
		'add_new_item'          => __( 'Nuova Richiesta', 'espressocoppola-child-theme' ),
		'add_new'               => __( 'Aggiungi Richiesta', 'espressocoppola-child-theme' ),
		'new_item'              => __( 'Nuova Richiesta', 'espressocoppola-child-theme' ),
		'edit_item'             => __( 'Dettaglio Richiesta Ho.Re.Ca.', 'espressocoppola-child-theme' ),
		'update_item'           => __( 'Aggiorna Richiesta', 'espressocoppola-child-theme' ),
		'view_item'             => __( 'Visualizza Richiesta', 'espressocoppola-child-theme' ),
		'search_items'          => __( 'Cerca richieste Ho.Re.Ca.', 'espressocoppola-child-theme' ),
		'not_found'             => __( 'Nessuna richiesta trovata', 'espressocoppola-child-theme' ),
		'not_found_in_trash'    => __( 'Nessuna richiesta nel cestino', 'espressocoppola-child-theme' ),
	);

	$args = array(
		'label'                 => __( 'Richieste Ho.Re.Ca.', 'espressocoppola-child-theme' ),
		'description'           => __( 'Richieste campioni commerciali per il canale Ho.Re.Ca.', 'espressocoppola-child-theme' ),
		'labels'                => $labels,
		'supports'              => array( 'title' ),
		'hierarchical'          => false,
		'public'                => false,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 30,
		'menu_icon'             => 'dashicons-coffee',
		'show_in_admin_bar'     => false,
		'show_in_nav_menus'     => false,
		'can_export'            => true,
		'has_archive'           => false,
		'exclude_from_search'   => true,
		'publicly_queryable'    => false,
		'query_var'             => false,
		'rewrite'               => false,
		'capability_type'       => 'post',
		'map_meta_cap'          => true,
		'show_in_rest'          => false,
	);

	register_post_type( 'ec_horeca_request', $args );
}
add_action( 'init', 'espressocoppola_register_horeca_cpt' );

/**
 * Return valid statuses and localized labels for Ho.Re.Ca. requests.
 *
 * @return array<string,array{label:string,badge_class:string,color:string}>
 */
function espressocoppola_get_horeca_statuses() {
	return array(
		'new' => array(
			'label'       => __( 'Nuova', 'espressocoppola-child-theme' ),
			'badge_class' => 'status-new',
			'color'       => '#c8861e',
		),
		'contacted' => array(
			'label'       => __( 'Contattata', 'espressocoppola-child-theme' ),
			'badge_class' => 'status-contacted',
			'color'       => '#3b82f6',
		),
		'sample_sent' => array(
			'label'       => __( 'Campione inviato', 'espressocoppola-child-theme' ),
			'badge_class' => 'status-sample-sent',
			'color'       => '#10b981',
		),
		'closed' => array(
			'label'       => __( 'Chiusa', 'espressocoppola-child-theme' ),
			'badge_class' => 'status-closed',
			'color'       => '#64748b',
		),
	);
}
