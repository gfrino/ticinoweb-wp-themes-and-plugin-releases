<?php
/**
 * Backend Admin UI for FAQ / Answer Atlas.
 *
 * Clean, modern, native WordPress admin interface.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Remove default distracting meta boxes to keep the FAQ editor focused and clean.
 *
 * @return void
 */
function espressocoppola_faq_clean_admin_meta_boxes() {
	remove_meta_box( 'slugdiv', 'ec_faq', 'normal' );

	add_meta_box(
		'espressocoppola_faq_settings_box',
		__( 'Impostazioni & Configurazione Answer Atlas', 'espressocoppola-child-theme' ),
		'espressocoppola_render_faq_meta_box',
		'ec_faq',
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'espressocoppola_faq_clean_admin_meta_boxes' );

/**
 * Render the dedicated meta box for FAQ metadata.
 *
 * @param WP_Post $post Current post object.
 * @return void
 */
function espressocoppola_render_faq_meta_box( $post ) {
	wp_nonce_field( 'espressocoppola_save_faq_meta', 'ec_faq_meta_nonce' );

	$is_active              = get_post_meta( $post->ID, '_ec_faq_active', true );
	$is_featured            = get_post_meta( $post->ID, '_ec_faq_featured', true );
	$order                  = get_post_meta( $post->ID, '_ec_faq_order', true );
	$conversational_query   = get_post_meta( $post->ID, '_ec_faq_conversational_query', true );
	$related_url            = get_post_meta( $post->ID, '_ec_faq_related_url', true );
	$related_label          = get_post_meta( $post->ID, '_ec_faq_related_label', true );

	// Default values for new items
	if ( '' === $is_active && 'auto-draft' === $post->post_status ) {
		$is_active = '1';
	}
	$is_active   = ( '1' === (string) $is_active || '' === $is_active );
	$is_featured = ( '1' === (string) $is_featured );
	$order       = '' !== $order ? (int) $order : (int) $post->menu_order;
	?>
	<div class="ec-faq-admin-container" style="display:flex;flex-direction:column;gap:18px;padding:8px 4px;">
		<!-- Visibilità e Stato -->
		<div style="display:flex;flex-wrap:wrap;gap:28px;padding-bottom:14px;border-bottom:1px solid #e2e8f0;">
			<label style="display:inline-flex;align-items:center;gap:8px;font-weight:600;font-size:14px;cursor:pointer;">
				<input type="checkbox" name="ec_faq_active" value="1" <?php checked( $is_active, true ); ?> style="width:18px;height:18px;" />
				<span><?php esc_html_e( 'FAQ Attiva (visibile nella pagina frontend)', 'espressocoppola-child-theme' ); ?></span>
			</label>

			<label style="display:inline-flex;align-items:center;gap:8px;font-weight:600;font-size:14px;cursor:pointer;">
				<input type="checkbox" name="ec_faq_featured" value="1" <?php checked( $is_featured, true ); ?> style="width:18px;height:18px;" />
				<span style="color:#b45309;"><?php esc_html_e( '★ In Evidenza (partecipa all\'Answer Stream immersivo)', 'espressocoppola-child-theme' ); ?></span>
			</label>

			<div style="display:inline-flex;align-items:center;gap:8px;">
				<label for="ec_faq_order" style="font-weight:600;font-size:14px;"><?php esc_html_e( 'Ordine di visualizzazione:', 'espressocoppola-child-theme' ); ?></label>
				<input type="number" id="ec_faq_order" name="ec_faq_order" value="<?php echo esc_attr( (string) $order ); ?>" style="width:75px;padding:4px 8px;" />
			</div>
		</div>

		<!-- Query Conversazionale per Sezione 04 -->
		<div>
			<label for="ec_faq_conversational_query" style="display:block;font-weight:600;margin-bottom:6px;font-size:13px;color:#1e293b;">
				<?php esc_html_e( 'Query Conversazionale ("Chiedilo come lo chiederesti a noi")', 'espressocoppola-child-theme' ); ?>
			</label>
			<input type="text" id="ec_faq_conversational_query" name="ec_faq_conversational_query" value="<?php echo esc_attr( (string) $conversational_query ); ?>" placeholder="<?php esc_attr_e( 'Es: Qual è la miscela Espresso Coppola più intensa?', 'espressocoppola-child-theme' ); ?>" style="width:100%;max-width:680px;padding:6px 10px;font-size:14px;" />
			<p class="description" style="margin-top:4px;color:#64748b;">
				<?php esc_html_e( 'Mostrato nella sezione di ricerca conversazionale naturale della pagina. Se vuoto, viene utilizzata la domanda principale.', 'espressocoppola-child-theme' ); ?>
			</p>
		</div>

		<!-- Link di approfondimento correlato -->
		<div style="display:flex;flex-wrap:wrap;gap:18px;">
			<div style="flex:1;min-width:280px;max-width:440px;">
				<label for="ec_faq_related_url" style="display:block;font-weight:600;margin-bottom:6px;font-size:13px;color:#1e293b;">
					<?php esc_html_e( 'Link di approfondimento (opzionale)', 'espressocoppola-child-theme' ); ?>
				</label>
				<input type="url" id="ec_faq_related_url" name="ec_faq_related_url" value="<?php echo esc_attr( (string) $related_url ); ?>" placeholder="https://... o /shop/" style="width:100%;padding:6px 10px;" />
			</div>

			<div style="flex:1;min-width:200px;max-width:320px;">
				<label for="ec_faq_related_label" style="display:block;font-weight:600;margin-bottom:6px;font-size:13px;color:#1e293b;">
					<?php esc_html_e( 'Etichetta pulsante link', 'espressocoppola-child-theme' ); ?>
				</label>
				<input type="text" id="ec_faq_related_label" name="ec_faq_related_label" value="<?php echo esc_attr( (string) $related_label ); ?>" placeholder="<?php esc_attr_e( 'Es: Scopri nello Shop →', 'espressocoppola-child-theme' ); ?>" style="width:100%;padding:6px 10px;" />
			</div>
		</div>
	</div>
	<?php
}

/**
 * Save FAQ metadata on post save.
 *
 * @param int $post_id Post ID.
 * @return void
 */
function espressocoppola_save_faq_meta( $post_id ) {
	if ( ! isset( $_POST['ec_faq_meta_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['ec_faq_meta_nonce'] ), 'espressocoppola_save_faq_meta' ) ) {
		return;
	}

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	// Active status
	$active = isset( $_POST['ec_faq_active'] ) ? '1' : '0';
	update_post_meta( $post_id, '_ec_faq_active', $active );

	// Featured status
	$featured = isset( $_POST['ec_faq_featured'] ) ? '1' : '0';
	update_post_meta( $post_id, '_ec_faq_featured', $featured );

	// Order
	$order = isset( $_POST['ec_faq_order'] ) ? (int) $_POST['ec_faq_order'] : 0;
	update_post_meta( $post_id, '_ec_faq_order', $order );

	// Also sync menu_order on the post object for standard queries
	// Senza togliere l'hook, wp_update_post() rilancerebbe questo salvataggio all'infinito.
	remove_action( 'save_post_ec_faq', 'espressocoppola_save_faq_meta' );
	wp_update_post(
		array(
			'ID'         => $post_id,
			'menu_order' => $order,
		)
	);
	add_action( 'save_post_ec_faq', 'espressocoppola_save_faq_meta' );

	// Conversational Query
	if ( isset( $_POST['ec_faq_conversational_query'] ) ) {
		update_post_meta( $post_id, '_ec_faq_conversational_query', sanitize_text_field( wp_unslash( $_POST['ec_faq_conversational_query'] ) ) );
	}

	// Related URL
	if ( isset( $_POST['ec_faq_related_url'] ) ) {
		update_post_meta( $post_id, '_ec_faq_related_url', esc_url_raw( wp_unslash( $_POST['ec_faq_related_url'] ) ) );
	}

	// Related Label
	if ( isset( $_POST['ec_faq_related_label'] ) ) {
		update_post_meta( $post_id, '_ec_faq_related_label', sanitize_text_field( wp_unslash( $_POST['ec_faq_related_label'] ) ) );
	}
}
add_action( 'save_post_ec_faq', 'espressocoppola_save_faq_meta' );

/**
 * Define custom columns for the FAQ list table in wp-admin.
 *
 * @param array<string,string> $columns Existing columns.
 * @return array<string,string>
 */
function espressocoppola_faq_custom_columns( $columns ) {
	$new_columns = array(
		'cb'                      => $columns['cb'],
		'faq_status'              => __( 'Stato', 'espressocoppola-child-theme' ),
		'title'                   => __( 'Domanda', 'espressocoppola-child-theme' ),
		'taxonomy-ec_faq_category'=> __( 'Categoria', 'espressocoppola-child-theme' ),
		'faq_featured'            => __( 'In Evidenza', 'espressocoppola-child-theme' ),
		'faq_query'               => __( 'Query Conversazionale', 'espressocoppola-child-theme' ),
		'faq_order'               => __( 'Ordine', 'espressocoppola-child-theme' ),
		'date'                    => __( 'Data', 'espressocoppola-child-theme' ),
	);

	return $new_columns;
}
add_filter( 'manage_ec_faq_posts_columns', 'espressocoppola_faq_custom_columns' );

/**
 * Render custom column content for FAQs.
 *
 * @param string $column  Column name.
 * @param int    $post_id Post ID.
 * @return void
 */
function espressocoppola_faq_render_custom_columns( $column, $post_id ) {
	switch ( $column ) {
		case 'faq_status':
			$active = get_post_meta( $post_id, '_ec_faq_active', true );
			if ( '0' === (string) $active ) {
				echo '<span style="display:inline-block;padding:2px 8px;border-radius:999px;font-size:11px;font-weight:700;background:#f1f5f9;color:#64748b;">' . esc_html__( 'Disattivata', 'espressocoppola-child-theme' ) . '</span>';
			} else {
				echo '<span style="display:inline-block;padding:2px 8px;border-radius:999px;font-size:11px;font-weight:700;background:#ecfdf5;color:#047857;">' . esc_html__( 'Attiva ✓', 'espressocoppola-child-theme' ) . '</span>';
			}
			break;

		case 'faq_featured':
			$featured = get_post_meta( $post_id, '_ec_faq_featured', true );
			if ( '1' === (string) $featured ) {
				echo '<span style="display:inline-block;padding:2px 8px;border-radius:999px;font-size:11px;font-weight:750;background:#fef3c7;color:#92400e;">★ ' . esc_html__( 'Answer Stream', 'espressocoppola-child-theme' ) . '</span>';
			} else {
				echo '<span style="color:#94a3b8;">—</span>';
			}
			break;

		case 'faq_query':
			$query = get_post_meta( $post_id, '_ec_faq_conversational_query', true );
			if ( ! empty( $query ) ) {
				echo '<span style="font-style:italic;color:#334155;">“' . esc_html( $query ) . '”</span>';
			} else {
				echo '<span style="color:#94a3b8;">—</span>';
			}
			break;

		case 'faq_order':
			$order = get_post_meta( $post_id, '_ec_faq_order', true );
			echo '<strong style="color:#0f172a;">' . esc_html( '' !== $order ? (string) $order : '0' ) . '</strong>';
			break;
	}
}
add_action( 'manage_ec_faq_posts_custom_column', 'espressocoppola_faq_render_custom_columns', 10, 2 );

/**
 * Make custom columns sortable.
 *
 * @param array<string,string> $columns Sortable columns.
 * @return array<string,string>
 */
function espressocoppola_faq_sortable_columns( $columns ) {
	$columns['faq_order'] = 'menu_order';
	return $columns;
}
add_filter( 'manage_edit-ec_faq_sortable_columns', 'espressocoppola_faq_sortable_columns' );
