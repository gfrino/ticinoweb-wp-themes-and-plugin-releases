<?php
/**
 * AJAX Form Submission, Security, DB Persistence, and Notification Handler for Ho.Re.Ca. requests.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handle AJAX submission of the 3-step Ho.Re.Ca. sample request form.
 *
 * @return void
 */
function espressocoppola_handle_horeca_sample_submission() {
	// 1. Security Nonce Check
	check_ajax_referer( 'espressocoppola_horeca_nonce', 'nonce' );

	// 2. Invisible Honeypot Antispam Check
	if ( ! empty( $_POST['hp_coppola_field'] ) ) {
		// Silent exit with fake success for bots
		wp_send_json_success(
			array(
				'message' => __( 'Richiesta ricevuta con successo.', 'espressocoppola-child-theme' ),
			)
		);
		exit;
	}

	// 3. Rate-Limiting Protection (max 4 submissions per 10 minutes per IP)
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '127.0.0.1';
	$rate_limit_key   = 'ec_horeca_rl_' . md5( $ip );
	$submission_count = (int) get_transient( $rate_limit_key );

	if ( $submission_count >= 4 ) {
		wp_send_json_error(
			array(
				'message' => __( 'Hai inviato diverse richieste di recente. Attendi qualche minuto prima di riprovare.', 'espressocoppola-child-theme' ),
			),
			429
		);
		exit;
	}

	// 4. Server-Side Sanitization & Validation
	$errors = array();

	// Step 1: Attività
	$company        = isset( $_POST['company'] ) ? sanitize_text_field( wp_unslash( $_POST['company'] ) ) : '';
	$first_name     = isset( $_POST['first_name'] ) ? sanitize_text_field( wp_unslash( $_POST['first_name'] ) ) : '';
	$last_name      = isset( $_POST['last_name'] ) ? sanitize_text_field( wp_unslash( $_POST['last_name'] ) ) : '';
	$activity_type  = isset( $_POST['activity_type'] ) ? sanitize_text_field( wp_unslash( $_POST['activity_type'] ) ) : '';
	$activity_other = isset( $_POST['activity_other'] ) ? sanitize_text_field( wp_unslash( $_POST['activity_other'] ) ) : '';
	$city           = isset( $_POST['city'] ) ? sanitize_text_field( wp_unslash( $_POST['city'] ) ) : '';
	$postal_code    = isset( $_POST['postal_code'] ) ? sanitize_text_field( wp_unslash( $_POST['postal_code'] ) ) : '';
	$website        = isset( $_POST['website'] ) ? esc_url_raw( wp_unslash( $_POST['website'] ) ) : '';

	if ( empty( $company ) ) {
		$errors['company'] = __( 'Inserisci la ragione sociale o denominazione.', 'espressocoppola-child-theme' );
	}
	if ( empty( $first_name ) ) {
		$errors['first_name'] = __( 'Inserisci il nome del referente.', 'espressocoppola-child-theme' );
	}
	if ( empty( $last_name ) ) {
		$errors['last_name'] = __( 'Inserisci il cognome del referente.', 'espressocoppola-child-theme' );
	}
	if ( empty( $activity_type ) ) {
		$errors['activity_type'] = __( 'Seleziona la tipologia di attività.', 'espressocoppola-child-theme' );
	} elseif ( 'Altro' === $activity_type && empty( $activity_other ) ) {
		$errors['activity_other'] = __( 'Specifica la tipologia della tua attività.', 'espressocoppola-child-theme' );
	}
	if ( empty( $city ) ) {
		$errors['city'] = __( 'Inserisci la città della sede.', 'espressocoppola-child-theme' );
	}
	if ( empty( $postal_code ) ) {
		$errors['postal_code'] = __( 'Inserisci il CAP.', 'espressocoppola-child-theme' );
	}

	// Step 2: Consumo
	$monthly_volume = isset( $_POST['monthly_volume'] ) ? sanitize_text_field( wp_unslash( $_POST['monthly_volume'] ) ) : '';
	$coffee_system  = isset( $_POST['coffee_system'] ) ? sanitize_text_field( wp_unslash( $_POST['coffee_system'] ) ) : '';

	if ( empty( $monthly_volume ) ) {
		$errors['monthly_volume'] = __( 'Seleziona il quantitativo medio mensile stimato.', 'espressocoppola-child-theme' );
	}
	if ( empty( $coffee_system ) ) {
		$errors['coffee_system'] = __( 'Seleziona il sistema caffè utilizzato o desiderato.', 'espressocoppola-child-theme' );
	}

	// Step 3: Campione & Contatti Consegna
	$sample_blend   = isset( $_POST['sample_blend'] ) ? sanitize_text_field( wp_unslash( $_POST['sample_blend'] ) ) : '';
	$sample_prod_id = isset( $_POST['sample_product_id'] ) ? absint( $_POST['sample_product_id'] ) : 0;
	$email          = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	$phone          = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
	$ship_address   = isset( $_POST['shipping_address'] ) ? sanitize_text_field( wp_unslash( $_POST['shipping_address'] ) ) : '';
	$ship_postal    = isset( $_POST['shipping_postal_code'] ) ? sanitize_text_field( wp_unslash( $_POST['shipping_postal_code'] ) ) : '';
	$ship_city      = isset( $_POST['shipping_city'] ) ? sanitize_text_field( wp_unslash( $_POST['shipping_city'] ) ) : '';
	$ship_country   = isset( $_POST['shipping_country'] ) ? sanitize_text_field( wp_unslash( $_POST['shipping_country'] ) ) : 'Italia';
	$notes          = isset( $_POST['notes'] ) ? sanitize_textarea_field( wp_unslash( $_POST['notes'] ) ) : '';
	$privacy        = ! empty( $_POST['privacy_consent'] );

	if ( empty( $sample_blend ) ) {
		$errors['sample_blend'] = __( 'Seleziona la miscela di caffè che desideri provare.', 'espressocoppola-child-theme' );
	}
	if ( empty( $email ) || ! is_email( $email ) ) {
		$errors['email'] = __( 'Inserisci un indirizzo email valido.', 'espressocoppola-child-theme' );
	}
	if ( empty( $phone ) ) {
		$errors['phone'] = __( 'Inserisci un numero di telefono di riferimento.', 'espressocoppola-child-theme' );
	}
	if ( empty( $ship_address ) ) {
		$errors['shipping_address'] = __( 'Inserisci l\'indirizzo di consegna del campione.', 'espressocoppola-child-theme' );
	}
	if ( empty( $ship_postal ) ) {
		$errors['shipping_postal_code'] = __( 'Inserisci il CAP di consegna.', 'espressocoppola-child-theme' );
	}
	if ( empty( $ship_city ) ) {
		$errors['shipping_city'] = __( 'Inserisci la città di consegna.', 'espressocoppola-child-theme' );
	}
	if ( ! $privacy ) {
		$errors['privacy_consent'] = __( 'È necessario accettare l\'informativa sulla privacy per procedere.', 'espressocoppola-child-theme' );
	}

	// If validation failed, return detailed JSON errors
	if ( ! empty( $errors ) ) {
		wp_send_json_error(
			array(
				'message' => __( 'Verifica i campi evidenziati e riprova.', 'espressocoppola-child-theme' ),
				'fields'  => $errors,
			),
			422
		);
		exit;
	}

	// 5. Database Persistence (Custom Post Type)
	$post_title = sprintf( '%s — %s %s', $company, $first_name, $last_name );
	$post_id    = wp_insert_post(
		array(
			'post_type'   => 'ec_horeca_request',
			'post_title'  => $post_title,
			'post_status' => 'publish',
			'post_author' => 1,
		),
		true
	);

	if ( is_wp_error( $post_id ) ) {
		wp_send_json_error(
			array(
				'message' => __( 'Si è verificato un errore durante il salvataggio della richiesta. Ti invitiamo a riprovare o a contattarci direttamente.', 'espressocoppola-child-theme' ),
			),
			500
		);
		exit;
	}

	// Save all post meta
	update_post_meta( $post_id, '_horeca_company', $company );
	update_post_meta( $post_id, '_horeca_first_name', $first_name );
	update_post_meta( $post_id, '_horeca_last_name', $last_name );
	update_post_meta( $post_id, '_horeca_activity_type', $activity_type );
	update_post_meta( $post_id, '_horeca_activity_other', $activity_other );
	update_post_meta( $post_id, '_horeca_city', $city );
	update_post_meta( $post_id, '_horeca_postal_code', $postal_code );
	update_post_meta( $post_id, '_horeca_website', $website );

	update_post_meta( $post_id, '_horeca_monthly_volume', $monthly_volume );
	update_post_meta( $post_id, '_horeca_coffee_system', $coffee_system );
	update_post_meta( $post_id, '_horeca_sample_blend', $sample_blend );
	update_post_meta( $post_id, '_horeca_sample_product_id', $sample_prod_id );

	update_post_meta( $post_id, '_horeca_email', $email );
	update_post_meta( $post_id, '_horeca_phone', $phone );
	update_post_meta( $post_id, '_horeca_shipping_address', $ship_address );
	update_post_meta( $post_id, '_horeca_shipping_postal_code', $ship_postal );
	update_post_meta( $post_id, '_horeca_shipping_city', $ship_city );
	update_post_meta( $post_id, '_horeca_shipping_country', $ship_country );
	update_post_meta( $post_id, '_horeca_notes', $notes );

	update_post_meta( $post_id, '_horeca_privacy_accepted', current_time( 'mysql' ) );
	update_post_meta( $post_id, '_horeca_ip_hash', md5( $ip ) );
	update_post_meta( $post_id, '_horeca_status', 'new' );

	// Update rate limit transient
	set_transient( $rate_limit_key, $submission_count + 1, 10 * MINUTE_IN_SECONDS );

	// 6. Notification Emails (Safe execution: failure does not break the submission)
	espressocoppola_send_horeca_notification_emails( $post_id, array(
		'company'        => $company,
		'first_name'     => $first_name,
		'last_name'      => $last_name,
		'activity_type'  => $activity_type,
		'activity_other' => $activity_other,
		'city'           => $city,
		'postal_code'    => $postal_code,
		'website'        => $website,
		'monthly_volume' => $monthly_volume,
		'coffee_system'  => $coffee_system,
		'sample_blend'   => $sample_blend,
		'email'          => $email,
		'phone'          => $phone,
		'ship_address'   => $ship_address,
		'ship_postal'    => $ship_postal,
		'ship_city'      => $ship_city,
		'ship_country'   => $ship_country,
		'notes'          => $notes,
	) );

	wp_send_json_success(
		array(
			'message' => __( 'Richiesta ricevuta con successo. Abbiamo registrato la tua richiesta per il canale Ho.Re.Ca.', 'espressocoppola-child-theme' ),
			'company' => $company,
		)
	);
	exit;
}
add_action( 'wp_ajax_espressocoppola_submit_horeca_sample', 'espressocoppola_handle_horeca_sample_submission' );
add_action( 'wp_ajax_nopriv_espressocoppola_submit_horeca_sample', 'espressocoppola_handle_horeca_sample_submission' );

/**
 * Send internal and client confirmation emails for a new Ho.Re.Ca. request.
 *
 * @param int                  $post_id Request ID.
 * @param array<string,string> $data    Request data.
 * @return void
 */
function espressocoppola_send_horeca_notification_emails( $post_id, $data ) {
	// A. Internal Company Notification Email
	$admin_email = get_option( 'admin_email' );
	if ( function_exists( 'ticinoweb_get_contact_info' ) ) {
		$cms_contact = ticinoweb_get_contact_info();
		if ( ! empty( $cms_contact['email'] ) && is_email( $cms_contact['email'] ) ) {
			$admin_email = $cms_contact['email'];
		}
	}

	$backend_link = admin_url( 'post.php?post=' . $post_id . '&action=edit' );
	$internal_subject = sprintf( '[Ho.Re.Ca.] Nuova richiesta campione — %s', $data['company'] );

	$activity_display = $data['activity_type'];
	if ( 'Altro' === $data['activity_type'] && ! empty( $data['activity_other'] ) ) {
		$activity_display .= ' (' . $data['activity_other'] . ')';
	}

	$internal_body = "È stata ricevuta una nuova richiesta di campione commerciale Ho.Re.Ca. tramite il sito web:\n\n"
		. "────────────────────────────────────────\n"
		. "01 — ATTIVITÀ\n"
		. "────────────────────────────────────────\n"
		. "Azienda: " . $data['company'] . "\n"
		. "Referente: " . $data['first_name'] . " " . $data['last_name'] . "\n"
		. "Tipologia: " . $activity_display . "\n"
		. "Sede: " . $data['postal_code'] . " " . $data['city'] . "\n"
		. ( ! empty( $data['website'] ) ? "Sito Web: " . $data['website'] . "\n" : "" )
		. "\n"
		. "────────────────────────────────────────\n"
		. "02 — CONSUMO & CAMPIONE\n"
		. "────────────────────────────────────────\n"
		. "Consumo stimato: " . $data['monthly_volume'] . "\n"
		. "Sistema utilizzato: " . $data['coffee_system'] . "\n"
		. "Campione richiesto: " . $data['sample_blend'] . "\n"
		. "\n"
		. "────────────────────────────────────────\n"
		. "03 — CONTATTI & CONSEGNA\n"
		. "────────────────────────────────────────\n"
		. "Email: " . $data['email'] . "\n"
		. "Telefono: " . $data['phone'] . "\n"
		. "Indirizzo consegna: " . $data['ship_address'] . ", " . $data['ship_postal'] . " " . $data['ship_city'] . " (" . $data['ship_country'] . ")\n"
		. ( ! empty( $data['notes'] ) ? "Note: " . $data['notes'] . "\n" : "" )
		. "\n"
		. "────────────────────────────────────────\n"
		. "Gestisci la richiesta nel pannello di controllo:\n"
		. $backend_link . "\n";

	$headers = array( 'Content-Type: text/plain; charset=UTF-8' );
	if ( is_email( $data['email'] ) ) {
		$headers[] = 'Reply-To: ' . $data['first_name'] . ' ' . $data['last_name'] . ' <' . $data['email'] . '>';
	}

	wp_mail( $admin_email, $internal_subject, $internal_body, $headers );

	// B. Customer Confirmation Email
	if ( is_email( $data['email'] ) ) {
		$customer_subject = 'Richiesta Ho.Re.Ca. ricevuta — Espresso Coppola';
		$customer_body    = "Gentile " . $data['first_name'] . " " . $data['last_name'] . ",\n\n"
			. "grazie per l'interesse nei confronti di Espresso Coppola e delle nostre miscele dedicate al canale professionale.\n\n"
			. "Abbiamo ricevuto correttamente la tua richiesta per conto di \"" . $data['company'] . "\".\n\n"
			. "RIEPILOGO RICHIESTA:\n"
			. "• Tipologia attività: " . $activity_display . "\n"
			. "• Consumo stimato: " . $data['monthly_volume'] . "\n"
			. "• Sistema di preparazione: " . $data['coffee_system'] . "\n"
			. "• Campione selezionato: " . $data['sample_blend'] . "\n"
			. "• Indirizzo indicato: " . $data['ship_address'] . ", " . $data['ship_postal'] . " " . $data['ship_city'] . "\n\n"
			. "Il nostro team commerciale valuterà i dettagli indicati e si metterà in contatto con te per organizzare la prova e fornirti ogni informazione utile per la tua attività.\n\n"
			. "Cordiali saluti,\n"
			. "Espresso Coppola — Essenza Napoletana\n"
			. home_url( '/' ) . "\n";

		wp_mail( $data['email'], $customer_subject, $customer_body, array( 'Content-Type: text/plain; charset=UTF-8' ) );
	}
}
