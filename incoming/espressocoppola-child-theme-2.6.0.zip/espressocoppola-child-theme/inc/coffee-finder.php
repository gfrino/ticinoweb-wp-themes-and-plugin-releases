<?php
/**
 * Coffee Finder catalog normalization.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return the editorial macro-preparations supported by the Finder.
 *
 * @return array<string,array<string,string>>
 */
function espressocoppola_get_preparation_definitions() {
	return array(
		'cialde'   => array(
			'name'   => __( 'Cialde', 'espressocoppola-child-theme' ),
			'detail' => __( 'Compatibilità ESE 44', 'espressocoppola-child-theme' ),
		),
		'capsule'  => array(
			'name'   => __( 'Capsule', 'espressocoppola-child-theme' ),
			'detail' => __( 'Trova il tuo sistema', 'espressocoppola-child-theme' ),
		),
		'chicchi'  => array(
			'name'   => __( 'Chicchi', 'espressocoppola-child-theme' ),
			'detail' => __( 'Caffè in grani', 'espressocoppola-child-theme' ),
		),
		'macinato' => array(
			'name'   => __( 'Macinato', 'espressocoppola-child-theme' ),
			'detail' => __( 'Moka e caffè macinato', 'espressocoppola-child-theme' ),
		),
	);
}

/**
 * Classify a root-to-leaf WooCommerce category path.
 *
 * Hierarchy is already encoded by the order of the supplied path. Slug is
 * considered before the human name for every term.
 *
 * @param array<int,array<string,mixed>> $path Root-to-leaf category path.
 * @return array{preparation:string,system:string}
 */
function espressocoppola_classify_category_path( $path ) {
	$tokens = array();

	foreach ( $path as $term ) {
		$slug = isset( $term['slug'] ) ? sanitize_title( $term['slug'] ) : '';
		$name = isset( $term['name'] ) ? sanitize_title( remove_accents( $term['name'] ) ) : '';
		$tokens[] = trim( $slug . ' ' . $name );
	}

	$haystack = implode( ' ', $tokens );
	$empty    = array( 'preparation' => '', 'system' => '' );

	foreach ( array( 'accessori', 'accessorio', 'tazze', 'tazza', 'kit-monouso', 'monouso' ) as $excluded ) {
		if ( false !== strpos( $haystack, $excluded ) ) {
			return $empty;
		}
	}

	$preparation = '';
	if ( false !== strpos( $haystack, 'ciald' ) || false !== strpos( $haystack, 'ese-44' ) ) {
		$preparation = 'cialde';
	} elseif (
		false !== strpos( $haystack, 'capsul' ) ||
		false !== strpos( $haystack, 'nespresso' ) ||
		false !== strpos( $haystack, 'modo-mio' ) ||
		false !== strpos( $haystack, 'dolce-gusto' )
	) {
		$preparation = 'capsule';
	} elseif ( false !== strpos( $haystack, 'chicch' ) || false !== strpos( $haystack, 'grani' ) ) {
		$preparation = 'chicchi';
	} elseif ( false !== strpos( $haystack, 'macinat' ) || false !== strpos( $haystack, 'moka' ) ) {
		$preparation = 'macinato';
	}

	if ( 'capsule' !== $preparation ) {
		return array( 'preparation' => $preparation, 'system' => '' );
	}

	$system = '';
	foreach ( array_reverse( $path ) as $term ) {
		$slug = isset( $term['slug'] ) ? sanitize_title( $term['slug'] ) : '';
		$name = isset( $term['name'] ) ? sanitize_title( remove_accents( $term['name'] ) ) : '';
		if ( in_array( $slug, array( '', 'capsule', 'capsula', 'capsule-compatibili' ), true ) ) {
			continue;
		}
		if (
			false !== strpos( $slug . ' ' . $name, 'nespresso' ) ||
			false !== strpos( $slug . ' ' . $name, 'modo-mio' ) ||
			false !== strpos( $slug . ' ' . $name, 'dolce-gusto' ) ||
			count( $path ) > 1
		) {
			$system = $slug;
			break;
		}
	}

	return array( 'preparation' => $preparation, 'system' => $system );
}

/**
 * Build a root-to-leaf path for a product category term.
 *
 * @param WP_Term $term Product category.
 * @return array<int,array<string,mixed>>
 */
function espressocoppola_get_category_path( $term ) {
	$ids  = array_reverse( get_ancestors( $term->term_id, 'product_cat', 'taxonomy' ) );
	$ids[] = $term->term_id;
	$path = array();

	foreach ( $ids as $term_id ) {
		$path_term = get_term( $term_id, 'product_cat' );
		if ( $path_term instanceof WP_Term ) {
			$path[] = array(
				'id'   => $path_term->term_id,
				'name' => $path_term->name,
				'slug' => $path_term->slug,
			);
		}
	}

	return $path;
}

/**
 * Return normalized preparation and capsule-system data for a product.
 *
 * @param WC_Product $product Product instance.
 * @return array<string,array<int,mixed>>
 */
function espressocoppola_get_product_preparation_data( $product ) {
	$preparations = array();
	$systems      = array();
	$terms        = wc_get_product_terms( $product->get_id(), 'product_cat', array( 'fields' => 'all' ) );

	foreach ( $terms as $term ) {
		$path           = espressocoppola_get_category_path( $term );
		$classification = espressocoppola_classify_category_path( $path );

		if ( '' === $classification['preparation'] ) {
			continue;
		}

		$preparations[ $classification['preparation'] ] = $classification['preparation'];
		if ( '' !== $classification['system'] ) {
			$system_term = get_term_by( 'slug', $classification['system'], 'product_cat' );
			$systems[ $classification['system'] ] = array(
				'slug' => $classification['system'],
				'name' => $system_term instanceof WP_Term ? $system_term->name : ucwords( str_replace( '-', ' ', $classification['system'] ) ),
			);
		}
	}

	return array(
		'preparations' => array_values( $preparations ),
		'systems'      => array_values( $systems ),
	);
}

/**
 * Return editorial metadata for a normalized blend.
 *
 * @param string $slug Blend slug.
 * @param string $name Blend name.
 * @return array<string,string>
 */
function espressocoppola_get_blend_editorial_data( $slug, $name ) {
	$normalized = sanitize_title( remove_accents( $slug . '-' . $name ) );
	$data       = array(
		'slug'      => sanitize_title( $slug ),
		'name'      => $name,
		'character' => '',
		'notes'     => '',
	);

	if ( false !== strpos( $normalized, 'arabica' ) ) {
		$data['slug']      = 'arabica';
		$data['name']      = __( '100% Arabica', 'espressocoppola-child-theme' );
		$data['character'] = __( 'Aromatico', 'espressocoppola-child-theme' );
		$data['notes']     = __( 'Elegante · Puro', 'espressocoppola-child-theme' );
	} elseif ( false !== strpos( $normalized, 'decaf' ) ) {
		$data['slug']      = 'decaffeinato';
		$data['name']      = __( 'Decaffeinato', 'espressocoppola-child-theme' );
		$data['character'] = __( 'Leggero', 'espressocoppola-child-theme' );
		$data['notes']     = __( 'Rotondo · Delicato', 'espressocoppola-child-theme' );
	} elseif ( false !== strpos( $normalized, 'delicat' ) ) {
		$data['slug']      = 'delicata';
		$data['name']      = __( 'Delicata', 'espressocoppola-child-theme' );
		$data['character'] = __( 'Equilibrato', 'espressocoppola-child-theme' );
		$data['notes']     = __( 'Morbido · Armonioso', 'espressocoppola-child-theme' );
	} elseif ( false !== strpos( $normalized, 'crema' ) ) {
		$data['slug']      = 'crema';
		$data['name']      = __( 'Crema', 'espressocoppola-child-theme' );
		$data['character'] = __( 'Intenso', 'espressocoppola-child-theme' );
		$data['notes']     = __( 'Cremoso · Avvolgente', 'espressocoppola-child-theme' );
	}

	return $data;
}

/**
 * Infer a blend only when no global WooCommerce taxonomy is configured.
 *
 * @param WC_Product $product Product instance.
 * @return array<int,array<string,string>>
 */
function espressocoppola_get_product_fallback_blends( $product ) {
	$name = $product->get_name();
	$data = espressocoppola_get_blend_editorial_data( $name, $name );

	return '' !== $data['character'] ? array( $data ) : array();
}
