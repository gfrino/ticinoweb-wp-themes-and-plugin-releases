<?php
/**
 * Homepage data adapters for ticinoWEB CMS and WooCommerce.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Resolve the visual atmosphere of a CMS slide without changing its content.
 *
 * @param string $title Slide title.
 * @param int    $index Zero-based slide index.
 * @return string
 */
function espressocoppola_get_slide_tone( $title, $index ) {
	$slug = sanitize_title( remove_accents( (string) $title ) );

	if ( false !== strpos( $slug, 'arabica' ) ) {
		return 'arabica';
	}

	if ( false !== strpos( $slug, 'delicat' ) ) {
		return 'delicata';
	}

	if ( false !== strpos( $slug, 'crema' ) ) {
		return 'crema';
	}

	$tones = array( 'crema', 'delicata', 'arabica' );

	return $tones[ $index % count( $tones ) ];
}

/**
 * Return normalized slides from the parent CMS helper.
 *
 * @return array<int,array<string,mixed>>
 */
function espressocoppola_get_home_slides() {
	if ( ! function_exists( 'ticinoweb_get_slider_data' ) ) {
		return array();
	}

	$slides     = array();
	$cms_slides = ticinoweb_get_slider_data();

	foreach ( $cms_slides as $index => $slide ) {
		$image = isset( $slide['image'] ) ? esc_url_raw( $slide['image'] ) : '';

		if ( '' === $image ) {
			continue;
		}

		$title = isset( $slide['title'] ) ? (string) $slide['title'] : '';

		$slides[] = array(
			'image'      => $image,
			'image_id'   => attachment_url_to_postid( $image ),
			'title'      => $title,
			'description'=> isset( $slide['desc'] ) ? (string) $slide['desc'] : '',
			'button_text'=> isset( $slide['btn1_text'] ) ? (string) $slide['btn1_text'] : '',
			'button_url' => isset( $slide['btn1_link'] ) ? esc_url_raw( $slide['btn1_link'] ) : '',
			'tone'       => espressocoppola_get_slide_tone( $title, count( $slides ) ),
		);
	}

	return $slides;
}

/**
 * Return real, non-empty WooCommerce format categories for the Hero.
 *
 * The shortest matching taxonomy path wins, so a preparation root such as
 * "Capsule" is preferred to one of its systems while nested formats such as
 * "Chicchi" and "Macinato" remain available when they are the real terms.
 *
 * @return array<int,array{key:string,name:string,url:string,term_id:int}>
 */
function espressocoppola_get_hero_format_links() {
	if ( ! taxonomy_exists( 'product_cat' ) || ! function_exists( 'espressocoppola_get_preparation_definitions' ) ) {
		return array();
	}

	$terms = get_terms(
		array(
			'taxonomy'   => 'product_cat',
			'hide_empty' => true,
			'orderby'    => 'menu_order',
			'order'      => 'ASC',
		)
	);

	if ( is_wp_error( $terms ) || empty( $terms ) ) {
		return array();
	}

	$definitions = espressocoppola_get_preparation_definitions();
	$candidates  = array();

	foreach ( $terms as $term ) {
		if ( ! $term instanceof WP_Term || $term->count < 1 ) {
			continue;
		}

		$path           = espressocoppola_get_category_path( $term );
		$classification = espressocoppola_classify_category_path( $path );
		$key            = $classification['preparation'];

		if ( '' === $key || ! isset( $definitions[ $key ] ) ) {
			continue;
		}

		$depth = count( $path );
		if ( isset( $candidates[ $key ] ) && $candidates[ $key ]['depth'] <= $depth ) {
			continue;
		}

		$url = get_term_link( $term );
		if ( is_wp_error( $url ) ) {
			continue;
		}

		$candidates[ $key ] = array(
			'key'     => $key,
			'name'    => $definitions[ $key ]['name'],
			'url'     => $url,
			'term_id' => (int) $term->term_id,
			'depth'   => $depth,
		);
	}

	$links = array();
	foreach ( array_keys( $definitions ) as $key ) {
		if ( ! isset( $candidates[ $key ] ) ) {
			continue;
		}

		unset( $candidates[ $key ]['depth'] );
		$links[] = $candidates[ $key ];
	}

	return $links;
}

/**
 * Render a responsive CMS image when it belongs to the Media Library.
 *
 * @param array<string,mixed> $slide Slide data.
 * @param bool                $is_first Whether this is the LCP candidate.
 * @return string
 */
function espressocoppola_get_slide_image_html( $slide, $is_first = false ) {
	$attributes = array(
		'class'    => 'espresso-stage__product-image',
		'alt'      => (string) $slide['title'],
		'decoding' => 'async',
		'loading'  => $is_first ? 'eager' : 'lazy',
	);

	if ( $is_first ) {
		$attributes['fetchpriority'] = 'high';
	}

	if ( ! empty( $slide['image_id'] ) ) {
		return wp_get_attachment_image(
			(int) $slide['image_id'],
			'full',
			false,
			$attributes + array( 'sizes' => '(max-width: 767px) 88vw, 52vw' )
		);
	}

	return sprintf(
		'<img src="%1$s" alt="%2$s" class="espresso-stage__product-image" loading="%3$s" decoding="async"%4$s>',
		esc_url( $slide['image'] ),
		esc_attr( $slide['title'] ),
		$is_first ? 'eager' : 'lazy',
		$is_first ? ' fetchpriority="high"' : ''
	);
}

/**
 * Detect the existing global attribute used for coffee blend/flavour.
 *
 * @return string Empty when the catalog has no equivalent global attribute.
 */
function espressocoppola_get_blend_taxonomy() {
	if ( ! function_exists( 'wc_get_attribute_taxonomies' ) ) {
		return '';
	}

	$preferred = array( 'gusto', 'blend', 'aroma' );
	$found     = array();

	foreach ( wc_get_attribute_taxonomies() as $attribute ) {
		$name  = sanitize_title( $attribute->attribute_name );
		$label = sanitize_title( remove_accents( $attribute->attribute_label ) );
		$taxonomy = wc_attribute_taxonomy_name( $attribute->attribute_name );

		if ( 'miscela' === $name && taxonomy_exists( $taxonomy ) ) {
			return $taxonomy;
		}

		foreach ( $preferred as $priority => $candidate ) {
			if ( $candidate === $name || $candidate === $label ) {
				if ( taxonomy_exists( $taxonomy ) && ! isset( $found[ $priority ] ) ) {
					$found[ $priority ] = $taxonomy;
				}
			}
		}
	}

	if ( empty( $found ) ) {
		return '';
	}

	ksort( $found );

	return (string) reset( $found );
}

/**
 * Return selectable format/variation attributes for a product.
 *
 * @param WC_Product $product Product instance.
 * @param string     $blend_taxonomy Blend taxonomy to exclude.
 * @return array<int,array<string,string>>
 */
function espressocoppola_get_product_formats( $product, $blend_taxonomy ) {
	$formats        = array();
	$format_markers = array( 'formato', 'peso', 'confezione', 'macinatura', 'grani', 'size', 'weight' );

	foreach ( $product->get_attributes() as $attribute ) {
		$name       = $attribute->get_name();
		$normalized = sanitize_title( remove_accents( $name . '-' . wc_attribute_label( $name ) ) );

		if ( $name === $blend_taxonomy ) {
			continue;
		}

		$is_format = $attribute->get_variation();
		foreach ( $format_markers as $marker ) {
			$is_format = $is_format || false !== strpos( $normalized, $marker );
		}

		if ( ! $is_format ) {
			continue;
		}

		$group = wc_attribute_label( $name );

		if ( $attribute->is_taxonomy() ) {
			$terms = wc_get_product_terms( $product->get_id(), $name, array( 'fields' => 'all' ) );
			foreach ( $terms as $term ) {
				$formats[ $name . ':' . $term->slug ] = array(
					'key'   => $name . ':' . $term->slug,
					'name'  => $term->name,
					'group' => $group,
				);
			}
		} else {
			foreach ( $attribute->get_options() as $option ) {
				$key = sanitize_title( $name ) . ':' . sanitize_title( $option );
				$formats[ $key ] = array(
					'key'   => $key,
					'name'  => (string) $option,
					'group' => $group,
				);
			}
		}
	}

	return array_values( $formats );
}

/**
 * Serialize a WooCommerce product for the client-side finder.
 *
 * @param WC_Product $product Product instance.
 * @param string     $blend_taxonomy Detected blend taxonomy.
 * @return array<string,mixed>
 */
function espressocoppola_serialize_finder_product( $product, $blend_taxonomy ) {
	$category_terms = wc_get_product_terms( $product->get_id(), 'product_cat', array( 'fields' => 'all' ) );
	$blend_terms    = $blend_taxonomy ? wc_get_product_terms( $product->get_id(), $blend_taxonomy, array( 'fields' => 'all' ) ) : array();
	$preparation    = espressocoppola_get_product_preparation_data( $product );
	$image_id       = $product->get_image_id();
	$categories     = array();
	$blends         = array();

	foreach ( $category_terms as $term ) {
		$categories[] = $term->slug;
	}

	if ( empty( $preparation['preparations'] ) ) {
		return null;
	}

	foreach ( $blend_terms as $term ) {
		$blends[] = espressocoppola_get_blend_editorial_data( $term->slug, $term->name );
	}

	if ( empty( $blends ) ) {
		$blends = espressocoppola_get_product_fallback_blends( $product );
	}

	$can_add_to_cart = $product->is_type( 'simple' ) && $product->is_purchasable() && $product->is_in_stock();

	return array(
		'id'           => $product->get_id(),
		'name'         => $product->get_name(),
		'url'          => get_permalink( $product->get_id() ),
		'image'        => $image_id ? wp_get_attachment_image_url( $image_id, 'woocommerce_thumbnail' ) : wc_placeholder_img_src( 'woocommerce_thumbnail' ),
		'imageSrcset'  => $image_id ? wp_get_attachment_image_srcset( $image_id, 'woocommerce_thumbnail' ) : '',
		'imageSizes'   => '(max-width: 640px) 82vw, 320px',
		'priceHtml'    => wp_kses_post( $product->get_price_html() ),
		'summary'      => wp_trim_words( wp_strip_all_tags( $product->get_short_description() ), 18 ),
		'categories'   => $categories,
		'preparations' => $preparation['preparations'],
		'systems'      => $preparation['systems'],
		'blends'       => $blends,
		'formats'      => espressocoppola_get_product_formats( $product, $blend_taxonomy ),
		'published'    => 'publish' === $product->get_status(),
		'inStock'      => $product->is_in_stock(),
		'canAddToCart' => $can_add_to_cart,
		'addToCartUrl' => $can_add_to_cart ? $product->add_to_cart_url() : '',
	);
}

/**
 * Return the cached homepage catalog for the current request.
 *
 * @return array<string,mixed>|null
 */
function espressocoppola_get_home_catalog_request_cache() {
	return isset( $GLOBALS['espressocoppola_home_catalog_request_cache'] ) && is_array( $GLOBALS['espressocoppola_home_catalog_request_cache'] )
		? $GLOBALS['espressocoppola_home_catalog_request_cache']
		: null;
}

/**
 * Persist the homepage catalog for the remainder of the current request.
 *
 * @param array<string,mixed> $catalog Catalog payload.
 * @return array<string,mixed>
 */
function espressocoppola_set_home_catalog_request_cache( $catalog ) {
	$GLOBALS['espressocoppola_home_catalog_request_cache'] = $catalog;

	return $catalog;
}

/**
 * Clear the homepage catalog request cache.
 *
 * @return void
 */
function espressocoppola_clear_home_catalog_request_cache() {
	unset( $GLOBALS['espressocoppola_home_catalog_request_cache'] );
}

/**
 * Build the Coffee Finder catalog from real WooCommerce entities.
 *
 * @return array<string,mixed>
 */
function espressocoppola_get_coffee_finder_catalog() {
	$catalog_cache = espressocoppola_get_home_catalog_request_cache();
	if ( null !== $catalog_cache ) {
		return $catalog_cache;
	}

	$empty = array(
		'categories'    => array(),
		'preparations'  => array(),
		'products'      => array(),
		'blendTaxonomy' => '',
	);

	if ( ! function_exists( 'wc_get_products' ) || ! taxonomy_exists( 'product_cat' ) ) {
		return espressocoppola_set_home_catalog_request_cache( $empty );
	}

	$cache_key  = 'espressocoppola_home_product_ids_v1';
	$product_ids = get_transient( $cache_key );

	if ( false === $product_ids ) {
		$catalog_limit = max( 1, (int) apply_filters( 'espressocoppola_finder_product_limit', 200 ) );
		$product_ids   = wc_get_products(
			array(
				'status'       => 'publish',
				'limit'        => $catalog_limit,
				'stock_status' => 'instock',
				'visibility'   => 'visible',
				'orderby'      => 'menu_order',
				'order'        => 'ASC',
				'return'       => 'ids',
			)
		);
		set_transient( $cache_key, array_map( 'absint', $product_ids ), 6 * HOUR_IN_SECONDS );
	}

	$products = array_filter(
		array_map( 'wc_get_product', array_map( 'absint', (array) $product_ids ) ),
		static function ( $product ) {
			return $product instanceof WC_Product;
		}
	);

	if ( empty( $products ) ) {
		return espressocoppola_set_home_catalog_request_cache( $empty );
	}

	$default_category = (int) get_option( 'default_product_cat', 0 );
	$category_ids     = array();

	foreach ( $products as $product ) {
		$category_ids = array_merge( $category_ids, $product->get_category_ids() );
	}

	$category_ids = array_values( array_diff( array_unique( array_map( 'absint', $category_ids ) ), array( $default_category ) ) );
	$categories   = array();

	if ( ! empty( $category_ids ) ) {
		$terms = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'include'    => $category_ids,
				'hide_empty' => true,
				'orderby'    => 'menu_order',
			)
		);

		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $term ) {
				$thumbnail_id = (int) get_term_meta( $term->term_id, 'thumbnail_id', true );
				$categories[] = array(
					'id'       => $term->term_id,
					'name'     => $term->name,
					'slug'     => $term->slug,
					'image'    => $thumbnail_id ? wp_get_attachment_image_url( $thumbnail_id, 'medium_large' ) : '',
					'imageAlt' => $term->name,
				);
			}
		}
	}

	$blend_taxonomy = espressocoppola_get_blend_taxonomy();
	$serialized     = array();

	foreach ( $products as $product ) {
		$serialized_product = espressocoppola_serialize_finder_product( $product, $blend_taxonomy );
		if ( is_array( $serialized_product ) ) {
			$serialized[] = $serialized_product;
		}
	}

	$definitions  = espressocoppola_get_preparation_definitions();
	$preparations = array();
	foreach ( $serialized as $product ) {
		foreach ( $product['preparations'] as $preparation_key ) {
			if ( ! isset( $definitions[ $preparation_key ] ) ) {
				continue;
			}
			if ( ! isset( $preparations[ $preparation_key ] ) ) {
				$preparations[ $preparation_key ] = array(
					'key'     => $preparation_key,
					'name'    => $definitions[ $preparation_key ]['name'],
					'detail'  => $definitions[ $preparation_key ]['detail'],
					'systems' => array(),
				);
			}
			foreach ( $product['systems'] as $system ) {
				$preparations[ $preparation_key ]['systems'][ $system['slug'] ] = $system;
			}
		}
	}

	foreach ( $preparations as &$preparation ) {
		$preparation['systems'] = array_values( $preparation['systems'] );
	}
	unset( $preparation );

	return espressocoppola_set_home_catalog_request_cache(
		array(
		'categories'    => array_values( $preparations ),
		'preparations'  => array_values( $preparations ),
		'products'      => $serialized,
		'blendTaxonomy' => $blend_taxonomy,
		)
	);
}

/**
 * Invalidate the bounded homepage catalog after WooCommerce data changes.
 *
 * @return void
 */
function espressocoppola_flush_home_catalog_cache() {
	delete_transient( 'espressocoppola_home_product_ids_v1' );
	espressocoppola_clear_home_catalog_request_cache();
}
add_action( 'woocommerce_update_product', 'espressocoppola_flush_home_catalog_cache' );
add_action( 'woocommerce_new_product', 'espressocoppola_flush_home_catalog_cache' );
add_action( 'woocommerce_delete_product', 'espressocoppola_flush_home_catalog_cache' );
add_action( 'woocommerce_product_set_stock_status', 'espressocoppola_flush_home_catalog_cache' );
add_action( 'woocommerce_variation_set_stock_status', 'espressocoppola_flush_home_catalog_cache' );
add_action( 'woocommerce_attribute_added', 'espressocoppola_flush_home_catalog_cache' );
add_action( 'woocommerce_attribute_updated', 'espressocoppola_flush_home_catalog_cache' );
add_action( 'woocommerce_attribute_deleted', 'espressocoppola_flush_home_catalog_cache' );

/**
 * Invalidate cached IDs when a product category or attribute term changes.
 *
 * @param int    $term_id Term ID.
 * @param int    $term_taxonomy_id Term-taxonomy ID.
 * @param string $taxonomy Taxonomy name.
 * @return void
 */
function espressocoppola_flush_home_catalog_on_term_change( $term_id, $term_taxonomy_id, $taxonomy ) {
	unset( $term_id, $term_taxonomy_id );

	if ( 'product_cat' === $taxonomy || 0 === strpos( $taxonomy, 'pa_' ) ) {
		espressocoppola_flush_home_catalog_cache();
	}
}
add_action( 'created_term', 'espressocoppola_flush_home_catalog_on_term_change', 10, 3 );
add_action( 'edited_term', 'espressocoppola_flush_home_catalog_on_term_change', 10, 3 );
add_action( 'delete_term', 'espressocoppola_flush_home_catalog_on_term_change', 10, 3 );

/**
 * Invalidate cached IDs when product term relationships change.
 *
 * @param int    $object_id Object ID.
 * @param mixed  $terms Assigned terms.
 * @param mixed  $term_taxonomy_ids Term-taxonomy IDs.
 * @param string $taxonomy Taxonomy name.
 * @return void
 */
function espressocoppola_flush_home_catalog_on_term_assignment( $object_id, $terms, $term_taxonomy_ids, $taxonomy ) {
	unset( $object_id, $terms, $term_taxonomy_ids );

	if ( 'product_cat' === $taxonomy || 0 === strpos( $taxonomy, 'pa_' ) ) {
		espressocoppola_flush_home_catalog_cache();
	}
}
add_action( 'set_object_terms', 'espressocoppola_flush_home_catalog_on_term_assignment', 10, 4 );

/**
 * Detect accessory language before applying any positive coffee fallback.
 *
 * @param string $text Product or category text.
 * @return bool
 */
function espressocoppola_product_text_is_accessory( $text ) {
	$normalized = sanitize_title( remove_accents( (string) $text ) );
	$tokens     = preg_split( '/-+/', $normalized );

	foreach ( array( 'kit', 'accessorio', 'accessori', 'tazza', 'tazze', 'bicchiere', 'bicchieri', 'monouso', 'zucchero', 'zuccheri', 'paletta', 'palette' ) as $excluded ) {
		if ( in_array( $excluded, $tokens, true ) ) {
			return true;
		}
	}

	foreach ( array( 'accessor', 'tazz', 'bicchier', 'monouso', 'zuccher', 'palett' ) as $excluded_prefix ) {
		if ( false !== strpos( $normalized, $excluded_prefix ) ) {
			return true;
		}
	}

	return false;
}

/**
 * Determine whether a WooCommerce product belongs to the coffee assortment.
 *
 * Category hierarchy is the primary source of truth. The title fallback keeps
 * an uncategorized coffee eligible, while explicit accessory language always
 * wins so cups and service kits never enter the editorial stage.
 *
 * @param WC_Product $product Product instance.
 * @return bool
 */
function espressocoppola_is_coffee_product( $product ) {
	if ( ! $product instanceof WC_Product ) {
		return false;
	}

	$name = sanitize_title( remove_accents( $product->get_name() ) );
	if ( espressocoppola_product_text_is_accessory( $name ) ) {
		return false;
	}

	$terms           = wc_get_product_terms( $product->get_id(), 'product_cat', array( 'fields' => 'all' ) );
	$has_preparation = false;
	foreach ( $terms as $term ) {
		$path           = espressocoppola_get_category_path( $term );
		$classification = espressocoppola_classify_category_path( $path );
		$path_text      = implode( ' ', array_merge( wp_list_pluck( $path, 'slug' ), wp_list_pluck( $path, 'name' ) ) );

		if ( espressocoppola_product_text_is_accessory( $path_text ) ) {
			return false;
		}

		$has_preparation = $has_preparation || '' !== $classification['preparation'];
	}

	if ( $has_preparation ) {
		return true;
	}

	foreach ( array( 'caffe', 'coffee', 'espresso', 'crema', 'delicat', 'arabica', 'decaf', 'miscela' ) as $coffee_marker ) {
		if ( false !== strpos( $name, $coffee_marker ) ) {
			return true;
		}
	}

	return false;
}

/**
 * Resolve a restrained visual tone from real blend taxonomy or product title.
 *
 * @param WC_Product $product Product instance.
 * @return string
 */
function espressocoppola_get_product_stage_tone( $product ) {
	$blend_taxonomy = espressocoppola_get_blend_taxonomy();
	$search_text     = $product->get_name();

	if ( $blend_taxonomy ) {
		$terms = wc_get_product_terms( $product->get_id(), $blend_taxonomy, array( 'fields' => 'names' ) );
		if ( ! is_wp_error( $terms ) ) {
			$search_text .= ' ' . implode( ' ', $terms );
		}
	}

	$normalized = sanitize_title( remove_accents( $search_text ) );

	if ( false !== strpos( $normalized, 'decaf' ) ) {
		return 'decaffeinato';
	}
	if ( false !== strpos( $normalized, 'arabica' ) ) {
		return 'arabica';
	}
	if ( false !== strpos( $normalized, 'delicat' ) ) {
		return 'delicata';
	}

	return 'crema';
}

/**
 * Build presentation data for one WooCommerce product in the Product Stage.
 *
 * @param WC_Product $product Product instance.
 * @param int        $index Product index.
 * @return array<string,mixed>
 */
function espressocoppola_get_product_stage_data( $product, $index = 0 ) {
	$tone             = espressocoppola_get_product_stage_tone( $product );
	$blend_taxonomy   = espressocoppola_get_blend_taxonomy();
	$blend_editorial  = array();
	$blend_terms      = $blend_taxonomy ? wc_get_product_terms( $product->get_id(), $blend_taxonomy, array( 'fields' => 'all' ) ) : array();
	$preparation_data = espressocoppola_get_product_preparation_data( $product );

	if ( ! is_wp_error( $blend_terms ) && ! empty( $blend_terms ) ) {
		$blend_editorial = espressocoppola_get_blend_editorial_data( $blend_terms[0]->slug, $blend_terms[0]->name );
	}

	if ( empty( $blend_editorial['character'] ) ) {
		$fallbacks       = espressocoppola_get_product_fallback_blends( $product );
		$blend_editorial = ! empty( $fallbacks ) ? $fallbacks[0] : array();
	}

	$definitions       = espressocoppola_get_preparation_definitions();
	$preparation_key   = ! empty( $preparation_data['preparations'][0] ) ? $preparation_data['preparations'][0] : '';
	$preparation_label = isset( $definitions[ $preparation_key ]['name'] ) ? $definitions[ $preparation_key ]['name'] : __( 'Caffè', 'espressocoppola-child-theme' );
	$blend_label       = ! empty( $blend_editorial['name'] ) ? $blend_editorial['name'] : $product->get_name();
	$summary           = wp_trim_words( wp_strip_all_tags( $product->get_short_description() ), 22 );

	if ( '' === $summary && ! empty( $blend_editorial['character'] ) ) {
		$summary = trim( $blend_editorial['character'] . ( ! empty( $blend_editorial['notes'] ) ? ' · ' . $blend_editorial['notes'] : '' ) );
	}

	return array(
		'index'             => absint( $index ),
		'id'                => $product->get_id(),
		'name'              => $product->get_name(),
		'url'               => get_permalink( $product->get_id() ),
		'tone'              => $tone,
		'blend_label'       => $blend_label,
		'preparation_label' => $preparation_label,
		'summary'           => $summary,
		'price_html'        => $product->get_price_html(),
		'image_id'          => $product->get_image_id(),
	);
}

/**
 * Return up to four published, visible and in-stock coffee products.
 *
 * Featured coffees lead within their blend family. A first pass preserves
 * blend variety; a second pass fills remaining positions with real coffees.
 *
 * @return WC_Product[]
 */
function espressocoppola_get_featured_products() {
	if ( ! function_exists( 'wc_get_products' ) ) {
		return array();
	}

	$catalog_limit = max( 4, (int) apply_filters( 'espressocoppola_product_stage_limit', 80 ) );
	$query_args    = array(
		'status'       => 'publish',
		'visibility'   => 'visible',
		'stock_status' => 'instock',
		'limit'        => $catalog_limit,
		'orderby'      => 'date',
		'order'        => 'DESC',
		'return'       => 'objects',
	);
	$featured      = wc_get_products(
		array_merge(
			$query_args,
			array(
				'featured' => true,
				'limit'    => -1,
			)
		)
	);
	$featured_ids  = array_map(
		static function ( $product ) {
			return $product->get_id();
		},
		$featured
	);
	$recent        = wc_get_products( array_merge( $query_args, array( 'exclude' => $featured_ids ) ) );
	$candidates    = array_merge( $featured, $recent );
	$featured_map  = array_fill_keys( $featured_ids, true );

	$candidates = array_values(
		array_filter(
			$candidates,
			static function ( $product ) {
				return $product instanceof WC_Product && $product->is_visible() && $product->is_in_stock() && espressocoppola_is_coffee_product( $product );
			}
		)
	);

	usort(
		$candidates,
		static function ( $left, $right ) use ( $featured_map ) {
			$left_featured  = isset( $featured_map[ $left->get_id() ] ) ? 1 : 0;
			$right_featured = isset( $featured_map[ $right->get_id() ] ) ? 1 : 0;

			if ( $left_featured !== $right_featured ) {
				return $right_featured <=> $left_featured;
			}

			$left_date  = $left->get_date_created();
			$right_date = $right->get_date_created();
			$left_time  = $left_date ? $left_date->getTimestamp() : 0;
			$right_time = $right_date ? $right_date->getTimestamp() : 0;

			return $right_time <=> $left_time;
		}
	);

	$selected = array();
	$used     = array();
	foreach ( $candidates as $candidate ) {
		$tone = espressocoppola_get_product_stage_tone( $candidate );
		if ( isset( $used[ $tone ] ) ) {
			continue;
		}
		$selected[]   = $candidate;
		$used[ $tone ] = true;
		if ( 4 === count( $selected ) ) {
			return $selected;
		}
	}

	$selected_ids = array_fill_keys( wp_list_pluck( $selected, 'id' ), true );
	foreach ( $candidates as $candidate ) {
		if ( isset( $selected_ids[ $candidate->get_id() ] ) ) {
			continue;
		}
		$selected[] = $candidate;
		if ( 4 === count( $selected ) ) {
			break;
		}
	}

	return $selected;
}

/**
 * Return the existing mapped or conventional company page URL.
 *
 * @return string
 */
function espressocoppola_get_brand_page_url() {
	if ( function_exists( 'ticinoweb_get_mapped_page_url' ) ) {
		$mapped_url = ticinoweb_get_mapped_page_url( 'page_chi_siamo' );
		if ( $mapped_url ) {
			return $mapped_url;
		}
	}

	$page = get_page_by_path( 'chi-siamo' );

	return $page ? get_permalink( $page ) : '';
}
