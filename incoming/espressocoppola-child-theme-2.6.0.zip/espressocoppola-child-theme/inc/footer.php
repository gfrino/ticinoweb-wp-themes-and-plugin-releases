<?php
/**
 * Footer data preparation, helpers and dynamic navigation adapters.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return the arguments for the WordPress-managed footer menu.
 *
 * @return array
 */
function espressocoppola_get_footer_menu_args() {
	$locations = get_nav_menu_locations();

	if ( ! empty( $locations['footer'] ) ) {
		$reference = array( 'theme_location' => 'footer' );
	} elseif ( ! empty( $locations['primary'] ) ) {
		$reference = array( 'theme_location' => 'primary' );
	} else {
		$fallback_id = absint( apply_filters( 'espressocoppola_header_menu_id', 53 ) );
		$reference   = $fallback_id > 0 ? array( 'menu' => $fallback_id ) : array( 'theme_location' => 'primary' );
	}

	return $reference + array(
		'menu_class'     => 'ec-footer__nav-list',
		'menu_id'        => 'ec-footer-menu',
		'container'      => false,
		'fallback_cb'    => false,
		'depth'          => 2,
		'echo'           => false,
		'items_wrap'     => '<ul id="%1$s" class="%2$s">%3$s</ul>',
	);
}

/**
 * Return the curated/dynamic shop system filters with their direct shop URLs (?type=slug).
 *
 * @return array<int,array{name:string,slug:string,url:string}>
 */
function espressocoppola_get_footer_shop_systems() {
	$shop_url = '';
	if ( function_exists( 'espressocoppola_get_header_shop_url' ) ) {
		$shop_url = espressocoppola_get_header_shop_url();
	}
	if ( empty( $shop_url ) && function_exists( 'wc_get_page_permalink' ) ) {
		$shop_url = wc_get_page_permalink( 'shop' );
	}
	if ( empty( $shop_url ) ) {
		$shop_url = home_url( '/shop/' );
	}

	$systems = array();

	// If shop catalog functions are available, extract real active types
	if ( function_exists( 'espressocoppola_get_shop_catalog' ) && function_exists( 'espressocoppola_get_shop_filter_options' ) ) {
		$catalog = espressocoppola_get_shop_catalog();
		$filters = espressocoppola_get_shop_filter_options( $catalog );

		if ( ! empty( $filters['types'] ) ) {
			foreach ( $filters['types'] as $type ) {
				$systems[] = array(
					'name' => $type['name'],
					'slug' => $type['slug'],
					'url'  => add_query_arg( 'type', $type['slug'], $shop_url ),
				);
			}
		}
	}

	// Curated luxury fallback matching the shop system slugs
	if ( empty( $systems ) ) {
		$defaults = array(
			'cialde-ese-44' => __( 'Cialde ESE 44', 'espressocoppola-child-theme' ),
			'dolce-gusto'   => __( 'Capsule Dolce Gusto', 'espressocoppola-child-theme' ),
			'nespresso'     => __( 'Capsule Nespresso', 'espressocoppola-child-theme' ),
			'a-modo-mio'    => __( 'Capsule A Modo Mio', 'espressocoppola-child-theme' ),
			'chicchi'       => __( 'Caffè in grani', 'espressocoppola-child-theme' ),
			'macinato'      => __( 'Caffè macinato Moka', 'espressocoppola-child-theme' ),
		);

		foreach ( $defaults as $slug => $name ) {
			$systems[] = array(
				'name' => $name,
				'slug' => $slug,
				'url'  => add_query_arg( 'type', $slug, $shop_url ),
			);
		}
	}

	return $systems;
}

/**
 * Prepare and sanitize the full dynamic context for the footer.
 *
 * @return array
 */
function espressocoppola_get_footer_context() {
	$contact = function_exists( 'ticinoweb_get_contact_info' ) ? ticinoweb_get_contact_info() : array();

	$shop_url = '';
	if ( function_exists( 'espressocoppola_get_header_shop_url' ) ) {
		$shop_url = espressocoppola_get_header_shop_url();
	}
	if ( empty( $shop_url ) && function_exists( 'wc_get_page_permalink' ) ) {
		$shop_url = wc_get_page_permalink( 'shop' );
	}
	if ( empty( $shop_url ) ) {
		$shop_url = home_url( '/shop/' );
	}

	$logo_url = function_exists( 'espressocoppola_get_header_logo_url' ) ? espressocoppola_get_header_logo_url() : '';
	if ( empty( $logo_url ) && function_exists( 'espressocoppola_get_logo_url' ) ) {
		$logo_url = espressocoppola_get_logo_url();
	}

	// Resolve phone across all possible CMS phone keys (phone, mobile, landline)
	$phone = '';
	if ( ! empty( $contact['phone'] ) ) {
		$phone = trim( (string) $contact['phone'] );
	} elseif ( ! empty( $contact['phone_mobile'] ) ) {
		$phone = trim( (string) $contact['phone_mobile'] );
	} elseif ( ! empty( $contact['phone_landline'] ) ) {
		$phone = trim( (string) $contact['phone_landline'] );
	} else {
		$opt_mobile   = get_option( 'ticinoweb_contact_phone_mobile' );
		$opt_phone    = get_option( 'ticinoweb_contact_phone' );
		$opt_display  = get_option( 'ticinoweb_contact_phone_display' );
		$opt_landline = get_option( 'ticinoweb_contact_phone_landline' );

		if ( ! empty( $opt_mobile ) ) {
			$phone = trim( (string) $opt_mobile );
		} elseif ( ! empty( $opt_phone ) ) {
			$phone = trim( (string) $opt_phone );
		} elseif ( ! empty( $opt_display ) ) {
			$phone = trim( (string) $opt_display );
		} elseif ( ! empty( $opt_landline ) ) {
			$phone = trim( (string) $opt_landline );
		}
	}

	$phone_clean = preg_replace( '/[^0-9+]/', '', $phone );
	$email       = isset( $contact['email'] ) ? sanitize_email( (string) $contact['email'] ) : '';
	$address     = isset( $contact['address'] ) ? trim( (string) $contact['address'] ) : '';
	$instagram   = isset( $contact['instagram'] ) ? esc_url( (string) $contact['instagram'] ) : '';
	$facebook    = isset( $contact['facebook'] ) ? esc_url( (string) $contact['facebook'] ) : '';
	$linkedin    = isset( $contact['linkedin'] ) ? esc_url( (string) $contact['linkedin'] ) : '';

	$socials = array();
	if ( ! empty( $instagram ) ) {
		$socials[] = array( 'label' => 'Instagram', 'url' => $instagram );
	}
	if ( ! empty( $facebook ) ) {
		$socials[] = array( 'label' => 'Facebook', 'url' => $facebook );
	}
	if ( ! empty( $linkedin ) ) {
		$socials[] = array( 'label' => 'LinkedIn', 'url' => $linkedin );
	}

	$privacy_url = function_exists( 'get_privacy_policy_url' ) ? get_privacy_policy_url() : '';
	$price_list  = function_exists( 'espressocoppola_get_price_list_config' ) ? espressocoppola_get_price_list_config() : array();

	return array(
		'site_name'    => get_bloginfo( 'name' ),
		'logo_url'     => $logo_url,
		'shop_url'     => $shop_url,
		'phone'        => $phone,
		'phone_clean'  => $phone_clean,
		'email'        => $email,
		'address'      => $address,
		'socials'      => $socials,
		'systems'      => espressocoppola_get_footer_shop_systems(),
		'privacy_url'  => $privacy_url,
		'price_list'   => $price_list,
		'current_year' => gmdate( 'Y' ),
	);
}

