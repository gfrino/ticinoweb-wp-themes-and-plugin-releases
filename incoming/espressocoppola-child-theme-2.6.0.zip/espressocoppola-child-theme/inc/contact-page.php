<?php
/**
 * Data adapter for the selectable Contatti page template.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Whether the current page uses the custom contact template.
 *
 * @return bool
 */
function espressocoppola_is_contact_page() {
	return is_page_template( 'page-templates/contatti.php' );
}

/**
 * Add a stable scope used to let the contact hero continue behind the header.
 *
 * @param string[] $classes Body classes.
 * @return string[]
 */
function espressocoppola_contact_body_class( $classes ) {
	if ( espressocoppola_is_contact_page() ) {
		$classes[] = 'espresso-coppola-contact';
	}

	return $classes;
}
add_filter( 'body_class', 'espressocoppola_contact_body_class' );

/**
 * Normalize a human-readable phone number for use in a tel URI.
 *
 * @param string $phone Phone number from the CMS.
 * @return string
 */
function espressocoppola_normalize_phone_uri( $phone ) {
	$phone       = trim( (string) $phone );
	$leading_plus = str_starts_with( $phone, '+' );
	$digits       = preg_replace( '/\D+/', '', $phone );

	if ( '' === $digits ) {
		return '';
	}

	return ( $leading_plus ? '+' : '' ) . $digits;
}

/**
 * Determine whether the CMS opening-hours value contains useful information.
 *
 * @param array  $hours Opening-hours option.
 * @param string $note  Optional schedule note.
 * @return bool
 */
function espressocoppola_contact_hours_are_configured( $hours, $note = '' ) {
	if ( '' !== trim( (string) $note ) ) {
		return true;
	}

	if ( ! is_array( $hours ) ) {
		return false;
	}

	foreach ( $hours as $day ) {
		if ( ! is_array( $day ) || ! empty( $day['closed'] ) ) {
			continue;
		}

		if ( ! empty( $day['open_24h'] ) ) {
			return true;
		}

		$slots = isset( $day['slots'] ) && is_array( $day['slots'] ) ? $day['slots'] : array();
		foreach ( $slots as $slot ) {
			if ( ! is_array( $slot ) ) {
				continue;
			}

			$open  = trim( (string) ( $slot['open'] ?? '' ) );
			$close = trim( (string) ( $slot['close'] ?? '' ) );
			if ( '' !== $open || '' !== $close ) {
				return true;
			}
		}
	}

	return false;
}

/**
 * Build unique, semantic direct-contact rows.
 *
 * @param array $contact Contact data returned by the parent helper.
 * @return array<int,array<string,string>>
 */
function espressocoppola_build_contact_channels( $contact ) {
	$contact  = is_array( $contact ) ? $contact : array();
	$channels = array();
	$seen     = array();
	$phones   = array(
		'phone_mobile'   => __( 'Cellulare', 'espressocoppola-child-theme' ),
		'phone'          => __( 'Telefono', 'espressocoppola-child-theme' ),
		'phone_landline' => __( 'Telefono fisso', 'espressocoppola-child-theme' ),
	);

	foreach ( $phones as $key => $label ) {
		$value = trim( (string) ( $contact[ $key ] ?? '' ) );
		$uri   = espressocoppola_normalize_phone_uri( $value );
		if ( '' === $value || '' === $uri || isset( $seen[ 'phone:' . $uri ] ) ) {
			continue;
		}

		$seen[ 'phone:' . $uri ] = true;
		$channels[]               = array(
			'type'  => 'phone',
			'label' => $label,
			'value' => $value,
			'url'   => 'tel:' . $uri,
		);
	}

	foreach ( array( 'email', 'email_2', 'email_3' ) as $index => $key ) {
		$value = sanitize_email( trim( (string) ( $contact[ $key ] ?? '' ) ) );
		$token = strtolower( $value );
		if ( '' === $value || isset( $seen[ 'email:' . $token ] ) ) {
			continue;
		}

		$seen[ 'email:' . $token ] = true;
		$channels[]                 = array(
			'type'  => 'email',
			'label' => 0 === $index ? __( 'Email', 'espressocoppola-child-theme' ) : __( 'Email diretta', 'espressocoppola-child-theme' ),
			'value' => $value,
			'url'   => 'mailto:' . $value,
		);
	}

	return $channels;
}

/**
 * Resolve the first published page using a selectable template.
 *
 * @param string $template Template path relative to the child theme.
 * @return string
 */
function espressocoppola_get_contact_related_page_url( $template ) {
	$pages = get_posts(
		array(
			'post_type'      => 'page',
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'no_found_rows'  => true,
			'meta_key'       => '_wp_page_template',
			'meta_value'     => sanitize_text_field( $template ),
		)
	);

	return $pages ? (string) get_permalink( $pages[0] ) : '';
}

/**
 * Format configured CMS hours as presentation rows.
 *
 * @param array $hours Opening-hours option.
 * @return array<int,array<string,string>>
 */
function espressocoppola_get_contact_hours_rows( $hours ) {
	$labels = array(
		'monday'    => __( 'Lunedì', 'espressocoppola-child-theme' ),
		'tuesday'   => __( 'Martedì', 'espressocoppola-child-theme' ),
		'wednesday' => __( 'Mercoledì', 'espressocoppola-child-theme' ),
		'thursday'  => __( 'Giovedì', 'espressocoppola-child-theme' ),
		'friday'    => __( 'Venerdì', 'espressocoppola-child-theme' ),
		'saturday'  => __( 'Sabato', 'espressocoppola-child-theme' ),
		'sunday'    => __( 'Domenica', 'espressocoppola-child-theme' ),
	);
	$rows = array();

	foreach ( $labels as $key => $label ) {
		if ( empty( $hours[ $key ] ) || ! is_array( $hours[ $key ] ) ) {
			continue;
		}

		$value = function_exists( 'ticinoweb_format_day_hours' ) ? ticinoweb_format_day_hours( $hours[ $key ] ) : '';
		if ( '' !== trim( (string) $value ) ) {
			$rows[] = array( 'label' => $label, 'value' => $value );
		}
	}

	return $rows;
}

/**
 * Assemble the CMS-backed context used by the contact page.
 *
 * @param int $page_id Current page ID.
 * @return array<string,mixed>
 */
function espressocoppola_get_contact_page_context( $page_id ) {
	$contact = function_exists( 'ticinoweb_get_contact_info' ) ? ticinoweb_get_contact_info() : array();
	$contact = is_array( $contact ) ? $contact : array();

	foreach ( array( 'youtube', 'x', 'tiktok' ) as $network ) {
		$contact[ $network ] = get_option( 'ticinoweb_contact_' . $network, '' );
	}

	$address    = trim( (string) ( $contact['address'] ?? '' ) );
	$hours      = isset( $contact['opening_hours'] ) && is_array( $contact['opening_hours'] ) ? $contact['opening_hours'] : array();
	$hours_note = trim( (string) ( $contact['opening_hours_note'] ?? '' ) );
	$show_hours = espressocoppola_contact_hours_are_configured( $hours, $hours_note );
	$socials    = array();
	$networks   = array(
		'instagram' => 'Instagram',
		'facebook'  => 'Facebook',
		'linkedin'  => 'LinkedIn',
		'youtube'   => 'YouTube',
		'x'         => 'X',
		'tiktok'    => 'TikTok',
	);

	foreach ( $networks as $key => $label ) {
		$url = esc_url_raw( trim( (string) ( $contact[ $key ] ?? '' ) ) );
		if ( '' !== $url ) {
			$socials[] = array( 'label' => $label, 'url' => $url );
		}
	}

	$shop_url = function_exists( 'espressocoppola_get_header_shop_url' ) ? espressocoppola_get_header_shop_url() : '';
	if ( '' === $shop_url && function_exists( 'wc_get_page_permalink' ) ) {
		$shop_url = wc_get_page_permalink( 'shop' );
	}

	return array(
		'title'       => get_the_title( $page_id ) ?: __( 'Contatti', 'espressocoppola-child-theme' ),
		'companyName' => get_bloginfo( 'name' ),
		'channels'    => espressocoppola_build_contact_channels( $contact ),
		'address'     => $address,
		'mapUrl'      => '' !== $address ? 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $address ) : '',
		'hours'       => $show_hours ? espressocoppola_get_contact_hours_rows( $hours ) : array(),
		'hoursNote'   => $show_hours ? $hours_note : '',
		'socials'     => $socials,
		'shopUrl'     => esc_url_raw( $shop_url ),
		'dnaUrl'      => espressocoppola_get_contact_related_page_url( 'page-templates/dna-delle-miscele.php' ),
	);
}
