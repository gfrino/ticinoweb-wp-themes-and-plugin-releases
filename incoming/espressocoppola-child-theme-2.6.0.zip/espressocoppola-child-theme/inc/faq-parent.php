<?php
/**
 * FAQ sul sistema del parent theme (ticinoweb-ai-theme >= 3.13.0).
 *
 * Le FAQ si gestiscono in Bacheca → FAQ, scheda "FAQ Espresso Coppola"
 * (slug `faq-espresso-coppola`): una domanda per riga, la "Sezione" e' la
 * categoria mostrata nella Question Map. I campi propri dell'Answer Atlas
 * (in evidenza, domanda conversazionale, link di approfondimento) sono campi
 * extra registrati qui con il filtro `ticinoweb_faq_item_fields`.
 *
 * Alla prima esecuzione con il parent aggiornato, le FAQ del vecchio CPT
 * `ec_faq` vengono copiate nella scheda (una volta sola, flag
 * `espressocoppola_faqs_parent_migrated_v1`). I post `ec_faq` restano nel
 * database intatti come copia di sicurezza, ma non sono piu' modificabili
 * dalla bacheca: un dato si inserisce in un posto solo.
 *
 * Senza il parent aggiornato tutto continua a funzionare con il CPT `ec_faq`.
 *
 * @package espressocoppola-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'ESPRESSOCOPPOLA_FAQ_SET', 'faq-espresso-coppola' );

/**
 * True quando le FAQ vivono nella scheda del parent.
 *
 * @return bool
 */
function espressocoppola_faq_on_parent() {
	return function_exists( 'ticinoweb_faq_get_set' ) && '1' === get_option( 'espressocoppola_faqs_parent_migrated_v1' );
}

/**
 * Campi extra di ogni domanda nell'editor della scheda FAQ.
 *
 * @param array $fields Campi registrati.
 * @return array
 */
function espressocoppola_faq_item_fields( $fields ) {
	$fields['featured']      = array(
		'label' => __( 'In evidenza nell\'Answer Atlas', 'espressocoppola-child-theme' ),
		'type'  => 'checkbox',
	);
	$fields['query']         = array(
		'label' => __( 'Domanda conversazionale', 'espressocoppola-child-theme' ),
		'type'  => 'text',
		'help'  => __( 'Come la chiederebbe un cliente a voce, per la sezione "Chiedilo come lo chiederesti a noi". Se vuota si usa la domanda.', 'espressocoppola-child-theme' ),
	);
	$fields['related_url']   = array(
		'label' => __( 'Link di approfondimento (facoltativo)', 'espressocoppola-child-theme' ),
		'type'  => 'url',
	);
	$fields['related_label'] = array(
		'label' => __( 'Testo del pulsante del link', 'espressocoppola-child-theme' ),
		'type'  => 'text',
		'help'  => __( 'Se vuoto: "Approfondisci →".', 'espressocoppola-child-theme' ),
	);
	return $fields;
}
add_filter( 'ticinoweb_faq_item_fields', 'espressocoppola_faq_item_fields' );

/**
 * Copia una volta le FAQ del CPT `ec_faq` nella scheda del parent.
 * Gira dopo il seed (20) e la migrazione Coffee Gateway (25).
 */
function espressocoppola_migrate_faqs_to_parent() {
	if ( ! function_exists( 'ticinoweb_faq_upsert_set' ) || '1' === get_option( 'espressocoppola_faqs_parent_migrated_v1' ) ) {
		return;
	}
	if ( '1' !== get_option( 'espressocoppola_faqs_seeded_v1' ) ) {
		return; // Il seed iniziale non e' ancora avvenuto: si migra alla richiesta successiva.
	}

	$posts = get_posts(
		array(
			'post_type'        => 'ec_faq',
			'post_status'      => array( 'publish', 'draft', 'pending', 'private' ),
			'numberposts'      => -1,
			'orderby'          => array(
				'menu_order' => 'ASC',
				'ID'         => 'ASC',
			),
			'suppress_filters' => true,
		)
	);

	$rows = array();
	foreach ( $posts as $post ) {
		$order_val = get_post_meta( $post->ID, '_ec_faq_order', true );
		$terms     = get_the_terms( $post->ID, 'ec_faq_category' );
		$active    = get_post_meta( $post->ID, '_ec_faq_active', true );
		$rows[]    = array(
			'sort' => array( '' !== $order_val ? (int) $order_val : (int) $post->menu_order, $post->ID ),
			'item' => array(
				'q'       => $post->post_title,
				'a'       => $post->post_content,
				'section' => ( ! empty( $terms ) && ! is_wp_error( $terms ) ) ? $terms[0]->name : __( 'Espresso Coppola', 'espressocoppola-child-theme' ),
				'visible' => 'publish' === $post->post_status && '0' !== (string) $active,
				'extra'   => array(
					'featured'      => '1' === (string) get_post_meta( $post->ID, '_ec_faq_featured', true ),
					'query'         => (string) get_post_meta( $post->ID, '_ec_faq_conversational_query', true ),
					'related_url'   => (string) get_post_meta( $post->ID, '_ec_faq_related_url', true ),
					'related_label' => (string) get_post_meta( $post->ID, '_ec_faq_related_label', true ),
				),
			),
		);
	}
	usort(
		$rows,
		static function ( $a, $b ) {
			return $a['sort'] <=> $b['sort'];
		}
	);

	$result = ticinoweb_faq_upsert_set(
		ESPRESSOCOPPOLA_FAQ_SET,
		__( 'FAQ Espresso Coppola', 'espressocoppola-child-theme' ),
		wp_list_pluck( $rows, 'item' )
	);
	if ( is_wp_error( $result ) ) {
		return; // Riprova alla richiesta successiva.
	}
	update_option( 'espressocoppola_faqs_parent_migrated_v1', '1', false );
}
add_action( 'init', 'espressocoppola_migrate_faqs_to_parent', 30 );

/**
 * Domande della scheda del parent nel formato usato dal template Answer Atlas.
 *
 * @return array<int,array<string,mixed>>
 */
function espressocoppola_faq_items_from_parent() {
	$set = ticinoweb_faq_get_set( ESPRESSOCOPPOLA_FAQ_SET );
	if ( ! $set ) {
		return array();
	}

	$items = array();
	foreach ( $set['items'] as $i => $item ) {
		$extra       = $item['extra'];
		$related_url = isset( $extra['related_url'] ) ? (string) $extra['related_url'] : '';
		$related_lbl = isset( $extra['related_label'] ) ? (string) $extra['related_label'] : '';
		if ( '' === $related_lbl && '' !== $related_url ) {
			$related_lbl = __( 'Approfondisci →', 'espressocoppola-child-theme' );
		}
		$query      = isset( $extra['query'] ) && '' !== $extra['query'] ? (string) $extra['query'] : $item['question'];
		$plain_text = trim( wp_strip_all_tags( $item['answer'] ) );
		$slug       = sanitize_title( $item['question'] );

		$items[] = array(
			'id'                   => $item['id'],
			'title'                => $item['question'],
			'slug'                 => '' !== $slug ? $slug : 'faq-' . $item['id'],
			'anchor'               => $item['anchor'],
			'content'              => wpautop( wp_kses_post( $item['answer'] ) ),
			'plain_text'           => $plain_text,
			'excerpt'              => wp_trim_words( $plain_text, 22, '…' ),
			'category_name'        => '' !== $item['section'] ? $item['section'] : __( 'Espresso Coppola', 'espressocoppola-child-theme' ),
			'category_slug'        => '' !== $item['section_slug'] ? $item['section_slug'] : 'espresso-coppola',
			'order'                => $i,
			'is_featured'          => ! empty( $extra['featured'] ),
			'conversational_query' => $query,
			'related_url'          => $related_url,
			'related_label'        => $related_lbl,
			'question'             => $item['question'],
			'answer'               => $item['answer'],
		);
	}
	return $items;
}
