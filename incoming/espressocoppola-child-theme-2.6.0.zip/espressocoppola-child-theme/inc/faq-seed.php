<?php
/**
 * Initial Seeder for FAQ / Answer Atlas.
 *
 * Populates the 14 baseline FAQs if the ec_faq CPT is empty.
 * Idempotent: runs once safely.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Replace the two legacy Coffee Finder phrases used by the baseline FAQs.
 *
 * Exact replacements preserve any unrelated editorial changes.
 *
 * @param string $content FAQ content.
 * @return string
 */
function espressocoppola_replace_finder_faq_copy( $content ) {
	return str_replace(
		array(
			'Il nostro strumento Coffee Finder ti guida passo dopo passo alla combinazione esatta',
			'il nostro strumento Coffee Finder ti guida passo dopo passo alla combinazione esatta',
			'Coffee Finder interattivo',
		),
		array(
			'Il Coffee Gateway ti porta direttamente ai prodotti disponibili per il tuo sistema',
			'il Coffee Gateway ti porta direttamente ai prodotti disponibili per il tuo sistema',
			'Coffee Gateway',
		),
		(string) $content
	);
}

/**
 * Seed initial FAQs into the database if none exist yet.
 *
 * @return void
 */
function espressocoppola_seed_initial_faqs() {
	// Only run on admin init or template load if not yet seeded
	if ( get_option( 'espressocoppola_faqs_seeded_v1' ) ) {
		return;
	}

	// Double check if any ec_faq post exists
	$existing = get_posts(
		array(
			'post_type'      => 'ec_faq',
			'post_status'    => 'any',
			'posts_per_page' => 1,
			'fields'         => 'ids',
		)
	);

	if ( ! empty( $existing ) ) {
		update_option( 'espressocoppola_faqs_seeded_v1', '1', false );
		return;
	}

	$shop_url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' );

	$faqs = array(
		// ---------------------------------------------------------------------
		// 01: Espresso Coppola
		// ---------------------------------------------------------------------
		array(
			'title'       => 'Che cos’è Espresso Coppola?',
			'content'     => "Espresso Coppola è un marchio di caffè legato alla cultura dell’espresso napoletano e pensato per offrire miscele dal carattere riconoscibile in diversi formati di consumo. Il progetto nasce dall’attenzione alla selezione del caffè, all’equilibrio delle miscele e al piacere quotidiano di una tazza intensa e piacevole.\n\nL’identità del marchio è racchiusa nel concetto “Essenza Napoletana”: un modo di vivere il caffè fatto di gusto, convivialità e rapporto diretto con le persone. La gamma comprende differenti soluzioni, dalle miscele in grani e macinate fino a cialde e capsule compatibili, così da permettere di scegliere il formato più adatto alle proprie abitudini.",
			'category'    => 'Espresso Coppola',
			'order'       => 1,
			'featured'    => 1,
			'query'       => 'Chi c\'è dietro il marchio Espresso Coppola e qual è la sua filosofia?',
			'related_url' => home_url( '/chi-siamo/' ),
			'related_lbl' => 'Scopri la nostra storia →',
		),
		array(
			'title'       => 'Cosa significa “Essenza Napoletana”?',
			'content'     => "“Essenza Napoletana” rappresenta l’identità che Espresso Coppola vuole portare nella tazza: il legame con una cultura del caffè intensa, conviviale e profondamente radicata nella quotidianità. Non indica soltanto un gusto specifico, ma un modo di interpretare il rito dell’espresso, in cui aroma, carattere e momento di condivisione hanno la stessa importanza.\n\nPer Espresso Coppola questo concetto accompagna l’intera gamma, pur lasciando a ogni miscela una propria personalità. Chi preferisce un espresso più strutturato può orientarsi verso profili differenti rispetto a chi cerca maggiore delicatezza o una componente aromatica più elegante.",
			'category'    => 'Espresso Coppola',
			'order'       => 2,
			'featured'    => 1,
			'query'       => 'Cosa significa esattamente il concetto di Essenza Napoletana?',
			'related_url' => home_url( '/chi-siamo/' ),
			'related_lbl' => 'Leggi il nostro Manifesto →',
		),

		// ---------------------------------------------------------------------
		// 02: Miscele
		// ---------------------------------------------------------------------
		array(
			'title'       => 'Quali miscele propone Espresso Coppola?',
			'content'     => "La gamma Espresso Coppola comprende diverse miscele pensate per offrire profili sensoriali differenti. Tra quelle presenti nel catalogo rientrano Crema, Delicata e 100% Arabica, oltre alle proposte decaffeinate disponibili nei formati compatibili previsti dal catalogo.\n\nCrema è orientata verso un espresso più corposo e intenso; Delicata cerca un equilibrio più morbido tra le componenti della miscela; 100% Arabica privilegia invece il carattere aromatico tipico dell’Arabica.\n\nLe disponibilità possono variare in base al formato. Nel nostro Shop ogni miscela è collegata ai prodotti WooCommerce realmente pubblicati, per verificare sempre le combinazioni e le confezioni attive.",
			'category'    => 'Miscele',
			'order'       => 3,
			'featured'    => 1,
			'query'       => 'Quali sono le miscele di caffè disponibili nel catalogo?',
			'related_url' => $shop_url,
			'related_lbl' => 'Esplora le Miscele nello Shop →',
		),
		array(
			'title'       => 'Qual è la differenza tra Crema, Delicata e 100% Arabica?',
			'content'     => "La differenza principale riguarda la composizione della miscela e il conseguente profilo in tazza. Crema è pensata per chi cerca maggiore struttura, corpo e intensità. Delicata offre invece un equilibrio più morbido tra carattere e rotondità. La miscela 100% Arabica mette maggiormente in evidenza la componente aromatica dell’Arabica e propone un’esperienza differente rispetto alle miscele che includono anche Robusta.\n\nPer scegliere non esiste una soluzione universalmente migliore: dipende dal gusto personale e dal tipo di espresso desiderato. La sezione “DNA delle miscele” del sito permette di confrontare i diversi profili sensoriali attraverso parametri precisi come corpo, dolcezza, tostatura, persistenza e intensità aromatica.",
			'category'    => 'Miscele',
			'order'       => 4,
			'featured'    => 1,
			'query'       => 'Qual è la differenza tra Crema, Delicata e 100% Arabica?',
			'related_url' => home_url( '/dna-delle-miscele/' ),
			'related_lbl' => 'Confronta il DNA delle Miscele →',
		),
		array(
			'title'       => 'Come posso scegliere la miscela Espresso Coppola più adatta ai miei gusti?',
			'content'     => "Il modo più semplice è partire dalle caratteristiche che cerchi nella tazza. Se preferisci un espresso intenso, corposo e persistente, puoi orientarti verso una miscela con valori più elevati nelle dimensioni legate a corpo, tostatura e intensità. Se invece cerchi un profilo più morbido o aromatico, può essere utile confrontare miscele con un equilibrio diverso.\n\nSul sito Espresso Coppola puoi utilizzare il Coffee Gateway e la sezione dedicata al DNA delle miscele per confrontare formati, sistemi compatibili e parametri quali intensità aromatica, intensità olfattiva, acidità, persistenza, tostatura, corpo e dolcezza.",
			'category'    => 'Miscele',
			'order'       => 5,
			'featured'    => 0,
			'query'       => 'Qual è la miscela Espresso Coppola più adatta al mio palato?',
			'related_url' => home_url( '/#coffee-gateway' ),
			'related_lbl' => 'Trova il formato nel Coffee Gateway →',
		),

		// ---------------------------------------------------------------------
		// 03: Compatibilità e formati
		// ---------------------------------------------------------------------
		array(
			'title'       => 'Le capsule Espresso Coppola sono compatibili con le macchine Nespresso?',
			'content'     => "Espresso Coppola propone capsule compatibili con il sistema Nespresso quando indicato espressamente nella scheda prodotto. Questo permette di utilizzare le miscele disponibili nel formato compatibile mantenendo la praticità tipica delle macchine che utilizzano questo sistema.\n\nÈ importante distinguere tra “compatibile” e “prodotto originale”: Espresso Coppola è un marchio indipendente e i riferimenti a Nespresso vengono utilizzati esclusivamente per indicare la compatibilità del formato. I marchi appartengono ai rispettivi titolari e non implicano affiliazione o sponsorizzazione.",
			'category'    => 'Compatibilità e formati',
			'order'       => 6,
			'featured'    => 1,
			'query'       => 'Quale caffè posso usare con una macchina Nespresso?',
			'related_url' => add_query_arg( 'type', 'nespresso', $shop_url ),
			'related_lbl' => 'Vedi compatibili Nespresso →',
		),
		array(
			'title'       => 'Espresso Coppola produce capsule compatibili con Dolce Gusto e A Modo Mio?',
			'content'     => "La gamma Espresso Coppola comprende prodotti compatibili con diversi sistemi, tra cui Nescafé Dolce Gusto e Lavazza A Modo Mio, quando tali formati risultano disponibili nel catalogo WooCommerce. Ogni confezione e scheda prodotto indica chiaramente il sistema con cui il caffè è destinato a essere utilizzato, così da evitare dubbi al momento dell’acquisto.\n\nAnche in questo caso si tratta di prodotti indipendenti compatibili con sistemi di terzi. I nomi commerciali vengono utilizzati unicamente per identificare la compatibilità del formato.",
			'category'    => 'Compatibilità e formati',
			'order'       => 7,
			'featured'    => 1,
			'query'       => 'Avete capsule per sistemi Dolce Gusto o A Modo Mio?',
			'related_url' => $shop_url,
			'related_lbl' => 'Controlla tutti i sistemi nello Shop →',
		),
		array(
			'title'       => 'Cosa significa che una capsula o una cialda è “compatibile”?',
			'content'     => "Quando un prodotto Espresso Coppola viene definito “compatibile”, significa che le sue dimensioni geometriche e la meccanica di estrazione sono specificamente progettate per funzionare con un dato sistema di preparazione. Non significa che il prodotto sia fabbricato dal proprietario del marchio della macchina o che esista un rapporto di licenza tra le aziende.\n\nSul sito vengono distinti con chiarezza il marchio Espresso Coppola e i sistemi compatibili. Prima dell’acquisto consigliamo sempre di verificare il nome esatto del proprio sistema di estrazione per scegliere con sicurezza.",
			'category'    => 'Compatibilità e formati',
			'order'       => 8,
			'featured'    => 0,
			'query'       => 'Cosa si intende per capsula o cialda compatibile?',
			'related_url' => $shop_url,
			'related_lbl' => 'Guarda i formati disponibili →',
		),
		array(
			'title'       => 'Espresso Coppola è disponibile anche in grani e macinato?',
			'content'     => "Sì, il catalogo Espresso Coppola comprende anche soluzioni dedicate a chi preferisce preparare il caffè partendo dai chicchi o dal caffè macinato, quando tali prodotti risultano disponibili nello Shop. Il caffè in grani è particolarmente adatto a chi utilizza macchine con macinacaffè integrato o desidera macinare al momento, preservando tutta la fragranza degli oli aromatici, mentre il macinato garantisce una preparazione rapida e fedele con la moka tradizionale.\n\nPesi e disponibilità sono aggiornati in tempo reale dal nostro catalogo.",
			'category'    => 'Compatibilità e formati',
			'order'       => 9,
			'featured'    => 0,
			'query'       => 'Vendete caffè in grani interi o macinato per moka?',
			'related_url' => add_query_arg( 'type', 'chicchi', $shop_url ),
			'related_lbl' => 'Scopri il caffè in grani →',
		),

		// ---------------------------------------------------------------------
		// 04: Acquisto e ordini
		// ---------------------------------------------------------------------
		array(
			'title'       => 'Come posso acquistare i prodotti Espresso Coppola?',
			'content'     => "I prodotti disponibili per la vendita possono essere acquistati direttamente nello Shop online di Espresso Coppola. Ogni scheda prodotto presenta con trasparenza formato, miscela, note sensoriali, varianti e box disponibili.\n\nPrezzi e disponibilità provengono direttamente dal nostro sistema WooCommerce senza sovrapprezzi o intermediari. È sufficiente aggiungere le confezioni desiderate al carrello e completare il checkout sicuro in pochi passaggi.",
			'category'    => 'Acquisto e ordini',
			'order'       => 10,
			'featured'    => 0,
			'query'       => 'Come posso acquistare il caffè direttamente online?',
			'related_url' => $shop_url,
			'related_lbl' => 'Vai allo Shop Espresso Coppola →',
		),
		array(
			'title'       => 'Come faccio a sapere quale formato acquistare per la mia macchina?',
			'content'     => "Il punto di partenza è identificare il modello o la tipologia di macchina da caffè che possiedi. Nel nostro catalogo i prodotti sono categorizzati con precisione tra cialde filtro-carta ESE 44 mm, capsule compatibili (Nespresso, Dolce Gusto, A Modo Mio), caffè in grani e macinato.\n\nSe utilizzi una macchina a capsule verifica la forma dell'alloggiamento; per macchine a braccetto manuale le cialde ESE 44 o il macinato sono solitamente lo standard. In caso di dubbio, il Coffee Gateway ti porta direttamente ai prodotti disponibili per il tuo sistema.",
			'category'    => 'Acquisto e ordini',
			'order'       => 11,
			'featured'    => 1,
			'query'       => 'Non so che capsula o cialda va bene per la mia macchinetta, come faccio?',
			'related_url' => home_url( '/#coffee-gateway' ),
			'related_lbl' => 'Apri il Coffee Gateway →',
		),

		// ---------------------------------------------------------------------
		// 05: Ho.Re.Ca.
		// ---------------------------------------------------------------------
		array(
			'title'       => 'Espresso Coppola propone soluzioni per bar, ristoranti e hotel?',
			'content'     => "Espresso Coppola dedica una sezione e un canale specifico al mondo Ho.Re.Ca., pensato per attività professionali quali bar, ristoranti, hotel, boutique B&B, uffici e servizi di catering che richiedono qualità costante e fornitura puntuale.\n\nAttraverso la pagina Ho.Re.Ca. è possibile presentare le esigenze del proprio locale, indicando consumi mensili stimati, tipologia di esercizio e miscele di interesse, per ricevere una proposta su misura dal nostro team commerciale.",
			'category'    => 'Ho.Re.Ca.',
			'order'       => 12,
			'featured'    => 1,
			'query'       => 'Espresso Coppola vende caffè per bar, ristoranti e uffici?',
			'related_url' => home_url( '/horeca/' ),
			'related_lbl' => 'Visita la sezione Ho.Re.Ca. →',
		),
		array(
			'title'       => 'Come posso richiedere un campione Espresso Coppola per la mia attività?',
			'content'     => "Le attività professionali possono utilizzare il modulo guidato in 3 step presente nella pagina Ho.Re.Ca. per richiedere un kit campione. Il modulo raccoglie i dati essenziali: ragione sociale, referente, indirizzo, consumo medio e sistema utilizzato.\n\nUna volta inviata, la richiesta commerciale viene registrata e presa in carico direttamente dai nostri referenti Ho.Re.Ca. per concordare la prova migliore per il tuo bancone o la tua sala.",
			'category'    => 'Ho.Re.Ca.',
			'order'       => 13,
			'featured'    => 0,
			'query'       => 'Come posso richiedere un kit campione per il mio bar o ristorante?',
			'related_url' => home_url( '/horeca/#richiedi-campione' ),
			'related_lbl' => 'Compila la richiesta campione →',
		),

		// ---------------------------------------------------------------------
		// 06: Profilo sensoriale
		// ---------------------------------------------------------------------
		array(
			'title'       => 'Cos’è il profilo sensoriale di un caffè?',
			'content'     => "Il profilo sensoriale è una mappa qualitativa e strutturata del carattere aromatico percepito in tazza. Nel modello Espresso Coppola analizziamo 7 dimensioni chiave: intensità aromatica, intensità olfattiva, acidità, persistenza, tostatura, corpo e dolcezza.\n\nQuesti parametri non stabiliscono quale caffè sia migliore in assoluto, ma descrivono con precisione oggettiva l'identità di ogni miscela. Nella sezione DNA delle Miscele ogni valore è rappresentato visivamente su un grafico radar poligonale per facilitare un confronto immediato prima dell’assaggio.",
			'category'    => 'Profilo sensoriale',
			'order'       => 14,
			'featured'    => 1,
			'query'       => 'Cosa indicano i valori del profilo sensoriale e del grafico radar?',
			'related_url' => home_url( '/dna-delle-miscele/' ),
			'related_lbl' => 'Scopri il radar del DNA →',
		),
	);

	foreach ( $faqs as $item ) {
		// Ensure category exists
		$term = term_exists( $item['category'], 'ec_faq_category' );
		if ( ! $term ) {
			$term = wp_insert_term( $item['category'], 'ec_faq_category' );
		}
		$term_id = is_array( $term ) ? (int) $term['term_id'] : (int) $term;

		// Insert post
		$post_id = wp_insert_post(
			array(
				'post_title'   => $item['title'],
				'post_content' => $item['content'],
				'post_status'  => 'publish',
				'post_type'    => 'ec_faq',
				'menu_order'   => $item['order'],
			)
		);

		if ( $post_id && ! is_wp_error( $post_id ) ) {
			if ( $term_id ) {
				wp_set_object_terms( $post_id, array( $term_id ), 'ec_faq_category' );
			}
			update_post_meta( $post_id, '_ec_faq_active', '1' );
			update_post_meta( $post_id, '_ec_faq_featured', (string) $item['featured'] );
			update_post_meta( $post_id, '_ec_faq_order', (int) $item['order'] );
			update_post_meta( $post_id, '_ec_faq_conversational_query', $item['query'] );
			if ( ! empty( $item['related_url'] ) ) {
				update_post_meta( $post_id, '_ec_faq_related_url', $item['related_url'] );
			}
			if ( ! empty( $item['related_lbl'] ) ) {
				update_post_meta( $post_id, '_ec_faq_related_label', $item['related_lbl'] );
			}
		}
	}

	update_option( 'espressocoppola_faqs_seeded_v1', '1', false );
}
add_action( 'init', 'espressocoppola_seed_initial_faqs', 20 );

/**
 * Update already-seeded FAQ references from Coffee Finder to Coffee Gateway.
 *
 * Runs once and only touches FAQs that still point to the exact retired anchor.
 *
 * @return void
 */
function espressocoppola_migrate_finder_faqs_to_gateway() {
	if ( get_option( 'espressocoppola_faqs_gateway_migrated_v1' ) ) {
		return;
	}

	$old_url = home_url( '/#coffee-finder' );
	$new_url = home_url( '/#coffee-gateway' );
	$legacy_label_map = array(
		'Trova il tuo Espresso con il Finder →'   => 'Trova il formato nel Coffee Gateway →',
		'Avvia la guida guidata Coffee Finder →' => 'Apri il Coffee Gateway →',
	);
	$faq_ids = get_posts(
		array(
			'post_type'              => 'ec_faq',
			'post_status'            => 'any',
			'posts_per_page'         => -1,
			'fields'                 => 'ids',
			'no_found_rows'          => true,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
			'meta_key'               => '_ec_faq_related_url',
			'meta_value'             => $old_url,
		)
	);
	$migration_complete = true;

	foreach ( $faq_ids as $faq_id ) {
		$content         = (string) get_post_field( 'post_content', $faq_id, 'raw' );
		$updated_content = espressocoppola_replace_finder_faq_copy( $content );

		if ( $updated_content !== $content ) {
			$result = wp_update_post(
				array(
					'ID'           => $faq_id,
					'post_content' => wp_slash( $updated_content ),
				),
				true
			);

			if ( is_wp_error( $result ) ) {
				$migration_complete = false;
				continue;
			}
		}

		$current_label = (string) get_post_meta( $faq_id, '_ec_faq_related_label', true );
		if ( isset( $legacy_label_map[ $current_label ] ) ) {
			$new_label     = $legacy_label_map[ $current_label ];
			$label_updated = update_post_meta( $faq_id, '_ec_faq_related_label', $new_label );
			if ( false === $label_updated && $new_label !== (string) get_post_meta( $faq_id, '_ec_faq_related_label', true ) ) {
				$migration_complete = false;
				continue;
			}
		}

		$url_updated = update_post_meta( $faq_id, '_ec_faq_related_url', $new_url );
		if ( false === $url_updated && $new_url !== (string) get_post_meta( $faq_id, '_ec_faq_related_url', true ) ) {
			$migration_complete = false;
		}
	}

	if ( $migration_complete ) {
		update_option( 'espressocoppola_faqs_gateway_migrated_v1', '1', false );
	}
}
add_action( 'init', 'espressocoppola_migrate_finder_faqs_to_gateway', 25 );
