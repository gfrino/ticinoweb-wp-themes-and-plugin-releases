<?php
/**
 * Data adapter and page helpers for the WooCommerce Cart page.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Whether the current page is the WooCommerce Cart page.
 * Detects standard WooCommerce cart, Gutenberg block cart, shortcode cart, and cart slugs.
 *
 * @return bool
 */
function espressocoppola_is_cart_page() {
	if ( function_exists( 'is_cart' ) && is_cart() ) {
		return true;
	}

	global $post;
	if ( $post instanceof WP_Post ) {
		if ( has_block( 'woocommerce/cart', $post ) || has_shortcode( $post->post_content, 'woocommerce_cart' ) ) {
			return true;
		}
		if ( 'carrello' === $post->post_name || 'cart' === $post->post_name ) {
			return true;
		}
	}

	return false;
}

/**
 * Add a stable body class for cart styling.
 *
 * @param string[] $classes Body classes.
 * @return string[]
 */
function espressocoppola_cart_body_class( $classes ) {
	if ( espressocoppola_is_cart_page() ) {
		$classes[] = 'espresso-coppola-cart';
	}

	return $classes;
}
add_filter( 'body_class', 'espressocoppola_cart_body_class' );
