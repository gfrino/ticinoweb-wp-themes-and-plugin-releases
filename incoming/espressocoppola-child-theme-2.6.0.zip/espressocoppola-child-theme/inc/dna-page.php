<?php
/** Sensory DNA page data adapter. @package EspressoCoppolaChildTheme */
if ( ! defined( 'ABSPATH' ) ) exit;

function espressocoppola_is_dna_page() {
	return is_page_template( 'page-templates/dna-delle-miscele.php' );
}

function espressocoppola_get_dna_page_context( $page_id ) {
	$explorer = espressocoppola_get_sensory_explorer_data();
	$catalog  = espressocoppola_get_shop_catalog();
	$shop_url = espressocoppola_get_header_shop_url();
	$products = array();
	$formats  = array();
	foreach ( $catalog as $item ) {
		if ( empty( $item['sensory'] ) || ! empty( $item['isAccessory'] ) ) continue;
		if ( count( $products ) < 3 ) $products[] = $item;
		foreach ( $item['types'] as $type ) {
			if ( ! isset( $formats[ $type['slug'] ] ) ) $formats[ $type['slug'] ] = $type + array( 'count' => 0, 'url' => add_query_arg( 'type', $type['slug'], $shop_url ) );
			++$formats[ $type['slug'] ]['count'];
		}
	}
	$featured = get_post_thumbnail_id( $page_id );
	$first    = $explorer['products'][0] ?? array();
	return array(
		'title'       => get_the_title( $page_id ) ?: __( 'DNA delle miscele', 'espressocoppola-child-theme' ),
		'intro'       => get_the_excerpt( $page_id ) ?: __( 'Esplora il carattere delle miscele Espresso Coppola attraverso aroma, corpo, tostatura e persistenza.', 'espressocoppola-child-theme' ),
		'content'     => trim( wp_strip_all_tags( get_post_field( 'post_content', $page_id ) ) ),
		'explorer'    => $explorer,
		'first'       => $first,
		'featured'    => $featured,
		'products'    => $products,
		'formats'     => array_values( $formats ),
		'shopUrl'     => $shop_url,
		'finderUrl'   => home_url( '/#coffee-gateway' ),
	);
}
