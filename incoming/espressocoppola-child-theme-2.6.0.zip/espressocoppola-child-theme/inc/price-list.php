<?php
/**
 * Dynamic Price List (Listino Prezzi) configuration and Customizer integration.
 *
 * Provides a dynamic button in the footer statement section with:
 * - A dedicated section in WordPress Customizer (Aspetto > Personalizza > Listino Prezzi)
 * - An administration page in the WordPress Dashboard (Aspetto > Listino Prezzi)
 * - Support for media library file upload (PDF), custom external URLs, download attribute and target options.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return the sanitized price list configuration.
 *
 * @return array{
 *     enabled: bool,
 *     button_text: string,
 *     file_url: string,
 *     custom_url: string,
 *     url: string,
 *     new_tab: bool,
 *     download: bool
 * }
 */
function espressocoppola_get_price_list_config() {
	$raw_enabled  = get_option( 'espressocoppola_price_list_enabled', '1' );
	$enabled      = ( '1' === (string) $raw_enabled || true === $raw_enabled );
	$button_text  = (string) get_option( 'espressocoppola_price_list_text', __( 'Scarica il listino', 'espressocoppola-child-theme' ) );
	$file_url     = (string) get_option( 'espressocoppola_price_list_file', '' );
	$custom_url   = (string) get_option( 'espressocoppola_price_list_url', '' );
	$raw_new_tab  = get_option( 'espressocoppola_price_list_new_tab', '1' );
	$new_tab      = ( '1' === (string) $raw_new_tab || true === $raw_new_tab );
	$raw_download = get_option( 'espressocoppola_price_list_download', '0' );
	$download     = ( '1' === (string) $raw_download || true === $raw_download );

	if ( '' === trim( $button_text ) ) {
		$button_text = __( 'Scarica il listino', 'espressocoppola-child-theme' );
	}

	$url = ! empty( $custom_url ) ? $custom_url : ( ! empty( $file_url ) ? $file_url : '#' );

	$config = array(
		'enabled'     => $enabled,
		'button_text' => $button_text,
		'file_url'    => $file_url,
		'custom_url'  => $custom_url,
		'url'         => $url,
		'new_tab'     => $new_tab,
		'download'    => $download,
	);

	/**
	 * Filter the price list configuration.
	 *
	 * @param array $config Sanitized price list options.
	 */
	return apply_filters( 'espressocoppola_price_list_config', $config );
}

/**
 * Register the Customizer section and controls for the Price List button.
 *
 * Accessible in: WordPress Admin > Aspetto > Personalizza > Listino Prezzi (Footer).
 *
 * @param WP_Customize_Manager $wp_customize Customizer instance.
 * @return void
 */
function espressocoppola_customize_register_price_list( $wp_customize ) {
	// 01 — Sezione dedicata
	$wp_customize->add_section(
		'espressocoppola_price_list_section',
		array(
			'title'       => __( 'Listino Prezzi (Footer)', 'espressocoppola-child-theme' ),
			'description' => __( 'Personalizza il pulsante dinamico del listino prezzi posizionato nel footer sotto "Scopri i nostri caffè".', 'espressocoppola-child-theme' ),
			'priority'    => 40,
		)
	);

	// 02 — Impostazione Abilitazione
	$wp_customize->add_setting(
		'espressocoppola_price_list_enabled',
		array(
			'type'              => 'option',
			'default'           => '1',
			'transport'         => 'refresh',
			'sanitize_callback' => 'espressocoppola_sanitize_checkbox',
		)
	);
	$wp_customize->add_control(
		'espressocoppola_price_list_enabled',
		array(
			'label'       => __( 'Mostra pulsante nel footer', 'espressocoppola-child-theme' ),
			'description' => __( 'Se deselezionato, il pulsante viene nascosto.', 'espressocoppola-child-theme' ),
			'section'     => 'espressocoppola_price_list_section',
			'type'        => 'checkbox',
		)
	);

	// 03 — Testo del pulsante
	$wp_customize->add_setting(
		'espressocoppola_price_list_text',
		array(
			'type'              => 'option',
			'default'           => __( 'Scarica il listino', 'espressocoppola-child-theme' ),
			'transport'         => 'refresh',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);
	$wp_customize->add_control(
		'espressocoppola_price_list_text',
		array(
			'label'       => __( 'Testo del pulsante', 'espressocoppola-child-theme' ),
			'description' => __( 'Testo mostrato nel pulsante (predefinito: "Scarica il listino").', 'espressocoppola-child-theme' ),
			'section'     => 'espressocoppola_price_list_section',
			'type'        => 'text',
		)
	);

	// 04 — Carica File PDF / Documento
	if ( class_exists( 'WP_Customize_Upload_Control' ) ) {
		$wp_customize->add_setting(
			'espressocoppola_price_list_file',
			array(
				'type'              => 'option',
				'default'           => '',
				'transport'         => 'refresh',
				'sanitize_callback' => 'esc_url_raw',
			)
		);
		$wp_customize->add_control(
			new WP_Customize_Upload_Control(
				$wp_customize,
				'espressocoppola_price_list_file',
				array(
					'label'       => __( 'File del Listino (PDF o documento)', 'espressocoppola-child-theme' ),
					'description' => __( 'Carica o seleziona il file PDF del listino prezzi dalla libreria multimediale.', 'espressocoppola-child-theme' ),
					'section'     => 'espressocoppola_price_list_section',
				)
			)
		);
	}

	// 05 — URL personalizzato alternativo
	$wp_customize->add_setting(
		'espressocoppola_price_list_url',
		array(
			'type'              => 'option',
			'default'           => '',
			'transport'         => 'refresh',
			'sanitize_callback' => 'esc_url_raw',
		)
	);
	$wp_customize->add_control(
		'espressocoppola_price_list_url',
		array(
			'label'       => __( 'URL alternativo o esterno (opzionale)', 'espressocoppola-child-theme' ),
			'description' => __( 'Se specificato, questo indirizzo ha la priorità sul file caricato (utile per link esterni, Google Drive o pagine dedicate).', 'espressocoppola-child-theme' ),
			'section'     => 'espressocoppola_price_list_section',
			'type'        => 'url',
		)
	);

	// 06 — Apri in nuova scheda
	$wp_customize->add_setting(
		'espressocoppola_price_list_new_tab',
		array(
			'type'              => 'option',
			'default'           => '1',
			'transport'         => 'refresh',
			'sanitize_callback' => 'espressocoppola_sanitize_checkbox',
		)
	);
	$wp_customize->add_control(
		'espressocoppola_price_list_new_tab',
		array(
			'label'       => __( 'Apri in una nuova scheda (target="_blank")', 'espressocoppola-child-theme' ),
			'section'     => 'espressocoppola_price_list_section',
			'type'        => 'checkbox',
		)
	);

	// 07 — Forza download diretto
	$wp_customize->add_setting(
		'espressocoppola_price_list_download',
		array(
			'type'              => 'option',
			'default'           => '0',
			'transport'         => 'refresh',
			'sanitize_callback' => 'espressocoppola_sanitize_checkbox',
		)
	);
	$wp_customize->add_control(
		'espressocoppola_price_list_download',
		array(
			'label'       => __( 'Forza il download diretto (attributo download)', 'espressocoppola-child-theme' ),
			'description' => __( 'Fa scaricare immediatamente il file sul dispositivo del visitatore invece di aprirlo nel browser.', 'espressocoppola-child-theme' ),
			'section'     => 'espressocoppola_price_list_section',
			'type'        => 'checkbox',
		)
	);
}
add_action( 'customize_register', 'espressocoppola_customize_register_price_list' );

/**
 * Sanitize checkbox inputs for options / Customizer.
 *
 * @param mixed $checked Checked state.
 * @return string '1' or '0'.
 */
function espressocoppola_sanitize_checkbox( $checked ) {
	return ( ( isset( $checked ) && true === (bool) $checked ) || '1' === (string) $checked ) ? '1' : '0';
}

/**
 * Register dedicated administrative page in WordPress dashboard under Aspetto > Listino Prezzi.
 *
 * Allows modifying the price list button directly from the backend dashboard without needing
 * to open the Customizer if preferred.
 *
 * @return void
 */
function espressocoppola_register_price_list_admin_menu() {
	$hook = add_theme_page(
		__( 'Listino Prezzi', 'espressocoppola-child-theme' ),
		__( 'Listino Prezzi', 'espressocoppola-child-theme' ),
		'manage_options',
		'espressocoppola-price-list',
		'espressocoppola_render_price_list_admin_page'
	);

	add_action( 'load-' . $hook, 'espressocoppola_price_list_admin_save' );
	add_action( 'admin_print_scripts-' . $hook, 'espressocoppola_price_list_admin_scripts' );
}
add_action( 'admin_menu', 'espressocoppola_register_price_list_admin_menu' );

/**
 * Enqueue native media scripts for the admin page.
 *
 * @return void
 */
function espressocoppola_price_list_admin_scripts() {
	wp_enqueue_media();
}

/**
 * Process form save on the dedicated admin page.
 *
 * @return void
 */
function espressocoppola_price_list_admin_save() {
	if ( ! isset( $_POST['espressocoppola_price_list_nonce'] ) ) {
		return;
	}

	if ( ! check_admin_referer( 'espressocoppola_save_price_list', 'espressocoppola_price_list_nonce' ) ) {
		wp_die( esc_html__( 'Verifica di sicurezza non superata.', 'espressocoppola-child-theme' ) );
	}

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Permessi insufficienti per compiere questa azione.', 'espressocoppola-child-theme' ) );
	}

	$enabled     = ! empty( $_POST['espressocoppola_price_list_enabled'] ) ? '1' : '0';
	$text        = isset( $_POST['espressocoppola_price_list_text'] ) ? sanitize_text_field( wp_unslash( $_POST['espressocoppola_price_list_text'] ) ) : '';
	$file        = isset( $_POST['espressocoppola_price_list_file'] ) ? esc_url_raw( wp_unslash( $_POST['espressocoppola_price_list_file'] ) ) : '';
	$url         = isset( $_POST['espressocoppola_price_list_url'] ) ? esc_url_raw( wp_unslash( $_POST['espressocoppola_price_list_url'] ) ) : '';
	$new_tab     = ! empty( $_POST['espressocoppola_price_list_new_tab'] ) ? '1' : '0';
	$download    = ! empty( $_POST['espressocoppola_price_list_download'] ) ? '1' : '0';

	update_option( 'espressocoppola_price_list_enabled', $enabled );
	update_option( 'espressocoppola_price_list_text', $text );
	update_option( 'espressocoppola_price_list_file', $file );
	update_option( 'espressocoppola_price_list_url', $url );
	update_option( 'espressocoppola_price_list_new_tab', $new_tab );
	update_option( 'espressocoppola_price_list_download', $download );

	wp_safe_redirect( add_query_arg( array( 'page' => 'espressocoppola-price-list', 'updated' => '1' ), admin_url( 'themes.php' ) ) );
	exit;
}

/**
 * Render the dedicated administrative page in WordPress Dashboard.
 *
 * @return void
 */
function espressocoppola_render_price_list_admin_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$config         = espressocoppola_get_price_list_config();
	$customizer_url = admin_url( 'customize.php?autofocus[section]=espressocoppola_price_list_section' );
	?>
	<div class="wrap ec-admin-price-list-wrap" style="max-width: 860px; margin-top: 24px;">
		<div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom: 20px;">
			<div>
				<h1 style="font-size: 26px; font-weight: 700; color: #1b120c; margin-bottom: 6px;">
					☕ <?php esc_html_e( 'Listino Prezzi — Pulsante Footer', 'espressocoppola-child-theme' ); ?>
				</h1>
				<p style="color: #64748b; font-size: 14px; margin: 0;">
					<?php esc_html_e( 'Gestisci il pulsante dinamico del listino prezzi posizionato nel footer, sotto il bottone "Scopri i nostri caffè".', 'espressocoppola-child-theme' ); ?>
				</p>
			</div>
			<div>
				<a href="<?php echo esc_url( $customizer_url ); ?>" class="button button-secondary" style="display:inline-flex; align-items:center; gap:6px;">
					<span><?php esc_html_e( 'Modifica nel Customizer Live', 'espressocoppola-child-theme' ); ?></span>
					<span aria-hidden="true">↗</span>
				</a>
			</div>
		</div>

		<?php if ( isset( $_GET['updated'] ) && '1' === $_GET['updated'] ) : ?>
			<div class="notice notice-success is-dismissible" style="border-left-color: #c89d54;">
				<p><strong><?php esc_html_e( 'Impostazioni del listino prezzi salvate con successo!', 'espressocoppola-child-theme' ); ?></strong></p>
			</div>
		<?php endif; ?>

		<div style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 28px; box-shadow: 0 4px 16px rgba(0,0,0,0.04);">
			<form method="post" action="">
				<?php wp_nonce_field( 'espressocoppola_save_price_list', 'espressocoppola_price_list_nonce' ); ?>

				<table class="form-table" role="presentation" style="margin-top: 0;">
					<tbody>
						<!-- 01 — Abilita pulsante -->
						<tr>
							<th scope="row" style="padding-top: 14px;">
								<label for="ec_pl_enabled"><?php esc_html_e( 'Visibilità Pulsante', 'espressocoppola-child-theme' ); ?></label>
							</th>
							<td>
								<label style="display:inline-flex; align-items:center; gap:8px; font-weight:600; cursor:pointer;">
									<input type="checkbox" name="espressocoppola_price_list_enabled" id="ec_pl_enabled" value="1" <?php checked( $config['enabled'] ); ?>>
									<span><?php esc_html_e( 'Mostra il pulsante "Scarica il listino" nel footer', 'espressocoppola-child-theme' ); ?></span>
								</label>
								<p class="description"><?php esc_html_e( 'Se disattivato, il pulsante non verrà renderizzato nel footer.', 'espressocoppola-child-theme' ); ?></p>
							</td>
						</tr>

						<!-- 02 — Testo pulsante -->
						<tr>
							<th scope="row">
								<label for="ec_pl_text"><?php esc_html_e( 'Testo del Pulsante', 'espressocoppola-child-theme' ); ?></label>
							</th>
							<td>
								<input type="text" name="espressocoppola_price_list_text" id="ec_pl_text" value="<?php echo esc_attr( $config['button_text'] ); ?>" class="regular-text" style="width: 100%; max-width: 440px;" placeholder="<?php esc_attr_e( 'Scarica il listino', 'espressocoppola-child-theme' ); ?>">
								<p class="description"><?php esc_html_e( 'Testo visualizzato all\'interno del bottone nel footer.', 'espressocoppola-child-theme' ); ?></p>
							</td>
						</tr>

						<!-- 03 — File PDF / Upload -->
						<tr>
							<th scope="row">
								<label for="ec_pl_file"><?php esc_html_e( 'File del Listino (PDF)', 'espressocoppola-child-theme' ); ?></label>
							</th>
							<td>
								<div style="display:flex; gap:10px; align-items:center; max-width: 580px;">
									<input type="url" name="espressocoppola_price_list_file" id="ec_pl_file" value="<?php echo esc_attr( $config['file_url'] ); ?>" class="regular-text" style="flex:1;" placeholder="https://.../listino.pdf">
									<button type="button" class="button button-secondary" id="ec_pl_upload_btn">
										📁 <?php esc_html_e( 'Seleziona / Carica PDF', 'espressocoppola-child-theme' ); ?>
									</button>
								</div>
								<p class="description"><?php esc_html_e( 'Carica o seleziona un file PDF direttamente dalla Libreria Media di WordPress.', 'espressocoppola-child-theme' ); ?></p>
							</td>
						</tr>

						<!-- 04 — URL Alternativo / Esterno -->
						<tr>
							<th scope="row">
								<label for="ec_pl_url"><?php esc_html_e( 'URL Alternativo (Opzionale)', 'espressocoppola-child-theme' ); ?></label>
							</th>
							<td>
								<input type="url" name="espressocoppola_price_list_url" id="ec_pl_url" value="<?php echo esc_attr( $config['custom_url'] ); ?>" class="regular-text" style="width: 100%; max-width: 440px;" placeholder="https://drive.google.com/... o https://...">
								<p class="description"><?php esc_html_e( 'Se compilato, ha priorità sul file caricato. Utile per link a Google Drive, Dropbox o landing page dedicate.', 'espressocoppola-child-theme' ); ?></p>
							</td>
						</tr>

						<!-- 05 — Target Nuova Scheda -->
						<tr>
							<th scope="row">
								<label for="ec_pl_new_tab"><?php esc_html_e( 'Comportamento Apertura', 'espressocoppola-child-theme' ); ?></label>
							</th>
							<td>
								<label style="display:inline-flex; align-items:center; gap:8px; cursor:pointer;">
									<input type="checkbox" name="espressocoppola_price_list_new_tab" id="ec_pl_new_tab" value="1" <?php checked( $config['new_tab'] ); ?>>
									<span><?php esc_html_e( 'Apri in una nuova scheda del browser (target="_blank")', 'espressocoppola-child-theme' ); ?></span>
								</label>
							</td>
						</tr>

						<!-- 06 — Download Diretto -->
						<tr>
							<th scope="row">
								<label for="ec_pl_download"><?php esc_html_e( 'Download Diretto', 'espressocoppola-child-theme' ); ?></label>
							</th>
							<td>
								<label style="display:inline-flex; align-items:center; gap:8px; cursor:pointer;">
									<input type="checkbox" name="espressocoppola_price_list_download" id="ec_pl_download" value="1" <?php checked( $config['download'] ); ?>>
									<span><?php esc_html_e( 'Forza il download automatico del file sul dispositivo (attributo download)', 'espressocoppola-child-theme' ); ?></span>
								</label>
							</td>
						</tr>
					</tbody>
				</table>

				<div style="margin-top: 24px; padding-top: 20px; border-top: 1px solid #f1f5f9; display:flex; justify-content:space-between; align-items:center;">
					<button type="submit" class="button button-primary button-large" style="background:#1b120c; border-color:#1b120c; padding: 4px 24px; height: 42px; font-size: 14px;">
						<?php esc_html_e( 'Salva Modifiche', 'espressocoppola-child-theme' ); ?>
					</button>
					<span style="font-size: 13px; color: #94a3b8;">
						<?php esc_html_e( 'Le modifiche saranno visibili immediatamente nel footer del sito.', 'espressocoppola-child-theme' ); ?>
					</span>
				</div>
			</form>
		</div>
	</div>

	<script>
	jQuery(document).ready(function($) {
		var mediaUploader;
		$('#ec_pl_upload_btn').on('click', function(e) {
			e.preventDefault();
			if (mediaUploader) {
				mediaUploader.open();
				return;
			}
			mediaUploader = wp.media({
				title: '<?php echo esc_js( __( 'Seleziona o carica il Listino Prezzi', 'espressocoppola-child-theme' ) ); ?>',
				button: {
					text: '<?php echo esc_js( __( 'Usa questo file come Listino', 'espressocoppola-child-theme' ) ); ?>'
				},
				multiple: false
			});
			mediaUploader.on('select', function() {
				var attachment = mediaUploader.state().get('selection').first().toJSON();
				$('#ec_pl_file').val(attachment.url);
			});
			mediaUploader.open();
		});
	});
	</script>
	<?php
}
