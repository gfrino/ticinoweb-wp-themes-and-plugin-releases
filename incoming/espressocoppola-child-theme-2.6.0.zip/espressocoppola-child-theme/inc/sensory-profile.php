<?php
/**
 * Product-owned sensory profiles for Espresso Coppola.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return the canonical radar axes in their immutable display order.
 *
 * @return array<string,array{label:string,meta_key:string}>
 */
function espressocoppola_get_sensory_axes() {
	return array(
		'aromatic_intensity'  => array(
			'label'    => __( 'Intensità aromatica', 'espressocoppola-child-theme' ),
			'meta_key' => '_ec_sensory_aromatic_intensity',
		),
		'olfactory_intensity' => array(
			'label'    => __( 'Intensità olfattiva', 'espressocoppola-child-theme' ),
			'meta_key' => '_ec_sensory_olfactory_intensity',
		),
		'acidity'             => array(
			'label'    => __( 'Acido', 'espressocoppola-child-theme' ),
			'meta_key' => '_ec_sensory_acidity',
		),
		'persistence'         => array(
			'label'    => __( 'Persistente', 'espressocoppola-child-theme' ),
			'meta_key' => '_ec_sensory_persistence',
		),
		'roast'               => array(
			'label'    => __( 'Tostato', 'espressocoppola-child-theme' ),
			'meta_key' => '_ec_sensory_roast',
		),
		'body'                => array(
			'label'    => __( 'Corpo', 'espressocoppola-child-theme' ),
			'meta_key' => '_ec_sensory_body',
		),
		'sweetness'           => array(
			'label'    => __( 'Dolce', 'espressocoppola-child-theme' ),
			'meta_key' => '_ec_sensory_sweetness',
		),
	);
}

/**
 * Validate one sensory score without coercing invalid data into range.
 *
 * @param mixed $value Submitted value.
 * @return int|null
 */
function espressocoppola_sanitize_sensory_value( $value ) {
	if ( is_int( $value ) ) {
		$integer = $value;
	} elseif ( is_string( $value ) && preg_match( '/^[1-5]$/', trim( $value ) ) ) {
		$integer = (int) trim( $value );
	} else {
		return null;
	}

	return $integer >= 1 && $integer <= 5 ? $integer : null;
}

/**
 * Normalize raw profile data into one predictable structure.
 *
 * @param array<string,mixed> $profile Raw profile data.
 * @return array<string,mixed>
 */
function espressocoppola_normalize_sensory_profile( $profile ) {
	$normalized = array(
		'enabled'            => ! empty( $profile['enabled'] ) && in_array( $profile['enabled'], array( true, 1, '1', 'yes', 'on' ), true ),
		'note'               => isset( $profile['note'] ) ? sanitize_text_field( wp_strip_all_tags( (string) $profile['note'] ) ) : '',
		'color'              => isset( $profile['color'] ) && sanitize_hex_color( $profile['color'] ) ? strtolower( sanitize_hex_color( $profile['color'] ) ) : '#d6b77a',
		'reference_image_id' => isset( $profile['reference_image_id'] ) ? absint( $profile['reference_image_id'] ) : 0,
		'values'             => array(),
	);

	$submitted_values = isset( $profile['values'] ) && is_array( $profile['values'] ) ? array_values( $profile['values'] ) : array();

	foreach ( array_keys( espressocoppola_get_sensory_axes() ) as $index => $axis_key ) {
		$raw_value = array_key_exists( $axis_key, $profile )
			? $profile[ $axis_key ]
			: ( array_key_exists( $index, $submitted_values ) ? $submitted_values[ $index ] : null );
		$value = espressocoppola_sanitize_sensory_value( $raw_value );

		$normalized[ $axis_key ] = $value;
		$normalized['values'][]  = $value;
	}

	return $normalized;
}

/**
 * Describe whether all seven scores are present and valid.
 *
 * @param array<string,mixed> $profile Raw or normalized profile data.
 * @return array{complete:bool,missing:array<string,string>}
 */
function espressocoppola_get_sensory_profile_status( $profile ) {
	$profile = espressocoppola_normalize_sensory_profile( $profile );
	$missing = array();

	foreach ( espressocoppola_get_sensory_axes() as $axis_key => $axis ) {
		if ( null === $profile[ $axis_key ] ) {
			$missing[ $axis_key ] = $axis['label'];
		}
	}

	return array(
		'complete' => empty( $missing ),
		'missing'  => $missing,
	);
}

/**
 * Read a sensory profile from one WooCommerce parent product.
 *
 * @param WC_Product|int $product Product object or ID.
 * @return array<string,mixed>
 */
function espressocoppola_get_product_sensory_profile( $product ) {
	if ( is_numeric( $product ) && function_exists( 'wc_get_product' ) ) {
		$product = wc_get_product( absint( $product ) );
	}

	if ( ! $product instanceof WC_Product ) {
		return espressocoppola_normalize_sensory_profile( array() );
	}

	$profile = array(
		'enabled'            => $product->get_meta( '_ec_sensory_enabled', true ),
		'note'               => $product->get_meta( '_ec_sensory_note', true ),
		'color'              => $product->get_meta( '_ec_sensory_color', true ),
		'reference_image_id' => $product->get_meta( '_ec_sensory_reference_image_id', true ),
	);

	foreach ( espressocoppola_get_sensory_axes() as $axis_key => $axis ) {
		$profile[ $axis_key ] = $product->get_meta( $axis['meta_key'], true );
	}

	return espressocoppola_normalize_sensory_profile( $profile );
}

/**
 * Add the sensory profile tab to the native WooCommerce product data box.
 *
 * @param array<string,array<string,mixed>> $tabs Product data tabs.
 * @return array<string,array<string,mixed>>
 */
function espressocoppola_add_sensory_product_data_tab( $tabs ) {
	$tabs['ec_sensory'] = array(
		'label'    => __( 'Profilo sensoriale', 'espressocoppola-child-theme' ),
		'target'   => 'ec_sensory_product_data',
		'class'    => array( 'show_if_simple', 'show_if_variable' ),
		'priority' => 72,
	);

	return $tabs;
}
add_filter( 'woocommerce_product_data_tabs', 'espressocoppola_add_sensory_product_data_tab' );

/**
 * Render the native product-data panel for sensory values.
 *
 * @return void
 */
function espressocoppola_render_sensory_product_data_panel() {
	global $post;

	$product = $post instanceof WP_Post && function_exists( 'wc_get_product' ) ? wc_get_product( $post->ID ) : null;
	$profile = espressocoppola_get_product_sensory_profile( $product );
	$status  = espressocoppola_get_sensory_profile_status( $profile );
	$image   = $profile['reference_image_id'] ? wp_get_attachment_image( $profile['reference_image_id'], 'medium' ) : '';
	$axes_count      = count( espressocoppola_get_sensory_axes() );
	$completed_count = $axes_count - count( $status['missing'] );
	$reference_file  = '';
	if ( $image ) {
		$reference_path = get_attached_file( $profile['reference_image_id'] );
		$reference_file = $reference_path ? wp_basename( $reference_path ) : '';
	}
	?>
	<div id="ec_sensory_product_data" class="panel woocommerce_options_panel hidden" data-sensory-admin>
		<?php wp_nonce_field( 'ec_save_sensory_profile', 'ec_sensory_nonce' ); ?>
		<header class="ec-sensory-admin__header">
			<div>
				<h2><?php esc_html_e( 'Profilo sensoriale Espresso Coppola', 'espressocoppola-child-theme' ); ?></h2>
				<p><?php esc_html_e( 'Inserisci i valori osservati nel grafico originale. I dati non vengono mai dedotti dal prodotto.', 'espressocoppola-child-theme' ); ?></p>
			</div>
			<div class="ec-sensory-admin__completion">
				<p class="ec-sensory-admin__status<?php echo $status['complete'] ? ' is-complete' : ''; ?>" data-sensory-status aria-live="polite">
					<?php
					if ( $status['complete'] ) {
						esc_html_e( 'Profilo completo ✓', 'espressocoppola-child-theme' );
					} else {
						echo esc_html(
							sprintf(
								/* translators: %d: number of missing sensory values. */
								_n( 'Profilo incompleto — manca %d valore', 'Profilo incompleto — mancano %d valori', count( $status['missing'] ), 'espressocoppola-child-theme' ),
								count( $status['missing'] )
							)
						);
					}
					?>
				</p>
				<small data-sensory-progress><?php echo esc_html( sprintf( '%1$d / %2$d valori compilati', $completed_count, $axes_count ) ); ?></small>
			</div>
		</header>

		<div class="options_group ec-sensory-admin__enable">
			<label for="ec_sensory_enabled">
				<input id="ec_sensory_enabled" type="checkbox" name="ec_sensory[enabled]" value="yes" <?php checked( $profile['enabled'] ); ?>>
				<strong><?php esc_html_e( 'Mostra questo prodotto nell’Explorer Sensoriale', 'espressocoppola-child-theme' ); ?></strong>
			</label>
		</div>

		<div class="ec-sensory-admin__workspace" data-sensory-main>
			<section class="ec-sensory-admin__card ec-sensory-admin__fields">
				<h3><?php esc_html_e( 'Valori radar', 'espressocoppola-child-theme' ); ?></h3>
				<p class="ec-sensory-admin__section-help"><?php esc_html_e( 'Imposta ogni caratteristica su una scala da 1 a 5.', 'espressocoppola-child-theme' ); ?></p>
				<?php foreach ( espressocoppola_get_sensory_axes() as $axis_key => $axis ) : ?>
					<div class="ec-sensory-admin__axis">
						<div class="ec-sensory-admin__axis-header">
							<label for="ec_sensory_<?php echo esc_attr( $axis_key ); ?>_number"><?php echo esc_html( $axis['label'] ); ?></label>
							<output for="ec_sensory_<?php echo esc_attr( $axis_key ); ?>_range ec_sensory_<?php echo esc_attr( $axis_key ); ?>_number" data-sensory-output data-sensory-axis="<?php echo esc_attr( $axis_key ); ?>"><?php echo esc_html( null === $profile[ $axis_key ] ? '— / 5' : $profile[ $axis_key ] . ' / 5' ); ?></output>
						</div>
						<div class="ec-sensory-admin__axis-controls">
							<input id="ec_sensory_<?php echo esc_attr( $axis_key ); ?>_range" type="range" min="1" max="5" step="1" value="<?php echo esc_attr( null === $profile[ $axis_key ] ? 1 : $profile[ $axis_key ] ); ?>" data-sensory-range data-sensory-axis="<?php echo esc_attr( $axis_key ); ?>">
							<input id="ec_sensory_<?php echo esc_attr( $axis_key ); ?>_number" type="number" name="ec_sensory[<?php echo esc_attr( $axis_key ); ?>]" min="1" max="5" step="1" value="<?php echo esc_attr( null === $profile[ $axis_key ] ? '' : $profile[ $axis_key ] ); ?>" data-sensory-number data-sensory-axis="<?php echo esc_attr( $axis_key ); ?>">
						</div>
					</div>
				<?php endforeach; ?>
			</section>
			<section class="ec-sensory-admin__card ec-sensory-admin__preview">
				<h3><?php esc_html_e( 'Preview ricostruita', 'espressocoppola-child-theme' ); ?></h3>
				<p class="ec-sensory-admin__section-help"><?php esc_html_e( 'Il grafico si aggiorna in tempo reale.', 'espressocoppola-child-theme' ); ?></p>
				<svg viewBox="0 0 520 520" role="img" data-sensory-radar></svg>
			</section>
		</div>

		<details class="ec-sensory-admin__card ec-sensory-admin__reference" data-sensory-reference-details>
			<summary>
				<span><strong><?php esc_html_e( 'Grafico originale', 'espressocoppola-child-theme' ); ?></strong><small data-sensory-reference-filename><?php echo esc_html( $reference_file ? $reference_file : __( 'Nessun file selezionato', 'espressocoppola-child-theme' ) ); ?></small></span>
				<span class="ec-sensory-admin__disclosure-label" data-sensory-reference-toggle><?php esc_html_e( 'Apri', 'espressocoppola-child-theme' ); ?></span>
			</summary>
			<div class="ec-sensory-admin__reference-body">
				<div class="ec-sensory-admin__reference-stage" data-sensory-reference-preview>
					<?php if ( $image ) : echo wp_kses_post( $image ); else : ?><p><?php esc_html_e( 'Nessuna immagine di riferimento.', 'espressocoppola-child-theme' ); ?></p><?php endif; ?>
				</div>
				<div class="ec-sensory-admin__reference-copy">
					<p><?php esc_html_e( 'Conserva qui il grafico usato come riferimento visivo durante la compilazione.', 'espressocoppola-child-theme' ); ?></p>
					<input type="hidden" name="ec_sensory[reference_image_id]" value="<?php echo esc_attr( $profile['reference_image_id'] ); ?>" data-sensory-reference-id>
					<div class="ec-sensory-admin__media-actions">
						<button type="button" class="button" data-sensory-reference-select><?php echo esc_html( $image ? __( 'Sostituisci immagine', 'espressocoppola-child-theme' ) : __( 'Scegli immagine', 'espressocoppola-child-theme' ) ); ?></button>
						<button type="button" class="button-link-delete" data-sensory-reference-remove<?php echo $image ? '' : ' hidden'; ?>><?php esc_html_e( 'Rimuovi', 'espressocoppola-child-theme' ); ?></button>
					</div>
				</div>
			</div>
		</details>

		<section class="ec-sensory-admin__card ec-sensory-admin__editorial" data-sensory-profile-details>
			<h3><?php esc_html_e( 'Dettagli profilo', 'espressocoppola-child-theme' ); ?></h3>
			<div class="ec-sensory-admin__detail-grid">
				<p class="form-field"><label for="ec_sensory_note"><?php esc_html_e( 'Nota sensoriale', 'espressocoppola-child-theme' ); ?></label><textarea id="ec_sensory_note" name="ec_sensory[note]" rows="3" maxlength="240"><?php echo esc_textarea( $profile['note'] ); ?></textarea></p>
				<p class="form-field"><label for="ec_sensory_color"><?php esc_html_e( 'Colore profilo', 'espressocoppola-child-theme' ); ?></label><input id="ec_sensory_color" type="text" name="ec_sensory[color]" value="<?php echo esc_attr( $profile['color'] ); ?>" class="ec-sensory-color-field" data-default-color="#d6b77a"></p>
			</div>
		</section>
	</div>
	<?php
}
add_action( 'woocommerce_product_data_panels', 'espressocoppola_render_sensory_product_data_panel' );

/**
 * Persist validated sensory profile values on the parent product.
 *
 * @param WC_Product $product Product being saved.
 * @return void
 */
function espressocoppola_save_sensory_product_data( $product ) {
	if ( ! $product instanceof WC_Product || ! isset( $_POST['ec_sensory_nonce'] ) ) {
		return;
	}

	$nonce = sanitize_text_field( wp_unslash( $_POST['ec_sensory_nonce'] ) );
	if ( ! wp_verify_nonce( $nonce, 'ec_save_sensory_profile' ) || ! current_user_can( 'edit_post', $product->get_id() ) ) {
		return;
	}

	$submitted = isset( $_POST['ec_sensory'] ) && is_array( $_POST['ec_sensory'] )
		? wp_unslash( $_POST['ec_sensory'] )
		: array();

	$product->update_meta_data( '_ec_sensory_enabled', ! empty( $submitted['enabled'] ) && 'yes' === $submitted['enabled'] ? 'yes' : 'no' );

	foreach ( espressocoppola_get_sensory_axes() as $axis_key => $axis ) {
		$value = isset( $submitted[ $axis_key ] ) ? espressocoppola_sanitize_sensory_value( $submitted[ $axis_key ] ) : null;
		if ( null === $value ) {
			$product->delete_meta_data( $axis['meta_key'] );
		} else {
			$product->update_meta_data( $axis['meta_key'], (string) $value );
		}
	}

	$note = isset( $submitted['note'] ) ? sanitize_text_field( wp_strip_all_tags( $submitted['note'] ) ) : '';
	if ( '' === $note ) {
		$product->delete_meta_data( '_ec_sensory_note' );
	} else {
		$product->update_meta_data( '_ec_sensory_note', $note );
	}

	$color = isset( $submitted['color'] ) ? sanitize_hex_color( $submitted['color'] ) : '';
	if ( $color ) {
		$product->update_meta_data( '_ec_sensory_color', strtolower( $color ) );
	} else {
		$product->delete_meta_data( '_ec_sensory_color' );
	}

	$reference_image_id = isset( $submitted['reference_image_id'] ) ? absint( $submitted['reference_image_id'] ) : 0;
	if ( $reference_image_id && wp_attachment_is_image( $reference_image_id ) ) {
		$product->update_meta_data( '_ec_sensory_reference_image_id', (string) $reference_image_id );
	} else {
		$product->delete_meta_data( '_ec_sensory_reference_image_id' );
	}

	unset( $GLOBALS['espressocoppola_sensory_explorer_request_cache'] );
}
add_action( 'woocommerce_admin_process_product_object', 'espressocoppola_save_sensory_product_data' );

/**
 * Select the most specific product category assigned to one product.
 *
 * @param WC_Product $product Product instance.
 * @return array{id:int,slug:string,name:string,depth:int}|null
 */
function espressocoppola_get_sensory_product_category( $product ) {
	$terms = wc_get_product_terms(
		$product->get_id(),
		'product_cat',
		array( 'fields' => 'all' )
	);

	if ( is_wp_error( $terms ) || empty( $terms ) ) {
		return null;
	}

	$candidates = array();
	foreach ( $terms as $term ) {
		if ( ! $term instanceof WP_Term ) {
			continue;
		}

		$candidates[] = array(
			'id'         => (int) $term->term_id,
			'slug'       => $term->slug,
			'name'       => $term->name,
			'depth'      => count( get_ancestors( $term->term_id, 'product_cat', 'taxonomy' ) ),
			'term_order' => isset( $term->term_order ) ? (int) $term->term_order : 0,
		);
	}

	usort(
		$candidates,
		static function ( $left, $right ) {
			if ( $left['depth'] !== $right['depth'] ) {
				return $right['depth'] <=> $left['depth'];
			}
			if ( $left['term_order'] !== $right['term_order'] ) {
				return $left['term_order'] <=> $right['term_order'];
			}
			return strcasecmp( $left['name'], $right['name'] );
		}
	);

	if ( empty( $candidates ) ) {
		return null;
	}

	$category = $candidates[0];
	unset( $category['term_order'] );

	return $category;
}

/**
 * Serialize one complete product into the minimal Explorer payload.
 *
 * @param WC_Product         $product Product instance.
 * @param array<string,mixed> $profile Valid normalized profile.
 * @return array<string,mixed>|null
 */
function espressocoppola_serialize_sensory_product( $product, $profile ) {
	if ( ! $product instanceof WC_Product || 'publish' !== $product->get_status() || empty( $profile['enabled'] ) ) {
		return null;
	}

	$status = espressocoppola_get_sensory_profile_status( $profile );
	if ( ! $status['complete'] ) {
		return null;
	}

	$category = espressocoppola_get_sensory_product_category( $product );
	if ( ! $category ) {
		return null;
	}

	$blend    = '';
	$taxonomy = function_exists( 'espressocoppola_get_blend_taxonomy' ) ? espressocoppola_get_blend_taxonomy() : '';
	if ( $taxonomy && taxonomy_exists( $taxonomy ) ) {
		$blend_terms = wc_get_product_terms( $product->get_id(), $taxonomy, array( 'fields' => 'names' ) );
		if ( ! is_wp_error( $blend_terms ) && ! empty( $blend_terms ) ) {
			$blend = implode( ' · ', array_map( 'sanitize_text_field', $blend_terms ) );
		}
	}

	$image_id = $product->get_image_id();

	return array(
		'id'          => $product->get_id(),
		'name'        => $product->get_name(),
		'url'         => get_permalink( $product->get_id() ),
		'image'       => $image_id ? wp_get_attachment_image_url( $image_id, 'woocommerce_single' ) : '',
		'imageSrcset' => $image_id ? wp_get_attachment_image_srcset( $image_id, 'woocommerce_single' ) : '',
		'imageSizes'  => '(max-width: 720px) 42vw, 28vw',
		'category'    => $category,
		'blend'       => $blend,
		'note'        => $profile['note'],
		'color'       => $profile['color'],
		'values'      => array_values( $profile['values'] ),
	);
}

/**
 * Build the request-cached catalog for the homepage sensory Explorer.
 *
 * @return array{categories:array<int,array<string,mixed>>,products:array<int,array<string,mixed>>}
 */
function espressocoppola_get_sensory_explorer_data() {
	if ( isset( $GLOBALS['espressocoppola_sensory_explorer_request_cache'] ) && is_array( $GLOBALS['espressocoppola_sensory_explorer_request_cache'] ) ) {
		return $GLOBALS['espressocoppola_sensory_explorer_request_cache'];
	}

	$empty = array(
		'categories' => array(),
		'products'   => array(),
	);

	if ( ! function_exists( 'wc_get_products' ) || ! taxonomy_exists( 'product_cat' ) ) {
		$GLOBALS['espressocoppola_sensory_explorer_request_cache'] = $empty;
		return $empty;
	}

	$limit = max( 1, (int) apply_filters( 'espressocoppola_sensory_product_limit', 200 ) );
	$products = wc_get_products(
		array(
			'status'  => 'publish',
			'limit'   => $limit,
			'return'  => 'objects',
			'orderby' => array(
				'menu_order' => 'ASC',
				'title'      => 'ASC',
			),
		)
	);

	$valid = array();
	foreach ( $products as $product ) {
		if ( ! $product instanceof WC_Product || 'yes' !== $product->get_meta( '_ec_sensory_enabled', true ) ) {
			continue;
		}

		$profile = espressocoppola_get_product_sensory_profile( $product );
		$payload = espressocoppola_serialize_sensory_product( $product, $profile );
		if ( $payload ) {
			$valid[] = array(
				'product' => $product,
				'payload' => $payload,
			);
		}
	}

	usort(
		$valid,
		static function ( $left, $right ) {
			$left_featured  = $left['product']->is_featured() ? 1 : 0;
			$right_featured = $right['product']->is_featured() ? 1 : 0;

			if ( $left_featured !== $right_featured ) {
				return $right_featured <=> $left_featured;
			}

			$menu_order = $left['product']->get_menu_order() <=> $right['product']->get_menu_order();
			if ( 0 !== $menu_order ) {
				return $menu_order;
			}

			$name_order = strcasecmp( $left['product']->get_name(), $right['product']->get_name() );
			return 0 !== $name_order ? $name_order : $left['product']->get_id() <=> $right['product']->get_id();
		}
	);

	$categories = array();
	$payloads   = array();
	foreach ( $valid as $item ) {
		$payload     = $item['payload'];
		$category_id = (int) $payload['category']['id'];
		if ( ! isset( $categories[ $category_id ] ) ) {
			$categories[ $category_id ] = array(
				'id'    => $category_id,
				'slug'  => $payload['category']['slug'],
				'name'  => $payload['category']['name'],
				'count' => 0,
			);
		}
		++$categories[ $category_id ]['count'];
		$payloads[] = $payload;
	}

	$data = array(
		'categories' => array_values( $categories ),
		'products'   => $payloads,
	);
	$GLOBALS['espressocoppola_sensory_explorer_request_cache'] = $data;

	return $data;
}

/**
 * Load the editor assets only on WooCommerce product screens.
 *
 * @param string $hook_suffix Current admin page hook.
 * @return void
 */
function espressocoppola_enqueue_sensory_admin_assets( $hook_suffix ) {
	if ( ! in_array( $hook_suffix, array( 'post.php', 'post-new.php' ), true ) ) {
		return;
	}

	$screen = get_current_screen();
	if ( ! $screen || 'product' !== $screen->post_type ) {
		return;
	}

	wp_enqueue_media();
	wp_enqueue_style( 'wp-color-picker' );
	wp_enqueue_style(
		'espressocoppola-sensory-admin',
		get_stylesheet_directory_uri() . '/assets/css/sensory-profile-admin.css',
		array( 'wp-color-picker' ),
		espressocoppola_asset_version( 'assets/css/sensory-profile-admin.css' )
	);
	wp_enqueue_script(
		'espressocoppola-sensory-radar',
		get_stylesheet_directory_uri() . '/assets/js/sensory-radar.js',
		array(),
		espressocoppola_asset_version( 'assets/js/sensory-radar.js' ),
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);
	wp_enqueue_script(
		'espressocoppola-sensory-admin',
		get_stylesheet_directory_uri() . '/assets/js/sensory-profile-admin.js',
		array( 'jquery', 'wp-color-picker', 'espressocoppola-sensory-radar' ),
		espressocoppola_asset_version( 'assets/js/sensory-profile-admin.js' ),
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);
	wp_localize_script(
		'espressocoppola-sensory-admin',
		'espressoSensoryAdminI18n',
		array(
			'complete'     => __( 'Profilo completo ✓', 'espressocoppola-child-theme' ),
			'missingOne'   => __( 'Profilo incompleto — manca 1 valore', 'espressocoppola-child-theme' ),
			'missingMany'  => __( 'Profilo incompleto — mancano %d valori', 'espressocoppola-child-theme' ),
			'previewName'  => __( 'Preview prodotto', 'espressocoppola-child-theme' ),
			'mediaTitle'   => __( 'Grafico originale di riferimento', 'espressocoppola-child-theme' ),
			'mediaButton'  => __( 'Usa questa immagine', 'espressocoppola-child-theme' ),
			'referenceAlt' => __( 'Grafico originale di riferimento', 'espressocoppola-child-theme' ),
			'noReference'  => __( 'Nessuna immagine di riferimento.', 'espressocoppola-child-theme' ),
			'progress'     => __( '%1$d / %2$d valori compilati', 'espressocoppola-child-theme' ),
			'open'         => __( 'Apri', 'espressocoppola-child-theme' ),
			'close'        => __( 'Chiudi', 'espressocoppola-child-theme' ),
			'noFile'       => __( 'Nessun file selezionato', 'espressocoppola-child-theme' ),
			'fileSelected' => __( 'Immagine selezionata', 'espressocoppola-child-theme' ),
			'select'       => __( 'Scegli immagine', 'espressocoppola-child-theme' ),
			'replace'      => __( 'Sostituisci immagine', 'espressocoppola-child-theme' ),
		)
	);
}
add_action( 'admin_enqueue_scripts', 'espressocoppola_enqueue_sensory_admin_assets' );
