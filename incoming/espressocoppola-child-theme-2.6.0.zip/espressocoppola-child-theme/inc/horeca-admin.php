<?php
/**
 * Backend Admin UI for Ho.Re.Ca. sample requests.
 *
 * Minimal, clean, modern, white, highly readable.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Remove default submitdiv and meta boxes to keep the screen minimal and focused.
 *
 * @return void
 */
function espressocoppola_horeca_clean_admin_meta_boxes() {
	remove_meta_box( 'submitdiv', 'ec_horeca_request', 'side' );
	remove_meta_box( 'slugdiv', 'ec_horeca_request', 'normal' );

	add_meta_box(
		'espressocoppola_horeca_detail_box',
		__( 'Dettaglio Richiesta Ho.Re.Ca.', 'espressocoppola-child-theme' ),
		'espressocoppola_render_horeca_detail_meta_box',
		'ec_horeca_request',
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'espressocoppola_horeca_clean_admin_meta_boxes' );

/**
 * Enqueue modern admin styles on Ho.Re.Ca. screens.
 *
 * @param string $hook Admin page hook.
 * @return void
 */
function espressocoppola_horeca_admin_assets( $hook ) {
	global $post_type;

	if ( 'ec_horeca_request' !== $post_type ) {
		return;
	}

	wp_enqueue_style(
		'espressocoppola-horeca-admin',
		get_stylesheet_directory_uri() . '/assets/css/horeca-admin.css',
		array(),
		wp_get_theme()->get( 'Version' )
	);
}
add_action( 'admin_enqueue_scripts', 'espressocoppola_horeca_admin_assets' );

/**
 * Define custom columns for the Ho.Re.Ca. requests list table.
 *
 * @param array<string,string> $columns Existing columns.
 * @return array<string,string>
 */
function espressocoppola_horeca_custom_columns( $columns ) {
	$new_columns = array(
		'cb'                 => $columns['cb'],
		'horeca_status'      => __( 'Stato', 'espressocoppola-child-theme' ),
		'title'              => __( 'Azienda / Richiedente', 'espressocoppola-child-theme' ),
		'horeca_referent'    => __( 'Referente', 'espressocoppola-child-theme' ),
		'horeca_consumption' => __( 'Consumo mensile', 'espressocoppola-child-theme' ),
		'horeca_system'      => __( 'Sistema', 'espressocoppola-child-theme' ),
		'horeca_sample'      => __( 'Campione', 'espressocoppola-child-theme' ),
		'date'               => __( 'Data ricezione', 'espressocoppola-child-theme' ),
	);

	return $new_columns;
}
add_filter( 'manage_ec_horeca_request_posts_columns', 'espressocoppola_horeca_custom_columns' );

/**
 * Render custom column content for Ho.Re.Ca. requests.
 *
 * @param string $column  Column name.
 * @param int    $post_id Post ID.
 * @return void
 */
function espressocoppola_horeca_render_custom_columns( $column, $post_id ) {
	$statuses = espressocoppola_get_horeca_statuses();

	switch ( $column ) {
		case 'horeca_status':
			$status_key = get_post_meta( $post_id, '_horeca_status', true );
			if ( ! $status_key || ! isset( $statuses[ $status_key ] ) ) {
				$status_key = 'new';
			}
			$status_info = $statuses[ $status_key ];
			printf(
				'<span class="ec-horeca-badge %s">%s</span>',
				esc_attr( $status_info['badge_class'] ),
				esc_html( $status_info['label'] )
			);
			break;

		case 'horeca_referent':
			$first_name = get_post_meta( $post_id, '_horeca_first_name', true );
			$last_name  = get_post_meta( $post_id, '_horeca_last_name', true );
			$email      = get_post_meta( $post_id, '_horeca_email', true );
			$phone      = get_post_meta( $post_id, '_horeca_phone', true );

			echo '<div class="ec-admin-ref-info">';
			echo '<strong>' . esc_html( trim( $first_name . ' ' . $last_name ) ) . '</strong>';
			if ( $email ) {
				echo '<br><a href="' . esc_url( 'mailto:' . $email ) . '" class="ec-admin-link">' . esc_html( $email ) . '</a>';
			}
			if ( $phone ) {
				echo '<br><a href="' . esc_url( 'tel:' . $phone ) . '" class="ec-admin-link">' . esc_html( $phone ) . '</a>';
			}
			echo '</div>';
			break;

		case 'horeca_consumption':
			$volume = get_post_meta( $post_id, '_horeca_monthly_volume', true );
			echo esc_html( $volume ? $volume : '—' );
			break;

		case 'horeca_system':
			$system = get_post_meta( $post_id, '_horeca_coffee_system', true );
			echo esc_html( $system ? $system : '—' );
			break;

		case 'horeca_sample':
			$sample = get_post_meta( $post_id, '_horeca_sample_blend', true );
			echo '<span class="ec-admin-sample-tag">' . esc_html( $sample ? $sample : '—' ) . '</span>';
			break;
	}
}
add_action( 'manage_ec_horeca_request_posts_custom_column', 'espressocoppola_horeca_render_custom_columns', 10, 2 );

/**
 * Filter requests list table by status using views / quick filters at the top.
 *
 * @param array<string,string> $views Views list.
 * @return array<string,string>
 */
function espressocoppola_horeca_filter_views( $views ) {
	global $typenow, $wpdb;

	if ( 'ec_horeca_request' !== $typenow ) {
		return $views;
	}

	$current_status = isset( $_GET['horeca_status'] ) ? sanitize_key( $_GET['horeca_status'] ) : '';
	$statuses       = espressocoppola_get_horeca_statuses();

	// Calculate total
	$total_count = (int) wp_count_posts( 'ec_horeca_request' )->publish;

	$custom_views = array();
	$all_class    = empty( $current_status ) ? ' class="current"' : '';
	$custom_views['all'] = sprintf(
		'<a href="%s"%s>%s <span class="count">(%d)</span></a>',
		esc_url( admin_url( 'edit.php?post_type=ec_horeca_request' ) ),
		$all_class,
		__( 'Tutte', 'espressocoppola-child-theme' ),
		$total_count
	);

	foreach ( $statuses as $key => $data ) {
		$count = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p
				INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
				WHERE p.post_type = 'ec_horeca_request'
				AND p.post_status = 'publish'
				AND pm.meta_key = '_horeca_status'
				AND pm.meta_value = %s",
				$key
			)
		);

		$is_current = ( $current_status === $key );
		$class      = $is_current ? ' class="current"' : '';
		$url        = add_query_arg(
			array(
				'post_type'     => 'ec_horeca_request',
				'horeca_status' => $key,
			),
			admin_url( 'edit.php' )
		);

		$custom_views[ $key ] = sprintf(
			'<a href="%s"%s>%s <span class="count">(%d)</span></a>',
			esc_url( $url ),
			$class,
			esc_html( $data['label'] ),
			$count
		);
	}

	return $custom_views;
}
add_filter( 'views_edit-ec_horeca_request', 'espressocoppola_horeca_filter_views' );

/**
 * Filter the query when a status filter view is selected.
 *
 * @param WP_Query $query Main query.
 * @return void
 */
function espressocoppola_horeca_filter_query( $query ) {
	global $pagenow, $typenow;

	if ( is_admin() && 'edit.php' === $pagenow && 'ec_horeca_request' === $typenow && $query->is_main_query() ) {
		if ( ! empty( $_GET['horeca_status'] ) ) {
			$status = sanitize_key( $_GET['horeca_status'] );
			$meta_query = array(
				array(
					'key'     => '_horeca_status',
					'value'   => $status,
					'compare' => '=',
				),
			);
			$query->set( 'meta_query', $meta_query );
		}
	}
}
add_action( 'pre_get_posts', 'espressocoppola_horeca_filter_query' );

/**
 * Render the clean, modern detail screen for one Ho.Re.Ca. request.
 *
 * @param WP_Post $post Current post.
 * @return void
 */
function espressocoppola_render_horeca_detail_meta_box( $post ) {
	wp_nonce_field( 'espressocoppola_horeca_admin_save', 'espressocoppola_horeca_admin_nonce' );

	$company        = get_post_meta( $post->ID, '_horeca_company', true );
	$first_name     = get_post_meta( $post->ID, '_horeca_first_name', true );
	$last_name      = get_post_meta( $post->ID, '_horeca_last_name', true );
	$activity_type  = get_post_meta( $post->ID, '_horeca_activity_type', true );
	$activity_other = get_post_meta( $post->ID, '_horeca_activity_other', true );
	$city           = get_post_meta( $post->ID, '_horeca_city', true );
	$postal_code    = get_post_meta( $post->ID, '_horeca_postal_code', true );
	$website        = get_post_meta( $post->ID, '_horeca_website', true );

	$monthly_volume = get_post_meta( $post->ID, '_horeca_monthly_volume', true );
	$coffee_system  = get_post_meta( $post->ID, '_horeca_coffee_system', true );
	$sample_blend   = get_post_meta( $post->ID, '_horeca_sample_blend', true );
	$sample_prod_id = (int) get_post_meta( $post->ID, '_horeca_sample_product_id', true );

	$email          = get_post_meta( $post->ID, '_horeca_email', true );
	$phone          = get_post_meta( $post->ID, '_horeca_phone', true );
	$address        = get_post_meta( $post->ID, '_horeca_shipping_address', true );
	$ship_postal    = get_post_meta( $post->ID, '_horeca_shipping_postal_code', true );
	$ship_city      = get_post_meta( $post->ID, '_horeca_shipping_city', true );
	$ship_country   = get_post_meta( $post->ID, '_horeca_shipping_country', true );
	$notes          = get_post_meta( $post->ID, '_horeca_notes', true );

	$status         = get_post_meta( $post->ID, '_horeca_status', true );
	if ( ! $status ) {
		$status = 'new';
	}
	$internal_notes = get_post_meta( $post->ID, '_horeca_internal_notes', true );
	$statuses       = espressocoppola_get_horeca_statuses();
	?>
	<div class="ec-horeca-detail-wrap">
		<!-- Top Bar Header -->
		<div class="ec-horeca-detail-header">
			<div class="ec-horeca-header-main">
				<h2 class="ec-horeca-company-title"><?php echo esc_html( $company ? $company : $post->post_title ); ?></h2>
				<span class="ec-horeca-badge <?php echo esc_attr( isset( $statuses[ $status ] ) ? $statuses[ $status ]['badge_class'] : 'status-new' ); ?>">
					<?php echo esc_html( isset( $statuses[ $status ] ) ? $statuses[ $status ]['label'] : __( 'Nuova', 'espressocoppola-child-theme' ) ); ?>
				</span>
			</div>
			<div class="ec-horeca-header-meta">
				<span><strong><?php esc_html_e( 'Ricevuta il:', 'espressocoppola-child-theme' ); ?></strong> <?php echo esc_html( get_the_date( 'd/m/Y \a\l\l\e H:i', $post ) ); ?></span>
			</div>
		</div>

		<!-- 3-Block Grid -->
		<div class="ec-horeca-grid">
			<!-- Blocco 1: Attività -->
			<div class="ec-horeca-card">
				<div class="ec-horeca-card__title">
					<span class="dashicons dashicons-building"></span>
					<h3><?php esc_html_e( '01 — Attività', 'espressocoppola-child-theme' ); ?></h3>
				</div>
				<table class="ec-horeca-table">
					<tr>
						<th><?php esc_html_e( 'Ragione Sociale', 'espressocoppola-child-theme' ); ?></th>
						<td><strong><?php echo esc_html( $company ? $company : '—' ); ?></strong></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Referente', 'espressocoppola-child-theme' ); ?></th>
						<td><?php echo esc_html( trim( $first_name . ' ' . $last_name ) ); ?></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Tipologia Attività', 'espressocoppola-child-theme' ); ?></th>
						<td>
							<?php
							echo esc_html( $activity_type );
							if ( 'Altro' === $activity_type && $activity_other ) {
								echo ' (' . esc_html( $activity_other ) . ')';
							}
							?>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Città e CAP', 'espressocoppola-child-theme' ); ?></th>
						<td><?php echo esc_html( trim( $postal_code . ' ' . $city ) ); ?></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Sito Web', 'espressocoppola-child-theme' ); ?></th>
						<td>
							<?php if ( $website ) : ?>
								<a href="<?php echo esc_url( $website ); ?>" target="_blank" rel="noopener" class="ec-admin-link">
									<?php echo esc_html( $website ); ?> <span class="dashicons dashicons-external"></span>
								</a>
							<?php else : ?>
								—
							<?php endif; ?>
						</td>
					</tr>
				</table>
			</div>

			<!-- Blocco 2: Consumo & Campione -->
			<div class="ec-horeca-card">
				<div class="ec-horeca-card__title">
					<span class="dashicons dashicons-coffee"></span>
					<h3><?php esc_html_e( '02 — Consumo & Campione', 'espressocoppola-child-theme' ); ?></h3>
				</div>
				<table class="ec-horeca-table">
					<tr>
						<th><?php esc_html_e( 'Consumo Mensile', 'espressocoppola-child-theme' ); ?></th>
						<td><span class="ec-horeca-tag"><?php echo esc_html( $monthly_volume ? $monthly_volume : '—' ); ?></span></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Sistema Utilizzato', 'espressocoppola-child-theme' ); ?></th>
						<td><strong><?php echo esc_html( $coffee_system ? $coffee_system : '—' ); ?></strong></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Campione Richiesto', 'espressocoppola-child-theme' ); ?></th>
						<td>
							<div class="ec-horeca-sample-display">
								<strong><?php echo esc_html( $sample_blend ? $sample_blend : '—' ); ?></strong>
								<?php if ( $sample_prod_id && get_post_status( $sample_prod_id ) ) : ?>
									<a href="<?php echo esc_url( get_edit_post_link( $sample_prod_id ) ); ?>" target="_blank" class="ec-admin-mini-link">
										<?php esc_html_e( 'Vedi prodotto WC', 'espressocoppola-child-theme' ); ?> ↗
									</a>
								<?php endif; ?>
							</div>
						</td>
					</tr>
				</table>
			</div>

			<!-- Blocco 3: Contatti & Consegna -->
			<div class="ec-horeca-card">
				<div class="ec-horeca-card__title">
					<span class="dashicons dashicons-location"></span>
					<h3><?php esc_html_e( '03 — Contatti & Consegna', 'espressocoppola-child-theme' ); ?></h3>
				</div>
				<table class="ec-horeca-table">
					<tr>
						<th><?php esc_html_e( 'Email', 'espressocoppola-child-theme' ); ?></th>
						<td>
							<?php if ( $email ) : ?>
								<a href="<?php echo esc_url( 'mailto:' . $email ); ?>" class="ec-admin-action-link is-email">
									<span class="dashicons dashicons-email"></span> <?php echo esc_html( $email ); ?>
								</a>
							<?php else : ?>
								—
							<?php endif; ?>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Telefono', 'espressocoppola-child-theme' ); ?></th>
						<td>
							<?php if ( $phone ) : ?>
								<a href="<?php echo esc_url( 'tel:' . $phone ); ?>" class="ec-admin-action-link is-phone">
									<span class="dashicons dashicons-phone"></span> <?php echo esc_html( $phone ); ?>
								</a>
							<?php else : ?>
								—
							<?php endif; ?>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Indirizzo Consegna', 'espressocoppola-child-theme' ); ?></th>
						<td>
							<?php echo esc_html( $address ); ?><br>
							<?php echo esc_html( trim( $ship_postal . ' ' . $ship_city ) ); ?><br>
							<small class="ec-admin-country"><?php echo esc_html( $ship_country ); ?></small>
						</td>
					</tr>
					<?php if ( ! empty( $notes ) ) : ?>
						<tr>
							<th><?php esc_html_e( 'Note Cliente', 'espressocoppola-child-theme' ); ?></th>
							<td><div class="ec-admin-customer-notes"><?php echo nl2br( esc_html( $notes ) ); ?></div></td>
						</tr>
					<?php endif; ?>
				</table>
			</div>
		</div>

		<!-- Operational Actions: Status + Internal Note -->
		<div class="ec-horeca-actions-box">
			<div class="ec-horeca-action-item">
				<label for="horeca_status_field"><strong><?php esc_html_e( 'Stato Richiesta:', 'espressocoppola-child-theme' ); ?></strong></label>
				<select name="horeca_status" id="horeca_status_field" class="ec-horeca-select">
					<?php foreach ( $statuses as $key => $s_data ) : ?>
						<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $status, $key ); ?>>
							<?php echo esc_html( $s_data['label'] ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</div>

			<div class="ec-horeca-action-item is-full">
				<label for="horeca_internal_notes"><strong><?php esc_html_e( 'Nota interna (visibile solo al team):', 'espressocoppola-child-theme' ); ?></strong></label>
				<textarea name="horeca_internal_notes" id="horeca_internal_notes" rows="3" class="ec-horeca-textarea" placeholder="<?php esc_attr_e( 'Inserisci qui eventuali appunti interni, storico contatti o tracking del campione...', 'espressocoppola-child-theme' ); ?>"><?php echo esc_textarea( $internal_notes ); ?></textarea>
			</div>

			<div class="ec-horeca-action-submit">
				<button type="submit" name="save" class="button button-primary button-large">
					<?php esc_html_e( 'Aggiorna Richiesta Ho.Re.Ca.', 'espressocoppola-child-theme' ); ?>
				</button>
				<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=ec_horeca_request' ) ); ?>" class="button button-secondary">
					← <?php esc_html_e( 'Torna alla lista', 'espressocoppola-child-theme' ); ?>
				</a>
			</div>
		</div>
	</div>
	<?php
}

/**
 * Save meta data from detail screen.
 *
 * @param int $post_id Current post ID.
 * @return void
 */
function espressocoppola_save_horeca_admin_meta( $post_id ) {
	if ( ! isset( $_POST['espressocoppola_horeca_admin_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['espressocoppola_horeca_admin_nonce'] ) ), 'espressocoppola_horeca_admin_save' ) ) {
		return;
	}

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	if ( isset( $_POST['horeca_status'] ) ) {
		$valid_statuses = array_keys( espressocoppola_get_horeca_statuses() );
		$status         = sanitize_key( $_POST['horeca_status'] );
		if ( in_array( $status, $valid_statuses, true ) ) {
			update_post_meta( $post_id, '_horeca_status', $status );
		}
	}

	if ( isset( $_POST['horeca_internal_notes'] ) ) {
		update_post_meta( $post_id, '_horeca_internal_notes', sanitize_textarea_field( wp_unslash( $_POST['horeca_internal_notes'] ) ) );
	}
}
add_action( 'save_post_ec_horeca_request', 'espressocoppola_save_horeca_admin_meta' );
