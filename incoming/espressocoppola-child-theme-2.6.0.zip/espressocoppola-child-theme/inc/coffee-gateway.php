<?php
/**
 * Coffee Gateway choice adapters.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Determine whether a gateway term must never become a selectable choice.
 *
 * @param string $slug Term slug.
 * @param string $label Term label.
 * @return bool
 */
function espressocoppola_is_excluded_gateway_term( $slug, $label ) {
	$normalized = sanitize_title( $slug . ' ' . remove_accents( $label ) );

	foreach ( array( 'accessori', 'accessorio', 'tazze', 'tazza', 'kit-monouso', 'monouso' ) as $excluded ) {
		if ( false !== strpos( $normalized, $excluded ) ) {
			return true;
		}
	}

	return false;
}

/**
 * Determine whether a serialized finder product is still selectable.
 *
 * @param array<string,mixed> $product Product payload.
 * @return bool
 */
function espressocoppola_is_gateway_product_available( $product ) {
	$is_published = ! array_key_exists( 'published', $product ) || ! empty( $product['published'] );
	$is_available = array_key_exists( 'available', $product )
		? ! empty( $product['available'] )
		: ( ! array_key_exists( 'inStock', $product ) || ! empty( $product['inStock'] ) );

	return $is_published && $is_available;
}

/**
 * Build ordered Coffee Gateway choices from the Finder catalog.
 *
 * @param array<string,mixed> $catalog Normalized finder catalog.
 * @return array<int,array<string,mixed>>
 */
function espressocoppola_get_coffee_gateway_choices( $catalog ) {
	$choices = array();

	foreach ( (array) ( $catalog['preparations'] ?? array() ) as $preparation ) {
		$preparation_slug = sanitize_title( $preparation['key'] ?? '' );
		$preparation_name = isset( $preparation['name'] ) ? (string) $preparation['name'] : '';
		$systems          = (array) ( $preparation['systems'] ?? array() );

		if ( '' === $preparation_slug || espressocoppola_is_excluded_gateway_term( $preparation_slug, $preparation_name ) ) {
			continue;
		}

		if ( empty( $systems ) ) {
			$choices[ $preparation_slug ] = array(
				'slug'      => $preparation_slug,
				'label'     => $preparation_name,
				'ambient'   => $preparation_name,
				'selection' => array(
					'preparation' => $preparation_slug,
					'system'      => '',
				),
				'count'     => 0,
			);
			continue;
		}

		foreach ( $systems as $system ) {
			$system_slug = sanitize_title( $system['slug'] ?? '' );
			$system_name = isset( $system['name'] ) ? (string) $system['name'] : '';

			if ( '' === $system_slug || isset( $choices[ $system_slug ] ) || espressocoppola_is_excluded_gateway_term( $system_slug, $system_name ) ) {
				continue;
			}

			$choices[ $system_slug ] = array(
				'slug'      => $system_slug,
				'label'     => $system_name,
				'ambient'   => $system_name,
				'selection' => array(
					'preparation' => $preparation_slug,
					'system'      => $system_slug,
				),
				'count'     => 0,
			);
		}
	}

	if ( empty( $choices ) ) {
		return array();
	}

	$matched_products = array_fill_keys( array_keys( $choices ), array() );

	foreach ( (array) ( $catalog['products'] ?? array() ) as $product ) {
		if ( ! espressocoppola_is_gateway_product_available( $product ) ) {
			continue;
		}

		$product_id           = absint( $product['id'] ?? 0 );
		if ( $product_id < 1 ) {
			continue;
		}
		$product_preparations = array_filter(
			array_map(
				'sanitize_title',
				array_map( 'strval', (array) ( $product['preparations'] ?? array() ) )
			)
		);
		$product_systems      = array();

		foreach ( (array) ( $product['systems'] ?? array() ) as $system ) {
			$system_slug = sanitize_title( $system['slug'] ?? '' );

			if ( '' !== $system_slug && ! espressocoppola_is_excluded_gateway_term( $system_slug, (string) ( $system['name'] ?? '' ) ) ) {
				$product_systems[] = $system_slug;
			}
		}

		$product_systems = array_values( array_unique( $product_systems ) );

		foreach ( $choices as $slug => &$choice ) {
			$selection = $choice['selection'];

			if ( ! in_array( $selection['preparation'], $product_preparations, true ) ) {
				continue;
			}

			if ( '' !== $selection['system'] && ! in_array( $selection['system'], $product_systems, true ) ) {
				continue;
			}

			if ( isset( $matched_products[ $slug ][ $product_id ] ) ) {
				continue;
			}

			$matched_products[ $slug ][ $product_id ] = true;
			++$choice['count'];
		}
		unset( $choice );
	}

	return array_values(
		array_filter(
			$choices,
			static function ( $choice ) {
				return ! empty( $choice['count'] );
			}
		)
	);
}

/**
 * Resolve the active gateway choice slug from a request value.
 *
 * @param array<int,array<string,mixed>> $choices Gateway choices.
 * @param string|null                    $requested Requested slug.
 * @return string
 */
function espressocoppola_get_coffee_gateway_active_slug( $choices, $requested ) {
	if ( empty( $choices ) ) {
		return '';
	}

	$requested_slug = null === $requested ? '' : sanitize_title( wp_unslash( $requested ) );
	$valid_slugs    = wp_list_pluck( $choices, 'slug' );

	if ( '' !== $requested_slug && in_array( $requested_slug, $valid_slugs, true ) ) {
		return $requested_slug;
	}

	return (string) $choices[0]['slug'];
}
