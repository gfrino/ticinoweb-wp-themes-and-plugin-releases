<?php
/**
 * Dynamic data adapters for the Espresso Coppola single-product experience.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Use the child-theme product template without copying a WooCommerce template.
 *
 * @param string $template Located template path.
 * @return string
 */
function espressocoppola_single_product_template( $template ) {
	if ( ! function_exists( 'is_product' ) || ! is_product() ) {
		return $template;
	}

	$child_template = get_stylesheet_directory() . '/single-product.php';
	return file_exists( $child_template ) ? $child_template : $template;
}
add_filter( 'template_include', 'espressocoppola_single_product_template', 99 );

/**
 * Add a stable product-page style scope.
 *
 * @param string[] $classes Body classes.
 * @return string[]
 */
function espressocoppola_product_body_class( $classes ) {
	if ( function_exists( 'is_product' ) && is_product() ) {
		$classes[] = 'espresso-coppola-product';
	}

	return $classes;
}
add_filter( 'body_class', 'espressocoppola_product_body_class' );

/**
 * Return display values for one WooCommerce product attribute.
 *
 * @param WC_Product_Attribute $attribute Product attribute.
 * @return string[]
 */
function espressocoppola_get_product_attribute_values( $attribute ) {
	if ( $attribute->is_taxonomy() ) {
		$terms = get_terms(
			array(
				'taxonomy'   => $attribute->get_name(),
				'include'    => $attribute->get_options(),
				'hide_empty' => false,
			)
		);

		return is_wp_error( $terms ) ? array() : array_values( wp_list_pluck( $terms, 'name' ) );
	}

	return array_values( array_filter( array_map( 'sanitize_text_field', $attribute->get_options() ) ) );
}

/**
 * Return enabled payment gateway names without exposing unverified brand copy.
 *
 * @return string[]
 */
function espressocoppola_get_enabled_payment_gateway_names() {
	if ( ! function_exists( 'WC' ) || ! WC()->payment_gateways() ) {
		return array();
	}

	$names = array();
	foreach ( WC()->payment_gateways()->payment_gateways() as $gateway ) {
		if ( isset( $gateway->enabled ) && 'yes' === $gateway->enabled ) {
			$names[] = wp_strip_all_tags( $gateway->get_title() );
		}
	}

	return array_values( array_filter( $names ) );
}

/**
 * Score and return up to three real related products.
 *
 * @param WC_Product $product Current product.
 * @return array<int,array<string,mixed>>
 */
function espressocoppola_get_product_related_cards( $product ) {
	$catalog   = espressocoppola_get_shop_catalog();
	$current   = espressocoppola_serialize_shop_product( $product, espressocoppola_get_blend_taxonomy() );
	$type_keys = wp_list_pluck( $current['types'], 'slug' );
	$blends    = wp_list_pluck( $current['blends'], 'slug' );
	$woo_ids   = function_exists( 'wc_get_related_products' ) ? wc_get_related_products( $product->get_id(), 50 ) : array();
	$ranked    = array();

	foreach ( $catalog as $item ) {
		if ( $item['id'] === $product->get_id() ) {
			continue;
		}
		$candidate = wc_get_product( $item['id'] );
		if ( ! $candidate instanceof WC_Product || ! $candidate->is_visible() || ! $candidate->is_in_stock() ) {
			continue;
		}

		$score  = count( array_intersect( $type_keys, wp_list_pluck( $item['types'], 'slug' ) ) ) * 20;
		$score += count( array_intersect( $blends, wp_list_pluck( $item['blends'], 'slug' ) ) ) * 8;
		$score += in_array( $item['id'], $woo_ids, true ) ? 4 : 0;
		$ranked[] = array( 'score' => $score, 'item' => $item );
	}

	usort(
		$ranked,
		static function ( $left, $right ) {
			return $right['score'] <=> $left['score'] ?: $right['item']['id'] <=> $left['item']['id'];
		}
	);

	return array_slice( wp_list_pluck( $ranked, 'item' ), 0, 3 );
}

/**
 * Build one escaped-ready context for the custom product templates.
 *
 * @param WC_Product|int $product Product object or ID.
 * @return array<string,mixed>
 */
function espressocoppola_get_single_product_context( $product ) {
	if ( is_numeric( $product ) ) {
		$product = wc_get_product( absint( $product ) );
	}
	if ( ! $product instanceof WC_Product ) {
		return array();
	}

	$taxonomy       = espressocoppola_get_blend_taxonomy();
	$profile        = espressocoppola_get_product_sensory_profile( $product );
	$profile_status = espressocoppola_get_sensory_profile_status( $profile );
	$types          = espressocoppola_get_shop_product_types( $product );
	$blends         = espressocoppola_get_shop_product_blends( $product, $taxonomy );
	$reliable_terms = $taxonomy ? wc_get_product_terms( $product->get_id(), $taxonomy, array( 'fields' => 'all' ) ) : array();
	$attributes     = array();

	foreach ( $product->get_attributes() as $attribute ) {
		$values = espressocoppola_get_product_attribute_values( $attribute );
		if ( empty( $values ) ) {
			continue;
		}
		$attributes[] = array(
			'name'      => wc_attribute_label( $attribute->get_name(), $product ),
			'values'    => $values,
			'variation' => $attribute->get_variation(),
			'visible'   => $attribute->get_visible(),
		);
	}

	$image_ids = array_values( array_unique( array_filter( array_merge( array( $product->get_image_id() ), $product->get_gallery_image_ids() ) ) ) );
	$stage_word   = '';
	$display_blend = '';
	if ( ! is_wp_error( $reliable_terms ) && 1 === count( $reliable_terms ) ) {
		$stage_word = preg_replace( '/^miscela\s+/iu', '', $reliable_terms[0]->name );
		$display_blend = $reliable_terms[0]->name;
	}

	$quick_facts = array();
	if ( ! empty( $types ) ) {
		$quick_facts[] = array(
			'label' => __( 'Sistema', 'espressocoppola-child-theme' ),
			'value' => implode( ' · ', wp_list_pluck( $types, 'name' ) ),
		);
	}
	if ( $display_blend ) {
		$quick_facts[] = array(
			'label' => __( 'Miscela', 'espressocoppola-child-theme' ),
			'value' => $display_blend,
		);
	}
	foreach ( $attributes as $attribute ) {
		if ( ! $attribute['visible'] || empty( $attribute['values'] ) ) {
			continue;
		}
		$quick_facts[] = array(
			'label' => $attribute['name'],
			'value' => implode( ' · ', $attribute['values'] ),
		);
	}
	$quick_facts = array_slice( $quick_facts, 0, 4 );

	return array(
		'product'          => $product,
		'types'            => $types,
		'blends'           => $blends,
		'classification'   => implode( ' · ', array_filter( array_merge( wp_list_pluck( $types, 'name' ), array( $display_blend ) ) ) ),
		'display_blend'    => $display_blend,
		'stage_word'       => $stage_word,
		'image_ids'        => $image_ids,
		'attributes'       => $attributes,
		'quick_facts'      => $quick_facts,
		'profile'          => $profile,
		'has_profile'      => $profile['enabled'] && $profile_status['complete'],
		'short_description'=> wp_kses_post( wpautop( $product->get_short_description() ) ),
		'description'      => wp_kses_post( apply_filters( 'the_content', $product->get_description() ) ),
		'gateway_names'    => espressocoppola_get_enabled_payment_gateway_names(),
		'related'          => espressocoppola_get_product_related_cards( $product ),
	);
}

/**
 * Implement Post-Redirect-Get (PRG) pattern on add-to-cart.
 * Prevents browser "Conferma reinvio modulo" / Form Resubmission dialog on page refresh.
 *
 * @param string          $url           Redirect target URL.
 * @param WC_Product|null $adding_to_cart Product being added.
 * @return string
 */
function espressocoppola_prevent_form_resubmission_redirect( $url, $adding_to_cart = null ) {
	if ( ! empty( $url ) ) {
		return $url;
	}

	// If redirect to cart is disabled in WooCommerce settings,
	// redirect back to the product page via GET so page refresh doesn't trigger form resubmission.
	if ( 'yes' !== get_option( 'woocommerce_cart_redirect_after_add' ) ) {
		if ( $adding_to_cart instanceof WC_Product ) {
			return get_permalink( $adding_to_cart->get_id() );
		}

		if ( ! empty( $_POST['add-to-cart'] ) ) {
			return get_permalink( absint( $_POST['add-to-cart'] ) );
		}

		if ( wp_get_referer() ) {
			return wp_get_referer();
		}
	}

	return $url;
}
add_filter( 'woocommerce_add_to_cart_redirect', 'espressocoppola_prevent_form_resubmission_redirect', 10, 2 );

/**
 * AJAX handler for adding a product to cart with mobile-like feedback and fragments update.
 *
 * @return void
 */
function espressocoppola_ajax_add_to_cart() {
	check_ajax_referer( 'espressocoppola_cart_nonce', 'nonce' );

	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		wp_send_json_error( array( 'message' => __( 'WooCommerce non è attivo.', 'espressocoppola-child-theme' ) ) );
	}

	$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
	if ( ! $product_id && isset( $_POST['add-to-cart'] ) ) {
		$product_id = absint( $_POST['add-to-cart'] );
	}

	$quantity     = isset( $_POST['quantity'] ) ? wc_stock_amount( wp_unslash( $_POST['quantity'] ) ) : 1;
	$variation_id = isset( $_POST['variation_id'] ) ? absint( $_POST['variation_id'] ) : 0;
	$variations   = array();

	// Collect any variation attributes
	foreach ( $_POST as $key => $value ) {
		if ( 0 === strpos( $key, 'attribute_' ) ) {
			$variations[ sanitize_text_field( $key ) ] = sanitize_text_field( wp_unslash( $value ) );
		}
	}

	$target_id = $variation_id ? $variation_id : $product_id;
	$product   = wc_get_product( $target_id );

	if ( ! $product ) {
		wp_send_json_error( array( 'message' => __( 'Prodotto non trovato.', 'espressocoppola-child-theme' ) ) );
	}

	$passed_validation = apply_filters( 'woocommerce_add_to_cart_validation', true, $product_id, $quantity, $variation_id, $variations );

	if ( $passed_validation ) {
		$cart_item_key = WC()->cart->add_to_cart( $product_id, $quantity, $variation_id, $variations );

		if ( $cart_item_key ) {
			do_action( 'woocommerce_ajax_added_to_cart', $product_id );

			// Clear notice queue so errors don't linger
			if ( function_exists( 'wc_clear_notices' ) ) {
				wc_clear_notices();
			}

			// Prepare mini-cart fragments
			$fragments = array();
			if ( class_exists( 'WC_AJAX' ) ) {
				ob_start();
				woocommerce_mini_cart();
				$mini_cart = ob_get_clean();

				$fragments = apply_filters(
					'woocommerce_add_to_cart_fragments',
					array(
						'div.widget_shopping_cart_content' => '<div class="widget_shopping_cart_content">' . $mini_cart . '</div>',
					)
				);
			}

			$data = array(
				'error'        => false,
				'product_id'   => $product_id,
				'product_name' => $product->get_name(),
				'cart_count'   => WC()->cart->get_cart_contents_count(),
				'cart_total'   => WC()->cart->get_cart_total(),
				'cart_url'     => function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : '',
				'fragments'    => $fragments,
				'cart_hash'    => WC()->cart->get_cart_hash(),
			);

			wp_send_json_success( $data );
		}
	}

	// If failed, extract any WC notices or fallback
	$notices = function_exists( 'wc_get_notices' ) ? wc_get_notices( 'error' ) : array();
	if ( function_exists( 'wc_clear_notices' ) ) {
		wc_clear_notices();
	}

	$error_message = ! empty( $notices ) && isset( $notices[0]['notice'] )
		? wp_strip_all_tags( $notices[0]['notice'] )
		: __( 'Impossibile aggiungere il prodotto al carrello.', 'espressocoppola-child-theme' );

	wp_send_json_error( array( 'message' => $error_message ) );
}
add_action( 'wp_ajax_espressocoppola_add_to_cart', 'espressocoppola_ajax_add_to_cart' );
add_action( 'wp_ajax_nopriv_espressocoppola_add_to_cart', 'espressocoppola_ajax_add_to_cart' );
