<?php
/**
 * Data adapter for the selectable “Chi siamo” page template.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Whether the current page uses the custom about template.
 *
 * @return bool
 */
function espressocoppola_is_about_page() {
	return is_page_template( 'page-templates/chi-siamo.php' );
}

/**
 * Select a small, varied group of real coffee products.
 *
 * @param array<int,array<string,mixed>> $catalog Serialized WooCommerce catalog.
 * @param int                            $limit Maximum products.
 * @return array<int,array<string,mixed>>
 */
function espressocoppola_get_about_products( $catalog, $limit = 3 ) {
	$selected = array();
	$used     = array();
	$coffee   = array_values( array_filter( $catalog, static fn( $item ) => empty( $item['isAccessory'] ) ) );

	foreach ( $coffee as $item ) {
		$blend = $item['blends'][0]['slug'] ?? 'coffee';
		if ( isset( $used[ $blend ] ) ) {
			continue;
		}
		$selected[]     = $item;
		$used[ $blend ] = true;
		if ( count( $selected ) >= $limit ) {
			return $selected;
		}
	}

	foreach ( $coffee as $item ) {
		if ( count( $selected ) >= $limit ) {
			break;
		}
		if ( ! in_array( $item['id'], wp_list_pluck( $selected, 'id' ), true ) ) {
			$selected[] = $item;
		}
	}

	return $selected;
}

/**
 * Assemble all dynamic CMS and WooCommerce content used by the page.
 *
 * @param int $page_id Current page ID.
 * @return array<string,mixed>
 */
function espressocoppola_get_about_page_context( $page_id ) {
	$catalog = function_exists( 'espressocoppola_get_shop_catalog' ) ? espressocoppola_get_shop_catalog() : array();
	$filters = function_exists( 'espressocoppola_get_shop_filter_options' ) ? espressocoppola_get_shop_filter_options( $catalog ) : array( 'types' => array(), 'blends' => array() );
	$slides  = function_exists( 'espressocoppola_get_home_slides' ) ? espressocoppola_get_home_slides() : array();
	$shop    = function_exists( 'espressocoppola_get_header_shop_url' ) ? espressocoppola_get_header_shop_url() : home_url( '/shop/' );
	$image_id = get_post_thumbnail_id( $page_id );

	if ( ! $image_id && ! empty( $slides[0]['image_id'] ) ) {
		$image_id = (int) $slides[0]['image_id'];
	}
	if ( ! $image_id && ! empty( $catalog[0]['imageId'] ) ) {
		$image_id = (int) $catalog[0]['imageId'];
	}

	// Definizione canonica ed editoriale delle 4 miscele di Espresso Coppola
	$canonical_blends = array(
		'crema' => array(
			'slug'      => 'crema',
			'name'      => __( 'Crema', 'espressocoppola-child-theme' ),
			'character' => __( 'Intenso', 'espressocoppola-child-theme' ),
			'notes'     => __( 'Cremoso · Avvolgente', 'espressocoppola-child-theme' ),
			'sensory'   => array(
				'values' => array( 4, 4, 1, 4, 4, 5, 2 ),
				'color'  => '#c89d54',
			),
		),
		'delicata' => array(
			'slug'      => 'delicata',
			'name'      => __( 'Delicata', 'espressocoppola-child-theme' ),
			'character' => __( 'Equilibrato', 'espressocoppola-child-theme' ),
			'notes'     => __( 'Morbido · Armonioso', 'espressocoppola-child-theme' ),
			'sensory'   => array(
				'values' => array( 4, 4, 2, 4, 3, 3, 4 ),
				'color'  => '#d49b4b',
			),
		),
		'arabica' => array(
			'slug'      => 'arabica',
			'name'      => __( '100% Arabica', 'espressocoppola-child-theme' ),
			'character' => __( 'Aromatico', 'espressocoppola-child-theme' ),
			'notes'     => __( 'Elegante · Puro', 'espressocoppola-child-theme' ),
			'sensory'   => array(
				'values' => array( 5, 5, 3, 4, 3, 3, 4 ),
				'color'  => '#b8860b',
			),
		),
		'decaffeinato' => array(
			'slug'      => 'decaffeinato',
			'name'      => __( 'Decaffeinato', 'espressocoppola-child-theme' ),
			'character' => __( 'Leggero', 'espressocoppola-child-theme' ),
			'notes'     => __( 'Rotondo · Delicato', 'espressocoppola-child-theme' ),
			'sensory'   => array(
				'values' => array( 3, 3, 2, 2, 3, 2, 4 ),
				'color'  => '#3d86b0',
			),
		),
	);

	$blends = array();
	foreach ( $canonical_blends as $slug_key => $def ) {
		$representative = null;
		$product_count  = 0;

		// Associa il prodotto più rappresentativo del catalogo
		foreach ( $catalog as $item ) {
			$item_blends = ! empty( $item['blends'] ) ? wp_list_pluck( $item['blends'], 'slug' ) : array();
			$item_name   = (string) ( $item['name'] ?? '' );
			$matches     = in_array( $slug_key, $item_blends, true )
				|| ( 'arabica' === $slug_key && in_array( '100-arabica', $item_blends, true ) )
				|| ( 'decaffeinato' === $slug_key && ( in_array( 'miscela-deca', $item_blends, true ) || in_array( 'deca', $item_blends, true ) ) )
				|| ( '' !== $item_name && false !== stripos( $item_name, $def['name'] ) )
				|| ( '' !== $item_name && false !== stripos( $item_name, $slug_key ) );

			if ( $matches ) {
				$product_count++;
				if ( null === $representative && ! empty( $item['imageId'] ) ) {
					$representative = $item;
				}
			}
		}

		$image_id = $representative['imageId'] ?? 0;
		if ( ! $image_id && ! empty( $catalog[0]['imageId'] ) ) {
			$image_id = (int) $catalog[0]['imageId'];
		}

		$sensory = ( ! empty( $representative['sensory'] ) && ! empty( $representative['sensory']['values'] ) )
			? $representative['sensory']
			: $def['sensory'];

		$blends[] = array(
			'slug'      => $def['slug'],
			'name'      => $def['name'],
			'character' => $def['character'],
			'notes'     => $def['notes'],
			'copy'      => $def['character'] . ' · ' . $def['notes'],
			'count'     => $product_count,
			'imageId'   => $image_id,
			'sensory'   => $sensory,
			'url'       => add_query_arg( 'blend', $def['slug'], $shop ),
		);
	}

	$formats = array();
	foreach ( $filters['types'] as $type ) {
		if ( 'accessori' === $type['slug'] ) {
			continue;
		}
		$formats[] = $type + array( 'url' => add_query_arg( 'type', $type['slug'], $shop ) );
	}

	$content = trim( wp_strip_all_tags( get_post_field( 'post_content', $page_id ) ) );
	$excerpt = trim( get_the_excerpt( $page_id ) );

	// Dati dinamici da CMS (admin.php?page=ticinoweb-cms#chi-siamo)
	$cms_title = trim( (string) get_option( 'ticinoweb_chi_siamo_title' ) );
	$cms_text  = trim( (string) get_option( 'ticinoweb_chi_siamo_text' ) );
	$cms_image = trim( (string) get_option( 'ticinoweb_chi_siamo_image' ) );

	$manifesto_title = $cms_title ?: __( 'Una pausa breve. Un carattere che resta.', 'espressocoppola-child-theme' );
	$manifesto_text  = $cms_text ?: ( $content ?: __( 'Espresso Coppola nasce per portare nella tazza un gusto riconoscibile, curato e sincero. Selezioniamo ogni miscela pensando al suo equilibrio, alla crema e al modo in cui accompagna la giornata.', 'espressocoppola-child-theme' ) );

	return array(
		'title'          => get_the_title( $page_id ) ?: __( 'Chi siamo', 'espressocoppola-child-theme' ),
		'intro'          => $excerpt ?: __( 'Il caffè è un gesto quotidiano. Noi lo interpretiamo con cura, carattere e un’anima profondamente napoletana.', 'espressocoppola-child-theme' ),
		'content'        => $content,
		'manifestoTitle' => $manifesto_title,
		'manifestoText'  => $manifesto_text,
		'manifestoImage' => $cms_image,
		'heroImageId'    => $image_id,
		'blends'         => $blends,
		'formats'        => $formats,
		'products'       => espressocoppola_get_about_products( $catalog ),
		'shopUrl'        => $shop,
		'finderUrl'      => home_url( '/#coffee-gateway' ),
	);
}
