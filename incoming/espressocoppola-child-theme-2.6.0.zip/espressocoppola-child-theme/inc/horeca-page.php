<?php
/**
 * Data aggregation and context helpers for the Ho.Re.Ca. template.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Determine if current request is the Ho.Re.Ca. page template.
 *
 * @param int|WP_Post|null $post Optional post.
 * @return bool
 */
function espressocoppola_is_horeca_page( $post = null ) {
	if ( ! is_page() ) {
		return false;
	}

	$post_id = $post ? ( is_object( $post ) ? $post->ID : (int) $post ) : get_the_ID();
	if ( ! $post_id ) {
		return false;
	}

	$template = get_page_template_slug( $post_id );
	if ( 'page-templates/horeca.php' === $template || 'horeca.php' === $template ) {
		return true;
	}

	return is_page( 'horeca' ) || is_page( 'ho-re-ca' );
}

/**
 * Automatically route to page-templates/horeca.php when viewing the Ho.Re.Ca. page.
 *
 * @param string $template Current template.
 * @return string
 */
function espressocoppola_horeca_template_include( $template ) {
	if ( espressocoppola_is_horeca_page() ) {
		$custom_template = get_stylesheet_directory() . '/page-templates/horeca.php';
		if ( file_exists( $custom_template ) ) {
			return $custom_template;
		}
	}

	return $template;
}
add_filter( 'template_include', 'espressocoppola_horeca_template_include', 99 );

/**
 * Add body class for the Ho.Re.Ca. template to enable immersive floating header.
 *
 * @param string[] $classes Body classes.
 * @return string[]
 */
function espressocoppola_horeca_body_class( $classes ) {
	if ( espressocoppola_is_horeca_page() ) {
		$classes[] = 'espresso-coppola-horeca';
		$classes[] = 'page-template-horeca';
	}

	return $classes;
}
add_filter( 'body_class', 'espressocoppola_horeca_body_class' );

/**
 * Build rich context for the Ho.Re.Ca. page template.
 *
 * @param int $page_id Current page ID.
 * @return array<string,mixed>
 */
function espressocoppola_get_horeca_page_context( $page_id ) {
	$shop_url    = espressocoppola_get_header_shop_url();
	$privacy_url = get_privacy_policy_url();
	if ( empty( $privacy_url ) ) {
		$privacy_page = get_page_by_path( 'privacy-policy' );
		$privacy_url  = $privacy_page ? get_permalink( $privacy_page->ID ) : home_url( '/privacy-policy/' );
	}

	// CMS Contact Info
	$contact = array(
		'email'   => 'office.newbusinessitaly@gmail.com',
		'phone'   => '+39 366 317 7428',
		'address' => 'Via Filippo Corridoni, 72 - 20071 Vermezzo con Zelo, Milano',
	);

	if ( function_exists( 'ticinoweb_get_contact_info' ) ) {
		$cms = ticinoweb_get_contact_info();
		if ( ! empty( $cms['email'] ) ) {
			$contact['email'] = $cms['email'];
		}
		if ( ! empty( $cms['phone'] ) ) {
			$contact['phone'] = $cms['phone'];
		} elseif ( ! empty( $cms['phone_mobile'] ) ) {
			$contact['phone'] = $cms['phone_mobile'];
		}
		if ( ! empty( $cms['address'] ) ) {
			$contact['address'] = $cms['address'];
		}
	}

	// Dynamic Coffee Products & Blends from WooCommerce
	$catalog         = function_exists( 'espressocoppola_get_shop_catalog' ) ? espressocoppola_get_shop_catalog() : array();
	$coffee_products = array();

	// Extract all distinct blends from catalog
	$sample_blends = array();
	$seen_blends   = array();

	foreach ( $catalog as $item ) {
		// Filter out accessories/mugs
		$is_coffee = true;
		if ( isset( $item['types'] ) && is_array( $item['types'] ) ) {
			foreach ( $item['types'] as $type ) {
				if ( 'accessori' === $type['slug'] ) {
					$is_coffee = false;
					break;
				}
			}
		}

		if ( ! $is_coffee ) {
			continue;
		}

		$coffee_products[] = $item;

		if ( ! empty( $item['blends'] ) && is_array( $item['blends'] ) ) {
			foreach ( $item['blends'] as $blend ) {
				$slug_raw = sanitize_title( $blend['slug'] );
				$slug_key = $slug_raw;
				$blend_name = $blend['name'];

				// Canonicalize into the 4 true blends of Espresso Coppola catalog
				if ( false !== strpos( $slug_raw, 'deca' ) || false !== strpos( $slug_raw, 'decaffeinato' ) ) {
					$slug_key   = 'decaffeinato';
					$blend_name = __( 'Decaffeinato', 'espressocoppola-child-theme' );
					$kicker     = __( 'Espresso Senza Caffeina', 'espressocoppola-child-theme' );
					$intensity  = 4;
				} elseif ( false !== strpos( $slug_raw, 'arabica' ) ) {
					$slug_key   = 'arabica';
					$blend_name = __( '100% Arabica', 'espressocoppola-child-theme' );
					$kicker     = __( 'Selezione Pregiata', 'espressocoppola-child-theme' );
					$intensity  = 5;
				} elseif ( false !== strpos( $slug_raw, 'delicat' ) ) {
					$slug_key   = 'delicata';
					$blend_name = __( 'Delicata', 'espressocoppola-child-theme' );
					$kicker     = __( 'Miscela Espresso Equilibrata', 'espressocoppola-child-theme' );
					$intensity  = 4;
				} elseif ( false !== strpos( $slug_raw, 'crema' ) ) {
					$slug_key   = 'crema';
					$blend_name = __( 'Crema', 'espressocoppola-child-theme' );
					$kicker     = __( 'Miscela Espresso Intensa', 'espressocoppola-child-theme' );
					$intensity  = 5;
				} else {
					$kicker    = __( 'Miscela Espresso', 'espressocoppola-child-theme' );
					$intensity = isset( $item['sensory']['values']['aromatic_intensity'] ) ? (int) $item['sensory']['values']['aromatic_intensity'] : 4;
				}

				if ( ! isset( $seen_blends[ $slug_key ] ) ) {
					$seen_blends[ $slug_key ] = true;

					$desc = isset( $item['summary'] ) && ! empty( $item['summary'] )
						? $item['summary']
						: sprintf( __( 'Miscela %s torrefatta secondo la migliore tradizione napoletana.', 'espressocoppola-child-theme' ), $blend_name );

					$sample_blends[] = array(
						'slug'        => $slug_key,
						'name'        => $blend_name,
						'kicker'      => $kicker,
						'productId'   => $item['id'],
						'image'       => $item['image'],
						'sensory'     => isset( $item['sensory']['values'] ) ? $item['sensory']['values'] : array(
							'body'        => 4,
							'persistence' => 4,
							'roast'       => 4,
							'sweetness'   => 3,
						),
						'intensity'   => $intensity,
						'description' => $desc,
					);
				}
			}
		}
	}

	// Fallback if catalog is empty (the 4 canonical blends of Espresso Coppola)
	if ( empty( $sample_blends ) ) {
		$sample_blends = array(
			array( 'slug' => 'crema', 'name' => 'Crema', 'kicker' => 'Miscela Espresso Intensa', 'productId' => 0, 'image' => '', 'sensory' => array( 'body' => 5, 'persistence' => 5, 'roast' => 5, 'sweetness' => 3 ), 'intensity' => 5, 'description' => 'Tostatura decisa napoletana, corpo denso e crema nocciola persistente.' ),
			array( 'slug' => 'delicata', 'name' => 'Delicata', 'kicker' => 'Miscela Espresso Equilibrata', 'productId' => 0, 'image' => '', 'sensory' => array( 'body' => 3, 'persistence' => 4, 'roast' => 3, 'sweetness' => 4 ), 'intensity' => 4, 'description' => 'Armoniosa e vellutata, con note tostate morbide e retrogusto cioccolatato.' ),
			array( 'slug' => 'arabica', 'name' => '100% Arabica', 'kicker' => 'Selezione Pregiata', 'productId' => 0, 'image' => '', 'sensory' => array( 'body' => 3, 'persistence' => 4, 'roast' => 3, 'sweetness' => 5 ), 'intensity' => 5, 'description' => 'Elegante e floreale, con fine acidità agrumata e dolcezza naturale.' ),
			array( 'slug' => 'decaffeinato', 'name' => 'Decaffeinato', 'kicker' => 'Espresso Senza Caffeina', 'productId' => 0, 'image' => '', 'sensory' => array( 'body' => 4, 'persistence' => 4, 'roast' => 4, 'sweetness' => 3 ), 'intensity' => 4, 'description' => 'Tutto il gusto e la densità dell\'autentico espresso napoletano, senza caffeina.' ),
		);
	}

	// Ho.Re.Ca. Audiences / Sectors
	$audiences = array(
		array(
			'num'      => '01',
			'title'    => __( 'Bar & Caffetterie', 'espressocoppola-child-theme' ),
			'subtitle' => __( 'Il rito dell\'espresso perfetto al banco', 'espressocoppola-child-theme' ),
			'desc'     => __( 'Estrazione uniforme, crema densa color tonaca di monaco e una resa in tazza che fidelizza la clientela fin dal primo assaggio del mattino.', 'espressocoppola-child-theme' ),
			'tag'      => __( 'Alta rotazione', 'espressocoppola-child-theme' ),
		),
		array(
			'num'      => '02',
			'title'    => __( 'Ristoranti & Trattorie', 'espressocoppola-child-theme' ),
			'subtitle' => __( 'Il gran finale della tua esperienza a tavola', 'espressocoppola-child-theme' ),
			'desc'     => __( 'L\'ultimo ricordo lasciato all\'ospite dopo il servizio: un espresso corposo, aromatico e indimenticabile che nobilita l\'intero menù.', 'espressocoppola-child-theme' ),
			'tag'      => __( 'Esperienza gastronomica', 'espressocoppola-child-theme' ),
		),
		array(
			'num'      => '03',
			'title'    => __( 'Hotel, Resort & B&B', 'espressocoppola-child-theme' ),
			'subtitle' => __( 'Accoglienza di livello dalla colazione al lounge', 'espressocoppola-child-theme' ),
			'desc'     => __( 'Dalla sala colazioni alle suite: soluzioni versatili in grani, cialde o capsule compatibili per garantire standard costanti ad ospiti internazionali.', 'espressocoppola-child-theme' ),
			'tag'      => __( 'Hospitality premium', 'espressocoppola-child-theme' ),
		),
		array(
			'num'      => '04',
			'title'    => __( 'Catering & Grandi Eventi', 'espressocoppola-child-theme' ),
			'subtitle' => __( 'Continuità ed eleganza per ricevimenti', 'espressocoppola-child-theme' ),
			'desc'     => __( 'Gestione agile e pulita per grandi numeri, matrimoni e banchetti aziendali, con praticità di erogazione e qualità impeccabile.', 'espressocoppola-child-theme' ),
			'tag'      => __( 'Banchetti & Fiere', 'espressocoppola-child-theme' ),
		),
		array(
			'num'      => '05',
			'title'    => __( 'Uffici & Spazi Professionali', 'espressocoppola-child-theme' ),
			'subtitle' => __( 'La pausa caffè che valorizza il tuo ambiente di lavoro', 'espressocoppola-child-theme' ),
			'desc'     => __( 'Trasforma la pausa aziendale e l\'accoglienza clienti in uno spazio di piacere raffinato ed energizzante con formati comodi e performanti.', 'espressocoppola-child-theme' ),
			'tag'      => __( 'Corporate & Studio', 'espressocoppola-child-theme' ),
		),
	);

	// Formati / Sistemi disponibili
	$systems = array(
		array(
			'key'      => 'grani',
			'title'    => __( 'Caffè in grani', 'espressocoppola-child-theme' ),
			'desc'     => __( 'Chicchi selezionati e tostati con cura artigianale, ideali per macinadosatori e macchine da bar tradizionali o superautomatiche.', 'espressocoppola-child-theme' ),
			'badge'    => __( 'Professionale', 'espressocoppola-child-theme' ),
		),
		array(
			'key'      => 'cialde',
			'title'    => __( 'Cialde in carta ESE 44', 'espressocoppola-child-theme' ),
			'desc'     => __( 'Dose perfetta di 7,2g di caffè pressato in filtro carta naturale e compostabile. Massima costanza ed ecocompatibilità.', 'espressocoppola-child-theme' ),
			'badge'    => __( 'Ecologico', 'espressocoppola-child-theme' ),
		),
		array(
			'key'      => 'nespresso',
			'title'    => __( 'Capsule compatibili Nespresso®*', 'espressocoppola-child-theme' ),
			'desc'     => __( 'Capsule studiate per erogare un vero espresso napoletano cremoso sulle macchine compatibili del sistema Nespresso®*.', 'espressocoppola-child-theme' ),
			'badge'    => __( 'Compatibile', 'espressocoppola-child-theme' ),
		),
		array(
			'key'      => 'dolce-gusto',
			'title'    => __( 'Capsule compatibili Dolce Gusto®*', 'espressocoppola-child-theme' ),
			'desc'     => __( 'Formato ad alta erogazione per estrazioni lunghe o intense, compatibile con il sistema Nescafé Dolce Gusto®*.', 'espressocoppola-child-theme' ),
			'badge'    => __( 'Compatibile', 'espressocoppola-child-theme' ),
		),
		array(
			'key'      => 'a-modo-mio',
			'title'    => __( 'Capsule compatibili A Modo Mio®*', 'espressocoppola-child-theme' ),
			'desc'     => __( 'Erogazione densa e corposa secondo il profilo napoletano, compatibile con il sistema Lavazza A Modo Mio®*.', 'espressocoppola-child-theme' ),
			'badge'    => __( 'Compatibile', 'espressocoppola-child-theme' ),
		),
		array(
			'key'      => 'macinato',
			'title'    => __( 'Caffè macinato Moka & Filtro', 'espressocoppola-child-theme' ),
			'desc'     => __( 'Macinatura calibrata per esaltare l\'estrazione casalinga e l\'hospitality intima di B&B e appartamenti vacanza.', 'espressocoppola-child-theme' ),
			'badge'    => __( 'Classico', 'espressocoppola-child-theme' ),
		),
	);

	// 4 Pillars / Perché Espresso Coppola
	$pillars = array(
		array(
			'num'   => '01',
			'title' => __( 'Torrefazione Napoletana Autentica', 'espressocoppola-child-theme' ),
			'desc'  => __( 'Cura scrupolosa delle curve di tostatura a caldo uniforme, per garantire la tipica densità e la crema color nocciola che contraddistingue il vero espresso napoletano.', 'espressocoppola-child-theme' ),
		),
		array(
			'num'   => '02',
			'title' => __( 'Ampia Gamma di Sistemi & Formati', 'espressocoppola-child-theme' ),
			'desc'  => __( 'Dal chicco fresco in grani alle cialde carta filtro e alle capsule compatibili: una soluzione su misura per ogni postazione operativa del tuo locale o struttura.', 'espressocoppola-child-theme' ),
		),
		array(
			'num'   => '03',
			'title' => __( 'Identità Sensoriale Definita e Costante', 'espressocoppola-child-theme' ),
			'desc'  => __( 'Miscele stabili e calibrate per offrire un profilo aromatico costante in ogni tazza servita, valorizzando il lavoro del tuo personale e la soddisfazione del cliente.', 'espressocoppola-child-theme' ),
		),
		array(
			'num'   => '04',
			'title' => __( 'Rapporto Diretto e Assistenza Commerciale', 'espressocoppola-child-theme' ),
			'desc'  => __( 'Nessun intermediario: parli direttamente con chi produce e seleziona il caffè, con consegne rapide, supporto continuativo e campionature di prova dedicate.', 'espressocoppola-child-theme' ),
		),
	);

	return array(
		'pageId'         => $page_id,
		'shopUrl'        => $shop_url,
		'privacyUrl'     => $privacy_url,
		'contact'        => $contact,
		'audiences'      => $audiences,
		'sampleBlends'   => $sample_blends,
		'coffeeProducts' => array_slice( $coffee_products, 0, 4 ),
		'systems'        => $systems,
		'pillars'        => $pillars,
		'nonce'          => wp_create_nonce( 'espressocoppola_horeca_nonce' ),
	);
}
