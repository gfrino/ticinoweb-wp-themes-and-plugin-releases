<?php
/**
 * Header data adapters for navigation, branding and WooCommerce.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Resolve the menu reference used by the floating header.
 *
 * @param array $locations Registered menu locations.
 * @param int   $fallback_id Fallback menu ID.
 * @return array
 */
function espressocoppola_resolve_header_menu_reference( $locations, $fallback_id ) {
	if ( ! empty( $locations['primary'] ) ) {
		return array( 'theme_location' => 'primary' );
	}

	return $fallback_id > 0 ? array( 'menu' => $fallback_id ) : array( 'theme_location' => 'primary' );
}

/**
 * Return the arguments for the WordPress-managed header menu.
 *
 * @return array
 */
function espressocoppola_get_header_menu_args() {
	$fallback_id = absint( apply_filters( 'espressocoppola_header_menu_id', 53 ) );
	$reference   = espressocoppola_resolve_header_menu_reference( get_nav_menu_locations(), $fallback_id );

	return $reference + array(
		'menu_class'  => 'ec-morph-menu',
		'menu_id'     => 'ec-morph-menu',
		'container'   => false,
		'fallback_cb' => false,
		'depth'       => 3,
		'echo'        => true,
		'items_wrap'  => '<ul id="%1$s" class="%2$s" data-header-menu-list>%3$s</ul>',
	);
}

/**
 * Resolve the header logo, preferring the configured parent logo.
 *
 * @return string
 */
function espressocoppola_get_header_logo_url() {
	if ( function_exists( 'ticinoweb_get_site_logo' ) ) {
		$site_logo = ticinoweb_get_site_logo();

		// Se nel CMS è stato impostato un logo dedicato (es. SVG o PNG) diverso dal vecchio JPEG grezzo
		if ( ! empty( $site_logo ) && false === strpos( $site_logo, 'logoespresso' ) ) {
			return esc_url_raw( $site_logo );
		}
	}

	if ( function_exists( 'espressocoppola_get_logo_url' ) ) {
		$logo_url = espressocoppola_get_logo_url();

		if ( ! empty( $logo_url ) ) {
			return esc_url_raw( $logo_url );
		}
	}

	if ( function_exists( 'ticinoweb_get_site_logo' ) ) {
		$site_logo = ticinoweb_get_site_logo();

		if ( ! empty( $site_logo ) ) {
			return esc_url_raw( $site_logo );
		}
	}

	return '';
}

/**
 * Resolve the shop URL through WooCommerce or the parent compatibility helper.
 *
 * @return string
 */
function espressocoppola_get_header_shop_url() {
	if ( function_exists( 'wc_get_page_permalink' ) ) {
		$shop_url = wc_get_page_permalink( 'shop' );

		if ( ! empty( $shop_url ) ) {
			return esc_url_raw( $shop_url );
		}
	}

	if ( function_exists( 'ticinoweb_get_shop_url' ) ) {
		$shop_url = ticinoweb_get_shop_url();

		if ( ! empty( $shop_url ) ) {
			return esc_url_raw( $shop_url );
		}
	}

	return '';
}

/**
 * Resolve the cart URL through WooCommerce.
 *
 * @return string
 */
function espressocoppola_get_header_cart_url() {
	if ( function_exists( 'wc_get_cart_url' ) ) {
		$cart_url = wc_get_cart_url();

		if ( ! empty( $cart_url ) ) {
			return esc_url_raw( $cart_url );
		}
	}

	return '';
}

/**
 * Resolve the account URL through WooCommerce.
 *
 * @return string
 */
function espressocoppola_get_header_account_url() {
	if ( function_exists( 'wc_get_page_permalink' ) ) {
		$account_url = wc_get_page_permalink( 'myaccount' );

		if ( ! empty( $account_url ) ) {
			return esc_url_raw( $account_url );
		}
	}

	return esc_url_raw( home_url( '/mio-account/' ) );
}

/**
 * Render the header account link markup.
 *
 * @return string
 */
function espressocoppola_get_header_account_markup() {
	$account_url = espressocoppola_get_header_account_url();

	$icon_svg = '<svg class="ec-header__account-icon" width="16" height="17" viewBox="0 0 20 22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 19.5v-1.5a4.5 4.5 0 0 0-4.5-4.5h-3A4.5 4.5 0 0 0 4 18v1.5"/><circle cx="10" cy="6.5" r="3.5"/></svg>';

	return sprintf(
		'<a class="ec-header__account" href="%1$s" aria-label="%2$s">%3$s</a>',
		esc_url( $account_url ),
		esc_attr__( 'Il mio account', 'espressocoppola-child-theme' ),
		$icon_svg
	);
}

/**
 * Return the current WooCommerce cart quantity.
 *
 * @return int
 */
function espressocoppola_get_header_cart_count() {
	return function_exists( 'WC' ) && WC()->cart ? max( 0, (int) WC()->cart->get_cart_contents_count() ) : 0;
}

/**
 * Render the complete header bag link used by initial output and fragments.
 *
 * @return string
 */
function espressocoppola_get_header_bag_markup() {
	$count = espressocoppola_get_header_cart_count();

	$icon_svg = '<svg class="ec-header__bag-icon" width="16" height="17" viewBox="0 0 20 22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3.5 6.5H16.5L18 20.5H2L3.5 6.5Z"/><path d="M6.5 9V4.5C6.5 2.567 8.067 1 10 1C11.933 1 13.5 2.567 13.5 4.5V9"/></svg>';

	$zero_class = 0 === $count ? ' is-zero' : '';

	return sprintf(
		'<a class="ec-header__bag" href="%1$s" aria-label="%2$s">%3$s<span class="ec-header__bag-count%4$s" aria-live="polite" aria-atomic="true"><span data-header-bag-count>%5$d</span></span></a>',
		esc_url( espressocoppola_get_header_cart_url() ),
		esc_attr__( 'Carrello', 'espressocoppola-child-theme' ),
		$icon_svg,
		$zero_class,
		$count
	);
}

/**
 * Replace the WooCommerce bag link after cart fragments update.
 *
 * @param array $fragments Existing WooCommerce fragments.
 * @return array
 */
function espressocoppola_header_cart_fragments( $fragments ) {
	$fragments['a.ec-header__bag'] = espressocoppola_get_header_bag_markup();

	return $fragments;
}
add_filter( 'woocommerce_add_to_cart_fragments', 'espressocoppola_header_cart_fragments' );

/**
 * Return an optional future header link supplied by the child theme.
 *
 * @return array
 */
function espressocoppola_get_header_extra_link() {
	$link = apply_filters( 'espressocoppola_header_extra_link', array() );

	if ( ! is_array( $link ) ) {
		return array();
	}

	$label  = isset( $link['label'] ) ? sanitize_text_field( $link['label'] ) : '';
	$url    = isset( $link['url'] ) ? esc_url_raw( $link['url'] ) : '';
	$target = isset( $link['target'] ) && '_blank' === $link['target'] ? '_blank' : '';

	if ( '' === $label || '' === $url ) {
		return array();
	}

	return array(
		'label'  => $label,
		'url'    => $url,
		'target' => $target,
	);
}
