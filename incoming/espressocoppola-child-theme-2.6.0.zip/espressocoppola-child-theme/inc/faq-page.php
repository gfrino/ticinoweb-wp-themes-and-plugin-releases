<?php
/**
 * Data adapter and presentation context for the FAQ / Answer Atlas page template.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return whether the current request is the custom FAQ / Answer Atlas page template.
 *
 * @param int|WP_Post|null $post Optional post.
 * @return bool
 */
function espressocoppola_is_faq_page( $post = null ) {
	if ( ! is_page() ) {
		return false;
	}

	$post_id = $post ? ( is_object( $post ) ? $post->ID : (int) $post ) : get_the_ID();
	if ( ! $post_id ) {
		return false;
	}

	$template = get_page_template_slug( $post_id );
	if ( 'page-templates/faq.php' === $template || 'faq.php' === $template ) {
		return true;
	}

	return is_page( 'faq' ) || is_page( 'domande-frequenti' ) || is_page( 'answer-atlas' );
}

/**
 * Automatically route to page-templates/faq.php when viewing the FAQ page.
 *
 * @param string $template Current template.
 * @return string
 */
function espressocoppola_faq_template_include( $template ) {
	if ( espressocoppola_is_faq_page() ) {
		$custom_template = get_stylesheet_directory() . '/page-templates/faq.php';
		if ( file_exists( $custom_template ) ) {
			return $custom_template;
		}
	}

	return $template;
}
add_filter( 'template_include', 'espressocoppola_faq_template_include', 99 );

/**
 * Add body classes for the FAQ page template to enable immersive floating header.
 *
 * @param string[] $classes Body classes.
 * @return string[]
 */
function espressocoppola_faq_body_class( $classes ) {
	if ( espressocoppola_is_faq_page() ) {
		$classes[] = 'espresso-coppola-faq';
		$classes[] = 'page-template-faq';
	}

	return $classes;
}
add_filter( 'body_class', 'espressocoppola_faq_body_class' );

/**
 * FAQ dal vecchio CPT `ec_faq` (usato finche' il parent non ha il sistema FAQ).
 *
 * @return array<int,array<string,mixed>>
 */
function espressocoppola_faq_items_legacy() {
	// Query all active ec_faq posts
	$query = new WP_Query(
		array(
			'post_type'      => 'ec_faq',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'meta_query'     => array(
				'relation' => 'OR',
				array(
					'key'     => '_ec_faq_active',
					'value'   => '1',
					'compare' => '=',
				),
				array(
					'key'     => '_ec_faq_active',
					'compare' => 'NOT EXISTS',
				),
			),
			'orderby'        => array(
				'menu_order' => 'ASC',
				'ID'         => 'ASC',
			),
		)
	);

	$raw_faqs = array();
	$order_map = array();

	if ( $query->have_posts() ) {
		while ( $query->have_posts() ) {
			$query->the_post();
			$pid = get_the_ID();

			// Read custom order
			$order_val = get_post_meta( $pid, '_ec_faq_order', true );
			$order     = '' !== $order_val ? (int) $order_val : (int) get_post_field( 'menu_order', $pid );

			// Category
			$terms = get_the_terms( $pid, 'ec_faq_category' );
			$cat_name = __( 'Espresso Coppola', 'espressocoppola-child-theme' );
			$cat_slug = 'espresso-coppola';
			if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
				$cat_name = $terms[0]->name;
				$cat_slug = $terms[0]->slug;
			}

			// Featured
			$featured_meta = get_post_meta( $pid, '_ec_faq_featured', true );
			$is_featured   = ( '1' === (string) $featured_meta );

			// Conversational query
			$conv_query = get_post_meta( $pid, '_ec_faq_conversational_query', true );
			if ( empty( $conv_query ) ) {
				$conv_query = get_the_title( $pid );
			}

			// Related link
			$related_url = get_post_meta( $pid, '_ec_faq_related_url', true );
			$related_lbl = get_post_meta( $pid, '_ec_faq_related_label', true );
			if ( empty( $related_lbl ) && ! empty( $related_url ) ) {
				$related_lbl = __( 'Approfondisci →', 'espressocoppola-child-theme' );
			}

			$title = get_the_title( $pid );
			$slug  = sanitize_title( $title );
			if ( empty( $slug ) ) {
				$slug = 'faq-' . $pid;
			}

			$raw_content = get_the_content( null, false, $pid );
			$content     = wpautop( wp_kses_post( $raw_content ) );
			$plain_text  = trim( wp_strip_all_tags( $raw_content ) );
			$excerpt     = wp_trim_words( $plain_text, 22, '…' );

			$raw_faqs[] = array(
				'id'                   => $pid,
				'title'                => $title,
				'slug'                 => $slug,
				'anchor'               => 'faq-' . $slug,
				'content'              => $content,
				'plain_text'           => $plain_text,
				'excerpt'              => $excerpt,
				'category_name'        => $cat_name,
				'category_slug'        => $cat_slug,
				'order'                => $order,
				'is_featured'          => $is_featured,
				'conversational_query' => $conv_query,
				'related_url'          => $related_url,
				'related_label'        => $related_lbl,
			);
		}
		wp_reset_postdata();
	}

	return $raw_faqs;
}

/**
 * Build the complete, safe presentation context for the FAQ / Answer Atlas template.
 *
 * @param int $page_id Current page ID.
 * @return array<string,mixed>
 */
function espressocoppola_get_faq_page_context( $page_id = 0 ) {
	$shop_url     = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' );
	$dna_page     = get_pages( array( 'meta_key' => '_wp_page_template', 'meta_value' => 'page-templates/dna-delle-miscele.php', 'number' => 1 ) );
	$dna_url      = ! empty( $dna_page ) ? get_permalink( $dna_page[0]->ID ) : home_url( '/dna-delle-miscele/' );
	$horeca_page  = get_pages( array( 'meta_key' => '_wp_page_template', 'meta_value' => 'page-templates/horeca.php', 'number' => 1 ) );
	$horeca_url   = ! empty( $horeca_page ) ? get_permalink( $horeca_page[0]->ID ) : home_url( '/horeca/' );
	$contact_page = get_pages( array( 'meta_key' => '_wp_page_template', 'meta_value' => 'page-templates/contatti.php', 'number' => 1 ) );
	$contact_url  = ! empty( $contact_page ) ? get_permalink( $contact_page[0]->ID ) : home_url( '/contatti/' );

	$raw_faqs = espressocoppola_faq_on_parent() ? espressocoppola_faq_items_from_parent() : espressocoppola_faq_items_legacy();

	// Sort FAQs by order field
	usort(
		$raw_faqs,
		static function( $a, $b ) {
			if ( $a['order'] === $b['order'] ) {
				return $a['id'] <=> $b['id'];
			}
			return $a['order'] <=> $b['order'];
		}
	);

	// Group by category and build Category Groups with sequential global indexing
	$categories_map = array();
	$global_idx     = 1;

	foreach ( $raw_faqs as &$faq_item ) {
		$faq_item['global_index'] = $global_idx;
		$cslug = $faq_item['category_slug'];
		$cname = $faq_item['category_name'];

		if ( ! isset( $categories_map[ $cslug ] ) ) {
			$categories_map[ $cslug ] = array(
				'name'   => $cname,
				'slug'   => $cslug,
				'anchor' => 'cat-' . $cslug,
				'count'  => 0,
				'items'  => array(),
			);
		}

		++$categories_map[ $cslug ]['count'];
		$categories_map[ $cslug ]['items'][] = $faq_item;
		++$global_idx;
	}
	unset( $faq_item );

	$category_groups = array();
	$question_map    = array();
	$cat_idx         = 1;
	foreach ( $categories_map as $cslug => $cat_data ) {
		$formatted_idx = sprintf( '%02d', $cat_idx );
		$cat_data['index']       = $formatted_idx;
		$cat_data['count_label'] = sprintf( _n( '%d DOMANDA', '%d DOMANDE', $cat_data['count'], 'espressocoppola-child-theme' ), $cat_data['count'] );

		$category_groups[] = $cat_data;
		$question_map[]    = array(
			'index'        => $formatted_idx,
			'name'         => $cat_data['name'],
			'slug'         => $cat_data['slug'],
			'anchor'       => $cat_data['anchor'],
			'count'        => $cat_data['count'],
			'count_label'  => $cat_data['count_label'],
			'first_anchor' => ! empty( $cat_data['items'] ) ? $cat_data['items'][0]['anchor'] : $cat_data['anchor'],
		);
		++$cat_idx;
	}

	// Conversational queries for section 03
	$conversational_queries = array();
	foreach ( $raw_faqs as $faq ) {
		if ( ! empty( $faq['conversational_query'] ) ) {
			$conversational_queries[] = array(
				'query'         => $faq['conversational_query'],
				'title'         => $faq['title'],
				'anchor'        => $faq['anchor'],
				'category_name' => $faq['category_name'],
			);
		}
	}
	// Limit conversational queries to maximum 6 impactful items
	$conversational_queries = array_slice( $conversational_queries, 0, 6 );

	// Related knowledge cards
	$related_links = array(
		array(
			'kicker' => __( 'Collezione & Formati', 'espressocoppola-child-theme' ),
			'title'  => __( 'Lo Shop Online', 'espressocoppola-child-theme' ),
			'desc'   => __( 'Esplora tutte le miscele, i formati compatibili, il caffè in grani e gli accessori Espresso Coppola.', 'espressocoppola-child-theme' ),
			'url'    => $shop_url,
			'label'  => __( 'Visita lo Shop →', 'espressocoppola-child-theme' ),
		),
		array(
			'kicker' => __( 'Analisi Sensoriale', 'espressocoppola-child-theme' ),
			'title'  => __( 'Il DNA delle Miscele', 'espressocoppola-child-theme' ),
			'desc'   => __( 'Confronta intensità, tostatura, persistenza e corpo attraverso i nostri grafici radar interattivi.', 'espressocoppola-child-theme' ),
			'url'    => $dna_url,
			'label'  => __( 'Esplora il DNA →', 'espressocoppola-child-theme' ),
		),
		array(
			'kicker' => __( 'Canale Professionale', 'espressocoppola-child-theme' ),
			'title'  => __( 'Mondo Ho.Re.Ca.', 'espressocoppola-child-theme' ),
			'desc'   => __( 'Forniture dedicate e valutazione campioni per bar, ristoranti, hotel, uffici e servizi catering.', 'espressocoppola-child-theme' ),
			'url'    => $horeca_url,
			'label'  => __( 'Scopri Ho.Re.Ca. →', 'espressocoppola-child-theme' ),
		),
		array(
			'kicker' => __( 'Torrefazione & Contatti', 'espressocoppola-child-theme' ),
			'title'  => __( 'Parla con Noi', 'espressocoppola-child-theme' ),
			'desc'   => __( 'Hai una richiesta specifica o desideri assistenza dedicata? I nostri referenti sono a tua disposizione.', 'espressocoppola-child-theme' ),
			'url'    => $contact_url,
			'label'  => __( 'Vai ai Contatti →', 'espressocoppola-child-theme' ),
		),
	);

	return array(
		'page_id'                => $page_id,
		'title'                  => get_the_title( $page_id ) ?: __( 'FAQ / Answer Atlas', 'espressocoppola-child-theme' ),
		'all_faqs'               => $raw_faqs,
		'total_count'            => count( $raw_faqs ),
		'question_map'           => $question_map,
		'category_groups'        => $category_groups,
		'conversational_queries' => $conversational_queries,
		'related_links'          => $related_links,
	);
}

/**
 * Generate Schema.org JSON-LD structured data for FAQPage.
 *
 * @param array<int,array<string,mixed>> $faqs Active FAQs.
 * @return string
 */
function espressocoppola_get_faq_json_ld( $faqs ) {
	if ( empty( $faqs ) ) {
		return '';
	}

	// Con il sistema FAQ del parent il FAQPage lo stampa il parent, una volta
	// sola per pagina (insieme ad altre eventuali schede FAQ).
	if ( function_exists( 'ticinoweb_faq_schema_add' ) && espressocoppola_faq_on_parent() ) {
		$items = array();
		foreach ( $faqs as $faq ) {
			$items[] = array(
				'question' => $faq['title'],
				'answer'   => isset( $faq['answer'] ) ? $faq['answer'] : $faq['content'],
			);
		}
		ticinoweb_faq_schema_add( $items );
		return '';
	}

	$entities = array();
	foreach ( $faqs as $faq ) {
		$entities[] = array(
			'@type'          => 'Question',
			'name'           => wp_strip_all_tags( $faq['title'] ),
			'acceptedAnswer' => array(
				'@type' => 'Answer',
				'text'  => $faq['plain_text'],
			),
		);
	}

	$schema = array(
		'@context'   => 'https://schema.org',
		'@type'      => 'FAQPage',
		'mainEntity' => $entities,
	);

	return '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>';
}
