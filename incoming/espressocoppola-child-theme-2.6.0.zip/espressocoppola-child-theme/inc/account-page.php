<?php
/**
 * Data adapter and page helpers for the WooCommerce My Account page.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Whether the current page is the WooCommerce My Account page.
 * Detects standard WooCommerce account endpoint, Gutenberg block, shortcode, and account slugs.
 *
 * @return bool
 */
function espressocoppola_is_account_page() {
	if ( function_exists( 'is_account_page' ) && is_account_page() ) {
		return true;
	}

	global $post;
	if ( $post instanceof WP_Post ) {
		if ( has_block( 'woocommerce/my-account', $post ) || has_shortcode( $post->post_content, 'woocommerce_my_account' ) ) {
			return true;
		}
		if ( 'mio-account' === $post->post_name || 'my-account' === $post->post_name || 'account' === $post->post_name ) {
			return true;
		}
	}

	return false;
}

/**
 * Add a stable body class for account styling.
 *
 * @param string[] $classes Body classes.
 * @return string[]
 */
function espressocoppola_account_body_class( $classes ) {
	if ( espressocoppola_is_account_page() ) {
		$classes[] = 'espresso-coppola-account';
	}

	return $classes;
}
add_filter( 'body_class', 'espressocoppola_account_body_class' );
