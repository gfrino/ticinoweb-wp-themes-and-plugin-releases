<?php
/**
 * Espresso Coppola Child Theme functions and definitions.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once get_stylesheet_directory() . '/inc/coffee-finder.php';
require_once get_stylesheet_directory() . '/inc/coffee-gateway.php';
require_once get_stylesheet_directory() . '/inc/homepage.php';
require_once get_stylesheet_directory() . '/inc/header.php';
require_once get_stylesheet_directory() . '/inc/sensory-profile.php';
require_once get_stylesheet_directory() . '/inc/shop.php';
require_once get_stylesheet_directory() . '/inc/product-page.php';
require_once get_stylesheet_directory() . '/inc/about-page.php';
require_once get_stylesheet_directory() . '/inc/dna-page.php';
require_once get_stylesheet_directory() . '/inc/coffee-exhibition.php';
require_once get_stylesheet_directory() . '/inc/contact-page.php';
require_once get_stylesheet_directory() . '/inc/footer.php';
require_once get_stylesheet_directory() . '/inc/price-list.php';
require_once get_stylesheet_directory() . '/inc/horeca-cpt.php';
require_once get_stylesheet_directory() . '/inc/horeca-admin.php';
require_once get_stylesheet_directory() . '/inc/horeca-form-handler.php';
require_once get_stylesheet_directory() . '/inc/horeca-page.php';
require_once get_stylesheet_directory() . '/inc/cart-page.php';
require_once get_stylesheet_directory() . '/inc/checkout-page.php';
require_once get_stylesheet_directory() . '/inc/account-page.php';
require_once get_stylesheet_directory() . '/inc/faq-cpt.php';
require_once get_stylesheet_directory() . '/inc/faq-admin.php';
require_once get_stylesheet_directory() . '/inc/faq-page.php';
require_once get_stylesheet_directory() . '/inc/faq-seed.php';
require_once get_stylesheet_directory() . '/inc/faq-parent.php';

/**
 * Return a cache-safe version for a child-theme asset.
 *
 * @param string $relative_path Path relative to the child-theme root.
 * @return string
 */
function espressocoppola_asset_version( $relative_path ) {
	$path = get_stylesheet_directory() . '/' . ltrim( $relative_path, '/' );

	return file_exists( $path ) ? (string) filemtime( $path ) : (string) wp_get_theme()->get( 'Version' );
}

/**
 * Load the parent and child theme stylesheets.
 *
 * The parent theme registers its main handle with get_stylesheet_uri(). When a
 * child theme is active that function points to the child stylesheet, so the
 * handle is replaced here to ensure both stylesheets are loaded exactly once.
 *
 * @return void
 */
function espressocoppola_child_enqueue_styles() {
	$parent_theme = wp_get_theme( get_template() );

	wp_dequeue_style( 'ticinoweb-ai-style' );
	wp_deregister_style( 'ticinoweb-ai-style' );

	wp_enqueue_style(
		'ticinoweb-ai-parent-style',
		get_template_directory_uri() . '/style.css',
		array( 'poppins-font' ),
		$parent_theme->get( 'Version' )
	);

	wp_enqueue_style(
		'espressocoppola-child-style',
		get_stylesheet_uri(),
		array( 'ticinoweb-ai-parent-style' ),
		espressocoppola_asset_version( 'style.css' )
	);

	wp_enqueue_style(
		'espressocoppola-header',
		get_stylesheet_directory_uri() . '/assets/css/header.css',
		array( 'espressocoppola-child-style' ),
		espressocoppola_asset_version( 'assets/css/header.css' )
	);

	wp_enqueue_style(
		'espressocoppola-footer',
		get_stylesheet_directory_uri() . '/assets/css/footer.css',
		array( 'espressocoppola-child-style' ),
		espressocoppola_asset_version( 'assets/css/footer.css' )
	);

	$header_script_dependencies = wp_script_is( 'wc-cart-fragments', 'registered' )
		? array( 'wc-cart-fragments' )
		: array();

	wp_enqueue_script(
		'espressocoppola-header',
		get_stylesheet_directory_uri() . '/assets/js/header.js',
		$header_script_dependencies,
		espressocoppola_asset_version( 'assets/js/header.js' ),
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);

	wp_enqueue_style(
		'espressocoppola-coffee-radio',
		get_stylesheet_directory_uri() . '/assets/css/coffee-radio.css',
		array( 'espressocoppola-child-style' ),
		espressocoppola_asset_version( 'assets/css/coffee-radio.css' )
	);

	wp_enqueue_script(
		'espressocoppola-coffee-radio',
		get_stylesheet_directory_uri() . '/assets/js/coffee-radio.js',
		array(),
		espressocoppola_asset_version( 'assets/js/coffee-radio.js' ),
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);

	if ( espressocoppola_is_shop_page() ) {
		wp_enqueue_style( 'espressocoppola-shop', get_stylesheet_directory_uri() . '/assets/css/shop.css', array( 'espressocoppola-header' ), espressocoppola_asset_version( 'assets/css/shop.css' ) );
		wp_enqueue_script( 'espressocoppola-sensory-radar', get_stylesheet_directory_uri() . '/assets/js/sensory-radar.js', array(), espressocoppola_asset_version( 'assets/js/sensory-radar.js' ), array( 'in_footer' => true, 'strategy' => 'defer' ) );
		wp_enqueue_script( 'espressocoppola-shop', get_stylesheet_directory_uri() . '/assets/js/shop.js', array( 'espressocoppola-sensory-radar' ), espressocoppola_asset_version( 'assets/js/shop.js' ), array( 'in_footer' => true, 'strategy' => 'defer' ) );
		wp_localize_script(
			'espressocoppola-shop',
			'espressoShopConfig',
			array(
				'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
				'nonce'     => wp_create_nonce( 'espressocoppola_shop_filter' ),
				'axes'      => array_values( wp_list_pluck( espressocoppola_get_sensory_axes(), 'label' ) ),
				'radarName' => __( 'Profilo sensoriale prodotto', 'espressocoppola-child-theme' ),
				'product'   => __( 'prodotto', 'espressocoppola-child-theme' ),
				'products'  => __( 'prodotti', 'espressocoppola-child-theme' ),
				'updated'   => __( '%d prodotti mostrati', 'espressocoppola-child-theme' ),
				'error'     => __( 'Non è stato possibile aggiornare il catalogo. Riprova.', 'espressocoppola-child-theme' ),
			)
		);
	}

	if ( function_exists( 'is_product' ) && is_product() ) {
		wp_enqueue_style( 'espressocoppola-shop', get_stylesheet_directory_uri() . '/assets/css/shop.css', array( 'espressocoppola-header' ), espressocoppola_asset_version( 'assets/css/shop.css' ) );
		wp_enqueue_style( 'espressocoppola-product', get_stylesheet_directory_uri() . '/assets/css/product.css', array( 'espressocoppola-shop' ), espressocoppola_asset_version( 'assets/css/product.css' ) );
		wp_enqueue_script( 'espressocoppola-sensory-radar', get_stylesheet_directory_uri() . '/assets/js/sensory-radar.js', array(), espressocoppola_asset_version( 'assets/js/sensory-radar.js' ), array( 'in_footer' => true, 'strategy' => 'defer' ) );
		wp_enqueue_script( 'wc-add-to-cart-variation' );
		wp_enqueue_script( 'espressocoppola-product', get_stylesheet_directory_uri() . '/assets/js/product.js', array( 'jquery', 'wc-add-to-cart-variation', 'espressocoppola-sensory-radar' ), espressocoppola_asset_version( 'assets/js/product.js' ), array( 'in_footer' => true, 'strategy' => 'defer' ) );
		wp_localize_script(
			'espressocoppola-product',
			'espressoProductConfig',
			array(
				'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
				'nonce'       => wp_create_nonce( 'espressocoppola_cart_nonce' ),
				'cartUrl'     => function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : '',
				'viewCart'    => __( 'Visualizza carrello', 'espressocoppola-child-theme' ),
				'addedNotice' => __( 'è stato aggiunto al carrello.', 'espressocoppola-child-theme' ),
				'added'       => __( 'Nel carrello', 'espressocoppola-child-theme' ),
				'adding'      => __( 'Aggiunta in corso...', 'espressocoppola-child-theme' ),
				'addToCart'   => __( 'Aggiungi al carrello', 'espressocoppola-child-theme' ),
				'axes'        => array_values( wp_list_pluck( espressocoppola_get_sensory_axes(), 'label' ) ),
				'inStock'     => __( 'Disponibile', 'espressocoppola-child-theme' ),
				'outOfStock'  => __( 'Non disponibile', 'espressocoppola-child-theme' ),
			)
		);
	}

	if ( espressocoppola_is_about_page() ) {
		wp_enqueue_style( 'espressocoppola-shop', get_stylesheet_directory_uri() . '/assets/css/shop.css', array( 'espressocoppola-header' ), espressocoppola_asset_version( 'assets/css/shop.css' ) );
		wp_enqueue_style( 'espressocoppola-about', get_stylesheet_directory_uri() . '/assets/css/about.css', array( 'espressocoppola-shop' ), espressocoppola_asset_version( 'assets/css/about.css' ) );
		wp_enqueue_script( 'espressocoppola-sensory-radar', get_stylesheet_directory_uri() . '/assets/js/sensory-radar.js', array(), espressocoppola_asset_version( 'assets/js/sensory-radar.js' ), array( 'in_footer' => true, 'strategy' => 'defer' ) );
		wp_enqueue_script( 'espressocoppola-about', get_stylesheet_directory_uri() . '/assets/js/about.js', array( 'espressocoppola-sensory-radar' ), espressocoppola_asset_version( 'assets/js/about.js' ), array( 'in_footer' => true, 'strategy' => 'defer' ) );
		wp_localize_script(
			'espressocoppola-about',
			'espressoAboutConfig',
			array(
				'axes'      => array_values( wp_list_pluck( espressocoppola_get_sensory_axes(), 'label' ) ),
				'radarName' => __( 'Profilo sensoriale Espresso Coppola', 'espressocoppola-child-theme' ),
			)
		);
	}

	if ( espressocoppola_is_dna_page() ) {
		wp_enqueue_style( 'espressocoppola-shop', get_stylesheet_directory_uri() . '/assets/css/shop.css', array( 'espressocoppola-header' ), espressocoppola_asset_version( 'assets/css/shop.css' ) );
		wp_enqueue_style( 'espressocoppola-sensory-explorer', get_stylesheet_directory_uri() . '/assets/css/sensory-explorer.css', array( 'espressocoppola-shop' ), espressocoppola_asset_version( 'assets/css/sensory-explorer.css' ) );
		wp_enqueue_style( 'espressocoppola-dna', get_stylesheet_directory_uri() . '/assets/css/dna.css', array( 'espressocoppola-sensory-explorer' ), espressocoppola_asset_version( 'assets/css/dna.css' ) );
		wp_enqueue_script( 'espressocoppola-sensory-radar', get_stylesheet_directory_uri() . '/assets/js/sensory-radar.js', array(), espressocoppola_asset_version( 'assets/js/sensory-radar.js' ), array( 'in_footer' => true, 'strategy' => 'defer' ) );
		wp_enqueue_script( 'espressocoppola-sensory-explorer', get_stylesheet_directory_uri() . '/assets/js/sensory-explorer.js', array( 'espressocoppola-sensory-radar' ), espressocoppola_asset_version( 'assets/js/sensory-explorer.js' ), array( 'in_footer' => true, 'strategy' => 'defer' ) );
		wp_enqueue_script( 'espressocoppola-dna', get_stylesheet_directory_uri() . '/assets/js/dna.js', array( 'espressocoppola-sensory-radar', 'espressocoppola-sensory-explorer' ), espressocoppola_asset_version( 'assets/js/dna.js' ), array( 'in_footer' => true, 'strategy' => 'defer' ) );
		wp_localize_script( 'espressocoppola-dna', 'espressoDnaConfig', array( 'axes' => array_values( wp_list_pluck( espressocoppola_get_sensory_axes(), 'label' ) ) ) );
	}

	if ( espressocoppola_is_exhibition_page() ) {
		wp_enqueue_style(
			'espressocoppola-coffee-exhibition',
			get_stylesheet_directory_uri() . '/assets/css/coffee-exhibition.css',
			array( 'espressocoppola-header' ),
			espressocoppola_asset_version( 'assets/css/coffee-exhibition.css' )
		);
		wp_enqueue_script(
			'espressocoppola-coffee-exhibition',
			get_stylesheet_directory_uri() . '/assets/js/coffee-exhibition.js',
			array(),
			espressocoppola_asset_version( 'assets/js/coffee-exhibition.js' ),
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
	}

	if ( espressocoppola_is_contact_page() ) {
		wp_enqueue_style(
			'espressocoppola-contact',
			get_stylesheet_directory_uri() . '/assets/css/contact.css',
			array( 'espressocoppola-header' ),
			espressocoppola_asset_version( 'assets/css/contact.css' )
		);
		wp_enqueue_script(
			'espressocoppola-contact',
			get_stylesheet_directory_uri() . '/assets/js/contact.js',
			array(),
			espressocoppola_asset_version( 'assets/js/contact.js' ),
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
	}

	if ( espressocoppola_is_horeca_page() ) {
		wp_enqueue_style(
			'espressocoppola-horeca',
			get_stylesheet_directory_uri() . '/assets/css/horeca.css',
			array( 'espressocoppola-header' ),
			espressocoppola_asset_version( 'assets/css/horeca.css' )
		);
		wp_enqueue_script(
			'espressocoppola-horeca',
			get_stylesheet_directory_uri() . '/assets/js/horeca.js',
			array(),
			espressocoppola_asset_version( 'assets/js/horeca.js' ),
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
		wp_localize_script(
			'espressocoppola-horeca',
			'espressoHorecaConfig',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'espressocoppola_horeca_nonce' ),
			)
		);
	}

	if ( espressocoppola_is_cart_page() ) {
		wp_enqueue_style(
			'espressocoppola-cart',
			get_stylesheet_directory_uri() . '/assets/css/cart.css',
			array( 'espressocoppola-header' ),
			espressocoppola_asset_version( 'assets/css/cart.css' )
		);
	}

	if ( espressocoppola_is_checkout_page() ) {
		wp_enqueue_style(
			'espressocoppola-checkout',
			get_stylesheet_directory_uri() . '/assets/css/checkout.css',
			array( 'espressocoppola-header' ),
			espressocoppola_asset_version( 'assets/css/checkout.css' )
		);
	}

	if ( espressocoppola_is_account_page() ) {
		wp_enqueue_style(
			'espressocoppola-account',
			get_stylesheet_directory_uri() . '/assets/css/account.css',
			array( 'espressocoppola-header' ),
			espressocoppola_asset_version( 'assets/css/account.css' )
		);
	}

	if ( espressocoppola_is_faq_page() ) {
		wp_enqueue_style(
			'espressocoppola-faq',
			get_stylesheet_directory_uri() . '/assets/css/faq.css',
			array( 'espressocoppola-header' ),
			espressocoppola_asset_version( 'assets/css/faq.css' )
		);
		wp_enqueue_script(
			'espressocoppola-faq',
			get_stylesheet_directory_uri() . '/assets/js/faq.js',
			array(),
			espressocoppola_asset_version( 'assets/js/faq.js' ),
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
	}

	if ( ! is_front_page() ) {
		return;
	}

	wp_enqueue_script(
		'espressocoppola-finder-core',
		get_stylesheet_directory_uri() . '/assets/js/coffee-finder-core.js',
		array(),
		espressocoppola_asset_version( 'assets/js/coffee-finder-core.js' ),
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);

	wp_enqueue_style(
		'espressocoppola-coffee-gateway',
		get_stylesheet_directory_uri() . '/assets/css/coffee-gateway.css',
		array( 'espressocoppola-header', 'espressocoppola-coffee-radio' ),
		espressocoppola_asset_version( 'assets/css/coffee-gateway.css' )
	);

	wp_enqueue_style(
		'espressocoppola-home',
		get_stylesheet_directory_uri() . '/assets/css/home.css',
		array( 'espressocoppola-coffee-gateway' ),
		espressocoppola_asset_version( 'assets/css/home.css' )
	);

	$sensory_explorer = espressocoppola_get_sensory_explorer_data();
	if ( ! empty( $sensory_explorer['products'] ) ) {
		wp_enqueue_style(
			'espressocoppola-sensory-explorer',
			get_stylesheet_directory_uri() . '/assets/css/sensory-explorer.css',
			array( 'espressocoppola-home' ),
			espressocoppola_asset_version( 'assets/css/sensory-explorer.css' )
		);
		wp_enqueue_script(
			'espressocoppola-sensory-radar',
			get_stylesheet_directory_uri() . '/assets/js/sensory-radar.js',
			array(),
			espressocoppola_asset_version( 'assets/js/sensory-radar.js' ),
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
		wp_enqueue_script(
			'espressocoppola-sensory-explorer',
			get_stylesheet_directory_uri() . '/assets/js/sensory-explorer.js',
			array( 'espressocoppola-sensory-radar' ),
			espressocoppola_asset_version( 'assets/js/sensory-explorer.js' ),
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
	}

	wp_enqueue_script(
		'espressocoppola-gateway',
		get_stylesheet_directory_uri() . '/assets/js/coffee-gateway.js',
		array( 'espressocoppola-finder-core' ),
		espressocoppola_asset_version( 'assets/js/coffee-gateway.js' ),
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);

	wp_localize_script(
		'espressocoppola-gateway',
		'espressoGatewayI18n',
		array(
			'discover'      => __( 'Acquista', 'espressocoppola-child-theme' ),
			'discoverLabel' => __( 'Acquista %s', 'espressocoppola-child-theme' ),
			'emptyTitle'    => __( 'La selezione sta cambiando.', 'espressocoppola-child-theme' ),
			'emptyCopy'     => __( 'Questa compatibilità tornerà presto disponibile nel nostro shop.', 'espressocoppola-child-theme' ),
			'nextWindow'    => __( 'Avanti', 'espressocoppola-child-theme' ),
			'previousWindow'=> __( 'Indietro', 'espressocoppola-child-theme' ),
			'statusTemplate'=> __( '%1$s, %2$d caffè disponibili.', 'espressocoppola-child-theme' ),
			'windowLabel'   => __( 'In vista', 'espressocoppola-child-theme' ),
			'shopUrl'       => function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' ),
		)
	);

	wp_enqueue_script(
		'espressocoppola-stage',
		get_stylesheet_directory_uri() . '/assets/js/espresso-stage.js',
		array(),
		espressocoppola_asset_version( 'assets/js/espresso-stage.js' ),
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);

	wp_enqueue_script(
		'espressocoppola-home-motion',
		get_stylesheet_directory_uri() . '/assets/js/home.js',
		array(),
		espressocoppola_asset_version( 'assets/js/home.js' ),
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);

}
add_action( 'wp_enqueue_scripts', 'espressocoppola_child_enqueue_styles', 20 );

/**
 * Render the global Espresso Coppola listening ritual on every public page.
 *
 * @return void
 */
function espressocoppola_render_global_coffee_radio() {
	if ( is_admin() ) {
		return;
	}

	get_template_part( 'template-parts/coffee-radio' );
}
add_action( 'wp_footer', 'espressocoppola_render_global_coffee_radio', 8 );

/**
 * Add a stable page scope for child-theme homepage styles.
 *
 * @param string[] $classes Body classes.
 * @return string[]
 */
function espressocoppola_home_body_class( $classes ) {
	if ( is_front_page() ) {
		$classes[] = 'espresso-coppola-home';
	}

	return $classes;
}
add_filter( 'body_class', 'espressocoppola_home_body_class' );

/**
 * Return the Espresso Coppola logo URL.
 *
 * @return string
 */
function espressocoppola_get_logo_url() {
	$theme_png = get_stylesheet_directory() . '/assets/images/espresso-coppola-logo.png';
	if ( file_exists( $theme_png ) ) {
		return get_stylesheet_directory_uri() . '/assets/images/espresso-coppola-logo.png';
	}

	$attachments = get_posts(
		array(
			'name'           => 'logoespresso',
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'posts_per_page' => 1,
			'fields'         => 'ids',
		)
	);

	if ( ! empty( $attachments ) ) {
		$logo_url = wp_get_attachment_image_url( (int) $attachments[0], 'full' );

		if ( $logo_url ) {
			return $logo_url;
		}
	}

	return get_stylesheet_directory_uri() . '/assets/images/espresso-coppola-logo.jpeg';
}
