<!DOCTYPE html>
<html <?php language_attributes(); ?> class="ec-no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<script>document.documentElement.classList.replace('ec-no-js','ec-js');</script>
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?> id="home">
<?php wp_body_open(); ?>
<?php
$header_logo  = espressocoppola_get_header_logo_url();
$header_shop  = espressocoppola_get_header_shop_url();
$header_extra = espressocoppola_get_header_extra_link();
?>
<header class="site-header ec-floating-header" data-floating-header>
	<div class="ec-header__brand-pill">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
			<?php if ( $header_logo ) : ?>
				<img src="<?php echo esc_url( $header_logo ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" class="site-logo ec-header__logo">
			<?php else : ?>
				<span class="site-title"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></span>
			<?php endif; ?>
		</a>
	</div>
	<div class="ec-header__actions-pill">
		<?php if ( $header_shop ) : ?>
			<a class="ec-header__shop" href="<?php echo esc_url( $header_shop ); ?>"><?php esc_html_e( 'Shop', 'espressocoppola-child-theme' ); ?></a>
			<span class="ec-header__divider" aria-hidden="true"></span>
		<?php endif; ?>
		<div class="ec-header__user-group">
			<?php echo espressocoppola_get_header_account_markup(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php echo espressocoppola_get_header_bag_markup(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</div>
		<span class="ec-header__divider" aria-hidden="true"></span>
		<button type="button" class="ec-header__menu-trigger" aria-expanded="false" aria-controls="ec-morph-panel" aria-label="<?php esc_attr_e( 'Apri menu', 'espressocoppola-child-theme' ); ?>" data-header-menu-trigger>
			<span class="ec-header__hamburger" aria-hidden="true">
				<span class="ec-hamburger-line"></span>
				<span class="ec-hamburger-line"></span>
				<span class="ec-hamburger-line"></span>
			</span>
			<span class="screen-reader-text"><?php esc_html_e( 'Menu', 'espressocoppola-child-theme' ); ?></span>
		</button>
	</div>
</header>
<div class="ec-header-backdrop" data-header-backdrop hidden></div>
<section id="ec-morph-panel" class="ec-morph-panel" aria-hidden="false" aria-label="<?php esc_attr_e( 'Menu principale', 'espressocoppola-child-theme' ); ?>" data-header-panel>
	<header class="ec-morph-panel__header">
		<span><?php echo esc_html( get_bloginfo( 'name' ) ); ?></span>
		<button type="button" data-header-close aria-label="<?php esc_attr_e( 'Chiudi il menu', 'espressocoppola-child-theme' ); ?>">×</button>
	</header>
	<div class="ec-morph-panel__word" aria-hidden="true" data-header-background-word></div>
	<nav class="ec-morph-panel__navigation" aria-label="<?php esc_attr_e( 'Navigazione principale', 'espressocoppola-child-theme' ); ?>">
		<?php wp_nav_menu( espressocoppola_get_header_menu_args() ); ?>
	</nav>
	<footer class="ec-morph-panel__footer">
		<?php if ( $header_extra ) : ?><a href="<?php echo esc_url( $header_extra['url'] ); ?>"<?php echo '_blank' === $header_extra['target'] ? ' target="_blank" rel="noopener noreferrer"' : ''; ?>><?php echo esc_html( $header_extra['label'] ); ?> <span aria-hidden="true">↗</span></a><?php endif; ?>
		<?php if ( $header_shop ) : ?><a href="<?php echo esc_url( $header_shop ); ?>"><?php esc_html_e( 'Shop', 'espressocoppola-child-theme' ); ?> <span aria-hidden="true">↗</span></a><?php endif; ?>
		<?php echo espressocoppola_get_header_account_markup(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<?php echo espressocoppola_get_header_bag_markup(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	</footer>
</section>
