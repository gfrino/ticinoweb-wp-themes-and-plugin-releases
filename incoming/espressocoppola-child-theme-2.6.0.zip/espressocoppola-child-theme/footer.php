<?php
/**
 * The template for displaying the custom Espresso Coppola footer.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$footer    = espressocoppola_get_footer_context();
$menu_args = espressocoppola_get_footer_menu_args();
?>

<footer class="ec-footer site-footer" id="contatti" role="contentinfo" aria-label="<?php esc_attr_e( 'Piè di pagina Espresso Coppola', 'espressocoppola-child-theme' ); ?>">
	<!-- Ambient Background Watermark -->
	<div class="ec-footer__watermark" aria-hidden="true">
		<span>ESPRESSO COPPOLA</span>
	</div>

	<div class="ec-footer__inner ec-footer-shell">

		<!-- ==========================================================================
		     01 — BRAND STATEMENT / HERO CTA (CTA SHOP & LISTINO PREZZI DINAMICO)
		     ========================================================================== -->
		<section class="ec-footer-statement" aria-label="<?php esc_attr_e( 'Brand Statement', 'espressocoppola-child-theme' ); ?>">
			<div class="ec-footer-statement__copy">
				<p class="ec-footer-statement__eyebrow"><?php esc_html_e( 'Manifesto & Tradizione', 'espressocoppola-child-theme' ); ?></p>
				<h2 class="ec-footer-statement__title">
					<span>Essenza napoletana.</span>
					<span>In ogni tazza.</span>
				</h2>
			</div>
			<div class="ec-footer-statement__actions">
				<a class="ec-footer-btn is-primary" href="<?php echo esc_url( $footer['shop_url'] ); ?>">
					<span><?php esc_html_e( 'Scopri i nostri caffè', 'espressocoppola-child-theme' ); ?></span>
					<span class="ec-footer-btn__arrow" aria-hidden="true">↗</span>
				</a>
				<?php if ( ! empty( $footer['price_list']['enabled'] ) ) : ?>
					<a
						class="ec-footer-btn is-secondary ec-footer-btn--price-list"
						href="<?php echo esc_url( $footer['price_list']['url'] ); ?>"
						<?php echo ( ! empty( $footer['price_list']['new_tab'] ) && '#' !== $footer['price_list']['url'] ) ? ' target="_blank" rel="noopener noreferrer"' : ''; ?>
						<?php echo ( ! empty( $footer['price_list']['download'] ) && '#' !== $footer['price_list']['url'] ) ? ' download' : ''; ?>
					>
						<span><?php echo esc_html( $footer['price_list']['button_text'] ); ?></span>
						<span class="ec-footer-btn__arrow ec-footer-btn__arrow--download" aria-hidden="true">↓</span>
					</a>
				<?php endif; ?>
			</div>
		</section>

		<!-- ==========================================================================
		     02 — CORPO FOOTER (GRIGLIA EDITORIALE PULITA)
		     ========================================================================== -->
		<div class="ec-footer-main">

			<!-- Colonna 1: Brand & Identità -->
			<div class="ec-footer-col ec-footer-col--brand">
				<div class="ec-footer-brand">
					<?php if ( ! empty( $footer['logo_url'] ) ) : ?>
						<a class="ec-footer-brand__logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php esc_attr_e( 'Torna alla homepage Espresso Coppola', 'espressocoppola-child-theme' ); ?>">
							<img src="<?php echo esc_url( $footer['logo_url'] ); ?>" alt="<?php echo esc_attr( $footer['site_name'] ); ?>" width="180" height="52" loading="lazy">
						</a>
					<?php else : ?>
						<a class="ec-footer-brand__text" href="<?php echo esc_url( home_url( '/' ) ); ?>">
							<?php echo esc_html( $footer['site_name'] ); ?>
						</a>
					<?php endif; ?>

					<p class="ec-footer-brand__tagline">
						<?php esc_html_e( 'Caffè, miscele e rituali d’eccellenza firmati Espresso Coppola.', 'espressocoppola-child-theme' ); ?>
					</p>

					<div class="ec-footer-brand__badge">
						<span class="ec-footer-badge-dot"></span>
						<span><?php esc_html_e( 'Torrefazione Artigianale Napoletana', 'espressocoppola-child-theme' ); ?></span>
					</div>
				</div>
			</div>

			<!-- Colonna 2: Navigazione -->
			<div class="ec-footer-col ec-footer-col--nav">
				<p class="ec-footer-col__title"><?php esc_html_e( 'Navigazione', 'espressocoppola-child-theme' ); ?></p>
				<nav class="ec-footer-nav" aria-label="<?php esc_attr_e( 'Menu piè di pagina', 'espressocoppola-child-theme' ); ?>">
					<?php
					$menu_output = wp_nav_menu( $menu_args );
					if ( ! empty( $menu_output ) ) {
						echo $menu_output; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					} else {
						?>
						<ul class="ec-footer__nav-list">
							<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><span><?php esc_html_e( 'Home', 'espressocoppola-child-theme' ); ?></span> <i class="ec-arrow" aria-hidden="true">↗</i></a></li>
							<li><a href="<?php echo esc_url( $footer['shop_url'] ); ?>"><span><?php esc_html_e( 'Shop', 'espressocoppola-child-theme' ); ?></span> <i class="ec-arrow" aria-hidden="true">↗</i></a></li>
							<li><a href="<?php echo esc_url( home_url( '/chi-siamo/' ) ); ?>"><span><?php esc_html_e( 'Chi siamo', 'espressocoppola-child-theme' ); ?></span> <i class="ec-arrow" aria-hidden="true">↗</i></a></li>
							<li><a href="<?php echo esc_url( home_url( '/dna-delle-miscele/' ) ); ?>"><span><?php esc_html_e( 'DNA delle miscele', 'espressocoppola-child-theme' ); ?></span> <i class="ec-arrow" aria-hidden="true">↗</i></a></li>
							<li><a href="<?php echo esc_url( home_url( '/coffee-exhibition/' ) ); ?>"><span><?php esc_html_e( 'Galleria', 'espressocoppola-child-theme' ); ?></span> <i class="ec-arrow" aria-hidden="true">↗</i></a></li>
							<li><a href="<?php echo esc_url( home_url( '/contatti/' ) ); ?>"><span><?php esc_html_e( 'Contatti', 'espressocoppola-child-theme' ); ?></span> <i class="ec-arrow" aria-hidden="true">↗</i></a></li>
						</ul>
						<?php
					}
					?>
				</nav>
			</div>

			<!-- Colonna 3: Boutique & Sistemi (Link diretti allo Shop con filtro attivo) -->
			<div class="ec-footer-col ec-footer-col--shop">
				<p class="ec-footer-col__title"><?php esc_html_e( 'Boutique & Sistemi', 'espressocoppola-child-theme' ); ?></p>
				<ul class="ec-footer-shop-list">
					<li>
						<a href="<?php echo esc_url( $footer['shop_url'] ); ?>">
							<span><?php esc_html_e( 'Tutti i prodotti', 'espressocoppola-child-theme' ); ?></span>
							<i class="ec-arrow" aria-hidden="true">↗</i>
						</a>
					</li>
					<?php if ( ! empty( $footer['systems'] ) ) : ?>
						<?php foreach ( $footer['systems'] as $system ) : ?>
							<li>
								<a href="<?php echo esc_url( $system['url'] ); ?>">
									<span><?php echo esc_html( $system['name'] ); ?></span>
									<i class="ec-arrow" aria-hidden="true">↗</i>
								</a>
							</li>
						<?php endforeach; ?>
					<?php endif; ?>
				</ul>
			</div>

			<!-- Colonna 4: Contatti & Social -->
			<div class="ec-footer-col ec-footer-col--contact">
				<p class="ec-footer-col__title"><?php esc_html_e( 'Contatti & Relazioni', 'espressocoppola-child-theme' ); ?></p>
				<div class="ec-footer-contact">
					<?php if ( ! empty( $footer['phone'] ) ) : ?>
						<div class="ec-footer-contact-item">
							<span class="ec-footer-contact-label"><?php esc_html_e( 'Telefono', 'espressocoppola-child-theme' ); ?></span>
							<a class="ec-footer-contact-link is-phone" href="tel:<?php echo esc_attr( $footer['phone_clean'] ); ?>">
								<?php echo esc_html( $footer['phone'] ); ?>
							</a>
						</div>
					<?php endif; ?>

					<?php if ( ! empty( $footer['email'] ) ) : ?>
						<div class="ec-footer-contact-item">
							<span class="ec-footer-contact-label"><?php esc_html_e( 'Email', 'espressocoppola-child-theme' ); ?></span>
							<a class="ec-footer-contact-link is-email" href="mailto:<?php echo esc_attr( $footer['email'] ); ?>">
								<?php echo esc_html( $footer['email'] ); ?>
							</a>
						</div>
					<?php endif; ?>

					<?php if ( ! empty( $footer['address'] ) ) : ?>
						<div class="ec-footer-contact-item">
							<span class="ec-footer-contact-label"><?php esc_html_e( 'Sede', 'espressocoppola-child-theme' ); ?></span>
							<address class="ec-footer-address">
								<?php echo nl2br( esc_html( $footer['address'] ) ); ?>
							</address>
						</div>
					<?php endif; ?>

					<?php if ( ! empty( $footer['socials'] ) ) : ?>
						<div class="ec-footer-socials">
							<?php foreach ( $footer['socials'] as $social ) : ?>
								<a class="ec-footer-social-link" href="<?php echo esc_url( $social['url'] ); ?>" target="_blank" rel="noopener noreferrer">
									<span><?php echo esc_html( $social['label'] ); ?></span>
									<span class="ec-arrow" aria-hidden="true">↗</span>
								</a>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>
				</div>
			</div>

		</div>

		<!-- ==========================================================================
		     03 — DISCLAIMER MARCHI / COMPATIBILITÀ
		     ========================================================================== -->
		<div class="ec-footer-disclaimer" aria-label="<?php esc_attr_e( 'Note legali e compatibilità marchi', 'espressocoppola-child-theme' ); ?>">
			<p>
				<?php esc_html_e( 'I marchi e i nomi commerciali citati, tra cui Nespresso, Nescafé Dolce Gusto e A Modo Mio, appartengono ai rispettivi titolari. Espresso Coppola è un operatore indipendente e non è affiliata, sponsorizzata o approvata dai rispettivi proprietari dei marchi. I riferimenti sono utilizzati esclusivamente per indicare la compatibilità dei prodotti.', 'espressocoppola-child-theme' ); ?>
			</p>
		</div>

		<!-- ==========================================================================
		     04 — LEGAL / COPYRIGHT / TICINOWEB
		     ========================================================================== -->
		<div class="ec-footer-bottom">
			<div class="ec-footer-bottom__left">
				<p class="ec-footer-copyright">
					<?php echo esc_html( sprintf( __( '© %s Espresso Coppola. Tutti i diritti riservati.', 'espressocoppola-child-theme' ), $footer['current_year'] ) ); ?>
				</p>
			</div>

			<div class="ec-footer-bottom__links">
				<?php if ( ! empty( $footer['privacy_url'] ) ) : ?>
					<a href="<?php echo esc_url( $footer['privacy_url'] ); ?>"><?php esc_html_e( 'Privacy Policy', 'espressocoppola-child-theme' ); ?></a>
				<?php endif; ?>
				<a href="<?php echo esc_url( admin_url() ); ?>" class="ec-footer__backend"><?php esc_html_e( 'Backend', 'espressocoppola-child-theme' ); ?></a>
			</div>

			<div class="ec-footer-bottom__right">
				<span class="ec-footer-credit">
					<?php esc_html_e( 'Design by', 'espressocoppola-child-theme' ); ?>
					<a href="https://ticinoweb.com" target="_blank" rel="noopener noreferrer">ticinoWEB</a>
				</span>
			</div>
		</div>

	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
