<?php
/**
 * Espresso Coppola front page.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$slides            = espressocoppola_get_home_slides();
$featured_products = espressocoppola_get_featured_products();
$finder_catalog    = espressocoppola_get_coffee_finder_catalog();
$gateway_choices   = espressocoppola_get_coffee_gateway_choices( $finder_catalog );
$active_gateway    = espressocoppola_get_coffee_gateway_active_slug(
	$gateway_choices,
	isset( $_GET['coffee_system'] ) ? wp_unslash( $_GET['coffee_system'] ) : null
);
$gateway_args      = array(
	'catalog'     => $finder_catalog,
	'choices'     => $gateway_choices,
	'active_slug' => $active_gateway,
);
$product_stage      = array();
$active_tone       = ! empty( $slides[0]['tone'] ) ? $slides[0]['tone'] : 'crema';
$collection_tone   = 'crema';
$shop_url          = function_exists( 'ticinoweb_get_shop_url' ) ? ticinoweb_get_shop_url() : '';
$hero_format_links = espressocoppola_get_hero_format_links();

foreach ( $featured_products as $product_index => $featured_product ) {
	if ( $featured_product instanceof WC_Product ) {
		$product_stage[] = array(
			'product' => $featured_product,
			'data'    => espressocoppola_get_product_stage_data( $featured_product, $product_index ),
		);
	}
}

if ( ! empty( $product_stage[0]['data']['tone'] ) ) {
	$collection_tone = $product_stage[0]['data']['tone'];
}

get_header();
?>
<main id="main" class="ec-home-main">
	<?php get_template_part( 'template-parts/home/coffee-gateway', null, $gateway_args ); ?>

	<!-- Espresso Stage: contenuti dinamici dallo Slider ticinoWEB CMS. -->
	<section
		class="espresso-stage espresso-stage--<?php echo esc_attr( $active_tone ); ?>"
		role="region"
		aria-label="<?php esc_attr_e( 'Selezione Espresso Coppola', 'espressocoppola-child-theme' ); ?>"
		data-source="ticinoweb-cms"
		data-tone="<?php echo esc_attr( $active_tone ); ?>"
		data-next-tone="<?php echo esc_attr( $collection_tone ); ?>"
		data-stage-count="<?php echo esc_attr( count( $slides ) ); ?>"
		data-stage-scroll
		data-espresso-stage
		data-home-hero
	>
		<?php if ( ! empty( $slides ) ) : ?>
			<div class="espresso-stage__sticky">
				<div class="espresso-stage__atmosphere" aria-hidden="true">
					<span class="espresso-stage__atmosphere-orbit"></span>
					<span class="espresso-stage__bean espresso-stage__bean--one"></span>
					<span class="espresso-stage__bean espresso-stage__bean--two"></span>
					<svg class="espresso-stage__steam" viewBox="0 0 180 260" focusable="false">
						<path d="M48 248C12 194 86 168 50 112C22 68 64 40 82 10" />
						<path d="M112 238C78 188 148 160 116 106C92 66 126 38 138 16" />
					</svg>
				</div>

				<div class="espresso-stage__track" aria-live="off">
					<?php foreach ( $slides as $index => $slide ) : ?>
						<?php
						$is_active   = 0 === $index;
						$word_length = function_exists( 'mb_strlen' ) ? mb_strlen( $slide['title'] ) : strlen( $slide['title'] );
						$word_scale  = $word_length > 10 ? 'long' : ( $word_length > 6 ? 'medium' : 'short' );
						?>
						<article
							id="espresso-stage-slide-<?php echo esc_attr( $index + 1 ); ?>"
							class="espresso-stage__slide<?php echo $is_active ? ' is-active' : ''; ?>"
							data-slide-index="<?php echo esc_attr( $index ); ?>"
							data-tone="<?php echo esc_attr( $slide['tone'] ); ?>"
							aria-hidden="<?php echo $is_active ? 'false' : 'true'; ?>"
							<?php echo $is_active ? '' : 'inert'; ?>
						>
							<p class="espresso-stage__word espresso-stage__word--<?php echo esc_attr( $word_scale ); ?>" aria-hidden="true"><?php echo esc_html( $slide['title'] ); ?></p>
							<div class="espresso-stage__copy">
								<div class="espresso-stage__meta">
									<p class="espresso-stage__eyebrow"><?php esc_html_e( 'Espresso Coppola — Essenza Napoletana', 'espressocoppola-child-theme' ); ?></p>
									<?php if ( $shop_url ) : ?>
										<a class="espresso-stage__shop-signal" href="<?php echo esc_url( $shop_url ); ?>" data-hero-shop-online>
											<?php esc_html_e( 'Shop online', 'espressocoppola-child-theme' ); ?> <span aria-hidden="true">↗</span>
										</a>
									<?php endif; ?>
								</div>
								<?php if ( 0 === $index ) : ?>
									<h1 class="espresso-stage__title"><?php echo esc_html( $slide['title'] ); ?></h1>
								<?php else : ?>
									<h2 class="espresso-stage__title"><?php echo esc_html( $slide['title'] ); ?></h2>
								<?php endif; ?>
								<?php if ( '' !== trim( $slide['description'] ) ) : ?>
									<p class="espresso-stage__description"><?php echo esc_html( $slide['description'] ); ?></p>
								<?php endif; ?>
								<?php if ( ! empty( $slide['button_text'] ) && ! empty( $slide['button_url'] ) ) : ?>
									<a class="ec-button ec-button--primary espresso-stage__cta" href="<?php echo esc_url( $slide['button_url'] ); ?>">
										<span><?php echo esc_html( $slide['button_text'] ); ?></span>
										<span aria-hidden="true">↗</span>
									</a>
								<?php endif; ?>
							</div>

							<div class="espresso-stage__visual" aria-hidden="true">
								<div class="espresso-stage__aura"></div>
								<div class="espresso-stage__product-plane">
									<div class="espresso-stage__product-float">
										<?php echo espressocoppola_get_slide_image_html( $slide, $is_active ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
									</div>
								</div>
							</div>
						</article>
					<?php endforeach; ?>
				</div>

				<?php if ( ! empty( $hero_format_links ) ) : ?>
					<nav class="espresso-stage__shop-formats" aria-label="<?php esc_attr_e( 'Acquista per formato', 'espressocoppola-child-theme' ); ?>" data-hero-shop-formats>
						<span class="espresso-stage__shop-formats-label"><?php esc_html_e( 'Shop by format', 'espressocoppola-child-theme' ); ?></span>
						<span class="espresso-stage__shop-format-links">
							<?php foreach ( $hero_format_links as $format_link ) : ?>
								<a href="<?php echo esc_url( $format_link['url'] ); ?>" data-hero-format-link>
									<?php echo esc_html( $format_link['name'] ); ?> <span aria-hidden="true">↗</span>
								</a>
							<?php endforeach; ?>
						</span>
					</nav>
				<?php endif; ?>

				<?php if ( count( $slides ) > 1 ) : ?>
					<div class="espresso-stage__chapter-ui">
						<div class="espresso-stage__counter">
							<span data-stage-current>01</span>
							<span aria-hidden="true">/</span>
							<span><?php echo esc_html( sprintf( '%02d', count( $slides ) ) ); ?></span>
						</div>
						<div class="espresso-stage__progress" aria-hidden="true"><span data-stage-progress></span></div>
						<nav class="espresso-stage__navigation" aria-label="<?php esc_attr_e( 'Vai a una miscela', 'espressocoppola-child-theme' ); ?>">
							<?php foreach ( $slides as $index => $slide ) : ?>
								<button
									class="espresso-stage__nav-item<?php echo 0 === $index ? ' is-active' : ''; ?>"
									type="button"
									data-stage-target="<?php echo esc_attr( $index ); ?>"
									aria-label="<?php echo esc_attr( sprintf( __( 'Vai alla miscela %s', 'espressocoppola-child-theme' ), $slide['title'] ) ); ?>"
									aria-controls="espresso-stage-slide-<?php echo esc_attr( $index + 1 ); ?>"
									<?php echo 0 === $index ? 'aria-current="true"' : ''; ?>
								><span aria-hidden="true"></span></button>
							<?php endforeach; ?>
						</nav>
						<span class="ec-screen-reader-text" role="status" aria-live="polite" aria-atomic="true" data-stage-status></span>
						<p class="espresso-stage__scroll-hint"><?php esc_html_e( 'Scorri per esplorare', 'espressocoppola-child-theme' ); ?><span aria-hidden="true">↓</span></p>
					</div>
				<?php endif; ?>
				<div class="espresso-stage__exit" aria-hidden="true"></div>
			</div>
		<?php else : ?>
			<div class="espresso-stage__empty">
				<p class="espresso-stage__eyebrow"><?php esc_html_e( 'Espresso Coppola — Essenza Napoletana', 'espressocoppola-child-theme' ); ?></p>
				<h1><?php esc_html_e( 'Il nostro espresso sta prendendo forma.', 'espressocoppola-child-theme' ); ?></h1>
				<p><?php esc_html_e( 'Le miscele saranno presto protagoniste di questo spazio.', 'espressocoppola-child-theme' ); ?></p>
				<div class="espresso-stage__empty-mark" aria-hidden="true">ec</div>
			</div>
		<?php endif; ?>
	</section>

	<!-- Product Stage: selezione editoriale dinamica da WooCommerce. -->
	<section
		id="coffee-collection"
		class="ec-featured ec-product-stage ec-stack-panel"
		aria-labelledby="ec-featured-title"
		data-home-observe
		data-product-stage
		data-product-count="<?php echo esc_attr( count( $product_stage ) ); ?>"
		data-active-index="0"
		data-tone="<?php echo esc_attr( $collection_tone ); ?>"
	>
		<div class="ec-product-stage__sticky">
			<div class="ec-product-stage__atmosphere" aria-hidden="true">
				<span class="ec-product-stage__halo"></span>
				<span class="ec-product-stage__orbit"></span>
				<span class="ec-product-stage__bean ec-product-stage__bean--one"></span>
				<span class="ec-product-stage__bean ec-product-stage__bean--two"></span>
			</div>
			<div class="ec-home-container ec-product-stage__inner">
			<header class="ec-featured__header">
				<div>
					<p><?php esc_html_e( 'La collezione', 'espressocoppola-child-theme' ); ?></p>
					<h2 id="ec-featured-title"><?php esc_html_e( 'I nostri caffè', 'espressocoppola-child-theme' ); ?></h2>
				</div>
				<?php if ( $shop_url ) : ?>
					<a href="<?php echo esc_url( $shop_url ); ?>"><?php esc_html_e( 'Scopri la collezione', 'espressocoppola-child-theme' ); ?> <span aria-hidden="true">↗</span></a>
				<?php endif; ?>
			</header>

			<?php if ( ! empty( $product_stage ) ) : ?>
				<div class="ec-product-stage__canvas">
					<nav class="ec-product-stage__navigation" aria-label="<?php esc_attr_e( 'Navigazione caffè in evidenza', 'espressocoppola-child-theme' ); ?>">
						<?php foreach ( $product_stage as $index => $stage_item ) : ?>
							<?php $stage_data = $stage_item['data']; ?>
							<button
								type="button"
								class="ec-product-stage__nav-item<?php echo 0 === $index ? ' is-active' : ''; ?>"
								data-product-target="<?php echo esc_attr( $index ); ?>"
								aria-controls="ec-product-stage-item-<?php echo esc_attr( $stage_data['id'] ); ?>"
								<?php echo 0 === $index ? 'aria-current="true"' : ''; ?>
							>
								<span><?php echo esc_html( sprintf( '%02d', $index + 1 ) ); ?></span>
								<strong><?php echo esc_html( $stage_data['blend_label'] ); ?></strong>
								<small><?php echo esc_html( $stage_data['preparation_label'] ); ?></small>
								<i aria-hidden="true"></i>
							</button>
						<?php endforeach; ?>
					</nav>

					<div class="ec-product-stage__viewport">
						<?php foreach ( $product_stage as $index => $stage_item ) : ?>
							<?php
							$stage_data        = $stage_item['data'];
							$product_image_html = '';

							if ( ! empty( $stage_data['image_id'] ) ) {
								$product_image_html = wp_get_attachment_image(
									$stage_data['image_id'],
									'woocommerce_single',
									false,
									array(
										'loading'  => 'lazy',
										'decoding' => 'async',
										'sizes'    => '(max-width: 780px) 86vw, 52vw',
										'alt'      => $stage_data['name'],
									)
								);
							}
							?>
							<article
								id="ec-product-stage-item-<?php echo esc_attr( $stage_data['id'] ); ?>"
								class="ec-product-stage__item ec-product-stage__item--<?php echo esc_attr( $stage_data['tone'] ); ?><?php echo 0 === $index ? ' is-active' : ''; ?>"
								data-product-item="<?php echo esc_attr( $index ); ?>"
								data-tone="<?php echo esc_attr( $stage_data['tone'] ); ?>"
							>
								<div class="ec-product-stage__copy">
									<p class="ec-product-stage__overline">
										<span><?php echo esc_html( $stage_data['blend_label'] ); ?></span>
										<span aria-hidden="true">—</span>
										<span><?php echo esc_html( $stage_data['preparation_label'] ); ?></span>
									</p>
									<h3><a href="<?php echo esc_url( $stage_data['url'] ); ?>"><?php echo esc_html( $stage_data['name'] ); ?></a></h3>
									<?php if ( '' !== $stage_data['summary'] ) : ?>
										<p class="ec-product-stage__description"><?php echo esc_html( $stage_data['summary'] ); ?></p>
									<?php endif; ?>
									<div class="ec-product-stage__commercial">
										<span class="ec-product-stage__price"><?php echo wp_kses_post( $stage_data['price_html'] ); ?></span>
										<a class="ec-button ec-button--dark" href="<?php echo esc_url( $stage_data['url'] ); ?>">
											<?php esc_html_e( 'Scopri il caffè', 'espressocoppola-child-theme' ); ?>
											<span aria-hidden="true">↗</span>
										</a>
									</div>
								</div>

								<a class="ec-product-stage__visual" href="<?php echo esc_url( $stage_data['url'] ); ?>" tabindex="-1" aria-hidden="true">
									<span class="ec-product-stage__disc"></span>
									<?php if ( '' !== $product_image_html ) : ?>
										<?php echo $product_image_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
									<?php else : ?>
										<span class="ec-product-stage__fallback">
											<strong>espresso<br>coppola</strong>
											<small><?php esc_html_e( 'Essenza Napoletana', 'espressocoppola-child-theme' ); ?></small>
										</span>
									<?php endif; ?>
								</a>
							</article>
						<?php endforeach; ?>
					</div>

					<p class="ec-product-stage__count" aria-hidden="true">
						<span data-product-current>01</span>
						<span></span>
						<span><?php echo esc_html( sprintf( '%02d', count( $product_stage ) ) ); ?></span>
					</p>
				</div>
			<?php else : ?>
				<div class="ec-featured__empty">
					<p><?php esc_html_e( 'La prima selezione Espresso Coppola arriverà presto.', 'espressocoppola-child-theme' ); ?></p>
				</div>
			<?php endif; ?>
			</div>
		</div>

		<?php if ( ! empty( $product_stage ) ) : ?>
			<div class="ec-product-stage__steps" aria-hidden="true">
				<?php foreach ( $product_stage as $index => $stage_item ) : ?>
					<span data-product-step="<?php echo esc_attr( $index ); ?>"></span>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</section>

	<?php
	get_template_part(
		'template-parts/home/sensory-explorer',
		null,
		array( 'explorer' => espressocoppola_get_sensory_explorer_data() )
	);
	?>
</main>
<?php
get_footer();
