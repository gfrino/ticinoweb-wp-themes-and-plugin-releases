<?php
/**
 * Espresso Coppola premium WooCommerce shop.
 *
 * @package EspressoCoppolaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$catalog    = espressocoppola_get_shop_catalog();
$filters    = espressocoppola_get_shop_filter_options( $catalog );
$axes       = espressocoppola_get_sensory_axes();
$raw_types  = isset( $_GET['type'] ) ? (array) $_GET['type'] : ( isset( $_GET['types'] ) ? (array) $_GET['types'] : array() );
$raw_blends = isset( $_GET['blend'] ) ? (array) $_GET['blend'] : ( isset( $_GET['blends'] ) ? (array) $_GET['blends'] : array() );
$init_state = espressocoppola_sanitize_shop_filters( array( 'types' => $raw_types, 'blends' => $raw_blends ) );
$products   = espressocoppola_filter_shop_catalog( $catalog, $init_state );

get_header();
?>
<main id="main" class="ec-shop" data-shop-root>
	<div class="ec-shop__orbit" aria-hidden="true"></div>
	<header class="ec-shop__intro">
		<p class="ec-shop__kicker"><?php esc_html_e( 'La collezione', 'espressocoppola-child-theme' ); ?></p>
		<div class="ec-shop__intro-grid">
			<h1><?php esc_html_e( 'I nostri caffè', 'espressocoppola-child-theme' ); ?></h1>
			<p><?php esc_html_e( 'Miscele, capsule, cialde e accessori selezionati per portare l’essenza napoletana in ogni tazza.', 'espressocoppola-child-theme' ); ?></p>
		</div>
		<p class="ec-shop__result-summary" aria-live="polite"><strong data-shop-count><?php echo esc_html( count( $products ) ); ?></strong> <span data-shop-count-label><?php echo esc_html( 1 === count( $products ) ? __( 'prodotto', 'espressocoppola-child-theme' ) : __( 'prodotti', 'espressocoppola-child-theme' ) ); ?></span></p>
	</header>

	<div class="ec-shop__toolbar">
		<button type="button" class="ec-shop__filter-trigger" data-shop-filter-open aria-controls="ec-shop-filters" aria-expanded="false"><?php esc_html_e( 'Filtri', 'espressocoppola-child-theme' ); ?> <span data-shop-active-count hidden></span></button>
		<div class="ec-shop__chips" data-shop-chips aria-label="<?php esc_attr_e( 'Filtri attivi', 'espressocoppola-child-theme' ); ?>"></div>
		<label class="ec-shop__order"><span><?php esc_html_e( 'Ordina', 'espressocoppola-child-theme' ); ?></span><select data-shop-order><option value="menu_order"><?php esc_html_e( 'Selezione', 'espressocoppola-child-theme' ); ?></option><option value="date-desc"><?php esc_html_e( 'Più recenti', 'espressocoppola-child-theme' ); ?></option><option value="price-asc"><?php esc_html_e( 'Prezzo crescente', 'espressocoppola-child-theme' ); ?></option><option value="price-desc"><?php esc_html_e( 'Prezzo decrescente', 'espressocoppola-child-theme' ); ?></option></select></label>
	</div>

	<div class="ec-shop__layout">
		<div class="ec-shop__backdrop" data-shop-filter-backdrop hidden></div>
		<aside id="ec-shop-filters" class="ec-shop__filters" aria-label="<?php esc_attr_e( 'Filtri catalogo', 'espressocoppola-child-theme' ); ?>" data-shop-filters>
			<div class="ec-shop__filter-head"><div><small><?php esc_html_e( 'Esplora', 'espressocoppola-child-theme' ); ?></small><h2><?php esc_html_e( 'Filtra la collezione', 'espressocoppola-child-theme' ); ?></h2></div><button type="button" data-shop-filter-close aria-label="<?php esc_attr_e( 'Chiudi filtri', 'espressocoppola-child-theme' ); ?>">×</button></div>
			<form data-shop-filter-form>
				<fieldset><legend><?php esc_html_e( 'Come lo prepari', 'espressocoppola-child-theme' ); ?></legend><div class="ec-shop__filter-list">
					<?php foreach ( $filters['types'] as $type ) : ?><label><input type="checkbox" name="types[]" value="<?php echo esc_attr( $type['slug'] ); ?>" <?php checked( in_array( $type['slug'], $init_state['types'], true ) ); ?>><span><?php echo esc_html( $type['name'] ); ?></span><small><?php echo esc_html( $type['count'] ); ?></small></label><?php endforeach; ?>
				</div></fieldset>
				<?php if ( $filters['blends'] ) : ?><fieldset><legend><?php esc_html_e( 'Miscela', 'espressocoppola-child-theme' ); ?></legend><div class="ec-shop__filter-list">
					<?php foreach ( $filters['blends'] as $blend ) : ?><label><input type="checkbox" name="blends[]" value="<?php echo esc_attr( $blend['slug'] ); ?>" <?php checked( in_array( $blend['slug'], $init_state['blends'], true ) ); ?>><span><?php echo esc_html( $blend['name'] ); ?></span><small><?php echo esc_html( $blend['count'] ); ?></small></label><?php endforeach; ?>
				</div></fieldset><?php endif; ?>
				<details class="ec-shop__sensory-filter"><summary><?php esc_html_e( 'Profilo sensoriale', 'espressocoppola-child-theme' ); ?><span aria-hidden="true">+</span></summary><div class="ec-shop__sensory-controls">
					<?php foreach ( $axes as $axis_key => $axis ) : ?><label><span><?php echo esc_html( $axis['label'] ); ?></span><output for="ec-shop-<?php echo esc_attr( $axis_key ); ?>">0</output><input id="ec-shop-<?php echo esc_attr( $axis_key ); ?>" type="range" name="sensory[<?php echo esc_attr( $axis_key ); ?>]" min="0" max="5" step="1" value="0" data-shop-sensory></label><?php endforeach; ?>
				</div></details>
				<div class="ec-shop__filter-actions"><button type="reset" data-shop-reset><?php esc_html_e( 'Reset filtri', 'espressocoppola-child-theme' ); ?></button><button type="button" data-shop-filter-apply><?php esc_html_e( 'Mostra prodotti', 'espressocoppola-child-theme' ); ?></button></div>
			</form>
		</aside>

		<section class="ec-shop__catalog" aria-label="<?php esc_attr_e( 'Catalogo prodotti', 'espressocoppola-child-theme' ); ?>">
			<div class="ec-shop__loading" data-shop-loading hidden><span></span><span><?php esc_html_e( 'Aggiorno la selezione…', 'espressocoppola-child-theme' ); ?></span></div>
			<div class="ec-shop__grid" data-shop-grid><?php echo espressocoppola_render_shop_cards( $products ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
			<div class="ec-shop__status ec-screen-reader-text" role="status" aria-live="polite" data-shop-status></div>
		</section>
	</div>
</main>
<?php get_footer(); ?>
