<?php
/**
 * Documenti dell'Albo patriziale.
 *
 * Un solo archivio di documenti (PDF o link esterno), diviso in tre sezioni con una
 * pagina ciascuna:
 * - Regolamenti e ordinanze (/regolamenti-e-ordinanze/): elenco unico, in ordine alfabetico;
 * - Assemblee (/assemblee/): un blocco per assemblea, dalla più recente;
 * - Concorsi (/concorsi/): un blocco per anno, dal più recente.
 *
 * Le assemblee sono termini della tassonomia `documento_assemblea`: si scelgono o si
 * creano dalla scheda del documento e si rinominano da Documenti → Assemblee.
 * Le pagine delle sezioni sono pagine normali (titolo e testo introduttivo modificabili)
 * che usano i template page-<slug>.php del tema.
 *
 * @package Patriziato Frasco
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sezioni dell'Albo che raccolgono documenti: chiave => dati della sezione.
 *
 * @return array
 */
function ptf_documenti_sezioni() {
	return array(
		'regolamenti' => array(
			'nome'        => 'Regolamenti e ordinanze',
			'slug'        => 'regolamenti-e-ordinanze',
			'sottotitolo' => 'Leggi, regolamenti e ordinanze del Patriziato.',
			'gruppi'      => 'nessuno',
		),
		'assemblee'   => array(
			'nome'        => 'Assemblee',
			'slug'        => 'assemblee',
			'sottotitolo' => 'Convocazioni, messaggi e rapporti di ogni assemblea.',
			'gruppi'      => 'assemblea',
		),
		'concorsi'    => array(
			'nome'        => 'Concorsi',
			'slug'        => 'concorsi',
			'sottotitolo' => 'Bandi e concorsi pubblici del Patriziato.',
			'gruppi'      => 'anno',
		),
	);
}

/**
 * Registra il tipo «Documento» e la tassonomia delle assemblee.
 */
function ptf_register_documenti_cpt() {
	register_post_type(
		'documento',
		array(
			'labels'        => array(
				'name'               => 'Documenti',
				'singular_name'      => 'Documento',
				'menu_name'          => 'Documenti',
				'name_admin_bar'     => 'Documento',
				'add_new'            => 'Aggiungi nuovo',
				'add_new_item'       => 'Aggiungi nuovo documento',
				'new_item'           => 'Nuovo documento',
				'edit_item'          => 'Modifica documento',
				'view_item'          => 'Visualizza documento',
				'all_items'          => 'Tutti i documenti',
				'search_items'       => 'Cerca documenti',
				'not_found'          => 'Nessun documento trovato.',
				'not_found_in_trash' => 'Nessun documento nel cestino.',
			),
			'public'        => true,
			'has_archive'   => false,
			'rewrite'       => array( 'slug' => 'documenti', 'with_front' => false ),
			'menu_position' => 5.46,
			'menu_icon'     => 'dashicons-media-document',
			'supports'      => array( 'title' ),
			'show_in_rest'  => false,
		)
	);

	register_taxonomy(
		'documento_assemblea',
		'documento',
		array(
			'labels'            => array(
				'name'          => 'Assemblee',
				'singular_name' => 'Assemblea',
				'menu_name'     => 'Assemblee',
				'all_items'     => 'Tutte le assemblee',
				'edit_item'     => 'Modifica assemblea',
				'update_item'   => 'Aggiorna assemblea',
				'add_new_item'  => 'Aggiungi nuova assemblea',
				'new_item_name' => 'Nome della nuova assemblea',
				'search_items'  => 'Cerca assemblee',
				'not_found'     => 'Nessuna assemblea.',
			),
			'public'            => false,
			'show_ui'           => true,
			'show_in_menu'      => true,
			'show_admin_column' => false,
			'meta_box_cb'       => false, // Si sceglie dal riquadro «Dettagli del documento».
			'hierarchical'      => false,
			'rewrite'           => false,
			'show_in_rest'      => false,
		)
	);
}
add_action( 'init', 'ptf_register_documenti_cpt' );

/**
 * Rigenera gli indirizzi una sola volta per versione delle regole, così le modifiche
 * agli URL funzionano anche sul server senza passare dai Permalink.
 */
function ptf_documenti_flush_rewrite_once() {
	if ( 'documenti-2' !== get_option( 'ptf_rewrite_version' ) ) {
		flush_rewrite_rules( false );
		update_option( 'ptf_rewrite_version', 'documenti-2' );
	}
}
add_action( 'init', 'ptf_documenti_flush_rewrite_once', 20 );

/**
 * Metabox con sezione, assemblea, PDF o link, data e descrizione.
 */
function ptf_documenti_add_metabox() {
	add_meta_box( 'ptf_documento_dettagli', 'Dettagli del documento', 'ptf_documenti_metabox', 'documento', 'normal', 'high' );
}
add_action( 'add_meta_boxes', 'ptf_documenti_add_metabox' );

/**
 * HTML del metabox.
 *
 * @param WP_Post $post Documento.
 */
function ptf_documenti_metabox( $post ) {
	wp_nonce_field( 'ptf_documento_salva', 'ptf_documento_nonce' );

	$sezioni     = ptf_documenti_sezioni();
	$sezione     = get_post_meta( $post->ID, '_documento_sezione', true );
	$pdf_id      = (int) get_post_meta( $post->ID, '_documento_pdf_id', true );
	$pdf_url     = $pdf_id ? wp_get_attachment_url( $pdf_id ) : '';
	$link        = get_post_meta( $post->ID, '_documento_link', true );
	$data        = get_post_meta( $post->ID, '_documento_data', true );
	$descrizione = get_post_meta( $post->ID, '_documento_descrizione', true );
	$assemblee   = get_terms( array( 'taxonomy' => 'documento_assemblea', 'hide_empty' => false ) );
	$assemblee   = is_wp_error( $assemblee ) ? array() : ptf_documenti_ordina_assemblee( $assemblee );
	$attuale     = wp_get_object_terms( $post->ID, 'documento_assemblea', array( 'fields' => 'ids' ) );
	$attuale     = ( ! is_wp_error( $attuale ) && $attuale ) ? (int) $attuale[0] : 0;
	?>
	<style>
		.ptf-doc-box { padding: 6px 2px; }
		.ptf-doc-aiuto { background: #f0f6fc; border-radius: 4px; padding: 10px 15px; margin-bottom: 20px; font-size: 14px; }
		.ptf-doc-riga { margin-bottom: 22px; }
		.ptf-doc-riga > label, .ptf-doc-titoletto { display: block; font-weight: 600; margin-bottom: 8px; font-size: 14px; }
		.ptf-doc-riga textarea { width: 100%; height: 90px; padding: 8px 10px; font-size: 14px; }
		.ptf-doc-riga select, .ptf-doc-riga input[type=url], .ptf-doc-riga input[type=text] { width: 100%; max-width: 480px; }
		.ptf-doc-sezioni label { display: inline-flex; align-items: center; gap: 6px; margin: 0 18px 6px 0; font-size: 14px; }
		.ptf-doc-nota { margin: 6px 0 0; color: #646970; font-size: 13px; }
		.ptf-doc-oppure { margin: 10px 0; color: #646970; font-size: 13px; }
		#ptf_documento_pdf_preview { display: block; margin-top: 8px; word-break: break-all; }
	</style>
	<div class="ptf-doc-box">
		<p class="ptf-doc-aiuto">💡 Scrivi il nome del documento nel campo in alto, scegli la sezione, carica il PDF e premi <strong>Pubblica</strong>. Il documento compare nella pagina della sezione, sotto <strong>Albo patriziale</strong>.</p>

		<div class="ptf-doc-riga">
			<span class="ptf-doc-titoletto">Sezione</span>
			<div class="ptf-doc-sezioni">
				<?php foreach ( $sezioni as $chiave => $dati ) : ?>
					<label><input type="radio" name="ptf_documento_sezione" value="<?php echo esc_attr( $chiave ); ?>" <?php checked( $sezione, $chiave ); ?> /> <?php echo esc_html( $dati['nome'] ); ?></label>
				<?php endforeach; ?>
			</div>
		</div>

		<div class="ptf-doc-riga" id="ptf_documento_riga_assemblea" <?php echo 'assemblee' === $sezione ? '' : 'style="display:none;"'; ?>>
			<label for="ptf_documento_assemblea">Assemblea</label>
			<select id="ptf_documento_assemblea" name="ptf_documento_assemblea">
				<option value="0">— scegli l'assemblea —</option>
				<?php foreach ( $assemblee as $assemblea ) : ?>
					<option value="<?php echo esc_attr( $assemblea->term_id ); ?>" <?php selected( $attuale, $assemblea->term_id ); ?>><?php echo esc_html( $assemblea->name ); ?></option>
				<?php endforeach; ?>
			</select>
			<p class="ptf-doc-oppure">oppure crea una nuova assemblea:</p>
			<input type="text" name="ptf_documento_assemblea_nuova" value="" placeholder="es. 1a Assemblea ordinaria 2027 – Aprile" />
			<p class="ptf-doc-nota">Tutti i documenti della stessa assemblea compaiono insieme, sotto il suo nome. La più recente sta in alto.</p>
		</div>

		<div class="ptf-doc-riga">
			<span class="ptf-doc-titoletto">File PDF</span>
			<input type="hidden" id="ptf_documento_pdf_id" name="ptf_documento_pdf_id" value="<?php echo esc_attr( $pdf_id ? $pdf_id : '' ); ?>" />
			<button type="button" class="button button-primary" id="ptf_documento_pdf_btn">Seleziona o carica PDF</button>
			<button type="button" class="button button-link-delete" id="ptf_documento_pdf_remove" <?php echo $pdf_id ? '' : 'style="display:none;"'; ?>>Rimuovi PDF</button>
			<span id="ptf_documento_pdf_preview">
				<?php if ( $pdf_url ) : ?>
					<a href="<?php echo esc_url( $pdf_url ); ?>" target="_blank" rel="noopener">Apri il PDF attuale (<?php echo esc_html( wp_basename( $pdf_url ) ); ?>)</a>
				<?php endif; ?>
			</span>
			<p class="ptf-doc-oppure">oppure, se il documento sta su un altro sito (es. il Cantone), incolla il link:</p>
			<input type="url" name="ptf_documento_link" value="<?php echo esc_attr( $link ); ?>" placeholder="https://…" />
		</div>

		<div class="ptf-doc-riga">
			<label for="ptf_documento_data">Data del documento (facoltativa)</label>
			<input type="date" id="ptf_documento_data" name="ptf_documento_data" value="<?php echo esc_attr( $data ); ?>" />
			<p class="ptf-doc-nota">Serve a mettere in ordine i documenti e, nei Concorsi, a scegliere l'anno. Se la lasci vuota vale la data di pubblicazione.</p>
		</div>

		<div class="ptf-doc-riga">
			<label for="ptf_documento_descrizione">Breve descrizione (facoltativa)</label>
			<textarea id="ptf_documento_descrizione" name="ptf_documento_descrizione" placeholder="es. Messaggio sul preventivo 2027"><?php echo esc_textarea( $descrizione ); ?></textarea>
		</div>
	</div>
	<script>
	jQuery( function ( $ ) {
		var frame;
		$( 'input[name="ptf_documento_sezione"]' ).on( 'change', function () {
			$( '#ptf_documento_riga_assemblea' ).toggle( 'assemblee' === this.value );
		} );
		$( '#ptf_documento_pdf_btn' ).on( 'click', function ( e ) {
			e.preventDefault();
			if ( frame ) { frame.open(); return; }
			frame = wp.media( {
				title: 'Seleziona il PDF',
				button: { text: 'Usa questo file' },
				multiple: false,
				library: { type: 'application/pdf' }
			} );
			frame.on( 'select', function () {
				var file = frame.state().get( 'selection' ).first().toJSON();
				$( '#ptf_documento_pdf_id' ).val( file.id );
				$( '#ptf_documento_pdf_preview' ).empty().append(
					$( '<a target="_blank" rel="noopener">' ).attr( 'href', file.url ).text( 'Apri il PDF attuale (' + file.filename + ')' )
				);
				$( '#ptf_documento_pdf_remove' ).show();
			} );
			frame.open();
		} );
		$( '#ptf_documento_pdf_remove' ).on( 'click', function ( e ) {
			e.preventDefault();
			$( '#ptf_documento_pdf_id' ).val( '' );
			$( '#ptf_documento_pdf_preview' ).empty();
			$( this ).hide();
		} );
	} );
	</script>
	<?php
}

/**
 * Salvataggio dei campi.
 *
 * @param int $post_id ID del documento.
 */
function ptf_documenti_salva( $post_id ) {
	if ( ! isset( $_POST['ptf_documento_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ptf_documento_nonce'] ) ), 'ptf_documento_salva' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( 'documento' !== get_post_type( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$sezione = isset( $_POST['ptf_documento_sezione'] ) ? sanitize_key( wp_unslash( $_POST['ptf_documento_sezione'] ) ) : '';
	if ( isset( ptf_documenti_sezioni()[ $sezione ] ) ) {
		update_post_meta( $post_id, '_documento_sezione', $sezione );
	} else {
		delete_post_meta( $post_id, '_documento_sezione' );
	}

	// Assemblea: una nuova scritta a mano vince sulla scelta dall'elenco.
	$assemblea = 0;
	if ( 'assemblee' === $sezione ) {
		$nuova = isset( $_POST['ptf_documento_assemblea_nuova'] ) ? sanitize_text_field( wp_unslash( $_POST['ptf_documento_assemblea_nuova'] ) ) : '';
		if ( '' !== $nuova && current_user_can( 'edit_posts' ) ) {
			$esiste = term_exists( $nuova, 'documento_assemblea' );
			if ( $esiste ) {
				$assemblea = (int) ( is_array( $esiste ) ? $esiste['term_id'] : $esiste );
			} else {
				$creata    = wp_insert_term( $nuova, 'documento_assemblea' );
				$assemblea = is_wp_error( $creata ) ? 0 : (int) $creata['term_id'];
			}
		} elseif ( ! empty( $_POST['ptf_documento_assemblea'] ) ) {
			$scelta    = absint( $_POST['ptf_documento_assemblea'] );
			$assemblea = term_exists( $scelta, 'documento_assemblea' ) ? $scelta : 0;
		}
	}
	wp_set_object_terms( $post_id, $assemblea ? array( $assemblea ) : array(), 'documento_assemblea', false );

	$pdf_id = isset( $_POST['ptf_documento_pdf_id'] ) ? absint( $_POST['ptf_documento_pdf_id'] ) : 0;
	if ( $pdf_id && 'application/pdf' === get_post_mime_type( $pdf_id ) ) {
		update_post_meta( $post_id, '_documento_pdf_id', $pdf_id );
	} else {
		delete_post_meta( $post_id, '_documento_pdf_id' );
	}

	$link = isset( $_POST['ptf_documento_link'] ) ? esc_url_raw( trim( wp_unslash( $_POST['ptf_documento_link'] ) ), array( 'http', 'https' ) ) : '';
	if ( '' !== $link ) {
		update_post_meta( $post_id, '_documento_link', $link );
	} else {
		delete_post_meta( $post_id, '_documento_link' );
	}

	$data = isset( $_POST['ptf_documento_data'] ) ? sanitize_text_field( wp_unslash( $_POST['ptf_documento_data'] ) ) : '';
	if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $data ) ) {
		update_post_meta( $post_id, '_documento_data', $data );
	} else {
		delete_post_meta( $post_id, '_documento_data' );
	}

	$descrizione = isset( $_POST['ptf_documento_descrizione'] ) ? sanitize_textarea_field( wp_unslash( $_POST['ptf_documento_descrizione'] ) ) : '';
	if ( '' !== $descrizione ) {
		update_post_meta( $post_id, '_documento_descrizione', $descrizione );
	} else {
		delete_post_meta( $post_id, '_documento_descrizione' );
	}
}
add_action( 'save_post', 'ptf_documenti_salva' );

/**
 * Libreria media per il pulsante «Seleziona o carica PDF».
 *
 * @param string $hook Schermata corrente.
 */
function ptf_documenti_admin_scripts( $hook ) {
	if ( in_array( $hook, array( 'post.php', 'post-new.php' ), true ) && 'documento' === get_current_screen()->post_type ) {
		wp_enqueue_media();
	}
}
add_action( 'admin_enqueue_scripts', 'ptf_documenti_admin_scripts' );

/**
 * Avvisi nell'editor: documento pubblicato ma che sul sito non si vede.
 */
function ptf_documenti_avvisi() {
	$screen = get_current_screen();
	if ( ! $screen || 'documento' !== $screen->post_type || 'post' !== $screen->base ) {
		return;
	}
	$post = get_post();
	if ( ! $post || 'publish' !== $post->post_status ) {
		return;
	}
	$manca = array();
	if ( ! ptf_documento_url( $post->ID ) ) {
		$manca[] = 'un PDF o un link';
	}
	if ( ! isset( ptf_documenti_sezioni()[ get_post_meta( $post->ID, '_documento_sezione', true ) ] ) ) {
		$manca[] = 'la sezione';
	}
	if ( $manca ) {
		echo '<div class="notice notice-warning"><p>Questo documento non compare sul sito finché non scegli ' . esc_html( implode( ' e ', $manca ) ) . '.</p></div>';
	}
}
add_action( 'admin_notices', 'ptf_documenti_avvisi' );

/**
 * Colonne dell'elenco nel pannello.
 *
 * @param array $columns Colonne.
 * @return array
 */
function ptf_documenti_colonne( $columns ) {
	return array(
		'cb'          => $columns['cb'],
		'title'       => 'Titolo',
		'ptf_sezione' => 'Sezione',
		'ptf_file'    => 'PDF o link',
		'ptf_data'    => 'Data del documento',
		'date'        => $columns['date'],
	);
}
add_filter( 'manage_documento_posts_columns', 'ptf_documenti_colonne' );

/**
 * Contenuto delle colonne.
 *
 * @param string $column  Colonna.
 * @param int    $post_id Documento.
 */
function ptf_documenti_colonna( $column, $post_id ) {
	if ( 'ptf_sezione' === $column ) {
		$sezioni = ptf_documenti_sezioni();
		$sezione = get_post_meta( $post_id, '_documento_sezione', true );
		if ( ! isset( $sezioni[ $sezione ] ) ) {
			echo '<span style="color:#b32d2e;">da scegliere</span>';
			return;
		}
		echo esc_html( $sezioni[ $sezione ]['nome'] );
		$assemblea = wp_get_object_terms( $post_id, 'documento_assemblea', array( 'fields' => 'names' ) );
		if ( 'assemblee' === $sezione && ! is_wp_error( $assemblea ) && $assemblea ) {
			echo '<br><span style="color:#646970;">' . esc_html( $assemblea[0] ) . '</span>';
		}
	}
	if ( 'ptf_file' === $column ) {
		$pdf_id = (int) get_post_meta( $post_id, '_documento_pdf_id', true );
		$link   = get_post_meta( $post_id, '_documento_link', true );
		if ( $pdf_id ) {
			echo esc_html( wp_basename( (string) wp_get_attachment_url( $pdf_id ) ) );
		} elseif ( $link ) {
			echo 'Link: ' . esc_html( wp_parse_url( $link, PHP_URL_HOST ) );
		} else {
			echo '<span style="color:#b32d2e;">manca</span>';
		}
	}
	if ( 'ptf_data' === $column ) {
		$data = get_post_meta( $post_id, '_documento_data', true );
		echo $data ? esc_html( wp_date( 'd.m.Y', strtotime( $data ) ) ) : '—';
	}
}
add_action( 'manage_documento_posts_custom_column', 'ptf_documenti_colonna', 10, 2 );

/**
 * Indirizzo da aprire: il PDF, altrimenti il link esterno.
 *
 * @param int $post_id Documento.
 * @return string URL, vuoto se manca.
 */
function ptf_documento_url( $post_id ) {
	$pdf_id = (int) get_post_meta( $post_id, '_documento_pdf_id', true );
	$url    = $pdf_id ? wp_get_attachment_url( $pdf_id ) : '';
	if ( ! $url ) {
		$url = (string) get_post_meta( $post_id, '_documento_link', true );
	}
	return $url ? $url : '';
}

/**
 * Data di riferimento del documento (AAAA-MM-GG HH:MM:SS) per ordinare e raggruppare.
 *
 * @param WP_Post $post Documento.
 * @return string
 */
function ptf_documento_data_riferimento( $post ) {
	$data = get_post_meta( $post->ID, '_documento_data', true );
	return $data ? $data . ' 00:00:00' : $post->post_date;
}

/**
 * Data mostrata per un documento: quella del documento o, se manca, quella di pubblicazione.
 *
 * @param int $post_id Documento.
 * @return string Data nel formato 23.08.2026.
 */
function ptf_documento_data_mostrata( $post_id ) {
	$data = get_post_meta( $post_id, '_documento_data', true );
	return $data ? wp_date( 'd.m.Y', strtotime( $data ) ) : get_the_date( 'd.m.Y', $post_id );
}

/**
 * Documenti pubblicati di una sezione che hanno un PDF o un link, dal più recente.
 *
 * @param string $sezione Chiave della sezione.
 * @return WP_Post[]
 */
function ptf_documenti_elenco( $sezione ) {
	$documenti = get_posts(
		array(
			'post_type'      => 'documento',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'meta_key'       => '_documento_sezione', // phpcs:ignore WordPress.DB.SlowDBQuery
			'meta_value'     => $sezione, // phpcs:ignore WordPress.DB.SlowDBQuery
		)
	);
	$documenti = array_values( array_filter( $documenti, static function ( $post ) {
		return '' !== ptf_documento_url( $post->ID );
	} ) );
	usort(
		$documenti,
		static function ( $a, $b ) {
			return strcmp( ptf_documento_data_riferimento( $b ), ptf_documento_data_riferimento( $a ) );
		}
	);
	return $documenti;
}

/**
 * Assemblee dalla più recente: anno scritto nel nome, poi l'ultima creata.
 *
 * @param WP_Term[] $assemblee Termini.
 * @return WP_Term[]
 */
function ptf_documenti_ordina_assemblee( $assemblee ) {
	usort(
		$assemblee,
		static function ( $a, $b ) {
			$anno_a = preg_match( '/\b(19|20)\d{2}\b/', $a->name, $m ) ? (int) $m[0] : 0;
			$anno_b = preg_match( '/\b(19|20)\d{2}\b/', $b->name, $m ) ? (int) $m[0] : 0;
			return $anno_a !== $anno_b ? $anno_b <=> $anno_a : $b->term_id <=> $a->term_id;
		}
	);
	return $assemblee;
}

/**
 * Documenti di una sezione divisi nei loro blocchi.
 *
 * - Regolamenti: un solo blocco senza titolo, in ordine alfabetico.
 * - Assemblee: un blocco per assemblea (la più recente in alto), documenti in ordine cronologico.
 * - Concorsi: un blocco per anno, dal più recente.
 *
 * @param string $sezione Chiave della sezione.
 * @return array[] Lista di array( 'titolo' => string, 'documenti' => WP_Post[] ).
 */
function ptf_documenti_gruppi( $sezione ) {
	$sezioni   = ptf_documenti_sezioni();
	$documenti = ptf_documenti_elenco( $sezione );
	if ( ! $documenti || ! isset( $sezioni[ $sezione ] ) ) {
		return array();
	}

	if ( 'nessuno' === $sezioni[ $sezione ]['gruppi'] ) {
		usort(
			$documenti,
			static function ( $a, $b ) {
				return strnatcasecmp( $a->post_title, $b->post_title );
			}
		);
		return array( array( 'titolo' => '', 'documenti' => $documenti ) );
	}

	$gruppi = array();
	foreach ( $documenti as $documento ) {
		if ( 'anno' === $sezioni[ $sezione ]['gruppi'] ) {
			$chiave = substr( ptf_documento_data_riferimento( $documento ), 0, 4 );
			$titolo = $chiave;
		} else {
			$termini = wp_get_object_terms( $documento->ID, 'documento_assemblea' );
			$termine = ( ! is_wp_error( $termini ) && $termini ) ? $termini[0] : null;
			$chiave  = $termine ? 't' . $termine->term_id : 'altri';
			$titolo  = $termine ? $termine->name : 'Altri documenti';
		}
		if ( ! isset( $gruppi[ $chiave ] ) ) {
			// I documenti arrivano dal più recente: il primo di ogni gruppo ne decide la posizione.
			$gruppi[ $chiave ] = array( 'titolo' => $titolo, 'documenti' => array() );
		}
		$gruppi[ $chiave ]['documenti'][] = $documento;
	}

	// Dentro un'assemblea i documenti seguono l'ordine dei lavori: dalla convocazione in poi.
	if ( 'assemblea' === $sezioni[ $sezione ]['gruppi'] ) {
		foreach ( $gruppi as $chiave => $gruppo ) {
			$gruppi[ $chiave ]['documenti'] = array_reverse( $gruppo['documenti'] );
		}
	}

	// «Altri documenti» (assemblea non scelta) sempre in fondo.
	if ( isset( $gruppi['altri'] ) ) {
		$altri = $gruppi['altri'];
		unset( $gruppi['altri'] );
		$gruppi['altri'] = $altri;
	}

	return array_values( $gruppi );
}

/**
 * Stampa i documenti di una sezione (usato da page-regolamenti-e-ordinanze.php,
 * page-assemblee.php e page-concorsi.php).
 *
 * @param string $sezione Chiave della sezione.
 */
function ptf_stampa_sezione_documenti( $sezione ) {
	$gruppi = ptf_documenti_gruppi( $sezione );
	if ( ! $gruppi ) {
		echo '<p class="ptf-documenti-vuoto">Nessun documento pubblicato al momento.</p>';
		return;
	}

	foreach ( $gruppi as $gruppo ) {
		echo '<section class="ptf-documenti-gruppo">';
		if ( '' !== $gruppo['titolo'] ) {
			echo '<h2 class="ptf-documenti-gruppo-titolo">' . esc_html( $gruppo['titolo'] ) . '</h2>';
		}
		echo '<ul class="ptf-documenti-lista">';
		foreach ( $gruppo['documenti'] as $documento ) {
			$url         = ptf_documento_url( $documento->ID );
			$e_pdf       = (bool) get_post_meta( $documento->ID, '_documento_pdf_id', true );
			$descrizione = get_post_meta( $documento->ID, '_documento_descrizione', true );
			$mostra_data = 'regolamenti' !== $sezione || get_post_meta( $documento->ID, '_documento_data', true );
			?>
			<li>
				<a class="ptf-documento" href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener">
					<span class="ptf-documento-icona" aria-hidden="true">
						<?php if ( $e_pdf ) : ?>
							<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" /></svg>
						<?php else : ?>
							<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M13.5 6H5.25A2.25 2.25 0 0 0 3 8.25v10.5A2.25 2.25 0 0 0 5.25 21h10.5A2.25 2.25 0 0 0 18 18.75V10.5m-10.5 6L21 3m0 0h-5.25M21 3v5.25" /></svg>
						<?php endif; ?>
					</span>
					<span class="ptf-documento-testo">
						<span class="ptf-documento-titolo"><?php echo esc_html( get_the_title( $documento ) ); ?></span>
						<?php if ( $mostra_data ) : ?>
							<span class="ptf-documento-data"><?php echo esc_html( ptf_documento_data_mostrata( $documento->ID ) ); ?></span>
						<?php endif; ?>
						<?php if ( $descrizione ) : ?>
							<span class="ptf-documento-descrizione"><?php echo esc_html( $descrizione ); ?></span>
						<?php endif; ?>
					</span>
					<span class="ptf-documento-azione"><?php echo $e_pdf ? 'Apri PDF' : 'Apri link'; ?><span class="screen-reader-text"> (si apre in una nuova scheda)</span> &rarr;</span>
				</a>
			</li>
			<?php
		}
		echo '</ul></section>';
	}
}

/**
 * Indirizzi da reindirizzare:
 * - la pagina del singolo documento porta al PDF o al link;
 * - /documenti/ (elenco unico della 1.9.0) porta all'Albo patriziale;
 * - la vecchia pagina /regolamento/ porta a Regolamenti e ordinanze, se esiste.
 */
function ptf_documenti_reindirizzi() {
	if ( is_singular( 'documento' ) ) {
		$url = ptf_documento_url( get_queried_object_id() );
		wp_redirect( $url ? $url : home_url( '/albo-patriziale/' ), 302 ); // phpcs:ignore WordPress.Security.SafeRedirect -- link esterni voluti, scritti da chi gestisce il sito.
		exit;
	}

	if ( is_404() ) {
		$percorso = trim( (string) wp_parse_url( add_query_arg( array() ), PHP_URL_PATH ), '/' );
		$base     = trim( (string) wp_parse_url( home_url(), PHP_URL_PATH ), '/' );
		if ( $base && 0 === strpos( $percorso, $base ) ) {
			$percorso = trim( substr( $percorso, strlen( $base ) ), '/' );
		}
		if ( 'documenti' === $percorso ) {
			wp_safe_redirect( home_url( '/albo-patriziale/' ), 301 );
			exit;
		}
	}

	if ( is_page( 'regolamento' ) && get_page_by_path( 'regolamenti-e-ordinanze' ) ) {
		wp_safe_redirect( home_url( '/regolamenti-e-ordinanze/' ), 301 );
		exit;
	}
}
add_action( 'template_redirect', 'ptf_documenti_reindirizzi' );

/**
 * Le pagine dei singoli documenti sono solo un rimando: fuori dalla sitemap.
 * Si somma alle esclusioni impostate in tW SEO.
 *
 * @param array $post_types Tipi di contenuto nella sitemap.
 * @return array
 */
function ptf_documenti_fuori_sitemap( $post_types ) {
	unset( $post_types['documento'] );
	return $post_types;
}
add_filter( 'wp_sitemaps_post_types', 'ptf_documenti_fuori_sitemap', 20 );

/**
 * CSS dell'elenco documenti, stampato solo nelle pagine delle sezioni.
 */
function ptf_documenti_css() {
	?>
	<style>
	.ptf-documenti { max-width: 900px; margin: var(--space-xl) auto; padding: 0 var(--space-md); }
	.ptf-documenti-intro { max-width: 700px; margin: 0 auto var(--space-xl) auto; text-align: center; font-size: 1.1rem; line-height: 1.7; color: var(--color-text-main); }
	.ptf-documenti-gruppo + .ptf-documenti-gruppo { margin-top: var(--space-xl); }
	.ptf-documenti-gruppo-titolo { margin: 0 0 var(--space-md) 0; font-family: var(--font-heading); font-size: clamp(1.3rem, 2.4vw, 1.7rem); line-height: 1.25; color: var(--color-primary-dark); }
	.ptf-documenti-lista { list-style: none; margin: 0; padding: 0; display: grid; gap: 12px; }
	.ptf-documento { display: flex; align-items: center; gap: var(--space-md); padding: 16px var(--space-md); background: var(--color-bg-pure-white); border: 1px solid rgba(0, 0, 0, 0.06); border-radius: var(--radius); box-shadow: 0 4px 15px rgba(0, 0, 0, 0.04); text-decoration: none; color: inherit; transition: transform 0.3s ease, box-shadow 0.3s ease; }
	.ptf-documento:hover, .ptf-documento:focus-visible { transform: translateY(-2px); box-shadow: 0 10px 25px rgba(22, 58, 138, 0.1); }
	.ptf-documento-icona { flex: 0 0 48px; height: 48px; display: flex; align-items: center; justify-content: center; border-radius: calc(var(--radius) - 4px); background: rgba(60, 105, 231, 0.07); color: var(--color-primary); }
	.ptf-documento-icona svg { width: 24px; height: 24px; }
	.ptf-documento-testo { flex: 1 1 auto; min-width: 0; display: flex; flex-direction: column; gap: 3px; }
	.ptf-documento-titolo { font-family: var(--font-heading); font-size: 1.08rem; font-weight: 600; line-height: 1.35; color: var(--color-primary-dark); overflow-wrap: anywhere; }
	.ptf-documento-data { font-size: 0.85rem; font-weight: 600; color: var(--color-text-light); }
	.ptf-documento-descrizione { font-size: 0.95rem; line-height: 1.55; color: var(--color-text-main); }
	.ptf-documento-azione { flex: 0 0 auto; font-weight: 700; font-size: 0.9rem; color: var(--color-primary); white-space: nowrap; }
	.ptf-documenti-vuoto { text-align: center; padding: var(--space-xxl) var(--space-md); background: var(--color-bg-pure-white); border-radius: var(--radius); color: var(--color-primary-light); font-size: 1.1rem; }
	.ptf-documenti-indietro { display: inline-block; margin-top: var(--space-xl); font-weight: 600; color: var(--color-primary); text-decoration: none; }
	html[data-theme="dark"] .ptf-documenti-gruppo-titolo, html[data-theme="dark"] .ptf-documento-titolo { color: var(--color-accent); }
	@media (max-width: 600px) {
		.ptf-documento { flex-wrap: wrap; }
		.ptf-documento-icona { flex-basis: 40px; height: 40px; }
		.ptf-documento-testo { flex-basis: calc(100% - 40px - var(--space-md)); }
		.ptf-documento-azione { flex-basis: 100%; text-align: right; }
	}
	</style>
	<?php
}

/**
 * Pagina completa di una sezione: intestazione, testo della pagina, documenti.
 *
 * @param string $sezione Chiave della sezione.
 */
function ptf_pagina_sezione_documenti( $sezione ) {
	$sezioni = ptf_documenti_sezioni();
	$dati    = $sezioni[ $sezione ];

	get_header();
	ptf_documenti_css();
	?>
	<div class="page-header-cinematic no-bg" style="background-color: var(--color-primary-dark);">
		<div class="page-header-overlay"></div>
		<div class="container page-header-inner animate-on-scroll">
			<h1 class="page-title"><?php single_post_title(); ?></h1>
			<p style="color: var(--color-accent); font-size: 1.5rem; font-weight: 500; font-family: var(--font-heading); margin-top: var(--space-sm);"><?php echo esc_html( $dati['sottotitolo'] ); ?></p>
		</div>
	</div>

	<main id="primary" class="site-main">
		<div class="ptf-documenti">
			<?php
			while ( have_posts() ) {
				the_post();
				if ( '' !== trim( (string) get_the_content() ) ) {
					echo '<div class="ptf-documenti-intro">';
					the_content();
					echo '</div>';
				}
			}
			ptf_stampa_sezione_documenti( $sezione );
			?>
			<a class="ptf-documenti-indietro" href="<?php echo esc_url( home_url( '/albo-patriziale/' ) ); ?>">&larr; Torna all'Albo patriziale</a>
		</div>
	</main>
	<?php
	get_footer();
}
