<?php
/**
 * Albo patriziale → Regolamenti e ordinanze (/regolamenti-e-ordinanze/).
 *
 * I documenti si caricano da Documenti → Aggiungi nuovo, sezione «Regolamenti e ordinanze».
 * Titolo e testo introduttivo sono quelli della pagina.
 *
 * @package Patriziato Frasco
 */

ptf_pagina_sezione_documenti( 'regolamenti' );
