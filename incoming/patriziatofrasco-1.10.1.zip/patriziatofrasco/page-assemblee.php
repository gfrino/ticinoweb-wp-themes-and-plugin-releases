<?php
/**
 * Albo patriziale → Assemblee (/assemblee/).
 *
 * I documenti si caricano da Documenti → Aggiungi nuovo, sezione «Assemblee».
 * Titolo e testo introduttivo sono quelli della pagina.
 *
 * @package Patriziato Frasco
 */

ptf_pagina_sezione_documenti( 'assemblee' );
