<?php
/**
 * Albo patriziale → Concorsi (/concorsi/).
 *
 * I documenti si caricano da Documenti → Aggiungi nuovo, sezione «Concorsi».
 * Titolo e testo introduttivo sono quelli della pagina.
 *
 * @package Patriziato Frasco
 */

ptf_pagina_sezione_documenti( 'concorsi' );
