<?php
/**
 * Template Name: ticinoWEB — Tipologia Sito Web
 *
 * THESIS: una pagina servizio deve mostrare struttura ed evoluzione, non ripetere liste identiche.
 * OWN-WORLD: carta calda, Ink, blu ticinoWEB, grandi crop e linee di processo.
 * STORY: comprendo l'offerta, verifico per chi è adatta, vedo cosa include e come nasce.
 * FIRST VIEWPORT: promessa commerciale a sinistra, visual CMS dominante a destra, CTA immediata.
 * FORM: editoriale svizzero in cinque macro-sezioni, unico per tutte le tipologie.
 *
 * @package ticinoWEB_Child_Theme
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$tw_data          = tw_web_services_get_data();
$tw_contact       = tw_home_mapped_url( 'page_contatti', 'contatti' );
$tw_primary       = $tw_data['hero_cta_url'] ?: $tw_contact;
$tw_final_url     = $tw_data['final_cta_url'] ?: $tw_contact;
$tw_has_intro     = '1' === ( $tw_data['show_intro'] ?? '1' );
$tw_has_audience  = '1' === ( $tw_data['show_audience'] ?? '1' ) && ! empty( $tw_data['audience'] );
$tw_has_includes  = '1' === ( $tw_data['show_includes'] ?? '1' ) && ! empty( $tw_data['includes'] );
$tw_has_growth    = '1' === ( $tw_data['show_growth'] ?? '1' ) && ! empty( $tw_data['features'] );
$tw_has_method    = '1' === ( $tw_data['show_process'] ?? '1' ) && ! empty( $tw_data['process'] );
$tw_hero_media_id = absint( $tw_data['hero_media_id'] ?? 0 );
$tw_is_food       = function_exists( 'tw_food_is_page' ) && tw_food_is_page();

get_header();
?>
<main class="tw-web-service tw-web-service--type<?php echo $tw_is_food ? ' tw-web-service--food' : ''; ?>">
	<section class="tw-web-hero tw-web-hero--service<?php echo $tw_hero_media_id ? ' has-media' : ' has-no-media'; ?>">
		<div class="tw-shell tw-web-hero__service-grid">
			<div class="tw-web-hero__copy">
				<p class="tw-kicker"><?php echo esc_html( $tw_data['hero_eyebrow'] ); ?></p>
				<h1><?php echo esc_html( $tw_data['hero_title'] ); ?></h1>
				<p class="tw-web-lead"><?php echo wp_kses_post( $tw_data['hero_text'] ); ?></p>
				<?php if ( $tw_data['hero_cta_text'] ) : ?><a class="tw-text-link" href="<?php echo esc_url( $tw_primary ); ?>"><?php echo esc_html( $tw_data['hero_cta_text'] ); ?> <span aria-hidden="true">↗</span></a><?php endif; ?>
			</div>
			<?php if ( $tw_hero_media_id ) tw_web_services_render_media( $tw_hero_media_id, 'hero', true ); ?>
				<?php if ( $tw_is_food && ! $tw_hero_media_id ) : ?><figure class="tw-food-hero-photo"><img src="<?php echo esc_url( tw_food_img( 'fd-order.webp' ) ); ?>" alt="<?php esc_attr_e( 'Una persona ordina online dal telefono', 'ticinoweb-child-theme' ); ?>" width="900" height="1350" decoding="async"></figure><?php endif; ?>
		</div>
	</section>

	<?php if ( $tw_is_food ) tw_food_band( 'fd-pizza.webp', __( 'Dal forno', 'ticinoweb-child-theme' ), __( 'Calda, appena sfornata, a casa tua', 'ticinoweb-child-theme' ), __( 'Il cliente ordina dal telefono, la cucina riceve l’ordine stampato e la pizza parte subito.', 'ticinoweb-child-theme' ), __( 'Pizza margherita con basilico e mozzarella', 'ticinoweb-child-theme' ), '30% 50%' ); ?>

	<?php if ( $tw_has_intro || $tw_has_audience ) : ?>
	<section class="tw-web-intro-audience">
		<div class="tw-shell tw-web-intro-audience__grid<?php echo $tw_has_intro && $tw_has_audience ? '' : ' is-single'; ?>">
			<?php if ( $tw_has_intro ) : ?>
			<div class="tw-web-intro-audience__intro">
				<p class="tw-kicker"><?php esc_html_e( 'In breve', 'ticinoweb-child-theme' ); ?></p>
				<h2><?php echo esc_html( $tw_data['intro_title'] ); ?></h2>
				<div class="tw-web-copy"><?php echo wp_kses_post( wpautop( $tw_data['intro_text'] ) ); ?></div>
				<?php tw_web_services_render_media( $tw_data['intro_media_id'] ?? 0, 'intro' ); ?>
			</div>
			<?php endif; ?>
			<?php if ( $tw_has_audience ) : ?>
			<div class="tw-web-audience">
				<p class="tw-kicker"><?php esc_html_e( 'Destinatari', 'ticinoweb-child-theme' ); ?></p>
				<h2><?php echo esc_html( $tw_data['audience_title'] ); ?></h2>
				<ol>
					<?php foreach ( $tw_data['audience'] as $tw_index => $tw_item ) : ?>
					<li><span><?php echo esc_html( $tw_item['number'] ?: str_pad( (string) ( $tw_index + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span><div><h3><?php echo esc_html( $tw_item['title'] ); ?></h3><?php echo wp_kses_post( wpautop( $tw_item['text'] ) ); ?></div></li>
					<?php endforeach; ?>
				</ol>
			</div>
			<?php endif; ?>
		</div>
	</section>
	<?php endif; ?>

	<?php if ( $tw_is_food ) tw_food_band( 'fd-salad.webp', __( 'Dalla cucina', 'ticinoweb-child-theme' ), __( 'Fresco, anche quando viaggia', 'ticinoweb-child-theme' ), __( 'Insalate, piatti caldi e menu del giorno: ogni piatto ha il suo posto nel catalogo online.', 'ticinoweb-child-theme' ), __( 'Insalata fresca che salta tra due palette di legno', 'ticinoweb-child-theme' ), '50% 40%' ); ?>

	<?php if ( $tw_has_includes || $tw_has_growth ) : ?>
	<section class="tw-web-offer">
		<?php if ( $tw_has_includes ) : ?>
		<div class="tw-shell tw-web-includes<?php echo empty( $tw_data['includes_media_id'] ) ? ' has-no-media' : ' has-media'; ?>">
			<header>
				<p class="tw-kicker"><?php esc_html_e( 'Struttura', 'ticinoweb-child-theme' ); ?></p>
				<h2><?php echo esc_html( $tw_data['includes_title'] ); ?></h2>
				<?php tw_web_services_render_media( $tw_data['includes_media_id'] ?? 0, 'includes' ); ?>
			</header>
			<ol class="tw-web-feature-list">
				<?php foreach ( $tw_data['includes'] as $tw_index => $tw_item ) : ?>
				<li><span><?php echo esc_html( $tw_item['number'] ?: str_pad( (string) ( $tw_index + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span><div><h3><?php echo esc_html( $tw_item['title'] ); ?></h3><?php echo wp_kses_post( wpautop( $tw_item['text'] ) ); ?></div></li>
				<?php endforeach; ?>
			</ol>
		</div>
		<?php endif; ?>

		<?php if ( $tw_has_growth ) : ?>
		<div class="tw-web-growth">
			<div class="tw-shell tw-web-growth__grid<?php echo empty( $tw_data['growth_media_id'] ) ? ' has-no-media' : ' has-media'; ?>">
				<header>
					<p class="tw-kicker"><?php esc_html_e( 'Evoluzione', 'ticinoweb-child-theme' ); ?></p>
					<h2><?php echo esc_html( $tw_data['features_title'] ); ?></h2>
					<?php echo wp_kses_post( wpautop( $tw_data['extras_text'] ?? '' ) ); ?>
					<?php tw_web_services_render_media( $tw_data['growth_media_id'] ?? 0, 'growth' ); ?>
				</header>
				<ol class="tw-web-growth__list">
					<?php foreach ( $tw_data['features'] as $tw_index => $tw_item ) : ?>
					<li><span><?php echo esc_html( $tw_item['number'] ?: str_pad( (string) ( $tw_index + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span><div><h3><?php echo esc_html( $tw_item['title'] ); ?></h3><?php echo wp_kses_post( wpautop( $tw_item['text'] ) ); ?></div></li>
					<?php endforeach; ?>
				</ol>
			</div>
		</div>
		<?php endif; ?>
	</section>
	<?php endif; ?>

	<?php if ( $tw_is_food ) tw_food_gallery(); ?>

	<?php if ( $tw_has_method ) : ?>
	<section class="tw-web-method" data-tw-web-method>
		<div class="tw-shell">
			<header class="tw-web-method__head<?php echo empty( $tw_data['method_media_id'] ) ? ' has-no-media' : ' has-media'; ?>">
				<div><p class="tw-kicker"><?php esc_html_e( 'Metodo', 'ticinoweb-child-theme' ); ?></p><h2><?php echo esc_html( $tw_data['process_title'] ); ?></h2></div>
				<?php tw_web_services_render_media( $tw_data['method_media_id'] ?? 0, 'method' ); ?>
			</header>
			<ol class="tw-web-method__timeline">
				<?php foreach ( $tw_data['process'] as $tw_index => $tw_item ) : ?>
				<li><span><?php echo esc_html( $tw_item['number'] ?: str_pad( (string) ( $tw_index + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span><h3><?php echo esc_html( $tw_item['title'] ); ?></h3><?php echo wp_kses_post( wpautop( $tw_item['text'] ) ); ?></li>
				<?php endforeach; ?>
			</ol>
		</div>
	</section>
	<?php endif; ?>

	<?php if ( '1' === ( $tw_data['show_faq'] ?? '0' ) && ! empty( $tw_data['faq_set_id'] ) && function_exists( 'ticinoweb_faq_render' ) ) : ?>
	<section class="tw-web-faq"><div class="tw-shell"><?php echo ticinoweb_faq_render( $tw_data['faq_set_id'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div></section>
	<?php endif; ?>

	<?php if ( '1' === ( $tw_data['show_final_cta'] ?? '1' ) ) : ?>
	<section class="tw-web-final-cta tw-web-final-cta--service">
		<div class="tw-shell tw-web-final-cta__service-grid">
			<div><p class="tw-kicker"><?php esc_html_e( 'Il prossimo passo', 'ticinoweb-child-theme' ); ?></p><h2><?php echo esc_html( $tw_data['final_cta_title'] ); ?></h2></div>
			<div><?php echo wp_kses_post( wpautop( $tw_data['final_cta_text'] ) ); ?><a class="tw-button" href="<?php echo esc_url( $tw_final_url ); ?>"><?php echo esc_html( $tw_data['final_cta_button'] ); ?> <span aria-hidden="true">↗</span></a></div>
		</div>
	</section>
	<?php endif; ?>
</main>
<?php get_footer(); ?>
