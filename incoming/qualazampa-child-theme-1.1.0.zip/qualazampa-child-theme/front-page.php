<?php
defined('ABSPATH') || exit;
get_header();
$departments=qz_departments();$products=qz_product_list((array)get_post_meta(get_queried_object_id(),'_qz_selection_ids',true),8);
$faq_id=get_post_meta(get_queried_object_id(),defined('TICINOWEB_FAQ_META_PAGE')?TICINOWEB_FAQ_META_PAGE:'_tw_faq_page_set',true);
?>
<main id="main-content">
<section class="qz-opening" data-opening>
    <div class="qz-opening__stage" data-opening-stage>
        <div class="qz-hero__photo" data-hero-photo><?php qz_photo(get_option('ticinoweb_slider_image_1'),'full',['loading'=>'eager','fetchpriority'=>'high','sizes'=>'(max-width: 760px) 100vw, 65vw']); ?></div>
        <div class="qz-hero__copy qz-container" data-hero-copy>
            <div class="qz-hero__copy-inner"><?php qz_title(qz_option('ticinoweb_slider_title_1'),'h1','qz-hero__title'); ?><p class="qz-hero__text"><?php echo esc_html(qz_option('ticinoweb_slider_desc_1')); ?></p>
            <div class="qz-actions"><a class="qz-button" href="<?php echo esc_url(ticinoweb_get_shop_url()); ?>"><?php echo esc_html(qz_option('ticinoweb_slider_btn_text_1')); ?><?php echo qz_icon(); ?></a><a class="qz-text-link" href="#i-loro-mondi"><?php esc_html_e('Trova il suo mondo','qualazampa'); ?><?php echo qz_icon('paw'); ?></a></div>
            <p class="qz-hero__note"><?php echo qz_icon('heart'); ?><?php echo esc_html(qz_home('hero_note')); ?></p></div>
        </div>
        <?php if($products): ?><div class="qz-hero__products" aria-label="<?php esc_attr_e('Idee dal negozio','qualazampa'); ?>" data-hero-products>
        <?php foreach(array_slice($products,0,3) as $index=>$hero_product): if(!$hero_product->get_image_id())continue; ?>
            <a class="qz-hero-product qz-hero-product--<?php echo esc_attr($index+1); ?>" data-hero-product href="<?php echo esc_url($hero_product->get_permalink()); ?>">
                <span class="qz-hero-product__image" aria-hidden="true"><?php echo wp_get_attachment_image($hero_product->get_image_id(),'full',false,['alt'=>'','loading'=>'eager','sizes'=>'(max-width: 760px) 30vw, 20vw']); ?></span>
                <span class="qz-hero-product__caption"><span><?php echo esc_html(preg_replace('/\s*\[[^\]]*\]\s*$/','',$hero_product->get_name())); ?></span><span class="qz-hero-product__price"><span><?php echo wp_kses_post($hero_product->get_price_html()); ?></span><?php echo qz_icon(); ?></span></span>
            </a>
        <?php endforeach; ?></div><?php endif; ?>
        <div class="qz-hero__stamp" aria-hidden="true"><?php echo qz_icon('paw'); ?></div>
        <div class="qz-hero__end" data-hero-end><?php qz_title(qz_option('ticinoweb_slider_title_2'),'h2'); ?><a class="qz-button qz-button--light" href="<?php echo esc_url(ticinoweb_get_shop_url()); ?>"><?php esc_html_e('Un pensiero per loro','qualazampa'); ?><?php echo qz_icon(); ?></a></div>
        <div class="qz-hero__bottom"><span><?php echo esc_html(qz_option('ticinoweb_slider_desc_2')); ?></span><a href="#i-loro-mondi" aria-label="<?php esc_attr_e('Scopri i reparti del negozio','qualazampa'); ?>"><?php echo qz_icon('arrow'); ?></a></div>
    </div>
</section>
<section class="qz-departments qz-section" id="i-loro-mondi" data-chapter="departments" data-worlds>
    <span class="qz-worlds__overview-anchor" id="reparti-completi" aria-hidden="true"></span>
    <div class="qz-worlds__stage" data-worlds-stage><div class="qz-container">
    <div class="qz-section-heading"><?php qz_title(qz_home('categories_title')); ?><p><?php echo esc_html(qz_home('categories_text')); ?></p></div><a class="qz-worlds__skip qz-text-link" href="#reparti-completi"><?php esc_html_e('Vedi tutti i reparti','qualazampa'); ?><?php echo qz_icon(); ?></a>
    <div class="qz-animals"><?php if(!is_wp_error($departments))foreach($departments as $term): ?>
        <a class="qz-animal" data-animal href="<?php echo esc_url(get_term_link($term)); ?>">
            <span class="qz-animal__image" aria-hidden="true"><?php $id=get_term_meta($term->term_id,'thumbnail_id',true);if($id)qz_photo($id,'large',['alt'=>'']);else echo qz_icon(get_term_meta($term->term_id,'_qz_icon',true)?:'paw'); ?></span>
            <span class="qz-animal__label"><span class="qz-animal__name"><?php echo esc_html($term->name); ?><?php echo qz_icon(); ?></span><span class="qz-animal__count"><?php /* translators: %s: Number of products in this department. */ echo esc_html(sprintf(_n('%s prodotto','%s prodotti',$term->count,'qualazampa'),number_format_i18n($term->count))); ?></span></span>
            <span class="qz-animal__story"><strong><?php echo esc_html(ucfirst(strtolower($term->name))); ?></strong><span class="qz-animal__description"><?php echo esc_html(wp_trim_words(wp_strip_all_tags($term->description),26)); ?></span><span class="qz-text-link"><?php esc_html_e('Scopri il reparto','qualazampa'); ?><?php echo qz_icon(); ?></span></span>
        </a>
    <?php endforeach; ?></div>
    </div></div>
</section>
<span data-flow-marker="selection" aria-hidden="true"></span><section class="qz-selection qz-section" data-chapter="selection"><div class="qz-container"><div class="qz-section-heading qz-section-heading--split"><div><?php qz_title(qz_home('selection_title')); ?><p><?php echo esc_html(qz_home('selection_text')); ?></p></div><a class="qz-text-link" href="<?php echo esc_url(ticinoweb_get_shop_url()); ?>"><?php esc_html_e('Tutti i prodotti','qualazampa'); ?><?php echo qz_icon(); ?></a></div><?php qz_product_grid($products); ?></div></section>
<section class="qz-cuddle" data-cuddle><div class="qz-cuddle__stage"><div class="qz-cuddle__photo"><?php qz_photo(get_option('ticinoweb_slider_image_2'),'full',['sizes'=>'100vw']); ?></div><div class="qz-cuddle__copy"><?php echo qz_icon('heart'); qz_title(qz_home('scene_title')); ?><p><?php echo esc_html(qz_home('scene_text')); ?></p><a class="qz-button qz-button--light" href="<?php echo esc_url(qz_home('scene_link')); ?>"><?php esc_html_e('Scopri i prodotti per gatti','qualazampa'); ?><?php echo qz_icon(); ?></a></div></div></section>
<section class="qz-brands qz-section"><div class="qz-container"><div class="qz-section-heading qz-section-heading--split"><?php qz_title(qz_home('brands_title')); ?><a class="qz-text-link" href="<?php echo esc_url(qz_home('brands_url')); ?>"><?php esc_html_e('Esplora le marche','qualazampa'); ?><?php echo qz_icon(); ?></a></div><div class="qz-brand-line"><?php $partners=min(24,(int)get_option('ticinoweb_partner_count',0)); for($i=1;$i<=$partners;$i++):$logo=get_option('ticinoweb_partner_logo_'.$i);$url=get_option('ticinoweb_partner_link_'.$i);if(!$logo)continue;$params=[];wp_parse_str((string)wp_parse_url($url,PHP_URL_QUERY),$params);$brand=!empty($params['qz_brand'])?get_term(absint($params['qz_brand']),'pa_marche'):null;$brand_name=$brand&&!is_wp_error($brand)?$brand->name:get_the_title(attachment_url_to_postid($logo));?><a aria-label="<?php echo esc_attr($brand_name); ?>" href="<?php echo esc_url($url?:qz_home('brands_url')); ?>"><?php qz_photo($logo,'medium',['alt'=>'']); ?></a><?php endfor; ?></div></div></section>
<span data-flow-marker="story" aria-hidden="true"></span><section class="qz-story qz-section" data-chapter="story"><div class="qz-container qz-story__layout"><div class="qz-story__photo"><?php qz_photo(get_option('ticinoweb_chi_siamo_image'),'large'); ?><span class="qz-story__heart" aria-hidden="true"><?php echo qz_icon('heart'); ?></span></div><div class="qz-story__copy"><?php qz_title(qz_option('ticinoweb_chi_siamo_title')); ?><p><?php echo nl2br(esc_html(qz_option('ticinoweb_chi_siamo_text'))); ?></p><a class="qz-text-link" href="<?php echo esc_url(get_option('ticinoweb_chi_siamo_link')); ?>"><?php esc_html_e('Facciamo conoscenza','qualazampa'); ?><?php echo qz_icon(); ?></a></div></div></section>
<?php $news=get_posts(['post_type'=>'post','post_status'=>'publish','numberposts'=>3]);if($news): ?><section class="qz-news qz-section" data-chapter="news"><div class="qz-container"><div class="qz-section-heading"><?php qz_title(qz_home('news_title')); ?></div><div class="qz-news__grid"><?php foreach($news as $item): ?><article><a class="qz-news__photo" href="<?php echo esc_url(get_permalink($item)); ?>"><?php echo get_the_post_thumbnail($item,'large',['loading'=>'lazy']); ?></a><p class="qz-news__date"><?php echo esc_html(get_the_date('', $item)); ?></p><h3><a href="<?php echo esc_url(get_permalink($item)); ?>"><?php echo esc_html(get_the_title($item)); ?></a></h3><a class="qz-text-link" href="<?php echo esc_url(get_permalink($item)); ?>"><?php esc_html_e('Scopri di più','qualazampa'); ?><?php echo qz_icon(); ?></a></article><?php endforeach; ?></div></div></section><?php endif; ?>
<section class="qz-store qz-section" data-chapter="store"><div class="qz-container qz-store__layout"><div><?php echo qz_icon('pin'); qz_title(qz_home('store_title')); ?><p><?php echo esc_html(qz_home('store_text')); ?></p><address><?php echo esc_html(qz_option('ticinoweb_contact_address')); ?></address><a class="qz-button" href="<?php echo esc_url(qz_home('contact_url')); ?>"><?php esc_html_e('Vieni a trovarci','qualazampa'); ?><?php echo qz_icon(); ?></a></div><div><h3><?php esc_html_e('Quando ci trovi','qualazampa'); ?></h3><?php qz_hours(); ?></div></div></section>
<?php if($faq_id): ?><section class="qz-faq qz-section"><div class="qz-container"><?php echo ticinoweb_faq_render($faq_id); ?></div></section><?php endif; ?>
</main><?php get_footer(); ?>
