(() => {
  'use strict';
  const opening=document.querySelector('[data-opening]');
  if(!opening)return;
  const stage=opening.querySelector('[data-opening-stage]');
  const photo=opening.querySelector('[data-hero-photo]');
  const copy=opening.querySelector('[data-hero-copy]');
  const end=opening.querySelector('[data-hero-end]');
  const products=[...opening.querySelectorAll('[data-hero-product]')];
  const productGroup=opening.querySelector('[data-hero-products]');
  const stamp=opening.querySelector('.qz-hero__stamp');
  const departments=document.querySelector('[data-chapter="departments"]');
  const selection=document.querySelector('[data-chapter="selection"]');
  const animals=[...document.querySelectorAll('[data-animal]')].map(link=>({link,image:link.querySelector('.qz-animal__image'),label:link.querySelector('.qz-animal__label'),story:link.querySelector('.qz-animal__story')}));
  const worldsStage=document.querySelector('[data-worlds-stage]');
  const worldsHeading=departments?.querySelector('.qz-section-heading');
  const animalLandscape=departments?.querySelector('.qz-animals');
  const cuddle=document.querySelector('[data-cuddle]');
  const story=document.querySelector('[data-chapter="story"]');
  const news=document.querySelector('[data-chapter="news"]');
  const stackPanels=[selection,story,news].filter(Boolean);
  const reduced=matchMedia('(prefers-reduced-motion:reduce)');
  const desktop=matchMedia('(min-width:981px) and (min-height:800px)');
  const clamp=v=>Math.max(0,Math.min(1,v));
  const range=(a,b,v)=>clamp((v-a)/(b-a));
  const smooth=(a,b,v)=>{const n=range(a,b,v);return n*n*(3-2*n);};
  const round=v=>Number(v.toFixed(3));
  let lenis=null,frame=0,dirty=true,immersive=false,lastY=-1,geometry=null;
  const placed=el=>{const r=el.getBoundingClientRect();return {top:r.top+scrollY,height:r.height};};
  const flow=(el,name)=>{const marker=document.querySelector(`[data-flow-marker="${name}"]`);return marker?{top:marker.getBoundingClientRect().top+scrollY+(parseFloat(getComputedStyle(el).marginTop)||0),height:el.offsetHeight}:placed(el);};
  function measure(){
    // All geometry reads are grouped here, never interleaved with scroll-frame writes.
    const header=document.querySelector('[data-header]')?.offsetHeight||0;
    const sw=stage.offsetWidth,sh=stage.offsetHeight;
    const pw=photo.offsetWidth,ph=photo.offsetHeight;
    geometry={header,viewport:innerHeight,opening:placed(opening),
      travel:Math.max(1,opening.offsetHeight-sh),
      photoX:sw/2-photo.offsetLeft-pw/2,photoY:sh/2-photo.offsetTop-ph/2,
      photoScale:Math.max(sw/Math.max(1,pw),sh/Math.max(1,ph))*1.22,
      worldWidth:animalLandscape?.offsetWidth||1,animalWidth:animals[0]?.link.offsetWidth||1,worldStageHeight:worldsStage?.offsetHeight||1,
      departments:departments?placed(departments):null,
      selection:selection?flow(selection,'selection'):null,cuddle:cuddle?placed(cuddle):null,
      story:story?flow(story,'story'):null};
    const fits=stackPanels.map(el=>el.offsetHeight<=innerHeight-header);
    stackPanels.forEach((el,i)=>el.toggleAttribute('data-stack-fit',fits[i]));
    dirty=false;
  }
  function reset(){
    [photo,copy,end,stamp,productGroup,...products].forEach(el=>el?.removeAttribute('style'));
    opening.style.removeProperty('--shade');
    [departments,selection,cuddle,story].forEach(el=>el?.removeAttribute('style'));
    stackPanels.forEach(el=>el.removeAttribute('data-stack-fit'));
    if(productGroup)productGroup.inert=false;
    animals.forEach(a=>{[a.link,a.image,a.label,a.story].forEach(el=>el?.removeAttribute('style'));a.link.inert=false;});
    worldsHeading?.removeAttribute('style');if(worldsHeading)worldsHeading.inert=false;
    copy.inert=false;end.inert=true;
  }
  function configure(){
    lenis?.destroy();lenis=null;
    immersive=desktop.matches&&!reduced.matches;
    opening.toggleAttribute('data-immersive',immersive);
    document.documentElement.toggleAttribute('data-qz-motion',immersive);
    reset();dirty=true;lastY=-1;
    if(immersive&&typeof Lenis==='function'){
      lenis=new Lenis({lerp:.105,smoothWheel:true,syncTouch:false,autoRaf:false,
        anchors:false});
    }
    wake();
  }
  function paint(y){
    const g=geometry;
    const p=clamp((y+g.header-g.opening.top)/g.travel);
    const camera=smooth(0,.8,p),exit=smooth(.06,.36,p),arrival=smooth(.4,.68,p);
    photo.style.transform=`translate3d(${round(g.photoX*camera)}px,${round(g.photoY*camera)}px,0) scale(${round(1+(g.photoScale-1)*camera)})`;
    opening.style.setProperty('--shade',round(arrival*.95));
    copy.style.transform=`translate3d(${round(-40*exit)}px,${round(-65*exit)}px,0)`;
    copy.style.opacity=1-exit;
    copy.inert=exit>.95;
    end.style.opacity=arrival;
    end.style.transform=`translate3d(0,${round(45*(1-arrival))}px,0)`;
    end.inert=arrival<.6;
    const packExit=smooth(.13,.33,p),lift=smooth(0,.38,p);
    // The window leaves as one composition; products retain their baseline and hierarchy.
    if(productGroup){
      productGroup.style.transform=`translate3d(0,${round(65*lift)}px,0)`;
      productGroup.style.opacity=1-packExit;
      productGroup.inert=packExit>.94;
    }
    if(stamp){stamp.style.transform=`translate3d(0,${round(-80*lift)}px,0) rotate(${round(15+65*lift)}deg)`;stamp.style.opacity=1-packExit;}
    // One portrait at a time, then the same portraits fan into the eight departments.
    if(g.departments&&animals.length){
      const wp=clamp((y+g.header-g.departments.top)/Math.max(1,g.departments.height-g.worldStageHeight));
      const tour=range(0,.7,wp)*(animals.length-1),resolve=smooth(.7,.88,wp);
      const mainX=g.worldWidth*.24-g.animalWidth/2;
      const gap=(g.worldWidth-animals.length*g.animalWidth)/Math.max(1,animals.length-1);
      const headingOut=smooth(.02,.1,wp)*(1-smooth(.74,.88,wp));
      if(worldsHeading){worldsHeading.style.opacity=1-headingOut;worldsHeading.style.transform=`scale(${round(1+.18*headingOut)})`;worldsHeading.inert=headingOut>.9;}
      animals.forEach((animal,i)=>{
        const delta=i-tour;
        const weight=1-smooth(0,1,Math.abs(delta));
        const sceneX=resolve>0?mainX+(i-(animals.length-1))*24:mainX+delta*g.worldWidth*.6;
        const x=sceneX*(1-resolve)+i*(g.animalWidth+gap)*resolve;
        const yy=(160-75*headingOut)*(1-resolve)+105*resolve;
        const opacity=weight+(1-weight)*resolve;
        animal.link.style.transform=`translate3d(${round(x)}px,${round(yy)}px,0)`;
        animal.link.style.opacity=round(opacity);
        animal.link.style.zIndex=String(Math.round(weight*10));
        animal.link.inert=opacity<.15;
        animal.image.style.transform=`scale(${round((1+1.55*weight)*(1-resolve)+resolve)})`;
        animal.label.style.opacity=resolve;
        animal.story.style.opacity=round(weight*(1-resolve));
        animal.story.style.transform=`translate3d(${round(25*(1-weight))}px,0,0)`;
        animal.story.style.visibility=weight*(1-resolve)<.02?'hidden':'visible';
      });
    }
    if(g.selection){
      const entry=smooth(0,1,(y+g.viewport-g.selection.top)/(g.viewport*.7));
      selection.style.setProperty('--chapter-y',`${round(40*(1-entry))}px`);
    }
    if(g.cuddle){
      const c=clamp((y+g.viewport-g.cuddle.top)/(g.cuddle.height+g.viewport));
      cuddle.style.setProperty('--cuddle-y',`${round(65*(.5-c))}px`);
      cuddle.style.setProperty('--cuddle-scale',round(1.035+.055*c));
      cuddle.style.setProperty('--cuddle-x',`${round(65*(1-smooth(.08,.45,c)))}px`);
    }
    if(g.story){
      const s=smooth(0,1,(y+g.viewport-g.story.top)/(g.story.height+g.viewport*.4));
      story.style.setProperty('--story-photo-y',`${round(40*(1-s))}px`);
      story.style.setProperty('--story-copy-y',`${round(-25*(1-s))}px`);
      story.style.setProperty('--story-rotate',`${round(-2*(1-s))}deg`);
    }
  }
  function render(time){
    frame=0;
    if(document.hidden)return;
    lenis?.raf(time);
    if(immersive){
      if(dirty)measure();
      const y=window.scrollY;
      if(y!==lastY){paint(y);lastY=y;}
    }
    // One clock drives the wheel and scene; no second easing chasing the scroll.
    if(lenis?.isScrolling)wake();
  }
  function wake(){if(!frame&&!document.hidden)frame=requestAnimationFrame(render);}
  addEventListener('scroll',wake,{passive:true});
  addEventListener('wheel',wake,{passive:true});
  document.addEventListener('click',event=>{
    if(!lenis||event.defaultPrevented||event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;
    const link=event.target.closest('a[href]');
    if(!link||link.target==='_blank')return;
    const url=new URL(link.href,location.href);
    if(url.origin!==location.origin||url.pathname!==location.pathname||!url.hash)return;
    let target;try{target=document.getElementById(decodeURIComponent(url.hash.slice(1)));}catch{return;}
    if(!target)return;
    event.preventDefault();
    const padding=parseFloat(getComputedStyle(document.documentElement).scrollPaddingTop)||0;
    const targetY=target.getBoundingClientRect().top+window.scrollY-padding;
    history.pushState(history.state,'',url.hash);
    lenis.scrollTo(targetY);
    wake();
  });
  // Keyboard users retain the ordinary document flow when cards would overlap focus.
  document.addEventListener('keydown',event=>{if(event.key==='Tab'){document.documentElement.setAttribute('data-qz-keyboard','');dirty=true;lastY=-1;wake();}});
  document.addEventListener('pointerdown',()=>{document.documentElement.removeAttribute('data-qz-keyboard');dirty=true;lastY=-1;wake();},{passive:true});
  addEventListener('resize',()=>{dirty=true;lastY=-1;wake();},{passive:true});
  reduced.addEventListener('change',configure);desktop.addEventListener('change',configure);
  document.addEventListener('visibilitychange',()=>{
    if(document.hidden){cancelAnimationFrame(frame);frame=0;}
    else{dirty=true;lastY=-1;wake();}
  });
  if(typeof ResizeObserver==='function'){
    const observer=new ResizeObserver(()=>{dirty=true;lastY=-1;wake();});
    [stage,document.querySelector('[data-header]'),departments,selection,cuddle,story,news].filter(Boolean).forEach(el=>observer.observe(el));
  }
  document.fonts?.ready.then(()=>{dirty=true;lastY=-1;wake();});
  configure();
})();
