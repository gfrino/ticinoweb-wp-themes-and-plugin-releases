/* Datatrans by ticinoWEB – order page: refund amount prefilled with what is
 * still refundable and capped there (the server refuses more anyway). */
( function ( $ ) {
	var data = window.twDatatransRefund || {};
	var max = parseFloat( data.available );
	if ( isNaN( max ) ) {
		return;
	}
	var $amount = $( '#refund_amount' );
	if ( ! $amount.length ) {
		return;
	}
	var decimals = parseInt( data.decimals, 10 ) || 2;
	var format = function ( n ) { return n.toFixed( decimals ); };

	$amount.attr( { max: format( max ), min: '0' } );

	// Prefill when the refund panel opens and the field is still empty.
	$( document ).on( 'click', 'button.refund-items', function () {
		setTimeout( function () {
			if ( ! $amount.val() ) {
				$amount.val( format( max ) ).trigger( 'change' );
			}
		}, 50 );
	} );

	// Never above the refundable total (also after WooCommerce fills it from the items).
	$amount.on( 'change blur', function () {
		var v = parseFloat( String( $amount.val() ).replace( ',', '.' ) );
		if ( ! isNaN( v ) && v > max ) {
			$amount.val( format( max ) ).trigger( 'change' );
			window.alert( data.message || '' );
		}
	} );
} )( jQuery );
