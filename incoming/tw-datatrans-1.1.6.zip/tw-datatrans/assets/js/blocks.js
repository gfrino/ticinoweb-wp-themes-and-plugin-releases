/* Datatrans by ticinoWEB – block checkout registration (no build step). */
( function () {
	if ( ! window.wc || ! wc.wcBlocksRegistry || ! wc.wcSettings ) {
		return;
	}
	var el = wp.element.createElement;
	var decode = wp.htmlEntities && wp.htmlEntities.decodeEntities ? wp.htmlEntities.decodeEntities : function ( s ) { return s; };
	var ids = [ 'tw_datatrans_twint', 'tw_datatrans_card', 'tw_datatrans_applepay', 'tw_datatrans_googlepay' ];

	ids.forEach( function ( id ) {
		var data = wc.wcSettings.getSetting( id + '_data', null );
		if ( ! data ) {
			return;
		}
		var title = decode( data.title || id );
		var label = el( 'span', { style: { display: 'flex', alignItems: 'center', gap: '8px' } },
			data.icon ? el( 'img', { src: data.icon, alt: '', style: { height: '24px', width: 'auto' } } ) : null,
			el( 'span', null, title )
		);
		var content = data.description ? el( 'div', { className: 'tw-datatrans-description' }, decode( data.description ) ) : el( 'div' );
		wc.wcBlocksRegistry.registerPaymentMethod( {
			name: id,
			label: label,
			content: content,
			edit: content,
			canMakePayment: function () { return true; },
			ariaLabel: title,
			supports: { features: data.supports || [ 'products' ] }
		} );
	} );
} )();
