<?php
/**
 * Block checkout support: one integration per gateway, all served by the
 * same small script (assets/js/blocks.js, no build step).
 */

defined( 'ABSPATH' ) || exit;

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class TW_Datatrans_Blocks extends AbstractPaymentMethodType {

	/** @var TW_Datatrans_Gateway|null */
	private $gateway = null;

	public function __construct( $id ) {
		$this->name = $id;
	}

	public function initialize() {
		$this->settings = get_option( 'woocommerce_' . $this->name . '_settings', array() );
		$gateways       = WC()->payment_gateways()->payment_gateways();
		$this->gateway  = $gateways[ $this->name ] ?? null;
	}

	public function is_active() {
		return $this->gateway ? $this->gateway->is_available() : false;
	}

	public function get_payment_method_script_handles() {
		$handle = 'tw-datatrans-blocks';
		if ( ! wp_script_is( $handle, 'registered' ) ) {
			wp_register_script(
				$handle,
				TW_DATATRANS_URL . 'assets/js/blocks.js',
				array( 'wc-blocks-registry', 'wc-settings', 'wp-element', 'wp-html-entities' ),
				TW_DATATRANS_VERSION,
				true
			);
		}
		return array( $handle );
	}

	public function get_payment_method_data() {
		return array(
			'title'       => $this->gateway ? $this->gateway->get_title() : $this->name,
			'description' => $this->gateway ? $this->gateway->get_description() : '',
			'icon'        => $this->gateway ? $this->gateway->icon : '',
			'supports'    => array( 'products', 'refunds' ),
		);
	}
}
