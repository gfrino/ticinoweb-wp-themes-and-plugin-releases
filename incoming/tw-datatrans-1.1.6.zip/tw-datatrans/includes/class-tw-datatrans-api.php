<?php
/**
 * Datatrans Transactions API v2 client (https://api-reference.datatrans.ch/json/).
 * Redirect integration: init → send the customer to the Datatrans payment
 * page → webhook + status check → credit for refunds.
 */

defined( 'ABSPATH' ) || exit;

class TW_Datatrans_API {

	/** Statuses that mean the customer has paid (autoSettle on: settled right away). */
	const PAID_STATUSES = array( 'authorized', 'settled', 'transmitted' );

	public static function api_host() {
		return TW_Datatrans_Settings::is_sandbox() ? 'https://api.sandbox.datatrans.com' : 'https://api.datatrans.com';
	}

	public static function pay_host() {
		return TW_Datatrans_Settings::is_sandbox() ? 'https://pay.sandbox.datatrans.com' : 'https://pay.datatrans.com';
	}

	/** Payment page URL for a transaction (same as the Location header of the init call, verified 2026-11-07). */
	public static function start_url( $transaction_id ) {
		return self::pay_host() . '/upp/v1/start/' . rawurlencode( $transaction_id );
	}

	private static function request( $method, $path, $body = null ) {
		list( $merchant, $password ) = TW_Datatrans_Settings::credentials();
		if ( '' === $merchant || '' === $password ) {
			return new WP_Error( 'tw_datatrans_unconfigured', __( 'Datatrans credentials are missing (WooCommerce → Datatrans).', 'tw-datatrans' ) );
		}
		$args = array(
			'method'  => $method,
			'timeout' => 30,
			'headers' => array(
				'Authorization' => 'Basic ' . base64_encode( $merchant . ':' . $password ),
				'Content-Type'  => 'application/json',
				'Accept'        => 'application/json',
			),
		);
		if ( null !== $body ) {
			$args['body'] = wp_json_encode( $body );
		}
		$response = wp_remote_request( self::api_host() . $path, $args );
		if ( is_wp_error( $response ) ) {
			tw_datatrans_log( array( 'request' => $method . ' ' . $path, 'error' => $response->get_error_message() ), 'error' );
			return new WP_Error( 'tw_datatrans_http', sprintf( __( 'Datatrans could not be reached: %s', 'tw-datatrans' ), $response->get_error_message() ) );
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		$raw  = (string) wp_remote_retrieve_body( $response );
		$data = json_decode( $raw, true );
		tw_datatrans_log( array( 'request' => $method . ' ' . $path, 'status' => $code, 'body' => self::redact( $data ) ) );
		if ( $code >= 400 || ! is_array( $data ) ) {
			$msg = is_array( $data ) && ! empty( $data['error']['message'] ) ? (string) $data['error']['message'] : sprintf( __( 'HTTP %d', 'tw-datatrans' ), $code );
			$err = new WP_Error( 'tw_datatrans_api', $msg, array( 'status' => $code, 'code' => $data['error']['code'] ?? '' ) );
			if ( $code >= 500 || 401 === $code ) {
				tw_datatrans_log( array( 'request' => $method . ' ' . $path, 'status' => $code, 'body' => $raw ), 'error' );
			}
			return $err;
		}
		$data['_location'] = (string) wp_remote_retrieve_header( $response, 'location' );
		return $data;
	}

	/** Never log card aliases. */
	private static function redact( $data ) {
		if ( is_array( $data ) ) {
			foreach ( $data as $k => $v ) {
				$data[ $k ] = ( 'alias' === $k ) ? '[redacted]' : self::redact( $v );
			}
		}
		return $data;
	}

	/**
	 * POST /v2/transactions → ['transactionId' => …, '_location' => payment page].
	 * Validity: 30 minutes.
	 */
	public static function init( array $body ) {
		return self::request( 'POST', '/v2/transactions', $body );
	}

	/** GET /v2/transactions/{id} */
	public static function status( $transaction_id ) {
		return self::request( 'GET', '/v2/transactions/' . rawurlencode( $transaction_id ) );
	}

	/** POST /v2/transactions/{id}/credit (refund, full or partial). */
	public static function credit( $transaction_id, $amount_cents, $currency, $refno ) {
		return self::request(
			'POST',
			'/v2/transactions/' . rawurlencode( $transaction_id ) . '/credit',
			array( 'currency' => $currency, 'refno' => $refno, 'amount' => (int) $amount_cents )
		);
	}

	/**
	 * Credentials check without creating anything: a status call for a
	 * transaction that cannot exist. 401 = wrong credentials; 400/404 =
	 * credentials accepted.
	 */
	public static function check_credentials() {
		$result = self::request( 'GET', '/v2/transactions/00000000-0000-0000-0000-000000000000' );
		if ( ! is_wp_error( $result ) ) {
			return array( 'ok' => true, 'message' => __( 'Credentials accepted by Datatrans.', 'tw-datatrans' ) );
		}
		$status = (int) ( $result->get_error_data()['status'] ?? 0 );
		if ( in_array( $status, array( 400, 404, 422 ), true ) ) {
			return array( 'ok' => true, 'message' => __( 'Credentials accepted by Datatrans.', 'tw-datatrans' ) );
		}
		if ( 401 === $status || 403 === $status ) {
			return array( 'ok' => false, 'message' => __( 'Datatrans refused the merchant ID or password.', 'tw-datatrans' ) );
		}
		return array( 'ok' => false, 'message' => $result->get_error_message() );
	}

	public static function is_paid_status( $status ) {
		return in_array( (string) $status, self::PAID_STATUSES, true );
	}

	/**
	 * Verifies `Datatrans-Signature: t=<ms>,s0=<hex>`: s0 = HMAC-SHA256
	 * (key = hex-decoded signing key, data = t + raw body).
	 */
	public static function verify_signature( $header, $raw_body, $hex_key ) {
		$parts = array();
		foreach ( explode( ',', (string) $header ) as $p ) {
			$kv = explode( '=', trim( $p ), 2 );
			if ( 2 === count( $kv ) ) {
				$parts[ $kv[0] ] = $kv[1];
			}
		}
		if ( empty( $parts['t'] ) || empty( $parts['s0'] ) || '' === $hex_key ) {
			return false;
		}
		$expected = hash_hmac( 'sha256', $parts['t'] . $raw_body, hex2bin( $hex_key ) );
		return hash_equals( $expected, strtolower( $parts['s0'] ) );
	}
}
