<?php
/**
 * Removes the plugin's options only if the admin chose so in WooCommerce →
 * Datatrans → "Delete these settings when the plugin is deleted". Order meta
 * (transaction ids) is never touched: it is part of the order history.
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

$tw_datatrans_settings = get_option( 'tw_datatrans_settings', array() );
if ( is_array( $tw_datatrans_settings ) && ( $tw_datatrans_settings['remove_on_uninstall'] ?? 'no' ) === 'yes' ) {
	delete_option( 'tw_datatrans_settings' );
	foreach ( array( 'twint', 'card', 'applepay', 'googlepay' ) as $tw_datatrans_method ) {
		delete_option( 'woocommerce_tw_datatrans_' . $tw_datatrans_method . '_settings' );
	}
}
