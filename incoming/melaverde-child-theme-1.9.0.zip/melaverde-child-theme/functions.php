<?php
/**
 * Mela Verde Child Theme functions and definitions
 *
 * @link https://developer.wordpress.org/themes/advanced-topics/child-themes/
 */

require get_stylesheet_directory() . '/inc/customizer.php';
require get_stylesheet_directory() . '/inc/footer.php';

add_action( 'wp_enqueue_scripts', 'melaverde_child_enqueue_styles' );
function melaverde_child_enqueue_styles() {
    // Carica il CSS del parent theme
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
    
    // Carica il CSS del child theme
    wp_enqueue_style( 'child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array( 'parent-style' ),
        wp_get_theme()->get('Version')
    );
    
    // ==============================================
    // LIBRERIE ESTERNE (SWIPER & GSAP)
    // ==============================================
    if ( is_front_page() || is_home() ) {
        // Swiper JS & CSS
        // Librerie ospitate sul sito (assets/lib): niente CDN di terzi. Swiper MIT, GSAP licenza standard GreenSock.
        $lib = get_stylesheet_directory_uri() . '/assets/lib';
        wp_enqueue_style( 'swiper-style', $lib . '/swiper/swiper-bundle.min.css', array(), '11.2.10' );
        wp_enqueue_script( 'swiper-js', $lib . '/swiper/swiper-bundle.min.js', array(), '11.2.10', true );
        
        // GSAP Core & ScrollTrigger
        wp_enqueue_script( 'gsap-js', $lib . '/gsap/gsap.min.js', array(), '3.12.2', true );
        wp_enqueue_script( 'gsap-scrolltrigger-js', $lib . '/gsap/ScrollTrigger.min.js', array('gsap-js'), '3.12.2', true );

        // Modulo contatti della home → gestore invii del parent (Invii Ricevuti + email).
        wp_enqueue_script(
            'melaverde-contact-form',
            get_stylesheet_directory_uri() . '/assets/js/contact-form.js',
            array( 'ticinoweb-ai-main' ),
            wp_get_theme()->get( 'Version' ),
            true
        );
        
        // Custom Apple-style GSAP Animations
        // We output the script inline in WP footer or directly inside front-page for simplicity 
        // to avoid creating new files if not strictly necessary, but let's enqueue an inline script later if needed.
        // For now we just load the libraries.
    }
}

// ==============================================================================
// AGGIUNGI SOTTO LE TUE FUNZIONI PERSONALIZZATE (HOOKS, FILTRI, SHORTCODES, ECC)
// ==============================================================================

add_action('wp_head', 'melaverde_child_custom_fonts_and_tailwind');

// Tailwind compilato (assets/css/tailwind.css, sorgente in tools/tailwind): stampato in fondo
// all'<head>, dove prima il CDN inseriva i suoi stili, per tenere lo stesso ordine delle regole.
add_action( 'wp_head', 'melaverde_tailwind_css', 999 );
function melaverde_tailwind_css() {
    $ver = wp_get_theme()->get( 'Version' ); // cache-buster: la versione del tema sale a ogni rilascio
    echo '<link rel="stylesheet" id="melaverde-tailwind-css" href="' . esc_url( get_stylesheet_directory_uri() . '/assets/css/tailwind.css?ver=' . $ver ) . '">' . "\n";
}
function melaverde_child_custom_fonts_and_tailwind() {
        ?>
        <?php // Font ospitati sul sito (assets/fonts): niente richieste a Google prima del consenso. ?>
        <link rel="preload" href="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/fonts/nunito-sans-latin.woff2' ); ?>" as="font" type="font/woff2" crossorigin>
        <link rel="preload" href="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/fonts/literata-latin.woff2' ); ?>" as="font" type="font/woff2" crossorigin>
        <link rel="stylesheet" href="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/fonts/fonts.css?ver=' . wp_get_theme()->get( 'Version' ) ); ?>">
        <style>
            body { font-family: 'Nunito Sans', sans-serif; background-color: #faf6f0; color: #2e3230; line-height: 1.6; }
            h1, h2, h3, h4, h5, h6 { font-family: 'Literata', serif; }
            .soft-shadow { box-shadow: 0 4px 20px rgba(46, 50, 48, 0.06); }
            /* Hide parent theme header and footer specific for the Tailwind frontpage */
            body.home .site-header, body.home .site-footer { display: none !important; }
            /* Properly space standard WordPress paragraphs injected via the_content() */
            body.home .leading-relaxed p { margin-bottom: 1.5rem; }
        </style>
        <?php
}

add_filter( 'body_class', 'melaverde_child_body_classes' );
function melaverde_child_body_classes( $classes ) {
    $classes[] = 'bg-background';
    $classes[] = 'text-on-background';
    $classes[] = 'antialiased';
    $classes[] = 'pt-20';
    return $classes;
}


// ==============================================================================
// PRIVACY: NIENTE RICHIESTE A GOOGLE FONTS
// Il parent carica Poppins da fonts.googleapis.com e apre due preconnect verso Google
// su ogni pagina: l'IP del visitatore arriva a Google prima di qualsiasi consenso.
// Questo sito usa solo font ospitati in assets/fonts, quindi li togliamo qui (solo Mela Verde).
// ==============================================================================

add_action( 'wp_enqueue_scripts', 'melaverde_no_google_fonts', 20 );
function melaverde_no_google_fonts() {
    // ticinoweb-ai-style dipende da poppins-font: lo si sostituisce con un handle vuoto
    // invece di toglierlo, così la dipendenza resta valida e non si stampa nulla.
    wp_deregister_style( 'poppins-font' );
    wp_register_style( 'poppins-font', false, array(), null );
}

add_action( 'wp_head', 'melaverde_remove_parent_google_preconnect', -100 );
function melaverde_remove_parent_google_preconnect() {
    global $wp_filter;
    if ( empty( $wp_filter['wp_head'] ) || empty( $wp_filter['wp_head']->callbacks[0] ) ) {
        return;
    }
    $parent_functions = wp_normalize_path( get_template_directory() . '/functions.php' );
    foreach ( $wp_filter['wp_head']->callbacks[0] as $callback ) {
        if ( ! ( $callback['function'] instanceof Closure ) ) {
            continue;
        }
        $ref = new ReflectionFunction( $callback['function'] );
        // Solo la closure del parent che stampa i preconnect verso fonts.googleapis.com.
        if ( wp_normalize_path( (string) $ref->getFileName() ) === $parent_functions ) {
            $lines = file( $parent_functions );
            $body  = implode( '', array_slice( (array) $lines, $ref->getStartLine() - 1, $ref->getEndLine() - $ref->getStartLine() + 1 ) );
            if ( strpos( $body, 'fonts.googleapis.com' ) !== false ) {
                remove_action( 'wp_head', $callback['function'], 0 );
            }
        }
    }
}

// Banner cookie del parent nei font e nei colori del sito (prima ereditava Poppins).
add_action( 'wp_head', 'melaverde_cookie_banner_style', 100 );
function melaverde_cookie_banner_style() {
    ?>
    <style id="melaverde-cookie-banner">
        body { --tw-cookie-primary: #4a7c59; }
        body .tw-cookie-banner, body .tw-cookie-banner button, body .tw-cookie-btn, body .tw-cookie-modal, body .tw-cookie-modal button { font-family: 'Nunito Sans', sans-serif; }
    </style>
    <?php
}

// Emoji di WordPress: lo script scarica le immagini da s.w.org (server esterno).
// Le emoji restano visibili con i caratteri del sistema del visitatore.
add_action( 'init', 'melaverde_disable_emojis' );
function melaverde_disable_emojis() {
    remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
    remove_action( 'wp_print_styles', 'print_emoji_styles' );
    remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
    remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
    remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
    add_filter( 'emoji_svg_url', '__return_false' );
}
