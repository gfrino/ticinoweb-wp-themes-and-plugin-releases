<?php
if (!defined('ABSPATH')) {
    exit;
}

/** Motore di sincronizzazione: release GitHub → prodotti WooCommerce. */
class Twss_Sync {
    const HOOK = 'twss_sync';
    const LOCK = 'twss_lock';

    public static function cron() {
        self::run();
    }

    /**
     * @param array $args dry (bool), force (bool: rilegge tutte le release), slug (string), reprocess (bool)
     * @return array|WP_Error righe {slug, version, action, notes}
     */
    public static function run($args = array()) {
        $args = array_merge(array('dry' => false, 'force' => false, 'slug' => '', 'reprocess' => false), $args);
        if (!class_exists('WooCommerce')) {
            return new WP_Error('twss_wc', 'WooCommerce non è attivo.');
        }
        if (get_transient(self::LOCK)) {
            return new WP_Error('twss_lock', 'Un’altra sincronizzazione è in corso.');
        }
        set_transient(self::LOCK, 1, 10 * MINUTE_IN_SECONDS);
        try {
            $rows = self::process($args);
        } finally {
            delete_transient(self::LOCK);
        }
        return $rows;
    }

    /** Aggiorna banner e storico delle versioni di tutti i prodotti, senza scaricare gli zip né toccare i testi. */
    public static function refresh() {
        $latest = Twss_Github::latest_by_slug(true);
        if (is_wp_error($latest)) {
            return $latest;
        }
        $done = array();
        foreach (Twss_Settings::state() as $slug => $st) {
            if (!isset($st['type']) || 'plugin' !== $st['type'] || empty($st['product_id']) || empty($latest[$slug])) {
                continue;
            }
            $raw = Twss_Github::raw('details/' . $slug . '/details.json');
            $details = $raw ? json_decode($raw, true) : array();
            Twss_Product::refresh_extras((int) $st['product_id'], $slug, $latest[$slug]['history'], is_array($details) ? $details : array());
            $done[] = array('slug' => $slug, 'versions' => count($latest[$slug]['history']), 'banner' => get_post_meta($st['product_id'], '_twss_banner_id', true));
        }
        return $done;
    }

    private static function process($args) {
        $state = Twss_Settings::state();
        $latest = Twss_Github::latest_by_slug($args['force'] || !$state);
        if (is_wp_error($latest)) {
            Twss_Settings::log('', $latest->get_error_message(), 'error');
            return $latest;
        }
        $rows = array();
        if (null === $latest) {
            return $rows; // nulla di nuovo su GitHub
        }
        $excluded = Twss_Settings::excluded_slugs();
        foreach ($latest as $slug => $rel) {
            if ($args['slug'] && $args['slug'] !== $slug) {
                continue;
            }
            $st = isset($state[$slug]) ? $state[$slug] : array();
            $type = isset($st['type']) ? $st['type'] : '';
            if ('theme' === $type || 'skip' === $type) {
                continue; // i temi non vanno mai nel negozio
            }
            if (!$args['reprocess'] && isset($st['version']) && version_compare($st['version'], $rel['version'], '>=') && ('plugin' !== $type || Twss_Product::find($slug))) {
                continue;
            }
            if (in_array(strtolower($slug), $excluded, true)) {
                $state[$slug] = array('type' => 'skip', 'version' => $rel['version'], 'why' => 'escluso');
                continue;
            }
            if ($rel['zip_size'] > Twss_Github::MAX_ZIP) {
                $state[$slug] = array('type' => 'skip', 'version' => $rel['version'], 'why' => 'zip oltre 20 MB');
                $rows[] = array('slug' => $slug, 'version' => $rel['version'], 'action' => 'skip', 'notes' => 'zip oltre 20 MB (tema)');
                continue;
            }
            $row = self::one($slug, $rel, $args['dry']);
            $rows[] = $row;
            if (!$args['dry'] && 'error' !== $row['action']) {
                $state[$slug] = array_merge($st, $row['state']);
            }
            unset($rows[count($rows) - 1]['state']);
        }
        if (!$args['dry']) {
            Twss_Settings::save_state($state);
            foreach ($rows as $r) {
                if ('skip' !== $r['action']) {
                    Twss_Settings::log($r['slug'], $r['version'] . ': ' . $r['action'] . ' — ' . $r['notes'], 'error' === $r['action'] ? 'error' : 'info');
                }
            }
        }
        return $rows;
    }

    private static function one($slug, $rel, $dry) {
        $base = array('slug' => $slug, 'version' => $rel['version']);
        $tmp = Twss_Github::download($rel['zip_url']);
        if (is_wp_error($tmp)) {
            return $base + array('action' => 'error', 'notes' => $tmp->get_error_message());
        }
        try {
            $pkg = Twss_Package::inspect($tmp, $slug);
            if ('plugin' !== $pkg['type']) {
                return $base + array('action' => 'skip', 'notes' => 'non è un plugin (' . $pkg['type'] . ')',
                    'state' => array('type' => 'theme' === $pkg['type'] ? 'theme' : 'skip', 'version' => $rel['version']));
            }
            $raw = Twss_Github::raw('details/' . $slug . '/details.json');
            $details = $raw ? json_decode($raw, true) : array();
            $details = is_array($details) ? $details : array();
            if (isset($details['shop']) && false === $details['shop']) {
                return $base + array('action' => 'skip', 'notes' => 'details.json: "shop": false',
                    'state' => array('type' => 'skip', 'version' => $rel['version'], 'why' => 'shop:false'));
            }
            $res = Twss_Product::upsert($slug, $rel, $pkg, $details, $tmp, $dry);
        } finally {
            @unlink($tmp); // phpcs:ignore WordPress.PHP.NoSilencedErrors
        }
        return $base + array('action' => $res['action'], 'notes' => implode(', ', $res['notes']),
            'state' => array('type' => 'plugin', 'version' => $rel['version'], 'product_id' => $res['id'], 'synced' => time()));
    }
}
