<?php
if (!defined('ABSPATH')) {
    exit;
}

/** Scheda prodotto dei plugin: banner in testa e storico delle versioni (changelog con date). */
class Twss_Frontend {
    public static function init() {
        add_action('woocommerce_before_single_product', array(__CLASS__, 'banner'), 5);
        add_action('woocommerce_after_single_product_summary', array(__CLASS__, 'changelog'), 12);
    }

    private static function is_ours($id) {
        return (bool) get_post_meta($id, '_twss_slug', true) && (bool) get_post_meta($id, '_twss_version', true);
    }

    public static function banner() {
        global $product;
        if (!$product || !self::is_ours($product->get_id())) {
            return;
        }
        $att = (int) get_post_meta($product->get_id(), '_twss_banner_id', true);
        if ($att) {
            echo '<figure class="twss-hero">' . wp_get_attachment_image($att, 'full', false, array('alt' => $product->get_name(), 'loading' => 'eager', 'decoding' => 'async')) . '</figure>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }
    }

    public static function changelog() {
        global $product;
        if (!$product || !self::is_ours($product->get_id())) {
            return;
        }
        $id = $product->get_id();
        $history = get_post_meta($id, '_twss_history', true);
        $compat = get_post_meta($id, '_twss_compat', true);
        echo '<section class="twss-changelog" aria-labelledby="twss-changelog-title"><div class="twss-changelog__head"><p class="twss-kicker">' . esc_html__('Versioni', 'ticinoweb-child-theme') . '</p><h2 id="twss-changelog-title">' . esc_html__('Changelog', 'ticinoweb-child-theme') . '</h2>';
        echo '<p>' . esc_html__('Licenza perpetua: si paga una volta sola, nessun canone annuale.', 'ticinoweb-child-theme') . '</p>';
        if (is_array($compat) && $compat) {
            echo '<ul class="twss-compat">';
            foreach ($compat as $k => $v) {
                /* translators: 1: software (WordPress, PHP…), 2: minimum version */
                echo '<li>' . esc_html(sprintf(__('%1$s %2$s o successivo', 'ticinoweb-child-theme'), $k, $v)) . '</li>';
            }
            echo '</ul>';
        }
        echo '</div><ol class="twss-timeline">';
        if (!is_array($history) || !$history) {
            $history = array(array('version' => get_post_meta($id, '_twss_version', true), 'date' => get_post_meta($id, '_twss_released', true), 'html' => get_post_meta($id, '_twss_changelog', true)));
        }
        foreach ($history as $i => $row) {
            $ts = strtotime($row['date']);
            echo '<li class="twss-release' . (0 === $i ? ' is-latest' : '') . '"><div class="twss-release__meta"><span class="twss-release__ver">' . esc_html($row['version']) . '</span>';
            if ($ts) {
                echo '<time datetime="' . esc_attr(gmdate('Y-m-d', $ts)) . '">' . esc_html(wp_date(get_option('date_format'), $ts)) . '</time>';
            }
            if (0 === $i) {
                echo '<span class="twss-release__tag">' . esc_html__('Ultima versione', 'ticinoweb-child-theme') . '</span>';
            }
            echo '</div><div class="twss-release__body">' . wp_kses_post($row['html']) . '</div></li>';
        }
        echo '</ol></section>';
    }
}
