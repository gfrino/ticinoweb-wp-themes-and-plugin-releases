<?php
/**
 * Footer del Liceo Diocesano: invito a contattare la scuola su foto scura, poi contatti e link.
 * Dati letti dal CMS del parent (contatti, social, privacy) e dal menu principale.
 *
 * @package liceo-diocesano-child
 */
$c        = ticinoweb_get_contact_info();
$yt       = get_option( 'ticinoweb_contact_youtube', '' );
$privacy  = function_exists( 'get_privacy_policy_url' ) ? get_privacy_policy_url() : '';
$register = liceo_diocesano_page_url( 'iscrizione' );
$contacts = liceo_diocesano_page_url( 'indirizzo_contatti' );
$menu_top = array();
$locs     = get_nav_menu_locations();
if ( ! empty( $locs['primary'] ) ) {
    foreach ( (array) wp_get_nav_menu_items( $locs['primary'] ) as $it ) {
        if ( ! (int) $it->menu_item_parent ) {
            $menu_top[] = $it;
        }
    }
}
$social = array(
    'Facebook'  => array( $c['facebook'], 'M24 12.07C24 5.44 18.63.07 12 .07S0 5.44 0 12.07c0 5.99 4.39 10.95 10.13 11.85v-8.38H7.08v-3.47h3.05V9.43c0-3.01 1.79-4.67 4.53-4.67 1.31 0 2.69.23 2.69.23v2.95h-1.51c-1.49 0-1.96.93-1.96 1.87v2.25h3.33l-.53 3.47h-2.8v8.38C19.61 23.03 24 18.06 24 12.07z' ),
    'Instagram' => array( $c['instagram'], 'M12 2.16c3.2 0 3.58.01 4.85.07 3.25.15 4.77 1.69 4.92 4.92.06 1.27.07 1.65.07 4.85s-.01 3.58-.07 4.85c-.15 3.23-1.66 4.77-4.92 4.92-1.27.06-1.64.07-4.85.07s-3.58-.01-4.85-.07c-3.26-.15-4.77-1.7-4.92-4.92C2.17 15.58 2.16 15.2 2.16 12s.01-3.58.07-4.85C2.38 3.92 3.9 2.38 7.15 2.23 8.42 2.17 8.8 2.16 12 2.16zM12 0C8.74 0 8.33.01 7.05.07 2.7.27.27 2.69.07 7.05.01 8.33 0 8.74 0 12s.01 3.67.07 4.95c.2 4.36 2.62 6.78 6.98 6.98C8.33 23.99 8.74 24 12 24s3.67-.01 4.95-.07c4.35-.2 6.78-2.62 6.98-6.98.06-1.28.07-1.69.07-4.95s-.01-3.67-.07-4.95c-.2-4.35-2.62-6.78-6.98-6.98C15.67.01 15.26 0 12 0zm0 5.84a6.16 6.16 0 100 12.32 6.16 6.16 0 000-12.32zM12 16a4 4 0 110-8 4 4 0 010 8zm6.41-11.85a1.44 1.44 0 100 2.88 1.44 1.44 0 000-2.88z' ),
    'YouTube'   => array( $yt, 'M23.5 6.2a3 3 0 00-2.1-2.1C19.5 3.6 12 3.6 12 3.6s-7.5 0-9.4.5A3 3 0 00.5 6.2C0 8.1 0 12 0 12s0 3.9.5 5.8a3 3 0 002.1 2.1c1.9.5 9.4.5 9.4.5s7.5 0 9.4-.5a3 3 0 002.1-2.1c.5-1.9.5-5.8.5-5.8s0-3.9-.5-5.8zM9.6 15.6V8.4l6.2 3.6-6.2 3.6z' ),
);
$cta_bg = liceo_diocesano_upload_url( '2025/10/3-mod.png' );
?>
<footer class="ld-footer" id="contatti">
    <div class="ld-footer__wrap">
        <section class="ld-footer__cta" style="background-image:url(<?php echo esc_url( $cta_bg ); ?>)">
            <div class="ld-footer__cta-in">
                <span class="ld-pill ld-pill--light"><?php esc_html_e( 'Iscrizioni e informazioni', 'liceo-diocesano-child' ); ?></span>
                <h2><?php esc_html_e( 'Vieni a conoscere il Liceo Diocesano', 'liceo-diocesano-child' ); ?></h2>
                <p><?php esc_html_e( 'Il primo passo è un colloquio con la Direzione. Scrivici o chiamaci: ti raccontiamo la scuola e i suoi percorsi.', 'liceo-diocesano-child' ); ?></p>
                <div class="ld-footer__cta-btns">
                    <?php if ( $register ) : ?>
                        <a class="ld-btn-light" href="<?php echo esc_url( $register ); ?>"><?php esc_html_e( 'Info e iscrizioni', 'liceo-diocesano-child' ); ?></a>
                    <?php endif; ?>
                    <?php if ( ! empty( $c['phone'] ) ) : ?>
                        <a class="ld-btn-ghost" href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $c['phone'] ) ); ?>"><?php echo esc_html( $c['phone'] ); ?></a>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <div class="ld-footer__main">
            <div class="ld-footer__brand">
                <h3><?php echo esc_html( get_bloginfo( 'name' ) ); ?></h3>
                <p><?php echo esc_html( get_bloginfo( 'description' ) ); ?></p>
                <div class="ld-footer__social">
                    <?php foreach ( $social as $name => $n ) : if ( empty( $n[0] ) ) { continue; } ?>
                        <a href="<?php echo esc_url( $n[0] ); ?>" target="_blank" rel="noopener" aria-label="<?php echo esc_attr( $name ); ?>"><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="<?php echo esc_attr( $n[1] ); ?>"/></svg></a>
                    <?php endforeach; ?>
                </div>
            </div>

            <?php if ( $menu_top ) : ?>
            <nav class="ld-footer__col" aria-label="<?php esc_attr_e( 'Link utili', 'liceo-diocesano-child' ); ?>">
                <h4><?php esc_html_e( 'Link utili', 'liceo-diocesano-child' ); ?></h4>
                <ul>
                    <?php foreach ( $menu_top as $it ) : ?>
                        <li><a href="<?php echo esc_url( $it->url ); ?>"><?php echo esc_html( $it->title ); ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </nav>
            <?php endif; ?>

            <div class="ld-footer__col">
                <h4><?php esc_html_e( 'Contatti', 'liceo-diocesano-child' ); ?></h4>
                <ul>
                    <?php if ( ! empty( $c['address'] ) ) : ?><li><?php echo esc_html( $c['address'] ); ?></li><?php endif; ?>
                    <?php if ( ! empty( $c['phone'] ) ) : ?><li><a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $c['phone'] ) ); ?>"><?php echo esc_html( $c['phone'] ); ?></a></li><?php endif; ?>
                    <?php foreach ( array( 'email' => 'Segreteria', 'email_2' => 'Direzione', 'email_3' => 'Amministrazione' ) as $k => $label ) : if ( empty( $c[ $k ] ) ) { continue; } ?>
                        <li><span class="ld-footer__label"><?php echo esc_html( $label ); ?></span><a href="mailto:<?php echo esc_attr( $c[ $k ] ); ?>"><?php echo esc_html( $c[ $k ] ); ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>

        <div class="ld-footer__bottom">
            <span>© <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php echo esc_html( get_bloginfo( 'name' ) ); ?></span>
            <span class="ld-footer__legal">
                <?php if ( $privacy ) : ?><a href="<?php echo esc_url( $privacy ); ?>"><?php esc_html_e( 'Privacy', 'liceo-diocesano-child' ); ?></a><?php endif; ?>
                <a href="<?php echo esc_url( admin_url() ); ?>"><?php esc_html_e( 'Backend', 'liceo-diocesano-child' ); ?></a>
                <span>Design by <a href="https://ticinoweb.com" target="_blank" rel="noopener">ticinoWEB</a></span>
            </span>
        </div>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
