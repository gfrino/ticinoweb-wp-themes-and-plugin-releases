( function () {
    var root = document.querySelector( '.ldo' );
    var frame = root && root.querySelector( '.ldo-viewer iframe' );
    if ( ! frame ) { return; }
    var pdf = frame.getAttribute( 'data-pdf' );
    var chips = root.querySelectorAll( '.ldo-chip' );
    var open = root.querySelector( '[data-ldo-open]' );
    chips.forEach( function ( chip ) {
        chip.addEventListener( 'click', function () {
            var page = chip.getAttribute( 'data-page' );
            chips.forEach( function ( c ) { c.classList.toggle( 'is-on', c === chip ); c.setAttribute( 'aria-pressed', c === chip ? 'true' : 'false' ); } );
            // Nuovo indirizzo ad ogni scelta, così il visualizzatore PDF cambia pagina in ogni browser.
            frame.src = pdf + '?c=' + encodeURIComponent( chip.textContent.trim() ) + '#page=' + page + '&view=FitH';
            if ( open ) { open.href = pdf + '#page=' + page; }
        } );
    } );
    if ( open ) { open.href = pdf + '#page=' + chips[ 0 ].getAttribute( 'data-page' ); }
} )();
