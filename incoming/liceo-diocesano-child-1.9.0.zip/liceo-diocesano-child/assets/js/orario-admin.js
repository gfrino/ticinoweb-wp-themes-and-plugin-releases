( function ( $ ) {
    var cfg = window.ldOrario || {};

    function nextIndex( $tbl ) {
        var max = -1;
        $tbl.find( 'tbody tr' ).each( function () { max = Math.max( max, parseInt( $( this ).data( 'i' ), 10 ) || 0 ); } );
        return max + 1;
    }
    $( 'table.ldo-rows tbody tr' ).each( function ( i ) { $( this ).attr( 'data-i', i ); } );

    var templates = {
        classes: function ( i ) {
            return '<tr data-i="' + i + '"><td><input type="text" name="classes[' + i + '][name]" placeholder="1A"></td>' +
                '<td><input type="number" min="1" name="classes[' + i + '][page]" value="1"></td>' +
                '<td><button type="button" class="button-link-delete ldo-del">Elimina</button></td></tr>';
        },
        bells: function ( i ) {
            return '<tr data-i="' + i + '"><td><input type="text" name="bells[' + i + '][label]" placeholder="1"></td>' +
                '<td><input type="text" name="bells[' + i + '][from]" placeholder="8:05"></td>' +
                '<td><input type="text" name="bells[' + i + '][to]" placeholder="8:50"></td>' +
                '<td><button type="button" class="button-link-delete ldo-del">Elimina</button></td></tr>';
        },
        docs: function ( i ) {
            return '<tr data-i="' + i + '"><td><input type="text" name="docs[' + i + '][title]" placeholder="Orario insegnanti"></td>' +
                '<td><span class="ldo-file"><input type="hidden" name="docs[' + i + '][id]" value="0" class="ldo-file__id">' +
                '<span class="ldo-file__name">' + cfg.none + '</span> <button type="button" class="button ldo-file__pick">' + cfg.choose + '</button></span></td>' +
                '<td><button type="button" class="button-link-delete ldo-del">Elimina</button></td></tr>';
        }
    };

    $( document ).on( 'click', '.ldo-add', function () {
        var key = $( this ).data( 'target' );
        var $tbl = $( 'table.ldo-rows[data-row="' + key + '"]' );
        $tbl.find( 'tbody' ).append( templates[ key ]( nextIndex( $tbl ) ) );
        $tbl.find( 'tbody tr:last input:first' ).trigger( 'focus' );
    } );

    $( document ).on( 'click', '.ldo-del', function () {
        $( this ).closest( 'tr' ).remove();
    } );

    $( document ).on( 'click', '.ldo-file__pick', function () {
        var $wrap = $( this ).closest( '.ldo-file' );
        var frame = wp.media( { title: cfg.chooseTitle, multiple: false } );
        frame.on( 'select', function () {
            var a = frame.state().get( 'selection' ).first().toJSON();
            $wrap.find( '.ldo-file__id' ).val( a.id );
            $wrap.find( '.ldo-file__name' ).text( a.filename || a.title );
            $wrap.find( '.ldo-file__pick' ).text( cfg.change );
        } );
        frame.open();
    } );
} )( jQuery );
