<?php
/**
 * Orario scolastico: sezione nel backend («Orario scolastico») e shortcode [ld_orario].
 *
 * La scuola aggiorna tutto da una sola schermata: anno scolastico, avviso, PDF dell'orario,
 * le classi (con la pagina del PDF), gli orari delle ore e altri documenti scaricabili.
 * Le pagine del sito mostrano il risultato con [ld_orario]: nessun testo da modificare a mano.
 *
 * @package liceo-diocesano-child
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

const LD_ORARIO_OPTION = 'ld_orario';
const LD_ORARIO_CAP    = 'edit_pages';

function liceo_diocesano_orario_defaults() {
    return array(
        'year'    => '',
        'notice'  => '',
        'updated' => '',
        'pdf_id'  => 0,
        'classes' => array(),
        'bells'   => array(
            array( '1', '8:05', '8:50' ), array( '2', '8:54', '9:39' ), array( '3', '9:43', '10:28' ),
            array( '4', '10:46', '11:31' ), array( '5', '11:35', '12:20' ), array( 'ds1', '12:55', '13:38' ),
            array( '6', '13:42', '14:27' ), array( '7', '14:31', '15:16' ), array( '8', '15:20', '16:05' ),
            array( 'ds2', '16:15', '17:00' ),
        ),
        'docs'    => array(),
    );
}

function liceo_diocesano_orario_get() {
    $o = get_option( LD_ORARIO_OPTION, array() );
    return wp_parse_args( is_array( $o ) ? $o : array(), liceo_diocesano_orario_defaults() );
}

// ---- Backend --------------------------------------------------------------------------------
add_action( 'admin_menu', function () {
    add_menu_page( __( 'Orario scolastico', 'liceo-diocesano-child' ), __( 'Orario scolastico', 'liceo-diocesano-child' ), LD_ORARIO_CAP, 'ld-orario', 'liceo_diocesano_orario_screen', 'dashicons-clock', 26 );
} );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
    if ( 'toplevel_page_ld-orario' !== $hook ) {
        return;
    }
    wp_enqueue_media();
    $dir = get_stylesheet_directory();
    $uri = get_stylesheet_directory_uri();
    wp_enqueue_style( 'ld-orario-admin', $uri . '/assets/css/orario-admin.css', array(), filemtime( $dir . '/assets/css/orario-admin.css' ) );
    wp_enqueue_script( 'ld-orario-admin', $uri . '/assets/js/orario-admin.js', array( 'jquery' ), filemtime( $dir . '/assets/js/orario-admin.js' ), true );
    wp_localize_script( 'ld-orario-admin', 'ldOrario', array(
        'chooseTitle' => __( 'Scegli il file', 'liceo-diocesano-child' ),
        'choose'      => __( 'Scegli file', 'liceo-diocesano-child' ),
        'change'      => __( 'Cambia file', 'liceo-diocesano-child' ),
        'none'        => __( 'Nessun file scelto', 'liceo-diocesano-child' ),
    ) );
} );

function liceo_diocesano_orario_file_field( $name, $id ) {
    $url = $id ? wp_get_attachment_url( $id ) : '';
    ?>
    <span class="ldo-file">
        <input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( (int) $id ); ?>" class="ldo-file__id">
        <span class="ldo-file__name"><?php echo $url ? esc_html( wp_basename( $url ) ) : esc_html__( 'Nessun file scelto', 'liceo-diocesano-child' ); ?></span>
        <button type="button" class="button ldo-file__pick"><?php echo $url ? esc_html__( 'Cambia file', 'liceo-diocesano-child' ) : esc_html__( 'Scegli file', 'liceo-diocesano-child' ); ?></button>
    </span>
    <?php
}

function liceo_diocesano_orario_screen() {
    if ( ! current_user_can( LD_ORARIO_CAP ) ) {
        return;
    }
    $o = liceo_diocesano_orario_get();
    ?>
    <div class="wrap ldo-admin">
        <h1><?php esc_html_e( 'Orario scolastico', 'liceo-diocesano-child' ); ?></h1>
        <?php if ( isset( $_GET['saved'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification ?>
            <div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Orario salvato. La pagina del sito è già aggiornata.', 'liceo-diocesano-child' ); ?></p></div>
        <?php endif; ?>
        <p class="description"><?php esc_html_e( 'Aggiorna qui l’orario di ogni anno. Per mostrarlo su una pagina inserisci lo shortcode [ld_orario] (è già nella pagina «Orario scolastico»).', 'liceo-diocesano-child' ); ?></p>

        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <input type="hidden" name="action" value="ld_orario_save">
            <?php wp_nonce_field( 'ld_orario_save' ); ?>

            <div class="ldo-card">
                <h2><?php esc_html_e( '1. Orario dell’anno', 'liceo-diocesano-child' ); ?></h2>
                <table class="form-table" role="presentation">
                    <tr><th><label for="ldo-year"><?php esc_html_e( 'Anno scolastico', 'liceo-diocesano-child' ); ?></label></th>
                        <td><input type="text" id="ldo-year" name="year" value="<?php echo esc_attr( $o['year'] ); ?>" class="regular-text" placeholder="2026-27"></td></tr>
                    <tr><th><?php esc_html_e( 'File PDF dell’orario', 'liceo-diocesano-child' ); ?></th>
                        <td><?php liceo_diocesano_orario_file_field( 'pdf_id', (int) $o['pdf_id'] ); ?>
                            <p class="description"><?php esc_html_e( 'Il PDF con le pagine delle classi. Quando arriva un nuovo orario, scegli qui il nuovo file.', 'liceo-diocesano-child' ); ?></p></td></tr>
                    <tr><th><label for="ldo-updated"><?php esc_html_e( 'Aggiornato il', 'liceo-diocesano-child' ); ?></label></th>
                        <td><input type="date" id="ldo-updated" name="updated" value="<?php echo esc_attr( $o['updated'] ); ?>">
                            <p class="description"><?php esc_html_e( 'Facoltativo: se compilato, appare sotto il titolo.', 'liceo-diocesano-child' ); ?></p></td></tr>
                    <tr><th><label for="ldo-notice"><?php esc_html_e( 'Avviso', 'liceo-diocesano-child' ); ?></label></th>
                        <td><textarea id="ldo-notice" name="notice" rows="3" class="large-text"><?php echo esc_textarea( $o['notice'] ); ?></textarea>
                            <p class="description"><?php esc_html_e( 'Una nota in evidenza sopra l’orario (es. orari particolari del mercoledì). Lascia vuoto per non mostrarla.', 'liceo-diocesano-child' ); ?></p></td></tr>
                </table>
            </div>

            <div class="ldo-card">
                <h2><?php esc_html_e( '2. Classi', 'liceo-diocesano-child' ); ?></h2>
                <p class="description"><?php esc_html_e( 'Per ogni classe indica in quale pagina del PDF si trova il suo orario. Gli studenti scelgono la classe e vedono subito la pagina giusta.', 'liceo-diocesano-child' ); ?></p>
                <table class="widefat striped ldo-rows" data-row="classes">
                    <thead><tr><th><?php esc_html_e( 'Classe', 'liceo-diocesano-child' ); ?></th><th><?php esc_html_e( 'Pagina del PDF', 'liceo-diocesano-child' ); ?></th><th></th></tr></thead>
                    <tbody>
                    <?php foreach ( (array) $o['classes'] as $i => $c ) : ?>
                        <tr><td><input type="text" name="classes[<?php echo (int) $i; ?>][name]" value="<?php echo esc_attr( $c[0] ); ?>" placeholder="1A"></td>
                            <td><input type="number" min="1" name="classes[<?php echo (int) $i; ?>][page]" value="<?php echo esc_attr( $c[1] ); ?>"></td>
                            <td><button type="button" class="button-link-delete ldo-del"><?php esc_html_e( 'Elimina', 'liceo-diocesano-child' ); ?></button></td></tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <p><button type="button" class="button ldo-add" data-target="classes"><?php esc_html_e( '+ Aggiungi classe', 'liceo-diocesano-child' ); ?></button></p>
            </div>

            <div class="ldo-card">
                <h2><?php esc_html_e( '3. Orari delle ore', 'liceo-diocesano-child' ); ?></h2>
                <p class="description"><?php esc_html_e( 'Gli orari di inizio e fine di ogni ora di lezione, mostrati in una riga scorrevole.', 'liceo-diocesano-child' ); ?></p>
                <table class="widefat striped ldo-rows" data-row="bells">
                    <thead><tr><th><?php esc_html_e( 'Ora', 'liceo-diocesano-child' ); ?></th><th><?php esc_html_e( 'Inizio', 'liceo-diocesano-child' ); ?></th><th><?php esc_html_e( 'Fine', 'liceo-diocesano-child' ); ?></th><th></th></tr></thead>
                    <tbody>
                    <?php foreach ( (array) $o['bells'] as $i => $b ) : ?>
                        <tr><td><input type="text" name="bells[<?php echo (int) $i; ?>][label]" value="<?php echo esc_attr( $b[0] ); ?>" placeholder="1"></td>
                            <td><input type="text" name="bells[<?php echo (int) $i; ?>][from]" value="<?php echo esc_attr( $b[1] ); ?>" placeholder="8:05"></td>
                            <td><input type="text" name="bells[<?php echo (int) $i; ?>][to]" value="<?php echo esc_attr( $b[2] ); ?>" placeholder="8:50"></td>
                            <td><button type="button" class="button-link-delete ldo-del"><?php esc_html_e( 'Elimina', 'liceo-diocesano-child' ); ?></button></td></tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <p><button type="button" class="button ldo-add" data-target="bells"><?php esc_html_e( '+ Aggiungi ora', 'liceo-diocesano-child' ); ?></button></p>
            </div>

            <div class="ldo-card">
                <h2><?php esc_html_e( '4. Altri documenti', 'liceo-diocesano-child' ); ?></h2>
                <p class="description"><?php esc_html_e( 'Altri orari da scaricare (insegnanti, complessivo…). Facoltativo.', 'liceo-diocesano-child' ); ?></p>
                <table class="widefat striped ldo-rows" data-row="docs">
                    <thead><tr><th><?php esc_html_e( 'Titolo', 'liceo-diocesano-child' ); ?></th><th><?php esc_html_e( 'File', 'liceo-diocesano-child' ); ?></th><th></th></tr></thead>
                    <tbody>
                    <?php foreach ( (array) $o['docs'] as $i => $d ) : ?>
                        <tr><td><input type="text" name="docs[<?php echo (int) $i; ?>][title]" value="<?php echo esc_attr( $d[0] ); ?>" placeholder="Orario insegnanti"></td>
                            <td><?php liceo_diocesano_orario_file_field( 'docs[' . (int) $i . '][id]', (int) $d[1] ); ?></td>
                            <td><button type="button" class="button-link-delete ldo-del"><?php esc_html_e( 'Elimina', 'liceo-diocesano-child' ); ?></button></td></tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <p><button type="button" class="button ldo-add" data-target="docs"><?php esc_html_e( '+ Aggiungi documento', 'liceo-diocesano-child' ); ?></button></p>
            </div>

            <?php submit_button( __( 'Salva orario', 'liceo-diocesano-child' ) ); ?>
        </form>
    </div>
    <?php
}

add_action( 'admin_post_ld_orario_save', function () {
    if ( ! current_user_can( LD_ORARIO_CAP ) ) {
        wp_die( esc_html__( 'Permessi insufficienti.', 'liceo-diocesano-child' ), 403 );
    }
    check_admin_referer( 'ld_orario_save' );
    // phpcs:disable WordPress.Security.ValidatedSanitizedInput
    $in      = wp_unslash( $_POST );
    $classes = array();
    foreach ( (array) ( $in['classes'] ?? array() ) as $c ) {
        $name = sanitize_text_field( $c['name'] ?? '' );
        if ( '' !== $name ) {
            $classes[] = array( $name, max( 1, (int) ( $c['page'] ?? 1 ) ) );
        }
    }
    $bells = array();
    foreach ( (array) ( $in['bells'] ?? array() ) as $b ) {
        $label = sanitize_text_field( $b['label'] ?? '' );
        if ( '' !== $label ) {
            $bells[] = array( $label, sanitize_text_field( $b['from'] ?? '' ), sanitize_text_field( $b['to'] ?? '' ) );
        }
    }
    $docs = array();
    foreach ( (array) ( $in['docs'] ?? array() ) as $d ) {
        $title = sanitize_text_field( $d['title'] ?? '' );
        $id    = absint( $d['id'] ?? 0 );
        if ( '' !== $title && $id && 'attachment' === get_post_type( $id ) ) {
            $docs[] = array( $title, $id );
        }
    }
    $pdf     = absint( $in['pdf_id'] ?? 0 );
    $updated = sanitize_text_field( $in['updated'] ?? '' );
    update_option( LD_ORARIO_OPTION, array(
        'year'    => sanitize_text_field( $in['year'] ?? '' ),
        'notice'  => sanitize_textarea_field( $in['notice'] ?? '' ),
        'updated' => preg_match( '/^\d{4}-\d{2}-\d{2}$/', $updated ) ? $updated : '',
        'pdf_id'  => ( $pdf && 'attachment' === get_post_type( $pdf ) ) ? $pdf : 0,
        'classes' => $classes,
        'bells'   => $bells,
        'docs'    => $docs,
    ), false );
    // phpcs:enable
    wp_safe_redirect( add_query_arg( array( 'page' => 'ld-orario', 'saved' => 1 ), admin_url( 'admin.php' ) ) );
    exit;
} );

// ---- Sito -----------------------------------------------------------------------------------
add_shortcode( 'ld_orario', function () {
    $o   = liceo_diocesano_orario_get();
    $dir = get_stylesheet_directory();
    $uri = get_stylesheet_directory_uri();
    wp_enqueue_style( 'ld-orario', $uri . '/assets/css/orario.css', array( 'child-style' ), filemtime( $dir . '/assets/css/orario.css' ) );
    $pdf = $o['pdf_id'] ? wp_get_attachment_url( (int) $o['pdf_id'] ) : '';
    if ( $pdf && $o['classes'] ) {
        wp_enqueue_script( 'ld-orario', $uri . '/assets/js/orario.js', array(), filemtime( $dir . '/assets/js/orario.js' ), true );
    }
    ob_start();
    ?>
    <div class="ldo">
        <header class="ldo-head">
            <?php if ( $o['year'] ) : ?><span class="ld-pill"><?php echo esc_html( sprintf( /* translators: %s: school year */ __( 'Anno scolastico %s', 'liceo-diocesano-child' ), $o['year'] ) ); ?></span><?php endif; ?>
            <?php if ( $o['updated'] ) : ?><span class="ldo-updated"><?php echo esc_html( sprintf( /* translators: %s: date */ __( 'Aggiornato il %s', 'liceo-diocesano-child' ), wp_date( get_option( 'date_format' ), strtotime( $o['updated'] ) ) ) ); ?></span><?php endif; ?>
        </header>

        <?php if ( $o['notice'] ) : ?>
            <p class="ldo-notice"><?php echo esc_html( $o['notice'] ); ?></p>
        <?php endif; ?>

        <?php if ( $pdf ) : ?>
            <section class="ldo-sec">
                <h2><?php esc_html_e( 'Orario della tua classe', 'liceo-diocesano-child' ); ?></h2>
                <?php if ( $o['classes'] ) : ?>
                    <div class="ldo-chips" role="group" aria-label="<?php esc_attr_e( 'Scegli la classe', 'liceo-diocesano-child' ); ?>">
                        <?php foreach ( $o['classes'] as $i => $c ) : ?>
                            <button type="button" class="ldo-chip<?php echo 0 === $i ? ' is-on' : ''; ?>" data-page="<?php echo (int) $c[1]; ?>" aria-pressed="<?php echo 0 === $i ? 'true' : 'false'; ?>"><?php echo esc_html( $c[0] ); ?></button>
                        <?php endforeach; ?>
                    </div>
                    <div class="ldo-viewer">
                        <iframe src="<?php echo esc_url( $pdf ); ?>#page=<?php echo (int) $o['classes'][0][1]; ?>&amp;view=FitH" data-pdf="<?php echo esc_url( $pdf ); ?>" title="<?php esc_attr_e( 'Orario della classe', 'liceo-diocesano-child' ); ?>" loading="lazy"></iframe>
                    </div>
                <?php endif; ?>
                <p class="ldo-actions">
                    <a class="ld-btn" href="<?php echo esc_url( $pdf ); ?>" target="_blank" rel="noopener" data-ldo-open><?php esc_html_e( 'Apri l’orario (PDF)', 'liceo-diocesano-child' ); ?></a>
                    <a class="ldo-link" href="<?php echo esc_url( $pdf ); ?>" download><?php esc_html_e( 'Scarica', 'liceo-diocesano-child' ); ?></a>
                </p>
            </section>
        <?php endif; ?>

        <?php if ( $o['bells'] ) : ?>
            <section class="ldo-sec">
                <h2><?php esc_html_e( 'Orari delle ore', 'liceo-diocesano-child' ); ?></h2>
                <ol class="ldo-bells">
                    <?php foreach ( $o['bells'] as $b ) : ?>
                        <li class="ldo-bell<?php echo ctype_digit( (string) $b[0] ) ? '' : ' is-extra'; ?>">
                            <span class="ldo-bell__n"><?php echo esc_html( $b[0] ); ?></span>
                            <span class="ldo-bell__t"><?php echo esc_html( $b[1] ); ?> – <?php echo esc_html( $b[2] ); ?></span>
                        </li>
                    <?php endforeach; ?>
                </ol>
            </section>
        <?php endif; ?>

        <?php if ( $o['docs'] ) : ?>
            <section class="ldo-sec">
                <h2><?php esc_html_e( 'Altri documenti', 'liceo-diocesano-child' ); ?></h2>
                <ul class="ldo-docs">
                    <?php foreach ( $o['docs'] as $d ) : $u = wp_get_attachment_url( (int) $d[1] ); if ( ! $u ) { continue; } ?>
                        <li><a href="<?php echo esc_url( $u ); ?>" target="_blank" rel="noopener"><span><?php echo esc_html( $d[0] ); ?></span><small><?php echo esc_html( strtoupper( pathinfo( $u, PATHINFO_EXTENSION ) ) ); ?></small></a></li>
                    <?php endforeach; ?>
                </ul>
            </section>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
} );
