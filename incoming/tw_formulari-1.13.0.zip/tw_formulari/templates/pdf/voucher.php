<?php
/**
 * PDF «Buono regalo» (A5 orizzontale, da stampare o mostrare dal telefono).
 *
 * A sinistra la foto scelta nel modulo (oppure un pacco regalo sul colore del buono), a destra su fondo caldo:
 * logo, titolo, importo grande, dedica, chi lo regala, numero, data e condizioni.
 *
 * Variabili:
 * - $voucher: title, amount, number, date, from, message, note, color, site_name.
 * - $logo_src: logo incorporato (data URI) oppure ''.
 * - $photo_src: foto incorporata (data URI) oppure ''.
 *
 * mPDF: solo tabelle con stili sulle celle, colori pieni, font inclusi (DejaVu).
 *
 * @package TicinoWeb\TWFormulari
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$color   = (string) ( $voucher['color'] ?? '#b68745' );
$title   = (string) ( $voucher['title'] ?? '' );
$amount  = (string) ( $voucher['amount'] ?? '' );
$number  = (string) ( $voucher['number'] ?? '' );
$date    = (string) ( $voucher['date'] ?? '' );
$from    = (string) ( $voucher['from'] ?? '' );
$message = (string) ( $voucher['message'] ?? '' );
$note    = (string) ( $voucher['note'] ?? '' );
$site    = (string) ( $voucher['site_name'] ?? '' );
$c       = esc_attr( $color );
// Titolo in più lingue («Buono regalo · Geschenkgutschein»): va a capo solo tra una lingua e l'altra.
$title_html = implode( ' · ', array_map( static function ( $part ) {
	return str_replace( ' ', '&nbsp;', esc_html( trim( $part ) ) );
}, explode( '·', $title ) ) );

// Pacco regalo disegnato (al posto della foto quando non c'è).
$gift = 'data:image/svg+xml;base64,' . base64_encode(
	'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" width="120" height="120">'
	. '<g fill="none" stroke="#ffffff" stroke-width="4" stroke-linejoin="round" stroke-linecap="round">'
	. '<rect x="18" y="48" width="84" height="58" rx="4"/><rect x="12" y="34" width="96" height="16" rx="3"/>'
	. '<path d="M60 34v72"/><path d="M60 34c-6-14-26-22-30-10s20 12 30 10z"/><path d="M60 34c6-14 26-22 30-10s-20 12-30 10z"/>'
	. '</g></svg>'
);
?>
<html>
<head>
<style>
	@page { margin: 0; }
	body { font-family: dejavusans; color: #2f2a26; }
	td { vertical-align: middle; }
</style>
</head>
<body>
<table width="100%" cellspacing="0" cellpadding="0" style="height: 148mm; border-collapse: collapse;">
	<tr>
		<?php if ( '' !== $photo_src ) : ?>
			<td width="42%" style="height: 148mm; background-color: <?php echo $c; ?>; background-image: url(<?php echo esc_attr( $photo_src ); ?>); background-image-resize: 6; background-repeat: no-repeat; background-position: center center;">&nbsp;</td>
		<?php else : ?>
			<td width="42%" style="height: 148mm; background-color: <?php echo $c; ?>; text-align: center;">
				<img src="<?php echo esc_attr( $gift ); ?>" style="width: 34mm; height: 34mm;" alt="">
			</td>
		<?php endif; ?>
		<td style="height: 148mm; background-color: #fbf6ee; padding: 9mm 11mm 8mm 11mm; text-align: center;">

			<table width="100%" cellspacing="0" cellpadding="0">
				<?php if ( '' !== $logo_src ) : ?>
					<tr><td style="text-align: center; padding-bottom: 5mm;"><img src="<?php echo esc_attr( $logo_src ); ?>" style="height: 19mm;" alt="<?php echo esc_attr( $site ); ?>"></td></tr>
				<?php else : ?>
					<tr><td style="text-align: center; padding-bottom: 5mm; font-family: dejavuserif; font-size: 17pt;"><?php echo esc_html( $site ); ?></td></tr>
				<?php endif; ?>

				<tr><td style="text-align: center; font-size: 7.5pt; letter-spacing: 0.2mm; text-transform: uppercase; color: <?php echo $c; ?>; font-weight: bold;">
					&#9733;&nbsp;&nbsp;<?php echo $title_html; // phpcs:ignore WordPress.Security.EscapeOutput -- escape per parte qui sopra ?>&nbsp;&nbsp;&#9733;
				</td></tr>

				<?php if ( '' !== $amount ) : ?>
					<tr><td style="text-align: center; padding-top: 3mm; font-family: dejavuserif; font-size: 40pt; font-weight: bold; color: <?php echo $c; ?>;"><?php echo esc_html( $amount ); ?></td></tr>
				<?php endif; ?>

				<?php if ( '' !== $message ) : ?>
					<tr><td style="text-align: center; padding: 4mm 4mm 0 4mm; font-family: dejavuserif; font-style: italic; font-size: 12pt; line-height: 1.45; color: #4a413a;">«<?php echo nl2br( esc_html( $message ) ); ?>»</td></tr>
				<?php endif; ?>
				<?php if ( '' !== $from ) : ?>
					<tr><td style="text-align: center; padding-top: 2.5mm; font-size: 9pt; color: #7a6f66;"><?php echo esc_html( sprintf( /* translators: %s: name of who gives the voucher */ __( 'Con i migliori auguri da %s', 'tw-formulari' ), $from ) ); ?></td></tr>
				<?php endif; ?>

				<tr><td style="padding-top: 6mm;">
					<table width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td width="50%" style="text-align: center; border-top: 0.3mm dashed <?php echo $c; ?>; padding-top: 3mm; font-size: 7pt; letter-spacing: 0.4mm; text-transform: uppercase; color: #8a7d72;"><?php esc_html_e( 'Buono n.', 'tw-formulari' ); ?></td>
							<td width="50%" style="text-align: center; border-top: 0.3mm dashed <?php echo $c; ?>; padding-top: 3mm; font-size: 7pt; letter-spacing: 0.4mm; text-transform: uppercase; color: #8a7d72;"><?php esc_html_e( 'Emesso il', 'tw-formulari' ); ?></td>
						</tr>
						<tr>
							<td style="text-align: center; padding-top: 1mm; font-size: 12pt; font-weight: bold; color: #2f2a26;"><?php echo esc_html( $number ); ?></td>
							<td style="text-align: center; padding-top: 1mm; font-size: 12pt; font-weight: bold; color: #2f2a26;"><?php echo esc_html( $date ); ?></td>
						</tr>
					</table>
				</td></tr>

				<?php if ( '' !== $note ) : ?>
					<tr><td style="text-align: center; padding-top: 5mm; font-size: 7.5pt; line-height: 1.4; color: #8a7d72;"><?php echo nl2br( esc_html( $note ) ); ?></td></tr>
				<?php endif; ?>
			</table>

		</td>
	</tr>
</table>
</body>
</html>
