<?php
/**
 * Storage of the submissions ("compilazioni") of the built-in forms.
 *
 * One row per submission in {prefix}twf_entries. The raw values are kept as JSON, together with a readable
 * snapshot of what was asked (label and text of every answer), so an old entry still reads well even after
 * the form has been edited. The visitor's IP is never stored, only a salted hash used against abuse.
 *
 * @package TicinoWeb\TWFormulari\Builder
 */

namespace TicinoWeb\TWFormulari\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Entries {

	public const DB_VERSION        = '1';
	public const DB_VERSION_OPTION = 'tw_formulari_entries_db';

	public const STATUS_NEW             = 'new';
	public const STATUS_READ            = 'read';
	public const STATUS_PENDING_PAYMENT = 'pending_payment';
	public const STATUS_PAID            = 'paid';
	public const STATUS_PAYMENT_FAILED  = 'payment_failed';
	/** Chose a manual way to pay (bank transfer, cash…): the owner marks it paid when the money arrives. */
	public const STATUS_AWAITING_PAYMENT = 'awaiting_payment';

	public static function table(): string {
		global $wpdb;
		return $wpdb->prefix . 'twf_entries';
	}

	/** Creates or updates the table when the schema version changes. */
	public static function install(): void {
		if ( self::DB_VERSION === get_option( self::DB_VERSION_OPTION ) ) {
			return;
		}
		global $wpdb;
		if ( ! function_exists( 'dbDelta' ) ) {
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		}
		$charset = $wpdb->get_charset_collate();
		$table   = self::table();
		dbDelta( "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			form_id bigint(20) unsigned NOT NULL,
			status varchar(20) NOT NULL DEFAULT 'new',
			created_gmt datetime NOT NULL,
			lang varchar(10) NOT NULL DEFAULT '',
			data longtext NOT NULL,
			display longtext NULL,
			files longtext NULL,
			payment longtext NULL,
			ip_hash char(64) NOT NULL DEFAULT '',
			PRIMARY KEY  (id),
			KEY form_created (form_id, created_gmt),
			KEY status (status)
		) {$charset};" );
		update_option( self::DB_VERSION_OPTION, self::DB_VERSION, false );
	}

	/**
	 * Builds the readable snapshot of the answers.
	 *
	 * @param array<string, mixed> $def    Normalised definition.
	 * @param array<string, mixed> $values Values keyed by field id (visible fields only).
	 * @return array<int, array{id:string,type:string,label:string,text:string}>
	 */
	public static function snapshot( array $def, array $values ): array {
		$rows = [];
		foreach ( (array) ( $def['fields'] ?? [] ) as $field ) {
			$id   = (string) ( $field['id'] ?? '' );
			$type = (string) ( $field['type'] ?? '' );
			if ( '' === $id || ! FieldTypes::is_input( $type ) || ! array_key_exists( $id, $values ) ) {
				continue;
			}
			$text = FieldTypes::display_value( $field, $values[ $id ] );
			if ( '' === $text && 'gdpr' !== $type ) {
				continue;
			}
			$rows[] = [
				'id'    => $id,
				'type'  => $type,
				'label' => '' !== (string) $field['label'] ? (string) $field['label'] : $id,
				'text'  => $text,
			];
		}
		return $rows;
	}

	/**
	 * @param array<string, mixed> $row form_id, status, lang, data, display, files, payment, ip_hash.
	 * @return int New entry id, or 0 on failure.
	 */
	public static function create( array $row ): int {
		global $wpdb;
		$ok = $wpdb->insert(
			self::table(),
			[
				'form_id'     => (int) $row['form_id'],
				'status'      => self::clean_status( (string) ( $row['status'] ?? self::STATUS_NEW ) ),
				'created_gmt' => preg_match( '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', (string) ( $row['created_gmt'] ?? '' ) ) ? (string) $row['created_gmt'] : gmdate( 'Y-m-d H:i:s' ),
				'lang'        => substr( preg_replace( '/[^A-Za-z_\-]/', '', (string) ( $row['lang'] ?? '' ) ), 0, 10 ),
				'data'        => wp_json_encode( $row['data'] ?? [] ),
				'display'     => wp_json_encode( $row['display'] ?? [] ),
				'files'       => wp_json_encode( $row['files'] ?? [] ),
				'payment'     => wp_json_encode( $row['payment'] ?? new \stdClass() ),
				'ip_hash'     => substr( (string) ( $row['ip_hash'] ?? '' ), 0, 64 ),
			],
			[ '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' ]
		);
		return $ok ? (int) $wpdb->insert_id : 0;
	}

	/**
	 * @return array<string, mixed>|null
	 */
	public static function get( int $id ): ?array {
		global $wpdb;
		$table = self::table();
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ), ARRAY_A );
		return $row ? self::decode( $row ) : null;
	}

	/**
	 * @param array<string, mixed> $fields Any of status, data, display, files, payment.
	 */
	public static function update( int $id, array $fields ): bool {
		global $wpdb;
		$set    = [];
		$format = [];
		foreach ( [ 'data', 'display', 'files', 'payment' ] as $col ) {
			if ( array_key_exists( $col, $fields ) ) {
				$set[ $col ] = wp_json_encode( $fields[ $col ] );
				$format[]    = '%s';
			}
		}
		if ( array_key_exists( 'status', $fields ) ) {
			$set['status'] = self::clean_status( (string) $fields['status'] );
			$format[]      = '%s';
		}
		if ( ! $set ) {
			return false;
		}
		return false !== $wpdb->update( self::table(), $set, [ 'id' => $id ], $format, [ '%d' ] );
	}

	/**
	 * Moves an entry from one of the given statuses to another in a single atomic UPDATE, so that two requests
	 * racing to confirm the same payment cannot both "win" (and send the e-mails twice).
	 *
	 * @param string[]             $from
	 * @param array<string, mixed> $payment New payment details.
	 * @return bool True only for the request that actually changed the row.
	 */
	public static function transition( int $id, array $from, string $to, array $payment ): bool {
		global $wpdb;
		$from = array_values( array_filter( array_map( [ self::class, 'clean_status' ], $from ) ) );
		if ( ! $from ) {
			return false;
		}
		$table = self::table();
		$in    = implode( ',', array_fill( 0, count( $from ), '%s' ) );
		$args  = array_merge( [ self::clean_status( $to ), wp_json_encode( $payment ), $id ], $from );
		$rows  = $wpdb->query( $wpdb->prepare( "UPDATE {$table} SET status = %s, payment = %s WHERE id = %d AND status IN ({$in})", $args ) );
		return 1 === (int) $rows;
	}

	/**
	 * Ids of the entries still waiting for a payment that started more than $older_than seconds ago.
	 *
	 * @return int[]
	 */
	public static function pending_payment_ids( int $older_than, int $limit = 50 ): array {
		global $wpdb;
		$table  = self::table();
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - max( 0, $older_than ) );
		$ids    = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$table} WHERE status = %s AND created_gmt < %s ORDER BY id ASC LIMIT %d", self::STATUS_PENDING_PAYMENT, $cutoff, max( 1, $limit ) ) );
		return array_map( 'intval', (array) $ids );
	}

	/**
	 * @param array{form_id?:int,status?:string,search?:string,per_page?:int,page?:int,order?:string} $args
	 * @return array{items:array<int,array<string,mixed>>,total:int}
	 */
	public static function query( array $args ): array {
		global $wpdb;
		$table = self::table();
		[ $where, $params ] = self::where( $args );

		$per_page = max( 1, min( 200, (int) ( $args['per_page'] ?? 20 ) ) );
		$offset   = max( 0, ( max( 1, (int) ( $args['page'] ?? 1 ) ) - 1 ) * $per_page );
		$order    = 'ASC' === strtoupper( (string) ( $args['order'] ?? 'DESC' ) ) ? 'ASC' : 'DESC';

		$total_sql = "SELECT COUNT(*) FROM {$table} {$where}";
		$total     = (int) ( $params ? $wpdb->get_var( $wpdb->prepare( $total_sql, $params ) ) : $wpdb->get_var( $total_sql ) );

		$list_sql = "SELECT * FROM {$table} {$where} ORDER BY created_gmt {$order}, id {$order} LIMIT %d OFFSET %d";
		$rows     = $wpdb->get_results( $wpdb->prepare( $list_sql, array_merge( $params, [ $per_page, $offset ] ) ), ARRAY_A );

		return [
			'items' => array_map( [ self::class, 'decode' ], (array) $rows ),
			'total' => $total,
		];
	}

	/** Number of entries of a form (all statuses, or only the given one). */
	public static function count( int $form_id, string $status = '' ): int {
		global $wpdb;
		$table = self::table();
		if ( '' === $status ) {
			return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE form_id = %d", $form_id ) );
		}
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE form_id = %d AND status = %s", $form_id, $status ) );
	}

	/**
	 * Deletes entries and their private files.
	 *
	 * @param int[] $ids
	 * @return int Entries deleted.
	 */
	public static function delete( array $ids ): int {
		global $wpdb;
		$ids = array_values( array_filter( array_map( 'intval', $ids ) ) );
		if ( ! $ids ) {
			return 0;
		}
		$table = self::table();
		foreach ( $ids as $id ) {
			$entry = self::get( $id );
			if ( $entry ) {
				Uploads::delete_files( (array) $entry['files'] );
			}
		}
		$in = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		return (int) $wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE id IN ({$in})", $ids ) );
	}

	/**
	 * Deletes the entries of a form older than the given number of days. 0 days means "keep forever".
	 *
	 * @return int Entries deleted.
	 */
	public static function purge_older_than( int $form_id, int $days ): int {
		global $wpdb;
		if ( $days <= 0 ) {
			return 0;
		}
		$table  = self::table();
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );
		$ids    = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$table} WHERE form_id = %d AND created_gmt < %s AND status <> %s LIMIT 500", $form_id, $cutoff, self::STATUS_PENDING_PAYMENT ) );
		return self::delete( array_map( 'intval', (array) $ids ) );
	}

	/**
	 * Rows of a CSV export for a form: header first, then one line per entry.
	 *
	 * @param array<string, mixed> $def
	 * @param array<int, array<string, mixed>> $entries
	 * @return array<int, array<int, string>>
	 */
	public static function csv_rows( array $def, array $entries ): array {
		$columns = [];
		foreach ( (array) ( $def['fields'] ?? [] ) as $field ) {
			if ( FieldTypes::is_input( (string) ( $field['type'] ?? '' ) ) && 'hidden' !== ( $field['type'] ?? '' ) ) {
				$columns[ (string) $field['id'] ] = (string) ( '' !== (string) $field['label'] ? $field['label'] : $field['id'] );
			}
		}
		$has_payment = false;
		foreach ( $entries as $entry ) {
			if ( isset( $entry['payment']['amount'] ) ) {
				$has_payment = true;
				break;
			}
		}
		$rows   = [ array_merge( [ 'ID', 'Data', 'Stato' ], $has_payment ? [ 'Importo', 'Valuta', 'Metodo di pagamento' ] : [], array_values( $columns ) ) ];
		foreach ( $entries as $entry ) {
			$by_id = [];
			foreach ( (array) ( $entry['display'] ?? [] ) as $item ) {
				if ( isset( $item['id'] ) ) {
					$by_id[ (string) $item['id'] ] = (string) ( $item['text'] ?? '' );
				}
			}
			$line = [ (string) $entry['id'], (string) $entry['created_gmt'], (string) $entry['status'] ];
			if ( $has_payment ) {
				$line[] = (string) ( $entry['payment']['amount'] ?? '' );
				$line[] = (string) ( $entry['payment']['currency'] ?? '' );
				$line[] = (string) ( $entry['payment']['label'] ?? ( isset( $entry['payment']['provider'] ) && 'stripe' === $entry['payment']['provider'] ? 'Stripe' : '' ) );
			}
			foreach ( array_keys( $columns ) as $id ) {
				$line[] = self::csv_safe( $by_id[ $id ] ?? '' );
			}
			$rows[] = $line;
		}
		return $rows;
	}

	/** Prevents spreadsheet formula injection: cells starting with = + - @ are prefixed with an apostrophe. */
	public static function csv_safe( string $cell ): string {
		return preg_match( '/^[=+\-@\t\r]/', $cell ) ? "'" . $cell : $cell;
	}

	/**
	 * @param array{form_id?:int,status?:string,search?:string} $args
	 * @return array{0:string,1:array<int,mixed>}
	 */
	private static function where( array $args ): array {
		global $wpdb;
		$clauses = [];
		$params  = [];
		if ( ! empty( $args['form_id'] ) ) {
			$clauses[] = 'form_id = %d';
			$params[]  = (int) $args['form_id'];
		}
		if ( ! empty( $args['status'] ) ) {
			$clauses[] = 'status = %s';
			$params[]  = self::clean_status( (string) $args['status'] );
		}
		if ( ! empty( $args['search'] ) ) {
			$clauses[] = 'display LIKE %s';
			$params[]  = '%' . $wpdb->esc_like( (string) $args['search'] ) . '%';
		}
		return [ $clauses ? 'WHERE ' . implode( ' AND ', $clauses ) : '', $params ];
	}

	private static function clean_status( string $status ): string {
		$allowed = [ self::STATUS_NEW, self::STATUS_READ, self::STATUS_PENDING_PAYMENT, self::STATUS_AWAITING_PAYMENT, self::STATUS_PAID, self::STATUS_PAYMENT_FAILED ];
		return in_array( $status, $allowed, true ) ? $status : self::STATUS_NEW;
	}

	/**
	 * @param array<string, mixed> $row
	 * @return array<string, mixed>
	 */
	private static function decode( array $row ): array {
		foreach ( [ 'data', 'display', 'files', 'payment' ] as $col ) {
			$decoded    = isset( $row[ $col ] ) ? json_decode( (string) $row[ $col ], true ) : null;
			$row[ $col ] = is_array( $decoded ) ? $decoded : [];
		}
		$row['id']      = (int) $row['id'];
		$row['form_id'] = (int) $row['form_id'];
		return $row;
	}
}
