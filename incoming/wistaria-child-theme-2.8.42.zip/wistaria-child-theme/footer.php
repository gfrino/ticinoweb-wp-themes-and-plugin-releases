<?php
/** Site footer. @package WistariaChildTheme */
$privacy_id = (int) get_option( 'wp_page_for_privacy_policy', 0 );
$privacy = $privacy_id && 'publish' === get_post_status( $privacy_id ) ? get_privacy_policy_url() : '';
$cookie_policy = get_page_by_path( 'cookie-policy-ue' );
$company_details_page = get_page_by_path( 'dati-aziendali' );
$email = sanitize_email( (string) get_option( 'ticinoweb_contact_email', '' ) );
$phone = sanitize_text_field( (string) get_option( 'ticinoweb_contact_phone', '' ) );
$address = sanitize_text_field( (string) get_option( 'ticinoweb_contact_address', '' ) );
?>
<footer class="site-footer">
	<div class="site-footer__inner">
		<div class="site-footer__brand">
			<p class="site-footer__name"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></p>
			<address class="site-footer__contact">
				<?php if ( $address ) : ?><p><?php echo esc_html( $address ); ?></p><?php endif; ?>
				<?php if ( $phone ) : ?><p><a href="<?php echo esc_url( 'tel:' . preg_replace( '/[^+0-9]/', '', $phone ) ); ?>"><?php echo esc_html( $phone ); ?></a></p><?php endif; ?>
				<?php if ( $email ) : ?><p><a href="<?php echo esc_url( 'mailto:' . $email ); ?>"><?php echo esc_html( $email ); ?></a></p><?php endif; ?>
			</address>
		</div>
		<nav class="site-footer__navigation" aria-label="<?php esc_attr_e( 'Esplora il sito', 'wistaria-child-theme' ); ?>">
			<h2 class="site-footer__heading"><?php esc_html_e( 'Esplora', 'wistaria-child-theme' ); ?></h2>
			<ul class="site-footer__links">
				<li><a href="<?php echo esc_url( home_url( '/#servizi' ) ); ?>"><?php esc_html_e( 'Servizi', 'wistaria-child-theme' ); ?></a></li>
				<li><a href="<?php echo esc_url( home_url( '/#lavori' ) ); ?>"><?php esc_html_e( 'Lavori', 'wistaria-child-theme' ); ?></a></li>
				<li><a href="<?php echo esc_url( home_url( '/#chi-siamo' ) ); ?>"><?php esc_html_e( 'Chi siamo', 'wistaria-child-theme' ); ?></a></li>
				<li><a href="<?php echo esc_url( home_url( '/#contatti' ) ); ?>"><?php esc_html_e( 'Contatti', 'wistaria-child-theme' ); ?></a></li>
			</ul>
		</nav>
		<nav class="site-footer__legal" aria-label="<?php esc_attr_e( 'Informazioni legali', 'wistaria-child-theme' ); ?>">
			<h2 class="site-footer__heading"><?php esc_html_e( 'Informazioni legali', 'wistaria-child-theme' ); ?></h2>
			<ul class="site-footer__links">
				<?php if ( $privacy ) : ?><li><a href="<?php echo esc_url( $privacy ); ?>"><?php esc_html_e( 'Privacy policy', 'wistaria-child-theme' ); ?></a></li><?php endif; ?>
				<?php if ( $cookie_policy && 'publish' === $cookie_policy->post_status ) : ?><li><a href="<?php echo esc_url( get_permalink( $cookie_policy ) ); ?>"><?php esc_html_e( 'Cookie policy', 'wistaria-child-theme' ); ?></a></li><?php endif; ?>
				<?php if ( get_option( 'tw_cookie_banner_enable' ) ) : ?><li><button class="site-footer__cookie-settings" type="button"><?php esc_html_e( 'Preferenze cookie', 'wistaria-child-theme' ); ?></button></li><?php endif; ?>
				<?php if ( $company_details_page && 'publish' === $company_details_page->post_status ) : ?><li><a href="<?php echo esc_url( get_permalink( $company_details_page ) ); ?>"><?php esc_html_e( 'Dati aziendali', 'wistaria-child-theme' ); ?></a></li><?php endif; ?>
			</ul>
		</nav>
	</div>
	<div class="site-footer__bottom">
		<span>© <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php esc_html_e( 'Copyright All rights reserved.', 'wistaria-child-theme' ); ?> <?php echo esc_html( get_bloginfo( 'name' ) ); ?></span>
		<div class="site-footer__credits">
			<a href="<?php echo esc_url( is_user_logged_in() ? admin_url() : wp_login_url( admin_url() ) ); ?>"><?php esc_html_e( 'Area riservata', 'wistaria-child-theme' ); ?></a>
			<a href="https://ticinoweb.net/"><?php esc_html_e( 'developed by ticinoWEB', 'wistaria-child-theme' ); ?></a>
		</div>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
