<?php
defined('ABSPATH') || exit;

function gomes_text($value, $context = '') {
    return function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text((string) $value, 'gomes:' . $context) : (string) $value;
}
function gomes_home() {
    return function_exists('ticinoweb_frontend_url') ? ticinoweb_frontend_url(home_url('/'), 'theme:url:home') : home_url('/');
}
function gomes_contact() {
    return function_exists('ticinoweb_get_contact_info') ? ticinoweb_get_contact_info() : array();
}
/** Shared translated day labels; hours remain owned by the parent CMS. */
function gomes_weekdays() {
    return array('monday' => __('Lunedì', 'gomes-gessatura'), 'tuesday' => __('Martedì', 'gomes-gessatura'), 'wednesday' => __('Mercoledì', 'gomes-gessatura'), 'thursday' => __('Giovedì', 'gomes-gessatura'), 'friday' => __('Venerdì', 'gomes-gessatura'), 'saturday' => __('Sabato', 'gomes-gessatura'), 'sunday' => __('Domenica', 'gomes-gessatura'));
}
function gomes_phone_href($phone) {
    return 'tel:' . preg_replace('/[^0-9+]/', '', (string) $phone);
}
/** Content images must resolve to the current site's Media Library. */
function gomes_image($value, $size = 'large', $attrs = array()) {
    $id = is_numeric($value) ? absint($value) : attachment_url_to_postid((string) $value);
    return $id ? wp_get_attachment_image($id, $size, false, $attrs) : '';
}
function gomes_services() {
    $services = function_exists('ticinoweb_get_services') ? ticinoweb_get_services() : array();
    if (!$services) { return; }
    $services = array_values(array_filter($services, static fn($service) => !empty($service['title'])));
    if (!$services) { return; }
    echo '<div class="gomes-service-explorer" data-services><div class="gomes-service-nav" data-service-nav hidden>';
    foreach ($services as $index => $service) {
        echo '<button type="button" data-service-select="' . esc_attr($index) . '">' . esc_html($service['title']) . '<span aria-hidden="true">↗</span></button>';
    }
    echo '</div><div class="gomes-services">';
    foreach ($services as $index => $service) {
        if (empty($service['title'])) { continue; }
        ?>
        <article class="gomes-service" data-service-panel="<?php echo esc_attr($index); ?>">
            <?php $image = gomes_image($service['image'] ?? '', 'large', array('loading' => 'lazy', 'sizes' => '(max-width: 540px) 100vw, (max-width: 1100px) 50vw, 60vw')); if ($image) : ?><figure class="gomes-service-photo"><?php echo $image; ?></figure><?php endif; ?>
            <div class="gomes-service-body">
                <h3><?php echo esc_html($service['title']); ?></h3>
                <div><?php echo wp_kses_post(wpautop($service['description'] ?? '')); ?><a class="gomes-text-link" href="<?php echo esc_url(gomes_home() . '#contatti'); ?>"><?php echo esc_html(gomes_text(__('Parliamo del tuo progetto', 'gomes-gessatura'), 'service-cta')); ?><span aria-hidden="true"> ↗</span></a></div>
            </div>
        </article>
        <?php
    }
    echo '</div></div>';
}

/** Native parent taxonomy, one bounded media query and the parent's curated term order. */
function gomes_gallery() {
    $taxonomy = 'ticinoweb_media_gallery';
    $terms = get_terms(array('taxonomy' => $taxonomy, 'hide_empty' => true, 'number' => 30));
    if (is_wp_error($terms) || !$terms) { return; }
    $ids = get_posts(array('post_type' => 'attachment', 'post_status' => 'inherit', 'post_mime_type' => 'image', 'posts_per_page' => 120, 'fields' => 'ids', 'orderby' => 'menu_order ID', 'order' => 'ASC', 'tax_query' => array(array('taxonomy' => $taxonomy, 'field' => 'term_id', 'terms' => wp_list_pluck($terms, 'term_id')))));
    if (!$ids) { return; }
    update_meta_cache('post', $ids);
    update_object_term_cache($ids, 'attachment');
    $ordered = array();
    foreach ($terms as $term) {
        $ordered = array_merge($ordered, array_map('absint', (array) get_term_meta($term->term_id, '_ticinoweb_gallery_order', true)));
    }
    $ids = array_values(array_unique(array_merge(array_intersect($ordered, $ids), $ids)));
    ?>
    <div class="gomes-gallery" data-gallery>
        <div class="gomes-filters" role="group" aria-label="<?php echo esc_attr(gomes_text(__('Filtra le lavorazioni', 'gomes-gessatura'), 'filter-label')); ?>" hidden>
            <button type="button" data-filter="all" aria-pressed="true"><?php echo esc_html(gomes_text(__('Tutti i lavori', 'gomes-gessatura'), 'all-work')); ?></button>
            <?php foreach ($terms as $term) : ?><button type="button" data-filter="<?php echo esc_attr($term->term_id); ?>" aria-pressed="false"><?php echo esc_html(gomes_text($term->name, 'gallery:' . $term->term_id)); ?></button><?php endforeach; ?>
        </div>
        <div class="gomes-gallery-grid">
            <?php foreach ($ids as $id) :
                $image_terms = get_the_terms($id, $taxonomy);
                $term_ids = is_array($image_terms) ? wp_list_pluck($image_terms, 'term_id') : array();
                $title = gomes_text(get_the_title($id), 'media:' . $id . ':title');
                $caption = gomes_text(wp_get_attachment_caption($id), 'media:' . $id . ':caption');
                ?>
                <figure data-gallery-item data-groups="<?php echo esc_attr(implode(' ', $term_ids)); ?>">
                    <a href="<?php echo esc_url(wp_get_attachment_image_url($id, 'full')); ?>" data-lightbox data-caption="<?php echo esc_attr($caption); ?>">
                        <?php echo wp_get_attachment_image($id, 'large', false, array('loading' => 'lazy', 'sizes' => '(max-width: 600px) 92vw, (max-width: 900px) 45vw, 30vw')); ?>
                        <span class="gomes-enlarge" aria-hidden="true">↗</span>
                        <span class="screen-reader-text"><?php echo esc_html(gomes_text(__('Ingrandisci:', 'gomes-gessatura'), 'enlarge') . ' ' . $title); ?></span>
                    </a>
                    <figcaption><h3><?php echo esc_html($title); ?></h3><?php if ($caption) : ?><p><?php echo esc_html($caption); ?></p><?php endif; ?></figcaption>
                </figure>
            <?php endforeach; ?>
        </div>
        <p class="screen-reader-text" data-gallery-status aria-live="polite"></p>
        <button class="gomes-button gomes-button-outline" type="button" data-gallery-more hidden><?php echo esc_html(gomes_text(__('Mostra altri lavori', 'gomes-gessatura'), 'more-work')); ?></button>
    </div>
    <dialog class="gomes-lightbox" aria-labelledby="gomes-lightbox-title">
        <div class="gomes-lightbox-bar"><p id="gomes-lightbox-title"></p><button type="button" data-lightbox-close autofocus><?php echo esc_html(gomes_text(__('Chiudi', 'gomes-gessatura'), 'close')); ?> <span aria-hidden="true">×</span></button></div>
        <div data-lightbox-media></div>
        <p data-lightbox-caption></p>
        <div class="gomes-lightbox-nav"><button type="button" data-lightbox-prev><?php echo esc_html(gomes_text(__('Precedente', 'gomes-gessatura'), 'previous')); ?></button><button type="button" data-lightbox-next><?php echo esc_html(gomes_text(__('Successiva', 'gomes-gessatura'), 'next')); ?></button></div>
    </dialog>
    <?php
}
function gomes_about() {
    $title = gomes_text(get_option('ticinoweb_chi_siamo_title', ''), 'about-title');
    $text = gomes_text(get_option('ticinoweb_chi_siamo_text', ''), 'about-text');
    if (!$title && !$text) { return; }
    echo '<div class="gomes-about">';
    echo gomes_image(get_option('ticinoweb_chi_siamo_image', ''), 'large', array('loading' => 'lazy', 'sizes' => '(max-width: 700px) 92vw, 40vw'));
    echo '<div class="gomes-about-copy">';
    if ($title) { echo '<h2>' . esc_html($title) . '</h2>'; }
    echo wp_kses_post(wpautop($text));
    echo '<a class="gomes-text-link gomes-about-link" href="' . esc_url(gomes_home() . '#contatti') . '">' . esc_html(gomes_text(__('Parliamo del tuo progetto', 'gomes-gessatura'), 'service-cta')) . '<span aria-hidden="true"> ↗</span></a>';
    echo '</div></div>';
}
