<?php
/**
 * REST GET /wp-json/cs/v1/addons/<category_id> (v2.21.0)
 *
 * The products of a category with their Product Add-ons groups, read by the mobile app.
 * It used to live in a Code Snippets snippet («Product Addons API», by Shades of Media) on every
 * sede: moved here unchanged so the app keeps receiving the same JSON. Same query (get_posts with
 * the WordPress default of 5 posts), same fields (the WP_Post fields plus product_addon and
 * product_addon_global), same 404 «empty_category» when the category has no products.
 *
 * GET /cs/v1/addons/all is NOT here: it is served by the mu-plugin cs-addons-rest-api.php
 * (registered first, so it already answered instead of the snippet's version).
 */

defined( 'ABSPATH' ) || exit;

add_action( 'rest_api_init', function () {
	if ( ! class_exists( 'WC_Product_Addons_Groups' ) ) {
		return;
	}
	register_rest_route( 'cs/v1', '/addons/(?P<category_id>\d+)', array(
		'methods'             => 'GET',
		'callback'            => 'ARD_rest_addons_by_category',
		'permission_callback' => '__return_true', // public, as the snippet: the app reads it without login
		'args'                => array(
			'category_id' => array(
				'validate_callback' => static function ( $value ) {
					return is_numeric( $value );
				},
			),
		),
	) );
} );

/** Products of the category (5, as the snippet) with their add-on groups and the global groups. */
function ARD_rest_addons_by_category( WP_REST_Request $request ) {
	$posts = get_posts( array(
		'post_type' => 'product',
		'tax_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- same query as the app always had
			array(
				'taxonomy' => 'product_cat',
				'field'    => 'term_id',
				'terms'    => array( absint( $request['category_id'] ) ),
				'operator' => 'IN',
			),
		),
	) );

	if ( empty( $posts ) ) {
		return new WP_Error( 'empty_category', 'There are no posts to display', array( 'status' => 404 ) );
	}

	$global = WC_Product_Addons_Groups::get_all_global_groups();
	foreach ( $posts as $key => $post ) {
		$posts[ $key ]->product_addon        = WC_Product_Addons_Groups::get_group( wc_clean( $post->ID ) );
		$posts[ $key ]->product_addon_global = $global;
	}

	$response = new WP_REST_Response( $posts );
	$response->set_status( 200 );
	return $response;
}
