<?php
/**
 * REST GET /wp-json/mobile/v1/products/id_translator (v2.23.0)
 *
 * Read by the app backend (Cloud Functions, getProductsTranslated) when a customer opens their
 * favourite products in English, German or French: it turns the Italian product IDs into the IDs of
 * the same products in that language, then asks WooCommerce for them.
 * It used to live in the Code Snippets snippet «Mobile - Products Custom Endpoints» on every sede:
 * moved here with the same parameters (from, to, include[] up to 20 IDs), the same errors (400
 * invalid_request / invalid_language) and the same JSON (the list of translated IDs).
 *
 * - WPML: IDs are mapped with the wpml_object_id filter; a product without a translation is left
 *   out, as the snippet did.
 * - tW Translate Plus or no translation plugin: a product has the same ID in every language, so the
 *   IDs come back unchanged (this is what the sedi do today, WPML being off).
 *
 * The snippet's other route, products/search, is NOT moved: nothing calls it (neither the app nor
 * the Cloud Functions) and it answered 500 on every sede once WPML was turned off.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'rest_api_init', function () {
	register_rest_route( 'mobile/v1', '/products/id_translator', array(
		'methods'             => 'GET',
		'callback'            => 'ARD_rest_products_id_translator',
		'permission_callback' => '__return_true', // public, as the snippet: it only maps product IDs, no private data
	) );
} );

/** Italian product IDs → IDs in the requested language. */
function ARD_rest_products_id_translator( WP_REST_Request $request ) {
	$languages = array( 'en', 'fr', 'it', 'de' );
	$from      = sanitize_key( (string) $request['from'] );
	$to        = sanitize_key( (string) $request['to'] );
	$ids       = $request['include'];

	if ( ! is_array( $ids ) ) {
		return new WP_Error( 'invalid_request', '"include" param missing or is not an array', array( 'status' => 400 ) );
	}
	foreach ( $ids as $id ) {
		if ( ! is_numeric( $id ) ) {
			return new WP_Error( 'invalid_request', '"include" need to be a array of numbers', array( 'status' => 400 ) );
		}
	}
	if ( count( $ids ) > 20 ) {
		return new WP_Error( 'invalid_request', '"include" max size is of 20', array( 'status' => 400 ) );
	}
	if ( '' === $from ) {
		return new WP_Error( 'invalid_request', '"from" param missing', array( 'status' => 400 ) );
	}
	if ( '' === $to ) {
		return new WP_Error( 'invalid_request', '"to" param missing', array( 'status' => 400 ) );
	}
	if ( ! in_array( $from, $languages, true ) ) {
		return new WP_Error( 'invalid_language', "lang '$from' not supported", array( 'status' => 400 ) );
	}
	if ( ! in_array( $to, $languages, true ) ) {
		return new WP_Error( 'invalid_language', "lang '$to' not supported", array( 'status' => 400 ) );
	}

	$translated = array();
	foreach ( $ids as $id ) {
		$id = absint( $id );
		// WPML answers with the translation (or null); without WPML the filter returns the ID itself.
		$tid = apply_filters( 'wpml_object_id', $id, 'product', false, $to );
		if ( ! empty( $tid ) ) {
			$translated[] = (string) $tid; // strings, as the snippet returned them
		}
	}

	return new WP_REST_Response( $translated, 200 );
}
