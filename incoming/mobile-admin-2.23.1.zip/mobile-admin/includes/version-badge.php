<?php
/**
 * Plugin version at the top left of every Mobile Admin page (v2.22.0), as ticinoWEB AI Theme does:
 * green dot = up to date, grey dot = update available (link to Dashboard → Updates),
 * hollow grey dot = the release repository cannot be read right now.
 * The latest version comes from TW_Release_Updater::releases() (one cached GitHub call shared
 * with the updater): no extra request.
 */

defined( 'ABSPATH' ) || exit;

/** Slugs (?page=) of the plugin pages. */
function ARD_admin_page_slugs() {
	return array(
		'ard_stato_app', 'ard_notifications', 'app_administration_backoffice_settings', 'ard_slides',
		'ard_category_icons', 'ard_payment_methods', 'ard_combo_menu', 'ard_app_keys', 'ard_app_links',
		'wc_site_status', 'ard_web_payments',
	);
}

add_action( 'in_admin_header', function () {
	$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read only, picks the screen
	if ( '' === $page || ! in_array( $page, ARD_admin_page_slugs(), true ) || ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$data      = get_file_data( WPADR_PATH . 'app-dashboard.php', array( 'Name' => 'Plugin Name', 'Version' => 'Version' ) );
	$installed = (string) $data['Version'];
	$latest    = '';
	if ( class_exists( 'TW_Release_Updater' ) && method_exists( 'TW_Release_Updater', 'releases' ) ) {
		$releases = TW_Release_Updater::releases();
		$latest   = isset( $releases['mobile-admin']['version'] ) ? (string) $releases['mobile-admin']['version'] : '';
	}

	$dot = 'width:8px;height:8px;border-radius:50%;display:inline-block;flex-shrink:0;';
	echo '<div class="ard-version" style="display:flex;align-items:center;gap:10px;margin:14px 20px 0 2px;font-size:13px;color:#50575e;">';
	echo '<strong style="color:#1d2327;">' . esc_html( $data['Name'] ) . '</strong> <span>v' . esc_html( $installed ) . '</span>';

	if ( '' === $latest ) {
		echo '<span style="display:inline-flex;align-items:center;gap:5px;font-size:12px;color:#9ca3af;" title="' . esc_attr__( 'Impossibile leggere le release da GitHub in questo momento.', 'wp-app-dashboard' ) . '">';
		echo '<span style="' . esc_attr( $dot ) . 'border:2px solid #d1d5db;box-sizing:border-box;"></span>' . esc_html__( 'Controllo non disponibile', 'wp-app-dashboard' ) . '</span>';
	} elseif ( version_compare( $installed, $latest, '>=' ) ) {
		echo '<span style="display:inline-flex;align-items:center;gap:5px;font-size:12px;color:#16a34a;">';
		echo '<span style="' . esc_attr( $dot ) . 'background:#22c55e;box-shadow:0 0 4px rgba(34,197,94,.6);"></span>' . esc_html__( 'Aggiornato', 'wp-app-dashboard' ) . '</span>';
	} else {
		$url = is_multisite() ? network_admin_url( 'update-core.php' ) : admin_url( 'update-core.php' );
		/* translators: %s: latest version, e.g. 2.22.0 */
		$label = sprintf( __( 'Aggiornamento disponibile (v%s)', 'wp-app-dashboard' ), $latest );
		echo '<span style="display:inline-flex;align-items:center;gap:5px;font-size:12px;color:#6b7280;">';
		echo '<span style="' . esc_attr( $dot ) . 'background:#9ca3af;"></span>';
		echo current_user_can( 'update_plugins' ) ? '<a href="' . esc_url( $url ) . '" style="color:inherit;">' . esc_html( $label ) . '</a>' : esc_html( $label );
		echo '</span>';
	}
	echo '</div>';
} );
