/* Menù combinati sul sito delle sedi: popup «Fai il tuo menù» e «Aggiungi una bibita» (mobile-admin 2.20.0: bibite in sezioni a fisarmonica). */
(function () {
	'use strict';
	var cfg = window.ardComboWeb;
	if (!cfg || typeof HTMLDialogElement === 'undefined') { return; }
	var t = cfg.i18n;

	function el(tag, cls, text) {
		var n = document.createElement(tag);
		if (cls) { n.className = cls; }
		if (text != null) { n.textContent = text; }
		return n;
	}
	function pic(src) {
		if (!src) { return el('span', 'ard-cw__ph'); }
		var i = el('img', 'ard-cw__img'); i.src = src; i.alt = ''; i.loading = 'lazy'; i.width = 64; i.height = 64;
		return i;
	}
	function post(url, data) {
		var body = new URLSearchParams();
		body.append('nonce', cfg.nonce);
		Object.keys(data || {}).forEach(function (k) {
			var v = data[k];
			if (v && typeof v === 'object') { Object.keys(v).forEach(function (s) { body.append(k + '[' + s + ']', v[s]); }); }
			else { body.append(k, v); }
		});
		return fetch(url, { method: 'POST', credentials: 'same-origin', body: body })
			.then(function (r) { return r.json(); })
			.then(function (j) { if (!j || !j.success) { throw new Error((j && j.data && j.data.message) || t.error); } return j; });
	}

	var dlg = el('dialog', 'ard-cw');
	dlg.setAttribute('aria-labelledby', 'ard-cw-title');
	var box = el('div', 'ard-cw__box');
	var close = el('button', 'ard-cw__close');
	close.type = 'button'; close.setAttribute('aria-label', t.close); close.innerHTML = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
	var head = el('div', 'ard-cw__head');
	var title = el('h2', 'ard-cw__title'); title.id = 'ard-cw-title';
	var lead = el('p', 'ard-cw__lead');
	var body = el('div', 'ard-cw__body');
	var msg = el('p', 'ard-cw__msg'); msg.setAttribute('role', 'alert');
	var foot = el('div', 'ard-cw__foot');
	head.append(title, lead);
	box.append(close, head, body, msg, foot);
	dlg.append(box);
	document.body.append(dlg);

	var busy = false;
	var done = false;
	function setBusy(b) { busy = b; dlg.classList.toggle('is-busy', b); dlg.querySelectorAll('button').forEach(function (x) { x.disabled = b; }); }
	function fail(e) { setBusy(false); msg.textContent = e.message || t.error; }
	function added() { done = true; window.location.reload(); }
	function skipAll() {
		if (done) { return; }
		done = true;
		post(cfg.ajax.skip).catch(function () {});
		if (dlg.open) { dlg.close(); }
	}

	/* Step 1: menus */
	function showMenus() {
		title.textContent = t.menuTitle; lead.textContent = t.menuText; msg.textContent = '';
		body.replaceChildren(); foot.replaceChildren();
		var current = cfg.menus[0].key;
		var picks = {};
		var list = el('div', 'ard-cw__menus');
		list.setAttribute('role', 'radiogroup');
		list.setAttribute('aria-label', t.menuTitle);
		var parts = el('div', 'ard-cw__parts');
		var cta = el('button', 'ard-cw__btn ard-cw__btn--primary'); cta.type = 'button';

		function renderParts() {
			var menu = cfg.menus.filter(function (m) { return m.key === current; })[0];
			parts.replaceChildren();
			menu.groups.forEach(function (g) {
				var group = cfg.groups[g];
				if (!group) { return; }
				if (!picks[g] || !group.products.some(function (p) { return p.id === picks[g]; })) { picks[g] = group.products[0].id; }
				var fs = el('fieldset', 'ard-cw__part');
				fs.append(el('legend', 'ard-cw__legend', t.choose + ': ' + group.label.toLowerCase()));
				var row = el('div', 'ard-cw__options');
				group.products.forEach(function (p) {
					var lab = el('label', 'ard-cw__option');
					var inp = el('input'); inp.type = 'radio'; inp.name = 'ard-cw-' + g; inp.value = p.id; inp.checked = picks[g] === p.id;
					inp.addEventListener('change', function () { picks[g] = p.id; });
					lab.append(inp, pic(p.image), el('span', 'ard-cw__name', p.name));
					row.append(lab);
				});
				fs.append(row);
				parts.append(fs);
			});
			cta.textContent = t.addMenu + ' · ' + menu.price;
		}

		cfg.menus.forEach(function (m) {
			var b = el('button', 'ard-cw__menu'); b.type = 'button';
			b.setAttribute('role', 'radio');
			b.setAttribute('aria-checked', m.key === current ? 'true' : 'false');
			b.append(el('span', 'ard-cw__menu-emoji', m.emoji || ''), el('span', 'ard-cw__menu-name', m.label), el('span', 'ard-cw__menu-price', m.price));
			b.addEventListener('click', function () {
				current = m.key;
				list.querySelectorAll('.ard-cw__menu').forEach(function (x) { x.setAttribute('aria-checked', x === b ? 'true' : 'false'); });
				renderParts();
			});
			list.append(b);
		});
		renderParts();

		var no = el('button', 'ard-cw__btn ard-cw__btn--ghost', t.noThanks); no.type = 'button';
		no.addEventListener('click', function () { if (cfg.drinks.length) { showDrinks(); } else { skipAll(); } });
		cta.addEventListener('click', function () {
			if (busy) { return; }
			setBusy(true); msg.textContent = '';
			var menu = cfg.menus.filter(function (m) { return m.key === current; })[0];
			var chosen = {};
			menu.groups.forEach(function (g) { chosen[g] = picks[g]; });
			post(cfg.ajax.menu, { menu: current, picks: chosen }).then(added).catch(fail);
		});
		body.append(list, parts);
		foot.append(no, cta);
	}

	/* Step 2: a drink */
	function showDrinks() {
		title.textContent = t.drinkTitle; lead.textContent = t.drinkText; msg.textContent = '';
		body.replaceChildren(); foot.replaceChildren();
		var sections = (cfg.sections || []).filter(function (s) { return s.products && s.products.length; });
		if (sections.length > 1) {
			// One accordion per category (Upsell sections of mobile-admin): closed, the customer opens the one they want.
			var acc = el('div', 'ard-cw__sections');
			sections.forEach(function (s) {
				var d = el('details', 'ard-cw__section');
				var sum = el('summary', 'ard-cw__summary');
				if (s.emoji) { sum.append(el('span', 'ard-cw__section-emoji', s.emoji)); }
				sum.append(el('span', 'ard-cw__section-name', s.label), el('span', 'ard-cw__section-count', String(s.products.length)));
				sum.lastChild.setAttribute('aria-hidden', 'true');
				var list = el('ul', 'ard-cw__drinks');
				s.products.forEach(function (p) { list.append(drinkItem(p)); });
				d.append(sum, list);
				acc.append(d);
			});
			body.append(acc);
		} else {
			var ul = el('ul', 'ard-cw__drinks');
			cfg.drinks.forEach(function (p) { ul.append(drinkItem(p)); });
			body.append(ul);
		}
		var go = el('button', 'ard-cw__btn ard-cw__btn--ghost', t.continue); go.type = 'button';
		go.addEventListener('click', skipAll);
		foot.append(go);
		box.focus();
	}

	function drinkItem(p) {
		var li = el('li', 'ard-cw__drink');
		var info = el('span', 'ard-cw__drink-info');
		info.append(el('span', 'ard-cw__name', p.name), el('span', 'ard-cw__price', p.price));
		var b = el('button', 'ard-cw__btn ard-cw__btn--small', t.add); b.type = 'button';
		b.setAttribute('aria-label', t.add + ': ' + p.name);
		b.addEventListener('click', function () {
			if (busy) { return; }
			setBusy(true); msg.textContent = '';
			post(cfg.ajax.drink, { product: p.id }).then(added).catch(fail);
		});
		li.append(pic(p.image), info, b);
		return li;
	}

	close.addEventListener('click', skipAll);
	dlg.addEventListener('cancel', function (e) { e.preventDefault(); if (!busy) { skipAll(); } });
	dlg.addEventListener('click', function (e) { if (e.target === dlg && !busy) { skipAll(); } });

	if (cfg.menus.length) { showMenus(); } else if (cfg.drinks.length) { showDrinks(); } else { return; }
	box.tabIndex = -1;
	dlg.showModal();
	box.focus();
})();
