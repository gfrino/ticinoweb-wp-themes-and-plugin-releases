<?php
/** Compatibility for existing WPML query-string URLs after migration. */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/** Keep bookmarked and indexed ?lang= URLs in the requested language. */
function lagalpi_redirect_legacy_language_url() {
    if ( defined( 'ICL_SITEPRESS_VERSION' ) || ! function_exists( 'twtr_get_language_url' )
        || is_admin() || wp_doing_ajax() || wp_doing_cron()
        || ! isset( $_GET['lang'] ) || ! is_string( $_GET['lang'] )
        || ! isset( $_SERVER['REQUEST_METHOD'] ) || $_SERVER['REQUEST_METHOD'] !== 'GET'
        || isset( $_GET['wc-ajax'] ) || isset( $_GET['add-to-cart'] ) || isset( $_GET['lsesi'] ) ) {
        return;
    }
    $lang = sanitize_key( wp_unslash( $_GET['lang'] ) );
    $languages = twtr_get_languages( true );
    if ( ! isset( $languages[ $lang ] ) ) {
        return;
    }
    $uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
    // Use the configured host, never a client-supplied Host header.
    $url = rtrim( get_option( 'home' ), '/' ) . '/' . ltrim( $uri, '/' );
    $target = twtr_get_language_url( $lang, remove_query_arg( 'lang', $url ) );
    if ( wp_safe_redirect( $target, 301, 'lagAlpi language migration' ) ) {
        exit;
    }
}
add_action( 'template_redirect', 'lagalpi_redirect_legacy_language_url', 1 );
