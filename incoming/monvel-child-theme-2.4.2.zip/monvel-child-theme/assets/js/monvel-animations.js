/**
 * Monvél - Custom Animations (GSAP)
 */
document.addEventListener('DOMContentLoaded', () => {
    
    // Check if GSAP is loaded
    if (typeof gsap === 'undefined') {
        console.warn('GSAP is not loaded.');
        return;
    }

    // Register ScrollTrigger
    gsap.registerPlugin(ScrollTrigger);

    // 1. Header Scroll Effect
    const header = document.querySelector('.monvel-header');
    if (header) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) {
                header.classList.add('is-scrolled');
            } else {
                header.classList.remove('is-scrolled');
            }
        });
    }

    // 1b. Front Page Video Audio Toggle
    const videoElement = document.getElementById('mv-front-video');
    const audioToggleBtn = document.getElementById('mv-audio-toggle');
    if(videoElement && audioToggleBtn) {
        const iconMuted = audioToggleBtn.querySelector('.mv-icon-muted');
        const iconUnmuted = audioToggleBtn.querySelector('.mv-icon-unmuted');
        
        audioToggleBtn.addEventListener('click', () => {
            if(videoElement.muted) {
                videoElement.muted = false;
                if(iconMuted) iconMuted.style.display = 'none';
                if(iconUnmuted) iconUnmuted.style.display = 'block';
            } else {
                videoElement.muted = true;
                if(iconMuted) iconMuted.style.display = 'block';
                if(iconUnmuted) iconUnmuted.style.display = 'none';
            }
        });
    }

    // Mobile Menu Toggle
    const mobileToggle = document.querySelector('.mv-mobile-toggle');
    const mainNav = document.querySelector('.main-navigation');
    if (mobileToggle && mainNav) {
        mobileToggle.addEventListener('click', () => {
            mainNav.classList.toggle('is-open');
            mobileToggle.classList.toggle('is-active');
            document.body.classList.toggle('body-no-scroll');
        });
    }

    // Mobile Submenu Accordion
    const mobileHasChildren = document.querySelectorAll('.main-navigation ul li.menu-item-has-children > a');
    mobileHasChildren.forEach(item => {
        // Create toggle element to guarantee alignment
        const toggleBtn = document.createElement('span');
        toggleBtn.className = 'mv-submenu-toggle';
        toggleBtn.innerHTML = '+';
        item.appendChild(toggleBtn);

        item.addEventListener('click', (e) => {
            if (window.innerWidth <= 768) {
                e.preventDefault();
                const parentLi = item.parentElement;
                parentLi.classList.toggle('is-active');
                
                // Toggle the icon
                const toggle = item.querySelector('.mv-submenu-toggle');
                if (toggle) {
                    toggle.innerHTML = parentLi.classList.contains('is-active') ? '−' : '+';
                }
            }
        });
    });

    // 2. Hero Swiper & Animations
    if (typeof Swiper !== 'undefined' && document.querySelector('.mv-hero-swiper')) {
        const heroSwiper = new Swiper('.mv-hero-swiper', {
            loop: true,
            effect: 'fade', // Elegant fade transition between slides
            fadeEffect: {
                crossFade: true
            },
            speed: 1000,
            autoplay: {
                delay: 5000,
                disableOnInteraction: false,
                pauseOnMouseEnter: true,
            },
            navigation: {
                nextEl: '.swiper-button-next-custom',
                prevEl: '.swiper-button-prev-custom',
            },
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            on: {
                init: function () {
                    animateSlideContent(this.slides[this.activeIndex]);
                },
                slideChangeTransitionStart: function () {
                    // Hide content of previous slide
                    const prevSlide = this.slides[this.previousIndex];
                    if(prevSlide) {
                        gsap.set(prevSlide.querySelectorAll('.mv-product-wrapper, .mv-hero-content'), { opacity: 0 });
                    }
                    // Animate new slide
                    animateSlideContent(this.slides[this.activeIndex]);
                }
            }
        });

        // Function to animate content inside the active slide
        function animateSlideContent(slide) {
            if (!slide) return;
            const productWrapper = slide.querySelector('.mv-product-wrapper');
            const hatImg = slide.querySelector('.hero-hat-img');
            const content = slide.querySelector('.mv-hero-content');
            
            const tl = gsap.timeline();
            
            if (productWrapper) {
                tl.fromTo(productWrapper, {
                    x: 50, opacity: 0
                }, {
                    x: 0, opacity: 1,
                    duration: 1.2, ease: "power3.out"
                }, 0.2);

                if (hatImg) {
                    // Re-apply elegant floating effect for PNGs
                    gsap.to(hatImg, {
                        y: -15, duration: 2.5, repeat: -1, yoyo: true, ease: "sine.inOut", delay: 1.4
                    });

                    // Handle hover scaling via GSAP to prevent CSS transform conflicts
                    productWrapper.addEventListener('mouseenter', () => {
                        gsap.to(hatImg, { scale: 1.05, filter: "drop-shadow(0 40px 50px rgba(0,0,0,0.35))", duration: 0.4, ease: "power2.out", overwrite: "auto" });
                    });
                    productWrapper.addEventListener('mouseleave', () => {
                        gsap.to(hatImg, { scale: 1, filter: "drop-shadow(0 30px 40px rgba(0,0,0,0.25))", duration: 0.4, ease: "power2.out", overwrite: "auto" });
                    });
                }
            }

            if (content) {
                tl.fromTo(content, {
                    x: -50, opacity: 0
                }, {
                    x: 0, opacity: 1,
                    duration: 1, ease: "power3.out"
                }, 0.3);
            }
        }
    }

    // Parallax Typography
    const heroText = document.querySelector('.mv-hero-typography');
    if (heroText) {
        gsap.to(heroText, {
            xPercent: -10, // Moves left on scroll
            ease: "none",
            scrollTrigger: {
                trigger: ".mv-hero",
                start: "top top",
                end: "bottom top",
                scrub: true
            }
        });
    }

    // 3. Product Grid Animations
    const productCards = document.querySelectorAll('.mv-product-card');
    
    productCards.forEach((card, index) => {
        gsap.from(card, {
            y: 100,
            opacity: 0,
            duration: 1,
            ease: "power3.out",
            scrollTrigger: {
                trigger: card,
                start: "top 85%", // Starts animation when element is 85% down the viewport
                toggleActions: "play none none reverse"
            }
        });

        // Subtle parallax for product images inside cards
        const img = card.querySelector('.mv-product-image');
        if (img) {
            gsap.to(img, {
                yPercent: -15,
                ease: "none",
                scrollTrigger: {
                    trigger: card,
                    start: "top bottom",
                    end: "bottom top",
                    scrub: true
                }
            });
        }
    });

    // 4. Tooltip Interactions
    const wrappers = document.querySelectorAll('.mv-product-wrapper');
    wrappers.forEach(wrapper => {
        const closeBtn = wrapper.querySelector('.mv-tooltip-close');
        const tooltip = wrapper.querySelector('.mv-product-tooltip');
        
        if (closeBtn && tooltip) {
            // Close tooltip on click
            closeBtn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                
                // Hide tooltip forcefully
                tooltip.style.opacity = '0';
                tooltip.style.visibility = 'hidden';
                tooltip.style.transform = 'translateY(20px)';
                
                // Reset on mouse leave so it can open again
                wrapper.addEventListener('mouseleave', () => {
                    tooltip.style.opacity = '';
                    tooltip.style.visibility = '';
                    tooltip.style.transform = '';
                }, { once: true });
            });
        }
    });

    // 5c. Final CTA Section
    const initFinalCTA = () => {
        const finalCta = document.querySelector('.mv-final-cta-section');
        if (!finalCta) return;

        gsap.fromTo(finalCta.querySelectorAll('.mv-final-eyebrow, .mv-final-title, .mv-final-subtitle, .mv-final-btn'),
            { y: 40, opacity: 0 },
            {
                scrollTrigger: {
                    trigger: finalCta,
                    start: "top 80%",
                },
                y: 0,
                opacity: 1,
                duration: 1,
                stagger: 0.15,
                ease: "power3.out"
            }
        );
    };



    // 6. Custom Single Product UI (WooCommerce Integration)
    const initSingleProductUI = () => {
        const productLayout = document.querySelector('.mv-single-product-layout');
        if (!productLayout) return;

        const swatches = document.querySelectorAll('.mv-swatch-single');
        const colorText = document.getElementById('mv-active-color-text');
        const glow = document.getElementById('mv-single-glow');
        const mainImg = document.getElementById('mv-single-main-img');
        const priceContainer = document.getElementById('mv-single-price');
        const customAddToCartBtn = document.getElementById('mv-custom-add-to-cart');
        const galleryContainer = document.querySelector('.mv-single-gallery');
        let originalGalleryHTML = galleryContainer ? galleryContainer.innerHTML : '';
        
        // Use jQuery to listen for WooCommerce variation events
        if (typeof jQuery !== 'undefined') {
            const $form = jQuery('.variations_form');
            
            // Handle Custom Swatch Click
            swatches.forEach(swatch => {
                swatch.addEventListener('click', () => {
                    if (swatch.classList.contains('disabled')) {
                        // Show tooltip on mobile tap briefly
                        swatch.classList.add('show-tooltip');
                        setTimeout(() => swatch.classList.remove('show-tooltip'), 2500);
                        return;
                    }
                    
                    // Update UI
                    swatches.forEach(s => s.classList.remove('active'));
                    swatch.classList.add('active');
                    
                    const colorName = swatch.getAttribute('data-name');
                    const colorVal = swatch.getAttribute('data-value');
                    const bgColor = swatch.style.backgroundColor;
                    const glowBg = swatch.getAttribute('data-glow-bg') || bgColor;
                    const attributeName = swatch.getAttribute('data-attribute'); // e.g. attribute_pa_colore
                    
                    if (colorText) colorText.textContent = colorName;
                    if (glow) {
                        // Create a softer version of the hex for the glow
                        glow.style.background = glowBg;
                        glow.style.opacity = '0.015'; 
                    }
                    
                    // Sync with hidden WooCommerce Select
                    if ($form.length && attributeName) {
                        let $select = $form.find(`select[name="${attributeName}"]`);
                        if ($select.length === 0) {
                            // Try alternative attribute name (e.g. attribute_colore instead of attribute_pa_colore)
                            const altName = attributeName.replace('attribute_pa_', 'attribute_');
                            $select = $form.find(`select[name="${altName}"]`);
                        }
                        
                        if ($select.length) {
                            $select.val(colorVal).trigger('change');
                        }
                        
                        // Auto-fill all other hidden attributes to satisfy WooCommerce validation
                        $form.find('.variations select').each(function() {
                            const currentName = jQuery(this).attr('name');
                            // If it's not the color select and has no value
                            if (currentName !== attributeName && currentName !== attributeName.replace('attribute_pa_', 'attribute_')) {
                                if (!jQuery(this).val()) {
                                    // Find first valid option value (not empty)
                                    const firstValidValue = jQuery(this).find('option[value!=""]').first().val();
                                    if (firstValidValue) {
                                        jQuery(this).val(firstValidValue).trigger('change');
                                    }
                                }
                            }
                        });
                    }
                });
            });

            // Handle WooCommerce found_variation event via delegation
            jQuery(document).on('found_variation', '.variations_form', function(event, variation) {
                // Update Main Image
                if (variation.image && variation.image.full_src && mainImg) {
                    mainImg.classList.add('fade-out');
                    setTimeout(() => {
                        mainImg.src = variation.image.full_src;
                        mainImg.classList.remove('fade-out');
                    }, 400); // Wait for CSS transition
                }

                // Update Gallery
                if (galleryContainer) {
                    if (variation.variation_gallery_images && variation.variation_gallery_images.length > 0) {
                        let newGalleryHTML = '';
                        variation.variation_gallery_images.forEach(function(img) {
                            newGalleryHTML += '<div class="mv-gallery-thumb" data-full="' + img.full_src + '"><img src="' + img.thumb_src + '" alt="' + img.alt + '"></div>';
                        });
                        galleryContainer.innerHTML = newGalleryHTML;
                    } else {
                        galleryContainer.innerHTML = originalGalleryHTML;
                    }
                }
                
                // Update Price
                if (variation.price_html && priceContainer) {
                    priceContainer.innerHTML = variation.price_html;
                }
                
                // Enable Custom Add to Cart Button
                if (customAddToCartBtn) {
                    customAddToCartBtn.classList.remove('disabled');
                    const ctaText = customAddToCartBtn.querySelector('.mv-cta-text');
                    if (ctaText) {
                        let totalExtraPrice = 0;
                        const addonInputs = document.querySelectorAll('.mv-addon-input');
                        addonInputs.forEach(activeInput => {
                            if (activeInput.checked) {
                                totalExtraPrice += parseFloat(activeInput.getAttribute('data-price') || 0);
                            }
                        });
                        if (totalExtraPrice > 0) {
                            ctaText.textContent = 'Aggiungi al carrello • + CHF ' + totalExtraPrice.toFixed(2);
                        } else {
                            ctaText.textContent = 'Aggiungi al carrello';
                        }
                    }
                }
            });

            // Handle WooCommerce reset_image event via delegation
            jQuery(document).on('reset_image', '.variations_form', function() {
                if (customAddToCartBtn) {
                    customAddToCartBtn.classList.add('disabled');
                    const ctaText = customAddToCartBtn.querySelector('.mv-cta-text');
                    if (ctaText) ctaText.textContent = 'Seleziona un colore';
                }
                
                // Restore original gallery
                if (galleryContainer) {
                    galleryContainer.innerHTML = originalGalleryHTML;
                }
            });

            // Handle Add-ons Checkboxes
            const addonInputs = document.querySelectorAll('.mv-addon-input');
            if (addonInputs.length > 0) {
                const targetForm = jQuery('.mv-hidden-wc-form form');
                
                addonInputs.forEach(input => {
                    input.addEventListener('change', () => {
                        // Toggle active class on card for styling
                        const card = input.closest('.mv-addon-row-compact');
                        if (card) {
                            if (input.checked) {
                                card.classList.add('is-active');
                            } else {
                                card.classList.remove('is-active');
                            }
                        }
                        
                        // Update hidden inputs in the form
                        targetForm.find('.mv-addon-hidden-input').remove(); // Clear existing
                        
                        let totalExtraPrice = 0;
                        addonInputs.forEach(activeInput => {
                            if (activeInput.checked) {
                                const index = activeInput.getAttribute('data-index');
                                const price = parseFloat(activeInput.getAttribute('data-price') || 0);
                                totalExtraPrice += price;
                                
                                // Append hidden input
                                targetForm.append('<input type="hidden" class="mv-addon-hidden-input" name="monvel_addon_' + index + '" value="1">');
                            }
                        });
                        
                        // Optionally update button text if customAddToCartBtn exists
                        if (customAddToCartBtn && !customAddToCartBtn.classList.contains('disabled')) {
                            const ctaText = customAddToCartBtn.querySelector('.mv-cta-text');
                            if (ctaText) {
                                if (totalExtraPrice > 0) {
                                    ctaText.textContent = 'Aggiungi al carrello • + CHF ' + totalExtraPrice.toFixed(2);
                                } else {
                                    ctaText.textContent = 'Aggiungi al carrello';
                                }
                            }
                        }
                    });
                });

                // Handle Mobile Info Toggles
                const infoBtns = document.querySelectorAll('.mv-addon-info-btn');
                infoBtns.forEach(btn => {
                    btn.addEventListener('click', (e) => {
                        e.preventDefault();
                        const row = btn.closest('.mv-addon-row-compact');
                        if (row) {
                            row.classList.toggle('is-expanded');
                        }
                    });
                });
            }

            // Handle Custom Add To Cart Click
            if (customAddToCartBtn) {
                customAddToCartBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    if (!customAddToCartBtn.classList.contains('disabled') && $form.length) {
                        // Find and click the hidden standard WooCommerce add to cart button
                        const wcButton = $form.find('.single_add_to_cart_button');
                        if (wcButton.length) {
                            wcButton.trigger('click');
                        } else {
                            $form.submit();
                        }
                    }
                });
            }
        }

        // Custom Gallery interactions (Event Delegation to support dynamic DOM changes)
        if (productLayout) {
            productLayout.addEventListener('click', (e) => {
                const thumb = e.target.closest('.mv-gallery-thumb');
                if (thumb) {
                    const fullUrl = thumb.getAttribute('data-full');
                    if (fullUrl && mainImg) {
                        mainImg.classList.add('fade-out');
                        setTimeout(() => {
                            mainImg.src = fullUrl;
                            mainImg.classList.remove('fade-out');
                        }, 400);
                    }
                }
            });
        }
        
        // Auto-select swatch based on URL parameter or fallback to first available
        setTimeout(() => {
            if (!document.querySelector('.mv-swatch-single.active')) {
                const urlParams = new URLSearchParams(window.location.search);
                let targetSwatch = null;

                // Check URL for pre-selected variation attributes
                for (const [key, value] of urlParams.entries()) {
                    if (key.startsWith('attribute_')) {
                        targetSwatch = Array.from(swatches).find(s => 
                            s.getAttribute('data-attribute') === key && 
                            s.getAttribute('data-value') === value &&
                            !s.classList.contains('disabled')
                        );
                        if (targetSwatch) break;
                    }
                }

                // Fallback to first available if no valid match found in URL
                if (!targetSwatch) {
                    targetSwatch = Array.from(swatches).find(s => !s.classList.contains('disabled'));
                }

                if (targetSwatch) {
                    targetSwatch.click();
                }
            }
        }, 50);
    };
    
    // 7. Custom Related Product Section Animation
    const initRelatedSection = () => {
        const relatedSection = document.querySelector('.mv-related-section');
        if (!relatedSection) return;

        gsap.fromTo(relatedSection.querySelectorAll('.mv-related-eyebrow, .mv-related-title, .mv-related-desc, .mv-related-btn, .mv-related-image-wrapper'),
            {
                y: 50,
                opacity: 0
            },
            {
                scrollTrigger: {
                    trigger: relatedSection,
                    start: "top 80%",
                },
                y: 0,
                opacity: 1,
                duration: 1,
                stagger: 0.15,
                ease: "power3.out"
            }
        );
    };

    // 8. Shop Archive Page Animation
    const initShopArchive = () => {
        const shopMain = document.querySelector('.mv-collection-showcase-main');
        if (!shopMain) return;

        // Animate Hero
        gsap.fromTo(shopMain.querySelectorAll('.mv-shop-title, .mv-shop-subtitle'),
            { y: 30, opacity: 0 },
            {
                y: 0,
                opacity: 1,
                duration: 1,
                stagger: 0.2,
                ease: "power3.out",
                delay: 0.2
            }
        );

        // Animate Grid Items
        const cards = shopMain.querySelectorAll('.mv-collection-panel');
        if (cards.length > 0) {
            gsap.fromTo(cards,
                { y: 50, opacity: 0 },
                {
                    scrollTrigger: {
                        trigger: '.mv-collection-showcase-main ul.products',
                        start: "top 85%",
                    },
                    y: 0,
                    opacity: 1,
                    duration: 1,
                    stagger: 0.15,
                    ease: "power2.out"
                }
            );
        }

        // Swatch Interactivity
        cards.forEach(panel => {
            const swatches = panel.querySelectorAll('.mv-swatch');
            const mainImg = panel.querySelector('.mv-panel-main-img');
            const glow = panel.querySelector('.mv-panel-glow');
            
            // Set initial glow based on active swatch
            const activeSwatch = panel.querySelector('.mv-swatch.active');
            if(activeSwatch && glow) {
                const hex = activeSwatch.getAttribute('data-color-hex');
                glow.style.background = `radial-gradient(circle, ${hex}33 0%, rgba(255,255,255,0) 70%)`;
            }

            swatches.forEach(swatch => {
                swatch.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation(); // prevent panel link click
                    
                    if (swatch.classList.contains('disabled')) {
                        // Show tooltip on mobile tap briefly
                        swatch.classList.add('show-tooltip');
                        setTimeout(() => swatch.classList.remove('show-tooltip'), 2500);
                        return;
                    }
                    
                    // Update active class
                    swatches.forEach(s => s.classList.remove('active'));
                    swatch.classList.add('active');

                    // Update Image
                    const newImgUrl = swatch.getAttribute('data-img-url');
                    if(newImgUrl && mainImg) {
                        mainImg.style.opacity = 0;
                        setTimeout(() => {
                            mainImg.src = newImgUrl;
                            mainImg.style.opacity = 1;
                        }, 300);
                    }

                    // Update Glow Color (Adding '33' to hex for ~20% opacity)
                    const hex = swatch.getAttribute('data-color-hex');
                    if(glow) {
                        glow.style.background = `radial-gradient(circle, ${hex}33 0%, rgba(255,255,255,0) 70%)`;
                    }
                });
            });
        });
    };

    // 9. LOGO DROP Easter Egg Logic (Hidden Brand Moment)
    const initLogoDrop = () => {
        const easterEggBtns = document.querySelectorAll('.mv-easter-egg-btn');
        const overlay = document.getElementById('logoDropOverlay');
        const closeBtn = document.getElementById('logoDropClose');
        const logo = document.getElementById('interactiveLogo');
        const ringFill = document.querySelector('.mv-progress-ring-fill');
        const resultArea = document.getElementById('logoDropResult');
        const canvasArea = document.getElementById('logoDropCanvas');
        const loadingText = document.querySelector('.mv-loading-text');
        const instructionText = document.querySelector('.mv-instruction-text');

        if (easterEggBtns.length === 0 || !overlay || !logo) {
            return;
        }

        let holdTimer;
        let isHolding = false;
        let isUnlocked = false;
        
        // Progress ring length is approx 478 (2 * pi * 76)
        const RING_LENGTH = 478;

        // Open Modal
        easterEggBtns.forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                overlay.classList.add('is-active');
                document.body.style.overflow = 'hidden';
            });
        });

        // Close Modal
        const closeModal = () => {
            overlay.classList.remove('is-active');
            document.body.style.overflow = '';
            
            // Reset everything after transition
            setTimeout(() => {
                isUnlocked = false;
                isHolding = false;
                gsap.killTweensOf(ringFill);
                ringFill.style.strokeDashoffset = RING_LENGTH;
                logo.classList.remove('is-holding');
                canvasArea.style.display = 'flex';
                canvasArea.style.opacity = 1;
                resultArea.classList.remove('is-visible');
                resultArea.style.display = 'none';
                if(instructionText) instructionText.style.display = 'inline';
                if(loadingText) loadingText.style.display = 'none';
            }, 500);
        };

        closeBtn.addEventListener('click', closeModal);
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) closeModal();
        });
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && overlay.classList.contains('is-active')) {
                closeModal();
            }
        });

        // Prevent Context Menu on Logo for mobile long press
        logo.addEventListener('contextmenu', (e) => {
            e.preventDefault();
        });

        const startHold = (e) => {
            if (e && e.cancelable !== false) e.preventDefault();
            if (isUnlocked) return;
            isHolding = true;
            logo.classList.add('is-holding');
            
            if(instructionText) instructionText.style.display = 'none';
            if(loadingText) loadingText.style.display = 'inline';

            // Animate ring fill over 2 seconds
            gsap.to(ringFill, {
                strokeDashoffset: 0,
                duration: 2,
                ease: "power1.inOut",
                onComplete: unlockDrop
            });
        };

        const endHold = (e) => {
            if (e && e.type !== 'contextmenu' && e.cancelable !== false) e.preventDefault();
            if (isUnlocked || !isHolding) return;
            isHolding = false;
            logo.classList.remove('is-holding');
            
            if(instructionText) instructionText.style.display = 'inline';
            if(loadingText) loadingText.style.display = 'none';

            // Revert ring fill
            gsap.killTweensOf(ringFill);
            gsap.to(ringFill, {
                strokeDashoffset: RING_LENGTH,
                duration: 0.5,
                ease: "power2.out"
            });
        };

        const unlockDrop = () => {
            isUnlocked = true;
            logo.classList.remove('is-holding');
            
            // Flash effect
            const tl = gsap.timeline();
            tl.to(canvasArea, {
                opacity: 0,
                scale: 1.1,
                filter: "brightness(2)",
                duration: 0.3,
                ease: "power2.out",
                onComplete: () => {
                    canvasArea.style.display = 'none';
                    resultArea.style.display = 'block';
                    // Trigger CSS animation for the result area
                    setTimeout(() => {
                        resultArea.classList.add('is-visible');
                    }, 50);
                }
            })
            // Reset scale/filter for future opens
            .set(canvasArea, { scale: 1, filter: "brightness(1)" });
        };

        // Attach hold events
        logo.addEventListener('mousedown', startHold);
        logo.addEventListener('touchstart', startHold, {passive: false});
        
        window.addEventListener('mouseup', endHold);
        window.addEventListener('touchend', endHold);
        logo.addEventListener('mouseleave', endHold);
        logo.addEventListener('touchcancel', endHold);
    };

    initSingleProductUI();
    initRelatedSection();
    

    
    // Initialize Final CTA Section
    initFinalCTA();

    // Initialize Shop Archive
    initShopArchive();

    // Init functions
    initLogoDrop();

    // 10. WooCommerce Toast Auto-hide
    const initWooNoticesToast = () => {
        const notices = document.querySelectorAll('.woocommerce-message, .woocommerce-error, .woocommerce-info');
        if(notices.length > 0) {
            notices.forEach(notice => {
                // Rimuovi testo estraneo se c'è
                notice.childNodes.forEach(node => {
                    // WooCommerce a volte inserisce testo libero
                });
                
                // Auto nascondi dopo 5 secondi
                setTimeout(() => {
                    notice.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
                    notice.style.opacity = '0';
                    notice.style.transform = 'translate(-50%, 20px)';
                    setTimeout(() => notice.remove(), 500);
                }, 5000);
            });
        }
    };
    initWooNoticesToast();

    
    
    // 11. Fly to Cart Animation & AJAX Add to Cart (No Page Reload)
    const initFlyToCart = () => {
        const cartForms = document.querySelectorAll('form.cart');
        
        cartForms.forEach(form => {
            form.addEventListener('submit', function(e) {
                if (form.dataset.isSubmitting === 'true') return;
                e.preventDefault(); // Blocca sempre il submit standard
                form.dataset.isSubmitting = 'true';

                const cartBtn = document.querySelector('.mv-cart-btn, .cart-contents, .header-cart, .site-header-cart');
                const submitBtn = form.querySelector('button[type="submit"]');
                const originalText = submitBtn ? submitBtn.innerText : '';
                
                if (submitBtn) {
                    submitBtn.innerText = 'AGGIUNTA...';
                    submitBtn.style.opacity = '0.7';
                    submitBtn.style.pointerEvents = 'none';
                }

                // --- 1. Animazione Volo (Fly-to-cart) ---
                let sourceImg = document.querySelector('.mv-panel-main-img') || 
                                document.querySelector('.woocommerce-product-gallery__image img') || 
                                document.querySelector('img.attachment-woocommerce_thumbnail');

                if (sourceImg && cartBtn) {
                    const srcRect = sourceImg.getBoundingClientRect();
                    const targetRect = cartBtn.getBoundingClientRect();

                    const flyingImg = sourceImg.cloneNode(true);
                    flyingImg.style.position = 'fixed';
                    flyingImg.style.zIndex = '999999';
                    flyingImg.style.top = srcRect.top + 'px';
                    flyingImg.style.left = srcRect.left + 'px';
                    flyingImg.style.width = srcRect.width + 'px';
                    flyingImg.style.height = srcRect.height + 'px';
                    flyingImg.style.margin = '0';
                    flyingImg.style.pointerEvents = 'none';
                    flyingImg.style.transition = 'all 0.8s cubic-bezier(0.25, 1, 0.5, 1)';
                    flyingImg.style.opacity = '0.9';
                    flyingImg.style.objectFit = 'contain';
                    flyingImg.style.background = 'transparent';
                    
                    document.body.appendChild(flyingImg);

                    requestAnimationFrame(() => {
                        flyingImg.style.top = (targetRect.top + targetRect.height / 2 - 20) + 'px';
                        flyingImg.style.left = (targetRect.left + targetRect.width / 2 - 20) + 'px';
                        flyingImg.style.width = '40px';
                        flyingImg.style.height = '40px';
                        flyingImg.style.opacity = '0';
                        flyingImg.style.transform = 'scale(0.1) rotate(15deg)';
                    });

                    setTimeout(() => {
                        flyingImg.remove();
                        cartBtn.style.transition = 'transform 0.2s cubic-bezier(0.175, 0.885, 0.32, 1.275)';
                        cartBtn.style.transform = 'scale(1.25)';
                        setTimeout(() => {
                            cartBtn.style.transform = 'scale(1)';
                        }, 200);
                    }, 800);
                }

                // --- 2. AJAX Add to Cart (Silenzioso, senza ricaricare la pagina) ---
                const formData = new FormData(form);
                if (submitBtn && submitBtn.name && submitBtn.value) {
                    formData.append(submitBtn.name, submitBtn.value);
                } else if (submitBtn && submitBtn.name) {
                    formData.append(submitBtn.name, '1');
                } else {
                    formData.append('add-to-cart', form.querySelector('[name="add-to-cart"]') ? form.querySelector('[name="add-to-cart"]').value : '');
                }

                fetch(window.location.href, {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'Accept': 'text/html, application/xhtml+xml, application/xml'
                    }
                }).then(response => {
                    form.dataset.isSubmitting = 'false';
                    if (submitBtn) {
                        submitBtn.innerText = 'AGGIUNTO!';
                        submitBtn.style.opacity = '1';
                        setTimeout(() => {
                            submitBtn.innerText = originalText;
                            submitBtn.style.pointerEvents = 'auto';
                        }, 3000);
                    }

                    // Aggiorna il carrello WooCommerce (contatore in header)
                    if (typeof jQuery !== 'undefined') {
                        jQuery(document.body).trigger('wc_fragment_refresh');
                    }

                    // Mostra il Toast Dinamico
                    showMvToast('Prodotto aggiunto al carrello');

                }).catch(err => {
                    console.error('AJAX add to cart failed:', err);
                    form.submit(); // fallback d'emergenza
                });
            });
        });

        // Funzione per generare il Toast JS puro
        const showMvToast = (message) => {
            document.querySelectorAll('.woocommerce-message.mv-dynamic-toast').forEach(el => el.remove());
            const toast = document.createElement('div');
            toast.className = 'woocommerce-message mv-dynamic-toast';
            toast.setAttribute('role', 'alert');
            toast.innerHTML = `
                <span>✓ ${message}</span>
                <a href="/carrello" class="button wc-forward">Visualizza carrello</a>
            `;
            document.body.appendChild(toast);

            setTimeout(() => {
                if(toast) {
                    toast.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
                    toast.style.opacity = '0';
                    toast.style.transform = 'translate(-50%, 20px) !important';
                    setTimeout(() => toast.remove(), 500);
                }
            }, 5000);
        };
    };

    // Keep the legacy interceptor inactive: cart submission belongs to WooCommerce
    // and the existing initSingleProductUI handler, including their validation.

    // 12. Generic Data-GSAP Fade-Up Handler (per pagine Contatti e future)
    const fadeUpElements = document.querySelectorAll('[data-gsap="fade-up"]');
    if (fadeUpElements.length > 0) {
        fadeUpElements.forEach(el => {
            let delay = parseFloat(el.getAttribute('data-delay')) || 0;
            gsap.fromTo(el, 
                { y: 40, opacity: 0 },
                {
                    y: 0, 
                    opacity: 1, 
                    duration: 1.2, 
                    ease: "power3.out", 
                    delay: delay,
                    scrollTrigger: {
                        trigger: el,
                        start: "top 90%",
                        toggleActions: "play none none reverse"
                    }
                }
            );
        });
    }


    // 13. Generic Data-GSAP Parallax Handler
    const parallaxElements = document.querySelectorAll('[data-gsap="parallax"]');
    if (parallaxElements.length > 0) {
        parallaxElements.forEach(el => {
            let speed = parseFloat(el.getAttribute('data-speed')) || 0.1;
            // Negative speed means moving down on scroll (slower than scroll)
            // Positive speed means moving up faster
            gsap.to(el, {
                yPercent: -100 * speed,
                ease: "none",
                scrollTrigger: {
                    trigger: el.parentElement,
                    start: "top bottom",
                    end: "bottom top",
                    scrub: true
                }
            });
        });
    }

    // 14. WooCommerce Logout Confirmation
    const logoutLinks = document.querySelectorAll('.woocommerce-MyAccount-navigation-link--customer-logout a');
    if (logoutLinks.length > 0) {
        logoutLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const logoutUrl = this.getAttribute('href');
                
                // Create modal if it doesn't exist
                if (!document.querySelector('.mv-logout-modal-overlay')) {
                    const modalHtml = `
                        <div class="mv-logout-modal-overlay">
                            <div class="mv-logout-modal">
                                <div class="mv-logout-title">Vuoi uscire dal tuo account?</div>
                                <div class="mv-logout-text">Sei sicuro di voler effettuare il logout?</div>
                                <div class="mv-logout-actions">
                                    <button class="mv-logout-btn-cancel">No, resta qui</button>
                                    <a href="${logoutUrl}" class="mv-logout-btn-confirm">Esci</a>
                                </div>
                            </div>
                        </div>
                    `;
                    document.body.insertAdjacentHTML('beforeend', modalHtml);
                    
                    const overlay = document.querySelector('.mv-logout-modal-overlay');
                    const cancelBtn = document.querySelector('.mv-logout-btn-cancel');
                    
                    const closeModal = () => {
                        overlay.classList.remove('is-active');
                    };
                    
                    cancelBtn.addEventListener('click', closeModal);
                    overlay.addEventListener('click', (e) => {
                        if (e.target === overlay) closeModal();
                    });
                    document.addEventListener('keydown', (e) => {
                        if (e.key === 'Escape' && overlay.classList.contains('is-active')) closeModal();
                    });
                }
                
                // Show modal
                setTimeout(() => {
                    const overlay = document.querySelector('.mv-logout-modal-overlay');
                    if (overlay) {
                        const confirmBtn = overlay.querySelector('.mv-logout-btn-confirm');
                        confirmBtn.setAttribute('href', logoutUrl);
                        overlay.classList.add('is-active');
                    }
                }, 10);
            });
        });
    }

});
