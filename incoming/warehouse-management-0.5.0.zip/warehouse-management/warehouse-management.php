<?php
/*
Plugin Name: Warehouse Management
Plugin URI: https://ticinoweb.com/
Description: Gestione dei lotti di magazzino per WooCommerce: quantità, scadenze e date di rifornimento per prodotto e variazione, lotti scalati a ogni ordine, limiti di acquisto in base ai lotti, filtri (scadenze, produttori, più e meno venduti) e report Excel nell'elenco prodotti.
Version: 0.5.0
Requires at least: 5.8
Requires PHP: 7.4
WC requires at least: 7.0
Author: ticinoWEB
Author URI: https://ticinoweb.com/
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: warehouse-management
Domain Path: /languages
Update URI: https://github.com/gfrino/ticinoweb-wp-themes-and-plugin-releases
*/

defined( 'ABSPATH' ) || exit;

define( 'WHM_VERSION', '0.5.0' );
define( 'WHM_DIR_PATH', plugin_dir_path( __FILE__ ) );
define( 'WHM_DIR_URL', plugin_dir_url( __FILE__ ) );
// Versione di includes/tw-release-updater.php (tenerla allineata al suo header).
define( 'WHM_RELEASE_UPDATER_VERSION', '1.2.0' );

// Aggiornamenti dal repo release ticinoWEB (vedi l'header Update URI).
require_once WHM_DIR_PATH . 'includes/tw-release-updater.php';

$phpexcel_loaded = false;
if ( file_exists( WHM_DIR_PATH . 'lib/vendor/autoload.php' ) ) {
	require_once WHM_DIR_PATH . 'lib/vendor/autoload.php'; // PhpSpreadsheet
	$phpexcel_loaded = true;
}
define( 'WHM_PHPEXCEL', $phpexcel_loaded );

// Compatibile con HPOS: le query sugli ordini usano whm_order_sql_parts().
add_action( 'before_woocommerce_init', function () {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
	}
} );

add_action( 'init', function () {
	load_plugin_textdomain( 'warehouse-management', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
} );

/**
 * Installa/aggiorna il mu-plugin "ticinoWEB Release Updater", che tiene
 * aggiornati i plugin ticinoWEB anche se questo venisse disattivato.
 */
function whm_install_release_updater() {
	if ( ! class_exists( 'TW_Release_Updater' ) || TW_Release_Updater::mu_is_current( WHM_RELEASE_UPDATER_VERSION ) ) {
		return;
	}
	if ( get_site_transient( 'whm_release_updater_failed' ) ) {
		return;
	}
	$result = TW_Release_Updater::install_mu( WHM_DIR_PATH . 'includes/tw-release-updater.php' );
	if ( is_wp_error( $result ) ) {
		set_site_transient( 'whm_release_updater_failed', $result->get_error_message(), 12 * HOUR_IN_SECONDS );
	}
}
add_action( 'admin_init', function () {
	if ( current_user_can( is_multisite() ? 'manage_network_plugins' : 'activate_plugins' ) ) {
		whm_install_release_updater();
	}
}, 20 );

require_once WHM_DIR_PATH . 'inc/exports.php';
require_once WHM_DIR_PATH . 'inc/hooks/admin/admin-hooks.php';
require_once WHM_DIR_PATH . 'inc/product_columns.php';
require_once WHM_DIR_PATH . 'inc/functions.php';
require_once WHM_DIR_PATH . 'inc/hooks/front/front-hooks.php';
require_once WHM_DIR_PATH . 'inc/order-lots.php';
