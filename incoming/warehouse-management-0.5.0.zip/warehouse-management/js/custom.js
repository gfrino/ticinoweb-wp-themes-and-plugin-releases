document.addEventListener('DOMContentLoaded', function() {
    const productType = whmCustomData.productType;
    //console.log(productType);
    const repeaterElements = document.querySelectorAll('.acf-field-repeater');
    // Loop through each repeater element
    repeaterElements.forEach(element => {
        // Check if the element has a data-name attribute with value 'lot_management'
        if (element.dataset.name === 'lot_management' && productType == 'variable' ) {
            element.style.display = 'none';
        }
    });
// Event listener for the add-new-lot-whm click event
   //document.getElementById('add-new-lot-whm').addEventListener('click', addLot);

});

window.addEventListener('load', function() {
    const repeaterElements = document.querySelectorAll('.acf-field-repeater');
    const productType = whmCustomData.productType;

// Loop through each repeater element
    repeaterElements.forEach(element => {
        // Check if the element has a data-name attribute with value 'lot_management'
        if (element.dataset.name === 'lot_management' && productType == 'variable' ) {
            element.style.display = 'none';
        }
    });
});

// 0.5.0: jQuery esplicito (in admin "$" non e' definito) e niente alert():
// al quinto lotto il pulsante "Aggiungi lotto" sparisce.
function addMoreLot( index ) {
    var $ = window.jQuery;
    var field = $('#lot_management_selected_hidden_' + index);
    var currentValue = parseInt(field.val(), 10) || 1;
    if (currentValue >= 5) {
        $('#lot-add-more-index-' + index).hide();
        return;
    }
    var newValue = currentValue + 1;
    field.val(newValue);
    $('#lot-group-' + newValue + '-' + index).show();
    if (newValue >= 5) {
        $('#lot-add-more-index-' + index).hide();
    }
}
