<?php
/**
 * Report Excel di magazzino: generato su richiesta e scaricato in modo protetto.
 *
 * 0.3.0: il file non sta piu' nella cartella pubblica del plugin ma in
 * uploads/.../whm-exports/ (protetta) e si scarica solo dal backend.
 * 0.5.0: il report non si rigenera piu' a ogni apertura dell'elenco prodotti
 * filtrato (una query su tutti i prodotti e un file Excel ogni volta). L'elenco
 * ricorda solo il filtro attivo, per utente; il file si crea quando si preme
 * "Scarica Excel", si invia e si cancella subito.
 *
 * @package warehouse-management
 */

defined( 'ABSPATH' ) || exit;

/**
 * Cartella protetta per i report (uploads del sito corrente, anche in multisite).
 *
 * @return string
 */
function whm_export_dir() {
	$uploads = wp_upload_dir();
	$dir     = trailingslashit( $uploads['basedir'] ) . 'whm-exports';

	if ( ! is_dir( $dir ) ) {
		wp_mkdir_p( $dir );
	}
	if ( ! file_exists( $dir . '/.htaccess' ) ) {
		file_put_contents( $dir . '/.htaccess', "Deny from all\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}
	if ( ! file_exists( $dir . '/index.php' ) ) {
		file_put_contents( $dir . '/index.php', "<?php\n// Silence is golden.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}

	return $dir;
}

/**
 * Percorso del report Excel dell'utente corrente.
 *
 * @return string
 */
function whm_export_file_path() {
	return whm_export_dir() . '/exported_products-' . get_current_user_id() . '.xlsx';
}

/**
 * Ricorda il filtro attivo nell'elenco prodotti (un'ora, per utente).
 *
 * @param array $args Argomenti della query principale dei prodotti.
 */
function whm_remember_export_query( $args ) {
	if ( ! is_array( $args ) || ! get_current_user_id() ) {
		return;
	}
	$args['posts_per_page'] = -1;
	$args['no_found_rows']  = false;
	$args['fields']         = '';
	set_transient( 'whm_export_args_' . get_current_user_id(), $args, HOUR_IN_SECONDS );
}

/**
 * URL di download del report (con nonce).
 *
 * @return string
 */
function whm_export_download_url() {
	return wp_nonce_url( admin_url( 'admin-post.php?action=whm_download_export' ), 'whm_download_export' );
}

/**
 * Download: genera il report con l'ultimo filtro usato (o tutti i prodotti
 * pubblicati se non c'e' filtro), lo invia e lo cancella.
 */
function whm_download_export() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		wp_die( esc_html__( 'Non hai i permessi per scaricare il report di magazzino.', 'warehouse-management' ), 403 );
	}
	check_admin_referer( 'whm_download_export' );

	if ( ! WHM_PHPEXCEL ) {
		wp_die( esc_html__( 'La libreria per creare i file Excel non è disponibile: reinstalla il plugin.', 'warehouse-management' ), 500 );
	}

	$args = get_transient( 'whm_export_args_' . get_current_user_id() );
	if ( ! is_array( $args ) || empty( $args['post_type'] ) || 'product' !== $args['post_type'] ) {
		$args = array(
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
		);
	}

	$file = whm_generate_and_save_csv( new WP_Query( $args ) );
	if ( ! $file || ! is_readable( $file ) ) {
		wp_die( esc_html__( 'Nessun prodotto corrisponde al filtro scelto: cambia filtro e riprova.', 'warehouse-management' ), 404 );
	}

	nocache_headers();
	header( 'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
	header( 'Content-Disposition: attachment; filename="report-magazzino-' . gmdate( 'Y-m-d' ) . '.xlsx"' );
	header( 'Content-Length: ' . filesize( $file ) );
	readfile( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	wp_delete_file( $file );
	exit;
}
add_action( 'admin_post_whm_download_export', 'whm_download_export' );
