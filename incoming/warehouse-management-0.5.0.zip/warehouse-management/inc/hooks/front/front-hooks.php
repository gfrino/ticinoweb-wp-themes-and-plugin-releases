<?php
/**
 * Custom function to restrict adding more quantity to cart than available lot for single and variable products
 */
function whm_restrict_quantity_by_lot( $passed, $product_id, $quantity, $variation_id = '', $variations = array() ) {
	// Get lot for single product or variation

	$lot_qty = 0;
	$cart = WC()->cart;
	$cart_qty = $cart->get_cart_contents_count();
    $product = wc_get_product($product_id);
    if( $product->is_type('variable') ){
        //This Logic For Variable Products
         if(isset($variation_id) && $variation_id != '' && $variation_id > 0 ){
            // echo "<pre>".print_r($variation_id, true)."</pre>";
             $lots_object = getLotDataByVariationId( $variation_id );


             //Case 1
             if ( !empty($lots_object) && !empty($lots_object[0]) ) {
                 $total_lots = $lots_object['total_lots'];

                 if($total_lots < 1 ){
                     wc_add_notice( sprintf( __( 'The maximum quantity allowed for this product is %s.', 'woocommerce' ), 0 ), 'error' );
                     return false;
                 }else{
                     if ($quantity > $total_lots) {
	                     $checkTotalQtyInCart = getTotalQtyByProductId( $variation_id, 'variable' );
	                     $available_qty = $total_lots - $checkTotalQtyInCart;
	                     wc_add_notice(sprintf(__('The maximum quantity allowed for this product is %s.', 'woocommerce'), $available_qty), 'error');
                         return false;
                     }
                 }
             }
             //End Case 1
         }

         //Case 2
        if(!empty($cart) && $cart_qty != 0 ){
            foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
                $cart_variation_id = $cart_item['variation_id'];
                $lots_object = getLotDataByVariationId($cart_variation_id);
                if (!empty($lots_object) && !empty($lots_object[0]) ) {
                    $total_lots = $lots_object['total_lots'];
                    if($cart_variation_id == $variation_id ){
                        $item_quantity = $cart_item['quantity'] + $quantity;
                    }else{
                        $item_quantity = $cart_item['quantity'];
                    }

                    if($total_lots < 1 ){
                        $cart->set_quantity($cart_item_key, 0);
                        wc_add_notice( sprintf( __( 'The maximum quantity allowed for this product is %s.', 'woocommerce' ), 0 ), 'error' );
                        return false;
                    }else{
                        if ($item_quantity > $total_lots ) {
	                        $checkTotalQtyInCart = getTotalQtyByProductId( $cart_variation_id, 'variable' );
	                        $available_qty = $total_lots - $checkTotalQtyInCart;
                            //$cart->set_quantity($cart_item_key, $total_lots);
                            wc_add_notice(sprintf(__('The maximum quantity allowed for this product is %s.', 'woocommerce'), $available_qty ), 'error');
                            return false;
                        }
                    }
                }
            }
            //End Case 2
        }else{
            //Case 3
            $lots_object = getLotDataByVariationId($variation_id);
            if ( !empty($lots_object) && !empty($lots_object[0]) ) {
                $total_lots = $lots_object['total_lots'];
                if($total_lots == 0 ){
                    wc_add_notice( sprintf( __( 'The maximum quantity allowed for this product is %s.', 'woocommerce' ), 0 ), 'error' );
                    return false;
                }else{
                    if ( isset($total_lots) && $total_lots > 0 && $quantity > $total_lots ) {
	                    $checkTotalQtyInCart = getTotalQtyByProductId( $variation_id, 'variable' );
	                    $available_qty = $total_lots - $checkTotalQtyInCart;
                        // Quantity exceeds lot, so prevent adding to cart
                        wc_add_notice( sprintf( __( 'The maximum quantity allowed for this product is %s.', 'woocommerce' ), $available_qty ), 'error' );
                        return false;
                    }
                }
            }
            //End Case 3
        }

    }else{

        //This Logic For Single Products
        if(isset($product_id) && $product_id > 0 ){
            $latest_prd_qty = get_cart_product_quantity_whm($product_id);
            $quantity = $quantity + $latest_prd_qty;
            $lots_object = getActiveLotIdsByProductID($product_id);

            //Case 1
            if (!empty($lots_object)) {
                $total_lots = $lots_object['total_lots'];
                if($total_lots < 1 ){
                    wc_add_notice( sprintf( __( 'The maximum quantity allowed for this product is %s.', 'woocommerce' ), 0 ), 'error' );
                    return false;
                }else{
	                $checkTotalQtyInCart = getTotalQtyByProductId( $product_id );
	                $available_qty = $total_lots - $checkTotalQtyInCart;
                    //echo "<pre> Line 18 {$product_id} ".print_r($quantity, true)."</pre>";
                    //echo "<pre> Line 19 {$product_id} ".print_r($total_lots, true)."</pre>";
                    if ($quantity > $total_lots) {
                        wc_add_notice(sprintf(__('The maximum quantity allowed for this product is %s.', 'woocommerce'), $available_qty), 'error');
                        return false;
                    }
                }
            }
            //End Case 1
        }

        if(!empty($cart) && $cart_qty != 0 ){
            foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
                $lots_object = getActiveLotIdsByProductID($product_id);
                if (!empty($lots_object)) {
                    $cat_product_id = $cart_item['product_id'];
                    $total_lots = $lots_object['total_lots'];

                    if($cat_product_id == $product_id ){
                        $item_quantity = $cart_item['quantity'] + $quantity;
                    }else{
                        $item_quantity = $cart_item['quantity'];
                    }

                    if($total_lots < 1 ){
                        $cart->set_quantity($cart_item_key, 0);
                        wc_add_notice( sprintf( __( 'The maximum quantity allowed for this product is %s.', 'woocommerce' ), 0 ), 'error' );
                        return false;
                    }else{

                        if ($item_quantity > $total_lots) {
	                        $checkTotalQtyInCart = getTotalQtyByProductId( $product_id );
	                        $available_qty = $total_lots - $checkTotalQtyInCart;
                            //$cart->set_quantity($cart_item_key, $total_lots);
                            wc_add_notice(sprintf(__('The maximum quantity allowed for this product is %s.', 'woocommerce'), $available_qty), 'error');
                            return false;
                        }
                    }
                }
            }
        }else{
            $lots_object = getActiveLotIdsByProductID($product_id);
            if ( !empty($lots_object) ) {
                $total_lots = $lots_object['total_lots'];
                if($total_lots == 0 ){
                    wc_add_notice( sprintf( __( 'The maximum quantity allowed for this product is %s.', 'woocommerce' ), 0 ), 'error' );
                    return false;
                }else{
                    if ( isset($total_lots) && $total_lots > 0 && $quantity > $total_lots ) {
	                    $checkTotalQtyInCart = getTotalQtyByProductId( $product_id );
	                    $available_qty = $total_lots - $checkTotalQtyInCart;
                        // Quantity exceeds lot, so prevent adding to cart
                        wc_add_notice( sprintf( __( 'The maximum quantity allowed for this product is %s.', 'woocommerce' ), $available_qty ), 'error' );
                        return false;
                    }
                }

            }
        }
    }


	return $passed;
}

add_filter( 'woocommerce_add_to_cart_validation', 'whm_restrict_quantity_by_lot', 10, 5 );

function getActiveLotIdsByProductID( $product_id, $interval = 'today' ) {

    if(empty($product_id))
        return ;

    $product = wc_get_product($product_id);
    $active_lot_data = array();

    if( $product->is_type('variable') ){
        $active_lot_data = getVariationLotDataByProduct( $product_id );
    }else{

        $total_lots = 0;
        $lots = get_field( 'lot_management', $product_id );

        if ( !empty($lots) ) {
            $acf_key_index = 0;
            foreach ( $lots as $lot_data ) {
                $expiry_date_str = $lot_data['expiry_date'];
                $expiry_date = '';
                $acf_key_expiry_date = "lot_management_{$acf_key_index}_expiry_date";
                $acf_key_qty = "lot_management_{$acf_key_index}_qty";
                if(isset($expiry_date_str) && $expiry_date_str != '' ){
                    $expiry_date_explode = explode('/', $expiry_date_str );
                    $timestamp = mktime(0, 0, 0, $expiry_date_explode[1], $expiry_date_explode[0], $expiry_date_explode[2]);
                    $expiry_date = date("Y-m-d", $timestamp);
                }

                if( strtotime($expiry_date) >= strtotime('midnight', current_time('timestamp')) ){
                    if($interval == 'today' && $expiry_date!= ''){
                        if( isset($lot_data['qty']) && $lot_data['qty'] > 0 && $expiry_date && strtotime( $expiry_date ) >= strtotime( 'today' )){
                            $active_lot_data[] = array(
                                'acf_key_date' => $acf_key_expiry_date,
                                'acf_key_qty' => $acf_key_qty,
                                'product_id' => $product_id,
                                'lot_data' => $lot_data
                            );
                            $total_lots += $lot_data['qty'];
                        }
                    }elseif($interval == '7' && $expiry_date!= ''){
                        $expiry_date_timestamp = strtotime($expiry_date);
                        $expiry_date_warning_timestamp = strtotime('+7 days', strtotime('midnight', current_time('timestamp')));
                        if (isset($lot_data['qty']) && $lot_data['qty'] > 0 && $expiry_date_timestamp && $expiry_date_timestamp <= $expiry_date_warning_timestamp ) {
                            $active_lot_data[] = array(
                                'acf_key_date' => $acf_key_expiry_date,
                                'acf_key_qty' => $acf_key_qty,
                                'product_id' => $product_id,
                                'lot_data' => $lot_data
                            );
                            $total_lots += $lot_data['qty'];
                        }
                    }elseif($interval == '2' && $expiry_date!= ''){
                        $expiry_date_timestamp = strtotime($expiry_date);
                        $expiry_date_warning_timestamp = strtotime('+2 days', strtotime('midnight', current_time('timestamp')));
                        if (isset($lot_data['qty']) && $lot_data['qty'] > 0 && $expiry_date_timestamp && $expiry_date_timestamp <= $expiry_date_warning_timestamp ) {
                            $active_lot_data[] = array(
                                'acf_key_date' => $acf_key_expiry_date,
                                'acf_key_qty' => $acf_key_qty,
                                'product_id' => $product_id,
                                'lot_data' => $lot_data
                            );
                            $total_lots += $lot_data['qty'];
                        }
                    }
                }
                $acf_key_index++;
            }
            $active_lot_data['total_lots'] = $total_lots;
        }
    }
    return $active_lot_data;
}

function getVariationLotDataByProduct( $product_id )
{
    if(empty($product_id))
        return;
    $lot_data = array();
    $product = wc_get_product($product_id);
    if( $product->is_type('variable') ){
        $variations = $product->get_available_variations();
        if (!empty($variations)) {
            // Loop through each variation
            foreach ($variations as $variation) {
                $variation_id = $variation['variation_id'];
                $lot_data[] = getLotDataByVariationId( $variation_id );
            }
        }
    }
    return $lot_data;
}

function getLotDataByVariationId( $variation_id, $interval = 'today' )
{
    if(empty($variation_id))
        return;

    $lot_data = array();
    $total_lots = 0;
    for ($v = 1; $v <= 5; $v++ ){
       $lot_management_name =  get_post_meta( $variation_id, 'lot_management_name_'.$v, true );
       $lot_management_qty  = get_post_meta( $variation_id, 'lot_management_qty_'.$v, true );
    $expiry_date  = get_post_meta( $variation_id, 'lot_management_expiry_date_'.$v, true );
    $rifornimento_date  = get_post_meta( $variation_id, 'lot_management_rifornimento_date_'.$v, true );
       //Check Future Lots data
        if( strtotime($expiry_date) >= strtotime('midnight', current_time('timestamp')) ){
            if($interval == 'today' && $expiry_date!= ''){
                if( isset($lot_management_qty) && $lot_management_qty > 0 && $expiry_date && strtotime( $expiry_date ) >= strtotime( 'today' )){
                    $lot_data[] = array(
                        'lot' => $lot_management_name,
                        'expiry_date' => $expiry_date,
                        'rifornimento_date' => $rifornimento_date,
                        'qty' => $lot_management_qty,
                        'key_index' => $v,
                        'variation_id' => $variation_id
                    );
                    $total_lots += $lot_management_qty;
                }
            }elseif($interval == '7' && $expiry_date!= ''){
                $expiry_date_timestamp = strtotime($expiry_date);
                $expiry_date_warning_timestamp = strtotime('+7 days', strtotime('midnight', current_time('timestamp')));
                if (isset($lot_management_qty) && $lot_management_qty > 0 && $expiry_date_timestamp && $expiry_date_timestamp <= $expiry_date_warning_timestamp ) {
                    $lot_data[] = array(
                        'lot' => $lot_management_name,
                        'expiry_date' => $expiry_date,
                        'rifornimento_date' => $rifornimento_date,
                        'qty' => $lot_management_qty,
                        'key_index' => $v,
                        'variation_id' => $variation_id
                    );
                    $total_lots += $lot_management_qty;
                }
            }elseif($interval == '2' && $expiry_date!= ''){
                $expiry_date_timestamp = strtotime($expiry_date);
                $expiry_date_warning_timestamp = strtotime('+2 days', strtotime('midnight', current_time('timestamp')));
                if (isset($lot_management_qty) && $lot_management_qty > 0 && $expiry_date_timestamp && $expiry_date_timestamp <= $expiry_date_warning_timestamp ) {
                    $lot_data[] = array(
                        'lot' => $lot_management_name,
                        'expiry_date' => $expiry_date,
                        'rifornimento_date' => $rifornimento_date,
                        'qty' => $lot_management_qty,
                        'key_index' => $v,
                        'variation_id' => $variation_id
                    );
                    $total_lots += $lot_management_qty;
                }
            }
        }
    }
    $lot_data['total_lots'] = $total_lots;
    return $lot_data;
}
function getActiveLotIdsByProductIDBCK( $product_id ) {
	if(empty($product_id))
		return ;

	$lots = get_field( 'lot_management', $product_id );
	$active_lot_data = array();
	$total_lots = 0;
	if ( !empty($lots) ) {
		$acf_key_index = 0;
		foreach ( $lots as $lot_data ) {
			$expiry_date_str = $lot_data['expiry_date'];
			$expiry_date = '';
			$acf_key_expiry_date = "lot_management_{$acf_key_index}_expiry_date";
			$acf_key_qty = "lot_management_{$acf_key_index}_qty";
			if(isset($expiry_date_str) && $expiry_date_str != '' ){
				$expiry_date_explode = explode('/', $expiry_date_str );
				$timestamp = mktime(0, 0, 0, $expiry_date_explode[1], $expiry_date_explode[0], $expiry_date_explode[2]);
				$expiry_date = date("Y-m-d", $timestamp);
			}
			if( isset($lot_data['qty']) && $lot_data['qty'] > 0 && $expiry_date && strtotime( $expiry_date ) >= strtotime( 'today' )){
				$active_lot_data[] = array(
					'acf_key_date' => $acf_key_expiry_date,
					'acf_key_qty' => $acf_key_qty,
					'product_id' => $product_id,
					'lot_data' => $lot_data
				);
				$total_lots += $lot_data['qty'];
			}
			$acf_key_index++;
		}
		$active_lot_data['total_lots'] = $total_lots;
	}

	return $active_lot_data;
}
function get_cart_product_quantity_whm($product_id) {
	// Get the cart object
	$cart = WC()->cart;

	// Initialize the quantity variable
	$quantity = 0;

	// Loop through each item in the cart
	foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
		// Check if the product ID matches
		if ($cart_item['product_id'] == $product_id) {
			// Get the latest quantity for this product
			$quantity += $cart_item['quantity'];
		}
	}

	return $quantity;
}
// 0.5.0: la riduzione dei lotti sugli ordini e' solo in inc/order-lots.php (prima c'era anche
// whm_reduce_stock_on_order_processing qui, che scalava una seconda volta i prodotti semplici).

/**
 * @param $product_id
 * @param $lot_key
 * @param $new_qty
 *
 * @return void
 */
function update_lot_data_in_database( $product_id, $lot_key, $new_qty ) {
	if( empty( $product_id ) || empty( $lot_key )  )
		return;

	update_post_meta( $product_id, $lot_key, $new_qty );
}

function getTotalQtyByProductId( $product_id, $type = 'simple' ) {

    if(empty($product_id))
		return;

	// Get the WooCommerce cart instance
	$cart = WC()->cart;

	// Get the cart contents
	$cart_items = $cart->get_cart();

	// Initialize quantity variable
	$quantity = 0;
	$type_key = 'product_id';
	if($type == 'variable'){
		$type_key = 'variation_id';
	}
	foreach ($cart_items as $cart_item_key => $cart_item) {
		if ($cart_item[$type_key] == $product_id) {
			$quantity += $cart_item['quantity'];
		}
	}
	return $quantity;

}