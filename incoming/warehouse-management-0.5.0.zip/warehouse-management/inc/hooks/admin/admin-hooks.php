<?php
// Add custom columns to product admin screen
add_action( 'admin_enqueue_scripts', 'lagalpi_enqueue_whm_admin_styles' );
add_filter( 'manage_product_posts_columns', 'lagalpi_whm_product_columns', 99 );
add_action( 'manage_product_posts_custom_column', 'lagalpi_custom_product_column_content', 10, 2 );

// Step 1: Add Custom Filter Options with JavaScript functionality
function whm_post_type_filter_custom() {
	global $typenow;

	//echo "<pre>".print_r(get_post_meta(17517), true)."</pre>";
	if ( 'shop_order' === $typenow ) {
		whm_order_post_type_filter_custom();
	}

	if ( 'product' === $typenow ) {
		whm_product_post_type_filter_custom();
	}
}
add_action('restrict_manage_posts', 'whm_post_type_filter_custom');

// Step 2: Filter Products by Expiry with Dynamic Filtering
function whm_admin_post_type_query_custom($query) {
	global $pagenow, $post_type, $wpdb;
	if ( 'product' === $pagenow  || $post_type == 'product') {
		whm_product_post_type_query_custom( $query );
	}

	if ( is_admin() && 'edit.php' === $pagenow && 'shop_order' === $post_type && isset( $_GET['product_id'] ) && $_GET['product_id'] && $query->query['post_type'] == 'shop_order') {
		$product_id = intval( $_GET['product_id'] );
		$orders = whm_get_orders_ids_by_product_id($product_id);
		if(!empty($orders)){
			$query->set('post__in', $orders);
        }
	}
}
add_action('pre_get_posts', 'whm_admin_post_type_query_custom');

// Elenco ordini HPOS (WooCommerce > Ordini): stesso filtro per prodotto.
add_action( 'woocommerce_order_list_table_restrict_manage_orders', function ( $order_type ) {
	if ( 'shop_order' === $order_type ) {
		$_REQUEST['post_type'] = 'shop_order'; // whm_order_post_type_filter_custom() controlla questo parametro.
		whm_order_post_type_filter_custom();
	}
} );
add_filter( 'woocommerce_shop_order_list_table_prepare_items_query_args', function ( $args ) {
	if ( current_user_can( 'administrator' ) && ! empty( $_GET['product_id'] ) ) {
		$orders           = whm_get_orders_ids_by_product_id( absint( $_GET['product_id'] ) );
		$args['post__in'] = ! empty( $orders ) ? array_map( 'absint', $orders ) : array( 0 );
	}
	return $args;
} );

add_action( 'woocommerce_variation_options_pricing', 'whm_add_custom_field_to_variations', 10, 3 );
function whm_add_custom_field_to_variations( $loop, $variation_data, $variation ) {
    // Output a heading for the custom options group
	echo '<style>
		.custom-options-group{
			display: inline-block;
		    width: 100%;
		}
		.custom-options-group .lot-group{
		    display: flex;
		    justify-content: space-between;
		    border-left: 1px solid #ccc;
		    border-bottom: 1px solid #ccc;
		}
		.custom-options-group .lot-group .form-field input[type=date]{
		border-style: solid;
		    border-width: 1px;
		    width: 95%;
		}

	.custom-options-group .lot-group .form-field {  
		flex-basis: 34%;  
		border-right: 1px solid #ccc;
	    margin: 0;
	    padding: 10px 10px;
    }
	.lot-container {
        display: flex;
	    justify-content: space-between;
	    border: 1px solid #ccc;
	    padding: 0px 0;
    }
    .item {
        flex-basis: 34%;
	    text-align: center;
	    border-left: 1px solid #ccc;
	    border: 1px solid #ccc;
	    padding: 10px 0;
	    font-weight: bold;
    }
    ._parcel_lot_number_'.$variation->ID.'_field, ._expiration_date_'.$variation->ID.'_field {
    	display: none;
    }
</style>';
    echo '<div class="custom-options-group ">';
    $lot_active_number = 1;
    echo '<h4>' . esc_html__('Lotti di magazzino', 'warehouse-management') . '</h4>';
    echo '<div class="lot-container">
    <div class="item">' . esc_html__( 'Lotto', 'warehouse-management' ) . '</div>
    <div class="item">' . esc_html__( 'Quantità', 'warehouse-management' ) . '</div>
    <div class="item">' . esc_html__( 'Scadenza', 'warehouse-management' ) . '</div>
    <div class="item">' . esc_html__( 'Rifornimento', 'warehouse-management' ) . '</div>
</div>';
    //echo '<h5>' . __('Lot Section 1', 'warehouse-management') . '</h5>';
    echo '<div class="lot-group" id="lot-group-1-'.$loop.'" >';
        woocommerce_wp_text_input(
            array(
            'id' => 'lot_management_name_1_[' . $loop . ']',
            'class' => 'short', 'placeholder' => __('Nome lotto', 'warehouse-management'),
            'value' => get_post_meta( $variation->ID, 'lot_management_name_1', true ),
        )

        );

    woocommerce_wp_text_input(
        array(
            'id'          => 'lot_management_qty_1_[' . $loop . ']',
            'type' => 'number',
            'placeholder' => __('Quantità', 'warehouse-management'),
            'value'       => get_post_meta( $variation->ID, 'lot_management_qty_1', true ),
            'custom_attributes' => array(
                'step' 	=> 'any',
                'min'	=> '0'
            )
        )
    );

    woocommerce_wp_text_input(array(
        'id' => 'lot_management_expiry_date_1_[' . $loop . ']',
        'placeholder' => __('Scadenza', 'warehouse-management'),
        'value' => get_post_meta($variation->ID, 'lot_management_expiry_date_1', true),
        'type' => 'date'
    ));

     woocommerce_wp_text_input(array(
        'id' => 'lot_management_rifornimento_date_1_[' . $loop . ']',
        'placeholder' => __('Rifornimento', 'warehouse-management'),
        'value' => get_post_meta($variation->ID, 'lot_management_rifornimento_date_1', true),
        'type' => 'date'
    ));


    echo '</div>'; // Close Lot Group



    $lot_management_name_2 = get_post_meta( $variation->ID, 'lot_management_name_2', true );
    if(isset($lot_management_name_2) && $lot_management_name_2 != '' ){
        echo '<div class="lot-group" id="lot-group-2-'.$loop.'">';
        $lot_active_number +=1;
    }else{
        echo '<div class="lot-group" id="lot-group-2-'.$loop.'" style="display: none;">';
    }
    woocommerce_wp_text_input(
        array(
            'id' => 'lot_management_name_2_[' . $loop . ']',
            'class' => 'short', 'placeholder' => __('Nome lotto', 'warehouse-management'),
            'value' => get_post_meta( $variation->ID, 'lot_management_name_2', true ),
        )

    );

    woocommerce_wp_text_input(
        array(
            'id'          => 'lot_management_qty_2_[' . $loop . ']',
            'type' => 'number',
            'placeholder' => __('Quantità', 'warehouse-management'),
            'value'       => get_post_meta( $variation->ID, 'lot_management_qty_2', true ),
            'custom_attributes' => array(
                'step' 	=> 'any',
                'min'	=> '0'
            )
        )
    );

    woocommerce_wp_text_input(array(
        'id' => 'lot_management_expiry_date_2_[' . $loop . ']',
        'value' => get_post_meta($variation->ID, 'lot_management_expiry_date_2', true),
        'type' => 'date'
    ));

    woocommerce_wp_text_input(array(
        'id' => 'lot_management_rifornimento_date_2_[' . $loop . ']',
        'value' => get_post_meta($variation->ID, 'lot_management_rifornimento_date_2', true),
        'type' => 'date'
    ));
    echo '</div>'; // Close Lot Group

    $lot_management_name_3 = get_post_meta( $variation->ID, 'lot_management_name_3', true );
    if(isset($lot_management_name_3) && $lot_management_name_3 != '' ){
        echo '<div class="lot-group" id="lot-group-3-'.$loop.'">';
        $lot_active_number +=1;
    }else{
        echo '<div class="lot-group" id="lot-group-3-'.$loop.'" style="display: none;">';
    }
    //echo '<h5>' . __('Lot Section 3', 'warehouse-management') . '</h5>';
    woocommerce_wp_text_input(
        array(
            'id' => 'lot_management_name_3_[' . $loop . ']',
            'class' => 'short', 'placeholder' => __('Nome lotto', 'warehouse-management'),
            'value' => get_post_meta( $variation->ID, 'lot_management_name_3', true ),
        )

    );

    woocommerce_wp_text_input(
        array(
            'id'          => 'lot_management_qty_3_[' . $loop . ']',
            'type' => 'number',
            'placeholder' => __('Quantità', 'warehouse-management'),
            'value'       => get_post_meta( $variation->ID, 'lot_management_qty_3', true ),
            'custom_attributes' => array(
                'step' 	=> 'any',
                'min'	=> '0'
            )
        )
    );

    woocommerce_wp_text_input(array(
        'id' => 'lot_management_expiry_date_3_[' . $loop . ']',
        'value' => get_post_meta($variation->ID, 'lot_management_expiry_date_3', true),
        'type' => 'date'
    ));

    woocommerce_wp_text_input(array(
        'id' => 'lot_management_rifornimento_date_3_[' . $loop . ']',
        'value' => get_post_meta($variation->ID, 'lot_management_rifornimento_date_3', true),
        'type' => 'date'
    ));

    echo '</div>'; // Close Lot Group

    $lot_management_name_4 = get_post_meta( $variation->ID, 'lot_management_name_4', true );
     if(isset($lot_management_name_4) && $lot_management_name_4 != '' ){
         $lot_active_number +=1;
         echo '<div class="lot-group" id="lot-group-4-'.$loop.'">';
     }else{
         echo '<div class="lot-group" id="lot-group-4-'.$loop.'" style="display: none;">';
     }

    woocommerce_wp_text_input(
        array(
            'id' => 'lot_management_name_4_[' . $loop . ']',
            'class' => 'short', 'placeholder' => __('Nome lotto', 'warehouse-management'),
            'value' => get_post_meta( $variation->ID, 'lot_management_name_4', true ),
        )

    );

    woocommerce_wp_text_input(
        array(
            'id'          => 'lot_management_qty_4_[' . $loop . ']',
            'type' => 'number',
            'placeholder' => __('Quantità', 'warehouse-management'),
            'value'       => get_post_meta( $variation->ID, 'lot_management_qty_4', true ),
            'custom_attributes' => array(
                'step' 	=> 'any',
                'min'	=> '0'
            )
        )
    );

    woocommerce_wp_text_input(array(
        'id' => 'lot_management_expiry_date_4_[' . $loop . ']',
        'value' => get_post_meta($variation->ID, 'lot_management_expiry_date_4', true),
        'type' => 'date'
    ));

    woocommerce_wp_text_input(array(
        'id' => 'lot_management_rifornimento_date_4_[' . $loop . ']',
        'value' => get_post_meta($variation->ID, 'lot_management_rifornimento_date_4', true),
        'type' => 'date'
    ));
    echo '</div>'; // Close Lot Group

    $lot_management_name_5 = get_post_meta( $variation->ID, 'lot_management_name_5', true );
    if(isset($lot_management_name_5) && $lot_management_name_5 != '' ){
        $lot_active_number +=1;
        echo '<div class="lot-group" id="lot-group-5-'.$loop.'">';
    }else{
        echo '<div class="lot-group" id="lot-group-5-'.$loop.'" style="display: none;">';
    }

    woocommerce_wp_text_input(
        array(
            'id' => 'lot_management_name_5_[' . $loop . ']',
            'class' => 'short', 'placeholder' => __('Nome lotto', 'warehouse-management'),
            'value' => get_post_meta( $variation->ID, 'lot_management_name_5', true ),
        )

    );

    woocommerce_wp_text_input(
        array(
            'id'          => 'lot_management_qty_5_[' . $loop . ']',
            'type' => 'number',
            'placeholder' => __('Quantità', 'warehouse-management'),
            'value'       => get_post_meta( $variation->ID, 'lot_management_qty_5', true ),
            'custom_attributes' => array(
                'step' 	=> 'any',
                'min'	=> '0'
            )
        )
    );

    woocommerce_wp_text_input(array(
        'id' => 'lot_management_expiry_date_5_[' . $loop . ']',
        'value' => get_post_meta($variation->ID, 'lot_management_expiry_date_5', true),
        'type' => 'date'
    ));

    woocommerce_wp_text_input(array(
        'id' => 'lot_management_rifornimento_date_5_[' . $loop . ']',
        'value' => get_post_meta($variation->ID, 'lot_management_rifornimento_date_5', true),
        'type' => 'date'
    ));
    echo '</div>'; // Close Lot Group

    echo '<div class="lot-group">';
    echo '<input type="hidden"  id="lot_management_selected_hidden_'.$loop.'" name="lot_management_selected_hidden_'.$loop.'" value="'.$lot_active_number.'">';
    echo '<p class="form-field"></p><p class="form-field"></p><p class="form-field"></p><p class="form-field"><a id="lot-add-more-index-'.$loop.'" href="javascript:addMoreLot( '.$loop.');" class="button">' . esc_html__( 'Aggiungi lotto', 'warehouse-management' ) . '</a></p>';
    echo '</div>'; // Close Add Now Button Close Lot Group

    echo '</div>'; // Close custom options group

	//
}

// -----------------------------------------
// 2. Save custom field on product variation save

add_action( 'woocommerce_save_product_variation', 'whm_save_custom_field_variations', 10, 2 );
function whm_save_custom_field_variations( $variation_id, $i ) {
    updateLotDataByVariationId( $variation_id, $i );
}

function updateLotDataByVariationId( $variation_id, $i )
{
    for ($v = 1; $v <= 5; $v++ ){
        $lot_management_name = $_POST['lot_management_name_'.$v.'_'][$i];
        $lot_management_qty = $_POST['lot_management_qty_'.$v.'_'][$i];
        $lot_management_expiry_date = $_POST['lot_management_expiry_date_'.$v.'_'][$i];
        $lot_management_rifornimento_date = $_POST['lot_management_rifornimento_date_'.$v.'_'][$i];

        if ( isset( $lot_management_name ) ) update_post_meta( $variation_id, 'lot_management_name_'.$v, esc_attr( $lot_management_name ) );
        if ( isset( $lot_management_qty ) ) update_post_meta( $variation_id, 'lot_management_qty_'.$v, esc_attr( $lot_management_qty ) );
        if ( isset( $lot_management_expiry_date ) ) update_post_meta( $variation_id, 'lot_management_expiry_date_'.$v, esc_attr( $lot_management_expiry_date ) );
        if ( isset( $lot_management_rifornimento_date ) ) update_post_meta( $variation_id, 'lot_management_rifornimento_date_'.$v, esc_attr( $lot_management_rifornimento_date ) );
    }
}




// -----------------------------------------
// 3. Store custom field value into variation data

//add_filter( 'woocommerce_available_variation', 'whm_add_custom_field_variation_data' );
function whm_add_custom_field_variation_data( $variations ) {
	$variations['country_of_origin'] = '<div class="woocommerce_custom_field">COUNTRY OF ORIGIN: <span>' . get_post_meta( $variations[ 'variation_id' ], 'country_of_origin', true ) . '</span></div>';
	//$variations['last_order_date_from_producer'] = '<div class="woocommerce_custom_field">LAST ORDER DATE FROM PRODUCER: <span>' . get_post_meta( $variations[ 'variation_id' ], 'last_order_date_from_producer', true ) . '</span></div>';
	$variations['manufacturer_reference_number'] = '<div class="woocommerce_custom_field">MANUFACTURER REFERENCE NUMBER: <span>' . get_post_meta( $variations[ 'variation_id' ], 'manufacturer_reference_number', true ) . '</span></div>';
	return $variations;
}

function whm_admin_check_product_expiry() {
    // Destinatario: l'email amministratore del sito (modificabile con il filtro).
    $admin_email = apply_filters( 'whm_expiry_notification_email', get_option( 'admin_email' ) );

    // Query products that have the 'lot_management' meta key
    $args = array(
        'post_type'      => 'product',
        'posts_per_page' => -1, // -1 to retrieve all products
        'meta_query'     => array(
            array(
                'key'     => 'lot_management', // Change 'lot_management' to your actual meta key
                'compare' => 'EXISTS',
            ),
        ),
    );
    $products = new WP_Query($args);

    // Check if products were found
    if ($products->have_posts()) {
        while ($products->have_posts()) {
            $products->the_post();
            $product_id = get_the_ID();
            $product_name = get_the_title();
            $product = wc_get_product($product_id);
            if ($product && $product->is_type('variable')) {
                $lots_object = getActiveLotIdsByProductID($product_id, '2');
            }else{
                $lots_object = getActiveLotIdsByProductID($product_id, '2');
            }
            if(!empty($lots_object)){
                $lots_object_data = current($lots_object);
                $lot_product_id = $lots_object_data['product_id'];
               if( $lot_product_id == $product_id ){
                   // Check if the expiry date is within 7 days from no
                   /* translators: %s: nome del prodotto */
                   $subject = sprintf( __( 'Lotto in scadenza: %s', 'warehouse-management' ), $product_name );
                   $lot_name = isset( $lots_object_data['lot_data']['lot'] ) ? $lots_object_data['lot_data']['lot'] : ( $lots_object_data['lot_data']['lot_name'] ?? '' );
                   $message  = '<p>' . sprintf( esc_html__( 'Il prodotto «%s» ha un lotto che scade entro 2 giorni.', 'warehouse-management' ), esc_html( $product_name ) ) . '</p>';
                   $message .= '<p>' . esc_html__( 'Lotto:', 'warehouse-management' ) . ' ' . esc_html( $lot_name ) . '</p>';
                   $message .= '<p><a href="' . esc_url( get_edit_post_link( $product_id, 'raw' ) ) . '">' . esc_html__( 'Apri il prodotto', 'warehouse-management' ) . '</a></p>';
                   $headers = array('Content-Type: text/html; charset=UTF-8');

                   // Send email to admin as HTML
                   wp_mail($admin_email, $subject, $message, $headers);
               }
            }
        }
        wp_reset_postdata(); // Reset post data
    }
}

add_action('admin_init', 'whm_admin_init_call_back');
function whm_admin_init_call_back(){
    // admin_init gira anche su admin-ajax.php per i visitatori non connessi:
    // le azioni qui sotto sono solo per gli utenti del backend.
    if ( wp_doing_ajax() ) {
        return;
    }

    if ( isset( $_REQUEST['test_cron'] ) && '1' === (string) $_REQUEST['test_cron'] && current_user_can( 'manage_options' ) ) {
        whm_admin_check_product_expiry();
    }

    if ( isset( $_REQUEST['product_id'], $_REQUEST['export'] ) && '' !== $_REQUEST['product_id'] && 'all_data' === $_REQUEST['export'] ) {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'Non hai i permessi per esportare i dati di magazzino.', 'warehouse-management' ), 403 );
        }
        $product_id = absint( $_REQUEST['product_id'] );
        check_admin_referer( 'whm_export_variations_' . $product_id );
        export_variations_to_csv_with_custom_columns( $product_id );
    }
}


function whm_enqueue_product_edit_scripts($hook) {
    global $post;

    // Check if the current page is the product edit page
    if (($hook == 'post.php' || $hook == 'post-new.php') && isset($post) && $post->post_type == 'product') {
        wp_register_script('custom-product-edit', WHM_DIR_URL . '/js/custom.js', array('jquery'), rand(1,99999), true);
        $product_id = isset( $_REQUEST['post'] ) ? absint( $_REQUEST['post'] ) : 0;
        $product = wc_get_product($product_id);
        $product_type = 'simple';
        if($product){
            if( $product->is_type('variable') ){
                $product_type = 'variable';
            }
        }
        $data_to_localize = array(
            'productType' => $product_type,
        );
        wp_localize_script('custom-product-edit', 'whmCustomData', $data_to_localize);
        wp_enqueue_script('custom-product-edit');
    }
}
add_action('admin_enqueue_scripts', 'whm_enqueue_product_edit_scripts');