<?php
/**
 * Lotti scalati dagli ordini.
 *
 * Quando un ordine passa in "In lavorazione" le quantita' dei lotti si
 * riducono (prima i lotti piu' vecchi): per le variazioni dai campi
 * lot_management_*_N, per i prodotti semplici dal ripetitore ACF
 * lot_management. Il riepilogo di cosa e' stato scalato resta nell'ordine,
 * nel riquadro "Lotti scalati".
 *
 * Fino alla 0.4.0 questa logica stava nel tema lagalpi-child (ex Code
 * Snippets #7) e il plugin aveva in piu' un suo hook per i prodotti semplici
 * (whm_reduce_stock_on_order_processing): due riduzioni sulla stessa
 * transizione. Dalla 0.5.0 c'e' solo questa, e ogni ordine viene scalato una
 * volta sola anche se torna piu' volte "In lavorazione".
 *
 * @package warehouse-management
 */

defined( 'ABSPATH' ) || exit;


add_action('woocommerce_order_status_processing', 'whm_reduce_lot_qty_on_order_complete');
function whm_reduce_lot_qty_on_order_complete($order_id) {
    // Get the order
    $order = wc_get_order($order_id);
    if ( ! $order || $order->get_meta( '_whm_lots_reduced_variations' ) ) {
        return;
    }
    $order->update_meta_data( '_whm_lots_reduced_variations', time() );
    $order->save_meta_data();

    // Loop through order items
    foreach ($order->get_items() as $item_id => $item) {
        $variation_id = $item->get_variation_id();
        $quantity_purchased = $item->get_quantity();

        if ($variation_id) {
            // Store lot meta information before reducing quantity
            $lot_meta_changes = whm_reduce_lot_qty($variation_id, $quantity_purchased);
            $order->update_meta_data('_lot_meta_changes_' . $item_id, $lot_meta_changes);
            $order->save_meta_data();
        }
    }
}

function whm_reduce_lot_qty($variation_id, $quantity_purchased) {
    $lot_meta_changes = [];

    for ($v = 1; $v <= 5; $v++) {
        // Retrieve the current lot quantity
        $lot_qty = get_post_meta($variation_id, 'lot_management_qty_' . $v, true);

        if ($lot_qty !== '') {
            // Convert lot quantity to an integer for comparison
            $lot_qty = intval($lot_qty);

            if ($lot_qty >= $quantity_purchased) {
                // Reduce the lot quantity by the quantity purchased and update it
                $new_qty = $lot_qty - $quantity_purchased;
                if ($new_qty > 0) {
                    update_post_meta($variation_id, 'lot_management_qty_' . $v, $new_qty);

                    // Store the reduced lot meta
                    $lot_meta_changes[] = [
                        'name' => get_post_meta($variation_id, 'lot_management_name_' . $v, true),
                        'old_qty' => $lot_qty,
                        'new_qty' => $new_qty,
                        'expiry' => get_post_meta($variation_id, 'lot_management_expiry_date_' . $v, true),
                        'rifornimento' => get_post_meta($variation_id, 'lot_management_rifornimento_date_' . $v, true),
                    ];
                } else {
                    // Store the lot meta before deleting
                    $lot_meta_changes[] = [
                        'name' => get_post_meta($variation_id, 'lot_management_name_' . $v, true),
                        'old_qty' => $lot_qty,
                        'new_qty' => 0,
                        'expiry' => get_post_meta($variation_id, 'lot_management_expiry_date_' . $v, true),
                        'rifornimento' => get_post_meta($variation_id, 'lot_management_rifornimento_date_' . $v, true),
                    ];

                    // Delete the lot metadata if the quantity reaches zero
                    delete_post_meta($variation_id, 'lot_management_name_' . $v);
                    delete_post_meta($variation_id, 'lot_management_qty_' . $v);
                    delete_post_meta($variation_id, 'lot_management_expiry_date_' . $v);
                    delete_post_meta($variation_id, 'lot_management_rifornimento_date_' . $v);
                }
                break;
            } else {
                // Store the lot meta before deleting
                $lot_meta_changes[] = [
                    'name' => get_post_meta($variation_id, 'lot_management_name_' . $v, true),
                    'old_qty' => $lot_qty,
                    'new_qty' => 0,
                    'expiry' => get_post_meta($variation_id, 'lot_management_expiry_date_' . $v, true),
                    'rifornimento' => get_post_meta($variation_id, 'lot_management_rifornimento_date_' . $v, true),
                ];

                // If lot quantity is less than the quantity purchased, set it to 0 and continue with the remaining quantity
                delete_post_meta($variation_id, 'lot_management_name_' . $v);
                delete_post_meta($variation_id, 'lot_management_qty_' . $v);
                delete_post_meta($variation_id, 'lot_management_expiry_date_' . $v);
                delete_post_meta($variation_id, 'lot_management_rifornimento_date_' . $v);
                $quantity_purchased -= $lot_qty;
            }
        }
    }

    return $lot_meta_changes;
}



add_action('woocommerce_order_status_processing', 'whm_reduce_simple_product_lot_qty_on_order_complete');
function whm_reduce_simple_product_lot_qty_on_order_complete($order_id) {
    // Get the order
    $order = wc_get_order($order_id);
    if ( ! $order || $order->get_meta( '_whm_lots_reduced_simple' ) ) {
        return;
    }
    $order->update_meta_data( '_whm_lots_reduced_simple', time() );
    $order->save_meta_data();

    // Loop through order items
    foreach ($order->get_items() as $item_id => $item) {
        $product_id = $item->get_product_id();
        $quantity_purchased = $item->get_quantity();
        $product = wc_get_product($product_id);

        // Check if the product is a simple product
        if ($product->is_type('simple')) {
            // Store lot meta information before reducing quantity
            $deleted_lot_meta = whm_reduce_simple_product_lot_qty($product_id, $quantity_purchased);
            $order->update_meta_data('_deleted_lot_meta_simple_' . $item_id, $deleted_lot_meta);
            $order->save_meta_data();
        }
    }
}

function whm_reduce_simple_product_lot_qty($product_id, $quantity_purchased) {
    // Get the current lot data from ACF
    $lot_data = get_field('lot_management', $product_id);
    $deleted_lot_meta = [];

    if ($lot_data) {
        foreach ($lot_data as $index => $lot) {
            $lot_qty = intval($lot['qty']);

            if ($lot_qty >= $quantity_purchased) {
                // Reduce the lot quantity by the quantity purchased and update it
                $new_qty = $lot_qty - $quantity_purchased;
                if ($new_qty > 0) {
                    $lot_data[$index]['qty'] = $new_qty;

                    // Store the reduced lot meta
                    $deleted_lot_meta[] = [
                        'name' => $lot['lot_name'],
                        'old_qty' => $lot_qty,
                        'new_qty' => $new_qty,
                        'expiry' => $lot['expiry_date'],
                        'rifornimento' => $lot['rifornimento_date'],
                    ];
                } else {
                    // Store the lot meta before deleting
                    $deleted_lot_meta[] = [
                        'name' => $lot['lot_name'],
                        'old_qty' => $lot_qty,
                        'new_qty' => 0,
                        'expiry' => $lot['expiry_date'],
                        'rifornimento' => $lot['rifornimento_date'],
                    ];

                    // Remove the lot if the quantity reaches zero
                    unset($lot_data[$index]);
                }
                break;
            } else {
                // Store the lot meta before deleting
                $deleted_lot_meta[] = [
                    'name' => $lot['lot_name'],
                    'old_qty' => $lot_qty,
                    'new_qty' => 0,
                    'expiry' => $lot['expiry_date'],
                    'rifornimento' => $lot['rifornimento_date'],
                ];

                // If lot quantity is less than the quantity purchased, set it to 0 and continue with the remaining quantity
                unset($lot_data[$index]);
                $quantity_purchased -= $lot_qty;
            }
        }

        // Update the ACF field with the new lot data
        update_field('lot_management', array_values($lot_data), $product_id);
    }

    return $deleted_lot_meta;
}



add_action('add_meta_boxes', 'whm_add_combined_lot_meta_box');
function whm_add_combined_lot_meta_box() {
    add_meta_box(
        'whm_combined_lot_meta_box',
        __( 'Lotti scalati', 'warehouse-management' ),
        'whm_display_combined_lot_meta_box',
        whm_lot_order_screens(),
        'normal',
        'default'
    );
}

function whm_display_combined_lot_meta_box( $post ) {
    $order = $post instanceof WC_Order ? $post : wc_get_order( $post->ID );
    if ( ! $order ) {
        return;
    }
    $shown = false;
    foreach ( $order->get_items() as $item_id => $item ) {
        $rows = array_merge(
            (array) $order->get_meta( '_lot_meta_changes_' . $item_id ),
            (array) $order->get_meta( '_deleted_lot_meta_simple_' . $item_id )
        );
        $rows = array_filter( $rows, 'is_array' );
        if ( ! $rows ) {
            continue;
        }
        $shown = true;
        echo '<h4>' . esc_html( $item->get_name() ) . '</h4>';
        echo '<table class="widefat striped"><thead><tr>';
        echo '<th>' . esc_html__( 'Lotto', 'warehouse-management' ) . '</th>';
        echo '<th>' . esc_html__( 'Quantità prima', 'warehouse-management' ) . '</th>';
        echo '<th>' . esc_html__( 'Quantità dopo', 'warehouse-management' ) . '</th>';
        echo '<th>' . esc_html__( 'Scadenza', 'warehouse-management' ) . '</th>';
        echo '<th>' . esc_html__( 'Rifornimento', 'warehouse-management' ) . '</th>';
        echo '</tr></thead><tbody>';
        foreach ( $rows as $meta ) {
            echo '<tr>';
            foreach ( array( 'name', 'old_qty', 'new_qty', 'expiry', 'rifornimento' ) as $key ) {
                echo '<td>' . esc_html( isset( $meta[ $key ] ) ? (string) $meta[ $key ] : '' ) . '</td>';
            }
            echo '</tr>';
        }
        echo '</tbody></table>';
    }
    if ( ! $shown ) {
        echo '<p>' . esc_html__( 'Nessun lotto scalato per questo ordine: succede quando l\'ordine non è ancora passato a «In lavorazione» o i prodotti non hanno lotti.', 'warehouse-management' ) . '</p>';
    }
}

/**
 * Schermate ordine: classica (shop_order) e HPOS (WooCommerce > Ordini).
 *
 * @return string[]
 */
function whm_lot_order_screens() {
    $screens = array( 'shop_order' );
    if ( function_exists( 'wc_get_page_screen_id' ) ) {
        $screens[] = wc_get_page_screen_id( 'shop-order' );
    }
    return array_values( array_unique( array_filter( $screens ) ) );
}
