<?php
/**
 * Tabella e colonne degli ordini per le query SQL dirette.
 *
 * Con HPOS (High-Performance Order Storage) gli ordini stanno in
 * {prefix}wc_orders; senza, in {prefix}posts. Le query del plugin usano
 * l'alias "posts" e queste colonne, cosi' funzionano in entrambi i casi.
 *
 * @return array{table:string,id:string,type:string,status:string,date:string,hpos:bool}
 */
function whm_order_sql_parts() {
    global $wpdb;
    $hpos = class_exists( '\\Automattic\\WooCommerce\\Utilities\\OrderUtil' )
        && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
    if ( $hpos ) {
        return array( 'table' => $wpdb->prefix . 'wc_orders', 'id' => 'id', 'type' => 'type', 'status' => 'status', 'date' => 'date_created_gmt', 'hpos' => true );
    }
    return array( 'table' => $wpdb->posts, 'id' => 'ID', 'type' => 'post_type', 'status' => 'post_status', 'date' => 'post_date', 'hpos' => false );
}

/**
 * Le date dei filtri sono nell'ora del sito: con HPOS la colonna e' in UTC.
 *
 * @param string $date Data/ora locale.
 * @return string
 */
function whm_order_sql_date( $date ) {
    $parts = whm_order_sql_parts();
    return $parts['hpos'] ? get_gmt_from_date( $date ) : $date;
}

/**
 * URL dell'elenco ordini filtrato per prodotto (HPOS o legacy).
 *
 * @param int $product_id Prodotto.
 * @return string
 */
function whm_orders_list_url( $product_id ) {
    $parts = whm_order_sql_parts();
    $base  = $parts['hpos'] ? 'admin.php?page=wc-orders' : 'edit.php?post_type=shop_order';
    return admin_url( $base . '&product_id=' . absint( $product_id ) );
}

function lagalpi_enqueue_whm_admin_styles() {
    wp_enqueue_style( 'whm-admin-styles', WHM_DIR_URL . 'css/admin-styles.css' );
}
function whm_generate_and_save_csv( $get_products ) {
    if(empty($get_products) || $get_products->query['post_type'] != 'product')
        return '';

    $found_posts = $get_products->found_posts;

    if(empty($found_posts) || $found_posts < 1 )
        return;


    if(WHM_PHPEXCEL){
        $objPHPExcel = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $objPHPExcel->getProperties()->setCreator('Warehouse Product Reports')
                    ->setLastModifiedBy('')
                    ->setTitle('Warehouse Product Reports')
                    ->setSubject('')
                    ->setDescription('Warehouse Product Reports')
                    ->setKeywords('Warehouse, Product, Reports')
                    ->setCategory('');
            $objPHPExcel->setActiveSheetIndex( 0 );
            $objPHPExcel->getActiveSheet()->setCellValue( 'A1', esc_html__( '#', 'warehouse-management' ) );
            $objPHPExcel->getActiveSheet()->setCellValue( 'B1', esc_html__( 'COD', 'warehouse-management' ) );
            $objPHPExcel->getActiveSheet()->setCellValue( 'C1', esc_html__( 'Title', 'warehouse-management' ) );
            $objPHPExcel->getActiveSheet()->setCellValue( 'D1', esc_html__( 'Stock', 'warehouse-management' ) );
            $objPHPExcel->getActiveSheet()->setCellValue( 'E1', esc_html__( 'Prezzo', 'warehouse-management' ) );
            $objPHPExcel->getActiveSheet()->setCellValue( 'F1', esc_html__( 'COG Cost', 'warehouse-management' ) );
            $objPHPExcel->getActiveSheet()->setCellValue( 'G1', esc_html__( 'Special Lot', 'warehouse-management' ) );
             $objPHPExcel->getActiveSheet()->setCellValue( 'H1', esc_html__( 'Lot Name', 'warehouse-management' ) );
              $objPHPExcel->getActiveSheet()->setCellValue( 'I1', esc_html__( 'Lot Expiry Date', 'warehouse-management' ) );
               $objPHPExcel->getActiveSheet()->setCellValue( 'J1', esc_html__( 'Lot Quantity', 'warehouse-management' ) );
                $objPHPExcel->getActiveSheet()->setCellValue( 'K1', esc_html__( 'Lot Rifornimento Date', 'warehouse-management' ) );
            $objPHPExcel->getActiveSheet()->setCellValue( 'L1', esc_html__( 'Fornitore', 'warehouse-management' ) );
            $objPHPExcel->getActiveSheet()->getStyle( 'A1:Z1' )->getFont()->setBold( true );

            // Set up the CSV file path in the plugin directory
            $csv_file_path = whm_export_file_path();
            if ( $get_products->have_posts() ) {
                $sr = 1;
                $csv_row = array();
                while ( $get_products->have_posts() ) {
                    $get_products->the_post();
                    // Get product data
                    $product = wc_get_product(get_the_ID());
                    $product_id        = $product->get_id();

                    //$_expiration_date       = get_post_meta($product_id, '_expiration_date', true);
                    $specific_lot        = get_post_meta($product_id, 'specific_lot', true);
                    $_wc_cog_cost        = get_post_meta($product_id, '_wc_cog_cost', true);
                    $product_sku = get_post_meta($product_id, '_sku', true );

                    $product_title     = $product->get_name();
                    $price     = $product->get_price();

                    //$stock_status      = $product->get_stock_status();
                    $stock_count       = $product->get_stock_quantity();

                    $attribute_name = 'pa_produttore';
                    $attribute_value = $product->get_attribute($attribute_name);
                    $attribute_value = $attribute_value ?? '';
                    $expiry_html = '';
                    if( $product->is_type('variable') ){
                        $variations = $product->get_available_variations();
                        foreach ($variations as $variation) {
                            $lot_data = '';
                            $expiry_html = '';
                            $variation_id = $variation['variation_id'];
                            $lot_data = getLotDataByVariationId($variation_id);
                            $variation_obj = new WC_Product_Variation($variation_id);
                            $variation_name = '';

                             if (is_a($variation_obj, 'WC_Product_Variation')) {
                                $variation_attributes = $variation_obj->get_attributes();
                                $variation_name = wc_get_formatted_variation($variation_attributes, true, false, true);
                            }


                            if (!empty($lot_data)) {

                                foreach ($lot_data as $lot_object) {

                                    $lot_name = $lot_object['lot'];
                                    $lot_expiry_date = $lot_object['expiry_date'];
                                    $lot_qty = $lot_object['qty'];
                                    $lot_rifornimento_date = $lot_object['rifornimento_date'];
                                    if (isset($lot_name, $lot_expiry_date, $lot_qty)) {
                                        $expiry_html = "Lot Name : {$lot_name} | Lot Expiry Date : {$lot_expiry_date} | Lot QTY : {$lot_qty} | Lot Data Rifornimento : {$lot_rifornimento_date} ";

                                            $csv_row[] = array(
                                            'sr' => $sr,
                                            'sku' => $product_sku,
                                            'title' => $product->get_name() . ' - ' .$variation_name,
                                            'stock_count' => $variation_obj->get_stock_quantity(),
                                            'price' => $variation_obj->get_price(),
                                            'cog_cost' => get_post_meta($variation_id, '_wc_cog_cost', true),
                                            'specific_lot' => get_post_meta($variation_id, 'specific_lot', true),
                                            'lot_name' => $lot_name,
                                            'lot_expiry_date' => date('d-m-Y', strtotime($lot_expiry_date)),
                                            'lot_qty' => $lot_qty,
                                            'lot_rifornimento_date' => date('d-m-Y', strtotime($lot_rifornimento_date)), 
                                            'attribute' => $product->get_attribute('pa_produttore') ?? ''
                                        );
                                        $sr++;
                                    }else if($lot_object == 0){
                                          $csv_row[] = array(
                                            'sr' => $sr,
                                            'sku' => $product_sku,
                                            'title' => $product->get_name() . ' - ' .$variation_name,
                                            'stock_count' => $variation_obj->get_stock_quantity(),
                                            'price' => $variation_obj->get_price(),
                                            'cog_cost' => get_post_meta($variation_id, '_wc_cog_cost', true),
                                            'specific_lot' => get_post_meta($variation_id, 'specific_lot', true),
                                            'lot_name' => '-',
                                            'lot_expiry_date' => '-',
                                            'lot_qty' => '-',
                                            'lot_rifornimento_date' => '-',
                                            'attribute' => $product->get_attribute('pa_produttore') ?? '',
                                        );
                                        $sr++;

                                    }
                                }
                            }else{
                                $csv_row[] = array(
                                    'sr' => $sr,
                                    'sku' => $product_sku,
                                    'title' => $product->get_name() . ' - ' .$variation_name,
                                    'stock_count' => $variation_obj->get_stock_quantity(),
                                    'price' => $variation_obj->get_price(),
                                    'cog_cost' => get_post_meta($variation_id, '_wc_cog_cost', true),
                                    'specific_lot' => get_post_meta($variation_id, 'specific_lot', true),
                                    'lot_name' => '',
                                    'lot_expiry_date' => '',
                                    'lot_qty' => '',
                                    'lot_rifornimento_date' => '',
                                    'attribute' => $product->get_attribute('pa_produttore') ?? '',
                                );
                                $sr++;
                            }

                            


                        }
                    }else{
                        $lot_management = getActiveLotIdsByProductID($product_id);
                        $lot_management = get_field('lot_management', $product_id);
                        if (!empty($lot_management)) {
                            foreach ($lot_management as $lot_data) {
                                $available_qty = $lot_data['qty'];
                                $lot_name = $lot_data['lot_name'];
                                $lot_expiry_date = $lot_data['expiry_date'];
                                $lot_rifornimento_date = $lot_data['rifornimento_date'];
                                
                                 //   $expiry_html = "Lot Name : {$lot_name} | Lot Expiry Date : {$lot_expiry_date} | Lot QTY : {$available_qty} | Lot Data Rifornimento2 : {$lot_rifornimento_date} ";

                                  //  $csv_row[] = array( 'sr' => $sr, 'sku' => $product_sku, 'title' => $product_title, 'stock_count' => $stock_count, 'price' => $price, 'cog_cost' => $_wc_cog_cost, 'specific_lot' => $specific_lot, 'attribute' => $attribute_value , 'expiry_info' => $expiry_html );

                                    $csv_row[] = array(
                                        'sr' => $sr,
                                        'sku' => $product_sku,
                                        'title' => $product_title,
                                        'stock_count' => $stock_count,
                                        'price' => $price,
                                        'cog_cost' => $_wc_cog_cost,
                                        'specific_lot' => $specific_lot,
                                        'lot_name' => $lot_name,
                                        'lot_expiry_date' => date('d-m-Y', strtotime($lot_expiry_date)),
                                        'lot_qty' => $available_qty,
                                        'lot_rifornimento_date' => date('d-m-Y', strtotime($lot_rifornimento_date)),
                                        'attribute' => $attribute_value,
                                    );


                                    $sr++;
                                
                            }
                        }else{
                           // $csv_row[] = array( 'sr' => $sr, 'sku' => $product_sku, 'title' => $product_title, 'stock_count' => $stock_count, 'price' => $price, 'cog_cost' => $_wc_cog_cost, 'specific_lot' => $specific_lot, 'attribute' => $attribute_value);

                              $csv_row[] = array(
                                        'sr' => $sr,
                                        'sku' => $product_sku,
                                        'title' => $product_title,
                                        'stock_count' => $stock_count,
                                        'price' => $price,
                                        'cog_cost' => $_wc_cog_cost,
                                        'specific_lot' => $specific_lot,
                                        'lot_name' => '',
                                        'lot_expiry_date' => '',
                                        'lot_qty' => '',
                                        'lot_rifornimento_date' => '',
                                        'attribute' => $attribute_value,
                                    );


                         $sr++;
                        }

                         
                    }

                    // Add product data to CSV row
                   

        //          echo "<pre>".print_r($csv_row, true)."</pre>";
        //          die;
                    // Write CSV row to the file
                    //fputcsv( $file_handle, $csv_row );

                    
                }
                wp_reset_postdata();

                if(!empty($csv_row)){
                    foreach ($csv_row as $i => $data ){

                        $objPHPExcel->getActiveSheet()->setCellValue( 'A' . ( $i + 2 ),  $data['sr']  );
                        $objPHPExcel->getActiveSheet()->setCellValue( 'B' . ( $i + 2 ),  $data['sku']  );
                        $objPHPExcel->getActiveSheet()->setCellValue( 'C' . ( $i + 2 ), $data['title'] );
                        $objPHPExcel->getActiveSheet()->setCellValue( 'D' . ( $i + 2 ), $data['stock_count'] );
                        $objPHPExcel->getActiveSheet()->setCellValue( 'E' . ( $i + 2 ), $data['price'] );
                        $objPHPExcel->getActiveSheet()->setCellValue( 'F' . ( $i + 2 ), $data['cog_cost'] );
                        $objPHPExcel->getActiveSheet()->setCellValue( 'G' . ( $i + 2 ), $data['specific_lot'] );
                        $objPHPExcel->getActiveSheet()->setCellValue( 'H' . ( $i + 2 ), $data['lot_name'] );
                        $objPHPExcel->getActiveSheet()->setCellValue( 'I' . ( $i + 2 ), $data['lot_expiry_date'] );
                        $objPHPExcel->getActiveSheet()->setCellValue( 'J' . ( $i + 2 ), $data['lot_qty'] );
                        $objPHPExcel->getActiveSheet()->setCellValue( 'K' . ( $i + 2 ), $data['lot_rifornimento_date'] );
                        $objPHPExcel->getActiveSheet()->setCellValue( 'L' . ( $i + 2 ),  $data['attribute'] );
                    }
                }
                $objPHPExcel->setActiveSheetIndex( 0 );
                //$filename = 'whm-product-report';
                //$filename = $filename . '.xlsx';

                $writer = \PhpOffice\PhpSpreadsheet\IOFactory::createWriter($objPHPExcel, 'Xlsx');
                $writer->save($csv_file_path);
        }

        return $csv_file_path;

    }
    return false; // Return false if no products are found
}

function whm_product_post_type_filter_custom() {

    if (!current_user_can('administrator') || ( $_REQUEST['post_type'] ?? '' ) !== 'product') {
        return;
    }

    $pa_produttore = get_terms(array(
        'taxonomy' => 'pa_produttore', // Taxonomy name for product attributes
        'hide_empty' => true, // Include empty terms (if any)
    ));

    $custom_filter_selected = isset($_GET['filter_by_custom_option']) ? $_GET['filter_by_custom_option'] : '';
    $selected = isset($_GET['filter_by_expiry']) ? $_GET['filter_by_expiry'] : '';
    $selected_produttore = isset($_GET['pa_produttore']) ? $_GET['pa_produttore'] : '';
    $selected_month = isset($_GET['ls_month_dropdown']) ? $_GET['ls_month_dropdown'] : '';
    $least_sold_options = isset($_GET['least_sold_options']) ? $_GET['least_sold_options'] : '';
    $options = array(
        '' => __('Tutte le scadenze', 'warehouse-management'),
        'tomorrow' => __('Domani', 'warehouse-management'),
        'this_week' => __('Questa settimana', 'warehouse-management'),
        'this_month' => __('Questo mese', 'warehouse-management'),
        'custom_date' => __('Date personalizzate', 'warehouse-management'),
    );

    $custom_options = array(
        '' => __('Filtri magazzino', 'warehouse-management'),
        'expiring_products' => __('Prodotti in scadenza', 'warehouse-management'),
        'manufacturers' => __('Produttori', 'warehouse-management'),
        'most_sold' => __('Più venduti', 'warehouse-management'),
        'least_sold' => __('Meno venduti', 'warehouse-management')
    );
    ?>
    <select name="filter_by_custom_option" id="filter_by_custom_option">
        <?php foreach ($custom_options as $key => $label) : ?>
            <option value="<?php echo esc_attr($key); ?>" <?php selected($custom_filter_selected, $key); ?>><?php echo esc_html($label); ?></option>
        <?php endforeach; ?>
    </select>
    <select name="filter_by_expiry" id="filter_by_expiry" style="display: none;">
        <?php foreach ($options as $key => $label) : ?>
            <option value="<?php echo esc_attr($key); ?>" <?php selected($selected, $key); ?>><?php echo esc_html($label); ?></option>
        <?php endforeach; ?>
    </select>

    <select name="pa_produttore" id="filter_by_list_manufacturers" style="display: none;">
        <option value=""><?php esc_html_e( 'Tutti i produttori', 'warehouse-management' ); ?></option>
        <?php
        if(!empty($pa_produttore)){
            foreach ($pa_produttore as $produttore) : ?>
                <option value="<?php echo esc_attr($produttore->slug); ?>" <?php selected($selected_produttore, $produttore->slug); ?>><?php echo esc_html($produttore->name); ?></option>
            <?php endforeach;
        } ?>
    </select>
    <?php
            $custom_date_from = '';
            $custom_date_to = '';
            $custom_date_from = sanitize_text_field( wp_unslash( $_GET['custom_date_from'] ?? '' ) );
            $custom_date_to = sanitize_text_field( wp_unslash( $_GET['custom_date_to'] ?? '' ) );
            ?>
    <div id="custom_date_filter" style="display: none;">
        <label for="custom_date_from"><?php esc_html_e( 'Dal', 'warehouse-management' ); ?></label>
        <input type="date" id="custom_date_from" name="custom_date_from" placeholder="YYYY-MM-DD" value="<?php echo esc_attr( $custom_date_from ); ?>">
        <label for="custom_date_to"><?php esc_html_e( 'Al', 'warehouse-management' ); ?></label>
        <input type="date" id="custom_date_to" name="custom_date_to" placeholder="YYYY-MM-DD" value="<?php echo esc_attr( $custom_date_to ); ?>">
    </div>

    <div id="custom_least_sold_filter" style="display: none;">
        <select name="least_sold_options" id="least_sold_options">
            <option value="" <?php selected($least_sold_options, ''); ?>><?php esc_html_e( 'Tutto il periodo', 'warehouse-management' ); ?></option>
            <option value="ls_months" <?php selected($least_sold_options, 'ls_months'); ?>><?php esc_html_e( 'Mese', 'warehouse-management' ); ?></option>
            <option value="ls_dates" <?php selected($least_sold_options, 'ls_dates'); ?>><?php esc_html_e( 'Date', 'warehouse-management' ); ?></option>
        </select>
        <div id="ls_months_filter" style="display: none;">
            <select id="monthDropdown" name="ls_month_dropdown"></select>
        </div>
        <?php
            $ls_custom_date_from = '';
            $ls_custom_date_to = '';
            $ls_custom_date_from = sanitize_text_field( wp_unslash( $_GET['ls_custom_date_from'] ?? '' ) );
            $ls_custom_date_to = sanitize_text_field( wp_unslash( $_GET['ls_custom_date_to'] ?? '' ) );
            ?>
        <div id="ls_custom_date_filter" style="display: none;">
            <label for="ls_custom_date_from"><?php esc_html_e( 'Dal', 'warehouse-management' ); ?></label>
            <input type="date" id="ls_custom_date_from" name="ls_custom_date_from" placeholder="YYYY-MM-DD" value="<?php echo esc_attr( $ls_custom_date_from ); ?>">
            <label for="ls_custom_date_to"><?php esc_html_e( 'Al', 'warehouse-management' ); ?></label>
            <input type="date" id="ls_custom_date_to" name="ls_custom_date_to" placeholder="YYYY-MM-DD" value="<?php echo esc_attr( $ls_custom_date_to ); ?>">
        </div>
    </div>
    <?php
    $download_url = whm_export_download_url();
    //if( $selected_produttore != '' || $selected != '' || $custom_filter_selected != ''  ) :
        ?>
        <a href="<?php echo esc_url( $download_url ); ?>" id="whm-download-csv" class="button"><?php esc_html_e( 'Scarica Excel', 'warehouse-management' ); ?></a>
    <?php // endif;?>
    <script>
        var selectedMonth = <?php echo wp_json_encode( sanitize_text_field( wp_unslash( $selected_month ) ) ); ?>;
        document.addEventListener('DOMContentLoaded', function() {
            // Get the select element by its ID
            const monthDropdown = document.getElementById('monthDropdown');
            // Array of month names
            const months = [ '',
                'January', 'February', 'March', 'April', 'May', 'June',
                'July', 'August', 'September', 'October', 'November', 'December'
            ];
            const monthLabels = <?php echo wp_json_encode( array( __( 'Tutti i mesi', 'warehouse-management' ), __( 'Gennaio', 'warehouse-management' ), __( 'Febbraio', 'warehouse-management' ), __( 'Marzo', 'warehouse-management' ), __( 'Aprile', 'warehouse-management' ), __( 'Maggio', 'warehouse-management' ), __( 'Giugno', 'warehouse-management' ), __( 'Luglio', 'warehouse-management' ), __( 'Agosto', 'warehouse-management' ), __( 'Settembre', 'warehouse-management' ), __( 'Ottobre', 'warehouse-management' ), __( 'Novembre', 'warehouse-management' ), __( 'Dicembre', 'warehouse-management' ) ) ); ?>;
            // Loop through the array and create an option element for each month
            months.forEach((month, index) => {
                // Create a new option element
                const option = document.createElement('option');
                // Set the value and text of the option element
                option.value = month; // Value can be 1-12
                option.text = monthLabels[index] || month;
                // Check if this is the selected month
                if (option.value === selectedMonth) {
                    option.selected = true;
                }
                // Add the option element to the dropdown
                monthDropdown.add(option);
            });

            // Function to toggle the visibility of the month filter
            function toggleMonthFilter() {
                const leastSoldOptions = document.getElementById('least_sold_options');
                const lsMonthsFilter = document.getElementById('ls_months_filter');
                const ls_custom_date_filter = document.getElementById('ls_custom_date_filter');

                if (leastSoldOptions.value === 'ls_months') {
                    lsMonthsFilter.style.display = 'block';
                    ls_custom_date_filter.style.display = 'none';
                }else if (leastSoldOptions.value === 'ls_dates') {
                    ls_custom_date_filter.style.display = 'block';
                    lsMonthsFilter.style.display = 'none';
                }
                else {
                    lsMonthsFilter.style.display = 'none';
                    ls_custom_date_filter.style.display = 'none';
                }
            }
            // Add event listener to the least_sold_options select element
            document.getElementById('least_sold_options').addEventListener('change', toggleMonthFilter);

            // Initial call to set the correct visibility on page load
            toggleMonthFilter();

            // Code to execute when the page is fully loaded
            const filterDropdown = document.getElementById('filter_by_custom_option');
            const downloadCsvButton = document.getElementById('whm-download-csv');
            const stockDropdown = document.querySelector('select[name="stock_status"]');

            function handleFilterChange() {
                downloadCsvButton.style.display = 'none';
                if (filterDropdown.value === 'manufacturers') {
                  //  stockDropdown.value = 'instock';
                jQuery('select[name="stock_status"] option:eq(1)'). attr('selected', 'selected');
                }
            }

            filterDropdown.addEventListener('change', handleFilterChange);
            if (filterDropdown.value === 'manufacturers') {
              //  stockDropdown.value = 'instock';
            }
        });

        jQuery(document).ready(function($) {
            const manufacturers_selected = $('#filter_by_list_manufacturers').val();
            const filter_by_expiry = $('#filter_by_expiry').val();
            const custom_date_from = $('#custom_date_from').val();
            const custom_date_to = $('#custom_date_to').val();
            const least_sold_options = $('#least_sold_options').val();
            if(custom_date_from != '' || custom_date_to != ''){
                $('#custom_date_filter').show();
            }
            if(manufacturers_selected != ''){
                $('#filter_by_list_manufacturers').show();
            }
            if(filter_by_expiry != ''){
                $('#filter_by_expiry').show();
            }
            if(least_sold_options != '' ){
                $('#custom_least_sold_filter').show();
            }
            $('#filter_by_expiry').change(function() {
                var selectedOption = $(this).val();
                if (selectedOption === 'custom_date') {
                    $('#custom_date_filter').show();
                } else {
                    $('#custom_date_filter').hide();
                }
            });
            $('#filter_by_custom_option').change(function() {
                var selectedOption = $(this).val();
                if (selectedOption === 'expiring_products') {
                    $('#filter_by_expiry').show();
                }else if (selectedOption === 'manufacturers') {
                    $('#filter_by_list_manufacturers').show();
                }else if (selectedOption === 'most_sold' || selectedOption === 'least_sold' ) {
                    $('#custom_least_sold_filter').show();
                }
            });
        });
    </script><?php
}

function whm_order_post_type_filter_custom() {

    if (!current_user_can('administrator') || ( $_REQUEST['post_type'] ?? '' ) !== 'shop_order') {
        return;
    }

    $selected_product = isset( $_GET['product_id'] ) ? $_GET['product_id'] : '';
    // Get list of products
    $products = get_posts( array(
        'post_type' => 'product',
        'posts_per_page' => -1,
        'orderby' => 'title',
        'order' => 'ASC',
        'post_status' => 'publish',
        'no_found_rows' => true,
        'update_post_meta_cache' => false,
        'update_post_term_cache' => false,
    ) );
    echo '<select name="product_id">';
    echo '<option value="">' . esc_html__( 'Tutti i prodotti', 'warehouse-management' ) . '</option>';
    foreach ( $products as $product ) {
        $selected = selected( $selected_product, $product->ID, false );
        echo '<option value="' . esc_attr( $product->ID ) . '" ' . $selected . '>' . esc_html( $product->post_title ) . '</option>';
    }
    echo '</select>';
}


function whm_product_post_type_query_custom( $query ) {

    if (!is_admin() || !$query->is_main_query()) {
        return;
    }

    if (current_user_can('administrator') && isset($_GET['filter_by_expiry'])) {
        $filter_option = isset( $_GET['filter_by_expiry'] ) ? sanitize_key( wp_unslash( $_GET['filter_by_expiry'] ) ) : '';

        
if ($filter_option === 'expiring_soon') {
    $expiring_date = date('Ymd', strtotime('+7 days'));
    
    $meta_query = array('relation' => 'AND');
    
    for ($i = 0; $i < 5; $i++) {
        $meta_query[] = array(
            'relation' => 'AND',
            array(
                'key' => "lot_management_{$i}_expiry_date",
                'value' => '',
                'compare' => '!=',
            ),
            array(
                'key' => "lot_management_{$i}_expiry_date",
                'value' => $expiring_date,
                'type' => 'CHAR',
                'compare' => '<=',
            ),
        );
    }

    $query->set('meta_query', $meta_query);

} elseif ($filter_option === 'tomorrow') {
    $tomorrow_date = date('Ymd', strtotime('tomorrow'));

    $meta_query = array('relation' => 'AND');
    
    for ($i = 0; $i < 5; $i++) {
        $meta_query[] = array(
            'relation' => 'AND',
            array(
                'key' => "lot_management_{$i}_expiry_date",
                'value' => '',
                'compare' => '!=',
            ),
            array(
                'key' => "lot_management_{$i}_expiry_date",
                'value' => $tomorrow_date,
                'type' => 'CHAR',
                'compare' => '<=',
            ),
        );
    }

    $query->set('meta_query', $meta_query);

} elseif ($filter_option === 'this_week') {
   // $end_of_week_date = date('Ymd', strtotime('next Sunday'));

            //  $date_from = date('Ymd', strtotime('monday this week'));
            // $date_to = date('Ymd', strtotime('next sunday'));

            // $meta_query = array('relation' => 'AND');

            //  for ($i = 0; $i < 5; $i++) {
            //     $meta_query[] = array(
            //         'relation' => 'AND',
            //         array(
            //             'key' => "lot_management_0_expiry_date",
            //             'value' => '',
            //             'compare' => '!=', // Not equal to blank
            //         ),
            //         array(
            //             'key' => "lot_management_0_expiry_date",
            //             'value' => array($date_from, $date_to),
            //             'type' => 'CHAR',
            //             'compare' => 'BETWEEN',
            //         ),
            //     );
            //     $index++;
            // }

            // $query->set('meta_query', $meta_query);



} elseif ($filter_option === 'this_month') {
    // Get the first and last day of the current month in Ymd format

            // $date_from = date('Ymd', strtotime('first day of this month'));
            // $date_to = date('Ymd', strtotime('last day of this month'));

            // $meta_query = array('relation' => 'AND');

            //  for ($i = 0; $i < 5; $i++) {
            //     $meta_query[] = array(
            //         'relation' => 'AND',
            //         array(
            //             'key' => "lot_management_0_expiry_date",
            //             'value' => '',
            //             'compare' => '!=', // Not equal to blank
            //         ),
            //         array(
            //             'key' => "lot_management_0_expiry_date",
            //             'value' => array($date_from, $date_to),
            //             'type' => 'CHAR',
            //             'compare' => 'BETWEEN',
            //         ),
            //     );
            //     $index++;
            // }

            // $query->set('meta_query', $meta_query);


}elseif ($filter_option === 'custom_date' && isset($_GET['custom_date_from']) && isset($_GET['custom_date_to'])) {
//             $custom_date_from = sanitize_text_field($_GET['custom_date_from']);
//             $custom_date_to = sanitize_text_field($_GET['custom_date_to']);
// // 		echo "<pre>";
// // 			print_r(get_post_meta(11269));

//             // Validate and set custom date range in the query
//             $date_from = date('Ymd', strtotime($custom_date_from));
//             $date_to = date('Ymd', strtotime($custom_date_to));

//             $meta_query = array('relation' => 'OR');

//              for ($i = 0; $i < 5; $i++) {
//                 $meta_query[] = array(
//                     'relation' => 'AND',
//                     array(
//                         'key' => "lot_management_{$i}_expiry_date",
//                         'value' => '',
//                         'compare' => '!=', // Not equal to blank
//                     ),
//                     array(
//                         'key' => "lot_management_{$i}_expiry_date",
//                         'value' => array($date_from, $date_to),
//                         'type' => 'CHAR',
//                         'compare' => 'BETWEEN',
//                     ),
//                 );
//                 $index++;
//             }

//             $query->set('meta_query', $meta_query);

        }
        //echo "<pre>".print_r($query->query_vars['meta_query'], true)."</pre>";

        if(!empty($query->tax_query->queries[0])){
            $main_query_args['tax_query'] = $query->tax_query->queries[0];
        }
        $main_query_args = $query->query_vars;
        $main_query_args['meta_query'] = $query->query_vars['meta_query'];
        $main_query_args['posts_per_page'] = '-1';
        whm_remember_export_query($main_query_args);
    }

    if (current_user_can('administrator') && isset($_GET['filter_by_custom_option']) ) {
        if ($_GET['filter_by_custom_option'] === 'most_sold') {
            $ls_month_dropdown = isset($_GET['ls_month_dropdown']) ? $_GET['ls_month_dropdown'] : '';
            $ls_custom_date_from = sanitize_text_field( wp_unslash( $_GET['ls_custom_date_from'] ?? '' ) );
            $ls_custom_date_to = sanitize_text_field( wp_unslash( $_GET['ls_custom_date_to'] ?? '' ) );
            if ( $ls_month_dropdown != '' ) {
                $product_ids = get_most_sold_product_ids_in_month( $ls_month_dropdown );
                if ( ! empty( $product_ids ) ) {
                    // Modify the query to include only the products sold in the current month, ordered by their sales
                    $query->set( 'post__in', $product_ids );
                    $query->set( 'orderby', 'post__in' ); // Maintain the order of product IDs as fetched
                } else {
                    // If no products sold in the current month, set a meta query that will result in no products
                    $query->set( 'post__in', [0] );
                }
            } else if (!empty($ls_custom_date_from) && !empty($ls_custom_date_to)) {
                $product_ids = get_most_sold_product_ids_in_custom_dates( $ls_custom_date_from, $ls_custom_date_to );
                if ( ! empty( $product_ids ) ) {
                    // Modify the query to include only the products sold in the current month, ordered by their sales
                    $query->set( 'post__in', $product_ids );
                    $query->set( 'orderby', 'post__in' ); // Maintain the order of product IDs as fetched
                } else {
                    // If no products sold in the current month, set a meta query that will result in no products
                    $query->set( 'post__in', [0] );
                }
            }else{
                $query->set('meta_key', 'total_sales');
                $query->set('orderby', 'meta_value_num');
                $query->set('order', 'DESC');
            }


        } elseif ($_GET['filter_by_custom_option'] === 'least_sold') {
            $ls_month_dropdown = isset($_GET['ls_month_dropdown']) ? $_GET['ls_month_dropdown'] : '';
            if ( $ls_month_dropdown != '' ) {
                $product_ids = get_least_sold_product_ids_in_month( $ls_month_dropdown );
                if ( ! empty( $product_ids ) ) {
                    // Modify the query to include only the products sold in the current month, ordered by their sales
                    $query->set( 'post__in', $product_ids );
                    $query->set( 'orderby', 'post__in' ); // Maintain the order of product IDs as fetched
                } else {
                    // If no products sold in the current month, set a meta query that will result in no products
                    $query->set( 'post__in', [0] );
                }

            }else if (!empty($ls_custom_date_from) && !empty($ls_custom_date_to)) {
                $product_ids = get_least_sold_product_ids_in_custom_dates( $ls_custom_date_from, $ls_custom_date_to );
                if ( ! empty( $product_ids ) ) {
                    // Modify the query to include only the products sold in the current month, ordered by their sales
                    $query->set( 'post__in', $product_ids );
                    $query->set( 'orderby', 'post__in' ); // Maintain the order of product IDs as fetched
                } else {
                    // If no products sold in the current month, set a meta query that will result in no products
                    $query->set( 'post__in', [0] );
                }
            }else{
                $query->set('meta_key', 'total_sales');
                $query->set('orderby', 'meta_value_num');
                $query->set('order', 'ASC');
            }
        }
        if(!empty($query->tax_query->queries[0])){
            $main_query_args['tax_query'] = $query->tax_query->queries[0];
        }
        $main_query_args = $query->query_vars;
        $main_query_args['meta_query'] = $query->query_vars['meta_query'];
        $main_query_args['posts_per_page'] = '-1';

        // echo "abc-<pre>";
        // print_r($main_query_args);
        // echo "</pre>";

        whm_remember_export_query($main_query_args);
    }
}

function get_most_sold_product_ids_in_custom_dates( $start_date, $end_date ) {
    global $wpdb;

    $o = whm_order_sql_parts();
    $start_date = whm_order_sql_date( $start_date );
    $end_date   = whm_order_sql_date( $end_date );

    $results = $wpdb->get_results($wpdb->prepare(
        "SELECT order_item_meta_2.meta_value as product_id, SUM(order_item_meta.meta_value) as total_qty
        FROM {$wpdb->prefix}woocommerce_order_items as order_items
        JOIN {$wpdb->prefix}woocommerce_order_itemmeta as order_item_meta ON order_items.order_item_id = order_item_meta.order_item_id
        JOIN {$wpdb->prefix}woocommerce_order_itemmeta as order_item_meta_2 ON order_items.order_item_id = order_item_meta_2.order_item_id
        JOIN {$o['table']} as posts ON order_items.order_id = posts.{$o['id']}
        WHERE order_item_meta.meta_key = '_qty'
        AND order_item_meta_2.meta_key = '_product_id'
        AND posts.{$o['type']} = 'shop_order'
        AND posts.{$o['status']} IN ('wc-completed', 'wc-processing', 'wc-on-hold')
        AND posts.{$o['date']} >= %s
        AND posts.{$o['date']} <= %s
        GROUP BY product_id
        ORDER BY total_qty DESC",
        $start_date, $end_date
    ));

    $product_ids = [];
    foreach ( $results as $result ) {
        $product_ids[] = $result->product_id;
    }

    return $product_ids;
}

function get_most_sold_product_ids_in_month( $month ) {
    global $wpdb;

    $nmonth = date("m", strtotime($month));
    $year = date('Y');
    $start_date = sprintf("%s-%02d-01 00:00:00", $year, $nmonth);

    $end_date = sprintf("%s-%02d-%02d 23:59:59", $year, $nmonth, date('t', strtotime($start_date))); // 't' gives the number of days in the month

    $o = whm_order_sql_parts();
    $start_date = whm_order_sql_date( $start_date );
    $end_date   = whm_order_sql_date( $end_date );

    $results = $wpdb->get_results($wpdb->prepare(
        "SELECT order_item_meta_2.meta_value as product_id, SUM(order_item_meta.meta_value) as total_qty
        FROM {$wpdb->prefix}woocommerce_order_items as order_items
        JOIN {$wpdb->prefix}woocommerce_order_itemmeta as order_item_meta ON order_items.order_item_id = order_item_meta.order_item_id
        JOIN {$wpdb->prefix}woocommerce_order_itemmeta as order_item_meta_2 ON order_items.order_item_id = order_item_meta_2.order_item_id
        JOIN {$o['table']} as posts ON order_items.order_id = posts.{$o['id']}
        WHERE order_item_meta.meta_key = '_qty'
        AND order_item_meta_2.meta_key = '_product_id'
        AND posts.{$o['type']} = 'shop_order'
        AND posts.{$o['status']} IN ('wc-completed', 'wc-processing', 'wc-on-hold')
        AND posts.{$o['date']} >= %s
        AND posts.{$o['date']} <= %s
        GROUP BY product_id
        ORDER BY total_qty DESC",
        $start_date, $end_date
    ));

    $product_ids = [];
    foreach ( $results as $result ) {
        $product_ids[] = $result->product_id;
    }

    return $product_ids;
}

function get_least_sold_product_ids_in_month( $month ) {
    global $wpdb;

    $nmonth = date("m", strtotime($month));
    $year = date('Y');
    $start_date = sprintf("%s-%02d-01 00:00:00", $year, $nmonth);
    $end_date = sprintf("%s-%02d-%02d 23:59:59", $year, $nmonth, date('t', strtotime($start_date))); // 't' gives the number of days in the month

    $o = whm_order_sql_parts();
    $start_date = whm_order_sql_date( $start_date );
    $end_date   = whm_order_sql_date( $end_date );

    $results = $wpdb->get_results($wpdb->prepare(
        "SELECT order_item_meta_2.meta_value as product_id, SUM(order_item_meta.meta_value) as total_qty
        FROM {$wpdb->prefix}woocommerce_order_items as order_items
        JOIN {$wpdb->prefix}woocommerce_order_itemmeta as order_item_meta ON order_items.order_item_id = order_item_meta.order_item_id
        JOIN {$wpdb->prefix}woocommerce_order_itemmeta as order_item_meta_2 ON order_items.order_item_id = order_item_meta_2.order_item_id
        JOIN {$o['table']} as posts ON order_items.order_id = posts.{$o['id']}
        WHERE order_item_meta.meta_key = '_qty'
        AND order_item_meta_2.meta_key = '_product_id'
        AND posts.{$o['type']} = 'shop_order'
        AND posts.{$o['status']} IN ('wc-completed', 'wc-processing', 'wc-on-hold')
        AND posts.{$o['date']} >= %s
        AND posts.{$o['date']} <= %s
        GROUP BY product_id
        ORDER BY total_qty ASC",
        $start_date, $end_date
    ));

    $product_ids = [];
    foreach ( $results as $result ) {
        $product_ids[] = $result->product_id;
    }

    return $product_ids;
}

function get_least_sold_product_ids_in_custom_dates( $start_date, $end_date ) {
    global $wpdb;

    $o = whm_order_sql_parts();
    $start_date = whm_order_sql_date( $start_date );
    $end_date   = whm_order_sql_date( $end_date );

    $results = $wpdb->get_results($wpdb->prepare(
        "SELECT order_item_meta_2.meta_value as product_id, SUM(order_item_meta.meta_value) as total_qty
        FROM {$wpdb->prefix}woocommerce_order_items as order_items
        JOIN {$wpdb->prefix}woocommerce_order_itemmeta as order_item_meta ON order_items.order_item_id = order_item_meta.order_item_id
        JOIN {$wpdb->prefix}woocommerce_order_itemmeta as order_item_meta_2 ON order_items.order_item_id = order_item_meta_2.order_item_id
        JOIN {$o['table']} as posts ON order_items.order_id = posts.{$o['id']}
        WHERE order_item_meta.meta_key = '_qty'
        AND order_item_meta_2.meta_key = '_product_id'
        AND posts.{$o['type']} = 'shop_order'
        AND posts.{$o['status']} IN ('wc-completed', 'wc-processing', 'wc-on-hold')
        AND posts.{$o['date']} >= %s
        AND posts.{$o['date']} <= %s
        GROUP BY product_id
        ORDER BY total_qty ASC",
        $start_date, $end_date
    ));

    $product_ids = [];
    foreach ( $results as $result ) {
        $product_ids[] = $result->product_id;
    }

    return $product_ids;
}


function whm_get_orders_ids_by_product_id($product_id) {

    global $wpdb;
    $o = whm_order_sql_parts();
    $order_status = ['wc-completed', 'wc-processing', 'wc-on-hold'];

    $results = $wpdb->get_col($wpdb->prepare("
        SELECT order_items.order_id
        FROM {$wpdb->prefix}woocommerce_order_items as order_items
        LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta as order_item_meta ON order_items.order_item_id = order_item_meta.order_item_id
        LEFT JOIN {$o['table']} AS posts ON order_items.order_id = posts.{$o['id']}
        WHERE posts.{$o['type']} = 'shop_order'
        AND posts.{$o['status']} IN ( '" . implode( "','", $order_status ) . "' )
        AND order_items.order_item_type = 'line_item'
        AND order_item_meta.meta_key = '_product_id'
        AND order_item_meta.meta_value = %d
        ORDER BY order_items.order_id DESC", absint( $product_id )));

    return $results;
}

add_action('pre_get_posts', function($query) {
    // Only apply to admin and correct post type list view
    if (!is_admin() || !$query->is_main_query()) return;

    // Adjust to your post type
    if ($query->get('post_type') !== 'product') return;

    $filter_option = isset( $_GET['filter_by_expiry'] ) ? sanitize_key( wp_unslash( $_GET['filter_by_expiry'] ) ) : '';

    if (isset($filter_option) && $filter_option !='' && $filter_option === 'custom_date' && isset($_GET['custom_date_from']) && isset($_GET['custom_date_to'])) {
        $date_from = date('Ymd', strtotime(sanitize_text_field($_GET['custom_date_from'])));
        $date_to   = date('Ymd', strtotime(sanitize_text_field($_GET['custom_date_to'])));
        $post_ids = getPostIdsFromCustomQueries( $date_from, $date_to );
    }elseif(isset($filter_option) && $filter_option !='' && $filter_option === 'this_month'){
        $date_from = date('Ymd', strtotime('first day of this month'));
        $date_to = date('Ymd', strtotime('last day of this month'));
        $post_ids = getPostIdsFromCustomQueries( $date_from, $date_to );
    }elseif (isset($filter_option) && $filter_option !='' && $filter_option === 'this_week') {
        $date_from = date('Ymd', strtotime('monday this week'));
        $date_to = date('Ymd', strtotime('next sunday'));
        $post_ids = getPostIdsFromCustomQueries( $date_from, $date_to );
    }elseif ($filter_option === 'tomorrow') {
        // $tomorrow_date = date('Ymd', strtotime('tomorrow'));
        // $post_ids = getPostIdsFromCustomQueries( $tomorrow_date, $tomorrow_date );
    }

    // Check for the custom filter parameters
    if ( !empty($post_ids) && $filter_option!='' ) {
        $query->set('post__in', $post_ids);
    }
});

function getPostIdsFromCustomQueries( $date_from, $date_to )  {
    if(empty($date_from) || empty($date_to))
        return;

    global $wpdb;

    $conditions = [];
    for ($i = 0; $i < 5; $i++) {
        $key = "lot_management_{$i}_expiry_date";
        $conditions[] = $wpdb->prepare(
            "(pm.meta_key = %s AND pm.meta_value != '' AND pm.meta_value BETWEEN %s AND %s)",
            $key, $date_from, $date_to
        );
    }

    $sql = "
        SELECT DISTINCT pm.post_id
        FROM {$wpdb->postmeta} pm
        WHERE " . implode(" OR ", $conditions);

    $post_ids = $wpdb->get_col($sql);
    return $post_ids;
}