<?php
/**
 * Post Type : Products
 * @param $columns
 * @return mixed
 */
function lagalpi_whm_product_columns( $columns ) {
	//if(WHM_DEBUG === true ){

	unset($columns['product_tag']);
	unset($columns['facebook_sync']);

    //$columns =  setColumnAfterCertainKey($columns, 'country', 'Country');
   // $columns =  setColumnAfterCertainKey($columns, 'last_order_date', 'Last Order Date');
    //$columns =  setColumnAfterCertainKey($columns, 'manufacturer_ref_no', 'Man. Ref No.');
    $columns =  setColumnAfterCertainKey($columns, 'orders', __( 'Ordini', 'warehouse-management' ));


    return setColumnAfterCertainKey($columns, 'variation_export', __( 'Esporta', 'warehouse-management' ));

}

function lagalpi_custom_product_column_content( $column, $post_id ) {
	if ( 'orders' === $column ) {
		$shop_order_url = whm_orders_list_url( $post_id );
		echo '<a target="_blank" href="' . esc_url( $shop_order_url ) . '">' . esc_html__( 'Ordini', 'warehouse-management' ) . '</a>';
	}
    if ( 'variation_export' === $column ) {
        $product = wc_get_product($post_id);
        if ($product && $product->is_type('variable')) {
            $export_url = wp_nonce_url( admin_url( 'edit.php?post_type=product&export=all_data&product_id=' . absint( $post_id ) ), 'whm_export_variations_' . absint( $post_id ) );
            echo '<a target="_blank" href="' . esc_url( $export_url ) . '">' . esc_html__( 'Esporta CSV', 'warehouse-management' ) . '</a>';
        }

	}

//	if ( 'country' === $column ) {
//		$country_of_origin = get_post_meta( $post_id, 'country_of_origin', true );
//		if(isset($country_of_origin) && $country_of_origin != '' ){
//			echo esc_html( $country_of_origin );
//		}
//	}
//	if ( 'last_order_date' === $column ) {
//		$last_order_date = get_field( 'last_order_date_from_producer', $post_id );
//		if(isset($last_order_date) && $last_order_date != '' ){
//			echo esc_html( $last_order_date );
//		}
//	}

//	if ( 'manufacturer_ref_no' === $column ) {
//		$manufacturer_ref_no = get_post_meta( $post_id, 'manufacturer_reference_number', true );
//		if(isset($manufacturer_ref_no) && $manufacturer_ref_no != '' ){
//			echo esc_html( $manufacturer_ref_no );
//		}
//	}
}

// Function to export variations of a specific product ID to CSV with custom columns
function export_variations_to_csv_with_custom_columns($product_id) { 

    $product = wc_get_product($product_id);
    $data_rows = array();
    if( $product->is_type('variable') ){
        $variations = $product->get_available_variations();
        $stock_count       = $product->get_stock_quantity();

        $attribute_name = 'pa_produttore';
        $attribute_value = $product->get_attribute($attribute_name);
        $attribute_value = $attribute_value ?? '';

        $_wc_cog_cost        = get_post_meta($product_id, '_wc_cog_cost', true);
         $product_sku = get_post_meta($product_id, '_sku', true );

        $product_title     = $product->get_name();
        if (!empty($variations)) {
            // Loop through each variation
            $sr = 1;
            foreach ($variations as $variation) {
                $variation_id = $variation['variation_id'];
                $variation_obj = wc_get_product($variation_id);

                $lot_data = getLotDataByVariationId( $variation_id );

                $expiry_html = '';
                if(!empty($lot_data)){
                    foreach ($lot_data as $lot_object ){
                        $lot_name = $lot_object['lot'];
                        $lot_expiry_date = $lot_object['expiry_date'];
                        $lot_qty = $lot_object['qty'];
                        if(isset($lot_name, $lot_expiry_date, $lot_qty)){
                            $expiry_html .= "Lot Name : {$lot_name} | Lot Expiry Date : {$lot_expiry_date} | Lot QTY : {$lot_qty} ";
                        }
                    }
                }
                $variation_price = $variation_obj->get_price();
                $total_lots = $lot_data['total_lots'];
                $data_rows[] = array(
                    'sr' => $sr,
                    'sku' => $product_sku,
                    'name' => $product_title,
                    'stock' => $stock_count,
                    'prezzo' => $variation_price,
                    'cog' => $_wc_cog_cost,
                    'lot' => $total_lots,
                    'fornitore' => $attribute_value,
                    'expiry' => $expiry_html
                );
                $sr++;
            }
        }
    }

    $header_row = array('#','COD', 'Title', 'Stock', 'Prezzo ( CHF )', 'COG Cost', 'Lot', 'Fornitore', 'Expiry Date');
	$time_stamp = time();
	$filename = "product-{$product_id}-variations-{$time_stamp}.csv";
	$fh = @fopen( 'php://output', 'w' );
	fprintf( $fh, chr(0xEF) . chr(0xBB) . chr(0xBF) );
	header( 'Cache-Control: must-revalidate, post-check=0, pre-check=0' );
	header( 'Content-Description: File Transfer' );
	header( 'Content-type: text/csv' );
	header( "Content-Disposition: attachment; filename={$filename}" );
	header( 'Expires: 0' );
	header( 'Pragma: public' );
	fputcsv( $fh, $header_row );
	foreach ( $data_rows as $data_row ) {
		fputcsv( $fh, $data_row );
	}
	fclose( $fh );
    exit;
}
function setColumnAfterCertainKey( $columns, $new_key, $new_label ) {
	if(empty($new_key))
		return;

	// Find the index of 'sku' key;
	$index = array_search('sku', array_keys($columns));
	// Split the array into two parts before and after 'sku'
	$before_sku = array_slice($columns, 0, $index + 1, true);
	$after_sku = array_slice($columns, $index + 1, null, true);
	// Insert the new key 'country' with its value after the 'sku' key
	return $before_sku + [ $new_key => $new_label ] + $after_sku;
}