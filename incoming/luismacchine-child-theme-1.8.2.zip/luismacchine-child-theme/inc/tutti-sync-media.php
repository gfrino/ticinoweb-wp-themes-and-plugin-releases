<?php
/**
 * Secure media sideloading for the prepared tutti.ch synchronization.
 *
 * This code runs only after the public connector has provided normalized
 * image URLs. Images are copied into the WordPress media library; the frontend
 * never hotlinks files from tutti.ch.
 *
 * @package LuismacchineChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Import at most 15 listing images and update the product gallery.
 *
 * Existing attachments are never deleted. If a remote image disappears from
 * an updated listing, it is removed from the product gallery but remains in the
 * media library for recovery.
 *
 * @param int    $post_id Product ID.
 * @param array  $item    Normalized listing.
 * @param string $action  Import action.
 * @return void
 */
function luismacchine_tutti_sync_product_media( $post_id, $item, $action ) {
	unset( $action );

	if ( empty( $item['images'] ) || ! is_array( $item['images'] ) ) {
		return;
	}

	$image_urls = array_slice( array_values( array_unique( $item['images'] ) ), 0, 15 );
	$stored_map = get_post_meta( $post_id, '_lm_tutti_image_map', true );
	$stored_map = is_array( $stored_map ) ? $stored_map : array();
	$new_map    = array();
	$image_ids  = array();

	foreach ( $image_urls as $position => $image_url ) {
		$image_url = esc_url_raw( $image_url );
		if ( ! luismacchine_tutti_image_url_allowed( $image_url ) ) {
			continue;
		}

		$attachment_id = isset( $stored_map[ $image_url ] ) ? absint( $stored_map[ $image_url ] ) : 0;
		if ( ! $attachment_id || 'attachment' !== get_post_type( $attachment_id ) ) {
			$attachment_id = luismacchine_tutti_sideload_image( $image_url, $post_id, $position );
		}
		if ( ! $attachment_id ) {
			continue;
		}

		$new_map[ $image_url ] = $attachment_id;
		$image_ids[]           = $attachment_id;
	}

	if ( empty( $image_ids ) ) {
		return;
	}

	update_post_meta( $post_id, '_lm_tutti_image_map', $new_map );
	set_post_thumbnail( $post_id, $image_ids[0] );
	update_post_meta( $post_id, '_lm_gallery_ids', implode( ',', array_slice( $image_ids, 1 ) ) );
}
add_action( 'luismacchine_tutti_item_saved', 'luismacchine_tutti_sync_product_media', 10, 3 );

/**
 * Download one allowed image into the WordPress media library.
 *
 * @param string $image_url Remote image URL.
 * @param int    $post_id   Parent product ID.
 * @param int    $position  Image position in the listing.
 * @return int Attachment ID or zero.
 */
function luismacchine_tutti_sideload_image( $image_url, $post_id, $position ) {
	if ( ! luismacchine_tutti_image_url_allowed( $image_url ) ) {
		return 0;
	}

	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';

	$max_size = (int) apply_filters( 'luismacchine_tutti_max_image_bytes', 12 * MB_IN_BYTES );
	$tmp_file = wp_tempnam( $image_url );
	if ( ! $tmp_file ) {
		return 0;
	}

	$response = wp_safe_remote_get(
		$image_url,
		array(
			'timeout'             => 30,
			'redirection'         => 3,
			'stream'              => true,
			'filename'            => $tmp_file,
			'limit_response_size' => $max_size + 1,
		)
	);
	if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
		wp_delete_file( $tmp_file );
		return 0;
	}

	$file_size = filesize( $tmp_file );
	if ( false === $file_size || $file_size < 1 || $file_size > $max_size ) {
		wp_delete_file( $tmp_file );
		return 0;
	}

	$url_path  = (string) wp_parse_url( $image_url, PHP_URL_PATH );
	$file_name = sanitize_file_name( wp_basename( $url_path ) );
	if ( ! preg_match( '/\.(jpe?g|png|webp|avif)$/i', $file_name ) ) {
		wp_delete_file( $tmp_file );
		return 0;
	}

	$file_check = wp_check_filetype_and_ext( $tmp_file, $file_name );
	$allowed    = array( 'image/jpeg', 'image/png', 'image/webp', 'image/avif' );
	if ( empty( $file_check['type'] ) || ! in_array( $file_check['type'], $allowed, true ) ) {
		wp_delete_file( $tmp_file );
		return 0;
	}

	$file_array = array(
		'name'     => $file_name,
		'tmp_name' => $tmp_file,
	);
	$attachment_id = media_handle_sideload( $file_array, $post_id, get_the_title( $post_id ) );
	if ( is_wp_error( $attachment_id ) ) {
		if ( file_exists( $tmp_file ) ) {
			wp_delete_file( $tmp_file );
		}
		return 0;
	}

	update_post_meta(
		$attachment_id,
		'_wp_attachment_image_alt',
		sprintf(
			/* translators: 1: product title, 2: image position. */
			__( '%1$s – foto %2$d', 'luismacchine-child-theme' ),
			get_the_title( $post_id ),
			absint( $position ) + 1
		)
	);
	update_post_meta( $attachment_id, '_lm_tutti_source_url', esc_url_raw( $image_url ) );

	return absint( $attachment_id );
}
