<?php
/**
 * IL MODULO DI CANDIDATURA della pagina Jobs, senza plugin.
 *
 * Replica i campi del modulo Squarespace di tenconi.ch/jobs: nome, cognome,
 * data di nascita, telefono, indirizzo con paese, email, posizione, messaggio,
 * allegati e consenso al trattamento dei dati.
 *
 * Stessa architettura e stesse difese del modulo contatti (inc/contact-form.php):
 * admin-post.php, POST-redirect-GET, nonce, honeypot, tempo minimo, un invio al
 * minuto per IP, validazione lato server. Il destinatario e' lo stesso
 * (tenconi_form_destinatario).
 *
 * INVII RICEVUTI. Ogni candidatura viene scritta anche nella tabella del CMS
 * ({prefix}ticinoweb_form_submissions, pannello ticinoWEB CMS -> Invii
 * Ricevuti), cosi' non va persa se la posta non parte, e da li' si cancella.
 * Il gestore del parent non si puo' usare cosi' com'e': accetta cinque campi
 * fissi e nessun allegato. Gli allegati quindi NON vanno nel database: passano
 * da una cartella temporanea il tempo di spedirli, poi vengono cancellati.
 *
 * RECAPTCHA del CMS (v3): attivo solo se il sito ha le chiavi nel pannello;
 * senza chiavi il modulo funziona con le altre difese.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** L'azione di admin-post. */
const TENCONI_CAND_AZIONE = 'tenconi_candidatura';

/** Allegati: quanti, quanto pesa ciascuno, quanto pesano insieme (la posta ha i suoi limiti). */
const TENCONI_CAND_MAX_FILE   = 5;
const TENCONI_CAND_MAX_PESO   = 5 * MB_IN_BYTES;
const TENCONI_CAND_MAX_TOTALE = 10 * MB_IN_BYTES;

/**
 * Le estensioni accettate, le stesse del modulo di tenconi.ch.
 *
 * @return string[]
 */
function tenconi_cand_estensioni() {
	return array( 'pdf', 'doc', 'docx', 'txt', 'pptx', 'jpg', 'jpeg', 'png', 'webp', 'heic', 'tif', 'tiff' );
}

/**
 * I campi, nell'ordine del modulo originale. `gruppo` raggruppa l'indirizzo.
 *
 * @return array<string,array<string,mixed>>
 */
function tenconi_cand_campi() {
	return array(
		'nome'      => array( 'label' => 'Nome', 'tipo' => 'text', 'obbl' => true, 'largo' => false, 'auto' => 'given-name' ),
		'cognome'   => array( 'label' => 'Cognome', 'tipo' => 'text', 'obbl' => true, 'largo' => false, 'auto' => 'family-name' ),
		'nascita'   => array( 'label' => 'Data di nascita', 'tipo' => 'date', 'obbl' => true, 'largo' => false, 'auto' => 'bday' ),
		'telefono'  => array( 'label' => 'Recapito telefonico', 'tipo' => 'tel', 'obbl' => true, 'largo' => false, 'auto' => 'tel' ),
		'paese'     => array( 'label' => 'Paese', 'tipo' => 'paese', 'obbl' => true, 'largo' => true, 'auto' => 'country', 'gruppo' => 'indirizzo' ),
		'via'       => array( 'label' => 'Via e numero', 'tipo' => 'text', 'obbl' => true, 'largo' => true, 'auto' => 'address-line1', 'gruppo' => 'indirizzo' ),
		'via2'      => array( 'label' => 'Complemento d’indirizzo', 'tipo' => 'text', 'obbl' => false, 'largo' => true, 'auto' => 'address-line2', 'gruppo' => 'indirizzo' ),
		'cap'       => array( 'label' => 'CAP', 'tipo' => 'text', 'obbl' => true, 'largo' => false, 'auto' => 'postal-code', 'gruppo' => 'indirizzo' ),
		'citta'     => array( 'label' => 'Località', 'tipo' => 'text', 'obbl' => true, 'largo' => false, 'auto' => 'address-level2', 'gruppo' => 'indirizzo' ),
		'email'     => array( 'label' => 'Email', 'tipo' => 'email', 'obbl' => true, 'largo' => true, 'auto' => 'email' ),
		'posizione' => array( 'label' => 'Posizione per la quale ti candidi', 'tipo' => 'text', 'obbl' => true, 'largo' => true, 'auto' => 'off' ),
		'messaggio' => array( 'label' => 'Messaggio', 'tipo' => 'textarea', 'obbl' => true, 'largo' => true, 'auto' => 'off' ),
	);
}

/**
 * Un testo del modulo, traducibile da tW Translate.
 *
 * @param string $testo  Testo italiano.
 * @param string $chiave Suffisso della chiave.
 * @return string
 */
function tenconi_cand_t( $testo, $chiave ) {
	return function_exists( 'tenconi_int_t' ) ? tenconi_int_t( $testo, 'tenconi:candidatura:' . $chiave ) : $testo;
}

/**
 * I paesi (codice ISO => nome nella lingua richiesta), in ordine alfabetico.
 * I nomi li da' la libreria intl di PHP: nessun elenco da tradurre a mano.
 *
 * @param string $lingua Locale, es. "it_CH".
 * @return array<string,string>
 */
function tenconi_cand_paesi( $lingua = '' ) {
	$codici = 'AF AX AL DZ AS AD AO AI AG AR AM AW AU AT AZ BS BH BD BB BY BE BZ BJ BM BT BO BA BW BR IO VG BN BG BF BI KH CM CA CV BQ KY CF TD CL CN CX CC CO KM CG CD CK CR CI HR CU CW CY CZ DK DJ DM DO EC EG SV GQ ER EE SZ ET FK FO FJ FI FR GF PF GA GM GE DE GH GI GR GL GD GP GU GT GG GN GW GY HT HN HK HU IS IN ID IR IQ IE IM IL IT JM JP JE JO KZ KE KI XK KW KG LA LV LB LS LR LY LI LT LU MO MG MW MY MV ML MT MH MQ MR MU YT MX FM MD MC MN ME MS MA MZ MM NA NR NP NL NC NZ NI NE NG NU NF KP MK MP NO OM PK PW PS PA PG PY PE PH PN PL PT PR QA RE RO RU RW WS SM ST SA SN RS SC SL SG SX SK SI SB SO ZA KR SS ES LK BL SH KN LC MF PM VC SD SR SJ SE CH SY TW TJ TZ TH TL TG TK TO TT TN TR TM TC TV UM VI UG UA AE GB US UY UZ VU VA VE VN WF EH YE ZM ZW';
	$lingua = '' !== $lingua ? $lingua : determine_locale();
	$paesi  = array();
	foreach ( explode( ' ', $codici ) as $c ) {
		$paesi[ $c ] = class_exists( 'Locale' ) ? Locale::getDisplayRegion( 'und-' . $c, $lingua ) : $c;
	}
	if ( class_exists( 'Collator' ) ) {
		$ord = new Collator( $lingua );
		uasort( $paesi, array( $ord, 'compare' ) );
	} else {
		asort( $paesi );
	}
	return $paesi;
}

/**
 * Riceve la candidatura, verifica, spedisce con gli allegati, torna alla pagina.
 *
 * @return void
 */
function tenconi_cand_gestisci() {

	$ritorno = wp_get_referer();
	if ( ! $ritorno ) {
		$ritorno = (string) get_post_type_archive_link( 'job' );
	}
	$ritorno = remove_query_arg( array( 'tl_cand', 'tl_errore' ), $ritorno );

	$fine = function ( $esito, $errore = '' ) use ( $ritorno ) {
		$arg = array( 'tl_cand' => $esito );
		if ( '' !== $errore ) {
			$arg['tl_errore'] = $errore;
		}
		wp_safe_redirect( add_query_arg( $arg, $ritorno ) . '#tl-candidatura' );
		exit;
	};

	/*
	 * 0. Allegati oltre post_max_size: PHP svuota $_POST e il nonce "manca".
	 * Senza questo controllo il candidato leggerebbe "sessione scaduta".
	 */
	$lunghezza = isset( $_SERVER['CONTENT_LENGTH'] ) ? (int) $_SERVER['CONTENT_LENGTH'] : 0;
	if ( empty( $_POST ) && $lunghezza > 0 ) {
		$fine( 'ko', 'file-peso' );
	}

	// 1. nonce
	if ( ! isset( $_POST['tl_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['tl_nonce'] ) ), TENCONI_CAND_AZIONE ) ) {
		$fine( 'ko', 'sessione' );
	}

	// 2. honeypot e 3. tempo minimo: ai bot si risponde "ok"
	if ( ! empty( $_POST['tl_sito'] ) ) {
		$fine( 'ok' );
	}
	$aperto = isset( $_POST['tl_t'] ) ? (int) $_POST['tl_t'] : 0;
	if ( $aperto && ( time() - $aperto ) < 3 ) {
		$fine( 'ok' );
	}

	// 4. rate limiting, separato da quello dei contatti
	$ip    = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$firma = 'tl_cand_' . md5( $ip . wp_salt() );
	if ( get_transient( $firma ) ) {
		$fine( 'ko', 'troppo-veloce' );
	}

	// 5. validazione e 6. sanitizzazione
	$dati    = array();
	$mancano = false;
	foreach ( tenconi_cand_campi() as $chiave => $c ) {
		$grezzo = isset( $_POST[ $chiave ] ) ? wp_unslash( $_POST[ $chiave ] ) : '';
		if ( 'email' === $c['tipo'] ) {
			$val = sanitize_email( $grezzo );
			if ( '' !== trim( (string) $grezzo ) && ! is_email( $val ) ) {
				$fine( 'ko', 'email' );
			}
		} elseif ( 'textarea' === $c['tipo'] ) {
			$val = sanitize_textarea_field( $grezzo );
		} else {
			$val = sanitize_text_field( $grezzo );
		}
		$val = trim( $val );
		if ( mb_strlen( $val ) > 4000 ) {
			$val = mb_substr( $val, 0, 4000 );
		}
		if ( $c['obbl'] && '' === $val ) {
			$mancano = true;
		}
		$dati[ $chiave ] = $val;
	}
	if ( $mancano || empty( $_POST['privacy'] ) ) {
		$fine( 'ko', 'campi' );
	}

	$paesi = tenconi_cand_paesi( 'it_CH' );
	if ( ! isset( $paesi[ $dati['paese'] ] ) ) {
		$fine( 'ko', 'campi' );
	}
	$nascita = DateTime::createFromFormat( '!Y-m-d', $dati['nascita'] );
	$anni    = $nascita ? (int) $nascita->diff( new DateTime( 'today' ) )->y : 0;
	if ( ! $nascita || $nascita->format( 'Y-m-d' ) !== $dati['nascita'] || $anni < 14 || $anni > 90 ) {
		$fine( 'ko', 'nascita' );
	}

	// reCAPTCHA v3 del CMS, solo se il sito lo ha configurato
	if ( get_option( 'ticinoweb_recaptcha_secret_key' ) && function_exists( 'ticinoweb_verify_recaptcha' ) ) {
		$rc_token = isset( $_POST['recaptcha_token'] ) ? sanitize_text_field( wp_unslash( $_POST['recaptcha_token'] ) ) : '';
		$rc       = '' !== $rc_token ? ticinoweb_verify_recaptcha( $rc_token ) : array( 'success' => false );
		if ( empty( $rc['success'] ) ) {
			$fine( 'ko', 'antispam' );
		}
	}

	// 7. allegati: tipo controllato sul contenuto, non solo sul nome
	$allegati = array();
	$cartella = '';
	$pulisci  = function () use ( &$allegati, &$cartella ) {
		foreach ( $allegati as $f ) {
			wp_delete_file( $f );
		}
		if ( '' !== $cartella && is_dir( $cartella ) ) {
			rmdir( $cartella );
		}
	};
	if ( ! empty( $_FILES['allegati']['name'] ) && is_array( $_FILES['allegati']['name'] ) ) {
		$f      = $_FILES['allegati']; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- ogni voce e' verificata sotto.
		$totale = 0;
		$scelti = array_filter( (array) $f['name'], 'strlen' );
		if ( count( $scelti ) > TENCONI_CAND_MAX_FILE ) {
			$fine( 'ko', 'file-numero' );
		}
		foreach ( array_keys( $scelti ) as $i ) {
			if ( UPLOAD_ERR_INI_SIZE === $f['error'][ $i ] || UPLOAD_ERR_FORM_SIZE === $f['error'][ $i ] ) {
				$pulisci();
				$fine( 'ko', 'file-peso' );
			}
			if ( UPLOAD_ERR_OK !== $f['error'][ $i ] || ! is_uploaded_file( $f['tmp_name'][ $i ] ) ) {
				$pulisci();
				$fine( 'ko', 'file-tipo' );
			}
			$peso    = (int) $f['size'][ $i ];
			$totale += $peso;
			if ( $peso > TENCONI_CAND_MAX_PESO || $totale > TENCONI_CAND_MAX_TOTALE ) {
				$pulisci();
				$fine( 'ko', 'file-peso' );
			}
			$nome = sanitize_file_name( wp_unslash( $f['name'][ $i ] ) );
			$tipo = wp_check_filetype_and_ext( $f['tmp_name'][ $i ], $nome );
			$ext  = strtolower( (string) ( $tipo['ext'] ? $tipo['ext'] : pathinfo( $nome, PATHINFO_EXTENSION ) ) );
			if ( ! in_array( $ext, tenconi_cand_estensioni(), true ) || ( ! $tipo['ext'] && ! in_array( $ext, array( 'heic', 'txt' ), true ) ) ) {
				$pulisci();
				$fine( 'ko', 'file-tipo' );
			}
			if ( '' === $cartella ) {
				$cartella = trailingslashit( get_temp_dir() ) . 'tl-cand-' . wp_generate_password( 12, false );
				wp_mkdir_p( $cartella );
			}
			$dest = trailingslashit( $cartella ) . ( '' !== $tipo['proper_filename'] && $tipo['proper_filename'] ? $tipo['proper_filename'] : $nome );
			if ( ! move_uploaded_file( $f['tmp_name'][ $i ], $dest ) ) {
				$pulisci();
				$fine( 'ko', 'invio' );
			}
			$allegati[] = $dest;
		}
	}

	// 8. spedizione
	$campi = tenconi_cand_campi();
	$righe = array();
	foreach ( $campi as $chiave => $c ) {
		if ( '' === $dati[ $chiave ] ) {
			continue;
		}
		$val = $dati[ $chiave ];
		if ( 'paese' === $chiave ) {
			$val = $paesi[ $val ];
		} elseif ( 'nascita' === $chiave ) {
			$val = $nascita->format( 'd.m.Y' );
		}
		$righe[] = $c['label'] . ': ' . $val;
	}
	$righe[] = 'Allegati: ' . ( $allegati ? implode( ', ', array_map( 'basename', $allegati ) ) : 'nessuno' );
	$corpo   = implode( "\n", $righe ) . "\n\n--\nCandidatura inviata dalla pagina Jobs di " . home_url( '/' );
	$oggetto = sprintf( 'Candidatura: %s %s — %s', $dati['nome'], $dati['cognome'], $dati['posizione'] );

	// Invii Ricevuti del CMS: i dati restano anche se la posta non parte; gli allegati no.
	global $wpdb;
	$tabella = $wpdb->prefix . 'ticinoweb_form_submissions';
	if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $tabella ) ) === $tabella ) {
		$wpdb->insert(
			$tabella,
			array(
				'data_invio' => current_time( 'mysql' ),
				'nome'       => $dati['nome'] . ' ' . $dati['cognome'],
				'email'      => $dati['email'],
				'telefono'   => $dati['telefono'],
				'oggetto'    => $oggetto,
				'messaggio'  => implode( "\n", $righe ) . ( $allegati ? "\n(gli allegati sono solo nell'email)" : '' ),
				'letto'      => 0,
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s', '%d' )
		);
	}

	$ok = wp_mail(
		tenconi_form_destinatario(),
		$oggetto,
		$corpo,
		array(
			'Content-Type: text/plain; charset=UTF-8',
			'Reply-To: ' . $dati['email'],
		),
		$allegati
	);

	$pulisci();
	set_transient( $firma, 1, MINUTE_IN_SECONDS );

	$fine( $ok ? 'ok' : 'ko', $ok ? '' : 'invio' );
}
add_action( 'admin_post_nopriv_' . TENCONI_CAND_AZIONE, 'tenconi_cand_gestisci' );
add_action( 'admin_post_' . TENCONI_CAND_AZIONE, 'tenconi_cand_gestisci' );

/**
 * Il messaggio di esito, leggibile da uno screen reader.
 *
 * @return string HTML.
 */
function tenconi_cand_esito() {

	$esito = isset( $_GET['tl_cand'] ) ? sanitize_key( wp_unslash( $_GET['tl_cand'] ) ) : '';
	if ( '' === $esito ) {
		return '';
	}
	$errore = isset( $_GET['tl_errore'] ) ? sanitize_key( wp_unslash( $_GET['tl_errore'] ) ) : '';

	if ( 'ok' === $esito ) {
		$testo = tenconi_cand_t( 'Grazie, la tua candidatura è stata inviata. Ti contatteremo al più presto.', 'esito-ok' );
		$cls   = 'tl-esito--ok';
	} else {
		$mappa = array(
			'campi'         => tenconi_cand_t( 'Alcuni campi obbligatori sono vuoti: completali e riprova.', 'errore-campi' ),
			'email'         => tenconi_cand_t( 'L’indirizzo email non è valido: controllalo e riprova.', 'errore-email' ),
			'nascita'       => tenconi_cand_t( 'La data di nascita non è valida: controllala e riprova.', 'errore-nascita' ),
			'file-peso'     => tenconi_cand_t( 'Gli allegati sono troppo pesanti: al massimo 5 MB ciascuno e 10 MB in tutto.', 'errore-file-peso' ),
			'file-numero'   => tenconi_cand_t( 'Puoi allegare al massimo 5 file.', 'errore-file-numero' ),
			'file-tipo'     => tenconi_cand_t( 'Uno degli allegati non è di un tipo accettato: usa PDF, Word, testo, PowerPoint o immagini.', 'errore-file-tipo' ),
			'antispam'      => tenconi_cand_t( 'La verifica anti-spam non è andata a buon fine. Ricarica la pagina e riprova.', 'errore-antispam' ),
			'troppo-veloce' => tenconi_cand_t( 'Una candidatura è già stata inviata da poco. Attendi un minuto e riprova.', 'errore-veloce' ),
			'sessione'      => tenconi_cand_t( 'La sessione è scaduta. Ricarica la pagina e riprova.', 'errore-sessione' ),
			'invio'         => tenconi_cand_t( 'Non è stato possibile inviare la candidatura. Scrivici a', 'errore-invio' ) . ' ' . tenconi_form_destinatario() . '.',
		);
		$testo = isset( $mappa[ $errore ] ) ? $mappa[ $errore ] : $mappa['invio'];
		$cls   = 'tl-esito--ko';
	}

	return sprintf(
		'<p class="tl-esito %1$s" role="status" tabindex="-1">%2$s</p>',
		esc_attr( $cls ),
		esc_html( $testo )
	);
}

/**
 * Stampa un campo del modulo.
 *
 * @param string $k Chiave del campo.
 * @param array  $c Definizione del campo.
 * @param string $v Valore iniziale.
 * @return void
 */
function tenconi_cand_campo( $k, $c, $v = '' ) {
	$id  = 'tl-cand-' . $k;
	$obb = $c['obbl'] ? ' required' : '';
	?>
	<p class="tl-form__c<?php echo $c['largo'] ? ' tl-form__c--largo' : ''; ?>">
		<label for="<?php echo esc_attr( $id ); ?>">
			<?php echo esc_html( tenconi_cand_t( $c['label'], 'campo-' . $k ) ); ?><?php echo $c['obbl'] ? ' <span class="tl-form__ob" aria-hidden="true">*</span>' : ''; ?>
		</label>
		<?php if ( 'textarea' === $c['tipo'] ) : ?>
			<textarea id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $k ); ?>" rows="6"<?php echo $obb; // phpcs:ignore WordPress.Security.EscapeOutput ?>></textarea>
		<?php elseif ( 'paese' === $c['tipo'] ) : ?>
			<select id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $k ); ?>" autocomplete="country"<?php echo $obb; // phpcs:ignore WordPress.Security.EscapeOutput ?>>
				<?php foreach ( tenconi_cand_paesi() as $codice => $nome ) : ?>
					<option value="<?php echo esc_attr( $codice ); ?>"<?php selected( $codice, 'CH' ); ?>><?php echo esc_html( $nome ); ?></option>
				<?php endforeach; ?>
			</select>
		<?php else : ?>
			<input type="<?php echo esc_attr( $c['tipo'] ); ?>" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $k ); ?>" value="<?php echo esc_attr( $v ); ?>" autocomplete="<?php echo esc_attr( $c['auto'] ); ?>"<?php echo 'date' === $c['tipo'] ? ' max="' . esc_attr( gmdate( 'Y-m-d' ) ) . '"' : ''; ?><?php echo $obb; // phpcs:ignore WordPress.Security.EscapeOutput ?>>
		<?php endif; ?>
	</p>
	<?php
}

/**
 * Il modulo completo.
 *
 * @param string $posizione Posizione gia' scelta (dal pulsante "Candidati").
 * @return void
 */
function tenconi_cand_modulo( $posizione = '' ) {
	$privacy = get_page_by_path( 'privacy' );
	$privacy = $privacy ? get_permalink( $privacy ) : get_privacy_policy_url();
	$accetta = '.' . implode( ',.', tenconi_cand_estensioni() );
	$campi   = tenconi_cand_campi();
	$rc_key  = function_exists( 'ticinoweb_get_recaptcha_site_key' ) ? (string) ticinoweb_get_recaptcha_site_key() : '';
	if ( '' !== $rc_key ) {
		/* Il token si chiede al momento dell'invio: dura due minuti, il modulo e' lungo. */
		wp_enqueue_script( 'google-recaptcha', 'https://www.google.com/recaptcha/api.js?render=' . rawurlencode( $rc_key ), array(), null, true );
		wp_add_inline_script(
			'google-recaptcha',
			'document.addEventListener("submit",function(e){var f=e.target;if(!f.closest||!f.closest("#tl-candidatura")||f.dataset.rc)return;e.preventDefault();grecaptcha.ready(function(){grecaptcha.execute(' . wp_json_encode( $rc_key ) . ',{action:"candidatura"}).then(function(t){f.recaptcha_token.value=t;f.dataset.rc="1";f.submit();});});});'
		);
	}
	?>
	<div class="tl-cand" id="tl-candidatura">
		<?php echo tenconi_cand_esito(); // phpcs:ignore WordPress.Security.EscapeOutput -- HTML gia' sfuggito nella funzione. ?>

		<form class="tl-form" method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( TENCONI_CAND_AZIONE ); ?>">
			<?php wp_nonce_field( TENCONI_CAND_AZIONE, 'tl_nonce' ); ?>
			<input type="hidden" name="tl_t" value="<?php echo esc_attr( (string) time() ); ?>">
			<input type="hidden" name="recaptcha_token" value="">

			<div class="tl-form__trappola" aria-hidden="true">
				<label for="tl-cand-sito">Sito web</label>
				<input type="text" id="tl-cand-sito" name="tl_sito" tabindex="-1" autocomplete="off">
			</div>

			<div class="tl-form__g">
				<?php
				foreach ( $campi as $k => $c ) {
					if ( 'indirizzo' === ( $c['gruppo'] ?? '' ) ) {
						continue;
					}
					if ( 'email' === $k ) {
						?>
						<fieldset class="tl-form__gruppo tl-form__c--largo">
							<legend><?php echo esc_html( tenconi_cand_t( 'Indirizzo', 'campo-indirizzo' ) ); ?></legend>
							<div class="tl-form__g">
								<?php
								foreach ( $campi as $k2 => $c2 ) {
									if ( 'indirizzo' === ( $c2['gruppo'] ?? '' ) ) {
										tenconi_cand_campo( $k2, $c2 );
									}
								}
								?>
							</div>
						</fieldset>
						<?php
					}
					tenconi_cand_campo( $k, $c, 'posizione' === $k ? $posizione : '' );
				}
				?>

				<p class="tl-form__c tl-form__c--largo">
					<label for="tl-cand-allegati"><?php echo esc_html( tenconi_cand_t( 'Allegati (CV, lettera, certificati)', 'campo-allegati' ) ); ?></label>
					<input type="file" id="tl-cand-allegati" name="allegati[]" multiple accept="<?php echo esc_attr( $accetta ); ?>" aria-describedby="tl-cand-allegati-n">
					<span class="tl-form__nota" id="tl-cand-allegati-n"><?php echo esc_html( tenconi_cand_t( 'Fino a 5 file, al massimo 5 MB ciascuno e 10 MB in tutto. PDF, Word, testo, PowerPoint o immagini.', 'nota-allegati' ) ); ?></span>
				</p>

				<fieldset class="tl-form__gruppo tl-form__c--largo">
					<legend><?php echo esc_html( tenconi_cand_t( 'Autorizzazione all’utilizzo dei dati', 'campo-privacy-titolo' ) ); ?> <span class="tl-form__ob" aria-hidden="true">*</span></legend>
					<?php if ( $privacy ) : ?>
						<p class="tl-form__nota"><a href="<?php echo esc_url( $privacy ); ?>" target="_blank" rel="noopener"><?php echo esc_html( tenconi_cand_t( 'Leggi la nostra informativa sulla privacy', 'link-privacy' ) ); ?></a></p>
					<?php endif; ?>
					<label class="tl-form__spunta">
						<input type="checkbox" name="privacy" value="1" required>
						<span><?php echo esc_html( tenconi_cand_t( 'Ho letto l’informativa sulla privacy e autorizzo il trattamento dei miei dati', 'campo-privacy' ) ); ?></span>
					</label>
				</fieldset>
			</div>

			<p class="tl-form__invia">
				<button type="submit" class="tl-bottone tl-bottone--invia"><?php echo esc_html( tenconi_cand_t( 'Invia la candidatura', 'invia' ) ); ?></button>
			</p>
		</form>
	</div>
	<?php
}
