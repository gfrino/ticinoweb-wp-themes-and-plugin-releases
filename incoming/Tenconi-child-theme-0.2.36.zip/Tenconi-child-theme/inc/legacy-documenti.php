<?php
/**
 * ELENCHI DI DOCUMENTI: Certificazioni, Condizioni di vendita.
 *
 * Jobs ha lasciato questo elenco: le posizioni aperte si gestiscono in bacheca
 * (inc/jobs.php) e non devono piu' richiedere un rilascio del tema.
 *
 * Nel legacy erano la stessa cosa tre volte: un titolo, gruppi etichettati e righe
 * di collegamenti a PDF, spesso lo stesso documento in piu' lingue. Un template.
 *
 * I collegamenti puntano al PDF corrispondente nella libreria media di WordPress
 * quando esiste; altrimenti la riga resta testo, senza link finto.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function tenconi_legacy_documenti() {

	return array(

		'certificazioni' => array(
			'titolo' => 'Certificazioni',
			'voci'   => array(
				array( 'p', 'Certificati di qualità e ambiente:', array() ),
				array( 'p', 'IQNET ISO 9001 / 14001 (English)', array( array( 'IQNET ISO 9001 / 14001', '102727_iq_H42941-en2y.pdf' ) ) ),
				array( 'p', 'ISO 9001 / 14001 (Italiano) ISO 9001 / 14001 (English) ISO 9001 / 14001 (Deutsch) ISO 9001 / 14001 (Français)', array( array( 'ISO 9001 / 14001', '102727_it_H42941-2e7c.pdf' ), array( 'ISO 9001 / 14001', '102727_en_H42941-85gh.pdf' ), array( 'ISO 9001 / 14001', '102727_de_H42941-a2yw.pdf' ), array( 'ISO 9001 / 14001', '102727_fr_H42941-7kdw.pdf' ) ) ),
				array( 'p', 'Certificati di saldatura:', array() ),
				array( 'p', 'ISO 3834-2 (Italiano) ISO 3834-2 (English)', array( array( 'ISO 3834-2', '102727_it_H42984-dfll.pdf' ), array( 'ISO 3834-2', '102727_en_H42984-3jt8.pdf' ) ) ),
				array( 'p', 'EN 1090-1 (Italiano) EN 1090-1 (English)', array( array( 'EN 1090-1', 'Zertifikat-1090-1_Tenconi_IT.pdf' ), array( 'EN 1090-1', 'Zertifikat-1090-1_Tenconi_EN.pdf' ) ) ),
				array( 'p', 'EN 1090-2 (Italiano) EN 1090-2 (English)', array( array( 'EN 1090-2', 'Zertifikat-1090-2_Tenconi_IT.pdf' ), array( 'EN 1090-2', 'Zertifikat-1090-2_Tenconi_EN.pdf' ) ) ),
				array( 'p', 'EN 15085-2 CL1 Airolo (Italiano) EN 15085-2 CL1 Airolo (English)', array( array( 'EN 15085-2 CL1 Airolo', 'Zertifikat_Tenconi-Airolo_IT-jsyj.pdf' ), array( 'EN 15085-2 CL1 Airolo', 'Zertifikat_Tenconi-Airolo_EN-p32k.pdf' ) ) ),
				array( 'p', 'EN 15085-2 CL1 Cadenazzo (Italiano) EN 15085-2 CL1 Cadenazzo (English)', array( array( 'EN 15085-2 CL1 Cadenazzo', 'Zertifikat_Tenconi-Cadenazzo_IT-bwzn.pdf' ), array( 'EN 15085-2 CL1 Cadenazzo', 'Zertifikat_Tenconi-Cadenazzo_EN-6bmt.pdf' ) ) ),
				array( 'p', 'DB Zulassung HPQ', array( array( 'DB Zulassung HPQ', '260415_DB_HPQ-Urkunde_Tenconi-SA.pdf' ) ) ),
				array( 'p', 'DUN&BRADSTREET Rating Certificate', array() ),
			),
		),

		'condizioni-di-vendita' => array(
			'titolo' => 'Condizioni di vendita',
			'voci'   => array(
				array( 'p', 'Condizioni generali di fornitura della TENCONI SA', array( array( 'Condizioni generali di fornitura della TENCONI SA', 'Condizioni_di_fornitura_2017_13112017_V2.pdf' ) ) ),
				array( 'p', 'General conditions of contract for the supply of TENCONI SA', array( array( 'General conditions of contract for the supply of TENCONI SA', 'General_conditions_for_the_supply_2017_13112017_V2.pdf' ) ) ),
				array( 'p', 'Allgemeine Lieferbedingungen der TENCONI SA', array( array( 'Allgemeine Lieferbedingungen der TENCONI SA', 'xxx___Allgemeine-Lieferbedingungen-_2017_13112017_V2.pdf' ) ) ),
				array( 'p', 'Conditions générales de livraison de la TENCONI SA', array( array( 'Conditions générales de livraison de la TENCONI SA', 'Conditions_de_livraison_2017_13112017_V2.pdf' ) ) ),
			),
		),
	);
}

