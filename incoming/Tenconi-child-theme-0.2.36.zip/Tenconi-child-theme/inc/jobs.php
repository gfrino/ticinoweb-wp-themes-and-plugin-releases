<?php
/**
 * LE POSIZIONI APERTE, gestite dalla bacheca.
 *
 * Prima l'elenco stava scritto nel tema (inc/legacy-documenti.php): per togliere
 * un annuncio scaduto serviva un rilascio, e infatti il Plant Manager e' rimasto
 * online mesi dopo che il cliente l'aveva tolto dal suo sito. Adesso ogni
 * posizione e' un contenuto "Lavora con noi" (CPT job, gia' registrato in
 * post-types.php): il cliente la pubblica, la mette in bozza quando il posto e'
 * occupato, e la pagina /jobs/ segue da sola.
 *
 * Per posizione: titolo (il nome del ruolo), testo dell'annuncio (facoltativo,
 * si apre nella pagina), un PDF del profilo (facoltativo). L'ordine e' quello
 * di "Attributi -> Ordine", poi le piu' recenti prima.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Meta con l'ID allegato del PDF del profilo. */
const TENCONI_JOB_PDF = '_tenconi_job_pdf';

/**
 * Le posizioni pubblicate, nell'ordine scelto in bacheca.
 *
 * @return WP_Post[]
 */
function tenconi_jobs_aperte() {
	return get_posts(
		array(
			'post_type'        => 'job',
			'post_status'      => 'publish',
			'posts_per_page'   => 50,
			'orderby'          => array(
				'menu_order' => 'ASC',
				'date'       => 'DESC',
			),
			'suppress_filters' => false,
		)
	);
}

/**
 * L'indirizzo del PDF del profilo di una posizione, o stringa vuota.
 *
 * @param int $id ID della posizione.
 * @return string
 */
function tenconi_job_pdf_url( $id ) {
	$pdf = (int) get_post_meta( (int) $id, TENCONI_JOB_PDF, true );
	return $pdf ? (string) wp_get_attachment_url( $pdf ) : '';
}

/**
 * Il riquadro "Profilo in PDF" nella scheda della posizione.
 *
 * @return void
 */
function tenconi_job_metabox_add() {
	add_meta_box( 'tenconi-job-pdf', 'Profilo in PDF (facoltativo)', 'tenconi_job_metabox', 'job', 'side' );
}
add_action( 'add_meta_boxes_job', 'tenconi_job_metabox_add' );

/**
 * Il contenuto del riquadro: un pulsante che apre la libreria media sui PDF.
 *
 * @param WP_Post $post La posizione.
 * @return void
 */
function tenconi_job_metabox( $post ) {
	$id   = (int) get_post_meta( $post->ID, TENCONI_JOB_PDF, true );
	$nome = $id ? basename( (string) get_attached_file( $id ) ) : '';
	wp_nonce_field( 'tenconi_job_pdf', 'tenconi_job_pdf_nonce' );
	?>
	<div class="tenconi-job-pdf">
		<input type="hidden" name="tenconi_job_pdf" value="<?php echo esc_attr( $id ? (string) $id : '' ); ?>">
		<p class="tenconi-job-pdf__nome"<?php echo $id ? '' : ' hidden'; ?>><strong><?php echo esc_html( $nome ); ?></strong></p>
		<p>
			<button type="button" class="button tenconi-job-pdf__scegli"><?php echo $id ? 'Cambia PDF' : 'Scegli il PDF'; ?></button>
			<button type="button" class="button-link button-link-delete tenconi-job-pdf__togli"<?php echo $id ? '' : ' hidden'; ?>>Togli</button>
		</p>
		<p class="description">Sulla pagina Jobs compare il pulsante «Scarica il PDF».</p>
	</div>
	<?php
}

/**
 * Salva il PDF scelto. Accetta solo un allegato PDF esistente.
 *
 * @param int $post_id ID della posizione.
 * @return void
 */
function tenconi_job_metabox_salva( $post_id ) {
	if ( ! isset( $_POST['tenconi_job_pdf_nonce'] )
		|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['tenconi_job_pdf_nonce'] ) ), 'tenconi_job_pdf' )
		|| ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
		|| ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$id = isset( $_POST['tenconi_job_pdf'] ) ? absint( $_POST['tenconi_job_pdf'] ) : 0;
	if ( $id && 'application/pdf' === get_post_mime_type( $id ) ) {
		update_post_meta( $post_id, TENCONI_JOB_PDF, $id );
	} else {
		delete_post_meta( $post_id, TENCONI_JOB_PDF );
	}
}
add_action( 'save_post_job', 'tenconi_job_metabox_salva' );

/**
 * Il selettore della libreria media, solo nella scheda della posizione.
 *
 * @return void
 */
function tenconi_job_admin_script() {
	$schermo = get_current_screen();
	if ( ! $schermo || 'job' !== $schermo->post_type || 'post' !== $schermo->base ) {
		return;
	}
	wp_enqueue_media();
	$js = <<<'JS'
jQuery(function ($) {
	var box = $('.tenconi-job-pdf'), frame;
	box.on('click', '.tenconi-job-pdf__scegli', function (e) {
		e.preventDefault();
		if (!frame) {
			frame = wp.media({ title: 'Scegli il PDF del profilo', library: { type: 'application/pdf' }, button: { text: 'Usa questo PDF' }, multiple: false });
			frame.on('select', function () {
				var a = frame.state().get('selection').first().toJSON();
				box.find('input[name=tenconi_job_pdf]').val(a.id);
				box.find('.tenconi-job-pdf__nome').prop('hidden', false).find('strong').text(a.filename);
				box.find('.tenconi-job-pdf__togli').prop('hidden', false);
				box.find('.tenconi-job-pdf__scegli').text('Cambia PDF');
			});
		}
		frame.open();
	});
	box.on('click', '.tenconi-job-pdf__togli', function (e) {
		e.preventDefault();
		box.find('input[name=tenconi_job_pdf]').val('');
		box.find('.tenconi-job-pdf__nome').prop('hidden', true);
		$(this).prop('hidden', true);
		box.find('.tenconi-job-pdf__scegli').text('Scegli il PDF');
	});
});
JS;
	wp_add_inline_script( 'media-editor', $js );
}
add_action( 'admin_enqueue_scripts', 'tenconi_job_admin_script' );

/**
 * Due righe di istruzioni in cima all'elenco delle posizioni, per chi le
 * gestisce senza conoscere WordPress.
 *
 * @return void
 */
function tenconi_job_admin_aiuto() {
	$schermo = get_current_screen();
	if ( ! $schermo || 'edit-job' !== $schermo->id ) {
		return;
	}
	$jobs = get_post_type_archive_link( 'job' );
	?>
	<div class="notice notice-info">
		<p>
			Le posizioni <strong>pubblicate</strong> compaiono sulla pagina
			<a href="<?php echo esc_url( (string) $jobs ); ?>" target="_blank" rel="noopener">Jobs</a>, sotto «Posizioni aperte».
			Quando un posto è occupato, apri la posizione e mettila <strong>in bozza</strong> (o nel cestino): sparisce dal sito.
		</p>
		<p>Per ogni posizione basta il titolo; il testo dell'annuncio e il PDF del profilo sono facoltativi.</p>
	</div>
	<?php
}
add_action( 'admin_notices', 'tenconi_job_admin_aiuto' );

/**
 * Una colonna "PDF" nell'elenco, per vedere a colpo d'occhio cosa manca.
 *
 * @param array $colonne Colonne dell'elenco.
 * @return array
 */
function tenconi_job_colonne( $colonne ) {
	$nuove = array();
	foreach ( $colonne as $k => $v ) {
		$nuove[ $k ] = $v;
		if ( 'title' === $k ) {
			$nuove['tenconi_pdf'] = 'PDF';
		}
	}
	return $nuove;
}
add_filter( 'manage_job_posts_columns', 'tenconi_job_colonne' );

/**
 * Il contenuto della colonna "PDF".
 *
 * @param string $colonna Colonna.
 * @param int    $post_id ID della posizione.
 * @return void
 */
function tenconi_job_colonna( $colonna, $post_id ) {
	if ( 'tenconi_pdf' !== $colonna ) {
		return;
	}
	$id = (int) get_post_meta( $post_id, TENCONI_JOB_PDF, true );
	echo $id ? esc_html( basename( (string) get_attached_file( $id ) ) ) : '—';
}
add_action( 'manage_job_posts_custom_column', 'tenconi_job_colonna', 10, 2 );
