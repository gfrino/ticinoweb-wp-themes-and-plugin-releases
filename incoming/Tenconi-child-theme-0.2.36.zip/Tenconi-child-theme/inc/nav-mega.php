<?php
/**
 * DATI DEL MEGA MENU: una fotografia e una frase per ogni voce di secondo livello.
 *
 * PERCHE' ESISTE QUESTO FILE. Il mega menu di riferimento mostra, per ogni voce,
 * un'icona, un titolo e una descrizione. La navigazione di Tenconi
 * (tenconi_nav_legacy) porta soltanto etichetta, URL e stato: niente icone,
 * niente descrizioni. Servivano, e c'erano due modi di procurarsele.
 *
 * NON SI INVENTANO. Scrivere qui "Soluzioni su misura per il settore ferroviario"
 * avrebbe riempito il pannello in cinque minuti, e sarebbe stato testo di comodo
 * dentro il tema: esattamente la regola che nav-config.php dichiara di non voler
 * aggirare. Quindi:
 *
 *   LE DESCRIZIONI vengono dal campo "Riassunto" della destinazione, e solo da
 *   quello. Oggi e' vuoto su tutte le voci, quindi le schede mostrano fotografia
 *   e titolo. Ricavarle automaticamente dal contenuto l'ho provato e l'ho
 *   buttato: su quindici voci ne produceva due, sbagliate entrambe. Il perche' e'
 *   scritto sopra tenconi_mega_frase().
 *
 *   LE FOTOGRAFIE, al posto delle icone del riferimento, vengono dalle mappe
 *   legacy gia' verificate. Non e' una scorciatoia: per un'azienda che lavora
 *   metallo una fotografia di officina dice piu' di un pittogramma, e sono le
 *   stesse immagini che il sito usa nelle pagine di destinazione — quindi il
 *   pannello anticipa cio' che si trovera' cliccando.
 *
 * COPERTURA REALE, misurata il 19.10.2026: tutte e diciassette le voci hanno
 * una fotografia. Per questo il pannello puo' mostrarle tutte a scheda, senza
 * righe di solo testo. Il ripiego con l'icona grande resta per il giorno in cui
 * una fotografia sparisse.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Da chiave di navigazione a sorgente dell'immagine.
 *
 * Tabella esplicita e non indovinata: le chiavi delle mappe legacy non coincidono
 * con quelle della navigazione — 'centocinquantesimo' nel menu e' '150esimo'
 * nella mappa — e una corrispondenza automatica sarebbe una scommessa che si
 * rompe in silenzio il giorno che una chiave cambia.
 *
 * Tipi di sorgente:
 *   menu     inc/legacy-menu-media.php, prima immagine della pagina
 *   area     inc/legacy-aree-media.php, prima immagine della prima galleria
 *   blocco   il blocco della home con quell'etichetta
 *
 * @return array<string,array{0:string,1:string}>
 */
function tenconi_mega_sorgenti() {
	return array(
		'missione'              => array( 'nome', 'missione-tenconi' ),
		'storia'                => array( 'nome', 'storia' ),
		'direzione'             => array( 'nome', 'direzione-cda' ),
		/* Come il 150esimo: un disegno per il menu, agganciato per nome del file. */
		'team'                  => array( 'nome', 'menu-team' ),
		/*
		 * NON PIU' LA PRIMA IMMAGINE DELLA PAGINA, ma un disegno fatto apposta
		 * per il menu: bianco su blu, nessuna persona. La pagina 150esimo
		 * resta com'e'; quello che cambia e' solo cosa si vede nel pannello.
		 */
		'centocinquantesimo'    => array( 'nome', 'menu-150esimo' ),
		/*
		 * Foto scelta per il menu: la prima immagine della pagina era quasi
		 * uguale a quella di Gestione progetti, e le due schede vicine
		 * sembravano doppie.
		 */
		'supporto'              => array( 'nome', 'menu-supporto' ),
		'sostenibilita'         => array( 'nome', 'sostenibilita' ),
		/*
		 * Voci che portano a una SEZIONE di una pagina (Qualita' e le due voci di
		 * Sostenibilita', le due di Jobs): l'immagine in evidenza della pagina
		 * sarebbe la stessa per tutte, quindi ognuna ha la sua fotografia.
		 */
		'qualita'               => array( 'nome', 'sostenibilita' ),
		'tutela-ambiente'       => array( 'nome', 'pannellifotovoltaici' ),
		'salute-sicurezza'      => array( 'nome', 'Saluteesicurezza' ),
		'posizioni-vacanti'     => array( 'nome', 'menu-supporto' ),
		'candidature-spontanee' => array( 'nome', 'montegenerosoteamfoto' ),
		'certificazioni'        => array( 'nome', 'certificazioni' ),
		'condizioni-di-vendita' => array( 'nome', 'condizioni-di-vendita' ),

		'ferroviario-infrastruttura' => array( 'area', 'ferroviario-infrastruttura' ),
		'ferroviario-rotabile'       => array( 'area', 'ferroviario-rotabile' ),
		'metalmeccanica'             => array( 'area', 'metalmeccanica' ),
		'carpenteria-metallica'      => array( 'area', 'carpenteria-metallica' ),
		'energia'                    => array( 'area', 'energia' ),

		'parco-macchine'    => array( 'blocco', 'Parco macchine' ),
		'referenze'         => array( 'nome', 'referenze-progetti' ),
		'gestione-progetti' => array( 'blocco', 'Gestione progetti' ),
	);
}

/**
 * L'immagine di una voce: identificativo dell'allegato e testo alternativo.
 *
 * PRIMA L'IMMAGINE SCELTA NEL BACKEND per la destinazione: immagine in evidenza
 * della pagina, campo del settore o immagine dell'archivio (vedi
 * inc/menu-immagini.php). Solo se quel posto e' vuoto si passa alle sorgenti
 * di tenconi_mega_sorgenti().
 *
 * @param string $key Chiave di navigazione.
 * @param string $url Indirizzo della destinazione, se noto.
 * @return array{img:int,alt:string}
 */
function tenconi_mega_immagine( $key, $url = '' ) {

	/* una voce che porta a una sezione (#) non prende l'immagine della pagina intera */
	$evidenza = ( function_exists( 'tenconi_menu_img_da_backend' ) && false === strpos( (string) $url, '#' ) ) ? tenconi_menu_img_da_backend( $url ) : 0;
	if ( $evidenza ) {
		return array(
			'img' => $evidenza,
			'alt' => (string) get_post_meta( $evidenza, '_wp_attachment_image_alt', true ),
		);
	}

	$sorgenti = tenconi_mega_sorgenti();
	if ( ! isset( $sorgenti[ $key ] ) ) {
		return array(
			'img' => 0,
			'alt' => '',
		);
	}

	list( $tipo, $rif ) = $sorgenti[ $key ];

	if ( 'nome' === $tipo && function_exists( 'tenconi_media_da_nome' ) ) {
		$id = tenconi_media_da_nome( $rif, 'image' );
		if ( $id ) {
			return array(
				'img' => $id,
				'alt' => (string) get_post_meta( $id, '_wp_attachment_image_alt', true ),
			);
		}
	}

	if ( 'menu' === $tipo && function_exists( 'tenconi_legacy_menu_media' ) ) {
		$mappa = tenconi_legacy_menu_media();
		if ( ! empty( $mappa[ $rif ]['img'][0][0] ) ) {
			return array(
				'img' => (int) $mappa[ $rif ]['img'][0][0],
				'alt' => (string) ( $mappa[ $rif ]['img'][0][1] ?? '' ),
			);
		}
	}

	if ( 'area' === $tipo && function_exists( 'tenconi_legacy_aree_media' ) ) {
		$mappa = tenconi_legacy_aree_media();
		if ( ! empty( $mappa[ $rif ]['g1']['img'][0][0] ) ) {
			return array(
				'img' => (int) $mappa[ $rif ]['g1']['img'][0][0],
				'alt' => (string) ( $mappa[ $rif ]['g1']['img'][0][1] ?? '' ),
			);
		}
	}

	if ( 'blocco' === $tipo && function_exists( 'tenconi_legacy_home_blocchi' ) ) {
		foreach ( tenconi_legacy_home_blocchi() as $b ) {
			if ( $rif === $b['label'] ) {
				return array(
					'img' => (int) $b['img'],
					'alt' => (string) ( $b['alt'] ?? '' ),
				);
			}
		}
	}

	return array(
		'img' => 0,
		'alt' => '',
	);
}

/**
 * La destinazione dichiarata di ogni chiave, primo e secondo livello.
 *
 * tenconi_nav_legacy() restituisce l'URL risolto ma non la destinazione: per
 * leggere il testo di una pagina serve il post, non il permalink. Si ricava dalla
 * configurazione, che e' la stessa fonte, cosi' le due letture non possono
 * divergere.
 *
 * @return array<string,array{0:string,1:string}>
 */
function tenconi_mega_destinazioni() {

	static $mappa = null;
	if ( null !== $mappa ) {
		return $mappa;
	}

	$mappa = array();
	foreach ( tenconi_nav_blueprint() as $voce ) {
		$mappa[ $voce['key'] ] = $voce['dest'];
		foreach ( $voce['children'] as $f ) {
			$mappa[ $f['key'] ] = $f['dest'];
		}
	}
	return $mappa;
}

/**
 * La descrizione di una voce: il RIASSUNTO scritto a mano in WordPress.
 *
 * PRIMA PROVAVO A RICAVARLA DAL CONTENUTO, prendendo la prima proposizione della
 * pagina. Sembrava elegante e non lo era: misurato su tutte e quindici le voci,
 * ne produceva due, e sbagliate entrambe.
 *
 *   storia          -> "/ 091 821 11 11), oppure acquistato direttamente presso
 *                      la Ditta Tenconi o nelle migliori..."
 *   metalmeccanica  -> "TENCONI SA"
 *
 * Il motivo e' che queste pagine non cominciano con una frase introduttiva:
 * cominciano con un titolo, un indirizzo o un frammento. Una regola che indovina
 * due volte su quindici e sbaglia sempre non e' una regola, e' un generatore di
 * figuracce sull'header di ogni pagina del sito.
 *
 * QUINDI SI LEGGE post_excerpt, e SOLTANTO quello: il campo "Riassunto" di
 * WordPress, che esiste esattamente per questo ed e' scritto da una persona. Oggi
 * e' vuoto su tutte le voci, quindi le schede mostrano fotografia e titolo — che
 * e' anche la forma che il componente di riferimento prevede per le voci senza
 * descrizione. Il giorno che qualcuno scrive un riassunto, quella voce si
 * arricchisce da sola, senza toccare il tema.
 *
 * Non si usa wp_trim_excerpt(): quello, con il riassunto vuoto, ricade sul
 * contenuto e riporta esattamente la spazzatura da cui si e' scappati.
 *
 * @param string $key Chiave di navigazione.
 * @param int    $max Lunghezza massima in caratteri.
 * @return string Riassunto, oppure stringa vuota.
 */
function tenconi_mega_frase( $key, $max = 96 ) {

	static $cache = array();
	if ( isset( $cache[ $key ] ) ) {
		return $cache[ $key ];
	}

	$cache[ $key ] = '';
	$dest          = tenconi_mega_destinazioni();
	if ( ! isset( $dest[ $key ] ) ) {
		return '';
	}

	list( $tipo, $rif ) = $dest[ $key ];

	$post = null;
	if ( 'page' === $tipo ) {
		$post = get_page_by_path( $rif );
	} elseif ( 'cpt_single' === $tipo ) {
		list( $pt, $slug ) = array_pad( explode( ':', $rif, 2 ), 2, '' );
		$post              = get_page_by_path( $slug, OBJECT, $pt );
	}
	if ( ! $post ) {
		return '';
	}

	$testo = trim( wp_strip_all_tags( (string) $post->post_excerpt ) );
	$testo = trim( preg_replace( '/\s+/u', ' ', html_entity_decode( $testo, ENT_QUOTES, 'UTF-8' ) ) );
	if ( '' === $testo ) {
		return '';
	}

	/*
	 * NON SI MOSTRA UN SEGNAPOSTO. Il cancello lascia passare le pagine con marche
	 * come [dato da confermare] — decisione del committente, perche' il menu deve
	 * replicare il legacy — ma stampare quella marca nel pannello la porterebbe
	 * sotto gli occhi del visitatore su ogni pagina del sito.
	 */
	if ( preg_match( TENCONI_PH_RE, $testo ) ) {
		return '';
	}

	if ( mb_strlen( $testo ) > $max ) {
		$tagliato = mb_substr( $testo, 0, $max );
		$spazio   = mb_strrpos( $tagliato, ' ' );
		if ( false !== $spazio && $spazio > 30 ) {
			$tagliato = mb_substr( $tagliato, 0, $spazio );
		}
		$testo = rtrim( $tagliato, " ,;:." ) . "\u{2026}";
	}

	$cache[ $key ] = $testo;
	return $testo;
}

/**
 * La navigazione arricchita per il mega menu.
 *
 * Aggiunge a ogni figlio la frase e l'immagine. OGNI FIGLIO E' UNA SCHEDA CON
 * FOTOGRAFIA: nel pannello non esistono piu' voci di solo testo.
 *
 * PRIMA ERANO DUE GRUPPI — i primi tre a scheda, gli altri in una colonna di
 * righe compatte a destra — e la regola del tre veniva dal componente di
 * riferimento. Il risultato sul sito era che Team e 150esimo, che una
 * fotografia ce l'hanno eccome, finivano scritti in piccolo di fianco a tre
 * schede grandi: la stessa pagina valeva meno della vicina per il solo fatto
 * di essere la quarta del menu.
 *
 * MISURATO PRIMA DI TOGLIERE LA REGOLA: tutte e diciassette le voci di secondo
 * livello hanno un'immagine (tenconi_mega_immagine le risolve tutte). Il
 * pannello piu' affollato ne ha cinque. Il ripiego con l'icona grande resta nel
 * markup per il giorno in cui una fotografia sparisse, non perche' serva oggi.
 *
 * @return array<int,array<string,mixed>>
 */
function tenconi_nav_mega() {

	static $out = null;
	if ( null !== $out ) {
		return $out;
	}

	$out = array();
	foreach ( tenconi_nav_legacy() as $voce ) {

		if ( 'gruppo' === $voce['tipo'] ) {
			$figli = array();
			foreach ( $voce['children'] as $f ) {
				$im      = tenconi_mega_immagine( $f['key'], $f['url'] );
				$figli[] = array(
					'key'    => $f['key'],
					'label'  => $f['label'],
					'url'    => $f['url'],
					'attiva' => $f['attiva'],
					'frase'  => tenconi_mega_frase( $f['key'] ),
					'img'    => $im['img'],
					'alt'    => $im['alt'],
				);
			}
			$voce['schede'] = $figli;
		} else {
			$voce['schede'] = array();
		}

		$out[] = $voce;
	}

	return $out;
}

/**
 * Da chiave di navigazione a icona.
 *
 * IL RIFERIMENTO USA lucide-react, che qui non c'e' e non serve: sono diciassette
 * glifi, disegnati a mano nel linguaggio del sito — tracciato da 1,6 px, nessun
 * riempimento, geometria squadrata, la stessa grammatica dei filetti e delle mire
 * usate nel resto del tema. Costano zero richieste e zero kB di libreria.
 *
 * SERVONO A DUE COSE, e la seconda e' quella che conta:
 *   1. accanto al titolo, danno alla voce un segno riconoscibile a colpo d'occhio;
 *   2. RIEMPIONO LA CORNICE dove la fotografia non esiste. Tre voci su quindici
 *      non hanno un'immagine — storia, referenze e sostenibilita': verificato,
 *      non hanno immagine in evidenza, non ne hanno nel contenuto, non hanno
 *      allegati, e i quindici progetti non ne hanno nessuna. Invece di inventare
 *      un'associazione — mettere una foto di officina sotto "La nostra storia"
 *      perche' fa scena — la cornice mostra l'icona in grande. E' anche la forma
 *      che il componente di riferimento prevede per le voci senza figura.
 *
 * @return array<string,string>
 */
function tenconi_mega_icone() {
	return array(
		'missione'                   => 'azienda',
		'storia'                     => 'libro',
		'direzione'                  => 'persona',
		'team'                       => 'persone',
		'centocinquantesimo'         => 'bandiera',
		'ferroviario-infrastruttura' => 'rotaia',
		'ferroviario-rotabile'       => 'vagone',
		'metalmeccanica'             => 'ingranaggio',
		'carpenteria-metallica'      => 'trave',
		'energia'                    => 'fulmine',
		'parco-macchine'             => 'macchina',
		'referenze'                  => 'cartella',
		'gestione-progetti'          => 'elenco',
		'supporto'                   => 'chiave',
		'sostenibilita'              => 'foglia',
		'qualita'                    => 'elenco',
		'tutela-ambiente'            => 'foglia',
		'salute-sicurezza'           => 'persone',
		'posizioni-vacanti'          => 'cartella',
		'candidature-spontanee'      => 'persona',
		'certificazioni'             => 'sigillo',
		'condizioni-di-vendita'      => 'documento',
	);
}

/**
 * Il richiamo a un'icona dello sprite.
 *
 * @param string $key   Chiave di navigazione.
 * @param string $extra Classi aggiuntive.
 * @return string Markup SVG, oppure stringa vuota.
 */
function tenconi_mega_icona( $key, $extra = '' ) {
	$mappa = tenconi_mega_icone();
	if ( ! isset( $mappa[ $key ] ) ) {
		return '';
	}
	return '<svg class="tl-ico' . ( '' !== $extra ? ' ' . esc_attr( $extra ) : '' ) . '"'
		. ' viewBox="0 0 24 24" aria-hidden="true" focusable="false">'
		. '<use href="#tl-i-' . esc_attr( $mappa[ $key ] ) . '"/></svg>';
}

/**
 * Lo sprite delle icone, stampato una volta sola.
 *
 * UN SOLO SVG CON I SYMBOL e non diciassette tracciati ripetuti nel markup: le
 * icone compaiono nelle schede, nelle righe compatte e nel menu mobile, quindi lo
 * stesso glifo puo' servire tre volte nella stessa pagina. Con <use> il tracciato
 * sta scritto una volta.
 *
 * I valori di stroke stanno sul gruppo e non su ogni tracciato: meno ripetizione,
 * e cambiare lo spessore di tutte le icone e' una riga.
 */
function tenconi_mega_sprite() {
	?>
	<svg class="tl-sprite" aria-hidden="true" focusable="false" width="0" height="0">
		<defs>
			<g id="tl-i-base" fill="none" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round"/>
		</defs>

		<symbol id="tl-i-azienda" viewBox="0 0 24 24">
			<g fill="none" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round">
				<path d="M4 20.5h16M6 20.5V8.5l6-3.5 6 3.5v12M8.4 11h2v2.4h-2zM13.6 11h2v2.4h-2zM8.4 15.4h2v2.4h-2zM13.6 15.4h2v2.4h-2z"/>
			</g>
		</symbol>
		<symbol id="tl-i-libro" viewBox="0 0 24 24">
			<g fill="none" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round">
				<path d="M12 6.6C10.4 5.4 8.2 4.8 4.5 4.8v13c3.7 0 5.9.6 7.5 1.8 1.6-1.2 3.8-1.8 7.5-1.8v-13c-3.7 0-5.9.6-7.5 1.8Zm0 0v12.8M6.3 8.2c1.6.15 2.9.55 4 1.2M6.3 11.4c1.6.15 2.9.55 4 1.2M17.7 8.2c-1.6.15-2.9.55-4 1.2M17.7 11.4c-1.6.15-2.9.55-4 1.2"/>
			</g>
		</symbol>
		<symbol id="tl-i-persona" viewBox="0 0 24 24">
			<g fill="none" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round">
				<circle cx="12" cy="8.2" r="3.4"/><path d="M5.2 20c0-3.7 3-5.6 6.8-5.6s6.8 1.9 6.8 5.6"/>
			</g>
		</symbol>
		<symbol id="tl-i-persone" viewBox="0 0 24 24">
			<g fill="none" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round">
				<circle cx="9.2" cy="8.4" r="3"/><path d="M3.4 19.6c0-3.3 2.6-5 5.8-5s5.8 1.7 5.8 5"/>
				<path d="M15.6 6.1a3 3 0 0 1 0 5.9M17 15.2c2.2.5 3.6 2.1 3.6 4.4"/>
			</g>
		</symbol>
		<symbol id="tl-i-bandiera" viewBox="0 0 24 24">
			<g fill="none" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round">
				<path d="M6 3.5v17M6 4.6h11.5l-2.3 3.8 2.3 3.8H6"/>
			</g>
		</symbol>
		<symbol id="tl-i-rotaia" viewBox="0 0 24 24">
			<g fill="none" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round">
				<path d="M10.5 3 3 21M13.5 3 21 21M9.8 4.8h4.4M8.3 8.4h7.5M6.4 12.9h11.2M4.1 18.3h15.8"/>
			</g>
		</symbol>
		<symbol id="tl-i-vagone" viewBox="0 0 24 24">
			<g fill="none" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round">
				<path d="M3.6 8.4 5 6.8h14l1.4 1.6v6.4H3.6zM3.6 14.8h16.8M7.2 9.6h3.6M13.2 9.6h3.6"/>
				<circle cx="7.6" cy="17.6" r="1.8"/><circle cx="16.4" cy="17.6" r="1.8"/>
			</g>
		</symbol>
		<symbol id="tl-i-ingranaggio" viewBox="0 0 24 24">
			<g fill="none" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round">
				<path d="M10.37 4.58 L9.99 2.82 L14.01 2.82 L13.63 4.58 L16.1 5.6 L17.07 4.08 L19.92 6.93 L18.4 7.9 L19.42 10.37 L21.18 9.99 L21.18 14.01 L19.42 13.63 L18.4 16.1 L19.92 17.07 L17.07 19.92 L16.1 18.4 L13.63 19.42 L14.01 21.18 L9.99 21.18 L10.37 19.42 L7.9 18.4 L6.93 19.92 L4.08 17.07 L5.6 16.1 L4.58 13.63 L2.82 14.01 L2.82 9.99 L4.58 10.37 L5.6 7.9 L4.08 6.93 L6.93 4.08 L7.9 5.6 Z"/>
				<circle cx="12" cy="12" r="2.6"/>
			</g>
		</symbol>
		<symbol id="tl-i-trave" viewBox="0 0 24 24">
			<g fill="none" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round">
				<path d="M5 4.6h14M5 19.4h14M12 4.6v14.8M8.4 4.6v2.2M15.6 4.6v2.2M8.4 17.2v2.2M15.6 17.2v2.2"/>
			</g>
		</symbol>
		<symbol id="tl-i-fulmine" viewBox="0 0 24 24">
			<g fill="none" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round">
				<path d="M13.4 3 6.2 13.4h5.2l-1 7.6 7.4-10.4h-5.2z"/>
			</g>
		</symbol>
		<symbol id="tl-i-macchina" viewBox="0 0 24 24">
			<g fill="none" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round">
				<path d="M4 20.4h16M6.4 20.4V9.2h11.2v11.2M9.6 9.2V5h4.8v4.2M12 12v4.6M9.6 16.6h4.8"/>
			</g>
		</symbol>
		<symbol id="tl-i-cartella" viewBox="0 0 24 24">
			<g fill="none" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round">
				<path d="M3.8 6.6h5.4l1.8 2.4h9.2v10.4H3.8zM3.8 9.4h17.4"/>
			</g>
		</symbol>
		<symbol id="tl-i-elenco" viewBox="0 0 24 24">
			<g fill="none" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round">
				<path d="M9.6 6.6h10.6M9.6 12h10.6M9.6 17.4h10.6M3.8 6.4l1.2 1.2 2-2M3.8 11.8l1.2 1.2 2-2M3.8 17.2l1.2 1.2 2-2"/>
			</g>
		</symbol>
		<symbol id="tl-i-chiave" viewBox="0 0 24 24">
			<g fill="none" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round">
				<circle cx="7.4" cy="16.6" r="3"/><circle cx="7.4" cy="16.6" r="1.1"/>
				<path d="M9.5 14.5 19 5M15.6 8.4l2 2M17.6 6.4l2 2"/>
			</g>
		</symbol>
		<symbol id="tl-i-foglia" viewBox="0 0 24 24">
			<g fill="none" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round">
				<path d="M4.8 19.2C4.8 11.3 11.1 5 19 5c0 7.9-6.3 14.2-14.2 14.2ZM9.4 14.6 19 5"/>
			</g>
		</symbol>
		<symbol id="tl-i-sigillo" viewBox="0 0 24 24">
			<g fill="none" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round">
				<circle cx="12" cy="9.2" r="4.6"/><circle cx="12" cy="9.2" r="2.6"/>
				<path d="M9.4 13.2 8.4 20.8 12 18.9l3.6 1.9-1-7.6"/>
			</g>
		</symbol>
		<symbol id="tl-i-documento" viewBox="0 0 24 24">
			<g fill="none" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round">
				<path d="M6.2 3.6h7.6l4 4v13.4H6.2zM13.8 3.6v4h4M9.2 11.6h5.6M9.2 14.6h5.6M9.2 17.6h3.6"/>
			</g>
		</symbol>
	</svg>
	<?php
}
