<?php
/**
 * Mappa dei redirect legacy italiani. GENERATA da tools/migration/26-redirect-map.py.
 *
 * Non modificare a mano: rigenerare. Ogni voce dichiara COME si risolve la
 * destinazione, non un URL letterale, cosi' il redirect non puo' puntare a un
 * URL inesistente e segue il contenuto se cambia slug.
 *
 * Nessuna voce per EN, DE, FR: WPML e' inattivo e quegli URL non esistono.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Percorso legacy => array( genere, riferimento ).
 *
 * @return array
 */
function tenconi_redirect_map() {
	return array(
		'150esimo'                               => array( 'page',    'storia' ),  // slug legacy confluito nel nuovo contenuto
		'api-radian-laser-tracker'               => array( 'cpt',     'machine/api-radian-laser-tracker' ),  // slug legacy confluito nel nuovo contenuto
		'aree-di-attivita'                       => array( 'archive', 'capability' ),  // slug legacy confluito nel nuovo contenuto
		'asservimento'                           => array( 'cpt',     'job/asservimento' ),  // slug legacy confluito nel nuovo contenuto
		'assistente-del-personale-e-aiuto-contabile-copy' => array( 'cpt',     'job/assistente-del-personale-e-aiuto-contabile-copy' ),  // slug legacy confluito nel nuovo contenuto
		'carnaghi-tg-25'                         => array( 'cpt',     'machine/carnaghi-tg-25' ),  // slug legacy confluito nel nuovo contenuto
		'carpenteria-metallica'                  => array( 'cpt',     'capability/carpenteria-metallica' ),  // slug legacy confluito nel nuovo contenuto
		'chi-siamo'                              => array( 'page',    'storia' ),   // 27.10.2026: contenuti di Chi siamo spostati in La nostra storia
		'chi-siamo-1'                            => array( 'page',    'azienda' ),  // slug legacy confluito nel nuovo contenuto
		'condizioni-di-vendita'                  => array( 'cpt',     'document/condizioni-di-vendita' ),  // slug legacy confluito nel nuovo contenuto
		'deuma-fanuc'                            => array( 'cpt',     'machine/deuma-fanuc' ),  // slug legacy confluito nel nuovo contenuto
		'direzione'                              => array( 'page',    'azienda' ),  // slug legacy confluito nel nuovo contenuto
		'elettrodotto-altdorf'                   => array( 'cpt',     'project/elettrodotto-altdorf' ),  // slug legacy confluito nel nuovo contenuto
		'elettrodotto-saastal'                   => array( 'cpt',     'project/elettrodotto-saastal' ),  // slug legacy confluito nel nuovo contenuto
		'elettroerosione-roboform-400'           => array( 'cpt',     'machine/elettroerosione-roboform-400' ),  // slug legacy confluito nel nuovo contenuto
		'energia'                                => array( 'term',    'market/energia' ),  // slug legacy confluito nel nuovo contenuto
		'ferroviario-infrastruttura'             => array( 'term',    'market/ferroviario-infrastruttura' ),  // slug legacy confluito nel nuovo contenuto
		'ferroviario-rotabile'                   => array( 'term',    'market/ferroviario-rotabile' ),  // slug legacy confluito nel nuovo contenuto
		'foto-serata-commemorativa'              => array( 'page',    'storia' ),  // slug legacy confluito nel nuovo contenuto
		'frasteil'                               => array( 'cpt',     'project/frasteil' ),  // slug legacy confluito nel nuovo contenuto
		'frazer-open-xl'                         => array( 'cpt',     'machine/frazer-open-xl' ),  // slug legacy confluito nel nuovo contenuto
		'fresatrice-fu140ca-tiger-5'             => array( 'cpt',     'machine/fresatrice-fu140ca-tiger-5' ),  // slug legacy confluito nel nuovo contenuto
		'fronius'                                => array( 'cpt',     'machine/fronius' ),  // slug legacy confluito nel nuovo contenuto
		'gestione-progetti'                      => array( 'cpt',     'capability/gestione-progetti' ),  // slug legacy confluito nel nuovo contenuto
		'giunto'                                 => array( 'cpt',     'product/giunti-isolanti' ),  // slug legacy confluito nel nuovo contenuto
		'granigliatrice-omsg-cwb-850-4/fac'      => array( 'archive', 'machine' ),  // artefatto fac escluso per decisione approvata: nessun cont
		'home'                                   => array( 'page',    'home' ),  // slug legacy confluito nel nuovo contenuto
		'kawasaki-fa-10l-fronius'                => array( 'cpt',     'machine/kawasaki-fa-10l-fronius' ),  // slug legacy confluito nel nuovo contenuto
		'logistica'                              => array( 'cpt',     'capability/logistica-stoccaggio' ),  // slug legacy confluito nel nuovo contenuto
		'macchina-di-misura-athena'              => array( 'cpt',     'machine/macchina-di-misura-athena' ),  // slug legacy confluito nel nuovo contenuto
		'macchina-di-misura-hera-sp'             => array( 'cpt',     'machine/macchina-di-misura-hera-sp' ),  // slug legacy confluito nel nuovo contenuto
		'maglio-banning-goa-4000'                => array( 'cpt',     'machine/maglio-banning-goa-4000' ),  // slug legacy confluito nel nuovo contenuto
		'mandelli-7u-hp'                         => array( 'cpt',     'machine/mandelli-7u-hp' ),  // slug legacy confluito nel nuovo contenuto
		'mandelli-samu-regent-1500'              => array( 'cpt',     'machine/mandelli-samu-regent-1500' ),  // slug legacy confluito nel nuovo contenuto
		'mandelli-storm-1400'                    => array( 'cpt',     'machine/mandelli-storm-1400' ),  // slug legacy confluito nel nuovo contenuto
		'manipolatore-di-saldatura-2'            => array( 'cpt',     'machine/manipolatore-di-saldatura-2' ),  // slug legacy confluito nel nuovo contenuto
		'mcm-atl-heavy-plus-800'                 => array( 'cpt',     'machine/mcm-atl-heavy-plus-800' ),  // slug legacy confluito nel nuovo contenuto
		'mcm-tank-th1300'                        => array( 'cpt',     'machine/mcm-tank-th1300' ),  // slug legacy confluito nel nuovo contenuto
		'meccanico-reparto-energia'              => array( 'cpt',     'job/meccanico-reparto-energia' ),  // slug legacy confluito nel nuovo contenuto
		'metalmeccanica'                         => array( 'cpt',     'capability/lavorazioni-meccaniche' ),  // slug legacy confluito nel nuovo contenuto
		'normativa-sulla-privacy'                => array( 'page',    'privacy' ),  // slug legacy confluito nel nuovo contenuto
		'ossitaglio-cnc-messer'                  => array( 'cpt',     'machine/ossitaglio-cnc-messer' ),  // slug legacy confluito nel nuovo contenuto
		'pali-di-sostegno-fevi'                  => array( 'cpt',     'project/pali-di-sostegno-fevi' ),  // slug legacy confluito nel nuovo contenuto
		'palo-telefonia-mobile'                  => array( 'cpt',     'project/palo-telefonia-mobile' ),  // slug legacy confluito nel nuovo contenuto
		'parco-macchine-1'                       => array( 'archive', 'machine' ),  // slug legacy confluito nel nuovo contenuto
		'parpas-xs'                              => array( 'cpt',     'machine/parpas-xs' ),  // slug legacy confluito nel nuovo contenuto
		'ponte-navegna'                          => array( 'cpt',     'project/ponte-navegna' ),  // slug legacy confluito nel nuovo contenuto
		'ponte-sul-mara'                         => array( 'cpt',     'project/ponte-sul-mara' ),  // slug legacy confluito nel nuovo contenuto
		'pressa-cnc-gasparini'                   => array( 'cpt',     'machine/pressa-cnc-gasparini' ),  // slug legacy confluito nel nuovo contenuto
		'pressa-scharringhausen'                 => array( 'cpt',     'machine/pressa-scharringhausen' ),  // slug legacy confluito nel nuovo contenuto
		'rampe-acrobatiche'                      => array( 'cpt',     'project/rampe-acrobatiche' ),  // slug legacy confluito nel nuovo contenuto
		'resp-qualit-ambiente-sicurezza'         => array( 'cpt',     'job/resp-qualit-ambiente-sicurezza' ),  // slug legacy confluito nel nuovo contenuto
		'rettifica-per-tondi-kellenberger'       => array( 'cpt',     'machine/rettifica-per-tondi-kellenberger' ),  // slug legacy confluito nel nuovo contenuto
		'rettifica-piana-blohm'                  => array( 'cpt',     'machine/rettifica-piana-blohm' ),  // slug legacy confluito nel nuovo contenuto
		'revisione-bypass-verzasca'              => array( 'cpt',     'project/revisione-bypass-verzasca' ),  // slug legacy confluito nel nuovo contenuto
		'revisione-verzasca'                     => array( 'cpt',     'project/revisione-verzasca' ),  // slug legacy confluito nel nuovo contenuto
		'robot-di-saldatura-1'                   => array( 'cpt',     'machine/robot-di-saldatura-1' ),  // slug legacy confluito nel nuovo contenuto
		'rullatrice-ort-rp30-u-cn'               => array( 'cpt',     'machine/rullatrice-ort-rp30-u-cn' ),  // slug legacy confluito nel nuovo contenuto
		'samsung-pl-45xlm'                       => array( 'cpt',     'machine/samsung-pl-45xlm' ),  // slug legacy confluito nel nuovo contenuto
		'sega-a-nastro-istech-350sa'             => array( 'cpt',     'machine/sega-a-nastro-istech-350sa' ),  // slug legacy confluito nel nuovo contenuto
		'sega-a-nastro-istech-431ncl'            => array( 'cpt',     'machine/sega-a-nastro-istech-431ncl' ),  // slug legacy confluito nel nuovo contenuto
		'segatrice-mep-shark-652-sxi-h-50'       => array( 'cpt',     'machine/segatrice-mep-shark-652-sxi-h-50' ),  // slug legacy confluito nel nuovo contenuto
		'sigma-mission-5'                        => array( 'cpt',     'machine/sigma-mission-5' ),  // slug legacy confluito nel nuovo contenuto
		'sigma-zenit-3p'                         => array( 'cpt',     'machine/sigma-zenit-3p' ),  // slug legacy confluito nel nuovo contenuto
		'sottostazione-ail'                      => array( 'cpt',     'project/sottostazione-ail' ),  // slug legacy confluito nel nuovo contenuto
		'staff'                                  => array( 'page',    'azienda' ),  // slug legacy confluito nel nuovo contenuto
		'supporto'                               => array( 'archive', 'capability' ),  // slug legacy confluito nel nuovo contenuto
		'telaio-motrice'                         => array( 'cpt',     'project/telaio-motrice' ),  // slug legacy confluito nel nuovo contenuto
		'tiesse-fa06e-fd40---kawasaki'           => array( 'cpt',     'machine/tiesse-fa06e-fd40-kawasaki' ),  // slug legacy confluito nel nuovo contenuto
		'tiesse-fa06e-fd40-/-kawasaki'           => array( 'cpt',     'machine/tiesse-fa06e-fd40-kawasaki' ),  // URL legacy con barra interna nello slug, non riproducibile
		'tiesse-fa10l-fd40---kawasaki'           => array( 'cpt',     'machine/tiesse-fa10l-fd40-kawasaki' ),  // slug legacy confluito nel nuovo contenuto
		'tiesse-fa10l-fd40-/-kawasaki'           => array( 'cpt',     'machine/tiesse-fa10l-fd40-kawasaki' ),  // URL legacy con barra interna nello slug, non riproducibile
		'tiger-tfa-5'                            => array( 'cpt',     'machine/tiger-tfa-5' ),  // slug legacy confluito nel nuovo contenuto
		'traverse'                               => array( 'cpt',     'product/traverse' ),  // slug legacy confluito nel nuovo contenuto
		'valvolafarfallavf2'                     => array( 'cpt',     'project/valvolafarfallavf2' ),  // slug legacy confluito nel nuovo contenuto
		'valvolafarfallavf3'                     => array( 'cpt',     'project/valvolafarfallavf3' ),  // slug legacy confluito nel nuovo contenuto
		'valvolasferica'                         => array( 'cpt',     'project/valvolasferica' ),  // slug legacy confluito nel nuovo contenuto
	);
}
