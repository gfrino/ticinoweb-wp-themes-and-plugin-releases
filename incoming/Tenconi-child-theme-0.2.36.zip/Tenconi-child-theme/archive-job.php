<?php
/**
 * JOBS — "Lavora con noi", l'archivio del CPT job reso come la pagina legacy.
 *
 * URL: /jobs/
 *
 * Le posizioni aperte vengono dalla bacheca (inc/jobs.php), la candidatura
 * spontanea ha il suo modulo (inc/job-application.php).
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$GLOBALS['tenconi_interne'] = true;
get_header();

get_template_part( 'template-parts/interne/jobs' );

get_footer();
