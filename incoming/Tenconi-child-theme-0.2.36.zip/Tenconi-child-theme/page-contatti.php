<?php
/**
 * CONTATTI — la pagina legacy: titolo centrato e blocchi di recapiti centrati.
 *
 * URL: /contatti/
 *
 * MISURE, dai pixel di tenconi.ch:contatti.png (2240 x 2135 CSS):
 *   H1              cassa 42,5, cima a y 300,5, centrato maiuscolo blu
 *   recapiti        blocchi CENTRATI in colonna stretta, righe di cassa 12,
 *                   la prima a y 406, poi 438,5 e 471 -> passo di riga ~32,5
 *   modulo          largo 682 e centrato, con alcune righe divise in due campi
 *                   da 336 con gap 10
 *
 * IL TESTO E' QUELLO PUBBLICATO, non l'HTML legacy: la Content Foundation lo ha
 * gia' costruito e la consegna dice di mantenerlo. Coincide col legacy tranne per
 * un blocco: il legacy mostra anche il recapito generale (telefono, fax ed
 * email), che nel contenuto pubblicato non c'e'. E' una divergenza di CONTENUTO, non di
 * layout, e non la colmo inventando: va aggiunta alla pagina in WordPress.
 *
 * IL MODULO NON VIENE RESO, e la ragione e' importante. Nel legacy c'era un
 * modulo Squarespace; qui non esiste alcun gestore di moduli — nessun plugin
 * installato, nessun endpoint. Disegnare i campi produrrebbe un modulo che
 * SEMBRA funzionante e getta via le richieste dei clienti: su una pagina contatti
 * di un'azienda manifatturiera e' il guasto peggiore possibile. Al suo posto c'e'
 * la via di contatto reale. Quando arriva un gestore, il modulo va qui, con la
 * geometria misurata sopra.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * Il modulo porta un nonce che scade: una copia in cache della pagina, servita
 * giorni dopo, farebbe fallire ogni invio con "sessione scaduta".
 */
do_action( 'litespeed_control_set_nocache', 'Tenconi: modulo contatti con nonce' );

get_header();

$tl_post = get_queried_object();

/*
 * I blocchi del legacy sono paragrafi separati. Si preserva quella struttura
 * leggendo il contenuto pubblicato e tenendo le righe: ogni riga vuota apre un
 * blocco nuovo, come nel legacy.
 */
$tl_raw = $tl_post ? (string) $tl_post->post_content : '';
/*
 * Prima le interruzioni, POI i blocchi. Senza il secondo passaggio
 * wp_strip_all_tags incolla le righe fra loro e viene fuori
 * "<RAGIONE SOCIALE><via><NPA localita>": il contenuto pubblicato
 * separa le righe con elementi di blocco, non con <br>.
 */
$tl_raw = preg_replace( '#<br\s*/?>#i', "\n", $tl_raw );
$tl_raw = preg_replace( '#</(p|div|h[1-6]|li|tr)>#i', "\n", $tl_raw );
$tl_txt = html_entity_decode( wp_strip_all_tags( $tl_raw ), ENT_QUOTES, 'UTF-8' );

$tl_blocchi = array();
foreach ( preg_split( '/\n\s*\n+/u', $tl_txt ) as $tl_b ) {
	$tl_righe = array();
	foreach ( preg_split( '/\n/u', $tl_b ) as $tl_r ) {
		$tl_r = trim( $tl_r );
		if ( '' !== $tl_r ) {
			$tl_righe[] = $tl_r;
		}
	}
	if ( $tl_righe ) {
		$tl_blocchi[] = $tl_righe;
	}
}
?>
<main id="main" class="tl-main" tabindex="-1">
	<div class="tl-wrap">

		<h1 class="tl-titolo tl-titolo--pagina">Contatti</h1>

		<?php
		/*
		 * IL LEGACY ALLINEA A SINISTRA in una colonna da 682 centrata nella pagina,
		 * non al centro. La prima lettura della geometria aveva misurato la fascia
		 * dell'H1 invece dei recapiti, e ne era uscito tutto centrato: sbagliato.
		 * La colonna da 682 e' la stessa del modulo, misurata a x 779.
		 *
		 * Il primo blocco di ogni gruppo e' il NOME (azienda o persona) e nel legacy
		 * e' in grassetto blu; le righe successive sono il recapito.
		 */
		?>

		<div class="tl-ct">
			<?php foreach ( $tl_blocchi as $tl_k => $tl_b ) : ?>
				<p class="tl-ct__b<?php echo 0 === $tl_k ? ' tl-ct__b--nome' : ''; ?>">
					<?php
					$tl_n = count( $tl_b );
					foreach ( $tl_b as $tl_i => $tl_r ) :
						/*
						 * Un recapito e' utile solo se e' azionabile: le mail diventano
						 * mailto e i numeri tel. Il testo mostrato resta identico.
						 */
						if ( preg_match( '/[\w.\-]+@[\w.\-]+\.\w+/u', $tl_r, $tl_m ) ) {
							$tl_pre = trim( str_replace( $tl_m[0], '', $tl_r ) );
							if ( '' !== $tl_pre ) {
								echo esc_html( $tl_pre ) . ' ';
							}
							printf(
								'<a class="tl-link" href="mailto:%1$s">%1$s</a>',
								esc_attr( $tl_m[0] )
							);
						} elseif ( preg_match( '/^(.*?)(\+[\d\s()\/]{9,})$/u', $tl_r, $tl_m ) ) {
							$tl_num = trim( $tl_m[2] );
							$tl_pre = trim( $tl_m[1] );
							if ( '' !== $tl_pre ) {
								echo esc_html( $tl_pre ) . ' ';
							}
							printf(
								'<a class="tl-link" href="tel:%1$s">%2$s</a>',
								esc_attr( preg_replace( '/[^\d+]/', '', $tl_num ) ),
								esc_html( $tl_num )
							);
						} else {
							echo esc_html( $tl_r );
						}
						if ( $tl_i < $tl_n - 1 ) {
							echo '<br>';
						}
					endforeach;
					?>
				</p>
			<?php endforeach; ?>
		</div>

		<?php
		/*
		 * IL MODULO. Nel legacy stava qui, largo 682 e centrato, con alcune righe
		 * divise in due campi da 336. Adesso funziona davvero: vedi
		 * inc/contact-form.php per nonce, honeypot, rate limiting e validazione.
		 */
		$tl_campi = tenconi_form_campi();
		?>
		<div class="tl-ct" id="tl-modulo">
			<hr class="tl-riga tl-riga--modulo">

			<?php echo tenconi_form_esito(); // phpcs:ignore WordPress.Security.EscapeOutput -- HTML gia' sfuggito nella funzione. ?>

			<form class="tl-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( TENCONI_FORM_AZIONE ); ?>">
				<?php wp_nonce_field( TENCONI_FORM_AZIONE, 'tl_nonce' ); ?>
				<input type="hidden" name="tl_t" value="<?php echo esc_attr( (string) time() ); ?>">

				<?php /* Honeypot: fuori dallo schermo ma non display:none, che i bot riconoscono. */ ?>
				<div class="tl-form__trappola" aria-hidden="true">
					<label for="tl-sito">Sito web</label>
					<input type="text" id="tl-sito" name="tl_sito" tabindex="-1" autocomplete="off">
				</div>

				<div class="tl-form__g">
					<?php foreach ( $tl_campi as $tl_k => $tl_c ) : ?>
						<p class="tl-form__c<?php echo $tl_c['largo'] ? ' tl-form__c--largo' : ''; ?>">
							<label for="tl-<?php echo esc_attr( $tl_k ); ?>">
								<?php echo esc_html( $tl_c['label'] ); ?><?php echo $tl_c['obbl'] ? ' <span class="tl-form__ob" aria-hidden="true">*</span>' : ''; ?>
							</label>
							<?php if ( 'textarea' === $tl_c['tipo'] ) : ?>
								<textarea id="tl-<?php echo esc_attr( $tl_k ); ?>" name="<?php echo esc_attr( $tl_k ); ?>" rows="5"<?php echo $tl_c['obbl'] ? ' required' : ''; ?>></textarea>
							<?php else : ?>
								<input type="<?php echo esc_attr( $tl_c['tipo'] ); ?>" id="tl-<?php echo esc_attr( $tl_k ); ?>" name="<?php echo esc_attr( $tl_k ); ?>"<?php echo $tl_c['obbl'] ? ' required' : ''; ?> autocomplete="<?php echo 'email' === $tl_c['tipo'] ? 'email' : 'on'; ?>">
							<?php endif; ?>
						</p>
					<?php endforeach; ?>
				</div>

				<p class="tl-form__invia">
					<button type="submit" class="tl-bottone tl-bottone--invia">Invia</button>
				</p>
			</form>
		</div>
	</div>
</main>
<?php
get_footer();
