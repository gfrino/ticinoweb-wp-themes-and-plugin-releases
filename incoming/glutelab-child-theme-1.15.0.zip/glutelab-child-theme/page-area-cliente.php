<?php
/** Protected customer account for lessons and credits. @package GluteLabChildTheme */
if ( ! defined( 'ABSPATH' ) ) exit;
get_header(); ?>
<main id="primary" class="gl-main gl-page gl-account-page">
	<?php glutelab_app_render_account_page(); ?>
</main>
<?php get_footer(); ?>
