<?php
/** Public purchase and booking UI. @package GluteLabChildTheme */
if ( ! defined( 'ABSPATH' ) ) exit;

function glutelab_app_is_purchase_page() { return is_page_template( 'page-acquista-o-prenota.php' ) || is_page( 'acquista-o-prenota' ); }
function glutelab_app_is_account_page() { return is_page_template( 'page-area-cliente.php' ) || is_page( 'area-clienti' ); }
function glutelab_app_enqueue_frontend() {
	if ( ! glutelab_app_is_purchase_page() && ! glutelab_app_is_account_page() ) return;
	wp_enqueue_style( 'glutelab-booking', get_stylesheet_directory_uri() . '/assets/css/booking.css', array( 'glutelab-responsive' ), GLUTELAB_THEME_VERSION );
	$handle = glutelab_app_is_account_page() ? 'glutelab-account' : 'glutelab-booking';
	$file   = glutelab_app_is_account_page() ? 'account.js' : 'booking.js';
	wp_enqueue_script( $handle, get_stylesheet_directory_uri() . '/assets/js/' . $file, array(), GLUTELAB_THEME_VERSION, true );
	wp_localize_script( $handle, 'glutelabBooking', array( 'slotsUrl' => rest_url( 'glutelab/v1/slots' ), 'nonce' => wp_create_nonce( 'wp_rest' ), 'chooseDate' => __( 'Prima scegli un giorno', 'glutelab-child-theme' ), 'chooseTime' => __( 'Scegli un orario', 'glutelab-child-theme' ), 'loading' => __( 'Caricamento orari…', 'glutelab-child-theme' ), 'empty' => __( 'Nessun orario disponibile per questa data.', 'glutelab-child-theme' ), 'error' => __( 'Non è stato possibile caricare gli orari.', 'glutelab-child-theme' ), 'cancelConfirm' => __( 'Vuoi annullare questa lezione? Il credito verrà restituito.', 'glutelab-child-theme' ) ) );
}
add_action( 'wp_enqueue_scripts', 'glutelab_app_enqueue_frontend', 30 );

function glutelab_app_protect_account_page() {
	if ( ! glutelab_app_is_account_page() ) return;
	if ( ! defined( 'DONOTCACHEPAGE' ) ) define( 'DONOTCACHEPAGE', true );
	nocache_headers();
}
add_action( 'template_redirect', 'glutelab_app_protect_account_page', 0 );

function glutelab_app_account_robots( $robots ) {
	if ( glutelab_app_is_account_page() ) { $robots['noindex'] = true; $robots['follow'] = true; }
	return $robots;
}
add_filter( 'wp_robots', 'glutelab_app_account_robots' );

function glutelab_app_register_slots_route() { register_rest_route( 'glutelab/v1', '/slots', array( 'methods' => 'GET', 'callback' => 'glutelab_app_slots_endpoint', 'permission_callback' => '__return_true', 'args' => array( 'package' => array( 'required' => true, 'sanitize_callback' => 'sanitize_key' ), 'date' => array( 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ) ) ) ); }
function glutelab_app_slots_endpoint( $request ) {
	$settings = glutelab_app_get_settings(); if ( empty( $settings['enabled'] ) || empty( $settings['booking_enabled'] ) ) return new WP_Error( 'booking_disabled', __( 'Prenotazione online non disponibile.', 'glutelab-child-theme' ), array( 'status' => 404 ) );
	$ip = sanitize_text_field( $_SERVER['REMOTE_ADDR'] ?? '' ); $key = 'gl_slots_' . md5( $ip ); $count = (int) get_transient( $key ); if ( $count > 60 ) return new WP_Error( 'rate_limited', __( 'Troppe richieste. Riprova tra poco.', 'glutelab-child-theme' ), array( 'status' => 429 ) ); set_transient( $key, $count + 1, MINUTE_IN_SECONDS );
	$package = glutelab_get_package( $request->get_param( 'package' ) ); if ( ! $package || 'active' !== ( $package['status'] ?? '' ) ) return new WP_Error( 'invalid_package', __( 'Offerta non disponibile.', 'glutelab-child-theme' ), array( 'status' => 404 ) );
	$slots = glutelab_app_filter_available_slots( glutelab_app_slots_for_date( $request->get_param( 'date' ), $package ), $package );
	foreach ( $slots as &$slot ) { $slot['value'] = $slot['utc'] . '|' . $slot['end_utc']; $slot['duration_label'] = glutelab_app_duration_label( $slot['duration_minutes'] ); unset( $slot['utc'], $slot['end_utc'] ); } unset( $slot );
	return rest_ensure_response( array( 'slots' => $slots ) );
}

function glutelab_app_result_message( $code, $reference = '' ) {
	$messages = array( 'received' => __( 'Richiesta ricevuta. Ti contatteremo per la conferma.', 'glutelab-child-theme' ), 'payment-pending' => __( 'Richiesta ricevuta. Il pagamento resta da completare: riceverai il link online appena disponibile.', 'glutelab-child-theme' ), 'payment-return' => __( 'Pagamento inviato. La conferma definitiva arriva dopo la verifica del pagamento.', 'glutelab-child-theme' ), 'payment-cancelled' => __( 'Pagamento annullato. La richiesta non è stata addebitata.', 'glutelab-child-theme' ), 'payment-error' => __( 'Non è stato possibile avviare il pagamento. La richiesta è stata salvata: contattaci indicando il riferimento.', 'glutelab-child-theme' ), 'slot-unavailable' => __( 'L’orario scelto non è più disponibile. Selezionane un altro.', 'glutelab-child-theme' ), 'too-fast' => __( 'La richiesta è già stata inviata. Attendi un minuto prima di riprovare.', 'glutelab-child-theme' ), 'disabled' => __( 'Il servizio online è in configurazione. Contattaci direttamente.', 'glutelab-child-theme' ) );
	$message = $messages[ $code ] ?? __( 'Non è stato possibile completare la richiesta. Controlla i dati e riprova.', 'glutelab-child-theme' );
	return $reference ? $message . ' ' . sprintf( __( 'Riferimento: %s.', 'glutelab-child-theme' ), sanitize_text_field( $reference ) ) : $message;
}

function glutelab_app_render_purchase_page( $selected_id ) {
	$package = glutelab_get_package( $selected_id ); $settings = glutelab_app_get_settings(); $result = sanitize_key( wp_unslash( $_GET['gl_result'] ?? '' ) ); $reference = sanitize_text_field( wp_unslash( $_GET['reference'] ?? '' ) );
	$is_success   = in_array( $result, array( 'received', 'payment-pending', 'payment-return' ), true );
	$notice_class = $is_success ? ' is-success' : ' is-warning';
	$schedule_enabled    = $package && ! empty( $settings['booking_enabled'] );
	$has_weekly_schedule = glutelab_app_has_weekly_availability( $settings );
	$has_duration        = $package && ! empty( $package['session_minutes'] );
	$booking_available   = $schedule_enabled && $has_weekly_schedule && $has_duration;
	$available_dates     = $booking_available ? glutelab_app_upcoming_schedule_dates( $package ) : ( $schedule_enabled && $has_weekly_schedule ? glutelab_app_upcoming_open_dates() : array() );
	$online_available    = $package && ! empty( $settings['stripe_enabled'] ) && ! empty( $package['online_purchase_available'] ) && (float) $package['price'] > 0 && glutelab_app_stripe_is_configured();
	?>
	<header class="gl-page-hero gl-booking-hero"><div class="gl-shell"><p class="gl-kicker"><?php esc_html_e( 'GLUTE LAB — RICHIESTA', 'glutelab-child-theme' ); ?></p><h1><?php the_title(); ?></h1><p><?php esc_html_e( 'Scegli il percorso e inviaci i tuoi dati. Le opzioni non ancora configurate restano visibili e vengono indicate chiaramente.', 'glutelab-child-theme' ); ?></p></div></header>
	<section class="gl-section"><div class="gl-shell">
	<?php if ( $result ) : ?><div id="gl-booking-result" class="gl-booking-notice<?php echo esc_attr( $notice_class ); ?>" role="status" aria-live="polite"><?php if ( $is_success ) : ?><span class="gl-booking-notice__icon" aria-hidden="true">&#10003;</span><?php endif; ?><strong><?php echo esc_html( glutelab_app_result_message( $result, $reference ) ); ?></strong></div><?php endif; ?>
	<?php if ( ! $package || 'active' !== $package['status'] ) : echo glutelab_purchase_summary_html( $selected_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	elseif ( empty( $settings['enabled'] ) ) : ?>
		<div class="gl-booking-layout"><div><?php echo glutelab_purchase_summary_html( $selected_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><aside class="gl-booking-panel"><p class="gl-kicker"><?php esc_html_e( 'CONFIGURAZIONE IN CORSO', 'glutelab-child-theme' ); ?></p><h2><?php esc_html_e( 'Richiedi informazioni', 'glutelab-child-theme' ); ?></h2><p><?php esc_html_e( 'Il sistema online è pronto ma non è ancora stato attivato. Nel frattempo puoi contattare direttamente ASCO Fit.', 'glutelab-child-theme' ); ?></p><a class="gl-button gl-button--primary" href="<?php echo esc_url( glutelab_page_url( 'contatti' ) ); ?>"><?php esc_html_e( 'Vai ai contatti', 'glutelab-child-theme' ); ?></a></aside></div>
	<?php else :
		$total_lessons    = glutelab_calculate_total_lessons( $package['lessons_purchased'], $package['bonus_lessons'] );
		$inclusions       = glutelab_package_inclusions( $package );
		$participant_text = null;
		if ( null !== $package['max_participants'] ) {
			$participant_text = 1 === (int) $package['max_participants'] ? __( 'One to One', 'glutelab-child-theme' ) : sprintf( __( 'Massimo %d persone', 'glutelab-child-theme' ), (int) $package['max_participants'] );
		}
	?>
		<div class="gl-booking-layout"><aside class="gl-booking-summary" aria-labelledby="gl-booking-summary-title">
			<div class="gl-booking-summary__head">
				<p class="gl-kicker"><?php echo esc_html( glutelab_get_catalog()['groups'][ $package['group_id'] ]['title'] ?? '' ); ?></p>
				<h2 id="gl-booking-summary-title"><?php echo esc_html( $package['title'] ); ?></h2>
				<p class="gl-booking-price"><?php echo esc_html( glutelab_package_price_text( $package ) ); ?></p>
				<?php if ( $package['description'] ) : ?><p class="gl-booking-summary__description"><?php echo esc_html( $package['description'] ); ?></p><?php endif; ?>
			</div>
			<?php if ( null !== $total_lessons || $has_duration || $participant_text ) : ?>
				<dl class="gl-booking-summary__facts">
					<?php if ( null !== $total_lessons ) : ?><div><dt><?php esc_html_e( 'Lezioni incluse', 'glutelab-child-theme' ); ?></dt><dd><?php echo esc_html( $total_lessons ); ?></dd></div><?php endif; ?>
					<?php if ( $has_duration ) : ?><div><dt><?php esc_html_e( 'Durata', 'glutelab-child-theme' ); ?></dt><dd><?php echo esc_html( glutelab_app_duration_label( $package['session_minutes'] ) ); ?></dd></div><?php endif; ?>
					<?php if ( $participant_text ) : ?><div><dt><?php esc_html_e( 'Formula', 'glutelab-child-theme' ); ?></dt><dd><?php echo esc_html( $participant_text ); ?></dd></div><?php endif; ?>
				</dl>
			<?php endif; ?>
			<?php if ( $inclusions ) : ?><div class="gl-booking-summary__includes"><h3><?php esc_html_e( 'Incluso nel percorso', 'glutelab-child-theme' ); ?></h3><ul><?php foreach ( $inclusions as $item ) : ?><li><?php echo esc_html( $item ); ?></li><?php endforeach; ?></ul></div><?php endif; ?>
			<div class="gl-booking-summary__foot"><p><?php esc_html_e( 'Giorno e orario verranno confermati da ASCO Fit dopo la richiesta.', 'glutelab-child-theme' ); ?></p><a class="gl-button gl-button--secondary gl-booking-summary__change" href="<?php echo esc_url( glutelab_page_url( 'pacchetti-e-lezioni' ) ); ?>"><?php esc_html_e( 'Cambia offerta', 'glutelab-child-theme' ); ?></a></div>
		</aside>
		<form class="gl-booking-form" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" data-gl-booking-form>
			<div class="gl-booking-form__head"><p class="gl-kicker"><?php esc_html_e( 'RICHIESTA LEZIONE', 'glutelab-child-theme' ); ?></p><h2><?php esc_html_e( 'Invia la richiesta', 'glutelab-child-theme' ); ?></h2><p><?php esc_html_e( 'Completa i tre passaggi. La richiesta non conferma automaticamente l’appuntamento: riceverai una risposta da ASCO Fit.', 'glutelab-child-theme' ); ?></p></div>
			<nav class="gl-form-progress" aria-label="<?php esc_attr_e( 'Avanzamento della richiesta', 'glutelab-child-theme' ); ?>" data-gl-form-progress>
				<ol>
					<li><button type="button" data-gl-step-target="1" data-step-announcement="<?php echo esc_attr( sprintf( __( 'Passaggio %1$d di %2$d: %3$s', 'glutelab-child-theme' ), 1, 3, __( 'I tuoi dati', 'glutelab-child-theme' ) ) ); ?>" aria-current="step"><span>1</span><strong><?php esc_html_e( 'I tuoi dati', 'glutelab-child-theme' ); ?></strong></button></li>
					<li><button type="button" data-gl-step-target="2" data-step-announcement="<?php echo esc_attr( sprintf( __( 'Passaggio %1$d di %2$d: %3$s', 'glutelab-child-theme' ), 2, 3, __( 'Giorno e orario', 'glutelab-child-theme' ) ) ); ?>" disabled><span>2</span><strong><?php esc_html_e( 'Giorno e orario', 'glutelab-child-theme' ); ?></strong></button></li>
					<li><button type="button" data-gl-step-target="3" data-step-announcement="<?php echo esc_attr( sprintf( __( 'Passaggio %1$d di %2$d: %3$s', 'glutelab-child-theme' ), 3, 3, __( 'Conferma', 'glutelab-child-theme' ) ) ); ?>" disabled><span>3</span><strong><?php esc_html_e( 'Conferma', 'glutelab-child-theme' ); ?></strong></button></li>
				</ol>
			</nav>
			<p class="screen-reader-text" data-gl-form-status aria-live="polite"></p>
			<input type="hidden" name="action" value="glutelab_app_request"><input type="hidden" name="package_id" value="<?php echo esc_attr( $package['id'] ); ?>"><?php wp_nonce_field( 'glutelab_app_request', 'glutelab_nonce' ); ?>
			<section class="gl-form-step" data-gl-form-step="1" aria-labelledby="gl-booking-step-title-1">
				<header class="gl-form-step__head"><p><?php esc_html_e( 'Passaggio 1 di 3', 'glutelab-child-theme' ); ?></p><h3 id="gl-booking-step-title-1" tabindex="-1"><?php esc_html_e( 'Come possiamo contattarti?', 'glutelab-child-theme' ); ?></h3><span><?php esc_html_e( 'Inserisci i dati della persona interessata al percorso.', 'glutelab-child-theme' ); ?></span></header>
				<div class="gl-form-grid"><label><?php esc_html_e( 'Nome', 'glutelab-child-theme' ); ?><input required name="first_name" autocomplete="given-name"></label><label><?php esc_html_e( 'Cognome', 'glutelab-child-theme' ); ?><input required name="last_name" autocomplete="family-name"></label><label><?php esc_html_e( 'Email', 'glutelab-child-theme' ); ?><input required type="email" name="email" autocomplete="email"></label><label><?php esc_html_e( 'Telefono', 'glutelab-child-theme' ); ?><input required type="tel" name="phone" autocomplete="tel"></label></div>
				<div class="gl-booking-form__nav"><button class="gl-button gl-button--primary" type="button" data-gl-form-next><?php esc_html_e( 'Continua', 'glutelab-child-theme' ); ?><span aria-hidden="true">&#8594;</span></button></div>
			</section>
			<section class="gl-form-step" data-gl-form-step="2" aria-labelledby="gl-booking-step-title-2">
				<header class="gl-form-step__head"><p><?php esc_html_e( 'Passaggio 2 di 3', 'glutelab-child-theme' ); ?></p><h3 id="gl-booking-step-title-2" tabindex="-1"><?php esc_html_e( 'Scegli quando preferisci', 'glutelab-child-theme' ); ?></h3><span><?php esc_html_e( 'Prima il giorno, poi uno degli orari disponibili. La preferenza resta facoltativa.', 'glutelab-child-theme' ); ?></span></header>
			<fieldset class="gl-booking-slot">
				<legend><?php esc_html_e( 'Quando preferisci?', 'glutelab-child-theme' ); ?></legend>
				<p><?php esc_html_e( 'I giorni seguono automaticamente le disponibilità configurate in Settimana A e Settimana B.', 'glutelab-child-theme' ); ?></p>
				<?php if ( $has_duration ) : ?><div class="gl-booking-duration"><span><?php esc_html_e( 'Durata della lezione', 'glutelab-child-theme' ); ?></span><strong><?php echo esc_html( glutelab_app_duration_label( $package['session_minutes'] ) ); ?></strong><small><?php esc_html_e( 'Ogni scelta oraria copre esattamente questa durata.', 'glutelab-child-theme' ); ?></small></div><?php endif; ?>
				<div class="gl-booking-steps">
					<div class="gl-booking-step">
						<span class="gl-booking-step__number" aria-hidden="true">1</span>
						<label><span class="gl-booking-step__title"><?php esc_html_e( '1. Scegli il giorno', 'glutelab-child-theme' ); ?></span>
							<select name="booking_date" data-gl-booking-date<?php echo $available_dates ? '' : ' disabled'; ?>>
								<option value=""><?php echo esc_html( $available_dates ? __( 'Scegli un giorno', 'glutelab-child-theme' ) : __( 'Nessun giorno prenotabile', 'glutelab-child-theme' ) ); ?></option>
								<?php foreach ( $available_dates as $available_date ) : $date_object = new DateTimeImmutable( $available_date['value'], glutelab_app_timezone() ); ?><option value="<?php echo esc_attr( $available_date['value'] ); ?>"><?php echo esc_html( wp_date( 'l j F', $date_object->getTimestamp(), glutelab_app_timezone() ) ); ?></option><?php endforeach; ?>
							</select>
						</label>
					</div>
					<div class="gl-booking-step<?php echo $booking_available && $available_dates ? '' : ' is-locked'; ?>">
						<span class="gl-booking-step__number" aria-hidden="true">2</span>
						<label><span class="gl-booking-step__title"><?php esc_html_e( '2. Scegli l’orario', 'glutelab-child-theme' ); ?></span>
							<select name="slot" data-gl-booking-time data-package="<?php echo esc_attr( $booking_available ? $package['id'] : '' ); ?>" disabled>
								<option value=""><?php echo esc_html( $booking_available && $available_dates ? __( 'Prima scegli un giorno', 'glutelab-child-theme' ) : ( $has_duration ? __( 'Nessun orario disponibile', 'glutelab-child-theme' ) : __( 'Durata dell’offerta da configurare', 'glutelab-child-theme' ) ) ); ?></option>
							</select>
						</label>
						<p class="gl-booking-slot-status" data-gl-booking-status role="status"><?php if ( $booking_available && $available_dates ) esc_html_e( 'Gli orari compariranno dopo la scelta del giorno.', 'glutelab-child-theme' ); ?></p>
					</div>
				</div>
				<?php if ( ! $schedule_enabled ) : ?>
					<p class="gl-booking-empty-state" role="status"><strong><?php esc_html_e( 'Scelta dell’orario non ancora attiva', 'glutelab-child-theme' ); ?></strong><span><?php esc_html_e( 'Puoi comunque inviare la richiesta senza indicare giorno e orario.', 'glutelab-child-theme' ); ?></span></p>
				<?php elseif ( ! $has_weekly_schedule ) : ?>
					<p class="gl-booking-empty-state" role="status"><strong><?php esc_html_e( 'Nessuna fascia disponibile configurata', 'glutelab-child-theme' ); ?></strong><span><?php esc_html_e( 'Configura almeno un giorno nella Settimana A o B. Nel frattempo puoi inviare la richiesta senza giorno e orario.', 'glutelab-child-theme' ); ?></span></p>
				<?php elseif ( ! $has_duration ) : ?>
					<p class="gl-booking-empty-state" role="status"><strong><?php esc_html_e( 'Le fasce A/B sono configurate, ma manca la durata di questa offerta', 'glutelab-child-theme' ); ?></strong><span><?php esc_html_e( 'Imposta la durata in “Pacchetti & lezioni” per generare automaticamente gli orari. Nel frattempo puoi scegliere il giorno e inviare la richiesta senza orario.', 'glutelab-child-theme' ); ?></span></p>
				<?php elseif ( ! $available_dates ) : ?>
					<p class="gl-booking-empty-state" role="status"><strong><?php esc_html_e( 'Nessun giorno disponibile al momento', 'glutelab-child-theme' ); ?></strong><span><?php esc_html_e( 'Nelle fasce della Settimana A/B non entra una lezione completa nel periodo prenotabile. Verifica fasce, preavviso e chiusure oppure riprova più tardi.', 'glutelab-child-theme' ); ?></span></p>
				<?php endif; ?>
			</fieldset>
				<div class="gl-booking-form__nav"><button class="gl-button gl-button--secondary" type="button" data-gl-form-back><span aria-hidden="true">&#8592;</span><?php esc_html_e( 'Indietro', 'glutelab-child-theme' ); ?></button><button class="gl-button gl-button--primary" type="button" data-gl-form-next><?php esc_html_e( 'Continua', 'glutelab-child-theme' ); ?><span aria-hidden="true">&#8594;</span></button></div>
			</section>
			<section class="gl-form-step" data-gl-form-step="3" aria-labelledby="gl-booking-step-title-3">
				<header class="gl-form-step__head"><p><?php esc_html_e( 'Passaggio 3 di 3', 'glutelab-child-theme' ); ?></p><h3 id="gl-booking-step-title-3" tabindex="-1"><?php esc_html_e( 'Pagamento e conferma', 'glutelab-child-theme' ); ?></h3><span><?php esc_html_e( 'Controlla i dati e il consenso prima di proseguire al pagamento online.', 'glutelab-child-theme' ); ?></span></header>
				<input type="hidden" name="payment_method" value="stripe">
				<div class="gl-booking-method"><div class="gl-booking-option<?php echo $online_available ? '' : ' is-unavailable'; ?>"><span><strong><?php esc_html_e( 'Pagamento online', 'glutelab-child-theme' ); ?></strong><small id="gl-payment-online-status"><?php $online_available ? esc_html_e( 'Dopo l’invio verrai reindirizzato al pagamento sicuro Stripe, dove potrai inserire anche un eventuale coupon.', 'glutelab-child-theme' ) : esc_html_e( 'Configurazione Stripe da completare. La richiesta verrà salvata e potrai ricevere il link di pagamento via email.', 'glutelab-child-theme' ); ?></small></span></div></div>
				<label><?php esc_html_e( 'Note (facoltative)', 'glutelab-child-theme' ); ?><textarea name="notes" rows="4"></textarea></label><label class="gl-booking-privacy"><input required type="checkbox" name="privacy" value="1"> <span><?php esc_html_e( 'Accetto che i dati vengano usati per gestire questa richiesta.', 'glutelab-child-theme' ); ?><?php if ( get_privacy_policy_url() ) : ?> <a href="<?php echo esc_url( get_privacy_policy_url() ); ?>" target="_blank" rel="privacy-policy"><?php esc_html_e( 'Privacy Policy', 'glutelab-child-theme' ); ?></a><?php endif; ?></span></label><label class="gl-honeypot" aria-hidden="true">Website<input name="website" tabindex="-1" autocomplete="off"></label>
				<div class="gl-booking-form__nav"><button class="gl-button gl-button--secondary" type="button" data-gl-form-back><span aria-hidden="true">&#8592;</span><?php esc_html_e( 'Indietro', 'glutelab-child-theme' ); ?></button><button class="gl-button gl-button--primary" type="submit"><?php $online_available ? esc_html_e( 'Vai al pagamento sicuro', 'glutelab-child-theme' ) : esc_html_e( 'Invia la richiesta', 'glutelab-child-theme' ); ?></button></div>
			</section>
		</form></div>
	<?php endif; ?></div></section><?php
}

