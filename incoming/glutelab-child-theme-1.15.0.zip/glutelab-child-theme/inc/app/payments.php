<?php
/** Payment and credit workflows. @package GluteLabChildTheme */
if ( ! defined( 'ABSPATH' ) ) exit;

function glutelab_app_booking_can_confirm_after_payment( array $booking, $now = null ) {
	$status = sanitize_key( $booking['status'] ?? '' );
	if ( 'confirmed' === $status ) return true;
	if ( 'pending' !== $status ) return false;
	if ( empty( $booking['expires_at'] ) ) return true;
	try {
		$expires = new DateTimeImmutable( $booking['expires_at'], new DateTimeZone( 'UTC' ) );
		$now     = $now instanceof DateTimeImmutable ? $now->setTimezone( new DateTimeZone( 'UTC' ) ) : new DateTimeImmutable( 'now', new DateTimeZone( 'UTC' ) );
		return $expires > $now;
	} catch ( Exception $error ) {
		return false;
	}
}

function glutelab_app_finalize_paid_order( $order_id, $provider_reference = '', array $payment_data = array() ) {
	global $wpdb; $order = glutelab_app_get_order( $order_id );
	if ( ! $order ) return new WP_Error( 'order_not_found', __( 'Ordine non trovato.', 'glutelab-child-theme' ) );
	if ( ! empty( $order['credits_granted'] ) ) {
		if ( function_exists( 'glutelab_app_ensure_customer_user' ) ) glutelab_app_ensure_customer_user( $order['customer_id'] );
		return $order;
	}
	$package = glutelab_get_package( $order['package_id'] ); if ( ! $package ) return new WP_Error( 'package_not_found', __( 'Offerta non trovata.', 'glutelab-child-theme' ) );
	$lock_name = glutelab_app_credit_lock_name( $order['customer_id'] );
	if ( ! $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 8)', $lock_name ) ) ) return new WP_Error( 'credit_locked', __( 'Il saldo lezioni è in aggiornamento. Riprova tra poco.', 'glutelab-child-theme' ) );
	$result = null;
	$wpdb->query( 'START TRANSACTION' );
	try {
		$order = glutelab_app_get_order( $order_id );
		if ( ! $order ) throw new RuntimeException( 'order_not_found' );
		$credits = glutelab_app_package_credits( $package );
		if ( empty( $order['credits_granted'] ) && $credits ) {
			$entry = glutelab_app_add_credit_entry( array( 'customer_id' => $order['customer_id'], 'order_id' => $order['id'], 'package_id' => $order['package_id'], 'delta' => $credits, 'reason' => 'purchase', 'idempotency_key' => 'order-paid-' . $order['id'], 'note' => $provider_reference ) );
			if ( is_wp_error( $entry ) ) throw new RuntimeException( $entry->get_error_code() );
		}
		$booking = ! empty( $order['booking_id'] ) ? glutelab_app_get_booking( $order['booking_id'] ) : null;
		$booking_can_confirm = $booking && glutelab_app_booking_can_confirm_after_payment( $booking );
		if ( $booking_can_confirm && $credits ) {
			if ( empty( $booking['credits_used'] ) ) {
				$used = glutelab_app_apply_booking_credit_locked( $booking );
				if ( is_wp_error( $used ) ) throw new RuntimeException( $used->get_error_code() );
			}
		}
		$subtotal = max( 0, (int) ( $payment_data['subtotal_cents'] ?? $order['amount_cents'] ) );
		$discount = max( 0, (int) ( $payment_data['discount_cents'] ?? 0 ) );
		$paid     = max( 0, (int) ( $payment_data['amount_paid_cents'] ?? max( 0, $subtotal - $discount ) ) );
		$updated = $wpdb->update( glutelab_app_table( 'orders' ), array( 'status' => 'paid', 'credits_granted' => 1, 'subtotal_cents' => $subtotal, 'discount_cents' => $discount, 'amount_paid_cents' => $paid, 'paid_at' => glutelab_app_now_utc(), 'updated_at' => glutelab_app_now_utc(), 'stripe_payment_intent_id' => sanitize_text_field( $provider_reference ), 'stripe_discount_id' => sanitize_text_field( $payment_data['discount_id'] ?? '' ) ), array( 'id' => (int) $order_id ) );
		if ( false === $updated ) throw new RuntimeException( 'order_update_failed' );
		if ( $booking_can_confirm ) $wpdb->update( glutelab_app_table( 'bookings' ), array( 'status' => 'confirmed', 'expires_at' => null, 'updated_at' => glutelab_app_now_utc() ), array( 'id' => (int) $order['booking_id'] ) );
		$wpdb->query( 'COMMIT' );
		$result = glutelab_app_get_order( $order_id );
	} catch ( Throwable $error ) {
		$wpdb->query( 'ROLLBACK' );
		$result = new WP_Error( $error->getMessage(), __( 'Non è stato possibile confermare il pagamento.', 'glutelab-child-theme' ) );
	}
	$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock_name ) );
	if ( ! is_wp_error( $result ) && function_exists( 'glutelab_app_ensure_customer_user' ) ) {
		$account = glutelab_app_ensure_customer_user( $order['customer_id'] );
		if ( is_wp_error( $account ) ) do_action( 'glutelab_app_account_provision_failed', $account, $order['customer_id'] );
	}
	return $result;
}

function glutelab_app_create_request( array $input ) {
	$package = glutelab_get_package( sanitize_key( $input['package_id'] ?? '' ) );
	if ( ! $package || 'active' !== $package['status'] ) return new WP_Error( 'invalid_package', __( 'L’offerta selezionata non è disponibile.', 'glutelab-child-theme' ) );
	$customer_id = glutelab_app_upsert_customer( $input ); if ( is_wp_error( $customer_id ) ) return $customer_id;
	$method = 'stripe';
	$order = glutelab_app_create_order( array( 'customer_id' => $customer_id, 'package_id' => $package['id'], 'amount_cents' => (int) round( $package['price'] * 100 ), 'payment_method' => $method, 'status' => 'awaiting_payment' ) );
	if ( is_wp_error( $order ) ) return $order;
	$booking = null;
	if ( ! empty( $input['start_at_utc'] ) || ! empty( $input['preferred_date'] ) ) {
		$booking = glutelab_app_create_booking( array( 'customer_id' => $customer_id, 'order_id' => $order['id'], 'preferred_date' => sanitize_text_field( $input['preferred_date'] ?? '' ), 'start_at_utc' => sanitize_text_field( $input['start_at_utc'] ?? '' ), 'end_at_utc' => sanitize_text_field( $input['end_at_utc'] ?? '' ), 'seats' => 1, 'status' => 'stripe' === $method ? 'pending' : 'requested', 'notes' => $input['notes'] ?? '', 'expires_at' => 'stripe' === $method ? gmdate( 'Y-m-d H:i:s', time() + 1800 ) : null ), $package );
		global $wpdb;
		if ( is_wp_error( $booking ) ) {
			$wpdb->delete( glutelab_app_table( 'orders' ), array( 'id' => (int) $order['id'] ), array( '%d' ) );
			return $booking;
		}
		$wpdb->update( glutelab_app_table( 'orders' ), array( 'booking_id' => $booking['id'] ), array( 'id' => $order['id'] ) );
	}
	return array( 'customer_id' => $customer_id, 'order' => $order, 'booking' => $booking, 'package' => $package );
}

/** Send a fresh Stripe Checkout link for an unpaid order and track the reminder. */
function glutelab_app_send_payment_reminder( $order_id ) {
	global $wpdb;
	$order = glutelab_app_get_order( (int) $order_id );
	if ( ! $order ) return new WP_Error( 'order_not_found', __( 'Pagamento non trovato.', 'glutelab-child-theme' ) );
	if ( ! in_array( $order['status'], array( 'pending', 'awaiting_payment', 'payment_failed' ), true ) ) return new WP_Error( 'payment_not_remindable', __( 'Questo pagamento non richiede un promemoria.', 'glutelab-child-theme' ) );
	$customer = glutelab_app_get_customer( $order['customer_id'] );
	$package  = glutelab_get_package( $order['package_id'] );
	if ( ! $customer || ! $package ) return new WP_Error( 'payment_data_missing', __( 'Mancano i dati necessari per il promemoria.', 'glutelab-child-theme' ) );
	$attempt = (int) ( $order['payment_reminder_count'] ?? 0 ) + 1;
	$link    = glutelab_app_stripe_create_checkout( array( 'order' => $order, 'package' => $package ), $attempt );
	if ( is_wp_error( $link ) ) return $link;
	$subject = sprintf( __( 'Completa il pagamento Glute Lab — %s', 'glutelab-child-theme' ), $order['reference'] );
	$message = implode( "\n\n", array(
		sprintf( __( 'Ciao %s,', 'glutelab-child-theme' ), $customer['first_name'] ),
		sprintf( __( 'Il pagamento di %1$s per %2$s risulta ancora da completare.', 'glutelab-child-theme' ), glutelab_format_chf( $order['amount_cents'] / 100 ), $package['title'] ),
		__( 'Puoi pagare online in modo sicuro da questo link:', 'glutelab-child-theme' ) . "\n" . $link,
		sprintf( __( 'Riferimento: %s', 'glutelab-child-theme' ), $order['reference'] ),
	) );
	if ( ! wp_mail( $customer['email'], $subject, $message ) ) return new WP_Error( 'payment_reminder_mail_failed', __( 'La mail non è stata inviata.', 'glutelab-child-theme' ) );
	$now = glutelab_app_now_utc();
	$wpdb->update( glutelab_app_table( 'orders' ), array( 'status' => 'awaiting_payment', 'payment_reminder_count' => $attempt, 'payment_reminder_sent_at' => $now, 'updated_at' => $now ), array( 'id' => (int) $order_id ) );
	return true;
}

function glutelab_app_apply_booking_credit_locked( array $booking ) {
	global $wpdb;
	if ( ! empty( $booking['credits_used'] ) ) return true;
	if ( glutelab_app_credit_balance( $booking['customer_id'], $booking['package_id'] ) < 1 ) return new WP_Error( 'insufficient_credits', __( 'Il cliente non ha crediti disponibili per questo pacchetto.', 'glutelab-child-theme' ) );
	$entry = glutelab_app_add_credit_entry( array( 'customer_id' => $booking['customer_id'], 'booking_id' => $booking['id'], 'order_id' => $booking['order_id'], 'package_id' => $booking['package_id'], 'delta' => -1, 'reason' => 'booking', 'idempotency_key' => 'booking-use-' . $booking['id'], 'note' => $booking['reference'] ) );
	if ( is_wp_error( $entry ) ) return $entry;
	return false === $wpdb->update( glutelab_app_table( 'bookings' ), array( 'credits_used' => 1, 'updated_at' => glutelab_app_now_utc() ), array( 'id' => (int) $booking['id'] ) ) ? new WP_Error( 'booking_update_failed', __( 'Non è stato possibile aggiornare la prenotazione.', 'glutelab-child-theme' ) ) : true;
}

function glutelab_app_use_booking_credit( $booking_id ) {
	global $wpdb; $booking = glutelab_app_get_booking( $booking_id );
	if ( ! $booking ) return new WP_Error( 'booking_not_found', __( 'Prenotazione non trovata.', 'glutelab-child-theme' ) );
	if ( ! empty( $booking['credits_used'] ) ) return true;
	$lock_name = glutelab_app_credit_lock_name( $booking['customer_id'] );
	if ( ! $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 8)', $lock_name ) ) ) return new WP_Error( 'credit_locked', __( 'Il saldo lezioni è in aggiornamento. Riprova tra poco.', 'glutelab-child-theme' ) );
	$wpdb->query( 'START TRANSACTION' );
	$result = glutelab_app_apply_booking_credit_locked( glutelab_app_get_booking( $booking_id ) );
	$wpdb->query( is_wp_error( $result ) ? 'ROLLBACK' : 'COMMIT' );
	$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock_name ) );
	return $result;
}

function glutelab_app_restore_booking_credit( $booking_id ) {
	global $wpdb; $booking = glutelab_app_get_booking( $booking_id );
	if ( ! $booking || empty( $booking['credits_used'] ) ) return true;
	$lock_name = glutelab_app_credit_lock_name( $booking['customer_id'] );
	if ( ! $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 8)', $lock_name ) ) ) return new WP_Error( 'credit_locked', __( 'Il saldo lezioni è in aggiornamento. Riprova tra poco.', 'glutelab-child-theme' ) );
	$wpdb->query( 'START TRANSACTION' );
	$entry = glutelab_app_add_credit_entry( array( 'customer_id' => $booking['customer_id'], 'booking_id' => $booking['id'], 'order_id' => $booking['order_id'], 'package_id' => $booking['package_id'], 'delta' => 1, 'reason' => 'cancellation', 'idempotency_key' => 'booking-restore-' . $booking['id'], 'note' => $booking['reference'] ) );
	if ( is_wp_error( $entry ) ) $wpdb->query( 'ROLLBACK' );
	else { $wpdb->update( glutelab_app_table( 'bookings' ), array( 'credits_used' => 0, 'updated_at' => glutelab_app_now_utc() ), array( 'id' => (int) $booking_id ) ); $wpdb->query( 'COMMIT' ); }
	$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock_name ) );
	return is_wp_error( $entry ) ? $entry : true;
}

function glutelab_app_can_customer_cancel( array $booking, $now = null, $hours = 24 ) {
	if ( 'confirmed' !== sanitize_key( $booking['status'] ?? '' ) || empty( $booking['start_at_utc'] ) ) return false;
	try {
		$start = new DateTimeImmutable( $booking['start_at_utc'], new DateTimeZone( 'UTC' ) );
		$now   = $now instanceof DateTimeImmutable ? $now->setTimezone( new DateTimeZone( 'UTC' ) ) : new DateTimeImmutable( 'now', new DateTimeZone( 'UTC' ) );
		return $start >= $now->modify( '+' . max( 0, (int) $hours ) . ' hours' );
	} catch ( Exception $error ) {
		return false;
	}
}

function glutelab_app_booking_status_transition_allowed( $current, $next ) {
	$current = sanitize_key( $current );
	$next    = sanitize_key( $next );
	if ( $current === $next ) return true;
	if ( in_array( $current, array( 'completed', 'cancelled', 'no_show' ), true ) ) return false;
	return in_array( $next, array( 'confirmed', 'cancelled', 'completed', 'no_show' ), true );
}
