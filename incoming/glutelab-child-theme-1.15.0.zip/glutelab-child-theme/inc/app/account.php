<?php
/** Customer account, lesson credits and self-service bookings. @package GluteLabChildTheme */
if ( ! defined( 'ABSPATH' ) ) exit;

define( 'GLUTELAB_APP_CANCELLATION_HOURS', 24 );

function glutelab_app_account_url( $args = array() ) {
	$url = glutelab_page_url( 'area-clienti' );
	return $args ? add_query_arg( $args, $url ) : $url;
}

function glutelab_app_new_account_email( $email, $user, $blogname ) {
	$email['subject'] = sprintf( __( 'Il tuo account Glute Lab — %s', 'glutelab-child-theme' ), $blogname );
	$email['message'] .= "\n\n" . __( 'Dopo aver impostato la password puoi controllare i crediti e prenotare le lezioni qui:', 'glutelab-child-theme' ) . "\n" . glutelab_app_account_url();
	return $email;
}

function glutelab_app_ensure_customer_user( $customer_id, $notify = true ) {
	global $wpdb;
	$customer = glutelab_app_get_customer( $customer_id );
	if ( ! $customer ) return new WP_Error( 'customer_not_found', __( 'Cliente non trovato.', 'glutelab-child-theme' ) );
	if ( ! empty( $customer['user_id'] ) && get_userdata( (int) $customer['user_id'] ) ) return (int) $customer['user_id'];

	$user    = get_user_by( 'email', $customer['email'] );
	$created = false;
	if ( ! $user ) {
		$base = sanitize_user( strtok( $customer['email'], '@' ), true );
		if ( '' === $base ) $base = 'glutelab-cliente';
		$login = $base; $suffix = 1;
		while ( username_exists( $login ) ) { $suffix++; $login = $base . '-' . $suffix; }
		$user_id = wp_insert_user( array(
			'user_login' => $login,
			'user_email' => $customer['email'],
			'user_pass' => wp_generate_password( 24, true, true ),
			'display_name' => trim( $customer['first_name'] . ' ' . $customer['last_name'] ),
			'first_name' => $customer['first_name'],
			'last_name' => $customer['last_name'],
			'role' => 'subscriber',
		) );
		if ( is_wp_error( $user_id ) ) return $user_id;
		$user = get_userdata( $user_id ); $created = true;
	}
	if ( ! $user ) return new WP_Error( 'account_write_failed', __( 'Non è stato possibile creare l’account.', 'glutelab-child-theme' ) );
	if ( is_multisite() && ! is_user_member_of_blog( $user->ID, get_current_blog_id() ) ) add_user_to_blog( get_current_blog_id(), $user->ID, 'subscriber' );
	$updated = $wpdb->update( glutelab_app_table( 'customers' ), array( 'user_id' => (int) $user->ID, 'updated_at' => glutelab_app_now_utc() ), array( 'id' => (int) $customer_id ) );
	if ( false === $updated ) return new WP_Error( 'account_link_failed', __( 'Non è stato possibile collegare l’account.', 'glutelab-child-theme' ) );
	if ( $created && $notify ) {
		add_filter( 'wp_new_user_notification_email', 'glutelab_app_new_account_email', 10, 3 );
		wp_send_new_user_notifications( $user->ID, 'user' );
		remove_filter( 'wp_new_user_notification_email', 'glutelab_app_new_account_email', 10 );
	}
	return (int) $user->ID;
}

function glutelab_app_customer_for_user( $user_id = 0 ) {
	global $wpdb;
	$user_id = $user_id ? absint( $user_id ) : get_current_user_id();
	if ( ! $user_id ) return null;
	$customer = glutelab_app_get_customer_by_user( $user_id );
	if ( $customer ) return $customer;
	$user = get_userdata( $user_id );
	if ( ! $user || ! is_email( $user->user_email ) ) return null;
	$table = glutelab_app_table( 'customers' );
	$customer = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE email = %s AND (user_id IS NULL OR user_id = 0 OR user_id = %d) LIMIT 1", $user->user_email, $user_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	if ( ! $customer ) return null;
	$wpdb->update( $table, array( 'user_id' => $user_id, 'updated_at' => glutelab_app_now_utc() ), array( 'id' => (int) $customer['id'] ) );
	$customer['user_id'] = $user_id;
	return $customer;
}

/** Customer accounts stay in the branded frontend and never expose wp-admin chrome. */
function glutelab_app_is_customer_user( $user_id = 0 ) {
	$user_id = $user_id ? absint( $user_id ) : get_current_user_id();
	return $user_id && ! user_can( $user_id, glutelab_app_management_capability() ) && (bool) glutelab_app_customer_for_user( $user_id );
}

function glutelab_app_customer_admin_bar( $show ) {
	return glutelab_app_is_customer_user() ? false : $show;
}
add_filter( 'show_admin_bar', 'glutelab_app_customer_admin_bar' );

function glutelab_app_customer_admin_redirect() {
	if ( ! glutelab_app_is_customer_user() || wp_doing_ajax() ) return;
	global $pagenow;
	if ( in_array( $pagenow, array( 'admin-post.php', 'async-upload.php' ), true ) ) return;
	wp_safe_redirect( glutelab_app_account_url() );
	exit;
}
add_action( 'admin_init', 'glutelab_app_customer_admin_redirect', 2 );

function glutelab_app_customer_orders( $customer_id ) {
	global $wpdb; $table = glutelab_app_table( 'orders' );
	return (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE customer_id = %d ORDER BY id DESC", (int) $customer_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
}

function glutelab_app_customer_bookings( $customer_id ) {
	global $wpdb; $table = glutelab_app_table( 'bookings' );
	return (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE customer_id = %d ORDER BY COALESCE(start_at_utc, created_at) DESC, id DESC", (int) $customer_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
}

function glutelab_app_customer_credit_packages( $customer_id ) {
	global $wpdb; $orders = glutelab_app_table( 'orders' );
	$package_ids = (array) $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT package_id FROM {$orders} WHERE customer_id = %d AND status = 'paid' ORDER BY package_id", (int) $customer_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	$result = array();
	foreach ( $package_ids as $package_id ) {
		$package = glutelab_get_package( $package_id );
		if ( ! $package ) continue;
		$package['credit_balance'] = glutelab_app_credit_balance( $customer_id, $package_id );
		$result[] = $package;
	}
	return $result;
}

function glutelab_app_latest_paid_order_id( $customer_id, $package_id ) {
	global $wpdb; $table = glutelab_app_table( 'orders' );
	return (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE customer_id = %d AND package_id = %s AND status = 'paid' ORDER BY paid_at DESC, id DESC LIMIT 1", (int) $customer_id, sanitize_key( $package_id ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
}

function glutelab_app_create_customer_booking( $user_id, $package_id, $date, $slot_value ) {
	global $wpdb;
	$customer = glutelab_app_customer_for_user( $user_id );
	$package_id = sanitize_key( $package_id ); $date = sanitize_text_field( $date ); $slot_value = sanitize_text_field( $slot_value );
	$package = glutelab_get_package( $package_id );
	if ( ! $customer || ! $package || 'active' !== ( $package['status'] ?? '' ) || empty( $package['session_minutes'] ) ) return new WP_Error( 'invalid_package', __( 'Questo pacchetto non è disponibile per la prenotazione.', 'glutelab-child-theme' ) );
	$order_id = glutelab_app_latest_paid_order_id( $customer['id'], $package_id );
	if ( ! $order_id ) return new WP_Error( 'package_not_owned', __( 'Non risulta un acquisto pagato per questo pacchetto.', 'glutelab-child-theme' ) );
	$selected = null;
	foreach ( glutelab_app_filter_available_slots( glutelab_app_slots_for_date( $date, $package ), $package ) as $slot ) {
		if ( hash_equals( $slot['utc'] . '|' . $slot['end_utc'], $slot_value ) ) { $selected = $slot; break; }
	}
	if ( ! $selected ) return new WP_Error( 'slot_unavailable', __( 'L’orario scelto non è più disponibile.', 'glutelab-child-theme' ) );

	$service     = sanitize_key( $package['group_id'] ?? $package_id );
	$credit_lock = glutelab_app_credit_lock_name( $customer['id'] );
	$slot_lock   = 'glutelab-service-' . get_current_blog_id() . '-' . md5( $service );
	if ( ! $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 8)', $credit_lock ) ) ) return new WP_Error( 'credit_locked', __( 'Il saldo lezioni è in aggiornamento. Riprova tra poco.', 'glutelab-child-theme' ) );
	if ( ! $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 8)', $slot_lock ) ) ) { $wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $credit_lock ) ); return new WP_Error( 'slot_locked', __( 'L’orario è in aggiornamento. Riprova tra poco.', 'glutelab-child-theme' ) ); }
	$wpdb->query( 'START TRANSACTION' );
	try {
		if ( glutelab_app_credit_balance( $customer['id'], $package_id ) < 1 ) throw new RuntimeException( 'insufficient_credits' );
		$bookings_table = glutelab_app_table( 'bookings' );
		$overlapping = (array) $wpdb->get_results( $wpdb->prepare( "SELECT start_at_utc, end_at_utc, seats FROM {$bookings_table} WHERE service_key = %s AND start_at_utc < %s AND end_at_utc > %s AND status IN ('pending','requested','confirmed','paid') AND (status <> 'pending' OR expires_at IS NULL OR expires_at > UTC_TIMESTAMP())", $service, $selected['end_utc'], $selected['utc'] ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( glutelab_app_interval_peak_seats( $overlapping, $selected['utc'], $selected['end_utc'] ) + 1 > glutelab_app_slot_capacity( $package ) ) throw new RuntimeException( 'slot_unavailable' );
		$now = glutelab_app_now_utc();
		$row = array( 'reference' => glutelab_app_reference( 'PREN' ), 'customer_id' => (int) $customer['id'], 'package_id' => $package_id, 'service_key' => $service, 'order_id' => $order_id, 'preferred_date' => $date, 'start_at_utc' => $selected['utc'], 'end_at_utc' => $selected['end_utc'], 'seats' => 1, 'status' => 'confirmed', 'credits_used' => 1, 'notes' => '', 'expires_at' => null, 'created_at' => $now, 'updated_at' => $now );
		if ( ! $wpdb->insert( $bookings_table, $row ) ) throw new RuntimeException( 'booking_write_failed' );
		$row['id'] = (int) $wpdb->insert_id;
		$entry = glutelab_app_add_credit_entry( array( 'customer_id' => $customer['id'], 'order_id' => $order_id, 'booking_id' => $row['id'], 'package_id' => $package_id, 'delta' => -1, 'reason' => 'booking', 'idempotency_key' => 'booking-use-' . $row['id'], 'note' => $row['reference'] ) );
		if ( is_wp_error( $entry ) ) throw new RuntimeException( $entry->get_error_code() );
		$wpdb->query( 'COMMIT' ); $result = $row;
	} catch ( Throwable $error ) {
		$wpdb->query( 'ROLLBACK' );
		$messages = array( 'insufficient_credits' => __( 'Non hai crediti disponibili per questo pacchetto.', 'glutelab-child-theme' ), 'slot_unavailable' => __( 'L’orario scelto non è più disponibile.', 'glutelab-child-theme' ) );
		$result = new WP_Error( $error->getMessage(), $messages[ $error->getMessage() ] ?? __( 'Non è stato possibile creare la prenotazione.', 'glutelab-child-theme' ) );
	}
	$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $slot_lock ) );
	$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $credit_lock ) );
	return $result;
}

function glutelab_app_cancel_customer_booking( $user_id, $booking_id ) {
	global $wpdb;
	$customer = glutelab_app_customer_for_user( $user_id ); $booking = glutelab_app_get_booking( $booking_id );
	if ( ! $customer || ! $booking || (int) $booking['customer_id'] !== (int) $customer['id'] ) return new WP_Error( 'booking_not_found', __( 'Prenotazione non trovata.', 'glutelab-child-theme' ) );
	if ( ! glutelab_app_can_customer_cancel( $booking, null, GLUTELAB_APP_CANCELLATION_HOURS ) ) return new WP_Error( 'cancellation_closed', __( 'Questa lezione non può più essere annullata online perché mancano meno di 24 ore.', 'glutelab-child-theme' ) );
	$lock_name = glutelab_app_credit_lock_name( $customer['id'] );
	if ( ! $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 8)', $lock_name ) ) ) return new WP_Error( 'credit_locked', __( 'Il saldo lezioni è in aggiornamento. Riprova tra poco.', 'glutelab-child-theme' ) );
	$wpdb->query( 'START TRANSACTION' );
	$entry = glutelab_app_add_credit_entry( array( 'customer_id' => $customer['id'], 'order_id' => $booking['order_id'], 'booking_id' => $booking['id'], 'package_id' => $booking['package_id'], 'delta' => 1, 'reason' => 'cancellation', 'idempotency_key' => 'booking-restore-' . $booking['id'], 'note' => $booking['reference'] ) );
	if ( is_wp_error( $entry ) ) { $wpdb->query( 'ROLLBACK' ); $result = $entry; }
	else {
		$updated = $wpdb->update( glutelab_app_table( 'bookings' ), array( 'status' => 'cancelled', 'credits_used' => 0, 'updated_at' => glutelab_app_now_utc() ), array( 'id' => (int) $booking['id'], 'customer_id' => (int) $customer['id'], 'status' => 'confirmed' ) );
		if ( 1 !== $updated ) { $wpdb->query( 'ROLLBACK' ); $result = new WP_Error( 'booking_update_failed', __( 'La prenotazione è già stata modificata.', 'glutelab-child-theme' ) ); }
		else { $wpdb->query( 'COMMIT' ); $result = true; }
	}
	$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock_name ) );
	return $result;
}

function glutelab_app_account_result_message( $code ) {
	$messages = array(
		'booked' => __( 'Lezione prenotata. Un credito è stato utilizzato.', 'glutelab-child-theme' ),
		'cancelled' => __( 'Lezione annullata. Il credito è stato restituito.', 'glutelab-child-theme' ),
		'insufficient_credits' => __( 'Non hai crediti disponibili per questo pacchetto.', 'glutelab-child-theme' ),
		'slot_unavailable' => __( 'L’orario scelto non è più disponibile. Scegline un altro.', 'glutelab-child-theme' ),
		'cancellation_closed' => __( 'Mancano meno di 24 ore: per questa lezione devi contattare direttamente Glute Lab.', 'glutelab-child-theme' ),
	);
	return $messages[ sanitize_key( $code ) ] ?? __( 'Non è stato possibile completare l’operazione. Riprova.', 'glutelab-child-theme' );
}

function glutelab_app_render_account_page() {
	$result = sanitize_key( wp_unslash( $_GET['gl_account_result'] ?? '' ) );
	?>
	<header class="gl-page-hero gl-account-hero"><div class="gl-shell"><p class="gl-kicker"><?php esc_html_e( 'GLUTE LAB — AREA CLIENTE', 'glutelab-child-theme' ); ?></p><h1><?php esc_html_e( 'Le tue lezioni', 'glutelab-child-theme' ); ?></h1><p><?php esc_html_e( 'Controlla i crediti, prenota la prossima lezione e gestisci i tuoi appuntamenti.', 'glutelab-child-theme' ); ?></p></div></header>
	<section class="gl-section gl-account"><div class="gl-shell">
	<?php if ( $result ) : ?><div class="gl-booking-notice <?php echo in_array( $result, array( 'booked', 'cancelled' ), true ) ? 'is-success' : 'is-warning'; ?>" role="status"><strong><?php echo esc_html( glutelab_app_account_result_message( $result ) ); ?></strong></div><?php endif; ?>
	<?php if ( ! is_user_logged_in() ) : ?>
		<div class="gl-account-login"><p class="gl-kicker"><?php esc_html_e( 'ACCESSO CLIENTE', 'glutelab-child-theme' ); ?></p><h2><?php esc_html_e( 'Accedi al tuo account', 'glutelab-child-theme' ); ?></h2><p><?php esc_html_e( 'Dopo il primo pagamento ricevi via email il collegamento per impostare la password.', 'glutelab-child-theme' ); ?></p><div><a class="gl-button gl-button--primary" href="<?php echo esc_url( wp_login_url( glutelab_app_account_url() ) ); ?>"><?php esc_html_e( 'Accedi', 'glutelab-child-theme' ); ?></a><a class="gl-text-link" href="<?php echo esc_url( wp_lostpassword_url( glutelab_app_account_url() ) ); ?>"><?php esc_html_e( 'Password dimenticata?', 'glutelab-child-theme' ); ?></a></div></div>
	<?php else : $customer = glutelab_app_customer_for_user(); if ( ! $customer ) : ?>
		<div class="gl-account-empty"><h2><?php esc_html_e( 'Nessun acquisto collegato', 'glutelab-child-theme' ); ?></h2><p><?php esc_html_e( 'Usa per l’acquisto la stessa email del tuo account. Se hai già pagato con un altro indirizzo, contatta Glute Lab.', 'glutelab-child-theme' ); ?></p><a class="gl-button gl-button--primary" href="<?php echo esc_url( glutelab_page_url( 'pacchetti-e-lezioni' ) ); ?>"><?php esc_html_e( 'Scopri i pacchetti', 'glutelab-child-theme' ); ?></a></div>
	<?php else :
		$packages = glutelab_app_customer_credit_packages( $customer['id'] );
		$bookings = glutelab_app_customer_bookings( $customer['id'] );
		$orders   = glutelab_app_customer_orders( $customer['id'] );
		$now      = glutelab_app_now_utc();
		$upcoming = array_values( array_filter( $bookings, static fn( $booking ) => 'confirmed' === $booking['status'] && ! empty( $booking['start_at_utc'] ) && $booking['start_at_utc'] >= $now ) );
		$history  = array_values( array_filter( $bookings, static fn( $booking ) => ! in_array( $booking['id'], array_column( $upcoming, 'id' ) ) ) );
		$total_credits = array_sum( array_map( static fn( $package ) => max( 0, (int) $package['credit_balance'] ), $packages ) );
	?>
		<div class="gl-account-toolbar"><div><p><?php echo esc_html( sprintf( __( 'Ciao %s', 'glutelab-child-theme' ), $customer['first_name'] ) ); ?></p><strong><?php echo esc_html( sprintf( _n( '%d credito disponibile', '%d crediti disponibili', $total_credits, 'glutelab-child-theme' ), $total_credits ) ); ?></strong></div><a class="gl-text-link" href="<?php echo esc_url( wp_logout_url( glutelab_app_account_url() ) ); ?>"><?php esc_html_e( 'Esci', 'glutelab-child-theme' ); ?></a></div>
		<section class="gl-account-section" aria-labelledby="gl-account-credits"><div class="gl-account-section__head"><p class="gl-kicker"><?php esc_html_e( 'SALDO', 'glutelab-child-theme' ); ?></p><h2 id="gl-account-credits"><?php esc_html_e( 'I tuoi pacchetti', 'glutelab-child-theme' ); ?></h2></div><div class="gl-account-credits"><?php foreach ( $packages as $package ) : ?><article><span><?php echo esc_html( $package['title'] ); ?></span><strong><?php echo esc_html( max( 0, (int) $package['credit_balance'] ) ); ?></strong><small><?php esc_html_e( 'lezioni disponibili', 'glutelab-child-theme' ); ?></small></article><?php endforeach; ?><?php if ( ! $packages ) : ?><p><?php esc_html_e( 'Non risultano ancora pacchetti pagati.', 'glutelab-child-theme' ); ?></p><?php endif; ?></div></section>
		<section class="gl-account-section gl-account-book" aria-labelledby="gl-account-book"><div class="gl-account-section__head"><p class="gl-kicker"><?php esc_html_e( 'PROSSIMA LEZIONE', 'glutelab-child-theme' ); ?></p><h2 id="gl-account-book"><?php esc_html_e( 'Prenota con un credito', 'glutelab-child-theme' ); ?></h2><p><?php esc_html_e( 'Scegli prima il giorno e poi uno degli orari realmente disponibili.', 'glutelab-child-theme' ); ?></p></div><div class="gl-account-book__forms">
		<?php foreach ( $packages as $package ) : if ( (int) $package['credit_balance'] < 1 || 'active' !== ( $package['status'] ?? '' ) || empty( $package['session_minutes'] ) ) continue; $dates = glutelab_app_upcoming_schedule_dates( $package ); ?>
			<form class="gl-account-booking-form" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" data-gl-account-booking><input type="hidden" name="action" value="glutelab_app_account_book"><input type="hidden" name="package_id" value="<?php echo esc_attr( $package['id'] ); ?>"><?php wp_nonce_field( 'glutelab_app_account_book' ); ?><header><div><h3><?php echo esc_html( $package['title'] ); ?></h3><p><?php echo esc_html( sprintf( __( '%1$d crediti · %2$s per lezione', 'glutelab-child-theme' ), $package['credit_balance'], glutelab_app_duration_label( $package['session_minutes'] ) ) ); ?></p></div></header><div class="gl-account-booking-form__fields"><label><?php esc_html_e( 'Giorno', 'glutelab-child-theme' ); ?><select required name="booking_date" data-gl-account-date><option value=""><?php esc_html_e( 'Scegli un giorno', 'glutelab-child-theme' ); ?></option><?php foreach ( $dates as $available_date ) : $date_object = new DateTimeImmutable( $available_date['value'], glutelab_app_timezone() ); ?><option value="<?php echo esc_attr( $available_date['value'] ); ?>"><?php echo esc_html( wp_date( 'l j F', $date_object->getTimestamp(), glutelab_app_timezone() ) ); ?></option><?php endforeach; ?></select></label><label><?php esc_html_e( 'Orario', 'glutelab-child-theme' ); ?><select required name="slot" data-gl-account-time data-package="<?php echo esc_attr( $package['id'] ); ?>" disabled><option value=""><?php esc_html_e( 'Prima scegli un giorno', 'glutelab-child-theme' ); ?></option></select></label><button class="gl-button gl-button--primary" type="submit"<?php echo $dates ? '' : ' disabled'; ?>><?php esc_html_e( 'Prenota la lezione', 'glutelab-child-theme' ); ?></button></div><p class="gl-booking-slot-status" data-gl-account-status role="status"><?php echo $dates ? '' : esc_html__( 'Nessun giorno disponibile al momento.', 'glutelab-child-theme' ); ?></p></form>
		<?php endforeach; ?>
		<?php if ( $total_credits < 1 ) : ?><div class="gl-account-empty"><h3><?php esc_html_e( 'Crediti terminati', 'glutelab-child-theme' ); ?></h3><p><?php esc_html_e( 'Acquista un nuovo pacchetto per programmare altre lezioni.', 'glutelab-child-theme' ); ?></p><a class="gl-button gl-button--primary" href="<?php echo esc_url( glutelab_page_url( 'pacchetti-e-lezioni' ) ); ?>"><?php esc_html_e( 'Acquista un pacchetto', 'glutelab-child-theme' ); ?></a></div><?php endif; ?>
		</div></section>
		<section class="gl-account-section" aria-labelledby="gl-account-upcoming"><div class="gl-account-section__head"><p class="gl-kicker"><?php esc_html_e( 'AGENDA', 'glutelab-child-theme' ); ?></p><h2 id="gl-account-upcoming"><?php esc_html_e( 'Prossime lezioni', 'glutelab-child-theme' ); ?></h2></div><div class="gl-account-lessons"><?php foreach ( $upcoming as $booking ) : $package = glutelab_get_package( $booking['package_id'] ); $can_cancel = glutelab_app_can_customer_cancel( $booking ); ?><article><div><time><?php echo esc_html( glutelab_app_booking_interval_label( $booking['start_at_utc'], $booking['end_at_utc'] ) ); ?></time><h3><?php echo esc_html( $package ? $package['title'] : $booking['package_id'] ); ?></h3><small><?php echo esc_html( $booking['reference'] ); ?></small></div><?php if ( $can_cancel ) : ?><form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" data-gl-cancel-booking><input type="hidden" name="action" value="glutelab_app_account_cancel"><input type="hidden" name="booking_id" value="<?php echo esc_attr( $booking['id'] ); ?>"><?php wp_nonce_field( 'glutelab_app_account_cancel' ); ?><button class="gl-button gl-button--secondary" type="submit"><?php esc_html_e( 'Annulla e recupera il credito', 'glutelab-child-theme' ); ?></button></form><?php else : ?><p class="gl-account-locked"><?php esc_html_e( 'Meno di 24 ore: contatta Glute Lab per qualsiasi modifica.', 'glutelab-child-theme' ); ?></p><?php endif; ?></article><?php endforeach; ?><?php if ( ! $upcoming ) : ?><p><?php esc_html_e( 'Non hai lezioni future prenotate.', 'glutelab-child-theme' ); ?></p><?php endif; ?></div></section>
		<details class="gl-account-history"><summary><?php esc_html_e( 'Storico lezioni e acquisti', 'glutelab-child-theme' ); ?></summary><div><h3><?php esc_html_e( 'Lezioni', 'glutelab-child-theme' ); ?></h3><ul><?php foreach ( array_slice( $history, 0, 20 ) as $booking ) : ?><li><span><?php echo esc_html( glutelab_app_booking_interval_label( $booking['start_at_utc'], $booking['end_at_utc'] ) ?: $booking['created_at'] ); ?></span><strong><?php echo esc_html( glutelab_app_admin_status_label( $booking['status'] ) ); ?></strong></li><?php endforeach; ?></ul><h3><?php esc_html_e( 'Acquisti', 'glutelab-child-theme' ); ?></h3><ul><?php foreach ( $orders as $order ) : $package = glutelab_get_package( $order['package_id'] ); $amount = 'paid' === $order['status'] && isset( $order['amount_paid_cents'] ) ? $order['amount_paid_cents'] : $order['amount_cents']; ?><li><span><?php echo esc_html( $package ? $package['title'] : $order['package_id'] ); ?> · <?php echo esc_html( $order['reference'] ); ?></span><strong><?php echo esc_html( glutelab_format_chf( $amount / 100 ) ); ?></strong></li><?php endforeach; ?></ul></div></details>
	<?php endif; endif; ?></div></section><?php
}
