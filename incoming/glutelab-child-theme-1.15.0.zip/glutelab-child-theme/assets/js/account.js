(() => {
  'use strict';
  if (!window.glutelabBooking) return;

  document.querySelectorAll('[data-gl-account-booking]').forEach((form) => {
    const date = form.querySelector('[data-gl-account-date]');
    const time = form.querySelector('[data-gl-account-time]');
    const status = form.querySelector('[data-gl-account-status]');
    if (!date || !time || !time.dataset.package) return;

    let controller;
    const resetTime = (message, statusMessage = '') => {
      time.replaceChildren(new Option(message, ''));
      time.disabled = true;
      if (status) status.textContent = statusMessage;
    };

    date.addEventListener('change', async () => {
      if (controller) controller.abort();
      controller = undefined;
      if (!date.value) {
        resetTime(glutelabBooking.chooseDate);
        return;
      }

      const requestController = new AbortController();
      controller = requestController;
      resetTime(glutelabBooking.loading, glutelabBooking.loading);
      try {
        const url = new URL(glutelabBooking.slotsUrl);
        url.searchParams.set('package', time.dataset.package);
        url.searchParams.set('date', date.value);
        const response = await fetch(url, {
          headers: { 'X-WP-Nonce': glutelabBooking.nonce },
          signal: requestController.signal,
        });
        if (!response.ok) throw new Error('slots');
        const data = await response.json();
        if (!data.slots || !data.slots.length) {
          resetTime(glutelabBooking.empty, glutelabBooking.empty);
          return;
        }
        time.replaceChildren(new Option(glutelabBooking.chooseTime, ''));
        data.slots.forEach((slot) => time.append(new Option(`${slot.label} · ${slot.duration_label}`, slot.value)));
        time.disabled = false;
        if (status) status.textContent = '';
      } catch (error) {
        if (error.name !== 'AbortError') resetTime(glutelabBooking.error, glutelabBooking.error);
      } finally {
        if (controller === requestController) controller = undefined;
      }
    });
  });

  document.querySelectorAll('[data-gl-cancel-booking]').forEach((form) => {
    form.addEventListener('submit', (event) => {
      if (!window.confirm(glutelabBooking.cancelConfirm)) event.preventDefault();
    });
  });
})();
