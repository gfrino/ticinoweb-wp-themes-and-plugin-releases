<?php
/**
 * Download di un'app desktop dalle release pubbliche di GitHub (es. GestABLE).
 *
 * Nella pagina (template Servizio) si indicano solo il nome dell'app e il repository delle release.
 * Il tema legge l'ultima release, sceglie da solo il file giusto per ogni sistema e mostra i pulsanti.
 * I pulsanti puntano a un indirizzo fisso del sito che rimanda al file dell'ultima versione: così il
 * link resta valido anche quando la pagina è in cache e GitHub pubblica una versione nuova.
 * Un sistema senza file nella release (oggi Windows) compare come «Presto in arrivo» e diventa
 * scaricabile da solo quando la release contiene il suo installer.
 *
 * @package ticinoWEB_Child_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const TW_APP_DL_META = '_tw_app_download';
const TW_APP_DL_TAG  = '_tw_app_download_tag';
const TW_APP_DL_CRON = 'tw_app_download_refresh';

/** Impostazioni della pagina: nome dell'app e repository `proprietario/nome`. */
function tw_app_download_settings( $post_id ) {
	$d    = (array) get_post_meta( $post_id, TW_APP_DL_META, true );
	$repo = tw_app_download_clean_repo( $d['repo'] ?? '' );
	return array(
		'repo' => $repo,
		'name' => trim( (string) ( $d['name'] ?? '' ) ),
	);
}

/** Accetta `proprietario/nome` o l'indirizzo completo di GitHub; restituisce '' se non valido. */
function tw_app_download_clean_repo( $raw ) {
	$raw = trim( (string) $raw );
	$raw = preg_replace( '#^https?://(www\.)?github\.com/#i', '', $raw );
	if ( ! preg_match( '#^([A-Za-z0-9_.-]+)/([A-Za-z0-9_.-]+?)(?:\.git)?(?:[/?\#].*)?$#', $raw, $m ) ) {
		return '';
	}
	return $m[1] . '/' . $m[2];
}

/**
 * Ultima release pubblicata (niente bozze né pre-release), con i file divisi per sistema.
 * In cache per un'ora; se GitHub non risponde si usa l'ultima lettura riuscita.
 *
 * @return array|WP_Error {tag, version, published, url, assets: {mac, mac_intel, windows}}
 */
function tw_app_download_release( $repo, $force = false ) {
	if ( ! $repo ) {
		return new WP_Error( 'tw_app_dl_repo', __( 'Repository delle release non indicato.', 'ticinoweb-child-theme' ) );
	}
	$key = 'tw_app_dl_' . md5( $repo );
	if ( ! $force ) {
		$cached = get_transient( $key );
		if ( is_array( $cached ) ) {
			return $cached;
		}
	}
	$headers = array(
		'Accept'     => 'application/vnd.github+json',
		'User-Agent' => 'ticinoweb-child-theme',
	);
	if ( defined( 'TWSS_GITHUB_TOKEN' ) && TWSS_GITHUB_TOKEN ) {
		$headers['Authorization'] = 'Bearer ' . TWSS_GITHUB_TOKEN;
	}
	$res  = wp_remote_get( 'https://api.github.com/repos/' . $repo . '/releases/latest', array( 'timeout' => 10, 'headers' => $headers ) );
	$code = is_wp_error( $res ) ? 0 : (int) wp_remote_retrieve_response_code( $res );
	$body = 200 === $code ? json_decode( wp_remote_retrieve_body( $res ), true ) : null;
	if ( ! is_array( $body ) || empty( $body['tag_name'] ) ) {
		$last = get_option( $key . '_last' );
		if ( is_array( $last ) ) {
			set_transient( $key, $last, 10 * MINUTE_IN_SECONDS );
			return $last;
		}
		return new WP_Error(
			'tw_app_dl_github',
			404 === $code
				? __( 'Su GitHub non c’è nessuna release pubblicata in questo repository (o il repository è privato).', 'ticinoweb-child-theme' )
				: __( 'GitHub non risponde in questo momento: riprova tra qualche minuto.', 'ticinoweb-child-theme' )
		);
	}
	$assets = array( 'mac' => null, 'mac_intel' => null, 'windows' => null );
	$mac_zip = null;
	foreach ( (array) ( $body['assets'] ?? array() ) as $a ) {
		$name = strtolower( (string) ( $a['name'] ?? '' ) );
		$file = array(
			'url'       => esc_url_raw( (string) ( $a['browser_download_url'] ?? '' ) ),
			'name'      => sanitize_file_name( (string) ( $a['name'] ?? '' ) ),
			'size'      => (int) ( $a['size'] ?? 0 ),
			'universal' => false !== strpos( $name, 'universal' ),
		);
		if ( ! $file['url'] || str_ends_with( $name, '.blockmap' ) ) {
			continue;
		}
		if ( preg_match( '/(arm64|universal)\.dmg$/', $name ) ) {
			$assets['mac'] = $file;
		} elseif ( str_ends_with( $name, '.dmg' ) ) {
			$assets['mac_intel'] = $file;
		} elseif ( preg_match( '/(arm64|universal)-mac\.zip$/', $name ) ) {
			$mac_zip = $file;
		} elseif ( preg_match( '/\.(exe|msi)$/', $name ) && false === strpos( $name, 'uninstall' ) ) {
			if ( ! $assets['windows'] || str_ends_with( $name, '.exe' ) ) {
				$assets['windows'] = $file;
			}
		}
	}
	if ( ! $assets['mac'] && $mac_zip ) {
		$assets['mac'] = $mac_zip;
	}
	if ( $assets['mac'] && $assets['mac']['universal'] ) {
		$assets['mac_intel'] = null; // Il file universale vale anche per i Mac Intel: un solo pulsante.
	}
	$release = array(
		'tag'       => sanitize_text_field( $body['tag_name'] ),
		'version'   => ltrim( sanitize_text_field( $body['tag_name'] ), 'vV' ),
		'published' => sanitize_text_field( (string) ( $body['published_at'] ?? '' ) ),
		'url'       => esc_url_raw( (string) ( $body['html_url'] ?? '' ) ),
		'assets'    => $assets,
	);
	set_transient( $key, $release, HOUR_IN_SECONDS );
	update_option( $key . '_last', $release, false );
	return $release;
}

/** Indirizzo fisso del sito che porta al file dell'ultima versione per quel sistema. */
function tw_app_download_link( $post_id, $platform ) {
	return add_query_arg( array( 'id' => (int) $post_id, 'os' => $platform ), rest_url( 'ticinoweb/v1/app-download' ) );
}

add_action(
	'rest_api_init',
	function () {
		register_rest_route(
			'ticinoweb/v1',
			'/app-download',
			array(
				'methods'             => 'GET',
				'permission_callback' => '__return_true',
				'args'                => array(
					'id'   => array( 'type' => 'integer', 'required' => true ),
					'os'   => array( 'type' => 'string', 'required' => true, 'enum' => array( 'mac', 'mac_intel', 'windows' ) ),
				),
				'callback'            => 'tw_app_download_redirect',
			)
		);
	}
);

/** Rimanda al file dell'ultima release; se non c'è, torna alla pagina. Mai in cache. */
function tw_app_download_redirect( WP_REST_Request $request ) {
	do_action( 'litespeed_control_set_nocache', 'tw app download redirect' );
	$post_id = (int) $request['id'];
	$target  = '';
	if ( 'publish' === get_post_status( $post_id ) && 'page' === get_post_type( $post_id ) ) {
		$s       = tw_app_download_settings( $post_id );
		$release = tw_app_download_release( $s['repo'] );
		$file    = is_array( $release ) ? ( $release['assets'][ $request['os'] ] ?? null ) : null;
		$target  = $file ? $file['url'] : get_permalink( $post_id ) . '#download';
	}
	$response = new WP_REST_Response( null, $target ? 302 : 404 );
	$response->header( 'Cache-Control', 'no-store, max-age=0' );
	$response->header( 'X-Robots-Tag', 'noindex' );
	if ( $target ) {
		$response->header( 'Location', $target );
	}
	return $response;
}

/** Ogni ora rilegge le release; se c'è una versione nuova svuota la cache delle pagine. */
add_action(
	'init',
	function () {
		if ( ! wp_next_scheduled( TW_APP_DL_CRON ) ) {
			wp_schedule_event( time() + 300, 'hourly', TW_APP_DL_CRON );
		}
	}
);
add_action( TW_APP_DL_CRON, 'tw_app_download_refresh_all' );
function tw_app_download_refresh_all() {
	$changed = false;
	$ids     = get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 'numberposts' => 20, 'fields' => 'ids', 'meta_key' => TW_APP_DL_META ) );
	foreach ( $ids as $id ) {
		$s = tw_app_download_settings( $id );
		if ( ! $s['repo'] ) {
			continue;
		}
		$release = tw_app_download_release( $s['repo'], true );
		if ( is_array( $release ) && get_post_meta( $id, TW_APP_DL_TAG, true ) !== $release['tag'] ) {
			update_post_meta( $id, TW_APP_DL_TAG, $release['tag'] );
			$changed = true;
		}
	}
	if ( $changed ) {
		// Una versione nuova è un evento raro: si svuota tutta la cache del sito, così si aggiornano anche le pagine tradotte.
		do_action( 'litespeed_purge_all', 'tw app download: new release' );
	}
}

/** Pagina con il download configurato? */
function tw_app_download_enabled( $post_id = 0 ) {
	$post_id = $post_id ? $post_id : get_queried_object_id();
	return $post_id && is_page( $post_id ) && '' !== tw_app_download_settings( $post_id )['repo'];
}

/** Dimensione leggibile, es. «96 MB». */
function tw_app_download_size( $bytes ) {
	return $bytes ? size_format( $bytes, 0 ) : '';
}

/** Simboli dei sistemi (viewBox 24). Apple: Simple Icons (CC0), come i loghi delle tecnologie. */
function tw_app_download_icon( $platform ) {
	if ( 'windows' === $platform ) {
		$svg = '<path d="M3 3h8.5v8.5H3zM12.5 3H21v8.5h-8.5zM3 12.5h8.5V21H3zM12.5 12.5H21V21h-8.5z"/>';
	} else {
		$logos = function_exists( 'tw_tech_logos' ) ? tw_tech_logos() : array();
		$svg   = isset( $logos['apple'][2] ) ? '<path d="' . esc_attr( $logos['apple'][2] ) . '"/>' : '';
	}
	return '<svg class="tw-app-download__icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="currentColor">' . $svg . '</svg>';
}

/** Sezione con i pulsanti di download (dopo l'hero della pagina Servizio). */
function tw_app_download_section( $post_id ) {
	if ( ! tw_app_download_enabled( $post_id ) ) {
		return;
	}
	$s       = tw_app_download_settings( $post_id );
	$name    = $s['name'] ? $s['name'] : get_the_title( $post_id );
	$release = tw_app_download_release( $s['repo'] );
	$assets  = is_array( $release ) ? $release['assets'] : array( 'mac' => null, 'mac_intel' => null, 'windows' => null );
	$mac     = $assets['mac'];

	$cards = array(
		array(
			'os'    => 'mac',
			'icon'  => 'mac',
			'title' => 'macOS',
			'text'  => $mac && $mac['universal']
				? __( 'Per tutti i Mac, con chip Apple o Intel. macOS 11 o successivo.', 'ticinoweb-child-theme' )
				: __( 'Per Mac con chip Apple (M1, M2, M3, M4 e successivi). macOS 11 o successivo.', 'ticinoweb-child-theme' ),
			'file'  => $mac,
			'cta'   => __( 'Scarica per Mac', 'ticinoweb-child-theme' ),
		),
	);
	if ( $assets['mac_intel'] ) {
		$cards[] = array(
			'os'    => 'mac_intel',
			'icon'  => 'mac',
			'title' => __( 'macOS Intel', 'ticinoweb-child-theme' ),
			'text'  => __( 'Per Mac con processore Intel. macOS 11 o successivo.', 'ticinoweb-child-theme' ),
			'file'  => $assets['mac_intel'],
			'cta'   => __( 'Scarica per Mac Intel', 'ticinoweb-child-theme' ),
		);
	}
	$cards[] = array(
		'os'    => 'windows',
		'icon'  => 'windows',
		'title' => 'Windows',
		'text'  => __( 'Per Windows 10 e Windows 11.', 'ticinoweb-child-theme' ),
		'file'  => $assets['windows'],
		'cta'   => __( 'Scarica per Windows', 'ticinoweb-child-theme' ),
	);

	$date = '';
	if ( is_array( $release ) && $release['published'] ) {
		$ts   = strtotime( $release['published'] );
		$date = $ts ? wp_date( 'j', $ts ) . ' ' . mb_strtolower( wp_date( 'F', $ts ) ) . ' ' . wp_date( 'Y', $ts ) : ''; // «16 novembre 2026»: giorno mese anno, mese minuscolo come si scrive in italiano (le traduzioni lo adattano).
	}
	?>
	<section id="download" class="tw-service-section tw-app-download" aria-labelledby="tw-app-download-title">
		<div class="tw-shell">
			<header class="tw-app-download__head">
				<h2 id="tw-app-download-title"><?php echo esc_html( sprintf( /* translators: %s: app name */ __( 'Scarica %s', 'ticinoweb-child-theme' ), $name ) ); ?></h2>
				<p class="tw-app-download__meta">
					<span class="tw-app-download__pill"><?php esc_html_e( 'Gratis', 'ticinoweb-child-theme' ); ?></span>
					<?php if ( is_array( $release ) ) : ?>
						<span><?php echo esc_html( sprintf( /* translators: %s: version number */ __( 'Versione %s', 'ticinoweb-child-theme' ), $release['version'] ) ); ?></span>
						<?php if ( $date ) : ?><span><?php echo esc_html( sprintf( /* translators: %s: date */ __( 'pubblicata il %s', 'ticinoweb-child-theme' ), $date ) ); ?></span><?php endif; ?>
					<?php endif; ?>
				</p>
			</header>
			<ul class="tw-app-download__grid">
				<?php foreach ( $cards as $card ) : ?>
					<li class="tw-app-download__card<?php echo $card['file'] ? '' : ' is-soon'; ?>" data-os="<?php echo esc_attr( $card['icon'] ); ?>">
						<?php echo tw_app_download_icon( $card['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<h3><?php echo esc_html( $card['title'] ); ?></h3>
						<p><?php echo esc_html( $card['text'] ); ?></p>
						<?php if ( $card['file'] ) : ?>
							<a class="tw-button tw-button--primary tw-app-download__btn" href="<?php echo esc_url( tw_app_download_link( $post_id, $card['os'] ) ); ?>" rel="nofollow"><?php echo esc_html( $card['cta'] ); ?><span class="tw-arrow" aria-hidden="true"></span></a>
							<p class="tw-app-download__file"><?php echo esc_html( trim( strtoupper( pathinfo( $card['file']['name'], PATHINFO_EXTENSION ) ) . ' · ' . tw_app_download_size( $card['file']['size'] ), ' ·' ) ); ?></p>
						<?php else : ?>
							<p class="tw-app-download__soon"><?php esc_html_e( 'Presto in arrivo', 'ticinoweb-child-theme' ); ?></p>
						<?php endif; ?>
					</li>
				<?php endforeach; ?>
			</ul>
			<p class="tw-app-download__note"><?php esc_html_e( 'L’app si aggiorna da sola: quando esce una versione nuova la scarica e la installa al riavvio.', 'ticinoweb-child-theme' ); ?></p>
		</div>
	</section>
	<script>(function(){var u=navigator.userAgent||'',o=/Macintosh|Mac OS X/.test(u)?'mac':(/Windows/.test(u)?'windows':'');if(!o)return;var c=document.querySelector('#download .tw-app-download__card[data-os="'+o+'"]');if(c)c.classList.add('is-yours');})();</script>
	<?php
}

/** CSS solo sulle pagine con il download. */
add_action(
	'wp_enqueue_scripts',
	function () {
		if ( is_singular( 'page' ) && tw_app_download_enabled() ) {
			wp_enqueue_style( 'tw-app-download', get_stylesheet_directory_uri() . '/assets/css/app-download.css', array( 'ticinoweb-child-site' ), wp_get_theme()->get( 'Version' ) );
		}
	},
	31
);

/** Dati strutturati SoftwareApplication (gratuita, sistemi disponibili, versione). */
add_action(
	'wp_head',
	function () {
		if ( ! is_singular( 'page' ) || ! tw_app_download_enabled() ) {
			return;
		}
		$id      = get_queried_object_id();
		$s       = tw_app_download_settings( $id );
		$release = tw_app_download_release( $s['repo'] );
		if ( ! is_array( $release ) ) {
			return;
		}
		$os = array();
		if ( $release['assets']['mac'] || $release['assets']['mac_intel'] ) {
			$os[] = 'macOS';
		}
		if ( $release['assets']['windows'] ) {
			$os[] = 'Windows';
		}
		$data = array(
			'@context'            => 'https://schema.org',
			'@type'               => 'SoftwareApplication',
			'name'                => $s['name'] ? $s['name'] : get_the_title( $id ),
			'url'                 => get_permalink( $id ),
			'applicationCategory' => 'BusinessApplication',
			'operatingSystem'     => implode( ', ', $os ),
			'softwareVersion'     => $release['version'],
			'offers'              => array( '@type' => 'Offer', 'price' => '0', 'priceCurrency' => 'CHF' ),
			'publisher'           => array( '@type' => 'Organization', 'name' => html_entity_decode( (string) get_option( 'tw_seo_org_name', get_bloginfo( 'name' ) ), ENT_QUOTES, 'UTF-8' ), 'url' => home_url( '/' ) ),
		);
		if ( $release['assets']['mac'] ) {
			$data['downloadUrl'] = tw_app_download_link( $id, 'mac' );
		}
		if ( has_post_thumbnail( $id ) ) {
			$data['image'] = get_the_post_thumbnail_url( $id, 'full' );
		}
		echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	},
	30
);

/** Box nell'editor della pagina: due campi e lo stato verificato con GitHub. */
add_action(
	'add_meta_boxes_page',
	function () {
		add_meta_box( 'tw-app-download', __( 'Download app desktop', 'ticinoweb-child-theme' ), 'tw_app_download_metabox', 'page', 'side' );
	}
);
function tw_app_download_metabox( $post ) {
	$s = tw_app_download_settings( $post->ID );
	$d = (array) get_post_meta( $post->ID, TW_APP_DL_META, true );
	wp_nonce_field( 'tw_app_download_save', 'tw_app_download_nonce' );
	?>
	<p><?php esc_html_e( 'Mostra i pulsanti per scaricare un’app sotto il titolo della pagina (template Servizio). Il file giusto per ogni sistema viene preso da solo dall’ultima versione pubblicata.', 'ticinoweb-child-theme' ); ?></p>
	<p><label for="tw-app-dl-name"><strong><?php esc_html_e( 'Nome dell’app', 'ticinoweb-child-theme' ); ?></strong></label><br>
		<input id="tw-app-dl-name" class="widefat" name="tw_app_download[name]" value="<?php echo esc_attr( $s['name'] ); ?>" placeholder="<?php echo esc_attr( get_the_title( $post ) ); ?>"></p>
	<p><label for="tw-app-dl-repo"><strong><?php esc_html_e( 'Repository delle release su GitHub', 'ticinoweb-child-theme' ); ?></strong></label><br>
		<input id="tw-app-dl-repo" class="widefat" name="tw_app_download[repo]" value="<?php echo esc_attr( $d['repo'] ?? '' ); ?>" placeholder="proprietario/nome-repository">
		<span class="description"><?php esc_html_e( 'Va bene anche l’indirizzo copiato da GitHub. Lascia vuoto per non mostrare i download.', 'ticinoweb-child-theme' ); ?></span></p>
	<?php
	if ( ! $s['repo'] ) {
		if ( ! empty( $d['repo'] ) ) {
			echo '<p style="color:#b32d2e">' . esc_html__( 'Il repository non è scritto bene: usa la forma proprietario/nome.', 'ticinoweb-child-theme' ) . '</p>';
		}
		return;
	}
	$release = tw_app_download_release( $s['repo'] );
	if ( is_wp_error( $release ) ) {
		echo '<p style="color:#b32d2e">' . esc_html( $release->get_error_message() ) . '</p>';
		return;
	}
	$labels = array( 'mac' => 'macOS', 'mac_intel' => 'macOS Intel', 'windows' => 'Windows' );
	echo '<p style="color:#008a20"><strong>' . esc_html( sprintf( /* translators: %s: version */ __( 'Collegato: ultima versione %s', 'ticinoweb-child-theme' ), $release['version'] ) ) . '</strong></p><ul style="margin:0">';
	foreach ( $labels as $k => $label ) {
		if ( 'mac_intel' === $k && ! $release['assets'][ $k ] ) {
			continue;
		}
		echo '<li>' . esc_html( $label ) . ': ' . esc_html( $release['assets'][ $k ] ? $release['assets'][ $k ]['name'] : __( 'presto in arrivo (nessun file nella release)', 'ticinoweb-child-theme' ) ) . '</li>';
	}
	echo '</ul>';
}
add_action(
	'save_post_page',
	function ( $id ) {
		if ( empty( $_POST['tw_app_download_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['tw_app_download_nonce'] ) ), 'tw_app_download_save' ) || ! current_user_can( 'edit_post', $id ) || wp_is_post_revision( $id ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) ) {
			return;
		}
		$raw  = (array) wp_unslash( $_POST['tw_app_download'] ?? array() ); // phpcs:ignore WordPress.Security.ValidationSanitization.InputNotSanitized
		$repo = sanitize_text_field( $raw['repo'] ?? '' );
		$name = sanitize_text_field( $raw['name'] ?? '' );
		if ( '' === $repo && '' === $name ) {
			delete_post_meta( $id, TW_APP_DL_META );
			return;
		}
		update_post_meta( $id, TW_APP_DL_META, array( 'repo' => $repo, 'name' => $name ) );
		$clean = tw_app_download_clean_repo( $repo );
		if ( $clean ) {
			$release = tw_app_download_release( $clean, true ); // Verifica subito: il box mostra l'esito dopo il salvataggio.
			if ( is_array( $release ) ) {
				update_post_meta( $id, TW_APP_DL_TAG, $release['tag'] );
			}
		}
	}
);
