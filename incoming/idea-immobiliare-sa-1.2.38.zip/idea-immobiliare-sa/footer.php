<?php
/** Shared site footer: CMS brand/contacts, native menu and property taxonomy. */
$contact = idea_immo_contact();
$cats = get_terms(array('taxonomy' => 'categoria_immobile', 'hide_empty' => true, 'number' => 12));
$cookie_url = (string) get_option('tw_privacy_policy_url', '');
if ($cookie_url === '' && function_exists('get_privacy_policy_url')) { $cookie_url = get_privacy_policy_url(); }
$logo = idea_immo_logo_url();
$logo_id = attachment_url_to_postid($logo);
?>
<footer class="idea-footer">
    <div class="idea-container idea-footer__grid">
        <div class="idea-footer__brand">
            <a class="idea-footer__brand-link" href="<?php echo esc_url(home_url('/')); ?>" rel="home">
                <?php if ($logo_id) { echo wp_get_attachment_image($logo_id, 'full', false, array('class' => 'idea-footer__logo', 'alt' => get_bloginfo('name'), 'loading' => 'lazy', 'sizes' => '180px')); } else { ?><img class="idea-footer__logo" src="<?php echo esc_url($logo); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" width="180" height="82" loading="lazy"><?php } ?>
            </a>
            <p class="idea-footer__name"><?php echo esc_html(get_bloginfo('name')); ?></p>
            <?php if (get_bloginfo('description') !== '') : ?><p class="idea-footer__description"><?php echo esc_html(get_bloginfo('description')); ?></p><?php endif; ?>
        </div>
        <?php if (has_nav_menu('primary')) : ?>
        <nav class="idea-footer__navigation" aria-labelledby="idea-footer-nav-title">
            <h2 id="idea-footer-nav-title"><?php esc_html_e('Esplora', 'idea-immobiliare-sa'); ?></h2>
            <?php
            $footer_item_id = static function ($id, $item, $args) { return !empty($args->idea_footer) ? 'idea-footer-item-' . $item->ID : $id; };
            add_filter('nav_menu_item_id', $footer_item_id, 10, 3);
            wp_nav_menu(array('theme_location' => 'primary', 'container' => false, 'menu_id' => 'idea-footer-menu', 'menu_class' => 'idea-footer__menu', 'depth' => 1, 'fallback_cb' => false, 'idea_footer' => true));
            remove_filter('nav_menu_item_id', $footer_item_id, 10);
            ?>
        </nav>
        <?php endif; ?>
        <div class="idea-footer__contact">
            <h2><?php esc_html_e('Contatti', 'idea-immobiliare-sa'); ?></h2>
            <address>
                <?php if ($contact['phone'] !== '') : ?><a class="idea-footer__phone" href="<?php echo esc_attr(idea_immo_tel_href($contact['phone'])); ?>"><?php echo esc_html($contact['phone']); ?><span class="idea-arrow" aria-hidden="true"><?php echo idea_immo_arrow(); // phpcs:ignore WordPress.Security.EscapeOutput ?></span></a><?php endif; ?>
                <?php if ($contact['email'] !== '') : ?><a class="idea-footer__email" href="mailto:<?php echo esc_attr($contact['email']); ?>"><?php echo esc_html($contact['email']); ?></a><?php endif; ?>
                <?php if ($contact['address'] !== '') : ?><p class="idea-footer__address"><?php echo nl2br(esc_html($contact['address'])); ?></p><?php endif; ?>
                <?php if ($contact['hours'] !== '') : ?><p class="idea-footer__hours"><?php echo nl2br(esc_html($contact['hours'])); ?></p><?php endif; ?>
            </address>
            <?php $socials = idea_immo_socials(); if ($socials) : ?>
            <ul class="idea-footer__social" aria-label="<?php esc_attr_e('Seguici sui social', 'idea-immobiliare-sa'); ?>">
                <?php foreach ($socials as $so) : ?><li><a href="<?php echo esc_url($so['url']); ?>" target="_blank" rel="noopener" aria-label="<?php echo esc_attr($so['label']); ?>"><?php echo $so['icon']; // phpcs:ignore WordPress.Security.EscapeOutput ?></a></li><?php endforeach; ?>
            </ul>
            <?php endif; ?>
        </div>
    </div>
    <?php if ($cats && !is_wp_error($cats)) : ?>
    <nav class="idea-footer__properties" aria-labelledby="idea-footer-properties-title">
        <div class="idea-container idea-footer__properties-inner">
            <h2 id="idea-footer-properties-title"><?php esc_html_e('Immobili', 'idea-immobiliare-sa'); ?></h2>
            <ul><?php foreach ($cats as $cat) : $url = get_term_link($cat); if (is_wp_error($url)) { continue; } ?><li><a href="<?php echo esc_url($url); ?>"><?php echo esc_html($cat->name); ?></a></li><?php endforeach; ?></ul>
        </div>
    </nav>
    <?php endif; ?>
    <div class="idea-footer__bottom">
        <div class="idea-container">
            <span>&copy; <?php echo esc_html(wp_date('Y')); ?> <?php echo esc_html(get_bloginfo('name')); ?></span>
            <div class="idea-footer__links">
                <?php if ($cookie_url !== '') : ?><a href="<?php echo esc_url($cookie_url); ?>"><?php esc_html_e('Privacy e cookie', 'idea-immobiliare-sa'); ?></a><?php endif; ?>
                <a href="<?php echo esc_url(wp_login_url()); ?>" rel="nofollow"><?php esc_html_e('Area riservata', 'idea-immobiliare-sa'); ?></a>
                <a class="idea-footer__top" href="#main"><?php esc_html_e('Torna su', 'idea-immobiliare-sa'); ?><span aria-hidden="true">↑</span></a>
            </div>
        </div>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
