/**
 * Comparsa leggera degli elementi allo scorrimento. Senza JavaScript, o con
 * «riduci animazioni», tutto resta visibile e fermo.
 */
(function () {
  'use strict';
  if (!('IntersectionObserver' in window)) return;
  if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  var selectors = [
    '.hn-sectionhead', '.hn-service', '.hn-project-card', '.hn-about__intro', '.hn-about__layout > *',
    '.hn-contact__layout > *', '.hn-search__surface', '.hn-journal__grid > *', '.hn-faq .idea-container > *',
    '.idea-gallery', '.idea-summary', '.idea-single__text', '.idea-single__side > *',
    '.idea-results .idea-card', '.idea-section .idea-grid > .idea-card', '.idea-cats li', '.idea-section__title',
    '.idea-footer__top > *', '.az-card', '.az-hero__photo'
  ].join(',');

  var all = Array.prototype.slice.call(document.querySelectorAll(selectors)).filter(function (el) {
    // le schede del catalogo in home hanno già la loro entrata, e gli elementi del primo schermo no
    return !el.closest('.hn-catalog') && !el.closest('.hn-hero') && el.getBoundingClientRect().top > window.innerHeight * 0.9;
  });
  if (!all.length) return;

  var queue = [], timer = null;
  function flush() {
    timer = null;
    var batch = queue.splice(0, queue.length);
    batch.sort(function (a, b) { return a.getBoundingClientRect().left - b.getBoundingClientRect().left; });
    batch.forEach(function (el, i) {
      el.style.setProperty('--mo-d', Math.min(i, 4) * 70 + 'ms');
      el.classList.add('mo-in');
      window.setTimeout(function () { el.classList.add('mo-done'); el.style.removeProperty('--mo-d'); }, 1000);
    });
  }
  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (!e.isIntersecting) return;
      io.unobserve(e.target);
      queue.push(e.target);
    });
    if (queue.length && !timer) timer = window.setTimeout(flush, 30);
  }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });

  all.forEach(function (el) { el.classList.add('mo-r'); io.observe(el); });

  // rete di sicurezza: se qualcosa non fosse comparso, dopo qualche secondo si mostra comunque
  window.setTimeout(function () {
    all.forEach(function (el) { el.classList.add('mo-in', 'mo-done'); });
  }, 12000);
})();
