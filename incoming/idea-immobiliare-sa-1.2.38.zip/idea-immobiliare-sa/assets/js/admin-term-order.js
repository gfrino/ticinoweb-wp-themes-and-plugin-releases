/**
 * Elenco Zone / Categorie: trascinando le righe si cambia l'ordine sul sito.
 */
(function ($) {
  'use strict';
  var list = $('#the-list');
  if (!list.length || typeof ideaTermOrder === 'undefined') return;
  // con ricerca, ordinamento per colonna o più pagine il trascinamento sarebbe ambiguo
  var qs = window.location.search;
  if (/[?&](s|orderby|paged)=/.test(qs)) {
    $('.idea-handle').css('visibility', 'hidden');
    return;
  }
  var toast = $('<div class="idea-toast" role="status" aria-live="polite"></div>').appendTo('body');
  var timer;
  function say(msg, bad) {
    toast.text(msg).toggleClass('is-bad', !!bad).addClass('is-on');
    clearTimeout(timer);
    timer = setTimeout(function () { toast.removeClass('is-on'); }, 2200);
  }
  list.sortable({
    items: '> tr',
    handle: '.idea-handle',
    axis: 'y',
    tolerance: 'pointer',
    helper: function (e, tr) {
      var cells = tr.children();
      var helper = tr.clone();
      helper.children().each(function (i) { $(this).width(cells.eq(i).width()); });
      return helper;
    },
    update: function () {
      var ids = list.children('tr').map(function () { return this.id.replace('tag-', ''); }).get();
      $.post(ideaTermOrder.ajax, { action: 'idea_term_order', nonce: ideaTermOrder.nonce, taxonomy: ideaTermOrder.taxonomy, ids: ids })
        .done(function (r) { say(r && r.success ? ideaTermOrder.saved : ideaTermOrder.error, !(r && r.success)); })
        .fail(function () { say(ideaTermOrder.error, true); });
    }
  });
})(jQuery);
