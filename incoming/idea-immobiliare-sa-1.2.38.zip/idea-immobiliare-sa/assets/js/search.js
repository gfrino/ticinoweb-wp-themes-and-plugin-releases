/**
 * Ricerca rapida nella testata: la lente diventa un campo; scrivendo, gli immobili compaiono subito.
 * Senza JavaScript la lente non compare (il catalogo ha comunque la sua ricerca).
 */
(function () {
  'use strict';
  var root = document.querySelector('[data-idea-search]');
  if (!root || !window.ideaSearch || !window.fetch) return;
  root.classList.add('is-ready');

  var btn = root.querySelector('.idea-search-live__btn');
  var input = root.querySelector('input');
  var list = root.querySelector('.idea-search-live__list');
  var timer = null, last = '', ctrl = null, active = -1, items = [];

  function setOpen(open) {
    root.classList.toggle('is-open', open);
    btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    if (open) { setTimeout(function () { input.focus(); }, 60); }
    else { closeList(); }
  }
  function closeList() {
    list.hidden = true; list.textContent = ''; input.setAttribute('aria-expanded', 'false'); active = -1; items = [];
  }
  function mobile() { return window.matchMedia('(max-width: 960px)').matches; }

  btn.addEventListener('click', function () { setOpen(!root.classList.contains('is-open')); });
  document.addEventListener('click', function (e) {
    if (!root.contains(e.target) && !mobile()) setOpen(false);
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && root.classList.contains('is-open')) { setOpen(false); btn.focus(); }
  });

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text) n.textContent = text;
    return n;
  }

  function render(data) {
    list.textContent = '';
    items = [];
    if (!data.length) {
      var li = el('li', 'idea-search-live__empty', window.ideaSearch.empty);
      list.appendChild(li);
    }
    data.forEach(function (it, i) {
      var li = el('li', 'idea-search-live__item');
      li.setAttribute('role', 'option');
      var a = el('a');
      a.href = it.url;
      var th = el('span', 'idea-search-live__thumb');
      if (it.thumb) { var img = document.createElement('img'); img.src = it.thumb; img.alt = ''; img.width = 56; img.height = 56; img.loading = 'lazy'; th.appendChild(img); }
      var tx = el('span', 'idea-search-live__text');
      tx.appendChild(el('strong', '', it.title));
      var meta = [];
      if (it.id) meta.push('ID ' + it.id);
      if (it.location) meta.push(it.location);
      tx.appendChild(el('small', '', meta.join(' · ')));
      a.appendChild(th); a.appendChild(tx);
      if (it.price) a.appendChild(el('span', 'idea-search-live__price', it.price));
      li.appendChild(a);
      list.appendChild(li);
      items.push(a);
    });
    list.hidden = false;
    input.setAttribute('aria-expanded', 'true');
    active = -1;
  }

  function search(q) {
    if (ctrl) ctrl.abort();
    ctrl = window.AbortController ? new AbortController() : null;
    fetch(window.ideaSearch.url + (window.ideaSearch.url.indexOf('?') > -1 ? '&' : '?') + 'q=' + encodeURIComponent(q), ctrl ? { signal: ctrl.signal } : {})
      .then(function (r) { return r.json(); })
      .then(function (d) { if (q === input.value.trim()) render(d.items || []); })
      .catch(function () {});
  }

  input.addEventListener('input', function () {
    var q = input.value.trim();
    clearTimeout(timer);
    if (q.length < 2) { closeList(); last = ''; return; }
    if (q === last) return;
    last = q;
    timer = setTimeout(function () { search(q); }, 180);
  });

  input.addEventListener('keydown', function (e) {
    if (!items.length) return;
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      active = (active + (e.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length;
      items.forEach(function (a, i) { a.parentNode.classList.toggle('is-active', i === active); });
      items[active].scrollIntoView({ block: 'nearest' });
    } else if (e.key === 'Enter') {
      e.preventDefault();
      (items[active] || items[0]).click();
    }
  });
})();
