<?php
/**
 * Ricerca rapida nella testata: scrivendo ID oggetto, località, titolo, zona o categoria
 * compaiono subito gli immobili corrispondenti. Endpoint pubblico di sola lettura (GET).
 *
 * @package Idea_Immobiliare_SA
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('rest_api_init', function () {
    register_rest_route('idea/v1', '/search', array(
        'methods'             => 'GET',
        'callback'            => 'idea_immo_live_search',
        'permission_callback' => '__return_true',
        'args'                => array('q' => array('type' => 'string', 'required' => true)),
    ));
});

function idea_immo_live_search(WP_REST_Request $req)
{
    global $wpdb;
    $q = trim(preg_replace('/\s+/', ' ', sanitize_text_field((string) $req->get_param('q'))));
    if ($q === '' || (function_exists('mb_strlen') ? mb_strlen($q) : strlen($q)) < 2) {
        return new WP_REST_Response(array('items' => array()));
    }
    $words = array_slice(array_filter(explode(' ', $q)), 0, 4);
    $meta_keys = "'_idea_ref','_idea_location','_idea_address'";
    $where = array();
    foreach ($words as $w) {
        $like = '%' . $wpdb->esc_like($w) . '%';
        $where[] = $wpdb->prepare(
            "(p.post_title LIKE %s
              OR EXISTS (SELECT 1 FROM {$wpdb->postmeta} m WHERE m.post_id = p.ID AND m.meta_key IN ($meta_keys) AND m.meta_value LIKE %s)
              OR EXISTS (SELECT 1 FROM {$wpdb->term_relationships} tr
                         JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id AND tt.taxonomy IN ('zona','categoria_immobile')
                         JOIN {$wpdb->terms} t ON t.term_id = tt.term_id
                         WHERE tr.object_id = p.ID AND t.name LIKE %s))",
            $like, $like, $like
        );
    }
    $sql = "SELECT p.ID FROM {$wpdb->posts} p
            WHERE p.post_type = 'immobile' AND p.post_status = 'publish'
              AND NOT EXISTS (SELECT 1 FROM {$wpdb->postmeta} s WHERE s.post_id = p.ID AND s.meta_key = '_idea_status' AND s.meta_value = 'archivio')
              AND " . implode(' AND ', $where) . "
            ORDER BY EXISTS (SELECT 1 FROM {$wpdb->postmeta} r WHERE r.post_id = p.ID AND r.meta_key = '_idea_ref' AND r.meta_value = " . $wpdb->prepare('%s', $q) . ") DESC,
                     CAST((SELECT r2.meta_value FROM {$wpdb->postmeta} r2 WHERE r2.post_id = p.ID AND r2.meta_key = '_idea_ref' LIMIT 1) AS UNSIGNED) DESC,
                     p.post_date DESC
            LIMIT 8";
    $ids = $wpdb->get_col($sql); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- parti già preparate sopra
    $items = array();
    foreach ($ids as $id) {
        $id    = (int) $id;
        $thumb = get_the_post_thumbnail_url($id, 'thumbnail');
        $items[] = array(
            'id'       => (string) get_post_meta($id, '_idea_ref', true),
            'title'    => html_entity_decode(get_the_title($id), ENT_QUOTES, 'UTF-8'),
            'url'      => get_permalink($id),
            'location' => idea_immo_location($id),
            'price'    => idea_immo_price_label($id),
            'thumb'    => $thumb ? $thumb : '',
        );
    }
    $res = new WP_REST_Response(array('items' => $items));
    $res->header('Cache-Control', 'public, max-age=60');
    return $res;
}
