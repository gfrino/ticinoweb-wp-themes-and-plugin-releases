<?php
/**
 * Ordine di zone e categorie scelto a mano: si trascinano le righe nell'elenco
 * (Immobili → Categorie / Zone) e lo stesso ordine vale su tutto il sito.
 *
 * @package Idea_Immobiliare_SA
 */

if (!defined('ABSPATH')) {
    exit;
}

function idea_immo_ordered_taxonomies()
{
    return array('zona', 'categoria_immobile');
}

/** Elenchi di termini: prima l'ordine scelto, poi il nome (i termini senza ordine vanno in fondo). */
add_filter('terms_clauses', 'idea_immo_terms_clauses', 10, 3);
function idea_immo_terms_clauses($clauses, $taxonomies, $args)
{
    global $wpdb;
    if (count($taxonomies) !== 1 || !in_array($taxonomies[0], idea_immo_ordered_taxonomies(), true)) {
        return $clauses;
    }
    $orderby = isset($args['orderby']) ? $args['orderby'] : 'name';
    if ($orderby !== 'name' || (is_admin() && isset($_GET['orderby']))) { // phpcs:ignore WordPress.Security.NonceVerification
        return $clauses;
    }
    $clauses['join']   .= " LEFT JOIN {$wpdb->termmeta} idea_o ON (idea_o.term_id = t.term_id AND idea_o.meta_key = 'idea_order')";
    $clauses['orderby'] = 'ORDER BY COALESCE(CAST(idea_o.meta_value AS UNSIGNED), 9999) ASC, t.name';
    $clauses['order']   = 'ASC';
    return $clauses;
}

/* Elenco in bacheca: maniglia per trascinare */
foreach (idea_immo_ordered_taxonomies() as $idea_tax) {
    add_filter("manage_edit-{$idea_tax}_columns", function ($cols) {
        $new = array();
        foreach ($cols as $key => $label) {
            $new[$key] = $label;
            if ($key === 'cb') {
                $new['idea_handle'] = '';
            }
        }
        return $new;
    });
    add_filter("manage_{$idea_tax}_custom_column", function ($content, $column) {
        if ($column === 'idea_handle') {
            return '<span class="idea-handle" title="' . esc_attr__('Trascina per cambiare l’ordine', 'idea-immobiliare-sa') . '" aria-hidden="true">⠿</span>';
        }
        return $content;
    }, 10, 2);
    add_action("{$idea_tax}_pre_add_form", function () {
        echo '<p class="idea-order-hint">' . esc_html__('Per cambiare l’ordine in cui compaiono sul sito, trascina le righe dell’elenco dalla maniglia ⠿.', 'idea-immobiliare-sa') . '</p>';
    });
}

add_action('admin_enqueue_scripts', function ($hook) {
    $screen = get_current_screen();
    if ($hook !== 'edit-tags.php' || !$screen || !in_array($screen->taxonomy, idea_immo_ordered_taxonomies(), true)) {
        return;
    }
    $dir = get_stylesheet_directory();
    wp_enqueue_script('idea-term-order', get_stylesheet_directory_uri() . '/assets/js/admin-term-order.js', array('jquery', 'jquery-ui-sortable'), (string) filemtime($dir . '/assets/js/admin-term-order.js'), true);
    wp_localize_script('idea-term-order', 'ideaTermOrder', array(
        'ajax'     => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('idea_term_order'),
        'taxonomy' => $screen->taxonomy,
        'saved'    => __('Ordine salvato', 'idea-immobiliare-sa'),
        'error'    => __('Ordine non salvato, riprova.', 'idea-immobiliare-sa'),
    ));
});

add_action('wp_ajax_idea_term_order', function () {
    check_ajax_referer('idea_term_order', 'nonce');
    $tax = isset($_POST['taxonomy']) ? sanitize_key(wp_unslash($_POST['taxonomy'])) : '';
    if (!in_array($tax, idea_immo_ordered_taxonomies(), true) || !current_user_can(get_taxonomy($tax)->cap->manage_terms)) {
        wp_send_json_error(null, 403);
    }
    $ids = isset($_POST['ids']) ? array_map('absint', (array) wp_unslash($_POST['ids'])) : array();
    foreach (array_values(array_filter($ids)) as $i => $term_id) {
        $term = get_term($term_id, $tax);
        if ($term && !is_wp_error($term)) {
            update_term_meta($term_id, 'idea_order', ($i + 1) * 10);
        }
    }
    clean_taxonomy_cache($tax);
    wp_send_json_success();
});
