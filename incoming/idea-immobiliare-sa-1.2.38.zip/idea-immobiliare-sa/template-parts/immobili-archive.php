<?php
/**
 * Catalogo immobili: ricerca + griglia + paginazione.
 * Usato dall'archivio e dalle pagine zona/categoria.
 *
 * @package Idea_Immobiliare_SA
 */
$f     = idea_immo_active_filters();
$title = post_type_archive_title('', false);
if (is_tax()) {
	$title = single_term_title('', false);
}
$total = (int) $GLOBALS['wp_query']->found_posts;
?>
<?php $cats = get_terms(array('taxonomy' => 'categoria_immobile', 'hide_empty' => true)); $base = get_post_type_archive_link('immobile'); $cur = is_tax('categoria_immobile') ? get_queried_object()->slug : ''; ?>
<main id="main" class="az hn az-catalog">
	<header class="az-hero az-hero--catalog">
		<div class="idea-container">
			<?php echo ticinoweb_get_breadcrumbs(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<h1><?php echo esc_html($title ?: __('Immobili', 'idea-immobiliare-sa')); ?></h1>
			<?php if (is_tax() && term_description()) : ?><div class="az-hero__intro"><?php echo wp_kses_post(term_description()); ?></div><?php endif; ?>
		</div>
	</header>

	<section class="hn-search idea-container" id="ricerca" aria-label="<?php esc_attr_e('Cerca un immobile', 'idea-immobiliare-sa'); ?>">
		<div class="hn-search__surface">
			<div class="hn-search__top"><h2><?php esc_html_e('Trova il tuo immobile', 'idea-immobiliare-sa'); ?></h2></div>
			<?php echo idea_immo_search_form(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<?php if (!is_wp_error($cats) && $cats) : ?>
			<nav class="hn-categories" aria-label="<?php esc_attr_e('Filtra per categoria', 'idea-immobiliare-sa'); ?>">
				<a href="<?php echo esc_url($base); ?>"<?php echo $cur === '' && empty($f['categoria']) ? ' aria-current="true"' : ''; ?>><span class="hn-category-label"><?php esc_html_e('Tutti', 'idea-immobiliare-sa'); ?></span></a>
				<?php foreach ($cats as $cat) : $on = ($cur === $cat->slug) || (!empty($f['categoria']) && $f['categoria'] === $cat->slug); ?>
					<a href="<?php echo esc_url(add_query_arg('categoria', $cat->slug, $base)); ?>"<?php echo $on ? ' aria-current="true"' : ''; ?>><span class="hn-category-label"><?php echo esc_html($cat->name); ?></span></a>
				<?php endforeach; ?>
			</nav>
			<?php endif; ?>
		</div>
	</section>

<section class="idea-section">
		<div class="idea-container">
			<p class="idea-results"><?php
				echo esc_html(sprintf(_n('%d immobile trovato', '%d immobili trovati', $total, 'idea-immobiliare-sa'), $total));
				if ($f['stato'] === 'archivio') {
					echo ' · ' . esc_html__('archivio', 'idea-immobiliare-sa');
				}
			?></p>

			<?php if (have_posts()) : ?>
				<div class="idea-grid hn-property-grid">
					<?php while (have_posts()) : the_post(); get_template_part('template-parts/property-card'); endwhile; ?>
				</div>
				<?php
				the_posts_pagination(array(
					'mid_size'  => 1,
					'prev_text' => '←',
					'next_text' => '→',
					'class'     => 'idea-pagination',
				));
				?>
			<?php else : ?>
				<div class="idea-empty">
					<p><?php esc_html_e('Nessun immobile corrisponde alla ricerca.', 'idea-immobiliare-sa'); ?></p>
					<p><a class="idea-btn idea-btn--navy" href="<?php echo esc_url(get_post_type_archive_link('immobile')); ?>"><?php esc_html_e('Vedi tutti gli immobili', 'idea-immobiliare-sa'); ?></a></p>
				</div>
			<?php endif; ?>

			<p class="idea-archive-toggle">
				<?php if ($f['stato'] === 'archivio') : ?>
					<a href="<?php echo esc_url(remove_query_arg(array('stato', 'paged'))); ?>"><?php esc_html_e('← Torna agli immobili disponibili', 'idea-immobiliare-sa'); ?></a>
				<?php else : ?>
					<a href="<?php echo esc_url(add_query_arg('stato', 'archivio', remove_query_arg('paged'))); ?>"><?php esc_html_e('Vedi anche gli immobili venduti o non più disponibili', 'idea-immobiliare-sa'); ?></a>
				<?php endif; ?>
			</p>
		</div>
	</section>
</main>
