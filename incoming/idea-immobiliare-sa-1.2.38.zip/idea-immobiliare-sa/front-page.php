<?php
/**
 * Respect WordPress Settings > Reading and the selected page's native template.
 * The parent also ships front-page.php, so the child keeps only this adapter.
 *
 * @package Idea_Immobiliare_SA
 */
if (!defined('ABSPATH')) { exit; }

$template = is_page() ? get_page_template() : get_home_template();
if (!$template) { $template = get_index_template(); }
if ($template) { load_template($template); }
