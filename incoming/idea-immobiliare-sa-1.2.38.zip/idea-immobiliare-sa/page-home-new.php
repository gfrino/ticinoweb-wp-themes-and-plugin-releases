<?php
/**
 * Template Name: Home NEW
 * THESIS: la ricerca incontra l'architettura; fotografie reali, navigazione immediata.
 * OWN-WORLD: ardesia, menta, Manrope, grandi superfici fotografiche e controlli netti.
 * STORY: esplorare il territorio, trovare una proprietà, parlare con la fiduciaria.
 * FIRST VIEWPORT: hero a sinistra, progetto a destra, ricerca sovrapposta in basso.
 * FORM: vetrina immobiliare con catalogo filtrabile e lettura progressiva.
 * @package Idea_Immobiliare_SA
 */
get_header();
$slides = idea_immo_home_slides();
$category = isset($_GET['categoria']) && is_string($_GET['categoria']) ? sanitize_title(wp_unslash($_GET['categoria'])) : '';
$page_number = isset($_GET['immo_page']) && is_scalar($_GET['immo_page']) ? max(1, absint($_GET['immo_page'])) : 1;
$catalog = new WP_Query(idea_immo_home_catalog_args($category, $page_number));
$cats = get_terms(array('taxonomy' => 'categoria_immobile', 'hide_empty' => true));
$archive = get_post_type_archive_link('immobile');
$base = get_permalink();
$contact = idea_immo_contact();
?>
<main id="main" class="hn">
<section class="hn-hero" data-hn-hero aria-label="<?php esc_attr_e('Progetti in primo piano', 'idea-immobiliare-sa'); ?>" aria-roledescription="<?php esc_attr_e('carosello', 'idea-immobiliare-sa'); ?>">
    <div class="hn-hero__photos">
    <?php foreach ($slides as $i => $slide) : ?>
        <div class="hn-photo<?php echo $i === 0 ? ' is-active' : ''; ?>" data-hn-photo aria-hidden="true">
        <?php if ($slide['image']) { echo wp_get_attachment_image($slide['image'], 'idea-hero', false, array('alt' => '', 'loading' => $i === 0 ? 'eager' : 'lazy', 'fetchpriority' => $i === 0 ? 'high' : 'low', 'sizes' => '100vw')); } else { ?><img src="<?php echo esc_url($slide['url']); ?>" alt=""<?php echo $i ? ' loading="lazy"' : ' fetchpriority="high"'; ?>><?php } ?>
        </div>
    <?php endforeach; ?>
    </div>
    <div class="hn-hero__shade"></div>
    <div class="hn-ambient" aria-hidden="true"><span class="hn-orbit"></span></div>
    <div class="idea-container hn-hero__layout">
        <div class="hn-hero__copy">
            <?php if (get_bloginfo('description')) : ?><p class="hn-kicker"><?php echo esc_html(get_bloginfo('description')); ?></p><?php endif; ?>
            <?php while (have_posts()) : the_post(); the_content(); endwhile; ?>
            <a class="hn-action hn-action--mint" href="<?php echo esc_url(get_post_type_archive_link('immobile')); ?>"><?php esc_html_e('Trova il tuo immobile', 'idea-immobiliare-sa'); ?><span class="idea-arrow" aria-hidden="true"><?php echo idea_immo_arrow(); // phpcs:ignore WordPress.Security.EscapeOutput ?></span></a>
        </div>
        <div class="hn-hero__projects">
        <?php foreach ($slides as $i => $slide) : ?>
            <div class="hn-project<?php echo $i === 0 ? ' is-active' : ''; ?>" data-hn-project<?php echo $i ? ' hidden' : ''; ?>>
                <p><?php esc_html_e('In primo piano', 'idea-immobiliare-sa'); ?></p>
                <h2 data-hn-fit><?php echo esc_html($slide['title']); ?></h2>
                <?php if ($slide['desc']) : ?><p class="hn-project__desc"><?php echo esc_html($slide['desc']); ?></p><?php endif; ?>
                <?php if (!empty($slide['thumb'])) : ?><img class="hn-project__thumb" src="<?php echo esc_url($slide['thumb']); ?>" alt="" width="132" height="88" loading="lazy" decoding="async"><?php endif; ?>
                <?php if ($slide['link'] && $slide['button']) : ?><a href="<?php echo esc_url($slide['link']); ?>"><?php echo esc_html($slide['button']); ?> <span class="idea-arrow" aria-hidden="true"><?php echo idea_immo_arrow(); // phpcs:ignore WordPress.Security.EscapeOutput ?></span></a><?php endif; ?>
            </div>
        <?php endforeach; ?>
        <div class="hn-controls" data-hn-controls hidden>
            <?php if (count($slides) > 1) : ?>
            <span class="hn-controls__count"><span data-hn-current>01</span><span aria-hidden="true"> / </span><?php echo esc_html(str_pad((string) count($slides), 2, '0', STR_PAD_LEFT)); ?></span>
            <button type="button" data-hn-prev aria-label="<?php esc_attr_e('Progetto precedente', 'idea-immobiliare-sa'); ?>">←</button>
            <button type="button" data-hn-next aria-label="<?php esc_attr_e('Progetto successivo', 'idea-immobiliare-sa'); ?>">→</button>
            <?php endif; ?>
        </div>
        </div>
    </div>
</section>

<section class="hn-search idea-container" id="ricerca" aria-labelledby="hn-search-title">
    <div class="hn-search__surface">
        <div class="hn-search__top"><h2 id="hn-search-title"><?php echo esc_html(idea_immo_home_label('search_title')); ?></h2><a href="<?php echo esc_url($archive); ?>"><?php esc_html_e('Esplora il catalogo', 'idea-immobiliare-sa'); ?> <span class="idea-arrow" aria-hidden="true"><?php echo idea_immo_arrow(); // phpcs:ignore WordPress.Security.EscapeOutput ?></span></a></div>
        <?php echo idea_immo_search_form(); ?>
    </div>
</section>

<section class="hn-catalog idea-container hn-section" id="immobili" data-hn-catalog aria-labelledby="hn-catalog-title">
    <div class="hn-sectionhead"><div><h2 id="hn-catalog-title"><?php echo esc_html(idea_immo_home_label('catalog_title')); ?></h2><p><?php echo esc_html(idea_immo_home_label('catalog_intro')); ?></p></div><a class="hn-textlink" href="<?php echo esc_url($archive); ?>"><?php esc_html_e('Tutti gli immobili', 'idea-immobiliare-sa'); ?> <span class="idea-arrow" aria-hidden="true"><?php echo idea_immo_arrow(); // phpcs:ignore WordPress.Security.EscapeOutput ?></span></a></div>
    <nav class="hn-categories" aria-label="<?php esc_attr_e('Filtra per categoria', 'idea-immobiliare-sa'); ?>">
        <a data-hn-filter href="<?php echo esc_url($base . '#immobili'); ?>"<?php echo $category === '' ? ' aria-current="true"' : ''; ?>><span class="hn-category-icon" aria-hidden="true"><?php echo idea_immo_home_category_icon('all'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span><span class="hn-category-label"><?php esc_html_e('Tutti', 'idea-immobiliare-sa'); ?></span></a>
        <?php if (!is_wp_error($cats)) : foreach ($cats as $cat) : ?>
            <a data-hn-filter href="<?php echo esc_url(add_query_arg('categoria', $cat->slug, $base) . '#immobili'); ?>"<?php echo $category === $cat->slug ? ' aria-current="true"' : ''; ?>><span class="hn-category-icon" aria-hidden="true"><?php echo idea_immo_home_category_icon($cat->slug); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span><span class="hn-category-label"><?php echo esc_html($cat->name); ?></span></a>
        <?php endforeach; endif; ?>
    </nav>
    <p class="hn-result-status" role="status" aria-live="polite" data-hn-status data-loading="<?php esc_attr_e('Aggiornamento degli immobili…', 'idea-immobiliare-sa'); ?>"><?php printf(esc_html(_n('%s immobile nel catalogo', '%s immobili nel catalogo', $catalog->found_posts, 'idea-immobiliare-sa')), esc_html(number_format_i18n($catalog->found_posts))); ?></p>
    <div data-hn-results>
    <?php if ($catalog->have_posts()) : ?>
        <div class="idea-grid hn-property-grid">
        <?php while ($catalog->have_posts()) : $catalog->the_post(); get_template_part('template-parts/property-card'); endwhile; wp_reset_postdata(); ?>
        </div>
        <?php if ($catalog->max_num_pages > 1) : ?><nav class="hn-pagination" aria-label="<?php esc_attr_e('Pagine degli immobili', 'idea-immobiliare-sa'); ?>"><?php echo paginate_links(array('base' => str_replace('999999999', '%#%', add_query_arg('immo_page', 999999999, $base)), 'format' => '', 'current' => $page_number, 'total' => $catalog->max_num_pages, 'add_args' => $category ? array('categoria' => $category) : false, 'add_fragment' => '#immobili', 'prev_text' => '←', 'next_text' => '→')); ?></nav><?php endif; ?>
    <?php else : ?>
        <div class="hn-empty"><p><?php esc_html_e('Non ci sono immobili disponibili in questa categoria.', 'idea-immobiliare-sa'); ?></p><a class="hn-textlink" href="<?php echo esc_url($archive); ?>"><?php esc_html_e('Esplora tutte le proposte', 'idea-immobiliare-sa'); ?> →</a></div>
    <?php endif; ?>
    </div>
</section>

<?php $about_title = idea_immo_home_text(get_option('ticinoweb_chi_siamo_title'), 'theme:about:title'); $about_text = idea_immo_home_text(get_option('ticinoweb_chi_siamo_text'), 'theme:about:text'); $about_link = idea_immo_home_url(get_option('ticinoweb_chi_siamo_link'), 'theme:url:about'); $services = (array) get_option('ticinoweb_services', array()); ?>
<?php if ($about_title || $about_text) : ?>
<section class="hn-about hn-lit"><div class="hn-section-light" data-hn-light aria-hidden="true"></div><div class="idea-container hn-about__layout">
    <div class="hn-about__intro"><h2><?php echo esc_html($about_title); ?></h2><div><?php echo wpautop(wp_kses_post($about_text)); ?></div><?php if ($about_link) : ?><a class="hn-action hn-action--mint" href="<?php echo esc_url($about_link); ?>"><?php esc_html_e('Conosciamoci', 'idea-immobiliare-sa'); ?> <span class="idea-arrow" aria-hidden="true"><?php echo idea_immo_arrow(); // phpcs:ignore WordPress.Security.EscapeOutput ?></span></a><?php endif; ?></div>
    <?php if ($services) : ?><div class="hn-services"><?php foreach ($services as $service) : if (empty($service['title'])) { continue; } ?><div class="hn-service"><h3><?php echo esc_html(idea_immo_home_text($service['title'], 'theme:service:' . ($service['id'] ?? '') . ':title')); ?><span class="idea-arrow" aria-hidden="true"><?php echo idea_immo_arrow(); // phpcs:ignore WordPress.Security.EscapeOutput ?></span></h3><div><?php echo wpautop(wp_kses_post(idea_immo_home_text($service['description'] ?? '', 'theme:service:' . ($service['id'] ?? '') . ':description'))); ?></div></div><?php endforeach; ?></div><?php endif; ?>
</div></section>
<?php endif; ?>

<?php $promos = new WP_Query(array('post_type' => 'promozione', 'posts_per_page' => 2, 'no_found_rows' => true, 'meta_key' => '_thumbnail_id')); ?>
<?php if ($promos->have_posts()) : ?>
<section class="idea-container hn-section hn-projects"><div class="hn-sectionhead"><h2><?php echo esc_html(idea_immo_home_label('projects_title')); ?></h2><a class="hn-textlink" href="<?php echo esc_url(get_post_type_archive_link('promozione')); ?>"><?php esc_html_e('Tutte le promozioni', 'idea-immobiliare-sa'); ?> <span class="idea-arrow" aria-hidden="true"><?php echo idea_immo_arrow(); // phpcs:ignore WordPress.Security.EscapeOutput ?></span></a></div>
    <div class="hn-project-grid"><?php while ($promos->have_posts()) : $promos->the_post(); ?><article class="hn-project-card"><a href="<?php echo esc_url(idea_immo_promo_link(get_post())); ?>"><?php the_post_thumbnail('large', array('loading' => 'lazy', 'alt' => '', 'sizes' => '(max-width: 700px) 100vw, 50vw')); ?><div><h3><?php the_title(); ?></h3><span class="idea-arrow" aria-hidden="true"><?php echo idea_immo_arrow(); // phpcs:ignore WordPress.Security.EscapeOutput ?></span></div></a><p><?php echo esc_html(wp_trim_words(get_the_excerpt(), 23)); ?></p></article><?php endwhile; wp_reset_postdata(); ?></div>
</section>
<?php endif; ?>

<?php $blog = new WP_Query(array('post_type' => 'post', 'posts_per_page' => 3, 'no_found_rows' => true, 'ignore_sticky_posts' => true)); ?>
<?php if ($blog->have_posts()) : ?>
<section class="hn-journal hn-lit"><div class="hn-section-light" data-hn-light aria-hidden="true"></div><div class="idea-container hn-section"><div class="hn-sectionhead"><h2><?php echo esc_html(idea_immo_home_label('journal_title')); ?></h2><?php if (get_option('page_for_posts')) : ?><a class="hn-textlink" href="<?php echo esc_url(get_permalink(get_option('page_for_posts'))); ?>"><?php esc_html_e('Leggi il blog', 'idea-immobiliare-sa'); ?> <span class="idea-arrow" aria-hidden="true"><?php echo idea_immo_arrow(); // phpcs:ignore WordPress.Security.EscapeOutput ?></span></a><?php endif; ?></div><div class="hn-journal__grid"><?php while ($blog->have_posts()) : $blog->the_post(); ?><article><time datetime="<?php echo esc_attr(get_the_date('c')); ?>"><?php echo esc_html(get_the_date()); ?></time><h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?><span class="idea-arrow" aria-hidden="true"><?php echo idea_immo_arrow(); // phpcs:ignore WordPress.Security.EscapeOutput ?></span></a></h3><p><?php echo esc_html(wp_trim_words(get_the_excerpt(), 22)); ?></p></article><?php endwhile; wp_reset_postdata(); ?></div></div></section>
<?php endif; ?>

<?php if (function_exists('ticinoweb_faq_render')) { $faq = ticinoweb_faq_render('domande-frequenti-idea-immobiliare', array('show_title' => false)); if ($faq) : ?>
<section class="idea-container hn-section hn-faq"><h2><?php echo esc_html(idea_immo_home_label('faq_title')); ?></h2><div><?php echo $faq; ?></div></section>
<?php endif; } ?>

<section class="hn-contact hn-lit"><div class="hn-section-light" data-hn-light aria-hidden="true"></div><div class="idea-container hn-contact__layout"><div><h2><?php echo esc_html(idea_immo_home_label('contact_title')); ?></h2><p><?php echo esc_html(idea_immo_home_label('contact_text')); ?></p></div><div class="hn-contact__actions"><?php if ($contact['phone']) : ?><a class="hn-action hn-action--mint" href="<?php echo esc_attr(idea_immo_tel_href($contact['phone'])); ?>"><?php echo esc_html($contact['phone']); ?> <span class="idea-arrow" aria-hidden="true"><?php echo idea_immo_arrow(); // phpcs:ignore WordPress.Security.EscapeOutput ?></span></a><?php endif; ?><?php if ($contact['email']) : ?><a href="mailto:<?php echo esc_attr($contact['email']); ?>"><?php echo esc_html($contact['email']); ?></a><?php endif; ?></div></div></section>
</main>
<?php get_footer(); ?>
