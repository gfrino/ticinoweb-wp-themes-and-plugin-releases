<?php
/**
 * Template Name: Sostienici basato rigorosamente sulla struttura Tailwind fornita.
 */

get_header();
?>
<!-- Call to Action Section (DONAZIONI) -->
<section class="relative py-32 flex items-center justify-center text-center" id="donazioni">
    <div class="absolute inset-0 z-0">
        <!-- Background Immagine come da design Call to Action -->
        <img alt="Sostienici" class="w-full h-full object-cover grayscale" src="<?php echo esc_url(get_stylesheet_directory_uri() . '/assets/media/sostienici-banner.png'); ?>" loading="lazy" />
        <div class="absolute inset-0 bg-brand-deepblue/95"></div>
    </div>
    <div class="relative z-10 px-6 max-w-4xl mx-auto flex flex-col items-center">
        <h2 class="font-serif text-2xl md:text-5xl text-white font-bold mb-6 md:mb-8 uppercase tracking-wide drop-shadow-lg text-center magic-title">
            Sostieni la Fondazione
        </h2>
        
        <!-- Il testo donazioni con card ad alto contrasto -->
        <div class="sostienici-card bg-[#0b1d36]/85 backdrop-blur-md border border-white/20 p-8 md:p-12 rounded-2xl shadow-2xl text-white text-base md:text-lg leading-relaxed mb-10 font-normal max-w-4xl space-y-5 text-left md:text-center mx-auto" style="color: #ffffff !important; background-color: rgba(11, 29, 54, 0.88) !important;">
            <p class="text-white text-base md:text-lg leading-relaxed" style="color: #ffffff !important;">La fondazione DEMIAP svolge la sua attività grazie al sostegno di volontari e alle donazioni. Trattandosi di una Fondazione riconosciuta per la pubblica utilità, ogni offerta può essere dedotta dalle imposte.</p>
            
            <p class="text-white text-base md:text-lg leading-relaxed" style="color: #ffffff !important;">Le attività operative che agiscono direttamente sul territorio le abbiamo riunite nella <strong class="text-white font-extrabold" style="color: #ffffff !important;">Missione Operativa Svizzera Italiana (MOSI)</strong>. Si tratta di attività che contemplano sempre un aspetto di preghiera. Per questo nei vostri versamenti vi saremmo grati se indicaste <span class="inline-block bg-brand-red text-white font-extrabold px-2.5 py-0.5 rounded shadow-sm tracking-wide" style="background-color: #E7363B !important; color: #ffffff !important;">SOSTEGNO MOSI</span> come motivo del versamento.</p>
            
            <p class="text-white text-base md:text-lg leading-relaxed" style="color: #ffffff !important;">Si può donare il proprio tempo partecipando in modo concreto alle nostre attività. In questo caso <a href="<?php echo esc_url(home_url('/#contatti')); ?>" class="inline-flex items-center text-white font-extrabold underline decoration-2 decoration-brand-red underline-offset-4 hover:bg-white/20 px-2 py-0.5 rounded transition-all" style="color: #ffffff !important;">contattaci &rarr;</a> attraverso i nostri recapiti.</p>
            
            <p class="text-white text-base md:text-lg leading-relaxed" style="color: #ffffff !important;">Si può evidentemente sostenere la nostra Fondazione anche con contributi finanziari. Per questo si può utilizzare l’IBAN o il codice QR che trovate sotto.</p>
            
            <!-- Link Video ad alto contrasto: pulsanti bianchi con testo scuro e icona rossa -->
            <div class="flex flex-col md:flex-row gap-4 justify-center py-6 border-y border-white/20 my-6">
                <a href="#" class="sostienici-btn group flex items-center justify-center gap-2.5 bg-white hover:bg-brand-red text-brand-deepblue hover:text-white border-2 border-white hover:border-brand-red px-6 py-3.5 rounded-lg transition-all text-sm md:text-base font-extrabold shadow-lg" style="background-color: #ffffff !important; color: #193256 !important;">
                    <span class="material-symbols-outlined text-brand-red group-hover:text-white transition-colors text-xl" style="color: #E7363B !important;">play_circle</span>
                    <span>Fr. 1.- al giorno (MOSI)</span>
                </a>
                <a href="#" class="sostienici-btn group flex items-center justify-center gap-2.5 bg-white hover:bg-brand-red text-brand-deepblue hover:text-white border-2 border-white hover:border-brand-red px-6 py-3.5 rounded-lg transition-all text-sm md:text-base font-extrabold shadow-lg" style="background-color: #ffffff !important; color: #193256 !important;">
                    <span class="material-symbols-outlined text-brand-red group-hover:text-white transition-colors text-xl" style="color: #E7363B !important;">play_circle</span>
                    <span>Versare la tua decima</span>
                </a>
                <a href="#" class="sostienici-btn group flex items-center justify-center gap-2.5 bg-white hover:bg-brand-red text-brand-deepblue hover:text-white border-2 border-white hover:border-brand-red px-6 py-3.5 rounded-lg transition-all text-sm md:text-base font-extrabold shadow-lg" style="background-color: #ffffff !important; color: #193256 !important;">
                    <span class="material-symbols-outlined text-brand-red group-hover:text-white transition-colors text-xl" style="color: #E7363B !important;">play_circle</span>
                    <span>Lasciti o eredità</span>
                </a>
            </div>

            <p class="text-white text-base md:text-lg leading-relaxed" style="color: #ffffff !important;">Un altro modo per sostenere la Fondazione DEMIAP è l’offerta di servizi. Dovendo viaggiare spesso al nord delle Alpi, ben vengano buoni vari come per: spostamenti in treno o auto, pasti, pernottamenti, sconti vari, buoni Reka e altro ancora.</p>
            <p class="text-white text-base md:text-lg leading-relaxed" style="color: #ffffff !important;">Siamo certamente aperti anche a sponsorizzazioni che non siano lesive dell’etica cristiana.</p>
        </div>

        <!-- Box IBAN / QR -->
        <div class="bg-white text-brand-deepblue p-8 rounded-sm shadow-2xl w-full max-w-2xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8 mt-4 border-b-4 border-brand-red transform hover:scale-[1.02] transition-transform">
            <div class="flex-1 text-left">
                <h4 class="font-bold text-lg mb-2 uppercase tracking-widest text-brand-red">Coordinate Bancarie</h4>
                <p class="text-sm font-bold mb-1">Fondazione DEMIAP</p>
                <div class="bg-gray-100 p-3 mt-4 rounded-sm text-sm font-mono tracking-wider border border-gray-200 break-all">
                    [ INSERIRE IBAN DELLA FONDAZIONE ]
                </div>
            </div>
            <div class="w-32 h-32 bg-gray-100 border border-gray-300 flex flex-col items-center justify-center text-xs text-gray-400 p-2 text-center rounded-sm">
                <span class="material-symbols-outlined text-4xl mb-1">qr_code_2</span>
                [ IMMAGINE QR ]
            </div>
        </div>
</section>

<?php get_footer(); ?>
