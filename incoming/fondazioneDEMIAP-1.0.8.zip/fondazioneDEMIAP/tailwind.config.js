/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: "class",
  content: [
    "./*.php",
    "./**/*.php",
    "./js/**/*.js"
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          red: '#E7363B',
          deepblue: '#193256',
          blue: '#a7c1ff',
          dark: '#000000',
          gray: '#f5f5f5'
        }
      },
      fontFamily: {
        "serif": ["Playfair Display", "serif"],
        "sans": ["Plus Jakarta Sans", "sans-serif"]
      }
    }
  },
  plugins: [
    require('@tailwindcss/forms'),
    require('@tailwindcss/container-queries')
  ],
}
