<?php
/**
 * Template Name: Agenda basato rigorosamente sulla struttura Tailwind fornita.
 */

get_header();
?>
<!-- Agenda / Events Section (Design Scuro dal Template) -->
<section class="bg-white text-gray-900 py-24 relative bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:20px_20px] hero-highlight group/hero" id="agenda">
    <!-- Hero Highlight Layer (Interactive) -->
    <div class="absolute inset-0 z-0 bg-[radial-gradient(#1877F2_1.5px,transparent_1.5px)] [background-size:20px_20px] pointer-events-none opacity-0 group-hover/hero:opacity-15 transition-opacity duration-500"
         style="mask-image: radial-gradient(300px circle at var(--mouse-x, 0px) var(--mouse-y, 0px), black 0%, transparent 100%); -webkit-mask-image: radial-gradient(300px circle at var(--mouse-x, 0px) var(--mouse-y, 0px), black 0%, transparent 100%);">
    </div>
    <!-- Decorazione Sfondo Vettoriale (Sottile ma visibile) -->

    <div class="container mx-auto px-6 md:px-12 relative z-10">
        <div class="mb-16 max-w-4xl mx-auto text-left">
            <h2 class="font-serif text-2xl md:text-4xl tracking-widest uppercase mb-6 text-brand-red text-left magic-title">Agenda & Info Point</h2>
            <p class="text-sm md:text-base font-light leading-relaxed text-gray-600">
                In questa sezione avete la possibilità di consultare l’agenda sempre aggiornata, che raccoglie tutte le attività organizzate dalla Fondazione DEMIAP, insieme a una pagina dedicata alle ultime novità e comunicazioni. Subito dopo, vi attende una panoramica completa delle nostre iniziative: ogni attività proposta viene descritta in modo approfondito, per permettervi di coglierne sia lo spirito sia le opportunità concrete. Che sia un incontro, un evento o un progetto di sostegno, troverete tutte le informazioni necessarie per partecipare e sentirvi parte attiva della nostra Fondazione.
            </p>
        </div>

        <div class="flex flex-col md:flex-row justify-center items-stretch divide-y md:divide-y-0 md:divide-x divide-gray-200" id="notizie">
            <!-- Colonna Agenda (Embed Calendario Esterno) -->
            <div class="flex-1 p-8 text-center flex flex-col items-center justify-start w-full relative z-10">
                <span class="material-symbols-outlined text-4xl mb-4 text-brand-red">calendar_month</span>
                <h3 class="font-serif text-2xl md:text-3xl mb-6 tracking-wide text-brand-deepblue text-center">Calendario Eventi</h3>
                
                <!-- PLACEHOLDER EMBED CALENDARIO -->
                <div class="w-full min-h-[400px] bg-gray-50 border-2 border-dashed border-gray-200 rounded flex flex-col items-center justify-center gap-3 p-6 text-gray-400 relative overflow-hidden transition-colors hover:border-gray-300 hover:bg-gray-100">
                    <span class="material-symbols-outlined text-3xl opacity-60">code</span>
                    <p class="font-bold text-sm tracking-widest uppercase">Area Embed Calendario</p>
                    <p class="text-xs font-light max-w-[250px] leading-relaxed text-center">Sostituisci questo blocco con il codice iframe o javascript fornito dal tuo servizio di calendario (Google Calendar, Calendly, ecc).</p>
                    
                    <!-- 
                    INCOLLA QUI IL CODICE EMBED. Esempio:
                    <iframe src="https://..." width="100%" height="400" frameborder="0" scrolling="no"></iframe>
                    -->
                </div>
            </div>
            
            <!-- Colonna Info Point (List) -->
            <div class="flex-1 p-8 flex flex-col items-start justify-center text-left">
                <h3 class="font-serif text-xl md:text-2xl mb-6 tracking-wide uppercase text-brand-deepblue border-b border-gray-200 pb-2 w-full text-center md:text-left">Bacheca Info Point</h3>
                <ul class="text-sm font-light leading-loose text-gray-700 list-disc list-inside w-full space-y-2">
                    <li>Bollettino pro autoritas</li>
                    <li>Le comunicazioni che solitamente mando via WhatsApp</li>
                    <li>Volantini</li>
                    <li>Attività</li>
                    <li>Notizie da Berna e resoconti</li>
                    <li>Ecc.</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>
