<?php
/**
 * Template Name: Chi Siamo basato rigorosamente sulla struttura Tailwind fornita.
 */
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

get_header();
?>


<!-- Text Intro: CHI SIAMO & MISSIONE -->
<section class="py-20 bg-gray-50 border-t border-gray-200 relative bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:20px_20px] hero-highlight group/hero" id="chisiamo">
    <!-- Hero Highlight Layer (Interactive) -->
    <div class="absolute inset-0 z-0 bg-[radial-gradient(#1877F2_1.5px,transparent_1.5px)] [background-size:20px_20px] pointer-events-none opacity-0 group-hover/hero:opacity-15 transition-opacity duration-500"
         style="mask-image: radial-gradient(300px circle at var(--mouse-x, 0px) var(--mouse-y, 0px), black 0%, transparent 100%); -webkit-mask-image: radial-gradient(300px circle at var(--mouse-x, 0px) var(--mouse-y, 0px), black 0%, transparent 100%);">
    </div>
    <!-- Decorazioni Sfondo Vettoriale -->
    <div class="container mx-auto px-6 md:px-12 max-w-5xl relative z-10">
        <h2 class="font-serif text-2xl md:text-4xl text-brand-deepblue font-bold tracking-wide uppercase mb-6 md:mb-8 text-center magic-title">Chi Siamo & La Nostra Missione</h2>
        
        <!-- Box Unificato "Chi Siamo" -->
        <div class="bg-white p-6 md:p-14 mb-12 md:mb-16 shadow-sm border-t-4 border-brand-red text-gray-700 text-xs sm:text-sm md:text-base leading-relaxed text-left space-y-4 md:space-y-6 relative z-10">
            <div class="page-content">
                <?php 
                $chi_siamo_text = get_option('ticinoweb_chi_siamo_text');
                if (!empty($chi_siamo_text)) {
                    echo wpautop(esc_html($chi_siamo_text));
                } else {
                    echo '<p>Nessun testo configurato. Inserisci il testo in "ticinoWEB CMS" -> "Chi Siamo".</p>';
                }
                ?>
            </div>
        </div>

        <!-- I Nostri Responsabili -->
        <h3 class="font-serif text-2xl md:text-4xl text-brand-deepblue font-bold tracking-wide uppercase mb-8 md:mb-10 text-center magic-title">I Nostri Responsabili</h3>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16 relative z-10">
            <!-- Box Milco -->
            <div class="bg-white p-6 md:p-10 shadow-sm border-t-4 border-brand-red text-xs sm:text-sm md:text-base text-gray-700 leading-relaxed flex flex-col items-center relative z-10">
                <div class="w-40 h-40 bg-gray-100 rounded-full mb-6 shadow-inner overflow-hidden flex items-center justify-center border-4 border-white drop-shadow-md">
                    <span class="text-gray-400 text-[10px] font-bold uppercase tracking-widest text-center px-4 leading-tight">[ FOTO<br>MILCO ]</span>
                </div>
                <h4 class="font-serif text-xl md:text-2xl tracking-widest uppercase mb-3 md:mb-4 text-brand-deepblue text-center">Milco Margaroli</h4>
                <div class="w-12 h-px bg-brand-red mb-6 mx-auto"></div>
                <p class="text-left">
                    Professionista nel campo infermieristico, Milco vanta una solida esperienza sia in psichiatria che in salute pubblica. Il suo percorso lo ha portato a specializzarsi nell’assistenza sanitaria, nella gestione delle curatele e nel ruolo di job coach, offrendo supporto concreto e personalizzato a chi si trova in situazioni di fragilità. Insieme a Daniela, ha fondato e guidato la Chiesa Ticino per ben 16 anni, esperienza che ha rafforzato il suo impegno nel promuovere una comunità accogliente e inclusiva. Dal 2017, Milco fa parte attiva del gruppo di preghiera a Palazzo federale, contribuendo alla dimensione spirituale della vita pubblica. All’interno della Fondazione DEMIAP, si dedica principalmente alla pianificazione e alla gestione degli aspetti organizzativi e operativi, garantendo che ogni iniziativa sia portata avanti con efficienza, dedizione e attenzione alle persone.
                </p>
            </div>
            <!-- Box Daniela -->
            <div class="bg-white p-6 md:p-10 shadow-sm border-t-4 border-brand-red text-xs sm:text-sm md:text-base text-gray-700 leading-relaxed flex flex-col items-center relative z-10">
                <div class="w-40 h-40 bg-gray-100 rounded-full mb-6 shadow-inner overflow-hidden flex items-center justify-center border-4 border-white drop-shadow-md">
                    <span class="text-gray-400 text-[10px] font-bold uppercase tracking-widest text-center px-4 leading-tight">[ FOTO<br>DANIELA ]</span>
                </div>
                <h4 class="font-serif text-xl md:text-2xl tracking-widest uppercase mb-3 md:mb-4 text-brand-deepblue text-center">Daniela Margaroli</h4>
                <div class="w-12 h-px bg-brand-red mb-6 mx-auto"></div>
                <p class="text-left">
                    Professionista dal percorso eclettico, Daniela ha iniziato la sua carriera con una formazione in ambito commerciale, arricchita successivamente dal diploma di infermiera in psichiatria. Questa doppia competenza le ha permesso di sviluppare una visione ampia e sensibile, che mette a frutto nella sua attività quotidiana. Si occupa con dedizione della gestione delle curatele e dell’elaborazione dei piani occupazionali in collaborazione con l’ufficio dell’assistenza sociale, offrendo supporto e orientamento a chi attraversa momenti di vulnerabilità. Dal 2022, Daniela è membro attivo dell’Associazione Pro Autoritas, dove si impegna a promuovere momenti di preghiera dedicati alle persone che lavorano nell’amministrazione federale, contribuendo così al benessere spirituale all’interno delle istituzioni. Nella Fondazione DEMIAP, Daniela riveste un ruolo centrale occupandosi degli aspetti amministrativi e spirituali: coordina con passione e precisione i due principali progetti di volontariato sociale, L’Angolino e L’OrTicino. Grazie alla sua capacità organizzativa e alla sua attenzione verso le persone, garantisce che ogni iniziativa sia animata da autentico spirito di servizio, favorendo la crescita di una comunità solidale e inclusiva.
                </p>
            </div>
        </div>

        <div class="bg-brand-deepblue text-white p-8 md:p-14 rounded-sm shadow-xl text-left">
            <h3 class="font-serif text-xl md:text-3xl uppercase tracking-widest text-brand-red mb-6 md:mb-8 drop-shadow-sm text-center md:text-left magic-title">La nostra missione</h3>
            <div class="text-xs sm:text-sm md:text-lg font-medium leading-loose space-y-4 md:space-y-6 max-w-4xl mx-auto" style="color: #ffffff !important;">
                <p style="color: #ffffff !important; opacity: 0.95;">La Fondazione DEMIAP nutre il profondo desiderio che ogni individuo possa realizzare appieno il proprio potenziale, diventando così protagonista attivo del proprio benessere e promotore di quello altrui. Questo obiettivo viene perseguito con costanza in tutti gli ambiti in cui la Fondazione è presente: dalla socialità alla spiritualità, dalla politica alle istituzioni, fino all’economia.</p>
                <p style="color: #ffffff !important; opacity: 0.95;">Nel rispetto delle diverse sensibilità personali, la Fondazione integra in ogni sua iniziativa i valori cristiani che guidano le sue azioni quotidiane: sostegno reciproco, aiuto concreto, rispetto, costruttività, incoraggiamento, autenticità e responsabilità individuale. Questi principi costituiscono la base su cui si fonda ogni progetto e attività, ispirando relazioni autentiche e percorsi di crescita condivisa.</p>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>
