<?php
/**
 * Template Name: Attivita
 * Template dinamico gestito da backend (ticinoWEB CMS -> Pagina Attivita).
 * Design System: Swiss NGO High-End Editorial Presentation
 */

get_header();

$d = demiap_get_attivita_data();
?>

<style id="attivita-editorial-design-system">
/* ==========================================================================
   SWISS NGO EDITORIAL DESIGN SYSTEM FOR ATTIVITA
   Scoped strictly under .demiap-attivita-page
   ========================================================================== */

.demiap-attivita-page {
    background-color: #FFFFFF;
    color: #1E293B;
    font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    line-height: 1.7;
    padding-top: 60px;
    padding-bottom: 120px;
    position: relative;
    overflow-x: hidden;
}

/* Neutralize any animation glitches from external scripts */
.demiap-attivita-page [data-aos] {
    opacity: 1 !important;
    transform: none !important;
    transition: none !important;
    filter: none !important;
}

.demiap-attivita-container {
    max-width: 1240px;
    margin-left: auto;
    margin-right: auto;
    padding-left: 24px;
    padding-right: 24px;
}

@media (min-width: 768px) {
    .demiap-attivita-container {
        padding-left: 36px;
        padding-right: 36px;
    }
}

/* --- HERO BANNER & PAGE HEADER --- */
.attivita-hero-header {
    text-align: center;
    max-width: 860px;
    margin: 0 auto 60px auto;
}

.attivita-eyebrow {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 6px 16px;
    border-radius: 9999px;
    background: #EFF6FF;
    border: 1px solid #DBEAFE;
    color: #193256;
    font-size: 0.75rem;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.12em;
    margin-bottom: 20px;
}

.attivita-eyebrow-dot {
    width: 6px;
    height: 6px;
    border-radius: 9999px;
    background: #E7363B;
}

.attivita-main-title {
    font-family: 'Playfair Display', Georgia, serif;
    font-size: clamp(2.4rem, 4.5vw, 3.8rem);
    font-weight: 800;
    color: #193256;
    line-height: 1.15;
    text-transform: uppercase;
    letter-spacing: 0.02em;
    margin: 0 0 16px 0;
}

.attivita-main-subtitle {
    font-size: clamp(1rem, 1.5vw, 1.15rem);
    color: #475569;
    line-height: 1.65;
    margin: 0 auto;
    max-width: 680px;
}

/* --- DOUBLE-BEZEL CARDS ARCHITECTURE --- */
.attivita-card-shell {
    background: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 24px;
    box-shadow: 0 12px 35px -8px rgba(25, 50, 86, 0.06), 0 2px 6px 0 rgba(0, 0, 0, 0.02);
    margin-bottom: 48px;
    overflow: hidden;
    transition: box-shadow 0.3s ease, border-color 0.3s ease;
}
.attivita-card-shell:hover {
    box-shadow: 0 18px 45px -10px rgba(25, 50, 86, 0.09);
    border-color: #CBD5E1;
}

/* Header bar inside shell */
.attivita-shell-header {
    padding: 24px 32px;
    background: linear-gradient(180deg, #F8FAFC 0%, #FFFFFF 100%);
    border-bottom: 1px solid #F1F5F9;
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
}

.attivita-shell-category {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 0.72rem;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    color: #E7363B;
    margin-bottom: 4px;
}

.attivita-shell-category-dot {
    width: 7px;
    height: 7px;
    border-radius: 9999px;
    background: #E7363B;
}

.attivita-shell-title {
    font-family: 'Playfair Display', Georgia, serif;
    font-size: clamp(1.65rem, 2.5vw, 2.25rem);
    font-weight: 800;
    color: #193256;
    margin: 0;
    line-height: 1.25;
}

.attivita-badges-group {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 10px;
}

.attivita-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 14px;
    border-radius: 9999px;
    font-size: 0.75rem;
    font-weight: 700;
    letter-spacing: 0.02em;
    background: #F1F5F9;
    color: #1E293B;
    border: 1px solid #E2E8F0;
}
.attivita-badge.blue {
    background: #EFF6FF;
    color: #193256;
    border-color: #DBEAFE;
}
.attivita-badge.green {
    background: #F0FDF4;
    color: #15803D;
    border-color: #DCFCE7;
}

/* --- MANIFESTO & PHILOSOPHY SECTION --- */
.attivita-intro-section {
    padding: 36px 32px;
    background: #FFFFFF;
    border-bottom: 1px solid #F1F5F9;
}
@media (min-width: 768px) {
    .attivita-intro-section {
        padding: 44px 40px;
    }
}

.attivita-manifesto-quote {
    background: linear-gradient(135deg, #F8FAFC 0%, #EFF6FF 100%);
    border: 1px solid #DBEAFE;
    border-left: 6px solid #E7363B;
    border-radius: 18px;
    padding: 28px 32px;
    margin-bottom: 32px;
    position: relative;
}

.attivita-manifesto-tag {
    font-size: 0.72rem;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    color: #E7363B;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.attivita-manifesto-text {
    font-family: 'Playfair Display', Georgia, serif;
    font-size: clamp(1.2rem, 1.8vw, 1.5rem);
    font-weight: 700;
    color: #193256;
    line-height: 1.5;
    margin: 0;
}

/* 4-Pillar Grid for Vision Text */
.attivita-pillars-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: 20px;
}
@media (min-width: 768px) {
    .attivita-pillars-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}

.attivita-pillar-card {
    background: #F8FAFC;
    border: 1px solid #E2E8F0;
    border-radius: 16px;
    padding: 24px;
    display: flex;
    flex-direction: column;
    gap: 12px;
    transition: all 0.25s ease;
}
.attivita-pillar-card:hover {
    background: #FFFFFF;
    border-color: #CBD5E1;
    box-shadow: 0 6px 18px rgba(25, 50, 86, 0.05);
}

.attivita-pillar-header {
    display: flex;
    align-items: center;
    gap: 12px;
}

.attivita-pillar-icon {
    width: 36px;
    height: 36px;
    border-radius: 10px;
    background: #EFF6FF;
    border: 1px solid #DBEAFE;
    color: #193256;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.attivita-pillar-title {
    font-size: 0.85rem;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: #193256;
    margin: 0;
}

.attivita-pillar-body {
    font-size: 0.95rem;
    line-height: 1.65;
    color: #334155;
    margin: 0;
}

/* --- FLAGSHIP PROJECTS SHOWCASE --- */
.attivita-projects-section {
    padding: 40px 28px;
    background: #F8FAFC;
}
@media (min-width: 768px) {
    .attivita-projects-section {
        padding: 50px 36px;
    }
}

.attivita-section-subhead {
    text-align: center;
    max-width: 600px;
    margin: 0 auto 36px auto;
}
.attivita-section-subhead span {
    font-size: 0.72rem;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.12em;
    color: #64748B;
    display: block;
    margin-bottom: 6px;
}
.attivita-section-subhead h3 {
    font-family: 'Playfair Display', Georgia, serif;
    font-size: clamp(1.6rem, 2.2vw, 2.2rem);
    font-weight: 800;
    color: #193256;
    margin: 0;
}

/* 2-Column Responsive Grid */
.attivita-projects-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: 32px;
    max-width: 1200px;
    margin: 0 auto;
}
@media (min-width: 860px) {
    .attivita-projects-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}

/* Project Card */
.attivita-project-box {
    background: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 20px;
    box-shadow: 0 4px 20px -2px rgba(25, 50, 86, 0.04);
    display: flex;
    flex-direction: column;
    overflow: hidden;
    transition: transform 0.3s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.3s ease, border-color 0.3s ease;
}
.attivita-project-box:hover {
    transform: translateY(-4px);
    box-shadow: 0 20px 40px -10px rgba(25, 50, 86, 0.1);
    border-color: #CBD5E1;
}

/* Project Card Header */
.attivita-project-header {
    padding: 24px 28px 20px 28px;
    border-bottom: 1px solid #F1F5F9;
    display: flex;
    flex-direction: column;
    gap: 16px;
}

.attivita-project-top-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
}

.attivita-project-title-cluster {
    display: flex;
    align-items: center;
    gap: 14px;
}

.attivita-project-avatar {
    width: 48px;
    height: 48px;
    min-width: 48px;
    border-radius: 12px;
    background: #EFF6FF;
    border: 1px solid #DBEAFE;
    color: #193256;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}
.attivita-project-avatar.green {
    background: #F0FDF4;
    border-color: #DCFCE7;
    color: #15803D;
}
.attivita-project-avatar svg {
    width: 24px;
    height: 24px;
    min-width: 24px;
    max-width: 24px;
    display: block;
}

.attivita-project-kicker {
    font-size: 0.72rem;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    color: #E7363B;
    display: block;
    margin-bottom: 2px;
}

.attivita-project-name {
    font-family: 'Playfair Display', Georgia, serif;
    font-size: clamp(1.5rem, 2vw, 1.85rem);
    font-weight: 800;
    color: #193256;
    margin: 0;
    line-height: 1.2;
}

/* Location Bar */
.attivita-location-strip {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    padding: 10px 14px;
    background: #F8FAFC;
    border: 1px solid #E2E8F0;
    border-radius: 10px;
    font-size: 0.825rem;
    color: #334155;
    line-height: 1.45;
}
.attivita-location-strip svg {
    width: 16px;
    height: 16px;
    min-width: 16px;
    color: #E7363B;
    margin-top: 2px;
    flex-shrink: 0;
}
.attivita-location-strip strong {
    color: #193256;
    font-weight: 700;
}

/* Project Card Content */
.attivita-project-body {
    padding: 24px 28px;
    display: flex;
    flex-direction: column;
    gap: 20px;
    flex-grow: 1;
}

.attivita-lead-objective {
    background: #F0F7FF;
    border: 1px solid #D0E4FF;
    border-radius: 12px;
    padding: 16px 18px;
}
.attivita-lead-objective.green {
    background: #F0FDF4;
    border-color: #BBF7D0;
}

.attivita-box-label {
    font-size: 0.72rem;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: #193256;
    margin-bottom: 8px;
    display: flex;
    align-items: center;
    gap: 8px;
}
.attivita-lead-objective.green .attivita-box-label {
    color: #15803D;
}
.attivita-lead-objective p {
    font-size: 0.9rem;
    line-height: 1.6;
    color: #1E293B;
    margin: 0;
}

/* 2 Sub-Columns inside Project Card */
.attivita-subcolumns {
    display: grid;
    grid-template-columns: 1fr;
    gap: 14px;
}
@media (min-width: 600px) {
    .attivita-subcolumns {
        grid-template-columns: 1fr 1fr;
    }
}

.attivita-subcolumn {
    background: #F8FAFC;
    border: 1px solid #E2E8F0;
    border-radius: 12px;
    padding: 14px 16px;
}

.attivita-subcol-title {
    font-size: 0.72rem;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    color: #193256;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 6px;
}

/* Checklist Styles */
.attivita-check-list {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.attivita-check-item {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    font-size: 0.85rem;
    line-height: 1.5;
    color: #334155;
}

.attivita-check-icon {
    width: 18px;
    height: 18px;
    min-width: 18px;
    border-radius: 9999px;
    background: #EFF6FF;
    color: #193256;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-top: 2px;
    flex-shrink: 0;
}
.attivita-check-icon.green {
    background: #DCFCE7;
    color: #15803D;
}
.attivita-check-icon svg {
    width: 11px;
    height: 11px;
    stroke-width: 3.5;
    display: block;
}

.attivita-check-text {
    flex: 1;
}

/* Destinatari Pills */
.attivita-pills-wrap {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
}

.attivita-pill {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 12px;
    background: #F1F5F9;
    border: 1px solid #E2E8F0;
    border-radius: 8px;
    font-size: 0.8rem;
    font-weight: 600;
    color: #1E293B;
    line-height: 1.35;
}

.attivita-pill-dot {
    width: 5px;
    height: 5px;
    border-radius: 9999px;
    background: #193256;
    flex-shrink: 0;
}

/* Human Value Quote Box */
.attivita-human-value-box {
    background: #FFFBEB;
    border: 1px solid #FDE68A;
    border-radius: 12px;
    padding: 16px 18px;
}
.attivita-human-value-title {
    font-size: 0.72rem;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    color: #B45309;
    margin-bottom: 6px;
    display: flex;
    align-items: center;
    gap: 6px;
}
.attivita-human-value-box p {
    font-size: 0.85rem;
    line-height: 1.6;
    color: #78350F;
    font-style: italic;
    margin: 0;
}

/* --- TWO-COLUMN LOWER SECTION (Preghiera & Sostegno) --- */
.attivita-split-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: 32px;
    margin-bottom: 48px;
}
@media (min-width: 900px) {
    .attivita-split-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}

.attivita-split-shell {
    background: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 24px;
    box-shadow: 0 10px 30px -5px rgba(25, 50, 86, 0.05);
    padding: 32px 28px;
    display: flex;
    flex-direction: column;
}
@media (min-width: 768px) {
    .attivita-split-shell {
        padding: 40px 36px;
    }
}

.attivita-split-header {
    margin-bottom: 24px;
    border-bottom: 1px solid #F1F5F9;
    padding-bottom: 18px;
}

.attivita-split-title {
    font-family: 'Playfair Display', Georgia, serif;
    font-size: clamp(1.4rem, 2vw, 1.8rem);
    font-weight: 800;
    color: #193256;
    margin: 0;
}

.attivita-desc-prose {
    font-size: 0.925rem;
    color: #334155;
    line-height: 1.7;
    margin-bottom: 24px;
}
.attivita-desc-prose p {
    margin-bottom: 12px;
}
.attivita-desc-prose p:last-child {
    margin-bottom: 0;
}

/* Stream of 7 Initiatives (Preghiera) */
.attivita-stream {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.attivita-stream-card {
    background: #F8FAFC;
    border: 1px solid #E2E8F0;
    border-radius: 12px;
    padding: 14px 18px;
    display: flex;
    align-items: flex-start;
    gap: 14px;
    transition: all 0.2s ease;
}
.attivita-stream-card:hover {
    background: #FFFFFF;
    border-color: #CBD5E1;
    box-shadow: 0 4px 12px rgba(25, 50, 86, 0.04);
}

.attivita-stream-num {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 28px;
    height: 28px;
    border-radius: 9999px;
    background: #EFF6FF;
    border: 1px solid #DBEAFE;
    color: #193256;
    font-size: 0.75rem;
    font-weight: 800;
    flex-shrink: 0;
    margin-top: 2px;
}

.attivita-stream-content {
    flex: 1;
}

.attivita-stream-title {
    font-size: 0.85rem;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    color: #193256;
    margin: 0 0 4px 0;
}

.attivita-stream-text {
    font-size: 0.85rem;
    color: #475569;
    line-height: 1.55;
    margin: 0;
}

.attivita-link-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    margin-top: 8px;
    font-size: 0.78rem;
    font-weight: 700;
    color: #193256;
    text-decoration: underline;
    transition: color 0.2s ease;
}
.attivita-link-btn:hover {
    color: #E7363B;
}

/* Accordions (Attivita di Sostegno) */
.attivita-accordions-group {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.attivita-acc-item {
    border: 1px solid #E2E8F0;
    border-radius: 12px;
    background: #FFFFFF;
    overflow: hidden;
    transition: border-color 0.2s ease, box-shadow 0.2s ease;
}
.attivita-acc-item:hover {
    border-color: #CBD5E1;
}
.attivita-acc-item[open] {
    border-color: #94A3B8;
    box-shadow: 0 4px 14px rgba(25, 50, 86, 0.04);
}

.attivita-acc-trigger {
    padding: 16px 20px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    list-style: none;
    font-size: 0.85rem;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: #193256;
    transition: color 0.2s ease;
    user-select: none;
}
.attivita-acc-trigger::-webkit-details-marker {
    display: none;
}
.attivita-acc-trigger:hover {
    color: #E7363B;
}

.attivita-acc-icon {
    width: 22px;
    height: 22px;
    border-radius: 9999px;
    background: #F1F5F9;
    color: #64748B;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: transform 0.2s ease;
    flex-shrink: 0;
}
.attivita-acc-item[open] .attivita-acc-icon {
    transform: rotate(180deg);
    background: #EFF6FF;
    color: #193256;
}
.attivita-acc-icon svg {
    width: 12px;
    height: 12px;
    display: block;
}

.attivita-acc-body {
    padding: 0 20px 20px 20px;
    border-top: 1px solid #F1F5F9;
    padding-top: 14px;
    font-size: 0.875rem;
    color: #334155;
    line-height: 1.65;
}

.attivita-acc-subtitle {
    font-style: italic;
    font-weight: 600;
    color: #193256;
    margin-bottom: 8px;
}

.attivita-acc-highlight {
    background: #EFF6FF;
    border-left: 3px solid #193256;
    border-radius: 0 8px 8px 0;
    padding: 12px 14px;
    margin-top: 12px;
    font-size: 0.825rem;
    color: #193256;
}
.attivita-acc-highlight strong {
    display: block;
    font-size: 0.72rem;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    margin-bottom: 2px;
}

.attivita-video-cta {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 8px 16px;
    border-radius: 8px;
    background: #193256;
    color: #FFFFFF;
    font-size: 0.78rem;
    font-weight: 700;
    text-decoration: none;
    margin-top: 12px;
    transition: background-color 0.2s ease;
}
.attivita-video-cta:hover {
    background: #E7363B;
    color: #FFFFFF;
}

/* --- COLLABORATIONS SECTION --- */
.attivita-collab-section {
    background: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 24px;
    box-shadow: 0 10px 30px -5px rgba(25, 50, 86, 0.05);
    padding: 36px 32px;
    margin-bottom: 48px;
}
@media (min-width: 768px) {
    .attivita-collab-section {
        padding: 48px 40px;
    }
}

.attivita-collab-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: 20px;
    margin-top: 28px;
}
@media (min-width: 768px) {
    .attivita-collab-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}

.attivita-collab-card {
    background: #F8FAFC;
    border: 1px solid #E2E8F0;
    border-radius: 16px;
    padding: 24px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    transition: all 0.25s ease;
}
.attivita-collab-card:hover {
    background: #FFFFFF;
    border-color: #CBD5E1;
    box-shadow: 0 8px 22px rgba(25, 50, 86, 0.05);
}

.attivita-collab-name {
    font-family: 'Playfair Display', Georgia, serif;
    font-size: 1.15rem;
    font-weight: 800;
    color: #193256;
    margin: 0 0 10px 0;
    line-height: 1.35;
}

.attivita-collab-desc {
    font-size: 0.88rem;
    color: #475569;
    line-height: 1.6;
    margin: 0 0 16px 0;
}

.attivita-collab-link {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-size: 0.8rem;
    font-weight: 700;
    color: #193256;
    text-decoration: underline;
    transition: color 0.2s ease;
}
.attivita-collab-link:hover {
    color: #E7363B;
}
</style>

<div class="demiap-attivita-page" id="attivita">
    <div class="demiap-attivita-container">

        <!-- ==========================================
             PAGE HERO / INTESTAZIONE
             ========================================== -->
        <header class="attivita-hero-header">
            <div class="attivita-eyebrow">
                <span class="attivita-eyebrow-dot"></span>
                Fondazione DEMIAP • Missione sul Territorio
            </div>
            <h1 class="attivita-main-title">
                <?php echo esc_html($d['page_title']); ?>
            </h1>
            <?php if (!empty($d['page_subtitle'])): ?>
                <p class="attivita-main-subtitle">
                    <?php echo nl2br(esc_html($d['page_subtitle'])); ?>
                </p>
            <?php endif; ?>
        </header>

        <!-- ==========================================
             1. ATTIVITÀ SOCIALI (HIGH-END EDITORIAL SHOWCASE)
             ========================================== -->
        <div class="attivita-card-shell">
            
            <!-- Shell Header Bar -->
            <div class="attivita-shell-header">
                <div>
                    <div class="attivita-shell-category">
                        <span class="attivita-shell-category-dot"></span>
                        Area Solidarietà &amp; Inclusione
                    </div>
                    <h2 class="attivita-shell-title">
                        <?php echo esc_html($d['sociali_title']); ?>
                    </h2>
                </div>
                <div class="attivita-badges-group">
                    <span class="attivita-badge blue">
                        <svg width="14" height="14" style="width:14px;height:14px;min-width:14px;display:inline-block;" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
                        2 Progetti Attivi
                    </span>
                    <span class="attivita-badge green">
                        <svg width="14" height="14" style="width:14px;height:14px;min-width:14px;display:inline-block;" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                        Canton Ticino
                    </span>
                </div>
            </div>

            <!-- Vision Breakdown / Manifesto -->
            <?php
            $raw_intro = (string)$d['sociali_intro'];
            $paragraphs = array_values(array_filter(array_map('trim', explode("\n\n", $raw_intro))));
            $lead_quote = !empty($paragraphs) ? array_shift($paragraphs) : '';
            
            $pillar_titles = array(
                'Una gioia e fonte di soddisfazione',
                'Benessere & Percorso di Crescita',
                'Far emergere i talenti trascurati',
                'Relazioni autentiche e fiducia concreta'
            );
            ?>
            <div class="attivita-intro-section">
                <?php if (!empty($lead_quote)): ?>
                    <div class="attivita-manifesto-quote">
                        <div class="attivita-manifesto-tag">
                            <span class="w-2 h-2 rounded-full bg-brand-red"></span>
                            Il Nostro Principio Guida
                        </div>
                        <p class="attivita-manifesto-text">
                            “<?php echo esc_html($lead_quote); ?>”
                        </p>
                    </div>
                <?php endif; ?>

                <?php if (!empty($paragraphs)): ?>
                    <div class="attivita-pillars-grid">
                        <?php foreach ($paragraphs as $index => $para): ?>
                            <div class="attivita-pillar-card">
                                <div class="attivita-pillar-header">
                                    <div class="attivita-pillar-icon">
                                        <svg width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                                        </svg>
                                    </div>
                                    <h4 class="attivita-pillar-title">
                                        <?php echo esc_html($pillar_titles[$index] ?? ('Pilastro ' . ($index + 1))); ?>
                                    </h4>
                                </div>
                                <p class="attivita-pillar-body">
                                    <?php echo nl2br(esc_html($para)); ?>
                                </p>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Flagship Projects: L'Angolino & L'Orticino -->
            <div class="attivita-projects-section">
                <div class="attivita-section-subhead">
                    <span>Iniziative di Solidarietà sul territorio</span>
                    <h3>I Nostri Spazi di Accoglienza</h3>
                </div>

                <div class="attivita-projects-grid">
                    
                    <!-- 1. L'ANGOLINO -->
                    <div class="attivita-project-box">
                        <div class="attivita-project-header">
                            <div class="attivita-project-top-row">
                                <div class="attivita-project-title-cluster">
                                    <div class="attivita-project-avatar">
                                        <!-- Stiro / Aiuto Icon -->
                                        <svg width="24" height="24" style="width:24px;height:24px;min-width:24px;max-width:24px;display:block;" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z"/>
                                        </svg>
                                    </div>
                                    <div>
                                        <span class="attivita-project-kicker">Progetto Sociale</span>
                                        <h4 class="attivita-project-name">
                                            <?php echo esc_html($d['angolino_title']); ?>
                                        </h4>
                                    </div>
                                </div>
                                <span class="attivita-badge green">
                                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                                    Attivo
                                </span>
                            </div>

                            <div class="attivita-location-strip">
                                <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
                                </svg>
                                <div>
                                    <strong>Sede del programma:</strong> <?php echo esc_html($d['angolino_luogo']); ?>
                                </div>
                            </div>
                        </div>

                        <div class="attivita-project-body">
                            <!-- Obiettivo -->
                            <div class="attivita-lead-objective">
                                <div class="attivita-box-label">
                                    <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                                    Obiettivo del Progetto
                                </div>
                                <p><?php echo esc_html($d['angolino_obiettivo']); ?></p>
                            </div>

                            <!-- 2 Colonne: Attività + Accoglienza -->
                            <div class="attivita-subcolumns">
                                <div class="attivita-subcolumn">
                                    <div class="attivita-subcol-title">
                                        Attività Proposte
                                    </div>
                                    <?php echo demiap_render_check_list($d['angolino_attivita'], 'navy'); ?>
                                </div>

                                <div class="attivita-subcolumn">
                                    <div class="attivita-subcol-title">
                                        Accoglienza &amp; Tutor
                                    </div>
                                    <?php echo demiap_render_check_list($d['angolino_accoglienza'], 'navy'); ?>
                                </div>
                            </div>

                            <!-- Destinatari -->
                            <div>
                                <span class="text-xs font-bold uppercase tracking-wider text-brand-deepblue block mb-2">
                                    A chi è rivolto:
                                </span>
                                <?php echo demiap_render_pills($d['angolino_destinatari']); ?>
                            </div>

                            <!-- Scopi e Finalità -->
                            <div>
                                <span class="text-xs font-bold uppercase tracking-wider text-brand-deepblue block mb-2">
                                    Finalità del percorso:
                                </span>
                                <?php echo demiap_render_check_list($d['angolino_scopi'], 'green'); ?>
                            </div>

                            <!-- Valore Umano -->
                            <?php if (!empty($d['angolino_conclusioni'])): ?>
                                <div class="attivita-human-value-box">
                                    <div class="attivita-human-value-title">
                                        Il Valore del Progetto:
                                    </div>
                                    <p>“<?php echo esc_html($d['angolino_conclusioni']); ?>”</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- 2. L'ORTICINO -->
                    <div class="attivita-project-box">
                        <div class="attivita-project-header">
                            <div class="attivita-project-top-row">
                                <div class="attivita-project-title-cluster">
                                    <div class="attivita-project-avatar green">
                                        <!-- Sprout / Natura Icon -->
                                        <svg width="24" height="24" style="width:24px;height:24px;min-width:24px;max-width:24px;display:block;" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
                                        </svg>
                                    </div>
                                    <div>
                                        <span class="attivita-project-kicker">Progetto Sociale</span>
                                        <h4 class="attivita-project-name">
                                            <?php echo esc_html($d['orticino_title']); ?>
                                        </h4>
                                    </div>
                                </div>
                                <span class="attivita-badge green">
                                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                                    Attivo
                                </span>
                            </div>

                            <div class="attivita-location-strip">
                                <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
                                </svg>
                                <div>
                                    <strong>Sede del programma:</strong> <?php echo esc_html($d['orticino_luogo']); ?>
                                </div>
                            </div>
                        </div>

                        <div class="attivita-project-body">
                            <!-- Obiettivo -->
                            <div class="attivita-lead-objective green">
                                <div class="attivita-box-label">
                                    <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                                    Obiettivo del Progetto
                                </div>
                                <p><?php echo esc_html($d['orticino_obiettivo']); ?></p>
                            </div>

                            <!-- 2 Colonne: Attività + Accoglienza -->
                            <div class="attivita-subcolumns">
                                <div class="attivita-subcolumn">
                                    <div class="attivita-subcol-title">
                                        Attività Proposte
                                    </div>
                                    <?php echo demiap_render_check_list($d['orticino_attivita'], 'green'); ?>
                                </div>

                                <div class="attivita-subcolumn">
                                    <div class="attivita-subcol-title">
                                        Accoglienza &amp; Tutor
                                    </div>
                                    <?php echo demiap_render_check_list($d['orticino_accoglienza'], 'navy'); ?>
                                </div>
                            </div>

                            <!-- Destinatari -->
                            <div>
                                <span class="text-xs font-bold uppercase tracking-wider text-brand-deepblue block mb-2">
                                    A chi è rivolto:
                                </span>
                                <?php echo demiap_render_pills($d['orticino_destinatari']); ?>
                            </div>

                            <!-- Scopi e Finalità -->
                            <div>
                                <span class="text-xs font-bold uppercase tracking-wider text-brand-deepblue block mb-2">
                                    Finalità del percorso:
                                </span>
                                <?php echo demiap_render_check_list($d['orticino_scopi'], 'green'); ?>
                            </div>

                            <!-- Valore Umano -->
                            <?php if (!empty($d['orticino_conclusioni'])): ?>
                                <div class="attivita-human-value-box">
                                    <div class="attivita-human-value-title">
                                        Il Valore del Progetto:
                                    </div>
                                    <p>“<?php echo esc_html($d['orticino_conclusioni']); ?>”</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                </div>
            </div>

        </div>

        <!-- ==========================================
             2 & 3. MINISTERO DI PREGHIERA & ATTIVITÀ DI SOSTEGNO
             ========================================== -->
        <div class="attivita-split-grid">
            
            <!-- SINISTRA: MINISTERO DI PREGHIERA -->
            <div class="attivita-split-shell">
                <div class="attivita-split-header">
                    <div class="attivita-shell-category">
                        <span class="attivita-shell-category-dot"></span>
                        Preghiera &amp; Intercessione
                    </div>
                    <h3 class="attivita-split-title">
                        <?php echo esc_html($d['preghiera_title']); ?>
                    </h3>
                </div>

                <div class="attivita-desc-prose">
                    <?php echo wpautop(esc_html($d['preghiera_desc_generale'])); ?>
                    <?php if (!empty($d['preghiera_mezzi_intro'])): ?>
                        <p style="font-weight: 700; color: #193256; margin-top: 14px;">
                            <?php echo esc_html($d['preghiera_mezzi_intro']); ?>
                        </p>
                    <?php endif; ?>
                </div>

                <!-- Lista delle 7 Iniziative -->
                <div class="attivita-stream">
                    <!-- 1 -->
                    <div class="attivita-stream-card">
                        <span class="attivita-stream-num">01</span>
                        <div class="attivita-stream-content">
                            <h5 class="attivita-stream-title"><?php echo esc_html($d['preghiera_scuola_titolo']); ?></h5>
                            <p class="attivita-stream-text"><?php echo esc_html($d['preghiera_scuola_testo']); ?></p>
                        </div>
                    </div>
                    <!-- 2 -->
                    <div class="attivita-stream-card">
                        <span class="attivita-stream-num">02</span>
                        <div class="attivita-stream-content">
                            <h5 class="attivita-stream-title"><?php echo esc_html($d['preghiera_comune_titolo']); ?></h5>
                            <p class="attivita-stream-text"><?php echo esc_html($d['preghiera_comune_testo']); ?></p>
                        </div>
                    </div>
                    <!-- 3 -->
                    <div class="attivita-stream-card">
                        <span class="attivita-stream-num">03</span>
                        <div class="attivita-stream-content">
                            <h5 class="attivita-stream-title"><?php echo esc_html($d['preghiera_agosto_titolo']); ?></h5>
                            <p class="attivita-stream-text"><?php echo esc_html($d['preghiera_agosto_testo']); ?></p>
                        </div>
                    </div>
                    <!-- 4 -->
                    <div class="attivita-stream-card">
                        <span class="attivita-stream-num">04</span>
                        <div class="attivita-stream-content">
                            <h5 class="attivita-stream-title"><?php echo esc_html($d['preghiera_digiuno_titolo']); ?></h5>
                            <p class="attivita-stream-text"><?php echo esc_html($d['preghiera_digiuno_testo']); ?></p>
                            <?php if (!empty($d['preghiera_digiuno_url'])): ?>
                                <a href="<?php echo esc_url($d['preghiera_digiuno_url']); ?>" target="_blank" rel="noopener noreferrer" class="attivita-link-btn">
                                    <?php echo esc_html($d['preghiera_digiuno_label'] ?: $d['preghiera_digiuno_url']); ?> &rarr;
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!-- 5 -->
                    <div class="attivita-stream-card">
                        <span class="attivita-stream-num">05</span>
                        <div class="attivita-stream-content">
                            <h5 class="attivita-stream-title"><?php echo esc_html($d['preghiera_catene_titolo']); ?></h5>
                            <p class="attivita-stream-text"><?php echo esc_html($d['preghiera_catene_testo']); ?></p>
                        </div>
                    </div>
                    <!-- 6 -->
                    <div class="attivita-stream-card">
                        <span class="attivita-stream-num">06</span>
                        <div class="attivita-stream-content">
                            <h5 class="attivita-stream-title"><?php echo esc_html($d['preghiera_intercantonali_titolo']); ?></h5>
                            <p class="attivita-stream-text"><?php echo esc_html($d['preghiera_intercantonali_testo']); ?></p>
                            <?php if (!empty($d['preghiera_intercantonali_url'])): ?>
                                <a href="<?php echo esc_url($d['preghiera_intercantonali_url']); ?>" target="_blank" rel="noopener noreferrer" class="attivita-link-btn">
                                    <?php echo esc_html($d['preghiera_intercantonali_label'] ?: $d['preghiera_intercantonali_url']); ?> &rarr;
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!-- 7 -->
                    <div class="attivita-stream-card">
                        <span class="attivita-stream-num">07</span>
                        <div class="attivita-stream-content">
                            <h5 class="attivita-stream-title"><?php echo esc_html($d['preghiera_territorio_titolo']); ?></h5>
                            <p class="attivita-stream-text"><?php echo esc_html($d['preghiera_territorio_testo']); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- DESTRA: ATTIVITÀ DI SOSTEGNO -->
            <div class="attivita-split-shell">
                <div class="attivita-split-header">
                    <div class="attivita-shell-category">
                        <span class="attivita-shell-category-dot"></span>
                        Relazioni &amp; Accompagnamento
                    </div>
                    <h3 class="attivita-split-title">
                        <?php echo esc_html($d['sostegno_title']); ?>
                    </h3>
                </div>

                <div class="attivita-desc-prose">
                    <?php echo wpautop(esc_html($d['sostegno_desc_generale'])); ?>
                </div>

                <!-- Accordions Group -->
                <div class="attivita-accordions-group">
                    
                    <!-- 1. Imprenditori Cristiani -->
                    <details class="attivita-acc-item">
                        <summary class="attivita-acc-trigger">
                            <span><?php echo esc_html($d['sostegno_imprenditori_tag']); ?></span>
                            <span class="attivita-acc-icon">
                                <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7"/></svg>
                            </span>
                        </summary>
                        <div class="attivita-acc-body">
                            <?php if (!empty($d['sostegno_imprenditori_sottotitolo'])): ?>
                                <div class="attivita-acc-subtitle"><?php echo esc_html($d['sostegno_imprenditori_sottotitolo']); ?></div>
                            <?php endif; ?>
                            <?php echo wpautop(esc_html($d['sostegno_imprenditori_testo'])); ?>
                            <?php if (!empty($d['sostegno_imprenditori_box'])): ?>
                                <div class="attivita-acc-highlight">
                                    <strong>Sostegno:</strong>
                                    <?php echo nl2br(esc_html($d['sostegno_imprenditori_box'])); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </details>

                    <!-- 2. Palazzo Federale -->
                    <details class="attivita-acc-item">
                        <summary class="attivita-acc-trigger">
                            <span><?php echo esc_html($d['sostegno_palazzo_tag']); ?></span>
                            <span class="attivita-acc-icon">
                                <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7"/></svg>
                            </span>
                        </summary>
                        <div class="attivita-acc-body">
                            <?php if (!empty($d['sostegno_palazzo_sottotitolo'])): ?>
                                <div class="attivita-acc-subtitle"><?php echo esc_html($d['sostegno_palazzo_sottotitolo']); ?></div>
                            <?php endif; ?>
                            <?php echo wpautop(esc_html($d['sostegno_palazzo_testo'])); ?>
                            <?php if (!empty($d['sostegno_palazzo_box'])): ?>
                                <div class="attivita-acc-highlight">
                                    <strong>Sostegno:</strong>
                                    <?php echo nl2br(esc_html($d['sostegno_palazzo_box'])); ?>
                                </div>
                            <?php endif; ?>
                            <?php if (!empty($d['sostegno_palazzo_video_url'])): ?>
                                <a href="<?php echo esc_url($d['sostegno_palazzo_video_url']); ?>" target="_blank" rel="noopener noreferrer" class="attivita-video-cta">
                                    <svg width="16" height="16" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                                    <?php echo esc_html($d['sostegno_palazzo_video_label'] ?: 'Guarda il servizio video RSI'); ?>
                                </a>
                            <?php endif; ?>
                        </div>
                    </details>

                    <!-- 3. Preghiera per la Nazione -->
                    <details class="attivita-acc-item">
                        <summary class="attivita-acc-trigger">
                            <span><?php echo esc_html($d['sostegno_nazione_tag']); ?></span>
                            <span class="attivita-acc-icon">
                                <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7"/></svg>
                            </span>
                        </summary>
                        <div class="attivita-acc-body">
                            <?php if (!empty($d['sostegno_nazione_sottotitolo'])): ?>
                                <div class="attivita-acc-subtitle"><?php echo esc_html($d['sostegno_nazione_sottotitolo']); ?></div>
                            <?php endif; ?>
                            <?php echo wpautop(esc_html($d['sostegno_nazione_testo'])); ?>
                            <?php if (!empty($d['sostegno_nazione_box'])): ?>
                                <div class="attivita-acc-highlight">
                                    <strong>Sostegno:</strong>
                                    <?php echo nl2br(esc_html($d['sostegno_nazione_box'])); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </details>

                    <!-- 4. Autorità Politiche Cantonali -->
                    <details class="attivita-acc-item">
                        <summary class="attivita-acc-trigger">
                            <span><?php echo esc_html($d['sostegno_cantonali_tag']); ?></span>
                            <span class="attivita-acc-icon">
                                <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7"/></svg>
                            </span>
                        </summary>
                        <div class="attivita-acc-body">
                            <?php if (!empty($d['sostegno_cantonali_sottotitolo'])): ?>
                                <div class="attivita-acc-subtitle"><?php echo esc_html($d['sostegno_cantonali_sottotitolo']); ?></div>
                            <?php endif; ?>
                            <?php echo wpautop(esc_html($d['sostegno_cantonali_testo'])); ?>
                        </div>
                    </details>

                    <!-- 5. Polizia -->
                    <details class="attivita-acc-item">
                        <summary class="attivita-acc-trigger">
                            <span><?php echo esc_html($d['sostegno_polizia_tag']); ?></span>
                            <span class="attivita-acc-icon">
                                <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7"/></svg>
                            </span>
                        </summary>
                        <div class="attivita-acc-body">
                            <?php if (!empty($d['sostegno_polizia_sottotitolo'])): ?>
                                <div class="attivita-acc-subtitle"><?php echo esc_html($d['sostegno_polizia_sottotitolo']); ?></div>
                            <?php endif; ?>
                            <?php echo wpautop(esc_html($d['sostegno_polizia_testo'])); ?>
                            <?php if (!empty($d['sostegno_polizia_box'])): ?>
                                <div class="attivita-acc-highlight">
                                    <strong>Sostegno:</strong>
                                    <?php echo nl2br(esc_html($d['sostegno_polizia_box'])); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </details>

                    <!-- 6. Bisogni Personali -->
                    <details class="attivita-acc-item">
                        <summary class="attivita-acc-trigger">
                            <span><?php echo esc_html($d['sostegno_personali_tag']); ?></span>
                            <span class="attivita-acc-icon">
                                <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7"/></svg>
                            </span>
                        </summary>
                        <div class="attivita-acc-body">
                            <?php if (!empty($d['sostegno_personali_sottotitolo'])): ?>
                                <div class="attivita-acc-subtitle"><?php echo esc_html($d['sostegno_personali_sottotitolo']); ?></div>
                            <?php endif; ?>
                            <?php echo wpautop(esc_html($d['sostegno_personali_testo'])); ?>
                            <?php if (!empty($d['sostegno_personali_box'])): ?>
                                <div class="attivita-acc-highlight">
                                    <strong>Richiesta Preghiera:</strong>
                                    <?php echo nl2br(esc_html($d['sostegno_personali_box'])); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </details>

                </div>
            </div>

        </div>

        <!-- ==========================================
             4. COLLABORAZIONI & RETI DI SOSTEGNO
             ========================================== -->
        <div class="attivita-collab-section">
            <div class="attivita-shell-category">
                <span class="attivita-shell-category-dot"></span>
                Insieme per il Bene Comune
            </div>
            <h3 class="attivita-shell-title">
                <?php echo esc_html($d['collab_title']); ?>
            </h3>
            
            <?php if (!empty($d['collab_desc_generale'])): ?>
                <div class="attivita-desc-prose" style="margin-top: 14px; margin-bottom: 24px;">
                    <?php echo wpautop(esc_html($d['collab_desc_generale'])); ?>
                </div>
            <?php endif; ?>

            <div class="attivita-collab-grid">
                
                <!-- 1. CH-CH -->
                <div class="attivita-collab-card">
                    <div>
                        <h4 class="attivita-collab-name"><?php echo esc_html($d['collab1_nome']); ?></h4>
                        <div class="attivita-collab-desc">
                            <?php echo wpautop(esc_html($d['collab1_desc'])); ?>
                        </div>
                    </div>
                    <?php if (!empty($d['collab1_url'])): ?>
                        <div>
                            <a href="<?php echo esc_url($d['collab1_url']); ?>" target="_blank" rel="noopener noreferrer" class="attivita-collab-link">
                                <?php echo esc_html($d['collab1_label'] ?: $d['collab1_url']); ?> &rarr;
                            </a>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- 2. Pro Autoritas -->
                <div class="attivita-collab-card">
                    <div>
                        <h4 class="attivita-collab-name"><?php echo esc_html($d['collab2_nome']); ?></h4>
                        <div class="attivita-collab-desc">
                            <?php echo wpautop(esc_html($d['collab2_desc'])); ?>
                        </div>
                    </div>
                    <?php if (!empty($d['collab2_label'])): ?>
                        <div>
                            <?php if (!empty($d['collab2_url'])): ?>
                                <a href="<?php echo esc_url($d['collab2_url']); ?>" target="_blank" rel="noopener noreferrer" class="attivita-collab-link">
                                    <?php echo esc_html($d['collab2_label']); ?> &rarr;
                                </a>
                            <?php else: ?>
                                <span class="attivita-badge"><?php echo esc_html($d['collab2_label']); ?></span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- 3. La Bussola -->
                <div class="attivita-collab-card">
                    <div>
                        <h4 class="attivita-collab-name"><?php echo esc_html($d['collab3_nome']); ?></h4>
                        <div class="attivita-collab-desc">
                            <?php echo wpautop(esc_html($d['collab3_desc'])); ?>
                        </div>
                    </div>
                    <?php if (!empty($d['collab3_url'])): ?>
                        <div>
                            <a href="<?php echo esc_url($d['collab3_url']); ?>" target="_blank" rel="noopener noreferrer" class="attivita-collab-link">
                                <?php echo esc_html($d['collab3_label'] ?: $d['collab3_url']); ?> &rarr;
                            </a>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- 4. Kingdom Dance -->
                <div class="attivita-collab-card">
                    <div>
                        <h4 class="attivita-collab-name"><?php echo esc_html($d['collab4_nome']); ?></h4>
                        <div class="attivita-collab-desc">
                            <?php echo wpautop(esc_html($d['collab4_desc'])); ?>
                        </div>
                    </div>
                    <?php if (!empty($d['collab4_url'])): ?>
                        <div>
                            <a href="<?php echo esc_url($d['collab4_url']); ?>" target="_blank" rel="noopener noreferrer" class="attivita-collab-link">
                                <?php echo esc_html($d['collab4_label'] ?: $d['collab4_url']); ?> &rarr;
                            </a>
                        </div>
                    <?php endif; ?>
                </div>

            </div>
        </div>

    </div>
</div>

<?php get_footer(); ?>
