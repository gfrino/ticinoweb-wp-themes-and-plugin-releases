<?php
/**
 * Template Name: Pagina Standard
 * Il template generico per le pagine (es. Privacy Policy, Cookie Policy, ecc.)
 */
get_header();
?>
<!-- Area Contenuto Pagina -->
<section class="py-20 bg-gray-50 border-t border-gray-200 relative bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:20px_20px] hero-highlight group/hero" id="pagecontent">
    <div class="absolute inset-0 z-0 bg-[radial-gradient(#1877F2_1.5px,transparent_1.5px)] [background-size:20px_20px] pointer-events-none opacity-0 group-hover/hero:opacity-15 transition-opacity duration-500"
         style="mask-image: radial-gradient(300px circle at var(--mouse-x, 0px) var(--mouse-y, 0px), black 0%, transparent 100%); -webkit-mask-image: radial-gradient(300px circle at var(--mouse-x, 0px) var(--mouse-y, 0px), black 0%, transparent 100%);">
    </div>
    
    <div class="container mx-auto px-6 md:px-12 max-w-4xl relative z-10">
        <?php while (have_posts()) : the_post(); ?>
            <h1 class="font-serif text-3xl md:text-5xl text-brand-deepblue font-bold tracking-wide uppercase mb-10 text-center magic-title"><?php the_title(); ?></h1>
            
            <div class="bg-white p-8 md:p-14 mb-12 shadow-sm border-t-4 border-brand-red text-gray-700 text-sm md:text-base leading-relaxed text-left page-content">
                <?php the_content(); ?>
            </div>
        <?php endwhile; ?>
    </div>
</section>

<?php get_footer(); ?>
