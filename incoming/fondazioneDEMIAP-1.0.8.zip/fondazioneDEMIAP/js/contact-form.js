/**
 * Modulo contatti → gestore del parent (ticinoweb_submit_form).
 *
 * La pagina può arrivare dalla cache per giorni: il token si chiede al parent
 * poco prima dell'invio. reCAPTCHA v3 si usa solo se il sito ha le chiavi nel
 * pannello ticinoWEB CMS e viene caricato quando il visitatore inizia a scrivere.
 */
(function () {
    'use strict';

    var form = document.querySelector('[data-demiap-contact-form]');
    if (!form || !window.fetch || !window.FormData) {
        return;
    }

    var cfg = window.ticinoweb_ai_main || {};
    var ajaxUrl = cfg.ajax_url || form.getAttribute('data-ajax-url');
    var tokenAction = cfg.token_action || 'ticinoweb_form_token';
    var submitAction = cfg.submit_action || 'ticinoweb_submit_form';
    var siteKey = cfg.recaptcha_site_key || '';
    var statusEl = document.getElementById('demiapFormStatus');
    var successBox = document.getElementById('demiapFormSuccess');
    var successText = document.getElementById('demiapFormSuccessText');
    var button = form.querySelector('button[type="submit"]');
    var recaptchaLoading = null;
    var mail = form.getAttribute('data-fallback-mail') || '';
    var i18n = {
        required: 'Campo obbligatorio.',
        email: 'Inserisci un indirizzo email valido.',
        privacy: 'Conferma di aver letto la Privacy Policy.',
        sending: 'Invio in corso…',
        sent: 'Il tuo messaggio è stato inviato. Ti risponderemo al più presto.',
        failed: 'Non è stato possibile inviare il messaggio. Riprova più tardi' + (mail ? ' oppure scrivici a ' + mail + '.' : '.')
    };

    function setStatus(text, kind) {
        statusEl.textContent = text || '';
        statusEl.className = 'demiap-form-status' + (kind ? ' is-' + kind : '');
    }

    function setError(name, text) {
        var slot = form.querySelector('[data-error-for="' + name + '"]');
        var field = form.elements[name];
        if (slot) { slot.textContent = text || ''; }
        if (field && field.setAttribute) {
            if (text) { field.setAttribute('aria-invalid', 'true'); } else { field.removeAttribute('aria-invalid'); }
        }
    }

    function validate() {
        var ok = true;
        ['nome', 'email', 'messaggio', 'privacy'].forEach(function (n) { setError(n, ''); });
        if (form.elements.nome.value.trim().length < 2) { setError('nome', i18n.required); ok = false; }
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.elements.email.value.trim())) { setError('email', i18n.email); ok = false; }
        if (form.elements.messaggio.value.trim().length < 5) { setError('messaggio', i18n.required); ok = false; }
        if (!form.elements.privacy.checked) { setError('privacy', i18n.privacy); ok = false; }
        return ok;
    }

    function loadRecaptcha() {
        if (!siteKey) { return Promise.resolve(); }
        if (recaptchaLoading) { return recaptchaLoading; }
        recaptchaLoading = new Promise(function (resolve) {
            var s = document.createElement('script');
            s.src = 'https://www.google.com/recaptcha/api.js?render=' + encodeURIComponent(siteKey);
            s.async = true;
            s.onload = resolve;
            s.onerror = resolve;
            document.head.appendChild(s);
        });
        return recaptchaLoading;
    }

    function recaptchaToken() {
        if (!siteKey) { return Promise.resolve(''); }
        return loadRecaptcha().then(function () {
            if (!window.grecaptcha) { return ''; }
            return new Promise(function (resolve) {
                window.grecaptcha.ready(function () {
                    window.grecaptcha.execute(siteKey, { action: 'contact' }).then(resolve, function () { resolve(''); });
                });
            });
        });
    }

    if (siteKey) {
        form.addEventListener('focusin', loadRecaptcha, { once: true });
    }

    function showSuccess(message) {
        successText.textContent = message;
        form.classList.add('hidden');
        successBox.classList.remove('hidden');
        successBox.classList.add('flex');
        successBox.focus();
    }

    form.addEventListener('submit', function (event) {
        event.preventDefault();
        if (!validate()) {
            setStatus('', '');
            var first = form.querySelector('[aria-invalid="true"]');
            if (first) { first.focus(); }
            return;
        }

        button.disabled = true;
        button.setAttribute('aria-busy', 'true');
        setStatus(i18n.sending, 'pending');

        fetch(ajaxUrl + '?action=' + encodeURIComponent(tokenAction), { credentials: 'same-origin', cache: 'no-store' })
            .then(function (r) { return r.json(); })
            .then(function (tokenResponse) {
                return recaptchaToken().then(function (rc) {
                    var data = new FormData(form);
                    data.delete('privacy');
                    data.append('action', submitAction);
                    data.append('token', tokenResponse && tokenResponse.data ? tokenResponse.data.token : '');
                    if (rc) { data.append('recaptcha_token', rc); }
                    return fetch(ajaxUrl, { method: 'POST', body: data, credentials: 'same-origin' });
                });
            })
            .then(function (r) { return r.json().catch(function () { return { success: false }; }); })
            .then(function (res) {
                if (res && res.success) {
                    form.reset();
                    setStatus('', '');
                    showSuccess((res.data && res.data.message) || i18n.sent);
                    return;
                }
                var fields = res && res.data && res.data.fields ? res.data.fields : {};
                Object.keys(fields).forEach(function (name) { setError(name, fields[name]); });
                setStatus((res && res.data && res.data.message) || i18n.failed, 'error');
            })
            .catch(function () { setStatus(i18n.failed, 'error'); })
            .then(function () {
                button.disabled = false;
                button.removeAttribute('aria-busy');
            });
    });
}());
