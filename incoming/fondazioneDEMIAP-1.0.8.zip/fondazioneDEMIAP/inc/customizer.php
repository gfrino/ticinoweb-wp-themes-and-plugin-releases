<?php
/**
 * Customizer per Fondazione DEMIAP
 */

function fondazionedemiap_customize_register($wp_customize) {
    // SEZIONE HERO
    $wp_customize->add_section('demiap_hero_section', array(
        'title' => 'Home / Hero',
        'priority' => 30,
    ));
    
    $wp_customize->add_setting('demiap_hero_title', array('default' => 'Un altro modo di vivere la comunità'));
    $wp_customize->add_control('demiap_hero_title', array('label' => 'Titolo', 'section' => 'demiap_hero_section', 'type' => 'text'));

    $wp_customize->add_setting('demiap_hero_text', array('default' => 'La Fondazione DEMIAP è una realtà senza scopo di lucro che promuove relazioni autentiche, aiuto concreto e crescita personale attraverso valori cristiani vissuti nella quotidianità.'));
    $wp_customize->add_control('demiap_hero_text', array('label' => 'Testo Missione', 'section' => 'demiap_hero_section', 'type' => 'textarea'));
    
    // SEZIONE FONDAZIONE
    $wp_customize->add_section('demiap_fondazione_section', array(
        'title' => 'Fondazione',
        'priority' => 31,
    ));
    
    $wp_customize->add_setting('demiap_fondazione_title', array('default' => 'Chi siamo'));
    $wp_customize->add_control('demiap_fondazione_title', array('label' => 'Titolo', 'section' => 'demiap_fondazione_section', 'type' => 'text'));

    $wp_customize->add_setting('demiap_fondazione_desc', array('default' => 'La Fondazione DEMIAP è un ente riconosciuto di utilità pubblica. Il nome DEMIAP racchiude i suoi tre pilastri fondamentali. Questi valori guidano ogni attività con l’obiettivo di generare un impatto positivo nella vita delle persone e nella comunità.'));
    $wp_customize->add_control('demiap_fondazione_desc', array('label' => 'Descrizione', 'section' => 'demiap_fondazione_section', 'type' => 'textarea'));

    // Pilastri
    for ($i=1; $i<=3; $i++) {
        $default_titolo = $i == 1 ? 'Divulgazione dell’Evangelo' : ($i == 2 ? 'Momenti d’Incontro' : 'Aiuto a Persone');
        $default_testo = $i == 1 ? 'Trasmettiamo i valori e gli insegnamenti di Gesù Cristo attraverso la vita quotidiana, relazioni genuine e testimonianza concreta.' : ($i == 2 ? 'Organizziamo eventi e occasioni di scambio per favorire relazioni autentiche e crescita personale.' : 'Offriamo supporto concreto a persone in difficoltà, promuovendo solidarietà e sostegno reciproco.');
        
        $wp_customize->add_setting("demiap_pilastro{$i}_title", array('default' => $default_titolo));
        $wp_customize->add_control("demiap_pilastro{$i}_title", array('label' => "Titolo Pilastro $i", 'section' => 'demiap_fondazione_section', 'type' => 'text'));

        $wp_customize->add_setting("demiap_pilastro{$i}_desc", array('default' => $default_testo));
        $wp_customize->add_control("demiap_pilastro{$i}_desc", array('label' => "Testo Pilastro $i", 'section' => 'demiap_fondazione_section', 'type' => 'textarea'));
    }

    // DONAZIONI
    $wp_customize->add_section('demiap_donazioni_section', array(
        'title' => 'Donazioni',
        'priority' => 32,
    ));
    $wp_customize->add_setting('demiap_dona_title', array('default' => 'Sostieni la Fondazione'));
    $wp_customize->add_control('demiap_dona_title', array('label' => 'Titolo', 'section' => 'demiap_donazioni_section', 'type' => 'text'));

}
add_action('customize_register', 'fondazionedemiap_customize_register');
