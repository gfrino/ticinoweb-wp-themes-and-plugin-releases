<?php
/**
 * Gestione dinamica dei contenuti della Pagina Attività
 * Fondazione DEMIAP
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Funzione di utilità per renderizzare righe di testo come elementi di una lista <ul>.
 */
function demiap_render_list_items($text, $list_class = 'list-disc pl-5 space-y-1 text-gray-600') {
    $lines = array_filter(array_map('trim', explode("\n", (string)$text)));
    if (empty($lines)) return '';
    $out = '<ul class="' . esc_attr($list_class) . '">';
    foreach ($lines as $line) {
        $out .= '<li>' . esc_html($line) . '</li>';
    }
    $out .= '</ul>';
    return $out;
}

/**
 * Renderizza le righe di testo come una lista elegante con icone SVG di spunta / freccia.
 */
function demiap_render_check_list($text, $accent_color = 'navy') {
    $lines = array_filter(array_map('trim', explode("\n", (string)$text)));
    if (empty($lines)) return '';
    
    $is_green = ($accent_color === 'green');
    $out = '<div class="attivita-check-list">';
    foreach ($lines as $line) {
        $clean_line = ltrim($line, "-•* \t");
        $icon_class = $is_green ? 'attivita-check-icon green' : 'attivita-check-icon';
        $out .= '<div class="attivita-check-item">';
        $out .= '<span class="' . $icon_class . '">';
        $out .= '<svg width="14" height="14" style="width:14px;height:14px;min-width:14px;display:block;" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="3"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>';
        $out .= '</span>';
        $out .= '<span class="attivita-check-text">' . esc_html($clean_line) . '</span>';
        $out .= '</div>';
    }
    $out .= '</div>';
    return $out;
}

/**
 * Renderizza le righe di testo come pillole/badge flessibili ed eleganti.
 */
function demiap_render_pills($text, $style = 'slate') {
    $lines = array_filter(array_map('trim', explode("\n", (string)$text)));
    if (empty($lines)) return '';
    
    $out = '<div class="attivita-pills-wrap">';
    foreach ($lines as $line) {
        $clean_line = ltrim($line, "-•* \t");
        $out .= '<span class="attivita-pill">';
        $out .= '<span class="attivita-pill-dot"></span>';
        $out .= esc_html($clean_line);
        $out .= '</span>';
    }
    $out .= '</div>';
    return $out;
}

/**
 * Restituisce l'array con tutti i testi predefiniti (estratti fedelmente dal PDF ufficiale).
 */
function demiap_get_attivita_default_data() {
    return array(
        // INTESTAZIONE PAGINA
        'page_title' => 'Le Nostre Attività',
        'page_subtitle' => 'Esplora il dettaglio delle nostre attività sociali, il ministero di preghiera e le reti di sostegno.',

        // 1. ATTIVITÀ SOCIALI
        'sociali_title' => 'Attività Sociali',
        'sociali_intro' => "C’è sempre spazio per una nuova opportunità! Questo è il principio che ispira e sostiene ogni nostro progetto di volontariato sociale.\n\nOffrire sempre un’opportunità a chiunque è il principio che anima i nostri progetti. Per noi, questo non rappresenta solo un dovere, ma è prima di tutto una gioia e una fonte di soddisfazione.\n\nIl nostro desiderio è che ognuno possa sentirsi davvero a proprio agio con sé stesso, trovando benessere e autenticità nella propria vita. Per questo motivo, i nostri progetti sono pensati proprio per favorire questo percorso di crescita personale e valorizzazione individuale.\n\nAttraverso attività quotidiane, ci impegniamo a valorizzare ogni individuo, riconoscendo e facendo emergere i talenti e le capacità che ciascuno possiede. In una società sempre più orientata alla prestazione e spesso carente di empatia nelle relazioni, desideriamo offrire uno spazio in cui queste qualità, talvolta trascurate o messe in secondo piano, possano trovare nuova espressione e riconoscimento.\n\nAttraverso i progetti di Aiuto alle Persone, ci proponiamo di offrire occasioni di incontro autentico e di favorire la nascita di legami profondi e significativi tra le persone. Il nostro intento è quello di creare spazi in cui ciascuno possa sentirsi accolto, ascoltato e valorizzato, promuovendo così relazioni basate sulla fiducia reciproca e sul sostegno concreto.",

        // Progetto L'Angolino
        'angolino_title' => "L'Angolino",
        'angolino_obiettivo' => "“L’Angolino” nasce con l’intento di offrire uno spazio occupazionale e relazionale a persone che vivono situazioni di fragilità sociale. Il progetto è rivolto a beneficiari dell’assistenza, disoccupati, persone con invalidità (AI) e individui che vivono in ritiro sociale. Attraverso attività soprattutto di lavaggio e stiro della biancheria, vogliamo favorire la riattivazione personale, la dignità e il senso di utilità.",
        'angolino_luogo' => "Il programma si svolge in Via Ballarini 5 a Muralto in un monolocale preso in affitto dalla Fondazione.",
        'angolino_attivita' => "Ritiro biancheria da lavare;\nLavaggio, piegatura ed ev. stiraggio della biancheria;\nRiconsegna della biancheria.",
        'angolino_accoglienza' => "Accompagnamento sul campo\nFrequenza flessibile da 1 a 4 giorni a settimana\nPresenza di una figura di riferimento con esperienza nell’ambito socio-educativo",
        'angolino_destinatari' => "in assistenza sociale o disoccupazione\ncon invalidità parziale o disagio psicosociale\nin situazione di isolamento o ritiro\nPersone senza attività fissa che prestano la loro opera a titolo volontario.\nPersone con difficoltà varie nel provvedere al lavaggio della propria biancheria.",
        'angolino_scopi' => "Riattivazione delle competenze;\nSocializzazione;\nRecupero dell’autostima;\nAiuto concreto al prossimo.",
        'angolino_conclusioni' => "La peculiarità di questo progetto risiede nel fatto che coinvolge persone con difficoltà affinché possano offrire il proprio aiuto ad altri individui che si trovano in situazioni di disagio differenti. Questo approccio genera un circolo virtuoso di solidarietà, consentendo ai partecipanti di riscoprire il senso di utilità e gratificazione personale—sensazioni spesso difficili da sperimentare altrove, considerate le circostanze in cui si trovano.",

        // Progetto L'Orticino
        'orticino_title' => "L'Orticino",
        'orticino_obiettivo' => "“L’Orticino” nasce con l’intento di offrire uno spazio occupazionale e relazionale a persone che vivono situazioni di fragilità sociale. Il progetto è rivolto a beneficiari dell’assistenza, disoccupati, persone con invalidità parziale (AI) e individui che vivono in ritiro sociale. Attraverso attività pratiche e all’aria aperta, legate alla cura dell’orto e alla vita in natura, vogliamo favorire la riattivazione personale, la dignità e il senso di utilità.",
        'orticino_luogo' => "il programma si svolge presso un terreno agricolo affittato alla Fondazione DEMIAP, situato in via Martinello a Sant’Antonino (TI).",
        'orticino_attivita' => "Coltivazione di ortaggi e piante aromatiche\nManutenzione degli spazi verdi e gestione dell’ambiente\nCompostaggio e cura sostenibile del terreno\nAttività manuali leggere e adatte alle capacità di ciascuno\nLavorazione e/o vendita dei prodotti raccolti\nMomenti di socializzazione attraverso attività concrete",
        'orticino_accoglienza' => "Accompagnamento personalizzato con presenza sul campo\nFrequenza flessibile da 1 a 4 giorni a settimana\nPresenza di una figura di riferimento con esperienza nell’ambito socio-educativo",
        'orticino_destinatari' => "in assistenza sociale o disoccupazione\ncon invalidità parziale o disagio psicosociale\nin situazione di isolamento o ritiro",
        'orticino_scopi' => "Promuovere la riattivazione personale e la motivazione\nFavorire l’autonomia e il rispetto dei ritmi individuali\nRafforzare le relazioni e il senso di appartenenza\nOffrire un’esperienza concreta di utilità sociale",
        'orticino_conclusioni' => "“L’Orticino” vuole essere un piccolo seme piantato nel terreno del disagio per far nascere nuove possibilità. Con il sostegno e le offerte dei benefattori, potremo continuare ad offrire una risposta concreta a chi oggi si trova ai margini, costruendo insieme percorsi di dignità, relazione e speranza.",

        // 2. MINISTERO DI PREGHIERA
        'preghiera_title' => 'Ministero di Preghiera',
        'preghiera_desc_generale' => "Una parte importante del mandato della Fondazione DEMIAP si esprime attraverso la preghiera: dalla dimensione personale all’intercessione per il prossimo, fino alla preghiera per la Nazione e per le autorità.\n\nAlla luce delle Scritture e dell’esperienza maturata nel metterle in pratica, crediamo che la preghiera prepari e accompagni ciò che poi può manifestarsi in modo concreto nella vita quotidiana. Per questo incoraggiamo le persone a coltivare una vita di preghiera personale, costante e radicata nella fiducia in Dio.",
        'preghiera_mezzi_intro' => 'Per stimolare una vita di preghiera ed aiutare le persone a fare in modo che la preghiera diventi una parte concreta nella vita della persona utilizziamo in particolare i seguenti mezzi:',
        
        'preghiera_scuola_titolo' => 'SCUOLA DI PREGHIERA',
        'preghiera_scuola_testo' => 'Lezioni specifiche sul tema della preghiera',

        'preghiera_comune_titolo' => 'TEMPI DI PREGHIERA IN COMUNE',
        'preghiera_comune_testo' => 'Invitiamo le persone a dei tempi di preghiera in particolare in favore dei comuni, del Canton Ticino e della Confederazione Svizzera',

        'preghiera_agosto_titolo' => '1° AGOSTO',
        'preghiera_agosto_testo' => 'In occasione della Festa Nazionale dal 2017 organizziamo un incontro interdenominazionale con ospiti che stimolano alla preghiera per la Nazione.',

        'preghiera_digiuno_titolo' => 'DIGIUNO FEDERALE',
        'preghiera_digiuno_testo' => 'In occasione della Festa Federale di Ringraziamento, Digiuno Federale, mettiamo in pratica la preghiera per la Nazione, con eventi direttamente sul territorio, in collaborazione con altri responsabili di preghiera cantonali.',
        'preghiera_digiuno_url' => 'https://www.digiuno-federale.ch',
        'preghiera_digiuno_label' => 'www.digiuno-federale.ch',

        'preghiera_catene_titolo' => 'CATENE DI PREGHIERA',
        'preghiera_catene_testo' => 'In occasioni particolari, come lo è stato con il COVID, organizziamo staffette di preghiera per bisogni specifici.',

        'preghiera_intercantonali_titolo' => 'INCONTRI DI PREGHIERA INTERCANTONALI',
        'preghiera_intercantonali_testo' => 'Partecipiamo e organizziamo eventi di preghiera che coinvolgono gruppi di persone di altri cantoni, che hanno scopi simili a quelli della nostra Fondazione. Un esempio su tutti è l’incontro annuale di preghiera sul passo dell’Oberalp.',
        'preghiera_intercantonali_url' => 'https://gebet-gr.jimdoweb.com/gebet-oberalp/',
        'preghiera_intercantonali_label' => "Incontro annuale sul passo dell'Oberalp",

        'preghiera_territorio_titolo' => 'USCITE DI PREGHIERA NEL TERRITORIO',
        'preghiera_territorio_testo' => 'Organizziamo momenti di preghiera in posti particolarmente significativi, soprattutto nel territorio ticinese e dei cantoni confinanti.',

        // 3. ATTIVITÀ DI SOSTEGNO
        'sostegno_title' => 'Attività di Sostegno',
        'sostegno_desc_generale' => "La Fondazione DEMIAP offre del sostegno anche in collaborazione con altre associazioni. Il sostegno va a categorie specifiche disponibili a far entrare il tema della fede e della preghiera nelle loro attività.\n\nAttualmente questa opera viene svolta in favore di imprenditori, politici, poliziotti, sanitari.",

        // Imprenditori
        'sostegno_imprenditori_tag' => 'GRUPPO IMPRENDITORI CRISTIANI',
        'sostegno_imprenditori_sottotitolo' => 'Servizio di preghiera per gli imprenditori cristiani.',
        'sostegno_imprenditori_testo' => "Dal luglio del 2022 la Fondazione DEMIAP organizza un incontro mensile dedicato agli imprenditori cristiani. Si tratta di un tempo dedicato alla condivisione e alla preghiera. Lo scopo è di favorire la conoscenza e il sostegno reciproco nelle sfide quotidiane che circondano la gestione delle imprese.\n\nSe desideri partecipare o avere informazioni ti invito a prendere contatto o a visionare l’Agenda.",
        'sostegno_imprenditori_box' => 'Vuoi far parte dei sostenitori di questa attività? Puoi fare un’offerta qui, menzionando nel versamento "SOSTEGNO MOSI imprenditori".',

        // Palazzo Federale
        'sostegno_palazzo_tag' => 'PREGHIERA A PALAZZO FEDERALE',
        'sostegno_palazzo_sottotitolo' => 'Servizio di preghiera per le autorità politiche federali.',
        'sostegno_palazzo_testo' => "La fondazione DEMIAP partecipa ad un servizio di preghiera per le autorità politiche federali. Dal novembre 2018 Milco Margaroli fa parte del team del Gruppo di Preghiera a Palazzo Federale a Berna, composto da 4 persone. Dal 2021 anche Daniela Margaroli si reca a Berna con Milco e si occupa per conto dell’associazione Pro Autoritas, di organizzare vari momenti dedicati alla preghiera, principalmente all’esterno del Palazzo Federale con il compito principale di pregare per i temi di politica federale e di sostenere gli impiegati dell’amministrazione federale.\n\nSi tratta di un’opera iniziata nel 1993 da Beat Christen, volta a sostenere con la preghiera e la relazione, le persone che fanno parte dell’Assemblea Federale, nonché coloro che gravitano attorno alle attività di Palazzo Federale.\n\nNel tempo molte persone ticinesi, ma anche svizzere tedesche e francesi che hanno la spinta a pregare per le autorità politiche, hanno deciso di far parte di una rete di preghiera che appoggia Milco e Daniela, nella loro attività a Berna. Queste persone ricevono direttamente da Milco e Daniela, via WhatsApp, i temi di attualità sui quali pregare. Se desiderate far parte di questa rete di preghiera siete invitati a prendere contatto.\n\nLe sessioni del parlamento si tengono 12 settimane all’anno, suddivise in quattro blocchi da tre settimane. Milco e Daniela si recano a Berna dal lunedì al mercoledì durante queste 12 settimane. Questo significa che sono presenti durante le sedute del parlamento per almeno 36 giorni all’anno. Svolgono questa attività in modo volontario. Una parte delle spese sono coperte dalle associazioni che fanno da cappello a questo ministero. Per il resto sono sostenuti dalle offerte che la Fondazione DEMIAP riceve come sostegno MOSI (Missione Operativa Svizzera Italiana).",
        'sostegno_palazzo_box' => 'Vuoi far parte dei sostenitori di questa attività? Puoi fare un’offerta qui, menzionando nel versamento "SOSTEGNO MOSI Berna".',
        'sostegno_palazzo_video_url' => 'https://tp.srgssr.ch/p/rsi/embed?urn=urn:rsi:video:11589469&autoplay=true&hideendscreen=1',
        'sostegno_palazzo_video_label' => 'Guarda il servizio della RSI su Milco del 13 marzo 2019',

        // Preghiera per la Nazione
        'sostegno_nazione_tag' => 'SERVIZIO DI PREGHIERA PER LA NAZIONE',
        'sostegno_nazione_sottotitolo' => 'Servizio di preghiera per la Nazione.',
        'sostegno_nazione_testo' => "Avendo visto aumentare l’interesse di pregare per le varie categorie di persone e apprezzando l’elevato numero di persone che hanno aderito alle varie chat di preghiera, la Fondazione DEMIAP ha organizzato un incontro mensile in presenza dove conoscerci reciprocamente e pregare assieme per la Nazione. È anche il momento privilegiato per comunicare le informazioni, a volte confidenziali, che riguardano in particolare il ministero a Berna.\n\nLa partecipazione è aperta a coloro che hanno a cuore la preghiera per la nostra Svizzera. Trovate le date e il luogo dell’incontro sull’Agenda.",
        'sostegno_nazione_box' => 'Vuoi far parte dei sostenitori di questa attività? Puoi fare un’offerta qui, menzionando nel versamento "SOSTEGNO MOSI Svizzera".',

        // Autorità Cantonali
        'sostegno_cantonali_tag' => 'PREGHIERA AUTORITÀ CANTONALI',
        'sostegno_cantonali_sottotitolo' => 'Preghiera in favore delle autorità politiche cantonali.',
        'sostegno_cantonali_testo' => "Un modo per sostenere le autorità politiche cantonali si é con la presenza sulle tribune nei momenti dove si riunisce il Gran Consiglio a Bellinzona. Da lì preghiamo discretamente per loro.\n\nUn altro modo è quello di coltivare le relazioni personali con chi è impegnato in questo ruolo. Far loro conoscere il nostro sostegno in preghiera apre molte porte per metterlo in pratica in modo concreto.",

        // Polizia
        'sostegno_polizia_tag' => 'GRUPPO POLIZIOTTI CRISTIANI',
        'sostegno_polizia_sottotitolo' => 'Servizio di preghiera per la polizia.',
        'sostegno_polizia_testo' => "Su input di alcuni poliziotti cristiani, la Fondazione DEMIAP li sostiene con un doppio impegno. Il primo è la partecipazione all’incontro periodico tra i poliziotti cristiani.\n\nIl secondo è la gestione di un gruppo di intercessori pronti a pregare per le necessità segnalate dai poliziotti stessi.",
        'sostegno_polizia_box' => "Vuoi far parte di coloro che si mettono a disposizione per pregare per la polizia? Contattaci.\nVuoi far parte dei sostenitori di questa attività? Puoi fare un’offerta qui, menzionando nel versamento \"SOSTEGNO MOSI polizia\".",

        // Bisogni Personali
        'sostegno_personali_tag' => 'BISOGNI SPECIFICI PERSONALI',
        'sostegno_personali_sottotitolo' => 'Servizio di preghiera per bisogni personali in genere.',
        'sostegno_personali_testo' => "Questo servizio di preghiera è nato nel 2008 prendendo in considerazione i vari bisogni delle persone che frequentavano la Chiesa Ticino in quel periodo. I bisogni delle persone credenti e non credenti sono infiniti. Abbiamo quindi pensato di organizzare un gruppo WhatsApp con persone scelte; cristiani desiderosi di pregare per i bisogni altrui; di conseguenza, chiunque ha sul cuore una richiesta di preghiera o un bisogno particolare per se, per la propria famiglia o per altri soggetti, lo invia a Daniela che gestisce il gruppo; viene in seguito formulata una preghiera per tutta il gruppo che prega in accordo. Siamo sempre molto incoraggiati di sentire le testimonianze di guarigione e di intervento divino nelle vite delle persone per cui si ha pregato.",
        'sostegno_personali_box' => 'Se necessiti di una preghiera, di sostegno per una situazione particolare, di guarigione o altro per te o per chi conosci, contatta Daniela anche per ulteriori chiarimenti.',

        // 4. COLLABORAZIONI
        'collab_title' => 'Collaborazioni',
        'collab_desc_generale' => "Di seguito vi trasmettiamo alcuni enti con i quali abbiamo una collaborazione significativa. Trovate una piccola descrizione e in genere un link.",

        // 1. CH-CH
        'collab1_nome' => 'CH-CH Cristiani per la Svizzera',
        'collab1_desc' => "Si tratta di un gruppo con il quale collaboriamo strettamente fin dalla sua creazione nel giugno del 2019, con l’obiettivo di ripristinare la celebrazione del Digiuno Federale in Svizzera. Assieme ai membri elaboriamo informazioni, stimoli e attività per raggiungere lo scopo. Sul sito in tre lingue potete trovare le informazioni specifiche.",
        'collab1_url' => 'https://www.digiuno-federale.ch',
        'collab1_label' => 'www.digiuno-federale.ch',

        // 2. Pro Autoritas
        'collab2_nome' => 'Associazione Pro Autoritas e Associazione Gruppo di Preghiera a Palazzo Federale',
        'collab2_desc' => "La Fondazione DEMIAP collabora con queste due associazioni. Lavorano in sintonia e si occupano rispettivamente di sostenere gli intercessori che operano fuori da Palazzo federale e quelli che operano all’interno di Palazzo federale.\n\nAssieme a loro, i nostri intercessori fanno 4-5 riunioni annuali durante le quali condividono le sfide e i bisogni di preghiera che vengono successivamente divulgati ai sostenitori, soprattutto attraverso un bollettino informativo che redigono assieme.",
        'collab2_url' => '',
        'collab2_label' => 'All’ultimo bollettino informativo',

        // 3. La Bussola
        'collab3_nome' => 'Associazione La Bussola',
        'collab3_desc' => 'L’Associazione La Bussola si occupa di sopperire ai bisogni sociali del comune di Cugnasco Gerra.',
        'collab3_url' => '',
        'collab3_label' => '',

        // 4. Kingdom Dance
        'collab4_nome' => 'Kingdom Dance',
        'collab4_desc' => 'Ministero di Lode a Dio in particolare attraverso la Danza',
        'collab4_url' => '',
        'collab4_label' => ''
    );
}

/**
 * Recupera i dati correnti per la pagina Attività fondendo DB e Default.
 */
function demiap_get_attivita_data() {
    $defaults = demiap_get_attivita_default_data();
    $saved = get_option('demiap_attivita_data', array());

    if (!is_array($saved) || empty($saved)) {
        return $defaults;
    }

    return wp_parse_args($saved, $defaults);
}

/**
 * Registrazione Menu Amministrazione
 */
add_action('admin_menu', 'demiap_register_attivita_admin_menu', 35);
function demiap_register_attivita_admin_menu() {
    // Sottomenu sotto ticinoWEB CMS
    add_submenu_page(
        'ticinoweb-cms',
        'Gestione Pagina Attività',
        'Pagina Attività',
        'edit_pages',
        'demiap-attivita',
        'demiap_render_attivita_admin_page'
    );

    // Menu diretto nella barra laterale principale
    add_menu_page(
        'Pagina Attività DEMIAP',
        'Pagina Attività',
        'edit_pages',
        'demiap-attivita-direct',
        'demiap_render_attivita_admin_page',
        'dashicons-clipboard',
        31
    );
}

/**
 * Rendering Pagina Backend - Interfaccia Ordinata e Intuitiva con Accordion
 */
function demiap_render_attivita_admin_page() {
    if (!current_user_can('edit_pages')) {
        wp_die(__('Non hai i permessi per accedere a questa pagina.'));
    }

    $notice = '';
    $defaults = demiap_get_attivita_default_data();

    // Salvataggio Dati
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['demiap_save_attivita'])) {
        check_admin_referer('demiap_save_attivita_action', 'demiap_attivita_nonce');

        $clean_data = array();
        foreach ($defaults as $key => $default_val) {
            if (isset($_POST[$key])) {
                $clean_data[$key] = wp_kses_post(wp_unslash($_POST[$key]));
            } else {
                $clean_data[$key] = $default_val;
            }
        }

        update_option('demiap_attivita_data', $clean_data);
        $notice = '<div class="notice notice-success is-dismissible"><p><strong>I contenuti della Pagina Attività sono stati salvati con successo!</strong></p></div>';
    }

    $active_tab = isset($_POST['demiap_active_tab']) ? sanitize_key($_POST['demiap_active_tab']) : 'tab-sociali';
    $data = demiap_get_attivita_data();
    ?>
    <div class="wrap demiap-admin-wrap">
        
        <!-- Header Amministrazione -->
        <div class="demiap-admin-header">
            <div>
                <h1>Gestione Pagina Attività</h1>
                <p class="demiap-subtitle">
                    Modifica in modo ordinato i testi, elenchi e link di ogni sezione.
                </p>
            </div>
            <a href="<?php echo esc_url(home_url('/attivita/')); ?>" target="_blank" class="button button-secondary demiap-view-link">
                Visualizza Pagina Live &rarr;
            </a>
        </div>

        <?php if (!empty($notice)) echo $notice; ?>

        <style>
            .demiap-admin-wrap { max-width: 1100px; margin-top: 20px; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif; }
            .demiap-admin-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; padding-bottom: 15px; border-bottom: 1px solid #CBD5E1; }
            .demiap-admin-header h1 { margin: 0 0 5px 0; font-size: 24px; color: #193256; font-weight: 700; }
            .demiap-subtitle { margin: 0; color: #64748B; font-size: 13px; }
            .demiap-view-link { font-weight: 600 !important; color: #193256 !important; }

            /* Navigazione Tab */
            .demiap-tab-nav { display: flex; gap: 6px; border-bottom: 2px solid #CBD5E1; margin-bottom: 20px; }
            .demiap-tab-btn {
                background: #F1F5F9;
                border: 1px solid #CBD5E1;
                border-bottom: none;
                padding: 10px 18px;
                font-weight: 600;
                font-size: 13px;
                color: #475569;
                cursor: pointer;
                border-radius: 6px 6px 0 0;
                transition: all 0.2s;
            }
            .demiap-tab-btn:hover { background: #E2E8F0; color: #0F172A; }
            .demiap-tab-btn.active {
                background: #193256;
                color: #FFFFFF;
                border-color: #193256;
            }

            /* Pannelli Tab */
            .demiap-tab-pane { display: none; background: #FFFFFF; border: 1px solid #E2E8F0; border-radius: 8px; padding: 20px 24px 30px; box-shadow: 0 1px 3px rgba(0,0,0,0.04); }
            .demiap-tab-pane.active { display: block; }

            /* Barra Strumenti Tab (Espandi / Riduci) */
            .demiap-tab-toolbar {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 18px;
                padding-bottom: 12px;
                border-bottom: 1px dashed #E2E8F0;
            }
            .demiap-tab-toolbar h2 { margin: 0; font-size: 16px; color: #1E293B; font-weight: 700; }
            .demiap-tool-btn { background: none; border: none; color: #0284C7; cursor: pointer; font-size: 12px; font-weight: 600; padding: 0 6px; text-decoration: underline; }
            .demiap-tool-btn:hover { color: #0369A1; }

            /* Accordion Card */
            .demiap-acc-item {
                border: 1px solid #E2E8F0;
                border-radius: 6px;
                margin-bottom: 12px;
                background: #FFFFFF;
                overflow: hidden;
                transition: border-color 0.2s, box-shadow 0.2s;
            }
            .demiap-acc-item:hover { border-color: #CBD5E1; }
            .demiap-acc-item.is-open { box-shadow: 0 2px 6px rgba(0,0,0,0.04); border-color: #94A3B8; }
            
            .demiap-acc-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 12px 16px;
                background: #F8FAFC;
                cursor: pointer;
                user-select: none;
                transition: background 0.2s;
            }
            .demiap-acc-header:hover { background: #F1F5F9; }
            .demiap-acc-item.is-open .demiap-acc-header { background: #EEF2F6; border-bottom: 1px solid #E2E8F0; }
            
            .demiap-acc-title {
                display: flex;
                align-items: center;
                gap: 10px;
                font-weight: 600;
                font-size: 14px;
                color: #1E293B;
            }
            .demiap-acc-badge {
                font-size: 11px;
                font-weight: 700;
                padding: 2px 8px;
                border-radius: 12px;
                background: #E2E8F0;
                color: #475569;
            }
            .demiap-acc-icon {
                font-size: 12px;
                color: #64748B;
                transition: transform 0.2s ease-in-out;
            }
            .demiap-acc-item.is-open .demiap-acc-icon { transform: rotate(90deg); }

            .demiap-acc-body {
                display: none;
                padding: 16px 20px;
                background: #FFFFFF;
            }
            .demiap-acc-item.is-open .demiap-acc-body { display: block; }

            /* Form Elements */
            .demiap-form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 12px; }
            .demiap-form-group { margin-bottom: 14px; }
            .demiap-form-group:last-child { margin-bottom: 0; }
            .demiap-form-group label { display: block; font-weight: 600; color: #334155; margin-bottom: 4px; font-size: 12px; text-transform: uppercase; letter-spacing: 0.03em; }
            .demiap-form-group .demiap-help { font-size: 11px; color: #64748B; margin-top: 3px; }
            
            .demiap-form-group input[type="text"],
            .demiap-form-group input[type="url"],
            .demiap-form-group textarea {
                width: 100%;
                border: 1px solid #CBD5E1;
                border-radius: 4px;
                padding: 8px 10px;
                font-size: 13px;
                line-height: 1.5;
                color: #1E293B;
                box-sizing: border-box;
                transition: border-color 0.2s, box-shadow 0.2s;
            }
            .demiap-form-group input[type="text"]:focus,
            .demiap-form-group input[type="url"]:focus,
            .demiap-form-group textarea:focus {
                border-color: #193256;
                outline: none;
                box-shadow: 0 0 0 2px rgba(25, 50, 86, 0.15);
            }
            .demiap-form-group textarea { resize: vertical; min-height: 60px; }

            /* Sticky Save Bar */
            .demiap-sticky-bar {
                position: sticky;
                bottom: 15px;
                background: #FFFFFF;
                border: 1px solid #CBD5E1;
                border-top: 3px solid #193256;
                padding: 12px 20px;
                box-shadow: 0 8px 20px rgba(0,0,0,0.12);
                border-radius: 6px;
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-top: 25px;
                z-index: 100;
            }
            .demiap-sticky-bar .demiap-status { font-size: 13px; color: #475569; }
            .demiap-save-btn {
                background: #E7363B !important;
                border-color: #E7363B !important;
                color: #FFFFFF !important;
                font-weight: 700 !important;
                padding: 8px 28px !important;
                height: auto !important;
                font-size: 14px !important;
                border-radius: 4px !important;
                box-shadow: 0 2px 4px rgba(231, 54, 59, 0.2) !important;
                cursor: pointer;
                transition: background 0.2s !important;
            }
            .demiap-save-btn:hover { background: #CC2027 !important; border-color: #CC2027 !important; }
        </style>

        <form method="POST" action="">
            <?php wp_nonce_field('demiap_save_attivita_action', 'demiap_attivita_nonce'); ?>
            <input type="hidden" name="demiap_active_tab" id="demiap_active_tab" value="<?php echo esc_attr($active_tab); ?>" />

            <!-- Tab Buttons -->
            <div class="demiap-tab-nav">
                <button type="button" class="demiap-tab-btn active" data-tab="tab-sociali" onclick="demiapSwitchTab(event, 'tab-sociali')">1. Attività Sociali</button>
                <button type="button" class="demiap-tab-btn" data-tab="tab-preghiera" onclick="demiapSwitchTab(event, 'tab-preghiera')">2. Ministero di Preghiera</button>
                <button type="button" class="demiap-tab-btn" data-tab="tab-sostegno" onclick="demiapSwitchTab(event, 'tab-sostegno')">3. Attività di Sostegno</button>
                <button type="button" class="demiap-tab-btn" data-tab="tab-collaborazioni" onclick="demiapSwitchTab(event, 'tab-collaborazioni')">4. Collaborazioni</button>
            </div>

            <!-- ========================================================================= -->
            <!-- TAB 1: ATTIVITÀ SOCIALI                                                   -->
            <!-- ========================================================================= -->
            <div id="tab-sociali" class="demiap-tab-pane active">
                <div class="demiap-tab-toolbar">
                    <h2>Sezione: Attività Sociali & Progetti</h2>
                    <div>
                        <button type="button" class="demiap-tool-btn" onclick="demiapToggleAll('tab-sociali', true)">Espandi tutto</button> |
                        <button type="button" class="demiap-tool-btn" onclick="demiapToggleAll('tab-sociali', false)">Riduci tutto</button>
                    </div>
                </div>

                <!-- Accordion: Intestazione Pagina -->
                <div class="demiap-acc-item">
                    <div class="demiap-acc-header" onclick="demiapToggleAcc(this)">
                        <div class="demiap-acc-title">
                            <span class="demiap-acc-icon">&#9654;</span>
                            <span>Intestazione Generale della Pagina</span>
                            <span class="demiap-acc-badge">Globale</span>
                        </div>
                    </div>
                    <div class="demiap-acc-body">
                        <div class="demiap-form-row">
                            <div class="demiap-form-group">
                                <label>Titolo Pagina (H1)</label>
                                <input type="text" name="page_title" value="<?php echo esc_attr($data['page_title']); ?>" />
                            </div>
                            <div class="demiap-form-group">
                                <label>Sottotitolo / Didascalia Pagina</label>
                                <textarea name="page_subtitle" rows="2"><?php echo esc_textarea($data['page_subtitle']); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Accordion: Intro Attività Sociali -->
                <div class="demiap-acc-item">
                    <div class="demiap-acc-header" onclick="demiapToggleAcc(this)">
                        <div class="demiap-acc-title">
                            <span class="demiap-acc-icon">&#9654;</span>
                            <span>Testo Introduttivo — Attività Sociali</span>
                            <span class="demiap-acc-badge">Introduzione</span>
                        </div>
                    </div>
                    <div class="demiap-acc-body">
                        <div class="demiap-form-group">
                            <label>Titolo della Sezione</label>
                            <input type="text" name="sociali_title" value="<?php echo esc_attr($data['sociali_title']); ?>" />
                        </div>
                        <div class="demiap-form-group">
                            <label>Testo Introduttivo Generale (Paragrafi)</label>
                            <textarea name="sociali_intro" rows="6"><?php echo esc_textarea($data['sociali_intro']); ?></textarea>
                            <div class="demiap-help">I ritorni a capo verranno convertiti automaticamente in paragrafi puliti.</div>
                        </div>
                    </div>
                </div>

                <!-- Accordion: L'Angolino -->
                <div class="demiap-acc-item">
                    <div class="demiap-acc-header" onclick="demiapToggleAcc(this)">
                        <div class="demiap-acc-title">
                            <span class="demiap-acc-icon">&#9654;</span>
                            <span>Progetto: L'Angolino</span>
                            <span class="demiap-acc-badge" style="background:#DBEAFE; color:#1E40AF;">Muralto</span>
                        </div>
                    </div>
                    <div class="demiap-acc-body">
                        <div class="demiap-form-row">
                            <div class="demiap-form-group">
                                <label>Titolo Progetto</label>
                                <input type="text" name="angolino_title" value="<?php echo esc_attr($data['angolino_title']); ?>" />
                            </div>
                            <div class="demiap-form-group">
                                <label>Luogo di Svolgimento</label>
                                <input type="text" name="angolino_luogo" value="<?php echo esc_attr($data['angolino_luogo']); ?>" />
                            </div>
                        </div>
                        <div class="demiap-form-group">
                            <label>Obiettivo del Progetto</label>
                            <textarea name="angolino_obiettivo" rows="3"><?php echo esc_textarea($data['angolino_obiettivo']); ?></textarea>
                        </div>
                        <div class="demiap-form-row">
                            <div class="demiap-form-group">
                                <label>Attività Proposte (una per riga)</label>
                                <textarea name="angolino_attivita" rows="3"><?php echo esc_textarea($data['angolino_attivita']); ?></textarea>
                            </div>
                            <div class="demiap-form-group">
                                <label>Accoglienza (una per riga)</label>
                                <textarea name="angolino_accoglienza" rows="3"><?php echo esc_textarea($data['angolino_accoglienza']); ?></textarea>
                            </div>
                        </div>
                        <div class="demiap-form-row">
                            <div class="demiap-form-group">
                                <label>Destinatari (uno per riga)</label>
                                <textarea name="angolino_destinatari" rows="3"><?php echo esc_textarea($data['angolino_destinatari']); ?></textarea>
                            </div>
                            <div class="demiap-form-group">
                                <label>Scopi (uno per riga)</label>
                                <textarea name="angolino_scopi" rows="3"><?php echo esc_textarea($data['angolino_scopi']); ?></textarea>
                            </div>
                        </div>
                        <div class="demiap-form-group">
                            <label>Conclusioni</label>
                            <textarea name="angolino_conclusioni" rows="3"><?php echo esc_textarea($data['angolino_conclusioni']); ?></textarea>
                        </div>
                    </div>
                </div>

                <!-- Accordion: L'Orticino -->
                <div class="demiap-acc-item">
                    <div class="demiap-acc-header" onclick="demiapToggleAcc(this)">
                        <div class="demiap-acc-title">
                            <span class="demiap-acc-icon">&#9654;</span>
                            <span>Progetto: L'Orticino</span>
                            <span class="demiap-acc-badge" style="background:#DCFCE7; color:#166534;">Sant’Antonino</span>
                        </div>
                    </div>
                    <div class="demiap-acc-body">
                        <div class="demiap-form-row">
                            <div class="demiap-form-group">
                                <label>Titolo Progetto</label>
                                <input type="text" name="orticino_title" value="<?php echo esc_attr($data['orticino_title']); ?>" />
                            </div>
                            <div class="demiap-form-group">
                                <label>Luogo di Svolgimento</label>
                                <input type="text" name="orticino_luogo" value="<?php echo esc_attr($data['orticino_luogo']); ?>" />
                            </div>
                        </div>
                        <div class="demiap-form-group">
                            <label>Obiettivo del Progetto</label>
                            <textarea name="orticino_obiettivo" rows="3"><?php echo esc_textarea($data['orticino_obiettivo']); ?></textarea>
                        </div>
                        <div class="demiap-form-row">
                            <div class="demiap-form-group">
                                <label>Attività Proposte (una per riga)</label>
                                <textarea name="orticino_attivita" rows="3"><?php echo esc_textarea($data['orticino_attivita']); ?></textarea>
                            </div>
                            <div class="demiap-form-group">
                                <label>Accoglienza (una per riga)</label>
                                <textarea name="orticino_accoglienza" rows="3"><?php echo esc_textarea($data['orticino_accoglienza']); ?></textarea>
                            </div>
                        </div>
                        <div class="demiap-form-row">
                            <div class="demiap-form-group">
                                <label>Destinatari (uno per riga)</label>
                                <textarea name="orticino_destinatari" rows="3"><?php echo esc_textarea($data['orticino_destinatari']); ?></textarea>
                            </div>
                            <div class="demiap-form-group">
                                <label>Scopi (uno per riga)</label>
                                <textarea name="orticino_scopi" rows="3"><?php echo esc_textarea($data['orticino_scopi']); ?></textarea>
                            </div>
                        </div>
                        <div class="demiap-form-group">
                            <label>Conclusione</label>
                            <textarea name="orticino_conclusioni" rows="3"><?php echo esc_textarea($data['orticino_conclusioni']); ?></textarea>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ========================================================================= -->
            <!-- TAB 2: MINISTERO DI PREGHIERA                                             -->
            <!-- ========================================================================= -->
            <div id="tab-preghiera" class="demiap-tab-pane">
                <div class="demiap-tab-toolbar">
                    <h2>Sezione: Ministero di Preghiera</h2>
                    <div>
                        <button type="button" class="demiap-tool-btn" onclick="demiapToggleAll('tab-preghiera', true)">Espandi tutto</button> |
                        <button type="button" class="demiap-tool-btn" onclick="demiapToggleAll('tab-preghiera', false)">Riduci tutto</button>
                    </div>
                </div>

                <!-- Intro Preghiera -->
                <div class="demiap-acc-item">
                    <div class="demiap-acc-header" onclick="demiapToggleAcc(this)">
                        <div class="demiap-acc-title">
                            <span class="demiap-acc-icon">&#9654;</span>
                            <span>Descrizione Generale & Mezzi Utilizzati</span>
                            <span class="demiap-acc-badge">Introduzione</span>
                        </div>
                    </div>
                    <div class="demiap-acc-body">
                        <div class="demiap-form-group">
                            <label>Titolo della Sezione</label>
                            <input type="text" name="preghiera_title" value="<?php echo esc_attr($data['preghiera_title']); ?>" />
                        </div>
                        <div class="demiap-form-group">
                            <label>Descrizione Generale (dal PDF)</label>
                            <textarea name="preghiera_desc_generale" rows="4"><?php echo esc_textarea($data['preghiera_desc_generale']); ?></textarea>
                        </div>
                        <div class="demiap-form-group">
                            <label>Introduzione Mezzi Utilizzati</label>
                            <input type="text" name="preghiera_mezzi_intro" value="<?php echo esc_attr($data['preghiera_mezzi_intro']); ?>" />
                        </div>
                    </div>
                </div>

                <!-- 1. Scuola di Preghiera -->
                <div class="demiap-acc-item">
                    <div class="demiap-acc-header" onclick="demiapToggleAcc(this)">
                        <div class="demiap-acc-title">
                            <span class="demiap-acc-icon">&#9654;</span>
                            <span>1. Scuola di Preghiera</span>
                        </div>
                    </div>
                    <div class="demiap-acc-body">
                        <div class="demiap-form-group">
                            <label>Titolo</label>
                            <input type="text" name="preghiera_scuola_titolo" value="<?php echo esc_attr($data['preghiera_scuola_titolo']); ?>" />
                        </div>
                        <div class="demiap-form-group">
                            <label>Descrizione</label>
                            <textarea name="preghiera_scuola_testo" rows="2"><?php echo esc_textarea($data['preghiera_scuola_testo']); ?></textarea>
                        </div>
                    </div>
                </div>

                <!-- 2. Tempi in Comune -->
                <div class="demiap-acc-item">
                    <div class="demiap-acc-header" onclick="demiapToggleAcc(this)">
                        <div class="demiap-acc-title">
                            <span class="demiap-acc-icon">&#9654;</span>
                            <span>2. Tempi di Preghiera in Comune</span>
                        </div>
                    </div>
                    <div class="demiap-acc-body">
                        <div class="demiap-form-group">
                            <label>Titolo</label>
                            <input type="text" name="preghiera_comune_titolo" value="<?php echo esc_attr($data['preghiera_comune_titolo']); ?>" />
                        </div>
                        <div class="demiap-form-group">
                            <label>Descrizione</label>
                            <textarea name="preghiera_comune_testo" rows="2"><?php echo esc_textarea($data['preghiera_comune_testo']); ?></textarea>
                        </div>
                    </div>
                </div>

                <!-- 3. 1° Agosto -->
                <div class="demiap-acc-item">
                    <div class="demiap-acc-header" onclick="demiapToggleAcc(this)">
                        <div class="demiap-acc-title">
                            <span class="demiap-acc-icon">&#9654;</span>
                            <span>3. 1° Agosto</span>
                        </div>
                    </div>
                    <div class="demiap-acc-body">
                        <div class="demiap-form-group">
                            <label>Titolo</label>
                            <input type="text" name="preghiera_agosto_titolo" value="<?php echo esc_attr($data['preghiera_agosto_titolo']); ?>" />
                        </div>
                        <div class="demiap-form-group">
                            <label>Descrizione</label>
                            <textarea name="preghiera_agosto_testo" rows="2"><?php echo esc_textarea($data['preghiera_agosto_testo']); ?></textarea>
                        </div>
                    </div>
                </div>

                <!-- 4. Digiuno Federale -->
                <div class="demiap-acc-item">
                    <div class="demiap-acc-header" onclick="demiapToggleAcc(this)">
                        <div class="demiap-acc-title">
                            <span class="demiap-acc-icon">&#9654;</span>
                            <span>4. Digiuno Federale (con link)</span>
                        </div>
                    </div>
                    <div class="demiap-acc-body">
                        <div class="demiap-form-group">
                            <label>Titolo</label>
                            <input type="text" name="preghiera_digiuno_titolo" value="<?php echo esc_attr($data['preghiera_digiuno_titolo']); ?>" />
                        </div>
                        <div class="demiap-form-group">
                            <label>Descrizione</label>
                            <textarea name="preghiera_digiuno_testo" rows="2"><?php echo esc_textarea($data['preghiera_digiuno_testo']); ?></textarea>
                        </div>
                        <div class="demiap-form-row">
                            <div class="demiap-form-group">
                                <label>URL Link</label>
                                <input type="url" name="preghiera_digiuno_url" value="<?php echo esc_attr($data['preghiera_digiuno_url']); ?>" />
                            </div>
                            <div class="demiap-form-group">
                                <label>Etichetta Testo Link</label>
                                <input type="text" name="preghiera_digiuno_label" value="<?php echo esc_attr($data['preghiera_digiuno_label']); ?>" />
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 5. Catene di Preghiera -->
                <div class="demiap-acc-item">
                    <div class="demiap-acc-header" onclick="demiapToggleAcc(this)">
                        <div class="demiap-acc-title">
                            <span class="demiap-acc-icon">&#9654;</span>
                            <span>5. Catene di Preghiera</span>
                        </div>
                    </div>
                    <div class="demiap-acc-body">
                        <div class="demiap-form-group">
                            <label>Titolo</label>
                            <input type="text" name="preghiera_catene_titolo" value="<?php echo esc_attr($data['preghiera_catene_titolo']); ?>" />
                        </div>
                        <div class="demiap-form-group">
                            <label>Descrizione</label>
                            <textarea name="preghiera_catene_testo" rows="2"><?php echo esc_textarea($data['preghiera_catene_testo']); ?></textarea>
                        </div>
                    </div>
                </div>

                <!-- 6. Incontri Intercantonali (Oberalp) -->
                <div class="demiap-acc-item">
                    <div class="demiap-acc-header" onclick="demiapToggleAcc(this)">
                        <div class="demiap-acc-title">
                            <span class="demiap-acc-icon">&#9654;</span>
                            <span>6. Incontri di Preghiera Intercantonali (Oberalp)</span>
                        </div>
                    </div>
                    <div class="demiap-acc-body">
                        <div class="demiap-form-group">
                            <label>Titolo</label>
                            <input type="text" name="preghiera_intercantonali_titolo" value="<?php echo esc_attr($data['preghiera_intercantonali_titolo']); ?>" />
                        </div>
                        <div class="demiap-form-group">
                            <label>Descrizione</label>
                            <textarea name="preghiera_intercantonali_testo" rows="2"><?php echo esc_textarea($data['preghiera_intercantonali_testo']); ?></textarea>
                        </div>
                        <div class="demiap-form-row">
                            <div class="demiap-form-group">
                                <label>URL Link Evento</label>
                                <input type="url" name="preghiera_intercantonali_url" value="<?php echo esc_attr($data['preghiera_intercantonali_url']); ?>" />
                            </div>
                            <div class="demiap-form-group">
                                <label>Etichetta Testo Link</label>
                                <input type="text" name="preghiera_intercantonali_label" value="<?php echo esc_attr($data['preghiera_intercantonali_label']); ?>" />
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 7. Uscite nel Territorio -->
                <div class="demiap-acc-item">
                    <div class="demiap-acc-header" onclick="demiapToggleAcc(this)">
                        <div class="demiap-acc-title">
                            <span class="demiap-acc-icon">&#9654;</span>
                            <span>7. Uscite di Preghiera nel Territorio</span>
                        </div>
                    </div>
                    <div class="demiap-acc-body">
                        <div class="demiap-form-group">
                            <label>Titolo</label>
                            <input type="text" name="preghiera_territorio_titolo" value="<?php echo esc_attr($data['preghiera_territorio_titolo']); ?>" />
                        </div>
                        <div class="demiap-form-group">
                            <label>Descrizione</label>
                            <textarea name="preghiera_territorio_testo" rows="2"><?php echo esc_textarea($data['preghiera_territorio_testo']); ?></textarea>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ========================================================================= -->
            <!-- TAB 3: ATTIVITÀ DI SOSTEGNO                                               -->
            <!-- ========================================================================= -->
            <div id="tab-sostegno" class="demiap-tab-pane">
                <div class="demiap-tab-toolbar">
                    <h2>Sezione: Attività di Sostegno (Fisarmoniche)</h2>
                    <div>
                        <button type="button" class="demiap-tool-btn" onclick="demiapToggleAll('tab-sostegno', true)">Espandi tutto</button> |
                        <button type="button" class="demiap-tool-btn" onclick="demiapToggleAll('tab-sostegno', false)">Riduci tutto</button>
                    </div>
                </div>

                <!-- Intro Sostegno -->
                <div class="demiap-acc-item">
                    <div class="demiap-acc-header" onclick="demiapToggleAcc(this)">
                        <div class="demiap-acc-title">
                            <span class="demiap-acc-icon">&#9654;</span>
                            <span>Descrizione Generale — Attività di Sostegno</span>
                            <span class="demiap-acc-badge">Introduzione</span>
                        </div>
                    </div>
                    <div class="demiap-acc-body">
                        <div class="demiap-form-group">
                            <label>Titolo della Sezione</label>
                            <input type="text" name="sostegno_title" value="<?php echo esc_attr($data['sostegno_title']); ?>" />
                        </div>
                        <div class="demiap-form-group">
                            <label>Descrizione Generale (dal PDF)</label>
                            <textarea name="sostegno_desc_generale" rows="3"><?php echo esc_textarea($data['sostegno_desc_generale']); ?></textarea>
                        </div>
                    </div>
                </div>

                <!-- 1. Imprenditori Cristiani -->
                <div class="demiap-acc-item">
                    <div class="demiap-acc-header" onclick="demiapToggleAcc(this)">
                        <div class="demiap-acc-title">
                            <span class="demiap-acc-icon">&#9654;</span>
                            <span>1. Gruppo Imprenditori Cristiani</span>
                        </div>
                    </div>
                    <div class="demiap-acc-body">
                        <div class="demiap-form-row">
                            <div class="demiap-form-group">
                                <label>Titolo Fisarmonica</label>
                                <input type="text" name="sostegno_imprenditori_tag" value="<?php echo esc_attr($data['sostegno_imprenditori_tag']); ?>" />
                            </div>
                            <div class="demiap-form-group">
                                <label>Sottotitolo Interno</label>
                                <input type="text" name="sostegno_imprenditori_sottotitolo" value="<?php echo esc_attr($data['sostegno_imprenditori_sottotitolo']); ?>" />
                            </div>
                        </div>
                        <div class="demiap-form-group">
                            <label>Testo Completo</label>
                            <textarea name="sostegno_imprenditori_testo" rows="4"><?php echo esc_textarea($data['sostegno_imprenditori_testo']); ?></textarea>
                        </div>
                        <div class="demiap-form-group">
                            <label>Box Offerte / Informazioni</label>
                            <input type="text" name="sostegno_imprenditori_box" value="<?php echo esc_attr($data['sostegno_imprenditori_box']); ?>" />
                        </div>
                    </div>
                </div>

                <!-- 2. Palazzo Federale -->
                <div class="demiap-acc-item">
                    <div class="demiap-acc-header" onclick="demiapToggleAcc(this)">
                        <div class="demiap-acc-title">
                            <span class="demiap-acc-icon">&#9654;</span>
                            <span>2. Preghiera a Palazzo Federale (Berna)</span>
                        </div>
                    </div>
                    <div class="demiap-acc-body">
                        <div class="demiap-form-row">
                            <div class="demiap-form-group">
                                <label>Titolo Fisarmonica</label>
                                <input type="text" name="sostegno_palazzo_tag" value="<?php echo esc_attr($data['sostegno_palazzo_tag']); ?>" />
                            </div>
                            <div class="demiap-form-group">
                                <label>Sottotitolo Interno</label>
                                <input type="text" name="sostegno_palazzo_sottotitolo" value="<?php echo esc_attr($data['sostegno_palazzo_sottotitolo']); ?>" />
                            </div>
                        </div>
                        <div class="demiap-form-group">
                            <label>Testo Completo (Paragrafi e Sessioni)</label>
                            <textarea name="sostegno_palazzo_testo" rows="6"><?php echo esc_textarea($data['sostegno_palazzo_testo']); ?></textarea>
                        </div>
                        <div class="demiap-form-group">
                            <label>Box Offerte / Informazioni</label>
                            <textarea name="sostegno_palazzo_box" rows="2"><?php echo esc_textarea($data['sostegno_palazzo_box']); ?></textarea>
                        </div>
                        <div class="demiap-form-row">
                            <div class="demiap-form-group">
                                <label>URL Video RSI</label>
                                <input type="url" name="sostegno_palazzo_video_url" value="<?php echo esc_attr($data['sostegno_palazzo_video_url']); ?>" />
                            </div>
                            <div class="demiap-form-group">
                                <label>Etichetta Link Video</label>
                                <input type="text" name="sostegno_palazzo_video_label" value="<?php echo esc_attr($data['sostegno_palazzo_video_label']); ?>" />
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 3. Preghiera per la Nazione -->
                <div class="demiap-acc-item">
                    <div class="demiap-acc-header" onclick="demiapToggleAcc(this)">
                        <div class="demiap-acc-title">
                            <span class="demiap-acc-icon">&#9654;</span>
                            <span>3. Servizio di Preghiera per la Nazione</span>
                        </div>
                    </div>
                    <div class="demiap-acc-body">
                        <div class="demiap-form-row">
                            <div class="demiap-form-group">
                                <label>Titolo Fisarmonica</label>
                                <input type="text" name="sostegno_nazione_tag" value="<?php echo esc_attr($data['sostegno_nazione_tag']); ?>" />
                            </div>
                            <div class="demiap-form-group">
                                <label>Sottotitolo Interno</label>
                                <input type="text" name="sostegno_nazione_sottotitolo" value="<?php echo esc_attr($data['sostegno_nazione_sottotitolo']); ?>" />
                            </div>
                        </div>
                        <div class="demiap-form-group">
                            <label>Testo Completo</label>
                            <textarea name="sostegno_nazione_testo" rows="3"><?php echo esc_textarea($data['sostegno_nazione_testo']); ?></textarea>
                        </div>
                        <div class="demiap-form-group">
                            <label>Box Offerte / Sostegno</label>
                            <input type="text" name="sostegno_nazione_box" value="<?php echo esc_attr($data['sostegno_nazione_box']); ?>" />
                        </div>
                    </div>
                </div>

                <!-- 4. Autorità Cantonali -->
                <div class="demiap-acc-item">
                    <div class="demiap-acc-header" onclick="demiapToggleAcc(this)">
                        <div class="demiap-acc-title">
                            <span class="demiap-acc-icon">&#9654;</span>
                            <span>4. Preghiera per le Autorità Cantonali</span>
                        </div>
                    </div>
                    <div class="demiap-acc-body">
                        <div class="demiap-form-row">
                            <div class="demiap-form-group">
                                <label>Titolo Fisarmonica</label>
                                <input type="text" name="sostegno_cantonali_tag" value="<?php echo esc_attr($data['sostegno_cantonali_tag']); ?>" />
                            </div>
                            <div class="demiap-form-group">
                                <label>Sottotitolo Interno</label>
                                <input type="text" name="sostegno_cantonali_sottotitolo" value="<?php echo esc_attr($data['sostegno_cantonali_sottotitolo']); ?>" />
                            </div>
                        </div>
                        <div class="demiap-form-group">
                            <label>Testo Completo</label>
                            <textarea name="sostegno_cantonali_testo" rows="3"><?php echo esc_textarea($data['sostegno_cantonali_testo']); ?></textarea>
                        </div>
                    </div>
                </div>

                <!-- 5. Polizia -->
                <div class="demiap-acc-item">
                    <div class="demiap-acc-header" onclick="demiapToggleAcc(this)">
                        <div class="demiap-acc-title">
                            <span class="demiap-acc-icon">&#9654;</span>
                            <span>5. Gruppo Poliziotti Cristiani</span>
                        </div>
                    </div>
                    <div class="demiap-acc-body">
                        <div class="demiap-form-row">
                            <div class="demiap-form-group">
                                <label>Titolo Fisarmonica</label>
                                <input type="text" name="sostegno_polizia_tag" value="<?php echo esc_attr($data['sostegno_polizia_tag']); ?>" />
                            </div>
                            <div class="demiap-form-group">
                                <label>Sottotitolo Interno</label>
                                <input type="text" name="sostegno_polizia_sottotitolo" value="<?php echo esc_attr($data['sostegno_polizia_sottotitolo']); ?>" />
                            </div>
                        </div>
                        <div class="demiap-form-group">
                            <label>Testo Completo</label>
                            <textarea name="sostegno_polizia_testo" rows="3"><?php echo esc_textarea($data['sostegno_polizia_testo']); ?></textarea>
                        </div>
                        <div class="demiap-form-group">
                            <label>Box Offerte / Sostegno</label>
                            <textarea name="sostegno_polizia_box" rows="2"><?php echo esc_textarea($data['sostegno_polizia_box']); ?></textarea>
                        </div>
                    </div>
                </div>

                <!-- 6. Bisogni Personali -->
                <div class="demiap-acc-item">
                    <div class="demiap-acc-header" onclick="demiapToggleAcc(this)">
                        <div class="demiap-acc-title">
                            <span class="demiap-acc-icon">&#9654;</span>
                            <span>6. Bisogni Specifici Personali (Intercessione WhatsApp)</span>
                        </div>
                    </div>
                    <div class="demiap-acc-body">
                        <div class="demiap-form-row">
                            <div class="demiap-form-group">
                                <label>Titolo Fisarmonica</label>
                                <input type="text" name="sostegno_personali_tag" value="<?php echo esc_attr($data['sostegno_personali_tag']); ?>" />
                            </div>
                            <div class="demiap-form-group">
                                <label>Sottotitolo Interno</label>
                                <input type="text" name="sostegno_personali_sottotitolo" value="<?php echo esc_attr($data['sostegno_personali_sottotitolo']); ?>" />
                            </div>
                        </div>
                        <div class="demiap-form-group">
                            <label>Testo Completo</label>
                            <textarea name="sostegno_personali_testo" rows="4"><?php echo esc_textarea($data['sostegno_personali_testo']); ?></textarea>
                        </div>
                        <div class="demiap-form-group">
                            <label>Box Contatto</label>
                            <textarea name="sostegno_personali_box" rows="2"><?php echo esc_textarea($data['sostegno_personali_box']); ?></textarea>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ========================================================================= -->
            <!-- TAB 4: COLLABORAZIONI                                                     -->
            <!-- ========================================================================= -->
            <div id="tab-collaborazioni" class="demiap-tab-pane">
                <div class="demiap-tab-toolbar">
                    <h2>Sezione: Collaborazioni</h2>
                    <div>
                        <button type="button" class="demiap-tool-btn" onclick="demiapToggleAll('tab-collaborazioni', true)">Espandi tutto</button> |
                        <button type="button" class="demiap-tool-btn" onclick="demiapToggleAll('tab-collaborazioni', false)">Riduci tutto</button>
                    </div>
                </div>

                <!-- Intro Collaborazioni -->
                <div class="demiap-acc-item">
                    <div class="demiap-acc-header" onclick="demiapToggleAcc(this)">
                        <div class="demiap-acc-title">
                            <span class="demiap-acc-icon">&#9654;</span>
                            <span>Descrizione Generale — Collaborazioni</span>
                            <span class="demiap-acc-badge">Introduzione</span>
                        </div>
                    </div>
                    <div class="demiap-acc-body">
                        <div class="demiap-form-group">
                            <label>Titolo della Sezione</label>
                            <input type="text" name="collab_title" value="<?php echo esc_attr($data['collab_title']); ?>" />
                        </div>
                        <div class="demiap-form-group">
                            <label>Descrizione Generale (dal PDF)</label>
                            <textarea name="collab_desc_generale" rows="2"><?php echo esc_textarea($data['collab_desc_generale']); ?></textarea>
                        </div>
                    </div>
                </div>

                <!-- 1. CH-CH -->
                <div class="demiap-acc-item">
                    <div class="demiap-acc-header" onclick="demiapToggleAcc(this)">
                        <div class="demiap-acc-title">
                            <span class="demiap-acc-icon">&#9654;</span>
                            <span>1. CH-CH Cristiani per la Svizzera</span>
                        </div>
                    </div>
                    <div class="demiap-acc-body">
                        <div class="demiap-form-group">
                            <label>Nome Ente / Titolo</label>
                            <input type="text" name="collab1_nome" value="<?php echo esc_attr($data['collab1_nome']); ?>" />
                        </div>
                        <div class="demiap-form-group">
                            <label>Descrizione</label>
                            <textarea name="collab1_desc" rows="3"><?php echo esc_textarea($data['collab1_desc']); ?></textarea>
                        </div>
                        <div class="demiap-form-row">
                            <div class="demiap-form-group">
                                <label>URL Sito Web</label>
                                <input type="url" name="collab1_url" value="<?php echo esc_attr($data['collab1_url']); ?>" />
                            </div>
                            <div class="demiap-form-group">
                                <label>Etichetta Testo Link</label>
                                <input type="text" name="collab1_label" value="<?php echo esc_attr($data['collab1_label']); ?>" />
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 2. Pro Autoritas -->
                <div class="demiap-acc-item">
                    <div class="demiap-acc-header" onclick="demiapToggleAcc(this)">
                        <div class="demiap-acc-title">
                            <span class="demiap-acc-icon">&#9654;</span>
                            <span>2. Pro Autoritas & Gruppo Preghiera Palazzo Federale</span>
                        </div>
                    </div>
                    <div class="demiap-acc-body">
                        <div class="demiap-form-group">
                            <label>Nome Ente / Titolo</label>
                            <input type="text" name="collab2_nome" value="<?php echo esc_attr($data['collab2_nome']); ?>" />
                        </div>
                        <div class="demiap-form-group">
                            <label>Descrizione</label>
                            <textarea name="collab2_desc" rows="3"><?php echo esc_textarea($data['collab2_desc']); ?></textarea>
                        </div>
                        <div class="demiap-form-row">
                            <div class="demiap-form-group">
                                <label>URL Eventuale Bollettino</label>
                                <input type="text" name="collab2_url" value="<?php echo esc_attr($data['collab2_url']); ?>" />
                            </div>
                            <div class="demiap-form-group">
                                <label>Etichetta Testo Link</label>
                                <input type="text" name="collab2_label" value="<?php echo esc_attr($data['collab2_label']); ?>" />
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 3. La Bussola -->
                <div class="demiap-acc-item">
                    <div class="demiap-acc-header" onclick="demiapToggleAcc(this)">
                        <div class="demiap-acc-title">
                            <span class="demiap-acc-icon">&#9654;</span>
                            <span>3. Associazione La Bussola</span>
                        </div>
                    </div>
                    <div class="demiap-acc-body">
                        <div class="demiap-form-group">
                            <label>Nome Ente / Titolo</label>
                            <input type="text" name="collab3_nome" value="<?php echo esc_attr($data['collab3_nome']); ?>" />
                        </div>
                        <div class="demiap-form-group">
                            <label>Descrizione</label>
                            <textarea name="collab3_desc" rows="2"><?php echo esc_textarea($data['collab3_desc']); ?></textarea>
                        </div>
                        <div class="demiap-form-row">
                            <div class="demiap-form-group">
                                <label>URL Eventuale Link</label>
                                <input type="text" name="collab3_url" value="<?php echo esc_attr($data['collab3_url']); ?>" />
                            </div>
                            <div class="demiap-form-group">
                                <label>Etichetta Testo Link</label>
                                <input type="text" name="collab3_label" value="<?php echo esc_attr($data['collab3_label']); ?>" />
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 4. Kingdom Dance -->
                <div class="demiap-acc-item">
                    <div class="demiap-acc-header" onclick="demiapToggleAcc(this)">
                        <div class="demiap-acc-title">
                            <span class="demiap-acc-icon">&#9654;</span>
                            <span>4. Kingdom Dance</span>
                        </div>
                    </div>
                    <div class="demiap-acc-body">
                        <div class="demiap-form-group">
                            <label>Nome Ente / Titolo</label>
                            <input type="text" name="collab4_nome" value="<?php echo esc_attr($data['collab4_nome']); ?>" />
                        </div>
                        <div class="demiap-form-group">
                            <label>Descrizione</label>
                            <textarea name="collab4_desc" rows="2"><?php echo esc_textarea($data['collab4_desc']); ?></textarea>
                        </div>
                        <div class="demiap-form-row">
                            <div class="demiap-form-group">
                                <label>URL Eventuale Link</label>
                                <input type="text" name="collab4_url" value="<?php echo esc_attr($data['collab4_url']); ?>" />
                            </div>
                            <div class="demiap-form-group">
                                <label>Etichetta Testo Link</label>
                                <input type="text" name="collab4_label" value="<?php echo esc_attr($data['collab4_label']); ?>" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Sticky Save Bar -->
            <div class="demiap-sticky-bar">
                <div class="demiap-status">
                    Le modifiche verranno applicate immediatamente sul sito live dopo il salvataggio.
                </div>
                <button type="submit" name="demiap_save_attivita" class="button demiap-save-btn">
                    Salva Tutte le Modifiche
                </button>
            </div>
        </form>
    </div>

    <script>
    function demiapSwitchTab(e, tabId) {
        document.querySelectorAll('.demiap-tab-btn').forEach(btn => btn.classList.remove('active'));
        document.querySelectorAll('.demiap-tab-pane').forEach(pane => pane.classList.remove('active'));
        if (e && e.currentTarget) {
            e.currentTarget.classList.add('active');
        } else {
            const btn = document.querySelector('.demiap-tab-btn[data-tab="' + tabId + '"]');
            if (btn) btn.classList.add('active');
        }
        const activePane = document.getElementById(tabId);
        if (activePane) {
            activePane.classList.add('active');
        }
        const input = document.getElementById('demiap_active_tab');
        if (input) input.value = tabId;
        try { sessionStorage.setItem('demiap_active_tab', tabId); } catch(err) {}
    }

    function demiapToggleAcc(headerEl) {
        const item = headerEl.closest('.demiap-acc-item');
        if (item) {
            item.classList.toggle('is-open');
        }
    }

    function demiapToggleAll(tabId, open) {
        const pane = document.getElementById(tabId);
        if (pane) {
            pane.querySelectorAll('.demiap-acc-item').forEach(item => {
                if (open) {
                    item.classList.add('is-open');
                } else {
                    item.classList.remove('is-open');
                }
            });
        }
    }

    document.addEventListener('DOMContentLoaded', function() {
        let savedTab = null;
        try { savedTab = sessionStorage.getItem('demiap_active_tab'); } catch(err) {}
        const inputTab = document.getElementById('demiap_active_tab') ? document.getElementById('demiap_active_tab').value : null;
        const tabToActivate = inputTab || savedTab || 'tab-sociali';
        const targetBtn = document.querySelector('.demiap-tab-btn[data-tab="' + tabToActivate + '"]');
        if (targetBtn) {
            demiapSwitchTab({ currentTarget: targetBtn }, tabToActivate);
        }
    });
    </script>
    <?php
}
