<?php
/**
 * Footer: dati letti da ticinoWEB CMS (contatti, social), link legali dal menu «footer» se presente,
 * altrimenti dalla privacy policy di WordPress e dalle pagine «Termini».
 */
if (!defined('ABSPATH')) {
    exit;
}
$contact = function_exists('ticinoweb_get_contact_info') ? ticinoweb_get_contact_info() : array();
$logo    = function_exists('ticinoweb_get_site_logo') ? ticinoweb_get_site_logo() : false;
$name    = get_bloginfo('name');
$terms   = get_page_by_path('termini-e-condizioni');
?>
</main>

<footer class="dnd-footer">
    <div class="dnd-wrap dnd-footer__cta">
        <h2><?php esc_html_e('Porta la verità sulla droga nella tua scuola o associazione.', 'dico-no-alla-droga-child-theme'); ?></h2>
        <a class="dnd-btn dnd-btn--sun dnd-btn--xl" href="<?php echo esc_url(dnd_cta_url()); ?>"><?php esc_html_e('Richiedi materiale per una conferenza', 'dico-no-alla-droga-child-theme'); ?></a>
    </div>

    <div class="dnd-wrap dnd-footer__grid">
        <div class="dnd-footer__brand">
            <strong><?php echo esc_html($name); ?></strong>
            <?php if (get_bloginfo('description')) : ?><p><?php echo esc_html(get_bloginfo('description')); ?></p><?php endif; ?>
        </div>

        <div>
            <h3><?php esc_html_e('Contatti', 'dico-no-alla-droga-child-theme'); ?></h3>
            <ul class="dnd-footer__list">
                <?php if (!empty($contact['email'])) : ?>
                    <li><a href="mailto:<?php echo esc_attr($contact['email']); ?>"><?php echo esc_html($contact['email']); ?></a></li>
                <?php endif; ?>
                <?php if (!empty($contact['phone'])) : ?>
                    <li><a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/', '', $contact['phone'])); ?>"><?php echo esc_html($contact['phone']); ?></a></li>
                <?php endif; ?>
                <?php if (!empty($contact['address'])) : ?>
                    <li><?php echo esc_html($contact['address']); ?></li>
                <?php endif; ?>
            </ul>
        </div>

        <div>
            <h3><?php esc_html_e('Seguici', 'dico-no-alla-droga-child-theme'); ?></h3>
            <ul class="dnd-footer__list">
                <?php if (!empty($contact['facebook'])) : ?><li><a href="<?php echo esc_url($contact['facebook']); ?>" target="_blank" rel="noopener">Facebook</a></li><?php endif; ?>
                <?php if (!empty($contact['instagram'])) : ?><li><a href="<?php echo esc_url($contact['instagram']); ?>" target="_blank" rel="noopener">Instagram</a></li><?php endif; ?>
            </ul>
        </div>

        <div>
            <h3><?php esc_html_e('Link utili', 'dico-no-alla-droga-child-theme'); ?></h3>
            <?php $raccolta = (int) get_option('dnd_page_raccolta'); ?>
            <?php if ($raccolta && get_post_status($raccolta) === 'publish') : ?>
                <a class="dnd-footer__feature" href="<?php echo esc_url(get_permalink($raccolta)); ?>"><?php echo esc_html(get_the_title($raccolta)); ?> <span aria-hidden="true">→</span></a>
            <?php endif; ?>
            <ul class="dnd-footer__list">
                <?php $official = (string) get_option('dnd_official_site_url', ''); ?>
                <?php if ($official !== '') : ?>
                    <li><a href="<?php echo esc_url($official); ?>" target="_blank" rel="noopener"><?php esc_html_e('Sito ufficiale: Drug-Free World', 'dico-no-alla-droga-child-theme'); ?></a></li>
                <?php endif; ?>
                <?php $resoconto = (int) get_option('dnd_page_resoconto'); ?>
                <?php if ($resoconto && get_post_status($resoconto) === 'publish') : ?>
                    <li><a href="<?php echo esc_url(get_permalink($resoconto)); ?>"><?php esc_html_e('Invia il resoconto', 'dico-no-alla-droga-child-theme'); ?></a></li>
                <?php endif; ?>
                <?php if (function_exists('get_privacy_policy_url') && get_privacy_policy_url()) : ?>
                    <li><a href="<?php echo esc_url(get_privacy_policy_url()); ?>"><?php esc_html_e('Privacy Policy', 'dico-no-alla-droga-child-theme'); ?></a></li>
                <?php endif; ?>
                <?php if ($terms) : ?>
                    <li><a href="<?php echo esc_url(get_permalink($terms)); ?>"><?php echo esc_html(get_the_title($terms)); ?></a></li>
                <?php endif; ?>
                <?php do_action('ticinoweb_footer_links'); ?>
            </ul>
        </div>
    </div>

    <div class="dnd-wrap dnd-footer__bottom">
        <span>© <?php echo esc_html(wp_date('Y')); ?> <?php echo esc_html($name); ?></span>
        <span>Design by <a href="https://ticinoweb.com" target="_blank" rel="noopener">ticinoWEB</a></span>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
