<?php
/**
 * Pagine interne: fascia scura con il titolo, poi il contenuto a blocchi.
 */
get_header();
while (have_posts()) :
    the_post();
    if (is_page('iscrizione-alla-stralugano')) :
        // Fascia con foto della StraLugano: il titolo della pagina fa da sopratitolo, il messaggio è l'estratto della pagina.
        $dnd_msg = has_excerpt() ? get_the_excerpt() : get_the_title();
        ?>
    <header class="dnd-pagehead dnd-stra-hero">
        <div class="dnd-wrap dnd-stra-hero__grid">
            <a class="dnd-stra-badge" href="https://www.stralugano.ch/evento/associazioni-charity/" target="_blank" rel="noopener">
                <span class="dnd-stra-badge__icon" aria-hidden="true"></span>
                <span class="dnd-stra-badge__text">
                    <small><?php esc_html_e('Programma Charity StraLugano', 'dico-no-alla-droga-child-theme'); ?></small>
                    <strong><?php esc_html_e('Associazione ufficialmente riconosciuta', 'dico-no-alla-droga-child-theme'); ?></strong>
                </span>
            </a>
            <div class="dnd-stra-hero__text">
                <?php if (shortcode_exists('ticinoweb_breadcrumbs')) { echo do_shortcode('[ticinoweb_breadcrumbs]'); } ?>
                <a class="dnd-stra-hero__logo" href="https://www.stralugano.ch/" target="_blank" rel="noopener" aria-label="StraLugano">
                    <img src="<?php echo esc_url(get_stylesheet_directory_uri() . '/assets/img/stralugano-logo.png'); ?>" alt="StraLugano" width="900" height="246" decoding="async">
                </a>
                <h1><?php echo esc_html($dnd_msg); ?></h1>
                <div class="dnd-stra-hero__cta">
                    <a class="dnd-btn dnd-btn--sun" href="#modulo"><?php esc_html_e('Iscriviti ora', 'dico-no-alla-droga-child-theme'); ?></a>
                    <a class="dnd-btn dnd-btn--ghost" href="#gare"><?php esc_html_e('Scopri le gare', 'dico-no-alla-droga-child-theme'); ?></a>
                </div>
            </div>
        </div>
    </header>
    <?php else : ?>
    <header class="dnd-pagehead">
        <div class="dnd-wrap">
            <?php if (shortcode_exists('ticinoweb_breadcrumbs')) { echo do_shortcode('[ticinoweb_breadcrumbs]'); } ?>
            <h1><?php the_title(); ?></h1>
            <?php if (has_excerpt()) : ?><p class="dnd-pagehead__lead"><?php echo esc_html(get_the_excerpt()); ?></p><?php endif; ?>
        </div>
    </header>
    <?php endif; ?>
    <div class="dnd-content dnd-content--page">
        <div class="dnd-wrap dnd-prose"><?php the_content(); ?></div>
    </div>
    <?php
endwhile;
get_footer();
