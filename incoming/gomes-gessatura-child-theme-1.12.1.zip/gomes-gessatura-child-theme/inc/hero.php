<?php
/** Native slider data, with the child responsible only for presentation. */
defined('ABSPATH') || exit;

function gomes_get_hero_slides() {
    if (!function_exists('ticinoweb_get_slider_data')) { return array(); }
    $native = ticinoweb_get_slider_data();
    $count = max(1, min(5, (int) (get_option('ticinoweb_slider_count') ?: get_theme_mod('slider_count', 3))));
    $slides = array();
    $cursor = 0;
    for ($slot = 1; $slot <= $count; $slot++) {
        $image = get_option('ticinoweb_slider_image_' . $slot) ?: get_theme_mod('slider_image_' . $slot);
        if (!$image) { continue; }
        $slide = $native[$cursor++] ?? array();
        $image_id = is_numeric($image) ? absint($image) : attachment_url_to_postid((string) $image);
        if (!$image_id || !wp_attachment_is_image($image_id)) { continue; }
        // Parent defaults are useful for generic demos, but must not invent client content.
        $fields = array('title' => 'title', 'desc' => 'desc', 'btn_text' => 'btn1_text', 'btn_link' => 'btn1_link');
        foreach ($fields as $field => $output) {
            $fallback = in_array($field, array('btn_text', 'btn_link'), true) ? str_replace('btn_', 'btn1_', $field) : $field;
            $raw = get_option('ticinoweb_slider_' . $field . '_' . $slot) ?: get_theme_mod('slider_' . $fallback . '_' . $slot, '');
            if (trim((string) $raw) === '') { $slide[$output] = ''; }
        }
        $link = (string) ($slide['btn1_link'] ?? '');
        if (strpos($link, '#') === 0) { $link = gomes_home() . $link; }
        $slide['btn1_link'] = esc_url($link);
        $slide['image_id'] = $image_id;
        $slide['slot'] = $slot;
        $slides[] = $slide;
    }
    return $slides;
}
