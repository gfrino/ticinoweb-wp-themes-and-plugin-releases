<?php
defined('ABSPATH') || exit;
/** Editorial content stays in native Home blocks; the child owns only the scene. */
function gomes_space_cases($block) {
    $cases = array();
    foreach ($block['innerBlocks'] ?? array() as $group) {
        $mode = str_replace('scenario-', '', $group['attrs']['anchor'] ?? '');
        if (!in_array($mode, array('spazio', 'comfort', 'acustica', 'carattere', 'led'), true)) { continue; }
        $category = in_array($mode, array('comfort', 'acustica'), true) ? 'comfort' : ($mode === 'spazio' ? 'spazio' : 'carattere');
        $case = array('category' => $category, 'mode' => $mode, 'title' => '', 'paragraphs' => array(), 'image' => 0);
        foreach ($group['innerBlocks'] ?? array() as $item) {
            if ($item['blockName'] === 'core/heading') { $case['title'] = wp_strip_all_tags(render_block($item)); }
            if ($item['blockName'] === 'core/paragraph') { $case['paragraphs'][] = wp_kses_post(render_block($item)); }
            if ($item['blockName'] === 'core/image') { $case['image'] = absint($item['attrs']['id'] ?? 0); }
        }
        if ($case['title'] && count($case['paragraphs']) >= 2) { $cases[] = $case; }
    }
    return $cases;
}
function gomes_space($block) {
    $cases = gomes_space_cases($block);
    if (!$cases) { return; }
    $variant_labels = array('spazio' => __('Parete divisoria', 'gomes-gessatura'), 'comfort' => __('Controsoffitto', 'gomes-gessatura'), 'acustica' => __('Plafone acustico', 'gomes-gessatura'), 'carattere' => __('Arco in gesso', 'gomes-gessatura'), 'led' => __('Dettaglio con LED', 'gomes-gessatura'));
    $label = static fn($text, $key) => esc_html(gomes_text($text, 'space-' . $key));
    ?>
    <section id="oltre-la-superficie" class="gomes-section gomes-space" data-space data-mode="<?php echo esc_attr($cases[0]['mode']); ?>" data-phase="finished" data-night="false" data-led-on="true">
      <div class="gomes-container">
        <div class="gomes-space-heading"><?php foreach ($block['innerBlocks'] ?? array() as $group) { if (in_array('gomes-space-intro', preg_split('/\s+/', $group['attrs']['className'] ?? ''), true)) { echo wp_kses_post(render_block($group)); break; } } ?></div>
        <div class="gomes-space-choices" data-space-choices hidden>
          <?php foreach ($cases as $i => $case) : if ($case['mode'] !== $case['category']) { continue; } ?><button type="button" data-space-choice="<?php echo esc_attr($case['mode']); ?>"><?php echo esc_html(gomes_text($case['title'], 'space-case-' . $case['mode'])); ?><span aria-hidden="true">↗</span></button><?php endforeach; ?>
        </div>
        <div class="gomes-space-study" id="gomes-space-workspace">
          <div class="gomes-space-drawing">
            <div class="gomes-space-variants" data-space-variants hidden aria-label="<?php echo esc_attr(gomes_text(__('Scegli una soluzione', 'gomes-gessatura'), 'space-variant-label')); ?>" role="group">
            <?php foreach ($cases as $case) : ?><button type="button" data-space-variant="<?php echo esc_attr($case['mode']); ?>" data-category="<?php echo esc_attr($case['category']); ?>" aria-pressed="false"><?php echo $label($variant_labels[$case['mode']], 'variant-' . $case['mode']); ?></button><?php endforeach; ?>
            </div>
            <div class="gomes-space-canvas">
              <p class="gomes-space-caption"><?php echo $label(__('Uno spazio, nuove possibilità', 'gomes-gessatura'), 'canvas'); ?></p>
              <?php get_template_part('template-parts/space-model'); ?>
              <p class="gomes-space-model-note"><?php echo $label(__('Modello illustrativo · Le soluzioni si definiscono con il sopralluogo.', 'gomes-gessatura'), 'note'); ?></p>
            </div>
            <div class="gomes-space-tools" hidden>
              <div class="gomes-space-phases" role="group" aria-label="<?php echo esc_attr(gomes_text(__('Fasi della lavorazione', 'gomes-gessatura'), 'space-phases')); ?>">
              <?php foreach (array('structure' => __('Struttura', 'gomes-gessatura'), 'board' => __('Rivestimento', 'gomes-gessatura'), 'finished' => __('Finitura', 'gomes-gessatura')) as $phase => $text) : ?><button type="button" data-space-phase="<?php echo esc_attr($phase); ?>" aria-pressed="false"><?php echo $label($text, $phase); ?></button><?php endforeach; ?>
              </div>
              <p class="gomes-space-phase-note" data-space-phase-note data-structure="<?php echo esc_attr(gomes_text(__('La struttura dà forma alla soluzione.', 'gomes-gessatura'), 'space-phase-structure')); ?>" data-board="<?php echo esc_attr(gomes_text(__('Il rivestimento definisce volumi e superfici.', 'gomes-gessatura'), 'space-phase-board')); ?>" data-finished="<?php echo esc_attr(gomes_text(__('La finitura completa il dettaglio.', 'gomes-gessatura'), 'space-phase-finished')); ?>"></p>
              <div class="gomes-space-actions"><button type="button" data-space-replay><?php echo $label(__('Rivedi la trasformazione', 'gomes-gessatura'), 'replay'); ?><span aria-hidden="true">↻</span></button><button type="button" data-space-layers aria-pressed="false"><?php echo $label(__('Esplora gli strati', 'gomes-gessatura'), 'layers'); ?><span aria-hidden="true">＋</span></button></div>
            </div>
          </div>
          <?php get_template_part('template-parts/space-light-controls', null, array('label' => $label)); ?>
          <div class="gomes-space-stories">
            <?php foreach ($cases as $case) : ?>
              <article class="gomes-space-story" id="gomes-space-<?php echo esc_attr($case['mode']); ?>" data-space-story="<?php echo esc_attr($case['mode']); ?>" data-category="<?php echo esc_attr($case['category']); ?>">
                <h3><?php echo esc_html(gomes_text($case['title'], 'space-case-' . $case['mode'])); ?></h3>
                <div class="gomes-space-need"><?php echo wp_kses_post(gomes_text($case['paragraphs'][0], 'space-need-' . $case['mode'])); ?></div>
                <div class="gomes-space-work"><?php echo wp_kses_post(gomes_text($case['paragraphs'][1], 'space-work-' . $case['mode'])); ?></div>
                <?php if ($case['image']) : $stock_image = (bool) get_post_meta($case['image'], '_gomes_stock_source', true); ?><figure class="gomes-space-proof"><?php echo gomes_image($case['image'], 'medium_large', array('loading' => 'lazy', 'sizes' => '(max-width: 800px) 90vw, 32vw')); ?><figcaption><?php echo $label($stock_image ? __('Immagine illustrativa', 'gomes-gessatura') : __('Dal cantiere', 'gomes-gessatura'), $stock_image ? 'stock-proof' : 'proof'); ?><span><?php echo esc_html(gomes_text(get_the_title($case['image']), 'media:' . $case['image'] . ':title')); ?></span></figcaption></figure><?php endif; ?>
              </article>
            <?php endforeach; ?>
          </div>
        </div>
        <div class="gomes-space-close"><p><?php echo $label(__('Hai in mente qualcosa di simile?', 'gomes-gessatura'), 'closing'); ?></p><a class="gomes-text-link" data-space-contact data-prefix="<?php echo esc_attr(gomes_text(__('Vorrei informazioni su:', 'gomes-gessatura'), 'space-request-prefix')); ?>" href="<?php echo esc_url(gomes_home() . '#contatti'); ?>"><?php echo $label(__('Parliamo di questa idea', 'gomes-gessatura'), 'idea-cta'); ?><span aria-hidden="true"> ↗</span></a></div>
      </div>
    </section>
    <?php
}
