<?php defined('ABSPATH') || exit; get_header(); ?>
<main id="main" class="gomes-container gomes-document">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?><article><h1><?php the_title(); ?></h1><?php the_content(); ?></article><?php endwhile; else : ?><h1><?php echo esc_html(gomes_text(__('Contenuto non disponibile', 'gomes-gessatura'), 'not-found')); ?></h1><a href="<?php echo esc_url(gomes_home()); ?>"><?php echo esc_html(gomes_text(__('Torna alla home', 'gomes-gessatura'), 'back-home')); ?></a><?php endif; ?>
</main>
<?php get_footer(); ?>
