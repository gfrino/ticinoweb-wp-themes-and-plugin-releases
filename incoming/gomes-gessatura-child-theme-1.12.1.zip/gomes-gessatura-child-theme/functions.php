<?php
/** Presentation layer only. The parent owns the CMS, forms, galleries, SEO and updater. */
defined('ABSPATH') || exit;
require_once __DIR__ . '/inc/render.php';
require_once __DIR__ . '/inc/hero.php';
require_once __DIR__ . '/inc/space.php';

add_action('after_setup_theme', function () {
    load_child_theme_textdomain('gomes-gessatura', get_stylesheet_directory() . '/languages');
    add_theme_support('editor-styles');
    add_editor_style('assets/css/site.css');
    add_theme_support('responsive-embeds');
    register_nav_menus(array('gomes_footer' => __('Menu legale', 'gomes-gessatura')));
    // Replace only frontend presentation assets; all parent business functions remain in use.
    remove_action('wp_enqueue_scripts', 'ticinoweb_ai_assets');
    remove_action('wp_enqueue_scripts', 'ticinoweb_form_localize_main', 20);
    remove_action('wp_head', 'ticinoweb_apply_page_background_image');
    global $wp_filter;
    // The parent adds anonymous Google Fonts preconnects at priority zero.
    if (isset($wp_filter['wp_head']->callbacks[0])) {
        foreach ($wp_filter['wp_head']->callbacks[0] as $entry) {
            if ($entry['function'] instanceof Closure) {
                $reflection = new ReflectionFunction($entry['function']);
                if ($reflection->getFileName() === get_template_directory() . '/functions.php' && strpos(implode('', array_slice(file($reflection->getFileName()), $reflection->getStartLine() - 1, $reflection->getEndLine() - $reflection->getStartLine() + 1)), 'fonts.googleapis.com') !== false) {
                    remove_action('wp_head', $entry['function'], 0);
                }
            }
        }
    }
}, 30);

add_action('wp_enqueue_scripts', function () {
    $version = wp_get_theme()->get('Version');
    wp_enqueue_style('gomes-site', get_stylesheet_directory_uri() . '/assets/css/site.css', array(), $version);
    wp_enqueue_style('gomes-header', get_stylesheet_directory_uri() . '/assets/css/header.css', array('gomes-site'), $version);
    wp_enqueue_script('gomes-site', get_stylesheet_directory_uri() . '/assets/js/site.js', array(), $version, true);
    wp_localize_script('gomes-site', 'gomesConfig', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'recaptchaKey' => (string) get_option('ticinoweb_recaptcha_site_key', ''),
        'sending' => gomes_text(__('Invio in corso…', 'gomes-gessatura'), 'sending'),
        'success' => gomes_text(__('Grazie, abbiamo ricevuto la tua richiesta.', 'gomes-gessatura'), 'success'),
        'saved' => gomes_text(__('La richiesta è stata registrata. Per una risposta più rapida puoi anche chiamarci.', 'gomes-gessatura'), 'saved'),
        'error' => gomes_text(__('Invio non riuscito. Riprova oppure contattaci per telefono o e-mail.', 'gomes-gessatura'), 'error'),
    ));
    if (is_front_page()) {
        // Archived studio assets load only when its native Home block is restored.
        $has_studio = false;
        foreach (parse_blocks(get_post_field('post_content', get_queried_object_id())) as $section) {
            if (($section['attrs']['anchor'] ?? '') === 'oltre-la-superficie') { $has_studio = true; break; }
        }
        if ($has_studio) {
        wp_enqueue_style('gomes-space', get_stylesheet_directory_uri() . '/assets/css/space.css', array('gomes-site'), $version);
        wp_enqueue_script('gomes-space', get_stylesheet_directory_uri() . '/assets/js/space.js', array(), $version, true);
        }
        wp_enqueue_style('gomes-motion', get_stylesheet_directory_uri() . '/assets/css/motion.css', array('gomes-site'), $version);
        wp_enqueue_script('gomes-motion', get_stylesheet_directory_uri() . '/assets/js/motion.js', array(), $version, true);
        wp_localize_script('gomes-motion', 'gomesMotionLabels', array('reduce' => gomes_text(__('Riduci gli effetti', 'gomes-gessatura'), 'motion-reduce'), 'restore' => gomes_text(__('Ripristina gli effetti', 'gomes-gessatura'), 'motion-restore')));
        wp_enqueue_style('gomes-services', get_stylesheet_directory_uri() . '/assets/css/services.css', array('gomes-site'), $version);
        wp_enqueue_script('gomes-services', get_stylesheet_directory_uri() . '/assets/js/services.js', array(), $version, true);
        wp_enqueue_style('gomes-hero', get_stylesheet_directory_uri() . '/assets/css/hero.css', array('gomes-site'), $version);
        wp_enqueue_script('gomes-hero', get_stylesheet_directory_uri() . '/assets/js/hero.js', array('gomes-motion'), $version, true);
    }
    $key = (string) get_option('ticinoweb_recaptcha_site_key', '');
    if ($key && is_front_page()) {
        wp_enqueue_script('gomes-recaptcha', add_query_arg('render', $key, 'https://www.google.com/recaptcha/api.js'), array(), null, true);
    }
}, 30);

add_action('wp_head', function () {
    echo '<link rel="preload" href="' . esc_url(get_stylesheet_directory_uri() . '/assets/fonts/manrope-latin.woff2') . '" as="font" type="font/woff2" crossorigin>' . "\n";
}, 2);

// Keep the primary navigation in the active language, including anchor links on inner pages.
add_filter('nav_menu_link_attributes', function ($atts) {
    if (!empty($atts['href']) && strpos($atts['href'], '#') === 0) {
        $atts['href'] = gomes_home() . $atts['href'];
    }
    return $atts;
});

// Enrich the parent's single entity; contacts stay synchronized with the CMS.
add_filter('ticinoweb_seo_jsonld_org_schema', function ($schema) {
    $contact = gomes_contact();
    $schema['name'] = get_bloginfo('name');
    if (!empty($contact['phone'])) { $schema['telephone'] = $contact['phone']; }
    if (!empty($contact['address'])) { $schema['address'] = array('@type' => 'PostalAddress', 'streetAddress' => $contact['address']); }
    if (!empty($contact['email'])) { $schema['email'] = $contact['email']; }
    $offers = array();
    foreach ((array) ticinoweb_get_services() as $service) {
        if (empty($service['title'])) { continue; }
        $offers[] = array('@type' => 'Offer', 'itemOffered' => array('@type' => 'Service', 'name' => $service['title'], 'description' => wp_strip_all_tags($service['description'] ?? '')));
    }
    if ($offers) { $schema['hasOfferCatalog'] = array('@type' => 'OfferCatalog', 'itemListElement' => $offers); }
    return $schema;
});
