<?php defined('ABSPATH') || exit; $contact = gomes_contact(); $privacy = get_option('tw_privacy_policy_url', ''); ?>
<div class="gomes-contact-grid">
    <div class="gomes-contact-details">
        <?php if (!empty($contact['phone'])) : ?><a class="gomes-contact-phone" href="<?php echo esc_url(gomes_phone_href($contact['phone'])); ?>"><?php echo esc_html(get_option('ticinoweb_contact_phone_display') ?: $contact['phone']); ?></a><?php endif; ?>
        <?php if (!empty($contact['email'])) : ?><a href="<?php echo esc_url('mailto:' . sanitize_email($contact['email'])); ?>"><?php echo esc_html($contact['email']); ?></a><?php endif; ?>
        <?php if (!empty($contact['address'])) : ?><p><?php echo esc_html($contact['address']); ?></p><a class="gomes-text-link" href="<?php echo esc_url('https://www.google.com/maps/search/?api=1&query=' . rawurlencode($contact['address'])); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html(gomes_text(__('Apri le indicazioni', 'gomes-gessatura'), 'directions')); ?> ↗</a><?php endif; ?>
        <?php if (!empty($contact['opening_hours'])) : ?>
        <dl class="gomes-hours"><?php
            $days = gomes_weekdays();
            foreach ($days as $key => $label) {
                if (!isset($contact['opening_hours'][$key])) { continue; }
                echo '<div><dt>' . esc_html(gomes_text($label, 'day:' . $key)) . '</dt><dd>' . esc_html(ticinoweb_format_day_hours($contact['opening_hours'][$key])) . '</dd></div>';
            }
        ?></dl><?php endif; ?>
        <?php if (!empty($contact['opening_hours_note'])) { echo wp_kses_post(wpautop($contact['opening_hours_note'])); } ?>
    </div>
    <form class="gomes-form" action="<?php echo esc_url(admin_url('admin-ajax.php')); ?>" method="post">
        <input type="hidden" name="action" value="ticinoweb_submit_form">
        <div class="gomes-form-row"><label><?php echo esc_html(gomes_text(__('Nome e cognome', 'gomes-gessatura'), 'name')); ?> *<input name="nome" autocomplete="name" required minlength="2" maxlength="255"></label><label><?php echo esc_html(gomes_text(__('E-mail', 'gomes-gessatura'), 'email')); ?> *<input type="email" name="email" autocomplete="email" required maxlength="254"></label></div>
        <label><?php echo esc_html(gomes_text(__('Telefono', 'gomes-gessatura'), 'phone')); ?><input type="tel" name="telefono" autocomplete="tel" maxlength="50"></label>
        <label><?php echo esc_html(gomes_text(__('Quale intervento hai in mente?', 'gomes-gessatura'), 'subject')); ?><select name="oggetto"><option value=""><?php echo esc_html(gomes_text(__('Seleziona un servizio', 'gomes-gessatura'), 'select-service')); ?></option><?php foreach ((array) ticinoweb_get_services() as $service) : ?><option><?php echo esc_html($service['title'] ?? ''); ?></option><?php endforeach; ?></select></label>
        <label><?php echo esc_html(gomes_text(__('Raccontaci il progetto e dove si trova', 'gomes-gessatura'), 'message')); ?> *<textarea name="messaggio" rows="4" required minlength="5" maxlength="5000"></textarea></label>
        <div class="gomes-honeypot" aria-hidden="true"><label>Website<input name="tw_hp" tabindex="-1" autocomplete="off"></label></div>
        <p class="gomes-form-privacy"><?php echo esc_html(gomes_text(__('Usiamo i dati inseriti per rispondere alla tua richiesta, che viene inviata via e-mail e conservata nel nostro archivio dei contatti.', 'gomes-gessatura'), 'privacy-note')); ?> <?php if ($privacy) : ?><a href="<?php echo esc_url($privacy); ?>"><?php echo esc_html(gomes_text(__('Informativa privacy', 'gomes-gessatura'), 'privacy-link')); ?></a><?php endif; ?></p>
        <button class="gomes-button" type="submit"><?php echo esc_html(gomes_text(__('Richiedi un sopralluogo', 'gomes-gessatura'), 'send')); ?> <span aria-hidden="true">↗</span></button>
        <p class="gomes-form-status" role="status" aria-live="polite" tabindex="-1"></p>
        <noscript><p><?php echo esc_html(gomes_text(__('Per usare il formulario abilita JavaScript, oppure contattaci per telefono o e-mail.', 'gomes-gessatura'), 'form-noscript')); ?></p></noscript>
    </form>
</div>
