<?php
/**
 * THESIS: reveal the work hidden inside a room, without simulating a real project.
 * OWN-WORLD: precise axonometric planes, plaster whites and Gomes blue.
 * STORY: choose a need, see construction become finish, inspect the layers.
 * FIRST VIEW: three choices above a large model, explanation and real site photograph beside it.
 * FORM: an architectural study inside the existing one-page identity; no external renderer.
 */
defined('ABSPATH') || exit;
?>
<svg class="gomes-space-model" viewBox="0 0 800 620" fill="none" aria-hidden="true" focusable="false">
 <defs>
  <linearGradient id="gomes-wall-left" x1="150" y1="150" x2="450" y2="350" gradientUnits="userSpaceOnUse"><stop stop-color="#f8f9f6"/><stop offset="1" stop-color="#dce3e5"/></linearGradient>
  <linearGradient id="gomes-wall-right" x1="420" y1="60" x2="700" y2="400" gradientUnits="userSpaceOnUse"><stop stop-color="#e4e9e9"/><stop offset="1" stop-color="#c3ced2"/></linearGradient>
  <linearGradient id="gomes-floor" x1="420" y1="270" x2="420" y2="560" gradientUnits="userSpaceOnUse"><stop stop-color="#c8d3d8"/><stop offset="1" stop-color="#ecf0ef"/></linearGradient>
  <linearGradient id="gomes-slab" x1="290" y1="150" x2="550" y2="500" gradientUnits="userSpaceOnUse"><stop stop-color="#fff"/><stop offset="1" stop-color="#e0e7e7"/></linearGradient>
  <pattern id="gomes-acoustic-perforation" width="10" height="10" patternUnits="userSpaceOnUse"><rect width="10" height="10" fill="#f0f3ef"/><circle cx="5" cy="5" r=".9" fill="#7f99a6" opacity=".55"/></pattern>
  <linearGradient id="gomes-light-wash" x1="0" y1="0" x2="0" y2="1"><stop stop-color="var(--led-color,#ffd397)" stop-opacity=".6"/><stop offset=".65" stop-color="var(--led-color,#ffd397)" stop-opacity=".12"/><stop offset="1" stop-color="var(--led-color,#ffd397)" stop-opacity="0"/></linearGradient>
  <linearGradient id="gomes-light-local" x1="0" y1="0" x2="0" y2="1"><stop stop-color="var(--led-color,#ffd397)" stop-opacity=".75"/><stop offset="1" stop-color="var(--led-color,#ffd397)" stop-opacity="0"/></linearGradient>
 </defs>
 <!-- One consistent axonometric room; rear walls remain the spatial reference. -->
 <g class="gomes-room-shell">
 <ellipse cx="420" cy="538" rx="258" ry="32" fill="#183b63" opacity=".07"/>
 <path d="M160 410 420 260 680 410 420 560Z" fill="url(#gomes-floor)" stroke="#b2c2ca"/>
 <path d="M160 410v9l260 150v-9Zm260 150v9l260-150v-9Z" fill="#bdcbd0"/>
 <path d="M160 190 420 40v220L160 410Z" fill="url(#gomes-wall-left)" stroke="#b5c4c9"/>
 <path d="M420 40 680 190v220L420 260Z" fill="url(#gomes-wall-right)" stroke="#adbec5"/>
 <path d="M160 190 420 40 680 190" stroke="#fff" stroke-width="5"/>
 <!-- Window, recessed into the right wall, rather than floating decoration. -->
 <path d="m486 126 128 74v128l-128-74Z" fill="#a4bdca" stroke="#f8faf8" stroke-width="7"/>
 <path d="m492 138 116 67v111l-116-67Z" fill="#c8dce3"/>
 <path d="m550 172 0 111m-58-89 116 67" stroke="#f7f9f6" stroke-width="4"/>
 <path d="m483 254 134 78 8-5-135-78Z" fill="#f6f8f6"/>
 <path d="m173 403 247-143 246 142" stroke="#f4f7f5" stroke-width="4"/>
 </g>
 <g class="gomes-room-light" aria-hidden="true"><path d="M160 190 420 40v220L160 410Z" fill="url(#gomes-light-wash)"/><path d="M420 40 680 190v220L420 260Z" fill="url(#gomes-light-wash)"/></g>
 <g class="gomes-space-variant" data-model="spazio">
  <g class="gomes-model-layer gomes-model-frame">
   <path d="M299 330V110l260 150v220Z" fill="#bdd0da" fill-opacity=".22" stroke="#54768b" stroke-width="3"/>
   <path d="M307 115v220m43-195v220m43-195v220m43-195v220m43-195v220m43-195v220m29-203v220M299 220l260 150" stroke="#7894a4" stroke-width="4"/>
   <path d="m299 110 260 150m-260 70 260 150" stroke="#e5eef0" stroke-width="7"/>
  </g>
  <g class="gomes-model-layer gomes-model-board"><path d="M299 110 559 260v220L299 330Z" fill="url(#gomes-slab)" stroke="#bccbd0" stroke-width="2"/><path d="M429 185v220" stroke="#c2d0d4" stroke-width="2"/><path d="m299 110 260 150" stroke="#fff" stroke-width="5"/></g>
  <g class="gomes-model-layer gomes-model-finish"><path d="M299 110 559 260v220L299 330Z" fill="url(#gomes-slab)" stroke="#d0dadd"/><path d="m299 110 260 150" stroke="#fff" stroke-width="5"/><path d="m309 325 240 139" stroke="#c0cdd2" stroke-width="3"/></g>
 </g>
 <g class="gomes-space-variant" data-model="comfort">
  <g class="gomes-model-layer gomes-model-frame"><path d="m177 180 243-140 243 140-243 140Z" fill="#b9cbd4" fill-opacity=".25" stroke="#7893a2" stroke-width="2"/><path d="m238 145 243 140m-182-175 243 140M360 75l243 140M238 215 481 75M299 250l243-140m-182 175 243-140" stroke="#7893a2" stroke-width="3"/><path d="M238 145v35m122-105v35m243 105v35M420 40v35" stroke="#54768b" stroke-width="2"/></g>
  <g class="gomes-model-layer gomes-model-board"><path d="m177 180 243-140 243 140-243 140Z" fill="#e9eeeb" stroke="#b5c5cb" stroke-width="2"/><path d="m299 110 243 140m-304-35 243-140m-121 210 243-140" stroke="#bfced1" stroke-width="2"/></g>
  <g class="gomes-model-layer gomes-model-finish"><path d="m177 180 243-140 243 140-243 140Z" fill="url(#gomes-slab)" stroke="#c5d1d4" stroke-width="2"/><path d="m177 180 243 140 243-140v7L420 327 177 187Z" fill="#bacbd1"/><ellipse cx="420" cy="177" rx="13" ry="7.5" fill="#d8e3e6"/><ellipse cx="420" cy="175" rx="9" ry="5" fill="#fbfcf8"/></g>
 </g>
 <g class="gomes-space-variant" data-model="acustica">
  <g class="gomes-model-layer gomes-model-frame"><path d="m177 180 243-140 243 140-243 140Z" fill="#b9cbd4" fill-opacity=".25" stroke="#7893a2" stroke-width="2"/><path d="m238 145 243 140m-182-175 243 140M360 75l243 140M238 215 481 75M299 250l243-140m-182 175 243-140" stroke="#7893a2" stroke-width="3"/><path d="M238 145v35m122-105v35m243 105v35M420 40v35" stroke="#54768b" stroke-width="2"/></g>
  <g class="gomes-model-layer gomes-model-board"><path d="m177 180 243-140 243 140-243 140Z" fill="#e9eeeb" stroke="#b5c5cb" stroke-width="2"/><path d="m299 110 243 140m-304-35 243-140m-121 210 243-140" stroke="#bfced1" stroke-width="2"/></g>
  <g class="gomes-model-layer gomes-model-finish"><g transform="matrix(.866 .5 -.866 .5 420 40)"><rect width="280" height="280" fill="#d1dce0"/><rect x="6" y="6" width="84" height="84" fill="url(#gomes-acoustic-perforation)" stroke="#b7c8ce"/><rect x="98" y="6" width="84" height="84" fill="url(#gomes-acoustic-perforation)" stroke="#b7c8ce"/><rect x="190" y="6" width="84" height="84" fill="url(#gomes-acoustic-perforation)" stroke="#b7c8ce"/><rect x="6" y="98" width="84" height="84" fill="url(#gomes-acoustic-perforation)" stroke="#b7c8ce"/><rect x="98" y="98" width="84" height="84" fill="url(#gomes-acoustic-perforation)" stroke="#b7c8ce"/><rect x="190" y="98" width="84" height="84" fill="url(#gomes-acoustic-perforation)" stroke="#b7c8ce"/><rect x="6" y="190" width="84" height="84" fill="url(#gomes-acoustic-perforation)" stroke="#b7c8ce"/><rect x="98" y="190" width="84" height="84" fill="url(#gomes-acoustic-perforation)" stroke="#b7c8ce"/><rect x="190" y="190" width="84" height="84" fill="url(#gomes-acoustic-perforation)" stroke="#b7c8ce"/></g><path d="m177 180 243 140 243-140v7L420 327 177 187Z" fill="#bacbd1"/></g>
 </g>
 <g class="gomes-space-variant" data-model="carattere">
  <g transform="matrix(.866 .5 0 1 299 110)">
   <g class="gomes-model-layer gomes-model-frame"><path fill-rule="evenodd" d="M0 0h300v220H0ZM85 220h130V112a65 65 0 0 0-130 0Z" fill="#b9cbd4" fill-opacity=".22" stroke="#67889b" stroke-width="3"/><path d="M15 0v220M75 0v220M150 0v45M225 0v220M285 0v220M0 145h85m130 0h85" stroke="#7894a4" stroke-width="4"/></g>
   <g class="gomes-model-layer gomes-model-board"><path fill-rule="evenodd" d="M0 0h300v220H0ZM85 220h130V112a65 65 0 0 0-130 0Z" fill="#e3e9e6" stroke="#b4c5cb" stroke-width="2"/><path d="M75 0v65m150-65v65M0 145h85m130 0h85" stroke="#bdcdd1" stroke-width="2"/></g>
   <g class="gomes-model-layer gomes-model-finish"><path fill-rule="evenodd" d="M0 0h300v220H0ZM85 220h130V112a65 65 0 0 0-130 0Z" fill="url(#gomes-slab)" stroke="#c0ced2" stroke-width="2"/><path d="M85 220V112a65 65 0 0 1 130 0v108" stroke="#9cb3be" stroke-width="7"/><path class="gomes-led-reflection" d="M4 8h292v64H4Z" fill="url(#gomes-light-local)"/><path class="gomes-led-source" d="M4 8h292" stroke="var(--led-color,#ffd397)" stroke-width="5"/><path class="gomes-led-source" d="M6 6h288" stroke="#fff9ed" stroke-width="1.5"/></g>
  </g>
 </g>
 <g class="gomes-space-variant" data-model="led">
  <g class="gomes-model-layer gomes-model-frame"><path d="m177 180 243-140 243 140-243 140Z M210 180 420 59 630 180 420 301Z" fill="#c1d0d6" fill-rule="evenodd" stroke="#7390a0" stroke-width="3"/><path d="m194 170 19 11m188-132 19 11m225 110-19 11m-206 126v12" stroke="#7390a0" stroke-width="3"/></g>
  <g class="gomes-model-layer gomes-model-board"><path d="m177 180 243-140 243 140-243 140Z M210 180 420 59 630 180 420 301Z" fill="#dfe6e5" fill-rule="evenodd" stroke="#b4c6cd" stroke-width="2"/></g>
  <g class="gomes-model-layer gomes-model-finish"><path d="m177 180 243-140 243 140-243 140Z M210 180 420 59 630 180 420 301Z" fill="url(#gomes-slab)" fill-rule="evenodd" stroke="#c4d1d5" stroke-width="2"/><path d="m177 180 243 140 243-140v9L420 329 177 189Z" fill="#bfced3"/><path class="gomes-led-reflection" d="m210 180 210 121 210-121-210 95Z" fill="var(--led-color,#ffd397)" opacity=".24"/><path class="gomes-led-source" d="m210 180 210-121 210 121-210 121Z" stroke="var(--led-color,#ffd397)" stroke-width="5"/><path class="gomes-led-source" d="m210 179 210-121 210 121-210 121Z" stroke="#fffaf2" stroke-width="1.4"/></g>
 </g>
</svg>
