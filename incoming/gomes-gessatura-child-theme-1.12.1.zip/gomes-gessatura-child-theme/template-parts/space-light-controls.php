<?php defined('ABSPATH') || exit; $label = $args['label']; ?>
<fieldset class="gomes-space-light" data-space-light hidden>
 <legend><?php echo $label(__('Crea la tua atmosfera', 'gomes-gessatura'), 'light-title'); ?></legend>
 <div class="gomes-light-top">
  <button type="button" data-led-switch aria-pressed="true"><?php echo $label(__('Luce LED', 'gomes-gessatura'), 'light-switch'); ?><span class="gomes-light-switch" aria-hidden="true"></span></button>
  <button type="button" data-space-night aria-pressed="false"><?php echo $label(__('Vista sera', 'gomes-gessatura'), 'light-night'); ?><span aria-hidden="true">◐</span></button>
 </div>
 <div class="gomes-light-colors" role="group" aria-label="<?php echo esc_attr(gomes_text(__('Colore della luce', 'gomes-gessatura'), 'space-colors')); ?>">
 <?php foreach (array('caldo' => array('#ffd397', __('Bianco caldo', 'gomes-gessatura')), 'neutro' => array('#f4f3e8', __('Bianco neutro', 'gomes-gessatura')), 'freddo' => array('#c6e5ff', __('Bianco freddo', 'gomes-gessatura')), 'blu' => array('#72a8ff', __('Blu', 'gomes-gessatura')), 'viola' => array('#b291ff', __('Viola', 'gomes-gessatura'))) as $key => [$color, $text]) : ?>
  <button type="button" data-led-color="<?php echo esc_attr($key); ?>" data-color="<?php echo esc_attr($color); ?>" style="--swatch:<?php echo esc_attr($color); ?>" aria-pressed="<?php echo $key === 'caldo' ? 'true' : 'false'; ?>"><span aria-hidden="true"></span><span class="screen-reader-text"><?php echo $label($text, 'color-' . $key); ?></span></button>
 <?php endforeach; ?>
 <output data-led-color-name><?php echo $label(__('Bianco caldo', 'gomes-gessatura'), 'color-caldo'); ?></output>
 </div>
 <label class="gomes-light-intensity"><?php echo $label(__('Intensità', 'gomes-gessatura'), 'light-intensity'); ?><input type="range" min="0" max="100" step="5" value="70" data-led-intensity><output data-led-level>70%</output></label>
 <p><?php echo $label(__('Colori ed effetto luminoso sono indicativi.', 'gomes-gessatura'), 'light-note'); ?></p>
</fieldset>
