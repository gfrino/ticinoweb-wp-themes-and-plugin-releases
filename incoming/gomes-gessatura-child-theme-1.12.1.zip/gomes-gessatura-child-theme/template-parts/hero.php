<?php
defined('ABSPATH') || exit;
$slides = gomes_get_hero_slides();
if (!$slides) { return; }
$total = count($slides);
$studio_available = false;
foreach (parse_blocks(get_post_field('post_content', get_queried_object_id())) as $section) {
    if (($section['attrs']['anchor'] ?? '') === 'oltre-la-superficie' && function_exists('gomes_space_cases') && gomes_space_cases($section)) { $studio_available = true; break; }
}
?>
<section id="inizio" class="gomes-hero" data-hero aria-roledescription="<?php echo esc_attr(gomes_text(__('Carosello', 'gomes-gessatura'), 'hero-carousel')); ?>" aria-label="<?php echo esc_attr(gomes_text(__('Le nostre lavorazioni', 'gomes-gessatura'), 'hero-label')); ?>">
    <div class="gomes-container gomes-hero-frame">
    <div class="gomes-hero-stage">
        <?php foreach ($slides as $index => $slide) :
            $title = (string) ($slide['title'] ?? '');
            $announcement = sprintf(gomes_text(__('%1$d di %2$d: %3$s', 'gomes-gessatura'), 'hero-announcement'), $index + 1, $total, $title);
            ?>
            <article class="gomes-hero-slide" data-hero-slide="<?php echo esc_attr($index); ?>" data-announcement="<?php echo esc_attr($announcement); ?>" role="group" aria-roledescription="<?php echo esc_attr(gomes_text(__('Diapositiva', 'gomes-gessatura'), 'hero-slide')); ?>" aria-label="<?php echo esc_attr(($index + 1) . ' / ' . $total); ?>" aria-hidden="<?php echo $index === 0 ? 'false' : 'true'; ?>"<?php if ($index > 0) { echo ' inert'; } ?>>
                <div class="gomes-hero-panel">
                    <p class="gomes-hero-brand"><?php echo esc_html(get_bloginfo('name')); ?></p>
                    <?php if ($title !== '') : ?>
                        <?php if ($index === 0) : ?><h1><?php echo esc_html($title); ?></h1><?php else : ?><h2><?php echo esc_html($title); ?></h2><?php endif; ?>
                    <?php elseif ($index === 0) : ?><h1><?php echo esc_html(get_bloginfo('name')); ?></h1><?php endif; ?>
                    <?php if (!empty($slide['desc'])) : ?><div class="gomes-hero-description"><?php echo wp_kses_post(wpautop($slide['desc'])); ?></div><?php endif; ?>
                    <div class="gomes-hero-actions">
                    <?php if (!empty($slide['btn1_text']) && !empty($slide['btn1_link'])) : ?><a class="gomes-button gomes-hero-cta" href="<?php echo esc_url($slide['btn1_link']); ?>"><?php echo esc_html($slide['btn1_text']); ?><span aria-hidden="true">↗</span></a><?php endif; ?>
                    <?php if ($studio_available) : ?><a class="gomes-hero-studio" href="<?php echo esc_url(gomes_home() . '#oltre-la-superficie'); ?>"><span class="gomes-hero-studio-icon" aria-hidden="true"><svg viewBox="0 0 32 32" fill="none"><path d="m4 20 12 7 12-7V8L16 1 4 8Zm0-12 12 7 12-7M16 15v12" stroke="currentColor" stroke-width="1.4"/><path d="m10 11 12 7v6" stroke="currentColor" stroke-width="1.4"/></svg></span><?php echo esc_html(gomes_text(__('Esplora spazio e luce', 'gomes-gessatura'), 'hero-studio')); ?><span aria-hidden="true">↗</span></a><?php endif; ?>
                    </div>
                </div>
                <figure class="gomes-hero-visual">
                    <?php echo wp_get_attachment_image($slide['image_id'], 'full', false, array('loading' => $index === 0 ? 'eager' : 'lazy', 'fetchpriority' => $index === 0 ? 'high' : 'low', 'sizes' => '100vw')); ?>
                </figure>
                <div class="gomes-hero-relief" aria-hidden="true"><span></span><span></span><span></span></div>
            </article>
        <?php endforeach; ?>
    </div>
    <?php if ($total > 1) : ?>
        <div class="gomes-hero-controls" data-hero-controls hidden>
            <div class="gomes-hero-index" role="group" aria-label="<?php echo esc_attr(gomes_text(__('Scegli una slide', 'gomes-gessatura'), 'hero-choose')); ?>">
                <?php foreach ($slides as $index => $slide) : ?><button type="button" data-hero-go="<?php echo esc_attr($index); ?>" aria-pressed="<?php echo $index === 0 ? 'true' : 'false'; ?>" aria-label="<?php echo esc_attr(sprintf(gomes_text(__('Mostra slide %1$d: %2$s', 'gomes-gessatura'), 'hero-show'), $index + 1, $slide['title'] ?? '')); ?>"><?php echo esc_html(sprintf('%02d', $index + 1)); ?></button><?php endforeach; ?>
            </div>
            <div class="gomes-hero-progress" aria-hidden="true"><span></span></div>
            <div class="gomes-hero-arrows">
                <button type="button" data-hero-prev aria-label="<?php echo esc_attr(gomes_text(__('Slide precedente', 'gomes-gessatura'), 'hero-prev')); ?>"><span aria-hidden="true">←</span></button>
                <button type="button" data-hero-next aria-label="<?php echo esc_attr(gomes_text(__('Slide successiva', 'gomes-gessatura'), 'hero-next')); ?>"><span aria-hidden="true">→</span></button>
            </div>
        </div>
        <p class="screen-reader-text" data-hero-status role="status" aria-live="polite" aria-atomic="true"></p>
    <?php endif; ?>
    </div>
</section>
