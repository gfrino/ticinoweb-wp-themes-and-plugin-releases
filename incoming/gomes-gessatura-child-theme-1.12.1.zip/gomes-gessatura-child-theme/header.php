<?php defined('ABSPATH') || exit; ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width, initial-scale=1"><?php wp_head(); ?></head>
<body <?php body_class('gomes-site'); ?>>
<?php wp_body_open(); ?>
<a class="gomes-skip" href="#main"><?php echo esc_html(gomes_text(__('Vai al contenuto', 'gomes-gessatura'), 'skip')); ?></a>
<header class="gomes-header">
    <div class="gomes-header-inner">
        <a class="gomes-brand" href="<?php echo esc_url(gomes_home()); ?>" aria-label="<?php echo esc_attr(get_bloginfo('name')); ?>">
            <?php $logo = function_exists('ticinoweb_get_site_logo') ? ticinoweb_get_site_logo() : ''; $logo_html = gomes_image($logo, 'medium_large', array('loading' => 'eager', 'sizes' => '(max-width: 800px) 220px, 264px')); echo $logo_html ?: esc_html(get_bloginfo('name')); ?>
        </a>
        <button class="gomes-menu-toggle" type="button" aria-expanded="false" aria-controls="gomes-navigation" hidden><?php echo esc_html(gomes_text(__('Menu', 'gomes-gessatura'), 'menu')); ?><span class="gomes-menu-icon" aria-hidden="true"><i></i><i></i></span></button>
        <nav id="gomes-navigation" aria-label="<?php echo esc_attr(gomes_text(__('Navigazione principale', 'gomes-gessatura'), 'navigation')); ?>">
            <?php wp_nav_menu(array('theme_location' => 'primary', 'container' => false, 'fallback_cb' => false, 'depth' => 1)); ?>
        </nav>
        <?php $contact = gomes_contact(); if (!empty($contact['phone'])) : ?><a class="gomes-header-call" href="<?php echo esc_url(gomes_phone_href($contact['phone'])); ?>"><?php echo esc_html(get_option('ticinoweb_contact_phone_display') ?: $contact['phone']); ?><span aria-hidden="true"> ↗</span></a><?php endif; ?>
    </div>
</header>
