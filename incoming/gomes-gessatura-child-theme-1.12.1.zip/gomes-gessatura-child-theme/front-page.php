<?php
defined('ABSPATH') || exit;
get_header();
?>
<main id="main">
<?php while (have_posts()) : the_post();
    // Sections are editable Gutenberg groups; their anchors select presentation components.
    $modules = array('servizi' => 'gomes_services', 'realizzazioni' => 'gomes_gallery', 'chi-siamo' => 'gomes_about');
    foreach (parse_blocks(get_the_content()) as $block) {
        if (empty($block['blockName'])) { continue; }
        $anchor = $block['attrs']['anchor'] ?? '';
        if (in_array($anchor, array('privacy', 'note-legali'), true)) { continue; }
        if ($anchor === 'inizio') { get_template_part('template-parts/hero'); continue; }
        if ($anchor === 'oltre-la-superficie') { gomes_space($block); continue; }
        $class = 'gomes-section gomes-section-' . sanitize_html_class($anchor ?: 'content');
        echo '<section class="' . esc_attr($class) . '"><div class="gomes-container">';
        echo apply_filters('the_content', serialize_block($block));
        if (isset($modules[$anchor])) { call_user_func($modules[$anchor]); }
        if ($anchor === 'contatti') { get_template_part('template-parts/contatti'); }
        echo '</div></section>';
    }
endwhile; ?>
</main>
<?php get_footer(); ?>
