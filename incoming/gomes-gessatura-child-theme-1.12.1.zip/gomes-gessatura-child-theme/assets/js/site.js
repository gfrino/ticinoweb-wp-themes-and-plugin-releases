(() => {
  'use strict';
  const config = window.gomesConfig || {};
  document.body.classList.add('gomes-js');
  // Reserve only the toolbar area actually visible, including mobile scroll-away.
  const toolbar = document.getElementById('wpadminbar');
  const syncToolbar = () => {
    const rect = toolbar?.getBoundingClientRect();
    const style = toolbar ? getComputedStyle(toolbar) : null;
    const visible = rect && style.display !== 'none' && style.visibility !== 'hidden' && rect.height > 0;
    document.documentElement.style.setProperty('--gomes-toolbar-offset', `${visible ? Math.max(0, Math.min(rect.height, rect.bottom)) : 0}px`);
  };
  syncToolbar();
  if (toolbar) {
    let toolbarFrame = null;
    const queueToolbar = () => {
      if (toolbarFrame !== null) return;
      toolbarFrame = requestAnimationFrame(() => { toolbarFrame = null; syncToolbar(); });
    };
    window.addEventListener('scroll', queueToolbar, {passive:true});
    window.addEventListener('resize', queueToolbar, {passive:true});
    if ('ResizeObserver' in window) new ResizeObserver(queueToolbar).observe(toolbar);
  }
  const menuButton = document.querySelector('.gomes-menu-toggle');
  const navigation = document.getElementById('gomes-navigation');
  if (menuButton && navigation) {
    menuButton.hidden = false;
    const closeMenu = () => { navigation.classList.remove('is-open'); menuButton.setAttribute('aria-expanded', 'false'); };
    menuButton.addEventListener('click', () => {
      const open = menuButton.getAttribute('aria-expanded') !== 'true';
      menuButton.setAttribute('aria-expanded', String(open)); navigation.classList.toggle('is-open', open);
    });
    navigation.addEventListener('click', event => { if (event.target.closest('a')) closeMenu(); });
    document.addEventListener('keydown', event => { if (event.key === 'Escape' && navigation.classList.contains('is-open')) { closeMenu(); menuButton.focus(); } });
    window.matchMedia('(max-width: 800px)').addEventListener('change', closeMenu);
    document.addEventListener('click', event => { if (!event.target.closest('.gomes-header')) closeMenu(); });
  }
  document.querySelectorAll('[data-gallery]').forEach(gallery => {
    const items = [...gallery.querySelectorAll('[data-gallery-item]')];
    const filters = [...gallery.querySelectorAll('[data-filter]')];
    const more = gallery.querySelector('[data-gallery-more]');
    const status = gallery.querySelector('[data-gallery-status]');
    let activeFilter = 'all'; let limit = 6;
    const update = () => {
      const matches = items.filter(item => activeFilter === 'all' || item.dataset.groups.split(' ').includes(activeFilter));
      items.forEach(item => { item.hidden = !matches.slice(0, limit).includes(item); });
      more.hidden = matches.length <= limit;
      filters.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.filter === activeFilter)));
      status.textContent = `${Math.min(limit, matches.length)} / ${matches.length}`;
    };
    gallery.querySelector('.gomes-filters').hidden = false;
    filters.forEach(button => button.addEventListener('click', () => { activeFilter = button.dataset.filter; limit = 6; update(); }));
    more.addEventListener('click', () => {
      const oldVisible = items.filter(item => !item.hidden); limit += 6; update();
      items.find(item => !item.hidden && !oldVisible.includes(item))?.querySelector('a')?.focus();
    });
    update();
    const dialog = document.querySelector('.gomes-lightbox');
    if (!dialog || !dialog.showModal) return;
    let current = null; let trigger = null;
    const links = () => items.filter(item => !item.hidden).map(item => item.querySelector('[data-lightbox]'));
    const show = link => {
      current = link;
      const source = link.querySelector('img');
      const image = document.createElement('img');
      image.dataset.lightboxImage = ''; image.src = link.href; image.alt = source.alt;
      dialog.querySelector('[data-lightbox-media]').replaceChildren(image);
      dialog.querySelector('#gomes-lightbox-title').textContent = link.closest('figure').querySelector('h3').textContent;
      dialog.querySelector('[data-lightbox-caption]').textContent = link.dataset.caption || '';
    };
    const step = offset => { const visible = links(); show(visible[(visible.indexOf(current) + offset + visible.length) % visible.length]); };
    gallery.addEventListener('click', event => {
      const link = event.target.closest('[data-lightbox]'); if (!link) return;
      event.preventDefault(); trigger = link; show(link); dialog.showModal();
    });
    dialog.querySelector('[data-lightbox-close]').addEventListener('click', () => dialog.close());
    dialog.querySelector('[data-lightbox-prev]').addEventListener('click', () => step(-1));
    dialog.querySelector('[data-lightbox-next]').addEventListener('click', () => step(1));
    dialog.addEventListener('keydown', event => { if (event.key === 'ArrowRight') step(1); if (event.key === 'ArrowLeft') step(-1); });
    dialog.addEventListener('click', event => { if (event.target === dialog) { const rect = dialog.getBoundingClientRect(); if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) dialog.close(); } });
    dialog.addEventListener('close', () => trigger?.focus());
  });
  const form = document.querySelector('.gomes-form');
  if (form) form.addEventListener('submit', async event => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    const status = form.querySelector('.gomes-form-status');
    const button = form.querySelector('[type=submit]');
    button.disabled = true; form.setAttribute('aria-busy', 'true'); status.textContent = config.sending; status.dataset.error = 'false';
    try {
      const tokenResponse = await fetch(`${config.ajaxUrl}?action=ticinoweb_form_token`, { credentials: 'same-origin', cache: 'no-store' });
      const token = await tokenResponse.json();
      if (!token.success || !token.data?.token) throw new Error(config.error);
      const data = new FormData(form); data.set('token', token.data.token);
      if (config.recaptchaKey) {
        if (!window.grecaptcha) throw new Error(config.error);
        await new Promise(resolve => window.grecaptcha.ready(resolve));
        data.set('recaptcha_token', await window.grecaptcha.execute(config.recaptchaKey, { action: 'contact' }));
      }
      const response = await fetch(config.ajaxUrl, { method: 'POST', body: data, credentials: 'same-origin' });
      const result = await response.json();
      if (!result.success) { const issue = new Error(); issue.userMessage = result.data?.message; throw issue; }
      status.textContent = result.data.id && result.data.mailed === false ? config.saved : config.success; form.reset();
    } catch (error) { status.textContent = error.userMessage || config.error; status.dataset.error = 'true'; }
    finally { button.disabled = false; form.removeAttribute('aria-busy'); status.focus(); }
  });
  const openLegal = () => {
    const id = window.location.hash.slice(1);
    const target = id ? document.getElementById(id) : null;
    if (target?.matches('details.gomes-legal')) target.open = true;
  };
  window.addEventListener('hashchange', openLegal); openLegal();
  document.addEventListener('click', event => {
    const link = event.target.closest('a');
    if (!link) return;
    const url = new URL(link.href, window.location.href);
    if (url.origin === window.location.origin && url.pathname === window.location.pathname && ['#privacy', '#note-legali'].includes(url.hash)) {
      const target = document.getElementById(url.hash.slice(1)); if (target) target.open = true;
    }
  });
  document.querySelector('[data-cookie-preferences]')?.addEventListener('click', () => {
    // Parent removes the banner after consent: reset only its consent cookies, then reuse its UI.
    ['tw_cookie_consent', 'tw_cookie_preferences'].forEach(name => { document.cookie = `${name}=; Max-Age=0; path=/; SameSite=Lax`; });
    window.location.reload();
  });
})();
