(() => {
  'use strict';
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const body = document.body;
  const toggle = document.querySelector('[data-motion-toggle]');
  const labels = window.gomesMotionLabels || {};
  let userReduced = false;
  try { userReduced = localStorage.getItem('gomes-reduce-effects') === '1'; } catch (_) { /* Storage can be blocked. */ }
  const animations = new Set();
  const disabled = () => reduced.matches || userReduced;
  const update = () => {
    body.classList.toggle('gomes-motion-off', disabled());
    body.classList.toggle('gomes-motion-sleep', document.hidden);
    if (disabled()) {
      animations.forEach(animation => animation.finish());
      animations.clear();
    } else {
      animations.forEach(animation => document.hidden ? animation.pause() : animation.play());
    }
    if (toggle) {
      toggle.textContent = disabled() ? labels.restore : labels.reduce;
      toggle.setAttribute('aria-pressed', String(disabled()));
      // An operating-system preference takes precedence over a local switch.
      toggle.hidden = reduced.matches;
    }
  };
  update();
  reduced.addEventListener('change', update);
  document.addEventListener('visibilitychange', update);
  toggle?.addEventListener('click', () => {
    userReduced = !userReduced;
    try { localStorage.setItem('gomes-reduce-effects', userReduced ? '1' : '0'); } catch (_) { /* Preference still works for this visit. */ }
    update();
  });
  // Keep each heading's exact text and a single accessible name; no duplicated visual copy.
  document.querySelectorAll('.gomes-hero-panel h1,.gomes-hero-panel h2,.gomes-section>.gomes-container>.wp-block-group h2').forEach(heading => {
    if (heading.childElementCount || !heading.textContent.trim()) return;
    const text = heading.textContent;
    const fragment = document.createDocumentFragment();
    let wordIndex = 0;
    text.split(/(\s+)/).forEach(part => {
      if (!part || /^\s+$/.test(part)) { fragment.append(document.createTextNode(part)); return; }
      const word = document.createElement('span');
      word.className = 'gomes-text-word'; word.textContent = part;
      word.setAttribute('aria-hidden', 'true');
      word.style.setProperty('--word-delay', `${Math.min(wordIndex++ * 40, 240)}ms`);
      fragment.append(word);
    });
    heading.setAttribute('aria-label', text);
    heading.replaceChildren(fragment);
  });
  const track = animation => {
    animations.add(animation);
    animation.addEventListener('finish', () => animations.delete(animation), {once:true});
    animation.addEventListener('cancel', () => animations.delete(animation), {once:true});
  };
  if (!('IntersectionObserver' in window)) { if (toggle) toggle.hidden = true; return; }
  const ambientObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => entry.target.classList.toggle('is-ambient-visible', entry.isIntersecting));
  }, {threshold:0.05});
  document.querySelectorAll('.gomes-section-chi-siamo,.gomes-section-percorso,.gomes-section-contatti,.gomes-footer').forEach(host => {
    const light = document.createElement('div');
    light.className = 'gomes-ambience'; light.setAttribute('aria-hidden', 'true');
    host.classList.add('gomes-ambient-host'); host.prepend(light);
    ambientObserver.observe(host);
  });
  // Architectural marks draw once when their section enters the reading area.
  const traceObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      entry.target.classList.add('is-trace-visible');
      traceObserver.unobserve(entry.target);
    });
  }, {threshold:0.15});
  document.querySelectorAll('.gomes-service-explorer,.gomes-process').forEach(element => traceObserver.observe(element));
  const revealObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting || entry.target.closest('[hidden]')) return;
      revealObserver.unobserve(entry.target);
      if (disabled() || document.hidden || !entry.target.animate) return;
      const words = [...entry.target.querySelectorAll(':scope > .gomes-text-word')];
      if (words.length) {
        words.forEach((word, i) => track(word.animate([
          {opacity:.15,transform:'translateY(.45em)',clipPath:'inset(0 0 100% 0)'},
          {opacity:1,transform:'translateY(0)',clipPath:'inset(-.12em 0 -.2em 0)'}
        ], {duration:650,delay:Math.min(i * 35, 180),easing:'cubic-bezier(.16,1,.3,1)',fill:'backwards'})));
        return;
      }
      const image = entry.target.tagName === 'IMG';
      const elements = entry.target.matches('.gomes-about-copy') ? [...entry.target.children] : [entry.target];
      elements.forEach((element, i) => {
        const frames = image
          ? [{clipPath:'inset(0 3% 0 0)',opacity:.8},{clipPath:'inset(0)',opacity:1}]
          : [{transform:'translateY(12px)',opacity:.45},{transform:'translateY(0)',opacity:1}];
        track(element.animate(frames, {duration:image ? 650 : 550,delay:Math.min(i * 65,160),easing:'cubic-bezier(.16,1,.3,1)',fill:'backwards'}));
      });
    });
  }, {threshold:0.12,rootMargin:'0px 0px -24px 0px'});
  document.querySelectorAll('.gomes-section>.gomes-container>.wp-block-group h2,.gomes-about>img,.gomes-about-copy,.gomes-process h3,.gomes-gallery-grid>figure,.gomes-footer-grid>div,.gomes-footer-grid>nav').forEach(element => revealObserver.observe(element));
})();
