(() => {
  'use strict';
  document.querySelectorAll('[data-hero]').forEach(hero => {
    const slides = [...hero.querySelectorAll('[data-hero-slide]')];
    // Fit the complete CMS title within two lines, including single-slide covers.
    const titles = [...hero.querySelectorAll('.gomes-hero-panel h1,.gomes-hero-panel h2')];
    const fitTitles = () => {
      titles.forEach(title => {
        title.style.removeProperty('font-size');
        const preferred = parseFloat(getComputedStyle(title).fontSize);
        const fits = () => title.getBoundingClientRect().height <= parseFloat(getComputedStyle(title).lineHeight) * 2 + 0.5 && title.scrollWidth <= title.clientWidth + 1;
        if (fits() || !title.clientWidth) return;
        let low = 1;
        let high = preferred;
        for (let step = 0; step < 10; step++) {
          const size = (low + high) / 2;
          title.style.fontSize = `${size}px`;
          if (fits()) low = size; else high = size;
        }
        title.style.fontSize = `${Math.floor(low * 10) / 10}px`;
      });
    };
    let fitFrame = null;
    const queueFit = () => {
      if (fitFrame !== null) cancelAnimationFrame(fitFrame);
      fitFrame = requestAnimationFrame(() => { fitFrame = null; fitTitles(); });
    };
    fitTitles();
    document.fonts?.ready.then(queueFit);
    window.addEventListener('resize', queueFit, {passive:true});
    // Start the photographic gesture only when its real image can be painted.
    // Text and the underlying photograph are never gated by this enhancement.
    const surface = slide => {
      const image = slide?.querySelector('img');
      if (!image) return;
      const reveal = () => {
        if (image.naturalWidth > 0 && slide.isConnected && slide.getAttribute('aria-hidden') === 'false') slide.classList.add('is-surfacing');
      };
      if (image.complete) reveal(); else image.addEventListener('load', reveal, {once:true});
    };
    slides[0]?.classList.add('is-entering');
    surface(slides[0]);
    const controls = hero.querySelector('[data-hero-controls]');
    if (slides.length < 2 || !controls) return;
    const choices = [...hero.querySelectorAll('[data-hero-go]')];
    const progress = hero.querySelector('.gomes-hero-progress span');
    const status = hero.querySelector('[data-hero-status]');
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
    let index = 0;
    let keyboardFocus = false;
    let onscreen = true;
    let timer = null;
    let progressAnimation = null;
    const interval = 6500;
    const stop = () => { hero.dataset.motionPaused = 'true'; window.clearTimeout(timer); timer = null; progressAnimation?.cancel(); };
    const schedule = () => {
      stop();
      if (reduced.matches || keyboardFocus || !onscreen || document.hidden) return;
      hero.dataset.motionPaused = 'false';
      if (!reduced.matches && progress.animate) {
        progressAnimation = progress.animate([{transform:'scaleX(0)'},{transform:'scaleX(1)'}], {duration:interval,fill:'forwards',easing:'linear'});
      }
      timer = window.setTimeout(() => show(index + 1, false), interval);
    };
    const show = (next, manual = true) => {
      index = (next + slides.length) % slides.length;

      slides.forEach((slide, i) => {
        const active = i === index;
        slide.setAttribute('aria-hidden', String(!active)); slide.inert = !active;
        slide.classList.toggle('is-entering', active);
        if (!active) slide.classList.remove('is-surfacing');
        if (active) {
          const image = slide.querySelector('img');
          if (image) image.loading = 'eager';
          surface(slide);
        }
      });
      const upcoming = slides[(index + 1) % slides.length].querySelector('img');
      if (upcoming) upcoming.loading = 'eager';
      choices.forEach((choice, i) => choice.setAttribute('aria-pressed', String(i === index)));
      if (manual) status.textContent = slides[index].dataset.announcement;
      schedule();
    };
    choices.forEach((choice, i) => choice.addEventListener('click', () => show(i)));
    hero.querySelector('[data-hero-prev]').addEventListener('click', () => show(index - 1));
    hero.querySelector('[data-hero-next]').addEventListener('click', () => show(index + 1));
    controls.addEventListener('keydown', event => {
      if (!['ArrowLeft','ArrowRight','Home','End'].includes(event.key)) return;
      event.preventDefault();
      keyboardFocus = true;
      show(event.key === 'Home' ? 0 : event.key === 'End' ? slides.length - 1 : index + (event.key === 'ArrowRight' ? 1 : -1));
      choices[index].focus();
    });
    // Only keyboard focus suspends the loop; pointer presence never freezes the cover.
    hero.addEventListener('focusin', event => {
      keyboardFocus = event.target.matches(':focus-visible'); schedule();
    });
    hero.addEventListener('focusout', event => {
      if (!hero.contains(event.relatedTarget)) { keyboardFocus = false; schedule(); }
    });
    document.addEventListener('visibilitychange', schedule);
    reduced.addEventListener('change', schedule);
    if ('IntersectionObserver' in window) {
      const observer = new IntersectionObserver(entries => { onscreen = entries[0].isIntersecting; schedule(); }, {threshold:0.25});
      observer.observe(hero);
    }
    const nextImage = slides[1].querySelector('img');
    if (nextImage) nextImage.loading = 'eager';
    controls.hidden = false;
    schedule();
  });
})();
