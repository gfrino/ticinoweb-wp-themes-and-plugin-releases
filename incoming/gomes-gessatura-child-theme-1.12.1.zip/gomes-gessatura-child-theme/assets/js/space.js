(() => {
  'use strict';
  document.querySelectorAll('[data-space]').forEach(space => {
    const nav = space.querySelector('[data-space-choices]');
    const choices = [...space.querySelectorAll('[data-space-choice]')];
    const variants = [...space.querySelectorAll('[data-space-variant]')];
    const stories = [...space.querySelectorAll('[data-space-story]')];
    const tools = space.querySelector('.gomes-space-tools');
    const layers = space.querySelector('[data-space-layers]');
    const phaseNote = space.querySelector('[data-space-phase-note]');
    const phases = [...space.querySelectorAll('[data-space-phase]')];
    const light = space.querySelector('[data-space-light]');
    const workspace = space.querySelector('#gomes-space-workspace');
    if (!nav || !tools || !choices.length || !variants.length || !phaseNote || !light) return;
    const reduced = matchMedia('(prefers-reduced-motion: reduce)');
    const motionOff = () => reduced.matches || document.body.classList.contains('gomes-motion-off');
    let timers = [];
    let entered = false;
    let selected = variants[0];
    const remembered = new Map();
    const cancel = () => { timers.forEach(clearTimeout); timers = []; };
    const phase = value => {
      space.dataset.phase = value;
      phaseNote.textContent = phaseNote.dataset[value];
      phases.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.spacePhase === value)));
    };
    const settle = () => { cancel(); phase('finished'); };
    const expand = value => {
      space.dataset.expanded = String(value); layers.setAttribute('aria-pressed', String(value));
      layers.querySelector('span').textContent = value ? '−' : '＋';
    };
    const play = () => {
      cancel(); expand(false);
      if (motionOff() || document.hidden) { phase('finished'); return; }
      phase('structure');
      timers = [setTimeout(() => phase('board'), 1500), setTimeout(() => { phase('finished'); timers = []; }, 3000)];
    };
    const chooseVariant = (button, animate = true) => {
      if (!button) return;
      selected = button; remembered.set(button.dataset.category, button.dataset.spaceVariant);
      cancel(); expand(false); space.dataset.mode = button.dataset.spaceVariant;
      variants.forEach(v => { v.hidden = v.dataset.category !== button.dataset.category; v.setAttribute('aria-pressed', String(v === button)); });
      stories.forEach(story => { story.hidden = story.dataset.spaceStory !== button.dataset.spaceVariant; });
      light.hidden = button.dataset.category !== 'carattere';
      if (light.hidden) space.dataset.night = 'false'; else space.dataset.night = String(space.querySelector('[data-space-night]').getAttribute('aria-pressed') === 'true');
      phase('finished'); if (animate) play();
    };
    const choose = (index, animate = true) => {
      const choice = choices[index]; if (!choice) return;
      choices.forEach((button, i) => { button.setAttribute('aria-selected', String(i === index)); button.tabIndex = i === index ? 0 : -1; });
      workspace.setAttribute('aria-labelledby', choice.id);
      const category = choice.dataset.spaceChoice;
      chooseVariant(variants.find(v => v.dataset.spaceVariant === remembered.get(category)) || variants.find(v => v.dataset.category === category), animate);
    };
    nav.setAttribute('role', 'tablist'); nav.setAttribute('aria-label', space.querySelector('h2')?.textContent || '');
    workspace.setAttribute('role', 'tabpanel'); workspace.tabIndex = 0;
    choices.forEach((choice, index) => {
      choice.id = `gomes-space-tab-${choice.dataset.spaceChoice}`;
      choice.setAttribute('role', 'tab'); choice.setAttribute('aria-controls', workspace.id);
      choice.addEventListener('click', () => choose(index));
      choice.addEventListener('keydown', event => {
        if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
        event.preventDefault(); const next = event.key === 'Home' ? 0 : event.key === 'End' ? choices.length - 1 : (index + (event.key === 'ArrowRight' ? 1 : -1) + choices.length) % choices.length;
        choices[next].focus(); choose(next);
      });
    });
    variants.forEach(button => button.addEventListener('click', () => chooseVariant(button)));
    phases.forEach(button => button.addEventListener('click', () => { cancel(); expand(false); phase(button.dataset.spacePhase); }));
    space.querySelector('[data-space-replay]').addEventListener('click', play);
    layers.addEventListener('click', () => { settle(); expand(layers.getAttribute('aria-pressed') !== 'true'); });
    const switchLed = space.querySelector('[data-led-switch]');
    switchLed.addEventListener('click', () => {
      settle(); expand(false);
      const on = switchLed.getAttribute('aria-pressed') !== 'true'; switchLed.setAttribute('aria-pressed', String(on)); space.dataset.ledOn = String(on);
    });
    space.querySelector('[data-space-night]').addEventListener('click', event => {
      settle(); expand(false);
      const button = event.currentTarget; const night = button.getAttribute('aria-pressed') !== 'true'; button.setAttribute('aria-pressed', String(night)); space.dataset.night = String(night);
    });
    const colors = [...space.querySelectorAll('[data-led-color]')];
    colors.forEach(button => button.addEventListener('click', () => {
      settle(); expand(false);
      colors.forEach(b => b.setAttribute('aria-pressed', String(b === button)));
      space.style.setProperty('--led-color', button.dataset.color);
      space.querySelector('[data-led-color-name]').textContent = button.textContent.trim();
    }));
    space.querySelector('[data-led-intensity]').addEventListener('input', event => {
      settle(); expand(false);
      const value = Math.max(0, Math.min(100, Number(event.target.value)));
      space.style.setProperty('--led-power', String(value / 100)); space.querySelector('[data-led-level]').textContent = `${value}%`;
    });
    const contact = space.querySelector('[data-space-contact]');
    let lastDraft = '';
    contact?.addEventListener('click', () => {
      const message = document.querySelector('.gomes-form textarea[name=messaggio]'); if (!message) return;
      const parts = [selected.textContent.trim()];
      if (!light.hidden && space.dataset.ledOn === 'true') parts.push(space.querySelector('[data-led-color-name]').textContent.trim(), space.querySelector('[data-led-level]').textContent.trim());
      const draft = `${contact.dataset.prefix} ${parts.join(' · ')}.`;
      if (!message.value.trim() || message.value === lastDraft) message.value = draft;
      else if (lastDraft && message.value.includes(lastDraft)) message.value = message.value.replace(lastDraft, draft);
      else if (message.value.length + draft.length + 2 <= message.maxLength) message.value += `\n\n${draft}`;
      lastDraft = draft; message.dispatchEvent(new Event('input', {bubbles:true}));
    });
    document.addEventListener('visibilitychange', () => { if (document.hidden) settle(); });
    reduced.addEventListener('change', settle);
    new MutationObserver(() => { if (motionOff()) settle(); }).observe(document.body, {attributes:true,attributeFilter:['class']});
    choose(0, false); space.classList.add('is-ready'); nav.hidden = false; tools.hidden = false; space.querySelector('[data-space-variants]').hidden = false;
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(entries => {
        if (entries[0].isIntersecting && !entered) { entered = true; play(); }
        if (!entries[0].isIntersecting) settle();
      }, {threshold:.25}).observe(space.querySelector('.gomes-space-canvas'));
    }
  });
})();
