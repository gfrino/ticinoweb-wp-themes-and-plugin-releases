(() => {
  'use strict';
  document.querySelectorAll('[data-services]').forEach((root, instance) => {
    const nav = root.querySelector('[data-service-nav]');
    const buttons = [...root.querySelectorAll('[data-service-select]')];
    const panels = [...root.querySelectorAll('[data-service-panel]')];
    if (buttons.length < 2 || panels.length !== buttons.length) return;
    let current = 0;
    nav.setAttribute('role', 'tablist');
    nav.setAttribute('aria-label', root.closest('section').querySelector('h2')?.textContent || '');
    const small = matchMedia('(max-width: 800px)');
    const orientation = () => nav.setAttribute('aria-orientation', small.matches ? 'horizontal' : 'vertical');
    orientation(); small.addEventListener('change', orientation);
    buttons.forEach((button, i) => {
      button.id = `gomes-service-tab-${instance}-${i}`;
      panels[i].id = `gomes-service-panel-${instance}-${i}`;
      button.setAttribute('role', 'tab');
      button.setAttribute('aria-controls', panels[i].id);
      panels[i].setAttribute('role', 'tabpanel');
      panels[i].setAttribute('aria-labelledby', button.id);
      panels[i].tabIndex = 0;
    });
    const select = (index, animate = true) => {
      current = (index + panels.length) % panels.length;
      panels.forEach((panel, i) => {
        const active = i === current;
        panel.inert = !active;
        panel.setAttribute('aria-hidden', String(!active));
        panel.classList.toggle('is-active', active);
        panel.classList.toggle('is-changing', active && animate);
        if (active) {
          const image = panel.querySelector('img');
          if (image) image.loading = 'eager';
        }
        buttons[i].setAttribute('aria-selected', String(active));
        buttons[i].tabIndex = active ? 0 : -1;
      });
    };
    buttons.forEach((button, i) => button.addEventListener('click', () => select(i)));
    nav.addEventListener('keydown', event => {
      const next = small.matches ? 'ArrowRight' : 'ArrowDown';
      const previous = small.matches ? 'ArrowLeft' : 'ArrowUp';
      if (![next, previous, 'Home', 'End'].includes(event.key)) return;
      event.preventDefault();
      select(event.key === 'Home' ? 0 : event.key === 'End' ? panels.length - 1 : current + (event.key === next ? 1 : -1));
      buttons[current].focus();
    });
    select(0, false);
    root.classList.add('is-ready');
    nav.hidden = false;
  });
})();
