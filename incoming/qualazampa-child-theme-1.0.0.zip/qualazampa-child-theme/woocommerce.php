<?php defined('ABSPATH') || exit;get_header(); ?>
<main id="main-content" class="qz-shop qz-container qz-section"><?php woocommerce_content(); ?></main><?php get_footer(); ?>
