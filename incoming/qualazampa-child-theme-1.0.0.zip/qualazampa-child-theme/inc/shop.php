<?php
defined('ABSPATH') || exit;
add_filter('woocommerce_product_query_tax_query',static function($tax){
    if(is_admin())return $tax;
    foreach(['qz_brand'=>'pa_marche','qz_kind'=>'pa_tipo-prodotto'] as $param=>$taxonomy){
        $id=isset($_GET[$param])?absint($_GET[$param]):0;
        if($id&&term_exists($id,$taxonomy))$tax[]=['taxonomy'=>$taxonomy,'field'=>'term_id','terms'=>[$id]];
    }
    return $tax;
});
function qz_shop_filters(){
    if(is_front_page())return;
    echo '<form class="qz-filters" method="get" action="'.esc_url(is_product_category()?get_term_link(get_queried_object()):wc_get_page_permalink('shop')).'">';
    foreach(['qz_brand'=>['pa_marche',__('Tutte le marche','qualazampa')],'qz_kind'=>['pa_tipo-prodotto',__('Tutti i tipi di prodotto','qualazampa')]] as $param=>$field){
        $selected=isset($_GET[$param])?absint($_GET[$param]):0;
        echo '<label><span class="screen-reader-text">'.esc_html($field[1]).'</span><select name="'.esc_attr($param).'">';echo '<option value="">'.esc_html($field[1]).'</option>';
        $terms=get_terms(['taxonomy'=>$field[0],'hide_empty'=>true]);if(!is_wp_error($terms))foreach($terms as $t)echo '<option value="'.esc_attr($t->term_id).'" '.selected($selected,$t->term_id,false).'>'.esc_html($t->name).'</option>';
        echo '</select></label>';
    }
    if(get_search_query())echo '<input type="hidden" name="s" value="'.esc_attr(get_search_query()).'"><input type="hidden" name="post_type" value="product">';
    echo '<button type="submit">'.esc_html__('Filtra prodotti','qualazampa').'</button><a href="'.esc_url(wc_get_page_permalink('shop')).'">'.esc_html__('Azzera filtri','qualazampa').'</a></form>';
}
add_action('woocommerce_before_shop_loop','qz_shop_filters',15);
add_action('woocommerce_no_products_found','qz_shop_filters',5);
add_filter('loop_shop_columns',static function(){return 4;});
add_filter('loop_shop_per_page',static function(){return 24;});
