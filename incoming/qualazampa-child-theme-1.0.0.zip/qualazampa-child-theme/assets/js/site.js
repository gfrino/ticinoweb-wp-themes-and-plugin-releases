(() => {
  'use strict';
  const header=document.querySelector('[data-header]');
  if(!header)return;
  const toggle=header.querySelector('.qz-menu-toggle');
  const nav=header.querySelector('#qz-navigation');
  const small=matchMedia('(max-width:760px)');
  function close(){header.removeAttribute('data-nav-open');toggle?.setAttribute('aria-expanded','false');}
  function size(){document.documentElement.style.setProperty('--qz-header',header.offsetHeight+'px');if(!small.matches)close();}
  header.setAttribute('data-nav-ready','');
  toggle?.addEventListener('click',()=>{const open=!header.hasAttribute('data-nav-open');header.toggleAttribute('data-nav-open',open);toggle.setAttribute('aria-expanded',String(open));});
  document.addEventListener('keydown',event=>{if(event.key==='Escape'&&header.hasAttribute('data-nav-open')){close();toggle?.focus();}});
  document.addEventListener('click',event=>{if(header.hasAttribute('data-nav-open')&&!header.contains(event.target))close();});
  nav?.addEventListener('click',event=>{if(event.target.closest('a'))close();});
  new ResizeObserver(size).observe(header);
  size();
})();
