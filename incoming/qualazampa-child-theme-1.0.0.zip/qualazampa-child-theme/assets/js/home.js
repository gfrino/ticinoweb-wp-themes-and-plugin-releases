(() => {
  'use strict';
  const opening=document.querySelector('[data-opening]');
  const stage=document.querySelector('[data-opening-stage]');
  const copy=document.querySelector('[data-hero-copy]');
  const end=document.querySelector('[data-hero-end]');
  const cuddle=document.querySelector('[data-cuddle]');
  const reduced=matchMedia('(prefers-reduced-motion:reduce)');
  const desktop=matchMedia('(min-width:761px)');
  const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
  let lenis=null,frame=0,needsUpdate=true;
  function configure(){
    lenis?.destroy();lenis=null;
    const immersive=desktop.matches&&!reduced.matches;
    opening?.toggleAttribute('data-immersive',immersive);
    if(immersive&&typeof Lenis==='function')lenis=new Lenis({duration:1.25,smoothWheel:true,syncTouch:false,anchors:{offset:-headerHeight()},autoRaf:false});
    if(!immersive){opening?.style.setProperty('--p','0');copy.inert=false;end.inert=true;}
    needsUpdate=true;
  }
  function headerHeight(){return document.querySelector('[data-header]')?.offsetHeight||0;}
  function render(time){
    if(document.hidden){frame=0;return;}
    lenis?.raf(time);
    if(needsUpdate&&opening&&stage&&desktop.matches&&!reduced.matches){
      const rect=opening.getBoundingClientRect();
      const distance=opening.offsetHeight-stage.offsetHeight;
      const p=clamp((headerHeight()-rect.top)/Math.max(1,distance));
      opening.style.setProperty('--p',p.toFixed(4));
      const enter=clamp((p-.48)/.4);
      end.style.opacity=String(enter);end.style.transform=`translateY(${24*(1-enter)}px)`;
      copy.inert=p>.44;end.inert=p<.7;
      if(cuddle){const r=cuddle.getBoundingClientRect();if(r.bottom>0&&r.top<innerHeight)cuddle.style.setProperty('--cuddle-y',`${clamp((innerHeight-r.top)/(innerHeight+r.height)) * 70-35}px`);}
      needsUpdate=false;
    }
    frame=requestAnimationFrame(render);
  }
  addEventListener('scroll',()=>{needsUpdate=true;},{passive:true});
  addEventListener('resize',()=>{needsUpdate=true;},{passive:true});
  reduced.addEventListener('change',configure);desktop.addEventListener('change',configure);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden&&!frame){needsUpdate=true;frame=requestAnimationFrame(render);}});
  configure();frame=requestAnimationFrame(render);
})();
