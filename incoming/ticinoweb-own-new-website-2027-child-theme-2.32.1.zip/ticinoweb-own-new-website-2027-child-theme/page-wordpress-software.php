<?php
/**
 * Template Name: ticinoWEB — Wordpress Software
 *
 * Catalogo dei plugin WordPress in vendita: i prodotti nascono da soli dalle release (inc/software-store.php).
 *
 * @package ticinoWEB_Child_Theme
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$tw_products = tw_software_products();
get_header();
?>
<main class="tw-public-archive tw-software">
	<header class="tw-public-hero">
		<div class="tw-shell">
			<p class="tw-blog-kicker"><?php esc_html_e( 'Software', 'ticinoweb-child-theme' ); ?></p>
			<h1><?php echo esc_html( get_the_title() ); ?></h1>
			<div class="tw-public-intro">
				<?php
				$tw_intro = trim( wp_strip_all_tags( get_post_field( 'post_content', get_the_ID() ) ) );
				echo $tw_intro ? wp_kses_post( wpautop( get_post_field( 'post_content', get_the_ID() ) ) ) : '<p>' . esc_html__( 'I plugin WordPress sviluppati da ticinoWEB: si acquistano una volta sola, con licenza perpetua e nessun canone annuale.', 'ticinoweb-child-theme' ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				?>
			</div>
		</div>
	</header>
	<div class="tw-shell tw-public-results">
		<?php if ( $tw_products ) : ?>
			<div class="tw-software-grid">
				<?php foreach ( $tw_products as $tw_product ) : ?>
					<?php
					$tw_pid   = $tw_product->get_id();
					$tw_url   = get_permalink( $tw_pid );
					$tw_ver   = get_post_meta( $tw_pid, '_twss_version', true );
					$tw_short = wp_trim_words( wp_strip_all_tags( $tw_product->get_short_description() ), 28 );
					?>
					<article class="tw-software-card">
						<?php if ( $tw_product->get_image_id() ) : ?>
							<a class="tw-software-card__media" href="<?php echo esc_url( $tw_url ); ?>" tabindex="-1" aria-hidden="true"><?php echo wp_get_attachment_image( $tw_product->get_image_id(), 'medium', false, array( 'alt' => '', 'loading' => 'lazy', 'decoding' => 'async' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
						<?php endif; ?>
						<h2><a href="<?php echo esc_url( $tw_url ); ?>"><?php echo esc_html( $tw_product->get_name() ); ?></a></h2>
						<?php if ( $tw_short ) : ?><p><?php echo esc_html( $tw_short ); ?></p><?php endif; ?>
						<p class="tw-software-card__meta">
							<?php if ( $tw_ver ) : ?><span><?php echo esc_html( sprintf( /* translators: %s: plugin version */ __( 'Versione %s', 'ticinoweb-child-theme' ), $tw_ver ) ); ?></span><?php endif; ?>
							<span><?php esc_html_e( 'Licenza perpetua', 'ticinoweb-child-theme' ); ?></span>
						</p>
						<p class="tw-software-card__buy"><strong><?php echo wp_kses_post( $tw_product->get_price_html() ); ?></strong>
							<a class="tw-blog-card__link" href="<?php echo esc_url( $tw_url ); ?>"><?php esc_html_e( 'Scopri di più', 'ticinoweb-child-theme' ); ?><span class="tw-arrow" aria-hidden="true"></span></a></p>
					</article>
				<?php endforeach; ?>
			</div>
		<?php else : ?>
			<div class="tw-public-empty">
				<h2><?php esc_html_e( 'Nuovi plugin in arrivo', 'ticinoweb-child-theme' ); ?></h2>
				<p><?php esc_html_e( 'Stiamo preparando il catalogo. Hai bisogno di una funzione su misura per il tuo sito? Scrivici.', 'ticinoweb-child-theme' ); ?></p>
				<div class="tw-public-actions"><a class="tw-public-action-primary" href="<?php echo esc_url( function_exists( 'tw_home_mapped_url' ) ? tw_home_mapped_url( 'page_contatti', 'contatti' ) : home_url( '/contatti/' ) ); ?>"><?php esc_html_e( 'Contattaci', 'ticinoweb-child-theme' ); ?></a></div>
			</div>
		<?php endif; ?>
	</div>
</main>
<?php get_footer(); ?>
