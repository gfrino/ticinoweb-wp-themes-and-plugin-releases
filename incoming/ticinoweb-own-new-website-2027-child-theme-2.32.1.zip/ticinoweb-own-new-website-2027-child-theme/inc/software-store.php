<?php
/**
 * Software store: ogni plugin WordPress pubblicato nel repo delle release diventa da solo un prodotto
 * WooCommerce (prezzo predefinito 199 CHF, licenza perpetua) e si aggiorna a ogni nuova versione.
 * I temi sono ignorati. Pagina pubblica «Wordpress Software»: page-wordpress-software.php.
 *
 * @package ticinoWEB_Child_Theme
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( ! defined( 'TWSS_REPO' ) ) {
	define( 'TWSS_REPO', 'gfrino/ticinoweb-wp-themes-and-plugin-releases' );
}

foreach ( array( 'settings', 'markdown', 'github', 'package', 'product', 'sync', 'frontend', 'rest' ) as $tw_ss_part ) {
	require_once get_stylesheet_directory() . '/inc/software-store/class-twss-' . $tw_ss_part . '.php';
}
if ( is_admin() ) {
	require_once get_stylesheet_directory() . '/inc/software-store/class-twss-admin.php';
	Twss_Admin::init();
}
if ( defined( 'WP_CLI' ) && WP_CLI ) {
	require_once get_stylesheet_directory() . '/inc/software-store/class-twss-cli.php';
}
Twss_Frontend::init();
Twss_Rest::init();
add_action( Twss_Sync::HOOK, array( 'Twss_Sync', 'cron' ) );

/** Controllo orario: si programma da solo se manca (cambio tema, cron perso). */
add_action( 'init', function () {
	if ( ! wp_next_scheduled( Twss_Sync::HOOK ) ) {
		wp_schedule_event( time() + 120, 'hourly', Twss_Sync::HOOK );
	}
} );
add_action( 'switch_theme', function () { wp_clear_scheduled_hook( Twss_Sync::HOOK ); } );

/** Prodotti della pagina «Wordpress Software» (categoria impostata in WooCommerce → Software Store). */
function tw_software_products() {
	if ( ! function_exists( 'wc_get_products' ) ) { return array(); }
	return wc_get_products( array(
		'status' => 'publish', 'limit' => 60, 'orderby' => 'title', 'order' => 'ASC',
		'category' => array( (string) Twss_Settings::get( 'category' ) ), 'visibility' => 'catalog',
	) );
}

function tw_software_enqueue() {
	if ( is_page_template( 'page-wordpress-software.php' ) ) {
		wp_enqueue_style( 'ticinoweb-child-software', get_stylesheet_directory_uri() . '/assets/css/software-store.css', array( 'ticinoweb-child-site' ), wp_get_theme()->get( 'Version' ) );
	}
}
add_action( 'wp_enqueue_scripts', 'tw_software_enqueue', 40 );
