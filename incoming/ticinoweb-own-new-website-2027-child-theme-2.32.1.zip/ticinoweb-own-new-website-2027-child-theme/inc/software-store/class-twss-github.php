<?php
if (!defined('ABSPATH')) {
    exit;
}

/** Lettura del repo pubblico delle release (API GitHub, richieste condizionali con ETag). */
class Twss_Github {
    const ETAG = 'twss_etag';
    const MAX_ZIP = 20971520; // 20 MB: oltre sono temi pesanti, mai plugin

    private static function headers() {
        $h = array('Accept' => 'application/vnd.github+json', 'User-Agent' => 'ticinoweb-child-theme');
        if (defined('TWSS_GITHUB_TOKEN') && TWSS_GITHUB_TOKEN) {
            $h['Authorization'] = 'Bearer ' . TWSS_GITHUB_TOKEN;
        }
        return $h;
    }

    /** Estrae {slug, version} da un tag `<slug>-v<versione>`. */
    public static function parse_tag($tag) {
        if (preg_match('/^(.+)-v(\d+(?:\.\d+){1,3})$/', (string) $tag, $m)) {
            return array($m[1], $m[2]);
        }
        return null;
    }

    /**
     * Release più recente per slug. Con $force legge tutte le pagine; altrimenti solo la prima e,
     * se GitHub risponde 304 (nulla di nuovo), restituisce null senza consumare quota.
     *
     * @return array|null|WP_Error slug => {tag, version, notes, published, zip_url, zip_size}
     */
    public static function latest_by_slug($force = false) {
        $out = array();
        $pages = $force ? 10 : 1;
        for ($p = 1; $p <= $pages; $p++) {
            $headers = self::headers();
            $etag = get_option(self::ETAG, '');
            if (1 === $p && !$force && $etag) {
                $headers['If-None-Match'] = $etag;
            }
            $res = wp_remote_get('https://api.github.com/repos/' . TWSS_REPO . '/releases?per_page=100&page=' . $p, array('timeout' => 25, 'headers' => $headers));
            if (is_wp_error($res)) {
                return $res;
            }
            $code = wp_remote_retrieve_response_code($res);
            if (304 === $code) {
                return null;
            }
            if (200 !== $code) {
                return new WP_Error('twss_github', sprintf('GitHub ha risposto %d', $code));
            }
            if (1 === $p && ($e = wp_remote_retrieve_header($res, 'etag'))) {
                update_option(self::ETAG, $e, false);
            }
            $list = json_decode(wp_remote_retrieve_body($res), true);
            if (!is_array($list) || !$list) {
                break;
            }
            foreach ($list as $r) {
                $parsed = self::parse_tag(isset($r['tag_name']) ? $r['tag_name'] : '');
                if (!$parsed || !empty($r['draft']) || !empty($r['prerelease'])) {
                    continue;
                }
                list($slug, $ver) = $parsed;
                $zip = null;
                foreach ((array) ($r['assets'] ?? array()) as $a) {
                    if (isset($a['name']) && $a['name'] === $slug . '-' . $ver . '.zip') {
                        $zip = $a;
                    }
                }
                if (!$zip) {
                    continue;
                }
                if (isset($out[$slug]) && version_compare($out[$slug]['version'], $ver, '>=')) {
                    continue;
                }
                $out[$slug] = array(
                    'tag'       => $r['tag_name'],
                    'version'   => $ver,
                    'notes'     => (string) ($r['body'] ?? ''),
                    'published' => (string) ($r['published_at'] ?? ''),
                    'zip_url'   => $zip['browser_download_url'],
                    'zip_size'  => (int) $zip['size'],
                );
            }
            if (count($list) < 100) {
                break;
            }
        }
        return $out;
    }

    /** Scarica lo zip in un file temporaneo (da cancellare a cura del chiamante). */
    public static function download($url) {
        if (!function_exists('download_url')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }
        if (0 !== strpos($url, 'https://github.com/' . TWSS_REPO . '/releases/download/')) {
            return new WP_Error('twss_url', 'URL dello zip non riconosciuto');
        }
        return download_url($url, 120);
    }

    /** File del repo (details/<slug>/…); null se non esiste. */
    public static function raw($path) {
        $res = wp_remote_get('https://raw.githubusercontent.com/' . TWSS_REPO . '/main/' . ltrim($path, '/'), array('timeout' => 20, 'headers' => array('User-Agent' => 'ticinoweb-child-theme')));
        if (is_wp_error($res) || 200 !== wp_remote_retrieve_response_code($res)) {
            return null;
        }
        return wp_remote_retrieve_body($res);
    }
}
