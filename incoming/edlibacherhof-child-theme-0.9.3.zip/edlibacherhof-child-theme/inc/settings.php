<?php
/**
 * Aspetto → Personalizza → «Edlibacherhof»: i testi e le foto della pagina iniziale che non stanno già nel CMS del parent.
 * Indirizzo, WhatsApp, email, orari, logo e «Chi siamo» si cambiano in ticinoWEB CMS; i piatti e i prezzi in Prodotti.
 * Valori letti con edlibacherhof_setting('<chiave>') (theme_mod «edlibacherhof_<chiave>»).
 *
 * @package edlibacherhof-child-theme
 */

defined('ABSPATH') || exit;

/** Slug di una galleria del parent: solo una esistente, altrimenti vuoto. */
function edlibacherhof_sanitize_gallery($value)
{
    $value = sanitize_title((string) $value);
    if ($value === '' || !taxonomy_exists('ticinoweb_media_gallery')) {
        return $value;
    }
    return term_exists($value, 'ticinoweb_media_gallery') ? $value : '';
}

/** Le gallerie del parent per i menu a tendina: [slug => nome]. */
function edlibacherhof_gallery_choices()
{
    $choices = array('' => __('— nessuna —', 'edlibacherhof-child-theme'));
    if (!taxonomy_exists('ticinoweb_media_gallery')) {
        return $choices;
    }
    $terms = get_terms(array('taxonomy' => 'ticinoweb_media_gallery', 'hide_empty' => false));
    foreach (is_array($terms) ? $terms : array() as $term) {
        $choices[$term->slug] = $term->name;
    }
    return $choices;
}

add_action('customize_register', function ($wp_customize) {
    $wp_customize->add_panel('edlibacherhof', array(
        'title'       => __('Edlibacherhof', 'edlibacherhof-child-theme'),
        'priority'    => 30,
        'description' => __('Testi e foto della pagina iniziale. Indirizzo, WhatsApp, email, orari, logo e «Chi siamo» si cambiano in ticinoWEB CMS; piatti e prezzi in Prodotti.', 'edlibacherhof-child-theme'),
    ));

    $section = function ($id, $title, $description = '') use ($wp_customize) {
        $wp_customize->add_section('edlibacherhof_' . $id, array('title' => $title, 'panel' => 'edlibacherhof', 'description' => $description));
    };
    $text = function ($section, $key, $label, $description = '', $type = 'text') use ($wp_customize) {
        $wp_customize->add_setting('edlibacherhof_' . $key, array(
            'default'           => '',
            'sanitize_callback' => $type === 'textarea' ? 'sanitize_textarea_field' : ($type === 'url' ? 'esc_url_raw' : 'sanitize_text_field'),
        ));
        $wp_customize->add_control('edlibacherhof_' . $key, array('section' => 'edlibacherhof_' . $section, 'type' => $type, 'label' => $label, 'description' => $description));
    };
    $image = function ($section, $key, $label, $description = '') use ($wp_customize) {
        $wp_customize->add_setting('edlibacherhof_' . $key, array('default' => 0, 'sanitize_callback' => 'absint'));
        $wp_customize->add_control(new WP_Customize_Media_Control($wp_customize, 'edlibacherhof_' . $key, array(
            'section' => 'edlibacherhof_' . $section, 'mime_type' => 'image', 'label' => $label, 'description' => $description,
        )));
    };

    // 1. Oben auf der Seite.
    $section('hero', __('In cima alla pagina', 'edlibacherhof-child-theme'));
    $text('hero', 'hero_title', __('Titolo', 'edlibacherhof-child-theme'), __('Cosa offrite e dove. Una parola tra *asterischi* riceve il filo giallo. Vuoto: il nome del sito.', 'edlibacherhof-child-theme'));
    $text('hero', 'hero_text', __('Testo sotto il titolo', 'edlibacherhof-child-theme'), __('Una o due frasi.', 'edlibacherhof-child-theme'), 'textarea');
    $text('hero', 'hero_note', __('Riga sotto i bottoni', 'edlibacherhof-child-theme'), __('Per esempio «Montag Ruhetag · Dienstag bis Sonntag geöffnet». Vuoto: la riga non compare.', 'edlibacherhof-child-theme'));
    $image('hero', 'hero_image', __('Foto accanto al titolo', 'edlibacherhof-child-theme'), __('Quadrata, almeno 1600 pixel.', 'edlibacherhof-child-theme'));
    $wp_customize->add_setting('edlibacherhof_hero_gallery_slug', array('default' => '', 'sanitize_callback' => 'edlibacherhof_sanitize_gallery'));
    $wp_customize->add_control('edlibacherhof_hero_gallery_slug', array(
        'section' => 'edlibacherhof_hero', 'type' => 'select', 'choices' => edlibacherhof_gallery_choices(),
        'label' => __('Foto che scorrono accanto al titolo', 'edlibacherhof-child-theme'),
        'description' => __('Una galleria di Media → Gallerie (foto quadrate o quasi, almeno 1200 pixel): le foto si alternano ogni 5 secondi dopo la foto qui sopra. Vuoto: resta solo la foto qui sopra.', 'edlibacherhof-child-theme'),
    ));
    $image('hero', 'strip_image', __('Foto larga sotto', 'edlibacherhof-child-theme'), __('La casa vista da fuori, orizzontale (3:1), almeno 2400 pixel di larghezza. Vuoto: nessuna foto.', 'edlibacherhof-child-theme'));
    $text('hero', 'strip_caption', __('Didascalia', 'edlibacherhof-child-theme'));

    // 2. Mittagsmenü.
    $section('lunch', __('Menu del pranzo', 'edlibacherhof-child-theme'), __('Fino a tre gruppi. Un piatto per riga, descrizione dopo una barra verticale: «Funghi | Frische Champignons». Un gruppo senza nome non compare; senza gruppi la sezione non compare.', 'edlibacherhof-child-theme'));
    $text('lunch', 'lunch_title', __('Titolo', 'edlibacherhof-child-theme'));
    $text('lunch', 'lunch_days', __('Riga sotto il titolo', 'edlibacherhof-child-theme'), __('Per esempio «Dienstag bis Freitag · Menü mit Salat inklusive».', 'edlibacherhof-child-theme'));
    $text('lunch', 'lunch_text', __('Nota', 'edlibacherhof-child-theme'), '', 'textarea');
    for ($i = 1; $i <= 3; $i++) {
        /* translators: %d: numero del gruppo */
        $n = sprintf(__('Gruppo %d', 'edlibacherhof-child-theme'), $i);
        $text('lunch', "lunch_{$i}_name", $n . ': ' . __('Nome', 'edlibacherhof-child-theme'));
        $text('lunch', "lunch_{$i}_price", $n . ': ' . __('Prezzo', 'edlibacherhof-child-theme'), __('Per esempio «Fr. 17.00».', 'edlibacherhof-child-theme'));
        $text('lunch', "lunch_{$i}_price_note", $n . ': ' . __('Aggiunta al prezzo', 'edlibacherhof-child-theme'), __('Per esempio «mit Salat Fr. 19.00».', 'edlibacherhof-child-theme'));
        $text('lunch', "lunch_{$i}_items", $n . ': ' . __('Piatti', 'edlibacherhof-child-theme'), '', 'textarea');
        $text('lunch', "lunch_{$i}_note", $n . ': ' . __('Nota sotto i piatti', 'edlibacherhof-child-theme'));
        $wp_customize->add_setting("edlibacherhof_lunch_{$i}_icon", array('default' => edlibacherhof_lunch_icon_default($i), 'sanitize_callback' => 'edlibacherhof_sanitize_lunch_icon'));
        $wp_customize->add_control("edlibacherhof_lunch_{$i}_icon", array(
            'section' => 'edlibacherhof_lunch', 'type' => 'select', 'choices' => edlibacherhof_lunch_icon_choices(),
            'label'   => $n . ': ' . __('Icona', 'edlibacherhof-child-theme'),
        ));
    }

    // 3. Speisekarte.
    $section('menu', __('Carta dei piatti', 'edlibacherhof-child-theme'), __('Le finestre sono le categorie dei prodotti che hanno un’immagine (Prodotti → Categorie), la prima è la più grande; le altre categorie compaiono in una riga sotto.', 'edlibacherhof-child-theme'));
    $text('menu', 'menu_title', __('Titolo', 'edlibacherhof-child-theme'));
    $text('menu', 'menu_text', __('Frase sotto il titolo', 'edlibacherhof-child-theme'), '', 'textarea');
    $text('menu', 'shop_title', __('Titolo della pagina per ordinare', 'edlibacherhof-child-theme'), __('Vuoto: «Speisekarte».', 'edlibacherhof-child-theme'));
    $text('menu', 'shop_text', __('Testo in cima alla pagina per ordinare', 'edlibacherhof-child-theme'), __('Per esempio come si ritira e si paga, in una frase.', 'edlibacherhof-child-theme'), 'textarea');
    $text('menu', 'order_url', __('Link «Online bestellen»', 'edlibacherhof-child-theme'), __('Vuoto: la pagina del negozio.', 'edlibacherhof-child-theme'), 'url');

    // 3b. Galleria.
    $section('gallery', __('Galleria', 'edlibacherhof-child-theme'), __('Le foto della galleria scelta, nell’ordine di Media → Gallerie. Il testo alternativo di ogni foto compare quando la si apre. Senza galleria la sezione non compare.', 'edlibacherhof-child-theme'));
    $text('gallery', 'gallery_title', __('Titolo', 'edlibacherhof-child-theme'));
    $text('gallery', 'gallery_text', __('Frase sotto il titolo', 'edlibacherhof-child-theme'), '', 'textarea');
    $wp_customize->add_setting('edlibacherhof_gallery_slug', array('default' => '', 'sanitize_callback' => 'edlibacherhof_sanitize_gallery'));
    $wp_customize->add_control('edlibacherhof_gallery_slug', array(
        'section' => 'edlibacherhof_gallery', 'type' => 'select', 'choices' => edlibacherhof_gallery_choices(),
        'label' => __('Galleria da mostrare', 'edlibacherhof-child-theme'),
    ));

    // 4. Bestellen.
    $section('order', __('Come ordinare', 'edlibacherhof-child-theme'));
    $text('order', 'order_title', __('Titolo', 'edlibacherhof-child-theme'));
    $text('order', 'order_text', __('Testo', 'edlibacherhof-child-theme'), '', 'textarea');
    $text('order', 'order_pickup', __('Ritiro', 'edlibacherhof-child-theme'), '', 'textarea');
    $text('order', 'order_payment', __('Pagamento', 'edlibacherhof-child-theme'), '', 'textarea');

    // 5. Restaurant.
    $section('restaurant', __('Restaurant', 'edlibacherhof-child-theme'), __('Titolo e testo vengono da ticinoWEB CMS → Chi siamo.', 'edlibacherhof-child-theme'));
    $text('restaurant', 'restaurant_signature', __('Firma', 'edlibacherhof-child-theme'), __('Per esempio «Salvino und Tetiana».', 'edlibacherhof-child-theme'));
    $image('restaurant', 'restaurant_image', __('Foto (verticale)', 'edlibacherhof-child-theme'));
    $image('restaurant', 'restaurant_map', __('Cartina o seconda foto (orizzontale)', 'edlibacherhof-child-theme'));
    $text('restaurant', 'restaurant_map_caption', __('Didascalia', 'edlibacherhof-child-theme'));
});

/** Icone per i gruppi del menu del pranzo (dalla famiglia del tema, assets/icons). */
function edlibacherhof_lunch_icon_choices()
{
    return array(
        ''         => __('Nessuna', 'edlibacherhof-child-theme'),
        'pizza'    => __('Pizza', 'edlibacherhof-child-theme'),
        'pasta'    => __('Pasta', 'edlibacherhof-child-theme'),
        'carne'    => __('Carne', 'edlibacherhof-child-theme'),
        'insalata' => __('Insalata', 'edlibacherhof-child-theme'),
        'posate'   => __('Posate', 'edlibacherhof-child-theme'),
    );
}

/** Icona proposta per il gruppo n (pizza, pasta, carne: l'ordine del menu di oggi). */
function edlibacherhof_lunch_icon_default($i)
{
    $base = array(1 => 'pizza', 2 => 'pasta', 3 => 'carne');
    return $base[(int) $i] ?? '';
}

function edlibacherhof_sanitize_lunch_icon($value)
{
    return array_key_exists((string) $value, edlibacherhof_lunch_icon_choices()) ? (string) $value : '';
}
