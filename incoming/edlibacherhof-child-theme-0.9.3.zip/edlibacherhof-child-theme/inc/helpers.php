<?php
/**
 * Funzioni di supporto del tema: testi dal database (passano dal livello di traduzione del parent), contatti e
 * orari del CMS, immagini della Libreria media, menu del pranzo, categorie del negozio.
 * Nessun dato del cliente sta qui: tutto si legge dal database a runtime.
 *
 * @package edlibacherhof-child-theme
 */

defined('ABSPATH') || exit;

/** Testo dal database, attraverso il livello di traduzione del parent (tW Translate / WPML). */
function edlibacherhof_t($text, $key)
{
    return function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text((string) $text, 'edlibacherhof:' . $key) : (string) $text;
}

/** URL nella lingua corrente, tramite il livello del parent. */
function edlibacherhof_url($url, $key)
{
    return function_exists('ticinoweb_frontend_url') ? ticinoweb_frontend_url($url, 'edlibacherhof:' . $key) : $url;
}

/** Un'impostazione del Personalizza (theme_mod «edlibacherhof_<chiave>»). */
function edlibacherhof_setting($key, $default = '')
{
    return get_theme_mod('edlibacherhof_' . $key, $default);
}

/** Testo di un'impostazione, già tradotto ('' se vuoto). */
function edlibacherhof_text($key)
{
    $value = trim((string) edlibacherhof_setting($key, ''));
    return $value === '' ? '' : edlibacherhof_t($value, 'setting:' . $key);
}

/**
 * Titolo con una parola evidenziata: «Pizza in *Edlibach*» → la parola tra asterischi ha il filo giallo dell'insegna.
 * Restituisce HTML già pulito.
 */
function edlibacherhof_title_html($text)
{
    $html = esc_html((string) $text);
    $html = preg_replace('/\*([^*]+)\*/u', '<em>$1</em>', $html);
    // L'ultima parola non resta mai sola a capo.
    return preg_replace('/ (\S+)$/u', '&nbsp;$1', (string) $html);
}

/* -------------------------------------------------------------------------
 * Contatti e orari: sempre dal CMS del parent (ticinoweb_contact_*)
 * ---------------------------------------------------------------------- */

/** I contatti del sito, già puliti. Ogni voce può essere ''. */
function edlibacherhof_contacts()
{
    static $contacts = null;
    if ($contacts !== null) {
        return $contacts;
    }
    $mobile  = trim((string) get_option('ticinoweb_contact_phone_mobile', ''));
    $phone   = trim((string) get_option('ticinoweb_contact_phone', ''));
    $address = trim((string) get_option('ticinoweb_contact_address', ''));
    $contacts = array(
        'mobile'    => $mobile,
        'phone'     => $phone,
        'email'     => sanitize_email((string) get_option('ticinoweb_contact_email', '')),
        'address'   => $address !== '' ? edlibacherhof_t($address, 'contact:address') : '',
        'facebook'  => esc_url_raw((string) get_option('ticinoweb_contact_facebook', '')),
        'instagram' => esc_url_raw((string) get_option('ticinoweb_contact_instagram', '')),
    );
    return $contacts;
}

/** Le righe dell'indirizzo del CMS (una per riga o separate da virgola). */
function edlibacherhof_address_lines()
{
    return array_values(array_filter(array_map('trim', preg_split('/\r\n|\r|\n|,/', edlibacherhof_contacts()['address']))));
}

/** Numero leggibile: +41 79 154 27 51 → 079 154 27 51 (come si scrive in Svizzera). */
function edlibacherhof_phone_display($number)
{
    $digits = preg_replace('/[^\d+]/', '', (string) $number);
    if (preg_match('/^(?:\+41|0041)(\d{2})(\d{3})(\d{2})(\d{2})$/', $digits, $m)) {
        return '0' . $m[1] . ' ' . $m[2] . ' ' . $m[3] . ' ' . $m[4];
    }
    return trim((string) $number);
}

/** Link WhatsApp del cellulare del CMS ('' se manca). */
function edlibacherhof_whatsapp_url()
{
    $digits = preg_replace('/\D/', '', edlibacherhof_contacts()['mobile']);
    if ($digits === '') {
        return '';
    }
    if (strpos($digits, '00') === 0) {
        $digits = substr($digits, 2);
    } elseif (strpos($digits, '0') === 0) {
        $digits = '41' . substr($digits, 1);
    }
    return 'https://wa.me/' . $digits;
}

/** Indicazioni stradali su Google Maps: è un link, nessuna richiesta a Google finché non lo si apre. */
function edlibacherhof_map_url()
{
    $lines = edlibacherhof_address_lines();
    if (!$lines) {
        return '';
    }
    return 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode(get_bloginfo('name') . ', ' . implode(', ', $lines));
}

/**
 * Gli orari del CMS (ticinoweb_contact_opening_hours) giorno per giorno:
 * [['giorno' => 'Montag', 'testo' => '11.00–14.00 · 17.00–22.00'], …]. Vuoto se nessun giorno è compilato.
 */
function edlibacherhof_hours()
{
    $hours = get_option('ticinoweb_contact_opening_hours', array());
    if (!is_array($hours) || !$hours) {
        return array();
    }
    $days = array(
        'monday'    => __('Montag', 'edlibacherhof-child-theme'),
        'tuesday'   => __('Dienstag', 'edlibacherhof-child-theme'),
        'wednesday' => __('Mittwoch', 'edlibacherhof-child-theme'),
        'thursday'  => __('Donnerstag', 'edlibacherhof-child-theme'),
        'friday'    => __('Freitag', 'edlibacherhof-child-theme'),
        'saturday'  => __('Samstag', 'edlibacherhof-child-theme'),
        'sunday'    => __('Sonntag', 'edlibacherhof-child-theme'),
    );
    $rows = array();
    foreach ($days as $key => $label) {
        $day = isset($hours[$key]) && is_array($hours[$key]) ? $hours[$key] : array('closed' => 1);
        if (!empty($day['open_24h'])) {
            $text = __('24 Stunden geöffnet', 'edlibacherhof-child-theme');
        } elseif (!empty($day['closed']) || empty($day['slots'])) {
            $text = __('Ruhetag', 'edlibacherhof-child-theme');
        } else {
            $slots = array();
            foreach ((array) $day['slots'] as $slot) {
                $open  = str_replace(':', '.', (string) ($slot['open'] ?? ''));
                $close = str_replace(':', '.', (string) ($slot['close'] ?? ''));
                if ($open !== '' || $close !== '') {
                    $slots[] = $open . '–' . $close;
                }
            }
            $text = $slots ? implode(' · ', $slots) : __('Ruhetag', 'edlibacherhof-child-theme');
        }
        $rows[] = array('giorno' => $label, 'testo' => $text);
    }
    return $rows;
}

/* -------------------------------------------------------------------------
 * Immagini, pagine, negozio
 * ---------------------------------------------------------------------- */

/** Un'immagine della Libreria media con srcset; testo alternativo dalla Libreria. '' se manca. */
function edlibacherhof_image($id, $size, array $attrs = array())
{
    $id = (int) $id;
    if (!$id || !wp_attachment_is_image($id)) {
        return '';
    }
    $attrs = array_merge(array('loading' => 'lazy', 'decoding' => 'async'), $attrs);
    $alt   = trim((string) get_post_meta($id, '_wp_attachment_image_alt', true));
    $attrs['alt'] = $alt !== '' ? edlibacherhof_t($alt, 'alt:' . $id) : '';
    return wp_get_attachment_image($id, $size, false, $attrs);
}

/** Le foto di una galleria del parent (Media → Gallerie), nell'ordine del gestore. */
function edlibacherhof_gallery_images($slug, $max = 12)
{
    if ((string) $slug === '' || !taxonomy_exists('ticinoweb_media_gallery')) {
        return array();
    }
    $term = get_term_by('slug', sanitize_title($slug), 'ticinoweb_media_gallery');
    if (!($term instanceof WP_Term)) {
        return array();
    }
    $ids = get_posts(array(
        'post_type'      => 'attachment',
        'post_status'    => 'inherit',
        'post_mime_type' => 'image',
        'posts_per_page' => 100,
        'fields'         => 'ids',
        'no_found_rows'  => true,
        'tax_query'      => array(array('taxonomy' => 'ticinoweb_media_gallery', 'field' => 'term_id', 'terms' => $term->term_id)),
    ));
    $order = get_term_meta($term->term_id, '_ticinoweb_gallery_order', true);
    if (is_array($order) && $order) {
        $order = array_map('intval', $order);
        usort($ids, function ($a, $b) use ($order) {
            $pa = array_search((int) $a, $order, true);
            $pb = array_search((int) $b, $order, true);
            return ($pa === false ? 99999 : $pa) <=> ($pb === false ? 99999 : $pb);
        });
    }
    return array_slice(array_map('intval', $ids), 0, (int) $max);
}

/** Link della pagina «Online bestellen»: l'impostazione, altrimenti il negozio WooCommerce, altrimenti ''. */
function edlibacherhof_order_url()
{
    $url = trim((string) edlibacherhof_setting('order_url', ''));
    if ($url === '' && function_exists('wc_get_page_permalink')) {
        $url = (string) wc_get_page_permalink('shop');
    }
    return $url === '' ? '' : edlibacherhof_url($url, 'url:order');
}

/** URL di una sezione della home (#mittagsmenue …), anche dalle pagine interne. */
function edlibacherhof_section_url($id)
{
    return is_front_page() ? '#' . $id : edlibacherhof_url(home_url('/'), 'url:home') . '#' . $id;
}

/** Link della pagina Privacy: impostazione di tW SEO, altrimenti quella di WordPress. */
function edlibacherhof_privacy_url()
{
    $url = trim((string) get_option('tw_privacy_policy_url', ''));
    if ($url === '' && function_exists('get_privacy_policy_url')) {
        $url = get_privacy_policy_url();
    }
    return $url;
}

/**
 * Il menu del pranzo, dalle impostazioni: fino a tre gruppi, ognuno con nome, prezzo, nota sul prezzo, piatti e nota finale.
 * Un piatto per riga: «Nome | Descrizione» (la descrizione si può omettere). Gruppi senza nome si saltano.
 */
function edlibacherhof_lunch_groups()
{
    $groups = array();
    for ($i = 1; $i <= 3; $i++) {
        $name = edlibacherhof_text("lunch_{$i}_name");
        if ($name === '') {
            continue;
        }
        $items = array();
        foreach (preg_split('/\r\n|\r|\n/', (string) edlibacherhof_setting("lunch_{$i}_items", '')) as $n => $line) {
            $line = trim($line);
            if ($line === '') {
                continue;
            }
            $parts   = array_map('trim', explode('|', $line, 2));
            $items[] = array(
                'nome'        => edlibacherhof_t($parts[0], "lunch:{$i}:{$n}:name"),
                'descrizione' => isset($parts[1]) && $parts[1] !== '' ? edlibacherhof_t($parts[1], "lunch:{$i}:{$n}:text") : '',
            );
        }
        $groups[] = array(
            'nome'   => $name,
            'prezzo' => edlibacherhof_text("lunch_{$i}_price"),
            'nota_prezzo' => edlibacherhof_text("lunch_{$i}_price_note"),
            'piatti' => $items,
            'nota'   => edlibacherhof_text("lunch_{$i}_note"),
            'icona'  => (string) edlibacherhof_setting("lunch_{$i}_icon", function_exists('edlibacherhof_lunch_icon_default') ? edlibacherhof_lunch_icon_default($i) : ''),
        );
    }
    return $groups;
}

/**
 * Le categorie del negozio con almeno un prodotto pubblicato, nell'ordine di WooCommerce:
 * [['nome', 'url', 'da' => prezzo minimo]]. Calcolato una volta e tenuto finché un prodotto non cambia.
 */
function edlibacherhof_menu_categories()
{
    if (!taxonomy_exists('product_cat')) {
        return array();
    }
    $cached = get_transient('edlibacherhof_menu_categories');
    if (is_array($cached)) {
        return $cached;
    }
    global $wpdb;
    $out   = array();
    $terms = get_terms(array('taxonomy' => 'product_cat', 'hide_empty' => true, 'parent' => 0, 'orderby' => 'menu_order', 'exclude' => array((int) get_option('default_product_cat', 0))));
    foreach (is_array($terms) ? $terms : array() as $term) {
        $min = $wpdb->get_var($wpdb->prepare(
            "SELECT MIN(CAST(pm.meta_value AS DECIMAL(10,2))) FROM {$wpdb->postmeta} pm
             JOIN {$wpdb->posts} p ON p.ID = pm.post_id AND p.post_status = 'publish' AND p.post_type = 'product'
             JOIN {$wpdb->term_relationships} tr ON tr.object_id = p.ID
             JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id AND tt.term_id = %d
             WHERE pm.meta_key = '_price' AND pm.meta_value <> ''",
            $term->term_id
        ));
        $out[] = array('id' => $term->term_id, 'slug' => $term->slug, 'nome' => $term->name, 'url' => get_term_link($term), 'da' => $min === null ? null : (float) $min, 'img' => (int) get_term_meta($term->term_id, 'thumbnail_id', true));
    }
    set_transient('edlibacherhof_menu_categories', $out, DAY_IN_SECONDS);
    return $out;
}

/** Prezzo svizzero: «Fr. 16.00». */
function edlibacherhof_price($value)
{
    return sprintf(__('Fr. %s', 'edlibacherhof-child-theme'), number_format((float) $value, 2, '.', "'"));
}

/** Se un prodotto o una categoria cambia, le categorie della home si ricalcolano. */
foreach (array('save_post_product', 'edited_product_cat', 'updated_term_meta', 'added_term_meta', 'created_product_cat', 'delete_product_cat', 'woocommerce_update_product') as $edlibacherhof_hook) {
    add_action($edlibacherhof_hook, function () {
        delete_transient('edlibacherhof_menu_categories');
    });
}

/**
 * Selettore della lingua (tW Translate Plus): «DE · IT», solo se ci sono almeno due lingue pubblicate.
 * Ogni link porta alla stessa pagina nell'altra lingua. $classe distingue testata e pannello del telefono.
 */
function edlibacherhof_language_switcher($classe = '')
{
    if (!function_exists('twtr_get_languages')) {
        return '';
    }
    $langs = twtr_get_languages();
    if (!is_array($langs) || count($langs) < 2) {
        return '';
    }
    $out = '<nav class="ed-lingue' . ($classe ? ' ' . esc_attr($classe) : '') . '" aria-label="' . esc_attr__('Sprache', 'edlibacherhof-child-theme') . '">';
    foreach ($langs as $slug => $lang) {
        $locale = str_replace('_', '-', (string) ($lang['locale'] ?? $slug));
        $label  = (string) ($lang['label'] ?? strtoupper($slug));
        // Bandiera al posto della sigla; il nome della lingua resta per i lettori di schermo e nel title.
        $dentro = edlibacherhof_flag($slug) . '<span class="ed-lingue__nome">' . esc_html($label) . '</span>';
        if (!empty($lang['is_current'])) {
            $out .= '<span class="ed-lingue__attuale" aria-current="true" lang="' . esc_attr($locale) . '" title="' . esc_attr($label) . '">' . $dentro . '</span>';
        } else {
            $out .= '<a href="' . esc_url($lang['url']) . '" hreflang="' . esc_attr($locale) . '" lang="' . esc_attr($locale) . '" title="' . esc_attr($label) . '">' . $dentro . '</a>';
        }
    }
    return $out . '</nav>';
}

/**
 * Bandiera della lingua (SVG in linea, 3:2, decorativa). Tedesco = Germania, italiano = Italia; per una lingua senza
 * bandiera qui torna la sigla.
 */
function edlibacherhof_flag($slug)
{
    $strisce = array(
        'de' => array('h', '#000000', '#dd0000', '#ffce00'),
        'it' => array('v', '#009246', '#ffffff', '#ce2b37'),
        'fr' => array('v', '#002395', '#ffffff', '#ed2939'),
    );
    $slug = strtolower((string) $slug);
    if (!isset($strisce[$slug])) {
        return '<span class="ed-lingue__sigla" aria-hidden="true">' . esc_html(strtoupper($slug)) . '</span>';
    }
    list($verso, $a, $b, $c) = $strisce[$slug];
    $rect = '';
    foreach (array($a, $b, $c) as $i => $colore) {
        $rect .= $verso === 'h'
            ? '<rect x="0" y="' . ($i * 4) . '" width="18" height="4" fill="' . $colore . '"/>'
            : '<rect x="' . ($i * 6) . '" y="0" width="6" height="12" fill="' . $colore . '"/>';
    }
    return '<svg class="ed-bandiera" viewBox="0 0 18 12" width="24" height="16" aria-hidden="true" focusable="false">' . $rect . '</svg>';
}

/** Mappa di Google incorporabile (senza chiave API) centrata sul locale, nella lingua della pagina. '' senza indirizzo. */
function edlibacherhof_map_embed_url()
{
    $lines = edlibacherhof_address_lines();
    if (!$lines) {
        return '';
    }
    $q = get_bloginfo('name') . ', ' . implode(', ', $lines);
    return 'https://maps.google.com/maps?q=' . rawurlencode($q) . '&z=15&hl=' . rawurlencode(substr(determine_locale(), 0, 2)) . '&output=embed';
}

/**
 * Logo in SVG ridisegnato dal JPG del cliente (tools/edlibacherhof/logo): «verde» per la testata chiara, «giallo»
 * per il piè di pagina verde, tutti e due senza sfondo. '' se il file manca: allora resta il logo del CMS.
 */
function edlibacherhof_logo_svg($variante, $alt, $altezza)
{
    $file = '/assets/logo/logo-' . sanitize_key($variante) . '.svg';
    if (!is_readable(EDLIBACHERHOF_DIR . $file)) {
        return '';
    }
    $ver = EDLIBACHERHOF_VERSION . '.' . filemtime(EDLIBACHERHOF_DIR . $file);
    // Proporzioni del disegno: 611 × 134,5 (viewBox stretto sulle lettere).
    $larghezza = (int) round($altezza * 611 / 134.5);
    return '<img class="ed-logo-svg" src="' . esc_url(EDLIBACHERHOF_URI . $file . '?ver=' . $ver) . '" alt="' . esc_attr($alt) . '" width="' . $larghezza . '" height="' . (int) $altezza . '" decoding="async">';
}
