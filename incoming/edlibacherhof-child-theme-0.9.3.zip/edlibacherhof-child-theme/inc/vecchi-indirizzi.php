<?php
/**
 * Vecchi indirizzi del sito Elementor che oggi sono sezioni della home: chi arriva da Google o da un vecchio link
 * finisce direttamente sulla sezione giusta o sulla carta (301), nella sua lingua. Vale solo quando la pagina vecchia
 * non esiste più (404): sul sito vero le pagine Elementor vanno messe in bozza. Le altre pagine sparite le gestisce WordPress.
 *
 * @package edlibacherhof-child-theme
 */

defined('ABSPATH') || exit;

add_action('template_redirect', function () {
    if (!is_404()) {
        return;
    }
    // Indirizzo vecchio (senza barre) => sezione della home («#…») o pagina del negozio («shop»).
    $sezioni = array(
        'edlibacherhof'      => '#restaurant', // «Authentische italienische Küche»
        'kontakt'            => '#kontakt',
        'unser-wochentliches-mittagsangebot-von-dienstag-bis-freitag' => '#mittagsmenue',
        'unsere-speisekarte' => 'shop',
        'schwerts-vorschlage' => 'shop',       // «Vorschläge», pagina rimasta dal vecchio sito Schwert
    );
    $base     = trim((string) wp_parse_url(home_url('/'), PHP_URL_PATH), '/');
    $percorso = trim((string) wp_parse_url((string) ($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH), '/'); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
    if ($base !== '' && strpos($percorso . '/', $base . '/') === 0) {
        $percorso = trim(substr($percorso, strlen($base)), '/');
    }
    if (isset($sezioni[$percorso])) {
        $meta = $sezioni[$percorso];
        $url  = $meta === 'shop' && function_exists('wc_get_page_permalink') ? wc_get_page_permalink('shop') : home_url('/' . $meta);
        wp_safe_redirect($url, 301, 'Edlibacherhof');
        exit;
    }
}, 1);
