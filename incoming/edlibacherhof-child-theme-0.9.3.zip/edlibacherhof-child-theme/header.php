<?php
/**
 * Testata: logo del CMS, voci del menu «primary», bottone «Online bestellen».
 * Sotto i 1024 px le voci si aprono da un bottone (44 px) in un pannello sotto la barra.
 *
 * @package edlibacherhof-child-theme
 */

defined('ABSPATH') || exit;

$ed_name  = get_bloginfo('name');
$ed_logo  = function_exists('ticinoweb_get_site_logo') ? (string) ticinoweb_get_site_logo() : '';
$ed_logo_id = $ed_logo === '' ? 0 : (is_numeric($ed_logo) ? (int) $ed_logo : (int) attachment_url_to_postid($ed_logo));
$ed_order = edlibacherhof_order_url();
$ed_items = array();
$ed_locs  = get_nav_menu_locations();
if (!empty($ed_locs['primary'])) {
    foreach ((array) wp_get_nav_menu_items($ed_locs['primary']) as $ed_item) {
        if ((int) $ed_item->menu_item_parent === 0) {
            $ed_items[] = $ed_item;
        }
    }
}
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="theme-color" content="#f5efe2">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="ed-salta ed-bottone ed-bottone--pieno" href="#inhalt"><?php esc_html_e('Zum Inhalt', 'edlibacherhof-child-theme'); ?></a>
<header class="ed-testata">
    <div class="ed-contenitore ed-testata__in">
        <a class="ed-testata__logo" href="<?php echo esc_url(edlibacherhof_url(home_url('/'), 'url:home')); ?>" rel="home">
            <?php if (($ed_svg = edlibacherhof_logo_svg('verde', $ed_name, 36)) !== '') : ?>
                <?php echo $ed_svg; // phpcs:ignore WordPress.Security.EscapeOutput -- costruito con esc_* ?>
            <?php elseif ($ed_logo_id) : ?>
                <?php echo wp_get_attachment_image($ed_logo_id, 'medium', false, array('alt' => $ed_name, 'loading' => 'eager', 'decoding' => 'async', 'sizes' => '172px')); // phpcs:ignore WordPress.Security.EscapeOutput ?>
            <?php elseif ($ed_logo !== '') : ?>
                <img src="<?php echo esc_url($ed_logo); ?>" alt="<?php echo esc_attr($ed_name); ?>" height="36" decoding="async">
            <?php else : ?>
                <span class="ed-testata__nome"><?php echo esc_html($ed_name); ?></span>
            <?php endif; ?>
        </a>
        <?php if ($ed_items) : ?>
            <nav class="ed-testata__nav" aria-label="<?php esc_attr_e('Hauptmenü', 'edlibacherhof-child-theme'); ?>">
                <?php foreach ($ed_items as $ed_item) : ?>
                    <a href="<?php echo esc_url($ed_item->url); ?>"<?php echo $ed_item->target ? ' target="' . esc_attr($ed_item->target) . '" rel="noopener"' : ''; ?>><?php echo esc_html($ed_item->title); ?></a>
                <?php endforeach; ?>
            </nav>
        <?php endif; ?>
        <?php echo edlibacherhof_language_switcher('ed-lingue--testata'); // phpcs:ignore WordPress.Security.EscapeOutput -- escape nella funzione ?>
        <?php echo function_exists('edlibacherhof_cart_link') ? edlibacherhof_cart_link() : ''; // phpcs:ignore WordPress.Security.EscapeOutput -- escape nella funzione ?>
        <?php if ($ed_order !== '') : ?>
            <a class="ed-bottone ed-bottone--pieno ed-testata__azione" href="<?php echo esc_url($ed_order); ?>"><?php esc_html_e('Online bestellen', 'edlibacherhof-child-theme'); ?></a>
        <?php endif; ?>
        <?php if ($ed_items) : ?>
            <button class="ed-testata__menu" type="button" aria-expanded="false" aria-controls="ed-menu-mobil" aria-label="<?php esc_attr_e('Menü öffnen', 'edlibacherhof-child-theme'); ?>"><svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true" focusable="false"><path d="M3 6h14M3 10h14M3 14h14"/></svg></button>
        <?php endif; ?>
    </div>
    <?php if ($ed_items) : ?>
        <div class="ed-testata__pannello" id="ed-menu-mobil">
            <nav class="ed-contenitore" aria-label="<?php esc_attr_e('Hauptmenü mobil', 'edlibacherhof-child-theme'); ?>">
                <?php foreach ($ed_items as $ed_item) : ?>
                    <a href="<?php echo esc_url($ed_item->url); ?>"><?php echo esc_html($ed_item->title); ?></a>
                <?php endforeach; ?>
                <?php if ($ed_order !== '') : ?>
                    <a class="ed-bottone ed-bottone--pieno" href="<?php echo esc_url($ed_order); ?>"><?php esc_html_e('Online bestellen', 'edlibacherhof-child-theme'); ?></a>
                <?php endif; ?>
                <?php echo edlibacherhof_language_switcher('ed-lingue--pannello'); // phpcs:ignore WordPress.Security.EscapeOutput -- escape nella funzione ?>
            </nav>
        </div>
    <?php endif; ?>
</header>
