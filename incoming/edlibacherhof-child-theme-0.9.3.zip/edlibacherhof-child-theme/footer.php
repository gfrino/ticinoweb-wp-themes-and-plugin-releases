<?php
/**
 * Piè di pagina nel verde dell'insegna, su tre colonne della griglia: logo con «Online bestellen», contatti, orari
 * (giorni uguali raggruppati: «Dienstag – Samstag»). Sotto, una riga sola: copyright, menu «Rechtliches» (posizione
 * ed-legal), cookie, conto cliente, area riservata, crediti. Tutti i dati dal CMS.
 *
 * @package edlibacherhof-child-theme
 */

defined('ABSPATH') || exit;

$ed_contacts = edlibacherhof_contacts();
$ed_name     = get_bloginfo('name');
$ed_logo     = function_exists('ticinoweb_get_site_logo') ? (string) ticinoweb_get_site_logo() : '';
$ed_logo_id  = $ed_logo === '' ? 0 : (is_numeric($ed_logo) ? (int) $ed_logo : (int) attachment_url_to_postid($ed_logo));
$ed_lines    = edlibacherhof_address_lines();
$ed_account  = function_exists('wc_get_page_permalink') ? (string) wc_get_page_permalink('myaccount') : '';
$ed_shop     = function_exists('wc_get_page_permalink') ? (string) wc_get_page_permalink('shop') : '';
$ed_wa       = edlibacherhof_whatsapp_url();
$ed_tagline  = trim((string) get_bloginfo('description'));
// Orari: i giorni consecutivi con lo stesso orario diventano una riga sola.
$ed_gruppi = array();
foreach (edlibacherhof_hours() as $ed_row) {
    $ed_ultimo = count($ed_gruppi) - 1;
    if ($ed_ultimo >= 0 && $ed_gruppi[$ed_ultimo]['testo'] === $ed_row['testo']) {
        $ed_gruppi[$ed_ultimo]['a'] = $ed_row['giorno'];
    } else {
        $ed_gruppi[] = array('da' => $ed_row['giorno'], 'a' => '', 'testo' => $ed_row['testo']);
    }
}
?>
<footer class="ed-piede">
    <div class="ed-contenitore">
        <div class="ed-piede__in">
            <div class="ed-piede__marca">
                <a class="ed-piede__logo" href="<?php echo esc_url(home_url('/')); ?>">
                    <?php if (($ed_svg = edlibacherhof_logo_svg('giallo', $ed_name, 52)) !== '') : ?>
                        <?php echo $ed_svg; // phpcs:ignore WordPress.Security.EscapeOutput -- costruito con esc_* ?>
                    <?php elseif ($ed_logo_id) : ?>
                        <?php echo wp_get_attachment_image($ed_logo_id, 'medium', false, array('alt' => $ed_name, 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '240px')); // phpcs:ignore WordPress.Security.EscapeOutput ?>
                    <?php else : ?>
                        <span><?php echo esc_html($ed_name); ?></span>
                    <?php endif; ?>
                </a>
                <?php if ($ed_tagline !== '') : ?><p class="ed-piede__frase"><?php echo esc_html(edlibacherhof_t($ed_tagline, 'site:tagline')); ?></p><?php endif; ?>
                <?php if ($ed_shop !== '') : ?><a class="ed-bottone ed-piede__ordina" href="<?php echo esc_url($ed_shop); ?>"><span><?php esc_html_e('Online bestellen', 'edlibacherhof-child-theme'); ?></span><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a><?php endif; ?>
            </div>
            <div class="ed-piede__blocco">
                <h2 class="ed-piede__titolo"><?php esc_html_e('Kontakt', 'edlibacherhof-child-theme'); ?></h2>
                <address class="ed-recapiti">
                    <span class="ed-recapito"><?php echo edlibacherhof_icona('pin'); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php echo esc_html($ed_name); ?><?php foreach ($ed_lines as $ed_line) : ?><br><?php echo esc_html($ed_line); ?><?php endforeach; ?></span></span>
                    <?php if ($ed_contacts['phone'] !== '') : ?><a class="ed-recapito" href="<?php echo esc_attr('tel:' . preg_replace('/[^\d+]/', '', $ed_contacts['phone'])); ?>"><?php echo edlibacherhof_icona('telefono'); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php echo esc_html(edlibacherhof_phone_display($ed_contacts['phone'])); ?></span></a><?php endif; ?>
                    <?php if ($ed_wa !== '') : ?><a class="ed-recapito" href="<?php echo esc_url($ed_wa); ?>" rel="noopener"><?php echo edlibacherhof_icona('whatsapp'); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php echo esc_html($ed_contacts['mobile'] !== '' ? sprintf(__('WhatsApp: %s', 'edlibacherhof-child-theme'), edlibacherhof_phone_display($ed_contacts['mobile'])) : 'WhatsApp'); ?></span></a><?php endif; ?>
                    <?php if ($ed_contacts['email'] !== '') : ?><a class="ed-recapito" href="<?php echo esc_attr('mailto:' . $ed_contacts['email']); ?>"><?php echo edlibacherhof_icona('email'); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php echo esc_html($ed_contacts['email']); ?></span></a><?php endif; ?>
                </address>
            </div>
            <?php if ($ed_gruppi) : ?>
                <div class="ed-piede__blocco">
                    <h2 class="ed-piede__titolo"><?php esc_html_e('Öffnungszeiten', 'edlibacherhof-child-theme'); ?></h2>
                    <dl class="ed-piede__orari">
                        <?php foreach ($ed_gruppi as $ed_g) : ?>
                            <div><dt><span><?php echo esc_html($ed_g['da']); ?></span><?php if ($ed_g['a'] !== '') : ?> – <span><?php echo esc_html($ed_g['a']); ?></span><?php endif; ?></dt><dd><?php echo esc_html($ed_g['testo']); ?></dd></div>
                        <?php endforeach; ?>
                    </dl>
                </div>
            <?php endif; ?>
        </div>
        <div class="ed-piede__fine">
            <span class="ed-piede__copy">&copy; <?php echo esc_html(wp_date('Y')); ?> <?php echo esc_html($ed_name); ?></span>
            <nav class="ed-piede__legale" aria-label="<?php esc_attr_e('Rechtliches', 'edlibacherhof-child-theme'); ?>">
                <?php
                $ed_locs = get_nav_menu_locations();
                if (!empty($ed_locs['ed-legal'])) {
                    foreach ((array) wp_get_nav_menu_items($ed_locs['ed-legal']) as $ed_item) {
                        echo '<a href="' . esc_url($ed_item->url) . '">' . esc_html($ed_item->title) . '</a>';
                    }
                } elseif (edlibacherhof_privacy_url() !== '') {
                    echo '<a href="' . esc_url(edlibacherhof_url(edlibacherhof_privacy_url(), 'url:privacy')) . '">' . esc_html__('Datenschutz', 'edlibacherhof-child-theme') . '</a>';
                }
                ?>
                <?php if (get_option('tw_cookie_banner_enable')) : ?><button type="button" class="ed-piede__cookie" data-ed-cookies><?php esc_html_e('Cookie-Einstellungen', 'edlibacherhof-child-theme'); ?></button><?php endif; ?>
                <?php if ($ed_account !== '') : ?><a href="<?php echo esc_url($ed_account); ?>"><?php esc_html_e('Mein Konto', 'edlibacherhof-child-theme'); ?></a><?php endif; ?>
                <?php // Accesso per chi gestisce il sito (ordini, carta, orari): la pagina di login, poi la Bacheca. ?>
                <a href="<?php echo esc_url(wp_login_url(admin_url())); ?>" rel="nofollow"><?php esc_html_e('Interner Bereich', 'edlibacherhof-child-theme'); ?></a>
            </nav>
            <a class="ed-piede__crediti" href="https://ticinoweb.com" rel="noopener"><?php esc_html_e('Website: ticinoWEB', 'edlibacherhof-child-theme'); ?></a>
        </div>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
