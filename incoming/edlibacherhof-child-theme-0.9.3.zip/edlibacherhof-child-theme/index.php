<?php
/**
 * Ripiego per ogni vista senza un template proprio (articoli, archivi, ricerca, 404).
 *
 * @package edlibacherhof-child-theme
 */

defined('ABSPATH') || exit;

get_header();
?>
<main id="inhalt" class="ed-pagina">
    <div class="ed-contenitore">
        <div class="ed-pagina__corpo">
            <?php if (have_posts() && !is_404()) : ?>
                <?php while (have_posts()) : the_post(); ?>
                    <article>
                        <h1><?php the_title(); ?></h1>
                        <div class="ed-prosa"><?php the_content(); ?></div>
                    </article>
                <?php endwhile; ?>
            <?php else : ?>
                <h1><?php esc_html_e('Seite nicht gefunden', 'edlibacherhof-child-theme'); ?></h1>
                <div class="ed-prosa">
                    <p><?php esc_html_e('Unter dieser Adresse gibt es keine Seite. Vielleicht hat sie sich geändert.', 'edlibacherhof-child-theme'); ?></p>
                    <p><a class="ed-link" href="<?php echo esc_url(edlibacherhof_url(home_url('/'), 'url:home')); ?>"><?php esc_html_e('Zur Startseite', 'edlibacherhof-child-theme'); ?></a></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</main>
<?php
get_footer();
