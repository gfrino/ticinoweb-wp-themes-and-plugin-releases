<?php
/**
 * Bacheca di «Mein Konto»: saluto con il nome, tre scorciatoie (ordini, indirizzi, dati e password) e il bottone per
 * ordinare. Sostituisce il paragrafo standard di WooCommerce con i link nel testo. Gli hook di WooCommerce restano.
 *
 * @package edlibacherhof-child-theme
 * @version 4.4.0
 */

defined('ABSPATH') || exit;

$ed_utente = wp_get_current_user();
$ed_nome   = trim((string) $ed_utente->first_name) !== '' ? $ed_utente->first_name : $ed_utente->display_name;
$ed_vie    = array(
    array('orders', __('Bestellungen', 'edlibacherhof-child-theme'), __('Ihre Bestellungen und deren Status', 'edlibacherhof-child-theme')),
    array('edit-address', __('Adressen', 'edlibacherhof-child-theme'), __('Rechnungs- und Lieferadresse', 'edlibacherhof-child-theme')),
    array('edit-account', __('Konto und Passwort', 'edlibacherhof-child-theme'), __('Name, E-Mail und Passwort ändern', 'edlibacherhof-child-theme')),
);
$ed_voci = wc_get_account_menu_items();
$ed_shop = (string) wc_get_page_permalink('shop');
?>
<div class="ed-conto">
    <?php // Il nome resta fuori dalla traduzione (tW Translate salta translate="no"): si traduce solo «Hallo». ?>
    <p class="ed-conto__saluto"><span><?php esc_html_e('Hallo', 'edlibacherhof-child-theme'); ?></span> <span class="notranslate" translate="no"><?php echo esc_html($ed_nome); ?></span></p>
    <ul class="ed-conto__vie">
        <?php foreach ($ed_vie as $ed_via) : ?>
            <?php if (!isset($ed_voci[$ed_via[0]])) { continue; } ?>
            <li>
                <a href="<?php echo esc_url(wc_get_account_endpoint_url($ed_via[0])); ?>">
                    <span class="ed-conto__nome"><?php echo esc_html($ed_via[1]); ?></span>
                    <span class="ed-conto__descr"><?php echo esc_html($ed_via[2]); ?></span>
                    <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>
    <?php if ($ed_shop !== '') : ?>
        <p><a class="ed-bottone ed-bottone--pieno" href="<?php echo esc_url($ed_shop); ?>"><?php esc_html_e('Online bestellen', 'edlibacherhof-child-theme'); ?></a></p>
    <?php endif; ?>
</div>
<?php
do_action('woocommerce_account_dashboard');
do_action('woocommerce_before_my_account'); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- hook storico
do_action('woocommerce_after_my_account'); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- hook storico
