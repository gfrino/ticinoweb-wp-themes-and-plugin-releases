<?php
/**
 * Pagina di testo (Datenschutz, AGB, Impressum, Warenkorb, Kasse, Mein Konto): titolo e contenuto.
 *
 * @package edlibacherhof-child-theme
 */

defined('ABSPATH') || exit;

get_header();
?>
<main id="inhalt" class="ed-pagina">
    <div class="ed-contenitore">
        <?php while (have_posts()) : the_post(); ?>
            <article class="ed-pagina__corpo">
                <h1><?php the_title(); ?></h1>
                <div class="ed-prosa"><?php the_content(); ?></div>
            </article>
        <?php endwhile; ?>
    </div>
</main>
<?php
get_footer();
