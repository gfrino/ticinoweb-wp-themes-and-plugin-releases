<?php
/**
 * Pagina iniziale (direzione A «Gasthof», prototipo in Kyle AI Dev/tools/edlibacherhof/prototipo-carattere).
 * Ogni testo e foto viene dal Personalizza (inc/settings.php), dal CMS del parent o dal negozio WooCommerce;
 * un blocco senza dati non compare.
 *
 * @package edlibacherhof-child-theme
 */

defined('ABSPATH') || exit;

get_header();

$ed_contacts = edlibacherhof_contacts();
$ed_wa       = edlibacherhof_whatsapp_url();
$ed_wa_label = $ed_contacts['mobile'] !== '' ? sprintf(__('WhatsApp: %s', 'edlibacherhof-child-theme'), edlibacherhof_phone_display($ed_contacts['mobile'])) : '';
$ed_order    = edlibacherhof_order_url();

$ed_title = edlibacherhof_text('hero_title');
$ed_title = $ed_title !== '' ? $ed_title : get_bloginfo('name');
?>
<main id="inhalt">
    <section class="ed-hero">
        <div class="ed-contenitore ed-griglia">
            <div class="ed-hero__testo" style="--t:5; --d:6">
                <h1><?php echo edlibacherhof_title_html($ed_title); // phpcs:ignore WordPress.Security.EscapeOutput -- escape nella funzione ?></h1>
                <?php if (($ed_text = edlibacherhof_text('hero_text')) !== '') : ?>
                    <p class="ed-lead"><?php echo esc_html($ed_text); ?></p>
                <?php endif; ?>
                <div class="ed-azioni ed-hero__azioni">
                    <?php if ($ed_order !== '') : ?><a class="ed-bottone ed-bottone--pieno" href="<?php echo esc_url($ed_order); ?>"><?php esc_html_e('Online bestellen', 'edlibacherhof-child-theme'); ?></a><?php endif; ?>
                    <a class="ed-vai" href="#speisekarte"><span><?php esc_html_e('Speisekarte ansehen', 'edlibacherhof-child-theme'); ?></span><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
                </div>
                <?php
                // Targa dal vivo, come il cartello sulla porta: «Jetzt geöffnet – bis 22.00 Uhr», «Schliesst bald»,
                // «Jetzt geschlossen – öffnet um 17.00 Uhr». Gli orari (dal CMS) e le frasi (traducibili) sono nell'HTML,
                // così la cache della pagina non sbaglia; l'ora la calcola site.js nel browser, ogni minuto.
                // Senza script resta la nota del Personalizza.
                $ed_orari = array();
                $ed_raw   = (array) get_option('ticinoweb_contact_opening_hours', array());
                foreach (array('monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday') as $ed_key) {
                    $ed_d = isset($ed_raw[$ed_key]) && is_array($ed_raw[$ed_key]) ? $ed_raw[$ed_key] : array('closed' => 1);
                    $ed_fasce = array();
                    if (!empty($ed_d['open_24h'])) {
                        $ed_fasce[] = array('00:00', '24:00');
                    } elseif (empty($ed_d['closed'])) {
                        foreach ((array) ($ed_d['slots'] ?? array()) as $ed_slot) {
                            if (!empty($ed_slot['open']) && !empty($ed_slot['close'])) {
                                $ed_fasce[] = array((string) $ed_slot['open'], (string) $ed_slot['close']);
                            }
                        }
                    }
                    $ed_orari[] = $ed_fasce;
                }
                $ed_giorni = wp_list_pluck(edlibacherhof_hours(), 'giorno');
                ?>
                <div class="ed-hero__dati">
                    <?php if (($ed_note = edlibacherhof_text('hero_note')) !== '') : ?><p class="ed-hero__nota" data-ed-senza-targa><?php echo esc_html($ed_note); ?></p><?php endif; ?>
                    <?php if (array_filter($ed_orari)) : ?>
                        <p class="ed-targa" data-ed-targa data-orari="<?php echo esc_attr(wp_json_encode($ed_orari)); ?>" hidden aria-live="polite">
                            <span class="ed-targa__titolo"></span>
                            <span class="ed-targa__ore"></span>
                        </p>
                        <span class="ed-targa__frasi" hidden>
                            <span data-f="aperto"><?php esc_html_e('Jetzt geöffnet', 'edlibacherhof-child-theme'); ?></span>
                            <span data-f="presto"><?php esc_html_e('Schliesst bald', 'edlibacherhof-child-theme'); ?></span>
                            <span data-f="chiuso"><?php esc_html_e('Jetzt geschlossen', 'edlibacherhof-child-theme'); ?></span>
                            <span data-f="riposo"><?php esc_html_e('Heute Ruhetag', 'edlibacherhof-child-theme'); ?></span>
                            <span data-f="fino"><?php esc_html_e('bis {ora} Uhr', 'edlibacherhof-child-theme'); ?></span>
                            <span data-f="chiude"><?php esc_html_e('schliesst um {ora} Uhr', 'edlibacherhof-child-theme'); ?></span>
                            <span data-f="oggi"><?php esc_html_e('öffnet um {ora} Uhr', 'edlibacherhof-child-theme'); ?></span>
                            <span data-f="domani"><?php esc_html_e('öffnet morgen um {ora} Uhr', 'edlibacherhof-child-theme'); ?></span>
                            <span data-f="giorno"><?php esc_html_e('öffnet am {giorno} um {ora} Uhr', 'edlibacherhof-child-theme'); ?></span>
                            <?php foreach ($ed_giorni as $ed_i => $ed_g) : ?><span data-g="<?php echo (int) $ed_i; ?>"><?php echo esc_html($ed_g); ?></span><?php endforeach; ?>
                        </span>
                    <?php endif; ?>
                    <?php if ($ed_wa !== '') : ?><p class="ed-hero__chiedi"><?php esc_html_e('Fragen?', 'edlibacherhof-child-theme'); ?> <a class="ed-recapito" href="<?php echo esc_url($ed_wa); ?>"><?php echo edlibacherhof_icona('whatsapp'); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php echo esc_html($ed_wa_label); ?></span></a></p><?php endif; ?>
                </div>
            </div>
            <?php
            // Foto accanto al titolo: la foto del Personalizza, poi quelle della galleria scelta, che si alternano
            // (site.js, ogni 5 secondi; ferme con «riduci movimento»). La prima si carica subito, le altre dopo.
            $ed_hero_ids = array_values(array_unique(array_filter(array_merge(
                array((int) edlibacherhof_setting('hero_image', 0)),
                edlibacherhof_gallery_images((string) edlibacherhof_setting('hero_gallery_slug', ''), 8)
            ))));
            $ed_hero_sizes = '(min-width: 1024px) 600px, (min-width: 600px) 38vw, 100vw';
            ?>
            <?php if ($ed_hero_ids) : ?>
                <figure class="ed-foto ed-hero__foto<?php echo count($ed_hero_ids) > 1 ? ' ed-hero__foto--scorre' : ''; ?>" style="--t:3; --d:6; --d-start:7; --ar:1/1; --fuoco:50% 45%"<?php echo count($ed_hero_ids) > 1 ? ' data-ed-scorre' : ''; ?>>
                    <?php foreach ($ed_hero_ids as $ed_k => $ed_hid) : ?>
                        <?php echo edlibacherhof_image($ed_hid, 'large', $ed_k === 0
                            ? array('loading' => 'eager', 'fetchpriority' => 'high', 'sizes' => $ed_hero_sizes, 'class' => 'attachment-large size-large ed-attiva')
                            : array('loading' => 'lazy', 'sizes' => $ed_hero_sizes)); // phpcs:ignore WordPress.Security.EscapeOutput ?>
                    <?php endforeach; ?>
                </figure>
            <?php endif; ?>
        </div>
        <?php if (($ed_strip = edlibacherhof_image(edlibacherhof_setting('strip_image', 0), 'full', array('sizes' => '(min-width: 1340px) 1240px, 92vw'))) !== '') : ?>
            <div class="ed-contenitore">
                <figure class="ed-strada">
                    <div class="ed-foto"><?php echo $ed_strip; // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
                    <?php if (($ed_cap = edlibacherhof_text('strip_caption')) !== '') : ?><figcaption><?php echo esc_html($ed_cap); ?></figcaption><?php endif; ?>
                </figure>
            </div>
        <?php endif; ?>
    </section>

    <?php $ed_lunch = edlibacherhof_lunch_groups(); ?>
    <?php if ($ed_lunch) : ?>
        <section class="ed-sezione ed-sezione--alt" id="mittagsmenue">
            <div class="ed-contenitore">
                <article class="ed-foglio">
                    <header class="ed-foglio__testa">
                        <h2 class="ed-foglio__titolo"><?php echo edlibacherhof_icona('posate'); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php echo esc_html(edlibacherhof_text('lunch_title') ?: __('Mittagsmenü', 'edlibacherhof-child-theme')); ?></span></h2>
                        <?php if (($ed_days = edlibacherhof_text('lunch_days')) !== '') : ?><p class="ed-foglio__giorni"><?php echo esc_html($ed_days); ?></p><?php endif; ?>
                        <?php if (($ed_ltext = edlibacherhof_text('lunch_text')) !== '') : ?><p><?php echo esc_html($ed_ltext); ?></p><?php endif; ?>
                    </header>
                    <?php
                    $ed_first = array_shift($ed_lunch);
                    $ed_group = function ($group, $class = '') {
                        ?>
                        <div class="ed-menu<?php echo $class ? ' ' . esc_attr($class) : ''; ?>">
                            <h3 class="ed-menu__titolo"><?php if ($group['icona'] !== '') : ?><?php echo edlibacherhof_icona($group['icona']); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php endif; ?><span><?php echo esc_html($group['nome']); ?></span>
                                <?php if ($group['prezzo'] !== '') : ?><span class="ed-menu__prezzo"><?php echo esc_html($group['prezzo']); ?><?php if ($group['nota_prezzo'] !== '') : ?> <small><?php echo esc_html($group['nota_prezzo']); ?></small><?php endif; ?></span><?php endif; ?>
                            </h3>
                            <?php if ($group['piatti']) : ?>
                                <ul role="list">
                                    <?php foreach ($group['piatti'] as $dish) : ?>
                                        <li><b><?php echo esc_html($dish['nome']); ?></b><?php if ($dish['descrizione'] !== '') : ?><span><?php echo esc_html($dish['descrizione']); ?></span><?php endif; ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                            <?php if ($group['nota'] !== '') : ?><p class="ed-menu__nota"><?php echo esc_html($group['nota']); ?></p><?php endif; ?>
                        </div>
                        <?php
                    };
                    $ed_group($ed_first, 'ed-menu--pizza');
                    if ($ed_lunch) {
                        echo '<div class="ed-foglio__coppia">';
                        foreach ($ed_lunch as $ed_g) {
                            $ed_group($ed_g);
                        }
                        echo '</div>';
                    }
                    ?>
                </article>
            </div>
        </section>
    <?php endif; ?>

    <?php
    $ed_cats     = edlibacherhof_menu_categories();
    $ed_finestre = array_values(array_filter($ed_cats, function ($c) { return $c['img'] && wp_attachment_is_image($c['img']); }));
    $ed_altre    = array_values(array_filter($ed_cats, function ($c) { return !($c['img'] && wp_attachment_is_image($c['img'])); }));
    $ed_shop     = function_exists('wc_get_page_permalink') ? (string) wc_get_page_permalink('shop') : '';
    $ed_cat_url  = function ($c) use ($ed_shop) {
        return $ed_shop !== '' ? edlibacherhof_url($ed_shop, 'url:shop') . '#kat-' . $c['slug'] : (is_string($c['url']) ? $c['url'] : '');
    };
    ?>
    <?php if ($ed_cats) : ?>
        <section class="ed-sezione ed-sezione-carta" id="speisekarte">
            <div class="ed-contenitore">
                <div class="ed-carta-testa">
                    <div class="ed-sezione__testa">
                        <h2><?php echo esc_html(edlibacherhof_text('menu_title') ?: __('Speisekarte', 'edlibacherhof-child-theme')); ?></h2>
                        <?php if (($ed_mtext = edlibacherhof_text('menu_text')) !== '') : ?><p><?php echo esc_html($ed_mtext); ?></p><?php endif; ?>
                    </div>
                    <?php if ($ed_order !== '') : ?>
                        <a class="ed-bottone ed-bottone--pieno ed-carta-testa__azione" href="<?php echo esc_url($ed_order); ?>"><?php esc_html_e('Online bestellen', 'edlibacherhof-child-theme'); ?></a>
                    <?php endif; ?>
                </div>
                <?php if ($ed_finestre) : ?>
                    <ul class="ed-finestre" role="list">
                        <?php foreach ($ed_finestre as $ed_i => $ed_cat) : ?>
                            <li class="ed-finestra<?php echo $ed_i === 0 ? ' ed-finestra--grande' : ''; ?>">
                                <a href="<?php echo esc_url($ed_cat_url($ed_cat)); ?>">
                                    <?php echo wp_get_attachment_image($ed_cat['img'], $ed_i === 0 ? 'large' : 'medium_large', false, array('alt' => '', 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => $ed_i === 0 ? '(min-width: 1024px) 620px, 100vw' : '(min-width: 1024px) 310px, 50vw')); // phpcs:ignore WordPress.Security.EscapeOutput ?>
                                    <span class="ed-finestra__targa">
                                        <span class="ed-finestra__nome"><?php echo esc_html(edlibacherhof_t($ed_cat['nome'], 'cat:' . $ed_cat['id'])); ?></span>
                                    </span>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
                <?php if ($ed_altre) : ?>
                    <p class="ed-carta-altre">
                        <span class="ed-carta-altre__titolo"><?php echo esc_html($ed_finestre ? __('Ausserdem', 'edlibacherhof-child-theme') : __('Auf der Karte', 'edlibacherhof-child-theme')); ?></span>
                        <?php foreach ($ed_altre as $ed_cat) : ?>
                            <a href="<?php echo esc_url($ed_cat_url($ed_cat)); ?>"><?php echo esc_html(edlibacherhof_t($ed_cat['nome'], 'cat:' . $ed_cat['id'])); ?></a>
                        <?php endforeach; ?>
                    </p>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>

    <?php
    $ed_rows = array_filter(array(
        __('Abholen', 'edlibacherhof-child-theme')   => edlibacherhof_text('order_pickup'),
        __('Bezahlen', 'edlibacherhof-child-theme')  => edlibacherhof_text('order_payment'),
    ));
    ?>
    <?php if ($ed_order !== '' && ($ed_rows || $ed_wa !== '')) : ?>
        <section class="ed-sezione ed-ordine" id="bestellen">
            <div class="ed-contenitore ed-griglia">
                <div class="ed-ordine__testo" style="--t:8; --d:5">
                    <h2><?php echo esc_html(edlibacherhof_text('order_title') ?: __('So bestellen Sie', 'edlibacherhof-child-theme')); ?></h2>
                    <?php if (($ed_otext = edlibacherhof_text('order_text')) !== '') : ?><p class="ed-lead"><?php echo esc_html($ed_otext); ?></p><?php endif; ?>
                    <div class="ed-azioni"><a class="ed-bottone ed-bottone--pieno" href="<?php echo esc_url($ed_order); ?>"><?php esc_html_e('Jetzt bestellen', 'edlibacherhof-child-theme'); ?></a></div>
                </div>
                <dl class="ed-ordine__righe" style="--t:8; --d:6; --d-start:7">
                    <?php foreach ($ed_rows as $ed_label => $ed_value) : ?>
                        <div><dt><?php echo esc_html($ed_label); ?></dt><dd><?php echo esc_html($ed_value); ?></dd></div>
                    <?php endforeach; ?>
                    <?php if ($ed_wa !== '') : ?>
                        <div><dt><?php esc_html_e('Fragen zur Bestellung', 'edlibacherhof-child-theme'); ?></dt><dd><?php esc_html_e('Schreiben Sie uns auf', 'edlibacherhof-child-theme'); ?> <a class="ed-link" href="<?php echo esc_url($ed_wa); ?>"><?php echo esc_html($ed_wa_label); ?></a>.</dd></div>
                    <?php endif; ?>
                </dl>
            </div>
        </section>
    <?php endif; ?>

    <?php $ed_gallery = edlibacherhof_gallery_images((string) edlibacherhof_setting('gallery_slug', ''), 24); ?>
    <?php if ($ed_gallery) : ?>
        <section class="ed-sezione ed-sezione--alt ed-galleria" id="galerie">
            <div class="ed-contenitore">
                <div class="ed-sezione__testa">
                    <h2><?php echo esc_html(edlibacherhof_text('gallery_title') ?: __('Galerie', 'edlibacherhof-child-theme')); ?></h2>
                    <?php if (($ed_gtext = edlibacherhof_text('gallery_text')) !== '') : ?><p><?php echo esc_html($ed_gtext); ?></p><?php endif; ?>
                </div>
                <ul class="ed-galleria__foto" role="list">
                    <?php foreach ($ed_gallery as $ed_gid) : ?>
                        <?php
                        $ed_full = wp_get_attachment_image_src($ed_gid, 'full');
                        $ed_raw  = trim((string) get_post_meta($ed_gid, '_wp_attachment_image_alt', true));   // originale: l'etichetta del bottone si traduce intera
                        $ed_alt  = $ed_raw !== '' ? edlibacherhof_t($ed_raw, 'alt:' . $ed_gid) : '';
                        ?>
                        <li>
                            <button class="ed-galleria__apri" type="button" data-ed-grande="<?php echo esc_url($ed_full ? $ed_full[0] : ''); ?>" data-ed-didascalia="<?php echo esc_attr($ed_alt); ?>" aria-label="<?php echo esc_attr($ed_raw !== '' ? sprintf(__('Foto vergrössern: %s', 'edlibacherhof-child-theme'), $ed_raw) : __('Foto vergrössern', 'edlibacherhof-child-theme')); ?>">
                                <?php echo edlibacherhof_image($ed_gid, 'medium_large', array('sizes' => '(min-width: 1024px) 300px, (min-width: 600px) 33vw, 50vw')); // phpcs:ignore WordPress.Security.EscapeOutput ?>
                            </button>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <dialog class="ed-visore" aria-label="<?php esc_attr_e('Galerie', 'edlibacherhof-child-theme'); ?>">
                <figure><img src="" alt=""><figcaption></figcaption></figure>
                <button type="button" class="ed-visore__btn ed-visore__chiudi" aria-label="<?php esc_attr_e('Schliessen', 'edlibacherhof-child-theme'); ?>"><svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="M5 5l10 10M15 5L5 15"/></svg></button>
                <button type="button" class="ed-visore__btn ed-visore__prec" aria-label="<?php esc_attr_e('Vorheriges Foto', 'edlibacherhof-child-theme'); ?>"><svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="M12.5 4.5L7 10l5.5 5.5"/></svg></button>
                <button type="button" class="ed-visore__btn ed-visore__succ" aria-label="<?php esc_attr_e('Nächstes Foto', 'edlibacherhof-child-theme'); ?>"><svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="M7.5 4.5L13 10l-5.5 5.5"/></svg></button>
            </dialog>
        </section>
    <?php endif; ?>

    <?php
    $ed_about_title = trim((string) get_option('ticinoweb_chi_siamo_title', ''));
    $ed_about_text  = trim((string) get_option('ticinoweb_chi_siamo_text', ''));
    $ed_rimg        = edlibacherhof_image(edlibacherhof_setting('restaurant_image', 0), 'large', array('sizes' => '(min-width: 1024px) 500px, 38vw'));
    $ed_rmap        = edlibacherhof_image(edlibacherhof_setting('restaurant_map', 0), 'full', array('sizes' => '(min-width: 600px) 480px, 92vw'));
    ?>
    <?php if ($ed_about_title !== '' || $ed_about_text !== '') : ?>
        <section class="ed-sezione ed-locale" id="restaurant">
            <div class="ed-contenitore ed-griglia">
                <div class="ed-locale__testo" style="<?php echo $ed_rimg ? '--t:5; --d:6' : '--t:8; --d:8'; ?>">
                    <?php if ($ed_about_title !== '') : ?><h2><?php echo esc_html(edlibacherhof_t($ed_about_title, 'about:title')); ?></h2><?php endif; ?>
                    <?php foreach (array_filter(array_map('trim', preg_split('/\n\s*\n/', $ed_about_text))) as $ed_i => $ed_par) : ?>
                        <p<?php echo $ed_i === 0 ? ' class="ed-lead"' : ''; ?>><?php echo nl2br(esc_html(edlibacherhof_t($ed_par, 'about:text:' . $ed_i))); ?></p>
                    <?php endforeach; ?>
                    <?php if (($ed_sig = edlibacherhof_text('restaurant_signature')) !== '') : ?><p class="ed-locale__firma"><?php echo esc_html($ed_sig); ?></p><?php endif; ?>
                    <?php if ($ed_rmap !== '') : ?>
                        <?php $ed_meta = wp_get_attachment_metadata((int) edlibacherhof_setting('restaurant_map', 0)); ?>
                        <figure class="ed-locale__foto ed-locale__cartina">
                            <div class="ed-foto" style="--ar:<?php echo (int) ($ed_meta['width'] ?? 3); ?>/<?php echo (int) ($ed_meta['height'] ?? 2); ?>"><?php echo $ed_rmap; // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
                            <?php if (($ed_mcap = edlibacherhof_text('restaurant_map_caption')) !== '') : ?><figcaption class="ed-didascalia"><?php echo esc_html($ed_mcap); ?></figcaption><?php endif; ?>
                        </figure>
                    <?php endif; ?>
                </div>
                <?php if ($ed_rimg !== '') : ?>
                    <figure class="ed-locale__foto ed-locale__foto--alta" style="--t:3; --d:5; --d-start:8">
                        <div class="ed-foto" style="--ar:4/5"><?php echo $ed_rimg; // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
                    </figure>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>

    <?php
    $ed_lines = edlibacherhof_address_lines();
    $ed_hours = edlibacherhof_hours();
    $ed_route = edlibacherhof_map_url();
    ?>
    <section class="ed-sezione ed-sezione--alt ed-contatti-sezione" id="kontakt">
        <div class="ed-contenitore ed-griglia">
            <div class="ed-contatti" style="--t:4; --d:5">
                <h2><?php esc_html_e('Kontakt', 'edlibacherhof-child-theme'); ?></h2>
                <address class="ed-recapiti">
                    <span class="ed-recapito"><?php echo edlibacherhof_icona('pin'); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php echo esc_html(get_bloginfo('name')); ?><?php foreach ($ed_lines as $ed_line) : ?><br><?php echo esc_html($ed_line); ?><?php endforeach; ?></span></span>
                    <?php if ($ed_contacts['phone'] !== '') : ?><a class="ed-recapito" href="<?php echo esc_attr('tel:' . preg_replace('/[^\d+]/', '', $ed_contacts['phone'])); ?>"><?php echo edlibacherhof_icona('telefono'); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php echo esc_html(sprintf(__('Telefon %s', 'edlibacherhof-child-theme'), edlibacherhof_phone_display($ed_contacts['phone']))); ?></span></a><?php endif; ?>
                    <?php if ($ed_wa !== '') : ?><a class="ed-recapito" href="<?php echo esc_url($ed_wa); ?>"><?php echo edlibacherhof_icona('whatsapp'); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php echo esc_html($ed_wa_label); ?></span></a><?php endif; ?>
                    <?php if ($ed_contacts['email'] !== '') : ?><a class="ed-recapito" href="<?php echo esc_attr('mailto:' . $ed_contacts['email']); ?>"><?php echo edlibacherhof_icona('email'); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php echo esc_html($ed_contacts['email']); ?></span></a><?php endif; ?>
                </address>
                <?php if ($ed_route !== '') : ?>
                    <div class="ed-azioni"><a class="ed-bottone ed-bottone--linea" href="<?php echo esc_url($ed_route); ?>" rel="noopener" target="_blank"><?php esc_html_e('Route planen', 'edlibacherhof-child-theme'); ?></a></div>
                <?php endif; ?>
            </div>
            <?php if ($ed_hours) : ?>
                <div style="--t:4; --d:6; --d-start:7">
                    <table class="ed-orari">
                        <caption><?php esc_html_e('Öffnungszeiten', 'edlibacherhof-child-theme'); ?></caption>
                        <tbody>
                            <?php foreach ($ed_hours as $ed_row) : ?>
                                <tr><th scope="row"><?php echo esc_html($ed_row['giorno']); ?></th><td><?php echo esc_html($ed_row['testo']); ?></td></tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php if (($ed_hnote = trim((string) get_option('ticinoweb_contact_opening_hours_note', ''))) !== '') : ?>
                        <p class="ed-didascalia ed-orari__nota"><?php echo esc_html(edlibacherhof_t($ed_hnote, 'hours:note')); ?></p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
        <?php $ed_embed = edlibacherhof_map_embed_url(); ?>
        <?php if ($ed_embed !== '') : ?>
            <div class="ed-contenitore">
                <?php // Mappa di Google: si carica solo con il consenso ai cookie di marketing (banner del parent) o con un clic. ?>
                <div class="ed-mappa" data-ed-gmappa="<?php echo esc_url($ed_embed); ?>" data-ed-titolo="<?php echo esc_attr(sprintf(__('Karte von Google Maps: %s', 'edlibacherhof-child-theme'), get_bloginfo('name'))); ?>">
                    <div class="ed-mappa__velo">
                        <p class="ed-mappa__titolo"><?php echo esc_html(get_bloginfo('name')); ?><?php foreach ($ed_lines as $ed_line) : ?>, <?php echo esc_html($ed_line); ?><?php endforeach; ?></p>
                        <button class="ed-bottone ed-bottone--linea ed-mappa__carica" type="button"><?php esc_html_e('Google-Karte anzeigen', 'edlibacherhof-child-theme'); ?></button>
                        <p class="ed-mappa__nota"><?php esc_html_e('Beim Laden erhält Google Ihre IP-Adresse und kann Cookies setzen.', 'edlibacherhof-child-theme'); ?><?php if (edlibacherhof_privacy_url() !== '') : ?> <a class="ed-link" href="<?php echo esc_url(edlibacherhof_url(edlibacherhof_privacy_url(), 'url:privacy')); ?>"><?php esc_html_e('Datenschutz', 'edlibacherhof-child-theme'); ?></a><?php endif; ?></p>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </section>
</main>
<?php
get_footer();
