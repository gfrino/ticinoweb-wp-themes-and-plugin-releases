/* Edlibacherhof: menu su telefono e tablet, riapertura delle preferenze dei cookie. Nessuna libreria. */
(function () {
  'use strict';
  var bottone = document.querySelector('.ed-testata__menu');
  var pannello = document.getElementById('ed-menu-mobil');
  var cfg = window.edlibacherhof || {};
  if (bottone && pannello) {
    var imposta = function (aperto) {
      bottone.setAttribute('aria-expanded', String(aperto));
      bottone.setAttribute('aria-label', aperto ? (cfg.menuClose || 'Menü schliessen') : (cfg.menuOpen || 'Menü öffnen'));
      pannello.classList.toggle('ed-aperto', aperto);
    };
    bottone.addEventListener('click', function () { imposta(bottone.getAttribute('aria-expanded') !== 'true'); });
    pannello.querySelectorAll('a').forEach(function (a) { a.addEventListener('click', function () { imposta(false); }); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && bottone.getAttribute('aria-expanded') === 'true') { imposta(false); bottone.focus(); } });
  }

  /* Il banner del parent sparisce dopo la scelta: si riapre togliendo il cookie della scelta. */
  document.querySelectorAll('[data-ed-cookies]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var scaduto = '=; expires=Thu, 01 Jan 1970 00:00:00 GMT; SameSite=Lax; path=';
      var percorso = window.location.pathname.split('/').slice(0, 2).join('/') || '/';
      document.cookie = 'tw_cookie_consent' + scaduto + '/';
      if (percorso !== '/') document.cookie = 'tw_cookie_consent' + scaduto + percorso;
      window.location.reload();
    });
  });
  /* Aggiunte delle pizze (Product Add-ons): ogni gruppo si apre con un tocco; accanto al nome, quante ne hai scelte.
     Il titolo originale (h2 nella legend) resta nella pagina, nascosto alla vista: lo legge il calcolo dei totali. */
  var nAggiunte = 0;
  window.edAggiunte = function (radice) { radice.querySelectorAll('.wc-pao-fieldset').forEach(function (fs) {
    var legend = fs.querySelector('.wc-pao-legend');
    var wrap = fs.querySelector('.wc-pao-addon-wrap');
    if (!legend || !wrap || fs.querySelector('.ed-aggiunte__apri')) return;
    wrap.id = wrap.id || 'ed-aggiunte-' + (++nAggiunte);
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'ed-aggiunte__apri';
    btn.setAttribute('aria-expanded', 'false');
    btn.setAttribute('aria-controls', wrap.id);
    var nome = document.createElement('span');
    nome.textContent = legend.textContent.trim();
    var n = document.createElement('span');
    n.className = 'ed-aggiunte__n';
    btn.appendChild(nome);
    btn.appendChild(n);
    legend.classList.add('ed-nascosto');
    legend.insertAdjacentElement('afterend', btn);
    wrap.hidden = true;
    var conta = function () {
      var k = wrap.querySelectorAll('input:checked').length;
      n.textContent = k ? '(' + k + ')' : '';
    };
    btn.addEventListener('click', function () {
      var aperto = btn.getAttribute('aria-expanded') === 'true';
      btn.setAttribute('aria-expanded', String(!aperto));
      wrap.hidden = aperto;
    });
    wrap.addEventListener('change', conta);
    conta();
  }); };
  window.edAggiunte(document);

  /* Carta: «Auswählen» apre un popup con le aggiunte (le schede dei piatti non si aprono). Il contenuto arriva
     dal server (wc-ajax ed_scelta), il modulo si manda a ed_aggiungi; poi conferma con «Weiter bestellen». */
  var scelta = document.querySelector('.ed-scelta');
  var conf = window.edlibacherhofScelta;
  if (scelta && conf && typeof scelta.showModal === 'function') {
    var corpo = scelta.querySelector('.ed-scelta__corpo');
    var frase = function (k) { var n = scelta.querySelector('[data-ed-frasi] [data-f="' + k + '"]'); return n ? n.textContent.trim() : ''; };
    var origine = null;
    var messaggio = function (testo, classe) {
      var p = document.createElement('p');
      p.className = classe || 'ed-scelta__nota';
      p.textContent = testo;
      return p;
    };
    /* Il popup si apre solo a contenuto pronto (foto compresa), già alla sua misura finale: niente finestra
       piccola che poi si allarga. Il contenuto si chiede in anticipo al passaggio del mouse o al tocco. */
    var cache = {};
    var prendi = function (id) {
      if (!cache[id]) {
        cache[id] = fetch(conf.scelta.replace('%%endpoint%%', 'ed_scelta') + '&id=' + encodeURIComponent(id), { credentials: 'same-origin' })
          .then(function (r) { if (!r.ok) throw new Error(r.status); return r.text(); })
          .catch(function (e) { delete cache[id]; throw e; });
      }
      return cache[id];
    };
    var foto = function (url) {
      if (!url) return Promise.resolve();
      var img = new Image();
      img.src = url;
      var pronta = img.decode ? img.decode().catch(function () {}) : Promise.resolve();
      return Promise.race([pronta, new Promise(function (ok) { setTimeout(ok, 1200); })]);
    };
    var mostra = function () {
      scelta.showModal();
      if (window.edLenis) window.edLenis.stop();
    };
    var apri = function (btn) {
      if (btn.classList.contains('loading')) return;
      origine = btn;
      btn.classList.add('loading');
      btn.setAttribute('aria-busy', 'true');
      var fine = function () { btn.classList.remove('loading'); btn.removeAttribute('aria-busy'); };
      prendi(btn.getAttribute('data-ed-scegli'))
        .then(function (html) {
          var tmp = document.createElement('div');
          tmp.innerHTML = html;
          var img = tmp.querySelector('.ed-scelta__foto img');
          return foto(img && (img.currentSrc || img.src)).then(function () { return html; });
        })
        .then(function (html) {
          corpo.innerHTML = html;
          window.edAggiunte(corpo);
          fine();
          mostra();
          scelta.scrollTop = 0;
          // Product Add-ons avvia i suoi totali sui moduli presenti quando riceve questo evento.
          if (window.jQuery) window.jQuery(document.body).trigger('quick-view-displayed');
          var t = corpo.querySelector('h2');
          if (t) { t.tabIndex = -1; t.focus({ preventScroll: true }); }
        })
        .catch(function () {
          fine();
          corpo.replaceChildren(messaggio(frase('errore'), 'ed-scelta__errore'));
          mostra();
        });
    };
    var anticipa = function (e) {
      var btn = e.target.closest && e.target.closest('[data-ed-scegli]');
      if (btn) prendi(btn.getAttribute('data-ed-scegli')).catch(function () {});
    };
    document.addEventListener('pointerover', anticipa, { passive: true });
    document.addEventListener('touchstart', anticipa, { passive: true });
    document.addEventListener('focusin', anticipa);
    var conferma = function (nome) {
      var box = document.createElement('div');
      box.className = 'ed-scelta__fatto';
      var p = messaggio(nome + ' ' + frase('aggiunto'), 'ed-scelta__ok');
      p.tabIndex = -1;
      var azioni = document.createElement('div');
      azioni.className = 'ed-scelta__azioni';
      var avanti = document.createElement('button');
      avanti.type = 'button';
      avanti.className = 'ed-bottone ed-bottone--linea';
      avanti.setAttribute('data-ed-chiudi', '');
      avanti.textContent = frase('continua');
      var vai = document.createElement('a');
      vai.className = 'ed-bottone ed-bottone--pieno';
      vai.href = scelta.querySelector('[data-ed-carrello]').href;
      vai.textContent = frase('carrello');
      azioni.append(avanti, vai);
      box.append(p, azioni);
      corpo.replaceChildren(box);
      p.focus();
    };
    document.addEventListener('click', function (e) {
      var btn = e.target.closest('[data-ed-scegli]');
      if (btn) { e.preventDefault(); apri(btn); }
    });
    scelta.addEventListener('click', function (e) {
      if (e.target === scelta || e.target.closest('[data-ed-chiudi]')) scelta.close();
    });
    scelta.addEventListener('close', function () {
      corpo.replaceChildren();
      if (window.edLenis) window.edLenis.start();
      if (origine) origine.focus();
    });
    corpo.addEventListener('submit', function (e) {
      var form = e.target.closest('form.cart');
      if (!form || e.defaultPrevented) return; // Product Add-ons ha già fermato un modulo incompleto
      e.preventDefault();
      if (form.checkValidity && !form.checkValidity()) { form.reportValidity(); return; }
      var bottone = form.querySelector('[type="submit"]');
      var dati = new FormData(form);
      dati.set('product_id', bottone && bottone.value ? bottone.value : (origine && origine.getAttribute('data-ed-scegli')));
      dati.delete('add-to-cart');
      if (bottone) { bottone.disabled = true; bottone.classList.add('loading'); }
      corpo.querySelectorAll('.ed-scelta__errore').forEach(function (n) { n.remove(); });
      fetch(conf.aggiungi.replace('%%endpoint%%', 'ed_aggiungi'), { method: 'POST', body: dati, credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (res) {
          if (!res || res.error) {
            var msgs = (res && res.messages && res.messages.length) ? res.messages : [frase('errore')];
            msgs.forEach(function (m) { form.prepend(messaggio(m, 'ed-scelta__errore')); });
            if (bottone) { bottone.disabled = false; bottone.classList.remove('loading'); }
            return;
          }
          Object.keys(res.fragments || {}).forEach(function (sel) {
            document.querySelectorAll(sel).forEach(function (n) { n.outerHTML = res.fragments[sel]; });
          });
          if (window.jQuery) window.jQuery(document.body).trigger('added_to_cart', [res.fragments, res.cart_hash, null]);
          var t = corpo.querySelector('h2');
          conferma(t ? t.textContent.trim() : '');
        })
        .catch(function () {
          form.prepend(messaggio(frase('errore'), 'ed-scelta__errore'));
          if (bottone) { bottone.disabled = false; bottone.classList.remove('loading'); }
        });
    });
  }
  /* Galleria: ogni foto si apre a schermo intero (<dialog>), frecce, tastiera e scorrimento con il dito. */
  var visore = document.querySelector('.ed-visore');
  var aperture = Array.prototype.slice.call(document.querySelectorAll('.ed-galleria__apri'));
  if (visore && aperture.length && typeof visore.showModal === 'function') {
    var img = visore.querySelector('img');
    var cap = visore.querySelector('figcaption');
    var attuale = 0;
    var mostra = function (i) {
      attuale = (i + aperture.length) % aperture.length;
      var b = aperture[attuale];
      img.src = b.getAttribute('data-ed-grande');
      img.alt = b.getAttribute('data-ed-didascalia') || '';
      cap.textContent = b.getAttribute('data-ed-didascalia') || '';
    };
    aperture.forEach(function (b, i) {
      b.addEventListener('click', function () { mostra(i); visore.showModal(); });
    });
    visore.querySelector('.ed-visore__chiudi').addEventListener('click', function () { visore.close(); });
    visore.querySelector('.ed-visore__prec').addEventListener('click', function () { mostra(attuale - 1); });
    visore.querySelector('.ed-visore__succ').addEventListener('click', function () { mostra(attuale + 1); });
    visore.addEventListener('click', function (e) { if (e.target === visore) visore.close(); });
    visore.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowLeft') mostra(attuale - 1);
      if (e.key === 'ArrowRight') mostra(attuale + 1);
    });
    visore.addEventListener('close', function () { aperture[attuale].focus(); });
    var x0 = null;
    visore.addEventListener('touchstart', function (e) { x0 = e.touches[0].clientX; }, { passive: true });
    visore.addEventListener('touchend', function (e) {
      if (x0 === null) return;
      var dx = e.changedTouches[0].clientX - x0;
      if (Math.abs(dx) > 50) mostra(attuale + (dx < 0 ? 1 : -1));
      x0 = null;
    });
  }
  /* Mappa di Google: si carica con il consenso ai cookie di marketing del banner del parent, oppure con un clic sul
     bottone (consenso solo per questo contenuto). Prima resta il riquadro con indirizzo e bottone. */
  document.querySelectorAll('[data-ed-gmappa]').forEach(function (box) {
    var carica = function () {
      if (box.querySelector('iframe')) return;
      var f = document.createElement('iframe');
      f.src = box.getAttribute('data-ed-gmappa');
      f.title = box.getAttribute('data-ed-titolo') || '';
      f.loading = 'lazy';
      f.referrerPolicy = 'no-referrer-when-downgrade';
      f.setAttribute('allowfullscreen', '');
      box.appendChild(f);
      box.classList.add('ed-caricata');
    };
    var pref = {};
    try { pref = JSON.parse(decodeURIComponent((document.cookie.match(/(?:^|; )tw_cookie_preferences=([^;]*)/) || [])[1] || '%7B%7D')); } catch (e) { pref = {}; }
    if (pref.marketing) carica();
    var btn = box.querySelector('.ed-mappa__carica');
    if (btn) btn.addEventListener('click', carica);
    var accetta = document.getElementById('tw-cookie-accept');
    if (accetta) accetta.addEventListener('click', function () { window.setTimeout(carica, 50); });
  });
  /* ---------- Link interni (#menu, #restaurant…): scorrimento morbido con frenata, poi il titolo della sezione «arriva».
     Con «riduci movimento» il salto resta immediato. ---------- */
  var calmo = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var curva = function (t) { return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; };
  var margine = function () { return parseFloat(getComputedStyle(document.documentElement).scrollPaddingTop) || 0; };
  var arriva = function (sezione) {
    var titolo = sezione.querySelector('h2, h1');
    if (!titolo || !titolo.animate) return;
    titolo.animate([{ opacity: 0.35, transform: 'translateY(14px)' }, { opacity: 1, transform: 'none' }], { duration: 520, easing: 'cubic-bezier(.22,.8,.24,1)' });
  };
  var vaiA = function (sezione) {
    var da = window.scrollY;
    var a = Math.max(0, Math.min(sezione.getBoundingClientRect().top + da - margine(), document.documentElement.scrollHeight - window.innerHeight));
    var dist = a - da;
    if (calmo || Math.abs(dist) < 4) { window.scrollTo(0, a); return; }
    var durata = Math.min(1100, Math.max(450, Math.abs(dist) * 0.35)), t0 = null, fermato = false;
    // Con Lenis attivo (movimento.js) lo scorrimento lo fa Lenis, con la stessa curva: niente due motori in lotta.
    if (window.edLenis) { window.edLenis.scrollTo(a, { duration: durata / 1000, easing: curva, onComplete: function () { arriva(sezione); } }); return; }
    var ferma = function () { fermato = true; };
    window.addEventListener('wheel', ferma, { passive: true, once: true });
    window.addEventListener('touchstart', ferma, { passive: true, once: true });
    var passo = function (ora) {
      if (fermato) return;
      if (t0 === null) t0 = ora;
      var k = Math.min(1, (ora - t0) / durata);
      window.scrollTo(0, da + dist * curva(k));
      if (k < 1) { requestAnimationFrame(passo); } else { arriva(sezione); }
    };
    requestAnimationFrame(passo);
  };
  document.addEventListener('click', function (e) {
    if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    var link = e.target.closest && e.target.closest('a[href*="#"]');
    if (!link || link.target === '_blank') return;
    var url = new URL(link.href, location.href);
    if (url.origin !== location.origin || url.pathname !== location.pathname || url.hash.length < 2) return;
    var sezione = document.getElementById(decodeURIComponent(url.hash.slice(1)));
    if (!sezione) return;
    e.preventDefault();
    if (history.pushState) { history.pushState(null, '', url.hash); }
    vaiA(sezione);
    sezione.setAttribute('tabindex', sezione.getAttribute('tabindex') || '-1');
    sezione.focus({ preventScroll: true });
  });
})();

/* Targa dal vivo nel primo schermo: aperto / chiude tra poco (30 min) / chiuso, con l'ora di oggi del browser.
   Orari e frasi arrivano dall'HTML (data-orari, .ed-targa__frasi); si aggiorna ogni minuto. */
(function () {
  var targa = document.querySelector('[data-ed-targa]');
  if (!targa) { return; }
  var orari;
  try { orari = JSON.parse(targa.getAttribute('data-orari') || '[]'); } catch (e) { return; }
  if (!orari.length) { return; }
  var frasi = targa.parentNode.querySelector('.ed-targa__frasi');
  function f(k) { var n = frasi && frasi.querySelector('[data-f="' + k + '"]'); return n ? n.textContent.trim() : ''; }
  function g(i) { var n = frasi && frasi.querySelector('[data-g="' + i + '"]'); return n ? n.textContent.trim() : ''; }
  function min(h) { var p = String(h).split(':'); return (+p[0]) * 60 + (+(p[1] || 0)); }
  function ora(h) { var m = min(h) % 1440; return String(Math.floor(m / 60)).padStart(2, '0') + '.' + String(m % 60).padStart(2, '0'); }
  var PRESTO = 30;

  function aggiorna() {
    var ora_ = new Date();
    var oggi = (ora_.getDay() + 6) % 7; // 0 = lunedì, come gli orari del CMS
    var adesso = ora_.getHours() * 60 + ora_.getMinutes();
    var stato, titolo, riga = '';
    var fasce = orari[oggi] || [];
    var aperta = fasce.filter(function (s) { return adesso >= min(s[0]) && adesso < min(s[1]); })[0];
    if (aperta) {
      var resta = min(aperta[1]) - adesso;
      stato = resta <= PRESTO ? 'presto' : 'aperto';
      titolo = f(stato);
      riga = (stato === 'presto' ? f('chiude') : f('fino')).replace('{ora}', ora(aperta[1]));
    } else {
      var dopo = fasce.filter(function (s) { return min(s[0]) > adesso; })[0];
      if (dopo) {
        stato = 'chiuso'; titolo = f('chiuso'); riga = f('oggi').replace('{ora}', ora(dopo[0]));
      } else {
        stato = fasce.length ? 'chiuso' : 'riposo';
        titolo = f(stato);
        for (var k = 1; k <= 7; k++) {
          var d = (oggi + k) % 7;
          if ((orari[d] || []).length) {
            riga = (k === 1 ? f('domani') : f('giorno').replace('{giorno}', g(d))).replace('{ora}', ora(orari[d][0][0]));
            break;
          }
        }
      }
    }
    targa.setAttribute('data-stato', stato);
    targa.querySelector('.ed-targa__titolo').textContent = titolo;
    targa.querySelector('.ed-targa__ore').textContent = riga;
    targa.hidden = false;
    var nota = targa.parentNode.querySelector('[data-ed-senza-targa]');
    if (nota) { nota.hidden = true; }
  }
  aggiorna();
  setInterval(aggiorna, 60000);
}());

/* Foto del primo schermo che si alternano ogni 5 secondi. Ferme con «riduci movimento», in pausa a scheda nascosta
   o con il mouse sopra; la foto successiva si carica prima di mostrarla. */
(function () {
  var box = document.querySelector('[data-ed-scorre]');
  if (!box || window.matchMedia('(prefers-reduced-motion: reduce)').matches) { return; }
  var foto = Array.prototype.slice.call(box.querySelectorAll(':scope > img'));
  if (foto.length < 2) { return; }
  var i = 0, ferma = false;
  // Le altre foto si scaricano solo a pagina caricata, per non rallentare il primo schermo.
  window.addEventListener('load', function () { foto.forEach(function (f) { f.loading = 'eager'; }); });
  box.addEventListener('mouseenter', function () { ferma = true; });
  box.addEventListener('mouseleave', function () { ferma = false; });
  setInterval(function () {
    if (ferma || document.hidden) { return; }
    var dopo = foto[(i + 1) % foto.length];
    if (!dopo.complete) { return; }
    foto[i].classList.remove('ed-attiva');
    i = (i + 1) % foto.length;
    dopo.classList.add('ed-attiva');
  }, 5000);
}());

/* Barra delle categorie: se la riga scorre, sfumatura e freccia dal lato dove ci sono altre categorie; le frecce
   scorrono la riga di quasi una larghezza. Al primo sguardo la riga fa un piccolo «assaggio» verso sinistra e torna,
   così su telefono si capisce che si può scorrere (una volta per visita, mai con «riduci movimento»). */
(function () {
  var nav = document.querySelector('.ed-categorie');
  var ul = nav && nav.querySelector('ul');
  if (!ul) { return; }
  var indietro = nav.querySelector('[data-ed-cat-scorri="-1"]');
  var avanti = nav.querySelector('[data-ed-cat-scorri="1"]');
  var calmo = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var misura = function () {
    var scorre = ul.scrollWidth > ul.clientWidth + 1;
    var sx = scorre && ul.scrollLeft > 2;
    var dx = scorre && ul.scrollLeft + ul.clientWidth < ul.scrollWidth - 2;
    nav.classList.toggle('ed-a-sinistra', sx);
    nav.classList.toggle('ed-a-destra', dx);
    if (indietro) { indietro.hidden = !sx; }
    if (avanti) { avanti.hidden = !dx; }
  };
  [indietro, avanti].forEach(function (b) {
    if (!b) { return; }
    b.addEventListener('click', function () {
      ul.scrollBy({ left: (+b.getAttribute('data-ed-cat-scorri')) * ul.clientWidth * 0.7, behavior: calmo ? 'auto' : 'smooth' });
    });
  });
  misura();
  ul.addEventListener('scroll', misura, { passive: true });
  window.addEventListener('resize', misura);
  if (document.fonts && document.fonts.ready) { document.fonts.ready.then(misura); }

  var giaVisto = false;
  try { giaVisto = sessionStorage.getItem('ed-cat-assaggio') === '1'; } catch (e) {}
  if (calmo || giaVisto || !('IntersectionObserver' in window)) { return; }
  var io = new IntersectionObserver(function (voci) {
    if (!voci[0].isIntersecting || !nav.classList.contains('ed-a-destra') || ul.scrollLeft > 2) { return; }
    io.disconnect();
    try { sessionStorage.setItem('ed-cat-assaggio', '1'); } catch (e) {}
    nav.classList.add('ed-invita');
    setTimeout(function () { ul.scrollTo({ left: 56, behavior: 'smooth' }); }, 500);
    setTimeout(function () { ul.scrollTo({ left: 0, behavior: 'smooth' }); }, 1100);
  }, { threshold: 0.9 });
  io.observe(nav);
}());

/* Carrello fluttuante: piccolo salto a ogni aggiunta (WooCommerce e popup degli extra lanciano «added_to_cart»;
   i frammenti hanno già sostituito l'elemento con il numero e il totale nuovi). */
(function () {
  if (!window.jQuery) { return; }
  window.jQuery(document.body).on('added_to_cart', function () {
    // Dopo un attimo: wc-cart-fragments può sostituire di nuovo l'elemento subito dopo l'evento.
    setTimeout(function () {
      var c = document.querySelector('.ed-carrello-flottante');
      if (!c || c.hidden) { return; }
      c.classList.remove('ed-sobbalza'); void c.offsetWidth; c.classList.add('ed-sobbalza');
    }, 120);
  });
}());
