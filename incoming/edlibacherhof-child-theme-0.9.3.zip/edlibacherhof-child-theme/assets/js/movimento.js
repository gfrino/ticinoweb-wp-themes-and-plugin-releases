/**
 * Edlibacherhof: movimento del sito con Lenis (scorrimento morbido) e GSAP + ScrollTrigger.
 * - Primo schermo: il titolo sale parola per parola da sotto una linea, testo e bottoni seguono, la foto si apre.
 * - Scorrendo: titoli e testi delle sezioni salgono, schede e righe arrivano in sequenza, le foto si scoprono dal basso,
 *   la foto della facciata e quella del locale scorrono un po' più lente della pagina (parallasse).
 * - Senza JavaScript, con «riduci movimento» o se le librerie non arrivano, tutto resta fermo e visibile.
 * Lenis si ferma quando sono aperti il visore delle foto o il menu del telefono; select2, menu e finestre scorrono da soli.
 */
(function () {
  'use strict';
  var html = document.documentElement;
  var calmo = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (calmo || !window.gsap || !window.ScrollTrigger) { html.classList.remove('ed-moto'); return; }
  var gsap = window.gsap, ST = window.ScrollTrigger;
  gsap.registerPlugin(ST);
  window.edMotoPartito = true;

  /* ---------- Lenis ---------- */
  if (window.Lenis) {
    var lenis = new window.Lenis({
      duration: 1.15,
      easing: function (t) { return Math.min(1, 1.001 - Math.pow(2, -10 * t)); },
      prevent: function (n) { return !!(n.closest && n.closest('.select2-container, #ed-menu-mobil, dialog, .ed-categorie ul, .woocommerce-MyAccount-navigation ul')); }
    });
    window.edLenis = lenis;
    lenis.on('scroll', ST.update);
    gsap.ticker.add(function (t) { lenis.raf(t * 1000); });
    gsap.ticker.lagSmoothing(0);
    var segui = function (el, attr, ferma) {
      if (!el || !window.MutationObserver) return;
      new MutationObserver(function () { if (ferma(el)) lenis.stop(); else lenis.start(); }).observe(el, { attributes: true, attributeFilter: [attr] });
    };
    segui(document.querySelector('.ed-visore'), 'open', function (el) { return el.open; });
    segui(document.querySelector('[aria-controls="ed-menu-mobil"]'), 'aria-expanded', function (el) { return el.getAttribute('aria-expanded') === 'true'; });
  }

  var E = 'power3.out';

  /* ---------- Primo schermo ---------- */
  var hero = document.querySelector('.ed-hero');
  if (hero) {
    var h1 = hero.querySelector('h1');
    var parole = [];
    if (h1) {
      // Ogni parola (o elemento, come la parola evidenziata) dentro una «finestra» che la taglia sotto la riga.
      var avvolgi = function (contenuto) {
        var fuori = document.createElement('span'); fuori.className = 'ed-parola';
        var dentro = document.createElement('span'); dentro.appendChild(contenuto);
        fuori.appendChild(dentro); parole.push(dentro); return fuori;
      };
      // Lo spazio unificatore prima della parola evidenziata («a Edlibach») tiene insieme le due parole: la parola
      // prima e l'<em> finiscono nella stessa finestra, così non vanno a capo separate e la riga non inizia con uno spazio.
      var nodi = Array.prototype.slice.call(h1.childNodes);
      var coda = null;
      nodi.forEach(function (n, i) {
        if (n.nodeType === 3) {
          var pezzi = n.textContent.split(/([ \t\n\r]+)/).filter(Boolean);
          var dopo = nodi[i + 1];
          if (dopo && dopo.nodeType === 1 && dopo.tagName !== 'BR' && pezzi.length && /\u00a0$/.test(pezzi[pezzi.length - 1])) {
            coda = pezzi.pop();
          }
          var frammento = document.createDocumentFragment();
          pezzi.forEach(function (pezzo) {
            frammento.appendChild(/^\s+$/.test(pezzo) ? document.createTextNode(pezzo) : avvolgi(document.createTextNode(pezzo)));
          });
          h1.replaceChild(frammento, n);
        } else if (n.nodeType === 1 && n.tagName !== 'BR') {
          var gruppo = document.createDocumentFragment();
          if (coda !== null) { gruppo.appendChild(document.createTextNode(coda)); coda = null; }
          gruppo.appendChild(n.cloneNode(true));
          h1.replaceChild(avvolgi(gruppo), n);
        }
      });
    }
    var tl = gsap.timeline({ defaults: { ease: E } });
    if (parole.length) tl.from(parole, { yPercent: 115, duration: 0.95, stagger: 0.07 }, 0.1);
    tl.from(hero.querySelectorAll('.ed-hero__testo > :not(h1)'), { y: 24, opacity: 0, duration: 0.8, stagger: 0.1 }, 0.45);
    var foto = hero.querySelector('.ed-hero__foto');
    if (foto) {
      tl.from(foto, { clipPath: 'inset(14% 10% 14% 10% round 14px)', duration: 1.4, ease: 'expo.out' }, 0)
        .from(foto.querySelector('img'), { scale: 1.18, duration: 1.8, ease: 'expo.out' }, 0);
    }
  }
  html.classList.remove('ed-moto');

  /* ---------- Entrate allo scorrimento ---------- */
  // Entrate con IntersectionObserver: segue la posizione vera anche quando la pagina cambia dopo il calcolo
  // (filtri della carta, immagini che arrivano, carrello che si aggiorna), così nessun elemento resta nascosto.
  var entra = function (sel, da, opz) {
    var els = gsap.utils.toArray(sel).filter(function (el) { return !hero || !hero.contains(el); });
    if (!els.length || !window.IntersectionObserver) return;
    gsap.set(els, da);
    var io = new IntersectionObserver(function (voci) {
      var gruppo = voci.filter(function (v) { return v.isIntersecting; }).map(function (v) { io.unobserve(v.target); return v.target; });
      if (gruppo.length) gsap.to(gruppo, Object.assign({ y: 0, x: 0, opacity: 1, scale: 1, duration: 0.9, ease: E, stagger: 0.08, overwrite: true, clearProps: 'transform,opacity,translate,rotate,scale' }, opz || {}));
    }, { rootMargin: '0px 0px -8% 0px' });
    els.forEach(function (el) { io.observe(el); });
  };
  // Titoli e testi: salgono un po'
  entra('.ed-sezione__testa > *, .ed-foglio__testa > *, .ed-locale__testo > *, .ed-contatti > *, .ed-carta-testa > *, .ed-pagina__corpo > h1, .ed-strada figcaption', { y: 28, opacity: 0 });
  // Schede, righe e gruppi: arrivano in fila
  entra('.ed-menu, .ed-finestra, .ed-ordine__righe > *, .ed-orari tr, .ed-piatto, .ed-gruppo > h2, .ed-conto__vie li, .ed-carta-altre li', { y: 32, opacity: 0 }, { stagger: 0.06 });
  // Il foglio del menu del pranzo: sale e si posa
  entra('.ed-foglio', { y: 60, opacity: 0, scale: 0.985 }, { duration: 1.1 });
  // Piè di pagina
  entra('.ed-piede__in > *', { y: 24, opacity: 0 }, { stagger: 0.1 });

  // Foto della galleria e del locale: si scoprono dal basso, l'immagine rientra dallo zoom
  gsap.utils.toArray('.ed-galleria__foto, .ed-locale__foto .ed-foto').forEach(function (box) {
    var img = box.querySelector('img');
    var t = gsap.timeline({ scrollTrigger: { trigger: box, start: 'top 90%', once: true } });
    t.from(box, { clipPath: 'inset(100% 0% 0% 0%)', duration: 1.1, ease: 'expo.out' });
    if (img && !box.closest('.ed-locale__foto--alta')) t.from(img, { scale: 1.2, duration: 1.4, ease: 'expo.out' }, 0);   // la foto alta ha già la parallasse
  });

  // Parallasse leggera: la facciata e la foto alta del locale scorrono più lente della pagina
  gsap.utils.toArray('.ed-strada .ed-foto img, .ed-locale__foto--alta .ed-foto img').forEach(function (img) {
    gsap.fromTo(img, { yPercent: -6, scale: 1.14 }, { yPercent: 6, scale: 1.14, ease: 'none', scrollTrigger: { trigger: img.closest('.ed-foto'), start: 'top bottom', end: 'bottom top', scrub: true } });
  });

  window.addEventListener('load', function () { ST.refresh(); });
})();
