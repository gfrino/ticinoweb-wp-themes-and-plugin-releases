<?php
/**
 * Pizzeria Edlibacherhof: child di ticinoWEB CMS (ticinoweb-ai-theme), senza Elementor.
 * Pagina iniziale dal prototipo della skill design-con-carattere (direzione A «Gasthof», 16.11.2026).
 * Contatti, orari, logo, «Chi siamo», gallerie, SEO e cookie restano nel parent; piatti e ordini sono WooCommerce;
 * i testi della home stanno in Aspetto → Personalizza → Edlibacherhof (inc/settings.php).
 *
 * @package edlibacherhof-child-theme
 */

defined('ABSPATH') || exit;

define('EDLIBACHERHOF_VERSION', wp_get_theme(get_stylesheet())->get('Version'));
define('EDLIBACHERHOF_DIR', get_stylesheet_directory());
define('EDLIBACHERHOF_URI', get_stylesheet_directory_uri());

require_once EDLIBACHERHOF_DIR . '/inc/helpers.php';
require_once EDLIBACHERHOF_DIR . '/inc/icone.php';
require_once EDLIBACHERHOF_DIR . '/inc/settings.php';
require_once EDLIBACHERHOF_DIR . '/inc/woocommerce.php';
require_once EDLIBACHERHOF_DIR . '/inc/vecchi-indirizzi.php';

add_action('after_setup_theme', function () {
    load_child_theme_textdomain('edlibacherhof-child-theme', EDLIBACHERHOF_DIR . '/languages');
    register_nav_menus(array('ed-legal' => __('Piè di pagina: link legali', 'edlibacherhof-child-theme')));
}, 20);

/**
 * Stili e script. Il parent accoda già lo style.css del child («ticinoweb-ai-style»): qui si mette lo style.css del
 * parent come dipendenza e si versiona tutto con la versione del child (ogni rilascio svuota la cache del browser).
 * I caratteri sono nel tema: Poppins di Google non si scarica.
 */
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('edlibacherhof-parent', get_template_directory_uri() . '/style.css', array(), wp_get_theme(get_template())->get('Version'));
    if (isset(wp_styles()->registered['ticinoweb-ai-style'])) {
        wp_styles()->registered['ticinoweb-ai-style']->deps[] = 'edlibacherhof-parent';
        // Versione del tema + data del file: ogni modifica arriva subito anche a chi ha il foglio in cache.
        wp_styles()->registered['ticinoweb-ai-style']->ver    = EDLIBACHERHOF_VERSION . '.' . (int) @filemtime(EDLIBACHERHOF_DIR . '/style.css');
    }
    // Handle vuoto al posto del carattere di Google: la dipendenza del parent resta valida, non si stampa nulla.
    wp_deregister_style('poppins-font');
    wp_register_style('poppins-font', false, array(), null);

    // Le pagine del tema non usano blocchi; sulle pagine del negozio gli stili dei blocchi servono (carrello e cassa).
    if (!(function_exists('is_woocommerce') && (is_woocommerce() || is_cart() || is_checkout() || is_account_page()))) {
        wp_dequeue_style('wp-block-library');
        wp_dequeue_style('classic-theme-styles');
        wp_dequeue_style('global-styles');
    }

    // Movimento: Lenis (scorrimento morbido) e GSAP + ScrollTrigger, nel tema (assets/lib), nessuna richiesta esterna.
    $ed_lib = EDLIBACHERHOF_URI . '/assets/lib/';
    wp_enqueue_style('edlibacherhof-lenis', $ed_lib . 'lenis.css', array(), '1.3.27');
    wp_enqueue_script('edlibacherhof-lenis', $ed_lib . 'lenis.min.js', array(), '1.3.27', array('in_footer' => true, 'strategy' => 'defer'));
    wp_enqueue_script('edlibacherhof-gsap', $ed_lib . 'gsap.min.js', array(), '3.15.1', array('in_footer' => true, 'strategy' => 'defer'));
    wp_enqueue_script('edlibacherhof-scrolltrigger', $ed_lib . 'ScrollTrigger.min.js', array('edlibacherhof-gsap'), '3.15.1', array('in_footer' => true, 'strategy' => 'defer'));
    wp_enqueue_script('edlibacherhof-movimento', EDLIBACHERHOF_URI . '/assets/js/movimento.js', array('edlibacherhof-lenis', 'edlibacherhof-gsap', 'edlibacherhof-scrolltrigger'), EDLIBACHERHOF_VERSION . '.' . (int) @filemtime(EDLIBACHERHOF_DIR . '/assets/js/movimento.js'), array('in_footer' => true, 'strategy' => 'defer'));

    wp_enqueue_script('edlibacherhof-site', EDLIBACHERHOF_URI . '/assets/js/site.js', array(), EDLIBACHERHOF_VERSION . '.' . (int) @filemtime(EDLIBACHERHOF_DIR . '/assets/js/site.js'), array('in_footer' => true, 'strategy' => 'defer'));
    wp_localize_script('edlibacherhof-site', 'edlibacherhof', array(
        'menuOpen'  => __('Menü öffnen', 'edlibacherhof-child-theme'),
        'menuClose' => __('Menü schliessen', 'edlibacherhof-child-theme'),
    ));
}, 20);

/**
 * Classe «ed-moto» su <html> prima che la pagina si disegni: il primo schermo resta nascosto finché movimento.js non lo
 * fa entrare (niente lampo). Con «riduci movimento» non si mette; se lo script non parte entro 2,5 s si toglie da sola.
 */
add_action('wp_head', function () {
    echo "<script>(function(d){if(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches)return;d.classList.add('ed-moto');setTimeout(function(){if(!window.edMotoPartito)d.classList.remove('ed-moto');},2500);})(document.documentElement);</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput
}, 2);

/** I due caratteri variabili si precaricano: servono già nel primo schermo. */
add_action('wp_head', function () {
    foreach (array('fraunces-latin-wght-normal.woff2', 'work-sans-latin-wght-normal.woff2') as $ed_font) {
        printf('<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url(EDLIBACHERHOF_URI . '/assets/fonts/' . $ed_font));
    }
}, 1);

/**
 * Il parent apre due preconnect verso Google Fonts su ogni pagina (closure su wp_head 0): si tolgono, perché nessun
 * carattere arriva da Google e l'IP del visitatore non deve uscire prima del consenso (come su Gotthard Resin).
 */
add_action('wp_head', function () {
    global $wp_filter;
    if (empty($wp_filter['wp_head']) || empty($wp_filter['wp_head']->callbacks[0])) {
        return;
    }
    $parent_functions = wp_normalize_path(get_template_directory() . '/functions.php');
    foreach ($wp_filter['wp_head']->callbacks[0] as $callback) {
        if (!($callback['function'] instanceof Closure)) {
            continue;
        }
        $ref = new ReflectionFunction($callback['function']);
        if (wp_normalize_path((string) $ref->getFileName()) !== $parent_functions) {
            continue;
        }
        $lines = file($parent_functions);
        $body  = implode('', array_slice((array) $lines, $ref->getStartLine() - 1, $ref->getEndLine() - $ref->getStartLine() + 1));
        if (strpos($body, 'fonts.googleapis.com') !== false) {
            remove_action('wp_head', $callback['function'], 0);
        }
    }
}, -100);

/** Emoji di WordPress: scaricherebbero immagini da s.w.org prima del consenso ai cookie. */
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');
add_filter('emoji_svg_url', '__return_false');

/** WordPress mette sizes="auto" sulle immagini lazy e le pianta a 1500px finché il CSS non arriva: si spegne. */
add_filter('wp_img_tag_add_auto_sizes', '__return_false');

add_filter('body_class', function ($classes) {
    $classes[] = 'ed-site';
    return $classes;
});

/**
 * Un'impostazione che manca la dice la bacheca, invece di lasciare la pagina vuota senza spiegazioni.
 */
add_action('admin_notices', function () {
    if (!current_user_can('manage_options')) {
        return;
    }
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if ($screen && !in_array($screen->id, array('dashboard', 'themes', 'toplevel_page_ticinoweb-settings'), true)) {
        return;
    }
    $missing = array();
    if (!edlibacherhof_address_lines()) {
        $missing[] = __('l’indirizzo (ticinoWEB CMS → Contatti): senza, la sezione Kontakt e il link «Route planen» restano vuoti', 'edlibacherhof-child-theme');
    }
    if (!edlibacherhof_hours()) {
        $missing[] = __('gli orari di apertura (ticinoWEB CMS → Contatti): senza, la tabella degli orari non compare', 'edlibacherhof-child-theme');
    }
    if (!function_exists('wc_get_page_permalink')) {
        $missing[] = __('WooCommerce non è attivo: senza, il bottone «Online bestellen» e la carta dei piatti non compaiono', 'edlibacherhof-child-theme');
    }
    if (edlibacherhof_privacy_url() === '') {
        $missing[] = __('la pagina Datenschutz (tW SEO → Cookie e privacy)', 'edlibacherhof-child-theme');
    }
    if (!$missing) {
        return;
    }
    echo '<div class="notice notice-warning"><p><strong>' . esc_html__('Tema Edlibacherhof: da completare', 'edlibacherhof-child-theme') . '</strong></p><ul style="list-style:disc;padding-left:20px">';
    foreach ($missing as $item) {
        echo '<li>' . esc_html($item) . '</li>';
    }
    echo '</ul></div>';
});
