(function () {
	'use strict';

	document.querySelectorAll('[data-gl-stripe-settings]').forEach(function (root) {
		var controls = Array.prototype.slice.call(root.querySelectorAll('[data-gl-stripe-mode]'));
		var panels = Array.prototype.slice.call(root.querySelectorAll('[data-gl-stripe-panel]'));
		var current = root.querySelector('[data-gl-stripe-current]');
		if (!controls.length || !panels.length) return;

		root.classList.add('is-enhanced');

		function syncMode() {
			var selected = controls.find(function (control) { return control.checked; });
			var mode = selected ? selected.value : 'test';
			panels.forEach(function (panel) {
				var active = panel.getAttribute('data-gl-stripe-panel') === mode;
				panel.hidden = !active;
				panel.classList.toggle('is-active', active);
			});
			if (current) {
				var template = current.getAttribute('data-gl-stripe-current-template') || '%s';
				var label = selected ? selected.getAttribute('data-gl-stripe-label') : 'Test';
				current.textContent = template.replace('%s', label);
			}
		}

		controls.forEach(function (control) { control.addEventListener('change', syncMode); });
		syncMode();
	});
}());
