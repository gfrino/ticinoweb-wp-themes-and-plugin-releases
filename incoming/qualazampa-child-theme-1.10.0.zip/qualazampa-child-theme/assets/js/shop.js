(() => {
  'use strict';
  const words=window.qzShop||{}, controls=[];
  let opened=null;
  document.querySelectorAll('[data-qz-select],.woocommerce-ordering select').forEach((select,index)=>{
    const wrap=document.createElement('div');wrap.className='qz-choice';
    const trigger=document.createElement('button');trigger.type='button';trigger.className='qz-choice__trigger';
    const value=document.createElement('span');trigger.append(value);
    const popup=document.createElement('div');popup.className='qz-choice__popup';popup.hidden=true;popup.setAttribute('data-lenis-prevent','');
    const list=document.createElement('ul');list.id='qz-options-'+index;list.className='qz-choice__list';list.setAttribute('role','listbox');
    const label=select.id?document.querySelector('label[for="'+select.id+'"]'):null;
    const name=label?.textContent||words.sort||select.getAttribute('aria-label')||'';
    trigger.id='qz-choice-'+index;trigger.setAttribute('aria-label',name);trigger.setAttribute('aria-haspopup','listbox');trigger.setAttribute('aria-expanded','false');trigger.setAttribute('aria-controls',list.id);
    list.setAttribute('aria-label',name);
    const options=Array.from(select.options).map(option=>{
      const item=document.createElement('li');item.className='qz-choice__option';item.textContent=option.textContent;item.setAttribute('role','option');item.tabIndex=-1;
      item.addEventListener('click',()=>choose(option.index));list.append(item);return item;
    });
    let search=null;
    if(options.length>10){
      search=document.createElement('input');search.type='search';search.className='qz-choice__search';search.placeholder=words.search;search.setAttribute('aria-label',words.search);search.setAttribute('aria-controls',list.id);
      search.addEventListener('input',()=>{
        const query=search.value.trim().toLocaleLowerCase();
        options.forEach((item,i)=>{item.hidden=i!==0&&!item.textContent.toLocaleLowerCase().includes(query);});
        empty.hidden=options.some((item,i)=>i>0&&!item.hidden);
      });popup.append(search);
    }
    const empty=document.createElement('p');empty.className='qz-choice__empty';empty.textContent=words.empty;empty.hidden=true;empty.setAttribute('role','status');
    popup.append(list,empty);wrap.append(trigger,popup);select.after(wrap);
    // Native GET form and Woo sorting stay the only data owners; JS adds the popup.
    select.hidden=true;if(label)label.htmlFor=trigger.id;
    function sync(){value.textContent=select.options[select.selectedIndex]?.textContent||'';trigger.setAttribute('aria-label',name+': '+value.textContent);options.forEach((item,i)=>item.setAttribute('aria-selected',String(i===select.selectedIndex)));}
    function close(restore=false){popup.hidden=true;trigger.setAttribute('aria-expanded','false');if(opened===api)opened=null;if(restore)trigger.focus();}
    function open(){
      opened?.close();opened=api;popup.hidden=false;trigger.setAttribute('aria-expanded','true');
      if(search){search.value='';options.forEach(item=>item.hidden=false);empty.hidden=true;search.focus();}
      else options[select.selectedIndex]?.focus({preventScroll:true});
    }
    function choose(i){select.selectedIndex=i;sync();close(true);select.dispatchEvent(new Event('change',{bubbles:true}));}
    const api={close,wrap};controls.push(api);
    trigger.addEventListener('click',()=>popup.hidden?open():close());
    trigger.addEventListener('keydown',event=>{if(['ArrowDown','ArrowUp'].includes(event.key)){event.preventDefault();open();}});
    popup.addEventListener('keydown',event=>{
      const visible=options.filter(item=>!item.hidden),at=visible.indexOf(document.activeElement);
      if(event.key==='Escape'){event.preventDefault();event.stopPropagation();close(true);return;}
      if(event.key==='Tab'){close();return;}
      if(['ArrowDown','ArrowUp','Home','End'].includes(event.key)&&(!search||document.activeElement!==search||event.key.startsWith('Arrow'))){
        event.preventDefault();const next=event.key==='Home'?0:event.key==='End'?visible.length-1:Math.max(0,Math.min(visible.length-1,at+(event.key==='ArrowDown'?1:-1)));visible[next]?.focus({preventScroll:true});visible[next]?.scrollIntoView({block:'nearest'});
      }
      if(event.key==='Enter'&&document.activeElement===search){event.preventDefault();return;}
      if(['Enter',' '].includes(event.key)&&options.includes(document.activeElement)){event.preventDefault();document.activeElement.click();}
    });
    select.addEventListener('change',sync);sync();
  });
  document.addEventListener('click',event=>{if(opened&&!opened.wrap.contains(event.target))opened.close();});
  document.addEventListener('focusin',event=>{if(opened&&!opened.wrap.contains(event.target))opened.close();});
  window.addEventListener('pagehide',()=>opened?.close());
})();
