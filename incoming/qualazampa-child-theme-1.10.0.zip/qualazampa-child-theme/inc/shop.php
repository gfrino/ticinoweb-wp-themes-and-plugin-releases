<?php
defined('ABSPATH') || exit;
function qz_filter_id($key){return isset($_GET[$key])&&is_scalar($_GET[$key])?absint($_GET[$key]):0;}
add_filter('woocommerce_product_query_tax_query',static function($tax){
    if(is_admin())return $tax;
    foreach(['qz_brand'=>'pa_marche','qz_kind'=>'pa_tipo-prodotto','qz_animal'=>'product_cat'] as $param=>$taxonomy){
        $id=qz_filter_id($param);
        if($id&&term_exists($id,$taxonomy))$tax[]=['taxonomy'=>$taxonomy,'field'=>'term_id','terms'=>[$id]];
    }
    return $tax;
});
add_filter('woocommerce_product_query_meta_query',static function($meta){
    if(!is_admin()&&1===qz_filter_id('qz_stock'))$meta[]=['key'=>'_stock_status','value'=>'instock'];
    return $meta;
});
/** Reuse category photography and descriptions; no new editorial inputs. */
function qz_catalog_header(){
    $term=is_product_taxonomy()?get_queried_object():null;
    $departments=qz_departments();$department=null;
    if($term&&'product_cat'===$term->taxonomy&&!is_wp_error($departments)){
        $family=array_merge([$term->term_id],get_ancestors($term->term_id,'product_cat','taxonomy'));
        foreach($departments as $candidate)if(in_array($candidate->term_id,$family,true)){$department=$candidate;break;}
    }
    $photo=$department?(int)get_term_meta($department->term_id,'thumbnail_id',true):0;
    $title=woocommerce_page_title(false);
    echo '<header class="qz-catalog-hero'.($photo?' qz-catalog-hero--animal':'').(strlen(wp_strip_all_tags($title))>10?' qz-catalog-hero--long-title':'').'"><div class="qz-catalog-hero__copy"><h1>'.esc_html($title).'</h1>';
    if($department&&$department->term_id!==$term->term_id){$link=get_term_link($department);if(!is_wp_error($link))echo '<a class="qz-catalog-parent" href="'.esc_url($link).'">'.esc_html($department->name).'</a>';}
    woocommerce_taxonomy_archive_description();woocommerce_product_archive_description();
    echo '</div>';
    if($photo){echo '<div class="qz-catalog-hero__portrait" aria-hidden="true">';qz_photo($photo,'large',['alt'=>'','loading'=>'eager','fetchpriority'=>'high','sizes'=>'(max-width:760px) 130px, 300px']);echo '</div>';}
    echo '</header>';
}
add_action('after_setup_theme',static function(){
    remove_action('woocommerce_archive_description','woocommerce_taxonomy_archive_description',10);
    remove_action('woocommerce_archive_description','woocommerce_product_archive_description',10);
    add_action('woocommerce_archive_description','qz_catalog_header',10);
},110);
add_filter('woocommerce_show_page_title','__return_false');
function qz_shop_filters(){
    if(is_front_page())return;
    $action=is_product_taxonomy()?get_term_link(get_queried_object()):wc_get_page_permalink('shop');
    if(is_wp_error($action))$action=wc_get_page_permalink('shop');
    $fields=[];
    if(!is_product_category())$fields['qz_animal']=[__('Animale','qualazampa'),__('Tutti gli animali','qualazampa'),qz_departments()];
    $fields['qz_brand']=[__('Marca','qualazampa'),__('Tutte le marche','qualazampa'),get_terms(['taxonomy'=>'pa_marche','hide_empty'=>true])];
    $fields['qz_kind']=[__('Tipo di prodotto','qualazampa'),__('Tutti i tipi di prodotto','qualazampa'),get_terms(['taxonomy'=>'pa_tipo-prodotto','hide_empty'=>true])];
    echo '<form class="qz-filters" method="get" action="'.esc_url($action).'" aria-label="'.esc_attr__('Filtri prodotti','qualazampa').'">';
    foreach($fields as $param=>$field){
        $selected=qz_filter_id($param);
        echo '<div class="qz-filter-field"><label for="'.esc_attr($param).'">'.esc_html($field[0]).'</label><select id="'.esc_attr($param).'" name="'.esc_attr($param).'" data-qz-select><option value="">'.esc_html($field[1]).'</option>';
        if(!is_wp_error($field[2]))foreach($field[2] as $t)echo '<option value="'.esc_attr($t->term_id).'" '.selected($selected,$t->term_id,false).'>'.esc_html($t->name).'</option>';
        echo '</select></div>';
    }
    echo '<label class="qz-stock"><input type="checkbox" name="qz_stock" value="1" '.checked(1,qz_filter_id('qz_stock'),false).'><span>'.esc_html__('Solo disponibili','qualazampa').'</span></label><button type="submit">'.esc_html__('Filtra prodotti','qualazampa').'</button>';
    // Keep search, language and sorting when applying filters; restart at page one.
    wc_query_string_form_fields(null,['qz_animal','qz_brand','qz_kind','qz_stock','paged','product-page','submit']);
    echo '</form>';
}
add_action('woocommerce_before_shop_loop','qz_shop_filters',15);
add_action('woocommerce_no_products_found','qz_shop_filters',5);
add_filter('loop_shop_columns',static function(){return 4;});
add_filter('loop_shop_per_page',static function(){return 24;});
// Preserve the complete packshot; generated Woo thumbnails may already be cropped.
add_filter('single_product_archive_thumbnail_size',static function(){return 'large';});

// Give native WooCommerce cards a readable hierarchy without changing commerce data.
add_action('woocommerce_shop_loop_item_title',static function(){
    global $product;
    if(!$product)return;
    $brands=get_the_terms($product->get_id(),'pa_marche');
    if($brands&&!is_wp_error($brands))echo '<span class="qz-product-brand">'.esc_html($brands[0]->name).'</span>';
    else echo '<span class="qz-product-brand" aria-hidden="true">&nbsp;</span>';
},5);
add_action('after_setup_theme',static function(){
    remove_action('woocommerce_shop_loop_item_title','woocommerce_template_loop_product_title',10);
    add_action('woocommerce_shop_loop_item_title',static function(){
        global $product;
        if(!$product)return;
        echo '<h2 class="woocommerce-loop-product__title">'.esc_html(preg_replace('/\s*\[[^\]]*\]\s*$/','',$product->get_name())).'</h2>';
    },10);
},110);

// Catalogue pagination uses explicit labels instead of decorative arrows.
add_filter('woocommerce_pagination_args',static function($args){
    $args['prev_text']=esc_html__('Precedente','qualazampa');
    $args['next_text']=esc_html__('Successiva','qualazampa');
    return $args;
});
