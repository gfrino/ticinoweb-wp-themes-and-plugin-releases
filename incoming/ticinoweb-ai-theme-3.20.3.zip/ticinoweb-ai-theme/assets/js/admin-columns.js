/**
 * ticinoWEB CMS - colonne ridimensionabili nelle tabelle elenco (3.19.0).
 *
 * Trascinando il bordo destro di un'intestazione si cambia la larghezza della
 * colonna (il bordo segue il mouse: la colonna accanto si stringe dello
 * stesso tanto); doppio clic su un bordo riporta tutte le colonne a quelle automatiche. Le larghezze
 * sono salvate per schermata nel browser (localStorage), quindi valgono per
 * chi le imposta su quel computer. Solo da 783 px in su: sotto, WordPress usa
 * la tabella a schede.
 */
(function () {
  'use strict';

  var MIN = 48;

  function storageKey() {
    var p = new URLSearchParams(window.location.search);
    var parts = [window.location.pathname.split('/').pop() || 'index.php'];
    ['post_type', 'taxonomy', 'page', 'post_status'].forEach(function (k) {
      if (k !== 'post_status' && p.get(k)) {
        parts.push(k + '=' + p.get(k));
      }
    });
    return 'twaColW:' + parts.join('&');
  }

  function load(key) {
    try {
      return JSON.parse(window.localStorage.getItem(key) || '{}') || {};
    } catch (e) {
      return {};
    }
  }

  function save(key, data) {
    try {
      if (Object.keys(data).length) {
        window.localStorage.setItem(key, JSON.stringify(data));
      } else {
        window.localStorage.removeItem(key);
      }
    } catch (e) {}
  }

  function colId(th) {
    if (th.id) {
      return th.id;
    }
    var m = (th.className || '').match(/\bcolumn-([\w-]+)/);
    return m ? m[1] : null;
  }

  function setWidth(table, id, px) {
    table.querySelectorAll('thead th, thead td, tfoot th, tfoot td').forEach(function (cell) {
      if (colId(cell) === id) {
        cell.style.width = px ? px + 'px' : '';
        cell.style.boxSizing = px ? 'border-box' : '';
      }
    });
  }

  function visible(cell) {
    return cell && !cell.classList.contains('hidden') && cell.offsetWidth > 0;
  }

  function nextColumn(cells, i) {
    for (var j = i + 1; j < cells.length; j++) {
      if (visible(cells[j]) && colId(cells[j])) {
        return cells[j];
      }
    }
    return null;
  }

  // Colonna che resta automatica: quella principale di WordPress, altrimenti la piu' larga.
  function flexColumn(cells) {
    var primary = null;
    var widest = null;
    cells.forEach(function (c) {
      if (!visible(c) || c.classList.contains('check-column')) {
        return;
      }
      if (c.classList.contains('column-primary')) {
        primary = c;
      }
      if (!widest || c.offsetWidth > widest.offsetWidth) {
        widest = c;
      }
    });
    return primary || widest;
  }

  // Fissa in pixel la larghezza attuale di tutte le colonne tranne quella automatica,
  // cosi' trascinando un bordo le altre non si muovono.
  function freeze(table, cells, widths, flex) {
    cells.forEach(function (c) {
      var cid = colId(c);
      if (!cid || c === flex || !visible(c) || c.classList.contains('check-column')) {
        return;
      }
      widths[cid] = Math.round(c.getBoundingClientRect().width);
      setWidth(table, cid, widths[cid]);
    });
  }

  function setup(table) {
    var head = table.querySelector('thead tr');
    if (!head || table.dataset.twaCols) {
      return;
    }
    table.dataset.twaCols = '1';
    table.classList.add('twa-resizable');

    var key = storageKey();
    var widths = load(key);
    Object.keys(widths).forEach(function (id) {
      setWidth(table, id, widths[id]);
    });

    var cells = Array.prototype.slice.call(head.children);
    cells.forEach(function (th, i) {
      var id = colId(th);
      if (!id || th.classList.contains('check-column') || i === cells.length - 1) {
        return;
      }
      var grip = document.createElement('span');
      grip.className = 'twa-col-grip';
      grip.setAttribute('aria-hidden', 'true');
      grip.title = (window.ticinowebAdminColumns && window.ticinowebAdminColumns.hint) || '';
      th.appendChild(grip);

      grip.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
      });

      grip.addEventListener('dblclick', function (e) {
        e.preventDefault();
        e.stopPropagation();
        // Doppio clic: tutte le colonne di questa tabella tornano automatiche.
        Object.keys(widths).forEach(function (k) {
          setWidth(table, k, 0);
          delete widths[k];
        });
        save(key, widths);
      });

      grip.addEventListener('pointerdown', function (e) {
        if (e.button !== 0) {
          return;
        }
        e.preventDefault();
        e.stopPropagation();

        // Il bordo tra questa colonna e la successiva segue il mouse, come in un
        // foglio di calcolo: una si allarga, l'altra si stringe dello stesso tanto.
        // La colonna principale (Titolo) resta automatica e assorbe il resto.
        var next = nextColumn(cells, i);
        if (!next) {
          return;
        }
        var nextId = colId(next);
        var flex = flexColumn(cells);
        freeze(table, cells, widths, flex);

        var startX = e.clientX;
        var startW = th.getBoundingClientRect().width;
        var startN = next.getBoundingClientRect().width;
        var leftFlex = th === flex;
        var rightFlex = next === flex;
        document.body.classList.add('twa-col-resizing');

        function move(ev) {
          var d = ev.clientX - startX;
          if (!leftFlex && !rightFlex) {
            d = Math.max(MIN - startW, Math.min(startN - MIN, d));
          } else if (leftFlex) {
            d = Math.min(startN - MIN, d);
          } else {
            d = Math.max(MIN - startW, d);
          }
          if (!leftFlex) {
            widths[id] = Math.round(startW + d);
            setWidth(table, id, widths[id]);
          }
          if (!rightFlex) {
            widths[nextId] = Math.round(startN - d);
            setWidth(table, nextId, widths[nextId]);
          }
        }

        function up() {
          document.removeEventListener('pointermove', move);
          document.removeEventListener('pointerup', up);
          document.removeEventListener('pointercancel', up);
          document.body.classList.remove('twa-col-resizing');
          save(key, widths);
        }

        document.addEventListener('pointermove', move);
        document.addEventListener('pointerup', up);
        document.addEventListener('pointercancel', up);
      });
    });
  }

  function run() {
    if (!window.matchMedia('(min-width: 783px)').matches) {
      return;
    }
    document.querySelectorAll('table.wp-list-table').forEach(setup);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run);
  } else {
    run();
  }
})();
