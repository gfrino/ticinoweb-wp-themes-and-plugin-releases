<?php

class Ticino_AI_Booking_Caldav_Client {

    private $url;
    private $user;
    private $pass;
    private $calendar_id;

    public function __construct() {
        $this->url = rtrim(get_option('ticino_ai_caldav_url', 'https://caldav.icloud.com'), '/');
        $this->user = get_option('ticino_ai_caldav_user');
        $this->pass = get_option('ticino_ai_caldav_pass');
        $this->calendar_id = get_option('ticino_ai_caldav_calendar_id');
    }

    public function create_event($appointment) {
        if (empty($this->user) || empty($this->pass) || empty($this->calendar_id)) {
            return new WP_Error('caldav_config', 'Credenziali CalDAV mancanti.');
        }

        $uid = wp_generate_uuid4();
        $event_url = $this->url . $this->calendar_id . '/' . $uid . '.ics';
        // iCloud typically uses https://caldav.icloud.com/{dsid}/calendars/{calendar_name}/

        $start_dt = new DateTime($appointment['requested_date'] . ' ' . $appointment['requested_time_slot'], new DateTimeZone('Europe/Zurich'));
        $start_dt->setTimezone(new DateTimeZone('UTC'));
        
        // Assume default 1 hour duration
        $end_dt = clone $start_dt;
        $end_dt->modify('+1 hour');

        $dtstart = $start_dt->format('Ymd\THis\Z');
        $dtend = $end_dt->format('Ymd\THis\Z');
        $dtstamp = gmdate('Ymd\THis\Z');

        $summary = "Appuntamento - " . $appointment['customer_first_name'] . " " . $appointment['customer_last_name'] . " - " . $appointment['requested_service'];
        
        $description = "Richiesta tramite AI Booking Assistant.\\n";
        $description .= "Cliente: " . $appointment['customer_first_name'] . " " . $appointment['customer_last_name'] . "\\n";
        $description .= "Email: " . $appointment['customer_email'] . "\\n";
        $description .= "Telefono: " . $appointment['customer_phone'] . "\\n";
        $description .= "Servizio: " . $appointment['requested_service'] . "\\n";
        $description .= "Note: " . str_replace(array("\r", "\n"), "\\n", $appointment['notes']) . "\\n";
        $description .= "Admin Note: " . str_replace(array("\r", "\n"), "\\n", $appointment['admin_notes']);

        $location = get_option('ticino_ai_company_address') ?: get_option('ticino_ai_company_name', get_bloginfo('name'));

        $ics = "BEGIN:VCALENDAR\r\n";
        $ics .= "VERSION:2.0\r\n";
        $ics .= "PRODID:-//ticinoWEB//AI Booking Assistant//IT\r\n";
        $ics .= "BEGIN:VEVENT\r\n";
        $ics .= "UID:" . $uid . "\r\n";
        $ics .= "DTSTAMP:" . $dtstamp . "\r\n";
        $ics .= "DTSTART:" . $dtstart . "\r\n";
        $ics .= "DTEND:" . $dtend . "\r\n";
        $ics .= "SUMMARY:" . $summary . "\r\n";
        $ics .= "DESCRIPTION:" . $description . "\r\n";
        $ics .= "LOCATION:" . $location . "\r\n";
        $ics .= "END:VEVENT\r\n";
        $ics .= "END:VCALENDAR\r\n";

        $response = wp_remote_request($event_url, array(
            'method' => 'PUT',
            'headers' => array(
                'Authorization' => 'Basic ' . base64_encode($this->user . ':' . $this->pass),
                'Content-Type' => 'text/calendar; charset=utf-8'
            ),
            'body' => $ics,
            'timeout' => 30
        ));

        if (is_wp_error($response)) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code($response);
        if ($code >= 200 && $code < 300) {
            return $uid; // Success
        }

        return new WP_Error('caldav_error', 'Errore CalDAV HTTP ' . $code . ': ' . wp_remote_retrieve_body($response));
    }
}
