<?php

class Ticino_AI_Booking_Chatbot {

    private $plugin_name;
    private $version;

    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
    }

    /**
     * Modalita' di funzionamento (opzione `ticino_ai_mode`, per sito):
     * - 'booking' (default): richieste di appuntamento con giorno e fascia oraria,
     *   conferma/annullamento dall'admin, sync Apple Calendar;
     * - 'lead': generazione contatti. Il form raccoglie nome, telefono, email,
     *   esigenza e note, senza data; le richieste si gestiscono come contatti da
     *   richiamare ("Segna come contattata").
     */
    public static function get_mode() {
        return get_option('ticino_ai_mode', 'booking') === 'lead' ? 'lead' : 'booking';
    }

    public static function is_lead_mode() {
        return self::get_mode() === 'lead';
    }

    /** Sanitize per register_setting di `ticino_ai_mode`. */
    public static function sanitize_mode($value) {
        return $value === 'lead' ? 'lead' : 'booking';
    }

    /** Nome azienda dalle impostazioni, con fallback al nome del sito. */
    /**
     * Immagine accanto al nome dell'assistente: il logo scelto nelle Impostazioni,
     * altrimenti l'icona del sito (Aspetto > Personalizza > Identita' del sito).
     * Stringa vuota = icona generica del plugin.
     */
    public static function bot_logo_url() {
        $id  = absint(get_option('ticino_ai_bot_logo', 0));
        $url = $id ? wp_get_attachment_image_url($id, 'thumbnail') : '';
        return $url ? $url : (string) get_site_icon_url(96);
    }

    public static function company_name() {
        $name = get_option('ticino_ai_company_name');
        return !empty($name) ? $name : get_bloginfo('name');
    }

    /** Azioni possibili di un bottone rapido. */
    public static function quick_reply_actions() {
        return array(
            'ai'      => "Invia all'AI",
            'booking' => self::is_lead_mode() ? 'Avvia il form di contatto' : 'Avvia il form di prenotazione',
            'reply'   => 'Risposta fissa (senza AI)',
            'link'    => 'Apri un link',
        );
    }

    /** Messaggio di benvenuto di default, in base alla modalita'. */
    public static function default_greeting() {
        $name = self::company_name();
        if (self::is_lead_mode()) {
            return sprintf("Ciao, sono l'assistente virtuale di %s. Posso darti informazioni sull'azienda, i suoi prodotti e servizi e i contatti, oppure raccogliere la tua richiesta di informazioni o di preventivo.", $name);
        }
        return sprintf("Ciao, sono l'assistente virtuale di %s. Posso darti informazioni su servizi, orari e contatti, oppure raccogliere una richiesta di appuntamento.", $name);
    }

    public static function default_booking_intro() {
        $name = self::company_name();
        if (self::is_lead_mode()) {
            return "Volentieri! Raccolgo la tua richiesta e il team di {$name} ti ricontatterà al più presto. Ti farò alcune brevi domande.\n\nCome ti chiami (Nome e Cognome)?";
        }
        return "Certamente! Posso raccogliere la tua richiesta di appuntamento. Ti farò alcune brevi domande e {$name} ti ricontatterà per confermare giorno e orario.\n\nCome ti chiami (Nome e Cognome)?";
    }

    /** Messaggio mostrato in chat dopo l'invio riuscito del form (configurabile, `ticino_ai_booking_success`). */
    public static function default_success_message() {
        if (self::is_lead_mode()) {
            return sprintf("Grazie, la tua richiesta è stata inviata correttamente. Il team di %s ti ricontatterà al più presto ai recapiti che hai indicato.", self::company_name());
        }
        return "Grazie, la tua richiesta è stata inviata correttamente. Ti ricontatteremo per confermare giorno e orario.\n\n📌 **Avviso importante:**\nGentili clienti vi rammentiamo che è necessario disdire o spostare un appuntamento 24 ore prima dello stesso. In caso contrario il corrispondente del trattamento prenotato vi verrà fatturato. È possibile avvisarci in qualunque momento telefonando o inviando un messaggio. Vi ringraziamo già sin da ora per la vostra collaborazione.";
    }

    public static function get_success_message() {
        $msg = get_option('ticino_ai_booking_success', '');
        return trim((string) $msg) !== '' ? $msg : self::default_success_message();
    }

    /** Messaggio introduttivo del form di prenotazione (configurabile). */
    public static function get_booking_intro() {
        $intro = get_option('ticino_ai_booking_intro', '');
        return trim((string) $intro) !== '' ? $intro : self::default_booking_intro();
    }

    /**
     * Registro errori leggero, consultabile in Dashboard senza WP_DEBUG:
     * ultimi 30 eventi nell'opzione `ticino_ai_error_log` + riga in error_log().
     */
    public static function log_error($message) {
        $message = mb_substr((string) $message, 0, 500);
        error_log('[AI WEB Agent] ' . $message);
        $log = get_option('ticino_ai_error_log', array());
        if (!is_array($log)) $log = array();
        array_unshift($log, array('t' => current_time('mysql'), 'm' => $message));
        update_option('ticino_ai_error_log', array_slice($log, 0, 30), false);
    }

    public static function get_error_log() {
        $log = get_option('ticino_ai_error_log', array());
        return is_array($log) ? $log : array();
    }

    /** Bottoni rapidi mostrati sotto la chat in stato "normale" (default storici). */
    public static function default_quick_replies() {
        if (self::is_lead_mode()) {
            return array(
                array('label' => 'Richiedi informazioni o un preventivo', 'value' => 'Vorrei informazioni',   'action' => 'booking', 'reply' => '', 'url' => '', 'enabled' => true),
                array('label' => 'Di cosa vi occupate?',                  'value' => 'Di cosa vi occupate?',  'action' => 'ai',      'reply' => '', 'url' => '', 'enabled' => true),
                array('label' => 'Dove siete e contatti',                 'value' => 'Dove siete e come posso contattarvi?', 'action' => 'ai', 'reply' => '', 'url' => '', 'enabled' => true),
            );
        }
        return array(
            array('label' => 'Vorrei prenotare un appuntamento', 'value' => 'Vorrei prenotare',      'action' => 'booking', 'reply' => '', 'url' => '', 'enabled' => true),
            array('label' => 'Quali servizi offrite?',           'value' => 'Quali servizi offrite?', 'action' => 'ai',    'reply' => '', 'url' => '', 'enabled' => true),
            array('label' => 'Orari e contatti',                 'value' => 'Orari e contatti',     'action' => 'ai',      'reply' => '', 'url' => '', 'enabled' => true),
        );
    }

    /**
     * Bottoni rapidi configurati (tutti, anche disattivati) per il pannello admin.
     * @return array<int, array{label:string, value:string, enabled:bool}>
     */
    public static function get_quick_replies() {
        $stored = get_option('ticino_ai_quick_replies', null);
        if ($stored === null || $stored === '') {
            return self::default_quick_replies();
        }
        $list = is_array($stored) ? $stored : json_decode($stored, true);
        return self::sanitize_quick_replies($list, false);
    }

    /** Solo i bottoni attivi, come arrivano al frontend; vuoto se la funzione e' disattivata. */
    public static function get_active_quick_replies() {
        if (get_option('ticino_ai_quick_replies_enabled', 'yes') === 'no') {
            return array();
        }
        $out = array();
        foreach (self::get_quick_replies() as $qr) {
            if (!empty($qr['enabled'])) {
                $out[] = array(
                    'label'  => $qr['label'],
                    'value'  => $qr['value'],
                    'action' => $qr['action'],
                    'reply'  => $qr['reply'],
                    'url'    => $qr['url'],
                );
            }
        }
        return $out;
    }

    /**
     * Sanitize per register_setting: accetta l'array del form (o JSON) e salva JSON.
     * @param mixed $input
     * @param bool  $as_json true -> stringa JSON per l'opzione, false -> array normalizzato
     */
    public static function sanitize_quick_replies($input, $as_json = true) {
        if (is_string($input)) {
            $decoded = json_decode(wp_unslash($input), true);
            $input = is_array($decoded) ? $decoded : array();
        }
        $clean = array();
        if (is_array($input)) {
            foreach ($input as $row) {
                if (!is_array($row)) {
                    continue;
                }
                $label = isset($row['label']) ? sanitize_text_field(wp_unslash($row['label'])) : '';
                if ($label === '') {
                    continue;
                }
                $value  = isset($row['value']) ? sanitize_text_field(wp_unslash($row['value'])) : '';
                $action = isset($row['action']) ? sanitize_key($row['action']) : 'ai';
                if (!array_key_exists($action, self::quick_reply_actions())) {
                    $action = 'ai';
                }
                $reply = isset($row['reply']) ? sanitize_textarea_field(wp_unslash($row['reply'])) : '';
                $url   = isset($row['url']) ? esc_url_raw(trim(wp_unslash($row['url']))) : '';
                if ($action === 'reply' && $reply === '') {
                    $action = 'ai'; // risposta fissa vuota: degrada a invio all'AI
                }
                if ($action === 'link' && $url === '') {
                    $action = 'ai';
                }
                $clean[] = array(
                    'label'   => mb_substr($label, 0, 60),
                    'value'   => mb_substr($value !== '' ? $value : $label, 0, 200),
                    'action'  => $action,
                    'reply'   => mb_substr($reply, 0, 1000),
                    'url'     => $url,
                    'enabled' => !empty($row['enabled']),
                );
                if (count($clean) >= 8) {
                    break;
                }
            }
        }
        return $as_json ? wp_json_encode($clean, JSON_UNESCAPED_UNICODE) : $clean;
    }

    public function enqueue_styles() {
        wp_enqueue_style($this->plugin_name . '-chatbot', TICINO_AI_BOOKING_PLUGIN_URL . 'assets/css/frontend-chatbot.css', array(), filemtime(TICINO_AI_BOOKING_PLUGIN_DIR . 'assets/css/frontend-chatbot.css'), 'all');
        
        // Colori custom inline
        $main_color = get_option('ticino_ai_bot_color_main', '#1a1a1a');
        $accent_color = get_option('ticino_ai_bot_color_accent', '#cebdad');
        $custom_css = "
            :root {
                --ticino-ai-main: {$main_color};
                --ticino-ai-accent: {$accent_color};
            }
        ";
        wp_add_inline_style($this->plugin_name . '-chatbot', $custom_css);
    }

    public function enqueue_scripts() {
        wp_enqueue_script($this->plugin_name . '-chatbot', TICINO_AI_BOOKING_PLUGIN_URL . 'assets/js/frontend-chatbot.js', array('jquery'), filemtime(TICINO_AI_BOOKING_PLUGIN_DIR . 'assets/js/frontend-chatbot.js'), true);

        $bot_name = get_option('ticino_ai_bot_name');
        if (empty($bot_name)) {
            $bot_name = 'Assistente virtuale';
        }
        $greeting = get_option('ticino_ai_bot_greeting');
        if (empty($greeting)) {
            $greeting = self::default_greeting();
        }

        wp_localize_script($this->plugin_name . '-chatbot', 'ticino_ai_chatbot', array(
            'rest_url'  => esc_url_raw(rest_url('ticino-ai-booking/v1/')),
            'nonce'     => wp_create_nonce('wp_rest'),
            'mode'      => self::get_mode(),
            'company_name' => self::company_name(),
            'bot_name'  => $bot_name,
            'greeting'  => $greeting,
            'quick_replies' => self::get_active_quick_replies(),
            'booking_intro' => self::get_booking_intro(),
            'success_message' => self::get_success_message(),
            'services'  => json_decode(get_option('ticino_ai_kb_services', '[]'), true)
        ));
    }

    public function render_chatbot_html() {
        $auto_show = get_option('ticino_ai_auto_show');
        if ($auto_show !== 'no') {
            require_once TICINO_AI_BOOKING_PLUGIN_DIR . 'templates/chatbot-widget.php';
        }
    }

    public function shortcode_render_chatbot() {
        ob_start();
        require TICINO_AI_BOOKING_PLUGIN_DIR . 'templates/chatbot-widget.php';
        return ob_get_clean();
    }

    public function register_rest_routes() {
        register_rest_route('ticino-ai-booking/v1', '/chat', array(
            'methods'  => 'POST',
            'callback' => array($this, 'rest_handle_chat'),
            'permission_callback' => function () {
                return is_user_logged_in() || true; // Nonce is checked by default in WP REST for logged in users, but we allow public. Let's rely on nonce for public too.
            }
        ));

        register_rest_route('ticino-ai-booking/v1', '/appointment', array(
            'methods'  => 'POST',
            'callback' => array($this, 'rest_handle_appointment'),
            'permission_callback' => '__return_true'
        ));
    }

    public function rest_handle_chat(WP_REST_Request $request) {
        $messages = $request->get_json_params();
        if (empty($messages) || !isset($messages['messages'])) {
            $messages = $request->get_param('messages');
        } else {
            $messages = $messages['messages'];
        }
        
        if (!is_array($messages) || empty($messages)) {
            $err = array('success' => false, 'error' => 'Messaggi non validi.', 'code' => 'invalid_data');
            return new WP_REST_Response($err, 400);
        }

        // Init AI client (provider Gemini/OpenAI scelto nelle impostazioni)
        $gemini = new Ticino_AI_Booking_Gemini_Client();
        $page_lang = $request->get_param('lang');
        $response = $gemini->generate_response($messages, is_string($page_lang) ? $page_lang : '');

        if ( defined('WP_DEBUG') && WP_DEBUG ) {
            error_log('AI Booking Chat Debug - Intent rilevato: ' . $gemini->last_intent);
            if ($gemini->used_fallback) {
                error_log('AI Booking Chat Debug - API ' . $gemini->get_provider_label() . ' fallita (' . $gemini->gemini_error . '). Fallback locale utilizzato.');
            } else {
                error_log('AI Booking Chat Debug - Risposta API ' . $gemini->get_provider_label() . ' generata con successo.');
            }
        }

        if (is_wp_error($response)) {
            // Non deve mai arrivare qui (il fallback locale risponde sempre), ma se succede il visitatore
            // riceve comunque una risposta utile e l'errore finisce nel registro della Dashboard.
            self::log_error('Risposta non disponibile (' . $response->get_error_code() . '): ' . $response->get_error_message());
            $company  = self::company_name();
            $response = "In questo momento non riesco a rispondere. Posso raccogliere una richiesta di contatto: scrivi \"Vorrei prenotare\" e ti faccio alcune brevi domande, oppure contatta direttamente " . $company . ".";
            return new WP_REST_Response(array('success' => true, 'message' => $response, 'source' => 'error'), 200);
        }

        return new WP_REST_Response(array(
            'success' => true,
            'message' => $response,
            'source'  => $gemini->used_fallback ? 'fallback' : 'ai',
            'ms'      => $gemini->last_latency_ms,
        ), 200);
    }

    public function rest_handle_appointment(WP_REST_Request $request) {
        global $wpdb;
        $table = $wpdb->prefix . 'ticino_ai_appointments';

        $first_name = sanitize_text_field($request->get_param('first_name'));
        $last_name = sanitize_text_field($request->get_param('last_name'));
        $email = sanitize_email($request->get_param('email'));
        $phone = sanitize_text_field($request->get_param('phone'));
        $service = sanitize_text_field($request->get_param('service'));
        $date = sanitize_text_field($request->get_param('date'));
        $time = sanitize_text_field($request->get_param('time'));
        $notes = sanitize_textarea_field($request->get_param('notes'));
        $privacy = rest_sanitize_boolean($request->get_param('privacy'));

        if (!$privacy) {
            return new WP_Error('privacy_required', 'Il consenso alla privacy è obbligatorio.', array('status' => 400));
        }
        if (!is_email($email)) {
            return new WP_Error('invalid_email', 'Email non valida.', array('status' => 400));
        }

        $inserted = $wpdb->insert(
            $table,
            array(
                'status' => 'nuova',
                'customer_first_name' => $first_name,
                'customer_last_name' => $last_name,
                'customer_email' => $email,
                'customer_phone' => $phone,
                'requested_service' => $service,
                'requested_date' => $date,
                'requested_time_slot' => $time,
                'notes' => $notes,
                'privacy_consent' => 1
            )
        );

        if (!$inserted) {
            return new WP_Error('db_error', 'Impossibile salvare la richiesta.', array('status' => 500));
        }

        $appointment_id = $wpdb->insert_id;

        // Invia Email (se classe Email esiste)
        if (class_exists('Ticino_AI_Booking_Email')) {
            $mailer = new Ticino_AI_Booking_Email();
            $full_name = $first_name . ' ' . $last_name;
            $mailer->send_customer_request_received($appointment_id, $email, $full_name, $service);
            $mailer->send_admin_new_request_notification($appointment_id, $full_name, $service, $date, $time, $notes, array('email' => $email, 'phone' => $phone));
        }

        return rest_ensure_response(array('success' => true, 'message' => 'Richiesta ricevuta con successo.'));
    }

}
