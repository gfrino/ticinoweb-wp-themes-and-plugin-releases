<?php
/**
 * Documenti PDF nella Knowledge Base (1.4.0).
 *
 * L'amministratore sceglie un PDF dalla libreria media (o lo carica da li').
 * Il testo viene estratto UNA volta (libreria smalot/pdfparser, inclusa in
 * lib/pdfparser, LGPL-3.0), diviso in pezzi di circa 1200 caratteri pagina per
 * pagina e salvato nella tabella {prefix}ticino_ai_kb_chunks del sito corrente.
 * Se il provider AI ha una chiave, ogni pezzo riceve anche un embedding
 * (Gemini o OpenAI) per la ricerca semantica, che funziona anche quando la
 * domanda e' in una lingua diversa da quella del PDF.
 *
 * A ogni domanda: se tutti i documenti insieme sono corti entrano interi nel
 * prompt (nessuna chiamata extra); altrimenti si scelgono i pezzi piu'
 * pertinenti (embedding se disponibili, altrimenti parole chiave). Ogni pezzo
 * porta nome del documento e pagina, cosi' l'AI puo' citare la fonte.
 *
 * Dalla 1.5.0 tutti i PDF della libreria media entrano da soli (cron di
 * WordPress, piu' l'avanzamento dal vivo con la pagina Knowledge Base aperta);
 * quelli tolti a mano non vengono rimessi, quelli non leggibili non si riprovano.
 *
 * Dalla 1.6.0 ogni PDF viene anche giudicato "ancora attuale" o no: scadenza
 * dichiarata e passata, nome da archivio (xxx_, old…), versione superata da
 * una piu' recente dello stesso documento, evento o offerta conclusi. Il
 * giudizio lo da' l'AI del sito (se c'e' la chiave) piu' regole fisse su nomi e
 * date; i PDF non attuali restano in elenco ma l'assistente non li usa, salvo
 * «Usa comunque». Ogni giorno si ricontrollano le scadenze.
 *
 * @package Ticino_AI_Booking
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Ticino_AI_Booking_PDF_Knowledge {

    const DB_VERSION        = '3'; // 2 = 1.6.0: giudizio "ancora attuale"; 3 = 1.6.1: nuovo giudizio con le istruzioni corrette
    const DB_VERSION_OPTION = 'ticino_ai_pdf_db_version';
    const DOCS_OPTION       = 'ticino_ai_kb_documents';
    const TABLE             = 'ticino_ai_kb_chunks';
    const AUTO_OPTION       = 'ticino_ai_pdf_auto';       // '1' = tutti i PDF della libreria media, da soli
    const SYNC_OPTION       = 'ticino_ai_pdf_sync_state'; // PDF non leggibili e tolti a mano
    const CRON_HOOK         = 'ticino_ai_pdf_sync';
    const LOCK_TRANSIENT    = 'ticino_ai_pdf_sync_lock';
    const CHECK_TRANSIENT   = 'ticino_ai_pdf_sync_checked';
    const DAILY_HOOK        = 'ticino_ai_pdf_daily';       // ricontrollo delle scadenze (1.6.0)
    const REVIEW_OPTION     = 'ticino_ai_pdf_review_due';  // '1' = confrontare le versioni dei PDF

    const CHUNK_CHARS   = 1200;  // lunghezza indicativa di un pezzo
    const CHUNK_OVERLAP = 150;   // sovrapposizione fra pezzi consecutivi della stessa pagina
    const FULL_BUDGET   = 16000; // sotto questa soglia (tutti i documenti) il testo va intero nel prompt
    const SEARCH_BUDGET = 9000;  // caratteri di pezzi pertinenti passati al modello per domanda
    const MAX_DOC_CHARS = 600000;
    const MAX_CHUNKS    = 2000;  // tetto per sito: tiene leggera la ricerca a ogni domanda
    const MIN_TEXT      = 80;    // meno di cosi' = PDF senza testo (scansione)
    const EMBED_DIMS    = 768;

    /** Limite di dimensione del file, modificabile con il filtro `ticino_ai_pdf_max_bytes`. */
    public static function max_bytes() {
        return (int) apply_filters('ticino_ai_pdf_max_bytes', 20 * MB_IN_BYTES);
    }

    public static function table() {
        global $wpdb;
        return $wpdb->prefix . self::TABLE;
    }

    /**
     * Crea/aggiorna la tabella del sito corrente. Gira all'attivazione e, per i
     * siti gia' attivi o attivati in rete, al primo caricamento dopo l'aggiornamento.
     */
    public static function install() {
        global $wpdb;
        $table = self::table();
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE $table (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            attachment_id bigint(20) unsigned NOT NULL,
            chunk_index int(11) unsigned NOT NULL,
            page int(11) unsigned NOT NULL DEFAULT 0,
            content mediumtext NOT NULL,
            embedding mediumtext NULL,
            PRIMARY KEY  (id),
            KEY attachment_id (attachment_id)
        ) $charset_collate;";
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
        update_option(self::DB_VERSION_OPTION, self::DB_VERSION, true);
    }

    public static function maybe_upgrade() {
        if (get_option(self::DB_VERSION_OPTION) !== self::DB_VERSION) {
            self::install();
            // Giudizio da rifare (1.6.1): l'1.6.0 scambiava per scadenze i periodi dei rapporti.
            // «Usa comunque» scelto a mano resta.
            $docs = self::get_documents();
            foreach ($docs as &$d) {
                unset($d['assessed']);
                if (($d['outdated_by'] ?? '') !== '') {
                    $d['outdated'] = false;
                    $d['outdated_by'] = '';
                    $d['outdated_reason'] = '';
                }
            }
            unset($d);
            self::save_documents($docs);
            self::schedule_sync(30); // giudica subito i PDF gia' in Knowledge Base
        }
    }

    /** @return array<int, array> documenti indicizzati, chiave = ID allegato */
    public static function get_documents() {
        $docs = get_option(self::DOCS_OPTION, array());
        return is_array($docs) ? $docs : array();
    }

    private static function save_documents($docs) {
        // Non autoload: serve solo nella pagina Knowledge Base e nelle risposte del chatbot
        update_option(self::DOCS_OPTION, $docs, false);
    }

    /* ------------------------------------------------------------------ */
    /*  AJAX (Knowledge Base)                                              */
    /* ------------------------------------------------------------------ */

    private static function check_request() {
        check_ajax_referer('ticino_ai_admin_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Non hai i permessi per modificare la Knowledge Base.', 'ticino-ai-booking')), 403);
        }
        return isset($_POST['attachment_id']) ? absint($_POST['attachment_id']) : 0;
    }

    /** Aggiunge (o rilegge) un PDF della libreria media. */
    public function ajax_add() {
        $attachment_id = self::check_request();
        $result = self::index_attachment($attachment_id);
        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()));
        }
        self::forget_sync_state($attachment_id);
        wp_send_json_success(array(
            'document' => self::document_for_js($attachment_id, $result),
            'message'  => sprintf(
                /* translators: 1: nome del documento, 2: numero di pagine */
                _n('«%1$s» è stato letto: %2$d pagina. L\'assistente ora può usarlo per rispondere.', '«%1$s» è stato letto: %2$d pagine. L\'assistente ora può usarlo per rispondere.', (int) $result['pages'], 'ticino-ai-booking'),
                $result['title'], $result['pages']
            ),
            'summary'  => self::summary(),
        ));
    }

    /** Toglie un PDF dalla Knowledge Base (il file resta nella libreria media). */
    public function ajax_remove() {
        $attachment_id = self::check_request();
        $docs = self::get_documents();
        $title = isset($docs[$attachment_id]['title']) ? $docs[$attachment_id]['title'] : '';
        self::remove_document($attachment_id);
        // Tolto a mano: la sincronizzazione automatica non lo rimette
        $state = self::get_sync_state();
        $state['excluded'][$attachment_id] = true;
        self::save_sync_state($state);
        wp_send_json_success(array(
            'message' => sprintf(
                /* translators: %s: nome del documento */
                __('«%s» è stato tolto dalla Knowledge Base. Il file resta nella libreria media.', 'ticino-ai-booking'),
                $title
            ),
            'summary' => self::summary(),
            'status'  => self::sync_status(),
        ));
    }

    /** Anteprima: quali passaggi userebbe l'assistente per una domanda. */
    public function ajax_search() {
        check_ajax_referer('ticino_ai_admin_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Non hai i permessi per modificare la Knowledge Base.', 'ticino-ai-booking')), 403);
        }
        $q = isset($_POST['q']) ? sanitize_text_field(wp_unslash($_POST['q'])) : '';
        if ($q === '') {
            wp_send_json_error(array('message' => __('Scrivi una domanda da provare.', 'ticino-ai-booking')));
        }
        $found = self::search($q, 3, true);
        $out = array();
        foreach ($found['chunks'] as $c) {
            $out[] = array(
                'title' => $c['title'],
                'page'  => (int) $c['page'],
                'text'  => mb_substr($c['content'], 0, 420) . (mb_strlen($c['content']) > 420 ? '…' : ''),
            );
        }
        wp_send_json_success(array('results' => $out, 'method' => $found['method']));
    }

    /** Un allegato cancellato dalla libreria media esce anche dalla Knowledge Base. */
    public static function on_delete_attachment($post_id) {
        $docs = self::get_documents();
        if (isset($docs[(int) $post_id])) {
            self::remove_document((int) $post_id);
        }
        self::forget_sync_state($post_id);
    }

    public static function remove_document($attachment_id) {
        global $wpdb;
        $wpdb->delete(self::table(), array('attachment_id' => (int) $attachment_id), array('%d'));
        $docs = self::get_documents();
        unset($docs[(int) $attachment_id]);
        self::save_documents($docs);
        update_option(self::REVIEW_OPTION, '1', false); // una versione superata puo' tornare attuale
        self::schedule_sync(30);
    }

    /* ------------------------------------------------------------------ */
    /*  Sincronizzazione automatica con la libreria media (1.5.0)          */
    /* ------------------------------------------------------------------ */

    /** true = ogni PDF della libreria media entra da solo nella Knowledge Base. */
    public static function auto_enabled() {
        return get_option(self::AUTO_OPTION, '1') === '1';
    }

    /**
     * Stato della sincronizzazione: PDF non leggibili (non si riprovano da soli)
     * e PDF tolti a mano (la sincronizzazione non li rimette).
     *
     * @return array{skipped: array<int, array>, excluded: array<int, bool>}
     */
    private static function get_sync_state() {
        $s = get_option(self::SYNC_OPTION, array());
        $s = is_array($s) ? $s : array();
        return array(
            'skipped'  => isset($s['skipped']) && is_array($s['skipped']) ? $s['skipped'] : array(),
            'excluded' => isset($s['excluded']) && is_array($s['excluded']) ? $s['excluded'] : array(),
        );
    }

    private static function save_sync_state($state) {
        update_option(self::SYNC_OPTION, $state, false);
    }

    /** Toglie un allegato dalle liste "non leggibile" e "tolto a mano". */
    private static function forget_sync_state($attachment_id) {
        $state = self::get_sync_state();
        unset($state['skipped'][(int) $attachment_id], $state['excluded'][(int) $attachment_id]);
        self::save_sync_state($state);
    }

    /**
     * ID dei PDF della libreria media, i piu' recenti prima, uno per file:
     * WPML (traduzione dei media) crea un allegato per lingua sullo stesso file.
     *
     * @return array<int, string> ID allegato => percorso relativo del file
     */
    private static function library_pdfs() {
        global $wpdb;
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT MIN(p.ID) AS id, m.meta_value AS file FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = '_wp_attached_file'
             WHERE p.post_type = 'attachment' AND p.post_mime_type = %s AND p.post_status = 'inherit'
             GROUP BY m.meta_value ORDER BY id DESC",
            'application/pdf'
        ));
        $out = array();
        foreach ($rows as $r) {
            $out[(int) $r->id] = (string) $r->file;
        }
        return $out;
    }

    private static function library_pdf_ids() {
        return array_keys(self::library_pdfs());
    }

    /** @return int[] PDF della libreria che la sincronizzazione deve ancora leggere */
    private static function pending_ids() {
        $docs  = self::get_documents();
        $state = self::get_sync_state();
        // File gia' letti con un altro allegato (es. aggiunto a mano dalla copia di un'altra lingua)
        $indexed_files = array();
        foreach (array_keys($docs) as $doc_id) {
            $indexed_files[(string) get_post_meta($doc_id, '_wp_attached_file', true)] = true;
        }
        $pending = array();
        foreach (self::library_pdfs() as $id => $file) {
            if (!isset($docs[$id]) && !isset($indexed_files[$file]) && !isset($state['skipped'][$id]) && !isset($state['excluded'][$id])) {
                $pending[] = $id;
            }
        }
        return $pending;
    }

    /**
     * Legge i PDF in attesa finche' resta tempo. Gira dal cron di WordPress e,
     * con la pagina Knowledge Base aperta, dalla pagina stessa (avanzamento dal vivo
     * anche dove il cron gira poco).
     *
     * @return array{added: array, skipped: array} documenti letti e non leggibili in questo giro
     */
    public static function sync_step($seconds) {
        $out = array('added' => array(), 'skipped' => array(), 'changed' => false);
        if (get_transient(self::LOCK_TRANSIENT)) {
            return $out;
        }
        set_transient(self::LOCK_TRANSIENT, 1, 2 * MINUTE_IN_SECONDS);
        $start = microtime(true);
        foreach (self::auto_enabled() ? self::pending_ids() : array() as $id) {
            // Nel frattempo potrebbe averlo aggiunto qualcuno a mano
            wp_cache_delete(self::DOCS_OPTION, 'options');
            if (isset(self::get_documents()[$id])) {
                continue;
            }
            $result = self::index_attachment($id);
            if (is_wp_error($result)) {
                $state = self::get_sync_state();
                $state['skipped'][$id] = array(
                    'title'  => trim(wp_strip_all_tags(get_the_title($id))) ?: wp_basename((string) get_attached_file($id)),
                    'reason' => $result->get_error_message(),
                );
                self::save_sync_state($state);
                $out['skipped'][$id] = $state['skipped'][$id];
                if ($result->get_error_code() === 'too_much') {
                    break; // limite di testo raggiunto: inutile provare gli altri
                }
            } else {
                $out['added'][$id] = $result;
            }
            if (microtime(true) - $start > $seconds) {
                break;
            }
        }
        // Poi: giudizio sui PDF letti prima della 1.6.0, infine il confronto fra versioni
        if (microtime(true) - $start <= $seconds && !(self::auto_enabled() && self::pending_ids())) {
            $out['changed'] = self::relevance_step($start, $seconds);
        }
        delete_transient(self::LOCK_TRANSIENT);
        return $out;
    }

    /** Cron: un giro, poi si riprogramma finche' restano PDF da leggere. */
    public static function cron_sync() {
        self::sync_step(25);
        self::schedule_sync(60);
    }

    public static function schedule_sync($delay = 10) {
        if (!wp_next_scheduled(self::CRON_HOOK) && ((self::auto_enabled() && self::pending_ids()) || self::relevance_work())) {
            wp_schedule_single_event(time() + $delay, self::CRON_HOOK);
        }
    }

    /** Un PDF appena caricato nella libreria media entra da solo nella Knowledge Base. */
    public static function on_add_attachment($post_id) {
        if (get_post_mime_type($post_id) === 'application/pdf') {
            self::schedule_sync(5);
        }
    }

    /**
     * In bacheca, al massimo due volte al giorno: recupera i PDF arrivati senza
     * passare dal caricamento (prima installazione della 1.5.0, import, migrazioni).
     */
    public static function maybe_schedule_sync() {
        if (self::auto_enabled() && !get_transient(self::CHECK_TRANSIENT)) {
            set_transient(self::CHECK_TRANSIENT, 1, 12 * HOUR_IN_SECONDS);
            self::schedule_sync();
        }
    }

    /* ------------------------------------------------------------------ */
    /*  PDF ancora attuali? (1.6.0)                                        */
    /* ------------------------------------------------------------------ */

    /** true = l'assistente usa il documento. */
    public static function is_active($doc) {
        return empty($doc['outdated']) || ($doc['override'] ?? '') === 'use';
    }

    /** Lavoro rimasto: PDF mai giudicati o confronto fra versioni da fare. */
    private static function relevance_work() {
        foreach (self::get_documents() as $d) {
            if (!isset($d['assessed'])) return true;
        }
        return get_option(self::REVIEW_OPTION) === '1' && count(self::get_documents()) > 1;
    }

    /**
     * Data scritta in un testo, formati europei e ISO, anche compatta nei nomi
     * dei file (19072022). @return string AAAA-MM-GG o ''
     */
    private static function parse_date($str) {
        $str = trim((string) $str);
        if (preg_match('/^(\d{4})-(\d{1,2})-(\d{1,2})$/', $str, $m)) {
            list(, $y, $mo, $d) = $m;
        } elseif (preg_match('/^(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{4})$/', $str, $m)) {
            list(, $d, $mo, $y) = $m;
        } elseif (preg_match('/^(\d{2})(\d{2})(\d{4})$/', $str, $m)) {
            list(, $d, $mo, $y) = $m;
        } else {
            return '';
        }
        return checkdate((int) $mo, (int) $d, (int) $y) ? sprintf('%04d-%02d-%02d', $y, $mo, $d) : '';
    }

    /**
     * Regole fisse, valgono anche senza chiave AI: nome da archivio e scadenza
     * dichiarata ("valido al", "gültig bis", "valid until"…).
     */
    private static function rule_assessment($title, $file, $text) {
        $out = array('valid_until' => '', 'doc_date' => '', 'outdated' => false, 'outdated_reason' => '');
        $name = $title . ' ' . $file;
        if (preg_match('/(?:^|[\s_\-.(])(x{3,}|old|obsolet[oaei]?|obsolete|vecchi[oa]|scadut[oa]|abgelaufen|expired|outdated|superseded|deprecated|non[\s_-]usare|da[\s_-]eliminare)(?=$|[\s_\-.)])/i', $name, $m)) {
            $out['outdated'] = true;
            /* translators: %s: segno trovato nel nome del file, es. xxx */
            $out['outdated_reason'] = sprintf(__('Il nome del file contiene «%s»: sembra un documento messo da parte.', 'ticino-ai-booking'), $m[1]);
        }
        $haystack = $name . ' ' . mb_substr($text, 0, 6000) . ' ' . mb_substr($text, -2000);
        if (preg_match('/(?:valid[oa]\s+(?:fino\s+)?al|validit[aà]\s+(?:fino\s+)?al|scadenza|g[üu]ltig\s+bis|valable\s+jusqu.au|valid\s+(?:until|to|through)|expiry\s+date|expires?(?:\s+on)?)[\s:_-]*(\d{1,2}[.\/-]\d{1,2}[.\/-]\d{4}|\d{4}-\d{2}-\d{2}|\d{8})/iu', $haystack, $m)) {
            $out['valid_until'] = self::parse_date($m[1]);
        }
        return $out;
    }

    /**
     * Giudizio su un documento: regole fisse, poi l'AI del sito se configurata.
     *
     * @return array valid_until, doc_date, outdated, outdated_reason, assessed
     */
    private static function assess_document($attachment_id, $title, $file, $text) {
        $out = self::rule_assessment($title, $file, $text);
        $today = current_time('Y-m-d');

        if (Ticino_AI_Booking_Gemini_Client::is_configured()) {
            $excerpt = mb_substr($text, 0, 3500) . (mb_strlen($text) > 4500 ? "\n[...]\n" . mb_substr($text, -1000) : '');
            $system = "Controlli i documenti PDF pubblicati sul sito di un'azienda e decidi se sono ancora attuali. Oggi e' {$today}. "
                . "Rispondi SOLO con un oggetto JSON: {\"document_date\": \"AAAA-MM-GG\" o null, \"valid_until\": \"AAAA-MM-GG\" o null, \"outdated\": true o false, \"reason\": \"...\"}. "
                . "document_date: la data di emissione o pubblicazione del documento, se si capisce (anche solo l'anno: usa il primo gennaio). "
                . "valid_until: solo se il documento dichiara una scadenza o un periodo di validita' DEL DOCUMENTO STESSO (certificati, attestati, offerte, listini, bandi, iscrizioni). "
                . "L'anno o il periodo a cui si riferisce un rapporto (rapporto annuale, CSR, sostenibilita', bilancio, report del territorio) NON e' una validita': per questi valid_until = null. "
                . "Anche le date di validita' di certificati o dichiarazioni citati DENTRO un rapporto non sono la validita' del rapporto. "
                . "outdated = true SOLO se: la validita' dichiarata e' finita prima di oggi; oppure il documento dice di essere sostituito o annullato; "
                . "oppure annuncia un evento, un'offerta, una posizione aperta o una scadenza chiaramente gia' passati. "
                . "Un documento vecchio ma ancora valido come informazione (rapporto di un anno, storia, scheda tecnica, catalogo, condizioni generali senza scadenza) NON e' outdated: "
                . "un rapporto non e' mai outdated per la sua data (le edizioni superate le trova un controllo separato). "
                . "reason: se outdated, una frase breve in italiano per l'amministratore del sito che spiega perche' (con la data); altrimenti stringa vuota.";
            $prompt = "Nome del documento: {$title}\nFile: {$file}\nCaricato sul sito il: " . get_the_date('Y-m-d', $attachment_id) . "\n\nTesto:\n{$excerpt}";
            $client = new Ticino_AI_Booking_Gemini_Client();
            $ai = $client->generate_json($system, $prompt, 1200);
            if (!is_wp_error($ai)) {
                $vu = self::parse_date((string) ($ai['valid_until'] ?? ''));
                $dd = self::parse_date((string) ($ai['document_date'] ?? ''));
                // Con l'AI vale la sua lettura della scadenza: la regola sulle date
                // scambia per scadenze anche i periodi di riferimento dei rapporti
                $out['valid_until'] = $vu;
                if ($dd !== '') $out['doc_date'] = $dd;
                if (!$out['outdated'] && !empty($ai['outdated'])) {
                    $out['outdated'] = true;
                    $out['outdated_reason'] = sanitize_text_field((string) ($ai['reason'] ?? '')) ?: __('Secondo il controllo automatico il documento non è più attuale.', 'ticino-ai-booking');
                }
            }
        }

        $out['outdated_by'] = $out['outdated'] ? 'content' : '';
        if (!$out['outdated'] && $out['valid_until'] !== '' && $out['valid_until'] < $today) {
            $out['outdated'] = true;
            $out['outdated_by'] = 'expiry';
            $out['outdated_reason'] = self::expired_reason($out['valid_until']);
        }
        if ($out['doc_date'] === '' && preg_match('/(?:^|\D)((?:19|20)\d{2})(?:\D|$)/', $title . ' ' . $file, $m)) {
            $out['doc_date'] = $m[1] . '-01-01';
        }
        $out['assessed'] = true;
        return $out;
    }

    private static function expired_reason($valid_until) {
        /* translators: %s: data di scadenza */
        return sprintf(__('Valido fino al %s: è scaduto.', 'ticino-ai-booking'), mysql2date(get_option('date_format'), $valid_until));
    }

    /** Testo gia' estratto di un documento (per giudicare quelli letti prima della 1.6.0). */
    private static function stored_text($attachment_id) {
        global $wpdb;
        $rows = $wpdb->get_col($wpdb->prepare('SELECT content FROM ' . self::table() . ' WHERE attachment_id = %d ORDER BY chunk_index', $attachment_id));
        return implode(' ', $rows ?: array());
    }

    /**
     * Un pezzo di lavoro sul giudizio: prima i documenti mai giudicati, poi il
     * confronto fra versioni. @return bool true se qualcosa e' cambiato
     */
    private static function relevance_step($start, $seconds) {
        $changed = false;
        foreach (self::get_documents() as $id => $doc) {
            if (isset($doc['assessed'])) continue;
            $doc = array_merge($doc, self::assess_document($id, $doc['title'], $doc['file'], self::stored_text($id)));
            wp_cache_delete(self::DOCS_OPTION, 'options');
            $docs = self::get_documents();
            if (!isset($docs[$id])) continue;
            $docs[$id] = $doc;
            self::save_documents($docs);
            update_option(self::REVIEW_OPTION, '1', false);
            $changed = true;
            if (microtime(true) - $start > $seconds) return $changed;
        }
        if (get_option(self::REVIEW_OPTION) === '1') {
            update_option(self::REVIEW_OPTION, '0', false);
            $changed = self::review_versions() || $changed;
        }
        return $changed;
    }

    /** Chiave per riconoscere lo stesso documento in anni o versioni diversi (regola senza AI). */
    private static function version_key($doc) {
        $k = mb_strtolower(preg_replace('/\.pdf$/i', '', $doc['file']));
        $k = preg_replace('/(?:19|20)\d{2}|\d{6,8}|\b(?:x{3,}|new|old|v\d+|rev\d+|final[e]?)\b/u', ' ', $k);
        $k = preg_replace('/-[a-z0-9]{4}$/', '', trim(preg_replace('/[^\p{L}\p{N}]+/u', '-', $k), '-'));
        return trim($k, '-');
    }

    /**
     * Versioni superate: piu' copie dello stesso documento (certificato
     * rinnovato, rapporto dell'anno dopo, listino nuovo) => resta la piu' recente.
     * Con la chiave AI il confronto lo fa l'AI sull'elenco dei titoli; senza,
     * nome uguale a meno di anni e date.
     */
    private static function review_versions() {
        $docs = self::get_documents();
        if (count($docs) < 2) return false;
        $superseded = array(); // id => array(by, reason)

        if (Ticino_AI_Booking_Gemini_Client::is_configured()) {
            $lines = array();
            foreach ($docs as $id => $d) {
                $lines[] = $id . ' | ' . $d['title'] . ' | ' . $d['file'] . ' | data: ' . (($d['doc_date'] ?? '') ?: '?') . ' | caricato: ' . get_the_date('Y-m-d', $id);
            }
            $system = "Ricevi l'elenco dei documenti PDF del sito di un'azienda (id | titolo | file | data del documento | data di caricamento). "
                . "Trova i documenti SUPERATI da una versione piu' recente DELLO STESSO documento NELLA STESSA LINGUA presente nell'elenco: "
                . "lo stesso certificato rinnovato, lo stesso listino o catalogo di un anno successivo, lo stesso rapporto periodico con un'edizione piu' recente, una revisione nuova dello stesso file. "
                . "Documenti diversi sullo stesso tema NON si superano. Le traduzioni in altre lingue NON si superano tra loro. Nel dubbio non segnalare nulla. "
                . "Rispondi SOLO con JSON: {\"superseded\": [{\"id\": numero, \"by\": numero, \"reason\": \"frase breve in italiano\"}]}.";
            $client = new Ticino_AI_Booking_Gemini_Client();
            $ai = $client->generate_json($system, implode("\n", $lines), 2500);
            if (!is_wp_error($ai) && isset($ai['superseded']) && is_array($ai['superseded'])) {
                foreach ($ai['superseded'] as $row) {
                    $id = (int) ($row['id'] ?? 0);
                    $by = (int) ($row['by'] ?? 0);
                    if ($id && $by && $id !== $by && isset($docs[$id], $docs[$by])) {
                        $superseded[$id] = array($by, sanitize_text_field((string) ($row['reason'] ?? '')));
                    }
                }
            } else {
                return false; // riprova al prossimo giro
            }
        } else {
            $groups = array();
            foreach ($docs as $id => $d) {
                if (($d['doc_date'] ?? '') !== '') $groups[self::version_key($d)][$id] = $d['doc_date'];
            }
            foreach ($groups as $key => $members) {
                if ($key === '' || count($members) < 2) continue;
                arsort($members);
                $newest = key($members);
                foreach ($members as $id => $date) {
                    if ($id !== $newest && $date < $members[$newest]) $superseded[$id] = array($newest, '');
                }
            }
        }

        $changed = false;
        wp_cache_delete(self::DOCS_OPTION, 'options');
        $docs = self::get_documents();
        foreach ($docs as $id => &$d) {
            $was_by_version = ($d['outdated_by'] ?? '') === 'version';
            if (isset($superseded[$id]) && empty($d['outdated'])) {
                list($by, $reason) = $superseded[$id];
                $d['outdated'] = true;
                $d['outdated_by'] = 'version';
                /* translators: %s: nome del documento piu' recente */
                $d['outdated_reason'] = $reason ?: sprintf(__('C\'è una versione più recente: «%s».', 'ticino-ai-booking'), $docs[$by]['title']);
                $changed = true;
            } elseif (!isset($superseded[$id]) && $was_by_version) {
                // La versione nuova e' stata tolta: il documento torna attuale
                $d['outdated'] = false;
                $d['outdated_by'] = '';
                $d['outdated_reason'] = '';
                $changed = true;
            }
        }
        unset($d);
        if ($changed) self::save_documents($docs);
        return $changed;
    }

    /** Ogni giorno: i documenti con una scadenza passata escono dalle risposte. */
    public static function daily_check() {
        $docs = self::get_documents();
        $today = current_time('Y-m-d');
        $changed = false;
        foreach ($docs as &$d) {
            if (empty($d['outdated']) && !empty($d['valid_until']) && $d['valid_until'] < $today) {
                $d['outdated'] = true;
                $d['outdated_by'] = 'expiry';
                $d['outdated_reason'] = self::expired_reason($d['valid_until']);
                $changed = true;
            }
        }
        unset($d);
        if ($changed) self::save_documents($docs);
        self::schedule_sync();
    }

    public static function maybe_schedule_daily() {
        if (!wp_next_scheduled(self::DAILY_HOOK)) {
            wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', self::DAILY_HOOK);
        }
    }

    /** AJAX: «Usa comunque» / «Non usarlo» su un documento non più attuale. */
    public function ajax_relevance() {
        $attachment_id = self::check_request();
        $docs = self::get_documents();
        if (!isset($docs[$attachment_id])) {
            wp_send_json_error(array('message' => __('Il documento non è più nella Knowledge Base.', 'ticino-ai-booking')));
        }
        $use = !empty($_POST['use']);
        $docs[$attachment_id]['override'] = $use ? 'use' : '';
        self::save_documents($docs);
        $title = $docs[$attachment_id]['title'];
        wp_send_json_success(array(
            'document' => self::document_for_js($attachment_id, $docs[$attachment_id]),
            'message'  => $use
                /* translators: %s: nome del documento */
                ? sprintf(__('L\'assistente userà di nuovo «%s», anche se non sembra più attuale.', 'ticino-ai-booking'), $title)
                /* translators: %s: nome del documento */
                : sprintf(__('L\'assistente non userà più «%s».', 'ticino-ai-booking'), $title),
            'status'   => self::sync_status(),
        ));
    }

    /** Stato per la pagina Knowledge Base. */
    public static function sync_status() {
        $state   = self::get_sync_state();
        $library = self::library_pdf_ids();
        $skipped = array();
        $excluded = array();
        foreach ($library as $id) {
            if (isset($state['skipped'][$id])) {
                $skipped[] = array('id' => $id, 'title' => $state['skipped'][$id]['title'], 'reason' => $state['skipped'][$id]['reason'], 'url' => wp_get_attachment_url($id));
            } elseif (isset($state['excluded'][$id])) {
                $excluded[] = array('id' => $id, 'title' => trim(wp_strip_all_tags(get_the_title($id))) ?: wp_basename((string) get_attached_file($id)));
            }
        }
        $docs = self::get_documents();
        $unassessed = 0;
        $outdated = 0;
        foreach ($docs as $d) {
            if (!isset($d['assessed'])) $unassessed++;
            if (!self::is_active($d)) $outdated++;
        }
        return array(
            'auto'     => self::auto_enabled(),
            'checking' => $unassessed,
            'review'   => get_option(self::REVIEW_OPTION) === '1' && count($docs) > 1,
            'outdated' => $outdated,
            'library'  => count($library),
            'pending'  => self::auto_enabled() ? count(self::pending_ids()) : 0,
            'skipped'  => $skipped,
            'excluded' => $excluded,
        );
    }

    /** AJAX: avanzamento dal vivo (step) e interruttore automatico (toggle). */
    public function ajax_sync() {
        check_ajax_referer('ticino_ai_admin_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Non hai i permessi per modificare la Knowledge Base.', 'ticino-ai-booking')), 403);
        }
        $do = isset($_POST['do']) ? sanitize_key($_POST['do']) : 'step';
        $added = array();
        if ($do === 'toggle') {
            update_option(self::AUTO_OPTION, !empty($_POST['auto']) ? '1' : '0', false);
            self::schedule_sync();
        } elseif ($do === 'step') {
            $result = self::sync_step(8);
            foreach ($result['added'] as $id => $doc) {
                $added[] = self::document_for_js($id, $doc);
            }
            if ($result['changed']) {
                // Giudizi cambiati: la pagina ridisegna l'elenco intero
                foreach (self::get_documents() as $id => $doc) {
                    $added[] = self::document_for_js($id, $doc);
                }
            }
        }
        wp_send_json_success(array(
            'added'   => $added,
            'status'  => self::sync_status(),
            'summary' => self::summary(),
            'busy'    => (bool) get_transient(self::LOCK_TRANSIENT),
        ));
    }

    /* ------------------------------------------------------------------ */
    /*  Indicizzazione                                                     */
    /* ------------------------------------------------------------------ */

    /**
     * Controlla il file, estrae il testo, lo divide in pezzi e lo salva.
     *
     * @return array|WP_Error metadati del documento
     */
    public static function index_attachment($attachment_id) {
        global $wpdb;

        $post = $attachment_id ? get_post($attachment_id) : null;
        if (!$post || $post->post_type !== 'attachment') {
            return new WP_Error('not_found', __('Il file scelto non esiste più nella libreria media.', 'ticino-ai-booking'));
        }
        $file = get_attached_file($attachment_id);
        $ext  = strtolower(pathinfo((string) $file, PATHINFO_EXTENSION));
        if ($post->post_mime_type !== 'application/pdf' || $ext !== 'pdf') {
            return new WP_Error('not_pdf', __('Si possono aggiungere solo file PDF.', 'ticino-ai-booking'));
        }
        if (!$file || !is_readable($file)) {
            return new WP_Error('missing_file', __('Il file PDF non si trova sul server: caricalo di nuovo nella libreria media.', 'ticino-ai-booking'));
        }
        $size = (int) filesize($file);
        if ($size > self::max_bytes()) {
            return new WP_Error('too_big', sprintf(
                /* translators: 1: dimensione del file, 2: dimensione massima */
                __('Il PDF pesa %1$s: il massimo è %2$s. Dividilo in più file o comprimilo e riprova.', 'ticino-ai-booking'),
                size_format($size), size_format(self::max_bytes())
            ));
        }
        $fh = fopen($file, 'rb');
        $head = $fh ? fread($fh, 1024) : '';
        if ($fh) fclose($fh);
        if (strpos((string) $head, '%PDF-') === false) {
            return new WP_Error('not_pdf', __('Il file ha estensione .pdf ma non è un PDF valido.', 'ticino-ai-booking'));
        }

        $pages = self::extract_pages($file);
        if (is_wp_error($pages)) {
            return $pages;
        }
        $total_chars = 0;
        foreach ($pages as $p) $total_chars += mb_strlen($p);
        $all_text = implode(' ', $pages);
        if ($total_chars < self::MIN_TEXT || !self::looks_readable($all_text)) {
            return new WP_Error('no_text', __('Questo PDF non contiene testo leggibile: probabilmente è una scansione o un\'immagine. L\'assistente non può leggerlo. Esporta il documento dal programma originale (Word, InDesign…) come PDF con testo, oppure passalo in un programma di riconoscimento del testo (OCR) e caricalo di nuovo.', 'ticino-ai-booking'));
        }

        $chunks = self::chunk_pages($pages);
        $existing = 0;
        foreach (self::get_documents() as $id => $d) {
            if ((int) $id !== (int) $attachment_id) $existing += (int) ($d['chunks'] ?? 0);
        }
        if ($existing + count($chunks) > self::MAX_CHUNKS) {
            return new WP_Error('too_much', __('La Knowledge Base ha raggiunto il limite di testo dai PDF. Togli un documento che non serve più e riprova.', 'ticino-ai-booking'));
        }

        // Embedding (facoltativi): se falliscono la ricerca usa le parole chiave
        $embed_model = '';
        $vectors = self::embed(wp_list_pluck($chunks, 'content'), 'document', $embed_model);
        if (is_wp_error($vectors)) {
            if ($vectors->get_error_code() !== 'no_key') Ticino_AI_Booking_Chatbot::log_error('PDF: embedding non disponibili (' . $vectors->get_error_message() . '), ricerca per parole chiave.');
            $vectors = array();
            $embed_model = '';
        }

        $table = self::table();
        $wpdb->delete($table, array('attachment_id' => (int) $attachment_id), array('%d'));
        foreach ($chunks as $i => $c) {
            $wpdb->insert($table, array(
                'attachment_id' => (int) $attachment_id,
                'chunk_index'   => $i,
                'page'          => (int) $c['page'],
                'content'       => $c['content'],
                'embedding'     => isset($vectors[$i]) ? self::pack_vector($vectors[$i]) : null,
            ), array('%d', '%d', '%d', '%s', '%s'));
        }

        $title = trim(wp_strip_all_tags($post->post_title)); // grezzo: get_the_title() aggiunge entita' HTML (&#8211;)
        if ($title === '') $title = wp_basename($file);
        $previous = self::get_documents()[(int) $attachment_id] ?? array();
        $doc = array(
            'title'       => $title,
            'file'        => wp_basename($file),
            'size'        => $size,
            'pages'       => count($pages),
            'chars'       => min($total_chars, self::MAX_DOC_CHARS),
            'chunks'      => count($chunks),
            'embed_model' => $embed_model,
            'indexed_at'  => current_time('mysql'),
            'override'    => $previous['override'] ?? '',
        );
        $doc = array_merge($doc, self::assess_document($attachment_id, $title, wp_basename($file), $all_text));
        $docs = self::get_documents();
        $docs[(int) $attachment_id] = $doc;
        self::save_documents($docs);
        update_option(self::REVIEW_OPTION, '1', false);
        self::schedule_sync(30);
        return $doc;
    }

    /** @return string[]|WP_Error testo di ogni pagina */
    private static function extract_pages($file) {
        self::load_parser();
        if (function_exists('wp_raise_memory_limit')) wp_raise_memory_limit('admin');
        if (function_exists('set_time_limit')) @set_time_limit(300);
        try {
            $config = new \Smalot\PdfParser\Config();
            $config->setRetainImageContent(false); // le immagini non servono e pesano in memoria
            $parser = new \Smalot\PdfParser\Parser(array(), $config);
            $pdf = $parser->parseFile($file);
            $pages = array();
            $total = 0;
            foreach ($pdf->getPages() as $page) {
                $text = self::clean_text($page->getText());
                $total += mb_strlen($text);
                if ($total > self::MAX_DOC_CHARS) break;
                $pages[] = $text;
            }
            return $pages;
        } catch (\Throwable $e) {
            $msg = $e->getMessage();
            Ticino_AI_Booking_Chatbot::log_error('PDF non leggibile (' . wp_basename($file) . '): ' . $msg);
            if (stripos($msg, 'secured') !== false || stripos($msg, 'encrypt') !== false) {
                return new WP_Error('encrypted', __('Il PDF è protetto da password o cifrato. Salvane una copia senza protezione e caricala di nuovo.', 'ticino-ai-booking'));
            }
            return new WP_Error('parse_error', __('Non è stato possibile leggere questo PDF (file danneggiato o formato non supportato). Prova a salvarlo di nuovo come PDF e a ricaricarlo.', 'ticino-ai-booking'));
        }
    }

    private static function load_parser() {
        if (class_exists('\Smalot\PdfParser\Parser')) {
            return; // gia' caricata da un altro plugin
        }
        spl_autoload_register(function ($class) {
            if (strpos($class, 'Smalot\\PdfParser\\') !== 0) return;
            $path = TICINO_AI_BOOKING_PLUGIN_DIR . 'lib/pdfparser/src/' . str_replace('\\', '/', $class) . '.php';
            if (is_readable($path)) require_once $path;
        });
    }

    private static function clean_text($text) {
        $text = (string) $text;
        if (!mb_check_encoding($text, 'UTF-8')) {
            $text = mb_convert_encoding($text, 'UTF-8', 'UTF-8');
        }
        $text = preg_replace('/[^\P{C}\n\t]/u', ' ', $text);   // caratteri di controllo
        $text = preg_replace('/(\p{L})-\s*\n\s*(\p{Ll})/u', '$1$2', $text); // parole spezzate a fine riga
        $text = preg_replace('/[ \t\x{00A0}]+/u', ' ', $text);
        $text = preg_replace('/\s*\n\s*/u', "\n", $text);
        $text = preg_replace('/\n{3,}/', "\n\n", $text);
        return trim((string) $text);
    }

    /** Testo vero o simboli senza senso (font senza mappa dei caratteri)? */
    private static function looks_readable($text) {
        $sample = mb_substr(preg_replace('/\s+/u', '', $text), 0, 5000);
        $len = mb_strlen($sample);
        if ($len === 0) return false;
        $letters = preg_match_all('/[\p{L}\p{N}]/u', $sample);
        return ($letters / $len) > 0.5;
    }

    /** @return array<int, array{page:int, content:string}> */
    private static function chunk_pages($pages) {
        $chunks = array();
        foreach ($pages as $i => $text) {
            if ($text === '') continue;
            $page = $i + 1;
            $len = mb_strlen($text);
            $start = 0;
            while ($start < $len) {
                $piece = mb_substr($text, $start, self::CHUNK_CHARS);
                $end = $start + mb_strlen($piece);
                if ($end < $len) {
                    // chiudi su fine paragrafo o frase, se ce n'e' una nella seconda meta' del pezzo
                    $cut = max(mb_strrpos($piece, "\n") ?: 0, mb_strrpos($piece, '. ') ?: 0);
                    if ($cut > self::CHUNK_CHARS / 2) {
                        $piece = mb_substr($piece, 0, $cut + 1);
                        $end = $start + $cut + 1;
                    }
                }
                $piece = trim($piece);
                if (mb_strlen($piece) >= 20) {
                    $chunks[] = array('page' => $page, 'content' => $piece);
                }
                if ($end >= $len) break;
                $start = max($end - self::CHUNK_OVERLAP, $start + 1);
                // il pezzo successivo parte da inizio parola, non a meta'
                $space = mb_strpos(mb_substr($text, $start, 40), ' ');
                if ($space !== false && $start + $space + 1 < $end) $start += $space + 1;
            }
        }
        return $chunks;
    }

    /* ------------------------------------------------------------------ */
    /*  Embedding (Gemini / OpenAI, provider attivo)                       */
    /* ------------------------------------------------------------------ */

    /** Modello di embedding del provider attivo, '' se manca la chiave. */
    public static function active_embed_model() {
        if (Ticino_AI_Booking_Gemini_Client::get_active_provider() === 'openai') {
            return get_option('ticino_ai_openai_api_key') ? 'openai:text-embedding-3-small' : '';
        }
        return get_option('ticino_ai_gemini_api_key') ? 'gemini:gemini-embedding-001' : '';
    }

    /**
     * @param string[] $texts
     * @param string   $kind 'document' | 'query'
     * @param string   $model_out modello usato
     * @return array<int, float[]>|WP_Error
     */
    private static function embed($texts, $kind, &$model_out) {
        $model_out = self::active_embed_model();
        if ($model_out === '' || empty($texts)) {
            return new WP_Error('no_key', 'chiave API assente');
        }
        $vectors = array();
        foreach (array_chunk($texts, 90) as $batch) {
            $res = strpos($model_out, 'openai:') === 0
                ? self::embed_openai($batch)
                : self::embed_gemini($batch, $kind);
            if (is_wp_error($res)) return $res;
            foreach ($res as $v) $vectors[] = self::normalize($v);
        }
        return count($vectors) === count($texts) ? $vectors : new WP_Error('embed_count', 'risposta incompleta');
    }

    private static function embed_gemini($batch, $kind) {
        $requests = array();
        foreach ($batch as $t) {
            $requests[] = array(
                'model'                => 'models/gemini-embedding-001',
                'content'              => array('parts' => array(array('text' => $t))),
                'taskType'             => $kind === 'query' ? 'RETRIEVAL_QUERY' : 'RETRIEVAL_DOCUMENT',
                'outputDimensionality' => self::EMBED_DIMS,
            );
        }
        $resp = wp_remote_post('https://generativelanguage.googleapis.com/v1beta/models/gemini-embedding-001:batchEmbedContents', array(
            'headers' => array('Content-Type' => 'application/json', 'x-goog-api-key' => (string) get_option('ticino_ai_gemini_api_key')),
            'body'    => wp_json_encode(array('requests' => $requests)),
            'timeout' => $kind === 'query' ? 5 : 60, // a ogni domanda: se tarda si ripiega sulle parole chiave
        ));
        if (is_wp_error($resp)) return $resp;
        $body = json_decode(wp_remote_retrieve_body($resp), true);
        if (wp_remote_retrieve_response_code($resp) !== 200 || empty($body['embeddings'])) {
            return new WP_Error('embed_error', $body['error']['message'] ?? ('HTTP ' . wp_remote_retrieve_response_code($resp)));
        }
        return wp_list_pluck($body['embeddings'], 'values');
    }

    private static function embed_openai($batch) {
        $resp = wp_remote_post('https://api.openai.com/v1/embeddings', array(
            'headers' => array('Content-Type' => 'application/json', 'Authorization' => 'Bearer ' . get_option('ticino_ai_openai_api_key')),
            'body'    => wp_json_encode(array('model' => 'text-embedding-3-small', 'input' => array_values($batch), 'dimensions' => self::EMBED_DIMS)),
            'timeout' => count($batch) === 1 ? 5 : 60,
        ));
        if (is_wp_error($resp)) return $resp;
        $body = json_decode(wp_remote_retrieve_body($resp), true);
        if (wp_remote_retrieve_response_code($resp) !== 200 || empty($body['data'])) {
            return new WP_Error('embed_error', $body['error']['message'] ?? ('HTTP ' . wp_remote_retrieve_response_code($resp)));
        }
        return wp_list_pluck($body['data'], 'embedding');
    }

    private static function normalize($v) {
        $norm = 0.0;
        foreach ($v as $x) $norm += $x * $x;
        $norm = sqrt($norm) ?: 1.0;
        return array_map(function ($x) use ($norm) { return $x / $norm; }, $v);
    }

    private static function pack_vector($v) {
        return base64_encode(pack('g*', ...$v));
    }

    private static function unpack_vector($s) {
        $bin = base64_decode((string) $s, true);
        return $bin ? array_values(unpack('g*', $bin)) : array();
    }

    /* ------------------------------------------------------------------ */
    /*  Ricerca e contesto per il prompt                                   */
    /* ------------------------------------------------------------------ */

    /** Totali per l'intestazione della sezione in bacheca. */
    public static function summary() {
        $docs = self::get_documents();
        return array(
            'documents' => count($docs),
            'pages'     => array_sum(wp_list_pluck($docs, 'pages')),
            'chunks'    => array_sum(wp_list_pluck($docs, 'chunks')),
        );
    }

    /**
     * Pezzi pertinenti a una domanda.
     *
     * @param bool $force_search true = sempre ricerca (anteprima in bacheca), anche se tutto starebbe nel prompt
     * @return array{chunks: array, method: string} method: all|semantic|keyword|none
     */
    public static function search($query, $limit = 0, $force_search = false) {
        global $wpdb;
        // Solo i documenti ancora attuali (1.6.0)
        $docs = array_filter(self::get_documents(), array(__CLASS__, 'is_active'));
        if (empty($docs)) return array('chunks' => array(), 'method' => 'none');

        $table = self::table();
        $in = 'attachment_id IN (' . implode(',', array_map('intval', array_keys($docs))) . ')';
        $total_chars = array_sum(wp_list_pluck($docs, 'chars'));
        $with_title = function ($rows) use ($docs) {
            foreach ($rows as &$r) {
                $r['title'] = $docs[(int) $r['attachment_id']]['title'] ?? '';
                $r['year']  = substr((string) ($docs[(int) $r['attachment_id']]['doc_date'] ?? ''), 0, 4);
            }
            return $rows;
        };

        // Documenti corti: tutto il testo, nessuna chiamata di embedding
        if (!$force_search && $total_chars <= self::FULL_BUDGET) {
            $rows = $wpdb->get_results("SELECT attachment_id, chunk_index, page, content FROM $table WHERE $in ORDER BY attachment_id, chunk_index", ARRAY_A);
            return array('chunks' => $with_title(self::dedupe_overlap($rows ?: array())), 'method' => 'all');
        }

        $scores = array();
        $rows = array();
        $method = 'keyword';

        // Semantica solo se tutti i documenti hanno gli embedding del provider attivo.
        // Prima solo i vettori (niente testo), poi il testo dei soli candidati migliori.
        $model = self::active_embed_model();
        $models = array_values(array_unique(wp_list_pluck($docs, 'embed_model')));
        if ($model !== '' && $models === array($model)) {
            $used = '';
            $qv = self::embed(array($query), 'query', $used);
            if (!is_wp_error($qv)) {
                $qv = $qv[0];
                $vectors = $wpdb->get_results("SELECT id, embedding FROM $table WHERE embedding IS NOT NULL AND $in", ARRAY_A) ?: array();
                $sem = array();
                foreach ($vectors as $r) {
                    $v = self::unpack_vector($r['embedding']);
                    if (count($v) !== count($qv)) continue;
                    $dot = 0.0;
                    foreach ($qv as $k => $x) $dot += $x * $v[$k];
                    $sem[(int) $r['id']] = $dot;
                }
                unset($vectors);
                if ($sem) {
                    arsort($sem);
                    $ids = array_slice(array_keys($sem), 0, 24);
                    $rows = $wpdb->get_results("SELECT id, attachment_id, chunk_index, page, content FROM $table WHERE id IN (" . implode(',', array_map('intval', $ids)) . ")", ARRAY_A) ?: array();
                    $kw = self::keyword_scores($query, $rows, $docs);
                    $max_kw = max($kw ?: array(0)) ?: 1;
                    foreach ($rows as $i => $r) {
                        $scores[$i] = $sem[(int) $r['id']] + 0.15 * ($kw[$i] / $max_kw);
                    }
                    $method = 'semantic';
                }
            }
        }

        if ($method === 'keyword') {
            $rows = $wpdb->get_results("SELECT id, attachment_id, chunk_index, page, content FROM $table WHERE $in", ARRAY_A) ?: array();
            if (empty($rows)) return array('chunks' => array(), 'method' => 'none');
            $scores = self::keyword_scores($query, $rows, $docs);
        }

        arsort($scores);
        $picked = array();
        $chars = 0;
        foreach ($scores as $i => $score) {
            if ($method === 'keyword' && $score <= 0) break;
            $len = mb_strlen($rows[$i]['content']);
            if ($chars + $len > self::SEARCH_BUDGET && !empty($picked)) break;
            $picked[] = $rows[$i];
            $chars += $len;
            if ($limit && count($picked) >= $limit) break;
        }
        return array('chunks' => $with_title($picked), 'method' => $method);
    }

    /** Toglie la sovrapposizione fra pezzi consecutivi quando li si passa tutti. */
    private static function dedupe_overlap($rows) {
        $prev = null;
        foreach ($rows as &$r) {
            if ($prev && $prev['attachment_id'] === $r['attachment_id'] && $prev['page'] === $r['page']) {
                $tail = mb_substr($prev['content'], -self::CHUNK_OVERLAP);
                $pos = mb_strpos($r['content'], mb_substr($tail, -60));
                if ($pos !== false && $pos < self::CHUNK_OVERLAP + 20) {
                    $r['content'] = ltrim(mb_substr($r['content'], $pos + 60));
                }
            }
            $prev = $r;
        }
        return $rows;
    }

    private static function tokens($text) {
        static $stop = null;
        if ($stop === null) {
            $stop = array_flip(explode(' ', 'che chi con per una uno del della delle dei degli alla alle allo nel nella nelle sul sulla come cosa sono siete avete potete posso quale quali quando dove anche non più the and for are you your what which when where how can does with from that this have des les une pour est que qui dans avec sur pas sont vous der die das und ist ein eine mit für wie was wer wo ich sie nicht'));
        }
        $words = preg_split('/[^\p{L}\p{N}]+/u', mb_strtolower((string) $text), -1, PREG_SPLIT_NO_EMPTY);
        $out = array();
        foreach ($words as $w) {
            if (mb_strlen($w) < 3 || isset($stop[$w])) continue;
            $out[] = mb_strlen($w) > 5 ? mb_substr($w, 0, 5) : $w; // radice grezza: prezzo/prezzi, orario/orari
        }
        return $out;
    }

    /** Punteggio TF-IDF semplice; il nome del documento conta come parte del testo. */
    private static function keyword_scores($query, $rows, $docs) {
        $q = array_unique(self::tokens($query));
        $scores = array_fill_keys(array_keys($rows), 0.0);
        if (empty($q)) return $scores;
        $n = count($rows);
        $df = array_fill_keys($q, 0);
        $tf = array();
        foreach ($rows as $i => $r) {
            $title = $docs[(int) $r['attachment_id']]['title'] ?? '';
            $counts = array_count_values(self::tokens($title . ' ' . $r['content']));
            $tf[$i] = $counts;
            foreach ($q as $t) if (isset($counts[$t])) $df[$t]++;
        }
        foreach ($rows as $i => $r) {
            $s = 0.0;
            foreach ($q as $t) {
                if (empty($tf[$i][$t])) continue;
                $s += (1 + log($tf[$i][$t])) * log(1 + $n / $df[$t]);
            }
            $scores[$i] = $s;
        }
        return $scores;
    }

    /**
     * Sezione del prompt con i passaggi dei PDF pertinenti alla domanda ('' se nessun PDF).
     *
     * @param string $query ultima domanda dell'utente (con quella precedente, per le domande di seguito)
     */
    public static function get_prompt_context($query) {
        $found = self::search($query);
        if (empty($found['chunks'])) {
            return '';
        }
        $out = "=== DOCUMENTI PDF DELL'AZIENDA ===\n"
             . ($found['method'] === 'all'
                ? "Testo dei documenti PDF caricati dall'azienda.\n"
                : "Passaggi dei documenti PDF dell'azienda piu' pertinenti alla domanda.\n")
             . "Quando usi un'informazione da questi documenti, indica da quale documento viene (es. «secondo il documento \"Nome\"»), senza citare numeri di pezzo. "
             . "I documenti possono essere in un'altra lingua: rispondi sempre nella lingua dell'utente. "
             . "Se due documenti dicono cose diverse, vale il piu' recente. "
             . "Se i documenti non contengono la risposta, non inventarla.\n\n";
        $last = null;
        foreach ($found['chunks'] as $c) {
            $label = '[Documento: "' . $c['title'] . '"' . (!empty($c['year']) ? ' (' . $c['year'] . ')' : '') . ($c['page'] ? ', pagina ' . (int) $c['page'] : '') . ']';
            if ($label !== $last) {
                $out .= "\n" . $label . "\n";
                $last = $label;
            }
            $out .= $c['content'] . "\n";
        }
        return $out . "\n";
    }

    /** Dati di una riga dell'elenco in bacheca. */
    public static function document_for_js($attachment_id, $doc) {
        $current = self::active_embed_model();
        return array(
            'id'         => (int) $attachment_id,
            'title'      => $doc['title'],
            'file'       => $doc['file'],
            'url'        => wp_get_attachment_url($attachment_id),
            'size'       => size_format((int) $doc['size']),
            'pages'      => (int) $doc['pages'],
            'chunks'     => (int) $doc['chunks'],
            'indexed_at' => mysql2date(get_option('date_format') . ' H:i', $doc['indexed_at']),
            'smart'      => $current !== '' && $doc['embed_model'] === $current,
            'outdated'   => !empty($doc['outdated']),
            'reason'     => (string) ($doc['outdated_reason'] ?? ''),
            'override'   => ($doc['override'] ?? '') === 'use',
            'valid_until'=> !empty($doc['valid_until']) ? mysql2date(get_option('date_format'), $doc['valid_until']) : '',
        );
    }
}
