<?php
/**
 * Fired during plugin activation
 */
class Ticino_AI_Booking_Activator {

	public static function activate() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        $table_appointments = $wpdb->prefix . 'ticino_ai_appointments';
        $table_conversations = $wpdb->prefix . 'ticino_ai_conversations';

        $sql_appointments = "CREATE TABLE $table_appointments (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
            status varchar(50) DEFAULT 'pending' NOT NULL,
            customer_first_name varchar(100) NOT NULL,
            customer_last_name varchar(100) NOT NULL,
            customer_email varchar(100) NOT NULL,
            customer_phone varchar(50) NOT NULL,
            requested_service varchar(255) NOT NULL,
            requested_date varchar(255) NOT NULL,
            requested_time_slot varchar(50) NOT NULL,
            notes text,
            privacy_consent tinyint(1) DEFAULT 0 NOT NULL,
            admin_notes text,
            calendar_event_id varchar(255),
            calendar_sync_status varchar(50),
            calendar_sync_error text,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        $sql_conversations = "CREATE TABLE $table_conversations (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
            session_id varchar(100) NOT NULL,
            customer_email varchar(100),
            messages_json longtext NOT NULL,
            appointment_id bigint(20),
            PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta( $sql_appointments );
        dbDelta( $sql_conversations );

        // Tabella dei pezzi di testo dei PDF della Knowledge Base (1.4.0)
        require_once TICINO_AI_BOOKING_PLUGIN_DIR . 'includes/class-pdf-knowledge.php';
        Ticino_AI_Booking_PDF_Knowledge::install();

        // Imposta opzioni default e precompila Knowledge Base se non esistono già
        self::set_default_options();
	}

    private static function set_default_options() {
        // Modalita': 'booking' (appuntamenti) o 'lead' (generazione contatti). Se l'opzione viene
        // impostata PRIMA dell'attivazione (es. `wp option add ticino_ai_mode lead`), tutti i
        // default qui sotto vengono generati gia' nella modalita' scelta.
        add_option('ticino_ai_mode', 'booking');
        $lead = Ticino_AI_Booking_Chatbot::is_lead_mode();

        // Opzioni Generali
        add_option('ticino_ai_company_name', get_option('ticinoweb_site_name', get_bloginfo('name')));
        add_option('ticino_ai_company_email', get_option('ticinoweb_contact_email', get_option('admin_email')));
        add_option('ticino_ai_company_phone', get_option('ticinoweb_contact_phone', ''));
        add_option('ticino_ai_company_address', wp_strip_all_tags((string) get_option('ticinoweb_contact_address', '')));
        add_option('ticino_ai_company_hours', '');

        // Opzioni Chatbot
        add_option('ticino_ai_bot_name', 'Assistente virtuale');
        add_option('ticino_ai_bot_greeting', Ticino_AI_Booking_Chatbot::default_greeting());
        add_option('ticino_ai_bot_color_main', '#1a1a1a'); // Antracite
        add_option('ticino_ai_bot_color_accent', '#cebdad'); // Champagne
        add_option('ticino_ai_auto_show', 'yes');
        add_option('ticino_ai_kb_source', 'site_auto');
        add_option('ticino_ai_kb_post_types', array());

        // Knowledge Base: vuota di default. In modalita' "site_auto" la conoscenza e' il sito stesso;
        // servizi, tecnologie, prodotti e FAQ si compilano in Knowledge Base se serve la modalita' manuale.
        add_option('ticino_ai_kb_services', '[]');
        add_option('ticino_ai_kb_techs', '[]');
        add_option('ticino_ai_kb_products', '[]');
        if ($lead) {
            $kb_faq = array(
                array('q' => 'Posso richiedere informazioni o un preventivo dal chatbot?', 'a' => 'Sì. Il chatbot raccoglie i tuoi recapiti e una breve descrizione della tua esigenza; l\'azienda ti ricontatta con le informazioni richieste o un\'offerta.'),
                array('q' => 'In quanto tempo vengo ricontattato?', 'a' => 'L\'azienda esamina la richiesta e ti ricontatta appena possibile ai recapiti che hai indicato.'),
                array('q' => 'Posso fissare un appuntamento in chat?', 'a' => 'No, in chat non si fissano appuntamenti: lascia una richiesta e l\'azienda ti contatterà per concordare i passi successivi.'),
            );
        } else {
            $kb_faq = array(
                array('q' => 'Posso prenotare direttamente dal chatbot?', 'a' => 'Il chatbot può raccogliere una richiesta di appuntamento con i tuoi dati e le tue preferenze. La conferma definitiva arriva dall\'azienda dopo la verifica della disponibilità.'),
                array('q' => 'L\'appuntamento è confermato subito?', 'a' => 'No. Dopo l\'invio riceverai una conferma di ricezione; l\'azienda ti ricontatterà per confermare giorno e orario.'),
                array('q' => 'Posso indicare giorno e fascia oraria preferita?', 'a' => 'Sì, puoi indicare una preferenza. L\'azienda verificherà la disponibilità e ti proporrà eventuali alternative.'),
            );
        }
        add_option('ticino_ai_kb_faq', wp_json_encode($kb_faq, JSON_UNESCAPED_UNICODE));
        add_option('ticino_ai_kb_company_desc', get_option('ticinoweb_site_description', get_bloginfo('description')));
        add_option('ticino_ai_kb_extra_context', '');

        // Prompt di sistema e regole: neutri, generati dai dati del sito (modificabili in Impostazioni > Modello AI)
        add_option('ticino_ai_gemini_system_prompt', Ticino_AI_Booking_Gemini_Client::default_system_prompt());
        add_option('ticino_ai_behavior_rules', Ticino_AI_Booking_Gemini_Client::default_behavior_rules());
        add_option('ticino_ai_gemini_model', 'gemini-2.0-flash');
        add_option('ticino_ai_provider', 'gemini');
        add_option('ticino_ai_openai_model', 'gpt-4.1-mini');

        // Privacy Defaults
        add_option('ticino_ai_privacy_save_conv', '1');
        add_option('ticino_ai_privacy_retention', '30');
        add_option('ticino_ai_privacy_text', $lead
            ? 'Accetto il trattamento dei dati personali per essere ricontattato in merito alla mia richiesta.'
            : 'Accetto il trattamento dei dati personali per poter inviare la richiesta di consulenza.');
        $privacy_page = (int) get_option('wp_page_for_privacy_policy');
        add_option('ticino_ai_privacy_link', $privacy_page ? get_permalink($privacy_page) : '/privacy-policy');

        // Email Templates Defaults
        if ($lead) {
            add_option('ticino_ai_email_req_subject', 'Abbiamo ricevuto la tua richiesta');
            add_option('ticino_ai_email_req_body', "Ciao {customer_name},\nabbiamo ricevuto la tua richiesta di informazioni ({service}).\nIl team di {company_name} la esaminerà e ti ricontatterà al più presto ai recapiti che hai indicato.\n\nGrazie,\n{company_name}");
            add_option('ticino_ai_email_conf_subject', 'Aggiornamento sulla tua richiesta');
            add_option('ticino_ai_email_conf_body', "Ciao {customer_name},\nla tua richiesta ({service}) è stata presa in carico da {company_name}.\n\nPer domande puoi contattarci al {company_phone}.\n\nGrazie,\n{company_name}");
            add_option('ticino_ai_email_rej_subject', 'Aggiornamento sulla tua richiesta');
            add_option('ticino_ai_email_rej_body', "Ciao {customer_name},\nti ringraziamo per la tua richiesta.\nPurtroppo al momento non possiamo dare seguito a quanto richiesto.\n\nPer qualsiasi chiarimento puoi contattarci al {company_phone}.\n\nGrazie,\n{company_name}");
            return;
        }
        add_option('ticino_ai_email_req_subject', 'Abbiamo ricevuto la tua richiesta di appuntamento');
        add_option('ticino_ai_email_req_body', "Ciao {customer_name},\nabbiamo ricevuto la tua richiesta per {service}.\nIl team di {company_name} verificherà la disponibilità e ti invierà una conferma il prima possibile.\nQuesta non è ancora una conferma definitiva dell'appuntamento.\n\nGentili clienti vi rammentiamo che è necessario disdire o spostare un appuntamento 24 ore prima dello stesso. In caso contrario il corrispondente del trattamento prenotato vi verrà fatturato. È possibile avvisarci in qualunque momento telefonando o inviando un messaggio. Vi ringraziamo già sin da ora per la vostra collaborazione.\n\nGrazie,\n{company_name}");
        add_option('ticino_ai_email_conf_subject', 'Il tuo appuntamento è confermato');
        add_option('ticino_ai_email_conf_body', "Ciao {customer_name},\nil tuo appuntamento presso {company_name} è stato confermato.\n\nServizio: {service}\nData: {confirmed_date}\nOrario: {confirmed_time}\n\nTi aspettiamo in {company_address}.\n\nPer modifiche o domande puoi contattarci al {company_phone}.\n\nGentili clienti vi rammentiamo che è necessario disdire o spostare un appuntamento 24 ore prima dello stesso. In caso contrario il corrispondente del trattamento prenotato vi verrà fatturato. È possibile avvisarci in qualunque momento telefonando o inviando un messaggio. Vi ringraziamo già sin da ora per la vostra collaborazione.");
        add_option('ticino_ai_email_rej_subject', 'Aggiornamento sulla tua richiesta di appuntamento');
        add_option('ticino_ai_email_rej_body', "Ciao {customer_name},\nti ringraziamo per la tua richiesta.\nPurtroppo non possiamo confermare l'appuntamento nella fascia indicata.\n\nTi invitiamo a contattarci o a inviare una nuova richiesta con un altro giorno/orario.\n\nGrazie,\n{company_name}");
    }
}
