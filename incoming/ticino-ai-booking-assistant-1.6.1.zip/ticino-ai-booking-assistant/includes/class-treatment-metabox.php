<?php
/**
 * Metabox AI per le pagine servizio/trattamento (attivo solo sui template che lo prevedono)
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Ticino_AI_Booking_Treatment_Metabox {

    private $plugin_name;
    private $version;
    private $gemini_client;

    public function __construct( $plugin_name, $version ) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
    }

    public function init() {
        // Hooks per aggiungere metabox e salvare meta
        add_action( 'add_meta_boxes', array( $this, 'add_ai_metabox' ) );
        add_action( 'save_post', array( $this, 'save_ai_metabox_data' ) );

        // Caricamento assets
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );

        // AJAX endpoints
        add_action( 'wp_ajax_ticino_ai_generate_treatment_content', array( $this, 'ajax_generate_content' ) );
    }

    public function enqueue_assets( $hook ) {
        global $post;
        if ( $hook == 'post-new.php' || $hook == 'post.php' ) {
            if ( 'page' === $post->post_type ) {
                if ( $this->is_treatment_page( $post->ID ) ) {
                    wp_enqueue_style( $this->plugin_name . '-metabox', TICINO_AI_BOOKING_PLUGIN_URL . 'assets/css/admin-metabox.css', array(), $this->version, 'all' );
                    wp_enqueue_script( $this->plugin_name . '-metabox', TICINO_AI_BOOKING_PLUGIN_URL . 'assets/js/admin-metabox.js', array( 'jquery', 'wp-util' ), $this->version, true );
                    
                    wp_localize_script( $this->plugin_name . '-metabox', 'ticino_ai_metabox_obj', array(
                        'ajax_url' => admin_url( 'admin-ajax.php' ),
                        'nonce'    => wp_create_nonce( 'ticino_ai_metabox_nonce' ),
                    ) );
                }
            }
        }
    }

    private function is_treatment_page( $post_id ) {
        $template = get_page_template_slug( $post_id );
        if ( $template === 'template-trattamento.php' || $template === 'template-parts/treatment/template-trattamento.php' ) {
            return true;
        }
        
        $post = get_post( $post_id );
        if ( $post && $post->post_parent ) {
            $parent = get_post( $post->post_parent );
            if ( $parent && stripos( $parent->post_title, 'Trattamenti' ) !== false ) {
                return true;
            }
        }
        return false;
    }

    public function add_ai_metabox() {
        global $post;
        if ( 'page' === $post->post_type && $this->is_treatment_page( $post->ID ) ) {
            add_meta_box(
                'ticino_ai_treatment_metabox',
                'AI Treatment Assistant <span style="background:linear-gradient(45deg,#E6D7BD,#9B9E9F);color:#fff;padding:2px 6px;border-radius:4px;font-size:10px;margin-left:5px;">PREMIUM</span>',
                array( $this, 'render_metabox' ),
                'page',
                'side',
                'high'
            );
        }
    }

    public function render_metabox( $post ) {
        wp_nonce_field( 'ticino_ai_save_metabox', 'ticino_ai_metabox_nonce_save' );

        $current_category = get_post_meta( $post->ID, '_ticino_ai_treatment_category', true );
        if ( empty( $current_category ) && $post->post_parent ) {
            $parent = get_post( $post->post_parent );
            $current_category = $parent->post_title;
        }
        
        $has_thumbnail = has_post_thumbnail( $post->ID ) ? '<span class="dashicons dashicons-yes-alt" style="color:green;"></span>' : '<span class="dashicons dashicons-dismiss" style="color:red;"></span>';
        $has_excerpt = !empty( $post->post_excerpt ) ? '<span class="dashicons dashicons-yes-alt" style="color:green;"></span>' : '<span class="dashicons dashicons-dismiss" style="color:red;"></span>';
        $has_content = !empty( $post->post_content ) ? '<span class="dashicons dashicons-yes-alt" style="color:green;"></span>' : '<span class="dashicons dashicons-dismiss" style="color:red;"></span>';

        include TICINO_AI_BOOKING_PLUGIN_DIR . 'templates/admin-treatment-metabox.php';
    }

    public function save_ai_metabox_data( $post_id ) {
        if ( ! isset( $_POST['ticino_ai_metabox_nonce_save'] ) ) {
            return;
        }
        if ( ! wp_verify_nonce( $_POST['ticino_ai_metabox_nonce_save'], 'ticino_ai_save_metabox' ) ) {
            return;
        }
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }
        if ( ! current_user_can( 'edit_page', $post_id ) ) {
            return;
        }

        if ( isset( $_POST['ticino_ai_treatment_category'] ) ) {
            update_post_meta( $post_id, '_ticino_ai_treatment_category', sanitize_text_field( $_POST['ticino_ai_treatment_category'] ) );
        }
    }

    public function ajax_generate_content() {
        check_ajax_referer( 'ticino_ai_metabox_nonce', 'nonce' );

        if ( ! current_user_can( 'edit_pages' ) ) {
            wp_send_json_error( array( 'message' => 'Non hai i permessi necessari.' ) );
        }

        $post_id = isset( $_POST['post_id'] ) ? intval( $_POST['post_id'] ) : 0;
        $gen_type = isset( $_POST['gen_type'] ) ? sanitize_text_field( $_POST['gen_type'] ) : '';
        $category = isset( $_POST['category'] ) ? sanitize_text_field( $_POST['category'] ) : '';
        $post_title = isset( $_POST['post_title'] ) ? sanitize_text_field( $_POST['post_title'] ) : '';

        if ( ! $post_id || ! $gen_type ) {
            wp_send_json_error( array( 'message' => 'Dati mancanti.' ) );
        }

        if ( ! class_exists( 'Ticino_AI_Booking_Gemini_Client' ) ) {
            require_once TICINO_AI_BOOKING_PLUGIN_DIR . 'includes/class-gemini-client.php';
        }
        
        $gemini = new Ticino_AI_Booking_Gemini_Client();
        
        $system_prompt = $this->build_system_prompt_for_type( $gen_type, $post_title, $category );
        
        $user_prompt = "Genera il contenuto richiesto per il servizio '{$post_title}' (Categoria: {$category}). Fornisci SOLO il contenuto generato, senza intro, saluti o marcatori markdown extra che non siano il codice html richiesto.";
        
        $response = $gemini->generate_content_raw( $system_prompt, $user_prompt );
        
        if ( is_wp_error( $response ) ) {
            wp_send_json_error( array( 'message' => $response->get_error_message() ) );
        }

        // Pulisci eventuale blocco markdown se ritornato da Gemini
        $response = preg_replace('/^```(?:html|json)?\s*/i', '', $response);
        $response = preg_replace('/\s*```$/i', '', $response);

        wp_send_json_success( array(
            'generated' => trim( $response ),
            'type'      => $gen_type
        ) );
    }

    private function build_system_prompt_for_type( $type, $title, $category ) {
        $co   = Ticino_AI_Booking_Dynamic_Site_Knowledge::get_company_info();
        $base = "Sei un copywriter esperto che scrive per '{$co['name']}'" . ($co['description'] !== '' ? " ({$co['description']})" : '') . ".
";
        $base .= "Il tono deve essere elegante, professionale e rassicurante (colori brand: silver, perla, champagne, antracite).\n";
        $base .= "REGOLE RIGOROSISSIME:\n- NON fare MAI promesse o garanzie di risultati medici.\n- NON fare diagnosi mediche.\n- NON inventare prezzi o durate (a meno che non ti siano stati forniti).\n";
        
        switch ( $type ) {
            case 'excerpt':
                return $base . "Compito: Scrivi una breve descrizione (excerpt) di 220-320 caratteri per il servizio. Testo chiaro, senza formattazione, ideale per mega-menu o card. Fai capire i benefici in modo sobrio.";
            case 'content':
                return $base . "Compito: Scrivi il contenuto completo per la pagina WordPress del servizio (1800-2800 caratteri).\nStruttura richiesta in HTML sicuro (h2, h3, p, ul, li):\n1. Introduzione chiara e rassicurante\n2. A chi è indicato (con bullet points)\n3. Come viene costruito il percorso (valutazione, personalizzazione)\n4. Cosa aspettarsi (prudente)\n5. Consulenza (invito finale all'azione).";
            case 'faq':
                return $base . "Compito: Scrivi 3-5 FAQ specifiche per il servizio in formato HTML definition list o simile, o semplicemente:\n<strong>Domanda?</strong>\n<p>Risposta.</p>\nDevono essere rassicuranti (es. adatto a tutti?, serve consulenza?, ecc).";
            case 'seo':
                return $base . "Compito: Scrivi il Meta Title (max 60 car.) e Meta Description (max 160 car.) per SEO. \nFormato testuale atteso:\nTitle: [titolo]\nDescription: [descrizione]\nKeywords: [kw1, kw2]";
            case 'image':
                return $base . "Compito: Scrivi un prompt in INGLESE per un modello AI generatore di immagini (Midjourney/DALL-E) per creare la foto di copertina (hero) di questo servizio. \nIl prompt deve descrivere:\n- Trattamento e mood premium\n- Luce morbida naturale\n- Ambiente beauty clinic, palette pearl/silver/champagne\n- NO TESTO, NO LOGHI nell'immagine, NO elementi medici aggressivi.\n- Solo il prompt finale in lingua inglese.";
        }
        return $base;
    }
}
