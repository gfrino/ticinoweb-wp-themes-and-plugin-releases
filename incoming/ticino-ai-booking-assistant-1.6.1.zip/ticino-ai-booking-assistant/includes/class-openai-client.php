<?php
/**
 * Client OpenAI (Chat Completions API).
 *
 * Espone la stessa interfaccia logica usata dal dispatcher in
 * Ticino_AI_Booking_Gemini_Client: riceve system prompt + storico messaggi
 * e restituisce il testo della risposta oppure un WP_Error.
 */
class Ticino_AI_Booking_OpenAI_Client {

    const ENDPOINT_CHAT   = 'https://api.openai.com/v1/chat/completions';
    const ENDPOINT_MODELS = 'https://api.openai.com/v1/models';
    const DEFAULT_MODEL   = 'gpt-4.1-mini';

    private $api_key;
    private $model;

    public function __construct($api_key = null, $model = null) {
        $this->api_key = $api_key !== null ? $api_key : get_option('ticino_ai_openai_api_key');

        if ($model === null) {
            $model = get_option('ticino_ai_openai_model', self::DEFAULT_MODEL);
            if ($model === 'custom') {
                $model = get_option('ticino_ai_openai_model_custom', self::DEFAULT_MODEL);
            }
        }
        $this->model = !empty($model) ? $model : self::DEFAULT_MODEL;
    }

    public function get_model() {
        return $this->model;
    }

    public function has_api_key() {
        return !empty($this->api_key);
    }

    /**
     * @param string $system_instruction  System prompt.
     * @param array  $messages            Lista di ['role' => 'user'|'model'|'assistant', 'content' => string].
     * @param float  $temperature
     * @param int    $max_tokens
     * @param int    $timeout
     * @return string|WP_Error
     */
    public function chat($system_instruction, $messages, $temperature = 0.3, $max_tokens = 1200, $timeout = 30) {
        if (!$this->has_api_key()) {
            return new WP_Error('no_api_key', 'OpenAI API key non configurata.');
        }

        $payload_messages = array(
            array('role' => 'system', 'content' => (string) $system_instruction),
        );
        foreach ($messages as $msg) {
            $role = (isset($msg['role']) && $msg['role'] === 'user') ? 'user' : 'assistant';
            $payload_messages[] = array(
                'role'    => $role,
                'content' => isset($msg['content']) ? (string) $msg['content'] : '',
            );
        }

        $body = array(
            'model'                 => $this->model,
            'messages'              => $payload_messages,
            'max_completion_tokens' => (int) $max_tokens,
        );
        // I modelli di ragionamento (gpt-5*, o1/o3/o4*) accettano solo la temperatura di default.
        if (self::supports_temperature($this->model)) {
            $body['temperature'] = (float) $temperature;
        }

        $api_resp = wp_remote_post(self::ENDPOINT_CHAT, array(
            'headers' => self::headers($this->api_key),
            'body'    => wp_json_encode($body),
            'timeout' => (int) $timeout,
        ));

        if (is_wp_error($api_resp)) {
            return $api_resp;
        }

        $code          = wp_remote_retrieve_response_code($api_resp);
        $body_response = json_decode(wp_remote_retrieve_body($api_resp), true);

        if ($code !== 200) {
            return new WP_Error('api_error', self::extract_error($body_response, $code));
        }

        if (isset($body_response['choices'][0]['message']['content']) && is_string($body_response['choices'][0]['message']['content'])) {
            return trim($body_response['choices'][0]['message']['content']);
        }

        return new WP_Error('api_error', 'Risposta inattesa da OpenAI API.');
    }

    /**
     * Test rapido della chiave: una completion minima con il modello indicato.
     * @return true|WP_Error
     */
    public static function test_key($api_key, $model) {
        $client = new self($api_key, $model);
        $result = $client->chat('Rispondi solo con OK.', array(array('role' => 'user', 'content' => 'OK?')), 0, 16, 15);
        return is_wp_error($result) ? $result : true;
    }

    /**
     * Elenco dei modelli chat disponibili per la chiave.
     * @return array|WP_Error
     */
    public static function list_models($api_key) {
        if (empty($api_key)) {
            return new WP_Error('no_api_key', 'Chiave API mancante.');
        }

        $api_resp = wp_remote_get(self::ENDPOINT_MODELS, array(
            'headers' => self::headers($api_key),
            'timeout' => 15,
        ));
        if (is_wp_error($api_resp)) {
            return $api_resp;
        }

        $code = wp_remote_retrieve_response_code($api_resp);
        $json = json_decode(wp_remote_retrieve_body($api_resp), true);
        if ($code !== 200 || !isset($json['data']) || !is_array($json['data'])) {
            return new WP_Error('api_error', self::extract_error($json, $code));
        }

        $models = array();
        foreach ($json['data'] as $m) {
            if (empty($m['id'])) {
                continue;
            }
            $id = $m['id'];
            // Solo modelli chat: escludi embedding, audio, immagini, moderazione, tts, realtime, ecc.
            if (!preg_match('/^(gpt-|o\d|chatgpt-)/', $id)) {
                continue;
            }
            if (preg_match('/(embedding|audio|realtime|transcribe|tts|image|search|moderation|instruct)/', $id)) {
                continue;
            }
            $models[] = $id;
        }
        sort($models);
        return $models;
    }

    public static function supports_temperature($model) {
        return !preg_match('/^(gpt-5|o\d)/i', (string) $model);
    }

    private static function headers($api_key) {
        return array(
            'Content-Type'  => 'application/json',
            'Authorization' => 'Bearer ' . $api_key,
        );
    }

    private static function extract_error($body_response, $code) {
        if (isset($body_response['error']['message'])) {
            return $body_response['error']['message'];
        }
        return 'Errore sconosciuto OpenAI API (HTTP ' . (int) $code . ')';
    }
}
