<?php
/**
 * Modulo di Analisi e Conoscenza Dinamica del Sito Web per AI WEB Agent
 * (Dynamic Site Knowledge Engine)
 *
 * Scansiona ed estrae in tempo reale la conoscenza del sito WordPress su cui il
 * plugin e' installato: dati aziendali, team, pagine, listino servizi (se il tema
 * ne espone uno), prodotti WooCommerce, articoli, promozioni CMS e la
 * "conoscenza aggiuntiva" scritta dall'amministratore. Nessun dato di settore
 * e' scritto nel codice: tutto arriva dal sito o dalle impostazioni.
 * 
 * @package Ticino_AI_Booking
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Ticino_AI_Booking_Dynamic_Site_Knowledge {

    const CACHE_KEY = 'ticino_ai_site_knowledge_cache';
    const CACHE_STATS_KEY = 'ticino_ai_site_stats_cache';
    const CACHE_EXPIRATION = 43200; // 12 ore

    /**
     * Ritorna le statistiche dei contenuti analizzati sul sito
     */
    /**
     * Membri del team. Fonte: opzione `synergy_team_members` se il tema attivo
     * espone un pannello team (name, role, title, photo), oppure il vecchio
     * formato `synergy_team_members_data`; filtro `ticino_ai_team_members_raw`
     * per altri temi. Lista normalizzata, vuota se il sito non ha un team.
     *
     * @return array<int, array{name:string, role:string, title:string, description:string}>
     */
    public static function get_team_members() {
        $raw = get_option('synergy_team_members');
        if (empty($raw) || !is_array($raw)) {
            $raw = get_option('synergy_team_members_data');
        }
        $raw = apply_filters('ticino_ai_team_members_raw', $raw);
        if (empty($raw) || !is_array($raw)) {
            return array();
        }

        $members = array();
        foreach ($raw as $m) {
            if (!is_array($m)) {
                continue;
            }
            if (array_key_exists('active', $m) && empty($m['active'])) {
                continue;
            }
            $name = isset($m['name']) ? sanitize_text_field($m['name']) : '';
            if ($name === '') {
                continue;
            }
            $role = isset($m['role']) ? sanitize_text_field($m['role']) : '';
            if (!empty($m['diploma'])) {
                $role .= ($role !== '' ? ', ' : '') . sanitize_text_field($m['diploma']);
            }
            $members[] = array(
                'name'        => $name,
                'role'        => $role,
                'title'       => isset($m['title']) ? sanitize_text_field($m['title']) : '',
                'description' => isset($m['description']) ? sanitize_text_field($m['description']) : '',
            );
        }
        return $members;
    }


    /**
     * Listino servizi del sito, normalizzato: name, category, duration, price, description.
     * Fonti in ordine: listino esposto dal tema (funzione synergy_get_price_list_data o
     * opzione synergy_price_list_data), poi la Knowledge Base manuale del plugin
     * (ticino_ai_kb_services). Filtro `ticino_ai_services_raw` per altre fonti.
     *
     * @return array<int, array{name:string, category:string, duration:string, price:string, description:string, variants:array}>
     */
    public static function get_services() {
        $items = array();
        if (function_exists('synergy_get_price_list_data')) {
            $data = synergy_get_price_list_data();
            if (!empty($data['items']) && is_array($data['items'])) {
                $items = $data['items'];
            }
        }
        if (empty($items)) {
            $saved = get_option('synergy_price_list_data');
            if (!empty($saved['items']) && is_array($saved['items'])) {
                $items = $saved['items'];
            }
        }
        if (empty($items)) {
            $kb = json_decode(get_option('ticino_ai_kb_services', '[]'), true);
            if (is_array($kb)) {
                foreach ($kb as $s) {
                    $items[] = array(
                        'name'        => $s['title'] ?? ($s['name'] ?? ''),
                        'category'    => $s['category'] ?? '',
                        'duration'    => $s['duration'] ?? '',
                        'price_label' => $s['price'] ?? ($s['price_label'] ?? ''),
                        'description' => $s['description'] ?? '',
                    );
                }
            }
        }
        $items = apply_filters('ticino_ai_services_raw', $items);

        $out = array();
        foreach ((array) $items as $t) {
            if (!is_array($t)) {
                continue;
            }
            $name = trim((string) ($t['name'] ?? ''));
            if ($name === '') {
                continue;
            }
            $price = $t['price_label'] ?? '';
            if ($price === '' && !empty($t['price_fixed'])) {
                $price = self::currency() . ' ' . number_format((float) $t['price_fixed'], 2);
            }
            $out[] = array(
                'name'        => $name,
                'category'    => (string) ($t['category'] ?? ($t['category_id'] ?? '')),
                'duration'    => (string) ($t['duration'] ?? ''),
                'price'       => (string) $price,
                'description' => (string) ($t['description'] ?? ''),
                'variants'    => !empty($t['variants']) && is_array($t['variants']) ? $t['variants'] : array(),
            );
        }
        return $out;
    }

    /**
     * Post type pubblici non nativi del sito (CPT del tema/plugin), candidati per l'indice.
     * Esclude `product` quando WooCommerce e' attivo perche' gia' indicizzato come catalogo.
     *
     * @return array<string, WP_Post_Type>
     */
    public static function get_available_post_types() {
        $types = get_post_types(array('public' => true, '_builtin' => false), 'objects');
        if (class_exists('WooCommerce')) {
            unset($types['product']);
        }
        unset($types['attachment']);
        return $types;
    }

    /** Post type scelti in Knowledge Base (opzione `ticino_ai_kb_post_types`), filtrati su quelli esistenti. */
    public static function get_indexed_post_types() {
        $chosen = get_option('ticino_ai_kb_post_types', array());
        if (!is_array($chosen)) {
            return array();
        }
        $available = array_keys(self::get_available_post_types());
        return array_values(array_intersect(array_map('sanitize_key', $chosen), $available));
    }

    /** Sanitize per register_setting di `ticino_ai_kb_post_types`: invalida anche la cache dell'indice. */
    public static function sanitize_post_types($value) {
        $clean = array();
        if (is_array($value)) {
            $available = array_keys(self::get_available_post_types());
            foreach ($value as $v) {
                $v = sanitize_key($v);
                if (in_array($v, $available, true)) {
                    $clean[] = $v;
                }
            }
        }
        delete_transient(self::CACHE_KEY);
        delete_transient(self::CACHE_STATS_KEY);
        return array_values(array_unique($clean));
    }

    /** Valuta: WooCommerce se attivo, altrimenti opzione `ticino_ai_currency` (default CHF). */
    public static function currency() {
        if (function_exists('get_woocommerce_currency')) {
            return get_woocommerce_currency();
        }
        $c = get_option('ticino_ai_currency', 'CHF');
        return $c !== '' ? $c : 'CHF';
    }

    /** Dati aziendali: opzioni del plugin, con fallback alle opzioni CMS del tema ticinoWEB e a WordPress. */
    public static function get_company_info() {
        $name    = get_option('ticino_ai_company_name') ?: get_option('ticinoweb_site_name', get_bloginfo('name'));
        $desc    = get_option('ticino_ai_kb_company_desc') ?: get_option('ticinoweb_site_description', get_bloginfo('description'));
        $address = get_option('ticino_ai_company_address') ?: wp_strip_all_tags((string) get_option('ticinoweb_contact_address', ''));
        $phone   = get_option('ticino_ai_company_phone') ?: get_option('ticinoweb_contact_phone', '');
        $email   = get_option('ticino_ai_company_email') ?: get_option('ticinoweb_contact_email', get_option('admin_email'));
        $hours   = get_option('ticino_ai_company_hours', '');
        $note    = get_option('ticinoweb_contact_opening_hours_note', '');
        return array(
            'name' => (string) $name, 'description' => (string) $desc, 'address' => (string) $address,
            'phone' => (string) $phone, 'email' => (string) $email, 'hours' => (string) $hours, 'hours_note' => (string) $note,
            'url' => home_url('/'),
        );
    }

    public static function get_site_stats($force_refresh = false) {
        if (!$force_refresh) {
            $cached = get_transient(self::CACHE_STATS_KEY);
            if ($cached !== false && is_array($cached)) {
                return $cached;
            }
        }

        // Pagine
        $pages = get_pages(array('post_status' => 'publish'));
        $pages_count = is_array($pages) ? count($pages) : 0;

        // Servizi (listino del tema o Knowledge Base del plugin)
        $services_count = count(self::get_services());

        // Prodotti WooCommerce
        $products_count = 0;
        if (class_exists('WooCommerce')) {
            $prod_posts = get_posts(array(
                'post_type' => 'product',
                'post_status' => 'publish',
                'numberposts' => -1,
                'fields' => 'ids'
            ));
            $products_count = is_array($prod_posts) ? count($prod_posts) : 0;
        }

        // Articoli Blog
        $posts = get_posts(array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'numberposts' => -1,
            'fields' => 'ids'
        ));
        $posts_count = is_array($posts) ? count($posts) : 0;

        // Tecnologie / attrezzature (solo se il tema le espone o sono nella KB manuale)
        $techs = get_option('synergy_prodotti_tecnologie_items', array());
        if (empty($techs)) {
            $techs = json_decode(get_option('ticino_ai_kb_techs', '[]'), true);
        }
        $techs_count = is_array($techs) ? count($techs) : 0;

        // Team (pannello "IL TEAM" del child theme)
        $team_count = count(self::get_team_members());

        $stats = array(
            'pages_count'    => $pages_count,
            'services_count' => $services_count,
            'products_count' => $products_count,
            'posts_count'    => $posts_count,
            'techs_count'    => $techs_count,
            'team_count'     => $team_count,
            'last_indexed'   => current_time('d/m/Y H:i:s'),
            'total_items'    => $pages_count + $services_count + $products_count + $posts_count + $techs_count + $team_count
        );

        set_transient(self::CACHE_STATS_KEY, $stats, self::CACHE_EXPIRATION);
        return $stats;
    }

    /**
     * Costruisce ed estrae l'intera conoscenza strutturata del sito web
     */
    public static function get_full_site_knowledge_context($force_refresh = false) {
        if (!$force_refresh) {
            $cached = get_transient(self::CACHE_KEY);
            if ($cached !== false && !empty($cached)) {
                return $cached;
            }
        }

        $output = "";

        // 1. INFORMAZIONI GENERALI E CONTATTI (impostazioni del plugin / CMS del tema / WordPress)
        $co = self::get_company_info();
        $output .= "=== 1. INFORMAZIONI AZIENDALI & CONTATTI ===\n";
        $output .= "Nome azienda / Brand: {$co['name']}\n";
        $output .= "Sito web: {$co['url']}\n";
        if ($co['description'] !== '') {
            $output .= "Descrizione: {$co['description']}\n";
        }
        if ($co['address'] !== '') {
            $output .= "Indirizzo sede: {$co['address']}\n";
        }
        if ($co['phone'] !== '') {
            $output .= "Telefono: {$co['phone']}\n";
        }
        if ($co['email'] !== '') {
            $output .= "Email di contatto: {$co['email']}\n";
        }
        if ($co['hours'] !== '') {
            $output .= "Orari di apertura: {$co['hours']}\n";
        } else {
            $output .= "Orari di apertura: non indicati nelle impostazioni. NON inventarli: invita a contattare l'azienda.\n";
        }
        if ($co['hours_note'] !== '') {
            $output .= "Note orari: {$co['hours_note']}\n";
        }
        if (class_exists('Ticino_AI_Booking_Chatbot') && Ticino_AI_Booking_Chatbot::is_lead_mode()) {
            $output .= "Richieste di informazioni e preventivi: possono essere raccolte direttamente in chat (nome, telefono, email, esigenza); l'azienda ricontatta il visitatore. In chat NON si fissano appuntamenti e non si comunicano prezzi.\n\n";
        } else {
            $output .= "Richieste di appuntamento: possono essere raccolte direttamente in chat; la conferma definitiva arriva dall'azienda dopo verifica della disponibilita'.\n\n";
        }

        // 2. TEAM (fonte: pannello team del tema, se presente)
        $team = self::get_team_members();
        $output .= "=== 2. TEAM ===\n";
        if (!empty($team)) {
            $output .= "Il team e' composto da " . count($team) . " person" . (count($team) === 1 ? 'a' : 'e') . ". Elenca SOLO queste persone, nessun altro nome:\n";
            foreach ($team as $m) {
                $line = "- {$m['name']}";
                $details = array_filter(array($m['role'], $m['title']));
                if (!empty($details)) {
                    $line .= " (" . implode(' - ', $details) . ")";
                }
                if ($m['description'] !== '') {
                    $line .= " - {$m['description']}";
                }
                $output .= $line . "\n";
            }
        } else {
            $output .= "- Informazioni sul team non configurate: NON inventare nomi. Invita a contattare l'azienda per conoscere il team.\n";
        }
        $output .= "\n";

        // 3. TUTTE LE PAGINE PUBBLICATE DEL SITO
        $pages = get_pages(array('post_status' => 'publish', 'sort_column' => 'menu_order, post_title'));
        if (!empty($pages)) {
            $output .= "=== 3. PAGINE E CONTENUTI PUBBLICATI SUL SITO ===\n";
            foreach ($pages as $p) {
                // Pagine legali/tecniche: inutili per la chat e lunghe
                if (preg_match('/privacy|cookie|termini|condizioni|impressum|note-legali|checkout|carrello|cart|my-account|mio-account|wishlist/i', $p->post_name)) {
                    continue;
                }
                $p_title = $p->post_title;
                $p_url   = get_permalink($p->ID);
                $clean_text = self::clean_content_text($p->post_content);
                
                // ~90 parole per pagina: il contesto intero deve restare sotto ~25k caratteri,
                // altrimenti ogni risposta costa 15-25 secondi e va in timeout
                $trimmed = wp_trim_words($clean_text, 60, '...');
                
                $output .= "• Pagina: {$p_title} (URL: {$p_url})\n";
                if (!empty($trimmed)) {
                    $output .= "  Contenuto: {$trimmed}\n\n";
                }
            }
        }

        // 3b. CONTENUTI PERSONALIZZATI (CPT del tema scelti in Knowledge Base > Contenuti da includere)
        foreach (self::get_indexed_post_types() as $pt) {
            $pt_obj = get_post_type_object($pt);
            if (!$pt_obj) {
                continue;
            }
            $items = get_posts(array(
                'post_type'   => $pt,
                'post_status' => 'publish',
                'numberposts' => 60,
                'orderby'     => 'menu_order title',
                'order'       => 'ASC',
            ));
            if (empty($items)) {
                continue;
            }
            $label = $pt_obj->labels->name;
            $output .= "=== 3b. " . mb_strtoupper($label) . " (" . count($items) . ") ===\n";
            $taxonomies = get_object_taxonomies($pt, 'objects');
            foreach ($items as $it) {
                $output .= "• {$label}: {$it->post_title} (URL: " . get_permalink($it->ID) . ")\n";
                foreach ($taxonomies as $tax) {
                    if (!$tax->public) {
                        continue;
                    }
                    $terms = get_the_terms($it->ID, $tax->name);
                    if (!empty($terms) && !is_wp_error($terms)) {
                        $output .= "  - {$tax->labels->singular_name}: " . implode(', ', wp_list_pluck($terms, 'name')) . "\n";
                    }
                }
                $text = self::clean_content_text($it->post_excerpt !== '' ? $it->post_excerpt : $it->post_content);
                if ($text !== '') {
                    $output .= "  Contenuto: " . wp_trim_words($text, 50, '...') . "\n";
                }
                $output .= "\n";
            }
        }

        // 4. LISTINO SERVIZI (dal tema o dalla Knowledge Base del plugin)
        $services = self::get_services();
        if (!empty($services)) {
            $cur = self::currency();
            $output .= "=== 4. SERVIZI OFFERTI E LISTINO UFFICIALE ({$cur}) ===\n";
            foreach ($services as $t) {
                $output .= "• Servizio: {$t['name']}\n";
                if ($t['category'] !== '') {
                    $output .= "  - Categoria: {$t['category']}\n";
                }
                if ($t['duration'] !== '') {
                    $output .= "  - Durata: {$t['duration']}\n";
                }
                $output .= "  - Prezzo: " . ($t['price'] !== '' ? $t['price'] : 'su richiesta') . "\n";
                if ($t['description'] !== '') {
                    $output .= "  - Descrizione: " . wp_trim_words($t['description'], 22, '...') . "\n";
                }
                if (!empty($t['variants'])) {
                    $output .= "  - Opzioni / Varianti:\n";
                    foreach ($t['variants'] as $v) {
                        $v_name = $v['name'] ?? '';
                        $v_prc  = $v['price_label'] ?? (!empty($v['price']) ? $cur . ' ' . number_format((float) $v['price'], 2) : '');
                        $output .= "    * {$v_name}" . ($v_prc !== '' ? ": {$v_prc}" : '') . "\n";
                    }
                }
                $output .= "\n";
            }
        }

        // 5. PRODOTTI WOOCOMMERCE / CATALOGO PRODOTTI
        if (class_exists('WooCommerce')) {
            $products = get_posts(array(
                'post_type' => 'product',
                'post_status' => 'publish',
                'numberposts' => 30
            ));

            if (!empty($products)) {
                $output .= "=== 5. CATALOGO PRODOTTI DISPONIBILI (SHOP) ===\n";
                foreach ($products as $prod_post) {
                    $wc_prod = wc_get_product($prod_post->ID);
                    if (!$wc_prod) continue;

                    $p_title = $wc_prod->get_name();
                    $p_price = $wc_prod->get_price();
                    $p_curr  = get_woocommerce_currency_symbol();
                    $p_desc  = wp_strip_all_tags($wc_prod->get_short_description() ?: $wc_prod->get_description());
                    $p_desc  = wp_trim_words($p_desc, 25);

                    $output .= "• Prodotto: {$p_title}\n";
                    if ($p_price) {
                        $output .= "  - Prezzo: {$p_curr} {$p_price}\n";
                    }
                    if (!empty($p_desc)) {
                        $output .= "  - Descrizione: {$p_desc}\n";
                    }
                    $output .= "\n";
                }
            }
        }

        // 6. TECNOLOGIE, BRAND E CONOSCENZA AGGIUNTIVA (solo se configurati)
        $techs = get_option('synergy_prodotti_tecnologie_items', array());
        if (empty($techs) || !is_array($techs)) {
            $techs = json_decode(get_option('ticino_ai_kb_techs', '[]'), true);
        }
        if (!empty($techs) && is_array($techs)) {
            $output .= "=== 6a. TECNOLOGIE E ATTREZZATURE ===\n";
            foreach ($techs as $t) {
                $label = is_array($t) ? trim(($t['name'] ?? ($t['title'] ?? '')) . (!empty($t['description']) ? ': ' . $t['description'] : '')) : (string) $t;
                if ($label !== '') {
                    $output .= "- " . wp_strip_all_tags($label) . "\n";
                }
            }
            $output .= "\n";
        }
        $brands = get_option('synergy_prodotti_brand_list', array());
        if (empty($brands) || !is_array($brands)) {
            $brands = json_decode(get_option('ticino_ai_kb_products', '[]'), true);
        }
        if (!empty($brands) && is_array($brands)) {
            $output .= "=== 6b. BRAND E PRODOTTI UTILIZZATI ===\n";
            foreach ($brands as $b) {
                $label = is_array($b) ? trim(($b['name'] ?? ($b['title'] ?? '')) . (!empty($b['description']) ? ': ' . $b['description'] : '')) : (string) $b;
                if ($label !== '') {
                    $output .= "- " . wp_strip_all_tags($label) . "\n";
                }
            }
            $output .= "\n";
        }
        $extra = trim((string) get_option('ticino_ai_kb_extra_context', ''));
        if ($extra !== '') {
            $output .= "=== 6c. CONOSCENZA AGGIUNTIVA FORNITA DALL'AZIENDA ===\n" . $extra . "\n\n";
        }

        // 7. ARTICOLI DEL BLOG & CONSIGLI
        $posts = get_posts(array(
            'post_type'   => 'post',
            'numberposts' => 6,
            'post_status' => 'publish'
        ));
        if (!empty($posts)) {
            $output .= "=== 7. ARTICOLI RECENTI E CONSIGLI DEL BLOG ===\n";
            foreach ($posts as $p) {
                $p_title = $p->post_title;
                $p_exc   = wp_trim_words(get_the_excerpt($p) ?: $p->post_content, 30);
                $output .= "• {$p_title}: {$p_exc}\n";
            }
            $output .= "\n";
        }

        // 8. PROMOZIONI ATTIVE DA CMS
        $promo_disabled = get_option('ticinoweb_disable_promozioni');
        if (!$promo_disabled) {
            $promo_title = get_option('ticinoweb_promozioni_title');
            $promo_text  = get_option('ticinoweb_promozioni_text');
            if (!empty($promo_title) || !empty($promo_text)) {
                $output .= "=== 8. PROMOZIONI & OFFERTE ATTIVE ===\n";
                if (!empty($promo_title)) $output .= "Titolo Offerta: {$promo_title}\n";
                if (!empty($promo_text))  $output .= "Dettagli Offerta: " . wp_strip_all_tags($promo_text) . "\n";
                $output .= "Disponibilita': richiedibile in chat o contattando l'azienda.\n\n";
            }
        }

        // Memorizza in cache
        set_transient(self::CACHE_KEY, $output, self::CACHE_EXPIRATION);

        return $output;
    }

    /**
     * Pulisce il testo HTML, shortcode e caratteri di spaziatura
     */
    private static function clean_content_text($content) {
        $content = strip_shortcodes($content);
        $content = wp_strip_all_tags($content);
        $content = preg_replace('/\s+/', ' ', $content);
        return trim($content);
    }
}

// Alias per retrocompatibilità
class_alias('Ticino_AI_Booking_Dynamic_Site_Knowledge', 'Ticino_AI_Booking_Site_Indexer');
