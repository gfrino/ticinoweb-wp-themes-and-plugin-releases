<?php
if (!class_exists('WP_List_Table')) {
    require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');
}

class Ticino_AI_Appointments_Table extends WP_List_Table {
    
    function __construct() {
        $lead = Ticino_AI_Booking_Chatbot::is_lead_mode();
        parent::__construct(array(
            'singular' => $lead ? 'richiesta' : 'appuntamento',
            'plural'   => $lead ? 'richieste' : 'appuntamenti',
            'ajax'     => false
        ));
    }

    function get_columns() {
        $lead = Ticino_AI_Booking_Chatbot::is_lead_mode();
        $columns = array(
            'cb'         => '<input type="checkbox" />',
            'created_at' => 'Data Richiesta',
            'customer'   => 'Cliente',
            'service'    => $lead ? 'Richiesta per' : 'Servizio',
            'pref_date'  => 'Preferenza',
            'status'     => 'Stato',
            'actions'    => 'Azioni'
        );
        if ($lead) {
            unset($columns['pref_date']); // nessuna data in modalita' lead
        }
        return $columns;
    }

    function column_default($item, $column_name) {
        switch($column_name) {
            case 'created_at':
                return date('d/m/Y H:i', strtotime($item['created_at']));
            case 'customer':
                return '<strong>' . esc_html($item['customer_first_name'] . ' ' . $item['customer_last_name']) . '</strong><br>' . 
                       '<a href="mailto:' . esc_attr($item['customer_email']) . '">' . esc_html($item['customer_email']) . '</a><br>' .
                       esc_html($item['customer_phone']);
            case 'service':
                return esc_html($item['requested_service']);
            case 'pref_date':
                return esc_html($item['requested_date']) . '<br>' . esc_html($item['requested_time_slot']);
            case 'status':
                $status_labels = array(
                    'nuova'         => '<span class="ticino-badge ticino-badge-warning" style="background:#ff9800;color:#fff;">Nuova</span>',
                    'da_contattare' => '<span class="ticino-badge ticino-badge-warning" style="background:#ffc107;color:#000;">Da contattare</span>',
                    'contattata'    => '<span class="ticino-badge ticino-badge-primary" style="background:#2196f3;color:#fff;">Contattata</span>',
                    'confermata'    => '<span class="ticino-badge ticino-badge-success" style="background:#4caf50;color:#fff;">Confermata</span>',
                    'annullata'     => '<span class="ticino-badge ticino-badge-neutral" style="background:#9e9e9e;color:#fff;">' . (Ticino_AI_Booking_Chatbot::is_lead_mode() ? 'Archiviata' : 'Annullata') . '</span>',
                    'pending'   => '<span class="ticino-badge ticino-badge-warning">In attesa</span>',
                    'confirmed' => '<span class="ticino-badge ticino-badge-success">Confermato</span>',
                    'rejected'  => '<span class="ticino-badge ticino-badge-danger">Rifiutato</span>',
                    'cancelled' => '<span class="ticino-badge ticino-badge-neutral">Annullato</span>'
                );
                return isset($status_labels[$item['status']]) ? $status_labels[$item['status']] : '<span class="ticino-badge ticino-badge-neutral">'.$item['status'].'</span>';
            case 'actions':
                $detail_url = add_query_arg(array('page' => 'ticino-ai-booking-appointments', 'action' => 'view', 'id' => $item['id']), admin_url('admin.php'));
                $delete_url = wp_nonce_url(
                    add_query_arg(array(
                        'action' => 'ticino_ai_delete_appointment',
                        'appointment_id' => $item['id']
                    ), admin_url('admin-post.php')),
                    'ticino_ai_delete_appointment_' . $item['id']
                );
                return sprintf(
                    '<div style="display:inline-flex; gap:6px; align-items:center;">
                        <a href="%s" class="button" style="display:inline-flex; align-items:center; justify-content:center; text-align:center; height:32px; line-height:1; padding:0 12px; font-weight:500;">Gestisci</a>
                        <a href="%s" class="button" style="display:inline-flex; align-items:center; justify-content:center; text-align:center; height:32px; width:32px; padding:0; color:#d32f2f; border-color:#ffcdd2; background:#ffebee;" onclick="return confirm(\'Sei sicuro di voler eliminare definitivamente questa richiesta?\');" title="Elimina richiesta">
                            <span class="dashicons dashicons-trash" style="font-size:16px; width:16px; height:16px; display:inline-flex; align-items:center; justify-content:center; margin:0;"></span>
                        </a>
                    </div>',
                    esc_url($detail_url),
                    esc_url($delete_url)
                );
            default:
                return '';
        }
    }

    function column_cb($item) {
        return sprintf('<input type="checkbox" name="appointment[]" value="%s" />', $item['id']);
    }

    function get_bulk_actions() {
        return array(
            'bulk-delete' => 'Elimina'
        );
    }

    public function process_bulk_action() {
        if ('bulk-delete' === $this->current_action()) {
            if (!current_user_can('manage_options')) {
                wp_die('Permessi insufficienti.');
            }
            $ids = isset($_REQUEST['appointment']) ? array_map('intval', (array)$_REQUEST['appointment']) : array();
            if (!empty($ids)) {
                global $wpdb;
                $table = $wpdb->prefix . 'ticino_ai_appointments';
                $ids_imploded = implode(',', array_filter($ids));
                if (!empty($ids_imploded)) {
                    $wpdb->query("DELETE FROM $table WHERE id IN ($ids_imploded)");
                }
                wp_redirect(add_query_arg(array('page' => 'ticino-ai-booking-appointments', 'message' => 'deleted'), admin_url('admin.php')));
                exit;
            }
        }
    }

    function prepare_items() {
        $this->process_bulk_action();

        global $wpdb;
        $table = $wpdb->prefix . 'ticino_ai_appointments';
        $columns = $this->get_columns();
        $hidden = array();
        $sortable = array();
        
        $this->_column_headers = array($columns, $hidden, $sortable);

        $query = "SELECT * FROM $table WHERE 1=1";
        
        // Handle filter by status
        if (isset($_REQUEST['status']) && $_REQUEST['status'] !== 'all') {
            $status = sanitize_text_field($_REQUEST['status']);
            $query .= $wpdb->prepare(" AND status = %s", $status);
        }

        // Handle search
        if (!empty($_REQUEST['s'])) {
            $search = '%' . $wpdb->esc_like(sanitize_text_field($_REQUEST['s'])) . '%';
            $query .= $wpdb->prepare(" AND (customer_first_name LIKE %s OR customer_last_name LIKE %s OR customer_email LIKE %s OR customer_phone LIKE %s OR requested_service LIKE %s)", $search, $search, $search, $search, $search);
        }

        $query .= " ORDER BY created_at DESC";
        
        $data = $wpdb->get_results($query, ARRAY_A);

        $per_page = 20;
        $current_page = $this->get_pagenum();
        $total_items = count($data);

        $this->items = array_slice($data, (($current_page - 1) * $per_page), $per_page);

        $this->set_pagination_args(array(
            'total_items' => $total_items,
            'per_page'    => $per_page,
            'total_pages' => ceil($total_items / $per_page)
        ));
    }
}

class Ticino_AI_Booking_Appointments {

    public function handle_delete() {
        if (!current_user_can('manage_options')) {
            wp_die('Permessi insufficienti.');
        }

        $id = isset($_REQUEST['appointment_id']) ? intval($_REQUEST['appointment_id']) : (isset($_REQUEST['id']) ? intval($_REQUEST['id']) : 0);
        $nonce = isset($_REQUEST['_wpnonce']) ? $_REQUEST['_wpnonce'] : '';

        if (!$id || !wp_verify_nonce($nonce, 'ticino_ai_delete_appointment_' . $id)) {
            wp_die('Richiesta non valida o token scaduto.');
        }

        global $wpdb;
        $table = $wpdb->prefix . 'ticino_ai_appointments';
        $wpdb->delete($table, array('id' => $id));

        wp_redirect(add_query_arg(array('page' => 'ticino-ai-booking-appointments', 'message' => 'deleted'), admin_url('admin.php')));
        exit;
    }

    public function handle_get_delete() {
        if (isset($_GET['page']) && $_GET['page'] === 'ticino-ai-booking-appointments' && isset($_GET['action']) && $_GET['action'] === 'delete') {
            $this->handle_delete();
        }
    }

    public function handle_mark_contacted() {
        if (!current_user_can('manage_options') || !isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'ticino_ai_contact_nonce')) {
            wp_die('Richiesta non valida.');
        }

        $id = intval($_POST['appointment_id']);

        global $wpdb;
        $table = $wpdb->prefix . 'ticino_ai_appointments';

        $data = array('status' => 'contattata');
        if (isset($_POST['admin_notes'])) {
            $data['admin_notes'] = sanitize_textarea_field(wp_unslash($_POST['admin_notes']));
        }
        $wpdb->update($table, $data, array('id' => $id));

        wp_redirect(add_query_arg(array('page' => 'ticino-ai-booking-appointments', 'action' => 'view', 'id' => $id, 'message' => 'contacted'), admin_url('admin.php')));
        exit;
    }

    public function handle_confirmation() {
        if (!current_user_can('manage_options') || !isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'ticino_ai_confirm_nonce')) {
            wp_die('Richiesta non valida.');
        }

        $id = intval($_POST['appointment_id']);
        $date = sanitize_text_field($_POST['confirmed_date']);
        $time = sanitize_text_field($_POST['confirmed_time']);
        $notes = sanitize_textarea_field($_POST['admin_notes']);

        global $wpdb;
        $table = $wpdb->prefix . 'ticino_ai_appointments';
        
        $wpdb->update($table, array(
            'status' => 'confermata',
            'requested_date' => $date, // Aggiorniamo con la data confermata
            'requested_time_slot' => $time,
            'admin_notes' => $notes
        ), array('id' => $id));

        // Invia email di conferma
        $appt = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $id), ARRAY_A);
        
        if (class_exists('Ticino_AI_Booking_Email')) {
            $mailer = new Ticino_AI_Booking_Email();
            $full_name = $appt['customer_first_name'] . ' ' . $appt['customer_last_name'];
            $mailer->send_customer_confirmation($appt['customer_email'], $full_name, $appt['requested_service'], $date, $time);
        }

        // CalDAV Sync
        if (get_option('ticino_ai_caldav_enabled')) {
            if (class_exists('Ticino_AI_Booking_Caldav_Client')) {
                $caldav = new Ticino_AI_Booking_Caldav_Client();
                $result = $caldav->create_event($appt);
                if (is_wp_error($result)) {
                    $wpdb->update($table, array('calendar_sync_status' => 'error', 'calendar_sync_error' => $result->get_error_message()), array('id' => $id));
                } else {
                    $wpdb->update($table, array('calendar_sync_status' => 'synced', 'calendar_event_id' => $result), array('id' => $id));
                }
            }
        }

        wp_redirect(add_query_arg(array('page' => 'ticino-ai-booking-appointments', 'message' => 'confirmed'), admin_url('admin.php')));
        exit;
    }

    public function handle_rejection() {
        if (!current_user_can('manage_options') || !isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'ticino_ai_reject_nonce')) {
            wp_die('Richiesta non valida.');
        }

        $id = intval($_POST['appointment_id']);
        
        global $wpdb;
        $table = $wpdb->prefix . 'ticino_ai_appointments';
        
        $wpdb->update($table, array('status' => 'annullata'), array('id' => $id));

        // Invia email di rifiuto. Se il form espone la scelta (modalita' lead, "Archivia"),
        // l'email parte solo se l'admin ha spuntato "Avvisa il cliente".
        $notify = empty($_POST['has_notify_option']) || !empty($_POST['notify_customer']);
        $appt = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $id), ARRAY_A);
        if ($notify && class_exists('Ticino_AI_Booking_Email')) {
            $mailer = new Ticino_AI_Booking_Email();
            $full_name = $appt['customer_first_name'] . ' ' . $appt['customer_last_name'];
            $mailer->send_customer_rejection($appt['customer_email'], $full_name);
        }

        wp_redirect(add_query_arg(array('page' => 'ticino-ai-booking-appointments', 'message' => 'rejected'), admin_url('admin.php')));
        exit;
    }
}
