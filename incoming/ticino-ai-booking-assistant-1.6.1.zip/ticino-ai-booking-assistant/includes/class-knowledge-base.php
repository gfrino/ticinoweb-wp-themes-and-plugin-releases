<?php

class Ticino_AI_Booking_Knowledge_Base {

    public function ajax_save() {
        check_ajax_referer('ticino_ai_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permessi insufficienti');
        }

        $type = isset($_POST['kb_type']) ? sanitize_text_field($_POST['kb_type']) : '';
        $data = isset($_POST['kb_data']) ? wp_unslash($_POST['kb_data']) : '';

        // Decode JSON safely
        $decoded = json_decode($data, true);
        if ($decoded === null && $data !== '[]') {
             // Se non è JSON valido e non era vuoto, forse è plain text (es. company desc)
             if ($type === 'company_desc') {
                 update_option('ticino_ai_kb_company_desc', sanitize_textarea_field($data));
                 wp_send_json_success();
             } else {
                 wp_send_json_error('Formato dati non valido');
             }
        }

        switch ($type) {
            case 'services':
                // Sanitizza l'array dei servizi
                $sanitized = array();
                foreach ($decoded as $item) {
                    $sanitized[] = array(
                        'id' => isset($item['id']) ? sanitize_text_field($item['id']) : wp_generate_uuid4(),
                        'title' => sanitize_text_field($item['title']),
                        'category' => sanitize_text_field($item['category']),
                        'duration' => sanitize_text_field($item['duration']),
                        'description' => sanitize_textarea_field($item['description'])
                    );
                }
                update_option('ticino_ai_kb_services', json_encode($sanitized));
                break;
            case 'techs':
            case 'products':
                $sanitized = array_map('sanitize_text_field', $decoded);
                update_option("ticino_ai_kb_{$type}", json_encode($sanitized));
                break;
            case 'faq':
                $sanitized = array();
                foreach ($decoded as $item) {
                    $sanitized[] = array(
                        'q' => sanitize_text_field($item['q']),
                        'a' => sanitize_textarea_field($item['a'])
                    );
                }
                update_option('ticino_ai_kb_faq', json_encode($sanitized));
                break;
        }

        wp_send_json_success();
    }

    public function ajax_delete() {
        check_ajax_referer('ticino_ai_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permessi insufficienti');
        }
        
        // Logica per cancellazione singolo item se necessario, 
        // per ora si fa sovrascrittura totale via JS
        wp_send_json_success();
    }

    public function ajax_reindex_site() {
        check_ajax_referer('ticino_ai_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permessi insufficienti');
        }

        // Forza ricaricamento indice e statistiche
        $stats = Ticino_AI_Booking_Dynamic_Site_Knowledge::get_site_stats(true);
        Ticino_AI_Booking_Dynamic_Site_Knowledge::get_full_site_knowledge_context(true);

        wp_send_json_success($stats);
    }
}
