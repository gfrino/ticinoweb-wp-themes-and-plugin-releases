<?php

class Ticino_AI_Booking_Email {

    public function send_customer_request_received($appointment_id, $customer_email, $customer_name, $service) {
        $subject = get_option('ticino_ai_email_req_subject');
        $body = get_option('ticino_ai_email_req_body');

        $replacements = array(
            '{customer_name}' => $customer_name,
            '{service}' => $service,
            '{company_name}' => get_option('ticino_ai_company_name'),
            '{company_phone}' => get_option('ticino_ai_company_phone'),
            '{company_address}' => get_option('ticino_ai_company_address'),
        );

        $body = str_replace(array_keys($replacements), array_values($replacements), $body);
        
        return wp_mail($customer_email, $subject, wpautop($body), array('Content-Type: text/html; charset=UTF-8'));
    }

    /**
     * Notifica all'azienda di una nuova richiesta dal chatbot.
     * In modalita' lead il testo parla di "richiesta di contatto" e omette data e fascia oraria.
     *
     * @param array $contact ['email' => ..., 'phone' => ...] recapiti del cliente (dalla 1.2.0)
     */
    public function send_admin_new_request_notification($appointment_id, $customer_name, $service, $date, $time, $notes = '', $contact = array()) {
        $admin_email = get_option('ticino_ai_company_email');
        if (empty($admin_email)) return false;

        $lead_mode = class_exists('Ticino_AI_Booking_Chatbot') && Ticino_AI_Booking_Chatbot::is_lead_mode();
        $customer_name = esc_html($customer_name);
        $service = esc_html($service);
        $c_email = !empty($contact['email']) ? esc_html($contact['email']) : '';
        $c_phone = !empty($contact['phone']) ? esc_html($contact['phone']) : '';

        if ($lead_mode) {
            $subject = "Nuova richiesta di contatto dal sito - " . $customer_name;
            $body = "Hai ricevuto una nuova richiesta di informazioni tramite AI WEB Agent.<br><br>
                     Cliente: $customer_name<br>";
        } else {
            $subject = "Nuova richiesta appuntamento da confermare - " . $customer_name;
            $body = "Hai ricevuto una nuova richiesta di appuntamento tramite AI WEB Agent.<br><br>
                     Cliente: $customer_name<br>";
        }
        if ($c_email !== '') {
            $body .= "Email: <a href=\"mailto:$c_email\">$c_email</a><br>";
        }
        if ($c_phone !== '') {
            $body .= "Telefono: $c_phone<br>";
        }
        $body .= ($lead_mode ? "Richiesta per: " : "Servizio: ") . $service . "<br>";
        if (!$lead_mode) {
            $body .= "Data Richiesta: " . esc_html($date) . "<br>
                      Fascia Oraria: " . esc_html($time) . "<br>";
        }

        if (!empty($notes)) {
            $body .= "Note: " . nl2br(esc_html($notes)) . "<br><br>";
        } else {
            $body .= "<br>";
        }

        $detail_url = admin_url('admin.php?page=ticino-ai-booking-appointments&action=view&id=' . (int) $appointment_id);
        $body .= $lead_mode
            ? "Ricontatta il cliente e poi segna la richiesta come contattata nel pannello: <a href=\"" . esc_url($detail_url) . "\">apri la richiesta</a>."
            : "Accedi al pannello per confermare o rifiutare: <a href=\"" . esc_url($detail_url) . "\">apri la richiesta</a>.";

        return wp_mail($admin_email, $subject, wpautop($body), array('Content-Type: text/html; charset=UTF-8'));
    }

    public function send_customer_confirmation($customer_email, $customer_name, $service, $confirmed_date, $confirmed_time) {
        $subject = get_option('ticino_ai_email_conf_subject');
        $body = get_option('ticino_ai_email_conf_body');

        $replacements = array(
            '{customer_name}' => $customer_name,
            '{service}' => $service,
            '{confirmed_date}' => $confirmed_date,
            '{confirmed_time}' => $confirmed_time,
            '{company_name}' => get_option('ticino_ai_company_name'),
            '{company_phone}' => get_option('ticino_ai_company_phone'),
            '{company_address}' => get_option('ticino_ai_company_address'),
        );

        $body = str_replace(array_keys($replacements), array_values($replacements), $body);
        
        return wp_mail($customer_email, $subject, wpautop($body), array('Content-Type: text/html; charset=UTF-8'));
    }

    public function send_customer_rejection($customer_email, $customer_name) {
        $subject = get_option('ticino_ai_email_rej_subject');
        $body = get_option('ticino_ai_email_rej_body');

        $replacements = array(
            '{customer_name}' => $customer_name,
            '{company_name}' => get_option('ticino_ai_company_name'),
            '{company_phone}' => get_option('ticino_ai_company_phone'),
            '{company_address}' => get_option('ticino_ai_company_address'),
        );

        $body = str_replace(array_keys($replacements), array_values($replacements), $body);
        
        return wp_mail($customer_email, $subject, wpautop($body), array('Content-Type: text/html; charset=UTF-8'));
    }

}
