jQuery(document).ready(function($) {

    let currentGenType = '';
    let generatedContentRaw = '';

    $('.ai-gen-btn').on('click', function(e) {
        e.preventDefault();

        const btn = $(this);
        const type = btn.data('type');
        const category = $('#ticino_ai_treatment_category').val();
        const postTitle = $('#ai-post-title').text();
        const postId = $('#post_ID').val();

        if(!postId) {
            alert("Devi prima salvare la pagina in bozza per avere un ID valido.");
            return;
        }

        // Reset UI
        $('.ai-metabox-preview-area').slideDown();
        $('#ai-preview-content').html('<em>Generazione in corso... Attendi, potrebbe richiedere alcuni secondi.</em>');
        $('#ai-loading-spinner').css('display', 'inline-block');
        $('#ai-btn-insert-editor, #ai-btn-insert-excerpt').hide();
        $('#ai-copy-notice').hide();
        
        currentGenType = type;
        
        // Disable buttons
        $('.ai-gen-btn').prop('disabled', true);

        $.ajax({
            url: ticino_ai_metabox_obj.ajax_url,
            type: 'POST',
            data: {
                action: 'ticino_ai_generate_treatment_content',
                nonce: ticino_ai_metabox_obj.nonce,
                post_id: postId,
                gen_type: type,
                category: category,
                post_title: postTitle
            },
            success: function(response) {
                if (response.success) {
                    generatedContentRaw = response.data.generated;
                    
                    // Mostra l'anteprima formattata se HTML, altrimenti testuale
                    if(type === 'content' || type === 'faq') {
                        $('#ai-preview-content').html(generatedContentRaw);
                    } else {
                        $('#ai-preview-content').text(generatedContentRaw);
                    }

                    // Mostra bottoni di inserimento specifici
                    if(type === 'content' || type === 'faq') {
                        $('#ai-btn-insert-editor').show();
                    } else if (type === 'excerpt') {
                        $('#ai-btn-insert-excerpt').show();
                    }

                } else {
                    $('#ai-preview-content').html('<span style="color:red;">Errore: ' + response.data.message + '</span>');
                }
            },
            error: function() {
                $('#ai-preview-content').html('<span style="color:red;">Errore di connessione al server.</span>');
            },
            complete: function() {
                $('#ai-loading-spinner').hide();
                $('.ai-gen-btn').prop('disabled', false);
            }
        });
    });

    $('#ai-btn-copy').on('click', function() {
        if(!generatedContentRaw) return;
        
        navigator.clipboard.writeText(generatedContentRaw).then(function() {
            $('#ai-copy-notice').fadeIn().delay(2000).fadeOut();
        }, function(err) {
            console.error('Errore durante la copia: ', err);
            alert("Non è stato possibile copiare il testo. Copialo manualmente dall'anteprima.");
        });
    });

    $('#ai-btn-insert-editor').on('click', function() {
        if(!generatedContentRaw) return;

        let confirmed = confirm("Vuoi inserire questo contenuto nell'editor?\nSe l'editor ha già contenuto, verrà aggiunto alla fine.");
        if(!confirmed) return;

        // Se siamo in Gutenberg (Block Editor)
        if (wp.data && wp.data.select('core/editor')) {
            // Crea un blocco custom html o block group
            const block = wp.blocks.createBlock('core/html', { content: generatedContentRaw });
            wp.data.dispatch('core/block-editor').insertBlocks([block]);
            alert("Blocco HTML inserito nell'editor!");
        } 
        // Se siamo nel Classic Editor o TinyMCE
        else if (typeof tinymce !== 'undefined' && tinymce.activeEditor && !tinymce.activeEditor.isHidden()) {
            tinymce.activeEditor.execCommand('mceInsertContent', false, generatedContentRaw);
            alert("Contenuto inserito nell'editor!");
        } 
        // Fallback editor testuale classico
        else if ($('#content').length) {
            let currentContent = $('#content').val();
            $('#content').val(currentContent + "\n\n" + generatedContentRaw);
            alert("Contenuto accodato nell'editor di testo!");
        } else {
            alert("Editor non trovato. Ti consigliamo di usare il pulsante Copia.");
        }
    });

    $('#ai-btn-insert-excerpt').on('click', function() {
        if(!generatedContentRaw) return;

        if ($('#excerpt').length) {
            $('#excerpt').val(generatedContentRaw);
            alert("Riassunto aggiornato! Ricordati di salvare la pagina.");
            
            // Aggiorna UI se presente in Gutenberg
            if (wp.data && wp.data.dispatch('core/editor')) {
                wp.data.dispatch('core/editor').editPost({ excerpt: generatedContentRaw });
            }
        } else {
            alert("Campo excerpt non visibile o non trovato. Prova ad attivarlo dalle Opzioni Schermata o copia il testo manualmente.");
        }
    });

});
