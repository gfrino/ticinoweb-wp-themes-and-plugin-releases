jQuery(document).ready(function($) {
    
    var conversationHistory = [];
    var $container = $('#ticino-ai-chatbot-container');
    var $trigger = $('#ticino-ai-chatbot-trigger');
    var $window = $('#ticino-ai-chatbot-window');
    var $messages = $('#ticino-ai-chatbot-messages');
    var $input = $('#ticino-ai-user-input');
    var $sendBtn = $('#ticino-ai-send-btn');
    var $minimizeBtn = $('#ticino-ai-chatbot-minimize');
    var $qrContainer = $('#ticino-ai-chatbot-quick-replies');

    // Modalita' (Impostazioni > Generale): 'booking' = appuntamenti (chiede anche giorno e fascia oraria),
    // 'lead' = generazione contatti (nome, telefono, email, esigenza, note: nessuna data).
    var cfg = (typeof ticino_ai_chatbot !== 'undefined') ? ticino_ai_chatbot : {};
    var isLead = cfg.mode === 'lead';

    // La pagina può arrivare dalla cache (es. QUIC.cloud) con un nonce scaduto o di un altro utente:
    // WordPress risponde 403 rest_cookie_invalid_nonce. Gli endpoint sono pubblici, quindi si riprova senza nonce.
    var nonceRejected = false;
    function isNonceError(status, data) {
        return status === 403 && data && data.code === 'rest_cookie_invalid_nonce';
    }
    var companyName = cfg.company_name || '';
    var companyLabel = companyName || (isLead ? "l'azienda" : 'il centro');

    // State Machine
    // states: 'normal', 'booking_name', 'booking_phone', 'booking_email', 'booking_service', 'booking_day', 'booking_time', 'booking_notes', 'booking_confirm'
    // In modalita' lead gli stati 'booking_day' e 'booking_time' vengono saltati.
    var chatState = 'normal';
    var bookingData = {
        first_name: '',
        last_name: '',
        phone: '',
        email: '',
        service: '',
        date: '',
        time: '',
        notes: ''
    };

    // Retrieve from session storage if exists
    if (sessionStorage.getItem('ticino_ai_chatState')) {
        chatState = sessionStorage.getItem('ticino_ai_chatState');
    }
    if (sessionStorage.getItem('ticino_ai_bookingData')) {
        bookingData = JSON.parse(sessionStorage.getItem('ticino_ai_bookingData'));
    }
    if (sessionStorage.getItem('ticino_ai_convHistory')) {
        conversationHistory = JSON.parse(sessionStorage.getItem('ticino_ai_convHistory'));
    }

    // Init
    function initBot() {
        if (conversationHistory.length === 0) {
            if (ticino_ai_chatbot.greeting) {
                addMessage(ticino_ai_chatbot.greeting, 'bot');
                conversationHistory.push({role: 'model', content: ticino_ai_chatbot.greeting});
                saveSession();
            }
        } else {
            // Restore messages visually
            conversationHistory.forEach(function(msg) {
                var role = msg.role === 'model' ? 'bot' : 'user';
                addMessageHTML(msg.content, role);
            });
            scrollToBottom();
            
            // Re-trigger current state prompts if in booking flow
            if (chatState !== 'normal') {
                showQuickRepliesForState(chatState);
            }
        }
    }

    initBot();

    // La finestra della chat resta chiusa finche' l'utente non clicca sul trigger (v1.0.17).

    function saveSession() {
        sessionStorage.setItem('ticino_ai_chatState', chatState);
        sessionStorage.setItem('ticino_ai_bookingData', JSON.stringify(bookingData));
        sessionStorage.setItem('ticino_ai_convHistory', JSON.stringify(conversationHistory));
    }
    
    function resetSession() {
        chatState = 'normal';
        bookingData = { first_name: '', last_name: '', phone: '', email: '', service: '', date: '', time: '', notes: '' };
        saveSession();
        $qrContainer.hide();
    }

    // Toggle Window
    $trigger.on('click', function() {
        if ($container.hasClass('ticino-ai-chatbot-open')) {
            closeBot();
        } else {
            openBot();
        }
    });

    $minimizeBtn.on('click', closeBot);
    $('#ticino-ai-chatbot-overlay').on('click', closeBot);

    function openBot() {
        $container.addClass('ticino-ai-chatbot-open');
        $trigger.find('.icon-chat').hide();
        $trigger.find('.icon-close').show();
        setTimeout(function(){ $input.focus(); }, 300);
    }

    function closeBot() {
        $container.removeClass('ticino-ai-chatbot-open');
        $trigger.find('.icon-close').hide();
        $trigger.find('.icon-chat').show();
    }

    // Process User Input
    function processInput(text) {
        if (!text || text.trim() === '') return;
        
        addMessage(text, 'user');
        $input.val('');
        $qrContainer.hide();

        conversationHistory.push({role: 'user', content: text});
        saveSession();

        if (chatState === 'normal') {
            if (isBookingTrigger(text)) {
                startBookingFlow();
                return;
            }
            sendToAI(text);
        } else {
            handleBookingFlow(text);
        }
    }

    // Frasi che avviano direttamente il form senza passare dall'AI
    function isBookingTrigger(text) {
        var msg = (text || '').toLowerCase().trim().replace(/[.!?]+$/, '');
        var triggers = [
            'vorrei prenotare', 'vorrei prenotare un appuntamento', 'voglio prenotare', 'richiedi un appuntamento', 'prenota',
            'vorrei informazioni', 'richiedi informazioni', 'vorrei un preventivo', 'richiedi un preventivo',
            'vorrei essere ricontattato', 'vorrei essere ricontattata', 'lascia una richiesta'
        ];
        return triggers.indexOf(msg) !== -1;
    }

    function startBookingFlow() {
        chatState = 'booking_name';
        saveSession();
        var reply = cfg.booking_intro ? cfg.booking_intro : (isLead
            ? "Volentieri! Raccolgo la tua richiesta e " + companyLabel + " ti ricontatterà al più presto. Ti farò alcune brevi domande.\n\nCome ti chiami (Nome e Cognome)?"
            : "Certamente! Posso raccogliere la tua richiesta di appuntamento. Ti farò alcune brevi domande e " + companyLabel + " ti ricontatterà per confermare giorno e orario.\n\nCome ti chiami (Nome e Cognome)?");
        addMessage(reply, 'bot');
        conversationHistory.push({role: 'model', content: reply});
        saveSession();
    }

    // Regex Utils
    function validateEmail(email) {
        var re = /\S+@\S+\.\S+/;
        return re.test(email);
    }
    
    function validatePhone(phone) {
        var re = /^[0-9\+\-\(\)\s]{6,}$/;
        return re.test(phone);
    }

    function handleBookingFlow(text) {
        var reply = '';
        var t = text.trim();

        if (t.toLowerCase() === 'annulla' || t.toLowerCase() === 'annulla richiesta') {
            resetSession();
            addMessage("Richiesta annullata. Come posso aiutarti?", 'bot');
            return;
        }

        switch (chatState) {
            case 'booking_name':
                if (t.length < 2) {
                    addMessage("Per favore, inserisci un nome valido.", 'bot');
                    return;
                }
                var parts = t.split(' ');
                bookingData.first_name = parts[0];
                bookingData.last_name = parts.length > 1 ? parts.slice(1).join(' ') : '';
                chatState = 'booking_phone';
                reply = "Grazie " + bookingData.first_name + ". Qual è il tuo numero di telefono?";
                break;
                
            case 'booking_phone':
                if (!validatePhone(t)) {
                    addMessage("Il numero inserito non sembra valido. Puoi controllarlo e scriverlo nuovamente?", 'bot');
                    return;
                }
                bookingData.phone = t;
                chatState = 'booking_email';
                reply = "Perfetto. Qual è il tuo indirizzo email?";
                break;
                
            case 'booking_email':
                if (!validateEmail(t)) {
                    addMessage("L'email inserita non sembra valida. Puoi controllarla e scriverla nuovamente?", 'bot');
                    return;
                }
                bookingData.email = t;
                chatState = 'booking_service';
                reply = isLead
                    ? "Per quale prodotto, servizio o lavorazione vorresti informazioni o un preventivo?"
                    : "Per quale servizio vorresti prenotare o avere informazioni?";
                break;

            case 'booking_service':
                bookingData.service = t;
                if (isLead) {
                    // Modalita' lead: nessuna data, si passa direttamente alla descrizione dell'esigenza
                    bookingData.date = '';
                    bookingData.time = '';
                    chatState = 'booking_notes';
                    reply = "Descrivi brevemente la tua esigenza (quantità, materiali, tempistiche o altri dettagli utili). Scrivi 'Nessuna nota' se preferisci essere semplicemente ricontattato.";
                } else {
                    chatState = 'booking_day';
                    reply = "Quando preferiresti venire?";
                }
                break;

            case 'booking_day':
                bookingData.date = t;
                chatState = 'booking_time';
                reply = "In quale fascia oraria preferiresti venire?";
                break;

            case 'booking_time':
                bookingData.time = t;
                chatState = 'booking_notes';
                reply = "Vuoi aggiungere un messaggio o una nota alla tua richiesta? (Scrivi 'Nessuna nota' se non hai altro da aggiungere)";
                break;

            case 'booking_notes':
                bookingData.notes = t.toLowerCase() !== 'nessuna nota' ? t : '';
                chatState = 'booking_confirm';
                
                reply = "Controlla i dati della tua richiesta:\n\n" +
                        "**Nome:** " + bookingData.first_name + " " + bookingData.last_name + "\n" +
                        "**Telefono:** " + bookingData.phone + "\n" +
                        "**Email:** " + bookingData.email + "\n" +
                        (isLead ? "**Richiesta per:** " : "**Servizio:** ") + bookingData.service + "\n";
                if (!isLead) {
                    reply += "**Giorno preferito:** " + bookingData.date + "\n" +
                             "**Fascia oraria:** " + bookingData.time + "\n";
                }
                reply += "**Note:** " + (bookingData.notes || "Nessuna") + "\n\n" +
                         "Confermi l'invio della richiesta? Ho letto e accetto l'informativa sulla privacy.";
                break;

            case 'booking_confirm':
                if (t.toLowerCase() === 'conferma richiesta' || t.toLowerCase() === 'sì' || t.toLowerCase() === 'confermo') {
                    submitBooking();
                    return;
                } else if (t.toLowerCase() === 'modifica dati' || t.toLowerCase() === 'modifica') {
                    chatState = 'booking_name';
                    reply = "Va bene, ricominciamo. Come ti chiami?";
                } else {
                    addMessage("Usa i pulsanti per confermare, modificare o annullare.", 'bot');
                    showQuickRepliesForState(chatState);
                    return;
                }
                break;
        }

        saveSession();
        addMessage(reply, 'bot');
        conversationHistory.push({role: 'model', content: reply});
        saveSession();
        
        showQuickRepliesForState(chatState);
    }

    function showQuickRepliesForState(state) {
        $qrContainer.empty().hide();
        var buttons = [];
        
        if (state === 'booking_service' && ticino_ai_chatbot.services) {
            ticino_ai_chatbot.services.forEach(function(s) {
                buttons.push($('<button>').addClass('ticino-ai-qr').text(s.title).data('val', s.title));
            });
            buttons.push($('<button>').addClass('ticino-ai-qr btn-cancel').text("Annulla").data('val', 'Annulla'));
        }
        else if (state === 'booking_day') {
            buttons.push($('<button>').addClass('ticino-ai-qr').text("Il prima possibile").data('val', "Il prima possibile"));
            buttons.push($('<button>').addClass('ticino-ai-qr').text("Questa settimana").data('val', "Questa settimana"));
            buttons.push($('<button>').addClass('ticino-ai-qr').text("La prossima settimana").data('val', "La prossima settimana"));
            buttons.push($('<button>').addClass('ticino-ai-qr btn-cancel').text("Annulla").data('val', 'Annulla'));
        }
        else if (state === 'booking_time') {
            buttons.push($('<button>').addClass('ticino-ai-qr').text("Mattina").data('val', "Mattina"));
            buttons.push($('<button>').addClass('ticino-ai-qr').text("Pausa pranzo").data('val', "Pausa pranzo"));
            buttons.push($('<button>').addClass('ticino-ai-qr').text("Pomeriggio").data('val', "Pomeriggio"));
            buttons.push($('<button>').addClass('ticino-ai-qr').text("Sera").data('val', "Sera"));
            buttons.push($('<button>').addClass('ticino-ai-qr').text("Indifferente").data('val', "Indifferente"));
            buttons.push($('<button>').addClass('ticino-ai-qr btn-cancel').text("Annulla").data('val', 'Annulla'));
        }
        else if (state === 'booking_notes') {
            buttons.push($('<button>').addClass('ticino-ai-qr').text("Nessuna nota").data('val', "Nessuna nota"));
            buttons.push($('<button>').addClass('ticino-ai-qr btn-cancel').text("Annulla").data('val', 'Annulla'));
        }
        else if (state === 'booking_confirm') {
            buttons.push($('<button>').addClass('ticino-ai-qr').text("Conferma richiesta").data('val', "Conferma richiesta"));
            buttons.push($('<button>').addClass('ticino-ai-qr').text("Modifica dati").data('val', "Modifica dati"));
            buttons.push($('<button>').addClass('ticino-ai-qr btn-cancel').text("Annulla").data('val', 'Annulla'));
        }
        else if (state === 'normal') {
            // Bottoni configurabili da Impostazioni > Chatbot UI > Bottoni Rapidi (vuoto = disattivati)
            var quickReplies = (typeof ticino_ai_chatbot !== 'undefined' && Array.isArray(ticino_ai_chatbot.quick_replies)) ? ticino_ai_chatbot.quick_replies : [];
            quickReplies.forEach(function(qr) {
                if (qr && qr.label) {
                    buttons.push(
                        $('<button>').addClass('ticino-ai-qr').text(qr.label)
                            .data('val', qr.value || qr.label)
                            .data('action', qr.action || 'ai')
                            .data('reply', qr.reply || '')
                            .data('url', qr.url || '')
                    );
                }
            });
        }

        if (buttons.length > 0) {
            buttons.forEach(function(btn) {
                $qrContainer.append(btn);
            });
            $qrContainer.show();
        }
    }
    
    // Mostra il messaggio dell'utente e lo salva nello storico senza inviarlo all'AI
    function pushUserMessage(text) {
        addMessage(text, 'user');
        $input.val('');
        $qrContainer.hide();
        conversationHistory.push({role: 'user', content: text});
        saveSession();
    }

    $qrContainer.on('click', '.ticino-ai-qr', function() {
        var $btn   = $(this);
        var text   = $btn.data('val');
        var action = chatState === 'normal' ? ($btn.data('action') || 'ai') : 'ai';

        if (action === 'booking') {
            pushUserMessage($btn.text());
            startBookingFlow();
            return;
        }
        if (action === 'reply' && $btn.data('reply')) {
            pushUserMessage($btn.text());
            var fixed = String($btn.data('reply'));
            addMessage(fixed, 'bot');
            conversationHistory.push({role: 'model', content: fixed});
            saveSession();
            showQuickRepliesForState('normal');
            return;
        }
        if (action === 'link' && $btn.data('url')) {
            window.open(String($btn.data('url')), '_blank', 'noopener');
            return;
        }
        processInput(text);
    });

    if (chatState === 'normal') {
        showQuickRepliesForState('normal');
    }

    // Chiamata al backend con timeout lato browser e un secondo tentativo sugli errori di rete
    function sendToAI(text, attempt) {
        attempt = attempt || 1;
        showTyping();

        var controller = (typeof AbortController !== 'undefined') ? new AbortController() : null;
        var timer = controller ? setTimeout(function() { controller.abort(); }, 45000) : null;

        fetch(ticino_ai_chatbot.rest_url + 'chat', {
            method: 'POST',
            headers: nonceRejected ? { 'Content-Type': 'application/json' } : {
                'Content-Type': 'application/json',
                'X-WP-Nonce': ticino_ai_chatbot.nonce
            },
            // lingua della pagina (WPML / tW Translate Plus la mettono in <html lang>): l'AI risponde in quella lingua
            body: JSON.stringify({ messages: conversationHistory.slice(-10), lang: document.documentElement.lang || '' }),
            signal: controller ? controller.signal : undefined
        })
        .then(function(response) {
            return response.json().then(function(data) { return {status: response.status, data: data}; });
        })
        .then(function(res) {
            if (timer) clearTimeout(timer);
            hideTyping();
            var data = res.data || {};
            if (res.status === 200 && data.success && data.message) {
                addMessage(data.message, 'bot');
                conversationHistory.push({role: 'model', content: data.message});
                saveSession();
                showQuickRepliesForState('normal');
                return;
            }
            if (!nonceRejected && isNonceError(res.status, data)) {
                nonceRejected = true;
                sendToAI(text, attempt);
                return;
            }
            console.error('AI WEB Agent Chat Error:', { status: res.status, data: data });
            if (attempt < 2 && res.status >= 500) {
                sendToAI(text, attempt + 1);
                return;
            }
            handleFallback(text);
        })
        .catch(function(error) {
            if (timer) clearTimeout(timer);
            hideTyping();
            console.error('AI WEB Agent Chat Fetch Error:', error);
            if (attempt < 2) {
                setTimeout(function() { sendToAI(text, attempt + 1); }, 800);
                return;
            }
            handleFallback(text);
        });
    }

    function handleFallback(userMessage) {
        var fallbackReply = 'Sto avendo un problema tecnico momentaneo, ma posso comunque raccogliere i tuoi dati per farti ricontattare da ' + companyLabel + '.';

        if (isBookingTrigger(userMessage)) {
            startBookingFlow();
        } else {
            addMessage(fallbackReply, 'bot');
            $qrContainer.empty().hide();
            $qrContainer.append($('<button>').addClass('ticino-ai-qr')
                .text(isLead ? "Sì, lascia una richiesta" : "Sì, richiedi un appuntamento")
                .data('val', isLead ? "Vorrei informazioni" : "Vorrei prenotare"));
            $qrContainer.append($('<button>').addClass('ticino-ai-qr btn-cancel').text("No, continua la chat").data('val', "Vorrei altre informazioni"));
            $qrContainer.show();
        }
    }

    $sendBtn.on('click', function() {
        processInput($input.val());
    });

    $input.on('keypress', function(e) {
        if (e.which == 13) {
            processInput($input.val());
        }
    });

    function submitBooking() {
        var data = {
            first_name: bookingData.first_name,
            last_name: bookingData.last_name,
            email: bookingData.email,
            phone: bookingData.phone,
            service: bookingData.service,
            date: bookingData.date,
            time: bookingData.time,
            notes: bookingData.notes,
            privacy: true
        };

        showTyping();
        $input.prop('disabled', true);
        $qrContainer.hide();

        $.ajax({
            url: ticino_ai_chatbot.rest_url + 'appointment',
            method: 'POST',
            beforeSend: function (xhr) {
                if (!nonceRejected) xhr.setRequestHeader('X-WP-Nonce', ticino_ai_chatbot.nonce);
            },
            data: data,
            success: function(response) {
                hideTyping();
                $input.prop('disabled', false);
                // Testo configurabile in Impostazioni > Chatbot UI > Messaggio di conferma invio
                var successReply = cfg.success_message ? cfg.success_message : 'Grazie, la tua richiesta è stata inviata correttamente. Ti ricontatteremo al più presto.';
                addMessage(successReply, 'bot');
                conversationHistory.push({role: 'model', content: successReply});
                resetSession();
                showQuickRepliesForState('normal');
            },
            error: function(xhr) {
                if (!nonceRejected && isNonceError(xhr.status, xhr.responseJSON)) {
                    nonceRejected = true;
                    submitBooking();
                    return;
                }
                hideTyping();
                $input.prop('disabled', false);
                addMessage("Errore durante l'invio della richiesta. Per favore riprova.", 'bot');
                showQuickRepliesForState('booking_confirm');
            }
        });
    }

    function addMessage(text, sender) {
        addMessageHTML(text, sender);
        scrollToBottom();
    }
    
    function addMessageHTML(text, sender) {
        var formatted = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        formatted = formatted.replace(/\n/g, '<br>');
        
        var msgHtml = '<div class="ticino-ai-msg ticino-ai-msg-' + sender + '">' + formatted + '</div>';
        $messages.append(msgHtml);
    }

    function showTyping() {
        var typingHtml = '<div id="ticino-ai-typing" class="ticino-ai-typing"><span></span><span></span><span></span></div>';
        $messages.append(typingHtml);
        scrollToBottom();
    }

    function hideTyping() {
        $('#ticino-ai-typing').remove();
    }

    function scrollToBottom() {
        $messages.scrollTop($messages[0].scrollHeight);
    }

});
