jQuery(document).ready(function($) {
    
    // --- Gestione Tabs Generali ---
    $('.ticino-tab-link').on('click', function(e) {
        e.preventDefault();
        var target = $(this).attr('href');
        
        // Rimuovi classe active dai tab links nello stesso contenitore nav
        $(this).closest('.ticino-tabs-nav').find('.ticino-tab-link').removeClass('active');
        $(this).addClass('active');
        
        // Nascondi tutti i contenuti dei tab
        var $wrapper = $(this).closest('.ticino-wrap');
        if ($wrapper.length === 0) $wrapper = $(document);
        
        $wrapper.find('.ticino-tab-pane').removeClass('active');
        $wrapper.find(target).addClass('active');
    });

    // --- Copia Variabili negli Appunti ---
    $('.ticino-variable').on('click', function() {
        var textToCopy = $(this).text();
        var $btn = $(this);
        
        navigator.clipboard.writeText(textToCopy).then(function() {
            var originalText = $btn.text();
            $btn.text('Copiato!');
            $btn.css('background-color', 'var(--ticino-success)');
            $btn.css('color', 'white');
            
            setTimeout(function() {
                $btn.text(originalText);
                $btn.css('background-color', '');
                $btn.css('color', '');
            }, 1500);
        });
    });

    // --- Live Preview Email ---
    function updateEmailPreview() {
        var bodyId = $('.ticino-tab-pane.active textarea').attr('id');
        if (!bodyId) return;
        
        var bodyContent = $('#' + bodyId).val() || '';
        
        // Sostituzioni fittizie per l'anteprima
        bodyContent = bodyContent.replace(/{customer_name}/g, 'Maria Rossi');
        bodyContent = bodyContent.replace(/{service}/g, 'Servizio di esempio');
        bodyContent = bodyContent.replace(/{confirmed_date}/g, '15 luglio 2026');
        bodyContent = bodyContent.replace(/{confirmed_time}/g, '14:30');
        bodyContent = bodyContent.replace(/{company_name}/g, 'La Tua Azienda SA');
        bodyContent = bodyContent.replace(/{company_phone}/g, '+41 91 000 00 00');
        bodyContent = bodyContent.replace(/{company_address}/g, 'Via Esempio 1, 6900 Lugano');
        
        // Converti newlines in <br>
        bodyContent = bodyContent.replace(/\n/g, '<br>');
        
        $('.ticino-email-preview-inner').html(bodyContent);
    }

    // Aggiorna preview all'input e al cambio tab
    $('.ticino-tab-pane textarea').on('input', updateEmailPreview);
    $('.ticino-tab-link').on('click', function() {
        setTimeout(updateEmailPreview, 50);
    });
    
    // Init preview
    if ($('.ticino-email-preview-inner').length) {
        updateEmailPreview();
    }

    // --- Gestione Accordion Knowledge Base ---
    $('.ticino-kb-header').on('click', function() {
        var $accordion = $(this).closest('.ticino-kb-accordion');
        $accordion.toggleClass('open');
        
        // Opzionale: chiudi gli altri
        // $('.ticino-kb-accordion').not($accordion).removeClass('open');
    });

    // --- Gestione Modelli AI ---
    $('#ticino-ai-model-select').on('change', function() {
        if ($(this).val() === 'custom') {
            $('#ticino-ai-custom-model-wrapper').slideDown();
        } else {
            $('#ticino-ai-custom-model-wrapper').slideUp();
        }
    });

    $('#update-gemini-2').on('click', function() {
        $('#ticino-ai-model-select').val('gemini-2.0-flash');
        $('#ticino-ai-model-select').closest('form').submit();
    });

    // --- Verifica modelli disponibili ---
    $('#check-gemini-models').on('click', function(e) {
        e.preventDefault();
        var key = $('input[name="ticino_ai_gemini_api_key"]').val();
        if(!key) {
            $('#check-gemini-models-result').html('<span style="color:var(--ticino-danger); font-weight:500;">Inserisci e salva una chiave API prima di verificare.</span>');
            return;
        }

        var $btn = $(this);
        $btn.prop('disabled', true).text('Verifica in corso...');
        $('#check-gemini-models-result').html('<span style="color:var(--ticino-primary);">⏳ Recupero modelli da Google...</span>');

        $.ajax({
            url: ticino_ai_admin.ajax_url,
            method: 'POST',
            data: {
                action: 'ticino_list_gemini_models',
                nonce: ticino_ai_admin.nonce,
                api_key: key
            },
            success: function(response) {
                $btn.prop('disabled', false).text('Verifica modelli disponibili');
                if(response.success) {
                    var html = '<div style="margin-top: 10px; padding: 10px; border: 1px solid var(--ticino-border); border-radius: 4px; background: #fff;">';
                    html += '<strong style="display:block; margin-bottom:8px;">Modelli supportati:</strong><ul style="margin:0; padding-left:20px;">';
                    response.data.forEach(function(m) {
                        html += '<li><code>' + m + '</code></li>';
                    });
                    html += '</ul></div>';
                    $('#check-gemini-models-result').html(html);
                } else {
                    $('#check-gemini-models-result').html('<span style="color:var(--ticino-danger); font-weight:600;">❌ ' + (response.data || 'Errore') + '</span>');
                }
            },
            error: function() {
                $btn.prop('disabled', false).text('Verifica modelli disponibili');
                $('#check-gemini-models-result').html('<span style="color:var(--ticino-danger); font-weight:600;">❌ Errore di rete</span>');
            }
        });
    });

    // --- Provider AI: mostra solo il pannello del provider selezionato ---
    $('.ticino-ai-provider-radio').on('change', function() {
        var provider = $('.ticino-ai-provider-radio:checked').val();
        $('.ticino-provider-pane').hide();
        $('#ticino-provider-' + provider).show();
    });

    $('#ticino-ai-openai-model-select').on('change', function() {
        if ($(this).val() === 'custom') {
            $('#ticino-ai-openai-custom-model-wrapper').slideDown();
        } else {
            $('#ticino-ai-openai-custom-model-wrapper').slideUp();
        }
    });

    // --- OpenAI: verifica modelli disponibili ---
    $('#check-openai-models').on('click', function(e) {
        e.preventDefault();
        var key = $('input[name="ticino_ai_openai_api_key"]').val();
        if(!key) {
            $('#check-openai-models-result').html('<span style="color:var(--ticino-danger); font-weight:500;">Inserisci una chiave API prima di verificare.</span>');
            return;
        }
        var $btn = $(this);
        $btn.prop('disabled', true).text('Verifica in corso...');
        $('#check-openai-models-result').html('<span style="color:var(--ticino-primary);">⏳ Recupero modelli da OpenAI...</span>');

        $.ajax({
            url: ticino_ai_admin.ajax_url,
            method: 'POST',
            data: { action: 'ticino_list_openai_models', nonce: ticino_ai_admin.nonce, api_key: key },
            success: function(response) {
                $btn.prop('disabled', false).text('Verifica modelli disponibili');
                if(response.success) {
                    var html = '<div style="margin-top: 10px; padding: 10px; border: 1px solid var(--ticino-border); border-radius: 4px; background: #fff;">';
                    html += '<strong style="display:block; margin-bottom:8px;">Modelli chat disponibili:</strong><ul style="margin:0; padding-left:20px;">';
                    response.data.forEach(function(m) { html += '<li><code>' + m + '</code></li>'; });
                    html += '</ul></div>';
                    $('#check-openai-models-result').html(html);
                } else {
                    $('#check-openai-models-result').html('<span style="color:var(--ticino-danger); font-weight:600;">❌ ' + (response.data || 'Errore') + '</span>');
                }
            },
            error: function() {
                $btn.prop('disabled', false).text('Verifica modelli disponibili');
                $('#check-openai-models-result').html('<span style="color:var(--ticino-danger); font-weight:600;">❌ Errore di rete</span>');
            }
        });
    });

    // --- OpenAI: test API Key ---
    $('#test-openai-key').on('click', function(e) {
        e.preventDefault();
        var key = $('input[name="ticino_ai_openai_api_key"]').val();
        if(!key) {
            $('#test-openai-result').html('<span style="color:var(--ticino-danger); font-weight:500;">Inserisci prima una chiave.</span>');
            return;
        }
        var selectedModel = $('#ticino-ai-openai-model-select').val();
        if (selectedModel === 'custom') {
            selectedModel = $('#ticino-ai-openai-custom-model').val();
            if(!selectedModel) {
                $('#test-openai-result').html('<span style="color:var(--ticino-danger); font-weight:500;">Inserisci il nome del modello personalizzato.</span>');
                return;
            }
        }
        var $btn = $(this);
        $btn.prop('disabled', true).text('Test in corso...');
        $('#test-openai-result').html('<span style="color:var(--ticino-primary);">⏳ Connessione a OpenAI...</span>');

        $.ajax({
            url: ticino_ai_admin.ajax_url,
            method: 'POST',
            data: { action: 'ticino_test_openai_key', nonce: ticino_ai_admin.nonce, api_key: key, model: selectedModel },
            success: function(response) {
                $btn.prop('disabled', false).text('Test API Key');
                if(response.success) {
                    $('#test-openai-result').html('<span style="color:var(--ticino-success); font-weight:600;">✅ ' + response.data + '</span>');
                } else {
                    $('#test-openai-result').html('<span style="color:var(--ticino-danger); font-weight:600;">❌ ' + (response.data || 'Errore') + '</span>');
                }
            },
            error: function() {
                $btn.prop('disabled', false).text('Test API Key');
                $('#test-openai-result').html('<span style="color:var(--ticino-danger); font-weight:600;">❌ Errore di rete</span>');
            }
        });
    });

    // --- Test API Key Gemini ---
    $('#test-gemini-key').on('click', function(e) {
        e.preventDefault();
        var key = $('input[name="ticino_ai_gemini_api_key"]').val();
        if(!key) {
            $('#test-gemini-result').html('<span style="color:var(--ticino-danger); font-weight:500;">Inserisci prima una chiave.</span>');
            return;
        }
        
        var selectedModel = $('#ticino-ai-model-select').val();
        if (selectedModel === 'custom') {
            selectedModel = $('#ticino-ai-custom-model').val();
            if(!selectedModel) {
                $('#test-gemini-result').html('<span style="color:var(--ticino-danger); font-weight:500;">Inserisci il nome del modello personalizzato.</span>');
                return;
            }
        }

        var $btn = $(this);
        $btn.prop('disabled', true).text('Test in corso...');
        $('#test-gemini-result').html('<span style="color:var(--ticino-primary);">⏳ Connessione a Google...</span>');
        
        $.ajax({
            url: ticino_ai_admin.ajax_url,
            method: 'POST',
            data: {
                action: 'ticino_test_gemini_key',
                nonce: ticino_ai_admin.nonce,
                api_key: key,
                model: selectedModel
            },
            success: function(response) {
                $btn.prop('disabled', false).text('Test API Key');
                if(response.success) {
                    $('#test-gemini-result').html('<span style="color:var(--ticino-success); font-weight:600;">✅ ' + response.data + '</span>');
                } else {
                    $('#test-gemini-result').html('<span style="color:var(--ticino-danger); font-weight:600;">❌ ' + (response.data || 'Errore') + '</span>');
                }
            },
            error: function() {
                $btn.prop('disabled', false).text('Test API Key');
                $('#test-gemini-result').html('<span style="color:var(--ticino-danger); font-weight:600;">❌ Errore di rete</span>');
            }
        });
    });


    // --- Bottoni rapidi: repeater ---
    var $qrTable = $('#ticino-ai-qr-table tbody');
    function qrReindex() {
        $qrTable.find('tr.ticino-ai-qr-row').each(function(i) {
            $(this).find('input, select, textarea').each(function() {
                this.name = this.name.replace(/ticino_ai_quick_replies\[[^\]]*\]/, 'ticino_ai_quick_replies[' + i + ']');
            });
        });
    }
    // Mostra solo il campo dettaglio coerente con l'azione scelta
    function qrSyncDetail($row) {
        var action = $row.find('.ticino-ai-qr-action').val();
        $row.find('.ticino-ai-qr-detail').hide().filter('[data-for="' + action + '"]').show();
    }
    $qrTable.find('tr.ticino-ai-qr-row').each(function() { qrSyncDetail($(this)); });
    $qrTable.on('change', '.ticino-ai-qr-action', function() { qrSyncDetail($(this).closest('tr')); });
    $('#ticino-ai-qr-add').on('click', function(e) {
        e.preventDefault();
        if ($qrTable.find('tr.ticino-ai-qr-row').length >= 8) { alert('Massimo 8 bottoni rapidi.'); return; }
        $qrTable.append($('#ticino-ai-qr-row-template').html());
        qrReindex();
        qrSyncDetail($qrTable.find('tr.ticino-ai-qr-row:last'));
        $qrTable.find('tr.ticino-ai-qr-row:last input[type=text]:first').focus();
    });
    $qrTable.on('click', '.ticino-ai-qr-remove', function(e) {
        e.preventDefault();
        $(this).closest('tr').remove();
        qrReindex();
    });
    $('#ticino-ai-qr-reset').on('click', function(e) {
        e.preventDefault();
        // Default forniti dal PHP in base alla modalita' (appuntamenti / lead)
        var defaults = (typeof ticino_ai_admin !== 'undefined' && Array.isArray(ticino_ai_admin.qr_defaults) && ticino_ai_admin.qr_defaults.length)
            ? ticino_ai_admin.qr_defaults
            : [
                ['Vorrei prenotare un appuntamento', 'Vorrei prenotare', 'booking'],
                ['Quali servizi offrite?', 'Quali servizi offrite?', 'ai'],
                ['Orari e contatti', 'Orari e contatti', 'ai']
            ];
        $qrTable.empty();
        defaults.forEach(function(d) {
            var $row = $($('#ticino-ai-qr-row-template').html());
            $row.find('input[type=text]').eq(0).val(d[0]);
            $row.find('input[type=text]').eq(1).val(d[1]);
            $row.find('.ticino-ai-qr-action').val(d[2]);
            $qrTable.append($row);
            qrSyncDetail($row);
        });
        qrReindex();
    });

});
