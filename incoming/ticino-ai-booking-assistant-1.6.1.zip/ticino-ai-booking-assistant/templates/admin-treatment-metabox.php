<?php
if ( ! defined( 'ABSPATH' ) ) exit;
?>

<div class="ticino-ai-treatment-metabox-wrapper">
    <div class="ai-metabox-status-panel">
        <p><strong>Titolo:</strong> <span id="ai-post-title"><?php echo esc_html( $post->post_title ); ?></span></p>
        <p><strong>Immagine in evidenza:</strong> <?php echo $has_thumbnail; ?></p>
        <p><strong>Riassunto (Excerpt):</strong> <?php echo $has_excerpt; ?></p>
        <p><strong>Contenuto:</strong> <?php echo $has_content; ?></p>
    </div>

    <div class="ai-metabox-category-panel">
        <label for="ticino_ai_treatment_category"><strong>Categoria Servizio:</strong></label>
        <select name="ticino_ai_treatment_category" id="ticino_ai_treatment_category" style="width: 100%; margin-top: 5px;">
            <option value="Generico" <?php selected($current_category, 'Generico'); ?>>Generico</option>
            <option value="Viso" <?php selected($current_category, 'Viso'); ?>>Viso</option>
            <option value="Corpo" <?php selected($current_category, 'Corpo'); ?>>Corpo</option>
            <option value="Beauty" <?php selected($current_category, 'Beauty'); ?>>Beauty</option>
            <option value="Epilazione" <?php selected($current_category, 'Epilazione'); ?>>Epilazione</option>
            <option value="Mani e piedi" <?php selected($current_category, 'Mani e piedi'); ?>>Mani e piedi</option>
            <option value="Massaggi" <?php selected($current_category, 'Massaggi'); ?>>Massaggi</option>
        </select>
        <p class="description">Aiuta l'AI a contestualizzare la generazione.</p>
    </div>

    <hr>

    <div class="ai-metabox-actions">
        <button type="button" class="button ai-gen-btn" data-type="excerpt">Genera Descrizione Breve</button>
        <button type="button" class="button button-primary ai-gen-btn" data-type="content">Genera Contenuto Completo</button>
        <button type="button" class="button ai-gen-btn" data-type="faq">Genera FAQ</button>
        <button type="button" class="button ai-gen-btn" data-type="seo">Genera SEO (Meta)</button>
        <button type="button" class="button ai-gen-btn" data-type="image">Genera Prompt Immagine</button>
    </div>

    <div class="ai-metabox-preview-area" style="display: none;">
        <h4>Anteprima Contenuto Generato <span class="spinner is-active" id="ai-loading-spinner" style="display:none; float:none;"></span></h4>
        <div id="ai-preview-content" class="ai-preview-box">
            <!-- Il contenuto verrà iniettato qui per la preview -->
        </div>
        
        <div class="ai-preview-actions" style="margin-top: 10px;">
            <button type="button" class="button" id="ai-btn-copy">Copia Testo</button>
            <button type="button" class="button button-primary" id="ai-btn-insert-editor" style="display:none;">Inserisci nell'Editor</button>
            <button type="button" class="button" id="ai-btn-insert-excerpt" style="display:none;">Usa come Excerpt</button>
            <span id="ai-copy-notice" style="color: green; display: none; margin-left: 10px;">Copiato!</span>
        </div>
    </div>
</div>
