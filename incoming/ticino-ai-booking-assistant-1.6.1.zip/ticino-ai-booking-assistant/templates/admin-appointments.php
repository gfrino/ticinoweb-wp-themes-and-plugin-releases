<?php $is_lead = Ticino_AI_Booking_Chatbot::is_lead_mode(); ?>
<div class="wrap ticino-wrap">
    <div class="ticino-header">
        <div>
            <h1><?php echo $is_lead ? 'Richieste di contatto' : 'Appuntamenti'; ?></h1>
            <p><?php echo $is_lead
                ? 'Contatti raccolti dal chatbot: ricontatta il cliente ai recapiti indicati, poi segna la richiesta come contattata oppure archiviala.'
                : 'Conferma o rifiuta le richieste raccolte dal chatbot. Gli appuntamenti vengono sincronizzati con Apple Calendar solo dopo la conferma manuale.'; ?></p>
        </div>
    </div>

    <?php
    $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : '';
    $id = isset($_GET['id']) ? intval($_GET['id']) : 0;

    if (isset($_GET['message'])) {
        if ($_GET['message'] === 'confirmed') {
            echo '<div class="notice notice-success is-dismissible"><p>Appuntamento confermato e notifiche inviate.</p></div>';
        } elseif ($_GET['message'] === 'rejected') {
            echo '<div class="notice notice-warning is-dismissible"><p>' . ($is_lead ? 'Richiesta archiviata.' : 'Appuntamento rifiutato e notifica inviata al cliente.') . '</p></div>';
        } elseif ($_GET['message'] === 'contacted') {
            echo '<div class="notice notice-success is-dismissible"><p>Richiesta segnata come contattata.</p></div>';
        } elseif ($_GET['message'] === 'deleted') {
            echo '<div class="notice notice-success is-dismissible"><p>Richiesta eliminata con successo.</p></div>';
        }
    }

    global $wpdb;
    $table = $wpdb->prefix . 'ticino_ai_appointments';

    if ($action === 'view' && $id > 0) {
        $appt = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $id), ARRAY_A);

        if (!$appt) {
            echo '<div class="ticino-empty-state"><h3>Appuntamento non trovato.</h3></div>';
        } else {
            // Status badge logic
            $status_class = 'ticino-badge-neutral';
            $status_label = ucfirst($appt['status']);
            if ($appt['status'] == 'nuova' || $appt['status'] == 'pending') { $status_class = 'ticino-badge-warning'; $status_label = 'Nuova'; }
            if ($appt['status'] == 'da_contattare') { $status_class = 'ticino-badge-warning'; $status_label = 'Da contattare'; }
            if ($appt['status'] == 'contattata') { $status_class = 'ticino-badge-primary'; $status_label = 'Contattata'; }
            if ($appt['status'] == 'confermata' || $appt['status'] == 'confirmed') { $status_class = 'ticino-badge-success'; $status_label = 'Confermata'; }
            if ($appt['status'] == 'annullata' || $appt['status'] == 'rejected') { $status_class = 'ticino-badge-danger'; $status_label = $is_lead ? 'Archiviata' : 'Annullata'; }
            $is_closed = in_array($appt['status'], array('confermata', 'confirmed', 'annullata', 'rejected'), true);
            ?>
            
            <div class="ticino-grid ticino-grid-layout">
                <!-- Colonna Sinistra: Dettagli Cliente e Richiesta -->
                <div class="ticino-grid" style="gap:20px; align-content: flex-start;">
                    
                    <div class="ticino-card">
                        <div class="ticino-card-title">
                            <span class="dashicons dashicons-id"></span> Scheda Cliente
                            <span class="ticino-badge <?php echo $status_class; ?>" style="margin-left:auto;"><?php echo $status_label; ?></span>
                        </div>
                        <p style="font-size:18px; font-weight:600; margin:0 0 10px 0;">
                            <?php echo esc_html($appt['customer_first_name'] . ' ' . $appt['customer_last_name']); ?>
                        </p>
                        <ul class="ticino-checklist">
                            <li><span class="dashicons dashicons-email"></span> <a href="mailto:<?php echo esc_attr($appt['customer_email']); ?>"><?php echo esc_html($appt['customer_email']); ?></a></li>
                            <li><span class="dashicons dashicons-phone"></span> <a href="tel:<?php echo esc_attr($appt['customer_phone']); ?>"><?php echo esc_html($appt['customer_phone']); ?></a></li>
                            <li><span class="dashicons dashicons-privacy"></span> Privacy Consenso: <?php echo $appt['privacy_consent'] ? '<strong>Sì</strong>' : 'No'; ?></li>
                        </ul>
                    </div>

                    <div class="ticino-card">
                        <div class="ticino-card-title">
                            <span class="dashicons dashicons-clipboard"></span> Dettagli Richiesta
                        </div>
                        <ul class="ticino-checklist">
                            <li><strong><?php echo $is_lead ? 'Richiesta per:' : 'Servizio Richiesto:'; ?></strong> <br><?php echo esc_html($appt['requested_service']); ?></li>
                            <?php if (!$is_lead): ?>
                            <li><strong>Data Preferita:</strong> <br><?php echo esc_html($appt['requested_date']); ?></li>
                            <li><strong>Fascia Oraria:</strong> <br><?php echo esc_html($appt['requested_time_slot']); ?></li>
                            <?php endif; ?>
                            <li><strong>Ricevuta il:</strong> <br><?php echo esc_html(date_i18n('d/m/Y H:i', strtotime($appt['created_at']))); ?></li>
                        </ul>
                        <?php if (!empty($appt['notes'])): ?>
                            <hr style="border: 0; border-top: 1px solid var(--ticino-border); margin: 15px 0;">
                            <p style="margin:0; font-weight:600;">Note dell'utente:</p>
                            <p style="margin:5px 0 0 0; background:var(--ticino-bg); padding:10px; border-radius:8px; font-style:italic;">
                                <?php echo nl2br(esc_html($appt['notes'])); ?>
                            </p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Colonna Destra: Azioni e Note Admin -->
                <div>
                    <?php if ($is_lead && !$is_closed): ?>
                        <?php if ($appt['status'] !== 'contattata'): ?>
                        <div class="ticino-card" style="border: 1px solid var(--ticino-primary); background: #f0f7fd;">
                            <div class="ticino-card-title" style="color: var(--ticino-primary);">
                                <span class="dashicons dashicons-phone"></span> Gestione contatto
                            </div>
                            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                                <input type="hidden" name="action" value="ticino_ai_contact_appointment">
                                <input type="hidden" name="appointment_id" value="<?php echo $id; ?>">
                                <?php wp_nonce_field('ticino_ai_contact_nonce'); ?>
                                <div class="ticino-form-group">
                                    <label>Note interne</label>
                                    <textarea name="admin_notes" rows="3" placeholder="Es. chiamato il 14/09, invia offerta entro venerdì..."><?php echo esc_textarea($appt['admin_notes']); ?></textarea>
                                </div>
                                <button type="submit" class="button button-primary button-hero" style="width:100%; justify-content:center; display:flex;">
                                    Segna come contattata
                                </button>
                                <p class="ticino-helper-text" style="margin-top:8px;">Nessuna email viene inviata al cliente: sei tu a ricontattarlo ai recapiti indicati.</p>
                            </form>
                        </div>
                        <?php else: ?>
                        <div class="ticino-card">
                            <div class="ticino-card-title"><span class="dashicons dashicons-yes"></span> Contatto gestito</div>
                            <p style="margin:0 0 10px 0;">Richiesta già segnata come contattata il <?php echo esc_html(date_i18n('d/m/Y H:i', strtotime($appt['updated_at']))); ?>.</p>
                            <p style="margin:0; font-weight:600;">Note interne:</p>
                            <p style="background:var(--ticino-bg); padding:10px; border-radius:8px; margin:5px 0 0 0;">
                                <?php echo !empty($appt['admin_notes']) ? nl2br(esc_html($appt['admin_notes'])) : '<em>Nessuna nota inserita.</em>'; ?>
                            </p>
                        </div>
                        <?php endif; ?>

                        <div class="ticino-card" style="margin-top:20px; border: 1px solid var(--ticino-border);">
                            <div class="ticino-card-title">
                                <span class="dashicons dashicons-archive"></span> Archivia richiesta
                            </div>
                            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                                <input type="hidden" name="action" value="ticino_ai_reject_appointment">
                                <input type="hidden" name="appointment_id" value="<?php echo $id; ?>">
                                <input type="hidden" name="has_notify_option" value="1">
                                <?php wp_nonce_field('ticino_ai_reject_nonce'); ?>
                                <label style="font-weight:normal; display:block; margin-bottom:12px;">
                                    <input type="checkbox" name="notify_customer" value="1"> Avvisa il cliente via email (template «Richiesta Archiviata»)
                                </label>
                                <button type="submit" class="button" style="width:100%; justify-content:center; display:flex;" onclick="return confirm('Archiviare questa richiesta?');">
                                    Archivia
                                </button>
                            </form>
                        </div>

                    <?php elseif (!$is_closed): ?>
                        <div class="ticino-card" style="border: 1px solid var(--ticino-primary); background: #f0f7fd;">
                            <div class="ticino-card-title" style="color: var(--ticino-primary);">
                                <span class="dashicons dashicons-calendar-alt"></span> Conferma Definitiva
                            </div>
                            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                                <input type="hidden" name="action" value="ticino_ai_confirm_appointment">
                                <input type="hidden" name="appointment_id" value="<?php echo $id; ?>">
                                <?php wp_nonce_field('ticino_ai_confirm_nonce'); ?>
                                
                                <div class="ticino-form-group">
                                    <label>Data Effettiva</label>
                                    <input type="date" name="confirmed_date" value="<?php echo esc_attr($appt['requested_date']); ?>" required>
                                </div>
                                <div class="ticino-form-group">
                                    <label>Ora Effettiva</label>
                                    <!-- Use requested_time_slot as text or time depending on formatting -->
                                    <input type="text" name="confirmed_time" value="<?php echo esc_attr($appt['requested_time_slot']); ?>" required>
                                </div>
                                <div class="ticino-form-group">
                                    <label>Note Interne / Apple Calendar</label>
                                    <textarea name="admin_notes" rows="3" placeholder="Queste note verranno salvate nell'evento del calendario..."></textarea>
                                </div>
                                
                                <button type="submit" class="button button-primary button-hero" style="width:100%; justify-content:center; display:flex;">
                                    Conferma Appuntamento & Notifica Cliente
                                </button>
                            </form>
                        </div>
                        
                        <div class="ticino-card" style="margin-top:20px; border: 1px solid var(--ticino-danger); background: #fef2f2;">
                            <div class="ticino-card-title" style="color: var(--ticino-danger);">
                                <span class="dashicons dashicons-no-alt"></span> Rifiuta o Annulla
                            </div>
                            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                                <input type="hidden" name="action" value="ticino_ai_reject_appointment">
                                <input type="hidden" name="appointment_id" value="<?php echo $id; ?>">
                                <?php wp_nonce_field('ticino_ai_reject_nonce'); ?>
                                <button type="submit" class="button" style="color: var(--ticino-danger); border-color:var(--ticino-danger); width:100%; justify-content:center; display:flex;" onclick="return confirm('Sicuro di voler annullare questa richiesta? Il cliente riceverà un\'email di notifica.');">
                                    Annulla Richiesta
                                </button>
                            </form>
                        </div>

                    <?php else: ?>
                        <div class="ticino-card">
                            <div class="ticino-card-title">
                                <span class="dashicons dashicons-backup"></span> Registro Operazioni
                            </div>
                            <ul class="ticino-checklist">
                                <li><strong>Data Richiesta:</strong> <?php echo esc_html($appt['created_at']); ?></li>
                                <li><strong>Ultima Modifica:</strong> <?php echo esc_html($appt['updated_at']); ?></li>
                            </ul>
                            <hr style="border: 0; border-top: 1px solid var(--ticino-border); margin: 15px 0;">
                            <p><strong>Note interne Admin:</strong></p>
                            <p style="background:var(--ticino-bg); padding:10px; border-radius:8px;">
                                <?php echo !empty($appt['admin_notes']) ? nl2br(esc_html($appt['admin_notes'])) : '<em>Nessuna nota inserita.</em>'; ?>
                            </p>
                            
                            <?php if ($appt['status'] === 'confermata' || $appt['status'] === 'confirmed'): ?>
                                <hr style="border: 0; border-top: 1px solid var(--ticino-border); margin: 15px 0;">
                                
                                <?php 
                                $sync_class = 'ticino-badge-neutral';
                                if (strpos(strtolower($appt['calendar_sync_status']), 'success') !== false || $appt['calendar_sync_status'] == 'synced') $sync_class = 'ticino-badge-success';
                                elseif (strpos(strtolower($appt['calendar_sync_status']), 'error') !== false || $appt['calendar_sync_status'] == 'failed') $sync_class = 'ticino-badge-danger';
                                ?>
                                
                                <p><strong>Apple Calendar Sync:</strong> <span class="ticino-badge <?php echo $sync_class; ?>"><?php echo esc_html($appt['calendar_sync_status']); ?></span></p>
                                
                                <?php if (!empty($appt['calendar_sync_error'])): ?>
                                    <p style="color:var(--ticino-danger); font-size:13px; background:var(--ticino-danger-bg); padding:8px; border-radius:4px;">
                                        <strong>Errore:</strong> <?php echo esc_html($appt['calendar_sync_error']); ?>
                                    </p>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    
                    <div style="margin-top: 20px;">
                        <a href="<?php echo admin_url('admin.php?page=ticino-ai-booking-appointments'); ?>" class="button">&larr; Torna alla lista</a>
                    </div>
                </div>
            </div>
            <?php
        }
    } else {
        // TABELLA PRINCIPALE
        
        $status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : 'all';
        $count_all = $wpdb->get_var("SELECT COUNT(*) FROM $table");
        $count_nuova = $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE status IN ('nuova', 'pending')");
        $count_da_contattare = $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE status = 'da_contattare'");
        $count_contattata = $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE status = 'contattata'");
        $count_confermata = $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE status IN ('confermata', 'confirmed')");
        $count_annullata = $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE status IN ('annullata', 'rejected')");
        ?>
        
        <div class="ticino-tabs-nav" style="border:none; margin-bottom:15px; padding:0;">
            <a href="?page=ticino-ai-booking-appointments&status=all" class="ticino-tab-link <?php echo $status_filter === 'all' ? 'active' : ''; ?>">
                Tutte <span class="ticino-badge ticino-badge-neutral" style="margin-left:4px;"><?php echo $count_all; ?></span>
            </a>
            <a href="?page=ticino-ai-booking-appointments&status=nuova" class="ticino-tab-link <?php echo $status_filter === 'nuova' ? 'active' : ''; ?>">
                Nuove <span class="ticino-badge ticino-badge-warning" style="margin-left:4px; background:#ff9800; color:#fff;"><?php echo $count_nuova; ?></span>
            </a>
            <a href="?page=ticino-ai-booking-appointments&status=da_contattare" class="ticino-tab-link <?php echo $status_filter === 'da_contattare' ? 'active' : ''; ?>">
                Da contattare <span class="ticino-badge ticino-badge-warning" style="margin-left:4px; background:#ffc107; color:#000;"><?php echo $count_da_contattare; ?></span>
            </a>
            <a href="?page=ticino-ai-booking-appointments&status=contattata" class="ticino-tab-link <?php echo $status_filter === 'contattata' ? 'active' : ''; ?>">
                Contattate <span class="ticino-badge ticino-badge-primary" style="margin-left:4px; background:#2196f3; color:#fff;"><?php echo $count_contattata; ?></span>
            </a>
            <?php if (!$is_lead): ?>
            <a href="?page=ticino-ai-booking-appointments&status=confermata" class="ticino-tab-link <?php echo $status_filter === 'confermata' ? 'active' : ''; ?>">
                Confermate <span class="ticino-badge ticino-badge-success" style="margin-left:4px; background:#4caf50; color:#fff;"><?php echo $count_confermata; ?></span>
            </a>
            <?php endif; ?>
            <a href="?page=ticino-ai-booking-appointments&status=annullata" class="ticino-tab-link <?php echo $status_filter === 'annullata' ? 'active' : ''; ?>">
                <?php echo $is_lead ? 'Archiviate' : 'Annullate'; ?> <span class="ticino-badge ticino-badge-neutral" style="margin-left:4px; background:#9e9e9e; color:#fff;"><?php echo $count_annullata; ?></span>
            </a>
        </div>
        
        <div class="ticino-card" style="padding:0; overflow:hidden;">
            <?php
            // Assicuriamoci che class-appointments gestisca il $_GET['status']
            $list_table = new Ticino_AI_Appointments_Table();
            $list_table->prepare_items();
            
            if (empty($list_table->items) && empty($_REQUEST['s'])) {
                ?>
                <div class="ticino-empty-state">
                    <span class="dashicons dashicons-<?php echo $is_lead ? 'id-alt' : 'calendar-alt'; ?>"></span>
                    <h3><?php echo $is_lead ? 'Nessuna richiesta di contatto' : 'Nessuna richiesta appuntamento'; ?></h3>
                    <p>Le richieste inviate tramite chatbot appariranno qui.<br><?php echo $is_lead ? 'Potrai ricontattare i clienti, segnarle come contattate o archiviarle.' : 'Potrai confermarle, rifiutarle e gestirle manualmente.'; ?></p>
                </div>
                <?php
            } else {
                ?>
                <form method="post" style="padding: 15px;">
                    <?php 
                    $list_table->search_box('Cerca per nome, email...', 'search_id');
                    $list_table->display(); 
                    ?>
                </form>
                <?php
            }
            ?>
        </div>
        <?php
    }
    ?>
</div>
