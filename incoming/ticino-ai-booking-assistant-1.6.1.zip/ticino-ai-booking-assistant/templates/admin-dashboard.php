<?php $is_lead = Ticino_AI_Booking_Chatbot::is_lead_mode(); ?>
<div class="wrap ticino-wrap">

    <div class="ticino-header">
        <div>
            <h1>AI WEB Agent</h1>
            <p>Gestisci chatbot, <?php echo $is_lead ? 'richieste di contatto' : 'richieste appuntamento'; ?>, knowledge base, email e integrazioni del tuo assistente AI.
               <span class="ticino-badge ticino-badge-neutral">Modalità: <?php echo $is_lead ? 'Generazione contatti (lead)' : 'Appuntamenti'; ?></span></p>
        </div>
        <div class="ticino-header-actions">
            <?php 
            $ai_provider = get_option('ticino_ai_provider', 'gemini') === 'openai' ? 'openai' : 'gemini';
            $ai_label    = $ai_provider === 'openai' ? 'OpenAI' : 'Gemini';
            $gemini_key  = $ai_provider === 'openai' ? get_option('ticino_ai_openai_api_key') : get_option('ticino_ai_gemini_api_key');
            $auto_show = get_option('ticino_ai_auto_show');
            ?>
            <span class="ticino-badge <?php echo ($auto_show === 'yes') ? 'ticino-badge-success' : 'ticino-badge-neutral'; ?>">
                Chatbot: <?php echo ($auto_show === 'yes') ? 'Attivo in Homepage' : 'Nascosto (Shortcode)'; ?>
            </span>
            <span class="ticino-badge <?php echo !empty($gemini_key) ? 'ticino-badge-success' : 'ticino-badge-warning'; ?>">
                <?php echo esc_html($ai_label); ?>: <?php echo !empty($gemini_key) ? 'Configurato' : 'Manca API Key'; ?>
            </span>
            <a href="<?php echo admin_url('admin.php?page=ticino-ai-booking-settings'); ?>" class="button button-primary">Impostazioni</a>
        </div>
    </div>

    <?php
    global $wpdb;
    $table_appt = $wpdb->prefix . 'ticino_ai_appointments';
    
    // Stats (stati reali: nuova / da_contattare / contattata / confermata / annullata, piu' i legacy pending/confirmed/rejected)
    $count_pending = $wpdb->get_var("SELECT COUNT(*) FROM $table_appt WHERE status IN ('nuova', 'pending', 'da_contattare')");
    $count_confirmed = $is_lead
        ? $wpdb->get_var("SELECT COUNT(*) FROM $table_appt WHERE status = 'contattata'")
        : $wpdb->get_var("SELECT COUNT(*) FROM $table_appt WHERE status IN ('confermata', 'confirmed')");
    $count_rejected = $wpdb->get_var("SELECT COUNT(*) FROM $table_appt WHERE status IN ('annullata', 'rejected')");
    
    // Config Status checks
    $kb_services = json_decode(get_option('ticino_ai_kb_services', '[]'), true);
    $has_company = get_option('ticino_ai_company_name') !== '';
    $has_gemini = !empty($gemini_key);
    $has_kb = !empty($kb_services);
    $has_email = get_option('ticino_ai_company_email') !== '';
    $caldav_enabled = get_option('ticino_ai_caldav_enabled') == '1';
    $has_caldav = $caldav_enabled && get_option('ticino_ai_caldav_pass') !== '';
    ?>

    <div class="ticino-grid ticino-grid-cols-4" style="margin-bottom: 24px;">
        <div class="ticino-card ticino-stat-card">
            <div class="ticino-stat-icon">
                <span class="dashicons dashicons-clock"></span>
            </div>
            <div class="ticino-stat-content">
                <h3><?php echo intval($count_pending); ?></h3>
                <p>Richieste in attesa</p>
            </div>
        </div>
        <div class="ticino-card ticino-stat-card">
            <div class="ticino-stat-icon" style="color: var(--ticino-success);">
                <span class="dashicons dashicons-yes-alt"></span>
            </div>
            <div class="ticino-stat-content">
                <h3><?php echo intval($count_confirmed); ?></h3>
                <p><?php echo $is_lead ? 'Contattate' : 'Confermati'; ?></p>
            </div>
        </div>
        <div class="ticino-card ticino-stat-card">
            <div class="ticino-stat-icon" style="color: var(--ticino-danger);">
                <span class="dashicons dashicons-dismiss"></span>
            </div>
            <div class="ticino-stat-content">
                <h3><?php echo intval($count_rejected); ?></h3>
                <p><?php echo $is_lead ? 'Archiviate' : 'Rifiutati'; ?></p>
            </div>
        </div>
        <div class="ticino-card ticino-stat-card">
            <div class="ticino-stat-icon" style="color: var(--ticino-warning);">
                <span class="dashicons dashicons-format-chat"></span>
            </div>
            <div class="ticino-stat-content">
                <h3>AI</h3>
                <p><?php echo $has_gemini ? 'Online' : 'Offline'; ?></p>
            </div>
        </div>
    </div>

    <div class="ticino-grid ticino-grid-layout">
        
        <!-- Left Col: Ultimi Appuntamenti -->
        <div class="ticino-card">
            <div class="ticino-card-title">
                <span class="dashicons dashicons-list-view"></span>
                <?php echo $is_lead ? 'Ultime richieste di contatto' : 'Ultime richieste appuntamento'; ?>
            </div>

            <?php
            $latest_requests = $wpdb->get_results("SELECT * FROM $table_appt ORDER BY created_at DESC LIMIT 5", ARRAY_A);
            if (empty($latest_requests)):
            ?>
                <div class="ticino-empty-state">
                    <span class="dashicons dashicons-<?php echo $is_lead ? 'id-alt' : 'calendar-alt'; ?>"></span>
                    <h3><?php echo $is_lead ? 'Nessuna richiesta di contatto al momento' : 'Nessuna richiesta appuntamento al momento'; ?></h3>
                    <p>Quando un cliente invierà una richiesta dal chatbot, apparirà qui.</p>
                </div>
            <?php else: ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>Cliente</th>
                            <th><?php echo $is_lead ? 'Richiesta per' : 'Servizio'; ?></th>
                            <?php if (!$is_lead): ?><th>Preferenza</th><?php endif; ?>
                            <th>Stato</th>
                            <th>Azione</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $dash_status_labels = array(
                            'nuova'         => array('warning', 'Nuova'),
                            'pending'       => array('warning', 'In attesa'),
                            'da_contattare' => array('warning', 'Da contattare'),
                            'contattata'    => array('primary', 'Contattata'),
                            'confermata'    => array('success', 'Confermata'),
                            'confirmed'     => array('success', 'Confermato'),
                            'annullata'     => array('neutral', $is_lead ? 'Archiviata' : 'Annullata'),
                            'rejected'      => array('danger', 'Rifiutato'),
                        );
                        foreach($latest_requests as $req):
                            $st = isset($dash_status_labels[$req['status']]) ? $dash_status_labels[$req['status']] : array('neutral', $req['status']);
                        ?>
                        <tr>
                            <td>
                                <strong><?php echo esc_html($req['customer_first_name'] . ' ' . $req['customer_last_name']); ?></strong><br>
                                <small style="color:var(--ticino-text-muted);"><?php echo esc_html($req['customer_email']); ?></small>
                            </td>
                            <td><?php echo esc_html($req['requested_service']); ?></td>
                            <?php if (!$is_lead): ?><td><?php echo esc_html($req['requested_date'] . ' ' . $req['requested_time_slot']); ?></td><?php endif; ?>
                            <td>
                                <span class="ticino-badge ticino-badge-<?php echo esc_attr($st[0]); ?>"><?php echo esc_html($st[1]); ?></span>
                            </td>
                            <td>
                                <a href="<?php echo admin_url('admin.php?page=ticino-ai-booking-appointments&action=view&id=' . $req['id']); ?>" class="button button-small">Dettagli</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <p style="text-align: right; margin-top: 10px;">
                    <a href="<?php echo admin_url('admin.php?page=ticino-ai-booking-appointments'); ?>">Vedi tutti &rarr;</a>
                </p>
            <?php endif; ?>
        </div>

        <!-- Right Col: Configurazione & Azioni Rapide -->
        <div>
            <div class="ticino-card" style="margin-bottom: 20px;">
                <div class="ticino-card-title">
                    <span class="dashicons dashicons-admin-generic"></span>
                    Configurazione plugin
                </div>
                <ul class="ticino-checklist">
                    <li>
                        <span class="dashicons dashicons-<?php echo $has_company ? 'yes-alt ticino-check-icon ok' : 'warning ticino-check-icon missing'; ?>"></span>
                        Dati azienda configurati
                    </li>
                    <li>
                        <span class="dashicons dashicons-<?php echo $has_gemini ? 'yes-alt ticino-check-icon ok' : 'warning ticino-check-icon missing'; ?>"></span>
                        API <?php echo esc_html($ai_label); ?> configurata
                    </li>
                    <li>
                        <span class="dashicons dashicons-<?php echo $has_kb ? 'yes-alt ticino-check-icon ok' : 'warning ticino-check-icon missing'; ?>"></span>
                        Knowledge Base compilata
                    </li>
                    <li>
                        <span class="dashicons dashicons-<?php echo $has_email ? 'yes-alt ticino-check-icon ok' : 'warning ticino-check-icon missing'; ?>"></span>
                        Email admin configurata
                    </li>
                    <?php if (!$is_lead): ?>
                    <li>
                        <span class="dashicons dashicons-<?php echo $has_caldav ? 'yes-alt ticino-check-icon ok' : 'minus ticino-check-icon neutral'; ?>"></span>
                        Apple Calendar <?php echo $caldav_enabled ? ($has_caldav ? 'configurato' : 'manca password') : 'disabilitato'; ?>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>

            <?php
            $ai_errors = Ticino_AI_Booking_Chatbot::get_error_log();
            $kb_ctx    = get_transient('ticino_ai_site_knowledge_cache');
            $kb_len    = is_string($kb_ctx) ? strlen($kb_ctx) : 0;
            ?>
            <div class="ticino-card" style="margin-bottom: 20px;">
                <div class="ticino-card-title">
                    <span class="dashicons dashicons-heart"></span>
                    Stato dell'assistente
                </div>
                <p style="margin:0 0 8px; font-size:13px; color:#64748b;">
                    Conoscenza del sito in cache: <strong><?php echo $kb_len ? esc_html(number_format_i18n($kb_len)) . ' caratteri (~' . esc_html(number_format_i18n((int) round($kb_len / 3.5))) . ' token)' : 'non ancora generata'; ?></strong>.
                    Sopra i 30.000 caratteri le risposte rallentano: riduci le pagine indicizzate o la conoscenza aggiuntiva.
                </p>
                <?php if (empty($ai_errors)) : ?>
                    <p style="margin:0; font-size:13px; color:var(--ticino-success, #15803d);">Nessun errore registrato dal provider AI.</p>
                <?php else : ?>
                    <p style="margin:0 0 6px; font-size:13px;">Ultimi errori del provider AI (max 30). Quando l'AI fallisce il visitatore riceve comunque una risposta dal fallback locale.</p>
                    <ul style="margin:0; padding-left:0; list-style:none; max-height:220px; overflow:auto; font-size:12px; font-family:monospace;">
                        <?php foreach (array_slice($ai_errors, 0, 15) as $e) : ?>
                            <li style="padding:4px 0; border-bottom:1px solid #eee;"><span style="color:#64748b;"><?php echo esc_html($e['t']); ?></span> — <?php echo esc_html($e['m']); ?></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>

            <div class="ticino-card">
                <div class="ticino-card-title">
                    <span class="dashicons dashicons-lightning"></span>
                    Azioni rapide
                </div>
                <div class="ticino-action-list">
                    <a href="<?php echo admin_url('admin.php?page=ticino-ai-booking-kb'); ?>" class="ticino-action-btn">
                        <span class="dashicons dashicons-database"></span> Modifica Knowledge Base
                    </a>
                    <a href="<?php echo admin_url('admin.php?page=ticino-ai-booking-appointments'); ?>" class="ticino-action-btn">
                        <span class="dashicons dashicons-<?php echo $is_lead ? 'id-alt' : 'calendar-alt'; ?>"></span> <?php echo $is_lead ? 'Gestisci Richieste' : 'Gestisci Appuntamenti'; ?>
                    </a>
                    <a href="<?php echo admin_url('admin.php?page=ticino-ai-booking-settings'); ?>" class="ticino-action-btn">
                        <span class="dashicons dashicons-admin-network"></span> Configura AI (<?php echo esc_html($ai_label); ?>)
                    </a>
                    <a href="<?php echo admin_url('admin.php?page=ticino-ai-booking-email'); ?>" class="ticino-action-btn">
                        <span class="dashicons dashicons-email-alt"></span> Modifica Template Email
                    </a>
                </div>
            </div>
        </div>

    </div>
</div>
