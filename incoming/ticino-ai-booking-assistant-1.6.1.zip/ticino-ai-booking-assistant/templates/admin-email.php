<?php $is_lead = Ticino_AI_Booking_Chatbot::is_lead_mode(); ?>
<div class="wrap ticino-wrap">
    <div class="ticino-header">
        <div>
            <h1>Template Email</h1>
            <p><?php echo $is_lead
                ? 'Personalizza le email automatiche inviate ai clienti: conferma di ricezione della richiesta e, se lo scegli, avviso di archiviazione. In modalità lead la conferma appuntamento non viene mai inviata.'
                : 'Personalizza le email automatiche inviate ai clienti durante il processo di richiesta e conferma appuntamento.'; ?></p>
        </div>
    </div>

    <?php settings_errors(); ?>

    <form method="post" action="options.php">
        <?php settings_fields('ticino_ai_booking_email_group'); ?>

        <div class="ticino-tabs-nav">
            <a href="#tab-req" class="ticino-tab-link active">Richiesta Ricevuta (Al Cliente)</a>
            <a href="#tab-conf" class="ticino-tab-link" <?php echo $is_lead ? 'style="display:none;"' : ''; ?>>Conferma Appuntamento (Al Cliente)</a>
            <a href="#tab-rej" class="ticino-tab-link"><?php echo $is_lead ? 'Richiesta Archiviata (Al Cliente)' : 'Appuntamento Rifiutato (Al Cliente)'; ?></a>
        </div>

        <div class="ticino-email-layout">
            <!-- Left: Modulo Modifica -->
            <div class="ticino-card">
                
                <div id="tab-req" class="ticino-tab-pane active">
                    <div class="ticino-card-title">Modulo Richiesta Ricevuta</div>
                    <p class="ticino-helper-text" style="margin-bottom: 20px;">Questa email viene inviata al cliente subito dopo aver compilato il modulo nel chatbot. Serve a rassicurare che la richiesta è stata presa in carico.</p>
                    <div class="ticino-form-group">
                        <label>Oggetto Email</label>
                        <input type="text" name="ticino_ai_email_req_subject" value="<?php echo esc_attr(get_option('ticino_ai_email_req_subject')); ?>">
                    </div>
                    <div class="ticino-form-group">
                        <label>Corpo Email (Testo puro, accetta line breaks)</label>
                        <textarea id="email-req-body" name="ticino_ai_email_req_body" rows="12"><?php echo esc_textarea(get_option('ticino_ai_email_req_body')); ?></textarea>
                    </div>
                </div>

                <div id="tab-conf" class="ticino-tab-pane">
                    <div class="ticino-card-title">Modulo Conferma Appuntamento</div>
                    <p class="ticino-helper-text" style="margin-bottom: 20px;">Questa email viene inviata al cliente quando l'amministratore clicca su "Conferma" nel dettaglio dell'appuntamento.</p>
                    <div class="ticino-form-group">
                        <label>Oggetto Email</label>
                        <input type="text" name="ticino_ai_email_conf_subject" value="<?php echo esc_attr(get_option('ticino_ai_email_conf_subject')); ?>">
                    </div>
                    <div class="ticino-form-group">
                        <label>Corpo Email (Testo puro, accetta line breaks)</label>
                        <textarea id="email-conf-body" name="ticino_ai_email_conf_body" rows="12"><?php echo esc_textarea(get_option('ticino_ai_email_conf_body')); ?></textarea>
                    </div>
                </div>

                <div id="tab-rej" class="ticino-tab-pane">
                    <div class="ticino-card-title"><?php echo $is_lead ? 'Modulo Richiesta Archiviata' : 'Modulo Appuntamento Rifiutato'; ?></div>
                    <p class="ticino-helper-text" style="margin-bottom: 20px;"><?php echo $is_lead
                        ? 'Questa email viene inviata al cliente solo se, archiviando la richiesta, spunti «Avvisa il cliente via email».'
                        : 'Questa email viene inviata al cliente se l\'amministratore non può confermare l\'appuntamento (es. orario non disponibile).'; ?></p>
                    <div class="ticino-form-group">
                        <label>Oggetto Email</label>
                        <input type="text" name="ticino_ai_email_rej_subject" value="<?php echo esc_attr(get_option('ticino_ai_email_rej_subject')); ?>">
                    </div>
                    <div class="ticino-form-group">
                        <label>Corpo Email (Testo puro, accetta line breaks)</label>
                        <textarea id="email-rej-body" name="ticino_ai_email_rej_body" rows="12"><?php echo esc_textarea(get_option('ticino_ai_email_rej_body')); ?></textarea>
                    </div>
                </div>

                <!-- Variabili disponibili (mostrate in tutti i tab) -->
                <hr style="border: 0; border-top: 1px solid var(--ticino-border); margin: 24px 0;">
                <label style="font-weight: 500; font-size: 14px;">Variabili Disponibili (Clicca per copiare)</label>
                <div class="ticino-variables">
                    <span class="ticino-variable" title="Nome del cliente">{customer_name}</span>
                    <span class="ticino-variable" title="Servizio richiesto">{service}</span>
                    <span class="ticino-variable" title="Data (se confermata)">{confirmed_date}</span>
                    <span class="ticino-variable" title="Ora (se confermata)">{confirmed_time}</span>
                    <span class="ticino-variable" title="Nome dell'azienda">{company_name}</span>
                    <span class="ticino-variable" title="Telefono dell'azienda">{company_phone}</span>
                    <span class="ticino-variable" title="Indirizzo dell'azienda">{company_address}</span>
                </div>
                
                <p class="submit" style="margin-top: 30px;">
                    <?php submit_button('Salva Template Email', 'primary', 'submit', false); ?>
                </p>
            </div>

            <!-- Right: Preview Live -->
            <div>
                <div class="ticino-card ticino-email-preview">
                    <div style="margin-bottom: 15px; font-weight: 600; color: var(--ticino-text-muted); display:flex; align-items:center; gap:8px;">
                        <span class="dashicons dashicons-visibility"></span> Anteprima Live
                    </div>
                    <div class="ticino-email-preview-inner">
                        <!-- Content populated by JS -->
                    </div>
                    <p class="ticino-helper-text" style="text-align: center; margin-top: 16px;">Anteprima generata con dati fittizi.</p>
                </div>
            </div>
            
        </div>
    </form>
</div>
