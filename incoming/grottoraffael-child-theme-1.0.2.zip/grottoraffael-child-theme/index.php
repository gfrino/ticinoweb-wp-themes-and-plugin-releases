<?php
/**
 * Articoli e archivi: titolo, data, immagine e testo in colonna, nello stile delle pagine di testo.
 */
defined('ABSPATH') || exit;

get_header();
?>
<main id="gr-main" class="gr-main gr-page gr-page--text">
    <div class="gr-wrap">
        <?php if (is_singular()) : ?>
            <?php while (have_posts()) : the_post(); ?>
                <article <?php post_class('gr-article'); ?>>
                    <h1 class="gr-page__title"><?php the_title(); ?></h1>
                    <p class="gr-article__date"><time datetime="<?php echo esc_attr(get_the_date('c')); ?>"><?php echo esc_html(get_the_date()); ?></time></p>
                    <?php if (has_post_thumbnail()) : ?><figure class="gr-article__image"><?php the_post_thumbnail('large'); ?></figure><?php endif; ?>
                    <div class="gr-prose"><?php the_content(); ?></div>
                </article>
            <?php endwhile; ?>
        <?php else : ?>
            <h1 class="gr-page__title"><?php echo esc_html(wp_strip_all_tags(get_the_archive_title() ?: get_bloginfo('name'))); ?></h1>
            <?php if (have_posts()) : ?>
                <ul class="gr-archive">
                    <?php while (have_posts()) : the_post(); ?>
                        <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a> <time datetime="<?php echo esc_attr(get_the_date('c')); ?>"><?php echo esc_html(get_the_date()); ?></time></li>
                    <?php endwhile; ?>
                </ul>
                <?php the_posts_pagination(); ?>
            <?php else : ?>
                <p><?php esc_html_e('Nessun contenuto da mostrare.', 'grottoraffael-child-theme'); ?></p>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</main>
<?php
get_footer();
