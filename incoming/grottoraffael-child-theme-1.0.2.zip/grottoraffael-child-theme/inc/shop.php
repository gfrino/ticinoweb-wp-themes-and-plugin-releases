<?php
/**
 * Negozio (WooCommerce) come su grottoraffael.ch: fascia con foto e titolo «Shop» sopra l'elenco,
 * schede prodotto con bordo e pulsante oro. Foto e titolo della fascia: quelli della pagina Shop.
 */
defined('ABSPATH') || exit;

if (!class_exists('WooCommerce')) {
    return;
}

remove_action('woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
remove_action('woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);
remove_action('woocommerce_sidebar', 'woocommerce_get_sidebar', 10);

add_action('woocommerce_before_main_content', function () {
    echo '<main id="gr-main" class="gr-main gr-shop">';
    if (is_shop() || is_product_taxonomy()) {
        $shop = wc_get_page_id('shop');
        $title = is_shop() ? get_the_title($shop) : single_term_title('', false);
        echo grottoraffael_banner($title, $shop > 0 ? (int) get_post_thumbnail_id($shop) : 0, 'gr-banner--short'); // phpcs:ignore WordPress.Security.EscapeOutput -- escape nella funzione
    }
    echo '<div class="gr-wrap gr-shop__inner">';
}, 10);

add_action('woocommerce_after_main_content', function () {
    echo '</div></main>';
}, 10);

/** Il titolo grande dell'elenco è nella fascia: WooCommerce non lo ripete. */
add_filter('woocommerce_show_page_title', '__return_false');

/** Quattro prodotti per riga come sull'originale. */
add_filter('loop_shop_columns', function () {
    return 4;
});
