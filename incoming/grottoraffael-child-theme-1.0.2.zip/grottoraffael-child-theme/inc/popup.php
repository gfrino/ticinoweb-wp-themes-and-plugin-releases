<?php
/**
 * Aspetto → Personalizza → Grotto Raffael: testo e partner del footer, popup della home.
 * Il popup (es. «Musica & Allegria», «Riapriamo il…») compare in home una volta per visita,
 * solo tra le date scelte. Il parent non ha un popup: da proporre a gfrino per tutti i siti.
 */
defined('ABSPATH') || exit;

add_action('customize_register', function ($wp_customize) {
    $wp_customize->add_section('grottoraffael', array('title' => __('Grotto Raffael', 'grottoraffael-child-theme'), 'priority' => 30));

    $wp_customize->add_setting('grottoraffael_footer_text', array('default' => '', 'sanitize_callback' => 'sanitize_textarea_field'));
    $wp_customize->add_control('grottoraffael_footer_text', array('label' => __('Footer: testo sotto il logo', 'grottoraffael-child-theme'), 'section' => 'grottoraffael', 'type' => 'textarea'));

    $wp_customize->add_setting('grottoraffael_partner_logo', array('default' => 0, 'sanitize_callback' => 'absint'));
    $wp_customize->add_control(new WP_Customize_Media_Control($wp_customize, 'grottoraffael_partner_logo', array('label' => __('Footer: logo del partner', 'grottoraffael-child-theme'), 'section' => 'grottoraffael', 'mime_type' => 'image')));

    $wp_customize->add_setting('grottoraffael_partner_url', array('default' => '', 'sanitize_callback' => 'esc_url_raw'));
    $wp_customize->add_control('grottoraffael_partner_url', array('label' => __('Footer: sito del partner', 'grottoraffael-child-theme'), 'section' => 'grottoraffael', 'type' => 'url'));

    // Menù classico nella lingua della pagina: il PDF del menu (italiano/tedesco) viene sostituito da questi.
    foreach (array('en' => __('Menù classico: PDF per le pagine in inglese', 'grottoraffael-child-theme'), 'fr' => __('Menù classico: PDF per le pagine in francese', 'grottoraffael-child-theme')) as $lang => $label) {
        $wp_customize->add_setting('grottoraffael_menu_pdf_' . $lang, array('default' => 0, 'sanitize_callback' => 'absint'));
        $wp_customize->add_control(new WP_Customize_Media_Control($wp_customize, 'grottoraffael_menu_pdf_' . $lang, array('label' => $label, 'section' => 'grottoraffael', 'mime_type' => 'application/pdf')));
    }
    $wp_customize->add_setting('grottoraffael_menu_pdf_base', array('default' => 0, 'sanitize_callback' => 'absint'));
    $wp_customize->add_control(new WP_Customize_Media_Control($wp_customize, 'grottoraffael_menu_pdf_base', array(
        'label'       => __('Menù classico: PDF usato nei menu (italiano e tedesco)', 'grottoraffael-child-theme'),
        'description' => __('Nelle pagine in inglese e francese il link a questo PDF apre quello della lingua scelto sopra.', 'grottoraffael-child-theme'),
        'section'     => 'grottoraffael',
        'mime_type'   => 'application/pdf',
    )));

    $wp_customize->add_setting('grottoraffael_popup_image', array('default' => 0, 'sanitize_callback' => 'absint'));
    $wp_customize->add_control(new WP_Customize_Media_Control($wp_customize, 'grottoraffael_popup_image', array(
        'label'       => __('Popup della home: immagine', 'grottoraffael-child-theme'),
        'description' => __('Senza immagine e senza titolo il popup non compare.', 'grottoraffael-child-theme'),
        'section'     => 'grottoraffael',
        'mime_type'   => 'image',
    )));
    foreach (array(
        'grottoraffael_popup_title' => array(__('Popup: titolo', 'grottoraffael-child-theme'), 'text', 'sanitize_text_field'),
        'grottoraffael_popup_text'  => array(__('Popup: testo', 'grottoraffael-child-theme'), 'textarea', 'sanitize_textarea_field'),
        'grottoraffael_popup_from'  => array(__('Popup: visibile dal (vuoto = subito)', 'grottoraffael-child-theme'), 'date', 'grottoraffael_sanitize_date'),
        'grottoraffael_popup_to'    => array(__('Popup: visibile fino al (compreso; vuoto = sempre)', 'grottoraffael-child-theme'), 'date', 'grottoraffael_sanitize_date'),
    ) as $id => $def) {
        $wp_customize->add_setting($id, array('default' => '', 'sanitize_callback' => $def[2]));
        $wp_customize->add_control($id, array('label' => $def[0], 'section' => 'grottoraffael', 'type' => $def[1]));
    }
});

function grottoraffael_sanitize_date($value)
{
    return preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) $value) ? $value : '';
}

/** Il popup è attivo oggi? */
function grottoraffael_popup_active()
{
    $image = (int) get_theme_mod('grottoraffael_popup_image', 0);
    $title = trim((string) get_theme_mod('grottoraffael_popup_title', ''));
    if (!$image && $title === '') {
        return false;
    }
    $today = wp_date('Y-m-d');
    $from = (string) get_theme_mod('grottoraffael_popup_from', '');
    $to = (string) get_theme_mod('grottoraffael_popup_to', '');
    return ($from === '' || $today >= $from) && ($to === '' || $today <= $to);
}

add_action('wp_footer', function () {
    if (!is_front_page() || !grottoraffael_popup_active()) {
        return;
    }
    $image = (int) get_theme_mod('grottoraffael_popup_image', 0);
    $title = trim((string) get_theme_mod('grottoraffael_popup_title', ''));
    $text = trim((string) get_theme_mod('grottoraffael_popup_text', ''));
    $key = md5($image . $title . get_theme_mod('grottoraffael_popup_from', ''));
    ?>
    <dialog class="gr-popup" data-gr-popup="<?php echo esc_attr($key); ?>" aria-label="<?php echo esc_attr($title ?: get_bloginfo('name')); ?>">
        <button type="button" class="gr-popup__close" data-gr-close aria-label="<?php echo esc_attr(grottoraffael_t(__('Chiudi', 'grottoraffael-child-theme'), 'ui:close')); ?>"><?php echo grottoraffael_icon('close', 22); // phpcs:ignore ?></button>
        <?php if ($image) : ?>
            <?php echo wp_get_attachment_image($image, 'large', false, array('class' => 'gr-popup__image', 'loading' => 'lazy')); ?>
        <?php endif; ?>
        <?php if ($title !== '' || $text !== '') : ?>
            <div class="gr-popup__body">
                <?php if ($title !== '') : ?><h2><?php echo esc_html($title); ?></h2><?php endif; ?>
                <?php if ($text !== '') : ?><?php echo wp_kses_post(wpautop($text)); ?><?php endif; ?>
                <button type="button" class="gr-btn" data-gr-close><?php esc_html_e('Vai al sito', 'grottoraffael-child-theme'); ?></button>
            </div>
        <?php endif; ?>
    </dialog>
    <?php
});
