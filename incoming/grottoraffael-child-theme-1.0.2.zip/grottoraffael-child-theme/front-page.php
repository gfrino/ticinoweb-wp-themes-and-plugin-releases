<?php
/**
 * Home: il contenuto della pagina è fatto di sezioni (classi gr-*), dalla foto grande in testa
 * alla striscia di foto in fondo. Tutto modificabile dalla pagina, niente testi nel tema.
 */
defined('ABSPATH') || exit;

get_header();
the_post();
?>
<main id="gr-main" class="gr-main gr-home">
    <?php the_content(); ?>
</main>
<?php
get_footer();
