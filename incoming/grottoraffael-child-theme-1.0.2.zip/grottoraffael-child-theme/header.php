<?php
/**
 * Header come su grottoraffael.ch: logo, menu principale (con la tendina dei menù in PDF),
 * selettore della lingua e pulsante «Buono Regalo». Logo e menu vengono dal CMS.
 */
defined('ABSPATH') || exit;

$site_name = function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text(get_bloginfo('name'), 'theme:branding:site_name') : get_bloginfo('name');
$logo = function_exists('ticinoweb_get_site_logo') ? ticinoweb_get_site_logo() : '';
$home = function_exists('ticinoweb_frontend_url') ? ticinoweb_frontend_url(home_url('/'), 'theme:url:home') : home_url('/');
$voucher = grottoraffael_voucher_url();
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="gr-skip" href="#gr-main"><?php esc_html_e('Vai al contenuto', 'grottoraffael-child-theme'); ?></a>
<header class="gr-header">
    <div class="gr-header__inner">
        <a class="gr-header__logo" href="<?php echo esc_url($home); ?>" rel="home">
            <?php if ($logo) : ?>
                <img src="<?php echo esc_url($logo); ?>" alt="<?php echo esc_attr($site_name); ?>" width="109" height="57">
            <?php else : ?>
                <span class="gr-header__name"><?php echo esc_html($site_name); ?></span>
            <?php endif; ?>
        </a>
        <button class="gr-menu-toggle" type="button" aria-expanded="false" aria-controls="gr-nav" aria-label="<?php echo esc_attr(grottoraffael_t(__('Apri il menu', 'grottoraffael-child-theme'), 'menu:open')); ?>">
            <span aria-hidden="true"></span>
        </button>
        <nav id="gr-nav" class="gr-nav" aria-label="<?php echo esc_attr(grottoraffael_t(__('Menu principale', 'grottoraffael-child-theme'), 'menu:label')); ?>">
            <?php
            wp_nav_menu(array(
                'theme_location' => 'primary',
                'menu_class'     => 'gr-nav__menu',
                'container'      => false,
                'fallback_cb'    => false,
                'depth'          => 2,
            ));
            ?>
            <?php echo grottoraffael_language_switcher(); // phpcs:ignore WordPress.Security.EscapeOutput -- escape nella funzione ?>
        </nav>
        <?php if ($voucher) : ?>
            <a class="gr-header__voucher" href="<?php echo esc_url($voucher); ?>"><?php echo grottoraffael_icon('gift', 14); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php echo esc_html(get_the_title(get_page_by_path('buono-regalo'))); ?></span></a>
        <?php endif; ?>
    </div>
</header>
