<?php
/**
 * Pagina interna. Le pagine fatte a sezioni (classi gr-*) decidono da sole fasce e larghezze;
 * le altre (testi legali, carrello, cassa) mostrano il titolo e il testo in colonna.
 * Se il contenuto non ha un <h1>, il titolo della pagina compare in testa: ogni pagina ne ha uno solo.
 */
defined('ABSPATH') || exit;

get_header();
the_post();
$content = get_the_content();
$sections = strpos($content, 'class="gr-') !== false;
?>
<main id="gr-main" class="gr-main <?php echo $sections ? 'gr-page' : 'gr-page gr-page--text'; ?>">
    <?php if ($sections) : ?>
        <?php if (stripos($content, '<h1') === false) : ?>
            <h1 class="screen-reader-text"><?php the_title(); ?></h1>
        <?php endif; ?>
        <?php the_content(); ?>
    <?php else : ?>
        <div class="gr-wrap">
            <h1 class="gr-page__title"><?php the_title(); ?></h1>
            <div class="gr-prose"><?php the_content(); ?></div>
        </div>
    <?php endif; ?>
</main>
<?php
get_footer();
