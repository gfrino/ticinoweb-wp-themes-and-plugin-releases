<?php
/**
 * Footer come su grottoraffael.ch: marchio con testo e social, menù in PDF, link, telefono e partner,
 * poi il riquadro con le note legali e le bandiere delle altre lingue.
 * Testo e partner: Aspetto → Personalizza → Grotto Raffael; telefono e social: ticinoWEB CMS.
 */
defined('ABSPATH') || exit;

$site_name = get_bloginfo('name');
$logo = function_exists('ticinoweb_get_site_logo') ? ticinoweb_get_site_logo() : '';
$contact = function_exists('ticinoweb_get_contact_info') ? ticinoweb_get_contact_info() : array();
$text = trim((string) get_theme_mod('grottoraffael_footer_text', ''));
$phone = ($contact['phone_landline'] ?? '') ?: ($contact['phone'] ?? '');
$booking = get_page_by_path('contatto');
$partner_logo = (int) get_theme_mod('grottoraffael_partner_logo', 0);
$partner_url = (string) get_theme_mod('grottoraffael_partner_url', '');
?>
<footer class="gr-footer">
    <div class="gr-wrap gr-footer__cols">
        <div class="gr-footer__brand">
            <?php if ($logo) : ?>
                <a href="<?php echo esc_url(home_url('/')); ?>"><img class="gr-footer__logo" src="<?php echo esc_url($logo); ?>" alt="<?php echo esc_attr($site_name); ?>" width="150" height="78" loading="lazy"></a>
            <?php endif; ?>
            <?php if ($text !== '') : ?>
                <div class="gr-footer__text"><?php echo wp_kses_post(wpautop($text)); ?></div>
            <?php endif; ?>
            <?php if (!empty($contact['facebook']) || !empty($contact['instagram'])) : ?>
                <p class="gr-footer__social">
                    <?php if (!empty($contact['facebook'])) : ?><a href="<?php echo esc_url($contact['facebook']); ?>" target="_blank" rel="noopener" aria-label="Facebook"><?php echo grottoraffael_icon('facebook', 19); // phpcs:ignore ?></a><?php endif; ?>
                    <?php if (!empty($contact['instagram'])) : ?><a href="<?php echo esc_url($contact['instagram']); ?>" target="_blank" rel="noopener" aria-label="Instagram"><?php echo grottoraffael_icon('instagram', 19); // phpcs:ignore ?></a><?php endif; ?>
                </p>
            <?php endif; ?>
        </div>
        <?php if (has_nav_menu('grottoraffael_footer_menu')) : ?>
            <nav class="gr-footer__nav" aria-label="<?php echo esc_attr(grottoraffael_t(__('Menù e carte', 'grottoraffael-child-theme'), 'footer:menus')); ?>">
                <?php wp_nav_menu(array('theme_location' => 'grottoraffael_footer_menu', 'container' => false, 'menu_class' => 'gr-footer__links gr-footer__links--icons', 'depth' => 1, 'fallback_cb' => false)); ?>
            </nav>
        <?php endif; ?>
        <?php if (has_nav_menu('grottoraffael_footer_links')) : ?>
            <nav class="gr-footer__nav" aria-label="<?php echo esc_attr(grottoraffael_t(__('Link', 'grottoraffael-child-theme'), 'footer:links')); ?>">
                <?php wp_nav_menu(array('theme_location' => 'grottoraffael_footer_links', 'container' => false, 'menu_class' => 'gr-footer__links', 'depth' => 1, 'fallback_cb' => false)); ?>
            </nav>
        <?php endif; ?>
        <div class="gr-footer__contact">
            <?php if ($phone) : ?>
                <p class="gr-footer__label"><?php esc_html_e('Telefono', 'grottoraffael-child-theme'); ?></p>
                <p class="gr-footer__phone"><a href="<?php echo esc_url(grottoraffael_tel($phone)); ?>"><?php echo esc_html($phone); ?></a></p>
            <?php endif; ?>
            <?php if ($booking) : ?>
                <p class="gr-footer__label"><a href="<?php echo esc_url(get_permalink($booking)); ?>"><?php esc_html_e('Prenota il tuo tavolo', 'grottoraffael-child-theme'); ?></a></p>
            <?php endif; ?>
            <?php if ($partner_logo) : ?>
                <p class="gr-footer__label gr-footer__label--partner"><?php esc_html_e('Partner', 'grottoraffael-child-theme'); ?></p>
                <?php
                $img = wp_get_attachment_image($partner_logo, 'medium', false, array('class' => 'gr-footer__partner', 'loading' => 'lazy'));
                echo $partner_url ? '<a href="' . esc_url($partner_url) . '" target="_blank" rel="noopener">' . $img . '</a>' : $img; // phpcs:ignore WordPress.Security.EscapeOutput
                ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="gr-wrap">
        <div class="gr-footer__bottom">
            <?php if (has_nav_menu('grottoraffael_legal')) : ?>
                <nav aria-label="<?php echo esc_attr(grottoraffael_t(__('Note legali', 'grottoraffael-child-theme'), 'footer:legal')); ?>">
                    <?php wp_nav_menu(array('theme_location' => 'grottoraffael_legal', 'container' => false, 'menu_class' => 'gr-footer__legal', 'depth' => 1, 'fallback_cb' => false)); ?>
                </nav>
            <?php endif; ?>
            <p class="gr-footer__copy">
                <?php
                printf(
                    /* translators: 1: anno, 2: nome del sito */
                    esc_html__('© Copyright %1$s %2$s Powered by', 'grottoraffael-child-theme'),
                    esc_html(wp_date('Y')),
                    esc_html($site_name)
                );
                ?>
                <a href="https://ticinoweb.com" target="_blank" rel="noopener">ticinoWEB</a>
            </p>
        </div>
        <?php echo grottoraffael_language_switcher('flags'); // phpcs:ignore WordPress.Security.EscapeOutput -- escape nella funzione ?>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
