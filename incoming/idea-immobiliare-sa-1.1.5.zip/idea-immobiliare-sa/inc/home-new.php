<?php
/** Home NEW: page-specific presentation, existing CMS inputs and catalog. */
if (!defined('ABSPATH')) { exit; }

function idea_immo_is_home_new() { return is_page_template('page-home-new.php'); }

function idea_immo_home_text($text, $context) {
    return function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text($text, $context) : $text;
}
function idea_immo_home_url($url, $context) {
    return function_exists('ticinoweb_frontend_url') ? ticinoweb_frontend_url($url, $context) : $url;
}

function idea_immo_home_labels() {
    return array(
        'search_title' => __('Titolo ricerca', 'idea-immobiliare-sa'),
        'catalog_title' => __('Titolo immobili', 'idea-immobiliare-sa'),
        'catalog_intro' => __('Introduzione immobili', 'idea-immobiliare-sa'),
        'projects_title' => __('Titolo promozioni', 'idea-immobiliare-sa'),
        'journal_title' => __('Titolo blog', 'idea-immobiliare-sa'),
        'faq_title' => __('Titolo domande frequenti', 'idea-immobiliare-sa'),
        'contact_title' => __('Titolo contatti', 'idea-immobiliare-sa'),
        'contact_text' => __('Testo contatti', 'idea-immobiliare-sa'),
    );
}
function idea_immo_home_label($key) {
    return idea_immo_home_text((string) get_post_meta(get_queried_object_id(), '_idea_home_' . $key, true), 'post:' . get_queried_object_id() . ':home:' . $key);
}

add_action('add_meta_boxes_page', function ($post) {
    if (get_page_template_slug($post) !== 'page-home-new.php') { return; }
    add_meta_box('idea-home-new-content', __('Home NEW · Testi delle sezioni', 'idea-immobiliare-sa'), function ($post) {
        wp_nonce_field('idea_home_new_save', 'idea_home_new_nonce');
        echo '<p>' . esc_html__('Il testo iniziale si modifica nell’editor della pagina. Fotografie e didascalie: ticinoWEB CMS → Slider. Presentazione e servizi: campi del CMS. Gli immobili e le promozioni si aggiornano dai rispettivi menu.', 'idea-immobiliare-sa') . '</p>';
        foreach (idea_immo_home_labels() as $key => $label) {
            echo '<p><label for="idea-home-' . esc_attr($key) . '"><strong>' . esc_html($label) . '</strong></label><br><textarea class="widefat" rows="2" id="idea-home-' . esc_attr($key) . '" name="idea_home[' . esc_attr($key) . ']">' . esc_textarea(get_post_meta($post->ID, '_idea_home_' . $key, true)) . '</textarea></p>';
        }
    }, 'page', 'normal', 'high');
});
add_action('save_post_page', function ($id) {
    if (!isset($_POST['idea_home_new_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['idea_home_new_nonce'])), 'idea_home_new_save') || !current_user_can('edit_post', $id) || wp_is_post_revision($id) || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)) { return; }
    $values = isset($_POST['idea_home']) && is_array($_POST['idea_home']) ? wp_unslash($_POST['idea_home']) : array();
    foreach (idea_immo_home_labels() as $key => $label) {
        if (isset($values[$key]) && is_scalar($values[$key])) { update_post_meta($id, '_idea_home_' . $key, sanitize_textarea_field($values[$key])); }
    }
});

add_action('wp_enqueue_scripts', function () {
    if (!idea_immo_is_home_new()) { return; }
    $uri = get_stylesheet_directory_uri();
    wp_dequeue_style('idea-immo-fonts');
    // Keep the incumbent stylesheet dependency satisfied without a third-party font request.
    wp_deregister_style('idea-immo-fonts');
    wp_register_style('idea-immo-fonts', false);
    wp_enqueue_style('idea-immo-home-new', $uri . '/assets/css/home-new.css', array('idea-immo-style'), IDEA_IMMO_VERSION);
    wp_enqueue_script('idea-immo-home-new', $uri . '/assets/js/home-new.js', array(), IDEA_IMMO_VERSION, true);
}, 30);
add_filter('body_class', function ($classes) { if (idea_immo_is_home_new()) { $classes[] = 'idea-home-new'; } return $classes; });

/** Existing catalog semantics; photos first, then latest, including records without a photo. */
function idea_immo_home_catalog_args($category = '', $page = 1) {
    $args = array('post_type' => 'immobile', 'post_status' => 'publish', 'posts_per_page' => 6, 'idea_home_catalog' => true, 'paged' => max(1, absint($page)),
        'meta_query' => array('relation' => 'AND',
            array('relation' => 'OR', array('key' => '_idea_status', 'compare' => 'NOT EXISTS'), array('key' => '_idea_status', 'value' => 'archivio', 'compare' => '!=')),
        ), 'orderby' => array('date' => 'DESC', 'ID' => 'DESC'));
    if ($category !== '') { $args['tax_query'] = array(array('taxonomy' => 'categoria_immobile', 'field' => 'slug', 'terms' => sanitize_title($category))); }
    return $args;
}

// The photo ID itself must never affect recency. Scope SQL strictly to this query.
add_filter('posts_clauses', function ($clauses, $query) {
    if (!$query->get('idea_home_catalog')) { return $clauses; }
    global $wpdb;
    $clauses['orderby'] = $wpdb->prepare(
        "EXISTS (SELECT 1 FROM {$wpdb->postmeta} AS idea_home_cover WHERE idea_home_cover.post_id = {$wpdb->posts}.ID AND idea_home_cover.meta_key = %s AND CAST(idea_home_cover.meta_value AS UNSIGNED) > 0) DESC, {$wpdb->posts}.post_date DESC, {$wpdb->posts}.ID DESC",
        '_thumbnail_id'
    );
    return $clauses;
}, 10, 2);

/** Parent CMS slider, with Media Library responsive images; no parallel content storage. */
function idea_immo_home_slides() {
    $slides = array();
    $count = min(5, max(0, (int) get_option('ticinoweb_slider_count', 0)));
    for ($i = 1; $i <= $count; $i++) {
        $url = (string) get_option('ticinoweb_slider_image_' . $i, '');
        if ($url === '') { continue; }
        $id = attachment_url_to_postid($url);
        $slides[] = array('image' => $id, 'url' => $url, 'title' => idea_immo_home_text((string) get_option('ticinoweb_slider_title_' . $i, ''), 'theme:slider:' . $i . ':title'), 'desc' => idea_immo_home_text(wp_strip_all_tags(html_entity_decode((string) get_option('ticinoweb_slider_desc_' . $i, ''), ENT_QUOTES, 'UTF-8')), 'theme:slider:' . $i . ':description'), 'link' => idea_immo_home_url((string) get_option('ticinoweb_slider_btn_link_' . $i, ''), 'theme:url:slider_' . $i), 'button' => idea_immo_home_text((string) get_option('ticinoweb_slider_btn_text_' . $i, ''), 'theme:slider:' . $i . ':btn_text'));
    }
    return $slides;
}
