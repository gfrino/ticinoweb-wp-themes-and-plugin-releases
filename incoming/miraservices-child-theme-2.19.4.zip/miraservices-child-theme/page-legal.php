<?php
/**
 * Template Name: Pagina informativa
 * Editorial content remains in the native WordPress page editor.
 * @package MiraServicesChildTheme
 */
defined( 'ABSPATH' ) || exit;
get_header();
?>
<main id="mira-main" class="mira-faq-page mira-legal-page">
 <?php while ( have_posts() ) : the_post(); ?>
 <article <?php post_class(); ?>>
  <header class="mira-faq-page__heading"><p><?php echo esc_html( get_bloginfo( 'name' ) ); ?></p><h1><?php the_title(); ?></h1></header>
  <div class="mira-faq-page__content mira-legal-page__content"><?php the_content(); ?></div>
 </article>
 <?php endwhile; ?>
</main>
<?php get_footer(); ?>
