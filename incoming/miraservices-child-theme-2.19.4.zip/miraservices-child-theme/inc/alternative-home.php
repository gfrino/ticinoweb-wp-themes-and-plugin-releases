<?php
/** Alternative Home: isolated assets, shared CMS and shared global navigation. */
defined( 'ABSPATH' ) || exit;
require_once __DIR__ . '/showroom.php';

function miraservices_is_alternative_home() {
 return function_exists( 'is_page_template' ) && is_page_template( 'page-alternative-home.php' );
}

function miraservices_is_faq_page() {
 return function_exists( 'is_page_template' ) && is_page_template( 'page-faq.php' );
}

function miraservices_is_editorial_page() {
 return miraservices_is_faq_page() || ( function_exists( 'is_page_template' ) && is_page_template( 'page-legal.php' ) );
}

add_action( 'after_setup_theme', function () {
 register_nav_menu( 'miraservices-footer', __( 'Collegamenti Footer', 'miraservices' ) );
}, 20 );

function miraservices_frontend_home_url( $fragment = '' ) {
 $base = miraservices_is_alternative_home() ? get_permalink() : home_url( '/' );
 return $base . ( $fragment ? '#' . ltrim( $fragment, '#' ) : '' );
}

add_filter( 'body_class', function ( $classes ) {
 if ( miraservices_is_alternative_home() || miraservices_is_editorial_page() ) { $classes[] = 'mira-alternative'; }
 return $classes;
} );

// Select the enhanced geometry before styles paint, rather than moving the image
// from normal flow when the deferred animation script finally starts.
add_action( 'wp_head', function () {
 if ( ! miraservices_is_alternative_home() ) { return; }
 echo '<script>if(!window.matchMedia("(prefers-reduced-motion: reduce)").matches){document.documentElement.classList.add("mira-cinematic")}</script>' . "\n";
}, 1 );

add_filter( 'wp_preload_resources', function ( $resources ) {
 if ( ! miraservices_is_alternative_home() && ! miraservices_is_editorial_page() ) { return $resources; }
 $fonts = miraservices_is_alternative_home() ? array( 'dela-gothic-one', 'manrope' ) : array( 'manrope' );
 foreach ( $fonts as $font ) {
  $resources[] = array( 'href' => get_stylesheet_directory_uri() . '/assets/fonts/' . $font . '.woff2', 'as' => 'font', 'type' => 'font/woff2', 'crossorigin' => 'anonymous' );
 }
 return $resources;
} );

add_action( 'wp_enqueue_scripts', function () {
 if ( ! miraservices_is_alternative_home() && ! miraservices_is_editorial_page() ) { return; }
 $version = wp_get_theme()->get( 'Version' );
 $uri = get_stylesheet_directory_uri();
 wp_enqueue_style( 'miraservices-alternative', $uri . '/assets/css/alternative-home.css', array( 'miraservices-site' ), $version );
 if ( miraservices_is_editorial_page() ) {
  wp_enqueue_style( 'miraservices-alternative-closing', $uri . '/assets/css/alternative-closing.css', array( 'miraservices-alternative' ), $version );
  $dependencies = array( 'miraservices-alternative-closing' );
  if ( miraservices_is_faq_page() ) { $dependencies[] = 'ticinoweb-faq'; }
  wp_enqueue_style( 'miraservices-faq-page', $uri . '/assets/css/faq-page.css', $dependencies, $version );
  return;
 }
 wp_enqueue_style( 'miraservices-alternative-journey', $uri . '/assets/css/alternative-journey.css', array( 'miraservices-alternative' ), $version );
 wp_enqueue_style( 'miraservices-lenis', $uri . '/assets/vendor/lenis/lenis.css', array(), '1.3.27' );
 wp_enqueue_style( 'miraservices-alternative-motion', $uri . '/assets/css/alternative-motion.css', array( 'miraservices-alternative-journey', 'miraservices-lenis' ), $version );
 wp_enqueue_style( 'miraservices-alternative-experience', $uri . '/assets/css/alternative-experience.css', array( 'miraservices-alternative-motion' ), $version );
 wp_enqueue_style( 'miraservices-alternative-closing', $uri . '/assets/css/alternative-closing.css', array( 'miraservices-alternative-experience' ), $version );
 wp_enqueue_script( 'miraservices-lenis', $uri . '/assets/vendor/lenis/lenis.min.js', array(), '1.3.27', true );
 wp_enqueue_script( 'miraservices-alternative', $uri . '/assets/js/alternative-home.js', array( 'miraservices-navigation', 'miraservices-lenis' ), $version, true );
 wp_enqueue_script( 'miraservices-showroom', $uri . '/assets/js/alternative-showroom.js', array( 'miraservices-alternative' ), $version, true );
} , 30 );

// Native WordPress menu items retain their content and service destinations.
add_filter( 'wp_get_nav_menu_items', function ( $items ) {
 if ( ! miraservices_is_alternative_home() ) { return $items; }
 foreach ( $items as $item ) {
  $fragment = wp_parse_url( $item->url, PHP_URL_FRAGMENT );
  $base = strtok( $item->url, '#' );
  if ( untrailingslashit( $base ) === untrailingslashit( home_url( '/' ) ) ) {
   $item->url = get_permalink() . ( $fragment ? '#' . $fragment : '#home' );
  }
 }
 return $items;
} );
