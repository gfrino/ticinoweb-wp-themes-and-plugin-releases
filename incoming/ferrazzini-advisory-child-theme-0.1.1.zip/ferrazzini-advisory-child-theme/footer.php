<?php
/**
 * Site footer for Ferrazzini Advisory & Tax SA.
 *
 * @package FerrazziniAdvisoryChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$ferrazzini_advisory_footer_contact_info    = function_exists( 'ticinoweb_get_contact_info' ) ? ticinoweb_get_contact_info() : array();
$ferrazzini_advisory_footer_contact_email   = ! empty( $ferrazzini_advisory_footer_contact_info['email'] ) ? sanitize_email( $ferrazzini_advisory_footer_contact_info['email'] ) : '';
$ferrazzini_advisory_footer_contact_phone   = ! empty( $ferrazzini_advisory_footer_contact_info['phone'] ) ? $ferrazzini_advisory_footer_contact_info['phone'] : '';
$ferrazzini_advisory_footer_contact_tel     = $ferrazzini_advisory_footer_contact_phone ? preg_replace( '/[^0-9+]/', '', $ferrazzini_advisory_footer_contact_phone ) : '';
$ferrazzini_advisory_footer_contact_address = ! empty( $ferrazzini_advisory_footer_contact_info['address'] ) ? $ferrazzini_advisory_footer_contact_info['address'] : '';
$ferrazzini_advisory_footer_service_pages   = function_exists( 'ferrazzini_advisory_service_detail_pages' ) ? ferrazzini_advisory_service_detail_pages() : array();
$ferrazzini_advisory_footer_logo_url        = function_exists( 'ticinoweb_get_site_logo' ) ? ticinoweb_get_site_logo() : get_option( 'ticinoweb_site_logo', '' );
$ferrazzini_advisory_footer_logo_dimensions = $ferrazzini_advisory_footer_logo_url && function_exists( 'ferrazzini_advisory_logo_dimensions' ) ? ferrazzini_advisory_logo_dimensions( $ferrazzini_advisory_footer_logo_url ) : array();
$ferrazzini_advisory_footer_privacy_url     = function_exists( 'ferrazzini_advisory_get_privacy_policy_url' ) ? ferrazzini_advisory_get_privacy_policy_url() : '';
$ferrazzini_advisory_footer_map_url         = $ferrazzini_advisory_footer_contact_address ? add_query_arg(
	array(
		'api'   => '1',
		'query' => $ferrazzini_advisory_footer_contact_address,
	),
	'https://www.google.com/maps/search/'
) : '';
?>
<footer class="ferrazzini-footer">
	<div class="ferrazzini-footer__main">
		<div class="ferrazzini-footer__identity">
			<a class="ferrazzini-footer__brand<?php echo $ferrazzini_advisory_footer_logo_url ? ' ferrazzini-footer__brand--logo' : ''; ?>" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
				<?php if ( $ferrazzini_advisory_footer_logo_url ) : ?>
					<img
						class="ferrazzini-footer__logo"
						src="<?php echo esc_url( $ferrazzini_advisory_footer_logo_url ); ?>"
						alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"
						<?php if ( $ferrazzini_advisory_footer_logo_dimensions ) : ?>
							width="<?php echo esc_attr( $ferrazzini_advisory_footer_logo_dimensions['width'] ); ?>"
							height="<?php echo esc_attr( $ferrazzini_advisory_footer_logo_dimensions['height'] ); ?>"
						<?php endif; ?>
						loading="lazy"
						decoding="async"
					>
				<?php else : ?>
					<?php echo esc_html( get_bloginfo( 'name' ) ); ?>
				<?php endif; ?>
			</a>
			<p class="ferrazzini-footer__description">
				<?php echo esc_html( ferrazzini_advisory_frontend_text( __( 'Consulenza fiduciaria, fiscale e aziendale.', 'ferrazzini-advisory' ), 'theme:ferrazzini:footer:description' ) ); ?>
			</p>
			<div class="ferrazzini-footer__professional-mark">
				<img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/images/expertsuisse-logo.svg' ); ?>" width="652" height="185" alt="<?php echo esc_attr( ferrazzini_advisory_frontend_text( __( 'EXPERTsuisse', 'ferrazzini-advisory' ), 'theme:ferrazzini:footer:expertsuisse' ) ); ?>" loading="lazy">
			</div>
		</div>

		<div class="ferrazzini-footer__navigation-wrap">
			<h2><?php echo esc_html( ferrazzini_advisory_frontend_text( __( 'Esplora', 'ferrazzini-advisory' ), 'theme:ferrazzini:footer:explore' ) ); ?></h2>
			<nav class="ferrazzini-footer__navigation" aria-label="<?php echo esc_attr( ferrazzini_advisory_frontend_text( __( 'Navigazione nel piè di pagina', 'ferrazzini-advisory' ), 'theme:ferrazzini:footer:navigation' ) ); ?>">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo esc_html( ferrazzini_advisory_frontend_text( __( 'Home', 'ferrazzini-advisory' ), 'theme:ferrazzini:navigation:home' ) ); ?></a>
				<a href="<?php echo esc_url( home_url( '/chi-siamo/' ) ); ?>"><?php echo esc_html( ferrazzini_advisory_frontend_text( __( 'Chi siamo', 'ferrazzini-advisory' ), 'theme:ferrazzini:navigation:about' ) ); ?></a>
				<a href="<?php echo esc_url( home_url( '/contatti/' ) ); ?>"><?php echo esc_html( ferrazzini_advisory_frontend_text( __( 'Contatti', 'ferrazzini-advisory' ), 'theme:ferrazzini:navigation:contact' ) ); ?></a>
				<?php foreach ( $ferrazzini_advisory_footer_service_pages as $ferrazzini_advisory_footer_service_page ) : ?>
					<a href="<?php echo esc_url( home_url( '/servizi/' . $ferrazzini_advisory_footer_service_page['slug'] . '/' ) ); ?>"><?php echo esc_html( $ferrazzini_advisory_footer_service_page['title'] ); ?></a>
				<?php endforeach; ?>
			</nav>
		</div>

		<div class="ferrazzini-footer__contacts">
			<h2><?php echo esc_html( ferrazzini_advisory_frontend_text( __( 'Contatti', 'ferrazzini-advisory' ), 'theme:ferrazzini:footer:contacts' ) ); ?></h2>
			<address>
				<?php if ( $ferrazzini_advisory_footer_contact_address && $ferrazzini_advisory_footer_map_url ) : ?>
					<a href="<?php echo esc_url( $ferrazzini_advisory_footer_map_url ); ?>"><?php echo esc_html( $ferrazzini_advisory_footer_contact_address ); ?></a>
				<?php endif; ?>
				<?php if ( $ferrazzini_advisory_footer_contact_phone && $ferrazzini_advisory_footer_contact_tel ) : ?>
					<a href="tel:<?php echo esc_attr( $ferrazzini_advisory_footer_contact_tel ); ?>"><?php echo esc_html( $ferrazzini_advisory_footer_contact_phone ); ?></a>
				<?php endif; ?>
				<?php if ( $ferrazzini_advisory_footer_contact_email ) : ?>
					<a href="mailto:<?php echo esc_attr( $ferrazzini_advisory_footer_contact_email ); ?>"><?php echo esc_html( $ferrazzini_advisory_footer_contact_email ); ?></a>
				<?php endif; ?>
			</address>
		</div>
	</div>

	<div class="ferrazzini-footer__bottom">
		<p>
			<?php
			echo esc_html(
				sprintf(
					/* translators: 1: current year, 2: site name. */
					ferrazzini_advisory_frontend_text( __( '© %1$s %2$s. Tutti i diritti riservati.', 'ferrazzini-advisory' ), 'theme:ferrazzini:footer:copyright' ),
					wp_date( 'Y' ),
					get_bloginfo( 'name' )
				)
			);
			?>
		</p>
		<?php if ( $ferrazzini_advisory_footer_privacy_url ) : ?>
			<p class="ferrazzini-footer__privacy">
				<a href="<?php echo esc_url( $ferrazzini_advisory_footer_privacy_url ); ?>">
					<?php echo esc_html( ferrazzini_advisory_frontend_text( __( 'Informativa sulla privacy', 'ferrazzini-advisory' ), 'theme:ferrazzini:footer:privacy' ) ); ?>
				</a>
			</p>
		<?php endif; ?>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
