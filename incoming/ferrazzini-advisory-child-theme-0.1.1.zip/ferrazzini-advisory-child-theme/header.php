<?php
/**
 * Site header for Ferrazzini Advisory & Tax SA.
 *
 * @package FerrazziniAdvisoryChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$ferrazzini_advisory_languages        = array();
$ferrazzini_advisory_current_language = array();
$ferrazzini_advisory_language_label   = '';
$ferrazzini_advisory_logo_url         = function_exists( 'ticinoweb_get_site_logo' ) ? ticinoweb_get_site_logo() : get_option( 'ticinoweb_site_logo', '' );
$ferrazzini_advisory_logo_dimensions  = $ferrazzini_advisory_logo_url && function_exists( 'ferrazzini_advisory_logo_dimensions' ) ? ferrazzini_advisory_logo_dimensions( $ferrazzini_advisory_logo_url ) : array();

if ( function_exists( 'twtr_get_languages' ) ) {
	$ferrazzini_advisory_available_languages = twtr_get_languages();

	foreach ( array( 'it', 'de', 'fr', 'en' ) as $ferrazzini_advisory_language_slug ) {
		if ( isset( $ferrazzini_advisory_available_languages[ $ferrazzini_advisory_language_slug ] ) ) {
			$ferrazzini_advisory_languages[ $ferrazzini_advisory_language_slug ] = $ferrazzini_advisory_available_languages[ $ferrazzini_advisory_language_slug ];
		}
	}

	foreach ( $ferrazzini_advisory_languages as $ferrazzini_advisory_language ) {
		if ( ! empty( $ferrazzini_advisory_language['is_current'] ) ) {
			$ferrazzini_advisory_current_language = $ferrazzini_advisory_language;
			break;
		}
	}

	if ( $ferrazzini_advisory_current_language ) {
		$ferrazzini_advisory_language_label = sprintf(
			/* translators: %s: current language name. */
			ferrazzini_advisory_frontend_text( __( 'Lingua corrente: %s. Cambia lingua.', 'ferrazzini-advisory' ), 'theme:ferrazzini:header:current_language' ),
			$ferrazzini_advisory_current_language['label']
		);
	}
}
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="ferrazzini-skip-link screen-reader-text" href="#contenuto-principale">
	<?php echo esc_html( ferrazzini_advisory_frontend_text( __( 'Vai al contenuto', 'ferrazzini-advisory' ), 'theme:ferrazzini:header:skip_link' ) ); ?>
</a>

<header class="ferrazzini-header">
	<a class="ferrazzini-header__brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
		<?php if ( $ferrazzini_advisory_logo_url ) : ?>
			<img
				class="ferrazzini-header__logo"
				src="<?php echo esc_url( $ferrazzini_advisory_logo_url ); ?>"
				alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"
				<?php if ( $ferrazzini_advisory_logo_dimensions ) : ?>
					width="<?php echo esc_attr( $ferrazzini_advisory_logo_dimensions['width'] ); ?>"
					height="<?php echo esc_attr( $ferrazzini_advisory_logo_dimensions['height'] ); ?>"
				<?php endif; ?>
				loading="eager"
				decoding="async"
				fetchpriority="high"
			>
		<?php else : ?>
			<?php echo esc_html( get_bloginfo( 'name' ) ); ?>
		<?php endif; ?>
	</a>

	<button
		class="ferrazzini-menu-toggle"
		type="button"
		aria-expanded="false"
		aria-controls="ferrazzini-primary-navigation"
		aria-label="<?php echo esc_attr( ferrazzini_advisory_frontend_text( __( 'Apri il menu', 'ferrazzini-advisory' ), 'theme:ferrazzini:header:menu_open' ) ); ?>"
	>
		<span aria-hidden="true"></span>
		<span aria-hidden="true"></span>
		<span aria-hidden="true"></span>
	</button>

	<div class="ferrazzini-header__menu">
		<nav
			id="ferrazzini-primary-navigation"
			class="ferrazzini-navigation"
			aria-label="<?php echo esc_attr( ferrazzini_advisory_frontend_text( __( 'Navigazione principale', 'ferrazzini-advisory' ), 'theme:ferrazzini:header:primary_navigation' ) ); ?>"
		>
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'menu_class'     => 'ferrazzini-navigation__list',
					'container'      => false,
					'fallback_cb'    => 'ferrazzini_advisory_primary_menu_fallback',
					'depth'          => 2,
				)
			);
			?>
		</nav>

		<?php if ( count( $ferrazzini_advisory_languages ) > 1 && $ferrazzini_advisory_current_language ) : ?>
			<nav
				class="ferrazzini-language-switcher"
				aria-label="<?php echo esc_attr( ferrazzini_advisory_frontend_text( __( 'Selezione della lingua', 'ferrazzini-advisory' ), 'theme:ferrazzini:header:language_navigation' ) ); ?>"
			>
				<details>
					<summary aria-label="<?php echo esc_attr( $ferrazzini_advisory_language_label ); ?>">
						<span class="ferrazzini-language-switcher__code"><?php echo esc_html( strtoupper( $ferrazzini_advisory_current_language['slug'] ) ); ?></span>
					</summary>
					<ul class="ferrazzini-language-switcher__list">
						<?php foreach ( $ferrazzini_advisory_languages as $ferrazzini_advisory_language ) : ?>
							<?php $ferrazzini_advisory_hreflang = str_replace( '_', '-', $ferrazzini_advisory_language['locale'] ); ?>
							<li>
								<a
									href="<?php echo esc_url( $ferrazzini_advisory_language['url'] ); ?>"
									hreflang="<?php echo esc_attr( $ferrazzini_advisory_hreflang ); ?>"
									lang="<?php echo esc_attr( $ferrazzini_advisory_hreflang ); ?>"
									<?php if ( ! empty( $ferrazzini_advisory_language['is_current'] ) ) : ?>
										aria-current="page"
									<?php endif; ?>
								>
									<span><?php echo esc_html( $ferrazzini_advisory_language['label'] ); ?></span>
									<span class="ferrazzini-language-switcher__option-code" aria-hidden="true"><?php echo esc_html( strtoupper( $ferrazzini_advisory_language['slug'] ) ); ?></span>
								</a>
							</li>
						<?php endforeach; ?>
					</ul>
				</details>
			</nav>
		<?php endif; ?>
	</div>

	<a class="ferrazzini-header__cta" href="<?php echo esc_url( home_url( '/contatti/' ) ); ?>">
		<span><?php echo esc_html( ferrazzini_advisory_frontend_text( __( 'Parliamone', 'ferrazzini-advisory' ), 'theme:ferrazzini:header:cta' ) ); ?></span>
	</a>
</header>
