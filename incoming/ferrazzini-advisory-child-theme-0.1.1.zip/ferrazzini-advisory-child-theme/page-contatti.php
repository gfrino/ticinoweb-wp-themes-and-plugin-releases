<?php
/**
 * Template Name: Contatti Ferrazzini
 * Template Post Type: page
 *
 * @package FerrazziniAdvisoryChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$ferrazzini_advisory_contact_page      = ferrazzini_advisory_contact_page_content();
$ferrazzini_advisory_privacy_url       = function_exists( 'ferrazzini_advisory_get_privacy_policy_url' ) ? ferrazzini_advisory_get_privacy_policy_url() : '';
$ferrazzini_advisory_contact_info      = function_exists( 'ticinoweb_get_contact_info' ) ? ticinoweb_get_contact_info() : array();
$ferrazzini_advisory_contact_email     = ! empty( $ferrazzini_advisory_contact_info['email'] ) ? sanitize_email( $ferrazzini_advisory_contact_info['email'] ) : '';
$ferrazzini_advisory_contact_phone     = ! empty( $ferrazzini_advisory_contact_info['phone'] ) ? sanitize_text_field( $ferrazzini_advisory_contact_info['phone'] ) : '';
$ferrazzini_advisory_contact_tel       = $ferrazzini_advisory_contact_phone ? preg_replace( '/[^0-9+]/', '', $ferrazzini_advisory_contact_phone ) : '';
$ferrazzini_advisory_contact_address   = ! empty( $ferrazzini_advisory_contact_info['address'] ) ? sanitize_text_field( $ferrazzini_advisory_contact_info['address'] ) : '';
$ferrazzini_advisory_contact_map_url   = $ferrazzini_advisory_contact_address ? add_query_arg(
	array(
		'api'   => '1',
		'query' => $ferrazzini_advisory_contact_address,
	),
	'https://www.google.com/maps/search/'
) : '';
$ferrazzini_advisory_contact_map_embed = $ferrazzini_advisory_contact_address ? add_query_arg(
	array(
		'q'      => $ferrazzini_advisory_contact_address,
		'output' => 'embed',
	),
	'https://www.google.com/maps'
) : '';
// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only status used after the form redirect.
$ferrazzini_advisory_contact_form_status = isset( $_GET['contact'] ) ? sanitize_key( wp_unslash( $_GET['contact'] ) ) : '';
// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Random token only retrieves single-use transient form data.
$ferrazzini_advisory_contact_flash_token = isset( $_GET['submission'] ) ? sanitize_key( wp_unslash( $_GET['submission'] ) ) : '';
$ferrazzini_advisory_contact_flash       = $ferrazzini_advisory_contact_flash_token ? ferrazzini_advisory_consume_contact_flash( $ferrazzini_advisory_contact_flash_token ) : array();
$ferrazzini_advisory_contact_values      = array(
	'name'    => '',
	'email'   => '',
	'phone'   => '',
	'message' => '',
);
$ferrazzini_advisory_contact_errors      = array();
$ferrazzini_advisory_contact_limits      = ferrazzini_advisory_contact_field_limits();

if ( ! empty( $ferrazzini_advisory_contact_flash['values'] ) && is_array( $ferrazzini_advisory_contact_flash['values'] ) ) {
	$ferrazzini_advisory_contact_values = array_merge(
		$ferrazzini_advisory_contact_values,
		ferrazzini_advisory_normalize_contact_submission( $ferrazzini_advisory_contact_flash['values'] )
	);
}

if ( ! empty( $ferrazzini_advisory_contact_flash['errors'] ) && is_array( $ferrazzini_advisory_contact_flash['errors'] ) ) {
	$ferrazzini_advisory_contact_error_messages = ferrazzini_advisory_contact_error_messages();
	$ferrazzini_advisory_contact_error_fields   = ferrazzini_advisory_contact_error_fields();

	foreach ( $ferrazzini_advisory_contact_flash['errors'] as $ferrazzini_advisory_contact_error_code ) {
		$ferrazzini_advisory_contact_error_code = sanitize_key( $ferrazzini_advisory_contact_error_code );
		if ( isset( $ferrazzini_advisory_contact_error_fields[ $ferrazzini_advisory_contact_error_code ], $ferrazzini_advisory_contact_error_messages[ $ferrazzini_advisory_contact_error_code ] ) ) {
			$ferrazzini_advisory_contact_errors[ $ferrazzini_advisory_contact_error_fields[ $ferrazzini_advisory_contact_error_code ] ] = $ferrazzini_advisory_contact_error_messages[ $ferrazzini_advisory_contact_error_code ];
		}
	}
}

$ferrazzini_advisory_contact_first_error = $ferrazzini_advisory_contact_errors ? (string) array_key_first( $ferrazzini_advisory_contact_errors ) : '';
$ferrazzini_advisory_contact_status_copy = array(
	'success'  => ferrazzini_advisory_frontend_text( __( 'Grazie. La richiesta è stata inviata correttamente: vi risponderemo appena possibile.', 'ferrazzini-advisory' ), 'theme:ferrazzini:contact_page:status_success' ),
	'invalid'  => ferrazzini_advisory_frontend_text( __( 'Controllate i campi indicati e riprovate.', 'ferrazzini-advisory' ), 'theme:ferrazzini:contact_page:status_invalid' ),
	'security' => ferrazzini_advisory_frontend_text( __( 'La sessione è scaduta. Ricaricate la pagina e riprovate.', 'ferrazzini-advisory' ), 'theme:ferrazzini:contact_page:status_security' ),
	'rate'     => ferrazzini_advisory_frontend_text( __( 'La richiesta è già stata ricevuta. Attendete qualche istante prima di inviarne un’altra.', 'ferrazzini-advisory' ), 'theme:ferrazzini:contact_page:status_rate' ),
	'send'     => ferrazzini_advisory_frontend_text( __( 'Non è stato possibile inviare la richiesta. Potete contattarci direttamente via email o telefono.', 'ferrazzini-advisory' ), 'theme:ferrazzini:contact_page:status_send' ),
);

get_header();
?>
<main id="contenuto-principale" class="ferrazzini-contact-page">
	<section class="ferrazzini-contact-page__hero" aria-labelledby="ferrazzini-contact-page-title">
		<div class="ferrazzini-contact-page__hero-copy">
			<h1 id="ferrazzini-contact-page-title"><?php echo esc_html( $ferrazzini_advisory_contact_page['hero_title'] ); ?></h1>
			<p><?php echo esc_html( $ferrazzini_advisory_contact_page['hero_intro'] ); ?></p>
		</div>

		<div class="ferrazzini-contact-page__hero-details">
			<?php if ( $ferrazzini_advisory_contact_phone && $ferrazzini_advisory_contact_tel ) : ?>
				<div class="ferrazzini-contact-page__detail">
					<span><?php echo esc_html( ferrazzini_advisory_frontend_text( __( 'Telefono', 'ferrazzini-advisory' ), 'theme:ferrazzini:contact:phone' ) ); ?></span>
					<a href="tel:<?php echo esc_attr( $ferrazzini_advisory_contact_tel ); ?>"><?php echo esc_html( $ferrazzini_advisory_contact_phone ); ?></a>
				</div>
			<?php endif; ?>

			<?php if ( $ferrazzini_advisory_contact_email ) : ?>
				<div class="ferrazzini-contact-page__detail">
					<span><?php echo esc_html( ferrazzini_advisory_frontend_text( __( 'Email', 'ferrazzini-advisory' ), 'theme:ferrazzini:contact:email' ) ); ?></span>
					<a href="mailto:<?php echo esc_attr( $ferrazzini_advisory_contact_email ); ?>"><?php echo esc_html( $ferrazzini_advisory_contact_email ); ?></a>
				</div>
			<?php endif; ?>

			<?php if ( $ferrazzini_advisory_contact_address ) : ?>
				<div class="ferrazzini-contact-page__detail">
					<span><?php echo esc_html( ferrazzini_advisory_frontend_text( __( 'Sede', 'ferrazzini-advisory' ), 'theme:ferrazzini:contact:office' ) ); ?></span>
					<address><?php echo esc_html( $ferrazzini_advisory_contact_address ); ?></address>
				</div>
			<?php endif; ?>
		</div>
	</section>

	<section class="ferrazzini-contact-page__body" aria-label="<?php echo esc_attr( ferrazzini_advisory_frontend_text( __( 'Modulo e posizione', 'ferrazzini-advisory' ), 'theme:ferrazzini:contact_page:body_label' ) ); ?>">
		<div id="modulo-contatti" class="ferrazzini-contact-page__form-panel">
			<header>
				<h2><?php echo esc_html( $ferrazzini_advisory_contact_page['form_title'] ); ?></h2>
				<p><?php echo esc_html( $ferrazzini_advisory_contact_page['form_intro'] ); ?></p>
			</header>

			<?php if ( isset( $ferrazzini_advisory_contact_status_copy[ $ferrazzini_advisory_contact_form_status ] ) ) : ?>
				<div class="ferrazzini-contact-form__status ferrazzini-contact-form__status--<?php echo esc_attr( $ferrazzini_advisory_contact_form_status ); ?>" role="<?php echo esc_attr( 'success' === $ferrazzini_advisory_contact_form_status ? 'status' : 'alert' ); ?>">
					<?php echo esc_html( $ferrazzini_advisory_contact_status_copy[ $ferrazzini_advisory_contact_form_status ] ); ?>
				</div>
			<?php endif; ?>

			<form class="ferrazzini-contact-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="ferrazzini_contact">
				<?php wp_nonce_field( 'ferrazzini_contact_submission', 'ferrazzini_contact_nonce' ); ?>

				<div class="ferrazzini-contact-form__field<?php echo isset( $ferrazzini_advisory_contact_errors['name'] ) ? ' ferrazzini-contact-form__field--invalid' : ''; ?>">
					<label for="ferrazzini-contact-name"><?php echo esc_html( ferrazzini_advisory_frontend_text( __( 'Nome e cognome', 'ferrazzini-advisory' ), 'theme:ferrazzini:contact_page:field_name' ) ); ?></label>
					<input id="ferrazzini-contact-name" name="name" type="text" autocomplete="name" maxlength="<?php echo esc_attr( $ferrazzini_advisory_contact_limits['name'] ); ?>" value="<?php echo esc_attr( $ferrazzini_advisory_contact_values['name'] ); ?>"<?php echo isset( $ferrazzini_advisory_contact_errors['name'] ) ? ' aria-invalid="true" aria-describedby="ferrazzini-contact-name-error"' : ''; ?><?php echo 'name' === $ferrazzini_advisory_contact_first_error ? ' autofocus' : ''; ?> required>
					<?php if ( isset( $ferrazzini_advisory_contact_errors['name'] ) ) : ?>
						<p id="ferrazzini-contact-name-error" class="ferrazzini-contact-form__error"><?php echo esc_html( $ferrazzini_advisory_contact_errors['name'] ); ?></p>
					<?php endif; ?>
				</div>

				<div class="ferrazzini-contact-form__field<?php echo isset( $ferrazzini_advisory_contact_errors['email'] ) ? ' ferrazzini-contact-form__field--invalid' : ''; ?>">
					<label for="ferrazzini-contact-email"><?php echo esc_html( ferrazzini_advisory_frontend_text( __( 'Email', 'ferrazzini-advisory' ), 'theme:ferrazzini:contact_page:field_email' ) ); ?></label>
					<input id="ferrazzini-contact-email" name="email" type="email" autocomplete="email" maxlength="<?php echo esc_attr( $ferrazzini_advisory_contact_limits['email'] ); ?>" value="<?php echo esc_attr( $ferrazzini_advisory_contact_values['email'] ); ?>"<?php echo isset( $ferrazzini_advisory_contact_errors['email'] ) ? ' aria-invalid="true" aria-describedby="ferrazzini-contact-email-error"' : ''; ?><?php echo 'email' === $ferrazzini_advisory_contact_first_error ? ' autofocus' : ''; ?> required>
					<?php if ( isset( $ferrazzini_advisory_contact_errors['email'] ) ) : ?>
						<p id="ferrazzini-contact-email-error" class="ferrazzini-contact-form__error"><?php echo esc_html( $ferrazzini_advisory_contact_errors['email'] ); ?></p>
					<?php endif; ?>
				</div>

				<div class="ferrazzini-contact-form__field<?php echo isset( $ferrazzini_advisory_contact_errors['phone'] ) ? ' ferrazzini-contact-form__field--invalid' : ''; ?>">
					<label for="ferrazzini-contact-phone"><?php echo esc_html( ferrazzini_advisory_frontend_text( __( 'Telefono (facoltativo)', 'ferrazzini-advisory' ), 'theme:ferrazzini:contact_page:field_phone' ) ); ?></label>
					<input id="ferrazzini-contact-phone" name="phone" type="tel" autocomplete="tel" maxlength="<?php echo esc_attr( $ferrazzini_advisory_contact_limits['phone'] ); ?>" value="<?php echo esc_attr( $ferrazzini_advisory_contact_values['phone'] ); ?>"<?php echo isset( $ferrazzini_advisory_contact_errors['phone'] ) ? ' aria-invalid="true" aria-describedby="ferrazzini-contact-phone-error"' : ''; ?><?php echo 'phone' === $ferrazzini_advisory_contact_first_error ? ' autofocus' : ''; ?>>
					<?php if ( isset( $ferrazzini_advisory_contact_errors['phone'] ) ) : ?>
						<p id="ferrazzini-contact-phone-error" class="ferrazzini-contact-form__error"><?php echo esc_html( $ferrazzini_advisory_contact_errors['phone'] ); ?></p>
					<?php endif; ?>
				</div>

				<div class="ferrazzini-contact-form__field<?php echo isset( $ferrazzini_advisory_contact_errors['message'] ) ? ' ferrazzini-contact-form__field--invalid' : ''; ?>">
					<label for="ferrazzini-contact-message"><?php echo esc_html( ferrazzini_advisory_frontend_text( __( 'Messaggio', 'ferrazzini-advisory' ), 'theme:ferrazzini:contact_page:field_message' ) ); ?></label>
					<textarea id="ferrazzini-contact-message" name="message" rows="5" maxlength="<?php echo esc_attr( $ferrazzini_advisory_contact_limits['message'] ); ?>"<?php echo isset( $ferrazzini_advisory_contact_errors['message'] ) ? ' aria-invalid="true" aria-describedby="ferrazzini-contact-message-error"' : ''; ?><?php echo 'message' === $ferrazzini_advisory_contact_first_error ? ' autofocus' : ''; ?> required><?php echo esc_textarea( $ferrazzini_advisory_contact_values['message'] ); ?></textarea>
					<?php if ( isset( $ferrazzini_advisory_contact_errors['message'] ) ) : ?>
						<p id="ferrazzini-contact-message-error" class="ferrazzini-contact-form__error"><?php echo esc_html( $ferrazzini_advisory_contact_errors['message'] ); ?></p>
					<?php endif; ?>
				</div>

				<div class="ferrazzini-contact-form__honeypot" aria-hidden="true">
					<label for="ferrazzini-contact-company"><?php esc_html_e( 'Sito web aziendale', 'ferrazzini-advisory' ); ?></label>
					<input id="ferrazzini-contact-company" name="company_website" type="text" tabindex="-1" autocomplete="off">
				</div>

				<?php if ( $ferrazzini_advisory_privacy_url ) : ?>
					<p class="ferrazzini-contact-form__privacy">
						<?php echo esc_html( ferrazzini_advisory_frontend_text( __( 'Per informazioni sul trattamento dei dati personali, consultate la', 'ferrazzini-advisory' ), 'theme:ferrazzini:contact_page:privacy_intro' ) ); ?>
						<a href="<?php echo esc_url( $ferrazzini_advisory_privacy_url ); ?>"><?php echo esc_html( ferrazzini_advisory_frontend_text( __( 'nostra informativa sulla privacy', 'ferrazzini-advisory' ), 'theme:ferrazzini:contact_page:privacy_link' ) ); ?></a>.
					</p>
				<?php endif; ?>

				<button class="ferrazzini-contact-form__submit" type="submit">
					<span><?php echo esc_html( ferrazzini_advisory_frontend_text( __( 'Invia la richiesta', 'ferrazzini-advisory' ), 'theme:ferrazzini:contact_page:submit' ) ); ?></span>
				</button>
			</form>
		</div>

		<div class="ferrazzini-contact-page__location">
			<h2><?php echo esc_html( $ferrazzini_advisory_contact_page['location_title'] ); ?></h2>

			<?php if ( $ferrazzini_advisory_contact_map_embed ) : ?>
				<div class="ferrazzini-contact-page__map">
					<iframe
						src="<?php echo esc_url( $ferrazzini_advisory_contact_map_embed ); ?>"
						title="<?php echo esc_attr( ferrazzini_advisory_frontend_text( __( 'Mappa della sede di Ferrazzini Advisory & Tax SA', 'ferrazzini-advisory' ), 'theme:ferrazzini:contact_page:map_title' ) ); ?>"
						loading="lazy"
						referrerpolicy="no-referrer-when-downgrade"
					></iframe>
				</div>
			<?php endif; ?>

			<?php if ( $ferrazzini_advisory_contact_address ) : ?>
				<address><?php echo esc_html( $ferrazzini_advisory_contact_address ); ?></address>
			<?php endif; ?>

			<?php if ( $ferrazzini_advisory_contact_map_url ) : ?>
				<a class="ferrazzini-contact-page__map-link" href="<?php echo esc_url( $ferrazzini_advisory_contact_map_url ); ?>">
					<span><?php echo esc_html( ferrazzini_advisory_frontend_text( __( 'Apri in Google Maps', 'ferrazzini-advisory' ), 'theme:ferrazzini:contact:maps' ) ); ?></span>
					<svg aria-hidden="true" viewBox="0 0 16 16" width="16" height="16" focusable="false">
						<path d="M4 12 12 4M6 4h6v6" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" />
					</svg>
				</a>
			<?php endif; ?>
		</div>
	</section>
</main>
<?php
get_footer();
