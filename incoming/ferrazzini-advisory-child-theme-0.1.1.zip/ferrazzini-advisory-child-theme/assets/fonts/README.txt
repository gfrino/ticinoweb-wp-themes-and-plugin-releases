Manrope Variable Font
Copyright (c) 2018 The Manrope Project Authors
License: SIL Open Font License, 1.1 — https://opensource.org/licenses/OFL-1.1
Reference: https://github.com/sharanda/manrope
Source asset: WordPress Twenty Twenty-Five theme bundled with this workspace.
