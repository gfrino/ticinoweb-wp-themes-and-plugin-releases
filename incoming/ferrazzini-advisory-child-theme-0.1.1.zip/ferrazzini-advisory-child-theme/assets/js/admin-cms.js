const headingSelect = document.querySelector("#ticinoweb_font_headings");

if (headingSelect && window.ferrazziniCmsTypography?.heading) {
  const headingFont = window.ferrazziniCmsTypography.heading;
  const hasHeadingFont = Array.from(headingSelect.options).some(
    (option) => option.value === headingFont,
  );

  if (!hasHeadingFont) {
    headingSelect.add(new Option(headingFont, headingFont));
  }

  headingSelect.value = headingFont;
}
