(() => {
  const invalidField = document.querySelector(
    ".ferrazzini-contact-form [aria-invalid='true']",
  );

  if (!invalidField) {
    return;
  }

  window.addEventListener(
    "load",
    () => {
      window.requestAnimationFrame(() => {
        invalidField.focus({ preventScroll: true });
        invalidField.scrollIntoView({ block: "center" });
      });
    },
    { once: true },
  );
})();
