(() => {
  const root = document.documentElement;
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const releaseMediaPreparation = () => {
    window.clearTimeout(window.ferrazziniMediaMotionFallback);
    root.classList.remove("ferrazzini-media-motion-pending");
  };

  if (reducedMotion) {
    releaseMediaPreparation();
    root.classList.add("ferrazzini-motion-reduced");
    return;
  }

  if (!window.gsap || !window.ScrollTrigger) {
    releaseMediaPreparation();
    return;
  }

  if (root.classList.contains("ferrazzini-motion-initialized")) {
    releaseMediaPreparation();
    return;
  }

  const { gsap, ScrollTrigger } = window;
  const animatedElements = new Set();
  const ease = "power3.out";
  const focalDuration = 0.8;
  const supportingDuration = 0.7;

  gsap.registerPlugin(ScrollTrigger);
  root.classList.add("ferrazzini-motion-initialized");

  const elementsFor = (selector, scope = document) =>
    gsap.utils.toArray(selector, scope).filter((element) => element instanceof Element);

  const remember = (elements) => {
    elements.forEach((element) => animatedElements.add(element));
    return elements;
  };

  const clearAnimatedStyles = () => {
    if (animatedElements.size === 0) {
      return;
    }

    gsap.set(Array.from(animatedElements), {
      clearProps: "clipPath,opacity,scale,transform,visibility",
    });
  };

  const waitForImage = async (image) => {
    if (!(image instanceof HTMLImageElement)) {
      return;
    }

    if (!image.complete) {
      await new Promise((resolve) => {
        image.addEventListener("load", resolve, { once: true });
        image.addEventListener("error", resolve, { once: true });
      });
    }

    if (typeof image.decode === "function") {
      await image.decode().catch(() => undefined);
    }
  };

  const prepareContentImage = (image, distance, options = {}) => {
    if (!(image instanceof HTMLImageElement) || image.dataset.motionImage === "ready") {
      return;
    }

    image.dataset.motionImage = "ready";
    remember([image]);

    let hasPlayed = false;

    const showImmediately = () => {
      hasPlayed = true;
      gsap.set(image, {
        clearProps: "opacity,scale,transform,visibility",
      });
    };

    const play = async () => {
      if (hasPlayed) {
        return;
      }

      hasPlayed = true;
      await Promise.race([
        waitForImage(image),
        new Promise((resolve) => window.setTimeout(resolve, 4000)),
      ]);

      gsap.fromTo(
        image,
        {
          opacity: 0.82,
          scale: 1.012,
          y: Math.min(distance, 16),
        },
        {
          opacity: 1,
          scale: 1,
          y: 0,
          delay: options.delay ?? 0,
          duration: focalDuration,
          ease,
          clearProps: "opacity,scale,transform,visibility",
          onComplete: () => ScrollTrigger.refresh(),
        },
      );
    };

    const bounds = image.getBoundingClientRect();

    if (bounds.bottom <= 0) {
      showImmediately();
      return;
    }

    if (bounds.top < window.innerHeight * 0.92 && bounds.bottom > 0) {
      void play();
      return;
    }

    ScrollTrigger.create({
      trigger: options.trigger ?? image,
      start: "top 88%",
      once: true,
      onEnter: () => void play(),
      onEnterBack: () => void play(),
    });
  };

  const prepareContentImages = (distance) => {
    elementsFor(
      ".ferrazzini-hero__media img, .ferrazzini-about-page__hero-media img, .ferrazzini-service-detail__media img",
    ).forEach((image) => prepareContentImage(image, distance, { delay: 0.08 }));

    elementsFor(".ferrazzini-team-profile__media img").forEach((image, index) => {
      prepareContentImage(image, distance, {
        delay: Math.min(index * 0.06, 0.12),
        trigger: image.closest(".ferrazzini-team-profile") ?? image,
      });
    });
  };

  const reveal = ({
    trigger,
    targets,
    from = { opacity: 0, y: 28 },
    duration = 0.68,
    stagger = 0,
    start = "top 84%",
  }) => {
    const triggerElement = document.querySelector(trigger);
    const targetElements = remember(elementsFor(targets));

    if (!triggerElement || targetElements.length === 0) {
      return;
    }

    gsap.fromTo(targetElements, from, {
      opacity: 1,
      clipPath: "inset(0% 0% 0% 0%)",
      duration,
      ease,
      scale: 1,
      stagger,
      x: 0,
      y: 0,
      clearProps: "clipPath,opacity,scale,transform,visibility",
      scrollTrigger: {
        trigger: triggerElement,
        start,
        once: true,
      },
    });
  };

  const revealHomeHero = (distance) => {
    const titleLines = remember(elementsFor(".ferrazzini-hero__title > span"));
    const supportingCopy = remember(
      elementsFor(".ferrazzini-hero__intro, .ferrazzini-hero__actions"),
    );

    if (titleLines.length === 0) {
      return;
    }

    const timeline = gsap.timeline({ defaults: { ease } });

    timeline
      .fromTo(
        titleLines,
        { opacity: 0, y: distance },
        {
          opacity: 1,
          clearProps: "opacity,transform,visibility",
          duration: focalDuration,
          stagger: 0.09,
          y: 0,
        },
      )
      .fromTo(
        supportingCopy,
        { opacity: 0, y: distance * 0.55 },
        {
          opacity: 1,
          clearProps: "opacity,transform,visibility",
          duration: supportingDuration,
          stagger: 0.08,
          y: 0,
        },
        "-=0.42",
      );
  };

  const revealInnerHero = () => {
    const heroConfigurations = [
      {
        root: ".ferrazzini-about-page__hero",
        copy: ".ferrazzini-about-page__hero-copy > *",
      },
      {
        root: ".ferrazzini-contact-page__hero",
        copy: ".ferrazzini-contact-page__hero-copy > *",
        secondary: ".ferrazzini-contact-page__hero-details > *",
      },
      {
        root: ".ferrazzini-service-detail__main",
        copy: ".ferrazzini-service-detail__content > h1, .ferrazzini-service-detail__intro",
      },
    ];

    const configuration = heroConfigurations.find(({ root: selector }) =>
      document.querySelector(selector),
    );

    if (!configuration) {
      return;
    }

    const copy = remember(elementsFor(configuration.copy));
    const secondary = configuration.secondary
      ? remember(elementsFor(configuration.secondary))
      : [];
    const timeline = gsap.timeline({ defaults: { ease } });

    timeline.fromTo(
      copy,
      { opacity: 0 },
      {
        opacity: 1,
        clearProps: "opacity,visibility",
        duration: focalDuration,
        stagger: 0.1,
      },
    );

    if (secondary.length > 0) {
      timeline.fromTo(
        secondary,
        { opacity: 0, y: 12 },
        {
          opacity: 1,
          clearProps: "opacity,transform,visibility",
          duration: supportingDuration,
          stagger: 0.08,
          y: 0,
        },
        "-=0.45",
      );
    }
  };

  const buildScrollSequences = (distance) => {
    const sequences = [
      {
        trigger: "#servizi .ferrazzini-section__heading",
        targets: "#servizi .ferrazzini-section__heading",
      },
      {
        trigger: ".ferrazzini-services__list",
        targets: ".ferrazzini-services__list > .ferrazzini-service",
        from: { opacity: 0, y: distance * 0.55 },
        stagger: 0.09,
      },
      {
        trigger: "#chi-siamo",
        targets: "#chi-siamo h2, #chi-siamo .ferrazzini-about__copy > *",
        stagger: 0.08,
      },
      {
        trigger: "#metodo .ferrazzini-approach__heading",
        targets: "#metodo .ferrazzini-approach__heading",
      },
      {
        trigger: ".ferrazzini-approach__steps",
        targets: ".ferrazzini-approach__steps > li",
        from: { opacity: 0, y: distance * 0.45 },
        stagger: 0.08,
      },
      {
        trigger: ".ferrazzini-contact",
        targets: ".ferrazzini-contact__panel",
        from: { opacity: 0, clipPath: "inset(0% 0% 10% 0%)", y: distance * 0.55 },
        stagger: 0.1,
      },
      {
        trigger: ".ferrazzini-about-story",
        targets: ".ferrazzini-about-story > h2, .ferrazzini-about-story__copy > *",
        stagger: 0.08,
      },
      {
        trigger: ".ferrazzini-about-team__heading",
        targets: ".ferrazzini-about-team__heading > *",
        stagger: 0.08,
      },
      {
        trigger: ".ferrazzini-about-team__profiles",
        targets: ".ferrazzini-team-profile__content",
        from: { opacity: 0, y: distance },
        stagger: 0.12,
      },
      {
        trigger: ".ferrazzini-about-contact",
        targets: ".ferrazzini-about-contact > *",
        stagger: 0.08,
      },
      {
        trigger: ".ferrazzini-contact-page__body",
        targets: ".ferrazzini-contact-page__form-panel, .ferrazzini-contact-page__location",
        from: { opacity: 0, clipPath: "inset(0% 0% 8% 0%)", y: distance * 0.65 },
        stagger: 0.1,
      },
      {
        trigger: ".ferrazzini-service-detail__support",
        targets: ".ferrazzini-service-detail__support > h2, .ferrazzini-service-detail__support li",
        stagger: 0.06,
      },
      {
        trigger: ".ferrazzini-service-detail__closing",
        targets: ".ferrazzini-service-detail__closing-copy, .ferrazzini-service-detail__related",
        stagger: 0.1,
      },
    ];

    sequences.forEach((sequence) => reveal(sequence));
  };

  try {
    const mobile = window.matchMedia("(max-width: 48rem)").matches;
    const distance = mobile ? 18 : 30;

    if (document.querySelector(".ferrazzini-home-main")) {
      revealHomeHero(distance);
    } else {
      revealInnerHero();
    }

    prepareContentImages(distance);
    buildScrollSequences(distance);
    root.classList.add("ferrazzini-motion-ready");
    releaseMediaPreparation();

    window.addEventListener("load", () => ScrollTrigger.refresh(), { once: true });
    window.addEventListener("pageshow", () => ScrollTrigger.refresh());
    document.fonts?.ready.then(() => ScrollTrigger.refresh());
  } catch (_error) {
    clearAnimatedStyles();
    releaseMediaPreparation();
    root.classList.remove("ferrazzini-motion-ready");
  }
})();
