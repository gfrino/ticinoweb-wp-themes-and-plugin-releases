document.querySelectorAll(".ferrazzini-home-media-field").forEach((field) => {
  const input = field.querySelector(".ferrazzini-home-media-url");
  const selectButton = field.querySelector(".ferrazzini-home-media-select");
  const removeButton = field.querySelector(".ferrazzini-home-media-remove");
  const preview = field.querySelector(".ferrazzini-home-media-preview");
  const previewImage = preview?.querySelector("img");

  if (!input || !selectButton || !removeButton || !preview || !previewImage) {
    return;
  }

  const updatePreview = (url) => {
    const hasImage = Boolean(url);

    preview.hidden = !hasImage;
    removeButton.hidden = !hasImage;
    previewImage.src = hasImage ? url : "";
  };

  selectButton.addEventListener("click", () => {
    if (!window.wp?.media) {
      return;
    }

    const frame = window.wp.media({
      title: window.ferrazziniHomepageMedia?.title ?? "Scegli l’immagine della hero",
      button: {
        text: window.ferrazziniHomepageMedia?.button ?? "Usa questa immagine",
      },
      library: { type: "image" },
      multiple: false,
    });

    frame.on("select", () => {
      const attachment = frame.state().get("selection").first()?.toJSON();

      if (!attachment?.url) {
        return;
      }

      input.value = attachment.url;
      updatePreview(attachment.url);

      const altInput = document.getElementById(field.dataset.altTarget);
      if (altInput && !altInput.value && attachment.alt) {
        altInput.value = attachment.alt;
      }

      input.dispatchEvent(new Event("change", { bubbles: true }));
    });

    frame.open();
  });

  removeButton.addEventListener("click", () => {
    input.value = "";
    updatePreview("");
    input.dispatchEvent(new Event("change", { bubbles: true }));
    input.focus();
  });

  input.addEventListener("input", () => updatePreview(input.value.trim()));
});
