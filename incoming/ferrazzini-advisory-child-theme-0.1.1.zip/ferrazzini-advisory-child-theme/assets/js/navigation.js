(() => {
  const header = document.querySelector(".ferrazzini-header");
  const toggle = header?.querySelector(".ferrazzini-menu-toggle");
  const navigation = header?.querySelector(".ferrazzini-navigation");
  const servicesItem = navigation?.querySelector(
    ".ferrazzini-navigation__services",
  );
  const servicesToggle = servicesItem?.querySelector(
    ":scope > .ferrazzini-navigation__submenu-toggle",
  );
  const languageDetails = header?.querySelector(
    ".ferrazzini-language-switcher details",
  );
  const languageSummary = languageDetails?.querySelector("summary");
  const labels = window.ferrazziniNavigation ?? {
    openMenu: "Apri il menu",
    closeMenu: "Chiudi il menu",
  };

  if (!header || !toggle || !navigation) {
    return;
  }

  const setOpen = (isOpen) => {
    if (isOpen) {
      header.setAttribute("data-menu-open", "");
    } else {
      header.removeAttribute("data-menu-open");
    }

    toggle.setAttribute("aria-expanded", String(isOpen));
    toggle.setAttribute("aria-label", isOpen ? labels.closeMenu : labels.openMenu);
  };

  const setServicesOpen = (isOpen) => {
    if (!servicesItem || !servicesToggle) {
      return;
    }

    servicesItem.toggleAttribute("data-submenu-open", isOpen);
    servicesToggle.setAttribute("aria-expanded", String(isOpen));
  };

  header.setAttribute("data-menu-ready", "");

  toggle.addEventListener("click", () => {
    setOpen(!header.hasAttribute("data-menu-open"));
  });

  servicesToggle?.addEventListener("click", () => {
    const isDesktop = window.matchMedia("(min-width: 64.01rem)").matches;

    setServicesOpen(
      isDesktop || !servicesItem.hasAttribute("data-submenu-open"),
    );
  });

  servicesItem?.addEventListener("mouseenter", () => {
    if (window.matchMedia("(min-width: 64.01rem)").matches) {
      setServicesOpen(true);
    }
  });

  servicesItem?.addEventListener("mouseleave", () => {
    if (window.matchMedia("(min-width: 64.01rem)").matches) {
      setServicesOpen(false);
    }
  });

  navigation.addEventListener("click", (event) => {
    if (event.target.closest("a")) {
      setServicesOpen(false);
      setOpen(false);
    }
  });

  document.addEventListener("click", (event) => {
    if (
      servicesItem?.hasAttribute("data-submenu-open") &&
      !servicesItem.contains(event.target)
    ) {
      setServicesOpen(false);
    }

    if (languageDetails?.open && !languageDetails.contains(event.target)) {
      languageDetails.removeAttribute("open");
    }
  });

  document.addEventListener("keydown", (event) => {
    if (event.key !== "Escape") {
      return;
    }

    if (languageDetails?.open) {
      languageDetails.removeAttribute("open");
      languageSummary?.focus();
      return;
    }

    if (servicesItem?.hasAttribute("data-submenu-open")) {
      setServicesOpen(false);
      servicesToggle?.focus();
      return;
    }

    if (header.hasAttribute("data-menu-open")) {
      setOpen(false);
      toggle.focus();
    }
  });

  window.addEventListener("resize", () => {
    if (window.matchMedia("(min-width: 64.01rem)").matches) {
      setOpen(false);
    }

    setServicesOpen(false);
    languageDetails?.removeAttribute("open");
  });
})();
