document.querySelectorAll(".ferrazzini-about-media-select").forEach((button) => {
  button.addEventListener("click", () => {
    const target = document.getElementById(button.dataset.target);

    if (!target || !window.wp?.media) {
      return;
    }

    const frame = window.wp.media({
      title: window.ferrazziniAboutMedia?.title ?? "Scegli una fotografia",
      button: {
        text: window.ferrazziniAboutMedia?.button ?? "Usa questa fotografia",
      },
      library: { type: "image" },
      multiple: false,
    });

    frame.on("select", () => {
      const attachment = frame.state().get("selection").first()?.toJSON();

      if (attachment?.url) {
        target.value = attachment.url;
        target.dispatchEvent(new Event("change", { bubbles: true }));
      }
    });

    frame.open();
  });
});
