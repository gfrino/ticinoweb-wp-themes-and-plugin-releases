<?php
/**
 * Ferrazzini Advisory & Tax child theme bootstrap.
 *
 * @package FerrazziniAdvisoryChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pass child-theme copy through the parent translation compatibility layer.
 *
 * @param string $text    Source text.
 * @param string $context Stable translation context.
 * @return string
 */
function ferrazzini_advisory_frontend_text( $text, $context ) {
	if ( function_exists( 'ticinoweb_frontend_text' ) ) {
		return ticinoweb_frontend_text( $text, $context );
	}

	return $text;
}

require_once get_stylesheet_directory() . '/inc/privacy.php';
require_once get_stylesheet_directory() . '/inc/media.php';
require_once get_stylesheet_directory() . '/inc/homepage-cms.php';
require_once get_stylesheet_directory() . '/inc/services-page-cms.php';
require_once get_stylesheet_directory() . '/inc/contact-security.php';
require_once get_stylesheet_directory() . '/inc/contact-page-cms.php';
require_once get_stylesheet_directory() . '/inc/about-page-cms.php';

/**
 * Return the visual defaults currently approved for the Ferrazzini prototype.
 *
 * @return array<string, string>
 */
function ferrazzini_advisory_design_defaults() {
	return array(
		'heading_font' => 'Manrope',
		'body_font'    => 'Manrope',
		'primary'      => '#176584',
		'primary_dark' => '#0e4f6c',
		'background'   => '#faf8f3',
		'ink'          => '#1f2930',
	);
}

/**
 * Return a CMS font value only when it belongs to the supported set.
 *
 * @param string $option_name Option to read.
 * @param string $fallback    Safe fallback.
 * @return string
 */
function ferrazzini_advisory_get_font( $option_name, $fallback ) {
	$allowed = array(
		'Poppins',
		'Inter',
		'Montserrat',
		'Nunito',
		'Roboto',
		'Open Sans',
		'Lato',
		'Raleway',
		'Merriweather',
		'Playfair Display',
		'Source Sans 3',
		'Work Sans',
		'DM Sans',
		'Manrope',
		'Rubik',
	);
	$value   = (string) get_option( $option_name, $fallback );

	return in_array( $value, $allowed, true ) ? $value : $fallback;
}

/**
 * Return the CMS design tokens used by the child theme.
 *
 * @return array<string, string>
 */
function ferrazzini_advisory_get_design_tokens() {
	$defaults = ferrazzini_advisory_design_defaults();
	$tokens   = array(
		'heading_font' => ferrazzini_advisory_get_font( 'ticinoweb_font_headings', $defaults['heading_font'] ),
		'body_font'    => ferrazzini_advisory_get_font( 'ticinoweb_font_body', $defaults['body_font'] ),
		'primary'      => sanitize_hex_color( get_option( 'ticinoweb_palette_primary', $defaults['primary'] ) ),
		'primary_dark' => sanitize_hex_color( get_option( 'ticinoweb_palette_suggested_1', $defaults['primary_dark'] ) ),
		'background'   => sanitize_hex_color( get_option( 'ticinoweb_palette_suggested_2', $defaults['background'] ) ),
		'ink'          => sanitize_hex_color( get_option( 'ticinoweb_palette_suggested_3', $defaults['ink'] ) ),
	);

	foreach ( array( 'primary', 'primary_dark', 'background', 'ink' ) as $key ) {
		if ( empty( $tokens[ $key ] ) ) {
			$tokens[ $key ] = $defaults[ $key ];
		}
	}

	return $tokens;
}

/**
 * Build a Google Fonts URL for the CMS-selected families.
 *
 * @param array<string, string> $tokens Design tokens.
 * @return string
 */
function ferrazzini_advisory_google_fonts_url( $tokens ) {
	$families = array_unique( array( $tokens['heading_font'], $tokens['body_font'] ) );
	$queries  = array();

	foreach ( $families as $font ) {
		$family    = str_replace( '%20', '+', rawurlencode( $font ) );
		$queries[] = 'family=' . $family . ':wght@400;500;600';
	}

	return 'https://fonts.googleapis.com/css2?' . implode( '&', $queries ) . '&display=swap';
}

/**
 * Load the parent and child theme stylesheets.
 *
 * The parent theme uses get_stylesheet_uri(), which resolves to the child
 * stylesheet when a child theme is active. Replace that registration so both
 * stylesheets are loaded in the intended order.
 *
 * @return void
 */
function ferrazzini_advisory_enqueue_styles() {
	$parent_theme = wp_get_theme( get_template() );
	$child_theme  = wp_get_theme();

	wp_dequeue_style( 'ticinoweb-ai-style' );
	wp_deregister_style( 'ticinoweb-ai-style' );
	wp_dequeue_style( 'poppins-font' );
	wp_deregister_style( 'poppins-font' );

	wp_enqueue_style(
		'ticinoweb-ai-parent-style',
		get_template_directory_uri() . '/style.css',
		array(),
		$parent_theme->get( 'Version' )
	);

	wp_enqueue_style(
		'ferrazzini-advisory-child-style',
		get_stylesheet_uri(),
		array( 'ticinoweb-ai-parent-style' ),
		$child_theme->get( 'Version' )
	);
}
add_action( 'wp_enqueue_scripts', 'ferrazzini_advisory_enqueue_styles', 20 );

/**
 * Prepare content images before the first paint so their entrance cannot flash.
 *
 * @return void
 */
function ferrazzini_advisory_prepare_media_motion() {
	$is_motion_page = is_front_page()
		|| is_page( 'servizi' )
		|| is_page_template( 'page-servizio.php' )
		|| is_page_template( 'page-contatti.php' )
		|| is_page_template( 'page-chi-siamo.php' );

	if ( is_admin() || ! $is_motion_page ) {
		return;
	}

	wp_print_inline_script_tag(
		'(function(){document.documentElement.classList.add("ferrazzini-js");if(!window.matchMedia("(prefers-reduced-motion: reduce)").matches){document.documentElement.classList.add("ferrazzini-media-motion-pending");window.ferrazziniMediaMotionFallback=window.setTimeout(function(){document.documentElement.classList.remove("ferrazzini-media-motion-pending");},3000);}})();'
	);
}
add_action( 'wp_head', 'ferrazzini_advisory_prepare_media_motion', 1 );

/**
 * Load assets used only by the Ferrazzini front page.
 *
 * @return void
 */
function ferrazzini_advisory_enqueue_home_assets() {
	$is_services_page       = is_page( 'servizi' );
	$is_service_detail_page = is_page_template( 'page-servizio.php' );
	$is_contact_page        = is_page_template( 'page-contatti.php' );
	$is_about_page          = is_page_template( 'page-chi-siamo.php' );

	if ( ! is_front_page() && ! $is_services_page && ! $is_service_detail_page && ! $is_contact_page && ! $is_about_page ) {
		return;
	}

	$stylesheet_path = get_stylesheet_directory() . '/assets/css/home.css';
	$fonts_path      = get_stylesheet_directory() . '/assets/css/fonts.css';
	$services_path   = get_stylesheet_directory() . '/assets/css/services.css';
	$contact_path    = get_stylesheet_directory() . '/assets/css/contact.css';
	$about_path      = get_stylesheet_directory() . '/assets/css/about.css';
	$script_path     = get_stylesheet_directory() . '/assets/js/navigation.js';
	$contact_script  = get_stylesheet_directory() . '/assets/js/contact.js';
	$motion_script   = get_stylesheet_directory() . '/assets/js/motion.js';
	$child_theme     = wp_get_theme();
	$theme_version   = $child_theme->get( 'Version' );
	$tokens          = ferrazzini_advisory_get_design_tokens();

	$uses_local_manrope = 'Manrope' === $tokens['heading_font'] && 'Manrope' === $tokens['body_font'];

	wp_enqueue_style(
		'ferrazzini-advisory-fonts',
		$uses_local_manrope ? get_stylesheet_directory_uri() . '/assets/css/fonts.css' : ferrazzini_advisory_google_fonts_url( $tokens ),
		array(),
		$uses_local_manrope && file_exists( $fonts_path ) ? (string) filemtime( $fonts_path ) : $theme_version
	);

	wp_enqueue_style(
		'ferrazzini-advisory-home',
		get_stylesheet_directory_uri() . '/assets/css/home.css',
		array( 'ferrazzini-advisory-child-style', 'ferrazzini-advisory-fonts' ),
		file_exists( $stylesheet_path ) ? (string) filemtime( $stylesheet_path ) : null
	);

	if ( $is_services_page || $is_service_detail_page ) {
		wp_enqueue_style(
			'ferrazzini-advisory-services',
			get_stylesheet_directory_uri() . '/assets/css/services.css',
			array( 'ferrazzini-advisory-home' ),
			file_exists( $services_path ) ? (string) filemtime( $services_path ) : null
		);
	}

	if ( $is_contact_page ) {
		wp_enqueue_style(
			'ferrazzini-advisory-contact',
			get_stylesheet_directory_uri() . '/assets/css/contact.css',
			array( 'ferrazzini-advisory-home' ),
			file_exists( $contact_path ) ? (string) filemtime( $contact_path ) : null
		);

		wp_enqueue_script(
			'ferrazzini-advisory-contact',
			get_stylesheet_directory_uri() . '/assets/js/contact.js',
			array(),
			file_exists( $contact_script ) ? (string) filemtime( $contact_script ) : null,
			true
		);
	}

	if ( $is_about_page ) {
		wp_enqueue_style(
			'ferrazzini-advisory-about',
			get_stylesheet_directory_uri() . '/assets/css/about.css',
			array( 'ferrazzini-advisory-home' ),
			file_exists( $about_path ) ? (string) filemtime( $about_path ) : null
		);
	}

	wp_register_style(
		'ferrazzini-advisory-cms-tokens',
		false,
		array( 'ferrazzini-advisory-home' ),
		$theme_version
	);
	wp_enqueue_style( 'ferrazzini-advisory-cms-tokens' );
	wp_add_inline_style(
		'ferrazzini-advisory-cms-tokens',
		sprintf(
			':root{--ferrazzini-petrol:%1$s;--ferrazzini-petrol-dark:%2$s;--ferrazzini-ivory:%3$s;--ferrazzini-ink:%4$s;--ferrazzini-font-heading:%5$s;--ferrazzini-font-body:%6$s;}',
			$tokens['primary'],
			$tokens['primary_dark'],
			$tokens['background'],
			$tokens['ink'],
			wp_json_encode( $tokens['heading_font'] ),
			wp_json_encode( $tokens['body_font'] )
		)
	);

	wp_enqueue_script(
		'ferrazzini-advisory-navigation',
		get_stylesheet_directory_uri() . '/assets/js/navigation.js',
		array(),
		file_exists( $script_path ) ? (string) filemtime( $script_path ) : null,
		true
	);

	wp_localize_script(
		'ferrazzini-advisory-navigation',
		'ferrazziniNavigation',
		array(
			'openMenu'  => ferrazzini_advisory_frontend_text( __( 'Apri il menu', 'ferrazzini-advisory' ), 'theme:ferrazzini:header:menu_open' ),
			'closeMenu' => ferrazzini_advisory_frontend_text( __( 'Chiudi il menu', 'ferrazzini-advisory' ), 'theme:ferrazzini:header:menu_close' ),
		)
	);

	wp_enqueue_script(
		'ferrazzini-advisory-gsap',
		get_stylesheet_directory_uri() . '/assets/vendor/gsap/gsap.min.js',
		array(),
		'3.13.0',
		true
	);
	wp_enqueue_script(
		'ferrazzini-advisory-scroll-trigger',
		get_stylesheet_directory_uri() . '/assets/vendor/gsap/ScrollTrigger.min.js',
		array( 'ferrazzini-advisory-gsap' ),
		'3.13.0',
		true
	);
	wp_enqueue_script(
		'ferrazzini-advisory-motion',
		get_stylesheet_directory_uri() . '/assets/js/motion.js',
		array( 'ferrazzini-advisory-gsap', 'ferrazzini-advisory-scroll-trigger' ),
		file_exists( $motion_script ) ? (string) filemtime( $motion_script ) : null,
		true
	);
}
add_action( 'wp_enqueue_scripts', 'ferrazzini_advisory_enqueue_home_assets', 30 );

/**
 * Keep the CMS typography selector aligned with the child theme without editing the parent.
 *
 * @param string $hook_suffix Current admin screen hook.
 * @return void
 */
function ferrazzini_advisory_enqueue_cms_assets( $hook_suffix ) {
	if ( 'toplevel_page_ticinoweb-cms' !== $hook_suffix ) {
		return;
	}

	$script_path = get_stylesheet_directory() . '/assets/js/admin-cms.js';

	wp_enqueue_script(
		'ferrazzini-advisory-admin-cms',
		get_stylesheet_directory_uri() . '/assets/js/admin-cms.js',
		array(),
		file_exists( $script_path ) ? (string) filemtime( $script_path ) : null,
		true
	);

	wp_localize_script(
		'ferrazzini-advisory-admin-cms',
		'ferrazziniCmsTypography',
		array(
			'heading' => ferrazzini_advisory_get_font( 'ticinoweb_font_headings', 'Manrope' ),
		)
	);
}
add_action( 'admin_enqueue_scripts', 'ferrazzini_advisory_enqueue_cms_assets', 30 );

/**
 * Load the Media Library selector only on the Ferrazzini About editor.
 *
 * @param string $hook_suffix Current admin screen hook.
 * @return void
 */
function ferrazzini_advisory_enqueue_about_cms_assets( $hook_suffix ) {
	if ( ! str_contains( $hook_suffix, 'ferrazzini-about-page' ) ) {
		return;
	}

	$script_path = get_stylesheet_directory() . '/assets/js/admin-about.js';

	wp_enqueue_media();
	wp_enqueue_script(
		'ferrazzini-advisory-admin-about',
		get_stylesheet_directory_uri() . '/assets/js/admin-about.js',
		array( 'media-editor' ),
		file_exists( $script_path ) ? (string) filemtime( $script_path ) : null,
		true
	);
	wp_localize_script(
		'ferrazzini-advisory-admin-about',
		'ferrazziniAboutMedia',
		array(
			'title'  => __( 'Scegli una fotografia', 'ferrazzini-advisory' ),
			'button' => __( 'Usa questa fotografia', 'ferrazzini-advisory' ),
		)
	);
}
add_action( 'admin_enqueue_scripts', 'ferrazzini_advisory_enqueue_about_cms_assets', 31 );

/**
 * Load the Media Library selector only on the Ferrazzini homepage editor.
 *
 * @param string $hook_suffix Current admin screen hook.
 * @return void
 */
function ferrazzini_advisory_enqueue_homepage_cms_assets( $hook_suffix ) {
	if ( ! str_contains( $hook_suffix, 'ferrazzini-homepage' ) ) {
		return;
	}

	$script_path = get_stylesheet_directory() . '/assets/js/admin-homepage.js';
	$style_path  = get_stylesheet_directory() . '/assets/css/admin-homepage.css';

	wp_enqueue_media();
	wp_enqueue_style(
		'ferrazzini-advisory-admin-homepage',
		get_stylesheet_directory_uri() . '/assets/css/admin-homepage.css',
		array(),
		file_exists( $style_path ) ? (string) filemtime( $style_path ) : null
	);
	wp_enqueue_script(
		'ferrazzini-advisory-admin-homepage',
		get_stylesheet_directory_uri() . '/assets/js/admin-homepage.js',
		array( 'media-editor' ),
		file_exists( $script_path ) ? (string) filemtime( $script_path ) : null,
		true
	);
	wp_localize_script(
		'ferrazzini-advisory-admin-homepage',
		'ferrazziniHomepageMedia',
		array(
			'title'  => __( 'Scegli l’immagine della hero', 'ferrazzini-advisory' ),
			'button' => __( 'Usa questa immagine', 'ferrazzini-advisory' ),
		)
	);
}
add_action( 'admin_enqueue_scripts', 'ferrazzini_advisory_enqueue_homepage_cms_assets', 32 );

/**
 * Render the project navigation while no WordPress menu is assigned.
 *
 * @return void
 */
function ferrazzini_advisory_primary_menu_fallback() {
	$service_pages = ferrazzini_advisory_service_detail_pages();
	$links         = array(
		array(
			'label' => ferrazzini_advisory_frontend_text( __( 'Home', 'ferrazzini-advisory' ), 'theme:ferrazzini:navigation:home' ),
			'url'   => home_url( '/' ),
		),
		array(
			'label' => ferrazzini_advisory_frontend_text( __( 'Servizi', 'ferrazzini-advisory' ), 'theme:ferrazzini:navigation:services' ),
			'url'   => home_url( '/servizi/' ),
		),
		array(
			'label' => ferrazzini_advisory_frontend_text( __( 'Chi siamo', 'ferrazzini-advisory' ), 'theme:ferrazzini:navigation:about' ),
			'url'   => home_url( '/chi-siamo/' ),
		),
		array(
			'label' => ferrazzini_advisory_frontend_text( __( 'Contatti', 'ferrazzini-advisory' ), 'theme:ferrazzini:navigation:contact' ),
			'url'   => home_url( '/contatti/' ),
		),
	);

	echo '<ul class="ferrazzini-navigation__list">';
	foreach ( $links as $link ) {
		if ( empty( $link['url'] ) ) {
			printf(
				'<li><span class="ferrazzini-navigation__placeholder">%s</span></li>',
				esc_html( $link['label'] )
			);
			continue;
		}

		$is_services_link = untrailingslashit( $link['url'] ) === untrailingslashit( home_url( '/servizi/' ) );

		if ( $is_services_link ) {
			echo '<li class="menu-item menu-item-has-children ferrazzini-navigation__services">';
			printf(
				'<button class="ferrazzini-navigation__submenu-toggle" type="button" aria-expanded="false" aria-haspopup="true">%1$s</button>',
				esc_html( $link['label'] )
			);
			echo '<ul class="sub-menu">';
			foreach ( $service_pages as $service_page ) {
				printf(
					'<li class="menu-item"><a href="%1$s">%2$s</a></li>',
					esc_url( home_url( '/servizi/' . $service_page['slug'] . '/' ) ),
					esc_html( $service_page['title'] )
				);
			}
			echo '</ul></li>';
			continue;
		}

		printf( '<li><a href="%1$s">%2$s</a></li>', esc_url( $link['url'] ), esc_html( $link['label'] ) );
	}
	echo '</ul>';
}

/**
 * Add a stable hook class to the Services menu item.
 *
 * @param string[] $classes Menu item classes.
 * @param WP_Post  $menu_item Current menu item.
 * @param stdClass $args Menu arguments.
 * @return string[]
 */
function ferrazzini_advisory_primary_menu_classes( $classes, $menu_item, $args ) {
	if ( empty( $args->theme_location ) || 'primary' !== $args->theme_location ) {
		return $classes;
	}

	$services_url = untrailingslashit( home_url( '/servizi/' ) );
	$item_url     = isset( $menu_item->url ) ? untrailingslashit( $menu_item->url ) : '';

	if ( $services_url === $item_url ) {
		$classes[] = 'ferrazzini-navigation__services';
	}

	return array_values( array_unique( $classes ) );
}
add_filter( 'nav_menu_css_class', 'ferrazzini_advisory_primary_menu_classes', 10, 3 );

/**
 * Render the top-level Services item as a disclosure control.
 *
 * The overview page remains available at its URL, while the primary navigation
 * uses Services only to reveal the three direct destinations.
 *
 * @param string   $item_output Menu item markup.
 * @param WP_Post  $menu_item   Current menu item.
 * @param int      $depth       Menu depth.
 * @param stdClass $args        Menu arguments.
 * @return string
 */
function ferrazzini_advisory_services_menu_toggle( $item_output, $menu_item, $depth, $args ) {
	if ( 0 !== $depth || empty( $args->theme_location ) || 'primary' !== $args->theme_location ) {
		return $item_output;
	}

	$services_url = untrailingslashit( home_url( '/servizi/' ) );
	$item_url     = isset( $menu_item->url ) ? untrailingslashit( $menu_item->url ) : '';

	if ( $services_url !== $item_url ) {
		return $item_output;
	}

	$label = ferrazzini_advisory_frontend_text(
		__( 'Servizi', 'ferrazzini-advisory' ),
		'theme:ferrazzini:navigation:services'
	);

	return sprintf(
		'<button class="ferrazzini-navigation__submenu-toggle" type="button" aria-expanded="false" aria-haspopup="true">%s</button>',
		esc_html( $label )
	);
}
add_filter( 'walker_nav_menu_start_el', 'ferrazzini_advisory_services_menu_toggle', 10, 4 );
