<?php
/**
 * Responsive media helpers for the Ferrazzini child theme.
 *
 * @package FerrazziniAdvisoryChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register the image crops used by the child templates.
 *
 * @return void
 */
function ferrazzini_advisory_register_image_sizes() {
	add_image_size( 'ferrazzini-home-hero', 1200, 900, true );
	add_image_size( 'ferrazzini-about-hero', 960, 960, true );
	add_image_size( 'ferrazzini-profile', 720, 720, true );
	add_image_size( 'ferrazzini-service', 960, 960, true );
}
add_action( 'after_setup_theme', 'ferrazzini_advisory_register_image_sizes', 5 );

/**
 * Generate modern derivatives for PNG uploads when the active editor supports WebP.
 *
 * Originals remain untouched and WordPress keeps managing every generated variant.
 *
 * @param array<string, string> $formats Output formats keyed by source MIME type.
 * @return array<string, string>
 */
function ferrazzini_advisory_image_editor_output_format( $formats ) {
	$formats['image/png'] = 'image/webp';

	return $formats;
}
add_filter( 'image_editor_output_format', 'ferrazzini_advisory_image_editor_output_format' );

/**
 * Resolve an attachment selected in the CMS, including legacy pre-conversion URLs.
 *
 * WordPress keeps the original upload URL as the attachment GUID when generated
 * derivatives are converted to WebP, so it is a safe compatibility lookup here.
 *
 * @param string $image_url Media URL stored by the CMS.
 * @return int
 */
function ferrazzini_advisory_attachment_id_from_url( $image_url ) {
	$attachment_id = attachment_url_to_postid( $image_url );

	if ( $attachment_id || ! $image_url ) {
		return $attachment_id;
	}

	global $wpdb;
	$cache_key = 'attachment_url_' . md5( $image_url );
	$found     = false;
	$cached    = wp_cache_get( $cache_key, 'ferrazzini_advisory', false, $found );

	if ( $found ) {
		return absint( $cached );
	}

	// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery -- WordPress has no GUID lookup API for a converted legacy media URL.
	// phpcs:disable WordPress.DB.DirectDatabaseQuery.NoCaching -- The result is cached immediately below.
	$attachment_id = absint(
		$wpdb->get_var(
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts} WHERE guid = %s AND post_type = 'attachment' LIMIT 1",
				$image_url
			)
		)
	);
	// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery
	// phpcs:enable WordPress.DB.DirectDatabaseQuery.NoCaching

	wp_cache_set( $cache_key, $attachment_id, 'ferrazzini_advisory' );

	return $attachment_id;
}

/**
 * Return a dedicated intermediate size, falling back to WordPress large images.
 *
 * The fallback keeps existing uploads responsive until their metadata is regenerated.
 *
 * @param int    $attachment_id Attachment ID.
 * @param string $preferred     Preferred registered size.
 * @return string
 */
function ferrazzini_advisory_responsive_image_size( $attachment_id, $preferred ) {
	$intermediate = image_get_intermediate_size( $attachment_id, $preferred );

	return $intermediate ? $preferred : 'large';
}

/**
 * Resolve stable intrinsic dimensions for a configured logo.
 *
 * Raster dimensions come from attachment metadata. SVG dimensions are derived from
 * the trusted local attachment viewBox so the header and footer do not shift.
 *
 * @param string $logo_url Configured logo URL.
 * @return array{width:int,height:int}|array{}
 */
function ferrazzini_advisory_logo_dimensions( $logo_url ) {
	$attachment_id = ferrazzini_advisory_attachment_id_from_url( $logo_url );
	$metadata      = $attachment_id ? wp_get_attachment_metadata( $attachment_id ) : array();

	if ( ! empty( $metadata['width'] ) && ! empty( $metadata['height'] ) ) {
		return array(
			'width'  => absint( $metadata['width'] ),
			'height' => absint( $metadata['height'] ),
		);
	}

	if ( ! $attachment_id || 'image/svg+xml' !== get_post_mime_type( $attachment_id ) ) {
		return array();
	}

	$cache_key = 'logo_dimensions_' . $attachment_id;
	$cached    = wp_cache_get( $cache_key, 'ferrazzini_advisory' );

	if ( is_array( $cached ) ) {
		return $cached;
	}

	$file       = get_attached_file( $attachment_id );
	$uploads    = wp_get_upload_dir();
	$real_file  = $file ? realpath( $file ) : false;
	$real_based = ! empty( $uploads['basedir'] ) ? realpath( $uploads['basedir'] ) : false;
	$dimensions = array();

	if ( $real_file && $real_based && str_starts_with( $real_file, trailingslashit( $real_based ) ) ) {
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Read-only access to a validated local media attachment.
		$svg = file_get_contents( $real_file );

		if ( is_string( $svg ) && preg_match( '/viewBox=["\']\s*[-\d.]+\s+[-\d.]+\s+([\d.]+)\s+([\d.]+)\s*["\']/i', $svg, $matches ) ) {
			$width  = (int) round( (float) $matches[1] );
			$height = (int) round( (float) $matches[2] );

			if ( $width > 0 && $height > 0 ) {
				$dimensions = array(
					'width'  => $width,
					'height' => $height,
				);
			}
		}
	}

	wp_cache_set( $cache_key, $dimensions, 'ferrazzini_advisory' );

	return $dimensions;
}
