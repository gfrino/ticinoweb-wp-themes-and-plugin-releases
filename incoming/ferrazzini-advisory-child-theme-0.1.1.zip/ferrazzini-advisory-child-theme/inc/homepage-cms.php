<?php
/**
 * Editable homepage content for the Ferrazzini child theme.
 *
 * @package FerrazziniAdvisoryChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return the approved working copy used by the homepage.
 *
 * @return array<string, string>
 */
function ferrazzini_advisory_home_defaults() {
	return array(
		'hero_title_primary'   => __( 'Chiarezza nelle scelte.', 'ferrazzini-advisory' ),
		'hero_title_secondary' => __( 'Valore nel tempo.', 'ferrazzini-advisory' ),
		'hero_intro'           => __( 'Consulenza fiduciaria, fiscale e aziendale per accompagnare imprese, imprenditori e privati con competenza e attenzione.', 'ferrazzini-advisory' ),
		'hero_image'           => '',
		'hero_image_alt'       => __( 'Tre professionisti riuniti attorno a un tavolo durante una riunione di consulenza.', 'ferrazzini-advisory' ),
		'services_title'       => __( 'Competenze per decisioni consapevoli.', 'ferrazzini-advisory' ),
		'services_intro'       => __( 'Tre ambiti connessi, affrontati con precisione e con una lettura d’insieme del contesto.', 'ferrazzini-advisory' ),
		'approach_title'       => __( 'Prima comprendere. Poi costruire la risposta.', 'ferrazzini-advisory' ),
		'approach_1_title'     => __( 'Ascolto', 'ferrazzini-advisory' ),
		'approach_1_text'      => __( 'Partire dal contesto, dalle priorità e dalle domande che richiedono una risposta.', 'ferrazzini-advisory' ),
		'approach_2_title'     => __( 'Chiarezza', 'ferrazzini-advisory' ),
		'approach_2_text'      => __( 'Organizzare informazioni e alternative per rendere comprensibili anche i passaggi più complessi.', 'ferrazzini-advisory' ),
		'approach_3_title'     => __( 'Continuità', 'ferrazzini-advisory' ),
		'approach_3_text'      => __( 'Mantenere una visione nel tempo, perché ogni decisione si inserisce in un percorso più ampio.', 'ferrazzini-advisory' ),
		'contact_title'        => __( 'Dove trovarci.', 'ferrazzini-advisory' ),
		'contact_intro'        => __( 'Riceviamo su appuntamento e siamo disponibili per un primo confronto diretto.', 'ferrazzini-advisory' ),
		'contact_cta_title'    => __( 'Parliamone.', 'ferrazzini-advisory' ),
		'contact_cta_intro'    => __( 'Per informazioni o per fissare un incontro, contattateci direttamente.', 'ferrazzini-advisory' ),
		'contact_pending'      => __( 'I recapiti saranno disponibili a breve.', 'ferrazzini-advisory' ),
	);
}

/**
 * Return saved homepage copy merged with safe defaults.
 *
 * @return array<string, string>
 */
function ferrazzini_advisory_home_content() {
	$saved   = get_option( 'ferrazzini_homepage_content', array() );
	$content = array_merge(
		ferrazzini_advisory_home_defaults(),
		is_array( $saved ) ? $saved : array()
	);

	foreach ( $content as $key => $value ) {
		if ( str_ends_with( $key, '_image' ) ) {
			continue;
		}

		$content[ $key ] = ferrazzini_advisory_frontend_text(
			(string) $value,
			'theme:ferrazzini:home:' . $key
		);
	}

	return $content;
}

/**
 * Render the homepage hero image selected in the CMS.
 *
 * @return string
 */
function ferrazzini_advisory_home_hero_image_html() {
	$content   = ferrazzini_advisory_home_content();
	$image_url = esc_url_raw( $content['hero_image'] );
	$image_id  = $image_url ? ferrazzini_advisory_attachment_id_from_url( $image_url ) : 0;
	$alt       = (string) $content['hero_image_alt'];

	if ( $image_id ) {
		return wp_get_attachment_image(
			$image_id,
			ferrazzini_advisory_responsive_image_size( $image_id, 'ferrazzini-home-hero' ),
			false,
			array(
				'alt'           => $alt,
				'loading'       => 'eager',
				'decoding'      => 'async',
				'fetchpriority' => 'high',
				'sizes'         => '(max-width: 900px) 100vw, 50vw',
			)
		);
	}

	if ( ! $image_url ) {
		return sprintf(
			'<img src="%1$s" width="1456" height="1092" alt="%2$s" loading="eager" decoding="async" fetchpriority="high">',
			esc_url( get_theme_file_uri( '/assets/images/hero-placeholder.webp' ) ),
			esc_attr( $alt )
		);
	}

	return sprintf(
		'<img src="%1$s" alt="%2$s" loading="eager" decoding="async" fetchpriority="high">',
		esc_url( $image_url ),
		esc_attr( $alt )
	);
}

/**
 * Seed the editable CMS fields on the Ferrazzini site only.
 *
 * @return void
 */
function ferrazzini_advisory_seed_home_content() {
	$defaults = ferrazzini_advisory_home_defaults();
	$saved    = get_option( 'ferrazzini_homepage_content', false );

	if ( false === $saved ) {
		add_option( 'ferrazzini_homepage_content', $defaults, '', false );
		add_option( 'ferrazzini_homepage_schema_version', 2, '', false );
		return;
	}

	if ( is_array( $saved ) && 'Lo studio ha sede a Locarno, in Via Luini 13.' === ( $saved['contact_intro'] ?? '' ) ) {
		$saved['contact_intro'] = $defaults['contact_intro'];
		update_option( 'ferrazzini_homepage_content', $saved, false );
	}

	update_option( 'ferrazzini_homepage_schema_version', 2, false );
}
add_action( 'after_setup_theme', 'ferrazzini_advisory_seed_home_content', 20 );

/**
 * Sanitize editable homepage fields.
 *
 * @param mixed $input Submitted option value.
 * @return array<string, string>
 */
function ferrazzini_advisory_sanitize_home_content( $input ) {
	$defaults = ferrazzini_advisory_home_defaults();
	$input    = is_array( $input ) ? $input : array();
	$output   = array();

	foreach ( $defaults as $key => $default ) {
		$value = isset( $input[ $key ] ) && is_scalar( $input[ $key ] ) ? (string) $input[ $key ] : $default;

		if ( str_ends_with( $key, '_image' ) ) {
			$output[ $key ] = esc_url_raw( $value );
		} elseif ( str_ends_with( $key, '_text' ) || str_ends_with( $key, '_intro' ) || 'about_lead' === $key ) {
			$output[ $key ] = sanitize_textarea_field( $value );
		} else {
			$output[ $key ] = sanitize_text_field( $value );
		}
	}

	return $output;
}

/**
 * Register the child-theme CMS option.
 *
 * @return void
 */
function ferrazzini_advisory_register_home_settings() {
	register_setting(
		'ferrazzini_homepage_settings',
		'ferrazzini_homepage_content',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'ferrazzini_advisory_sanitize_home_content',
			'default'           => ferrazzini_advisory_home_defaults(),
		)
	);
}
add_action( 'admin_init', 'ferrazzini_advisory_register_home_settings' );

/**
 * Add the homepage editor under ticinoWEB CMS.
 *
 * @return void
 */
function ferrazzini_advisory_add_homepage_cms_page() {
	add_submenu_page(
		'ticinoweb-cms',
		__( 'Homepage Ferrazzini', 'ferrazzini-advisory' ),
		__( 'Homepage Ferrazzini', 'ferrazzini-advisory' ),
		'edit_theme_options',
		'ferrazzini-homepage',
		'ferrazzini_advisory_render_homepage_cms_page'
	);
}
add_action( 'admin_menu', 'ferrazzini_advisory_add_homepage_cms_page', 20 );

/**
 * Return CMS field definitions grouped by homepage section.
 *
 * @return array<string, array<string, array<string, string>>>
 */
function ferrazzini_advisory_home_field_groups() {
	return array(
		__( 'Hero', 'ferrazzini-advisory' )     => array(
			'hero_title_primary'   => array(
				'label' => __( 'Titolo blu', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
			'hero_title_secondary' => array(
				'label' => __( 'Titolo scuro', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
			'hero_intro'           => array(
				'label' => __( 'Introduzione', 'ferrazzini-advisory' ),
				'type'  => 'textarea',
			),
			'hero_image'           => array(
				'label'       => __( 'Immagine hero', 'ferrazzini-advisory' ),
				'type'        => 'media',
				'description' => __( 'Formato consigliato: orizzontale 4:3, almeno 1400 × 1050 px.', 'ferrazzini-advisory' ),
			),
			'hero_image_alt'       => array(
				'label'       => __( 'Testo alternativo immagine hero', 'ferrazzini-advisory' ),
				'type'        => 'text',
				'description' => __( 'Descrivi brevemente ciò che appare nella fotografia.', 'ferrazzini-advisory' ),
			),
		),
		__( 'Servizi', 'ferrazzini-advisory' )  => array(
			'services_title' => array(
				'label' => __( 'Titolo sezione', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
			'services_intro' => array(
				'label' => __( 'Introduzione sezione', 'ferrazzini-advisory' ),
				'type'  => 'textarea',
			),
		),
		__( 'Metodo', 'ferrazzini-advisory' )   => array(
			'approach_title'   => array(
				'label' => __( 'Titolo sezione', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
			'approach_1_title' => array(
				'label' => __( 'Passaggio 1 · titolo', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
			'approach_1_text'  => array(
				'label' => __( 'Passaggio 1 · descrizione', 'ferrazzini-advisory' ),
				'type'  => 'textarea',
			),
			'approach_2_title' => array(
				'label' => __( 'Passaggio 2 · titolo', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
			'approach_2_text'  => array(
				'label' => __( 'Passaggio 2 · descrizione', 'ferrazzini-advisory' ),
				'type'  => 'textarea',
			),
			'approach_3_title' => array(
				'label' => __( 'Passaggio 3 · titolo', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
			'approach_3_text'  => array(
				'label' => __( 'Passaggio 3 · descrizione', 'ferrazzini-advisory' ),
				'type'  => 'textarea',
			),
		),
		__( 'Contatti', 'ferrazzini-advisory' ) => array(
			'contact_title'     => array(
				'label' => __( 'Titolo', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
			'contact_intro'     => array(
				'label' => __( 'Introduzione', 'ferrazzini-advisory' ),
				'type'  => 'textarea',
			),
			'contact_cta_title' => array(
				'label' => __( 'Titolo invito al contatto', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
			'contact_cta_intro' => array(
				'label' => __( 'Testo invito al contatto', 'ferrazzini-advisory' ),
				'type'  => 'textarea',
			),
			'contact_pending'   => array(
				'label' => __( 'Messaggio senza recapiti', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
		),
	);
}

/**
 * Render the child-theme homepage editor.
 *
 * @return void
 */
function ferrazzini_advisory_render_homepage_cms_page() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		wp_die( esc_html__( 'Permessi insufficienti.', 'ferrazzini-advisory' ) );
	}

	$content = ferrazzini_advisory_home_content();
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Homepage Ferrazzini', 'ferrazzini-advisory' ); ?></h1>
		<p><?php esc_html_e( 'Questi contenuti alimentano direttamente la homepage. Durante la fase di progetto possono essere modificati e mantenuti sincronizzati con il frontend.', 'ferrazzini-advisory' ); ?></p>
		<p>
			<?php
			printf(
				/* translators: %s: URL of the main ticinoWEB CMS screen. */
				wp_kses_post( __( 'Palette, font, servizi e contenuto “Chi siamo” si modificano nel <a href="%s">ticinoWEB CMS principale</a>.', 'ferrazzini-advisory' ) ),
				esc_url( admin_url( 'admin.php?page=ticinoweb-cms' ) )
			);
			?>
		</p>
		<form method="post" action="options.php">
			<?php settings_fields( 'ferrazzini_homepage_settings' ); ?>
			<?php foreach ( ferrazzini_advisory_home_field_groups() as $group_label => $fields ) : ?>
				<h2><?php echo esc_html( $group_label ); ?></h2>
				<table class="form-table" role="presentation">
					<?php foreach ( $fields as $key => $field ) : ?>
						<tr>
							<th scope="row"><label for="ferrazzini-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $field['label'] ); ?></label></th>
							<td>
								<?php if ( 'textarea' === $field['type'] ) : ?>
									<textarea class="large-text" rows="3" id="ferrazzini-<?php echo esc_attr( $key ); ?>" name="ferrazzini_homepage_content[<?php echo esc_attr( $key ); ?>]"><?php echo esc_textarea( $content[ $key ] ); ?></textarea>
								<?php elseif ( 'media' === $field['type'] ) : ?>
									<div class="ferrazzini-home-media-field" data-alt-target="ferrazzini-hero_image_alt">
										<input class="large-text ferrazzini-home-media-url" type="url" id="ferrazzini-<?php echo esc_attr( $key ); ?>" name="ferrazzini_homepage_content[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $content[ $key ] ); ?>">
										<div class="ferrazzini-home-media-actions">
											<button class="button ferrazzini-home-media-select" type="button"><?php esc_html_e( 'Scegli dalla Libreria media', 'ferrazzini-advisory' ); ?></button>
											<button class="button-link-delete ferrazzini-home-media-remove" type="button"<?php echo $content[ $key ] ? '' : ' hidden'; ?>><?php esc_html_e( 'Rimuovi immagine', 'ferrazzini-advisory' ); ?></button>
										</div>
										<div class="ferrazzini-home-media-preview"<?php echo $content[ $key ] ? '' : ' hidden'; ?>>
											<?php if ( $content[ $key ] ) : ?>
												<img src="<?php echo esc_url( $content[ $key ] ); ?>" alt="">
											<?php else : ?>
												<img alt="">
											<?php endif; ?>
										</div>
									</div>
								<?php else : ?>
									<input class="regular-text" type="text" id="ferrazzini-<?php echo esc_attr( $key ); ?>" name="ferrazzini_homepage_content[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $content[ $key ] ); ?>">
								<?php endif; ?>
								<?php if ( ! empty( $field['description'] ) ) : ?>
									<p class="description"><?php echo esc_html( $field['description'] ); ?></p>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</table>
			<?php endforeach; ?>
			<?php submit_button( __( 'Salva homepage', 'ferrazzini-advisory' ) ); ?>
		</form>
	</div>
	<?php
}
