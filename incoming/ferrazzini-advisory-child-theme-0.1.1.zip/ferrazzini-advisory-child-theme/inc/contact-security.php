<?php
/**
 * Abuse-protection helpers for the Ferrazzini contact form.
 *
 * @package FerrazziniAdvisoryChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Build a non-reversible transient key for a contact client.
 *
 * @param string $scope          Supported rate-limit scope.
 * @param string $remote_address Client network address.
 * @return string
 */
function ferrazzini_advisory_contact_rate_key( $scope, $remote_address ) {
	$scope          = in_array( $scope, array( 'attempt', 'success' ), true ) ? $scope : 'attempt';
	$remote_address = '' !== trim( (string) $remote_address ) ? (string) $remote_address : 'unknown';

	return 'ferrazzini_contact_' . $scope . '_' . hash( 'sha256', $remote_address );
}

/**
 * Register an attempted contact submission and report whether it is allowed.
 *
 * @param string $remote_address Client network address.
 * @return bool
 */
function ferrazzini_advisory_register_contact_attempt( $remote_address ) {
	$key   = ferrazzini_advisory_contact_rate_key( 'attempt', $remote_address );
	$count = max( 0, (int) get_transient( $key ) );

	if ( $count >= 6 ) {
		return false;
	}

	set_transient( $key, $count + 1, 5 * MINUTE_IN_SECONDS );

	return true;
}

/**
 * Bound the sanitized values stored briefly after validation errors.
 *
 * @param array<string, string> $values Sanitized field values.
 * @param array<string, int>    $limits Maximum character counts.
 * @return array<string, string>
 */
function ferrazzini_advisory_limit_contact_flash_values( $values, $limits ) {
	$limited = array();

	foreach ( array( 'name', 'email', 'phone', 'message' ) as $field ) {
		$value             = isset( $values[ $field ] ) ? (string) $values[ $field ] : '';
		$limit             = isset( $limits[ $field ] ) ? max( 0, (int) $limits[ $field ] ) : 0;
		$limited[ $field ] = mb_substr( $value, 0, $limit );
	}

	return $limited;
}
