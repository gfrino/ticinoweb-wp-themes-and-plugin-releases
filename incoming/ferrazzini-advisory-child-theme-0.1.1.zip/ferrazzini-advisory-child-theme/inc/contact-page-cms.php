<?php
/**
 * Contact page content, provisioning and form handling.
 *
 * @package FerrazziniAdvisoryChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return editable defaults for the contact page.
 *
 * @return array<string, string>
 */
function ferrazzini_advisory_contact_page_defaults() {
	return array(
		'hero_title'     => __( 'Parliamone.', 'ferrazzini-advisory' ),
		'hero_intro'     => __( 'Ogni collaborazione inizia da una conversazione chiara. Raccontateci le vostre esigenze: vi risponderemo con attenzione e concretezza.', 'ferrazzini-advisory' ),
		'form_title'     => __( 'Scriveteci.', 'ferrazzini-advisory' ),
		'form_intro'     => __( 'Compilate il modulo: vi ricontatteremo per comprendere il vostro contesto e concordare il prossimo passo.', 'ferrazzini-advisory' ),
		'location_title' => __( 'Venite a trovarci.', 'ferrazzini-advisory' ),
	);
}

/**
 * Return saved contact-page content with translation contexts.
 *
 * @return array<string, string>
 */
function ferrazzini_advisory_contact_page_content() {
	$saved   = get_option( 'ferrazzini_contact_page_content', array() );
	$content = array_merge(
		ferrazzini_advisory_contact_page_defaults(),
		is_array( $saved ) ? $saved : array()
	);

	foreach ( $content as $key => $value ) {
		$content[ $key ] = ferrazzini_advisory_frontend_text(
			(string) $value,
			'theme:ferrazzini:contact_page:' . $key
		);
	}

	return $content;
}

/**
 * Seed contact-page copy on this site only.
 *
 * @return void
 */
function ferrazzini_advisory_seed_contact_page_content() {
	if ( false === get_option( 'ferrazzini_contact_page_content', false ) ) {
		add_option( 'ferrazzini_contact_page_content', ferrazzini_advisory_contact_page_defaults(), '', false );
	}
}
add_action( 'after_setup_theme', 'ferrazzini_advisory_seed_contact_page_content', 20 );

/**
 * Sanitize contact-page fields.
 *
 * @param mixed $input Submitted option value.
 * @return array<string, string>
 */
function ferrazzini_advisory_sanitize_contact_page_content( $input ) {
	$defaults = ferrazzini_advisory_contact_page_defaults();
	$input    = is_array( $input ) ? $input : array();
	$output   = array();

	foreach ( $defaults as $key => $default ) {
		$value          = isset( $input[ $key ] ) && is_scalar( $input[ $key ] ) ? (string) $input[ $key ] : $default;
		$output[ $key ] = str_ends_with( $key, '_intro' ) ? sanitize_textarea_field( $value ) : sanitize_text_field( $value );
	}

	return $output;
}

/**
 * Register the contact-page option.
 *
 * @return void
 */
function ferrazzini_advisory_register_contact_page_settings() {
	register_setting(
		'ferrazzini_contact_page_settings',
		'ferrazzini_contact_page_content',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'ferrazzini_advisory_sanitize_contact_page_content',
			'default'           => ferrazzini_advisory_contact_page_defaults(),
		)
	);
}
add_action( 'admin_init', 'ferrazzini_advisory_register_contact_page_settings' );

/**
 * Add the contact editor under ticinoWEB CMS.
 *
 * @return void
 */
function ferrazzini_advisory_add_contact_page_cms_page() {
	add_submenu_page(
		'ticinoweb-cms',
		__( 'Pagina Contatti', 'ferrazzini-advisory' ),
		__( 'Pagina Contatti', 'ferrazzini-advisory' ),
		'edit_theme_options',
		'ferrazzini-contact-page',
		'ferrazzini_advisory_render_contact_page_cms'
	);
}
add_action( 'admin_menu', 'ferrazzini_advisory_add_contact_page_cms_page', 22 );

/**
 * Render the contact-page editor.
 *
 * @return void
 */
function ferrazzini_advisory_render_contact_page_cms() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		wp_die( esc_html__( 'Permessi insufficienti.', 'ferrazzini-advisory' ) );
	}

	$content = ferrazzini_advisory_contact_page_content();
	$fields  = array(
		'hero_title'     => array(
			'label' => __( 'Titolo hero', 'ferrazzini-advisory' ),
			'type'  => 'text',
		),
		'hero_intro'     => array(
			'label' => __( 'Introduzione hero', 'ferrazzini-advisory' ),
			'type'  => 'textarea',
		),
		'form_title'     => array(
			'label' => __( 'Titolo modulo', 'ferrazzini-advisory' ),
			'type'  => 'text',
		),
		'form_intro'     => array(
			'label' => __( 'Introduzione modulo', 'ferrazzini-advisory' ),
			'type'  => 'textarea',
		),
		'location_title' => array(
			'label' => __( 'Titolo posizione', 'ferrazzini-advisory' ),
			'type'  => 'text',
		),
	);
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Pagina Contatti', 'ferrazzini-advisory' ); ?></h1>
		<p><?php esc_html_e( 'Questi testi alimentano la pagina Contatti. Telefono, email e indirizzo continuano a provenire dalla sezione Contatti del ticinoWEB CMS principale.', 'ferrazzini-advisory' ); ?></p>
		<form method="post" action="options.php">
			<?php settings_fields( 'ferrazzini_contact_page_settings' ); ?>
			<table class="form-table" role="presentation">
				<?php foreach ( $fields as $key => $field ) : ?>
					<tr>
						<th scope="row"><label for="ferrazzini-contact-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $field['label'] ); ?></label></th>
						<td>
							<?php if ( 'textarea' === $field['type'] ) : ?>
								<textarea class="large-text" rows="4" id="ferrazzini-contact-<?php echo esc_attr( $key ); ?>" name="ferrazzini_contact_page_content[<?php echo esc_attr( $key ); ?>]"><?php echo esc_textarea( $content[ $key ] ); ?></textarea>
							<?php else : ?>
								<input class="regular-text" type="text" id="ferrazzini-contact-<?php echo esc_attr( $key ); ?>" name="ferrazzini_contact_page_content[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $content[ $key ] ); ?>">
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</table>
			<?php submit_button( __( 'Salva pagina Contatti', 'ferrazzini-advisory' ) ); ?>
		</form>
	</div>
	<?php
}

/**
 * Create the public Contact page and connect it to the primary menu.
 *
 * @return int|WP_Error
 */
function ferrazzini_advisory_install_contact_page() {
	$page = get_page_by_path( 'contatti', OBJECT, 'page' );

	if ( ! $page instanceof WP_Post ) {
		$page_id = wp_insert_post(
			array(
				'post_title'   => __( 'Contatti', 'ferrazzini-advisory' ),
				'post_name'    => 'contatti',
				'post_status'  => 'publish',
				'post_type'    => 'page',
				'post_content' => '',
			),
			true
		);

		if ( is_wp_error( $page_id ) ) {
			return $page_id;
		}
	} else {
		$page_id = $page->ID;
	}

	update_post_meta( $page_id, '_wp_page_template', 'page-contatti.php' );
	update_post_meta(
		$page_id,
		'_tw_seo_description',
		sanitize_text_field( __( 'Contattate Ferrazzini Advisory & Tax SA a Locarno per servizi fiduciari, fiscali e di consulenza aziendale.', 'ferrazzini-advisory' ) )
	);

	$locations = get_nav_menu_locations();
	if ( empty( $locations['primary'] ) ) {
		return $page_id;
	}

	$menu_id          = (int) $locations['primary'];
	$menu_items       = wp_get_nav_menu_items( $menu_id );
	$contact_menu_id  = 0;
	$contact_position = 0;

	foreach ( is_array( $menu_items ) ? $menu_items : array() as $menu_item ) {
		if ( 'Contatti' === trim( wp_strip_all_tags( $menu_item->title ) ) ) {
			$contact_menu_id  = (int) $menu_item->ID;
			$contact_position = (int) $menu_item->menu_order;
			break;
		}
	}

	wp_update_nav_menu_item(
		$menu_id,
		$contact_menu_id,
		array(
			'menu-item-title'     => __( 'Contatti', 'ferrazzini-advisory' ),
			'menu-item-object'    => 'page',
			'menu-item-object-id' => $page_id,
			'menu-item-parent-id' => 0,
			'menu-item-position'  => $contact_position,
			'menu-item-status'    => 'publish',
			'menu-item-type'      => 'post_type',
		)
	);

	return $page_id;
}
add_action( 'after_switch_theme', 'ferrazzini_advisory_install_contact_page' );

/**
 * Validate and normalize a contact request.
 *
 * @param mixed $input Submitted form data.
 * @return array<string, string>|WP_Error
 */
function ferrazzini_advisory_validate_contact_submission( $input ) {
	$values   = ferrazzini_advisory_normalize_contact_submission( $input );
	$limits   = ferrazzini_advisory_contact_field_limits();
	$messages = ferrazzini_advisory_contact_error_messages();
	$errors   = new WP_Error();

	if ( '' === $values['name'] ) {
		$errors->add( 'contact_name_required', $messages['contact_name_required'] );
	} elseif ( mb_strlen( $values['name'] ) > $limits['name'] ) {
		$errors->add( 'contact_name_too_long', $messages['contact_name_too_long'] );
	}

	if ( mb_strlen( $values['email'] ) > $limits['email'] ) {
		$errors->add( 'contact_email_too_long', $messages['contact_email_too_long'] );
	} elseif ( ! is_email( $values['email'] ) ) {
		$errors->add( 'contact_email_invalid', $messages['contact_email_invalid'] );
	}

	if ( mb_strlen( $values['phone'] ) > $limits['phone'] ) {
		$errors->add( 'contact_phone_too_long', $messages['contact_phone_too_long'] );
	}

	if ( '' === $values['message'] ) {
		$errors->add( 'contact_message_required', $messages['contact_message_required'] );
	} elseif ( mb_strlen( $values['message'] ) > $limits['message'] ) {
		$errors->add( 'contact_message_too_long', $messages['contact_message_too_long'] );
	}

	if ( $errors->has_errors() ) {
		return $errors;
	}

	return $values;
}

/**
 * Return the accepted contact-field lengths.
 *
 * @return array<string, int>
 */
function ferrazzini_advisory_contact_field_limits() {
	return array(
		'name'    => 120,
		'email'   => 254,
		'phone'   => 40,
		'message' => 4000,
	);
}

/**
 * Sanitize contact values while preserving safe data after validation errors.
 *
 * @param mixed $input Submitted form data.
 * @return array<string, string>
 */
function ferrazzini_advisory_normalize_contact_submission( $input ) {
	$input = is_array( $input ) ? $input : array();

	return array(
		'name'    => isset( $input['name'] ) ? sanitize_text_field( (string) $input['name'] ) : '',
		'email'   => isset( $input['email'] ) ? sanitize_text_field( trim( (string) $input['email'] ) ) : '',
		'phone'   => isset( $input['phone'] ) ? sanitize_text_field( (string) $input['phone'] ) : '',
		'message' => isset( $input['message'] ) ? sanitize_textarea_field( (string) $input['message'] ) : '',
	);
}

/**
 * Return the public validation messages keyed by error code.
 *
 * @return array<string, string>
 */
function ferrazzini_advisory_contact_error_messages() {
	return array(
		'contact_name_required'    => __( 'Inserite nome e cognome.', 'ferrazzini-advisory' ),
		'contact_name_too_long'    => __( 'Il nome può contenere al massimo 120 caratteri.', 'ferrazzini-advisory' ),
		'contact_email_invalid'    => __( 'Inserite un indirizzo email valido.', 'ferrazzini-advisory' ),
		'contact_email_too_long'   => __( 'L’indirizzo email può contenere al massimo 254 caratteri.', 'ferrazzini-advisory' ),
		'contact_phone_too_long'   => __( 'Il numero di telefono può contenere al massimo 40 caratteri.', 'ferrazzini-advisory' ),
		'contact_message_required' => __( 'Inserite un messaggio.', 'ferrazzini-advisory' ),
		'contact_message_too_long' => __( 'Il messaggio può contenere al massimo 4.000 caratteri.', 'ferrazzini-advisory' ),
	);
}

/**
 * Map validation errors to their form fields.
 *
 * @return array<string, string>
 */
function ferrazzini_advisory_contact_error_fields() {
	return array(
		'contact_name_required'    => 'name',
		'contact_name_too_long'    => 'name',
		'contact_email_invalid'    => 'email',
		'contact_email_too_long'   => 'email',
		'contact_phone_too_long'   => 'phone',
		'contact_message_required' => 'message',
		'contact_message_too_long' => 'message',
	);
}

/**
 * Store invalid form data briefly and return a single-use lookup token.
 *
 * @param array<string, string> $values Sanitized form values.
 * @param array<int, string>    $errors Validation error codes.
 * @return string
 */
function ferrazzini_advisory_store_contact_flash( $values, $errors ) {
	$values = ferrazzini_advisory_limit_contact_flash_values(
		$values,
		ferrazzini_advisory_contact_field_limits()
	);

	try {
		$token = bin2hex( random_bytes( 16 ) );
	} catch ( Exception $exception ) {
		$token = md5( wp_generate_password( 64, true, true ) . microtime() );
	}

	set_transient(
		'ferrazzini_contact_flash_' . $token,
		array(
			'values' => $values,
			'errors' => array_values( array_map( 'sanitize_key', $errors ) ),
		),
		5 * MINUTE_IN_SECONDS
	);

	return $token;
}

/**
 * Read and immediately delete invalid form data.
 *
 * @param string $token Single-use lookup token.
 * @return array<string, mixed>
 */
function ferrazzini_advisory_consume_contact_flash( $token ) {
	if ( ! preg_match( '/^[a-f0-9]{32}$/', $token ) ) {
		return array();
	}

	$key   = 'ferrazzini_contact_flash_' . $token;
	$flash = get_transient( $key );
	delete_transient( $key );

	return is_array( $flash ) ? $flash : array();
}

/**
 * Redirect back to the contact form with a stable status code.
 *
 * @param string $status           Public status code.
 * @param string $submission_token Optional single-use form token.
 * @return void
 */
function ferrazzini_advisory_contact_redirect( $status, $submission_token = '' ) {
	$query_args = array( 'contact' => sanitize_key( $status ) );

	if ( $submission_token ) {
		$query_args['submission'] = sanitize_key( $submission_token );
	}

	wp_safe_redirect(
		add_query_arg( $query_args, home_url( '/contatti/' ) ) . '#modulo-contatti'
	);
	exit;
}

/**
 * Process contact requests from authenticated and anonymous visitors.
 *
 * @return void
 */
function ferrazzini_advisory_handle_contact_submission() {
	$request_method = isset( $_SERVER['REQUEST_METHOD'] ) ? sanitize_key( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) : '';
	if ( 'post' !== $request_method ) {
		ferrazzini_advisory_contact_redirect( 'invalid' );
	}

	$nonce = isset( $_POST['ferrazzini_contact_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['ferrazzini_contact_nonce'] ) ) : '';
	if ( ! wp_verify_nonce( $nonce, 'ferrazzini_contact_submission' ) ) {
		ferrazzini_advisory_contact_redirect( 'security' );
	}

	$honeypot = isset( $_POST['company_website'] ) ? sanitize_text_field( wp_unslash( $_POST['company_website'] ) ) : '';
	if ( '' !== $honeypot ) {
		ferrazzini_advisory_contact_redirect( 'success' );
	}

	$remote_address   = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$success_rate_key = ferrazzini_advisory_contact_rate_key( 'success', $remote_address );

	if ( get_transient( $success_rate_key ) || ! ferrazzini_advisory_register_contact_attempt( $remote_address ) ) {
		ferrazzini_advisory_contact_redirect( 'rate' );
	}

	$raw_submission = wp_unslash( $_POST );
	$submission     = ferrazzini_advisory_validate_contact_submission( $raw_submission );
	if ( is_wp_error( $submission ) ) {
		$submission_token = ferrazzini_advisory_store_contact_flash(
			ferrazzini_advisory_normalize_contact_submission( $raw_submission ),
			$submission->get_error_codes()
		);
		ferrazzini_advisory_contact_redirect( 'invalid', $submission_token );
	}

	$contact_info = function_exists( 'ticinoweb_get_contact_info' ) ? ticinoweb_get_contact_info() : array();
	$recipient    = ! empty( $contact_info['email'] ) ? sanitize_email( $contact_info['email'] ) : '';
	if ( ! is_email( $recipient ) ) {
		ferrazzini_advisory_contact_redirect( 'send' );
	}

	$subject = sprintf(
		/* translators: %s: sender name. */
		__( 'Richiesta dal sito — %s', 'ferrazzini-advisory' ),
		$submission['name']
	);
	$body    = implode(
		"\n\n",
		array(
			__( 'Nuova richiesta dalla pagina Contatti.', 'ferrazzini-advisory' ),
			__( 'Nome:', 'ferrazzini-advisory' ) . ' ' . $submission['name'],
			__( 'Email:', 'ferrazzini-advisory' ) . ' ' . $submission['email'],
			__( 'Telefono:', 'ferrazzini-advisory' ) . ' ' . ( '' !== $submission['phone'] ? $submission['phone'] : __( 'Non indicato', 'ferrazzini-advisory' ) ),
			__( 'Messaggio:', 'ferrazzini-advisory' ) . "\n" . $submission['message'],
		)
	);
	$headers = array(
		'Content-Type: text/plain; charset=UTF-8',
		sprintf( 'Reply-To: %s <%s>', $submission['name'], $submission['email'] ),
	);

	if ( ! wp_mail( $recipient, $subject, $body, $headers ) ) {
		ferrazzini_advisory_contact_redirect( 'send' );
	}

	set_transient( $success_rate_key, 1, MINUTE_IN_SECONDS );
	ferrazzini_advisory_contact_redirect( 'success' );
}
add_action( 'admin_post_nopriv_ferrazzini_contact', 'ferrazzini_advisory_handle_contact_submission' );
add_action( 'admin_post_ferrazzini_contact', 'ferrazzini_advisory_handle_contact_submission' );
