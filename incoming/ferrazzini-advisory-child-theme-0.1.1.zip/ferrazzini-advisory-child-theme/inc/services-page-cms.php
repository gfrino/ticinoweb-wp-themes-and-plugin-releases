<?php
/**
 * Editable content for the Ferrazzini services page.
 *
 * @package FerrazziniAdvisoryChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return the working copy used by the services page.
 *
 * Service names and summaries continue to come from the parent CMS. This
 * option only owns page-specific introductions, detail lists and image text.
 *
 * @return array<string, string>
 */
function ferrazzini_advisory_services_page_defaults() {
	return array(
		'hero_title'           => __( 'Competenze che lavorano insieme.', 'ferrazzini-advisory' ),
		'hero_intro'           => __( 'Tre aree coordinate per accompagnare imprese, imprenditori e privati nelle decisioni che contano.', 'ferrazzini-advisory' ),
		'accounting_details'   => __( "Tenuta della contabilità\nChiusure annuali e bilanci\nGestione salariale\nBudget e pianificazione finanziaria\nIVA e imposta alla fonte\nAssicurazioni sociali", 'ferrazzini-advisory' ),
		'tax_details'          => __( "Dichiarazioni fiscali\nFiscalità di persone e società\nIVA e imposta alla fonte\nTemi successori\nQuestioni internazionali\nRappresentanza fiscale", 'ferrazzini-advisory' ),
		'advisory_details'     => __( "Valutazioni aziendali\nRisanamenti\nFusioni e trasformazioni\nLiquidazioni\nInvestimenti\nRapporti con istituti di credito", 'ferrazzini-advisory' ),
		'accounting_image_alt' => __( 'Professionista che esamina documenti contabili e finanziari.', 'ferrazzini-advisory' ),
		'tax_image_alt'        => __( 'Due professionisti che analizzano insieme una documentazione fiscale.', 'ferrazzini-advisory' ),
		'advisory_image_alt'   => __( 'Tre professionisti riuniti durante un incontro di consulenza aziendale.', 'ferrazzini-advisory' ),
		'closing_title'        => __( 'Avete bisogno di un confronto?', 'ferrazzini-advisory' ),
		'closing_intro'        => __( 'Siamo a disposizione per comprendere le vostre esigenze e individuare insieme il punto di partenza.', 'ferrazzini-advisory' ),
		'contact_title'        => __( 'Parliamo del vostro contesto.', 'ferrazzini-advisory' ),
		'contact_intro'        => __( 'Un confronto diretto per comprendere le vostre esigenze e individuare insieme le soluzioni più adatte.', 'ferrazzini-advisory' ),
	);
}

/**
 * Return services-page content merged with safe defaults and translations.
 *
 * @return array<string, string>
 */
function ferrazzini_advisory_services_page_content() {
	$saved   = get_option( 'ferrazzini_services_page_content', array() );
	$content = array_merge(
		ferrazzini_advisory_services_page_defaults(),
		is_array( $saved ) ? $saved : array()
	);

	foreach ( $content as $key => $value ) {
		$content[ $key ] = ferrazzini_advisory_frontend_text(
			(string) $value,
			'theme:ferrazzini:services_page:' . $key
		);
	}

	return $content;
}

/**
 * Return the three services with their page-specific presentation data.
 *
 * Names and summaries remain owned by the main ticinoWEB services CMS. The
 * dedicated page option supplies only detail lists and image alternatives.
 *
 * @return array<int, array<string, mixed>>
 */
function ferrazzini_advisory_service_detail_pages() {
	$content  = ferrazzini_advisory_services_page_content();
	$services = function_exists( 'ticinoweb_get_services' )
		? ticinoweb_get_services()
		: get_option( 'ticinoweb_services', array() );
	$config   = array(
		'srv_ferrazzini_fiduciaria' => array(
			'slug'         => 'fiduciaria-contabilita',
			'icon'         => 'ferrazzini-service-dossier__icon--accounting',
			'image'        => 'service-accounting.avif',
			'image_width'  => 2172,
			'image_height' => 724,
			'image_alt'    => $content['accounting_image_alt'],
			'details'      => $content['accounting_details'],
			'image_class'  => 'ferrazzini-service-detail__image--accounting',
		),
		'srv_ferrazzini_fiscalita'  => array(
			'slug'         => 'fiscalita',
			'icon'         => 'ferrazzini-service-dossier__icon--tax',
			'image'        => 'service-tax.avif',
			'image_width'  => 2046,
			'image_height' => 768,
			'image_alt'    => $content['tax_image_alt'],
			'details'      => $content['tax_details'],
			'image_class'  => 'ferrazzini-service-detail__image--tax',
		),
		'srv_ferrazzini_aziendale'  => array(
			'slug'         => 'consulenza-aziendale',
			'icon'         => 'ferrazzini-service-dossier__icon--advisory',
			'image'        => 'service-advisory.jpg',
			'image_width'  => 2073,
			'image_height' => 759,
			'image_alt'    => $content['advisory_image_alt'],
			'details'      => $content['advisory_details'],
			'image_class'  => 'ferrazzini-service-detail__image--advisory',
		),
	);
	$output   = array();

	foreach ( $services as $service ) {
		$service_id = isset( $service['id'] ) ? (string) $service['id'] : '';

		if ( ! isset( $config[ $service_id ] ) ) {
			continue;
		}

		$cms_image_url                      = ! empty( $service['image'] ) ? esc_url_raw( $service['image'] ) : '';
		$detail_lines                       = preg_split( '/\R/u', trim( $config[ $service_id ]['details'] ) );
		$detail_lines                       = is_array( $detail_lines ) ? array_values( array_filter( array_map( 'trim', $detail_lines ) ) ) : array();
		$output[ $service_id ]              = array_merge( $service, $config[ $service_id ] );
		$output[ $service_id ]['details']   = $detail_lines;
		$output[ $service_id ]['image_url'] = $cms_image_url ? $cms_image_url : get_stylesheet_directory_uri() . '/assets/images/' . $config[ $service_id ]['image'];
		$output[ $service_id ]['image_id']  = $cms_image_url ? ferrazzini_advisory_attachment_id_from_url( $cms_image_url ) : 0;
	}

	return $output;
}

/**
 * Render a service image using Media Library metadata when available.
 *
 * @param array<string, mixed>  $service    Service presentation data.
 * @param array<string, string> $attributes Additional image attributes.
 * @return string
 */
function ferrazzini_advisory_service_image_html( $service, $attributes = array() ) {
	$default_attributes = array(
		'class'    => isset( $service['image_class'] ) ? (string) $service['image_class'] : '',
		'alt'      => isset( $service['image_alt'] ) ? (string) $service['image_alt'] : '',
		'decoding' => 'async',
	);
	$image_attributes   = array_merge( $default_attributes, $attributes );
	$image_id           = isset( $service['image_id'] ) ? absint( $service['image_id'] ) : 0;

	if ( $image_id ) {
		return wp_get_attachment_image(
			$image_id,
			ferrazzini_advisory_responsive_image_size( $image_id, 'ferrazzini-service' ),
			false,
			$image_attributes
		);
	}

	$image_url    = isset( $service['image_url'] ) ? esc_url( $service['image_url'] ) : '';
	$image_width  = isset( $service['image_width'] ) ? absint( $service['image_width'] ) : 0;
	$image_height = isset( $service['image_height'] ) ? absint( $service['image_height'] ) : 0;

	if ( ! $image_url ) {
		return '';
	}

	return sprintf(
		'<img src="%1$s" width="%2$d" height="%3$d" class="%4$s" alt="%5$s" loading="%6$s" decoding="%7$s"%8$s>',
		$image_url,
		$image_width,
		$image_height,
		esc_attr( $image_attributes['class'] ),
		esc_attr( $image_attributes['alt'] ),
		esc_attr( isset( $image_attributes['loading'] ) ? $image_attributes['loading'] : 'lazy' ),
		esc_attr( $image_attributes['decoding'] ),
		isset( $image_attributes['fetchpriority'] ) ? ' fetchpriority="' . esc_attr( $image_attributes['fetchpriority'] ) . '"' : ''
	);
}

/**
 * Create the CMS pages and submenu entries used by the service detail pages.
 *
 * The routine is idempotent and scoped to the site where this child theme is
 * active. It is run on theme activation and may also be called manually when
 * provisioning an existing local installation.
 *
 * @return array<int, int>|WP_Error Page IDs keyed by service identifier.
 */
function ferrazzini_advisory_install_service_detail_pages() {
	$services_parent = get_page_by_path( 'servizi', OBJECT, 'page' );

	if ( ! $services_parent instanceof WP_Post ) {
		return new WP_Error( 'ferrazzini_services_parent_missing', __( 'La pagina Servizi non è disponibile.', 'ferrazzini-advisory' ) );
	}

	$page_ids = array();
	foreach ( ferrazzini_advisory_service_detail_pages() as $service_id => $service ) {
		$path = 'servizi/' . $service['slug'];
		$page = get_page_by_path( $path, OBJECT, 'page' );

		if ( ! $page instanceof WP_Post ) {
			$page_id = wp_insert_post(
				array(
					'post_title'  => $service['title'],
					'post_name'   => $service['slug'],
					'post_status' => 'publish',
					'post_type'   => 'page',
					'post_parent' => $services_parent->ID,
				),
				true
			);

			if ( is_wp_error( $page_id ) ) {
				return $page_id;
			}
		} else {
			$page_id = $page->ID;
		}

		update_post_meta( $page_id, '_wp_page_template', 'page-servizio.php' );
		update_post_meta( $page_id, '_tw_seo_description', sanitize_text_field( wp_strip_all_tags( $service['description'] ) ) );
		$page_ids[ $service_id ] = $page_id;
	}

	$locations = get_nav_menu_locations();
	if ( empty( $locations['primary'] ) ) {
		return $page_ids;
	}

	$menu_id       = (int) $locations['primary'];
	$menu_items    = wp_get_nav_menu_items( $menu_id );
	$services_item = null;

	foreach ( is_array( $menu_items ) ? $menu_items : array() as $menu_item ) {
		if ( (int) $menu_item->object_id === (int) $services_parent->ID ) {
			$services_item = $menu_item;
			break;
		}
	}

	if ( ! $services_item instanceof WP_Post ) {
		return $page_ids;
	}

	$order = 1;
	foreach ( $page_ids as $service_id => $page_id ) {
		$existing_item_id = 0;
		foreach ( is_array( $menu_items ) ? $menu_items : array() as $menu_item ) {
			if ( (int) $menu_item->object_id === (int) $page_id ) {
				$existing_item_id = (int) $menu_item->ID;
				break;
			}
		}

		$service = ferrazzini_advisory_service_detail_pages()[ $service_id ];
		wp_update_nav_menu_item(
			$menu_id,
			$existing_item_id,
			array(
				'menu-item-title'     => $service['title'],
				'menu-item-object'    => 'page',
				'menu-item-object-id' => $page_id,
				'menu-item-parent-id' => $services_item->ID,
				'menu-item-position'  => $order,
				'menu-item-status'    => 'publish',
				'menu-item-type'      => 'post_type',
			)
		);
		++$order;
	}

	return $page_ids;
}
add_action( 'after_switch_theme', 'ferrazzini_advisory_install_service_detail_pages' );

/**
 * Keep the retired overview URL out of the public navigation flow.
 *
 * The page remains in WordPress so the hierarchical service permalinks and the
 * visual backup stay reversible, but visitors land on the first real service.
 *
 * @return void
 */
function ferrazzini_advisory_redirect_services_overview() {
	if ( is_admin() || wp_doing_ajax() || ! is_page_template( 'page-servizi.php' ) ) {
		return;
	}

	wp_safe_redirect( home_url( '/servizi/fiduciaria-contabilita/' ), 302, 'Ferrazzini Advisory' );
	exit;
}
add_action( 'template_redirect', 'ferrazzini_advisory_redirect_services_overview', 1 );

/**
 * Seed the editable services-page option on this site only.
 *
 * @return void
 */
function ferrazzini_advisory_seed_services_page_content() {
	if ( false === get_option( 'ferrazzini_services_page_content', false ) ) {
		add_option( 'ferrazzini_services_page_content', ferrazzini_advisory_services_page_defaults(), '', false );
	}
}
add_action( 'after_setup_theme', 'ferrazzini_advisory_seed_services_page_content', 20 );

/**
 * Sanitize services-page fields.
 *
 * @param mixed $input Submitted option value.
 * @return array<string, string>
 */
function ferrazzini_advisory_sanitize_services_page_content( $input ) {
	$defaults = ferrazzini_advisory_services_page_defaults();
	$input    = is_array( $input ) ? $input : array();
	$output   = array();

	foreach ( $defaults as $key => $default ) {
		$value          = isset( $input[ $key ] ) && is_scalar( $input[ $key ] ) ? (string) $input[ $key ] : $default;
		$output[ $key ] = str_ends_with( $key, '_details' ) || str_ends_with( $key, '_intro' )
			? sanitize_textarea_field( $value )
			: sanitize_text_field( $value );
	}

	return $output;
}

/**
 * Register the services-page option.
 *
 * @return void
 */
function ferrazzini_advisory_register_services_page_settings() {
	register_setting(
		'ferrazzini_services_page_settings',
		'ferrazzini_services_page_content',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'ferrazzini_advisory_sanitize_services_page_content',
			'default'           => ferrazzini_advisory_services_page_defaults(),
		)
	);
}
add_action( 'admin_init', 'ferrazzini_advisory_register_services_page_settings' );

/**
 * Add the services-page editor under ticinoWEB CMS.
 *
 * @return void
 */
function ferrazzini_advisory_add_services_page_cms_page() {
	add_submenu_page(
		'ticinoweb-cms',
		__( 'Pagina Servizi', 'ferrazzini-advisory' ),
		__( 'Pagina Servizi', 'ferrazzini-advisory' ),
		'edit_theme_options',
		'ferrazzini-services-page',
		'ferrazzini_advisory_render_services_page_cms'
	);
}
add_action( 'admin_menu', 'ferrazzini_advisory_add_services_page_cms_page', 21 );

/**
 * Return CMS fields grouped by page region.
 *
 * @return array<string, array<string, array<string, string>>>
 */
function ferrazzini_advisory_services_page_field_groups() {
	return array(
		__( 'Introduzione', 'ferrazzini-advisory' )       => array(
			'hero_title' => array(
				'label' => __( 'Titolo', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
			'hero_intro' => array(
				'label' => __( 'Testo introduttivo', 'ferrazzini-advisory' ),
				'type'  => 'textarea',
			),
		),
		__( 'Fiduciaria e contabilità', 'ferrazzini-advisory' ) => array(
			'accounting_details'   => array(
				'label' => __( 'Ambiti, uno per riga', 'ferrazzini-advisory' ),
				'type'  => 'textarea',
			),
			'accounting_image_alt' => array(
				'label' => __( 'Testo alternativo immagine', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
		),
		__( 'Fiscalità', 'ferrazzini-advisory' )          => array(
			'tax_details'   => array(
				'label' => __( 'Ambiti, uno per riga', 'ferrazzini-advisory' ),
				'type'  => 'textarea',
			),
			'tax_image_alt' => array(
				'label' => __( 'Testo alternativo immagine', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
		),
		__( 'Consulenza aziendale', 'ferrazzini-advisory' ) => array(
			'advisory_details'   => array(
				'label' => __( 'Ambiti, uno per riga', 'ferrazzini-advisory' ),
				'type'  => 'textarea',
			),
			'advisory_image_alt' => array(
				'label' => __( 'Testo alternativo immagine', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
		),
		__( 'Chiusura dettagli servizio', 'ferrazzini-advisory' ) => array(
			'closing_title' => array(
				'label' => __( 'Titolo', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
			'closing_intro' => array(
				'label' => __( 'Testo', 'ferrazzini-advisory' ),
				'type'  => 'textarea',
			),
		),
		__( 'Invito al contatto', 'ferrazzini-advisory' ) => array(
			'contact_title' => array(
				'label' => __( 'Titolo', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
			'contact_intro' => array(
				'label' => __( 'Testo', 'ferrazzini-advisory' ),
				'type'  => 'textarea',
			),
		),
	);
}

/**
 * Render the services-page editor.
 *
 * @return void
 */
function ferrazzini_advisory_render_services_page_cms() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		wp_die( esc_html__( 'Permessi insufficienti.', 'ferrazzini-advisory' ) );
	}

	$content = ferrazzini_advisory_services_page_content();
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Pagina Servizi', 'ferrazzini-advisory' ); ?></h1>
		<p><?php esc_html_e( 'Questi campi alimentano la pagina Servizi. Titoli e descrizioni principali dei tre servizi restano nel ticinoWEB CMS principale.', 'ferrazzini-advisory' ); ?></p>
		<form method="post" action="options.php">
			<?php settings_fields( 'ferrazzini_services_page_settings' ); ?>
			<?php foreach ( ferrazzini_advisory_services_page_field_groups() as $group_label => $fields ) : ?>
				<h2><?php echo esc_html( $group_label ); ?></h2>
				<table class="form-table" role="presentation">
					<?php foreach ( $fields as $key => $field ) : ?>
						<tr>
							<th scope="row"><label for="ferrazzini-services-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $field['label'] ); ?></label></th>
							<td>
								<?php if ( 'textarea' === $field['type'] ) : ?>
									<textarea class="large-text" rows="5" id="ferrazzini-services-<?php echo esc_attr( $key ); ?>" name="ferrazzini_services_page_content[<?php echo esc_attr( $key ); ?>]"><?php echo esc_textarea( $content[ $key ] ); ?></textarea>
								<?php else : ?>
									<input class="regular-text" type="text" id="ferrazzini-services-<?php echo esc_attr( $key ); ?>" name="ferrazzini_services_page_content[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $content[ $key ] ); ?>">
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</table>
			<?php endforeach; ?>
			<?php submit_button( __( 'Salva pagina Servizi', 'ferrazzini-advisory' ) ); ?>
		</form>
	</div>
	<?php
}
