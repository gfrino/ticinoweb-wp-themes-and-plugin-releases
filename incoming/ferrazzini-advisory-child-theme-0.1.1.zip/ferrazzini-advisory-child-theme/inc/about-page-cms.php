<?php
/**
 * About page content, media and provisioning.
 *
 * @package FerrazziniAdvisoryChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return editable defaults for the About page.
 *
 * @return array<string, string>
 */
function ferrazzini_advisory_about_page_defaults() {
	return array(
		'hero_title'           => __( 'Competenza, ascolto, continuità.', 'ferrazzini-advisory' ),
		'hero_intro'           => __( "Ferrazzini Advisory & Tax affianca imprese, imprenditori e privati con competenze fiduciarie, fiscali e aziendali coordinate.\n\nDalla gestione contabile e fiscale alle decisioni che accompagnano l’impresa, lo studio offre un interlocutore diretto e un approccio chiaro, attento al contesto e orientato alla continuità.", 'ferrazzini-advisory' ),
		'hero_image'           => '',
		'hero_image_alt'       => '',
		'story_title'          => __( 'Un rapporto diretto, costruito nel tempo.', 'ferrazzini-advisory' ),
		'story_text'           => __( "Ogni incarico parte dalla comprensione del contesto, delle priorità e delle persone coinvolte.\n\nLavoriamo per trasformare temi complessi in indicazioni comprensibili, mantenendo attenzione tanto al quadro generale quanto ai dettagli che fanno la differenza.", 'ferrazzini-advisory' ),
		'story_detail_1_label' => __( 'Il nostro metodo', 'ferrazzini-advisory' ),
		'story_detail_1_text'  => __( 'Ascolto, chiarezza e continuità.', 'ferrazzini-advisory' ),
		'story_detail_2_label' => __( 'Le nostre competenze', 'ferrazzini-advisory' ),
		'story_detail_2_text'  => __( 'Fiduciaria, fiscalità e consulenza aziendale.', 'ferrazzini-advisory' ),
		'team_title'           => __( 'Le persone dietro ogni consulenza', 'ferrazzini-advisory' ),
		'team_intro'           => __( 'Un rapporto fiduciario nasce prima di tutto dalle persone. Conosci i professionisti che seguono direttamente ogni incarico.', 'ferrazzini-advisory' ),
		'profile_1_name'       => __( 'Céline Marconi-Ferrazzini', 'ferrazzini-advisory' ),
		'profile_1_role'       => __( 'Amministratrice', 'ferrazzini-advisory' ),
		'profile_1_bio'        => __( "Testo provvisorio — da sostituire appena saranno disponibili i materiali professionali definitivi.\n\nQuesto spazio presenterà il percorso, le competenze specifiche e l’approccio alla consulenza di Céline Marconi-Ferrazzini.", 'ferrazzini-advisory' ),
		'profile_1_image'      => '',
		'profile_1_image_alt'  => '',
		'profile_2_name'       => __( 'Secondo profilo', 'ferrazzini-advisory' ),
		'profile_2_role'       => __( 'Informazioni in aggiornamento', 'ferrazzini-advisory' ),
		'profile_2_bio'        => __( "Testo provvisorio — da sostituire con nome, ruolo e informazioni professionali definitive.\n\nQuesto spazio presenterà il percorso, le aree di competenza e il contributo della seconda persona dello studio.", 'ferrazzini-advisory' ),
		'profile_2_image'      => '',
		'profile_2_image_alt'  => '',
		'contact_title'        => __( 'Conosciamoci di persona.', 'ferrazzini-advisory' ),
		'contact_intro'        => __( 'Un primo confronto ci permette di comprendere il vostro contesto e individuare insieme il prossimo passo.', 'ferrazzini-advisory' ),
	);
}

/**
 * Return saved About-page content with translation contexts.
 *
 * @return array<string, string>
 */
function ferrazzini_advisory_about_page_content() {
	$saved   = get_option( 'ferrazzini_about_page_content', array() );
	$content = array_merge(
		ferrazzini_advisory_about_page_defaults(),
		is_array( $saved ) ? $saved : array()
	);

	foreach ( $content as $key => $value ) {
		if ( str_ends_with( $key, '_image' ) ) {
			continue;
		}

		$content[ $key ] = ferrazzini_advisory_frontend_text(
			(string) $value,
			'theme:ferrazzini:about_page:' . $key
		);
	}

	return $content;
}

/**
 * Return the two editable profile records.
 *
 * @return array<int, array<string, string|int>>
 */
function ferrazzini_advisory_about_profiles() {
	$content  = ferrazzini_advisory_about_page_content();
	$profiles = array();

	for ( $index = 1; $index <= 2; ++$index ) {
		$image_url  = esc_url_raw( $content[ 'profile_' . $index . '_image' ] );
		$profiles[] = array(
			'name'      => $content[ 'profile_' . $index . '_name' ],
			'role'      => $content[ 'profile_' . $index . '_role' ],
			'bio'       => $content[ 'profile_' . $index . '_bio' ],
			'image_url' => $image_url,
			'image_id'  => $image_url ? ferrazzini_advisory_attachment_id_from_url( $image_url ) : 0,
			'image_alt' => $content[ 'profile_' . $index . '_image_alt' ],
		);
	}

	return $profiles;
}

/**
 * Render the optional About-page hero image.
 *
 * @return string
 */
function ferrazzini_advisory_about_hero_image_html() {
	$content   = ferrazzini_advisory_about_page_content();
	$image_url = esc_url_raw( $content['hero_image'] );
	$image_id  = $image_url ? ferrazzini_advisory_attachment_id_from_url( $image_url ) : 0;
	$alt       = (string) $content['hero_image_alt'];

	if ( $image_id ) {
		return wp_get_attachment_image(
			$image_id,
			ferrazzini_advisory_responsive_image_size( $image_id, 'ferrazzini-about-hero' ),
			false,
			array(
				'alt'           => $alt,
				'loading'       => 'eager',
				'decoding'      => 'async',
				'fetchpriority' => 'high',
				'sizes'         => '(max-width: 900px) 100vw, 42vw',
			)
		);
	}

	if ( ! $image_url ) {
		return '';
	}

	return sprintf(
		'<img src="%1$s" alt="%2$s" loading="eager" decoding="async" fetchpriority="high">',
		esc_url( $image_url ),
		esc_attr( $alt )
	);
}

/**
 * Render a responsive profile image.
 *
 * @param array<string, string|int> $profile Profile presentation data.
 * @return string
 */
function ferrazzini_advisory_about_profile_image_html( $profile ) {
	$image_id = isset( $profile['image_id'] ) ? absint( $profile['image_id'] ) : 0;
	$alt      = isset( $profile['image_alt'] ) ? (string) $profile['image_alt'] : '';

	if ( $image_id ) {
		return wp_get_attachment_image(
			$image_id,
			ferrazzini_advisory_responsive_image_size( $image_id, 'ferrazzini-profile' ),
			false,
			array(
				'alt'      => $alt,
				'loading'  => 'lazy',
				'decoding' => 'async',
				'sizes'    => '(max-width: 700px) 100vw, 50vw',
			)
		);
	}

	$image_url = isset( $profile['image_url'] ) ? esc_url( (string) $profile['image_url'] ) : '';
	if ( ! $image_url ) {
		return sprintf(
			'<div class="ferrazzini-team-profile__placeholder" role="img" aria-label="%1$s"><span>%2$s</span></div>',
			esc_attr__( 'Fotografia da inserire', 'ferrazzini-advisory' ),
			esc_html__( 'Foto da inserire', 'ferrazzini-advisory' )
		);
	}

	return sprintf(
		'<img src="%1$s" width="1122" height="1402" alt="%2$s" loading="lazy" decoding="async">',
		$image_url,
		esc_attr( $alt )
	);
}

/**
 * Seed About-page copy on this site only.
 *
 * @return void
 */
function ferrazzini_advisory_seed_about_page_content() {
	$defaults       = ferrazzini_advisory_about_page_defaults();
	$saved          = get_option( 'ferrazzini_about_page_content', false );
	$schema_version = (int) get_option( 'ferrazzini_about_page_schema_version', 1 );

	if ( false === $saved ) {
		add_option( 'ferrazzini_about_page_content', $defaults, '', false );
	} elseif ( is_array( $saved ) ) {
		if ( $schema_version < 2 ) {
			$legacy_titles = array(
				'hero_title'  => 'La consulenza comincia dalle persone.',
				'story_title' => 'Un rapporto diretto, costruito sull’ascolto.',
			);

			foreach ( $legacy_titles as $key => $legacy_title ) {
				if ( isset( $saved[ $key ] ) && $legacy_title === $saved[ $key ] ) {
					$saved[ $key ] = $defaults[ $key ];
				}
			}
		}

		if ( $schema_version < 3 ) {
			foreach ( array( 'profile_1_bio', 'profile_2_bio' ) as $bio_key ) {
				if ( ! isset( $saved[ $bio_key ] ) || '' === trim( (string) $saved[ $bio_key ] ) ) {
					$saved[ $bio_key ] = $defaults[ $bio_key ];
				}
			}
		}

		$legacy_hero_intro       = 'Ferrazzini Advisory & Tax SA affianca imprese, imprenditori e privati con competenze fiduciarie, fiscali e aziendali coordinate.';
		$hero_intro_needs_update = ! isset( $saved['hero_intro'] ) || $legacy_hero_intro === $saved['hero_intro'];

		if ( $hero_intro_needs_update ) {
			$saved['hero_intro'] = $defaults['hero_intro'];
		}

		if ( $schema_version < 5 ) {
			foreach ( array( 'hero_image', 'hero_image_alt' ) as $hero_image_key ) {
				if ( ! isset( $saved[ $hero_image_key ] ) ) {
					$saved[ $hero_image_key ] = $defaults[ $hero_image_key ];
				}
			}
		}

		if ( $schema_version < 6 ) {
			$story_detail_keys = array(
				'story_detail_1_label',
				'story_detail_1_text',
				'story_detail_2_label',
				'story_detail_2_text',
			);

			foreach ( $story_detail_keys as $story_detail_key ) {
				if ( ! isset( $saved[ $story_detail_key ] ) ) {
					$saved[ $story_detail_key ] = $defaults[ $story_detail_key ];
				}
			}
		}

		if ( $schema_version < 8 ) {
			$legacy_team_copy = array(
				'team_title' => 'Le persone dello studio.',
				'team_intro' => 'Due profili complementari, uniti da un modo di lavorare preciso, accessibile e orientato alla continuità.',
			);

			foreach ( $legacy_team_copy as $key => $legacy_value ) {
				if ( isset( $saved[ $key ] ) && $legacy_value === $saved[ $key ] ) {
					$saved[ $key ] = $defaults[ $key ];
				}
			}
		}

		if ( $schema_version < 10 ) {
			$legacy_profile_images = array(
				'profile_1_image' => 'about-profile-01-provisional.avif',
				'profile_2_image' => 'about-profile-02-provisional.avif',
			);

			foreach ( $legacy_profile_images as $image_key => $legacy_image_filename ) {
				$image_path = isset( $saved[ $image_key ] ) ? (string) wp_parse_url( (string) $saved[ $image_key ], PHP_URL_PATH ) : '';

				if ( '' !== $image_path && wp_basename( $image_path ) === $legacy_image_filename ) {
					$saved[ $image_key ]          = '';
					$saved[ $image_key . '_alt' ] = '';
				}
			}
		}

		if ( $schema_version < 10 || $hero_intro_needs_update ) {
			update_option( 'ferrazzini_about_page_content', $saved );
		}
	}

	if ( false === get_option( 'ferrazzini_about_page_schema_version', false ) ) {
		add_option( 'ferrazzini_about_page_schema_version', 10, '', false );
	} else {
		update_option( 'ferrazzini_about_page_schema_version', 10 );
	}
}
add_action( 'after_setup_theme', 'ferrazzini_advisory_seed_about_page_content', 20 );

/**
 * Sanitize About-page fields.
 *
 * @param mixed $input Submitted option value.
 * @return array<string, string>
 */
function ferrazzini_advisory_sanitize_about_page_content( $input ) {
	$defaults = ferrazzini_advisory_about_page_defaults();
	$input    = is_array( $input ) ? $input : array();
	$output   = array();

	foreach ( $defaults as $key => $default ) {
		$value = isset( $input[ $key ] ) && is_scalar( $input[ $key ] ) ? (string) $input[ $key ] : $default;

		if ( str_ends_with( $key, '_image' ) ) {
			$output[ $key ] = esc_url_raw( $value );
		} elseif ( str_ends_with( $key, '_text' ) || str_ends_with( $key, '_intro' ) || str_ends_with( $key, '_bio' ) ) {
			$output[ $key ] = sanitize_textarea_field( $value );
		} else {
			$output[ $key ] = sanitize_text_field( $value );
		}
	}

	return $output;
}

/**
 * Register the About-page option.
 *
 * @return void
 */
function ferrazzini_advisory_register_about_page_settings() {
	register_setting(
		'ferrazzini_about_page_settings',
		'ferrazzini_about_page_content',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'ferrazzini_advisory_sanitize_about_page_content',
			'default'           => ferrazzini_advisory_about_page_defaults(),
		)
	);
}
add_action( 'admin_init', 'ferrazzini_advisory_register_about_page_settings' );

/**
 * Add the About editor under ticinoWEB CMS.
 *
 * @return void
 */
function ferrazzini_advisory_add_about_page_cms_page() {
	add_submenu_page(
		'ticinoweb-cms',
		__( 'Pagina Chi siamo', 'ferrazzini-advisory' ),
		__( 'Pagina Chi siamo', 'ferrazzini-advisory' ),
		'edit_theme_options',
		'ferrazzini-about-page',
		'ferrazzini_advisory_render_about_page_cms'
	);
}
add_action( 'admin_menu', 'ferrazzini_advisory_add_about_page_cms_page', 22 );

/**
 * Return CMS fields grouped by page region.
 *
 * @return array<string, array<string, array<string, string>>>
 */
function ferrazzini_advisory_about_page_field_groups() {
	return array(
		__( 'Introduzione', 'ferrazzini-advisory' )       => array(
			'hero_title'           => array(
				'label' => __( 'Titolo hero', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
			'hero_intro'           => array(
				'label' => __( 'Introduzione hero', 'ferrazzini-advisory' ),
				'type'  => 'textarea',
			),
			'hero_image'           => array(
				'label' => __( 'Immagine hero', 'ferrazzini-advisory' ),
				'type'  => 'media',
			),
			'hero_image_alt'       => array(
				'label' => __( 'Testo alternativo immagine hero', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
			'story_title'          => array(
				'label' => __( 'Titolo presentazione', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
			'story_text'           => array(
				'label' => __( 'Testo presentazione', 'ferrazzini-advisory' ),
				'type'  => 'textarea',
			),
			'story_detail_1_label' => array(
				'label' => __( 'Etichetta sintesi 1', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
			'story_detail_1_text'  => array(
				'label' => __( 'Testo sintesi 1', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
			'story_detail_2_label' => array(
				'label' => __( 'Etichetta sintesi 2', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
			'story_detail_2_text'  => array(
				'label' => __( 'Testo sintesi 2', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
			'team_title'           => array(
				'label' => __( 'Titolo team', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
			'team_intro'           => array(
				'label' => __( 'Introduzione team', 'ferrazzini-advisory' ),
				'type'  => 'textarea',
			),
		),
		__( 'Primo profilo', 'ferrazzini-advisory' )      => array(
			'profile_1_name'      => array(
				'label' => __( 'Nome e cognome', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
			'profile_1_role'      => array(
				'label' => __( 'Ruolo o qualifica', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
			'profile_1_bio'       => array(
				'label'       => __( 'Testo del profilo', 'ferrazzini-advisory' ),
				'type'        => 'textarea',
				'description' => __( 'Per creare più paragrafi, separali con una riga vuota.', 'ferrazzini-advisory' ),
			),
			'profile_1_image'     => array(
				'label'       => __( 'Fotografia', 'ferrazzini-advisory' ),
				'type'        => 'media',
				'description' => __( 'Se il campo resta vuoto, sul sito appare “Foto da inserire”.', 'ferrazzini-advisory' ),
			),
			'profile_1_image_alt' => array(
				'label' => __( 'Testo alternativo fotografia', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
		),
		__( 'Secondo profilo', 'ferrazzini-advisory' )    => array(
			'profile_2_name'      => array(
				'label' => __( 'Nome e cognome', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
			'profile_2_role'      => array(
				'label' => __( 'Ruolo o qualifica', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
			'profile_2_bio'       => array(
				'label'       => __( 'Testo del profilo', 'ferrazzini-advisory' ),
				'type'        => 'textarea',
				'description' => __( 'Per creare più paragrafi, separali con una riga vuota.', 'ferrazzini-advisory' ),
			),
			'profile_2_image'     => array(
				'label'       => __( 'Fotografia', 'ferrazzini-advisory' ),
				'type'        => 'media',
				'description' => __( 'Se il campo resta vuoto, sul sito appare “Foto da inserire”.', 'ferrazzini-advisory' ),
			),
			'profile_2_image_alt' => array(
				'label' => __( 'Testo alternativo fotografia', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
		),
		__( 'Invito al contatto', 'ferrazzini-advisory' ) => array(
			'contact_title' => array(
				'label' => __( 'Titolo', 'ferrazzini-advisory' ),
				'type'  => 'text',
			),
			'contact_intro' => array(
				'label' => __( 'Testo', 'ferrazzini-advisory' ),
				'type'  => 'textarea',
			),
		),
	);
}

/**
 * Render the About-page editor.
 *
 * @return void
 */
function ferrazzini_advisory_render_about_page_cms() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		wp_die( esc_html__( 'Permessi insufficienti.', 'ferrazzini-advisory' ) );
	}

	$content = ferrazzini_advisory_about_page_content();
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Pagina Chi siamo', 'ferrazzini-advisory' ); ?></h1>
		<p><?php esc_html_e( 'Da qui puoi aggiornare nomi, ruoli, testi e fotografie dei due profili mostrati nella pagina.', 'ferrazzini-advisory' ); ?></p>
		<form method="post" action="options.php">
			<?php settings_fields( 'ferrazzini_about_page_settings' ); ?>
			<?php foreach ( ferrazzini_advisory_about_page_field_groups() as $group_label => $fields ) : ?>
				<h2><?php echo esc_html( $group_label ); ?></h2>
				<table class="form-table" role="presentation">
					<?php foreach ( $fields as $key => $field ) : ?>
						<tr>
							<th scope="row"><label for="ferrazzini-about-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $field['label'] ); ?></label></th>
							<td>
								<?php if ( 'textarea' === $field['type'] ) : ?>
									<textarea class="large-text" rows="5" id="ferrazzini-about-<?php echo esc_attr( $key ); ?>" name="ferrazzini_about_page_content[<?php echo esc_attr( $key ); ?>]"><?php echo esc_textarea( $content[ $key ] ); ?></textarea>
								<?php elseif ( 'media' === $field['type'] ) : ?>
									<div class="ferrazzini-about-media-field">
										<input class="large-text" type="url" id="ferrazzini-about-<?php echo esc_attr( $key ); ?>" name="ferrazzini_about_page_content[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $content[ $key ] ); ?>">
										<button class="button ferrazzini-about-media-select" type="button" data-target="ferrazzini-about-<?php echo esc_attr( $key ); ?>"><?php esc_html_e( 'Scegli dalla Libreria media', 'ferrazzini-advisory' ); ?></button>
									</div>
								<?php else : ?>
									<input class="regular-text" type="text" id="ferrazzini-about-<?php echo esc_attr( $key ); ?>" name="ferrazzini_about_page_content[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $content[ $key ] ); ?>">
								<?php endif; ?>
								<?php if ( isset( $field['description'] ) ) : ?>
									<p class="description"><?php echo esc_html( $field['description'] ); ?></p>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</table>
			<?php endforeach; ?>
			<?php submit_button( __( 'Salva pagina Chi siamo', 'ferrazzini-advisory' ) ); ?>
		</form>
	</div>
	<?php
}

/**
 * Create the public About page and connect it to the primary menu.
 *
 * @return int|WP_Error
 */
function ferrazzini_advisory_install_about_page() {
	$page = get_page_by_path( 'chi-siamo', OBJECT, 'page' );

	if ( ! $page instanceof WP_Post ) {
		$page_id = wp_insert_post(
			array(
				'post_title'   => __( 'Chi siamo', 'ferrazzini-advisory' ),
				'post_name'    => 'chi-siamo',
				'post_status'  => 'publish',
				'post_type'    => 'page',
				'post_content' => '',
			),
			true
		);

		if ( is_wp_error( $page_id ) ) {
			return $page_id;
		}
	} else {
		$page_id = $page->ID;
	}

	update_post_meta( $page_id, '_wp_page_template', 'page-chi-siamo.php' );
	update_post_meta(
		$page_id,
		'_tw_seo_description',
		sanitize_text_field( __( 'Conoscete le persone e il metodo di Ferrazzini Advisory & Tax SA, studio fiduciario, fiscale e aziendale a Locarno.', 'ferrazzini-advisory' ) )
	);

	$locations = get_nav_menu_locations();
	if ( empty( $locations['primary'] ) ) {
		return $page_id;
	}

	$menu_id        = (int) $locations['primary'];
	$menu_items     = wp_get_nav_menu_items( $menu_id );
	$about_menu_id  = 0;
	$about_position = 0;

	foreach ( is_array( $menu_items ) ? $menu_items : array() as $menu_item ) {
		if ( 'Chi siamo' === trim( wp_strip_all_tags( $menu_item->title ) ) ) {
			$about_menu_id  = (int) $menu_item->ID;
			$about_position = (int) $menu_item->menu_order;
			break;
		}
	}

	wp_update_nav_menu_item(
		$menu_id,
		$about_menu_id,
		array(
			'menu-item-title'     => __( 'Chi siamo', 'ferrazzini-advisory' ),
			'menu-item-object'    => 'page',
			'menu-item-object-id' => $page_id,
			'menu-item-parent-id' => 0,
			'menu-item-position'  => $about_position,
			'menu-item-status'    => 'publish',
			'menu-item-type'      => 'post_type',
		)
	);

	return $page_id;
}
add_action( 'after_switch_theme', 'ferrazzini_advisory_install_about_page' );
