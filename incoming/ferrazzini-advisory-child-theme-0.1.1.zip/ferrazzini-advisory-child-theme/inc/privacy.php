<?php
/**
 * Privacy helpers shared by the Ferrazzini templates.
 *
 * @package FerrazziniAdvisoryChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return the single authoritative privacy-policy URL for this site.
 *
 * WordPress core takes precedence. The parent CMS option remains a fallback
 * for existing ticinoWEB installations that store an external legal URL.
 *
 * @return string
 */
function ferrazzini_advisory_get_privacy_policy_url() {
	$core_url = function_exists( 'get_privacy_policy_url' ) ? (string) get_privacy_policy_url() : '';
	$core_url = esc_url_raw( $core_url, array( 'http', 'https' ) );

	if ( $core_url ) {
		return $core_url;
	}

	return esc_url_raw(
		(string) get_option( 'tw_privacy_policy_url', '' ),
		array( 'http', 'https' )
	);
}
