<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="tt-header animate-header">
    <div class="tt-header-inner tt-container">
        <a href="<?php echo esc_url(home_url('/')); ?>" class="tt-logo" style="display: flex; align-items: center;">
            <img src="<?php echo esc_url(tt_get_brand_image_url('Logo-Ticino-Top-banner.svg')); ?>" alt="Ticino Top" style="height: 40px; width: auto;">
        </a>
        <nav class="tt-nav">
            <?php
            wp_nav_menu( array(
                'theme_location' => 'primary',
                'container'      => false,
                'depth'          => 1,
                'fallback_cb'    => 'ticinotop_menu_fallback',
            ) );
            ?>
        </nav>
        <a href="<?php echo esc_url(home_url('/candidati/')); ?>" class="tt-btn tt-btn-primary tt-desktop-only-btn" style="padding: 8px 16px; font-size: 13px;">Candidati</a>
        <button class="tt-hamburger" aria-label="Menu" aria-expanded="false" aria-controls="mobile-menu">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</header>

<div id="mobile-menu" class="tt-mobile-menu">
    <div class="tt-mobile-menu-inner">
        <nav class="tt-mobile-nav">
            <?php
            wp_nav_menu( array(
                'theme_location' => 'primary',
                'container'      => false,
                'depth'          => 1,
                'fallback_cb'    => 'ticinotop_menu_fallback',
            ) );
            ?>
        </nav>
        <div class="tt-mobile-actions">
            <a href="<?php echo esc_url(home_url('/candidati/')); ?>" class="tt-btn tt-btn-primary" style="width: 100%; text-align: center; justify-content: center; padding: 14px 20px;">Candidati</a>
        </div>
    </div>
</div>
