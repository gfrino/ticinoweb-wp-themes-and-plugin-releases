<?php
/**
 * Ticino Top - Ricerca web delle aziende con OpenAI (Responses API + tool web_search).
 *
 * Usa la stessa chiave OpenAI dello Scanner AI. OpenAI cerca sul web i dati pubblici dell'azienda
 * (registro di commercio, recensioni Google e di altre piattaforme, orari, servizi, social) e per
 * ogni dato indica la pagina da cui l'ha preso.
 *
 * Veridicita: la risposta del modello non viene presa per buona. Ogni dato con una fonte viene
 * accettato solo se quella fonte e' davvero tra le pagine consultate dalla ricerca (sources e
 * citazioni restituite dall'API) oppure e' sul sito ufficiale dell'azienda. Il resto viene scartato.
 */

if (!defined('ABSPATH')) {
    exit;
}

define('TT_AI_RESEARCH_DEFAULT_MODEL', 'gpt-4.1-mini');

/**
 * Modello per la ricerca web (Scanner AI > Impostazioni). Deve supportare il tool web_search.
 */
function tt_ai_research_model() {
    $model = trim((string) get_option('tt_openai_research_model', ''));
    return $model !== '' ? $model : TT_AI_RESEARCH_DEFAULT_MODEL;
}

/**
 * Normalizza un URL per il confronto con le fonti (host senza www, path senza slash finale, niente query/frammenti).
 */
function tt_ai_normalize_source_url($url) {
    $parts = wp_parse_url(trim((string) $url));
    if (empty($parts['host'])) {
        return '';
    }
    $host = preg_replace('/^www\./', '', strtolower($parts['host']));
    $path = isset($parts['path']) ? rtrim($parts['path'], '/') : '';
    return $host . strtolower($path);
}

function tt_ai_url_host($url) {
    $host = wp_parse_url((string) $url, PHP_URL_HOST);
    return $host ? preg_replace('/^www\./', '', strtolower($host)) : '';
}

/**
 * Chiamata alla Responses API con web_search. Prova il modello configurato e poi gpt-4.1-mini / gpt-4.1;
 * se il tool web_search non e' accettato riprova con web_search_preview.
 * Ritorna array('text' => string, 'sources' => array(url => title), 'model' => string) oppure WP_Error.
 */
function tt_ai_responses_web_search($instructions, $input) {
    $api_key = tt_ai_get_openai_key();
    if (!$api_key) {
        return new WP_Error('tt_no_key', 'Chiave API OpenAI non configurata (Scanner AI > Impostazioni).');
    }

    $models = array_values(array_unique(array(tt_ai_research_model(), 'gpt-4.1-mini', 'gpt-4.1')));
    $last_error = null;

    foreach ($models as $model) {
        foreach (array('web_search', 'web_search_preview') as $tool_type) {
            $tool = array(
                'type'                => $tool_type,
                'search_context_size' => 'high',
                'user_location'       => array('type' => 'approximate', 'country' => 'CH', 'region' => 'Ticino'),
            );
            $body = array(
                'model'             => $model,
                'instructions'      => $instructions,
                'input'             => $input,
                'tools'             => array($tool),
                'tool_choice'       => 'required',
                'max_output_tokens' => 6000,
            );
            if ($tool_type === 'web_search') {
                $body['include'] = array('web_search_call.action.sources');
            }
            if (preg_match('/^(gpt-5|o\d)/', $model)) {
                $body['reasoning'] = array('effort' => 'low');
            }

            $response = wp_remote_post('https://api.openai.com/v1/responses', array(
                'timeout' => 180,
                'headers' => array(
                    'Authorization' => 'Bearer ' . $api_key,
                    'Content-Type'  => 'application/json',
                ),
                'body'    => wp_json_encode($body),
            ));

            if (is_wp_error($response)) {
                return new WP_Error('tt_api', 'Errore di connessione a OpenAI (ricerca web): ' . $response->get_error_message());
            }

            $data = json_decode(wp_remote_retrieve_body($response), true);
            if (isset($data['error'])) {
                $msg = isset($data['error']['message']) ? $data['error']['message'] : 'errore sconosciuto';
                $last_error = new WP_Error('tt_api', 'Errore da OpenAI (ricerca web, ' . $model . '): ' . $msg);
                // Tool non supportato: prova la variante preview; modello non disponibile: prova il successivo
                if (stripos($msg, 'web_search') !== false || stripos($msg, 'tool') !== false || stripos($msg, 'include') !== false) {
                    continue;
                }
                if (stripos($msg, 'model') !== false) {
                    continue 2;
                }
                return $last_error;
            }

            $text = '';
            $sources = array();
            foreach ((array) (isset($data['output']) ? $data['output'] : array()) as $item) {
                $type = isset($item['type']) ? $item['type'] : '';
                if ($type === 'web_search_call' && !empty($item['action']['sources'])) {
                    foreach ((array) $item['action']['sources'] as $src) {
                        if (!empty($src['url'])) {
                            $sources[$src['url']] = isset($src['title']) ? $src['title'] : '';
                        }
                    }
                }
                if ($type === 'message' && !empty($item['content'])) {
                    foreach ((array) $item['content'] as $c) {
                        if (isset($c['type']) && $c['type'] === 'output_text') {
                            $text .= isset($c['text']) ? $c['text'] : '';
                            foreach ((array) (isset($c['annotations']) ? $c['annotations'] : array()) as $a) {
                                if (isset($a['type']) && $a['type'] === 'url_citation' && !empty($a['url'])) {
                                    $sources[$a['url']] = isset($a['title']) ? $a['title'] : '';
                                }
                            }
                        }
                    }
                }
            }

            return array('text' => $text, 'sources' => $sources, 'model' => $model);
        }
    }

    return $last_error ?: new WP_Error('tt_api', 'Ricerca web OpenAI non disponibile.');
}

/**
 * Estrae il primo oggetto JSON dal testo del modello (che puo contenere citazioni o un blocco ```json).
 */
function tt_ai_parse_json_block($text) {
    $text = trim((string) $text);
    $text = preg_replace('/^```(?:json)?\s*|\s*```$/m', '', $text);
    $start = strpos($text, '{');
    $end = strrpos($text, '}');
    if ($start === false || $end === false || $end <= $start) {
        return null;
    }
    $json = substr($text, $start, $end - $start + 1);
    // Le citazioni inline del web search possono comparire come [testo](url) dentro le stringhe: innocue per json_decode
    $data = json_decode($json, true);
    return is_array($data) ? $data : null;
}

/**
 * Ricerca web dell'azienda. Ritorna i dati verificati:
 * array(
 *   'status'  => ok|error,
 *   'message' => string,
 *   'fields'  => array(campo => array('value' => ..., 'source' => url)),   // ragione_sociale, forma_giuridica, uid, anno_fondazione, indirizzo, telefono, email, orari, servizi
 *   'google'  => array('rating' => float, 'count' => int, 'maps_url' => url, 'source' => url) | null,
 *   'reviews' => array(array('platform', 'rating', 'count', 'url')),
 *   'social'  => array(array('network', 'url')),
 *   'sources' => array(url => title),   // pagine consultate
 *   'discarded' => int,                 // dati scartati perche senza fonte verificabile
 *   'model'   => string,
 * )
 */
function tt_ai_research_company($name, $website, $localita = '', $site_social = array()) {
    $site_host = tt_ai_url_host($website);

    $instructions = "Sei un ricercatore di Ticino Top, il portale che recensisce le aziende del Canton Ticino (Svizzera). "
        . "Cerca sul web informazioni PUBBLICHE e VERIFICABILI su UNA azienda precisa, identificata dal suo sito ufficiale. "
        . "Controlla che ogni risultato riguardi davvero quell'azienda (stesso sito, stesso indirizzo o stessa ragione sociale): ignora omonimi. "
        . "Fonti da cercare: il sito ufficiale; il registro di commercio svizzero (zefix.ch, moneyhouse.ch, easymonitoring.ch) per ragione sociale, forma giuridica, UID (CHE-xxx.xxx.xxx), anno di iscrizione e sede; "
        . "la scheda Google (Google Maps / Profilo dell'attivita) per voto medio e numero di recensioni; altre piattaforme di recensioni (local.ch, search.ch, Trustpilot, TripAdvisor, Facebook); i profili social ufficiali. "
        . "Regole: non inventare nulla. Ogni dato deve avere come 'fonte' l'URL esatto della pagina da cui lo hai letto. "
        . "Se non trovi un dato con certezza lascia il valore vuoto (\"\" oppure null). Non stimare voti o numeri di recensioni. "
        . "Il voto Google va riportato solo se lo hai letto su una pagina che lo mostra per questa azienda. "
        . "Rispondi SOLO con un oggetto JSON valido con questa struttura, senza testo prima o dopo:\n"
        . '{"ragione_sociale":{"valore":"","fonte":""},"forma_giuridica":{"valore":"","fonte":""},"uid":{"valore":"","fonte":""},'
        . '"anno_fondazione":{"valore":"","fonte":""},"indirizzo":{"valore":"","fonte":""},"telefono":{"valore":"","fonte":""},'
        . '"email":{"valore":"","fonte":""},"orari":{"valore":"","fonte":""},"servizi":{"valore":[],"fonte":""},'
        . '"google":{"voto":null,"recensioni":null,"url_scheda":"","fonte":""},'
        . '"altre_recensioni":[{"piattaforma":"","voto":null,"recensioni":null,"url":""}],'
        . '"social":[{"rete":"","url":""}]}';

    $input = "Azienda: " . $name . "\nSito ufficiale: " . $website . ($localita ? "\nLocalita: " . $localita : '')
        . "\nCerca i dati elencati e restituisci il JSON richiesto.";

    $res = tt_ai_responses_web_search($instructions, $input);
    if (is_wp_error($res)) {
        return array('status' => 'error', 'message' => $res->get_error_message(), 'fields' => array(), 'google' => null, 'reviews' => array(), 'social' => array(), 'sources' => array(), 'discarded' => 0, 'model' => '');
    }

    $raw = tt_ai_parse_json_block($res['text']);
    if (!$raw) {
        return array('status' => 'error', 'message' => 'La ricerca web non ha restituito dati leggibili.', 'fields' => array(), 'google' => null, 'reviews' => array(), 'social' => array(), 'sources' => $res['sources'], 'discarded' => 0, 'model' => $res['model']);
    }

    $out = tt_ai_research_validate($raw, $res['sources'], $site_host, $site_social);
    $out['model'] = $res['model'];
    return $out;
}

/**
 * Tiene solo i dati la cui fonte e' una pagina realmente consultata (o il sito ufficiale).
 */
function tt_ai_research_validate($raw, $sources, $site_host, $site_social = array()) {
    $known = array();
    foreach (array_keys($sources) as $url) {
        $n = tt_ai_normalize_source_url($url);
        if ($n) {
            $known[$n] = $url;
        }
    }
    $source_hosts = array();
    foreach (array_keys($sources) as $url) {
        $h = tt_ai_url_host($url);
        if ($h) {
            $source_hosts[$h] = true;
        }
    }

    // Una fonte e' valida se e' tra le pagine consultate o se e' sul sito ufficiale dell'azienda
    $valid_source = function ($url) use ($known, $site_host) {
        $url = esc_url_raw(trim((string) $url));
        if (!$url || !preg_match('#^https?://#i', $url)) {
            return '';
        }
        $n = tt_ai_normalize_source_url($url);
        if (isset($known[$n])) {
            return $known[$n];
        }
        if ($site_host && tt_ai_url_host($url) === $site_host) {
            return $url;
        }
        return '';
    };

    $discarded = 0;
    $fields = array();
    foreach (array('ragione_sociale', 'forma_giuridica', 'uid', 'anno_fondazione', 'indirizzo', 'telefono', 'email', 'orari', 'servizi') as $key) {
        if (!isset($raw[$key]) || !is_array($raw[$key])) {
            continue;
        }
        $value = isset($raw[$key]['valore']) ? $raw[$key]['valore'] : '';
        if ($key === 'servizi') {
            $value = array_values(array_filter(array_map('sanitize_text_field', (array) $value)));
            $value = array_slice($value, 0, 12);
        } else {
            $value = is_scalar($value) ? sanitize_text_field((string) $value) : '';
        }
        if ($value === '' || $value === array()) {
            continue;
        }
        $source = $valid_source(isset($raw[$key]['fonte']) ? $raw[$key]['fonte'] : '');
        if (!$source) {
            $discarded++;
            continue;
        }
        if ($key === 'uid') {
            $value = strtoupper(str_replace(' ', '', $value));
            if (!preg_match('/^CHE-?\d{3}\.?\d{3}\.?\d{3}$/', $value)) {
                $discarded++;
                continue;
            }
            $digits = preg_replace('/\D/', '', $value);
            $value = 'CHE-' . substr($digits, 0, 3) . '.' . substr($digits, 3, 3) . '.' . substr($digits, 6, 3);
        }
        if ($key === 'anno_fondazione') {
            if (!preg_match('/\b(1[89]\d{2}|20\d{2})\b/', $value, $m) || intval($m[1]) > intval(wp_date('Y'))) {
                $discarded++;
                continue;
            }
            $value = $m[1];
        }
        if ($key === 'email') {
            $value = sanitize_email($value);
            if (!$value) {
                continue;
            }
        }
        $fields[$key] = array('value' => $value, 'source' => $source);
    }

    // Recensioni Google
    $google = null;
    if (!empty($raw['google']) && is_array($raw['google'])) {
        $g = $raw['google'];
        $rating = isset($g['voto']) && is_numeric(str_replace(',', '.', (string) $g['voto'])) ? (float) str_replace(',', '.', (string) $g['voto']) : null;
        $count = isset($g['recensioni']) ? intval(preg_replace('/\D/', '', (string) $g['recensioni'])) : 0;
        $source = $valid_source(isset($g['fonte']) ? $g['fonte'] : '');
        $maps = esc_url_raw(isset($g['url_scheda']) ? (string) $g['url_scheda'] : '');
        $maps_host = tt_ai_url_host($maps);
        // Link alla scheda: solo domini Google
        if ($maps && !preg_match('/(^|\.)google\.[a-z.]+$|^goo\.gl$|^maps\.app\.goo\.gl$|^g\.co$/', $maps_host)) {
            $maps = '';
        }
        if ($rating !== null && $rating >= 1 && $rating <= 5 && $count > 0 && $source) {
            $google = array('rating' => round($rating, 1), 'count' => $count, 'maps_url' => $maps, 'source' => $source);
        } elseif ($rating !== null || $count > 0) {
            $discarded++;
        }
    }

    // Altre piattaforme di recensioni (scala 1-5, link realmente consultato)
    $reviews = array();
    foreach ((array) (isset($raw['altre_recensioni']) ? $raw['altre_recensioni'] : array()) as $r) {
        if (!is_array($r) || empty($r['url'])) {
            continue;
        }
        $url = $valid_source($r['url']);
        $rating = isset($r['voto']) && is_numeric(str_replace(',', '.', (string) $r['voto'])) ? (float) str_replace(',', '.', (string) $r['voto']) : null;
        $count = isset($r['recensioni']) ? intval(preg_replace('/\D/', '', (string) $r['recensioni'])) : 0;
        if (!$url || $rating === null || $rating < 1 || $rating > 5 || $count < 1) {
            $discarded++;
            continue;
        }
        $platform = sanitize_text_field(isset($r['piattaforma']) ? $r['piattaforma'] : '') ?: tt_ai_url_host($url);
        if (stripos($platform, 'google') !== false) {
            continue; // Google e' gestito a parte
        }
        $reviews[] = array('platform' => $platform, 'rating' => round($rating, 1), 'count' => $count, 'url' => $url);
    }
    $reviews = array_slice($reviews, 0, 6);

    // Social: domini noti, link visto dalla ricerca o presente sul sito ufficiale
    $social = array();
    $site_social_norm = array_map('tt_ai_normalize_source_url', (array) $site_social);
    $social_domains = array('facebook.com', 'instagram.com', 'linkedin.com', 'youtube.com', 'tiktok.com', 'x.com', 'twitter.com');
    foreach ((array) (isset($raw['social']) ? $raw['social'] : array()) as $s) {
        if (!is_array($s) || empty($s['url'])) {
            continue;
        }
        $url = esc_url_raw((string) $s['url']);
        $host = tt_ai_url_host($url);
        $ok_domain = false;
        foreach ($social_domains as $d) {
            if ($host === $d || substr($host, -strlen('.' . $d)) === '.' . $d) {
                $ok_domain = true;
            }
        }
        $seen = $valid_source($url) || in_array(tt_ai_normalize_source_url($url), $site_social_norm, true);
        if ($ok_domain && $seen) {
            $social[] = array('network' => sanitize_text_field(isset($s['rete']) ? $s['rete'] : $host), 'url' => $url);
        }
    }

    return array(
        'status'    => 'ok',
        'message'   => '',
        'fields'    => $fields,
        'google'    => $google,
        'reviews'   => $reviews,
        'social'    => $social,
        'sources'   => $sources,
        'discarded' => $discarded,
    );
}

/**
 * Icona "G" di Google (attribuzione delle recensioni Google).
 */
function tt_google_g_icon($size = 18) {
    $size = intval($size);
    return '<svg class="tt-g-icon" width="' . $size . '" height="' . $size . '" viewBox="0 0 48 48" aria-hidden="true" focusable="false">'
        . '<path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>'
        . '<path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>'
        . '<path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>'
        . '<path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>'
        . '</svg>';
}

/**
 * Stelle 0-5 con riempimento parziale (es. 4.5).
 */
function tt_rating_stars($rating, $size = 16) {
    $pct = max(0, min(100, ((float) $rating / 5) * 100));
    $star = '<svg width="' . intval($size) . '" height="' . intval($size) . '" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2l2.9 6.9 7.1.6-5.4 4.7 1.6 7L12 17.5 5.8 21.2l1.6-7L2 9.5l7.1-.6z"/></svg>';
    return '<span class="tt-stars" role="img" aria-label="' . esc_attr(sprintf('%s su 5', number_format_i18n((float) $rating, 1))) . '">'
        . '<span class="tt-stars-base">' . str_repeat($star, 5) . '</span>'
        . '<span class="tt-stars-fill" style="width:' . esc_attr(round($pct, 1)) . '%">' . str_repeat($star, 5) . '</span>'
        . '</span>';
}

/* ---------- Admin: stili, lista Aziende (azione "Aggiorna con AI" e colonna voto) ---------- */

add_action('admin_enqueue_scripts', function ($hook) {
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    $is_azienda = $screen && $screen->post_type === 'azienda' && in_array($screen->base, array('post', 'edit'), true);
    $is_scanner = isset($_GET['page']) && strpos((string) $_GET['page'], 'tt-ai-scanner') === 0;
    if (!$is_azienda && !$is_scanner) {
        return;
    }
    $file = get_stylesheet_directory() . '/assets/css/tt-admin.css';
    wp_enqueue_style('tt-admin', get_stylesheet_directory_uri() . '/assets/css/tt-admin.css', array(), filemtime($file));
});

add_filter('post_row_actions', function ($actions, $post) {
    if ($post->post_type === 'azienda' && current_user_can('manage_options') && get_post_meta($post->ID, '_tt_website', true) && function_exists('tt_company_refresh_url')) {
        $actions['tt_ai_refresh'] = '<a href="' . esc_url(tt_company_refresh_url($post->ID)) . '">Aggiorna con AI</a>';
    }
    return $actions;
}, 10, 2);

add_filter('manage_azienda_posts_columns', function ($columns) {
    $new = array();
    foreach ($columns as $key => $label) {
        $new[$key] = $label;
        if ($key === 'title') {
            $new['tt_rating'] = 'Voto';
        }
    }
    return $new;
});

add_action('manage_azienda_posts_custom_column', function ($column, $post_id) {
    if ($column !== 'tt_rating') {
        return;
    }
    $voto = get_post_meta($post_id, '_tt_voto', true);
    if ($voto === '') {
        echo '<span class="tt-muted">—</span>';
        return;
    }
    $google = function_exists('tt_azienda_has_google_rating') && tt_azienda_has_google_rating($post_id);
    echo '<span class="tt-list-rating">' . ($google ? tt_google_g_icon(16) : '') . '<b>' . esc_html(number_format_i18n((float) $voto, 1)) . '</b>' . tt_rating_stars((float) $voto, 12) . '</span>';
    $count = get_post_meta($post_id, '_tt_recensioni', true);
    if ($count !== '') {
        echo '<br><span class="tt-muted" style="font-size:12px;">' . esc_html($count) . ' recensioni' . ($google ? ' Google' : '') . '</span>';
    }
}, 10, 2);
