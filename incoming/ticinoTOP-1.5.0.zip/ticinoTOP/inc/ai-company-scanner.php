<?php
/**
 * Ticino Top - Scanner AI del sito web di un'azienda
 *
 * Flusso: URL del sito aziendale -> scansione di home + pagine chiave (contatti, chi siamo, servizi)
 * -> estrazione dati strutturati -> OpenAI (output JSON a schema fisso) -> anteprima modificabile
 * -> "Pubblica in Aziende" crea/aggiorna il CPT azienda con tutti i campi compilati.
 */

if (!defined('ABSPATH')) {
    exit;
}

define('TT_COMPANY_SCAN_TTL', DAY_IN_SECONDS);
define('TT_COMPANY_SCAN_MAX_PAGES', 5);
define('TT_COMPANY_SCAN_PAGE_CHARS', 15000);
define('TT_COMPANY_SCAN_TOTAL_CHARS', 45000);

/**
 * Chiave OpenAI: costante in wp-config.php (se definita) oppure opzione salvata dal pannello.
 */
function tt_ai_get_openai_key() {
    if (defined('TT_OPENAI_API_KEY') && TT_OPENAI_API_KEY) {
        return TT_OPENAI_API_KEY;
    }
    return (string) get_option('tt_openai_api_key', '');
}

function tt_ai_score_keys() {
    return array('qualita', 'fiducia', 'servizio', 'prezzo', 'innovazione', 'coerenza');
}

/**
 * Aggiunge una scansione alla media cumulativa (benchmark) della categoria.
 */
function tt_ai_update_category_benchmark($category_id, $scores) {
    $scan_count = intval(get_term_meta($category_id, '_tt_benchmark_scan_count', true));

    foreach (tt_ai_score_keys() as $param) {
        $value = intval(isset($scores[$param]) ? $scores[$param] : 0);
        if ($scan_count > 0) {
            $current = intval(get_term_meta($category_id, '_tt_benchmark_' . $param, true));
            $value = round((($current * $scan_count) + $value) / ($scan_count + 1));
        }
        update_term_meta($category_id, '_tt_benchmark_' . $param, $value);
    }

    update_term_meta($category_id, '_tt_benchmark_scan_count', $scan_count + 1);
}

/**
 * Host normalizzato (senza www) usato per riconoscere aziende gia presenti.
 */
function tt_company_normalize_host($url) {
    $host = wp_parse_url($url, PHP_URL_HOST);
    if (!$host) {
        return '';
    }
    return preg_replace('/^www\./', '', strtolower($host));
}

function tt_company_find_existing($host, $title = '') {
    if ($host) {
        $found = get_posts(array(
            'post_type'      => 'azienda',
            'post_status'    => array('publish', 'draft', 'pending', 'private', 'future'),
            'posts_per_page' => 1,
            'meta_key'       => '_tt_website_host',
            'meta_value'     => $host,
            'fields'         => 'ids',
        ));
        if ($found) {
            return (int) $found[0];
        }
    }
    if ($title) {
        $found = get_posts(array(
            'post_type'      => 'azienda',
            'post_status'    => array('publish', 'draft', 'pending', 'private', 'future'),
            'posts_per_page' => 1,
            'title'          => $title,
            'fields'         => 'ids',
        ));
        if ($found) {
            return (int) $found[0];
        }
    }
    return 0;
}

/**
 * Scarica una pagina HTML. wp_safe_remote_get rifiuta host interni/privati (protezione SSRF).
 */
function tt_company_fetch_page($url) {
    $response = wp_safe_remote_get($url, array(
        'timeout'             => 15,
        'redirection'         => 5,
        'limit_response_size' => 3 * MB_IN_BYTES,
        'user-agent'          => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
        'headers'             => array(
            'Accept'          => 'text/html,application/xhtml+xml;q=0.9,*/*;q=0.8',
            'Accept-Language' => 'it-CH,it;q=0.9,de;q=0.6,fr;q=0.5,en;q=0.4',
        ),
    ));

    if (is_wp_error($response)) {
        return $response;
    }

    $code = wp_remote_retrieve_response_code($response);
    if ($code < 200 || $code >= 300) {
        return new WP_Error('tt_http', sprintf('HTTP %d', $code));
    }

    $type = wp_remote_retrieve_header($response, 'content-type');
    if ($type && stripos($type, 'html') === false) {
        return new WP_Error('tt_type', 'Contenuto non HTML: ' . $type);
    }

    return wp_remote_retrieve_body($response);
}

/**
 * Estrae testo, metadati, JSON-LD, contatti, link interni e immagini candidate da una pagina.
 */
function tt_company_parse_html($html, $page_url) {
    $out = array(
        'title'       => '',
        'description' => '',
        'og'          => array(),
        'jsonld'      => array(),
        'phones'      => array(),
        'emails'      => array(),
        'social'      => array(),
        'links'       => array(),
        'images'      => array(),
        'text'        => '',
    );

    if (!class_exists('DOMDocument') || trim($html) === '') {
        $out['text'] = trim(preg_replace('/\s+/u', ' ', wp_strip_all_tags($html)));
        return $out;
    }

    $prev = libxml_use_internal_errors(true);
    $dom = new DOMDocument();
    $dom->loadHTML('<?xml encoding="UTF-8">' . $html, LIBXML_NONET | LIBXML_NOWARNING | LIBXML_NOERROR);
    libxml_clear_errors();
    libxml_use_internal_errors($prev);
    $xpath = new DOMXPath($dom);

    $abs = function ($href) use ($page_url) {
        $href = trim($href);
        if ($href === '' || strpos($href, 'data:') === 0) {
            return '';
        }
        return WP_Http::make_absolute_url($href, $page_url);
    };

    $title = $xpath->query('//title');
    if ($title->length) {
        $out['title'] = trim($title->item(0)->textContent);
    }

    foreach ($xpath->query('//meta[@name or @property]') as $meta) {
        $key = strtolower($meta->getAttribute('property') ?: $meta->getAttribute('name'));
        $content = trim($meta->getAttribute('content'));
        if ($content === '') {
            continue;
        }
        if ($key === 'description') {
            $out['description'] = $content;
        } elseif (strpos($key, 'og:') === 0) {
            $out['og'][$key] = $content;
        }
    }
    if (!empty($out['og']['og:image'])) {
        $out['images'][] = $abs($out['og']['og:image']);
    }

    foreach ($xpath->query('//script[@type="application/ld+json"]') as $script) {
        $decoded = json_decode(trim($script->textContent), true);
        if (is_array($decoded)) {
            $out['jsonld'][] = $decoded;
        }
    }

    $social_hosts = array('facebook.com', 'instagram.com', 'linkedin.com', 'youtube.com', 'tiktok.com', 'x.com', 'twitter.com', 'tripadvisor.');
    $page_host = tt_company_normalize_host($page_url);

    foreach ($xpath->query('//a[@href]') as $a) {
        $href = trim($a->getAttribute('href'));
        if (stripos($href, 'tel:') === 0) {
            $out['phones'][] = trim(ltrim(rawurldecode(substr($href, 4)), '/'));
            continue;
        }
        if (stripos($href, 'mailto:') === 0) {
            $email = sanitize_email(strtok(substr($href, 7), '?'));
            if ($email) {
                $out['emails'][] = $email;
            }
            continue;
        }
        $url = $abs($href);
        if (!$url || !preg_match('#^https?://#i', $url)) {
            continue;
        }
        $host = tt_company_normalize_host($url);
        foreach ($social_hosts as $sh) {
            if (strpos($host, $sh) !== false) {
                $out['social'][] = strtok($url, '#');
                continue 2;
            }
        }
        if ($host === $page_host) {
            $out['links'][] = array(
                'url'   => strtok($url, '#'),
                'label' => trim(preg_replace('/\s+/u', ' ', $a->textContent)),
            );
        }
    }

    // Logo e immagini significative
    foreach ($xpath->query('//link[contains(@rel,"apple-touch-icon")]/@href') as $attr) {
        $out['images'][] = $abs($attr->value);
    }
    foreach ($xpath->query('//img') as $img) {
        $src = $img->getAttribute('src') ?: $img->getAttribute('data-src');
        $hint = strtolower($img->getAttribute('class') . ' ' . $img->getAttribute('alt') . ' ' . $img->getAttribute('id') . ' ' . $src);
        if ($src && strpos($hint, 'logo') !== false) {
            $out['images'][] = $abs($src);
        }
    }

    // Testo visibile, senza script/style/svg
    foreach (array('script', 'style', 'noscript', 'svg', 'iframe', 'template') as $tag) {
        $nodes = $dom->getElementsByTagName($tag);
        for ($i = $nodes->length - 1; $i >= 0; $i--) {
            $node = $nodes->item($i);
            $node->parentNode->removeChild($node);
        }
    }
    $body = $dom->getElementsByTagName('body');
    $text = $body->length ? $body->item(0)->textContent : $dom->textContent;
    $out['text'] = trim(preg_replace('/\s+/u', ' ', $text));

    foreach (array('phones', 'emails', 'social', 'images') as $k) {
        $out[$k] = array_values(array_unique(array_filter($out[$k])));
    }

    return $out;
}

/**
 * Sceglie le pagine interne piu utili (contatti, chi siamo, servizi...).
 */
function tt_company_pick_subpages($links, $home_url, $max) {
    $patterns = array(
        'contatt', 'contact', 'kontakt', 'chi-siamo', 'chisiamo', 'about', 'azienda', 'company',
        'ueber-uns', 'uber-uns', 'servizi', 'services', 'dienstleistungen', 'prodotti', 'products',
        'team', 'storia', 'dove-siamo', 'impressum', 'note-legali',
    );
    $home = untrailingslashit(strtok($home_url, '?'));
    $picked = array();

    foreach ($patterns as $pattern) {
        foreach ($links as $link) {
            $url = $link['url'];
            $path = strtolower((string) wp_parse_url($url, PHP_URL_PATH));
            $haystack = $path . ' ' . strtolower(remove_accents($link['label']));
            if (untrailingslashit(strtok($url, '?')) === $home || isset($picked[$url])) {
                continue;
            }
            if (preg_match('/\.(pdf|jpe?g|png|gif|webp|zip|docx?)$/i', $path)) {
                continue;
            }
            if (strpos($haystack, $pattern) !== false) {
                $picked[$url] = true;
                break;
            }
        }
        if (count($picked) >= $max) {
            break;
        }
    }

    return array_keys($picked);
}

/**
 * Scansiona il sito aziendale. Ritorna array con pagine lette, dati raccolti e testo per l'AI.
 */
function tt_company_crawl($url) {
    $home_html = tt_company_fetch_page($url);
    if (is_wp_error($home_html)) {
        return $home_html;
    }

    $home = tt_company_parse_html($home_html, $url);
    $pages = array($url => $home);

    foreach (tt_company_pick_subpages($home['links'], $url, TT_COMPANY_SCAN_MAX_PAGES - 1) as $sub_url) {
        $html = tt_company_fetch_page($sub_url);
        if (!is_wp_error($html)) {
            $pages[$sub_url] = tt_company_parse_html($html, $sub_url);
        }
    }

    $collected = array('phones' => array(), 'emails' => array(), 'social' => array(), 'images' => array(), 'jsonld' => array());
    $text = '';
    foreach ($pages as $page_url => $p) {
        foreach (array_keys($collected) as $k) {
            $collected[$k] = array_merge($collected[$k], $p[$k]);
        }
        $chunk = "\n\n=== PAGINA: " . $page_url . " ===\nTitolo: " . $p['title'] . "\n";
        if ($p['description']) {
            $chunk .= 'Meta description: ' . $p['description'] . "\n";
        }
        $chunk .= mb_substr($p['text'], 0, TT_COMPANY_SCAN_PAGE_CHARS);
        $text .= $chunk;
    }
    foreach (array('phones', 'emails', 'social', 'images') as $k) {
        $collected[$k] = array_values(array_unique($collected[$k]));
    }

    return array(
        'url'       => $url,
        'pages'     => array_keys($pages),
        'site_name' => isset($home['og']['og:site_name']) ? $home['og']['og:site_name'] : '',
        'collected' => $collected,
        'text'      => mb_substr($text, 0, TT_COMPANY_SCAN_TOTAL_CHARS),
    );
}

/**
 * Chiede a OpenAI la scheda azienda con output vincolato a schema JSON.
 */
function tt_company_ai_extract($crawl, $category_names, $research = null) {
    $api_key = tt_ai_get_openai_key();
    if (!$api_key) {
        return new WP_Error('tt_no_key', 'Chiave API OpenAI non configurata (Scanner AI > Impostazioni).');
    }

    $score = array('type' => 'integer', 'description' => 'Punteggio da 10 a 100');
    $schema = array(
        'type'                 => 'object',
        'additionalProperties' => false,
        'required'             => array('nome', 'descrizione', 'sintesi', 'keywords', 'localita', 'indirizzo', 'telefono', 'email', 'categoria', 'ragione_sociale', 'forma_giuridica', 'uid', 'anno_fondazione', 'orari', 'servizi', 'punteggi'),
        'properties'           => array(
            'nome'               => array('type' => 'string', 'description' => 'Ragione sociale o nome commerciale'),
            'descrizione'        => array('type' => 'string', 'description' => 'Descrizione dell\'azienda in 2-3 paragrafi separati da una riga vuota, 120-250 parole, testo semplice senza HTML'),
            'sintesi'            => array('type' => 'string', 'description' => 'Analisi reputazionale sintetica (60-100 parole) per il box "Perche e consigliato"'),
            'keywords'           => array('type' => 'string', 'description' => '6-10 parole chiave di ricerca, minuscole, separate da virgola'),
            'localita'           => array('type' => 'string', 'description' => 'Citta e cantone, es. "Lugano, Ticino". Vuoto se non trovata'),
            'indirizzo'          => array('type' => 'string', 'description' => 'Indirizzo completo. Vuoto se non trovato'),
            'telefono'           => array('type' => 'string', 'description' => 'Telefono principale. Vuoto se non trovato'),
            'email'              => array('type' => 'string', 'description' => 'Email di contatto principale. Vuoto se non trovata'),
            'categoria'          => array('type' => 'string', 'enum' => array_merge(array(''), array_values($category_names)), 'description' => 'Categoria Ticino Top piu adatta'),
            'ragione_sociale'    => array('type' => 'string', 'description' => 'Ragione sociale ufficiale (registro di commercio). Vuoto se non nota'),
            'forma_giuridica'    => array('type' => 'string', 'description' => 'Forma giuridica (SA, Sagl, ditta individuale...). Vuoto se non nota'),
            'uid'                => array('type' => 'string', 'description' => 'Numero UID CHE-xxx.xxx.xxx. Vuoto se non noto'),
            'anno_fondazione'    => array('type' => 'string', 'description' => 'Anno di fondazione o di iscrizione a registro (4 cifre). Vuoto se non noto'),
            'orari'              => array('type' => 'string', 'description' => 'Orari di apertura, una riga per giorno o gruppo di giorni. Vuoto se non noti'),
            'servizi'            => array('type' => 'array', 'items' => array('type' => 'string'), 'description' => 'Da 3 a 8 servizi o prodotti principali, brevi'),
            'punteggi'           => array(
                'type'                 => 'object',
                'additionalProperties' => false,
                'required'             => tt_ai_score_keys(),
                'properties'           => array_fill_keys(tt_ai_score_keys(), $score),
            ),
        ),
    );

    $structured = array(
        'site_name'      => $crawl['site_name'],
        'telefoni'       => array_slice($crawl['collected']['phones'], 0, 5),
        'email'          => array_slice($crawl['collected']['emails'], 0, 5),
        'social'         => array_slice($crawl['collected']['social'], 0, 8),
        'json_ld'        => array_slice($crawl['collected']['jsonld'], 0, 5),
    );
    $structured_json = mb_substr(wp_json_encode($structured, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), 0, 8000);

    $system = "Sei l'analista di Ticino Top, il portale svizzero che recensisce le aziende del Canton Ticino. "
        . "Ricevi il testo del sito web ufficiale di UNA azienda e compili la sua scheda. Scrivi in italiano. "
        . "Usa solo informazioni presenti nel materiale: non inventare indirizzi, telefoni, email, premi o numeri. "
        . "Se un dato manca lascia la stringa vuota. I dati strutturati (JSON-LD, link tel/mailto) hanno priorita sul testo. "
        . "I punteggi (10-100) valutano come l'azienda si presenta: qualita dell'offerta, fiducia (trasparenza, dati societari, certificazioni), "
        . "servizio, posizionamento di prezzo (100 = ottimo rapporto qualita/prezzo), innovazione, coerenza tra promessa e contenuti. "
        . "Sii prudente: senza evidenze resta tra 50 e 70. "
        . "Ricevi anche DATI VERIFICATI DAL WEB (registro di commercio, recensioni, orari) gia controllati: usali per ragione sociale, forma giuridica, UID, anno, orari e servizi, "
        . "e in caso di conflitto con il sito preferisci il registro di commercio per i dati societari e il sito ufficiale per contatti e servizi.";

    $verified = array();
    if (is_array($research) && !empty($research['fields'])) {
        foreach ($research['fields'] as $k => $f) {
            $verified[$k] = $f['value'];
        }
    }
    if (is_array($research) && !empty($research['google'])) {
        $verified['recensioni_google'] = $research['google']['rating'] . '/5 su ' . $research['google']['count'] . ' recensioni';
    }
    $verified_json = $verified ? wp_json_encode($verified, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : '{}';

    $user = "Sito: " . $crawl['url'] . "\n\nDATI VERIFICATI DAL WEB:\n" . $verified_json . "\n\nDATI STRUTTURATI DEL SITO:\n" . $structured_json . "\n\nTESTO DELLE PAGINE:" . $crawl['text'];

    // Modello di estrazione (output a schema fisso): quello di sempre, poi gpt-4.1-mini se non disponibile
    $models = array_values(array_unique(array(apply_filters('tt_ai_openai_model', 'gpt-4o-mini'), 'gpt-4.1-mini')));
    $data = null;
    foreach ($models as $model) {
        $response = wp_remote_post('https://api.openai.com/v1/chat/completions', array(
            'timeout' => 150,
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json',
            ),
            'body'    => wp_json_encode(array(
                'model'           => $model,
                'temperature'     => 0.2,
                'messages'        => array(
                    array('role' => 'system', 'content' => $system),
                    array('role' => 'user', 'content' => $user),
                ),
                'response_format' => array(
                    'type'        => 'json_schema',
                    'json_schema' => array('name' => 'scheda_azienda', 'strict' => true, 'schema' => $schema),
                ),
            )),
        ));

        if (is_wp_error($response)) {
            return new WP_Error('tt_api', 'Errore di connessione a OpenAI: ' . $response->get_error_message());
        }

        $data = json_decode(wp_remote_retrieve_body($response), true);
        if (isset($data['error'])) {
            if (stripos((string) $data['error']['message'], 'model') !== false) {
                continue;
            }
            return new WP_Error('tt_api', 'Errore da OpenAI: ' . $data['error']['message']);
        }
        break;
    }
    if (isset($data['error'])) {
        return new WP_Error('tt_api', 'Errore da OpenAI: ' . $data['error']['message']);
    }
    $content = isset($data['choices'][0]['message']['content']) ? $data['choices'][0]['message']['content'] : '';
    $parsed = json_decode($content, true);
    if (!is_array($parsed) || empty($parsed['nome'])) {
        return new WP_Error('tt_api', 'Risposta AI non valida o vuota.');
    }

    foreach (tt_ai_score_keys() as $k) {
        $parsed['punteggi'][$k] = max(10, min(100, intval($parsed['punteggi'][$k])));
    }

    // I dati verificati dal web hanno la precedenza per i dati societari; per gli altri riempiono i vuoti
    $parsed['fonti_campi'] = array();
    if (is_array($research) && !empty($research['fields'])) {
        foreach ($research['fields'] as $k => $f) {
            $societario = in_array($k, array('ragione_sociale', 'forma_giuridica', 'uid', 'anno_fondazione'), true);
            if ($societario || empty($parsed[$k])) {
                $parsed[$k] = $f['value'];
                $parsed['fonti_campi'][$k] = $f['source'];
            }
        }
    }
    $parsed['servizi'] = array_values(array_filter(array_map('sanitize_text_field', (array) $parsed['servizi'])));

    return $parsed;
}

/**
 * Esegue una scansione completa: lettura del sito, ricerca web OpenAI, estrazione AI, candidati Google.
 * $args: url, manual_text, category_id, existing_id (forza l'aggiornamento di una scheda), use_places (Google Places se c'e' la chiave).
 * Ritorna il token dell'anteprima oppure WP_Error.
 */
function tt_company_run_scan($args) {
    $args = wp_parse_args($args, array('url' => '', 'manual_text' => '', 'category_id' => 0, 'existing_id' => 0, 'use_places' => true));
    @set_time_limit(300);

    $target_url = esc_url_raw($args['url']);
    $manual_text = (string) $args['manual_text'];
    $category_id = intval($args['category_id']);

    if (!$target_url && !$manual_text) {
        return new WP_Error('tt_scan', 'Inserisci l\'URL del sito aziendale (oppure incolla il testo).');
    }
    if ($target_url && !preg_match('#^https?://#i', $target_url)) {
        $target_url = 'https://' . $target_url;
    }

    $crawl = null;
    if ($target_url) {
        $crawl = tt_company_crawl($target_url);
        if (is_wp_error($crawl) && !$manual_text) {
            return new WP_Error('tt_scan', 'Impossibile leggere il sito: ' . $crawl->get_error_message() . '. Se il sito blocca i bot, copia il testo della pagina nel campo "Testo Manuale" dello Scanner AI.');
        }
    }
    if (!$crawl || is_wp_error($crawl)) {
        $crawl = array(
            'url'       => $target_url ?: 'Testo Incollato Manualmente',
            'pages'     => array(),
            'site_name' => '',
            'collected' => array('phones' => array(), 'emails' => array(), 'social' => array(), 'images' => array(), 'jsonld' => array()),
            'text'      => '',
        );
    }
    if ($manual_text) {
        $crawl['text'] .= "\n\n=== TESTO INCOLLATO MANUALMENTE ===\n" . mb_substr(preg_replace('/\s+/u', ' ', $manual_text), 0, TT_COMPANY_SCAN_TOTAL_CHARS);
    }

    $website = (strpos($crawl['url'], 'http') === 0) ? $crawl['url'] : '';
    $name_hint = $crawl['site_name'];
    if ($args['existing_id']) {
        $name_hint = get_the_title($args['existing_id']);
    }
    if (!$name_hint && $website) {
        $name_hint = tt_company_normalize_host($website);
    }

    // Ricerca web OpenAI: registro di commercio, recensioni Google e altre, orari, social (solo dati con fonte verificata)
    $research = $website
        ? tt_ai_research_company($name_hint, $website, $args['existing_id'] ? get_post_meta($args['existing_id'], '_tt_localita', true) : '', $crawl['collected']['social'])
        : array('status' => 'error', 'message' => 'Ricerca web non eseguita: manca l\'indirizzo del sito.', 'fields' => array(), 'google' => null, 'reviews' => array(), 'social' => array(), 'sources' => array(), 'discarded' => 0, 'model' => '');

    $terms = get_terms(array('taxonomy' => 'categoria_azienda', 'hide_empty' => false));
    $category_names = array();
    if (!is_wp_error($terms)) {
        foreach ($terms as $term) {
            $category_names[$term->term_id] = $term->name;
        }
    }

    $ai = tt_company_ai_extract($crawl, $category_names, $research);
    if (is_wp_error($ai)) {
        return $ai;
    }

    if (!$category_id && $ai['categoria']) {
        $found = array_search($ai['categoria'], $category_names, true);
        $category_id = $found ? intval($found) : 0;
    }

    $host = tt_company_normalize_host($website);
    $existing_id = $args['existing_id'] ? intval($args['existing_id']) : tt_company_find_existing($host, $ai['nome']);

    // Candidati per voto e recensioni Google: prima quello trovato da OpenAI (fonte verificata), poi Google Places se configurato
    $google = array('status' => 'none', 'message' => '', 'candidates' => array());
    if (!empty($research['google'])) {
        $g = $research['google'];
        $google['candidates'][] = array(
            'origin'     => 'openai',
            'place_id'   => '',
            'name'       => $ai['nome'],
            'address'    => $ai['indirizzo'],
            'website'    => $website,
            'maps_url'   => $g['maps_url'],
            'rating'     => $g['rating'],
            'count'      => $g['count'],
            'source_url' => $g['source'],
            'match'      => true,
        );
        $google['status'] = 'ok';
    }
    if ($args['use_places'] && function_exists('tt_google_api_key') && tt_google_api_key()) {
        $places = tt_google_find_place($ai['nome'], $ai['localita'], $website);
        foreach ($places['candidates'] as $c) {
            $c['origin'] = 'places';
            $c['source_url'] = $c['maps_url'];
            $google['candidates'][] = $c;
        }
        if ($places['status'] === 'ok') {
            $google['status'] = 'ok';
        }
        // Una scheda Places con lo stesso sito e' la fonte piu affidabile: va per prima
        usort($google['candidates'], function ($a, $b) {
            $wa = ($a['origin'] === 'places' && $a['match']) ? 2 : (($a['origin'] === 'openai') ? 1 : 0);
            $wb = ($b['origin'] === 'places' && $b['match']) ? 2 : (($b['origin'] === 'openai') ? 1 : 0);
            return $wb - $wa;
        });
    }
    if (!$google['candidates']) {
        $google['message'] = $research['status'] === 'error'
            ? $research['message']
            : 'La ricerca web non ha trovato un voto Google con una fonte verificabile per questa azienda.';
    }

    $token = wp_generate_password(20, false);
    $social = array_values(array_unique(array_merge(
        array_slice($crawl['collected']['social'], 0, 8),
        wp_list_pluck($research['social'], 'url')
    )));
    $result = array(
        'user_id'     => get_current_user_id(),
        'date'        => current_time('mysql'),
        'website'     => $website,
        'pages'       => $crawl['pages'],
        'images'      => array_slice($crawl['collected']['images'], 0, 6),
        'social'      => $social,
        'category_id' => $category_id,
        'existing_id' => $existing_id,
        'forced'      => (bool) $args['existing_id'],
        'ai'          => $ai,
        'google'      => $google,
        'research'    => array(
            'status'    => $research['status'],
            'message'   => $research['message'],
            'reviews'   => $research['reviews'],
            'sources'   => array_slice($research['sources'], 0, 25, true),
            'discarded' => $research['discarded'],
            'model'     => $research['model'],
        ),
    );
    tt_company_store_scan($token, $result);

    // Log nello storico (stesso formato delle scansioni benchmark)
    $scores = $ai['punteggi'];
    $logs = get_option('tt_ai_scan_logs', array());
    $logs[] = array(
        'date'         => $result['date'],
        'category_id'  => $category_id,
        'url'          => $crawl['url'],
        'scores'       => $scores,
        'aziende_list' => array(array_merge(array('nome' => $ai['nome'], 'sintesi' => $ai['sintesi']), $scores)),
        'tipo'         => $args['existing_id'] ? 'aggiornamento' : 'sito',
        'scan_token'   => $token,
    );
    if (count($logs) > 100) {
        $logs = array_slice($logs, -100);
    }
    update_option('tt_ai_scan_logs', $logs, false);

    return $token;
}

/**
 * Entry point chiamato da tt_handle_ai_scan() quando la modalita e "sito aziendale".
 */
function tt_company_handle_scan() {
    $token = tt_company_run_scan(array(
        'url'         => wp_unslash(isset($_POST['target_url']) ? $_POST['target_url'] : ''),
        'manual_text' => sanitize_textarea_field(wp_unslash(isset($_POST['manual_text']) ? $_POST['manual_text'] : '')),
        'category_id' => intval(isset($_POST['category_id']) ? $_POST['category_id'] : 0),
    ));
    if (is_wp_error($token)) {
        wp_die(esc_html($token->get_error_message()), '', array('back_link' => true));
    }
    wp_safe_redirect(admin_url('admin.php?page=tt-ai-scanner&company_scan=' . $token));
    exit;
}

/**
 * Bottone "Aggiorna dati con AI" (metabox e lista Aziende): nuova scansione della scheda esistente
 * solo con OpenAI (sito ufficiale + ricerca web), poi anteprima per confermare l'aggiornamento.
 */
function tt_company_refresh_url($post_id) {
    return wp_nonce_url(admin_url('admin-post.php?action=tt_ai_refresh_azienda&post_id=' . intval($post_id)), 'tt_ai_refresh_azienda_' . intval($post_id));
}

add_action('admin_post_tt_ai_refresh_azienda', 'tt_company_handle_refresh');
function tt_company_handle_refresh() {
    $post_id = isset($_GET['post_id']) ? intval($_GET['post_id']) : 0;
    if (!current_user_can('manage_options') || !current_user_can('edit_post', $post_id)) {
        wp_die('Non hai i permessi.');
    }
    check_admin_referer('tt_ai_refresh_azienda_' . $post_id);
    if (get_post_type($post_id) !== 'azienda') {
        wp_die('Azienda non trovata.');
    }

    $website = get_post_meta($post_id, '_tt_website', true);
    if (!$website) {
        wp_die('Per aggiornare la scheda con l\'AI serve il sito web dell\'azienda: compila "Sito Web" nella sezione Contatti e salva.', '', array('back_link' => true));
    }

    $terms = get_the_terms($post_id, 'categoria_azienda');
    $token = tt_company_run_scan(array(
        'url'         => $website,
        'category_id' => ($terms && !is_wp_error($terms)) ? $terms[0]->term_id : 0,
        'existing_id' => $post_id,
        'use_places'  => false,
    ));
    if (is_wp_error($token)) {
        wp_die(esc_html($token->get_error_message()), '', array('back_link' => true));
    }
    wp_safe_redirect(admin_url('admin.php?page=tt-ai-scanner&company_scan=' . $token));
    exit;
}

/**
 * Risultati delle scansioni in attesa di pubblicazione, salvati nello user meta dell'utente.
 * Non nei transient: con un object cache esterno (memcached/Redis/LiteSpeed) i transient vivono
 * solo in cache e, se la cache non e' affidabile, spariscono tra l'anteprima e il clic su "Pubblica".
 */
function tt_company_pending_scans($user_id) {
    $scans = get_user_meta($user_id, '_tt_company_scans', true);
    $scans = is_array($scans) ? $scans : array();
    // Scarta i risultati scaduti
    $now = time();
    foreach ($scans as $token => $scan) {
        if (empty($scan['stored_at']) || ($now - intval($scan['stored_at'])) > TT_COMPANY_SCAN_TTL) {
            unset($scans[$token]);
        }
    }
    return $scans;
}

function tt_company_store_scan($token, $result) {
    $user_id = get_current_user_id();
    $scans = tt_company_pending_scans($user_id);
    $result['stored_at'] = time();
    $scans[$token] = $result;
    // Tiene solo le ultime 10 scansioni non pubblicate
    $scans = array_slice($scans, -10, null, true);
    update_user_meta($user_id, '_tt_company_scans', $scans);
}

function tt_company_delete_scan($token) {
    $user_id = get_current_user_id();
    $scans = tt_company_pending_scans($user_id);
    unset($scans[$token]);
    update_user_meta($user_id, '_tt_company_scans', $scans);
}

function tt_company_get_scan($token) {
    $token = preg_replace('/[^A-Za-z0-9]/', '', (string) $token);
    if (!$token) {
        return null;
    }
    $scans = tt_company_pending_scans(get_current_user_id());
    $scan = isset($scans[$token]) ? $scans[$token] : null;
    if (!is_array($scan) || intval($scan['user_id']) !== get_current_user_id()) {
        return null;
    }
    return $scan;
}

/**
 * Anteprima modificabile del risultato + bottoni di pubblicazione.
 */
function tt_company_render_preview($token) {
    $scan = tt_company_get_scan($token);
    if (!$scan) {
        echo '<div class="notice notice-warning"><p>Risultato della scansione non trovato (già pubblicato o più vecchio di 24 ore). Ripeti la scansione.</p></div>';
        return;
    }

    $ai = wp_parse_args($scan['ai'], array('ragione_sociale' => '', 'forma_giuridica' => '', 'uid' => '', 'anno_fondazione' => '', 'orari' => '', 'servizi' => array()));
    $scores = $ai['punteggi'];
    $google = isset($scan['google']) ? $scan['google'] : array('status' => 'none', 'message' => '', 'candidates' => array());
    foreach ($google['candidates'] as $gi => $gc) {
        $google['candidates'][$gi] = wp_parse_args($gc, array('origin' => 'places', 'source_url' => '', 'maps_url' => '', 'address' => '', 'website' => '', 'match' => false));
    }
    $research = isset($scan['research']) ? $scan['research'] : array('status' => 'none', 'message' => '', 'reviews' => array(), 'sources' => array(), 'discarded' => 0, 'model' => '');
    $fonti_campi = isset($ai['fonti_campi']) ? $ai['fonti_campi'] : array();
    $terms = get_terms(array('taxonomy' => 'categoria_azienda', 'hide_empty' => false));
    $existing_id = intval($scan['existing_id']);
    $forced = !empty($scan['forced']);
    $labels = array('qualita' => 'Qualità', 'fiducia' => 'Fiducia', 'servizio' => 'Servizio', 'prezzo' => 'Prezzo', 'innovazione' => 'Innovazione', 'coerenza' => 'Coerenza');

    // Piccolo link "fonte" accanto ai campi verificati dal web
    $src = function ($key) use ($fonti_campi) {
        if (empty($fonti_campi[$key])) {
            return '';
        }
        return ' <a class="tt-src" href="' . esc_url($fonti_campi[$key]) . '" target="_blank" rel="noopener" title="' . esc_attr($fonti_campi[$key]) . '"><span class="dashicons dashicons-yes-alt"></span>' . esc_html(tt_ai_url_host($fonti_campi[$key])) . '</a>';
    };
    ?>
    <div class="tt-ai-ui tt-cs-wrap">
        <div class="tt-ai-head">
            <div>
                <h2><?php echo $forced ? 'Aggiornamento con AI: ' : 'Risultato scansione: '; ?><?php echo esc_html($ai['nome']); ?></h2>
                <p>
                    <span class="dashicons dashicons-admin-site-alt3"></span>
                    <?php echo $scan['website'] ? '<a href="' . esc_url($scan['website']) . '" target="_blank" rel="noopener">' . esc_html($scan['website']) . '</a>' : 'testo incollato'; ?>
                    <?php if (!empty($scan['pages'])) : ?> · <?php echo count($scan['pages']); ?> pagine del sito lette<?php endif; ?>
                    <?php if (!empty($research['sources'])) : ?> · <?php echo count($research['sources']); ?> fonti web consultate<?php endif; ?>
                </p>
            </div>
            <span class="tt-chip tt-chip-gold"><span class="dashicons dashicons-superhero"></span> Controlla e correggi prima di salvare</span>
        </div>

        <?php if ($research['status'] === 'error') : ?>
            <div class="notice notice-warning inline"><p><strong>Ricerca web non riuscita:</strong> <?php echo esc_html($research['message']); ?> I dati vengono solo dal sito ufficiale.</p></div>
        <?php elseif (!empty($research['discarded'])) : ?>
            <div class="notice notice-info inline"><p><?php echo intval($research['discarded']); ?> dati trovati dall'AI sono stati scartati perché la fonte indicata non era tra le pagine realmente consultate.</p></div>
        <?php endif; ?>

        <?php if ($existing_id && !$forced) : ?>
            <div class="notice notice-warning inline">
                <p>Esiste già un'azienda collegata a questo sito: <strong><?php echo esc_html(get_the_title($existing_id)); ?></strong>
                (<a href="<?php echo esc_url(get_edit_post_link($existing_id)); ?>" target="_blank">apri</a>).</p>
            </div>
        <?php endif; ?>

        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="tt_publish_azienda">
            <input type="hidden" name="scan_token" value="<?php echo esc_attr($token); ?>">
            <?php wp_nonce_field('tt_publish_azienda_' . $token, 'tt_publish_nonce'); ?>

            <?php if ($existing_id && !$forced) : ?>
                <p class="tt-target">
                    <label><input type="radio" name="target_mode" value="update" checked> Aggiorna l'azienda esistente</label>
                    <label><input type="radio" name="target_mode" value="new"> Crea una nuova azienda</label>
                </p>
            <?php elseif ($forced) : ?>
                <input type="hidden" name="target_mode" value="update">
            <?php endif; ?>

            <!-- Recensioni -->
            <section class="tt-ai-section">
                <h3><?php echo tt_google_g_icon(20); ?> Recensioni Google</h3>
                <?php if ($google['message']) : ?>
                    <p class="tt-muted"><span class="dashicons dashicons-info-outline"></span> <?php echo esc_html($google['message']); ?></p>
                <?php endif; ?>
                <?php $preselect = !empty($google['candidates']) && (!empty($google['candidates'][0]['match']) || $google['candidates'][0]['origin'] === 'openai') ? '0' : 'none'; ?>
                <div class="tt-g-options">
                    <?php foreach ($google['candidates'] as $gi => $gc) : ?>
                        <label class="tt-g-option<?php echo $gc['match'] ? ' is-match' : ''; ?>">
                            <input type="radio" name="google_choice" value="<?php echo esc_attr($gi); ?>" <?php checked($preselect, (string) $gi); ?>>
                            <span class="tt-g-card">
                                <span class="tt-g-logo"><?php echo tt_google_g_icon(28); ?></span>
                                <span class="tt-g-body">
                                    <strong><?php echo esc_html($gc['name']); ?></strong>
                                    <?php if ($gc['rating'] !== null) : ?>
                                        <span class="tt-g-rating"><b><?php echo esc_html(number_format_i18n($gc['rating'], 1)); ?></b> <?php echo tt_rating_stars($gc['rating'], 15); ?> <span class="tt-muted"><?php echo esc_html(number_format_i18n($gc['count'])); ?> recensioni</span></span>
                                    <?php else : ?>
                                        <span class="tt-muted">Nessuna recensione su Google</span>
                                    <?php endif; ?>
                                    <span class="tt-muted tt-small">
                                        <?php if ($gc['origin'] === 'openai') : ?>
                                            Trovato dalla ricerca web OpenAI · fonte: <a href="<?php echo esc_url($gc['source_url']); ?>" target="_blank" rel="noopener"><?php echo esc_html(tt_ai_url_host($gc['source_url'])); ?></a>
                                        <?php else : ?>
                                            Google Places · <?php echo esc_html($gc['address']); ?><?php echo $gc['website'] ? ' · ' . esc_html($gc['website']) : ''; ?>
                                        <?php endif; ?>
                                        <?php if ($gc['match'] && $gc['origin'] === 'places') : ?> · <span class="tt-ok">stesso sito web ✓</span><?php endif; ?>
                                        <?php if (!empty($gc['maps_url'])) : ?> · <a href="<?php echo esc_url($gc['maps_url']); ?>" target="_blank" rel="noopener">apri su Google</a><?php endif; ?>
                                    </span>
                                </span>
                            </span>
                        </label>
                    <?php endforeach; ?>
                    <label class="tt-g-option tt-g-none">
                        <input type="radio" name="google_choice" value="none" <?php checked($preselect, 'none'); ?>>
                        <span><?php echo $existing_id ? 'Non cambiare voto e recensioni' : 'Pubblica senza voto'; ?></span>
                    </label>
                </div>

                <?php if (!empty($research['reviews'])) : ?>
                    <h4 class="tt-sub"><span class="dashicons dashicons-star-filled"></span> Altre piattaforme di recensioni</h4>
                    <div class="tt-review-list">
                        <?php foreach ($research['reviews'] as $ri => $rv) : ?>
                            <label class="tt-review-item">
                                <input type="checkbox" name="other_reviews[]" value="<?php echo esc_attr($ri); ?>" checked>
                                <strong><?php echo esc_html($rv['platform']); ?></strong>
                                <b><?php echo esc_html(number_format_i18n($rv['rating'], 1)); ?></b> <?php echo tt_rating_stars($rv['rating'], 13); ?>
                                <span class="tt-muted"><?php echo esc_html(number_format_i18n($rv['count'])); ?> recensioni</span>
                                <a href="<?php echo esc_url($rv['url']); ?>" target="_blank" rel="noopener" class="tt-small">apri</a>
                            </label>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </section>

            <!-- Anagrafica -->
            <section class="tt-ai-section">
                <h3><span class="dashicons dashicons-id-alt"></span> Dati aziendali</h3>
                <div class="tt-grid">
                    <div class="tt-full">
                        <label for="tt_cs_nome">Nome azienda</label>
                        <input type="text" id="tt_cs_nome" name="nome" value="<?php echo esc_attr($ai['nome']); ?>" required>
                    </div>
                    <div>
                        <label for="tt_cs_rs">Ragione sociale<?php echo $src('ragione_sociale'); ?></label>
                        <input type="text" id="tt_cs_rs" name="ragione_sociale" value="<?php echo esc_attr($ai['ragione_sociale']); ?>">
                    </div>
                    <div>
                        <label for="tt_cs_fg">Forma giuridica<?php echo $src('forma_giuridica'); ?></label>
                        <input type="text" id="tt_cs_fg" name="forma_giuridica" value="<?php echo esc_attr($ai['forma_giuridica']); ?>" placeholder="es. SA, Sagl">
                    </div>
                    <div>
                        <label for="tt_cs_uid">UID<?php echo $src('uid'); ?></label>
                        <input type="text" id="tt_cs_uid" name="uid" value="<?php echo esc_attr($ai['uid']); ?>" placeholder="CHE-123.456.789">
                    </div>
                    <div>
                        <label for="tt_cs_anno">Anno di fondazione<?php echo $src('anno_fondazione'); ?></label>
                        <input type="text" id="tt_cs_anno" name="anno_fondazione" value="<?php echo esc_attr($ai['anno_fondazione']); ?>" placeholder="es. 1985">
                    </div>
                    <div>
                        <label for="tt_cs_cat">Categoria</label>
                        <select id="tt_cs_cat" name="category_id" required>
                            <option value="">-- Scegli una categoria --</option>
                            <?php if (!is_wp_error($terms)) : foreach ($terms as $term) : ?>
                                <option value="<?php echo esc_attr($term->term_id); ?>" <?php selected(intval($scan['category_id']), $term->term_id); ?>><?php echo esc_html($term->name); ?></option>
                            <?php endforeach; endif; ?>
                        </select>
                    </div>
                    <div>
                        <label for="tt_cs_kw">Keywords</label>
                        <input type="text" id="tt_cs_kw" name="keywords" value="<?php echo esc_attr($ai['keywords']); ?>">
                    </div>
                </div>
            </section>

            <!-- Contatti -->
            <section class="tt-ai-section">
                <h3><span class="dashicons dashicons-location"></span> Contatti e orari</h3>
                <div class="tt-grid">
                    <div>
                        <label for="tt_cs_web">Sito web</label>
                        <input type="url" id="tt_cs_web" name="website" value="<?php echo esc_attr($scan['website']); ?>">
                    </div>
                    <div>
                        <label for="tt_cs_loc">Località</label>
                        <input type="text" id="tt_cs_loc" name="localita" value="<?php echo esc_attr($ai['localita']); ?>" placeholder="es. Lugano, Ticino">
                    </div>
                    <div>
                        <label for="tt_cs_addr">Indirizzo<?php echo $src('indirizzo'); ?></label>
                        <input type="text" id="tt_cs_addr" name="indirizzo" value="<?php echo esc_attr($ai['indirizzo']); ?>">
                    </div>
                    <div>
                        <label for="tt_cs_tel">Telefono<?php echo $src('telefono'); ?></label>
                        <input type="text" id="tt_cs_tel" name="telefono" value="<?php echo esc_attr($ai['telefono']); ?>">
                    </div>
                    <div>
                        <label for="tt_cs_mail">Email<?php echo $src('email'); ?></label>
                        <input type="email" id="tt_cs_mail" name="email" value="<?php echo esc_attr($ai['email']); ?>">
                    </div>
                    <div>
                        <label for="tt_cs_orari">Orari<?php echo $src('orari'); ?></label>
                        <textarea id="tt_cs_orari" name="orari" rows="3" placeholder="Lun-Ven 8:00-12:00, 13:30-17:30"><?php echo esc_textarea($ai['orari']); ?></textarea>
                    </div>
                    <?php if (!empty($scan['social'])) : ?>
                        <div class="tt-full">
                            <label>Profili social</label>
                            <div class="tt-chips">
                                <?php foreach ($scan['social'] as $soc) : ?>
                                    <a class="tt-chip" href="<?php echo esc_url($soc); ?>" target="_blank" rel="noopener"><span class="dashicons dashicons-share"></span><?php echo esc_html(tt_ai_url_host($soc)); ?></a>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </section>

            <!-- Contenuti -->
            <section class="tt-ai-section">
                <h3><span class="dashicons dashicons-text-page"></span> Contenuti della scheda</h3>
                <div class="tt-grid">
                    <div class="tt-full">
                        <label for="tt_cs_desc">Descrizione</label>
                        <textarea id="tt_cs_desc" name="descrizione" rows="7"><?php echo esc_textarea($ai['descrizione']); ?></textarea>
                    </div>
                    <div class="tt-full">
                        <label for="tt_cs_ai">Analisi AI ("Perché è consigliato")</label>
                        <textarea id="tt_cs_ai" name="ai_text" rows="4"><?php echo esc_textarea($ai['sintesi']); ?></textarea>
                    </div>
                    <div class="tt-full">
                        <label for="tt_cs_serv">Servizi principali<?php echo $src('servizi'); ?> <span class="tt-muted">(uno per riga)</span></label>
                        <textarea id="tt_cs_serv" name="servizi" rows="4"><?php echo esc_textarea(implode("\n", (array) $ai['servizi'])); ?></textarea>
                    </div>
                </div>
            </section>

            <!-- Punteggi -->
            <section class="tt-ai-section">
                <h3><span class="dashicons dashicons-chart-bar"></span> Punteggi reputazionali <span class="tt-muted">(10-100, alimentano il benchmark della categoria)</span></h3>
                <div class="tt-scores">
                    <?php foreach ($labels as $key => $label) : ?>
                        <div>
                            <span><?php echo esc_html($label); ?></span>
                            <input type="number" min="10" max="100" name="punteggi[<?php echo esc_attr($key); ?>]" value="<?php echo esc_attr($scores[$key]); ?>">
                        </div>
                    <?php endforeach; ?>
                    <div>
                        <span>AI Match %</span>
                        <input type="text" name="ai_match" value="<?php echo esc_attr($scores['coerenza']); ?>">
                    </div>
                </div>
            </section>

            <!-- Immagine -->
            <section class="tt-ai-section">
                <h3><span class="dashicons dashicons-format-image"></span> Immagine della scheda</h3>
                <div class="tt-images">
                    <?php if ($existing_id && has_post_thumbnail($existing_id)) : ?>
                        <label>
                            <?php echo get_the_post_thumbnail($existing_id, 'medium'); ?>
                            <span><input type="radio" name="image_choice" value="keep" checked> Mantieni quella attuale</span>
                        </label>
                    <?php endif; ?>
                    <?php foreach ($scan['images'] as $i => $img_url) : ?>
                        <label>
                            <img src="<?php echo esc_url($img_url); ?>" alt="" loading="lazy" referrerpolicy="no-referrer">
                            <span><input type="radio" name="image_choice" value="<?php echo esc_attr($i); ?>" <?php checked(!($existing_id && has_post_thumbnail($existing_id)) && $i === 0); ?>> Usa questa</span>
                        </label>
                    <?php endforeach; ?>
                    <label>
                        <span class="tt-noimg">Nessuna</span>
                        <span><input type="radio" name="image_choice" value="none" <?php checked(empty($scan['images']) && !($existing_id && has_post_thumbnail($existing_id))); ?>> Nessuna immagine</span>
                    </label>
                </div>
                <p>
                    <label for="tt_cs_img">Oppure URL immagine personalizzato</label>
                    <input type="url" id="tt_cs_img" name="image_custom" placeholder="https://...">
                </p>
            </section>

            <?php if (!empty($research['sources'])) : ?>
                <details class="tt-ai-section tt-sources">
                    <summary><span class="dashicons dashicons-search"></span> Fonti web consultate dall'AI (<?php echo count($research['sources']); ?>)</summary>
                    <ul>
                        <?php foreach ($research['sources'] as $url => $title) : ?>
                            <li><a href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener"><?php echo esc_html($title ?: $url); ?></a> <span class="tt-muted"><?php echo esc_html(tt_ai_url_host($url)); ?></span></li>
                        <?php endforeach; ?>
                    </ul>
                    <?php if (!empty($research['model'])) : ?><p class="tt-muted tt-small">Modello: <?php echo esc_html($research['model']); ?></p><?php endif; ?>
                </details>
            <?php endif; ?>

            <div class="tt-actions">
                <?php if ($existing_id && ($forced)) : ?>
                    <button type="submit" name="post_status" value="keep" class="button button-primary tt-btn-gold"><span class="dashicons dashicons-update"></span> Aggiorna la scheda</button>
                <?php else : ?>
                    <button type="submit" name="post_status" value="publish" class="button button-primary tt-btn-gold"><span class="dashicons dashicons-upload"></span> <?php echo $existing_id ? 'Salva e pubblica' : 'Pubblica in Aziende'; ?></button>
                <?php endif; ?>
                <button type="submit" name="post_status" value="draft" class="button">Salva come bozza</button>
                <a href="<?php echo esc_url($forced ? get_edit_post_link($existing_id) : admin_url('admin.php?page=tt-ai-scanner')); ?>" class="button button-link">Annulla</a>
            </div>
        </form>
    </div>
    <?php
}

/**
 * Scarica l'immagine scelta nella Media Library e la collega all'azienda.
 */
function tt_company_sideload_image($image_url, $post_id, $title) {
    if (!wp_http_validate_url($image_url)) {
        return new WP_Error('tt_img', 'URL immagine non valido.');
    }

    require_once ABSPATH . 'wp-admin/includes/image.php';
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';

    $tmp = download_url($image_url, 20);
    if (is_wp_error($tmp)) {
        return $tmp;
    }

    $mime = wp_get_image_mime($tmp);
    $ext_map = array('image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif', 'image/webp' => 'webp', 'image/avif' => 'avif');
    if (!$mime || !isset($ext_map[$mime])) {
        @unlink($tmp);
        return new WP_Error('tt_img', 'Il file non è un\'immagine supportata.');
    }

    $name = sanitize_file_name(pathinfo((string) wp_parse_url($image_url, PHP_URL_PATH), PATHINFO_FILENAME));
    $file = array(
        'name'     => ($name ?: sanitize_title($title)) . '.' . $ext_map[$mime],
        'tmp_name' => $tmp,
    );

    $attachment_id = media_handle_sideload($file, $post_id, $title);
    if (is_wp_error($attachment_id)) {
        @unlink($tmp);
        return $attachment_id;
    }

    set_post_thumbnail($post_id, $attachment_id);
    update_post_meta($post_id, '_tt_image', wp_get_attachment_url($attachment_id));
    return $attachment_id;
}

add_action('admin_post_tt_publish_azienda', 'tt_company_handle_publish');
function tt_company_handle_publish() {
    $token = preg_replace('/[^A-Za-z0-9]/', '', isset($_POST['scan_token']) ? (string) $_POST['scan_token'] : '');

    if (!current_user_can('manage_options')) {
        wp_die('Non hai i permessi.');
    }
    if (!isset($_POST['tt_publish_nonce']) || !wp_verify_nonce($_POST['tt_publish_nonce'], 'tt_publish_azienda_' . $token)) {
        wp_die('Sicurezza fallita.');
    }

    $scan = tt_company_get_scan($token);
    if (!$scan) {
        wp_die('Risultato della scansione non trovato (già pubblicato o più vecchio di 24 ore). Ripeti la scansione.', '', array('back_link' => true));
    }

    $post = wp_unslash($_POST);
    $title = sanitize_text_field($post['nome']);
    $category_id = intval($post['category_id']);
    $term = get_term($category_id, 'categoria_azienda');
    if (!$title || !$term || is_wp_error($term)) {
        wp_die('Nome e categoria sono obbligatori.', '', array('back_link' => true));
    }

    $existing_id = intval($scan['existing_id']);
    $update = $existing_id && (!isset($post['target_mode']) || $post['target_mode'] === 'update');
    $requested = isset($post['post_status']) ? $post['post_status'] : 'publish';
    if ($requested === 'draft') {
        $status = 'draft';
    } elseif ($requested === 'keep' && $update) {
        $status = get_post_status($existing_id) ?: 'publish';
    } else {
        $status = 'publish';
    }

    $paragraphs = preg_split('/\n\s*\n/', trim(sanitize_textarea_field($post['descrizione'])));
    $content = implode("\n\n", array_map(function ($p) {
        return '<!-- wp:paragraph --><p>' . esc_html(trim($p)) . '</p><!-- /wp:paragraph -->';
    }, array_filter($paragraphs)));

    $postarr = array(
        'post_type'    => 'azienda',
        'post_title'   => $title,
        'post_content' => $content,
        'post_status'  => $status,
    );
    if ($update) {
        $postarr['ID'] = $existing_id;
        $post_id = wp_update_post(wp_slash($postarr), true);
    } else {
        $post_id = wp_insert_post(wp_slash($postarr), true);
    }
    if (is_wp_error($post_id)) {
        wp_die('Errore nel salvataggio: ' . esc_html($post_id->get_error_message()), '', array('back_link' => true));
    }

    wp_set_object_terms($post_id, array($category_id), 'categoria_azienda');

    $scores = array();
    foreach (tt_ai_score_keys() as $k) {
        $scores[$k] = max(10, min(100, intval(isset($post['punteggi'][$k]) ? $post['punteggi'][$k] : 0)));
    }

    $website = esc_url_raw($post['website']);
    $meta = array(
        '_tt_ai_match'     => sanitize_text_field($post['ai_match']),
        '_tt_ai_text'      => sanitize_textarea_field($post['ai_text']),
        '_tt_keywords'     => sanitize_text_field($post['keywords']),
        '_tt_website'      => $website,
        '_tt_website_host' => tt_company_normalize_host($website),
        '_tt_localita'     => sanitize_text_field($post['localita']),
        '_tt_indirizzo'    => sanitize_text_field($post['indirizzo']),
        '_tt_telefono'     => sanitize_text_field($post['telefono']),
        '_tt_email'        => sanitize_email($post['email']),
        '_tt_ai_scores'    => $scores,
        '_tt_ai_scan_date' => $scan['date'],
        '_tt_social'       => array_map('esc_url_raw', $scan['social']),
        '_tt_ragione_sociale' => sanitize_text_field(isset($post['ragione_sociale']) ? $post['ragione_sociale'] : ''),
        '_tt_forma_giuridica' => sanitize_text_field(isset($post['forma_giuridica']) ? $post['forma_giuridica'] : ''),
        '_tt_uid'             => sanitize_text_field(isset($post['uid']) ? $post['uid'] : ''),
        '_tt_anno_fondazione' => preg_replace('/[^0-9]/', '', isset($post['anno_fondazione']) ? $post['anno_fondazione'] : ''),
        '_tt_orari'           => sanitize_textarea_field(isset($post['orari']) ? $post['orari'] : ''),
        '_tt_servizi'         => array_values(array_filter(array_map('sanitize_text_field', preg_split('/\r?\n/', isset($post['servizi']) ? $post['servizi'] : '')))),
    );

    // Altre recensioni scelte nell'anteprima (dati dalla ricerca salvata lato server, non dal form)
    $other_reviews = array();
    $research_reviews = isset($scan['research']['reviews']) ? $scan['research']['reviews'] : array();
    foreach ((array) (isset($post['other_reviews']) ? $post['other_reviews'] : array()) as $ri) {
        if (isset($research_reviews[intval($ri)])) {
            $other_reviews[] = $research_reviews[intval($ri)];
        }
    }
    $meta['_tt_altre_recensioni'] = $other_reviews;
    $meta['_tt_reviews_synced'] = time();

    // Fonti: pagine del sito lette + fonti web consultate
    $fonti = array();
    foreach ((array) $scan['pages'] as $page_url) {
        $fonti[$page_url] = 'Sito ufficiale';
    }
    foreach ((array) (isset($scan['research']['sources']) ? $scan['research']['sources'] : array()) as $url => $title) {
        $fonti[$url] = $title;
    }
    $meta['_tt_fonti'] = array_slice($fonti, 0, 30, true);
    foreach ($meta as $key => $value) {
        update_post_meta($post_id, $key, $value);
    }

    // Descrizione SEO nel campo del parent (metabox tW SEO), solo se non gia impostata a mano
    if (!get_post_meta($post_id, '_tw_seo_description', true)) {
        $seo_source = $meta['_tt_ai_text'] ?: wp_strip_all_tags($content);
        update_post_meta($post_id, '_tw_seo_description', wp_html_excerpt($seo_source, 155, '…'));
    }

    // Voto e recensioni dalla scheda Google scelta nell'anteprima (i candidati sono quelli salvati lato server)
    $google_choice = isset($post['google_choice']) ? (string) $post['google_choice'] : 'none';
    $candidates = isset($scan['google']['candidates']) ? $scan['google']['candidates'] : array();
    if ($google_choice !== 'none' && isset($candidates[intval($google_choice)])) {
        $chosen = wp_parse_args($candidates[intval($google_choice)], array('origin' => 'places', 'source_url' => ''));
        tt_google_apply_to_azienda($post_id, $chosen);
    } elseif (!$update) {
        update_post_meta($post_id, '_tt_voto', '');
        update_post_meta($post_id, '_tt_recensioni', '');
    }

    // Immagine: URL personalizzato > immagine scelta tra quelle trovate
    $image_url = esc_url_raw(isset($post['image_custom']) ? $post['image_custom'] : '');
    $choice = isset($post['image_choice']) ? $post['image_choice'] : 'none';
    if (!$image_url && !in_array($choice, array('none', 'keep'), true) && isset($scan['images'][intval($choice)])) {
        $image_url = $scan['images'][intval($choice)];
    }
    $image_error = '';
    if ($image_url) {
        $img = tt_company_sideload_image($image_url, $post_id, $title);
        if (is_wp_error($img)) {
            $image_error = $img->get_error_message();
        }
    }

    // Benchmark: solo per le aziende nuove, per non contare due volte la stessa azienda
    if (!$update) {
        tt_ai_update_category_benchmark($category_id, $scores);
    }

    // Collega il log della scansione alla scheda
    $logs = get_option('tt_ai_scan_logs', array());
    foreach ($logs as $i => $log) {
        if (isset($log['scan_token']) && $log['scan_token'] === $token) {
            $logs[$i]['post_id'] = $post_id;
            $logs[$i]['category_id'] = $category_id;
            $logs[$i]['scores'] = $scores;
        }
    }
    update_option('tt_ai_scan_logs', $logs, false);

    tt_company_delete_scan($token);

    if (!empty($scan['forced'])) {
        wp_safe_redirect(add_query_arg(array('post' => $post_id, 'action' => 'edit', 'tt_ai_updated' => 1, 'img_error' => $image_error ? 1 : 0), admin_url('post.php')));
        exit;
    }

    $args = array(
        'page'      => 'tt-ai-scanner',
        'published' => $post_id,
        'mode'      => $update ? 'updated' : 'created',
    );
    if ($image_error) {
        $args['img_error'] = '1';
    }
    wp_safe_redirect(add_query_arg($args, admin_url('admin.php')));
    exit;
}

/**
 * Notifica dopo la pubblicazione.
 */
function tt_company_render_published_notice() {
    if (empty($_GET['published'])) {
        return;
    }
    $post_id = intval($_GET['published']);
    if (get_post_type($post_id) !== 'azienda') {
        return;
    }
    $verb = (isset($_GET['mode']) && $_GET['mode'] === 'updated') ? 'aggiornata' : 'creata';
    $status = get_post_status($post_id) === 'publish' ? 'pubblicata' : 'salvata come bozza';
    ?>
    <div class="notice notice-success is-dismissible" style="border-left-color:#D4AF37;">
        <p><strong><?php echo esc_html(get_the_title($post_id)); ?></strong> <?php echo esc_html($verb . ' e ' . $status); ?>.
            <a href="<?php echo esc_url(get_edit_post_link($post_id)); ?>">Modifica</a> ·
            <a href="<?php echo esc_url(get_permalink($post_id)); ?>" target="_blank">Visualizza</a></p>
        <?php if (!empty($_GET['img_error'])) : ?>
            <p>L'immagine non è stata scaricata: impostala a mano dalla scheda.</p>
        <?php endif; ?>
    </div>
    <?php
}
