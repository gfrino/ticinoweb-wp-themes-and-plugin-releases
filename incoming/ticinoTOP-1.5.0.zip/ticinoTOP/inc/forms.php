<?php
/**
 * Ticino Top - Form pubblici (candidature e simulazione TopScan)
 *
 * Nessun gestore proprio: i dati passano dal gestore form del parent
 * (ticinoweb-ai-theme/inc/form-handler.php -> ticinoweb_submit_form), che fornisce
 * token fresco compatibile con la cache LiteSpeed, honeypot, rate limit per IP,
 * reCAPTCHA v3, salvataggio in "Invii Ricevuti" ed email ai contatti del sito.
 * Il child aggiunge solo la creazione del post `candidatura` (azione ticinoweb_form_submitted).
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_enqueue_scripts', 'tt_forms_enqueue', 30);
function tt_forms_enqueue() {
    if (!is_page_template(array('template-candidati.php', 'template-topscan.php'))) {
        return;
    }
    $file = get_stylesheet_directory() . '/assets/js/tt-forms.js';
    wp_enqueue_script('tt-forms', get_stylesheet_directory_uri() . '/assets/js/tt-forms.js', array('ticinoweb-ai-main'), filemtime($file), true);
}

add_action('wp_enqueue_scripts', 'tt_topscan_enqueue_chart', 30);
function tt_topscan_enqueue_chart() {
    if (is_page_template('template-topscan.php')) {
        // Chart.js self-hosted (MIT), prima era caricato dal CDN jsdelivr senza versione
        wp_enqueue_script('chartjs', get_stylesheet_directory_uri() . '/assets/js/chart.umd.min.js', array(), '4.5.1', false);
    }
}

/**
 * Dopo l'invio gestito dal parent: se e' una candidatura, crea il post privato `candidatura`.
 */
add_action('ticinoweb_form_submitted', 'tt_forms_create_candidatura', 10, 3);
function tt_forms_create_candidatura($submission_id, $fields, $sent = false) {
    if (!isset($_POST['tt_form']) || $_POST['tt_form'] !== 'candidatura') {
        return;
    }

    $post = wp_unslash($_POST);
    $data = array(
        'nome_azienda' => isset($post['nome_azienda']) ? sanitize_text_field($post['nome_azienda']) : '',
        'categoria'    => isset($post['categoria']) ? sanitize_text_field($post['categoria']) : '',
        'link_fonte'   => isset($post['link_fonte']) ? esc_url_raw($post['link_fonte']) : '',
        'motivazione'  => isset($post['motivazione']) ? sanitize_textarea_field($post['motivazione']) : '',
    );
    if ($data['nome_azienda'] === '') {
        return;
    }

    $content = '<p><strong>Referente:</strong> ' . esc_html($fields['nome']) . '<br>'
        . '<strong>Email:</strong> ' . esc_html($fields['email']) . '<br>'
        . '<strong>Telefono:</strong> ' . esc_html($fields['telefono']) . '<br>'
        . '<strong>Link per Scanner AI:</strong> <a href="' . esc_url($data['link_fonte']) . '">' . esc_html($data['link_fonte']) . '</a></p>'
        . '<p><strong>Perché merita l\'accesso:</strong><br>' . nl2br(esc_html($data['motivazione'])) . '</p>';

    $post_id = wp_insert_post(array(
        'post_title'   => 'Richiesta: ' . $data['nome_azienda'] . ($data['categoria'] ? ' - ' . $data['categoria'] : ''),
        'post_content' => $content,
        'post_status'  => 'private',
        'post_type'    => 'candidatura',
    ));

    if ($post_id && !is_wp_error($post_id)) {
        update_post_meta($post_id, 'email_referente', $fields['email']);
        update_post_meta($post_id, 'link_analisi', $data['link_fonte']);
        update_post_meta($post_id, '_tt_form_submission_id', (int) $submission_id);
    }
}

/**
 * Informativa privacy breve per i form, con link alla pagina privacy del sito.
 */
function tt_forms_privacy_notice($context = 'candidatura') {
    $url = get_privacy_policy_url();
    $text = $context === 'topscan'
        ? 'Inserendo la tua email accetti che Ticino Top la usi per inviarti il report e ricontattarti sulla simulazione.'
        : 'Inviando la candidatura accetti che i dati vengano usati per valutarla e ricontattarti.';
    $html = esc_html($text);
    if ($url) {
        $html .= ' <a href="' . esc_url($url) . '" target="_blank" rel="noopener" style="color: inherit; text-decoration: underline;">Informativa privacy</a>.';
    }
    return $html;
}
