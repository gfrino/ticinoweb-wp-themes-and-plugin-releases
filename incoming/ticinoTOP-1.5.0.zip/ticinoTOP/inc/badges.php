<?php
/**
 * Ticino Top - Gestione Sistema Dynamic Badges & Bollini
 * Registra il Custom Post Type "tt_badge" e i pannelli di relazione nelle Aziende, Classifiche ed Articoli.
 */

// 1. Registrazione Custom Post Type "Badge"
function tt_register_badge_cpt() {
    register_post_type('tt_badge', [
        'labels' => [
            'name' => 'Badge Ticino Top',
            'singular_name' => 'Badge',
            'menu_name' => 'Badge Ticino Top',
            'add_new' => 'Aggiungi Nuovo',
            'add_new_item' => 'Aggiungi Nuovo Badge',
            'edit_item' => 'Modifica Badge',
            'all_items' => 'Tutti i Badge',
            'search_items' => 'Cerca Badge',
            'not_found' => 'Nessun badge trovato.',
        ],
        'public' => true,
        'has_archive' => false,
        'menu_icon' => 'dashicons-awards',
        'menu_position' => 8,
        'supports' => ['title', 'thumbnail'], // Titolo per il Nome, Immagine in Evidenza per l'icona SVG/PNG
        'show_in_rest' => true,
    ]);
}
add_action('init', 'tt_register_badge_cpt');

// 2. Meta Box per Impostazioni del Badge CPT
function tt_add_badge_metaboxes() {
    add_meta_box('tt_badge_settings', 'Impostazioni Badge', 'tt_badge_settings_callback', 'tt_badge', 'normal', 'high');
}
add_action('add_meta_boxes', 'tt_add_badge_metaboxes');

function tt_badge_settings_callback($post) {
    wp_nonce_field('tt_badge_save_meta', 'tt_badge_nonce');
    
    $category = get_post_meta($post->ID, '_tt_badge_category', true);
    $status = get_post_meta($post->ID, '_tt_badge_status', true) !== '0'; // Default attivo
    
    echo '<style>
        .tt-meta-row { margin-bottom: 20px; } 
        .tt-meta-row label { display: block; font-weight: bold; margin-bottom: 8px; font-size: 14px; } 
        .tt-meta-row input[type="text"], .tt-meta-row select { width: 100%; max-width: 400px; padding: 6px 10px; }
        .tt-meta-desc { font-size: 12px; color: #666; margin-top: 4px; display: block; }
    </style>';
    
    echo '<div class="tt-meta-row">';
    echo '<label>Settore / Categoria</label>';
    echo '<input type="text" name="tt_badge_category" value="' . esc_attr($category) . '" placeholder="es. Food, Health, Mobility, Experience">';
    echo '<span class="tt-meta-desc">Il settore o categoria di appartenenza di questo badge (es. Experience).</span>';
    echo '</div>';
    
    echo '<div class="tt-meta-row" style="background: #fafafa; padding: 15px; border-radius: 6px; border: 1px solid #e2e8f0; max-width: 400px;">';
    echo '<label style="display: flex; align-items: center; cursor: pointer; font-weight: bold; margin: 0; color: #0f172a;">';
    echo '<input type="checkbox" name="tt_badge_status" value="1" ' . checked($status, true, false) . ' style="margin-right: 10px; width: 18px; height: 18px;">';
    echo '🟢 Badge Attivo';
    echo '</label>';
    echo '<span class="tt-meta-desc" style="margin-left: 28px;">Disattivalo per nasconderlo dalle opzioni di selezione nei post del sito.</span>';
    echo '</div>';
}

function tt_badge_save_meta($post_id) {
    if (!isset($_POST['tt_badge_nonce']) || !wp_verify_nonce($_POST['tt_badge_nonce'], 'tt_badge_save_meta'))
        return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
        return;
    if (!current_user_can('edit_post', $post_id))
        return;
        
    if (isset($_POST['tt_badge_category']))
        update_post_meta($post_id, '_tt_badge_category', sanitize_text_field($_POST['tt_badge_category']));
        
    $status_val = isset($_POST['tt_badge_status']) ? '1' : '0';
    update_post_meta($post_id, '_tt_badge_status', $status_val);
}
add_action('save_post', 'tt_badge_save_meta');


// 3. Meta Box per Assegnare Badge (Repeater Relazionale nelle Schede)
function tt_add_assigned_badges_metaboxes() {
    foreach (['azienda', 'classifica', 'post'] as $screen) {
        add_meta_box(
            'tt_assigned_badges', 
            'Bollini / Badges Ticino Top', 
            'tt_assigned_badges_callback', 
            $screen, 
            'normal', 
            'high'
        );
    }
}
add_action('add_meta_boxes', 'tt_add_assigned_badges_metaboxes');

function tt_assigned_badges_callback($post) {
    wp_nonce_field('tt_assigned_badges_save_meta', 'tt_assigned_badges_nonce');
    
    $assigned_json = get_post_meta($post->ID, '_tt_assigned_badges', true);
    $assigned = json_decode($assigned_json, true) ?: [];
    
    // Recupera i badge attivi configurati nel sistema
    $badges_query = new WP_Query([
        'post_type' => 'tt_badge',
        'posts_per_page' => -1,
        'post_status' => 'publish',
    ]);
    
    $active_badges = [];
    if ($badges_query->have_posts()) {
        while ($badges_query->have_posts()) {
            $badges_query->the_post();
            $b_id = get_the_ID();
            $status = get_post_meta($b_id, '_tt_badge_status', true);
            if ($status !== '0') {
                $active_badges[] = [
                    'id' => $b_id,
                    'title' => get_the_title(),
                ];
            }
        }
        wp_reset_postdata();
    }
    
    echo '<style>
        .tt-badge-repeater-table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        .tt-badge-repeater-table th, .tt-badge-repeater-table td { padding: 12px; border: 1px solid #e2e8f0; text-align: left; }
        .tt-badge-repeater-table th { background: #f8fafc; font-weight: bold; color: #1e293b; }
        .tt-badge-repeater-table tr:hover { background: #fafafa; }
        .tt-badge-input-vote { width: 70px !important; text-align: center; }
        .tt-badge-input-year { width: 90px !important; text-align: center; }
        .tt-badge-input-text { width: 100%; box-sizing: border-box; }
        .tt-btn-add-badge { background: #D4AF37 !important; border-color: #b5952f !important; color: #fff !important; padding: 6px 16px !important; font-size: 13px !important; font-weight: 600 !important; border-radius: 4px !important; cursor: pointer; display: inline-flex; align-items: center; gap: 6px; }
        .tt-btn-add-badge:hover { background: #c29f2e !important; }
        .tt-btn-remove-badge { color: #ef4444; text-decoration: none; font-weight: 600; cursor: pointer; }
        .tt-btn-remove-badge:hover { color: #dc2626; }
    </style>';
    
    if (empty($active_badges)) {
        echo '<p style="padding: 15px; background: #fffbeb; border-left: 4px solid #f59e0b; color: #b45309; border-radius: 4px;">';
        echo '⚠️ <strong>Nessun Badge configurato:</strong> Vai prima nella sezione <a href="' . esc_url(admin_url('edit.php?post_type=tt_badge')) . '" style="font-weight:bold; color:#b45309; text-decoration:underline;">Badge Ticino Top</a> e crea i tuoi badge (es. Experience, Health, ecc.) inserendo il nome del bollino e caricando il file grafico come immagine in evidenza.';
        echo '</p>';
        return;
    }
    
    ?>
    <div class="tt-badges-repeater-wrapper">
        <p class="description" style="margin-bottom:15px;">Associa uno o più badge reputazionali a questa scheda, inserendo il voto numerico da proiettare sul bollino (es. 4.8) e altri dettagli facoltativi.</p>
        
        <table class="tt-badge-repeater-table" id="tt-assigned-badges-table">
            <thead>
                <tr>
                    <th style="width: 250px;">Seleziona Badge</th>
                    <th style="width: 100px; text-align: center;">Voto (es. 4.8)</th>
                    <th style="width: 120px; text-align: center;">Anno (opzionale)</th>
                    <th>Testo Aggiuntivo (opzionale)</th>
                    <th style="width: 80px; text-align: center;">Azione</th>
                </tr>
            </thead>
            <tbody id="tt-badge-repeater-body">
                <!-- Riga Modello / Template per clonazione via JS -->
                <tr class="tt-badge-row-template" style="display: none;">
                    <td>
                        <select name="tt_assigned_badge_id[]" disabled>
                            <option value="">-- Seleziona Badge --</option>
                            <?php foreach ($active_badges as $badge) : ?>
                                <option value="<?php echo esc_attr($badge['id']); ?>"><?php echo esc_html($badge['title']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                    <td style="text-align: center;">
                        <input type="text" name="tt_assigned_badge_vote[]" class="tt-badge-input-vote" placeholder="4.8" disabled required>
                    </td>
                    <td style="text-align: center;">
                        <input type="text" name="tt_assigned_badge_year[]" class="tt-badge-input-year" placeholder="2026" disabled>
                    </td>
                    <td>
                        <input type="text" name="tt_assigned_badge_text[]" class="tt-badge-input-text" placeholder="es. Top Rating" disabled>
                    </td>
                    <td style="text-align: center;">
                        <span class="tt-btn-remove-badge" onclick="ttRemoveBadgeRow(this)">Rimuovi</span>
                    </td>
                </tr>

                <!-- Righe Esistenti Salvate -->
                <?php 
                if (!empty($assigned)) :
                    foreach ($assigned as $item) : 
                ?>
                    <tr class="tt-badge-row-active">
                        <td>
                            <select name="tt_assigned_badge_id[]" required>
                                <option value="">-- Seleziona Badge --</option>
                                <?php foreach ($active_badges as $badge) : ?>
                                    <option value="<?php echo esc_attr($badge['id']); ?>" <?php selected($item['badge_id'], $badge['id']); ?>><?php echo esc_html($badge['title']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td style="text-align: center;">
                            <input type="text" name="tt_assigned_badge_vote[]" class="tt-badge-input-vote" value="<?php echo esc_attr($item['vote']); ?>" placeholder="4.8" required>
                        </td>
                        <td style="text-align: center;">
                            <input type="text" name="tt_assigned_badge_year[]" class="tt-badge-input-year" value="<?php echo esc_attr($item['year']); ?>" placeholder="2026">
                        </td>
                        <td>
                            <input type="text" name="tt_assigned_badge_text[]" class="tt-badge-input-text" value="<?php echo esc_attr($item['text']); ?>" placeholder="es. Top Rating">
                        </td>
                        <td style="text-align: center;">
                            <span class="tt-btn-remove-badge" onclick="ttRemoveBadgeRow(this)">Rimuovi</span>
                        </td>
                    </tr>
                <?php 
                    endforeach;
                endif; 
                ?>
            </tbody>
        </table>
        
        <div style="margin-top: 15px; display: flex; justify-content: flex-end;">
            <button type="button" class="button tt-btn-add-badge" id="tt-btn-add-badge-row">
                <span class="dashicons dashicons-plus" style="margin-top:2px;"></span> Aggiungi Bollino
            </button>
        </div>
    </div>

    <!-- Script Repeater Dynamic Javascript Natively -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const addBtn = document.getElementById('tt-btn-add-badge-row');
            const tbody = document.getElementById('tt-badge-repeater-body');
            const template = document.querySelector('.tt-badge-row-template');

            if (addBtn && tbody && template) {
                addBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    
                    // Clona la riga modello
                    const newRow = template.cloneNode(true);
                    newRow.classList.remove('tt-badge-row-template');
                    newRow.classList.add('tt-badge-row-active');
                    newRow.style.display = '';
                    
                    // Abilita tutti gli input all'interno della riga
                    const inputs = newRow.querySelectorAll('input, select');
                    inputs.forEach(input => {
                        input.removeAttribute('disabled');
                    });
                    
                    tbody.appendChild(newRow);
                });
            }
        });

        function ttRemoveBadgeRow(element) {
            const row = element.closest('tr');
            if (row) {
                row.remove();
            }
        }
    </script>
    <?php
}

// 4. Salvataggio e Serializzazione JSON delle Associazioni Badge
function tt_assigned_badges_save_meta($post_id) {
    if (!isset($_POST['tt_assigned_badges_nonce']) || !wp_verify_nonce($_POST['tt_assigned_badges_nonce'], 'tt_assigned_badges_save_meta'))
        return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
        return;
    
    // Verifichiamo i permessi in base al tipo di post salvato
    $post_type = get_post_type($post_id);
    if ($post_type === 'page') {
        if (!current_user_can('edit_page', $post_id)) return;
    } else {
        if (!current_user_can('edit_post', $post_id)) return;
    }

    $assigned = [];
    if (!empty($_POST['tt_assigned_badge_id'])) {
        $ids = $_POST['tt_assigned_badge_id'];
        $votes = $_POST['tt_assigned_badge_vote'];
        $years = $_POST['tt_assigned_badge_year'];
        $texts = $_POST['tt_assigned_badge_text'];
        
        for ($i = 0; $i < count($ids); $i++) {
            $b_id = intval($ids[$i]);
            // Salva solo righe con un badge valido selezionato
            if ($b_id > 0) {
                $assigned[] = [
                    'badge_id' => $b_id,
                    'vote' => sanitize_text_field($votes[$i]),
                    'year' => sanitize_text_field($years[$i]),
                    'text' => sanitize_text_field($texts[$i]),
                ];
            }
        }
    }

    if (!empty($assigned)) {
        update_post_meta($post_id, '_tt_assigned_badges', wp_json_encode($assigned));
    } else {
        delete_post_meta($post_id, '_tt_assigned_badges');
    }
}
add_action('save_post', 'tt_assigned_badges_save_meta');


// 5. Componente Frontend: Rendering Grafico del Badge con Voto
function tt_render_single_badge($assigned_badge) {
    $badge_id = intval($assigned_badge['badge_id']);
    $vote = sanitize_text_field($assigned_badge['vote']);
    $year = isset($assigned_badge['year']) ? sanitize_text_field($assigned_badge['year']) : '';
    $text = isset($assigned_badge['text']) ? sanitize_text_field($assigned_badge['text']) : '';
    
    $badge_post = get_post($badge_id);
    if (!$badge_post || $badge_post->post_type !== 'tt_badge') {
        return '';
    }
    
    $badge_title = get_the_title($badge_id);
    $img_url = get_the_post_thumbnail_url($badge_id, 'full');
    
    // Fallback: se l'amministratore non ha caricato l'immagine in evidenza sul badge,
    // proviamo a cercarla nel percorso predefinito degli uploads in base allo slug del titolo
    if (!$img_url) {
        $slug = sanitize_title($badge_title);
        $img_url = tt_get_brand_image_url("{$slug}.svg");
    }
    
    // Creazione del testo per il tooltip a fumetto
    $tooltip_title = esc_attr($badge_title);
    if (!empty($year)) {
        $tooltip_title .= " (" . esc_attr($year) . ")";
    }
    
    ob_start();
    ?>
    <div class="tt-dynamic-badge">
        <img src="<?php echo esc_url($img_url); ?>" alt="<?php echo esc_attr($badge_title); ?>" class="tt-badge-graphic">
        <?php if ($vote !== '') : ?><div class="tt-badge-rating"><?php echo esc_html($vote); ?></div><?php endif; ?>
        
        <!-- Tooltip Hover Elegante -->
        <div class="tt-badge-tooltip">
            <span class="tt-badge-tooltip-title"><?php echo esc_html($tooltip_title); ?></span>
            <?php if (!empty($text)) : ?>
                <span class="tt-badge-tooltip-desc"><?php echo esc_html($text); ?></span>
            <?php endif; ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

// Helper PHP globale stampabile ovunque nei template
function tt_render_assigned_badges($post_id = null) {
    if (!$post_id) {
        $post_id = get_the_ID();
    }
    if (!$post_id) return '';
    
    $assigned_json = get_post_meta($post_id, '_tt_assigned_badges', true);
    $assigned = json_decode($assigned_json, true);
    
    if (empty($assigned) || !is_array($assigned)) return '';
    
    ob_start();
    ?>
    <div class="tt-badges-flex-container">
        <?php 
        foreach ($assigned as $badge_item) {
            echo tt_render_single_badge($badge_item);
        }
        ?>
    </div>
    <?php
    return ob_get_clean();
}

// Funzione echo diretta per comodità nei template
function tt_the_assigned_badges($post_id = null) {
    echo tt_render_assigned_badges($post_id);
}


// 6. Registrazione degli Shortcode Ufficiali
// Shortcode 1: [tt_badge id="badge_id" vote="4.8" year="2026" text="Motivazione"]
function tt_single_badge_shortcode($atts) {
    $args = shortcode_atts([
        'id' => 0,
        'vote' => '',
        'year' => '',
        'text' => '',
    ], $atts);
    
    $badge_id = intval($args['id']);
    if (!$badge_id) return '';
    
    $badge_item = [
        'badge_id' => $badge_id,
        'vote' => $args['vote'],
        'year' => $args['year'],
        'text' => $args['text'],
    ];
    
    return tt_render_single_badge($badge_item);
}
add_shortcode('tt_badge', 'tt_single_badge_shortcode');

// Shortcode 2: [tt_assigned_badges post_id="optional"]
function tt_assigned_badges_shortcode($atts) {
    $args = shortcode_atts([
        'post_id' => 0,
    ], $atts);
    
    $post_id = intval($args['post_id']);
    return tt_render_assigned_badges($post_id);
}
add_shortcode('tt_assigned_badges', 'tt_assigned_badges_shortcode');

// 7. Visualizzazione Grafica dei Badge nell'elenco di Backend (edit.php?post_type=tt_badge)
// Aggiunge la colonna personalizzata "Anteprima" alla lista dei Badge
function tt_set_badge_columns($columns) {
    $new_columns = [];
    foreach ($columns as $key => $title) {
        if ($key === 'title') {
            $new_columns['tt_badge_preview'] = 'Anteprima';
        }
        $new_columns[$key] = $title;
    }
    return $new_columns;
}
add_filter('manage_tt_badge_posts_columns', 'tt_set_badge_columns');

// Rende il contenuto della colonna "Anteprima" nella lista dei Badge
function tt_render_badge_custom_column($column, $post_id) {
    if ($column === 'tt_badge_preview') {
        $img_url = get_the_post_thumbnail_url($post_id, 'thumbnail');
        
        // Fallback identico alla logica frontend
        if (!$img_url) {
            $badge_title = get_the_title($post_id);
            $slug = sanitize_title($badge_title);
            $img_url = tt_get_brand_image_url("{$slug}.svg");
        }
        
        if ($img_url) {
            // Mostriamo una piccola anteprima del badge con il cerchio per il voto
            echo '<div class="tt-dynamic-badge" style="width: 46px; height: 46px; display: inline-block; position: relative; container-type: inline-size; background: #fafafa; border: 1px solid #cbd5e1; border-radius: 8px; padding: 3px; box-sizing: border-box; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">';
            echo '<img src="' . esc_url($img_url) . '" style="width: 100%; height: 100%; object-fit: contain; display: block;">';
            echo '<div style="position: absolute; top: 76.3%; left: 50.2%; transform: translate(-50%, -50%); font-family: sans-serif; font-size: 10cqw; font-weight: 800; color: #031836; background: #ffffff; width: 22cqw; height: 22cqw; border-radius: 50%; display: flex; align-items: center; justify-content: center; line-height: 1; text-align: center; box-shadow: 0 1px 2px rgba(0,0,0,0.1); pointer-events: none; user-select: none;">4.8</div>';
            echo '</div>';
        } else {
            echo '<span style="color: #94a3b8; font-style: italic;">Nessun bollino</span>';
        }
    }
}
add_action('manage_tt_badge_posts_custom_column', 'tt_render_badge_custom_column', 10, 2);

// Imposta la larghezza della colonna anteprima nel backend per un look pulito
function tt_badge_admin_css() {
    echo '<style>
        .column-tt_badge_preview { width: 80px; text-align: center; vertical-align: middle !important; }
        .tt-badge-repeater-table select, .tt-badge-repeater-table input { width: 100%; height: 32px; box-sizing: border-box; }
    </style>';
}
add_action('admin_head', 'tt_badge_admin_css');

