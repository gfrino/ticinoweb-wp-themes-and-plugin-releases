<?php
/**
 * Template Name: TT Candidati
 */

// Gestione invio form
$success_message = false;
$error_message = false;

// L'invio pubblico passa dal gestore form del parent (vedi inc/forms.php e assets/js/tt-forms.js):
// qui resta solo il pulsante di test mail, riservato agli amministratori.

// GESTIONE PULSANTE TEST MAIL
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['test_mail_candidatura']) && current_user_can('manage_options') && get_option('tt_test_mail_active', '0') === '1'
    && isset($_POST['candidatura_nonce']) && wp_verify_nonce($_POST['candidatura_nonce'], 'submit_candidatura_action')) {
    $to = get_option('admin_email');
    $subject = 'TEST: Nuova Candidatura Ticino Top';
    $headers = array('Content-Type: text/html; charset=UTF-8');
    $message = "<h2>Nuova Richiesta di Ammissione Ticino Top (TEST EMAIL)</h2>";
    $message .= "<p>Questa è una mail di prova per verificare che il server stia inviando correttamente le notifiche.</p>";
    $message .= "<div style='background: #f9f9f9; padding: 20px; border: 1px solid #ddd; margin-top: 20px;'>";
    $message .= "<strong>Azienda:</strong> Ristorante Fittizio Test<br>";
    $message .= "<strong>Referente:</strong> Mario Rossi<br>";
    $message .= "<strong>Email:</strong> test@example.com<br>";
    $message .= "<strong>Telefono:</strong> +41 12 345 67 89<br>";
    $message .= "<strong>Link per Scanner AI:</strong> <a href='https://google.com'>https://google.com</a><br><br>";
    $message .= "<strong>Perché merita l'accesso:</strong><br>Siamo i migliori della città, test email.";
    $message .= "</div>";
    
    $mail_sent = wp_mail($to, $subject, $message, $headers);
    if ($mail_sent) {
        $success_message = "Email di Test inviata con successo all'indirizzo amministratore: " . $to;
    } else {
        $error_message = "Errore nell'invio dell'email di test. Controlla la configurazione SMTP del server.";
    }
}
get_header(); ?>

<style>
    .tt-candidatura-container {
        max-width: 800px;
        margin: 0 auto;
        padding: 0 20px;
    }
    .tt-form-box {
        background: rgba(255, 255, 255, 0.03);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 24px;
        padding: 40px;
        backdrop-filter: blur(10px);
    }
    .tt-alert {
        background: rgba(212, 175, 55, 0.1);
        border: 1px solid rgba(212, 175, 55, 0.3);
        border-radius: 12px;
        padding: 24px;
        margin-bottom: 40px;
        display: flex;
        gap: 16px;
        align-items: flex-start;
    }
    .tt-alert-icon { font-size: 24px; line-height: 1; }
    .tt-alert-text h4 { color: var(--tt-gold-champagne); margin: 0 0 8px 0; font-family: var(--tt-font-serif); font-size: 20px; }
    .tt-alert-text p { margin: 0; color: #cbd5e1; line-height: 1.5; font-size: 15px; }
    .tt-form-group { margin-bottom: 24px; text-align: left; }
    .tt-form-group label { display: block; color: #cbd5e1; font-weight: 500; margin-bottom: 8px; font-size: 14px; letter-spacing: 0.5px; text-transform: uppercase; }
    .tt-form-control {
        width: 100%; background: rgba(0, 0, 0, 0.5); border: 1px solid rgba(255, 255, 255, 0.1);
        color: white; padding: 16px; border-radius: 12px; font-size: 16px; font-family: inherit; transition: all 0.3s ease;
    }
    .tt-form-control:focus { outline: none; border-color: var(--tt-gold-champagne); box-shadow: 0 0 0 4px rgba(212, 175, 55, 0.1); }
    .tt-form-buttons {
        display: flex;
        gap: 16px;
        margin-top: 32px;
        align-items: center;
        width: 100%;
    }
    .tt-btn-submit {
        background: var(--tt-gold-champagne);
        color: var(--tt-black) !important;
        border: 2px solid transparent;
        padding: 18px 40px;
        font-size: 18px;
        font-weight: 700;
        border-radius: 30px;
        cursor: pointer;
        transition: all 0.3s ease;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-family: inherit;
        flex: 2;
    }
    .tt-btn-submit:hover {
        background: var(--tt-gold-light) !important;
        color: var(--tt-black) !important;
        border-color: var(--tt-gold-champagne) !important;
        transform: translateY(-2px);
        box-shadow: 0 8px 24px rgba(212, 175, 55, 0.25);
    }
    .tt-btn-admin-test {
        background: rgba(59, 130, 246, 0.05);
        color: #93c5fd !important;
        border: 1px solid rgba(59, 130, 246, 0.3);
        padding: 18px 40px;
        font-size: 16px;
        font-weight: 600;
        border-radius: 30px;
        cursor: pointer;
        transition: all 0.3s ease;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-family: inherit;
        flex: 1;
    }
    .tt-btn-admin-test:hover {
        background: rgba(59, 130, 246, 0.15);
        color: #ffffff !important;
        border-color: rgba(59, 130, 246, 0.6);
        transform: translateY(-2px);
        box-shadow: 0 8px 24px rgba(59, 130, 246, 0.15);
    }
    
    @media (max-width: 768px) {
        .tt-form-buttons {
            flex-direction: column;
            gap: 12px;
        }
        .tt-btn-submit, .tt-btn-admin-test {
            width: 100%;
            flex: none;
        }
    }
    .tt-msg-success { background: rgba(34, 197, 94, 0.1); border: 1px solid rgba(34, 197, 94, 0.3); color: #4ade80; padding: 40px; border-radius: 12px; margin-bottom: 40px; text-align: center; }
    .tt-msg-error { background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); color: #f87171; padding: 16px; border-radius: 12px; margin-bottom: 24px; }
</style>

<main class="tt-main" style="background: var(--tt-white);">
    <!-- Hero Candidati -->
    <section class="tt-section" style="position: sticky; top: 0; min-height: 100vh; display: flex; flex-direction: column; justify-content: center; z-index: 10; background: var(--tt-black); color: var(--tt-white); text-align: center;">
        <div class="tt-container" style="max-width: 800px;">
            <div class="tt-badge tt-badge-gold animate-hero-logo" style="margin-bottom: 24px; color: var(--tt-black);">Ammissione Reputazionale</div>
            <h1 class="animate-hero-title" style="font-family: var(--tt-font-serif); font-size: 56px; margin-bottom: 24px; line-height: 1.15;">L'Albo d'Oro del Ticino.<br><span style="color: var(--tt-gold-champagne);">Se non ci sei... stai perdendo clienti.</span></h1>
            <p class="animate-hero-subtitle" style="font-size: 20px; color: #cbd5e1; margin-bottom: 40px; line-height: 1.6;">Ticino Top non è una vetrina a pagamento. È lo status d'eccellenza che i consumatori cercano prima di scegliere. Esibire il Bollino d'Oro sul tuo sito comunica garanzia istantanea; non averlo dice silenziosamente al mercato che un tuo concorrente ha standard superiori.</p>
            <div class="animate-hero-btns">
                <a href="#form-candidatura" class="tt-btn tt-btn-premium" style="font-size: 16px; padding: 14px 28px;">Avvia il Processo di Audit</a>
            </div>
        </div>
    </section>

    <!-- Why Apply -->
    <section class="tt-section" style="position: sticky; top: 0; min-height: 100vh; display: flex; flex-direction: column; justify-content: center; z-index: 20; background: var(--tt-white); border-radius: 40px 40px 0 0; box-shadow: 0 -20px 50px rgba(0,0,0,0.2);">
        <div class="tt-container">
            <div class="tt-grid-3 reveal-grid">
                <div style="padding: 32px; border: 1px solid var(--tt-gray-border); border-radius: var(--tt-radius-lg);">
                    <div style="font-size: 40px; margin-bottom: 16px;">💎</div>
                    <h3 style="font-size: 20px; margin-bottom: 16px; font-family: var(--tt-font-serif);">Status d'Elite</h3>
                    <p style="color: var(--tt-gray-text); margin: 0; line-height: 1.6;">Ottenere il Bollino d'Oro Ticino Top è un traguardo supremo. È un marchio di garanzia protetto ferocemente, riconosciuto all'istante dai clienti ad alto budget.</p>
                </div>
                <div style="padding: 32px; border: 1px solid var(--tt-gray-border); border-radius: var(--tt-radius-lg); background: var(--tt-gray-light);">
                    <div style="font-size: 40px; margin-bottom: 16px;">📈</div>
                    <h3 style="font-size: 20px; margin-bottom: 16px; font-family: var(--tt-font-serif);">Protezione Digitale</h3>
                    <p style="color: var(--tt-gray-text); margin: 0; line-height: 1.6;">Blocca la perdita invisibile di clienti sul web. Le attività escluse vedono l'utenza scivolare costantemente verso i concorrenti che mostrano il sigillo d'eccellenza.</p>
                </div>
                <div style="padding: 32px; border: 1px solid var(--tt-gray-border); border-radius: var(--tt-radius-lg);">
                    <div style="font-size: 40px; margin-bottom: 16px;">🤖</div>
                    <h3 style="font-size: 20px; margin-bottom: 16px; font-family: var(--tt-font-serif);">Audit Algoritmico</h3>
                    <p style="color: var(--tt-gray-text); margin: 0; line-height: 1.6;">Nessuna influenza commerciale, nessun favoritismo o sponsorizzazione in vendita. Un report scientifico spietato basato sull'AI certifica la reale eccellenza.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Step By Step -->
    <section class="tt-section" style="position: sticky; top: 0; min-height: 100vh; display: flex; flex-direction: column; justify-content: center; z-index: 30; background: var(--tt-gray-light); border-radius: 40px 40px 0 0; box-shadow: 0 -20px 50px rgba(0,0,0,0.1);">
        <div class="tt-container" style="max-width: 800px; margin: 0 auto; padding: 40px 20px;">
            <h2 class="reveal-on-scroll" style="font-family: var(--tt-font-serif); font-size: 36px; text-align: center; margin-bottom: 60px;">Il Rigoroso Protocollo di Selezione</h2>
            
            <div class="reveal-on-scroll" style="display: flex; flex-direction: column; gap: 40px; position: relative;">
                <!-- Linea guida -->
                <div style="position: absolute; left: 24px; top: 0; bottom: 0; width: 2px; background: var(--tt-gold-champagne); opacity: 0.3;"></div>
                
                <div style="display: flex; gap: 32px; position: relative; z-index: 1;">
                    <div style="width: 48px; height: 48px; border-radius: 50%; background: var(--tt-gold-champagne); color: var(--tt-black); display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 20px; flex-shrink: 0;">1</div>
                    <div>
                        <h3 style="font-size: 24px; margin-bottom: 12px; font-family: var(--tt-font-serif);">Candidatura & Screening Istantaneo</h3>
                        <p style="color: var(--tt-gray-text); line-height: 1.6;">Inserimento dei dati societari e attivazione immediata dell'algoritmo di prima scansione digitale sul sentiment dei clienti in Canton Ticino.</p>
                    </div>
                </div>
                
                <div style="display: flex; gap: 32px; position: relative; z-index: 1;">
                    <div style="width: 48px; height: 48px; border-radius: 50%; background: var(--tt-black); color: var(--tt-white); display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 20px; flex-shrink: 0;">2</div>
                    <div>
                        <h3 style="font-size: 24px; margin-bottom: 12px; font-family: var(--tt-font-serif);">Audit Reputazionale Incrociato (TopScan™)</h3>
                        <p style="color: var(--tt-gray-text); line-height: 1.6;">L'AI esamina a fondo oltre 20 piattaforme indipendenti. Isola, pesa ed elimina i dati manipolati per certificare la reale affidabilità aziendale.</p>
                    </div>
                </div>

                <div style="display: flex; gap: 32px; position: relative; z-index: 1;">
                    <div style="width: 48px; height: 48px; border-radius: 50%; background: var(--tt-black); color: var(--tt-white); display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 20px; flex-shrink: 0;">3</div>
                    <div>
                        <h3 style="font-size: 24px; margin-bottom: 12px; font-family: var(--tt-font-serif);">Delibera e Sigillo d'Oro</h3>
                        <p style="color: var(--tt-gray-text); line-height: 1.6;">Al superamento del benchmark minimo di 85/100, la tua impresa viene iscritta all'Albo d'Oro Ticino Top, riceve il Certificato Fisico e attiva il Badge Digitale sul web.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Sezione Modulo Candidatura -->
    <section id="form-candidatura" class="tt-section reveal-on-scroll" style="position: sticky; top: 0; min-height: 100vh; display: flex; flex-direction: column; justify-content: center; z-index: 40; background: var(--tt-black); border-radius: 40px 40px 0 0; box-shadow: 0 -20px 50px rgba(0,0,0,0.3);">
        <div class="tt-candidatura-container" style="width: 100%; max-width: 800px; margin: 0 auto; padding: 40px 20px;">
            
            <h2 style="font-family: var(--tt-font-serif); font-size: 36px; text-align: center; margin-bottom: 40px; color: var(--tt-white);">Sottoponi la tua Attività ad Audit</h2>

            <?php if ($success_message): ?>
                <div class="tt-msg-success">
                    <p style="font-size: 16px; margin: 0;"><?php echo esc_html($success_message); ?></p>
                </div>
            <?php else: ?>

                <div class="tt-alert" style="background: rgba(239, 68, 68, 0.08); border: 2px dashed rgba(239, 68, 68, 0.4); border-radius: 20px; padding: 32px; margin-bottom: 40px; text-align: left; backdrop-filter: blur(10px); box-shadow: 0 10px 30px rgba(239, 68, 68, 0.1); display: flex; gap: 20px; align-items: flex-start;">
                    <div style="font-size: 32px; line-height: 1; flex-shrink: 0;">⚠️</div>
                    <div class="tt-alert-text">
                        <h4 style="color: #f87171; margin: 0 0 8px 0; font-family: var(--tt-font-serif); font-size: 20px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">STANDARD DI SELEZIONE RIGIDI: IL 78% DELLE AZIENDE VIENE RESPINTO</h4>
                        <p style="margin: 0; color: #e2e8f0; line-height: 1.6; font-size: 15px;">Il Bollino d'Oro Ticino Top è uno status d'eccellenza esclusivo e <strong>ferocemente tutelato</strong>. Per garantire il valore del brand, l'audit scientifico dell'AI e il verdetto del comitato escludono il 78% delle candidature.</p>
                        <p style="margin: 12px 0 0 0; color: #cbd5e1; line-height: 1.6; font-size: 14px;">Ti consigliamo fortemente di eseguire la <a href="<?php echo esc_url(home_url('/topscan/')); ?>" style="color: var(--tt-gold-champagne); text-decoration: underline; font-weight: 600;">Diagnostica Istantanea TopScan™</a> prima di inviare questo form. Accettiamo solo candidature di imprese che ritengono di poter superare un punteggio reputazionale di 85/100.</p>
                    </div>
                </div>

                <?php if ($error_message): ?>
                    <div class="tt-msg-error"><?php echo esc_html($error_message); ?></div>
                <?php endif; ?>

                <div class="tt-msg-success" id="tt-candidatura-success" style="display: none;" role="status">
                    <h3 style="font-family: var(--tt-font-serif); font-size: 28px; margin-bottom: 12px; color: #fff;">🎉 Richiesta di Audit Ricevuta!</h3>
                    <p style="font-size: 16px; margin: 0;">Candidatura inviata con successo! Il nostro team utilizzerà il link fornito per eseguire l'analisi AI e ti contatterà a breve.</p>
                </div>
                <div class="tt-msg-error" id="tt-candidatura-error" style="display: none;" role="alert"></div>

                <div class="tt-form-box">
                    <form method="post" action="#form-candidatura" id="tt-candidatura-form" novalidate>
                        <?php wp_nonce_field('submit_candidatura_action', 'candidatura_nonce'); ?>
                        <!-- Honeypot del gestore form del parent: deve restare vuoto -->
                        <div style="position: absolute; left: -9999px;" aria-hidden="true">
                            <label>Lascia vuoto <input type="text" name="tw_hp" tabindex="-1" autocomplete="off"></label>
                        </div>
                        
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px;">
                            <div class="tt-form-group">
                                <label>Nome Azienda *</label>
                                <input type="text" name="nome_azienda" class="tt-form-control" required placeholder="Es. Ristorante Da Mario">
                            </div>
                            <div class="tt-form-group">
                                <label>Categoria Principale</label>
                                <select name="categoria" class="tt-form-control">
                                    <?php
                                    $categories = get_terms(array(
                                        'taxonomy'   => 'categoria_azienda',
                                        'hide_empty' => false,
                                    ));
                                    if (!is_wp_error($categories) && !empty($categories)) {
                                        foreach ($categories as $category) {
                                            echo '<option value="' . esc_attr($category->name) . '">' . esc_html($category->name) . '</option>';
                                        }
                                    } else {
                                        echo '<option value="Altro">Altro</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <div class="tt-form-group">
                            <label>Link alla Scheda Google o TripAdvisor *</label>
                            <p style="color: #64748b; font-size: 12px; margin: 0 0 8px 0;">Questo link verrà dato in pasto al nostro Scanner AI per calcolare il tuo punteggio reale.</p>
                            <input type="url" name="link_fonte" class="tt-form-control" required placeholder="https://...">
                        </div>

                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px;">
                            <div class="tt-form-group">
                                <label>Nome del Referente</label>
                                <input type="text" name="referente" class="tt-form-control" placeholder="Mario Rossi">
                            </div>
                            <div class="tt-form-group">
                                <label>Telefono</label>
                                <input type="text" name="telefono" class="tt-form-control" placeholder="+41 79 123 45 67">
                            </div>
                        </div>

                        <div class="tt-form-group">
                            <label>Indirizzo Email *</label>
                            <input type="email" name="email" class="tt-form-control" required placeholder="info@azienda.ch">
                        </div>

                        <div class="tt-form-group">
                            <label>Perché la tua azienda merita l'ammissione in Ticino Top? *</label>
                            <textarea name="motivazione" class="tt-form-control" rows="4" maxlength="3000" placeholder="Fai valere la tua candidatura. Perché il comitato reputazionale AI e umano dovrebbe ammettere la tua azienda tra i leader indiscussi del Canton Ticino? Descrivi l'unicità e la qualità maniacale del tuo servizio..."></textarea>
                        </div>

                        <p style="color: #94a3b8; font-size: 13px; line-height: 1.5; margin: 0 0 24px 0; text-align: left;"><?php echo tt_forms_privacy_notice('candidatura'); ?></p>

                        <div class="tt-form-buttons">
                            <button type="submit" name="submit_candidatura" class="tt-btn-submit">Sottoponi la Candidatura</button>
                            <!-- Pulsante Test Mail visibile solo se attivo nelle impostazioni e ad amministratori -->
                            <?php if (current_user_can('manage_options') && get_option('tt_test_mail_active', '0') === '1'): ?>
                            <button type="submit" name="test_mail_candidatura" formnovalidate class="tt-btn-admin-test" data-tt-native="1">Test Invio Mail</button>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>

            <?php endif; ?>
        </div>
    </section>

</main>
<?php get_footer(); ?>
