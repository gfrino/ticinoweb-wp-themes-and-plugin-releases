<footer style="background: var(--tt-blue-notte); color: var(--tt-white); padding: 60px 0 20px; position: relative; z-index: 10;">
    <div class="tt-container tt-footer-inner" style="display: flex; justify-content: space-between; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 40px; margin-bottom: 20px;">
        <div>
            <div class="tt-logo" style="margin-bottom: 16px;">
                <img src="<?php echo esc_url(tt_get_brand_image_url('Logo-Ticino-Top.svg')); ?>" alt="Ticino Top" style="height: 45px; width: auto; filter: brightness(0) invert(1);">
            </div>
            <p style="color: #94a3b8; max-width: 300px; font-size: 14px;">Il punto di riferimento del Ticino per ciò che è più apprezzato, consigliato e affidabile.</p>
        </div>
        <div style="display: flex; gap: 40px;">
            <div>
                <h4 class="tt-footer-title">Navigazione</h4>
                <?php
                wp_nav_menu( array(
                    'theme_location' => 'primary',
                    'container'      => false,
                    'depth'          => 1,
                    'fallback_cb'    => 'ticinotop_menu_fallback',
                    'menu_class'     => 'tt-footer-menu',
                ) );
                ?>
            </div>
        </div>
    </div>
    <div class="tt-container" style="text-align: center; color: #64748b; font-size: 12px; display: flex; flex-direction: column; gap: 8px; align-items: center; justify-content: center; margin-top: 10px;">
        <div>
            &copy; <?php echo esc_html(wp_date('Y')); ?> Ticino Top. Design by <a href="https://ticinoweb.com/" target="_blank" rel="noopener" style="color: inherit; text-decoration: none; border-bottom: 1px dashed rgba(100,116,139,0.4); transition: color 0.3s;" onmouseover="this.style.color='#94a3b8'" onmouseout="this.style.color='#64748b'">ticinoWEB</a>.
        </div>
        <?php
        // Link legali: privacy (Impostazioni > Privacy) e impressum / note legali se la pagina esiste
        $legal_links = array();
        $privacy_page_id = get_option('wp_page_for_privacy_policy');
        if ($privacy_page_id && get_post_status($privacy_page_id) === 'publish') {
            $legal_links[] = array(get_permalink($privacy_page_id), 'Privacy Policy');
        }
        foreach (array('impressum', 'note-legali', 'note-legali-impressum') as $legal_slug) {
            $legal_page = get_page_by_path($legal_slug);
            if ($legal_page && $legal_page->post_status === 'publish') {
                $legal_links[] = array(get_permalink($legal_page), get_the_title($legal_page));
                break;
            }
        }
        if ($legal_links) :
        ?>
            <div style="display: flex; gap: 16px; flex-wrap: wrap; justify-content: center;">
                <?php foreach ($legal_links as $legal_link) : ?>
                    <a href="<?php echo esc_url($legal_link[0]); ?>" style="color: inherit; text-decoration: none; border-bottom: 1px dashed rgba(100,116,139,0.4); transition: color 0.3s;" onmouseover="this.style.color='#94a3b8'" onmouseout="this.style.color='#64748b'"><?php echo esc_html($legal_link[1]); ?></a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</footer>
<script>
document.addEventListener('DOMContentLoaded', () => {
    // Scroll reveal observer
    const observerOptions = {
        root: null,
        threshold: 0.05,
        rootMargin: '0px 0px -50px 0px'
    };
    const observer = new IntersectionObserver((entries, obs) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('in-view');
                obs.unobserve(entry.target);
            }
        });
    }, observerOptions);
    document.querySelectorAll('.reveal-on-scroll, .reveal-grid').forEach(el => observer.observe(el));

    // Sticky header scroll effects
    const header = document.querySelector('.tt-header');
    if (header) {
        const handleHeaderScroll = () => {
            if (window.scrollY > 30) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        };
        window.addEventListener('scroll', handleHeaderScroll, { passive: true });
        handleHeaderScroll();
    }

    // Mobile menu toggle logic
    const hamburger = document.querySelector('.tt-hamburger');
    const mobileMenu = document.querySelector('.tt-mobile-menu');
    
    if (hamburger && mobileMenu) {
        hamburger.addEventListener('click', () => {
            const isExpanded = hamburger.getAttribute('aria-expanded') === 'true';
            hamburger.setAttribute('aria-expanded', !isExpanded);
            hamburger.classList.toggle('active');
            mobileMenu.classList.toggle('active');
            document.body.classList.toggle('no-scroll');
        });

        // Close menu when clicking on any mobile nav links
        const mobileLinks = mobileMenu.querySelectorAll('a');
        mobileLinks.forEach(link => {
            link.addEventListener('click', () => {
                hamburger.setAttribute('aria-expanded', 'false');
                hamburger.classList.remove('active');
                mobileMenu.classList.remove('active');
                document.body.classList.remove('no-scroll');
            });
        });
    }
});
</script>
<?php wp_footer(); ?>
</body>
</html>
