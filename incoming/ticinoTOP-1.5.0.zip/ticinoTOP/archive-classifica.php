<?php
/**
 * The template for displaying archive of Classifiche (Rankings)
 */
get_header(); ?>

<main class="tt-main" style="background: var(--tt-white);">

    <!-- HERO CLASSIFICHE -->
    <header class="tt-hero" style="position: sticky; top: 0; padding: 120px 0 160px; z-index: 10; background: var(--tt-white); text-align: center;">
        <div class="tt-container" style="position: relative; z-index: 2;">
            <div class="tt-badge tt-badge-gold animate-hero-logo" style="margin-bottom: 24px; display: inline-block; background: rgba(212, 175, 55, 0.1); border-color: rgba(212, 175, 55, 0.5); color: var(--tt-gold-champagne);">Archivio Ufficiale</div>
            <h1 class="animate-hero-title" style="font-family: var(--tt-font-serif); font-size: 56px; color: var(--tt-black); margin-bottom: 24px; line-height: 1.1;">Le Classifiche Premium</h1>
            <p class="animate-hero-subtitle" style="color: var(--tt-gray-text); font-size: 18px; max-width: 600px; margin: 0 auto; line-height: 1.6;">Esplora i ranking ufficiali di Ticino Top. Dalle guide gastronomiche ai migliori professionisti locali, basati sul nostro algoritmo di reputazione e approvati dalle persone.</p>
        </div>
    </header>

    <!-- GRID CLASSIFICHE -->
    <section class="tt-section" style="position: relative; z-index: 20; background: var(--tt-black); border-radius: 40px 40px 0 0; box-shadow: 0 -20px 50px rgba(0,0,0,0.5); padding: 100px 0 60px;">
        <div class="tt-container">
            <div class="reveal-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(350px, 1fr)); gap: 40px;">
                
                <?php 
                $args = array('post_type' => 'classifica', 'posts_per_page' => -1);
                $query = new WP_Query($args);
                
                if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post(); 
                    
                    $image_url = get_post_meta(get_the_ID(), '_tt_image', true);
                    if (!$image_url) {
                        $image_url = get_the_post_thumbnail_url(get_the_ID(), 'large');
                    }
                    if (!$image_url) {
                        $image_url = get_stylesheet_directory_uri() . '/images/placeholder-business.jpg'; // fallback
                    }
                ?>
                
                <a href="<?php the_permalink(); ?>" class="tt-classifica-card" style="display: block; position: relative; overflow: hidden; border-radius: 20px; text-decoration: none; box-shadow: 0 20px 40px rgba(0,0,0,0.4);">
                    <div style="position: relative; aspect-ratio: 3/4; overflow: hidden;">
                        <img src="<?php echo esc_url($image_url); ?>" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.8s cubic-bezier(0.4, 0, 0.2, 1);" alt="<?php the_title_attribute(); ?>">
                        
                        <div style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: linear-gradient(to top, rgba(10,25,47,0.95) 0%, rgba(10,25,47,0.4) 50%, rgba(10,25,47,0) 100%);"></div>
                        
                        <div style="position: absolute; bottom: 0; left: 0; right: 0; padding: 40px 32px; z-index: 2; display: flex; flex-direction: column; justify-content: flex-end; height: 100%;">
                            
                            <div class="tt-badge-hover" style="margin-bottom: 16px; background: rgba(212, 175, 55, 0.2); color: var(--tt-gold-champagne); padding: 6px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; display: inline-block; width: max-content; border: 1px solid rgba(212, 175, 55, 0.5); backdrop-filter: blur(4px);">
                                Top 2026
                            </div>
                            
                            <h3 style="color: var(--tt-white); font-family: var(--tt-font-serif); font-size: 28px; line-height: 1.2; margin-bottom: 16px; text-shadow: 0 4px 12px rgba(0,0,0,0.5);">
                                <?php the_title(); ?>
                            </h3>
                            
                            <p style="color: #cbd5e1; font-size: 15px; margin: 0; line-height: 1.6; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; opacity: 0.8; transition: opacity 0.3s ease;">
                                <?php echo get_the_excerpt(); ?>
                            </p>
                        </div>
                    </div>
                </a>
                
                <?php endwhile; wp_reset_postdata(); else : ?>
                    <p style="color: var(--tt-gray-text); font-size: 18px; text-align: center; grid-column: 1 / -1; padding: 40px 0;">Stiamo elaborando le prime classifiche ufficiali. Torna presto.</p>
                <?php endif; ?>

            </div>
        </div>
    </section>

</main>

<style>
.tt-classifica-card img {
    transition: transform 0.8s cubic-bezier(0.4, 0, 0.2, 1);
}
.tt-classifica-card:hover img {
    transform: scale(1.08);
}
.tt-classifica-card::after {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0; bottom: 0;
    border-radius: 20px;
    border: 1px solid rgba(255,255,255,0.1);
    transition: all 0.4s ease;
    z-index: 3;
    pointer-events: none;
}
.tt-classifica-card:hover::after {
    border-color: var(--tt-gold-champagne);
    box-shadow: inset 0 0 0 1px var(--tt-gold-champagne);
}
.tt-classifica-card p {
    opacity: 0.7;
}
.tt-classifica-card:hover p {
    opacity: 1;
}
</style>

<?php get_footer(); ?>
