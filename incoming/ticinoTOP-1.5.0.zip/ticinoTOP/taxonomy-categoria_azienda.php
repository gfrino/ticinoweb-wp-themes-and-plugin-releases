<?php
/**
 * Template Name: TT Categoria
 */
get_header(); ?>

<main class="tt-main">
    <!-- Hero Categoria -->
    <?php
    $term = get_queried_object();
    $banner_img = get_stylesheet_directory_uri() . '/images/category-default.jpg'; // fallback
    if ($term && !is_wp_error($term)) {
        if (in_array($term->slug, ['food-dining', 'ristorazione-locali', 'ristorazione-amp-locali'])) {
            $banner_img = get_stylesheet_directory_uri() . '/images/category-food.jpg';
        } elseif (in_array($term->slug, ['health-trust', 'salute-medicina', 'salute-amp-medicina'])) {
            $banner_img = get_stylesheet_directory_uri() . '/images/category-health.jpg';
        } elseif (in_array($term->slug, ['experience-stay', 'hotel-alloggi', 'hotel-amp-alloggi'])) {
            $banner_img = get_stylesheet_directory_uri() . '/images/category-experience.jpg';
        }
    }
    ?>
    <section class="tt-section tt-section-dark" style="padding: 100px 0; background-image: linear-gradient(to right, var(--tt-blue-notte), rgba(10,25,47,0.8)), url('<?php echo esc_url($banner_img); ?>'); background-size: cover; background-position: center;">
        <div class="tt-container" style="display: flex; justify-content: space-between; align-items: center;">
            <div style="max-width: 600px;">
                <?php $term = get_queried_object(); ?>
                <div class="tt-badge tt-badge-gold" style="margin-bottom: 24px;">Categoria</div>
                <h1 style="font-family: var(--tt-font-serif); font-size: 64px; margin-bottom: 16px;"><?php single_term_title(); ?></h1>
                <p style="font-size: 20px; color: #cbd5e1; margin-bottom: 32px;">Le eccellenze del Ticino per la categoria <?php single_term_title(); ?>, analizzate e validate dall'intelligenza artificiale.</p>
                <div style="display: flex; gap: 24px; color: var(--tt-white);">
                    <div>
                        <div style="font-size: 32px; font-weight: 700; color: var(--tt-gold-champagne);">142</div>
                        <div style="font-size: 12px; text-transform: uppercase;">Attività Top</div>
                    </div>
                    <div>
                        <div style="font-size: 32px; font-weight: 700; color: var(--tt-gold-champagne);">8</div>
                        <div style="font-size: 12px; text-transform: uppercase;">Classifiche</div>
                    </div>
                </div>
            </div>
            <div style="background: var(--tt-white); padding: 32px; border-radius: var(--tt-radius-lg); width: 320px; text-align: center; color: var(--tt-black);">
                <div style="font-size: 48px; margin-bottom: 16px;">🏅</div>
                <h3 style="margin-bottom: 12px; font-family: var(--tt-font-serif);">Badge Ufficiale</h3>
                <p style="font-size: 14px; color: var(--tt-gray-text); margin-bottom: 24px;">Le attività in questa categoria sono insignite del badge <strong>Ticino Top <?php single_term_title(); ?> Excellence</strong>.</p>
                <?php $tt_criteri = get_page_by_path('topscan') ?: get_page_by_path('chi-siamo'); ?>
                <?php if ($tt_criteri) : ?>
                    <a href="<?php echo esc_url(get_permalink($tt_criteri)); ?>" class="tt-btn tt-btn-outline" style="width: 100%;">Scopri i Criteri</a>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Aziende in questa categoria -->
    <section class="tt-section" style="background: var(--tt-gray-light);">
        <div class="tt-container">
            <h2 style="font-family: var(--tt-font-serif); font-size: 32px; margin-bottom: 40px;">Aziende in <?php single_term_title(); ?></h2>
            
            <div class="tt-grid-3">
                <?php 
                if (have_posts()) :
                    $position = 1;
                    while (have_posts()) : the_post();
                        $post_id = get_the_ID();
                        
                        $voto = get_post_meta($post_id, '_tt_voto', true);
                        $recensioni = get_post_meta($post_id, '_tt_recensioni', true);
                        $ai_text = get_post_meta($post_id, '_tt_ai_text', true);
                        
                        $fallback_pool = [
                            get_stylesheet_directory_uri() . '/images/placeholder-restaurant.jpg',
                            get_stylesheet_directory_uri() . '/images/placeholder-business.jpg',
                            get_stylesheet_directory_uri() . '/images/placeholder-clinic.jpg',
                            get_stylesheet_directory_uri() . '/images/placeholder-scenic.jpg',
                            get_stylesheet_directory_uri() . '/images/placeholder-boutique.jpg',
                            get_stylesheet_directory_uri() . '/images/placeholder-office.jpg',
                            get_stylesheet_directory_uri() . '/images/placeholder-cafe.jpg'
                        ];
                        $fallback_img = $fallback_pool[$post_id % count($fallback_pool)];
                        
                        $img_meta = get_post_meta($post_id, '_tt_image', true);
                        $img = $img_meta ?: (get_the_post_thumbnail_url($post_id, 'large') ?: $fallback_img);
                        
                        $ranking_data = [
                            'title' => get_the_title(),
                            'category' => single_term_title('', false),
                            'position' => $position,
                            'score' => $voto,
                            'reviews' => $recensioni,
                            'ai_text' => wp_trim_words($ai_text, 15, '...'),
                            'img' => $img,
                            'url' => get_permalink()
                        ];
                        
                        set_query_var('tt_ranking', $ranking_data);
                        get_template_part('template-parts/card', 'ranking'); 
                        
                        $position++;
                    endwhile;
                else :
                    echo '<p style="grid-column: 1/-1; text-align: center; color: var(--tt-gray-text);">Nessuna azienda trovata in questa categoria.</p>';
                endif;
                ?>
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?>
