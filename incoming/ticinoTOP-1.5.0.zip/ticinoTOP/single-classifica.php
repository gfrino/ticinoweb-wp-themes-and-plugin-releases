<?php
/**
 * The template for displaying single Classifiche (Rankings)
 */
get_header(); 

$post_id = get_the_ID();

// Fetch meta values
$badge = get_post_meta($post_id, '_tt_classifica_badge', true) ?: 'Top Classifica';
$affidabilita = get_post_meta($post_id, '_tt_classifica_affidabilita', true);
$valutate = get_post_meta($post_id, '_tt_classifica_valutate', true);
$limit = get_post_meta($post_id, '_tt_classifica_limit', true) ?: 10;
$methodology = get_post_meta($post_id, '_tt_classifica_methodology', true) ?: "L'AI di Ticino Top ha analizzato le recensioni verificando la coerenza temporale e l'affidabilità di ciascuna attività.";
$linked_cat = get_post_meta($post_id, '_tt_classifica_categoria', true);

$img_meta = get_post_meta($post_id, '_tt_image', true);
$img = $img_meta ?: (get_the_post_thumbnail_url($post_id, 'full') ?: get_stylesheet_directory_uri() . '/images/placeholder-restaurant.jpg');

// Query dynamic companies
$companies = [];
$using_fallback = false;

if ($linked_cat) {
    $args = [
        'post_type' => 'azienda',
        'posts_per_page' => intval($limit),
        'tax_query' => [
            [
                'taxonomy' => 'categoria_azienda',
                'field' => 'term_id',
                'terms' => intval($linked_cat),
            ]
        ],
        'meta_key' => '_tt_voto',
        'orderby' => 'meta_value_num',
        'order' => 'DESC',
    ];
    $query = new WP_Query($args);
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            
            $comp_id = get_the_ID();
            $comp_voto = get_post_meta($comp_id, '_tt_voto', true);
            $comp_recensioni = get_post_meta($comp_id, '_tt_recensioni', true);
            $comp_match = get_post_meta($comp_id, '_tt_ai_match', true);
            $comp_ai_text = get_post_meta($comp_id, '_tt_ai_text', true);
            $comp_img_meta = get_post_meta($comp_id, '_tt_image', true);
            $comp_img = $comp_img_meta ?: (get_the_post_thumbnail_url($comp_id, 'large') ?: get_stylesheet_directory_uri() . '/images/placeholder-business.jpg');
            
            // Smart parse location from title or keywords
            $keywords = get_post_meta($comp_id, '_tt_keywords', true);
            $location = 'Ticino';
            if (stripos(get_the_title(), 'Lugano') !== false || stripos($keywords, 'lugano') !== false) {
                $location = 'Lugano';
            } elseif (stripos(get_the_title(), 'Locarno') !== false || stripos($keywords, 'locarno') !== false) {
                $location = 'Locarno';
            } elseif (stripos(get_the_title(), 'Ascona') !== false || stripos($keywords, 'ascona') !== false) {
                $location = 'Ascona';
            } elseif (stripos(get_the_title(), 'Bellinzona') !== false || stripos($keywords, 'bellinzona') !== false) {
                $location = 'Bellinzona';
            } else {
                $terms = get_the_terms($comp_id, 'categoria_azienda');
                if ($terms && !is_wp_error($terms)) {
                    $location = $terms[0]->name;
                }
            }
            
            $companies[] = [
                'id' => $comp_id,
                'title' => get_the_title(),
                'category' => $location,
                'score' => $comp_voto,
                'reviews' => $comp_recensioni,
                'ai_text' => $comp_ai_text,
                'img' => $comp_img,
                'url' => get_permalink(),
                'website' => get_post_meta($comp_id, '_tt_website', true),
            ];
        }
        wp_reset_postdata();
    }
}

// Rimosso il fallback statico ristoranti per evitare incongruenze di categoria (es: ristoranti in classifica cliniche)

$selected_count = count($companies);
// "Aziende Valutate": se non indicato a mano, il numero reale di aziende pubblicate nella categoria
if ($valutate === '' && $linked_cat) {
    $term = get_term(intval($linked_cat), 'categoria_azienda');
    $valutate = ($term && !is_wp_error($term)) ? (string) $term->count : '';
}
$selected_text = 'Top ' . $selected_count;
?>

<main class="tt-main">
    <!-- Hero Editoriale -->
    <section class="tt-section tt-section-dark" style="padding: 120px 0; background-image: linear-gradient(to bottom, rgba(10,25,47,0.8), var(--tt-blue-notte)), url('<?php echo esc_url($img); ?>'); background-size: cover; background-position: center;">
        <div class="tt-container" style="max-width: 900px; margin: 0 auto; text-align: center;">
            <div class="tt-badge tt-badge-gold animate-hero-logo" style="margin-bottom: 24px;"><?php echo esc_html($badge); ?></div>
            <h1 class="animate-hero-title" style="font-size: 56px; font-family: var(--tt-font-serif); margin-bottom: 24px; line-height: 1.1;"><?php echo esc_html(get_the_title($post_id)); ?></h1>
            <p class="animate-hero-subtitle" style="font-size: 20px; color: #cbd5e1; margin-bottom: 40px;"><?php echo esc_html(get_the_excerpt($post_id) ?: 'Classifica aggiornata al 2026, basata su recensioni analizzate, segnali di reputazione digitale e validazione AI.'); ?></p>
            
            <div style="display: flex; gap: 32px; justify-content: center; color: var(--tt-white);">
                <?php if ($affidabilita !== '') : ?>
                <div>
                    <div style="font-size: 24px; font-weight: 700; color: var(--tt-gold-champagne);"><?php echo esc_html($affidabilita); ?></div>
                    <div style="font-size: 12px; text-transform: uppercase; color: #94a3b8;">Affidabilità Dati</div>
                </div>
                <?php endif; ?>
                <?php if ($valutate !== '') : ?>
                <div>
                    <div style="font-size: 24px; font-weight: 700; color: var(--tt-gold-champagne);"><?php echo esc_html($valutate); ?></div>
                    <div style="font-size: 12px; text-transform: uppercase; color: #94a3b8;">Aziende Valutate</div>
                </div>
                <?php endif; ?>
                <div>
                    <div style="font-size: 24px; font-weight: 700; color: var(--tt-gold-champagne);"><?php echo esc_html($selected_text); ?></div>
                    <div style="font-size: 12px; text-transform: uppercase; color: #94a3b8;">Selezionati</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Metodologia -->
    <section class="tt-section" style="padding: 40px 0; background: var(--tt-white); border-bottom: 1px solid var(--tt-gray-border);">
        <div class="tt-container" style="max-width: 900px;">
            <div class="reveal-on-scroll" style="background: var(--tt-gray-light); padding: 24px; border-radius: var(--tt-radius-md); border-left: 4px solid var(--tt-gold-champagne); display: flex; gap: 24px; align-items: flex-start;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color: var(--tt-gold-champagne); flex-shrink: 0;"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                <div>
                    <h3 style="font-size: 16px; margin-bottom: 8px;">Come leggiamo i dati</h3>
                    <p style="font-size: 14px; color: var(--tt-gray-text); margin: 0;"><?php echo esc_html($methodology); ?></p>
                </div>
            </div>
        </div>
    </section>

    <!-- Ranking List -->
    <section class="tt-section">
        <div class="tt-container" style="max-width: 900px;">
            
            <?php if (empty($companies)) : ?>
                <div style="text-align: center; padding: 60px 24px; background: var(--tt-gray-light); border-radius: var(--tt-radius-md); border: 2px dashed var(--tt-gray-border); margin: 20px 0;">
                    <div style="font-size: 48px; margin-bottom: 16px; color: var(--tt-gray-text);">📊</div>
                    <h3 style="font-size: 18px; font-weight: 600; color: var(--tt-blue-notte); margin-bottom: 8px;">Nessuna azienda associata a questa classifica</h3>
                    <p style="font-size: 14px; color: var(--tt-gray-text); max-width: 480px; margin: 0 auto;">Associa le attività alla categoria corrispondente nel backend WordPress per vederle comparire automaticamente in questa classifica.</p>
                </div>
            <?php else : ?>
                <div class="reveal-grid" style="display: flex; flex-direction: column; gap: 40px;">
                    <?php 
                    $pos = 1;
                    foreach ($companies as $comp) {
                        $comp['position'] = $pos++;
                        set_query_var('tt_ranking', $comp);
                        get_template_part('template-parts/card', 'ranking-row'); 
                    }
                    ?>
                </div>
            <?php endif; ?>

        </div>
    </section>
</main>
<?php get_footer(); ?>
