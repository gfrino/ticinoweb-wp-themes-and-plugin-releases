<?php
/**
 * Template Name: TT Home Premium
 */
get_header(); ?>

<main class="tt-main">
    <!-- Hero Section -->
    <!-- Wavy Golden Fabric Background Canvas -->
    <canvas id="tt-golden-fabric" aria-hidden="true" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: -10; pointer-events: none;"></canvas>

    <!-- SVG star texture — CSS background, always reliable & visible -->
    <div class="tt-svg-stars" aria-hidden="true" style="
        position: fixed; top: 0; left: 0; width: 100%; height: 100%;
        z-index: -9; pointer-events: none;
        background-image: url('data:image/svg+xml;utf8,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%22180%22 height=%22180%22><polygon points=%2290,14 102.1,51.3 141.4,51.3 109.6,74.4 121.7,111.7 90,88.6 58.3,111.7 70.4,74.4 38.6,51.3 77.9,51.3%22 fill=%22rgba(212,175,55,0.08)%22/></svg>');
        background-size: 180px 180px;
    "></div>

    <section class="tt-hero" style="position: relative; min-height: 85vh; display: flex; flex-direction: column; justify-content: center; z-index: 10; padding: 100px 0; background: transparent;">
        <div class="tt-container">
            <div class="tt-badge tt-badge-gold animate-hero-logo" style="margin-bottom: 24px;">Ticino Top Recommended</div>
            <h1 class="animate-hero-title" style="margin-bottom: 24px; display: flex; justify-content: center;">
                <img src="<?php echo esc_url(tt_get_brand_image_url('Logo-Ticino-Top.svg')); ?>" alt="Ticino Top" style="height: 180px; width: auto; max-width: 100%;">
            </h1>
            <p class="tt-subtitle animate-hero-subtitle">Il punto di riferimento delle attività più consigliate del Ticino.</p>
            <p class="animate-hero-subtitle" style="color: var(--tt-gray-text); margin-bottom: 40px;">Scopri classifiche, guide e badge reputazionali basati su recensioni, reputazione digitale, segnali di fiducia e analisi AI.</p>
            
            <?php 
            $hide_search = get_theme_mod( 'ticinotop_hide_hero_search', false );
            if ( ! $hide_search ) : 
            ?>
            <div class="tt-hero-actions animate-hero-btns">
                <a href="<?php echo home_url('/classifica/'); ?>" class="tt-btn tt-btn-primary">Scopri i migliori</a>
                <a href="<?php echo home_url('/topscan/'); ?>" class="tt-btn tt-btn-premium">Analizza ora la tua azienda</a>
                <a href="<?php echo home_url('/categorie/'); ?>" class="tt-btn tt-btn-outline">Cerca per categoria</a>
            </div>
            
            <!-- Real Search Form with Autocomplete -->
            <div class="animate-hero-search" style="position: relative; max-width: 600px; margin: 40px auto 0;">
                <form id="tt-search-form" role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>" style="background: #fff; padding: 12px; border-radius: 50px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); display: flex;">
                    <input type="hidden" name="post_type" value="azienda">
                    <input type="search" id="tt-search-input" name="s" placeholder="Cerca ristoranti, dentisti, servizi..." value="<?php echo get_search_query(); ?>" autocomplete="off" style="border: none; outline: none; flex: 1; padding: 0 16px; font-size: 16px;" required>
                    <button type="submit" class="tt-btn tt-btn-primary" style="border-radius: 50px; padding: 10px 24px; border: none; cursor: pointer;">Cerca</button>
                </form>
                
                <div id="tt-search-results" style="display: none; position: absolute; top: 100%; left: 0; right: 0; background: #fff; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); margin-top: 10px; z-index: 100; max-height: 380px; overflow-y: auto; overscroll-behavior: contain; text-align: left;">
                    <!-- Results will be injected here via JS -->
                </div>
            </div>
            <?php else : ?>
            <div class="tt-hero-actions animate-hero-btns">
                <a href="<?php echo home_url('/topscan/'); ?>" class="tt-btn tt-btn-premium" style="padding: 16px 36px; font-size: 16px;">Analizza ora la tua azienda</a>
            </div>
            <?php endif; ?>

            <script>
            document.addEventListener('DOMContentLoaded', function() {
                const heroSection = document.querySelector('.tt-hero');
                const searchInput = document.getElementById('tt-search-input');
                const resultsContainer = document.getElementById('tt-search-results');
                
                if (searchInput && resultsContainer) {
                    let timeout = null;

                    const showResults = () => {
                        resultsContainer.style.display = 'block';
                        if (heroSection) {
                            heroSection.classList.add('tt-search-active');
                        }
                    };

                    const hideResults = () => {
                        resultsContainer.style.display = 'none';
                        if (heroSection) {
                            heroSection.classList.remove('tt-search-active');
                        }
                    };

                    searchInput.addEventListener('input', function() {
                        clearTimeout(timeout);
                        const keyword = this.value.trim();

                        if (keyword.length < 2) {
                            hideResults();
                            return;
                        }

                        timeout = setTimeout(() => {
                            const formData = new FormData();
                            formData.append('action', 'tt_autocomplete_search');
                            formData.append('keyword', keyword);

                            fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                                method: 'POST',
                                body: formData
                            })
                            .then(response => response.json())
                            .then(data => {
                                if (data.success && data.data.length > 0) {
                                    let html = '<ul style="list-style: none; margin: 0; padding: 0;">';
                                    data.data.forEach(item => {
                                        html += `
                                        <li style="border-bottom: 1px solid #f1f5f9;">
                                            <a href="${item.url}" style="display: flex; justify-content: space-between; align-items: center; padding: 16px; text-decoration: none; color: var(--tt-black); transition: background 0.2s;">
                                                <div>
                                                    <div style="font-weight: 600; margin-bottom: 4px;">${item.title}</div>
                                                    <div style="font-size: 12px; color: var(--tt-gray-text);">${item.category}</div>
                                                </div>
                                                <div style="display: flex; align-items: center; gap: 4px; color: var(--tt-gold-champagne); font-weight: 600; font-size: 14px;">
                                                    <span>★</span> ${item.score}
                                                </div>
                                            </a>
                                        </li>`;
                                    });
                                    html += '</ul>';
                                    resultsContainer.innerHTML = html;
                                    showResults();
                                    
                                    // Add hover effects
                                    const links = resultsContainer.querySelectorAll('a');
                                    links.forEach(link => {
                                        link.addEventListener('mouseenter', () => link.style.background = '#f8fafc');
                                        link.addEventListener('mouseleave', () => link.style.background = 'transparent');
                                    });
                                } else {
                                    resultsContainer.innerHTML = '<div style="padding: 16px; color: var(--tt-gray-text); text-align: center;">Nessun risultato trovato</div>';
                                    showResults();
                                }
                            })
                            .catch(() => {
                                hideResults();
                            });
                        }, 300); // 300ms debounce
                    });

                    // Hide when clicking outside
                    document.addEventListener('click', function(e) {
                        if (!searchInput.contains(e.target) && !resultsContainer.contains(e.target)) {
                            hideResults();
                        }
                    });
                    
                    // Show again when focusing if there's text
                    searchInput.addEventListener('focus', function() {
                        if (this.value.trim().length >= 2 && resultsContainer.innerHTML !== '') {
                            showResults();
                        }
                    });

                    // Prevent background scrolling when scrolling inside or over results container
                    resultsContainer.addEventListener('wheel', function(e) {
                        const scrollTop = this.scrollTop;
                        const scrollHeight = this.scrollHeight;
                        const height = this.clientHeight;
                        const delta = e.deltaY;
                        
                        // If content is not scrollable, block all wheel events
                        if (scrollHeight <= height) {
                            e.preventDefault();
                            return;
                        }
                        
                        // If scrolling up at the top, or down at the bottom, prevent default
                        if (delta < 0 && scrollTop <= 0) {
                            e.preventDefault();
                        } else if (delta > 0 && scrollTop + height >= scrollHeight) {
                            e.preventDefault();
                        }
                    }, { passive: false });

                    // Also prevent touchmove chaining on mobile devices
                    let touchStartY = 0;
                    resultsContainer.addEventListener('touchstart', function(e) {
                        if (e.touches.length === 1) {
                            touchStartY = e.touches[0].clientY;
                        }
                    }, { passive: true });

                    resultsContainer.addEventListener('touchmove', function(e) {
                        if (e.touches.length !== 1) return;
                        
                        const touchY = e.touches[0].clientY;
                        const deltaY = touchStartY - touchY; // positive = scrolling down, negative = scrolling up
                        const scrollTop = this.scrollTop;
                        const scrollHeight = this.scrollHeight;
                        const height = this.clientHeight;
                        
                        if (scrollHeight <= height) {
                            if (e.cancelable) e.preventDefault();
                            return;
                        }
                        
                        if (deltaY < 0 && scrollTop <= 0) {
                            if (e.cancelable) e.preventDefault();
                        } else if (deltaY > 0 && scrollTop + height >= scrollHeight) {
                            if (e.cancelable) e.preventDefault();
                        }
                    }, { passive: false });
                }

                // Smooth scroll for the down arrow
                const scrollArrow = document.querySelector('.tt-scroll-down-arrow');
                if (scrollArrow) {
                    scrollArrow.addEventListener('click', function(e) {
                        e.preventDefault();
                        const targetId = this.getAttribute('href');
                        const target = document.querySelector(targetId);
                        if (target) {
                            const header = document.querySelector('.tt-header');
                            const headerHeight = header ? header.offsetHeight : 80;
                            const targetPosition = target.getBoundingClientRect().top + window.pageYOffset - headerHeight + 50; // Scroll past 50px of top padding for a snugger fit
                            const startPosition = window.pageYOffset;
                            const distance = targetPosition - startPosition;
                            const duration = 1000; // Premium, elegant fluid transition (1 second)
                            let startTime = null;

                            function easeInOutCubic(t, b, c, d) {
                                t /= d / 2;
                                if (t < 1) return c / 2 * t * t * t + b;
                                t -= 2;
                                return c / 2 * (t * t * t + 2) + b;
                            }

                            function animation(currentTime) {
                                if (startTime === null) startTime = currentTime;
                                const timeElapsed = currentTime - startTime;
                                const run = easeInOutCubic(timeElapsed, startPosition, distance, duration);
                                window.scrollTo(0, run);
                                if (timeElapsed < duration) {
                                    requestAnimationFrame(animation);
                                } else {
                                    window.scrollTo(0, targetPosition);
                                }
                            }
                            requestAnimationFrame(animation);
                        }
                    });
                }
            });
            </script>
        </div>

        <!-- Golden Woven Fabric — animated canvas (threads + weaving stars) -->

        <script>
        (function() {
            var canvas = document.getElementById('tt-golden-fabric');
            if (!canvas) return;
            var ctx = canvas.getContext('2d');

            function resizeCanvas() {
                canvas.width  = window.innerWidth;
                canvas.height = window.innerHeight;
            }
            resizeCanvas();
            window.addEventListener('resize', resizeCanvas);

            /* ─── Palette ────────────────────────────────────────────── */
            var GOLD  = { r: 212, g: 175, b: 55  };
            var AMBER = { r: 200, g: 160, b: 40  };
            var PALE  = { r: 255, g: 238, b: 165 };

            /* ─── Warp threads (horizontal) — more movement ─────────── */
            var WARP = 18;
            var warpDef = [];
            var warpPal = [GOLD, AMBER, PALE, GOLD, AMBER, PALE];
            for (var i = 0; i < WARP; i++) {
                var c = warpPal[i % warpPal.length];
                warpDef.push({
                    yFrac : i / (WARP - 1),
                    half  : 3.5 + Math.random() * 3,
                    amp   : 14 + Math.random() * 18,        // was 5–15, now 14–32
                    freq  : 0.0007 + Math.random() * 0.001,
                    speed : 0.00022 + Math.random() * 0.00016,  // was ~0.0001, now ~0.0003
                    phase : Math.random() * Math.PI * 2,
                    r: c.r, g: c.g, b: c.b,
                    alpha : 0.030 + Math.random() * 0.022,
                });
            }

            /* ─── Weft threads (vertical) — more movement ───────────── */
            var WEFT = 22;
            var weftDef = [];
            var weftPal = [PALE, GOLD, AMBER, PALE, GOLD];
            for (var j = 0; j < WEFT; j++) {
                var d = weftPal[j % weftPal.length];
                weftDef.push({
                    xFrac : j / (WEFT - 1),
                    half  : 3 + Math.random() * 2.5,
                    amp   : 12 + Math.random() * 14,        // was 4–12, now 12–26
                    freq  : 0.0010 + Math.random() * 0.0014,
                    speed : 0.00026 + Math.random() * 0.00018,
                    phase : Math.random() * Math.PI * 2,
                    r: d.r, g: d.g, b: d.b,
                    alpha : 0.022 + Math.random() * 0.018,
                });
            }

            var startTime = performance.now();
            var rafId;

            /* ─── Draw a filled 5-pointed star ──────────────────────── */
            function drawStar(cx, cy, size, alpha) {
                ctx.beginPath();
                for (var p = 0; p < 5; p++) {
                    // Outer tip: step 72° each (2π/5), starting from top (-90°)
                    var outerA = (p * 2 * Math.PI / 5) - Math.PI / 2;
                    // Inner dip: 36° after each outer tip (π/5)
                    var innerA = outerA + Math.PI / 5;
                    var ox = cx + size * Math.cos(outerA);
                    var oy = cy + size * Math.sin(outerA);
                    var ix = cx + size * 0.382 * Math.cos(innerA);
                    var iy = cy + size * 0.382 * Math.sin(innerA);
                    if (p === 0) ctx.moveTo(ox, oy); else ctx.lineTo(ox, oy);
                    ctx.lineTo(ix, iy);
                }
                ctx.closePath();
                ctx.fillStyle = 'rgba(212,175,55,' + alpha + ')';
                ctx.fill();
            }

            /* ─── Draw weaving star field ────────────────────────────── */
            function drawStars(t, W, H) {
                var spacing = 190;
                var cols = Math.ceil(W / spacing) + 1;
                var rows = Math.ceil(H / spacing) + 1;
                for (var r = 0; r < rows; r++) {
                    for (var c = 0; c < cols; c++) {
                        var bx = (c - 0.5) * spacing;
                        var by = (r - 0.5) * spacing;
                        var dx = 15 * Math.sin(by * 0.009  + t * 0.00020 + c * 1.1);
                        var dy = 13 * Math.sin(bx * 0.0110 + t * 0.00017 + r * 0.8);
                        var sz = 7 + 2 * Math.sin(t * 0.00025 + c * 0.6 + r * 0.9);
                        // Opacity breathes between 5.0% and 10.0%
                        var al = 0.075 + 0.025 * Math.sin(t * 0.00030 + c * 0.5 + r * 1.1);
                        drawStar(bx + dx, by + dy, sz, al);
                    }
                }
            }

            /* ─── Ribbon helpers ─────────────────────────────────────── */
            function drawWarpRibbon(l, t, W, H) {
                var baseY = l.yFrac * H;
                var STEP = 6, steps = Math.ceil(W / STEP);
                ctx.beginPath();
                for (var s = 0; s <= steps; s++) {
                    var x = s * STEP;
                    var y = baseY + l.amp * Math.sin(x * l.freq + l.phase + t * l.speed) - l.half;
                    if (s === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
                }
                for (var s2 = steps; s2 >= 0; s2--) {
                    var x2 = s2 * STEP;
                    ctx.lineTo(x2, baseY + l.amp * Math.sin(x2 * l.freq + l.phase + t * l.speed) + l.half);
                }
                ctx.closePath();
                ctx.fillStyle = 'rgba(' + l.r + ',' + l.g + ',' + l.b + ',' + l.alpha + ')';
                ctx.fill();
            }

            function drawWeftRibbon(l, t, W, H) {
                var baseX = l.xFrac * W;
                var STEP = 6, steps = Math.ceil(H / STEP);
                ctx.beginPath();
                for (var s = 0; s <= steps; s++) {
                    var y = s * STEP;
                    var x = baseX + l.amp * Math.sin(y * l.freq + l.phase + t * l.speed) - l.half;
                    if (s === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
                }
                for (var s2 = steps; s2 >= 0; s2--) {
                    var y2 = s2 * STEP;
                    ctx.lineTo(baseX + l.amp * Math.sin(y2 * l.freq + l.phase + t * l.speed) + l.half, y2);
                }
                ctx.closePath();
                ctx.fillStyle = 'rgba(' + l.r + ',' + l.g + ',' + l.b + ',' + l.alpha + ')';
                ctx.fill();
            }

            /* ─── Main render loop ───────────────────────────────────── */
            function drawFrame(now) {
                var t = now - startTime;
                var W = canvas.width;
                var H = canvas.height;

                ctx.clearRect(0, 0, W, H);

                // Warm ivory base
                var bg = ctx.createLinearGradient(0, 0, 0, H);
                bg.addColorStop(0, '#FEFBF2');
                bg.addColorStop(1, '#FAF5E4');
                ctx.fillStyle = bg;
                ctx.fillRect(0, 0, W, H);

                // 1. Warp threads
                for (var wi = 0; wi < warpDef.length; wi++) drawWarpRibbon(warpDef[wi], t, W, H);
                // 2. Weft threads
                for (var wj = 0; wj < weftDef.length; wj++) drawWeftRibbon(weftDef[wj], t, W, H);
                // 3. Weaving stars (drawn on canvas so they animate)
                drawStars(t, W, H);
                // 4. Gentle silk sheen travelling slowly down
                var shY = ((t * 0.000022) % 1.0) * (H + 160) - 80;
                var sg  = ctx.createLinearGradient(0, shY - 80, 0, shY + 80);
                sg.addColorStop(0,   'rgba(255,245,190,0)');
                sg.addColorStop(0.5, 'rgba(255,248,200,0.05)');
                sg.addColorStop(1,   'rgba(255,245,190,0)');
                ctx.fillStyle = sg;
                ctx.fillRect(0, shY - 80, W, 160);

                rafId = requestAnimationFrame(drawFrame);
            }

            rafId = requestAnimationFrame(drawFrame);

            document.addEventListener('visibilitychange', function() {
                if (document.hidden) { cancelAnimationFrame(rafId); }
                else { rafId = requestAnimationFrame(drawFrame); }
            });
        })();
        </script>

        <!-- Style and Markup for scroll down arrow -->
        <style>
        @keyframes bounceArrow {
            0%, 20%, 50%, 80%, 100% {
                transform: translateY(0);
            }
            40% {
                transform: translateY(-8px);
            }
            60% {
                transform: translateY(-4px);
            }
        }
        .bounce-arrow {
            animation: bounceArrow 2s infinite;
        }
        .tt-scroll-down-arrow {
            color: var(--tt-black, #0f172a);
            font-size: 24px;
            text-decoration: none;
            display: inline-flex;
            flex-direction: column;
            align-items: center;
            gap: 8px;
            transition: color 0.3s, transform 0.3s;
            cursor: pointer;
        }
        .tt-scroll-down-arrow:hover {
            color: var(--tt-gold-champagne, #d4af37) !important;
        }
        .tt-scroll-down-arrow:hover .bounce-arrow {
            animation-play-state: paused;
        }
        .animate-hero-arrow {
            position: absolute;
            bottom: -25px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 15;
            text-align: center;
            transition: opacity 0.3s ease, transform 0.3s ease;
        }
        .tt-search-active .animate-hero-arrow {
            opacity: 0;
            pointer-events: none;
            transform: translate(-50%, 20px);
        }
        </style>

        <!-- Scroll Down Arrow -->
        <div class="animate-hero-arrow">
            <?php
            $hide_classifiche = get_theme_mod('ticinotop_hide_classifiche_evidenza', false);
            $is_blog_home = get_theme_mod('ticinotop_home_blog_layout', false);
            if ($is_blog_home) {
                $scroll_target = '#tt-blog-sezione';
            } else {
                $scroll_target = $hide_classifiche ? '#doppia-validazione' : '#classifiche-in-evidenza';
            }
            ?>
            <a href="<?php echo esc_attr($scroll_target); ?>" class="tt-scroll-down-arrow">
                <span style="font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.15em; color: var(--tt-gray-text);">Scopri di più</span>
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="bounce-arrow">
                    <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
            </a>
        </div>
    </section>

    <?php if ( get_theme_mod( 'ticinotop_home_blog_layout', false ) ) : ?>
        <!-- Sezione Blog Articoli -->
        <section id="tt-blog-sezione" class="tt-section" style="position: relative; z-index: 5; background: transparent; padding: 100px 0;">
            <div class="tt-container">
                <div style="text-align: center; margin-bottom: 60px;">
                    <span class="tt-badge" style="background: rgba(10,25,47,0.05); border-color: rgba(10,25,47,0.1); color: var(--tt-blue-notte); margin-bottom: 16px;">News</span>
                    <h2 class="reveal-on-scroll" style="font-family: var(--tt-font-serif); font-size: 44px; margin-bottom: 16px; color: var(--tt-black); font-weight: 700;">Storie & Insight</h2>
                    <p class="reveal-on-scroll" style="font-size: 18px; color: var(--tt-gray-text); max-width: 600px; margin: 0 auto; line-height: 1.6;">Letture di approfondimento sul mondo della reputazione digitale, dell'intelligenza artificiale e delle eccellenze del Ticino.</p>
                </div>

                <?php
                // 1. Query for the latest post to display as featured
                $featured_args = [
                    'post_type' => 'post',
                    'post_status' => 'publish',
                    'posts_per_page' => 1,
                    'orderby' => 'date',
                    'order' => 'DESC',
                ];
                $featured_query = new WP_Query($featured_args);
                $featured_id = 0;
                $featured_post = null;

                if ($featured_query->have_posts()) {
                    $featured_query->the_post();
                    $featured_id = get_the_ID();
                    $categories = get_the_category();
                    $featured_post = [
                        'id' => $featured_id,
                        'title' => get_the_title(),
                        'excerpt' => get_the_excerpt() ?: wp_trim_words(get_the_content(), 25),
                        'img' => get_the_post_thumbnail_url($featured_id, 'full') ?: get_stylesheet_directory_uri() . '/images/category-default.jpg',
                        'url' => get_permalink(),
                        'category' => ($categories) ? $categories[0]->name : 'Trend & Insight',
                        'date' => get_the_date('j F Y'),
                    ];
                    wp_reset_postdata();
                }

                // 2. Query remaining grid posts
                $grid_posts = [];
                $grid_args = [
                    'post_type' => 'post',
                    'post_status' => 'publish',
                    'posts_per_page' => 6,
                ];
                if ($featured_id > 0) {
                    $grid_args['post__not_in'] = [$featured_id];
                }
                $blog_query = new WP_Query($grid_args);
                if ($blog_query->have_posts()) {
                    while ($blog_query->have_posts()) {
                        $blog_query->the_post();
                        $p_id = get_the_ID();
                        $categories = get_the_category();
                        $grid_posts[] = [
                            'id' => $p_id,
                            'title' => get_the_title(),
                            'excerpt' => get_the_excerpt() ?: wp_trim_words(get_the_content(), 25),
                            'img' => get_the_post_thumbnail_url($p_id, 'full') ?: get_stylesheet_directory_uri() . '/images/category-default.jpg',
                            'url' => get_permalink(),
                            'category' => ($categories) ? $categories[0]->name : 'Trend & Insight',
                            'date' => get_the_date('j F Y'),
                        ];
                    }
                    wp_reset_postdata();
                }
                ?>

                <?php if ($featured_post) : ?>
                    <!-- Featured Article -->
                    <div class="tt-card reveal-on-scroll tt-featured-hero" style="display: flex; flex-direction: row; margin-bottom: 60px; min-height: 450px; overflow: hidden; border-radius: var(--tt-radius-lg); box-shadow: var(--tt-shadow-premium); border: 1px solid var(--tt-gray-border); padding: 0;">
                        <div class="tt-featured-hero-img" style="width: 55%; background: url('<?php echo esc_url($featured_post['img']); ?>') center/cover; position: relative; min-height: 350px;">
                            <div style="position: absolute; inset: 0; background: linear-gradient(to right, transparent 50%, rgba(255,255,255,0.05));"></div>
                        </div>
                        <div class="tt-featured-hero-body" style="width: 45%; padding: 48px; display: flex; flex-direction: column; justify-content: center; background: var(--tt-white);">
                            <div class="tt-badge tt-badge-dark" style="margin-bottom: 24px; align-self: flex-start; background: var(--tt-blue-notte); border-color: var(--tt-blue-notte); color: var(--tt-white);"><?php echo esc_html($featured_post['category']); ?></div>
                            <?php if (tt_show_post_dates()) : ?><span style="font-size: 13px; color: var(--tt-gray-text); margin-bottom: 12px; font-weight: 500;"><?php echo esc_html($featured_post['date']); ?></span><?php endif; ?>
                            <h2 style="font-family: var(--tt-font-serif); font-size: 36px; margin: 0 0 16px 0; line-height: 1.2; color: var(--tt-black);">
                                <a class="tt-featured-title-link" href="<?php echo esc_url($featured_post['url']); ?>" style="color: inherit; text-decoration: none; transition: color 0.3s ease;"><?php echo esc_html($featured_post['title']); ?></a>
                            </h2>
                            <p style="font-size: 16px; color: var(--tt-gray-text); margin-bottom: 32px; line-height: 1.6;"><?php echo esc_html($featured_post['excerpt']); ?></p>
                            <a href="<?php echo esc_url($featured_post['url']); ?>" class="tt-btn tt-btn-primary" style="align-self: flex-start;">Leggi l'Articolo</a>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if (!empty($grid_posts)) : ?>
                    <!-- Grid Articles -->
                    <div class="tt-grid-3 reveal-grid">
                        <?php foreach ($grid_posts as $post) : ?>
                            <a href="<?php echo esc_url($post['url']); ?>" class="tt-card tt-blog-card" style="display: flex; flex-direction: column; text-decoration: none; border-radius: var(--tt-radius-md); overflow: hidden; background: var(--tt-white); box-shadow: var(--tt-shadow-sm); border: 1px solid var(--tt-gray-border); height: 100%; transition: all 0.3s ease; padding: 0; box-shadow: none;">
                                <div style="height: 240px; background: url('<?php echo esc_url($post['img']); ?>') center/cover; position: relative;">
                                    <div style="position: absolute; top: 16px; left: 16px;">
                                        <span class="tt-badge" style="background: rgba(255,255,255,0.95); backdrop-filter: blur(4px); -webkit-backdrop-filter: blur(4px); color: var(--tt-black); border-color: rgba(255,255,255,0.5); font-weight: 600;"><?php echo esc_html($post['category']); ?></span>
                                    </div>
                                </div>
                                <div style="padding: 28px; flex-grow: 1; display: flex; flex-direction: column; justify-content: space-between; background: var(--tt-white);">
                                    <div>
                                        <?php if (tt_show_post_dates()) : ?><span style="color: var(--tt-gray-text); font-size: 12px; display: block; margin-bottom: 12px; font-weight: 500;"><?php echo esc_html($post['date']); ?></span><?php endif; ?>
                                        <h3 style="font-size: 22px; margin: 0 0 12px 0; font-family: var(--tt-font-serif); color: var(--tt-black); line-height: 1.3; transition: color 0.3s ease;"><?php echo esc_html($post['title']); ?></h3>
                                        <p style="font-size: 14.5px; color: var(--tt-gray-text); margin: 0; line-height: 1.6; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden;"><?php echo esc_html($post['excerpt']); ?></p>
                                    </div>
                                    <div style="margin-top: 24px; font-weight: 600; font-size: 14px; color: var(--tt-gold-champagne); display: flex; align-items: center; gap: 4px;">
                                        Leggi Articolo →
                                    </div>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    </div>

                    <div class="reveal-on-scroll" style="text-align: center; margin-top: 50px;">
                        <a href="<?php echo home_url('/news/'); ?>" class="tt-btn tt-btn-primary">VEDI TUTTI GLI ARTICOLI</a>
                    </div>
                <?php else : ?>
                    <div class="tt-card" style="text-align: center; padding: 60px; background: var(--tt-white);">
                        <p style="color: var(--tt-gray-text); font-size: 18px; margin: 0;">Nessun articolo pubblicato nel blog al momento.</p>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <style>
        .tt-blog-card:hover {
            transform: translateY(-6px);
            border-color: rgba(212, 175, 55, 0.4) !important;
            box-shadow: var(--tt-shadow-premium) !important;
        }
        .tt-blog-card:hover h3, .tt-featured-title-link:hover {
            color: var(--tt-gold-champagne) !important;
        }
        </style>
    <?php else : ?>
        <!-- Classifiche in Evidenza -->
        <?php if ( ! get_theme_mod('ticinotop_hide_classifiche_evidenza', false) ) : ?>
        <section id="classifiche-in-evidenza" class="tt-section" style="position: relative; z-index: 5; background: var(--tt-white); padding: 100px 0;">
        <div class="tt-container" style="padding: 40px 0;">
            <h2 class="reveal-on-scroll" style="font-family: var(--tt-font-serif); font-size: 32px; margin-bottom: 40px; text-align: center;">Classifiche in Evidenza</h2>
            
            <div class="tt-grid-3 reveal-grid">
                <?php 
                // First query: Classifiche in Evidenza explicitly checked
                $args = [
                    'post_type' => 'classifica',
                    'posts_per_page' => 3,
                    'meta_query' => [
                        [
                            'key' => '_tt_classifica_evidenza',
                            'value' => '1',
                            'compare' => '='
                        ]
                    ]
                ];
                $classifiche_query = new WP_Query($args);
                
                // Fallback: if fewer than 3, get the latest classifiche to fill the 3 slots
                if ($classifiche_query->post_count < 3) {
                    $exclude_ids = wp_list_pluck($classifiche_query->posts, 'ID');
                    $needed = 3 - $classifiche_query->post_count;
                    $fallback_args = [
                        'post_type' => 'classifica',
                        'posts_per_page' => $needed,
                        'post__not_in' => !empty($exclude_ids) ? $exclude_ids : [],
                        'orderby' => 'date',
                        'order' => 'DESC'
                    ];
                    $fallback_query = new WP_Query($fallback_args);
                    
                    // Merge posts
                    $merged_posts = array_merge($classifiche_query->posts, $fallback_query->posts);
                    $classifiche_query->posts = $merged_posts;
                    $classifiche_query->post_count = count($merged_posts);
                }
                
                if ($classifiche_query->have_posts()) :
                    while ($classifiche_query->have_posts()) : $classifiche_query->the_post();
                        
                        $post_id = get_the_ID();
                        $image_url = get_post_meta($post_id, '_tt_image', true);
                        if (!$image_url) {
                            $image_url = get_the_post_thumbnail_url($post_id, 'large');
                        }
                        if (!$image_url) {
                            $image_url = get_stylesheet_directory_uri() . '/images/category-default.jpg'; // fallback
                        }
                        
                        $badge = get_post_meta($post_id, '_tt_classifica_badge', true) ?: 'Top Classifica';
                ?>
                        <a href="<?php the_permalink(); ?>" class="tt-classifica-card" style="display: block; position: relative; overflow: hidden; border-radius: 20px; text-decoration: none; box-shadow: 0 20px 40px rgba(0,0,0,0.4);">
                            <div style="position: relative; aspect-ratio: 3/4; overflow: hidden;">
                                <img src="<?php echo esc_url($image_url); ?>" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.8s cubic-bezier(0.4, 0, 0.2, 1);" alt="<?php the_title_attribute(); ?>">
                                
                                <div style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: linear-gradient(to top, rgba(10,25,47,0.95) 0%, rgba(10,25,47,0.4) 50%, rgba(10,25,47,0) 100%);"></div>
                                
                                <div style="position: absolute; bottom: 0; left: 0; right: 0; padding: 40px 32px; z-index: 2; display: flex; flex-direction: column; justify-content: flex-end; height: 100%;">
                                    
                                    <div class="tt-badge-hover" style="margin-bottom: 16px; background: rgba(212, 175, 55, 0.2); color: var(--tt-gold-champagne); padding: 6px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; display: inline-block; width: max-content; border: 1px solid rgba(212, 175, 55, 0.5); backdrop-filter: blur(4px);">
                                        <?php echo esc_html($badge); ?>
                                    </div>
                                    
                                    <h3 style="color: var(--tt-white); font-family: var(--tt-font-serif); font-size: 24px; line-height: 1.2; margin-bottom: 16px; text-shadow: 0 4px 12px rgba(0,0,0,0.5);">
                                        <?php the_title(); ?>
                                    </h3>
                                    
                                    <p style="color: #cbd5e1; font-size: 14px; margin: 0; line-height: 1.6; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; opacity: 0.8;">
                                        <?php echo get_the_excerpt(); ?>
                                    </p>
                                </div>
                            </div>
                        </a>
                <?php 
                    endwhile;
                    wp_reset_postdata();
                else:
                    echo '<p style="text-align:center; grid-column: 1/-1; color: var(--tt-gray-text);">Nessuna classifica disponibile.</p>';
                endif;
                ?>
            </div>
            
            <div class="reveal-on-scroll" style="text-align: center; margin-top: 40px;">
                <a href="<?php echo home_url('/classifica/'); ?>" class="tt-btn tt-btn-outline">Vedi tutte le classifiche</a>
            </div>
        </div>
        
        <style>
        .tt-classifica-card img {
            transition: transform 0.8s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .tt-classifica-card:hover img {
            transform: scale(1.08);
        }
        .tt-classifica-card::after {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            border-radius: 20px;
            border: 1px solid rgba(255,255,255,0.1);
            transition: all 0.4s ease;
            z-index: 3;
            pointer-events: none;
        }
        .tt-classifica-card:hover::after {
            border-color: var(--tt-gold-champagne);
            box-shadow: inset 0 0 0 1px var(--tt-gold-champagne);
        }
        .tt-classifica-card p {
            opacity: 0.7;
            transition: opacity 0.3s ease;
        }
        .tt-classifica-card:hover p {
            opacity: 1;
        }
        </style>
    </section>
    <?php endif; ?>

    <!-- Sezione FOMO ed Esclusività per le Aziende -->
    <section class="tt-section" style="position: relative; z-index: 10; background: transparent; padding: 120px 0; color: var(--tt-black); overflow: hidden; border-top: 1px solid rgba(212, 175, 55, 0.15);">
        <!-- Glowing decorative background radial lights -->
        <div style="position: absolute; top: -10%; left: -10%; width: 40%; height: 40%; background: radial-gradient(circle, rgba(212, 175, 55, 0.08) 0%, rgba(212, 175, 55, 0) 70%); pointer-events: none; z-index: 1;"></div>
        <div style="position: absolute; bottom: -10%; right: -10%; width: 40%; height: 40%; background: radial-gradient(circle, rgba(212, 175, 55, 0.05) 0%, rgba(212, 175, 55, 0) 70%); pointer-events: none; z-index: 1;"></div>

        <div class="tt-container" style="position: relative; z-index: 5;">
            <div style="text-align: center; max-width: 800px; margin: 0 auto 60px;">
                <h2 class="reveal-on-scroll" style="font-family: var(--tt-font-serif); font-size: 46px; line-height: 1.15; color: var(--tt-black); margin-bottom: 24px;">
                    La tua attività è nell'Elite?<br>
                    <span style="background: linear-gradient(135deg, #031836 30%, var(--tt-gold-champagne) 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">Se non ci sei... stai perdendo clienti ogni singolo giorno.</span>
                </h2>
                <p class="reveal-on-scroll" style="font-size: 19px; color: #475569; line-height: 1.6; margin: 0;">
                    Il Sigillo d'Oro Ticino Top non è in vendita ed è riservato esclusivamente al <strong>miglior 5% delle attività</strong>. Ogni giorno, migliaia di ticinesi scelgono dove cenare, a quale medico affidarsi o chi contattare basandosi sulle nostre classifiche. Senza la nostra certificazione reputazionale, stai silenziosamente cedendo credibilità e fatturato ai tuoi competitor ammessi.
                </p>
            </div>

            <!-- Staggered FOMO Metrics Grid -->
            <div class="tt-grid-3 reveal-grid" style="gap: 30px; margin-bottom: 70px;">
                <!-- Card 1 -->
                <div style="background: rgba(255, 255, 255, 0.75); border: 1px solid rgba(212, 175, 55, 0.2); border-radius: 24px; padding: 40px 32px; text-align: left; box-shadow: 0 10px 30px rgba(0,0,0,0.03); backdrop-filter: blur(10px); transition: all 0.3s ease; position: relative;" onmouseover="this.style.borderColor='rgba(212,175,55,0.5)'; this.style.transform='translateY(-5px)'; this.style.boxShadow='0 15px 40px rgba(212,175,55,0.08)'" onmouseout="this.style.borderColor='rgba(212,175,55,0.2)'; this.style.transform='translateY(0)'; this.style.boxShadow='0 10px 30px rgba(0,0,0,0.03)'">
                    <div style="font-size: 54px; font-weight: 800; color: var(--tt-gold-champagne); margin-bottom: 12px; line-height: 1; font-family: var(--tt-font-serif);">92%</div>
                    <h3 style="font-size: 20px; color: var(--tt-black); margin-bottom: 12px; font-weight: 600;">Fattore di Esclusione</h3>
                    <p style="color: #475569; font-size: 14px; margin: 0; line-height: 1.6;">
                        Dei consumatori alto-spendenti in Ticino sceglie <em>esclusivamente</em> attività certificate Ticino Top prima di acquistare o prenotare. Se il tuo brand è assente, sei matematicamente escluso dalla loro decisione d'acquisto.
                    </p>
                </div>
                <!-- Card 2 -->
                <div style="background: rgba(255, 255, 255, 0.75); border: 1px solid rgba(212, 175, 55, 0.2); border-radius: 24px; padding: 40px 32px; text-align: left; box-shadow: 0 10px 30px rgba(0,0,0,0.03); backdrop-filter: blur(10px); transition: all 0.3s ease; position: relative;" onmouseover="this.style.borderColor='rgba(212,175,55,0.5)'; this.style.transform='translateY(-5px)'; this.style.boxShadow='0 15px 40px rgba(212,175,55,0.08)'" onmouseout="this.style.borderColor='rgba(212,175,55,0.2)'; this.style.transform='translateY(0)'; this.style.boxShadow='0 10px 30px rgba(0,0,0,0.03)'">
                    <div style="font-size: 54px; font-weight: 800; color: #ef4444; margin-bottom: 12px; line-height: 1; font-family: var(--tt-font-serif);">-27%</div>
                    <h3 style="font-size: 20px; color: var(--tt-black); margin-bottom: 12px; font-weight: 600;">Perdita di Clienti</h3>
                    <p style="color: #475569; font-size: 14px; margin: 0; line-height: 1.6;">
                        Rappresenta la contrazione media registrata nei tassi di scelta per le attività prive di Badge Ticino Top rispetto ai competitor certificati. Senza il Sigillo d'Oro, molti utenti scelgono di passare a un concorrente.
                    </p>
                </div>
                <!-- Card 3 -->
                <div style="background: rgba(255, 255, 255, 0.75); border: 1px solid rgba(212, 175, 55, 0.35); border-radius: 24px; padding: 40px 32px; text-align: left; box-shadow: 0 10px 30px rgba(212,175,55,0.04); backdrop-filter: blur(10px); transition: all 0.3s ease; position: relative;" onmouseover="this.style.borderColor='rgba(212,175,55,0.6)'; this.style.transform='translateY(-5px)'; this.style.boxShadow='0 15px 40px rgba(212,175,55,0.1)'" onmouseout="this.style.borderColor='rgba(212,175,55,0.35)'; this.style.transform='translateY(0)'; this.style.boxShadow='0 10px 30px rgba(212,175,55,0.04)'">
                    <div style="position: absolute; top: 20px; right: 20px; font-size: 24px;">🏆</div>
                    <div style="font-size: 54px; font-weight: 800; color: var(--tt-gold-champagne); margin-bottom: 12px; line-height: 1; font-family: var(--tt-font-serif);">TOP 5</div>
                    <h3 style="font-size: 20px; color: var(--tt-black); margin-bottom: 12px; font-weight: 600;">Sbarramento Rigido</h3>
                    <p style="color: #475569; font-size: 14px; margin: 0; line-height: 1.6;">
                        I posti in classifica sono rigorosamente limitati. L'ammissione è basata su standard scientifici non manipolabili: o meriti lo status di eccellenza certificata, o lasci che sia il tuo concorrente diretto a raccogliere i frutti del prestigio.
                    </p>
                </div>
            </div>

            <!-- Highly Urging Dynamic CTA Callout -->
            <div class="reveal-on-scroll" style="background: rgba(255, 255, 255, 0.85); border: 1px solid rgba(212, 175, 55, 0.35); border-radius: 30px; padding: 50px 40px; text-align: center; max-width: 900px; margin: 0 auto; box-shadow: 0 20px 50px rgba(212, 175, 55, 0.08); backdrop-filter: blur(10px);">
                <h3 style="font-family: var(--tt-font-serif); font-size: 28px; color: var(--tt-black); margin-top: 0; margin-bottom: 16px;">
                    Non rischiare l'invisibilità. La tua attività ha i requisiti per entrare?
                </h3>
                <p style="color: #475569; font-size: 16px; margin-bottom: 32px; max-width: 720px; margin-left: auto; margin-right: auto; line-height: 1.6;">
                    Avvia all'istante l'analisi diagnostica con il nostro scanner gratuito <strong>TopScan™</strong> o invia la tua candidatura formale per la sessione di audit in corso prima che gli slot reputazionali per la tua categoria vengano blindati.
                </p>
                <div style="display: flex; gap: 20px; justify-content: center; flex-wrap: wrap;">
                    <a href="<?php echo home_url('/topscan/'); ?>" class="tt-btn tt-btn-primary" style="padding: 16px 36px; font-size: 15px; font-weight: 700; border-radius: 50px; background: var(--tt-gold-champagne); color: var(--tt-black); text-decoration: none; display: inline-flex; align-items: center; gap: 8px; box-shadow: 0 8px 24px rgba(212,175,55,0.25); transition: all 0.3s; transform: translateY(0);" onmouseover="this.style.transform='translateY(-3px)'; this.style.boxShadow='0 12px 30px rgba(212,175,55,0.4)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 8px 24px rgba(212,175,55,0.25)'">
                        <span class="dashicons dashicons-superhero" style="margin-top:2px;"></span> Verifica la tua Attività (TopScan™)
                    </a>
                    <a href="<?php echo home_url('/candidati/'); ?>" class="tt-btn tt-btn-outline" style="padding: 16px 36px; font-size: 15px; font-weight: 700; border-radius: 50px; border: 2px solid rgba(0, 0, 0, 0.2); color: var(--tt-black); text-decoration: none; display: inline-flex; align-items: center; gap: 8px; transition: all 0.3s; transform: translateY(0); background: transparent;" onmouseover="this.style.borderColor='var(--tt-gold-champagne)'; this.style.color='var(--tt-gold-champagne)'; this.style.transform='translateY(-3px)';" onmouseout="this.style.borderColor='rgba(0, 0, 0, 0.2)'; this.style.color='var(--tt-black)'; this.style.transform='translateY(0)';">
                        Candidati Ora
                    </a>
                </div>
            </div>
        </div>

        <style>
        @keyframes tt-pulse {
            0% {
                transform: scale(0.95);
                box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.7);
            }
            70% {
                transform: scale(1);
                box-shadow: 0 0 0 8px rgba(239, 68, 68, 0);
            }
            100% {
                transform: scale(0.95);
                box-shadow: 0 0 0 0 rgba(239, 68, 68, 0);
            }
        }
        </style>
    </section>

    <!-- Doppia Validazione -->
    <section id="doppia-validazione" class="tt-section tt-section-dark" style="position: relative; z-index: 30; background: var(--tt-black); border-radius: 40px 40px 0 0; box-shadow: 0 -20px 50px rgba(0,0,0,0.5); padding: 100px 0 60px;">
        <div class="tt-container" style="text-align: center;">
            <h2 class="reveal-on-scroll" style="font-family: var(--tt-font-serif); font-size: 36px; margin-bottom: 24px; color: var(--tt-gold-champagne);">Persone + AI</h2>
            <p class="reveal-on-scroll" style="max-width: 700px; margin: 0 auto 40px; font-size: 18px; color: #cbd5e1;">
                Il nostro differenziante principale. Non classifichiamo in base a chi paga di più, ma attraverso l'analisi oggettiva di migliaia di segnali pubblici, validati dall'intelligenza artificiale.
            </p>
            <div class="tt-grid-3 reveal-grid">
                <div style="padding: 24px; border: 1px solid rgba(255,255,255,0.1); border-radius: var(--tt-radius-md);">
                    <h3 style="color: var(--tt-white);">People Score</h3>
                    <p style="color: #94a3b8; font-size: 14px;">Analizziamo le recensioni pubbliche reali per capire l'apprezzamento effettivo.</p>
                </div>
                <div style="padding: 24px; border: 1px solid rgba(255,255,255,0.1); border-radius: var(--tt-radius-md);">
                    <h3 style="color: var(--tt-white);">AI Consistency</h3>
                    <p style="color: #94a3b8; font-size: 14px;">L'AI verifica la coerenza delle recensioni e isola le opinioni più affidabili.</p>
                </div>
                <div style="padding: 24px; border: 1px solid rgba(212, 175, 55, 0.3); border-radius: var(--tt-radius-md); background: rgba(212, 175, 55, 0.05);">
                    <h3 style="color: var(--tt-gold-champagne);">Reputation Signal</h3>
                    <p style="color: #94a3b8; font-size: 14px;">Il risultato finale è uno score autorevole e trasparente.</p>
                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>
</main>

<?php get_footer(); ?>
