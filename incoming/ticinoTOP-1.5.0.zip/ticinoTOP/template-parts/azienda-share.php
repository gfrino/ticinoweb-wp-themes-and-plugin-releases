<?php
/**
 * Condivisione e stampa PDF della scheda azienda.
 *
 * Solo link di condivisione semplici: nessuno script o pixel dei social (niente tracciamento
 * prima del consenso). Il PDF usa la stampa del browser ("Salva come PDF") con il foglio
 * di stile di stampa assets/css/tt-azienda.css.
 */
$share_url   = get_permalink();
$share_title = get_the_title();
$share_text  = sprintf('%s su Ticino Top', $share_title);

$networks = array(
    'facebook' => array('Facebook', 'https://www.facebook.com/sharer/sharer.php?u=' . rawurlencode($share_url)),
    'linkedin' => array('LinkedIn', 'https://www.linkedin.com/sharing/share-offsite/?url=' . rawurlencode($share_url)),
    'whatsapp' => array('WhatsApp', 'https://wa.me/?text=' . rawurlencode($share_text . ' ' . $share_url)),
    'x'        => array('X', 'https://x.com/intent/tweet?text=' . rawurlencode($share_text) . '&url=' . rawurlencode($share_url)),
    'email'    => array('Email', 'mailto:?subject=' . rawurlencode($share_text) . '&body=' . rawurlencode($share_text . "\n" . $share_url)),
);

$icons = array(
    'facebook' => '<path d="M14 8h3V4h-3c-2.8 0-5 2.2-5 5v2H7v4h2v7h4v-7h3l1-4h-4V9c0-.6.4-1 1-1z"/>',
    'linkedin' => '<path d="M4 9h4v12H4zM6 3a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM10 9h3.8v1.7h.1c.5-1 1.8-2 3.8-2 4 0 4.8 2.6 4.8 6V21h-4v-5.6c0-1.3 0-3-1.9-3s-2.2 1.5-2.2 2.9V21h-4z"/>',
    'whatsapp' => '<path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 18.2c-1.5 0-3-.4-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8-.2-.1-.4-.1-.6.1l-.8 1c-.1.2-.3.2-.5.1a6.7 6.7 0 0 1-3.3-2.9c-.2-.4.2-.4.7-1.3.1-.2 0-.3 0-.4l-.8-1.8c-.2-.5-.4-.4-.6-.4h-.5c-.2 0-.4.1-.7.3-.2.3-.9.9-.9 2.2s.9 2.5 1 2.7c.1.2 1.8 2.8 4.4 3.9 1.6.7 2.3.8 3.1.6.5-.1 1.5-.6 1.7-1.2.2-.6.2-1.1.2-1.2-.1-.1-.3-.2-.5-.3z"/>',
    'x'        => '<path d="M17.8 3h3.1l-6.8 7.8L22 21h-6.2l-4.9-6.4L5.3 21H2.2l7.3-8.3L2 3h6.4l4.4 5.8zm-1.1 16.2h1.7L7.4 4.7H5.6z"/>',
    'email'    => '<path d="M3 5h18a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1zm1 2.4V17h16V7.4l-8 5.3zM5.6 7l6.4 4.2L18.4 7z"/>',
);
?>
<div class="tt-share" data-share-url="<?php echo esc_url($share_url); ?>" data-share-title="<?php echo esc_attr($share_text); ?>">
    <div class="tt-share-label">Condividi questa scheda</div>
    <div class="tt-share-buttons">
        <?php foreach ($networks as $key => $net) : ?>
            <a class="tt-share-btn tt-share-<?php echo esc_attr($key); ?>" href="<?php echo esc_url($net[1]); ?>"<?php echo $key === 'email' ? '' : ' target="_blank" rel="noopener nofollow"'; ?> aria-label="<?php echo esc_attr('Condividi su ' . $net[0]); ?>" title="<?php echo esc_attr($net[0]); ?>">
                <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor" aria-hidden="true"><?php echo $icons[$key]; ?></svg>
            </a>
        <?php endforeach; ?>
        <button type="button" class="tt-share-btn tt-share-copy" aria-label="Copia il link della scheda" title="Copia link">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/></svg>
        </button>
        <button type="button" class="tt-share-btn tt-share-native" aria-label="Altre opzioni di condivisione" title="Condividi" hidden>
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 12v7a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-7"/><path d="M16 6l-4-4-4 4"/><path d="M12 2v13"/></svg>
        </button>
    </div>
    <div class="tt-share-feedback" role="status" aria-live="polite"></div>

    <button type="button" class="tt-btn tt-btn-outline tt-print-btn" style="width: 100%;" title="Apre la stampa del browser: scegli «Salva come PDF»">
        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="margin-right: 8px; vertical-align: -3px;"><path d="M6 9V2h12v7"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><path d="M6 14h12v8H6z"/></svg>
        Scarica PDF
    </button>
</div>
