<?php
$data = get_query_var('tt_ranking');
if (!$data) return;
?>
<div class="tt-card tt-ranking-card">
    <div class="tt-card-img" style="background-image: url('<?php echo esc_url($data['img']); ?>');">
        <div class="tt-ranking-position">#<?php echo esc_html($data['position']); ?></div>
    </div>
    <div class="tt-card-body">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px;">
            <div class="tt-badge tt-badge-dark"><?php echo esc_html($data['category']); ?></div>
            <?php if (!empty($data['score'])) : ?>
            <div class="tt-score-box">
                <span class="tt-score-num">★ <?php echo esc_html($data['score']); ?></span>
            </div>
            <?php endif; ?>
        </div>
        <h3 class="tt-ranking-title"><a href="<?php echo esc_url($data['url']); ?>" style="color: inherit; text-decoration: none;"><?php echo esc_html($data['title']); ?></a></h3>
        <?php if (!empty($data['reviews'])) : ?>
        <div class="tt-ranking-meta">
            <span><?php echo esc_html($data['reviews']); ?> recensioni analizzate</span>
        </div>
        <?php endif; ?>
        
        <?php if (!empty($data['ai_text'])) : ?>
        <div class="tt-ai-box">
            <div class="tt-ai-box-title">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="color: var(--tt-gold-champagne);"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                AI Insights
            </div>
            <?php echo esc_html($data['ai_text']); ?>
        </div>
        <?php endif; ?>
        
        <div style="display: flex; gap: 8px; margin-top: 16px;">
            <a href="<?php echo esc_url($data['url']); ?>" class="tt-btn tt-btn-premium" style="flex: 1; padding: 8px; font-size: 13px;">Vedi Scheda</a>
        </div>
    </div>
</div>
