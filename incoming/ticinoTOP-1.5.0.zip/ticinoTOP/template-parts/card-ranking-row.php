<?php
$data = get_query_var('tt_ranking');
if (!$data) return;
?>
<div class="tt-card tt-ranking-row-card" style="display: flex; flex-direction: row; align-items: stretch; min-height: 250px;">
    <div class="tt-ranking-row-img" style="width: 35%; background-image: url('<?php echo esc_url($data['img']); ?>'); background-size: cover; background-position: center; position: relative;">
        <div class="tt-ranking-position" style="top: 16px; left: 16px; width: 48px; height: 48px; font-size: 24px;">#<?php echo esc_html($data['position']); ?></div>
    </div>
    <div class="tt-ranking-row-body" style="width: 65%; padding: 32px; display: flex; flex-direction: column;">
        <div class="tt-ranking-row-header" style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 12px;">
            <div>
                <h2 style="font-family: var(--tt-font-serif); font-size: 28px; margin-bottom: 8px;"><?php echo esc_html($data['title']); ?></h2>
                <div style="display: flex; gap: 16px; color: var(--tt-gray-text); font-size: 14px; align-items: center;">
                    <span>📍 <?php echo esc_html($data['category']); ?></span>
                    <?php if (!empty($data['reviews'])) : ?><span>💬 <?php echo esc_html($data['reviews']); ?> recensioni</span><?php endif; ?>
                </div>
                <?php if (isset($data['id']) && function_exists('tt_render_assigned_badges')) : ?>
                    <div style="margin-top: 12px;">
                        <?php tt_the_assigned_badges($data['id']); ?>
                    </div>
                <?php endif; ?>
            </div>
            <?php if (!empty($data['score'])) : ?>
            <div style="text-align: right;">
                <div style="font-size: 32px; font-weight: 700; color: var(--tt-gold-champagne); line-height: 1;">★ <?php echo esc_html($data['score']); ?></div>
                <div style="font-size: 12px; color: var(--tt-gray-text); text-transform: uppercase;">People Score</div>
            </div>
            <?php endif; ?>
        </div>
        
        <?php if (!empty($data['ai_text'])) : ?>
        <div class="tt-ai-box" style="margin-top: 16px; flex-grow: 1;">
            <div class="tt-ai-box-title">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color: var(--tt-gold-champagne);"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                Perché è in questa posizione
            </div>
            <p style="margin: 0; color: var(--tt-gray-text);"><?php echo esc_html($data['ai_text']); ?></p>
        </div>
        <?php endif; ?>
        
        <div style="margin-top: 24px; display: flex; gap: 16px;">
            <a href="<?php echo esc_url($data['url']); ?>" class="tt-btn tt-btn-primary">Scheda Reputazionale</a>
            <?php if (!empty($data['website'])) : ?>
                <a href="<?php echo esc_url($data['website']); ?>" class="tt-btn tt-btn-outline" target="_blank" rel="noopener nofollow">Visita Sito</a>
            <?php endif; ?>
        </div>
    </div>
</div>
