<?php
/**
 * Template Name: TT Hub Categorie
 */
get_header(); ?>

<main class="tt-main">
    <section class="tt-section" style="padding-top: 60px;">
        <div class="tt-container">
            <h1 class="animate-hero-title" style="font-family: var(--tt-font-serif); font-size: 56px; margin-bottom: 16px; text-align: center;">Esplora per Categoria</h1>
            <p class="animate-hero-subtitle" style="text-align: center; color: var(--tt-gray-text); margin-bottom: 60px; font-size: 18px; max-width: 600px; margin-left: auto; margin-right: auto;">
                Trova le migliori attività del Ticino suddivise per settore, analizzate e consigliate dall'Intelligenza Artificiale.
            </p>

            <div class="tt-grid-3 reveal-grid">
                <?php
                $terms = get_terms([
                    'taxonomy' => 'categoria_azienda',
                    'hide_empty' => false,
                ]);

                if (!empty($terms) && !is_wp_error($terms)) {
                    foreach ($terms as $term) {
                        // Dummy image logic based on slug
                        $img = get_stylesheet_directory_uri() . '/images/category-default.jpg'; // fallback
                        if (in_array($term->slug, ['food-dining', 'ristorazione-locali', 'ristorazione-amp-locali'])) {
                            $img = get_stylesheet_directory_uri() . '/images/category-food.jpg';
                        } elseif (in_array($term->slug, ['health-trust', 'salute-medicina', 'salute-amp-medicina'])) {
                            $img = get_stylesheet_directory_uri() . '/images/category-health.jpg';
                        } elseif (in_array($term->slug, ['experience-stay', 'hotel-alloggi', 'hotel-amp-alloggi'])) {
                            $img = get_stylesheet_directory_uri() . '/images/category-experience.jpg';
                        }

                        $term_link = get_term_link($term);
                        ?>
                        <a href="<?php echo esc_url($term_link); ?>" class="tt-card" style="display: block; overflow: hidden; position: relative; border-radius: var(--tt-radius-lg); height: 280px;">
                            <div style="position: absolute; inset: 0; background-image: url('<?php echo esc_url($img); ?>'); background-size: cover; background-position: center; transition: transform 0.5s ease;" class="tt-cat-bg"></div>
                            <div style="position: absolute; inset: 0; background: linear-gradient(to top, rgba(10,25,47,0.9) 0%, rgba(10,25,47,0.3) 50%, transparent 100%);"></div>
                            <div style="position: absolute; bottom: 0; left: 0; right: 0; padding: 32px;">
                                <h3 style="color: var(--tt-white); font-family: var(--tt-font-serif); font-size: 28px; margin-bottom: 8px;"><?php echo esc_html($term->name); ?></h3>
                                <div style="display: flex; justify-content: space-between; align-items: center;">
                                    <span style="color: var(--tt-gold-champagne); font-weight: 600; font-size: 14px;"><?php echo esc_html($term->count); ?> Attività Top</span>
                                    <span style="color: var(--tt-white); background: rgba(255,255,255,0.2); width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; border-radius: 50%;">→</span>
                                </div>
                            </div>
                        </a>
                        <?php
                    }
                } else {
                    echo '<p>Nessuna categoria trovata.</p>';
                }
                ?>
            </div>
            <style>
                .tt-card:hover .tt-cat-bg { transform: scale(1.05); }
            </style>
        </div>
    </section>
</main>

<?php get_footer(); ?>
