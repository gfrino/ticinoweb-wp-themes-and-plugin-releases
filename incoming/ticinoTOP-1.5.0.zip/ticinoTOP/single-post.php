<?php
/**
 * The template for displaying all single posts (standard blog posts)
 */
get_header(); 

if (have_posts()) : while (have_posts()) : the_post();

$post_id = get_the_ID();

// Fetch dynamic metadata
$categories = get_the_category();
$cat_name = ($categories) ? $categories[0]->name : 'Trend & Insight';
$date = get_the_date('j F Y');

// Calculate reading time
$content = get_the_content();
$word_count = str_word_count(strip_tags($content));
$reading_time = ceil($word_count / 200) ?: 1;
$reading_time_text = $reading_time . ' min di lettura';

// Author name
$author = get_the_author() ?: 'Redazione TT';

// Featured Image
$img = get_the_post_thumbnail_url($post_id, 'full') ?: get_stylesheet_directory_uri() . '/images/category-default.jpg';
?>

<main class="tt-main" style="background: var(--tt-white); min-height: 100vh; padding-bottom: 80px;">
    <!-- Article Hero -->
    <section class="tt-section" style="padding-top: 80px; padding-bottom: 40px; background: var(--tt-gray-light); border-bottom: 1px solid var(--tt-gray-border);">
        <div class="tt-container" style="max-width: 800px; text-align: center;">
            <div class="tt-badge tt-badge-dark" style="margin-bottom: 24px; background: var(--tt-blue-notte); border-color: var(--tt-blue-notte); color: var(--tt-white);"><?php echo esc_html($cat_name); ?></div>
            <h1 class="animate-hero-title" style="font-family: var(--tt-font-serif); font-size: 48px; margin-bottom: 24px; line-height: 1.2; color: var(--tt-black);"><?php the_title(); ?></h1>
            
            <?php if (has_excerpt()) : ?>
                <p class="animate-hero-subtitle" style="font-size: 20px; color: var(--tt-gray-text); margin-bottom: 32px; line-height: 1.6;"><?php echo esc_html(get_the_excerpt()); ?></p>
            <?php endif; ?>
            
            <div style="display: flex; gap: 16px; justify-content: center; align-items: center; font-size: 14px; color: var(--tt-gray-text); font-weight: 500;">
                <span>Di <strong><?php echo esc_html($author); ?></strong></span>
                <span>•</span>
                <?php if (tt_show_post_dates()) : ?>
                <span><?php echo esc_html($date); ?></span>
                <span>•</span>
                <?php endif; ?>
                <span><?php echo esc_html($reading_time_text); ?></span>
            </div>
        </div>
    </section>

    <!-- Cover Image -->
    <div class="tt-container" style="max-width: 1000px; margin-top: 60px; margin-bottom: 60px;">
        <div style="height: 500px; background: url('<?php echo esc_url($img); ?>') center/cover; border-radius: var(--tt-radius-lg); box-shadow: var(--tt-shadow-premium); border: 1px solid var(--tt-gray-border);"></div>
    </div>

    <!-- Article Content -->
    <section class="tt-section" style="padding-top: 0;">
        <div class="tt-container tt-article-content" style="max-width: 740px; font-size: 18px; line-height: 1.8; color: #2d3748;">
            <?php the_content(); ?>
        </div>
    </section>
</main>

<style>
/* Style the article content nicely for WP editor blocks */
.tt-article-content p {
    margin-bottom: 28px;
}
.tt-article-content h2, .tt-article-content h3 {
    font-family: var(--tt-font-serif);
    color: var(--tt-black);
    margin-top: 48px;
    margin-bottom: 20px;
    line-height: 1.3;
}
.tt-article-content h2 {
    font-size: 32px;
}
.tt-article-content h3 {
    font-size: 26px;
}
.tt-article-content blockquote {
    border-left: 4px solid var(--tt-gold-champagne);
    padding-left: 24px;
    margin: 40px 0;
    font-family: var(--tt-font-serif);
    font-size: 24px;
    font-style: italic;
    color: var(--tt-black);
    line-height: 1.5;
}
.tt-article-content ul, .tt-article-content ol {
    margin-bottom: 28px;
    padding-left: 24px;
}
.tt-article-content li {
    margin-bottom: 10px;
}
.tt-article-content img {
    max-width: 100%;
    height: auto;
    border-radius: var(--tt-radius-md);
    margin: 30px 0;
}
</style>

<?php 
endwhile; endif;
get_footer(); 
?>
