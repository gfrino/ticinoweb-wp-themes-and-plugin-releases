<?php
get_header(); ?>

<main class="tt-main">
    <section class="tt-section tt-section-dark" style="padding: 100px 0; background: var(--tt-blue-notte);">
        <div class="tt-container" style="text-align: center;">
            <div class="tt-badge tt-badge-gold" style="margin-bottom: 24px;">Ricerca</div>
            <h1 style="font-family: var(--tt-font-serif); font-size: 56px; margin-bottom: 16px;">Risultati per "<?php echo get_search_query(); ?>"</h1>
            <p style="font-size: 20px; color: #cbd5e1;">Abbiamo trovato <?php global $wp_query; echo $wp_query->found_posts; ?> risultati corrispondenti.</p>
        </div>
    </section>

    <section class="tt-section" style="background: var(--tt-gray-light);">
        <div class="tt-container">
            <div class="tt-grid-3">
                <?php 
                if (have_posts()) :
                    $position = 1;
                    while (have_posts()) : the_post();
                        // Support for multiple post types if needed, but defaults to azienda via our form
                        $post_type = get_post_type();
                        
                        if ($post_type === 'azienda') {
                            $post_id = get_the_ID();
                            $terms = get_the_terms($post_id, 'categoria_azienda');
                            $cat_name = ($terms && !is_wp_error($terms)) ? $terms[0]->name : 'Azienda';
                            
                            $voto = get_post_meta($post_id, '_tt_voto', true);
                            $recensioni = get_post_meta($post_id, '_tt_recensioni', true);
                            $ai_text = get_post_meta($post_id, '_tt_ai_text', true);
                            
                            $fallback_pool = [
                                get_stylesheet_directory_uri() . '/images/placeholder-restaurant.jpg',
                                get_stylesheet_directory_uri() . '/images/placeholder-business.jpg',
                                get_stylesheet_directory_uri() . '/images/placeholder-clinic.jpg',
                                get_stylesheet_directory_uri() . '/images/placeholder-scenic.jpg',
                                get_stylesheet_directory_uri() . '/images/placeholder-boutique.jpg',
                                get_stylesheet_directory_uri() . '/images/placeholder-office.jpg',
                                get_stylesheet_directory_uri() . '/images/placeholder-cafe.jpg'
                            ];
                            $fallback_img = $fallback_pool[$post_id % count($fallback_pool)];
                            
                            $img_meta = get_post_meta($post_id, '_tt_image', true);
                            $img = $img_meta ?: (get_the_post_thumbnail_url($post_id, 'large') ?: $fallback_img);
                            
                            $ranking_data = [
                                'title' => get_the_title(),
                                'category' => $cat_name,
                                'position' => $position,
                                'score' => $voto,
                                'reviews' => $recensioni,
                                'ai_text' => wp_trim_words($ai_text, 15, '...'),
                                'img' => $img,
                                'url' => get_permalink()
                            ];
                            
                            set_query_var('tt_ranking', $ranking_data);
                            get_template_part('template-parts/card', 'ranking'); 
                            $position++;
                        } else {
                            // Basic fallback for standard posts or pages
                            ?>
                            <a href="<?php the_permalink(); ?>" class="tt-card" style="display: block;">
                                <div style="padding: 24px;">
                                    <h3 style="font-size: 20px; margin-bottom: 8px;"><?php the_title(); ?></h3>
                                    <p style="font-size: 14px; color: var(--tt-gray-text); margin: 0;"><?php echo wp_trim_words(get_the_excerpt(), 20); ?></p>
                                </div>
                            </a>
                            <?php
                        }
                    endwhile;
                else :
                    echo '<p style="grid-column: 1/-1; text-align: center; color: var(--tt-gray-text); font-size: 18px;">Nessun risultato trovato. Prova con termini diversi.</p>';
                endif;
                ?>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>
