<?php
/**
 * Template Name: TT Chi Siamo
 */
get_header(); 

$post_id = get_the_ID();

// Fetch dynamic CMS values with hardcoded fallbacks
$hero_title = get_post_meta($post_id, '_tt_chisiamo_hero_title', true) ?: "Siamo l'osservatorio che dà voce alla qualità oggettiva.";
$hero_subtitle = get_post_meta($post_id, '_tt_chisiamo_hero_subtitle', true) ?: "Ticino Top nasce per risolvere un problema di fiducia. Sul web tutti dicono di essere i migliori. Noi usiamo i dati e l'intelligenza artificiale per scoprire chi lo è davvero.";

$manifesto_title = get_post_meta($post_id, '_tt_chisiamo_manifesto_title', true) ?: "Il Nostro Manifesto";

$manifesto_items = [];
for ($i = 1; $i <= 4; $i++) {
    $item = get_post_meta($post_id, '_tt_chisiamo_manifesto_' . $i, true);
    if ($item) {
        $manifesto_items[] = $item;
    }
}
// Default items fallback if none exist
if (empty($manifesto_items)) {
    $manifesto_items = [
        "L'autorevolezza non è in vendita. I posizionamenti in classifica non possono essere sponsorizzati.",
        "Crediamo nella voce delle persone, ma esigiamo la verifica matematica dell'AI per scartare manipolazioni e bias.",
        "Trasparenza assoluta: ogni classifica deve avere una metodologia spiegata e chiara.",
        "Celebriamo le eccellenze del Ticino per incentivare l'innalzamento della qualità globale dei servizi."
    ];
}

$side_title = get_post_meta($post_id, '_tt_chisiamo_side_title', true) ?: "Il Modello Persone + AI";
$side_p1 = get_post_meta($post_id, '_tt_chisiamo_side_p1', true) ?: "L'essere umano valuta l'emozione, l'atmosfera e la cortesia. L'AI analizza la frequenza di queste valutazioni su migliaia di campioni nel tempo.";
$side_p2 = get_post_meta($post_id, '_tt_chisiamo_side_p2', true) ?: "Questa sinergia elimina il \"giudizio di pancia\" del singolo recensore arrabbiato e le \"recensioni perfette\" sospette, lasciando emergere la vera identità reputazionale di un brand.";
?>

<main class="tt-main" style="background: var(--tt-white);">
    <!-- Hero Chi Siamo -->
    <section class="tt-section tt-chisiamo-sticky-section" style="position: sticky; top: 0; min-height: 100vh; display: flex; flex-direction: column; justify-content: center; z-index: 10; background: var(--tt-white);">
        <div class="tt-container" style="max-width: 900px; text-align: center;">
            <h1 class="animate-hero-title" style="font-family: var(--tt-font-serif); font-size: 56px; margin-bottom: 32px; line-height: 1.1; color: var(--tt-black);"><?php echo esc_html($hero_title); ?></h1>
            <p class="animate-hero-subtitle" style="font-size: 22px; color: var(--tt-gray-text); line-height: 1.6;"><?php echo esc_html($hero_subtitle); ?></p>
        </div>
    </section>

    <!-- Manifesto -->
    <section class="tt-section tt-section-dark tt-chisiamo-sticky-section" style="position: sticky; top: 0; min-height: 100vh; display: flex; flex-direction: column; justify-content: center; z-index: 20; background: var(--tt-black); border-radius: 40px 40px 0 0; box-shadow: 0 -20px 50px rgba(0,0,0,0.5);">
        <div class="tt-container">
            <div class="tt-manifesto-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 60px; align-items: center;">
                <div>
                    <h2 class="reveal-on-scroll" style="font-family: var(--tt-font-serif); font-size: 40px; margin-bottom: 24px; color: var(--tt-gold-champagne);"><?php echo esc_html($manifesto_title); ?></h2>
                    <ul class="reveal-on-scroll" style="list-style: none; padding: 0; font-size: 18px; line-height: 1.8; color: #cbd5e1;">
                        <?php 
                        $count = 1;
                        foreach ($manifesto_items as $item) : 
                        ?>
                            <li style="margin-bottom: 16px; display: flex; gap: 12px;"><span style="color: var(--tt-gold-champagne);"><?php echo $count++; ?>.</span> <?php echo esc_html($item); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div>
                    <div class="reveal-on-scroll" style="background: rgba(255,255,255,0.05); padding: 40px; border-radius: var(--tt-radius-lg); border: 1px solid rgba(212, 175, 55, 0.2);">
                        <h3 style="font-size: 24px; margin-bottom: 24px; font-family: var(--tt-font-serif); color: var(--tt-white);"><?php echo esc_html($side_title); ?></h3>
                        <p style="color: #94a3b8; margin-bottom: 24px;"><?php echo esc_html($side_p1); ?></p>
                        <p style="color: #94a3b8; margin: 0;"><?php echo esc_html($side_p2); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?>
