<?php
/**
 * Template Name: TT Awards
 */
get_header(); 

// Dynamic counters query for 2026 awards
$food_winners_query = new WP_Query([
    'post_type' => 'azienda',
    'posts_per_page' => -1,
    'meta_query' => [
        [
            'key' => '_tt_award_category',
            'value' => 'food',
            'compare' => '='
        ],
        [
            'key' => '_tt_award_year',
            'value' => '2026',
            'compare' => '='
        ]
    ]
]);
$food_count = $food_winners_query->found_posts ?: 12;

$health_winners_query = new WP_Query([
    'post_type' => 'azienda',
    'posts_per_page' => -1,
    'meta_query' => [
        [
            'key' => '_tt_award_category',
            'value' => 'health',
            'compare' => '='
        ],
        [
            'key' => '_tt_award_year',
            'value' => '2026',
            'compare' => '='
        ]
    ]
]);
$health_count = $health_winners_query->found_posts ?: 8;

$business_winners_query = new WP_Query([
    'post_type' => 'azienda',
    'posts_per_page' => -1,
    'meta_query' => [
        [
            'key' => '_tt_award_category',
            'value' => 'business',
            'compare' => '='
        ],
        [
            'key' => '_tt_award_year',
            'value' => '2026',
            'compare' => '='
        ]
    ]
]);
$business_count = $business_winners_query->found_posts ?: 15;
?>

<main class="tt-main" style="background: var(--tt-black); color: var(--tt-white); overflow-x: hidden;">
    <!-- Hero Awards -->
    <section class="tt-section tt-awards-sticky-section" style="position: sticky; top: 0; min-height: 100vh; display: flex; flex-direction: column; justify-content: center; z-index: 10; background-image: radial-gradient(circle at center, #1a2942 0%, var(--tt-black) 100%); text-align: center;">
        <div class="tt-container">
            <div class="tt-badge tt-badge-gold animate-hero-logo" style="margin-bottom: 24px; background: rgba(212, 175, 55, 0.1); border-color: rgba(212, 175, 55, 0.4); color: var(--tt-gold-champagne); letter-spacing: 2px;">TICINO TOP EXCELLENCE</div>
            <h1 class="animate-hero-title" style="font-family: var(--tt-font-serif); font-size: 72px; color: var(--tt-gold-champagne); margin-bottom: 16px; letter-spacing: 0.05em;">AWARDS 2026</h1>
            <p class="animate-hero-subtitle" style="font-size: 20px; color: #cbd5e1; max-width: 600px; margin: 0 auto 40px;">Il massimo riconoscimento per le eccellenze del territorio. Non si compra, si conquista attraverso la reputazione e il voto reale delle persone.</p>
            <div class="animate-hero-btns" style="display: flex; gap: 16px; justify-content: center;">
                <a href="#showcase" class="tt-btn tt-btn-premium" style="scroll-behavior: smooth;">Scopri i Vincitori</a>
                <a href="<?php echo esc_url(home_url('/candidati/')); ?>" class="tt-btn tt-btn-outline" style="border-color: rgba(255,255,255,0.2); color: var(--tt-white);">Candidati per il 2027</a>
            </div>
        </div>
    </section>

    <!-- Categorie -->
    <section class="tt-section tt-awards-sticky-section" style="position: sticky; top: 0; min-height: 100vh; display: flex; flex-direction: column; justify-content: center; z-index: 20; background: var(--tt-black); border-radius: 40px 40px 0 0; border-top: 1px solid rgba(255,255,255,0.1); box-shadow: 0 -20px 50px rgba(0,0,0,0.5);">
        <div class="tt-container">
            <h2 class="reveal-on-scroll" style="font-family: var(--tt-font-serif); font-size: 36px; text-align: center; margin-bottom: 60px;">Categorie d'Eccellenza</h2>
            
            <div class="tt-grid-3 reveal-grid">
                <div class="tt-card tt-awards-category-card" style="background: var(--tt-dark); border: 1px solid rgba(212, 175, 55, 0.2); padding: 40px 32px; text-align: center; box-shadow: none; border-radius: 20px; transition: all 0.4s ease;">
                    <div style="font-size: 40px; margin-bottom: 16px;">🍽️</div>
                    <h3 style="color: var(--tt-white); margin-bottom: 16px; font-family: var(--tt-font-serif); font-size: 24px;">Food Excellence</h3>
                    <p style="color: #94a3b8; font-size: 14px; line-height: 1.6;">Premio ai ristoranti, grotto e café che offrono un'esperienza culinaria e un servizio impeccabili.</p>
                    <div style="color: var(--tt-gold-champagne); font-weight: 700; margin-top: 24px; font-size: 14px; text-transform: uppercase; letter-spacing: 1px;"><?php echo esc_html($food_count); ?> Vincitori</div>
                </div>
                
                <div class="tt-card tt-awards-category-card" style="background: var(--tt-dark); border: 1px solid rgba(255, 255, 255, 0.1); padding: 40px 32px; text-align: center; box-shadow: none; border-radius: 20px; transition: all 0.4s ease;">
                    <div style="font-size: 40px; margin-bottom: 16px;">🏥</div>
                    <h3 style="color: var(--tt-white); margin-bottom: 16px; font-family: var(--tt-font-serif); font-size: 24px;">Health Trust</h3>
                    <p style="color: #94a3b8; font-size: 14px; line-height: 1.6;">Il riconoscimento per studi medici, cliniche e professionisti della salute con la massima affidabilità percepita.</p>
                    <div style="color: var(--tt-gold-champagne); font-weight: 700; margin-top: 24px; font-size: 14px; text-transform: uppercase; letter-spacing: 1px;"><?php echo esc_html($health_count); ?> Vincitori</div>
                </div>

                <div class="tt-card tt-awards-category-card" style="background: var(--tt-dark); border: 1px solid rgba(255, 255, 255, 0.1); padding: 40px 32px; text-align: center; box-shadow: none; border-radius: 20px; transition: all 0.4s ease;">
                    <div style="font-size: 40px; margin-bottom: 16px;">💼</div>
                    <h3 style="color: var(--tt-white); margin-bottom: 16px; font-family: var(--tt-font-serif); font-size: 24px;">Business Reputation</h3>
                    <p style="color: #94a3b8; font-size: 14px; line-height: 1.6;">Aziende B2B e B2C che eccellono nella soddisfazione clienti e nella trasparenza operativa.</p>
                    <div style="color: var(--tt-gold-champagne); font-weight: 700; margin-top: 24px; font-size: 14px; text-transform: uppercase; letter-spacing: 1px;"><?php echo esc_html($business_count); ?> Vincitori</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Winners Showcase Section -->
    <section id="showcase" class="tt-section tt-awards-sticky-section" style="position: sticky; top: 0; min-height: 100vh; padding: 120px 0; z-index: 30; background: #0c1524; border-radius: 40px 40px 0 0; border-top: 1px solid rgba(212, 175, 55, 0.3); box-shadow: 0 -30px 60px rgba(0,0,0,0.7);">
        <div class="tt-container">
            <div style="text-align: center; margin-bottom: 80px;">
                <span class="tt-badge" style="background: rgba(212, 175, 55, 0.1); border-color: var(--tt-gold-champagne); color: var(--tt-gold-champagne); margin-bottom: 16px;">Albo d'Oro Ufficiale</span>
                <h2 style="font-family: var(--tt-font-serif); font-size: 48px; color: var(--tt-white); margin-bottom: 16px;">Vincitori Ufficiali 2026</h2>
                <p style="color: #94a3b8; font-size: 16px; max-width: 600px; margin: 0 auto;">Queste attività locali hanno superato i severi parametri di stabilità reputazionale misurati da Ticino Top nell'ultimo anno solare.</p>
            </div>

            <?php
            $cat_infos = [
                'food' => [
                    'title' => 'Food Excellence 🍽️',
                    'class' => 'food-section'
                ],
                'health' => [
                    'title' => 'Health Trust 🏥',
                    'class' => 'health-section'
                ],
                'business' => [
                    'title' => 'Business Reputation 💼',
                    'class' => 'business-section'
                ]
            ];

            foreach ($cat_infos as $slug => $info) :
                $winners = new WP_Query([
                    'post_type' => 'azienda',
                    'posts_per_page' => -1,
                    'meta_query' => [
                        [
                            'key' => '_tt_award_category',
                            'value' => $slug,
                            'compare' => '='
                        ],
                        [
                            'key' => '_tt_award_year',
                            'value' => '2026',
                            'compare' => '='
                        ]
                    ]
                ]);

                if ($winners->have_posts()) :
            ?>
                <div class="reveal-on-scroll" style="margin-bottom: 80px;">
                    <h3 style="font-family: var(--tt-font-serif); font-size: 28px; color: var(--tt-gold-champagne); margin-bottom: 30px; border-left: 4px solid var(--tt-gold-champagne); padding-left: 16px;"><?php echo esc_html($info['title']); ?></h3>
                    
                    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 30px;">
                        <?php while ($winners->have_posts()) : $winners->the_post(); 
                            $w_id = get_the_ID();
                            $w_voto = get_post_meta($w_id, '_tt_voto', true);
                            $w_motivation = get_post_meta($w_id, '_tt_award_motivation', true) ?: "Eletto per la costanza della reputazione digitale e il servizio eccellente.";
                            $w_img_meta = get_post_meta($w_id, '_tt_image', true);
                            $w_img = $w_img_meta ?: (get_the_post_thumbnail_url($w_id, 'large') ?: get_stylesheet_directory_uri() . '/images/placeholder-business.jpg');
                            
                            $w_keywords = get_post_meta($w_id, '_tt_keywords', true);
                            $w_location = get_post_meta($w_id, '_tt_localita', true) ?: 'Ticino';
                            if (!get_post_meta($w_id, '_tt_localita', true) && stripos(get_the_title(), 'Lugano') !== false || stripos($w_keywords, 'lugano') !== false) {
                                $w_location = 'Lugano';
                            } elseif (stripos(get_the_title(), 'Locarno') !== false || stripos($w_keywords, 'locarno') !== false) {
                                $w_location = 'Locarno';
                            }
                        ?>
                            <div class="tt-winner-card reveal-on-scroll" style="background: rgba(25, 33, 49, 0.4); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 20px; overflow: hidden; backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px); display: flex; flex-direction: column; height: 100%; transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1); box-shadow: 0 10px 30px rgba(0,0,0,0.2);">
                                <div style="height: 200px; background-image: url('<?php echo esc_url($w_img); ?>'); background-size: cover; background-position: center; position: relative;">
                                    <div style="position: absolute; inset: 0; background: linear-gradient(to top, rgba(12, 21, 36, 0.95), transparent);"></div>
                                    <?php if ($w_voto !== '') : ?>
                                    <div style="position: absolute; top: 16px; right: 16px; background: rgba(212, 175, 55, 0.9); color: var(--tt-black); padding: 4px 10px; border-radius: 20px; font-weight: 700; font-size: 13px; box-shadow: 0 4px 10px rgba(0,0,0,0.3); display: flex; align-items: center; gap: 4px;">
                                        ★ <?php echo esc_html($w_voto); ?>
                                    </div>
                                    <?php endif; ?>
                                    <div style="position: absolute; bottom: 16px; left: 20px; display: flex; flex-direction: column;">
                                        <span style="font-size: 12px; color: var(--tt-gold-champagne); font-weight: 600; text-transform: uppercase; letter-spacing: 1px;">📍 <?php echo esc_html($w_location); ?></span>
                                        <h4 style="font-family: var(--tt-font-serif); font-size: 22px; color: var(--tt-white); margin: 4px 0 0 0; text-shadow: 0 2px 4px rgba(0,0,0,0.5);"><?php the_title(); ?></h4>
                                    </div>
                                </div>
                                <div style="padding: 24px; display: flex; flex-direction: column; flex-grow: 1; justify-content: space-between;">
                                    <div class="tt-ai-box" style="margin-bottom: 24px; padding: 14px 16px; background: rgba(212, 175, 55, 0.05); border-left: 2px solid var(--tt-gold-champagne); border-radius: 0 8px 8px 0;">
                                        <div style="font-size: 11px; text-transform: uppercase; color: var(--tt-gold-champagne); font-weight: 700; letter-spacing: 1px; margin-bottom: 6px; display: flex; align-items: center; gap: 6px;">
                                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color: var(--tt-gold-champagne);"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                                            Motivazione Ufficiale
                                        </div>
                                        <p style="margin: 0; color: #cbd5e1; font-size: 13.5px; line-height: 1.5; font-style: italic;">
                                            "<?php echo esc_html($w_motivation); ?>"
                                        </p>
                                    </div>
                                    <a href="<?php the_permalink(); ?>" class="tt-btn tt-btn-premium" style="width: 100%; text-align: center; justify-content: center; font-size: 13px; padding: 10px 16px;">Visualizza Analisi AI</a>
                                </div>
                            </div>
                        <?php endwhile; wp_reset_postdata(); ?>
                    </div>
                </div>
            <?php 
                endif; 
            endforeach; 
            ?>
        </div>
    </section>
</main>

<style>
.tt-awards-category-card:hover {
    transform: translateY(-8px);
    border-color: var(--tt-gold-champagne) !important;
    box-shadow: 0 15px 40px rgba(212, 175, 55, 0.1) !important;
}
.tt-winner-card:hover {
    transform: translateY(-5px);
    border-color: rgba(212, 175, 55, 0.4) !important;
    box-shadow: 0 20px 40px rgba(0,0,0,0.5), 0 0 20px rgba(212, 175, 55, 0.05) !important;
}
</style>

<?php get_footer(); ?>
