<?php
/**
 * Template Name: TT TopScan
 */
get_header(); ?>

<!-- Chart.js: self-hosted, accodato in inc/forms.php (tt_topscan_enqueue_chart) -->

<style>
    .tt-topscan-hero {
        background: radial-gradient(circle at top right, rgba(10, 25, 47, 1) 0%, rgba(0, 0, 0, 1) 100%);
        color: var(--tt-white);
        padding: 120px 0 160px;
        position: sticky;
        top: 0;
        min-height: 100vh;
        z-index: 10;
        display: flex;
        flex-direction: column;
        justify-content: center;
        overflow: hidden;
    }
    .tt-radar-container {
        position: absolute;
        top: 50%;
        left: 50%;
        width: 1000px;
        height: 1000px;
        transform: translate(-50%, -50%);
        pointer-events: none;
        z-index: 1;
        opacity: 0.15;
    }
    .tt-radar-grid {
        position: absolute;
        top: 0; left: 0; right: 0; bottom: 0;
        border-radius: 50%;
        border: 2px solid rgba(255,255,255,0.4);
        background: 
            repeating-radial-gradient(
                circle at center,
                transparent 0,
                transparent 19.5%,
                rgba(255,255,255,0.2) 20%
            ),
            linear-gradient(90deg, transparent 49.5%, rgba(255,255,255,0.3) 50%, transparent 50.5%),
            linear-gradient(0deg, transparent 49.5%, rgba(255,255,255,0.3) 50%, transparent 50.5%);
    }
    .tt-radar-sweep {
        position: absolute;
        top: 0; left: 0; right: 0; bottom: 0;
        border-radius: 50%;
        background: conic-gradient(
            from 0deg,
            rgba(255,255,255,0) 0deg,
            rgba(255,255,255,0) 270deg,
            rgba(255,255,255,0.8) 360deg
        );
        animation: radar-spin 4s linear infinite;
    }
    @keyframes radar-spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
    }
    .tt-metric-card {
        background: rgba(255, 255, 255, 0.03);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: var(--tt-radius-lg);
        padding: 24px;
        backdrop-filter: blur(10px);
        transition: transform 0.3s ease;
    }
    .tt-metric-card:hover {
        transform: translateY(-5px);
        border-color: rgba(212, 175, 55, 0.3);
    }
    .tt-metric-value {
        font-family: var(--tt-font-serif);
        font-size: 48px;
        color: var(--tt-gold-champagne);
        line-height: 1;
        margin-bottom: 8px;
    }
    .tt-metric-label {
        font-size: 13px;
        text-transform: uppercase;
        letter-spacing: 0.1em;
        color: #94a3b8;
    }
    .tt-dashboard-wrapper {
        margin-top: 0;
        position: relative;
        z-index: 10;
        background: var(--tt-dark);
        border-radius: 24px;
        padding: 40px;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
        border: 1px solid rgba(255, 255, 255, 0.1);
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 60px;
    }
    @media (max-width: 992px) {
        .tt-dashboard-wrapper { grid-template-columns: 1fr; }
    }
    .tt-progress-track {
        background: rgba(255, 255, 255, 0.1);
        height: 6px;
        border-radius: 3px;
        overflow: hidden;
        margin-top: 8px;
    }
    .tt-progress-fill {
        height: 100%;
        background: linear-gradient(90deg, var(--tt-gold-champagne), #F9F5EB);
        border-radius: 3px;
    }
    .tt-benchmark-box {
        background: linear-gradient(145deg, rgba(212, 175, 55, 0.1), rgba(0,0,0,0));
        border-left: 3px solid var(--tt-gold-champagne);
        padding: 20px;
        border-radius: 0 8px 8px 0;
        margin-top: 32px;
    }
    /* WIZARD CSS */
    .tt-wizard-modal {
        display: none;
        position: fixed;
        top: 0; left: 0; right: 0; bottom: 0;
        background: rgba(0, 0, 0, 0.85);
        z-index: 9999;
        align-items: center;
        justify-content: center;
        backdrop-filter: blur(10px);
        overflow-y: auto;
        padding: 20px;
        box-sizing: border-box;
    }
    .tt-wizard-content {
        background: var(--tt-dark);
        border: 1px solid rgba(255,255,255,0.1);
        width: 100%;
        max-width: 600px;
        border-radius: 24px;
        padding: 40px;
        text-align: center;
        position: relative;
        box-sizing: border-box;
    }
    .tt-wizard-close {
        position: absolute;
        top: 24px; right: 24px;
        color: var(--tt-gray-text);
        cursor: pointer;
        font-size: 24px;
    }
    .tt-wizard-step {
        display: none;
    }
    .tt-wizard-step.active {
        display: block;
        animation: fadeIn 0.4s ease forwards;
    }
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    .tt-wizard-q {
        font-family: var(--tt-font-serif);
        font-size: 28px;
        color: var(--tt-white);
        margin-bottom: 32px;
    }
    .tt-wizard-options {
        display: flex;
        flex-direction: column;
        gap: 16px;
    }
    .tt-wizard-btn {
        background: rgba(255,255,255,0.05);
        border: 1px solid rgba(255,255,255,0.1);
        color: var(--tt-white);
        padding: 16px;
        border-radius: 12px;
        cursor: pointer;
        font-size: 16px;
        transition: all 0.2s;
    }
    .tt-wizard-btn:hover {
        background: rgba(212, 175, 55, 0.1);
        border-color: var(--tt-gold-champagne);
    }
    .tt-wizard-progress {
        display: flex;
        gap: 8px;
        justify-content: center;
        margin-bottom: 24px;
    }
    .tt-wizard-dot {
        width: 8px; height: 8px;
        border-radius: 50%;
        background: rgba(255,255,255,0.2);
    }
    .tt-wizard-dot.active {
        background: var(--tt-gold-champagne);
    }
    @media (max-width: 768px) {
        /* 1. Disabilita lo sticky stacking per far scorrere la pagina normalmente su mobile */
        .tt-topscan-hero,
        .tt-topscan-dashboard-section,
        #how-it-works {
            position: relative !important;
            top: auto !important;
            min-height: auto !important;
            height: auto !important;
            transform: none !important;
            box-shadow: none !important;
            border-radius: 0 !important;
        }
        
        .tt-topscan-hero {
            padding: 80px 0 60px !important;
        }
        
        .tt-topscan-dashboard-section {
            padding: 40px 0 60px !important;
            border-radius: 24px 24px 0 0 !important; /* Manteniamo la stondatura all'inizio del dashboard per eleganza */
        }
        
        #how-it-works {
            padding: 80px 0 !important;
            border-radius: 24px 24px 0 0 !important; /* Manteniamo la stondatura dei Pilastri */
        }
        
        /* 2. Ridimensionamento elementi Hero e incolonnamento pulsanti per evitare scroll laterale */
        .tt-topscan-hero h1 {
            font-size: 44px !important;
            margin-bottom: 16px !important;
        }
        
        .tt-topscan-hero p {
            font-size: 16px !important;
            margin-bottom: 32px !important;
            padding: 0 12px !important;
        }
        
        .tt-topscan-hero .animate-hero-btns {
            flex-direction: column !important;
            gap: 12px !important;
            align-items: center !important;
            max-width: 320px !important;
            margin: 0 auto !important;
            padding: 0 12px !important;
        }
        
        .tt-topscan-hero .tt-btn {
            width: 100% !important;
            box-sizing: border-box !important;
            font-size: 15px !important;
            padding: 14px 24px !important;
            text-align: center !important;
        }

        /* 3. Responsive Dashboard wrapper e metriche */
        .tt-dashboard-wrapper {
            padding: 24px 16px !important;
            gap: 32px !important;
            border-radius: 16px !important;
        }
        
        .tt-dashboard-metrics-grid {
            grid-template-columns: 1fr !important;
            gap: 16px !important;
        }
        
        .tt-metric-card {
            padding: 16px !important;
        }
        
        .tt-metric-value {
            font-size: 36px !important;
        }
        
        /* 4. Overlay "Dati Protetti" responsive */
        #dashboard-unlock-overlay {
            padding: 16px !important;
        }
        
        #dashboard-unlock-overlay > div {
            padding: 32px 16px !important;
            border-radius: 16px !important;
            width: 100% !important;
            max-width: 100% !important;
            box-sizing: border-box !important;
        }
        
        #dashboard-unlock-overlay h3 {
            font-size: 20px !important;
            margin-bottom: 12px !important;
        }
        
        #dashboard-unlock-overlay p {
            font-size: 14px !important;
            margin-bottom: 16px !important;
            max-width: 100% !important;
        }

        /* 5. Wizard Form overrides */
        .tt-wizard-content {
            width: 100% !important;
            max-width: 100% !important;
            padding: 32px 16px !important;
            border-radius: 16px !important;
        }
        .tt-wizard-q {
            font-size: 22px !important;
            line-height: 1.3 !important;
            margin-bottom: 24px !important;
        }
        .tt-wizard-close {
            top: 16px !important;
            right: 16px !important;
            font-size: 20px !important;
        }
        .tt-wizard-options {
            gap: 12px !important;
        }
        .tt-wizard-btn {
            padding: 12px 16px !important;
            font-size: 14px !important;
            line-height: 1.4 !important;
        }
    }
</style>

<main class="tt-main" style="background: var(--tt-black);">
    
    <!-- Hero Section -->
    <section class="tt-topscan-hero">
        <!-- Effetto Radar Background -->
        <div class="tt-radar-container">
            <div class="tt-radar-grid"></div>
            <div class="tt-radar-sweep"></div>
        </div>

        <div class="tt-container" style="text-align: center; max-width: 900px; position: relative; z-index: 2;">
            <div class="tt-badge tt-badge-gold animate-hero-logo" style="margin-bottom: 24px; border-color: rgba(212, 175, 55, 0.5);">Diagnostica Premium</div>
            <h1 class="animate-hero-title" style="font-family: var(--tt-font-serif); font-size: 72px; margin-bottom: 24px; font-weight: 800; letter-spacing: -1px; color: var(--tt-white);">TopScan<span style="color: var(--tt-gold-champagne);">™</span></h1>
            <p class="animate-hero-subtitle" style="font-size: 22px; color: #cbd5e1; margin-bottom: 48px; font-weight: 300; line-height: 1.6;">
                L'osservatorio indipendente che misura il livello di raccomandabilità della tua azienda, incrociando l'opinione delle persone con l'analisi predittiva dell'Intelligenza Artificiale.
            </p>
            <div class="animate-hero-btns" style="display: flex; gap: 16px; justify-content: center;">
                <button type="button" id="open-wizard-btn" class="tt-btn tt-btn-premium" style="font-size: 16px; padding: 16px 32px; border-radius: 30px; border: none; cursor: pointer;">Avvia Simulazione Interattiva</button>
                <a href="#how-it-works" class="tt-btn tt-btn-outline" style="font-size: 16px; padding: 16px 32px; border-radius: 30px; border-color: rgba(255,255,255,0.2); color: white;">Scopri il Metodo</a>
            </div>
        </div>
    </section>

    <!-- Dashboard Interactive -->
    <section class="tt-section tt-topscan-dashboard-section" style="position: sticky; top: 0; min-height: 100vh; display: flex; flex-direction: column; justify-content: center; z-index: 15; background: var(--tt-black); padding: 40px 0; border-radius: 40px 40px 0 0; border-top: 1px solid rgba(255,255,255,0.1); box-shadow: 0 -20px 50px rgba(0,0,0,0.5);">
        <div class="tt-container">
            <div style="position: relative;">
                
                <div class="tt-dashboard-wrapper" id="dashboard-blur-target" style="filter: blur(12px); pointer-events: none; user-select: none; opacity: 0.6; transition: all 1s ease;">
                    
                    <!-- Colonna Sinistra: Radar Chart -->
                    <div>
                        <h3 style="color: var(--tt-white); font-family: var(--tt-font-sans); font-size: 18px; margin-bottom: 32px; font-weight: 500; letter-spacing: 1px; text-transform: uppercase;">Mappatura Reputazionale</h3>
                        <div style="position: relative; aspect-ratio: 1; width: 100%; max-width: 400px; margin: 0 auto;">
                            <canvas id="topscanRadar"></canvas>
                        </div>
                    </div>

                    <!-- Colonna Destra: Metriche -->
                    <div>
                        <div class="tt-dashboard-metrics-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-bottom: 40px;">
                            <div class="tt-metric-card">
                                <div class="tt-metric-value" id="final-ai-score">94<span style="font-size: 24px;">%</span></div>
                                <div class="tt-metric-label">AI Confidence Score</div>
                            </div>
                            <div class="tt-metric-card">
                                <div class="tt-metric-value" id="final-people-score">4.8<span style="font-size: 24px;">/5</span></div>
                                <div class="tt-metric-label">People Sentiment</div>
                            </div>
                        </div>

                        <div style="margin-bottom: 24px;">
                            <div style="display: flex; justify-content: space-between; color: var(--tt-white); font-size: 14px; font-weight: 500;">
                                <span>Costanza nel Tempo (Consistency)</span>
                                <span>Ottima</span>
                            </div>
                            <div class="tt-progress-track">
                                <div class="tt-progress-fill" id="final-consistency-bar" style="width: 92%; transition: width 1s ease;"></div>
                            </div>
                        </div>

                        <div style="margin-bottom: 24px;">
                            <div style="display: flex; justify-content: space-between; color: var(--tt-white); font-size: 14px; font-weight: 500;">
                                <span>Livello di Raccomandabilità</span>
                                <span>Eccezionale</span>
                            </div>
                            <div class="tt-progress-track">
                                <div class="tt-progress-fill" id="final-recommend-bar" style="width: 96%; transition: width 1s ease;"></div>
                            </div>
                        </div>

                        <div class="tt-benchmark-box">
                            <h4 id="benchmark-title" style="color: var(--tt-gold-champagne); margin-bottom: 8px; font-size: 16px;">Benchmark di Settore</h4>
                            <p style="color: #cbd5e1; font-size: 14px; margin: 0; line-height: 1.6;">
                                Il punteggio elaborato dall'AI supera la media dei competitor locali. L'algoritmo segnala un'anomalia positiva legata alla percezione del servizio e all'affidabilità. L'azienda è qualificata per accedere a Ticino Top.
                            </p>
                        </div>
                        
                        <!-- Messaggio di Candidatura (Iniettato via JS se > 85) -->
                        <div id="final-candidacy-message"></div>
                    </div>

                </div>

                <!-- Overlay di Blocco -->
                <div id="dashboard-unlock-overlay" class="reveal-on-scroll" style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; display: flex; flex-direction: column; align-items: center; justify-content: center; z-index: 20; padding: 40px; text-align: center;">
                    <div style="background: rgba(10, 25, 47, 0.8); padding: 40px; border-radius: 24px; border: 1px solid rgba(212, 175, 55, 0.3); backdrop-filter: blur(5px); box-shadow: 0 20px 40px rgba(0,0,0,0.5);">
                        <div style="font-size: 48px; margin-bottom: 16px;">🔒</div>
                        <h3 style="font-family: var(--tt-font-serif); font-size: 24px; color: var(--tt-white); margin-bottom: 16px;">Dati Protetti</h3>
                        <p style="color: #cbd5e1; margin-bottom: 24px; max-width: 300px; margin-left: auto; margin-right: auto; line-height: 1.6;">Avvia la simulazione interattiva per sbloccare il cruscotto e scoprire il tuo profilo reputazionale.</p>
                        <button onclick="document.getElementById('open-wizard-btn').click();" class="tt-btn tt-btn-premium" style="font-size: 16px; padding: 12px 24px;">Avvia Simulazione</button>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- 3 Pilastri -->
    <section id="how-it-works" class="tt-section" style="position: sticky; top: 0; min-height: 100vh; display: flex; flex-direction: column; justify-content: center; z-index: 20; background: var(--tt-white); border-radius: 40px 40px 0 0; color: var(--tt-black); padding: 120px 0; box-shadow: 0 -20px 50px rgba(0,0,0,0.5);">
        <div class="tt-container">
            <div class="reveal-on-scroll" style="text-align: center; max-width: 700px; margin: 0 auto 80px;">
                <h2 style="font-family: var(--tt-font-serif); font-size: 40px; margin-bottom: 24px;">I 3 Pilastri dell'Analisi</h2>
                <p style="font-size: 18px; color: var(--tt-gray-text);">Non ci basiamo su opinioni soggettive. Il nostro algoritmo analizza moli di dati irraggiungibili per un essere umano, restituendo un verdetto matematico.</p>
            </div>
            
            <div class="tt-grid-3 reveal-grid">
                <div style="padding: 40px; background: var(--tt-gray-light); border-radius: 20px;">
                    <div style="font-size: 40px; margin-bottom: 24px;">📊</div>
                    <h3 style="font-size: 22px; margin-bottom: 16px; font-family: var(--tt-font-serif);">Data Scraping Globale</h3>
                    <p style="color: var(--tt-gray-text); line-height: 1.6;">Il sistema raccoglie recensioni, menzioni e segnali sociali su oltre 12 piattaforme diverse (Google, Tripadvisor, Trustpilot, ecc.) per creare un profilo digitale completo.</p>
                </div>
                <div style="padding: 40px; background: var(--tt-gray-light); border-radius: 20px;">
                    <div style="font-size: 40px; margin-bottom: 24px;">🧠</div>
                    <h3 style="font-size: 22px; margin-bottom: 16px; font-family: var(--tt-font-serif);">Filtro AI Anti-Fake</h3>
                    <p style="color: var(--tt-gray-text); line-height: 1.6;">Modelli linguistici avanzati analizzano il testo delle recensioni scartando quelle palesemente false, comprate o scritte da bot, garantendo l'integrità del dato.</p>
                </div>
                <div style="padding: 40px; background: rgba(212, 175, 55, 0.05); border: 1px solid rgba(212, 175, 55, 0.2); border-radius: 20px;">
                    <div style="font-size: 40px; margin-bottom: 24px;">🏆</div>
                    <h3 style="font-size: 22px; margin-bottom: 16px; font-family: var(--tt-font-serif); color: var(--tt-gold-champagne);">Score di Ammissione</h3>
                    <p style="color: var(--tt-gray-text); line-height: 1.6;">Se l'algoritmo decreta un punteggio superiore all'85/100, l'azienda supera la barriera d'ingresso e può candidarsi per essere ufficialmente inserita nel network Ticino Top.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Wizard Modal -->
    <div class="tt-wizard-modal" id="topscan-wizard">
        <div class="tt-wizard-content">
            <div class="tt-wizard-close" id="close-wizard">✕</div>
            
            <div class="tt-wizard-progress" id="wizard-progress">
                <!-- Dots injected via JS -->
            </div>

            <div id="wizard-steps-container">
                <!-- Steps injected via JS -->
            </div>
        </div>
    </div>

</main>

<?php
// Generazione dinamica dei Benchmark di Settore dal database
$dynamic_benchmarks = [];
$category_options = [];

$terms = get_terms(array(
    'taxonomy'   => 'categoria_azienda',
    'hide_empty' => false,
));

if (!is_wp_error($terms) && !empty($terms)) {
    foreach ($terms as $term) {
        $qualita = get_term_meta($term->term_id, '_tt_benchmark_qualita', true) ?: 70;
        $fiducia = get_term_meta($term->term_id, '_tt_benchmark_fiducia', true) ?: 70;
        $servizio = get_term_meta($term->term_id, '_tt_benchmark_servizio', true) ?: 70;
        $prezzo = get_term_meta($term->term_id, '_tt_benchmark_prezzo', true) ?: 70;
        $innovazione = get_term_meta($term->term_id, '_tt_benchmark_innovazione', true) ?: 70;
        $coerenza = get_term_meta($term->term_id, '_tt_benchmark_coerenza', true) ?: 70;
        
        $term_name = html_entity_decode($term->name, ENT_QUOTES, 'UTF-8');
        
        $dynamic_benchmarks[$term_name] = [
            round($qualita), 
            round($fiducia), 
            round($servizio), 
            round($prezzo), 
            round($innovazione), 
            round($coerenza)
        ];
        
        $category_options[] = [
            'text' => $term_name,
            'sector' => $term_name,
            'impacts' => [0, 0, 0, 0, 0, 0]
        ];
    }
} else {
    // Fallback if no categories exist
    $dynamic_benchmarks['Generale'] = [70, 70, 70, 70, 70, 70];
    $category_options[] = [
        'text' => 'Generale',
        'sector' => 'Generale',
        'impacts' => [0, 0, 0, 0, 0, 0]
    ];
}
?>
<script>
const dynamicSectorBenchmarks = <?php echo json_encode($dynamic_benchmarks); ?>;
const dynamicCategoryOpts = <?php echo json_encode($category_options); ?>;

// Prendiamo i dati del primo settore come default
const firstSectorKey = Object.keys(dynamicSectorBenchmarks)[0];
const defaultBenchmarkData = dynamicSectorBenchmarks[firstSectorKey];

let radarChart;

document.addEventListener('DOMContentLoaded', function() {
    const ctx = document.getElementById('topscanRadar').getContext('2d');
    
    // Configurazione del Radar Chart (stile McKinsey / Dark Premium)
    radarChart = new Chart(ctx, {
        type: 'radar',
        data: {
            labels: ['Qualità', 'Fiducia', 'Servizio', 'Prezzo', 'Innovazione', 'Coerenza'],
            datasets: [{
                label: 'Azienda Target',
                data: [92, 88, 95, 82, 78, 96],
                backgroundColor: 'rgba(212, 175, 55, 0.2)',
                borderColor: '#D4AF37', // Gold Champagne
                pointBackgroundColor: '#D4AF37',
                pointBorderColor: '#fff',
                pointHoverBackgroundColor: '#fff',
                pointHoverBorderColor: '#D4AF37',
                borderWidth: 2,
            },
            {
                label: 'Benchmark di Settore (' + firstSectorKey + ')',
                data: defaultBenchmarkData,
                backgroundColor: 'rgba(255, 255, 255, 0.05)',
                borderColor: 'rgba(255, 255, 255, 0.3)',
                pointBackgroundColor: 'rgba(255, 255, 255, 0.5)',
                pointBorderColor: 'transparent',
                borderWidth: 1,
                borderDash: [5, 5]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            scales: {
                r: {
                    angleLines: { color: 'rgba(255, 255, 255, 0.1)' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    pointLabels: {
                        color: 'rgba(255, 255, 255, 0.7)',
                        font: {
                            family: "'Inter', sans-serif",
                            size: 11,
                            weight: '500'
                        }
                    },
                    ticks: {
                        display: false,
                        min: 0,
                        max: 100
                    }
                }
            },
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: 'rgba(255, 255, 255, 0.7)',
                        font: { family: "'Inter', sans-serif" },
                        padding: 20
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(10, 25, 47, 0.9)',
                    titleFont: { family: "'Inter', sans-serif", size: 13 },
                    bodyFont: { family: "'Inter', sans-serif", size: 12 },
                    padding: 12,
                    borderColor: 'rgba(212, 175, 55, 0.3)',
                    borderWidth: 1
                }
            }
        }
    });

    // ==========================================
    // WIZARD LOGIC
    // ==========================================
    const wizardModal = document.getElementById('topscan-wizard');
    const openBtn = document.getElementById('open-wizard-btn');
    const closeBtn = document.getElementById('close-wizard');
    const stepsContainer = document.getElementById('wizard-steps-container');
    const progressContainer = document.getElementById('wizard-progress');
    
    // Dataset benchmark per settore (Categorie dinamiche da WP)
    const sectorBenchmarks = dynamicSectorBenchmarks;
    let selectedSector = firstSectorKey;

    // Partiamo da un punteggio base ancora più sfidante (20) per bilanciare le 12 domande (ora 13 con il settore)
    let currentData = [20, 20, 20, 20, 20, 20]; 
    let currentStep = 0;

    // Ordine labels: 'Qualità', 'Fiducia', 'Servizio', 'Prezzo', 'Innovazione', 'Coerenza'
    const questions = [
        {
            q: "In quale categoria aziendale operi?",
            opts: dynamicCategoryOpts
        },
        {
            q: "Da quanti anni opera la tua azienda nel territorio?",
            opts: [
                { text: "Startup (< 2 anni)", impacts: [-5, -5, 0, 0, 15, -10] },
                { text: "Stabile (2-10 anni)", impacts: [0, 10, 0, 0, 5, 10] },
                { text: "Storica (> 10 anni)", impacts: [5, 20, 5, 0, -5, 15] }
            ]
        },
        {
            q: "Come posizioni i tuoi prodotti o servizi?",
            opts: [
                { text: "Massima convenienza", impacts: [-10, 0, 0, 25, -5, 0] },
                { text: "Qualità/Prezzo bilanciato", impacts: [10, 5, 5, 10, 5, 10] },
                { text: "Premium ed Esclusivo", impacts: [20, 10, 10, -15, 10, 5] }
            ]
        },
        {
            q: "Con quale frequenza aggiorni l'offerta o introduci novità?",
            opts: [
                { text: "Raramente (format consolidato)", impacts: [5, 10, 0, 0, -15, 15] },
                { text: "Annualmente (upgrade costanti)", impacts: [5, 5, 5, 0, 10, 10] },
                { text: "Continuamente (sperimentazione)", impacts: [5, 0, 0, 5, 25, -5] }
            ]
        },
        {
            q: "Qual è il complimento più frequente dei clienti?",
            opts: [
                { text: "«Prezzi onesti e imbattibili»", impacts: [-5, 5, 5, 20, 0, 0] },
                { text: "«Personale gentilissimo e veloce»", impacts: [5, 10, 25, 0, 0, 10] },
                { text: "«Qualità e cura dei dettagli maniacale»", impacts: [25, 10, 5, -5, 10, 5] }
            ]
        },
        {
            q: "Come gestisci i reclami o le recensioni negative?",
            opts: [
                { text: "Le ignoro o cerco di farle rimuovere", impacts: [-5, -20, -15, 0, 0, -15] },
                { text: "Rispondo solo per difendermi", impacts: [0, 5, 0, 0, 0, 5] },
                { text: "Le uso come feedback per migliorare", impacts: [10, 20, 20, 0, 10, 15] }
            ]
        },
        {
            q: "Quanto investi nella formazione del tuo team?",
            opts: [
                { text: "Solo il minimo obbligatorio", impacts: [-5, 0, -10, 5, -5, 0] },
                { text: "Qualche corso di aggiornamento", impacts: [5, 5, 10, 0, 5, 10] },
                { text: "Formazione continua e budget dedicato", impacts: [15, 15, 20, 0, 15, 15] }
            ]
        },
        {
            q: "Che percentuale dei tuoi clienti è 'ricorrente'?",
            opts: [
                { text: "Sotto il 30% (clienti occasionali)", impacts: [0, 0, 0, 10, 5, -5] },
                { text: "Tra il 30% e il 60% (buon mix)", impacts: [10, 10, 10, 5, 0, 10] },
                { text: "Oltre il 60% (clientela fedelissima)", impacts: [15, 25, 15, 0, 0, 20] }
            ]
        },
        {
            q: "Se un competitor abbassa drasticamente i prezzi, tu cosa fai?",
            opts: [
                { text: "Abbasso i prezzi anche io", impacts: [-5, -5, 0, 20, -5, -10] },
                { text: "Lancio una promozione temporanea", impacts: [0, 5, 0, 10, 5, 0] },
                { text: "Non li cambio, comunico il mio valore", impacts: [20, 15, 15, -15, 10, 20] }
            ]
        },
        {
            q: "Come misuri la soddisfazione dei tuoi clienti?",
            opts: [
                { text: "Non la misuro, mi fido dell'intuito", impacts: [-5, -10, -5, 0, 0, -10] },
                { text: "Chiedo feedback a voce quando posso", impacts: [5, 5, 5, 0, 0, 5] },
                { text: "Uso sondaggi, dati e KPI strutturati", impacts: [10, 15, 10, 0, 15, 15] }
            ]
        },
        {
            q: "Qual è il tuo canale principale di acquisizione clienti?",
            opts: [
                { text: "Passaparola spontaneo (storico)", impacts: [15, 20, 10, 0, -5, 10] },
                { text: "Sconti e offerte aggressive sui social", impacts: [-10, -5, 0, 20, 5, -15] },
                { text: "Mix di posizionamento organico e brand", impacts: [10, 10, 5, -5, 15, 15] }
            ]
        },
        {
            q: "Se sbagli e il cliente si lamenta (giustamente), qual è la tua policy?",
            opts: [
                { text: "Mi scuso ma raramente rimborso", impacts: [-5, -15, -10, 0, 0, -10] },
                { text: "Offro un piccolo sconto futuro", impacts: [5, 5, 10, 10, 0, 5] },
                { text: "Risolvo il problema subito a mie spese", impacts: [15, 25, 25, -10, 5, 15] }
            ]
        },
        {
            q: "Come vedi il futuro del tuo settore con le nuove tecnologie (es. AI)?",
            opts: [
                { text: "Una minaccia, spero passi la moda", impacts: [0, -5, 0, 0, -25, -10] },
                { text: "Un trend interessante, per ora aspetto", impacts: [5, 5, 5, 0, 5, 5] },
                { text: "Un'opportunità enorme che sto già integrando", impacts: [10, 10, 10, 0, 30, 10] }
            ]
        }
    ];

    function renderWizard() {
        progressContainer.innerHTML = questions.map((_, i) => `<div class="tt-wizard-dot ${i === currentStep ? 'active' : ''}"></div>`).join('') + `<div class="tt-wizard-dot ${currentStep === questions.length ? 'active' : ''}"></div>`;

        if (currentStep < questions.length) {
            const q = questions[currentStep];
            stepsContainer.innerHTML = `
                <div class="tt-wizard-step active">
                    <div class="tt-badge tt-badge-gold" style="margin-bottom:16px;">Step ${currentStep + 1} di ${questions.length}</div>
                    <div class="tt-wizard-q">${q.q}</div>
                    <div class="tt-wizard-options">
                        ${q.opts.map((opt, i) => `<button class="tt-wizard-btn" onclick="answerQuestion(${i})">${opt.text}</button>`).join('')}
                    </div>
                </div>
            `;
        } else {
            stepsContainer.innerHTML = `
                <div class="tt-wizard-step active">
                    <div style="font-size: 60px; margin-bottom: 24px;">🏆</div>
                    <div class="tt-wizard-q" style="color: var(--tt-gold-champagne);">Analisi Completata</div>
                    <p style="color: #94a3b8; font-size: 16px; margin-bottom: 32px;">Il motore AI ha processato le tue ${questions.length} risposte.<br>Il tuo profilo reputazionale è pronto.</p>
                    
                    <div style="margin-bottom: 32px; text-align: left;">
                        <input type="email" id="tt-wizard-email" placeholder="Inserisci la tua email per sbloccare il report" required style="width: 100%; padding: 16px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.2); background: rgba(0,0,0,0.2); color: white; font-size: 16px; outline: none; box-sizing: border-box; text-align: center; transition: border-color 0.3s;">
                        <input type="text" id="tt-wizard-hp" tabindex="-1" autocomplete="off" aria-hidden="true" style="position: absolute; left: -9999px;">
                        <p style="color: #94a3b8; font-size: 12px; line-height: 1.5; margin: 12px 0 0 0; text-align: center;"><?php echo tt_forms_privacy_notice('topscan'); ?></p>
                    </div>

                    <button class="tt-btn tt-btn-premium" style="width: 100%;" onclick="submitWizardEmail(this);">Svela il Risultato Finale</button>
                </div>
            `;
        }
    }

    window.submitWizardEmail = function(btn) {
        const emailInput = document.getElementById('tt-wizard-email');
        const email = emailInput.value.trim();
        
        if (!email || !email.includes('@') || !email.includes('.')) {
            emailInput.style.borderColor = '#ef4444';
            emailInput.focus();
            return;
        }
        
        emailInput.style.borderColor = 'rgba(255,255,255,0.2)';
        btn.innerText = 'Elaborazione in corso...';
        btn.style.opacity = '0.7';
        btn.style.pointerEvents = 'none';

        const avg = currentData.reduce((a,b)=>a+b,0) / currentData.length;
        const score = Math.round(avg);
        const peopleScore = ((avg / 100) * 5).toFixed(1);

        // Invio tramite il gestore form del parent (token, honeypot, rate limit, "Invii Ricevuti")
        const hp = document.getElementById('tt-wizard-hp');
        const sent = window.ttParentForm ? window.ttParentForm.submit({
            nome: 'Simulazione TopScan',
            email: email,
            oggetto: 'Nuova Simulazione TopScan Completata',
            messaggio: 'Settore: ' + selectedSector + '\nScore AI: ' + score + '%\nPeople Score: ' + peopleScore + '/5\n\nUn utente ha completato la simulazione TopScan e ha inserito la sua email.',
            tw_hp: hp ? hp.value : ''
        }, 'topscan') : Promise.resolve(null);

        sent.then(() => {
            setTimeout(() => {
                unlockDashboard();
            }, 600);
        });
    };

    window.unlockDashboard = function() {
        // Chiudi il modal
        document.getElementById('topscan-wizard').style.display = 'none';
        
        // Rimuovi il blur dal cruscotto
        const dashboard = document.getElementById('dashboard-blur-target');
        const overlay = document.getElementById('dashboard-unlock-overlay');
        
        dashboard.style.filter = 'none';
        dashboard.style.pointerEvents = 'auto';
        dashboard.style.opacity = '1';
        overlay.style.display = 'none';

        // Calcola i punteggi finali fittizi basati sui dati correnti per renderlo realistico
        const avg = currentData.reduce((a,b)=>a+b,0) / currentData.length;
        const peopleScore = ((avg / 100) * 5).toFixed(1);
        
        document.getElementById('final-ai-score').innerHTML = Math.round(avg) + '<span style="font-size: 24px;">%</span>';
        document.getElementById('final-people-score').innerHTML = peopleScore + '<span style="font-size: 24px;">/5</span>';
        document.getElementById('final-consistency-bar').style.width = currentData[5] + '%'; // 5 è coerenza
        document.getElementById('final-recommend-bar').style.width = currentData[1] + '%'; // 1 è fiducia
        
        // Se il punteggio supera 85, mostra il messaggio di candidatura
        if (avg >= 85) {
            document.getElementById('final-candidacy-message').innerHTML = `
                <div style="margin-top: 24px; padding: 24px; background: rgba(212, 175, 55, 0.1); border: 1px solid rgba(212, 175, 55, 0.4); border-radius: 16px; text-align: center;">
                    <h4 style="color: var(--tt-gold-champagne); margin-bottom: 12px; font-size: 20px; font-family: var(--tt-font-serif);">🎉 Sei Idoneo!</h4>
                    <p style="color: #cbd5e1; font-size: 15px; margin-bottom: 20px; line-height: 1.5;">Hai superato l'85/100. La tua azienda rispetta i rigidi standard di eccellenza. Richiedi subito l'accesso al network ufficiale Ticino Top.</p>
                    <a href="<?php echo esc_url(home_url('/candidati/')); ?>" class="tt-btn tt-btn-premium" style="display: inline-block; padding: 12px 32px;">Candidati Ora</a>
                </div>
            `;
        } else {
            document.getElementById('final-candidacy-message').innerHTML = `
                <div style="margin-top: 24px; padding: 20px; background: rgba(255, 255, 255, 0.05); border: 1px dashed rgba(255, 255, 255, 0.2); border-radius: 12px; text-align: center;">
                    <p style="color: #cbd5e1; font-size: 14px; margin: 0; line-height: 1.5;">Il punteggio calcolato è <strong style="color: #fff;">inferiore all'85/100</strong>. Il sistema AI consiglia di consolidare ulteriormente la reputazione aziendale prima di poter richiedere la candidatura a Ticino Top.</p>
                </div>
            `;
        }
        
        // Scroll smoothly to dashboard
        document.getElementById('dashboard-blur-target').scrollIntoView({ behavior: 'smooth', block: 'center' });
    };

    window.answerQuestion = function(optIndex) {
        const opt = questions[currentStep].opts[optIndex];
        const impacts = opt.impacts;
        
        // Se è la domanda sul settore, aggiorna il benchmark del grafico e il titolo
        if (opt.sector) {
            selectedSector = opt.sector;
            radarChart.data.datasets[1].data = sectorBenchmarks[selectedSector];
            document.getElementById('benchmark-title').innerText = 'Benchmark di Settore (' + selectedSector + ')';
        }

        // Aggiorna i dati correnti (assicurandosi che rimangano tra 10 e 100)
        currentData = currentData.map((val, i) => {
            let newVal = val + impacts[i];
            if(newVal > 100) newVal = 100;
            if(newVal < 10) newVal = 10;
            return newVal;
        });

        // Aggiorna il grafico in tempo reale
        radarChart.data.datasets[0].data = [...currentData];
        radarChart.update();

        // Prossimo step
        currentStep++;
        renderWizard();
    };

    openBtn.addEventListener('click', (e) => {
        e.preventDefault();
        
        // Reset a un livello base all'apertura del wizard
        currentData = [20, 20, 20, 20, 20, 20];
        radarChart.data.datasets[0].data = [...currentData];
        radarChart.update();
        
        currentStep = 0;
        renderWizard();
        wizardModal.style.display = 'flex';
    });

    closeBtn.addEventListener('click', () => {
        wizardModal.style.display = 'none';
    });
});
</script>

<?php get_footer(); ?>
