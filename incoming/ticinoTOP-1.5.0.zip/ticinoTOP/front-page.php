<?php
// Override parent theme's front-page.php and force our Home template
require_once get_stylesheet_directory() . '/template-home.php';
