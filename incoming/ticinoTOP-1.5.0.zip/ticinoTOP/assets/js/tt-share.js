/**
 * Ticino Top - condivisione e stampa PDF della scheda azienda.
 */
(function () {
  'use strict';

  var box = document.querySelector('.tt-share');
  if (!box) return;

  var url = box.getAttribute('data-share-url') || window.location.href;
  var title = box.getAttribute('data-share-title') || document.title;
  var feedback = box.querySelector('.tt-share-feedback');

  function say(text) {
    if (!feedback) return;
    feedback.textContent = text;
    clearTimeout(say.t);
    say.t = setTimeout(function () { feedback.textContent = ''; }, 2500);
  }

  /* Copia link: API Clipboard, poi metodo classico, infine il link da copiare a mano */
  function legacyCopy(text) {
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    var ok = false;
    try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
    document.body.removeChild(ta);
    return ok;
  }

  var copyBtn = box.querySelector('.tt-share-copy');
  if (copyBtn) {
    copyBtn.addEventListener('click', function () {
      var fallback = function () {
        if (legacyCopy(url)) {
          say('Link copiato');
        } else {
          window.prompt('Copia il link:', url);
        }
      };
      if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(url).then(function () { say('Link copiato'); }, fallback);
      } else {
        fallback();
      }
    });
  }

  /* Condivisione nativa (smartphone): visibile solo se il browser la supporta */
  var nativeBtn = box.querySelector('.tt-share-native');
  if (nativeBtn && navigator.share) {
    nativeBtn.hidden = false;
    nativeBtn.addEventListener('click', function () {
      navigator.share({ title: title, url: url }).catch(function () {});
    });
  }

  /* PDF: stampa del browser con il foglio di stile di stampa; il titolo diventa il nome del file */
  var printBtn = box.querySelector('.tt-print-btn');
  if (printBtn) {
    printBtn.addEventListener('click', function () {
      var original = document.title;
      var name = (document.querySelector('.tt-company-hero-title') || {}).textContent || '';
      document.title = 'Ticino Top - ' + name.trim();
      var restore = function () {
        document.title = original;
        window.removeEventListener('afterprint', restore);
      };
      window.addEventListener('afterprint', restore);
      window.print();
    });
  }
})();
