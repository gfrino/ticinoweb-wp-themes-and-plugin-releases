/**
 * Ticino Top - invio form tramite il gestore AJAX del parent (ticinoweb_submit_form).
 * Token chiesto al momento dell'invio (le pagine sono in cache LiteSpeed), reCAPTCHA v3 se configurato.
 */
(function () {
  'use strict';

  var cfg = window.ticinoweb_ai_main || {};
  var recaptchaReady = null;

  function loadRecaptcha() {
    if (recaptchaReady || !cfg.recaptcha_site_key) return;
    recaptchaReady = new Promise(function (resolve) {
      var s = document.createElement('script');
      s.src = 'https://www.google.com/recaptcha/api.js?render=' + encodeURIComponent(cfg.recaptcha_site_key);
      s.async = true;
      s.onload = resolve;
      s.onerror = resolve;
      document.head.appendChild(s);
    });
  }

  function getRecaptchaToken(action) {
    if (!cfg.recaptcha_site_key) return Promise.resolve('');
    loadRecaptcha();
    return recaptchaReady.then(function () {
      if (!window.grecaptcha || !grecaptcha.execute) return '';
      return new Promise(function (resolve) {
        grecaptcha.ready(function () {
          grecaptcha.execute(cfg.recaptcha_site_key, { action: action || 'contact' }).then(resolve, function () { resolve(''); });
        });
      });
    });
  }

  function getToken() {
    return fetch(cfg.ajax_url + '?action=' + encodeURIComponent(cfg.token_action || 'ticinoweb_form_token'), {
      credentials: 'same-origin',
      cache: 'no-store'
    }).then(function (r) { return r.json(); }).then(function (d) {
      return d && d.success && d.data ? d.data.token : '';
    });
  }

  /**
   * Invia un oggetto {campo: valore}. Risolve con la risposta JSON del parent ({success, data}).
   */
  function submit(fields, action) {
    if (!cfg.ajax_url) {
      return Promise.resolve({ success: false, data: { message: 'Il modulo non è disponibile al momento.' } });
    }
    return Promise.all([getToken(), getRecaptchaToken(action)]).then(function (tokens) {
      var fd = new FormData();
      Object.keys(fields).forEach(function (k) { fd.append(k, fields[k] == null ? '' : fields[k]); });
      fd.append('action', cfg.submit_action || 'ticinoweb_submit_form');
      fd.append('token', tokens[0]);
      if (tokens[1]) fd.append('recaptcha_token', tokens[1]);
      return fetch(cfg.ajax_url, { method: 'POST', body: fd, credentials: 'same-origin' });
    }).then(function (r) { return r.json(); }).catch(function () {
      return { success: false, data: { message: 'Invio non riuscito, riprova tra qualche istante.' } };
    });
  }

  window.ttParentForm = { submit: submit, preload: loadRecaptcha };

  /* Form candidature */
  var form = document.getElementById('tt-candidatura-form');
  if (!form) return;

  var okBox = document.getElementById('tt-candidatura-success');
  var errBox = document.getElementById('tt-candidatura-error');
  var btn = form.querySelector('button[type="submit"]');
  var btnLabel = btn ? btn.textContent : '';

  form.addEventListener('focusin', loadRecaptcha, { once: true });

  form.addEventListener('submit', function (e) {
    // Il pulsante "Test Invio Mail" (solo admin) usa il normale invio POST della pagina
    if (e.submitter && e.submitter.getAttribute('data-tt-native')) return;
    e.preventDefault();
    if (errBox) errBox.style.display = 'none';
    if (!form.reportValidity()) return;

    var v = function (name) { var el = form.elements[name]; return el ? el.value.trim() : ''; };
    var azienda = v('nome_azienda');
    var categoria = v('categoria');
    var referente = v('referente');

    var messaggio = [
      'Azienda: ' + azienda,
      'Categoria: ' + categoria,
      'Link per Scanner AI: ' + v('link_fonte'),
      'Referente: ' + (referente || '-'),
      '',
      'Perché merita l\'accesso:',
      v('motivazione') || '-'
    ].join('\n');

    if (btn) { btn.disabled = true; btn.textContent = 'Invio in corso…'; }

    submit({
      tt_form: 'candidatura',
      nome: referente || azienda,
      email: v('email'),
      telefono: v('telefono'),
      oggetto: 'Candidatura Ticino Top: ' + azienda + (categoria ? ' - ' + categoria : ''),
      messaggio: messaggio,
      nome_azienda: azienda,
      categoria: categoria,
      link_fonte: v('link_fonte'),
      motivazione: v('motivazione'),
      tw_hp: v('tw_hp')
    }, 'candidatura').then(function (res) {
      if (res && res.success) {
        form.style.display = 'none';
        if (okBox) { okBox.style.display = 'block'; okBox.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
        return;
      }
      if (errBox) {
        errBox.textContent = (res && res.data && res.data.message) ? res.data.message : 'Invio non riuscito, riprova.';
        errBox.style.display = 'block';
      }
      if (btn) { btn.disabled = false; btn.textContent = btnLabel; }
    });
  });
})();
