/*
 * Sfondo «mesh» della homepage: passa al CSS quanto si e' scorso (--tg-s, in
 * pixel), e il CSS sposta le quattro macchie a velocita' diverse. Un solo
 * aggiornamento per fotogramma, nessun lavoro quando la parte alta e' fuori
 * vista, niente movimento con «riduci movimento».
 */
( function () {
	var mesh = document.querySelector( '[data-tg-mesh]' );
	if ( ! mesh || ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) ) {
		return;
	}
	var queued = false;
	var last = -1;
	function update() {
		queued = false;
		var y = Math.min( Math.max( window.scrollY || 0, 0 ), 1400 );
		if ( y !== last ) {
			last = y;
			mesh.style.setProperty( '--tg-s', y );
		}
	}
	window.addEventListener( 'scroll', function () {
		if ( ! queued ) {
			queued = true;
			window.requestAnimationFrame( update );
		}
	}, { passive: true } );
	update();
}() );
