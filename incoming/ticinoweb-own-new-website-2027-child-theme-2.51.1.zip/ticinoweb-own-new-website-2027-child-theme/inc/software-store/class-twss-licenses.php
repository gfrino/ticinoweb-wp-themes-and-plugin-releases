<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Licenze dei plugin venduti. A ordine completato, Odoo (GestaClient su ticinoweb.online) crea una chiave per
 * ogni plugin dell'ordine: la chiave resta nella riga dell'ordine e si vede nell'email «Ordine completato», nel
 * dettaglio dell'ordine e in Il mio account. Rimborso o annullamento: Odoo spegne le licenze dell'ordine.
 *
 * Richieste firmate HMAC-SHA256 con il segreto condiviso (costante TWSS_LICENSE_SECRET in wp-config o opzione
 * twss_license_secret, non autoload). Se Odoo non risponde il pagamento non si blocca mai: nuovo tentativo in
 * background e, quando la chiave arriva, il cliente la riceve con una nota dell'ordine (email).
 */
class Twss_Licenses {
    const META = '_twss_license_key';
    const RETRY_HOOK = 'twss_license_retry';
    const REVOKE_HOOK = 'twss_license_revoke_retry';
    const CATALOG_HOOK = 'twss_license_catalog';
    const CATALOG_DAILY = 'twss_license_catalog_daily';
    const OPT_CATALOG = 'twss_license_catalog_last';
    const OPT_SECRET = 'twss_license_secret';
    const ODOO = 'https://ticinoweb.online';
    /** Attese fra un tentativo e l'altro (secondi): 5 min, 15 min, 1 ora, poi ogni 6 ore per due giorni. */
    const DELAYS = array(300, 900, 3600, 21600, 21600, 21600, 21600, 21600, 21600, 21600, 21600);

    public static function init() {
        // Priorità 5: prima dell'email «Ordine completato» (10), così la chiave è già nell'email.
        add_action('woocommerce_order_status_completed', array(__CLASS__, 'on_completed'), 5, 2);
        add_action('woocommerce_order_status_refunded', array(__CLASS__, 'on_revoked'), 10, 2);
        add_action('woocommerce_order_status_cancelled', array(__CLASS__, 'on_revoked'), 10, 2);
        add_action(self::RETRY_HOOK, array(__CLASS__, 'retry'), 10, 2);
        add_action(self::REVOKE_HOOK, array(__CLASS__, 'retry_revoke'), 10, 2);
        add_filter('woocommerce_order_item_get_formatted_meta_data', array(__CLASS__, 'show_key'), 10, 2);
        // Elenco dei plugin in vendita in Odoo: quando un plugin entra o esce dal negozio, e una volta al giorno.
        add_action('transition_post_status', array(__CLASS__, 'on_product_status'), 10, 3);
        add_action(self::CATALOG_HOOK, array(__CLASS__, 'push_catalog'));
        add_action(self::CATALOG_DAILY, array(__CLASS__, 'push_catalog'));
        add_action('init', function () {
            if (!wp_next_scheduled(self::CATALOG_DAILY)) {
                wp_schedule_event(time() + 600, 'daily', self::CATALOG_DAILY);
            }
        });
    }

    /** Un plugin del negozio pubblicato, tolto, cestinato: fra un minuto Odoo riceve l'elenco aggiornato. */
    public static function on_product_status($new, $old, $post) {
        if ($new === $old || !$post || 'product' !== $post->post_type || ('publish' !== $new && 'publish' !== $old)) {
            return;
        }
        if ('' === (string) get_post_meta($post->ID, '_twss_slug', true) || wp_next_scheduled(self::CATALOG_HOOK)) {
            return;
        }
        wp_schedule_single_event(time() + 60, self::CATALOG_HOOK);
    }

    /** Plugin in vendita adesso (prodotti pubblicati del software store): slug => nome. */
    public static function catalog() {
        $out = array();
        $ids = get_posts(array('post_type' => 'product', 'post_status' => 'publish', 'numberposts' => -1, 'fields' => 'ids',
            'meta_key' => '_twss_slug', 'meta_compare' => 'EXISTS')); // phpcs:ignore WordPress.DB.SlowDBQuery
        foreach ($ids as $id) {
            $slug = (string) get_post_meta($id, '_twss_slug', true);
            if ('' !== $slug) {
                $out[$slug] = get_the_title($id);
            }
        }
        return $out;
    }

    /** Manda a Odoo l'elenco completo dei plugin in vendita. @return array|WP_Error */
    public static function push_catalog() {
        $list = array();
        foreach (self::catalog() as $slug => $name) {
            $list[] = array('slug' => $slug, 'name' => html_entity_decode($name, ENT_QUOTES, 'UTF-8'));
        }
        $res = $list ? self::call('/tw_app/license/plugins', array('plugins' => $list))
            : new WP_Error('twss_license', __('Nessun plugin in vendita: elenco non mandato.', 'ticinoweb-child-theme'));
        update_option(self::OPT_CATALOG, array('t' => time(), 'count' => count($list),
            'result' => is_wp_error($res) ? array() : $res, 'error' => is_wp_error($res) ? $res->get_error_message() : ''), false);
        if (is_wp_error($res)) {
            Twss_Settings::log('licenze', 'Elenco plugin a Odoo: ' . $res->get_error_message(), 'error');
        }
        return $res;
    }

    public static function secret() {
        if (defined('TWSS_LICENSE_SECRET') && TWSS_LICENSE_SECRET) {
            return (string) TWSS_LICENSE_SECRET;
        }
        return (string) get_option(self::OPT_SECRET, '');
    }

    public static function odoo() {
        return untrailingslashit(defined('TWSS_LICENSE_ODOO') && TWSS_LICENSE_ODOO ? TWSS_LICENSE_ODOO : self::ODOO);
    }

    /** Il negozio come lo vede Odoo (ordine = «ticinoweb.com #1234»). */
    private static function shop() {
        $host = strtolower((string) wp_parse_url(home_url(), PHP_URL_HOST));
        return 0 === strpos($host, 'www.') ? substr($host, 4) : $host;
    }

    /** Righe dell'ordine che sono plugin in vendita: item_id => slug. */
    public static function plugin_items(WC_Order $order) {
        $out = array();
        foreach ($order->get_items() as $item_id => $item) {
            $slug = (string) get_post_meta((int) $item->get_product_id(), '_twss_slug', true);
            if ('' !== $slug) {
                $out[$item_id] = $slug;
            }
        }
        return $out;
    }

    /** POST firmato a Odoo: array con la risposta, oppure WP_Error. */
    private static function call($path, array $data) {
        $secret = self::secret();
        if ('' === $secret) {
            return new WP_Error('twss_license', __('Manca il segreto per Odoo (WooCommerce → Software Store → Licenze).', 'ticinoweb-child-theme'));
        }
        $data['ts'] = time();
        $data['shop'] = self::shop();
        $body = wp_json_encode($data);
        $res = wp_remote_post(self::odoo() . $path, array(
            'timeout' => 15,
            'headers' => array('Content-Type' => 'application/json', 'X-TW-Signature' => hash_hmac('sha256', $body, $secret)),
            'body' => $body,
        ));
        if (is_wp_error($res)) {
            return $res;
        }
        $code = (int) wp_remote_retrieve_response_code($res);
        $json = json_decode((string) wp_remote_retrieve_body($res), true);
        if (200 !== $code || !is_array($json)) {
            /* translators: 1: HTTP status code, 2: error code returned by Odoo */
            return new WP_Error('twss_license', sprintf(__('Odoo ha risposto %1$d (%2$s).', 'ticinoweb-child-theme'), $code, is_array($json) && isset($json['error']) ? $json['error'] : '-'));
        }
        return $json;
    }

    /**
     * Chiede a Odoo le chiavi delle righe che non ce l'hanno ancora e le salva nelle righe.
     * @return array|WP_Error item_id => chiave delle righe nuove
     */
    public static function issue(WC_Order $order) {
        $lines = array();
        foreach (self::plugin_items($order) as $item_id => $slug) {
            $item = $order->get_item($item_id);
            if ($item && '' === (string) $item->get_meta(self::META)) {
                $lines[] = array('id' => (string) $item_id, 'plugin' => $slug, 'name' => $item->get_name(), 'qty' => (int) $item->get_quantity());
            }
        }
        if (!$lines) {
            return array();
        }
        $res = self::call('/tw_app/license/issue', array(
            'order' => (string) $order->get_order_number(),
            'email' => $order->get_billing_email(),
            'name' => trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()),
            'company' => $order->get_billing_company(),
            'lines' => $lines,
        ));
        if (is_wp_error($res)) {
            return $res;
        }
        $new = array();
        foreach ((array) ($res['licenses'] ?? array()) as $lic) {
            $item = $order->get_item((int) ($lic['line'] ?? 0));
            $key = isset($lic['key']) ? sanitize_text_field($lic['key']) : '';
            if ($item && '' !== $key) {
                $item->update_meta_data(self::META, $key);
                $item->save();
                $new[$item->get_id()] = $key;
            }
        }
        return $new;
    }

    public static function on_completed($order_id, $order = null) {
        $order = $order instanceof WC_Order ? $order : wc_get_order($order_id);
        if (!$order || !self::plugin_items($order)) {
            return;
        }
        $res = self::issue($order);
        if (is_wp_error($res)) {
            self::schedule($order, 0, $res);
            return;
        }
        if ($res) {
            $order->add_order_note(__('Chiavi di licenza create in Odoo (GestaClient).', 'ticinoweb-child-theme'));
        }
    }

    public static function retry($order_id, $attempt = 1) {
        $order = wc_get_order($order_id);
        if (!$order || !$order->has_status('completed')) {
            return;
        }
        $res = self::issue($order);
        if (is_wp_error($res)) {
            self::schedule($order, (int) $attempt, $res);
            return;
        }
        if ($res) {
            // L'email «Ordine completato» è già partita senza chiave: la mandiamo con una nota per il cliente.
            $order->add_order_note(self::customer_note($order, $res), 1);
            Twss_Settings::log('licenze', sprintf('Ordine %s: chiavi create al tentativo %d.', $order->get_order_number(), (int) $attempt + 1));
        }
    }

    private static function schedule(WC_Order $order, $attempt, WP_Error $error) {
        Twss_Settings::log('licenze', sprintf('Ordine %s: %s', $order->get_order_number(), $error->get_error_message()), 'error');
        if (!isset(self::DELAYS[$attempt])) {
            $order->add_order_note(sprintf(
                /* translators: %s: error message */
                __('Chiavi di licenza NON create: %s Riprova con WP-CLI: wp tw-store license <numero ordine>.', 'ticinoweb-child-theme'),
                $error->get_error_message()
            ));
            return;
        }
        $when = time() + self::DELAYS[$attempt];
        if (function_exists('as_schedule_single_action')) {
            as_schedule_single_action($when, self::RETRY_HOOK, array($order->get_id(), $attempt + 1), 'twss');
        } else {
            wp_schedule_single_event($when, self::RETRY_HOOK, array($order->get_id(), $attempt + 1));
        }
        if (0 === $attempt) {
            $order->add_order_note(sprintf(
                /* translators: %s: error message */
                __('Chiavi di licenza non ancora create (%s). Nuovi tentativi automatici: il cliente riceverà la chiave per email.', 'ticinoweb-child-theme'),
                $error->get_error_message()
            ));
        }
    }

    private static function customer_note(WC_Order $order, array $keys) {
        $lines = array();
        foreach ($keys as $item_id => $key) {
            $item = $order->get_item($item_id);
            $lines[] = ($item ? $item->get_name() : '') . ': ' . $key;
        }
        return __('Ecco la chiave di licenza del tuo acquisto:', 'ticinoweb-child-theme') . "\n" . implode("\n", $lines) . "\n"
            . __('Incollala nelle impostazioni del plugin: il sito si attiva da solo. La trovi anche in Il mio account → Ordini.', 'ticinoweb-child-theme');
    }

    public static function on_revoked($order_id, $order = null) {
        $order = $order instanceof WC_Order ? $order : wc_get_order($order_id);
        if (!$order) {
            return;
        }
        $has_key = false;
        foreach (array_keys(self::plugin_items($order)) as $item_id) {
            $item = $order->get_item($item_id);
            $has_key = $has_key || ($item && '' !== (string) $item->get_meta(self::META));
        }
        if ($has_key) {
            self::retry_revoke($order->get_id(), 0);
        }
    }

    public static function retry_revoke($order_id, $attempt = 0) {
        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }
        $res = self::call('/tw_app/license/revoke', array('order' => (string) $order->get_order_number(), 'reason' => $order->get_status()));
        if (!is_wp_error($res)) {
            $order->add_order_note(__('Licenze dell\'ordine spente in Odoo (GestaClient).', 'ticinoweb-child-theme'));
            return;
        }
        Twss_Settings::log('licenze', sprintf('Ordine %s, revoca: %s', $order->get_order_number(), $res->get_error_message()), 'error');
        if (isset(self::DELAYS[$attempt]) && function_exists('as_schedule_single_action')) {
            as_schedule_single_action(time() + self::DELAYS[$attempt], self::REVOKE_HOOK, array($order->get_id(), $attempt + 1), 'twss');
        } else {
            $order->add_order_note(__('Licenze NON spente in Odoo: spegnile a mano in GestaClient → Plugin WordPress → Licenze.', 'ticinoweb-child-theme'));
        }
    }

    /** La chiave come riga visibile dell'ordine (email, Il mio account, dettaglio ordine in bacheca). */
    public static function show_key($formatted, $item) {
        if (!$item instanceof WC_Order_Item_Product) {
            return $formatted;
        }
        $key = (string) $item->get_meta(self::META);
        if ('' !== $key) {
            $formatted['twss_license'] = (object) array(
                'key' => 'twss_license',
                'value' => $key,
                'display_key' => __('Chiave di licenza', 'ticinoweb-child-theme'),
                'display_value' => '<code>' . esc_html($key) . '</code>',
            );
        }
        return $formatted;
    }

    /**
     * Zip di un plugin a pagamento da Odoo (non sta nel repo pubblico): link firmato, download, controllo SHA-256.
     * @return string|WP_Error file temporaneo (da cancellare a cura del chiamante)
     */
    public static function download_zip($slug, $version) {
        $info = self::call('/tw_app/license/shop-package', array('plugin' => $slug, 'version' => $version));
        if (is_wp_error($info)) {
            return $info;
        }
        $url = (string) ($info['url'] ?? '');
        if (0 !== strpos($url, self::odoo() . '/tw_app/license/zip/')) {
            return new WP_Error('twss_license', __('Odoo non ha dato un link valido per lo zip.', 'ticinoweb-child-theme'));
        }
        if (!function_exists('download_url')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }
        $tmp = download_url($url, 300);
        if (is_wp_error($tmp)) {
            return $tmp;
        }
        if (!empty($info['sha256']) && !hash_equals((string) $info['sha256'], (string) hash_file('sha256', $tmp))) {
            @unlink($tmp); // phpcs:ignore WordPress.PHP.NoSilencedErrors
            return new WP_Error('twss_license', __('Lo zip scaricato da Odoo non corrisponde (SHA-256).', 'ticinoweb-child-theme'));
        }
        return $tmp;
    }

    /** Prova del collegamento senza effetti: revoca di un ordine che non esiste. */
    public static function test() {
        $res = self::call('/tw_app/license/revoke', array('order' => 'prova-collegamento'));
        return is_wp_error($res) ? $res : true;
    }
}
