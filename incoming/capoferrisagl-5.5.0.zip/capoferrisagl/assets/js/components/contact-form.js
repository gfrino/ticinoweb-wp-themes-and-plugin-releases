/**
 * Modulo contatti: validazione frontend, stati di invio e feedback
 * accessibili. La validazione autorevole resta lato server.
 */

export function initContactForm() {
    const form = document.querySelector('[data-cfs-contact]');
    if (!form || typeof window.cfsData === 'undefined') {
        return;
    }

    const submit = form.querySelector('[data-submit]');
    const feedback = form.querySelector('[data-feedback]');

    const setError = (name, message) => {
        const field = form.querySelector(`[name="${name}"]`);
        const box = form.querySelector(`#cfs-${name}-error`);
        if (field) {
            field.classList.toggle('is-invalid', Boolean(message));
            field.setAttribute('aria-invalid', message ? 'true' : 'false');
        }
        if (box) {
            box.textContent = message || '';
        }
        return !message;
    };

    const validate = () => {
        let valid = true;
        const value = (name) => (form.querySelector(`[name="${name}"]`)?.value || '').trim();

        valid = setError('name', value('name').length < 2 ? 'Inserisci il tuo nome e cognome.' : '') && valid;
        valid = setError('email', /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value('email')) ? '' : 'Inserisci un indirizzo email valido.') && valid;
        valid = setError('message', value('message').length < 10 ? 'Scrivi un messaggio di almeno 10 caratteri.' : '') && valid;
        valid = setError('privacy', form.querySelector('[name="privacy"]')?.checked ? '' : 'Devi accettare l\'informativa sulla privacy.') && valid;

        return valid;
    };

    form.querySelectorAll('input, textarea, select').forEach((field) => {
        field.addEventListener('blur', () => {
            if (field.classList.contains('is-invalid')) {
                validate();
            }
        });
    });

    form.addEventListener('submit', async (event) => {
        event.preventDefault();

        feedback.textContent = '';
        feedback.className = 'cfs-form__feedback';

        if (!validate()) {
            const invalid = form.querySelector('.is-invalid');
            if (invalid) {
                invalid.focus();
            }
            return;
        }

        submit.disabled = true;
        submit.textContent = submit.dataset.sending;

        const data = new FormData(form);
        data.append('action', 'cfs_contact');

        try {
            const response = await fetch(window.cfsData.ajaxUrl, {
                method: 'POST',
                credentials: 'same-origin',
                body: data,
            });
            const result = await response.json();

            if (result.success) {
                feedback.textContent = result.data.message;
                feedback.classList.add('is-success');
                form.reset();
            } else {
                feedback.textContent = result.data?.message || 'Si è verificato un errore. Riprova.';
                feedback.classList.add('is-error');
                if (result.data?.field) {
                    setError(result.data.field, result.data.message);
                }
            }
        } catch (error) {
            feedback.textContent = 'Non è stato possibile inviare la richiesta. Riprova o chiamaci.';
            feedback.classList.add('is-error');
        } finally {
            submit.disabled = false;
            submit.textContent = submit.dataset.label;
        }
    });
}
