<?php
/**
 * CPT Servizi: registrazione, schema dei campi, metabox a tab,
 * riordino drag & drop e duplicazione.
 *
 * @package Capoferrisagl
 */

if (!defined('ABSPATH')) {
    exit;
}

/* ─────────────────────────────────────────────
   REGISTRAZIONE
   ───────────────────────────────────────────── */

add_action('init', 'cfs_register_servizi');
function cfs_register_servizi()
{
    register_post_type('cfs_servizio', array(
        'labels' => array(
            'name'               => __('Servizi', 'capoferrisagl'),
            'singular_name'      => __('Servizio', 'capoferrisagl'),
            'add_new'            => __('Aggiungi servizio', 'capoferrisagl'),
            'add_new_item'       => __('Aggiungi nuovo servizio', 'capoferrisagl'),
            'edit_item'          => __('Modifica servizio', 'capoferrisagl'),
            'new_item'           => __('Nuovo servizio', 'capoferrisagl'),
            'view_item'          => __('Vedi servizio', 'capoferrisagl'),
            'search_items'       => __('Cerca servizi', 'capoferrisagl'),
            'not_found'          => __('Nessun servizio presente. Aggiungi il primo servizio.', 'capoferrisagl'),
            'not_found_in_trash' => __('Nessun servizio nel cestino.', 'capoferrisagl'),
            'menu_name'          => __('Servizi', 'capoferrisagl'),
        ),
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => 'capoferri', // menu proprio, separato dal ticinoWEB CMS
        'menu_position'      => 31,
        'menu_icon'          => 'dashicons-admin-tools',
        'capability_type'    => 'post',
        'hierarchical'       => false,
        'supports'           => array('title', 'thumbnail', 'page-attributes', 'revisions'),
        'has_archive'        => false,
        'rewrite'            => array('slug' => 'servizi', 'with_front' => false),
        'show_in_rest'       => false,
    ));
}

/**
 * Tipologie di blocco disponibili nella tab Contenuto.
 */
function cfs_block_types()
{
    return array(
        'title_text'       => __('Titolo e testo', 'capoferrisagl'),
        'text_image_right' => __('Testo con immagine a destra', 'capoferrisagl'),
        'text_image_left'  => __('Testo con immagine a sinistra', 'capoferrisagl'),
        'image_full'       => __('Immagine a tutta larghezza', 'capoferrisagl'),
        'two_columns'      => __('Testo a due colonne', 'capoferrisagl'),
        'list'             => __('Elenco puntato', 'capoferrisagl'),
        'benefits'         => __('Elenco dei vantaggi', 'capoferrisagl'),
        'quote'            => __('Citazione', 'capoferrisagl'),
        'cta'              => __('Call to action', 'capoferrisagl'),
        'gallery'          => __('Galleria', 'capoferrisagl'),
        'separator'        => __('Separatore', 'capoferrisagl'),
        'spacer'           => __('Spazio controllato', 'capoferrisagl'),
    );
}

/* ─────────────────────────────────────────────
   SCHEMA CAMPI (tab del servizio)
   ───────────────────────────────────────────── */

function cfs_service_tabs()
{
    $text_types  = array('title_text', 'text_image_right', 'text_image_left', 'two_columns', 'list', 'benefits', 'quote', 'cta');
    $image_types = array('text_image_right', 'text_image_left', 'image_full');

    return array(

        'info' => array(
            'label'  => __('Informazioni', 'capoferrisagl'),
            'desc'   => __('Dati principali del servizio. Il titolo si modifica nel campo in alto.', 'capoferrisagl'),
            'fields' => array(
                'label'       => array('type' => 'text', 'label' => __('Etichetta', 'capoferrisagl'), 'desc' => __('Testo breve mostrato sopra il titolo (facoltativo). Es. “Servizio”.', 'capoferrisagl')),
                'excerpt'     => array('type' => 'textarea', 'label' => __('Descrizione breve', 'capoferrisagl'), 'rows' => 3, 'counter' => 180, 'desc' => __('Usata nelle card della Home e della pagina Servizi.', 'capoferrisagl')),
                'intro'       => array('type' => 'textarea', 'label' => __('Introduzione', 'capoferrisagl'), 'rows' => 4, 'desc' => __('Primo testo della pagina interna. Lascia una riga vuota per separare i paragrafi.', 'capoferrisagl')),
                'intro_title' => array('type' => 'text', 'label' => __('Titolo dell\'introduzione', 'capoferrisagl')),
                'intro_image' => array('type' => 'image', 'label' => __('Immagine dell\'introduzione', 'capoferrisagl')),
            ),
        ),

        'hero' => array(
            'label'  => __('Hero', 'capoferrisagl'),
            'desc'   => __('Prima schermata della pagina del servizio.', 'capoferrisagl'),
            'fields' => array(
                'hero_title'    => array('type' => 'text', 'label' => __('Titolo alternativo', 'capoferrisagl'), 'desc' => __('Se vuoto viene usato il titolo del servizio.', 'capoferrisagl')),
                'hero_intro'    => array('type' => 'textarea', 'label' => __('Testo introduttivo', 'capoferrisagl'), 'rows' => 3),
                'cover_desktop' => array('type' => 'image', 'label' => __('Immagine di copertina (desktop)', 'capoferrisagl'), 'desc' => __('Usata anche come immagine della card nelle liste servizi.', 'capoferrisagl')),
                'cover_mobile'  => array('type' => 'image', 'label' => __('Immagine di copertina (mobile)', 'capoferrisagl'), 'desc' => __('Facoltativa: se vuota si usa quella desktop.', 'capoferrisagl')),
                'cover_alt'     => array('type' => 'text', 'label' => __('Testo alternativo della copertina', 'capoferrisagl'), 'desc' => __('Se vuoto viene usato quello della Libreria multimediale.', 'capoferrisagl')),
                'cover_caption' => array('type' => 'text', 'label' => __('Didascalia della copertina', 'capoferrisagl')),
                'cover_focal'   => array('type' => 'focal', 'label' => __('Punto focale della copertina', 'capoferrisagl'), 'desc' => __('Definisce quale parte della foto resta visibile nei ritagli.', 'capoferrisagl')),
                'hero_cta_text' => array('type' => 'text', 'label' => __('Testo del pulsante', 'capoferrisagl')),
                'hero_cta_url'  => array('type' => 'url', 'label' => __('Link del pulsante', 'capoferrisagl')),
                'hero_number'   => array('type' => 'text', 'label' => __('Numero progressivo', 'capoferrisagl'), 'desc' => __('Dettaglio grafico facoltativo, es. “01”.', 'capoferrisagl')),
            ),
        ),

        'content' => array(
            'label'  => __('Contenuto', 'capoferrisagl'),
            'desc'   => __('Blocchi modulari della pagina. Trascinali per riordinarli, disattivane uno per nasconderlo senza eliminarlo.', 'capoferrisagl'),
            'fields' => array(
                'blocks' => array(
                    'type'      => 'repeater',
                    'add_label' => __('Aggiungi sezione', 'capoferrisagl'),
                    'row_label' => __('Sezione', 'capoferrisagl'),
                    'row_title' => 'heading',
                    'empty'     => __('Nessuna sezione presente. Aggiungi la prima sezione di contenuto.', 'capoferrisagl'),
                    'fields'    => array(
                        'type'    => array('type' => 'select', 'label' => __('Tipo di sezione', 'capoferrisagl'), 'options' => cfs_block_types(), 'default' => 'title_text'),
                        'heading' => array('type' => 'text', 'label' => __('Titolo', 'capoferrisagl'), 'show_if' => array('type' => $text_types)),
                        'text'    => array('type' => 'textarea', 'label' => __('Testo', 'capoferrisagl'), 'rows' => 6, 'show_if' => array('type' => array('title_text', 'text_image_right', 'text_image_left', 'two_columns', 'quote', 'cta'))),
                        'items'   => array('type' => 'textarea', 'label' => __('Voci dell\'elenco', 'capoferrisagl'), 'rows' => 6, 'desc' => __('Una voce per riga.', 'capoferrisagl'), 'show_if' => array('type' => array('list', 'benefits'))),
                        'image'   => array('type' => 'image', 'label' => __('Immagine', 'capoferrisagl'), 'show_if' => array('type' => $image_types)),
                        'image_caption' => array('type' => 'text', 'label' => __('Didascalia immagine', 'capoferrisagl'), 'show_if' => array('type' => $image_types)),
                        'gallery' => array('type' => 'gallery', 'label' => __('Immagini della galleria', 'capoferrisagl'), 'show_if' => array('type' => array('gallery'))),
                        'author'  => array('type' => 'text', 'label' => __('Autore della citazione', 'capoferrisagl'), 'show_if' => array('type' => array('quote'))),
                        'cta_text' => array('type' => 'text', 'label' => __('Testo del pulsante', 'capoferrisagl'), 'show_if' => array('type' => array('cta', 'title_text', 'text_image_right', 'text_image_left'))),
                        'cta_url'  => array('type' => 'url', 'label' => __('Link del pulsante', 'capoferrisagl'), 'show_if' => array('type' => array('cta', 'title_text', 'text_image_right', 'text_image_left'))),
                        'space'    => array('type' => 'select', 'label' => __('Altezza dello spazio', 'capoferrisagl'), 'options' => array('sm' => __('Piccolo', 'capoferrisagl'), 'md' => __('Medio', 'capoferrisagl'), 'lg' => __('Grande', 'capoferrisagl')), 'default' => 'md', 'show_if' => array('type' => array('spacer'))),
                    ),
                ),
            ),
        ),

        'strengths' => array(
            'label'  => __('Punti di forza', 'capoferrisagl'),
            'desc'   => __('Elenco sintetico mostrato accanto all\'introduzione del servizio.', 'capoferrisagl'),
            'fields' => array(
                'strengths' => array(
                    'type'      => 'repeater',
                    'add_label' => __('Aggiungi punto di forza', 'capoferrisagl'),
                    'row_label' => __('Punto di forza', 'capoferrisagl'),
                    'row_title' => 'title',
                    'empty'     => __('Nessun punto di forza inserito.', 'capoferrisagl'),
                    'fields'    => array(
                        'title' => array('type' => 'text', 'label' => __('Titolo', 'capoferrisagl')),
                        'text'  => array('type' => 'textarea', 'label' => __('Descrizione', 'capoferrisagl'), 'rows' => 3),
                        'icon'  => array('type' => 'image', 'label' => __('Icona', 'capoferrisagl'), 'desc' => __('Facoltativa.', 'capoferrisagl')),
                    ),
                ),
            ),
        ),

        'gallery' => array(
            'label'  => __('Galleria', 'capoferrisagl'),
            'desc'   => __('Immagini dei lavori riferite a questo servizio. Se la galleria è vuota, la sezione non viene mostrata nel sito.', 'capoferrisagl'),
            'fields' => array(
                'gallery_title' => array('type' => 'text', 'label' => __('Titolo della galleria', 'capoferrisagl')),
                'gallery_text'  => array('type' => 'textarea', 'label' => __('Testo introduttivo', 'capoferrisagl'), 'rows' => 3),
                'gallery'       => array('type' => 'gallery', 'label' => __('Immagini', 'capoferrisagl')),
            ),
        ),

        'cta' => array(
            'label'  => __('Call to action', 'capoferrisagl'),
            'desc'   => __('Sezione finale della pagina. Se lasci vuoto il titolo viene usata la call to action globale.', 'capoferrisagl'),
            'fields' => array(
                'cta_title'      => array('type' => 'text', 'label' => __('Titolo', 'capoferrisagl')),
                'cta_text'       => array('type' => 'textarea', 'label' => __('Testo', 'capoferrisagl'), 'rows' => 3),
                'cta_btn1_text'  => array('type' => 'text', 'label' => __('Pulsante principale — testo', 'capoferrisagl')),
                'cta_btn1_url'   => array('type' => 'url', 'label' => __('Pulsante principale — link', 'capoferrisagl')),
                'cta_btn2_text'  => array('type' => 'text', 'label' => __('Pulsante secondario — testo', 'capoferrisagl')),
                'cta_btn2_url'   => array('type' => 'url', 'label' => __('Pulsante secondario — link', 'capoferrisagl')),
                'cta_image'      => array('type' => 'image', 'label' => __('Immagine di sfondo', 'capoferrisagl')),
            ),
        ),

        'seo' => array(
            'label'  => __('SEO', 'capoferrisagl'),
            'desc'   => __('Come appare la pagina nei risultati di ricerca e nelle condivisioni social.', 'capoferrisagl'),
            'fields' => array(
                'seo_title'  => array('type' => 'text', 'label' => __('SEO title', 'capoferrisagl'), 'counter' => 60, 'desc' => __('Se vuoto viene usato il titolo del servizio.', 'capoferrisagl')),
                'seo_desc'   => array('type' => 'textarea', 'label' => __('Meta description', 'capoferrisagl'), 'rows' => 3, 'counter' => 160, 'desc' => __('Se vuota viene usata la descrizione breve.', 'capoferrisagl')),
                'seo_image'  => array('type' => 'image', 'label' => __('Immagine Open Graph', 'capoferrisagl'), 'desc' => __('Se vuota viene usata la copertina.', 'capoferrisagl')),
                'seo_canonical' => array('type' => 'url', 'label' => __('URL canonico', 'capoferrisagl'), 'desc' => __('Da compilare solo in casi particolari.', 'capoferrisagl')),
                'seo_noindex'   => array('type' => 'checkbox', 'label' => __('Indicizzazione', 'capoferrisagl'), 'checkbox_label' => __('Escludi questa pagina dai motori di ricerca', 'capoferrisagl')),
            ),
        ),
    );
}

/**
 * Tutte le chiavi meta gestite (per il salvataggio).
 */
function cfs_service_field_keys()
{
    $keys = array();
    foreach (cfs_service_tabs() as $tab) {
        foreach (array_keys($tab['fields']) as $key) {
            $keys[] = $key;
        }
    }
    return $keys;
}

/* ─────────────────────────────────────────────
   METABOX
   ───────────────────────────────────────────── */

add_action('add_meta_boxes', 'cfs_service_metaboxes');
function cfs_service_metaboxes()
{
    add_meta_box(
        'cfs_service_data',
        __('Contenuti del servizio', 'capoferrisagl'),
        'cfs_render_service_metabox',
        'cfs_servizio',
        'normal',
        'high'
    );
}

function cfs_render_service_metabox($post)
{
    wp_nonce_field('cfs_save_service_' . $post->ID, 'cfs_service_nonce');

    $tabs   = cfs_service_tabs();
    $values = array();
    foreach (cfs_service_field_keys() as $key) {
        $values[$key] = get_post_meta($post->ID, '_cfs_' . $key, true);
    }
    $first = array_key_first($tabs);
    ?>
    <div class="cfs-admin cfs-admin--metabox">
        <nav class="cfs-tabs" data-cfs-tabs>
            <?php foreach ($tabs as $tab_id => $tab) : ?>
                <button type="button" class="cfs-tabs__btn<?php echo $tab_id === $first ? ' is-active' : ''; ?>"
                        data-tab="<?php echo esc_attr($tab_id); ?>"
                        aria-selected="<?php echo $tab_id === $first ? 'true' : 'false'; ?>">
                    <?php echo esc_html($tab['label']); ?>
                </button>
            <?php endforeach; ?>
        </nav>

        <?php foreach ($tabs as $tab_id => $tab) : ?>
            <section class="cfs-panel<?php echo $tab_id === $first ? ' is-active' : ''; ?>" data-panel="<?php echo esc_attr($tab_id); ?>">
                <?php if (!empty($tab['desc'])) : ?>
                    <p class="cfs-panel__desc"><?php echo wp_kses_post($tab['desc']); ?></p>
                <?php endif; ?>
                <?php cfs_render_fields($tab['fields'], $values, 'cfs_service'); ?>
            </section>
        <?php endforeach; ?>
    </div>
    <?php
}

add_action('save_post_cfs_servizio', 'cfs_save_service', 10, 2);
function cfs_save_service($post_id, $post)
{
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (!isset($_POST['cfs_service_nonce']) || !wp_verify_nonce(sanitize_key(wp_unslash($_POST['cfs_service_nonce'])), 'cfs_save_service_' . $post_id)) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    $raw = isset($_POST['cfs_service']) ? wp_unslash($_POST['cfs_service']) : array();
    $raw = is_array($raw) ? $raw : array();

    foreach (cfs_service_field_keys() as $key) {
        $value = isset($raw[$key]) ? cfs_sanitize_recursive($raw[$key]) : '';
        update_post_meta($post_id, '_cfs_' . $key, $value);
    }

    // La copertina alimenta anche l'immagine in evidenza (usata dai social e dalle liste).
    $cover = (int) get_post_meta($post_id, '_cfs_cover_desktop', true);
    if ($cover) {
        set_post_thumbnail($post_id, $cover);
    }
}

/* ─────────────────────────────────────────────
   LISTA SERVIZI: colonne, riordino, duplica
   ───────────────────────────────────────────── */

add_filter('manage_cfs_servizio_posts_columns', 'cfs_service_columns');
function cfs_service_columns($columns)
{
    $new = array(
        'cb'          => $columns['cb'],
        'cfs_thumb'   => __('Copertina', 'capoferrisagl'),
        'title'       => __('Titolo', 'capoferrisagl'),
        'cfs_slug'    => __('Slug', 'capoferrisagl'),
        'cfs_status'  => __('Stato', 'capoferrisagl'),
        'cfs_order'   => __('Ordine', 'capoferrisagl'),
        'cfs_actions' => __('Azioni', 'capoferrisagl'),
        'date'        => __('Ultima modifica', 'capoferrisagl'),
    );
    return $new;
}

add_action('manage_cfs_servizio_posts_custom_column', 'cfs_service_column_content', 10, 2);
function cfs_service_column_content($column, $post_id)
{
    switch ($column) {
        case 'cfs_thumb':
            $cover = cfs_service_cover($post_id);
            if ($cover) {
                echo wp_get_attachment_image($cover, array(80, 60), false, array('style' => 'border-radius:4px;object-fit:cover;'));
            } else {
                echo '<span class="cfs-admin-hint">' . esc_html__('Seleziona un\'immagine di copertina.', 'capoferrisagl') . '</span>';
            }
            break;

        case 'cfs_slug':
            echo '<code>' . esc_html(get_post_field('post_name', $post_id)) . '</code>';
            break;

        case 'cfs_status':
            $status = get_post_status($post_id);
            $labels = array('publish' => __('Pubblicato', 'capoferrisagl'), 'draft' => __('Bozza', 'capoferrisagl'), 'pending' => __('In revisione', 'capoferrisagl'), 'private' => __('Privato', 'capoferrisagl'));
            printf('<span class="cfs-badge cfs-badge--%s">%s</span>', esc_attr($status), esc_html($labels[$status] ?? $status));
            break;

        case 'cfs_order':
            echo (int) get_post_field('menu_order', $post_id);
            break;

        case 'cfs_actions':
            $duplicate = wp_nonce_url(
                admin_url('admin-post.php?action=cfs_duplicate_service&post=' . $post_id),
                'cfs_duplicate_' . $post_id
            );
            printf(
                '<a href="%s">%s</a> · <a href="%s">%s</a> · <a href="%s">%s</a>',
                esc_url(get_edit_post_link($post_id)),
                esc_html__('Modifica', 'capoferrisagl'),
                esc_url($duplicate),
                esc_html__('Duplica', 'capoferrisagl'),
                esc_url(get_preview_post_link($post_id)),
                esc_html__('Anteprima', 'capoferrisagl')
            );
            break;
    }
}

/** Ordinamento predefinito nella lista admin: come nel sito. */
add_action('pre_get_posts', 'cfs_admin_service_order');
function cfs_admin_service_order($query)
{
    if (!is_admin() || !$query->is_main_query()) {
        return;
    }
    if ($query->get('post_type') === 'cfs_servizio' && !$query->get('orderby')) {
        $query->set('orderby', 'menu_order title');
        $query->set('order', 'ASC');
    }
}

/** Duplicazione di un servizio. */
add_action('admin_post_cfs_duplicate_service', 'cfs_duplicate_service');
function cfs_duplicate_service()
{
    $post_id = isset($_GET['post']) ? absint($_GET['post']) : 0;
    if (!$post_id || !current_user_can('edit_posts')) {
        wp_die(esc_html__('Permessi insufficienti.', 'capoferrisagl'));
    }
    check_admin_referer('cfs_duplicate_' . $post_id);

    $original = get_post($post_id);
    if (!$original || $original->post_type !== 'cfs_servizio') {
        wp_die(esc_html__('Servizio non trovato.', 'capoferrisagl'));
    }

    $new_id = wp_insert_post(array(
        'post_type'   => 'cfs_servizio',
        'post_title'  => $original->post_title . ' ' . __('(copia)', 'capoferrisagl'),
        'post_status' => 'draft',
        'menu_order'  => $original->menu_order,
    ));

    if (!is_wp_error($new_id)) {
        foreach (get_post_meta($post_id) as $key => $values) {
            if (strpos($key, '_cfs_') === 0) {
                update_post_meta($new_id, $key, maybe_unserialize($values[0]));
            }
        }
    }

    wp_safe_redirect(admin_url('edit.php?post_type=cfs_servizio&cfs_duplicated=1'));
    exit;
}

/* ─────────────────────────────────────────────
   RIORDINO DRAG & DROP (pagina dedicata)
   ───────────────────────────────────────────── */

add_action('wp_ajax_cfs_reorder_services', 'cfs_ajax_reorder_services');
function cfs_ajax_reorder_services()
{
    check_ajax_referer('cfs_reorder', 'nonce');

    if (!current_user_can('edit_posts')) {
        wp_send_json_error(array('message' => __('Permessi insufficienti.', 'capoferrisagl')), 403);
    }

    $order = isset($_POST['order']) ? array_map('absint', (array) wp_unslash($_POST['order'])) : array();
    if (!$order) {
        wp_send_json_error(array('message' => __('Ordine non valido.', 'capoferrisagl')), 400);
    }

    foreach ($order as $position => $post_id) {
        if (get_post_type($post_id) === 'cfs_servizio') {
            wp_update_post(array('ID' => $post_id, 'menu_order' => $position + 1));
        }
    }

    wp_send_json_success(array('message' => __('Ordine salvato.', 'capoferrisagl')));
}
