<?php
/**
 * Struttura iniziale del sito: pagine, menu e contenuti di partenza.
 *
 * Viene eseguita una sola volta (flag in option). Da lì in poi ogni testo
 * si modifica dal backend: questa routine non sovrascrive nulla di esistente.
 *
 * @package Capoferrisagl
 */

if (!defined('ABSPATH')) {
    exit;
}

define('CFS_SETUP_VERSION', 2);

add_action('after_switch_theme', 'cfs_run_setup');
add_action('admin_init', 'cfs_maybe_run_setup');

function cfs_maybe_run_setup()
{
    if ((int) get_option('cfs_setup_version', 0) < CFS_SETUP_VERSION) {
        cfs_run_setup();
    }
}

function cfs_run_setup()
{
    cfs_setup_pages();
    cfs_setup_menu();
    cfs_setup_defaults();
    cfs_setup_services();

    update_option('cfs_setup_version', CFS_SETUP_VERSION);
    flush_rewrite_rules();
}

/* ─────────────────────────────────────────────
   PAGINE
   ───────────────────────────────────────────── */

function cfs_setup_pages()
{
    $pages = array(
        'home'            => array('title' => 'Home', 'template' => ''),
        'servizi'         => array('title' => 'Servizi', 'template' => 'page-servizi.php'),
        'chi-siamo'       => array('title' => 'Chi siamo', 'template' => 'page-chi-siamo.php'),
        'contatti'        => array('title' => 'Contatti', 'template' => 'page-contatti.php'),
        'privacy-policy'  => array('title' => 'Privacy Policy', 'template' => ''),
        'cookie-policy'   => array('title' => 'Cookie Policy', 'template' => ''),
    );

    $ids = get_option('cfs_page_ids', array());

    foreach ($pages as $slug => $data) {
        $existing = get_page_by_path($slug);

        if ($existing) {
            $page_id = $existing->ID;
        } else {
            $page_id = wp_insert_post(array(
                'post_type'   => 'page',
                'post_status' => 'publish',
                'post_title'  => $data['title'],
                'post_name'   => $slug,
            ));
        }

        if (is_wp_error($page_id) || !$page_id) {
            continue;
        }

        if ($data['template']) {
            update_post_meta($page_id, '_wp_page_template', $data['template']);
        }
        $ids[$slug] = (int) $page_id;
    }

    update_option('cfs_page_ids', $ids);

    // La home mostra la front-page del tema.
    if (!empty($ids['home'])) {
        update_option('show_on_front', 'page');
        update_option('page_on_front', $ids['home']);
    }
}

/* ─────────────────────────────────────────────
   MENU
   ───────────────────────────────────────────── */

function cfs_setup_menu()
{
    $menu_name = 'Menu Principale';
    $menu      = wp_get_nav_menu_object($menu_name);

    if (!$menu) {
        $menu_id = wp_create_nav_menu($menu_name);
        if (is_wp_error($menu_id)) {
            return;
        }
    } else {
        $menu_id = $menu->term_id;
        if (wp_get_nav_menu_items($menu_id)) {
            cfs_assign_menu_location($menu_id);
            return; // Menu già popolato: non tocchiamo le scelte dell'utente.
        }
    }

    $ids = get_option('cfs_page_ids', array());
    foreach (array('home', 'servizi', 'chi-siamo', 'contatti') as $position => $slug) {
        if (empty($ids[$slug])) {
            continue;
        }
        wp_update_nav_menu_item($menu_id, 0, array(
            'menu-item-object-id' => $ids[$slug],
            'menu-item-object'    => 'page',
            'menu-item-type'      => 'post_type',
            'menu-item-status'    => 'publish',
            'menu-item-position'  => $position + 1,
        ));
    }

    cfs_assign_menu_location($menu_id);
}

function cfs_assign_menu_location($menu_id)
{
    $locations = get_theme_mod('nav_menu_locations', array());
    if (empty($locations['primary'])) {
        $locations['primary'] = $menu_id;
        set_theme_mod('nav_menu_locations', $locations);
    }
}

/* ─────────────────────────────────────────────
   CONTENUTI DI PARTENZA
   ───────────────────────────────────────────── */

/**
 * Scrive i valori solo se l'option è ancora vuota.
 */
function cfs_seed_option($key, $values)
{
    $current = get_option($key, array());
    if (!is_array($current)) {
        $current = array();
    }
    update_option($key, array_replace_recursive($values, $current));
}

function cfs_setup_defaults()
{
    $ids  = get_option('cfs_page_ids', array());
    $url  = function ($slug) use ($ids) {
        return !empty($ids[$slug]) ? get_permalink($ids[$slug]) : home_url('/');
    };

    /* Impostazioni globali — dati verificati dal sito e dal documento di modifiche. */
    cfs_seed_option('cfs_settings', array(
        'company_name'       => 'Capoferri',
        'legal_name'         => 'Capoferri Servizi Ecologici Sagl',
        'street'             => 'Via al Dosso 30',
        'po_box'             => 'Casella Postale 67',
        'postal_code'        => '6828',
        'city'               => 'Balerna',
        'country'            => 'Svizzera',
        'legal_address_label'=> 'Sede legale / Corrispondenza',
        'op_street'          => 'Via alle Zocche 19',
        'op_postal_code'     => '6874',
        'op_city'            => 'Castel San Pietro',
        'op_address_label'   => 'Sede operativa',
        'phone'              => '+41 (0)91 682 23 38',
        'phone_raw'          => '+41916822338',
        'email'              => 'ecoservice@capoferrisagl.ch',
        'cta_text'           => 'Richiedi un intervento',
        'cta_url'            => $url('contatti'),
        'mobile_bar'         => '1',
        'footer_services'    => 'Servizi',
        'footer_contacts'    => 'Contatti',
        'copyright'          => '© %s Capoferri Servizi Ecologici Sagl',
        'breadcrumb_home'    => 'Home',
        'related_title'      => 'Altri servizi',
        'legal_links'        => array(
            array('text' => 'Privacy Policy', 'url' => $url('privacy-policy'), 'enabled' => '1'),
            array('text' => 'Cookie Policy', 'url' => $url('cookie-policy'), 'enabled' => '1'),
        ),
        'e404_title'         => 'Pagina non trovata',
        'e404_text'          => 'La pagina che cercavi non esiste o è stata spostata.',
        'e404_btn'           => 'Torna alla home',
        'e404_url'           => home_url('/'),
        'cta_title'          => 'Hai bisogno di un intervento o di maggiori informazioni?',
        'cta_btn1_text'      => 'Contattaci',
        'cta_btn1_url'       => $url('contatti'),
        'cta_btn2_text'      => 'Guarda i nostri servizi',
        'cta_btn2_url'       => $url('servizi'),
    ));

    /* Home */
    cfs_seed_option('cfs_home', array(
        'hero' => array(
            'label'       => 'Servizi ecologici — Ticino',
            'title'       => "Interventi professionali.\nSoluzioni concrete.",
            'subtitle'    => 'Manutenzione delle canalizzazioni, pulizia di pozzi e strade, ispezioni con videocamere.',
            'btn1_text'   => 'Richiedi un intervento',
            'btn1_url'    => $url('contatti'),
            'btn2_text'   => 'Guarda i nostri servizi',
            'btn2_url'    => $url('servizi'),
            'position'    => 'left',
            'scroll_hint' => 'Scorri',
        ),
        'intro' => array(
            'enabled' => '1',
            'label'   => 'Chi siamo',
            'title'   => 'Solidità, continuità ed esperienza',
            'text'    => "La ditta Capoferri, con i sofisticati mezzi a disposizione, è specializzata nella manutenzione in genere delle canalizzazioni sia verticali che orizzontali e nella ricerca di eventuali danni tramite ispezioni con videocamere.\n\nSiamo attenti ai problemi dei nostri clienti e alla ricerca di sempre nuovi servizi e prodotti, con la preoccupazione di trovare soluzioni sostenibili e rispettose dell'ambiente.",
            'btn_text' => 'Scopri chi siamo',
            'btn_url'  => $url('chi-siamo'),
            'strengths' => array(
                array('title' => 'Prontezza di intervento', 'text' => '', 'enabled' => '1'),
                array('title' => 'Professionalità dei collaboratori', 'text' => '', 'enabled' => '1'),
                array('title' => 'Mezzi e attrezzature aggiornati', 'text' => '', 'enabled' => '1'),
            ),
        ),
        'services' => array(
            'enabled'  => '1',
            'label'    => 'Servizi',
            'title'    => 'Come possiamo aiutarti',
            'btn_text' => 'Guarda tutti i servizi',
            'btn_url'  => $url('servizi'),
            'limit'    => '0',
        ),
        'method' => array(
            'enabled' => '1',
            'label'   => 'Metodo',
            'title'   => 'Come lavoriamo',
            'steps'   => array(
                array('title' => 'Ascolto della richiesta', 'text' => '', 'enabled' => '1'),
                array('title' => 'Analisi del problema', 'text' => '', 'enabled' => '1'),
                array('title' => 'Intervento con mezzi adeguati', 'text' => '', 'enabled' => '1'),
                array('title' => 'Assistenza alla clientela', 'text' => '', 'enabled' => '1'),
            ),
        ),
        'gallery' => array(
            'enabled' => '1',
            'label'   => 'Lavori',
            'title'   => 'I nostri interventi',
        ),
        'cta' => array(
            'enabled'   => '1',
            'title'     => 'Hai bisogno di un intervento o di maggiori informazioni?',
            'btn1_text' => 'Contattaci',
            'btn1_url'  => $url('contatti'),
            'btn2_text' => 'Chiama ora',
            'btn2_url'  => 'tel:+41916822338',
        ),
    ));

    /* Chi siamo — testi ripresi dal sito precedente. */
    cfs_seed_option('cfs_about', array(
        'hero' => array(
            'label' => 'Chi siamo',
            'title' => 'La nostra storia',
        ),
        'intro' => array(
            'enabled' => '1',
            'title'   => 'Una ditta costruita sull\'esperienza',
            'text'    => "Da questo breve profilo si riesce a capire che la solidità, la continuità e l'esperienza hanno un'importanza fondamentale.\n\nSono costruite sulla capacità di essere attenti ai problemi dei propri clienti e sulla ricerca di sempre nuovi servizi e prodotti, con la preoccupazione di trovare soluzioni sostenibili e rispettose dell'ambiente, mettendo sempre a disposizione di clienti privati, studi di architettura e ingegneria, comuni, consorzi di depurazione e aziende la propria esperienza per risolvere le problematiche inerenti a tutte le opere che abbiamo sotto i nostri piedi e che troppo spesso trascuriamo.",
        ),
        'story' => array(
            'enabled' => '1',
            'label'   => 'Storia',
            'title'   => 'Dalla fine degli anni 60 a oggi',
            'text'    => "La storia della ditta Capoferri ha inizio alla fine degli anni 60.\n\nAll'epoca il Signor Martinelli Gianni dà inizio a questa attività acquistando un'autocisterna, rispondendo così alle esigenze del mercato di quegli anni. L'attività viene portata avanti con successo dal Signor Martinelli fino al 1989.\n\nIn quell'anno il Signor Capoferri Geremia, già suo prezioso collaboratore, fonda la ditta Capoferri sulle solide basi della precedente e due anni dopo anche il figlio Maurizio si aggrega a questa avventura.\n\nLa ditta, con queste maestranze, prosegue fino al 2017, quando anche i figli di quest'ultimo decidono di “salire a bordo” per dare continuità a questa storica ditta.",
            'layout'  => 'side',
        ),
        'timeline' => array(
            'enabled' => '1',
            'title'   => 'Le tappe principali',
            'items'   => array(
                array('year' => 'Fine anni 60', 'title' => 'L\'inizio dell\'attività', 'text' => 'Il Signor Martinelli Gianni dà inizio all\'attività acquistando un\'autocisterna.', 'enabled' => '1'),
                array('year' => '1989', 'title' => 'Nasce la ditta Capoferri', 'text' => 'Il Signor Capoferri Geremia, già prezioso collaboratore, fonda la ditta sulle solide basi della precedente.', 'enabled' => '1'),
                array('year' => '1991', 'title' => 'Il figlio Maurizio in azienda', 'text' => 'Due anni dopo la fondazione, anche il figlio Maurizio si aggrega a questa avventura.', 'enabled' => '1'),
                array('year' => '2017', 'title' => 'La nuova generazione', 'text' => 'I figli di Maurizio decidono di “salire a bordo” per dare continuità a questa storica ditta.', 'enabled' => '1'),
            ),
        ),
        'values' => array(
            'enabled' => '1',
            'title'   => 'I nostri valori',
            'items'   => array(
                array('title' => 'Solidità', 'text' => 'Una struttura costruita nel tempo, con continuità generazionale.', 'enabled' => '1'),
                array('title' => 'Prontezza di intervento', 'text' => 'Rapidità nel rispondere alle richieste della clientela.', 'enabled' => '1'),
                array('title' => 'Rispetto dell\'ambiente', 'text' => 'Ricerca di soluzioni sostenibili e rispettose dell\'ambiente.', 'enabled' => '1'),
                array('title' => 'Competenza tecnica', 'text' => 'Mezzi sofisticati e aggiornati per ogni tipo di intervento.', 'enabled' => '1'),
            ),
        ),
        'quote' => array(
            'enabled' => '1',
            'text'    => 'I punti forti della ditta Capoferri sono la prontezza di intervento, nonché la professionalità che tutti i suoi collaboratori mettono quotidianamente a disposizione della clientela.',
        ),
        'cta' => array(
            'enabled'   => '1',
            'title'     => 'Parliamo del tuo intervento',
            'btn1_text' => 'Contattaci',
            'btn1_url'  => $url('contatti'),
        ),
    ));

    /* Contatti */
    cfs_seed_option('cfs_contact', array(
        'hero' => array(
            'label' => 'Contatti',
            'title' => 'Parliamone',
            'intro' => 'Scrivici o chiamaci: ti rispondiamo al più presto.',
        ),
        'info' => array(
            'hours_title' => 'Orari',
        ),
        'map' => array(
            'enabled' => '1',
            'title'   => 'Mappa della sede di Balerna',
        ),
        'form' => array(
            'title'         => 'Mandaci un messaggio',
            'label_name'    => 'Nome e cognome',
            'label_email'   => 'Email',
            'label_phone'   => 'Telefono',
            'label_service' => 'Servizio di interesse',
            'label_message' => 'Messaggio',
            'label_privacy' => 'Acconsento al trattamento dei miei dati per essere ricontattato.',
            'submit'        => 'Invia la richiesta',
            'sending'       => 'Invio in corso…',
            'success'       => 'Grazie, abbiamo ricevuto la tua richiesta. Ti ricontattiamo al più presto.',
            'error'         => 'Non è stato possibile inviare la richiesta. Riprova oppure chiamaci.',
        ),
        'mail' => array(
            'subject' => 'Nuova richiesta dal sito Capoferri',
        ),
    ));
}

/* ─────────────────────────────────────────────
   SERVIZI
   ───────────────────────────────────────────── */

/**
 * Servizi del sito con i contenuti aggiornati secondo le specifiche del PDF.
 */
function cfs_get_pdf_services_data()
{
    return array(
        array(
            'title'   => 'Manutenzione delle canalizzazioni',
            'slug'    => 'manutenzione-delle-canalizzazioni',
            'excerpt' => 'Risolviamo otturazioni e rotture delle canalizzazioni orizzontali e verticali, delle acque scure o chiare, su condotte di tutti i diametri.',
            'intro'   => "Grazie alle apparecchiature professionali di cui disponiamo, siamo in grado di intervenire in modo efficace e risolutivo su qualsiasi problema di otturazione, ostruzione o rottura delle canalizzazioni, sia orizzontali che verticali.\n\nInterveniamo su impianti per acque chiare e acque scure, risolvendo problematiche che interessano, ad esempio, scarichi di lavandini, bagni, docce e WC, oltre alle condotte fognarie di qualsiasi diametro.\n\nUn intervento preciso e mirato, pensato per individuare e risolvere il problema alla radice, riducendo al minimo disagi e tempi di intervento.",
        ),
        array(
            'title'   => 'Pulizia di pozzi in genere e strade',
            'slug'    => 'pulizia-di-pozzi-in-genere-e-strade',
            'excerpt' => 'Pulizia di fosse biologiche, pozzi perdenti, pozzi pompa, pozzetti stradali e separatori di idrocarburi.',
            'intro'   => "Effettuiamo la pulizia periodica e straordinaria di fosse biologiche, pozzi perdenti, pozzi pompa, pozzetti stradali e impianti separatori di idrocarburi con idropulitrici ad alta pressione e mezzi di aspirazione avanzati.",
        ),
        array(
            'title'   => 'Ispezioni con videocamere',
            'slug'    => 'ispezioni-con-videocamere',
            'excerpt' => 'Ricerca e diagnosi di eventuali danni alle condotte tramite ispezioni con videocamere ad alta risoluzione.',
            'intro'   => "Grazie a sistemi di ispezione video ad alta risoluzione, siamo in grado di esplorare le canalizzazioni dall'interno, individuando tempestivamente rotture, ostruzioni, schiacciamenti o infiltrazioni di radici senza interventi demolitivi.",
        ),
        array(
            'title'   => 'Localizzazione e ricerca canalizzazioni',
            'slug'    => 'localizzazione-e-ricerca-canalizzazioni',
            'old_slug'=> 'localizzazione-dei-punti-critici',
            'excerpt' => 'Localizzazione di pozzetti smarriti o nascosti, tracciamento del percorso delle canalizzazioni ed individuazione dei punti critici.',
            'intro'   => "Quando il pozzetto o la canalizzazione non si trova più:\n\nA volte, inavvertitamente o senza pensare alle conseguenze, vengono dimenticati sotto il manto erboso o sotto pavimentazioni varie i pozzetti d'ispezione delle canalizzazioni. Quando poi si rende necessario accedervi per un controllo, non si riesce più a trovare la loro posizione.\n\nEcco allora che con degli appositi localizzatori siamo in grado di individuarli senza inutili scavi di sondaggio.\n\nI nostri detector vengono inoltre impiegati per tracciare con precisione l'intero percorso delle canalizzazioni o per stabilire l'esatto punto in cui, per esempio, si sono infiltrate delle radici.",
        ),
        array(
            'title'   => 'Prove di tenuta canalizzazioni e collaudo nuove canalizzazioni',
            'slug'    => 'prove-di-tenuta-e-collaudo-canalizzazioni',
            'excerpt' => 'Prove di tenuta in pressione con palloni e collaudo funzionale di nuove canalizzazioni tramite video ispezione. Tenuta perfetta, ambiente protetto!',
            'intro'   => "Una prova di tenuta verifica che le tubazioni non presentino perdite, mantenendole in pressione con degli appositi palloni per verificarne la tenuta stagna.\n\nIl collaudo di una nuova canalizzazione consiste nel verificarne il corretto funzionamento tramite video ispezione.\n\nTenuta perfetta, ambiente protetto!",
        ),
        array(
            'title'   => 'Assistenza alla clientela',
            'slug'    => 'assistenza-alla-clientela',
            'excerpt' => 'Consulenza e supporto tecnico per privati, architetti, ingegneri, comuni e consorzi.',
            'intro'   => "Mettiamo la nostra esperienza a disposizione di clienti privati, studi di architettura e ingegneria, comuni e consorzi per la risoluzione di qualsiasi problematica riguardante le canalizzazioni.",
        ),
        array(
            'title'   => 'Servizi di noleggio',
            'slug'    => 'servizi-di-noleggio',
            'excerpt' => 'Noleggio di attrezzature e mezzi specializzati per l\'intervento sulle canalizzazioni.',
            'intro'   => "Noleggio di attrezzature professionali per la pulizia, ispezione e disostruzione delle canalizzazioni.",
        ),
    );
}

function cfs_setup_services()
{
    $services = cfs_get_pdf_services_data();

    foreach ($services as $position => $service) {
        $existing = get_page_by_path($service['slug'], OBJECT, 'cfs_servizio');

        if (!$existing && !empty($service['old_slug'])) {
            $existing = get_page_by_path($service['old_slug'], OBJECT, 'cfs_servizio');
        }

        if ($existing) {
            $post_id = $existing->ID;
            wp_update_post(array(
                'ID'         => $post_id,
                'post_title' => $service['title'],
                'post_name'  => $service['slug'],
                'menu_order' => $position + 1,
            ));
        } else {
            $post_id = wp_insert_post(array(
                'post_type'   => 'cfs_servizio',
                'post_status' => 'publish',
                'post_title'  => $service['title'],
                'post_name'   => $service['slug'],
                'menu_order'  => $position + 1,
            ));
        }

        if (is_wp_error($post_id) || !$post_id) {
            continue;
        }

        update_post_meta($post_id, '_cfs_label', 'Servizio');
        update_post_meta($post_id, '_cfs_excerpt', $service['excerpt']);
        update_post_meta($post_id, '_cfs_intro', $service['intro']);
        update_post_meta($post_id, '_cfs_hero_number', str_pad((string) ($position + 1), 2, '0', STR_PAD_LEFT));
    }
}
