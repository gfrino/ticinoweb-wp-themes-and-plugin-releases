<?php
/**
 * Modulo contatti: CPT delle richieste ricevute, gestione invio AJAX,
 * validazione, antispam e schermate del backend.
 *
 * @package Capoferrisagl
 */

if (!defined('ABSPATH')) {
    exit;
}

/* ─────────────────────────────────────────────
   CPT RICHIESTE
   ───────────────────────────────────────────── */

add_action('init', 'cfs_register_leads');
function cfs_register_leads()
{
    register_post_type('cfs_lead', array(
        'labels' => array(
            'name'          => __('Moduli ricevuti', 'capoferrisagl'),
            'singular_name' => __('Richiesta', 'capoferrisagl'),
            'menu_name'     => __('Moduli ricevuti', 'capoferrisagl'),
            'edit_item'     => __('Richiesta', 'capoferrisagl'),
            'search_items'  => __('Cerca richieste', 'capoferrisagl'),
            'not_found'     => __('Nessuna richiesta ricevuta.', 'capoferrisagl'),
            'not_found_in_trash' => __('Nessuna richiesta nel cestino.', 'capoferrisagl'),
        ),
        'public'             => false,
        'show_ui'            => true,
        'show_in_menu'       => 'capoferri',
        'capability_type'    => 'post',
        'capabilities'       => array('create_posts' => 'do_not_allow'),
        'map_meta_cap'       => true,
        'supports'           => array('title'),
        'menu_icon'          => 'dashicons-email-alt',
    ));

    register_post_status('cfs_new', array(
        'label'                     => __('Nuova', 'capoferrisagl'),
        'public'                    => false,
        'internal'                  => true,
        'show_in_admin_all_list'    => true,
        'show_in_admin_status_list' => true,
        'label_count'               => _n_noop('Nuova <span class="count">(%s)</span>', 'Nuove <span class="count">(%s)</span>', 'capoferrisagl'),
    ));
}

/**
 * Stati gestionali della richiesta (salvati come meta, non come post_status,
 * per non interferire con le liste standard di WordPress).
 */
function cfs_lead_statuses()
{
    return array(
        'new'       => __('Nuova', 'capoferrisagl'),
        'read'      => __('Letta', 'capoferrisagl'),
        'progress'  => __('In gestione', 'capoferrisagl'),
        'done'      => __('Completata', 'capoferrisagl'),
        'archived'  => __('Archiviata', 'capoferrisagl'),
    );
}

/* ─────────────────────────────────────────────
   LISTA RICHIESTE
   ───────────────────────────────────────────── */

add_filter('manage_cfs_lead_posts_columns', function () {
    return array(
        'cb'          => '<input type="checkbox">',
        'cfs_date'    => __('Data e ora', 'capoferrisagl'),
        'cfs_name'    => __('Nome', 'capoferrisagl'),
        'cfs_email'   => __('Email', 'capoferrisagl'),
        'cfs_phone'   => __('Telefono', 'capoferrisagl'),
        'cfs_service' => __('Servizio', 'capoferrisagl'),
        'cfs_status'  => __('Stato', 'capoferrisagl'),
    );
});

add_action('manage_cfs_lead_posts_custom_column', function ($column, $post_id) {
    switch ($column) {
        case 'cfs_date':
            printf(
                '<a href="%s"><strong>%s</strong></a>',
                esc_url(get_edit_post_link($post_id)),
                esc_html(get_the_date('d.m.Y H:i', $post_id))
            );
            break;
        case 'cfs_name':
            echo esc_html(get_post_meta($post_id, '_cfs_lead_name', true));
            break;
        case 'cfs_email':
            $email = get_post_meta($post_id, '_cfs_lead_email', true);
            if ($email) {
                printf('<a href="mailto:%1$s">%1$s</a>', esc_attr($email));
            }
            break;
        case 'cfs_phone':
            echo esc_html(get_post_meta($post_id, '_cfs_lead_phone', true));
            break;
        case 'cfs_service':
            echo esc_html(get_post_meta($post_id, '_cfs_lead_service', true));
            break;
        case 'cfs_status':
            $status   = get_post_meta($post_id, '_cfs_lead_status', true) ?: 'new';
            $statuses = cfs_lead_statuses();
            printf(
                '<span class="cfs-badge cfs-badge--lead-%s">%s</span>',
                esc_attr($status),
                esc_html($statuses[$status] ?? $status)
            );
            break;
    }
}, 10, 2);

add_action('add_meta_boxes', function () {
    add_meta_box('cfs_lead_data', __('Richiesta', 'capoferrisagl'), 'cfs_render_lead_metabox', 'cfs_lead', 'normal', 'high');
});

function cfs_render_lead_metabox($post)
{
    wp_nonce_field('cfs_save_lead_' . $post->ID, 'cfs_lead_nonce');
    $get = function ($key) use ($post) {
        return get_post_meta($post->ID, '_cfs_lead_' . $key, true);
    };
    $status = $get('status') ?: 'new';
    ?>
    <div class="cfs-admin cfs-admin--metabox">
        <dl class="cfs-lead">
            <dt><?php esc_html_e('Ricevuta il', 'capoferrisagl'); ?></dt>
            <dd><?php echo esc_html(get_the_date('d.m.Y', $post) . ' ' . get_the_time('H:i', $post)); ?></dd>

            <dt><?php esc_html_e('Nome e cognome', 'capoferrisagl'); ?></dt>
            <dd><?php echo esc_html($get('name')); ?></dd>

            <dt><?php esc_html_e('Email', 'capoferrisagl'); ?></dt>
            <dd><a href="mailto:<?php echo esc_attr($get('email')); ?>"><?php echo esc_html($get('email')); ?></a></dd>

            <dt><?php esc_html_e('Telefono', 'capoferrisagl'); ?></dt>
            <dd><?php echo $get('phone') ? esc_html($get('phone')) : '<em>' . esc_html__('non indicato', 'capoferrisagl') . '</em>'; ?></dd>

            <dt><?php esc_html_e('Servizio di interesse', 'capoferrisagl'); ?></dt>
            <dd><?php echo $get('service') ? esc_html($get('service')) : '<em>' . esc_html__('non indicato', 'capoferrisagl') . '</em>'; ?></dd>

            <dt><?php esc_html_e('Messaggio', 'capoferrisagl'); ?></dt>
            <dd class="cfs-lead__message"><?php echo nl2br(esc_html($get('message'))); ?></dd>

            <dt><?php esc_html_e('Consenso privacy', 'capoferrisagl'); ?></dt>
            <dd><?php echo $get('privacy') ? esc_html__('Accettato', 'capoferrisagl') : esc_html__('Non registrato', 'capoferrisagl'); ?></dd>
        </dl>

        <div class="cfs-field">
            <label class="cfs-field__label" for="cfs-lead-status"><?php esc_html_e('Stato', 'capoferrisagl'); ?></label>
            <select id="cfs-lead-status" name="cfs_lead_status" class="cfs-input cfs-select">
                <?php foreach (cfs_lead_statuses() as $key => $label) : ?>
                    <option value="<?php echo esc_attr($key); ?>" <?php selected($status, $key); ?>><?php echo esc_html($label); ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="cfs-field">
            <label class="cfs-field__label" for="cfs-lead-note"><?php esc_html_e('Nota interna', 'capoferrisagl'); ?></label>
            <textarea id="cfs-lead-note" name="cfs_lead_note" rows="4" class="cfs-input cfs-textarea"><?php echo esc_textarea($get('note')); ?></textarea>
            <p class="cfs-field__desc"><?php esc_html_e('Visibile solo nel backend.', 'capoferrisagl'); ?></p>
        </div>
    </div>
    <?php
}

add_action('save_post_cfs_lead', function ($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (!isset($_POST['cfs_lead_nonce']) || !wp_verify_nonce(sanitize_key(wp_unslash($_POST['cfs_lead_nonce'])), 'cfs_save_lead_' . $post_id)) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    if (isset($_POST['cfs_lead_status'])) {
        $status   = sanitize_key(wp_unslash($_POST['cfs_lead_status']));
        $statuses = cfs_lead_statuses();
        update_post_meta($post_id, '_cfs_lead_status', isset($statuses[$status]) ? $status : 'new');
    }
    if (isset($_POST['cfs_lead_note'])) {
        update_post_meta($post_id, '_cfs_lead_note', sanitize_textarea_field(wp_unslash($_POST['cfs_lead_note'])));
    }
});

/** Segna come "letta" all'apertura della richiesta. */
add_action('load-post.php', function () {
    $post_id = isset($_GET['post']) ? absint($_GET['post']) : 0;
    if ($post_id && get_post_type($post_id) === 'cfs_lead') {
        $status = get_post_meta($post_id, '_cfs_lead_status', true);
        if (!$status || $status === 'new') {
            update_post_meta($post_id, '_cfs_lead_status', 'read');
        }
    }
});

/** Badge con il numero di richieste nuove nel menu. */
add_filter('add_menu_classes', 'cfs_lead_menu_badge');
function cfs_lead_menu_badge($menu)
{
    $new = get_posts(array(
        'post_type'      => 'cfs_lead',
        'post_status'    => 'any',
        'posts_per_page' => 50,
        'fields'         => 'ids',
        'meta_query'     => array(
            'relation' => 'OR',
            array('key' => '_cfs_lead_status', 'value' => 'new'),
            array('key' => '_cfs_lead_status', 'compare' => 'NOT EXISTS'),
        ),
    ));
    if (!$new) {
        return $menu;
    }
    foreach ($menu as $key => $item) {
        if (isset($item[2]) && $item[2] === 'capoferri') {
            $menu[$key][0] .= ' <span class="update-plugins count-' . count($new) . '"><span class="plugin-count">' . count($new) . '</span></span>';
        }
    }
    return $menu;
}

/* ─────────────────────────────────────────────
   INVIO DEL MODULO
   ───────────────────────────────────────────── */

add_action('wp_ajax_cfs_contact', 'cfs_handle_contact');
add_action('wp_ajax_nopriv_cfs_contact', 'cfs_handle_contact');
function cfs_handle_contact()
{
    $form = cfs_contact('form', array());

    $fail = function ($message, $field = '') {
        wp_send_json_error(array('message' => $message, 'field' => $field), 200);
    };

    // Nonce (CSRF).
    if (!isset($_POST['cfs_nonce']) || !wp_verify_nonce(sanitize_key(wp_unslash($_POST['cfs_nonce'])), 'cfs_contact')) {
        $fail(__('La sessione è scaduta. Ricarica la pagina e riprova.', 'capoferrisagl'));
    }

    // Honeypot: campo che deve restare vuoto.
    if (!empty($_POST['cfs_website'])) {
        wp_send_json_success(array('message' => $form['success'] ?? __('Grazie, abbiamo ricevuto la tua richiesta.', 'capoferrisagl')));
    }

    // Tempo minimo di compilazione (antispam).
    $started = isset($_POST['cfs_started']) ? absint($_POST['cfs_started']) : 0;
    if ($started && (time() - $started) < 3) {
        $fail(__('Invio troppo rapido: riprova tra qualche istante.', 'capoferrisagl'));
    }

    $name    = isset($_POST['name']) ? sanitize_text_field(wp_unslash($_POST['name'])) : '';
    $email   = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
    $phone   = isset($_POST['phone']) ? sanitize_text_field(wp_unslash($_POST['phone'])) : '';
    $service = isset($_POST['service']) ? sanitize_text_field(wp_unslash($_POST['service'])) : '';
    $message = isset($_POST['message']) ? sanitize_textarea_field(wp_unslash($_POST['message'])) : '';
    $privacy = !empty($_POST['privacy']);

    if ($name === '' || mb_strlen($name) < 2) {
        $fail(__('Inserisci il tuo nome e cognome.', 'capoferrisagl'), 'name');
    }
    if (!is_email($email)) {
        $fail(__('Inserisci un indirizzo email valido.', 'capoferrisagl'), 'email');
    }
    if ($message === '' || mb_strlen($message) < 10) {
        $fail(__('Scrivi un messaggio di almeno 10 caratteri.', 'capoferrisagl'), 'message');
    }
    if (!$privacy) {
        $fail(__('Per inviare la richiesta devi accettare l\'informativa sulla privacy.', 'capoferrisagl'), 'privacy');
    }

    // Salvataggio nel backend.
    $lead_id = wp_insert_post(array(
        'post_type'   => 'cfs_lead',
        'post_status' => 'publish',
        'post_title'  => sprintf('%s — %s', $name, wp_date('d.m.Y H:i')),
    ));

    if (!is_wp_error($lead_id)) {
        update_post_meta($lead_id, '_cfs_lead_name', $name);
        update_post_meta($lead_id, '_cfs_lead_email', $email);
        update_post_meta($lead_id, '_cfs_lead_phone', $phone);
        update_post_meta($lead_id, '_cfs_lead_service', $service);
        update_post_meta($lead_id, '_cfs_lead_message', $message);
        update_post_meta($lead_id, '_cfs_lead_privacy', '1');
        update_post_meta($lead_id, '_cfs_lead_status', 'new');
        update_post_meta($lead_id, '_cfs_lead_ip', isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '');
    }

    // Invio email (usa SMTP/SendGrid già configurati nel CMS del parent).
    $company = cfs_company();
    $mail    = cfs_contact('mail', array());
    $to      = !empty($mail['to']) ? $mail['to'] : $company['email'];
    $subject = !empty($mail['subject']) ? $mail['subject'] : sprintf(__('Nuova richiesta dal sito — %s', 'capoferrisagl'), $company['name']);

    $body_lines = array(
        __('Nuova richiesta ricevuta dal sito.', 'capoferrisagl'),
        '',
        __('Nome:', 'capoferrisagl') . ' ' . $name,
        __('Email:', 'capoferrisagl') . ' ' . $email,
        __('Telefono:', 'capoferrisagl') . ' ' . ($phone !== '' ? $phone : '—'),
        __('Servizio:', 'capoferrisagl') . ' ' . ($service !== '' ? $service : '—'),
        '',
        __('Messaggio:', 'capoferrisagl'),
        $message,
    );

    $headers = array('Content-Type: text/plain; charset=UTF-8', 'Reply-To: ' . $name . ' <' . $email . '>');
    if (!empty($mail['cc'])) {
        foreach (array_filter(array_map('trim', explode(',', $mail['cc']))) as $cc) {
            if (is_email($cc)) {
                $headers[] = 'Cc: ' . $cc;
            }
        }
    }

    $sent = $to ? wp_mail($to, $subject, implode("\n", $body_lines), $headers) : false;

    if (!$sent && is_wp_error($lead_id)) {
        $fail($form['error'] ?? __('Non è stato possibile inviare la richiesta. Riprova o chiamaci.', 'capoferrisagl'));
    }

    wp_send_json_success(array(
        'message' => $form['success'] ?? __('Grazie, abbiamo ricevuto la tua richiesta. Ti ricontattiamo al più presto.', 'capoferrisagl'),
    ));
}
