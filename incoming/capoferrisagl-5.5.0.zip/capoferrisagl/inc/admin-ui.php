<?php
/**
 * Framework campi per il backend del child theme.
 *
 * Fornisce: render dei campi da schema, tab, repeater ordinabili,
 * selezione immagini/gallerie dalla libreria media, salvataggio e
 * sanitizzazione. Usato sia dalle pagine option sia dal CPT Servizi.
 *
 * @package Capoferrisagl
 */

if (!defined('ABSPATH')) {
    exit;
}

/* ─────────────────────────────────────────────
   ASSET ADMIN
   ───────────────────────────────────────────── */

add_action('admin_enqueue_scripts', 'cfs_admin_assets');
function cfs_admin_assets($hook)
{
    $screen = get_current_screen();
    $page   = isset($_GET['page']) ? sanitize_text_field(wp_unslash($_GET['page'])) : '';
    // La Home riusa lo slug del menu ("capoferri"); le altre pagine usano "cfs-*".
    $is_cfs_page   = $page !== '' && (strpos($page, 'cfs-') === 0 || $page === 'capoferri');
    $is_cfs_screen = $screen && in_array($screen->post_type, array('cfs_servizio', 'cfs_lead'), true);

    if (!$is_cfs_page && !$is_cfs_screen) {
        return;
    }

    $ver = wp_get_theme()->get('Version');

    wp_enqueue_media();
    wp_enqueue_script('jquery-ui-sortable');

    wp_enqueue_style(
        'cfs-admin',
        get_stylesheet_directory_uri() . '/assets/css/admin.css',
        array(),
        $ver
    );

    wp_enqueue_script(
        'cfs-admin',
        get_stylesheet_directory_uri() . '/assets/js/admin/fields.js',
        array('jquery', 'jquery-ui-sortable'),
        $ver,
        true
    );

    wp_localize_script('cfs-admin', 'cfsAdmin', array(
        'chooseImage'   => __('Seleziona immagine', 'capoferrisagl'),
        'chooseImages'  => __('Aggiungi immagini alla galleria', 'capoferrisagl'),
        'useImage'      => __('Usa questa immagine', 'capoferrisagl'),
        'useImages'     => __('Aggiungi alla galleria', 'capoferrisagl'),
        'confirmRemove' => __('Vuoi davvero rimuovere questo elemento? L\'operazione non è annullabile dopo il salvataggio.', 'capoferrisagl'),
        'unsaved'       => __('Ci sono modifiche non salvate. Vuoi davvero uscire da questa pagina?', 'capoferrisagl'),
    ));
}

/* ─────────────────────────────────────────────
   RENDER CAMPI
   ───────────────────────────────────────────── */

/**
 * Render di un singolo campo.
 *
 * @param array  $field  Definizione campo.
 * @param mixed  $value  Valore corrente.
 * @param string $name   Nome HTML completo (es. cfs_home[hero][title]).
 */
function cfs_render_field($field, $value, $name)
{
    $type   = $field['type'] ?? 'text';
    $id     = 'cfs-' . preg_replace('/[^a-z0-9]+/i', '-', $name);
    $label  = $field['label'] ?? '';
    $desc   = $field['desc'] ?? '';
    $req    = !empty($field['required']);
    $wide   = !empty($field['wide']) ? ' cfs-field--wide' : '';

    if ($type === 'note') {
        echo '<div class="cfs-note">' . wp_kses_post($field['text'] ?? '') . '</div>';
        return;
    }

    $conditional = '';
    if (!empty($field['show_if']) && is_array($field['show_if'])) {
        $conditional = ' data-show-if="' . esc_attr(wp_json_encode($field['show_if'])) . '"';
    }

    echo '<div class="cfs-field cfs-field--' . esc_attr($type) . $wide . '"' . $conditional . '>'; // phpcs:ignore WordPress.Security.EscapeOutput

    if ($label !== '') {
        echo '<label class="cfs-field__label" for="' . esc_attr($id) . '">' . esc_html($label);
        if ($req) {
            echo ' <span class="cfs-req" aria-hidden="true">*</span><span class="screen-reader-text">' . esc_html__('(campo obbligatorio)', 'capoferrisagl') . '</span>';
        }
        echo '</label>';
    }

    switch ($type) {

        case 'textarea':
            $rows    = (int) ($field['rows'] ?? 5);
            $counter = isset($field['counter']) ? (int) $field['counter'] : 0;
            printf(
                '<textarea id="%s" name="%s" rows="%d" class="cfs-input cfs-textarea"%s placeholder="%s">%s</textarea>',
                esc_attr($id),
                esc_attr($name),
                $rows,
                $counter ? ' data-cfs-counter="' . $counter . '"' : '',
                esc_attr($field['placeholder'] ?? ''),
                esc_textarea((string) $value)
            );
            if ($counter) {
                echo '<p class="cfs-counter" data-for="' . esc_attr($id) . '"></p>';
            }
            break;

        case 'wysiwyg':
            wp_editor((string) $value, $id, array(
                'textarea_name' => $name,
                'textarea_rows' => (int) ($field['rows'] ?? 8),
                'media_buttons' => false,
                'teeny'         => true,
                'quicktags'     => true,
            ));
            break;

        case 'select':
            printf('<select id="%s" name="%s" class="cfs-input cfs-select">', esc_attr($id), esc_attr($name));
            foreach (($field['options'] ?? array()) as $key => $text) {
                printf(
                    '<option value="%s"%s>%s</option>',
                    esc_attr($key),
                    selected((string) $value, (string) $key, false),
                    esc_html($text)
                );
            }
            echo '</select>';
            break;

        case 'checkbox':
            printf(
                '<label class="cfs-toggle"><input type="hidden" name="%1$s" value="0"><input type="checkbox" id="%2$s" name="%1$s" value="1"%3$s><span class="cfs-toggle__track"></span><span class="cfs-toggle__text">%4$s</span></label>',
                esc_attr($name),
                esc_attr($id),
                checked((string) $value, '1', false),
                esc_html($field['checkbox_label'] ?? __('Attiva', 'capoferrisagl'))
            );
            break;

        case 'image':
            cfs_render_image_field($id, $name, (int) $value, $field);
            break;

        case 'video':
            cfs_render_video_field($id, $name, (string) $value, $field);
            break;

        case 'gallery':
            cfs_render_gallery_field($id, $name, (string) $value, $field);
            break;

        case 'focal':
            cfs_render_focal_field($id, $name, (string) $value);
            break;

        case 'service_picker':
            cfs_render_service_picker($id, $name, $value);
            break;

        case 'number':
            printf(
                '<input type="number" id="%s" name="%s" value="%s" class="cfs-input cfs-input--small" step="%s">',
                esc_attr($id),
                esc_attr($name),
                esc_attr((string) $value),
                esc_attr($field['step'] ?? '1')
            );
            break;

        case 'color':
            printf(
                '<input type="text" id="%s" name="%s" value="%s" class="cfs-input cfs-input--small" placeholder="#0B1F3A">',
                esc_attr($id),
                esc_attr($name),
                esc_attr((string) $value)
            );
            break;

        default: // text, url, email, tel
            $counter = isset($field['counter']) ? (int) $field['counter'] : 0;
            printf(
                '<input type="%s" id="%s" name="%s" value="%s" class="cfs-input" placeholder="%s"%s>',
                esc_attr(in_array($type, array('url', 'email', 'tel'), true) ? $type : 'text'),
                esc_attr($id),
                esc_attr($name),
                esc_attr((string) $value),
                esc_attr($field['placeholder'] ?? ''),
                $counter ? ' data-cfs-counter="' . $counter . '"' : ''
            );
            if ($counter) {
                echo '<p class="cfs-counter" data-for="' . esc_attr($id) . '"></p>';
            }
            break;
    }

    if ($desc !== '') {
        echo '<p class="cfs-field__desc">' . wp_kses_post($desc) . '</p>';
    }

    echo '</div>';
}

/**
 * Campo immagine singola con anteprima.
 */
function cfs_render_video_field($id, $name, $value, $field = array())
{
    $value = (string) $value;
    ?>
    <div class="cfs-image" data-cfs-video>
        <div class="cfs-image__preview<?php echo $value ? '' : ' is-empty'; ?>" data-preview>
            <?php if ($value) : ?>
                <video src="<?php echo esc_url($value); ?>" muted playsinline style="max-height:200px;width:auto;"></video>
            <?php else : ?>
                <span class="cfs-image__empty"><?php esc_html_e('Nessun video selezionato', 'capoferrisagl'); ?></span>
            <?php endif; ?>
        </div>
        <input type="url" id="<?php echo esc_attr($id); ?>" name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr($value); ?>" class="cfs-input" placeholder="https://… .mp4" data-input>
        <div class="cfs-image__actions">
            <button type="button" class="button button-secondary" data-select><?php esc_html_e('Seleziona dalla Libreria', 'capoferrisagl'); ?></button>
            <button type="button" class="button-link cfs-danger" data-remove<?php echo $value ? '' : ' hidden'; ?>><?php esc_html_e('Rimuovi', 'capoferrisagl'); ?></button>
        </div>
        <p class="cfs-field__desc"><?php esc_html_e('Carica o scegli un file MP4 dalla Libreria media, oppure incolla l\'URL.', 'capoferrisagl'); ?></p>
    </div>
    <?php
}

function cfs_render_image_field($id, $name, $value, $field = array())
{
    $image = cfs_image($value, 'medium');
    ?>
    <div class="cfs-image" data-cfs-image>
        <div class="cfs-image__preview<?php echo $image ? '' : ' is-empty'; ?>" data-preview>
            <?php if ($image) : ?>
                <img src="<?php echo esc_url($image['url']); ?>" alt="">
            <?php else : ?>
                <span class="cfs-image__empty"><?php esc_html_e('Nessuna immagine selezionata', 'capoferrisagl'); ?></span>
            <?php endif; ?>
        </div>
        <input type="hidden" id="<?php echo esc_attr($id); ?>" name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr((string) $value); ?>" data-input>
        <div class="cfs-image__actions">
            <button type="button" class="button button-secondary" data-select>
                <?php echo $image ? esc_html__('Sostituisci immagine', 'capoferrisagl') : esc_html__('Seleziona immagine', 'capoferrisagl'); ?>
            </button>
            <button type="button" class="button-link cfs-danger" data-remove<?php echo $image ? '' : ' hidden'; ?>>
                <?php esc_html_e('Rimuovi immagine', 'capoferrisagl'); ?>
            </button>
        </div>
        <?php if ($image && $image['alt'] === '') : ?>
            <p class="cfs-warning"><?php esc_html_e('Questa immagine non ha testo alternativo: aggiungilo dalla Libreria multimediale per l\'accessibilità.', 'capoferrisagl'); ?></p>
        <?php endif; ?>
    </div>
    <?php
}

/**
 * Campo galleria: lista ordinabile di immagini (ID separati da virgola).
 */
function cfs_render_gallery_field($id, $name, $value, $field = array())
{
    $ids = array_filter(array_map('absint', explode(',', $value)));
    ?>
    <div class="cfs-gallery" data-cfs-gallery>
        <input type="hidden" id="<?php echo esc_attr($id); ?>" name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr(implode(',', $ids)); ?>" data-input>
        <ul class="cfs-gallery__list<?php echo $ids ? '' : ' is-empty'; ?>" data-list>
            <?php foreach ($ids as $image_id) :
                $img = cfs_image($image_id, 'thumbnail');
                if (!$img) {
                    continue;
                } ?>
                <li class="cfs-gallery__item" data-id="<?php echo esc_attr($image_id); ?>">
                    <img src="<?php echo esc_url($img['url']); ?>" alt="">
                    <button type="button" class="cfs-gallery__remove" data-remove aria-label="<?php esc_attr_e('Rimuovi immagine dalla galleria', 'capoferrisagl'); ?>">&times;</button>
                    <?php if ($img['alt'] === '') : ?>
                        <span class="cfs-gallery__flag" title="<?php esc_attr_e('Manca il testo alternativo', 'capoferrisagl'); ?>">alt!</span>
                    <?php endif; ?>
                </li>
            <?php endforeach; ?>
        </ul>
        <p class="cfs-empty-state" data-empty<?php echo $ids ? ' hidden' : ''; ?>>
            <?php esc_html_e('Non hai ancora aggiunto immagini a questa galleria.', 'capoferrisagl'); ?>
        </p>
        <div class="cfs-gallery__actions">
            <button type="button" class="button button-secondary" data-add><?php esc_html_e('Aggiungi immagini', 'capoferrisagl'); ?></button>
        </div>
        <p class="cfs-field__desc"><?php esc_html_e('Trascina le immagini per cambiarne l\'ordine. Titolo, testo alternativo e didascalia si modificano dalla Libreria multimediale.', 'capoferrisagl'); ?></p>
    </div>
    <?php
}

/**
 * Punto focale: due slider 0-100 salvati come "x|y".
 */
function cfs_render_focal_field($id, $name, $value)
{
    $parts = explode('|', $value !== '' ? $value : '50|50');
    $x = isset($parts[0]) ? (float) $parts[0] : 50;
    $y = isset($parts[1]) ? (float) $parts[1] : 50;
    ?>
    <div class="cfs-focal" data-cfs-focal>
        <input type="hidden" id="<?php echo esc_attr($id); ?>" name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr($x . '|' . $y); ?>" data-input>
        <label class="cfs-focal__row">
            <span><?php esc_html_e('Orizzontale', 'capoferrisagl'); ?></span>
            <input type="range" min="0" max="100" value="<?php echo esc_attr($x); ?>" data-axis="x">
            <output><?php echo esc_html($x); ?>%</output>
        </label>
        <label class="cfs-focal__row">
            <span><?php esc_html_e('Verticale', 'capoferrisagl'); ?></span>
            <input type="range" min="0" max="100" value="<?php echo esc_attr($y); ?>" data-axis="y">
            <output><?php echo esc_html($y); ?>%</output>
        </label>
    </div>
    <?php
}

/**
 * Selezione multipla e ordinabile di servizi.
 */
function cfs_render_service_picker($id, $name, $value)
{
    $selected = is_array($value) ? array_map('absint', $value) : array_filter(array_map('absint', explode(',', (string) $value)));
    $services = get_posts(array(
        'post_type'      => 'cfs_servizio',
        'post_status'    => array('publish', 'draft'),
        'posts_per_page' => -1,
        'orderby'        => 'menu_order title',
        'order'          => 'ASC',
    ));

    if (!$services) {
        echo '<p class="cfs-empty-state">' . esc_html__('Non hai ancora creato nessun servizio.', 'capoferrisagl') . '</p>';
        return;
    }

    // Prima i selezionati, nell'ordine scelto.
    $ordered = array();
    foreach ($selected as $sid) {
        foreach ($services as $service) {
            if ($service->ID === $sid) {
                $ordered[] = $service;
            }
        }
    }
    foreach ($services as $service) {
        if (!in_array($service->ID, $selected, true)) {
            $ordered[] = $service;
        }
    }
    ?>
    <ul class="cfs-picker" data-cfs-sortable-list>
        <?php foreach ($ordered as $service) :
            $is_on = in_array($service->ID, $selected, true); ?>
            <li class="cfs-picker__item">
                <span class="cfs-drag" aria-hidden="true">⋮⋮</span>
                <label>
                    <input type="checkbox" name="<?php echo esc_attr($name); ?>[]" value="<?php echo esc_attr($service->ID); ?>" <?php checked($is_on); ?>>
                    <?php echo esc_html($service->post_title); ?>
                    <?php if ($service->post_status !== 'publish') : ?>
                        <em class="cfs-badge cfs-badge--draft"><?php esc_html_e('bozza', 'capoferrisagl'); ?></em>
                    <?php endif; ?>
                </label>
            </li>
        <?php endforeach; ?>
    </ul>
    <p class="cfs-field__desc"><?php esc_html_e('Spunta i servizi da mostrare e trascinali per definirne l\'ordine.', 'capoferrisagl'); ?></p>
    <?php
}

/* ─────────────────────────────────────────────
   REPEATER
   ───────────────────────────────────────────── */

/**
 * Repeater ordinabile con duplica / elimina / attiva.
 *
 * @param array  $field  Definizione (fields, add_label, row_title, empty).
 * @param array  $rows   Righe salvate.
 * @param string $name   Nome base (es. cfs_home[method][steps]).
 */
function cfs_render_repeater($field, $rows, $name)
{
    $sub_fields = $field['fields'] ?? array();
    $rows       = is_array($rows) ? array_values($rows) : array();
    ?>
    <div class="cfs-repeater" data-cfs-repeater data-name="<?php echo esc_attr($name); ?>">
        <?php if (!empty($field['label'])) : ?>
            <h4 class="cfs-repeater__title"><?php echo esc_html($field['label']); ?></h4>
        <?php endif; ?>
        <?php if (!empty($field['desc'])) : ?>
            <p class="cfs-field__desc"><?php echo wp_kses_post($field['desc']); ?></p>
        <?php endif; ?>

        <div class="cfs-repeater__rows" data-rows>
            <?php foreach ($rows as $index => $row) {
                cfs_render_repeater_row($sub_fields, $row, $name, $index, $field);
            } ?>
        </div>

        <p class="cfs-empty-state" data-empty<?php echo $rows ? ' hidden' : ''; ?>>
            <?php echo esc_html($field['empty'] ?? __('Nessun elemento presente. Usa il pulsante qui sotto per aggiungerne uno.', 'capoferrisagl')); ?>
        </p>

        <script type="text/html" data-template>
            <?php cfs_render_repeater_row($sub_fields, array(), $name, '__INDEX__', $field); ?>
        </script>

        <p class="cfs-repeater__actions">
            <button type="button" class="button button-secondary" data-add>
                <?php echo esc_html($field['add_label'] ?? __('Aggiungi elemento', 'capoferrisagl')); ?>
            </button>
        </p>
    </div>
    <?php
}

/**
 * Una riga di repeater.
 */
function cfs_render_repeater_row($sub_fields, $row, $name, $index, $parent = array())
{
    $row_name = $name . '[' . $index . ']';
    $title_key = $parent['row_title'] ?? '';
    $title     = $title_key && !empty($row[$title_key]) ? $row[$title_key] : ($parent['row_label'] ?? __('Elemento', 'capoferrisagl'));
    $enabled   = !isset($row['enabled']) || $row['enabled'] === '1';
    ?>
    <div class="cfs-row<?php echo $enabled ? '' : ' is-disabled'; ?>" data-row>
        <div class="cfs-row__head">
            <span class="cfs-drag" data-handle aria-hidden="true">⋮⋮</span>
            <button type="button" class="cfs-row__toggle" data-toggle aria-expanded="false">
                <span class="cfs-row__title" data-row-title data-title-key="<?php echo esc_attr($title_key); ?>"><?php echo esc_html($title); ?></span>
            </button>
            <span class="cfs-row__tools">
                <label class="cfs-mini-toggle" title="<?php esc_attr_e('Mostra o nascondi nel sito', 'capoferrisagl'); ?>">
                    <input type="hidden" name="<?php echo esc_attr($row_name); ?>[enabled]" value="0">
                    <input type="checkbox" name="<?php echo esc_attr($row_name); ?>[enabled]" value="1" <?php checked($enabled); ?> data-enabled>
                    <span><?php esc_html_e('Attivo', 'capoferrisagl'); ?></span>
                </label>
                <button type="button" class="button-link" data-duplicate><?php esc_html_e('Duplica', 'capoferrisagl'); ?></button>
                <button type="button" class="button-link cfs-danger" data-delete><?php esc_html_e('Elimina', 'capoferrisagl'); ?></button>
            </span>
        </div>
        <div class="cfs-row__body" hidden>
            <?php foreach ($sub_fields as $key => $sub) {
                $value = $row[$key] ?? ($sub['default'] ?? '');
                if (($sub['type'] ?? '') === 'repeater') {
                    cfs_render_repeater($sub, is_array($value) ? $value : array(), $row_name . '[' . $key . ']');
                } else {
                    cfs_render_field($sub, $value, $row_name . '[' . $key . ']');
                }
            } ?>
        </div>
    </div>
    <?php
}

/* ─────────────────────────────────────────────
   SEZIONI E TAB
   ───────────────────────────────────────────── */

/**
 * Render di una lista di campi (con supporto repeater annidati).
 */
function cfs_render_fields($fields, $values, $base_name)
{
    foreach ($fields as $key => $field) {
        $value = $values[$key] ?? ($field['default'] ?? '');
        $name  = $base_name . '[' . $key . ']';

        if (($field['type'] ?? '') === 'repeater') {
            cfs_render_repeater($field, is_array($value) ? $value : array(), $name);
            continue;
        }
        if (($field['type'] ?? '') === 'group') {
            echo '<div class="cfs-group"><h4 class="cfs-group__title">' . esc_html($field['label'] ?? '') . '</h4>';
            if (!empty($field['desc'])) {
                echo '<p class="cfs-field__desc">' . wp_kses_post($field['desc']) . '</p>';
            }
            cfs_render_fields($field['fields'] ?? array(), is_array($value) ? $value : array(), $name);
            echo '</div>';
            continue;
        }
        cfs_render_field($field, $value, $name);
    }
}

/**
 * Pagina option con tab. Salva su un'unica option array.
 */
function cfs_render_options_page($option_key, $page_title, $intro, $tabs)
{
    if (!current_user_can('edit_pages')) {
        wp_die(esc_html__('Non hai i permessi per modificare questa pagina.', 'capoferrisagl'));
    }

    $values  = cfs_group($option_key);
    $saved   = isset($_GET['cfs_saved']);
    $tab_ids = array_keys($tabs);
    $current = isset($_GET['tab']) && in_array($_GET['tab'], $tab_ids, true)
        ? sanitize_key(wp_unslash($_GET['tab']))
        : $tab_ids[0];
    ?>
    <div class="wrap cfs-admin">
        <h1 class="cfs-admin__title"><?php echo esc_html($page_title); ?></h1>
        <?php if ($intro) : ?>
            <p class="cfs-admin__intro"><?php echo wp_kses_post($intro); ?></p>
        <?php endif; ?>

        <?php if ($saved) : ?>
            <div class="notice notice-success is-dismissible"><p><?php esc_html_e('Modifiche salvate.', 'capoferrisagl'); ?></p></div>
        <?php endif; ?>

        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" data-cfs-form>
            <input type="hidden" name="action" value="cfs_save_options">
            <input type="hidden" name="cfs_option_key" value="<?php echo esc_attr($option_key); ?>">
            <input type="hidden" name="cfs_current_tab" value="<?php echo esc_attr($current); ?>">
            <?php wp_nonce_field('cfs_save_' . $option_key, 'cfs_nonce'); ?>

            <nav class="cfs-tabs" data-cfs-tabs>
                <?php foreach ($tabs as $tab_id => $tab) : ?>
                    <button type="button" class="cfs-tabs__btn<?php echo $tab_id === $current ? ' is-active' : ''; ?>"
                            data-tab="<?php echo esc_attr($tab_id); ?>"
                            aria-selected="<?php echo $tab_id === $current ? 'true' : 'false'; ?>">
                        <?php echo esc_html($tab['label']); ?>
                    </button>
                <?php endforeach; ?>
            </nav>

            <?php foreach ($tabs as $tab_id => $tab) : ?>
                <section class="cfs-panel<?php echo $tab_id === $current ? ' is-active' : ''; ?>" data-panel="<?php echo esc_attr($tab_id); ?>">
                    <?php if (!empty($tab['desc'])) : ?>
                        <p class="cfs-panel__desc"><?php echo wp_kses_post($tab['desc']); ?></p>
                    <?php endif; ?>
                    <?php cfs_render_fields($tab['fields'] ?? array(), $values, $option_key); ?>
                </section>
            <?php endforeach; ?>

            <div class="cfs-actions">
                <button type="submit" class="button button-primary button-hero"><?php esc_html_e('Salva modifiche', 'capoferrisagl'); ?></button>
                <span class="cfs-actions__hint" data-dirty hidden><?php esc_html_e('Modifiche non salvate', 'capoferrisagl'); ?></span>
            </div>
        </form>
    </div>
    <?php
}

/* ─────────────────────────────────────────────
   SALVATAGGIO
   ───────────────────────────────────────────── */

add_action('admin_post_cfs_save_options', 'cfs_handle_save_options');
function cfs_handle_save_options()
{
    if (!current_user_can('edit_pages')) {
        wp_die(esc_html__('Permessi insufficienti.', 'capoferrisagl'));
    }

    $option_key = isset($_POST['cfs_option_key']) ? sanitize_key(wp_unslash($_POST['cfs_option_key'])) : '';
    if (!in_array($option_key, cfs_option_keys(), true)) {
        wp_die(esc_html__('Richiesta non valida.', 'capoferrisagl'));
    }

    check_admin_referer('cfs_save_' . $option_key, 'cfs_nonce');

    $raw   = isset($_POST[$option_key]) ? wp_unslash($_POST[$option_key]) : array();
    $clean = cfs_sanitize_recursive($raw);

    update_option($option_key, $clean);

    $tab      = isset($_POST['cfs_current_tab']) ? sanitize_key(wp_unslash($_POST['cfs_current_tab'])) : '';
    $referer  = wp_get_referer();
    $redirect = $referer ? remove_query_arg(array('cfs_saved'), $referer) : admin_url('admin.php?page=' . str_replace('_', '-', $option_key));
    $redirect = add_query_arg(array('cfs_saved' => '1', 'tab' => $tab), $redirect);

    wp_safe_redirect($redirect);
    exit;
}

/**
 * Sanitizzazione ricorsiva conservativa: HTML limitato sui testi lunghi,
 * testo semplice su tutto il resto.
 */
function cfs_sanitize_recursive($value)
{
    if (is_array($value)) {
        $out = array();
        foreach ($value as $key => $item) {
            $out[is_int($key) ? $key : sanitize_key($key)] = cfs_sanitize_recursive($item);
        }
        return $out;
    }

    $value = (string) $value;

    if (strpos($value, '<') !== false) {
        return wp_kses_post($value);
    }
    if (strpos($value, "\n") !== false) {
        return sanitize_textarea_field($value);
    }
    if (preg_match('#^https?://#i', $value)) {
        return esc_url_raw($value);
    }
    if (is_email($value)) {
        return sanitize_email($value);
    }
    return sanitize_text_field($value);
}
