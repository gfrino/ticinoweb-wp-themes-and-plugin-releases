<?php
/**
 * Product editorial presentation; commerce remains entirely WooCommerce native.
 *
 * THESIS: A bottle to discover, with the purchase immediately beside it.
 * OWN-WORLD: Existing ivory paper, burgundy ink, Cormorant and Manrope; open
 * compositions, measured rules, an unboxed bottle and a dark tasting passage.
 * STORY: Identify the bottle, buy, then explore its story, character and origin.
 * FIRST VIEWPORT: Purchase left, native gallery and story centre, detail right.
 * FORM: Approved editorial product composition extending the site's identity.
 */
defined( 'ABSPATH' ) || exit;

/** Install presentation hooks only after the main product query is available. */
function adb_product_page_setup() {
    if ( ! function_exists( 'is_product' ) || ! is_product() ) { return; }
    add_filter( 'body_class', 'adb_product_page_body_class' );
    add_action( 'woocommerce_before_single_product_summary', 'adb_product_stage_open', 1 );
    add_action( 'woocommerce_before_single_product_summary', 'adb_product_center_open', 15 );
    remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash', 10 );
    add_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash', 18 );
    add_action( 'woocommerce_before_single_product_summary', 'adb_product_center_close', 25 );
    add_action( 'woocommerce_after_single_product_summary', 'adb_product_center_story', -1 );
    add_action( 'woocommerce_after_single_product_summary', 'adb_product_detail_column', 0 );
    add_action( 'woocommerce_after_single_product_summary', 'adb_product_stage_close', 1 );
    add_action( 'woocommerce_single_product_summary', 'adb_product_identity', 4 );
    remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20 );
    remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
    add_action( 'woocommerce_single_product_summary', 'adb_product_introduction', 15 );
    add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 20 );
    add_action( 'woocommerce_single_product_summary', 'adb_product_quick_facts', 25 );
    add_action( 'woocommerce_single_product_summary', 'adb_product_trust', 35 );
    remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
    add_action( 'woocommerce_after_single_product_summary', 'adb_product_editorial', 5 );
    add_filter( 'woocommerce_product_tabs', 'adb_product_editorial_tabs', 100 );
    add_filter( 'woocommerce_product_single_add_to_cart_text', 'adb_product_cart_label' );
}
add_action( 'wp', 'adb_product_page_setup', 30 );

function adb_product_cart_label( $label ) { return __( 'Aggiungi al carrello', 'amicidibacco' ); }

/** Payment brands are supplied by enabled WooCommerce gateways, never a static promise. */
function adb_product_trust() {
    $shop = wc_get_page_id('shop');
    $logo = adb_valid_image_id(get_post_meta($shop,'_adb_shipping_logo',true));
    $label = get_post_meta($shop,'_adb_shipping_label',true);
    $icons = array();
    foreach (WC()->payment_gateways()->payment_gateways() as $gateway) {
        if ('yes' !== $gateway->enabled) { continue; }
        $icon = $gateway->get_icon();
        if ($icon) { $icons[] = $icon; }
    }
    // The approved brand strip is preview-only; live payment promises follow enabled gateways.
    $preview = in_array(wp_parse_url(home_url(), PHP_URL_HOST), array('localhost','127.0.0.1','::1'), true);
    $preview_logo = $preview && !$icons ? adb_valid_image_id(get_post_meta($shop,'_adb_payment_preview_logo',true)) : 0;
    echo '<aside class="adb-product-trust" aria-label="'.esc_attr__('Acquisto e consegna','amicidibacco').'">';
    echo '<div class="adb-product-trust__payment"><span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" aria-hidden="true"><rect x="5" y="10" width="14" height="11" rx="1"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>'.esc_html__('Pagamento sicuro','amicidibacco').'</span>';
    foreach (array_unique($icons) as $icon) { echo wp_kses_post($icon); }
    echo '</div>';
    if ($preview_logo) { echo wp_get_attachment_image($preview_logo,'medium_large',false,array('class'=>'adb-product-trust__brands','alt'=>__('TWINT, PostFinance, Mastercard, American Express, Visa e Apple Pay','amicidibacco'),'loading'=>'lazy','sizes'=>'340px')); }
    if ($logo && is_scalar($label) && trim((string)$label)) { echo '<div class="adb-product-trust__shipping">'.wp_get_attachment_image($logo,'medium',false,array('alt'=>(string)$label,'loading'=>'lazy','sizes'=>'108px')).'<span>'.esc_html($label).'</span></div>'; }
    echo '</aside>';
}

add_action('add_meta_boxes_page', static function($post) {
    if ((int)$post->ID !== wc_get_page_id('shop')) { return; }
    add_meta_box('adb-shop-trust',__('Acquisto e consegna','amicidibacco'),static function($post){
        wp_nonce_field('adb_shop_trust','adb_shop_trust_nonce');
        echo '<p>'.esc_html__('I loghi di pagamento provengono automaticamente dai metodi attivi in WooCommerce. Il corriere si modifica qui per tutte le schede prodotto.','amicidibacco').'</p>';
        adb_admin_media_field('adb_shipping_logo',absint(get_post_meta($post->ID,'_adb_shipping_logo',true)),__('Logo del corriere','amicidibacco'));
        adb_admin_media_field('adb_payment_preview_logo',absint(get_post_meta($post->ID,'_adb_payment_preview_logo',true)),__('Loghi di pagamento — anteprima locale','amicidibacco'));
        echo '<p><label for="adb-shipping-label">'.esc_html__('Testo della consegna','amicidibacco').'</label><input class="widefat" id="adb-shipping-label" name="adb_shipping_label" value="'.esc_attr(get_post_meta($post->ID,'_adb_shipping_label',true)).'"></p>';
    },'page','normal');
});
add_action('save_post_page',static function($id){
    if ($id!==wc_get_page_id('shop') || wp_is_post_revision($id) || wp_is_post_autosave($id) || !current_user_can('edit_post',$id) || !isset($_POST['adb_shop_trust_nonce']) || !is_string($_POST['adb_shop_trust_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['adb_shop_trust_nonce'])),'adb_shop_trust')) { return; }
    if (isset($_POST['adb_shipping_logo']) && is_scalar($_POST['adb_shipping_logo'])) { update_post_meta($id,'_adb_shipping_logo',adb_valid_image_id(wp_unslash($_POST['adb_shipping_logo']))); }
    if (isset($_POST['adb_payment_preview_logo']) && is_scalar($_POST['adb_payment_preview_logo'])) { update_post_meta($id,'_adb_payment_preview_logo',adb_valid_image_id(wp_unslash($_POST['adb_payment_preview_logo']))); }
    if (isset($_POST['adb_shipping_label']) && is_string($_POST['adb_shipping_label'])) { update_post_meta($id,'_adb_shipping_label',sanitize_text_field(wp_unslash($_POST['adb_shipping_label']))); }
});

function adb_product_page_body_class( $classes ) {
    $classes[] = 'adb-product-page';
    if ( has_term( array( 'le-selezioni', 'le-selezioni-grappa' ), 'product_cat', get_queried_object_id() ) ) { $classes[] = 'adb-product-page--selection'; }
    return $classes;
}
function adb_product_stage_open() { echo '<div class="adb-product-stage">'; }
function adb_product_stage_close() { echo '</div>'; }
function adb_product_center_open() { echo '<div class="adb-product-center">'; }

/** Native gallery, the wine's complete story, and its CMS-linked winery. */
function adb_product_center_close() { echo '</div>'; }

function adb_product_center_story() {
    global $product;
    if ( $product instanceof WC_Product ) {
        $data = adb_product_editorial_data( $product );
        echo '<div class="adb-product-center__story">';
        if ( $data['producer'] ) { adb_product_producer_section( $data['producer'] ); }
        if ( trim( $data['story'] ) ) {
            echo '<section id="adb-product-story" class="adb-product-story" aria-labelledby="adb-product-story-title"><h2 id="adb-product-story-title">'.esc_html__('Il racconto','amicidibacco').'</h2><div class="adb-product-prose">'.wp_kses_post(apply_filters('the_content',$data['story'])).'</div></section>';
        }
        echo '</div>';
    }
}

/** Read existing per-product content, never create or infer a factual value. */
function adb_product_editorial_field( $product_id, $keys ) {
    foreach ( (array) $keys as $key ) {
        $value = function_exists( 'adb_product_field_value' ) ? adb_product_field_value( $product_id, $key ) : get_post_meta( $product_id, $key, true );
        if ( is_scalar( $value ) && '' !== trim( wp_strip_all_tags( (string) $value ) ) ) { return (string) $value; }
    }
    return '';
}

/** A producer is linked by the recorded cantina taxonomy ID, never its name. */
function adb_product_linked_producer( $product ) {
    $ids = wc_get_product_terms( $product->get_id(), 'pa_cantina', array( 'fields' => 'ids' ) );
    if ( ! $ids || is_wp_error( $ids ) ) { return null; }
    $posts = get_posts( array(
        'post_type' => 'produttore', 'post_status' => 'publish', 'posts_per_page' => 1,
        'no_found_rows' => true, 'suppress_filters' => false, 'adb_language' => 'it',
        'orderby' => 'title', 'order' => 'ASC',
        'meta_query' => array( array( 'key' => 'cantina', 'value' => array_map( 'absint', $ids ), 'compare' => 'IN', 'type' => 'NUMERIC' ) ),
    ) );
    return $posts ? $posts[0] : null;
}

/** Collect once; navigation and sections always agree, including sparse products. */
function adb_product_editorial_data( $product ) {
    static $cache = array();
    $cache_key = get_current_blog_id() . ':' . $product->get_id();
    if ( isset( $cache[ $cache_key ] ) ) { return $cache[ $cache_key ]; }
    $id = $product->get_id();
    $field = static function ( $keys ) use ( $id ) { return adb_product_editorial_field( $id, $keys ); };
    $tasting = function_exists( 'adb_tasting_data' ) ? adb_tasting_data( $id ) : array();
    $tasting = is_array( $tasting ) ? $tasting : array();
    $selection = array();
    foreach ( array( '', '_grappa' ) as $suffix ) {
        for ( $number = 1; $number <= ( $suffix ? 2 : 3 ); $number++ ) {
            $value = $field( 'descrizione_' . $number . $suffix );
            if ( $value ) {
                $selection[] = array( 'title' => $field( 'etichetta_descrizione_' . $number . $suffix ), 'value' => $value );
            }
        }
    }
    // A collection has no single sensorial profile; never average its bottles.
    $kind = sanitize_title( $field( 'tipo_di_prodotto' ) );
    $is_selection = $selection || false !== strpos( $kind, 'selezion' ) || has_term( array( 'le-selezioni', 'le-selezioni-grappa' ), 'product_cat', $id );
    if ( $is_selection ) {
        $tasting['scores'] = array();
        $tasting['aromas'] = array();
        $tasting['finish'] = '';
    }
    $narrative = (string) $product->get_description();
    if ( '' === trim( $narrative ) ) { $narrative = (string) $product->get_short_description(); }
    $technical = array();
    $keys = array( 'vitigno', 'vinificazione', 'gradazione_alcolica', 'vitigni_disponibili:', 'provenienza_vinaccia:', 'sistema_di_distillazione:', 'periodo_di_distillazione:', 'tipologia_di_invecchiamento:', 'grado_alcolico:', 'stilebirra', 'ingredientibirra', 'gradazione_alcolicabirre' );
    $labels = adb_product_fields();
    foreach ( $keys as $key ) {
        $value = $field( $key );
        if ( $value ) { $technical[] = array( 'label' => $labels[ $key ], 'value' => $value ); }
    }
    // Preserve native visible attributes when retiring the redundant WooCommerce tab.
    $shown = array('pa_cantina','pa_regione','pa_nazione','pa_anno','pa_dimensione');
    foreach ($product->get_attributes() as $attribute) {
        if (!$attribute->get_visible() || in_array($attribute->get_name(),$shown,true)) { continue; }
        $value = $product->get_attribute($attribute->get_name());
        if ($value) { $technical[] = array('label'=>wc_attribute_label($attribute->get_name(),$product),'value'=>$value); }
    }
    $data = array(
        'story' => $narrative, 'selection' => $selection, 'tasting' => $tasting,
        'color' => $is_selection ? '' : $field( array( 'colore', 'colore:', 'colorebirre' ) ),
        'nose' => $is_selection ? '' : $field( array( 'al_naso', 'profumo:', 'al_nasobirre' ) ),
        'palate' => $is_selection ? '' : $field( array( 'al_palato', 'sapore:', 'al_palatobirre' ) ),
        'serving' => $field( array( 'temperatura_di_servizio', 'temperatura_di_serviziobirre' ) ),
        'pairing' => $field( 'abbinamenti_gastronomici' ),
        'technical' => $technical, 'producer' => adb_product_linked_producer( $product ),
    );
    $data['has_tasting'] = $data['color'] || $data['nose'] || $data['palate'] || ! empty( $tasting['aromas'] ) || ! empty( $tasting['finish'] ) || count( array_filter( $tasting['scores'] ?? array(), static function ( $score ) { return is_numeric( $score ) && $score >= 1 && $score <= 5; } ) );
    $cache[ $cache_key ] = $data;
    return $data;
}

function adb_product_identity() {
    global $product;
    if ( ! $product instanceof WC_Product ) { return; }
    $denomination = adb_product_editorial_field( $product->get_id(), 'etichetta' );
    $grapes = adb_product_editorial_field( $product->get_id(), 'vitigno' );
    $winery = $product->get_attribute( 'pa_cantina' );
    if ( ! $denomination && ! $winery && ! $grapes ) { return; }
    echo '<div class="adb-product-identity">';
    if ( $winery ) { echo '<span>' . esc_html( $winery ) . '</span>'; }
    if ( $grapes ) { echo '<span class="adb-product-identity__grapes">' . esc_html( wp_strip_all_tags( $grapes ) ) . '</span>'; }
    if ( $denomination ) { echo '<span>' . esc_html( $denomination ) . '</span>'; }
    echo '</div>';
}

function adb_product_introduction() {
    global $product;
    if ( ! $product instanceof WC_Product ) { return; }
    $intro = trim( (string) $product->get_short_description() );
    if ( '' === $intro ) { $intro = adb_product_editorial_field( $product->get_id(), 'descrizione_etichetta' ); }
    if ( '' === $intro ) { return; }
    // Legacy imports occasionally store the complete technical sheet as excerpt.
    if ( str_word_count( wp_strip_all_tags( $intro ) ) > 80 || preg_match( '/<(?:table|h[1-6]|dl)\b/i', $intro ) ) {
        $intro = wp_trim_words( wp_strip_all_tags( $intro ), 48 );
    }
    echo '<div class="adb-product-introduction">' . wp_kses_post( wpautop( $intro ) ) . '</div>';
}

function adb_product_quick_facts() {
    global $product;
    if ( ! $product instanceof WC_Product ) { return; }
    $years = array();
    if ( $product->is_type( 'variable' ) ) {
        foreach ( $product->get_variation_attributes()['pa_anno'] ?? array() as $slug ) {
            $term = get_term_by( 'slug', $slug, 'pa_anno' );
            if ( $term ) { $years[] = $term->name; }
        }
    } elseif ( $product->get_attribute( 'pa_anno' ) ) { $years[] = $product->get_attribute( 'pa_anno' ); }
    $years = array_values( array_unique( $years ) );
    $facts = array(
        _n( 'Annata', 'Annate', count( $years ), 'amicidibacco' ) => implode( ', ', $years ),
        __( 'Provenienza', 'amicidibacco' ) => implode( ', ', array_filter( array( $product->get_attribute( 'pa_regione' ), $product->get_attribute( 'pa_nazione' ) ) ) ),
    );
    $facts = array_filter( $facts );
    if ( ! $facts ) { return; }
    echo '<div class="adb-product-facts-row">';
    echo '<dl class="adb-product-quick-facts">';
    foreach ( $facts as $label => $value ) { echo '<div><dt>' . esc_html( $label ) . '</dt><dd>' . esc_html( $value ) . '</dd></div>'; }
    echo '</dl>';
    echo '</div>';
}

/** Details live in the editorial sheet; keep native reviews only. */
function adb_product_editorial_tabs( $tabs ) {
    unset( $tabs['description'], $tabs['adb_technical'], $tabs['additional_information'] );
    return $tabs;
}

/** The third column preserves every recorded technical, tasting and serving field. */
function adb_product_detail_column() {
    global $product;
    if ( ! $product instanceof WC_Product ) { return; }
    $data = adb_product_editorial_data( $product );
    ?>
    <div class="adb-product-detail-column">
        <?php if ( $data['technical'] ) : ?>
        <section id="adb-product-details" class="adb-product-details adb-product-section" aria-labelledby="adb-product-details-title">
            <h2 id="adb-product-details-title"><?php esc_html_e( 'Scheda tecnica', 'amicidibacco' ); ?></h2>
            <dl class="adb-product-specifications"><?php foreach ( $data['technical'] as $row ) : ?><div><dt><?php echo esc_html( $row['label'] ); ?></dt><dd><?php echo wp_kses_post( wpautop( $row['value'] ) ); ?></dd></div><?php endforeach; ?></dl>
        </section>
        <?php endif; ?>
        <?php if ( $data['has_tasting'] ) { adb_product_tasting_section( $data ); } ?>
        <?php if ( $data['serving'] || $data['pairing'] ) : ?>
        <section id="adb-product-serving" class="adb-product-serving adb-product-section" aria-labelledby="adb-product-serving-title">
            <h2 id="adb-product-serving-title"><?php esc_html_e( 'A tavola', 'amicidibacco' ); ?></h2>
            <div class="adb-product-serving__body">
                <?php if ( $data['serving'] ) : ?><div class="adb-product-temperature"><h3><?php esc_html_e( 'Temperatura di servizio', 'amicidibacco' ); ?></h3><div><?php echo wp_kses_post( wpautop( $data['serving'] ) ); ?></div></div><?php endif; ?>
                <?php if ( $data['pairing'] ) : ?><div class="adb-product-pairing"><h3><?php esc_html_e( 'Gli abbinamenti', 'amicidibacco' ); ?></h3><?php echo wp_kses_post( wpautop( $data['pairing'] ) ); ?></div><?php endif; ?>
            </div>
        </section>
        <?php endif; ?>
        <?php if ( $data['selection'] ) : ?>
        <section class="adb-product-selection" aria-labelledby="adb-product-selection-title">
            <h2 id="adb-product-selection-title"><?php esc_html_e( 'Nella selezione', 'amicidibacco' ); ?></h2>
            <?php foreach ( $data['selection'] as $item ) : ?><div><?php if ( $item['title'] ) : ?><h3><?php echo esc_html( $item['title'] ); ?></h3><?php endif; ?><?php echo wp_kses_post( wpautop( $item['value'] ) ); ?></div><?php endforeach; ?>
        </section>
        <?php endif; ?>
    </div>
    <?php
}

function adb_product_editorial() {
    echo '<div class="adb-product-native-meta">';
    woocommerce_template_single_meta();
    echo '</div>';
}

function adb_product_tasting_section( $data ) {
    $tasting = $data['tasting'];
    $aromas = array_filter( (array) ( $tasting['aromas'] ?? array() ), 'is_string' );
    $axes = function_exists( 'adb_tasting_axes' ) ? adb_tasting_axes() : array();
    $scores = array_filter( (array) ( $tasting['scores'] ?? array() ), static function ( $score ) { return is_numeric( $score ) && $score >= 1 && $score <= 5; } );
    ?>
    <section id="adb-product-tasting" class="adb-product-tasting" aria-labelledby="adb-product-tasting-title" data-product-reveal>
        <header class="adb-product-tasting__heading"><h2 id="adb-product-tasting-title"><?php esc_html_e( 'Nel calice', 'amicidibacco' ); ?></h2></header>
        <div class="adb-product-tasting__body">
            <?php if ( $aromas ) : ?><div class="adb-product-aromas"><h3><?php esc_html_e( 'Le note aromatiche', 'amicidibacco' ); ?></h3><ul><?php foreach ( $aromas as $aroma ) : ?><li><?php echo esc_html( $aroma ); ?></li><?php endforeach; ?></ul></div><?php endif; ?>
            <?php if ( $data['color'] || $data['nose'] || $data['palate'] || ! empty( $tasting['finish'] ) ) : ?>
            <dl class="adb-product-senses">
                <?php if ( $data['color'] ) : ?><div><dt><?php esc_html_e( 'Il colore', 'amicidibacco' ); ?></dt><dd><?php echo wp_kses_post( wpautop( $data['color'] ) ); ?></dd></div><?php endif; ?>
                <?php if ( $data['nose'] ) : ?><div><dt><?php esc_html_e( 'Al naso', 'amicidibacco' ); ?></dt><dd><?php echo wp_kses_post( wpautop( $data['nose'] ) ); ?></dd></div><?php endif; ?>
                <?php if ( $data['palate'] ) : ?><div><dt><?php esc_html_e( 'Al palato', 'amicidibacco' ); ?></dt><dd><?php echo wp_kses_post( wpautop( $data['palate'] ) ); ?></dd></div><?php endif; ?>
                <?php if ( ! empty( $tasting['finish'] ) && is_string( $tasting['finish'] ) ) : ?><div><dt><?php esc_html_e( 'Il finale', 'amicidibacco' ); ?></dt><dd><?php echo wp_kses_post( wpautop( $tasting['finish'] ) ); ?></dd></div><?php endif; ?>
            </dl>
            <?php endif; ?>
            <?php if ( $scores && $axes ) : ?>
            <div class="adb-product-profile"><h3><?php esc_html_e( 'Il carattere', 'amicidibacco' ); ?></h3><p class="adb-product-profile__note"><?php if ( 'editorial' === ( $tasting['score_method'] ?? '' ) ) { esc_html_e( 'Profilo stilistico indicativo: stime editoriali da 1 a 5 basate sulle caratteristiche del vino. Descrive lo stile, non è un voto di qualità.', 'amicidibacco' ); } else { esc_html_e( 'Intensità da 1 a 5: descrive lo stile, non la qualità.', 'amicidibacco' ); } ?></p><dl>
                <?php foreach ( $axes as $key => $axis ) : if ( ! isset( $scores[ $key ] ) ) { continue; } $score = (int) $scores[ $key ]; ?>
                <div class="adb-product-axis"><dt><?php echo esc_html( $axis['label'] ); ?></dt><dd><span class="adb-product-axis__value"><?php echo esc_html( sprintf( __( '%d su 5', 'amicidibacco' ), $score ) ); ?></span><span class="adb-product-axis__segments" aria-hidden="true"><?php for ( $segment = 1; $segment <= 5; $segment++ ) : ?><i<?php echo $segment <= $score ? ' class="is-filled"' : ''; ?>></i><?php endfor; ?></span><span class="adb-product-axis__ends" aria-hidden="true"><span><?php echo esc_html( $axis['low'] ); ?></span><span><?php echo esc_html( $axis['high'] ); ?></span></span></dd></div>
                <?php endforeach; ?>
            </dl></div>
            <?php endif; ?>
            <?php adb_product_tasting_sources( $tasting ); ?>
        </div>
    </section>
    <?php
}

function adb_product_tasting_sources( $tasting ) {
    $sources = array_filter( (array) ( $tasting['sources'] ?? array() ), static function ( $source ) { return is_array( $source ) && ! empty( $source['url'] ) && ! empty( $source['title'] ) && esc_url( $source['url'] ); } );
    if ( ! $sources ) { return; }
    ?>
    <details class="adb-product-sources"><summary><?php esc_html_e( 'Fonti e annata di riferimento', 'amicidibacco' ); ?></summary>
        <?php if ( ! empty( $tasting['reference_vintage'] ) && is_scalar( $tasting['reference_vintage'] ) ) : ?><p><?php echo esc_html( sprintf( __( 'Annata di riferimento: %s', 'amicidibacco' ), $tasting['reference_vintage'] ) ); ?></p><?php endif; ?>
        <ul><?php foreach ( $sources as $source ) : ?><li><a href="<?php echo esc_url( $source['url'] ); ?>" rel="external nofollow"><?php echo esc_html( $source['title'] ); ?></a><?php if ( ! empty( $source['vintage'] ) && is_scalar( $source['vintage'] ) ) : ?><span> · <?php echo esc_html( sprintf( __( 'Annata %s', 'amicidibacco' ), $source['vintage'] ) ); ?></span><?php endif; ?></li><?php endforeach; ?></ul>
    </details>
    <?php
}

function adb_product_producer_section( $producer ) {
    $logo = get_post_thumbnail_id( $producer->ID );
    $excerpt = $producer->post_excerpt ?: wp_trim_words( wp_strip_all_tags( strip_shortcodes( $producer->post_content ) ), 30 );
    ?>
    <section id="adb-product-producer" class="adb-product-producer" aria-labelledby="adb-product-producer-title">
        <?php if ( $logo ) : ?><a class="adb-product-winery-logo" href="<?php echo esc_url(get_permalink($producer)); ?>" aria-label="<?php echo esc_attr(get_the_title($producer)); ?>"><?php echo wp_get_attachment_image($logo,'full',false,array('alt'=>get_the_title($producer),'sizes'=>'176px','loading'=>'lazy','decoding'=>'async')); ?></a><?php endif; ?>
        <div class="adb-product-producer__body"><h2 id="adb-product-producer-title"><?php echo esc_html( get_the_title( $producer ) ); ?></h2><?php if ( $excerpt ) : ?><p><?php echo esc_html( wp_strip_all_tags( $excerpt ) ); ?></p><?php endif; ?><a class="adb-link" href="<?php echo esc_url( get_permalink( $producer ) ); ?>"><?php esc_html_e( 'Scopri la cantina', 'amicidibacco' ); ?> <?php echo adb_icon(); ?></a></div>
    </section>
    <?php
}
