<?php
/**
 * Email delle richieste dalla scheda di un immobile: aggiunge una piccola foto e il collegamento alla scheda.
 * Usa il gestore del parent (filtri ticinoweb_form_fields / ticinoweb_form_email_body): destinatari,
 * Reply-To e salvataggio in Invii Ricevuti restano quelli del parent.
 */
if (!defined('ABSPATH')) {
    exit;
}

/** Immobile pubblicato indicato dal modulo, 0 se non c'è o non è valido. */
function idea_immo_inquiry_property($fields)
{
    $id = isset($fields['immobile_id']) ? (int) $fields['immobile_id'] : 0;
    return ($id && get_post_type($id) === 'immobile' && get_post_status($id) === 'publish') ? $id : 0;
}

add_filter('ticinoweb_form_fields', function ($fields, $post) {
    $fields['immobile_id'] = isset($post['immobile_id']) ? absint($post['immobile_id']) : 0;
    return $fields;
}, 10, 2);

add_filter('ticinoweb_form_email_body', function ($body, $fields) {
    $pid = idea_immo_inquiry_property((array) $fields);
    if (!$pid) {
        return $body;
    }
    $e   = 'esc_html';
    $row = function ($label, $value_html) {
        return '<tr><td style="padding:2px 12px 2px 0;color:#667;">' . esc_html($label) . '</td><td style="padding:2px 0;">' . $value_html . '</td></tr>';
    };

    $html  = '<div style="font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.5;color:#1d2a36;">';
    $html .= '<table role="presentation" cellpadding="0" cellspacing="0" style="margin:0 0 14px;">';
    $html .= $row(__('Nome', 'idea-immobiliare-sa'), $e($fields['nome']));
    $html .= $row(__('Email', 'idea-immobiliare-sa'), '<a href="mailto:' . esc_attr($fields['email']) . '">' . $e($fields['email']) . '</a>');
    if (!empty($fields['telefono'])) {
        $html .= $row(__('Telefono', 'idea-immobiliare-sa'), $e($fields['telefono']));
    }
    $html .= '</table>';
    $html .= '<p style="margin:0 0 18px;white-space:pre-line;">' . $e($fields['messaggio']) . '</p>';

    $link = get_permalink($pid);
    $img  = '';
    $ids  = idea_immo_gallery_ids($pid);
    if ($ids) {
        $src = wp_get_attachment_image_url($ids[0], 'medium');
        if ($src) {
            $img = '<a href="' . esc_url($link) . '"><img src="' . esc_url($src) . '" width="220" alt="' . esc_attr(idea_immo_inquiry_subject($pid)) . '" style="display:block;width:220px;max-width:100%;height:auto;border-radius:6px;border:0;"></a>';
        }
    }
    $html .= '<table role="presentation" cellpadding="0" cellspacing="0" style="border:1px solid #dde3e8;border-radius:8px;"><tr>';
    if ($img) {
        $html .= '<td style="padding:10px;vertical-align:top;">' . $img . '</td>';
    }
    $html .= '<td style="padding:10px 14px 10px 4px;vertical-align:top;">';
    $html .= '<strong style="font-size:16px;">' . $e(html_entity_decode(get_the_title($pid), ENT_QUOTES, 'UTF-8')) . '</strong><br>';
    $ref = trim((string) get_post_meta($pid, '_idea_ref', true));
    if ($ref !== '') {
        $html .= $e(sprintf(__('ID %s', 'idea-immobiliare-sa'), $ref)) . '<br>';
    }
    $html .= $e(idea_immo_price_label($pid)) . '<br>';
    $html .= '<a href="' . esc_url($link) . '">' . $e(__('Apri la scheda', 'idea-immobiliare-sa')) . '</a>';
    $html .= '</td></tr></table>';
    $html .= '<p style="margin:18px 0 0;font-size:12px;color:#667;">' . $e(sprintf(__('Inviato dal sito %1$s · %2$s', 'idea-immobiliare-sa'), wp_parse_url(home_url('/'), PHP_URL_HOST), wp_date(get_option('date_format') . ' ' . get_option('time_format')))) . '</p>';
    $html .= '</div>';

    // L'email di questa richiesta è in HTML; il filtro si toglie subito dopo l'invio.
    add_filter('wp_mail_content_type', 'idea_immo_inquiry_html_type');
    return $html;
}, 10, 2);

function idea_immo_inquiry_html_type()
{
    return 'text/html';
}
add_action('ticinoweb_form_submitted', function () {
    remove_filter('wp_mail_content_type', 'idea_immo_inquiry_html_type');
});
