<?php
/**
 * Security functionality for the plugin.
 *
 * @package WPNews
 */

/**
 * Security class.
 */
class WPNews_Security {

	/**
	 * Option name holding the HMAC secret shared by unsubscribe/confirm/tracking tokens.
	 */
	const SECRET_OPTION = 'wpnews_unsubscribe_secret';

	/**
	 * Verify nonce for form submissions.
	 *
	 * @param string $nonce_field The nonce field name.
	 * @param string $action      The nonce action.
	 * @return bool
	 */
	public static function verify_nonce( $nonce_field, $action ) {
		if ( ! isset( $_POST[ $nonce_field ] ) ) {
			return false;
		}

		return (bool) wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ $nonce_field ] ) ), $action );
	}

	/**
	 * Check if current user has required capability.
	 *
	 * @param string $capability The required capability.
	 * @return bool
	 */
	public static function current_user_can( $capability ) {
		return current_user_can( $capability );
	}

	/**
	 * Sanitize text input.
	 *
	 * @param string $input The input to sanitize.
	 * @return string
	 */
	public static function sanitize_text( $input ) {
		return sanitize_text_field( wp_unslash( (string) $input ) );
	}

	/**
	 * Sanitize textarea input.
	 *
	 * @param string $input The input to sanitize.
	 * @return string
	 */
	public static function sanitize_textarea( $input ) {
		return sanitize_textarea_field( wp_unslash( (string) $input ) );
	}

	/**
	 * Sanitize email.
	 *
	 * @param string $email The email to sanitize.
	 * @return string
	 */
	public static function sanitize_email( $email ) {
		return sanitize_email( wp_unslash( (string) $email ) );
	}

	/**
	 * Validate email.
	 *
	 * @param string $email The email to validate.
	 * @return bool
	 */
	public static function is_valid_email( $email ) {
		return false !== is_email( (string) $email );
	}

	/**
	 * Return the site-specific HMAC secret, creating it on first use.
	 *
	 * @return string Hex-encoded 32-byte secret.
	 */
	public static function get_secret(): string {
		$secret = get_option( self::SECRET_OPTION, '' );
		if ( empty( $secret ) || ! is_string( $secret ) ) {
			$secret = bin2hex( random_bytes( 32 ) );
			add_option( self::SECRET_OPTION, $secret, '', false );
			// Another process may have created it in the meantime: re-read to stay consistent.
			$stored = get_option( self::SECRET_OPTION, '' );
			if ( ! empty( $stored ) && is_string( $stored ) ) {
				$secret = $stored;
			}
		}
		return $secret;
	}

	/**
	 * URL for an href/src inside an email body.
	 *
	 * esc_url() writes "&" as "&#038;". Correct HTML, but link rewriters such
	 * as SendGrid's Google Analytics tracking do not decode it and turn
	 * "&#038;s=..." into a "#" fragment, so every parameter after the first is
	 * lost (broken confirm / unsubscribe / click links). "&amp;" is handled by
	 * every rewriter and mail client.
	 *
	 * @param string $url URL.
	 * @return string Attribute-safe URL.
	 */
	public static function email_url( $url ) {
		return esc_attr( esc_url_raw( (string) $url ) );
	}

	/**
	 * Sign arbitrary data with HMAC-SHA256 using the site secret.
	 *
	 * @param string $data Data to sign.
	 * @return string Hex-encoded signature (64 chars).
	 */
	public static function sign( string $data ): string {
		return hash_hmac( 'sha256', $data, self::get_secret() );
	}

	/**
	 * Verify a signature produced by self::sign() in constant time.
	 *
	 * @param string $data Signed data.
	 * @param string $sig  Signature to verify.
	 * @return bool
	 */
	public static function verify( string $data, string $sig ): bool {
		if ( '' === $sig ) {
			return false;
		}
		return hash_equals( self::sign( $data ), $sig );
	}
}
