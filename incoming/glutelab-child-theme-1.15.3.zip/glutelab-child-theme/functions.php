<?php
/**
 * Glute Lab child theme bootstrap.
 *
 * @package GluteLabChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'GLUTELAB_THEME_VERSION', '1.15.3' );

require_once get_stylesheet_directory() . '/inc/theme-data.php';
require_once get_stylesheet_directory() . '/inc/packages.php';
require_once get_stylesheet_directory() . '/inc/admin-packages.php';
require_once get_stylesheet_directory() . '/inc/setup.php';
require_once get_stylesheet_directory() . '/inc/app/bootstrap.php';

/**
 * Load the child theme translations.
 *
 * @return void
 */
function glutelab_child_setup() {
	load_child_theme_textdomain( 'glutelab-child-theme', get_stylesheet_directory() . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
}
add_action( 'after_setup_theme', 'glutelab_child_setup', 20 );

/**
 * Check whether a native menu item points to the customer account page.
 *
 * @param WP_Post|object $item Menu item.
 * @param stdClass|object $args Menu arguments.
 * @return bool
 */
function glutelab_is_account_menu_item( $item, $args ) {
	if ( ! is_object( $args ) || empty( $args->theme_location ) || 'primary' !== $args->theme_location || empty( $args->menu_class ) || 'gl-nav__list' !== $args->menu_class ) {
		return false;
	}

	static $account_page_id = null;
	if ( null === $account_page_id ) {
		$account_page    = get_page_by_path( 'area-clienti' );
		$account_page_id = $account_page ? (int) $account_page->ID : 0;
	}

	return $account_page_id && isset( $item->object_id ) && $account_page_id === (int) $item->object_id;
}

/**
 * Replace the visible account menu label with an accessible profile icon.
 *
 * @param string         $title Menu item title.
 * @param WP_Post|object $item Menu item.
 * @param stdClass|object $args Menu arguments.
 * @return string
 */
function glutelab_account_menu_item_title( $title, $item, $args ) {
	if ( ! glutelab_is_account_menu_item( $item, $args ) ) {
		return $title;
	}

	$label = __( 'Area cliente', 'glutelab-child-theme' );
	return '<span class="gl-account-icon" aria-hidden="true"><svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" focusable="false"><circle cx="12" cy="8" r="3.25"></circle><path d="M5.75 19c.55-3.15 2.75-5 6.25-5s5.7 1.85 6.25 5"></path></svg></span><span class="screen-reader-text">' . esc_html( $label ) . '</span>';
}
add_filter( 'nav_menu_item_title', 'glutelab_account_menu_item_title', 10, 3 );

/**
 * Add the visual hook and tooltip to the native account link.
 *
 * @param array<string,string> $atts Link attributes.
 * @param WP_Post|object       $item Menu item.
 * @param stdClass|object      $args Menu arguments.
 * @return array<string,string>
 */
function glutelab_account_menu_link_attributes( $atts, $item, $args ) {
	if ( ! glutelab_is_account_menu_item( $item, $args ) ) {
		return $atts;
	}

	$label               = __( 'Area cliente', 'glutelab-child-theme' );
	$atts['class']       = trim( ( isset( $atts['class'] ) ? $atts['class'] . ' ' : '' ) . 'gl-account-link' );
	$atts['aria-label'] = $label;
	$atts['title']       = $label;
	return $atts;
}
add_filter( 'nav_menu_link_attributes', 'glutelab_account_menu_link_attributes', 10, 3 );

/**
 * Load the parent stylesheet first and the child stylesheet second.
 *
 * The parent registers its main handle with get_stylesheet_uri(), which points
 * to the child stylesheet while a child theme is active. Re-registering the
 * handle here prevents the child stylesheet from being loaded twice.
 *
 * @return void
 */
function glutelab_child_enqueue_styles() {
	$parent_theme = wp_get_theme( get_template() );
	$child_theme  = wp_get_theme();

	wp_dequeue_style( 'ticinoweb-ai-style' );
	wp_deregister_style( 'ticinoweb-ai-style' );

	wp_enqueue_style(
		'ticinoweb-ai-parent-style',
		get_template_directory_uri() . '/style.css',
		array( 'poppins-font' ),
		$parent_theme->get( 'Version' )
	);

	wp_enqueue_style(
		'glutelab-child-style',
		get_stylesheet_uri(),
		array( 'ticinoweb-ai-parent-style' ),
		$child_theme->get( 'Version' )
	);

	wp_enqueue_style( 'glutelab-responsive', get_stylesheet_directory_uri() . '/assets/css/responsive.css', array( 'glutelab-child-style' ), GLUTELAB_THEME_VERSION );
	wp_enqueue_script( 'glutelab-site', get_stylesheet_directory_uri() . '/assets/js/site.js', array(), GLUTELAB_THEME_VERSION, true );
	wp_localize_script( 'glutelab-site', 'glutelabSite', array(
		'ajaxUrl' => admin_url( 'admin-ajax.php' ), 'tokenAction' => 'ticinoweb_form_token',
		'submitAction' => 'ticinoweb_submit_form',
		'genericError' => __( 'Invio non riuscito. Riprova o contattaci direttamente.', 'glutelab-child-theme' ),
	) );

	if ( is_front_page() ) {
		wp_enqueue_style( 'glutelab-home', get_stylesheet_directory_uri() . '/assets/css/home.css', array( 'glutelab-responsive' ), GLUTELAB_THEME_VERSION );
		wp_enqueue_script( 'glutelab-home', get_stylesheet_directory_uri() . '/assets/js/home.js', array( 'glutelab-site' ), GLUTELAB_THEME_VERSION, true );
		wp_localize_script( 'glutelab-home', 'glutelabHome', array(
			'slideStatus' => __( 'Slide %1$d di %2$d: %3$s', 'glutelab-child-theme' ),
		) );
	}
}
add_action( 'wp_enqueue_scripts', 'glutelab_child_enqueue_styles', 20 );

/** Preload the first hero image. */
function glutelab_resource_hints( $urls, $relation ) {
	if ( 'preload' === $relation && is_front_page() ) {
		$slides = glutelab_get_slides();
		if ( ! empty( $slides[0]['image'] ) ) {
			$urls[] = array( 'href' => esc_url_raw( $slides[0]['image'] ), 'as' => 'image', 'fetchpriority' => 'high' );
		}
	}
	return $urls;
}
add_filter( 'wp_resource_hints', 'glutelab_resource_hints', 10, 2 );

/** Print CMS-selected fonts as local fallback stacks. */
function glutelab_font_variables() {
	$allowed  = array( 'Poppins', 'Inter', 'Roboto', 'Open Sans', 'Lato', 'Montserrat', 'Nunito', 'Raleway', 'Arial', 'Georgia' );
	$headings = sanitize_text_field( get_option( 'ticinoweb_font_headings', 'Poppins' ) );
	$body     = sanitize_text_field( get_option( 'ticinoweb_font_body', 'Inter' ) );
	$headings = in_array( $headings, $allowed, true ) ? $headings : 'Poppins';
	$body     = in_array( $body, $allowed, true ) ? $body : 'Inter';
	printf( '<style id="glutelab-cms-fonts">:root{--gl-font-display:%1$s,Arial,sans-serif;--gl-font-body:%2$s,Arial,sans-serif}</style>', esc_html( $headings ), esc_html( $body ) );
}
add_action( 'wp_head', 'glutelab_font_variables', 20 );
