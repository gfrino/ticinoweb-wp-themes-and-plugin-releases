<?php
defined( 'ABSPATH' ) || exit;
get_header();
$contact = ticinoweb_get_contact_info();
$phones = adb_contact_phones( $contact );
$emails = array_unique( array_filter( array( $contact['email'] ?? '', $contact['email_2'] ?? '', $contact['email_3'] ?? '' ), 'is_email' ) );
$days = array( 'monday' => __( 'Lunedì', 'amicidibacco' ), 'tuesday' => __( 'Martedì', 'amicidibacco' ), 'wednesday' => __( 'Mercoledì', 'amicidibacco' ), 'thursday' => __( 'Giovedì', 'amicidibacco' ), 'friday' => __( 'Venerdì', 'amicidibacco' ), 'saturday' => __( 'Sabato', 'amicidibacco' ), 'sunday' => __( 'Domenica', 'amicidibacco' ) );
$hours = array();
foreach ( $days as $key => $label ) {
    $value = ticinoweb_format_day_hours( $contact['opening_hours'][ $key ] ?? array() );
    if ( $value ) { $hours[] = array( $label, $value ); }
}
$has_address = ! empty( $contact['address'] ) || ! empty( $contact['address_2'] );
$socials = array_filter( array_intersect_key( $contact, array_flip( array( 'instagram', 'facebook', 'linkedin', 'youtube', 'x', 'tiktok', 'behance', 'github' ) ) ) );
?>
<main id="main-content" class="adb-contact-page">
    <?php while ( have_posts() ) : the_post(); $photo = get_post_thumbnail_id(); ?>
    <section class="adb-wrap adb-contact-opening<?php echo $photo ? '' : ' adb-contact-opening--text'; ?>" aria-labelledby="adb-contact-title">
        <div class="adb-contact-opening__copy">
            <h1 id="adb-contact-title"><?php the_title(); ?></h1>
            <div class="adb-contact-editorial"><?php the_content(); ?></div>
        </div>
        <?php if ( $photo ) : ?><figure class="adb-contact-photo">
            <?php adb_photo( $photo, 'full', array( 'loading' => 'eager', 'fetchpriority' => 'high', 'decoding' => 'async', 'sizes' => '(max-width:760px) 100vw, 55vw', 'alt' => '' ) ); ?>
            <?php if ( wp_get_attachment_caption( $photo ) ) : ?><figcaption><?php echo esc_html( wp_get_attachment_caption( $photo ) ); ?></figcaption><?php endif; ?>
        </figure><?php endif; ?>
    </section>
    <?php if ( $emails || $phones ) : ?>
    <section class="adb-wrap adb-contact-direct" aria-label="<?php esc_attr_e( 'Contatti diretti', 'amicidibacco' ); ?>">
        <?php if ( $emails ) : ?><div><h2><?php esc_html_e( 'Scrivici', 'amicidibacco' ); ?></h2><ul>
            <?php foreach ( $emails as $email ) : ?><li><a href="<?php echo esc_url( 'mailto:' . $email ); ?>"><?php echo esc_html( $email ); ?><?php echo adb_icon(); ?></a></li><?php endforeach; ?>
        </ul></div><?php endif; ?>
        <?php if ( $phones ) : ?><div><h2><?php esc_html_e( 'Chiamaci', 'amicidibacco' ); ?></h2><ul>
            <?php foreach ( $phones as $number => $display ) : ?><li><a href="<?php echo esc_url( 'tel:' . $number ); ?>"><?php echo esc_html( $display ); ?><?php echo adb_icon(); ?></a></li><?php endforeach; ?>
        </ul></div><?php endif; ?>
    </section>
    <?php endif; ?>
    <?php if ( ! empty( $contact['address'] ) || ! empty( $contact['address_2'] ) || $hours || ! empty( $contact['opening_hours_note'] ) ) : ?>
    <section class="adb-contact-visit" aria-label="<?php esc_attr_e( 'Visite e appuntamenti', 'amicidibacco' ); ?>"><div class="adb-wrap adb-contact-visit__inner">
        <?php if ( $has_address ) : ?><div><h2 id="adb-contact-visit-title"><?php esc_html_e( 'Dove incontrarci', 'amicidibacco' ); ?></h2>
            <?php foreach ( array( array( 'address', 'address_label' ), array( 'address_2', 'address_2_label' ) ) as $keys ) :
                $address = (string) ( $contact[ $keys[0] ] ?? '' ); if ( ! trim( $address ) ) { continue; }
                $map = adb_contact_map_url( $address, 'address' === $keys[0] ? ( $contact['map_url'] ?? '' ) : '' ); ?>
            <div class="adb-contact-address">
                <?php if ( ! empty( $contact[ $keys[1] ] ) ) : ?><h3><?php echo esc_html( $contact[ $keys[1] ] ); ?></h3><?php endif; ?>
                <address><?php echo nl2br( esc_html( $address ) ); ?></address>
                <?php if ( $map ) : ?><a class="adb-link" href="<?php echo esc_url( $map ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Come raggiungerci', 'amicidibacco' ); ?><?php echo adb_icon(); ?></a><?php endif; ?>
            </div>
            <?php endforeach; ?>
            <?php if ( ! empty( $contact['vat'] ) ) : ?><p class="adb-contact-vat"><?php echo esc_html( $contact['vat'] ); ?></p><?php endif; ?>
        </div><?php endif; ?>
        <?php if ( $hours || ! empty( $contact['opening_hours_note'] ) ) : ?><div class="adb-contact-availability"><h2><?php esc_html_e( 'Quando incontrarci', 'amicidibacco' ); ?></h2>
            <?php if ( ! empty( $contact['opening_hours_note'] ) ) : ?><p><?php echo nl2br( esc_html( $contact['opening_hours_note'] ) ); ?></p><?php endif; ?>
            <?php if ( $hours ) : ?><dl><?php foreach ( $hours as $day ) : ?><div><dt><?php echo esc_html( $day[0] ); ?></dt><dd><?php echo esc_html( $day[1] ); ?></dd></div><?php endforeach; ?></dl><?php endif; ?>
        </div><?php endif; ?>
    </div></section>
    <?php endif; ?>
    <?php if ( $socials ) : ?><nav class="adb-wrap adb-contact-social" aria-label="<?php esc_attr_e( 'Seguici', 'amicidibacco' ); ?>">
        <?php foreach ( $socials as $name => $url ) : $url = esc_url( $url, array( 'https', 'http' ) ); if ( ! $url ) { continue; } ?><a class="adb-link" href="<?php echo $url; ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( 'x' === $name ? 'X' : ucfirst( $name ) ); ?><?php echo adb_icon(); ?></a><?php endforeach; ?>
    </nav><?php endif; ?>
    <?php endwhile; ?>
</main>
<?php get_footer(); ?>
