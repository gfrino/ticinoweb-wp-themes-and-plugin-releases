/* Presentation adapter only: WooCommerce owns values, compatibility, price and stock. */
(($) => {
    'use strict';
    let serial = 0, opened = null;
    const chevron = '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.4"><path d="m6 9 6 6 6-6"/></svg>';
    const check = '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.4"><path d="m5 12 4 4L19 6"/></svg>';
    function enhance(select) {
        if (select.dataset.adbEnhanced) return;
        const id = `adb-variation-${++serial}`;
        const label = select.labels?.[0];
        const wrapper = document.createElement('div'); wrapper.className = 'adb-variation-select';
        const trigger = document.createElement('button'); trigger.type = 'button'; trigger.className = 'adb-variation-trigger'; trigger.id = `${id}-trigger`;
        trigger.setAttribute('role', 'combobox'); trigger.setAttribute('aria-haspopup', 'listbox'); trigger.setAttribute('aria-expanded', 'false'); trigger.setAttribute('aria-controls', `${id}-list`);
        const text = document.createElement('span'); text.id = `${id}-value`; trigger.append(text); trigger.insertAdjacentHTML('beforeend', chevron);
        if (label) { if (!label.id) label.id = `${id}-label`; trigger.setAttribute('aria-labelledby', `${label.id} ${text.id}`); }
        else trigger.setAttribute('aria-label', select.getAttribute('aria-label') || select.name);
        const popup = document.createElement('div'); popup.className = 'adb-variation-popup'; popup.id = `${id}-list`; popup.hidden = true; popup.setAttribute('role', 'listbox'); popup.setAttribute('data-lenis-prevent', '');
        if (label) popup.setAttribute('aria-labelledby', label.id);
        select.before(wrapper); wrapper.append(select, trigger); document.body.append(popup);
        select.dataset.adbEnhanced = 'true'; select.classList.add('adb-variation-native'); select.tabIndex = -1; select.setAttribute('aria-hidden', 'true');
        let choices = [], active = -1, prefix = '', prefixTimer;
        const place = () => {
            if (popup.hidden) return;
            const rect = trigger.getBoundingClientRect(); const availableBelow = window.innerHeight - rect.bottom - 12;
            const availableAbove = rect.top - 12; const above = availableBelow < 180 && availableAbove > availableBelow;
            popup.style.width = `${Math.min(rect.width, window.innerWidth - 24)}px`;
            popup.style.left = `${Math.max(12, Math.min(rect.left, window.innerWidth - rect.width - 12))}px`;
            popup.style.maxHeight = `${Math.max(60, Math.min(300, above ? availableAbove : availableBelow))}px`;
            popup.style.top = above ? 'auto' : `${rect.bottom + 6}px`;
            popup.style.bottom = above ? `${window.innerHeight - rect.top + 6}px` : 'auto';
        };
        const highlight = index => {
            active = index;
            choices.forEach((entry, i) => entry.node.classList.toggle('is-active', i === active));
            if (choices[active]) { trigger.setAttribute('aria-activedescendant', choices[active].node.id); choices[active].node.scrollIntoView({block: 'nearest'}); }
        };
        const close = () => { popup.hidden = true; trigger.setAttribute('aria-expanded', 'false'); trigger.removeAttribute('aria-activedescendant'); if (opened?.trigger === trigger) opened = null; prefix = ''; clearTimeout(prefixTimer); };
        const refresh = () => {
            const current = select.selectedOptions[0]; text.textContent = current?.textContent || select.options[0]?.textContent || '';
            trigger.disabled = select.disabled; trigger.classList.toggle('has-value', !!select.value); trigger.setAttribute('aria-required', String(select.required));
            const previous = choices[active]?.value;
            choices = []; popup.replaceChildren();
            [...select.options].forEach((option, index) => {
                if (option.hidden) return;
                const node = document.createElement('div'); node.className = 'adb-variation-option'; node.id = `${id}-option-${index}`; node.setAttribute('role', 'option'); node.setAttribute('aria-selected', String(option.selected)); node.setAttribute('aria-disabled', String(option.disabled));
                const name = document.createElement('span'); name.textContent = option.textContent; node.append(name); if (option.selected) node.insertAdjacentHTML('beforeend', check);
                const entry = {node, value: option.value, disabled: option.disabled}; choices.push(entry); popup.append(node);
                node.addEventListener('pointerdown', event => event.preventDefault());
                node.addEventListener('click', () => choose(entry));
            });
            if (trigger.disabled) close();
            if (!popup.hidden) { place(); highlight(Math.max(0, choices.findIndex(entry => entry.value === previous && !entry.disabled))); }
        };
        const choose = entry => {
            if (!entry || entry.disabled) return;
            close(); select.value = entry.value; $(select).trigger('change'); refresh(); trigger.focus({preventScroll: true});
        };
        const open = () => {
            if (trigger.disabled) return;
            opened?.close(); refresh(); popup.hidden = false; trigger.setAttribute('aria-expanded', 'true'); opened = {trigger, popup, close}; place();
            highlight(Math.max(0, choices.findIndex(entry => entry.value === select.value && !entry.disabled)));
        };
        trigger.addEventListener('click', () => popup.hidden ? open() : close());
        label?.addEventListener('click', event => { event.preventDefault(); trigger.focus(); if (popup.hidden) open(); });
        trigger.addEventListener('keydown', event => {
            const enabled = choices.map((entry, index) => entry.disabled ? -1 : index).filter(index => index >= 0);
            if (['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) {
                event.preventDefault(); if (popup.hidden) { open(); return; }
                const offset = enabled.indexOf(active);
                highlight(event.key === 'Home' ? enabled[0] : event.key === 'End' ? enabled.at(-1) : enabled[Math.max(0, Math.min(enabled.length - 1, offset + (event.key === 'ArrowDown' ? 1 : -1)))]);
            } else if (event.key === 'Escape' && !popup.hidden) { event.preventDefault(); close(); }
            else if (event.key === 'Tab') close();
            else if ((event.key === 'Enter' || event.key === ' ') && !popup.hidden) { event.preventDefault(); choose(choices[active]); }
            else if (event.key.length === 1 && !event.ctrlKey && !event.metaKey && !event.altKey && event.key !== ' ') {
                event.preventDefault(); if (popup.hidden) open(); prefix += event.key.toLocaleLowerCase(); clearTimeout(prefixTimer); prefixTimer = setTimeout(() => { prefix = ''; }, 700);
                const match = choices.findIndex(entry => !entry.disabled && entry.node.textContent.trim().toLocaleLowerCase().startsWith(prefix)); if (match >= 0) highlight(match);
            }
        });
        // WooCommerce focuses the first native field after reset; keep focus on its visible control.
        select.addEventListener('focus', () => trigger.focus({preventScroll: true}));
        select.addEventListener('invalid', () => trigger.focus());
        $(select).on('change.adbSelect', refresh);
        $(select.form).on('woocommerce_update_variation_values.adbSelect reset_data.adbSelect found_variation.adbSelect', refresh);
        new MutationObserver(refresh).observe(select, {childList: true, subtree: true, attributes: true, attributeFilter: ['disabled', 'selected', 'hidden', 'value']});
        refresh();
    }
    const init = () => document.querySelectorAll('.variations_form .variations select').forEach(enhance);
    $(init); $(document).on('wc_variation_form', init);
    document.addEventListener('pointerdown', event => { if (opened && !opened.popup.contains(event.target) && !opened.trigger.contains(event.target)) opened.close(); });
    document.addEventListener('focusin', event => { if (opened && !opened.trigger.contains(event.target) && !opened.popup.contains(event.target)) opened.close(); });
    document.addEventListener('scroll', event => { if (opened && !opened.popup.contains(event.target)) opened.close(); }, true);
    window.addEventListener('resize', () => opened?.close());
})(jQuery);
