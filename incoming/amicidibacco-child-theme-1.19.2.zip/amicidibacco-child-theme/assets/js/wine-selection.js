(function (root, factory) {
    'use strict';
    if (typeof module === 'object' && module.exports) { module.exports = factory(); }
    else { root.ADBWineSelection = factory(); }
}(typeof window !== 'undefined' ? window : globalThis, function () {
    'use strict';

    /**
     * Return original {id, group, image, ...} items, without mutating either input.
     * recent.ids/groups/images are newest-first; images is optional.
     * The caller owns history persistence.
     * A small pool may reuse history, but never duplicates a wine or image.
     */
    function choose(pool, recent, limit, random) {
        limit = limit === undefined ? 5 : Math.max(0, Math.floor(Number(limit) || 0));
        random = typeof random === 'function' ? random : Math.random;
        recent = recent || {};
        var recentIds = (Array.isArray(recent.ids) ? recent.ids : []).map(String);
        var recentGroups = (Array.isArray(recent.groups) ? recent.groups : []).map(String);
        var recentImages = (Array.isArray(recent.images) ? recent.images : []).map(String);
        var candidates = (Array.isArray(pool) ? pool : []).filter(function (item) {
            return item && Number(item.id) > 0 && typeof item.group === 'string' && item.group.trim() && Number(item.image) > 0;
        });
        // Fisher–Yates shuffles a new array, including on a cached page response.
        for (var index = candidates.length - 1; index > 0; index -= 1) {
            var sample = Number(random());
            var target = Math.floor(Math.min(0.9999999999999999, Math.max(0, sample || 0)) * (index + 1));
            var temporary = candidates[index];
            candidates[index] = candidates[target];
            candidates[target] = temporary;
        }
        var fresh = [];
        var reused = [];
        candidates.forEach(function (item) {
            (recentIds.indexOf(String(item.id)) === -1 && recentGroups.indexOf(item.group) === -1 && recentImages.indexOf(String(item.image)) === -1 ? fresh : reused).push(item);
        });
        candidates = fresh.concat(reused);
        // Even when the whole pool is recent, start with another wine if possible.
        var different = candidates.findIndex(function (item) {
            return String(item.id) !== recentIds[0] && item.group !== recentGroups[0] && String(item.image) !== recentImages[0];
        });
        if (different > 0) { candidates.unshift(candidates.splice(different, 1)[0]); }
        var selected = [];
        var ids = new Set();
        var groups = new Set();
        var images = new Set();
        candidates.some(function (item) {
            if (selected.length >= limit) { return true; }
            var id = String(item.id);
            var image = String(item.image);
            if (!ids.has(id) && !groups.has(item.group) && !images.has(image)) {
                selected.push(item);
                ids.add(id);
                groups.add(item.group);
                images.add(image);
            }
            return false;
        });
        return selected;
    }

    return { choose: choose };
}));
