(() => {
    'use strict';
    const math=window.ADBMotion;
    if (!math) return;
    const {clamp,wineStack,passage,counterAperture,coverZoom,portal:portalState}=math;
    const reduced=matchMedia('(prefers-reduced-motion: reduce)');
    const desktop=matchMedia('(min-width: 901px) and (pointer: fine)');
    const saveData=!!navigator.connection?.saveData;
    let gameVisible=false;
    const hero=document.querySelector('[data-hero]');
    const landscape=document.querySelector('[data-hero-landscape] img');
    const stack=document.querySelector('[data-wine-stack]');
    function chooseWineStack() {
        const template=document.querySelector('[data-wine-pool]'),picker=window.ADBWineSelection;
        if(!stack||!template||!picker)return;
        const pool=[...template.content.querySelectorAll('[data-wine-slide]')].map(node=>({id:Number(node.dataset.wineId),group:node.dataset.wineGroup,image:Number(node.dataset.wineImage),node}));
        const key='adb-wine-history:'+location.pathname;let recent={ids:[],groups:[],images:[]};
        try{const saved=JSON.parse(sessionStorage.getItem(key)||'null');if(saved)recent={ids:Array.isArray(saved.ids)?saved.ids.slice(0,15):[],groups:Array.isArray(saved.groups)?saved.groups.slice(0,15):[],images:Array.isArray(saved.images)?saved.images.slice(0,15):[]};}catch{}
        const chosen=picker.choose(pool,recent,5);if(!chosen.length)return;
        const nodes=chosen.map((item,index)=>{const node=item.node.cloneNode(true);node.dataset.wineSlide=String(index);node.classList.toggle('is-active',!index);node.inert=!!index;if(!index){node.removeAttribute('aria-hidden');node.removeAttribute('tabindex');node.querySelector('img')?.setAttribute('loading','eager');}else{node.setAttribute('aria-hidden','true');node.setAttribute('tabindex','-1');}return node;});
        stack.replaceChildren(...nodes);
        try{sessionStorage.setItem(key,JSON.stringify({ids:[...chosen.map(item=>item.id),...recent.ids].slice(0,15),groups:[...chosen.map(item=>item.group),...recent.groups].slice(0,15),images:[...chosen.map(item=>item.image),...recent.images].slice(0,15)}));}catch{}
    }
    chooseWineStack();
    let slides=[...document.querySelectorAll('[data-wine-slide]')];
    const opening=document.querySelector('[data-opening]');
    const openingStage=document.querySelector('[data-opening-stage]');
    const openingIntro=document.querySelector('[data-opening-intro]');
    const portalInk=document.querySelector('[data-portal-ink]');
    const nextScene=document.querySelector('[data-next-scene]');
    const journey=document.querySelector('[data-journey]');
    const journeyPhotos=[...document.querySelectorAll('[data-journey-photo]')];
    const journeyWords=document.querySelector('.adb-journey__words');
    const portraits=[...document.querySelectorAll('.adb-territory__photo img,.adb-story__photo img')];
    let lenis=null,raf=0,lastTime=0,dirty=true,bounds={},selected=-1;
    let apertureReady=true,stackCycle=7000,stackTransition=1400,stackTime=0,wasMoving=false,commerceVisible=true,heroVisible=true,focused=false;
    const outlineReady=!!window.ADBCalligraphy&&[...(portalInk?.querySelector('text')?.textContent||'')].every(char=>window.ADBCalligraphy.chars[char]);
    const cinematic=()=>!reduced.matches&&!saveData&&outlineReady&&apertureReady;
    const autoAdvance=()=>cinematic()&&slides.length>1&&heroVisible&&commerceVisible&&!focused&&!document.hidden;
    function paintStack() {
        const state=wineStack(slides.length,stackTime,stackCycle,stackTransition);
        if(!dirty&&!state.moving&&!wasMoving&&selected===state.active)return;
        wasMoving=state.moving;selected=state.active;
        slides.forEach((el,index)=>{
            const slide=state.slides[index],active=index===state.active;
            for(const [key,value] of Object.entries(slide))if(key!=='z')el.style.setProperty(`--wine-${key}`,value.toFixed(5));
            el.style.zIndex=String(slide.z);el.classList.toggle('is-active',active);el.inert=!active;
            if(active){el.removeAttribute('aria-hidden');el.removeAttribute('tabindex');}
            else{el.setAttribute('aria-hidden','true');el.setAttribute('tabindex','-1');}
        });
    }
    function paintScroll() {
        const y=scrollY,h=innerHeight;
        if(opening&&y+h>bounds.opening.top&&y<bounds.opening.bottom){
            const progress=clamp((y-bounds.opening.start)/bounds.opening.travel);
            const geometry=bounds.entry;
            const state=portalState(progress,geometry.zoomEnd);
            // Fixed horizontal anchor: zoom into the lettering without a sideways camera pan.
            const tx=geometry.startX;
            const ty=geometry.startY+(geometry.height*.5-geometry.startY)*state.rise;
            const matrix=`translate(${tx} ${ty}) scale(${state.zoom}) translate(${-geometry.pivotX} ${-geometry.pivotY})`;
            portalInk?.setAttribute('transform',matrix);
            if(portalInk)portalInk.style.opacity=String(state.ink);
            if(nextScene)nextScene.style.opacity=String(state.sceneBlend);
            if(hero){hero.style.opacity=String(state.heroOpacity);hero.style.transform=`translate3d(0,${-progress*55}px,0)`;hero.inert=progress>.45;}
            if(stack)stack.style.transform=`translate3d(${progress*150}px,0,0)`;
            if(openingIntro)openingIntro.style.opacity=String(state.introOpacity);
            if(landscape)landscape.style.transform=`scale(${1.05+progress*.13}) translate3d(0,${progress*-14}px,0)`;
            commerceVisible=progress<.42;
        }
        if (journey&&y+h>bounds.journey.top&&y<bounds.journey.bottom) {
            const progress=passage(bounds.journey.top,bounds.journey.height,y,h);
            journey.style.setProperty('--journey-progress',String(progress));
            journeyPhotos.forEach((photo,index)=>{
                const amount=index?clamp((progress-(index===1?.19:.54))/.3):1;
                photo.style.opacity=String(amount);
                const image=photo.querySelector('img');
                if(image)image.style.transform=`translate3d(0,${(progress-.5)*-90}px,0) scale(1.07)`;
            });
            if(journeyWords)journeyWords.style.transform=`translate3d(${-progress*18}vw,0,0)`;
        }
        portraits.forEach((image,i)=>{
            const b=bounds.portraits[i];
            if(y+h>b.top&&y<b.bottom)image.style.transform=`translate3d(0,${(passage(b.top,b.height,y,h)-.5)*-32}px,0) scale(1.07)`;
        });
    }
    function frame(time) {
        raf=0;
        if(document.hidden||gameVisible){lastTime=0;return;}
        const dt=lastTime?Math.min(250,time-lastTime):16;lastTime=time;
        lenis?.raf(time);
        const moving=autoAdvance();if(moving)stackTime+=dt;
        if(moving||dirty)paintStack();
        if(cinematic()&&(dirty||lenis?.isScrolling))paintScroll();
        dirty=false;
        if(lenis||autoAdvance())requestFrame();
    }
    function requestFrame(){if(!raf&&!document.hidden&&!gameVisible)raf=requestAnimationFrame(frame);}
    function requestPaint(){dirty=true;requestFrame();}
    function box(el){if(!el)return{top:0,bottom:0,height:1};const top=el.getBoundingClientRect().top+scrollY,height=el.offsetHeight;return{top,height,bottom:top+height};}
    // Font outlines stay geometric even beyond the browser's text rasterisation limit.
    function buildLettering(size) {
        const font=window.ADBCalligraphy,source=portalInk?.querySelector('text');
        if(!font||!source)return null;
        let cursor=0,previous='',items=[];
        for(const character of source.textContent){
            const name=font.chars[character],glyph=font.glyphs[name];if(!glyph)continue;
            cursor+=font.kern[previous+'|'+name]||0;items.push({glyph,x:cursor,character});cursor+=glyph.advance;previous=name;
        }
        const scale=size/font.units;
        [portalInk].filter(Boolean).forEach(parent=>{
            parent.querySelector('[data-entry-outline]')?.remove();parent.querySelector('text').style.display='none';
            const group=document.createElementNS('http://www.w3.org/2000/svg','g');group.setAttribute('data-entry-outline','');
            items.forEach(item=>{if(!item.glyph.d)return;const path=document.createElementNS(group.namespaceURI,'path');path.setAttribute('d',item.glyph.d);path.setAttribute('data-letter',item.character);path.setAttribute('transform',`translate(${(item.x-cursor/2)*scale} 0) scale(${scale} ${-scale})`);group.append(path);});
            parent.setAttribute('fill','#fffdf8');parent.append(group);
        });
        return {items,scale,width:cursor};
    }
    let lettering=null,letteringSize=0;
    function fitWineTitles() {
        const titles=slides.map(slide=>slide.querySelector('[data-wine-title]')).filter(Boolean);
        titles.forEach(title=>{title.style.removeProperty('--wine-title-size');title.style.whiteSpace='nowrap';title.style.overflowWrap='normal';});
        const minimum=innerWidth<=760?18:26;
        const metrics=titles.map(title=>({base:parseFloat(getComputedStyle(title).fontSize),width:title.clientWidth,ink:title.scrollWidth}));
        titles.forEach((title,index)=>{const m=metrics[index],size=Math.max(minimum,m.ink<=m.width?m.base:Math.min(m.base,m.base*m.width/Math.max(1,m.ink)*.98));title.style.setProperty('--wine-title-size',`${size.toFixed(2)}px`);const fits=m.ink*size/m.base<=m.width;title.style.whiteSpace=fits?'nowrap':'normal';title.style.overflowWrap=fits?'normal':'break-word';});
    }
    function measure() {
        const nextCycle=innerWidth>760?5600:7000;
        if(stackCycle!==nextCycle){stackCycle=nextCycle;stackTime=Math.max(0,selected)*stackCycle;}
        stackTransition=innerWidth>760?900:1400;
        document.body.classList.add('adb-motion-ready');
        document.body.classList.toggle('adb-cinematic',cinematic());
        const wantsSmooth=desktop.matches&&cinematic()&&typeof window.Lenis==='function';
        if(wantsSmooth&&!lenis)lenis=new window.Lenis({autoRaf:false,lerp:.12,smoothWheel:true,syncTouch:false,anchors:false,prevent:node=>!!node.closest?.('dialog,textarea,select,[data-lenis-prevent]')});
        if(!wantsSmooth&&lenis){lenis.destroy();lenis=null;}
        window.adbSmoothScroll=lenis;
        bounds={opening:box(opening),journey:box(journey),portraits:portraits.map(image=>box(image.parentElement))};
        if(openingStage){
            bounds.opening.start=bounds.opening.top-(parseFloat(getComputedStyle(openingStage).top)||0);
            bounds.opening.travel=Math.max(1,opening.offsetHeight-openingStage.offsetHeight);
            const canvasHeight=1440*openingStage.clientHeight/Math.max(1,openingStage.clientWidth);
            const svg=openingStage.querySelector('.adb-entry svg');
            svg?.setAttribute('viewBox',`0 0 1440 ${canvasHeight}`);
            const source=portalInk?.querySelector('text');
            const typeSize=parseFloat(getComputedStyle(source).fontSize)||120;
            if(typeSize!==letteringSize){lettering=buildLettering(typeSize);letteringSize=typeSize;}
            const text=portalInk?.querySelector('[data-entry-outline]')||source,bbox=text?.getBBox()||{x:-250,y:-90,width:500,height:100};
            const key=`${text?.textContent}|${typeSize}|${bbox.width}|${bbox.height}|${document.fonts.check(`${typeSize}px "Bacco Calligraphy"`)}`;
            if(!measure.aperture||measure.aperture.key!==key){
                const canvas=document.createElement('canvas');canvas.width=Math.ceil(bbox.width+8);canvas.height=Math.ceil(bbox.height+8);
                const context=canvas.getContext('2d',{willReadFrequently:true});
                context.translate(4-bbox.x,4-bbox.y);context.fillStyle='#000';
                if(lettering)lettering.items.forEach(item=>{if(!item.glyph.d)return;context.save();context.translate((item.x-lettering.width/2)*lettering.scale,0);context.scale(lettering.scale,-lettering.scale);context.fill(new Path2D(item.glyph.d));context.restore();});
                const letter=lettering?.items.find(item=>item.character==='B');
                const letterPath=portalInk.querySelector('[data-letter="B"]'),letterBox=letterPath?.getBBox();
                const target=letter&&letterBox?{x:(letter.x-lettering.width/2)*lettering.scale+(letterBox.x+letterBox.width*.55)*lettering.scale+4-bbox.x,y:-(letterBox.y+letterBox.height*.4)*lettering.scale+4-bbox.y}:{x:canvas.width*.65,y:canvas.height*.55};
                const aperture=counterAperture(context.getImageData(0,0,canvas.width,canvas.height).data,canvas.width,canvas.height,target);
                measure.aperture={key,x:aperture.x+bbox.x-4,y:aperture.y+bbox.y-4,radius:aperture.radius};
            }
            const hasAperture=measure.aperture.radius>0;
            if(apertureReady!==hasAperture){apertureReady=hasAperture;return measure();}
            const pivot=measure.aperture;
            const copyLeft=hero?.querySelector('.adb-hero__copy')?.getBoundingClientRect().left||24;
            const startX=copyLeft*1440/openingStage.clientWidth+pivot.x-bbox.x;
            bounds.entry={height:canvasHeight,pivotX:pivot.x,pivotY:pivot.y,startX,startY:canvasHeight*.91+pivot.y-(bbox.y+bbox.height/2),zoomEnd:coverZoom({x:startX,y:canvasHeight*.5},pivot.radius,1440,canvasHeight)};
        }
        if(!cinematic()){
            stackTime=Math.max(0,selected)*stackCycle;
            [landscape,hero,stack,journeyWords,...portraits,...journeyPhotos.map(p=>p.querySelector('img'))].filter(Boolean).forEach(el=>el.style.removeProperty('transform'));
            journeyPhotos.forEach(el=>el.style.removeProperty('opacity'));
            hero?.style.removeProperty('opacity');if(hero)hero.inert=false;openingIntro?.style.removeProperty('opacity');
            portalInk?.removeAttribute('transform');nextScene?.style.removeProperty('opacity');
            [portalInk].filter(Boolean).forEach(el=>el.style.removeProperty('opacity'));
            commerceVisible=true;
        }
        fitWineTitles();lenis?.resize();lastTime=0;requestPaint();
    }
    stack?.addEventListener('focusin',()=>{focused=true;stackTime=selected*stackCycle;requestPaint();});
    stack?.addEventListener('focusout',event=>{focused=stack.contains(event.relatedTarget);requestFrame();});
    // Observer gates every nonessential loop; no background wine cycle after the hero.
    if(hero)new IntersectionObserver(entries=>{heroVisible=entries[0].isIntersecting;lastTime=0;requestFrame();},{threshold:0}).observe(hero);
    document.querySelectorAll('a[href^="#"]').forEach(link=>link.addEventListener('click',event=>{
        const hash=link.getAttribute('href');if(!hash||hash.length<2)return;
        let id;try{id=decodeURIComponent(hash.slice(1));}catch{return;}
        const target=document.getElementById(id);if(!target)return;
        event.preventDefault();const top=id==='il-nostro-mondo'&&cinematic()?bounds.opening.start+bounds.opening.travel:target.getBoundingClientRect().top+scrollY-(document.querySelector('[data-header]')?.offsetHeight||80)-25;
        if(lenis)lenis.scrollTo(top,{duration:1.05,easing:t=>1-(1-t)**4});
        else window.scrollTo({top,behavior:reduced.matches?'instant':'smooth'});
        history.replaceState(null,'',hash);target.setAttribute('tabindex','-1');target.focus({preventScroll:true});
    }));
    addEventListener('scroll',requestPaint,{passive:true});addEventListener('resize',measure,{passive:true});addEventListener('pageshow',event=>{if(event.persisted){chooseWineStack();slides=[...document.querySelectorAll('[data-wine-slide]')];stackTime=0;selected=-1;wasMoving=false;focused=!!stack?.contains(document.activeElement);}measure();});
    reduced.addEventListener('change',measure);desktop.addEventListener('change',measure);
    document.addEventListener('adb:game-visibility',event=>{gameVisible=!!event.detail?.open;lastTime=0;if(gameVisible){if(raf)cancelAnimationFrame(raf);raf=0;}else requestPaint();});
    document.addEventListener('visibilitychange',()=>{lastTime=0;if(document.hidden){if(raf)cancelAnimationFrame(raf);raf=0;}else requestPaint();});
    addEventListener('pagehide',()=>{if(raf)cancelAnimationFrame(raf);raf=0;lastTime=0;});
    document.fonts?.ready.then(measure);addEventListener('load',measure,{once:true});measure();
})();
