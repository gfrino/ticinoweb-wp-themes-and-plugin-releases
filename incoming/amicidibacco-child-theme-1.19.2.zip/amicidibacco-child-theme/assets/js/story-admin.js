jQuery(function ($) {
    'use strict';
    const section = document.getElementById('adb-story-settings');
    const tab = document.getElementById('chi-siamo');
    if (!section || !tab) return;
    tab.append(section);
    $(section).on('click', '.adb-choose-media', function () {
        const box = $(this).closest('.adb-media-field');
        const frame = wp.media({title: $(box).find('label').text(), library: {type: 'image'}, multiple: false});
        frame.on('select', function () {
            const image = frame.state().get('selection').first().toJSON();
            box.find('input[type=hidden]').val(image.id).trigger('change');
            box.find('.adb-media-preview').empty().append($('<img>').attr({src: image.sizes?.thumbnail?.url || image.url, alt: ''}));
        });
        frame.open();
    });
    $(section).on('click', '.adb-clear-media', function () {
        const box = $(this).closest('.adb-media-field');
        box.find('input[type=hidden]').val('').trigger('change');
        box.find('.adb-media-preview').empty();
    });
});
