/* Native document navigation: only the header's enoteca link receives the circular entrance. */
(function () {
    'use strict';
    if (!('onpageswap' in window) || !('onpagereveal' in window)) { return; }
    var key = 'adb-enoteca-entry';
    var root = document.documentElement;
    var pending = null;
    var props = ['--adb-entry-x', '--adb-entry-y', '--adb-entry-radius'];
    var reduce = function () { return window.matchMedia('(prefers-reduced-motion: reduce)').matches; };
    var clearStored = function () { try { window.sessionStorage.removeItem(key); } catch (error) { /* Native links remain available. */ } };
    var clean = function () {
        root.classList.remove('adb-enoteca-transition');
        props.forEach(function (name) { root.style.removeProperty(name); });
    };
    var address = function (href) {
        try { var url = new URL(href, window.location.href); url.hash = ''; return url.origin === window.location.origin ? url.href : ''; }
        catch (error) { return ''; }
    };
    var valid = function (entry, destination) {
        return entry && entry.to === destination && Number.isFinite(entry.x) && entry.x >= 0 && entry.x <= 1 &&
            Number.isFinite(entry.y) && entry.y >= 0 && entry.y <= 1 && Number.isFinite(entry.at) &&
            Date.now() >= entry.at && Date.now() - entry.at < 12000;
    };
    var show = function (entry) {
        var x = entry.x * window.innerWidth;
        var y = entry.y * window.innerHeight;
        var radius = Math.hypot(Math.max(x, window.innerWidth - x), Math.max(y, window.innerHeight - y));
        root.style.setProperty(props[0], x.toFixed(2) + 'px');
        root.style.setProperty(props[1], y.toFixed(2) + 'px');
        root.style.setProperty(props[2], Math.ceil(radius + 2) + 'px');
        root.classList.add('adb-enoteca-transition');
    };
    var observe = function (transition) {
        // The outgoing ready promise rejects normally when the browser hides its document.
        transition.ready.catch(function () {});
        transition.finished.then(clean, clean);
    };
    var skip = function (transition) { clean(); if (transition) { observe(transition); transition.skipTransition(); } };

    document.addEventListener('click', function (event) {
        pending = null;
        clearStored();
        var link = event.target && typeof event.target.closest === 'function' ? event.target.closest('.adb-header__shop') : null;
        if (!link || event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey ||
            link.hasAttribute('download') || (link.target && link.target !== '_self') || reduce()) { return; }
        var to = address(link.href);
        if (!to || to === address(window.location.href) || window.innerWidth <= 0 || window.innerHeight <= 0) { return; }
        var rect = link.getBoundingClientRect();
        pending = { to: to, x: Math.max(0, Math.min(1, (rect.left + rect.width / 2) / window.innerWidth)),
            y: Math.max(0, Math.min(1, (rect.top + rect.height / 2) / window.innerHeight)), at: Date.now() };
        // No preventDefault, timer, fetch or DOM replacement: WooCommerce owns the next page.
    });

    window.addEventListener('pageswap', function (event) {
        var entry = pending;
        pending = null;
        var transition = event.viewTransition;
        var destination = event.activation && event.activation.entry ? address(event.activation.entry.url) : entry && entry.to;
        if (!transition || reduce() || !valid(entry, destination)) { clearStored(); skip(transition); return; }
        try { window.sessionStorage.setItem(key, JSON.stringify(entry)); }
        catch (error) { skip(transition); return; }
        show(entry);
        observe(transition);
    });

    window.addEventListener('pagereveal', function (event) {
        var entry = null;
        try { entry = JSON.parse(window.sessionStorage.getItem(key)); } catch (error) { /* Invalid or unavailable state is ignored. */ }
        clearStored();
        if (!event.viewTransition || reduce() || !valid(entry, address(window.location.href))) { skip(event.viewTransition); return; }
        show(entry);
        observe(event.viewTransition);
    });

    window.addEventListener('pageshow', function (event) {
        if (event.persisted) { pending = null; clean(); }
    });
}());
