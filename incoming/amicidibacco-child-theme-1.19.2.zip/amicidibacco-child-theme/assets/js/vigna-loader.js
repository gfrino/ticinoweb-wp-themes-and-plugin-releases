(() => {
 'use strict';
 const dialog=document.querySelector('[data-vigna]'),config=window.adbVigna;
 if(!dialog||!config||!dialog.showModal)return;
 let retries=0,pending=null,game=null,returnFocus=null,search=null,previousOverflow='',generation=0;
 const close=()=>{
  generation++;game?.dispose();game=null;document.dispatchEvent(new CustomEvent('adb:game-visibility',{detail:{open:false}}));dialog.classList.remove('is-ready','is-complete','is-simple');
  document.documentElement.style.overflow=previousOverflow;
  if(search?.showModal){
   if(returnFocus){returnFocus.value='';returnFocus.dispatchEvent(new Event('input',{bubbles:true}));}
   if(!search.open)search.showModal();window.adbSmoothScroll?.stop();returnFocus?.focus({preventScroll:true});
  }else{window.adbSmoothScroll?.start();document.querySelector('[data-search-open]')?.focus({preventScroll:true});}
 };
 const load=()=>{
  if(!pending){
   const css=new Promise((resolve,reject)=>{
    let link=document.querySelector('link[data-vigna-style]');if(link?.sheet){resolve();return;}
    if(link)link.remove();link=document.createElement('link');link.rel='stylesheet';link.href=config.css;link.dataset.vignaStyle='';
    const timeout=setTimeout(()=>{link.remove();reject(new Error('style timeout'));},15000);
    link.onload=()=>{clearTimeout(timeout);resolve();};link.onerror=()=>{clearTimeout(timeout);link.remove();reject(new Error('style'));};document.head.append(link);
   });
   pending=Promise.all([css,import(config.module+(retries?'&retry='+retries:''))]).then(([,module])=>module).catch(error=>{pending=null;retries++;throw error;});
  }
  return pending;
 };
 document.addEventListener('adb:vineyard-request',async event=>{
  event.preventDefault();if(dialog.open)return;const current=++generation;
  search=document.querySelector('[data-search-dialog]');returnFocus=search?.querySelector('input[type=search]');
  previousOverflow=document.documentElement.style.overflow;search?.close();document.documentElement.style.overflow='hidden';
  const loading=dialog.querySelector('[data-vigna-loading]');loading.textContent=config.strings.loading;loading.hidden=false;
  dialog.showModal();document.dispatchEvent(new CustomEvent('adb:game-visibility',{detail:{open:true}}));window.adbSmoothScroll?.stop();dialog.querySelector('[data-vigna-exit]').focus({preventScroll:true});
  try{const module=await load();if(current!==generation||!dialog.open)return;const preparedArtwork=await module.prepareVineyard(config);if(current!==generation||!dialog.open)return;game=module.startVineyard(dialog,{...config,preparedArtwork});}
  catch{if(current===generation)loading.textContent=config.strings.failure;}
 });
 dialog.querySelector('[data-vigna-exit]').addEventListener('click',()=>dialog.close());
 dialog.addEventListener('close',close);
 dialog.addEventListener('keydown',event=>{if(event.key==='Escape')event.stopPropagation();});
})();
