(function () {
    'use strict';
    var root = document.querySelector('[data-cellars]'); if (!root) { return; }
    var searchBox = root.querySelector('[data-cellars-search]'), search = searchBox.querySelector('input');
    var clear = root.querySelector('[data-cellars-clear]'), countries = root.querySelector('[data-cellars-countries]');
    var count = root.querySelector('[data-cellars-count]'), empty = root.querySelector('[data-cellars-empty]');
    var strings = JSON.parse(root.querySelector('[data-cellars-strings]').textContent);
    var selected = '', normalize = function (text) { return text.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase().trim(); };
    var cards = Array.from(root.querySelectorAll('[data-cellar]')).map(function (el) { return { el: el, text: normalize(el.dataset.search), countries: JSON.parse(el.dataset.country) }; });
    searchBox.hidden = false; countries.hidden = false;
    function update() {
        var words = normalize(search.value).split(/\s+/).filter(Boolean), total = 0;
        cards.forEach(function (card) { var visible = (!selected || card.countries.includes(selected)) && words.every(function (word) { return card.text.includes(word); }); card.el.hidden = !visible; if (visible) { total++; } });
        count.textContent = (total === 1 ? strings.one : strings.count).replace('%d', total);
        clear.hidden = !search.value; empty.hidden = total !== 0;
    }
    search.addEventListener('input', update);
    clear.addEventListener('click', function () { search.value = ''; update(); search.focus(); });
    countries.addEventListener('click', function (event) {
        var button = event.target.closest('[data-country]'); if (!button) { return; }
        selected = button.dataset.country;
        countries.querySelectorAll('button').forEach(function (item) { item.setAttribute('aria-pressed', item === button ? 'true' : 'false'); }); update();
    });
    var reduce = window.matchMedia('(prefers-reduced-motion: reduce)');
    if ('IntersectionObserver' in window) {
        var observer = new IntersectionObserver(function (entries) { entries.forEach(function (entry, order) { if (entry.isIntersecting) { if (!reduce.matches) { entry.target.style.setProperty('--cellar-delay', Math.min(order, 2) * 85 + 'ms'); entry.target.classList.add('is-cellar-visible'); } observer.unobserve(entry.target); } }); }, { threshold: .08 });
        cards.forEach(function (card) { observer.observe(card.el); });
    }
    var hero = root.querySelector('.adb-cellars-hero'), photo = hero.querySelector('img'), frame = 0, visible = true;
    function render() {
        frame = 0;
        if (!photo || reduce.matches || innerWidth < 900) { hero.style.removeProperty('--cellar-pan'); hero.style.removeProperty('--cellar-depth'); hero.style.removeProperty('--cellar-copy-pan'); return; }
        var bounds = hero.getBoundingClientRect(), top = bounds.top;
        var progress = Math.max(0, Math.min(1, -top / bounds.height));
        hero.style.setProperty('--cellar-depth', (1.035 + progress * .055).toFixed(4));
        hero.style.setProperty('--cellar-copy-pan', (progress * 18).toFixed(2) + 'px');
        hero.style.setProperty('--cellar-pan', Math.max(-16, Math.min(32, -top * .08)).toFixed(2) + 'px');
    }
    function schedule() { if (visible && !document.hidden && !frame) { frame = requestAnimationFrame(render); } }
    window.addEventListener('scroll', schedule, { passive: true }); window.addEventListener('resize', schedule); reduce.addEventListener('change', render);
    if ('IntersectionObserver' in window) { var heroObserver = new IntersectionObserver(function (entries) { visible = entries[0].isIntersecting; if (visible) { schedule(); } }); heroObserver.observe(hero); }
    update(); render();
}());
