/* A landscape opens, then five wines follow the existing native scroll. */
(function (root, factory) {
    var api = factory();
    if (typeof module === 'object' && module.exports) { module.exports = api; }
    if (typeof document !== 'undefined') { api.mount(root, document); }
}(typeof window !== 'undefined' ? window : this, function () {
    'use strict';
    var clamp = function (value) { return Math.max(0, Math.min(1, Number.isFinite(value) ? value : 0)); };
    var ease = function (value) { value = clamp(value); if (value > 1 - 1e-9) { return 1; } return clamp(value * value * value * (value * (value * 6 - 15) + 10)); };

    function territoryProgress(top, height, stageHeight, offset) {
        if (![top, height, stageHeight, offset].every(Number.isFinite) || height <= stageHeight) { return 0; }
        return clamp((offset - top) / (height - stageHeight));
    }

    function territoryFrame(progress, count) {
        var p = clamp(progress);
        count = Math.max(0, Math.floor(Number.isFinite(count) ? count : 0));
        var passage = clamp((p - .25) / .51) * Math.max(0, count - 1);
        var base = Math.floor(passage);
        var t = clamp(((passage - base) - .65) / .35);
        var blend = t * t * (3 - 2 * t);
        var fade = function (value) { value = clamp(value); return value * value * (3 - 2 * value); };
        var outgoing = 1 - fade(t * 2);
        var incoming = fade(t * 2 - 1);
        var active = count ? Math.min(count - 1, base + (blend >= .5 ? 1 : 0)) : -1;
        var slides = Array.from({ length: count }, function (_, n) {
            if (n === base) { return { opacity: outgoing, y: outgoing === 1 ? 0 : -18 * (1 - outgoing) }; }
            if (n === base + 1) { return { opacity: incoming, y: 18 * (1 - incoming) }; }
            return { opacity: 0, y: n < base ? -18 : 18 };
        });
        var intro = Math.max(1 - ease(p / .065), ease((p - .96) / .04));
        var products = ease((p - .20) / .05) * (1 - ease((p - .84) / .055));
        return {
            expand: ease(p / .20) * (1 - ease((p - .89) / .11)),
            intro: intro,
            products: products,
            rail: Math.max(intro, products),
            active: active,
            slides: slides,
            progress: p
        };
    }

    function territoryFocus(frame, count, focus) {
        if (focus === 'intro') {
            return Object.assign({}, frame, { expand: 0, intro: 1, products: 0, rail: 1, active: 0 });
        }
        if (Number.isInteger(focus) && focus >= 0 && focus < count) {
            return Object.assign({}, frame, {
                active: focus, expand: 1, products: 1, intro: 0, rail: 1,
                slides: Array.from({ length: count }, function (_, n) { return { opacity: n === focus ? 1 : 0, y: 0 }; })
            });
        }
        return frame;
    }

    function territoryScroll(win, top) {
        var smoother = win.adbSmoothScroll;
        if (smoother && typeof smoother.scrollTo === 'function') {
            if (typeof smoother.resize === 'function') { smoother.resize(); }
            smoother.scrollTo(top, { immediate: true, force: true });
        } else { win.scrollTo({ top: top, behavior: 'instant' }); }
    }

    function territoryLayout(width, left, right, mirrored) {
        var shift = Math.max(0, width - left - right) * .535;
        return {
            insetLeft: mirrored ? left : left + shift,
            insetRight: mirrored ? right + shift : right,
            introLeft: mirrored ? left + shift : left,
            imageShift: mirrored ? -shift : 0
        };
    }

    function mount(win, doc) {
        var chapters = Array.prototype.map.call(doc.querySelectorAll('[data-territory-chapter]'), function (chapter) {
            return {
                node: chapter, stage: chapter.querySelector('[data-territory-stage]'),
                landscape: chapter.querySelector('[data-territory-landscape]'),
                intro: chapter.querySelector('[data-territory-intro]'),
                rail: chapter.querySelector('[data-territory-rail]'),
                insetLeft: 0, insetRight: 0, imageShift: 0,
                mirrored: chapter.classList.contains('adb-territory-chapter--photo-left'),
                wines: Array.prototype.slice.call(chapter.querySelectorAll('[data-territory-wine]')),
                current: chapter.querySelector('[data-territory-current]'),
                enabled: false, active: -1
            };
        });
        if (!chapters.length || !win.matchMedia) { return; }
        var motion = win.matchMedia('(prefers-reduced-motion: reduce)');
        var desktop = win.matchMedia('(min-width: 1024px) and (min-height: 700px)');
        var offset = 0;
        var pending = false;
        var keyboard = false;

        function expose(node, visible) {
            if (!node) { return; }
            node.inert = !visible;
            if (visible) { node.removeAttribute('aria-hidden'); }
            else { node.setAttribute('aria-hidden', 'true'); }
        }

        function paint() {
            pending = false;
            // Read both geometries before writing styles: no per-card layout loop.
            var frames = chapters.map(function (item) {
                return item.enabled ? territoryFrame(territoryProgress(item.node.getBoundingClientRect().top, item.node.offsetHeight, item.stage.offsetHeight, offset), item.wines.length) : null;
            });
            chapters.forEach(function (item, index) {
                var frame = frames[index];
                if (!frame) { return; }
                // A keyboard user keeps the focused wine until focus leaves it.
                var focused = item.wines.findIndex(function (wine) { return wine.contains(doc.activeElement); });
                var introFocused = item.intro && item.intro.contains(doc.activeElement);
                frame = territoryFocus(frame, item.wines.length, introFocused ? 'intro' : (focused >= 0 ? focused : null));
                var style = item.stage.style;
                style.setProperty('--territory-inset-top', (8 * (1 - frame.expand)).toFixed(3) + '%');
                style.setProperty('--territory-inset-right', (item.insetRight * (1 - frame.expand)).toFixed(2) + 'px');
                style.setProperty('--territory-inset-bottom', (8 * (1 - frame.expand)).toFixed(3) + '%');
                style.setProperty('--territory-inset-left', (item.insetLeft * (1 - frame.expand)).toFixed(2) + 'px');
                style.setProperty('--territory-expand', frame.expand.toFixed(4));
                style.setProperty('--territory-image-x', (item.imageShift * (1 - frame.expand)).toFixed(2) + 'px');
                // Rail changes ink only while its opacity is zero; no mask or paper overlay switches.
                item.node.classList.toggle('is-territory-dark', frame.expand >= .94);
                style.setProperty('--territory-intro', frame.intro.toFixed(4));
                style.setProperty('--territory-products', frame.products.toFixed(4));
                var railFocused = item.rail && item.rail.contains(doc.activeElement);
                style.setProperty('--territory-rail', (railFocused ? 1 : frame.rail).toFixed(4));
                expose(item.rail, frame.rail > .6 || railFocused);
                style.setProperty('--territory-progress', frame.progress.toFixed(4));
                expose(item.intro, frame.intro > .6 || introFocused);
                if (item.active !== frame.active) {
                    item.active = frame.active;
                    item.current.textContent = String(frame.active + 1);
                    item.wines.forEach(function (wine, n) { wine.classList.toggle('is-territory-current', n === frame.active); });
                }
                item.wines.forEach(function (wine, n) {
                    var slide = frame.slides[n];
                    wine.style.setProperty('--territory-wine-opacity', slide.opacity.toFixed(4));
                    wine.style.setProperty('--territory-wine-y', slide.y.toFixed(2) + 'px');
                    wine.classList.toggle('is-territory-visible', slide.opacity > 0);
                    expose(wine, n === frame.active && frame.products * slide.opacity > .6);
                });
            });
        }

        function requestPaint() {
            if (pending || !chapters.some(function (item) { return item.enabled; })) { return; }
            pending = true;
            win.requestAnimationFrame(paint);
        }

        function refresh() {
            var header = doc.querySelector('.adb-header');
            offset = header ? header.offsetHeight + (parseFloat(win.getComputedStyle(header).top) || 0) : 0;
            var viewportWidth = doc.documentElement.clientWidth || win.innerWidth;
            var inner = doc.querySelector('.adb-header__inner') || header;
            var bounds = inner ? inner.getBoundingClientRect() : { left: 0, right: viewportWidth };
            var padding = inner ? win.getComputedStyle(inner) : {};
            var left = Math.max(0, bounds.left + (parseFloat(padding.paddingLeft) || 0));
            var right = Math.max(0, viewportWidth - bounds.right + (parseFloat(padding.paddingRight) || 0));
            chapters.forEach(function (item) {
                item.node.style.setProperty('--territory-gutter-left', left + 'px');
                item.node.style.setProperty('--territory-gutter-right', right + 'px');
                var layout = territoryLayout(viewportWidth, left, right, item.mirrored);
                item.insetLeft = layout.insetLeft;
                item.insetRight = layout.insetRight;
                item.imageShift = layout.imageShift;
                item.node.style.setProperty('--territory-intro-left', layout.introLeft + 'px');
                var ready = desktop.matches && !motion.matches && !keyboard && !!item.landscape && item.wines.length === 5 && 'inert' in item.node;
                item.enabled = ready;
                item.node.classList.toggle('is-territory-ready', ready);
                item.node.classList.toggle('is-territory-enhanced', item.enabled);
                item.node.style.setProperty('--territory-top', offset + 'px');
                if (!item.enabled) {
                    item.stage.removeAttribute('style');
                    item.node.classList.remove('is-territory-dark');
                    expose(item.intro, true);
                    expose(item.rail, true);
                    item.wines.forEach(function (wine) { expose(wine, true); wine.classList.remove('is-territory-current', 'is-territory-visible'); wine.removeAttribute('style'); });
                    item.active = -1;
                }
            });
            paint();
        }

        // Keyboard users receive the complete native list, without extra controls.
        doc.addEventListener('keydown', function (event) {
            if (event.key !== 'Tab' || keyboard) { return; }
            var active = doc.activeElement;
            var preserve = active && active.closest('[data-territory-chapter]');
            var before = preserve ? active.getBoundingClientRect().top : 0;
            keyboard = true;
            refresh();
            territoryScroll(win, win.scrollY + (preserve ? active.getBoundingClientRect().top - before : 0));
        });
        win.addEventListener('scroll', requestPaint, { passive: true });
        doc.addEventListener('focusin', requestPaint);
        doc.addEventListener('focusout', requestPaint);
        win.addEventListener('resize', refresh, { passive: true });
        motion.addEventListener('change', refresh);
        desktop.addEventListener('change', refresh);
        refresh();
    }
    return { territoryFrame: territoryFrame, territoryProgress: territoryProgress, territoryFocus: territoryFocus, territoryScroll: territoryScroll, territoryLayout: territoryLayout, mount: mount };
}));
