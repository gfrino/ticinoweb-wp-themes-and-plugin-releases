<?php
/** Editorial photo framing, stored once on the Media Library attachment. */
defined( 'ABSPATH' ) || exit;

function adb_cellar_framing( $attachment_id ) {
    $saved = get_post_meta( $attachment_id, '_adb_cellar_framing', true );
    $saved = is_array( $saved ) ? $saved : array();
    return array(
        'x' => isset( $saved['x'] ) && is_numeric( $saved['x'] ) ? max( 0, min( 100, (float) $saved['x'] ) ) : 50,
        'y' => isset( $saved['y'] ) && is_numeric( $saved['y'] ) ? max( 0, min( 100, (float) $saved['y'] ) ) : 50,
        'panorama' => ! empty( $saved['panorama'] ),
    );
}

function adb_cellar_frame_style( $attachment_id ) {
    $frame = adb_cellar_framing( $attachment_id );
    $meta = wp_get_attachment_metadata( $attachment_id );
    $source_ratio = max( 1, (int) ( $meta['width'] ?? 1 ) ) / max( 1, (int) ( $meta['height'] ?? 1 ) );
    $ratio = $frame['panorama'] ? max( 1.7, min( 2.5, $source_ratio ) ) : 4 / 3;
    $crop = array( 'x' => min( 1, $ratio / $source_ratio ), 'y' => min( 1, $source_ratio / $ratio ) );
    $position = array();
    foreach ( $crop as $axis => $visible ) {
        $start = max( 0, min( 1 - $visible, $frame[ $axis ] / 100 - $visible / 2 ) );
        $position[ $axis ] = $visible < .9999 ? $start / ( 1 - $visible ) * 100 : 50;
    }
    return sprintf( '--cellar-focal-x:%.3F%%;--cellar-focal-y:%.3F%%;--cellar-photo-ratio:%.5F;', $position['x'], $position['y'], $ratio );
}

function adb_cellar_photo_sizes( $attachment_id ) {
    $frame = adb_cellar_framing( $attachment_id );
    $meta = wp_get_attachment_metadata( $attachment_id );
    $ratio = max( 1, (int) ( $meta['width'] ?? 1 ) ) / max( 1, (int) ( $meta['height'] ?? 1 ) );
    $target = $frame['panorama'] ? max( 1.7, min( 2.5, $ratio ) ) : 4 / 3;
    $factor = max( 1, $ratio / $target );
    return sprintf( '(max-width:650px) %.2Fvw, (max-width:1100px) %.2Fvw, %.2Fvw', 100 * $factor, ( $frame['panorama'] ? 92 : 46 ) * $factor, ( $frame['panorama'] ? 66 : 31 ) * $factor );
}

add_filter( 'wp_get_attachment_image_attributes', function ( $attr ) {
    // Auto-sizes sees the frame width, but cover crops need more source pixels.
    if ( false !== strpos( $attr['class'] ?? '', 'adb-cellar__image' ) && isset( $attr['sizes'] ) ) {
        $attr['sizes'] = preg_replace( '/^auto,\s*/', '', $attr['sizes'] );
    }
    return $attr;
}, 30 );

add_filter( 'wp_content_img_tag', function ( $html ) {
    // The content pipeline can re-add auto after a shortcode has rendered.
    if ( false === strpos( $html, 'adb-cellar__image' ) ) { return $html; }
    $tag = new WP_HTML_Tag_Processor( $html );
    if ( $tag->next_tag( 'IMG' ) ) {
        $sizes = $tag->get_attribute( 'sizes' );
        if ( is_string( $sizes ) ) { $tag->set_attribute( 'sizes', preg_replace( '/^auto,\s*/', '', $sizes ) ); }
    }
    return $tag->get_updated_html();
}, 30 );

add_filter( 'attachment_fields_to_edit', function ( $fields, $post ) {
    if ( ! wp_attachment_is_image( $post->ID ) ) { return $fields; }
    $frame = adb_cellar_framing( $post->ID );
    foreach ( array( 'x' => __( 'Centro orizzontale', 'amicidibacco' ), 'y' => __( 'Centro verticale', 'amicidibacco' ) ) as $axis => $label ) {
        $fields[ 'adb_cellar_' . $axis ] = array(
            'label' => $label, 'input' => 'html',
            'html' => '<input type="number" min="0" max="100" step="1" name="attachments[' . absint( $post->ID ) . '][adb_cellar_' . esc_attr( $axis ) . ']" value="' . esc_attr( round( $frame[ $axis ] ) ) . '" aria-label="' . esc_attr( $label ) . '">',
            'helps' => 'x' === $axis ? __( 'Ritaglio cantine: 0 = sinistra, 50 = centro, 100 = destra.', 'amicidibacco' ) : __( 'Ritaglio cantine: 0 = alto, 50 = centro, 100 = basso.', 'amicidibacco' ),
        );
    }
    $fields['adb_cellar_panorama'] = array(
        'label' => __( 'Foto panoramica', 'amicidibacco' ), 'input' => 'html',
        'html' => '<input type="hidden" name="attachments[' . absint( $post->ID ) . '][adb_cellar_panorama]" value="0"><label><input type="checkbox" name="attachments[' . absint( $post->ID ) . '][adb_cellar_panorama]" value="1" ' . checked( $frame['panorama'], true, false ) . '> ' . esc_html__( 'Conserva i soggetti ai bordi su una scheda più ampia.', 'amicidibacco' ) . '</label>',
    );
    return $fields;
}, 10, 2 );

// The native media form checks its own nonce; enforce attachment permissions as well.
add_filter( 'attachment_fields_to_save', function ( $post, $attachment ) {
    $id = absint( $post['ID'] ?? 0 );
    if ( ! $id || ! current_user_can( 'edit_post', $id ) || ! wp_attachment_is_image( $id ) ) { return $post; }
    $frame = adb_cellar_framing( $id ); $changed = false;
    foreach ( array( 'x', 'y' ) as $axis ) {
        $key = 'adb_cellar_' . $axis;
        if ( isset( $attachment[ $key ] ) && is_numeric( $attachment[ $key ] ) ) { $frame[ $axis ] = max( 0, min( 100, (float) $attachment[ $key ] ) ); $changed = true; }
    }
    if ( isset( $attachment['adb_cellar_panorama'] ) ) { $frame['panorama'] = '1' === (string) $attachment['adb_cellar_panorama']; $changed = true; }
    if ( $changed ) { update_post_meta( $id, '_adb_cellar_framing', $frame ); }
    return $post;
}, 10, 2 );
