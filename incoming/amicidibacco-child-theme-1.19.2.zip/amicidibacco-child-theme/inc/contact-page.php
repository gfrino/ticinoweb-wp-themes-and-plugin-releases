<?php
/** Contact information has one owner: the parent CMS. */
defined( 'ABSPATH' ) || exit;

function adb_is_contact_page() {
    $mapping = get_option( 'ticinoweb_page_mapping', array() );
    return is_page_template( 'page-contatti.php' ) || ( ! empty( $mapping['page_contatti'] ) && is_page( absint( $mapping['page_contatti'] ) ) );
}

add_filter( 'template_include', function ( $template ) {
    return adb_is_contact_page() ? get_stylesheet_directory() . '/page-contatti.php' : $template;
}, 50 );

function adb_contact_phones( $contact ) {
    $phones = array();
    foreach ( array( 'phone', 'phone_landline', 'phone_mobile' ) as $key ) {
        $number = preg_replace( '/[^+0-9]/', '', (string) ( $contact[ $key ] ?? '' ) );
        if ( ! preg_match( '/^\+?\d{5,15}$/', $number ) || isset( $phones[ $number ] ) ) { continue; }
        $display = 'phone' === $key && ! empty( $contact['phone_display'] ) ? $contact['phone_display'] : ( $contact[ $key ] ?? '' );
        if ( $display === $number && preg_match( '/^\+41(\d{2})(\d{3})(\d{2})(\d{2})$/', $number, $parts ) ) { $display = '+41 ' . implode( ' ', array_slice( $parts, 1 ) ); }
        $phones[ $number ] = $display;
    }
    return $phones;
}

function adb_contact_map_url( $address, $saved = '' ) {
    $address = preg_replace( '/\s+/u', ' ', trim( $address ) );
    $saved = esc_url_raw( (string) $saved, array( 'https', 'http' ) );
    return $saved ?: ( trim( $address ) ? 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( trim( $address ) ) : '' );
}
