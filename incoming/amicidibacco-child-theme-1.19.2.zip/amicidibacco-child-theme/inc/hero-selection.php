<?php
/** Read-only WooCommerce wine candidates for the opening scene. */
defined( 'ABSPATH' ) || exit;

/** Stable identity across products sharing a wine name and winery. */
function adb_hero_wine_group( $product ) {
    return sanitize_title( $product->get_name() ) . '|' . sanitize_title( $product->get_attribute( 'pa_cantina' ) );
}

/** Keep only genuine, available single wines with a native packshot attachment. */
function adb_hero_wine_eligible( $product ) {
    if ( ! $product instanceof WC_Product || 'publish' !== $product->get_status() || ! $product->is_visible() || ! $product->is_in_stock() || '' === $product->get_price() ) { return false; }
    if ( 'VINO SINGOLO' !== get_post_meta( $product->get_id(), 'tipo_di_prodotto', true ) ) { return false; }
    $image_id = $product->get_image_id();
    return $image_id > 0 && in_array( get_post_mime_type( $image_id ), array( 'image/png', 'image/webp' ), true );
}

/**
 * Return up to 24 WC_Product objects from at most 60 random Italian candidates.
 * The browser selects five from this cache-safe pool on each opening. Editorial
 * IDs are retained only as an empty-pool fallback; no catalog data is modified.
 */
function adb_hero_wine_pool( $fallback_ids = array() ) {
    if ( ! function_exists( 'wc_get_product' ) ) { return array(); }
    $query = array(
        'post_type' => 'product',
        'post_status' => 'publish',
        'posts_per_page' => 60,
        'orderby' => 'rand',
        'no_found_rows' => true,
        'ignore_sticky_posts' => true,
        'suppress_filters' => false,
        'adb_language' => 'it',
        'update_post_meta_cache' => true,
        'update_post_term_cache' => true,
        'meta_query' => array(
            array( 'key' => 'tipo_di_prodotto', 'value' => 'VINO SINGOLO', 'compare' => '=' ),
            array( 'key' => '_thumbnail_id', 'value' => 0, 'compare' => '>', 'type' => 'NUMERIC' ),
        ),
    );
    if ( function_exists( 'wc_get_product_visibility_term_ids' ) ) {
        $visibility = wc_get_product_visibility_term_ids();
        if ( ! empty( $visibility['exclude-from-catalog'] ) ) {
            $query['tax_query'] = array( array( 'taxonomy' => 'product_visibility', 'field' => 'term_taxonomy_id', 'terms' => array( $visibility['exclude-from-catalog'] ), 'operator' => 'NOT IN' ) );
        }
    }
    // get_posts primes product posts, metadata and object-term relationships.
    $posts = get_posts( $query );
    if ( function_exists( 'wp_prime_option_caches' ) && ! wp_using_ext_object_cache() ) {
        $options = array();
        foreach ( $posts as $post ) {
            foreach ( array( 'wc_var_prices_', 'wc_product_children_', 'wc_child_has_weight_', 'wc_child_has_dimensions_', 'wc_related_' ) as $transient ) {
                $options[] = '_transient_' . $transient . $post->ID;
                $options[] = '_transient_timeout_' . $transient . $post->ID;
            }
        }
        if ( $options ) { wp_prime_option_caches( $options ); }
    }
    $images = array_values( array_unique( array_filter( array_map( 'get_post_thumbnail_id', $posts ) ) ) );
    if ( $images ) { _prime_post_caches( $images, false, true ); }
    $pool = array();
    foreach ( $posts as $post ) {
        $product = wc_get_product( $post->ID );
        if ( adb_hero_wine_eligible( $product ) ) { $pool[] = $product; }
        if ( count( $pool ) >= 24 ) { break; }
    }
    if ( ! $pool ) {
        $ids = array_slice( wp_parse_id_list( $fallback_ids ), 0, 24 );
        $pool = array_values( array_filter( adb_products( array( 'ids' => $ids, 'limit' => 24 ) ), 'adb_hero_wine_eligible' ) );
    }
    return $pool;
}
