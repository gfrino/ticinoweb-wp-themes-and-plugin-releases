<?php
/** Small compatibility layer for retired CMS pages; no global routing changes. */
defined('ABSPATH') || exit;

/** Native WooCommerce emails inherit the CMS logo if no email-specific image is set. */
function adb_email_logo($image) {
    if ($image || !function_exists('ticinoweb_get_site_logo')) { return $image; }
    return ticinoweb_get_site_logo() ?: $image;
}
add_filter('option_woocommerce_email_header_image', 'adb_email_logo');
add_filter('default_option_woocommerce_email_header_image', 'adb_email_logo');

/** Let WooCommerce own Product schema; a catalog sheet is not a news article. */
add_filter('ticinoweb_seo_jsonld_article_schema', static function ($schema, $post) {
    if (!in_array($post->post_type, ['product', 'produttore'], true)) { return $schema; }
    $url = get_permalink($post);
    return ['@context'=>'https://schema.org', '@type'=>'WebPage', '@id'=>$url . '#webpage', 'url'=>$url, 'name'=>wp_strip_all_tags(get_the_title($post))];
}, 20, 2);

function adb_legacy_page_target($page_id) {
    $redirects = get_option('adb_legacy_redirects', []);
    if (!is_array($redirects)) { return 0; }
    $target = $redirects[absint($page_id)] ?? 0;
    if (!is_scalar($target)) { return 0; }
    $target = absint($target);
    if (!$target || $target === absint($page_id) || isset($redirects[$target])) { return 0; }
    return 'page' === get_post_type($target) && 'publish' === get_post_status($target) ? $target : 0;
}

function adb_legacy_page_url($page_id) {
    $target = adb_legacy_page_target($page_id);
    if (!$target) { return ''; }
    $url = get_permalink($target);
    // Existing payment, receipt and account links must keep their native endpoint and key.
    $endpoint = function_exists('WC') && WC()->query ? WC()->query->get_current_endpoint() : '';
    if ($endpoint) { $url = wc_get_endpoint_url($endpoint, get_query_var($endpoint), $url); }
    $allowed = array_merge(['s', 'post_type', 'orderby', 'key', 'pay_for_order', 'login', 'show-reset-form', 'id', 'adb_min_price', 'adb_max_price'], array_column(adb_catalog_filter_definitions(), 'param'));
    $query = [];
    foreach ($allowed as $key) {
        if (isset($_GET[$key]) && is_scalar($_GET[$key])) { $query[$key] = sanitize_text_field(substr(wp_unslash((string) $_GET[$key]), 0, 512)); }
    }
    return add_query_arg($query, $url);
}

add_action('template_redirect', static function () {
    $object = get_queried_object();
    if (is_admin() || !$object instanceof WP_Post || 'page' !== $object->post_type || (!is_page() && !is_404()) || is_preview() || !in_array($_SERVER['REQUEST_METHOD'] ?? 'GET', ['GET', 'HEAD'], true)) { return; }
    $url = adb_legacy_page_url(get_queried_object_id());
    if ($url && wp_safe_redirect($url, 301, 'Amici di Bacco')) { exit; }
}, 5);
