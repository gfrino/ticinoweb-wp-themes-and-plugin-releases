<?php
/** Client-only secret game; catalog data remains owned by WooCommerce. */
defined('ABSPATH') || exit;

function adb_vineyard_wine() {
    $key = 'adb_vigna_' . substr(adb_search_rate_key(), -32);
    $bucket = get_transient($key);
    if (!is_array($bucket) || ($bucket['until'] ?? 0) <= time()) { $bucket = ['count' => 0, 'until' => time() + 60]; }
    if ($bucket['count'] >= 10) { return new WP_Error('adb_vigna_limit', __('Attendi un momento e riprova.', 'amicidibacco'), ['status' => 429]); }
    $bucket['count']++;
    set_transient($key, $bucket, max(1, $bucket['until'] - time()));
    $pool = adb_hero_wine_pool();
    $product = $pool ? $pool[wp_rand(0, count($pool) - 1)] : null;
    $item = null;
    if ($product) {
        $item = ['name' => wp_strip_all_tags($product->get_name()), 'winery' => wp_strip_all_tags($product->get_attribute('pa_cantina')),
            'url' => $product->get_permalink(), 'image' => wp_get_attachment_image_url($product->get_image_id(), 'woocommerce_thumbnail'),
            'price' => wp_kses($product->get_price_html(), ['span' => ['class' => true, 'aria-hidden' => true], 'bdi' => [], 'del' => ['aria-hidden' => true], 'ins' => ['aria-hidden' => true], 'small' => ['class' => true]])];
    }
    $response = new WP_REST_Response(['wine' => $item, 'catalog' => adb_catalog_url()]);
    $response->header('Cache-Control', 'no-store, max-age=0');
    return $response;
}
add_action('rest_api_init', static function () {
    register_rest_route('amicidibacco/v1', '/vineyard-wine', ['methods' => WP_REST_Server::READABLE, 'permission_callback' => '__return_true', 'callback' => 'adb_vineyard_wine']);
});

add_action('wp_enqueue_scripts', static function () {
    $base = get_stylesheet_directory_uri();
    wp_enqueue_script('adb-vigna-loader', $base . '/assets/js/vigna-loader.js', ['adb-search'], ADB_VERSION, true);
    wp_localize_script('adb-vigna-loader', 'adbVigna', [
        'module' => $base . '/assets/js/vigna-game.mjs?ver=' . ADB_VERSION, 'css' => $base . '/assets/css/vigna.css?ver=' . ADB_VERSION,
        'wineEndpoint' => rest_url('amicidibacco/v1/vineyard-wine'), 'catalog' => adb_catalog_url(), 'brand' => get_bloginfo('name'),
        'artwork' => ['wood' => $base . '/assets/images/harvest/wood.webp?ver=' . ADB_VERSION, 'full' => $base . '/assets/images/harvest/full.webp?ver=' . ADB_VERSION, 'grapes' => $base . '/assets/images/harvest/grapes.webp?ver=' . ADB_VERSION, 'basket' => $base . '/assets/images/harvest/basket.webp?ver=' . ADB_VERSION, 'bottle' => $base . '/assets/images/harvest/bottle.webp?ver=' . ADB_VERSION],
        'strings' => [
            'loading' => __('La vendemmia sta per cominciare…', 'amicidibacco'),
            'failure' => __('Il gioco non si è caricato. Esci e scrivi di nuovo BACCO per riprovare.', 'amicidibacco'),
            'phases' => [__('Tra i filari', 'amicidibacco'), __('Si alza il vento', 'amicidibacco'), __('L’ora dorata', 'amicidibacco')],
            'phaseNotes' => [__('Cerca il centro del cestino.', 'amicidibacco'), __('Segui la traiettoria dei grappoli.', 'amicidibacco'), __('Gli ultimi grappoli possono cambiare tutto.', 'amicidibacco')],
            'perfect' => __('Raccolta perfetta', 'amicidibacco'), 'ripe' => __('Uva matura', 'amicidibacco'), 'green' => __('Uva acerba', 'amicidibacco'), 'gold' => __('Grappolo dorato', 'amicidibacco'),
            'win' => __('Una vendemmia da ricordare.', 'amicidibacco'), 'lose' => __('La sera è arrivata.', 'amicidibacco'),
            'winText' => __('Hai raggiunto l’obiettivo. Questa è la tua bottiglia virtuale, nata dalla partita appena giocata.', 'amicidibacco'),
            'loseText' => __('Questa è la tua bottiglia virtuale. Per vincere servono almeno 28 grappoli maturi e l’80% di qualità. La prossima vendemmia può essere quella giusta.', 'amicidibacco'),
            'score' => __('Punti', 'amicidibacco'), 'quality' => __('Qualità', 'amicidibacco'), 'best' => __('Il tuo record', 'amicidibacco'), 'newBest' => __('Nuovo record personale', 'amicidibacco'),
            'labels' => [__('Primo filare', 'amicidibacco'), __('Filare segreto', 'amicidibacco'), __('Luce d’oro', 'amicidibacco')],
            'virtual' => __('Vendemmia virtuale', 'amicidibacco'), 'gameLabel' => __('Etichetta di gioco · non in vendita', 'amicidibacco'),
            'normalIntro' => __('Un minuto prima che scenda la sera. Raccogli almeno 28 grappoli maturi e mantieni la qualità all’80%.', 'amicidibacco'),
            'calmIntro' => __('Raccogli almeno 28 grappoli maturi e mantieni la qualità all’80%. Il ritmo è più lento e la sera può aspettare.', 'amicidibacco'),
            'calm' => __('Senza fretta', 'amicidibacco'), 'saved' => __('Etichetta pronta da salvare.', 'amicidibacco'),
            'discover' => __('Continua la scoperta in enoteca', 'amicidibacco'), 'wineIntro' => __('Dalla vendemmia virtuale alle bottiglie vere.', 'amicidibacco'),
            'resumed' => __('La vendemmia riprende.', 'amicidibacco'), 'paused' => __('Partita in pausa.', 'amicidibacco'), 'started' => __('La vendemmia è iniziata. Muovi il cestino e raccogli i grappoli maturi.', 'amicidibacco'),
            'fallback' => __('Grafica leggera attiva. Regole e comandi restano gli stessi.', 'amicidibacco'),
            'ripeCount' => __('Grappoli maturi raccolti', 'amicidibacco'), 'catchCount' => __('%d grappoli maturi raccolti.', 'amicidibacco'),
        ],
    ]);
}, 35);
add_action('wp_footer', static function () { ?>
<dialog class="adb-vigna" data-vigna aria-labelledby="adb-vigna-title" aria-describedby="adb-vigna-description" data-screen="ready">
    <div class="harvest-backdrop" aria-hidden="true"><?php $background = wp_get_attachment_image_url(absint(adb_home('intro_image_id') ?: adb_home('hero_image_id')), 'full'); if ($background) : ?><img src="<?php echo esc_url($background); ?>" alt="" loading="lazy" decoding="async"><?php endif; ?></div>
    <div class="vigna-world" data-vigna-world tabindex="0" role="group" aria-label="<?php esc_attr_e('Area di gioco. Muovi il cestino con il mouse, un dito o le frecce della tastiera.', 'amicidibacco'); ?>"></div>
    <div class="vigna-shade" aria-hidden="true"></div>
    <header class="vigna-header"><span class="vigna-signature"><?php echo esc_html(get_bloginfo('name')); ?></span><div class="vigna-header-actions"><button type="button" data-harvest-pause hidden><?php echo adb_icon('pause'); ?><span><?php esc_html_e('Pausa', 'amicidibacco'); ?></span></button><button type="button" class="vigna-exit" data-vigna-exit><?php esc_html_e('Esci', 'amicidibacco'); ?><?php echo adb_icon('close'); ?></button></div></header>
    <section class="vigna-intro" data-harvest-intro>
        <h2 id="adb-vigna-title"><?php esc_html_e('L’ultima', 'amicidibacco'); ?><em><?php esc_html_e('vendemmia.', 'amicidibacco'); ?></em></h2>
        <p id="adb-vigna-description"><?php esc_html_e('Un minuto prima che scenda la sera. Raccogli almeno 28 grappoli maturi e mantieni la qualità all’80%.', 'amicidibacco'); ?></p>
        <div class="harvest-legend" aria-label="<?php esc_attr_e('I grappoli della partita', 'amicidibacco'); ?>"><span><i class="is-ripe" aria-hidden="true"></i><?php esc_html_e('Maturi: raccogli', 'amicidibacco'); ?></span><span><i class="is-green" aria-hidden="true"></i><?php esc_html_e('Acerbi: evita', 'amicidibacco'); ?></span><span><i class="is-gold" aria-hidden="true"></i><?php esc_html_e('Dorati: più punti', 'amicidibacco'); ?></span></div>
        <p class="harvest-guidance"><?php esc_html_e('Muovi il cestino con il mouse, un dito o le frecce. Punta al centro per una raccolta perfetta e accumula combinazioni.', 'amicidibacco'); ?></p>
        <button type="button" class="harvest-primary" data-harvest-start disabled><?php esc_html_e('Inizia la vendemmia', 'amicidibacco'); ?><?php echo adb_icon(); ?></button>
        <label class="harvest-calm"><input type="checkbox" data-harvest-calm><span><?php esc_html_e('Senza fretta', 'amicidibacco'); ?><small><?php esc_html_e('Ritmo più lento, senza conto alla rovescia.', 'amicidibacco'); ?></small></span></label>
    </section>
    <div class="vigna-loading" data-vigna-loading role="status"><?php esc_html_e('La vendemmia sta per cominciare…', 'amicidibacco'); ?></div>
    <div class="harvest-hud" data-harvest-hud hidden aria-live="off"><div><span><?php esc_html_e('Raccolta', 'amicidibacco'); ?></span><strong data-harvest-count>0<small>/28</small></strong></div><div><span><?php esc_html_e('Qualità', 'amicidibacco'); ?></span><strong data-harvest-quality>100<small>%</small></strong></div><div class="harvest-time"><span data-harvest-time-label><?php esc_html_e('Alla sera', 'amicidibacco'); ?></span><strong data-harvest-time>60<small>s</small></strong></div></div>
    <div class="harvest-chapter" data-harvest-chapter hidden><strong data-harvest-phase></strong><span data-harvest-phase-note></span></div>
    <div class="harvest-score" data-harvest-score-wrap hidden><span><?php esc_html_e('Punti', 'amicidibacco'); ?></span><strong data-harvest-score>0</strong><small data-harvest-combo></small></div>
    <div class="harvest-feedback" data-harvest-feedback aria-hidden="true"></div>
    <label class="harvest-steer" data-harvest-steer-wrap hidden><span><?php esc_html_e('Muovi il cestino', 'amicidibacco'); ?></span><input data-harvest-steer type="range" min="-92" max="92" step="1" value="0" aria-label="<?php esc_attr_e('Posizione del cestino', 'amicidibacco'); ?>"></label>
    <section class="harvest-pause" data-harvest-pause-panel hidden aria-labelledby="harvest-pause-title"><h3 id="harvest-pause-title"><?php esc_html_e('La sera può aspettare.', 'amicidibacco'); ?></h3><p><?php esc_html_e('Prenditi il tuo tempo. La vendemmia riparte da dove l’hai lasciata.', 'amicidibacco'); ?></p><button class="harvest-primary" type="button" data-harvest-resume><?php esc_html_e('Riprendi la partita', 'amicidibacco'); ?><?php echo adb_icon(); ?></button></section>
    <section class="harvest-result" data-harvest-result hidden aria-labelledby="harvest-result-title"><h3 id="harvest-result-title" data-harvest-result-title tabindex="-1"></h3><p data-harvest-result-text></p><div class="harvest-result-stats"><div><span><?php esc_html_e('Punti', 'amicidibacco'); ?></span><strong data-harvest-result-score></strong></div><div><span><?php esc_html_e('Qualità', 'amicidibacco'); ?></span><strong data-harvest-result-quality></strong></div><div><span><?php esc_html_e('Raccolti', 'amicidibacco'); ?></span><strong data-harvest-result-count></strong></div></div><p class="harvest-best" data-harvest-best></p><div class="harvest-result-actions"><button class="harvest-primary" type="button" data-harvest-replay><?php esc_html_e('Gioca ancora', 'amicidibacco'); ?><?php echo adb_icon(); ?></button><button type="button" class="harvest-save" data-harvest-save><?php esc_html_e('Salva l’etichetta', 'amicidibacco'); ?></button></div><div class="harvest-wine" data-harvest-wine></div></section>
    <p class="screen-reader-text" data-harvest-status role="status" aria-live="polite"></p>
</dialog>
<?php }, 10);
