<?php defined('ABSPATH') || exit; get_header(); ?>
<main id="main-content" class="adb-cellars-page"><?php echo adb_render_winery_directory(); ?></main>
<?php get_footer(); ?>
