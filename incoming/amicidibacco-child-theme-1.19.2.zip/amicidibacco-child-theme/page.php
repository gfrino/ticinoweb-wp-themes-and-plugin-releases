<?php defined('ABSPATH') || exit; get_header(); if (adb_is_selection_page() || adb_is_offers_page()) : ?>
<main id="main-content" class="adb-page adb-wrap adb-collections-page"><?php while (have_posts()) : the_post(); the_content(); endwhile; ?></main>
<?php elseif (adb_is_story_page()) : ?>
<main id="main-content" class="adb-story-page"><?php while (have_posts()) : the_post(); echo adb_render_story(); endwhile; ?></main>
<?php elseif (adb_is_winery_directory()) : ?>
<main id="main-content" class="adb-cellars-page"><?php while (have_posts()) : the_post(); the_content(); endwhile; ?></main>
<?php else : ?>
<main id="main-content" class="adb-page adb-wrap"><?php while (have_posts()) : the_post(); ?><header class="adb-page__heading"><h1><?php the_title(); ?></h1></header><div class="adb-page__content"><?php the_content(); ?></div><?php endwhile; ?></main>
<?php endif; ?>
<?php get_footer(); ?>
