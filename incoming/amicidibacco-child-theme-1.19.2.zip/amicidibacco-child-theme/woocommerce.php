<?php defined('ABSPATH') || exit; get_header(); ?>
<main id="main-content" class="adb-commerce adb-wrap">
<?php if (is_product()) { woocommerce_breadcrumb(); } ?>
<?php if (!is_product()) : ?>
    <header class="adb-catalog-heading"><p class="adb-kicker"><?php echo esc_html(get_bloginfo('name')); ?></p><h1><?php woocommerce_page_title(); ?></h1><p><?php echo esc_html(get_post_field('post_excerpt', wc_get_page_id('shop'))); ?></p></header>
    <?php adb_shop_filter_form(); ?>
<?php endif; ?>
<?php woocommerce_content(); ?>
</main>
<?php get_footer(); ?>
