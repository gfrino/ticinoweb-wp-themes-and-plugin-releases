(() => {
 'use strict';
 const root=document.querySelector('[data-projects]');
 if(!root || typeof HTMLDialogElement==='undefined' || !HTMLDialogElement.prototype.showModal)return;
 let sheet=null,returnTo=null,photoReturn=null,photos=[],photoIndex=0;
 const lightbox=root.querySelector('[data-project-lightbox]');
 const full=lightbox.querySelector('[data-full-photo]');
 const lock=()=>document.documentElement.classList.toggle('project-overlay-open',!!sheet?.open||lightbox.open);
 root.querySelectorAll('[data-project-sheet]').forEach(section=>{
  const dialog=document.createElement('dialog');
  [...section.attributes].forEach(attr=>dialog.setAttribute(attr.name,attr.value));
  dialog.append(...section.childNodes);section.replaceWith(dialog);
  dialog.addEventListener('close',()=>{sheet=null;lock();returnTo?.focus({preventScroll:true});});
  dialog.addEventListener('click',event=>{if(event.target===dialog){const r=dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)dialog.close();}});
 });
 const showPhoto=index=>{
  photoIndex=(index+photos.length)%photos.length;
  const item=photos[photoIndex],thumb=item.querySelector('img');
  full.alt=thumb?.alt||'';full.src=item.href;
  lightbox.querySelector('[data-photo-count]').textContent=`${photoIndex+1} / ${photos.length}`;
  lightbox.querySelector('[data-photo-caption]').textContent=item.dataset.caption||'';
  lightbox.querySelectorAll('[data-photo-prev],[data-photo-next]').forEach(button=>button.hidden=photos.length<2);
 };
 root.addEventListener('click',event=>{
  const opener=event.target.closest('[data-open-project]');
  if(opener){event.preventDefault();returnTo=opener;sheet=document.getElementById(opener.dataset.openProject);sheet.showModal();sheet.scrollTop=0;lock();return;}
  if(event.target.closest('[data-close-project]')){sheet?.close();return;}
  const photo=event.target.closest('[data-project-photo]');
  if(photo){event.preventDefault();photoReturn=photo;photos=[...photo.closest('[data-project-sheet]').querySelectorAll('[data-project-photo]')];showPhoto(photos.indexOf(photo));lightbox.showModal();lock();return;}
  if(event.target.closest('[data-close-photo]'))lightbox.close();
  if(event.target.closest('[data-photo-prev]'))showPhoto(photoIndex-1);
  if(event.target.closest('[data-photo-next]'))showPhoto(photoIndex+1);
 });
 lightbox.addEventListener('keydown',event=>{
  if(event.key==='ArrowRight'||event.key==='ArrowLeft'){event.preventDefault();showPhoto(photoIndex+(event.key==='ArrowRight'?1:-1));}
 });
 lightbox.addEventListener('click',event=>{if(event.target===lightbox)lightbox.close();});
 lightbox.addEventListener('close',()=>{full.removeAttribute('src');lock();photoReturn?.focus({preventScroll:true});});
 // Native dialogs provide focus containment and Escape; nested lightbox closes first.
})();
