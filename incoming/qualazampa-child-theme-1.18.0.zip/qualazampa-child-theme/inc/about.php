<?php
/** Page presentation; team registration and galleries are owned by the parent CMS. */
defined('ABSPATH') || exit;

function qz_about_id(){return absint(((array)get_option('ticinoweb_page_mapping',[]))['page_chi_siamo']??0);}
function qz_is_about(){
    $id=absint(apply_filters('wpml_object_id',qz_about_id(),'page',true));
    return $id&&is_page($id);
}
function qz_about_data(){return (array)get_post_meta(qz_about_id(),'_qz_about',true);}
function qz_about_text($key){
    $value=(string)(qz_about_data()[$key]??'');
    return function_exists('ticinoweb_frontend_text')?ticinoweb_frontend_text($value,'qz:about:'.$key):$value;
}
add_filter('template_include',static function($template){return qz_is_about()?get_stylesheet_directory().'/page-chi-siamo.php':$template;});

function qz_about_fields(){return [
    'team_title'=>__('Titolo del team','qualazampa'),
    'team_text'=>__('Introduzione del team','qualazampa'),
    'loyalty_title'=>__('Titolo tessera fedeltà','qualazampa'),
    'loyalty_text'=>__('Come funziona la tessera','qualazampa'),
    'gallery_title'=>__('Titolo galleria','qualazampa'),
    'gallery_text'=>__('Introduzione galleria','qualazampa'),
];}
function qz_about_gallery(){
    $term=absint(qz_about_data()['gallery_id']??0);
    if(!$term||!term_exists($term,'ticinoweb_media_gallery'))return [];
    $order=array_values(array_filter(array_map('absint',(array)get_term_meta($term,'_ticinoweb_gallery_order',true))));
    $ids=get_posts(['post_type'=>'attachment','post_status'=>'inherit','post_mime_type'=>'image','fields'=>'ids','posts_per_page'=>24,'orderby'=>'ID','order'=>'ASC','no_found_rows'=>true,'tax_query'=>[['taxonomy'=>'ticinoweb_media_gallery','field'=>'term_id','terms'=>$term]]]);
    $rank=array_flip($order);
    usort($ids,static fn($a,$b)=>($rank[$a]??100000+$a)<=>($rank[$b]??100000+$b));
    return $ids;
}
function qz_about_team(){return post_type_exists('qz_team')?get_posts(['post_type'=>'qz_team','posts_per_page'=>12,'post_status'=>'publish','orderby'=>['menu_order'=>'ASC','ID'=>'ASC'],'no_found_rows'=>true]):[];}

add_action('init',static function(){
    if(!post_type_exists('qz_team'))return;
    remove_post_type_support('qz_team','editor');
    remove_post_type_support('qz_team','custom-fields');
},20);
add_action('add_meta_boxes_qz_team',static function(){
    remove_meta_box('postexcerpt','qz_team','normal');
    add_meta_box('postexcerpt',__('Breve presentazione (facoltativa)','qualazampa'),'post_excerpt_meta_box','qz_team','normal','high');
    add_meta_box('qz-team-guide',__('La persona nella pagina Chi siamo','qualazampa'),static function(){
        echo '<p>'.esc_html__('Scegli la foto in evidenza e usa il titolo per riconoscere la persona. Compilando la breve presentazione, anche il titolo e il testo compariranno sotto la foto. Lasciandola vuota, viene mostrato soltanto il ritratto. Il campo Ordinamento stabilisce la posizione: prima i numeri più piccoli.','qualazampa').'</p>';
    },'qz_team','normal','high');
});

// Keep the parent's configurable CPT as the sole team owner; this only places its editor in the CMS.
add_action('admin_menu',static function(){
    if(post_type_exists('qz_team')){
        remove_menu_page('edit.php?post_type=qz_team');
        add_submenu_page('ticinoweb-cms',__('Il team','qualazampa'),__('Il team','qualazampa'),'edit_posts','edit.php?post_type=qz_team');
    }
    if(qz_about_id())add_submenu_page('ticinoweb-cms',__('Pagina Chi siamo','qualazampa'),__('Pagina Chi siamo','qualazampa'),'edit_pages','post.php?post='.qz_about_id().'&action=edit');
},100);
add_filter('parent_file',static function($parent){global $typenow;return $typenow==='qz_team'?'ticinoweb-cms':$parent;});
add_filter('manage_qz_team_posts_columns',static function($columns){$columns['qz_portrait']=__('Foto','qualazampa');return $columns;});
add_action('manage_qz_team_posts_custom_column',static function($column,$id){if($column==='qz_portrait')echo get_the_post_thumbnail($id,[64,80]);},10,2);
add_filter('use_block_editor_for_post',static function($use,$post){return (int)$post->ID===qz_about_id()?false:$use;},20,2);
add_filter('tiny_mce_before_init',static function($settings){
    global $post;if($post&&(int)$post->ID===qz_about_id())$settings['content_style']=($settings['content_style']??'').'body{font-family:system-ui,sans-serif;font-size:16px;line-height:1.65;max-width:760px;margin:16px 20px}';
    return $settings;
});
add_filter('admin_body_class',static function($classes){global $post;return $post&&get_current_screen()->base==='post'&&(int)$post->ID===qz_about_id()?$classes.' qz-about-editor':$classes;});
add_action('admin_enqueue_scripts',static function($hook){
    global $post;if($hook!=='post.php'||!$post||(int)$post->ID!==qz_about_id())return;
    wp_enqueue_style('qz-about-editor',get_stylesheet_directory_uri().'/assets/css/about-editor.css',[],qz_asset_version('assets/css/about-editor.css'));
    wp_enqueue_script('qz-about-editor',get_stylesheet_directory_uri().'/assets/js/about-editor.js',[],qz_asset_version('assets/js/about-editor.js'),true);
});
add_action('edit_form_top',static function($post){
    if((int)$post->ID!==qz_about_id())return;
    echo '<div class="qz-about-guide"><div><h2>'.esc_html__('Gestisci la pagina Chi siamo','qualazampa').'</h2><p>'.esc_html__('La storia si modifica qui sotto. Team, tessera e galleria hanno ciascuno il proprio pannello. Premi Aggiorna per salvare le modifiche.','qualazampa').'</p><nav aria-label="'.esc_attr__('Sezioni della pagina','qualazampa').'">';
    foreach(['postdivrich'=>__('Storia','qualazampa'),'qz-about-team'=>__('Il team','qualazampa'),'qz-about-loyalty'=>__('Tessera fedeltà','qualazampa'),'qz-about-gallery'=>__('Galleria','qualazampa')] as $id=>$label)echo '<a href="#'.esc_attr($id).'">'.esc_html($label).'</a>';
    echo '</nav></div><a class="button" target="_blank" rel="noopener" href="'.esc_url(get_permalink($post)).'">'.esc_html__('Apri la pagina','qualazampa').'</a></div>';
});
add_action('edit_form_after_title',static function($post){if((int)$post->ID===qz_about_id())echo '<p class="qz-about-story-help">'.esc_html__('Il titolo qui sopra e il testo qui sotto compongono la sezione dedicata alla storia del negozio.','qualazampa').'</p>';});
add_action('add_meta_boxes_page',static function($post){
    if((int)$post->ID!==qz_about_id())return;
    // Opening imagery belongs to the parent CMS, not the unused page thumbnail.
    remove_meta_box('postimagediv','page','side');
    remove_meta_box('pageparentdiv','page','side');
    add_meta_box('qz-about-presentation',__('Presentazione iniziale','qualazampa'),'qz_about_presentation_box','page','side','default');
    add_meta_box('qz-about-team',__('Il team','qualazampa'),'qz_about_team_box','page','normal','high');
    add_meta_box('qz-about-loyalty',__('Tessera fedeltà','qualazampa'),'qz_about_loyalty_box','page','normal','high');
    add_meta_box('qz-about-gallery',__('Galleria del negozio','qualazampa'),'qz_about_gallery_box','page','normal','high');
},30);
function qz_about_editor_field($key,$rows=2){
    $labels=qz_about_fields();$data=qz_about_data();
    echo '<div class="qz-about-field"><label for="qz-about-'.esc_attr($key).'">'.esc_html($labels[$key]).'</label><textarea id="qz-about-'.esc_attr($key).'" name="qz_about['.esc_attr($key).']" class="large-text" rows="'.absint($rows).'">'.esc_textarea($data[$key]??'').'</textarea></div>';
}
function qz_about_presentation_box(){
    echo '<div class="qz-about-presentation">';qz_photo(get_option('ticinoweb_chi_siamo_image'),'medium',['loading'=>'lazy','alt'=>'']);
    echo '<p><strong>'.nl2br(esc_html(get_option('ticinoweb_chi_siamo_title'))).'</strong></p><p>'.esc_html__('Titolo, introduzione e foto iniziali sono condivisi con la home. Si modificano nel CMS, in un solo posto.','qualazampa').'</p>';
    if(current_user_can('edit_pages'))echo '<a class="button" target="_blank" rel="noopener" href="'.esc_url(admin_url('admin.php?page=ticinoweb-cms#chi-siamo')).'">'.esc_html__('Modifica presentazione','qualazampa').'</a>';
    echo '</div>';
}
function qz_about_team_box(){
    wp_nonce_field('qz_save_about','qz_about_nonce');
    echo '<p>'.esc_html__('Questi testi introducono le fotografie del team. Nomi, ritratti e ordine si modificano nelle singole persone.','qualazampa').'</p>';
    qz_about_editor_field('team_title');qz_about_editor_field('team_text',3);
    echo '<div class="qz-about-people">';
    foreach(qz_about_team() as $person){
        echo '<div>'.get_the_post_thumbnail($person,[64,80]).'<span>'.esc_html(get_the_title($person)).'</span>';
        if(current_user_can('edit_post',$person->ID))echo '<a target="_blank" rel="noopener" href="'.esc_url(get_edit_post_link($person->ID,'raw')).'">'.esc_html__('Modifica','qualazampa').'<span class="screen-reader-text"> '.esc_html(get_the_title($person)).'</span></a>';
        echo '</div>';
    }
    echo '</div><p><a class="button" target="_blank" rel="noopener" href="'.esc_url(admin_url('edit.php?post_type=qz_team')).'">'.esc_html__('Gestisci il team','qualazampa').'</a></p><p class="description">'.esc_html__('Le gestioni collegate si aprono in una nuova scheda, senza chiudere questa pagina.','qualazampa').'</p>';
}
function qz_about_loyalty_box(){
    $data=qz_about_data();qz_about_editor_field('loyalty_title');qz_about_editor_field('loyalty_text',4);
    echo '<div class="qz-about-numbers">';
    foreach(['rate'=>[__('Sconto della tessera (%)','qualazampa'),100],'purchases'=>[__('Numero di acquisti','qualazampa'),1000]] as $key=>$field){
        echo '<div class="qz-about-field"><label for="qz-about-'.esc_attr($key).'">'.esc_html($field[0]).'</label><input id="qz-about-'.esc_attr($key).'" type="number" min="0" max="'.esc_attr($field[1]).'" step="1" name="qz_about['.esc_attr($key).']" value="'.esc_attr($data[$key]??'').'"></div>';
    }
    echo '</div><div class="qz-about-benefit"><strong>'.esc_html__('Nella pagina vedrai','qualazampa').'</strong><output data-loyalty-preview data-pattern="'.esc_attr__('%1$s%% sul totale di %2$s acquisti','qualazampa').'" data-empty="'.esc_attr__('La tessera è nascosta nella pagina.','qualazampa').'" aria-live="polite">';
    echo esc_html(!empty($data['rate'])&&!empty($data['purchases'])?sprintf(__('%1$s%% sul totale di %2$s acquisti','qualazampa'),$data['rate'],$data['purchases']):__('La tessera è nascosta nella pagina.','qualazampa'));
    echo '</output></div><p class="description">'.esc_html__('Per nascondere la sezione della tessera, imposta uno dei due valori a zero.','qualazampa').'</p>';
}
function qz_about_gallery_box(){
    $data=qz_about_data();qz_about_editor_field('gallery_title');qz_about_editor_field('gallery_text',3);
    echo '<p><label><strong>'.esc_html__('Galleria fotografica del negozio','qualazampa').'</strong><br><select name="qz_about[gallery_id]"><option value="0">'.esc_html__('Nessuna galleria','qualazampa').'</option>';
    $terms=get_terms(['taxonomy'=>'ticinoweb_media_gallery','hide_empty'=>false]);
    if(!is_wp_error($terms))foreach($terms as $term)echo '<option value="'.esc_attr($term->term_id).'" '.selected(absint($data['gallery_id']??0),$term->term_id,false).'>'.esc_html($term->name).'</option>';
    echo '</select></label></p><p class="description">'.esc_html__('Scegli la raccolta da mostrare. Con Nessuna galleria, la sezione non compare sul sito.','qualazampa').'</p><p><a class="button" target="_blank" rel="noopener" href="'.esc_url(admin_url('upload.php?page=ticinoweb-media-galleries-manager')).'">'.esc_html__('Gestisci foto e ordine nella galleria del CMS','qualazampa').'</a></p>';
}
function qz_sanitize_about($raw,$old){
    foreach(qz_about_fields() as $key=>$label)if(isset($raw[$key])&&is_scalar($raw[$key]))$old[$key]=sanitize_textarea_field($raw[$key]);
    foreach(['rate'=>100,'purchases'=>1000] as $key=>$max)if(isset($raw[$key])&&is_scalar($raw[$key]))$old[$key]=min($max,absint($raw[$key]));
    if(isset($raw['gallery_id'])&&is_scalar($raw['gallery_id'])){
        $id=absint($raw['gallery_id']);if(!$id||term_exists($id,'ticinoweb_media_gallery'))$old['gallery_id']=$id;
    }
    return $old;
}
add_action('save_post_page',static function($id){
    if((int)$id!==qz_about_id()||!isset($_POST['qz_about_nonce'])||!is_scalar($_POST['qz_about_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['qz_about_nonce'])),'qz_save_about')||!current_user_can('edit_post',$id)||wp_is_post_revision($id)||wp_is_post_autosave($id))return;
    if(isset($_POST['qz_about'])&&is_array($_POST['qz_about']))update_post_meta($id,'_qz_about',qz_sanitize_about(wp_unslash($_POST['qz_about']),qz_about_data()));
});
