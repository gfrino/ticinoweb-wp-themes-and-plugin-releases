<?php
/**
 * Shared Datatrans settings (one place for the whole account): merchant
 * credentials for production and sandbox, webhook signing key, settlement,
 * logging. The four payment methods are WooCommerce gateways that only hold
 * their own title/description/enabled flag and link back here.
 */

defined( 'ABSPATH' ) || exit;

class TW_Datatrans_Settings {

	const OPTION = 'tw_datatrans_settings';
	const PAGE   = 'tw-datatrans';

	public static function defaults() {
		return array(
			'merchant_id'         => '',
			'password'            => '',
			'sandbox'             => 'no',
			'sandbox_merchant_id' => '',
			'sandbox_password'    => '',
			'sign_key'            => '',
			'autosettle'          => 'yes',
			'log'                 => 'no',
			'webhook_token'       => '',
			'remove_on_uninstall' => 'no',
		);
	}

	/** @var array|null */
	private static $cache = null;

	public static function reset() {
		self::$cache = null;
	}

	/** Network option (multisite): the brand hub can manage one account for every site. */
	const NETWORK_OPTION = 'tw_datatrans_network_settings';
	const NETWORK_KEYS   = array( 'merchant_id', 'password', 'sandbox', 'sandbox_merchant_id', 'sandbox_password', 'sign_key', 'autosettle' );

	public static function network() {
		if ( ! is_multisite() ) {
			return array();
		}
		$n = get_site_option( self::NETWORK_OPTION, array() );
		return is_array( $n ) ? $n : array();
	}

	/** True when the network settings carry the credentials for every site. */
	public static function is_network_managed() {
		$n = self::network();
		return ( $n['managed'] ?? 'no' ) === 'yes';
	}

	public static function all() {
		$cache = &self::$cache;
		if ( null === $cache ) {
			$saved = get_option( self::OPTION, array() );
			$cache = array_merge( self::defaults(), is_array( $saved ) ? $saved : array() );
			if ( self::is_network_managed() ) {
				foreach ( self::NETWORK_KEYS as $k ) {
					if ( array_key_exists( $k, self::network() ) ) {
						$cache[ $k ] = (string) self::network()[ $k ];
					}
				}
			}
			// Constants in wp-config.php win over the database (secrets out of the DB if wanted).
			foreach ( array( 'merchant_id', 'password', 'sandbox_merchant_id', 'sandbox_password', 'sign_key' ) as $k ) {
				$const = 'TW_DATATRANS_' . strtoupper( $k );
				if ( defined( $const ) && constant( $const ) !== '' ) {
					$cache[ $k ] = (string) constant( $const );
				}
			}
			if ( '' === $cache['webhook_token'] ) {
				$cache['webhook_token'] = wp_generate_password( 32, false, false );
				$saved['webhook_token'] = $cache['webhook_token'];
				update_option( self::OPTION, is_array( $saved ) ? $saved : array( 'webhook_token' => $cache['webhook_token'] ), false );
			}
		}
		return $cache;
	}

	public static function get( $key ) {
		$all = self::all();
		return $all[ $key ] ?? '';
	}

	public static function is_sandbox() {
		return 'yes' === self::get( 'sandbox' );
	}

	/** Credentials of the active environment. */
	public static function credentials() {
		if ( self::is_sandbox() ) {
			return array( self::get( 'sandbox_merchant_id' ), self::get( 'sandbox_password' ) );
		}
		return array( self::get( 'merchant_id' ), self::get( 'password' ) );
	}

	public static function is_configured() {
		list( $id, $pw ) = self::credentials();
		return '' !== $id && '' !== $pw;
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 60 );
		add_action( 'admin_notices', array( __CLASS__, 'notice_unconfigured' ) );
	}

	public static function menu() {
		add_submenu_page(
			'woocommerce',
			__( 'Datatrans', 'tw-datatrans' ),
			__( 'Datatrans', 'tw-datatrans' ),
			'manage_woocommerce',
			self::PAGE,
			array( __CLASS__, 'render' )
		);
	}

	public static function notice_unconfigured() {
		if ( self::is_configured() || ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		if ( isset( $_GET['page'] ) && self::PAGE === $_GET['page'] ) {
			return;
		}
		$enabled = false;
		foreach ( TW_Datatrans_Gateway::methods() as $id => $class ) {
			$opt = get_option( 'woocommerce_' . $id . '_settings', array() );
			if ( is_array( $opt ) && ( $opt['enabled'] ?? 'no' ) === 'yes' ) {
				$enabled = true;
			}
		}
		if ( ! $enabled ) {
			return;
		}
		echo '<div class="notice notice-warning"><p><strong>Datatrans:</strong> '
			. esc_html__( 'a Datatrans payment method is enabled but the merchant credentials are missing: customers cannot pay.', 'tw-datatrans' )
			. ' <a href="' . esc_url( admin_url( 'admin.php?page=' . self::PAGE ) ) . '">' . esc_html__( 'Enter the credentials', 'tw-datatrans' ) . '</a></p></div>';
	}

	/** Saves the account (unless network-managed) and the methods' on/off; then the page. */
	public static function render() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You are not allowed to manage these settings.', 'tw-datatrans' ) );
		}
		$notices = array();
		$managed = self::is_network_managed();

		if ( isset( $_POST['tw_datatrans_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['tw_datatrans_nonce'] ) ), 'tw_datatrans_save' ) ) {
			$in = isset( $_POST['tw_datatrans'] ) && is_array( $_POST['tw_datatrans'] ) ? wp_unslash( $_POST['tw_datatrans'] ) : array();
			if ( ! $managed ) {
				$saved = get_option( self::OPTION, array() );
				$saved = is_array( $saved ) ? $saved : array();
				$text  = function ( $k ) use ( $in ) {
					return sanitize_text_field( trim( (string) ( $in[ $k ] ?? '' ) ) );
				};
				$saved['merchant_id']         = preg_replace( '/\D/', '', $text( 'merchant_id' ) );
				$saved['sandbox_merchant_id'] = preg_replace( '/\D/', '', $text( 'sandbox_merchant_id' ) );
				// Secrets: an empty field keeps the stored value (never printed in the HTML).
				foreach ( array( 'password', 'sandbox_password', 'sign_key' ) as $secret ) {
					$v = trim( (string) ( $in[ $secret ] ?? '' ) );
					if ( '' !== $v ) {
						$saved[ $secret ] = 'sign_key' === $secret ? strtolower( preg_replace( '/[^0-9a-fA-F]/', '', $v ) ) : $v;
					} elseif ( ! empty( $in[ $secret . '_clear' ] ) ) {
						$saved[ $secret ] = '';
					}
				}
				$saved['sandbox']    = ( $in['sandbox'] ?? 'no' ) === 'yes' ? 'yes' : 'no';
				$saved['autosettle'] = ! empty( $in['autosettle'] ) ? 'yes' : 'no';
			} else {
				$saved = get_option( self::OPTION, array() );
				$saved = is_array( $saved ) ? $saved : array();
			}
			$saved['log']                 = ! empty( $in['log'] ) ? 'yes' : 'no';
			$saved['remove_on_uninstall'] = ! empty( $in['remove_on_uninstall'] ) ? 'yes' : 'no';
			update_option( self::OPTION, $saved, false );
			// Methods on/off (the gateways' own "enabled" flag).
			$methods = isset( $_POST['tw_method'] ) && is_array( $_POST['tw_method'] ) ? wp_unslash( $_POST['tw_method'] ) : array();
			foreach ( TW_Datatrans_Gateway::methods() as $id => $class ) {
				$key = 'woocommerce_' . $id . '_settings';
				$opt = get_option( $key, array() );
				$opt = is_array( $opt ) ? $opt : array();
				$opt['enabled'] = ! empty( $methods[ $id ] ) ? 'yes' : 'no';
				update_option( $key, $opt, 'yes' );
			}
			self::reset();
			wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE, 'saved' => 1 ), admin_url( 'admin.php' ) ) );
			exit;
		}
		if ( isset( $_GET['saved'] ) ) {
			$notices[] = array( 'success', __( 'Settings saved.', 'tw-datatrans' ) );
		}

		$check = null;
		if ( isset( $_POST['tw_datatrans_check_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['tw_datatrans_check_nonce'] ) ), 'tw_datatrans_check' ) ) {
			$check = TW_Datatrans_API::check_credentials();
		}

		$s          = self::all();
		$sandbox    = self::is_sandbox();
		$configured = self::is_configured();
		$webhook    = TW_Datatrans_Handlers::webhook_url();
		$live_ok    = '' !== $s['merchant_id'] && '' !== $s['password'];
		$test_ok    = '' !== $s['sandbox_merchant_id'] && '' !== $s['sandbox_password'];
		$gateways   = array();
		foreach ( TW_Datatrans_Gateway::methods() as $id => $class ) {
			$opt            = get_option( 'woocommerce_' . $id . '_settings', array() );
			$gateways[ $id ] = array(
				'label' => $class::LABEL,
				'icon'  => $class::ICON ? TW_DATATRANS_URL . 'assets/img/' . $class::ICON : '',
				'on'    => is_array( $opt ) && ( $opt['enabled'] ?? 'no' ) === 'yes',
			);
		}
		$active_count = count( array_filter( array_column( $gateways, 'on' ) ) );
		$secret_field = function ( $name, $id, $has_value, $placeholder, $mono = false ) use ( $managed ) {
			?>
			<div class="twdt-secret">
				<input type="password" id="<?php echo esc_attr( $id ); ?>" name="tw_datatrans[<?php echo esc_attr( $name ); ?>]" value="" autocomplete="new-password" <?php echo $mono ? 'class="twdt-mono"' : ''; ?> placeholder="<?php echo esc_attr( $has_value ? __( 'Saved · type to replace', 'tw-datatrans' ) : $placeholder ); ?>" <?php disabled( $managed ); ?> />
				<?php if ( $has_value && ! $managed ) : ?>
					<label class="twdt-clear"><input type="checkbox" name="tw_datatrans[<?php echo esc_attr( $name ); ?>_clear]" value="1" /> <?php esc_html_e( 'remove', 'tw-datatrans' ); ?></label>
				<?php endif; ?>
			</div>
			<?php
		};
		?>
		<style>
			.twdt-wrap { max-width: 1080px; }
			.twdt-wrap h1 { margin-bottom: 4px; }
			.twdt-intro { color: #50575e; margin: 0 0 16px; max-width: 760px; }
			.twdt-status { display: flex; flex-wrap: wrap; gap: 10px; align-items: center; margin: 0 0 20px; }
			.twdt-pill { display: inline-flex; align-items: center; gap: 6px; border-radius: 999px; padding: 5px 12px; font-size: 13px; font-weight: 600; background: #f0f0f1; color: #1d2327; }
			.twdt-pill.is-live { background: #e6f4ea; color: #1e6b2e; }
			.twdt-pill.is-test { background: #fff4e5; color: #8a5a00; }
			.twdt-pill.is-bad { background: #fde8e8; color: #9b1c1c; }
			.twdt-pill.is-ok { background: #e6f4ea; color: #1e6b2e; }
			.twdt-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 16px; align-items: start; }
			.twdt-card { background: #fff; border: 1px solid #dcdcde; border-radius: 12px; padding: 18px 20px; }
			.twdt-card.is-wide { grid-column: 1 / -1; }
			.twdt-card.is-muted { background: #f9fafb; }
			.twdt-card h2 { font-size: 15px; margin: 0 0 4px; display: flex; align-items: center; gap: 10px; }
			.twdt-card .twdt-hint { color: #646970; font-size: 12px; margin: 0 0 12px; }
			.twdt-field { margin-bottom: 12px; }
			.twdt-field label.twdt-label { display: block; font-weight: 600; font-size: 13px; margin-bottom: 4px; }
			.twdt-field input[type=text], .twdt-field input[type=password] { width: 100%; max-width: 420px; }
			.twdt-mono { font-family: Menlo, Consolas, monospace; }
			.twdt-secret { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
			.twdt-secret input { flex: 1 1 240px; }
			.twdt-clear { font-size: 12px; color: #646970; white-space: nowrap; }
			.twdt-seg { display: inline-flex; border: 1.5px solid #dcdcde; border-radius: 999px; overflow: hidden; background: #f6f7f7; }
			.twdt-seg label { position: relative; padding: 8px 18px; cursor: pointer; font-weight: 600; font-size: 13px; color: #50575e; }
			.twdt-seg input { position: absolute; opacity: 0; width: 0; height: 0; }
			.twdt-seg label.is-on { background: #1ca5a8; color: #fff; }
			.twdt-seg label.is-on.is-test { background: #b26b00; }
			.twdt-seg-hint { color: #646970; font-size: 12px; margin-top: 8px; }
			.twdt-methods { display: flex; flex-wrap: wrap; gap: 10px; }
			.twdt-toggle { position: relative; display: inline-flex; align-items: center; gap: 10px; border: 1.5px solid #dcdcde; border-radius: 999px; padding: 8px 14px 8px 10px; background: #f6f7f7; cursor: pointer; user-select: none; transition: border-color .15s, background .15s; }
			.twdt-toggle input { position: absolute; opacity: 0; width: 0; height: 0; }
			.twdt-toggle img { height: 22px; width: auto; border-radius: 4px; }
			.twdt-toggle .twdt-name { font-size: 13px; font-weight: 600; color: #1d2327; }
			.twdt-toggle .twdt-switch { width: 32px; height: 19px; border-radius: 999px; background: #c3c4c7; position: relative; transition: background .15s; flex: none; }
			.twdt-toggle .twdt-switch::after { content: ""; position: absolute; top: 2px; left: 2px; width: 15px; height: 15px; border-radius: 50%; background: #fff; box-shadow: 0 1px 2px rgba(0,0,0,.25); transition: left .15s; }
			.twdt-toggle.is-on { background: #fff; border-color: #1ca5a8; }
			.twdt-toggle.is-on .twdt-switch { background: #1ca5a8; }
			.twdt-toggle.is-on .twdt-switch::after { left: 15px; }
			.twdt-toggle:not(.is-on) img, .twdt-toggle:not(.is-on) .twdt-name { opacity: .55; }
			.twdt-toggle a { font-size: 12px; margin-left: 2px; }
			.twdt-switchrow { display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 10px 0; border-top: 1px solid #f0f0f1; }
			.twdt-switchrow:first-of-type { border-top: 0; }
			.twdt-switchrow strong { display: block; font-size: 13px; }
			.twdt-switchrow span { color: #646970; font-size: 12px; }
			.twdt-actions { display: flex; align-items: center; gap: 14px; margin-top: 18px; flex-wrap: wrap; }
			.twdt-actions .button-primary { background: #1ca5a8; border-color: #1ca5a8; padding: 4px 24px; }
			.twdt-actions .button-primary:hover { background: #178a8d; border-color: #178a8d; }
			.twdt-unsaved { color: #996800; font-size: 13px; display: none; }
			.twdt-webhook { display: block; word-break: break-all; font-size: 11px; background: #f6f7f7; padding: 8px 10px; border-radius: 6px; }
			.twdt-check { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
			@media (max-width: 782px) { .twdt-card { padding: 14px; } }
		</style>
		<div class="wrap twdt-wrap">
			<h1>Datatrans by ticinoWEB</h1>
			<p class="twdt-intro"><?php esc_html_e( 'One Datatrans account for TWINT, cards, Apple Pay and Google Pay. Enter the credentials once, then switch the methods on: they appear at checkout like any other payment method.', 'tw-datatrans' ); ?></p>
			<?php foreach ( $notices as $n ) : ?>
				<div class="notice notice-<?php echo esc_attr( $n[0] ); ?> is-dismissible"><p><?php echo esc_html( $n[1] ); ?></p></div>
			<?php endforeach; ?>

			<div class="twdt-status">
				<span class="twdt-pill <?php echo $sandbox ? 'is-test' : 'is-live'; ?>"><?php echo $sandbox ? '🧪 ' . esc_html__( 'Test mode', 'tw-datatrans' ) : '● ' . esc_html__( 'Live', 'tw-datatrans' ); ?></span>
				<?php if ( $configured ) : ?>
					<span class="twdt-pill"><?php echo esc_html( sprintf( __( 'Merchant %s', 'tw-datatrans' ), self::credentials()[0] ) ); ?></span>
				<?php else : ?>
					<span class="twdt-pill is-bad">⚠️ <?php esc_html_e( 'Credentials missing', 'tw-datatrans' ); ?></span>
				<?php endif; ?>
				<span class="twdt-pill <?php echo $active_count ? 'is-ok' : ''; ?>"><?php echo esc_html( sprintf( _n( '%d method at checkout', '%d methods at checkout', $active_count, 'tw-datatrans' ), $active_count ) ); ?></span>
				<?php if ( $managed ) : ?>
					<span class="twdt-pill">🏢 <?php esc_html_e( 'Account managed by the main site', 'tw-datatrans' ); ?></span>
				<?php endif; ?>
				<?php if ( null !== $check ) : ?>
					<span class="twdt-pill <?php echo $check['ok'] ? 'is-ok' : 'is-bad'; ?>"><?php echo esc_html( ( $check['ok'] ? '✅ ' : '❌ ' ) . $check['message'] ); ?></span>
				<?php endif; ?>
			</div>

			<form method="post" id="twdt-form">
				<?php wp_nonce_field( 'tw_datatrans_save', 'tw_datatrans_nonce' ); ?>
				<div class="twdt-grid">

					<div class="twdt-card is-wide">
						<h2><?php esc_html_e( 'Payment methods at checkout', 'tw-datatrans' ); ?></h2>
						<p class="twdt-hint"><?php esc_html_e( 'Switch on what your customers can use. Each method must also be active on your Datatrans contract (Webadmin → UPP Administration → Payment methods); Apple Pay also needs the Apple Pay web terms accepted there. "Name and text" changes what the customer reads.', 'tw-datatrans' ); ?></p>
						<div class="twdt-methods">
							<?php foreach ( $gateways as $id => $g ) : ?>
								<label class="twdt-toggle<?php echo $g['on'] ? ' is-on' : ''; ?>">
									<input type="checkbox" name="tw_method[<?php echo esc_attr( $id ); ?>]" value="1" <?php checked( $g['on'] ); ?> />
									<?php if ( $g['icon'] ) : ?><img src="<?php echo esc_url( $g['icon'] ); ?>" alt="" /><?php endif; ?>
									<span class="twdt-name"><?php echo esc_html( $g['label'] ); ?></span>
									<span class="twdt-switch" aria-hidden="true"></span>
									<a href="<?php echo esc_url( admin_url( 'admin.php?page=wc-settings&tab=checkout&section=' . $id ) ); ?>"><?php esc_html_e( 'name and text', 'tw-datatrans' ); ?></a>
								</label>
							<?php endforeach; ?>
						</div>
						<?php if ( ! $configured ) : ?>
							<p class="twdt-hint" style="margin:10px 0 0;color:#9b1c1c;"><?php esc_html_e( 'The methods stay hidden at checkout until the credentials below are saved.', 'tw-datatrans' ); ?></p>
						<?php endif; ?>
					</div>

					<div class="twdt-card<?php echo $managed ? ' is-muted' : ''; ?>">
						<h2><?php esc_html_e( 'Mode', 'tw-datatrans' ); ?></h2>
						<p class="twdt-hint"><?php esc_html_e( 'Live takes real payments. Test uses the Datatrans sandbox: no money moves.', 'tw-datatrans' ); ?></p>
						<div class="twdt-seg" id="twdt-seg">
							<label class="<?php echo $sandbox ? '' : 'is-on'; ?>"><input type="radio" name="tw_datatrans[sandbox]" value="no" <?php checked( ! $sandbox ); ?> <?php disabled( $managed ); ?> /> <?php esc_html_e( 'Live', 'tw-datatrans' ); ?></label>
							<label class="is-test <?php echo $sandbox ? 'is-on' : ''; ?>"><input type="radio" name="tw_datatrans[sandbox]" value="yes" <?php checked( $sandbox ); ?> <?php disabled( $managed ); ?> /> <?php esc_html_e( 'Test (sandbox)', 'tw-datatrans' ); ?></label>
						</div>
						<div class="twdt-seg-hint" id="twdt-seg-hint"><?php echo $sandbox ? esc_html__( 'Customers see the methods but nothing is charged: use the Datatrans test cards.', 'tw-datatrans' ) : esc_html__( 'Payments are real. Refunds from the order page go to the customer.', 'tw-datatrans' ); ?></div>
						<div class="twdt-switchrow" style="margin-top:12px;">
							<div><strong><?php esc_html_e( 'Charge immediately', 'tw-datatrans' ); ?></strong><span><?php esc_html_e( 'Automatic settlement. Off: the amount is only reserved and must be settled in the Webadmin.', 'tw-datatrans' ); ?></span></div>
							<label class="twdt-toggle<?php echo 'yes' === $s['autosettle'] ? ' is-on' : ''; ?>"><input type="checkbox" name="tw_datatrans[autosettle]" value="1" <?php checked( 'yes', $s['autosettle'] ); ?> <?php disabled( $managed ); ?> /><span class="twdt-switch" aria-hidden="true"></span></label>
						</div>
					</div>

					<div class="twdt-card<?php echo $managed ? ' is-muted' : ''; ?>">
						<h2><?php esc_html_e( 'Live credentials', 'tw-datatrans' ); ?> <span class="twdt-pill <?php echo $live_ok ? 'is-ok' : 'is-bad'; ?>"><?php echo $live_ok ? esc_html__( 'saved', 'tw-datatrans' ) : esc_html__( 'missing', 'tw-datatrans' ); ?></span></h2>
						<p class="twdt-hint"><?php esc_html_e( 'Datatrans Webadmin → UPP Administration → Security → "Server-to-server services security".', 'tw-datatrans' ); ?></p>
						<div class="twdt-field">
							<label class="twdt-label" for="tw-dt-merchant"><?php esc_html_e( 'Merchant ID', 'tw-datatrans' ); ?></label>
							<input type="text" id="tw-dt-merchant" name="tw_datatrans[merchant_id]" value="<?php echo esc_attr( $s['merchant_id'] ); ?>" class="twdt-mono" inputmode="numeric" placeholder="3000012345" <?php disabled( $managed ); ?> />
						</div>
						<div class="twdt-field">
							<label class="twdt-label" for="tw-dt-password"><?php esc_html_e( 'Server-to-server password', 'tw-datatrans' ); ?></label>
							<?php $secret_field( 'password', 'tw-dt-password', '' !== $s['password'], '' ); ?>
						</div>
					</div>

					<div class="twdt-card<?php echo $managed ? ' is-muted' : ''; ?>">
						<h2><?php esc_html_e( 'Test credentials', 'tw-datatrans' ); ?> <span class="twdt-pill <?php echo $test_ok ? 'is-ok' : ''; ?>"><?php echo $test_ok ? esc_html__( 'saved', 'tw-datatrans' ) : esc_html__( 'optional', 'tw-datatrans' ); ?></span></h2>
						<p class="twdt-hint"><?php esc_html_e( 'From the Datatrans sandbox account (admin.sandbox.datatrans.com). Used only in Test mode.', 'tw-datatrans' ); ?></p>
						<div class="twdt-field">
							<label class="twdt-label" for="tw-dt-smerchant"><?php esc_html_e( 'Sandbox merchant ID', 'tw-datatrans' ); ?></label>
							<input type="text" id="tw-dt-smerchant" name="tw_datatrans[sandbox_merchant_id]" value="<?php echo esc_attr( $s['sandbox_merchant_id'] ); ?>" class="twdt-mono" inputmode="numeric" placeholder="1100012345" <?php disabled( $managed ); ?> />
						</div>
						<div class="twdt-field">
							<label class="twdt-label" for="tw-dt-spassword"><?php esc_html_e( 'Sandbox password', 'tw-datatrans' ); ?></label>
							<?php $secret_field( 'sandbox_password', 'tw-dt-spassword', '' !== $s['sandbox_password'], '' ); ?>
						</div>
					</div>

					<div class="twdt-card<?php echo $managed ? ' is-muted' : ''; ?>">
						<h2><?php esc_html_e( 'Webhook signature', 'tw-datatrans' ); ?> <span class="twdt-pill <?php echo '' !== $s['sign_key'] ? 'is-ok' : ''; ?>"><?php echo '' !== $s['sign_key'] ? esc_html__( 'active', 'tw-datatrans' ) : esc_html__( 'recommended', 'tw-datatrans' ); ?></span></h2>
						<p class="twdt-hint"><?php esc_html_e( 'Webadmin → UPP Administration → Security → "Important parameters will be digitally signed (HMAC-SHA256)": paste the hexadecimal key. Only notifications really sent by Datatrans are then accepted; every notification is in any case re-checked against the API before an order is marked paid.', 'tw-datatrans' ); ?></p>
						<div class="twdt-field">
							<label class="twdt-label" for="tw-dt-sign"><?php esc_html_e( 'HMAC key', 'tw-datatrans' ); ?></label>
							<?php $secret_field( 'sign_key', 'tw-dt-sign', '' !== $s['sign_key'], __( 'hexadecimal key', 'tw-datatrans' ), true ); ?>
						</div>
					</div>

					<div class="twdt-card">
						<h2><?php esc_html_e( 'Connection', 'tw-datatrans' ); ?></h2>
						<p class="twdt-hint"><?php esc_html_e( 'Checks the saved credentials against Datatrans without creating any transaction.', 'tw-datatrans' ); ?></p>
						<div class="twdt-check">
							<button type="submit" class="button" form="twdt-check-form" <?php disabled( ! $configured ); ?>><?php esc_html_e( 'Check the credentials', 'tw-datatrans' ); ?></button>
							<?php if ( null !== $check ) : ?><span class="twdt-pill <?php echo $check['ok'] ? 'is-ok' : 'is-bad'; ?>"><?php echo esc_html( $check['message'] ); ?></span><?php endif; ?>
						</div>
						<p class="twdt-hint" style="margin:14px 0 6px;"><strong><?php esc_html_e( 'Notifications (webhook)', 'tw-datatrans' ); ?></strong> — <?php esc_html_e( 'sent to Datatrans with every payment, nothing to configure in the Webadmin.', 'tw-datatrans' ); ?></p>
						<code class="twdt-webhook"><?php echo esc_html( $webhook ); ?></code>
					</div>

					<div class="twdt-card">
						<h2><?php esc_html_e( 'Maintenance', 'tw-datatrans' ); ?></h2>
						<div class="twdt-switchrow">
							<div><strong><?php esc_html_e( 'Detailed log', 'tw-datatrans' ); ?></strong><span><?php esc_html_e( 'WooCommerce → Status → Logs, source "tw-datatrans". Errors are always logged.', 'tw-datatrans' ); ?></span></div>
							<label class="twdt-toggle<?php echo 'yes' === $s['log'] ? ' is-on' : ''; ?>"><input type="checkbox" name="tw_datatrans[log]" value="1" <?php checked( 'yes', $s['log'] ); ?> /><span class="twdt-switch" aria-hidden="true"></span></label>
						</div>
						<div class="twdt-switchrow">
							<div><strong><?php esc_html_e( 'Delete settings on uninstall', 'tw-datatrans' ); ?></strong><span><?php esc_html_e( 'Order data is never deleted.', 'tw-datatrans' ); ?></span></div>
							<label class="twdt-toggle<?php echo 'yes' === $s['remove_on_uninstall'] ? ' is-on' : ''; ?>"><input type="checkbox" name="tw_datatrans[remove_on_uninstall]" value="1" <?php checked( 'yes', $s['remove_on_uninstall'] ); ?> /><span class="twdt-switch" aria-hidden="true"></span></label>
						</div>
					</div>
				</div>

				<div class="twdt-actions">
					<?php submit_button( __( 'Save', 'tw-datatrans' ), 'primary', 'submit', false ); ?>
					<span class="twdt-unsaved" id="twdt-unsaved"><?php esc_html_e( 'Unsaved changes', 'tw-datatrans' ); ?></span>
				</div>
			</form>
			<form method="post" id="twdt-check-form"><?php wp_nonce_field( 'tw_datatrans_check', 'tw_datatrans_check_nonce' ); ?></form>

			<script>
			(function () {
				var form = document.getElementById('twdt-form');
				if (!form) return;
				form.addEventListener('change', function (e) {
					var input = e.target;
					if (!input) return;
					var toggle = input.closest('.twdt-toggle');
					if (toggle && input.type === 'checkbox') toggle.classList.toggle('is-on', input.checked);
					if (input.type === 'radio' && input.name === 'tw_datatrans[sandbox]') {
						form.querySelectorAll('#twdt-seg label').forEach(function (l) { l.classList.toggle('is-on', l.querySelector('input').checked); });
						document.getElementById('twdt-seg-hint').textContent = input.value === 'yes'
							? <?php echo wp_json_encode( __( 'Customers see the methods but nothing is charged: use the Datatrans test cards.', 'tw-datatrans' ) ); ?>
							: <?php echo wp_json_encode( __( 'Payments are real. Refunds from the order page go to the customer.', 'tw-datatrans' ) ); ?>;
					}
					document.getElementById('twdt-unsaved').style.display = 'inline';
				});
			})();
			</script>
		</div>
		<?php
	}
}
