<?php
/** Project presentation, using the parent's configurable post types and media galleries. */
if (!defined('ABSPATH')) { exit; }

add_filter('register_post_type_args', static function ($args, $type) {
    if ($type !== 'pons_project') { return $args; }
    $args['publicly_queryable'] = false;
    $args['exclude_from_search'] = true;
    $args['rewrite'] = false;
    $args['query_var'] = false;
    $args['supports'] = array('title', 'editor', 'thumbnail', 'page-attributes', 'revisions');
    $args['template'] = array(array('core/paragraph', array('placeholder' => __('Descrivi il progetto, il contesto e il lavoro svolto.', 'ponsenergiasolare'))));
    return $args;
}, 10, 2);

add_action('add_meta_boxes_pons_project', static function () {
    add_meta_box('pons-project-gallery', __('Fotografie del progetto', 'ponsenergiasolare'), 'pons_project_gallery_box', 'pons_project', 'side', 'high');
});
function pons_project_gallery_box($post) {
    wp_nonce_field('pons_project_gallery', 'pons_project_nonce');
    $images = pons_project_gallery_ids($post->ID);
    echo '<div data-project-photo-editor><p>' . esc_html__('Aggiungi le fotografie e trascinale per riordinarle. Puoi usare anche le frecce sotto ogni foto.', 'ponsenergiasolare') . '</p>';
    echo '<input type="hidden" name="pons_project_images" value="' . esc_attr(implode(',', $images)) . '" data-project-photo-ids>';
    echo '<ul class="pons-photo-editor-list" data-project-photo-list>';
    foreach ($images as $image) {
        echo '<li data-image-id="' . esc_attr($image) . '">' . wp_get_attachment_image($image, 'thumbnail') . '</li>';
    }
    echo '</ul><p class="description" data-project-photo-empty' . ($images ? ' hidden' : '') . '>' . esc_html__('Nessuna fotografia aggiunta.', 'ponsenergiasolare') . '</p>';
    echo '<p><button type="button" class="button button-secondary" data-project-photo-add>' . esc_html__('Aggiungi / scegli foto', 'ponsenergiasolare') . '</button></p>';
    echo '<p class="description">' . esc_html__('La copertina si imposta in Immagine in evidenza e viene inclusa anche nella scheda. Le modifiche alle foto si salvano con Aggiorna o Pubblica.', 'ponsenergiasolare') . '</p>';
    echo '<p class="description" aria-live="polite" data-project-photo-status></p></div>';
}

add_action('admin_enqueue_scripts', static function () {
    $screen = get_current_screen();
    if (!$screen || $screen->post_type !== 'pons_project' || $screen->base !== 'post') { return; }
    wp_enqueue_media();
    $version = wp_get_theme()->get('Version');
    wp_enqueue_style('pons-project-editor', get_stylesheet_directory_uri() . '/assets/css/project-editor.css', array(), $version);
    wp_enqueue_script('pons-project-editor', get_stylesheet_directory_uri() . '/assets/js/project-editor.js', array('jquery', 'jquery-ui-sortable', 'media-views'), $version, true);
    wp_localize_script('pons-project-editor', 'ponsProjectPhotos', array(
        'title' => __('Fotografie del progetto', 'ponsenergiasolare'),
        'choose' => __('Usa queste foto', 'ponsenergiasolare'),
        'before' => __('Sposta prima la foto %d', 'ponsenergiasolare'),
        'after' => __('Sposta dopo la foto %d', 'ponsenergiasolare'),
        'remove' => __('Rimuovi la foto %d dal progetto', 'ponsenergiasolare'),
        'changed' => __('Foto aggiornate. Salva il progetto per applicare le modifiche.', 'ponsenergiasolare'),
    ));
});

/** Changes the parent's native gallery relationships; never deletes attachments. */
function pons_update_project_photos($id, $images) {
    $images = array_values(array_unique(array_filter(array_map('absint', $images), 'wp_attachment_is_image')));
    $slug = 'pons-project-' . $id;
    $term = get_term_by('slug', $slug, 'ticinoweb_media_gallery');
    if (!$term) {
        $created = wp_insert_term(get_post_field('post_title', $id), 'ticinoweb_media_gallery', array('slug' => $slug));
        if (is_wp_error($created)) { return false; }
        $term_id = (int) $created['term_id'];
    } else { $term_id = (int) $term->term_id; }
    $previous = get_objects_in_term($term_id, 'ticinoweb_media_gallery');
    if (is_wp_error($previous)) { return false; }
    foreach (array_diff(array_map('absint', $previous), $images) as $image) {
        wp_remove_object_terms($image, array($term_id), 'ticinoweb_media_gallery');
    }
    foreach ($images as $image) { wp_set_object_terms($image, array($term_id), 'ticinoweb_media_gallery', true); }
    update_term_meta($term_id, '_ticinoweb_gallery_order', $images);
    update_post_meta($id, '_pons_project_gallery', $term_id);
    return true;
}

add_action('save_post_pons_project', static function ($id) {
    if (wp_is_post_revision($id) || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || !current_user_can('edit_post', $id) || !current_user_can('upload_files')) { return; }
    if (!isset($_POST['pons_project_nonce'], $_POST['pons_project_images']) || !is_string($_POST['pons_project_images']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pons_project_nonce'])), 'pons_project_gallery')) { return; }
    $images = explode(',', wp_unslash($_POST['pons_project_images']));
    pons_update_project_photos($id, $images);
});

function pons_project_gallery_ids($id) {
    $term = absint(get_post_meta($id, '_pons_project_gallery', true));
    $images = array();
    if ($term && !is_wp_error(get_term($term, 'ticinoweb_media_gallery')) && get_term($term, 'ticinoweb_media_gallery')) {
        $images = get_posts(array('post_type' => 'attachment', 'post_status' => 'inherit', 'post_mime_type' => 'image', 'posts_per_page' => -1, 'fields' => 'ids', 'tax_query' => array(array('taxonomy' => 'ticinoweb_media_gallery', 'field' => 'term_id', 'terms' => $term)), 'orderby' => 'menu_order ID', 'order' => 'ASC'));
        $order = get_term_meta($term, '_ticinoweb_gallery_order', true);
        if (is_array($order) && $order) {
            $positions = array_flip(array_map('absint', $order));
            usort($images, static function ($a, $b) use ($positions) { return ($positions[$a] ?? PHP_INT_MAX) <=> ($positions[$b] ?? PHP_INT_MAX); });
        }
    }
    return array_values(array_unique(array_map('absint', $images)));
}
function pons_project_image_ids($id) {
    return array_values(array_unique(array_filter(array_merge(array(absint(get_post_thumbnail_id($id))), pons_project_gallery_ids($id)))));
}

add_action('wp_enqueue_scripts', static function () {
    $content = get_post_field('post_content', get_queried_object_id());
    if (!has_shortcode($content, 'pons_projects')) { return; }
    $version = wp_get_theme()->get('Version');
    wp_enqueue_style('pons-projects', get_stylesheet_directory_uri() . '/assets/css/projects.css', array('pons-pages'), $version);
    wp_enqueue_script('pons-projects', get_stylesheet_directory_uri() . '/assets/js/projects.js', array(), $version, true);
}, 40);

add_shortcode('pons_projects', static function () {
    $projects = get_posts(array('post_type' => 'pons_project', 'post_status' => 'publish', 'has_password' => false, 'posts_per_page' => -1, 'orderby' => array('menu_order' => 'ASC', 'date' => 'DESC'), 'suppress_filters' => false));
    if (!$projects) { return ''; }
    ob_start(); ?>
    <div class="pons-projects" data-projects>
        <div class="project-grid">
        <?php foreach ($projects as $project) :
            $images = pons_project_image_ids($project->ID);
            if (!$images) { continue; }
            $panel = 'project-' . $project->ID;
            $title = get_the_title($project);
        ?>
            <article class="project-card">
                <a class="project-card-link" href="#<?php echo esc_attr($panel); ?>" data-open-project="<?php echo esc_attr($panel); ?>" aria-haspopup="dialog">
                    <div class="project-cover"><?php echo wp_get_attachment_image($images[0], 'large', false, array('loading' => 'lazy', 'sizes' => '(max-width:780px) 90vw, 46vw')); ?><span class="project-open" aria-hidden="true">↗</span></div>
                    <div class="project-card-caption"><h2><?php echo esc_html($title); ?></h2><span><?php echo esc_html(sprintf(__('%s foto', 'ponsenergiasolare'), number_format_i18n(count($images)))); ?></span></div>
                </a>
            </article>
        <?php endforeach; ?>
        </div>
        <?php foreach ($projects as $project) :
            $images = pons_project_image_ids($project->ID);
            if (!$images) { continue; }
            $panel = 'project-' . $project->ID;
        ?>
        <section class="project-sheet" id="<?php echo esc_attr($panel); ?>" aria-labelledby="<?php echo esc_attr($panel); ?>-title" data-project-sheet>
            <div class="project-sheet-inner">
                <div class="project-sheet-bar"><span><?php echo esc_html__('Il progetto', 'ponsenergiasolare'); ?></span><button type="button" class="project-close" data-close-project aria-label="<?php esc_attr_e('Chiudi il progetto', 'ponsenergiasolare'); ?>"><?php esc_html_e('Chiudi', 'ponsenergiasolare'); ?><span aria-hidden="true">×</span></button></div>
                <div class="project-sheet-intro"><h2 id="<?php echo esc_attr($panel); ?>-title"><?php echo esc_html(get_the_title($project)); ?></h2><div class="project-description"><?php echo wp_kses_post(wpautop(do_blocks($project->post_content))); ?></div></div>
                <div class="project-photos">
                <?php foreach ($images as $index => $image) :
                    $full = wp_get_attachment_image_url($image, 'full');
                    if (!$full) { continue; }
                ?>
                    <a href="<?php echo esc_url($full); ?>" class="project-photo" data-project-photo data-caption="<?php echo esc_attr(wp_strip_all_tags(wp_get_attachment_caption($image))); ?>" aria-label="<?php echo esc_attr(sprintf(__('Ingrandisci foto %1$d di %2$d', 'ponsenergiasolare'), $index + 1, count($images))); ?>"><?php echo wp_get_attachment_image($image, 'large', false, array('loading' => 'lazy', 'sizes' => '(max-width:780px) 90vw, 48vw')); ?><span aria-hidden="true">＋</span></a>
                <?php endforeach; ?>
                </div>
            </div>
        </section>
        <?php endforeach; ?>
        <dialog class="project-lightbox" aria-label="<?php esc_attr_e('Galleria fotografica del progetto', 'ponsenergiasolare'); ?>" data-project-lightbox>
            <div class="project-lightbox-bar"><span data-photo-count aria-live="polite"></span><button type="button" class="project-close" data-close-photo aria-label="<?php esc_attr_e('Chiudi la fotografia', 'ponsenergiasolare'); ?>"><?php esc_html_e('Chiudi', 'ponsenergiasolare'); ?><span aria-hidden="true">×</span></button></div>
            <figure><img data-full-photo alt=""><figcaption data-photo-caption></figcaption></figure>
            <div class="project-lightbox-nav"><button type="button" data-photo-prev aria-label="<?php esc_attr_e('Foto precedente', 'ponsenergiasolare'); ?>">←</button><button type="button" data-photo-next aria-label="<?php esc_attr_e('Foto successiva', 'ponsenergiasolare'); ?>">→</button></div>
        </dialog>
    </div>
    <?php return ob_get_clean();
});

add_filter('manage_pons_project_posts_columns', static function ($columns) {
    $columns['pons_project_photos'] = __('Fotografie', 'ponsenergiasolare');
    return $columns;
});
add_action('manage_pons_project_posts_custom_column', static function ($column, $id) {
    if ($column !== 'pons_project_photos') { return; }
    $cover = get_post_thumbnail_id($id);
    if ($cover) { echo wp_get_attachment_image($cover, 'thumbnail', false, array('style' => 'width:80px;height:55px;object-fit:cover;display:block;margin-bottom:6px')); }
    $term = absint(get_post_meta($id, '_pons_project_gallery', true));
    if ($term) { echo '<a href="' . esc_url(get_edit_post_link($id) . '#pons-project-gallery') . '">' . esc_html__('Gestisci foto', 'ponsenergiasolare') . '</a>'; }
}, 10, 2);
