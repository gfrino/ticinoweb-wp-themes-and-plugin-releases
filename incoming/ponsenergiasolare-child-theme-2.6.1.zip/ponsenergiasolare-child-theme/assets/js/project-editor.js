/* Project editing uses WordPress' own media picker and sortable library. */
(function($){
 'use strict';
 $('[data-project-photo-editor]').each(function(){
  const root=this,list=root.querySelector('[data-project-photo-list]'),input=root.querySelector('[data-project-photo-ids]');
  const labels=window.ponsProjectPhotos;
  let items=[...list.querySelectorAll('[data-image-id]')].map(li=>({id:Number(li.dataset.imageId),url:li.querySelector('img').src,alt:li.querySelector('img').alt})),frame;
  const sync=()=>{
   input.value=items.map(item=>item.id).join(',');
   $(input).trigger('change');
   root.querySelector('[data-project-photo-status]').textContent=labels.changed;
  };
  const render=()=>{
   list.replaceChildren();
   root.querySelector('[data-project-photo-empty]').hidden=items.length>0;
   items.forEach((item,index)=>{
    const li=document.createElement('li');li.dataset.imageId=String(item.id);
    const image=document.createElement('img');image.src=item.url;image.alt=item.alt||'';image.draggable=false;li.append(image);
    const controls=document.createElement('div');controls.className='pons-photo-editor-controls';
    [['←','before',-1],['→','after',1],['×','remove',0]].forEach(([icon,action,delta])=>{
     const button=document.createElement('button');button.type='button';button.className='button';button.textContent=icon;
     button.setAttribute('aria-label',labels[action].replace('%d',String(index+1)));button.title=button.getAttribute('aria-label');
     button.disabled=(action==='before'&&index===0)||(action==='after'&&index===items.length-1);
     button.addEventListener('click',()=>{
      if(action==='remove')items.splice(index,1);
      else [items[index],items[index+delta]]=[items[index+delta],items[index]];
      render();sync();
      const next=Math.max(0,Math.min(items.length-1,index+delta));
      const focusTarget=list.children[next]?.querySelector('button:not(:disabled)')||root.querySelector('[data-project-photo-add]');
      focusTarget.focus();
     });
     controls.append(button);
    });
    li.append(controls);list.append(li);
   });
   $(list).sortable('refresh');
  };
  $(list).sortable({items:'>li',handle:'img',tolerance:'pointer',placeholder:'pons-photo-editor-placeholder',update:()=>{
   const order=[...list.children].map(li=>Number(li.dataset.imageId));
   items=order.map(id=>items.find(item=>item.id===id));render();sync();
  }});
  root.querySelector('[data-project-photo-add]').addEventListener('click',()=>{
   if(!frame){
    frame=wp.media({title:labels.title,button:{text:labels.choose},library:{type:'image'},multiple:'add'});
    frame.on('open',()=>{
     const selection=frame.state().get('selection');selection.reset();
     items.forEach(item=>{const model=wp.media.attachment(item.id);model.fetch();selection.add(model);});
    });
    frame.on('select',()=>{
     const previous=new Map(items.map(item=>[item.id,item]));
     items=frame.state().get('selection').toJSON().map(image=>({id:image.id,url:image.sizes?.thumbnail?.url||image.url||previous.get(image.id)?.url,alt:image.alt||''})).filter(image=>image.url);
     render();sync();
    });
   }
   frame.open();
  });
  render();
 });
})(jQuery);
