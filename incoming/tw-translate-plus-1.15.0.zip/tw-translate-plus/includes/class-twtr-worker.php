<?php
/**
 * Self-contained background worker.
 *
 * The plugin must translate on any host without server configuration. WP-Cron
 * alone is not enough: with DISABLE_WP_CRON and a server cron that only hits
 * the main site (common on multisite), a subsite's events never run. So the
 * plugin drives itself:
 *
 * 1. Dispatch: a non-blocking loopback POST to the site's own admin-ajax.php
 *    (the same technique core uses in spawn_cron()), signed with a per-site
 *    secret so nobody else can start it.
 * 2. Chain: the worker runs for up to RUN_SECONDS (index sweep first, then
 *    the translation queue) and, while work remains, dispatches the next
 *    worker itself. Once started it needs no visitors.
 * 3. Watchdog: any request to the site (frontend, admin, REST), at most once
 *    a minute, restarts a chain that died (PHP killed, host restart) or
 *    that was never started.
 * 4. Fallback: if loopback requests never arrive (firewall, basic auth), the
 *    watchdog runs a short batch itself after the response has been sent to
 *    the visitor (fastcgi_finish_request / litespeed_finish_request), so
 *    nobody waits for it.
 *
 * WP-Cron hooks stay registered and go through the same lock: where cron
 * works it simply helps.
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Worker {

    const ACTION       = 'twtr_worker';
    const STATE_OPTION = 'twtr_worker_state';
    const LOCK_OPTION  = 'twtr_worker_lock';
    const RUN_SECONDS  = 45;
    /** Seconds of budget for the in-request fallback (visitor already served). */
    const FALLBACK_SECONDS = 20;
    /** A chain with no heartbeat for this long is considered dead. */
    const STALE_SECONDS = 180;
    /** Watchdog check interval per site. */
    const WATCHDOG_SECONDS = 60;
    /** Dispatched but never started for this long: loopback is broken. */
    const LOOPBACK_GRACE = 300;

    public static function init() {
        add_action('wp_ajax_' . self::ACTION, array(__CLASS__, 'handle'));
        add_action('wp_ajax_nopriv_' . self::ACTION, array(__CLASS__, 'handle'));
        add_action('shutdown', array(__CLASS__, 'watchdog'), 20);
    }

    /* ------------------------------------------------------------ state */

    /**
     * @return array{heartbeat:int,dispatched:int,pending:int,paused_until:int,loopback:string,last_daily:int,last_run:array}
     */
    public static function state() {
        $saved = get_option(self::STATE_OPTION, array());
        return wp_parse_args(is_array($saved) ? $saved : array(), array(
            'heartbeat'    => 0,
            'dispatched'   => 0,
            'pending'      => 1, // unknown: assume work until the first run says otherwise
            'paused_until' => 0,
            'loopback'     => '', // '' unknown | ok | broken
            'last_daily'   => 0,
            'watchdog_at'  => 0,
            'last_run'     => array(),
        ));
    }

    private static function update_state($partial) {
        update_option(self::STATE_OPTION, array_merge(self::state(), $partial), true);
    }

    /**
     * New work was queued (content saved, language enabled, errors retried):
     * clear any pause and make sure a worker is on it.
     */
    public static function nudge() {
        $s = self::state();
        // Called for every string queued during an index sweep: write only
        // when something actually changes.
        if ($s['pending'] < 1 || $s['paused_until'] > 0) {
            self::update_state(array('pending' => max(1, $s['pending']), 'paused_until' => 0));
            $s = self::state();
        }
        if (!self::is_alive($s) && $s['dispatched'] < time() - 30) {
            self::dispatch();
        }
    }

    private static function is_alive($s) {
        return $s['heartbeat'] > time() - self::STALE_SECONDS;
    }

    /** @return bool Whether there is anything for the worker to do. */
    private static function has_work($s) {
        if ($s['paused_until'] > time()) {
            return false;
        }
        twtr_glossary();
        require_once TWTR_DIR . 'includes/class-twtr-extractor.php';
        $index_running = Twtr_Extractor::index_state()['running'];
        $daily_due     = $s['last_daily'] < time() - DAY_IN_SECONDS && Twtr_Settings::extra_languages();
        if ($index_running || $daily_due) {
            return true;
        }
        return $s['pending'] > 0 && Twtr_Settings::auto_translate() && Twtr_Settings::engine_ready();
    }

    /* --------------------------------------------------------- dispatch */

    /** Per-site secret signing the loopback requests. */
    private static function secret() {
        $secret = get_option('twtr_worker_secret', '');
        if (!is_string($secret) || strlen($secret) < 32) {
            $secret = wp_generate_password(64, false, false);
            update_option('twtr_worker_secret', $secret, false);
        }
        return $secret;
    }

    private static function signature($ts) {
        return hash_hmac('sha256', get_current_blog_id() . '|' . $ts, self::secret());
    }

    /**
     * Fire a non-blocking loopback request that starts one worker run.
     */
    public static function dispatch() {
        $ts = time();
        self::update_state(array('dispatched' => $ts));
        $url  = add_query_arg('action', self::ACTION, admin_url('admin-ajax.php'));
        $args = array(
            // 10 ms (core's spawn_cron value) is too short to finish a TLS
            // handshake: on HTTPS the request often never left, and the
            // chain stalled until the watchdog noticed (3 minutes later).
            'timeout'   => 1,
            'blocking'  => false,
            'sslverify' => apply_filters('https_local_ssl_verify', false),
            'body'      => array('ts' => $ts, 'sig' => self::signature($ts)),
            'cookies'   => array(),
        );
        wp_remote_post($url, (array) apply_filters('twtr_worker_dispatch_args', $args));
    }

    /* ----------------------------------------------------------- worker */

    /**
     * Loopback endpoint (admin-ajax, also unauthenticated: the HMAC is the
     * authentication).
     */
    public static function handle() {
        $ts  = isset($_POST['ts']) ? (int) $_POST['ts'] : 0; // phpcs:ignore WordPress.Security.NonceVerification -- HMAC-signed loopback.
        $sig = isset($_POST['sig']) ? (string) wp_unslash($_POST['sig']) : ''; // phpcs:ignore WordPress.Security.NonceVerification,WordPress.Security.ValidatedSanitizedInput
        if (abs(time() - $ts) > 120 || !hash_equals(self::signature($ts), $sig)) {
            wp_send_json_error(null, 403);
        }
        ignore_user_abort(true);
        if (self::state()['loopback'] !== 'ok') {
            self::update_state(array('loopback' => 'ok'));
        }
        self::run(self::RUN_SECONDS, true);
        wp_send_json_success();
    }

    /**
     * One worker run under the site lock: daily maintenance, index sweep,
     * then the translation queue, within $seconds.
     *
     * @param int  $seconds Time budget.
     * @param bool $chain   Dispatch the next run when work remains.
     * @return bool False when another run holds the lock.
     */
    public static function run($seconds, $chain = false) {
        if (!self::lock($seconds + 30)) {
            return false;
        }
        // Shared hosting: at most MAX_SITES sites of the network translate at
        // the same time, so background work never starves visitors of PHP
        // workers. A site without a slot simply tries again later (watchdog).
        if (!self::take_slot($seconds + 30)) {
            self::unlock();
            return false;
        }
        if (function_exists('set_time_limit')) {
            @set_time_limit($seconds + 30); // phpcs:ignore WordPress.PHP.NoSilencedErrors
        }
        $start = microtime(true);
        self::update_state(array('heartbeat' => time()));

        try {
            twtr_maybe_upgrade();
            Twtr_Settings::upgrade_site();
            twtr_queue();
            twtr_glossary();
            require_once TWTR_DIR . 'includes/class-twtr-extractor.php';

            $s = self::state();
            if ($s['last_daily'] < time() - DAY_IN_SECONDS) {
                self::update_state(array('last_daily' => time()));
                Twtr_Extractor::maybe_auto_index();
                // Errors are never final: credit topped up, outage over,
                // model fixed... give every parked string a fresh try daily.
                Twtr_Storage::retry_errors();
            }

            // Index sweep first (cheap, local), with at most half the budget.
            if (Twtr_Extractor::index_state()['running']) {
                Twtr_Extractor::run_auto_index((int) max(5, $seconds / 2));
            }

            $result = array('processed' => 0, 'reused' => 0, 'errors' => 0, 'remaining' => 0, 'message' => '');
            $left   = (int) ($seconds - (microtime(true) - $start));
            if ($left > 5 && Twtr_Settings::auto_translate()) {
                $result = Twtr_Queue::process_for($left);
            } else {
                $result['remaining'] = Twtr_Queue::remaining();
            }

            if ($result['processed'] > 0) {
                Twtr_Settings::set_engine_check(true);
            } elseif ($result['errors'] > 0 && $result['message'] !== '') {
                Twtr_Settings::set_engine_check(false, $result['message']);
            }

            $pause = 0;
            $limit = Twtr_Settings::daily_char_limit();
            if ($limit > 0 && Twtr_Settings::usage_today() >= $limit) {
                // Daily character limit (counted per UTC day): resume tomorrow.
                $pause = ((int) floor(time() / DAY_IN_SECONDS) + 1) * DAY_IN_SECONDS;
            } elseif ($result['errors'] > 0 && $result['processed'] === 0) {
                // Engine failing (credit, outage): back off, don't hammer it.
                $pause = time() + 10 * MINUTE_IN_SECONDS;
            }
            self::update_state(array(
                'heartbeat'    => time(),
                'pending'      => (int) $result['remaining'],
                'paused_until' => $pause,
                'last_run'     => array(
                    'at'        => time(),
                    'processed' => (int) $result['processed'],
                    'reused'    => (int) $result['reused'],
                    'errors'    => (int) $result['errors'],
                    'remaining' => (int) $result['remaining'],
                    'message'   => (string) $result['message'],
                ),
            ));
            // Site-wide strings changed while full purges were throttled.
            if (get_transient('twtr_purge_all_pending') && !get_transient('twtr_purge_all_recent')) {
                set_transient('twtr_purge_all_recent', 1, 10 * MINUTE_IN_SECONDS);
                delete_transient('twtr_purge_all_pending');
                Twtr_Cache::purge_all();
            }
        } finally {
            self::release_slot();
            self::unlock();
        }

        if ($chain && self::has_work(self::state())) {
            self::dispatch();
        }
        return true;
    }

    /**
     * WP-Cron entry point (queue and index events): same run, same lock;
     * keeps the loopback chain going if work remains.
     */
    public static function run_from_cron() {
        self::run(self::RUN_SECONDS, true);
    }

    /* --------------------------------------------------------- watchdog */

    /**
     * End of every request (at most once a minute per site): restart a dead
     * or never-started chain; if loopbacks never arrive, work in-request
     * after the response has been flushed to the visitor.
     */
    public static function watchdog() {
        if (wp_doing_ajax() && isset($_REQUEST['action']) && $_REQUEST['action'] === self::ACTION) { // phpcs:ignore WordPress.Security.NonceVerification
            return;
        }
        if ((defined('WP_INSTALLING') && WP_INSTALLING) || (defined('WP_CLI') && WP_CLI)) {
            return;
        }
        // The state option is autoloaded: this check costs no query.
        $s = self::state();
        if ($s['watchdog_at'] > time() - self::WATCHDOG_SECONDS || !Twtr_Settings::extra_languages()) {
            return;
        }
        self::update_state(array('watchdog_at' => time()));
        if (self::is_alive($s) || !self::has_work($s)) {
            return;
        }

        // Dispatched long ago and no worker ever started: loopback is broken.
        $stuck = $s['dispatched'] > 0 && $s['dispatched'] < time() - self::LOOPBACK_GRACE && $s['heartbeat'] < $s['dispatched'];
        if ($stuck && $s['loopback'] !== 'broken') {
            self::update_state(array('loopback' => 'broken'));
            $s['loopback'] = 'broken';
        }

        if ($s['loopback'] === 'broken') {
            if (self::finish_response()) {
                self::run(self::FALLBACK_SECONDS, false);
                // Keep probing: a working loopback switches back to chaining.
                self::dispatch();
            }
            return;
        }
        // Detach the visitor first: the dispatch may take up to a second.
        self::finish_response();
        self::dispatch();
    }

    /**
     * Send the response to the client and keep running.
     *
     * @return bool False when the server API cannot detach the client.
     */
    private static function finish_response() {
        ignore_user_abort(true);
        if (function_exists('fastcgi_finish_request')) {
            return fastcgi_finish_request();
        }
        if (function_exists('litespeed_finish_request')) {
            litespeed_finish_request();
            return true;
        }
        return false;
    }

    /* -------------------------------------------------- network slots */

    /** Sites of one network translating at the same time (filter twtr_worker_max_sites). */
    const MAX_SITES = 3;

    private static function take_slot($ttl) {
        if (!is_multisite()) {
            return true;
        }
        $max   = max(1, (int) apply_filters('twtr_worker_max_sites', self::MAX_SITES));
        $now   = time();
        $slots = array_filter((array) get_site_option('twtr_worker_slots', array()), function ($until) use ($now) {
            return (int) $until > $now;
        });
        $me = get_current_blog_id();
        if (!isset($slots[$me]) && count($slots) >= $max) {
            return false;
        }
        $slots[$me] = $now + (int) $ttl;
        update_site_option('twtr_worker_slots', $slots);
        return true;
    }

    private static function release_slot() {
        if (!is_multisite()) {
            return;
        }
        $slots = (array) get_site_option('twtr_worker_slots', array());
        unset($slots[get_current_blog_id()]);
        update_site_option('twtr_worker_slots', $slots);
    }

    /* ------------------------------------------------------------- lock */

    private static function lock($ttl) {
        $until = time() + (int) $ttl;
        if (add_option(self::LOCK_OPTION, $until, '', false)) {
            return true;
        }
        $current = (int) get_option(self::LOCK_OPTION, 0);
        if ($current < time()) {
            // Expired lock left by a killed worker: take it over atomically.
            global $wpdb;
            $taken = $wpdb->query($wpdb->prepare(
                "UPDATE {$wpdb->options} SET option_value = %s WHERE option_name = %s AND option_value = %s",
                (string) $until, self::LOCK_OPTION, (string) $current
            ));
            wp_cache_delete(self::LOCK_OPTION, 'options');
            return (bool) $taken;
        }
        return false;
    }

    private static function unlock() {
        delete_option(self::LOCK_OPTION);
    }
}
