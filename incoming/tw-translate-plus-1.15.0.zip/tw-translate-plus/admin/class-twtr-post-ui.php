<?php
/**
 * Translation status where the content is edited: a "Traduzioni" box in the
 * editor of every public post type (products, pages, posts…) with the state
 * per language and a «Traduci adesso» button, and a compact column in the
 * list tables. One grouped query per screen, nothing on the frontend.
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Post_UI {

    public static function init() {
        add_action('add_meta_boxes', array(__CLASS__, 'add_box'), 10, 2);
        add_action('admin_init', array(__CLASS__, 'register_columns'));
        add_action('admin_enqueue_scripts', array(__CLASS__, 'assets'));
        add_action('wp_ajax_twtr_translate_post', array(__CLASS__, 'ajax_translate_post'));
    }

    /** @return bool */
    private static function active() {
        return current_user_can(Twtr_Admin::CAP) && Twtr_Settings::extra_languages();
    }

    /** @return string[] Post types that get the box and the column. */
    private static function post_types() {
        require_once TWTR_DIR . 'includes/class-twtr-extractor.php';
        return Twtr_Extractor::indexable_post_types();
    }

    public static function assets($hook) {
        if (!in_array($hook, array('post.php', 'post-new.php', 'edit.php'), true) || !self::active()) {
            return;
        }
        wp_enqueue_style('twtr-admin', TWTR_URL . 'admin/assets/admin.css', array(), TWTR_VERSION);
        wp_enqueue_script('twtr-post', TWTR_URL . 'admin/assets/post.js', array('jquery'), TWTR_VERSION, true);
        wp_localize_script('twtr-post', 'twtrPost', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('twtr_translate_post'),
            'working' => __('Traduzione in corso…', 'tw-translate-plus'),
            'error'   => __('Errore: riprova tra poco.', 'tw-translate-plus'),
        ));
    }

    /* ---------------------------------------------------------- status */

    /**
     * Summary of one language for one post.
     *
     * @param array|null $c Counts ready/pending/error, null = nothing stored.
     * @return array{state:string,label:string}
     */
    private static function summarize($c) {
        if (!$c || ($c['ready'] + $c['pending'] + $c['error']) === 0) {
            return array('state' => 'none', 'label' => __('Non ancora in coda', 'tw-translate-plus'));
        }
        if ($c['error'] > 0) {
            return array('state' => 'error', 'label' => sprintf(
                /* translators: %d: failed strings. */
                _n('%d testo in errore', '%d testi in errore', $c['error'], 'tw-translate-plus'),
                $c['error']
            ));
        }
        if ($c['pending'] > 0) {
            return array('state' => 'pending', 'label' => sprintf(
                /* translators: 1: translated, 2: total. */
                __('In traduzione: %1$d di %2$d testi pronti', 'tw-translate-plus'),
                $c['ready'], $c['ready'] + $c['pending']
            ));
        }
        return array('state' => 'ready', 'label' => __('Tradotto', 'tw-translate-plus'));
    }

    /**
     * @param int $post_id
     * @return string HTML of the per-language list.
     */
    public static function status_html($post_id) {
        $status = Twtr_Storage::posts_status(array($post_id));
        $status = isset($status[$post_id]) ? $status[$post_id] : array();
        $html   = '<ul class="twtr-post-status">';
        foreach (Twtr_Settings::extra_languages() as $lang) {
            $s    = self::summarize(isset($status[$lang]) ? $status[$lang] : null);
            $view = get_post_status($post_id) === 'publish' ? Twtr_Router::language_url($lang, get_permalink($post_id)) : '';
            $html .= '<li class="twtr-ps-' . esc_attr($s['state']) . '">'
                . '<span class="twtr-ps-dot"></span><strong>' . esc_html(strtoupper($lang)) . '</strong> '
                . esc_html($s['label'])
                . ($view && $s['state'] !== 'none' ? ' <a href="' . esc_url($view) . '" target="_blank" rel="noopener">' . esc_html__('Vedi', 'tw-translate-plus') . '</a>' : '')
                . '</li>';
        }
        return $html . '</ul>';
    }

    /* ------------------------------------------------------- editor box */

    public static function add_box($post_type, $post = null) {
        if (!self::active() || !in_array($post_type, self::post_types(), true)) {
            return;
        }
        add_meta_box('twtr-translations', __('Traduzioni', 'tw-translate-plus'), array(__CLASS__, 'render_box'), $post_type, 'side', 'high');
    }

    public static function render_box($post) {
        $published = $post->post_status === 'publish';
        ?>
        <div class="twtr-post-box" data-post="<?php echo esc_attr($post->ID); ?>">
            <div class="twtr-post-box-status"><?php echo self::status_html($post->ID); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in status_html(). ?></div>
            <?php if ($published) : ?>
                <p>
                    <button type="button" class="button button-primary twtr-translate-now"><?php esc_html_e('Traduci adesso', 'tw-translate-plus'); ?></button>
                    <span class="twtr-post-feedback" role="status"></span>
                </p>
                <p class="description"><?php esc_html_e('Le traduzioni si fanno comunque da sole in background: questo pulsante passa questo contenuto davanti a tutti. Salva prima le modifiche.', 'tw-translate-plus'); ?></p>
                <p><a href="<?php echo esc_url(add_query_arg(array('page' => Twtr_Admin::SLUG, 'tab' => 'translations', 's' => 'post:' . $post->ID . ':'), admin_url('admin.php'))); ?>"><?php esc_html_e('Correggi le traduzioni a mano →', 'tw-translate-plus'); ?></a></p>
            <?php else : ?>
                <p class="description"><?php esc_html_e('Verrà tradotto quando lo pubblichi.', 'tw-translate-plus'); ?></p>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * «Traduci adesso»: extract the saved post again, then translate its
     * strings first (memory, then engine) within ~40 s.
     */
    public static function ajax_translate_post() {
        check_ajax_referer('twtr_translate_post');
        $post_id = isset($_POST['post_id']) ? (int) $_POST['post_id'] : 0;
        $post    = $post_id ? get_post($post_id) : null;
        if (!$post || !current_user_can(Twtr_Admin::CAP) || !current_user_can('edit_post', $post_id)) {
            wp_send_json_error(array('message' => __('Permessi insufficienti.', 'tw-translate-plus')), 403);
        }
        require_once TWTR_DIR . 'includes/class-twtr-extractor.php';
        twtr_queue();
        Twtr_Extractor::on_save_post($post_id, $post);
        Twtr_Storage::retry_post($post_id);

        $message = '';
        if (Twtr_Settings::engine_ready()) {
            $result  = Twtr_Queue::process_post($post_id, 40);
            $message = $result['errors'] > 0 ? $result['message'] : '';
        } else {
            $message = Twtr_Settings::engine_missing_reason();
        }

        $status  = Twtr_Storage::posts_status(array($post_id));
        $left    = 0;
        foreach (isset($status[$post_id]) ? $status[$post_id] : array() as $c) {
            $left += $c['pending'];
        }
        if ($message === '') {
            $message = $left > 0
                ? __('Quasi fatto: il resto si completa da solo in background tra poco.', 'tw-translate-plus')
                : __('Fatto: questo contenuto è tradotto.', 'tw-translate-plus');
        }
        Twtr_Worker::nudge();
        wp_send_json_success(array('html' => self::status_html($post_id), 'message' => $message, 'done' => $left === 0));
    }

    /* ------------------------------------------------------ list column */

    public static function register_columns() {
        if (!self::active()) {
            return;
        }
        foreach (self::post_types() as $type) {
            add_filter("manage_{$type}_posts_columns", array(__CLASS__, 'add_column'), 20);
            add_action("manage_{$type}_posts_custom_column", array(__CLASS__, 'render_column'), 10, 2);
        }
    }

    public static function add_column($columns) {
        $columns['twtr'] = __('Traduzioni', 'tw-translate-plus');
        return $columns;
    }

    public static function render_column($column, $post_id) {
        if ($column !== 'twtr') {
            return;
        }
        static $cache = null;
        if ($cache === null) {
            // One query for every row of the current list page.
            global $wp_query;
            $ids   = $wp_query && !empty($wp_query->posts) ? wp_list_pluck($wp_query->posts, 'ID') : array($post_id);
            $cache = Twtr_Storage::posts_status($ids);
        }
        $status = isset($cache[$post_id]) ? $cache[$post_id] : array();
        foreach (Twtr_Settings::extra_languages() as $lang) {
            $s = self::summarize(isset($status[$lang]) ? $status[$lang] : null);
            echo '<span class="twtr-chip twtr-ps-' . esc_attr($s['state']) . '" title="' . esc_attr($s['label']) . '">' . esc_html(strtoupper($lang)) . '</span> ';
        }
    }
}
