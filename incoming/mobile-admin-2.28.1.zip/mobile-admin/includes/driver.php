<?php
/**
 * Gestione App → Driver: consegne con i propri fattorini (v2.27.0, solo app dalla 2.28.0, solo siti con WooCommerce dalla 2.28.1).
 *
 * L'amministratore promuove un utente a Driver; il Driver vede gli ordini a domicilio nell'app,
 * li accetta (uno solo per ordine), apre la navigazione e segna «Consegnato». Il cliente riceve le notifiche,
 * segue l'auto sulla mappa e (iPhone) la Live Activity. Posizione, notifiche e mappa passano dalle
 * Cloud Functions dell'app (Firebase): vedi includes/driver/firebase.php.
 *
 * Spento di default su ogni sito: finché nessuno lo accende in Gestione App → Driver non crea tabelle,
 * ruoli, pagine né API e non tocca gli ordini. Si accende e spegne per sito (sede), così lo stesso Mobile Admin
 * serve anche le app degli altri clienti.
 *
 * Prefisso `madr_` (Mobile Admin Driver), API REST `app-driver/v1`.
 *
 * @package mobile-admin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'MADR_VERSION', '2.28.1' );
define( 'MADR_DB_VERSION', '2' );
define( 'MADR_DIR', WPADR_PATH . 'includes/driver/' );
define( 'MADR_URL', WPADR_URL . 'assets/driver/' );
const MADR_ENABLED_OPTION = 'madr_enabled';
const MADR_ADMIN_SLUG     = 'madr-drivers';

/** Il Driver è acceso su questo sito. */
function madr_enabled() {
	return '1' === (string) get_option( MADR_ENABLED_OPTION, '0' );
}

/** Il sito ha un negozio WooCommerce (gli ordini da consegnare). Il sito «vetrina» del marchio di solito no. */
function madr_has_shop() {
	return function_exists( 'wc_get_orders' ) && class_exists( 'WooCommerce' );
}

/*
 * Si decide dopo che tutti i plugin sono caricati: Mobile Admin viene caricato prima di WooCommerce.
 * Senza WooCommerce il Driver resta spento anche se l'interruttore è acceso (2.28.1: prima la scheda
 * «Consegne» andava in errore critico sul sito del marchio).
 */
add_action( 'plugins_loaded', 'madr_boot', 20 );
function madr_boot() {
	if ( madr_enabled() && madr_has_shop() ) {
		require_once MADR_DIR . 'setup.php';
		require_once MADR_DIR . 'deliveries.php';
		require_once MADR_DIR . 'firebase.php';
		require_once MADR_DIR . 'rest.php';
		require_once MADR_DIR . 'admin.php';
		require_once MADR_DIR . 'frontend.php';
		return;
	}
	// Spento (o senza negozio): solo la pagina con l'interruttore o la spiegazione.
	add_action( 'admin_menu', function () {
		$title  = __( 'Driver e consegne', 'wp-app-dashboard' );
		$parent = ! empty( $GLOBALS['admin_page_hooks']['ard_stato_app'] ) ? 'ard_stato_app' : '';
		if ( $parent ) {
			add_submenu_page( $parent, $title, __( 'Driver', 'wp-app-dashboard' ), madr_has_shop() ? 'manage_woocommerce' : 'manage_options', MADR_ADMIN_SLUG, 'madr_admin_page_off' );
		}
	}, 30 );
}

/** Pagina del Driver spento: cosa fa e come si accende. */
function madr_admin_page_off() {
	if ( ! current_user_can( madr_has_shop() ? 'manage_woocommerce' : 'manage_options' ) ) {
		return;
	}
	if ( ! madr_has_shop() ) {
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Driver e consegne', 'wp-app-dashboard' ); ?></h1>
			<p><?php esc_html_e( 'Questo sito non ha un negozio WooCommerce, quindi non ha ordini da consegnare. Il Driver si accende nei siti delle sedi, dove arrivano gli ordini.', 'wp-app-dashboard' ); ?></p>
		</div>
		<?php
		return;
	}
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Driver e consegne', 'wp-app-dashboard' ); ?></h1>
		<p><?php esc_html_e( 'Consegne a domicilio con i vostri fattorini: il Driver accetta gli ordini dal sito o dall\'app, apre la navigazione e segna «Consegnato»; il cliente riceve le notifiche e segue l\'auto sulla mappa.', 'wp-app-dashboard' ); ?></p>
		<p><?php esc_html_e( 'Serve l\'app con l\'area Driver e le Cloud Functions del tracking. Finché è spento non cambia nulla su questo sito.', 'wp-app-dashboard' ); ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="madr_toggle">
			<input type="hidden" name="enable" value="1">
			<?php wp_nonce_field( 'madr_toggle' ); ?>
			<?php submit_button( __( 'Attiva le consegne con Driver', 'wp-app-dashboard' ), 'primary', 'submit', false ); ?>
		</form>
	</div>
	<?php
}

/** Accende o spegne il Driver su questo sito. Spegnendo, dati e Driver restano: si ritrovano riaccendendo. */
add_action( 'admin_post_madr_toggle', function () {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		wp_die( esc_html__( 'Non hai i permessi per questa operazione.', 'wp-app-dashboard' ), 403 );
	}
	check_admin_referer( 'madr_toggle' );
	$on = ! empty( $_POST['enable'] ) && madr_has_shop();
	update_option( MADR_ENABLED_OPTION, $on ? '1' : '0', true );
	if ( $on ) {
		require_once MADR_DIR . 'setup.php';
		madr_install_site();
	} else {
		wp_clear_scheduled_hook( 'madr_retry_sync' );
	}
	wp_safe_redirect( add_query_arg( array( 'page' => MADR_ADMIN_SLUG ), admin_url( 'admin.php' ) ) );
	exit;
} );
