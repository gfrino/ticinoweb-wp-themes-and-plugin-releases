<?php
/**
 * Ricerca nel catalogo: zona, categoria, prezzo massimo, locali minimi.
 * I filtri arrivano da un modulo GET (link condivisibili) e valgono per
 * l'archivio degli immobili e per le pagine zona/categoria.
 *
 * @package Idea_Immobiliare_SA
 */

if (!defined('ABSPATH')) {
    exit;
}

/** Scaglioni di prezzo del selettore (valore => etichetta). */
function idea_immo_price_steps()
{
    $steps = array(300000, 400000, 500000, 600000, 800000, 1000000, 1500000, 2000000);
    $out = array();
    foreach ($steps as $s) {
        $out[$s] = sprintf(__('fino a CHF %s', 'idea-immobiliare-sa'), idea_immo_number($s));
    }
    return $out;
}

function idea_immo_room_steps()
{
    return array(
        '2' => __('2 locali o più', 'idea-immobiliare-sa'),
        '3' => __('3 locali o più', 'idea-immobiliare-sa'),
        '4' => __('4 locali o più', 'idea-immobiliare-sa'),
        '5' => __('5 locali o più', 'idea-immobiliare-sa'),
    );
}

/** Filtri attivi letti dall'URL, già ripuliti. */
function idea_immo_active_filters()
{
    $f = array(
        'zona'       => isset($_GET['zona']) ? sanitize_title(wp_unslash($_GET['zona'])) : '',
        'categoria'  => isset($_GET['categoria']) ? sanitize_title(wp_unslash($_GET['categoria'])) : '',
        'prezzo_max' => isset($_GET['prezzo_max']) ? absint($_GET['prezzo_max']) : 0,
        'locali'     => isset($_GET['locali']) ? absint($_GET['locali']) : 0,
        'offerta'    => isset($_GET['offerta']) ? sanitize_key(wp_unslash($_GET['offerta'])) : '',
        'stato'      => isset($_GET['stato']) ? sanitize_key(wp_unslash($_GET['stato'])) : '',
    );
    if (is_tax('zona')) {
        $f['zona'] = get_queried_object()->slug;
    }
    if (is_tax('categoria_immobile')) {
        $f['categoria'] = get_queried_object()->slug;
    }
    return $f;
}

add_action('pre_get_posts', 'idea_immo_filter_archive');
function idea_immo_filter_archive($q)
{
    if (is_admin() || !$q->is_main_query()) {
        return;
    }
    if (!($q->is_post_type_archive('immobile') || $q->is_tax(array('zona', 'categoria_immobile')))) {
        return;
    }

    $q->set('post_type', 'immobile');
    $q->set('posts_per_page', 12);
    $q->set('orderby', array('date' => 'DESC'));

    $f = idea_immo_active_filters();
    $tax = array();
    if ($f['zona'] !== '' && !$q->is_tax('zona')) {
        $tax[] = array('taxonomy' => 'zona', 'field' => 'slug', 'terms' => $f['zona']);
    }
    if ($f['categoria'] !== '' && !$q->is_tax('categoria_immobile')) {
        $tax[] = array('taxonomy' => 'categoria_immobile', 'field' => 'slug', 'terms' => $f['categoria']);
    }
    if ($tax) {
        $q->set('tax_query', $tax);
    }

    $meta = array('relation' => 'AND');
    if ($f['prezzo_max'] > 0) {
        $meta[] = array('key' => '_idea_price', 'value' => $f['prezzo_max'], 'type' => 'NUMERIC', 'compare' => '<=');
    }
    if ($f['locali'] > 0) {
        $meta[] = array('key' => '_idea_rooms', 'value' => $f['locali'], 'type' => 'DECIMAL(4,1)', 'compare' => '>=');
    }
    if ($f['offerta'] === 'affitto' || $f['offerta'] === 'vendita') {
        if ($f['offerta'] === 'affitto') {
            $meta[] = array('key' => '_idea_offer', 'value' => 'affitto');
        } else {
            $meta[] = array(
                'relation' => 'OR',
                array('key' => '_idea_offer', 'compare' => 'NOT EXISTS'),
                array('key' => '_idea_offer', 'value' => 'vendita'),
            );
        }
    }
    // Catalogo: in archivio solo gli immobili disponibili o riservati.
    if ($f['stato'] === 'archivio') {
        $meta[] = array('key' => '_idea_status', 'value' => 'archivio');
    } else {
        $meta[] = array(
            'relation' => 'OR',
            array('key' => '_idea_status', 'compare' => 'NOT EXISTS'),
            array('key' => '_idea_status', 'value' => 'archivio', 'compare' => '!='),
        );
    }
    $q->set('meta_query', $meta);
}

/** Query per la home (in evidenza): ultimi immobili disponibili. */
function idea_immo_featured_query($count = 9)
{
    return new WP_Query(array(
        'post_type'      => 'immobile',
        'posts_per_page' => $count,
        'orderby'        => 'date',
        'order'          => 'DESC',
        'no_found_rows'  => true,
        'meta_query'     => array(
            'relation' => 'OR',
            array('key' => '_idea_status', 'compare' => 'NOT EXISTS'),
            array('key' => '_idea_status', 'value' => 'archivio', 'compare' => '!='),
        ),
    ));
}

/** Modulo di ricerca (home e catalogo). */
function idea_immo_search_form($args = array())
{
    $f = idea_immo_active_filters();
    $zones = get_terms(array('taxonomy' => 'zona', 'hide_empty' => true));
    $cats  = get_terms(array('taxonomy' => 'categoria_immobile', 'hide_empty' => true));
    $action = get_post_type_archive_link('immobile');
    ob_start();
    ?>
    <form class="idea-search" action="<?php echo esc_url($action); ?>" method="get" role="search" aria-label="<?php esc_attr_e('Cerca un immobile', 'idea-immobiliare-sa'); ?>">
        <div class="idea-search__field">
            <label for="idea-s-zona"><?php esc_html_e('Zona', 'idea-immobiliare-sa'); ?></label>
            <select id="idea-s-zona" name="zona">
                <option value=""><?php esc_html_e('Tutte le zone', 'idea-immobiliare-sa'); ?></option>
                <?php if (!is_wp_error($zones)) : foreach ($zones as $t) : ?>
                    <option value="<?php echo esc_attr($t->slug); ?>"<?php selected($f['zona'], $t->slug); ?>><?php echo esc_html($t->name); ?></option>
                <?php endforeach; endif; ?>
            </select>
        </div>
        <div class="idea-search__field">
            <label for="idea-s-cat"><?php esc_html_e('Categoria', 'idea-immobiliare-sa'); ?></label>
            <select id="idea-s-cat" name="categoria">
                <option value=""><?php esc_html_e('Tutte le categorie', 'idea-immobiliare-sa'); ?></option>
                <?php if (!is_wp_error($cats)) : foreach ($cats as $t) : ?>
                    <option value="<?php echo esc_attr($t->slug); ?>"<?php selected($f['categoria'], $t->slug); ?>><?php echo esc_html($t->name); ?></option>
                <?php endforeach; endif; ?>
            </select>
        </div>
        <div class="idea-search__field">
            <label for="idea-s-prezzo"><?php esc_html_e('Prezzo', 'idea-immobiliare-sa'); ?></label>
            <select id="idea-s-prezzo" name="prezzo_max">
                <option value=""><?php esc_html_e('Qualsiasi prezzo', 'idea-immobiliare-sa'); ?></option>
                <?php foreach (idea_immo_price_steps() as $value => $label) : ?>
                    <option value="<?php echo (int) $value; ?>"<?php selected($f['prezzo_max'], $value); ?>><?php echo esc_html($label); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="idea-search__field">
            <label for="idea-s-locali"><?php esc_html_e('Locali', 'idea-immobiliare-sa'); ?></label>
            <select id="idea-s-locali" name="locali">
                <option value=""><?php esc_html_e('Qualsiasi', 'idea-immobiliare-sa'); ?></option>
                <?php foreach (idea_immo_room_steps() as $value => $label) : ?>
                    <option value="<?php echo (int) $value; ?>"<?php selected($f['locali'], (int) $value); ?>><?php echo esc_html($label); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="idea-btn idea-btn--mint"><?php esc_html_e('Cerca', 'idea-immobiliare-sa'); ?></button>
    </form>
    <?php
    return ob_get_clean();
}


/**
 * Ordine degli immobili sul sito: per ID oggetto, dal più alto al più basso (i più recenti in cima);
 * a parità, o senza ID, per data. Vale per catalogo, zone, categorie e home.
 */
add_filter('posts_clauses', 'idea_immo_order_by_ref', 20, 2);
function idea_immo_order_by_ref($clauses, $query)
{
    if (is_admin() || $query->get('post_type') !== 'immobile' || $query->get('idea_keep_order')) {
        return $clauses;
    }
    global $wpdb;
    $clauses['orderby'] = $wpdb->prepare(
        "COALESCE((SELECT CAST(idea_ref.meta_value AS UNSIGNED) FROM {$wpdb->postmeta} AS idea_ref WHERE idea_ref.post_id = {$wpdb->posts}.ID AND idea_ref.meta_key = %s LIMIT 1), 0) DESC, {$wpdb->posts}.post_date DESC, {$wpdb->posts}.ID DESC",
        '_idea_ref'
    );
    return $clauses;
}
