<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CC_Form_Handler {
    public static function init() {
        add_action( 'wp_ajax_cc_submit_enrollment', array( __CLASS__, 'handle_form_submission' ) );
        add_action( 'wp_ajax_nopriv_cc_submit_enrollment', array( __CLASS__, 'handle_form_submission' ) );
        add_action( 'wp_ajax_cc_get_fresh_nonce', array( __CLASS__, 'get_fresh_nonce' ) );
        add_action( 'wp_ajax_nopriv_cc_get_fresh_nonce', array( __CLASS__, 'get_fresh_nonce' ) );
    }

    public static function get_fresh_nonce() {
        wp_send_json_success( array(
            'nonce' => wp_create_nonce( 'cc_form_nonce' )
        ) );
    }

    public static function handle_form_submission() {
        if ( ! isset( $_POST['cc_nonce'] ) || ! wp_verify_nonce( $_POST['cc_nonce'], 'cc_form_nonce' ) ) {
            wp_send_json_error( 'Richiesta non valida. Ricarica la pagina e riprova.' );
        }

        $course_id = isset( $_POST['course_id'] ) ? intval( $_POST['course_id'] ) : 0;
        if ( ! $course_id ) {
            wp_send_json_error( 'Corso non specificato.' );
        }

        $max_participants = intval( get_post_meta( $course_id, '_cc_max_participants', true ) );
        $enrolled_count = intval( get_post_meta( $course_id, '_cc_enrolled_count', true ) );
        $available_seats = $max_participants - $enrolled_count;

        $participants = isset( $_POST['participants'] ) ? $_POST['participants'] : array();
        $num_participants_to_enroll = count( $participants );

        if ( $num_participants_to_enroll <= 0 ) {
            wp_send_json_error( 'Inserisci almeno un partecipante.' );
        }

        if ( $num_participants_to_enroll > $available_seats ) {
            wp_send_json_error( 'Siamo spiacenti, non ci sono abbastanza posti disponibili. Posti rimasti: ' . $available_seats );
        }

        $billing_company = isset( $_POST['billing_company'] ) ? sanitize_text_field( $_POST['billing_company'] ) : '';
        $billing_email   = isset( $_POST['billing_email'] ) ? sanitize_email( $_POST['billing_email'] ) : '';
        $billing_phone   = isset( $_POST['billing_phone'] ) ? sanitize_text_field( $_POST['billing_phone'] ) : '';
        $billing_vat     = isset( $_POST['billing_vat'] ) ? sanitize_text_field( $_POST['billing_vat'] ) : '';
        $billing_address = isset( $_POST['billing_address'] ) ? sanitize_text_field( $_POST['billing_address'] ) : '';

        $enrollment_title = 'Iscrizione al corso ' . get_the_title( $course_id ) . ' - ' . date('d/m/Y H:i');
        
        $enrollment_id = wp_insert_post( array(
            'post_type'   => 'enrollment',
            'post_title'  => $enrollment_title,
            'post_status' => 'publish',
            'post_parent' => $course_id,
        ) );

        if ( is_wp_error( $enrollment_id ) ) {
            wp_send_json_error( 'Si è verificato un errore durante l\'iscrizione. Riprova più tardi.' );
        }

        $sanitized_participants = array();
        foreach ( $participants as $p ) {
            $sanitized_participants[] = array(
                'name'      => sanitize_text_field( $p['name'] ),
                'birthdate' => sanitize_text_field( $p['birthdate'] ),
            );
        }

        update_post_meta( $enrollment_id, '_cc_course_id', $course_id );
        update_post_meta( $enrollment_id, '_cc_participants', $sanitized_participants );
        update_post_meta( $enrollment_id, '_cc_billing_company', $billing_company );
        update_post_meta( $enrollment_id, '_cc_billing_email', $billing_email );
        update_post_meta( $enrollment_id, '_cc_billing_phone', $billing_phone );
        update_post_meta( $enrollment_id, '_cc_billing_vat', $billing_vat );
        update_post_meta( $enrollment_id, '_cc_billing_address', $billing_address );

        update_post_meta( $course_id, '_cc_enrolled_count', $enrolled_count + $num_participants_to_enroll );

        // Forza la pulizia della cache della pagina del corso in ambiente di produzione server
        // (necessario perché alcuni plugin di cache non reagiscono a 'update_post_meta')
        wp_update_post( array(
            'ID' => $course_id,
        ) );
        // --- INVIO EMAIL (Gestito automaticamente da WP Mail SMTP / SendGrid su server) ---
        $course_title = get_the_title( $course_id );
        $course_date_raw = get_post_meta( $course_id, '_cc_start_date', true );
        $course_date = $course_date_raw ? date_i18n('j F Y', strtotime($course_date_raw)) : '';
        
        // Determina la mail a cui inviare la notifica (usa WP Mail SMTP se esiste, altrimenti l'admin di default)
        $admin_email = get_option('admin_email');
        $admin_email = get_option('admin_email');
        $wp_mail_smtp_options = get_option('wp_mail_smtp');
        if ( is_array($wp_mail_smtp_options) && !empty($wp_mail_smtp_options['mail']['from_email']) ) {
            $admin_email = sanitize_email( $wp_mail_smtp_options['mail']['from_email'] );
        }
        
        // Impostiamo il formato HTML usando l'hook nativo di WordPress per EVITARE
        // conflitti di headers con plugin SMTP come SendGrid.
        add_filter( 'wp_mail_content_type', function() {
            return 'text/html';
        });
        
        // 1. Email all'Amministratore
        $admin_subject = 'Nuova iscrizione al corso: ' . $course_title;
        $admin_message = '<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body style="font-family: Arial, sans-serif; color: #333;">';
        $admin_message .= '<h2>Nuova Iscrizione Ricevuta</h2>';
        $admin_message .= '<p><strong>Corso:</strong> ' . esc_html($course_title) . ' - in data: ' . esc_html($course_date) . '</p>';
        $admin_message .= '<p><strong>Azienda/Privato:</strong> ' . esc_html($billing_company) . '</p>';
        $admin_message .= '<p><strong>Email di contatto:</strong> ' . esc_html($billing_email) . '</p>';
        $admin_message .= '<p><strong>Telefono:</strong> ' . esc_html($billing_phone) . '</p>';
        if(!empty($billing_vat)) $admin_message .= '<p><strong>Partita IVA:</strong> ' . esc_html($billing_vat) . '</p>';
        if(!empty($billing_address)) $admin_message .= '<p><strong>Indirizzo:</strong> ' . esc_html($billing_address) . '</p>';
        
        $admin_message .= '<h3>Partecipanti iscritti:</h3><ul>';
        foreach($sanitized_participants as $p) {
            $admin_message .= '<li>Nome Cognome: <strong>' . esc_html($p['name']) . '</strong> | Data di Nascita: ' . esc_html($p['birthdate']) . '</li>';
        }
        $admin_message .= '</ul>';
        $admin_message .= '<p><br>Puoi visualizzare i dettagli completi nella dashboard di WordPress.</p>';
        $admin_message .= '</body></html>';
        
        wp_mail( $admin_email, $admin_subject, $admin_message );

        // 2. Email di Conferma al Cliente
        if ( is_email( $billing_email ) ) {
            $customer_subject = 'Conferma iscrizione: ' . $course_title;
            
            $logo_url = 'https://solutionstrategies.ch/wp-content/uploads/sites/143/2025/10/655da88a-c81c-5cf1-de5c-a8f8448c1459.png';
            $customer_message = '<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body style="font-family: Arial, sans-serif; color: #333;">';
            $customer_message .= '<div style="margin-bottom: 20px;"><img src="' . esc_url($logo_url) . '" alt="Solution Strategies" width="150" border="0" style="display: block; width: 150px; max-width: 150px; height: auto;"></div>';
            
            $customer_message .= '<h2>Iscrizione Confermata</h2>';
            if(!empty($billing_company)) {
                $customer_message .= '<p>Gentile ' . esc_html($billing_company) . ',</p>';
            } else {
                $customer_message .= '<p>Gentile Cliente,</p>';
            }
            $customer_message .= '<p>Ti confermiamo di aver ricevuto correttamente la tua richiesta di iscrizione.</p>';
            $customer_message .= '<p><strong>Dettagli del Corso:</strong></p>';
            $customer_message .= '<ul><li><strong>Nome Corso:</strong> ' . esc_html($course_title) . '</li>';
            $customer_message .= '<li><strong>Data Inizio:</strong> ' . esc_html($course_date) . '</li></ul>';
            
            $customer_message .= '<h3>Elenco Partecipanti:</h3><ul>';
            foreach($sanitized_participants as $p) {
                $customer_message .= '<li>' . esc_html($p['name']) . '</li>';
            }
            $customer_message .= '</ul>';
            $customer_message .= '<p><br>Restiamo a disposizione per qualsiasi necessità.</p>';
            $customer_message .= '<p>Cordiali saluti,<br>Il team di ' . get_bloginfo('name') . '</p>';
            $customer_message .= '</body></html>';
            
            wp_mail( $billing_email, $customer_subject, $customer_message );
        }
        // ----------------------------------------------------

        wp_send_json_success( 'Iscrizione completata con successo! Grazie.' );
    }
}
CC_Form_Handler::init();
