<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CC_Shortcodes {
    public static function init() {
        add_shortcode( 'courses_calendar', array( __CLASS__, 'render_calendar' ) );
        add_shortcode( 'courses_list', array( __CLASS__, 'render_upcoming_courses_list' ) );
        add_action( 'wp_ajax_cc_load_calendar', array( __CLASS__, 'ajax_load_calendar' ) );
        add_action( 'wp_ajax_nopriv_cc_load_calendar', array( __CLASS__, 'ajax_load_calendar' ) );
    }

    public static function get_course_icon_html( $post_id ) {
        $icon = get_post_meta( $post_id, '_cc_course_icon', true );
        if ( !empty( $icon ) ) {
            return '<img src="' . esc_url( $icon ) . '" alt="Icona Corso" class="cc-custom-icon">';
        }
        return '';
    }

    public static function render_calendar( $atts ) {
        ob_start();
        ?>
        <div id="cc-calendar-wrapper" class="cc-calendar">
            <div class="cc-calendar-header">
                <button id="cc-prev-month" class="cc-btn">&laquo; Precedente</button>
                <div class="cc-month-year">
                    <h2 id="cc-current-month-label"></h2>
                </div>
                <!-- Semplice selettore -->
                <div class="cc-calendar-filters">
                    <select id="cc-month-select">
                        <option value="1">Gennaio</option><option value="2">Febbraio</option><option value="3">Marzo</option>
                        <option value="4">Aprile</option><option value="5">Maggio</option><option value="6">Giugno</option>
                        <option value="7">Luglio</option><option value="8">Agosto</option><option value="9">Settembre</option>
                        <option value="10">Ottobre</option><option value="11">Novembre</option><option value="12">Dicembre</option>
                    </select>
                    <select id="cc-year-select">
                        <?php 
                        $current_year = date('Y');
                        for($i = $current_year - 1; $i <= $current_year + 3; $i++){
                            echo '<option value="'.$i.'">'.$i.'</option>';
                        }
                        ?>
                    </select>
                </div>
                <button id="cc-next-month" class="cc-btn">Successivo &raquo;</button>
            </div>
            
            <div class="cc-calendar-grid">
                <div class="cc-calendar-days-header">
                    <div><span class="cc-desktop-day">Lunedì</span><span class="cc-mobile-day">L</span></div>
                    <div><span class="cc-desktop-day">Martedì</span><span class="cc-mobile-day">M</span></div>
                    <div><span class="cc-desktop-day">Mercoledì</span><span class="cc-mobile-day">M</span></div>
                    <div><span class="cc-desktop-day">Giovedì</span><span class="cc-mobile-day">G</span></div>
                    <div><span class="cc-desktop-day">Venerdì</span><span class="cc-mobile-day">V</span></div>
                </div>
                <div id="cc-calendar-body" class="cc-calendar-body">
                    <!-- I giorni saranno popolati tramite AJAX -->
                </div>
            </div>
            <div id="cc-loading" style="display:none; text-align: center; padding: 20px;">Caricamento...</div>
        </div>
        <?php
        return ob_get_clean();
    }

    public static function render_upcoming_courses_list() {
        $today = current_time('Y-m-d');
        $args = array(
            'post_type'      => 'courses',
            'posts_per_page' => -1,
            'meta_key'       => '_cc_start_date',
            'orderby'        => 'meta_value',
            'order'          => 'ASC',
            'meta_query'     => array(
                array(
                    'key'     => '_cc_start_date',
                    'value'   => $today,
                    'compare' => '>=',
                    'type'    => 'DATE'
                )
            ),
        );
        $courses = get_posts($args);

        $salute_courses = array();
        $bls_courses = array();
        $antincendio_courses = array();

        foreach($courses as $c) {
            $title = strtolower($c->post_title);
            if(strpos($title, 'bls') !== false || strpos($title, 'aed') !== false || strpos($title, 'src') !== false) {
                $bls_courses[] = $c;
            } elseif(strpos($title, 'antincendio') !== false) {
                $antincendio_courses[] = $c;
            } else {
                $salute_courses[] = $c;
            }
        }

        // Raggruppo per nome (case-insensitive per evitare doppioni)
        $salute_courses_grouped = array();
        foreach($salute_courses as $c) {
            $original_title = trim($c->post_title);
            $t_key = strtolower($original_title); // Chiave minuscola per raggruppare senza doppioni dovuti a maiuscole
            if(!isset($salute_courses_grouped[$t_key])) {
                $salute_courses_grouped[$t_key] = array(
                    'label' => $original_title,
                    'courses' => array()
                );
            }
            $salute_courses_grouped[$t_key]['courses'][] = $c;
        }

        ob_start();
        ?>
        <div class="cc-upcoming-list-container" style="margin-top: 50px;">
            
            <!-- BARRA DEI FILTRI DIVISA IN MACRO AREE -->
            <div class="cc-list-filters-wrapper" style="background:var(--cc-primary); border-radius:20px; padding:20px; margin-bottom: 30px; color:#fff;">
                
                <div style="margin-bottom:15px;">
                    <button class="cc-filter-btn active" data-filter="all" style="background:#fff; color:var(--cc-primary); border:none; padding:8px 20px; border-radius:20px; cursor:pointer; font-weight:bold; transition:all 0.3s ease;">Mostra Tutti i Corsi</button>
                </div>

                <div style="display:flex; flex-wrap:wrap; gap:20px;">
                    <!-- Filter Group 1 -->
                    <div style="flex:1; min-width:300px; border-right:1px solid rgba(255,255,255,0.2); padding-right:20px;">
                        <h4 style="color:#fff; margin-bottom:10px; font-size:14px; text-transform:uppercase; letter-spacing:1px; border-bottom:1px solid rgba(255,255,255,0.2); padding-bottom:5px;">Salute e Sicurezza</h4>
                        <div style="display:flex; flex-wrap:wrap; gap:8px;">
                            <button class="cc-filter-btn" data-filter="area-salute" style="background:transparent; color:#fff; border:1px solid rgba(255,255,255,0.5); padding:6px 15px; border-radius:15px; cursor:pointer; font-size:13px; transition:all 0.3s ease;">Tutti Salute e Sicurezza</button>
                            <?php foreach($salute_courses_grouped as $group_data) : $slug = sanitize_title($group_data['label']); ?>
                                <button class="cc-filter-btn" data-filter="course-<?php echo esc_attr($slug); ?>" style="background:transparent; color:#fff; border:1px solid rgba(255,255,255,0.5); padding:6px 15px; border-radius:15px; cursor:pointer; font-size:13px; transition:all 0.3s ease;"><?php echo esc_html($group_data['label']); ?></button>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Filter Group 2 -->
                    <div style="flex:1; min-width:300px;">
                        <h4 style="color:#fff; margin-bottom:10px; font-size:14px; text-transform:uppercase; letter-spacing:1px; border-bottom:1px solid rgba(255,255,255,0.2); padding-bottom:5px;">BLS-AED SRC e Antincendio</h4>
                        <div style="display:flex; flex-wrap:wrap; gap:8px;">
                            <button class="cc-filter-btn" data-filter="area-emergenze" style="background:transparent; color:#fff; border:1px solid rgba(255,255,255,0.5); padding:6px 15px; border-radius:15px; cursor:pointer; font-size:13px; transition:all 0.3s ease;">Tutti Corsi BLS/Antincendio</button>
                            <button class="cc-filter-btn" data-filter="bls" style="background:transparent; color:#fff; border:1px solid rgba(255,255,255,0.5); padding:6px 15px; border-radius:15px; cursor:pointer; font-size:13px; transition:all 0.3s ease;">BLS-AED SRC</button>
                            <button class="cc-filter-btn" data-filter="antincendio" style="background:transparent; color:#fff; border:1px solid rgba(255,255,255,0.5); padding:6px 15px; border-radius:15px; cursor:pointer; font-size:13px; transition:all 0.3s ease;">Antincendio</button>
                        </div>
                    </div>
                </div>

            </div>

            <!-- MACRO AREA 1 -->
            <div class="cc-macro-area cc-area-salute" data-categories="salute" style="margin-bottom: 40px;">
                <h3 style="border-bottom: 2px solid var(--cc-primary); padding-bottom: 10px; margin-bottom: 20px;">Riepilogo dei corsi in programma dedicati alla salute e sicurezza sul lavoro</h3>
                <div class="cc-list-grid" style="display:grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px;">
                    <?php 
                    if(!empty($salute_courses)) {
                        foreach($salute_courses as $c) {
                            $slug = sanitize_title(trim($c->post_title));
                            self::render_course_card($c, 'salute', 'course-'.$slug);
                        }
                    } else {
                        echo '<p>Nessun corso in programma in quest\'area.</p>';
                    }
                    ?>
                </div>
            </div>

            <!-- MACRO AREA 2 -->
            <div class="cc-macro-area cc-area-emergenze" data-categories="bls,antincendio">
                <h3 style="border-bottom: 2px solid var(--cc-primary); padding-bottom: 10px; margin-bottom: 20px;">Corsi di formazione BLS-AED SRC e Antincendio</h3>
                
                <div class="cc-sub-area cc-sub-bls" data-category="bls">
                    <h4 style="margin-bottom:15px; color:var(--cc-primary);">Corso BLS - AED SRC</h4>
                    <div class="cc-list-grid" style="display:grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px;">
                        <?php 
                        if(!empty($bls_courses)) {
                            foreach($bls_courses as $c) { self::render_course_card($c, 'bls', 'bls'); } 
                        } else {
                            echo '<p>Nessun corso in programma.</p>';
                        }
                        ?>
                    </div>
                </div>

                <div class="cc-sub-area cc-sub-antincendio" data-category="antincendio" style="margin-top: 30px;">
                    <h4 style="margin-bottom:15px; color:var(--cc-primary);">Corso Antincendio</h4>
                    <div class="cc-list-grid" style="display:grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px;">
                        <?php 
                        if(!empty($antincendio_courses)) {
                            foreach($antincendio_courses as $c) { self::render_course_card($c, 'antincendio', 'antincendio'); } 
                        } else {
                            echo '<p>Nessun corso in programma.</p>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
        
        <script>
            document.addEventListener('DOMContentLoaded', function(){
                var btns = document.querySelectorAll('.cc-filter-btn');
                btns.forEach(function(b){
                    b.addEventListener('click', function(){
                        // Reset all buttons style
                        btns.forEach(btn => {
                            btn.classList.remove('active');
                            if(btn.getAttribute('data-filter') === 'all') {
                                btn.style.background = 'rgba(255,255,255,0.2)';
                                btn.style.color = '#fff';
                            } else {
                                btn.style.background = 'transparent';
                                btn.style.color = '#fff';
                                btn.style.border = '1px solid rgba(255,255,255,0.5)';
                            }
                        });
                        
                        // Set active style
                        this.classList.add('active');
                        this.style.background = '#fff';
                        this.style.color = 'var(--cc-primary)';
                        this.style.border = '1px solid #fff';
                        
                        var filter = this.getAttribute('data-filter');
                        
                        var allCards = document.querySelectorAll('.cc-list-card');
                        var areaSalute = document.querySelector('.cc-area-salute');
                        var areaEmergenze = document.querySelector('.cc-area-emergenze');
                        var subBls = document.querySelector('.cc-sub-bls');
                        var subAnti = document.querySelector('.cc-sub-antincendio');
                        
                        if(filter === 'all') {
                            areaSalute.style.display = 'block';
                            areaEmergenze.style.display = 'block';
                            subBls.style.display = 'block';
                            subAnti.style.display = 'block';
                            allCards.forEach(c => c.style.display = 'flex');
                        } else if(filter === 'area-salute') {
                            areaSalute.style.display = 'block';
                            areaEmergenze.style.display = 'none';
                            allCards.forEach(c => {
                                if(c.classList.contains('cc-cat-salute')) c.style.display = 'flex';
                                else c.style.display = 'none';
                            });
                        } else if(filter === 'area-emergenze') {
                            areaSalute.style.display = 'none';
                            areaEmergenze.style.display = 'block';
                            subBls.style.display = 'block';
                            subAnti.style.display = 'block';
                            allCards.forEach(c => {
                                if(c.classList.contains('cc-cat-bls') || c.classList.contains('cc-cat-antincendio')) c.style.display = 'flex';
                                else c.style.display = 'none';
                            });
                        } else if(filter === 'bls') {
                            areaSalute.style.display = 'none';
                            areaEmergenze.style.display = 'block';
                            subBls.style.display = 'block';
                            subAnti.style.display = 'none';
                            allCards.forEach(c => {
                                if(c.classList.contains('cc-cat-bls')) c.style.display = 'flex';
                                else c.style.display = 'none';
                            });
                        } else if(filter === 'antincendio') {
                            areaSalute.style.display = 'none';
                            areaEmergenze.style.display = 'block';
                            subBls.style.display = 'none';
                            subAnti.style.display = 'block';
                            allCards.forEach(c => {
                                if(c.classList.contains('cc-cat-antincendio')) c.style.display = 'flex';
                                else c.style.display = 'none';
                            });
                        } else {
                            // Si tratta di un corso specifico della prima macro area
                            areaSalute.style.display = 'block';
                            areaEmergenze.style.display = 'none';
                            // Controllo sui post in cui il contenitore si applicherà (eventualmente potrei nascondere i sub-blocchi in altre macro, ma areaEmergenze è none)
                            allCards.forEach(c => {
                                if(c.getAttribute('data-course-slug') === filter) c.style.display = 'flex';
                                else c.style.display = 'none';
                            });
                        }
                    });
                });
            });
        </script>
        <?php
        return ob_get_clean();
    }

    private static function render_course_card($course, $cat_class, $slug = '') {
        $date = get_post_meta($course->ID, '_cc_start_date', true);
        $icon = self::get_course_icon_html($course->ID);
        $link = get_permalink($course->ID);
        $date_formatted = $date ? date_i18n('j F Y', strtotime($date)) : '-';
        ?>
        <a href="<?php echo esc_url($link); ?>" class="cc-list-card cc-cat-<?php echo esc_attr($cat_class); ?>" data-course-slug="<?php echo esc_attr($slug); ?>" style="text-decoration:none; color:inherit; background:#ffffff; border:1px solid #e2e8f0; border-radius:10px; padding:20px; display:flex; flex-direction:column; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); transition:transform 0.2s, box-shadow 0.2s;" onmouseover="this.style.transform='translateY(-5px)'; this.style.boxShadow='0 10px 15px -3px rgba(0,0,0,0.1)';" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 6px -1px rgba(0,0,0,0.05)';">
            <div class="cc-card-icon" style="margin-bottom: 15px; text-align:center;">
                <?php if($icon) { 
                    echo str_replace('<img ', '<img style="max-height:60px; max-width:100%; object-fit:contain;" ', $icon); 
                } ?>
            </div>
            <h4 style="margin: 0 0 15px 0; font-size: 16px; line-height:1.4; color: var(--cc-primary); text-align:center; flex-grow:1;"><?php echo esc_html($course->post_title); ?></h4>
            <div class="cc-card-date" style="font-size:14px; color:#666; font-weight:bold; text-align:center; border-top:1px solid #e2e8f0; padding-top:10px;">
                <span class="dashicons dashicons-calendar-alt" style="font-size:16px; width:16px; height:16px; vertical-align:middle; position:relative; top:-2px;"></span> <?php echo esc_html($date_formatted); ?>
            </div>
        </a>
        <?php
    }

    public static function ajax_load_calendar() {
        $month = isset($_POST['month']) ? intval($_POST['month']) : current_time('m');
        $year = isset($_POST['year']) ? intval($_POST['year']) : current_time('Y');

        $first_day = "$year-" . str_pad($month, 2, '0', STR_PAD_LEFT) . "-01";
        $last_day  = date("Y-m-t", strtotime($first_day));

        $args = array(
            'post_type'      => 'courses',
            'posts_per_page' => -1,
            'meta_query'     => array(
                'relation' => 'AND',
                array(
                    'key'     => '_cc_start_date',
                    'value'   => array($first_day, $last_day),
                    'compare' => 'BETWEEN',
                    'type'    => 'DATE'
                )
            ),
        );
        $courses = get_posts($args);
        
        $courses_by_date = array();
        foreach($courses as $course) {
            $date = get_post_meta($course->ID, '_cc_start_date', true);
            $icon_html = self::get_course_icon_html($course->ID);

            $courses_by_date[$date][] = array(
                'id' => $course->ID,
                'title' => $course->post_title,
                'link' => get_permalink($course->ID),
                'icon_html' => $icon_html
            );
            
            $end_date = get_post_meta($course->ID, '_cc_end_date', true);
            if(!empty($end_date) && $end_date != $date) {
                $current = strtotime($date);
                $end = strtotime($end_date);
                while($current < $end) {
                    $current = strtotime('+1 day', $current);
                    $d_str = date('Y-m-d', $current);
                    if( date('N', $current) <= 5 ) {
                        $courses_by_date[$d_str][] = array(
                            'id' => $course->ID,
                            'title' => $course->post_title . ' (Cont.)',
                            'link' => get_permalink($course->ID),
                            'icon_html' => $icon_html
                        );
                    }
                }
            }
        }

        $first_day_of_month_ts = strtotime($first_day);
        $days_in_month = date('t', $first_day_of_month_ts);
        $first_day_w = date('N', $first_day_of_month_ts); 
        
        $html = '';

        $offset = $first_day_w - 1; 
        if($offset > 4) $offset = 0; 
        
        if($offset > 0 && $first_day_w <= 5) {
            for($i = 0; $i < $offset; $i++) {
                $html .= '<div class="cc-day cc-empty"></div>';
            }
        }

        $today_str = current_time('Y-m-d');

        for($day = 1; $day <= $days_in_month; $day++) {
            $date_str = "$year-" . str_pad($month, 2, '0', STR_PAD_LEFT) . "-" . str_pad($day, 2, '0', STR_PAD_LEFT);
            $ts = strtotime($date_str);
            $weekday = date('N', $ts);
            
            if($weekday > 5) continue; 

            $is_past = ($date_str < $today_str) ? ' cc-past-day' : '';

            $html .= '<div class="cc-day' . $is_past . '">';
            $html .= '<div class="cc-date-num">' . $day . '</div>';
            
            if(isset($courses_by_date[$date_str])) {
                foreach($courses_by_date[$date_str] as $c) {
                    $html .= '<a href="'.esc_url($c['link']).'" class="cc-course-badge">';
                    $html .= $c['icon_html'] . '<span class="cc-course-title">' . esc_html($c['title']) . '</span>';
                    $html .= '</a>';
                }
            }
            
            $html .= '</div>';
        }

        wp_send_json_success(array(
            'html' => $html,
            'month_label' => date_i18n('F Y', $first_day_of_month_ts)
        ));
    }
}
CC_Shortcodes::init();
