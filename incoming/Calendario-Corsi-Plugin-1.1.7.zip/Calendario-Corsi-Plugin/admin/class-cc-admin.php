<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CC_Admin {
    public static function init() {
        add_action( 'add_meta_boxes', array( __CLASS__, 'add_course_meta_boxes' ) );
        add_action( 'save_post', array( __CLASS__, 'save_course_meta_data' ) );
        add_action( 'trashed_post', array( __CLASS__, 'recalculate_course_enrollments' ) );
        add_action( 'untrashed_post', array( __CLASS__, 'recalculate_course_enrollments' ) );
        add_action( 'delete_post', array( __CLASS__, 'recalculate_course_enrollments' ) );
        add_action( 'admin_footer-edit.php', array( __CLASS__, 'add_delete_confirmation_script' ) );
        
        // Logica per Duplicazione Corsi
        add_filter( 'post_row_actions', array( __CLASS__, 'add_duplicate_post_link' ), 10, 2 );
        add_action( 'admin_action_cc_duplicate_course', array( __CLASS__, 'duplicate_course_action' ) );

        // Strumento di Test Email nel backend
        add_action('admin_menu', array(__CLASS__, 'add_plugin_admin_menus'));
    }

    public static function add_plugin_admin_menus() {
        add_submenu_page(
            'edit.php?post_type=courses',
            'Strumento Test Email',
            'Invia Test Email',
            'manage_options',
            'cc-test-email',
            array( __CLASS__, 'render_test_email_page' )
        );
    }

    public static function render_test_email_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Non hai i permessi per accedere a questa pagina.' );
        }

        $message = '';
        if ( isset( $_POST['cc_send_test_email'] ) && isset( $_POST['test_email_address'] ) ) {
            check_admin_referer( 'cc_test_email_action', 'cc_test_email_nonce' );
            
            $to = sanitize_email( $_POST['test_email_address'] );
            
            $admin_email = get_option('admin_email');
            $wp_mail_smtp_options = get_option('wp_mail_smtp');
            if ( is_array($wp_mail_smtp_options) && !empty($wp_mail_smtp_options['mail']['from_email']) ) {
                $admin_email = sanitize_email( $wp_mail_smtp_options['mail']['from_email'] );
            }
            
            add_filter( 'wp_mail_content_type', function() {
                return 'text/html';
            });

            $subject = 'Test di funzionamento sistema prenotazione - Calendario Corsi';
            $body = '<h2>Test Email Riuscito!</h2><p>Se vedi questo messaggio, il plugin Calendario Corsi sta comunicando correttamente con il tuo sistema SMTP.</p><p>Assicurati di controllare che la mail (e le prossime iscrizioni) ti arrivino. SendGrid ora le processerà regolarmente, delegando interamente gli headers a WP Mail SMTP.</p>';

            $result = wp_mail( $to, $subject, $body );

            if ( $result ) {
                $message = '<div class="notice notice-success is-dismissible"><p>Test Inviato correttamente a <strong>' . esc_html($to) . '</strong> (Senza forzare testate esterne).</p></div>';
            } else {
                $message = '<div class="notice notice-error is-dismissible"><p>Errore durante l\'invio (wp_mail ha ritornato false). Controlla il log di WP Mail SMTP.</p></div>';
            }
        }

        ?>
        <div class="wrap">
            <h1>Test di Invio Email - Calendario Corsi</h1>
            <p>Utilizza questo strumento per verificare se il server permette inviare le stesse email (con gli stessi Header esatti) generate all'atto dell'iscrizione.</p>
            <?php echo $message; ?>
            <form method="post" action="">
                <?php wp_nonce_field( 'cc_test_email_action', 'cc_test_email_nonce' ); ?>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="test_email_address">Invia a:</label></th>
                        <td>
                            <input name="test_email_address" type="email" id="test_email_address" value="<?php echo esc_attr( get_option('admin_email') ); ?>" class="regular-text" required>
                        </td>
                    </tr>
                </table>
                <p class="submit">
                    <input type="submit" name="cc_send_test_email" id="submit" class="button button-primary" value="Invia Mail di Test">
                </p>
            </form>
        </div>
        <?php
    }

    public static function add_duplicate_post_link( $actions, $post ) {
        if ( $post->post_type === 'courses' && current_user_can( 'edit_posts' ) ) {
            $url = wp_nonce_url(
                admin_url( 'admin.php?action=cc_duplicate_course&post=' . $post->ID ),
                'cc_duplicate_course_' . $post->ID
            );
            $actions['duplicate'] = '<a href="' . esc_url( $url ) . '" title="Duplica questo corso">Duplica</a>';
        }
        return $actions;
    }

    public static function duplicate_course_action() {
        if ( ! ( isset( $_GET['post'] ) || isset( $_POST['post'] ) || ( isset( $_REQUEST['action'] ) && 'cc_duplicate_course' == $_REQUEST['action'] ) ) ) {
            wp_die( 'Nessun corso fornito per la duplicazione.' );
        }

        if ( ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( $_GET['_wpnonce'], 'cc_duplicate_course_' . $_GET['post'] ) ) {
            wp_die( 'Errore di sicurezza, riprova.' );
        }

        $post_id = (isset($_GET['post']) ? absint( $_GET['post'] ) : absint( $_POST['post'] ) );
        $post = get_post( $post_id );

        if ( isset( $post ) && $post != null ) {
            $current_user = wp_get_current_user();
            $new_post_author = $current_user->ID;

            $args = array(
                'comment_status' => $post->comment_status,
                'ping_status'    => $post->ping_status,
                'post_author'    => $new_post_author,
                'post_content'   => $post->post_content,
                'post_excerpt'   => $post->post_excerpt,
                'post_name'      => $post->post_name,
                'post_parent'    => $post->post_parent,
                'post_password'  => $post->post_password,
                'post_status'    => 'draft', // Crea come bozza per sicurezza
                'post_title'     => $post->post_title . ' (Copia)',
                'post_type'      => $post->post_type,
                'to_ping'        => $post->to_ping,
                'menu_order'     => $post->menu_order
            );

            $new_post_id = wp_insert_post( $args );

            // Copia i metadati del post originale, scartando gli iscritti attuali (il nuovo corso parte da 0)
            $post_meta_infos = get_post_custom( $post_id );
            if ( count( $post_meta_infos ) != 0 ) {
                foreach ( $post_meta_infos as $meta_key => $meta_values ) {
                    if ( $meta_key === '_cc_enrolled_count' || $meta_key === '_cc_participants' ) {
                        continue;
                    }
                    foreach ( $meta_values as $meta_value ) {
                        $meta_value = maybe_unserialize( $meta_value );
                        add_post_meta( $new_post_id, $meta_key, $meta_value );
                    }
                }
            }

            // Aggiungi manualmente il contatore a 0 per il corso nuovo
            update_post_meta( $new_post_id, '_cc_enrolled_count', 0 );

            wp_redirect( admin_url( 'post.php?action=edit&post=' . $new_post_id ) );
            exit;
        } else {
            wp_die( 'Creazione fallita: impossibile trovare il corso originario.' );
        }
    }

    public static function add_course_meta_boxes() {
        add_meta_box(
            'cc_course_details',
            'Dettagli del Corso',
            array( __CLASS__, 'render_course_details_meta_box' ),
            'courses',
            'normal',
            'high'
        );
        add_meta_box(
            'cc_enrollment_details',
            'Dettagli Iscrizione',
            array( __CLASS__, 'render_enrollment_details_meta_box' ),
            'enrollment',
            'normal',
            'high'
        );
    }

    public static function render_course_details_meta_box( $post ) {
        wp_nonce_field( 'cc_save_course_data', 'cc_course_meta_nonce' );

        $start_date         = get_post_meta( $post->ID, '_cc_start_date', true );
        $end_date           = get_post_meta( $post->ID, '_cc_end_date', true );
        $time               = get_post_meta( $post->ID, '_cc_time', true );
        $price              = get_post_meta( $post->ID, '_cc_price', true );
        $location           = get_post_meta( $post->ID, '_cc_location', true );
        $certificate_type   = get_post_meta( $post->ID, '_cc_certificate_type', true );
        $duration           = get_post_meta( $post->ID, '_cc_duration', true );
        $max_participants   = get_post_meta( $post->ID, '_cc_max_participants', true );
        $min_participants   = get_post_meta( $post->ID, '_cc_min_participants', true );
        $presentation       = get_post_meta( $post->ID, '_cc_presentation', true );
        $methodology        = get_post_meta( $post->ID, '_cc_methodology', true );
        $cancellation       = get_post_meta( $post->ID, '_cc_cancellation', true );
        $contents           = get_post_meta( $post->ID, '_cc_contents', true );
        $icon               = get_post_meta( $post->ID, '_cc_course_icon', true );
        $enrolled_count     = get_post_meta( $post->ID, '_cc_enrolled_count', true );
        if ( $enrolled_count === '' ) $enrolled_count = 0;
        
        $profilo_professionale = get_post_meta( $post->ID, '_cc_profilo_professionale', true );
        $gruppo_target       = get_post_meta( $post->ID, '_cc_gruppo_target', true );
        $obiettivi           = get_post_meta( $post->ID, '_cc_obiettivi_didattici', true );
        $strumenti           = get_post_meta( $post->ID, '_cc_strumenti', true );
        $modalita_svolgimento = get_post_meta( $post->ID, '_cc_modalita_svolgimento', true );
        $ente_erogatore      = get_post_meta( $post->ID, '_cc_ente_erogatore', true );
        $formatore           = get_post_meta( $post->ID, '_cc_formatore', true );
        
        $contents_list      = !empty($contents) ? json_decode($contents, true) : array();
        $obiettivi_list     = !empty($obiettivi) ? json_decode($obiettivi, true) : array();
        
        $custom_icons = get_option( 'cc_custom_icons', array() );

        ?>
        <style>
            .cc-meta-row { margin-bottom: 15px; }
            .cc-meta-row label { display: block; font-weight: bold; margin-bottom: 5px; }
            .cc-meta-row input[type="text"], .cc-meta-row input[type="number"], .cc-meta-row textarea { width: 100%; max-width: 600px; padding: 5px; }
            .cc-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
            .cc-meta-item { display: flex; gap: 10px; margin-bottom: 5px; }
            .cc-meta-item input { flex: 1; }
            .cc-icon-selector { display:flex; flex-wrap:wrap; gap:10px; margin-bottom: 10px; }
            .cc-icon-selector label { display: inline-flex; align-items: center; gap: 5px; background: #f0f0f1; padding: 5px 10px; border-radius: 4px; cursor: pointer; }
            .cc-icon-selector input[type="radio"] { margin: 0; }
            .cc-icon-preview { height: 24px; width: auto; max-width: 24px; vertical-align: middle; }
        </style>

        <div class="cc-meta-row" style="background: #f9f9fa; padding: 15px; border: 1px solid #e2e8f0; border-radius: 8px;">
            <label>Icona del Corso</label>
            <p style="font-size: 13px; color: #666; margin-top:0;">Seleziona un'icona precedentemente caricata o inserisci un nuovo URL. L'URL verrà salvato per utilizzi futuri.</p>
            
            <div class="cc-icon-selector">
                <label>
                    <input type="radio" name="cc_course_icon" value="" <?php checked($icon, ''); ?>>
                    Nessuna icona
                </label>
                <?php foreach ( $custom_icons as $custom_icon_url ) : ?>
                    <label>
                        <input type="radio" name="cc_course_icon" value="<?php echo esc_attr($custom_icon_url); ?>" <?php checked($icon, $custom_icon_url); ?>>
                        <img src="<?php echo esc_url($custom_icon_url); ?>" class="cc-icon-preview" alt="Icon">
                    </label>
                <?php endforeach; ?>
            </div>
            
            <div style="margin-top: 10px;">
                <label for="cc_new_custom_icon">URL per una *nuova* icona (sovrascrive la selezione se compilato)</label>
                <input type="text" id="cc_new_custom_icon" name="cc_new_custom_icon" value="" placeholder="https://esempio.com/icona.png (o SVG)">
            </div>
        </div>

        <div class="cc-grid">
            <div class="cc-meta-row">
                <label for="cc_start_date">Data di inizio</label>
                <input type="date" id="cc_start_date" name="cc_start_date" value="<?php echo esc_attr( $start_date ); ?>" required>
            </div>
            <div class="cc-meta-row">
                <label for="cc_end_date">Data di fine (opzionale)</label>
                <input type="date" id="cc_end_date" name="cc_end_date" value="<?php echo esc_attr( $end_date ); ?>">
            </div>
            <div class="cc-meta-row">
                <label for="cc_time">Orario</label>
                <input type="text" id="cc_time" name="cc_time" value="<?php echo esc_attr( $time ); ?>">
            </div>
            <div class="cc-meta-row">
                <label for="cc_duration">Durata</label>
                <input type="text" id="cc_duration" name="cc_duration" value="<?php echo esc_attr( $duration ); ?>">
            </div>
            <div class="cc-meta-row">
                <label for="cc_price">Prezzo</label>
                <input type="text" id="cc_price" name="cc_price" value="<?php echo esc_attr( $price ); ?>" placeholder="Es. 150.00 oppure Gratuito">
            </div>
            <div class="cc-meta-row">
                <label for="cc_location">Luogo</label>
                <input type="text" id="cc_location" name="cc_location" value="<?php echo esc_attr( $location ); ?>">
            </div>
            <div class="cc-meta-row">
                <label for="cc_certificate_type">Tipo di attestazione</label>
                <input type="text" id="cc_certificate_type" name="cc_certificate_type" value="<?php echo esc_attr( $certificate_type ); ?>">
            </div>
            <div class="cc-meta-row">
                <label for="cc_max_participants">Max Partecipanti Totali</label>
                <input type="number" id="cc_max_participants" name="cc_max_participants" value="<?php echo esc_attr( $max_participants ); ?>" required>
            </div>
            <div class="cc-meta-row">
                <label for="cc_enrolled_count">Iscritti Attuali (Posti Occupati)</label>
                <input type="number" id="cc_enrolled_count" name="cc_enrolled_count" value="<?php echo esc_attr( $enrolled_count ); ?>" min="0">
                <p style="font-size:11px; color:#666; margin:0;">Modificabile manualmente per conteggiare iscritti "offline".</p>
            </div>
            <div class="cc-meta-row">
                <label for="cc_ente_erogatore">Ente erogatore</label>
                <input type="text" id="cc_ente_erogatore" name="cc_ente_erogatore" value="<?php echo esc_attr( $ente_erogatore ); ?>">
            </div>
            <div class="cc-meta-row">
                <label for="cc_formatore">Formatore</label>
                <input type="text" id="cc_formatore" name="cc_formatore" value="<?php echo esc_attr( $formatore ); ?>">
            </div>
        </div>

        <hr>

        <div class="cc-meta-row">
            <label for="cc_presentation">Testo Presentazione</label>
            <textarea id="cc_presentation" name="cc_presentation" rows="4"><?php echo esc_textarea( $presentation ); ?></textarea>
        </div>

        <div class="cc-meta-row">
            <label>Contenuti del corso (Lista)</label>
            <div id="cc_contents_wrapper">
                <?php 
                if(!empty($contents_list)){
                    foreach($contents_list as $item){
                        echo '<div class="cc-meta-item"><input type="text" name="cc_contents[]" value="'.esc_attr($item).'"><button type="button" class="button remove-content">Rimuovi</button></div>';
                    }
                } else {
                    echo '<div class="cc-meta-item"><input type="text" name="cc_contents[]" value=""><button type="button" class="button remove-content">Rimuovi</button></div>';
                }
                ?>
            </div>
            <button type="button" class="button" id="cc_add_content">Aggiungi Voce</button>
        </div>

        <div class="cc-meta-row">
            <label for="cc_profilo_professionale">Profilo professionale</label>
            <textarea id="cc_profilo_professionale" name="cc_profilo_professionale" rows="4"><?php echo esc_textarea( $profilo_professionale ); ?></textarea>
        </div>

        <div class="cc-meta-row">
            <label for="cc_gruppo_target">Gruppo target</label>
            <textarea id="cc_gruppo_target" name="cc_gruppo_target" rows="4"><?php echo esc_textarea( $gruppo_target ); ?></textarea>
        </div>

        <div class="cc-meta-row">
            <label>Obiettivi didattici (Lista)</label>
            <div id="cc_obiettivi_wrapper">
                <?php 
                if(!empty($obiettivi_list)){
                    foreach($obiettivi_list as $item){
                        echo '<div class="cc-meta-item"><input type="text" name="cc_obiettivi_didattici[]" value="'.esc_attr($item).'"><button type="button" class="button remove-obiettivo">Rimuovi</button></div>';
                    }
                } else {
                    echo '<div class="cc-meta-item"><input type="text" name="cc_obiettivi_didattici[]" value=""><button type="button" class="button remove-obiettivo">Rimuovi</button></div>';
                }
                ?>
            </div>
            <button type="button" class="button" id="cc_add_obiettivo">Aggiungi Obiettivo</button>
        </div>

        <div class="cc-meta-row">
            <label for="cc_methodology">Metodologia</label>
            <textarea id="cc_methodology" name="cc_methodology" rows="4"><?php echo esc_textarea( $methodology ); ?></textarea>
        </div>
        
        <div class="cc-meta-row">
            <label for="cc_strumenti">Strumenti</label>
            <textarea id="cc_strumenti" name="cc_strumenti" rows="4"><?php echo esc_textarea( $strumenti ); ?></textarea>
        </div>

        <div class="cc-meta-row">
            <label for="cc_modalita_svolgimento">Modalità di svolgimento</label>
            <textarea id="cc_modalita_svolgimento" name="cc_modalita_svolgimento" rows="4"><?php echo esc_textarea( $modalita_svolgimento ); ?></textarea>
        </div>

        <div class="cc-meta-row">
            <label for="cc_cancellation">Disdetta e rimborso</label>
            <textarea id="cc_cancellation" name="cc_cancellation" rows="4"><?php echo esc_textarea( $cancellation ); ?></textarea>
        </div>

        <script>
            jQuery(document).ready(function($) {
                $('#cc_add_content').on('click', function(e){
                    e.preventDefault();
                    $('#cc_contents_wrapper').append('<div class="cc-meta-item"><input type="text" name="cc_contents[]" value=""><button type="button" class="button remove-content">X</button></div>');
                });
                
                $(document).on('click', '.remove-content', function(e){
                    e.preventDefault();
                    if($('#cc_contents_wrapper .cc-meta-item').length > 1) {
                        $(this).parent().remove();
                    } else {
                        $(this).siblings('input').val('');
                    }
                });

                $('#cc_add_obiettivo').on('click', function(e){
                    e.preventDefault();
                    $('#cc_obiettivi_wrapper').append('<div class="cc-meta-item"><input type="text" name="cc_obiettivi_didattici[]" value=""><button type="button" class="button remove-obiettivo">X</button></div>');
                });
                
                $(document).on('click', '.remove-obiettivo', function(e){
                    e.preventDefault();
                    if($('#cc_obiettivi_wrapper .cc-meta-item').length > 1) {
                        $(this).parent().remove();
                    } else {
                        $(this).siblings('input').val('');
                    }
                });
            });
        </script>
        <?php
    }

    public static function render_enrollment_details_meta_box( $post ) {
        $course_id       = get_post_meta( $post->ID, '_cc_course_id', true );
        $billing_company = get_post_meta( $post->ID, '_cc_billing_company', true );
        $billing_email   = get_post_meta( $post->ID, '_cc_billing_email', true );
        $billing_phone   = get_post_meta( $post->ID, '_cc_billing_phone', true );
        $billing_vat     = get_post_meta( $post->ID, '_cc_billing_vat', true );
        $billing_address = get_post_meta( $post->ID, '_cc_billing_address', true );
        $participants    = get_post_meta( $post->ID, '_cc_participants', true );
        
        ?>
        <style>
            .cc-enrollment-box p { margin: 12px 0; font-size: 14px; }
            .cc-enrollment-box strong { display: inline-block; width: 140px; color: #1d2327; }
            .cc-copy-val { user-select: all; background: #fff; padding: 4px 8px; border-radius: 4px; border: 1px solid #8c8f94; display: inline-block; min-width: 250px; color: #2271b1; font-weight: 500;}
            .cc-copy-btn { margin-left: 8px !important; }
            .cc-copy-msg { color: #00a32a; font-size: 13px; margin-left: 5px; display: none; font-weight: bold; }
        </style>
        <script>
            function ccCopyToClip(btn) {
                var container = btn.closest('p, li');
                var valSpan = container.querySelector('.cc-copy-val');
                var text = valSpan ? valSpan.innerText : '';
                navigator.clipboard.writeText(text).then(function() {
                    var msg = container.querySelector('.cc-copy-msg');
                    if(msg) {
                        msg.style.display = 'inline';
                        setTimeout(function(){ msg.style.display = 'none'; }, 2000);
                    }
                });
            }
        </script>
        <div class="cc-enrollment-box">
        <?php
        
        $course_date_raw = $course_id ? get_post_meta( $course_id, '_cc_start_date', true ) : '';
        $course_date_str = $course_date_raw ? date_i18n('j F Y', strtotime($course_date_raw)) : '';
        
        echo '<h2 style="padding:0; margin: 0 0 5px 0;">Corso prenotato: <span style="color:var(--cc-primary);">' . ( $course_id ? esc_html(get_the_title($course_id)) : 'N/A' ) . '</span></h2>';
        if ($course_date_str) {
            echo '<p style="margin: 0 0 20px 0; font-size: 15px; color: #50575e;"><strong>Data del corso:</strong> ' . esc_html($course_date_str) . '</p>';
        } else {
            echo '<p style="margin: 0 0 20px 0;"></p>';
        }
        
        echo '<h3 style="border-bottom: 1px solid #dcdcde; padding-bottom: 5px;">Dati Referente / Fatturazione</h3>';
        
        $fields = array(
            'Azienda/Nome' => $billing_company,
            'Email'        => $billing_email,
            'Telefono'     => $billing_phone,
            'Partita IVA'  => $billing_vat,
            'Indirizzo'    => $billing_address,
        );
        
        foreach($fields as $label => $val) {
            echo '<p>';
            echo '<strong>'.$label.':</strong> ';
            echo '<span class="cc-copy-val">' . esc_html(empty($val) ? '-' : $val) . '</span>';
            if(!empty($val)) {
                echo ' <button type="button" class="button button-small cc-copy-btn" onclick="ccCopyToClip(this)">Copia</button>';
                echo ' <span class="cc-copy-msg">✓ Copiato!</span>';
            }
            echo '</p>';
        }

        echo '<h3 style="border-bottom: 1px solid #dcdcde; padding-bottom: 5px; margin-top: 30px;">Partecipanti iscritti (' . (is_array($participants) ? count($participants) : 0) . ')</h3>';
        if ( is_array($participants) && !empty($participants) ) {
            echo '<ol style="background: #f0f0f1; padding: 20px 20px 20px 40px; border: 1px solid #c3c4c7; border-radius: 4px; margin-top: 15px;">';
            foreach($participants as $p) {
                // Retrocompatibilità: gestiamo sia vecchi iscritti (con birthplace) che nuovi (con birthdate)
                $birthplace_str = !empty($p['birthplace']) ? ' a ' . $p['birthplace'] : '';
                $birthdate_str  = !empty($p['birthdate']) ? ' il ' . date('d/m/Y', strtotime($p['birthdate'])) : '';
                $nato_str = ($birthplace_str || $birthdate_str) ? ' (Nato/a' . $birthplace_str . $birthdate_str . ')' : '';
                
                $p_str = $p['name'] . $nato_str;
                echo '<li style="margin-bottom: 15px; font-size: 14px;">';
                echo '<span class="cc-copy-val" style="min-width: 350px;">' . esc_html($p_str) . '</span>';
                echo ' <button type="button" class="button button-small cc-copy-btn" onclick="ccCopyToClip(this)">Copia</button>';
                echo ' <span class="cc-copy-msg">✓ Copiato!</span>';
                echo '</li>';
            }
            echo '</ol>';
        } else {
            echo '<p>Nessun partecipante trovato.</p>';
        }
        echo '</div>';
    }

    public static function save_course_meta_data( $post_id ) {
        if ( ! isset( $_POST['cc_course_meta_nonce'] ) || ! wp_verify_nonce( $_POST['cc_course_meta_nonce'], 'cc_save_course_data' ) ) return;
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;

        $fields = array(
            '_cc_start_date' => 'cc_start_date',
            '_cc_end_date' => 'cc_end_date',
            '_cc_time' => 'cc_time',
            '_cc_price' => 'cc_price',
            '_cc_location' => 'cc_location',
            '_cc_certificate_type' => 'cc_certificate_type',
            '_cc_duration' => 'cc_duration',
            '_cc_max_participants' => 'cc_max_participants',
            '_cc_min_participants' => 'cc_min_participants',
            '_cc_presentation' => 'cc_presentation',
            '_cc_methodology' => 'cc_methodology',
            '_cc_cancellation' => 'cc_cancellation',
            '_cc_profilo_professionale' => 'cc_profilo_professionale',
            '_cc_gruppo_target'         => 'cc_gruppo_target',
            '_cc_strumenti'             => 'cc_strumenti',
            '_cc_modalita_svolgimento'  => 'cc_modalita_svolgimento',
            '_cc_ente_erogatore'        => 'cc_ente_erogatore',
            '_cc_formatore'             => 'cc_formatore',
        );

        foreach ( $fields as $meta_key => $post_key ) {
            if ( isset( $_POST[ $post_key ] ) ) {
                $value = $_POST[ $post_key ];
                if ( in_array( $meta_key, array( '_cc_presentation', '_cc_methodology', '_cc_cancellation', '_cc_profilo_professionale', '_cc_gruppo_target', '_cc_strumenti', '_cc_modalita_svolgimento' ) ) ) {
                    $value = sanitize_textarea_field( $value );
                } else {
                    $value = sanitize_text_field( $value );
                }
                update_post_meta( $post_id, $meta_key, $value );
            }
        }

        // Gestione iscritti (offset manuale per prenotazioni offline)
        if ( isset( $_POST['cc_enrolled_count'] ) ) {
            $posted_enrolled = intval( $_POST['cc_enrolled_count'] );
            
            $args = array(
                'post_type'      => 'enrollment',
                'post_status'    => 'publish',
                'posts_per_page' => -1,
                'meta_query'     => array(
                    array(
                        'key'     => '_cc_course_id',
                        'value'   => $post_id,
                        'compare' => '='
                    )
                )
            );
            $enrollments = get_posts( $args );
            $real_enrolled = 0;
            foreach ( $enrollments as $enr ) {
                $participants = get_post_meta( $enr->ID, '_cc_participants', true );
                if ( is_array( $participants ) ) {
                    $real_enrolled += count( $participants );
                }
            }
            
            $manual_offset = $posted_enrolled - $real_enrolled;
            update_post_meta( $post_id, '_cc_manual_offset', $manual_offset );
            update_post_meta( $post_id, '_cc_enrolled_count', $posted_enrolled );
        }

        // Gestione Icone Personalizzate
        $icon_value = isset($_POST['cc_course_icon']) ? sanitize_text_field($_POST['cc_course_icon']) : '';
        if ( !empty( $_POST['cc_new_custom_icon'] ) ) {
            $new_icon_url = esc_url_raw( $_POST['cc_new_custom_icon'] );
            $custom_icons = get_option( 'cc_custom_icons', array() );
            if ( !in_array( $new_icon_url, $custom_icons ) ) {
                $custom_icons[] = $new_icon_url;
                update_option( 'cc_custom_icons', $custom_icons );
            }
            $icon_value = $new_icon_url;
        }
        update_post_meta( $post_id, '_cc_course_icon', $icon_value );

        if ( isset( $_POST['cc_contents'] ) && is_array( $_POST['cc_contents'] ) ) {
            $contents = array_filter( array_map( 'sanitize_text_field', wp_unslash( $_POST['cc_contents'] ) ), function($v) { return !empty(trim($v)); } );
            update_post_meta( $post_id, '_cc_contents', wp_slash( wp_json_encode( array_values( $contents ), JSON_UNESCAPED_UNICODE ) ) );
        } else {
            update_post_meta( $post_id, '_cc_contents', wp_slash( wp_json_encode( array() ) ) );
        }
        
        if ( isset( $_POST['cc_obiettivi_didattici'] ) && is_array( $_POST['cc_obiettivi_didattici'] ) ) {
            $obiettivi = array_filter( array_map( 'sanitize_text_field', wp_unslash( $_POST['cc_obiettivi_didattici'] ) ), function($v) { return !empty(trim($v)); } );
            update_post_meta( $post_id, '_cc_obiettivi_didattici', wp_slash( wp_json_encode( array_values( $obiettivi ), JSON_UNESCAPED_UNICODE ) ) );
        } else {
            update_post_meta( $post_id, '_cc_obiettivi_didattici', wp_slash( wp_json_encode( array() ) ) );
        }
    }

    public static function recalculate_course_enrollments( $post_id ) {
        if ( get_post_type( $post_id ) !== 'enrollment' ) {
            return;
        }

        $course_id = get_post_meta( $post_id, '_cc_course_id', true );
        if ( ! $course_id ) return;

        $args = array(
            'post_type'      => 'enrollment',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'meta_query'     => array(
                array(
                    'key'     => '_cc_course_id',
                    'value'   => $course_id,
                    'compare' => '='
                )
            )
        );
        $enrollments = get_posts( $args );
        
        $total_enrolled = 0;
        foreach ( $enrollments as $enr ) {
            $participants = get_post_meta( $enr->ID, '_cc_participants', true );
            if ( is_array( $participants ) ) {
                $total_enrolled += count( $participants );
            }
        }
        
        $manual_offset = intval( get_post_meta( $course_id, '_cc_manual_offset', true ) );
        update_post_meta( $course_id, '_cc_enrolled_count', $total_enrolled + $manual_offset );
    }

    public static function add_delete_confirmation_script() {
        global $post_type;
        if ( 'enrollment' === $post_type ) {
            ?>
            <script>
            jQuery(document).ready(function($){
                $('.submitdelete').on('click', function(e){
                    if(!confirm('Sei sicuro di voler spostare questa iscrizione nel cestino? I posti torneranno immediatamente vuoti e disponibili nel corso relativo.')){
                        e.preventDefault();
                    }
                });
            });
            </script>
            <?php
        }
    }
}
CC_Admin::init();
