jQuery(document).ready(function($) {

    /* ==================== CALENDARIO ==================== */
    if ($('#cc-calendar-wrapper').length) {
        let currentDate = new Date();
        let currentMonth = currentDate.getMonth() + 1;
        let currentYear = currentDate.getFullYear();

        function loadCalendar(month, year) {
            let body = $('#cc-calendar-body');
            
            // Inizia il fade out tramite CSS
            body.css({
                'transition': 'opacity 0.25s ease',
                'opacity': '0'
            });

            let startTime = Date.now();

            $.ajax({
                url: cc_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'cc_load_calendar',
                    month: month,
                    year: year
                },
                success: function(response) {
                    if (response && response.success) {
                        let elapsedTime = Date.now() - startTime;
                        let remainingTime = Math.max(0, 250 - elapsedTime);

                        // Attendiamo che il fade-out sia materialmente completato prima di scambiare l'HTML
                        setTimeout(function() {
                            body.html(response.data.html);
                            $('#cc-current-month-label').text(response.data.month_label);
                            $('#cc-month-select').val(month);
                            $('#cc-year-select').val(year);
                            
                            // Fade in
                            body.css('opacity', '1');
                        }, remainingTime);
                    }
                }
            });
        }

        let firstLoad = true;
        loadCalendar(currentMonth, currentYear);
        
        $('#cc-prev-month').on('click', function(e) {
            e.preventDefault();
            currentMonth--;
            if(currentMonth < 1) { currentMonth = 12; currentYear--; }
            loadCalendar(currentMonth, currentYear);
        });

        $('#cc-next-month').on('click', function(e) {
            e.preventDefault();
            currentMonth++;
            if(currentMonth > 12) { currentMonth = 1; currentYear++; }
            loadCalendar(currentMonth, currentYear);
        });

        $('#cc-month-select, #cc-year-select').on('change', function() {
            currentMonth = parseInt($('#cc-month-select').val());
            currentYear = parseInt($('#cc-year-select').val());
            loadCalendar(currentMonth, currentYear);
        });
    }

    /* ==================== FORM DI ISCRIZIONE ==================== */
    if ($('#cc-enrollment-form').length) {
        
        // Aggiorna il nonce all'avvio per evitare problemi di cache
        $.ajax({
            url: cc_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'cc_get_fresh_nonce'
            },
            success: function(response) {
                if (response && response.success && response.data.nonce) {
                    cc_ajax.nonce = response.data.nonce;
                    $('input[name="cc_nonce"]').val(response.data.nonce);
                }
            }
        });
        
        // Aggiunta Partecipante
        $('#cc-add-participant').on('click', function(e) {
            e.preventDefault();
            let wrapper = $('#cc-participants-wrapper');
            let numParticipants = wrapper.find('.cc-participant-block').length;

            if (typeof maxSeatsAvailable !== 'undefined' && numParticipants >= maxSeatsAvailable) {
                alert('Hai raggiunto il numero massimo di posti disponibili: ' + maxSeatsAvailable);
                return;
            }

            let newIndex = numParticipants;
            let block = `
            <div class="cc-participant-block" data-index="${newIndex}">
                <h4>Dati Partecipante ${newIndex + 1}</h4>
                <div class="cc-form-group">
                    <label>Nome e Cognome *</label>
                    <input type="text" name="participants[${newIndex}][name]" required>
                </div>
                <div class="cc-form-group">
                    <label>Data di Nascita *</label>
                    <input type="date" name="participants[${newIndex}][birthdate]" required>
                </div>
                <a href="#" class="cc-remove-btn" style="text-decoration: none;" onclick="event.preventDefault(); ccRemoveParticipant(this)">Rimuovi</a>
            </div>
            `;
            wrapper.append(block);
            ccUpdatePrice();
        });

        // Invio Form (AJAX)
        $('#cc-enrollment-form').on('submit', function(e) {
            e.preventDefault();
            let form = $(this);
            let btn = $('#cc-submit-btn');
            let msgContainer = $('#cc-form-message');

            btn.prop('disabled', true).text('Invio in corso...');
            msgContainer.html('');

            let formData = form.serialize() + '&cc_nonce=' + cc_ajax.nonce;

            $.ajax({
                url: cc_ajax.ajax_url,
                type: 'POST',
                data: formData,
                success: function(response) {
                    if (response.success) {
                        msgContainer.html('<div style="color: green; font-weight: bold; margin-bottom: 20px;">' + response.data + '</div>');
                        form.fadeTo("slow", 1, function() {
                            $(this).find('input').val(''); // svuota i campi
                            location.reload(); 
                        });
                    } else {
                        msgContainer.html('<div style="color: red; font-weight: bold; margin-bottom: 20px;">' + response.data + '</div>');
                        btn.prop('disabled', false).text('Iscriviti Ora');
                    }
                },
                error: function() {
                    msgContainer.html('<div style="color: red; font-weight: bold; margin-bottom: 20px;">Errore di connessione. Riprova.</div>');
                    btn.prop('disabled', false).text('Iscriviti Ora');
                }
            });
        });
    }

});

// Funzioni Globali (fuori dal document.ready per onclick attribute)
function ccRemoveParticipant(btn) {
    jQuery(btn).closest('.cc-participant-block').remove();
    let blocks = jQuery('.cc-participant-block');
    blocks.each(function(index) {
        jQuery(this).find('h4').text('Dati Partecipante ' + (index + 1));
    });
    ccUpdatePrice();
}

function ccUpdatePrice() {
    if (typeof baseCoursePrice !== 'undefined') {
        let numParticipants = jQuery('#cc-participants-wrapper .cc-participant-block').length;
        let totPrice = baseCoursePrice * numParticipants;
        let formattedPrice = totPrice.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, "'");
        jQuery('#cc-dynamic-price').text(formattedPrice);
        
        if (numParticipants > 1) {
            jQuery('#cc-price-label-tot').text('(Totale per ' + numParticipants + ' iscritti)');
        } else {
            jQuery('#cc-price-label-tot').text('');
        }
    }
}

function ccToggleBilling() {
    let content = jQuery('#cc-billing-content');
    let toggleBtn = jQuery('.cc-billing-toggle');
    if (content.is(':visible')) {
        content.slideUp();
        toggleBtn.find('.cc-toggle-icon').html('<i class="dashicons dashicons-arrow-down-alt2"></i>');
    } else {
        content.slideDown();
        toggleBtn.find('.cc-toggle-icon').html('<i class="dashicons dashicons-arrow-up-alt2"></i>');
    }
}
