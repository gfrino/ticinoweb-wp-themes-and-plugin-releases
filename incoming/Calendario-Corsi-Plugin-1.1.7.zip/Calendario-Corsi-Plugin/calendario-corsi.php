<?php
/**
 * Plugin Name: Calendario Corsi
 * Description: Pubblica i tuoi corsi in un calendario mensile e in una lista, con pagina di dettaglio e modulo d'iscrizione: le iscrizioni arrivano nel sito e per email, e i posti disponibili si aggiornano da soli.
 * Version: 1.1.7
 * Requires PHP: 7.4
 * Author: ticinoWEB
 * Text Domain: calendario-corsi
 * Update URI: https://github.com/gfrino/ticinoweb-wp-themes-and-plugin-releases
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Definisci le costanti del plugin
define( 'CC_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'CC_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// Carica i file necessari
define( 'CC_RELEASE_UPDATER_VERSION', '1.2.0' );

require_once CC_PLUGIN_DIR . 'includes/tw-release-updater.php';
require_once CC_PLUGIN_DIR . 'includes/class-cc-post-types.php';
require_once CC_PLUGIN_DIR . 'includes/class-cc-template-loader.php';

if ( is_admin() ) {
    require_once CC_PLUGIN_DIR . 'admin/class-cc-admin.php';
}

require_once CC_PLUGIN_DIR . 'frontend/class-cc-shortcodes.php';
require_once CC_PLUGIN_DIR . 'frontend/class-cc-form-handler.php';

// Caricamento Assets (CSS / JS)
function cc_enqueue_scripts() {
    wp_enqueue_style( 'cc-style', CC_PLUGIN_URL . 'assets/css/style.css', array(), '1.1.7' );
    wp_enqueue_script( 'cc-script', CC_PLUGIN_URL . 'assets/js/script.js', array('jquery'), '1.1.7', true );
    
    // Passa le variabili globali al JS
    wp_localize_script( 'cc-script', 'cc_ajax', array(
        'ajax_url' => admin_url( 'admin-ajax.php' ),
        'nonce'    => wp_create_nonce( 'cc_form_nonce' )
    ) );
}
add_action( 'wp_enqueue_scripts', 'cc_enqueue_scripts' );

// Attivazione del plugin: Svuota la cache dei Permalink (Evita errore 404 sui Corsi)
function cc_activate_plugin() {
    require_once CC_PLUGIN_DIR . 'includes/class-cc-post-types.php';
    CC_Post_Types::register_course_cpt();
    CC_Post_Types::register_enrollment_cpt();
    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'cc_activate_plugin' );

/**
 * Installa o aggiorna il mu-plugin dell'aggiornatore standard ticinoWEB dalla copia inclusa.
 */
function cc_install_release_updater() {
    if ( ! class_exists( 'TW_Release_Updater' ) || TW_Release_Updater::mu_is_current( CC_RELEASE_UPDATER_VERSION ) ) {
        return;
    }
    if ( get_site_transient( 'cc_release_updater_failed' ) ) {
        return;
    }
    $result = TW_Release_Updater::install_mu( CC_PLUGIN_DIR . 'includes/tw-release-updater.php' );
    if ( is_wp_error( $result ) ) {
        set_site_transient( 'cc_release_updater_failed', $result->get_error_message(), 12 * HOUR_IN_SECONDS );
    }
}

add_action( 'admin_init', function () {
    if ( current_user_can( is_multisite() ? 'manage_network_plugins' : 'activate_plugins' ) ) {
        cc_install_release_updater();
    }
}, 20 );
