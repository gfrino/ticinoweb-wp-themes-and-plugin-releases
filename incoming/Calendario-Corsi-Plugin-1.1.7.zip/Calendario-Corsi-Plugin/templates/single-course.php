<?php
get_header();

while ( have_posts() ) :
    the_post();

    $post_id          = get_the_ID();
    $start_date       = get_post_meta( $post_id, '_cc_start_date', true );
    $end_date         = get_post_meta( $post_id, '_cc_end_date', true );
    $time             = get_post_meta( $post_id, '_cc_time', true );
    $price            = get_post_meta( $post_id, '_cc_price', true );
    $location         = get_post_meta( $post_id, '_cc_location', true );
    $certificate_type = get_post_meta( $post_id, '_cc_certificate_type', true );
    $duration         = get_post_meta( $post_id, '_cc_duration', true );
    $max_participants = intval( get_post_meta( $post_id, '_cc_max_participants', true ) );
    $min_participants = get_post_meta( $post_id, '_cc_min_participants', true );
    $enrolled_count   = intval( get_post_meta( $post_id, '_cc_enrolled_count', true ) );
    $presentation     = get_post_meta( $post_id, '_cc_presentation', true );
    $methodology      = get_post_meta( $post_id, '_cc_methodology', true );
    $cancellation     = get_post_meta( $post_id, '_cc_cancellation', true );
    $contents         = get_post_meta( $post_id, '_cc_contents', true );
    $contents_list    = !empty( $contents ) ? json_decode( $contents, true ) : array();

    $profilo          = get_post_meta( $post_id, '_cc_profilo_professionale', true );
    $gruppo_target    = get_post_meta( $post_id, '_cc_gruppo_target', true );
    $obiettivi        = get_post_meta( $post_id, '_cc_obiettivi_didattici', true );
    $obiettivi_list   = !empty( $obiettivi ) ? json_decode( $obiettivi, true ) : array();
    $strumenti        = get_post_meta( $post_id, '_cc_strumenti', true );
    $modalita         = get_post_meta( $post_id, '_cc_modalita_svolgimento', true );
    $ente             = get_post_meta( $post_id, '_cc_ente_erogatore', true );
    $formatore        = get_post_meta( $post_id, '_cc_formatore', true );

    $available_seats  = $max_participants - $enrolled_count;

    // Icona del corso
    $icon_html = '';
    if ( class_exists('CC_Shortcodes') ) {
        $icon_html = CC_Shortcodes::get_course_icon_html($post_id);
    }

    $formatted_date = '';
    if ( $start_date ) {
        $formatted_date = date_i18n( 'j F Y', strtotime( $start_date ) );
        if ( $end_date && $end_date != $start_date ) {
            $formatted_date .= ' - ' . date_i18n( 'j F Y', strtotime( $end_date ) );
        }
    }

    $is_numeric_price = is_numeric($price);
    $display_price    = $is_numeric_price ? 'CHF ' . number_format((float)$price, 2, '.', '\'') : esc_html($price);

    ?>
    <div id="cc-single-course-container" class="cc-single-container">
        
        <div class="cc-back-navigation" style="margin-bottom: 20px;">
            <a href="javascript:history.back();" style="display: inline-flex; align-items: center; gap: 8px; font-weight: 600; font-size: 15px; color: var(--cc-primary); text-decoration: none; padding: 5px 0; transition: transform 0.2s ease;" onmouseover="this.style.transform='translateX(-3px)'" onmouseout="this.style.transform='translateX(0)'">
                <span class="dashicons dashicons-arrow-left-alt" style="font-size: 20px; width: 20px; height: 20px;"></span> 
                Torna al calendario
            </a>
        </div>

        <div class="cc-single-header">
            <?php if ( has_post_thumbnail() ) : ?>
                <div class="cc-course-image">
                    <?php the_post_thumbnail( 'full' ); ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="cc-single-content">
            <div class="cc-col-left">
                <h1 class="cc-course-title" style="display: flex; align-items: center;">
                    <?php echo !empty($icon_html) ? '<span style="margin-right: 15px; display: flex; align-items: center;">' . $icon_html . '</span>' : ''; ?>
                    <?php the_title(); ?>
                </h1>
                
                <div class="cc-course-meta-top">
                    <?php if($formatted_date) : ?>
                    <span class="cc-meta"><i class="dashicons dashicons-calendar-alt"></i> <?php echo esc_html( $formatted_date ); ?></span>
                    <?php endif; ?>
                    <?php if($time) : ?>
                    <span class="cc-meta"><i class="dashicons dashicons-clock"></i> <?php echo esc_html( $time ); ?></span>
                    <?php endif; ?>
                    <?php if($duration) : ?>
                    <span class="cc-meta"><i class="dashicons dashicons-hourglass"></i> <?php echo esc_html( $duration ); ?></span>
                    <?php endif; ?>
                </div>

                <div class="cc-course-description">
                    <?php the_content(); ?>
                </div>

                <?php if ( $presentation ) : ?>
                <div class="cc-course-section">
                    <h2>Presentazione del corso</h2>
                    <p><?php echo nl2br( esc_html( $presentation ) ); ?></p>
                </div>
                <?php endif; ?>

                <?php if ( $profilo ) : ?>
                <div class="cc-course-section">
                    <h2>Profilo professionale</h2>
                    <p><?php echo nl2br( esc_html( $profilo ) ); ?></p>
                </div>
                <?php endif; ?>

                <?php if ( $gruppo_target ) : ?>
                <div class="cc-course-section">
                    <h2>Gruppo target</h2>
                    <p><?php echo nl2br( esc_html( $gruppo_target ) ); ?></p>
                </div>
                <?php endif; ?>

                <?php if ( ! empty( $obiettivi_list ) ) : ?>
                <div class="cc-course-section">
                    <h2>Obiettivi didattici</h2>
                    <ul class="cc-content-list">
                        <?php foreach ( $obiettivi_list as $item ) : ?>
                            <li><?php echo esc_html( $item ); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>

                <?php if ( ! empty( $contents_list ) ) : ?>
                <div class="cc-course-section">
                    <h2>Contenuti del corso</h2>
                    <ul class="cc-content-list">
                        <?php foreach ( $contents_list as $item ) : ?>
                            <li><?php echo esc_html( $item ); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>

                <?php if ( $methodology ) : ?>
                <div class="cc-course-section">
                    <h2>Metodologia</h2>
                    <p><?php echo nl2br( esc_html( $methodology ) ); ?></p>
                </div>
                <?php endif; ?>

                <?php if ( $strumenti ) : ?>
                <div class="cc-course-section">
                    <h2>Strumenti</h2>
                    <p><?php echo nl2br( esc_html( $strumenti ) ); ?></p>
                </div>
                <?php endif; ?>

                <?php if ( $modalita ) : ?>
                <div class="cc-course-section">
                    <h2>Modalità di svolgimento</h2>
                    <p><?php echo nl2br( esc_html( $modalita ) ); ?></p>
                </div>
                <?php endif; ?>

                <div class="cc-course-section cc-info-summary">
                    <h2>Informazioni sintetiche</h2>
                    <ul>
                        <?php if($duration) : ?><li><strong>Durata:</strong> <?php echo esc_html( $duration ); ?></li><?php endif; ?>
                        <?php if($certificate_type) : ?><li><strong>Tipo di attestazione:</strong> <?php echo esc_html( $certificate_type ); ?></li><?php endif; ?>
                        <?php if($location) : ?><li><strong>Luogo:</strong> <?php echo esc_html( $location ); ?></li><?php endif; ?>
                        <?php if($ente) : ?><li><strong>Ente erogatore:</strong> <?php echo esc_html( $ente ); ?></li><?php endif; ?>
                        <?php if($formatore) : ?><li><strong>Formatore:</strong> <?php echo esc_html( $formatore ); ?></li><?php endif; ?>
                        <?php if($price !== '') : ?><li><strong>Costo:</strong> <?php echo $display_price; ?></li><?php endif; ?>
                        <li><strong>Numero Partecipanti:</strong> Minimo <?php echo esc_html($min_participants); ?> - Massimo <?php echo esc_html($max_participants); ?></li>
                        <li><strong>Data:</strong> <?php echo esc_html($formatted_date); ?></li>
                        <?php if($cancellation) : ?>
                        <li><strong>Disdetta e Rimborso:</strong><br> <?php echo nl2br(esc_html($cancellation)); ?></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>

            <!-- DESTRA -->
            <div class="cc-col-right">
                <div class="cc-sticky-card">
                    <div class="cc-card-summary">
                        <h3>Scopri Corso</h3>
                        <p class="cc-summary-desc">Contattaci per maggiori informazioni, senza vincolo di prenotazione</p>
                        
                        <div class="cc-summary-details">
                            <div class="cc-detail-item">
                                <strong>Prezzo <span id="cc-price-label-tot" style="font-size:12px; font-weight:normal;"></span>:</strong> 
                                <span><span id="cc-dynamic-price"><?php echo $display_price; ?></span></span>
                            </div>
                            <div class="cc-detail-item" style="align-items: flex-start; gap: 15px;">
                                <strong style="white-space: nowrap;">Luogo:</strong> 
                                <span style="text-align: right; line-height: 1.4;"><?php echo esc_html($location); ?></span>
                            </div>
                            
                            <?php if ( $available_seats > 0 ) : ?>
                                <div class="cc-detail-item cc-seats-ok">
                                    <strong>Posti disponibili:</strong> 
                                    <span><?php echo $available_seats; ?></span>
                                </div>
                            <?php else : ?>
                                <div class="cc-detail-item cc-seats-ko" style="justify-content: center;">
                                    <strong>Corso al completo</strong>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <?php if ( $available_seats > 0 ) : ?>
                    <form id="cc-enrollment-form" class="cc-form">
                        <input type="hidden" name="action" value="cc_submit_enrollment">
                        <input type="hidden" name="course_id" value="<?php echo $post_id; ?>">
                        <?php wp_nonce_field( 'cc_form_nonce', 'cc_nonce' ); ?>
                        
                        <div id="cc-participants-wrapper" class="cc-participants-wrapper">
                            <div class="cc-participant-block" data-index="0">
                                <h4>Dati Partecipante 1</h4>
                                <div class="cc-form-group">
                                    <label>Nome e Cognome *</label>
                                    <input type="text" name="participants[0][name]" required>
                                </div>
                                <div class="cc-form-group">
                                    <label>Data di Nascita *</label>
                                    <input type="date" name="participants[0][birthdate]" required>
                                </div>
                                <button type="button" class="cc-remove-btn" style="display:none;" onclick="ccRemoveParticipant(this)">Rimuovi</button>
                            </div>
                        </div>

                        <a href="#" id="cc-add-participant" class="cc-btn cc-btn-outline" style="text-decoration:none;"><i class="dashicons dashicons-plus"></i> Aggiungi partecipante</a>
                        
                        <div class="cc-billing-section">
                            <h4 style="margin-bottom: 15px; color: var(--cc-primary);">Dati Azienda / Referente</h4>
                            <div class="cc-form-group">
                                <label>Azienda / Intestazione *</label>
                                <input type="text" name="billing_company" required>
                            </div>
                            <div class="cc-form-row">
                                <div class="cc-form-group cc-w50">
                                    <label>Email *</label>
                                    <input type="email" name="billing_email" required>
                                </div>
                                <div class="cc-form-group cc-w50">
                                    <label>Telefono *</label>
                                    <input type="text" name="billing_phone" required>
                                </div>
                            </div>
                            <div class="cc-form-group">
                                <label>Partita IVA / UID (CHE-…)</label>
                                <input type="text" name="billing_vat" placeholder="es. CHE-123.456.789">
                            </div>
                            <div class="cc-form-group">
                                <label>Indirizzo Completo *</label>
                                <input type="text" name="billing_address" required>
                            </div>
                        </div>

                        <div class="cc-payment-method-box" style="margin-bottom: 20px; font-size: 13px; background: #fff8e1; border-left: 4px solid #ffc107; padding: 15px; border-radius: 6px; color: #5a5a5a;">
                            <strong>Modalità di pagamento:</strong><br>
                            Il pagamento dovrà essere effettuato a seguito della ricezione della fattura, che verrà inviata alcuni giorni prima dell’avvio del corso.
                        </div>
                        
                        <div id="cc-form-message"></div>
                        <button type="submit" id="cc-submit-btn" class="cc-btn cc-btn-primary">Iscriviti Ora</button>
                    </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <script>
        var maxSeatsAvailable = <?php echo $available_seats; ?>;
        var baseCoursePrice = <?php echo $is_numeric_price ? floatval($price) : 'false'; ?>;
    </script>
    <?php

endwhile; // End of the loop.

get_footer();
