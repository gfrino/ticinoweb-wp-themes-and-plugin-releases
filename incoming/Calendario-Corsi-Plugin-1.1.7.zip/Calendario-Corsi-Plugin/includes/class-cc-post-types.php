<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CC_Post_Types {
    public static function init() {
        add_action( 'init', array( __CLASS__, 'register_course_cpt' ) );
        add_action( 'init', array( __CLASS__, 'register_enrollment_cpt' ) );
        
        // Pannello Iscrizioni
        add_filter( 'manage_enrollment_posts_columns', array( __CLASS__, 'enrollment_columns' ) );
        add_action( 'manage_enrollment_posts_custom_column', array( __CLASS__, 'enrollment_custom_column' ), 10, 2 );

        // Pannello Corsi
        add_filter( 'manage_courses_posts_columns', array( __CLASS__, 'course_columns' ) );
        add_action( 'manage_courses_posts_custom_column', array( __CLASS__, 'course_custom_column' ), 10, 2 );
        add_filter( 'manage_edit-courses_sortable_columns', array( __CLASS__, 'course_sortable_columns' ) );
        add_action( 'pre_get_posts', array( __CLASS__, 'course_sort_by_date' ) );
    }

    public static function register_course_cpt() {
        $labels = array(
            'name'                  => 'Corsi',
            'singular_name'         => 'Corso',
            'menu_name'             => 'Corsi',
            'name_admin_bar'        => 'Corso',
            'add_new'               => 'Aggiungi Nuovo',
            'add_new_item'          => 'Aggiungi Nuovo Corso',
            'new_item'              => 'Nuovo Corso',
            'edit_item'             => 'Modifica Corso',
            'view_item'             => 'Visualizza Corso',
            'all_items'             => 'Tutti i Corsi',
            'search_items'          => 'Cerca Corsi',
            'not_found'             => 'Nessun corso trovato.',
        );

        $args = array(
            'labels'             => $labels,
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => array( 'slug' => 'corsi' ),
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => 20,
            'menu_icon'          => 'dashicons-welcome-learn-more',
            'supports'           => array( 'title', 'editor' ), // L'editor è usato per la "Descrizione"
        );

        register_post_type( 'courses', $args );
    }

    public static function register_enrollment_cpt() {
        $labels = array(
            'name'                  => 'Iscrizioni',
            'singular_name'         => 'Iscrizione',
            'menu_name'             => 'Iscrizioni',
            'all_items'             => 'Tutte le Iscrizioni',
        );

        $args = array(
            'labels'             => $labels,
            'public'             => false,
            'show_ui'            => true,
            'show_in_menu'       => 'edit.php?post_type=courses', // Sotto menu di Corsi
            'supports'           => array( 'title' ),
            'capabilities'       => array(
                'create_posts' => 'do_not_allow', // Le iscrizioni vanno fatte da frontend
            ),
            'map_meta_cap'       => true,
        );

        register_post_type( 'enrollment', $args );
    }

    public static function enrollment_columns( $columns ) {
        $new_columns = array();
        $new_columns['cb'] = $columns['cb'];
        $new_columns['title'] = $columns['title'];
        $new_columns['course'] = 'Corso';
        $new_columns['company'] = 'Azienda';
        $new_columns['email'] = 'Email';
        $new_columns['phone'] = 'Telefono';
        $new_columns['participants'] = 'N° Partecipanti';
        $new_columns['date'] = $columns['date'];
        return $new_columns;
    }

    public static function enrollment_custom_column( $column, $post_id ) {
        switch ( $column ) {
            case 'course':
                $course_id = get_post_meta( $post_id, '_cc_course_id', true );
                echo $course_id ? get_the_title( $course_id ) : '-';
                break;
            case 'company':
                echo esc_html( get_post_meta( $post_id, '_cc_billing_company', true ) );
                break;
            case 'email':
                echo esc_html( get_post_meta( $post_id, '_cc_billing_email', true ) );
                break;
            case 'phone':
                echo esc_html( get_post_meta( $post_id, '_cc_billing_phone', true ) );
                break;
            case 'participants':
                $parts = get_post_meta( $post_id, '_cc_participants', true );
                echo is_array($parts) ? count($parts) : '0';
                break;
        }
    }

    public static function course_columns( $columns ) {
        $new_columns = array();
        foreach ( $columns as $key => $value ) {
            $new_columns[$key] = $value;
            if ( $key === 'title' ) {
                $new_columns['course_date'] = 'Data del corso';
            }
        }
        return $new_columns;
    }

    public static function course_custom_column( $column, $post_id ) {
        if ( $column === 'course_date' ) {
            $start_date = get_post_meta( $post_id, '_cc_start_date', true );
            if ( $start_date ) {
                echo date( 'd/m/Y', strtotime( $start_date ) );
            } else {
                echo '-';
            }
        }
    }

    public static function course_sortable_columns( $columns ) {
        $columns['course_date'] = 'course_date';
        return $columns;
    }

    public static function course_sort_by_date( $query ) {
        if ( ! is_admin() || ! $query->is_main_query() ) {
            return;
        }

        if ( 'courses' === $query->get( 'post_type' ) ) {
            $orderby = $query->get( 'orderby' );

            if ( 'course_date' === $orderby ) {
                $query->set( 'meta_key', '_cc_start_date' );
                $query->set( 'orderby', 'meta_value' );
            }
        }
    }
}
CC_Post_Types::init();
