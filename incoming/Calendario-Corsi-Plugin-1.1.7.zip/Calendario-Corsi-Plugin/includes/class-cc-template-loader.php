<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CC_Template_Loader {
    public static function init() {
        add_filter( 'single_template', array( __CLASS__, 'load_single_course_template' ) );
    }

    public static function load_single_course_template( $template ) {
        global $post;

        if ( 'courses' === $post->post_type ) {
            $plugin_template = CC_PLUGIN_DIR . 'templates/single-course.php';
            if ( file_exists( $plugin_template ) ) {
                return $plugin_template;
            }
        }

        return $template;
    }
}
CC_Template_Loader::init();
