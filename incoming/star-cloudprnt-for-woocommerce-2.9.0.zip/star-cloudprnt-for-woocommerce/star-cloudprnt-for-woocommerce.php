<?php
	/*
	 * Plugin Name: Star CloudPRNT for WooCommerce
	 * Plugin URI: https://ticinoweb.com/
	 * Description: Cloud printing technology for CloudPRNT by Star Micronics.
 	 * Version: 2.9.0
	 * Author: ticinoWEB
	 * Author URI: https://ticinoweb.com/
	 * Requires at least: 5.9
	 * Tested up to: 6.4
	 * WC requires at least: 7.0
	 * WC tested up to: 8.5
	 * Requires PHP: 8.0
	 * Update URI: https://github.com/gfrino/ticinoweb-wp-themes-and-plugin-releases
	 */
	 
	// Block direct access to this script
	if (!defined( 'ABSPATH' )) exit;

	// ---------------------------------------------------------------------------
	// Minimum supported versions - change these if you want to support older/newer
	// environments. Defaults chosen to drop older WP/WC/PHP versions (per request).
	// ---------------------------------------------------------------------------
	define('STAR_CLOUDPRNT_MIN_PHP', '8.0.0');
	define('STAR_CLOUDPRNT_MIN_WP', '5.9');
	define('STAR_CLOUDPRNT_MIN_WC', '7.0.0');

	// If any requirement is not satisfied, register an admin notice and stop loading
	// the rest of the plugin. This prevents fatal errors on older platforms.
	$php_ok = version_compare(PHP_VERSION, STAR_CLOUDPRNT_MIN_PHP, '>=');
	$wp_version = isset($GLOBALS['wp_version']) ? $GLOBALS['wp_version'] : null;
	$wp_ok = $wp_version ? version_compare($wp_version, STAR_CLOUDPRNT_MIN_WP, '>=') : false;
	// Determine whether WooCommerce is active for this site. In multisite setups
	// WooCommerce might be active only on some subsites; in that case we should
	// only enforce the WooCommerce version check on sites where WC is active.
	$wc_ok = true;
	$woo_active_on_site = false;
	// If WP functions are available, inspect active plugins for this site
	if (function_exists('get_option')) {
		$active_plugins = (array) get_option('active_plugins', array());
		if (in_array('woocommerce/woocommerce.php', $active_plugins, true)) {
			$woo_active_on_site = true;
		}
		// In multisite, check sitewide active plugins as well
		if (!$woo_active_on_site && function_exists('is_multisite') && is_multisite() && function_exists('get_site_option')) {
			$sitewide = (array) get_site_option('active_sitewide_plugins', array());
			if (isset($sitewide['woocommerce/woocommerce.php'])) $woo_active_on_site = true;
		}
	}

	if ($woo_active_on_site) {
		// Prefer the runtime constant if available
		$wc_version = defined('WC_VERSION') ? WC_VERSION : (defined('WOOCOMMERCE_VERSION') ? WOOCOMMERCE_VERSION : null);
		if ($wc_version) {
			$wc_ok = version_compare($wc_version, STAR_CLOUDPRNT_MIN_WC, '>=');
		} else {
			// If runtime constant not present, try to read the per-site stored option
			$stored = null;
			if (function_exists('get_option')) {
				$stored = get_option('woocommerce_version');
			}
			$wc_ok = $stored ? version_compare($stored, STAR_CLOUDPRNT_MIN_WC, '>=') : false;
		}
	} else {
		// WooCommerce is not active on the current site - however in multisite the
		// plugin may be active on another subsite. Check other sites and accept if
		// any subsite has WooCommerce active with an acceptable version.
		$found_ok = false;
		if (function_exists('is_multisite') && is_multisite() && function_exists('get_sites')) {
			$sites = get_sites(array('fields' => 'ids'));
			if (!empty($sites)) {
				foreach ($sites as $blog_id) {
					// Avoid checking the current blog twice
					if (function_exists('get_current_blog_id') && $blog_id == get_current_blog_id()) continue;
					if (function_exists('switch_to_blog')) switch_to_blog($blog_id);
					$active = false;
					if (function_exists('get_option')) {
						$apl = (array) get_option('active_plugins', array());
						if (in_array('woocommerce/woocommerce.php', $apl, true)) $active = true;
					}
					if ($active) {
						// Try stored option for WooCommerce version on that blog
						$stored = null;
						if (function_exists('get_option')) $stored = get_option('woocommerce_version');
						if ($stored && version_compare($stored, STAR_CLOUDPRNT_MIN_WC, '>=')) {
							$found_ok = true;
						}
					}
					if (function_exists('restore_current_blog')) restore_current_blog();
					if ($found_ok) break;
				}
			}
		}
		$wc_ok = $found_ok ? true : true; // do not block on main site if WC not present; allow loading
	}

	// Only block plugin load for WooCommerce if WooCommerce is active on this site and
	// its version does not meet the minimum. For multisite with WC active on a
	// different subsite, do not block the main site.
	if (! $php_ok || ! $wp_ok || ($woo_active_on_site && ! $wc_ok)) {
		// Defer notice registration until admin area is available
		add_action('admin_notices', function() use ($php_ok, $wp_ok, $wc_ok, $wp_version, $wc_version, $woo_active_on_site) {
			$needs = array();
			if (! $php_ok) $needs[] = 'PHP ' . STAR_CLOUDPRNT_MIN_PHP . '+';
			if (! $wp_ok) $needs[] = 'WordPress ' . STAR_CLOUDPRNT_MIN_WP . '+';
			if ($woo_active_on_site && ! $wc_ok) $needs[] = 'WooCommerce ' . STAR_CLOUDPRNT_MIN_WC . '+';

			$current = sprintf('PHP %s, WP %s, WC %s', PHP_VERSION, $wp_version ? $wp_version : 'missing', $wc_version ? $wc_version : 'missing');

			$msg = sprintf(
				'Star CloudPRNT plugin requires %s. Current versions: %s. Please upgrade or deactivate the plugin.',
				implode(', ', $needs),
				$current
			);

			echo '<div class="notice notice-error"><p>' . esc_html($msg) . '</p></div>';
		});

		// Also log to PHP error log for non-admin contexts
		error_log('Star CloudPRNT: minimum requirements not met - PHP:' . PHP_VERSION . ' WP:' . ($wp_version ?: 'missing') . ' WC:' . ($wc_version ?: 'missing'));

		// Prevent plugin from loading further when critical (PHP/WP) or when WC is
		// required for this site and missing/old.
		if (! $php_ok || ! $wp_ok || ($woo_active_on_site && ! $wc_ok)) return;
	}

	// The wordpress.org listing of this slug was closed, so never offer its updates.
	// Updates from the ticinoWEB releases repo (see the Update URI header) are not touched.
	function star_cloud_filter_plugin_updates( $value ) {
		$key = 'star-cloudprnt-for-woocommerce/star-cloudprnt-for-woocommerce.php';
		if ( is_object( $value ) && isset( $value->response[ $key ] ) ) {
			$package = isset( $value->response[ $key ]->package ) ? (string) $value->response[ $key ]->package : '';
			if ( strpos( $package, 'github.com/gfrino/ticinoweb-wp-themes-and-plugin-releases/' ) !== 0 ) {
				unset( $value->response[ $key ] );
			}
		}
		return $value;
	}
	add_filter( 'site_transient_update_plugins', 'star_cloud_filter_plugin_updates' );

	// Version of the bundled includes/tw-release-updater.php (keep in sync with its header).
	define( 'STAR_CLOUDPRNT_RELEASE_UPDATER_VERSION', '1.2.0' );

	/*
	 * Updates from the ticinoWEB releases repo. The bundled loader is generic and is
	 * also installed as a mu-plugin, so updates work in Network Admin and cron too.
	 * If the mu-plugin is already loaded this include is a no-op.
	 */
	require_once plugin_dir_path( __FILE__ ) . 'includes/tw-release-updater.php';

	function star_cloudprnt_install_release_updater() {
		if ( ! class_exists( 'TW_Release_Updater' ) || TW_Release_Updater::mu_is_current( STAR_CLOUDPRNT_RELEASE_UPDATER_VERSION ) ) {
			return;
		}
		if ( get_site_transient( 'star_cloudprnt_release_updater_failed' ) ) {
			return;
		}
		$result = TW_Release_Updater::install_mu( plugin_dir_path( __FILE__ ) . 'includes/tw-release-updater.php' );
		if ( is_wp_error( $result ) ) {
			set_site_transient( 'star_cloudprnt_release_updater_failed', $result->get_error_message(), 12 * HOUR_IN_SECONDS );
		}
	}
	register_activation_hook( __FILE__, 'star_cloudprnt_install_release_updater' );
	add_action( 'admin_init', function () {
		if ( current_user_can( is_multisite() ? 'manage_network_plugins' : 'activate_plugins' ) ) {
			star_cloudprnt_install_release_updater();
		}
	}, 20 );

    add_action( 'before_woocommerce_init', function() {
        if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
            \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
        }
    } );

	
	/* if($_SERVER['REMOTE_ADDR'] == '106.77.132.93'){
		 error_reporting(E_ALL);
		@ini_set( 'display_errors', 1 );
		 
	} */
	// Include printer files
	if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') include_once(plugin_dir_path(__FILE__).'cloudprnt\\printer.inc.php');
	else include_once(plugin_dir_path(__FILE__).'cloudprnt/printer.inc.php');
	include_once(plugin_dir_path(__FILE__).star_cloudprnt_get_os_path('cloudprnt/printer_star_line.inc.php'));
	include_once(plugin_dir_path(__FILE__).star_cloudprnt_get_os_path('cloudprnt/printer_text_plain.inc.php'));
	include_once(plugin_dir_path(__FILE__).star_cloudprnt_get_os_path('cloudprnt/printer_star_prnt.inc.php'));

// Ensure internal logger is available in all plugin contexts
include_once(plugin_dir_path(__FILE__) . 'cloudprnt/internal_log_fallback.php');

// Network-wide printer ownership registry (one printer -> exactly one site).
// Must load after printer.inc.php, which provides star_cloudprnt_normalize_mac().
include_once(plugin_dir_path(__FILE__) . 'cloudprnt/printer_ownership.inc.php');
	
	// Include plugin page settings and woo commerce hooks
	include_once(plugin_dir_path(__FILE__).star_cloudprnt_get_os_path('create-settings.php'));
	include_once(plugin_dir_path(__FILE__).star_cloudprnt_get_os_path('order-handler.php'));
	include_once(plugin_dir_path(__FILE__).'ibsa-menu-support.php');
	include_once(plugin_dir_path(__FILE__).star_cloudprnt_get_os_path('z-report.php'));
	// Conditionally include POS module when enabled
	if (get_option('star-cloudprnt-enable-pos', 'no') === 'yes') {
		$pos_file = plugin_dir_path(__FILE__) . 'FOOD-DELIVERY-POS/food-delivery-pos.php';
		if (file_exists($pos_file)) {
			include_once($pos_file);
		} else {
			// Log missing POS file if logging enabled
			if (!function_exists('star_cloudprnt_log')) {
				// minimal logger if not yet defined
				function star_cloudprnt_log($message, $level = 'INFO') {}
			}
			star_cloudprnt_log('POS module file not found at ' . $pos_file, 'WARN');
		}
	}

// Plugin-local logging helper
if (!function_exists('star_cloudprnt_log')) {
	function star_cloudprnt_log($message, $level = 'INFO') {
		// Only log when enabled in settings
		$enabled = get_option('star_cloudprnt_enable_log', 'no');
		if ($enabled !== 'yes') return;

		$logDir = rtrim(plugin_dir_path(__FILE__), '/\\') . DIRECTORY_SEPARATOR . 'logs' . DIRECTORY_SEPARATOR;
		if (!is_dir($logDir)) @mkdir($logDir, 0755, true);
		$logFile = $logDir . 'star-cloudprnt.log';
		$time = date('Y-m-d H:i:s');
		@file_put_contents($logFile, sprintf("[%s] [%s] %s\n", $time, strtoupper($level), $message), FILE_APPEND | LOCK_EX);
	}
}
    
    // Prevent duplicate saving of extra printer (_cus1) without showing error
add_filter('pre_update_option_star-cloudprnt-printer-select_cus1', function($new_value, $old_value) {
    $main_printer = isset($_POST['star-cloudprnt-printer-select']) 
        ? sanitize_text_field($_POST['star-cloudprnt-printer-select']) 
        : '';

    $extra_printer = isset($_POST['star-cloudprnt-printer-select_cus1']) 
        ? sanitize_text_field($_POST['star-cloudprnt-printer-select_cus1']) 
        : '';

    // If duplicate and old value is empty → prevent saving (force empty)
    if (!empty($main_printer) && $main_printer === $extra_printer) {
        if (empty($old_value)) {
            return ''; // keep it empty, don’t allow saving duplicate
        }
        return $old_value; // keep existing value if it was set
    }

    return $new_value; // save normally
}, 10, 2);


// LAYER 3: refuse, at the moment it is configured, to bind a printer that another
// site already owns. Applies to both the primary and the secondary printer slot -
// a site may own several printers, but a printer may not be shared between sites.
// The dropdown posts a display NAME; the option stores a MAC. Resolve a posted
// value to the MAC it refers to, falling back to $fallback when it matches nothing.
if (!function_exists('star_cloudprnt_resolve_posted_printer')) {
	function star_cloudprnt_resolve_posted_printer($posted, $fallback = '')
	{
		$posted = trim((string) $posted);
		if ($posted === '') {
			return '';
		}
		if (function_exists('star_cloudprnt_get_printer_list')
			&& function_exists('star_cloudprnt_option_matches_printer'))
		{
			foreach (star_cloudprnt_get_printer_list() as $listMac => $p) {
				if (star_cloudprnt_option_matches_printer($posted, $p, $listMac)) {
					return isset($p['printerMAC']) ? $p['printerMAC'] : $listMac;
				}
			}
		}
		return $fallback;
	}
}

if (!function_exists('star_cloudprnt_guard_printer_binding')) {
	function star_cloudprnt_guard_printer_binding($new_value, $old_value)
	{
		if (!function_exists('star_cloudprnt_normalize_mac')) {
			return $new_value; // ownership module unavailable - fail open, never block saving
		}
		$new = star_cloudprnt_normalize_mac($new_value);
		$old = star_cloudprnt_normalize_mac($old_value);

		if ($new !== '' && $new !== $old) {
			$owner = star_cloudprnt_get_printer_owner($new);
			$me    = star_cloudprnt_this_blog_id();
			if ($owner && $owner !== $me) {
				if (function_exists('add_settings_error')) {
					add_settings_error(
						'star-cloudprnt',
						'star-cloudprnt-printer-taken',
						sprintf(
							'Printer %s is already assigned to %s. A printer can only belong to one site - '
							. 'release it there first, or pick a different printer. Your previous setting was kept.',
							$new_value,
							star_cloudprnt_owner_label($owner)
						),
						'error'
					);
				}
				if (function_exists('star_cloudprnt_internal_log')) {
					star_cloudprnt_internal_log(
						"REFUSED printer binding: blog " . $me . " tried to claim " . $new
						. " which belongs to " . star_cloudprnt_owner_label($owner), 'ERROR'
					);
				}
				return $old_value; // keep what was there
			}
		}

		// Re-sync this site's claims from BOTH slots.
		// Start from what is stored, overlay whatever this request is submitting.
		// Using the posted values for both slots (not just the one being filtered)
		// matters because WordPress fires these filters one option at a time: while
		// the primary is being saved the secondary is still its old value, so syncing
		// from stored values alone would briefly release a printer that this very
		// request is about to re-assign.
		$primary   = get_option('star-cloudprnt-printer-select', '');
		$secondary = get_option('star-cloudprnt-printer-select_cus1', '');

		if (isset($_POST['star-cloudprnt-printer-select'])) {
			$primary = star_cloudprnt_resolve_posted_printer(
				sanitize_text_field(wp_unslash($_POST['star-cloudprnt-printer-select'])), $primary);
		}
		if (isset($_POST['star-cloudprnt-printer-select_cus1'])) {
			$secondary = star_cloudprnt_resolve_posted_printer(
				sanitize_text_field(wp_unslash($_POST['star-cloudprnt-printer-select_cus1'])), $secondary);
		}
		// The slot actually being written wins - it is the value that will be stored.
		if (isset($GLOBALS['star_cloudprnt_saving_slot'])) {
			if ($GLOBALS['star_cloudprnt_saving_slot'] === 'primary')   { $primary   = $new_value; }
			if ($GLOBALS['star_cloudprnt_saving_slot'] === 'secondary') { $secondary = $new_value; }
		}
		star_cloudprnt_sync_site_printers(array($primary, $secondary));

		return $new_value;
	}
}

// Priority 99 - these must run LAST. The lock filter (priority 10) and the
// duplicate-slot filter can both veto a change by returning $old_value. Running
// before them meant claiming a printer in the registry that then never got saved,
// while releasing the one still in use. Running last, $new_value is the value that
// will actually be stored.
add_filter('pre_update_option_star-cloudprnt-printer-select', function ($new_value, $old_value) {
	$GLOBALS['star_cloudprnt_saving_slot'] = 'primary';
	$out = star_cloudprnt_guard_printer_binding($new_value, $old_value);
	unset($GLOBALS['star_cloudprnt_saving_slot']);
	return $out;
}, 99, 2);

add_filter('pre_update_option_star-cloudprnt-printer-select_cus1', function ($new_value, $old_value) {
	$GLOBALS['star_cloudprnt_saving_slot'] = 'secondary';
	$out = star_cloudprnt_guard_printer_binding($new_value, $old_value);
	unset($GLOBALS['star_cloudprnt_saving_slot']);
	return $out;
}, 99, 2);

	//star_cloudprnt_register_settings();
	add_action('admin_init', 'star_cloudprnt_register_settings');
	
	// Run page setup and woo commerce hooks
	star_cloudprnt_create_settings_page();
	star_cloudprnt_setup_order_handler();

	// Add a settings link on the plugins page
	function my_plugin_settings_link($links) { 
		$settings_link = '<a href="options-general.php?page=star-cloudprnt-settings-admin">Settings</a>'; 
		array_unshift($links, $settings_link); 
		return $links; 
	}
	$plugin = plugin_basename(__FILE__); 
	add_filter("plugin_action_links_$plugin", 'my_plugin_settings_link' );



	/**
	 * Trigger Star CloudPRNT printing when an order is created via the WooCommerce REST API.
	 */
	add_action('woocommerce_rest_insert_shop_order', 'star_cloudprnt_on_rest_order_created', 10, 3);

	function star_cloudprnt_on_rest_order_created($order, $request, $creating) {
		if (!$creating) {
			return; // Only trigger on creation, not updates
		}

		$order_id = $order->get_id();
		error_log('REST order created - ID: ' . $order_id);

		// You can decide which printer to trigger (primary, secondary, or both)
		do_action('star_cloudprnt_primary_trigger_note', $order_id);
		star_cloudprnt_trigger_print($order_id);

		// Optional: trigger second printer if enabled
		do_action('star_cloudprnt_secondary_trigger_note', $order_id);
		star_cloudprnt_second_printer_trigger_print($order_id);
	}

    // Update and register plugin version
	add_action('init', function(){
		$stored = get_option('star_cloudprnt_plugin_version');
		$current = '2.8.1';
		if ($stored !== $current) {
			update_option('star_cloudprnt_plugin_version', $current, false);
			if (function_exists('star_cloudprnt_log')) {
				star_cloudprnt_log('Plugin version set to ' . $current, 'INFO');
			}
		}
	});

?>