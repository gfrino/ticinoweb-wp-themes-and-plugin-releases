<?php
/**
 * Elenco generico (blog, risultati di ricerca, archivi).
 *
 * @package Idea_Immobiliare_SA
 */
get_header();
$is_blog = is_home();
$title = $is_blog && get_option('page_for_posts') ? get_the_title(get_option('page_for_posts')) : (is_search() ? sprintf(__('Risultati per «%s»', 'idea-immobiliare-sa'), get_search_query()) : get_the_archive_title());
?>
<main id="main">
	<header class="idea-pagehead">
		<div class="idea-container">
			<?php echo ticinoweb_get_breadcrumbs(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<h1><?php echo esc_html(wp_strip_all_tags($title)); ?></h1>
		</div>
	</header>
	<section class="idea-section">
		<div class="idea-container">
			<?php if (have_posts()) : ?>
				<div class="idea-grid idea-grid--3">
					<?php while (have_posts()) : the_post(); get_template_part('template-parts/post-card'); endwhile; ?>
				</div>
				<?php the_posts_pagination(array('mid_size' => 1, 'prev_text' => '←', 'next_text' => '→', 'class' => 'idea-pagination')); ?>
			<?php else : ?>
				<p class="idea-empty"><?php esc_html_e('Nessun contenuto trovato.', 'idea-immobiliare-sa'); ?></p>
			<?php endif; ?>
		</div>
	</section>
</main>
<?php get_footer(); ?>
