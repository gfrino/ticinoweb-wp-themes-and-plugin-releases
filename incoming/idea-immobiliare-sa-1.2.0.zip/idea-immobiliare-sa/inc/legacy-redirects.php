<?php
/**
 * Redirect 301 dagli indirizzi del vecchio sito (TYPO3) a quelli nuovi, così i link
 * di Google, dei portali e dei clienti continuano a funzionare quando il dominio
 * idea-immobiliare.ch torna online. Gli immobili si riconoscono dal campo
 * `_idea_legacy_slug` assegnato all'import.
 *
 * @package Idea_Immobiliare_SA
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('template_redirect', 'idea_immo_legacy_redirects', 1);
function idea_immo_legacy_redirects()
{
    if (is_admin() || !is_404()) {
        return;
    }
    $uri  = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '';
    $path = rawurldecode((string) wp_parse_url($uri, PHP_URL_PATH));
    // Il sito può stare in una sottocartella (multisite): si toglie il prefisso del sito.
    $base = rtrim((string) wp_parse_url(home_url('/'), PHP_URL_PATH), '/');
    if ($base !== '' && strpos($path, $base) === 0) {
        $path = substr($path, strlen($base));
    }
    $path = '/' . ltrim($path, '/');

    $target = '';
    $find = function ($legacy, $type) {
        $q = get_posts(array('post_type' => $type, 'meta_key' => '_idea_legacy_slug', 'meta_value' => $legacy, 'numberposts' => 1, 'fields' => 'ids', 'post_status' => 'publish'));
        return $q ? get_permalink($q[0]) : '';
    };

    if (preg_match('#^/proprieta/proprieta-detail/immobiliare/([^/]+?)(?:/sort/\d+)?\.html$#', $path, $m)) {
        $target = $find($m[1], 'immobile');
    } elseif (preg_match('#^/blog/news-details/article/(.+)\.html$#', $path, $m)) {
        $target = $find('blog:' . $m[1], 'post');
    } elseif (preg_match('#^/promozioni/promo-details/article/(.+)\.html$#', $path, $m)) {
        $target = $find('promo:' . $m[1], 'promozione');
    } else {
        $static = array(
            '/immobili.html'                          => get_post_type_archive_link('immobile'),
            '/home.html'                              => home_url('/'),
            '/azienda/chi-siamo.html'                 => 'azienda',
            '/azienda/clientela-privata.html'         => 'azienda/clientela-privata',
            '/azienda/professionista-immobiliare.html' => 'azienda/professionista-immobiliare',
            '/servizi.html'                           => 'servizi',
            '/servizi/calcolo-dei-costi.html'         => 'servizi',
            '/servizi/tassi-di-interesse.html'        => 'servizi',
            '/mandati.html'                           => 'mandati',
            '/promozioni.html'                        => get_post_type_archive_link('promozione'),
            '/blog.html'                              => 'blog',
            '/contatti.html'                          => 'contatti',
            '/cookie-policy.html'                     => 'privacy-policy',
        );
        if (isset($static[$path])) {
            $dest = $static[$path];
            $target = (strpos($dest, 'http') === 0) ? $dest : (get_page_by_path($dest) ? get_permalink(get_page_by_path($dest)) : '');
        } elseif (preg_match('#^/immobili/ptyp/\d+\.html$#', $path)) {
            $target = get_post_type_archive_link('immobile');
        }
    }

    if ($target !== '') {
        wp_safe_redirect($target, 301);
        exit;
    }
}
