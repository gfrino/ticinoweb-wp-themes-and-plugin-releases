<?php
/**
 * Shortcode del tema: modulo di contatto, calcolatore dei costi, ricerca.
 * Il modulo invia al gestore del parent (ticinoweb_submit_form): salvataggio
 * in "Invii Ricevuti", reCAPTCHA v3 e destinatario dal ticinoWEB CMS.
 *
 * @package Idea_Immobiliare_SA
 */

if (!defined('ABSPATH')) {
    exit;
}

add_shortcode('idea_contact_form', 'idea_immo_contact_form_shortcode');
function idea_immo_contact_form_shortcode($atts = array())
{
    $atts = shortcode_atts(array('oggetto' => '', 'titolo' => ''), $atts, 'idea_contact_form');
    return idea_immo_contact_form($atts['oggetto'], $atts['titolo']);
}

/**
 * Modulo "Richiedi informazioni". $subject precompila l'oggetto (es. nome immobile).
 */
function idea_immo_contact_form($subject = '', $title = '')
{
    static $n = 0;
    $n++;
    $id = 'idea-cf-' . $n;
    $contact = idea_immo_contact();
    ob_start();
    ?>
    <div class="idea-form-wrap">
        <?php if ($title !== '') : ?><h2 class="idea-form-title"><?php echo esc_html($title); ?></h2><?php endif; ?>
        <form class="idea-form" id="<?php echo esc_attr($id); ?>" novalidate>
            <input type="hidden" name="oggetto" value="<?php echo esc_attr($subject); ?>">
            <p class="idea-form__hp" aria-hidden="true"><label>Non compilare<input type="text" name="tw_hp" tabindex="-1" autocomplete="off"></label></p>
            <div class="idea-form__row">
                <div class="idea-form__field">
                    <label for="<?php echo esc_attr($id); ?>-nome"><?php esc_html_e('Nome e cognome', 'idea-immobiliare-sa'); ?> *</label>
                    <input type="text" id="<?php echo esc_attr($id); ?>-nome" name="nome" autocomplete="name" required>
                    <span class="idea-form__error" data-for="nome"></span>
                </div>
                <div class="idea-form__field">
                    <label for="<?php echo esc_attr($id); ?>-email"><?php esc_html_e('Email', 'idea-immobiliare-sa'); ?> *</label>
                    <input type="email" id="<?php echo esc_attr($id); ?>-email" name="email" autocomplete="email" required>
                    <span class="idea-form__error" data-for="email"></span>
                </div>
            </div>
            <div class="idea-form__field">
                <label for="<?php echo esc_attr($id); ?>-tel"><?php esc_html_e('Telefono', 'idea-immobiliare-sa'); ?></label>
                <input type="tel" id="<?php echo esc_attr($id); ?>-tel" name="telefono" autocomplete="tel">
            </div>
            <div class="idea-form__field">
                <label for="<?php echo esc_attr($id); ?>-msg"><?php esc_html_e('Messaggio', 'idea-immobiliare-sa'); ?> *</label>
                <textarea id="<?php echo esc_attr($id); ?>-msg" name="messaggio" rows="5" required><?php echo $subject !== '' ? esc_textarea(sprintf(__('Buongiorno, vorrei ricevere maggiori informazioni su: %s.', 'idea-immobiliare-sa'), $subject)) : ''; ?></textarea>
                <span class="idea-form__error" data-for="messaggio"></span>
            </div>
            <p class="idea-form__privacy"><?php
                $privacy = function_exists('get_privacy_policy_url') ? get_privacy_policy_url() : '';
                if (!$privacy && get_option('tw_privacy_policy_url')) {
                    $privacy = get_option('tw_privacy_policy_url');
                }
                if ($privacy) {
                    printf(
                        /* translators: %s: link to privacy policy */
                        esc_html__('Inviando il modulo accetti il trattamento dei dati secondo la %s.', 'idea-immobiliare-sa'),
                        '<a href="' . esc_url($privacy) . '">' . esc_html__('privacy policy', 'idea-immobiliare-sa') . '</a>'
                    );
                } else {
                    esc_html_e('I dati inviati sono usati solo per rispondere alla tua richiesta.', 'idea-immobiliare-sa');
                }
            ?></p>
            <button type="submit" class="idea-btn idea-btn--mint"><?php esc_html_e('Invia la richiesta', 'idea-immobiliare-sa'); ?></button>
            <p class="idea-form__status" role="status" aria-live="polite"></p>
        </form>
        <?php if ($contact['phone'] !== '') : ?>
            <p class="idea-form__alt"><?php esc_html_e('Preferisci parlare con noi?', 'idea-immobiliare-sa'); ?> <a href="<?php echo esc_attr(idea_immo_tel_href($contact['phone'])); ?>"><?php echo esc_html($contact['phone']); ?></a></p>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('idea_calcolatore', 'idea_immo_calculator_shortcode');
function idea_immo_calculator_shortcode()
{
    ob_start();
    ?>
    <div class="idea-calc" data-idea-calc>
        <h2 class="idea-calc__title"><?php esc_html_e('Calcolatore dei costi', 'idea-immobiliare-sa'); ?></h2>
        <p class="idea-calc__intro"><?php esc_html_e('Il risultato è un’indicazione di base. Un’analisi dettagliata è sempre consigliata: i nostri responsabili sono a tua disposizione per una consulenza personalizzata.', 'idea-immobiliare-sa'); ?></p>
        <div class="idea-calc__grid">
            <div class="idea-form__field">
                <label for="idea-calc-price"><?php esc_html_e('Prezzo di vendita (CHF)', 'idea-immobiliare-sa'); ?></label>
                <input type="number" inputmode="numeric" id="idea-calc-price" min="0" step="1000" value="750000" data-calc="price">
            </div>
            <div class="idea-form__field">
                <label for="idea-calc-equity"><?php esc_html_e('Capitale proprio (CHF)', 'idea-immobiliare-sa'); ?></label>
                <input type="number" inputmode="numeric" id="idea-calc-equity" min="0" step="1000" value="150000" data-calc="equity">
            </div>
            <div class="idea-form__field">
                <label for="idea-calc-rate"><?php esc_html_e('Tasso ipotecario (%)', 'idea-immobiliare-sa'); ?></label>
                <input type="number" inputmode="decimal" id="idea-calc-rate" min="0" max="15" step="0.05" value="1.5" data-calc="rate">
            </div>
        </div>
        <dl class="idea-calc__result" aria-live="polite">
            <div><dt><?php esc_html_e('Ipoteca necessaria', 'idea-immobiliare-sa'); ?></dt><dd data-out="mortgage">–</dd></div>
            <div><dt><?php esc_html_e('Costi annui (interessi, ammortamento, manutenzione)', 'idea-immobiliare-sa'); ?></dt><dd data-out="yearly">–</dd></div>
            <div><dt><?php esc_html_e('Costi mensili', 'idea-immobiliare-sa'); ?></dt><dd data-out="monthly">–</dd></div>
            <div><dt><?php esc_html_e('Capitale proprio minimo (20%)', 'idea-immobiliare-sa'); ?></dt><dd data-out="minequity">–</dd></div>
            <div><dt><?php esc_html_e('Reddito lordo annuo consigliato', 'idea-immobiliare-sa'); ?></dt><dd data-out="income">–</dd></div>
        </dl>
        <p class="idea-calc__note"><?php esc_html_e('Calcolo indicativo con tasso teorico del 5%, manutenzione dell’1% e ammortamento della seconda ipoteca in 15 anni. Non costituisce una consulenza finanziaria.', 'idea-immobiliare-sa'); ?></p>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('idea_ricerca', function () {
    return idea_immo_search_form();
});
