<?php
/**
 * Dati dell'immobile: chiavi dei campi e helper di lettura.
 *
 * @package Idea_Immobiliare_SA
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Campi dell'immobile: chiave meta => [etichetta, tipo, unità, aiuto].
 * Il valore è sempre salvato come testo semplice; "numero" accetta decimali.
 */
function idea_immo_fields()
{
    return array(
        '_idea_ref'          => array('label' => __('ID oggetto', 'idea-immobiliare-sa'), 'type' => 'text', 'help' => __('Il numero con cui riconoscete l’oggetto, es. 20208.', 'idea-immobiliare-sa')),
        '_idea_location'     => array('label' => __('Località', 'idea-immobiliare-sa'), 'type' => 'text', 'help' => __('Il comune, es. Cadenazzo.', 'idea-immobiliare-sa')),
        '_idea_address'      => array('label' => __('Indirizzo', 'idea-immobiliare-sa'), 'type' => 'text', 'help' => ''),
        '_idea_price'        => array('label' => __('Prezzo (CHF)', 'idea-immobiliare-sa'), 'type' => 'number', 'help' => __('Solo cifre, es. 890000. Lascia vuoto per «su richiesta».', 'idea-immobiliare-sa')),
        '_idea_rooms'        => array('label' => __('Numero locali', 'idea-immobiliare-sa'), 'type' => 'number', 'step' => '0.5', 'help' => ''),
        '_idea_surface'      => array('label' => __('Superficie abitabile (m²)', 'idea-immobiliare-sa'), 'type' => 'number', 'help' => ''),
        '_idea_land'         => array('label' => __('Terreno (m²)', 'idea-immobiliare-sa'), 'type' => 'number', 'help' => ''),
        '_idea_garden'       => array('label' => __('Giardino (m²)', 'idea-immobiliare-sa'), 'type' => 'number', 'help' => ''),
        '_idea_terrace'      => array('label' => __('Terrazzo/i (m²)', 'idea-immobiliare-sa'), 'type' => 'number', 'help' => ''),
        '_idea_transport'    => array('label' => __('Trasporti pubblici', 'idea-immobiliare-sa'), 'type' => 'text', 'help' => __('es. 300 m', 'idea-immobiliare-sa')),
        '_idea_shops'        => array('label' => __('Negozi', 'idea-immobiliare-sa'), 'type' => 'text', 'help' => __('es. 300 m', 'idea-immobiliare-sa')),
        '_idea_availability' => array('label' => __('Disponibilità', 'idea-immobiliare-sa'), 'type' => 'text', 'help' => __('es. Subito, Da concordare', 'idea-immobiliare-sa')),
    );
}

/** Stato dell'annuncio. */
function idea_immo_statuses()
{
    return array(
        'disponibile' => __('In vendita / disponibile', 'idea-immobiliare-sa'),
        'riservato'   => __('Riservato', 'idea-immobiliare-sa'),
        'archivio'    => __('Archivio (non più disponibile)', 'idea-immobiliare-sa'),
    );
}

function idea_immo_offers()
{
    return array(
        'vendita' => __('Vendita', 'idea-immobiliare-sa'),
        'affitto' => __('Affitto', 'idea-immobiliare-sa'),
    );
}

function idea_immo_status($post_id = 0)
{
    $post_id = $post_id ?: get_the_ID();
    $status = (string) get_post_meta($post_id, '_idea_status', true);
    return isset(idea_immo_statuses()[$status]) ? $status : 'disponibile';
}

function idea_immo_offer($post_id = 0)
{
    $post_id = $post_id ?: get_the_ID();
    $offer = (string) get_post_meta($post_id, '_idea_offer', true);
    return isset(idea_immo_offers()[$offer]) ? $offer : 'vendita';
}

/** "1'880'000" */
function idea_immo_number($n)
{
    return number_format((float) $n, 0, '.', '’');
}

/** Prezzo pronto da mostrare: "CHF 890’000" oppure "Su richiesta". */
function idea_immo_price_label($post_id = 0)
{
    $post_id = $post_id ?: get_the_ID();
    $price = (float) get_post_meta($post_id, '_idea_price', true);
    if ($price <= 0) {
        return __('Prezzo su richiesta', 'idea-immobiliare-sa');
    }
    $suffix = idea_immo_offer($post_id) === 'affitto' ? ' / ' . __('mese', 'idea-immobiliare-sa') : '';
    return 'CHF ' . idea_immo_number($price) . $suffix;
}

/** Numero con al massimo un decimale: 4.5, 3, 2.5 */
function idea_immo_trim_number($n)
{
    $n = (float) $n;
    return rtrim(rtrim(number_format($n, 1, '.', ''), '0'), '.');
}

/**
 * Elenco dei dati dell'immobile pronto per la scheda: [ [label, value], ... ]
 * Salta i valori vuoti. Le righe extra libere stanno in `_idea_extra`.
 */
function idea_immo_details($post_id = 0, $short = false)
{
    $post_id = $post_id ?: get_the_ID();
    $get = function ($key) use ($post_id) {
        return trim((string) get_post_meta($post_id, $key, true));
    };
    $rows = array();
    $ref = $get('_idea_ref');
    if ($ref !== '' && !$short) {
        $rows[] = array(__('ID oggetto', 'idea-immobiliare-sa'), $ref);
    }
    $rooms = $get('_idea_rooms');
    if ($rooms !== '') {
        $rows[] = array(__('Locali', 'idea-immobiliare-sa'), idea_immo_trim_number($rooms));
    }
    foreach (array(
        '_idea_surface' => __('Superficie', 'idea-immobiliare-sa'),
        '_idea_land'    => __('Terreno', 'idea-immobiliare-sa'),
        '_idea_garden'  => __('Giardino', 'idea-immobiliare-sa'),
        '_idea_terrace' => __('Terrazzo/i', 'idea-immobiliare-sa'),
    ) as $key => $label) {
        $v = $get($key);
        if ($v !== '' && (float) $v > 0) {
            $rows[] = array($label, idea_immo_number($v) . ' m²');
        }
    }
    if ($short) {
        return $rows;
    }
    foreach (array(
        '_idea_address'      => __('Indirizzo', 'idea-immobiliare-sa'),
        '_idea_transport'    => __('Trasporti pubblici', 'idea-immobiliare-sa'),
        '_idea_shops'        => __('Negozi', 'idea-immobiliare-sa'),
        '_idea_availability' => __('Disponibilità', 'idea-immobiliare-sa'),
    ) as $key => $label) {
        $v = $get($key);
        if ($v !== '') {
            $rows[] = array($label, $v);
        }
    }
    $extra = get_post_meta($post_id, '_idea_extra', true);
    if (is_array($extra)) {
        foreach ($extra as $label => $value) {
            if (trim((string) $value) !== '') {
                $rows[] = array((string) $label, (string) $value);
            }
        }
    }
    return $rows;
}

/** ID degli allegati della galleria (il primo è l'immagine di copertina). */
function idea_immo_gallery_ids($post_id = 0)
{
    $post_id = $post_id ?: get_the_ID();
    $ids = get_post_meta($post_id, '_idea_gallery', true);
    $ids = is_array($ids) ? array_map('intval', $ids) : array();
    $ids = array_values(array_filter($ids, function ($id) {
        return $id > 0 && get_post_type($id) === 'attachment';
    }));
    if (!$ids && has_post_thumbnail($post_id)) {
        $ids[] = (int) get_post_thumbnail_id($post_id);
    }
    return $ids;
}

/** Località in chiaro (fallback sul termine di zona). */
function idea_immo_location($post_id = 0)
{
    $post_id = $post_id ?: get_the_ID();
    return trim((string) get_post_meta($post_id, '_idea_location', true));
}

function idea_immo_term_name($taxonomy, $post_id = 0)
{
    $terms = get_the_terms($post_id ?: get_the_ID(), $taxonomy);
    return $terms && !is_wp_error($terms) ? $terms[0]->name : '';
}

/** Indirizzo a cui porta una promozione nello slider: il suo link, se impostato, altrimenti la sua pagina. */
function idea_immo_promo_link($post)
{
    $link = trim((string) get_post_meta(get_post($post)->ID, '_idea_link', true));
    return $link !== '' ? $link : get_permalink($post);
}
