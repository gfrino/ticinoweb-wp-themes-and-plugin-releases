<?php
/**
 * SEO: arricchimento del JSON-LD del parent (tW SEO) e annunci immobiliari.
 * Title, meta description, Open Graph e canonical restano al parent.
 *
 * @package Idea_Immobiliare_SA
 */

if (!defined('ABSPATH')) {
    exit;
}

add_filter('ticinoweb_seo_og_locale', function () {
    return 'it_CH';
});

/** L'organizzazione è un'agenzia immobiliare (sottotipo di LocalBusiness). */
add_filter('ticinoweb_seo_jsonld_org_schema', 'idea_immo_enrich_org_schema');
function idea_immo_enrich_org_schema($schema)
{
    $schema['@type'] = 'RealEstateAgent';
    $contact = idea_immo_contact();
    if ($contact['phone'] !== '' && empty($schema['telephone'])) {
        $schema['telephone'] = $contact['phone'];
    }
    if ($contact['email'] !== '' && empty($schema['email'])) {
        $schema['email'] = $contact['email'];
    }
    if (empty($schema['areaServed'])) {
        $schema['areaServed'] = array('@type' => 'AdministrativeArea', 'name' => 'Ticino');
    }
    $schema['currenciesAccepted'] = 'CHF';
    return $schema;
}

/**
 * Annuncio dell'immobile: RealEstateListing con offerta, dati del fabbricato e immagini,
 * al posto dello schema Article del parent (una sola scheda JSON-LD per pagina).
 */
add_filter('ticinoweb_seo_jsonld_article_schema', 'idea_immo_listing_schema', 10, 2);
function idea_immo_listing_schema($article_schema, $post = null)
{
    // Il parent stampa uno schema "Article" per ogni contenuto singolo: per gli immobili
    // lo sostituiamo con l'annuncio, così la pagina ha una sola scheda JSON-LD.
    if (!$post || $post->post_type !== 'immobile') {
        return $article_schema;
    }
    $id = $post->ID;
    $images = array();
    foreach (array_slice(idea_immo_gallery_ids($id), 0, 8) as $att) {
        $url = wp_get_attachment_image_url($att, 'large');
        if ($url) {
            $images[] = $url;
        }
    }
    $desc = trim(wp_strip_all_tags(get_the_excerpt($id)));
    if ($desc === '') {
        $desc = wp_trim_words(wp_strip_all_tags(get_post_field('post_content', $id)), 40, '…');
    }

    $schema = array(
        '@context'    => 'https://schema.org',
        '@type'       => 'RealEstateListing',
        'name'        => get_the_title($id),
        'url'         => get_permalink($id),
        'datePosted'  => get_the_date('c', $id),
        'description' => $desc,
    );
    if ($images) {
        $schema['image'] = $images;
    }

    $location = idea_immo_location($id);
    $about = array('@type' => 'Residence', 'name' => get_the_title($id));
    $address = array('@type' => 'PostalAddress', 'addressCountry' => 'CH', 'addressRegion' => 'Ticino');
    if ($location !== '') {
        $address['addressLocality'] = $location;
    }
    $street = trim((string) get_post_meta($id, '_idea_address', true));
    if ($street !== '') {
        $address['streetAddress'] = $street;
    }
    $about['address'] = $address;
    $rooms = (float) get_post_meta($id, '_idea_rooms', true);
    if ($rooms > 0) {
        $about['numberOfRooms'] = $rooms;
    }
    $surface = (float) get_post_meta($id, '_idea_surface', true);
    if ($surface > 0) {
        $about['floorSize'] = array('@type' => 'QuantitativeValue', 'value' => $surface, 'unitCode' => 'MTK');
    }
    $schema['about'] = $about;

    $price = (float) get_post_meta($id, '_idea_price', true);
    if ($price > 0) {
        $schema['offers'] = array(
            '@type'         => 'Offer',
            'price'         => $price,
            'priceCurrency' => 'CHF',
            'availability'  => idea_immo_status($id) === 'archivio' ? 'https://schema.org/SoldOut' : 'https://schema.org/InStock',
        );
    }

    return $schema;
}

/** Gli immobili in archivio restano raggiungibili ma fuori dall'indice. */
add_filter('wp_robots', 'idea_immo_robots_archived');
function idea_immo_robots_archived($robots)
{
    if (is_singular('immobile') && idea_immo_status(get_the_ID()) === 'archivio') {
        $robots['noindex'] = true;
        $robots['follow']  = true;
        unset($robots['index']);
    }
    return $robots;
}
