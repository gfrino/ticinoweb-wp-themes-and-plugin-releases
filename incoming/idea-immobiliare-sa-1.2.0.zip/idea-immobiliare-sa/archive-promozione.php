<?php
/**
 * Archivio promozioni immobiliari.
 *
 * @package Idea_Immobiliare_SA
 */
get_header(); ?>
<main id="main">
	<header class="idea-pagehead">
		<div class="idea-container">
			<?php echo ticinoweb_get_breadcrumbs(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<h1><?php esc_html_e('Promozioni immobiliari', 'idea-immobiliare-sa'); ?></h1>
			<p class="idea-pagehead__lead"><?php esc_html_e('Scelte con cura e selezionate per voi.', 'idea-immobiliare-sa'); ?></p>
		</div>
	</header>
	<section class="idea-section">
		<div class="idea-container">
			<?php if (have_posts()) : ?>
				<div class="idea-grid idea-grid--3">
					<?php while (have_posts()) : the_post(); get_template_part('template-parts/post-card'); endwhile; ?>
				</div>
				<?php the_posts_pagination(array('mid_size' => 1, 'prev_text' => '←', 'next_text' => '→', 'class' => 'idea-pagination')); ?>
			<?php else : ?>
				<p class="idea-empty"><?php esc_html_e('Nessuna promozione al momento.', 'idea-immobiliare-sa'); ?></p>
			<?php endif; ?>
		</div>
	</section>
</main>
<?php get_footer(); ?>
