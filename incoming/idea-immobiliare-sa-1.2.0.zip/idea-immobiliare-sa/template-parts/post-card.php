<?php
/**
 * Scheda di un articolo o di una promozione.
 *
 * @package Idea_Immobiliare_SA
 */
?>
<article <?php post_class('idea-card idea-card--post'); ?>>
	<?php if (has_post_thumbnail()) : ?>
	<a class="idea-card__media" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
		<?php the_post_thumbnail('idea-card', array('loading' => 'lazy', 'alt' => '')); ?>
	</a>
	<?php endif; ?>
	<div class="idea-card__body">
		<?php if (get_post_type() === 'post') : ?><p class="idea-card__meta"><span><?php echo esc_html(get_the_date()); ?></span></p><?php endif; ?>
		<h3 class="idea-card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
		<p class="idea-card__excerpt"><?php echo esc_html(wp_trim_words(get_the_excerpt(), 28, '…')); ?></p>
		<a class="idea-card__link" href="<?php the_permalink(); ?>"><?php esc_html_e('Leggi tutto', 'idea-immobiliare-sa'); ?> →</a>
	</div>
</article>
