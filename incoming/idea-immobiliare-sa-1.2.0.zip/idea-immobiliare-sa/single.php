<?php
/**
 * Articolo del blog o promozione.
 *
 * @package Idea_Immobiliare_SA
 */
get_header();
while (have_posts()) : the_post();
	$is_post = get_post_type() === 'post'; ?>
<main id="main">
	<header class="idea-pagehead">
		<div class="idea-container">
			<?php echo ticinoweb_get_breadcrumbs(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<h1><?php the_title(); ?></h1>
			<?php if ($is_post) : ?><p class="idea-pagehead__lead"><time datetime="<?php echo esc_attr(get_the_date('c')); ?>"><?php echo esc_html(get_the_date()); ?></time></p><?php endif; ?>
		</div>
	</header>
	<article class="idea-section">
		<div class="idea-container idea-prose">
			<?php if (has_post_thumbnail()) : ?><figure class="idea-prose__cover"><?php the_post_thumbnail('large'); ?></figure><?php endif; ?>
			<?php the_content(); ?>
			<aside class="idea-cta">
				<h2><?php esc_html_e('Vuoi saperne di più?', 'idea-immobiliare-sa'); ?></h2>
				<?php echo idea_immo_contact_form(get_the_title()); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			</aside>
			<p><a href="<?php echo esc_url($is_post ? (get_option('page_for_posts') ? get_permalink(get_option('page_for_posts')) : home_url('/')) : get_post_type_archive_link('promozione')); ?>">← <?php esc_html_e('Torna indietro', 'idea-immobiliare-sa'); ?></a></p>
		</div>
	</article>
</main>
<?php endwhile;
get_footer();
