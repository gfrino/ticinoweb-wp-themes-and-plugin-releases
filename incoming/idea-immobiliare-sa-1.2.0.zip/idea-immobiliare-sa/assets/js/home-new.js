/* Home NEW: unhurried photography and progressive catalog navigation. */
(function () {
  'use strict';
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)');
  let paused = reduce.matches;
  const lights = [...document.querySelectorAll('[data-hn-light]')];
  const visibleLights = new Set();
  function updateLights() {
    lights.forEach(light => {
      light.dataset.hnMotion = !paused && !reduce.matches && !document.hidden && visibleLights.has(light) ? 'running' : 'paused';
    });
  }
  if ('IntersectionObserver' in window) {
    const lightVisibility = new IntersectionObserver(entries => {
      entries.forEach(entry => { if (entry.isIntersecting) visibleLights.add(entry.target); else visibleLights.delete(entry.target); });
      updateLights();
    });
    lights.forEach(light => lightVisibility.observe(light));
  }
  document.addEventListener('visibilitychange', updateLights);
  reduce.addEventListener('change', () => { paused = reduce.matches; updateLights(); });
  updateLights();

  const hero = document.querySelector('[data-hn-hero]');
  if (hero) {
    const photos = [...hero.querySelectorAll('[data-hn-photo]')];
    const projects = [...hero.querySelectorAll('[data-hn-project]')];
    const controls = hero.querySelector('[data-hn-controls]');
    let index = 0, timer = null, visible = true, startX = null;
    const pause = hero.querySelector('[data-hn-pause]');
    function stop() { window.clearTimeout(timer); timer = null; }
    function schedule() {
      stop();
      const active = !paused && !reduce.matches && !document.hidden && visible;
      hero.dataset.hnMotion = active ? 'running' : 'paused';
      // Keep keyboard reading stable; pointer hover never stops the scene.
      if (active && photos.length > 1 && !hero.querySelector(':focus-visible')) {
        timer = window.setTimeout(() => { show(index + 1); schedule(); }, 7500);
      }
    }
    function show(next) {
      index = (next + photos.length) % photos.length;
      photos.forEach((photo, i) => {
        const img = photo.querySelector('img');
        if (i === index && img) img.loading = 'eager';
        photo.classList.toggle('is-active', i === index);
      });
      projects.forEach((project, i) => { project.hidden = i !== index; project.classList.toggle('is-active', i === index); });
      const counter = hero.querySelector('[data-hn-current]');
      if (counter) counter.textContent = String(index + 1).padStart(2, '0');
    }
    function updatePause() {
      if (!pause) return;
      pause.textContent = paused ? pause.dataset.play : pause.dataset.pause;
      pause.setAttribute('aria-pressed', String(paused));
      pause.setAttribute('aria-label', paused ? (pause.dataset.playLabel || pause.dataset.play) : (pause.dataset.pauseLabel || pause.dataset.pause));
    }
    if (controls) {
      controls.hidden = false;
      hero.querySelector('[data-hn-prev]')?.addEventListener('click', () => { show(index - 1); schedule(); });
      hero.querySelector('[data-hn-next]')?.addEventListener('click', () => { show(index + 1); schedule(); });
      pause.addEventListener('click', () => { paused = !paused; updatePause(); updateLights(); schedule(); });
      hero.addEventListener('focusin', schedule);
      hero.addEventListener('focusout', () => window.setTimeout(schedule, 0));
      document.addEventListener('visibilitychange', schedule);
      reduce.addEventListener('change', () => { paused = reduce.matches; updatePause(); schedule(); });
      hero.addEventListener('touchstart', e => { startX = e.touches[0].clientX; stop(); }, { passive: true });
      hero.addEventListener('touchend', e => {
        if (photos.length > 1 && startX !== null && Math.abs(e.changedTouches[0].clientX - startX) > 60) show(index + (e.changedTouches[0].clientX < startX ? 1 : -1));
        startX = null; schedule();
      }, { passive: true });
      // One lifecycle for photos and light: no invisible or background loops.
      if ('IntersectionObserver' in window) {
        const visibility = new IntersectionObserver(entries => {
          visible = entries[0].isIntersecting;
          schedule();
        }, { threshold: 0 });
        visibility.observe(hero);
      }
      updatePause(); schedule();
    }
  }

  const catalog = document.querySelector('[data-hn-catalog]');
  if (!catalog || !window.fetch || !window.AbortController) return;
  let request = null;
  async function load(url, push, focusResults = false) {
    if (request) request.abort();
    const controller = new AbortController(); request = controller;
    const results = catalog.querySelector('[data-hn-results]');
    const status = catalog.querySelector('[data-hn-status]');
    results.setAttribute('aria-busy', 'true');
    status.textContent = status.dataset.loading;
    try {
      const response = await fetch(url, { signal: controller.signal, credentials: 'same-origin' });
      if (!response.ok) throw new Error('HTTP ' + response.status);
      const doc = new DOMParser().parseFromString(await response.text(), 'text/html');
      const incoming = doc.querySelector('[data-hn-results]');
      const incomingStatus = doc.querySelector('[data-hn-status]');
      if (!incoming || !incomingStatus) throw new Error('Missing catalog');
      results.replaceChildren(...incoming.childNodes);
      status.textContent = incomingStatus.textContent;
      const selected = new URL(url, window.location.href).searchParams.get('categoria') || '';
      catalog.querySelectorAll('[data-hn-filter]').forEach(link => {
        const current = (new URL(link.href).searchParams.get('categoria') || '') === selected;
        if (current) link.setAttribute('aria-current', 'true'); else link.removeAttribute('aria-current');
      });
      const categorySelect = document.getElementById('idea-s-cat');
      if (categorySelect) { categorySelect.value = selected; categorySelect.dispatchEvent(new Event('change', { bubbles: true })); }
      if (focusResults) {
        const heading = document.getElementById('hn-catalog-title');
        heading.setAttribute('tabindex', '-1');
        heading.focus({ preventScroll: true });
      }
      if (push) history.pushState({ ideaCatalog: true }, '', url);
    } catch (error) {
      if (error.name !== 'AbortError') window.location.assign(url);
    } finally {
      if (request === controller) results.removeAttribute('aria-busy');
    }
  }
  catalog.addEventListener('click', e => {
    const link = e.target.closest('[data-hn-filter], .hn-pagination a');
    if (!link || e.button !== 0 || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
    e.preventDefault();
    if (link.closest('.hn-pagination')) catalog.scrollIntoView({ behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' });
    load(link.href, true, Boolean(link.closest('.hn-pagination')));
  });
  window.addEventListener('popstate', () => load(window.location.href, false));
})();
