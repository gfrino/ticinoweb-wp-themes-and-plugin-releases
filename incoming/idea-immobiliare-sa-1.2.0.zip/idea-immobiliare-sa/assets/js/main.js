/**
 * L'Idea Immobiliare SA — menu mobile, galleria dell'immobile, calcolatore dei costi.
 */
(function () {
  'use strict';

  /* Menu mobile */
  var burger = document.getElementById('idea-burger');
  var nav = document.getElementById('idea-nav');
  if (burger && nav) {
    burger.addEventListener('click', function () {
      var open = nav.classList.toggle('is-open');
      burger.setAttribute('aria-expanded', open ? 'true' : 'false');
      burger.setAttribute('aria-label', open ? 'Chiudi il menu' : 'Apri il menu');
      document.body.classList.toggle('idea-nav-open', open);
    });
    nav.addEventListener('click', function (e) {
      if (e.target.closest('a') && nav.classList.contains('is-open')) burger.click();
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && nav.classList.contains('is-open')) { burger.click(); burger.focus(); }
    });
  }

  /* Galleria: miniature, frecce, tastiera e swipe */
  document.querySelectorAll('[data-idea-gallery]').forEach(function (root) {
    var img = root.querySelector('.idea-gallery__img');
    var thumbs = Array.prototype.slice.call(root.querySelectorAll('.idea-gallery__thumbs button'));
    var counter = root.querySelector('[data-idea-current]');
    if (!img || !thumbs.length) return;
    var idx = 0;

    function show(i) {
      idx = (i + thumbs.length) % thumbs.length;
      var btn = thumbs[idx];
      img.removeAttribute('srcset');
      img.removeAttribute('sizes');
      img.src = btn.getAttribute('data-full');
      thumbs.forEach(function (t, n) { if (n === idx) t.setAttribute('aria-current', 'true'); else t.removeAttribute('aria-current'); });
      if (counter) counter.textContent = String(idx + 1);
      var preload = thumbs[(idx + 1) % thumbs.length].getAttribute('data-full');
      if (preload) { var p = new Image(); p.src = preload; }
    }

    thumbs.forEach(function (t, i) { t.addEventListener('click', function () { show(i); }); });
    var prev = root.querySelector('.idea-gallery__nav--prev');
    var next = root.querySelector('.idea-gallery__nav--next');
    if (prev) prev.addEventListener('click', function () { show(idx - 1); });
    if (next) next.addEventListener('click', function () { show(idx + 1); });

    root.setAttribute('tabindex', '0');
    root.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowLeft') { show(idx - 1); e.preventDefault(); }
      if (e.key === 'ArrowRight') { show(idx + 1); e.preventDefault(); }
    });

    var x0 = null;
    root.addEventListener('touchstart', function (e) { x0 = e.touches[0].clientX; }, { passive: true });
    root.addEventListener('touchend', function (e) {
      if (x0 === null) return;
      var dx = e.changedTouches[0].clientX - x0;
      if (Math.abs(dx) > 40) show(idx + (dx < 0 ? 1 : -1));
      x0 = null;
    });
  });

  /* Calcolatore dei costi */
  document.querySelectorAll('[data-idea-calc]').forEach(function (root) {
    var price = root.querySelector('[data-calc="price"]');
    var equity = root.querySelector('[data-calc="equity"]');
    var rate = root.querySelector('[data-calc="rate"]');
    var out = {};
    root.querySelectorAll('[data-out]').forEach(function (el) { out[el.getAttribute('data-out')] = el; });

    function chf(n) {
      return 'CHF ' + Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '’');
    }

    function calc() {
      var p = Math.max(0, parseFloat(price.value) || 0);
      var e = Math.max(0, parseFloat(equity.value) || 0);
      var r = Math.max(0, parseFloat(rate.value) || 0) / 100;
      var mortgage = Math.max(0, p - e);
      var amort = Math.max(0, mortgage - p * 0.65) / 15;
      var maint = p * 0.01;
      var yearly = mortgage * r + amort + maint;
      var theoretical = mortgage * 0.05 + amort + maint;
      out.mortgage.textContent = chf(mortgage);
      out.yearly.textContent = chf(yearly);
      out.monthly.textContent = chf(yearly / 12);
      out.minequity.textContent = chf(p * 0.2);
      out.income.textContent = p > 0 ? chf(theoretical * 3) : '–';
    }

    [price, equity, rate].forEach(function (el) { el.addEventListener('input', calc); });
    calc();
  });

  /* Slider delle promozioni: frecce, puntini, swipe, avanzamento automatico */
  document.querySelectorAll('[data-idea-slider]').forEach(function (root) {
    var slides = Array.prototype.slice.call(root.querySelectorAll('.idea-slide'));
    var dots = Array.prototype.slice.call(root.querySelectorAll('.idea-slider__dots button'));
    if (slides.length < 2) return;
    var idx = 0, timer = null, startX = null, moved = false;
    var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    function show(i) {
      idx = (i + slides.length) % slides.length;
      slides.forEach(function (s, n) {
        var on = n === idx;
        s.classList.toggle('is-active', on);
        if (on) { s.removeAttribute('aria-hidden'); s.removeAttribute('tabindex'); } else { s.setAttribute('aria-hidden', 'true'); s.setAttribute('tabindex', '-1'); }
      });
      dots.forEach(function (d, n) { if (n === idx) d.setAttribute('aria-current', 'true'); else d.removeAttribute('aria-current'); });
    }
    function stop() { if (timer) { clearInterval(timer); timer = null; } }
    function start() { if (!reduce && !timer) timer = setInterval(function () { show(idx + 1); }, 6000); }

    root.querySelector('.idea-slider__nav--prev').addEventListener('click', function () { show(idx - 1); });
    root.querySelector('.idea-slider__nav--next').addEventListener('click', function () { show(idx + 1); });
    dots.forEach(function (d, n) { d.addEventListener('click', function () { show(n); }); });
    root.addEventListener('mouseenter', stop);
    root.addEventListener('mouseleave', start);
    root.addEventListener('focusin', stop);
    root.addEventListener('focusout', start);
    root.addEventListener('touchstart', function (e) { startX = e.touches[0].clientX; moved = false; stop(); }, { passive: true });
    root.addEventListener('touchend', function (e) {
      if (startX === null) return;
      var dx = e.changedTouches[0].clientX - startX;
      if (Math.abs(dx) > 50) { moved = true; show(idx + (dx < 0 ? 1 : -1)); }
      startX = null; start();
    });
    root.addEventListener('click', function (e) { if (moved) { e.preventDefault(); moved = false; } }, true);
    start();
  });
})();
