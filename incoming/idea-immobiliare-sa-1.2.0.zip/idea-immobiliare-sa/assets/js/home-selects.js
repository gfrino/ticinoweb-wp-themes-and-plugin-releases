/* Home NEW: progressive, single-select listboxes over the existing GET controls. */
(function () {
  'use strict';
  if (window.matchMedia('(forced-colors: active)').matches) return;
  let opened = null;
  const controls = [];
  document.querySelectorAll('.hn-search select').forEach(select => {
    const label = select.labels[0];
    if (!label || select.disabled || select.multiple) return;
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'hn-select-trigger';
    button.id = select.id + '-trigger';
    button.setAttribute('role', 'combobox');
    button.setAttribute('aria-haspopup', 'listbox');
    button.setAttribute('aria-expanded', 'false');
    const value = document.createElement('span');
    value.className = 'hn-select-value';
    const chevron = document.createElement('span');
    chevron.className = 'hn-select-chevron';
    chevron.setAttribute('aria-hidden', 'true');
    button.append(value, chevron);
    const panel = document.createElement('div');
    panel.className = 'hn-select-panel';
    panel.hidden = true;
    panel.id = select.id + '-listbox';
    panel.setAttribute('role', 'listbox');
    label.id ||= select.id + '-label';
    button.setAttribute('aria-labelledby', label.id + ' ' + button.id + '-value');
    value.id = button.id + '-value';
    panel.setAttribute('aria-labelledby', label.id);
    button.setAttribute('aria-controls', panel.id);
    let active = select.selectedIndex, buffer = '', typedAt = 0;
    const options = [...select.options];
    const rows = options.map((option, i) => {
      const row = document.createElement('div');
      row.className = 'hn-select-option';
      row.id = panel.id + '-' + i;
      row.setAttribute('role', 'option');
      row.textContent = option.textContent;
      if (option.disabled) row.setAttribute('aria-disabled', 'true');
      row.addEventListener('pointerdown', e => e.preventDefault());
      row.addEventListener('click', () => { if (!option.disabled) commit(i); });
      panel.append(row);
      return row;
    });
    function sync() {
      value.textContent = options[select.selectedIndex]?.textContent || '';
      button.dataset.selected = String(select.value !== '');
      rows.forEach((row, i) => row.setAttribute('aria-selected', String(i === select.selectedIndex)));
    }
    function highlight(i) {
      active = i;
      rows.forEach((row, n) => row.classList.toggle('is-highlighted', n === i));
      button.setAttribute('aria-activedescendant', rows[i].id);
      rows[i].scrollIntoView({ block: 'nearest' });
    }
    function position() {
      if (opened !== control) return;
      const r = button.getBoundingClientRect();
      const vh = window.visualViewport?.height || innerHeight;
      if (r.bottom < 0 || r.top > vh) { close(); return; }
      const width = Math.min(Math.max(r.width, 240), innerWidth - 24);
      const below = vh - r.bottom - 12, above = r.top - 12;
      const up = below < Math.min(panel.scrollHeight, 220) && above > below;
      const height = Math.min(340, Math.max(96, up ? above : below));
      panel.style.width = width + 'px';
      panel.style.maxHeight = height + 'px';
      panel.style.left = Math.max(12, Math.min(r.left, innerWidth - width - 12)) + 'px';
      panel.style.top = (up ? Math.max(12, r.top - Math.min(panel.scrollHeight, height) - 8) : r.bottom + 8) + 'px';
      panel.dataset.side = up ? 'above' : 'below';
    }
    function open() {
      if (opened && opened !== control) opened.close();
      opened = control;
      panel.hidden = false;
      button.setAttribute('aria-expanded', 'true');
      sync(); position();
      highlight(Math.max(0, select.selectedIndex));
    }
    function close() {
      panel.hidden = true;
      button.setAttribute('aria-expanded', 'false');
      button.removeAttribute('aria-activedescendant');
      buffer = '';
      if (opened === control) opened = null;
    }
    function commit(i) {
      select.selectedIndex = i;
      select.dispatchEvent(new Event('input', { bubbles: true }));
      select.dispatchEvent(new Event('change', { bubbles: true }));
      close(); button.focus({ preventScroll: true });
    }
    function step(direction) {
      let next = active;
      do { next += direction; } while (next >= 0 && next < options.length && options[next].disabled);
      if (next >= 0 && next < options.length) highlight(next);
    }
    const control = { button, panel, close, position, sync };
    controls.push(control);
    button.addEventListener('click', () => opened === control ? close() : open());
    button.addEventListener('keydown', e => {
      if (e.key === 'Tab') { close(); return; }
      if (e.key === 'Escape') { e.preventDefault(); close(); return; }
      if (['ArrowDown', 'ArrowUp', 'Home', 'End', 'Enter', ' '].includes(e.key)) {
        e.preventDefault();
        if (opened !== control) { open(); return; }
        if (e.key === 'Enter' || e.key === ' ') commit(active);
        else if (e.key === 'Home') highlight(options.findIndex(o => !o.disabled));
        else if (e.key === 'End') highlight(options.findLastIndex(o => !o.disabled));
        else step(e.key === 'ArrowDown' ? 1 : -1);
      } else if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
        e.preventDefault();
        if (opened !== control) open();
        const now = Date.now();
        buffer = now - typedAt > 650 ? e.key : buffer + e.key;
        typedAt = now;
        const normalize = text => text.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase();
        const match = options.findIndex(o => !o.disabled && normalize(o.textContent.trim()).startsWith(normalize(buffer)));
        if (match >= 0) highlight(match);
      }
    });
    button.addEventListener('blur', close);
    select.addEventListener('change', sync);
    select.form?.addEventListener('reset', () => setTimeout(() => { close(); sync(); }, 0));
    select.after(button);
    document.body.append(panel);
    sync();
    select.hidden = true;
    label.htmlFor = button.id;
  });
  document.addEventListener('pointerdown', e => {
    if (opened && !opened.button.contains(e.target) && !opened.panel.contains(e.target)) opened.close();
  });
  let frame = null;
  function reposition() {
    if (opened && frame === null) frame = requestAnimationFrame(() => { frame = null; opened?.position(); });
  }
  window.addEventListener('scroll', reposition, { capture: true, passive: true });
  window.addEventListener('resize', reposition, { passive: true });
  window.visualViewport?.addEventListener('resize', reposition, { passive: true });
  window.addEventListener('pageshow', () => controls.forEach(control => { control.close(); control.sync(); }));
})();
