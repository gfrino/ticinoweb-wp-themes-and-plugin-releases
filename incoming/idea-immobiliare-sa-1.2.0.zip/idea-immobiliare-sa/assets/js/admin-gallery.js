/**
 * Schermata di inserimento: selettore foto (più foto o una sola), dati
 * aggiuntivi a righe, anteprima del prezzo.
 */
(function ($) {
  'use strict';

  /* ── Foto ── */
  $('.idea-media').each(function () {
    var box = $(this);
    var multiple = box.data('mode') === 'gallery';
    var input = box.find('.idea-media__input');
    var list = box.find('.idea-media__list');
    var frame;

    function sync() {
      var ids = [];
      list.children('li[data-id]').each(function () { ids.push($(this).data('id')); });
      input.val(ids.join(','));
      box.toggleClass('is-full', !multiple && ids.length > 0);
    }

    function item(id, url) {
      return $('<li/>').attr('data-id', id)
        .append($('<img/>').attr({ src: url, alt: '' }))
        .append($('<button/>').attr({ type: 'button', 'aria-label': 'Rimuovi' }).addClass('idea-media__remove').text('×'));
    }

    if (multiple) list.sortable({ items: '> li[data-id]', update: sync, tolerance: 'pointer', placeholder: 'idea-media__ph' });
    sync();

    list.on('click', '.idea-media__remove', function () {
      $(this).closest('li').remove();
      sync();
    });

    box.on('click', '.idea-media__addbtn', function (e) {
      e.preventDefault();
      if (!frame) {
        frame = wp.media({
          title: box.data('title'),
          button: { text: box.data('button') },
          library: { type: 'image' },
          multiple: multiple ? 'add' : false
        });
        frame.on('open', function () {
          var sel = frame.state().get('selection');
          sel.reset();
          list.children('li[data-id]').each(function () {
            var att = wp.media.attachment($(this).data('id'));
            att.fetch();
            sel.add(att);
          });
        });
        frame.on('select', function () {
          var sel = frame.state().get('selection');
          var existing = {};
          list.children('li[data-id]').each(function () { existing[$(this).data('id')] = $(this); });
          var next = [];
          sel.each(function (att) {
            var id = att.get('id');
            if (existing[id]) { next.push(existing[id]); return; }
            var sizes = att.get('sizes') || {};
            next.push(item(id, (sizes.medium || sizes.thumbnail || {}).url || att.get('url')));
          });
          list.children('li[data-id]').remove();
          list.prepend(next);
          sync();
        });
      }
      frame.open();
    });
  });

  /* ── Dati aggiuntivi ── */
  $('.idea-extra').each(function () {
    var wrap = $(this);
    var add = wrap.parent().find('.idea-extra__add');
    function row() {
      return $('<div class="idea-extra__row"/>')
        .append($('<input type="text" name="idea_extra_label[]"/>').attr('placeholder', wrap.data('label')))
        .append($('<input type="text" name="idea_extra_value[]"/>').attr('placeholder', wrap.data('value')))
        .append($('<button type="button" class="idea-extra__remove" aria-label="Rimuovi">×</button>'));
    }
    add.on('click', function () { var r = row(); wrap.append(r); r.find('input').first().focus(); });
    wrap.on('click', '.idea-extra__remove', function () { $(this).closest('.idea-extra__row').remove(); });
  });

  /* ── Anteprima del prezzo ── */
  var price = $('#_idea_price');
  var preview = $('.idea-price-preview');
  function fmt() {
    var v = parseFloat(price.val());
    preview.text(v > 0 ? 'Sul sito: CHF ' + Math.round(v).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '’') : 'Sul sito: prezzo su richiesta');
  }
  if (price.length) { price.on('input', fmt); fmt(); }
})(jQuery);
