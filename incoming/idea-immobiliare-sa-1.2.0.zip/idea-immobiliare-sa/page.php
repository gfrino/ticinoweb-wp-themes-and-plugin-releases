<?php
/**
 * Pagine standard (azienda, servizi, mandati, contatti, privacy…).
 *
 * @package Idea_Immobiliare_SA
 */
get_header();
while (have_posts()) : the_post(); ?>
<main id="main">
	<header class="idea-pagehead">
		<div class="idea-container">
			<?php echo ticinoweb_get_breadcrumbs(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<h1><?php the_title(); ?></h1>
			<?php if (has_excerpt()) : ?><p class="idea-pagehead__lead"><?php echo esc_html(get_the_excerpt()); ?></p><?php endif; ?>
		</div>
	</header>
	<section class="idea-section">
		<div class="idea-container idea-prose">
			<?php the_content(); ?>
		</div>
	</section>
</main>
<?php endwhile;
get_footer();
