<?php
/**
 * Catalogo immobili (ricerca + griglia): vedi template-parts/immobili-archive.php
 *
 * @package Idea_Immobiliare_SA
 */
get_header();
get_template_part('template-parts/immobili-archive');
get_footer();
