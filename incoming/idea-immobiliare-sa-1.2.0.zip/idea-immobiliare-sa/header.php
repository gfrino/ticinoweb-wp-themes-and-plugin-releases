<?php
/**
 * Header: logo, menu principale, telefono.
 *
 * @package Idea_Immobiliare_SA
 */
$contact = idea_immo_contact();
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="idea-skip" href="#main"><?php esc_html_e('Vai al contenuto', 'idea-immobiliare-sa'); ?></a>

<header class="idea-header" id="top">
	<div class="idea-container idea-header__inner">
		<a class="idea-logo" href="<?php echo esc_url(home_url('/')); ?>" rel="home">
			<img src="<?php echo esc_url(idea_immo_logo_url()); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" width="136" height="62">
		</a>

		<nav class="idea-nav" id="idea-nav" aria-label="<?php esc_attr_e('Navigazione principale', 'idea-immobiliare-sa'); ?>">
			<?php if (has_nav_menu('primary')) : ?>
				<?php wp_nav_menu(array('theme_location' => 'primary', 'container' => false, 'menu_class' => 'idea-nav__list', 'depth' => 1)); ?>
			<?php else : ?>
				<?php wp_page_menu(array('menu_class' => 'idea-nav__list', 'show_home' => true)); ?>
			<?php endif; ?>
			<?php if ($contact['phone'] !== '') : ?>
				<a class="idea-nav__phone" href="<?php echo esc_attr(idea_immo_tel_href($contact['phone'])); ?>">
					<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
					<span><?php echo esc_html($contact['phone']); ?></span>
				</a>
			<?php endif; ?>
		</nav>

		<button class="idea-burger" id="idea-burger" type="button" aria-controls="idea-nav" aria-expanded="false" aria-label="<?php esc_attr_e('Apri il menu', 'idea-immobiliare-sa'); ?>">
			<span></span><span></span><span></span>
		</button>
	</div>
</header>
