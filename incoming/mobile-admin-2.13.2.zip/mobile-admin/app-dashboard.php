<?php

/**
 * Plugin Name: Mobile App Management
 * Plugin URI: https://ticinoweb.com/
 * Author: Giovanni Frino
 * Author URI: https://ticinoweb.com/
 * Version: 2.13.2
 * Description: Complete backoffice management system for the Mache Pizza mobile application. Provides admin UI to control app status, manage discounts/coupons, configure promotional slides, push notifications, and category icons. Exposes REST API endpoints for: mobile config, user registration, slides, category icons, and WooCommerce global product addons (required by Firebase Cloud Functions). Integrates with WooCommerce, Simple JWT Login, and Firebase.
 * Text-Domain: wp-app-dashboard
 * Company: ticinoWEB
 * Update URI: https://github.com/gfrino/ticinoweb-wp-themes-and-plugin-releases
 */


if (!defined('ABSPATH')) : exit();
endif; // No direct access allowed.

/**
 * Define Plugins Contants
 */
define('WPADR_PATH', trailingslashit(plugin_dir_path(__FILE__)));
define('WPADR_URL', trailingslashit(plugins_url('/', __FILE__)));
// Version of the bundled includes/tw-release-updater.php (keep in sync with its header).
define('ARD_RELEASE_UPDATER_VERSION', '1.1.0');

/*
 * Updates from the ticinoWEB releases repo (see the Update URI header). The
 * bundled loader is generic and is also installed as a mu-plugin, so updates
 * work in Network Admin and the main site's cron too. If the mu-plugin is
 * already loaded this include is a no-op.
 */
require_once WPADR_PATH . 'includes/tw-release-updater.php';
// Gestione App → Menù combinati + REST combo-menu (uses the ARD_payment_methods_* helpers below).
require_once WPADR_PATH . 'includes/combo-menu.php';

function ARD_install_release_updater() {
  if ( ! class_exists( 'TW_Release_Updater' ) || TW_Release_Updater::mu_is_current( ARD_RELEASE_UPDATER_VERSION ) ) {
    return;
  }
  if ( get_site_transient( 'ard_release_updater_failed' ) ) {
    return;
  }
  $result = TW_Release_Updater::install_mu( WPADR_PATH . 'includes/tw-release-updater.php' );
  if ( is_wp_error( $result ) ) {
    set_site_transient( 'ard_release_updater_failed', $result->get_error_message(), 12 * HOUR_IN_SECONDS );
  }
}
register_activation_hook( __FILE__, 'ARD_install_release_updater' );
add_action( 'admin_init', function () {
  if ( current_user_can( is_multisite() ? 'manage_network_plugins' : 'activate_plugins' ) ) {
    ARD_install_release_updater();
  }
}, 20 );

/**
 * Shared secret for POST <fetch_url>/config/update (must match CONFIG_SECRET or
 * JWT_SECRET of the Cloud Functions). Never hardcoded: the plugin is published
 * in a public releases repo. Set it in wp-config.php:
 *   define( 'ARD_CONFIG_API_SECRET', '...' );
 * or as a network option: wp site option update ard_config_api_secret '...'
 */
function ARD_config_api_secret() {
  if ( defined( 'ARD_CONFIG_API_SECRET' ) && ARD_CONFIG_API_SECRET ) {
    return (string) ARD_CONFIG_API_SECRET;
  }
  return (string) get_site_option( 'ard_config_api_secret', '' );
}

add_action( 'admin_notices', 'ARD_missing_api_secret_notice' );
add_action( 'network_admin_notices', 'ARD_missing_api_secret_notice' );
function ARD_missing_api_secret_notice() {
  if ( ARD_config_api_secret() !== '' || ! get_option( 'fetch_url' ) || ! current_user_can( 'manage_options' ) ) {
    return;
  }
  echo '<div class="notice notice-error"><p><strong>Mobile App Management:</strong> manca il secret per sincronizzare slide, icone e configurazione con l\'app. Definisci <code>ARD_CONFIG_API_SECRET</code> in <code>wp-config.php</code> oppure l\'opzione di rete <code>ard_config_api_secret</code>.</p></div>';
}

/**
 * Global flag to prevent recursive propagation
 */
global $ARD_WC_PROPAGATING;
$ARD_WC_PROPAGATING = false;

/**
 * Loading Necessary Scripts
 */

add_action('admin_enqueue_scripts', 'ARD_load_scripts');

function ARD_load_scripts( $hook )
{
	 $url = esc_attr( get_option('fetch_url') );
     echo "<script>var fetch_url= '$url';</script>";
  wp_enqueue_style('wp-app-dashboard', WPADR_URL . 'build/main.css', [], '1.0.0', 'all');

  // Enqueue WP Media Library on the Slides admin page so wp.media() works
  if ( isset( $_GET['page'] ) && $_GET['page'] === 'ard_slides' ) {
    wp_enqueue_media();
  }
}

// Inject schedule manager UI (hidden, will be shown when clicking "Stato dell'app")
function ARD_inject_schedule_manager_hidden() {
  $fetch_url = get_option('fetch_url');
  if (empty($fetch_url)) {
    return; // Skip if no Firebase URL configured
  }
  
  $fetch_url_escaped = esc_attr($fetch_url);
  ?>
  <style>
    #ard-schedule-manager {
      display: block;
      position: relative;
      background: #fff;
      border: 1px solid #ddd;
      border-radius: 8px;
      padding: 20px;
      margin: 20px 0 40px 0;
      max-width: 100%;
      width: 100%;
      box-shadow: 0 2px 6px rgba(0,0,0,0.08);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      z-index: auto;
    }
    #ard-schedule-manager.ard-visible { display: block; }
    #ard-schedule-manager > * { max-width: 100%; margin: 0; }
    #ard-schedule-manager h2 {
      margin: 0 0 20px 0;
      font-size: 24px;
      color: #333;
      border-bottom: 2px solid #2e7d32;
      padding-bottom: 10px;
    }
    .ard-status-display {
      background: #f5f5f5;
      padding: 15px;
      border-radius: 6px;
      margin-bottom: 20px;
    }
    .ard-status-badge {
      display: inline-block;
      padding: 8px 16px;
      border-radius: 20px;
      font-weight: 600;
      font-size: 14px;
      margin-bottom: 10px;
    }
    .ard-status-active { background: #4caf50; color: white; }
    .ard-status-inactive { background: #f44336; color: white; }
    .ard-form-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
      margin-bottom: 20px;
    }
    .ard-form-field {
      display: flex;
      flex-direction: column;
    }
    .ard-form-field label {
      font-weight: 600;
      margin-bottom: 8px;
      color: #555;
      font-size: 13px;
    }
    .ard-form-field input,
    .ard-form-field textarea {
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 4px;
      font-size: 14px;
      font-family: inherit;
    }
    .ard-form-field textarea {
      min-height: 80px;
      resize: vertical;
    }
    .ard-button {
      padding: 12px 24px;
      border: none;
      border-radius: 4px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s;
    }
    .ard-button-primary {
      background: #2e7d32;
      color: white;
    }
    .ard-button-primary:hover {
      background: #1b5e20;
    }
    .ard-button-danger {
      background: #f44336;
      color: white;
    }
    .ard-button-danger:hover {
      background: #d32f2f;
    }
    .ard-message {
      padding: 12px;
      border-radius: 4px;
      margin-top: 15px;
      font-size: 14px;
    }
    .ard-message-success {
      background: #4caf50;
      color: white;
    }
    .ard-message-error {
      background: #f44336;
      color: white;
    }
    .ard-schedule-info {
      background: #fff3cd;
      border-left: 4px solid #ffc107;
      padding: 12px;
      margin-bottom: 15px;
      font-size: 14px;
    }
  </style>

  <div class="wrap"><div id="ard-schedule-manager">
    <h2>📅 Gestione Programmazione Chiusura App</h2>
    
    <div class="ard-status-display" id="ard-current-status">
      <div>Caricamento stato attuale...</div>
    </div>

    <div class="ard-schedule-info">
      <strong>ℹ️ Come funziona:</strong><br>
      Programma la chiusura temporanea dell'app mobile. Durante il periodo specificato, l'app mostrerà il messaggio personalizzato agli utenti. L'app si riattiverà automaticamente alla fine del periodo.
    </div>

    <div class="ard-form-grid">
      <div class="ard-form-field">
        <label>📅 Data/Ora Inizio Chiusura</label>
        <input type="datetime-local" id="ard-start-datetime" />
      </div>
      <div class="ard-form-field">
        <label>📅 Data/Ora Fine Chiusura</label>
        <input type="datetime-local" id="ard-end-datetime" />
      </div>
    </div>

    <div class="ard-form-grid">
      <div class="ard-form-field">
        <label>📝 Titolo Messaggio</label>
        <input type="text" id="ard-title" placeholder="Es: App Chiusa per Festività" maxlength="100" />
      </div>
      <div class="ard-form-field">
        <label>📝 Descrizione Messaggio</label>
        <textarea id="ard-description" placeholder="Es: Saremo di nuovo online il 1° gennaio. Buone feste!"></textarea>
      </div>
    </div>

    <div style="display: flex; gap: 10px; align-items: center;">
      <button class="ard-button ard-button-primary" onclick="ARD_saveSchedule()">
        💾 Salva Programmazione
      </button>
      <button class="ard-button ard-button-danger" onclick="ARD_clearSchedule()">
        🗑️ Rimuovi Programmazione
      </button>
    </div>

    <div id="ard-message"></div>
  </div></div>

  <script>
  (function() {
    const API_URL = '<?php echo $fetch_url_escaped; ?>';
    let currentStatus = null;

    // Load current status on page load
    async function loadCurrentStatus() {
      try {
        const response = await fetch(API_URL + '/appStatus');
        if (!response.ok) throw new Error('Errore caricamento stato');
        
        currentStatus = await response.json();
        displayCurrentStatus();
        populateForm();
      } catch (error) {
        document.getElementById('ard-current-status').innerHTML = 
          '<span style="color:#f44336;">❌ Errore caricamento: ' + error.message + '</span>';
      }
    }

    function displayCurrentStatus() {
      const now = Date.now();
      const inactivity = currentStatus.inactivity || {};
      const startAt = inactivity.startAt || 0;
      const endAt = inactivity.endAt || 0;
      
      let statusHtml = '';
      let isInScheduledPeriod = now >= startAt && now <= endAt;
      let hasFutureSchedule = startAt > now;
      
      if (isInScheduledPeriod) {
        const endDate = new Date(endAt);
        const endStr = formatDateTime(endDate);
        statusHtml = `
          <span class="ard-status-badge ard-status-inactive">🔴 App Attualmente Inattiva</span>
          <div style="margin-top:10px;">
            <strong>Programmazione Attiva:</strong><br>
            Riapertura prevista: <strong>${endStr}</strong>
          </div>
          <div style="margin-top:8px;">
            <strong>Messaggio:</strong> ${currentStatus.title || 'N/A'}<br>
            <strong>Descrizione:</strong> ${currentStatus.description || 'N/A'}
          </div>
        `;
      } else if (hasFutureSchedule) {
        const startDate = new Date(startAt);
        const endDate = new Date(endAt);
        const startStr = formatDateTime(startDate);
        const endStr = formatDateTime(endDate);
        statusHtml = `
          <span class="ard-status-badge ard-status-active">🟢 App Attualmente Attiva</span>
          <div style="margin-top:10px;">
            <strong>⏰ Chiusura Programmata:</strong><br>
            Dal <strong>${startStr}</strong><br>
            Al <strong>${endStr}</strong>
          </div>
          <div style="margin-top:8px;">
            <strong>Messaggio programmato:</strong> ${currentStatus.title || 'N/A'}<br>
            <strong>Descrizione:</strong> ${currentStatus.description || 'N/A'}
          </div>
        `;
      } else {
        statusHtml = `
          <span class="ard-status-badge ard-status-active">🟢 App Attualmente Attiva</span>
          <div style="margin-top:10px;">Nessuna chiusura programmata</div>
        `;
      }
      
      document.getElementById('ard-current-status').innerHTML = statusHtml;
    }

    function populateForm() {
      const inactivity = currentStatus.inactivity || {};
      
      if (inactivity.startAt) {
        document.getElementById('ard-start-datetime').value = 
          new Date(inactivity.startAt).toISOString().slice(0, 16);
      }
      if (inactivity.endAt) {
        document.getElementById('ard-end-datetime').value = 
          new Date(inactivity.endAt).toISOString().slice(0, 16);
      }
      if (currentStatus.title) {
        document.getElementById('ard-title').value = currentStatus.title;
      }
      if (currentStatus.description) {
        document.getElementById('ard-description').value = currentStatus.description;
      }
    }

    function formatDateTime(date) {
      return date.toLocaleString('it-IT', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    }

    function showMessage(text, isError = false) {
      const msgDiv = document.getElementById('ard-message');
      msgDiv.className = 'ard-message ' + (isError ? 'ard-message-error' : 'ard-message-success');
      msgDiv.textContent = text;
      setTimeout(() => msgDiv.textContent = '', 5000);
    }

    window.ARD_saveSchedule = async function() {
      const startVal = document.getElementById('ard-start-datetime').value;
      const endVal = document.getElementById('ard-end-datetime').value;
      const title = document.getElementById('ard-title').value.trim();
      const description = document.getElementById('ard-description').value.trim();

      if (!startVal || !endVal) {
        showMessage('⚠️ Inserisci data/ora inizio e fine', true);
        return;
      }

      const startDate = new Date(startVal);
      const endDate = new Date(endVal);

      if (endDate <= startDate) {
        showMessage('⚠️ La data di fine deve essere successiva alla data di inizio', true);
        return;
      }

      if (!title) {
        showMessage('⚠️ Inserisci un titolo per il messaggio', true);
        return;
      }

      try {
        const payload = {
          isOnline: false,
          title: title,
          description: description || '',
          inactivity: {
            startAt: startDate.getTime(),
            endAt: endDate.getTime()
          }
        };

        const response = await fetch(API_URL + '/appStatus', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });

        if (!response.ok) throw new Error('Errore salvataggio');

        showMessage('✅ Programmazione salvata con successo!');
        setTimeout(() => loadCurrentStatus(), 1000);
      } catch (error) {
        showMessage('❌ Errore: ' + error.message, true);
      }
    };

    window.ARD_clearSchedule = async function() {
      if (!confirm('Sei sicuro di voler rimuovere la programmazione?')) return;

      try {
        const payload = {
          isOnline: true,
          title: '',
          description: '',
          inactivity: {
            startAt: 0,
            endAt: 0
          }
        };

        const response = await fetch(API_URL + '/appStatus', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });

        if (!response.ok) throw new Error('Errore rimozione');

        showMessage('✅ Programmazione rimossa!');
        document.getElementById('ard-start-datetime').value = '';
        document.getElementById('ard-end-datetime').value = '';
        document.getElementById('ard-title').value = '';
        document.getElementById('ard-description').value = '';
        setTimeout(() => loadCurrentStatus(), 1000);
      } catch (error) {
        showMessage('❌ Errore: ' + error.message, true);
      }
    };

    // Initialize - show panel immediately since we're on the right page
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => {
        const panel = document.getElementById('ard-schedule-manager');
        if (panel) {
          panel.classList.add('ard-visible');
          loadCurrentStatus();
        }
      });
    } else {
      const panel = document.getElementById('ard-schedule-manager');
      if (panel) {
        panel.classList.add('ard-visible');
        loadCurrentStatus();
      }
    }
  })();
  </script>
  <?php
}

function ADR_showContent()
{
  $mainHTML = file_get_contents(WPADR_URL . 'build/index.html');

  echo $mainHTML;
}

add_action('admin_menu', 'ADR_createMenuOption');

function ADR_createMenuOption()
{
  // Main icon for all menu items
  $icon_url = plugin_dir_url(__FILE__) . 'icon.png';
  
  // Parent: Gestione App (with icon)
  add_menu_page(
    'Gestione App', // Page Title
    'Gestione App', // Menu Title
    'manage_options', // Capability
    'ard_stato_app', // slug
    'ARD_showContent_stato_app',
    $icon_url // icon
  );
  
  // Child: Notifications
  add_submenu_page(
    'ard_stato_app', // Parent slug
    'Notifiche', // Page Title
    'Notifiche', // Menu Title
    'manage_options', // Capability
    'ard_notifications', // slug
    'ARD_showContent_notifications'
  );
  
  // Child: Impostazioni
  add_submenu_page(
    'ard_stato_app', // Parent slug
    'Impostazioni', // Page Title
    'Impostazioni', // Menu Title
    'manage_options', // Capability
    'app_administration_backoffice_settings', // slug
    'ADR_showContent_settings'
  );

  // Child: Slides
  add_submenu_page(
    'ard_stato_app', // Parent slug
    'Slides Home', // Page Title
    'Slides', // Menu Title
    'manage_options', // Capability
    'ard_slides', // slug
    'ARD_showContent_slides'
  );

  // Child: Icone Categorie
  add_submenu_page(
    'ard_stato_app', // Parent slug
    'Icone Categorie', // Page Title
    'Icone Categorie', // Menu Title
    'manage_options', // Capability
    'ard_category_icons', // slug
    'ARD_showContent_category_icons'
  );
  
  // WooCommerce Site Status page (separate)
  add_menu_page(
    'Gestione Sito WooCommerce', // Page Title
    'Gestione Woo', // Menu Title
    'manage_options', // Capability
    'wc_site_status', // slug
    'ADR_showContent_wc_status',
    $icon_url // icon
  );
  
  // Register settings
  add_action( 'admin_init', 'register_Backoffice_settings' );
  add_action('admin_init', 'register_wc_status_settings');
  add_action( 'admin_init', 'ARD_register_slides_settings' );
  add_action( 'admin_init', 'ARD_register_category_icons_settings' );
}

function ARD_showContent_stato_app()
{
  ARD_inject_schedule_manager_hidden();
}

function ARD_showContent_notifications()
{
  ARD_inject_notifications_manager_hidden();
}

function register_Backoffice_settings() {
	//register our settings
	register_setting( 'Backoffice-settings-group', 'fetch_url' );
	register_setting( 'Backoffice-settings-group', 'stripe_publishable_key' );
	register_setting( 'Backoffice-settings-group', 'app_site_url' );
	register_setting( 'Backoffice-settings-group', 'app_wc_consumer_key' );
	register_setting( 'Backoffice-settings-group', 'app_wc_consumer_secret' );
}

/**
 * Sync app configuration to Firestore via Cloud Functions when settings are saved.
 * This allows Cloud Functions to read the site URL and WooCommerce keys
 * dynamically without redeploying.
 */
function ARD_sync_config_to_firestore() {
  $fetch_url        = get_option( 'fetch_url' );
  $app_site_url     = get_option( 'app_site_url' );
  $wc_consumer_key  = get_option( 'app_wc_consumer_key' );
  $wc_consumer_secret = get_option( 'app_wc_consumer_secret' );

  if ( empty( $fetch_url ) ) {
    return; // No Cloud Functions URL configured
  }

  if ( ARD_config_api_secret() === '' ) {
    error_log( '[MobileAdmin] Config sync skipped: ARD_CONFIG_API_SECRET not configured' );
    return;
  }

  $config_endpoint = rtrim( $fetch_url, '/' ) . '/config/update';

  $payload = array(
    'apiSecret'        => ARD_config_api_secret(), // Must match CONFIG_SECRET / JWT_SECRET of the Cloud Functions
    'siteUrl'          => $app_site_url ?: site_url(),
    'wooConsumerKey'   => $wc_consumer_key,
    'wooConsumerSecret' => $wc_consumer_secret,
  );

  $response = wp_remote_post( $config_endpoint, array(
    'body'    => wp_json_encode( $payload ),
    'headers' => array( 'Content-Type' => 'application/json' ),
    'timeout' => 15,
  ) );

  if ( is_wp_error( $response ) ) {
    error_log( '[MobileAdmin] Config sync to Firestore failed: ' . $response->get_error_message() );
  } else {
    $code = wp_remote_retrieve_response_code( $response );
    if ( $code !== 200 ) {
      error_log( '[MobileAdmin] Config sync returned HTTP ' . $code . ': ' . wp_remote_retrieve_body( $response ) );
    }
  }
}
add_action( 'update_option_app_site_url', 'ARD_sync_config_to_firestore', 10, 0 );
add_action( 'update_option_app_wc_consumer_key', 'ARD_sync_config_to_firestore', 10, 0 );
add_action( 'update_option_app_wc_consumer_secret', 'ARD_sync_config_to_firestore', 10, 0 );

// WooCommerce Site Status settings
function register_wc_status_settings() {
  register_setting( 'wc-status-settings-group', 'wc_closed_message', [ 'default' => 'Ordini temporaneamente sospesi. Torna più tardi.' ] );
  // Scheduling options (date and time range)
  register_setting( 'wc-status-settings-group', 'wc_schedule_enabled', [ 'default' => 0 ] );
  register_setting( 'wc-status-settings-group', 'wc_closed_start_date', [ 'default' => '' ] ); // YYYY-MM-DD
  register_setting( 'wc-status-settings-group', 'wc_closed_end_date', [ 'default' => '' ] ); // YYYY-MM-DD
  register_setting( 'wc-status-settings-group', 'wc_closed_start_time', [ 'default' => '' ] ); // HH:MM
  register_setting( 'wc-status-settings-group', 'wc_closed_end_time', [ 'default' => '' ] ); // HH:MM
  // Multisite linked sites (array of blog IDs)
  register_setting( 'wc-status-settings-group', 'wc_schedule_linked_sites', [ 'default' => [] ] );
}

function ADR_showContent_settings() {
?>
<div class="wrap">
<h1>Mobile App Settings Page</h1>

<form method="post" action="options.php">
    <?php settings_fields( 'Backoffice-settings-group' ); ?>
    <?php do_settings_sections( 'Backoffice-settings-group' ); ?>
    <table class="form-table">
        <tr valign="top">
        <th scope="row">Firebase Cloud Functions URL</th>
        <td><input type="text" name="fetch_url" value="<?php echo esc_attr( get_option('fetch_url') ); ?>" class="regular-text" placeholder="https://europe-west1-project.cloudfunctions.net" /></td>
        </tr>
        <tr valign="top">
        <th scope="row">WordPress Site URL (per l'app)</th>
        <td>
            <input type="text" name="app_site_url" value="<?php echo esc_attr( get_option('app_site_url', site_url()) ); ?>" class="regular-text" placeholder="https://machepizza.ch" />
            <p class="description">L'URL del sito WordPress che le Cloud Functions useranno per le API WooCommerce. Viene sincronizzato automaticamente su Firestore.</p>
        </td>
        </tr>
        <tr valign="top">
        <th scope="row">WooCommerce Consumer Key</th>
        <td>
            <input type="text" name="app_wc_consumer_key" value="<?php echo esc_attr( get_option('app_wc_consumer_key') ); ?>" class="regular-text" placeholder="ck_..." />
            <p class="description">Consumer Key dalle impostazioni API di WooCommerce. Sincronizzato su Firestore.</p>
        </td>
        </tr>
        <tr valign="top">
        <th scope="row">WooCommerce Consumer Secret</th>
        <td>
            <input type="password" name="app_wc_consumer_secret" value="<?php echo esc_attr( get_option('app_wc_consumer_secret') ); ?>" class="regular-text" placeholder="cs_..." />
            <p class="description">Consumer Secret dalle impostazioni API di WooCommerce. Sincronizzato su Firestore.</p>
        </td>
        </tr>
    </table>
    
    <?php submit_button(); ?>

</form>

<hr style="margin: 40px 0 20px 0; border: 0; border-top: 1px solid #ccc;" />

<div class="card" style="max-width: 800px; margin-top: 20px; border-left: 4px solid #2e7d32; border-radius: 4px; padding: 20px; background: #fff; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
    <h2 style="margin-top: 0; color: #2e7d32; font-size: 1.3em;">ℹ️ CAP di consegna, minimi d'ordine e selettore CAP</h2>
    <p>Fonte di verità: le <strong>Zone di Spedizione WooCommerce di ciascun sottosito</strong>. Ecco come funziona il sistema:</p>
    <ol style="padding-left: 20px; line-height: 1.5; margin-bottom: 0;">
        <li><strong>CAP di consegna (per sede):</strong>
            <br />Su ogni sottosito, in <code>WooCommerce &gt; Impostazioni &gt; Spedizione &gt; Zone di spedizione</code>, i CAP delle zone con un metodo <strong>Tariffa Unica</strong> o <strong>Spedizione Gratuita</strong> attivo definiscono dove quella sede consegna.
            <br />Il plugin legge queste zone da tutti i sottositi (endpoint <code>/wp-json/wpadr/v1/delivery-caps</code>, cache 10 minuti) e le espone allo shortcode <code>[wpadr_cap_selector]</code>: inseriscilo nella pagina di smistamento del sito principale al posto della selezione CAP manuale. Un CAP va gestito in un punto solo: la zona di spedizione del sottosito.
        </li>
        <li style="margin-top: 10px;"><strong>Minimo d'ordine per la consegna (per sede, non per CAP):</strong>
            <br />È il valore configurato nel plugin WooDelivery del sottosito (restrizione carrello, es. <code>24.90</code> a Biasca) e viene applicato dalle Cloud Functions su tutti i metodi di pagamento dell'app. Un unico minimo per sede.
        </li>
        <li style="margin-top: 10px;"><strong>Minimo per Tariffa Unica (solo carrello del sito web):</strong>
            <br />I campi <em>Abilita importo minimo / Soglia importo minimo</em> aggiunti da questo plugin al metodo Tariffa Unica agiscono sul checkout <strong>del sito web</strong> (nascondono la tariffa sotto soglia). <strong>Non</strong> sono letti dall'app mobile.
        </li>
    </ol>
</div>
</div>
<?php }

// WooCommerce Site Status admin page
function ADR_showContent_wc_status() {
  $message = esc_attr( get_option('wc_closed_message', 'Ordini temporaneamente sospesi. Torna più tardi.') );
  $schedule_enabled = (int) get_option('wc_schedule_enabled', 0);
  $start_date = esc_attr( get_option('wc_closed_start_date', '') );
  $end_date   = esc_attr( get_option('wc_closed_end_date', '') );
  $orders_open = ARD_wc_orders_open();
  $linked_sites = (array) get_option('wc_schedule_linked_sites', [] );
  if ( empty($linked_sites) ) { $linked_sites = [ get_current_blog_id() ]; }
  $sites_list = ARD_wc_get_sites_list();
?>
<div class="wrap">
  <h1>Gestione Woo</h1>
  <p>Stato ordini WooCommerce determinato dalla pianificazione. Quando disattivato, i clienti non potranno aggiungere prodotti al carrello né completare il checkout e verrà mostrato un banner rosso in alto sul sito.</p>

  <style>
    .ard-switch-row { display:flex; align-items:center; gap:16px; }
    .ard-switch {
      appearance: none; border: none; cursor: pointer; padding: 10px 16px; border-radius: 24px;
      font-size: 16px; font-weight: 600; color: #fff; transition: all .2s ease-in-out;
    }
    .ard-switch[data-active="1"] { background: #2e7d32; }
    .ard-switch[data-active="0"] { background: #b00020; }
    .ard-switch:focus { outline: 2px solid #1976d2; }
  </style>

  <form method="post" action="options.php">
    <?php settings_fields( 'wc-status-settings-group' ); ?>
    <?php do_settings_sections( 'wc-status-settings-group' ); ?>
    <table class="form-table">
      <tr valign="top">
        <th scope="row">Ordini WooCommerce</th>
        <td>
          <div class="ard-switch-row">
            <span class="ard-switch" style="cursor: default;" data-active="<?php echo $orders_open ? '1' : '0'; ?>">
              <?php echo $orders_open ? 'Ordini ATTIVI' : 'Ordini CHIUSI'; ?>
            </span>
          </div>
          <p class="description">Lo stato è calcolato automaticamente in base alla pianificazione sotto. Il pulsante non è cliccabile.</p>
        </td>
      </tr>
      <tr valign="top">
        <th scope="row">Messaggio ai clienti</th>
        <td>
          <textarea name="wc_closed_message" rows="3" cols="60"><?php echo $message; ?></textarea>
          <p class="description">Questo testo viene mostrato globalmente: nel banner rosso in alto e come avviso nel carrello/checkout quando gli ordini sono disattivati.</p>
        </td>
      </tr>
      <tr valign="top">
        <th scope="row">Pianificazione</th>
        <td>
          <label for="wc_schedule_enabled">
            <input type="checkbox" id="wc_schedule_enabled" name="wc_schedule_enabled" value="1" <?php checked( 1, $schedule_enabled ); ?> />
            Abilita pianificazione (chiusura automatica per intervallo di date)
          </label>
          <p class="description">Quando attiva, gli ordini verranno chiusi automaticamente tra le date e ore indicate.</p>
          <hr />
          <strong>Intervallo di chiusura</strong><br />
          <label>Dal: <input type="date" name="wc_closed_start_date" value="<?php echo $start_date; ?>" /></label>
          &nbsp;
          <label>Ore: <input type="time" name="wc_closed_start_time" value="<?php echo esc_attr( get_option('wc_closed_start_time', '') ); ?>" placeholder="00:00" /></label>
          <br /><br />
          <label>Al: <input type="date" name="wc_closed_end_date" value="<?php echo $end_date; ?>" /></label>
          &nbsp;
          <label>Ore: <input type="time" name="wc_closed_end_time" value="<?php echo esc_attr( get_option('wc_closed_end_time', '') ); ?>" placeholder="23:59" /></label>
          <p class="description">Formato data: YYYY-MM-DD, ora: HH:MM (24h). Se non imposti l'ora, viene usato l'inizio (00:00) o fine (23:59) della giornata.</p>
          <?php if ( is_multisite() ) : ?>
          <hr />
          <strong>Siti collegati (Multisite)</strong>
          <p class="description">Seleziona i siti che devono seguire queste stesse impostazioni di chiusura.</p>
          <table id="wc-linked-sites" class="widefat" style="max-width:720px;">
            <thead><tr><th style="width:80%; padding-left: 16px;">Sito</th><th style="width:20%;">Azioni</th></tr></thead>
            <tbody>
            <?php foreach ( $linked_sites as $idx => $blog_id ) : ?>
              <tr>
                <td>
                  <select name="wc_schedule_linked_sites[]" <?php echo ($blog_id === get_current_blog_id()) ? 'disabled' : ''; ?>>
                    <?php foreach ( $sites_list as $sid => $label ) : ?>
                      <option value="<?php echo (int)$sid; ?>" <?php selected( (int)$sid, (int)$blog_id ); ?>><?php echo esc_html( $label ); ?></option>
                    <?php endforeach; ?>
                  </select>
                  <?php if ( $blog_id === get_current_blog_id() ) : ?>
                    <input type="hidden" name="wc_schedule_linked_sites[]" value="<?php echo (int) get_current_blog_id(); ?>" />
                    <small>(Sito corrente)</small>
                  <?php endif; ?>
                </td>
                <td>
                  <?php if ( $blog_id !== get_current_blog_id() ) : ?>
                  <button type="button" class="button link-delete-row">Rimuovi</button>
                  <?php else: ?>
                  <span class="button disabled">—</span>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
          <?php if ( is_super_admin() ) : ?>
            <p><button type="button" class="button button-secondary" id="wc-add-linked-site">Aggiungi sito</button></p>
          <?php endif; ?>
          <p class="description">Nota: per mostrare il banner e bloccare gli ordini anche nei siti collegati, il plugin deve essere attivo su quei siti (oppure attivato a livello di network).</p>
          <script>
          (function(){
            var sites = <?php echo wp_json_encode( $sites_list ); ?>;
            var currentId = <?php echo (int) get_current_blog_id(); ?>;
            var table = document.getElementById('wc-linked-sites');
            var addBtn = document.getElementById('wc-add-linked-site');
            function makeRow(selected){
              var tr = document.createElement('tr');
              var td1 = document.createElement('td');
              var td2 = document.createElement('td');
              var sel = document.createElement('select');
              sel.name = 'wc_schedule_linked_sites[]';
              for (var sid in sites){ if(!sites.hasOwnProperty(sid)) continue; var opt = document.createElement('option'); opt.value = sid; opt.textContent = sites[sid]; sel.appendChild(opt); }
              if (selected) sel.value = String(selected);
              td1.appendChild(sel);
              var rm = document.createElement('button'); rm.type='button'; rm.className='button link-delete-row'; rm.textContent='Rimuovi';
              rm.addEventListener('click', function(){ tr.parentNode.removeChild(tr); });
              td2.appendChild(rm);
              tr.appendChild(td1); tr.appendChild(td2);
              return tr;
            }
            addBtn && addBtn.addEventListener('click', function(){
              var tbody = table.querySelector('tbody');
              tbody.appendChild( makeRow(null) );
            });
            table.addEventListener('click', function(e){
              if (e.target && e.target.classList.contains('link-delete-row')){
                var tr = e.target.closest('tr');
                if (tr){ tr.parentNode.removeChild(tr); }
              }
            });
          })();
          </script>
          <?php endif; ?>
        </td>
      </tr>
    </table>

    <?php submit_button(); ?>
  </form>
</div>
<!-- Stato ordini basato su pianificazione; nessuna interazione JS necessaria -->
<?php }

// Block WooCommerce ordering when disabled
function ARD_wc_is_purchasable( $purchasable, $product ) {
  // Don't block if it's a backend/admin request (allows printer and other backend processes)
  if ( is_admin() || wp_doing_cron() || ( defined('REST_REQUEST') && REST_REQUEST ) ) {
    return $purchasable;
  }
  
  if ( ! ARD_wc_orders_open() ) {
    return false;
  }
  return $purchasable;
}
add_filter( 'woocommerce_is_purchasable', 'ARD_wc_is_purchasable', 10, 2 );

function ARD_wc_add_to_cart_validation( $passed, $product_id, $quantity ) {
  // Don't block if it's a backend/admin request (allows printer and other backend processes)
  if ( is_admin() || wp_doing_cron() || ( defined('REST_REQUEST') && REST_REQUEST ) ) {
    return $passed;
  }
  
  if ( ! ARD_wc_orders_open() ) {
    $msg = get_option('wc_closed_message', 'Ordini temporaneamente sospesi. Torna più tardi.');
    wc_add_notice( $msg, 'error' );
    return false;
  }
  return $passed;
}
add_filter( 'woocommerce_add_to_cart_validation', 'ARD_wc_add_to_cart_validation', 10, 3 );

function ARD_wc_before_checkout_form() {
  if ( ! ARD_wc_orders_open() ) {
    $msg = get_option('wc_closed_message', 'Ordini temporaneamente sospesi. Torna più tardi.');
    wc_print_notice( $msg, 'error' );
  }
}
add_action( 'woocommerce_before_checkout_form', 'ARD_wc_before_checkout_form', 5 );

function ARD_wc_checkout_process_block() {
  // Don't block if it's a backend/admin request (allows printer and other backend processes)
  if ( is_admin() || wp_doing_cron() || ( defined('REST_REQUEST') && REST_REQUEST ) ) {
    return;
  }
  
  if ( ! ARD_wc_orders_open() ) {
    $msg = get_option('wc_closed_message', 'Ordini temporaneamente sospesi. Torna più tardi.');
    wc_add_notice( $msg, 'error' );
  }
}
add_action( 'woocommerce_checkout_process', 'ARD_wc_checkout_process_block' );

// Frontend global banner output (when orders disabled)
function ARD_wc_banner_head() {
  // Don't show banner on admin pages, AJAX, or REST API requests
  if ( is_admin() || wp_doing_ajax() || ( defined('REST_REQUEST') && REST_REQUEST ) ) { return; }
  if ( ARD_wc_orders_open() ) { return; }
  ?>
  <style id="ard-wc-site-banner-css">
    #ard-wc-site-banner { position: fixed; top: 0; left: 0; right: 0; background: #b00020; color: #fff; padding: 12px 16px; text-align: center; z-index: 99999; box-shadow: 0 2px 6px rgba(0,0,0,.15); font-size: 16px; line-height: 1.4; }
    #ard-wc-site-banner .ard-wc-site-banner__text { display: inline-block; margin: 0; }
    html { scroll-padding-top: 52px; }
    body { padding-top: 52px; }
    @media (max-width:768px){ html{ scroll-padding-top: 64px; } body{ padding-top: 64px; } }
  </style>
  <?php
}
add_action( 'wp_head', 'ARD_wc_banner_head', 20 );

function ARD_wc_render_site_banner() {
  // Don't show banner on admin pages, AJAX, or REST API requests
  if ( is_admin() || wp_doing_ajax() || ( defined('REST_REQUEST') && REST_REQUEST ) ) { return; }
  if ( ARD_wc_orders_open() ) { return; }
  $text = get_option('wc_closed_message', 'Ordini temporaneamente sospesi. Torna più tardi.' );
  ?>
  <div id="ard-wc-site-banner" role="status" aria-live="polite">
    <span class="ard-wc-site-banner__text"><?php echo esc_html( $text ); ?></span>
  </div>
  <?php
}
add_action( 'wp_footer', 'ARD_wc_render_site_banner', 5 );
// Try to render at the very top when theme supports wp_body_open
add_action( 'wp_body_open', 'ARD_wc_render_site_banner', 1 );

// Ensure banner appears even if theme omits wp_footer/wp_body_open
function ARD_wc_banner_script_inject() {
  // Don't inject script on admin pages, AJAX, or REST API requests
  if ( is_admin() || wp_doing_ajax() || ( defined('REST_REQUEST') && REST_REQUEST ) ) { return; }
  if ( ARD_wc_orders_open() ) { return; }
  $text = get_option('wc_closed_message', 'Ordini temporaneamente sospesi. Torna più tardi.' );
  ?>
  <script id="ard-wc-site-banner-js">
    (function(){
      var text = <?php echo json_encode( $text ); ?>;
      function ensureBanner(){
        if (!document.getElementById('ard-wc-site-banner')){
          var div = document.createElement('div');
          div.id = 'ard-wc-site-banner';
          div.setAttribute('role','status');
          div.setAttribute('aria-live','polite');
          var span = document.createElement('span');
          span.className = 'ard-wc-site-banner__text';
          span.textContent = text;
          div.appendChild(span);
          var body = document.body;
          if (body.firstChild){ body.insertBefore(div, body.firstChild); }
          else { body.appendChild(div); }
        }
      }
      if (document.readyState === 'loading'){
        document.addEventListener('DOMContentLoaded', ensureBanner);
      } else {
        ensureBanner();
      }
    })();
  </script>
  <?php
}
add_action( 'wp_head', 'ARD_wc_banner_script_inject', 21 );

/**
 * Auto-reset expired schedule dates.
 * If end_date has passed, reset both start and end dates to allow orders to reopen.
 * This function runs via WP-Cron hourly.
 */
function ARD_wc_auto_reset_expired_schedule() {
  // Only reset if scheduling is actually enabled
  $schedule_enabled = (int) get_option('wc_schedule_enabled', 0) === 1;
  if ( ! $schedule_enabled ) { return; }

  $now = current_time( 'timestamp' );
  $current_datetime = date( 'Y-m-d H:i', $now );
  
  $start_date = (string) get_option( 'wc_closed_start_date', '' );
  $end_date   = (string) get_option( 'wc_closed_end_date', '' );
  $start_time = (string) get_option( 'wc_closed_start_time', '' );
  $end_time   = (string) get_option( 'wc_closed_end_time', '' );
  
  // If no end date and start is in the past, this is a permanent closure - don't reset
  if ( $end_date === '' && $start_date !== '' ) {
    return; // Keep permanent closure as-is
  }
  
  // Build end datetime (default to 23:59 if no time specified)
  $end_datetime = $end_date !== '' ? $end_date . ' ' . ( $end_time !== '' ? $end_time : '23:59' ) : '';
  
  // If end_datetime is set and has passed, reset all schedule fields
  if ( $end_datetime !== '' && $current_datetime > $end_datetime ) {
    update_option( 'wc_closed_start_date', '' );
    update_option( 'wc_closed_end_date', '' );
    update_option( 'wc_closed_start_time', '' );
    update_option( 'wc_closed_end_time', '' );
    
    // This update_option call will trigger propagation to linked sites automatically
    // via the update_option hooks
  }
}

/**
 * Register WP-Cron hook for auto-reset (runs hourly)
 */
function ARD_wc_schedule_auto_reset() {
  if ( ! wp_next_scheduled( 'ard_wc_auto_reset_hook' ) ) {
    wp_schedule_event( time(), 'hourly', 'ard_wc_auto_reset_hook' );
  }
}
add_action( 'wp_loaded', 'ARD_wc_schedule_auto_reset' );
add_action( 'ard_wc_auto_reset_hook', 'ARD_wc_auto_reset_expired_schedule' );

/**
 * Cleanup: unschedule when plugin deactivates
 */
function ARD_wc_unschedule_auto_reset() {
  wp_clear_scheduled_hook( 'ard_wc_auto_reset_hook' );
}
register_deactivation_hook( __FILE__, 'ARD_wc_unschedule_auto_reset' );

// Helper: determine if orders are open considering schedule
function ARD_wc_orders_open() {
  // Scheduling-only control: if scheduling disabled, orders are open
  $schedule_enabled = (int) get_option('wc_schedule_enabled', 0) === 1;
  if ( ! $schedule_enabled ) { return true; }

  $now = current_time( 'timestamp' ); // WP local time
  $current_datetime = date( 'Y-m-d H:i', $now ); // YYYY-MM-DD HH:MM

  $start_date = (string) get_option( 'wc_closed_start_date', '' );
  $end_date   = (string) get_option( 'wc_closed_end_date', '' );
  $start_time = (string) get_option( 'wc_closed_start_time', '' );
  $end_time   = (string) get_option( 'wc_closed_end_time', '' );

  // If both dates empty, scheduling has no effect
  if ( $start_date === '' && $end_date === '' ) { return true; }

  // Build full datetime strings (default times: start=00:00, end=23:59)
  $start_datetime = $start_date !== '' ? $start_date . ' ' . ( $start_time !== '' ? $start_time : '00:00' ) : '';
  $end_datetime   = $end_date !== '' ? $end_date . ' ' . ( $end_time !== '' ? $end_time : '23:59' ) : '';

  // Compare YYYY-MM-DD HH:MM strings lexicographically (works because consistent format)
  if ( $start_datetime !== '' && $end_datetime !== '' ) {
    if ( $current_datetime >= $start_datetime && $current_datetime <= $end_datetime ) { return false; }
  } elseif ( $start_datetime !== '' ) {
    if ( $current_datetime >= $start_datetime ) { return false; }
  } elseif ( $end_datetime !== '' ) {
    if ( $current_datetime <= $end_datetime ) { return false; }
  }

  return true;
}

// Force no-caching when orders are closed
function ARD_wc_nocache_when_closed() {
  // Don't modify headers for CloudPRNT printer requests
  if ( isset($_SERVER['REQUEST_URI']) && strpos($_SERVER['REQUEST_URI'], 'cloudprnt') !== false ) {
    return;
  }
  // Don't modify headers for backend requests
  if ( is_admin() || wp_doing_cron() || ( defined('REST_REQUEST') && REST_REQUEST ) ) {
    return;
  }
  
  if ( ARD_wc_orders_open() ) { return; }
  nocache_headers();
  // Extra safety for some caches
  header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0' );
  header( 'Pragma: no-cache' );
  header( 'Expires: 0' );
}
add_action( 'send_headers', 'ARD_wc_nocache_when_closed' );

function ARD_wc_meta_nocache() {
  // Don't output meta tags for CloudPRNT or backend requests
  if ( is_admin() || wp_doing_ajax() || ( defined('REST_REQUEST') && REST_REQUEST ) ) {
    return;
  }
  if ( isset($_SERVER['REQUEST_URI']) && strpos($_SERVER['REQUEST_URI'], 'cloudprnt') !== false ) {
    return;
  }
  
  if ( ARD_wc_orders_open() ) { return; }
  echo "\n<meta http-equiv=\"Cache-Control\" content=\"no-cache, no-store, must-revalidate\">\n";
  echo "<meta http-equiv=\"Pragma\" content=\"no-cache\">\n";
  echo "<meta http-equiv=\"Expires\" content=\"0\">\n";
}
add_action( 'wp_head', 'ARD_wc_meta_nocache', 1 );

// ===== Multisite propagation =====
global $ARD_WC_PROPAGATING; $ARD_WC_PROPAGATING = false;

function ARD_wc_get_sites_list() {
  $list = [];
  if ( ! is_multisite() ) { return $list; }
  $sites = get_sites([ 'number' => 0 ]);
  foreach ( $sites as $site ) {
    $id = (int) $site->blog_id;
    $label = $site->domain . $site->path;
    $list[$id] = $label;
  }
  return $list;
}

/**
 * Propagate all schedule settings to linked sites.
 * This creates a group where all linked sites have the same schedule settings.
 * Changes on ANY site propagate to all others (DA ME updates Mr Joe, and vice versa).
 * When auto-reset expires dates on one site, all sites sync that reset immediately.
 */
function ARD_wc_propagate_schedule_to_linked_sites() {
  global $ARD_WC_PROPAGATING;
  if ( $ARD_WC_PROPAGATING ) { return; }
  if ( ! is_multisite() ) { return; }

  $linked = (array) get_option( 'wc_schedule_linked_sites', [] );
  if ( empty( $linked ) ) { return; }

  $vals = [
    'wc_schedule_enabled'  => (int) get_option( 'wc_schedule_enabled', 0 ),
    'wc_closed_start_date' => (string) get_option( 'wc_closed_start_date', '' ),
    'wc_closed_end_date'   => (string) get_option( 'wc_closed_end_date', '' ),
    'wc_closed_start_time' => (string) get_option( 'wc_closed_start_time', '' ),
    'wc_closed_end_time'   => (string) get_option( 'wc_closed_end_time', '' ),
    'wc_closed_message'    => (string) get_option( 'wc_closed_message', '' ),
  ];

  $origin = get_current_blog_id();
  $ARD_WC_PROPAGATING = true;
  foreach ( $linked as $blog_id ) {
    $blog_id = (int) $blog_id;
    if ( $blog_id === $origin ) { continue; }
    switch_to_blog( $blog_id );
    foreach ( $vals as $k => $v ) { update_option( $k, $v ); }
    restore_current_blog();
  }
  $ARD_WC_PROPAGATING = false;
}

/**
 * Clear cache when schedule changes to ensure banner updates immediately.
 * This works with LiteSpeed Cache, WP Cache, and other caching plugins.
 */
function ARD_wc_clear_cache_on_schedule_change() {
  // LiteSpeed Cache
  if ( function_exists('do_action') ) {
    do_action('litespeed_purge_all');
  }
  
  // WP native cache
  wp_cache_flush();
  
  // Object cache
  if ( function_exists('wp_cache_flush') ) {
    wp_cache_flush();
  }
}

// Propagate on any relevant option update (including auto-resets)
add_action( 'update_option_wc_schedule_enabled', 'ARD_wc_propagate_schedule_to_linked_sites', 10, 0 );
add_action( 'update_option_wc_closed_start_date', 'ARD_wc_propagate_schedule_to_linked_sites', 10, 0 );
add_action( 'update_option_wc_closed_end_date', 'ARD_wc_propagate_schedule_to_linked_sites', 10, 0 );
add_action( 'update_option_wc_closed_start_time', 'ARD_wc_propagate_schedule_to_linked_sites', 10, 0 );
add_action( 'update_option_wc_closed_end_time', 'ARD_wc_propagate_schedule_to_linked_sites', 10, 0 );
add_action( 'update_option_wc_closed_message', 'ARD_wc_propagate_schedule_to_linked_sites', 10, 0 );
add_action( 'update_option_wc_schedule_linked_sites', 'ARD_wc_propagate_schedule_to_linked_sites', 10, 0 );

// Clear cache after schedule changes
add_action( 'update_option_wc_schedule_enabled', 'ARD_wc_clear_cache_on_schedule_change', 11, 0 );
add_action( 'update_option_wc_closed_start_date', 'ARD_wc_clear_cache_on_schedule_change', 11, 0 );
add_action( 'update_option_wc_closed_end_date', 'ARD_wc_clear_cache_on_schedule_change', 11, 0 );
add_action( 'update_option_wc_closed_start_time', 'ARD_wc_clear_cache_on_schedule_change', 11, 0 );
add_action( 'update_option_wc_closed_end_time', 'ARD_wc_clear_cache_on_schedule_change', 11, 0 );
add_action( 'update_option_wc_closed_message', 'ARD_wc_clear_cache_on_schedule_change', 11, 0 );

// Clear cache after slides or category icons changes
add_action( 'update_option_app_slides', 'ARD_wc_clear_cache_on_schedule_change', 11, 0 );
add_action( 'add_option_app_slides', 'ARD_wc_clear_cache_on_schedule_change', 11, 0 );
add_action( 'update_option_app_category_icons', 'ARD_wc_clear_cache_on_schedule_change', 11, 0 );
add_action( 'add_option_app_category_icons', 'ARD_wc_clear_cache_on_schedule_change', 11, 0 );

// ===== Admin Toolbar Items =====
function ARD_app_is_active_cached() {
  static $cached = null;
  if ( $cached !== null ) { return $cached; }

  $fetch_url = get_option( 'fetch_url' );
  if ( empty( $fetch_url ) || ! is_string( $fetch_url ) || trim( $fetch_url ) === '' ) {
    $cached = false;
    return $cached;
  }

  $active = true; // Default to active
  $endpoint = rtrim( $fetch_url, '/' ) . '/appStatus';
  $resp = wp_remote_get( $endpoint, [ 'timeout' => 3, 'redirection' => 2, 'sslverify' => false ] );
  if ( ! is_wp_error( $resp ) && isset( $resp['response']['code'] ) && (int) $resp['response']['code'] === 200 ) {
    $body = wp_remote_retrieve_body( $resp );
    $data = json_decode( $body, true );
    if ( is_array( $data ) ) {
      $isOnline = isset( $data['isOnline'] ) ? (bool) $data['isOnline'] : true;
      if ( ! $isOnline ) {
        // App is locked ONLY if current time is within the scheduled inactivity window
        if ( ! empty( $data['inactivity']['startAt'] ) && ! empty( $data['inactivity']['endAt'] ) ) {
          $now = time() * 1000; // current time in milliseconds
          $start = (float) $data['inactivity']['startAt'];
          $end = (float) $data['inactivity']['endAt'];
          if ( $now >= $start && $now <= $end ) {
            $active = false;
          }
        } else {
          // If isOnline is false and no schedule, mark as inactive
          $active = false;
        }
      }
    }
  } else {
    $active = false; // Fallback if API fails
  }
  $cached = $active;
  return $cached;
}

function ARD_admin_bar_items() {
  global $wp_admin_bar;
  if ( ! is_admin_bar_showing() || ! is_user_logged_in() ) { return; }
  
  // Stato Woo button
  $wc_open = ARD_wc_orders_open();
  $wc_color = $wc_open ? '#2e7d32' : '#b00020';
  $wc_label = $wc_open ? '🟢 Ordini Attivi' : '🔴 Ordini Chiusi';
  $wp_admin_bar->add_node( [
    'id' => 'ard-wc-status',
    'parent' => 'top-secondary',
    'title' => '<span style="background:' . $wc_color . '; color:#fff; padding:5px 15px; border-radius:4px; display:inline-block; font-weight:600; line-height:1.2;">' . $wc_label . '</span>',
    'href' => admin_url( 'admin.php?page=wc_site_status' ),
    'meta' => [ 'class' => 'ard-admin-bar-item' ],
  ] );
  
  // Stato App button (ONLY if fetch_url is set)
  $fetch_url = get_option('fetch_url');
  if ( ! empty( $fetch_url ) ) {
      $app_url = admin_url( 'admin.php?page=app_administration_backoffice' );
      $app_active = ARD_app_is_active_cached();
      $app_color = $app_active ? '#2e7d32' : '#b00020';
      $app_label = $app_active ? '🟢 App Attiva' : '🔴 App Inattiva';
      $wp_admin_bar->add_node( [
        'id' => 'ard-app-status',
        'parent' => 'top-secondary',
        'title' => '<span style="background:' . $app_color . '; color:#fff; padding:5px 15px; border-radius:4px; display:inline-block; font-weight:600; line-height:1.2;">' . $app_label . '</span>',
        'href' => $app_url,
        'meta' => [ 'class' => 'ard-admin-bar-item' ],
      ] );
  }
}
add_action( 'admin_bar_menu', 'ARD_admin_bar_items', 999 );

// Inject notifications manager UI (hidden, will be shown when clicking "Notifiche")
function ARD_inject_notifications_manager_hidden() {
  $fetch_url = get_option('fetch_url');
  if (empty($fetch_url)) {
    return; // Skip if no Firebase URL configured
  }
  
  $fetch_url_escaped = esc_attr($fetch_url);
  $fcm_admin_key = esc_attr(get_option('fcm_admin_key', ''));
  
  $sites_list = ARD_wc_get_sites_list();
  if ( is_multisite() ) {
    $linked_sites = (array) get_option( 'wc_schedule_linked_sites', array() );
    if ( empty( $linked_sites ) ) {
      $linked_sites = array( get_current_blog_id() );
    }
    $linked_sites_ints = array_map( 'intval', $linked_sites );
    $filtered_sites = array();
    foreach ( $sites_list as $sid => $label ) {
      if ( in_array( (int) $sid, $linked_sites_ints, true ) ) {
        $filtered_sites[$sid] = $label;
      }
    }
    $sites_list = $filtered_sites;
  }
  
  $current_blog_id = get_current_blog_id();
  
  $rest_urls = array();
  if ( is_multisite() ) {
    foreach ( $sites_list as $sid => $label ) {
      $rest_urls[ $sid ] = array(
        'cats' => esc_url_raw( get_rest_url( $sid, 'wc/v3/products/categories' ) ),
        'products' => esc_url_raw( get_rest_url( $sid, 'wc/v3/products' ) ),
      );
    }
  }

  $site_domains = array();
  if ( is_multisite() ) {
    foreach ( $sites_list as $sid => $label ) {
      $site_domains[ $sid ] = str_replace( array( 'http://', 'https://', '/' ), '', get_home_url( $sid ) );
    }
  }
  ?>
  <style>
    #ard-notifications-manager {
      display: block;
      position: relative;
      background: #fff;
      border: 1px solid #ddd;
      border-radius: 8px;
      padding: 20px;
      margin: 20px 0 40px 0;
      max-width: 100%;
      width: 100%;
      box-shadow: 0 2px 6px rgba(0,0,0,0.08);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      z-index: auto;
    }
    #ard-notifications-manager.ard-visible { display: block; }
    #ard-notifications-manager > * { max-width: 100%; margin: 0; }
    #ard-notifications-manager h2 {
      margin: 0 0 20px 0;
      font-size: 24px;
      color: #333;
      border-bottom: 2px solid #2196F3;
      padding-bottom: 10px;
    }
    .ard-notif-form-grid {
      display: grid;
      grid-template-columns: 1fr;
      gap: 20px;
      margin-bottom: 20px;
    }
    .ard-notif-form-field {
      display: flex;
      flex-direction: column;
    }
    .ard-notif-form-field label {
      font-weight: 600;
      margin-bottom: 8px;
      color: #555;
      font-size: 13px;
    }
    .ard-notif-form-field input,
    .ard-notif-form-field textarea,
    .ard-notif-form-field select {
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 4px;
      font-size: 14px;
      font-family: inherit;
    }
    .ard-notif-form-field textarea {
      min-height: 100px;
      resize: vertical;
    }
    .ard-notif-button {
      padding: 12px 24px;
      border: none;
      border-radius: 4px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s;
      margin-right: 10px;
    }
    .ard-notif-button-primary {
      background: #2196F3;
      color: white;
    }
    .ard-notif-button-primary:hover {
      background: #1976D2;
    }
    .ard-notif-message {
      padding: 12px;
      border-radius: 4px;
      margin-top: 15px;
      font-size: 14px;
    }
    .ard-notif-message-success {
      background: #4caf50;
      color: white;
    }
    .ard-notif-message-error {
      background: #f44336;
      color: white;
    }
    .ard-notif-info {
      background: #e3f2fd;
      border-left: 4px solid #2196F3;
      padding: 12px;
      margin-bottom: 15px;
      font-size: 14px;
    }
    /* Autocomplete for app deep links */
    .ard-link-autocomplete {
      position: relative;
    }
    .ard-link-autocomplete input {
      width: 100%;
    }
    .ard-link-dropdown {
      position: absolute;
      top: 100%;
      left: 0;
      right: 0;
      background: #fff;
      border: 1px solid #ddd;
      border-top: none;
      border-radius: 0 0 6px 6px;
      max-height: 220px;
      overflow-y: auto;
      z-index: 1000;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      display: none;
    }
    .ard-link-dropdown.active { display: block; }
    .ard-link-option {
      padding: 10px 14px;
      cursor: pointer;
      font-size: 13px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      transition: background 0.15s;
      gap: 12px;
    }
    .ard-link-option:hover, .ard-link-option.selected {
      background: #e3f2fd;
    }
    .ard-link-option .ard-link-label { font-weight: 500; white-space: nowrap; }
    .ard-link-option .ard-link-value { color: #999; font-size: 11px; text-align: right; word-break: break-all; max-width: 180px; }
    .ard-link-clear {
      position: absolute;
      right: 8px;
      top: 50%;
      transform: translateY(-50%);
      background: none;
      border: none;
      cursor: pointer;
      font-size: 16px;
      color: #999;
      padding: 2px 6px;
      border-radius: 50%;
      line-height: 1;
    }
    .ard-link-clear:hover { background: #f0f0f0; color: #333; }
  </style>

  <div class="wrap"><div id="ard-notifications-manager">
    <h2>📢 Invia Notifiche Push</h2>
    
    <div class="ard-notif-info">
      <strong>ℹ️ Come funziona:</strong><br>
      Invia una notifica push a tutti gli utenti della app mobile. La notifica aparirà sul loro dispositivo con il titolo e il messaggio specificati.
    </div>

    <div class="ard-notif-form-grid">
      <div class="ard-notif-form-field">
        <label>👤 Destinatari</label>
        <select id="ard-notif-recipients">
          <option value="all">Tutti gli utenti</option>
          <option value="android">Solo Android</option>
          <option value="ios">Solo iOS</option>
        </select>
      </div>
    </div>

    <div class="ard-notif-form-grid">
      <div class="ard-notif-form-field">
        <label>📝 Titolo Notifica</label>
        <input type="text" id="ard-notif-title" placeholder="Es: Nuova Offerta!" maxlength="60" />
      </div>
      <div class="ard-notif-form-field">
        <label>📝 Messaggio</label>
        <textarea id="ard-notif-message" placeholder="Es: Scopri le nostre nuove promozioni di fine anno!"></textarea>
      </div>
      <div class="ard-notif-form-field">
        <label>🔗 Link (opzionale)</label>
        
        <?php if ( is_multisite() ) : ?>
        <div style="margin-bottom:8px;">
          <select id="ard-notif-site-id" style="width:100%; padding:6px; border:1px solid #ddd; border-radius:6px; font-size:13px; height:32px;">
            <option value="0">🌍 Tutte le filiali (Generico)</option>
            <?php foreach ( $sites_list as $sid => $label ) : ?>
              <option value="<?php echo (int)$sid; ?>">
                📍 <?php echo esc_html( $label ); ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <?php else : ?>
        <input type="hidden" id="ard-notif-site-id" value="0" />
        <?php endif; ?>

        <div class="ard-link-autocomplete" id="ard-notif-link-wrap">
          <input type="text" id="ard-notif-link" placeholder="Digita per cercare una pagina dell'app..." autocomplete="off" />
          <button type="button" class="ard-link-clear" id="ard-notif-link-clear" style="display:none;" title="Rimuovi link">&times;</button>
          <div class="ard-link-dropdown" id="ard-notif-link-dropdown"></div>
        </div>
        <small style="color:#888; margin-top:4px; display:block;">Seleziona una pagina dell'app. Lascia vuoto per aprire la Home.</small>
      </div>
    </div>

    <div style="display: flex; align-items: center; gap: 10px;">
      <button class="ard-notif-button ard-notif-button-primary" onclick="ARD_sendNotification()">
        ✈️ Invia Notifica
      </button>
      <div id="ard-notif-loading" style="display:none; color:#2196F3; font-weight:600;">
        ⏳ Invio in corso...
      </div>
    </div>

    <div id="ard-notif-message"></div>
  </div></div>

  <script>
  (function() {
    const API_URL = '<?php echo $fetch_url_escaped; ?>';
    const FCM_ADMIN_KEY = '<?php echo $fcm_admin_key; ?>';
    const WP_NONCE = '<?php echo wp_create_nonce("wp_rest"); ?>';
    const CURRENT_BLOG_ID = <?php echo (int) $current_blog_id; ?>;
    const REST_URLS = <?php echo json_encode( $rest_urls ); ?>;
    const BRANCH_PAGES_API_URL = '<?php echo esc_url( get_rest_url( null, "mobile-admin/v1/branch-pages" ) ); ?>';
    const SITE_DOMAINS = <?php echo json_encode( $site_domains ); ?>;

    // ── App Deep Link Autocomplete ──
    const STATIC_PAGES = [
      { label: '🏠 Home', value: 'app://home' },
      { label: '🛒 Carrello', value: 'app://cart' },
      { label: '📋 Ordini', value: 'app://orders' },
      { label: '❤️ Favoriti', value: 'app://favorites' },
      { label: 'ℹ️ Chi Siamo', value: 'app://about' },
      { label: '👤 Il Mio Account', value: 'app://account' },
      { label: '📍 Indirizzi', value: 'app://addresses' },
      { label: '📄 Altre Info', value: 'app://info' },
      { label: '📜 Impressum', value: 'app://impressum' },
    ];
    
    const branchPagesCache = {
      "0": [...STATIC_PAGES]
    };

    window.ARD_getBranchPages = function(siteId, callback) {
      siteId = parseInt(siteId) || 0;
      if (branchPagesCache[siteId]) {
        callback(branchPagesCache[siteId]);
        return;
      }

      if (siteId === 0) {
        callback(STATIC_PAGES);
        return;
      }

      fetch(BRANCH_PAGES_API_URL + '?blog_id=' + siteId, {
        headers: { 'X-WP-Nonce': WP_NONCE }
      })
      .then(r => r.json())
      .then(res => {
        let categoryPages = [];
        let productPages = [];
        if (res && Array.isArray(res.categories)) {
          categoryPages = res.categories.map(c => ({
            label: '📁 Categoria: ' + c.name,
            value: 'app://category/' + c.id + '/' + encodeURIComponent(c.name),
            blog_id: siteId
          }));
        }
        if (res && Array.isArray(res.products)) {
          productPages = res.products.map(p => {
            return {
              label: '🍕 Prodotto: ' + p.name,
              value: 'app://product/' + p.cat_id + '/' + encodeURIComponent(p.cat_name) + '/' + encodeURIComponent(p.name),
              blog_id: siteId
            };
          });
        }
        const combined = [...STATIC_PAGES, ...categoryPages, ...productPages];
        branchPagesCache[siteId] = combined;
        callback(combined);
      })
      .catch(err => {
        console.error("Error loading branch pages:", err);
        callback(STATIC_PAGES);
      });
    };

    let allPages = [];
    window.ARD_getBranchPages(CURRENT_BLOG_ID, (pages) => {
      allPages = pages;
      window.ARD_allPages = pages;
    });

    /**
     * Initialize autocomplete on an input + dropdown pair.
     * @param {string} inputId - The input element ID
     * @param {string} dropdownId - The dropdown element ID
     * @param {string} clearBtnId - The clear button ID
     * @param {string|null} hiddenInputName - If set, creates/updates a hidden input with this name
     * @param {string|null} siteSelectId - If set, filters suggestions dynamically by selected site select field
     */
    window.ARD_initLinkAutocomplete = function(inputId, dropdownId, clearBtnId, hiddenInputName, siteSelectId) {
      const input = document.getElementById(inputId);
      const dropdown = document.getElementById(dropdownId);
      const clearBtn = document.getElementById(clearBtnId);
      if (!input || !dropdown) return;

      let selectedValue = '';

      function render(filter) {
        const q = (filter || '').toLowerCase();
        const siteSelect = siteSelectId ? document.getElementById(siteSelectId) : null;
        const siteId = siteSelect ? parseInt(siteSelect.value) : CURRENT_BLOG_ID;

        window.ARD_getBranchPages(siteId, (pages) => {
          const matches = q ? pages.filter(p => p.label.toLowerCase().includes(q) || p.value.toLowerCase().includes(q)) : pages;
          if (matches.length === 0) {
            dropdown.innerHTML = '<div class="ard-link-option" style="color:#999; cursor:default;">Nessun risultato</div>';
          } else {
            dropdown.innerHTML = matches.map(p =>
              '<div class="ard-link-option" data-value="' + p.value + '">' +
                '<span class="ard-link-label">' + p.label + '</span>' +
                '<span class="ard-link-value">' + decodeURIComponent(p.value.replace('app://', '')) + '</span>' +
              '</div>'
            ).join('');
          }
          dropdown.classList.add('active');
        });
      }

      input.addEventListener('focus', () => render(input.value));
      input.addEventListener('input', () => render(input.value));

      if (siteSelectId) {
        const siteSelect = document.getElementById(siteSelectId);
        if (siteSelect) {
          siteSelect.addEventListener('change', () => {
            // Clear input values when site changes to avoid cross-site link leak
            selectedValue = '';
            input.value = '';
            input.dataset.linkValue = '';
            if (clearBtn) clearBtn.style.display = 'none';
            if (hiddenInputName) {
              const hidden = input.parentElement.querySelector('input[name="' + hiddenInputName + '"]');
              if (hidden) hidden.value = '';
            }
          });
        }
      }

      dropdown.addEventListener('click', (e) => {
        const option = e.target.closest('.ard-link-option');
        if (!option || !option.dataset.value) return;
        selectedValue = option.dataset.value;
        input.value = option.querySelector('.ard-link-label').textContent;
        input.dataset.linkValue = selectedValue;
        dropdown.classList.remove('active');
        if (clearBtn) clearBtn.style.display = 'block';
        // Update hidden input if exists
        if (hiddenInputName) {
          let hidden = input.parentElement.querySelector('input[name="' + hiddenInputName + '"]');
          if (!hidden) {
            hidden = document.createElement('input');
            hidden.type = 'hidden';
            hidden.name = hiddenInputName;
            input.parentElement.appendChild(hidden);
          }
          hidden.value = selectedValue;
        }
      });

      if (clearBtn) {
        clearBtn.addEventListener('click', () => {
          selectedValue = '';
          input.value = '';
          input.dataset.linkValue = '';
          clearBtn.style.display = 'none';
          if (hiddenInputName) {
            const hidden = input.parentElement.querySelector('input[name="' + hiddenInputName + '"]');
            if (hidden) hidden.value = '';
          }
        });
      }

      // Close dropdown when clicking outside
      document.addEventListener('click', (e) => {
        if (!input.contains(e.target) && !dropdown.contains(e.target)) {
          dropdown.classList.remove('active');
        }
      });

      // Return getter for the selected link value
      return () => input.dataset.linkValue || selectedValue || '';
    };

    // Initialize notification link autocomplete
    const getNotifLink = ARD_initLinkAutocomplete('ard-notif-link', 'ard-notif-link-dropdown', 'ard-notif-link-clear', null, 'ard-notif-site-id');

    window.ARD_sendNotification = async function() {
      const recipients = document.getElementById('ard-notif-recipients').value;
      const title = document.getElementById('ard-notif-title').value.trim();
      const message = document.getElementById('ard-notif-message').value.trim();
      const link = getNotifLink ? getNotifLink() : '';
      const loadingDiv = document.getElementById('ard-notif-loading');
      const msgDiv = document.getElementById('ard-notif-message');

      const siteSelect = document.getElementById('ard-notif-site-id');
      const siteId = siteSelect ? siteSelect.value : '0';
      
      let branchUrl = null;
      if (typeof SITE_DOMAINS !== 'undefined') {
        if (siteId !== '0' && SITE_DOMAINS[siteId]) {
          branchUrl = SITE_DOMAINS[siteId];
        } else if (typeof CURRENT_BLOG_ID !== 'undefined' && SITE_DOMAINS[CURRENT_BLOG_ID]) {
          branchUrl = SITE_DOMAINS[CURRENT_BLOG_ID];
        }
      }

      if (!title) {
        showNotifMessage('⚠️ Inserisci un titolo per la notifica', true);
        return;
      }

      if (!message) {
        showNotifMessage('⚠️ Inserisci un messaggio', true);
        return;
      }

      try {
        loadingDiv.style.display = 'block';
        msgDiv.textContent = '';

        const payload = {
          title: title,
          message: message,
          link: link || null,
          branchUrl: branchUrl,
          recipients: recipients,
          adminKey: FCM_ADMIN_KEY
        };

        const response = await fetch(API_URL + '/fcmNotifications/sendNotification', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-fcm-admin-key': FCM_ADMIN_KEY
          },
          body: JSON.stringify(payload)
        });

        if (!response.ok) {
          const error = await response.json();
          throw new Error(error.error || 'Errore invio notifica');
        }

        const result = await response.json();
        
        loadingDiv.style.display = 'none';
        showNotifMessage('✅ Notifica inviata! Broadcast: ' + (result.topicBroadcast || '✅') + ' | Legacy: ' + (result.legacySentCount || 0) + ' dispositivi');
        
        // Clear form
        document.getElementById('ard-notif-title').value = '';
        document.getElementById('ard-notif-message').value = '';
        document.getElementById('ard-notif-link').value = '';
        document.getElementById('ard-notif-link').dataset.linkValue = '';
        document.getElementById('ard-notif-link-clear').style.display = 'none';
      } catch (error) {
        loadingDiv.style.display = 'none';
        showNotifMessage('❌ Errore: ' + error.message, true);
      }
    };

    function showNotifMessage(text, isError = false) {
      const msgDiv = document.getElementById('ard-notif-message');
      msgDiv.className = 'ard-notif-message ' + (isError ? 'ard-notif-message-error' : 'ard-notif-message-success');
      msgDiv.textContent = text;
      if (!isError) {
        setTimeout(() => msgDiv.textContent = '', 5000);
      }
    }

    // Initialize
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => {
        const panel = document.getElementById('ard-notifications-manager');
        if (panel) {
          panel.classList.add('ard-visible');
        }
      });
    } else {
      const panel = document.getElementById('ard-notifications-manager');
      if (panel) {
        panel.classList.add('ard-visible');
      }
    }
  })();
  </script>
  <?php
}

function remove_footer_admin()
{
  echo '<span id="footer-thankyou">Developed by <a href="https://ticinoweb.com/" target="_blank">TicinoWEB</a></span>';
}

add_filter('admin_footer_text', 'remove_footer_admin');

// ==============================
// REST API for Mobile App Config (v1.4.0)
// ==============================

add_action( 'rest_api_init', 'WPADR_register_rest_routes' );
function WPADR_register_rest_routes() {
	// GET /wp-json/mobile-admin/v1/config
	register_rest_route( 'mobile-admin/v1', '/config', array(
		'methods'  => 'GET',
		'callback' => 'WPADR_rest_get_config',
		'permission_callback' => '__return_true',
	) );

	// GET /wp-json/mobile-admin/v1/pos-info
	register_rest_route( 'mobile-admin/v1', '/pos-info', array(
		'methods'  => 'GET',
		'callback' => 'WPADR_rest_get_pos_info',
		'permission_callback' => '__return_true',
	) );

	// POST /wp-json/mobile-admin/v1/register-or-add
	// Handles WP Multisite: if user exists in network, adds to this subsite + updates password
	register_rest_route( 'mobile-admin/v1', '/register-or-add', array(
		'methods'  => 'POST',
		'callback' => 'WPADR_rest_register_or_add_user',
		'permission_callback' => '__return_true',
	) );

	// GET /wp-json/mobile-admin/v1/order-status
	register_rest_route( 'mobile-admin/v1', '/order-status', array(
		'methods'  => 'GET',
		'callback' => 'WPADR_rest_get_order_status',
		'permission_callback' => '__return_true',
	) );
}

/**
 * GET /wp-json/mobile-admin/v1/order-status?id=123
 * Returns the status of a WooCommerce order.
 */
function WPADR_rest_get_order_status( $request ) {
	$order_id = $request->get_param( 'id' );
	if ( empty( $order_id ) ) {
		return new WP_Error( 'missing_id', 'Missing order ID', array( 'status' => 400 ) );
	}

	if ( ! class_exists( 'WooCommerce' ) ) {
		return new WP_Error( 'wc_missing', 'WooCommerce is not active on this site', array( 'status' => 500 ) );
	}

	$order = wc_get_order( (int) $order_id );
	if ( ! $order ) {
		return new WP_Error( 'invalid_order', 'Order not found', array( 'status' => 404 ) );
	}

	return rest_ensure_response( array(
		'status' => $order->get_status()
	) );
}

/**
 * GET /wp-json/mobile-admin/v1/config
 * Returns public mobile app configuration including Stripe publishable key.
 */
function WPADR_rest_get_config( $request ) {
	$stripe_key = get_option( 'stripe_publishable_key', '' );
	$app_name   = get_bloginfo( 'name' );

	return rest_ensure_response( array(
		'stripePublishableKey' => $stripe_key,
		'appName'             => $app_name,
	) );
}

/**
 * POST /wp-json/mobile-admin/v1/register-or-add
 *
 * For WP Multisite: if a user already exists in the network but not on this
 * subsite, add them to this site, update their password, and return a JWT.
 * If the user does not exist at all, create them normally.
 *
 * Params: username, email, password, AUTH_KEY
 */
function WPADR_rest_register_or_add_user( $request ) {
	$username = sanitize_user( $request->get_param( 'username' ) );
	$email    = sanitize_email( $request->get_param( 'email' ) );
	$password = $request->get_param( 'password' );
	$auth_key = $request->get_param( 'AUTH_KEY' );

	// Validate AUTH_KEY against Simple JWT Login auth codes
	$sjl_raw      = get_option( 'simple_jwt_login_settings', '{}' );
	$sjl_settings = is_string( $sjl_raw ) ? json_decode( $sjl_raw, true ) : $sjl_raw;
	if ( ! is_array( $sjl_settings ) ) $sjl_settings = array();

	$valid_key = false;
	if ( ! empty( $sjl_settings['auth_codes'] ) ) {
		foreach ( $sjl_settings['auth_codes'] as $code_entry ) {
			if ( isset( $code_entry['code'] ) && $code_entry['code'] === $auth_key ) {
				$valid_key = true;
				break;
			}
		}
	}
	if ( ! $valid_key ) {
		return new WP_Error( 'invalid_auth_key', 'AUTH_KEY non valida.', array( 'status' => 403 ) );
	}

	if ( empty( $username ) || empty( $email ) || empty( $password ) ) {
		return new WP_Error( 'missing_fields', 'Username, email e password sono obbligatori.', array( 'status' => 400 ) );
	}

	$current_blog_id = get_current_blog_id();

	// Check if user exists by username or email
	$user = get_user_by( 'login', $username );
	if ( ! $user ) {
		$user = get_user_by( 'email', $email );
	}

	if ( $user ) {
		// User exists in the network — add to this subsite if not already a member
		if ( ! is_user_member_of_blog( $user->ID, $current_blog_id ) ) {
			$role = ! empty( $sjl_settings['new_user_profile'] ) ? $sjl_settings['new_user_profile'] : 'customer';
			add_user_to_blog( $current_blog_id, $user->ID, $role );
		}

		// Update password to the one they provided
		wp_set_password( $password, $user->ID );

		// Clear cached user object after password change
		$user = get_user_by( 'id', $user->ID );
	} else {
		// User does not exist at all — create them
		$user_id = wp_create_user( $username, $password, $email );
		if ( is_wp_error( $user_id ) ) {
			return $user_id;
		}
		$role = ! empty( $sjl_settings['new_user_profile'] ) ? $sjl_settings['new_user_profile'] : 'customer';
		$user = get_user_by( 'id', $user_id );
		$user->set_role( $role );
	}

	// Generate JWT using Simple JWT Login's decryption key
	$decryption_key = isset( $sjl_settings['decryption_key'] ) ? $sjl_settings['decryption_key'] : '';
	if ( empty( $decryption_key ) ) {
		return new WP_Error( 'jwt_config_error', 'JWT decryption key non configurata.', array( 'status' => 500 ) );
	}

	$issued_at = time();
	$ttl       = isset( $sjl_settings['jwt_auth_ttl'] ) ? intval( $sjl_settings['jwt_auth_ttl'] ) : 60;
	$iss       = isset( $sjl_settings['jwt_auth_iss'] ) ? stripslashes( $sjl_settings['jwt_auth_iss'] ) : get_site_url();

	$payload = array(
		'iat'      => $issued_at,
		'exp'      => $issued_at + ( $ttl * 60 ),
		'email'    => $user->user_email,
		'id'       => $user->ID,
		'username' => $user->user_login,
		'iss'      => $iss,
	);

	$jwt = WPADR_jwt_encode( $payload, $decryption_key );

	return rest_ensure_response( array(
		'success' => true,
		'id'      => $user->ID,
		'message' => 'Utente registrato/aggiunto con successo.',
		'user'    => array(
			'ID'         => (string) $user->ID,
			'user_login' => $user->user_login,
			'user_email' => $user->user_email,
		),
		'jwt'     => $jwt,
	) );
}

/**
 * Simple HS256 JWT encoder (avoids external library dependency).
 */
function WPADR_jwt_encode( $payload, $secret ) {
	$header = array( 'typ' => 'JWT', 'alg' => 'HS256' );

	$segments = array(
		WPADR_base64url_encode( json_encode( $header, JSON_UNESCAPED_SLASHES ) ),
		WPADR_base64url_encode( json_encode( $payload, JSON_UNESCAPED_SLASHES ) ),
	);

	$signing_input = implode( '.', $segments );
	$signature     = hash_hmac( 'sha256', $signing_input, $secret, true );
	$segments[]    = WPADR_base64url_encode( $signature );

	return implode( '.', $segments );
}

function WPADR_base64url_encode( $data ) {
	return rtrim( strtr( base64_encode( $data ), '+/', '-_' ), '=' );
}

// ================================================================
// SLIDES MANAGEMENT
// ================================================================

function ARD_register_slides_settings() {
  register_setting( 'ard-slides-group', 'app_slides', array(
    'type' => 'array',
    'default' => array(),
    'sanitize_callback' => 'ARD_sanitize_slides',
  ) );
}

function ARD_sanitize_slides( $input ) {
  if ( ! is_array( $input ) ) return array();
  $slides = array_slice( $input, 0, 5 ); // Max 5 slides
  $result = array();
  foreach ( $slides as $slide ) {
    // Support legacy format (plain URL string) and new format (object with url+title+link)
    if ( is_string( $slide ) ) {
      $url = $slide;
      $title = '';
      $link = '';
    } elseif ( is_array( $slide ) ) {
      $url = isset( $slide['url'] ) ? $slide['url'] : '';
      $title = isset( $slide['title'] ) ? sanitize_text_field( $slide['title'] ) : '';
      $link = isset( $slide['link'] ) ? sanitize_text_field( $slide['link'] ) : '';
      $site_id = isset( $slide['site_id'] ) ? (int) $slide['site_id'] : 0;
    } else {
      continue;
    }
    if ( filter_var( $url, FILTER_VALIDATE_URL ) ) {
      $result[] = array( 'url' => $url, 'title' => $title, 'link' => $link, 'site_id' => $site_id );
    }
  }
  return array_values( $result );
}

add_action( 'save_post_product', 'ARD_clear_search_targets_transient' );
add_action( 'edited_product_cat', 'ARD_clear_search_targets_transient' );
function ARD_clear_search_targets_transient() {
  delete_site_transient( 'ard_all_search_targets_v5' );
}

// Filter WooCommerce REST API product response to serve optimized thumbnails instead of original full-size images
add_filter( 'woocommerce_rest_prepare_product_object', 'ARD_optimize_rest_product_images', 10, 3 );
function ARD_optimize_rest_product_images( $response, $object, $request ) {
  $data = $response->get_data();
  if ( ! empty( $data['images'] ) && is_array( $data['images'] ) ) {
    foreach ( $data['images'] as $key => $image ) {
      if ( ! empty( $image['id'] ) ) {
        $attachment_id = (int) $image['id'];
        // Use 'medium' (typically 300x300px) which is extremely light (often < 30KB) and resolves immediately
        $thumbnail_url = wp_get_attachment_image_url( $attachment_id, 'medium' );
        if ( $thumbnail_url ) {
          $data['images'][$key]['src'] = $thumbnail_url;
        }
      }
    }
    $response->set_data( $data );
  }
  return $response;
}

// Filter WooCommerce REST API product variation response to serve optimized thumbnails instead of original full-size images
add_filter( 'woocommerce_rest_prepare_product_variation_object', 'ARD_optimize_rest_variation_images', 10, 3 );
function ARD_optimize_rest_variation_images( $response, $object, $request ) {
  $data = $response->get_data();
  if ( ! empty( $data['image'] ) && is_array( $data['image'] ) ) {
    if ( ! empty( $data['image']['id'] ) ) {
      $attachment_id = (int) $data['image']['id'];
      $thumbnail_url = wp_get_attachment_image_url( $attachment_id, 'medium' );
      if ( $thumbnail_url ) {
        $data['image']['src'] = $thumbnail_url;
      }
    }
    $response->set_data( $data );
  }
  return $response;
}


function ARD_get_all_search_targets() {
  $cache = get_site_transient( 'ard_all_search_targets_v5' );
  if ( ! empty( $cache ) && is_array( $cache ) ) {
    return $cache;
  }

  global $wpdb;
  $targets = [];
  
  if ( is_multisite() ) {
    $linked_sites = (array) get_option( 'wc_schedule_linked_sites', [] );
    if ( empty( $linked_sites ) ) {
      $linked_sites = [ get_current_blog_id() ];
    }
    $linked_sites_ints = array_map( 'intval', $linked_sites );

    $sites = get_sites([ 'number' => 0 ]);
    foreach ( $sites as $site ) {
      $blog_id = (int) $site->blog_id;
      if ( ! in_array( $blog_id, $linked_sites_ints, true ) ) {
        continue;
      }
      switch_to_blog( $blog_id );
      
      $site_name = str_replace( [ 'bellinzona.', 'giubiasco.', 'sorengo.', 'dame-' ], '', $site->domain );
      $site_name = ucfirst( explode( '.', $site_name )[0] );
      
      // 1. Query Categories via SQL directly (with correct blog prefix)
      $categories = $wpdb->get_results( "
        SELECT t.term_id, t.name 
        FROM {$wpdb->prefix}terms t 
        INNER JOIN {$wpdb->prefix}term_taxonomy tt ON t.term_id = tt.term_id 
        WHERE tt.taxonomy = 'product_cat'
      " );
      if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) {
        foreach ( $categories as $cat ) {
          $targets[] = [
            'label' => '🍕 [' . $site_name . '] ' . $cat->name,
            'value' => 'app://category/' . $cat->term_id . '/' . rawurlencode( $cat->name ),
            'blog_id' => $blog_id,
          ];
        }
      }
      
      // 2. Query Products via SQL directly (with correct blog prefix)
      $products = $wpdb->get_results( "
        SELECT p.ID, p.post_title, 
               (SELECT tr.term_taxonomy_id 
                FROM {$wpdb->prefix}term_relationships tr 
                INNER JOIN {$wpdb->prefix}term_taxonomy tt ON tr.term_taxonomy_id = tt.term_taxonomy_id 
                WHERE tr.object_id = p.ID AND tt.taxonomy = 'product_cat' 
                LIMIT 1) as cat_id
        FROM {$wpdb->prefix}posts p
        WHERE p.post_type = 'product' AND p.post_status = 'publish'
      " );
      if ( ! empty( $products ) && ! is_wp_error( $products ) ) {
        foreach ( $products as $prod ) {
          $cat_id = $prod->cat_id ? (int) $prod->cat_id : 0;
          $targets[] = [
            'label' => '🍔 [' . $site_name . '] ' . $prod->post_title,
            'value' => 'app://product/' . $cat_id . '/' . rawurlencode( $prod->post_title ),
            'blog_id' => $blog_id,
          ];
        }
      }
      
      restore_current_blog();
    }
  } else {
    $categories = $wpdb->get_results( "
      SELECT t.term_id, t.name 
      FROM {$wpdb->prefix}terms t 
      INNER JOIN {$wpdb->prefix}term_taxonomy tt ON t.term_id = tt.term_id 
      WHERE tt.taxonomy = 'product_cat'
    " );
    if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) {
      foreach ( $categories as $cat ) {
        $targets[] = [
          'label' => '🍕 ' . $cat->name,
          'value' => 'app://category/' . $cat->term_id . '/' . rawurlencode( $cat->name ),
          'blog_id' => get_current_blog_id(),
        ];
      }
    }
    
    $products = $wpdb->get_results( "
      SELECT p.ID, p.post_title, 
             (SELECT tr.term_taxonomy_id 
              FROM {$wpdb->prefix}term_relationships tr 
              INNER JOIN {$wpdb->prefix}term_taxonomy tt ON tr.term_taxonomy_id = tt.term_taxonomy_id 
              WHERE tr.object_id = p.ID AND tt.taxonomy = 'product_cat' 
              LIMIT 1) as cat_id
      FROM {$wpdb->prefix}posts p
      WHERE p.post_type = 'product' AND p.post_status = 'publish'
    " );
    if ( ! empty( $products ) && ! is_wp_error( $products ) ) {
      foreach ( $products as $prod ) {
        $cat_id = $prod->cat_id ? (int) $prod->cat_id : 0;
        $targets[] = [
          'label' => '🍔 ' . $prod->post_title,
          'value' => 'app://product/' . $cat_id . '/' . rawurlencode( $prod->post_title ),
          'blog_id' => get_current_blog_id(),
        ];
      }
    }
  }

  set_site_transient( 'ard_all_search_targets_v5', $targets, 12 * HOUR_IN_SECONDS );
  return $targets;
}

function ARD_showContent_slides() {
  // Handle form submission
  if ( isset( $_POST['ard_slides_nonce'] ) && wp_verify_nonce( $_POST['ard_slides_nonce'], 'ard_save_slides' ) ) {
    $urls = isset( $_POST['app_slide_urls'] ) ? (array) $_POST['app_slide_urls'] : array();
    $titles = isset( $_POST['app_slide_titles'] ) ? stripslashes_deep( (array) $_POST['app_slide_titles'] ) : array();
    $links = isset( $_POST['app_slide_links'] ) ? stripslashes_deep( (array) $_POST['app_slide_links'] ) : array();
    $site_ids = isset( $_POST['app_slide_site_ids'] ) ? (array) $_POST['app_slide_site_ids'] : array();
    $raw = array();
    foreach ( $urls as $i => $url ) {
      $raw[] = array(
        'url'   => $url,
        'title' => isset( $titles[ $i ] ) ? $titles[ $i ] : '',
        'link'  => isset( $links[ $i ] ) ? sanitize_text_field( $links[ $i ] ) : '',
        'site_id' => isset( $site_ids[ $i ] ) ? (int) $site_ids[ $i ] : 0,
      );
    }
    $slides = ARD_sanitize_slides( $raw );
    update_option( 'app_slides', $slides );
    ARD_sync_slides_to_firestore();
    echo '<div class="notice notice-success"><p>Slides salvate e sincronizzate!</p></div>';
  }

  $slides = get_option( 'app_slides', array() );
  // Migrate legacy format (plain URL strings) to new format
  foreach ( $slides as &$slide ) {
    if ( is_string( $slide ) ) {
      $slide = array( 'url' => $slide, 'title' => '', 'link' => '', 'site_id' => 0 );
    }
    if ( ! isset( $slide['link'] ) ) {
      $slide['link'] = '';
    }
    if ( ! isset( $slide['site_id'] ) ) {
      $slide['site_id'] = 0;
    }
  }
  unset( $slide );
  $sites_list = ARD_wc_get_sites_list();
  if ( is_multisite() ) {
    $linked_sites = (array) get_option( 'wc_schedule_linked_sites', array() );
    if ( empty( $linked_sites ) ) {
      $linked_sites = array( get_current_blog_id() );
    }
    $linked_sites_ints = array_map( 'intval', $linked_sites );
    $filtered_sites = array();
    foreach ( $sites_list as $sid => $label ) {
      if ( in_array( (int) $sid, $linked_sites_ints, true ) ) {
        $filtered_sites[$sid] = $label;
      }
    }
    $sites_list = $filtered_sites;
  }
  ?>
  <div class="wrap">
    <h1>Slides Home Page App</h1>
    <p class="description">
      Gestisci le immagini dello slider nella home page dell'app mobile. Massimo <strong>5 slides</strong>.<br/>
      💡 Puoi inserire link personalizzati digitandoli direttamente nel campo (es. <code>app://category/ID</code> per una categoria, o <code>app://product/ID/NomeProdotto</code> per evidenziare un prodotto specifico).
    </p>

    <style>
      .ard-slides-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px; margin: 20px 0; }
      .ard-slide-card { position: relative; background: #fff; border: 2px solid #ddd; border-radius: 12px; transition: all 0.2s; }
      .ard-slide-card:hover { border-color: #2e7d32; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
      .ard-slide-card img { width: 100%; height: 180px; object-fit: cover; display: block; border-top-left-radius: 10px; border-top-right-radius: 10px; }
      .ard-slide-card .ard-slide-fields { padding: 10px; background: #fff; }
      .ard-slide-card .ard-slide-fields input[type="text"] { width: 100%; padding: 6px 10px; border: 1px solid #ddd; border-radius: 6px; font-size: 13px; }
      .ard-slide-card .ard-slide-actions { padding: 10px; display: flex; justify-content: space-between; align-items: center; background: #f9f9f9; border-bottom-left-radius: 10px; border-bottom-right-radius: 10px; }
      .ard-slide-remove { background: #f44336; color: #fff; border: none; padding: 6px 14px; border-radius: 6px; cursor: pointer; font-size: 13px; }
      .ard-slide-remove:hover { background: #d32f2f; }
      .ard-slide-order { font-weight: 600; color: #666; font-size: 14px; }
      .ard-add-slide { display: flex; align-items: center; justify-content: center; min-height: 260px; border: 2px dashed #ccc; border-radius: 12px; cursor: pointer; transition: all 0.2s; background: #fafafa; }
      .ard-add-slide:hover { border-color: #2e7d32; background: #f0f8f0; }
      .ard-add-slide span { font-size: 48px; color: #999; }
      .ard-submit-bar { margin-top: 20px; padding: 15px; background: #f5f5f5; border-radius: 8px; display: flex; gap: 10px; align-items: center; }

      .ard-link-autocomplete { position: relative; width: 100%; }
      .ard-link-dropdown {
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background: #fff;
        border: 1px solid #ddd;
        border-top: none;
        border-radius: 0 0 6px 6px;
        max-height: 200px;
        overflow-y: auto;
        z-index: 1000;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        display: none;
      }
      .ard-link-dropdown.active { display: block; }
      .ard-link-option {
        padding: 8px 12px;
        cursor: pointer;
        font-size: 13px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        transition: background 0.15s;
        gap: 12px;
      }
      .ard-link-option:hover { background: #e3f2fd; }
      .ard-link-option .ard-link-label { font-weight: 500; white-space: nowrap; }
      .ard-link-option .ard-link-value { color: #999; font-size: 11px; text-align: right; word-break: break-all; max-width: 140px; display: block; }
      .ard-link-clear {
        position: absolute;
        right: 8px;
        top: 50%;
        transform: translateY(-50%);
        background: none;
        border: none;
        cursor: pointer;
        font-size: 16px;
        color: #999;
        padding: 2px 6px;
        border-radius: 50%;
        line-height: 1;
      }
      .ard-link-clear:hover { background: #f0f0f0; color: #333; }
    </style>

    <form method="post" id="ard-slides-form">
      <?php wp_nonce_field( 'ard_save_slides', 'ard_slides_nonce' ); ?>

      <div class="ard-slides-grid" id="ard-slides-container">
        <?php foreach ( $slides as $i => $slide ) :
          $url = is_array( $slide ) ? $slide['url'] : $slide;
          $title = is_array( $slide ) && isset( $slide['title'] ) ? $slide['title'] : '';
          $link = is_array( $slide ) && isset( $slide['link'] ) ? $slide['link'] : '';
          $site_id = is_array( $slide ) && isset( $slide['site_id'] ) ? (int) $slide['site_id'] : 0;
          // Map link to display label
          $link_display = '';
          if ( $link ) {
            $link_labels = array(
              'app://home' => '🏠 Home',
              'app://cart' => '🛒 Carrello',
              'app://orders' => '📋 Ordini',
              'app://favorites' => '❤️ Favoriti',
              'app://about' => 'ℹ️ Chi Siamo',
              'app://account' => '👤 Il Mio Account',
              'app://addresses' => '📍 Indirizzi',
              'app://info' => '📄 Altre Info',
              'app://impressum' => '📜 Impressum',
            );
            if ( isset( $link_labels[ $link ] ) ) {
              $link_display = $link_labels[ $link ];
            } elseif ( preg_match( '#^app://category/\d+/(.+)$#', $link, $m ) ) {
              $link_display = '🍕 ' . urldecode( $m[1] );
            } elseif ( preg_match( '#^app://product/\d+/(.+)$#', $link, $m ) ) {
              $link_display = '🍔 ' . urldecode( $m[1] );
            } else {
              $link_display = $link;
            }
          }
        ?>
        <div class="ard-slide-card" data-index="<?php echo $i; ?>">
          <img src="<?php echo esc_url( $url ); ?>" alt="Slide <?php echo $i + 1; ?>" />
          <input type="hidden" name="app_slide_urls[]" value="<?php echo esc_url( $url ); ?>" />
          <div class="ard-slide-fields">
            <input type="text" name="app_slide_titles[]" value="<?php echo esc_attr( $title ); ?>" placeholder="Titolo slide (opzionale)" />
            
            <?php if ( is_multisite() ) : ?>
            <div style="margin-top:6px;">
              <select name="app_slide_site_ids[]" style="width:100%; padding:6px; border:1px solid #ddd; border-radius:6px; font-size:13px; height:32px;">
                <option value="0">🌍 Tutte le filiali (Generico)</option>
                <?php foreach ( $sites_list as $sid => $label ) : ?>
                  <option value="<?php echo (int)$sid; ?>" <?php selected( $site_id, (int)$sid ); ?>>
                    📍 <?php echo esc_html( $label ); ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </div>
            <?php else : ?>
            <input type="hidden" name="app_slide_site_ids[]" value="0" />
            <?php endif; ?>

            <div class="ard-link-autocomplete" style="margin-top:6px;">
              <input type="text" class="ard-slide-link-input" value="<?php echo esc_attr( $link_display ); ?>" placeholder="🔗 Link pagina app (opzionale)" autocomplete="off" data-link-value="<?php echo esc_attr( $link ); ?>" />
              <input type="hidden" name="app_slide_links[]" value="<?php echo esc_attr( $link ); ?>" />
              <?php if ( $link ) : ?>
              <button type="button" class="ard-link-clear" onclick="ARD_clearSlideLink(this)" title="Rimuovi link">&times;</button>
              <?php else : ?>
              <button type="button" class="ard-link-clear" style="display:none;" onclick="ARD_clearSlideLink(this)" title="Rimuovi link">&times;</button>
              <?php endif; ?>
              <div class="ard-link-dropdown"></div>
            </div>
          </div>
          <div class="ard-slide-actions">
            <span class="ard-slide-order">Slide #<?php echo $i + 1; ?></span>
            <button type="button" class="ard-slide-remove" onclick="this.closest('.ard-slide-card').remove(); ARD_updateSlideNumbers();">Rimuovi</button>
          </div>
        </div>
        <?php endforeach; ?>
        
        <?php if ( count( $slides ) < 5 ) : ?>
        <div class="ard-add-slide" id="ard-add-slide-btn" onclick="ARD_addSlide()">
          <span>＋</span>
        </div>
        <?php endif; ?>
      </div>

      <div class="ard-submit-bar">
        <button type="submit" class="button button-primary button-large">💾 Salva Slides</button>
        <span class="description">Le slides verranno sincronizzate automaticamente con l'app.</span>
      </div>
    </form>
  </div>

  <script>
  // Autocomplete suggestions (including categories & products from all subsites)
  var allPages = [
    { label: '🏠 Home', value: 'app://home' },
    { label: '🍕 Lista Categorie Prodotti', value: 'app://products' },
    { label: '🛒 Carrello', value: 'app://cart' },
    { label: '📋 Ordini', value: 'app://orders' },
    { label: '❤️ Favoriti', value: 'app://favorites' },
    { label: 'ℹ️ Chi Siamo', value: 'app://about' },
    { label: '👤 Il Mio Account', value: 'app://account' },
    { label: '📍 Indirizzi', value: 'app://addresses' },
    { label: '📄 Altre Info', value: 'app://info' },
    { label: '📜 Impressum', value: 'app://impressum' },
  ];
  
  var dbTargets = <?php echo wp_json_encode( ARD_get_all_search_targets() ); ?> || [];
  allPages = allPages.concat(dbTargets);

  function ARD_addSlide() {
    var container = document.getElementById('ard-slides-container');
    var cards = container.querySelectorAll('.ard-slide-card');
    if (cards.length >= 5) { alert('Massimo 5 slides!'); return; }

    var frame = wp.media({
      title: 'Seleziona immagine per la slide',
      multiple: false,
      library: { type: 'image' },
      button: { text: 'Usa questa immagine' }
    });

    frame.on('select', function() {
      var attachment = frame.state().get('selection').first().toJSON();
      var url = attachment.url;
      var idx = cards.length + 1;
      
      var siteDropdownHtml = '';
      <?php if ( is_multisite() ) : ?>
      siteDropdownHtml = 
        '<div style="margin-top:6px;">' +
          '<select name="app_slide_site_ids[]" style="width:100%; padding:6px; border:1px solid #ddd; border-radius:6px; font-size:13px; height:32px;">' +
            '<option value="0">\ud83c\udf0d Tutte le filiali (Generico)</option>' +
            <?php foreach ( $sites_list as $sid => $label ) : ?>
            '<option value="<?php echo (int)$sid; ?>">\ud83d\udccd <?php echo esc_js( esc_html( $label ) ); ?></option>' +
            <?php endforeach; ?>
          '</select>' +
        '</div>';
      <?php else : ?>
      siteDropdownHtml = '<input type="hidden" name="app_slide_site_ids[]" value="0" />';
      <?php endif; ?>

      var card = document.createElement('div');
      card.className = 'ard-slide-card';
      card.innerHTML =
        '<img src="' + url + '" alt="Slide ' + idx + '" />' +
        '<input type="hidden" name="app_slide_urls[]" value="' + url + '" />' +
        '<div class="ard-slide-fields">' +
          '<input type="text" name="app_slide_titles[]" value="" placeholder="Titolo slide (opzionale)" />' +
          siteDropdownHtml +
          '<div class="ard-link-autocomplete" style="margin-top:6px;">' +
            '<input type="text" class="ard-slide-link-input" value="" placeholder="\ud83d\udd17 Link pagina app (opzionale)" autocomplete="off" data-link-value="" />' +
            '<input type="hidden" name="app_slide_links[]" value="" />' +
            '<button type="button" class="ard-link-clear" style="display:none;" onclick="ARD_clearSlideLink(this)" title="Rimuovi link">&times;</button>' +
            '<div class="ard-link-dropdown"></div>' +
          '</div>' +
        '</div>' +
        '<div class="ard-slide-actions">' +
          '<span class="ard-slide-order">Slide #' + idx + '</span>' +
          '<button type="button" class="ard-slide-remove" onclick="this.closest(\'.ard-slide-card\').remove(); ARD_updateSlideNumbers();">Rimuovi</button>' +
        '</div>';
      
      var addBtn = document.getElementById('ard-add-slide-btn');
      container.insertBefore(card, addBtn);
      
      // Hide add button if 5 slides
      if (container.querySelectorAll('.ard-slide-card').length >= 5) {
        addBtn.style.display = 'none';
      }
      ARD_updateSlideNumbers();
    });

    frame.open();
  }

  function ARD_updateSlideNumbers() {
    var cards = document.querySelectorAll('.ard-slide-card');
    cards.forEach(function(card, i) {
      card.querySelector('.ard-slide-order').textContent = 'Slide #' + (i + 1);
    });
    var addBtn = document.getElementById('ard-add-slide-btn');
    if (addBtn) {
      addBtn.style.display = cards.length >= 5 ? 'none' : 'flex';
    }
  }

  // ── Slide link autocomplete (uses ARD_initLinkAutocomplete from notifications page if available) ──

  function ARD_clearSlideLink(btn) {
    var wrap = btn.closest('.ard-link-autocomplete');
    var input = wrap.querySelector('.ard-slide-link-input');
    var hidden = wrap.querySelector('input[type="hidden"]');
    if (input) { input.value = ''; input.dataset.linkValue = ''; }
    if (hidden) hidden.value = '';
    btn.style.display = 'none';
  }

  // Event delegation for slide link autocomplete dropdowns
  document.addEventListener('click', function(e) {
    // Handle dropdown option click
    var option = e.target.closest('.ard-slide-card .ard-link-option');
    if (option && option.dataset.value) {
      var wrap = option.closest('.ard-link-autocomplete');
      var input = wrap.querySelector('.ard-slide-link-input');
      var hidden = wrap.querySelector('input[type="hidden"]');
      var clearBtn = wrap.querySelector('.ard-link-clear');
      var dropdown = wrap.querySelector('.ard-link-dropdown');
      if (input) {
        input.value = option.querySelector('.ard-link-label').textContent;
        input.dataset.linkValue = option.dataset.value;
      }
      if (hidden) hidden.value = option.dataset.value;
      if (clearBtn) clearBtn.style.display = 'block';
      if (dropdown) dropdown.classList.remove('active');
      return;
    }
    // Close all slide dropdowns when clicking outside
    document.querySelectorAll('.ard-slide-card .ard-link-dropdown.active').forEach(function(dd) {
      if (!dd.closest('.ard-link-autocomplete').contains(e.target)) {
        dd.classList.remove('active');
      }
    });
  });

  // Render slide dropdown options
  function ARD_renderSlideDropdown(dropdown, filter, selectedSiteId) {
    const siteId = selectedSiteId ? parseInt(selectedSiteId) : CURRENT_BLOG_ID;

    window.ARD_getBranchPages(siteId, (pages) => {
      var q = (filter || '').toLowerCase();
      var matches = q ? pages.filter(function(p) { return p.label.toLowerCase().indexOf(q) >= 0 || p.value.toLowerCase().indexOf(q) >= 0; }) : pages;
      if (matches.length === 0) {
        dropdown.innerHTML = '<div class="ard-link-option" style="color:#999; cursor:default;">Nessun risultato</div>';
      } else {
        dropdown.innerHTML = matches.map(function(p) {
          return '<div class="ard-link-option" data-value="' + p.value + '">' +
            '<span class="ard-link-label">' + p.label + '</span>' +
          '</div>';
        }).join('');
      }
      dropdown.classList.add('active');
    });
  }

  // Clear slide link on branch dropdown change to prevent wrong links
  document.addEventListener('change', function(e) {
    if (e.target && e.target.name === 'app_slide_site_ids[]') {
      var card = e.target.closest('.ard-slide-card');
      if (card) {
        var wrap = card.querySelector('.ard-link-autocomplete');
        if (wrap) {
          var input = wrap.querySelector('.ard-slide-link-input');
          var hidden = wrap.querySelector('input[type="hidden"]');
          var clearBtn = wrap.querySelector('.ard-link-clear');
          if (input) { input.value = ''; input.dataset.linkValue = ''; }
          if (hidden) hidden.value = '';
          if (clearBtn) clearBtn.style.display = 'none';
        }
      }
    }
  });

  // Event delegation for focus/input on slide link inputs
  document.addEventListener('focusin', function(e) {
    if (e.target.classList.contains('ard-slide-link-input')) {
      var wrap = e.target.closest('.ard-link-autocomplete');
      var card = e.target.closest('.ard-slide-card');
      var select = card.querySelector('select[name="app_slide_site_ids[]"]');
      var selectedSiteId = select ? parseInt(select.value) : 0;
      
      var dropdown = wrap.querySelector('.ard-link-dropdown');
      ARD_renderSlideDropdown(dropdown, e.target.value, selectedSiteId);
    }
  });
  document.addEventListener('input', function(e) {
    if (e.target.classList.contains('ard-slide-link-input')) {
      var wrap = e.target.closest('.ard-link-autocomplete');
      var card = e.target.closest('.ard-slide-card');
      var select = card.querySelector('select[name="app_slide_site_ids[]"]');
      var selectedSiteId = select ? parseInt(select.value) : 0;
      
      var dropdown = wrap.querySelector('.ard-link-dropdown');
      var hidden = wrap.querySelector('input[type="hidden"]');
      var clearBtn = wrap.querySelector('.ard-link-clear');
      
      var val = e.target.value.trim();
      if (val.startsWith('http://') || val.startsWith('https://') || val.startsWith('app://')) {
        if (hidden) hidden.value = val;
        e.target.dataset.linkValue = val;
      }
      if (clearBtn) clearBtn.style.display = val ? 'block' : 'none';
      ARD_renderSlideDropdown(dropdown, val, selectedSiteId);
    }
  });
  document.addEventListener('change', function(e) {
    if (e.target.classList.contains('ard-slide-link-input')) {
      var wrap = e.target.closest('.ard-link-autocomplete');
      var hidden = wrap.querySelector('input[type="hidden"]');
      var val = e.target.value.trim();
      if (val.startsWith('http://') || val.startsWith('https://') || val.startsWith('app://')) {
        if (hidden) hidden.value = val;
        e.target.dataset.linkValue = val;
      }
    }
  });
  </script>
  <?php
}

/**
 * Sync slides to Firestore via Cloud Functions.
 */
function ARD_sync_slides_to_firestore() {
  $fetch_url = get_option( 'fetch_url' );
  if ( empty( $fetch_url ) ) return;

  $slides = get_option( 'app_slides', array() );
  // Ensure slides are in the new {url, title, link, site_id} format for Firestore
  $formatted = array();
  foreach ( $slides as $slide ) {
    if ( is_string( $slide ) ) {
      $formatted[] = array( 'url' => $slide, 'title' => '', 'link' => '', 'site_id' => 0 );
    } elseif ( is_array( $slide ) ) {
      $formatted[] = array(
        'url'   => isset( $slide['url'] ) ? $slide['url'] : '',
        'title' => isset( $slide['title'] ) ? $slide['title'] : '',
        'link'  => isset( $slide['link'] ) ? $slide['link'] : '',
        'site_id' => isset( $slide['site_id'] ) ? (int) $slide['site_id'] : 0,
      );
    }
  }

  if ( ARD_config_api_secret() === '' ) {
    error_log( '[MobileAdmin] Slides sync skipped: ARD_CONFIG_API_SECRET not configured' );
    return;
  }

  $response = wp_remote_post( rtrim( $fetch_url, '/' ) . '/config/update', array(
    'body'    => wp_json_encode( array(
      'apiSecret' => ARD_config_api_secret(),
      'slides'    => $formatted,
    ) ),
    'headers' => array( 'Content-Type' => 'application/json' ),
    'timeout' => 15,
  ) );

  if ( is_wp_error( $response ) ) {
    error_log( '[MobileAdmin] Slides sync failed: ' . $response->get_error_message() );
  }
}


// ================================================================
// CATEGORY ICONS MANAGEMENT
// ================================================================

function ARD_register_category_icons_settings() {
  register_setting( 'ard-category-icons-group', 'app_category_icons', array(
    'type' => 'array',
    'default' => array(),
  ) );
}

/**
 * Get the URL base for bundled SVG category icons shipped with the plugin.
 */
function ARD_category_icons_url() {
  return plugin_dir_url( __FILE__ ) . 'category-icons/';
}

/**
 * Get the filesystem path for bundled SVG category icons.
 */
function ARD_category_icons_path() {
  return plugin_dir_path( __FILE__ ) . 'category-icons/';
}

/**
 * Get the path for custom uploaded category icons inside persistent WordPress uploads.
 */
function ARD_custom_category_icons_path() {
  $upload_dir = wp_upload_dir();
  return $upload_dir['basedir'] . '/category-icons/';
}

/**
 * Get the URL for custom uploaded category icons inside persistent WordPress uploads.
 */
function ARD_custom_category_icons_url() {
  $upload_dir = wp_upload_dir();
  return $upload_dir['baseurl'] . '/category-icons/';
}

/**
 * List all available SVG icon files (both bundled default ones and custom uploaded ones).
 */
function ARD_get_available_svg_icons() {
  $icons = array();

  // 1. Scan default icons bundled with the plugin: colorful/ (Fluent Emoji, MIT),
  //    then the line icons in category-icons/ and category-icons/food-icons/
  $default_dir = ARD_category_icons_path();
  $default_url = ARD_category_icons_url();
  if ( is_dir( $default_dir ) ) {
    foreach ( glob( $default_dir . 'colorful/*.svg' ) as $file ) {
      $basename = basename( $file, '.svg' );
      $icons[ $basename ] = array(
        'file'  => basename( $file ),
        'url'   => $default_url . 'colorful/' . basename( $file ),
        'group' => 'color',
      );
    }
    foreach ( glob( $default_dir . '*.svg' ) as $file ) {
      $basename = basename( $file, '.svg' );
      if ( isset( $icons[ $basename ] ) ) continue;
      $icons[ $basename ] = array(
        'file'  => basename( $file ),
        'url'   => $default_url . basename( $file ),
        'group' => 'line',
      );
    }
    if ( is_dir( $default_dir . 'food-icons/' ) ) {
      foreach ( glob( $default_dir . 'food-icons/*.svg' ) as $file ) {
        $basename = sanitize_title( basename( $file, '.svg' ) );
        if ( ! isset( $icons[ $basename ] ) ) {
          $icons[ $basename ] = array(
            'file'  => basename( $file ),
            'url'   => $default_url . 'food-icons/' . rawurlencode( basename( $file ) ),
            'group' => 'line',
          );
        }
      }
    }
  }

  // 2. Scan custom uploaded icons in wp-content/uploads/category-icons/
  $custom_dir = ARD_custom_category_icons_path();
  $custom_url = ARD_custom_category_icons_url();
  if ( is_dir( $custom_dir ) ) {
    foreach ( glob( $custom_dir . '*.svg' ) as $file ) {
      $basename = basename( $file, '.svg' );
      $icons[ $basename ] = array(
        'file'  => basename( $file ),
        'url'   => $custom_url . basename( $file ),
        'group' => 'custom',
      );
    }
  }

  // Grouped (custom, color, line), alphabetical within each group
  $rank = array( 'custom' => 0, 'color' => 1, 'line' => 2 );
  uksort( $icons, function( $a, $b ) use ( $icons, $rank ) {
    $ga = $rank[ $icons[ $a ]['group'] ];
    $gb = $rank[ $icons[ $b ]['group'] ];
    return $ga !== $gb ? $ga - $gb : strcmp( $a, $b );
  } );
  return $icons;
}

/**
 * Food sections of the icon library sidebar (accordion). Colorful icons not
 * listed here end up in "Altre icone a colori"; uploaded and line icons have
 * their own sections. Order = display order.
 */
function ARD_svg_icon_food_sections() {
  return array(
    'pizza' => array(
      'label' => '🍕 Pizza e forno',
      'icons' => array( 'pizza-intera', 'pizza-bianca-intera', 'pizza-trancio', 'calzone-farcito', 'pane', 'baguette', 'pane-arabo', 'cornetto', 'bagel', 'pretzel', 'formaggio' ),
    ),
    'burger' => array(
      'label' => '🍔 Burger e panini',
      'icons' => array( 'hamburger-classico', 'panino', 'hot-dog', 'bacon' ),
    ),
    'street' => array(
      'label' => '🌯 Kebab e street food',
      'icons' => array( 'piadina-kebab', 'falafel', 'burrito-avvolto', 'tacos-messicani', 'tamale', 'takeaway' ),
    ),
    'fritti' => array(
      'label' => '🍟 Fritti e snack',
      'icons' => array( 'patatine', 'gamberi-fritti', 'popcorn' ),
    ),
    'carne' => array(
      'label' => '🥩 Carne e pesce',
      'icons' => array( 'bistecca', 'carne-osso', 'pollo-coscia', 'pesce', 'uovo' ),
    ),
    'piatti' => array(
      'label' => '🍝 Primi e piatti caldi',
      'icons' => array( 'spaghetti', 'spezzatino', 'paella', 'curry', 'riso', 'fonduta', 'colazione' ),
    ),
    'asia' => array(
      'label' => '🍣 Cucina asiatica',
      'icons' => array( 'sushi-nigiri', 'ramen', 'bento', 'ravioli-cinesi' ),
    ),
    'verdure' => array(
      'label' => '🥗 Insalate e verdure',
      'icons' => array( 'insalata', 'verdure', 'broccoli', 'carota', 'pomodoro', 'avocado', 'peperoncino', 'aglio', 'cipolla', 'funghi', 'olive', 'mais', 'vegano' ),
    ),
    'frutta' => array(
      'label' => '🍓 Frutta',
      'icons' => array( 'anguria', 'mela', 'fragola', 'limone' ),
    ),
    'dolci' => array(
      'label' => '🍰 Dolci e gelati',
      'icons' => array( 'torta-compleanno', 'fetta-torta', 'cupcake-panna', 'crostata', 'ciambella', 'biscotto', 'cioccolato', 'caramelle', 'lecca-lecca', 'budino', 'miele', 'pancake', 'waffle', 'gelato-cono', 'gelato-coppa', 'granita' ),
    ),
    'bevande' => array(
      'label' => '🥤 Bevande',
      'icons' => array( 'acqua', 'bibita-cannuccia', 'succo', 'latte', 'caffe', 'te', 'bubble-tea' ),
    ),
    'alcolici' => array(
      'label' => '🍺 Birre, vini e cocktail',
      'icons' => array( 'birra', 'vino', 'spumante', 'cocktail', 'drink-tropicale' ),
    ),
    'menu' => array(
      'label' => '🏷️ Menu ed etichette',
      'icons' => array( 'menu-completo', 'posate', 'offerta', 'novita', 'piccante', 'bambini' ),
    ),
  );
}

/**
 * Icon library split into accordion sections:
 * array( key => array( 'label' => ..., 'icons' => array( slug => info ) ) ), empty sections removed.
 */
function ARD_svg_icon_sections( $svg_list ) {
  $food = ARD_svg_icon_food_sections();
  $sections = array( 'custom' => array( 'label' => '📤 Caricate da te', 'icons' => array() ) );
  $slug_to_section = array();
  foreach ( $food as $key => $def ) {
    $sections[ $key ] = array( 'label' => $def['label'], 'icons' => array() );
    foreach ( $def['icons'] as $slug ) {
      $slug_to_section[ $slug ] = $key;
    }
  }
  $sections['altre'] = array( 'label' => '✨ Altre icone a colori', 'icons' => array() );
  $sections['line']  = array( 'label' => '✏️ Icone a linea (stile vecchio)', 'icons' => array() );

  foreach ( $svg_list as $slug => $info ) {
    if ( $info['group'] === 'custom' ) {
      $key = 'custom';
    } elseif ( $info['group'] === 'line' ) {
      $key = 'line';
    } else {
      $key = isset( $slug_to_section[ $slug ] ) ? $slug_to_section[ $slug ] : 'altre';
    }
    $sections[ $key ]['icons'][ $slug ] = $info;
  }
  // Curated order inside the food sections
  foreach ( $food as $key => $def ) {
    $ordered = array();
    foreach ( $def['icons'] as $slug ) {
      if ( isset( $sections[ $key ]['icons'][ $slug ] ) ) {
        $ordered[ $slug ] = $sections[ $key ]['icons'][ $slug ];
      }
    }
    $sections[ $key ]['icons'] = $ordered;
  }
  return array_filter( $sections, function( $sec ) { return ! empty( $sec['icons'] ); } );
}

/**
 * Labels of the icon groups returned by ARD_get_available_svg_icons().
 */
function ARD_svg_icon_group_labels() {
  return array(
    'custom' => '📤 Caricate da te',
    'color'  => '🎨 A colori',
    'line'   => '✏️ A linea',
  );
}

/**
 * Detect the default/primary language code for a site (blog_id).
 */
function ARD_get_site_default_language( $blog_id ) {
  switch_to_blog( (int) $blog_id );
  $default_lang = '';

  // 1. WPML settings option
  $sitepress_settings = get_option( 'icl_sitepress_settings' );
  if ( is_array( $sitepress_settings ) && ! empty( $sitepress_settings['default_language'] ) ) {
    $default_lang = $sitepress_settings['default_language'];
  }

  // 2. WPML filter
  if ( empty( $default_lang ) && function_exists( 'apply_filters' ) ) {
    $wpml_default = apply_filters( 'wpml_default_language', null );
    if ( ! empty( $wpml_default ) && is_string( $wpml_default ) ) {
      $default_lang = $wpml_default;
    }
  }

  // 3. Polylang
  if ( empty( $default_lang ) && function_exists( 'pll_default_language' ) ) {
    $pll_lang = pll_default_language( 'slug' );
    if ( ! empty( $pll_lang ) ) {
      $default_lang = $pll_lang;
    }
  }

  // 4. WordPress locale (e.g. 'it_IT' -> 'it')
  if ( empty( $default_lang ) ) {
    $locale = get_locale();
    if ( ! empty( $locale ) ) {
      $parts = explode( '_', $locale );
      $default_lang = strtolower( $parts[0] );
    }
  }

  restore_current_blog();
  return $default_lang ? strtolower( trim( $default_lang ) ) : 'it';
}

/**
 * Get map of category translations for a site.
 * Returns array where each category name maps to an array of its translated names in other languages.
 * E.g.: [ 'Pizze Classiche Normali' => [ 'Classic Normal Pizzas', 'Klassische Normale Pizzen' ], ... ]
 */
function ARD_get_category_translations( $blog_id ) {
  global $wpdb;
  switch_to_blog( (int) $blog_id );
  
  $prefix = $wpdb->prefix;
  $wpml_table = $prefix . 'icl_translations';
  $trans_map = array();

  // 1. WPML
  if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $wpml_table ) ) === $wpml_table ) {
    $rows = $wpdb->get_results(
      "SELECT icl.trid, t.name, icl.language_code
       FROM {$wpml_table} AS icl
       INNER JOIN {$prefix}term_taxonomy AS tt ON (icl.element_id = tt.term_taxonomy_id OR icl.element_id = tt.term_id)
       INNER JOIN {$prefix}terms AS t ON tt.term_id = t.term_id
       WHERE icl.element_type = 'tax_product_cat'
         AND tt.taxonomy = 'product_cat'"
    );

    if ( ! empty( $rows ) ) {
      $trid_groups = array();
      foreach ( $rows as $r ) {
        if ( ! empty( $r->trid ) && ! empty( $r->name ) ) {
          $trid_groups[ $r->trid ][] = $r->name;
        }
      }

      foreach ( $trid_groups as $trid => $names ) {
        $unique_names = array_values( array_unique( $names ) );
        if ( count( $unique_names ) > 1 ) {
          foreach ( $unique_names as $name ) {
            $others = array_values( array_diff( $unique_names, array( $name ) ) );
            $trans_map[ $name ] = $others;
          }
        }
      }
    }
  }

  // 2. Polylang (if WPML was empty and Polylang is available)
  if ( empty( $trans_map ) && function_exists( 'pll_get_term_translations' ) ) {
    $terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
    if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
      foreach ( $terms as $term ) {
        $translations = pll_get_term_translations( $term->term_id );
        if ( is_array( $translations ) && count( $translations ) > 1 ) {
          $trans_names = array();
          foreach ( $translations as $lang => $trans_id ) {
            if ( $trans_id !== $term->term_id ) {
              $t = get_term( $trans_id, 'product_cat' );
              if ( $t && ! is_wp_error( $t ) ) {
                $trans_names[] = $t->name;
              }
            }
          }
          if ( ! empty( $trans_names ) ) {
            $trans_map[ $term->name ] = $trans_names;
          }
        }
      }
    }
  }

  restore_current_blog();
  return $trans_map;
}

/**
 * Automatically propagate category icons to their translated names across languages.
 * If category "Pizze Classiche" has icon X, any translated counterparts
 * ("Classic Pizzas", "Klassische Pizzen") automatically receive the exact same icon
 * without requiring the user to configure each translation manually.
 */
function ARD_propagate_icons_to_translations( $icons ) {
  if ( ! is_array( $icons ) ) return $icons;

  foreach ( $icons as $blog_id => $site_icons ) {
    $blog_id = intval( $blog_id );
    if ( ! is_array( $site_icons ) || empty( $site_icons ) ) continue;

    $trans_map = ARD_get_category_translations( $blog_id );
    if ( empty( $trans_map ) ) continue;

    foreach ( $site_icons as $cat_name => $data ) {
      if ( empty( $data ) || ! is_array( $data ) ) continue;
      if ( empty( $data['value'] ) ) continue;

      if ( isset( $trans_map[ $cat_name ] ) ) {
        foreach ( $trans_map[ $cat_name ] as $translated_name ) {
          // If the translated category has no icon set yet, or has an auto-propagated icon:
          if ( ! isset( $site_icons[ $translated_name ] ) || empty( $site_icons[ $translated_name ]['value'] ) || ! empty( $site_icons[ $translated_name ]['auto_i18n'] ) ) {
            $site_icons[ $translated_name ] = array(
              'type'       => isset( $data['type'] ) ? $data['type'] : 'emoji',
              'value'      => $data['value'],
              'equivalent' => isset( $data['equivalent'] ) ? $data['equivalent'] : '',
              // Same position as the source category: the app shows one
              // language at a time, so the sequence stays identical.
              'order'      => isset( $data['order'] ) ? (int) $data['order'] : 999,
              'auto_i18n'  => true,
            );
          }
        }
      }
    }

    $icons[ $blog_id ] = $site_icons;
  }

  return $icons;
}

/**
 * Fetch WooCommerce product categories for a specific site (blog_id).
 * Automatically filters to only return categories in the site's default/primary language
 * so multilingual sites (WPML/Polylang) don't load duplicate categories for every language.
 * Uses direct DB query because switch_to_blog() doesn't re-register
 * WooCommerce taxonomies, so get_terms('product_cat') fails.
 * Returns an array of objects with properties: term_id, name, slug.
 */
function ARD_get_categories_for_site( $blog_id ) {
  global $wpdb;
  switch_to_blog( (int) $blog_id );
  
  $prefix = $wpdb->prefix; // This updates after switch_to_blog()
  $default_lang = ARD_get_site_default_language( $blog_id );
  $wpml_table = $prefix . 'icl_translations';
  $has_wpml = ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $wpml_table ) ) === $wpml_table );

  $results = array();

  if ( $has_wpml ) {
    // In WPML: query categories in the site's default language
    if ( $default_lang ) {
      $results = $wpdb->get_results(
        $wpdb->prepare(
          "SELECT t.term_id, t.name, t.slug, tt.count
           FROM {$prefix}terms AS t
           INNER JOIN {$prefix}term_taxonomy AS tt ON t.term_id = tt.term_id
           INNER JOIN {$wpml_table} AS icl ON (icl.element_id = tt.term_taxonomy_id OR icl.element_id = t.term_id)
           WHERE tt.taxonomy = 'product_cat'
             AND icl.element_type = 'tax_product_cat'
             AND t.slug != 'uncategorized'
             AND tt.count > 0
             AND icl.language_code = %s
           GROUP BY t.term_id
           ORDER BY t.name ASC",
          $default_lang
        )
      );
    }
    
    // Fallback if empty: original/base language terms (source_language_code is null/empty)
    if ( empty( $results ) ) {
      $results = $wpdb->get_results(
        "SELECT t.term_id, t.name, t.slug, tt.count
         FROM {$prefix}terms AS t
         INNER JOIN {$prefix}term_taxonomy AS tt ON t.term_id = tt.term_id
         INNER JOIN {$wpml_table} AS icl ON (icl.element_id = tt.term_taxonomy_id OR icl.element_id = t.term_id)
         WHERE tt.taxonomy = 'product_cat'
           AND icl.element_type = 'tax_product_cat'
           AND t.slug != 'uncategorized'
           AND tt.count > 0
           AND (icl.source_language_code IS NULL OR icl.source_language_code = '')
         GROUP BY t.term_id
         ORDER BY t.name ASC"
      );
    }
  } else {
    // Check Polylang
    $has_pll = taxonomy_exists( 'language' );
    if ( $has_pll && $default_lang ) {
      $results = $wpdb->get_results(
        $wpdb->prepare(
          "SELECT t.term_id, t.name, t.slug, tt.count
           FROM {$prefix}terms AS t
           INNER JOIN {$prefix}term_taxonomy AS tt ON t.term_id = tt.term_id
           INNER JOIN {$prefix}term_relationships AS tr ON tr.object_id = tt.term_taxonomy_id
           INNER JOIN {$prefix}term_taxonomy AS tt_lang ON tr.term_taxonomy_id = tt_lang.term_taxonomy_id
           INNER JOIN {$prefix}terms AS t_lang ON tt_lang.term_id = t_lang.term_id
           WHERE tt.taxonomy = 'product_cat'
             AND tt_lang.taxonomy = 'language'
             AND (t_lang.slug = %s OR t_lang.name = %s)
             AND t.slug != 'uncategorized'
             AND tt.count > 0
           GROUP BY t.term_id
           ORDER BY t.name ASC",
          $default_lang,
          $default_lang
        )
      );
    }
  }

  // Safety fallback: if language filtering yielded empty results, return all categories
  if ( empty( $results ) ) {
    $results = $wpdb->get_results(
      "SELECT t.term_id, t.name, t.slug, tt.count
       FROM {$prefix}terms AS t
       INNER JOIN {$prefix}term_taxonomy AS tt ON t.term_id = tt.term_id
       WHERE tt.taxonomy = 'product_cat'
         AND t.slug != 'uncategorized'
         AND tt.count > 0
       ORDER BY t.name ASC"
    );
  }
  
  restore_current_blog();
  return is_array( $results ) ? $results : array();
}

/**
 * Get linked sites from the option (same logic used elsewhere in the plugin).
 */
function ARD_get_linked_sites_for_icons() {
  // The option is stored on the current blog (the admin hub, e.g. blog 8 for mrjoecity.ch)
  $linked = (array) get_option( 'wc_schedule_linked_sites', array() );
  if ( empty( $linked ) ) {
    $linked = array( get_current_blog_id() );
  }
  $linked = array_values( array_map( 'intval', $linked ) );

  // Explicitly exclude the main management hub (blog 8) if multisite is active
  if ( is_multisite() ) {
    $linked = array_filter( $linked, function( $id ) {
      return intval( $id ) !== 8;
    } );
  }
  $linked = array_values( $linked );

  // Filter: only keep sites that have WooCommerce product categories with products
  $filtered = array();
  foreach ( $linked as $bid ) {
    $cats = ARD_get_categories_for_site( $bid );
    if ( ! empty( $cats ) ) {
      $filtered[] = $bid;
    }
  }
  return $filtered;
}

/**
 * Migrate old flat icon format to new per-site structure.
 * Old: { "Category Name": "🍕" }
 * New: { blog_id: { "Category Name": { "type": "emoji", "value": "🍕" } } }
 */
/**
 * Give an explicit 'order' index to entries saved before ordering was stored.
 * The WordPress option keeps the drag&drop order as array key order, so that
 * order is what gets frozen into the numeric index.
 */
function ARD_backfill_icons_order( $icons ) {
  foreach ( $icons as $blog_id => $site_icons ) {
    if ( ! is_array( $site_icons ) ) continue;
    $position = 0;
    foreach ( $site_icons as $name => $data ) {
      if ( is_array( $data ) && ! isset( $data['order'] ) ) {
        $site_icons[ $name ]['order'] = $position;
      }
      $position++;
    }
    $icons[ $blog_id ] = $site_icons;
  }
  return $icons;
}

/**
 * Re-link icon rows to WooCommerce categories that were renamed.
 *
 * Rows are keyed by category NAME (that is what the app matches on). When a
 * category is renamed in WooCommerce (e.g. "Pizze Classiche Normali" →
 * "Pizze Normali") its slug usually stays the same, so a saved row whose name
 * no longer exists but whose sanitized name equals a current category slug is
 * moved to the current name, keeping icon and order. It replaces an
 * auto-propagated (auto_i18n) entry for that name, never a real row.
 * Every row matching a current category also gets its `term_id`.
 *
 * @return array{0: array, 1: bool} Healed icons and whether anything was renamed.
 */
function ARD_heal_renamed_category_icons( $icons ) {
  $changed = false;
  if ( ! is_array( $icons ) ) return array( $icons, $changed );

  foreach ( $icons as $blog_id => $site_icons ) {
    if ( ! is_numeric( $blog_id ) || ! is_array( $site_icons ) || empty( $site_icons ) ) continue;
    $cats = ARD_get_categories_for_site( (int) $blog_id );
    if ( empty( $cats ) || ! is_array( $cats ) ) continue;

    $by_name = array();
    $by_slug = array();
    foreach ( $cats as $c ) {
      $by_name[ $c->name ] = $c;
      $by_slug[ $c->slug ] = $c;
    }

    foreach ( array_keys( $site_icons ) as $name ) {
      $data = $site_icons[ $name ];
      if ( ! is_array( $data ) || ! empty( $data['auto_i18n'] ) ) continue;

      if ( isset( $by_name[ $name ] ) ) {
        $site_icons[ $name ]['term_id'] = (int) $by_name[ $name ]->term_id;
        continue;
      }
      $slug = sanitize_title( $name );
      if ( ! isset( $by_slug[ $slug ] ) ) continue; // orphan: shown with a warning in admin

      $current = $by_slug[ $slug ]->name;
      if ( isset( $site_icons[ $current ] ) && empty( $site_icons[ $current ]['auto_i18n'] ) ) continue;

      $data['term_id'] = (int) $by_slug[ $slug ]->term_id;
      unset( $site_icons[ $name ] );
      $site_icons[ $current ] = $data;
      $by_name[ $current ] = $by_slug[ $slug ];
      $changed = true;
    }

    $icons[ $blog_id ] = ARD_sort_icons_by_order( $site_icons );
  }

  return array( $icons, $changed );
}

function ARD_maybe_migrate_category_icons( $icons ) {
  if ( empty( $icons ) || ! is_array( $icons ) ) return $icons;
  // Check if already in new format (keys are numeric blog IDs)
  $first_key = array_key_first( $icons );
  if ( is_numeric( $first_key ) && is_array( reset( $icons ) ) ) {
    // Check deeper: is it already { type, value } or still flat?
    $first_inner = reset( $icons );
    if ( ! empty( $first_inner ) ) {
      $inner_val = reset( $first_inner );
      if ( is_array( $inner_val ) && isset( $inner_val['type'] ) ) {
        return ARD_backfill_icons_order( $icons ); // Already in new format
      }
    }
  }
  // Old flat format detected — migrate all to current blog
  $migrated = array();
  $current_blog = get_current_blog_id();
  $linked = ARD_get_linked_sites_for_icons();
  $target_blog = in_array( $current_blog, $linked ) ? $current_blog : ( ! empty( $linked ) ? $linked[0] : $current_blog );
  
  foreach ( $icons as $name => $value ) {
    if ( is_string( $value ) ) {
      $migrated[ $target_blog ][ $name ] = array( 'type' => 'emoji', 'value' => $value );
    }
  }
  return $migrated;
}

/**
 * Sort a site's icon entries by their saved 'order' index (drag&drop order).
 * Entries without an order keep their relative position at the end.
 */
function ARD_sort_icons_by_order( $site_icons ) {
  if ( ! is_array( $site_icons ) || empty( $site_icons ) ) return $site_icons;
  $i = 0;
  $indexed = array();
  foreach ( $site_icons as $name => $data ) {
    $indexed[] = array(
      'name'     => $name,
      'data'     => $data,
      'order'    => isset( $data['order'] ) ? (int) $data['order'] : PHP_INT_MAX,
      'fallback' => $i++,
    );
  }
  usort( $indexed, function( $a, $b ) {
    if ( $a['order'] !== $b['order'] ) return $a['order'] - $b['order'];
    return $a['fallback'] - $b['fallback'];
  } );
  $sorted = array();
  foreach ( $indexed as $row ) {
    $sorted[ $row['name'] ] = $row['data'];
  }
  return $sorted;
}

/**
 * Display the Category Icons admin page with per-site tabs and SVG support.
 */
function ARD_showContent_category_icons() {
  // Handle SVG deletion
  if ( isset( $_GET['action'] ) && $_GET['action'] === 'delete_svg' && isset( $_GET['svg'] ) && isset( $_GET['_wpnonce'] ) ) {
    $svg_slug = sanitize_text_field( wp_unslash( $_GET['svg'] ) );
    if ( wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'ard_delete_svg_' . $svg_slug ) ) {
      $svg_name = sanitize_file_name( $svg_slug ) . '.svg';
      $custom_path = ARD_custom_category_icons_path() . $svg_name;

      // Only uploaded icons can be deleted: bundled ones are plugin files and
      // would be restored by the next update.
      $deleted = false;
      if ( current_user_can( 'manage_options' ) && file_exists( $custom_path ) ) {
        unlink( $custom_path );
        $deleted = true;
      }
      
      if ( $deleted ) {
        wp_safe_redirect( remove_query_arg( array( 'action', 'svg', '_wpnonce' ) ) );
        exit;
      }
    }
  }

  // Handle form submission
  if ( isset( $_POST['ard_icons_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ard_icons_nonce'] ) ), 'ard_save_icons' ) ) {
    $icons = array();
    if ( isset( $_POST['ard_site_icons'] ) && is_array( $_POST['ard_site_icons'] ) ) {
      foreach ( $_POST['ard_site_icons'] as $blog_id => $site_icons ) {
        $blog_id = intval( $blog_id );
        if ( ! is_array( $site_icons ) ) continue;
        // Row order in the POST array is the drag&drop order: persist it as an
        // explicit numeric index, because Firestore maps don't keep key order.
        $position = 0;
        foreach ( $site_icons as $entry ) {
          $name  = isset( $entry['name'] )  ? sanitize_text_field( $entry['name'] )  : '';
          $type  = isset( $entry['type'] )  ? sanitize_text_field( $entry['type'] )  : 'emoji';
          $value = isset( $entry['value'] ) ? sanitize_text_field( $entry['value'] ) : '';
          if ( $type === 'svg' ) {
            $value = esc_url_raw( $value );
          }
          $equivalent = isset( $entry['equivalent'] ) ? sanitize_text_field( $entry['equivalent'] ) : '';
          if ( $name && $value ) {
            $icons[ $blog_id ][ $name ] = array(
              'type' => $type,
              'value' => $value,
              'equivalent' => $equivalent,
              'order' => $position
            );
            $position++;
          }
        }
      }
    }
    $icons = ARD_propagate_icons_to_translations( $icons );
    update_option( 'app_category_icons', $icons );
    ARD_sync_category_icons_to_firestore();
    echo '<div class="notice notice-success"><p>✅ Icone categorie salvate e sincronizzate (con propagazione automatica alle altre lingue)!</p></div>';
  }

  // Handle SVG upload via AJAX-style inline upload
  if ( isset( $_POST['ard_upload_svg_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ard_upload_svg_nonce'] ) ), 'ard_upload_svg' ) ) {
    if ( ! empty( $_FILES['ard_svg_file']['name'] ) ) {
      $upload_dir = ARD_custom_category_icons_path();
      if ( ! is_dir( $upload_dir ) ) {
        wp_mkdir_p( $upload_dir );
      }
      $filename = sanitize_file_name( $_FILES['ard_svg_file']['name'] );
      if ( strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) ) === 'svg' ) {
        $target = $upload_dir . $filename;
        if ( move_uploaded_file( $_FILES['ard_svg_file']['tmp_name'], $target ) ) {
          echo '<div class="notice notice-success"><p>✅ SVG caricato: ' . esc_html( $filename ) . '</p></div>';
        } else {
          echo '<div class="notice notice-error"><p>❌ Errore nel caricamento del file SVG.</p></div>';
        }
      } else {
        echo '<div class="notice notice-error"><p>❌ Solo file .svg sono accettati.</p></div>';
      }
    }
  }

  $icons    = get_option( 'app_category_icons', array() );
  $icons    = ARD_maybe_migrate_category_icons( $icons );
  list( $icons, $ard_healed ) = ARD_heal_renamed_category_icons( $icons );
  if ( $ard_healed ) {
    update_option( 'app_category_icons', $icons );
    ARD_sync_category_icons_to_firestore();
    echo '<div class="notice notice-info is-dismissible"><p>🔗 Alcune categorie erano state rinominate in WooCommerce: le loro icone e posizioni sono state ricollegate al nome attuale e sincronizzate con l\'app.</p></div>';
  }
  $linked   = ARD_get_linked_sites_for_icons();
  $svg_list = ARD_get_available_svg_icons();
  ?>
  <div class="wrap">
    <h1>🎨 Icone Categorie App</h1>
    <p class="description">Configura le icone (emoji o SVG) per ogni categoria di prodotti nell'app mobile. Le categorie vengono caricate dinamicamente da WooCommerce per ogni sito collegato.</p>

    <style>
      .ard-icons-wrap { max-width: 900px; margin: 20px 0; }
      .ard-site-tabs { display: flex; gap: 0; border-bottom: 2px solid #0073aa; margin-bottom: 0; }
      .ard-site-tab { padding: 10px 20px; background: #f1f1f1; border: 1px solid #ccc; border-bottom: none; border-radius: 6px 6px 0 0; cursor: pointer; font-weight: 600; font-size: 13px; color: #555; transition: all .2s; }
      .ard-site-tab:hover { background: #e0e0e0; }
      .ard-site-tab.active { background: #fff; color: #0073aa; border-color: #0073aa; border-bottom: 2px solid #fff; margin-bottom: -2px; }
      .ard-site-panel { display: none; background: #fff; border: 1px solid #0073aa; border-top: none; padding: 20px; border-radius: 0 0 8px 8px; }
      .ard-site-panel.active { display: block; }
      .ard-icons-table { width: 100%; border-collapse: collapse; }
      .ard-icons-table th { background: #f8f9fa; font-weight: 600; font-size: 12px; color: #666; text-transform: uppercase; letter-spacing: 0.5px; padding: 10px 12px; text-align: left; border-bottom: 2px solid #eee; }
      .ard-icons-table td { padding: 10px 12px; border-bottom: 1px solid #f0f0f0; vertical-align: middle; }
      .ard-icons-table tr:hover { background: #f9fbfd; }
      .ard-icon-preview { display: inline-flex; align-items: center; justify-content: center; width: 40px; height: 40px; border-radius: 8px; background: #f5f5f5; }
      .ard-icon-preview img { width: 28px; height: 28px; }
      .ard-icon-preview .emoji-preview { font-size: 24px; line-height: 1; }
      .ard-name-input { padding: 6px 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 13px; width: 200px; }
      .ard-type-select { padding: 6px 8px; border: 1px solid #ddd; border-radius: 4px; font-size: 13px; }
      .ard-value-input { padding: 6px 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 13px; width: 120px; }
      .ard-svg-select { padding: 6px 8px; border: 1px solid #ddd; border-radius: 4px; font-size: 13px; max-width: 200px; }
      .ard-remove-row { background: #dc3545; color: #fff; border: none; padding: 4px 10px; border-radius: 4px; cursor: pointer; font-size: 11px; }
      .ard-remove-row:hover { background: #c82333; }
      .ard-drag-handle { cursor: grab; font-size: 18px; color: #aaa; user-select: none; text-align: center; padding: 0 4px; }
      .ard-drag-handle:hover { color: #666; }
      .ard-drag-handle:active { cursor: grabbing; }
      tr.ard-dragging { opacity: 0.4; background: #e8f0fe; }
      tr.ard-drag-over { border-top: 2px solid #0073aa; }
      .ard-orphan-badge { display: inline-block; margin-top: 4px; padding: 1px 8px; background: #fcf0f1; color: #b32d2e; border: 1px solid #f5c2c7; border-radius: 10px; font-size: 11px; font-weight: 600; }
      .ard-icons-layout { display: grid; grid-template-columns: minmax(0, 1fr) 380px; gap: 24px; align-items: start; margin-top: 16px; }
      .ard-icons-layout .ard-icons-wrap { max-width: none; margin-top: 0; }
      .ard-icons-sidebar { position: sticky; top: 46px; max-height: calc(100vh - 62px); display: flex; flex-direction: column; background: #fff; border: 1px solid #dcdcde; border-radius: 12px; box-shadow: 0 4px 16px rgba(0,0,0,.06); overflow: hidden; }
      .ard-lib-head { padding: 14px 16px 10px; border-bottom: 1px solid #f0f0f1; }
      .ard-lib-head h2 { margin: 0 0 4px; font-size: 15px; }
      .ard-library-hint { margin: 0 0 10px; font-size: 12px; color: #646970; }
      #ard-icon-search { width: 100%; padding: 7px 12px; border: 1px solid #ccd0d4; border-radius: 20px; font-size: 13px; }
      .ard-lib-tools { display: flex; gap: 6px; margin-top: 8px; }
      .ard-lib-tool { background: none; border: 0; padding: 2px 4px; color: #2271b1; font-size: 12px; cursor: pointer; text-decoration: underline; }
      .ard-lib-body { flex: 1 1 auto; overflow-y: auto; padding: 6px 10px 10px; overscroll-behavior: contain; }
      .ard-lib-section { border-bottom: 1px solid #f0f0f1; }
      .ard-lib-section:last-of-type { border-bottom: 0; }
      .ard-lib-section > summary { display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 10px 6px; cursor: pointer; font-weight: 600; font-size: 13px; color: #1d2327; list-style: none; border-radius: 6px; }
      .ard-lib-section > summary::-webkit-details-marker { display: none; }
      .ard-lib-section > summary::after { content: '▸'; color: #8c8f94; transition: transform .15s ease; margin-left: 4px; }
      .ard-lib-section[open] > summary::after { transform: rotate(90deg); }
      .ard-lib-section > summary:hover { background: #f6f7f7; }
      .ard-lib-title { flex: 1; }
      .ard-lib-count { background: #f0f0f1; color: #50575e; border-radius: 10px; padding: 1px 8px; font-size: 11px; font-weight: 600; }
      .ard-lib-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(76px, 1fr)); gap: 6px; padding: 4px 2px 12px; }
      .ard-icon-chip { position: relative; display: flex; flex-direction: column; align-items: center; gap: 4px; padding: 8px 4px 6px; background: #fff; border-radius: 10px; border: 1px solid #eee; cursor: grab; user-select: none; transition: transform .12s ease, box-shadow .12s ease, border-color .12s ease; }
      .ard-icon-chip img { width: 32px; height: 32px; pointer-events: none; }
      .ard-chip-name { font-size: 10.5px; line-height: 1.2; color: #50575e; max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
      .ard-chip-delete { position: absolute; top: 2px; right: 4px; color: #d63638; text-decoration: none; font-weight: 700; font-size: 14px; line-height: 1; }
      .ard-icon-chip:hover { border-color: #2271b1; box-shadow: 0 2px 8px rgba(34,113,177,.18); transform: translateY(-1px); }
      .ard-icon-chip:active { cursor: grabbing; }
      .ard-icon-chip:focus-visible { outline: 2px solid #2271b1; outline-offset: 2px; }
      .ard-icon-chip.ard-chip-selected { border-color: #2271b1; background: #e7f1fb; box-shadow: 0 0 0 2px #2271b1; }
      .ard-lib-empty { margin: 16px 6px; color: #646970; text-align: center; }
      .ard-lib-upload { border-top: 1px solid #f0f0f1; padding: 8px 16px; background: #f8f9fa; }
      .ard-lib-upload > summary { cursor: pointer; font-weight: 600; font-size: 13px; padding: 4px 0; }
      .ard-lib-upload form { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; margin-top: 8px; }
      @media (max-width: 1400px) {
        .ard-icons-layout { grid-template-columns: 1fr; }
        .ard-icons-sidebar { position: static; max-height: 520px; order: -1; }
      }
      .ard-icon-chip.ard-chip-dragging { opacity: .5; }
      .ard-icon-chip img { pointer-events: none; }
      body.ard-icon-dragging tr.ard-icon-target td, body.ard-assign-mode .ard-icons-table tbody tr:hover td { background: #e7f1fb !important; }
      body.ard-icon-dragging tr.ard-icon-target .ard-icon-preview, body.ard-assign-mode .ard-icons-table tbody tr:hover .ard-icon-preview { box-shadow: 0 0 0 2px #2271b1; background: #fff; }
      body.ard-assign-mode .ard-icons-table tbody tr { cursor: copy; }
      tr.ard-icon-assigned td { animation: ardAssigned 1.2s ease; }
      @keyframes ardAssigned { 0% { background: #d7f5dd; } 100% { background: transparent; } }
      #ard-unsaved-bar { position: fixed; left: 50%; bottom: 20px; transform: translateX(-50%) translateY(120px); z-index: 9999; display: flex; align-items: center; gap: 12px; padding: 10px 14px 10px 18px; background: #1d2327; color: #fff; border-radius: 30px; box-shadow: 0 8px 24px rgba(0,0,0,.25); font-size: 13px; transition: transform .3s ease; }
      #ard-unsaved-bar.ard-visible { transform: translateX(-50%) translateY(0); }
      #ard-unsaved-bar .button { border-radius: 20px; }
      .ard-btn-group { display: flex; gap: 8px; margin: 12px 0; }
      .ard-btn { padding: 8px 16px; border: none; border-radius: 6px; cursor: pointer; font-size: 13px; font-weight: 500; }
      .ard-btn-green { background: #28a745; color: #fff; }
      .ard-btn-green:hover { background: #218838; }
      .ard-btn-blue { background: #0073aa; color: #fff; }
      .ard-btn-blue:hover { background: #005a87; }
      .ard-submit-bar { margin-top: 20px; padding: 15px; background: #f5f5f5; border-radius: 8px; display: flex; gap: 12px; align-items: center; }
    </style>

    <!-- SVG Upload Box -->
    <div class="ard-icons-layout">
    <div class="ard-icons-main">
    <form method="post">
      <?php wp_nonce_field( 'ard_save_icons', 'ard_icons_nonce' ); ?>

      <div class="ard-icons-wrap">
        <!-- Site Tabs -->
        <div class="ard-site-tabs">
          <?php foreach ( $linked as $idx => $blog_id ) :
            switch_to_blog( $blog_id );
            $site_name = get_bloginfo( 'name' );
            restore_current_blog();
          ?>
            <div class="ard-site-tab <?php echo $idx === 0 ? 'active' : ''; ?>" onclick="ARD_switchTab(<?php echo (int) $blog_id; ?>)" data-site="<?php echo (int) $blog_id; ?>">
              <?php echo esc_html( $site_name ); ?>
            </div>
          <?php endforeach; ?>
        </div>

        <!-- Site Panels -->
        <?php foreach ( $linked as $idx => $blog_id ) :
          $blog_id    = intval( $blog_id );
          $site_icons = isset( $icons[ $blog_id ] ) ? $icons[ $blog_id ] : array();
          $site_icons = ARD_sort_icons_by_order( $site_icons );
          $wc_cats    = ARD_get_categories_for_site( $blog_id );
          switch_to_blog( $blog_id );
          $site_name  = get_bloginfo( 'name' );
          restore_current_blog();
        ?>
          <div class="ard-site-panel <?php echo $idx === 0 ? 'active' : ''; ?>" data-site="<?php echo $blog_id; ?>" id="ard-panel-<?php echo $blog_id; ?>">
            <table class="ard-icons-table">
              <thead>
                <tr>
                  <th style="width:30px;"></th>
                  <th style="width:60px;">Anteprima</th>
                  <th>Nome Categoria</th>
                  <th style="width:80px; text-align:center;">Prodotti</th>
                  <th style="width:140px;">Sito</th>
                  <th style="width:200px;">Equivalente</th>
                  <th style="width:100px;">Tipo</th>
                  <th>Valore / Icona</th>
                  <th style="width:50px;"></th>
                </tr>
              </thead>
              <tbody id="ard-tbody-<?php echo $blog_id; ?>">
                <?php
                // Only show saved/assigned icons — user controls what appears via 'Aggiungi categoria'
                if ( ! empty( $site_icons ) ) :
                $default_cat_names = array_map( function( $c ) { return $c->name; }, $wc_cats );
                $trans_map = ARD_get_category_translations( $blog_id );
                $cat_counts = array();
                foreach ( $wc_cats as $c ) {
                  $cat_counts[ $c->name ] = (int) $c->count;
                }

                foreach ( $site_icons as $cat_name => $saved ) :
                  // Skip auto-propagated translated rows so they don't clutter the admin UI
                  if ( ! empty( $saved['auto_i18n'] ) ) {
                    continue;
                  }
                  // Skip translated row if its default-language source already exists in site_icons
                  if ( ! empty( $trans_map[ $cat_name ] ) && ! in_array( $cat_name, $default_cat_names, true ) ) {
                    $has_default_sister = false;
                    foreach ( $trans_map[ $cat_name ] as $sister ) {
                      if ( in_array( $sister, $default_cat_names, true ) && isset( $site_icons[ $sister ] ) ) {
                        $has_default_sister = true;
                        break;
                      }
                    }
                    if ( $has_default_sister ) {
                      continue;
                    }
                  }
                  $prod_count = isset( $cat_counts[ $cat_name ] ) ? $cat_counts[ $cat_name ] : 0;
                  if ( $prod_count === 0 && ! empty( $trans_map[ $cat_name ] ) ) {
                    foreach ( $trans_map[ $cat_name ] as $sister ) {
                      if ( isset( $cat_counts[ $sister ] ) && $cat_counts[ $sister ] > 0 ) {
                        $prod_count = $cat_counts[ $sister ];
                        break;
                      }
                    }
                  }
                  $type  = isset( $saved['type'] )  ? $saved['type']  : 'emoji';
                  $value = isset( $saved['value'] ) ? $saved['value'] : '';
                  $eq    = isset( $saved['equivalent'] ) ? $saved['equivalent'] : '';
                ?>
                <tr draggable="true" ondragstart="ARD_dragStart(event)" ondragend="ARD_dragEnd(event)" ondragover="ARD_dragOver(event)" ondragleave="ARD_dragLeave(event)" ondrop="ARD_drop(event)">
                  <td class="ard-drag-handle" title="Trascina per riordinare">⠿</td>
                  <td>
                    <span class="ard-icon-preview">
                      <?php if ( ! empty( $eq ) ) : ?>
                        <span class="emoji-preview">🔗</span>
                      <?php elseif ( $type === 'svg' && $value ) : ?>
                        <img src="<?php echo esc_url( $value ); ?>" width="28" height="28" />
                      <?php elseif ( $value ) : ?>
                        <span class="emoji-preview"><?php echo esc_html( $value ); ?></span>
                      <?php else : ?>
                        <span class="emoji-preview">❓</span>
                      <?php endif; ?>
                    </span>
                  </td>
                  <td>
                    <input type="hidden" name="ard_site_icons[<?php echo $blog_id; ?>][<?php echo esc_attr( $cat_name ); ?>][name]" value="<?php echo esc_attr( $cat_name ); ?>" />
                    <strong><?php echo esc_html( $cat_name ); ?></strong>
                    <?php if ( ! in_array( $cat_name, $default_cat_names, true ) && empty( $trans_map[ $cat_name ] ) ) : ?>
                      <div class="ard-orphan-badge" title="Nessuna categoria WooCommerce con questo nome o slug (con prodotti) su questo sito. Nell'app non compare: puoi eliminare la riga.">⚠️ Categoria non trovata</div>
                    <?php endif; ?>
                  </td>
                  <td style="text-align:center;">
                    <span style="display:inline-block; min-width:24px; padding:2px 8px; background:#eef2f7; color:#334e68; border:1px solid #d0dbe5; border-radius:12px; font-weight:600; font-size:12px;" title="<?php echo esc_attr( $prod_count ); ?> prodotti in questa categoria">
                      <?php echo esc_html( $prod_count ); ?>
                    </span>
                  </td>
                  <td>
                    <span style="display:inline-block; padding:3px 8px; background:#e8f0fe; border-radius:4px; font-size:11px; color:#1a73e8; font-weight:500;"><?php echo esc_html( $site_name ); ?></span>
                  </td>
                  <td>
                    <select class="ard-eq-select" name="ard_site_icons[<?php echo $blog_id; ?>][<?php echo esc_attr( $cat_name ); ?>][equivalent]" onchange="ARD_toggleEquivalent(this)" style="width:100%; max-width:180px;">
                      <option value="">— Nessuna —</option>
                      <?php
                      foreach ( $linked as $other_bid ) {
                        if ( $other_bid === $blog_id ) continue;
                        switch_to_blog( $other_bid );
                        $other_site_name = get_bloginfo( 'name' );
                        restore_current_blog();
                        $other_cats = ARD_get_categories_for_site( $other_bid );
                        foreach ( $other_cats as $other_cat ) {
                          $opt_val = $other_bid . '|' . $other_cat->name;
                          echo '<option value="' . esc_attr( $opt_val ) . '" ' . selected( $eq, $opt_val, false ) . '>';
                          echo '[' . esc_html( $other_site_name ) . '] ' . esc_html( $other_cat->name );
                          echo '</option>';
                        }
                      }
                      ?>
                    </select>
                  </td>
                  <td>
                    <select class="ard-type-select" name="ard_site_icons[<?php echo $blog_id; ?>][<?php echo esc_attr( $cat_name ); ?>][type]" onchange="ARD_toggleValueInput(this)" style="<?php echo ! empty( $eq ) ? 'display:none;' : ''; ?>">
                      <option value="emoji" <?php selected( $type, 'emoji' ); ?>>🔤 Emoji</option>
                      <option value="svg" <?php selected( $type, 'svg' ); ?>>📁 SVG</option>
                    </select>
                  </td>
                  <td>
                    <span class="ard-emoji-field" style="<?php echo ($type === 'svg' || ! empty( $eq )) ? 'display:none;' : ''; ?>">
                      <input type="text" class="ard-value-input" name="ard_site_icons[<?php echo $blog_id; ?>][<?php echo esc_attr( $cat_name ); ?>][emoji_value]" value="<?php echo $type === 'emoji' ? esc_attr( $value ) : ''; ?>" placeholder="🍕" style="width:60px; text-align:center; font-size:20px;" />
                    </span>
                    <span class="ard-svg-field" style="<?php echo ($type === 'emoji' || ! empty( $eq )) ? 'display:none;' : ''; ?>">
                      <select class="ard-svg-select" name="ard_site_icons[<?php echo $blog_id; ?>][<?php echo esc_attr( $cat_name ); ?>][svg_value]">
                        <option value="">— Seleziona SVG —</option>
                        <?php
                          $opt_group = null;
                          $opt_labels = ARD_svg_icon_group_labels();
                          foreach ( $svg_list as $slug => $info ) :
                            if ( $info['group'] !== $opt_group ) :
                              if ( $opt_group !== null ) echo '</optgroup>';
                              $opt_group = $info['group'];
                              echo '<optgroup label="' . esc_attr( $opt_labels[ $opt_group ] ) . '">';
                            endif;
                        ?>
                          <option value="<?php echo esc_attr( $info['url'] ); ?>" <?php selected( $type === 'svg' ? $value : '', $info['url'] ); ?>><?php echo esc_html( $slug ); ?></option>
                        <?php endforeach; if ( $opt_group !== null ) echo '</optgroup>'; ?>
                      </select>
                    </span>
                    <span class="ard-eq-placeholder" style="<?php echo ! empty( $eq ) ? '' : 'display:none;'; ?> color:#999; font-style:italic;">— (Usa equivalente)</span>
                    <input type="hidden" class="ard-final-value" name="ard_site_icons[<?php echo $blog_id; ?>][<?php echo esc_attr( $cat_name ); ?>][value]" value="<?php echo esc_attr( $value ); ?>" />
                  </td>
                  <td>
                    <button type="button" class="ard-remove-row" onclick="this.closest('tr').remove();">✕</button>
                  </td>
                </tr>
                <?php endforeach;
                endif;
                if ( empty( $site_icons ) ) : ?>
                <tr>
                  <td colspan="9" style="text-align:center; padding:20px; color:#999; font-style:italic;">
                    Nessuna icona assegnata. Usa "＋ Aggiungi categoria" per iniziare.
                  </td>
                </tr>
                <?php endif; ?>
              </tbody>
            </table>

            <div class="ard-btn-group">
              <button type="button" class="ard-btn ard-btn-green" onclick="ARD_addIconRow(<?php echo $blog_id; ?>)">＋ Aggiungi singola</button>
              <button type="button" class="ard-btn ard-btn-blue" onclick="ARD_populateAllCategories(<?php echo $blog_id; ?>)">⚡ Carica tutte le categorie</button>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      <div class="ard-submit-bar">
        <button type="submit" class="button button-primary button-large">💾 Salva Icone</button>
        <div id="ard-unsaved-bar" role="status" aria-live="polite">
          <span>✏️ Modifiche non salvate</span>
          <button type="submit" class="button button-primary">💾 Salva Icone</button>
        </div>
        <span class="description">Salva le icone per tutti i siti collegati.</span>
      </div>
    </form>
    </div><!-- .ard-icons-main -->

    <?php $ard_sections = ARD_svg_icon_sections( $svg_list ); ?>
    <aside class="ard-icons-sidebar" id="ard-icon-library" aria-label="Libreria icone">
      <div class="ard-lib-head">
        <h2>🎨 Libreria icone</h2>
        <p class="ard-library-hint">✋ Trascina un'icona su una categoria, oppure cliccala e poi clicca la categoria.</p>
        <input type="search" id="ard-icon-search" placeholder="🔍 Cerca (es. pizza, birra, dolce)…" autocomplete="off" />
        <div class="ard-lib-tools">
          <button type="button" class="ard-lib-tool" data-lib-action="open">Apri tutte</button>
          <button type="button" class="ard-lib-tool" data-lib-action="close">Chiudi tutte</button>
        </div>
      </div>
      <div class="ard-lib-body">
        <?php
          $ard_default_open = array( 'custom', 'pizza' );
          foreach ( $ard_sections as $sec_key => $sec ) :
        ?>
        <details class="ard-lib-section" data-section="<?php echo esc_attr( $sec_key ); ?>" <?php echo in_array( $sec_key, $ard_default_open, true ) ? 'open' : ''; ?>>
          <summary>
            <span class="ard-lib-title"><?php echo esc_html( $sec['label'] ); ?></span>
            <span class="ard-lib-count"><?php echo count( $sec['icons'] ); ?></span>
          </summary>
          <div class="ard-lib-grid">
            <?php foreach ( $sec['icons'] as $slug => $info ) : ?>
            <div class="ard-icon-chip" draggable="true" tabindex="0" role="button" data-url="<?php echo esc_attr( $info['url'] ); ?>" data-slug="<?php echo esc_attr( $slug ); ?>" title="<?php echo esc_attr( $slug ); ?>">
              <img src="<?php echo esc_url( $info['url'] ); ?>" width="32" height="32" alt="" loading="lazy" />
              <span class="ard-chip-name"><?php echo esc_html( $slug ); ?></span>
              <?php if ( $info['group'] === 'custom' ) :
                $delete_url = wp_nonce_url( add_query_arg( array( 'action' => 'delete_svg', 'svg' => $slug ) ), 'ard_delete_svg_' . $slug );
              ?>
              <a class="ard-chip-delete" href="<?php echo esc_url( $delete_url ); ?>" title="Elimina SVG" onclick="return confirm('Sei sicuro di voler eliminare questa icona SVG?');">×</a>
              <?php endif; ?>
            </div>
            <?php endforeach; ?>
          </div>
        </details>
        <?php endforeach; ?>
        <p class="ard-lib-empty" hidden>Nessuna icona trovata.</p>
      </div>
      <details class="ard-lib-upload">
        <summary>📁 Carica nuova icona SVG</summary>
        <form method="post" enctype="multipart/form-data">
          <?php wp_nonce_field( 'ard_upload_svg', 'ard_upload_svg_nonce' ); ?>
          <input type="file" name="ard_svg_file" accept=".svg" />
          <button type="submit" class="ard-btn ard-btn-blue">⬆ Carica SVG</button>
        </form>
      </details>
    </aside>
    </div><!-- .ard-icons-layout -->
  </div>

  <script>
  function ARD_switchTab(siteId) {
    document.querySelectorAll('.ard-site-tab').forEach(function(tab) { tab.classList.remove('active'); });
    document.querySelectorAll('.ard-site-panel').forEach(function(panel) { panel.classList.remove('active'); });
    document.querySelector('.ard-site-tab[data-site="' + siteId + '"]').classList.add('active');
    document.getElementById('ard-panel-' + siteId).classList.add('active');
  }

  function ARD_toggleValueInput(select) {
    var tr = select.closest('tr');
    var emojiField = tr.querySelector('.ard-emoji-field');
    var svgField = tr.querySelector('.ard-svg-field');
    var finalValue = tr.querySelector('.ard-final-value');
    if (select.value === 'svg') {
      emojiField.style.display = 'none';
      svgField.style.display = '';
      // Update final value from SVG select
      var svgSelect = svgField.querySelector('select');
      finalValue.value = svgSelect.value;
    } else {
      emojiField.style.display = '';
      svgField.style.display = 'none';
      // Update final value from emoji input
      var emojiInput = emojiField.querySelector('input');
      finalValue.value = emojiInput.value;
    }
    ARD_updatePreview(tr);
  }

  function ARD_updatePreview(tr) {
    var type = tr.querySelector('.ard-type-select').value;
    var preview = tr.querySelector('.ard-icon-preview');
    var finalValue = tr.querySelector('.ard-final-value');
    if (type === 'svg') {
      var svgSelect = tr.querySelector('.ard-svg-field select');
      var url = svgSelect.value;
      finalValue.value = url;
      preview.innerHTML = url ? '<img src="' + url + '" width="28" height="28" />' : '<span class="emoji-preview">❓</span>';
    } else {
      var emojiInput = tr.querySelector('.ard-emoji-field input');
      var emoji = emojiInput.value;
      finalValue.value = emoji;
      preview.innerHTML = '<span class="emoji-preview">' + (emoji || '❓') + '</span>';
    }
  }

  function ARD_toggleEquivalent(select) {
    var tr = select.closest('tr');
    var typeSelect = tr.querySelector('.ard-type-select');
    var emojiField = tr.querySelector('.ard-emoji-field');
    var svgField = tr.querySelector('.ard-svg-field');
    var placeholder = tr.querySelector('.ard-eq-placeholder');
    var preview = tr.querySelector('.ard-icon-preview');
    
    if (select.value) {
      typeSelect.style.display = 'none';
      if (emojiField) emojiField.style.display = 'none';
      if (svgField) svgField.style.display = 'none';
      if (placeholder) placeholder.style.display = '';
      preview.innerHTML = '<span class="emoji-preview">🔗</span>';
    } else {
      typeSelect.style.display = '';
      if (placeholder) placeholder.style.display = 'none';
      ARD_toggleValueInput(typeSelect);
    }
  }

  // Attach live-update listeners
  document.addEventListener('change', function(e) {
    if (e.target.matches('.ard-svg-select')) {
      var tr = e.target.closest('tr');
      tr.querySelector('.ard-final-value').value = e.target.value;
      ARD_updatePreview(tr);
    }
  });
  document.addEventListener('input', function(e) {
    if (e.target.matches('.ard-emoji-field input')) {
      var tr = e.target.closest('tr');
      tr.querySelector('.ard-final-value').value = e.target.value;
      ARD_updatePreview(tr);
    }
  });

  // Available SVGs for dynamic rows
  var ardSvgOptions = <?php echo wp_json_encode( $svg_list ); ?>;
  var ardSvgGroupLabels = <?php echo wp_json_encode( ARD_svg_icon_group_labels() ); ?>;
  // <option>s grouped like the PHP-rendered selects (custom, color, line)
  function ardSvgOptionsHtml() {
    var html = '<option value="">— Seleziona SVG —</option>';
    var group = null;
    for (var slug in ardSvgOptions) {
      var g = ardSvgOptions[slug].group;
      if (g !== group) {
        if (group !== null) html += '</optgroup>';
        group = g;
        html += '<optgroup label="' + (ardSvgGroupLabels[g] || g) + '">';
      }
      html += '<option value="' + ardSvgOptions[slug].url + '">' + slug + '</option>';
    }
    if (group !== null) html += '</optgroup>';
    return html;
  }

  // WooCommerce categories per site (for the dropdown)
  <?php
    $cats_js = array();
    $cat_counts_js = array();
    foreach ( $linked as $bid ) {
      $cats = ARD_get_categories_for_site( $bid );
      $cats_js[ $bid ] = array();
      $cat_counts_js[ $bid ] = array();
      foreach ( $cats as $c ) {
        $cats_js[ $bid ][] = $c->name;
        $cat_counts_js[ $bid ][ $c->name ] = (int) $c->count;
      }
    }
  ?>
  var ardSiteCategories = <?php echo wp_json_encode( $cats_js ); ?>;
  var ardSiteCatCounts = <?php echo wp_json_encode( $cat_counts_js ); ?>;

  // Site names for dynamic rows
  var ardSiteNames = <?php
    $names_js = array();
    foreach ( $linked as $bid ) {
      switch_to_blog( $bid );
      $names_js[ $bid ] = get_bloginfo( 'name' );
      restore_current_blog();
    }
    echo wp_json_encode( $names_js );
  ?>;

  function ARD_updateRowCount(select, siteId) {
    var tr = select.closest('tr');
    var badge = tr.querySelector('.ard-row-count');
    if (!badge) return;
    var count = (ardSiteCatCounts[siteId] && ardSiteCatCounts[siteId][select.value] !== undefined)
      ? ardSiteCatCounts[siteId][select.value]
      : 0;
    badge.textContent = count;
    badge.setAttribute('title', count + ' prodotti in questa categoria');
  }

  function ARD_addIconRow(siteId) {
    var tbody = document.getElementById('ard-tbody-' + siteId);
    // Get categories already assigned in this panel
    var usedNames = [];
    tbody.querySelectorAll('input[type="hidden"][name$="[name]"]').forEach(function(inp) {
      if (inp.value) usedNames.push(inp.value);
    });
    // Also check any <select> name dropdowns from previously added rows
    tbody.querySelectorAll('select.ard-cat-select').forEach(function(sel) {
      if (sel.value) usedNames.push(sel.value);
    });
    // Filter available categories
    var allCats = ardSiteCategories[siteId] || [];
    var available = allCats.filter(function(name) { return usedNames.indexOf(name) === -1; });
    if (available.length === 0) {
      alert('Tutte le categorie WooCommerce di questo sito hanno già un\'icona assegnata.');
      return;
    }
    var catOpts = '<option value="">— Seleziona categoria —</option>';
    available.forEach(function(name) {
      catOpts += '<option value="' + name + '">' + name + '</option>';
    });
    var svgOpts = ardSvgOptionsHtml();
    var eqOpts = '<option value="">— Nessuna —</option>';
    for (var otherBid in ardSiteCategories) {
      if (parseInt(otherBid) === parseInt(siteId)) continue;
      var otherSiteName = ardSiteNames[otherBid] || '';
      var otherCats = ardSiteCategories[otherBid] || [];
      otherCats.forEach(function(catName) {
        var optVal = otherBid + '|' + catName;
        eqOpts += '<option value="' + optVal + '">[' + otherSiteName + '] ' + catName + '</option>';
      });
    }

    var baseName = 'ard_site_icons[' + siteId + '][new_' + Date.now() + ']';
    var tr = document.createElement('tr');
    tr.draggable = true;
    tr.ondragstart = ARD_dragStart;
    tr.ondragend = ARD_dragEnd;
    tr.ondragover = ARD_dragOver;
    tr.ondragleave = ARD_dragLeave;
    tr.ondrop = ARD_drop;
    tr.innerHTML =
      '<td class="ard-drag-handle" title="Trascina per riordinare">⠿</td>' +
      '<td><span class="ard-icon-preview"><span class="emoji-preview">❓</span></span></td>' +
      '<td><select class="ard-cat-select" style="padding:6px 10px; border:1px solid #ddd; border-radius:4px; font-size:13px; width:220px;" onchange="this.nextElementSibling.value=this.value; ARD_updateRowCount(this, ' + siteId + ');">' + catOpts + '</select>' +
        '<input type="hidden" name="' + baseName + '[name]" value="" /></td>' +
      '<td style="text-align:center;"><span class="ard-row-count" style="display:inline-block; min-width:24px; padding:2px 8px; background:#eef2f7; color:#334e68; border:1px solid #d0dbe5; border-radius:12px; font-weight:600; font-size:12px;" title="0 prodotti in questa categoria">0</span></td>' +
      '<td><span style="display:inline-block; padding:3px 8px; background:#e8f0fe; border-radius:4px; font-size:11px; color:#1a73e8; font-weight:500;">' + (ardSiteNames[siteId] || '') + '</span></td>' +
      '<td><select class="ard-eq-select" name="' + baseName + '[equivalent]" onchange="ARD_toggleEquivalent(this)" style="width:100%; max-width:180px;">' + eqOpts + '</select></td>' +
      '<td><select class="ard-type-select" name="' + baseName + '[type]" onchange="ARD_toggleValueInput(this)"><option value="emoji">🔤 Emoji</option><option value="svg">📁 SVG</option></select></td>' +
      '<td>' +
        '<span class="ard-emoji-field"><input type="text" class="ard-value-input" name="' + baseName + '[emoji_value]" value="" placeholder="🍕" style="width:60px; text-align:center; font-size:20px;" /></span>' +
        '<span class="ard-svg-field" style="display:none;"><select class="ard-svg-select" name="' + baseName + '[svg_value]">' + svgOpts + '</select></span>' +
        '<span class="ard-eq-placeholder" style="display:none; color:#999; font-style:italic;">— (Usa equivalente)</span>' +
        '<input type="hidden" class="ard-final-value" name="' + baseName + '[value]" value="" />' +
      '</td>' +
      '<td><button type="button" class="ard-remove-row" onclick="this.closest(\'tr\').remove();">✕</button></td>';
    tbody.appendChild(tr);
  }

  function ARD_populateAllCategories(siteId) {
    var tbody = document.getElementById('ard-tbody-' + siteId);
    
    // Get categories already assigned in this panel
    var usedNames = [];
    tbody.querySelectorAll('input[type="hidden"][name$="[name]"]').forEach(function(inp) {
      if (inp.value) usedNames.push(inp.value);
    });
    tbody.querySelectorAll('select.ard-cat-select').forEach(function(sel) {
      if (sel.value) usedNames.push(sel.value);
    });
    
    var allCats = ardSiteCategories[siteId] || [];
    var available = allCats.filter(function(name) { return usedNames.indexOf(name) === -1; });
    
    if (available.length === 0) {
      alert('Tutte le categorie WooCommerce di questo sito con prodotti sono già in elenco.');
      return;
    }
    
    // Remove empty state row if present
    var emptyRow = tbody.querySelector('tr td[colspan]');
    if (emptyRow) {
      emptyRow.closest('tr').remove();
    }
    
    available.forEach(function(name, index) {
      var baseName = 'ard_site_icons[' + siteId + '][new_' + (Date.now() + index) + ']';
      var svgOpts = ardSvgOptionsHtml();
      
      var eqOpts = '<option value="">— Nessuna —</option>';
      for (var otherBid in ardSiteCategories) {
        if (parseInt(otherBid) === parseInt(siteId)) continue;
        var otherSiteName = ardSiteNames[otherBid] || '';
        var otherCats = ardSiteCategories[otherBid] || [];
        otherCats.forEach(function(catName) {
          var optVal = otherBid + '|' + catName;
          eqOpts += '<option value="' + optVal + '">[' + otherSiteName + '] ' + catName + '</option>';
        });
      }

      var count = (ardSiteCatCounts[siteId] && ardSiteCatCounts[siteId][name] !== undefined) ? ardSiteCatCounts[siteId][name] : 0;

      var tr = document.createElement('tr');
      tr.draggable = true;
      tr.ondragstart = ARD_dragStart;
      tr.ondragend = ARD_dragEnd;
      tr.ondragover = ARD_dragOver;
      tr.ondragleave = ARD_dragLeave;
      tr.ondrop = ARD_drop;
      
      tr.innerHTML =
        '<td class="ard-drag-handle" title="Trascina per riordinare">⠿</td>' +
        '<td><span class="ard-icon-preview"><span class="emoji-preview">❓</span></span></td>' +
        '<td><strong style="font-size:13px;">' + name + '</strong>' +
          '<input type="hidden" name="' + baseName + '[name]" value="' + name + '" /></td>' +
        '<td style="text-align:center;"><span style="display:inline-block; min-width:24px; padding:2px 8px; background:#eef2f7; color:#334e68; border:1px solid #d0dbe5; border-radius:12px; font-weight:600; font-size:12px;" title="' + count + ' prodotti in questa categoria">' + count + '</span></td>' +
        '<td><span style="display:inline-block; padding:3px 8px; background:#e8f0fe; border-radius:4px; font-size:11px; color:#1a73e8; font-weight:500;">' + (ardSiteNames[siteId] || '') + '</span></td>' +
        '<td><select class="ard-eq-select" name="' + baseName + '[equivalent]" onchange="ARD_toggleEquivalent(this)" style="width:100%; max-width:180px;">' + eqOpts + '</select></td>' +
        '<td><select class="ard-type-select" name="' + baseName + '[type]" onchange="ARD_toggleValueInput(this)"><option value="emoji">🔤 Emoji</option><option value="svg">📁 SVG</option></select></td>' +
        '<td>' +
          '<span class="ard-emoji-field"><input type="text" class="ard-value-input" name="' + baseName + '[emoji_value]" value="" placeholder="🍕" style="width:60px; text-align:center; font-size:20px;" /></span>' +
          '<span class="ard-svg-field" style="display:none;"><select class="ard-svg-select" name="' + baseName + '[svg_value]">' + svgOpts + '</select></span>' +
          '<span class="ard-eq-placeholder" style="display:none; color:#999; font-style:italic;">— (Usa equivalente)</span>' +
          '<input type="hidden" class="ard-final-value" name="' + baseName + '[value]" value="" />' +
        '</td>' +
        '<td><button type="button" class="ard-remove-row" onclick="this.closest(\'tr\').remove();">✕</button></td>';
      tbody.appendChild(tr);
    });
  }

  // ---- Icon library → category: drag & drop + click-to-assign ----
  var ardDraggedIcon = null;   // { url, slug } while an icon chip is dragged
  var ardSelectedChip = null;  // chip picked with a click (touch / keyboard)

  function ARD_assignIconToRow(tr, url, slug) {
    if (!tr || !url || !tr.querySelector('.ard-svg-select')) return;
    // Dropping an icon replaces a "use equivalent" link
    var eq = tr.querySelector('.ard-eq-select');
    if (eq && eq.value) { eq.value = ''; ARD_toggleEquivalent(eq); }
    var typeSelect = tr.querySelector('.ard-type-select');
    typeSelect.value = 'svg';
    var svgSelect = tr.querySelector('.ard-svg-select');
    var hasOption = Array.prototype.some.call(svgSelect.options, function(o) { return o.value === url; });
    if (!hasOption) {
      var opt = document.createElement('option');
      opt.value = url; opt.textContent = slug || url;
      svgSelect.appendChild(opt);
    }
    svgSelect.value = url;
    ARD_toggleValueInput(typeSelect); // shows the SVG field, sets the hidden value, refreshes the preview
    tr.classList.remove('ard-icon-assigned'); void tr.offsetWidth; tr.classList.add('ard-icon-assigned');
    ARD_markUnsaved();
  }

  function ARD_markUnsaved() {
    var bar = document.getElementById('ard-unsaved-bar');
    if (bar) bar.classList.add('ard-visible');
  }

  function ARD_clearIconSelection() {
    if (ardSelectedChip) ardSelectedChip.classList.remove('ard-chip-selected');
    ardSelectedChip = null;
    document.body.classList.remove('ard-assign-mode');
  }

  document.addEventListener('dragstart', function(e) {
    var chip = e.target.closest && e.target.closest('.ard-icon-chip');
    if (!chip) return;
    e.stopPropagation();
    ardDraggedIcon = { url: chip.dataset.url, slug: chip.dataset.slug };
    chip.classList.add('ard-chip-dragging');
    document.body.classList.add('ard-icon-dragging');
    e.dataTransfer.effectAllowed = 'copy';
    e.dataTransfer.setData('text/plain', chip.dataset.slug); // Firefox needs data
    var img = chip.querySelector('img');
    if (img && e.dataTransfer.setDragImage) e.dataTransfer.setDragImage(img, 12, 12);
  }, true);

  document.addEventListener('dragend', function(e) {
    if (!ardDraggedIcon) return;
    ardDraggedIcon = null;
    document.body.classList.remove('ard-icon-dragging');
    document.querySelectorAll('.ard-chip-dragging').forEach(function(el) { el.classList.remove('ard-chip-dragging'); });
    document.querySelectorAll('.ard-icon-target').forEach(function(el) { el.classList.remove('ard-icon-target'); });
  }, true);

  // Click a chip to pick it, then click a category row (works on touch screens too)
  document.addEventListener('click', function(e) {
    var chip = e.target.closest('.ard-icon-chip');
    if (chip) {
      if (e.target.closest('a')) return; // delete link of uploaded icons
      if (ardSelectedChip === chip) { ARD_clearIconSelection(); return; }
      ARD_clearIconSelection();
      ardSelectedChip = chip;
      chip.classList.add('ard-chip-selected');
      document.body.classList.add('ard-assign-mode');
      return;
    }
    if (!ardSelectedChip) return;
    var tr = e.target.closest('.ard-icons-table tbody tr');
    if (tr && !e.target.closest('select, input, button, a')) {
      ARD_assignIconToRow(tr, ardSelectedChip.dataset.url, ardSelectedChip.dataset.slug);
      ARD_clearIconSelection();
    }
  });
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') ARD_clearIconSelection();
    var chip = e.target.closest && e.target.closest('.ard-icon-chip');
    if (chip && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); chip.click(); }
  });

  // ---- Icon library sidebar: accordion state, open/close all, search ----
  var ARD_LIB_KEY = 'ardIconLibOpen';
  var ardLibSearching = false;
  var ardLibBeforeSearch = [];
  function ARD_libSections() { return Array.prototype.slice.call(document.querySelectorAll('#ard-icon-library .ard-lib-section')); }
  function ARD_saveLibState() {
    if (ardLibSearching) return;
    try {
      var open = ARD_libSections().filter(function(d) { return d.open; }).map(function(d) { return d.dataset.section; });
      localStorage.setItem(ARD_LIB_KEY, JSON.stringify(open));
    } catch (err) {}
  }
  function ARD_restoreLibState() {
    var open = null;
    try { open = JSON.parse(localStorage.getItem(ARD_LIB_KEY) || 'null'); } catch (err) {}
    if (!Array.isArray(open)) return; // keep server defaults
    ARD_libSections().forEach(function(d) { d.open = open.indexOf(d.dataset.section) !== -1; });
  }
  ARD_restoreLibState();
  document.addEventListener('toggle', function(e) {
    if (e.target.classList && e.target.classList.contains('ard-lib-section')) ARD_saveLibState();
  }, true);
  document.addEventListener('click', function(e) {
    var btn = e.target.closest('.ard-lib-tool');
    if (!btn) return;
    var open = btn.dataset.libAction === 'open';
    ARD_libSections().forEach(function(d) { if (d.style.display !== 'none') d.open = open; });
    ARD_saveLibState();
  });
  document.addEventListener('input', function(e) {
    if (e.target.id !== 'ard-icon-search') return;
    var q = e.target.value.trim().toLowerCase();
    var any = false;
    if (q && !ardLibSearching) {
      ardLibSearching = true;
      ardLibBeforeSearch = ARD_libSections().filter(function(d) { return d.open; }).map(function(d) { return d.dataset.section; });
    }
    ARD_libSections().forEach(function(d) {
      var matches = 0;
      d.querySelectorAll('.ard-icon-chip').forEach(function(chip) {
        var hit = !q || chip.dataset.slug.toLowerCase().indexOf(q) !== -1;
        chip.style.display = hit ? '' : 'none';
        if (hit) matches++;
      });
      d.style.display = matches ? '' : 'none';
      if (q && matches) d.open = true;
      if (matches) any = true;
    });
    var empty = document.querySelector('#ard-icon-library .ard-lib-empty');
    if (empty) empty.hidden = any;
    if (!q && ardLibSearching) {
      ARD_libSections().forEach(function(d) { d.open = ardLibBeforeSearch.indexOf(d.dataset.section) !== -1; });
      ardLibSearching = false;
    }
  });

  // Any manual change in the table also counts as unsaved
  document.addEventListener('change', function(e) {
    if (e.target.closest && e.target.closest('.ard-icons-table')) ARD_markUnsaved();
  });

  // ---- Drag & Drop Reordering ----
  var ardDraggedRow = null;

  function ARD_dragStart(e) {
    if (ardDraggedIcon) return;
    ardDraggedRow = e.target.closest('tr');
    ardDraggedRow.classList.add('ard-dragging');
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', ''); // Required for Firefox
  }

  function ARD_dragEnd(e) {
    if (ardDraggedRow) { ardDraggedRow.classList.remove('ard-dragging'); ARD_markUnsaved(); }
    document.querySelectorAll('.ard-drag-over').forEach(function(el) { el.classList.remove('ard-drag-over'); });
    ardDraggedRow = null;
  }

  function ARD_dragOver(e) {
    e.preventDefault();
    if (ardDraggedIcon) {
      e.dataTransfer.dropEffect = 'copy';
      var iconRow = e.target.closest('tr');
      if (iconRow && iconRow.parentNode.tagName === 'TBODY') {
        document.querySelectorAll('.ard-icon-target').forEach(function(el) { if (el !== iconRow) el.classList.remove('ard-icon-target'); });
        iconRow.classList.add('ard-icon-target');
      }
      return;
    }
    e.dataTransfer.dropEffect = 'move';
    var targetRow = e.target.closest('tr');
    if (targetRow && targetRow !== ardDraggedRow && targetRow.parentNode.tagName === 'TBODY') {
      // Remove highlight from all rows first
      targetRow.closest('tbody').querySelectorAll('.ard-drag-over').forEach(function(el) { el.classList.remove('ard-drag-over'); });
      targetRow.classList.add('ard-drag-over');
    }
  }

  function ARD_dragLeave(e) {
    var targetRow = e.target.closest('tr');
    if (!targetRow) return;
    targetRow.classList.remove('ard-drag-over');
    if (ardDraggedIcon && !targetRow.contains(e.relatedTarget)) targetRow.classList.remove('ard-icon-target');
  }

  function ARD_drop(e) {
    e.preventDefault();
    var targetRow = e.target.closest('tr');
    if (ardDraggedIcon) {
      if (targetRow && targetRow.parentNode.tagName === 'TBODY') {
        targetRow.classList.remove('ard-icon-target');
        ARD_assignIconToRow(targetRow, ardDraggedIcon.url, ardDraggedIcon.slug);
      }
      return;
    }
    if (!targetRow || !ardDraggedRow || targetRow === ardDraggedRow) return;
    var tbody = targetRow.closest('tbody');
    if (!tbody) return;
    // Determine position: insert before or after
    var rows = Array.from(tbody.querySelectorAll('tr'));
    var dragIdx = rows.indexOf(ardDraggedRow);
    var targetIdx = rows.indexOf(targetRow);
    if (dragIdx < targetIdx) {
      tbody.insertBefore(ardDraggedRow, targetRow.nextSibling);
    } else {
      tbody.insertBefore(ardDraggedRow, targetRow);
    }
    targetRow.classList.remove('ard-drag-over');
  }
  </script>
  <?php
}

/**
 * Sync category icons to Firestore via Cloud Functions.
 */
function ARD_sync_category_icons_to_firestore() {
  $fetch_url = get_option( 'fetch_url' );
  if ( empty( $fetch_url ) ) return;
  if ( ARD_config_api_secret() === '' ) {
    error_log( '[MobileAdmin] Category icons sync skipped: ARD_CONFIG_API_SECRET not configured' );
    return;
  }

  $icons = get_option( 'app_category_icons', array() );
  $icons = ARD_maybe_migrate_category_icons( $icons );
  list( $icons ) = ARD_heal_renamed_category_icons( $icons );
  $icons = ARD_propagate_icons_to_translations( $icons );

  $response = wp_remote_post( rtrim( $fetch_url, '/' ) . '/config/update', array(
    'body'    => wp_json_encode( array(
      'apiSecret'     => ARD_config_api_secret(),
      'categoryIcons' => $icons,
    ) ),
    'headers' => array( 'Content-Type' => 'application/json' ),
    'timeout' => 15,
  ) );

  if ( is_wp_error( $response ) ) {
    error_log( '[MobileAdmin] Category icons sync failed: ' . $response->get_error_message() );
  }
}

// REST API endpoint for slides + category icons
add_action( 'rest_api_init', function() {
  register_rest_route( 'mobile-admin/v1', '/slides', array(
    'methods'             => 'GET',
    'callback'            => 'ARD_rest_get_slides',
    'permission_callback' => '__return_true',
  ) );
  register_rest_route( 'mobile-admin/v1', '/category-icons', array(
    'methods'             => 'GET',
    'callback'            => 'ARD_rest_get_category_icons',
    'permission_callback' => '__return_true',
  ) );
} );

function ARD_rest_get_slides() {
  $slides = get_option( 'app_slides', array() );
  foreach ( $slides as &$slide ) {
    if ( is_array( $slide ) ) {
      $site_id = isset( $slide['site_id'] ) ? (int) $slide['site_id'] : 0;
      $slide['site_url'] = ( $site_id > 0 ) ? get_home_url( $site_id ) : '';
    }
  }
  unset( $slide );
  return rest_ensure_response( array( 'slides' => $slides ) );
}

function ARD_rest_get_category_icons() {
  $icons = get_option( 'app_category_icons', array() );
  $icons = ARD_maybe_migrate_category_icons( $icons );
  list( $icons ) = ARD_heal_renamed_category_icons( $icons );
  $icons = ARD_propagate_icons_to_translations( $icons );
  return rest_ensure_response( array( 'icons' => $icons ) );
}

add_action( 'rest_api_init', function() {
  register_rest_route( 'mobile-admin/v1', '/search-suggest', array(
    'methods'             => 'GET',
    'callback'            => 'ARD_rest_global_search_suggest',
    'permission_callback' => '__return_true',
  ) );
  register_rest_route( 'mobile-admin/v1', '/branch-pages', array(
    'methods'             => 'GET',
    'callback'            => 'ARD_rest_get_branch_pages',
    'permission_callback' => '__return_true',
  ) );
} );

function ARD_rest_global_search_suggest( $request ) {
  $query = sanitize_text_field( $request->get_param( 'q' ) );

  $linked = get_option( 'wc_schedule_linked_sites', array() );
  // Exclude main hub (blog 8) if present
  $linked = array_diff( $linked, array( 8 ) );

  $suggestions = array();

  foreach ( $linked as $blog_id ) {
    switch_to_blog( $blog_id );

    global $wpdb;
    
    // 1. Query WooCommerce categories with products
    $term_sql = "
      SELECT t.name 
      FROM {$wpdb->terms} t
      INNER JOIN {$wpdb->term_taxonomy} tt ON t.term_id = tt.term_id
      WHERE tt.taxonomy = 'product_cat' 
        AND tt.count > 0
    ";
    if ( ! empty( $query ) ) {
      $term_sql .= " AND t.name LIKE '%" . esc_sql( $wpdb->esc_like( $query ) ) . "%'";
      $term_sql .= " LIMIT 15";
    } else {
      $term_sql .= " LIMIT 100";
    }
    $term_rows = $wpdb->get_results( $term_sql );

    $icons = get_option( 'app_category_icons', array() );
    $icons = ARD_maybe_migrate_category_icons( $icons );

    foreach ( $term_rows as $row ) {
      $clean_name = preg_replace( '/^\d+\.\s*/', '', $row->name );

      // If there is an equivalent category mapped, group under the equivalent category's clean name
      if ( isset( $icons[ $blog_id ][ $row->name ]['equivalent'] ) && ! empty( $icons[ $blog_id ][ $row->name ]['equivalent'] ) ) {
        $parts = explode( '|', $icons[ $blog_id ][ $row->name ]['equivalent'] );
        if ( count( $parts ) === 2 ) {
          $clean_name = preg_replace( '/^\d+\.\s*/', '', $parts[1] );
        }
      }

      $key = 'cat_' . sanitize_title( $clean_name );
      if ( ! isset( $suggestions[ $key ] ) ) {
        $suggestions[ $key ] = array(
          'label' => $clean_name,
          'value' => $clean_name,
          'type'  => 'category',
          'sites' => array()
        );
      }
      if ( ! in_array( $blog_id, $suggestions[ $key ]['sites'] ) ) {
        $suggestions[ $key ]['sites'][] = (int) $blog_id;
      }
    }

    // 2. Query products (post_type = 'product', post_status = 'publish') with category details
    $product_sql = "
      SELECT p.post_title, t.term_id AS category_id, t.name AS category_name
      FROM {$wpdb->posts} p
      INNER JOIN {$wpdb->term_relationships} tr ON p.ID = tr.object_id
      INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id AND tt.taxonomy = 'product_cat'
      INNER JOIN {$wpdb->terms} t ON tt.term_id = t.term_id
      WHERE p.post_type = 'product'
        AND p.post_status = 'publish'
    ";
    if ( ! empty( $query ) ) {
      $product_sql .= " AND p.post_title LIKE '%" . esc_sql( $wpdb->esc_like( $query ) ) . "%'";
      $product_sql .= " LIMIT 40";
    } else {
      $product_sql .= " LIMIT 800";
    }
    $product_rows = $wpdb->get_results( $product_sql );

    foreach ( $product_rows as $row ) {
      // Clean leading number and dot (e.g. "4. ")
      $clean_name = preg_replace( '/^\d+\.\s*/', '', $row->post_title );
      $clean_name = preg_replace( '/\s+/', ' ', $clean_name );
      $clean_name = trim( $clean_name );
      
      // Standardize "Singola", "Famiglia" and "Bimbi" tags formatting
      if ( preg_match( '/\bSingola\b/i', $clean_name ) && ! preg_match( '/\(\s*Singola\s*\)/i', $clean_name ) ) {
        $clean_name = preg_replace( '/\s+Singola\b/i', ' (Singola)', $clean_name );
      }
      if ( preg_match( '/\bFamiglia\b/i', $clean_name ) && ! preg_match( '/\(\s*Famiglia\s*\)/i', $clean_name ) ) {
        $clean_name = preg_replace( '/\s+Famiglia\b/i', ' (Famiglia)', $clean_name );
      }
      if ( preg_match( '/\bBimbi\b/i', $clean_name ) && ! preg_match( '/\(\s*Bimbi\s*\)/i', $clean_name ) ) {
        $clean_name = preg_replace( '/\s+Bimbi\b/i', ' (Bimbi)', $clean_name );
      }

      $key = 'prod_' . sanitize_title( $clean_name );
      
      $raw_cat_name = $row->category_name;
      $clean_cat_name = preg_replace( '/^\d+\.\s*/', '', $raw_cat_name );
      
      if ( isset( $icons[ $blog_id ][ $raw_cat_name ]['equivalent'] ) && ! empty( $icons[ $blog_id ][ $raw_cat_name ]['equivalent'] ) ) {
        $parts = explode( '|', $icons[ $blog_id ][ $raw_cat_name ]['equivalent'] );
        if ( count( $parts ) === 2 ) {
          $clean_cat_name = preg_replace( '/^\d+\.\s*/', '', $parts[1] );
        }
      }

      if ( ! isset( $suggestions[ $key ] ) ) {
        $suggestions[ $key ] = array(
          'label'      => $clean_name,
          'value'      => $clean_name,
          'type'       => 'product',
          'sites'      => array(),
          'categories' => array()
        );
      }
      if ( ! in_array( $blog_id, $suggestions[ $key ]['sites'] ) ) {
        $suggestions[ $key ]['sites'][] = (int) $blog_id;
      }
      
      $suggestions[ $key ]['categories'][ (string) $blog_id ] = array(
        'id'   => (int) $row->category_id,
        'name' => $clean_cat_name
      );
    }

    restore_current_blog();
  }

  return rest_ensure_response( array( 'suggestions' => array_values( $suggestions ) ) );
}

function ARD_rest_get_branch_pages( $request ) {
  $blog_id = (int) $request->get_param( 'blog_id' );
  if ( ! $blog_id ) {
    return rest_ensure_response( array( 'categories' => array(), 'products' => array() ) );
  }

  // Verify that it is a linked site to prevent unauthorized access
  $linked_sites = (array) get_option( 'wc_schedule_linked_sites', array() );
  if ( empty( $linked_sites ) ) {
    $linked_sites = array( get_current_blog_id() );
  }
  if ( ! in_array( $blog_id, array_map( 'intval', $linked_sites ), true ) ) {
    return rest_ensure_response( array( 'categories' => array(), 'products' => array() ) );
  }

  switch_to_blog( $blog_id );
  global $wpdb;

  // 1. Fetch WooCommerce categories that have at least one product
  $cats_sql = "
    SELECT t.term_id AS id, t.name 
    FROM {$wpdb->terms} t
    INNER JOIN {$wpdb->term_taxonomy} tt ON t.term_id = tt.term_id
    WHERE tt.taxonomy = 'product_cat' 
      AND tt.count > 0
    ORDER BY t.name ASC
  ";
  $cats = $wpdb->get_results( $cats_sql );

  // 2. Fetch products with their corresponding category ID and name
  $products_sql = "
    SELECT p.ID AS id, p.post_title AS name, t.term_id AS cat_id, t.name AS cat_name
    FROM {$wpdb->posts} p
    INNER JOIN {$wpdb->term_relationships} tr ON p.ID = tr.object_id
    INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id AND tt.taxonomy = 'product_cat'
    INNER JOIN {$wpdb->terms} t ON tt.term_id = t.term_id
    WHERE p.post_type = 'product'
      AND p.post_status = 'publish'
    ORDER BY p.post_title ASC
  ";
  $products = $wpdb->get_results( $products_sql );

  restore_current_blog();

  return rest_ensure_response( array(
    'categories' => $cats ? $cats : array(),
    'products'   => $products ? $products : array(),
  ) );
}

// ================================================================
// WOOCOMMERCE GLOBAL PRODUCT ADDONS REST ENDPOINT
// Extracted to mu-plugins/cs-addons-rest-api.php for clean separation of concerns.
// Registers: GET /wp-json/cs/v1/addons/all
// Required by Firebase Cloud Function getAddonsAsync().
// ================================================================

function WPADR_rest_get_pos_info() {
	// Read linked sites dynamically from the main site (blog ID 1) option
	switch_to_blog( 1 );
	$linked_sites = (array) get_option( 'wc_schedule_linked_sites', array() );
	restore_current_blog();

	if ( empty( $linked_sites ) ) {
		$linked_sites = array( 22, 23, 63 ); // Fallback to current main sites
	}

	$info = array();

	// Fallback numbers/addresses if POS settings are empty or point to giubiasco
	$fallbacks = array(
		22 => array(
			'phone'   => '091 857 88 77',
			'address' => 'Viale Stazione 11, 6512 Giubiasco',
		),
		23 => array(
			'phone'   => '091 857 88 77',
			'address' => 'Vicolo Nord 1, 6500 Bellinzona',
		),
		24 => array(
			'phone'   => '091 994 63 63',
			'address' => 'Via Paradiso 24, 6924 Sorengo',
		),
		63 => array(
			'phone'   => '091 825 18 19',
			'address' => 'Via San Giovanni 9, 6500 Bellinzona',
		),
	);

	foreach ( $linked_sites as $blog_id ) {
		$blog_id = intval( $blog_id );
		if ( $blog_id === 1 ) {
			continue; // Skip the main network dashboard hub
		}

		switch_to_blog( $blog_id );

		$store_name    = get_option( 'woocommerce_pos_store_name', '' );
		$store_address = get_option( 'woocommerce_pos_store_address', '' );
		$store_phone   = get_option( 'woocommerce_pos_store_phone', '' );
		$store_email   = get_option( 'woocommerce_pos_store_email', '' );

		if ( empty( $store_name ) ) {
			$store_name = get_bloginfo( 'name' );
		}

		if ( empty( $store_phone ) ) {
			$store_phone = isset( $fallbacks[ $blog_id ] ) ? $fallbacks[ $blog_id ]['phone'] : '091 857 88 77';
		}

		// Clean up address if it contains Giubiasco on a non-Giubiasco site
		if ( empty( $store_address ) || ( $blog_id !== 22 && strpos( strtolower( $store_address ), 'giubiasco' ) !== false ) ) {
			$store_address = isset( $fallbacks[ $blog_id ] ) ? $fallbacks[ $blog_id ]['address'] : '';
		}

		// Get delivery hours settings
		$time_settings      = get_option( 'coderockz_woo_delivery_time_settings', array() );
		$time_slot_settings = get_option( 'coderockz_woo_delivery_time_slot_settings', array() );

		$schedules = array();

		// Default schedules mapping if delivery time slots are empty
		if ( empty( $time_slot_settings ) || empty( $time_slot_settings['time_slot'] ) ) {
			// Fallback schedules
			if ( $blog_id === 24 ) {
				$schedules = array(
					array(
						'title'     => 'Dal Lunedì al Sabato:',
						'fromAndTo' => array( array( '17:00', '22:00' ) ),
					),
					array(
						'title'     => 'Orari di consegna a domicilio:',
						'fromAndTo' => array( array( '18:00', '22:00' ) ),
					),
				);
			} else {
				$schedules = array(
					array(
						'title'     => 'Dal Lunedì al Sabato:',
						'fromAndTo' => array(
							array( '10:00', '14:00' ),
							array( '17:00', '22:00' ),
						),
					),
					array(
						'title'     => 'Orari di consegna a domicilio:',
						'fromAndTo' => array( array( '18:00', '22:00' ) ),
					),
				);
			}
		} else {
			// Parse the time slots from WooCommerce Delivery settings dynamically!
			$slots = $time_slot_settings['time_slot'];
			
			// We group timeslots by their name/type or just compile them
			foreach ( $slots as $slot ) {
				if ( isset( $slot['enable'] ) && $slot['enable'] ) {
					$slot_name = isset( $slot['name'] ) ? $slot['name'] : 'Orari';
					
					// Convert start/end minutes to HH:MM format
					$start_min = isset( $slot['start'] ) ? (int) $slot['start'] : 0;
					$end_min   = isset( $slot['end'] ) ? (int) $slot['end'] : 0;
					
					$start_h   = str_pad( floor( $start_min / 60 ), 2, '0', STR_PAD_LEFT );
					$start_m   = str_pad( $start_min % 60, 2, '0', STR_PAD_LEFT );
					$end_h     = str_pad( floor( $end_min / 60 ), 2, '0', STR_PAD_LEFT );
					$end_m     = str_pad( $end_min % 60, 2, '0', STR_PAD_LEFT );
					
					$time_range = array( "{$start_h}:{$start_m}", "{$end_h}:{$end_m}" );
					
					// Check if a slot with this name already exists in $schedules
					$found = false;
					$title_str = $slot_name . ':';
					foreach ( $schedules as &$sch ) {
						if ( $sch['title'] === $title_str ) {
							$sch['fromAndTo'][] = $time_range;
							$found = true;
							break;
						}
					}
					if ( !$found ) {
						$schedules[] = array(
							'title'     => $title_str,
							'fromAndTo' => array( $time_range ),
						);
					}
				}
			}
		}

		$details = get_blog_details( $blog_id );
		if ( $details && strpos( strtolower( $details->domain ), 'dame' ) !== false ) {
			$key = 'dame';
		} else {
			$key = $details ? str_replace( array( '.mrjoecity.ch', '.ch', '/' ), '', $details->domain . $details->path ) : "site_{$blog_id}";
		}

		$info[] = array(
			'key'       => $key,
			'siteId'    => $blog_id,
			'name'      => $store_name,
			'address'   => str_replace( array( "\r\n", "\r", "\n" ), ", ", trim( $store_address ) ),
			'phone'     => $store_phone,
			'email'     => $store_email,
			'schedules' => $schedules,
		);

		restore_current_blog();
	}

	return rest_ensure_response( array( 'outlets' => $info ) );
}

/**
 * Add custom fields to WooCommerce Flat Rate shipping settings
 */
add_filter( 'woocommerce_shipping_instance_form_fields_flat_rate', 'WPADR_add_flat_rate_minimum_order_fields', 10, 1 );
function WPADR_add_flat_rate_minimum_order_fields( $fields ) {
	$fields['enable_min_amount'] = array(
		'title'   => 'Importo minimo',
		'type'    => 'checkbox',
		'label'   => 'Abilita importo minimo del carrello',
		'default' => 'no',
	);
	$fields['min_amount'] = array(
		'title'       => 'Soglia importo minimo (CHF)',
		'type'        => 'number',
		'description' => 'L\'importo minimo del carrello necessario per rendere disponibile questo metodo.',
		'desc_tip'    => true,
		'default'     => '',
		'custom_attributes' => array(
			'step' => 'any',
			'min'  => '0',
		),
	);
	return $fields;
}

/**
 * Filter available WooCommerce rates by minimum order amount configured on the Flat Rate method
 */
add_filter( 'woocommerce_package_rates', 'WPADR_filter_flat_rate_rates_by_minimum_order', 10, 2 );
function WPADR_filter_flat_rate_rates_by_minimum_order( $rates, $package ) {
	// Skip if WooCommerce cart is not loaded
	if ( ! WC() || ! WC()->cart ) {
		return $rates;
	}

	$cart_total = WC()->cart->get_subtotal();

	foreach ( $rates as $rate_key => $rate ) {
		if ( 'flat_rate' === $rate->method_id ) {
			$option_key = 'woocommerce_flat_rate_' . $rate->instance_id . '_settings';
			$settings = get_option( $option_key );
			if ( is_array( $settings ) ) {
				$enable_min = isset( $settings['enable_min_amount'] ) ? $settings['enable_min_amount'] : 'no';
				$min_val = isset( $settings['min_amount'] ) ? floatval( $settings['min_amount'] ) : 0;
				if ( 'yes' === $enable_min && $cart_total < $min_val ) {
					unset( $rates[ $rate_key ] );
				}
			}
		}
	}
	return $rates;
}

/* =========================================================================
 * Delivery CAPs from WooCommerce shipping zones (network-wide, v2.1.0)
 *
 * Single source of truth: the postcodes configured in each subsite's
 * WooCommerce shipping zones. Exposed as:
 *  - PHP helper  WPADR_get_network_delivery_caps()
 *  - REST        GET /wp-json/wpadr/v1/delivery-caps  (?refresh=1 for admins)
 *  - Shortcode   [wpadr_cap_selector]  (CAP input -> matching sedi + links)
 * Multisite only: on single-site installs everything returns empty / renders
 * nothing, so the plugin stays safe on other (non-network) installations.
 * ========================================================================= */

/**
 * Collect, per subsite, the postcodes covered by delivery-capable shipping
 * zones (enabled flat_rate/free_shipping) and whether local pickup is offered.
 * Cached in a network transient for 10 minutes.
 *
 * @return array[] [ blog_id, name, url, delivery_caps => string[], pickup => bool ]
 */
function WPADR_get_network_delivery_caps( $force_refresh = false ) {
	if ( ! is_multisite() ) {
		return array();
	}
	$cache_key = 'wpadr_network_delivery_caps';
	if ( ! $force_refresh ) {
		$cached = get_site_transient( $cache_key );
		if ( false !== $cached ) {
			return $cached;
		}
	}

	// Only sites under the same registrable domain as the current site
	// (e.g. bellinzona.littleinka.ch under littleinka.ch): on shared networks
	// this keeps other brands' shops out of the selector.
	$current_host = (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST );

	global $wpdb;
	$rows = array();
	foreach ( get_sites( array( 'number' => 0 ) ) as $site ) {
		switch_to_blog( (int) $site->blog_id );

		$site_host   = (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST );
		$same_domain = ( $site_host === $current_host )
			|| ( substr( $site_host, -strlen( '.' . $current_host ) ) === '.' . $current_host );

		// switch_to_blog() does NOT load the other site's plugins, so the WC
		// classes are unavailable when WooCommerce is inactive on the current
		// site (the hub). Read the zone tables directly instead.
		$methods_table   = $wpdb->prefix . 'woocommerce_shipping_zone_methods';
		$locations_table = $wpdb->prefix . 'woocommerce_shipping_zone_locations';
		$has_wc_tables   = $same_domain
			&& $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $methods_table ) ) === $methods_table;

		if ( $has_wc_tables ) {
			$delivery_caps  = array();
			$has_pickup     = false;
			$delivery_zones = array();

			$methods = $wpdb->get_results(
				"SELECT zone_id, method_id, is_enabled FROM `{$methods_table}`"
			);
			foreach ( $methods as $method ) {
				if ( ! (int) $method->is_enabled ) {
					continue;
				}
				if ( in_array( $method->method_id, array( 'flat_rate', 'free_shipping' ), true ) ) {
					$delivery_zones[ (int) $method->zone_id ] = true;
				}
				// Zone 0 ("rest of the world") holds pickup-only setups.
				if ( 'local_pickup' === $method->method_id ) {
					$has_pickup = true;
				}
			}

			if ( ! empty( $delivery_zones ) ) {
				$locations = $wpdb->get_results(
					"SELECT zone_id, location_code, location_type FROM `{$locations_table}`"
				);
				foreach ( $locations as $location ) {
					if ( 'postcode' === $location->location_type
						&& isset( $delivery_zones[ (int) $location->zone_id ] ) ) {
						$delivery_caps[] = (string) $location->location_code;
					}
				}
			}

			if ( ! empty( $delivery_caps ) || $has_pickup ) {
				$rows[] = array(
					'blog_id'       => (int) $site->blog_id,
					'name'          => get_bloginfo( 'name' ),
					'url'           => home_url( '/' ),
					'delivery_caps' => array_values( array_unique( $delivery_caps ) ),
					'pickup'        => $has_pickup,
				);
			}
		}
		restore_current_blog();
	}

	// Prefer the sede post title (CPT on the main site) over the raw blog name.
	$sede_query = new WP_Query( array( 'post_type' => 'sede', 'posts_per_page' => -1 ) );
	if ( $sede_query->have_posts() && function_exists( 'get_field' ) ) {
		$titles_by_host = array();
		foreach ( $sede_query->posts as $sede_post ) {
			$link = (string) get_field( 'link_per_questa_sede', $sede_post->ID );
			$host = wp_parse_url( $link, PHP_URL_HOST );
			if ( $host ) {
				$titles_by_host[ $host ] = get_the_title( $sede_post );
			}
		}
		foreach ( $rows as $i => $row ) {
			$host = wp_parse_url( $row['url'], PHP_URL_HOST );
			if ( $host && isset( $titles_by_host[ $host ] ) ) {
				$rows[ $i ]['name'] = $titles_by_host[ $host ];
			}
		}
	}
	wp_reset_postdata();

	set_site_transient( $cache_key, $rows, 10 * MINUTE_IN_SECONDS );
	return $rows;
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'wpadr/v1', '/delivery-caps', array(
		'methods'             => 'GET',
		'callback'            => 'WPADR_rest_delivery_caps',
		'permission_callback' => '__return_true',
	) );
} );
function WPADR_rest_delivery_caps( WP_REST_Request $request ) {
	$force = $request->get_param( 'refresh' ) && current_user_can( 'manage_options' );
	return rest_ensure_response( WPADR_get_network_delivery_caps( (bool) $force ) );
}

/**
 * [wpadr_cap_selector] — CAP input that routes visitors to the sede that
 * delivers to their postcode, reading directly from the shipping zones.
 * Supports exact codes, wildcards ("65*") and ranges ("6500...6599").
 */
add_shortcode( 'wpadr_cap_selector', 'WPADR_cap_selector_shortcode' );
function WPADR_cap_selector_shortcode( $atts ) {
	$atts = shortcode_atts( array(
		'placeholder'  => 'Inserisci il tuo CAP...',
		'no_delivery'  => 'Nessuna consegna a domicilio disponibile per questo CAP. Puoi ordinare con ritiro in sede:',
		'order_label'  => 'Ordina',
		'pickup_badge' => 'Solo Ritiro in Sede',
	), $atts, 'wpadr_cap_selector' );

	$sites = WPADR_get_network_delivery_caps();
	if ( empty( $sites ) ) {
		return '';
	}

	$payload = wp_json_encode( $sites );
	$uid     = 'wpadr-cap-' . wp_unique_id();

	ob_start();
	?>
	<div class="wpadr-cap-selector" id="<?php echo esc_attr( $uid ); ?>">
		<input type="text" inputmode="numeric" maxlength="4" class="wpadr-cap-input"
			placeholder="<?php echo esc_attr( $atts['placeholder'] ); ?>" aria-label="CAP" />
		<div class="wpadr-cap-results" role="region" aria-live="polite"></div>
	</div>
	<style>
		.wpadr-cap-selector .wpadr-cap-input{width:100%;max-width:420px;padding:12px 16px;font-size:1.1em;border:1px solid #ccc;border-radius:8px}
		.wpadr-cap-selector .wpadr-cap-card{display:flex;align-items:center;justify-content:space-between;gap:12px;border:1px solid #ddd;border-radius:8px;padding:14px 16px;margin-top:10px;max-width:420px}
		.wpadr-cap-selector .wpadr-cap-card a{white-space:nowrap}
		.wpadr-cap-selector .wpadr-cap-note{margin-top:10px;max-width:420px}
		.wpadr-cap-selector .wpadr-cap-badge{font-size:.85em;opacity:.75}
	</style>
	<script>
	(function(){
		var root = document.getElementById(<?php echo wp_json_encode( $uid ); ?>);
		if (!root) return;
		var SITES = <?php echo $payload; ?>;
		var LABELS = <?php echo wp_json_encode( array(
			'no_delivery'  => $atts['no_delivery'],
			'order_label'  => $atts['order_label'],
			'pickup_badge' => $atts['pickup_badge'],
		) ); ?>;
		var input = root.querySelector('.wpadr-cap-input');
		var results = root.querySelector('.wpadr-cap-results');

		function capMatches(code, cap){
			code = String(code).trim();
			if (code.indexOf('...') !== -1){
				var p = code.split('...');
				return cap >= p[0].trim() && cap <= p[1].trim();
			}
			if (code.slice(-1) === '*'){
				return cap.indexOf(code.slice(0, -1)) === 0;
			}
			return code === cap;
		}
		function card(site, badge){
			var div = document.createElement('div');
			div.className = 'wpadr-cap-card';
			var left = document.createElement('div');
			var strong = document.createElement('strong');
			strong.textContent = site.name;
			left.appendChild(strong);
			if (badge){
				var b = document.createElement('div');
				b.className = 'wpadr-cap-badge';
				b.textContent = badge;
				left.appendChild(b);
			}
			var a = document.createElement('a');
			a.href = site.url;
			a.className = 'wpadr-cap-order button';
			a.textContent = LABELS.order_label;
			div.appendChild(left);
			div.appendChild(a);
			return div;
		}
		function render(){
			var cap = input.value.replace(/\D/g, '');
			input.value = cap;
			results.textContent = '';
			if (cap.length !== 4) return;
			var delivering = SITES.filter(function(s){
				return (s.delivery_caps || []).some(function(c){ return capMatches(c, cap); });
			});
			if (delivering.length){
				delivering.forEach(function(s){ results.appendChild(card(s, null)); });
				return;
			}
			var note = document.createElement('p');
			note.className = 'wpadr-cap-note';
			note.textContent = LABELS.no_delivery;
			results.appendChild(note);
			SITES.filter(function(s){ return s.pickup; }).forEach(function(s){
				results.appendChild(card(s, LABELS.pickup_badge));
			});
		}
		input.addEventListener('input', render);
	})();
	</script>
	<?php
	return ob_get_clean();
}



/**
 * App payment methods per sede (v2.3.0)
 *
 * Lets the admin switch TWINT / payment on delivery on or off for each
 * sede of the app. Stored as a NETWORK option keyed by sede host (the
 * `siteId` the app already uses, e.g. "biasca.littleinka.ch"); the admin
 * page exists only on the brand hub (littleinka.ch).
 *
 *  - Admin page  Gestione App → Metodi di Pagamento
 *  - REST        GET mobile-admin/v1/payment-methods[?site=<host>]
 *
 * A sede without a saved row gets every method enabled, i.e. the app keeps
 * behaving exactly as before until something is switched off.
 */
/**
 * Payment methods the app supports. `provider` is who processes an online
 * payment (shown to the admin and returned by the REST endpoint); offline
 * methods have none. Filterable, so a new method or a provider switch only
 * needs to be declared here, never in the page markup.
 */
function ARD_payment_methods_catalog() {
	return apply_filters( 'ard_app_payment_methods_catalog', array(
		'twint'     => array(
			'label'    => 'TWINT',
			'type'     => 'online',
			'provider' => 'Datatrans',
		),
		'card'      => array(
			'label'    => 'Carta di credito/debito',
			'type'     => 'online',
			'provider' => 'Datatrans',
			'note'     => 'Visa e Mastercard',
		),
		'applepay'  => array(
			'label'    => 'Apple Pay',
			'type'     => 'online',
			'provider' => 'Datatrans',
			'note'     => 'Solo iPhone',
		),
		'googlepay' => array(
			'label'    => 'Google Pay',
			'type'     => 'online',
			'provider' => 'Datatrans',
			'note'     => 'Solo Android',
		),
		'cod'       => array(
			'label'    => 'Pagamento alla consegna',
			'type'     => 'offline',
			'provider' => '',
		),
	) );
}

/** "Online · Datatrans" / "Contanti o carta alla consegna" for the column header. */
function ARD_payment_methods_describe( array $method ) {
	if ( 'online' === $method['type'] ) {
		$text = $method['provider'] ? 'Online · ' . $method['provider'] : 'Online';
	} else {
		$text = 'Alla consegna / al ritiro';
	}
	return empty( $method['note'] ) ? $text : $text . ' · ' . $method['note'];
}

function ARD_payment_methods_normalize_host( $host ) {
	$host = strtolower( trim( (string) $host ) );
	$host = preg_replace( '#^https?://#', '', $host );
	return rtrim( $host, '/' );
}

/**
 * Sedi = subdomains with WooCommerce of the current site's brand domain
 * (*.littleinka.ch, from the hub or any sede), so other brands sharing the
 * network never show up. Returns [ host => label ].
 */
function ARD_payment_methods_sites() {
	if ( ! is_multisite() ) {
		$host = ARD_payment_methods_normalize_host( wp_parse_url( home_url( '/' ), PHP_URL_HOST ) );
		return array( $host => get_bloginfo( 'name' ) );
	}

	$current_host = (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST );
	$labels       = explode( '.', $current_host );
	$brand_domain = implode( '.', array_slice( $labels, -2 ) );

	global $wpdb;
	$sites = array();
	foreach ( get_sites( array( 'number' => 0, 'deleted' => 0, 'archived' => 0 ) ) as $site ) {
		$host = ARD_payment_methods_normalize_host( $site->domain );
		// Sedi are subdomains: the brand hub itself (littleinka.ch) is not one.
		if ( substr( $host, -strlen( '.' . $brand_domain ) ) !== '.' . $brand_domain ) {
			continue;
		}
		$table = $wpdb->get_blog_prefix( (int) $site->blog_id ) . 'woocommerce_shipping_zone_methods';
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) !== $table ) {
			continue;
		}
		$details        = get_blog_details( (int) $site->blog_id );
		$sites[ $host ] = $details && $details->blogname ? $details->blogname : $host;
	}
	return $sites;
}

/** Enabled flags for one sede host: [ method => bool ]. */
function ARD_payment_methods_for_host( $host ) {
	$saved  = (array) get_site_option( 'ard_app_payment_methods', array() );
	$host   = ARD_payment_methods_normalize_host( $host );
	$result = array();
	foreach ( array_keys( ARD_payment_methods_catalog() ) as $method ) {
		$result[ $method ] = isset( $saved[ $host ][ $method ] ) ? (bool) $saved[ $host ][ $method ] : true;
	}
	return $result;
}

/**
 * The setting is managed centrally from the brand hub only (littleinka.ch):
 * true on a site whose host has no subdomain part, or on a single install.
 */
function ARD_payment_methods_is_hub() {
	if ( ! is_multisite() ) {
		return true;
	}
	$host = ARD_payment_methods_normalize_host( wp_parse_url( home_url( '/' ), PHP_URL_HOST ) );
	return substr_count( $host, '.' ) === 1;
}

add_action( 'admin_menu', 'ARD_payment_methods_menu', 20 );
function ARD_payment_methods_menu() {
	if ( ! ARD_payment_methods_is_hub() ) {
		return;
	}
	add_submenu_page(
		'ard_stato_app',
		'Metodi di Pagamento',
		'Metodi di Pagamento',
		'manage_options',
		'ard_payment_methods',
		'ARD_showContent_payment_methods'
	);
}

function ARD_showContent_payment_methods() {
	if ( ! ARD_payment_methods_is_hub() || ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Pagina disponibile solo sul sito principale del brand.' );
	}
	$catalog = ARD_payment_methods_catalog();
	$sites   = ARD_payment_methods_sites();
	$errors  = array();

	if ( isset( $_POST['ard_payment_methods_nonce'] )
		&& wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ard_payment_methods_nonce'] ) ), 'ard_save_payment_methods' ) ) {
		$posted = isset( $_POST['ard_pm'] ) && is_array( $_POST['ard_pm'] ) ? wp_unslash( $_POST['ard_pm'] ) : array();
		$saved  = (array) get_site_option( 'ard_app_payment_methods', array() );

		foreach ( $sites as $host => $label ) {
			$row = array();
			foreach ( array_keys( $catalog ) as $method ) {
				$row[ $method ] = ! empty( $posted[ $host ][ $method ] );
			}
			// A sede with no method at all could never complete a checkout:
			// keep its previous settings and tell the admin.
			if ( ! in_array( true, $row, true ) ) {
				$errors[] = $label;
				continue;
			}
			$saved[ $host ] = $row;
		}

		update_site_option( 'ard_app_payment_methods', $saved );
		do_action( 'litespeed_purge_all' );

		if ( $errors ) {
			echo '<div class="notice notice-error"><p>Ogni sede deve avere almeno un metodo di pagamento attivo. Non salvate: <strong>' . esc_html( implode( ', ', $errors ) ) . '</strong></p></div>';
		} else {
			echo '<div class="notice notice-success"><p>Metodi di pagamento salvati. L\'app li applica dal prossimo carrello aperto.</p></div>';
		}
	}
	$icons = ARD_payment_methods_icons();
	?>
	<style>
		.ard-pm-wrap { max-width: 980px; }
		.ard-pm-wrap h1 { margin-bottom: 4px; }
		.ard-pm-intro { color: #50575e; margin: 0 0 18px; max-width: 760px; }
		.ard-pm-legend { display: flex; flex-wrap: wrap; gap: 10px; margin: 0 0 22px; }
		.ard-pm-legend-item { display: flex; align-items: center; gap: 10px; background: #fff; border: 1px solid #dcdcde; border-radius: 10px; padding: 8px 12px; min-width: 190px; }
		.ard-pm-legend-item strong { display: block; font-size: 13px; }
		.ard-pm-legend-item span { display: block; color: #646970; font-size: 12px; }
		.ard-pm-icon { width: 36px; height: 24px; border-radius: 6px; display: inline-flex; align-items: center; justify-content: center; flex: none; overflow: hidden; }
		.ard-pm-card { background: #fff; border: 1px solid #dcdcde; border-radius: 12px; padding: 16px 20px; margin-bottom: 12px; display: flex; flex-wrap: wrap; align-items: center; gap: 14px 24px; }
		.ard-pm-card.is-warning { border-color: #d63638; box-shadow: 0 0 0 1px #d63638 inset; }
		.ard-pm-site { flex: 1 1 240px; min-width: 200px; }
		.ard-pm-site strong { display: block; font-size: 15px; margin-bottom: 2px; }
		.ard-pm-site code { background: #f0f0f1; border-radius: 4px; padding: 1px 6px; font-size: 12px; }
		.ard-pm-count { color: #646970; font-size: 12px; margin-top: 6px; }
		.ard-pm-count.is-warning { color: #d63638; font-weight: 600; }
		.ard-pm-toggles { display: flex; flex-wrap: wrap; gap: 8px; flex: 2 1 520px; }
		.ard-pm-toggle { position: relative; display: inline-flex; align-items: center; gap: 8px; border: 1.5px solid #dcdcde; border-radius: 999px; padding: 6px 12px 6px 8px; background: #f6f7f7; cursor: pointer; user-select: none; transition: border-color .15s, background .15s; }
		.ard-pm-toggle input { position: absolute; opacity: 0; width: 0; height: 0; }
		.ard-pm-toggle .ard-pm-switch { width: 30px; height: 18px; border-radius: 999px; background: #c3c4c7; position: relative; transition: background .15s; flex: none; }
		.ard-pm-toggle .ard-pm-switch::after { content: ""; position: absolute; top: 2px; left: 2px; width: 14px; height: 14px; border-radius: 50%; background: #fff; box-shadow: 0 1px 2px rgba(0,0,0,.25); transition: left .15s; }
		.ard-pm-toggle .ard-pm-name { font-size: 13px; font-weight: 600; color: #1d2327; }
		.ard-pm-toggle.is-on { background: #fff; border-color: #1ca5a8; }
		.ard-pm-toggle.is-on .ard-pm-switch { background: #1ca5a8; }
		.ard-pm-toggle.is-on .ard-pm-switch::after { left: 14px; }
		.ard-pm-toggle:not(.is-on) .ard-pm-icon, .ard-pm-toggle:not(.is-on) .ard-pm-name { opacity: .55; }
		.ard-pm-toggle:focus-within { outline: 2px solid #1ca5a8; outline-offset: 1px; }
		.ard-pm-actions { display: flex; align-items: center; gap: 14px; margin-top: 18px; }
		.ard-pm-actions .button-primary { background: #1ca5a8; border-color: #1ca5a8; padding: 4px 22px; }
		.ard-pm-actions .button-primary:hover { background: #178a8d; border-color: #178a8d; }
		.ard-pm-unsaved { color: #996800; font-size: 13px; display: none; }
		@media (max-width: 782px) { .ard-pm-card { padding: 14px; } .ard-pm-toggles { flex-basis: 100%; } }
	</style>
	<div class="wrap ard-pm-wrap">
		<h1>Metodi di Pagamento App</h1>
		<p class="ard-pm-intro">Accendi o spegni i metodi che il carrello dell'app mostra per ogni sede. Ogni sede deve averne almeno uno attivo. Carta, Apple Pay e Google Pay compaiono nell'app dalla versione 3.2.0: le versioni precedenti mostrano solo TWINT e pagamento alla consegna.</p>

		<div class="ard-pm-legend">
			<?php foreach ( $catalog as $key => $method ) : ?>
				<div class="ard-pm-legend-item">
					<span class="ard-pm-icon"><?php echo isset( $icons[ $key ] ) ? $icons[ $key ] : ''; // phpcs:ignore WordPress.Security.EscapeOutput -- static inline SVG ?></span>
					<div>
						<strong><?php echo esc_html( $method['label'] ); ?></strong>
						<span><?php echo esc_html( ARD_payment_methods_describe( $method ) ); ?></span>
					</div>
				</div>
			<?php endforeach; ?>
		</div>

		<?php if ( empty( $sites ) ) : ?>
			<p><em>Nessuna sede con WooCommerce trovata su questo dominio.</em></p>
		<?php else : ?>
		<form method="post" id="ard-pm-form">
			<?php wp_nonce_field( 'ard_save_payment_methods', 'ard_payment_methods_nonce' ); ?>
			<?php foreach ( $sites as $host => $label ) :
				$enabled = ARD_payment_methods_for_host( $host );
				$active  = count( array_filter( $enabled ) ); ?>
				<div class="ard-pm-card<?php echo 0 === $active ? ' is-warning' : ''; ?>" data-host="<?php echo esc_attr( $host ); ?>">
					<div class="ard-pm-site">
						<strong><?php echo esc_html( $label ); ?></strong>
						<code><?php echo esc_html( $host ); ?></code>
						<div class="ard-pm-count<?php echo 0 === $active ? ' is-warning' : ''; ?>"><?php echo esc_html( sprintf( '%d di %d metodi attivi', $active, count( $catalog ) ) ); ?></div>
					</div>
					<div class="ard-pm-toggles">
						<?php foreach ( $catalog as $key => $method ) : ?>
							<label class="ard-pm-toggle<?php echo $enabled[ $key ] ? ' is-on' : ''; ?>" title="<?php echo esc_attr( ARD_payment_methods_describe( $method ) ); ?>">
								<input type="checkbox" name="ard_pm[<?php echo esc_attr( $host ); ?>][<?php echo esc_attr( $key ); ?>]" value="1" <?php checked( $enabled[ $key ] ); ?> />
								<span class="ard-pm-icon"><?php echo isset( $icons[ $key ] ) ? $icons[ $key ] : ''; // phpcs:ignore WordPress.Security.EscapeOutput -- static inline SVG ?></span>
								<span class="ard-pm-name"><?php echo esc_html( $method['label'] ); ?></span>
								<span class="ard-pm-switch" aria-hidden="true"></span>
							</label>
						<?php endforeach; ?>
					</div>
				</div>
			<?php endforeach; ?>
			<div class="ard-pm-actions">
				<?php submit_button( 'Salva metodi di pagamento', 'primary', 'submit', false ); ?>
				<span class="ard-pm-unsaved" id="ard-pm-unsaved">Modifiche non salvate</span>
			</div>
		</form>
		<script>
		(function () {
			var form = document.getElementById('ard-pm-form');
			if (!form) return;
			var total = <?php echo (int) count( $catalog ); ?>;
			form.addEventListener('change', function (e) {
				var input = e.target;
				if (!input || input.type !== 'checkbox') return;
				input.closest('.ard-pm-toggle').classList.toggle('is-on', input.checked);
				var card = input.closest('.ard-pm-card');
				var active = card.querySelectorAll('input[type=checkbox]:checked').length;
				var count = card.querySelector('.ard-pm-count');
				count.textContent = active + ' di ' + total + ' metodi attivi';
				count.classList.toggle('is-warning', active === 0);
				card.classList.toggle('is-warning', active === 0);
				document.getElementById('ard-pm-unsaved').style.display = 'inline';
			});
		})();
		</script>
		<?php endif; ?>
	</div>
	<?php
}

/** Small inline SVG badges for the payment methods (no external assets). */
function ARD_payment_methods_icons() {
	return array(
		'twint'     => '<svg width="36" height="24" viewBox="0 0 36 24" xmlns="http://www.w3.org/2000/svg"><rect width="36" height="24" rx="5" fill="#000"/><text x="18" y="15.5" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-size="8.5" font-weight="700" fill="#fff" letter-spacing=".5">TWINT</text></svg>',
		'card'      => '<svg width="36" height="24" viewBox="0 0 36 24" xmlns="http://www.w3.org/2000/svg"><rect width="36" height="24" rx="5" fill="#1a3b8f"/><rect x="0" y="6" width="36" height="4" fill="#0e2561"/><rect x="5" y="14" width="12" height="3" rx="1" fill="#fff" opacity=".9"/><rect x="21" y="14" width="10" height="3" rx="1" fill="#f5b800"/></svg>',
		'applepay'  => '<svg width="36" height="24" viewBox="0 0 36 24" xmlns="http://www.w3.org/2000/svg"><rect width="36" height="24" rx="5" fill="#000"/><path d="M12.6 8.1c.5-.6.8-1.4.7-2.2-.7 0-1.5.5-2 1.1-.4.5-.8 1.3-.7 2.1.8.1 1.5-.4 2-1zm.7 1.2c-1.1-.1-2 .6-2.5.6s-1.3-.6-2.2-.6c-1.1 0-2.2.7-2.8 1.7-1.2 2.1-.3 5.1.9 6.8.6.8 1.2 1.7 2.1 1.7.8 0 1.2-.5 2.2-.5s1.3.5 2.2.5 1.5-.8 2-1.7c.6-.9.9-1.9.9-1.9s-1.8-.7-1.8-2.7c0-1.7 1.4-2.5 1.4-2.5-.7-1.1-1.9-1.3-2.4-1.4z" fill="#fff"/><text x="25" y="16" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-size="9" font-weight="600" fill="#fff">Pay</text></svg>',
		'googlepay' => '<svg width="36" height="24" viewBox="0 0 36 24" xmlns="http://www.w3.org/2000/svg"><rect width="36" height="24" rx="5" fill="#fff" stroke="#dcdcde"/><circle cx="12" cy="12" r="5.5" fill="none" stroke="#4285f4" stroke-width="2.2" stroke-dasharray="20 15"/><circle cx="12" cy="12" r="5.5" fill="none" stroke="#34a853" stroke-width="2.2" stroke-dasharray="8 27" stroke-dashoffset="-22"/><circle cx="12" cy="12" r="5.5" fill="none" stroke="#fbbc05" stroke-width="2.2" stroke-dasharray="6 29" stroke-dashoffset="-30"/><circle cx="12" cy="12" r="5.5" fill="none" stroke="#ea4335" stroke-width="2.2" stroke-dasharray="8 27" stroke-dashoffset="-1"/><rect x="12" y="11" width="5" height="2.2" fill="#4285f4"/><text x="25.5" y="16" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-size="9" font-weight="600" fill="#5f6368">Pay</text></svg>',
		'cod'       => '<svg width="36" height="24" viewBox="0 0 36 24" xmlns="http://www.w3.org/2000/svg"><rect width="36" height="24" rx="5" fill="#2e7d32"/><rect x="7" y="7" width="22" height="11" rx="2" fill="#a5d6a7"/><circle cx="18" cy="12.5" r="3.2" fill="#2e7d32"/><rect x="9.5" y="9.5" width="2" height="6" fill="#2e7d32"/><rect x="24.5" y="9.5" width="2" height="6" fill="#2e7d32"/></svg>',
	);
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'mobile-admin/v1', '/payment-methods', array(
		'methods'             => 'GET',
		'callback'            => 'ARD_rest_get_payment_methods',
		'permission_callback' => '__return_true',
	) );
} );

/**
 * GET /wp-json/mobile-admin/v1/payment-methods?site=biasca.littleinka.ch
 *   → { "site": "biasca.littleinka.ch", "methods": { "twint": true, "cod": false },
 *       "catalog": { "twint": { "label", "type", "provider" }, ... } }
 * Without ?site: { "sites": { "<host>": { ... }, ... }, "catalog": ... }.
 */
function ARD_rest_get_payment_methods( WP_REST_Request $request ) {
	$site = $request->get_param( 'site' );
	if ( ! empty( $site ) ) {
		$host = ARD_payment_methods_normalize_host( $site );
		$data = array( 'site' => $host, 'methods' => ARD_payment_methods_for_host( $host ) );
	} else {
		$data = array( 'sites' => array() );
		foreach ( array_keys( ARD_payment_methods_sites() ) as $host ) {
			$data['sites'][ $host ] = ARD_payment_methods_for_host( $host );
		}
	}
	$data['catalog'] = ARD_payment_methods_catalog();

	// Must reflect a change immediately: never let LiteSpeed/CDN cache it.
	$response = rest_ensure_response( $data );
	$response->header( 'Cache-Control', 'no-cache, no-store, must-revalidate' );
	$response->header( 'X-LiteSpeed-Cache-Control', 'no-cache' );
	return $response;
}

/**
 * ------------------------------------------------------------------
 * Chiavi API WooCommerce per le Cloud Functions dell'app (v2.8.0)
 *
 * The Cloud Functions create the app's orders through the WooCommerce REST
 * API of every sede, so each sede needs a consumer key/secret pair. Until
 * 2.7.0 those pairs lived in two ACF fields of the "Sede" posts on the brand
 * hub, encrypted with a fixed key and served by a PUBLIC endpoint: on
 * 2026-11-06 the fields were trashed as "unused" and every app order failed.
 *
 * Now the keys are generated and kept here:
 *  - Admin page  Gestione App → Chiavi API (hub only, like Metodi di Pagamento):
 *                one row per sede, status, "Genera"/"Rigenera" buttons. The
 *                WooCommerce key is created directly in the sede's table, the
 *                admin never copies anything by hand.
 *  - Storage     NETWORK option `ard_app_wc_api_keys` [ host => {...} ],
 *                not autoloaded in the sedi (network options are read on demand).
 *  - REST        GET mobile-admin/v1/app-keys, only with header
 *                `X-App-Keys-Secret` equal to the shared secret
 *                (constant ARD_APP_KEYS_SECRET in wp-config.php, or network
 *                option `ard_app_keys_secret`, generated on first use and
 *                shown on the page so it can be put in the Cloud Functions env).
 * ------------------------------------------------------------------
 */

/** Shared secret the Cloud Functions must present to read the keys. */
function ARD_app_keys_secret() {
	if ( defined( 'ARD_APP_KEYS_SECRET' ) && ARD_APP_KEYS_SECRET !== '' ) {
		return (string) ARD_APP_KEYS_SECRET;
	}
	$secret = (string) get_site_option( 'ard_app_keys_secret', '' );
	if ( $secret === '' ) {
		$secret = wp_generate_password( 48, false, false );
		update_site_option( 'ard_app_keys_secret', $secret );
	}
	return $secret;
}

/** All saved keys: [ host => [ blog_id, key_id, consumer_key, consumer_secret, truncated, created, created_by ] ]. */
function ARD_app_keys_all() {
	$all = get_site_option( 'ard_app_wc_api_keys', array() );
	return is_array( $all ) ? $all : array();
}

/** blog_id of a sede host (0 when unknown). */
function ARD_app_keys_blog_id( $host ) {
	if ( ! is_multisite() ) {
		return get_current_blog_id();
	}
	$site = get_site_by_path( ARD_payment_methods_normalize_host( $host ), '/' );
	return $site ? (int) $site->blog_id : 0;
}

/** Same formulas WooCommerce uses (wc_rand_hash / wc_api_hash): the hub may not run WooCommerce. */
function ARD_app_keys_rand_hash() {
	if ( function_exists( 'wc_rand_hash' ) ) {
		return wc_rand_hash();
	}
	return function_exists( 'openssl_random_pseudo_bytes' )
		? bin2hex( openssl_random_pseudo_bytes( 20 ) )
		: sha1( wp_rand() );
}
function ARD_app_keys_api_hash( $data ) {
	return function_exists( 'wc_api_hash' ) ? wc_api_hash( $data ) : hash_hmac( 'sha256', $data, 'wc-api' );
}

/**
 * Live status of a sede's key, read from the sede's own WooCommerce table:
 * 'missing' (never generated), 'deleted' (removed in WooCommerce), 'ok'.
 */
function ARD_app_keys_status( $host ) {
	$all   = ARD_app_keys_all();
	$host  = ARD_payment_methods_normalize_host( $host );
	$saved = isset( $all[ $host ] ) && is_array( $all[ $host ] ) ? $all[ $host ] : null;
	if ( ! $saved || empty( $saved['key_id'] ) || empty( $saved['blog_id'] ) ) {
		return array( 'state' => 'missing', 'saved' => $saved, 'last_access' => '' );
	}
	global $wpdb;
	switch_to_blog( (int) $saved['blog_id'] );
	$row = $wpdb->get_row( $wpdb->prepare(
		"SELECT key_id, last_access, permissions FROM {$wpdb->prefix}woocommerce_api_keys WHERE key_id = %d",
		(int) $saved['key_id']
	) );
	restore_current_blog();
	if ( ! $row || $row->permissions !== 'read_write' ) {
		return array( 'state' => 'deleted', 'saved' => $saved, 'last_access' => '' );
	}
	return array( 'state' => 'ok', 'saved' => $saved, 'last_access' => (string) $row->last_access );
}

/**
 * Create a read/write WooCommerce key in the sede's table and save the pair.
 * A previous key generated by this page is deleted; keys created by hand in
 * WooCommerce are never touched. Returns the saved row or a WP_Error.
 */
function ARD_app_keys_generate( $host ) {
	$host    = ARD_payment_methods_normalize_host( $host );
	$blog_id = ARD_app_keys_blog_id( $host );
	if ( ! $blog_id ) {
		return new WP_Error( 'ard_no_site', 'Sede non trovata nel network: ' . $host );
	}
	global $wpdb;
	switch_to_blog( $blog_id );
	$table = $wpdb->prefix . 'woocommerce_api_keys';
	if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) !== $table ) {
		restore_current_blog();
		return new WP_Error( 'ard_no_wc', 'WooCommerce non è attivo su ' . $host );
	}
	// The key acts as this user in WooCommerce: reuse the user of the sede's
	// existing read/write key (a shop admin), otherwise the current admin.
	$user_id = (int) $wpdb->get_var( "SELECT user_id FROM {$table} WHERE permissions = 'read_write' ORDER BY key_id ASC LIMIT 1" );
	if ( ! $user_id || ! user_can( $user_id, 'manage_woocommerce' ) ) {
		$user_id = get_current_user_id();
	}
	$ck = 'ck_' . ARD_app_keys_rand_hash();
	$cs = 'cs_' . ARD_app_keys_rand_hash();
	$ok = $wpdb->insert(
		$table,
		array(
			'user_id'         => $user_id,
			'description'     => 'App mobile – Cloud Functions (Gestione App, ' . wp_date( 'd.m.Y H:i' ) . ')',
			'permissions'     => 'read_write',
			'consumer_key'    => ARD_app_keys_api_hash( $ck ),
			'consumer_secret' => $cs,
			'truncated_key'   => substr( $ck, -7 ),
		),
		array( '%d', '%s', '%s', '%s', '%s', '%s' )
	);
	$key_id = $ok ? (int) $wpdb->insert_id : 0;

	$all      = ARD_app_keys_all();
	$previous = isset( $all[ $host ] ) && is_array( $all[ $host ] ) ? $all[ $host ] : null;
	if ( $key_id && $previous && ! empty( $previous['key_id'] ) && (int) $previous['blog_id'] === $blog_id ) {
		$wpdb->delete( $table, array( 'key_id' => (int) $previous['key_id'] ), array( '%d' ) );
	}
	restore_current_blog();

	if ( ! $key_id ) {
		return new WP_Error( 'ard_insert_failed', 'WooCommerce non ha accettato la nuova chiave per ' . $host . ': ' . $wpdb->last_error );
	}
	$user         = get_userdata( get_current_user_id() );
	$all[ $host ] = array(
		'blog_id'         => $blog_id,
		'key_id'          => $key_id,
		'consumer_key'    => $ck,
		'consumer_secret' => $cs,
		'truncated'       => substr( $ck, -7 ),
		'created'         => current_time( 'mysql' ),
		'created_by'      => $user ? $user->display_name : '',
	);
	update_site_option( 'ard_app_wc_api_keys', $all );
	delete_site_transient( 'ard_app_keys_broken' );
	do_action( 'litespeed_purge_all' );
	return $all[ $host ];
}

add_action( 'admin_menu', 'ARD_app_keys_menu', 21 );
function ARD_app_keys_menu() {
	if ( ! ARD_payment_methods_is_hub() ) {
		return;
	}
	add_submenu_page(
		'ard_stato_app',
		'Chiavi API app',
		'Chiavi API app',
		'manage_options',
		'ard_app_keys',
		'ARD_showContent_app_keys'
	);
}

/** One red notice on the hub while a sede has no working key: the app cannot order there. */
add_action( 'admin_notices', 'ARD_app_keys_notice' );
add_action( 'network_admin_notices', 'ARD_app_keys_notice' );
function ARD_app_keys_notice() {
	if ( ! ARD_payment_methods_is_hub() || ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( isset( $_GET['page'] ) && 'ard_app_keys' === $_GET['page'] ) {
		return;
	}
	// One query per sede: cached 10 minutes, cleared whenever a key is generated.
	$broken = get_site_transient( 'ard_app_keys_broken' );
	if ( ! is_array( $broken ) ) {
		$broken = array();
		foreach ( ARD_payment_methods_sites() as $host => $label ) {
			$status = ARD_app_keys_status( $host );
			if ( 'ok' !== $status['state'] ) {
				$broken[] = $label;
			}
		}
		set_site_transient( 'ard_app_keys_broken', $broken, 10 * MINUTE_IN_SECONDS );
	}
	if ( ! $broken ) {
		return;
	}
	echo '<div class="notice notice-error"><p><strong>App mobile:</strong> manca la chiave API WooCommerce per <strong>' . esc_html( implode( ', ', $broken ) ) . '</strong>: da queste sedi l\'app non può ricevere ordini. <a href="' . esc_url( admin_url( 'admin.php?page=ard_app_keys' ) ) . '">Genera le chiavi</a>.</p></div>';
}

function ARD_showContent_app_keys() {
	if ( ! ARD_payment_methods_is_hub() || ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Pagina disponibile solo sul sito principale del brand.' );
	}
	$sites   = ARD_payment_methods_sites();
	$notices = array();

	if ( isset( $_POST['ard_app_keys_nonce'] )
		&& wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ard_app_keys_nonce'] ) ), 'ard_app_keys_action' ) ) {
		$targets = array();
		if ( ! empty( $_POST['ard_generate_host'] ) ) {
			$targets[] = ARD_payment_methods_normalize_host( sanitize_text_field( wp_unslash( $_POST['ard_generate_host'] ) ) );
		} elseif ( ! empty( $_POST['ard_generate_missing'] ) ) {
			foreach ( array_keys( $sites ) as $host ) {
				if ( 'ok' !== ARD_app_keys_status( $host )['state'] ) {
					$targets[] = $host;
				}
			}
		}
		foreach ( $targets as $host ) {
			if ( ! isset( $sites[ $host ] ) ) {
				continue;
			}
			$result = ARD_app_keys_generate( $host );
			if ( is_wp_error( $result ) ) {
				$notices[] = array( 'error', $result->get_error_message() );
			} else {
				$notices[] = array( 'success', 'Chiave generata per ' . $sites[ $host ] . ' (…' . $result['truncated'] . '). L\'app la usa entro pochi minuti, senza riavvii.' );
			}
		}
		if ( ! $targets ) {
			$notices[] = array( 'info', 'Tutte le sedi hanno già una chiave attiva.' );
		}
	}

	// Cloud Functions base URL (refunds and reconciliation call it, v2.11.0).
	if ( isset( $_POST['ard_functions_url_nonce'] )
		&& wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ard_functions_url_nonce'] ) ), 'ard_functions_url_save' ) ) {
		$url = untrailingslashit( esc_url_raw( trim( (string) wp_unslash( $_POST['ard_functions_url'] ?? '' ) ) ) );
		if ( '' !== $url && 0 !== strpos( $url, 'https://' ) ) {
			$notices[] = array( 'error', 'L\'indirizzo delle Cloud Functions deve iniziare con https://.' );
		} else {
			update_site_option( 'ard_app_functions_url', $url );
			$notices[] = array( 'success', '' === $url ? 'Indirizzo delle Cloud Functions rimosso: i rimborsi Datatrans dagli ordini sono disattivati.' : 'Indirizzo delle Cloud Functions salvato.' );
		}
	}

	$secret        = ARD_app_keys_secret();
	$endpoint      = rest_url( 'mobile-admin/v1/app-keys' );
	$functions_url = ARD_app_functions_url();
	?>
	<div class="wrap">
		<h1>Chiavi API app</h1>
		<p class="description" style="max-width:760px;">
			Per ricevere gli ordini dall'app, ogni sede deve avere una chiave WooCommerce dedicata. Qui le generi con un clic:
			la chiave viene creata direttamente in WooCommerce della sede e consegnata all'app in modo protetto.
			<strong>Non cancellare queste chiavi da WooCommerce → Impostazioni → Avanzate → REST API:</strong> l'app smetterebbe di ordinare da quella sede.
		</p>

		<?php foreach ( $notices as $n ) : ?>
			<div class="notice notice-<?php echo esc_attr( $n[0] ); ?>"><p><?php echo esc_html( $n[1] ); ?></p></div>
		<?php endforeach; ?>

		<?php if ( empty( $sites ) ) : ?>
			<p><em>Nessuna sede con WooCommerce trovata su questo dominio.</em></p>
		<?php else : ?>
		<form method="post">
			<?php wp_nonce_field( 'ard_app_keys_action', 'ard_app_keys_nonce' ); ?>
			<table class="widefat striped" style="max-width:900px;margin-top:16px;">
				<thead>
					<tr>
						<th>Sede</th>
						<th>Stato</th>
						<th>Chiave</th>
						<th style="width:160px;"></th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ( $sites as $host => $label ) :
					$status = ARD_app_keys_status( $host );
					$saved  = $status['saved'];
					$state  = $status['state'];
					$badge  = array(
						'ok'      => array( '#2e7d32', '✅ Attiva' ),
						'missing' => array( '#b00020', '⚠️ Mancante' ),
						'deleted' => array( '#b00020', '❌ Cancellata in WooCommerce' ),
					);
					?>
					<tr>
						<td><strong><?php echo esc_html( $label ); ?></strong><br/><code><?php echo esc_html( $host ); ?></code></td>
						<td style="vertical-align:middle;">
							<span style="font-weight:600;color:<?php echo esc_attr( $badge[ $state ][0] ); ?>;"><?php echo esc_html( $badge[ $state ][1] ); ?></span>
							<?php if ( 'ok' === $state ) : ?>
								<br/><span style="color:#646970;font-size:12px;">
									<?php echo $status['last_access'] && '0000-00-00 00:00:00' !== $status['last_access']
										? 'Ultimo uso dall\'app: ' . esc_html( wp_date( 'd.m.Y H:i', strtotime( $status['last_access'] ) ) )
										: 'Non ancora usata dall\'app'; ?>
								</span>
							<?php elseif ( 'deleted' === $state ) : ?>
								<br/><span style="color:#646970;font-size:12px;">Qualcuno l'ha eliminata da WooCommerce: rigenerala.</span>
							<?php else : ?>
								<br/><span style="color:#646970;font-size:12px;">L'app non può ordinare da questa sede finché non la generi.</span>
							<?php endif; ?>
						</td>
						<td style="vertical-align:middle;">
							<?php if ( $saved && ! empty( $saved['truncated'] ) ) : ?>
								<code>ck_…<?php echo esc_html( $saved['truncated'] ); ?></code>
								<br/><span style="color:#646970;font-size:12px;">creata il <?php echo esc_html( wp_date( 'd.m.Y', strtotime( $saved['created'] ) ) ); ?><?php echo $saved['created_by'] ? ' da ' . esc_html( $saved['created_by'] ) : ''; ?></span>
							<?php else : ?>
								<span style="color:#646970;">—</span>
							<?php endif; ?>
						</td>
						<td style="vertical-align:middle;">
							<button type="submit" name="ard_generate_host" value="<?php echo esc_attr( $host ); ?>" class="button <?php echo 'ok' === $state ? '' : 'button-primary'; ?>"
								<?php if ( 'ok' === $state ) : ?>onclick="return confirm('Rigenerare la chiave di <?php echo esc_js( $label ); ?>? Quella attuale viene sostituita.');"<?php endif; ?>>
								<?php echo 'ok' === $state ? 'Rigenera' : 'Genera chiave'; ?>
							</button>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<p style="margin-top:12px;">
				<button type="submit" name="ard_generate_missing" value="1" class="button button-primary">Genera tutte le chiavi mancanti</button>
			</p>
		</form>
		<?php endif; ?>

		<div class="card" style="max-width:860px;margin-top:24px;padding:16px 20px;">
			<h2 style="margin-top:0;">Collegamento con le Cloud Functions</h2>
			<p class="description">
				Le Cloud Functions dell'app leggono le chiavi da questo indirizzo presentando il segreto qui sotto.
				Il segreto va impostato una sola volta nella configurazione delle Cloud Functions (variabile <code>WP_APP_KEYS_SECRET</code>): serve solo a chi gestisce l'app, non ai clienti.
			</p>
			<table class="form-table" style="margin:0;">
				<tr>
					<th scope="row" style="width:160px;">Indirizzo</th>
					<td><code><?php echo esc_html( $endpoint ); ?></code></td>
				</tr>
				<tr>
					<th scope="row">Segreto</th>
					<td>
						<input type="password" id="ard-app-keys-secret" value="<?php echo esc_attr( $secret ); ?>" readonly class="regular-text" style="font-family:monospace;" />
						<button type="button" class="button" onclick="var i=document.getElementById('ard-app-keys-secret');i.type=i.type==='password'?'text':'password';this.textContent=i.type==='password'?'Mostra':'Nascondi';">Mostra</button>
						<button type="button" class="button" onclick="var i=document.getElementById('ard-app-keys-secret');i.type='text';i.select();document.execCommand('copy');i.type='password';this.textContent='Copiato';">Copia</button>
						<?php if ( defined( 'ARD_APP_KEYS_SECRET' ) && ARD_APP_KEYS_SECRET !== '' ) : ?>
							<p class="description">Definito in <code>wp-config.php</code> (costante <code>ARD_APP_KEYS_SECRET</code>).</p>
						<?php endif; ?>
					</td>
				</tr>
			</table>
		</div>

		<div class="card" style="max-width:860px;margin-top:24px;padding:16px 20px;">
			<h2 style="margin-top:0;">Rimborsi Datatrans dagli ordini</h2>
			<p class="description">
				Con l'indirizzo delle Cloud Functions, nella pagina di un ordine pagato nell'app compare «Rimborsa … tramite Datatrans» e ogni sede
				registra ogni ora gli storni fatti nel Webadmin Datatrans. Lo stesso segreto qui sopra protegge le chiamate.
			</p>
			<form method="post">
				<?php wp_nonce_field( 'ard_functions_url_save', 'ard_functions_url_nonce' ); ?>
				<table class="form-table" style="margin:0;">
					<tr>
						<th scope="row" style="width:160px;"><label for="ard-functions-url">Indirizzo delle Cloud Functions</label></th>
						<td>
							<input type="url" id="ard-functions-url" name="ard_functions_url" value="<?php echo esc_attr( $functions_url ); ?>" class="regular-text" style="font-family:monospace;width:420px;max-width:100%;" placeholder="https://europe-west1-<progetto>.cloudfunctions.net" <?php disabled( defined( 'ARD_APP_FUNCTIONS_URL' ) && ARD_APP_FUNCTIONS_URL !== '' ); ?> />
							<?php if ( defined( 'ARD_APP_FUNCTIONS_URL' ) && ARD_APP_FUNCTIONS_URL !== '' ) : ?>
								<p class="description">Definito in <code>wp-config.php</code> (costante <code>ARD_APP_FUNCTIONS_URL</code>).</p>
							<?php else : ?>
								<p class="description">Lo stesso indirizzo che usa l'app (Firebase → Functions, regione e progetto), senza percorso finale.</p>
							<?php endif; ?>
						</td>
					</tr>
				</table>
				<?php if ( ! ( defined( 'ARD_APP_FUNCTIONS_URL' ) && ARD_APP_FUNCTIONS_URL !== '' ) ) : ?>
					<p style="margin:12px 0 0;"><button type="submit" class="button button-primary">Salva indirizzo</button></p>
				<?php endif; ?>
			</form>
		</div>
	</div>
	<?php
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'mobile-admin/v1', '/app-keys', array(
		'methods'             => 'GET',
		'callback'            => 'ARD_rest_get_app_keys',
		'permission_callback' => 'ARD_rest_app_keys_permission',
	) );
} );

/**
 * This response carries secrets and must never be served from a cache, not
 * even its 403: LiteSpeed caches REST GETs by URL (hub: "Cache REST API" on)
 * and ignores a plain Cache-Control header set by the callback. Tell LSCWP
 * through its own control hook, then the X-LiteSpeed-Cache-Control header
 * becomes "no-cache" and the request bypasses the page cache.
 */
function ARD_app_keys_never_cache() {
	do_action( 'litespeed_control_set_nocache', 'mobile-admin app-keys: secrets' );
	nocache_headers();
}

/** Only the Cloud Functions, with the shared secret in the X-App-Keys-Secret header. */
function ARD_rest_app_keys_permission( WP_REST_Request $request ) {
	ARD_app_keys_never_cache();
	$given = (string) $request->get_header( 'x_app_keys_secret' );
	if ( '' === $given || ! hash_equals( ARD_app_keys_secret(), $given ) ) {
		return new WP_Error( 'ard_forbidden', 'Segreto mancante o errato.', array( 'status' => 403 ) );
	}
	return true;
}

/**
 * GET /wp-json/mobile-admin/v1/app-keys  (header X-App-Keys-Secret)
 *   → { "sites": { "<host>": { "url", "consumer_key", "consumer_secret", "key_id", "blog_id" }, ... } }
 * Only sedi whose key still exists in WooCommerce are returned.
 */
function ARD_rest_get_app_keys( WP_REST_Request $request ) {
	$data = array( 'sites' => array() );
	foreach ( array_keys( ARD_payment_methods_sites() ) as $host ) {
		$status = ARD_app_keys_status( $host );
		if ( 'ok' !== $status['state'] ) {
			continue;
		}
		$saved                  = $status['saved'];
		$data['sites'][ $host ] = array(
			'url'             => 'https://' . $host,
			'consumer_key'    => $saved['consumer_key'],
			'consumer_secret' => $saved['consumer_secret'],
			'key_id'          => (int) $saved['key_id'],
			'blog_id'         => (int) $saved['blog_id'],
		);
	}
	$response = rest_ensure_response( $data );
	$response->header( 'Cache-Control', 'no-cache, no-store, must-revalidate, private' );
	$response->header( 'X-LiteSpeed-Cache-Control', 'no-cache' );
	return $response;
}

/**
 * ------------------------------------------------------------------
 * Collegamento app (universal link / App Link) — v2.10.0
 *
 * The Datatrans Mobile SDK refuses card payments unless the app has an
 * https callback URL that is a verified universal link (iOS) / App Link
 * (Android): after 3-D Secure the bank's page hands control back to the
 * app through it. Verification needs two files on the brand domain:
 *   https://<hub>/.well-known/apple-app-site-association
 *   https://<hub>/.well-known/assetlinks.json
 * Both are served here from the settings saved on Gestione App →
 * Collegamento app (hub only), so nobody has to upload files by FTP, and
 * the path itself (/app/pagamento) shows a "torna all'app" page in case
 * it is opened in a browser. Settings live in the NETWORK option
 * `ard_app_links` (not autoloaded in the sedi).
 * ------------------------------------------------------------------
 */

function ARD_app_links_defaults() {
	return array(
		'path'          => '/app/pagamento',
		'ios_team_id'   => '',
		'ios_bundle_id' => '',
		'android_package' => '',
		'android_sha256'  => '',
		'app_name'      => '',
	);
}

function ARD_app_links_settings() {
	$saved = get_site_option( 'ard_app_links', array() );
	return array_merge( ARD_app_links_defaults(), is_array( $saved ) ? $saved : array() );
}

/** Normalised path of the return page: always starts with "/", never ends with one. */
function ARD_app_links_path( $settings = null ) {
	$settings = $settings ?: ARD_app_links_settings();
	$path     = '/' . trim( (string) $settings['path'], '/ ' );
	return '/' === $path ? '/app/pagamento' : $path;
}

/** SHA-256 fingerprints as Android wants them: uppercase, colon separated, one per line in the field. */
function ARD_app_links_fingerprints( $settings = null ) {
	$settings = $settings ?: ARD_app_links_settings();
	$out      = array();
	foreach ( preg_split( '/[\s,]+/', (string) $settings['android_sha256'] ) as $fp ) {
		$fp = strtoupper( preg_replace( '/[^0-9a-fA-F]/', '', $fp ) );
		if ( 64 === strlen( $fp ) ) {
			$out[] = implode( ':', str_split( $fp, 2 ) );
		}
	}
	return array_values( array_unique( $out ) );
}

/** The two association files, as PHP arrays (empty when not configured). */
function ARD_app_links_aasa( $settings = null ) {
	$settings = $settings ?: ARD_app_links_settings();
	if ( '' === $settings['ios_team_id'] || '' === $settings['ios_bundle_id'] ) {
		return null;
	}
	$app_id = $settings['ios_team_id'] . '.' . $settings['ios_bundle_id'];
	$path   = ARD_app_links_path( $settings );
	return array(
		'applinks' => array(
			'apps'    => array(),
			'details' => array(
				array(
					'appID' => $app_id,
					'paths' => array( $path, $path . '/*' ),
				),
			),
		),
	);
}

function ARD_app_links_assetlinks( $settings = null ) {
	$settings     = $settings ?: ARD_app_links_settings();
	$fingerprints = ARD_app_links_fingerprints( $settings );
	if ( '' === $settings['android_package'] || ! $fingerprints ) {
		return null;
	}
	return array(
		array(
			'relation' => array( 'delegate_permission/common.handle_all_urls' ),
			'target'   => array(
				'namespace'                => 'android_app',
				'package_name'             => $settings['android_package'],
				'sha256_cert_fingerprints' => $fingerprints,
			),
		),
	);
}

/**
 * Serve the association files and the return page before WordPress looks
 * for a post: Apple and Google fetch them with no redirect allowed, as
 * application/json, and they must be identical on every request. Only on
 * the hub: the sedi share the plugin but not the domain.
 */
add_action( 'parse_request', 'ARD_app_links_serve', 1 );
function ARD_app_links_serve( $wp ) {
	if ( ! ARD_payment_methods_is_hub() ) {
		return;
	}
	$uri  = (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH );
	$uri  = '/' . trim( $uri, '/' );
	$json = null;
	if ( '/.well-known/apple-app-site-association' === $uri ) {
		$json = ARD_app_links_aasa();
	} elseif ( '/.well-known/assetlinks.json' === $uri ) {
		$json = ARD_app_links_assetlinks();
	}
	if ( null !== $json ) {
		nocache_headers();
		status_header( 200 );
		header( 'Content-Type: application/json; charset=utf-8' );
		echo wp_json_encode( $json, JSON_UNESCAPED_SLASHES );
		exit;
	}
	if ( null === $json && 0 === strpos( $uri, '/.well-known/' ) ) {
		return; // other .well-known paths (ACME challenges…) are not ours.
	}
	$path = ARD_app_links_path();
	if ( $uri === $path || 0 === strpos( $uri, $path . '/' ) ) {
		ARD_app_links_return_page();
		exit;
	}
}

/** Shown only when the link is opened in a browser (app missing or link not verified). */
function ARD_app_links_return_page() {
	$settings = ARD_app_links_settings();
	$name     = $settings['app_name'] !== '' ? $settings['app_name'] : get_bloginfo( 'name' );
	nocache_headers();
	status_header( 200 );
	header( 'Content-Type: text/html; charset=utf-8' );
	header( 'X-Robots-Tag: noindex, nofollow' );
	?>
<!DOCTYPE html>
<html lang="<?php echo esc_attr( substr( get_locale(), 0, 2 ) ); ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?php echo esc_html( $name ); ?></title>
<style>
body{margin:0;font-family:-apple-system,system-ui,"Segoe UI",Roboto,sans-serif;background:#f6f7f8;color:#1d2327;display:flex;min-height:100vh;align-items:center;justify-content:center;text-align:center;padding:24px;box-sizing:border-box}
.card{background:#fff;border-radius:16px;padding:40px 28px;max-width:420px;width:100%;box-shadow:0 4px 16px rgba(0,0,0,.08)}
h1{font-size:22px;margin:0 0 10px}p{color:#50575e;line-height:1.5;margin:0 0 24px}
.ok{font-size:56px;margin-bottom:16px}
</style>
</head>
<body>
<div class="card">
	<div class="ok">✅</div>
	<h1><?php echo esc_html( sprintf( __( 'Torna all\'app %s', 'wp-app-dashboard' ), $name ) ); ?></h1>
	<p><?php esc_html_e( 'Il pagamento è stato verificato. Chiudi questa pagina e torna all\'app per vedere l\'esito del tuo ordine.', 'wp-app-dashboard' ); ?></p>
</div>
</body>
</html>
	<?php
}

add_action( 'admin_menu', 'ARD_app_links_menu', 22 );
function ARD_app_links_menu() {
	if ( ! ARD_payment_methods_is_hub() ) {
		return;
	}
	add_submenu_page(
		'ard_stato_app',
		'Collegamento app',
		'Collegamento app',
		'manage_options',
		'ard_app_links',
		'ARD_showContent_app_links'
	);
}

function ARD_showContent_app_links() {
	if ( ! ARD_payment_methods_is_hub() || ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Pagina disponibile solo sul sito principale del brand.' );
	}
	$notice = null;
	if ( isset( $_POST['ard_app_links_nonce'] )
		&& wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ard_app_links_nonce'] ) ), 'ard_app_links_save' ) ) {
		$in       = isset( $_POST['ard_app_links'] ) && is_array( $_POST['ard_app_links'] ) ? wp_unslash( $_POST['ard_app_links'] ) : array();
		$settings = array(
			'path'            => '/' . trim( sanitize_text_field( $in['path'] ?? '' ), '/ ' ),
			'ios_team_id'     => strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) ( $in['ios_team_id'] ?? '' ) ) ),
			'ios_bundle_id'   => preg_replace( '/[^A-Za-z0-9.\-]/', '', (string) ( $in['ios_bundle_id'] ?? '' ) ),
			'android_package' => preg_replace( '/[^A-Za-z0-9._]/', '', (string) ( $in['android_package'] ?? '' ) ),
			'android_sha256'  => implode( "\n", ARD_app_links_fingerprints( array( 'android_sha256' => (string) ( $in['android_sha256'] ?? '' ) ) ) ),
			'app_name'        => sanitize_text_field( $in['app_name'] ?? '' ),
		);
		if ( '/' === $settings['path'] ) {
			$settings['path'] = '/app/pagamento';
		}
		update_site_option( 'ard_app_links', $settings );
		do_action( 'litespeed_purge_all' );
		$notice = 'Impostazioni salvate. I file di verifica sono aggiornati: Apple li rilegge quando l\'app viene installata, Google alla prima apertura.';
	}
	$s        = ARD_app_links_settings();
	$home     = home_url( '/' );
	$link     = untrailingslashit( $home ) . ARD_app_links_path( $s );
	$aasa_ok  = null !== ARD_app_links_aasa( $s );
	$links_ok = null !== ARD_app_links_assetlinks( $s );
	?>
	<div class="wrap">
		<h1>Collegamento app</h1>
		<p class="description" style="max-width:760px;">
			Dopo la verifica della carta (3-D Secure) la banca deve riportare il cliente nell'app: serve un indirizzo di questo sito collegato all'app
			(«universal link» su iPhone, «App Link» su Android). Compila i dati qui sotto e questo sito pubblica da solo i file di verifica che Apple e Google richiedono.
		</p>
		<?php if ( $notice ) : ?><div class="notice notice-success"><p><?php echo esc_html( $notice ); ?></p></div><?php endif; ?>

		<form method="post">
			<?php wp_nonce_field( 'ard_app_links_save', 'ard_app_links_nonce' ); ?>
			<table class="form-table" style="max-width:860px;">
				<tr>
					<th scope="row"><label for="ard-al-path">Indirizzo di ritorno</label></th>
					<td>
						<code><?php echo esc_html( untrailingslashit( $home ) ); ?></code>
						<input type="text" id="ard-al-path" name="ard_app_links[path]" value="<?php echo esc_attr( ARD_app_links_path( $s ) ); ?>" class="regular-text" style="width:220px;" />
						<p class="description">Lo stesso indirizzo va impostato nell'app (opzione <code>appLinkUrl</code>): <code><?php echo esc_html( $link ); ?></code></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="ard-al-name">Nome dell'app</label></th>
					<td><input type="text" id="ard-al-name" name="ard_app_links[app_name]" value="<?php echo esc_attr( $s['app_name'] ); ?>" class="regular-text" placeholder="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" />
					<p class="description">Mostrato nella pagina «Torna all'app» se il link viene aperto nel browser.</p></td>
				</tr>
				<tr><th colspan="2" style="padding-bottom:0;"><h2 style="margin:0;">iPhone</h2></th></tr>
				<tr>
					<th scope="row"><label for="ard-al-team">Apple Team ID</label></th>
					<td><input type="text" id="ard-al-team" name="ard_app_links[ios_team_id]" value="<?php echo esc_attr( $s['ios_team_id'] ); ?>" class="regular-text" style="width:160px;font-family:monospace;" placeholder="ABCDE12345" />
					<p class="description">Apple Developer → Membership details → Team ID (10 caratteri).</p></td>
				</tr>
				<tr>
					<th scope="row"><label for="ard-al-bundle">Bundle ID dell'app</label></th>
					<td><input type="text" id="ard-al-bundle" name="ard_app_links[ios_bundle_id]" value="<?php echo esc_attr( $s['ios_bundle_id'] ); ?>" class="regular-text" style="font-family:monospace;" placeholder="ch.esempio.app" /></td>
				</tr>
				<tr><th colspan="2" style="padding-bottom:0;"><h2 style="margin:0;">Android</h2></th></tr>
				<tr>
					<th scope="row"><label for="ard-al-package">Package dell'app</label></th>
					<td><input type="text" id="ard-al-package" name="ard_app_links[android_package]" value="<?php echo esc_attr( $s['android_package'] ); ?>" class="regular-text" style="font-family:monospace;" placeholder="ch.esempio.app" /></td>
				</tr>
				<tr>
					<th scope="row"><label for="ard-al-sha">Impronte SHA-256 del certificato</label></th>
					<td><textarea id="ard-al-sha" name="ard_app_links[android_sha256]" rows="3" class="large-text code" placeholder="AA:BB:CC:…"><?php echo esc_textarea( $s['android_sha256'] ); ?></textarea>
					<p class="description">Google Play Console → Configurazione → Firma dell'app → «Impronta del certificato SHA-256» della chiave di firma dell'app. Una per riga (puoi aggiungere anche quella della chiave di caricamento).</p></td>
				</tr>
			</table>
			<?php submit_button( 'Salva' ); ?>
		</form>

		<div class="card" style="max-width:860px;margin-top:8px;padding:16px 20px;">
			<h2 style="margin-top:0;">File pubblicati</h2>
			<table class="widefat striped">
				<tbody>
					<tr>
						<td style="width:40%;"><a href="<?php echo esc_url( untrailingslashit( $home ) . '/.well-known/apple-app-site-association' ); ?>" target="_blank" rel="noopener">/.well-known/apple-app-site-association</a></td>
						<td><?php echo $aasa_ok ? '<span style="color:#2e7d32;font-weight:600;">✅ Pubblicato</span>' : '<span style="color:#b00020;font-weight:600;">⚠️ Mancano Team ID o Bundle ID</span>'; ?></td>
					</tr>
					<tr>
						<td><a href="<?php echo esc_url( untrailingslashit( $home ) . '/.well-known/assetlinks.json' ); ?>" target="_blank" rel="noopener">/.well-known/assetlinks.json</a></td>
						<td><?php echo $links_ok ? '<span style="color:#2e7d32;font-weight:600;">✅ Pubblicato</span>' : '<span style="color:#b00020;font-weight:600;">⚠️ Mancano package o impronta SHA-256</span>'; ?></td>
					</tr>
					<tr>
						<td><a href="<?php echo esc_url( $link ); ?>" target="_blank" rel="noopener"><?php echo esc_html( ARD_app_links_path( $s ) ); ?></a></td>
						<td>Pagina «Torna all'app» (vista solo nel browser)</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
	<?php
}

/**
 * ------------------------------------------------------------------
 * Rimborsi Datatrans dall'ordine WooCommerce — v2.11.0
 *
 * App orders paid through Datatrans carry `_datatrans_transaction_id`
 * (v2, UUID-like) on the WooCommerce order. A refund-only payment gateway
 * ("Datatrans") gives the order page WooCommerce's own "Rimborsa X CHF
 * tramite Datatrans" button: WooCommerce computes the amount from the
 * selected items, the gateway asks the app's Cloud Functions to credit the
 * transaction (the Datatrans credentials stay there), and WooCommerce
 * records the refund. The gateway is never offered at checkout.
 *
 * WooCommerce finds the gateway by `$order->get_payment_method()`, which
 * for app orders is a label ("Applicazione Mobile - Pagamento con TWINT"):
 * the getter is rerouted to this gateway only while the refund panel is
 * rendered and while the refund AJAX runs, so nothing else changes.
 *
 * Refunds made in Datatrans Webadmin send no webhook: an hourly cron on
 * every sede asks the Cloud Functions for the refunded amount of recent
 * orders and mirrors the difference as a WooCommerce refund.
 * ------------------------------------------------------------------
 */

/** Base URL of the app's Cloud Functions (Gestione App → Chiavi API app). */
function ARD_app_functions_url() {
	if ( defined( 'ARD_APP_FUNCTIONS_URL' ) && ARD_APP_FUNCTIONS_URL !== '' ) {
		return untrailingslashit( (string) ARD_APP_FUNCTIONS_URL );
	}
	return untrailingslashit( (string) get_site_option( 'ard_app_functions_url', '' ) );
}

/** The v2 Datatrans transaction id of an order, or '' (v1 numeric ids cannot be refunded from here). */
function ARD_datatrans_transaction_id( $order ) {
	$id = $order instanceof WC_Order ? (string) $order->get_meta( '_datatrans_transaction_id' ) : '';
	return ( '' !== $id && ! ctype_digit( $id ) ) ? $id : '';
}

/**
 * Call one of the refund routes of the Cloud Functions. Returns the decoded
 * body or a WP_Error whose message is meant for the shop admin.
 */
function ARD_datatrans_functions_call( $route, array $body ) {
	$base = ARD_app_functions_url();
	if ( '' === $base ) {
		return new WP_Error( 'ard_no_functions_url', 'Indirizzo delle Cloud Functions non impostato: Gestione App → Chiavi API app sul sito principale.' );
	}
	$response = wp_remote_post(
		$base . '/datatrans' . $route,
		array(
			'timeout' => 45,
			'headers' => array(
				'Content-Type'      => 'application/json',
				'X-App-Keys-Secret' => ARD_app_keys_secret(),
			),
			'body'    => wp_json_encode( $body ),
		)
	);
	if ( is_wp_error( $response ) ) {
		return new WP_Error( 'ard_functions_unreachable', 'Cloud Functions non raggiungibili: ' . $response->get_error_message() );
	}
	$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
	$code = (int) wp_remote_retrieve_response_code( $response );
	if ( 200 !== $code || ! is_array( $data ) ) {
		$message = is_array( $data ) && ! empty( $data['message'] ) ? (string) $data['message'] : 'risposta ' . $code;
		return new WP_Error( 'ard_functions_error', $message );
	}
	return $data;
}

add_action( 'plugins_loaded', 'ARD_datatrans_gateway_boot', 20 );
function ARD_datatrans_gateway_boot() {
	if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
		return;
	}

	class ARD_Datatrans_Refund_Gateway extends WC_Payment_Gateway {
		public function __construct() {
			$this->id                 = 'ard_datatrans';
			$this->method_title       = 'Datatrans (app mobile) — lasciare INATTIVO';
			$this->method_description = 'NON ATTIVARE: non è un metodo di pagamento del sito e non compare mai nel checkout. Serve solo a far comparire il pulsante «Rimborsa tramite Datatrans» sugli ordini pagati nell\'app (TWINT, carta, Apple Pay, Google Pay). Per i pagamenti del sito usa i metodi «Datatrans — …» del plugin Datatrans by ticinoWEB. Anche se viene abilitato, resta disattivato.';
			$this->title              = 'Datatrans';
			$this->has_fields         = false;
			$this->supports           = array( 'refunds' );
			// Always off at checkout, whatever the stored option says: the refund
			// button only needs the gateway to exist.
			$this->enabled            = 'no';
			$this->form_fields        = array(
				'info' => array(
					'title'       => 'Nessuna impostazione',
					'type'        => 'title',
					'description' => 'Questo metodo deve restare inattivo: lavora da solo sugli ordini dell\'app. Le credenziali Datatrans sono nelle Cloud Functions dell\'app (Gestione App → Chiavi API app sul sito principale).',
				),
			);
		}

		/** Never at checkout. */
		public function is_available() {
			return false;
		}

		public function can_refund_order( $order ) {
			return $order instanceof WC_Order && '' !== ARD_datatrans_transaction_id( $order );
		}

		/** Called by WooCommerce from the "Rimborsa … tramite Datatrans" button. */
		public function process_refund( $order_id, $amount = null, $reason = '' ) {
			$order = wc_get_order( $order_id );
			$txid  = $order ? ARD_datatrans_transaction_id( $order ) : '';
			if ( '' === $txid ) {
				return new WP_Error( 'ard_not_refundable', 'Questo ordine non ha una transazione Datatrans rimborsabile da qui: usa il Webadmin Datatrans.' );
			}
			$cents = (int) round( (float) $amount * 100 );
			if ( $cents <= 0 ) {
				return new WP_Error( 'ard_bad_amount', 'Importo del rimborso non valido.' );
			}
			$result = ARD_datatrans_functions_call(
				'/refund',
				array(
					'transactionId' => $txid,
					'amount'        => $cents,
					'reason'        => (string) $reason,
					'orderId'       => (string) $order->get_order_number(),
					'siteId'        => (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ),
				)
			);
			if ( is_wp_error( $result ) ) {
				$order->add_order_note( 'Rimborso Datatrans NON eseguito: ' . $result->get_error_message() );
				return $result;
			}
			$order->add_order_note( sprintf(
				'Rimborso di %s eseguito su Datatrans (transazione %s). Totale rimborsato su Datatrans: %s.',
				wc_price( $cents / 100, array( 'currency' => $order->get_currency() ) ),
				$txid,
				wc_price( ( (int) ( $result['refundedAmount'] ?? 0 ) ) / 100, array( 'currency' => $order->get_currency() ) )
			) );
			$order->update_meta_data( '_datatrans_refunded_amount', (int) ( $result['refundedAmount'] ?? 0 ) );
			$order->update_meta_data( '_ard_datatrans_checked', time() );
			$order->save();
			return true;
		}
	}

	add_filter( 'woocommerce_payment_gateways', function ( $gateways ) {
		$gateways[] = 'ARD_Datatrans_Refund_Gateway';
		return $gateways;
	} );
}

/** True while WooCommerce is rendering the refund panel or running the refund AJAX. */
function ARD_datatrans_refund_context( $set = null ) {
	static $on = false;
	if ( null !== $set ) {
		$on = (bool) $set;
	}
	return $on;
}
// The items box resolves the gateway at the top of its template, before
// any of its own hooks: switch the context on at the end of the "Dettagli
// ordine" box (rendered first, and after its payment-method dropdown, which
// must keep showing the app's label).
add_action( 'woocommerce_admin_order_data_after_order_details', function () {
	ARD_datatrans_refund_context( true );
}, 1 );
add_action( 'woocommerce_order_item_add_line_buttons', function () {
	ARD_datatrans_refund_context( true );
}, 1 );
add_action( 'wp_ajax_woocommerce_refund_line_items', function () {
	ARD_datatrans_refund_context( true );
}, 1 );
add_filter( 'woocommerce_order_get_payment_method', function ( $value, $order ) {
	if ( ARD_datatrans_refund_context() && $order instanceof WC_Order && '' !== ARD_datatrans_transaction_id( $order ) ) {
		return 'ard_datatrans';
	}
	return $value;
}, 10, 2 );

/* ---------- Riconciliazione oraria degli storni fatti in Webadmin ---------- */

add_action( 'init', 'ARD_datatrans_reconcile_schedule' );
function ARD_datatrans_reconcile_schedule() {
	if ( ! function_exists( 'wc_get_orders' ) || ARD_payment_methods_is_hub() ) {
		return;
	}
	if ( ! wp_next_scheduled( 'ard_datatrans_reconcile' ) ) {
		wp_schedule_event( time() + 5 * MINUTE_IN_SECONDS, 'hourly', 'ard_datatrans_reconcile' );
	}
}

add_action( 'ard_datatrans_reconcile', 'ARD_datatrans_reconcile_run' );
/**
 * Orders of the last 30 days paid through Datatrans, at most 150 per run and
 * each one at most every 6 hours: when Datatrans reports more refunded than
 * WooCommerce knows, the difference becomes a WooCommerce refund (money
 * already returned by Webadmin, so `refund_payment` is false) with a note.
 */
function ARD_datatrans_reconcile_run() {
	if ( ! function_exists( 'wc_get_orders' ) || '' === ARD_app_functions_url() ) {
		return;
	}
	if ( get_transient( 'ard_datatrans_reconcile_lock' ) ) {
		return;
	}
	set_transient( 'ard_datatrans_reconcile_lock', 1, 10 * MINUTE_IN_SECONDS );

	$orders = wc_get_orders( array(
		'limit'        => 150,
		'status'       => array( 'processing', 'completed', 'on-hold', 'refunded' ),
		'date_created' => '>' . ( time() - 30 * DAY_IN_SECONDS ),
		'orderby'      => 'date',
		'order'        => 'DESC',
		'meta_query'   => array( array( 'key' => '_datatrans_transaction_id', 'compare' => 'EXISTS' ) ),
	) );
	$by_tx = array();
	foreach ( $orders as $order ) {
		$txid = ARD_datatrans_transaction_id( $order );
		if ( '' === $txid ) {
			continue;
		}
		if ( (int) $order->get_meta( '_ard_datatrans_checked' ) > time() - 6 * HOUR_IN_SECONDS ) {
			continue;
		}
		$by_tx[ $txid ] = $order;
	}
	if ( ! $by_tx ) {
		delete_transient( 'ard_datatrans_reconcile_lock' );
		return;
	}

	$result = ARD_datatrans_functions_call( '/refund-state', array( 'transactionIds' => array_keys( $by_tx ) ) );
	if ( is_wp_error( $result ) ) {
		error_log( 'mobile-admin: riconciliazione Datatrans non riuscita: ' . $result->get_error_message() );
		delete_transient( 'ard_datatrans_reconcile_lock' );
		return;
	}
	$states = isset( $result['states'] ) && is_array( $result['states'] ) ? $result['states'] : array();
	foreach ( $by_tx as $txid => $order ) {
		$state = $states[ $txid ] ?? null;
		if ( ! is_array( $state ) ) {
			continue; // lookup failed: retry next run
		}
		$dt_refunded = ( (int) $state['refundedAmount'] ) / 100;
		$wc_refunded = (float) $order->get_total_refunded();
		$diff        = round( $dt_refunded - $wc_refunded, 2 );
		if ( $diff >= 0.01 ) {
			$voided = ! empty( $state['voided'] );
			$refund = wc_create_refund( array(
				'amount'         => min( $diff, (float) $order->get_total() - $wc_refunded ),
				'reason'         => $voided ? 'Annullato su Datatrans (Webadmin) prima dell\'incasso' : 'Stornato da Datatrans (Webadmin)',
				'order_id'       => $order->get_id(),
				'refund_payment' => false,
				'restock_items'  => false,
			) );
			if ( is_wp_error( $refund ) ) {
				error_log( 'mobile-admin: rimborso WooCommerce non creato per ordine ' . $order->get_id() . ': ' . $refund->get_error_message() );
				continue;
			}
			$order->add_order_note( sprintf(
				$voided
					? 'Pagamento di %s annullato su Datatrans (Webadmin) prima dell\'incasso: il cliente non è stato addebitato, registrato come rimborso.'
					: 'Storno di %s trovato su Datatrans (fatto dal Webadmin): registrato in WooCommerce.',
				wc_price( $diff, array( 'currency' => $order->get_currency() ) )
			) );
		}
		$order->update_meta_data( '_datatrans_refunded_amount', (int) $state['refundedAmount'] );
		$order->update_meta_data( '_ard_datatrans_checked', time() );
		$order->save();
	}
	delete_transient( 'ard_datatrans_reconcile_lock' );
}

register_deactivation_hook( __FILE__, function () {
	wp_clear_scheduled_hook( 'ard_datatrans_reconcile' );
} );

/**
 * ------------------------------------------------------------------
 * Gestione Woo → Metodi di pagamento web — v2.12.0
 *
 * The web shop of every sede pays through the "Datatrans by ticinoWEB"
 * plugin (tw-datatrans). This page, on the brand hub only, manages it for
 * all sedi at once: one Datatrans account (saved as the network option the
 * plugin reads, `tw_datatrans_network_settings`), the plugin activated per
 * sede with a click, and the four methods (TWINT, card, Apple Pay, Google
 * Pay) switched on or off per sede by writing each sede's WooCommerce
 * gateway option. Nothing here needs WooCommerce on the hub.
 * ------------------------------------------------------------------
 */

const ARD_WEBPM_PLUGIN = 'tw-datatrans/tw-datatrans.php';

function ARD_webpm_catalog() {
	return array(
		'twint'     => array( 'label' => 'TWINT', 'icon' => 'twint' ),
		'card'      => array( 'label' => 'Carta', 'icon' => 'card' ),
		'applepay'  => array( 'label' => 'Apple Pay', 'icon' => 'applepay' ),
		'googlepay' => array( 'label' => 'Google Pay', 'icon' => 'googlepay' ),
	);
}

/** Current state of one sede: plugin installed/active and the gateways' enabled flags. */
function ARD_webpm_site_state( $host ) {
	$blog_id = ARD_app_keys_blog_id( $host );
	$state   = array( 'blog_id' => $blog_id, 'installed' => file_exists( WP_PLUGIN_DIR . '/' . ARD_WEBPM_PLUGIN ), 'active' => false, 'methods' => array(), 'other_twint' => false );
	if ( ! $blog_id ) {
		return $state;
	}
	switch_to_blog( $blog_id );
	$active          = (array) get_option( 'active_plugins', array() );
	$state['active'] = in_array( ARD_WEBPM_PLUGIN, $active, true );
	foreach ( array_keys( ARD_webpm_catalog() ) as $m ) {
		$opt                    = get_option( 'woocommerce_tw_datatrans_' . $m . '_settings', array() );
		$state['methods'][ $m ] = is_array( $opt ) && ( $opt['enabled'] ?? 'no' ) === 'yes';
	}
	// Stripe TWINT (woo-stripe-payment) still on: the customer would see TWINT twice.
	// The option survives when the Stripe plugin is deactivated, so only count it while the plugin runs on that sede.
	$stripe_file          = 'woo-stripe-payment/stripe-payments.php';
	$stripe_active        = in_array( $stripe_file, $active, true ) || array_key_exists( $stripe_file, (array) get_site_option( 'active_sitewide_plugins', array() ) );
	$stripe_twint         = get_option( 'woocommerce_stripe_twint_settings', array() );
	$state['other_twint'] = $stripe_active && is_array( $stripe_twint ) && ( $stripe_twint['enabled'] ?? 'no' ) === 'yes';
	restore_current_blog();
	return $state;
}

/** Switch one gateway on/off in a sede (writes the option the plugin reads; works whether or not the sede has loaded it). */
function ARD_webpm_set_method( $blog_id, $method, $on ) {
	switch_to_blog( (int) $blog_id );
	$key = 'woocommerce_tw_datatrans_' . $method . '_settings';
	$opt = get_option( $key, array() );
	$opt = is_array( $opt ) ? $opt : array();
	$opt['enabled'] = $on ? 'yes' : 'no';
	update_option( $key, $opt, 'yes' );
	restore_current_blog();
}

function ARD_webpm_activate_plugin( $blog_id ) {
	if ( ! function_exists( 'activate_plugin' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	switch_to_blog( (int) $blog_id );
	$result = activate_plugin( ARD_WEBPM_PLUGIN, '', false, true );
	restore_current_blog();
	return $result;
}

add_action( 'admin_menu', 'ARD_webpm_menu', 23 );
function ARD_webpm_menu() {
	if ( ! ARD_payment_methods_is_hub() ) {
		return;
	}
	add_submenu_page(
		'wc_site_status',
		'Metodi di pagamento web',
		'Metodi di pagamento',
		'manage_options',
		'ard_web_payments',
		'ARD_showContent_web_payments'
	);
}

function ARD_showContent_web_payments() {
	if ( ! ARD_payment_methods_is_hub() || ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Pagina disponibile solo sul sito principale del brand.' );
	}
	$catalog = ARD_webpm_catalog();
	$sites   = ARD_payment_methods_sites();
	$notices = array();

	// --- Datatrans account shared by the whole network --------------------
	if ( isset( $_POST['ard_webpm_account_nonce'] )
		&& wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ard_webpm_account_nonce'] ) ), 'ard_webpm_account' ) ) {
		$in    = isset( $_POST['ard_dt'] ) && is_array( $_POST['ard_dt'] ) ? wp_unslash( $_POST['ard_dt'] ) : array();
		$saved = get_site_option( 'tw_datatrans_network_settings', array() );
		$saved = is_array( $saved ) ? $saved : array();
		$saved['managed']             = ! empty( $in['managed'] ) ? 'yes' : 'no';
		$saved['sandbox']             = ! empty( $in['sandbox'] ) ? 'yes' : 'no';
		$saved['autosettle']          = ! empty( $in['autosettle'] ) ? 'yes' : 'no';
		$saved['merchant_id']         = preg_replace( '/\D/', '', sanitize_text_field( (string) ( $in['merchant_id'] ?? '' ) ) );
		$saved['sandbox_merchant_id'] = preg_replace( '/\D/', '', sanitize_text_field( (string) ( $in['sandbox_merchant_id'] ?? '' ) ) );
		foreach ( array( 'password', 'sandbox_password', 'sign_key' ) as $secret ) {
			$v = trim( (string) ( $in[ $secret ] ?? '' ) );
			if ( '' !== $v ) {
				$saved[ $secret ] = 'sign_key' === $secret ? strtolower( preg_replace( '/[^0-9a-fA-F]/', '', $v ) ) : $v;
			} elseif ( ! empty( $in[ $secret . '_clear' ] ) ) {
				$saved[ $secret ] = '';
			}
		}
		update_site_option( 'tw_datatrans_network_settings', $saved );
		do_action( 'litespeed_purge_all' );
		$notices[] = array( 'success', 'Account Datatrans salvato' . ( 'yes' === $saved['managed'] ? ': tutte le sedi lo usano da subito.' : '. Gestione centrale spenta: ogni sede usa le proprie impostazioni.' ) );
	}

	// --- Plugin activation and methods per sede ----------------------------
	if ( isset( $_POST['ard_webpm_nonce'] )
		&& wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ard_webpm_nonce'] ) ), 'ard_webpm_save' ) ) {
		$posted = isset( $_POST['ard_wpm'] ) && is_array( $_POST['ard_wpm'] ) ? wp_unslash( $_POST['ard_wpm'] ) : array();
		$act    = isset( $_POST['ard_wpm_activate'] ) && is_array( $_POST['ard_wpm_activate'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['ard_wpm_activate'] ) ) : array();
		$all    = ! empty( $_POST['ard_wpm_activate_all'] );
		$errors = array();
		$count  = 0;
		foreach ( $sites as $host => $label ) {
			$state = ARD_webpm_site_state( $host );
			if ( ! $state['blog_id'] ) {
				continue;
			}
			if ( ! $state['active'] && ( $all || in_array( $host, $act, true ) ) ) {
				if ( ! $state['installed'] ) {
					$errors[] = $label . ': plugin non installato sul network';
				} else {
					$r = ARD_webpm_activate_plugin( $state['blog_id'] );
					if ( is_wp_error( $r ) ) {
						$errors[] = $label . ': ' . $r->get_error_message();
					} else {
						$state['active'] = true;
					}
				}
			}
			if ( isset( $posted[ $host ] ) || ( $state['active'] && isset( $_POST['ard_wpm_submitted'] ) ) ) {
				foreach ( array_keys( $catalog ) as $m ) {
					$on = ! empty( $posted[ $host ][ $m ] );
					if ( $on !== $state['methods'][ $m ] ) {
						ARD_webpm_set_method( $state['blog_id'], $m, $on );
						$count++;
					}
				}
			}
		}
		do_action( 'litespeed_purge_all' );
		if ( $errors ) {
			$notices[] = array( 'error', 'Non riuscito: ' . implode( '; ', $errors ) );
		}
		$notices[] = array( 'success', $count ? sprintf( 'Salvato: %d %s cambiati nelle sedi.', $count, 1 === $count ? 'metodo' : 'metodi' ) : 'Salvato.' );
	}

	$net       = get_site_option( 'tw_datatrans_network_settings', array() );
	$net       = array_merge( array( 'managed' => 'no', 'sandbox' => 'no', 'autosettle' => 'yes', 'merchant_id' => '', 'sandbox_merchant_id' => '', 'password' => '', 'sandbox_password' => '', 'sign_key' => '' ), is_array( $net ) ? $net : array() );
	$managed   = 'yes' === $net['managed'];
	$installed = file_exists( WP_PLUGIN_DIR . '/' . ARD_WEBPM_PLUGIN );
	$icons     = ARD_payment_methods_icons();
	?>
	<style>
		.ard-wpm-wrap { max-width: 1040px; }
		.ard-wpm-intro { color: #50575e; margin: 0 0 18px; max-width: 780px; }
		.ard-wpm-account { background: #fff; border: 1px solid #dcdcde; border-radius: 12px; padding: 16px 20px; margin-bottom: 22px; }
		.ard-wpm-account h2 { margin: 0 0 6px; }
		.ard-wpm-account .form-table th { width: 200px; }
		.ard-pm-icon { width: 36px; height: 24px; border-radius: 6px; display: inline-flex; align-items: center; justify-content: center; flex: none; overflow: hidden; }
		.ard-pm-card { background: #fff; border: 1px solid #dcdcde; border-radius: 12px; padding: 16px 20px; margin-bottom: 12px; display: flex; flex-wrap: wrap; align-items: center; gap: 14px 24px; }
		.ard-pm-card.is-off { background: #f6f7f7; }
		.ard-pm-site { flex: 1 1 240px; min-width: 200px; }
		.ard-pm-site strong { display: block; font-size: 15px; margin-bottom: 2px; }
		.ard-pm-site code { background: #f0f0f1; border-radius: 4px; padding: 1px 6px; font-size: 12px; }
		.ard-pm-count { color: #646970; font-size: 12px; margin-top: 6px; }
		.ard-pm-count.is-warning { color: #996800; font-weight: 600; }
		.ard-pm-toggles { display: flex; flex-wrap: wrap; gap: 8px; flex: 2 1 520px; align-items: center; }
		.ard-pm-toggle { position: relative; display: inline-flex; align-items: center; gap: 8px; border: 1.5px solid #dcdcde; border-radius: 999px; padding: 6px 12px 6px 8px; background: #f6f7f7; cursor: pointer; user-select: none; transition: border-color .15s, background .15s; }
		.ard-pm-toggle input { position: absolute; opacity: 0; width: 0; height: 0; }
		.ard-pm-toggle .ard-pm-switch { width: 30px; height: 18px; border-radius: 999px; background: #c3c4c7; position: relative; transition: background .15s; flex: none; }
		.ard-pm-toggle .ard-pm-switch::after { content: ""; position: absolute; top: 2px; left: 2px; width: 14px; height: 14px; border-radius: 50%; background: #fff; box-shadow: 0 1px 2px rgba(0,0,0,.25); transition: left .15s; }
		.ard-pm-toggle .ard-pm-name { font-size: 13px; font-weight: 600; color: #1d2327; }
		.ard-pm-toggle.is-on { background: #fff; border-color: #1ca5a8; }
		.ard-pm-toggle.is-on .ard-pm-switch { background: #1ca5a8; }
		.ard-pm-toggle.is-on .ard-pm-switch::after { left: 14px; }
		.ard-pm-toggle:not(.is-on) .ard-pm-icon, .ard-pm-toggle:not(.is-on) .ard-pm-name { opacity: .55; }
		.ard-wpm-plugin { font-size: 12px; margin-top: 6px; }
		.ard-wpm-plugin .is-ok { color: #2e7d32; font-weight: 600; }
		.ard-wpm-plugin .is-missing { color: #b00020; font-weight: 600; }
		.ard-wpm-warn { font-size: 12px; color: #996800; margin-top: 6px; }
		.ard-pm-actions { display: flex; align-items: center; gap: 14px; margin-top: 18px; flex-wrap: wrap; }
		.ard-pm-actions .button-primary { background: #1ca5a8; border-color: #1ca5a8; padding: 4px 22px; }
		.ard-pm-unsaved { color: #996800; font-size: 13px; display: none; }
	</style>
	<div class="wrap ard-wpm-wrap">
		<h1>Metodi di pagamento web</h1>
		<p class="ard-wpm-intro">I negozi online delle sedi pagano con il plugin <strong>Datatrans by ticinoWEB</strong>: da qui imposti una volta l'account Datatrans per tutte le sedi, attivi il plugin dove manca e accendi o spegni TWINT, carta, Apple Pay e Google Pay sede per sede. I metodi dell'app si gestiscono in Gestione App → Metodi di Pagamento.</p>

		<?php foreach ( $notices as $n ) : ?>
			<div class="notice notice-<?php echo esc_attr( $n[0] ); ?>"><p><?php echo esc_html( $n[1] ); ?></p></div>
		<?php endforeach; ?>
		<?php if ( ! $installed ) : ?>
			<div class="notice notice-error"><p>Il plugin <strong>Datatrans by ticinoWEB</strong> non è installato sul network: installalo da Plugin → Aggiungi nuovo (repo release ticinoWEB) prima di usare questa pagina.</p></div>
		<?php endif; ?>

		<div class="ard-wpm-account">
			<h2>Account Datatrans comune</h2>
			<p class="description">Lo stesso merchant ID dell'app. Le password non vengono mai mostrate: un campo vuoto conserva il valore salvato.</p>
			<form method="post">
				<?php wp_nonce_field( 'ard_webpm_account', 'ard_webpm_account_nonce' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row">Gestione centrale</th>
						<td><label><input type="checkbox" name="ard_dt[managed]" value="1" <?php checked( $managed ); ?> /> Tutte le sedi usano l'account qui sotto (le impostazioni Datatrans delle singole sedi diventano di sola lettura)</label></td>
					</tr>
					<tr>
						<th scope="row">Modalità</th>
						<td>
							<label style="margin-right:16px;"><input type="radio" name="ard_dt[sandbox]" value="" <?php checked( 'no', $net['sandbox'] ); ?> /> <strong>Live</strong> (pagamenti reali)</label>
							<label><input type="radio" name="ard_dt[sandbox]" value="1" <?php checked( 'yes', $net['sandbox'] ); ?> /> <strong>Test</strong> (sandbox Datatrans, nessun addebito)</label>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="ard-dt-merchant">Merchant ID (live)</label></th>
						<td><input type="text" id="ard-dt-merchant" name="ard_dt[merchant_id]" value="<?php echo esc_attr( $net['merchant_id'] ); ?>" class="regular-text" style="font-family:monospace;width:200px;" inputmode="numeric" placeholder="3000012345" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="ard-dt-password">Password server-to-server (live)</label></th>
						<td>
							<input type="password" id="ard-dt-password" name="ard_dt[password]" value="" class="regular-text" autocomplete="new-password" placeholder="<?php echo '' !== $net['password'] ? '•••••••• (salvata)' : ''; ?>" />
							<?php if ( '' !== $net['password'] ) : ?><label style="margin-left:8px;"><input type="checkbox" name="ard_dt[password_clear]" value="1" /> rimuovi</label><?php endif; ?>
							<p class="description">Webadmin Datatrans → Gestione UPP → Sicurezza → «Sicurezza servizi server-to-server».</p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="ard-dt-sign">Chiave di firma webhook (HMAC)</label></th>
						<td>
							<input type="password" id="ard-dt-sign" name="ard_dt[sign_key]" value="" class="regular-text" autocomplete="new-password" style="font-family:monospace;" placeholder="<?php echo '' !== $net['sign_key'] ? '•••••••• (salvata)' : 'chiave esadecimale da Webadmin → Sicurezza'; ?>" />
							<?php if ( '' !== $net['sign_key'] ) : ?><label style="margin-left:8px;"><input type="checkbox" name="ard_dt[sign_key_clear]" value="1" /> rimuovi</label><?php endif; ?>
							<p class="description">La stessa chiave HMAC usata dall'app: Webadmin → Gestione UPP → Sicurezza, terza opzione.</p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="ard-dt-smerchant">Merchant ID sandbox</label></th>
						<td>
							<input type="text" id="ard-dt-smerchant" name="ard_dt[sandbox_merchant_id]" value="<?php echo esc_attr( $net['sandbox_merchant_id'] ); ?>" class="regular-text" style="font-family:monospace;width:200px;" inputmode="numeric" />
							<input type="password" name="ard_dt[sandbox_password]" value="" class="regular-text" autocomplete="new-password" style="margin-left:8px;" placeholder="<?php echo '' !== $net['sandbox_password'] ? '•••••••• password salvata' : 'password sandbox'; ?>" />
							<?php if ( '' !== $net['sandbox_password'] ) : ?><label style="margin-left:8px;"><input type="checkbox" name="ard_dt[sandbox_password_clear]" value="1" /> rimuovi</label><?php endif; ?>
							<p class="description">Solo per la modalità Test.</p>
						</td>
					</tr>
					<tr>
						<th scope="row">Incasso</th>
						<td><label><input type="checkbox" name="ard_dt[autosettle]" value="1" <?php checked( 'yes', $net['autosettle'] ); ?> /> Addebita subito (incasso automatico)</label></td>
					</tr>
				</table>
				<p><button type="submit" class="button button-primary">Salva account Datatrans</button></p>
			</form>
		</div>

		<h2 style="margin-bottom:6px;">Sedi</h2>
		<p class="description" style="margin-bottom:12px;">Ogni metodo deve essere attivo anche nel Webadmin Datatrans. Apple Pay viene proposto solo in Safari; Google Pay in tutti i browser.</p>
		<?php if ( empty( $sites ) ) : ?>
			<p><em>Nessuna sede con WooCommerce trovata su questo dominio.</em></p>
		<?php else : ?>
		<form method="post" id="ard-wpm-form">
			<?php wp_nonce_field( 'ard_webpm_save', 'ard_webpm_nonce' ); ?>
			<input type="hidden" name="ard_wpm_submitted" value="1" />
			<?php $missing = 0;
			foreach ( $sites as $host => $label ) :
				$state  = ARD_webpm_site_state( $host );
				$active = count( array_filter( $state['methods'] ) );
				if ( ! $state['active'] ) { $missing++; } ?>
				<div class="ard-pm-card<?php echo $state['active'] ? '' : ' is-off'; ?>" data-host="<?php echo esc_attr( $host ); ?>">
					<div class="ard-pm-site">
						<strong><?php echo esc_html( $label ); ?></strong>
						<code><?php echo esc_html( $host ); ?></code>
						<?php if ( $state['active'] ) : ?>
							<div class="ard-wpm-plugin"><span class="is-ok">✅ Plugin attivo</span> · <a href="<?php echo esc_url( 'https://' . $host . '/wp-admin/admin.php?page=wc-settings&tab=checkout' ); ?>" target="_blank" rel="noopener">pagamenti della sede</a></div>
							<div class="ard-pm-count<?php echo 0 === $active ? ' is-warning' : ''; ?>"><?php echo esc_html( sprintf( '%d di %d metodi Datatrans attivi', $active, count( $catalog ) ) ); ?></div>
							<?php if ( $state['other_twint'] && $state['methods']['twint'] ) : ?>
								<div class="ard-wpm-warn">⚠️ Anche TWINT di Stripe è attivo: il cliente vede TWINT due volte. Spegnilo nei pagamenti della sede.</div>
							<?php endif; ?>
						<?php else : ?>
							<div class="ard-wpm-plugin"><span class="is-missing">⚠️ Plugin non attivo</span></div>
							<label style="font-size:12px;display:block;margin-top:4px;"><input type="checkbox" name="ard_wpm_activate[]" value="<?php echo esc_attr( $host ); ?>" <?php disabled( ! $installed ); ?> /> Attiva il plugin su questa sede al salvataggio</label>
						<?php endif; ?>
					</div>
					<div class="ard-pm-toggles">
						<?php foreach ( $catalog as $key => $method ) : ?>
							<label class="ard-pm-toggle<?php echo $state['methods'][ $key ] ? ' is-on' : ''; ?>">
								<input type="checkbox" name="ard_wpm[<?php echo esc_attr( $host ); ?>][<?php echo esc_attr( $key ); ?>]" value="1" <?php checked( $state['methods'][ $key ] ); ?> />
								<span class="ard-pm-icon"><?php echo isset( $icons[ $method['icon'] ] ) ? $icons[ $method['icon'] ] : ''; // phpcs:ignore WordPress.Security.EscapeOutput -- static inline SVG ?></span>
								<span class="ard-pm-name"><?php echo esc_html( $method['label'] ); ?></span>
								<span class="ard-pm-switch" aria-hidden="true"></span>
							</label>
						<?php endforeach; ?>
					</div>
				</div>
			<?php endforeach; ?>
			<div class="ard-pm-actions">
				<?php submit_button( 'Salva', 'primary', 'submit', false ); ?>
				<?php if ( $missing && $installed ) : ?>
					<button type="submit" name="ard_wpm_activate_all" value="1" class="button">Attiva il plugin su tutte le sedi (<?php echo (int) $missing; ?>)</button>
				<?php endif; ?>
				<span class="ard-pm-unsaved" id="ard-wpm-unsaved">Modifiche non salvate</span>
			</div>
		</form>
		<script>
		(function () {
			var form = document.getElementById('ard-wpm-form');
			if (!form) return;
			var total = <?php echo (int) count( $catalog ); ?>;
			form.addEventListener('change', function (e) {
				var input = e.target;
				if (!input || input.type !== 'checkbox') return;
				var toggle = input.closest('.ard-pm-toggle');
				if (toggle) {
					toggle.classList.toggle('is-on', input.checked);
					var card = input.closest('.ard-pm-card');
					var active = card.querySelectorAll('.ard-pm-toggle input:checked').length;
					var count = card.querySelector('.ard-pm-count');
					if (count) { count.textContent = active + ' di ' + total + ' metodi Datatrans attivi'; count.classList.toggle('is-warning', active === 0); }
				}
				document.getElementById('ard-wpm-unsaved').style.display = 'inline';
			});
		})();
		</script>
		<?php endif; ?>
	</div>
	<?php
}
