<?php
/**
 * Garage Molinari child theme setup.
 *
 * @package Molinarieco
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
add_action( 'wp_enqueue_scripts', function () {
    wp_enqueue_style( 'molinarieco-parent', get_template_directory_uri() . '/style.css', array(), wp_get_theme( get_template() )->get( 'Version' ) );
}, 9 );

// The parent registers Google Fonts; use the system font on this site to avoid a third-party request.
add_action( 'wp_enqueue_scripts', function () {
    wp_dequeue_style( 'ticinoweb-ai-style' );
    wp_deregister_style( 'ticinoweb-ai-style' );
    wp_dequeue_style( 'poppins-font' );
    wp_deregister_style( 'poppins-font' );
    wp_register_style( 'poppins-font', false );
    wp_enqueue_style( 'ticinoweb-ai-style', get_stylesheet_uri(), array( 'molinarieco-parent' ), wp_get_theme()->get( 'Version' ) );
}, 11 );

// The parent prints Google Fonts preconnects even when its font is disabled.
// Remove only that closure for this child so a public visit does not contact Google.
add_action( 'after_setup_theme', function () {
    global $wp_filter;

    if ( empty( $wp_filter['wp_head']->callbacks[0] ) ) {
        return;
    }

    foreach ( $wp_filter['wp_head']->callbacks[0] as $entry ) {
        $callback = $entry['function'];
        if ( ! $callback instanceof Closure ) {
            continue;
        }

        $reflection = new ReflectionFunction( $callback );
        if ( $reflection->getFileName() !== get_template_directory() . '/functions.php' ) {
            continue;
        }

        $source = file( $reflection->getFileName() );
        $body   = implode( '', array_slice( $source, $reflection->getStartLine() - 1, $reflection->getEndLine() - $reflection->getStartLine() + 1 ) );
        if ( str_contains( $body, 'fonts.googleapis.com' ) && str_contains( $body, 'fonts.gstatic.com' ) ) {
            remove_action( 'wp_head', $callback, 0 );
        }
    }
}, 20 );

add_action( 'ticinoweb_footer_links', function () {
    $services = get_page_by_path( 'servizi' );
    if ( $services ) {
        echo '<li><a href="' . esc_url( get_permalink( $services ) ) . '">' . esc_html( get_the_title( $services ) ) . '</a></li>';
    }
} );
