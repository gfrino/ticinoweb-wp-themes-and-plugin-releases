/**
 * ticinoWEB CMS - colonne ridimensionabili nelle tabelle elenco (3.19.0).
 *
 * Trascinando il bordo destro di un'intestazione si cambia la larghezza della
 * colonna; doppio clic sul bordo la riporta a quella automatica. Le larghezze
 * sono salvate per schermata nel browser (localStorage), quindi valgono per
 * chi le imposta su quel computer. Solo da 783 px in su: sotto, WordPress usa
 * la tabella a schede.
 */
(function () {
  'use strict';

  var MIN = 48;

  function storageKey() {
    var p = new URLSearchParams(window.location.search);
    var parts = [window.location.pathname.split('/').pop() || 'index.php'];
    ['post_type', 'taxonomy', 'page', 'post_status'].forEach(function (k) {
      if (k !== 'post_status' && p.get(k)) {
        parts.push(k + '=' + p.get(k));
      }
    });
    return 'twaColW:' + parts.join('&');
  }

  function load(key) {
    try {
      return JSON.parse(window.localStorage.getItem(key) || '{}') || {};
    } catch (e) {
      return {};
    }
  }

  function save(key, data) {
    try {
      if (Object.keys(data).length) {
        window.localStorage.setItem(key, JSON.stringify(data));
      } else {
        window.localStorage.removeItem(key);
      }
    } catch (e) {}
  }

  function colId(th) {
    if (th.id) {
      return th.id;
    }
    var m = (th.className || '').match(/\bcolumn-([\w-]+)/);
    return m ? m[1] : null;
  }

  function setWidth(table, id, px) {
    table.querySelectorAll('thead th, thead td, tfoot th, tfoot td').forEach(function (cell) {
      if (colId(cell) === id) {
        cell.style.width = px ? px + 'px' : '';
        cell.style.boxSizing = px ? 'border-box' : '';
      }
    });
  }

  function setup(table) {
    var head = table.querySelector('thead tr');
    if (!head || table.dataset.twaCols) {
      return;
    }
    table.dataset.twaCols = '1';
    table.classList.add('twa-resizable');

    var key = storageKey();
    var widths = load(key);
    Object.keys(widths).forEach(function (id) {
      setWidth(table, id, widths[id]);
    });

    var cells = Array.prototype.slice.call(head.children);
    cells.forEach(function (th, i) {
      var id = colId(th);
      if (!id || th.classList.contains('check-column') || i === cells.length - 1) {
        return;
      }
      var grip = document.createElement('span');
      grip.className = 'twa-col-grip';
      grip.setAttribute('aria-hidden', 'true');
      grip.title = (window.ticinowebAdminColumns && window.ticinowebAdminColumns.hint) || '';
      th.appendChild(grip);

      grip.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
      });

      grip.addEventListener('dblclick', function (e) {
        e.preventDefault();
        e.stopPropagation();
        delete widths[id];
        setWidth(table, id, 0);
        save(key, widths);
      });

      grip.addEventListener('pointerdown', function (e) {
        if (e.button !== 0) {
          return;
        }
        e.preventDefault();
        e.stopPropagation();
        var startX = e.clientX;
        var startW = th.getBoundingClientRect().width;
        document.body.classList.add('twa-col-resizing');

        function move(ev) {
          var w = Math.max(MIN, Math.round(startW + ev.clientX - startX));
          widths[id] = w;
          setWidth(table, id, w);
        }

        function up() {
          document.removeEventListener('pointermove', move);
          document.removeEventListener('pointerup', up);
          document.removeEventListener('pointercancel', up);
          document.body.classList.remove('twa-col-resizing');
          save(key, widths);
        }

        document.addEventListener('pointermove', move);
        document.addEventListener('pointerup', up);
        document.addEventListener('pointercancel', up);
      });
    });
  }

  function run() {
    if (!window.matchMedia('(min-width: 783px)').matches) {
      return;
    }
    document.querySelectorAll('table.wp-list-table').forEach(setup);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run);
  } else {
    run();
  }
})();
