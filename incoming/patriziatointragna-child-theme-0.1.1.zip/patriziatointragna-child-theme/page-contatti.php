<?php
/**
 * Contatti: recapito del Patriziato (dal ticinoWEB CMS) e Ufficio patriziale (dalla pagina «Il Patriziato»).
 */
get_header();
$c = function_exists('ticinoweb_get_contact_info') ? ticinoweb_get_contact_info() : [];
$email = $c['email'] ?? '';
$indirizzo = $c['address'] ?? '';
while (have_posts()) : the_post();
	pi_testa_pagina(get_the_title(), pi_opz('contatti_nota'));
	?>
	<div class="contenitore pi-contatti">
		<div class="pi-contatti__recapito">
			<h2>Patriziato di Intragna, Golino e Verdasio</h2>
			<?php if ($indirizzo) : ?><p class="pi-grande"><?php echo nl2br(esc_html($indirizzo)); ?></p><?php endif; ?>
			<?php if ($email) : ?><p><a class="pi-bottone" href="mailto:<?php echo esc_attr($email); ?>">Scrivi a <?php echo esc_html($email); ?></a></p><?php endif; ?>
			<?php if (trim(get_the_content()) !== '') : ?><div class="pi-testo"><?php the_content(); ?></div><?php endif; ?>
		</div>
		<section class="pi-contatti__ufficio" aria-labelledby="pi-ufficio">
			<h2 id="pi-ufficio">Ufficio patriziale</h2>
			<?php get_template_part('template-parts/membri'); ?>
		</section>
	</div>
<?php endwhile;
get_footer();
