<?php
/**
 * Un atto dell'albo: tipo e data, titolo, testo, documenti con anteprima, gli altri atti della stessa assemblea.
 */
get_header();
while (have_posts()) : the_post();
	$id = get_the_ID();
	$all = pi_allegati($id);
	$tipo = pi_tipo_di($id);
	$ass = wp_get_post_terms($id, 'pi_assemblea');
	$ass = (!is_wp_error($ass) && $ass) ? $ass[0] : null;
	$immagini = array_values(array_filter($all, 'wp_attachment_is_image'));
	$fino = get_post_meta($id, '_pi_evidenza_fino', true);
	?>
	<article class="pi-atto">
		<header class="pi-testa contenitore">
			<nav class="pi-briciole" aria-label="Sei qui"><a href="<?php echo esc_url(home_url('/')); ?>">Inizio</a><span aria-hidden="true">/</span><a href="<?php echo esc_url(pi_url_albo()); ?>">Albo</a></nav>
			<p class="pi-atto__meta"><?php echo pi_etichetta_tipo($id); ?> <time datetime="<?php echo esc_attr(get_the_date('Y-m-d')); ?>">pubblicato il <?php echo esc_html(mb_strtolower(get_the_date('j F Y'))); ?></time></p>
			<h1><?php echo esc_html(pi_titolo_pulito(get_the_title())); ?></h1>
			<?php if ($ass) : ?>
				<p class="pi-testa__sotto">Riguarda l'<a href="<?php echo esc_url(get_term_link($ass)); ?>">assemblea del <?php echo esc_html(pi_data_lunga(pi_assemblea_data($ass))); ?></a>.</p>
			<?php endif; ?>
			<?php if ($tipo === 'avviso' && $fino && $fino >= current_time('Y-m-d')) : ?>
				<p class="pi-testa__sotto">Avviso valido fino al <?php echo esc_html(pi_data_lunga($fino)); ?>.</p>
			<?php endif; ?>
		</header>

		<div class="contenitore pi-atto__corpo">
			<div class="pi-atto__principale">
				<?php if (trim(get_the_content()) !== '') : ?>
					<div class="pi-testo"><?php the_content(); ?></div>
				<?php endif; ?>
				<?php if ($immagini) : ?>
					<div class="pi-atto__immagini">
						<?php foreach ($immagini as $img) : ?>
							<a href="<?php echo esc_url(wp_get_attachment_url($img)); ?>" aria-label="<?php echo esc_attr('Apri l\'immagine a grandezza piena: ' . pi_titolo_pulito(get_the_title())); ?>"><?php echo pi_foto($img, 'pi-medio', ['sizes' => '(min-width: 1024px) 60vw, 100vw']); ?></a>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>
				<?php
				$primo_pdf = null;
				foreach ($all as $a) {
					if (get_post_mime_type($a) === 'application/pdf') {
						$primo_pdf = $a;
						break;
					}
				}
				if ($primo_pdf) {
					pi_anteprima_pdf($primo_pdf);
				}
				?>
			</div>
			<aside class="pi-atto__lato">
				<?php if ($all) : ?>
					<h2 class="pi-lato__titolo">Documenti</h2>
					<?php pi_lista_file($all); ?>
				<?php else : ?>
					<p class="pi-vuoto">Nessun documento allegato.</p>
				<?php endif; ?>
				<?php if ($ass) :
					$altri = array_filter(pi_atti_assemblea($ass->term_id), function ($p) use ($id) {
						return $p->ID !== $id;
					});
					if ($altri) : ?>
						<h2 class="pi-lato__titolo">Stessa assemblea</h2>
						<ul class="pi-lato__lista" role="list">
							<?php foreach ($altri as $p) : ?>
								<li><a href="<?php echo esc_url(get_permalink($p)); ?>"><?php echo esc_html(pi_tipo_etichetta(pi_tipo_di($p->ID))); ?></a> <span><?php echo esc_html(get_the_date('d.m.Y', $p)); ?></span></li>
							<?php endforeach; ?>
						</ul>
					<?php endif;
				endif; ?>
			</aside>
		</div>

		<nav class="contenitore pi-atto__vicini" aria-label="Altri atti">
			<?php
			$prec = get_previous_post();
			$succ = get_next_post();
			if ($succ) {
				printf('<a class="pi-vicino" href="%s"><span>Atto successivo</span>%s</a>', esc_url(get_permalink($succ)), esc_html(pi_titolo_pulito(get_the_title($succ))));
			}
			if ($prec) {
				printf('<a class="pi-vicino pi-vicino--prima" href="%s"><span>Atto precedente</span>%s</a>', esc_url(get_permalink($prec)), esc_html(pi_titolo_pulito(get_the_title($prec))));
			}
			?>
		</nav>
	</article>
<?php endwhile;
get_footer();
