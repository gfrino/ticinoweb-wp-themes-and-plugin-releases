<?php
/**
 * Albo: tutti gli atti dal più recente, filtrabili per tipo e anno (filtri via indirizzo: funzionano anche senza JavaScript).
 */
get_header();
global $wpdb;
$tipo_sel = sanitize_key($_GET['tipo'] ?? '');
$anno_sel = absint($_GET['anno'] ?? 0);
$anni = $wpdb->get_col("SELECT DISTINCT YEAR(post_date) FROM {$wpdb->posts} WHERE post_type='post' AND post_status='publish' ORDER BY 1 DESC");
$base = pi_url_albo();
pi_testa_pagina('Albo del Patriziato', 'Tutti gli atti pubblicati: convocazioni, verbali, risoluzioni, avvisi, ratifiche. Dal più recente.');
?>
<div class="contenitore pi-albo">
	<form class="pi-filtri" method="get" action="<?php echo esc_url($base); ?>" aria-label="Filtra gli atti">
		<fieldset class="pi-filtri__tipi">
			<legend class="pi-nascosto">Tipo di atto</legend>
			<a href="<?php echo esc_url(remove_query_arg(['tipo', 'paged'], add_query_arg($anno_sel ? ['anno' => $anno_sel] : [], $base))); ?>" class="pi-chip" <?php echo $tipo_sel ? '' : 'aria-current="true"'; ?>>Tutti</a>
			<?php foreach (pi_tipi_atto() as $slug => $t) :
				$url = add_query_arg(array_filter(['tipo' => $slug, 'anno' => $anno_sel ?: null]), $base); ?>
				<a href="<?php echo esc_url($url); ?>" class="pi-chip" <?php echo $tipo_sel === $slug ? 'aria-current="true"' : ''; ?>><?php echo esc_html($t[0]); ?></a>
			<?php endforeach; ?>
		</fieldset>
		<div class="pi-filtri__altri">
			<?php if ($tipo_sel) : ?><input type="hidden" name="tipo" value="<?php echo esc_attr($tipo_sel); ?>"><?php endif; ?>
			<label>Anno
				<select name="anno">
					<option value="">Tutti gli anni</option>
					<?php foreach ($anni as $a) : ?>
						<option value="<?php echo (int) $a; ?>" <?php selected($anno_sel, (int) $a); ?>><?php echo (int) $a; ?></option>
					<?php endforeach; ?>
				</select>
			</label>
			<button type="submit" class="pi-bottone pi-bottone--linea">Mostra</button>
		</div>
	</form>
	<form class="pi-cerca" role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
		<label for="pi-cerca-albo">Cerca per parola</label>
		<input id="pi-cerca-albo" type="search" name="s" placeholder="Per esempio: legna, verbale 2024, strada">
		<button type="submit" class="pi-bottone">Cerca</button>
	</form>

	<?php if (have_posts()) :
		$anno_corrente = null; ?>
		<?php while (have_posts()) : the_post();
			$anno = get_the_date('Y');
			if ($anno !== $anno_corrente) {
				if ($anno_corrente !== null) {
					echo '</ol></section>';
				}
				$anno_corrente = $anno;
				echo '<section class="pi-anno"><h2 class="pi-anno__titolo">' . esc_html($anno) . '</h2><ol class="pi-righe" role="list">';
			}
			pi_riga_atto(get_post(), false);
		endwhile;
		echo '</ol></section>'; ?>
		<nav class="pi-paginazione" aria-label="Pagine dell'albo">
			<?php echo paginate_links(['prev_text' => 'Più recenti', 'next_text' => 'Meno recenti', 'mid_size' => 1]); ?>
		</nav>
	<?php else : ?>
		<p class="pi-vuoto">Nessun atto con questi filtri. <a href="<?php echo esc_url($base); ?>">Mostra tutto l'albo</a>.</p>
	<?php endif; ?>
</div>
<?php get_footer(); ?>
