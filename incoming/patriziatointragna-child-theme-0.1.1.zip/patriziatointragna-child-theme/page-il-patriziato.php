<?php
/**
 * Il Patriziato: testo della pagina (che cos'è, organi), foto d'archivio, ufficio patriziale dal CMS.
 */
get_header();
$o = pi_opz();
while (have_posts()) : the_post();
	pi_testa_pagina(get_the_title(), has_excerpt() ? get_the_excerpt() : '');
	?>
	<div class="contenitore pi-patriziato">
		<div class="pi-testo pi-testo--editoriale"><?php the_content(); ?></div>
		<?php if ($o['storia_foto']) : ?>
			<figure class="pi-patriziato__foto">
				<div class="pi-cornice" data-pi-rivela><?php echo pi_foto($o['storia_foto'], 'pi-medio', ['sizes' => '(min-width: 1024px) 34vw, 100vw']); ?></div>
				<figcaption><?php echo esc_html(wp_get_attachment_caption($o['storia_foto']) ?: pi_credito($o['storia_foto'])); ?></figcaption>
			</figure>
		<?php endif; ?>
	</div>
	<?php if ($o['membri']) : ?>
		<section class="sezione sezione--alt" aria-labelledby="pi-ufficio">
			<div class="contenitore">
				<div class="sezione__testa">
					<h2 id="pi-ufficio">Ufficio patriziale</h2>
					<p>L'organo esecutivo che amministra il Patriziato. Per scrivere: <a href="<?php echo esc_url(pi_url('contatti')); ?>">contatti</a>.</p>
				</div>
				<?php get_template_part('template-parts/membri'); ?>
			</div>
		</section>
	<?php endif;
endwhile;
get_footer();
