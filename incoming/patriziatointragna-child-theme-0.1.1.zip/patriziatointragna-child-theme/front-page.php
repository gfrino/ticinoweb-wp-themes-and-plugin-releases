<?php
/**
 * Prima pagina: chi è il Patriziato (ieri e oggi), poi subito l'albo, i registri, la storia, il territorio.
 */
get_header();
$o = pi_opz();
$avvisi = pi_avvisi_attivi(3);
$ev = pi_assemblea_in_evidenza();
$escludi = [];
if ($ev) {
	$escludi = wp_list_pluck(pi_atti_assemblea($ev['term']->term_id), 'ID');
}
$ultimi = get_posts(['post_type' => 'post', 'posts_per_page' => 6, 'post__not_in' => array_merge($escludi, wp_list_pluck($avvisi, 'ID')), 'no_found_rows' => true]);
$patriziato = get_page_by_path('il-patriziato');
$catalogo = get_page_by_path('catalogo-elettorale', OBJECT, 'pi_documento');
?>

<section class="pi-hero contenitore" aria-labelledby="pi-hero-titolo">
	<div class="pi-hero__testo">
		<h1 id="pi-hero-titolo" class="pi-hero__titolo"><?php echo esc_html(get_bloginfo('name')); ?></h1>
		<div class="pi-hero__dopo">
		<?php echo pi_paragrafi($o['home_intro']) ? '<div class="pi-hero__sotto">' . pi_paragrafi($o['home_intro']) . '</div>' : ''; ?>
		<ul class="pi-hero__vie" role="list">
			<?php if ($ev) : ?>
				<li><a href="<?php echo esc_url(get_term_link($ev['term'])); ?>"><?php echo $ev['futura'] ? 'Prossima assemblea: ' : 'Ultima assemblea: '; ?><?php echo esc_html(pi_data_breve(pi_assemblea_data($ev['term']))); ?></a></li>
			<?php endif; ?>
			<?php if ($catalogo) : ?><li><a href="<?php echo esc_url(get_permalink($catalogo)); ?>">Catalogo elettorale</a></li><?php endif; ?>
			<li><a href="<?php echo esc_url(pi_url_albo()); ?>">Tutti gli atti</a></li>
		</ul>
		</div>
	</div>
	<?php if ($o['foto_ieri'] || $o['foto_oggi']) : ?>
		<div class="pi-confronto" data-pi-confronto>
			<?php if ($o['foto_ieri']) : ?>
				<figure class="pi-confronto__ieri">
					<div class="pi-cornice"><?php echo pi_foto($o['foto_ieri'], 'pi-medio', ['loading' => 'eager', 'sizes' => '(min-width: 1024px) 40vw, 45vw']); ?></div>
					<figcaption><b>Ieri</b><span><?php echo esc_html($o['foto_ieri_nota'] ?: pi_credito($o['foto_ieri'])); ?></span></figcaption>
				</figure>
			<?php endif; ?>
			<?php if ($o['foto_oggi']) : ?>
				<figure class="pi-confronto__oggi">
					<div class="pi-cornice"><?php echo pi_foto($o['foto_oggi'], 'pi-largo', ['loading' => 'eager', 'fetchpriority' => 'high', 'sizes' => '(min-width: 1024px) 58vw, 55vw']); ?></div>
					<figcaption><b>Oggi</b><span><?php echo esc_html(wp_get_attachment_caption($o['foto_oggi']) ?: get_the_title($o['foto_oggi'])); ?></span></figcaption>
				</figure>
			<?php endif; ?>
		</div>
	<?php endif; ?>
</section>

<?php if ($avvisi) : ?>
	<section class="pi-avvisi" aria-label="Avvisi in corso">
		<div class="contenitore">
			<?php foreach ($avvisi as $a) : ?>
				<a class="pi-avviso" href="<?php echo esc_url(get_permalink($a)); ?>">
					<span class="pi-avviso__etichetta">Avviso</span>
					<span class="pi-avviso__titolo"><?php echo esc_html(pi_titolo_pulito(get_the_title($a))); ?></span>
					<span class="pi-avviso__data">pubblicato il <?php echo esc_html(get_the_date('d.m.Y', $a)); ?></span>
				</a>
			<?php endforeach; ?>
		</div>
	</section>
<?php endif; ?>

<section class="pi-albo-home sezione" aria-labelledby="pi-albo-titolo">
	<div class="contenitore pi-albo-home__griglia">
		<div class="pi-albo-home__testa">
			<h2 id="pi-albo-titolo">Albo del Patriziato</h2>
			<p>Convocazioni, verbali, risoluzioni e avvisi ufficiali, appena pubblicati.</p>
		</div>
		<?php if ($ev) :
			$t = $ev['term'];
			$data = pi_assemblea_data($t);
			$ora = get_term_meta($t->term_id, 'pi_ora', true);
			$luogo = get_term_meta($t->term_id, 'pi_luogo', true); ?>
			<article class="pi-assemblea-card">
				<p class="pi-assemblea-card__stato"><?php echo $ev['futura'] ? 'Prossima assemblea' : 'Ultima assemblea'; ?></p>
				<p class="pi-assemblea-card__data">
					<span class="pi-assemblea-card__giorno"><?php echo esc_html(wp_date('j', strtotime($data . ' 12:00'))); ?></span>
					<span><?php echo esc_html(mb_strtolower(wp_date('F', strtotime($data . ' 12:00'))) . ' ' . wp_date('Y', strtotime($data . ' 12:00'))); ?><?php if ($ora) : ?><br>ore <?php echo esc_html($ora); ?><?php endif; ?></span>
				</p>
				<?php if ($luogo) : ?><p class="pi-assemblea-card__luogo"><?php echo esc_html($luogo); ?></p><?php endif; ?>
				<ul class="pi-assemblea-card__atti" role="list">
					<?php foreach (pi_atti_assemblea($t->term_id) as $a) : ?>
						<li><a href="<?php echo esc_url(get_permalink($a)); ?>"><?php echo esc_html(pi_tipo_etichetta(pi_tipo_di($a->ID))); ?></a></li>
					<?php endforeach; ?>
				</ul>
				<a class="pi-link-freccia" href="<?php echo esc_url(get_term_link($t)); ?>">Tutti gli atti dell'assemblea</a>
			</article>
		<?php endif; ?>
		<div class="pi-albo-home__lista">
			<ol class="pi-righe" role="list">
				<?php foreach ($ultimi as $p) {
					pi_riga_atto($p);
				} ?>
			</ol>
			<a class="pi-bottone" href="<?php echo esc_url(pi_url_albo()); ?>">Apri l'albo completo</a>
		</div>
	</div>
</section>

<?php $docs = pi_documenti(); if ($docs) : ?>
	<section class="pi-registri sezione sezione--alt" aria-labelledby="pi-registri-titolo">
		<div class="contenitore">
			<div class="sezione__testa">
				<h2 id="pi-registri-titolo">Registri e regolamenti</h2>
				<p>Sempre la versione in vigore. Le versioni precedenti restano consultabili.</p>
			</div>
			<ul class="pi-registro" role="list">
				<?php foreach ($docs as $d) :
					$dal = get_post_meta($d->ID, '_pi_valido_dal', true); ?>
					<li>
						<a href="<?php echo esc_url(get_permalink($d)); ?>"><?php echo esc_html(get_the_title($d)); ?></a>
						<span class="pi-registro__racc"><?php echo esc_html(pi_raccolte()[pi_documento_raccolta($d->ID)][0]); ?></span>
						<span class="pi-registro__dal"><?php echo $dal ? 'in vigore dal ' . esc_html(pi_data_breve($dal)) : ''; ?></span>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</section>
<?php endif; ?>

<?php if ($patriziato) :
	$estratto = has_excerpt($patriziato) ? get_the_excerpt($patriziato) : '';
	if ($estratto === '' && preg_match('#<p>(.*?)</p>#s', $patriziato->post_content, $m)) {
		$estratto = wp_strip_all_tags($m[1]);
	} ?>
	<section class="pi-storia sezione" aria-labelledby="pi-storia-titolo">
		<div class="contenitore pi-storia__griglia">
			<?php if ($o['storia_foto']) : ?>
				<figure class="pi-storia__foto" data-pi-rivela>
					<div class="pi-cornice"><?php echo pi_foto($o['storia_foto'], 'pi-medio', ['sizes' => '(min-width: 1024px) 40vw, 100vw']); ?></div>
					<figcaption><?php echo esc_html(wp_get_attachment_caption($o['storia_foto']) ?: pi_credito($o['storia_foto'])); ?></figcaption>
				</figure>
			<?php endif; ?>
			<div class="pi-storia__testo">
				<h2 id="pi-storia-titolo">Che cos'è il Patriziato</h2>
				<p class="pi-grande"><?php echo esc_html($estratto); ?></p>
				<a class="pi-link-freccia" href="<?php echo esc_url(get_permalink($patriziato)); ?>">Organi, ufficio patriziale e storia</a>
			</div>
		</div>
	</section>
<?php endif; ?>

<?php
$paesi = array_filter(pi_paesi(), function ($k) use ($o) {
	return !empty($o[$k . '_foto']);
}, ARRAY_FILTER_USE_KEY);
if ($paesi) : ?>
	<section class="pi-paesi sezione sezione--alt" aria-labelledby="pi-paesi-titolo">
		<div class="contenitore">
			<div class="sezione__testa">
				<h2 id="pi-paesi-titolo">Tre paesi, un Patriziato</h2>
				<?php echo $o['territorio_intro'] ? '<p>' . esc_html(wp_trim_words($o['territorio_intro'], 40)) . '</p>' : ''; ?>
			</div>
			<ul class="pi-paesi__griglia" role="list">
				<?php foreach ($paesi as $k => $nome) : ?>
					<li class="pi-paese pi-paese--<?php echo esc_attr($k); ?>">
						<a href="<?php echo esc_url(pi_url('territorio') . '#' . $k); ?>">
							<div class="pi-cornice" data-pi-rivela><?php echo pi_foto($o[$k . '_foto'], 'pi-medio', ['sizes' => '(min-width: 1024px) 33vw, 100vw']); ?></div>
							<h3><?php echo esc_html($nome); ?></h3>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
			<?php if ($o['gettoni']) : ?>
				<aside class="pi-gettoni">
					<h3>Gettoni per le strade forestali</h3>
					<?php echo $o['gettoni_testo'] ? '<p>' . esc_html($o['gettoni_testo']) . '</p>' : ''; ?>
					<ul role="list">
						<?php foreach ($o['gettoni'] as $g) : ?>
							<li><span><?php echo esc_html($g['nome']); ?></span><?php if ($g['telefono']) : ?><a href="tel:<?php echo esc_attr(pi_tel($g['telefono'])); ?>"><?php echo esc_html($g['telefono']); ?></a><?php endif; ?></li>
						<?php endforeach; ?>
					</ul>
				</aside>
			<?php endif; ?>
		</div>
	</section>
<?php endif; ?>

<?php get_footer(); ?>
