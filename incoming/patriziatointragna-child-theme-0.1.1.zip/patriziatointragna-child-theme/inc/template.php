<?php
/**
 * Pezzi di stampa condivisi dai template.
 */
if (!defined('ABSPATH')) {
	exit;
}

/** URL di una pagina per slug (le pagine nascono con la migrazione; il menu le usa). */
function pi_url($slug) {
	static $cache = [];
	if (!isset($cache[$slug])) {
		$p = get_page_by_path($slug);
		$cache[$slug] = $p ? get_permalink($p) : home_url('/' . $slug . '/');
	}
	return $cache[$slug];
}

function pi_url_albo() {
	$id = (int) get_option('page_for_posts');
	return $id ? get_permalink($id) : home_url('/albo/');
}

/** Foto con srcset vero e dimensioni corrette. */
function pi_foto($id, $size = 'pi-medio', $attr = []) {
	if (!$id) {
		return '';
	}
	$attr = wp_parse_args($attr, ['loading' => 'lazy', 'decoding' => 'async']);
	return wp_get_attachment_image((int) $id, $size, false, $attr);
}

/** Credito breve di una foto (autore · licenza), se registrato. */
function pi_credito($id) {
	$c = get_post_meta((int) $id, '_pi_credito', true);
	return is_array($c) ? trim(($c['autore'] ?? '') . (empty($c['licenza']) ? '' : ' · ' . $c['licenza'])) : '';
}

/** Marca: stemma (logo del CMS) + nome su due righe. */
function pi_marca($classe = 'pi-marca') {
	$logo = function_exists('ticinoweb_get_site_logo') ? ticinoweb_get_site_logo() : '';
	$nome = get_bloginfo('name');
	$parti = preg_split('/,\s*/', $nome, 2);
	?>
	<a class="<?php echo esc_attr($classe); ?>" href="<?php echo esc_url(home_url('/')); ?>" rel="home">
		<?php if ($logo) : ?><img src="<?php echo esc_url($logo); ?>" alt="" width="56" height="56"><?php endif; ?>
		<span><?php echo esc_html($parti[0] . (isset($parti[1]) ? ',' : '')); ?><?php if (isset($parti[1])) : ?><br><?php echo esc_html($parti[1]); ?><?php endif; ?></span>
	</a>
	<?php
}

/** Etichetta del tipo di un atto. */
function pi_etichetta_tipo($post_id) {
	$t = pi_tipo_di($post_id);
	return '<span class="pi-tipo pi-tipo--' . esc_attr($t) . '">' . esc_html(pi_tipo_etichetta($t)) . '</span>';
}

/** Riga di un atto negli elenchi: data, tipo, titolo, formato del file principale. */
function pi_riga_atto($p, $mostra_anno = true) {
	$all = pi_allegati($p->ID);
	$f = $all ? pi_file_info($all[0]) : null;
	?>
	<li class="pi-riga">
		<time class="pi-riga__data" datetime="<?php echo esc_attr(get_the_date('Y-m-d', $p)); ?>"><?php echo esc_html(get_the_date($mostra_anno ? 'd.m.Y' : 'd.m', $p)); ?></time>
		<span class="pi-riga__tipo"><?php echo pi_etichetta_tipo($p->ID); ?></span>
		<a class="pi-riga__titolo" href="<?php echo esc_url(get_permalink($p)); ?>"><?php echo esc_html(pi_titolo_pulito(get_the_title($p))); ?></a>
		<span class="pi-riga__file"><?php echo $f ? esc_html($f['formato'] . (count($all) > 1 ? ' +' . (count($all) - 1) : '')) : ''; ?></span>
	</li>
	<?php
}

/** Titoli scritti tutti in maiuscolo dal vecchio sito: resi leggibili senza toccare il dato. */
function pi_titolo_pulito($t) {
	$lettere = preg_replace('/[^\p{L}]/u', '', $t);
	$maiuscole = preg_replace('/[^\p{Lu}]/u', '', $t);
	if (mb_strlen($lettere) > 6 && mb_strlen($maiuscole) / mb_strlen($lettere) > 0.6) {
		$t = mb_strtolower($t);
		$t = mb_strtoupper(mb_substr($t, 0, 1)) . mb_substr($t, 1);
		foreach (['intragna' => 'Intragna', 'golino' => 'Golino', 'verdasio' => 'Verdasio', 'centovalli' => 'Centovalli', 'rfd' => 'RFD', 'rfp' => 'RFP', 'mm ' => 'MM ', 'sel ' => 'SEL '] as $a => $b) {
			$t = preg_replace('/\b' . preg_quote(trim($a), '/') . '\b/u', trim($b), $t);
		}
	}
	return $t;
}

/** Elenco dei file allegati con apertura e scaricamento. */
function pi_lista_file($ids, $rel_nofollow = false) {
	if (!$ids) {
		return;
	}
	echo '<ul class="pi-file" role="list">';
	foreach ($ids as $id) {
		$f = pi_file_info($id);
		if (!$f) {
			continue;
		}
		$rel = $rel_nofollow ? ' rel="nofollow"' : '';
		printf(
			'<li><a class="pi-file__link" href="%1$s"%5$s><span class="pi-file__formato">%2$s</span><span class="pi-file__nome">%3$s</span><span class="pi-file__peso">%4$s</span></a><a class="pi-file__scarica" href="%1$s" download%5$s aria-label="Scarica %3$s">Scarica</a></li>',
			esc_url($f['url']),
			esc_html($f['formato']),
			esc_html($f['titolo']),
			esc_html($f['peso']),
			$rel
		);
	}
	echo '</ul>';
}

/** Anteprima del primo PDF: caricata solo quando entra nello schermo. */
function pi_anteprima_pdf($id) {
	$f = pi_file_info($id);
	if (!$f || !$f['pdf']) {
		return;
	}
	printf(
		'<figure class="pi-anteprima" data-pi-pdf="%s"><div class="pi-anteprima__cornice"><p>Anteprima del documento in caricamento…</p></div><figcaption><a href="%s">Apri il PDF a tutto schermo</a></figcaption></figure>',
		esc_url($f['url'] . '#view=FitH'),
		esc_url($f['url'])
	);
}

/** Intestazione delle pagine interne: occhiello di sezione (link), titolo, sottotitolo. */
function pi_testa_pagina($titolo, $sotto = '', $sezione = null) {
	?>
	<header class="pi-testa contenitore">
		<?php if ($sezione) : ?>
			<nav class="pi-briciole" aria-label="Sei qui"><a href="<?php echo esc_url(home_url('/')); ?>">Inizio</a><span aria-hidden="true">/</span><a href="<?php echo esc_url($sezione[1]); ?>"><?php echo esc_html($sezione[0]); ?></a></nav>
		<?php else : ?>
			<nav class="pi-briciole" aria-label="Sei qui"><a href="<?php echo esc_url(home_url('/')); ?>">Inizio</a></nav>
		<?php endif; ?>
		<h1><?php echo esc_html($titolo); ?></h1>
		<?php if ($sotto) : ?><p class="pi-testa__sotto"><?php echo esc_html($sotto); ?></p><?php endif; ?>
	</header>
	<?php
}

/** Testo semplice dal CMS (textarea) in paragrafi. */
function pi_paragrafi($testo) {
	$testo = trim((string) $testo);
	return $testo === '' ? '' : wpautop(esc_html($testo));
}

/** Telefono per link tel:. */
function pi_tel($n) {
	$n = preg_replace('/[^\d+]/', '', (string) $n);
	if (strpos($n, '00') === 0) {
		return '+' . substr($n, 2);
	}
	return strpos($n, '0') === 0 ? '+41' . substr($n, 1) : $n;
}

/** Menu se nel CMS non ne è ancora stato assegnato uno. */
function pi_menu_di_ripiego() {
	$voci = [
		'Albo'          => pi_url_albo(),
		'Assemblee'     => pi_url('assemblee'),
		'Documenti'     => get_post_type_archive_link('pi_documento'),
		'Territorio'    => pi_url('territorio'),
		'Il Patriziato' => pi_url('il-patriziato'),
		'Contatti'      => pi_url('contatti'),
	];
	echo '<ul class="pi-nav__lista">';
	foreach ($voci as $n => $u) {
		printf('<li><a href="%s">%s</a></li>', esc_url($u), esc_html($n));
	}
	echo '</ul>';
}
