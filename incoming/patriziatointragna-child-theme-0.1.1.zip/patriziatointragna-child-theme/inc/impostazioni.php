<?php
/**
 * Pagina «Il Patriziato» nel ticinoWEB CMS: i dati del sito che non sono atti né documenti.
 * Tutto in un'opzione sola `pi_opzioni`. Contatti (email, indirizzo) restano quelli del parent:
 * ticinoWEB CMS → Contatti (`ticinoweb_contact_*`).
 */
if (!defined('ABSPATH')) {
	exit;
}

function pi_paesi() {
	return ['intragna' => 'Intragna', 'golino' => 'Golino', 'verdasio' => 'Verdasio'];
}

function pi_opzioni_vuote() {
	$o = [
		'home_intro'     => '',
		'foto_oggi'      => 0,
		'foto_ieri'      => 0,
		'foto_ieri_nota' => '',
		'membri'         => [],
		'gettoni_testo'  => '',
		'gettoni'        => [],
		'strade_testo'   => '',
		'storia_foto'    => 0,
		'territorio_intro' => '',
		'contatti_nota'  => '',
	];
	foreach (array_keys(pi_paesi()) as $p) {
		$o[$p . '_testo'] = '';
		$o[$p . '_foto']  = 0;
	}
	return $o;
}

function pi_opz($chiave = null) {
	static $o = null;
	if ($o === null) {
		$o = wp_parse_args((array) get_option('pi_opzioni', []), pi_opzioni_vuote());
	}
	return $chiave === null ? $o : ($o[$chiave] ?? '');
}

if (!is_admin()) {
	return;
}

add_action('admin_menu', function () {
	add_submenu_page('ticinoweb-cms', 'Il Patriziato', 'Il Patriziato', 'edit_pages', 'pi-patriziato', 'pi_pagina_impostazioni');
}, 20);

add_action('admin_post_pi_salva_impostazioni', 'pi_salva_impostazioni');
function pi_salva_impostazioni() {
	if (!current_user_can('edit_pages')) {
		wp_die('Non hai i permessi per questa operazione.');
	}
	check_admin_referer('pi_impostazioni');
	$in = wp_unslash($_POST['pi'] ?? []);
	$o  = pi_opzioni_vuote();

	foreach (['home_intro', 'gettoni_testo', 'strade_testo', 'territorio_intro', 'contatti_nota'] as $k) {
		$o[$k] = sanitize_textarea_field($in[$k] ?? '');
	}
	$o['foto_ieri_nota'] = sanitize_text_field($in['foto_ieri_nota'] ?? '');
	foreach (['foto_oggi', 'foto_ieri', 'storia_foto'] as $k) {
		$o[$k] = absint($in[$k] ?? 0);
	}
	foreach (array_keys(pi_paesi()) as $p) {
		$o[$p . '_testo'] = sanitize_textarea_field($in[$p . '_testo'] ?? '');
		$o[$p . '_foto']  = absint($in[$p . '_foto'] ?? 0);
	}
	foreach ((array) ($in['membri'] ?? []) as $m) {
		$r = [
			'nome'     => sanitize_text_field($m['nome'] ?? ''),
			'ruolo'    => sanitize_text_field($m['ruolo'] ?? ''),
			'email'    => sanitize_email($m['email'] ?? ''),
			'telefono' => sanitize_text_field($m['telefono'] ?? ''),
		];
		if ($r['nome'] !== '') {
			$o['membri'][] = $r;
		}
	}
	foreach ((array) ($in['gettoni'] ?? []) as $g) {
		$r = ['nome' => sanitize_text_field($g['nome'] ?? ''), 'telefono' => sanitize_text_field($g['telefono'] ?? '')];
		if ($r['nome'] !== '') {
			$o['gettoni'][] = $r;
		}
	}
	update_option('pi_opzioni', $o, true);
	do_action('litespeed_purge_all');
	wp_safe_redirect(add_query_arg(['page' => 'pi-patriziato', 'salvato' => '1'], admin_url('admin.php')));
	exit;
}

/** Campo foto: anteprima + «Scegli foto» + «Togli». */
function pi_campo_foto($nome, $valore, $etichetta) {
	$src = $valore ? wp_get_attachment_image_url($valore, 'medium') : '';
	?>
	<div class="pi-campo pi-foto" data-pi-foto>
		<span class="pi-etichetta"><?php echo esc_html($etichetta); ?></span>
		<img src="<?php echo esc_url($src); ?>" alt="" <?php echo $src ? '' : 'hidden'; ?>>
		<input type="hidden" name="pi[<?php echo esc_attr($nome); ?>]" value="<?php echo (int) $valore; ?>">
		<span class="pi-bottoni">
			<button type="button" class="button" data-scegli>Scegli una foto</button>
			<button type="button" class="button-link pi-togli" data-togli <?php echo $valore ? '' : 'hidden'; ?>>Togli</button>
		</span>
	</div>
	<?php
}

function pi_pagina_impostazioni() {
	if (!current_user_can('edit_pages')) {
		return;
	}
	wp_enqueue_media();
	$o = pi_opz();
	$membri = $o['membri'] ?: [['nome' => '', 'ruolo' => '', 'email' => '', 'telefono' => '']];
	$gettoni = $o['gettoni'] ?: [['nome' => '', 'telefono' => '']];
	?>
	<div class="wrap pi-impostazioni">
		<h1>Il Patriziato</h1>
		<p class="pi-aiuto">Qui si cambiano le informazioni fisse del sito. Email e indirizzo del Patriziato stanno in <a href="<?php echo esc_url(admin_url('admin.php?page=ticinoweb-cms')); ?>">ticinoWEB CMS → Contatti</a>.</p>
		<?php if (!empty($_GET['salvato'])) : ?>
			<div class="notice notice-success"><p><strong>Salvato.</strong> Il sito è già aggiornato.</p></div>
		<?php endif; ?>
		<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
			<input type="hidden" name="action" value="pi_salva_impostazioni">
			<?php wp_nonce_field('pi_impostazioni'); ?>

			<section class="pi-blocco">
				<h2>Ufficio patriziale</h2>
				<p class="pi-aiuto">Le persone dell'amministrazione, nell'ordine in cui compaiono nella pagina Contatti. Email e telefono sono facoltativi: se li lasci vuoti non compaiono.</p>
				<div class="pi-righe" data-pi-righe="membri">
					<?php foreach ($membri as $i => $m) : ?>
						<div class="pi-riga">
							<label>Nome e cognome<input type="text" name="pi[membri][<?php echo (int) $i; ?>][nome]" value="<?php echo esc_attr($m['nome']); ?>"></label>
							<label>Carica<input type="text" name="pi[membri][<?php echo (int) $i; ?>][ruolo]" value="<?php echo esc_attr($m['ruolo']); ?>" placeholder="Presidente, Membro, Segretario…"></label>
							<label>Email<input type="email" name="pi[membri][<?php echo (int) $i; ?>][email]" value="<?php echo esc_attr($m['email']); ?>"></label>
							<label>Telefono<input type="text" name="pi[membri][<?php echo (int) $i; ?>][telefono]" value="<?php echo esc_attr($m['telefono']); ?>"></label>
							<button type="button" class="button-link pi-togli" data-togli-riga>Togli</button>
						</div>
					<?php endforeach; ?>
				</div>
				<button type="button" class="button" data-aggiungi-riga="membri">Aggiungi una persona</button>
				<label class="pi-campo">Nota per chi scrive al Patriziato (piè di pagina e Contatti)<textarea name="pi[contatti_nota]" rows="2"><?php echo esc_textarea($o['contatti_nota']); ?></textarea></label>
			</section>

			<section class="pi-blocco">
				<h2>Gettoni per le strade forestali</h2>
				<label class="pi-campo">Testo<textarea name="pi[gettoni_testo]" rows="3"><?php echo esc_textarea($o['gettoni_testo']); ?></textarea></label>
				<p class="pi-aiuto">Dove si comprano i gettoni:</p>
				<div class="pi-righe" data-pi-righe="gettoni">
					<?php foreach ($gettoni as $i => $g) : ?>
						<div class="pi-riga">
							<label>Negozio o ristorante<input type="text" name="pi[gettoni][<?php echo (int) $i; ?>][nome]" value="<?php echo esc_attr($g['nome']); ?>"></label>
							<label>Telefono<input type="text" name="pi[gettoni][<?php echo (int) $i; ?>][telefono]" value="<?php echo esc_attr($g['telefono']); ?>"></label>
							<button type="button" class="button-link pi-togli" data-togli-riga>Togli</button>
						</div>
					<?php endforeach; ?>
				</div>
				<button type="button" class="button" data-aggiungi-riga="gettoni">Aggiungi un punto vendita</button>
				<label class="pi-campo">Le strade forestali (testo della pagina Territorio)<textarea name="pi[strade_testo]" rows="4"><?php echo esc_textarea($o['strade_testo']); ?></textarea></label>
			</section>

			<section class="pi-blocco">
				<h2>Pagina iniziale</h2>
				<label class="pi-campo">Frase sotto il titolo<textarea name="pi[home_intro]" rows="3"><?php echo esc_textarea($o['home_intro']); ?></textarea></label>
				<div class="pi-griglia">
					<?php pi_campo_foto('foto_ieri', $o['foto_ieri'], 'Foto d\'archivio (a sinistra)'); ?>
					<?php pi_campo_foto('foto_oggi', $o['foto_oggi'], 'Foto di oggi (a destra)'); ?>
				</div>
				<label class="pi-campo">Didascalia della foto d'archivio<input type="text" name="pi[foto_ieri_nota]" value="<?php echo esc_attr($o['foto_ieri_nota']); ?>" placeholder="ca. 1950"></label>
				<?php pi_campo_foto('storia_foto', $o['storia_foto'], 'Foto della sezione «Il Patriziato»'); ?>
			</section>

			<section class="pi-blocco">
				<h2>Territorio</h2>
				<label class="pi-campo">Introduzione<textarea name="pi[territorio_intro]" rows="3"><?php echo esc_textarea($o['territorio_intro']); ?></textarea></label>
				<div class="pi-griglia">
					<?php foreach (pi_paesi() as $k => $nome) : ?>
						<div>
							<h3><?php echo esc_html($nome); ?></h3>
							<label class="pi-campo">Testo<textarea name="pi[<?php echo esc_attr($k); ?>_testo]" rows="6"><?php echo esc_textarea($o[$k . '_testo']); ?></textarea></label>
							<?php pi_campo_foto($k . '_foto', $o[$k . '_foto'], 'Foto'); ?>
						</div>
					<?php endforeach; ?>
				</div>
			</section>

			<p class="pi-salva"><button type="submit" class="button button-primary button-hero">Salva</button></p>
		</form>
	</div>
	<?php
}
