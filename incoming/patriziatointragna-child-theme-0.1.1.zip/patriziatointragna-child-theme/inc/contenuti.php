<?php
/**
 * Modello dei contenuti.
 *
 * - Gli atti dell'albo sono articoli (`post`): restano agli indirizzi di sempre (/titolo-dell-atto/).
 *   Ogni atto ha un tipo (`pi_tipo`), allegati (`_pi_allegati`), e se riguarda un'assemblea la sua data
 *   (`_pi_assemblea_data`), da cui il sistema ricava da solo la scheda dell'assemblea (`pi_assemblea`).
 * - I documenti sempre validi (regolamenti, catalogo elettorale, elenco dei patrizi) sono `pi_documento`:
 *   il file si sostituisce e la versione precedente va da sola nello storico (`_pi_versioni`).
 */
if (!defined('ABSPATH')) {
	exit;
}

/** Tipi di atto: slug => [etichetta, descrizione per il cliente, legato a un'assemblea?]. */
function pi_tipi_atto() {
	return [
		'avviso'       => ['Avviso', 'Lavori, chiusure di strade, legna, acqua: un\'informazione pratica, anche con scadenza.', false],
		'convocazione' => ['Convocazione', 'L\'avviso di convocazione di un\'assemblea patriziale.', true],
		'verbale'      => ['Verbale', 'Il verbale di un\'assemblea.', true],
		'risoluzioni'  => ['Risoluzioni', 'L\'estratto delle risoluzioni di un\'assemblea.', true],
		'presenze'     => ['Lista presenze', 'La lista dei presenti a un\'assemblea.', true],
		'messaggio'    => ['Messaggio', 'Un messaggio dell\'Ufficio patriziale all\'assemblea.', true],
		'ratifica'     => ['Ratifica', 'Una ratifica o approvazione della Sezione degli enti locali o di un\'altra autorità.', false],
		'elezioni'     => ['Elezioni', 'Avvisi, proposte e risultati delle elezioni patriziali.', false],
		'comunicato'   => ['Comunicato', 'Ogni altra comunicazione ufficiale.', false],
	];
}

function pi_tipo_etichetta($slug) {
	$t = pi_tipi_atto();
	return isset($t[$slug]) ? $t[$slug][0] : 'Comunicato';
}

/** Raccolte dei documenti sempre validi. */
function pi_raccolte() {
	return [
		'registri'    => ['Registri dei patrizi', 'Catalogo elettorale ed elenco dei patrizi aggiornati.', true],
		'regolamenti' => ['Regolamenti e leggi', 'Le norme che reggono il Patriziato e l\'uso dei suoi beni.', false],
	];
}

add_action('init', 'pi_registra_contenuti', 5);
function pi_registra_contenuti() {
	register_taxonomy('pi_tipo', ['post'], [
		'labels'            => ['name' => 'Tipi di atto', 'singular_name' => 'Tipo di atto'],
		'public'            => false,
		'show_ui'           => false,
		'show_in_rest'      => false,
		'hierarchical'      => false,
		'rewrite'           => false,
		'meta_box_cb'       => false,
	]);

	register_taxonomy('pi_assemblea', ['post'], [
		'labels'            => ['name' => 'Assemblee', 'singular_name' => 'Assemblea'],
		'public'            => true,
		'show_ui'           => false,
		'show_in_rest'      => false,
		'hierarchical'      => false,
		'rewrite'           => ['slug' => 'assemblee', 'with_front' => false],
		'meta_box_cb'       => false,
	]);

	register_post_type('pi_documento', [
		'labels' => [
			'name'               => 'Documenti',
			'singular_name'      => 'Documento',
			'menu_name'          => 'Documenti',
			'add_new'            => 'Aggiungi documento',
			'add_new_item'       => 'Aggiungi un documento',
			'edit_item'          => 'Modifica il documento',
			'new_item'           => 'Nuovo documento',
			'view_item'          => 'Vedi il documento sul sito',
			'all_items'          => 'Tutti i documenti',
			'search_items'       => 'Cerca un documento',
			'not_found'          => 'Nessun documento.',
			'not_found_in_trash' => 'Nessun documento nel cestino.',
		],
		'public'          => true,
		'has_archive'     => 'documenti',
		'rewrite'         => ['slug' => 'documenti', 'with_front' => false],
		'supports'        => ['title'],
		'show_in_rest'    => false,
		'menu_position'   => 6,
		'menu_icon'       => 'dashicons-media-document',
		'capability_type' => 'post',
	]);

	// Una volta sola per versione dello schema: tipi di atto e permalink.
	if (get_option('pi_schema_versione') !== '1') {
		foreach (array_keys(pi_tipi_atto()) as $slug) {
			if (!term_exists($slug, 'pi_tipo')) {
				wp_insert_term(pi_tipo_etichetta($slug), 'pi_tipo', ['slug' => $slug]);
			}
		}
		add_action('wp_loaded', function () {
			flush_rewrite_rules(false);
			update_option('pi_schema_versione', '1', true);
		});
	}
}

/* ---------------------------------------------------------------------------
 * Lettura
 * ------------------------------------------------------------------------- */

function pi_tipo_di($post_id) {
	$t = get_the_terms($post_id, 'pi_tipo'); // usa la cache dei termini già caricata dalle query
	return (!is_wp_error($t) && $t) ? $t[0]->slug : 'comunicato';
}

/** Allegati di un atto: array di ID allegato, nell'ordine scelto. */
function pi_allegati($post_id) {
	$ids = get_post_meta($post_id, '_pi_allegati', true);
	$ids = is_array($ids) ? array_values(array_filter(array_map('intval', $ids))) : [];
	return array_values(array_filter($ids, function ($id) {
		return get_post_type($id) === 'attachment';
	}));
}

/** Dati di un file per la stampa: url, nome, formato, peso. */
function pi_file_info($id) {
	$path = get_attached_file($id);
	$url  = wp_get_attachment_url($id);
	if (!$url) {
		return null;
	}
	$ext = strtoupper(pathinfo($url, PATHINFO_EXTENSION));
	$size = ($path && file_exists($path)) ? filesize($path) : 0;
	return [
		'id'       => $id,
		'url'      => $url,
		'titolo'   => pi_nome_file_leggibile(get_the_title($id)),
		'formato'  => $ext === 'JPEG' ? 'JPG' : $ext,
		'peso'     => $size ? size_format($size, $size > 1048576 ? 1 : 0) : '',
		'immagine' => wp_attachment_is_image($id),
		'pdf'      => get_post_mime_type($id) === 'application/pdf',
	];
}

/** Avvisi in evidenza oggi (scadenza non passata). */
function pi_avvisi_attivi($limite = 3) {
	$oggi = current_time('Y-m-d');
	return get_posts([
		'post_type'      => 'post',
		'posts_per_page' => $limite,
		'meta_key'       => '_pi_evidenza_fino',
		'orderby'        => 'date',
		'order'          => 'DESC',
		'meta_query'     => [['key' => '_pi_evidenza_fino', 'value' => $oggi, 'compare' => '>=', 'type' => 'DATE']],
		'no_found_rows'  => true,
	]);
}

/** Data dell'assemblea (Y-m-d) di un termine pi_assemblea. */
function pi_assemblea_data($term) {
	$term = is_object($term) ? $term : get_term($term, 'pi_assemblea');
	return $term && !is_wp_error($term) ? (string) get_term_meta($term->term_id, 'pi_data', true) : '';
}

/** Assemblee ordinate per data, la più recente prima. */
function pi_assemblee($limite = 0) {
	$terms = get_terms([
		'taxonomy'   => 'pi_assemblea',
		'hide_empty' => true,
		'meta_key'   => 'pi_data',
		'orderby'    => 'meta_value',
		'order'      => 'DESC',
		'number'     => $limite,
	]);
	return is_wp_error($terms) ? [] : $terms;
}

/** Atti di un'assemblea, nell'ordine logico: convocazione, messaggi, verbale, risoluzioni, presenze. */
function pi_atti_assemblea($term_id) {
	$ordine = ['convocazione' => 1, 'messaggio' => 2, 'verbale' => 3, 'risoluzioni' => 4, 'presenze' => 5];
	$atti = get_posts([
		'post_type'      => 'post',
		'posts_per_page' => -1,
		'tax_query'      => [['taxonomy' => 'pi_assemblea', 'terms' => (int) $term_id]],
		'orderby'        => 'date',
		'order'          => 'ASC',
		'no_found_rows'  => true,
	]);
	usort($atti, function ($a, $b) use ($ordine) {
		$oa = $ordine[pi_tipo_di($a->ID)] ?? 9;
		$ob = $ordine[pi_tipo_di($b->ID)] ?? 9;
		return $oa === $ob ? strcmp($a->post_date, $b->post_date) : $oa - $ob;
	});
	return $atti;
}

/**
 * Collega un atto all'assemblea della data indicata, creando la scheda se manca.
 * La scheda prende ora e luogo dalla convocazione, se ci sono.
 */
function pi_collega_assemblea($post_id, $data) {
	if (!$data || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $data)) {
		$prima = wp_get_object_terms($post_id, 'pi_assemblea', ['fields' => 'ids']);
		wp_set_object_terms($post_id, [], 'pi_assemblea');
		pi_pulisci_assemblee($prima);
		return 0;
	}
	$slug = 'assemblea-' . $data;
	$term = get_term_by('slug', $slug, 'pi_assemblea');
	if (!$term) {
		$nome = 'Assemblea del ' . pi_data_lunga($data);
		$r = wp_insert_term($nome, 'pi_assemblea', ['slug' => $slug]);
		if (is_wp_error($r)) {
			return 0;
		}
		$term_id = (int) $r['term_id'];
		update_term_meta($term_id, 'pi_data', $data);
	} else {
		$term_id = (int) $term->term_id;
	}
	$prima = wp_get_object_terms($post_id, 'pi_assemblea', ['fields' => 'ids']);
	wp_set_object_terms($post_id, [$term_id], 'pi_assemblea');
	pi_pulisci_assemblee($prima);
	if (pi_tipo_di($post_id) === 'convocazione') {
		foreach (['ora' => '_pi_ora', 'luogo' => '_pi_luogo'] as $k => $meta) {
			$v = get_post_meta($post_id, $meta, true);
			if ($v !== '') {
				update_term_meta($term_id, 'pi_' . $k, $v);
			}
		}
	}
	return $term_id;
}

/** Prossima assemblea (data futura), altrimenti l'ultima svolta. */
function pi_assemblea_in_evidenza() {
	$oggi = current_time('Y-m-d');
	$futura = get_terms([
		'taxonomy' => 'pi_assemblea', 'hide_empty' => true, 'number' => 1,
		'meta_key' => 'pi_data', 'orderby' => 'meta_value', 'order' => 'ASC',
		'meta_query' => [['key' => 'pi_data', 'value' => $oggi, 'compare' => '>=', 'type' => 'DATE']],
	]);
	if (!is_wp_error($futura) && $futura) {
		return ['term' => $futura[0], 'futura' => true];
	}
	$ultima = pi_assemblee(1);
	return $ultima ? ['term' => $ultima[0], 'futura' => false] : null;
}

/** File attuale di un documento. */
function pi_documento_file($post_id) {
	$id = (int) get_post_meta($post_id, '_pi_file', true);
	return $id && get_post_type($id) === 'attachment' ? $id : 0;
}

function pi_documento_raccolta($post_id) {
	$r = get_post_meta($post_id, '_pi_raccolta', true);
	return isset(pi_raccolte()[$r]) ? $r : 'regolamenti';
}

/** Versioni precedenti: [['file'=>id,'data'=>'Y-m-d'], ...] dalla più recente. */
function pi_documento_versioni($post_id) {
	$v = get_post_meta($post_id, '_pi_versioni', true);
	return is_array($v) ? array_values(array_filter($v, function ($x) {
		return !empty($x['file']) && get_post_type((int) $x['file']) === 'attachment';
	})) : [];
}

function pi_documenti($raccolta = '') {
	$args = [
		'post_type' => 'pi_documento', 'posts_per_page' => -1, 'orderby' => ['menu_order' => 'ASC', 'title' => 'ASC'],
		'no_found_rows' => true,
	];
	if ($raccolta) {
		$args['meta_query'] = [['key' => '_pi_raccolta', 'value' => $raccolta]];
	}
	return get_posts($args);
}

/** Data italiana breve con numeri: 18.06.2026 */
function pi_data_breve($ymd_or_ts) {
	$ts = is_numeric($ymd_or_ts) ? (int) $ymd_or_ts : strtotime($ymd_or_ts . ' 12:00');
	return $ts ? wp_date('d.m.Y', $ts) : '';
}

/** Data italiana lunga: 18 giugno 2026 (sempre in italiano, qualunque sia la lingua di chi è collegato). */
function pi_data_lunga($ymd_or_ts) {
	$ts = is_numeric($ymd_or_ts) ? (int) $ymd_or_ts : strtotime($ymd_or_ts . ' 12:00');
	return $ts ? wp_date('j', $ts) . ' ' . pi_mese((int) wp_date('n', $ts)) . ' ' . wp_date('Y', $ts) : '';
}

function pi_mese($n) {
	$m = [1 => 'gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
	return $m[$n] ?? '';
}

/** Schede di assemblea rimaste senza atti (data corretta in un atto): via. */
function pi_pulisci_assemblee($term_ids) {
	foreach ((array) $term_ids as $tid) {
		$t = get_term((int) $tid, 'pi_assemblea');
		if ($t && !is_wp_error($t) && !get_objects_in_term($t->term_id, 'pi_assemblea')) {
			wp_delete_term($t->term_id, 'pi_assemblea');
		}
	}
}

/** «Verbale_vidimato_18_giugno_2026» → «Verbale vidimato 18 giugno 2026». */
function pi_nome_file_leggibile($t) {
	$t = html_entity_decode((string) $t, ENT_QUOTES, 'UTF-8');
	if (strpos($t, ' ') === false || substr_count($t, '_') > 1) {
		$t = trim(preg_replace('/[_\s]+|(?<=[a-z])-(?=[a-z])/i', ' ', $t));
		$t = mb_strtoupper(mb_substr($t, 0, 1)) . mb_substr($t, 1);
	}
	return $t;
}
