</main>
<?php
$c = function_exists('ticinoweb_get_contact_info') ? ticinoweb_get_contact_info() : [];
$email = $c['email'] ?? get_option('ticinoweb_contact_email');
$indirizzo = $c['address'] ?? get_option('ticinoweb_contact_address');
$logo = function_exists('ticinoweb_get_site_logo') ? ticinoweb_get_site_logo() : '';
$privacy = get_privacy_policy_url();
$crediti = get_page_by_path('crediti-fotografici');
?>
<footer class="pi-piede">
	<div class="contenitore">
		<div class="pi-piede__alto">
			<div class="pi-piede__marca">
				<?php if ($logo) : ?><img src="<?php echo esc_url($logo); ?>" alt="Stemma del Patriziato" width="112" height="112" loading="lazy"><?php endif; ?>
				<p class="pi-piede__nome"><?php echo esc_html(get_bloginfo('name')); ?></p>
			</div>
			<div class="pi-piede__recapiti">
				<h2 class="pi-piede__titolo">Recapiti</h2>
				<?php if ($indirizzo) : ?><p><?php echo nl2br(esc_html($indirizzo)); ?></p><?php endif; ?>
				<?php if ($email) : ?><p><a href="mailto:<?php echo esc_attr($email); ?>"><?php echo esc_html($email); ?></a></p><?php endif; ?>
				<?php if (pi_opz('contatti_nota')) : ?><p class="pi-piede__nota"><?php echo esc_html(pi_opz('contatti_nota')); ?></p><?php endif; ?>
			</div>
			<nav class="pi-piede__nav" aria-label="Sezioni del sito">
				<h2 class="pi-piede__titolo">Sezioni</h2>
				<?php
				if (has_nav_menu('pi-piede')) {
					wp_nav_menu(['theme_location' => 'pi-piede', 'container' => false, 'menu_class' => 'pi-piede__lista', 'depth' => 1]);
				} else {
					pi_menu_di_ripiego();
				}
				?>
			</nav>
		</div>
		<div class="pi-piede__basso">
			<span>© <?php echo esc_html(wp_date('Y')); ?> <?php echo esc_html(get_bloginfo('name')); ?></span>
			<?php if ($privacy) : ?><a href="<?php echo esc_url($privacy); ?>">Privacy</a><?php endif; ?>
			<?php if ($crediti && $crediti->post_status === 'publish') : ?><a href="<?php echo esc_url(get_permalink($crediti)); ?>">Crediti fotografici</a><?php endif; ?>
			<a href="<?php echo esc_url(trailingslashit(get_option('home')) . 'tw-login/'); ?>" rel="nofollow">Area riservata</a>
			<span class="pi-piede__firma">Sito di <a href="https://ticinoweb.com" target="_blank" rel="noopener">ticinoWEB</a></span>
		</div>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
