/* Patriziato di Intragna: menu, testata, foto che si scoprono, anteprima PDF, filtri dell'albo. Nessuna libreria. */
(function () {
	'use strict';
	var d = document;
	var riduci = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

	/* Menu su telefono e tablet */
	var btn = d.querySelector('[data-pi-menu]');
	var nav = d.getElementById('pi-navigazione');
	if (btn && nav) {
		var fuori = [d.getElementById('contenuto'), d.querySelector('.pi-piede')].filter(Boolean);
		var chiudi = function () {
			fuori.forEach(function (e) { e.inert = false; });
			btn.setAttribute('aria-expanded', 'false');
			btn.querySelector('.pi-menu-btn__testo').textContent = 'Menu';
			nav.removeAttribute('data-aperto');
			d.body.classList.remove('pi-menu-aperto');
		};
		btn.addEventListener('click', function () {
			if (btn.getAttribute('aria-expanded') === 'true') { chiudi(); return; }
			btn.setAttribute('aria-expanded', 'true');
			btn.querySelector('.pi-menu-btn__testo').textContent = 'Chiudi';
			nav.setAttribute('data-aperto', '');
			d.body.classList.add('pi-menu-aperto');
			fuori.forEach(function (e) { e.inert = true; });
			var primo = nav.querySelector('a');
			if (primo) { primo.focus(); }
		});
		d.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' && btn.getAttribute('aria-expanded') === 'true') { chiudi(); btn.focus(); }
		});
		window.matchMedia('(min-width: 1100px)').addEventListener('change', chiudi);
		nav.addEventListener('click', function (e) { if (e.target.closest('a')) { chiudi(); } });
	}

	/* Testata: si ritira scendendo, torna risalendo */
	var testata = d.querySelector('[data-pi-testata]');
	if (testata && !riduci) {
		var ultimo = window.scrollY, attesa = false;
		window.addEventListener('scroll', function () {
			if (attesa) { return; }
			attesa = true;
			requestAnimationFrame(function () {
				var y = window.scrollY;
				var aperto = btn && btn.getAttribute('aria-expanded') === 'true';
				if (!aperto && y > 240 && y > ultimo + 4) { testata.classList.add('pi-testata--nascosta'); }
				else if (y < ultimo - 4 || y < 240) { testata.classList.remove('pi-testata--nascosta'); }
				ultimo = y;
				attesa = false;
			});
		}, { passive: true });
		testata.addEventListener('focusin', function () { testata.classList.remove('pi-testata--nascosta'); });
	}

	/* Foto che si scoprono entrando nello schermo (una volta sola) e anteprima PDF caricata solo quando serve */
	var guarda = function (sel, fai, margine) {
		var el = d.querySelectorAll(sel);
		if (!el.length) { return; }
		if (!('IntersectionObserver' in window)) { el.forEach(fai); return; }
		var io = new IntersectionObserver(function (voci) {
			voci.forEach(function (v) {
				if (v.isIntersecting) { fai(v.target); io.unobserve(v.target); }
			});
		}, { rootMargin: margine || '0px 0px -8% 0px' });
		el.forEach(function (e) { io.observe(e); });
	};
	guarda('[data-pi-rivela]', function (e) { e.classList.add('pi-visto'); });
	guarda('[data-pi-pdf]', function (fig) {
		var c = fig.querySelector('.pi-anteprima__cornice');
		var f = d.createElement('iframe');
		f.src = fig.getAttribute('data-pi-pdf');
		f.title = 'Anteprima del documento';
		f.loading = 'lazy';
		c.innerHTML = '';
		c.appendChild(f);
	}, '200px 0px');

})();
