<?php
/** Risultati della ricerca: atti, documenti e pagine. */
get_header();
global $wp_query;
$q = get_search_query(false);
pi_testa_pagina($q !== '' ? 'Risultati per «' . $q . '»' : 'Cerca', $wp_query->found_posts ? sprintf(_n('%d risultato', '%d risultati', $wp_query->found_posts), $wp_query->found_posts) . ', dal più recente.' : '', ['Albo', pi_url_albo()]);
?>
<div class="contenitore pi-albo">
	<form class="pi-cerca" role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
		<label for="pi-cerca-risultati">Cerca per parola</label>
		<input id="pi-cerca-risultati" type="search" name="s" value="<?php echo esc_attr($q); ?>">
		<button type="submit" class="pi-bottone">Cerca</button>
	</form>
	<?php if (have_posts()) : ?>
		<ol class="pi-righe" role="list">
			<?php while (have_posts()) : the_post();
				if (get_post_type() === 'post') {
					pi_riga_atto(get_post());
				} else { ?>
					<li class="pi-riga">
						<span class="pi-riga__data"></span>
						<span class="pi-riga__tipo"><span class="pi-tipo"><?php echo get_post_type() === 'pi_documento' ? 'Documento' : 'Pagina'; ?></span></span>
						<a class="pi-riga__titolo" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
						<span class="pi-riga__file"></span>
					</li>
				<?php }
			endwhile; ?>
		</ol>
		<nav class="pi-paginazione" aria-label="Pagine dei risultati"><?php echo paginate_links(['prev_text' => 'Precedenti', 'next_text' => 'Successivi']); ?></nav>
	<?php else : ?>
		<p class="pi-vuoto">Nessun risultato. Prova con una parola sola, per esempio «verbale» o «legna», oppure <a href="<?php echo esc_url(pi_url_albo()); ?>">sfoglia l'albo</a>.</p>
	<?php endif; ?>
</div>
<?php get_footer(); ?>
