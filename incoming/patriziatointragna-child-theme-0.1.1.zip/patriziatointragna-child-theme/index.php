<?php
/** Ripiego per archivi non previsti: stesso elenco dell'albo. */
get_header();
pi_testa_pagina(wp_strip_all_tags(get_the_archive_title()) ?: 'Albo');
?>
<div class="contenitore pi-albo">
	<?php if (have_posts()) : ?>
		<ol class="pi-righe" role="list"><?php while (have_posts()) : the_post();
			pi_riga_atto(get_post());
		endwhile; ?></ol>
		<nav class="pi-paginazione"><?php echo paginate_links(); ?></nav>
	<?php else : ?>
		<p class="pi-vuoto">Niente da mostrare qui. <a href="<?php echo esc_url(pi_url_albo()); ?>">Vai all'albo</a>.</p>
	<?php endif; ?>
</div>
<?php get_footer(); ?>
