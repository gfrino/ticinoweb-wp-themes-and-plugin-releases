<?php
/**
 * Patriziato di Intragna, Golino e Verdasio — child di ticinoweb-ai-theme.
 * Prefisso funzioni: pi_  · prefisso classi CSS: pi-
 */
if (!defined('ABSPATH')) {
	exit;
}

define('PI_VERSIONE', wp_get_theme()->get('Version'));
define('PI_DIR', get_stylesheet_directory());
define('PI_URI', get_stylesheet_directory_uri());

require_once PI_DIR . '/inc/contenuti.php';     // tipi di atto, assemblee, documenti, funzioni di lettura
require_once PI_DIR . '/inc/impostazioni.php';  // pagina «Patriziato» nel CMS: ufficio, territorio, gettoni, home
require_once PI_DIR . '/inc/setup.php';         // asset, menu, immagini, pulizia del parent
require_once PI_DIR . '/inc/seo.php';           // indirizzi vecchi (301), noindex dei registri, sitemap
require_once PI_DIR . '/inc/template.php';      // funzioni di stampa usate dai template

if (is_admin()) {
	require_once PI_DIR . '/inc/admin-pubblicazione.php'; // modulo semplice per gli atti dell'albo
	require_once PI_DIR . '/inc/admin-documento.php';     // documenti con sostituzione e versioni
	require_once PI_DIR . '/inc/admin-cliente.php';       // cruscotto e menu semplificati per il Patriziato
}
