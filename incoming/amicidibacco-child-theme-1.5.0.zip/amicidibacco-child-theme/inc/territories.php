<?php
/** Two native-scroll chapters using the existing editorial fields and catalog. */
defined( 'ABSPATH' ) || exit;

/** Exact configured territory only; no fallback to unrelated or unavailable wines. */
function adb_territory_wines( $taxonomy, $term_id ) {
    static $cache = array();
    $term_id = absint( $term_id );
    if ( ! in_array( $taxonomy, array( 'pa_regione', 'pa_nazione' ), true ) || ! $term_id || ! function_exists( 'wc_get_product' ) ) { return array(); }
    $term = get_term( $term_id, $taxonomy );
    if ( ! $term || is_wp_error( $term ) ) { return array(); }
    $key = get_current_blog_id() . ':' . $taxonomy . ':' . $term_id;
    if ( isset( $cache[ $key ] ) ) { return $cache[ $key ]; }
    $param = 'pa_regione' === $taxonomy ? 'adb_region' : 'adb_country';
    $candidates = adb_products( array( 'limit' => 80, 'filters' => array( $param => $term->slug ) ) );
    shuffle( $candidates );
    $wines = $groups = $images = array();
    foreach ( $candidates as $wine ) {
        if ( ! adb_hero_wine_eligible( $wine ) || ! has_term( $term_id, $taxonomy, $wine->get_id() ) ) { continue; }
        $group = adb_hero_wine_group( $wine );
        $image = $wine->get_image_id();
        if ( isset( $groups[ $group ] ) || isset( $images[ $image ] ) ) { continue; }
        $groups[ $group ] = $images[ $image ] = true;
        $wines[] = $wine;
        if ( 5 === count( $wines ) ) { break; }
    }
    return $cache[ $key ] = $wines;
}

function adb_territory_chapter( $place ) {
    if ( ! in_array( $place, array( 'ticino', 'italia' ), true ) ) { return; }
    $taxonomy = 'ticino' === $place ? 'pa_regione' : 'pa_nazione';
    $term_id = absint( adb_home( $place . '_term_id' ) );
    $term = $term_id ? get_term( $term_id, $taxonomy ) : null;
    if ( ! $term || is_wp_error( $term ) ) { return; }
    $url = get_term_link( $term );
    if ( is_wp_error( $url ) ) { return; }
    $image = absint( adb_home( $place . '_image_id' ) );
    $wines = adb_territory_wines( $taxonomy, $term_id );
    $id = 'adb-territory-' . $place;
    ?>
    <section class="adb-territory-chapter" id="<?php echo esc_attr( $id ); ?>" data-territory-chapter data-territory-count="<?php echo esc_attr( count( $wines ) ); ?>" aria-labelledby="<?php echo esc_attr( $id ); ?>-title">
        <div class="adb-territory-chapter__stage" data-territory-stage>
            <?php if ( $image ) : ?><div class="adb-territory-chapter__landscape" data-territory-landscape><?php adb_photo( $image, 'full', array( 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '100vw', 'alt' => '' ) ); ?></div><?php endif; ?>
            <div class="adb-territory-chapter__shade" aria-hidden="true"></div>
            <header class="adb-territory-chapter__intro" data-territory-intro>
                <?php if ( adb_home( $place . '_subtitle' ) ) : ?><p class="adb-kicker"><?php echo esc_html( adb_home( $place . '_subtitle' ) ); ?></p><?php endif; ?>
                <h3 id="<?php echo esc_attr( $id ); ?>-title"><?php echo esc_html( $term->name ); ?></h3>
                <?php if ( adb_home( $place . '_text' ) ) : ?><p class="adb-territory-chapter__text"><?php echo esc_html( adb_home( $place . '_text' ) ); ?></p><?php endif; ?>
                <a class="adb-link" href="<?php echo esc_url( $url ); ?>"><?php esc_html_e( 'Esplora i vini', 'amicidibacco' ); ?> <?php echo adb_icon(); ?></a>
            </header>
            <?php if ( $wines ) : ?>
            <div class="adb-territory-chapter__rail" data-territory-rail>
                <span><?php echo esc_html( $term->name ); ?> <span aria-hidden="true">· <span data-territory-current>1</span> / <?php echo esc_html( count( $wines ) ); ?></span></span>
                <button type="button" class="adb-territory-chapter__toggle" data-territory-toggle aria-controls="<?php echo esc_attr( $id ); ?>-wines" aria-expanded="false" data-list-label="<?php esc_attr_e( 'Vedi tutti i vini', 'amicidibacco' ); ?>" data-scene-label="<?php esc_attr_e( 'Torna al paesaggio', 'amicidibacco' ); ?>"><?php esc_html_e( 'Vedi tutti i vini', 'amicidibacco' ); ?></button>
            </div>
            <ol class="adb-territory-wines" id="<?php echo esc_attr( $id ); ?>-wines" data-territory-wines>
                <?php foreach ( $wines as $index => $wine ) : ?>
                <li class="adb-territory-wine" data-territory-wine="<?php echo esc_attr( $index ); ?>">
                    <a class="adb-territory-wine__bottle" href="<?php echo esc_url( $wine->get_permalink() ); ?>" aria-label="<?php echo esc_attr( $wine->get_name() ); ?>"><?php echo $wine->get_image( 'large', array( 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '(max-width: 760px) 100px, 42vw', 'alt' => '' ) ); ?></a>
                    <div class="adb-territory-wine__info">
                        <?php if ( $wine->get_attribute( 'pa_cantina' ) ) : ?><p class="adb-territory-wine__producer"><?php echo esc_html( $wine->get_attribute( 'pa_cantina' ) ); ?></p><?php endif; ?>
                        <h4><a href="<?php echo esc_url( $wine->get_permalink() ); ?>"><?php echo esc_html( $wine->get_name() ); ?></a></h4>
                        <?php $denomination = adb_product_field_value( $wine->get_id(), 'etichetta' ); if ( $denomination ) : ?><p class="adb-territory-wine__denomination"><?php echo esc_html( $denomination ); ?></p><?php endif; ?>
                        <div class="adb-territory-wine__purchase"><div class="adb-territory-wine__price"><?php echo wp_kses_post( $wine->get_price_html() ); ?></div><a class="adb-link" href="<?php echo esc_url( $wine->get_permalink() ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Scopri %s', 'amicidibacco' ), $wine->get_name() ) ); ?>"><?php esc_html_e( 'Scopri il vino', 'amicidibacco' ); ?> <?php echo adb_icon(); ?></a></div>
                    </div>
                </li>
                <?php endforeach; ?>
            </ol>
            <div class="adb-territory-chapter__progress" aria-hidden="true"><span data-territory-progress></span></div>
            <?php endif; ?>
        </div>
    </section>
    <?php
}

function adb_territories_render() {
    ?>
    <section class="adb-territories adb-territories--chapters" aria-labelledby="adb-territory-title">
        <div class="adb-section-heading adb-wrap"><div><?php if ( adb_home( 'territory_eyebrow' ) ) : ?><p class="adb-kicker"><?php echo esc_html( adb_home( 'territory_eyebrow' ) ); ?></p><?php endif; ?><h2 id="adb-territory-title"><?php echo esc_html( adb_home( 'territory_title' ) ); ?></h2></div><?php if ( adb_home( 'territory_text' ) ) : ?><p><?php echo esc_html( adb_home( 'territory_text' ) ); ?></p><?php endif; ?></div>
        <?php adb_territory_chapter( 'ticino' ); adb_territory_chapter( 'italia' ); ?>
    </section>
    <?php
}
