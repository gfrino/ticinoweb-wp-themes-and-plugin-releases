<?php
/**
 * Template Name: Pagina legale Rainbow
 * Template Post Type: page
 *
 * @package RainbowNailsChildTheme
 */

get_header();

while ( have_posts() ) :
	the_post();
	$summary       = get_the_excerpt();
	$modified_iso  = get_the_modified_date( 'c' );
	$modified_date = get_the_modified_date( 'd.m.Y' );
	?>
	<main id="rn-main" class="rn-legal-page">
		<header class="rn-legal-page__hero">
			<div class="rn-legal-page__halos" aria-hidden="true"><span></span><span></span><span></span></div>
			<div class="rn-shell rn-legal-page__hero-grid" data-rn-reveal>
				<div>
					<p class="rn-kicker"><?php esc_html_e( 'Informazioni legali', 'rainbownails-child-theme' ); ?></p>
					<h1><?php the_title(); ?></h1>
				</div>
				<?php if ( $summary ) : ?>
					<p class="rn-legal-page__lead"><?php echo esc_html( $summary ); ?></p>
				<?php endif; ?>
			</div>
		</header>

		<section class="rn-legal-page__content rn-section">
			<div class="rn-shell rn-legal-page__grid">
				<article class="rn-prose rn-legal-page__article" data-rn-reveal>
					<?php the_content(); ?>
				</article>

				<aside class="rn-legal-page__aside" aria-label="<?php esc_attr_e( 'Informazioni sulla pagina', 'rainbownails-child-theme' ); ?>" data-rn-reveal>
					<p class="rn-kicker"><?php esc_html_e( 'Trasparenza', 'rainbownails-child-theme' ); ?></p>
					<h2><?php esc_html_e( 'Documenti e aggiornamenti', 'rainbownails-child-theme' ); ?></h2>
					<p class="rn-legal-page__updated"><?php esc_html_e( 'Ultimo aggiornamento', 'rainbownails-child-theme' ); ?> <time datetime="<?php echo esc_attr( $modified_iso ); ?>"><?php echo esc_html( $modified_date ); ?></time></p>
					<?php
					wp_nav_menu(
						array(
							'theme_location' => 'footer_utility',
							'container'      => 'nav',
							'container_aria_label' => __( 'Documenti e collegamenti utili', 'rainbownails-child-theme' ),
							'menu_class'     => 'rn-legal-nav',
							'fallback_cb'    => false,
							'depth'          => 1,
						)
					);
					?>
				</aside>
			</div>
		</section>
	</main>
	<?php
endwhile;

get_footer();
