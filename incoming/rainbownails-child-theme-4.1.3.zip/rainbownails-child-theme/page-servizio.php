<?php
/**
 * Template Name: Pagina servizio Rainbow
 * Template Post Type: page, trattamento
 *
 * @package RainbowNailsChildTheme
 */

get_header();

while ( have_posts() ) :
	the_post();
	get_template_part( 'template-parts/service-page' );
endwhile;

get_footer();
