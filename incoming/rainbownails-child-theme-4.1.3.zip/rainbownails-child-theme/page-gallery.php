<?php
/**
 * Dynamic Gallery page backed by the native ticinoWEB media galleries.
 *
 * @package RainbowNailsChildTheme
 */

get_header();
while ( have_posts() ) :
	the_post();
	$story_ids   = rainbownails_get_story_gallery_ids();
	$excluded    = rainbownails_get_home_used_media_ids( $story_ids );
	$excluded    = array_merge( $excluded, rainbownails_get_hero_gallery_ids() );
	$gallery_ids = rainbownails_get_inspiration_gallery_ids( $excluded );
	$intro       = rainbownails_get_gallery_page_intro( get_post() );
	?>
	<main id="rn-main" class="rn-gallery-page" data-rn-gallery-source="nail-inspiration" data-rn-gallery-count="<?php echo esc_attr( (string) count( $gallery_ids ) ); ?>">
		<header class="rn-gallery-page__hero">
			<div class="rn-shell rn-gallery-page__hero-grid" data-rn-reveal>
				<div>
					<p class="rn-kicker"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></p>
					<h1><?php the_title(); ?></h1>
				</div>
				<?php if ( $intro ) : ?><p class="rn-gallery-page__intro"><?php echo esc_html( $intro ); ?></p><?php endif; ?>
			</div>
		</header>

		<section class="rn-gallery-page__collection rn-section" aria-label="<?php esc_attr_e( 'Galleria di ispirazione', 'rainbownails-child-theme' ); ?>">
			<div class="rn-shell">
				<?php if ( $gallery_ids ) : ?>
					<div class="rn-gallery__grid">
						<?php foreach ( $gallery_ids as $image_id ) : ?>
							<figure class="rn-gallery__item rn-media-reveal">
								<?php
								echo wp_get_attachment_image(
									$image_id,
									'large',
									false,
									array(
										'loading'  => 'lazy',
										'decoding' => 'async',
										'sizes'    => '(max-width: 767px) 50vw, (max-width: 960px) 34vw, 25vw',
									)
								); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								?>
							</figure>
						<?php endforeach; ?>
					</div>
				<?php else : ?>
					<div class="rn-empty-state">
						<h2><?php esc_html_e( 'Nuove ispirazioni in arrivo', 'rainbownails-child-theme' ); ?></h2>
						<p><?php esc_html_e( 'La raccolta viene aggiornata direttamente dalla Libreria Media.', 'rainbownails-child-theme' ); ?></p>
					</div>
				<?php endif; ?>
			</div>
		</section>
	</main>
	<?php
endwhile;
get_footer();
