<?php
/**
 * Rainbow Nails child theme bootstrap.
 *
 * @package RainbowNailsChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once get_stylesheet_directory() . '/inc/theme-data.php';
require_once get_stylesheet_directory() . '/inc/gallery-sync.php';
require_once get_stylesheet_directory() . '/inc/service-sync.php';
require_once get_stylesheet_directory() . '/inc/class-rainbownails-menu-walker.php';

function rainbownails_setup() {
	load_child_theme_textdomain( 'rainbownails-child-theme', get_stylesheet_directory() . '/languages' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'responsive-embeds' );
	register_nav_menus(
		array(
			'footer_utility' => __( 'Footer — collegamenti utility', 'rainbownails-child-theme' ),
		)
	);
}
add_action( 'after_setup_theme', 'rainbownails_setup', 20 );

/**
 * Refresh treatment routes once after each child-theme update.
 *
 * The treatment CPT is registered dynamically by the parent from CMS settings.
 * Its rewrite rules can therefore be missing after an import or theme update,
 * even though the editor and generated permalinks are already available.
 */
function rainbownails_refresh_treatment_rewrite_rules() {
	if ( ! post_type_exists( 'trattamento' ) ) {
		return;
	}

	$version = (string) wp_get_theme()->get( 'Version' );
	if ( $version === (string) get_option( 'rainbownails_rewrite_rules_version', '' ) ) {
		return;
	}

	flush_rewrite_rules( false );
	update_option( 'rainbownails_rewrite_rules_version', $version, false );
}
add_action( 'init', 'rainbownails_refresh_treatment_rewrite_rules', 99 );

/**
 * Load the bespoke frontend and remove the parent's generic presentation.
 * CMS and SEO logic remain inherited from the parent.
 */
function rainbownails_assets() {
	$theme = wp_get_theme();
	$base  = get_stylesheet_directory();
	$uri   = get_stylesheet_directory_uri();

	wp_dequeue_style( 'ticinoweb-ai-style' );
	wp_deregister_style( 'ticinoweb-ai-style' );
	wp_dequeue_script( 'ticinoweb-ai-main' );
	wp_deregister_script( 'ticinoweb-ai-main' );

	$styles = array( 'style', 'base', 'header', 'home' );
	if ( ! is_front_page() ) {
		$styles[] = 'pages';
	}
	$styles[] = 'responsive';
	foreach ( $styles as $index => $name ) {
		$file   = 'style' === $name ? '/style.css' : "/assets/css/{$name}.css";
		$handle = "rainbownails-{$name}";
		$deps   = 0 === $index ? array( 'poppins-font' ) : array( "rainbownails-{$styles[ $index - 1 ]}" );
		wp_enqueue_style( $handle, $uri . $file, $deps, file_exists( $base . $file ) ? (string) filemtime( $base . $file ) : $theme->get( 'Version' ) );
	}

	$script_files = array(
		'navigation' => '/assets/js/navigation.js',
		'motion'     => '/assets/js/motion.js',
	);
	if ( is_front_page() ) {
		$script_files['services'] = '/assets/js/services.js';
		$script_files['hero'] = '/assets/js/hero.js';
		$script_files['faq']  = '/assets/js/faq.js';
		$script_files['contact'] = '/assets/js/contact.js';
	}
	foreach ( $script_files as $name => $file ) {
		wp_enqueue_script( "rainbownails-{$name}", $uri . $file, array(), (string) filemtime( $base . $file ), true );
	}
}
add_action( 'wp_enqueue_scripts', 'rainbownails_assets', 100 );

function rainbownails_defer_scripts( $tag, $handle ) {
	if ( 0 === strpos( $handle, 'rainbownails-' ) && false === strpos( $tag, ' defer' ) ) {
		return str_replace( ' src=', ' defer src=', $tag );
	}
	return $tag;
}
add_filter( 'script_loader_tag', 'rainbownails_defer_scripts', 10, 2 );

function rainbownails_body_classes( $classes ) {
	$classes[] = 'rainbownails-site';
	$classes[] = 'no-js';
	if ( is_page() ) {
		$page = get_queried_object();
		if ( $page instanceof WP_Post && ( has_shortcode( $page->post_content, 'tw_faq' ) || get_post_meta( $page->ID, '_tw_faq_page_set', true ) || ( function_exists( 'has_block' ) && has_block( 'ticinoweb/faq', $page ) ) ) ) {
			$classes[] = 'rn-page-has-faq';
		}
	}
	return $classes;
}
add_filter( 'body_class', 'rainbownails_body_classes' );

function rainbownails_preload_hero_image() {
	if ( ! is_front_page() ) {
		return;
	}
	$slides = rainbownails_get_hero_slides();
	if ( ! empty( $slides[0]['image'] ) ) {
		printf( '<link rel="preload" as="image" href="%s">' . "\n", esc_url( $slides[0]['image'] ) );
	}
}
add_action( 'wp_head', 'rainbownails_preload_hero_image', 2 );

/**
 * Represent treatment singles as services in the parent's JSON-LD output.
 *
 * @param array   $schema Parent schema.
 * @param WP_Post $post   Current post.
 * @return array
 */
function rainbownails_service_schema( $schema, $post ) {
	if ( ! $post instanceof WP_Post || 'trattamento' !== $post->post_type ) {
		return $schema;
	}

	$description = has_excerpt( $post ) ? get_the_excerpt( $post ) : wp_trim_words( wp_strip_all_tags( $post->post_content ), 36 );
	$service     = array(
		'@context'    => 'https://schema.org',
		'@type'       => 'Service',
		'@id'         => rainbownails_service_permalink( $post ) . '#service',
		'name'        => get_the_title( $post ),
		'description' => $description,
		'url'         => rainbownails_service_permalink( $post ),
		'provider'    => array(
			'@type' => 'LocalBusiness',
			'name'  => get_bloginfo( 'name' ),
			'url'   => home_url( '/' ),
		),
	);
	if ( has_post_thumbnail( $post ) ) {
		$service['image'] = get_the_post_thumbnail_url( $post, 'full' );
	}

	return $service;
}
add_filter( 'ticinoweb_seo_jsonld_article_schema', 'rainbownails_service_schema', 10, 2 );

/**
 * Register native taxonomy for treatments.
 */
function rainbownails_register_taxonomies() {
	$labels = array(
		'name'              => _x( 'Categorie Trattamenti', 'taxonomy general name', 'rainbownails-child-theme' ),
		'singular_name'     => _x( 'Categoria Trattamento', 'taxonomy singular name', 'rainbownails-child-theme' ),
		'search_items'      => __( 'Cerca Categorie', 'rainbownails-child-theme' ),
		'all_items'         => __( 'Tutte le Categorie', 'rainbownails-child-theme' ),
		'parent_item'       => __( 'Categoria Genitore', 'rainbownails-child-theme' ),
		'parent_item_colon' => __( 'Categoria Genitore:', 'rainbownails-child-theme' ),
		'edit_item'         => __( 'Modifica Categoria', 'rainbownails-child-theme' ),
		'update_item'       => __( 'Aggiorna Categoria', 'rainbownails-child-theme' ),
		'add_new_item'      => __( 'Aggiungi Nuova Categoria', 'rainbownails-child-theme' ),
		'new_item_name'     => __( 'Nuovo Nome Categoria', 'rainbownails-child-theme' ),
		'menu_name'         => __( 'Categorie', 'rainbownails-child-theme' ),
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'show_in_rest'      => true,
		'rewrite'           => array( 'slug' => 'categoria-trattamento', 'with_front' => false ),
	);

	register_taxonomy( 'categoria_trattamento', array( 'trattamento' ), $args );
}
add_action( 'init', 'rainbownails_register_taxonomies', 20 );

/**
 * Handle 301 redirects for unconfirmed or relocated treatment slugs to preserve SEO equity.
 */
function rainbownails_service_redirects() {
	if ( is_admin() ) {
		return;
	}

	$target_slug = '';
	if ( is_singular( 'trattamento' ) ) {
		$target_slug = get_post_field( 'post_name', get_queried_object_id() );
	} elseif ( isset( $_GET['trattamento'] ) ) {
		$target_slug = sanitize_title( wp_unslash( $_GET['trattamento'] ) );
	}

	if ( ! $target_slug ) {
		return;
	}

	$redirect_map = array(
		'manicure-classica'           => 'cura-delle-mani',
		'smalto-semipermanente'       => 'cura-delle-mani',
		'semipermanente-rinforzato'   => 'cura-delle-mani',
		'french-manicure-baby-boomer' => 'cura-delle-mani',
		'nail-art-decorazioni'        => 'cura-delle-mani',
		'riparazione-unghie'          => 'cura-delle-mani',
		'rimozione-gel-acrilico'      => 'cura-delle-mani',
		'ricostruzione-unghie-in-gel' => 'cura-delle-mani',
		'refill-gel'                  => 'cura-delle-mani',
	);

	if ( isset( $redirect_map[ $target_slug ] ) ) {
		$destination = get_page_by_path( $redirect_map[ $target_slug ], OBJECT, 'trattamento' );
		if ( $destination && 'publish' === $destination->post_status ) {
			wp_safe_redirect( rainbownails_service_permalink( $destination ), 301 );
			exit;
		}
	}
}
add_action( 'template_redirect', 'rainbownails_service_redirects', 10 );
