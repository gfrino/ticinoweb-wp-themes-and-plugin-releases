<?php
/**
 * Editorial fallback for standard WordPress pages.
 *
 * @package RainbowNailsChildTheme
 */
get_header();
while ( have_posts() ) :
	the_post();
	?>
	<main id="rn-main" class="rn-standard-page">
		<header class="rn-standard-page__hero"><div class="rn-shell" data-rn-reveal><p class="rn-kicker"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></p><h1><?php the_title(); ?></h1></div></header>
		<section class="rn-standard-page__content rn-section"><div class="rn-shell"><div class="rn-prose" data-rn-reveal><?php the_content(); ?></div></div></section>
	</main>
	<?php
endwhile;
get_footer();
