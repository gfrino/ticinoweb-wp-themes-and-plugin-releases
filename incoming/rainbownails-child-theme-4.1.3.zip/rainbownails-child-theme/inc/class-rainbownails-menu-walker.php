<?php
/**
 * Accessible menu walker for desktop megamenu and mobile accordion.
 *
 * @package RainbowNailsChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class RainbowNails_Menu_Walker extends Walker_Nav_Menu {
	private $mode;

	public function __construct( $mode = 'desktop' ) {
		$this->mode = $mode;
	}

	public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
		$path        = trailingslashit( (string) wp_parse_url( $item->url, PHP_URL_PATH ) );
		$is_services = false !== strpos( $path, '/servizi/' );
		$is_booking  = 0 === strpos( (string) $item->url, 'https://wa.me/' ) || false !== stripos( $item->title, 'prenota' );
		$classes     = array_filter( array_map( 'sanitize_html_class', (array) $item->classes ) );
		$classes[]   = 'rn-menu-item';
		$classes[]   = $is_services ? 'rn-menu-item--services' : '';
		$classes[]   = $is_booking ? 'rn-menu-item--booking' : '';
		$output     .= '<li class="' . esc_attr( implode( ' ', array_filter( $classes ) ) ) . '">';

		if ( $is_services ) {
			$target  = 'desktop' === $this->mode ? 'rn-megamenu' : 'rn-mobile-services';
			$control = 'desktop' === $this->mode ? 'data-rn-mega-toggle' : 'data-rn-services-toggle';
			$output .= sprintf(
				'<button class="rn-menu-link rn-menu-toggle" type="button" %1$s aria-expanded="false" aria-controls="%2$s"><span>%3$s</span><svg aria-hidden="true" viewBox="0 0 12 8"><path d="m1 1 5 5 5-5"/></svg></button>',
				esc_attr( $control ),
				esc_attr( $target ),
				esc_html( $item->title )
			);
			if ( 'mobile' === $this->mode ) {
				$output .= '<div class="rn-mobile-services" id="rn-mobile-services" hidden>';
				foreach ( rainbownails_get_service_groups() as $category => $services ) {
					$output .= '<p class="rn-mobile-services__label">' . esc_html( $category ) . '</p><ul class="rn-mobile-services__list">';
					foreach ( $services as $service ) {
						$output .= '<li><a href="' . esc_url( $service['url'] ) . '">' . esc_html( $service['title'] ) . '</a></li>';
					}
					$output .= '</ul>';
				}
				$output .= '<a class="rn-mobile-services__all" href="' . esc_url( $item->url ) . '">' . esc_html__( 'Scopri tutti i servizi', 'rainbownails-child-theme' ) . ' <span aria-hidden="true">→</span></a></div>';
			}
			return;
		}

		$attributes = array(
			'href'   => $item->url,
			'class'  => $is_booking ? 'rn-menu-link rn-menu-link--booking' : 'rn-menu-link',
			'target' => $item->target,
			'rel'    => $item->xfn,
		);
		$output .= '<a';
		foreach ( $attributes as $name => $value ) {
			if ( '' !== (string) $value ) {
				$output .= ' ' . esc_attr( $name ) . '="' . esc_attr( $value ) . '"';
			}
		}
		$output .= '>' . esc_html( $item->title ) . '</a>';
	}

	public function end_el( &$output, $item, $depth = 0, $args = null ) {
		$output .= '</li>';
	}
}
