<?php
/**
 * One-time migration from the original single gallery to CMS-owned collections.
 *
 * @package RainbowNailsChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return or create a native media gallery term.
 *
 * @param string $name        Gallery name.
 * @param string $slug        Gallery slug.
 * @param string $description Gallery description.
 * @return WP_Term|null
 */
function rainbownails_gallery_term( $name, $slug, $description ) {
	$term = get_term_by( 'slug', $slug, 'ticinoweb_media_gallery' );
	if ( $term && ! is_wp_error( $term ) ) {
		return $term;
	}
	$created = wp_insert_term(
		$name,
		'ticinoweb_media_gallery',
		array(
			'slug'        => $slug,
			'description' => $description,
		)
	);
	if ( is_wp_error( $created ) || empty( $created['term_id'] ) ) {
		return null;
	}
	$term = get_term( (int) $created['term_id'], 'ticinoweb_media_gallery' );
	return ( $term && ! is_wp_error( $term ) ) ? $term : null;
}

/**
 * Snapshot gallery membership and order before the one-time migration.
 *
 * @param WP_Term|null $term Gallery term.
 * @return array<string, mixed>|null
 */
function rainbownails_gallery_snapshot( $term ) {
	if ( ! $term instanceof WP_Term ) {
		return null;
	}
	return array(
		'term_id'     => (int) $term->term_id,
		'name'        => $term->name,
		'slug'        => $term->slug,
		'order'       => get_term_meta( $term->term_id, '_ticinoweb_gallery_order', true ),
		'attachments' => rainbownails_get_gallery_ids( $term->slug ),
	);
}

/**
 * Assign ordered images to a native gallery and optionally remove another term.
 *
 * @param WP_Term    $target      Target gallery.
 * @param array<int> $image_ids   Attachment IDs.
 * @param WP_Term    $source      Optional source gallery.
 * @return void
 */
function rainbownails_assign_gallery_images( $target, $image_ids, $source = null ) {
	$image_ids = rainbownails_unique_media_ids( $image_ids );
	foreach ( $image_ids as $image_id ) {
		wp_set_object_terms( $image_id, array( (int) $target->term_id ), 'ticinoweb_media_gallery', true );
		if ( $source instanceof WP_Term && (int) $source->term_id !== (int) $target->term_id ) {
			wp_remove_object_terms( $image_id, array( (int) $source->term_id ), 'ticinoweb_media_gallery' );
		}
	}
	update_term_meta( $target->term_id, '_ticinoweb_gallery_order', $image_ids );
}

/**
 * Create dedicated Hero and Story galleries without hardcoded attachment IDs.
 * Existing selections are respected; the original gallery is only reorganized once.
 *
 * @return void
 */
function rainbownails_sync_gallery_structure() {
	$structure_version = '1';
	if ( $structure_version === (string) get_option( 'rainbownails_gallery_structure_version', '' ) ) {
		return;
	}
	if ( ! taxonomy_exists( 'ticinoweb_media_gallery' ) ) {
		return;
	}

	$inspiration = get_term_by( 'slug', 'nail-inspiration', 'ticinoweb_media_gallery' );
	if ( ! $inspiration || is_wp_error( $inspiration ) ) {
		return;
	}

	$story = rainbownails_gallery_term(
		__( 'Rainbow Story', 'rainbownails-child-theme' ),
		'rainbow-story',
		__( 'Immagini narrative usate esclusivamente nelle sezioni editoriali della Home.', 'rainbownails-child-theme' )
	);
	$hero = rainbownails_gallery_term(
		__( 'Rainbow Hero', 'rainbownails-child-theme' ),
		'rainbow-hero',
		__( 'Immagini supplementari usate esclusivamente nella composizione Hero.', 'rainbownails-child-theme' )
	);
	if ( ! $story || ! $hero ) {
		return;
	}

	$gallery_page = get_page_by_path( 'gallery' );
	$backup       = array(
		'created_at'  => current_time( 'mysql' ),
		'inspiration' => rainbownails_gallery_snapshot( $inspiration ),
		'story'       => rainbownails_gallery_snapshot( $story ),
		'hero'        => rainbownails_gallery_snapshot( $hero ),
		'gallery_page' => $gallery_page instanceof WP_Post ? array(
			'id'      => (int) $gallery_page->ID,
			'content' => $gallery_page->post_content,
		) : null,
	);
	add_option( 'rainbownails_gallery_structure_backup_20261021', $backup, '', false );

	$inspiration_ids = rainbownails_get_gallery_ids( 'nail-inspiration' );
	$story_ids       = rainbownails_get_gallery_ids( 'rainbow-story' );
	if ( empty( $story_ids ) ) {
		$hero_keys    = array_values( array_filter( array_map( 'rainbownails_media_key', wp_list_pluck( rainbownails_get_hero_slides(), 'image' ) ) ) );
		$about_id     = rainbownails_attachment_id_from_url( get_option( 'ticinoweb_chi_siamo_image', '' ) );
		$story_pool   = array_values(
			array_filter(
				$inspiration_ids,
				static function ( $image_id ) use ( $hero_keys, $about_id ) {
					return (int) $image_id !== (int) $about_id && ! in_array( rainbownails_media_key( wp_get_attachment_url( $image_id ) ), $hero_keys, true );
				}
			)
		);
		$story_ids = array_slice( $story_pool, 0, 3 );
		rainbownails_assign_gallery_images( $story, $story_ids, $inspiration );
	}

	$hero_ids = rainbownails_get_gallery_ids( 'rainbow-hero' );
	if ( empty( $hero_ids ) ) {
		$used_ids  = rainbownails_get_home_used_media_ids( $story_ids );
		$hero_pool = rainbownails_unique_media_ids( $inspiration_ids, $used_ids );
		$hero_ids  = array_slice( $hero_pool, 0, 1 );
		rainbownails_assign_gallery_images( $hero, $hero_ids, $inspiration );
	}

	$moved_ids             = array_merge( $story_ids, $hero_ids );
	$remaining_inspiration = array_values( array_diff( $inspiration_ids, $moved_ids ) );
	update_term_meta( $inspiration->term_id, '_ticinoweb_gallery_order', $remaining_inspiration );

	if ( $gallery_page instanceof WP_Post && preg_match( '/(?:\[gallery\b|wp:gallery|galleryid-)/i', (string) $gallery_page->post_content ) ) {
		$intro = rainbownails_get_gallery_page_intro( $gallery_page );
		if ( $intro ) {
			wp_update_post(
				array(
					'ID'           => $gallery_page->ID,
					'post_content' => wp_slash( '<!-- wp:paragraph -->' . "\n" . '<p>' . esc_html( $intro ) . '</p>' . "\n" . '<!-- /wp:paragraph -->' ),
				)
			);
		}
	}

	update_option( 'rainbownails_gallery_structure_version', $structure_version, false );
}
add_action( 'init', 'rainbownails_sync_gallery_structure', 40 );
