<?php
/**
 * Read-only integration layer for ticinoWEB CMS and WordPress content.
 *
 * @package RainbowNailsChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rainbownails_frontend_text( $value, $context ) {
	return function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( (string) $value, 'rainbownails:' . $context ) : (string) $value;
}

/**
 * Return a working CPT URL with both pretty and plain permalink structures.
 *
 * @param WP_Post $post Treatment post.
 * @return string
 */
function rainbownails_service_permalink( $post ) {
	if ( '' === (string) get_option( 'permalink_structure' ) ) {
		return add_query_arg( 'trattamento', $post->post_name, home_url( '/' ) );
	}
	return get_permalink( $post );
}

function rainbownails_get_macro_categories() {
	return array(
		'mani-piedi' => array(
			'slug'        => 'mani-piedi',
			'number'      => '01',
			'title'       => __( 'Mani & Piedi', 'rainbownails-child-theme' ),
			'eyebrow'     => __( '01 — Cura & Dettagli', 'rainbownails-child-theme' ),
			'kicker'      => __( 'Mani & Piedi', 'rainbownails-child-theme' ),
			'description' => __( 'Trattamenti dedicati alla cura estetica e alla valorizzazione di mani, piedi e unghie, con attenzione ai dettagli e al tuo stile.', 'rainbownails-child-theme' ),
			'accent'      => 'pink',
			'color'       => '#f5b4cc',
			'order'       => 10,
		),
		'cerette'    => array(
			'slug'        => 'cerette',
			'number'      => '02',
			'title'       => __( 'Cerette', 'rainbownails-child-theme' ),
			'eyebrow'     => __( '02 — Epilazione delicata', 'rainbownails-child-theme' ),
			'kicker'      => __( 'Cerette', 'rainbownails-child-theme' ),
			'description' => __( 'Trattamenti di epilazione con ceretta dedicati alla cura estetica e alla valorizzazione della pelle, per una sensazione di ordine e benessere.', 'rainbownails-child-theme' ),
			'accent'      => 'peach',
			'color'       => '#ffc9ad',
			'order'       => 20,
		),
		'ciglia'     => array(
			'slug'        => 'ciglia',
			'number'      => '03',
			'title'       => __( 'Ciglia', 'rainbownails-child-theme' ),
			'eyebrow'     => __( '03 — Sguardo naturale', 'rainbownails-child-theme' ),
			'kicker'      => __( 'Ciglia', 'rainbownails-child-theme' ),
			'description' => __( 'Trattamenti estetici pensati per valorizzare la curvatura naturale delle ciglia e mettere in risalto la bellezza del tuo sguardo.', 'rainbownails-child-theme' ),
			'accent'      => 'lilac',
			'color'       => '#c9b5ef',
			'order'       => 30,
		),
		'viso'       => array(
			'slug'        => 'viso',
			'number'      => '04',
			'title'       => __( 'Viso', 'rainbownails-child-theme' ),
			'eyebrow'     => __( '04 — Benessere & Skincare', 'rainbownails-child-theme' ),
			'kicker'      => __( 'Viso', 'rainbownails-child-theme' ),
			'description' => __( 'Trattamenti dedicati alla detersione e alla cura della pelle del viso, per valorizzarne la luminosità in un momento di autentico benessere.', 'rainbownails-child-theme' ),
			'accent'      => 'sky',
			'color'       => '#b7def1',
			'order'       => 40,
		),
	);
}

function rainbownails_normalize_category_slug( $key ) {
	$sanitized = sanitize_title( (string) $key );
	if ( in_array( $sanitized, array( 'nails', 'mani', 'piedi', 'mani-e-piedi', 'mani-piedi' ), true ) ) {
		return 'mani-piedi';
	}
	if ( in_array( $sanitized, array( 'cerette', 'ceretta', 'epilazione' ), true ) ) {
		return 'cerette';
	}
	if ( in_array( $sanitized, array( 'ciglia', 'lash', 'lashes' ), true ) ) {
		return 'ciglia';
	}
	if ( in_array( $sanitized, array( 'viso', 'facial', 'skincare' ), true ) ) {
		return 'viso';
	}
	return $sanitized;
}

function rainbownails_get_services() {
	static $services = null;
	if ( null !== $services ) {
		return $services;
	}
	$services = array();
	$posts    = get_posts(
		array(
			'post_type'        => 'trattamento',
			'post_status'      => 'publish',
			'posts_per_page'   => -1,
			'orderby'          => array( 'menu_order' => 'ASC', 'title' => 'ASC' ),
			'no_found_rows'    => true,
			'suppress_filters' => false,
		)
	);
	$macros   = rainbownails_get_macro_categories();
	foreach ( $posts as $post ) {
		$image_id      = (int) get_post_thumbnail_id( $post );
		$terms         = get_the_terms( $post->ID, 'categoria_trattamento' );
		$term          = ( ! empty( $terms ) && ! is_wp_error( $terms ) ) ? $terms[0] : null;
		$category_raw  = $term ? $term->name : trim( (string) get_post_meta( $post->ID, '_rainbownails_service_category', true ) );
		$category_slug = $term ? $term->slug : rainbownails_normalize_category_slug( $category_raw );
		if ( isset( $macros[ $category_slug ] ) ) {
			$category_label = $macros[ $category_slug ]['title'];
		} elseif ( $category_raw ) {
			$category_label = rainbownails_frontend_text( $category_raw, 'service-category:' . sanitize_key( $category_raw ) );
		} else {
			$category_label = __( 'Trattamenti', 'rainbownails-child-theme' );
		}
		$subtitle    = trim( (string) get_post_meta( $post->ID, '_rainbownails_service_subtitle', true ) );
		$state       = trim( (string) get_post_meta( $post->ID, '_rainbownails_service_state', true ) );
		$description = has_excerpt( $post ) ? get_the_excerpt( $post ) : wp_trim_words( wp_strip_all_tags( $post->post_content ), 28 );
		$services[]  = array(
			'id'            => (int) $post->ID,
			'title'         => get_the_title( $post ),
			'description'   => $description,
			'subtitle'      => $subtitle,
			'state'         => $state,
			'content'       => apply_filters( 'the_content', $post->post_content ),
			'category_key'  => $category_raw ? $category_raw : $category_label,
			'category_slug' => $category_slug,
			'category'      => $category_label,
			'image_id'      => $image_id,
			'image'         => $image_id ? wp_get_attachment_image_url( $image_id, 'large' ) : '',
			'url'           => rainbownails_service_permalink( $post ),
		);
	}
	return $services;
}

/**
 * Return the complete public treatment catalogue for the Home.
 *
 * @return array<int, array<string, mixed>>
 */
function rainbownails_get_home_services() {
	return rainbownails_get_services();
}

/**
 * Return only categories that actually have published treatments.
 *
 * @return array<string, array<string, mixed>>
 */
function rainbownails_get_categories() {
	static $categories = null;
	if ( null !== $categories ) {
		return $categories;
	}
	$all_services = rainbownails_get_services();
	$macros       = rainbownails_get_macro_categories();
	$categories   = array();

	foreach ( $macros as $slug => $macro ) {
		$cat_services = array_values(
			array_filter(
				$all_services,
				static function ( $service ) use ( $slug ) {
					return $service['category_slug'] === $slug;
				}
			)
		);
		// Do not publish categories without services.
		if ( empty( $cat_services ) ) {
			continue;
		}

		$primary_service = $cat_services[0];
		$term            = get_term_by( 'slug', $slug, 'categoria_trattamento' );
		$desc            = ( $term && ! empty( $term->description ) ) ? $term->description : $macro['description'];
		$image_id        = $term ? (int) get_term_meta( $term->term_id, '_rn_category_image_id', true ) : 0;
		if ( ! $image_id && ! empty( $primary_service['image_id'] ) ) {
			$image_id = $primary_service['image_id'];
		}
		$image_url = $image_id ? wp_get_attachment_image_url( $image_id, 'large' ) : $primary_service['image'];

		$macro['description']   = $desc;
		$macro['services']      = $cat_services;
		$macro['service_count'] = count( $cat_services );
		$macro['image_id']      = $image_id;
		$macro['image']         = $image_url;
		$macro['url']           = home_url( '/servizi/#' . sanitize_title( $slug ) );
		$categories[ $slug ]    = $macro;
	}

	return $categories;
}

function rainbownails_get_service_groups() {
	$groups     = array();
	$categories = rainbownails_get_categories();
	foreach ( $categories as $cat ) {
		$groups[ $cat['title'] ] = $cat['services'];
	}
	// Fallback for any services outside macro categories
	foreach ( rainbownails_get_services() as $service ) {
		if ( ! isset( $groups[ $service['category'] ] ) ) {
			$groups[ $service['category'] ][] = $service;
		}
	}
	return $groups;
}

function rainbownails_get_hero_slides() {
	$base     = function_exists( 'ticinoweb_get_slider_data' ) ? ticinoweb_get_slider_data() : array();
	$extended = get_option( 'rainbownails_slider_extended', array() );
	$result   = array();
	foreach ( $base as $index => $slide ) {
		$extra    = isset( $extended[ $index + 1 ] ) && is_array( $extended[ $index + 1 ] ) ? $extended[ $index + 1 ] : array();
		$image    = isset( $slide['image'] ) ? $slide['image'] : '';
		$result[] = array(
			'image'          => $image,
			'image_id'       => rainbownails_attachment_id_from_url( $image ),
			'title'          => isset( $slide['title'] ) ? $slide['title'] : '',
			'description'    => isset( $slide['desc'] ) ? $slide['desc'] : '',
			'eyebrow'        => isset( $extra['subtitle'] ) ? rainbownails_frontend_text( $extra['subtitle'], 'hero:' . ( $index + 1 ) . ':subtitle' ) : '',
			'button'         => isset( $slide['btn1_text'] ) ? $slide['btn1_text'] : '',
			'link'           => rainbownails_normalize_url( isset( $slide['btn1_link'] ) ? $slide['btn1_link'] : '' ),
			'secondary_text' => isset( $extra['secondary_text'] ) ? rainbownails_frontend_text( $extra['secondary_text'], 'hero:' . ( $index + 1 ) . ':secondary-text' ) : '',
			'secondary_link' => rainbownails_normalize_url( isset( $extra['secondary_link'] ) ? $extra['secondary_link'] : '' ),
		);
	}
	return $result;
}

function rainbownails_normalize_url( $url ) {
	$url = trim( (string) $url );
	if ( '' === $url ) {
		return '';
	}
	if ( 0 === strpos( $url, '#' ) ) {
		return home_url( '/' . $url );
	}
	$fragment = wp_parse_url( $url, PHP_URL_FRAGMENT );
	$host     = wp_parse_url( $url, PHP_URL_HOST );
	$home     = wp_parse_url( home_url( '/' ), PHP_URL_HOST );
	if ( $fragment && ( ! $host || $host === $home || in_array( $host, array( 'localhost', '127.0.0.1' ), true ) ) ) {
		return home_url( '/#' . sanitize_title( $fragment ) );
	}
	return $url;
}

function rainbownails_get_home_sections() {
	static $sections = null;
	if ( null !== $sections ) {
		return $sections;
	}
	$sections = array();
	$page_id  = (int) get_option( 'page_on_front' );
	$content  = $page_id ? (string) get_post_field( 'post_content', $page_id ) : '';
	$unnamed  = 0;
	foreach ( parse_blocks( $content ) as $block ) {
		if ( 'core/group' !== $block['blockName'] ) {
			continue;
		}
		$key = ! empty( $block['attrs']['anchor'] ) ? sanitize_key( $block['attrs']['anchor'] ) : '';
		if ( '' === $key ) {
			++$unnamed;
			$key = 1 === $unnamed ? 'rainbow-moment' : 'section-' . $unnamed;
		}
		$html                       = render_block( $block );
		$sections[ $key ]           = rainbownails_extract_editorial_content( $html );
		$sections[ $key ]['html']   = $html;
	}
	return $sections;
}

function rainbownails_extract_editorial_content( $html ) {
	$result = array( 'eyebrow' => '', 'title' => '', 'paragraphs' => array() );
	if ( ! class_exists( 'DOMDocument' ) || '' === trim( $html ) ) {
		return $result;
	}
	$document = new DOMDocument();
	libxml_use_internal_errors( true );
	$document->loadHTML( '<?xml encoding="utf-8" ?><div>' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
	libxml_clear_errors();
	$headings = $document->getElementsByTagName( 'h2' );
	if ( $headings->length ) {
		$result['title'] = trim( $headings->item( 0 )->textContent );
	}
	foreach ( $document->getElementsByTagName( 'p' ) as $paragraph ) {
		$text = trim( $paragraph->textContent );
		if ( '' === $text ) {
			continue;
		}
		if ( '' === $result['eyebrow'] ) {
			$result['eyebrow'] = $text;
		} else {
			$result['paragraphs'][] = $text;
		}
	}
	return $result;
}

/**
 * Convert the editorial Gutenberg FAQ block into stable, semantic items.
 *
 * The local parent does not expose its native FAQ module yet, so the Home
 * content remains the single CMS source while the child controls presentation.
 */
function rainbownails_extract_faq_content( $html ) {
	$result = array( 'title' => '', 'items' => array() );
	if ( ! class_exists( 'DOMDocument' ) || '' === trim( (string) $html ) ) {
		return $result;
	}

	$document = new DOMDocument();
	libxml_use_internal_errors( true );
	$document->loadHTML( '<?xml encoding="utf-8" ?><div>' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
	libxml_clear_errors();

	$headings = $document->getElementsByTagName( 'h2' );
	if ( $headings->length ) {
		$result['title'] = trim( $headings->item( 0 )->textContent );
	}

	foreach ( $document->getElementsByTagName( 'h3' ) as $heading ) {
		$answer_html = '';
		$answer      = $heading->nextSibling;
		while ( $answer ) {
			if ( XML_ELEMENT_NODE === $answer->nodeType && in_array( strtolower( $answer->nodeName ), array( 'h2', 'h3' ), true ) ) {
				break;
			}
			if ( XML_ELEMENT_NODE === $answer->nodeType ) {
				$answer_html .= $document->saveHTML( $answer );
			}
			$answer = $answer->nextSibling;
		}
		if ( '' === trim( $answer_html ) ) {
			continue;
		}
		$result['items'][] = array(
			'question' => trim( $heading->textContent ),
			'answer'   => trim( $answer_html ),
		);
	}

	return $result;
}

/**
 * Return ordered attachment IDs from a native ticinoWEB media gallery.
 *
 * @param string $slug Gallery term slug.
 * @return array<int>
 */
function rainbownails_get_gallery_ids( $slug = 'nail-inspiration' ) {
	$term = get_term_by( 'slug', sanitize_title( $slug ), 'ticinoweb_media_gallery' );
	if ( ! $term || is_wp_error( $term ) ) {
		return array();
	}
	$order = get_term_meta( $term->term_id, '_ticinoweb_gallery_order', true );
	if ( is_array( $order ) && $order ) {
		return array_values( array_filter( array_map( 'absint', $order ) ) );
	}
	$ids = get_objects_in_term( $term->term_id, 'ticinoweb_media_gallery' );
	return is_wp_error( $ids ) ? array() : array_map( 'absint', $ids );
}

/**
 * Build a stable key for the same Media Library image across generated sizes.
 */
function rainbownails_media_key( $url ) {
	$path = (string) wp_parse_url( (string) $url, PHP_URL_PATH );
	$name = pathinfo( wp_basename( $path ), PATHINFO_FILENAME );
	return preg_replace( '/-\d+x\d+$/', '', strtolower( $name ) );
}

/**
 * Resolve a Media Library attachment from its original URL or a generated size.
 *
 * @param string $url Image URL stored by the CMS.
 * @return int
 */
function rainbownails_attachment_id_from_url( $url ) {
	$url = (string) $url;
	if ( '' === $url ) {
		return 0;
	}
	$attachment_id = attachment_url_to_postid( $url );
	if ( $attachment_id ) {
		return (int) $attachment_id;
	}
	$original_url = preg_replace( '/-\d+x\d+(?=\.[^.]+$)/', '', $url );
	return $original_url && $original_url !== $url ? (int) attachment_url_to_postid( $original_url ) : 0;
}

/**
 * Return the responsive data needed when an image changes in JavaScript.
 *
 * @param int    $attachment_id Attachment ID.
 * @param string $url           Fallback CMS URL.
 * @param string $size          Registered WordPress size.
 * @return array<string, mixed>
 */
function rainbownails_get_image_data( $attachment_id, $url, $size = 'large' ) {
	$attachment_id = absint( $attachment_id );
	if ( ! $attachment_id ) {
		$attachment_id = rainbownails_attachment_id_from_url( $url );
	}
	$data = array(
		'id'     => $attachment_id,
		'src'    => (string) $url,
		'srcset' => '',
		'sizes'  => '',
		'alt'    => '',
		'width'  => 0,
		'height' => 0,
	);
	if ( ! $attachment_id ) {
		return $data;
	}
	$source = wp_get_attachment_image_src( $attachment_id, $size );
	if ( $source ) {
		$data['src']    = $source[0];
		$data['width']  = (int) $source[1];
		$data['height'] = (int) $source[2];
	}
	$data['srcset'] = (string) wp_get_attachment_image_srcset( $attachment_id, $size );
	$data['sizes']  = (string) wp_get_attachment_image_sizes( $attachment_id, $size );
	$data['alt']    = trim( (string) get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ) );
	return $data;
}

/**
 * Keep valid, unique media while excluding images already used elsewhere.
 * Generated image sizes and duplicate attachment records share the same key.
 *
 * @param array<int> $candidate_ids Candidate attachment IDs.
 * @param array<int> $excluded_ids  Attachment IDs already used on the page.
 * @return array<int>
 */
function rainbownails_unique_media_ids( $candidate_ids, $excluded_ids = array() ) {
	$excluded_keys = array();
	foreach ( array_unique( array_map( 'absint', (array) $excluded_ids ) ) as $image_id ) {
		$key = rainbownails_media_key( wp_get_attachment_url( $image_id ) );
		if ( $key ) {
			$excluded_keys[ $key ] = true;
		}
	}

	$result = array();
	$seen   = array();
	foreach ( array_unique( array_map( 'absint', (array) $candidate_ids ) ) as $image_id ) {
		if ( ! $image_id || ! wp_attachment_is_image( $image_id ) ) {
			continue;
		}
		$key = rainbownails_media_key( wp_get_attachment_url( $image_id ) );
		if ( ! $key || isset( $seen[ $key ] ) || isset( $excluded_keys[ $key ] ) ) {
			continue;
		}
		$seen[ $key ] = true;
		$result[]     = $image_id;
	}

	return $result;
}

/**
 * Return the dedicated narrative images managed in Media > Gestisci Gallerie.
 *
 * @return array<int>
 */
function rainbownails_get_story_gallery_ids() {
	return array_slice( rainbownails_unique_media_ids( rainbownails_get_gallery_ids( 'rainbow-story' ) ), 0, 3 );
}

/**
 * Return optional supplemental Hero thumbnails from their dedicated gallery.
 *
 * @return array<int>
 */
function rainbownails_get_hero_gallery_ids() {
	return array_slice( rainbownails_unique_media_ids( rainbownails_get_gallery_ids( 'rainbow-hero' ) ), 0, 3 );
}

/**
 * Collect every content image used outside the inspiration grid on the Home.
 *
 * @param array<int>                                      $story_ids Narrative gallery IDs.
 * @param array<int, array<string, mixed>>|null           $slides    Hero slides.
 * @param array<string, array<string, mixed>>|null        $categories Service categories.
 * @return array<int>
 */
function rainbownails_get_home_used_media_ids( $story_ids = array(), $slides = null, $categories = null ) {
	$slides     = is_array( $slides ) ? $slides : rainbownails_get_hero_slides();
	$categories = is_array( $categories ) ? $categories : rainbownails_get_categories();
	$used_ids   = array_map( 'absint', (array) $story_ids );

	foreach ( $slides as $slide ) {
		$used_ids[] = ! empty( $slide['image_id'] ) ? absint( $slide['image_id'] ) : 0;
	}
	foreach ( $categories as $category ) {
		$used_ids[] = ! empty( $category['image_id'] ) ? absint( $category['image_id'] ) : 0;
	}
	$used_ids[] = rainbownails_attachment_id_from_url( get_option( 'ticinoweb_chi_siamo_image', '' ) );
	$used_ids[] = (int) get_post_thumbnail_id( (int) get_option( 'page_on_front' ) );

	return array_values( array_filter( array_unique( array_map( 'absint', $used_ids ) ) ) );
}

/**
 * Return the ordered inspiration grid without any image used elsewhere.
 *
 * @param array<int> $excluded_ids Page media to exclude.
 * @return array<int>
 */
function rainbownails_get_inspiration_gallery_ids( $excluded_ids = array() ) {
	return array_slice(
		rainbownails_unique_media_ids( rainbownails_get_gallery_ids( 'nail-inspiration' ), $excluded_ids ),
		0,
		20
	);
}

/**
 * Extract editable introductory copy while ignoring legacy gallery markup.
 *
 * @param WP_Post $post Page post.
 * @return string
 */
function rainbownails_get_gallery_page_intro( $post ) {
	if ( ! $post instanceof WP_Post ) {
		return '';
	}
	if ( has_excerpt( $post ) ) {
		return trim( (string) get_the_excerpt( $post ) );
	}
	$html = apply_filters( 'the_content', (string) $post->post_content );
	if ( ! class_exists( 'DOMDocument' ) || '' === trim( $html ) ) {
		return trim( wp_strip_all_tags( strip_shortcodes( (string) $post->post_content ) ) );
	}
	$document = new DOMDocument();
	libxml_use_internal_errors( true );
	$document->loadHTML( '<?xml encoding="utf-8" ?><div>' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
	libxml_clear_errors();
	foreach ( $document->getElementsByTagName( 'p' ) as $paragraph ) {
		$text = trim( $paragraph->textContent );
		if ( '' !== $text ) {
			return $text;
		}
	}
	return '';
}

function rainbownails_image( $attachment_id, $url, $size = 'large', $attributes = array() ) {
	$attachment_id = absint( $attachment_id );
	if ( ! $attachment_id ) {
		$attachment_id = rainbownails_attachment_id_from_url( $url );
	}
	if ( $attachment_id ) {
		return wp_get_attachment_image( $attachment_id, $size, false, $attributes );
	}
	if ( ! $url ) {
		return '';
	}
	$defaults = array( 'alt' => '', 'loading' => 'lazy', 'decoding' => 'async' );
	$attrs    = '';
	foreach ( array_merge( $defaults, $attributes ) as $name => $value ) {
		$attrs .= sprintf( ' %s="%s"', esc_attr( $name ), esc_attr( $value ) );
	}
	return sprintf( '<img src="%s"%s>', esc_url( $url ), $attrs );
}

function rainbownails_primary_menu_id() {
	$locations = get_nav_menu_locations();
	if ( ! empty( $locations['primary'] ) ) {
		return (int) $locations['primary'];
	}
	$menus = wp_get_nav_menus();
	return ! empty( $menus[0]->term_id ) ? (int) $menus[0]->term_id : 0;
}

function rainbownails_get_contact_data() {
	$parent = function_exists( 'ticinoweb_get_contact_info' ) ? ticinoweb_get_contact_info() : array();
	$phone  = get_option( 'ticinoweb_contact_phone', isset( $parent['phone'] ) ? $parent['phone'] : '' );
	return array(
		'address'       => isset( $parent['address'] ) ? $parent['address'] : rainbownails_frontend_text( get_option( 'ticinoweb_contact_address', '' ), 'contact:address' ),
		'email'         => get_option( 'ticinoweb_contact_email', isset( $parent['email'] ) ? $parent['email'] : '' ),
		'phone'         => $phone,
		'phone_display' => get_option( 'ticinoweb_contact_phone_display', $phone ),
		'instagram'     => get_option( 'ticinoweb_contact_instagram', isset( $parent['instagram'] ) ? $parent['instagram'] : '' ),
		'whatsapp'      => get_option( 'rainbownails_whatsapp_url', '' ),
		'hours'         => get_option( 'ticinoweb_contact_opening_hours', array() ),
	);
}

function rainbownails_get_logo_url() {
	return function_exists( 'ticinoweb_get_site_logo' ) ? (string) ticinoweb_get_site_logo() : (string) get_option( 'ticinoweb_site_logo', '' );
}

function rainbownails_get_logo_id() {
	return rainbownails_attachment_id_from_url( rainbownails_get_logo_url() );
}
