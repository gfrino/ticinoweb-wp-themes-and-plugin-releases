<?php
/**
 * Keep the parent's legacy CMS service option aligned with treatments.
 *
 * The treatment CPT is the only editorial source. The option remains a
 * compatibility projection for the parent CMS screen and its helper APIs.
 *
 * @package RainbowNailsChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Confirm that the current Multisite blog is using this child theme.
 *
 * Hooks remain registered after switch_to_blog(), so every write path must
 * verify the current blog dynamically instead of relying on a fixed blog ID.
 *
 * @return bool
 */
function rainbownails_is_current_theme_site() {
	return function_exists( 'get_stylesheet' ) && get_stylesheet() === basename( dirname( __DIR__ ) );
}

/**
 * Build the CMS-compatible service list from published treatments.
 *
 * @param array $existing Existing CMS rows, used only to preserve icon choices.
 * @return array<int, array<string, string>>
 */
function rainbownails_build_cms_services( $existing = array() ) {
	if ( ! rainbownails_is_current_theme_site() ) {
		return is_array( $existing ) ? $existing : array();
	}

	$existing_by_id    = array();
	$existing_by_title = array();
	foreach ( (array) $existing as $service ) {
		if ( ! is_array( $service ) ) {
			continue;
		}
		if ( ! empty( $service['id'] ) ) {
			$existing_by_id[ (string) $service['id'] ] = $service;
		}
		if ( ! empty( $service['title'] ) ) {
			$existing_by_title[ sanitize_title( $service['title'] ) ] = $service;
		}
	}

	$query_args = array(
		'post_type'        => 'trattamento',
		'post_status'      => 'publish',
		'posts_per_page'   => -1,
		'orderby'          => array( 'menu_order' => 'ASC', 'title' => 'ASC' ),
		'no_found_rows'    => true,
		'suppress_filters' => false,
	);
	$default_language = apply_filters( 'wpml_default_language', null );
	if ( is_string( $default_language ) && '' !== $default_language ) {
		$query_args['lang'] = $default_language;
	}
	$posts = get_posts( $query_args );

	$services = array();
	foreach ( $posts as $post ) {
		$service_id  = 'rn_treatment_' . (int) $post->ID;
		$title       = get_the_title( $post );
		$previous    = isset( $existing_by_id[ $service_id ] ) ? $existing_by_id[ $service_id ] : ( $existing_by_title[ sanitize_title( $title ) ] ?? array() );
		$image_id    = (int) get_post_thumbnail_id( $post );
		$description = has_excerpt( $post ) ? get_the_excerpt( $post ) : wp_trim_words( wp_strip_all_tags( $post->post_content ), 36 );

		$services[] = array(
			'id'          => $service_id,
			'image'       => $image_id ? (string) wp_get_attachment_image_url( $image_id, 'large' ) : '',
			'title'       => $title,
			'description' => $description,
			'icon'        => ! empty( $previous['icon'] ) ? sanitize_html_class( $previous['icon'] ) : 'dashicons-art',
			'icon_type'   => ! empty( $previous['icon_type'] ) && 'svg' === $previous['icon_type'] ? 'svg' : 'dashicon',
			'icon_svg'    => ! empty( $previous['icon_svg'] ) ? esc_url_raw( $previous['icon_svg'] ) : '',
		);
	}

	return $services;
}

/**
 * Reconcile the compatibility option without performing unnecessary writes.
 *
 * @return array<int, array<string, string>>
 */
function rainbownails_sync_cms_services() {
	$current = get_option( 'ticinoweb_services', array() );
	if ( ! rainbownails_is_current_theme_site() ) {
		return is_array( $current ) ? $current : array();
	}
	$synced  = rainbownails_build_cms_services( $current );

	if ( $current !== $synced ) {
		$GLOBALS['rainbownails_cms_service_projection'] = $synced;
		update_option( 'ticinoweb_services', $synced, false );
		unset( $GLOBALS['rainbownails_cms_service_projection'] );
	}

	return $synced;
}

/**
 * Prevent the legacy CMS form from becoming a second source of truth.
 *
 * @param mixed $new_value Submitted value.
 * @param mixed $old_value Stored value.
 * @return array<int, array<string, string>>
 */
function rainbownails_enforce_treatment_service_projection( $new_value, $old_value ) {
	if ( ! rainbownails_is_current_theme_site() ) {
		return $new_value;
	}
	if ( isset( $GLOBALS['rainbownails_cms_service_projection'] ) && is_array( $GLOBALS['rainbownails_cms_service_projection'] ) ) {
		return $GLOBALS['rainbownails_cms_service_projection'];
	}
	return rainbownails_build_cms_services( is_array( $old_value ) ? $old_value : array() );
}
add_filter( 'pre_update_option_ticinoweb_services', 'rainbownails_enforce_treatment_service_projection', 10, 2 );

/**
 * Recreate the projection if the legacy option is deleted manually.
 *
 * @param string $option Deleted option name.
 */
function rainbownails_restore_deleted_service_projection( $option ) {
	if ( 'ticinoweb_services' === $option && rainbownails_is_current_theme_site() ) {
		rainbownails_sync_cms_services();
	}
}
add_action( 'deleted_option', 'rainbownails_restore_deleted_service_projection' );

/**
 * Sync after a treatment is saved.
 *
 * @param int $post_id Treatment ID.
 */
function rainbownails_sync_service_on_save( $post_id ) {
	if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
		return;
	}
	rainbownails_sync_cms_services();
}
add_action( 'save_post_trattamento', 'rainbownails_sync_service_on_save', 30 );

/**
 * Sync when a treatment changes publication state.
 *
 * @param string  $new_status New status.
 * @param string  $old_status Previous status.
 * @param WP_Post $post       Updated post.
 */
function rainbownails_sync_service_on_status( $new_status, $old_status, $post ) {
	if ( $new_status !== $old_status && $post instanceof WP_Post && 'trattamento' === $post->post_type ) {
		rainbownails_sync_cms_services();
	}
}
add_action( 'transition_post_status', 'rainbownails_sync_service_on_status', 30, 3 );

/**
 * Sync after trash, restore or permanent deletion.
 *
 * @param int $post_id Post ID.
 */
function rainbownails_sync_service_on_removal( $post_id ) {
	if ( 'trattamento' === get_post_type( $post_id ) ) {
		rainbownails_sync_cms_services();
	}
}
add_action( 'trashed_post', 'rainbownails_sync_service_on_removal', 30 );
add_action( 'untrashed_post', 'rainbownails_sync_service_on_removal', 30 );

/**
 * Sync after WordPress has permanently removed a treatment.
 *
 * @param int     $post_id Deleted post ID.
 * @param WP_Post $post    Deleted post object.
 */
function rainbownails_sync_service_after_delete( $post_id, $post ) {
	unset( $post_id );
	if ( $post instanceof WP_Post && 'trattamento' === $post->post_type ) {
		rainbownails_sync_cms_services();
	}
}
add_action( 'after_delete_post', 'rainbownails_sync_service_after_delete', 30, 2 );

/**
 * Keep image changes reflected even when they are saved after the post.
 *
 * @param int    $meta_id Meta row ID.
 * @param int    $post_id Post ID.
 * @param string $meta_key Meta key.
 */
function rainbownails_sync_service_on_meta( $meta_id, $post_id, $meta_key ) {
	unset( $meta_id );
	if ( '_thumbnail_id' === $meta_key && 'trattamento' === get_post_type( $post_id ) ) {
		rainbownails_sync_cms_services();
	}
}
add_action( 'added_post_meta', 'rainbownails_sync_service_on_meta', 30, 3 );
add_action( 'updated_post_meta', 'rainbownails_sync_service_on_meta', 30, 3 );
add_action( 'deleted_post_meta', 'rainbownails_sync_service_on_meta', 30, 3 );

/**
 * Reconcile missed imports and make the CMS panel clearly read-only.
 */
function rainbownails_reconcile_services_in_admin() {
	$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( 'ticinoweb-cms' === $page ) {
		rainbownails_sync_cms_services();
	}
}
add_action( 'admin_init', 'rainbownails_reconcile_services_in_admin', 30 );

/**
 * Explain the single-source workflow directly in the parent's CMS screen.
 */
function rainbownails_service_sync_admin_footer() {
	if ( ! rainbownails_is_current_theme_site() ) {
		return;
	}
	$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( 'ticinoweb-cms' !== $page ) {
		return;
	}
	$treatments_url = admin_url( 'edit.php?post_type=trattamento' );
	?>
	<script>
	document.addEventListener('DOMContentLoaded', () => {
		const panel = document.getElementById('services');
		const container = document.getElementById('services-container');
		if (!panel || !container || container.dataset.rnSynchronized === 'true') return;
		container.dataset.rnSynchronized = 'true';
		const notice = document.createElement('div');
		notice.className = 'notice notice-info inline';
		notice.innerHTML = <?php echo wp_json_encode( '<p><strong>' . esc_html__( 'Servizi sincronizzati automaticamente.', 'rainbownails-child-theme' ) . '</strong> ' . esc_html__( 'Aggiungi, modifica, pubblica o rimuovi i servizi dalla sezione Trattamenti.', 'rainbownails-child-theme' ) . ' <a href="' . esc_url( $treatments_url ) . '">' . esc_html__( 'Gestisci i trattamenti', 'rainbownails-child-theme' ) . '</a></p>' ); ?>;
		container.before(notice);
		const legacyDescription = panel.querySelector('.notification-message');
		if (legacyDescription) {
			legacyDescription.hidden = true;
			legacyDescription.setAttribute('aria-hidden', 'true');
			legacyDescription.style.display = 'none';
		}
		container.querySelectorAll('input, textarea, .upload-service-image, .upload-service-svg, .remove-service').forEach((control) => {
			control.disabled = true;
		});
		panel.querySelectorAll('.remove-service, #add-service').forEach((control) => {
			control.hidden = true;
			control.disabled = true;
			control.setAttribute('aria-hidden', 'true');
			control.style.display = 'none';
		});
	});
	</script>
	<?php
}
add_action( 'admin_footer', 'rainbownails_service_sync_admin_footer', 30 );
