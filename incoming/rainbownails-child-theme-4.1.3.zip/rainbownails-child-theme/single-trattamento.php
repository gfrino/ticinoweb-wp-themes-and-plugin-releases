<?php
/**
 * Apply the shared service-page layout to every published treatment.
 *
 * @package RainbowNailsChildTheme
 */

get_header();

while ( have_posts() ) :
	the_post();
	get_template_part( 'template-parts/service-page' );
endwhile;

get_footer();
