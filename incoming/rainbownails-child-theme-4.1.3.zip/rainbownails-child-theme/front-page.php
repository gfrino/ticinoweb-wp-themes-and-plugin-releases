<?php
/**
 * THESIS: Rainbow Nails turns colour into an editorial self-expression journey.
 * OWN-WORLD: warm paper surfaces, sculpted photography and one organic rainbow ribbon.
 * STORY: desire → detail → treatments → colour → inspiration → place → booking.
 * FIRST VIEWPORT: a calm message balances one deep, layered three-image composition.
 * FORM: asymmetric layouts, measured overlaps and motion that follows real scroll.
 *
 * @package RainbowNailsChildTheme
 */

get_header();
$slides       = rainbownails_get_hero_slides();
$sections     = rainbownails_get_home_sections();
$services     = rainbownails_get_home_services();
$categories   = rainbownails_get_categories();
$story_ids    = rainbownails_get_story_gallery_ids();
$hero_gallery_ids = rainbownails_get_hero_gallery_ids();
$contacts     = rainbownails_get_contact_data();
$primary      = isset( $slides[0] ) ? $slides[0] : array();
$secondary    = isset( $slides[1] ) ? $slides[1] : $primary;
$tertiary     = isset( $slides[2] ) ? $slides[2] : $secondary;
$reveal_title_lines = ! empty( $secondary['title'] ) ? preg_split( '/(?<=\.)\s+/u', trim( $secondary['title'] ), -1, PREG_SPLIT_NO_EMPTY ) : array();
$intro        = isset( $sections['studio'] ) ? $sections['studio'] : array();
$services_copy = isset( $sections['servizi'] ) ? $sections['servizi'] : array();
$moment       = isset( $sections['rainbow-moment'] ) ? $sections['rainbow-moment'] : array();
$gallery_copy = isset( $sections['gallery'] ) ? $sections['gallery'] : array();
$contact_copy = isset( $sections['contatti'] ) ? $sections['contatti'] : array();
$about_image_id = rainbownails_attachment_id_from_url( get_option( 'ticinoweb_chi_siamo_image', '' ) );
$home_image_id = (int) get_post_thumbnail_id( (int) get_option( 'page_on_front' ) );
$intro_image_id = isset( $story_ids[0] ) ? $story_ids[0] : $home_image_id;
$moment_main_id = isset( $story_ids[1] ) ? $story_ids[1] : 0;
$moment_detail_id = isset( $story_ids[2] ) ? $story_ids[2] : 0;
$gallery_excluded_ids = rainbownails_get_home_used_media_ids( $story_ids, $slides, $categories );
$gallery_excluded_ids = array_merge( $gallery_excluded_ids, $hero_gallery_ids );
$gallery_display_ids  = rainbownails_get_inspiration_gallery_ids( $gallery_excluded_ids );
$gallery_ids          = $gallery_display_ids;
$faq_content  = ! empty( $sections['faq']['html'] ) ? rainbownails_extract_faq_content( $sections['faq']['html'] ) : array( 'title' => '', 'items' => array() );
?>
<main id="rn-main" class="rn-flow" data-rn-flow>
	<?php if ( $primary ) : ?>
	<?php
	$hero_thumbs = array();
	if ( ! empty( $secondary['image'] ) ) {
		$hero_thumbs[] = array(
			'id'    => $secondary['image_id'],
			'image' => $secondary['image'],
			'title' => ! empty( $secondary['title'] ) ? $secondary['title'] : '',
		);
	}
	if ( ! empty( $tertiary['image'] ) ) {
		$hero_thumbs[] = array(
			'id'    => $tertiary['image_id'],
			'image' => $tertiary['image'],
			'title' => ! empty( $tertiary['title'] ) ? $tertiary['title'] : '',
		);
	}
	foreach ( $hero_gallery_ids as $hero_gallery_id ) {
		if ( count( $hero_thumbs ) >= 3 ) {
			break;
		}
		$hero_thumbs[] = array(
			'id'    => $hero_gallery_id,
			'image' => wp_get_attachment_image_url( $hero_gallery_id, 'large' ),
			'title' => get_the_title( $hero_gallery_id ),
		);
	}
	?>
	<section class="rn-hero" data-rn-hero data-rn-flow-scene>
		<div class="rn-hero__sticky">
			<div class="rn-shell rn-hero__stage">
				<div class="rn-hero__copy" data-rn-hero-copy>
					<?php if ( $primary['eyebrow'] ) : ?><p class="rn-kicker" data-rn-hero-reveal="eyebrow"><?php echo esc_html( $primary['eyebrow'] ); ?></p><?php endif; ?>
					<h1 data-rn-hero-reveal="title"><?php echo esc_html( $primary['title'] ); ?></h1>
					<?php if ( $primary['description'] ) : ?><p class="rn-hero__lead" data-rn-hero-reveal="lead"><?php echo esc_html( $primary['description'] ); ?></p><?php endif; ?>
					<div class="rn-actions" data-rn-hero-reveal="actions">
						<?php if ( $primary['button'] && $primary['link'] ) : ?><a class="rn-button rn-button--primary" href="<?php echo esc_url( $primary['link'] ); ?>"><?php echo esc_html( $primary['button'] ); ?><span aria-hidden="true">↗</span></a><?php endif; ?>
						<?php if ( $primary['secondary_text'] && $primary['secondary_link'] ) : ?><a class="rn-text-link" href="<?php echo esc_url( $primary['secondary_link'] ); ?>"><?php echo esc_html( $primary['secondary_text'] ); ?><span aria-hidden="true">↓</span></a><?php endif; ?>
					</div>
					<?php if ( $hero_thumbs ) : ?>
					<div class="rn-hero__duo rn-hero__trio" data-rn-hero-reveal="duo">
						<?php foreach ( $hero_thumbs as $t_index => $thumb ) : ?>
						<figure class="rn-hero__thumb rn-hero__thumb--<?php echo esc_attr( (string) ( $t_index + 1 ) ); ?>">
							<?php echo rainbownails_image( $thumb['id'], $thumb['image'], 'large', array( 'alt' => $thumb['title'], 'loading' => 'eager', 'decoding' => 'async' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</figure>
						<?php endforeach; ?>
					</div>
					<?php endif; ?>
				</div>
				<div class="rn-hero__visual" data-rn-hero-visual>
					<div class="rn-hero__atmosphere" aria-hidden="true">
						<span class="rn-hero__halo rn-hero__halo--pink"></span>
						<span class="rn-hero__halo rn-hero__halo--sky"></span>
						<span class="rn-hero__halo rn-hero__halo--lilac"></span>
						<span class="rn-hero__spark rn-hero__spark--1"></span>
						<span class="rn-hero__spark rn-hero__spark--2"></span>
						<span class="rn-hero__spark rn-hero__spark--3"></span>
						<span class="rn-hero__spark rn-hero__spark--4"></span>
						<span class="rn-hero__spark rn-hero__spark--5"></span>
						<span class="rn-hero__spark rn-hero__spark--6"></span>
						<span class="rn-hero__spark rn-hero__spark--7"></span>
						<span class="rn-hero__spark rn-hero__spark--8"></span>
						<span class="rn-hero__spark rn-hero__spark--9"></span>
						<span class="rn-hero__spark rn-hero__spark--10"></span>
						<span class="rn-hero__spark rn-hero__spark--11"></span>
						<span class="rn-hero__spark rn-hero__spark--12"></span>
						<span class="rn-hero__spark rn-hero__spark--13"></span>
						<span class="rn-hero__spark rn-hero__spark--14"></span>
					</div>
					<figure class="rn-hero__image rn-hero__image--main" data-rn-hero-main data-rn-hero-enter="main">
						<?php echo rainbownails_image( $primary['image_id'], $primary['image'], 'full', array( 'alt' => $primary['title'], 'loading' => 'eager', 'fetchpriority' => 'high', 'decoding' => 'async' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</figure>
					<?php if ( $secondary['title'] || $secondary['description'] ) : ?>
					<div class="rn-hero__reveal" data-rn-hero-statement>
						<div class="rn-hero__reveal-copy" data-rn-hero-reveal-copy>
							<?php if ( $reveal_title_lines ) : ?>
							<p class="rn-hero__statement">
								<?php foreach ( $reveal_title_lines as $line_index => $reveal_title_line ) : ?><span<?php echo 1 === $line_index ? ' class="rn-hero__statement-accent"' : ''; ?>><?php echo esc_html( $reveal_title_line ); ?></span><?php endforeach; ?>
							</p>
							<?php endif; ?>
							<?php if ( $secondary['description'] ) : ?><p class="rn-hero__statement-subtitle"><?php echo nl2br( esc_html( $secondary['description'] ), false ); ?></p><?php endif; ?>
						</div>
						<svg class="rn-hero__reveal-ribbon" viewBox="0 0 248 142" aria-hidden="true" focusable="false">
							<path d="M8 134C28 53 94 10 238 10" />
							<path d="M13 137C34 60 99 17 239 17" />
							<path d="M19 139C40 67 104 24 240 24" />
							<path d="M25 140C47 74 110 31 241 31" />
							<path d="M32 141C54 81 116 38 242 38" />
						</svg>
					</div>
					<?php endif; ?>
				</div>
				<p class="rn-hero__scroll" aria-hidden="true"><span></span><?php esc_html_e( 'Scorri per esplorare', 'rainbownails-child-theme' ); ?></p>
			</div>
		</div>
	</section>
	<?php endif; ?>

	<?php if ( ! empty( $intro['title'] ) ) : ?>
	<section class="rn-intro rn-section" id="studio" data-rn-flow-scene>
		<div class="rn-intro__atmosphere" data-rn-intro-atmosphere aria-hidden="true">
			<span class="rn-intro__dot rn-intro__dot--1"></span>
			<span class="rn-intro__dot rn-intro__dot--2"></span>
			<span class="rn-intro__dot rn-intro__dot--3"></span>
			<span class="rn-intro__dot rn-intro__dot--4"></span>
			<span class="rn-intro__dot rn-intro__dot--5"></span>
			<span class="rn-intro__dot rn-intro__dot--6"></span>
			<span class="rn-intro__dot rn-intro__dot--7"></span>
			<span class="rn-intro__dot rn-intro__dot--8"></span>
			<span class="rn-intro__dot rn-intro__dot--9"></span>
		</div>
		<div class="rn-shell rn-intro__grid">
			<div class="rn-intro__image rn-media-reveal" data-rn-reveal<?php echo in_array( $intro_image_id, $story_ids, true ) ? ' data-rn-gallery-source="rainbow-story"' : ''; ?>>
				<?php echo rainbownails_image( $intro_image_id, $primary['image'], 'large', array( 'alt' => $intro['title'], 'loading' => 'lazy' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</div>
			<div class="rn-intro__copy" data-rn-reveal>
				<?php if ( $intro['eyebrow'] ) : ?><p class="rn-kicker"><?php echo esc_html( $intro['eyebrow'] ); ?></p><?php endif; ?>
				<h2><?php echo esc_html( $intro['title'] ); ?></h2>
				<?php foreach ( $intro['paragraphs'] as $paragraph ) : ?><p><?php echo esc_html( $paragraph ); ?></p><?php endforeach; ?>
				<a class="rn-arrow-link" href="<?php echo esc_url( get_permalink( get_page_by_path( 'studio' ) ) ); ?>"><?php esc_html_e( 'Conosci il mondo Rainbow', 'rainbownails-child-theme' ); ?> <span aria-hidden="true">→</span></a>
			</div>
		</div>
	</section>
	<?php endif; ?>

	<?php if ( $categories ) : ?>
	<section class="rn-services rn-section" id="servizi" data-rn-service-section data-rn-service-count="<?php echo esc_attr( (string) count( $categories ) ); ?>" data-rn-flow-scene>
		<div class="rn-services__ribbon" aria-hidden="true"><?php get_template_part( 'template-parts/rainbow-ribbon' ); ?></div>
		<div class="rn-shell">
			<header class="rn-section-heading" data-rn-reveal>
				<?php if ( ! empty( $services_copy['eyebrow'] ) ) : ?><p class="rn-kicker"><?php echo esc_html( $services_copy['eyebrow'] ); ?></p><?php endif; ?>
				<h2><?php echo esc_html( ! empty( $services_copy['title'] ) ? $services_copy['title'] : __( 'I nostri mondi beauty', 'rainbownails-child-theme' ) ); ?></h2>
				<?php if ( ! empty( $services_copy['paragraphs'][0] ) ) : ?><p><?php echo esc_html( $services_copy['paragraphs'][0] ); ?></p><?php endif; ?>
			</header>
			<div class="rn-services__layout">
				<div class="rn-services__visual" data-rn-service-visual aria-hidden="true">
					<?php $cat_index = 0; ?>
					<?php foreach ( $categories as $slug => $cat ) : ?>
						<div class="rn-services__image<?php echo 0 === $cat_index ? ' is-active' : ''; ?>" data-rn-service-image="<?php echo esc_attr( $slug ); ?>" data-rn-category-accent="<?php echo esc_attr( $cat['accent'] ); ?>">
							<?php echo rainbownails_image( $cat['image_id'], $cat['image'], 'large', array( 'alt' => '', 'loading' => 'lazy' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<span class="rn-services__badge rn-services__badge--<?php echo esc_attr( $cat['accent'] ); ?>">
								<span class="rn-services__badge-dot" aria-hidden="true"></span>
								<span><?php echo esc_html( $cat['title'] ); ?></span>
							</span>
						</div>
						<?php ++$cat_index; ?>
					<?php endforeach; ?>
				</div>
				<div class="rn-services__list">
					<?php $cat_index = 0; ?>
					<?php foreach ( $categories as $slug => $cat ) : ?>
						<article class="rn-service-row rn-service-row--category rn-service-row--<?php echo esc_attr( $cat['accent'] ); ?><?php echo 0 === $cat_index ? ' is-active' : ''; ?>" data-rn-service-item="<?php echo esc_attr( $slug ); ?>" data-rn-service-index="<?php echo esc_attr( (string) $cat_index ); ?>" data-rn-service-accent="<?php echo esc_attr( $cat['accent'] ); ?>" aria-current="<?php echo 0 === $cat_index ? 'true' : 'false'; ?>">
							<span class="rn-service-row__number"><?php echo esc_html( $cat['number'] ); ?></span>
							<div class="rn-service-row__content">
								<p class="rn-service-row__category rn-service-row__category--<?php echo esc_attr( $cat['accent'] ); ?>"><?php echo esc_html( $cat['eyebrow'] ); ?></p>
								<h3><?php echo esc_html( $cat['title'] ); ?></h3>
								<p class="rn-service-row__desc"><?php echo esc_html( $cat['description'] ); ?></p>
								<?php if ( ! empty( $cat['services'] ) ) : ?>
									<div class="rn-service-row__treatments">
										<span class="rn-service-row__treatments-label"><?php esc_html_e( 'Trattamenti disponibili', 'rainbownails-child-theme' ); ?></span>
										<ul class="rn-service-row__treatments-list">
											<?php foreach ( $cat['services'] as $treatment ) : ?>
												<li><a class="rn-service-pill" href="<?php echo esc_url( $treatment['url'] ); ?>"><?php echo esc_html( $treatment['title'] ); ?></a></li>
											<?php endforeach; ?>
										</ul>
									</div>
								<?php endif; ?>
							</div>
						</article>
						<?php ++$cat_index; ?>
					<?php endforeach; ?>
					<a class="rn-arrow-link rn-services__all" href="<?php echo esc_url( home_url( '/servizi/' ) ); ?>"><?php esc_html_e( 'Scopri tutti i trattamenti', 'rainbownails-child-theme' ); ?> <span aria-hidden="true">→</span></a>
				</div>
			</div>
		</div>
	</section>
	<?php endif; ?>

	<?php if ( ! empty( $moment['title'] ) || $gallery_ids ) : ?>
	<div class="rn-inspiration-stack" data-rn-inspiration-stack>
	<?php endif; ?>

	<?php if ( ! empty( $moment['title'] ) ) : ?>
	<section class="rn-moment rn-section" data-rn-flow-scene>
		<div class="rn-moment__ribbon" aria-hidden="true"><?php get_template_part( 'template-parts/rainbow-ribbon' ); ?></div>
		<div class="rn-shell rn-moment__inner">
			<div class="rn-moment__copy" data-rn-reveal>
				<?php if ( $moment['eyebrow'] ) : ?><p class="rn-kicker"><?php echo esc_html( $moment['eyebrow'] ); ?></p><?php endif; ?>
				<h2><?php echo esc_html( $moment['title'] ); ?></h2>
				<?php foreach ( $moment['paragraphs'] as $paragraph ) : ?><p><?php echo esc_html( $paragraph ); ?></p><?php endforeach; ?>
			</div>
			<?php if ( $moment_main_id ) : ?><figure class="rn-moment__image rn-media-reveal" data-rn-reveal data-rn-gallery-source="rainbow-story"><?php echo wp_get_attachment_image( $moment_main_id, 'large', false, array( 'loading' => 'lazy', 'decoding' => 'async' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></figure><?php endif; ?>
			<?php if ( $moment_detail_id ) : ?><figure class="rn-moment__detail rn-media-reveal" data-rn-reveal data-rn-gallery-source="rainbow-story"><?php echo wp_get_attachment_image( $moment_detail_id, 'medium_large', false, array( 'loading' => 'lazy', 'decoding' => 'async' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></figure><?php endif; ?>
		</div>
	</section>
	<?php endif; ?>

	<?php if ( $gallery_ids ) : ?>
	<section class="rn-gallery rn-section" id="gallery" data-rn-flow-scene data-rn-gallery-source="nail-inspiration" data-rn-gallery-count="<?php echo esc_attr( (string) count( $gallery_display_ids ) ); ?>">
		<div class="rn-shell">
			<header class="rn-section-heading rn-gallery__heading" data-rn-reveal>
				<?php if ( ! empty( $gallery_copy['eyebrow'] ) ) : ?><p class="rn-kicker"><?php echo esc_html( $gallery_copy['eyebrow'] ); ?></p><?php endif; ?>
				<h2><?php echo esc_html( ! empty( $gallery_copy['title'] ) ? $gallery_copy['title'] : __( 'Lasciati ispirare', 'rainbownails-child-theme' ) ); ?></h2>
				<?php if ( ! empty( $gallery_copy['paragraphs'][0] ) ) : ?><p><?php echo esc_html( $gallery_copy['paragraphs'][0] ); ?></p><?php endif; ?>
			</header>
			<div class="rn-gallery__grid">
				<?php foreach ( array_slice( $gallery_display_ids, 0, 20 ) as $image_id ) : ?>
					<figure class="rn-gallery__item rn-media-reveal">
						<?php
						echo wp_get_attachment_image(
							$image_id,
							'large',
							false,
							array(
								'loading'  => 'lazy',
								'decoding' => 'async',
								'sizes'    => '(max-width: 767px) 50vw, (max-width: 960px) 34vw, 25vw',
							)
						); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						?>
					</figure>
				<?php endforeach; ?>
			</div>
			<?php if ( $contacts['instagram'] ) : ?><a class="rn-button rn-button--outline rn-gallery__cta" href="<?php echo esc_url( $contacts['instagram'] ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Seguici su Instagram', 'rainbownails-child-theme' ); ?><span aria-hidden="true">↗</span></a><?php endif; ?>
		</div>
	</section>
	<?php endif; ?>

	<?php if ( ! empty( $moment['title'] ) || $gallery_ids ) : ?>
	</div>
	<?php endif; ?>

	<?php if ( ! empty( $faq_content['title'] ) && ! empty( $faq_content['items'] ) ) : ?>
	<section class="rn-faq rn-section" data-rn-faq data-rn-flow-scene>
		<div class="rn-shell rn-faq__inner">
			<header class="rn-faq__heading">
				<p class="rn-kicker"><?php esc_html_e( 'FAQ', 'rainbownails-child-theme' ); ?></p>
				<h2><?php echo esc_html( $faq_content['title'] ); ?></h2>
				<div class="rn-faq__progress" data-rn-faq-progress aria-hidden="true"><span></span></div>
				<p class="rn-faq__status" aria-hidden="true"><span data-rn-faq-current>01</span><span>/</span><span><?php echo esc_html( sprintf( '%02d', count( $faq_content['items'] ) ) ); ?></span></p>
			</header>
			<div class="rn-faq__list">
				<?php foreach ( $faq_content['items'] as $index => $item ) : ?>
				<article class="rn-faq__item<?php echo 0 === $index ? ' is-active' : ''; ?>" data-rn-faq-item>
					<span class="rn-faq__number" aria-hidden="true"><?php echo esc_html( sprintf( '%02d', $index + 1 ) ); ?></span>
					<div>
						<h3><?php echo esc_html( $item['question'] ); ?></h3>
						<div class="rn-faq__answer"><?php echo wp_kses_post( $item['answer'] ); ?></div>
					</div>
				</article>
				<?php endforeach; ?>
			</div>
		</div>
	</section>
	<?php endif; ?>

	<section class="rn-contact rn-section" id="contatti" data-rn-flow-scene data-rn-contact-atmosphere>
		<div class="rn-contact__atmosphere" aria-hidden="true">
			<span class="rn-contact__halo rn-contact__halo--coral"></span>
			<span class="rn-contact__halo rn-contact__halo--lilac"></span>
			<span class="rn-contact__halo rn-contact__halo--sky"></span>
			<span class="rn-contact__orbit"></span>
			<span class="rn-contact__drop rn-contact__drop--1"></span>
			<span class="rn-contact__drop rn-contact__drop--2"></span>
			<span class="rn-contact__drop rn-contact__drop--3"></span>
			<span class="rn-contact__drop rn-contact__drop--4"></span>
			<span class="rn-contact__drop rn-contact__drop--5"></span>
			<span class="rn-contact__drop rn-contact__drop--6"></span>
		</div>
		<div class="rn-contact__ribbon" aria-hidden="true"><?php get_template_part( 'template-parts/rainbow-ribbon' ); ?></div>
		<div class="rn-shell rn-contact__inner">
			<div class="rn-contact__copy">
				<p class="rn-kicker"><?php esc_html_e( 'Appuntamenti', 'rainbownails-child-theme' ); ?></p>
				<h2><?php echo esc_html( ! empty( $contact_copy['title'] ) ? $contact_copy['title'] : __( 'Il tuo prossimo colore ti aspetta.', 'rainbownails-child-theme' ) ); ?></h2>
				<?php if ( ! empty( $contact_copy['paragraphs'][0] ) ) : ?><p><?php echo esc_html( $contact_copy['paragraphs'][0] ); ?></p><?php endif; ?>
				<div class="rn-actions">
					<?php if ( $contacts['whatsapp'] ) : ?><a class="rn-button rn-button--primary" href="<?php echo esc_url( $contacts['whatsapp'] ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Prenota su WhatsApp', 'rainbownails-child-theme' ); ?><span aria-hidden="true">↗</span></a><?php endif; ?>
					<?php if ( $contacts['phone'] ) : ?><a class="rn-button rn-button--light" href="tel:<?php echo esc_attr( preg_replace( '/[^+0-9]/', '', $contacts['phone'] ) ); ?>"><?php esc_html_e( 'Chiamaci', 'rainbownails-child-theme' ); ?></a><?php endif; ?>
				</div>
			</div>
			<?php if ( $contacts['address'] || $contacts['phone'] || $contacts['instagram'] ) : ?>
			<aside class="rn-contact__panel" aria-labelledby="rn-contact-panel-title">
				<div class="rn-contact__swatches" aria-hidden="true"><span></span><span></span><span></span><span></span><span></span><span></span></div>
				<h3 class="rn-contact__panel-title" id="rn-contact-panel-title"><?php esc_html_e( 'Il tuo prossimo appuntamento', 'rainbownails-child-theme' ); ?></h3>
				<div class="rn-contact__details">
				<?php if ( $contacts['address'] ) : ?><div><span><?php esc_html_e( 'Dove', 'rainbownails-child-theme' ); ?></span><p><?php echo esc_html( $contacts['address'] ); ?></p><a href="<?php echo esc_url( 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $contacts['address'] ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Apri la mappa', 'rainbownails-child-theme' ); ?> ↗</a></div><?php endif; ?>
				<?php if ( $contacts['phone'] || $contacts['instagram'] ) : ?><div><span><?php esc_html_e( 'Parliamo', 'rainbownails-child-theme' ); ?></span><?php if ( $contacts['phone'] ) : ?><a href="tel:<?php echo esc_attr( preg_replace( '/[^+0-9]/', '', $contacts['phone'] ) ); ?>"><?php echo esc_html( $contacts['phone_display'] ); ?></a><?php endif; ?><?php if ( $contacts['instagram'] ) : ?><a href="<?php echo esc_url( $contacts['instagram'] ); ?>" target="_blank" rel="noopener">Instagram ↗</a><?php endif; ?></div><?php endif; ?>
				</div>
			</aside>
			<?php endif; ?>
		</div>
	</section>
</main>
<?php get_footer(); ?>
