<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="rn-skip-link" href="#rn-main"><?php esc_html_e( 'Vai al contenuto', 'rainbownails-child-theme' ); ?></a>
<?php
$logo_url = rainbownails_get_logo_url();
$logo_id  = rainbownails_get_logo_id();
$menu_id  = rainbownails_primary_menu_id();
$contacts = rainbownails_get_contact_data();
$services = rainbownails_get_services();
$groups   = rainbownails_get_service_groups();
$first    = ! empty( $services[0] ) ? $services[0] : null;
?>
<header class="rn-header" data-rn-header>
	<div class="rn-header__bar rn-shell">
		<a class="rn-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
			<?php if ( $logo_url ) : ?>
				<?php echo rainbownails_image( $logo_id, $logo_url, 'medium', array( 'alt' => get_bloginfo( 'name' ), 'loading' => 'eager', 'decoding' => 'async', 'sizes' => '(max-width: 960px) 124px, 190px' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php else : ?>
				<span><?php bloginfo( 'name' ); ?></span>
			<?php endif; ?>
		</a>
		<nav class="rn-desktop-nav" aria-label="<?php esc_attr_e( 'Navigazione principale', 'rainbownails-child-theme' ); ?>">
			<?php
			wp_nav_menu(
				array(
					'menu'        => $menu_id,
					'menu_class'  => 'rn-menu',
					'container'   => false,
					'fallback_cb' => false,
					'depth'       => 1,
					'walker'      => new RainbowNails_Menu_Walker( 'desktop' ),
				)
			);
			?>
		</nav>
		<div class="rn-header__mobile-actions">
			<?php if ( $contacts['whatsapp'] ) : ?>
				<a class="rn-header__quick-book" href="<?php echo esc_url( $contacts['whatsapp'] ); ?>" aria-label="<?php esc_attr_e( 'Prenota su WhatsApp', 'rainbownails-child-theme' ); ?>">
					<svg aria-hidden="true" viewBox="0 0 24 24"><path d="M20.5 3.5A11.8 11.8 0 0 0 12.1 0C5.6 0 .3 5.3.3 11.8c0 2.1.5 4.1 1.6 5.9L.2 24l6.4-1.7a11.8 11.8 0 0 0 5.5 1.4c6.5 0 11.8-5.3 11.8-11.8 0-3.2-1.2-6.1-3.4-8.4Zm-8.4 18.2c-1.7 0-3.4-.5-4.8-1.3l-.3-.2-3.8 1 1-3.7-.2-.4a9.7 9.7 0 1 1 8.1 4.6Zm5.3-7.3c-.3-.1-1.7-.8-2-.9-.3-.1-.5-.1-.7.2-.2.3-.8.9-.9 1.1-.2.2-.3.2-.6.1-1.7-.8-2.8-1.5-3.9-3.4-.3-.5.3-.5.8-1.6.1-.2 0-.4 0-.6l-.9-2.1c-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.6.1-.9.4-.3.3-1.2 1.2-1.2 2.9 0 1.7 1.2 3.4 1.4 3.6.2.2 2.4 3.7 5.9 5.2 2.2.9 3.1 1 4.2.9.7-.1 2.2-.9 2.5-1.8.3-.9.3-1.7.2-1.8-.1-.3-.3-.4-.6-.5Z"/></svg>
				</a>
			<?php endif; ?>
			<button class="rn-menu-button" type="button" data-rn-menu-toggle aria-expanded="false" aria-controls="rn-mobile-panel">
				<span class="rn-menu-button__label"><?php esc_html_e( 'Menu', 'rainbownails-child-theme' ); ?></span>
				<span class="rn-menu-button__icon" aria-hidden="true"><i></i><i></i></span>
			</button>
		</div>
	</div>

	<?php if ( $first ) : ?>
		<div class="rn-megamenu" id="rn-megamenu" data-rn-megamenu hidden>
			<div class="rn-megamenu__inner rn-shell">
				<div class="rn-megamenu__nav">
					<?php foreach ( $groups as $category => $category_services ) : ?>
						<p class="rn-megamenu__category"><?php echo esc_html( $category ); ?></p>
						<ul>
							<?php foreach ( $category_services as $service ) : ?>
								<?php
								$service_image     = rainbownails_get_image_data( $service['image_id'], $service['image'], 'large' );
								$service_image_alt = $service_image['alt'] ? $service_image['alt'] : $service['title'];
								?>
								<li><a href="<?php echo esc_url( $service['url'] ); ?>" data-rn-service-preview data-title="<?php echo esc_attr( $service['title'] ); ?>" data-description="<?php echo esc_attr( $service['description'] ); ?>" data-image="<?php echo esc_url( $service_image['src'] ); ?>" data-image-srcset="<?php echo esc_attr( $service_image['srcset'] ); ?>" data-image-sizes="<?php echo esc_attr( $service_image['sizes'] ); ?>" data-image-alt="<?php echo esc_attr( $service_image_alt ); ?>" data-image-width="<?php echo esc_attr( (string) $service_image['width'] ); ?>" data-image-height="<?php echo esc_attr( (string) $service_image['height'] ); ?>"><?php echo esc_html( $service['title'] ); ?></a></li>
							<?php endforeach; ?>
						</ul>
					<?php endforeach; ?>
					<a class="rn-arrow-link" href="<?php echo esc_url( home_url( '/servizi/' ) ); ?>"><?php esc_html_e( 'Scopri tutti i trattamenti', 'rainbownails-child-theme' ); ?> <span aria-hidden="true">→</span></a>
				</div>
				<div class="rn-megamenu__copy" aria-live="polite">
					<p class="rn-kicker"><?php esc_html_e( 'Trattamento selezionato', 'rainbownails-child-theme' ); ?></p>
					<h2 data-rn-preview-title><?php echo esc_html( $first['title'] ); ?></h2>
					<p data-rn-preview-description><?php echo esc_html( $first['description'] ); ?></p>
				</div>
				<div class="rn-megamenu__visual">
					<?php get_template_part( 'template-parts/rainbow-ribbon' ); ?>
					<?php echo rainbownails_image( $first['image_id'], $first['image'], 'large', array( 'data-rn-preview-image' => '', 'alt' => $first['title'], 'sizes' => '(max-width: 1200px) 30vw, 360px' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
			</div>
		</div>
	<?php endif; ?>

	<div class="rn-mobile-panel" id="rn-mobile-panel" data-rn-mobile-panel hidden>
		<div class="rn-mobile-panel__inner rn-shell">
			<nav aria-label="<?php esc_attr_e( 'Navigazione mobile', 'rainbownails-child-theme' ); ?>">
				<?php
				wp_nav_menu(
					array(
						'menu'        => $menu_id,
						'menu_class'  => 'rn-mobile-menu',
						'container'   => false,
						'fallback_cb' => false,
						'depth'       => 1,
						'walker'      => new RainbowNails_Menu_Walker( 'mobile' ),
					)
				);
				?>
			</nav>
			<div class="rn-mobile-panel__contact">
				<?php if ( $contacts['phone'] ) : ?><a href="tel:<?php echo esc_attr( preg_replace( '/[^+0-9]/', '', $contacts['phone'] ) ); ?>"><?php echo esc_html( $contacts['phone_display'] ); ?></a><?php endif; ?>
				<?php if ( $contacts['instagram'] ) : ?><a href="<?php echo esc_url( $contacts['instagram'] ); ?>" target="_blank" rel="noopener">Instagram</a><?php endif; ?>
			</div>
		</div>
	</div>
</header>
