<?php
/**
 * Services index page - Reorganized by Four Beauty Worlds.
 *
 * @package RainbowNailsChildTheme
 */

get_header();
$categories   = rainbownails_get_categories();
$all_services = rainbownails_get_services();
?>
<main id="rn-main" class="rn-inner-page">
	<header class="rn-inner-hero">
		<div class="rn-inner-hero__ribbon" aria-hidden="true"><?php get_template_part( 'template-parts/rainbow-ribbon' ); ?></div>
		<div class="rn-shell rn-inner-hero__content" data-rn-reveal>
			<p class="rn-kicker"><?php echo esc_html( get_bloginfo( 'name' ) ); ?> &middot; <?php esc_html_e( 'Locarno', 'rainbownails-child-theme' ); ?></p>
			<h1><?php the_title(); ?></h1>
			<p class="rn-inner-hero__lead">
				<?php
				if ( has_excerpt() ) {
					echo esc_html( get_the_excerpt() );
				} else {
					esc_html_e( 'Dalla cura di mani e piedi all’epilazione con ceretta, laminazione ciglia e pulizia del viso classica: scopri tutti i nostri trattamenti.', 'rainbownails-child-theme' );
				}
				?>
			</p>
			<?php if ( ! empty( $categories ) ) : ?>
				<nav class="rn-category-nav" aria-label="<?php esc_attr_e( 'Navigazione macro-categorie', 'rainbownails-child-theme' ); ?>">
					<?php foreach ( $categories as $slug => $cat ) : ?>
						<a class="rn-category-nav__item rn-category-nav__item--<?php echo esc_attr( $cat['accent'] ); ?>" href="#<?php echo esc_attr( $slug ); ?>">
							<span class="rn-category-nav__num"><?php echo esc_html( $cat['number'] ); ?></span>
							<span class="rn-category-nav__title"><?php echo esc_html( $cat['title'] ); ?></span>
						</a>
					<?php endforeach; ?>
				</nav>
			<?php endif; ?>
		</div>
	</header>
	<section class="rn-service-index rn-section">
		<div class="rn-shell">
			<?php if ( $categories ) : ?>
				<?php $global_index = 0; ?>
				<?php foreach ( $categories as $slug => $cat ) : ?>
					<section class="rn-service-category rn-service-category--<?php echo esc_attr( $cat['accent'] ); ?>" id="<?php echo esc_attr( $slug ); ?>" data-rn-service-category="<?php echo esc_attr( $slug ); ?>">
						<header class="rn-service-category__heading" data-rn-reveal>
							<div class="rn-service-category__meta">
								<p class="rn-kicker rn-kicker--<?php echo esc_attr( $cat['accent'] ); ?>"><?php echo esc_html( $cat['eyebrow'] ); ?></p>
								<h2><?php echo esc_html( $cat['title'] ); ?></h2>
								<p class="rn-service-category__desc"><?php echo esc_html( $cat['description'] ); ?></p>
							</div>
							<?php if ( ! empty( $cat['image'] ) ) : ?>
								<figure class="rn-service-category__visual rn-media-reveal">
									<?php echo rainbownails_image( $cat['image_id'], $cat['image'], 'large', array( 'alt' => $cat['title'], 'loading' => 'lazy' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								</figure>
							<?php endif; ?>
						</header>
						<div class="rn-service-category__items">
							<?php foreach ( $cat['services'] as $service ) : ?>
								<?php $index = $global_index++; ?>
								<article class="rn-service-feature<?php echo 1 === $index % 2 ? ' rn-service-feature--reverse' : ''; ?>" data-rn-reveal>
									<figure class="rn-service-feature__image rn-media-reveal">
										<?php echo rainbownails_image( $service['image_id'], $service['image'], 'large', array( 'alt' => $service['title'], 'loading' => 0 === $index ? 'eager' : 'lazy' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
									</figure>
									<div class="rn-service-feature__copy">
										<p class="rn-service-feature__number"><?php echo esc_html( str_pad( (string) ( $index + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></p>
										<h3><?php echo esc_html( $service['title'] ); ?></h3>
										<?php if ( ! empty( $service['subtitle'] ) ) : ?>
											<p class="rn-service-feature__subtitle"><?php echo esc_html( $service['subtitle'] ); ?></p>
										<?php endif; ?>
										<p class="rn-service-feature__desc"><?php echo esc_html( $service['description'] ); ?></p>
										<a class="rn-arrow-link" href="<?php echo esc_url( $service['url'] ); ?>"><?php esc_html_e( 'Scopri il trattamento', 'rainbownails-child-theme' ); ?> <span aria-hidden="true">&rarr;</span></a>
									</div>
								</article>
							<?php endforeach; ?>
						</div>
					</section>
				<?php endforeach; ?>
			<?php else : ?>
				<p class="rn-empty-state"><?php esc_html_e( 'I trattamenti saranno pubblicati presto. Contattaci per maggiori informazioni.', 'rainbownails-child-theme' ); ?></p>
			<?php endif; ?>
		</div>
	</section>
</main>
<?php get_footer(); ?>
