<?php
/**
 * Decorative brand ribbon. Content is intentionally absent from accessibility tree.
 *
 * @package RainbowNailsChildTheme
 */
?>
<svg class="rn-ribbon" viewBox="0 0 780 340" fill="none" aria-hidden="true" focusable="false">
	<defs>
		<?php $ribbon_id = esc_attr( wp_unique_id( 'rn-ribbon-' ) ); ?>
		<linearGradient id="<?php echo $ribbon_id; ?>-wash" x1="55" y1="286" x2="725" y2="58" gradientUnits="userSpaceOnUse">
			<stop stop-color="#c9b5ef"/><stop offset=".22" stop-color="#b7def1"/><stop offset=".42" stop-color="#c3e3cb"/><stop offset=".61" stop-color="#f6e5a6"/><stop offset=".8" stop-color="#ffc9ad"/><stop offset="1" stop-color="#f5b4cc"/>
		</linearGradient>
		<filter id="<?php echo $ribbon_id; ?>-shadow" x="-20%" y="-30%" width="140%" height="180%">
			<feDropShadow dx="0" dy="18" stdDeviation="18" flood-color="#b77f99" flood-opacity=".16"/>
		</filter>
	</defs>
	<path class="rn-ribbon__wash" d="M26 292C143 105 267 64 383 153C482 229 572 247 751 54" stroke="url(#<?php echo $ribbon_id; ?>-wash)" stroke-width="98" stroke-linecap="round" filter="url(#<?php echo $ribbon_id; ?>-shadow)"/>
	<g class="rn-ribbon__strands">
		<path class="rn-ribbon__strand rn-ribbon__strand--lilac" d="M14 271C137 84 270 51 393 139C493 211 584 224 741 43"/>
		<path class="rn-ribbon__strand rn-ribbon__strand--sky" d="M21 280C142 94 272 57 391 145C491 218 581 231 745 48"/>
		<path class="rn-ribbon__strand rn-ribbon__strand--mint" d="M28 289C147 104 274 64 389 151C489 225 578 238 749 53"/>
		<path class="rn-ribbon__strand rn-ribbon__strand--butter" d="M35 298C152 114 276 71 387 157C487 232 575 245 753 58"/>
		<path class="rn-ribbon__strand rn-ribbon__strand--peach" d="M42 307C157 124 278 78 385 163C485 239 572 252 757 63"/>
		<path class="rn-ribbon__strand rn-ribbon__strand--pink" d="M49 316C162 134 280 85 383 169C483 246 569 259 761 68"/>
	</g>
</svg>
