<?php
/**
 * Shared dynamic layout for WordPress service pages and treatments.
 *
 * @package RainbowNailsChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$post_id      = get_the_ID();
$post_type    = get_post_type( $post_id );
$image_id     = (int) get_post_thumbnail_id();
$contacts     = rainbownails_get_contact_data();
$summary      = trim( (string) get_the_excerpt() );
$category     = '';
$subtitle     = '';

if ( 'trattamento' === $post_type ) {
	$terms         = get_the_terms( $post_id, 'categoria_trattamento' );
	$term          = ( ! empty( $terms ) && ! is_wp_error( $terms ) ) ? $terms[0] : null;
	$category_slug = $term ? $term->slug : rainbownails_normalize_category_slug( get_post_meta( $post_id, '_rainbownails_service_category', true ) );
	$macros        = rainbownails_get_macro_categories();
	$category      = isset( $macros[ $category_slug ] ) ? $macros[ $category_slug ]['title'] : ( $term ? $term->name : '' );
	$subtitle_raw  = trim( (string) get_post_meta( $post_id, '_rainbownails_service_subtitle', true ) );
	$subtitle      = $subtitle_raw ? rainbownails_frontend_text( $subtitle_raw, 'service:' . $post_id . ':subtitle' ) : '';
} else {
	$parent_id = (int) wp_get_post_parent_id( $post_id );
	$category  = $parent_id ? get_the_title( $parent_id ) : __( 'Servizi', 'rainbownails-child-theme' );
}

if ( '' === $category ) {
	$category = __( 'Servizi', 'rainbownails-child-theme' );
}
?>
<main id="rn-main" class="rn-service-page<?php echo $image_id ? '' : ' rn-service-page--without-image'; ?>">
	<header class="rn-service-hero">
		<div class="rn-service-hero__halos" aria-hidden="true">
			<span class="rn-service-hero__halo rn-service-hero__halo--pink"></span>
			<span class="rn-service-hero__halo rn-service-hero__halo--sky"></span>
			<span class="rn-service-hero__halo rn-service-hero__halo--lilac"></span>
		</div>
		<div class="rn-shell rn-service-hero__grid">
			<div class="rn-service-hero__copy" data-rn-reveal>
				<p class="rn-kicker"><?php echo esc_html( $category ); ?></p>
				<h1><?php the_title(); ?></h1>
				<?php if ( $subtitle ) : ?>
					<p class="rn-service-hero__subtitle"><?php echo esc_html( $subtitle ); ?></p>
				<?php endif; ?>
				<?php if ( $summary ) : ?>
					<p class="rn-service-hero__summary"><?php echo esc_html( $summary ); ?></p>
				<?php endif; ?>
				<?php if ( $contacts['whatsapp'] || $contacts['phone'] ) : ?>
					<div class="rn-actions">
						<?php if ( $contacts['whatsapp'] ) : ?>
							<a class="rn-button rn-button--primary" href="<?php echo esc_url( $contacts['whatsapp'] ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Richiedi un appuntamento', 'rainbownails-child-theme' ); ?><span aria-hidden="true">&rarr;</span></a>
						<?php endif; ?>
						<?php if ( $contacts['phone'] ) : ?>
							<a class="rn-text-link" href="tel:<?php echo esc_attr( preg_replace( '/[^+0-9]/', '', $contacts['phone'] ) ); ?>"><?php esc_html_e( 'Chiamaci', 'rainbownails-child-theme' ); ?></a>
						<?php endif; ?>
					</div>
				<?php endif; ?>
			</div>

			<?php if ( $image_id ) : ?>
				<figure class="rn-service-hero__image rn-media-reveal" data-rn-reveal>
					<?php
					echo wp_get_attachment_image(
						$image_id,
						'full',
						false,
						array(
							'loading'       => 'eager',
							'fetchpriority' => 'high',
							'decoding'      => 'async',
						)
					); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					?>
				</figure>
			<?php endif; ?>
		</div>
	</header>

	<section class="rn-service-content rn-section">
		<div class="rn-shell rn-service-content__grid">
			<article class="rn-service-content__main" data-rn-reveal>
				<p class="rn-service-content__label"><?php esc_html_e( 'Il servizio', 'rainbownails-child-theme' ); ?></p>
				<div class="rn-prose"><?php the_content(); ?></div>
			</article>

			<?php if ( $contacts['whatsapp'] || $contacts['phone'] ) : ?>
				<aside class="rn-service-booking" data-rn-reveal aria-labelledby="rn-service-booking-title">
					<span class="rn-service-booking__glow" aria-hidden="true"></span>
					<p class="rn-kicker"><?php esc_html_e( 'Prenotazioni', 'rainbownails-child-theme' ); ?></p>
					<h2 id="rn-service-booking-title"><?php esc_html_e( 'Prenota il tuo momento Rainbow.', 'rainbownails-child-theme' ); ?></h2>
					<div class="rn-service-booking__actions">
						<?php if ( $contacts['whatsapp'] ) : ?>
							<a class="rn-button rn-button--primary" href="<?php echo esc_url( $contacts['whatsapp'] ); ?>" target="_blank" rel="noopener">WhatsApp <span aria-hidden="true">&rarr;</span></a>
						<?php endif; ?>
						<?php if ( $contacts['phone'] ) : ?>
							<a class="rn-button rn-button--light" href="tel:<?php echo esc_attr( preg_replace( '/[^+0-9]/', '', $contacts['phone'] ) ); ?>"><?php echo esc_html( $contacts['phone_display'] ); ?></a>
						<?php endif; ?>
					</div>
				</aside>
			<?php endif; ?>
		</div>
	</section>
</main>
