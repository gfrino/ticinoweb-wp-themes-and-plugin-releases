(() => {
  'use strict';

  const contact = document.querySelector('[data-rn-contact-atmosphere]');
  if (!contact) return;

  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  let visible = false;

  const update = () => {
    contact.classList.toggle('is-contact-active', visible && !document.hidden && !reduceMotion.matches);
  };

  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting;
      update();
    }, { threshold: .08 });
    observer.observe(contact);
  } else {
    visible = true;
  }

  document.addEventListener('visibilitychange', update);
  reduceMotion.addEventListener?.('change', update);
  update();
})();
