(() => {
  'use strict';

  const hero = document.querySelector('[data-rn-hero]');
  if (!hero) return;

  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const atmosphere = hero.querySelector('.rn-hero__atmosphere');
  let frame = 0;
  let heroVisible = true;
  let entranceTimer = 0;
  let scrollIdleTimer = 0;

  const finishEntrance = () => {
    window.clearTimeout(entranceTimer);
    hero.classList.add('is-ready', 'has-entered');
  };

  const startEntrance = () => {
    if (reduceMotion.matches) {
      finishEntrance();
      return;
    }

    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        hero.classList.add('is-ready');
        entranceTimer = window.setTimeout(() => hero.classList.add('has-entered'), 1450);
      });
    });
  };

  const updateAtmosphere = () => {
    hero.classList.toggle('is-atmosphere-active', Boolean(atmosphere) && heroVisible && !document.hidden && !reduceMotion.matches);
  };

  const update = () => {
    frame = 0;
    if (reduceMotion.matches || window.innerWidth <= 960) {
      hero.style.setProperty('--rn-hero-progress', '0');
      return;
    }
    const rect = hero.getBoundingClientRect();
    const distance = Math.max(1, hero.offsetHeight - window.innerHeight);
    const progress = Math.min(1, Math.max(0, -rect.top / distance));
    hero.style.setProperty('--rn-hero-progress', progress.toFixed(4));
  };

  const schedule = () => {
    if (!frame) frame = requestAnimationFrame(update);
  };

  const handleScroll = () => {
    if (!reduceMotion.matches && window.innerWidth > 960) {
      hero.classList.add('is-scrolling');
      window.clearTimeout(scrollIdleTimer);
      scrollIdleTimer = window.setTimeout(() => hero.classList.remove('is-scrolling'), 160);
    }
    schedule();
  };

  startEntrance();
  update();
  updateAtmosphere();

  if ('IntersectionObserver' in window) {
    const visibilityObserver = new IntersectionObserver(([entry]) => {
      heroVisible = entry.isIntersecting;
      updateAtmosphere();
    }, { threshold: .01 });
    visibilityObserver.observe(hero);
  }

  window.addEventListener('scroll', handleScroll, { passive: true });
  window.addEventListener('resize', schedule, { passive: true });
  window.addEventListener('load', schedule, { once: true });
  document.addEventListener('visibilitychange', updateAtmosphere);
  reduceMotion.addEventListener?.('change', () => {
    if (reduceMotion.matches) finishEntrance();
    schedule();
    updateAtmosphere();
  });
})();
