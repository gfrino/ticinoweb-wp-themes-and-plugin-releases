(() => {
  'use strict';

  document.querySelectorAll('[data-rn-service-section]').forEach((section) => {
    const items = [...section.querySelectorAll('[data-rn-service-item]')];
    const images = [...section.querySelectorAll('[data-rn-service-image]')];
    if (!items.length || !images.length) return;

    const imageById = new Map(images.map((image) => [image.dataset.rnServiceImage, image]));
    let hoverId = null;
    let scrollId = items[0].dataset.rnServiceItem;
    let currentId = scrollId;
    let activationToken = 0;
    let scrollFrame = 0;
    let leaveTimer = 0;

    const syncItems = (id) => {
      items.forEach((item) => {
        const active = item.dataset.rnServiceItem === id;
        item.classList.toggle('is-active', active);
        item.setAttribute('aria-current', active ? 'true' : 'false');
      });
      section.dataset.rnActiveService = id;
    };

    const prepareImage = async (container) => {
      const image = container?.querySelector('img');
      if (!image) return;
      image.loading = 'eager';
      if (!image.complete) {
        await new Promise((resolve) => {
          image.addEventListener('load', resolve, { once: true });
          image.addEventListener('error', resolve, { once: true });
        });
      }
      if (image.naturalWidth && typeof image.decode === 'function') {
        await image.decode().catch(() => {});
      }
      container.classList.add('is-ready');
    };

    const warmNeighbours = (id) => {
      const index = images.findIndex((image) => image.dataset.rnServiceImage === id);
      [images[index - 1], images[index + 1]].filter(Boolean).forEach((image) => {
        prepareImage(image);
      });
    };

    const activate = async (id) => {
      const nextImage = imageById.get(id);
      const token = ++activationToken;
      if (!nextImage) return;
      if (id === currentId) {
        section.classList.remove('is-service-loading');
        syncItems(currentId);
        return;
      }

      syncItems(id);
      section.classList.add('is-service-loading');
      await prepareImage(nextImage);
      if (token !== activationToken) return;

      window.clearTimeout(leaveTimer);
      const previousImage = imageById.get(currentId);
      images.forEach((image) => {
        if (image !== previousImage && image !== nextImage) {
          image.classList.remove('is-active', 'is-leaving', 'is-leaving-out');
        }
      });

      if (previousImage && previousImage !== nextImage) {
        previousImage.classList.remove('is-active');
        previousImage.classList.add('is-leaving');
      }
      nextImage.classList.remove('is-leaving', 'is-leaving-out');
      nextImage.classList.add('is-active');
      currentId = id;
      syncItems(id);
      section.classList.remove('is-service-loading');
      warmNeighbours(id);

      requestAnimationFrame(() => {
        if (token === activationToken && previousImage && previousImage !== nextImage) {
          previousImage.classList.add('is-leaving-out');
        }
      });
      leaveTimer = window.setTimeout(() => {
        previousImage?.classList.remove('is-leaving', 'is-leaving-out');
      }, 680);
    };

    const updateFromScroll = () => {
      scrollFrame = 0;
      const sectionRect = section.getBoundingClientRect();
      if (sectionRect.bottom <= 0 || sectionRect.top >= window.innerHeight) return;

      const readingLine = window.innerHeight * 0.48;
      let closest = items[0];
      let closestDistance = Number.POSITIVE_INFINITY;
      items.forEach((item) => {
        const rect = item.getBoundingClientRect();
        const distance = Math.abs((rect.top + rect.bottom) / 2 - readingLine);
        if (distance < closestDistance) {
          closest = item;
          closestDistance = distance;
        }
      });
      scrollId = closest.dataset.rnServiceItem;
      if (!hoverId) activate(scrollId);
    };

    const scheduleScroll = () => {
      if (!scrollFrame) scrollFrame = requestAnimationFrame(updateFromScroll);
    };

    items.forEach((item) => {
      const run = () => {
        hoverId = item.dataset.rnServiceItem;
        activate(hoverId);
      };
      item.addEventListener('mouseenter', run);
      item.addEventListener('focusin', run);
      item.addEventListener('mouseleave', () => {
        hoverId = null;
        scheduleScroll();
      });
      item.addEventListener('focusout', (event) => {
        if (!item.contains(event.relatedTarget)) {
          hoverId = null;
          scheduleScroll();
        }
      });
    });

    prepareImage(imageById.get(currentId));
    warmNeighbours(currentId);
    updateFromScroll();
    window.addEventListener('scroll', scheduleScroll, { passive: true });
    window.addEventListener('resize', scheduleScroll, { passive: true });
  });
})();
