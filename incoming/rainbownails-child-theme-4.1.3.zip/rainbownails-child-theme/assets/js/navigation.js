(() => {
  'use strict';

  document.querySelectorAll('a[href$="#preferenze-cookie"]').forEach((link) => {
    link.addEventListener('click', (event) => {
      event.preventDefault();
      document.cookie = 'tw_cookie_consent=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/; SameSite=Lax';
      document.cookie = 'tw_cookie_preferences=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/; SameSite=Lax';
      window.location.reload();
    });
  });

  const header = document.querySelector('[data-rn-header]');
  if (!header) return;

  const megaToggle = header.querySelector('[data-rn-mega-toggle]');
  const mega = header.querySelector('[data-rn-megamenu]');
  const mobileToggle = header.querySelector('[data-rn-menu-toggle]');
  const mobilePanel = header.querySelector('[data-rn-mobile-panel]');
  const servicesToggle = header.querySelector('[data-rn-services-toggle]');
  const mobileServices = header.querySelector('#rn-mobile-services');

  const setScrolled = () => header.classList.toggle('is-scrolled', window.scrollY > 18);
  setScrolled();
  window.addEventListener('scroll', setScrolled, { passive: true });

  const closeMega = (restoreFocus = false) => {
    if (!mega || !megaToggle) return;
    mega.hidden = true;
    megaToggle.setAttribute('aria-expanded', 'false');
    header.classList.remove('is-menu-open');
    if (restoreFocus) megaToggle.focus();
  };

  const openMega = () => {
    if (!mega || !megaToggle) return;
    mega.hidden = false;
    megaToggle.setAttribute('aria-expanded', 'true');
    header.classList.add('is-menu-open');
  };

  if (megaToggle && mega) {
    megaToggle.addEventListener('click', () => mega.hidden ? openMega() : closeMega());
    megaToggle.addEventListener('mouseenter', openMega);
    mega.addEventListener('mouseleave', closeMega);
    header.addEventListener('focusout', (event) => {
      if (!header.contains(event.relatedTarget) && !mega.hidden) closeMega();
    });
  }

  const closeMobile = (restoreFocus = false) => {
    if (!mobilePanel || !mobileToggle) return;
    mobilePanel.hidden = true;
    mobileToggle.setAttribute('aria-expanded', 'false');
    document.body.classList.remove('rn-menu-open');
    header.classList.remove('is-menu-open');
    if (restoreFocus) mobileToggle.focus();
  };

  if (mobileToggle && mobilePanel) {
    mobileToggle.addEventListener('click', () => {
      const opens = mobilePanel.hidden;
      mobilePanel.hidden = !opens;
      mobileToggle.setAttribute('aria-expanded', String(opens));
      document.body.classList.toggle('rn-menu-open', opens);
      header.classList.toggle('is-menu-open', opens);
    });
    mobilePanel.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => closeMobile()));
  }

  if (servicesToggle && mobileServices) {
    servicesToggle.addEventListener('click', () => {
      const opens = mobileServices.hidden;
      mobileServices.hidden = !opens;
      servicesToggle.setAttribute('aria-expanded', String(opens));
    });
  }

  document.addEventListener('click', (event) => {
    if (!header.contains(event.target)) closeMega();
  });

  document.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape') return;
    if (mobilePanel && !mobilePanel.hidden) closeMobile(true);
    else if (mega && !mega.hidden) closeMega(true);
  });

  window.addEventListener('resize', () => {
    if (window.innerWidth > 960) closeMobile();
    else closeMega();
  }, { passive: true });

  const previewLinks = header.querySelectorAll('[data-rn-service-preview]');
  const previewTitle = header.querySelector('[data-rn-preview-title]');
  const previewDescription = header.querySelector('[data-rn-preview-description]');
  const previewImage = header.querySelector('[data-rn-preview-image]');
  const previewVisual = previewImage ? previewImage.parentElement : null;

  previewLinks.forEach((link) => {
    const update = () => {
      if (previewTitle) previewTitle.textContent = link.dataset.title || '';
      if (previewDescription) previewDescription.textContent = link.dataset.description || '';
      if (previewImage && link.dataset.image && previewImage.src !== link.dataset.image) {
        if (previewVisual) previewVisual.classList.add('is-changing');
        const probe = new Image();
        probe.onload = () => {
          if (link.dataset.imageSrcset) previewImage.setAttribute('srcset', link.dataset.imageSrcset);
          else previewImage.removeAttribute('srcset');
          if (link.dataset.imageSizes) previewImage.setAttribute('sizes', link.dataset.imageSizes);
          else previewImage.removeAttribute('sizes');
          previewImage.src = link.dataset.image;
          previewImage.alt = link.dataset.imageAlt || link.dataset.title || '';
          if (link.dataset.imageWidth) previewImage.width = Number(link.dataset.imageWidth);
          if (link.dataset.imageHeight) previewImage.height = Number(link.dataset.imageHeight);
          if (previewVisual) requestAnimationFrame(() => previewVisual.classList.remove('is-changing'));
        };
        if (link.dataset.imageSrcset) probe.srcset = link.dataset.imageSrcset;
        if (link.dataset.imageSizes) probe.sizes = link.dataset.imageSizes;
        probe.src = link.dataset.image;
      }
    };
    link.addEventListener('mouseenter', update);
    link.addEventListener('focus', update);
  });
})();
