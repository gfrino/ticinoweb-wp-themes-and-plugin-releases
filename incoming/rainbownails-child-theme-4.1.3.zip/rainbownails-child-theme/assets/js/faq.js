(() => {
  'use strict';

  const faq = document.querySelector('[data-rn-faq]');
  if (!faq) return;

  const items = [...faq.querySelectorAll('[data-rn-faq-item]')];
  const current = faq.querySelector('[data-rn-faq-current]');
  const motionPreference = window.matchMedia('(prefers-reduced-motion: reduce)');
  if (!items.length) return;

  const activate = (item) => {
    const index = items.indexOf(item);
    if (index < 0) return;
    items.forEach((candidate) => candidate.classList.toggle('is-active', candidate === item));
    faq.style.setProperty('--rn-faq-progress', ((index + 1) / items.length).toFixed(4));
    if (current) current.textContent = String(index + 1).padStart(2, '0');
  };

  const start = () => {
    if (motionPreference.matches || !('IntersectionObserver' in window)) {
      faq.classList.add('is-static');
      items.forEach((item) => item.classList.add('is-active'));
      return;
    }

    faq.classList.remove('is-static');
    activate(items[0]);
    const observer = new IntersectionObserver((entries) => {
      const visible = entries
        .filter((entry) => entry.isIntersecting)
        .sort((a, b) => Math.abs(a.boundingClientRect.top + a.boundingClientRect.height / 2 - innerHeight / 2) - Math.abs(b.boundingClientRect.top + b.boundingClientRect.height / 2 - innerHeight / 2));
      if (visible[0]) activate(visible[0].target);
    }, { rootMargin: '-38% 0px -38% 0px', threshold: 0 });
    items.forEach((item) => observer.observe(item));
  };

  start();
})();
