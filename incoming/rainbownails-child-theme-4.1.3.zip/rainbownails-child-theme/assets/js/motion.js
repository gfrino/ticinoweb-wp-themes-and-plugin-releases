(() => {
  'use strict';

  document.documentElement.classList.add('js');
  document.body.classList.remove('no-js');

  const motionPreference = window.matchMedia('(prefers-reduced-motion: reduce)');
  const reduceMotion = motionPreference.matches;
  const elements = document.querySelectorAll('[data-rn-reveal], .rn-media-reveal');
  const introAtmosphere = document.querySelector('[data-rn-intro-atmosphere]');
  const introSection = introAtmosphere?.closest('.rn-intro');
  const momentSection = document.querySelector('.rn-moment');
  if (reduceMotion || !('IntersectionObserver' in window)) {
    elements.forEach((element) => element.classList.add('is-visible'));
    if (!reduceMotion) {
      introSection?.classList.add('is-intro-active');
      momentSection?.classList.add('is-moment-active');
    }
    return;
  }

  const observer = new IntersectionObserver((entries, instance) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      entry.target.classList.add('is-visible');
      instance.unobserve(entry.target);
    });
  }, { threshold: 0.13, rootMargin: '0px 0px -7% 0px' });

  elements.forEach((element) => observer.observe(element));

  if (introSection) {
    let introVisible = false;
    const updateIntroMotion = () => {
      introSection.classList.toggle('is-intro-active', introVisible && !document.hidden);
    };
    const introObserver = new IntersectionObserver(([entry]) => {
      introVisible = entry.isIntersecting;
      updateIntroMotion();
    }, { threshold: 0.08 });
    introObserver.observe(introSection);
    document.addEventListener('visibilitychange', updateIntroMotion);
  }

  if (momentSection) {
    const momentMotionTarget = momentSection.closest('[data-rn-inspiration-stack]') || momentSection;
    let momentVisible = false;
    const updateMomentMotion = () => {
      momentSection.classList.toggle('is-moment-active', momentVisible && !document.hidden);
    };
    const momentObserver = new IntersectionObserver(([entry]) => {
      momentVisible = entry.isIntersecting;
      updateMomentMotion();
    }, { threshold: 0.08 });
    momentObserver.observe(momentMotionTarget);
    document.addEventListener('visibilitychange', updateMomentMotion);
  }

  const scenes = [...document.querySelectorAll('[data-rn-flow-scene]')];
  const flow = document.querySelector('[data-rn-flow]');
  if (!scenes.length || reduceMotion) return;

  let frame = 0;
  const updateFlow = () => {
    frame = 0;
    const viewport = window.innerHeight || 1;
    scenes.forEach((scene) => {
      const rect = scene.getBoundingClientRect();
      const distance = Math.max(1, rect.height + viewport);
      const progress = Math.min(1, Math.max(0, (viewport - rect.top) / distance));
      scene.style.setProperty('--rn-scene-progress', progress.toFixed(4));
    });
    if (flow) {
      const max = Math.max(1, document.documentElement.scrollHeight - viewport);
      flow.style.setProperty('--rn-flow-progress', Math.min(1, window.scrollY / max).toFixed(4));
    }
  };
  const scheduleFlow = () => {
    if (!frame) frame = requestAnimationFrame(updateFlow);
  };

  updateFlow();
  window.addEventListener('scroll', scheduleFlow, { passive: true });
  window.addEventListener('resize', scheduleFlow, { passive: true });
  window.addEventListener('load', scheduleFlow, { once: true });
  motionPreference.addEventListener?.('change', scheduleFlow);
})();
