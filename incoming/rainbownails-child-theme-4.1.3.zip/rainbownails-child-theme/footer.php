<?php
/**
 * Shared site footer.
 *
 * @package RainbowNailsChildTheme
 */
$contacts = rainbownails_get_contact_data();
$services = rainbownails_get_services();
$logo_url = rainbownails_get_logo_url();
$logo_id = rainbownails_get_logo_id();
$address_url = $contacts['address'] ? 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $contacts['address'] ) : '';
?>
<footer class="rn-footer">
	<div class="rn-shell rn-footer__main">
		<div class="rn-footer__brand">
			<a class="rn-footer__brandmark" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
				<?php if ( $logo_url ) : ?><?php echo rainbownails_image( $logo_id, $logo_url, 'medium', array( 'alt' => get_bloginfo( 'name' ), 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '(max-width: 680px) 180px, 260px' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php else : ?><span><?php bloginfo( 'name' ); ?></span><?php endif; ?>
			</a>
			<p><?php echo esc_html( get_bloginfo( 'description' ) ); ?></p>
		</div>
		<nav class="rn-footer__nav" aria-label="<?php esc_attr_e( 'Navigazione nel footer', 'rainbownails-child-theme' ); ?>">
			<p class="rn-footer__title"><?php esc_html_e( 'Esplora', 'rainbownails-child-theme' ); ?></p>
			<?php wp_nav_menu( array( 'menu' => rainbownails_primary_menu_id(), 'container' => false, 'menu_class' => 'rn-footer-menu', 'fallback_cb' => false, 'depth' => 1 ) ); ?>
		</nav>
		<div class="rn-footer__services">
			<p class="rn-footer__title"><?php esc_html_e( 'Trattamenti', 'rainbownails-child-theme' ); ?></p>
			<ul>
				<?php
				$footer_cats = rainbownails_get_categories();
				foreach ( $footer_cats as $cat ) :
					$rep_service = ! empty( $cat['services'][0] ) ? $cat['services'][0] : null;
					if ( $rep_service ) :
						?>
						<li><a href="<?php echo esc_url( $rep_service['url'] ); ?>"><?php echo esc_html( $rep_service['title'] ); ?></a></li>
						<?php
					endif;
				endforeach;
				?>
			</ul>
		</div>
		<div class="rn-footer__contact">
			<p class="rn-footer__title"><?php esc_html_e( 'Contatti', 'rainbownails-child-theme' ); ?></p>
			<?php if ( $contacts['address'] ) : ?><a class="rn-footer__address" href="<?php echo esc_url( $address_url ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $contacts['address'] ); ?> <span aria-hidden="true">↗</span></a><?php endif; ?>
			<?php if ( $contacts['instagram'] ) : ?><a href="<?php echo esc_url( $contacts['instagram'] ); ?>" target="_blank" rel="noopener">Instagram</a><?php endif; ?>
			<?php if ( $contacts['phone'] || $contacts['whatsapp'] ) : ?>
			<div class="rn-footer__contact-actions">
				<?php if ( $contacts['phone'] ) : ?><a class="rn-footer__contact-action" href="tel:<?php echo esc_attr( preg_replace( '/[^+0-9]/', '', $contacts['phone'] ) ); ?>"><?php echo esc_html( $contacts['phone_display'] ); ?></a><?php endif; ?>
				<?php if ( $contacts['whatsapp'] ) : ?><a class="rn-footer__contact-action rn-footer__contact-action--primary" href="<?php echo esc_url( $contacts['whatsapp'] ); ?>" target="_blank" rel="noopener">WhatsApp <span aria-hidden="true">↗</span></a><?php endif; ?>
			</div>
			<?php endif; ?>
		</div>
	</div>
	<div class="rn-shell rn-footer__bottom">
		<p>© <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?>.</p>
		<div class="rn-footer__bottom-links">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'footer_utility',
					'container'      => 'nav',
					'container_class'=> 'rn-footer__utility',
					'container_aria_label' => __( 'Navigazione utility nel footer', 'rainbownails-child-theme' ),
					'menu_class'     => 'rn-footer-utility-menu',
					'fallback_cb'    => false,
					'depth'          => 1,
				)
			);
			?>
			<a href="https://ticinoweb.com" target="_blank" rel="noopener">Design by ticinoWEB</a>
		</div>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
