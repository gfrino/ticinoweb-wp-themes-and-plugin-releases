<?php
/**
 * Il CMS «a prova di chiunque» per il Patriziato (chi non è amministratore).
 *
 * Pubblicare = scrivere un titolo, scegliere il file dal computer, premere «Pubblica».
 * Niente schermate di WordPress, niente scelte tecniche: tipo dell'atto e assemblea li capisce il sistema
 * (pi_classifica_atto), la prima pagina e gli archivi si aggiornano da soli.
 * Gli amministratori (ticinoWEB) continuano a usare le schermate complete.
 */
if (!defined('ABSPATH')) {
	exit;
}

function pi_url_admin($pagina, $args = []) {
	return add_query_arg(array_merge(['page' => $pagina], $args), admin_url('admin.php'));
}

add_action('admin_menu', function () {
	if (!pi_e_cliente()) {
		return;
	}
	add_menu_page('Pubblicazioni', 'Pubblicazioni', 'edit_posts', 'pi-pubblicazioni', 'pi_pagina_pubblicazioni', 'dashicons-megaphone', 2);
	add_submenu_page('pi-pubblicazioni', 'Tutte le pubblicazioni', 'Tutte le pubblicazioni', 'edit_posts', 'pi-pubblicazioni', 'pi_pagina_pubblicazioni');
	add_submenu_page('pi-pubblicazioni', 'Nuova pubblicazione', 'Nuova pubblicazione', 'edit_posts', 'pi-pubblica', 'pi_pagina_pubblica');
	add_menu_page('Documenti', 'Documenti', 'edit_posts', 'pi-documenti', 'pi_pagina_documenti', 'dashicons-media-document', 3);
}, 6);

// Le schermate di WordPress per atti e documenti portano a quelle semplici.
add_action('admin_init', function () {
	if (!pi_e_cliente() || wp_doing_ajax()) {
		return;
	}
	global $pagenow;
	$tipo = $_GET['post_type'] ?? '';
	if ($pagenow === 'post.php' && isset($_GET['post'])) {
		$tipo = get_post_type((int) $_GET['post']);
	}
	if (in_array($pagenow, ['edit.php', 'post-new.php', 'post.php'], true)) {
		if ($tipo === 'pi_documento') {
			wp_safe_redirect(pi_url_admin('pi-documenti'));
			exit;
		}
		if ($tipo === '' || $tipo === 'post') {
			$dest = ($pagenow === 'post.php' && isset($_GET['post'])) ? pi_url_admin('pi-pubblica', ['id' => (int) $_GET['post']]) : ($pagenow === 'post-new.php' ? pi_url_admin('pi-pubblica') : pi_url_admin('pi-pubblicazioni'));
			wp_safe_redirect($dest);
			exit;
		}
	}
});

// «Modifica» (anche dalla barra in alto sul sito) apre il modulo semplice.
add_filter('get_edit_post_link', function ($link, $id) {
	if (!pi_e_cliente()) {
		return $link;
	}
	$t = get_post_type($id);
	if ($t === 'post') {
		return pi_url_admin('pi-pubblica', ['id' => $id]);
	}
	if ($t === 'pi_documento') {
		return pi_url_admin('pi-documenti') . '#doc-' . $id;
	}
	return $link;
}, 10, 2);

add_action('admin_bar_menu', function ($bar) {
	if (pi_e_cliente()) {
		$bar->remove_node('new-content');
		$bar->remove_node('comments');
		$bar->add_node(['id' => 'pi-nuova', 'title' => '+ Nuova pubblicazione', 'href' => pi_url_admin('pi-pubblica')]);
	}
}, 999);

/** Avviso in cima alle pagine semplici. */
function pi_messaggio() {
	$m = sanitize_key($_GET['fatto'] ?? '');
	$testi = [
		'pubblicato'  => 'Pubblicato. È già sul sito, nella sezione giusta.',
		'salvato'     => 'Modifiche salvate. Il sito è già aggiornato.',
		'eliminato'   => 'Pubblicazione tolta dal sito. Se è stato un errore, ticinoWEB la può recuperare.',
		'caricato'    => 'Versione nuova caricata. Quella vecchia è conservata nello storico.',
		'aggiunto'    => 'Documento aggiunto al sito.',
		'manca-file'  => 'Non è stato scelto nessun file. Premi «Scegli il file» e riprova.',
		'errore-file' => 'Il file non è stato caricato. Controlla che sia un PDF, un documento Word o una foto, e riprova.',
		'manca-tutto' => 'Scrivi un titolo o scegli almeno un file.',
	];
	if (isset($testi[$m])) {
		$errore = in_array($m, ['manca-file', 'errore-file', 'manca-tutto'], true);
		$link = '';
		if (!$errore && !empty($_GET['vedi'])) {
			$link = ' <a href="' . esc_url(get_permalink((int) $_GET['vedi'])) . '" target="_blank" rel="noopener">Guardalo sul sito ↗</a>';
		}
		printf('<div class="notice %s pi-avviso-grande"><p>%s%s</p></div>', $errore ? 'notice-error' : 'notice-success', esc_html($testi[$m]), $link);
	}
}

/** Carica i file scelti (campo name="$campo[]"); restituisce gli ID degli allegati. */
function pi_carica_file($campo, $post_id = 0) {
	if (empty($_FILES[$campo]['name']) || !is_array($_FILES[$campo]['name'])) {
		return [];
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	add_filter('fallback_intermediate_image_sizes', '__return_empty_array'); // niente miniature dei PDF: lente
	$ids = [];
	$f = $_FILES[$campo];
	foreach ($f['name'] as $i => $nome) {
		if ($nome === '' || (int) $f['error'][$i] === UPLOAD_ERR_NO_FILE) {
			continue;
		}
		$_FILES['pi_un_file'] = ['name' => $f['name'][$i], 'type' => $f['type'][$i], 'tmp_name' => $f['tmp_name'][$i], 'error' => $f['error'][$i], 'size' => $f['size'][$i]];
		$titolo = pi_nome_file_leggibile(pathinfo($nome, PATHINFO_FILENAME));
		$id = media_handle_upload('pi_un_file', $post_id, ['post_title' => $titolo], ['test_form' => false, 'mimes' => [
			'pdf' => 'application/pdf', 'doc' => 'application/msword', 'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
			'xls' => 'application/vnd.ms-excel', 'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
			'jpg|jpeg' => 'image/jpeg', 'png' => 'image/png',
		]]);
		if (!is_wp_error($id)) {
			$ids[] = (int) $id;
		}
	}
	unset($_FILES['pi_un_file']);
	return $ids;
}

/* ---------------------------------------------------------------- Pubblicazioni: elenco */
function pi_pagina_pubblicazioni() {
	$cerca = sanitize_text_field(wp_unslash($_GET['cerca'] ?? ''));
	$pag = max(1, absint($_GET['pg'] ?? 1));
	$q = new WP_Query(['post_type' => 'post', 'post_status' => ['publish', 'future', 'draft'], 'posts_per_page' => 25, 'paged' => $pag, 's' => $cerca]);
	?>
	<div class="wrap pi-semplice">
		<h1>Pubblicazioni</h1>
		<?php pi_messaggio(); ?>
		<p><a class="button button-primary button-hero" href="<?php echo esc_url(pi_url_admin('pi-pubblica')); ?>">+ Nuova pubblicazione</a></p>
		<form method="get" class="pi-cerca-admin">
			<input type="hidden" name="page" value="pi-pubblicazioni">
			<label for="pi-cerca">Cerca una pubblicazione</label>
			<input id="pi-cerca" type="search" name="cerca" value="<?php echo esc_attr($cerca); ?>" placeholder="Per esempio: verbale 2025">
			<button class="button button-large">Cerca</button>
		</form>
		<?php if ($q->have_posts()) : ?>
			<ul class="pi-elenco">
				<?php foreach ($q->posts as $p) :
					$n = count(pi_allegati($p->ID)); ?>
					<li>
						<span class="pi-elenco__data"><?php echo esc_html(get_the_date('d.m.Y', $p)); ?></span>
						<span class="pi-elenco__titolo"><?php echo esc_html(pi_titolo_pulito(get_the_title($p))); ?>
							<small><?php echo esc_html(pi_tipo_etichetta(pi_tipo_di($p->ID))); ?> · <?php echo $n ? esc_html(sprintf(_n('%d documento', '%d documenti', $n), $n)) : 'nessun documento'; ?><?php echo $p->post_status !== 'publish' ? ' · <strong>non ancora sul sito</strong>' : ''; ?></small>
						</span>
						<span class="pi-elenco__azioni">
							<a class="button" href="<?php echo esc_url(pi_url_admin('pi-pubblica', ['id' => $p->ID])); ?>">Modifica</a>
							<a class="button-link" href="<?php echo esc_url(get_permalink($p)); ?>" target="_blank" rel="noopener">Vedi</a>
						</span>
					</li>
				<?php endforeach; ?>
			</ul>
			<?php
			echo '<p class="pi-pagine">';
			for ($i = 1; $i <= $q->max_num_pages; $i++) {
				printf($i === $pag ? '<strong>%d</strong> ' : '<a href="%2$s">%1$d</a> ', $i, esc_url(pi_url_admin('pi-pubblicazioni', ['pg' => $i, 'cerca' => $cerca])));
			}
			echo '</p>';
			?>
		<?php else : ?>
			<p class="pi-vuoto">Nessuna pubblicazione trovata.</p>
		<?php endif; ?>
	</div>
	<?php
}

/* ---------------------------------------------------------------- Pubblicazioni: nuova / modifica */
function pi_pagina_pubblica() {
	$id = absint($_GET['id'] ?? 0);
	$p = $id ? get_post($id) : null;
	if ($id && (!$p || $p->post_type !== 'post' || !current_user_can('edit_post', $id))) {
		echo '<div class="wrap"><p>Pubblicazione non trovata.</p></div>';
		return;
	}
	$fino = $p ? get_post_meta($id, '_pi_evidenza_fino', true) : '';
	$testo = $p ? trim(wp_strip_all_tags(str_replace(['</p>', '<br>', '<br />'], "\n", $p->post_content))) : '';
	?>
	<div class="wrap pi-semplice">
		<h1><?php echo $p ? 'Modifica la pubblicazione' : 'Nuova pubblicazione'; ?></h1>
		<?php pi_messaggio(); ?>
		<form class="pi-modulo-semplice" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" enctype="multipart/form-data">
			<input type="hidden" name="action" value="pi_salva_pubblicazione">
			<input type="hidden" name="id" value="<?php echo (int) $id; ?>">
			<?php wp_nonce_field('pi_pubblicazione'); ?>

			<label class="pi-campo-grande">
				<span>Titolo</span>
				<input type="text" name="titolo" value="<?php echo esc_attr($p ? $p->post_title : ''); ?>" placeholder="Per esempio: Convocazione assemblea patriziale del 17.12.2026" autofocus>
			</label>

			<div class="pi-campo-grande">
				<span>Documento</span>
				<?php if ($p && pi_allegati($id)) : ?>
					<ul class="pi-file-attuali">
						<?php foreach (pi_allegati($id) as $a) :
							$f = pi_file_info($a);
							if (!$f) {
								continue;
							} ?>
							<li><a href="<?php echo esc_url($f['url']); ?>" target="_blank" rel="noopener"><?php echo esc_html($f['titolo']); ?></a> <small><?php echo esc_html($f['formato']); ?></small>
								<label class="pi-togli-file"><input type="checkbox" name="togli[]" value="<?php echo (int) $a; ?>"> togli</label></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
				<label class="pi-scegli-file">
					<input type="file" name="pi_file[]" multiple accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png" data-pi-file>
					<span class="button button-hero">Scegli il file dal computer</span>
					<span class="pi-file-scelti" data-pi-file-nomi><?php echo $p ? 'Puoi aggiungere altri file.' : 'PDF, Word o foto. Puoi sceglierne anche più di uno.'; ?></span>
				</label>
			</div>

			<label class="pi-campo-grande">
				<span>Testo <small>(facoltativo)</small></span>
				<textarea name="testo" rows="5" placeholder="Di solito non serve: basta il documento."><?php echo esc_textarea($testo); ?></textarea>
			</label>

			<div class="pi-campo-grande pi-evidenza">
				<label class="pi-spunta"><input type="checkbox" name="evidenza" value="1" data-pi-evidenza <?php checked((bool) $fino); ?>> È un avviso importante: mostralo in prima pagina</label>
				<label class="pi-fino" data-pi-fino <?php echo $fino ? '' : 'hidden'; ?>>fino al <input type="date" name="fino" value="<?php echo esc_attr($fino); ?>"></label>
			</div>

			<p class="pi-azioni-modulo">
				<button type="submit" class="button button-primary button-hero"><?php echo $p ? 'Salva le modifiche' : 'Pubblica'; ?></button>
				<a href="<?php echo esc_url(pi_url_admin('pi-pubblicazioni')); ?>">Annulla</a>
			</p>
		</form>
		<?php if ($p) : ?>
			<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="pi-elimina" data-pi-conferma="Togliere questa pubblicazione dal sito?">
				<input type="hidden" name="action" value="pi_elimina_pubblicazione">
				<input type="hidden" name="id" value="<?php echo (int) $id; ?>">
				<?php wp_nonce_field('pi_elimina_' . $id); ?>
				<button type="submit" class="button-link pi-togli">Togli questa pubblicazione dal sito</button>
			</form>
		<?php endif; ?>
	</div>
	<?php
}

add_action('admin_post_pi_salva_pubblicazione', function () {
	check_admin_referer('pi_pubblicazione');
	$id = absint($_POST['id'] ?? 0);
	if (!($id ? current_user_can('edit_post', $id) : current_user_can('publish_posts')) || ($id && get_post_type($id) !== 'post')) {
		wp_die('Non hai i permessi per questa operazione.');
	}
	$titolo = sanitize_text_field(wp_unslash($_POST['titolo'] ?? ''));
	$testo = sanitize_textarea_field(wp_unslash($_POST['testo'] ?? ''));
	$nuovi = pi_carica_file('pi_file', $id);
	if (!$id && $titolo === '' && !$nuovi) {
		$ha_file = !empty($_FILES['pi_file']['name'][0]);
		wp_safe_redirect(pi_url_admin('pi-pubblica', ['fatto' => $ha_file ? 'errore-file' : 'manca-tutto']));
		exit;
	}
	if ($titolo === '' && $nuovi) {
		$titolo = get_the_title($nuovi[0]);
	}
	$dati = ['post_type' => 'post', 'post_title' => $titolo, 'post_content' => $testo !== '' ? wpautop(esc_html($testo)) : ''];
	if ($id) {
		$dati['ID'] = $id;
		wp_update_post($dati);
	} else {
		$dati['post_status'] = 'publish';
		$id = wp_insert_post($dati);
	}
	$togli = array_map('absint', (array) ($_POST['togli'] ?? []));
	$all = array_values(array_diff(pi_allegati($id), $togli));
	$all = array_values(array_unique(array_merge($all, $nuovi)));
	update_post_meta($id, '_pi_allegati', $all);
	foreach ($nuovi as $a) {
		wp_update_post(['ID' => $a, 'post_parent' => $id]);
	}
	$fino = sanitize_text_field($_POST['fino'] ?? '');
	if (!empty($_POST['evidenza'])) {
		if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $fino)) {
			$fino = wp_date('Y-m-d', strtotime('+14 days')); // senza data: due settimane
		}
		update_post_meta($id, '_pi_evidenza_fino', $fino);
	} else {
		delete_post_meta($id, '_pi_evidenza_fino');
	}
	wp_set_object_terms($id, [], 'category');
	pi_classifica_atto($id);
	do_action('litespeed_purge_all');
	wp_safe_redirect(pi_url_admin('pi-pubblicazioni', ['fatto' => isset($dati['ID']) ? 'salvato' : 'pubblicato', 'vedi' => $id]));
	exit;
});

add_action('admin_post_pi_elimina_pubblicazione', function () {
	$id = absint($_POST['id'] ?? 0);
	check_admin_referer('pi_elimina_' . $id);
	if (!$id || get_post_type($id) !== 'post' || !current_user_can('delete_post', $id)) {
		wp_die('Non hai i permessi per questa operazione.');
	}
	wp_trash_post($id);
	do_action('litespeed_purge_all');
	wp_safe_redirect(pi_url_admin('pi-pubblicazioni', ['fatto' => 'eliminato']));
	exit;
});

/* ---------------------------------------------------------------- Documenti */
function pi_pagina_documenti() {
	?>
	<div class="wrap pi-semplice">
		<h1>Documenti</h1>
		<?php pi_messaggio(); ?>
		<p class="pi-aiuto">Per aggiornare un documento basta caricare il file nuovo: il sito mostra subito quello nuovo e conserva il vecchio nello storico.</p>
		<?php foreach (pi_raccolte() as $slug => $r) : ?>
			<h2><?php echo esc_html($r[0]); ?></h2>
			<?php foreach (pi_documenti($slug) as $d) :
				$f = pi_documento_file($d->ID) ? pi_file_info(pi_documento_file($d->ID)) : null;
				$dal = get_post_meta($d->ID, '_pi_valido_dal', true); ?>
				<form class="pi-doc" id="doc-<?php echo (int) $d->ID; ?>" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" enctype="multipart/form-data">
					<input type="hidden" name="action" value="pi_carica_versione">
					<input type="hidden" name="id" value="<?php echo (int) $d->ID; ?>">
					<?php wp_nonce_field('pi_versione_' . $d->ID); ?>
					<h3><?php echo esc_html(get_the_title($d)); ?></h3>
					<p class="pi-doc__ora"><?php if ($f) : ?>Sul sito adesso: <a href="<?php echo esc_url($f['url']); ?>" target="_blank" rel="noopener"><?php echo esc_html($f['titolo']); ?></a><?php echo $dal ? ' · valido dal ' . esc_html(pi_data_breve($dal)) : ''; ?><?php else : ?>Nessun file ancora.<?php endif; ?></p>
					<div class="pi-doc__nuovo">
						<label class="pi-scegli-file">
							<input type="file" name="pi_file[]" accept=".pdf,.doc,.docx" data-pi-file>
							<span class="button button-large">Scegli il file nuovo</span>
							<span class="pi-file-scelti" data-pi-file-nomi></span>
						</label>
						<label>valido dal <input type="date" name="dal" value="<?php echo esc_attr(current_time('Y-m-d')); ?>"></label>
						<button type="submit" class="button button-primary button-large">Carica la versione nuova</button>
					</div>
				</form>
			<?php endforeach; ?>
		<?php endforeach; ?>

		<h2>Aggiungi un documento nuovo</h2>
		<form class="pi-doc pi-doc--nuovo" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" enctype="multipart/form-data">
			<input type="hidden" name="action" value="pi_nuovo_documento">
			<?php wp_nonce_field('pi_nuovo_documento'); ?>
			<label class="pi-campo-grande"><span>Nome del documento</span><input type="text" name="titolo" required placeholder="Per esempio: Regolamento per l'uso dei pascoli"></label>
			<label class="pi-scegli-file">
				<input type="file" name="pi_file[]" accept=".pdf,.doc,.docx" data-pi-file required>
				<span class="button button-large">Scegli il file dal computer</span>
				<span class="pi-file-scelti" data-pi-file-nomi></span>
			</label>
			<p><button type="submit" class="button button-primary button-large">Aggiungi al sito</button></p>
		</form>
	</div>
	<?php
}

add_action('admin_post_pi_carica_versione', function () {
	$id = absint($_POST['id'] ?? 0);
	check_admin_referer('pi_versione_' . $id);
	if (!$id || get_post_type($id) !== 'pi_documento' || !current_user_can('edit_post', $id)) {
		wp_die('Non hai i permessi per questa operazione.');
	}
	$nuovi = pi_carica_file('pi_file', $id);
	if (!$nuovi) {
		wp_safe_redirect(pi_url_admin('pi-documenti', ['fatto' => empty($_FILES['pi_file']['name'][0]) ? 'manca-file' : 'errore-file']) . '#doc-' . $id);
		exit;
	}
	$dal = sanitize_text_field($_POST['dal'] ?? '');
	$dal = preg_match('/^\d{4}-\d{2}-\d{2}$/', $dal) ? $dal : current_time('Y-m-d');
	$vecchio = pi_documento_file($id);
	if ($vecchio) {
		$v = pi_documento_versioni($id);
		array_unshift($v, ['file' => $vecchio, 'data' => get_post_meta($id, '_pi_valido_dal', true) ?: get_the_date('Y-m-d', $vecchio)]);
		update_post_meta($id, '_pi_versioni', $v);
	}
	update_post_meta($id, '_pi_file', $nuovi[0]);
	update_post_meta($id, '_pi_valido_dal', $dal);
	do_action('litespeed_purge_all');
	wp_safe_redirect(pi_url_admin('pi-documenti', ['fatto' => 'caricato', 'vedi' => $id]) . '#doc-' . $id);
	exit;
});

add_action('admin_post_pi_nuovo_documento', function () {
	check_admin_referer('pi_nuovo_documento');
	if (!current_user_can('publish_posts')) {
		wp_die('Non hai i permessi per questa operazione.');
	}
	$titolo = sanitize_text_field(wp_unslash($_POST['titolo'] ?? ''));
	$nuovi = pi_carica_file('pi_file');
	if ($titolo === '' || !$nuovi) {
		wp_safe_redirect(pi_url_admin('pi-documenti', ['fatto' => $nuovi ? 'manca-tutto' : 'manca-file']));
		exit;
	}
	$id = wp_insert_post(['post_type' => 'pi_documento', 'post_status' => 'publish', 'post_title' => $titolo, 'menu_order' => 50]);
	update_post_meta($id, '_pi_raccolta', 'regolamenti'); // i registri dei patrizi esistono già: un documento nuovo è un regolamento
	update_post_meta($id, '_pi_file', $nuovi[0]);
	update_post_meta($id, '_pi_valido_dal', current_time('Y-m-d'));
	wp_update_post(['ID' => $nuovi[0], 'post_parent' => $id]);
	do_action('litespeed_purge_all');
	wp_safe_redirect(pi_url_admin('pi-documenti', ['fatto' => 'aggiunto', 'vedi' => $id]));
	exit;
});
