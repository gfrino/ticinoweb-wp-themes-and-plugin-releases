<?php
/**
 * PAGINA INTERNA, NUOVO SISTEMA — le pagine di documenti (Jobs, Certificazioni,
 * Condizioni di vendita): testata del sistema, poi i documenti in un elenco a
 * righe con il filetto, ogni PDF come un collegamento ben visibile.
 *
 * Il contenuto e' quello di prima (tenconi_legacy_documenti) e i PDF si
 * trovano come prima, per nome del file nella libreria media.
 *
 * Variabili attese: $tl_slug.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$tl_slug = isset( $tl_slug ) ? (string) $tl_slug : '';
$tl_map  = tenconi_legacy_documenti();
if ( ! isset( $tl_map[ $tl_slug ] ) ) {
	return;
}
$tl_p = $tl_map[ $tl_slug ];

if ( ! function_exists( 'tenconi_int_pdf_url' ) ) {
	/**
	 * L'indirizzo di un PDF della libreria media, cercato per nome del file.
	 *
	 * @param string $file Nome del file.
	 * @return string
	 */
	function tenconi_int_pdf_url( $file ) {
		static $cache = array();
		$file = (string) $file;
		if ( '' === $file ) {
			return '';
		}
		if ( ! isset( $cache[ $file ] ) ) {
			$id             = function_exists( 'tenconi_media_da_nome' ) ? tenconi_media_da_nome( preg_replace( '/\.pdf$/i', '', $file ), 'application' ) : 0;
			$cache[ $file ] = $id ? (string) wp_get_attachment_url( (int) $id ) : '';
		}
		return $cache[ $file ];
	}
}

$tl_voce   = tenconi_int_voce( $tl_slug );
$tl_titolo = '' !== $tl_voce['titolo'] ? $tl_voce['titolo'] : $tl_p['titolo'];
$tl_post   = is_page() ? get_queried_object() : null;
$tl_url    = $tl_post ? get_permalink( $tl_post ) : (string) get_post_type_archive_link( (string) get_query_var( 'post_type' ) );
$tl_intro  = ( $tl_post && has_excerpt( $tl_post ) ) ? get_the_excerpt( $tl_post ) : '';
?>
<main id="main" class="tl-main tl-int" tabindex="-1">
	<?php
	tenconi_int_testa(
		array(
			'gruppo' => $tl_voce['gruppo'],
			'titolo' => $tl_titolo,
			'intro'  => $tl_intro,
			'hero'   => tenconi_mega_immagine( $tl_slug, $tl_url )['img'],
		)
	);
	?>
	<section class="tl-int__sez">
		<div class="tl-wrap tl-int__testo">
			<div class="tl-int__doc">
				<?php
				foreach ( $tl_p['voci'] as $tl_v ) :
					list( $tl_tag, $tl_testo, $tl_link ) = array_pad( (array) $tl_v, 3, array() );

					if ( 'h2' === $tl_tag || 'h3' === $tl_tag ) {
						printf( '<h2 class="tl-int__doc-t" id="%s">%s</h2>', esc_attr( sanitize_title( $tl_testo ) ), esc_html( $tl_testo ) );
						continue;
					}
					if ( empty( $tl_link ) ) {
						printf( '<p class="tl-int__doc-p">%s</p>', esc_html( $tl_testo ) );
						continue;
					}
					?>
					<?php
					/*
					 * UNA RIGA PER DOCUMENTO, UN PULSANTE PER LINGUA. Nei dati le
					 * versioni hanno tutte la stessa etichetta ("ISO 3834-2" due
					 * volte): la lingua sta solo nel testo della riga, fra
					 * parentesi e nello stesso ordine dei file. Se i conti tornano
					 * diventa il nome del pulsante, altrimenti resta l'etichetta.
					 */
					preg_match_all( '/\(([^()]+)\)/u', (string) $tl_testo, $tl_lingue );
					$tl_lingue = ( count( $tl_lingue[1] ) === count( $tl_link ) ) ? $tl_lingue[1] : array();
					?>
					<div class="tl-int__doc-r">
						<p class="tl-int__doc-n"><?php echo esc_html( $tl_link[0][0] ); ?></p>
						<p class="tl-int__doc-l">
							<?php
							foreach ( $tl_link as $tl_k => $tl_l ) :
								list( $tl_et, $tl_file ) = $tl_l;
								if ( isset( $tl_lingue[ $tl_k ] ) ) {
									$tl_et = $tl_lingue[ $tl_k ];
								} elseif ( 1 === count( $tl_link ) ) {
									$tl_et = tenconi_int_t( 'Scarica il PDF', 'tenconi:interne:scarica-pdf' );
								}
								$tl_u = tenconi_int_pdf_url( $tl_file );
								if ( '' !== $tl_u ) :
									?>
									<a class="tl-int__pdf" href="<?php echo esc_url( $tl_u ); ?>" rel="noopener" aria-label="<?php echo esc_attr( $tl_link[0][0] . ' — ' . $tl_et . ' (PDF)' ); ?>">
										<span class="tl-int__pdf-ico" aria-hidden="true">PDF</span>
										<span><?php echo esc_html( $tl_et ); ?></span>
									</a>
								<?php else : ?>
									<span class="tl-int__pdf tl-int__pdf--manca"><?php echo esc_html( $tl_et ); ?></span>
									<?php
								endif;
							endforeach;
							?>
						</p>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</section>
	<?php
	/* Su Jobs l'invito "Parliamo del vostro progetto" parlerebbe al cliente sbagliato. */
	if ( 'jobs' !== $tl_slug ) {
		tenconi_int_cta();
	}
	?>
</main>
