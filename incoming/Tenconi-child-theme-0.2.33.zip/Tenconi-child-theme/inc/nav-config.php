<?php
/**
 * Architettura di navigazione approvata, e cancello di pubblicazione.
 *
 * DUE LIVELLI, DELIBERATAMENTE SEPARATI.
 *
 * 1. LA CONFIGURAZIONE DICHIARATA - tenconi_nav_blueprint(). E' l'architettura
 *    approvata dal committente il 4 agosto 2026: cinque voci principali piu
 *    Contatti come elemento utility. Contiene TUTTE le voci previste, comprese
 *    quelle che oggi non si possono pubblicare. Resta leggibile qui perche' il
 *    piano non deve vivere in un documento esterno: quando un contenuto viene
 *    completato la voce si accende da sola.
 *
 * 2. IL CANCELLO - tenconi_dest_state(). Decide se una destinazione e'
 *    pubblicabile OGGI, interrogando il database. Il frontend pubblico mostra
 *    soltanto cio' che passa. Non esistono href="#", non esistono pagine hub
 *    inventate, non esistono link verso pagine vuote, placeholder, testi non
 *    redatti, documenti da riautorizzare o archivi senza contenuti.
 *
 * PERCHE' IL CANCELLO E' CALCOLATO E NON UNA LISTA. Una lista di voci disabilitate
 * scritta a mano mente il giorno dopo, quando il contenuto arriva o peggiora.
 * Interrogare la destinazione costa poche query, si memorizza per richiesta, e
 * non richiede di ricordarsi di aggiornare niente.
 *
 * REGOLA CHE NON VA AGGIRATA: per accendere una voce si completa il contenuto.
 * Non si scrive un testo di comodo nel tema.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pattern dei segnaposto che rendono una pagina non pubblicabile.
 *
 * Sono le marche prodotte dalla redazione automatica della Content Foundation
 * piu' le stringhe che il committente ha vietato esplicitamente.
 */
const TENCONI_PH_RE = '/\[dato da confermare\]|\[anno da confermare\]|non ancora redatto|scheda da redigere|scheda parziale|lorem ipsum/i';

/**
 * Soglia minima di testo perche' una pagina non sia considerata uno stub.
 *
 * Le schede di lavorazione importate da CF-2 hanno 10 caratteri: sono titoli
 * senza corpo. 120 caratteri e' circa una frase e mezzo: sotto quella soglia
 * non c'e' una pagina, c'e' un segnaposto strutturale.
 */
const TENCONI_MIN_TESTO = 120;

/**
 * L'architettura approvata, per intero.
 *
 * Ogni voce dichiara:
 *   key      identificatore stabile, usato nel report e nei test
 *   label    etichetta approvata. Sono le etichette LEGACY: dove divergono dal
 *            titolo pubblicato in WordPress la divergenza e' nota e va risolta
 *            editorialmente, non silenziosamente qui.
 *   dest     array( tipo, riferimento ) della destinazione
 *   children voci di secondo livello
 *   nota     perche' una voce potrebbe non passare il cancello
 *
 * Tipi di destinazione ammessi:
 *   page          pagina, per slug
 *   cpt_archive   archivio di un custom post type
 *   cpt_single    singolo record di un custom post type, per slug
 *   term_archive  archivio di un termine di tassonomia
 *   none          nessuna destinazione esiste: la voce non potra' mai accendersi
 *                 finche' non le viene data
 *
 * @return array<int,array<string,mixed>>
 */
/**
 * Le etichette del blueprint, passate a ticinoweb_frontend_text() UNA SOLA
 * VOLTA qui — non in ogni punto dove una voce viene stampata (mega menu
 * desktop, menu mobile, footer se mai la useranno). Un solo punto vuol dire
 * una sola chiave di contesto per etichetta, quindi una sola riga in coda di
 * traduzione: se lo si facesse al momento della stampa, la stessa etichetta
 * comparirebbe due volte nella coda — una per il desktop, una per il mobile
 * — e verrebbe tradotta due volte, sprecando quota Google per lo stesso testo.
 *
 * LA CHIAVE DI CONTESTO usa la 'key' gia' presente in ogni voce, che e' gia'
 * stabile e univoca per costruzione (serve anche al report e ai test): non se
 * ne inventa una seconda.
 *
 * function_exists() e non un require: se il parent cambiasse e la funzione di
 * compatibilita' sparisse, il menu deve continuare a mostrare l'italiano
 * invece di un fatal error.
 *
 * @param array<int,array<string,mixed>> $voci Voci del blueprint, primo livello.
 * @return array<int,array<string,mixed>>
 */
function tenconi_nav_traduci_blueprint( $voci ) {
	if ( ! function_exists( 'ticinoweb_frontend_text' ) ) {
		return $voci;
	}
	foreach ( $voci as &$voce ) {
		$voce['label'] = ticinoweb_frontend_text( $voce['label'], 'tenconi:nav:' . $voce['key'] );
		if ( ! empty( $voce['children'] ) ) {
			foreach ( $voce['children'] as &$figlio ) {
				$figlio['label'] = ticinoweb_frontend_text( $figlio['label'], 'tenconi:nav:' . $figlio['key'] );
			}
			unset( $figlio );
		}
	}
	unset( $voce );
	return $voci;
}

function tenconi_nav_blueprint() {

	/*
	 * STRUTTURA DEL MENU DECISA DAL CLIENTE IL 27.10.2026:
	 * Azienda · Prodotti e servizi · Tecnologia e progetti · Jobs ·
	 * Qualita' / Ambiente e sicurezza.
	 *
	 * Le voci sono ETICHETTE che portano a pagine esistenti o a sezioni di
	 * pagine ('ancora'): nessuna pagina nuova. Le chiavi restano quelle di prima
	 * dove la destinazione non cambia, cosi' immagini e icone del mega menu
	 * restano al loro posto. I gruppi non hanno una pagina propria ('none'):
	 * altrimenti il pannello aggiungerebbe una scheda col nome del gruppo.
	 *
	 * Fuori dal menu ma ancora online: Energia (andra' sul sito di Tenconi
	 * Idromeccanica SA) e Tecnologia e servizi di supporto.
	 */
	return tenconi_nav_traduci_blueprint( array(

		array(
			'key'      => 'azienda',
			'label'    => 'Azienda',
			'dest'     => array( 'none', '' ),
			'children' => array(
				array(
					'key'   => 'storia',
					'label' => 'La nostra storia',
					'dest'  => array( 'page', 'storia' ),
				),
				array(
					// la presentazione dell'azienda (era "Chi siamo")
					'key'   => 'chi-siamo',
					'label' => 'Missione',
					'dest'  => array( 'page', 'chi-siamo' ),
					'nota'  => 'La pagina contiene ancora la marca [dato da confermare] sul numero di collaboratori.',
				),
				array(
					'key'   => 'direzione',
					'label' => 'Direzione e CdA',
					'dest'  => array( 'page', 'direzione' ),
				),
				array(
					'key'   => 'team',
					'label' => 'Team',
					'dest'  => array( 'page', 'team' ),
				),
				array(
					'key'   => 'centocinquantesimo',
					'label' => '150esimo',
					'dest'  => array( 'page', '150esimo' ),
				),
			),
		),

		array(
			'key'      => 'aree-di-attivita',
			'label'    => 'Prodotti e servizi',
			'dest'     => array( 'none', '' ),
			'children' => array(
				array(
					'key'   => 'ferroviario-infrastruttura',
					'label' => 'Ferroviario - Infrastruttura',
					'dest'  => array( 'term_archive', 'market:ferroviario-infrastruttura' ),
				),
				array(
					'key'   => 'ferroviario-rotabile',
					'label' => 'Ferroviario - Rotabile',
					'dest'  => array( 'term_archive', 'market:ferroviario-rotabile' ),
				),
				array(
					'key'   => 'carpenteria-metallica',
					'label' => 'Carpenteria metallica',
					'dest'  => array( 'cpt_single', 'capability:carpenteria-metallica' ),
				),
				array(
					'key'   => 'metalmeccanica',
					'label' => 'Lavorazioni meccaniche',
					'dest'  => array( 'cpt_single', 'capability:lavorazioni-meccaniche' ),
				),
			),
		),

		array(
			'key'      => 'tecnologia-e-progetti',
			'label'    => 'Tecnologia e progetti',
			'dest'     => array( 'none', '' ),
			'children' => array(
				array(
					'key'   => 'parco-macchine',
					'label' => 'Parco macchine',
					'dest'  => array( 'cpt_archive', 'machine' ),
				),
				array(
					'key'   => 'referenze',
					'label' => 'Referenze',
					'dest'  => array( 'cpt_archive', 'project' ),
				),
				array(
					'key'   => 'gestione-progetti',
					'label' => 'Tecnica e progettazione',
					'dest'  => array( 'cpt_single', 'capability:gestione-progetti' ),
				),
			),
		),

		array(
			'key'      => 'lavora-con-noi',
			'label'    => 'Jobs',
			'dest'     => array( 'none', '' ),
			'children' => array(
				array(
					'key'    => 'posizioni-vacanti',
					'label'  => 'Posizioni vacanti',
					'dest'   => array( 'cpt_archive', 'job' ),
					'ancora' => 'posizioni-aperte',
				),
				array(
					'key'    => 'candidature-spontanee',
					'label'  => 'Candidature spontanee',
					'dest'   => array( 'cpt_archive', 'job' ),
					'ancora' => 'candidatura-spontanea',
				),
			),
		),

		array(
			'key'      => 'qualita-e-ambiente',
			'label'    => 'Qualità / Ambiente e sicurezza',
			'dest'     => array( 'none', '' ),
			'children' => array(
				array(
					// introduzione, rapporti CSR e capitolo Economia di Sostenibilita'
					'key'   => 'qualita',
					'label' => 'Qualità',
					'dest'  => array( 'page', 'sostenibilita' ),
				),
				array(
					'key'    => 'tutela-ambiente',
					'label'  => 'Tutela ambiente',
					'dest'   => array( 'page', 'sostenibilita' ),
					'ancora' => 'ambiente',
				),
				array(
					'key'    => 'salute-sicurezza',
					'label'  => 'Salute, sicurezza, etica e benessere',
					'dest'   => array( 'page', 'sostenibilita' ),
					'ancora' => 'persone',
				),
				array(
					'key'   => 'certificazioni',
					'label' => 'Certificazioni',
					'dest'  => array( 'page', 'certificazioni' ),
				),
				array(
					'key'   => 'condizioni-di-vendita',
					'label' => 'Condizioni di vendita',
					'dest'  => array( 'page', 'condizioni-di-vendita' ),
					'nota'  => 'Documento del 2017, marcato da riautorizzare.',
				),
			),
		),
	) );
}

/**
 * Destinazione utility: Contatti. Non e' una voce di navigazione.
 *
 * @return array{label:string,dest:array{0:string,1:string}}
 */
function tenconi_nav_utility() {
	$label = 'Contatti';
	if ( function_exists( 'ticinoweb_frontend_text' ) ) {
		$label = ticinoweb_frontend_text( $label, 'tenconi:nav:contatti-utility' );
	}
	return array(
		'label' => $label,
		'dest'  => array( 'page', 'contatti' ),
	);
}

/**
 * Un post ha testo pubblicabile?
 *
 * @param WP_Post $post Il post da valutare.
 * @return array{ok:bool,motivo:string}
 */
function tenconi_testo_pubblicabile( $post ) {

	if ( 'publish' !== $post->post_status ) {
		return array(
			'ok'     => false,
			'motivo' => 'non pubblicata (' . $post->post_status . ')',
		);
	}

	$testo = trim( wp_strip_all_tags( (string) $post->post_content ) );

	/*
	 * IL GATING AUTOMATICO E' STATO RIMOSSO su decisione esplicita del committente
	 * (07/08/2026). Prima una pagina restava fuori dal menu se conteneva un
	 * segnaposto o se il testo era sotto i 120 caratteri.
	 *
	 * Serviva quando il sito era incompleto: evitava di pubblicare pagine vuote.
	 * Ora l'obiettivo e' un altro — il menu deve replicare quello del legacy — e
	 * una pagina che nel legacy era un vero link non puo' restare spenta perche'
	 * la migrazione le ha lasciato dentro un segnaposto. Il segnaposto si
	 * ripristina dal legacy, non si nasconde spegnendo la voce.
	 *
	 * Resta il solo controllo che conta: la pagina deve esistere ed essere
	 * pubblicata. Quello e' verificato sopra.
	 */

	/*
	 * Solo 'placeholder' vieta la pubblicazione. 'partial' NO, e la distinzione
	 * conta: /contatti/ e' partial perche' manca l'indirizzo della seconda sede,
	 * ma quello di Airolo e' reale e completo e la pagina non mostra nessun
	 * segnaposto. Vietarla avrebbe spento la conversione principale del sito per
	 * un dato che non e' in pagina. Dove invece un contenuto parziale va tenuto
	 * fuori per decisione del committente, lo dice il flag 'ritenuta'.
	 */
	$stato = (string) get_post_meta( $post->ID, '_tcm_text_state', true );
	if ( 'placeholder' === $stato ) {
		return array(
			'ok'     => false,
			'motivo' => 'testo marcato placeholder dalla Content Foundation',
		);
	}

	if ( has_term( 'Da riautorizzare', 'confidentiality', $post->ID ) ) {
		return array(
			'ok'     => false,
			'motivo' => 'marcato da riautorizzare',
		);
	}

	return array(
		'ok'     => true,
		'motivo' => '',
	);
}

/**
 * Stato di una destinazione: esiste, e' pubblicabile, e a quale URL.
 *
 * Memorizzato per richiesta: la stessa destinazione compare piu volte fra
 * header, homepage e footer.
 *
 * @param string $kind Tipo di destinazione.
 * @param string $ref  Riferimento, la cui forma dipende dal tipo.
 * @return array{ok:bool,url:string,motivo:string,extra:string}
 */
function tenconi_dest_state( $kind, $ref ) {

	static $cache = array();
	$chiave = $kind . '|' . $ref;
	if ( isset( $cache[ $chiave ] ) ) {
		return $cache[ $chiave ];
	}

	$out = array(
		'ok'     => false,
		'url'    => '',
		'motivo' => '',
		'extra'  => '',
	);

	/*
	 * LE CINQUE PAGINE AREA PASSANO PER UNA VIA PROPRIA, e la ragione va scritta.
	 *
	 * Il cancello misura se una destinazione ha contenuto guardando il database:
	 * quanti record sono assegnati a un termine, quanti caratteri ha un testo. Con
	 * quel criterio le cinque aree risultavano vuote — archivi a zero record e
	 * testi da dieci caratteri — e infatti restavano non cliccabili.
	 *
	 * Ma nel legacy quelle pagine NON elencavano altri contenuti: mostravano due
	 * gallerie di fotografie con didascalia, e quelle gallerie ora esistono, mappate
	 * in inc/legacy-aree-media.php e verificate sugli screenshot. Il contenuto c'e',
	 * solo non e' nel posto in cui il cancello lo cercava.
	 *
	 * Quindi il cancello non viene aggirato: viene insegnato a guardare anche qui.
	 * Se un giorno la mappa perdesse una pagina, quella pagina tornerebbe chiusa da
	 * sola, che e' il comportamento giusto.
	 */
	if ( function_exists( 'tenconi_legacy_aree_media' ) && in_array( $kind, array( 'term_archive', 'cpt_single' ), true ) ) {
		$slug  = substr( $ref, strpos( $ref, ':' ) + 1 );
		$key   = tenconi_legacy_area_chiave( $slug );
		$mappa = tenconi_legacy_aree_media();
		if ( '' !== $key && ! empty( $mappa[ $key ]['g1']['img'] ) ) {
			$url = '';
			if ( 'term_archive' === $kind ) {
				$tax = substr( $ref, 0, strpos( $ref, ':' ) );
				$t   = get_term_by( 'slug', $slug, $tax );
				if ( $t && ! is_wp_error( $t ) ) {
					$l = get_term_link( $t );
					$url = is_wp_error( $l ) ? '' : $l;
				}
			} else {
				$tipo = substr( $ref, 0, strpos( $ref, ':' ) );
				$post = get_page_by_path( $slug, OBJECT, $tipo );
				$url  = $post ? get_permalink( $post ) : '';
			}
			if ( $url ) {
				$out['ok']    = true;
				$out['url']   = $url;
				$out['extra'] = 'galleria legacy';
				$cache[ $chiave ] = $out;
				return $out;
			}
		}
	}

	switch ( $kind ) {

		case 'none':
			$out['motivo'] = 'nessuna destinazione esiste';
			break;

		case 'page':
			$p = get_page_by_path( $ref );
			if ( ! $p ) {
				$out['motivo'] = 'la pagina non esiste';
				break;
			}
			$v             = tenconi_testo_pubblicabile( $p );
			$out['ok']     = $v['ok'];
			$out['motivo'] = $v['motivo'];
			$out['url']    = get_permalink( $p );
			$out['extra']  = sprintf( '%d caratteri', mb_strlen( trim( wp_strip_all_tags( (string) $p->post_content ) ) ) );
			break;

		case 'cpt_single':
			list( $tipo, $slug ) = array_pad( explode( ':', $ref, 2 ), 2, '' );
			$p                   = get_page_by_path( $slug, OBJECT, $tipo );
			if ( ! $p ) {
				$out['motivo'] = 'il record non esiste';
				break;
			}
			$v             = tenconi_testo_pubblicabile( $p );
			$out['ok']     = $v['ok'];
			$out['motivo'] = $v['motivo'];
			$out['url']    = get_permalink( $p );
			$out['extra']  = sprintf( '%d caratteri', mb_strlen( trim( wp_strip_all_tags( (string) $p->post_content ) ) ) );
			break;

		case 'cpt_archive':
			$url = get_post_type_archive_link( $ref );
			if ( ! $url ) {
				$out['motivo'] = 'archivio non registrato';
				break;
			}
			$out['url'] = $url;
			$ids        = get_posts(
				array(
					'post_type'        => $ref,
					'numberposts'      => -1,
					'fields'           => 'ids',
					'suppress_filters' => false,
				)
			);
			$tot        = count( $ids );
			if ( 0 === $tot ) {
				$out['motivo'] = 'archivio senza record pubblicati';
				$out['extra']  = '0 record';
				break;
			}
			$rev = 0;
			foreach ( $ids as $id ) {
				if ( has_term( 'Da riautorizzare', 'confidentiality', $id ) ) {
					++$rev;
				}
			}
			$out['extra'] = sprintf( '%d record', $tot );
			if ( $rev === $tot ) {
				$out['motivo'] = sprintf( 'tutti i %d record sono da riautorizzare', $tot );
				break;
			}
			if ( $rev > 0 ) {
				$out['extra'] .= sprintf( ', %d da riautorizzare', $rev );
			}
			$out['ok'] = true;
			break;

		case 'term_archive':
			list( $tax, $slug ) = array_pad( explode( ':', $ref, 2 ), 2, '' );
			$t                  = get_term_by( 'slug', $slug, $tax );
			if ( ! $t || is_wp_error( $t ) ) {
				$out['motivo'] = 'il termine non esiste';
				break;
			}
			$out['url']   = get_term_link( $t );
			$out['extra'] = sprintf( '%d contenuti assegnati', (int) $t->count );
			if ( 0 === (int) $t->count ) {
				$out['motivo'] = 'nessun contenuto assegnato: archivio vuoto';
				break;
			}
			$out['ok'] = true;
			break;
	}

	if ( is_wp_error( $out['url'] ) ) {
		$out['url'] = '';
		$out['ok']  = false;
	}

	$cache[ $chiave ] = $out;
	return $out;
}

/**
 * Comodita': l'URL di una destinazione, solo se pubblicabile.
 *
 * @param string $kind Tipo.
 * @param string $ref  Riferimento.
 * @return string URL, oppure stringa vuota.
 */
function tenconi_dest_url( $kind, $ref ) {
	$s = tenconi_dest_state( $kind, $ref );
	return $s['ok'] ? (string) $s['url'] : '';
}

/**
 * La navigazione da mostrare al pubblico.
 *
 * Regole di resa, in quest'ordine:
 *   - un figlio entra solo se la sua destinazione passa il cancello;
 *   - se il genitore ha figli abilitati diventa un BUTTON che apre il pannello.
 *     Se anche la sua destinazione passa il cancello, entra come primo link del
 *     pannello: cosi la voce resta raggiungibile senza trasformare il trigger
 *     in un link finto;
 *   - se il genitore non ha figli abilitati ma la sua destinazione passa,
 *     diventa un link diretto;
 *   - se non passa nulla, la voce non viene resa.
 *
 * @return array<int,array<string,mixed>>
 */
function tenconi_nav_public() {

	static $out = null;
	if ( null !== $out ) {
		return $out;
	}

	$out = array();

	foreach ( tenconi_nav_blueprint() as $voce ) {

		$figli = array();
		foreach ( $voce['children'] as $f ) {
			if ( ! empty( $f['ritenuta'] ) ) {
				continue;
			}
			$s = tenconi_dest_state( $f['dest'][0], $f['dest'][1] );
			if ( $s['ok'] ) {
				$figli[] = array(
					'key'   => $f['key'],
					'label' => $f['label'],
					'url'   => $s['url'],
				);
			}
		}

		$hub = tenconi_dest_state( $voce['dest'][0], $voce['dest'][1] );
		if ( ! empty( $voce['ritenuta'] ) ) {
			$hub['ok'] = false;
		}

		if ( $figli ) {
			if ( $hub['ok'] ) {
				array_unshift(
					$figli,
					array(
						'key'   => $voce['key'],
						'label' => $voce['label'],
						'url'   => $hub['url'],
					)
				);
			}
			$out[] = array(
				'key'      => $voce['key'],
				'label'    => $voce['label'],
				'tipo'     => 'gruppo',
				'url'      => '',
				'children' => $figli,
			);
			continue;
		}

		if ( $hub['ok'] ) {
			$out[] = array(
				'key'      => $voce['key'],
				'label'    => $voce['label'],
				'tipo'     => 'link',
				'url'      => $hub['url'],
				'children' => array(),
			);
		}
	}

	return $out;
}

/**
 * La navigazione per la LEGACY PARITY.
 *
 * Differenza di principio rispetto a tenconi_nav_public(): li' una voce senza
 * figli abilitati NON veniva resa, e l'header perdeva "Qualita e ambiente",
 * scendendo a quattro voci. Il committente ha deciso il contrario: le cinque voci
 * del menu legacy sono la struttura, e restano tutte visibili sempre.
 *
 * COSA CAMBIA PER UNA DESTINAZIONE NON PUBBLICABILE. Non si inventa una pagina,
 * non si usa href="#" e non si porta a una pagina vuota: l'etichetta resta al suo
 * posto nel menu e diventa NON CLICCABILE. Il visitatore vede la struttura vera
 * del sito; il link compare da solo il giorno in cui il contenuto e' pronto.
 *
 * Il primo livello non e' mai un link quando ha figli: nel legacy era un folder
 * Squarespace che serviva il primo figlio, meccanismo che in WordPress non esiste
 * e che non va simulato con una pagina hub inventata.
 *
 * @return array<int,array<string,mixed>>
 */
function tenconi_nav_legacy() {

	static $out = null;
	if ( null !== $out ) {
		return $out;
	}

	$out = array();

	foreach ( tenconi_nav_blueprint() as $voce ) {

		$figli = array();
		foreach ( $voce['children'] as $f ) {
			$rit = ! empty( $f['ritenuta'] );
			$s   = tenconi_dest_state( $f['dest'][0], $f['dest'][1] );
			$ok  = $s['ok'] && ! $rit;
			$url = $ok ? $s['url'] : '';
			if ( '' !== $url && ! empty( $f['ancora'] ) ) {
				$url .= '#' . sanitize_title( $f['ancora'] );
			}
			$figli[] = array(
				'key'    => $f['key'],
				'label'  => $f['label'],
				'url'    => $url,
				'attiva' => $ok,
				'motivo' => $ok ? '' : ( $rit ? 'ritenuta dal committente' : $s['motivo'] ),
			);
		}

		$hub = tenconi_dest_state( $voce['dest'][0], $voce['dest'][1] );
		if ( ! empty( $voce['ritenuta'] ) ) {
			$hub['ok'] = false;
		}

		/*
		 * Se la voce ha figli, il primo livello apre la tendina e non e' un link.
		 * Se la destinazione della voce e' pubblicabile, entra come primo figlio,
		 * cosi' resta raggiungibile senza trasformare il trigger in un link finto.
		 */
		if ( $figli && empty( $voce['piatta'] ) ) {
			if ( $hub['ok'] ) {
				array_unshift(
					$figli,
					array(
						'key'    => $voce['key'],
						'label'  => $voce['label'],
						'url'    => $hub['url'],
						'attiva' => true,
						'motivo' => '',
					)
				);
			}
			$out[] = array(
				'key'      => $voce['key'],
				'label'    => $voce['label'],
				'tipo'     => 'gruppo',
				'url'      => '',
				'children' => $figli,
			);
			continue;
		}

		// Senza figli: link diretto se pubblicabile, altrimenti etichetta inerte.
		$out[] = array(
			'key'      => $voce['key'],
			'label'    => $voce['label'],
			'tipo'     => $hub['ok'] ? 'link' : 'inerte',
			'url'      => $hub['ok'] ? $hub['url'] : '',
			'children' => array(),
		);
	}

	return $out;
}

/**
 * Rapporto completo sullo stato dell'architettura.
 *
 * Serve al checkpoint e a chiunque debba sapere cosa manca per accendere una
 * voce. Non viene stampato nel frontend.
 *
 * @return array<int,array<string,mixed>>
 */
function tenconi_nav_report() {

	$righe = array();

	foreach ( tenconi_nav_blueprint() as $voce ) {

		$s       = tenconi_dest_state( $voce['dest'][0], $voce['dest'][1] );
		$righe[] = array(
			'livello' => 1,
			'key'     => $voce['key'],
			'label'   => $voce['label'],
			'dest'    => $voce['dest'][0] . ( '' !== $voce['dest'][1] ? ':' . $voce['dest'][1] : '' ),
			'ok'      => $s['ok'],
			'motivo'  => $s['ok'] ? '' : ( $s['motivo'] ? $s['motivo'] : ( $voce['nota'] ?? '' ) ),
			'extra'   => $s['extra'],
		);

		foreach ( $voce['children'] as $f ) {
			$sf  = tenconi_dest_state( $f['dest'][0], $f['dest'][1] );
			$rit = ! empty( $f['ritenuta'] );
			$righe[] = array(
				'livello'  => 2,
				'key'      => $f['key'],
				'label'    => $f['label'],
				'dest'     => $f['dest'][0] . ( '' !== $f['dest'][1] ? ':' . $f['dest'][1] : '' ),
				'ok'       => $sf['ok'] && ! $rit,
				'ritenuta' => $rit,
				'motivo'   => ( $sf['ok'] && ! $rit ) ? '' : ( $rit ? 'RITENUTA dal committente' : ( $sf['motivo'] ? $sf['motivo'] : ( $f['nota'] ?? '' ) ) ),
				'extra'    => $sf['extra'],
			);
		}
	}

	$u       = tenconi_nav_utility();
	$su      = tenconi_dest_state( $u['dest'][0], $u['dest'][1] );
	$righe[] = array(
		'livello' => 0,
		'key'     => 'contatti',
		'label'   => $u['label'] . ' (utility)',
		'dest'    => $u['dest'][0] . ':' . $u['dest'][1],
		'ok'      => $su['ok'],
		'motivo'  => $su['ok'] ? '' : $su['motivo'],
		'extra'   => $su['extra'],
	);

	return $righe;
}
