<?php
/** Selection presentation reads the existing page, categories and WooCommerce products. */
defined( 'ABSPATH' ) || exit;

function adb_collection_page_kind() {
    if ( ! is_page() ) { return ''; }
    $page = get_queried_object();
    if ( ! $page instanceof WP_Post || ! has_shortcode( $page->post_content, 'adb_collection' ) ) { return ''; }
    if ( preg_match( '/\[adb_collection\b([^\]]*)\]/', $page->post_content, $match ) ) {
        $atts = shortcode_parse_atts( $match[1] );
        return is_array( $atts ) ? sanitize_key( $atts['kind'] ?? 'selections' ) : 'selections';
    }
    return '';
}

function adb_is_selection_page() { return 'selections' === adb_collection_page_kind(); }
function adb_is_offers_page() { return 'offers' === adb_collection_page_kind(); }

add_action( 'template_redirect', function () {
    if ( ! adb_is_offers_page() ) { return; }
    // A cached editorial page must not outlive a price change or sale end date.
    if ( ! defined( 'DONOTCACHEPAGE' ) ) { define( 'DONOTCACHEPAGE', true ); }
    nocache_headers();
    do_action( 'litespeed_control_set_nocache', 'Dynamic WooCommerce offers' );
} );

/** Dates and variations remain WooCommerce's responsibility, rather than a second price engine. */
function adb_offer_is_active( $product ) {
    if ( ! $product instanceof WC_Product || ! $product->is_visible() || ! $product->is_on_sale() ) { return false; }
    if ( ! $product->is_type( 'variable' ) ) { return true; }
    // A stale variable-price cache must not keep a finished variation sale in the list.
    $children = $product->get_visible_children();
    if ( $children ) { _prime_post_caches( $children, true, true ); }
    foreach ( $children as $id ) {
        $variation = wc_get_product( $id );
        if ( $variation && $variation->variation_is_visible() && $variation->is_on_sale() ) { return true; }
    }
    return false;
}

function adb_offer_ids() {
    $ids = array();
    $candidates = wp_parse_id_list( wc_get_product_ids_on_sale() );
    // WooCommerce's lookup flag can omit a zero sale price. Keep WC_Product as
    // the authority, using this narrow candidate fallback only for that case.
    $zero_sales = get_posts( array(
        'post_type' => array( 'product', 'product_variation' ), 'post_status' => 'publish',
        'posts_per_page' => -1, 'fields' => 'ids', 'suppress_filters' => false,
        'meta_query' => array(
            array( 'key' => '_sale_price', 'value' => '', 'compare' => '!=' ),
            array( 'key' => '_sale_price', 'value' => 0, 'compare' => '=', 'type' => 'DECIMAL(19,4)' ),
        ),
    ) );
    if ( $zero_sales ) {
        _prime_post_caches( $zero_sales, false, false );
        $candidates = array_merge( $candidates, $zero_sales, array_map( 'wp_get_post_parent_id', $zero_sales ) );
    }
    // The native cache is invalidated by WooCommerce when products/variations are saved.
    // Batch hydration avoids the editorial helper's 100-product limit truncating future offers.
    foreach ( array_chunk( wp_parse_id_list( $candidates ), 100 ) as $batch ) {
        foreach ( adb_products( array( 'ids' => $batch, 'limit' => 100 ) ) as $product ) {
            if ( adb_offer_is_active( $product ) ) { $ids[] = $product->get_id(); }
        }
    }
    return array_values( array_unique( $ids ) );
}

function adb_offers_page( $page = 1, $per_page = 24 ) {
    $query = new WP_Query( array(
        'post_type' => 'product', 'post_status' => 'publish', 'post__in' => adb_offer_ids() ?: array( 0 ),
        'posts_per_page' => max( 1, min( 48, (int) $per_page ) ), 'paged' => max( 1, (int) $page ),
        'adb_language' => 'it', 'orderby' => array( 'title' => 'ASC', 'ID' => 'ASC' ), 'ignore_sticky_posts' => true,
    ) );
    return array( 'products' => adb_products( array( 'ids' => wp_list_pluck( $query->posts, 'ID' ), 'limit' => $per_page ) ), 'total' => (int) $query->found_posts, 'pages' => (int) $query->max_num_pages );
}

function adb_offers_requested_page() {
    // Match WooCommerce's shortcode pagination, without requiring archive rewrite rules.
    $value = wp_unslash( $_GET['product-page'] ?? 1 ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- public read-only pagination.
    return is_scalar( $value ) ? max( 1, absint( $value ) ) : 1;
}

function adb_render_offers() {
    $page = adb_offers_requested_page();
    $result = adb_offers_page( $page );
    if ( $page > max( 1, $result['pages'] ) ) { $page = max( 1, $result['pages'] ); $result = adb_offers_page( $page ); }
    $intro = get_the_excerpt( get_queried_object_id() );
    ob_start(); ?>
    <div class="adb-collections adb-offers">
        <header class="adb-collections__heading"><h1><?php echo esc_html( get_the_title( get_queried_object_id() ) ); ?></h1><div><?php if ( $intro ) : ?><p><?php echo esc_html( $intro ); ?></p><?php endif; ?></div></header>
        <section class="adb-collections__catalog" aria-labelledby="adb-offers-title">
            <div class="adb-collections__catalog-heading"><h2 id="adb-offers-title"><?php esc_html_e( 'Le occasioni del momento', 'amicidibacco' ); ?></h2><p><?php echo esc_html( sprintf( _n( '%d prodotto in offerta', '%d prodotti in offerta', $result['total'], 'amicidibacco' ), $result['total'] ) ); ?></p></div>
            <?php if ( $result['products'] ) : ?>
                <p class="adb-offers__variants"><?php esc_html_e( 'Per i prodotti con più formati o annate, apri la scheda per vedere le varianti in offerta.', 'amicidibacco' ); ?></p>
                <div class="adb-product-grid"><?php foreach ( $result['products'] as $product ) { adb_product_card( $product, 'adb-product--offer' ); } ?></div>
            <?php else : ?>
                <p><?php esc_html_e( 'Al momento non ci sono offerte attive. Le nuove proposte compariranno automaticamente qui.', 'amicidibacco' ); ?></p>
                <a class="adb-link" href="<?php echo esc_url( adb_catalog_url() ); ?>"><?php esc_html_e( 'Esplora l’enoteca', 'amicidibacco' ); ?><?php echo adb_icon(); ?></a>
            <?php endif; ?>
        </section>
        <?php if ( $result['pages'] > 1 ) : ?><nav class="adb-collection-pagination" aria-label="<?php esc_attr_e( 'Pagine delle offerte', 'amicidibacco' ); ?>"><?php echo wp_kses_post( paginate_links( array( 'base' => str_replace( '999999999', '%#%', add_query_arg( 'product-page', 999999999, get_permalink( get_queried_object_id() ) ) ), 'format' => '', 'total' => $result['pages'], 'current' => $page, 'prev_text' => __( 'Precedente', 'amicidibacco' ), 'next_text' => __( 'Successiva', 'amicidibacco' ), 'type' => 'list' ) ) ); ?></nav><?php endif; ?>
    </div>
    <?php return ob_get_clean();
}

function adb_render_selections() {
    $page = max( 1, (int) get_query_var( 'paged' ), (int) get_query_var( 'page' ) );
    $tax = array( array( 'taxonomy' => 'product_cat', 'field' => 'slug', 'terms' => array( 'le-selezioni', 'le-selezioni-grappa' ) ) );
    $visibility = wc_get_product_visibility_term_ids();
    $excluded = array_filter( array( $visibility['exclude-from-catalog'] ?? 0, 'yes' === get_option( 'woocommerce_hide_out_of_stock_items' ) ? ( $visibility['outofstock'] ?? 0 ) : 0 ) );
    if ( $excluded ) { $tax[] = array( 'taxonomy' => 'product_visibility', 'field' => 'term_taxonomy_id', 'terms' => $excluded, 'operator' => 'NOT IN' ); }
    $query = new WP_Query( array( 'post_type' => 'product', 'post_status' => 'publish', 'posts_per_page' => 24, 'paged' => $page, 'adb_language' => 'it', 'tax_query' => $tax, 'orderby' => 'date', 'order' => 'DESC', 'ignore_sticky_posts' => true ) );
    $products = adb_products( array( 'ids' => wp_list_pluck( $query->posts, 'ID' ), 'limit' => 24 ) );
    $featured = 1 === $page && $products ? array_shift( $products ) : null;
    $intro = get_the_excerpt( get_queried_object_id() );
    ob_start();
    ?>
    <div class="adb-collections">
        <header class="adb-collections__heading"><h1><?php echo esc_html( get_the_title( get_queried_object_id() ) ); ?></h1><div><p><?php echo esc_html( $intro ?: __( 'Scopri cosa racchiude ogni selezione e trova quella che fa per te.', 'amicidibacco' ) ); ?></p></div></header>
        <?php if ( $featured ) : ?>
        <article class="adb-collection-feature" aria-labelledby="adb-collection-feature-title">
            <a class="adb-collection-feature__photo" href="<?php echo esc_url( $featured->get_permalink() ); ?>" aria-label="<?php echo esc_attr( $featured->get_name() ); ?>"><?php echo $featured->get_image( 'large', array( 'loading' => 'eager', 'fetchpriority' => 'high', 'decoding' => 'async' ) ); ?><?php if ( $featured->is_on_sale() ) : ?><span class="adb-product__badge"><?php esc_html_e( 'In offerta', 'amicidibacco' ); ?></span><?php endif; ?></a>
            <div class="adb-collection-feature__body">
                <?php if ( $featured->get_attribute( 'pa_cantina' ) ) : ?><p class="adb-collection-feature__producer"><?php echo esc_html( $featured->get_attribute( 'pa_cantina' ) ); ?></p><?php endif; ?>
                <h2 id="adb-collection-feature-title"><a href="<?php echo esc_url( $featured->get_permalink() ); ?>"><?php echo esc_html( $featured->get_name() ); ?></a></h2>
                <?php if ( trim( $featured->get_short_description() ) ) : ?><p class="adb-collection-feature__intro"><?php echo esc_html( wp_trim_words( wp_strip_all_tags( $featured->get_short_description() ), 45 ) ); ?></p><?php endif; ?>
                <p class="adb-collection-feature__price"><?php echo wp_kses_post( $featured->get_price_html() ); ?></p>
                <a class="adb-button" href="<?php echo esc_url( $featured->get_permalink() ); ?>"><?php esc_html_e( 'Scopri la selezione', 'amicidibacco' ); ?><?php echo adb_icon(); ?></a>
            </div>
        </article>
        <?php endif; ?>
        <section class="adb-collections__catalog" aria-labelledby="adb-collections-title"><div class="adb-collections__catalog-heading"><h2 id="adb-collections-title"><?php echo esc_html( $featured ? __( 'Le altre selezioni', 'amicidibacco' ) : __( 'Esplora le selezioni', 'amicidibacco' ) ); ?></h2><p><?php echo esc_html( sprintf( _n( '%d selezione disponibile', '%d selezioni disponibili', (int) $query->found_posts, 'amicidibacco' ), $query->found_posts ) ); ?></p></div>
            <?php if ( $products ) : ?><div class="adb-product-grid"><?php foreach ( $products as $product ) { adb_product_card( $product, 'adb-product--collection' ); } ?></div><?php elseif ( ! $featured ) : ?><p><?php esc_html_e( 'Al momento non ci sono selezioni disponibili.', 'amicidibacco' ); ?></p><a class="adb-link" href="<?php echo esc_url( adb_catalog_url() ); ?>"><?php esc_html_e( 'Esplora l’enoteca', 'amicidibacco' ); ?><?php echo adb_icon(); ?></a><?php endif; ?>
        </section>
        <?php if ( $query->max_num_pages > 1 ) : ?><nav class="adb-collection-pagination" aria-label="<?php esc_attr_e( 'Pagine delle selezioni', 'amicidibacco' ); ?>"><?php echo wp_kses_post( paginate_links( array( 'total' => $query->max_num_pages, 'current' => $page, 'prev_text' => __( 'Precedente', 'amicidibacco' ), 'next_text' => __( 'Successiva', 'amicidibacco' ), 'type' => 'list' ) ) ); ?></nav><?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}
