<?php
/** Read-only, bounded product suggestions. The normal search form remains the fallback. */
defined('ABSPATH') || exit;

function adb_search_rate_key() {
    $address = isset($_SERVER['REMOTE_ADDR']) && is_string($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
    return 'adb_search_' . substr(hash_hmac('sha256', $address, wp_salt('nonce')), 0, 32);
}

function adb_search_suggestions($request) {
    if (!function_exists('wc_get_product')) { return new WP_Error('adb_search_unavailable', __('Il catalogo non è disponibile.', 'amicidibacco'), ['status' => 503]); }
    // Public information only: no nonce or user capability is needed for this GET route.
    // Store only an ephemeral keyed digest, never an IP address or search history.
    $key = adb_search_rate_key();
    $bucket = get_transient($key);
    if (!is_array($bucket) || ($bucket['until'] ?? 0) <= time()) { $bucket = ['count' => 0, 'until' => time() + 60]; }
    if ($bucket['count'] >= 80) { return new WP_Error('adb_search_limit', __('Attendi un momento oppure premi Invio per cercare nel catalogo.', 'amicidibacco'), ['status' => 429]); }
    $bucket['count']++;
    set_transient($key, $bucket, max(1, $bucket['until'] - time()));

    $term = sanitize_text_field($request->get_param('term'));
    $visibility = wc_get_product_visibility_term_ids();
    $excluded = array_filter([$visibility['exclude-from-search'] ?? 0]);
    if ('yes' === get_option('woocommerce_hide_out_of_stock_items')) { $excluded[] = $visibility['outofstock'] ?? 0; }
    $args = ['post_type' => 'product', 'post_status' => 'publish', 's' => $term, 'posts_per_page' => 6,
        'orderby' => 'relevance', 'ignore_sticky_posts' => true, 'suppress_filters' => false, 'adb_language' => 'it'];
    if ($excluded) { $args['tax_query'] = [['taxonomy' => 'product_visibility', 'field' => 'term_taxonomy_id', 'terms' => array_filter($excluded), 'operator' => 'NOT IN']]; }
    $query = new WP_Query($args);
    $items = [];
    foreach ($query->posts as $post) {
        $product = wc_get_product($post->ID);
        if (!$product || !in_array($product->get_catalog_visibility(), ['visible', 'search'], true)) { continue; }
        $items[] = [
            'name' => wp_strip_all_tags($product->get_name()),
            'url' => get_permalink($post),
            'image' => wp_get_attachment_image_url($product->get_image_id(), 'woocommerce_thumbnail') ?: wc_placeholder_img_src('woocommerce_thumbnail'),
            'winery' => wp_strip_all_tags($product->get_attribute('pa_cantina')),
            'price' => wp_kses($product->get_price_html(), ['span' => ['class' => true, 'aria-hidden' => true], 'bdi' => [], 'del' => ['aria-hidden' => true], 'ins' => ['aria-hidden' => true], 'small' => ['class' => true]]),
        ];
    }
    $response = new WP_REST_Response(['items' => $items, 'total' => (int) $query->found_posts,
        'all_url' => add_query_arg(['s' => $term, 'post_type' => 'product'], home_url('/'))]);
    $response->header('Cache-Control', 'no-store, max-age=0');
    return $response;
}

add_action('rest_api_init', static function () {
    register_rest_route('amicidibacco/v1', '/search', [
        'methods' => WP_REST_Server::READABLE,
        'permission_callback' => '__return_true',
        'callback' => 'adb_search_suggestions',
        'args' => ['term' => ['required' => true, 'type' => 'string',
            'validate_callback' => static function ($value) {
                if (!is_string($value)) { return false; }
                $value = trim(sanitize_text_field($value));
                $length = function_exists('mb_strlen') ? mb_strlen($value) : strlen($value);
                return $length >= 2 && $length <= 80;
            }, 'sanitize_callback' => 'sanitize_text_field']],
    ]);
});
