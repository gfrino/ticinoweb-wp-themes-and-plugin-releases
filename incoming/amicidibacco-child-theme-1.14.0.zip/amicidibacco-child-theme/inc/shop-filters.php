<?php
/** Read-only, variant-aware facets. All choices and prices come from WooCommerce. */
defined( 'ABSPATH' ) || exit;

function adb_shop_selection( $input = null ) {
    $input = null === $input ? wp_unslash( $_GET ) : $input; // Public read-only GET form.
    $out = array();
    foreach ( adb_catalog_filter_definitions() as $def ) {
        $value = $input[ $def['param'] ] ?? '';
        if ( is_scalar( $value ) && '' !== (string) $value ) { $out[ $def['param'] ] = sanitize_title( substr( (string) $value, 0, 200 ) ); }
    }
    foreach ( array( 'adb_min_price', 'adb_max_price' ) as $key ) {
        $value = $input[ $key ] ?? '';
        if ( is_scalar( $value ) && preg_match( '/^\d{1,7}(?:[.,]\d{1,2})?$/D', (string) $value ) ) { $out[ $key ] = (float) str_replace( ',', '.', $value ); }
    }
    if ( isset( $out['adb_min_price'], $out['adb_max_price'] ) && $out['adb_min_price'] > $out['adb_max_price'] ) {
        $min = $out['adb_max_price']; $out['adb_max_price'] = $out['adb_min_price']; $out['adb_min_price'] = $min;
    }
    return array_filter( $out, static function ( $value ) { return '' !== $value; } );
}

/** Small batched index, request-local only: no duplicated CMS data, transients or public endpoint. */
function adb_shop_index() {
    static $index = null;
    if ( null !== $index ) { return $index; }
    global $wpdb;
    $index = array( 'filters' => array(), 'rows' => array() );
    $definitions = adb_catalog_filter_definitions();
    $all_terms = get_terms( array( 'taxonomy' => array_filter( array_column( $definitions, 'taxonomy' ), 'taxonomy_exists' ), 'hide_empty' => false, 'adb_language' => 'it', 'orderby' => 'name' ) );
    $taxonomy_params = array();
    foreach ( $definitions as $def ) {
        $taxonomy_params[ $def['taxonomy'] ] = $def['param'];
        $terms = is_wp_error( $all_terms ) ? array() : array_filter( $all_terms, static function ( $term ) use ( $def ) { return $term->taxonomy === $def['taxonomy']; } );
        $def['terms'] = array();
        foreach ( is_wp_error( $terms ) ? array() : $terms as $term ) {
            $def['terms'][] = array( 'id' => (int) $term->term_id, 'slug' => $term->slug, 'name' => html_entity_decode( $term->name, ENT_QUOTES, 'UTF-8' ) );
        }
        $index['filters'][] = $def;
    }
    $visibility = wc_get_product_visibility_term_ids();
    $excluded = array_filter( array( $visibility[ is_search() ? 'exclude-from-search' : 'exclude-from-catalog' ] ?? 0, 'yes' === get_option( 'woocommerce_hide_out_of_stock_items' ) ? ( $visibility['outofstock'] ?? 0 ) : 0 ) );
    $ids = array();
    // Batches keep new catalogs bounded without silently dropping later products.
    for ( $page = 1; ; ++$page ) {
        $args = array( 'post_type' => 'product', 'post_status' => 'publish', 'posts_per_page' => 500, 'paged' => $page, 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'ASC', 'no_found_rows' => true, 'adb_language' => 'it', 'suppress_filters' => false, 'update_post_meta_cache' => false, 'update_post_term_cache' => false );
        if ( $excluded ) { $args['tax_query'] = array( array( 'taxonomy' => 'product_visibility', 'field' => 'term_taxonomy_id', 'terms' => $excluded, 'operator' => 'NOT IN' ) ); }
        $batch = get_posts( $args );
        $ids = array_merge( $ids, array_map( 'intval', $batch ) );
        if ( count( $batch ) < 500 ) { break; }
    }
    if ( ! $ids ) { return $index; }
    $parent_facets = array_fill_keys( $ids, array() );
    $relationships = wp_get_object_terms( $ids, array_keys( $taxonomy_params ), array( 'fields' => 'all_with_object_id', 'adb_language' => 'it' ) );
    foreach ( is_wp_error( $relationships ) ? array() : $relationships as $term ) {
        $param = $taxonomy_params[ $term->taxonomy ];
        $parent_facets[ $term->object_id ][ $param ][] = (int) $term->term_id;
        if ( 'product_cat' === $term->taxonomy ) {
            foreach ( get_ancestors( $term->term_id, 'product_cat', 'taxonomy' ) as $ancestor ) { $parent_facets[ $term->object_id ][ $param ][] = (int) $ancestor; }
        }
    }
    $placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
    $records = $wpdb->get_results( $wpdb->prepare( "SELECT p.ID, p.post_parent, l.min_price, l.stock_status FROM {$wpdb->posts} p LEFT JOIN {$wpdb->wc_product_meta_lookup} l ON l.product_id=p.ID WHERE (p.ID IN ($placeholders) OR (p.post_type='product_variation' AND p.post_status='publish' AND p.post_parent IN ($placeholders)))", ...array_merge( $ids, $ids ) ), ARRAY_A );
    $record_ids = array_map( 'intval', array_column( $records, 'ID' ) );
    $meta_placeholders = implode( ',', array_fill( 0, count( $record_ids ), '%d' ) );
    $meta = $wpdb->get_results( $wpdb->prepare( "SELECT post_id,meta_key,meta_value FROM {$wpdb->postmeta} WHERE post_id IN ($meta_placeholders) AND (meta_key LIKE 'attribute\\_pa\\_%%' OR meta_key IN ('_price','_tax_class','_tax_status','_stock_status'))", ...$record_ids ), ARRAY_A );
    $values = array();
    foreach ( $meta as $row ) { $values[ $row['post_id'] ][ $row['meta_key'] ] = $row['meta_value']; }
    $slugs = array();
    foreach ( $index['filters'] as $def ) { $slugs[ $def['param'] ] = array_column( $def['terms'], 'id', 'slug' ); }
    // Imported variants can still reference a translated slug of the same recorded term.
    // Resolve its existing Italian counterpart without rewriting any taxonomy or variation.
    $language_table = adb_language_table();
    if ( $language_table ) {
        $tax_placeholders = implode( ',', array_fill( 0, count( $taxonomy_params ), '%s' ) );
        $aliases = $wpdb->get_results( $wpdb->prepare( "SELECT tt.taxonomy,t.slug,it_tt.term_id FROM {$wpdb->terms} t JOIN {$wpdb->term_taxonomy} tt ON tt.term_id=t.term_id JOIN `$language_table` tr ON tr.element_id=tt.term_taxonomy_id AND tr.element_type=CONCAT('tax_',tt.taxonomy) JOIN `$language_table` it ON it.trid=tr.trid AND it.element_type=tr.element_type AND it.language_code=%s JOIN {$wpdb->term_taxonomy} it_tt ON it_tt.term_taxonomy_id=it.element_id WHERE tt.taxonomy IN ($tax_placeholders)", ...array_merge( array( 'it' ), array_keys( $taxonomy_params ) ) ), ARRAY_A );
        foreach ( $aliases as $alias ) {
            $param = $taxonomy_params[ $alias['taxonomy'] ];
            if ( in_array( (int) $alias['term_id'], $slugs[ $param ], true ) ) { $slugs[ $param ][ $alias['slug'] ] = (int) $alias['term_id']; }
        }
    }
    $children = array();
    foreach ( $records as $record ) { if ( (int) $record['post_parent'] ) { $children[ $record['post_parent'] ] = true; } }
    foreach ( $records as $record ) {
        $id = (int) $record['ID'];
        $parent = (int) $record['post_parent'];
        if ( ! $parent && isset( $children[ $id ] ) ) { continue; }
        $product_id = $parent ?: $id;
        $stock_status = $record['stock_status'] ?: ( $values[ $id ]['_stock_status'] ?? $values[ $product_id ]['_stock_status'] ?? 'instock' );
        if ( 'yes' === get_option( 'woocommerce_hide_out_of_stock_items' ) && 'outofstock' === $stock_status ) { continue; }
        $facets = $parent_facets[ $product_id ] ?? array();
        if ( $parent ) {
            foreach ( $definitions as $def ) {
                $slug = $values[ $id ][ 'attribute_' . $def['taxonomy'] ] ?? '';
                if ( '' !== $slug ) { $facets[ $def['param'] ] = isset( $slugs[ $def['param'] ][ $slug ] ) ? array( $slugs[ $def['param'] ][ $slug ] ) : array(); }
            }
        }
        $price = isset( $values[ $id ]['_price'] ) && '' !== $values[ $id ]['_price'] && null !== $record['min_price'] ? (float) $record['min_price'] : null;
        if ( null !== $price && wc_tax_enabled() ) {
            $tax_product = new WC_Product();
            $tax_product->set_tax_status( $values[ $product_id ]['_tax_status'] ?? 'taxable' );
            $class = $values[ $id ]['_tax_class'] ?? 'parent';
            $tax_product->set_tax_class( 'parent' === $class ? ( $values[ $product_id ]['_tax_class'] ?? '' ) : $class );
            $price = (float) wc_get_price_to_display( $tax_product, array( 'price' => $price ) );
        }
        $index['rows'][] = array( 'id' => $product_id, 'price' => null === $price ? null : round( $price, wc_get_price_decimals() ), 'stock' => 'outofstock' !== $stock_status, 'f' => $facets );
    }
    return $index;
}

function adb_shop_row_matches( $row, $selection, $except = '' ) {
    static $maps = null;
    if ( null === $maps ) { foreach ( adb_shop_index()['filters'] as $def ) { $maps[ $def['param'] ] = array_column( $def['terms'], 'id', 'slug' ); } }
    foreach ( $selection as $key => $value ) {
        if ( $key === $except ) { continue; }
        if ( 'adb_min_price' === $key && ( null === $row['price'] || $row['price'] < $value ) ) { return false; }
        if ( 'adb_max_price' === $key && ( null === $row['price'] || $row['price'] > $value ) ) { return false; }
        if ( isset( $maps[ $key ] ) && ! in_array( $maps[ $key ][ $value ] ?? -1, $row['f'][ $key ] ?? array(), true ) ) { return false; }
    }
    return true;
}

function adb_shop_matching_ids( $rows, $selection ) {
    $ids = array();
    foreach ( $rows as $row ) { if ( adb_shop_row_matches( $row, $selection ) ) { $ids[ $row['id'] ] = $row['id']; } }
    return array_values( $ids );
}

/** Restrict facet previews to the current taxonomy/search, preserving native archive semantics. */
function adb_shop_context_index() {
    $index = adb_shop_index();
    $term = get_queried_object();
    $context_tax = array();
    if ( $term instanceof WP_Term ) {
        $def = array_values( array_filter( $index['filters'], static function ( $def ) use ( $term ) { return $def['taxonomy'] === $term->taxonomy; } ) );
        if ( $def ) { $index['rows'] = array_values( array_filter( $index['rows'], static function ( $row ) use ( $def, $term ) { return in_array( (int) $term->term_id, $row['f'][ $def[0]['param'] ] ?? array(), true ); } ) ); }
        else { $context_tax = array( array( 'taxonomy' => $term->taxonomy, 'field' => 'term_id', 'terms' => array( $term->term_id ) ) ); }
    }
    if ( is_search() || $context_tax ) {
        $ids = array();
        for ( $page = 1; ; ++$page ) {
            $args = array( 'post_type' => 'product', 'post_status' => 'publish', 'posts_per_page' => 500, 'paged' => $page, 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'ASC', 'no_found_rows' => true, 'adb_language' => 'it', 'suppress_filters' => false, 'update_post_meta_cache' => false, 'update_post_term_cache' => false );
            if ( is_search() ) { $args['s'] = get_search_query( false ); }
            if ( $context_tax ) { $args['tax_query'] = $context_tax; }
            $batch = get_posts( $args ); $ids = array_merge( $ids, $batch );
            if ( count( $batch ) < 500 ) { break; }
        }
        $index['rows'] = array_values( array_filter( $index['rows'], static function ( $row ) use ( $ids ) { return in_array( $row['id'], $ids, true ); } ) );
    }
    return $index;
}

function adb_shop_filter_form() {
    $index = adb_shop_context_index();
    $selection = adb_shop_selection();
    $prices = array_filter( array_column( $index['rows'], 'price' ), 'is_numeric' );
    $min = $prices ? floor( min( $prices ) ) : 0;
    $max = $prices ? ceil( max( $prices ) ) : 1;
    $count = count( adb_shop_matching_ids( $index['rows'], $selection ) );
    $action = adb_catalog_url();
    $term = get_queried_object();
    if ( $term instanceof WP_Term ) { $url = get_term_link( $term ); if ( ! is_wp_error( $url ) ) { $action = $url; } }
    $strings = array( 'all' => __( 'Tutti', 'amicidibacco' ), 'unavailable' => __( 'Non disponibile', 'amicidibacco' ), 'order' => __( 'Ordina', 'amicidibacco' ), 'search' => __( 'Cerca un’opzione', 'amicidibacco' ), 'none' => __( 'Nessuna opzione corrisponde', 'amicidibacco' ), 'count' => __( '%d vini corrispondono alla tua ricerca', 'amicidibacco' ), 'one' => __( '1 vino corrisponde alla tua ricerca', 'amicidibacco' ), 'apply' => __( 'Mostra %d vini', 'amicidibacco' ), 'applyOne' => __( 'Mostra 1 vino', 'amicidibacco' ), 'remove' => __( 'Rimuovi %s', 'amicidibacco' ), 'budget' => __( 'Prezzo', 'amicidibacco' ) );
    ?>
    <form class="adb-shop-filters" method="get" action="<?php echo esc_url( $action ); ?>" aria-label="<?php esc_attr_e( 'Filtra il catalogo', 'amicidibacco' ); ?>" data-shop-filters>
        <div class="adb-shop-filters__heading"><h2><?php esc_html_e( 'Trova il tuo vino', 'amicidibacco' ); ?></h2><a class="adb-shop-reset" href="<?php echo esc_url( $action ); ?>" data-filter-reset><?php echo adb_icon( 'close' ); ?><?php esc_html_e( 'Rimuovi filtri', 'amicidibacco' ); ?></a></div>
        <div class="adb-shop-filters__layout"><div class="adb-shop-filters__fields">
        <?php foreach ( $index['filters'] as $def ) : adb_shop_select( $def, $selection, $index['rows'] ); endforeach; ?>
        </div><fieldset class="adb-price"><legend><?php esc_html_e( 'Fascia di prezzo', 'amicidibacco' ); ?><span><?php echo esc_html( get_woocommerce_currency() ); ?></span></legend>
            <div class="adb-price__numbers"><label><span><?php esc_html_e( 'Da', 'amicidibacco' ); ?></span><input type="number" name="adb_min_price" min="0" max="9999999" step="0.01" placeholder="<?php echo esc_attr( $min ); ?>" value="<?php echo esc_attr( $selection['adb_min_price'] ?? '' ); ?>" aria-label="<?php esc_attr_e( 'Prezzo minimo in franchi', 'amicidibacco' ); ?>"></label><label><span><?php esc_html_e( 'A', 'amicidibacco' ); ?></span><input type="number" name="adb_max_price" min="0" max="9999999" step="0.01" placeholder="<?php echo esc_attr( $max ); ?>" value="<?php echo esc_attr( $selection['adb_max_price'] ?? '' ); ?>" aria-label="<?php esc_attr_e( 'Prezzo massimo in franchi', 'amicidibacco' ); ?>"></label></div>
            <div class="adb-price__histogram" aria-hidden="true" data-price-histogram hidden></div>
            <div class="adb-price__sliders" data-price-sliders hidden><div class="adb-price__track"></div><input type="range" min="0" max="1000" step="1" value="0" aria-label="<?php esc_attr_e( 'Prezzo minimo', 'amicidibacco' ); ?>" data-price-low><input type="range" min="0" max="1000" step="1" value="1000" aria-label="<?php esc_attr_e( 'Prezzo massimo', 'amicidibacco' ); ?>" data-price-high></div>
        </fieldset></div>

        <div class="adb-filter-chips" data-filter-chips></div><div class="adb-shop-filters__footer"><p role="status" aria-live="polite" data-filter-count><?php echo esc_html( sprintf( 1 === $count ? $strings['one'] : $strings['count'], $count ) ); ?></p><button class="adb-button" type="submit"><span data-filter-apply><?php echo esc_html( sprintf( 1 === $count ? $strings['applyOne'] : $strings['apply'], $count ) ); ?></span><?php echo adb_icon(); ?></button></div>
        <?php if ( is_search() ) : ?><input type="hidden" name="s" value="<?php echo esc_attr( get_search_query( false ) ); ?>"><input type="hidden" name="post_type" value="product"><?php endif; ?>
        <?php if ( isset( $_GET['orderby'] ) && is_scalar( $_GET['orderby'] ) ) : ?><input type="hidden" name="orderby" value="<?php echo esc_attr( sanitize_key( wp_unslash( $_GET['orderby'] ) ) ); ?>"><?php endif; ?>
        <script type="application/json" data-filter-index><?php echo wp_json_encode( array( 'filters' => $index['filters'], 'rows' => $index['rows'], 'min' => $min, 'max' => max( $min + 1, $max ), 'strings' => $strings, 'currency' => get_woocommerce_currency(), 'locale' => str_replace( '_', '-', get_locale() ) ), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ); ?></script>
    </form>
    <?php
}

function adb_shop_select( $def, $selection, $rows ) {
    $key = $def['param'];
    $counts = array();
    foreach ( $rows as $row ) { if ( adb_shop_row_matches( $row, $selection, $key ) ) { foreach ( $row['f'][ $key ] ?? array() as $id ) { $counts[ $id ][ $row['id'] ] = true; } } }
    ?><div class="adb-facet"><label for="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $def['label'] ); ?></label><select id="<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $key ); ?>" data-facet><option value=""><?php esc_html_e( 'Tutti', 'amicidibacco' ); ?></option><?php if ( ! empty( $selection[ $key ] ) && ! in_array( $selection[ $key ], array_column( $def['terms'], 'slug' ), true ) ) : ?><option value="<?php echo esc_attr( $selection[ $key ] ); ?>" selected><?php esc_html_e( 'Non disponibile', 'amicidibacco' ); ?></option><?php endif; ?><?php foreach ( $def['terms'] as $term ) : if ( empty( $counts[ $term['id'] ] ) && ( $selection[ $key ] ?? '' ) !== $term['slug'] ) { continue; } ?><option value="<?php echo esc_attr( $term['slug'] ); ?>" <?php selected( $selection[ $key ] ?? '', $term['slug'] ); ?>><?php echo esc_html( $term['name'] ); ?></option><?php endforeach; ?></select></div><?php
}
