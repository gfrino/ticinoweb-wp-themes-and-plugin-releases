(() => {
    'use strict';
    const dialog = document.querySelector('[data-search-dialog]');
    const input = dialog?.querySelector('input[type="search"]');
    const results = dialog?.querySelector('[data-search-results]');
    const status = dialog?.querySelector('#adb-search-status');
    const config = window.adbSearch;
    if (!input || !results || !status || !config || !window.AbortController) return;
    let timer, controller, sequence = 0;
    const reset = () => {
        clearTimeout(timer); controller?.abort(); sequence++;
        results.replaceChildren(); results.removeAttribute('aria-busy');
    };
    const lookup = async () => {
        reset();
        const term = input.value.trim();
        status.textContent = config.hint;
        if (term.length < 2 || !dialog.open) return;
        const current = sequence;
        controller = new AbortController();
        results.setAttribute('aria-busy', 'true'); status.textContent = config.loading;
        try {
            const url = new URL(config.endpoint); url.searchParams.set('term', term);
            const response = await fetch(url, {signal: controller.signal, credentials: 'same-origin', cache: 'no-store'});
            if (!response.ok) throw new Error('search');
            const data = await response.json();
            if (current !== sequence || !dialog.open) return;
            const list = document.createElement('ul'); list.className = 'adb-search-list';
            data.items.forEach(item => {
                const row = document.createElement('li');
                const link = document.createElement('a'); link.className = 'adb-search-result'; link.href = item.url;
                const image = document.createElement('img'); image.src = item.image; image.alt = ''; image.width = 60; image.height = 76; image.decoding = 'async';
                const details = document.createElement('span'); details.className = 'adb-search-result__details';
                const name = document.createElement('strong'); name.textContent = item.name; details.append(name);
                if (item.winery) { const winery = document.createElement('span'); winery.textContent = item.winery; details.append(winery); }
                const price = document.createElement('span'); price.className = 'adb-search-result__price';
                // Only native WooCommerce price markup, allowlisted server-side by this same-origin endpoint.
                price.innerHTML = item.price;
                link.append(image, details, price); row.append(link); list.append(row);
            });
            results.replaceChildren(list);
            status.textContent = data.items.length ? config.results.replace('%d', data.total) : config.empty;
            if (data.items.length) {
                const all = document.createElement('a'); all.className = 'adb-search-all'; all.href = data.all_url;
                all.textContent = config.all.replace('%d', data.total); results.append(all);
            }
        } catch (error) {
            if (error.name !== 'AbortError' && current === sequence) { results.replaceChildren(); status.textContent = config.error; }
        } finally { if (current === sequence) results.removeAttribute('aria-busy'); }
    };
    input.addEventListener('input', () => { reset(); status.textContent = config.hint; if (!input.matches(':invalid')) timer = setTimeout(lookup, 230); });
    input.addEventListener('keydown', event => {
        if (event.key === 'ArrowDown') { const first = results.querySelector('a'); if (first) { event.preventDefault(); first.focus(); } }
    });
    results.addEventListener('keydown', event => {
        if (!['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) return;
        const links = [...results.querySelectorAll('a')]; const index = links.indexOf(document.activeElement);
        if (index < 0) return;
        event.preventDefault();
        if (event.key === 'Home') links[0]?.focus();
        else if (event.key === 'End') links.at(-1)?.focus();
        else if (event.key === 'ArrowUp' && index === 0) input.focus();
        else links[Math.min(links.length - 1, index + (event.key === 'ArrowDown' ? 1 : -1))]?.focus();
    });
    dialog.addEventListener('close', reset);
    new MutationObserver(() => { if (dialog.open) lookup(); }).observe(dialog, {attributes: true, attributeFilter: ['open']});
})();
