<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="mol-skip" href="#main"><?php esc_html_e( 'Vai al contenuto', 'molinarieco-child-theme' ); ?></a>
<?php $logo = function_exists( 'ticinoweb_get_site_logo' ) ? ticinoweb_get_site_logo() : false; ?>
<header class="mol-header"><div class="mol-header-inner">
<a class="mol-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
<?php if ( $logo ) : ?><img src="<?php echo esc_url( $logo ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" width="180" height="62"><?php else : ?><span class="mol-brand-text"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></span><?php endif; ?>
</a>
<nav class="mol-nav" aria-label="<?php esc_attr_e( 'Menu principale', 'molinarieco-child-theme' ); ?>"><?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'fallback_cb' => false ) ); ?></nav>
<details class="mol-mobile-nav"><summary><?php esc_html_e( 'Menu', 'molinarieco-child-theme' ); ?></summary><nav aria-label="<?php esc_attr_e( 'Menu mobile', 'molinarieco-child-theme' ); ?>"><?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'fallback_cb' => false ) ); ?></nav></details>
</div></header>
