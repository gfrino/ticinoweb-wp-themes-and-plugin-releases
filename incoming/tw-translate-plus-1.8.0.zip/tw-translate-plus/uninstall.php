<?php
/**
 * Uninstall handler.
 *
 * By default NOTHING is deleted: manual translations and the global glossary
 * are preserved. Data is removed only when the explicit network setting
 * "Elimina dati alla disinstallazione" was enabled (default off).
 *
 * @package tw-translate-plus
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

/*
 * Release updater mu-plugin: remove it only if no other installed plugin
 * relies on it (same Update URI). Done regardless of the data setting below:
 * it is infrastructure, not data.
 */
if (!function_exists('get_plugins')) {
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
}
$twtr_mu_file = trailingslashit(WPMU_PLUGIN_DIR) . 'tw-release-updater.php';
if (file_exists($twtr_mu_file)) {
    $twtr_mu_users = 0;
    foreach (get_plugins() as $twtr_file => $twtr_data) {
        if ($twtr_file !== 'tw-translate-plus/tw-translate-plus.php'
            && !empty($twtr_data['UpdateURI'])
            && untrailingslashit(strtolower(trim($twtr_data['UpdateURI']))) === 'https://github.com/gfrino/ticinoweb-wp-themes-and-plugin-releases') {
            $twtr_mu_users++;
        }
    }
    if ($twtr_mu_users === 0) {
        @unlink($twtr_mu_file); // phpcs:ignore WordPress.PHP.NoSilencedErrors
    }
}

$twtr_network = get_site_option('twtr_network_settings', array());
$twtr_delete  = is_array($twtr_network) && !empty($twtr_network['delete_on_uninstall']);

if ($twtr_delete) {
    global $wpdb;
    $wpdb->query('DROP TABLE IF EXISTS ' . $wpdb->base_prefix . 'twtr_entries');   // phpcs:ignore WordPress.DB
    $wpdb->query('DROP TABLE IF EXISTS ' . $wpdb->base_prefix . 'twtr_glossary');  // phpcs:ignore WordPress.DB

    delete_site_option('twtr_network_settings');
    delete_site_option('twtr_db_version');
    delete_site_option('twtr_usage');               // network counter of versions < 1.7.0
    delete_site_transient('twtr_google_token');     // network token of versions < 1.7.0

    $twtr_delete_site = function () {
        delete_option('twtr_settings');
        delete_option('twtr_engine');
        delete_option('twtr_usage');
        delete_transient('twtr_google_token');
    };
    if (is_multisite()) {
        $twtr_site_ids = get_sites(array('fields' => 'ids', 'number' => 1000));
        foreach ($twtr_site_ids as $twtr_sid) {
            switch_to_blog($twtr_sid);
            $twtr_delete_site();
            restore_current_blog();
        }
    } else {
        $twtr_delete_site();
    }
}
