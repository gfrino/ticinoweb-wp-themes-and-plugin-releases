<?php
/**
 * Plugin Name: ticinoWEB Release Updater
 * Description: Aggiornamenti automatici dei plugin ticinoWEB dal repo pubblico delle release (gfrino/ticinoweb-wp-themes-and-plugin-releases). Installato e aggiornato automaticamente dai plugin che lo includono: non modificare a mano.
 * Version:     1.0.0
 * Author:      ticinoWEB
 * License:     Proprietary — Licenza d'uso esclusiva ticinoWEB
 *
 * Generico: non elenca nessun plugin. Gestisce OGNI plugin installato il cui
 * header contiene
 *
 *     Update URI: https://github.com/gfrino/ticinoweb-wp-themes-and-plugin-releases
 *
 * e cerca nel repo la release con tag `<slug>-v<versione>` (slug = cartella
 * del plugin) e asset `<slug>-<versione>.zip`. Per aggiungere un plugin al
 * sistema basta quell'header, e includere questo file (vedi sotto): il
 * mu-plugin non va mai toccato.
 *
 * Perche' un mu-plugin: in multisite WordPress cerca e installa gli
 * aggiornamenti dalla bacheca di rete e dal cron del sito principale, dove un
 * plugin attivo solo su alcuni sottositi non viene caricato. Un mu-plugin si
 * carica ovunque. Ogni plugin che usa il sistema porta con se' una copia di
 * questo file (`includes/tw-release-updater.php`), la carica quando e' attivo
 * e alla attivazione / in admin la copia in `wp-content/mu-plugins/` se manca
 * o se quella installata e' piu' vecchia: vince sempre la versione piu'
 * recente fra quelle incluse nei plugin installati.
 *
 * Usa il meccanismo nativo di WordPress per l'header Update URI (filtro
 * `update_plugins_github.com`, WP 5.8+): e' il core a decidere "aggiornamento
 * disponibile" o "aggiornato" e a offrire l'interruttore degli aggiornamenti
 * automatici. Gli aggiornamenti automatici sono ACCESI per questi plugin;
 * `define('TW_RELEASE_AUTO_UPDATE', false);` in wp-config.php li spegne.
 *
 * Si carica solo in admin, cron e WP-CLI: nessun effetto sul frontend.
 *
 * @package ticinoweb-release-updater
 */

if (!defined('ABSPATH')) {
    exit;
}

// Two copies can be included in the same request (mu-plugins + a plugin's
// bundled copy): the first one wins. Conditional declaration on purpose — a
// top-level class would be declared at compile time and fatal the second time.
if (!class_exists('TW_Release_Updater')) {

    final class TW_Release_Updater {

        const VERSION   = '1.0.0';
        const REPO      = 'gfrino/ticinoweb-wp-themes-and-plugin-releases';
        const HOST      = 'github.com';
        const CACHE_KEY = 'tw_release_updater_releases';
        const CACHE_TTL = 12 * HOUR_IN_SECONDS;

        /** @var string Absolute path of the copy that was loaded. */
        public static $file = '';

        /** @var array<string,string>|null plugin file => slug, for plugins managed here. */
        private static $managed = null;

        public static function init($file) {
            self::$file = $file;
            if (!is_admin() && !wp_doing_cron() && !(defined('WP_CLI') && WP_CLI)) {
                return;
            }
            add_filter('update_plugins_' . self::HOST, array(__CLASS__, 'check_update'), 10, 3);
            add_filter('plugins_api', array(__CLASS__, 'plugin_details'), 10, 3);
            add_filter('upgrader_source_selection', array(__CLASS__, 'fix_source_folder'), 10, 4);
            add_filter('auto_update_plugin', array(__CLASS__, 'auto_update'), 10, 2);
            add_action('upgrader_process_complete', array(__CLASS__, 'flush_cache'), 10, 0);
            add_action('load-update-core.php', array(__CLASS__, 'maybe_force_check'));
            add_action('load-plugins.php', array(__CLASS__, 'maybe_force_check'));
        }

        /** @return string Canonical Update URI of this system. */
        public static function update_uri() {
            return 'https://' . self::HOST . '/' . self::REPO;
        }

        /**
         * @param string $uri Value of a plugin's Update URI header.
         * @return bool
         */
        public static function is_ours($uri) {
            return untrailingslashit(strtolower(trim((string) $uri))) === strtolower(self::update_uri());
        }

        /** @return string Slug = plugin folder (or file name for single-file plugins). */
        private static function slug_of($plugin_file) {
            $dir = dirname($plugin_file);
            return $dir !== '.' ? $dir : basename($plugin_file, '.php');
        }

        /**
         * Installed plugins that declare this Update URI.
         *
         * @return array<string,string> plugin file => slug.
         */
        public static function managed_plugins() {
            if (self::$managed === null) {
                if (!function_exists('get_plugins')) {
                    require_once ABSPATH . 'wp-admin/includes/plugin.php';
                }
                self::$managed = array();
                foreach (get_plugins() as $file => $data) {
                    if (!empty($data['UpdateURI']) && self::is_ours($data['UpdateURI'])) {
                        self::$managed[$file] = self::slug_of($file);
                    }
                }
            }
            return self::$managed;
        }

        public static function flush_cache() {
            delete_site_transient(self::CACHE_KEY);
            self::$managed = null;
        }

        public static function maybe_force_check() {
            if (isset($_GET['force-check'])) { // phpcs:ignore WordPress.Security.NonceVerification -- read-only cache flush, same as core.
                delete_site_transient(self::CACHE_KEY);
            }
        }

        /**
         * Latest stable release per slug, from ONE GitHub API call cached for
         * 12 hours network-wide.
         *
         * @return array<string,array{version:string,package:string,url:string,body:string,published:string}>
         */
        public static function releases() {
            $cached = get_site_transient(self::CACHE_KEY);
            if (is_array($cached)) {
                return $cached;
            }

            $response = wp_remote_get(
                'https://api.github.com/repos/' . self::REPO . '/releases?per_page=100',
                array(
                    'timeout' => 8,
                    'headers' => array(
                        'Accept'     => 'application/vnd.github+json',
                        'User-Agent' => 'ticinoWEB-release-updater/' . self::VERSION,
                    ),
                )
            );
            if (is_wp_error($response) || (int) wp_remote_retrieve_response_code($response) !== 200) {
                // Network error or rate limit: retry in an hour, quietly.
                set_site_transient(self::CACHE_KEY, array(), HOUR_IN_SECONDS);
                return array();
            }

            $latest = array();
            foreach ((array) json_decode(wp_remote_retrieve_body($response), true) as $rel) {
                if (!is_array($rel) || !empty($rel['draft']) || !empty($rel['prerelease'])) {
                    continue;
                }
                $tag = isset($rel['tag_name']) ? (string) $rel['tag_name'] : '';
                if (!preg_match('/^(.+)-v(\d+(?:\.\d+){1,3})$/', $tag, $m)) {
                    continue;
                }
                list(, $slug, $version) = $m;
                $package = '';
                foreach ((array) (isset($rel['assets']) ? $rel['assets'] : array()) as $asset) {
                    $name = isset($asset['name']) ? (string) $asset['name'] : '';
                    if ($name === $slug . '-' . $version . '.zip') {
                        $package = (string) $asset['browser_download_url'];
                        break;
                    }
                }
                if ($package === '') {
                    continue;
                }
                if (!isset($latest[$slug]) || version_compare($version, $latest[$slug]['version'], '>')) {
                    $latest[$slug] = array(
                        'version'   => $version,
                        'package'   => $package,
                        'url'       => isset($rel['html_url']) ? (string) $rel['html_url'] : '',
                        'body'      => isset($rel['body']) ? (string) $rel['body'] : '',
                        'published' => isset($rel['published_at']) ? (string) $rel['published_at'] : '',
                    );
                }
            }
            set_site_transient(self::CACHE_KEY, $latest, self::CACHE_TTL);
            return $latest;
        }

        /**
         * `update_plugins_github.com`: answer for our plugins only. Returning
         * the latest version (equal or newer) lets core file the plugin under
         * "response" or "no_update" by itself.
         */
        public static function check_update($update, $plugin_data, $plugin_file) {
            if (empty($plugin_data['UpdateURI']) || !self::is_ours($plugin_data['UpdateURI'])) {
                return $update;
            }
            $slug     = self::slug_of($plugin_file);
            $releases = self::releases();
            if (!isset($releases[$slug])) {
                return $update;
            }
            $rel = $releases[$slug];
            return array(
                'slug'         => $slug,
                'version'      => $rel['version'],
                'url'          => $rel['url'],
                'package'      => $rel['package'],
                'requires_php' => isset($plugin_data['RequiresPHP']) ? $plugin_data['RequiresPHP'] : '',
                'requires'     => isset($plugin_data['RequiresWP']) ? $plugin_data['RequiresWP'] : '',
            );
        }

        /**
         * Automatic updates on by default for our plugins (core sets the
         * update item's id to the plugin's Update URI).
         */
        public static function auto_update($update, $item) {
            if (defined('TW_RELEASE_AUTO_UPDATE') && !TW_RELEASE_AUTO_UPDATE) {
                return $update;
            }
            if (is_object($item) && !empty($item->id) && self::is_ours($item->id)) {
                return true;
            }
            return $update;
        }

        /** "Dettagli versione" popup. */
        public static function plugin_details($result, $action, $args) {
            if ($action !== 'plugin_information' || empty($args->slug)) {
                return $result;
            }
            $file = array_search($args->slug, self::managed_plugins(), true);
            if ($file === false) {
                return $result;
            }
            $releases = self::releases();
            if (!isset($releases[$args->slug])) {
                return $result;
            }
            $rel  = $releases[$args->slug];
            $data = get_plugins()[$file];
            return (object) array(
                'name'          => $data['Name'],
                'slug'          => $args->slug,
                'version'       => $rel['version'],
                'author'        => $data['Author'],
                'homepage'      => 'https://github.com/' . self::REPO,
                'requires'      => $data['RequiresWP'],
                'requires_php'  => $data['RequiresPHP'],
                'last_updated'  => $rel['published'],
                'download_link' => $rel['package'],
                'sections'      => array(
                    'description' => esc_html($data['Description']),
                    'changelog'   => self::format_body($rel['body']),
                ),
            );
        }

        /**
         * The zip must extract to a folder named after the slug: rename it
         * when the asset was built with another folder name.
         */
        public static function fix_source_folder($source, $remote_source, $upgrader, $hook_extra) {
            if (is_wp_error($source) || empty($hook_extra['plugin'])) {
                return $source;
            }
            $managed = self::managed_plugins();
            if (!isset($managed[$hook_extra['plugin']])) {
                return $source;
            }
            $slug = $managed[$hook_extra['plugin']];
            if (basename(untrailingslashit($source)) === $slug) {
                return $source;
            }
            global $wp_filesystem;
            $target = trailingslashit(dirname(untrailingslashit($source))) . $slug;
            if ($wp_filesystem && $wp_filesystem->move($source, $target)) {
                return trailingslashit($target);
            }
            return $source;
        }

        /** Minimal markdown of a release body → safe HTML. */
        private static function format_body($md) {
            $html    = '';
            $in_list = false;
            foreach (preg_split('/\r?\n/', trim((string) $md)) as $line) {
                $line = trim($line);
                if (preg_match('/^[-*]\s+(.*)$/', $line, $m)) {
                    if (!$in_list) { $html .= '<ul>'; $in_list = true; }
                    $html .= '<li>' . self::inline_md($m[1]) . '</li>';
                    continue;
                }
                if ($in_list) { $html .= '</ul>'; $in_list = false; }
                if ($line === '') {
                    continue;
                }
                if (preg_match('/^(#{1,6})\s+(.*)$/', $line, $m)) {
                    $level = min(4, max(3, strlen($m[1])));
                    $html .= "<h{$level}>" . self::inline_md($m[2]) . "</h{$level}>";
                    continue;
                }
                $html .= '<p>' . self::inline_md($line) . '</p>';
            }
            if ($in_list) { $html .= '</ul>'; }
            return $html;
        }

        private static function inline_md($text) {
            $text = esc_html($text);
            $text = preg_replace('/`([^`]+)`/', '<code>$1</code>', $text);
            return preg_replace('/\*\*([^*]+)\*\*/', '<strong>$1</strong>', $text);
        }

        /* ---------- installazione come mu-plugin (chiamata dai plugin) ---------- */

        /**
         * Copy a plugin's bundled copy of this file into mu-plugins when the
         * mu-plugin is missing or older. Atomic (temp file + rename).
         *
         * @param string $bundled Absolute path of the plugin's bundled copy.
         * @return bool|WP_Error True when installed/updated, false when nothing to do.
         */
        public static function install_mu($bundled) {
            if (!defined('WPMU_PLUGIN_DIR') || !is_readable($bundled)) {
                return false;
            }
            $target  = trailingslashit(WPMU_PLUGIN_DIR) . 'tw-release-updater.php';
            $new_ver = get_file_data($bundled, array('v' => 'Version'))['v'];
            if (file_exists($target)) {
                $cur_ver = get_file_data($target, array('v' => 'Version'))['v'];
                if (!version_compare((string) $new_ver, (string) $cur_ver, '>')) {
                    return false;
                }
            }
            if (!wp_mkdir_p(WPMU_PLUGIN_DIR) || !is_writable(WPMU_PLUGIN_DIR)) {
                return new WP_Error('tw_release_updater', 'wp-content/mu-plugins non e\' scrivibile.');
            }
            $tmp = $target . '.tmp-' . wp_generate_password(8, false);
            if (!@copy($bundled, $tmp)) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
                return new WP_Error('tw_release_updater', 'Copia del mu-plugin non riuscita.');
            }
            @chmod($tmp, 0644); // phpcs:ignore WordPress.PHP.NoSilencedErrors
            if (!@rename($tmp, $target)) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
                @unlink($tmp); // phpcs:ignore WordPress.PHP.NoSilencedErrors
                return new WP_Error('tw_release_updater', 'Installazione del mu-plugin non riuscita.');
            }
            if (function_exists('opcache_invalidate')) {
                opcache_invalidate($target, true);
            }
            return true;
        }

        /**
         * Whether the loaded copy is the mu-plugin at the current version.
         *
         * @param string $bundled_version Version of the calling plugin's copy.
         * @return bool
         */
        public static function mu_is_current($bundled_version) {
            return self::$file !== ''
                && wp_normalize_path(dirname(self::$file)) === wp_normalize_path(untrailingslashit(WPMU_PLUGIN_DIR))
                && !version_compare($bundled_version, self::VERSION, '>');
        }
    }

    TW_Release_Updater::init(__FILE__);
}
