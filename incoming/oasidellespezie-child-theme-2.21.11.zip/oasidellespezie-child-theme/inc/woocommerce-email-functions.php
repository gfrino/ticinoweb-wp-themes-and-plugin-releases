<?php
/**
 * WooCommerce email branding and order item photos.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Prefer the current CMS logo while preserving WooCommerce's native fallback.
 *
 * The same resolver is used for the saved setting and for WooCommerce's email
 * preview transient so the preview always matches the emails that are sent.
 *
 * @param mixed $pre_value Value supplied by an earlier pre-option filter.
 * @return mixed CMS logo URL, or the untouched value when the CMS logo is empty.
 */
function oasi_email_logo_from_cms( mixed $pre_value ): mixed {
	$cms_logo = function_exists( 'ticinoweb_get_site_logo' ) ? ticinoweb_get_site_logo() : false;
	$logo_url = is_string( $cms_logo ) ? esc_url_raw( trim( $cms_logo ) ) : '';

	return '' !== $logo_url ? $logo_url : $pre_value;
}

/**
 * Enable the CMS logo only for the WooCommerce header rendering window.
 */
function oasi_email_logo_enable_cms_source(): void {
	add_filter( 'pre_option_woocommerce_email_header_image', 'oasi_email_logo_from_cms', 20 );
	add_filter( 'pre_transient_woocommerce_email_header_image', 'oasi_email_logo_from_cms', 20 );
}

/**
 * Restore native WooCommerce option handling immediately after the header.
 */
function oasi_email_logo_disable_cms_source(): void {
	remove_filter( 'pre_option_woocommerce_email_header_image', 'oasi_email_logo_from_cms', 20 );
	remove_filter( 'pre_transient_woocommerce_email_header_image', 'oasi_email_logo_from_cms', 20 );
}

add_action( 'woocommerce_email_header', 'oasi_email_logo_enable_cms_source', 5 );
add_action( 'woocommerce_email_header', 'oasi_email_logo_disable_cms_source', 15 );

/**
 * Always show product thumbnails in HTML order emails.
 *
 * WooCommerce resolves the photo from the purchased variation or product.
 */
function oasi_email_order_items_show_photos( array $args ): array {
	if ( empty( $args['plain_text'] ) ) {
		$args['show_image'] = true;
	}

	return $args;
}
add_filter( 'woocommerce_email_order_items_args', 'oasi_email_order_items_show_photos' );

/**
 * Let the mail client load the thumbnail without browser-only lazy loading.
 */
function oasi_email_order_item_photo( string $image ): string {
	$tag = new WP_HTML_Tag_Processor( $image );
	if ( $tag->next_tag( 'IMG' ) && 'lazy' === $tag->get_attribute( 'loading' ) ) {
		$tag->remove_attribute( 'loading' );
	}

	return $tag->get_updated_html();
}
add_filter( 'woocommerce_order_item_thumbnail', 'oasi_email_order_item_photo' );
