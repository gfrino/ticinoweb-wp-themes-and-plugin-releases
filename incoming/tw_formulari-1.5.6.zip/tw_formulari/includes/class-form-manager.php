<?php
/**
 * Form Manager orchestrating multi-engine adapters and submission routing.
 *
 * @package TicinoWeb\TWFormulari
 */

namespace TicinoWeb\TWFormulari;

use TicinoWeb\TWFormulari\Adapters\FormAdapterInterface;
use TicinoWeb\TWFormulari\Adapters\FormDiscoveryInterface;
use TicinoWeb\TWFormulari\Adapters\ElementorAdapter;
use TicinoWeb\TWFormulari\Adapters\ContactForm7Adapter;
use TicinoWeb\TWFormulari\Adapters\WPFormsAdapter;
use TicinoWeb\TWFormulari\Adapters\GravityFormsAdapter;
use TicinoWeb\TWFormulari\Adapters\FluentFormsAdapter;
use TicinoWeb\TWFormulari\Adapters\GenericAdapter;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class FormManager {

	/**
	 * Singleton instance.
	 *
	 * @var FormManager|null
	 */
	private static $instance = null;

	/**
	 * Registered adapters.
	 *
	 * @var array<string, FormAdapterInterface>
	 */
	private $adapters = [];

	/**
	 * Get singleton instance.
	 *
	 * @return FormManager
	 */
	public static function get_instance(): FormManager {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		$this->register_default_adapters();
	}

	/**
	 * Register default supported adapters.
	 *
	 * @return void
	 */
	private function register_default_adapters(): void {
		$this->register_adapter( new ElementorAdapter() );
		$this->register_adapter( new ContactForm7Adapter() );
		$this->register_adapter( new WPFormsAdapter() );
		$this->register_adapter( new GravityFormsAdapter() );
		$this->register_adapter( new FluentFormsAdapter() );
		$this->register_adapter( new GenericAdapter() );
	}

	/**
	 * Register an adapter instance.
	 *
	 * @param FormAdapterInterface $adapter
	 * @return void
	 */
	public function register_adapter( FormAdapterInterface $adapter ): void {
		$this->adapters[ $adapter->get_id() ] = $adapter;
	}

	/**
	 * Get all registered adapters.
	 *
	 * @return array<string, FormAdapterInterface>
	 */
	public function get_adapters(): array {
		return $this->adapters;
	}

	/**
	 * Get adapters whose underlying plugins are active on the site.
	 *
	 * @return array<string, FormAdapterInterface>
	 */
	public function get_available_adapters(): array {
		return array_filter( $this->adapters, function( FormAdapterInterface $adapter ) {
			return $adapter->is_available();
		} );
	}

	/**
	 * Sanitize, deduplicate and sort form choices returned by adapters.
	 *
	 * @param array<int, array<string, mixed>> $forms Raw form choices.
	 * @return array<int, array<string, string>>
	 */
	public static function normalize_form_choices( array $forms ): array {
		$normalized = [];
		foreach ( $forms as $form ) {
			if ( ! is_array( $form ) ) {
				continue;
			}
			$id = sanitize_text_field( (string) ( $form['id'] ?? '' ) );
			if ( '' === $id || isset( $normalized[ $id ] ) ) {
				continue;
			}
			$normalized[ $id ] = [
				'id'       => $id,
				'name'     => sanitize_text_field( (string) ( $form['name'] ?? '' ) ),
				'location' => sanitize_text_field( (string) ( $form['location'] ?? '' ) ),
			];
		}
		$normalized = array_values( $normalized );
		usort( $normalized, static function ( array $left, array $right ): int {
			return strnatcasecmp( $left['name'] ?: $left['id'], $right['name'] ?: $right['id'] );
		} );
		return $normalized;
	}

	/**
	 * Get discoverable forms for an engine, using a short-lived admin cache.
	 *
	 * @param string $engine Engine ID or auto.
	 * @param bool   $force_refresh Ignore the cached list.
	 * @return array<int, array<string, string>>
	 */
	public function get_forms_for_engine( string $engine, bool $force_refresh = false ): array {
		$engine = $this->resolve_engine_id( sanitize_key( $engine ) );
		if ( '' === $engine || ! isset( $this->adapters[ $engine ] ) ) {
			return [];
		}

		$adapter = $this->adapters[ $engine ];
		if ( ! $adapter instanceof FormDiscoveryInterface || ! $adapter->is_available() ) {
			return [];
		}

		$cache_key = 'twf_form_choices_' . $engine;
		if ( $force_refresh ) {
			delete_transient( $cache_key );
		} else {
			$cached = get_transient( $cache_key );
			if ( is_array( $cached ) ) {
				return $cached;
			}
		}

		$forms = self::normalize_form_choices( $adapter->get_forms() );
		set_transient( $cache_key, $forms, 5 * MINUTE_IN_SECONDS );
		return $forms;
	}

	/**
	 * Builds a fresh privacy-safe preview from the selected form schema.
	 * Schema reads are intentionally not cached, so form edits appear immediately.
	 *
	 * @param string $engine Configured engine ID or auto.
	 * @param string $form_id Selected form ID.
	 * @return array<string, mixed>
	 */
	public function get_preview_data_for_form( string $engine, string $form_id ): array {
		$engine  = $this->resolve_engine_id( sanitize_key( $engine ) );
		$form_id = sanitize_text_field( $form_id );
		if ( '' === $engine || '' === $form_id || ! isset( $this->adapters[ $engine ] ) ) {
			throw new \RuntimeException( 'Formulario non disponibile.' );
		}
		$adapter = $this->adapters[ $engine ];
		if ( ! $adapter instanceof FormDiscoveryInterface ) {
			throw new \RuntimeException( 'Il sistema selezionato non espone lo schema del formulario.' );
		}
		$schema = $adapter->get_form_schema( $form_id );
		if ( empty( $schema ) ) {
			throw new \RuntimeException( 'Il formulario selezionato non contiene campi leggibili.' );
		}
		return DataNormalizer::preview_from_schema( $schema );
	}

	/**
	 * Resolve automatic mode only when exactly one discoverable builder is active.
	 *
	 * @param string $engine Engine setting.
	 * @return string
	 */
	public function resolve_engine_id( string $engine ): string {
		if ( 'auto' !== $engine ) {
			return $engine;
		}
		$available = array_filter( $this->get_available_adapters(), static function ( FormAdapterInterface $adapter ): bool {
			return 'generic' !== $adapter->get_id();
		} );
		return 1 === count( $available ) ? (string) array_key_first( $available ) : '';
	}

	/**
	 * Initializes all active adapter hooks.
	 *
	 * @return void
	 */
	public function init_hooks(): void {
		$form_settings = Settings::get_form_settings();
		$active_engine = $form_settings['active_engine'] ?? 'auto';
		if ( 'auto' === $active_engine ) {
			$available = array_filter( $this->get_available_adapters(), static function ( FormAdapterInterface $adapter ): bool {
				return 'generic' !== $adapter->get_id();
			} );
			if ( 1 !== count( $available ) ) {
				return;
			}
			reset( $available )->register_hooks();
			return;
		}

		foreach ( $this->adapters as $id => $adapter ) {
			if ( $active_engine === $id && ( 'generic' === $id || $adapter->is_available() ) ) {
				$adapter->register_hooks();
			}
		}
	}

	/**
	 * Main processing gateway for form submissions coming from any adapter.
	 *
	 * @param array<string, mixed> $payload Submission payload.
	 * @return void
	 */
	public function handle_submission( array $payload ): void {
		$engine    = sanitize_key( $payload['engine'] ?? '' );
		$form_id   = sanitize_text_field( (string) ( $payload['form_id'] ?? '' ) );
		$form_name = sanitize_text_field( (string) ( $payload['form_name'] ?? '' ) );
		$submission_id = sanitize_text_field( (string) ( $payload['submission_id'] ?? '' ) );
		$post_id   = (int) ( $payload['post_id'] ?? 0 );
		$fields    = (array) ( $payload['fields'] ?? [] );
		$schema    = isset( $payload['schema'] ) && is_array( $payload['schema'] ) ? $payload['schema'] : [];
		if ( ! self::payload_within_limits( $fields ) ) {
			return;
		}

		$form_settings = Settings::get_form_settings();

		// Verify target form matching
		if ( ! $this->matches_target_form( 'generic_dynamic', $form_settings, $engine, $form_id, $form_name, $post_id ) ) {
			return;
		}

		$lock_payload = compact( 'engine', 'form_id', 'submission_id', 'fields' );
		if ( ! self::claim_submission( $lock_payload ) ) {
			return;
		}

		try {
			// Only form builders with a server-side schema may declare email
			// recipients. Raw generic POST metadata is controlled by the visitor.
			$data = DataNormalizer::normalize_generic( $fields, '', 'generic' !== $engine, $schema );
			$pdf_path = PdfGenerator::generate_file( $data );
			$sent = EmailService::send_admission_email( $data, $pdf_path );
			Logger::log( $sent ? 'completed' : 'delivery_failed', $sent ? 'success' : 'error', $sent ? 'Ultimo formulario elaborato e inviato.' : 'Invio non riuscito. Controllare la configurazione email.' );
			if ( $sent ) {
				self::complete_submission( $lock_payload );
			} else {
				self::release_submission( $lock_payload );
			}

		} catch ( \Throwable $e ) {
			self::release_submission( $lock_payload );
			Logger::log( 'process_error', 'error', 'Elaborazione non riuscita. Verificare configurazione e log del server.' );
		}
	}

	/**
	 * Prevents oversized builder payloads from reaching PDF generation.
	 *
	 * @param array<string|int, mixed> $fields Submitted fields.
	 * @return bool
	 */
	public static function payload_within_limits( array $fields ): bool {
		if ( count( $fields, COUNT_RECURSIVE ) > 300 ) {
			return false;
		}
		$encoded = wp_json_encode( $fields );
		return is_string( $encoded ) && strlen( $encoded ) <= 262144;
	}

	/**
	 * Claims a short-lived submission lock.
	 *
	 * @param array<string, mixed> $payload Submission identity and fields.
	 * @return bool
	 */
	public static function claim_submission( array $payload ): bool {
		$key = self::submission_lock_key( $payload );
		$now = time();
		if ( (int) get_option( $key, 0 ) < $now ) {
			delete_option( $key );
		}
		$ttl = empty( $payload['submission_id'] ) ? 30 * MINUTE_IN_SECONDS : 5 * MINUTE_IN_SECONDS;
		return add_option( $key, $now + $ttl, '', false );
	}

	/**
	 * Keeps a brief success marker for adapters that do not expose entry IDs.
	 *
	 * @param array<string, mixed> $payload Submission identity and fields.
	 * @return void
	 */
	public static function complete_submission( array $payload ): void {
		if ( empty( $payload['submission_id'] ) ) {
			update_option( self::submission_lock_key( $payload ), time() + 5, false );
		}
	}

	/**
	 * Releases a lock so a failed delivery can be retried.
	 *
	 * @param array<string, mixed> $payload Submission identity and fields.
	 * @return void
	 */
	public static function release_submission( array $payload ): void {
		delete_option( self::submission_lock_key( $payload ) );
	}

	/** @param array<string, mixed> $payload @return string */
	private static function submission_lock_key( array $payload ): string {
		$field_hash = hash( 'sha256', (string) wp_json_encode( $payload['fields'] ?? [] ) );
		$identity   = ! empty( $payload['submission_id'] ) ? (string) $payload['submission_id'] . '|' . $field_hash : $field_hash;
		return 'twf_submission_lock_' . hash( 'sha256', (string) ( $payload['engine'] ?? '' ) . '|' . (string) ( $payload['form_id'] ?? '' ) . '|' . $identity );
	}

	/**
	 * Evaluates if the incoming submission should be handled by tw_formulari.
	 *
	 * @param string               $profile_mode Legacy argument retained for compatibility.
	 * @param array<string, mixed> $settings
	 * @param string               $engine
	 * @param string               $form_id
	 * @param string               $form_name
	 * @param int                  $post_id
	 * @return bool
	 */
	public function matches_target_form( string $profile_mode, array $settings, string $engine, string $form_id, string $form_name, int $post_id ): bool {
		$target_form_id = trim( (string) ( $settings['target_form_id'] ?? '' ) );
		$active_engine  = sanitize_key( (string) ( $settings['active_engine'] ?? 'auto' ) );
		if ( 'auto' === $active_engine ) {
			$available = array_keys( array_filter( $this->get_available_adapters(), static function ( FormAdapterInterface $adapter ): bool {
				return 'generic' !== $adapter->get_id();
			} ) );
			if ( 1 !== count( $available ) || $engine !== reset( $available ) ) {
				return false;
			}
		}
		if ( 'auto' !== $active_engine && ! hash_equals( $active_engine, $engine ) ) {
			return false;
		}
		if ( '' !== $target_form_id && hash_equals( $target_form_id, $form_id ) ) {
			return true;
		}

		return false;
	}
}
