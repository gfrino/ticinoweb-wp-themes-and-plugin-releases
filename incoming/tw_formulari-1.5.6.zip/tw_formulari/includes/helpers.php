<?php
/**
 * Utility helper functions for tw_formulari.
 *
 * @package TicinoWeb\TWFormulari
 */

namespace TicinoWeb\TWFormulari;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Returns the temporary directory used for generated PDFs.
 *
 * @return string Directory path with trailing slash.
 */
function get_temp_pdf_dir(): string {
	$temp_dir = trailingslashit( get_temp_dir() ) . 'tw-formulari-' . substr( hash( 'sha256', wp_salt( 'auth' ) . ABSPATH ), 0, 16 ) . '/';

	if ( is_link( $temp_dir ) ) {
		throw new \RuntimeException( 'La directory temporanea PDF non è sicura.' );
	}

	if ( ! file_exists( $temp_dir ) ) {
		if ( ! wp_mkdir_p( $temp_dir ) ) {
			throw new \RuntimeException( 'Impossibile creare la directory temporanea PDF.' );
		}
		@chmod( $temp_dir, 0700 );
	}

	if ( ! is_dir( $temp_dir ) || ! is_writable( $temp_dir ) ) {
		throw new \RuntimeException( 'La directory temporanea PDF non è scrivibile.' );
	}

	return $temp_dir;
}

/**
 * Normalizes and sanitizes a string for use in a file name.
 *
 * @param string $string Raw string.
 * @return string Sanitized ASCII slug.
 */
function sanitize_file_slug( string $string ): string {
	$string = sanitize_title( $string );
	$string = preg_replace( '/[^a-z0-9-_]/i', '', $string );
	return trim( (string) $string, '-_' );
}

/**
 * Deletes any orphaned temporary PDF files older than a given time limit.
 *
 * @param int $max_age_seconds Maximum file age before deletion. Defaults to 3600 (1 hour).
 * @return int Number of files deleted.
 */
function clean_orphaned_temp_pdfs( int $max_age_seconds = 3600 ): int {
	$temp_dir = get_temp_pdf_dir();
	$deleted  = 0;

	if ( ! is_dir( $temp_dir ) ) {
		return 0;
	}

	$files = glob( $temp_dir . '*.pdf' );
	if ( empty( $files ) ) {
		return 0;
	}

	$now = time();
	foreach ( $files as $file ) {
		if ( is_file( $file ) ) {
			$file_mtime = @filemtime( $file );
			if ( false !== $file_mtime && ( $now - $file_mtime ) > $max_age_seconds ) {
				if ( @unlink( $file ) ) {
					$deleted++;
				}
			}
		}
	}

	return $deleted;
}

/**
 * Removes PDF files left by versions that stored temporary data in uploads.
 *
 * @return int Number of deleted PDF files.
 */
function clean_legacy_temp_pdfs(): int {
	$uploads = wp_upload_dir();
	$dir     = trailingslashit( (string) ( $uploads['basedir'] ?? '' ) ) . 'tw_formulari_temp/';
	if ( empty( $uploads['basedir'] ) || ! is_dir( $dir ) || is_link( $dir ) ) {
		return 0;
	}

	$deleted = 0;
	foreach ( glob( $dir . '*.pdf' ) ?: [] as $file ) {
		if ( is_file( $file ) && @unlink( $file ) ) {
			++$deleted;
		}
	}
	foreach ( [ 'index.php', '.htaccess' ] as $control_file ) {
		if ( is_file( $dir . $control_file ) ) {
			@unlink( $dir . $control_file );
		}
	}
	@rmdir( $dir );
	return $deleted;
}

/**
 * Removes expired atomic submission locks and rate-limit slots.
 *
 * @return int Number of deleted options.
 */
function clean_expired_security_options(): int {
	global $wpdb;
	if ( ! isset( $wpdb ) || ! is_object( $wpdb ) || empty( $wpdb->options ) ) {
		return 0;
	}

	$submission_like = $wpdb->esc_like( 'twf_submission_lock_' ) . '%';
	$rate_like       = $wpdb->esc_like( 'twf_rate_slot_' ) . '%';
	$query           = $wpdb->prepare(
		"SELECT option_name FROM {$wpdb->options} WHERE (option_name LIKE %s OR option_name LIKE %s) AND CAST(option_value AS UNSIGNED) < %d",
		$submission_like,
		$rate_like,
		time()
	);
	$deleted = 0;
	foreach ( $wpdb->get_col( $query ) ?: [] as $option_name ) {
		if ( delete_option( $option_name ) ) {
			++$deleted;
		}
	}
	return $deleted;
}

/**
 * Checks if a string looks like a calendar date.
 *
 * @param string $string Candidate string.
 * @return bool True if recognized as a date, false otherwise.
 */
function is_date_string( string $string ): bool {
	$string = trim( $string );
	if ( empty( $string ) || '—' === $string ) {
		return false;
	}

	// 1. Year first: YYYY-MM-DD, YYYY/MM/DD, YYYY.MM.DD with optional time
	if ( preg_match( '/^(\d{4})[-\/\.](\d{1,2})[-\/\.](\d{1,2})(?:[T\s](\d{1,2}):(\d{2})(?::(\d{2}))?)?$/', $string, $m ) ) {
		$year  = (int) $m[1];
		$month = (int) $m[2];
		$day   = (int) $m[3];
		if ( $year >= 1900 && $year <= 2100 && checkdate( $month, $day, $year ) ) {
			return true;
		}
	}

	// 2. Day or Month first: DD-MM-YYYY, DD/MM/YYYY, DD.MM.YYYY or MM/DD/YYYY with optional time
	if ( preg_match( '/^(\d{1,2})[-\/\.](\d{1,2})[-\/\.](\d{4})(?:[T\s](\d{1,2}):(\d{2})(?::(\d{2}))?)?$/', $string, $m ) ) {
		$part1 = (int) $m[1];
		$part2 = (int) $m[2];
		$year  = (int) $m[3];
		if ( $year >= 1900 && $year <= 2100 ) {
			if ( checkdate( $part2, $part1, $year ) || checkdate( $part1, $part2, $year ) ) {
				return true;
			}
		}
	}

	return false;
}

/**
 * Formats a date string safely to DD/MM/YYYY (gg/mm/aaaa) and never American year-first.
 *
 * @param string $date_str Raw date string.
 * @return string Formatted date (gg/mm/aaaa or gg/mm/aaaa HH:ii) or original string if not parseable.
 */
function format_display_date( string $date_str ): string {
	$date_str = trim( $date_str );
	if ( empty( $date_str ) || '—' === $date_str ) {
		return '—';
	}

	// Helper for time suffix: non-zero time preserved as ' HH:ii'
	$extract_time = static function ( array $m ): string {
		if ( ! empty( $m[4] ) || ( isset( $m[4] ) && '0' === $m[4] ) ) {
			$hour = (int) $m[4];
			$min  = isset( $m[5] ) ? (int) $m[5] : 0;
			$sec  = isset( $m[6] ) ? (int) $m[6] : 0;
			if ( $hour > 0 || $min > 0 || $sec > 0 ) {
				return sprintf( ' %02d:%02d', $hour, $min );
			}
		}
		return '';
	};

	// 1. Year first (American/ISO: YYYY-MM-DD, YYYY/MM/DD, YYYY.MM.DD) -> always convert to gg/mm/aaaa
	if ( preg_match( '/^(\d{4})[-\/\.](\d{1,2})[-\/\.](\d{1,2})(?:[T\s](\d{1,2}):(\d{2})(?::(\d{2}))?)?$/', $date_str, $m ) ) {
		$year  = (int) $m[1];
		$month = (int) $m[2];
		$day   = (int) $m[3];
		if ( checkdate( $month, $day, $year ) ) {
			return sprintf( '%02d/%02d/%04d', $day, $month, $year ) . $extract_time( $m );
		}
	}

	// 2. Day or Month first: DD-MM-YYYY, DD.MM.YYYY, DD/MM/YYYY, or American MM/DD/YYYY
	if ( preg_match( '/^(\d{1,2})[-\/\.](\d{1,2})[-\/\.](\d{4})(?:[T\s](\d{1,2}):(\d{2})(?::(\d{2}))?)?$/', $date_str, $m ) ) {
		$part1 = (int) $m[1];
		$part2 = (int) $m[2];
		$year  = (int) $m[3];
		$time  = $extract_time( $m );

		// Prioritize European: part1 = day, part2 = month
		if ( checkdate( $part2, $part1, $year ) ) {
			return sprintf( '%02d/%02d/%04d', $part1, $part2, $year ) . $time;
		}

		// Fallback American: part1 = month, part2 = day (e.g. 09/30/2026)
		if ( checkdate( $part1, $part2, $year ) ) {
			return sprintf( '%02d/%02d/%04d', $part2, $part1, $year ) . $time;
		}
	}

	// 3. Fallback for textual dates via strtotime (if plausible year between 1900 and 2100)
	$timestamp = strtotime( $date_str );
	if ( false !== $timestamp && $timestamp > 0 ) {
		$year = (int) gmdate( 'Y', $timestamp );
		if ( $year >= 1900 && $year <= 2100 ) {
			if ( preg_match( '/\b\d{1,2}:\d{2}\b/', $date_str ) ) {
				return date_i18n( 'd/m/Y H:i', $timestamp );
			}
			return date_i18n( 'd/m/Y', $timestamp );
		}
	}

	return esc_html( $date_str );
}
