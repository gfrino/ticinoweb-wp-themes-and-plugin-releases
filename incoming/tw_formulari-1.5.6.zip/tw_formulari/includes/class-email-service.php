<?php
/**
 * Universal Email delivery service for tw_formulari.
 *
 * @package TicinoWeb\TWFormulari
 */

namespace TicinoWeb\TWFormulari;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EmailService {

	/**
	 * Send confirmation email with PDF attachment to configured recipients.
	 *
	 * Ensures the temporary PDF file is safely deleted immediately after sending.
	 *
	 * @param array<string, mixed> $data Normalized form data.
	 * @param string               $pdf_filepath Absolute path to the generated temporary PDF file.
	 * @return bool True if mail was accepted for delivery, false otherwise.
	 */
	public static function send_admission_email( array $data, string $pdf_filepath ): bool {
		if ( ! self::is_managed_temp_file( $pdf_filepath ) || filesize( $pdf_filepath ) <= 0 ) {
			return false;
		}

		$sent = false;
		try {
			$email_settings = Settings::get_email_settings();
			$pdf_settings   = Settings::get_pdf_settings();
			$recipients     = self::determine_recipients( $data, $email_settings );
			if ( empty( $recipients ) ) {
				return false;
			}

			$sender_name  = ! empty( $email_settings['sender_name'] ) ? $email_settings['sender_name'] : ( $pdf_settings['facility_name'] ?? get_bloginfo( 'name' ) );
			$sender_email = ! empty( $email_settings['sender_email'] ) && is_email( $email_settings['sender_email'] ) ? $email_settings['sender_email'] : get_option( 'admin_email' );
			$subject      = ! empty( $email_settings['email_subject'] ) ? $email_settings['email_subject'] : 'Richiesta ricevuta — ' . $sender_name;
			$headers      = [
				'Content-Type: text/html; charset=UTF-8',
				sprintf( 'From: %s <%s>', esc_attr( $sender_name ), sanitize_email( $sender_email ) ),
			];
			$message = self::render_email_body( $data, $email_settings, $pdf_settings );
			$sent    = true;
			foreach ( $recipients as $recipient ) {
				if ( ! wp_mail( $recipient, $subject, $message, $headers, [ $pdf_filepath ] ) ) {
					$sent = false;
				}
			}
		} catch ( \Throwable $e ) {
			$sent = false;
		} finally {
			// Guarantee immediate deletion of the temporary PDF file for privacy compliance
			self::cleanup_temp_file( $pdf_filepath );
		}

		return $sent;
	}

	/**
	 * Resolves recipient email addresses based on settings and available data.
	 *
	 * @param array<string, mixed> $data Normalized form data.
	 * @param array<string, mixed> $settings Email settings.
	 * @return array<int, string> Array of unique, valid recipient email addresses.
	 */
	public static function determine_recipients( array $data, array $settings ): array {
		$recipients = [];
		$detected   = isset( $data['recipient_emails'] ) && is_array( $data['recipient_emails'] ) ? $data['recipient_emails'] : [];

		// Normalized submissions expose every email field automatically. The
		// fallback keeps compatibility with data normalized by older versions.
		if ( empty( $detected ) ) {
			$detected[] = $data['client_email'] ?? '';
		}

		foreach ( $detected as $email ) {
			self::append_recipient( $recipients, (string) $email );
		}

		if ( ! empty( $settings['send_facility'] ) && ! empty( $settings['facility_email'] ) ) {
			self::append_recipient( $recipients, (string) $settings['facility_email'] );
		}

		return $recipients;
	}

	/**
	 * Adds a valid address only once without exposing recipient addresses to
	 * one another. Comparison is case-insensitive.
	 *
	 * @param array<int, string> $recipients Recipient list passed by reference.
	 * @param string             $candidate Candidate address.
	 * @return void
	 */
	private static function append_recipient( array &$recipients, string $candidate ): void {
		$candidate = trim( $candidate );
		if ( ! is_email( $candidate ) ) {
			return;
		}
		$email = sanitize_email( $candidate );
		foreach ( $recipients as $existing ) {
			if ( 0 === strcasecmp( $existing, $email ) ) {
				return;
			}
		}
		$recipients[] = $email;
	}

	/**
	 * Renders HTML email template.
	 *
	 * @param array<string, mixed> $data Normalized form data.
	 * @param array<string, mixed> $settings Email settings.
	 * @param array<string, mixed> $pdf_settings PDF settings.
	 * @return string Rendered HTML.
	 */
	private static function render_email_body( array $data, array $settings, array $pdf_settings ): string {
		ob_start();
		$template_file = TW_FORMULARI_PATH . 'templates/email/generic-confirmation.php';

		if ( file_exists( $template_file ) ) {
			require $template_file;
		}
		return ob_get_clean() ?: '';
	}

	/**
	 * Safely unlinks a temporary file.
	 *
	 * @param string $filepath Path to temporary file.
	 * @return void
	 */
	private static function cleanup_temp_file( string $filepath ): void {
		if ( ! self::is_managed_temp_file( $filepath ) ) {
			return;
		}
		$file = realpath( $filepath );
		@unlink( $file );
	}

	/** @param string $filepath @return bool */
	private static function is_managed_temp_file( string $filepath ): bool {
		if ( empty( $filepath ) || ! is_file( $filepath ) ) {
			return false;
		}
		$root = realpath( get_temp_pdf_dir() );
		$file = realpath( $filepath );
		return false !== $root && false !== $file && 0 === strpos( $file, trailingslashit( $root ) );
	}
}
