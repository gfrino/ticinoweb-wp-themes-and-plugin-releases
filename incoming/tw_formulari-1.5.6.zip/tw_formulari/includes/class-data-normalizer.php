<?php
/**
 * Universal Data normalizer for any form submission.
 *
 * @package TicinoWeb\TWFormulari
 */

namespace TicinoWeb\TWFormulari;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DataNormalizer {

	/**
	 * Normalizes raw submitted fields according to the active profile mode.
	 *
	 * @param array<string, mixed> $raw_fields Raw fields input.
	 * @param string               $profile_mode Legacy argument retained for backward compatibility.
	 * @param string               $email_field Legacy argument, retained for backward compatibility and ignored.
	 * @param bool                 $detect_recipients Whether field type metadata is trusted for delivery.
	 * @return array<string, mixed> Normalized data structure.
	 */
	public static function normalize( array $raw_fields, string $profile_mode = 'generic_dynamic', string $email_field = '', bool $detect_recipients = true ): array {
		return self::normalize_generic( $raw_fields, $email_field, $detect_recipients );
	}

	/**
	 * Builds privacy-safe preview data from the current form schema.
	 *
	 * @param array<int, array<string, mixed>> $schema Normalized field definitions.
	 * @return array<string, mixed> Generic preview dataset.
	 */
	public static function preview_from_schema( array $schema ): array {
		$fields = [];
		foreach ( array_slice( $schema, 0, 100 ) as $index => $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}
			$id      = sanitize_text_field( (string) ( $field['id'] ?? 'field_' . $index ) );
			$label   = sanitize_text_field( (string) ( $field['label'] ?? $id ) );
			$type    = sanitize_key( (string) ( $field['type'] ?? 'text' ) );
			$options = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : [];
			if ( '' === $id || '' === $label ) {
				continue;
			}
			if ( self::is_section_type( $type ) ) {
				continue;
			}

			$value = self::preview_value_for_type( $type, $options );
			$fields[ $id ] = [
				'id'    => $id,
				'title' => $label,
				'type'  => $type,
				'value' => $value,
			];
		}

		return self::normalize_generic( $fields, '', false, $schema );
	}

	/**
	 * @param string             $type Field type.
	 * @param array<int, mixed>  $options Selectable values.
	 * @return string
	 */
	private static function preview_value_for_type( string $type, array $options ): string {
		if ( in_array( $type, [ 'email', 'email_address', 'emailaddress', 'mail' ], true ) ) {
			return 'nome@example.com';
		}
		if ( in_array( $type, [ 'tel', 'phone', 'telephone' ], true ) ) {
			return '+41 79 000 00 00';
		}
		if ( in_array( $type, [ 'date', 'datepicker', 'datetime', 'date-time', 'date_time' ], true ) ) {
			return date_i18n( 'd/m/Y' );
		}
		if ( in_array( $type, [ 'checkbox', 'acceptance', 'consent' ], true ) ) {
			return '✓ Selezionato';
		}
		if ( ! empty( $options ) ) {
			return sanitize_text_field( (string) reset( $options ) );
		}
		if ( in_array( $type, [ 'textarea', 'wysiwyg' ], true ) ) {
			return 'Testo dimostrativo del campo.';
		}
		return 'Valore dimostrativo';
	}


	/**
	 * Normalizes any generic form submission dynamically.
	 *
	 * @param array<string, mixed> $raw_fields
	 * @param string               $email_field Legacy argument, retained for backward compatibility and ignored.
	 * @param bool                 $detect_recipients Whether field type metadata is trusted for delivery.
	 * @param array<int, array<string, mixed>> $schema Ordered form schema with optional section markers.
	 * @return array<string, mixed>
	 */
	public static function normalize_generic( array $raw_fields, string $email_field = '', bool $detect_recipients = true, array $schema = [] ): array {
		$fields_list     = [];
		$client_name     = '';
		$client_phone    = '';
		$submission_date = current_time( 'd/m/Y H:i' );

		// Skip internal or system fields
		$ignore_keys = [
			'action', 'form_id', 'post_id', 'queried_id', 'referer_title',
			'_wpcf7', '_wpcf7_version', '_wpcf7_locale', '_wpcf7_unit_tag', '_wpcf7_container_post',
			'twf_form_id', 'twf_form_name', '_wpnonce',
		];

		$flattened   = self::flatten_fields( $raw_fields, $ignore_keys );
		$fields_list = array_slice( $flattened, 0, 100 );

		foreach ( $fields_list as $field ) {
			$raw_key       = $field['key'];
			$raw_label     = $field['label'];
			$formatted_val = $field['value'];

			// Auto-detect display information if possible.
			$lower_k = strtolower( $raw_key . ' ' . $raw_label );
			if ( empty( $client_name ) && ( strpos( $lower_k, 'nome' ) !== false || strpos( $lower_k, 'name' ) !== false || strpos( $lower_k, 'contatto' ) !== false || strpos( $lower_k, 'persona' ) !== false ) ) {
				if ( $formatted_val !== '—' ) {
					$client_name = $formatted_val;
				}
			}
			if ( empty( $client_phone ) && ( strpos( $lower_k, 'tel' ) !== false || strpos( $lower_k, 'phone' ) !== false ) ) {
				if ( $formatted_val !== '—' ) {
					$client_phone = $formatted_val;
				}
			}
		}

		$recipient_emails = $detect_recipients ? self::extract_recipient_emails( $raw_fields ) : [];
		$client_email     = $recipient_emails[0] ?? '';

		return [
			'_mode'           => 'generic_dynamic',
			'submission_date' => $submission_date,
			'client_name'     => $client_name ?: 'Richiedente',
			'client_email'    => $client_email,
			'recipient_emails' => $recipient_emails,
			'client_phone'    => $client_phone,
			'fields'          => $fields_list,
			'sections'        => self::organize_sections( $fields_list, $schema ),
		];
	}

	/**
	 * Rebuilds the visual form structure from ordered schema markers.
	 * Submitted values remain the source of truth; schema is used only for
	 * ordering and presentation.
	 *
	 * @param array<int, array<string, string>> $fields Normalized display fields.
	 * @param array<int, array<string, mixed>>  $schema Ordered form schema.
	 * @return array<int, array{title:string,fields:array<int, array<string, string>>}>
	 */
	public static function organize_sections( array $fields, array $schema = [] ): array {
		if ( empty( $fields ) ) {
			return [];
		}

		$field_indexes           = [];
		$canonical_field_indexes = [];
		foreach ( $fields as $index => $field ) {
			$id = sanitize_text_field( (string) ( $field['id'] ?? $field['key'] ?? '' ) );
			if ( '' !== $id ) {
				$field_indexes[ $id ][] = $index;
				$canonical_field_indexes[ self::canonical_field_path( $id ) ][] = $index;
			}
		}

		$sections       = [];
		$current_index  = null;
		$used           = [];
		$pending_fields = [];

		foreach ( array_slice( $schema, 0, 120 ) as $schema_entry ) {
			if ( ! is_array( $schema_entry ) ) {
				continue;
			}
			$type = sanitize_key( (string) ( $schema_entry['type'] ?? 'text' ) );
			if ( self::is_section_type( $type ) ) {
				$title = sanitize_text_field( (string) ( $schema_entry['label'] ?? '' ) );
				$sections[] = [
					'title'  => $title ?: sprintf( 'Sezione %d', count( $sections ) + 1 ),
					'fields' => [],
				];
				$current_index = count( $sections ) - 1;
				if ( ! empty( $pending_fields ) ) {
					array_splice( $sections, $current_index, 0, [ [
						'title'  => 'Dati iniziali',
						'fields' => $pending_fields,
					] ] );
					++$current_index;
					$pending_fields = [];
				}
				continue;
			}

			$id = sanitize_text_field( (string) ( $schema_entry['id'] ?? '' ) );
			if ( '' === $id ) {
				continue;
			}

			$matched_indexes = [];
			if ( ! empty( $field_indexes[ $id ] ) ) {
				do {
					$field_index = array_shift( $field_indexes[ $id ] );
				} while ( null !== $field_index && isset( $used[ $field_index ] ) && ! empty( $field_indexes[ $id ] ) );
				if ( null !== $field_index && ! isset( $used[ $field_index ] ) ) {
					$matched_indexes[] = $field_index;
				}
			} elseif ( ! empty( $canonical_field_indexes[ self::canonical_field_path( $id ) ] ) ) {
				foreach ( $canonical_field_indexes[ self::canonical_field_path( $id ) ] as $field_index ) {
					if ( ! isset( $used[ $field_index ] ) ) {
						$matched_indexes[] = $field_index;
					}
				}
			} else {
				$prefix = self::canonical_field_path( $id ) . '.';
				foreach ( $fields as $field_index => $field ) {
					$field_id = sanitize_text_field( (string) ( $field['id'] ?? $field['key'] ?? '' ) );
					if ( ! isset( $used[ $field_index ] ) && 0 === strpos( self::canonical_field_path( $field_id ), $prefix ) ) {
						$matched_indexes[] = $field_index;
					}
				}
			}

			foreach ( $matched_indexes as $field_index ) {
				$used[ $field_index ] = true;
				if ( null === $current_index ) {
					$pending_fields[] = $fields[ $field_index ];
				} else {
					$sections[ $current_index ]['fields'][] = $fields[ $field_index ];
				}
			}
		}

		$remaining = $pending_fields;
		foreach ( $fields as $index => $field ) {
			if ( ! isset( $used[ $index ] ) ) {
				$remaining[] = $field;
			}
		}

		$sections = array_values( array_filter( $sections, static function ( array $section ): bool {
			return ! empty( $section['fields'] );
		} ) );

		if ( ! empty( $sections ) ) {
			if ( ! empty( $remaining ) ) {
				$sections[] = [ 'title' => 'Altri dati', 'fields' => $remaining ];
			}
			return $sections;
		}

		return self::build_balanced_fallback_sections( $remaining ?: $fields );
	}

	/**
	 * Removes numeric repeater indexes while retaining the builder field path.
	 * Example: people.0.email and people.1.email both map to people.email.
	 *
	 * @param string $path Submitted or schema field path.
	 * @return string
	 */
	private static function canonical_field_path( string $path ): string {
		$segments = array_filter( explode( '.', $path ), static function ( string $segment ): bool {
			return '' !== $segment && ! ctype_digit( $segment );
		} );
		return implode( '.', $segments );
	}

	/** @param string $type Field type. @return bool */
	private static function is_section_type( string $type ): bool {
		return in_array( $type, [ 'step', 'section', 'page', 'pagebreak', 'divider', 'form_step' ], true );
	}

	/**
	 * Divides long forms without structural metadata into readable groups.
	 *
	 * @param array<int, array<string, string>> $fields Display fields.
	 * @return array<int, array{title:string,fields:array<int, array<string, string>>}>
	 */
	private static function build_balanced_fallback_sections( array $fields ): array {
		$count = count( $fields );
		if ( $count <= 8 ) {
			return [ [ 'title' => 'Dati del formulario', 'fields' => $fields ] ];
		}

		$section_count = min( 7, (int) ceil( $count / 6 ) );
		$chunk_size    = (int) ceil( $count / $section_count );
		$sections      = [];
		foreach ( array_chunk( $fields, $chunk_size ) as $index => $chunk ) {
			$sections[] = [
				'title'  => sprintf( 'Sezione %d', $index + 1 ),
				'fields' => $chunk,
			];
		}
		return $sections;
	}

	/**
	 * Finds every valid recipient address in fields explicitly identified as
	 * email inputs by a trusted form-builder schema.
	 *
	 * A syntactically valid address inside a normal text or notes field is not
	 * considered a recipient, preventing accidental disclosure of the PDF.
	 *
	 * @param array<string|int, mixed> $fields Submitted form fields with trusted metadata.
	 * @return array<int, string> Unique valid addresses in form order.
	 */
	public static function extract_recipient_emails( array $fields ): array {
		$emails = [];
		self::collect_recipient_fields( $fields, $emails );
		return $emails;
	}

	/**
	 * Walks builder field structures and follows nested repeaters without ever
	 * inferring a recipient from the submitted value alone.
	 *
	 * @param array<string|int, mixed> $fields Current field collection.
	 * @param array<int, string>       $emails Recipient list passed by reference.
	 * @param int                      $depth Recursion depth.
	 * @return void
	 */
	private static function collect_recipient_fields( array $fields, array &$emails, int $depth = 0 ): void {
		if ( $depth > 8 ) {
			return;
		}

		$email_types = [ 'email', 'email_address', 'emailaddress', 'mail' ];
		foreach ( $fields as $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}

			if ( array_key_exists( 'value', $field ) ) {
				$type  = sanitize_key( (string) ( $field['type'] ?? '' ) );
				$value = $field['value'];
				if ( in_array( $type, $email_types, true ) ) {
					self::collect_email_values( $value, $emails );
				} elseif ( ! empty( $field['_twf_trusted_nested'] ) && is_array( $value ) ) {
					self::collect_recipient_fields( $value, $emails, $depth + 1 );
				}
				// A non-email value is traversed only when its adapter rebuilt the
				// nested wrappers from server-side builder metadata.
				continue;
			}

			self::collect_recipient_fields( $field, $emails, $depth + 1 );
		}
	}

	/**
	 * @param mixed              $value Scalar or repeated email values.
	 * @param array<int, string> $emails Recipient list passed by reference.
	 * @param int                $depth Recursion depth.
	 * @return void
	 */
	private static function collect_email_values( $value, array &$emails, int $depth = 0 ): void {
		if ( $depth > 8 ) {
			return;
		}
		if ( is_array( $value ) ) {
			foreach ( $value as $nested ) {
				self::collect_email_values( $nested, $emails, $depth + 1 );
			}
			return;
		}
		if ( is_scalar( $value ) ) {
			self::append_unique_email( $emails, (string) $value );
		}
	}

	/**
	 * Adds an address once, comparing case-insensitively while retaining the
	 * spelling submitted by the first matching field.
	 *
	 * @param array<int, string> $emails Recipient list passed by reference.
	 * @param string             $candidate Candidate address.
	 * @return void
	 */
	private static function append_unique_email( array &$emails, string $candidate ): void {
		$candidate = trim( $candidate );
		if ( ! is_email( $candidate ) ) {
			return;
		}

		$email = sanitize_email( $candidate );
		foreach ( $emails as $existing ) {
			if ( 0 === strcasecmp( $existing, $email ) ) {
				return;
			}
		}
		$emails[] = $email;
	}

	/**
	 * Flattens nested builder payloads into stable PDF rows.
	 *
	 * @param array<string, mixed> $fields Raw fields.
	 * @param array<int, string>   $ignore_keys Internal field names.
	 * @param string               $parent_key Current path.
	 * @param string               $parent_label Current label path.
	 * @param int                  $depth Current recursion depth.
	 * @return array<int, array<string, string>>
	 */
	private static function flatten_fields( array $fields, array $ignore_keys, string $parent_key = '', string $parent_label = '', int $depth = 0 ): array {
		$result = [];
		if ( $depth > 3 ) {
			return $result;
		}

		foreach ( $fields as $key => $item ) {
			$key = (string) $key;
			if ( in_array( $key, $ignore_keys, true ) || strpos( $key, 'step_' ) === 0 || strpos( $key, 'twf_' ) === 0 ) {
				continue;
			}

			$path  = '' === $parent_key ? $key : $parent_key . '.' . $key;
			$label = '' === $parent_label ? self::prettify_key( $key ) : $parent_label . ' — ' . self::prettify_key( $key );
			$type  = is_array( $item ) && ! empty( $item['type'] ) ? sanitize_key( $item['type'] ) : 'text';
			if ( in_array( $type, [ 'hidden', 'input_hidden', 'honeypot', 'html', 'custom_html', 'submit', 'button', 'step', 'page', 'pagebreak', 'section', 'captcha', 'recaptcha', 'recaptcha_v3' ], true ) ) {
				continue;
			}

			if ( is_array( $item ) && array_key_exists( 'value', $item ) ) {
				$path  = sanitize_text_field( (string) ( $item['id'] ?? $path ) );
				$label = sanitize_text_field( (string) ( $item['title'] ?? $item['label'] ?? $label ) );
				$item  = $item['value'];
			}

			$contains_nested = is_array( $item ) && array_filter( $item, 'is_array' );
			if ( is_array( $item ) && ( self::is_associative( $item ) || $contains_nested ) ) {
				$result = array_merge( $result, self::flatten_fields( $item, $ignore_keys, $path, $label, $depth + 1 ) );
				continue;
			}

			if ( is_array( $item ) ) {
				$value = implode( ', ', array_map( 'sanitize_text_field', array_slice( $item, 0, 50 ) ) );
				$type  = 'choice';
			} elseif ( is_bool( $item ) ) {
				$value = $item ? 'Sì / Accettato' : 'No / Non selezionato';
				$type  = 'boolean';
			} else {
				$value = sanitize_textarea_field( substr( (string) $item, 0, 5000 ) );
			}

			if ( in_array( $type, [ 'date', 'datepicker', 'datetime', 'date-time', 'date_time' ], true ) || is_date_string( $value ) ) {
				$value = format_display_date( $value );
				if ( ! in_array( $type, [ 'date', 'datepicker', 'datetime', 'date-time', 'date_time' ], true ) ) {
					$type = 'date';
				}
			}

			$result[] = [
				'key'     => mb_substr( sanitize_text_field( $path ), 0, 190 ),
				'id'      => mb_substr( sanitize_text_field( $path ), 0, 190 ),
				'label'   => mb_substr( sanitize_text_field( $label ), 0, 240 ),
				'value'   => '' === trim( $value ) ? '—' : $value,
				'type'    => $type,
				'section' => $parent_label,
			];
		}

		return $result;
	}

	/**
	 * @param array<mixed> $value Value to inspect.
	 * @return bool
	 */
	private static function is_associative( array $value ): bool {
		return [] !== $value && array_keys( $value ) !== range( 0, count( $value ) - 1 );
	}

	/**
	 * Converts raw input keys like "first_name" or "field_phone" into nice labels like "First Name" or "Phone".
	 *
	 * @param string $key
	 * @return string
	 */
	public static function prettify_key( string $key ): string {
		$key = preg_replace( '/^field_/', '', $key );
		$key = str_replace( [ '_', '-' ], ' ', $key );
		return ucwords( trim( $key ) );
	}

}
