<?php
/**
 * Settings manager for tw_formulari.
 *
 * @package TicinoWeb\TWFormulari
 */

namespace TicinoWeb\TWFormulari;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Settings {

	const FORM_SETTINGS_KEY  = 'tw_formulari_form_settings';
	const EMAIL_SETTINGS_KEY = 'tw_formulari_email_settings';
	const PDF_SETTINGS_KEY   = 'tw_formulari_pdf_settings';

	/**
	 * Returns default dynamic form configuration settings.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_default_form_settings(): array {
		return [
			'active_engine'  => 'auto',
			'target_form_id' => '',
		];
	}

	/**
	 * Returns default email settings.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_default_email_settings(): array {
		$site_name   = sanitize_text_field( get_bloginfo( 'name' ) );
		$admin_email = sanitize_email( get_option( 'admin_email' ) );

		return [
			'send_facility'    => 1,
			'facility_email'   => $admin_email,
			'sender_name'      => $site_name,
			'sender_email'     => $admin_email,
			'email_subject'    => sprintf( 'Formulario ricevuto — %s', $site_name ),
			'email_body_intro' => 'Abbiamo ricevuto correttamente il formulario compilato. In allegato trovi una copia in PDF.',
		];
	}

	/**
	 * Returns default PDF and identity settings.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_default_pdf_settings(): array {
		return [
			'facility_name'    => sanitize_text_field( get_bloginfo( 'name' ) ),
			'address'          => '',
			'city'             => '',
			'phone'            => '',
			'email'            => sanitize_email( get_option( 'admin_email' ) ),
			'document_title'   => 'FORMULARIO RICEVUTO',
			'document_subtitle'=> 'Modulo compilato online',
			'logo_url'         => '',
			'mandatory_notice' => '',
		];
	}

	/**
	 * Get current form configuration settings merged with defaults.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_form_settings(): array {
		$saved = get_option( self::FORM_SETTINGS_KEY, [] );
		if ( ! is_array( $saved ) ) {
			$saved = [];
		}
		return wp_parse_args( $saved, self::get_default_form_settings() );
	}

	/**
	 * Get current email settings merged with defaults.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_email_settings(): array {
		$saved = get_option( self::EMAIL_SETTINGS_KEY, [] );
		if ( ! is_array( $saved ) ) {
			$saved = [];
		}
		return wp_parse_args( $saved, self::get_default_email_settings() );
	}

	/**
	 * Get current PDF and identity settings merged with defaults.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_pdf_settings(): array {
		$saved = get_option( self::PDF_SETTINGS_KEY, [] );
		if ( ! is_array( $saved ) ) {
			$saved = [];
		}
		return wp_parse_args( $saved, self::get_default_pdf_settings() );
	}

	/**
	 * Save form configuration settings.
	 *
	 * @param array<string, mixed> $settings Raw settings from POST.
	 * @return bool
	 */
	public static function save_form_settings( array $settings ): bool {
		$allowed_engines  = [ 'auto', 'elementor', 'cf7', 'wpforms', 'gravityforms', 'fluentforms', 'generic' ];
		$active_engine    = sanitize_key( $settings['active_engine'] ?? 'auto' );

		$sanitized = [
			'active_engine'  => in_array( $active_engine, $allowed_engines, true ) ? $active_engine : 'auto',
			'target_form_id' => self::resolve_target_form_id( $settings ),
		];

		return update_option( self::FORM_SETTINGS_KEY, $sanitized );
	}

	/**
	 * Prefer the explicit fallback ID only when the administrator filled it.
	 *
	 * @param array<string, mixed> $settings Raw form settings.
	 * @return string
	 */
	public static function resolve_target_form_id( array $settings ): string {
		$manual = sanitize_text_field( $settings['target_form_id_manual'] ?? '' );
		return '' !== $manual ? $manual : sanitize_text_field( $settings['target_form_id'] ?? '' );
	}

	/**
	 * Save email settings.
	 *
	 * @param array<string, mixed> $settings Raw settings from POST.
	 * @return bool
	 */
	public static function save_email_settings( array $settings ): bool {
		$sanitized = [
			'send_facility'    => ! empty( $settings['send_facility'] ) ? 1 : 0,
			'facility_email'   => sanitize_email( $settings['facility_email'] ?? '' ),
			'sender_name'      => sanitize_text_field( $settings['sender_name'] ?? '' ),
			'sender_email'     => sanitize_email( $settings['sender_email'] ?? '' ),
			'email_subject'    => sanitize_text_field( $settings['email_subject'] ?? '' ),
			'email_body_intro' => sanitize_textarea_field( $settings['email_body_intro'] ?? '' ),
		];

		return update_option( self::EMAIL_SETTINGS_KEY, $sanitized );
	}

	/**
	 * Save PDF and identity settings.
	 *
	 * @param array<string, mixed> $settings Raw settings from POST.
	 * @return bool
	 */
	public static function save_pdf_settings( array $settings ): bool {
		$sanitized = [
			'facility_name'    => sanitize_text_field( $settings['facility_name'] ?? '' ),
			'address'          => sanitize_text_field( $settings['address'] ?? '' ),
			'city'             => sanitize_text_field( $settings['city'] ?? '' ),
			'phone'            => sanitize_text_field( $settings['phone'] ?? '' ),
			'email'            => sanitize_email( $settings['email'] ?? '' ),
			'document_title'   => sanitize_text_field( $settings['document_title'] ?? '' ),
			'document_subtitle'=> sanitize_text_field( $settings['document_subtitle'] ?? '' ),
			'logo_url'         => esc_url_raw( $settings['logo_url'] ?? '' ),
			'mandatory_notice' => sanitize_textarea_field( $settings['mandatory_notice'] ?? '' ),
		];

		return update_option( self::PDF_SETTINGS_KEY, $sanitized );
	}
}
