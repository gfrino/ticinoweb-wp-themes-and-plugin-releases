<?php
/**
 * Operational technical logger for tw_formulari.
 *
 * @package TicinoWeb\TWFormulari
 */

namespace TicinoWeb\TWFormulari;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Logger {

	/**
	 * Option key for storing logs.
	 */
	const OPTION_KEY = 'tw_formulari_last_status';

	/**
	 * Record a technical log entry.
	 *
	 * Note: Strictly operational information only. No personal data is stored.
	 *
	 * @param string $event Event identifier (e.g. 'form_intercepted', 'pdf_generated', 'email_sent', 'error').
	 * @param string $status Status ('success', 'warning', 'error').
	 * @param string $message Technical message/summary.
	 * @return void
	 */
	public static function log( string $event, string $status, string $message ): void {
		$entry = [
			'id'        => wp_generate_uuid4(),
			'timestamp' => current_time( 'mysql' ),
			'event'     => sanitize_key( $event ),
			'status'    => sanitize_key( $status ),
			'message'   => sanitize_text_field( $message ),
		];

		update_option( self::OPTION_KEY, $entry, false );
	}

	/**
	 * Get the most recent log entry.
	 *
	 * @return array<string, string>|null Latest log entry or null.
	 */
	public static function get_last_entry(): ?array {
		$entry = get_option( self::OPTION_KEY, [] );
		return is_array( $entry ) && ! empty( $entry['event'] ) ? $entry : null;
	}

}
