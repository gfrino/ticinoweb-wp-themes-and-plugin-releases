<?php
/**
 * Generic POST / Custom Form Adapter.
 *
 * @package TicinoWeb\TWFormulari\Adapters
 */

namespace TicinoWeb\TWFormulari\Adapters;

use TicinoWeb\TWFormulari\FormManager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GenericAdapter implements FormAdapterInterface {

	public function get_id(): string {
		return 'generic';
	}

	public function get_name(): string {
		return 'Modulo Generico (POST)';
	}

	public function is_available(): bool {
		return true; // Always available
	}

	public function register_hooks(): void {
		add_action( 'wp', [ $this, 'handle_post_submission' ] );
		add_action( 'admin_post_twf_custom_form', [ $this, 'handle_admin_post_submission' ] );
		add_action( 'admin_post_nopriv_twf_custom_form', [ $this, 'handle_admin_post_submission' ] );
		add_shortcode( 'tw_formulari_security_fields', [ $this, 'render_security_fields' ] );
	}

	/**
	 * Hidden fields required by explicitly configured custom forms.
	 *
	 * @return string
	 */
	public function render_security_fields(): string {
		return sprintf(
			'<input type="hidden" name="twf_nonce" value="%s"><input type="hidden" name="twf_submission_id" value="%s"><input type="text" name="twf_website" value="" tabindex="-1" autocomplete="off" aria-hidden="true" style="position:absolute;left:-10000px;width:1px;height:1px;overflow:hidden">',
			esc_attr( wp_create_nonce( 'twf_custom_form' ) ),
			esc_attr( wp_generate_uuid4() )
		);
	}

	/**
	 * Validates authenticity and hard payload bounds before processing.
	 *
	 * @param array<string, mixed> $request Request data.
	 * @return bool
	 */
	public static function validate_request( array $request ): bool {
		$nonce = sanitize_text_field( (string) ( $request['twf_nonce'] ?? '' ) );
		if ( ! wp_verify_nonce( $nonce, 'twf_custom_form' ) || ! empty( $request['twf_website'] ) ) {
			return false;
		}

		if ( count( $request, COUNT_RECURSIVE ) > 300 ) {
			return false;
		}

		$encoded = wp_json_encode( $request );
		return is_string( $encoded ) && strlen( $encoded ) <= 262144;
	}

	/**
	 * Handler for standard POST requests.
	 *
	 * @return void
	 */
	public function handle_post_submission(): void {
		if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) {
			return;
		}

		$request = is_array( $_POST ) ? wp_unslash( $_POST ) : [];
		if ( empty( $request['twf_form_id'] ) || ! self::validate_request( $request ) ) {
			return;
		}

		$form_id   = sanitize_text_field( (string) $request['twf_form_id'] );
		$settings  = \TicinoWeb\TWFormulari\Settings::get_form_settings();
		if ( 'generic' !== ( $settings['active_engine'] ?? '' ) || empty( $settings['target_form_id'] ) || ! hash_equals( (string) $settings['target_form_id'], $form_id ) || ! self::consume_rate_limit( (string) ( $_SERVER['REMOTE_ADDR'] ?? 'unknown' ) ) ) {
			return;
		}
		$form_name = sanitize_text_field( (string) ( $request['twf_form_name'] ?? '' ) );
		$post_id   = (int) ( $request['post_id'] ?? get_the_ID() ?: 0 );

		$fields = $request['form_fields'] ?? $request;

		FormManager::get_instance()->handle_submission( [
			'engine'    => $this->get_id(),
			'form_id'   => $form_id,
			'form_name' => $form_name,
			'post_id'   => $post_id,
			'submission_id' => sanitize_text_field( (string) ( $request['twf_submission_id'] ?? '' ) ),
			'fields'    => is_array( $fields ) ? $fields : [],
		] );
	}

	/**
	 * Handler for admin-post submissions.
	 *
	 * @return void
	 */
	public function handle_admin_post_submission(): void {
		$this->handle_post_submission();
	}

	/**
	 * Limits unauthenticated processing per source and across the site.
	 *
	 * @return bool
	 */
	public static function consume_rate_limit( string $source ): bool {
		$window = 10 * MINUTE_IN_SECONDS;
		$bucket = (string) floor( time() / $window );
		$hash   = substr( hash( 'sha256', sanitize_text_field( $source ) ), 0, 20 );
		for ( $slot = 1; $slot <= 20; ++$slot ) {
			$key = sprintf( 'twf_rate_slot_%s_%s_%d', $bucket, $hash, $slot );
			if ( add_option( $key, time() + $window, '', false ) ) {
				return true;
			}
		}
		return false;
	}
}
