<?php
/**
 * Contact Form 7 Adapter.
 *
 * @package TicinoWeb\TWFormulari\Adapters
 */

namespace TicinoWeb\TWFormulari\Adapters;

use TicinoWeb\TWFormulari\FormManager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ContactForm7Adapter implements FormAdapterInterface, FormDiscoveryInterface {

	public function get_id(): string {
		return 'cf7';
	}

	public function get_name(): string {
		return 'Contact Form 7';
	}

	public function is_available(): bool {
		return defined( 'WPCF7_VERSION' ) || function_exists( 'wpcf7' );
	}

	public function register_hooks(): void {
		add_action( 'wpcf7_mail_sent', [ $this, 'handle_mail_sent' ], 10, 1 );
	}

	/** @return array<int, array<string, string>> */
	public function get_forms(): array {
		return self::format_form_posts( get_posts( [
			'post_type'      => 'wpcf7_contact_form',
			'post_status'    => 'any',
			'posts_per_page' => 250,
			'orderby'        => 'title',
			'order'          => 'ASC',
			'no_found_rows'  => true,
		] ) );
	}

	/** @return array<int, array<string, mixed>> */
	public function get_form_schema( string $form_id ): array {
		if ( ! class_exists( '\\WPCF7_ContactForm' ) || ! method_exists( '\\WPCF7_ContactForm', 'get_instance' ) ) {
			return [];
		}
		$form = \WPCF7_ContactForm::get_instance( absint( $form_id ) );
		if ( ! is_object( $form ) || ! method_exists( $form, 'scan_form_tags' ) ) {
			return [];
		}
		$tags = $form->scan_form_tags();
		return self::schema_from_tags( is_array( $tags ) ? $tags : [] );
	}

	/**
	 * @param array<int, object> $tags Contact Form 7 form tags.
	 * @return array<int, array<string, mixed>>
	 */
	public static function schema_from_tags( array $tags ): array {
		$schema = [];
		foreach ( $tags as $tag ) {
			$name = is_object( $tag ) ? sanitize_text_field( (string) ( $tag->name ?? '' ) ) : '';
			$type = is_object( $tag ) ? sanitize_key( (string) ( $tag->basetype ?? $tag->type ?? 'text' ) ) : 'text';
			if ( '' === $name || 0 === strpos( $name, '_wpcf7' ) || in_array( $type, [ 'hidden', 'submit' ], true ) ) {
				continue;
			}
			$options = [];
			foreach ( (array) ( $tag->values ?? [] ) as $option ) {
				$option = sanitize_text_field( (string) $option );
				if ( '' !== $option ) {
					$options[] = $option;
				}
			}
			$schema[] = [
				'id'      => $name,
				'label'   => ucwords( str_replace( [ '_', '-' ], ' ', $name ) ),
				'type'    => $type ?: 'text',
				'options' => $options,
			];
		}
		return $schema;
	}

	/**
	 * @param array<int, object> $posts Contact form posts.
	 * @return array<int, array<string, string>>
	 */
	public static function format_form_posts( array $posts ): array {
		$forms = [];
		foreach ( $posts as $post ) {
			$id = sanitize_text_field( (string) ( $post->ID ?? '' ) );
			if ( '' !== $id ) {
				$forms[] = [
					'id'       => $id,
					'name'     => sanitize_text_field( (string) ( $post->post_title ?? '' ) ),
					'location' => '',
				];
			}
		}
		return $forms;
	}

	/**
	 * Enriches submitted values with the field types exposed by Contact Form 7.
	 *
	 * @param array<string, mixed> $posted_data Submitted values.
	 * @param array<int, object>   $tags Form tags returned by scan_form_tags().
	 * @return array<string, array<string, mixed>>
	 */
	public static function format_fields( array $posted_data, array $tags = [] ): array {
		$types = [];
		foreach ( $tags as $tag ) {
			$name = is_object( $tag ) ? sanitize_text_field( (string) ( $tag->name ?? '' ) ) : '';
			$type = is_object( $tag ) ? sanitize_key( (string) ( $tag->basetype ?? $tag->type ?? 'text' ) ) : 'text';
			if ( '' !== $name ) {
				$types[ $name ] = $type ?: 'text';
			}
		}

		$formatted = [];
		foreach ( $posted_data as $key => $value ) {
			$id = sanitize_text_field( (string) $key );
			if ( '' === $id || 0 === strpos( $id, '_wpcf7' ) || ( ! empty( $types ) && ! isset( $types[ $id ] ) ) ) {
				continue;
			}
			$formatted[ $id ] = [
				'id'    => $id,
				'title' => ucwords( str_replace( [ '_', '-' ], ' ', $id ) ),
				'type'  => $types[ $id ] ?? 'text',
				'value' => $value,
			];
		}
		return $formatted;
	}

	/**
	 * Handler for Contact Form 7 mail sent.
	 *
	 * @param \WPCF7_ContactForm $contact_form
	 * @return void
	 */
	public function handle_mail_sent( $contact_form ): void {
		if ( ! is_object( $contact_form ) || ! method_exists( $contact_form, 'id' ) ) {
			return;
		}

		$form_id   = (string) $contact_form->id();
		$form_name = method_exists( $contact_form, 'title' ) ? (string) $contact_form->title() : '';

		$submission = class_exists( '\WPCF7_Submission' ) ? \WPCF7_Submission::get_instance() : null;
		$posted_data = $submission ? $submission->get_posted_data() : ( $_POST ?? [] );

		$tags = method_exists( $contact_form, 'scan_form_tags' ) ? $contact_form->scan_form_tags() : [];
		$cleaned_fields = self::format_fields( is_array( $posted_data ) ? $posted_data : [], is_array( $tags ) ? $tags : [] );

		$submission_id = '';
		if ( $submission && method_exists( $submission, 'get_meta' ) ) {
			$submission_id = hash( 'sha256', $form_id . '|' . (string) $submission->get_meta( 'timestamp' ) . '|' . (string) $submission->get_meta( 'remote_ip' ) . '|' . wp_json_encode( $cleaned_fields ) );
		}

		FormManager::get_instance()->handle_submission( [
			'engine'    => $this->get_id(),
			'form_id'   => $form_id,
			'form_name' => $form_name,
			'post_id'   => get_the_ID() ?: 0,
			'submission_id' => $submission_id,
			'fields'    => $cleaned_fields,
			'schema'    => self::schema_from_tags( is_array( $tags ) ? $tags : [] ),
		] );
	}
}
