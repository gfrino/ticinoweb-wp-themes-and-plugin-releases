<?php
/**
 * Gravity Forms Adapter.
 *
 * @package TicinoWeb\TWFormulari\Adapters
 */

namespace TicinoWeb\TWFormulari\Adapters;

use TicinoWeb\TWFormulari\FormManager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GravityFormsAdapter implements FormAdapterInterface, FormDiscoveryInterface {

	public function get_id(): string {
		return 'gravityforms';
	}

	public function get_name(): string {
		return 'Gravity Forms';
	}

	public function is_available(): bool {
		return class_exists( '\GFForms' ) || class_exists( '\RGFormsModel' );
	}

	public function register_hooks(): void {
		add_action( 'gform_after_submission', [ $this, 'handle_after_submission' ], 10, 2 );
	}

	/** @return array<int, array<string, string>> */
	public function get_forms(): array {
		if ( ! class_exists( '\GFAPI' ) || ! method_exists( '\GFAPI', 'get_forms' ) ) {
			return [];
		}
		$forms = \GFAPI::get_forms();
		return self::format_form_records( is_array( $forms ) ? $forms : [] );
	}

	/** @return array<int, array<string, mixed>> */
	public function get_form_schema( string $form_id ): array {
		if ( ! class_exists( '\\GFAPI' ) || ! method_exists( '\\GFAPI', 'get_form' ) ) {
			return [];
		}
		$form = \GFAPI::get_form( absint( $form_id ) );
		return self::schema_from_form( is_array( $form ) ? $form : [] );
	}

	/**
	 * @param array<string, mixed> $form Gravity Forms structure.
	 * @return array<int, array<string, mixed>>
	 */
	public static function schema_from_form( array $form ): array {
		$schema = [];
		foreach ( (array) ( $form['fields'] ?? [] ) as $index => $field ) {
			if ( ! is_object( $field ) && ! is_array( $field ) ) {
				continue;
			}
			$get = static function ( string $key, $default = '' ) use ( $field ) {
				return is_array( $field ) ? ( $field[ $key ] ?? $default ) : ( $field->{$key} ?? $default );
			};
			$type = sanitize_key( (string) $get( 'type', 'text' ) );
			if ( in_array( $type, [ 'hidden', 'html', 'captcha' ], true ) ) {
				continue;
			}
			$id = sanitize_key( 'field_' . (string) $get( 'id', $index ) );
			$label = sanitize_text_field( (string) $get( 'label', $id ) );
			if ( in_array( $type, [ 'section', 'page' ], true ) ) {
				$schema[] = [ 'id' => $id, 'label' => $label ?: 'Nuova sezione', 'type' => 'section', 'options' => [] ];
				continue;
			}
			$options = [];
			foreach ( (array) $get( 'choices', [] ) as $choice ) {
				$value = is_array( $choice ) ? ( $choice['text'] ?? $choice['value'] ?? '' ) : ( is_object( $choice ) ? ( $choice->text ?? $choice->value ?? '' ) : $choice );
				$value = sanitize_text_field( (string) $value );
				if ( '' !== $value ) {
					$options[] = $value;
				}
			}
			$schema[] = [ 'id' => $id, 'label' => $label ?: $id, 'type' => $type ?: 'text', 'options' => $options ];
		}
		return $schema;
	}

	/**
	 * @param array<int, array<string, mixed>> $records Gravity Forms records.
	 * @return array<int, array<string, string>>
	 */
	public static function format_form_records( array $records ): array {
		$forms = [];
		foreach ( $records as $record ) {
			$id = sanitize_text_field( (string) ( $record['id'] ?? '' ) );
			if ( '' !== $id ) {
				$forms[] = [
					'id'       => $id,
					'name'     => sanitize_text_field( (string) ( $record['title'] ?? '' ) ),
					'location' => '',
				];
			}
		}
		return $forms;
	}

	/**
	 * Handler for Gravity Forms submission.
	 *
	 * @param array $entry
	 * @param array $form
	 * @return void
	 */
	public function handle_after_submission( $entry, $form ): void {
		$form_id   = (string) ( $form['id'] ?? '' );
		$form_name = (string) ( $form['title'] ?? '' );

		$formatted_fields = [];
		if ( ! empty( $form['fields'] ) && is_array( $form['fields'] ) ) {
			foreach ( $form['fields'] as $field ) {
				$field_id    = $field->id ?? '';
				$field_label = $field->label ?? ( 'field_' . $field_id );
				$val         = \RGFormsModel::get_lead_field_value( $entry, $field );
				$key = sanitize_key( 'field_' . (string) $field_id );
				$formatted_fields[ $key ] = [
					'id'    => $key,
					'title' => sanitize_text_field( (string) $field_label ),
					'type'  => sanitize_key( (string) ( $field->type ?? 'text' ) ),
					'value' => $val,
				];
			}
		}

		FormManager::get_instance()->handle_submission( [
			'engine'    => $this->get_id(),
			'form_id'   => $form_id,
			'form_name' => $form_name,
			'post_id'   => get_the_ID() ?: 0,
			'submission_id' => (string) ( $entry['id'] ?? '' ),
			'fields'    => $formatted_fields,
			'schema'    => self::schema_from_form( is_array( $form ) ? $form : [] ),
		] );
	}
}
