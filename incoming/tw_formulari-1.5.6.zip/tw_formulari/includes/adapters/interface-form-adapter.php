<?php
/**
 * Contract for all form builder integration adapters.
 *
 * @package TicinoWeb\TWFormulari
 */

namespace TicinoWeb\TWFormulari\Adapters;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

interface FormAdapterInterface {

	/**
	 * Unique identifier for this adapter (e.g. 'elementor', 'cf7', 'wpforms', 'gravityforms', 'fluentforms', 'generic').
	 *
	 * @return string
	 */
	public function get_id(): string;

	/**
	 * Human-readable name of the form engine.
	 *
	 * @return string
	 */
	public function get_name(): string;

	/**
	 * Check if the respective form plugin is currently installed and active.
	 *
	 * @return bool
	 */
	public function is_available(): bool;

	/**
	 * Registers the necessary action/filter hooks for this form system.
	 *
	 * @return void
	 */
	public function register_hooks(): void;
}
