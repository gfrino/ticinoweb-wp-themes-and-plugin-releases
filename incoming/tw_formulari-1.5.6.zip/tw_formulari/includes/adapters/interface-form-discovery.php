<?php
/**
 * Optional contract for form builders that can list configured forms.
 *
 * @package TicinoWeb\TWFormulari\Adapters
 */

namespace TicinoWeb\TWFormulari\Adapters;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

interface FormDiscoveryInterface {

	/**
	 * Return form choices with id, name and optional location.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function get_forms(): array;

	/**
	 * Return the current visible field schema for one configured form.
	 *
	 * @param string $form_id Form identifier exposed by get_forms().
	 * @return array<int, array<string, mixed>>
	 */
	public function get_form_schema( string $form_id ): array;
}
