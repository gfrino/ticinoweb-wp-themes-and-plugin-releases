<?php
/**
 * Elementor Pro Forms Adapter.
 *
 * @package TicinoWeb\TWFormulari\Adapters
 */

namespace TicinoWeb\TWFormulari\Adapters;

use TicinoWeb\TWFormulari\FormManager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ElementorAdapter implements FormAdapterInterface, FormDiscoveryInterface {

	/**
	 * Reads the visible input schema for one Elementor form widget.
	 *
	 * @param array<int, array<string, mixed>> $elements Elementor element tree.
	 * @param string                           $form_id Target widget ID.
	 * @return array<int, array<string, mixed>>
	 */
	public static function extract_schema_from_elements( array $elements, string $form_id ): array {
		foreach ( $elements as $element ) {
			if ( ! is_array( $element ) ) {
				continue;
			}
			if ( 'form' === ( $element['widgetType'] ?? '' ) && hash_equals( $form_id, (string) ( $element['id'] ?? '' ) ) ) {
				$settings = isset( $element['settings'] ) && is_array( $element['settings'] ) ? $element['settings'] : [];
				return self::schema_from_form_fields( (array) ( $settings['form_fields'] ?? [] ) );
			}
			if ( ! empty( $element['elements'] ) && is_array( $element['elements'] ) ) {
				$schema = self::extract_schema_from_elements( $element['elements'], $form_id );
				if ( ! empty( $schema ) ) {
					return $schema;
				}
			}
		}
		return [];
	}

	/**
	 * Converts the Elementor field repeater into ordered fields and section markers.
	 *
	 * @param array<int, array<string, mixed>> $form_fields Elementor form fields.
	 * @return array<int, array<string, mixed>>
	 */
	public static function schema_from_form_fields( array $form_fields ): array {
		$schema         = [];
		$section_number = 0;
		foreach ( $form_fields as $index => $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}
			$type = sanitize_key( (string) ( $field['field_type'] ?? 'text' ) );
			if ( in_array( $type, [ 'hidden', 'honeypot', 'html', 'captcha', 'recaptcha', 'recaptcha_v3' ], true ) ) {
				continue;
			}
			$id = sanitize_text_field( (string) ( $field['custom_id'] ?? $field['field_id'] ?? $field['_id'] ?? 'field_' . $index ) );
			if ( '' === $id ) {
				continue;
			}
			$label = sanitize_text_field( (string) ( $field['field_label'] ?? $field['step_title'] ?? $field['placeholder'] ?? $id ) );
			if ( 'step' === $type ) {
				++$section_number;
				$schema[] = [
					'id'      => $id,
					'label'   => $label ?: sprintf( 'Sezione %d', $section_number ),
					'type'    => 'section',
					'options' => [],
				];
				continue;
			}
			$options  = self::parse_options( $field['field_options'] ?? [] );
			$schema[] = [
				'id'      => $id,
				'label'   => $label ?: $id,
				'type'    => $type ?: 'text',
				'options' => $options,
			];
		}
		return $schema;
	}

	/** @param mixed $raw_options @return array<int, string> */
	private static function parse_options( $raw_options ): array {
		$options = is_array( $raw_options ) ? $raw_options : preg_split( '/\r\n|\r|\n/', (string) $raw_options );
		$clean   = [];
		foreach ( (array) $options as $option ) {
			if ( is_array( $option ) ) {
				$option = $option['label'] ?? $option['value'] ?? '';
			}
			$option = sanitize_text_field( (string) $option );
			if ( '' !== $option ) {
				$clean[] = $option;
			}
		}
		return $clean;
	}

	/**
	 * Extract Elementor form widgets from a nested element tree.
	 *
	 * @param array<int, array<string, mixed>> $elements Elementor elements.
	 * @param string                           $location Human-readable source.
	 * @return array<int, array<string, string>>
	 */
	public static function extract_forms_from_elements( array $elements, string $location = '' ): array {
		$forms = [];
		foreach ( $elements as $element ) {
			if ( ! is_array( $element ) ) {
				continue;
			}
			if ( 'form' === ( $element['widgetType'] ?? '' ) ) {
				$id       = sanitize_text_field( (string) ( $element['id'] ?? '' ) );
				$settings = isset( $element['settings'] ) && is_array( $element['settings'] ) ? $element['settings'] : [];
				if ( '' !== $id ) {
					$forms[] = [
						'id'       => $id,
						'name'     => sanitize_text_field( (string) ( $settings['form_name'] ?? '' ) ),
						'location' => sanitize_text_field( $location ),
					];
				}
			}
			if ( ! empty( $element['elements'] ) && is_array( $element['elements'] ) ) {
				$forms = array_merge( $forms, self::extract_forms_from_elements( $element['elements'], $location ) );
			}
		}
		return $forms;
	}

	public function get_id(): string {
		return 'elementor';
	}

	public function get_name(): string {
		return 'Elementor Pro Forms';
	}

	public function is_available(): bool {
		return did_action( 'elementor_pro/init' ) || defined( 'ELEMENTOR_PRO_VERSION' ) || class_exists( '\ElementorPro\Plugin' );
	}

	public function register_hooks(): void {
		add_action( 'elementor_pro/forms/new_record', [ $this, 'handle_new_record' ], 10, 2 );
	}

	/** @return array<int, array<string, string>> */
	public function get_forms(): array {
		$forms = [];
		$post_types = array_values( get_post_types( [ 'show_ui' => true ], 'names' ) );
		if ( ! in_array( 'elementor_library', $post_types, true ) ) {
			$post_types[] = 'elementor_library';
		}
		$post_ids = get_posts( [
			'post_type'              => $post_types,
			'post_status'            => [ 'publish', 'draft', 'private' ],
			'posts_per_page'         => 250,
			'fields'                 => 'ids',
			'orderby'                => 'title',
			'order'                  => 'ASC',
			'no_found_rows'          => true,
			'update_post_meta_cache' => true,
			'meta_query'             => [
				[
					'key'     => '_elementor_data',
					'compare' => 'EXISTS',
				],
			],
		] );

		foreach ( $post_ids as $post_id ) {
			$elements = json_decode( (string) get_post_meta( (int) $post_id, '_elementor_data', true ), true );
			if ( ! is_array( $elements ) ) {
				continue;
			}
			$title = get_the_title( (int) $post_id );
			$forms = array_merge( $forms, self::extract_forms_from_elements( $elements, (string) $title ) );
		}

		return $forms;
	}

	/** @return array<int, array<string, mixed>> */
	public function get_form_schema( string $form_id ): array {
		$form_id = sanitize_text_field( $form_id );
		if ( '' === $form_id ) {
			return [];
		}
		$post_types = array_values( get_post_types( [ 'show_ui' => true ], 'names' ) );
		if ( ! in_array( 'elementor_library', $post_types, true ) ) {
			$post_types[] = 'elementor_library';
		}
		$post_ids = get_posts( [
			'post_type'              => $post_types,
			'post_status'            => [ 'publish', 'draft', 'private' ],
			'posts_per_page'         => 250,
			'fields'                 => 'ids',
			'no_found_rows'          => true,
			'update_post_meta_cache' => true,
			'meta_query'             => [ [ 'key' => '_elementor_data', 'compare' => 'EXISTS' ] ],
		] );
		foreach ( $post_ids as $post_id ) {
			$elements = json_decode( (string) get_post_meta( (int) $post_id, '_elementor_data', true ), true );
			if ( ! is_array( $elements ) ) {
				continue;
			}
			$schema = self::extract_schema_from_elements( $elements, $form_id );
			if ( ! empty( $schema ) ) {
				return $schema;
			}
		}
		return [];
	}

	/**
	 * Handler for Elementor Pro submission.
	 *
	 * @param \ElementorPro\Modules\Forms\Classes\Form_Record $record
	 * @param \ElementorPro\Modules\Forms\Classes\Ajax_Handler $ajax_handler
	 * @return void
	 */
	public function handle_new_record( $record, $ajax_handler ): void {
		if ( ! is_object( $record ) || ! method_exists( $record, 'get_form_settings' ) ) {
			return;
		}

		$form_id   = (string) $record->get_form_settings( 'id' );
		$form_name = (string) $record->get_form_settings( 'form_name' );
		$post_id   = (int) ( $_POST['post_id'] ?? 0 );

		$raw_fields = $record->get( 'fields' );
		if ( empty( $raw_fields ) && ! empty( $_POST['form_fields'] ) && is_array( $_POST['form_fields'] ) ) {
			$raw_fields = $_POST['form_fields'];
		}

		$form_fields = $record->get_form_settings( 'form_fields' );
		$schema      = is_array( $form_fields ) ? self::schema_from_form_fields( $form_fields ) : [];
		if ( empty( $schema ) ) {
			$schema = $this->get_form_schema( $form_id );
		}

		FormManager::get_instance()->handle_submission( [
			'engine'    => $this->get_id(),
			'form_id'   => $form_id,
			'form_name' => $form_name,
			'post_id'   => $post_id,
			'fields'    => $raw_fields,
			'schema'    => $schema,
		] );
	}
}
