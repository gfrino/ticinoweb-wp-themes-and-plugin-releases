<?php
/**
 * Fluent Forms Adapter.
 *
 * @package TicinoWeb\TWFormulari\Adapters
 */

namespace TicinoWeb\TWFormulari\Adapters;

use TicinoWeb\TWFormulari\FormManager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class FluentFormsAdapter implements FormAdapterInterface, FormDiscoveryInterface {

	public function get_id(): string {
		return 'fluentforms';
	}

	public function get_name(): string {
		return 'Fluent Forms';
	}

	public function is_available(): bool {
		return defined( 'FLUENTFORM_VERSION' ) || function_exists( 'wpFluentForm' );
	}

	public function register_hooks(): void {
		add_action( 'fluentform/submission_inserted', [ $this, 'handle_submission_inserted' ], 10, 3 );
	}

	/** @return array<int, array<string, string>> */
	public function get_forms(): array {
		$records = [];
		if ( function_exists( 'wpFluent' ) ) {
			$records = wpFluent()->table( 'fluentform_forms' )->select( [ 'id', 'title' ] )->orderBy( 'title' )->get();
		} elseif ( class_exists( '\FluentForm\App\Models\Form' ) ) {
			$records = \FluentForm\App\Models\Form::select( [ 'id', 'title' ] )->orderBy( 'title' )->get();
		}
		if ( is_object( $records ) && method_exists( $records, 'all' ) ) {
			$records = $records->all();
		}
		return self::format_form_records( is_iterable( $records ) ? $records : [] );
	}

	/** @return array<int, array<string, mixed>> */
	public function get_form_schema( string $form_id ): array {
		$form = null;
		if ( class_exists( '\\FluentForm\\App\\Models\\Form' ) ) {
			$form = \FluentForm\App\Models\Form::find( absint( $form_id ) );
		} elseif ( function_exists( 'wpFluent' ) ) {
			$form = wpFluent()->table( 'fluentform_forms' )->where( 'id', absint( $form_id ) )->first();
		}
		if ( ! is_object( $form ) && ! is_array( $form ) ) {
			return [];
		}
		$stored = is_array( $form ) ? ( $form['form_fields'] ?? $form['fields'] ?? [] ) : ( $form->form_fields ?? $form->fields ?? [] );
		return self::schema_from_form_structure( $stored );
	}

	/**
	 * @param mixed $structure Fluent Forms field structure or JSON.
	 * @return array<int, array<string, mixed>>
	 */
	public static function schema_from_form_structure( $structure ): array {
		if ( is_string( $structure ) ) {
			$decoded   = json_decode( $structure, true );
			$structure = is_array( $decoded ) ? $decoded : [];
		} elseif ( is_object( $structure ) ) {
			$structure = (array) $structure;
		}
		$field_schema = [];
		self::collect_field_schema( is_array( $structure ) ? $structure : [], $field_schema );
		$schema = [];
		foreach ( $field_schema as $id => $metadata ) {
			if ( ! self::is_displayable_schema_field( $metadata ) ) {
				continue;
			}
			$schema[] = [
				'id'      => $id,
				'label'   => $metadata['label'] ?: ucwords( str_replace( [ '_', '-' ], ' ', $id ) ),
				'type'    => $metadata['type'],
				'options' => $metadata['options'] ?? [],
			];
		}

		$step_titles = self::extract_step_titles( is_array( $structure ) ? $structure : [] );
		if ( ! empty( $step_titles ) ) {
			$mapped      = [];
			$title_index = 0;
			if ( empty( $schema ) || 'section' !== ( $schema[0]['type'] ?? '' ) ) {
				$mapped[] = [
					'id'      => '__step_0',
					'label'   => $step_titles[0],
					'type'    => 'section',
					'options' => [],
				];
				++$title_index;
			}
			foreach ( $schema as $entry ) {
				if ( 'section' === ( $entry['type'] ?? '' ) ) {
					if ( isset( $step_titles[ $title_index ] ) ) {
						$entry['label'] = $step_titles[ $title_index ];
					}
					++$title_index;
				}
				$mapped[] = $entry;
			}
			$schema = $mapped;
		}
		return $schema;
	}

	/**
	 * Reads the navigation labels used by Fluent Forms multi-step wrappers.
	 *
	 * @param array<mixed> $structure Fluent form structure.
	 * @return array<int, string>
	 */
	private static function extract_step_titles( array $structure ): array {
		$raw_titles = $structure['stepsWrapper']['stepStart']['settings']['step_titles'] ?? null;
		if ( null === $raw_titles ) {
			foreach ( $structure as $key => $value ) {
				if ( 'step_titles' === $key ) {
					$raw_titles = $value;
					break;
				}
				if ( is_object( $value ) ) {
					$value = (array) $value;
				}
				if ( is_array( $value ) ) {
					$titles = self::extract_step_titles( $value );
					if ( ! empty( $titles ) ) {
						return $titles;
					}
				}
			}
		}

		$titles = [];
		foreach ( (array) $raw_titles as $title ) {
			if ( is_array( $title ) ) {
				$title = $title['title'] ?? $title['label'] ?? $title['value'] ?? '';
			} elseif ( is_object( $title ) ) {
				$title = $title->title ?? $title->label ?? $title->value ?? '';
			}
			$title = sanitize_text_field( (string) $title );
			if ( '' !== $title ) {
				$titles[] = $title;
			}
		}
		return $titles;
	}

	/**
	 * @param iterable<int, object|array<string, mixed>> $records Fluent Forms records.
	 * @return array<int, array<string, string>>
	 */
	public static function format_form_records( iterable $records ): array {
		$forms = [];
		foreach ( $records as $record ) {
			$id    = is_array( $record ) ? ( $record['id'] ?? '' ) : ( $record->id ?? '' );
			$title = is_array( $record ) ? ( $record['title'] ?? '' ) : ( $record->title ?? '' );
			$id    = sanitize_text_field( (string) $id );
			if ( '' !== $id ) {
				$forms[] = [
					'id'       => $id,
					'name'     => sanitize_text_field( (string) $title ),
					'location' => '',
				];
			}
		}
		return $forms;
	}

	/**
	 * Enriches Fluent Forms submission values with type and label metadata from
	 * the stored form schema.
	 *
	 * @param array<string, mixed> $form_data Submitted values.
	 * @param mixed                $schema Form schema array, object or JSON.
	 * @return array<string, array<string, mixed>>
	 */
	public static function format_fields( array $form_data, $schema = [] ): array {
		if ( is_string( $schema ) ) {
			$decoded = json_decode( $schema, true );
			$schema  = is_array( $decoded ) ? $decoded : [];
		} elseif ( is_object( $schema ) ) {
			$schema = (array) $schema;
		}

		$field_schema = self::build_field_tree( is_array( $schema ) ? $schema : [] );
		$formatted = [];
		foreach ( $form_data as $key => $value ) {
			$id = sanitize_text_field( (string) $key );
			if ( '' === $id || ( ! empty( $field_schema ) && ! isset( $field_schema[ $id ] ) ) ) {
				continue;
			}
			$metadata = $field_schema[ $id ] ?? [];
			if ( ! empty( $field_schema ) && ! self::is_displayable_schema_field( $metadata ) ) {
				continue;
			}
			$label    = ! empty( $metadata['label'] ) ? $metadata['label'] : ucwords( str_replace( [ '_', '-' ], ' ', $id ) );
			$value    = self::filter_nested_value_by_schema( $value, $metadata, 0, $id, (string) $label );
			if ( is_array( $value ) && empty( $value ) && ! empty( $metadata['children'] ) ) {
				continue;
			}
			$formatted[ $id ] = [
				'id'    => $id,
				'title' => sanitize_text_field( (string) $label ),
				'type'  => sanitize_key( (string) ( $metadata['type'] ?? 'text' ) ),
				'value' => $value,
				'_twf_trusted_nested' => ! empty( $metadata['children'] ),
			];
		}
		return $formatted;
	}

	/**
	 * Removes hidden or technical children from compound Fluent Forms values.
	 * Numeric choice lists are preserved because they do not map to field names.
	 *
	 * @param mixed                                $value Submitted field value.
	 * @param array<string, mixed>                 $metadata Path-scoped field metadata.
	 * @param int                                  $depth Recursion depth.
	 * @return mixed
	 */
	private static function filter_nested_value_by_schema( $value, array $metadata, int $depth = 0, string $parent_id = '', string $parent_label = '' ) {
		if ( ! is_array( $value ) || $depth > 8 ) {
			return $value;
		}

		$filtered         = [];
		$allowed_children = (array) ( $metadata['children'] ?? [] );
		foreach ( $value as $key => $nested_value ) {
			if ( is_int( $key ) ) {
				$row_id           = '' === $parent_id ? (string) $key : $parent_id . '.' . $key;
				$filtered[ $key ] = self::filter_nested_value_by_schema( $nested_value, $metadata, $depth + 1, $row_id, $parent_label );
				continue;
			}

			$field_key = sanitize_text_field( (string) $key );
			$child_metadata = [];
			if ( ! empty( $allowed_children ) ) {
				if ( '' === $field_key || ! isset( $allowed_children[ $field_key ] ) ) {
					continue;
				}
				$child_metadata = $allowed_children[ $field_key ];
				if ( ! self::is_displayable_schema_field( $child_metadata ) ) {
					continue;
				}
			}

			$child_id    = '' === $parent_id ? $field_key : $parent_id . '.' . $field_key;
			$child_label = sanitize_text_field( (string) ( $child_metadata['label'] ?? '' ) );
			if ( '' === $child_label ) {
				$child_label = ucwords( str_replace( [ '_', '-' ], ' ', $field_key ) );
			}
			$label_path = '' === $parent_label ? $child_label : $parent_label . ' — ' . $child_label;
			$child_value = self::filter_nested_value_by_schema( $nested_value, $child_metadata, $depth + 1, $child_id, $label_path );
			$filtered[ $key ] = [
				'id'    => $child_id,
				'title' => $label_path,
				'type'  => sanitize_key( (string) ( $child_metadata['type'] ?? 'text' ) ),
				'value' => $child_value,
				'_twf_trusted_nested' => ! empty( $child_metadata['children'] ),
			];
		}

		return $filtered;
	}

	/**
	 * Builds path-scoped field metadata so identically named compound children
	 * cannot overwrite each other's visibility rules.
	 *
	 * @param array<mixed> $node Current schema node.
	 * @param int          $depth Recursion depth.
	 * @return array<string, array<string, mixed>>
	 */
	private static function build_field_tree( array $node, int $depth = 0 ): array {
		if ( $depth > 8 ) {
			return [];
		}

		$children = [];
		foreach ( $node as $key => $child ) {
			if ( in_array( $key, [ 'attributes', 'settings' ], true ) ) {
				continue;
			}
			if ( is_object( $child ) ) {
				$child = (array) $child;
			}
			if ( is_array( $child ) ) {
				$children = array_replace( $children, self::build_field_tree( $child, $depth + 1 ) );
			}
		}

		$attributes = isset( $node['attributes'] ) && is_array( $node['attributes'] ) ? $node['attributes'] : [];
		$name       = sanitize_text_field( (string) ( $attributes['name'] ?? $node['name'] ?? '' ) );
		if ( '' === $name ) {
			return $children;
		}

		$element  = sanitize_key( (string) ( $node['element'] ?? $node['type'] ?? 'text' ) );
		$settings = isset( $node['settings'] ) && is_array( $node['settings'] ) ? $node['settings'] : [];
		return [
			$name => [
				'type'     => false !== strpos( $element, 'email' ) ? 'email' : ( $element ?: 'text' ),
				'label'    => sanitize_text_field( (string) ( $settings['label'] ?? $node['label'] ?? '' ) ),
				'visible'  => ! array_key_exists( 'visible', $settings ) || ! in_array( $settings['visible'], [ false, 0, '0', 'false', 'no', 'off' ], true ),
				'children' => $children,
			],
		];
	}

	/**
	 * @param array<mixed>                         $node Current schema node.
	 * @param array<string, array<string, mixed>> $fields Collected metadata.
	 * @param int                                  $depth Recursion depth.
	 * @return void
	 */
	private static function collect_field_schema( array $node, array &$fields, int $depth = 0, string $parent_id = '', string $parent_label = '' ): void {
		if ( $depth > 8 ) {
			return;
		}

		$attributes = isset( $node['attributes'] ) && is_array( $node['attributes'] ) ? $node['attributes'] : [];
		$name       = sanitize_text_field( (string) ( $attributes['name'] ?? $node['name'] ?? '' ) );
		$element    = sanitize_key( (string) ( $node['element'] ?? $node['type'] ?? 'text' ) );
		$settings   = isset( $node['settings'] ) && is_array( $node['settings'] ) ? $node['settings'] : [];
		if ( 'form_step' === $element ) {
			$section_id = $name ?: 'section_' . count( $fields );
			$label      = sanitize_text_field( (string) ( $settings['label'] ?? $settings['step_title'] ?? $settings['title'] ?? $node['label'] ?? '' ) );
			$fields[ $section_id ] = [
				'type'    => 'section',
				'label'   => $label ?: 'Nuova sezione',
				'options' => [],
				'visible' => true,
			];
			return;
		}

		$visible = ! array_key_exists( 'visible', $settings ) || ! in_array( $settings['visible'], [ false, 0, '0', 'false', 'no', 'off' ], true );
		if ( '' !== $name && ! $visible ) {
			return;
		}

		$child_nodes = [];
		foreach ( (array) ( $node['fields'] ?? [] ) as $child ) {
			if ( is_object( $child ) ) {
				$child = (array) $child;
			}
			if ( is_array( $child ) ) {
				$child_nodes[] = $child;
			}
		}

		$metadata = [
			'type'    => false !== strpos( $element, 'email' ) ? 'email' : ( $element ?: 'text' ),
			'label'   => sanitize_text_field( (string) ( $settings['label'] ?? $node['label'] ?? '' ) ),
			'visible' => $visible,
		];
		$is_displayable = self::is_displayable_schema_field( $metadata );

		if ( '' !== $name && ! empty( $child_nodes ) ) {
			$field_id    = '' === $parent_id ? $name : $parent_id . '.' . $name;
			$field_label = $metadata['label'] ?: ucwords( str_replace( [ '_', '-' ], ' ', $name ) );
			$label_path  = '' === $parent_label ? $field_label : $parent_label . ' — ' . $field_label;
			foreach ( $child_nodes as $child ) {
				self::collect_field_schema( $child, $fields, $depth + 1, $is_displayable ? $field_id : $parent_id, $is_displayable ? $label_path : $parent_label );
			}
			return;
		}

		if ( '' !== $name && $is_displayable ) {
			$options = [];
			foreach ( (array) ( $settings['advanced_options'] ?? $node['options'] ?? [] ) as $option ) {
				$value = is_array( $option ) ? ( $option['label'] ?? $option['value'] ?? '' ) : $option;
				$value = sanitize_text_field( (string) $value );
				if ( '' !== $value ) {
					$options[] = $value;
				}
			}
			$field_id    = '' === $parent_id ? $name : $parent_id . '.' . $name;
			$field_label = $metadata['label'] ?: ucwords( str_replace( [ '_', '-' ], ' ', $name ) );
			$fields[ $field_id ] = [
				'type'  => $metadata['type'],
				'label' => '' === $parent_label ? $field_label : $parent_label . ' — ' . $field_label,
				'options' => $options,
				'visible' => true,
			];
			return;
		}

		foreach ( $node as $key => $child ) {
			if ( in_array( $key, [ 'attributes', 'settings', 'stepsWrapper' ], true ) ) {
				continue;
			}
			if ( is_object( $child ) ) {
				$child = (array) $child;
			}
			if ( is_array( $child ) ) {
				self::collect_field_schema( $child, $fields, $depth + 1, $parent_id, $parent_label );
			}
		}
	}

	/**
	 * @param array<string, mixed> $metadata Normalized Fluent field metadata.
	 * @return bool
	 */
	private static function is_displayable_schema_field( array $metadata ): bool {
		if ( isset( $metadata['visible'] ) && false === $metadata['visible'] ) {
			return false;
		}
		return ! in_array( (string) ( $metadata['type'] ?? '' ), [ 'hidden', 'input_hidden', 'html', 'custom_html', 'input_html', 'container', 'form_step' ], true );
	}

	/**
	 * Handler for Fluent Forms submission.
	 *
	 * @param int $entryId
	 * @param array $formData
	 * @param object $form
	 * @return void
	 */
	public function handle_submission_inserted( $entryId, $formData, $form ): void {
		$form_id   = (string) ( $form->id ?? '' );
		$form_name = (string) ( $form->title ?? '' );

		$schema = is_object( $form ) ? ( $form->form_fields ?? $form->fields ?? [] ) : [];
		$fields = self::format_fields( is_array( $formData ) ? $formData : [], $schema );

		FormManager::get_instance()->handle_submission( [
			'engine'    => $this->get_id(),
			'form_id'   => $form_id,
			'form_name' => $form_name,
			'post_id'   => get_the_ID() ?: 0,
			'submission_id' => (string) $entryId,
			'fields'    => $fields,
			'schema'    => self::schema_from_form_structure( $schema ),
		] );
	}
}
