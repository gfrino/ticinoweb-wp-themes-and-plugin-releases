<?php
/**
 * WPForms Adapter.
 *
 * @package TicinoWeb\TWFormulari\Adapters
 */

namespace TicinoWeb\TWFormulari\Adapters;

use TicinoWeb\TWFormulari\FormManager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPFormsAdapter implements FormAdapterInterface, FormDiscoveryInterface {

	public function get_id(): string {
		return 'wpforms';
	}

	public function get_name(): string {
		return 'WPForms';
	}

	public function is_available(): bool {
		return function_exists( 'wpforms' ) || class_exists( '\WPForms' );
	}

	public function register_hooks(): void {
		add_action( 'wpforms_process_complete', [ $this, 'handle_process_complete' ], 10, 4 );
	}

	/** @return array<int, array<string, string>> */
	public function get_forms(): array {
		return self::format_form_posts( get_posts( [
			'post_type'      => 'wpforms',
			'post_status'    => 'any',
			'posts_per_page' => 250,
			'orderby'        => 'title',
			'order'          => 'ASC',
			'no_found_rows'  => true,
		] ) );
	}

	/** @return array<int, array<string, mixed>> */
	public function get_form_schema( string $form_id ): array {
		$post = get_post( absint( $form_id ) );
		if ( ! is_object( $post ) || 'wpforms' !== ( $post->post_type ?? '' ) ) {
			return [];
		}
		$form_data = json_decode( (string) ( $post->post_content ?? '' ), true );
		return self::schema_from_form_data( is_array( $form_data ) ? $form_data : [] );
	}

	/**
	 * @param array<string, mixed> $form_data Stored WPForms structure.
	 * @return array<int, array<string, mixed>>
	 */
	public static function schema_from_form_data( array $form_data ): array {
		$schema = [];
		foreach ( (array) ( $form_data['fields'] ?? [] ) as $index => $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}
			$type = sanitize_key( (string) ( $field['type'] ?? 'text' ) );
			if ( in_array( $type, [ 'hidden', 'html', 'content', 'divider', 'entry-preview', 'internal-information', 'layout', 'captcha' ], true ) ) {
				continue;
			}
			$id = sanitize_key( 'field_' . (string) ( $field['id'] ?? $index ) );
			$label = sanitize_text_field( (string) ( $field['label'] ?? $field['name'] ?? $field['page_title'] ?? $id ) );
			if ( 'pagebreak' === $type ) {
				$schema[] = [ 'id' => $id, 'label' => $label ?: 'Nuova sezione', 'type' => 'section', 'options' => [] ];
				continue;
			}
			$options = [];
			foreach ( (array) ( $field['choices'] ?? [] ) as $choice ) {
				$value = is_array( $choice ) ? ( $choice['label'] ?? $choice['value'] ?? '' ) : $choice;
				$value = sanitize_text_field( (string) $value );
				if ( '' !== $value ) {
					$options[] = $value;
				}
			}
			$schema[] = [ 'id' => $id, 'label' => $label ?: $id, 'type' => $type ?: 'text', 'options' => $options ];
		}
		return $schema;
	}

	/**
	 * @param array<int, object> $posts WPForms posts.
	 * @return array<int, array<string, string>>
	 */
	public static function format_form_posts( array $posts ): array {
		$forms = [];
		foreach ( $posts as $post ) {
			$id = sanitize_text_field( (string) ( $post->ID ?? '' ) );
			if ( '' !== $id ) {
				$forms[] = [
					'id'       => $id,
					'name'     => sanitize_text_field( (string) ( $post->post_title ?? '' ) ),
					'location' => '',
				];
			}
		}
		return $forms;
	}

	/**
	 * Handler for WPForms process complete.
	 *
	 * @param array $fields Sanitized form field data.
	 * @param array $entry Entry raw values.
	 * @param array $form_data Form settings and structure.
	 * @param int $entry_id Entry ID.
	 * @return void
	 */
	public function handle_process_complete( $fields, $entry, $form_data, $entry_id ): void {
		$form_id   = (string) ( $form_data['id'] ?? '' );
		$form_name = (string) ( $form_data['settings']['form_title'] ?? '' );

		$formatted_fields = self::format_fields( is_array( $fields ) ? $fields : [] );

		FormManager::get_instance()->handle_submission( [
			'engine'    => $this->get_id(),
			'form_id'   => $form_id,
			'form_name' => $form_name,
			'post_id'   => get_the_ID() ?: 0,
			'submission_id' => (string) $entry_id,
			'fields'    => $formatted_fields,
			'schema'    => self::schema_from_form_data( is_array( $form_data ) ? $form_data : [] ),
		] );
	}

	/**
	 * Converts WPForms fields without using labels as array keys.
	 *
	 * @param array<int, array<string, mixed>> $fields WPForms fields.
	 * @return array<string, array<string, mixed>>
	 */
	public static function format_fields( array $fields ): array {
		$formatted = [];
		foreach ( $fields as $field ) {
			$id  = sanitize_key( 'field_' . (string) ( $field['id'] ?? '' ) );
			$key = $id ?: 'field_' . count( $formatted );
			$formatted[ $key ] = [
				'id'    => $key,
				'title' => sanitize_text_field( (string) ( $field['name'] ?? $key ) ),
				'type'  => sanitize_key( (string) ( $field['type'] ?? 'text' ) ),
				'value' => $field['value'] ?? '',
			];
		}
		return $formatted;
	}
}
