<?php
/**
 * Uninstallation cleanup for TW Formulari.
 *
 * @package TicinoWeb\TWFormulari
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Delete options
delete_option( 'tw_formulari_email_settings' );
delete_option( 'tw_formulari_pdf_settings' );
delete_option( 'tw_formulari_form_settings' );
delete_option( 'tw_formulari_activity_log' );
delete_option( 'tw_formulari_last_status' );
delete_option( 'tw_formulari_db_version' );

foreach ( [ 'elementor', 'cf7', 'wpforms', 'gravityforms', 'fluentforms' ] as $engine ) {
	delete_transient( 'twf_form_choices_' . $engine );
}

wp_clear_scheduled_hook( 'tw_formulari_daily_cleanup' );

global $wpdb;
if ( isset( $wpdb ) && is_object( $wpdb ) && ! empty( $wpdb->options ) ) {
	$submission_like = $wpdb->esc_like( 'twf_submission_lock_' ) . '%';
	$rate_like       = $wpdb->esc_like( 'twf_rate_slot_' ) . '%';
	$names = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s", $submission_like, $rate_like ) );
	foreach ( $names ?: [] as $option_name ) {
		delete_option( $option_name );
	}
}

// Clean temporary directory
$temp_dir = trailingslashit( get_temp_dir() ) . 'tw-formulari-' . substr( hash( 'sha256', wp_salt( 'auth' ) . ABSPATH ), 0, 16 ) . '/';

if ( is_dir( $temp_dir ) && ! is_link( $temp_dir ) ) {
	$files = glob( $temp_dir . '*' );
	if ( ! empty( $files ) ) {
		foreach ( $files as $file ) {
			if ( is_file( $file ) ) {
				@unlink( $file );
			}
		}
	}
	@rmdir( $temp_dir );
}

$legacy_dir = trailingslashit( wp_upload_dir()['basedir'] ) . 'tw_formulari_temp/';
if ( is_dir( $legacy_dir ) && ! is_link( $legacy_dir ) ) {
	foreach ( glob( $legacy_dir . '*.pdf' ) ?: [] as $file ) {
		if ( is_file( $file ) ) {
			@unlink( $file );
		}
	}
	foreach ( [ 'index.php', '.htaccess' ] as $control_file ) {
		if ( is_file( $legacy_dir . $control_file ) ) {
			@unlink( $legacy_dir . $control_file );
		}
	}
	@rmdir( $legacy_dir );
}
