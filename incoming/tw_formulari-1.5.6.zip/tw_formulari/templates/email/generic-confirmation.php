<?php
/**
 * Generic confirmation email template.
 *
 * Variables available:
 * - $data: Normalized generic data array.
 * - $settings: Email and facility settings array.
 * - $pdf_settings: PDF settings array.
 *
 * @package TicinoWeb\TWFormulari
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$facility_name  = $pdf_settings['facility_name'] ?? get_bloginfo( 'name' );
$facility_addr  = $pdf_settings['address'] ?? '';
$facility_city  = $pdf_settings['city'] ?? '';
$facility_phone = $pdf_settings['phone'] ?? '';
$facility_email = $pdf_settings['email'] ?? get_option( 'admin_email' );
$email_intro    = $settings['email_body_intro'] ?? 'Gentile utente, abbiamo ricevuto la tua richiesta.';
$client_name    = $data['client_name'] ?? 'Utente';
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
	body {
		font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
		background-color: #f7f9f6;
		margin: 0;
		padding: 20px;
		color: #333333;
		line-height: 1.6;
	}
	.email-card {
		max-width: 580px;
		margin: 0 auto;
		background: #ffffff;
		border: 1px solid #dbe2da;
		border-radius: 8px;
		overflow: hidden;
		box-shadow: 0 2px 6px rgba(0,0,0,0.04);
	}
	.email-header {
		background-color: #2f522e;
		color: #ffffff;
		padding: 24px 28px;
		text-align: center;
	}
	.email-header h1 {
		margin: 0;
		font-size: 20px;
		font-weight: 600;
	}
	.email-body {
		padding: 28px;
	}
	.highlight-box {
		background-color: #f2f6f1;
		border-left: 4px solid #3d6b3a;
		padding: 14px 16px;
		margin: 20px 0;
		border-radius: 4px;
	}
	.email-footer {
		background-color: #f4f6f3;
		padding: 18px 28px;
		font-size: 12px;
		color: #595f68;
		text-align: center;
		border-top: 1px solid #e5ebe4;
	}
	.contact-info {
		margin-top: 15px;
		padding-top: 15px;
		border-top: 1px dashed #d5ded4;
		font-size: 13px;
		color: #555555;
	}
</style>
</head>
<body>

<div class="email-card">
	<div class="email-header">
		<h1><?php echo esc_html( $facility_name ); ?></h1>
	</div>

	<div class="email-body">
		<p><?php echo nl2br( esc_html( $email_intro ) ); ?></p>

		<div class="highlight-box">
			<strong>Riepilogo in allegato:</strong><br>
			<span style="font-size: 13px; color: #555555;">In allegato a questa email troverete il documento PDF completo con il riepilogo di tutti i dati trasmessi.</span>
		</div>

		<?php if ( ! empty( $facility_addr ) || ! empty( $facility_phone ) || ! empty( $facility_email ) ) : ?>
		<div class="contact-info">
			<strong><?php echo esc_html( $facility_name ); ?></strong><br>
			<?php if ( ! empty( $facility_addr ) ) : ?><?php echo esc_html( $facility_addr ); ?>, <?php echo esc_html( $facility_city ); ?><br><?php endif; ?>
			<?php if ( ! empty( $facility_phone ) ) : ?>Telefono: <?php echo esc_html( $facility_phone ); ?> | <?php endif; ?>
			<?php if ( ! empty( $facility_email ) ) : ?>Email: <a href="mailto:<?php echo esc_attr( $facility_email ); ?>" style="color: #2f522e;"><?php echo esc_html( $facility_email ); ?></a><?php endif; ?>
		</div>
		<?php endif; ?>
	</div>

	<div class="email-footer">
		Questa è una notifica automatica generata dal sito web <?php echo esc_html( $facility_name ); ?>.
	</div>
</div>

</body>
</html>
