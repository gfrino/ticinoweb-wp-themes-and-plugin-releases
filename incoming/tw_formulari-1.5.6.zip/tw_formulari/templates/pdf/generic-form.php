<?php
/**
 * Dynamic single-page A4 PDF template for any supported form.
 *
 * Variables available:
 * - $data: Normalized generic data array.
 * - $settings: PDF and facility settings array.
 * - $logo_src: Safe embedded logo data URI.
 *
 * @package TicinoWeb\TWFormulari
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use function TicinoWeb\TWFormulari\format_display_date;
use function TicinoWeb\TWFormulari\is_date_string;

$facility_name     = $settings['facility_name'] ?? get_bloginfo( 'name' );
$facility_address  = $settings['address'] ?? '';
$facility_city     = $settings['city'] ?? '';
$facility_phone    = $settings['phone'] ?? '';
$facility_email    = $settings['email'] ?? get_option( 'admin_email' );
$document_title    = $settings['document_title'] ?? 'RIEPILOGO RICHIESTA';
$document_subtitle = $settings['document_subtitle'] ?? 'Modulo inviato online';
$mandatory_notice  = $settings['mandatory_notice'] ?? '';
$raw_submission_date = $data['submission_date'] ?? current_time( 'd/m/Y H:i' );
$submission_date     = format_display_date( (string) $raw_submission_date );
$fields            = is_array( $data['fields'] ?? null ) ? $data['fields'] : [];
$sections          = is_array( $data['sections'] ?? null ) ? $data['sections'] : [];

$sections = array_values( array_filter( $sections, static function ( $section ): bool {
	return is_array( $section ) && ! empty( $section['fields'] ) && is_array( $section['fields'] );
} ) );
if ( empty( $sections ) && ! empty( $fields ) ) {
	$sections = [ [ 'title' => 'Dati del formulario', 'fields' => $fields ] ];
}

$field_count      = count( $fields );
$section_count    = count( $sections );
$long_field_count = 0;
foreach ( $fields as $field ) {
	$type  = sanitize_key( (string) ( $field['type'] ?? 'text' ) );
	$value = (string) ( $field['value'] ?? '' );
	if ( in_array( $type, [ 'textarea', 'wysiwyg', 'file', 'upload' ], true ) || false !== strpos( $value, "\n" ) || mb_strlen( $value ) > 110 ) {
		++$long_field_count;
	}
}

$layout_score = $field_count + ( 2 * $section_count ) + ( 2 * $long_field_count ) + ( $mandatory_notice ? 2 : 0 );
if ( $field_count <= 24 && $section_count <= 4 && $layout_score <= 36 ) {
	$density = 'density-airy';
} elseif ( $field_count <= 28 && $layout_score <= 48 ) {
	$density = 'density-spacious';
} elseif ( $field_count <= 38 && $layout_score <= 62 ) {
	$density = 'density-balanced';
} else {
	$density = 'density-compact';
}

$prepare_section = static function ( array $section ): array {
	$section_fields = array_values( array_filter( (array) ( $section['fields'] ?? [] ), 'is_array' ) );
	$count          = count( $section_fields );
	$choice_types   = [ 'checkbox', 'radio', 'select', 'choice', 'acceptance', 'consent' ];
	$choice_count   = 0;
	$column_count   = 2;
	if ( 1 === $count ) {
		$column_count = 1;
	} elseif ( 3 === $count || 5 === $count || $count >= 7 ) {
		$column_count = 3;
	}

	$rows        = [];
	$current_row = [];
	foreach ( $section_fields as $field ) {
		$type    = sanitize_key( (string) ( $field['type'] ?? 'text' ) );
		$value   = (string) ( $field['value'] ?? '' );
		if ( in_array( $type, $choice_types, true ) ) {
			++$choice_count;
		}
		$is_wide = in_array( $type, [ 'textarea', 'wysiwyg', 'file', 'upload' ], true ) || false !== strpos( $value, "\n" ) || mb_strlen( $value ) > 110;

		if ( $is_wide ) {
			if ( ! empty( $current_row ) ) {
				$rows[]      = $current_row;
				$current_row = [];
			}
			$field['_twf_wide'] = true;
			$rows[]              = [ $field ];
			continue;
		}

		$current_row[] = $field;
		if ( count( $current_row ) === $column_count ) {
			$rows[]      = $current_row;
			$current_row = [];
		}
	}
	if ( ! empty( $current_row ) ) {
		$rows[] = $current_row;
	}

	return [
		'title'        => sanitize_text_field( (string) ( $section['title'] ?? '' ) ),
		'column_count' => $column_count,
		'rows'         => $rows,
		'choice_focus' => $choice_count >= 2 && $choice_count >= (int) ceil( $count / 2 ),
	];
};

$prepared_sections = array_map( $prepare_section, $sections );
$facility_location = trim( $facility_address . ( $facility_address && $facility_city ? ', ' : '' ) . $facility_city );
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
	@page {
		margin-top: 9mm;
		margin-bottom: 10mm;
		margin-left: 12mm;
		margin-right: 12mm;
		footer: html_pdfFooter;
	}
	body {
		font-family: 'DejaVu Sans', 'Helvetica Neue', Arial, sans-serif;
		font-size: 8.8pt;
		line-height: 1.34;
		color: #2d3748;
		background: #ffffff;
	}
	.header-container {
		padding: 10px 14px 9px;
		border-radius: 3px 3px 0 0;
		background-color: #f4f7f2;
	}
	.header-main-table,
	.header-accent-table,
	.section-heading-table,
	.fields-grid,
	.footer-bar-table {
		width: 100%;
		border-collapse: collapse;
	}
	.header-logo-cell { width: 30%; vertical-align: middle; }
	.header-logo-img { max-width: 210px; max-height: 44px; width: auto; }
	.header-center-cell { width: 40%; padding: 0 4px; text-align: center; vertical-align: middle; }
	.header-doc-title { font-size: 15pt; font-weight: bold; line-height: 1.14; color: #1e3a1d; letter-spacing: 0.55px; text-transform: uppercase; }
	.header-doc-sub { margin-top: 3px; font-size: 7.8pt; font-weight: bold; color: #4a6b48; letter-spacing: 0.45px; text-transform: uppercase; }
	.header-right-cell { width: 30%; font-size: 7.5pt; line-height: 1.35; color: #4a5568; text-align: right; vertical-align: middle; }
	.header-facility-name { margin-bottom: 2px; font-size: 9.5pt; font-weight: bold; color: #1e3a1d; }
	.header-accent-table { height: 3px; margin-bottom: 10px; }
	.accent-green { width: 82%; height: 3px; background: #2b5329; }
	.accent-orange { width: 18%; height: 3px; background: #d9533f; }

	.section-wrap { margin-bottom: 8px; page-break-inside: avoid; }
	.section-bar { margin-bottom: 4px; padding: 5px 9px; border-left: 3px solid #2b5329; border-radius: 2px; background: #f2f7f1; }
	.section-number { width: 28px; font-size: 8.8pt; font-weight: bold; color: #2b5329; }
	.section-title { font-size: 8.4pt; font-weight: bold; color: #1a202c; letter-spacing: 0.3px; text-transform: uppercase; }
	.section-date { font-size: 7.2pt; color: #64748b; text-align: right; }
	.fields-card { padding: 7px 10px; border: 0.8px solid #e2e8f0; border-radius: 3px; background: #fafbf9; }
	.fields-grid tr { page-break-inside: avoid; }
	.field-cell { padding: 6px 9px 7px 4px; border-bottom: 0.5px solid #edf2f7; vertical-align: top; }
	.fields-grid tr:last-child .field-cell,
	.fields-grid tr:last-child .empty-cell { border-bottom: 0; }
	.field-label { margin-bottom: 3px; font-size: 6.8pt; font-weight: bold; line-height: 1.18; color: #64748b; letter-spacing: 0.22px; text-transform: uppercase; }
	.field-value { font-size: 8.9pt; line-height: 1.28; color: #1e293b; }
	.field-value.is-choice { font-weight: bold; color: #1e3a1d; }
	.empty-value { color: #94a3b8; font-style: italic; }
	.empty-cell { border-bottom: 0.5px solid #edf2f7; }

	.density-airy .section-wrap { margin-bottom: 11px; }
	.density-airy .section-bar { padding-top: 6px; padding-bottom: 6px; }
	.density-airy .fields-card { padding-top: 9px; padding-bottom: 9px; }
	.density-airy .field-cell { padding-top: 11px; padding-bottom: 12px; }
	.density-airy .field-label { font-size: 7.1pt; }
	.density-airy .field-value { font-size: 9.5pt; }
	.density-spacious .section-wrap { margin-bottom: 11px; }
	.density-spacious .section-bar { padding-top: 6px; padding-bottom: 6px; }
	.density-spacious .fields-card { padding-top: 9px; padding-bottom: 9px; }
	.density-spacious .field-cell { padding-top: 9px; padding-bottom: 10px; }
	.density-spacious .field-value { font-size: 9.2pt; }
	.density-balanced .section-wrap { margin-bottom: 6px; }
	.density-balanced .section-bar { padding-top: 4px; padding-bottom: 4px; }
	.density-balanced .field-cell { padding-top: 4px; padding-bottom: 5px; }
	.density-compact .section-wrap { margin-bottom: 4px; }
	.density-compact .section-bar { margin-bottom: 3px; padding-top: 3px; padding-bottom: 3px; }
	.density-compact .fields-card { padding: 4px 7px; }
	.density-compact .field-cell { padding: 2px 5px 3px 3px; }
	.density-compact .field-label { margin-bottom: 1px; font-size: 5.8pt; line-height: 1.08; }
	.density-compact .field-value { font-size: 7.5pt; line-height: 1.14; }

	.choice-focus-section .fields-card { padding-top: 8px; padding-bottom: 8px; border-color: #cbdcc9; background: #f8fbf7; }
	.choice-focus-section .section-number { font-size: 9.8pt; }
	.choice-focus-section .section-title { font-size: 9.4pt; }
	.choice-focus-section .field-cell { padding-top: 7px; padding-bottom: 8px; }
	.choice-focus-section .field-label { margin-bottom: 4px; font-size: 9.5pt; line-height: 1.2; color: #415f43; letter-spacing: 0.18px; }
	.choice-focus-section .field-value { font-size: 11.2pt; line-height: 1.3; }
	.choice-focus-section .emphasized-choice { display: inline-block; padding: 3px 8px; border: 0.7px solid #91b58d; border-radius: 10px; background: #e9f4e7; color: #173f1b; font-size: 11.4pt; font-weight: bold; }
	.density-compact .choice-focus-section .fields-card { padding-top: 5px; padding-bottom: 5px; }
	.density-compact .choice-focus-section .field-cell { padding-top: 4px; padding-bottom: 5px; }
	.density-compact .choice-focus-section .field-label { margin-bottom: 2px; font-size: 8.6pt; line-height: 1.14; }
	.density-compact .choice-focus-section .field-value { font-size: 10pt; line-height: 1.2; }
	.density-compact .choice-focus-section .emphasized-choice { padding: 2px 6px; font-size: 10.3pt; }

	.notice-box { margin-top: 9px; padding: 9px 12px; border: 0.8px solid #e2e8f0; border-left: 3px solid #d9533f; border-radius: 3px; background: #fafbf9; page-break-inside: avoid; }
	.notice-title { margin-bottom: 4px; font-size: 8pt; font-weight: bold; color: #8e2b1d; letter-spacing: 0.3px; text-transform: uppercase; }
	.notice-text { margin: 0; font-size: 8pt; line-height: 1.42; color: #4a5568; }
	.density-compact .notice-box { margin-top: 5px; padding: 6px 9px; }
	.density-compact .notice-text { font-size: 7pt; line-height: 1.25; }
	.footer-bar-table { padding-top: 3px; border-top: 0.5px solid #cbd5e1; font-size: 6.8pt; color: #718096; }
</style>
</head>
<body class="<?php echo esc_attr( $density ); ?>">

<htmlpagefooter name="pdfFooter">
	<table class="footer-bar-table">
		<tr>
			<td style="width: 35%; text-align: left; font-weight: bold; color: #4a5568;"><?php echo esc_html( $facility_name ); ?></td>
			<td style="width: 45%; text-align: center;">
				<?php echo esc_html( $facility_location ); ?>
				<?php if ( ! empty( $facility_phone ) ) : ?> · Tel. <?php echo esc_html( $facility_phone ); ?><?php endif; ?>
			</td>
			<td style="width: 20%; text-align: right;">Pagina {PAGENO} di {nbpg}</td>
		</tr>
	</table>
</htmlpagefooter>

<div class="header-container">
	<table class="header-main-table">
		<tr>
			<td class="header-logo-cell">
				<?php if ( ! empty( $logo_src ) ) : ?>
					<img src="<?php echo esc_attr( $logo_src ); ?>" class="header-logo-img" alt="Logo" />
				<?php else : ?>
					<div class="header-facility-name"><?php echo esc_html( $facility_name ); ?></div>
				<?php endif; ?>
			</td>
			<td class="header-center-cell">
				<div class="header-doc-title"><?php echo esc_html( $document_title ); ?></div>
				<?php if ( ! empty( $document_subtitle ) ) : ?><div class="header-doc-sub"><?php echo esc_html( $document_subtitle ); ?></div><?php endif; ?>
			</td>
			<td class="header-right-cell">
				<div class="header-facility-name"><?php echo esc_html( $facility_name ); ?></div>
				<?php if ( ! empty( $facility_location ) ) : ?><div><?php echo esc_html( $facility_location ); ?></div><?php endif; ?>
				<?php if ( ! empty( $facility_phone ) ) : ?><div>Tel. <?php echo esc_html( $facility_phone ); ?></div><?php endif; ?>
				<?php if ( ! empty( $facility_email ) ) : ?><div><?php echo esc_html( $facility_email ); ?></div><?php endif; ?>
			</td>
		</tr>
	</table>
</div>
<table class="header-accent-table"><tr><td class="accent-green"></td><td class="accent-orange"></td></tr></table>

<?php if ( empty( $prepared_sections ) ) : ?>
	<div class="fields-card"><div class="empty-value" style="padding: 8px; text-align: center;">Nessun campo registrato nel modulo.</div></div>
<?php else : ?>
	<?php foreach ( $prepared_sections as $section_index => $section ) : ?>
		<div class="section-wrap <?php echo ! empty( $section['choice_focus'] ) ? 'choice-focus-section' : ''; ?>">
			<div class="section-bar">
				<table class="section-heading-table">
					<tr>
						<td class="section-number"><?php echo esc_html( str_pad( (string) ( $section_index + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></td>
						<td class="section-title"><?php echo esc_html( $section['title'] ?: sprintf( 'Sezione %d', $section_index + 1 ) ); ?></td>
						<?php if ( 0 === $section_index ) : ?><td class="section-date">Inviato il <?php echo esc_html( $submission_date ); ?></td><?php endif; ?>
					</tr>
				</table>
			</div>
			<div class="fields-card">
				<table class="fields-grid">
					<?php foreach ( $section['rows'] as $row ) : ?>
						<?php $is_wide_row = ! empty( $row[0]['_twf_wide'] ); ?>
						<tr>
							<?php foreach ( $row as $field ) : ?>
								<?php
								$label = (string) ( $field['label'] ?? $field['key'] ?? '' );
								$value = (string) ( $field['value'] ?? '' );
								$type  = sanitize_key( (string) ( $field['type'] ?? 'text' ) );
								if ( in_array( $type, [ 'date', 'datepicker', 'datetime', 'date-time', 'date_time' ], true ) || is_date_string( $value ) ) {
									$value = format_display_date( $value );
								}
								?>
								<td class="field-cell" style="width: <?php echo esc_attr( $is_wide_row ? '100%' : ( 100 / $section['column_count'] ) . '%' ); ?>;">
									<div class="field-label"><?php echo esc_html( $label ); ?></div>
								<div class="field-value <?php echo in_array( $type, [ 'checkbox', 'radio', 'select', 'choice', 'acceptance', 'consent' ], true ) ? 'is-choice' : ''; ?> <?php echo ! empty( $section['choice_focus'] ) && in_array( $type, [ 'checkbox', 'radio', 'select', 'choice', 'acceptance', 'consent' ], true ) ? 'emphasized-choice' : ''; ?> <?php echo '' === trim( $value ) || '—' === $value ? 'empty-value' : ''; ?>"><?php echo nl2br( esc_html( '' === trim( $value ) ? '—' : $value ) ); ?></div>
								</td>
							<?php endforeach; ?>
							<?php if ( ! $is_wide_row && count( $row ) < $section['column_count'] ) : ?>
								<?php for ( $empty = count( $row ); $empty < $section['column_count']; ++$empty ) : ?>
									<td class="empty-cell" style="width: <?php echo esc_attr( ( 100 / $section['column_count'] ) . '%' ); ?>;"></td>
								<?php endfor; ?>
							<?php endif; ?>
						</tr>
					<?php endforeach; ?>
				</table>
			</div>
		</div>
	<?php endforeach; ?>
<?php endif; ?>

<?php if ( ! empty( $mandatory_notice ) ) : ?>
	<div class="notice-box">
		<div class="notice-title">Note e informazioni</div>
		<p class="notice-text"><?php echo nl2br( esc_html( $mandatory_notice ) ); ?></p>
	</div>
<?php endif; ?>

</body>
</html>
