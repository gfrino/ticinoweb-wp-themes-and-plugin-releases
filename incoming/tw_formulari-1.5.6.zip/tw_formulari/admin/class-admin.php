<?php
/**
 * Admin controller for TW Formulari.
 *
 * @package TicinoWeb\TWFormulari
 */

namespace TicinoWeb\TWFormulari;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Admin {

	/** @var string */
	private $hook_suffix = '';

	/** @return void */
	public function init(): void {
		add_action( 'admin_menu', [ $this, 'register_admin_menu' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_assets' ] );
		add_action( 'admin_post_twf_save_settings', [ $this, 'handle_save_settings' ] );
		add_action( 'admin_post_twf_generate_test_pdf', [ $this, 'handle_generate_test_pdf' ] );
		add_action( 'wp_ajax_twf_get_forms', [ $this, 'handle_get_forms' ] );
	}

	/** @return void */
	public function register_admin_menu(): void {
		$this->hook_suffix = add_menu_page(
			__( 'TW Formulari', 'tw-formulari' ),
			__( 'TW Formulari', 'tw-formulari' ),
			'manage_options',
			'tw-formulari',
			[ $this, 'render_page' ],
			'dashicons-media-document',
			32
		);
	}

	/**
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public function enqueue_admin_assets( string $hook ): void {
		if ( $hook !== $this->hook_suffix ) {
			return;
		}

		wp_enqueue_media();
		wp_enqueue_style( 'twf-admin-style', TW_FORMULARI_URL . 'admin/assets/admin.css', [], TW_FORMULARI_VERSION );
		wp_enqueue_script( 'twf-admin-script', TW_FORMULARI_URL . 'admin/assets/admin.js', [ 'jquery' ], TW_FORMULARI_VERSION, true );
		$form_settings = Settings::get_form_settings();
		wp_localize_script( 'twf-admin-script', 'twfAdmin', [
			'ajaxUrl'       => admin_url( 'admin-ajax.php' ),
			'nonce'         => wp_create_nonce( 'twf_discover_forms' ),
			'currentEngine' => $form_settings['active_engine'] ?? 'auto',
			'currentFormId' => $form_settings['target_form_id'] ?? '',
			'strings'       => [
				'choose'       => __( 'Seleziona un formulario', 'tw-formulari' ),
				'loading'      => __( 'Ricerca dei formulari…', 'tw-formulari' ),
				'empty'        => __( 'Nessun formulario rilevato. Puoi inserire l’ID nelle impostazioni avanzate.', 'tw-formulari' ),
				'chooseEngine' => __( 'Sono presenti più sistemi: selezionane uno per vedere i suoi formulari.', 'tw-formulari' ),
				'manual'       => __( 'Per un modulo POST personalizzato, inserisci l’ID nelle impostazioni avanzate.', 'tw-formulari' ),
				'required'     => __( 'Seleziona un formulario oppure inserisci l’ID manuale nelle impostazioni avanzate.', 'tw-formulari' ),
				'error'        => __( 'Impossibile aggiornare l’elenco. Riprova o usa l’ID manuale.', 'tw-formulari' ),
				'current'      => __( 'Configurazione attuale', 'tw-formulari' ),
				'formsFound'   => __( '%d formulari rilevati.', 'tw-formulari' ),
				'oneFormFound' => __( '1 formulario rilevato.', 'tw-formulari' ),
			],
		] );
	}

	/** @return void */
	public function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Accesso non consentito.', 'tw-formulari' ) );
		}

		$message       = sanitize_key( $_GET['message'] ?? '' );
		$form_settings = Settings::get_form_settings();
		$active_engine = $form_settings['active_engine'] ?? 'auto';
		$engine_ready  = 'auto' !== $active_engine;
		if ( 'auto' === $active_engine ) {
			$native = array_filter( FormManager::get_instance()->get_available_adapters(), static function ( $adapter ): bool { return 'generic' !== $adapter->get_id(); } );
			$engine_ready = 1 === count( $native );
		}
		$is_configured = $engine_ready && '' !== trim( (string) ( $form_settings['target_form_id'] ?? '' ) );
		?>
		<div class="wrap twf-wrap">
			<header class="twf-header">
				<div>
					<div class="twf-title-row">
						<h1>TW Formulari</h1>
						<span class="twf-version">v<?php echo esc_html( TW_FORMULARI_VERSION ); ?></span>
					</div>
					<p>Collega un formulario, invia le conferme e genera automaticamente il PDF.</p>
				</div>
				<span class="twf-active <?php echo $is_configured ? 'is-ready' : 'needs-setup'; ?>"><span aria-hidden="true"></span><?php echo $is_configured ? esc_html__( 'Configurato', 'tw-formulari' ) : esc_html__( 'Da configurare', 'tw-formulari' ); ?></span>
			</header>

			<?php if ( 'saved' === $message ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Impostazioni salvate.', 'tw-formulari' ); ?></p></div>
			<?php elseif ( 'missing_form' === $message ) : ?>
				<div class="notice notice-error"><p><?php esc_html_e( 'Seleziona il formulario da gestire oppure inserisci il suo ID nelle impostazioni avanzate.', 'tw-formulari' ); ?></p></div>
			<?php endif; ?>

			<?php require TW_FORMULARI_PATH . 'admin/views/settings.php'; ?>
		</div>
		<?php
	}

	/** @return void */
	public function handle_save_settings(): void {
		check_admin_referer( 'twf_save_settings_action', 'twf_settings_nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Permessi insufficienti.', 'tw-formulari' ) );
		}

		$form  = isset( $_POST['twf_form'] ) && is_array( $_POST['twf_form'] ) ? wp_unslash( $_POST['twf_form'] ) : [];
		$email = isset( $_POST['twf_email'] ) && is_array( $_POST['twf_email'] ) ? wp_unslash( $_POST['twf_email'] ) : [];
		$pdf   = isset( $_POST['twf_pdf'] ) && is_array( $_POST['twf_pdf'] ) ? wp_unslash( $_POST['twf_pdf'] ) : [];

		$form['target_form_id'] = Settings::resolve_target_form_id( $form );
		if ( '' === $form['target_form_id'] ) {
			wp_safe_redirect( admin_url( 'admin.php?page=tw-formulari&message=missing_form' ) );
			exit;
		}

		Settings::save_form_settings( $form );
		Settings::save_email_settings( $email );
		Settings::save_pdf_settings( $pdf );

		if ( ! empty( $_POST['twf_preview'] ) ) {
			$this->stream_current_demo();
		}

		wp_safe_redirect( admin_url( 'admin.php?page=tw-formulari&message=saved' ) );
		exit;
	}

	/** @return void */
	public function handle_get_forms(): void {
		check_ajax_referer( 'twf_discover_forms', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => __( 'Permessi insufficienti.', 'tw-formulari' ) ], 403 );
		}

		$engine = sanitize_key( wp_unslash( $_POST['engine'] ?? '' ) );
		$force  = ! empty( $_POST['force'] );
		$manager = FormManager::get_instance();
		$resolved_engine = $manager->resolve_engine_id( $engine );
		if ( '' === $resolved_engine ) {
			wp_send_json_success( [ 'forms' => [], 'resolvedEngine' => '' ] );
			return;
		}

		$adapters = $manager->get_adapters();
		if ( ! isset( $adapters[ $resolved_engine ] ) || ( 'generic' !== $resolved_engine && ! $adapters[ $resolved_engine ]->is_available() ) ) {
			wp_send_json_error( [ 'message' => __( 'Il sistema formulario selezionato non è disponibile.', 'tw-formulari' ) ], 400 );
			return;
		}

		try {
			$forms = $manager->get_forms_for_engine( $resolved_engine, $force );
		} catch ( \Throwable ) {
			wp_send_json_error( [ 'message' => __( 'Impossibile leggere i formulari dal sistema selezionato.', 'tw-formulari' ) ], 500 );
			return;
		}

		wp_send_json_success( [
			'forms'          => $forms,
			'resolvedEngine' => $resolved_engine,
		] );
	}

	/** @return void */
	public function handle_generate_test_pdf(): void {
		check_admin_referer( 'twf_test_pdf_action' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Permessi insufficienti.', 'tw-formulari' ) );
		}
		$this->stream_current_demo();
	}

	/** @return void */
	private function stream_current_demo(): void {
		$settings = Settings::get_form_settings();
		try {
			$data = FormManager::get_instance()->get_preview_data_for_form(
				(string) ( $settings['active_engine'] ?? 'auto' ),
				(string) ( $settings['target_form_id'] ?? '' )
			);
		} catch ( \Throwable $error ) {
			wp_die( esc_html__( 'Impossibile leggere i campi aggiornati del formulario selezionato. Aggiorna l’elenco dei formulari e verifica la configurazione.', 'tw-formulari' ) );
		}

		try {
			PdfGenerator::stream_to_browser( $data, 'I' );
			exit;
		} catch ( \Throwable $error ) {
			wp_die( esc_html__( 'Impossibile generare il PDF di prova. Verifica che il pacchetto del plugin e le estensioni PHP richieste siano disponibili.', 'tw-formulari' ) );
		}
	}
}
