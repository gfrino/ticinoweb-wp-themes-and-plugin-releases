<?php
/**
 * Single settings view.
 *
 * @package TicinoWeb\TWFormulari
 */

use TicinoWeb\TWFormulari\FormManager;
use TicinoWeb\TWFormulari\Logger;
use TicinoWeb\TWFormulari\Settings;
use function TicinoWeb\TWFormulari\format_display_date;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$form_settings  = Settings::get_form_settings();
$email_settings = Settings::get_email_settings();
$pdf_settings   = Settings::get_pdf_settings();
$last_status    = Logger::get_last_entry();
$adapters       = FormManager::get_instance()->get_adapters();
$preview_url    = wp_nonce_url( admin_url( 'admin-post.php?action=twf_generate_test_pdf' ), 'twf_test_pdf_action' );
?>

<?php if ( $last_status ) : ?>
	<div class="twf-last-status twf-status-<?php echo esc_attr( $last_status['status'] ); ?>" role="status">
		<span class="dashicons <?php echo 'success' === $last_status['status'] ? 'dashicons-yes-alt' : 'dashicons-warning'; ?>" aria-hidden="true"></span>
		<div>
			<strong><?php echo 'success' === $last_status['status'] ? esc_html__( 'Ultimo invio completato', 'tw-formulari' ) : esc_html__( 'Ultimo invio non completato', 'tw-formulari' ); ?></strong>
			<span><?php echo esc_html( $last_status['message'] ); ?> · <?php echo esc_html( format_display_date( (string) $last_status['timestamp'] ) ); ?></span>
		</div>
	</div>
<?php endif; ?>

<form id="twf-settings-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
	<?php wp_nonce_field( 'twf_save_settings_action', 'twf_settings_nonce' ); ?>
	<input type="hidden" name="action" value="twf_save_settings">

	<div class="twf-layout">
		<main class="twf-settings-panel">
			<section class="twf-section twf-section-form" aria-labelledby="twf-form-heading">
				<div class="twf-section-copy">
					<h2 id="twf-form-heading">1. Formulario</h2>
					<p>Il plugin gestisce un solo formulario su questo sito.</p>
				</div>
				<div class="twf-fields twf-form-fields">
					<div class="twf-field">
						<label for="twf-active-engine">Sistema utilizzato</label>
						<select id="twf-active-engine" name="twf_form[active_engine]" aria-describedby="twf-engine-help">
							<option value="auto" <?php selected( $form_settings['active_engine'], 'auto' ); ?>>Automatico — richiede un solo builder installato</option>
							<?php foreach ( $adapters as $adapter_id => $adapter ) : ?>
								<?php if ( 'generic' !== $adapter_id && ! $adapter->is_available() && $form_settings['active_engine'] !== $adapter_id ) { continue; } ?>
								<option value="<?php echo esc_attr( $adapter_id ); ?>" <?php selected( $form_settings['active_engine'], $adapter_id ); ?>><?php echo esc_html( $adapter->get_name() ); ?><?php echo $adapter->is_available() ? esc_html__( ' — disponibile', 'tw-formulari' ) : ''; ?></option>
							<?php endforeach; ?>
						</select>
						<p id="twf-engine-help" class="description">Se sono installati più builder, seleziona quello del formulario. Il modulo POST personalizzato va sempre attivato esplicitamente.</p>
					</div>

					<div class="twf-field twf-form-picker">
						<label for="twf-target-form">Formulario da collegare</label>
						<div class="twf-picker-control">
							<select id="twf-target-form" name="twf_form[target_form_id]" aria-describedby="twf-form-id-help twf-form-discovery-status">
								<option value=""><?php esc_html_e( 'Seleziona un formulario', 'tw-formulari' ); ?></option>
								<?php if ( '' !== trim( (string) $form_settings['target_form_id'] ) ) : ?>
									<option value="<?php echo esc_attr( $form_settings['target_form_id'] ); ?>" selected><?php echo esc_html( sprintf( __( 'Configurazione attuale — ID: %s', 'tw-formulari' ), $form_settings['target_form_id'] ) ); ?></option>
								<?php endif; ?>
							</select>
							<button id="twf-refresh-forms" type="button" class="button" aria-describedby="twf-form-discovery-status">
								<span class="dashicons dashicons-update" aria-hidden="true"></span>
								<span><?php esc_html_e( 'Aggiorna elenco', 'tw-formulari' ); ?></span>
							</button>
						</div>
						<p id="twf-form-id-help" class="description">Mostra nome, pagina quando disponibile e ID. Soltanto il formulario selezionato verrà elaborato.</p>
						<p id="twf-form-discovery-status" class="twf-discovery-status" role="status" aria-live="polite"></p>
					</div>

					<div id="twf-generic-help" class="twf-inline-help" hidden>
						<strong>Modulo personalizzato</strong>
						<p>Inserisci lo shortcode <code>[tw_formulari_security_fields]</code> nel form e invia anche <code>twf_form_id</code> con lo stesso ID indicato sopra.</p>
					</div>
				</div>
			</section>

			<section class="twf-section twf-section-delivery" aria-labelledby="twf-delivery-heading">
				<div class="twf-section-copy">
					<h2 id="twf-delivery-heading">2. Consegna</h2>
					<p>Le conferme seguono automaticamente i campi email presenti nel formulario.</p>
				</div>
				<div class="twf-fields twf-delivery-fields">
					<div class="twf-auto-delivery" role="note">
						<span class="dashicons dashicons-email-alt" aria-hidden="true"></span>
						<div>
							<strong>Conferme automatiche</strong>
							<p>Il PDF viene inviato a ogni indirizzo valido trovato nei campi email certificati dal form builder.</p>
							<small>Campi vuoti, indirizzi non validi e duplicati vengono ignorati. I moduli POST personalizzati, privi di uno schema verificabile, inviano soltanto la copia interna.</small>
						</div>
					</div>
					<label class="twf-check"><input id="twf-send-facility" type="checkbox" name="twf_email[send_facility]" value="1" <?php checked( $email_settings['send_facility'], 1 ); ?>><span><strong>Invia una copia interna</strong><small>Notifica l’azienda o la struttura.</small></span></label>

					<div class="twf-field" id="twf-facility-email-row">
						<label for="twf-facility-email">Email interna</label>
						<input id="twf-facility-email" type="email" name="twf_email[facility_email]" value="<?php echo esc_attr( $email_settings['facility_email'] ); ?>">
					</div>
					<div class="twf-field">
						<label for="twf-email-subject">Oggetto email</label>
						<input id="twf-email-subject" type="text" name="twf_email[email_subject]" value="<?php echo esc_attr( $email_settings['email_subject'] ); ?>">
					</div>
					<div class="twf-field">
						<label for="twf-email-intro">Messaggio introduttivo</label>
						<textarea id="twf-email-intro" name="twf_email[email_body_intro]" rows="3"><?php echo esc_textarea( $email_settings['email_body_intro'] ); ?></textarea>
					</div>
				</div>
			</section>

			<section class="twf-section twf-section-document" aria-labelledby="twf-document-heading">
				<div class="twf-section-copy">
					<h2 id="twf-document-heading">3. Documento PDF</h2>
					<p>I campi e i valori arrivano dal formulario; qui imposti solo identità e testo fisso.</p>
				</div>
				<div class="twf-fields twf-document-fields">
					<div class="twf-field"><label for="twf-facility-name">Nome azienda o struttura</label><input id="twf-facility-name" type="text" name="twf_pdf[facility_name]" value="<?php echo esc_attr( $pdf_settings['facility_name'] ); ?>" required></div>
					<div class="twf-field twf-logo-field">
						<span class="twf-field-label">Logo <span class="twf-optional">facoltativo</span></span>
						<input id="twf-logo-url-input" type="hidden" name="twf_pdf[logo_url]" value="<?php echo esc_attr( $pdf_settings['logo_url'] ); ?>">
						<div class="twf-logo-actions">
							<button type="button" id="twf-upload-logo-btn" class="button">Scegli dalla Libreria Media</button>
							<button type="button" id="twf-reset-logo-btn" class="button-link-delete">Rimuovi</button>
							<img id="twf-logo-img" src="<?php echo esc_url( $pdf_settings['logo_url'] ); ?>" alt="" <?php echo empty( $pdf_settings['logo_url'] ) ? 'hidden' : ''; ?>>
						</div>
					</div>
					<div class="twf-grid-two">
						<div class="twf-field"><label for="twf-document-title">Titolo documento</label><input id="twf-document-title" type="text" name="twf_pdf[document_title]" value="<?php echo esc_attr( $pdf_settings['document_title'] ); ?>"></div>
						<div class="twf-field"><label for="twf-document-subtitle">Sottotitolo</label><input id="twf-document-subtitle" type="text" name="twf_pdf[document_subtitle]" value="<?php echo esc_attr( $pdf_settings['document_subtitle'] ); ?>"></div>
					</div>
					<div class="twf-field"><label for="twf-mandatory-notice">Nota in fondo al documento <span class="twf-optional">facoltativa</span></label><textarea id="twf-mandatory-notice" name="twf_pdf[mandatory_notice]" rows="3"><?php echo esc_textarea( $pdf_settings['mandatory_notice'] ); ?></textarea></div>
				</div>
			</section>

			<details class="twf-advanced">
				<summary>Impostazioni avanzate</summary>
				<div class="twf-advanced-grid">
					<div class="twf-field">
						<label for="twf-target-form-manual">ID formulario manuale</label>
						<input id="twf-target-form-manual" type="text" name="twf_form[target_form_id_manual]" value="" aria-describedby="twf-manual-form-help" placeholder="es. contact-12 o 347">
						<p id="twf-manual-form-help" class="description">Usalo solo se il formulario non compare nell’elenco. Se compilato, sostituisce la selezione.</p>
					</div>
					<div class="twf-field"><label for="twf-sender-name">Nome mittente</label><input id="twf-sender-name" type="text" name="twf_email[sender_name]" value="<?php echo esc_attr( $email_settings['sender_name'] ); ?>"></div>
					<div class="twf-field"><label for="twf-sender-email">Email mittente</label><input id="twf-sender-email" type="email" name="twf_email[sender_email]" value="<?php echo esc_attr( $email_settings['sender_email'] ); ?>"></div>
					<div class="twf-field"><label for="twf-address">Indirizzo</label><input id="twf-address" type="text" name="twf_pdf[address]" value="<?php echo esc_attr( $pdf_settings['address'] ); ?>"></div>
					<div class="twf-field"><label for="twf-city">CAP / Località</label><input id="twf-city" type="text" name="twf_pdf[city]" value="<?php echo esc_attr( $pdf_settings['city'] ); ?>"></div>
					<div class="twf-field"><label for="twf-phone">Telefono</label><input id="twf-phone" type="text" name="twf_pdf[phone]" value="<?php echo esc_attr( $pdf_settings['phone'] ); ?>"></div>
					<div class="twf-field"><label for="twf-contact-email">Email sul PDF</label><input id="twf-contact-email" type="email" name="twf_pdf[email]" value="<?php echo esc_attr( $pdf_settings['email'] ); ?>"></div>
				</div>
			</details>

			<footer class="twf-actions">
				<span id="twf-unsaved" aria-live="polite"></span>
				<div><button type="submit" name="twf_preview" value="1" formtarget="_blank" class="button button-secondary">Salva e apri anteprima <span class="screen-reader-text">(si apre in una nuova scheda)</span></button><button type="submit" class="button button-primary">Salva impostazioni</button></div>
			</footer>
		</main>

		<aside class="twf-side-panel" aria-labelledby="twf-preview-heading">
			<h2 id="twf-preview-heading">Anteprima PDF</h2>
			<p>Legge i campi aggiornati del formulario selezionato e usa valori dimostrativi.</p>
			<a href="<?php echo esc_url( $preview_url ); ?>" target="_blank" rel="noopener" class="button button-secondary">Apri anteprima salvata <span class="screen-reader-text">(si apre in una nuova scheda)</span></a>
			<hr>
			<p class="twf-privacy"><span class="dashicons dashicons-shield" aria-hidden="true"></span><span>Il PDF della richiesta è temporaneo, ha un nome anonimo e viene eliminato dopo l’invio.</span></p>
		</aside>
	</div>
</form>
