<?php
/**
 * Signup form builder: pick a list by name, set the options, see a live
 * preview and copy a ready-made [wpnews_subscribe_form] shortcode.
 *
 * Expects:
 *   $wpnews_builder_lists    array of lists (WPNews_List_Manager::get_lists()).
 *   $wpnews_builder_selected int   list preselected (0 = first list).
 *
 * The preview markup mirrors WPNews_Public::render_subscribe_form_shortcode()
 * and uses public/css/public.css; admin/js/admin.js keeps it in sync.
 *
 * @package WPNews
 */

if (!defined('ABSPATH')) {
	exit;
}

$wpnews_builder_lists    = isset($wpnews_builder_lists) && is_array($wpnews_builder_lists) ? $wpnews_builder_lists : array();
$wpnews_builder_selected = isset($wpnews_builder_selected) ? (int) $wpnews_builder_selected : 0;
$wpnews_privacy_url      = get_privacy_policy_url();
?>
<div class="wpnews-card wpnews-builder" id="wpnews-signup-builder">
	<div class="wpnews-card-title">
		<span class="dashicons dashicons-feedback wpnews-text-indigo"></span>
		<h3><?php esc_html_e('Signup form for your website', 'wp-news'); ?></h3>
	</div>

	<?php if (empty($wpnews_builder_lists)) : ?>
		<p class="wpnews-muted-text"><?php esc_html_e('Create a mailing list first: the signup form adds new subscribers to it.', 'wp-news'); ?></p>
	<?php else : ?>
		<p class="wpnews-muted-text wpnews-builder__intro">
			<?php esc_html_e('1. Choose the list  ·  2. Adjust the form  ·  3. Copy the code and paste it into any page, post or widget.', 'wp-news'); ?>
		</p>

		<div class="wpnews-builder__grid">
			<div class="wpnews-builder__controls">
				<label class="wpnews-field-label" for="wpnews-b-list"><?php esc_html_e('New subscribers join the list', 'wp-news'); ?></label>
				<select id="wpnews-b-list" class="wpnews-input" data-b="list">
					<?php foreach ($wpnews_builder_lists as $wpnews_l) :
						$wpnews_lid = (int) ($wpnews_l['id'] ?? 0);
						$wpnews_cnt = (int) ($wpnews_l['subscriber_count'] ?? 0);
						?>
						<option value="<?php echo esc_attr($wpnews_lid); ?>" <?php selected($wpnews_builder_selected, $wpnews_lid); ?>>
							<?php
							echo esc_html(sprintf(
								/* translators: 1: list name, 2: number of subscribers */
								_n('%1$s (%2$s subscriber)', '%1$s (%2$s subscribers)', $wpnews_cnt, 'wp-news'),
								(string) ($wpnews_l['name'] ?? ''),
								number_format_i18n($wpnews_cnt)
							));
							?>
						</option>
					<?php endforeach; ?>
				</select>

				<label class="wpnews-field-label" for="wpnews-b-title"><?php esc_html_e('Title', 'wp-news'); ?></label>
				<input type="text" id="wpnews-b-title" class="wpnews-input" data-b="title" placeholder="<?php esc_attr_e('Subscribe to our Newsletter', 'wp-news'); ?>">
				<label class="wpnews-check"><input type="checkbox" data-b="hide_title"> <?php esc_html_e('No title', 'wp-news'); ?></label>

				<label class="wpnews-field-label" for="wpnews-b-desc"><?php esc_html_e('Short text under the title (optional)', 'wp-news'); ?></label>
				<input type="text" id="wpnews-b-desc" class="wpnews-input" data-b="description" placeholder="<?php esc_attr_e('e.g. One email a month, no spam.', 'wp-news'); ?>">

				<label class="wpnews-field-label" for="wpnews-b-button"><?php esc_html_e('Button text', 'wp-news'); ?></label>
				<input type="text" id="wpnews-b-button" class="wpnews-input" data-b="button" placeholder="<?php esc_attr_e('Subscribe', 'wp-news'); ?>">

				<label class="wpnews-check"><input type="checkbox" data-b="names" checked> <?php esc_html_e('Ask for first and last name', 'wp-news'); ?></label>
				<label class="wpnews-check"><input type="checkbox" data-b="consent"> <?php esc_html_e('Privacy consent checkbox (required to subscribe)', 'wp-news'); ?></label>
				<?php if (!$wpnews_privacy_url) : ?>
					<p class="wpnews-builder__hint" data-b-show="consent" hidden>
						<?php
						printf(
							/* translators: %s: link to Settings > Privacy */
							esc_html__('Tip: choose your privacy policy page in %s so the checkbox links to it.', 'wp-news'),
							'<a href="' . esc_url(admin_url('options-privacy.php')) . '">' . esc_html__('Settings → Privacy', 'wp-news') . '</a>'
						);
						?>
					</p>
				<?php endif; ?>
			</div>

			<div class="wpnews-builder__output">
				<span class="wpnews-field-label"><?php esc_html_e('Your code', 'wp-news'); ?></span>
				<div class="wpnews-shortcode-chip wpnews-shortcode-chip--big">
					<code data-b-out="code"></code>
					<button type="button" class="wpnews-copy-btn" data-copy="" title="<?php esc_attr_e('Copy shortcode', 'wp-news'); ?>">
						<span class="dashicons dashicons-admin-page" aria-hidden="true"></span>
						<span class="wpnews-copy-label"><?php esc_html_e('Copy', 'wp-news'); ?></span>
					</button>
				</div>
				<p class="wpnews-builder__hint">
					<?php esc_html_e('In the block editor add a "Shortcode" block and paste the code; in Elementor use the "Shortcode" widget.', 'wp-news'); ?>
				</p>

				<span class="wpnews-field-label"><?php esc_html_e('Preview', 'wp-news'); ?></span>
				<div class="wpnews-builder__preview" aria-hidden="true">
					<div class="wpnews-subscribe-form">
						<h3 class="wpnews-form-title" data-b-out="title"><?php esc_html_e('Subscribe to our Newsletter', 'wp-news'); ?></h3>
						<p class="wpnews-form-description" data-b-out="description" hidden></p>
						<div class="wpnews-form-row" data-b-show="names">
							<div class="wpnews-form-group">
								<label><?php esc_html_e('First Name', 'wp-news'); ?></label>
								<input type="text" placeholder="<?php esc_attr_e('Your first name', 'wp-news'); ?>" tabindex="-1" readonly>
							</div>
							<div class="wpnews-form-group">
								<label><?php esc_html_e('Last Name', 'wp-news'); ?></label>
								<input type="text" placeholder="<?php esc_attr_e('Your last name', 'wp-news'); ?>" tabindex="-1" readonly>
							</div>
						</div>
						<div class="wpnews-form-group">
							<label><?php esc_html_e('Email (required)', 'wp-news'); ?></label>
							<input type="email" placeholder="<?php esc_attr_e('Your email', 'wp-news'); ?>" tabindex="-1" readonly>
						</div>
						<div class="wpnews-form-group wpnews-form-consent" data-b-show="consent" hidden>
							<label>
								<input type="checkbox" tabindex="-1" disabled>
								<span>
									<?php
									if ($wpnews_privacy_url) {
										printf(
											/* translators: %s: link to the privacy policy page */
											esc_html__('I agree to receive the newsletter and accept the %s.', 'wp-news'),
											'<a>' . esc_html__('privacy policy', 'wp-news') . '</a>'
										);
									} else {
										esc_html_e('I agree to receive the newsletter.', 'wp-news');
									}
									?>
								</span>
							</label>
						</div>
						<span class="wpnews-submit-btn" data-b-out="button"><?php esc_html_e('Subscribe', 'wp-news'); ?></span>
					</div>
				</div>
				<p class="wpnews-builder__hint"><?php esc_html_e('On the website the form takes the fonts of your theme.', 'wp-news'); ?></p>
			</div>
		</div>
	<?php endif; ?>
</div>
