/**
 * WP-News Public JavaScript (vanilla, no jQuery).
 * Handles the [wpnews_subscribe_form] shortcode submission via admin-ajax.
 */
(function () {
	'use strict';

	var cfg = window.wpNewsPublic || {};
	var S = cfg.strings || {};

	function t(key, fallback) {
		return Object.prototype.hasOwnProperty.call(S, key) ? S[key] : fallback;
	}

	function isValidEmail(email) {
		return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
	}

	function showMessage(form, message, type) {
		var slot = form.querySelector('.wpnews-message-slot') || form;
		var existing = form.querySelector('.wpnews-message');
		if (existing) {
			existing.parentNode.removeChild(existing);
		}
		var div = document.createElement('div');
		div.className = 'wpnews-message ' + type;
		div.setAttribute('role', type === 'error' ? 'alert' : 'status');
		div.textContent = message;
		slot.appendChild(div);
	}

	document.addEventListener('submit', function (e) {
		var form = e.target && e.target.closest ? e.target.closest('.wpnews-subscribe-form') : null;
		if (!form) {
			return;
		}
		e.preventDefault();

		if (!cfg.ajaxUrl) {
			return;
		}

		var emailInput = form.querySelector('input[name="email"]');
		var email = emailInput ? emailInput.value.trim() : '';
		if (!isValidEmail(email)) {
			showMessage(form, t('invalidEmail', 'Please enter a valid email address.'), 'error');
			if (emailInput) {
				emailInput.focus();
			}
			return;
		}

		var consent = form.querySelector('input[name="wpnews_consent"]');
		if (consent && !consent.checked) {
			showMessage(form, t('consentRequired', 'Please accept the privacy conditions to subscribe.'), 'error');
			consent.focus();
			return;
		}

		var submitBtn = form.querySelector('button[type="submit"]');
		var originalText = submitBtn ? submitBtn.textContent : '';
		if (submitBtn) {
			submitBtn.disabled = true;
			submitBtn.textContent = t('subscribing', 'Subscribing...');
		}

		var data = new FormData(form);
		data.append('action', 'wpnews_subscribe');
		data.append('nonce', cfg.nonce || '');

		var restore = function () {
			if (submitBtn) {
				submitBtn.disabled = false;
				submitBtn.textContent = originalText;
			}
		};

		fetch(cfg.ajaxUrl, { method: 'POST', body: data, credentials: 'same-origin' })
			.then(function (r) { return r.json(); })
			.then(function (resp) {
				var message = resp && resp.data && resp.data.message ? resp.data.message : '';
				if (resp && resp.success) {
					showMessage(form, message, 'success');
					form.reset();
				} else {
					showMessage(form, message || t('subscribeError', 'Error subscribing. Please try again.'), 'error');
				}
				restore();
			})
			.catch(function () {
				showMessage(form, t('subscribeError', 'Error subscribing. Please try again.'), 'error');
				restore();
			});
	});
})();
