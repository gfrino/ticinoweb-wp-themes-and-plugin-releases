<?php
/**
 * Pannelli a comparsa del design: scheda servizio, galleria ingrandita, preventivo,
 * nuova recensione. Il contenuto lo riempie assets/js/app.js.
 *
 * @var array $args ['services' => elenco da npd_services()]
 */
if (!defined('ABSPATH')) {
    exit;
}
$npd_services = isset($args['services']) ? $args['services'] : array();
$npd_t = 'new-polo-design-child-theme';
$npd_input = 'npd-input';
?>
<div class="npd-overlay" data-npd-sheet-overlay hidden>
    <div class="npd-sheet" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e('Scheda servizio', $npd_t); ?>" tabindex="-1">
        <button type="button" class="npd-close" data-npd-close aria-label="<?php esc_attr_e('Chiudi', $npd_t); ?>"><?php echo npd_icon('x', 22); // phpcs:ignore WordPress.Security.EscapeOutput ?></button>
        <div class="mx-auto mt-4 h-2 w-[100px] rounded-full bg-muted"></div>
        <div class="w-full overflow-y-auto pb-10 npd-sheet-body" data-npd-sheet-body></div>
    </div>
</div>

<div class="fixed inset-0 z-[70] bg-black/90 backdrop-blur-sm flex items-center justify-center" data-npd-lightbox role="dialog" aria-modal="true" hidden>
    <div class="absolute top-0 left-0 right-0 flex items-center justify-between p-4 text-white z-10">
        <div class="text-sm"><span class="font-semibold" data-npd-lb-title></span><span class="ml-2 text-white/60" data-npd-lb-cat></span></div>
        <div class="flex items-center gap-2">
            <button type="button" data-npd-lb-zoom aria-label="<?php esc_attr_e('Ingrandisci', $npd_t); ?>" class="h-10 w-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center"><?php echo npd_icon('zoom-in', 20); // phpcs:ignore WordPress.Security.EscapeOutput ?></button>
            <button type="button" data-npd-lb-close aria-label="<?php esc_attr_e('Chiudi', $npd_t); ?>" class="h-10 w-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center"><?php echo npd_icon('x', 20); // phpcs:ignore WordPress.Security.EscapeOutput ?></button>
        </div>
    </div>
    <button type="button" data-npd-lb-prev aria-label="<?php esc_attr_e('Precedente', $npd_t); ?>" class="absolute left-3 sm:left-6 z-10 h-12 w-12 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center"><?php echo npd_icon('chevron-left', 26); // phpcs:ignore WordPress.Security.EscapeOutput ?></button>
    <img alt="" data-npd-lb-img class="max-h-[82vh] max-w-[90vw] rounded-lg object-contain shadow-2xl transition-transform duration-300 cursor-zoom-in">
    <button type="button" data-npd-lb-next aria-label="<?php esc_attr_e('Successivo', $npd_t); ?>" class="absolute right-3 sm:right-6 z-10 h-12 w-12 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center"><?php echo npd_icon('chevron-right', 26); // phpcs:ignore WordPress.Security.EscapeOutput ?></button>
    <div class="absolute bottom-5 left-1/2 -translate-x-1/2 text-white/70 text-sm" data-npd-lb-count></div>
</div>

<div class="npd-overlay npd-overlay-center" data-npd-quote-overlay hidden>
    <div class="npd-modal" role="dialog" aria-modal="true" aria-labelledby="npd-quote-title" tabindex="-1">
        <button type="button" class="npd-close" data-npd-close aria-label="<?php esc_attr_e('Chiudi', $npd_t); ?>"><?php echo npd_icon('x', 22); // phpcs:ignore WordPress.Security.EscapeOutput ?></button>
        <div data-npd-quote-form-wrap>
            <h2 id="npd-quote-title" class="text-2xl sm:text-3xl font-bold text-foreground" data-npd-quote-title><?php esc_html_e('Richiedi Preventivo', $npd_t); ?></h2>
            <p class="text-muted-foreground mt-2 mb-6" data-npd-quote-desc><?php esc_html_e('Compila il form per ricevere una proposta su misura.', $npd_t); ?></p>
            <div class="mb-6 rounded-xl border border-primary/10 bg-primary/5 p-4" data-npd-quote-include hidden>
                <p class="font-semibold text-primary text-sm mb-2"><?php esc_html_e('Cosa include:', $npd_t); ?></p>
                <ul class="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-sm text-foreground/80" data-npd-quote-include-list></ul>
            </div>
            <form class="space-y-5" novalidate data-npd-quote-form>
                <input type="text" name="tw_hp" tabindex="-1" autocomplete="off" aria-hidden="true" class="npd-hp">
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <label class="npd-field"><span><?php esc_html_e('Nome *', $npd_t); ?></span><input class="<?php echo esc_attr($npd_input); ?>" type="text" name="nome" placeholder="<?php esc_attr_e('Mario', $npd_t); ?>" autocomplete="given-name"><em data-err="nome"></em></label>
                    <label class="npd-field"><span><?php esc_html_e('Cognome *', $npd_t); ?></span><input class="<?php echo esc_attr($npd_input); ?>" type="text" name="cognome" placeholder="<?php esc_attr_e('Rossi', $npd_t); ?>" autocomplete="family-name"><em data-err="cognome"></em></label>
                </div>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <label class="npd-field"><span><?php esc_html_e('Email *', $npd_t); ?></span><input class="<?php echo esc_attr($npd_input); ?>" type="email" name="email" placeholder="mario@example.com" autocomplete="email"><em data-err="email"></em></label>
                    <label class="npd-field"><span><?php esc_html_e('Telefono *', $npd_t); ?></span><input class="<?php echo esc_attr($npd_input); ?>" type="tel" name="telefono" placeholder="333 1234567" autocomplete="tel"><em data-err="telefono"></em></label>
                </div>
                <label class="npd-field"><span><?php esc_html_e('Azienda', $npd_t); ?></span><input class="<?php echo esc_attr($npd_input); ?>" type="text" name="azienda" placeholder="<?php esc_attr_e('La tua azienda srl', $npd_t); ?>" autocomplete="organization"></label>
                <label class="npd-field"><span><?php esc_html_e('Servizio di interesse', $npd_t); ?></span>
                    <select class="<?php echo esc_attr($npd_input); ?>" name="servizio">
                        <option value=""><?php esc_html_e('Seleziona un servizio', $npd_t); ?></option>
                        <?php foreach ($npd_services as $s) : ?><option value="<?php echo esc_attr($s['name']); ?>"><?php echo esc_html($s['name']); ?></option><?php endforeach; ?>
                    </select>
                </label>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <label class="npd-field"><span><?php esc_html_e('Budget indicativo', $npd_t); ?></span><input class="<?php echo esc_attr($npd_input); ?>" type="text" name="budget" placeholder="<?php esc_attr_e('Es. 500-1000 €', $npd_t); ?>"></label>
                    <label class="npd-field"><span><?php esc_html_e('Tempistiche', $npd_t); ?></span><input class="<?php echo esc_attr($npd_input); ?>" type="text" name="tempistiche" placeholder="<?php esc_attr_e('Es. entro 2 settimane', $npd_t); ?>"></label>
                </div>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <label class="npd-field"><span><?php esc_html_e('Indirizzo', $npd_t); ?></span><input class="<?php echo esc_attr($npd_input); ?>" type="text" name="indirizzo" placeholder="<?php esc_attr_e('Via, numero civico', $npd_t); ?>" autocomplete="street-address"></label>
                    <label class="npd-field"><span><?php esc_html_e('Città', $npd_t); ?></span><input class="<?php echo esc_attr($npd_input); ?>" type="text" name="citta" placeholder="<?php esc_attr_e('Es. Locarno', $npd_t); ?>" autocomplete="address-level2"></label>
                </div>
                <label class="npd-field"><span><?php esc_html_e('Descrizione Progetto *', $npd_t); ?></span><textarea class="<?php echo esc_attr($npd_input); ?>" name="descrizione" rows="5" placeholder="<?php esc_attr_e('Raccontaci i dettagli del tuo progetto, quantità, tempistiche...', $npd_t); ?>"></textarea><em data-err="descrizione"></em></label>
                <label class="npd-field"><span><?php esc_html_e('Note aggiuntive', $npd_t); ?></span><textarea class="<?php echo esc_attr($npd_input); ?>" name="note" rows="3" placeholder="<?php esc_attr_e('Eventuali informazioni utili', $npd_t); ?>"></textarea></label>
                <p class="text-sm font-medium text-red-600" data-npd-quote-error role="alert" hidden></p>
                <div class="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <button type="button" data-npd-send="whatsapp" class="inline-flex items-center justify-center gap-2 whitespace-nowrap h-14 text-base bg-[#25D366] hover:bg-[#25D366]/90 text-white font-bold rounded-xl shadow-lg hover:-translate-y-0.5 transition-all disabled:opacity-60"><?php echo npd_icon('message-circle', 20); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php esc_html_e('Invia su WhatsApp', $npd_t); ?></span></button>
                    <button type="button" data-npd-send="email" class="inline-flex items-center justify-center gap-2 whitespace-nowrap h-14 text-base bg-accent hover:bg-accent/90 text-accent-foreground font-bold rounded-xl shadow-lg hover:-translate-y-0.5 transition-all disabled:opacity-60"><?php echo npd_icon('mail', 20); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php esc_html_e('Invia via Email', $npd_t); ?></span></button>
                </div>
                <p class="text-center text-xs text-muted-foreground mt-3"><?php esc_html_e('I tuoi dati verranno usati solo per elaborare la richiesta di preventivo.', $npd_t); ?></p>
            </form>
        </div>
        <div class="flex flex-col items-center text-center py-10" data-npd-quote-done hidden>
            <div class="relative w-24 h-24 rounded-full bg-[#25D366]/10 flex items-center justify-center mb-6 text-[#25D366]"><?php echo npd_icon('circle-check', 56); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
            <h2 class="text-2xl sm:text-3xl font-bold text-foreground mb-3"><?php esc_html_e('Richiesta inviata con successo!', $npd_t); ?></h2>
            <p class="text-muted-foreground max-w-md mb-8"><?php esc_html_e('Grazie! Abbiamo ricevuto la tua richiesta e ti risponderemo al più presto.', $npd_t); ?></p>
            <div class="flex flex-col sm:flex-row gap-3 w-full max-w-md">
                <button type="button" data-npd-close class="flex-1 h-14 bg-primary hover:bg-primary/90 text-primary-foreground rounded-xl font-bold"><?php esc_html_e('Torna ai Servizi', $npd_t); ?></button>
                <button type="button" data-npd-quote-again class="flex-1 h-14 rounded-xl border-2 border-primary text-primary hover:bg-primary/5 font-bold"><?php esc_html_e('Invia un\'altra richiesta', $npd_t); ?></button>
            </div>
        </div>
    </div>
</div>

<div class="npd-overlay npd-overlay-center" data-npd-review-overlay hidden>
    <div class="npd-modal npd-modal-sm" role="dialog" aria-modal="true" aria-labelledby="npd-review-title" tabindex="-1">
        <button type="button" class="npd-close" data-npd-close aria-label="<?php esc_attr_e('Chiudi', $npd_t); ?>"><?php echo npd_icon('x', 22); // phpcs:ignore WordPress.Security.EscapeOutput ?></button>
        <div data-npd-review-form-wrap>
            <h2 id="npd-review-title" class="text-2xl font-bold text-foreground"><?php esc_html_e('Lascia una recensione', $npd_t); ?></h2>
            <p class="text-muted-foreground mt-2 mb-6"><?php esc_html_e('Racconta la tua esperienza con noi. La recensione sarà pubblicata dopo l\'approvazione.', $npd_t); ?></p>
            <form class="space-y-5" novalidate data-npd-review-form>
                <input type="text" name="tw_hp" tabindex="-1" autocomplete="off" aria-hidden="true" class="npd-hp">
                <label class="npd-field"><span><?php esc_html_e('Nome *', $npd_t); ?></span><input class="<?php echo esc_attr($npd_input); ?>" type="text" name="nome" placeholder="<?php esc_attr_e('Il tuo nome', $npd_t); ?>" autocomplete="name"></label>
                <label class="npd-field"><span><?php esc_html_e('Azienda (opzionale)', $npd_t); ?></span><input class="<?php echo esc_attr($npd_input); ?>" type="text" name="azienda" placeholder="<?php esc_attr_e('La tua azienda o ruolo', $npd_t); ?>"></label>
                <label class="npd-field"><span><?php esc_html_e('Email *', $npd_t); ?></span><input class="<?php echo esc_attr($npd_input); ?>" type="email" name="email" placeholder="mario@example.com" autocomplete="email"></label>
                <div class="npd-field"><span><?php esc_html_e('Valutazione', $npd_t); ?></span>
                    <div class="flex gap-1 text-accent" data-npd-stars role="radiogroup" aria-label="<?php esc_attr_e('Valutazione', $npd_t); ?>">
                        <?php for ($i = 1; $i <= 5; $i++) : ?><button type="button" data-npd-star="<?php echo (int) $i; ?>" role="radio" aria-checked="<?php echo $i === 5 ? 'true' : 'false'; ?>" aria-label="<?php echo esc_attr(sprintf(_n('%d stella', '%d stelle', $i, $npd_t), $i)); ?>" class="p-0.5"><?php echo npd_icon('star', 28, $i <= 5 ? 'fill-current' : ''); // phpcs:ignore WordPress.Security.EscapeOutput ?></button><?php endfor; ?>
                    </div>
                </div>
                <label class="npd-field"><span><?php esc_html_e('La tua recensione *', $npd_t); ?></span><textarea class="<?php echo esc_attr($npd_input); ?>" name="testo" rows="5" placeholder="<?php esc_attr_e('Descrivi la tua esperienza...', $npd_t); ?>"></textarea></label>
                <p class="text-sm font-medium text-red-600" data-npd-review-error role="alert" hidden></p>
                <div class="flex gap-3">
                    <button type="button" data-npd-close class="flex-1 h-12 rounded-xl border border-border font-semibold"><?php esc_html_e('Annulla', $npd_t); ?></button>
                    <button type="submit" class="flex-1 h-12 rounded-xl bg-primary text-primary-foreground font-bold disabled:opacity-60"><?php esc_html_e('Invia recensione', $npd_t); ?></button>
                </div>
            </form>
        </div>
        <div class="text-center py-10" data-npd-review-done hidden>
            <div class="mx-auto w-20 h-20 rounded-full bg-[#25D366]/10 flex items-center justify-center mb-5 text-[#25D366]"><?php echo npd_icon('circle-check', 48); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
            <h2 class="text-2xl font-bold text-foreground mb-2"><?php esc_html_e('Grazie per la tua recensione!', $npd_t); ?></h2>
            <p class="text-muted-foreground mb-6"><?php esc_html_e('La pubblicheremo dopo una breve verifica.', $npd_t); ?></p>
            <button type="button" data-npd-close class="h-12 px-8 rounded-xl bg-primary text-primary-foreground font-bold"><?php esc_html_e('Chiudi', $npd_t); ?></button>
        </div>
    </div>
</div>
