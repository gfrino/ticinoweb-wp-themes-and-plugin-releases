<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="pi-salta" href="#contenuto">Vai al contenuto</a>
<header class="pi-testata" data-pi-testata>
	<div class="contenitore pi-testata__riga">
		<?php pi_marca(); ?>
		<button class="pi-menu-btn" type="button" aria-expanded="false" aria-controls="pi-navigazione" data-pi-menu>
			<span class="pi-menu-btn__linee" aria-hidden="true"></span><span class="pi-menu-btn__testo">Menu</span>
		</button>
		<nav class="pi-nav" id="pi-navigazione" aria-label="Menu principale">
			<?php
			wp_nav_menu([
				'theme_location' => 'pi-principale',
				'container'      => false,
				'menu_class'     => 'pi-nav__lista',
				'depth'          => 2,
				'fallback_cb'    => 'pi_menu_di_ripiego',
			]);
			?>
			<form class="pi-nav__cerca" role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
				<label for="pi-cerca-testata">Cerca un atto o un documento</label>
				<input id="pi-cerca-testata" type="search" name="s" placeholder="Cerca negli atti" value="<?php echo esc_attr(get_search_query()); ?>">
			</form>
		</nav>
	</div>
</header>
<main id="contenuto" class="pi-principale">
