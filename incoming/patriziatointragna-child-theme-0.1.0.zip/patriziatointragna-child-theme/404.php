<?php
/** Pagina non trovata: niente rimando muto alla home, ma la ricerca e le sezioni. */
status_header(404);
get_header();
pi_testa_pagina('Questa pagina non c\'è più', 'Forse l\'atto o il documento che cerchi ha cambiato indirizzo con il nuovo sito. Cercalo per parola o sfoglia le sezioni.');
?>
<div class="contenitore pi-albo">
	<form class="pi-cerca" role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
		<label for="pi-cerca-404">Cerca per parola</label>
		<input id="pi-cerca-404" type="search" name="s">
		<button type="submit" class="pi-bottone">Cerca</button>
	</form>
	<ul class="pi-vie-404" role="list">
		<li><a class="pi-link-freccia" href="<?php echo esc_url(pi_url_albo()); ?>">Albo del Patriziato</a></li>
		<li><a class="pi-link-freccia" href="<?php echo esc_url(pi_url('assemblee')); ?>">Assemblee</a></li>
		<li><a class="pi-link-freccia" href="<?php echo esc_url(get_post_type_archive_link('pi_documento')); ?>">Documenti</a></li>
		<li><a class="pi-link-freccia" href="<?php echo esc_url(home_url('/')); ?>">Pagina iniziale</a></li>
	</ul>
</div>
<?php get_footer(); ?>
