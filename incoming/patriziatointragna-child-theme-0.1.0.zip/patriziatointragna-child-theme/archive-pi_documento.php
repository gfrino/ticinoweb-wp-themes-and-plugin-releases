<?php
/**
 * Documenti sempre validi, per raccolta.
 */
get_header();
pi_testa_pagina('Documenti', 'Regolamenti, leggi e registri dei patrizi nella versione in vigore.');
?>
<div class="contenitore pi-documenti">
	<?php foreach (pi_raccolte() as $slug => $r) :
		$docs = pi_documenti($slug);
		if (!$docs) {
			continue;
		} ?>
		<section class="pi-raccolta" id="<?php echo esc_attr($slug); ?>">
			<div class="pi-raccolta__testa">
				<h2><?php echo esc_html($r[0]); ?></h2>
				<p><?php echo esc_html($r[1]); ?></p>
			</div>
			<ul class="pi-schede" role="list">
				<?php foreach ($docs as $d) :
					$file = pi_documento_file($d->ID);
					$f = $file ? pi_file_info($file) : null;
					$dal = get_post_meta($d->ID, '_pi_valido_dal', true);
					$riservato = pi_documento_riservato($d->ID); ?>
					<li class="pi-scheda">
						<h3><a href="<?php echo esc_url(get_permalink($d)); ?>"><?php echo esc_html(get_the_title($d)); ?></a></h3>
						<?php $desc = get_post_meta($d->ID, '_pi_descrizione', true); if ($desc) : ?><p><?php echo esc_html($desc); ?></p><?php endif; ?>
						<p class="pi-meta"><?php echo $dal ? 'In vigore dal ' . esc_html(pi_data_lunga($dal)) : ''; ?><?php echo count(pi_documento_versioni($d->ID)) ? ' · ' . count(pi_documento_versioni($d->ID)) . ' versioni precedenti' : ''; ?></p>
						<?php if ($f) : ?>
							<a class="pi-bottone" href="<?php echo esc_url($f['url']); ?>"<?php echo $riservato ? ' rel="nofollow"' : ''; ?>>Apri il <?php echo esc_html($f['formato']); ?><?php echo $f['peso'] ? ' · ' . esc_html($f['peso']) : ''; ?></a>
						<?php endif; ?>
					</li>
				<?php endforeach; ?>
			</ul>
		</section>
	<?php endforeach; ?>
</div>
<?php get_footer(); ?>
