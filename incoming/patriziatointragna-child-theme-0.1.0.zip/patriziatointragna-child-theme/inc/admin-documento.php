<?php
/**
 * Documenti sempre validi: un nome, una raccolta, un file. «Sostituisci con la versione nuova» sposta
 * da solo il file precedente nello storico, con la sua data: l'indirizzo della pagina non cambia mai.
 */
if (!defined('ABSPATH')) {
	exit;
}

add_action('add_meta_boxes_pi_documento', function () {
	add_meta_box('pi_documento', 'Il documento', 'pi_metabox_documento', 'pi_documento', 'normal', 'high');
	if (!current_user_can('manage_options')) {
		remove_meta_box('slugdiv', 'pi_documento', 'normal');
	}
});

function pi_metabox_documento($post) {
	wp_nonce_field('pi_documento', 'pi_documento_nonce');
	$file = pi_documento_file($post->ID);
	$info = $file ? pi_file_info($file) : null;
	$racc = get_post_meta($post->ID, '_pi_raccolta', true);
	$dal  = get_post_meta($post->ID, '_pi_valido_dal', true);
	$desc = get_post_meta($post->ID, '_pi_descrizione', true);
	$vers = pi_documento_versioni($post->ID);
	?>
	<div class="pi-modulo" data-pi-documento>
		<fieldset class="pi-passo">
			<legend><span class="pi-numero">1</span> In quale raccolta va?</legend>
			<div class="pi-tipi">
				<?php foreach (pi_raccolte() as $slug => $r) : ?>
					<label class="pi-tipo">
						<input type="radio" name="pi_raccolta" value="<?php echo esc_attr($slug); ?>" <?php checked($racc ?: 'regolamenti', $slug); ?>>
						<span><strong><?php echo esc_html($r[0]); ?></strong><small><?php echo esc_html($r[1]); ?></small></span>
					</label>
				<?php endforeach; ?>
			</div>
		</fieldset>

		<fieldset class="pi-passo" data-pi-file>
			<legend><span class="pi-numero">2</span> Il file</legend>
			<input type="hidden" name="pi_file" value="<?php echo (int) $file; ?>" data-file-id data-originale="<?php echo (int) $file; ?>">
			<p class="pi-file-attuale" data-file-nome><?php echo $info ? '<span class="pi-formato">' . esc_html($info['formato']) . '</span> ' . esc_html($info['titolo']) : '<em>Nessun file ancora.</em>'; ?></p>
			<p>
				<button type="button" class="button button-large" data-scegli-file><?php echo $file ? 'Sostituisci con la versione nuova' : 'Carica il file'; ?></button>
			</p>
			<p class="pi-aiuto" data-avviso-sostituzione hidden>Salvando, il file precedente passa nello storico con la sua data. Chi ha il vecchio link trova sempre la versione nuova.</p>
			<div class="pi-campi">
				<label>Valido dal <input type="date" name="pi_valido_dal" value="<?php echo esc_attr($dal); ?>"></label>
			</div>
		</fieldset>

		<fieldset class="pi-passo">
			<legend><span class="pi-numero">3</span> Due righe di spiegazione <small>(facoltativo)</small></legend>
			<textarea name="pi_descrizione" rows="3" class="large-text"><?php echo esc_textarea($desc); ?></textarea>
		</fieldset>

		<?php if ($vers) : ?>
			<div class="pi-passo">
				<p><strong>Versioni precedenti</strong> (restano consultabili sul sito)</p>
				<ul class="pi-versioni">
					<?php foreach ($vers as $v) :
						$vi = pi_file_info((int) $v['file']); ?>
						<li><?php echo esc_html(pi_data_breve($v['data'])); ?> · <a href="<?php echo esc_url($vi['url']); ?>" target="_blank" rel="noopener"><?php echo esc_html($vi['titolo']); ?></a></li>
					<?php endforeach; ?>
				</ul>
			</div>
		<?php endif; ?>
	</div>
	<?php
}

add_action('save_post_pi_documento', function ($post_id) {
	if ((defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || wp_is_post_revision($post_id)) {
		return;
	}
	if (!isset($_POST['pi_documento_nonce']) || !wp_verify_nonce($_POST['pi_documento_nonce'], 'pi_documento') || !current_user_can('edit_post', $post_id)) {
		return;
	}
	$racc = sanitize_key($_POST['pi_raccolta'] ?? '');
	update_post_meta($post_id, '_pi_raccolta', isset(pi_raccolte()[$racc]) ? $racc : 'regolamenti');
	update_post_meta($post_id, '_pi_descrizione', sanitize_textarea_field($_POST['pi_descrizione'] ?? ''));

	$vecchio = pi_documento_file($post_id);
	$dal_vecchio = get_post_meta($post_id, '_pi_valido_dal', true);
	$nuovo = absint($_POST['pi_file'] ?? 0);
	$dal = sanitize_text_field($_POST['pi_valido_dal'] ?? '');
	$dal = preg_match('/^\d{4}-\d{2}-\d{2}$/', $dal) ? $dal : '';

	if ($nuovo && get_post_type($nuovo) === 'attachment' && $nuovo !== $vecchio) {
		if ($vecchio) {
			$vers = pi_documento_versioni($post_id);
			array_unshift($vers, ['file' => $vecchio, 'data' => $dal_vecchio ?: get_the_date('Y-m-d', $vecchio)]);
			update_post_meta($post_id, '_pi_versioni', $vers);
			if ($dal === $dal_vecchio) {
				$dal = ''; // la data del file vecchio non vale per quello nuovo
			}
		}
		update_post_meta($post_id, '_pi_file', $nuovo);
		if (!wp_get_post_parent_id($nuovo)) {
			wp_update_post(['ID' => $nuovo, 'post_parent' => $post_id]);
		}
	}
	update_post_meta($post_id, '_pi_valido_dal', $dal ?: current_time('Y-m-d'));
});

add_filter('manage_pi_documento_posts_columns', function ($c) {
	return ['cb' => $c['cb'], 'title' => 'Documento', 'pi_raccolta' => 'Raccolta', 'pi_dal' => 'Valido dal', 'date' => $c['date']];
});
add_action('manage_pi_documento_posts_custom_column', function ($col, $id) {
	if ($col === 'pi_raccolta') {
		echo esc_html(pi_raccolte()[pi_documento_raccolta($id)][0]);
	}
	if ($col === 'pi_dal') {
		$d = get_post_meta($id, '_pi_valido_dal', true);
		echo $d ? esc_html(pi_data_breve($d)) : '—';
		if (!pi_documento_file($id)) {
			echo '<br><span class="pi-manca">manca il file</span>';
		}
	}
}, 10, 2);
