<?php
/**
 * Asset, menu, immagini e i tre ritocchi al comportamento del parent (solo tramite hook).
 */
if (!defined('ABSPATH')) {
	exit;
}

add_action('after_setup_theme', function () {
	register_nav_menus(['pi-principale' => 'Menu principale', 'pi-piede' => 'Menu del piè di pagina']);
	add_theme_support('title-tag');
	add_theme_support('html5', ['search-form', 'gallery', 'caption', 'style', 'script']);
	add_image_size('pi-largo', 2000, 0, false);
	add_image_size('pi-medio', 1200, 0, false);
	// Un sito istituzionale non manda chi sbaglia indirizzo in prima pagina senza dirglielo:
	// il 404 del parent (301 alla home) è sostituito da una pagina 404 con la ricerca.
	remove_action('template_redirect', 'ticinoweb_redirect_404_to_home');
}, 20);

// Le foto non vanno piantate a una larghezza fissa da sizes="auto".
add_filter('wp_img_tag_add_auto_sizes', '__return_false');
add_filter('big_image_size_threshold', function () {
	return 2400;
});

add_action('wp_enqueue_scripts', function () {
	// Lo script dello slider del parent non serve.
	wp_dequeue_script('ticinoweb-ai-main');
	// style.css del child è caricato dal parent con la versione del parent: lo allineo alla nostra.
	$css = PI_DIR . '/style.css';
	if (isset(wp_styles()->registered['ticinoweb-ai-style'])) {
		wp_styles()->registered['ticinoweb-ai-style']->ver = PI_VERSIONE . '.' . filemtime($css);
	}
	$js = PI_DIR . '/assets/js/sito.js';
	wp_enqueue_script('pi-sito', PI_URI . '/assets/js/sito.js', [], PI_VERSIONE . '.' . filemtime($js), ['strategy' => 'defer', 'in_footer' => true]);
}, 100);

// Poppins da Google arriverebbe prima del consenso ai cookie: tolto. Non basta il dequeue,
// perché style.css ne dipende; si sostituisce con un handle vuoto (come in melaverde-child-theme).
add_action('wp_enqueue_scripts', function () {
	wp_deregister_style('poppins-font');
	wp_register_style('poppins-font', false);
}, 20);
// Il preconnect a fonts.googleapis.com del parent è una closure: si trova e si toglie.
add_action('wp_head', function () {
	global $wp_filter;
	if (empty($wp_filter['wp_head']->callbacks[0])) {
		return;
	}
	foreach ($wp_filter['wp_head']->callbacks[0] as $cb) {
		if (!($cb['function'] instanceof Closure)) {
			continue;
		}
		$rf = new ReflectionFunction($cb['function']);
		$file = (string) $rf->getFileName();
		if (strpos($file, '/ticinoweb-ai-theme/') === false) {
			continue;
		}
		$righe = array_slice(file($file), $rf->getStartLine() - 1, $rf->getEndLine() - $rf->getStartLine() + 1);
		if (strpos(implode('', $righe), 'fonts.googleapis.com') !== false) {
			remove_action('wp_head', $cb['function'], 0);
		}
	}
}, -100);
add_filter('wp_resource_hints', function ($urls, $rel) {
	if ($rel === 'preconnect' || $rel === 'dns-prefetch') {
		$urls = array_filter($urls, function ($u) {
			$h = is_array($u) ? ($u['href'] ?? '') : $u;
			return strpos($h, 'fonts.g') === false;
		});
	}
	return $urls;
}, 99, 2);

add_action('wp_head', function () {
	echo "<script>document.documentElement.classList.add('js')</script>\n";
	foreach (['libre-caslon-display-400', 'libre-franklin-400'] as $f) {
		printf('<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url(PI_URI . '/assets/fonts/' . $f . '.woff2'));
	}
	echo '<meta name="theme-color" content="#fafaf8">' . "\n";
}, 2);

add_filter('body_class', function ($c) {
	if (is_front_page()) {
		$c[] = 'pi-home';
	}
	return $c;
});

// Ricerca: solo atti, documenti e pagine.
add_action('pre_get_posts', function ($q) {
	if (!is_admin() && $q->is_main_query() && $q->is_search()) {
		$q->set('post_type', ['post', 'pi_documento', 'page']);
		$q->set('posts_per_page', 20);
	}
	if (!is_admin() && $q->is_main_query() && $q->is_home()) {
		$q->set('posts_per_page', 20);
		$tipo = sanitize_key($_GET['tipo'] ?? '');
		if ($tipo && isset(pi_tipi_atto()[$tipo])) {
			$q->set('tax_query', [['taxonomy' => 'pi_tipo', 'field' => 'slug', 'terms' => $tipo]]);
		}
		$anno = absint($_GET['anno'] ?? 0);
		if ($anno > 1990 && $anno < 2100) {
			$q->set('year', $anno);
		}
	}
	if (!is_admin() && $q->is_main_query() && $q->is_post_type_archive('pi_documento')) {
		$q->set('posts_per_page', -1);
		$q->set('orderby', ['menu_order' => 'ASC', 'title' => 'ASC']);
	}
});
