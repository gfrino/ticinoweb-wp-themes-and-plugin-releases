<?php
/**
 * Modulo «Pubblica un atto»: titolo → tipo → (data dell'assemblea | scadenza dell'avviso) → testo → allegati → Pubblica.
 * Il resto (sezione, ordine, pagina dell'assemblea, archivio, home) lo fa il sistema.
 */
if (!defined('ABSPATH')) {
	exit;
}

// Editor classico per atti, pagine e documenti: un modulo, non un impaginatore.
add_filter('use_block_editor_for_post_type', function ($use, $type) {
	return in_array($type, ['post', 'page', 'pi_documento'], true) ? false : $use;
}, 20, 2);

// Barra del testo ridotta all'essenziale e niente «Aggiungi media» nel testo: i file vanno negli allegati.
add_filter('wp_editor_settings', function ($s, $id) {
	if ($id === 'content') {
		$s['media_buttons'] = current_user_can('manage_options');
		$s['quicktags']     = current_user_can('manage_options');
		$s['editor_height'] = 260;
	}
	return $s;
}, 10, 2);
add_filter('mce_buttons', function ($b) {
	return current_user_can('manage_options') ? $b : ['formatselect', 'bold', 'italic', 'bullist', 'numlist', 'link', 'unlink', 'undo', 'redo'];
});
add_filter('mce_buttons_2', function ($b) {
	return current_user_can('manage_options') ? $b : [];
});
add_filter('tiny_mce_before_init', function ($init) {
	$init['block_formats'] = 'Paragrafo=p;Titoletto=h3';
	return $init;
});

// Etichette: «Articoli» diventa «Albo».
add_action('init', function () {
	$o = get_post_type_object('post');
	if (!$o) {
		return;
	}
	$l = $o->labels;
	$l->name = $l->menu_name = $l->name_admin_bar = 'Albo';
	$l->singular_name = 'Pubblicazione';
	$l->add_new = 'Pubblica un atto o un avviso';
	$l->add_new_item = 'Pubblica un atto o un avviso';
	$l->edit_item = 'Modifica la pubblicazione';
	$l->new_item = 'Nuova pubblicazione';
	$l->view_item = $l->view_items = 'Vedi sul sito';
	$l->all_items = 'Tutte le pubblicazioni';
	$l->search_items = 'Cerca nell\'albo';
	$l->not_found = 'Nessuna pubblicazione trovata.';
	$l->not_found_in_trash = 'Nessuna pubblicazione nel cestino.';
	$l->item_published = 'Pubblicato. È già sul sito, nella sezione giusta.';
	$l->item_updated = 'Modifiche salvate.';
	$o->menu_icon = 'dashicons-megaphone';
}, 1000); // dopo ticinoweb_customize_post_labels del parent (999), che usa le opzioni ticinoweb_post_name_*

add_filter('enter_title_here', function ($t, $post) {
	if ($post->post_type === 'post') {
		return 'Titolo, per esempio «Convocazione assemblea patriziale del 17 dicembre 2026»';
	}
	if ($post->post_type === 'pi_documento') {
		return 'Nome del documento, per esempio «Regolamento del Patriziato»';
	}
	return $t;
}, 10, 2);

// Il riquadro «FAQ della pagina» del parent resta solo a ticinoWEB.
add_filter('ticinoweb_faq_page_post_types', function ($t) {
	return current_user_can('manage_options') ? $t : [];
});

// Riquadri che il Patriziato non deve vedere.
add_action('add_meta_boxes', function () {
	foreach (['categorydiv', 'tagsdiv-post_tag', 'postexcerpt', 'postcustom', 'trackbacksdiv', 'commentstatusdiv', 'commentsdiv', 'slugdiv', 'authordiv', 'formatdiv', 'revisionsdiv', 'postimagediv'] as $box) {
		if (!current_user_can('manage_options') || in_array($box, ['categorydiv', 'tagsdiv-post_tag', 'postimagediv'], true)) {
			remove_meta_box($box, 'post', 'normal');
			remove_meta_box($box, 'post', 'side');
			remove_meta_box($box, 'post', 'advanced');
		}
	}
	if (!current_user_can('manage_options')) {
		foreach (['postcustom', 'slugdiv', 'authordiv', 'commentstatusdiv', 'commentsdiv', 'pageparentdiv', 'revisionsdiv', 'postimagediv'] as $box) {
			remove_meta_box($box, 'page', 'normal');
			remove_meta_box($box, 'page', 'side');
		}
	}
}, 99);

// Tipo, assemblea e scadenza subito sotto il titolo.
add_action('edit_form_after_title', function ($post) {
	if ($post->post_type !== 'post') {
		return;
	}
	wp_nonce_field('pi_atto', 'pi_atto_nonce');
	$tipo   = $post->post_status === 'auto-draft' ? '' : pi_tipo_di($post->ID);
	$data   = get_post_meta($post->ID, '_pi_assemblea_data', true);
	$ora    = get_post_meta($post->ID, '_pi_ora', true);
	$luogo  = get_post_meta($post->ID, '_pi_luogo', true);
	$fino   = get_post_meta($post->ID, '_pi_evidenza_fino', true);
	?>
	<div class="pi-modulo" data-pi-atto>
		<fieldset class="pi-passo">
			<legend><span class="pi-numero">1</span> Che cosa pubblichi?</legend>
			<div class="pi-tipi">
				<?php foreach (pi_tipi_atto() as $slug => $t) : ?>
					<label class="pi-tipo">
						<input type="radio" name="pi_tipo" value="<?php echo esc_attr($slug); ?>" data-assemblea="<?php echo $t[2] ? '1' : '0'; ?>" <?php checked($tipo, $slug); ?> required>
						<span><strong><?php echo esc_html($t[0]); ?></strong><small><?php echo esc_html($t[1]); ?></small></span>
					</label>
				<?php endforeach; ?>
			</div>
		</fieldset>

		<fieldset class="pi-passo" data-se="assemblea" hidden>
			<legend><span class="pi-numero">2</span> Di quale assemblea si tratta?</legend>
			<div class="pi-campi">
				<label>Data dell'assemblea <input type="date" name="pi_assemblea_data" value="<?php echo esc_attr($data); ?>"></label>
				<label data-se="convocazione">Ora <input type="text" name="pi_ora" value="<?php echo esc_attr($ora); ?>" placeholder="20.00"></label>
				<label data-se="convocazione">Luogo <input type="text" name="pi_luogo" value="<?php echo esc_attr($luogo); ?>" placeholder="Sala patriziale, Intragna"></label>
			</div>
			<p class="pi-aiuto">Tutti gli atti con la stessa data finiscono insieme nella pagina di quell'assemblea.</p>
		</fieldset>

		<fieldset class="pi-passo" data-se="avviso" hidden>
			<legend><span class="pi-numero">2</span> Fino a quando va messo in evidenza?</legend>
			<div class="pi-campi">
				<label>In evidenza in prima pagina fino al <input type="date" name="pi_evidenza_fino" value="<?php echo esc_attr($fino); ?>"></label>
			</div>
			<p class="pi-aiuto">Dopo questa data l'avviso esce dalla prima pagina e resta nell'albo. Lascia vuoto per non metterlo in evidenza.</p>
		</fieldset>
		<p class="pi-passo-testo"><span class="pi-numero">3</span> Testo <small>(facoltativo: spesso basta il documento allegato)</small></p>
	</div>
	<?php
});

// Allegati subito sotto il testo.
add_action('edit_form_after_editor', function ($post) {
	if ($post->post_type !== 'post') {
		return;
	}
	pi_campo_allegati(pi_allegati($post->ID));
});

/** Lista di allegati riordinabile con «Aggiungi documenti o foto». */
function pi_campo_allegati($ids) {
	?>
	<fieldset class="pi-passo pi-allegati" data-pi-allegati>
		<legend><span class="pi-numero">4</span> Documenti e foto allegati</legend>
		<ol class="pi-allegati__lista">
			<?php foreach ($ids as $id) :
				$f = pi_file_info($id);
				if (!$f) {
					continue;
				} ?>
				<li data-id="<?php echo (int) $id; ?>">
					<input type="hidden" name="pi_allegati[]" value="<?php echo (int) $id; ?>">
					<span class="pi-formato"><?php echo esc_html($f['formato']); ?></span>
					<span class="pi-nome"><?php echo esc_html($f['titolo']); ?></span>
					<span class="pi-azioni">
						<button type="button" class="button-link" data-su aria-label="Sposta su">↑</button>
						<button type="button" class="button-link" data-giu aria-label="Sposta giù">↓</button>
						<button type="button" class="button-link pi-togli" data-togli-allegato>Togli</button>
					</span>
				</li>
			<?php endforeach; ?>
		</ol>
		<button type="button" class="button button-large" data-aggiungi-allegati>Aggiungi documenti o foto</button>
		<p class="pi-aiuto">PDF, Word o foto. Il primo allegato è quello principale: sul sito si apre in anteprima.</p>
	</fieldset>
	<?php
}

add_action('save_post_post', function ($post_id, $post) {
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
		return;
	}
	if (wp_is_post_revision($post_id) || !isset($_POST['pi_atto_nonce']) || !wp_verify_nonce($_POST['pi_atto_nonce'], 'pi_atto')) {
		return;
	}
	if (!current_user_can('edit_post', $post_id)) {
		return;
	}
	$tipi = pi_tipi_atto();
	$tipo = sanitize_key($_POST['pi_tipo'] ?? '');
	$tipo = isset($tipi[$tipo]) ? $tipo : 'comunicato';
	wp_set_object_terms($post_id, [$tipo], 'pi_tipo');

	$ids = array_values(array_unique(array_filter(array_map('absint', (array) ($_POST['pi_allegati'] ?? [])))));
	$ids = array_values(array_filter($ids, function ($id) {
		return get_post_type($id) === 'attachment';
	}));
	update_post_meta($post_id, '_pi_allegati', $ids);
	foreach ($ids as $id) {
		if (!wp_get_post_parent_id($id)) {
			wp_update_post(['ID' => $id, 'post_parent' => $post_id]);
		}
	}

	$data = sanitize_text_field($_POST['pi_assemblea_data'] ?? '');
	$data = ($tipi[$tipo][2] && preg_match('/^\d{4}-\d{2}-\d{2}$/', $data)) ? $data : '';
	update_post_meta($post_id, '_pi_assemblea_data', $data);
	update_post_meta($post_id, '_pi_ora', $tipo === 'convocazione' ? sanitize_text_field($_POST['pi_ora'] ?? '') : '');
	update_post_meta($post_id, '_pi_luogo', $tipo === 'convocazione' ? sanitize_text_field($_POST['pi_luogo'] ?? '') : '');
	pi_collega_assemblea($post_id, $data);

	$fino = sanitize_text_field($_POST['pi_evidenza_fino'] ?? '');
	if ($tipo === 'avviso' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $fino)) {
		update_post_meta($post_id, '_pi_evidenza_fino', $fino);
	} else {
		delete_post_meta($post_id, '_pi_evidenza_fino');
	}
	// L'atto non va mai in «Senza categoria»: la categoria storica resta solo per i vecchi indirizzi.
	wp_set_object_terms($post_id, [], 'category');
}, 10, 2);

// Un atto con solo il PDF (senza titolo né testo) non è «vuoto»: WordPress altrimenti lo rifiuterebbe.
add_filter('wp_insert_post_empty_content', function ($vuoto, $data) {
	return ($data['post_type'] ?? '') === 'post' && isset($_POST['pi_tipo']) ? false : $vuoto;
}, 10, 2);

// Titolo mancante: lo scrive il sistema (es. «Verbale dell'assemblea del 18.06.2026»).
add_filter('wp_insert_post_data', function ($data, $raw) {
	if ($data['post_type'] !== 'post' || trim($data['post_title']) !== '' || !isset($_POST['pi_tipo'])) {
		return $data;
	}
	$tipo = sanitize_key($_POST['pi_tipo']);
	$t = pi_tipo_etichetta($tipo);
	$d = sanitize_text_field($_POST['pi_assemblea_data'] ?? '');
	$data['post_title'] = $d ? $t . ' dell\'assemblea del ' . pi_data_breve($d) : $t . ' del ' . wp_date('d.m.Y');
	return $data;
}, 10, 2);

// Colonne dell'elenco: tipo, allegati, assemblea.
add_filter('manage_post_posts_columns', function ($c) {
	unset($c['categories'], $c['tags'], $c['comments'], $c['author']);
	$nuove = [];
	foreach ($c as $k => $v) {
		$nuove[$k] = $v;
		if ($k === 'title') {
			$nuove['pi_tipo'] = 'Tipo';
			$nuove['pi_allegati'] = 'Allegati';
		}
	}
	return $nuove;
});
add_action('manage_post_posts_custom_column', function ($col, $id) {
	if ($col === 'pi_tipo') {
		echo esc_html(pi_tipo_etichetta(pi_tipo_di($id)));
		$fino = get_post_meta($id, '_pi_evidenza_fino', true);
		if ($fino && $fino >= current_time('Y-m-d')) {
			echo '<br><small>in evidenza fino al ' . esc_html(pi_data_breve($fino)) . '</small>';
		}
		$d = get_post_meta($id, '_pi_assemblea_data', true);
		if ($d) {
			echo '<br><small>assemblea del ' . esc_html(pi_data_breve($d)) . '</small>';
		}
	}
	if ($col === 'pi_allegati') {
		$n = count(pi_allegati($id));
		echo $n ? (int) $n : '<span class="pi-manca">nessuno</span>';
	}
}, 10, 2);

// Filtro per tipo sopra l'elenco.
add_action('restrict_manage_posts', function ($type) {
	if ($type !== 'post') {
		return;
	}
	$sel = sanitize_key($_GET['pi_tipo'] ?? '');
	echo '<select name="pi_tipo"><option value="">Tutti i tipi</option>';
	foreach (pi_tipi_atto() as $slug => $t) {
		printf('<option value="%s"%s>%s</option>', esc_attr($slug), selected($sel, $slug, false), esc_html($t[0]));
	}
	echo '</select>';
});
add_action('pre_get_posts', function ($q) {
	if (!$q->is_main_query() || $q->get('post_type') && $q->get('post_type') !== 'post') {
		return;
	}
	$tipo = sanitize_key($_GET['pi_tipo'] ?? '');
	if ($tipo && isset(pi_tipi_atto()[$tipo])) {
		$q->set('tax_query', [['taxonomy' => 'pi_tipo', 'field' => 'slug', 'terms' => $tipo]]);
	}
});
