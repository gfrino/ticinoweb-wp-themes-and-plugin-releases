<?php
/**
 * WooCommerce → Odoo KPI: indirizzo di Odoo, chiave della sede, prova del collegamento, stato degli
 * invii e invio degli ordini già fatti. Solo per chi gestisce WooCommerce.
 */
defined('ABSPATH') || exit;

const LITTLEINKA_KPI_PAGE = 'littleinka-odoo-kpi';

add_action('admin_menu', function () {
    add_submenu_page(
        'woocommerce',
        __('Odoo KPI', 'littleinka-child-theme'),
        __('Odoo KPI', 'littleinka-child-theme'),
        'manage_woocommerce',
        LITTLEINKA_KPI_PAGE,
        'littleinka_kpi_admin_page'
    );
}, 70);

/** Torna alla pagina con un messaggio (codice breve nell'URL, testo lungo in un transient dell'utente). */
function littleinka_kpi_admin_redirect($notice, $detail = '')
{
    if ($detail !== '') {
        set_transient('littleinka_kpi_notice_' . get_current_user_id(), $detail, 120);
    }
    wp_safe_redirect(add_query_arg(array('page' => LITTLEINKA_KPI_PAGE, 'kpi' => $notice), admin_url('admin.php')));
    exit;
}

add_action('admin_post_littleinka_kpi_save', function () {
    if (!current_user_can('manage_woocommerce')) {
        wp_die(esc_html__('Non hai i permessi per questa pagina.', 'littleinka-child-theme'), 403);
    }
    check_admin_referer('littleinka_kpi_save');
    $url = esc_url_raw(trim((string) wp_unslash($_POST['littleinka_kpi_url'] ?? '')), array('https', 'http'));
    update_option('littleinka_kpi_url', untrailingslashit($url), false);
    $key = trim(sanitize_text_field((string) wp_unslash($_POST['littleinka_kpi_key'] ?? '')));
    if ($key !== '') {
        update_option('littleinka_kpi_key', $key, false);
    }
    if (littleinka_kpi_url() === '' || littleinka_kpi_key() === '') {
        littleinka_kpi_admin_redirect('saved');
    }
    $result = littleinka_kpi_request('ping', array('site' => home_url('/')));
    $status = (array) get_option('littleinka_kpi_status', array());
    $status['test_at'] = time();
    $status['test_ok'] = $result['ok'];
    $status['test_sede'] = $result['ok'] ? sanitize_text_field((string) ($result['data']['sede'] ?? '')) : '';
    update_option('littleinka_kpi_status', $status, false);
    $result['ok'] ? littleinka_kpi_admin_redirect('ok') : littleinka_kpi_admin_redirect('ko', $result['error']);
});

add_action('admin_post_littleinka_kpi_backfill', function () {
    if (!current_user_can('manage_woocommerce')) {
        wp_die(esc_html__('Non hai i permessi per questa pagina.', 'littleinka-child-theme'), 403);
    }
    check_admin_referer('littleinka_kpi_backfill');
    if (!littleinka_kpi_enabled()) {
        littleinka_kpi_admin_redirect('ko', __('Prima inserisci indirizzo di Odoo e chiave della sede.', 'littleinka-child-theme'));
    }
    $since = strtotime(sanitize_text_field((string) wp_unslash($_POST['littleinka_kpi_since'] ?? '')) . ' 00:00:00');
    if (!$since) {
        littleinka_kpi_admin_redirect('ko', __('Data non valida.', 'littleinka-child-theme'));
    }
    as_unschedule_all_actions('littleinka_kpi_backfill', null, LITTLEINKA_KPI_GROUP);
    $status = (array) get_option('littleinka_kpi_status', array());
    $status['backfill_running'] = time();
    $status['backfill_since'] = $since;
    $status['backfill_sent'] = 0;
    unset($status['backfill_done']);
    update_option('littleinka_kpi_status', $status, false);
    as_enqueue_async_action('littleinka_kpi_backfill', array($since, 1), LITTLEINKA_KPI_GROUP);
    littleinka_kpi_admin_redirect('backfill');
});

/** Una riga dello stato: etichetta e valore (data o testo). */
function littleinka_kpi_admin_row($label, $value)
{
    printf('<tr><th scope="row">%s</th><td>%s</td></tr>', esc_html($label), wp_kses_post($value));
}

function littleinka_kpi_admin_page()
{
    if (!current_user_can('manage_woocommerce')) {
        return;
    }
    $status = (array) get_option('littleinka_kpi_status', array());
    $date = function ($ts) {
        return $ts ? esc_html(wp_date(get_option('date_format') . ' H:i', (int) $ts)) : '—';
    };
    $notice = sanitize_key($_GET['kpi'] ?? '');
    $detail = get_transient('littleinka_kpi_notice_' . get_current_user_id());
    delete_transient('littleinka_kpi_notice_' . get_current_user_id());
    $pending = function_exists('as_get_scheduled_actions')
        ? count(as_get_scheduled_actions(array('group' => LITTLEINKA_KPI_GROUP, 'status' => 'pending', 'per_page' => 500), 'ids'))
        : 0;
    $key = littleinka_kpi_key();
    ?>
    <div class="wrap">
        <h1><?php esc_html_e('Odoo KPI', 'littleinka-child-theme'); ?></h1>
        <p><?php esc_html_e('Gli ordini di questa sede (sito, app e telefono) arrivano da soli su Odoo, nella dashboard «Little Inka KPI» insieme alle vendite in cassa. Si inviano numeri, importi, prodotti, consegna o ritiro e CAP: mai nome, e-mail, telefono o indirizzo dei clienti.', 'littleinka-child-theme'); ?></p>

        <?php if ($notice === 'ok') : ?>
            <div class="notice notice-success"><p><?php printf(esc_html__('Collegato. Odoo riconosce questa chiave come sede «%s».', 'littleinka-child-theme'), esc_html($status['test_sede'] ?? '')); ?></p></div>
        <?php elseif ($notice === 'ko') : ?>
            <div class="notice notice-error"><p><?php echo esc_html__('Odoo non ha accettato il collegamento:', 'littleinka-child-theme') . ' ' . esc_html((string) $detail); ?></p></div>
        <?php elseif ($notice === 'saved') : ?>
            <div class="notice notice-warning"><p><?php esc_html_e('Salvato. Manca ancora l’indirizzo di Odoo o la chiave della sede.', 'littleinka-child-theme'); ?></p></div>
        <?php elseif ($notice === 'backfill') : ?>
            <div class="notice notice-success"><p><?php esc_html_e('Invio degli ordini già fatti avviato: va avanti da solo, 50 ordini alla volta. Ricarica la pagina per vedere a che punto è.', 'littleinka-child-theme'); ?></p></div>
        <?php endif; ?>

        <h2><?php esc_html_e('Collegamento', 'littleinka-child-theme'); ?></h2>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="littleinka_kpi_save">
            <?php wp_nonce_field('littleinka_kpi_save'); ?>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><label for="littleinka_kpi_url"><?php esc_html_e('Indirizzo di Odoo', 'littleinka-child-theme'); ?></label></th>
                    <td>
                        <input type="url" class="regular-text" id="littleinka_kpi_url" name="littleinka_kpi_url" value="<?php echo esc_attr(littleinka_kpi_url()); ?>" placeholder="https://odoo.example.ch">
                        <p class="description"><?php esc_html_e('Lo stesso per tutte le sedi: lo trovi nella finestra della chiave in Odoo.', 'littleinka-child-theme'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="littleinka_kpi_key"><?php esc_html_e('Chiave della sede', 'littleinka-child-theme'); ?></label></th>
                    <td>
                        <input type="password" class="regular-text" id="littleinka_kpi_key" name="littleinka_kpi_key" value="" autocomplete="off"
                               placeholder="<?php echo $key !== '' ? esc_attr(sprintf(__('Salvata (…%s): lascia vuoto per tenerla', 'littleinka-child-theme'), substr($key, -4))) : esc_attr__('Incolla la chiave creata in Odoo', 'littleinka-child-theme'); ?>">
                        <p class="description"><?php esc_html_e('In Odoo: Little Inka KPI → Configurazione → Sedi → questa sede → «Crea la chiave per il sito». Ogni sede ha la sua.', 'littleinka-child-theme'); ?></p>
                    </td>
                </tr>
            </table>
            <?php submit_button(__('Salva e prova', 'littleinka-child-theme')); ?>
        </form>

        <h2><?php esc_html_e('Stato', 'littleinka-child-theme'); ?></h2>
        <table class="form-table" role="presentation">
            <?php
            littleinka_kpi_admin_row(__('Ultima prova', 'littleinka-child-theme'), empty($status['test_at']) ? '—' : $date($status['test_at']) . ' · ' . (!empty($status['test_ok']) ? esc_html__('riuscita', 'littleinka-child-theme') : esc_html__('non riuscita', 'littleinka-child-theme')));
            littleinka_kpi_admin_row(__('Ultimo invio riuscito', 'littleinka-child-theme'), $date($status['last_ok'] ?? 0));
            littleinka_kpi_admin_row(__('Ultimo errore', 'littleinka-child-theme'), empty($status['last_error']) ? '—' : $date($status['last_error']) . ' · ' . esc_html((string) ($status['last_error_text'] ?? '')));
            littleinka_kpi_admin_row(__('In coda', 'littleinka-child-theme'), esc_html((string) $pending) . ' · ' . esc_html__('se Odoo non risponde, ogni ordine si riprova da solo più tardi', 'littleinka-child-theme'));
            if (!empty($status['backfill_running']) || !empty($status['backfill_done'])) {
                $text = sprintf(__('dal %1$s: %2$d ordini inviati', 'littleinka-child-theme'), wp_date(get_option('date_format'), (int) ($status['backfill_since'] ?? 0)), (int) ($status['backfill_sent'] ?? 0));
                $text .= !empty($status['backfill_done']) ? ' · ' . __('finito', 'littleinka-child-theme') : ' · ' . __('in corso', 'littleinka-child-theme');
                littleinka_kpi_admin_row(__('Ordini già fatti', 'littleinka-child-theme'), esc_html($text));
            }
            ?>
        </table>

        <h2><?php esc_html_e('Ordini già fatti', 'littleinka-child-theme'); ?></h2>
        <p><?php esc_html_e('Gli ordini nuovi vanno su Odoo da soli. Per avere nella dashboard anche quelli di prima, scegli da quale giorno partire: rimandarli non crea doppioni.', 'littleinka-child-theme'); ?></p>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="littleinka_kpi_backfill">
            <?php wp_nonce_field('littleinka_kpi_backfill'); ?>
            <label for="littleinka_kpi_since"><?php esc_html_e('Dal giorno', 'littleinka-child-theme'); ?></label>
            <input type="date" id="littleinka_kpi_since" name="littleinka_kpi_since" value="<?php echo esc_attr(wp_date('Y') . '-01-01'); ?>" max="<?php echo esc_attr(wp_date('Y-m-d')); ?>">
            <?php submit_button(__('Invia a Odoo', 'littleinka-child-theme'), 'secondary', 'submit', false, littleinka_kpi_enabled() ? array() : array('disabled' => 'disabled')); ?>
        </form>
    </div>
    <?php
}
