<?php
/**
 * Little Inka → Odoo «Little Inka KPI» (modulo tw_littleinka_kpi).
 *
 * Ogni ordine della sede (sito, app e telefono) arriva su Odoo, dove si somma alle vendite in cassa
 * nella dashboard sede per sede. Si invia dopo il pagamento, a ogni cambio di stato e a ogni rimborso,
 * in coda (Action Scheduler): la cassa del sito non aspetta mai Odoo, e se Odoo non risponde si riprova
 * più tardi (5 min, 15 min, 1 h, 3 h, 12 h…).
 *
 * Dati inviati: numero, stato, canale, data, importi, IVA, consegna/ritiro, metodo di pagamento, CAP e
 * località di consegna, codici sconto, righe (prodotto, categoria, quantità, importo). Nessun nome,
 * e-mail, telefono o indirizzo: il cliente è un codice anonimo (HMAC dell'e-mail con un sale della rete),
 * che serve solo a contare clienti nuovi e abituali.
 *
 * Impostazioni: WooCommerce → Odoo KPI (indirizzo di Odoo e chiave della sede, creata in Odoo nella
 * scheda della sede). Comandi: wp littleinka-kpi test | sync --since=2026-01-01 | status.
 */
defined('ABSPATH') || exit;

const LITTLEINKA_KPI_GROUP = 'littleinka-kpi';
const LITTLEINKA_KPI_BATCH = 50;
const LITTLEINKA_KPI_RETRY = array(300, 900, 3600, 10800, 43200, 86400);

/** Indirizzo di Odoo senza la barra finale ('' se non impostato). */
function littleinka_kpi_url()
{
    return untrailingslashit((string) get_option('littleinka_kpi_url', ''));
}

/** Chiave della sede (mai stampata: in pagina se ne mostrano solo le ultime 4 cifre). */
function littleinka_kpi_key()
{
    return (string) get_option('littleinka_kpi_key', '');
}

function littleinka_kpi_enabled()
{
    return littleinka_kpi_url() !== '' && littleinka_kpi_key() !== '' && function_exists('as_enqueue_async_action');
}

/** Sale della rete per il codice anonimo del cliente: uguale per tutte le sedi, creato una volta. */
function littleinka_kpi_salt()
{
    $salt = get_site_option('littleinka_kpi_salt', '');
    if ($salt === '') {
        $salt = wp_generate_password(48, false, false);
        update_site_option('littleinka_kpi_salt', $salt);
    }
    return $salt;
}

/** Importo come stringa con due decimali (Odoo riceve sempre lo stesso formato). */
function littleinka_kpi_money($value)
{
    return number_format((float) $value, 2, '.', '');
}

/** Data in UTC, formato ISO, o null. */
function littleinka_kpi_date($date)
{
    return $date instanceof WC_DateTime ? gmdate('Y-m-d\TH:i:s\Z', $date->getTimestamp()) : null;
}

/** Il canale dell'ordine: sito, app o inserito a mano (telefono). */
function littleinka_kpi_channel(WC_Order $order)
{
    $via = (string) $order->get_created_via();
    if ($via === 'rest-api' || $order->get_meta('firebaseUID') !== '') {
        return 'app';
    }
    if ($via === 'admin') {
        return 'phone';
    }
    return 'web';
}

/** Consegna o ritiro: CodeRockz (delivery_type), altrimenti il metodo di spedizione. */
function littleinka_kpi_fulfilment(WC_Order $order)
{
    $type = strtolower((string) $order->get_meta('delivery_type'));
    if ($type === 'pickup' || $type === 'delivery') {
        return $type;
    }
    foreach ($order->get_shipping_methods() as $method) {
        if (in_array($method->get_method_id(), array('local_pickup', 'local_pick_up', 'pickup_location'), true)) {
            return 'pickup';
        }
    }
    return $order->get_shipping_methods() ? 'delivery' : 'pickup';
}

/** Metodo di pagamento raggruppato (le app scrivono il titolo intero al posto del codice). */
function littleinka_kpi_payment_group(WC_Order $order)
{
    $text = strtolower($order->get_payment_method() . ' ' . $order->get_payment_method_title());
    $groups = array(
        'twint'      => array('twint'),
        'apple_pay'  => array('apple'),
        'google_pay' => array('google'),
        'cash'       => array('cod', 'contanti', 'cash', 'alla consegna'),
        'card'       => array('card', 'carta', 'stripe', 'datatrans'),
    );
    foreach ($groups as $group => $needles) {
        foreach ($needles as $needle) {
            if (strpos($text, $needle) !== false) {
                return $group;
            }
        }
    }
    return trim($text) === '' ? 'none' : 'other';
}

/** Ora del servizio scelta dal cliente (CodeRockz): data e fascia, se ci sono. */
function littleinka_kpi_service(WC_Order $order)
{
    $date = (string) ($order->get_meta('delivery_date') ?: $order->get_meta('pickup_date'));
    $time = (string) ($order->get_meta('delivery_time') ?: $order->get_meta('pickup_time'));
    return array(
        'service_date' => $date !== '' && strtotime($date) ? gmdate('Y-m-d', strtotime($date)) : null,
        'service_time' => $time !== '' ? sanitize_text_field($time) : null,
    );
}

/** Nome della categoria principale del prodotto (senza il numero d'ordine «01. »). */
function littleinka_kpi_category($product)
{
    static $cache = array();
    if (!$product) {
        return '';
    }
    $id = $product->get_parent_id() ?: $product->get_id();
    if (!isset($cache[$id])) {
        $terms = get_the_terms($id, 'product_cat');
        $name = (is_array($terms) && $terms) ? $terms[0]->name : '';
        $cache[$id] = trim(preg_replace('/^\d+\.\s*/', '', html_entity_decode($name, ENT_QUOTES, 'UTF-8')));
    }
    return $cache[$id];
}

/** L'ordine come lo riceve Odoo, o null se non si invia (bozze, rimborsi, altri tipi). */
function littleinka_kpi_payload($order)
{
    if (!$order instanceof WC_Order || $order instanceof WC_Order_Refund || $order->get_type() !== 'shop_order') {
        return null;
    }
    if (in_array($order->get_status(), array('checkout-draft', 'auto-draft'), true)) {
        return null;
    }
    $lines = array();
    foreach ($order->get_items('line_item') as $item) {
        $product = $item->get_product();
        $lines[] = array(
            'product_id'   => (int) $item->get_product_id(),
            'variation_id' => (int) $item->get_variation_id(),
            'sku'          => $product ? (string) $product->get_sku() : '',
            'name'         => html_entity_decode(wp_strip_all_tags($item->get_name()), ENT_QUOTES, 'UTF-8'),
            'category'     => littleinka_kpi_category($product),
            'quantity'     => (float) $item->get_quantity(),
            'total'        => littleinka_kpi_money((float) $item->get_total() + (float) $item->get_total_tax()),
            'total_tax'    => littleinka_kpi_money($item->get_total_tax()),
        );
    }
    $email = strtolower(trim((string) $order->get_billing_email()));
    $postcode = $order->get_shipping_postcode() ?: $order->get_billing_postcode();
    $city = $order->get_shipping_city() ?: $order->get_billing_city();
    return array_merge(array(
        'id'                   => (int) $order->get_id(),
        'number'               => (string) $order->get_order_number(),
        'status'               => $order->get_status(),
        'channel'              => littleinka_kpi_channel($order),
        'fulfilment'           => littleinka_kpi_fulfilment($order),
        'date_created'         => littleinka_kpi_date($order->get_date_created()),
        'date_paid'            => littleinka_kpi_date($order->get_date_paid()),
        'date_completed'       => littleinka_kpi_date($order->get_date_completed()),
        'currency'             => $order->get_currency(),
        'total'                => littleinka_kpi_money($order->get_total()),
        'total_tax'            => littleinka_kpi_money($order->get_total_tax()),
        'shipping_total'       => littleinka_kpi_money((float) $order->get_shipping_total() + (float) $order->get_shipping_tax()),
        'discount_total'       => littleinka_kpi_money((float) $order->get_discount_total() + (float) $order->get_discount_tax()),
        'refunded'             => littleinka_kpi_money($order->get_total_refunded()),
        'payment_method'       => (string) $order->get_payment_method(),
        'payment_method_title' => wp_strip_all_tags((string) $order->get_payment_method_title()),
        'payment_group'        => littleinka_kpi_payment_group($order),
        'postcode'             => sanitize_text_field((string) $postcode),
        'city'                 => sanitize_text_field((string) $city),
        'customer_ref'         => $email !== '' ? hash_hmac('sha256', $email, littleinka_kpi_salt()) : null,
        'coupons'              => array_values($order->get_coupon_codes()),
        'lines'                => $lines,
    ), littleinka_kpi_service($order));
}

/**
 * POST a Odoo. Restituisce array('ok' => bool, 'data' => array|null, 'error' => string).
 * La chiave viaggia solo nell'intestazione Authorization, mai nell'URL.
 */
function littleinka_kpi_request($path, array $body, $timeout = 20)
{
    if (littleinka_kpi_url() === '' || littleinka_kpi_key() === '') {
        return array('ok' => false, 'data' => null, 'error' => __('Indirizzo di Odoo o chiave della sede mancanti.', 'littleinka-child-theme'));
    }
    $response = wp_remote_post(littleinka_kpi_url() . '/tw_littleinka_kpi/v1/' . $path, array(
        'timeout'     => $timeout,
        'redirection' => 0,
        'headers'     => array(
            'Authorization' => 'Bearer ' . littleinka_kpi_key(),
            'Content-Type'  => 'application/json',
            'Accept'        => 'application/json',
        ),
        'body'        => wp_json_encode($body),
    ));
    if (is_wp_error($response)) {
        return array('ok' => false, 'data' => null, 'error' => $response->get_error_message());
    }
    $code = (int) wp_remote_retrieve_response_code($response);
    $data = json_decode((string) wp_remote_retrieve_body($response), true);
    if ($code !== 200 || !is_array($data) || empty($data['ok'])) {
        $message = is_array($data) && !empty($data['error']) ? (string) $data['error'] : sprintf(__('Risposta di Odoo: HTTP %d', 'littleinka-child-theme'), $code);
        return array('ok' => false, 'data' => is_array($data) ? $data : null, 'error' => sanitize_text_field($message));
    }
    return array('ok' => true, 'data' => $data, 'error' => '');
}

/** Invia un gruppo di ordini; segna l'esito nello stato visibile in WooCommerce → Odoo KPI. */
function littleinka_kpi_send(array $orders)
{
    $payloads = array_values(array_filter(array_map('littleinka_kpi_payload', $orders)));
    if (!$payloads) {
        return array('ok' => true, 'data' => array('received' => 0), 'error' => '');
    }
    $result = littleinka_kpi_request('orders', array('site' => home_url('/'), 'orders' => $payloads));
    $status = get_option('littleinka_kpi_status', array());
    $status = is_array($status) ? $status : array();
    if ($result['ok']) {
        $status['last_ok'] = time();
        $status['last_count'] = count($payloads);
        foreach ($orders as $order) {
            if ($order instanceof WC_Order) {
                $order->update_meta_data('_littleinka_kpi_sent', time());
                $order->delete_meta_data('_littleinka_kpi_attempts');
                $order->save_meta_data();
            }
        }
    } else {
        $status['last_error'] = time();
        $status['last_error_text'] = $result['error'];
    }
    update_option('littleinka_kpi_status', $status, false);
    return $result;
}

/** Mette in coda l'invio di un ordine (una sola azione in attesa per ordine). */
function littleinka_kpi_queue($order_id)
{
    $order_id = (int) $order_id;
    if ($order_id <= 0 || !littleinka_kpi_enabled()) {
        return;
    }
    if (function_exists('as_has_scheduled_action') && as_has_scheduled_action('littleinka_kpi_push', array($order_id), LITTLEINKA_KPI_GROUP)) {
        return;
    }
    as_enqueue_async_action('littleinka_kpi_push', array($order_id), LITTLEINKA_KPI_GROUP);
}

// Ordine creato, pagato, cambiato di stato, rimborsato, cestinato o ripristinato: va su Odoo.
add_action('woocommerce_new_order', 'littleinka_kpi_queue', 20);
add_action('woocommerce_payment_complete', 'littleinka_kpi_queue', 20);
add_action('woocommerce_order_status_changed', 'littleinka_kpi_queue', 20);
add_action('woocommerce_order_refunded', 'littleinka_kpi_queue', 20);
add_action('woocommerce_trash_order', 'littleinka_kpi_queue', 20);
add_action('woocommerce_untrash_order', 'littleinka_kpi_queue', 20);
add_action('wp_trash_post', function ($post_id) {
    if (get_post_type($post_id) === 'shop_order') {
        littleinka_kpi_queue($post_id);
    }
});

/** L'azione in coda: invia l'ordine; se Odoo non risponde riprova più tardi, fino a 6 volte. */
add_action('littleinka_kpi_push', function ($order_id) {
    $order = wc_get_order((int) $order_id);
    if (!$order) {
        return;
    }
    $result = littleinka_kpi_send(array($order));
    if ($result['ok']) {
        return;
    }
    $attempt = (int) $order->get_meta('_littleinka_kpi_attempts');
    if ($attempt < count(LITTLEINKA_KPI_RETRY)) {
        $order->update_meta_data('_littleinka_kpi_attempts', $attempt + 1);
        $order->save_meta_data();
        as_schedule_single_action(time() + LITTLEINKA_KPI_RETRY[$attempt], 'littleinka_kpi_push', array((int) $order_id), LITTLEINKA_KPI_GROUP);
    }
});

/** Ordini (solo id) creati da una data, a pagine: per lo storico e per il comando sync. */
function littleinka_kpi_order_ids($since_ts, $page)
{
    return wc_get_orders(array(
        'type'         => 'shop_order',
        'status'       => array_keys(wc_get_order_statuses()),
        'date_created' => '>=' . (int) $since_ts,
        'orderby'      => 'ID',
        'order'        => 'ASC',
        'limit'        => LITTLEINKA_KPI_BATCH,
        'paged'        => max(1, (int) $page),
        'return'       => 'ids',
    ));
}

/** Storico: una pagina di ordini per azione, poi la pagina dopo, finché ci sono ordini. */
add_action('littleinka_kpi_backfill', function ($since_ts, $page = 1) {
    $ids = littleinka_kpi_order_ids($since_ts, $page);
    if (!$ids) {
        $status = (array) get_option('littleinka_kpi_status', array());
        unset($status['backfill_running']);
        $status['backfill_done'] = time();
        update_option('littleinka_kpi_status', $status, false);
        return;
    }
    $result = littleinka_kpi_send(array_filter(array_map('wc_get_order', $ids)));
    if (!$result['ok']) {
        // Odoo non risponde: la stessa pagina tra 15 minuti.
        as_schedule_single_action(time() + 900, 'littleinka_kpi_backfill', array((int) $since_ts, (int) $page), LITTLEINKA_KPI_GROUP);
        return;
    }
    $status = (array) get_option('littleinka_kpi_status', array());
    $status['backfill_sent'] = (int) ($status['backfill_sent'] ?? 0) + count($ids);
    update_option('littleinka_kpi_status', $status, false);
    as_enqueue_async_action('littleinka_kpi_backfill', array((int) $since_ts, (int) $page + 1), LITTLEINKA_KPI_GROUP);
}, 10, 2);

if (is_admin()) {
    require_once LITTLEINKA_DIR . '/inc/odoo-kpi-admin.php';
}

if (defined('WP_CLI') && WP_CLI) {
    /**
     * Little Inka → Odoo KPI.
     *
     * ## EXAMPLES
     *     wp littleinka-kpi test --url=bellinzona.littleinka.ch
     *     wp littleinka-kpi sync --since=2026-01-01 --url=bellinzona.littleinka.ch
     *     wp littleinka-kpi status --url=bellinzona.littleinka.ch
     */
    WP_CLI::add_command('littleinka-kpi', new class {
        /** Prova la connessione con Odoo e mostra la sede collegata alla chiave. */
        public function test()
        {
            $result = littleinka_kpi_request('ping', array('site' => home_url('/')));
            $result['ok'] ? WP_CLI::success(sprintf('Collegato a Odoo, sede «%s».', $result['data']['sede'] ?? '?')) : WP_CLI::error($result['error']);
        }

        /**
         * Invia subito a Odoo gli ordini creati da una data (senza coda).
         *
         * [--since=<date>]
         * : Data di partenza, AAAA-MM-GG. Predefinito: inizio dell'anno.
         */
        public function sync($args, $assoc)
        {
            $since = strtotime(($assoc['since'] ?? gmdate('Y') . '-01-01') . ' 00:00:00');
            if (!$since) {
                WP_CLI::error('Data non valida: usa AAAA-MM-GG.');
            }
            $page = 1;
            $sent = 0;
            while ($ids = littleinka_kpi_order_ids($since, $page)) {
                $result = littleinka_kpi_send(array_filter(array_map('wc_get_order', $ids)));
                if (!$result['ok']) {
                    WP_CLI::error(sprintf('Pagina %d: %s (inviati finora: %d)', $page, $result['error'], $sent));
                }
                $sent += count($ids);
                WP_CLI::log(sprintf('Inviati %d ordini…', $sent));
                $page++;
            }
            WP_CLI::success(sprintf('%d ordini inviati a Odoo.', $sent));
        }

        /** Stato dell'ultimo invio e ordini in coda. */
        public function status()
        {
            $status = (array) get_option('littleinka_kpi_status', array());
            WP_CLI::log('Odoo: ' . (littleinka_kpi_url() ?: '(non impostato)'));
            WP_CLI::log('Chiave: ' . (littleinka_kpi_key() !== '' ? '…' . substr(littleinka_kpi_key(), -4) : '(non impostata)'));
            foreach (array('last_ok', 'last_error', 'backfill_done') as $key) {
                if (!empty($status[$key])) {
                    WP_CLI::log($key . ': ' . wp_date('Y-m-d H:i', (int) $status[$key]));
                }
            }
            if (!empty($status['last_error_text'])) {
                WP_CLI::log('Ultimo errore: ' . $status['last_error_text']);
            }
            if (function_exists('as_get_scheduled_actions')) {
                WP_CLI::log('In coda: ' . count(as_get_scheduled_actions(array('group' => LITTLEINKA_KPI_GROUP, 'status' => 'pending', 'per_page' => 500), 'ids')));
            }
        }
    });
}
