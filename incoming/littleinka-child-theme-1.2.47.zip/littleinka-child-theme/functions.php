<?php
/**
 * Little Inka: child di ticinoWEB CMS (ticinoweb-ai-theme) per le sedi, senza Elementor.
 * Un solo tema per tutte le sedi: contatti, orari, logo, SEO, cookie e FAQ restano nel parent,
 * prodotti e consegne in WooCommerce e CodeRockz, i pochi dati propri della sede in
 * Aspetto → Personalizza → Little Inka (inc/settings.php).
 */
defined('ABSPATH') || exit;

define('LITTLEINKA_VERSION', wp_get_theme(get_stylesheet())->get('Version'));
define('LITTLEINKA_DIR', get_stylesheet_directory());
define('LITTLEINKA_URI', get_stylesheet_directory_uri());
// Sito che elenca tutte le sedi: valore predefinito di «Cambia sede» (si cambia in Personalizza → Little Inka).
define('LITTLEINKA_PORTAL_DEFAULT', 'https://littleinka.ch');
// La società che firma il © di tutte le sedi (si cambia in Personalizza → Little Inka).
define('LITTLEINKA_COPYRIGHT_DEFAULT', 'Little Inka Sagl');

require_once LITTLEINKA_DIR . '/inc/helpers.php';
require_once LITTLEINKA_DIR . '/inc/icone.php';
require_once LITTLEINKA_DIR . '/inc/points.php';
require_once LITTLEINKA_DIR . '/inc/delivery.php';
require_once LITTLEINKA_DIR . '/inc/settings.php';
require_once LITTLEINKA_DIR . '/inc/menu.php';
require_once LITTLEINKA_DIR . '/inc/poke.php';
require_once LITTLEINKA_DIR . '/inc/shop.php';
require_once LITTLEINKA_DIR . '/inc/quick-add.php';
require_once LITTLEINKA_DIR . '/inc/seo.php';
require_once LITTLEINKA_DIR . '/inc/odoo-kpi.php';
if (is_admin()) {
    require_once LITTLEINKA_DIR . '/inc/content-transfer.php';
    require_once LITTLEINKA_DIR . '/inc/setup-check.php';
}

add_action('after_setup_theme', function () {
    load_child_theme_textdomain('littleinka-child-theme', LITTLEINKA_DIR . '/languages');
    add_post_type_support('page', 'excerpt');
    // La posizione «primary» è del parent; queste due riempiono le colonne del footer.
    register_nav_menus(array(
        'littleinka_footer_links'   => __('Footer: link veloci', 'littleinka-child-theme'),
        'littleinka_footer_support' => __('Footer: informazioni e supporto', 'littleinka-child-theme'),
    ));
}, 20);

/**
 * Stili e script. Il parent accoda già lo style.css del child («ticinoweb-ai-style») con la versione del
 * parent: qui si aggiunge il suo style.css come dipendenza e si versiona tutto con la versione del child
 * (ogni rilascio svuota la cache del browser). Poppins di Google non si scarica: i caratteri sono nel tema.
 */
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('littleinka-parent', get_template_directory_uri() . '/style.css', array(), wp_get_theme(get_template())->get('Version'));
    if (isset(wp_styles()->registered['ticinoweb-ai-style'])) {
        wp_styles()->registered['ticinoweb-ai-style']->deps[] = 'littleinka-parent';
        wp_styles()->registered['ticinoweb-ai-style']->ver = LITTLEINKA_VERSION;
    }
    // Handle vuoto al posto del font di Google: la dipendenza del parent resta valida, non si stampa nulla.
    wp_deregister_style('poppins-font');
    wp_register_style('poppins-font', false, array(), null);

    // Le pagine sono HTML del tema, non blocchi: gli stili dei blocchi pesano ~28 KB su ogni pagina.
    wp_dequeue_style('wp-block-library');
    wp_dequeue_style('classic-theme-styles');
    wp_dequeue_style('global-styles');
    wp_enqueue_script('littleinka-site', LITTLEINKA_URI . '/assets/js/site.js', array(), LITTLEINKA_VERSION, array('in_footer' => true, 'strategy' => 'defer'));
    wp_localize_script('littleinka-site', 'littleInka', array(
        'menuOpen'  => littleinka_t(__('Apri il menu', 'littleinka-child-theme'), 'ui:menu_open'),
        'fragments' => function_exists('WC') ? esc_url_raw(WC_AJAX::get_endpoint('get_refreshed_fragments')) : '',
        'menuClose' => littleinka_t(__('Chiudi il menu', 'littleinka-child-theme'), 'ui:menu_close'),
        'close'     => littleinka_t(__('Chiudi', 'littleinka-child-theme'), 'ui:close'),
    ));
}, 20);

/**
 * CSS di un modulo (assets/css/<modulo>.css), accodato solo dalle pagine che lo usano.
 * Dipende dallo style.css del child, così i token :root sono già definiti.
 */
function littleinka_enqueue_module_css($module)
{
    $handle = 'littleinka-' . sanitize_key($module);
    if (!wp_style_is($handle, 'enqueued') && file_exists(LITTLEINKA_DIR . '/assets/css/' . sanitize_key($module) . '.css')) {
        wp_enqueue_style($handle, LITTLEINKA_URI . '/assets/css/' . sanitize_key($module) . '.css', array('ticinoweb-ai-style'), LITTLEINKA_VERSION);
    }
}

/** JS di un modulo (assets/js/<modulo>.js), con le dipendenze indicate, differito in fondo alla pagina. */
function littleinka_enqueue_module_js($module, $deps = array(), $data = null)
{
    $handle = 'littleinka-' . sanitize_key($module);
    if (!wp_script_is($handle, 'enqueued') && file_exists(LITTLEINKA_DIR . '/assets/js/' . sanitize_key($module) . '.js')) {
        wp_enqueue_script($handle, LITTLEINKA_URI . '/assets/js/' . sanitize_key($module) . '.js', $deps, LITTLEINKA_VERSION, array('in_footer' => true, 'strategy' => 'defer'));
        if (is_array($data)) {
            wp_add_inline_script($handle, 'window.littleInka' . ucfirst(sanitize_key($module)) . ' = ' . wp_json_encode($data) . ';', 'before');
        }
    }
}

/**
 * Sfondo decorativo della sede (Personalizza → Little Inka): un motivo ripetuto, molto trasparente, dietro le parti bianche.
 * Si usa la misura 1536 px dell'immagine (non l'originale da 2560): fiori grandi ma file leggero.
 */
add_action('wp_enqueue_scripts', function () {
    $id = (int) littleinka_setting('bg_pattern', 0);
    if (!$id || !wp_attachment_is_image($id)) {
        return;
    }
    $src = wp_get_attachment_image_src($id, '1536x1536') ?: wp_get_attachment_image_src($id, 'large');
    if (!$src) {
        return;
    }
    $strength = max(2, min(20, (int) littleinka_setting('bg_pattern_strength', 4)));
    wp_add_inline_style('ticinoweb-ai-style', ':root{--li-pattern:url("' . esc_url_raw($src[0]) . '");--li-pattern-opacity:' . ($strength / 100) . ';}');
}, 25);
add_filter('body_class', function ($classes) {
    if ((int) littleinka_setting('bg_pattern', 0)) {
        $classes[] = 'li-has-pattern';
    }
    return $classes;
});

/** Il carattere dei titoli si precarica: lo usano il logo testuale, l'h1 e il menu. */
add_action('wp_head', function () {
    printf('<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url(LITTLEINKA_URI . '/assets/fonts/bricolage-grotesque-latin.woff2'));
}, 1);

/**
 * Il parent apre due preconnect verso Google Fonts su ogni pagina (closure su wp_head 0): si tolgono,
 * perché nessun carattere arriva da Google e l'IP del visitatore non deve uscire prima del consenso.
 */
add_action('wp_head', function () {
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    global $wp_filter;
    if (empty($wp_filter['wp_head']) || empty($wp_filter['wp_head']->callbacks[0])) {
        return;
    }
    $parent_functions = wp_normalize_path(get_template_directory() . '/functions.php');
    foreach ($wp_filter['wp_head']->callbacks[0] as $callback) {
        if (!($callback['function'] instanceof Closure)) {
            continue;
        }
        $ref = new ReflectionFunction($callback['function']);
        if (wp_normalize_path((string) $ref->getFileName()) !== $parent_functions) {
            continue;
        }
        $lines = file($parent_functions);
        $body  = implode('', array_slice((array) $lines, $ref->getStartLine() - 1, $ref->getEndLine() - $ref->getStartLine() + 1));
        if (strpos($body, 'fonts.googleapis.com') !== false) {
            remove_action('wp_head', $callback['function'], 0);
        }
    }
}, -100);

/** Emoji di WordPress: scaricherebbero immagini da s.w.org prima del consenso ai cookie. */
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');
add_filter('emoji_svg_url', '__return_false');

/**
 * WordPress mette sizes="auto" sulle immagini lazy e le pianta a 1500px (contain-intrinsic-size):
 * nel menu le foto dei piatti si vedrebbero enormi finché il CSS non arriva. Si spegne.
 */
add_filter('wp_img_tag_add_auto_sizes', '__return_false');

/** Classi del body: offerta e metodi di consegna della sede, così il CSS e i template si adattano. */
add_filter('body_class', function ($classes) {
    $classes[] = 'li-offerta-' . littleinka_offer();
    $delivery = littleinka_delivery();
    $classes[] = $delivery['delivery'] ? 'li-consegna-si' : 'li-consegna-no';
    $classes[] = $delivery['pickup'] ? 'li-ritiro-si' : 'li-ritiro-no';
    return $classes;
});

/** Le pagine fatte a sezioni (classi li-*) sono HTML pronto: niente paragrafi automatici. */
add_filter('the_content', function ($content) {
    if (is_singular() && strpos($content, 'class="li-') !== false) {
        remove_filter('the_content', 'wpautop');
    }
    return $content;
}, 9);

/**
 * Le funzioni del tema che dipendono da un plugin lo dicono in bacheca, invece di tacere:
 * WooCommerce (menu, carrello), Product Add-ons e Make your own Pokè (Crea la tua poké).
 */
add_action('admin_notices', function () {
    if (!current_user_can('switch_themes')) {
        return;
    }
    $missing = array();
    if (!class_exists('WooCommerce')) {
        $missing[] = 'WooCommerce';
    }
    if (!class_exists('WC_Product_Addons_Helper')) {
        $missing[] = 'WooCommerce Product Add-ons';
    }
    if (!defined('BRTW_VERSION')) {
        $missing[] = 'Make your own Pokè';
    }
    if ($missing) {
        echo '<div class="notice notice-warning"><p>' . esc_html(sprintf(
            /* translators: %s: elenco di plugin */
            __('Tema Little Inka: per il menu online e «Crea la tua poké» servono questi plugin, ora non attivi: %s.', 'littleinka-child-theme'),
            implode(', ', $missing)
        )) . '</p></div>';
    }
});
