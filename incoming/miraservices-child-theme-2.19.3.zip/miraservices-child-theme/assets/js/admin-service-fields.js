(() => {
	'use strict';

	const select = document.querySelector('[data-mira-service-media-select]');
	const remove = document.querySelector('[data-mira-service-media-remove]');
	const input = document.querySelector('[data-mira-service-media-id]');
	const preview = document.querySelector('[data-mira-service-media-preview]');
	if (!select || !input || !preview || !window.wp?.media) return;

	select.addEventListener('click', () => {
		const frame = window.wp.media({ title: 'Scegli immagine secondaria', button: { text: 'Usa questa immagine' }, multiple: false, library: { type: 'image' } });
		frame.on('select', () => {
			const image = frame.state().get('selection').first().toJSON();
			input.value = image.id;
			preview.src = image.sizes?.medium?.url || image.url;
			preview.hidden = false;
			if (remove) remove.hidden = false;
		});
		frame.open();
	});

	remove?.addEventListener('click', () => {
		input.value = '';
		preview.src = '';
		preview.hidden = true;
		remove.hidden = true;
	});
})();
