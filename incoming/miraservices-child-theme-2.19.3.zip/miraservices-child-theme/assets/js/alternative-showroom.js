(() => {
 'use strict';
 const root=document.querySelector('[data-alt-showroom]');if(!root)return;
 const links=[...root.querySelectorAll('[data-showroom-photo]')];
 const dialog=root.querySelector('[data-showroom-dialog]');if(!dialog||typeof dialog.showModal!=='function')return;
 const image=dialog.querySelector('[data-showroom-image]'),caption=dialog.querySelector('[data-showroom-caption]');
 const position=dialog.querySelector('[data-showroom-position]'),announcement=dialog.querySelector('[data-showroom-announcement]');
 const cursor=document.querySelector('[data-mira-cursor]');
 const cursorParent=cursor?.parentNode,cursorNext=cursor?.nextSibling;
 let index=0,opener=null;
 const show=(next)=>{
  index=(next+links.length)%links.length;const link=links[index];
  image.src=link.href;image.alt=link.dataset.title||'';caption.textContent=link.dataset.title||'';
  position.textContent=`${String(index+1).padStart(2,'0')} / ${links.length}`;announcement.textContent=position.textContent;
 };
 links.forEach((link,i)=>link.addEventListener('click',(event)=>{
  if(event.ctrlKey||event.metaKey||event.shiftKey||event.altKey)return;
  event.preventDefault();opener=link;show(i);
  // A modal is in the browser top layer: the existing decorative cursor must join it.
  if(cursor)dialog.append(cursor);
  dialog.showModal();document.body.classList.add('mira-showroom-open');
 }));
 dialog.querySelector('[data-showroom-close]').addEventListener('click',()=>dialog.close());
 dialog.querySelector('[data-showroom-prev]').addEventListener('click',()=>show(index-1));
 dialog.querySelector('[data-showroom-next]').addEventListener('click',()=>show(index+1));
 dialog.addEventListener('keydown',(event)=>{if(event.key==='ArrowRight'){event.preventDefault();show(index+1);}if(event.key==='ArrowLeft'){event.preventDefault();show(index-1);}});
 dialog.addEventListener('close',()=>{
  if(cursor&&cursorParent)cursorParent.insertBefore(cursor,cursorNext?.parentNode===cursorParent?cursorNext:null);
  document.body.classList.remove('mira-showroom-open');opener?.focus({preventScroll:true});
 });
})();
