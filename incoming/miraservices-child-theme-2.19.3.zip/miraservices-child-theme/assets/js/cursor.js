(() => {
	'use strict';

	const cursor = document.querySelector('[data-mira-cursor]');
	const label = cursor?.querySelector('[data-mira-cursor-label]');
	const finePointer = window.matchMedia('(hover: hover) and (pointer: fine)');
	const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
	const interactiveSelector = 'a, button, [role="button"], input, textarea, select, label, summary, [tabindex]:not([tabindex="-1"])';
	const fieldSelector = 'input, textarea, select, [contenteditable="true"]';
	const importantSelector = '[data-cursor-label], .mira-button, .mira-header__cta, .mira-service-button, .mira-emergency__call-btn, .mira-reference__row';
	let targetX = -80;
	let targetY = -80;
	let currentX = -80;
	let currentY = -80;
	let frame = 0;
	let enabled = false;

	if (!cursor) return;

	const render = () => {
		const ease = reducedMotion.matches ? 1 : 0.22;
		currentX += (targetX - currentX) * ease;
		currentY += (targetY - currentY) * ease;
		cursor.style.transform = `translate3d(${currentX}px, ${currentY}px, 0)`;
		if (Math.abs(targetX - currentX) > 0.1 || Math.abs(targetY - currentY) > 0.1) {
			frame = window.requestAnimationFrame(render);
		} else {
			frame = 0;
		}
	};

	const scheduleRender = () => {
		if (!frame) frame = window.requestAnimationFrame(render);
	};

	const resetState = () => {
		cursor.classList.remove('is-visible', 'is-hovering', 'is-active', 'is-input', 'has-label');
		if (label) label.textContent = '↗';
	};

	const setEnabled = () => {
		enabled = finePointer.matches;
		document.documentElement.classList.toggle('mira-cursor-ready', enabled);
		if (!enabled) resetState();
	};

	document.addEventListener('pointermove', (event) => {
		if (!enabled || event.pointerType === 'touch') return;
		targetX = event.clientX;
		targetY = event.clientY;
		if (!cursor.classList.contains('is-visible')) {
			currentX = targetX;
			currentY = targetY;
			cursor.classList.add('is-visible');
		}
		scheduleRender();
	}, { passive: true });

	document.addEventListener('pointerover', (event) => {
		if (!enabled || !(event.target instanceof Element)) return;
		const interactive = event.target.closest(interactiveSelector);
		const field = event.target.closest(fieldSelector);
		const important = event.target.closest(importantSelector);
		cursor.classList.toggle('is-hovering', Boolean(interactive));
		cursor.classList.toggle('is-input', Boolean(field));
		cursor.classList.toggle('has-label', Boolean(important) && !field);
		if (label && important && !field) label.textContent = important.dataset.cursorLabel || '↗';
	});

	document.addEventListener('pointerdown', (event) => {
		if (enabled && event.pointerType !== 'touch') cursor.classList.add('is-active');
	});
	document.addEventListener('pointerup', () => cursor.classList.remove('is-active'));
	document.addEventListener('pointercancel', () => cursor.classList.remove('is-active'));
	document.documentElement.addEventListener('mouseleave', () => cursor.classList.remove('is-visible'));
	document.addEventListener('visibilitychange', () => {
		if (document.hidden) cursor.classList.remove('is-visible');
	});

	finePointer.addEventListener?.('change', setEnabled);
	setEnabled();
})();
