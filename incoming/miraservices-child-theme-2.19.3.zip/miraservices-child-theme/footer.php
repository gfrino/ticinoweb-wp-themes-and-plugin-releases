<?php
/**
 * Global editorial site footer.
 *
 * @package MiraServicesChildTheme
 */

$mira_contact       = function_exists( 'ticinoweb_get_contact_info' ) ? ticinoweb_get_contact_info() : array();
$mira_logo          = function_exists( 'ticinoweb_get_site_logo' ) ? ticinoweb_get_site_logo() : '';
$mira_menu          = miraservices_get_primary_menu_tree();
$mira_services      = miraservices_get_frontend_services();
$mira_legal_links   = miraservices_get_legal_links();
$mira_footer_visual = array();

foreach ( $mira_services as $mira_service ) {
	if ( empty( $mira_service['secondary_image'] ) ) {
		continue;
	}
	if ( empty( $mira_footer_visual ) || 'giardinaggio' === $mira_service['id'] ) {
		$mira_footer_visual = $mira_service;
	}
	if ( 'giardinaggio' === $mira_service['id'] ) {
		break;
	}
}

$mira_footer_image_url = ! empty( $mira_footer_visual['secondary_image'] ) ? (string) $mira_footer_visual['secondary_image'] : '';
$mira_footer_image_id  = (int) get_option( 'miraservices_footer_image_id', 0 );

if ( $mira_footer_image_id && wp_attachment_is_image( $mira_footer_image_id ) ) {
	$mira_selected_footer_image_url = wp_get_attachment_url( $mira_footer_image_id );
	if ( $mira_selected_footer_image_url ) {
		$mira_footer_image_url = $mira_selected_footer_image_url;
	}
}

$mira_footer_description = get_bloginfo( 'description' );
if ( ! $mira_footer_description ) {
	$mira_footer_description = __( 'Cura, manutenzione e gestione operativa di immobili e spazi.', 'miraservices' );
}
?>
<aside class="mira-footer-bridge" id="mira-footer-cta" aria-labelledby="mira-footer-bridge-title">
	<div class="mira-footer-bridge__media" aria-hidden="true">
		<?php if ( ! empty( $mira_footer_visual['secondary_image'] ) ) : ?>
			<?php echo miraservices_image( $mira_footer_visual['secondary_image'], array( 'alt' => '', 'loading' => 'lazy', 'sizes' => '100vw', 'attachment_only' => true ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<?php endif; ?>
	</div>
	<div class="mira-shell mira-footer-bridge__content">
		<div>
			<h2 id="mira-footer-bridge-title"><?php esc_html_e( 'Hai un immobile da seguire?', 'miraservices' ); ?></h2>
			<p><?php esc_html_e( 'Dalla manutenzione quotidiana agli interventi urgenti, Mira Services è un unico riferimento per la cura dei tuoi spazi.', 'miraservices' ); ?></p>
		</div>
		<a class="mira-footer-bridge__cta" href="<?php echo esc_url( miraservices_frontend_home_url( 'contatti' ) ); ?>" data-cursor-label="<?php esc_attr_e( 'CONTATTA', 'miraservices' ); ?>">
			<span><?php esc_html_e( 'Richiedi un preventivo', 'miraservices' ); ?></span>
			<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 19 19 5M9 5h10v10"/></svg>
		</a>
	</div>
</aside>

<footer class="mira-footer" data-mira-footer>
	<?php if ( $mira_footer_image_url ) : ?>
		<div class="mira-footer__material" aria-hidden="true">
			<?php echo miraservices_image( $mira_footer_image_url, array( 'alt' => '', 'loading' => 'lazy', 'sizes' => '(min-width: 1100px) 42vw, 1px', 'attachment_only' => true ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</div>
	<?php endif; ?>

	<div class="mira-shell mira-footer__inner">
		<div class="mira-footer__masthead">
			<a class="mira-footer__brand" href="<?php echo esc_url( miraservices_frontend_home_url() ); ?>" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?> — <?php esc_attr_e( 'Home', 'miraservices' ); ?>">
				<?php if ( $mira_logo ) : ?>
					<img src="<?php echo esc_url( $mira_logo ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" width="220" height="76">
				<?php else : ?>
					<span><?php bloginfo( 'name' ); ?></span>
				<?php endif; ?>
			</a>
			<div class="mira-footer__claim">
				<h2><?php esc_html_e( 'Un solo riferimento per il tuo immobile.', 'miraservices' ); ?></h2>
				<p><?php echo esc_html( $mira_footer_description ); ?></p>
			</div>
		</div>

		<div class="mira-footer__directory">
			<section class="mira-footer__group mira-footer__contacts" aria-labelledby="mira-footer-contacts-title">
				<h3 id="mira-footer-contacts-title"><?php esc_html_e( 'Contatti', 'miraservices' ); ?></h3>
				<div class="mira-footer__contact-list">
					<?php if ( ! empty( $mira_contact['address'] ) ) : ?><address><?php echo esc_html( $mira_contact['address'] ); ?></address><?php endif; ?>
					<?php if ( ! empty( $mira_contact['phone'] ) ) : ?><a href="tel:<?php echo esc_attr( miraservices_phone_uri( $mira_contact['phone'] ) ); ?>"><?php echo esc_html( miraservices_format_phone( $mira_contact['phone'] ) ); ?></a><?php endif; ?>
					<?php if ( ! empty( $mira_contact['email'] ) ) : ?><a href="mailto:<?php echo esc_attr( $mira_contact['email'] ); ?>"><?php echo esc_html( $mira_contact['email'] ); ?></a><?php endif; ?>
				</div>
				<div class="mira-footer__socials">
					<?php foreach ( array( 'instagram' => 'Instagram', 'facebook' => 'Facebook', 'linkedin' => 'LinkedIn' ) as $mira_network => $mira_label ) : ?>
						<?php if ( ! empty( $mira_contact[ $mira_network ] ) ) : ?><a href="<?php echo esc_url( $mira_contact[ $mira_network ] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $mira_label ); ?></a><?php endif; ?>
					<?php endforeach; ?>
				</div>
			</section>

			<nav class="mira-footer__group mira-footer__services" aria-labelledby="mira-footer-services-title">
				<h3 id="mira-footer-services-title"><?php esc_html_e( 'Servizi', 'miraservices' ); ?></h3>
				<ul>
					<?php foreach ( $mira_services as $mira_service ) : ?>
						<?php if ( ! empty( $mira_service['title'] ) && ! empty( $mira_service['url'] ) ) : ?>
							<li><a href="<?php echo esc_url( $mira_service['url'] ); ?>"><span><?php echo esc_html( $mira_service['title'] ); ?></span></a></li>
						<?php endif; ?>
					<?php endforeach; ?>
				</ul>
			</nav>

			<nav class="mira-footer__group mira-footer__navigation" aria-labelledby="mira-footer-navigation-title">
				<h3 id="mira-footer-navigation-title"><?php esc_html_e( 'Navigazione', 'miraservices' ); ?></h3>
				<ul>
					<?php foreach ( $mira_menu as $mira_item ) : ?>
						<li><a href="<?php echo esc_url( $mira_item['url'] ); ?>"><span><?php echo esc_html( $mira_item['title'] ); ?></span></a></li>
					<?php endforeach; ?>
				</ul>
					<?php if ( has_nav_menu( 'miraservices-footer' ) ) {
						wp_nav_menu( array( 'theme_location' => 'miraservices-footer', 'container' => false, 'menu_class' => 'mira-footer__extra', 'fallback_cb' => false, 'depth' => 1 ) );
					} ?>
			</nav>
		</div>

		<?php if ( ! empty( $mira_contact['phone'] ) ) : ?>
			<div class="mira-footer__emergency">
				<span class="mira-footer__emergency-dot" aria-hidden="true"></span>
				<div>
					<strong><?php esc_html_e( 'Picchetto 24h', 'miraservices' ); ?></strong>
					<p><?php esc_html_e( 'Per le necessità che non possono aspettare.', 'miraservices' ); ?></p>
				</div>
				<a href="tel:<?php echo esc_attr( miraservices_phone_uri( $mira_contact['phone'] ) ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Chiama il Picchetto 24h al numero %s', 'miraservices' ), miraservices_format_phone( $mira_contact['phone'] ) ) ); ?>">
					<span><?php echo esc_html( miraservices_format_phone( $mira_contact['phone'] ) ); ?></span>
					<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 19 19 5M9 5h10v10"/></svg>
				</a>
			</div>
		<?php endif; ?>

		<div class="mira-footer__wordmark" aria-hidden="true">MIRA</div>

		<div class="mira-footer__bottom">
			<p>© <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?></p>
			<?php if ( ! empty( $mira_legal_links ) ) : ?>
				<nav class="mira-footer__legal" aria-label="<?php esc_attr_e( 'Link legali', 'miraservices' ); ?>">
					<?php foreach ( $mira_legal_links as $mira_legal_link ) : ?>
						<a href="<?php echo esc_url( $mira_legal_link['url'] ); ?>"><?php echo esc_html( $mira_legal_link['label'] ); ?></a>
					<?php endforeach; ?>
				</nav>
			<?php endif; ?>
			<a class="mira-footer__back-to-top" href="<?php echo esc_url( miraservices_frontend_home_url( 'home' ) ); ?>">
				<span><?php esc_html_e( 'Torna su', 'miraservices' ); ?></span>
				<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 19V5M6 11l6-6 6 6"/></svg>
			</a>
		</div>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
