<?php
/** Read the parent media gallery. No parallel settings or automatic media publication. */
defined( 'ABSPATH' ) || exit;

function miraservices_get_showroom() {
	$empty = array( 'title' => '', 'description' => '', 'ids' => array() );
	$term = get_term_by( 'slug', 'showroom-realizzazioni', 'ticinoweb_media_gallery' );
	if ( ! $term || is_wp_error( $term ) ) { return $empty; }
	$photos = get_posts( array(
		'post_type' => 'attachment', 'post_status' => 'inherit', 'post_mime_type' => 'image',
		'posts_per_page' => 500, 'orderby' => 'ID', 'order' => 'ASC', 'update_post_meta_cache' => true,
		'tax_query' => array( array( 'taxonomy' => 'ticinoweb_media_gallery', 'field' => 'term_id', 'terms' => $term->term_id ) ),
	) );
	$ids = array_map( static function ( $photo ) { return (int) $photo->ID; }, $photos );
	$order = get_term_meta( $term->term_id, '_ticinoweb_gallery_order', true );
	$order = is_array( $order ) ? array_map( 'intval', $order ) : array();
	$ordered = array_unique( array_merge( array_intersect( $order, $ids ), $ids ) );
	$valid = array(); $seen = array();
	foreach ( $ordered as $id ) {
		$meta = wp_get_attachment_metadata( $id ); $url = wp_get_attachment_url( $id );
		if ( ! wp_attachment_is_image( $id ) || empty( $meta['width'] ) || empty( $meta['height'] ) || ! $url || isset( $seen[ $url ] ) ) { continue; }
		$seen[ $url ] = true; $valid[] = (int) $id;
	}
	return array( 'title' => $term->name, 'description' => $term->description, 'ids' => $valid );
}

/** Ratio-led rows: keep full photographs, including very tall portraits. */
function miraservices_showroom_rows( $ids ) {
	$rows = array(); $row = array(); $ratio = 0;
	foreach ( $ids as $id ) {
		$meta = wp_get_attachment_metadata( $id );
		$row[] = $id; $ratio += $meta['width'] / $meta['height'];
		if ( $ratio >= 3.2 || count( $row ) >= 5 ) { $rows[] = $row; $row = array(); $ratio = 0; }
	}
	if ( $row ) { $rows[] = $row; }
	return $rows;
}
