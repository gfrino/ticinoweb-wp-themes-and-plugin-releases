<?php
/**
 * Child-owned editorial controls for the shared service template.
 *
 * The WordPress page remains the source of truth for copy. These fields only
 * cover relationships and visual data that the parent CMS does not expose.
 *
 * @package MiraServicesChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return the compact defaults used by the one-time 2.7 migration.
 *
 * Audience labels are distilled from the already published page copy. Related
 * services preserve the editorial relationships used by the previous template.
 *
 * @return array<string,array<string,mixed>>
 */
function miraservices_service_field_defaults() {
	return array(
		'manutenzione-immobili' => array(
			'intro_title' => __( 'Manutenzione pensata per durare.', 'miraservices' ),
			'audience'    => array( 'Proprietari', 'Amministrazioni', 'Condomini', 'Seconde case', 'Uffici', 'Attività commerciali' ),
			'related'     => array( 'portineria-custodia', 'muratura-pittura', 'giardinaggio' ),
			'style'       => 'technical',
		),
		'giardinaggio' => array(
			'intro_title' => __( 'Il verde, seguito stagione dopo stagione.', 'miraservices' ),
			'audience'    => array( 'Ville e abitazioni', 'Condomini', 'Seconde case', 'Immobili commerciali' ),
			'related'     => array( 'manutenzione-immobili', 'portineria-custodia' ),
			'style'       => 'outdoor',
		),
		'pulizie' => array(
			'intro_title' => __( 'Pulizie organizzate intorno agli spazi.', 'miraservices' ),
			'audience'    => array( 'Amministrazioni', 'Aziende', 'Studi', 'Attività commerciali', 'Proprietari' ),
			'related'     => array( 'portineria-custodia', 'manutenzione-immobili', 'picchetto-24h' ),
			'style'       => 'standard',
		),
		'portineria-custodia' => array(
			'intro_title' => __( 'Una presenza che conosce l’immobile.', 'miraservices' ),
			'audience'    => array( 'Amministrazioni', 'Condomini', 'Seconde case', 'Proprietari' ),
			'related'     => array( 'manutenzione-immobili', 'pulizie', 'giardinaggio' ),
			'style'       => 'standard',
		),
		'muratura-pittura' => array(
			'intro_title' => __( 'Ripristini precisi, ambienti rinnovati.', 'miraservices' ),
			'audience'    => array( 'Abitazioni', 'Spazi comuni', 'Uffici', 'Ambienti commerciali' ),
			'related'     => array( 'ristrutturazioni', 'manutenzione-immobili' ),
			'style'       => 'technical',
		),
		'ristrutturazioni' => array(
			'intro_title' => __( 'Un progetto coordinato dall’inizio alla fine.', 'miraservices' ),
			'audience'    => array( 'Abitazioni', 'Immobili residenziali', 'Spazi commerciali', 'Ambienti da rinnovare' ),
			'related'     => array( 'muratura-pittura', 'pulizie', 'manutenzione-immobili' ),
			'style'       => 'technical',
		),
		'traslochi-sgomberi' => array(
			'intro_title' => __( 'Ogni spostamento parte da un piano chiaro.', 'miraservices' ),
			'audience'    => array( 'Privati', 'Aziende', 'Amministrazioni', 'Attività commerciali' ),
			'related'     => array( 'pulizie', 'manutenzione-immobili' ),
			'style'       => 'standard',
		),
		'picchetto-24h' => array(
			'intro_title' => __( 'Un riferimento quando non si può aspettare.', 'miraservices' ),
			'audience'    => array( 'Proprietari', 'Amministrazioni', 'Condomini', 'Seconde case', 'Aziende' ),
			'related'     => array( 'manutenzione-immobili', 'portineria-custodia' ),
			'style'       => 'emergency',
		),
	);
}

/**
 * Seed missing child meta once, without overwriting editorial changes.
 *
 * @return void
 */
function miraservices_migrate_service_fields() {
	$migration_version = '2.7.0-services-order-8';
	if ( $migration_version === get_option( 'miraservices_service_fields_version', '' ) ) {
		return;
	}

	$mapping  = (array) get_option( 'miraservices_service_page_mapping', array() );
	$services = (array) get_option( 'ticinoweb_services', array() );
	$service_ids = array_filter( array_map( static function ( $service ) {
		return isset( $service['id'] ) ? sanitize_key( $service['id'] ) : '';
	}, $services ) );

	/* Restore the eighth canonical service if an older local CMS save omitted it. */
	if ( ! in_array( 'traslochi-sgomberi', $service_ids, true ) && function_exists( 'get_page_by_path' ) ) {
		$traslochi_page = get_page_by_path( 'traslochi-sgomberi', OBJECT, 'page' );
		if ( $traslochi_page instanceof WP_Post && 'publish' === $traslochi_page->post_status ) {
			$image_id  = get_post_thumbnail_id( $traslochi_page->ID );
			$image_url = $image_id ? wp_get_attachment_url( $image_id ) : '';
			$services[] = array(
				'id'          => 'traslochi-sgomberi',
				'image'       => $image_url,
				'title'       => 'Traslochi & Sgomberi',
				'description' => 'Organizzazione di traslochi e sgomberi per uffici, magazzini, appartamenti, case e cantine.',
				'icon'        => '',
				'icon_type'   => 'svg',
				'icon_svg'    => get_template_directory_uri() . '/assets/icons/Varie/bundle.svg',
			);
			$mapping['traslochi-sgomberi'] = (int) $traslochi_page->ID;
			update_option( 'ticinoweb_services', $services );
			update_option( 'miraservices_service_page_mapping', $mapping );
		}
	}

	$canonical_order = array( 'manutenzione-immobili', 'giardinaggio', 'pulizie', 'portineria-custodia', 'muratura-pittura', 'ristrutturazioni', 'traslochi-sgomberi', 'picchetto-24h' );
	$service_lookup  = array();
	foreach ( $services as $service ) {
		if ( ! empty( $service['id'] ) ) {
			$service_lookup[ sanitize_key( $service['id'] ) ] = $service;
		}
	}
	$ordered_services = array();
	foreach ( $canonical_order as $service_id ) {
		if ( isset( $service_lookup[ $service_id ] ) ) {
			$ordered_services[] = $service_lookup[ $service_id ];
			unset( $service_lookup[ $service_id ] );
		}
	}
	$ordered_services = array_merge( $ordered_services, array_values( $service_lookup ) );
	if ( $ordered_services !== $services ) {
		$services = $ordered_services;
		update_option( 'ticinoweb_services', $services );
	}

	$defaults = miraservices_service_field_defaults();
	if ( empty( $mapping ) ) {
		return;
	}

	foreach ( $mapping as $service_key => $page_id ) {
		$page_id = (int) $page_id;
		if ( $page_id <= 0 || ! isset( $defaults[ $service_key ] ) ) {
			continue;
		}

		$seed = $defaults[ $service_key ];
		if ( '' === (string) get_post_meta( $page_id, '_mira_service_intro_title', true ) ) {
			update_post_meta( $page_id, '_mira_service_intro_title', $seed['intro_title'] );
		}
		if ( array() === (array) get_post_meta( $page_id, '_mira_service_audience', true ) ) {
			update_post_meta( $page_id, '_mira_service_audience', $seed['audience'] );
		}
		if ( array() === (array) get_post_meta( $page_id, '_mira_service_related', true ) ) {
			update_post_meta( $page_id, '_mira_service_related', $seed['related'] );
		}
		if ( '' === (string) get_post_meta( $page_id, '_mira_service_style', true ) ) {
			update_post_meta( $page_id, '_mira_service_style', $seed['style'] );
		}
	}

	update_option( 'miraservices_service_fields_version', $migration_version, false );
}
add_action( 'init', 'miraservices_migrate_service_fields', 30 );

/**
 * Register service metadata for REST/editor compatibility.
 *
 * @return void
 */
function miraservices_register_service_meta() {
	if ( ! function_exists( 'register_post_meta' ) ) {
		return;
	}

	$single_text = array(
		'single'            => true,
		'type'              => 'string',
		'show_in_rest'      => true,
		'sanitize_callback' => 'sanitize_text_field',
		'auth_callback'     => static function () { return current_user_can( 'edit_pages' ); },
	);
	foreach ( array( '_mira_service_intro_title', '_mira_service_visual_note', '_mira_service_why', '_mira_service_style' ) as $key ) {
		register_post_meta( 'page', $key, $single_text );
	}
	register_post_meta( 'page', '_mira_service_secondary_image', array_merge( $single_text, array( 'type' => 'integer', 'sanitize_callback' => 'absint' ) ) );
}
add_action( 'init', 'miraservices_register_service_meta' );

/**
 * Add a compact editor panel only to mapped service pages.
 *
 * @return void
 */
function miraservices_add_service_meta_box() {
	$post_id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( ! $post_id || ! miraservices_is_service_page( $post_id ) ) {
		return;
	}
	add_meta_box( 'mira-service-layout', __( 'Mira — Pagina servizio', 'miraservices' ), 'miraservices_render_service_meta_box', 'page', 'normal', 'high' );
}
add_action( 'add_meta_boxes_page', 'miraservices_add_service_meta_box' );

/**
 * Render the child-owned service controls.
 *
 * @param WP_Post $post Current page.
 * @return void
 */
function miraservices_render_service_meta_box( $post ) {
	$services       = miraservices_get_frontend_services();
	$current_key    = miraservices_get_service_page_key( $post->ID );
	$audience       = (array) get_post_meta( $post->ID, '_mira_service_audience', true );
	$related        = (array) get_post_meta( $post->ID, '_mira_service_related', true );
	$secondary_id   = (int) get_post_meta( $post->ID, '_mira_service_secondary_image', true );
	$secondary_url  = $secondary_id ? wp_get_attachment_image_url( $secondary_id, 'medium' ) : '';
	wp_nonce_field( 'miraservices_save_service_fields', 'miraservices_service_fields_nonce' );
	?>
	<style>.mira-service-fields{display:grid;gap:22px}.mira-service-fields label{font-weight:600}.mira-service-fields small{display:block;color:#646970;margin-top:5px}.mira-service-fields input[type=text],.mira-service-fields textarea,.mira-service-fields select{width:100%;max-width:900px}.mira-service-fields__relations{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:8px 16px}.mira-service-fields__media{display:flex;align-items:center;gap:12px;flex-wrap:wrap}.mira-service-fields__media img{width:120px;height:80px;object-fit:cover;background:#f0f0f1}</style>
	<div class="mira-service-fields">
		<p><label for="mira-service-intro-title"><?php esc_html_e( 'Titolo introduzione', 'miraservices' ); ?></label><br><input id="mira-service-intro-title" type="text" name="mira_service_intro_title" value="<?php echo esc_attr( get_post_meta( $post->ID, '_mira_service_intro_title', true ) ); ?>"><small><?php esc_html_e( 'Il testo introduttivo resta nel contenuto principale della pagina.', 'miraservices' ); ?></small></p>
		<p><label for="mira-service-audience"><?php esc_html_e( 'A chi ci rivolgiamo', 'miraservices' ); ?></label><br><textarea id="mira-service-audience" name="mira_service_audience" rows="5"><?php echo esc_textarea( implode( "\n", $audience ) ); ?></textarea><small><?php esc_html_e( 'Un segmento per riga.', 'miraservices' ); ?></small></p>
		<div><label><?php esc_html_e( 'Immagine secondaria', 'miraservices' ); ?></label><div class="mira-service-fields__media"><input type="hidden" name="mira_service_secondary_image" value="<?php echo esc_attr( $secondary_id ); ?>" data-mira-service-media-id><img src="<?php echo esc_url( $secondary_url ); ?>" alt="" data-mira-service-media-preview<?php echo $secondary_url ? '' : ' hidden'; ?>><button type="button" class="button" data-mira-service-media-select><?php esc_html_e( 'Scegli immagine', 'miraservices' ); ?></button><button type="button" class="button-link-delete" data-mira-service-media-remove<?php echo $secondary_url ? '' : ' hidden'; ?>><?php esc_html_e( 'Rimuovi', 'miraservices' ); ?></button></div><small><?php esc_html_e( 'Opzionale: se vuota, il momento fotografico non viene mostrato.', 'miraservices' ); ?></small></div>
		<p><label for="mira-service-visual-note"><?php esc_html_e( 'Nota sulla fotografia', 'miraservices' ); ?></label><br><input id="mira-service-visual-note" type="text" name="mira_service_visual_note" value="<?php echo esc_attr( get_post_meta( $post->ID, '_mira_service_visual_note', true ) ); ?>"></p>
		<p><label for="mira-service-why"><?php esc_html_e( 'Perché Mira — testo alternativo', 'miraservices' ); ?></label><br><textarea id="mira-service-why" name="mira_service_why" rows="4"><?php echo esc_textarea( get_post_meta( $post->ID, '_mira_service_why', true ) ); ?></textarea><small><?php esc_html_e( 'Se vuoto viene usato il secondo paragrafo introduttivo, senza duplicarlo sopra.', 'miraservices' ); ?></small></p>
		<div><strong><?php esc_html_e( 'Servizi correlati', 'miraservices' ); ?></strong><div class="mira-service-fields__relations"><?php foreach ( $services as $service ) : if ( $service['id'] === $current_key ) { continue; } ?><label><input type="checkbox" name="mira_service_related[]" value="<?php echo esc_attr( $service['id'] ); ?>" <?php checked( in_array( $service['id'], $related, true ) ); ?>> <?php echo esc_html( $service['title'] ); ?></label><?php endforeach; ?></div></div>
		<p><label for="mira-service-style"><?php esc_html_e( 'Stile pagina servizio', 'miraservices' ); ?></label><br><select id="mira-service-style" name="mira_service_style"><?php foreach ( array( 'standard' => 'Standard', 'outdoor' => 'Outdoor', 'technical' => 'Tecnico', 'emergency' => 'Emergenza' ) as $value => $label ) : ?><option value="<?php echo esc_attr( $value ); ?>" <?php selected( get_post_meta( $post->ID, '_mira_service_style', true ), $value ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></p>
	</div>
	<?php
}

/** Save the service controls safely. */
function miraservices_save_service_fields( $post_id ) {
	if ( ! isset( $_POST['miraservices_service_fields_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['miraservices_service_fields_nonce'] ) ), 'miraservices_save_service_fields' ) || ! current_user_can( 'edit_post', $post_id ) || wp_is_post_revision( $post_id ) || ! miraservices_is_service_page( $post_id ) ) {
		return;
	}

	update_post_meta( $post_id, '_mira_service_intro_title', sanitize_text_field( wp_unslash( $_POST['mira_service_intro_title'] ?? '' ) ) );
	update_post_meta( $post_id, '_mira_service_visual_note', sanitize_text_field( wp_unslash( $_POST['mira_service_visual_note'] ?? '' ) ) );
	update_post_meta( $post_id, '_mira_service_why', sanitize_textarea_field( wp_unslash( $_POST['mira_service_why'] ?? '' ) ) );
	update_post_meta( $post_id, '_mira_service_secondary_image', absint( $_POST['mira_service_secondary_image'] ?? 0 ) );

	$audience = array_filter( array_map( 'sanitize_text_field', preg_split( '/\R/u', wp_unslash( $_POST['mira_service_audience'] ?? '' ) ) ) );
	update_post_meta( $post_id, '_mira_service_audience', array_values( array_slice( $audience, 0, 12 ) ) );

	$valid_services = array_column( miraservices_get_frontend_services(), 'id' );
	$related        = array_map( 'sanitize_key', (array) ( $_POST['mira_service_related'] ?? array() ) );
	update_post_meta( $post_id, '_mira_service_related', array_values( array_slice( array_intersect( $related, $valid_services ), 0, 3 ) ) );

	$style = sanitize_key( wp_unslash( $_POST['mira_service_style'] ?? 'standard' ) );
	update_post_meta( $post_id, '_mira_service_style', in_array( $style, array( 'standard', 'outdoor', 'technical', 'emergency' ), true ) ? $style : 'standard' );
}
add_action( 'save_post_page', 'miraservices_save_service_fields' );

/** Load the media picker only on mapped service pages. */
function miraservices_service_admin_assets( $hook ) {
	if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
		return;
	}
	$post_id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( ! $post_id || ! miraservices_is_service_page( $post_id ) ) {
		return;
	}
	wp_enqueue_media();
	wp_enqueue_script( 'miraservices-service-fields', get_stylesheet_directory_uri() . '/assets/js/admin-service-fields.js', array(), wp_get_theme()->get( 'Version' ), true );
}
add_action( 'admin_enqueue_scripts', 'miraservices_service_admin_assets' );
