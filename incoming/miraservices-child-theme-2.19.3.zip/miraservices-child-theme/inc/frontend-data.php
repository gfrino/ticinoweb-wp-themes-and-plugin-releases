<?php
/**
 * Frontend data adapters for Mira Services.
 *
 * @package MiraServicesChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( '__' ) ) {
	function __( $text, $domain = 'default' ) {
		return $text;
	}
}

/**
 * Build a two-level menu tree from the assigned WordPress primary menu.
 *
 * @return array<int,array<string,mixed>>
 */
function miraservices_get_primary_menu_tree() {
	$locations = get_nav_menu_locations();
	$menu_id   = isset( $locations['primary'] ) ? (int) $locations['primary'] : 0;
	if ( ! $menu_id ) {
		return array();
	}

	$menu = wp_get_nav_menu_object( $menu_id );
	if ( ! $menu ) {
		return array();
	}

	$items = wp_get_nav_menu_items( $menu->term_id );
	if ( ! is_array( $items ) ) {
		return array();
	}

	$nodes = array();
	foreach ( $items as $item ) {
		$title = (string) $item->title;
		$url   = (string) $item->url;

		if ( 'mira' === strtolower( trim( $title ) ) || false !== strpos( $url, '#mira' ) || false !== strpos( $url, '#chi-siamo' ) ) {
			$title = function_exists( '__' ) ? __( 'Chi siamo', 'miraservices' ) : 'Chi siamo';
			$url   = function_exists( 'home_url' ) ? home_url( '/#chi-siamo' ) : '#chi-siamo';
		}

		$nodes[ (int) $item->ID ] = array(
			'id'       => (int) $item->ID,
			'parent'   => (int) $item->menu_item_parent,
			'title'    => $title,
			'url'      => $url,
			'target'   => (string) $item->target,
			'classes'  => array_filter( (array) $item->classes ),
			'children' => array(),
		);
	}

	$tree = array();
	foreach ( $nodes as $id => $node ) {
		if ( $node['parent'] && isset( $nodes[ $node['parent'] ] ) ) {
			$nodes[ $node['parent'] ]['children'][] = $node;
		} else {
			$tree[] = &$nodes[ $id ];
		}
	}

	return array_values( $tree );
}

/**
 * Resolve a WordPress attachment id from an uploaded media URL.
 *
 * @param string $url Media URL.
 * @return int
 */
function miraservices_attachment_id_from_url( $url ) {
	if ( ! is_string( $url ) || '' === $url || ! function_exists( 'attachment_url_to_postid' ) ) {
		return 0;
	}

	return (int) attachment_url_to_postid( $url );
}

/**
 * Render responsive WordPress image markup with a remote-safe fallback.
 *
 * @param string $url  Media URL.
 * @param array  $args Image attributes.
 * @return string
 */
function miraservices_image( $url, $args = array() ) {
	$defaults = array(
		'size'          => 'full',
		'class'         => '',
		'alt'           => null,
		'loading'       => 'lazy',
		'fetchpriority' => 'auto',
		'sizes'         => '100vw',
		'attachment_only' => false,
	);
	$args = array_merge( $defaults, is_array( $args ) ? $args : array() );
	$id   = miraservices_attachment_id_from_url( $url );

	$attributes = array(
		'class'         => $args['class'],
		'loading'       => $args['loading'],
		'fetchpriority' => $args['fetchpriority'],
		'sizes'         => $args['sizes'],
		'decoding'      => 'async',
	);
	if ( null !== $args['alt'] ) {
		$attributes['alt'] = $args['alt'];
	}

	if ( $id && function_exists( 'wp_get_attachment_image' ) ) {
		return wp_get_attachment_image( $id, $args['size'], false, $attributes );
	}
	if ( $args['attachment_only'] ) {
		return '';
	}

	if ( ! $url ) {
		return '';
	}

	return sprintf(
		'<img src="%1$s" class="%2$s" alt="%3$s" loading="%4$s" fetchpriority="%5$s" sizes="%6$s" decoding="async">',
		esc_url( $url ),
		esc_attr( $args['class'] ),
		esc_attr( null === $args['alt'] ? '' : $args['alt'] ),
		esc_attr( $args['loading'] ),
		esc_attr( $args['fetchpriority'] ),
		esc_attr( $args['sizes'] )
	);
}

/**
 * Read the CMS services and append their mapped page URL and media id.
 *
 * @return array<int,array<string,mixed>>
 */
function miraservices_get_frontend_services() {
	$services = function_exists( 'ticinoweb_get_services' ) ? ticinoweb_get_services() : get_option( 'ticinoweb_services', array() );
	$mapping  = get_option( 'miraservices_service_page_mapping', array() );
	$output   = array();

	foreach ( (array) $services as $index => $service ) {
		$id      = isset( $service['id'] ) ? sanitize_key( $service['id'] ) : 'service-' . ( $index + 1 );
		$page_id = isset( $mapping[ $id ] ) ? (int) $mapping[ $id ] : 0;
		$url     = '';
		if ( $page_id && 'publish' === get_post_status( $page_id ) ) {
			$url = get_permalink( $page_id );
		}
		if ( ! $url ) {
			$url = function_exists( 'home_url' ) ? home_url( '/#contatti' ) : '#contatti';
		}

		$raw_desc = isset( $service['description'] ) ? trim( (string) $service['description'] ) : '';
		$rich_defaults = array(
			'manutenzione-immobili' => __( 'Controllo generale dello stabile, piccoli interventi e sistemazioni preventive: una presenza continuativa per mantenere ogni spazio efficiente, curato e perfettamente funzionante nel tempo.', 'miraservices' ),
			'giardinaggio'          => __( 'Seguiamo giardini e aree verdi durante tutto l\'anno: manutenzione del prato, potature, trattamenti e interventi stagionali organizzati in funzione degli spazi e delle reali necessità dell\'immobile.', 'miraservices' ),
			'pulizie'               => __( 'Pulizie accurate e metodiche per abitazioni private, condomini, uffici e cantieri: programmiamo frequenze e interventi su misura garantendo standard igienici rigorosi e continuità.', 'miraservices' ),
			'portineria-custodia'   => __( 'Un riferimento operativo per la gestione quotidiana dello stabile, degli spazi comuni e dei piccoli interventi che richiedono continuità, coordinamento e controllo affidabile.', 'miraservices' ),
			'muratura-pittura'      => __( 'Piccoli interventi di muratura, ripristini murari, tinteggiature interne ed esterne e lavori di finitura per rinnovare e proteggere le superfici usurate dell\'immobile.', 'miraservices' ),
			'ristrutturazioni'      => __( 'Rinnovi completi di appartamenti, cucine, bagni e locali: coordiniamo maestranze e artigiani locali garantendo rispetto dei tempi, pulizia del cantiere e qualità svizzera.', 'miraservices' ),
			'traslochi-sgomberi'    => __( 'Movimentazione ordinata di arredi, sgombero locali e smaltimento certificato di materiali: pianifichiamo ogni fase con la massima cura e rispetto per gli spazi.', 'miraservices' ),
			'picchetto-24h'         => __( 'Reperibilità immediata 24 ore su 24 per emergenze idrauliche, guasti imprevisti o problemi di accesso: una squadra pronta a intervenire giorno e notte ad Ascona e nel Locarnese.', 'miraservices' ),
		);
		$description = ( mb_strlen( $raw_desc ) > 50 ) ? $raw_desc : ( isset( $rich_defaults[ $id ] ) ? $rich_defaults[ $id ] : $raw_desc );

		$image           = isset( $service['image'] ) ? (string) $service['image'] : '';
		$secondary_id    = 0;
		$secondary_image = '';

		if ( $page_id && 'publish' === get_post_status( $page_id ) ) {
			$secondary_id = (int) get_post_meta( $page_id, '_mira_service_secondary_image', true );
			if ( $secondary_id && wp_attachment_is_image( $secondary_id ) ) {
				$secondary_image = (string) wp_get_attachment_url( $secondary_id );
			}
		}
		if ( ! $secondary_image ) {
			$secondary_id    = miraservices_attachment_id_from_url( $image );
			$secondary_image = $image;
		}

		$output[] = array(
			'id'            => $id,
			'index'         => $index + 1,
			'title'         => isset( $service['title'] ) ? (string) $service['title'] : '',
			'description'   => $description,
			'image'         => $image,
			'icon_svg'      => isset( $service['icon_svg'] ) ? (string) $service['icon_svg'] : '',
			'page_id'       => $page_id,
			'url'           => $url,
			'attachment_id' => miraservices_attachment_id_from_url( $image ),
			'secondary_id'  => $secondary_id,
			'secondary_image' => $secondary_image,
			'is_emergency'  => 'picchetto-24h' === $id,
		);
	}

	return $output;
}

/**
 * Get only complete, verified partner entries from CMS options.
 *
 * @return array<int,array{logo:string,url:string}>
 */
function miraservices_get_partners() {
	$count    = max( 0, min( 24, (int) get_option( 'ticinoweb_partner_count', 0 ) ) );
	$partners = array();
	for ( $index = 1; $index <= $count; $index++ ) {
		$logo = trim( (string) get_option( "ticinoweb_partner_logo_{$index}", '' ) );
		if ( '' === $logo ) {
			continue;
		}
		$partners[] = array(
			'logo' => $logo,
			'url'  => trim( (string) get_option( "ticinoweb_partner_link_{$index}", '' ) ),
			'name' => ( function () use ( $logo ) {
				$attachment_id = miraservices_attachment_id_from_url( $logo );
				if ( $attachment_id ) {
					$alt = trim( (string) get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ) );
					return $alt ? $alt : get_the_title( $attachment_id );
				}
				return __( 'Partner Mira Services', 'miraservices' );
			} )(),
		);
	}
	return $partners;
}

/**
 * Get verified reviews only when the CMS feature is enabled.
 *
 * @return array
 */
function miraservices_get_reviews() {
	if ( get_option( 'ticinoweb_disable_reviews', 0 ) || ! function_exists( 'ticinoweb_get_google_reviews' ) ) {
		return array();
	}
	return (array) ticinoweb_get_google_reviews( 3, 4 );
}

/**
 * Resolve the service key associated with a published WordPress page.
 *
 * The mapping is maintained by the idempotent content importer and remains the
 * authoritative relationship between CMS services and their detail pages.
 *
 * @param int $post_id Optional page id. Defaults to the queried object.
 * @return string
 */
function miraservices_get_service_page_key( $post_id = 0 ) {
	if ( ! $post_id && function_exists( 'get_queried_object_id' ) ) {
		$post_id = (int) get_queried_object_id();
	}

	if ( $post_id <= 0 ) {
		return '';
	}

	$mapping = get_option( 'miraservices_service_page_mapping', array() );
	foreach ( (array) $mapping as $service_key => $page_id ) {
		if ( (int) $page_id === (int) $post_id ) {
			return sanitize_key( $service_key );
		}
	}

	return '';
}

/**
 * Determine whether a page belongs to the Mira service-page collection.
 *
 * @param int $post_id Optional page id.
 * @return bool
 */
function miraservices_is_service_page( $post_id = 0 ) {
	return '' !== miraservices_get_service_page_key( $post_id );
}

/**
 * Parse the existing editorial page content into the shared service layout.
 *
 * No copy is duplicated in the template: headings, paragraphs, activity lists
 * and calls to action continue to come from the WordPress page editor.
 *
 * @param string $content Raw WordPress post content.
 * @return array<string,mixed>
 */
function miraservices_parse_service_content( $content ) {
	$empty = array(
		'eyebrow'  => '',
		'intro'     => array(),
		'scope'     => array( 'title' => '', 'items' => array() ),
		'audience'  => array( 'title' => '', 'text' => '' ),
		'operation' => array( 'title' => '', 'text' => '', 'action' => array() ),
		'cta'       => array(),
	);

	if ( ! is_string( $content ) || '' === trim( $content ) || ! class_exists( 'DOMDocument' ) ) {
		return $empty;
	}

	$previous_errors = libxml_use_internal_errors( true );
	$document        = new DOMDocument( '1.0', 'UTF-8' );
	$loaded          = $document->loadHTML( '<?xml encoding="utf-8" ?><div id="mira-service-parser">' . $content . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
	libxml_clear_errors();
	libxml_use_internal_errors( $previous_errors );

	if ( ! $loaded ) {
		return $empty;
	}

	$xpath   = new DOMXPath( $document );
	$wrapper = $xpath->query( '//*[@id="mira-service-parser"]' )->item( 0 );
	if ( ! $wrapper instanceof DOMElement ) {
		return $empty;
	}

	$sections      = array();
	$current_index = -1;
	$all_links     = array();

	foreach ( $wrapper->childNodes as $node ) {
		if ( XML_ELEMENT_NODE !== $node->nodeType ) {
			continue;
		}

		$tag  = strtolower( $node->nodeName );
		$text = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $document->saveHTML( $node ) ) ) );

		if ( 'h1' === $tag ) {
			continue;
		}

		if ( 'h2' === $tag ) {
			++$current_index;
			$sections[ $current_index ] = array(
				'title'      => $text,
				'items'      => array(),
				'paragraphs' => array(),
			);
			continue;
		}

		if ( 'ul' === $tag && $current_index >= 0 ) {
			foreach ( $xpath->query( './li', $node ) as $item ) {
				$item_text = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $document->saveHTML( $item ) ) ) );
				if ( '' !== $item_text ) {
					$sections[ $current_index ]['items'][] = $item_text;
				}
			}
			continue;
		}

		if ( 'p' !== $tag ) {
			continue;
		}

		$strong = $xpath->query( './strong', $node );
		if ( $current_index < 0 && $strong && $strong->length > 0 ) {
			$empty['eyebrow'] = $text;
			continue;
		}

		$paragraph_links = array();
		foreach ( $xpath->query( './/a[@href]', $node ) as $link ) {
			$link_data = array(
				'label' => trim( preg_replace( '/\s+/u', ' ', $link->textContent ) ),
				'url'   => trim( $link->getAttribute( 'href' ) ),
			);
			if ( '' !== $link_data['label'] && '' !== $link_data['url'] ) {
				$paragraph_links[] = $link_data;
				$all_links[]       = $link_data;
			}
		}

		if ( $current_index < 0 ) {
			if ( '' !== $text ) {
				$empty['intro'][] = $text;
			}
			continue;
		}

		$sections[ $current_index ]['paragraphs'][] = array(
			'text'  => $text,
			'links' => $paragraph_links,
		);
	}

	if ( isset( $sections[0] ) ) {
		$empty['scope']['title'] = $sections[0]['title'];
		$empty['scope']['items'] = $sections[0]['items'];
	}
	if ( isset( $sections[1] ) ) {
		$empty['audience']['title'] = $sections[1]['title'];
		$empty['audience']['text']  = $sections[1]['paragraphs'][0]['text'] ?? '';
	}
	if ( isset( $sections[2] ) ) {
		$empty['operation']['title'] = $sections[2]['title'];
		$empty['operation']['text']  = $sections[2]['paragraphs'][0]['text'] ?? '';
		foreach ( $sections[2]['paragraphs'] as $paragraph ) {
			foreach ( $paragraph['links'] as $link ) {
				if ( 0 === strpos( $link['url'], 'tel:' ) || 0 === strpos( $link['url'], 'mailto:' ) ) {
					$empty['operation']['action'] = $link;
					break 2;
				}
			}
		}
	}

	if ( ! empty( $all_links ) ) {
		$empty['cta'] = end( $all_links );
	}

	return $empty;
}

/**
 * Build all dynamic data required by the shared service-page template.
 *
 * @param int $post_id WordPress page id.
 * @return array<string,mixed>
 */
function miraservices_get_service_page_data( $post_id ) {
	$service_key = miraservices_get_service_page_key( $post_id );
	if ( '' === $service_key ) {
		return array();
	}

	$services        = miraservices_get_frontend_services();
	$current_service = array();
	$service_lookup  = array();
	foreach ( $services as $service ) {
		$service_lookup[ $service['id'] ] = $service;
		if ( $service_key === $service['id'] ) {
			$current_service = $service;
		}
	}

	if ( empty( $current_service ) ) {
		return array();
	}

	$content = get_post_field( 'post_content', $post_id );
	$parsed  = miraservices_parse_service_content( $content );
	if ( empty( $parsed['scope']['title'] ) || empty( $parsed['scope']['items'] ) ) {
		return array();
	}

	$field_defaults = function_exists( 'miraservices_service_field_defaults' ) ? miraservices_service_field_defaults() : array();
	$field_default  = $field_defaults[ $service_key ] ?? array();
	$related        = array();
	$related_ids    = array_filter( array_map( 'sanitize_key', (array) get_post_meta( $post_id, '_mira_service_related', true ) ) );
	if ( empty( $related_ids ) && ! empty( $field_default['related'] ) ) {
		$related_ids = $field_default['related'];
	}
	if ( empty( $related_ids ) ) {
		$service_keys = array_values( array_diff( array_keys( $service_lookup ), array( $service_key ) ) );
		$current_pos  = array_search( $service_key, array_keys( $service_lookup ), true );
		$start        = false === $current_pos ? 0 : (int) $current_pos;
		$rotated      = array_merge( array_slice( $service_keys, $start ), array_slice( $service_keys, 0, $start ) );
		$related_ids  = array_slice( $rotated, 0, 2 );
	}
	foreach ( $related_ids as $related_id ) {
		if ( $related_id !== $service_key && isset( $service_lookup[ $related_id ] ) && ! empty( $service_lookup[ $related_id ]['url'] ) ) {
			$related[] = $service_lookup[ $related_id ];
		}
	}

	$home_contact  = miraservices_get_home_sections();
	$contact_block = $home_contact['contact'] ?? array();
	$method        = $home_contact['method'] ?? array();
	$excerpt       = trim( (string) get_post_field( 'post_excerpt', $post_id ) );
	$final_cta     = $parsed['cta'];
	$hero_cta      = $final_cta;
	$intro         = array_values( array_filter( (array) $parsed['intro'] ) );
	$why_text      = trim( (string) get_post_meta( $post_id, '_mira_service_why', true ) );
	if ( '' === $why_text && count( $intro ) > 1 ) {
		$why_text = (string) array_pop( $intro );
	}
	$secondary_id = (int) get_post_meta( $post_id, '_mira_service_secondary_image', true );
	$audience_items = array_values( array_filter( (array) get_post_meta( $post_id, '_mira_service_audience', true ) ) );
	if ( empty( $audience_items ) && ! empty( $field_default['audience'] ) ) {
		$audience_items = $field_default['audience'];
	}
	$style        = sanitize_key( (string) get_post_meta( $post_id, '_mira_service_style', true ) );
	if ( '' === $style && ! empty( $field_default['style'] ) ) {
		$style = $field_default['style'];
	}
	if ( ! in_array( $style, array( 'standard', 'outdoor', 'technical', 'emergency' ), true ) ) {
		$style = $current_service['is_emergency'] ? 'emergency' : 'standard';
	}

	if ( $current_service['is_emergency'] && ! empty( $parsed['operation']['action'] ) ) {
		$hero_cta = $parsed['operation']['action'];
	}

	return array(
		'id'            => (int) $post_id,
		'key'           => $service_key,
		'title'         => get_the_title( $post_id ),
		'lead'          => $excerpt ?: $current_service['description'],
		'index'         => (int) $current_service['index'],
		'count'         => count( $services ),
		'is_emergency'  => (bool) $current_service['is_emergency'],
		'eyebrow'       => $parsed['eyebrow'],
		'intro_title'   => trim( (string) get_post_meta( $post_id, '_mira_service_intro_title', true ) ) ?: ( $field_default['intro_title'] ?? get_the_title( $post_id ) ),
		'intro'         => $intro,
		'scope'         => $parsed['scope'],
		'audience'      => $parsed['audience'],
		'audience_items'=> $audience_items,
		'operation'     => $parsed['operation'],
		'method_steps'  => array_slice( (array) ( $method['steps'] ?? array() ), 0, 4 ),
		'why_title'     => $home_contact['advantage']['title'] ?? '',
		'why_text'      => $why_text,
		'secondary_id'  => $secondary_id,
		'visual_note'   => trim( (string) get_post_meta( $post_id, '_mira_service_visual_note', true ) ),
		'style'         => $style,
		'hero_cta'      => $hero_cta,
		'final_cta'     => $final_cta,
		'final_title'   => $contact_block['title'] ?? '',
		'final_text'    => $contact_block['text'] ?? '',
		'phone'         => trim( (string) get_option( 'ticinoweb_contact_phone_display', '' ) ),
		'phone_href'    => trim( (string) get_option( 'ticinoweb_contact_phone_mobile', get_option( 'ticinoweb_contact_phone', '' ) ) ),
		'related'       => $related,
	);
}

/**
 * Extract plain text from the first tag in a DOM element.
 *
 * @param DOMXPath   $xpath XPath reader.
 * @param DOMElement $section Section element.
 * @param string     $tag Tag name.
 * @param int        $position One-based tag position.
 * @return string
 */
function miraservices_dom_text( $xpath, $section, $tag, $position = 1 ) {
	$nodes = $xpath->query( './/' . $tag, $section );
	if ( ! $nodes || $nodes->length < $position ) {
		return '';
	}
	$node = $nodes->item( $position - 1 );
	$html = $node->ownerDocument->saveHTML( $node );
	$html = preg_replace( '/<br\s*\/?>/i', ' ', $html );
	return trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $html ) ) );
}

/**
 * Parse the editorial source content stored on the WordPress Home page.
 *
 * @param string|null $content Optional content fixture/source.
 * @return array<string,mixed>
 */
function miraservices_get_home_sections( $content = null ) {
	static $runtime_cache = null;
	$use_runtime_cache = null === $content;
	if ( $use_runtime_cache && null !== $runtime_cache ) {
		return $runtime_cache;
	}

	if ( null === $content ) {
		$page_id = (int) get_option( 'page_on_front', 0 );
		if ( ! $page_id && function_exists( 'get_queried_object_id' ) ) {
			$page_id = get_queried_object_id();
		}
		$content = $page_id && function_exists( 'get_post_field' ) ? get_post_field( 'post_content', $page_id ) : '';
	}

	$empty = array(
		'intro'     => array( 'eyebrow' => '', 'title' => '', 'text' => '' ),
		'services'  => array( 'eyebrow' => '', 'title' => '', 'text' => '' ),
		'advantage' => array( 'title' => '', 'text' => '' ),
		'method'    => array( 'title' => '', 'steps' => array() ),
		'emergency' => array( 'eyebrow' => '', 'title' => '', 'text' => '' ),
		'contact'   => array( 'title' => '', 'text' => '' ),
	);
	if ( ! is_string( $content ) || '' === trim( $content ) || ! class_exists( 'DOMDocument' ) ) {
		if ( $use_runtime_cache ) {
			$runtime_cache = $empty;
		}
		return $empty;
	}

	$previous_errors = libxml_use_internal_errors( true );
	$document        = new DOMDocument( '1.0', 'UTF-8' );
	$document->loadHTML( '<?xml encoding="utf-8" ?><main id="mira-parser">' . $content . '</main>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
	libxml_clear_errors();
	libxml_use_internal_errors( $previous_errors );
	$xpath    = new DOMXPath( $document );
	$sections = $xpath->query( '//*[@id="mira-parser"]/section' );
	$result   = $empty;

	foreach ( $sections as $section ) {
		$id       = $section->getAttribute( 'id' );
		$eyebrow  = miraservices_dom_text( $xpath, $section, 'strong' );
		$heading  = miraservices_dom_text( $xpath, $section, 'h2' );
		$paragraph = miraservices_dom_text( $xpath, $section, 'p', $eyebrow ? 2 : 1 );

		if ( 'servizi' === $id ) {
			$result['services'] = array( 'eyebrow' => $eyebrow, 'title' => $heading, 'text' => $paragraph );
			continue;
		}
		if ( 'perche-mira' === $id ) {
			$result['advantage'] = array( 'title' => $heading, 'text' => miraservices_dom_text( $xpath, $section, 'p', 1 ) );
			$result['method']['title'] = miraservices_dom_text( $xpath, $section, 'h2', 2 );
			$step_nodes = $xpath->query( './/h3', $section );
			foreach ( $step_nodes as $step_node ) {
				$description = '';
				$sibling     = $step_node->nextSibling;
				while ( $sibling ) {
					if ( XML_ELEMENT_NODE === $sibling->nodeType && 'p' === strtolower( $sibling->nodeName ) ) {
						$description = trim( preg_replace( '/\s+/u', ' ', $sibling->textContent ) );
						break;
					}
					$sibling = $sibling->nextSibling;
				}
				$result['method']['steps'][] = array(
					'title' => trim( preg_replace( '/\s+/u', ' ', $step_node->textContent ) ),
					'text'  => $description,
				);
			}
			continue;
		}
		if ( 'contatti' === $id ) {
			$result['contact'] = array( 'title' => $heading, 'text' => miraservices_dom_text( $xpath, $section, 'p', 1 ) );
			continue;
		}
		if ( false !== stripos( $eyebrow, 'PICCHETTO' ) ) {
			$result['emergency'] = array( 'eyebrow' => $eyebrow, 'title' => $heading, 'text' => $paragraph );
			continue;
		}
		if ( '' === $result['intro']['title'] ) {
			$result['intro'] = array( 'eyebrow' => $eyebrow, 'title' => $heading, 'text' => $paragraph );
		}
	}

	if ( $use_runtime_cache ) {
		$runtime_cache = $result;
	}
	return $result;
}

/**
 * Return the configured privacy URL, preferring WordPress core and falling
 * back to the value managed by the parent CMS.
 *
 * @return string
 */
function miraservices_get_privacy_url() {
	$core_url = function_exists( 'get_privacy_policy_url' ) ? get_privacy_policy_url() : '';
	return $core_url ? $core_url : (string) get_option( 'tw_privacy_policy_url', '' );
}

/**
 * Return only published legal pages that really exist in WordPress.
 *
 * @return array<int,array{label:string,url:string}>
 */
function miraservices_get_legal_links() {
	$links       = array();
	$privacy_url = miraservices_get_privacy_url();

	if ( $privacy_url ) {
		$privacy_id    = function_exists( 'url_to_postid' ) ? url_to_postid( $privacy_url ) : 0;
		$privacy_label = $privacy_id ? get_the_title( $privacy_id ) : '';
		$links[]       = array(
			'label' => $privacy_label ? $privacy_label : __( 'Privacy', 'miraservices' ),
			'url'   => $privacy_url,
		);
	}

	foreach ( array( 'cookie-policy', 'politica-cookie', 'cookie' ) as $cookie_slug ) {
		$cookie_page = get_page_by_path( $cookie_slug, OBJECT, 'page' );
		if ( ! $cookie_page || 'publish' !== get_post_status( $cookie_page ) ) {
			continue;
		}
		$cookie_url = get_permalink( $cookie_page );
		if ( ! $cookie_url || untrailingslashit( $cookie_url ) === untrailingslashit( $privacy_url ) ) {
			break;
		}
		$links[] = array(
			'label' => get_the_title( $cookie_page ),
			'url'   => $cookie_url,
		);
		break;
	}

	return $links;
}

/**
 * Normalize a phone number for tel: or wa.me links.
 *
 * @param string $phone Phone number.
 * @return string
 */
function miraservices_phone_uri( $phone ) {
	$normalized = preg_replace( '/[^0-9+]/', '', (string) $phone );
	return preg_replace( '/(?!^)\+/', '', $normalized );
}

/**
 * Format a phone number cleanly for human display.
 *
 * @param string $phone Phone number.
 * @return string
 */
function miraservices_format_phone( $phone ) {
	$raw = trim( (string) $phone );
	if ( preg_match( '/^\+41\s*(\d{2})\s*(\d{3})\s*(\d{2})\s*(\d{2})$/', $raw, $m ) ) {
		return sprintf( '+41 %s %s %s %s', $m[1], $m[2], $m[3], $m[4] );
	}
	return $raw;
}
