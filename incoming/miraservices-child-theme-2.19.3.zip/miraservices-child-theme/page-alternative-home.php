<?php
/**
 * Template Name: Alternative Home
 * THESIS: A full-width typographic landscape opens into a photographic journey.
 * OWN-WORLD: Blue display type, pale citron, rectangular photographic fields.
 * STORY: A single partner connects different spaces, services and daily needs.
 * FIRST VIEWPORT: Large name, clear offer and contact action, first landscape below.
 * FORM: Typographic masthead, offset photography, full-screen service chapters.
 * @package MiraServicesChildTheme
 */
defined( 'ABSPATH' ) || exit;
get_header();
$sections = miraservices_get_home_sections();
$services = miraservices_get_frontend_services();
$slides = function_exists( 'ticinoweb_get_slider_data' ) ? ticinoweb_get_slider_data() : array();
$contact = function_exists( 'ticinoweb_get_contact_info' ) ? ticinoweb_get_contact_info() : array();
$hero = $slides[0] ?? array();
$title = preg_split( '/(?<=\.)\s+/u', $hero['title'] ?? get_the_title(), 2 );
$featured = array();
foreach ( array( 'giardinaggio', 'manutenzione-immobili', 'pulizie' ) as $service_id ) {
 foreach ( $services as $service ) { if ( $service['id'] === $service_id ) { $featured[] = $service; } }
}
$brand_word = explode( ' ', trim( get_bloginfo( 'name' ) ) )[0];
$showroom = miraservices_get_showroom();
?>
<div class="alt-preload" aria-hidden="true">
 <div class="alt-preload__word"><?php foreach ( preg_split( '//u', mb_strtoupper( $brand_word ), -1, PREG_SPLIT_NO_EMPTY ) as $letter ) : ?><span><?php echo esc_html( $letter ); ?></span><?php endforeach; ?></div>
 <span class="alt-preload__name"><?php echo esc_html( get_bloginfo( 'description' ) ); ?></span>
</div>
<main id="mira-main" class="alt-home">
 <section class="alt-hero" id="home">
  <div class="alt-portal" data-alt-portal>
  <svg class="alt-portal__veil" aria-hidden="true" focusable="false" width="100%" height="100%">
   <defs><mask id="alt-name-aperture" maskUnits="userSpaceOnUse" x="0" y="0" width="100%" height="100%"><rect width="100%" height="100%" fill="white"/><text class="alt-portal__type alt-portal__aperture" x="50%" y="85%" text-anchor="middle" textLength="94%" lengthAdjust="spacingAndGlyphs" fill="black"><?php echo esc_html( mb_strtoupper( $brand_word ) ); ?></text></mask></defs>
   <rect class="alt-portal__surface" width="100%" height="100%" mask="url(#alt-name-aperture)"/>
   <text class="alt-portal__type alt-portal__ink" x="50%" y="85%" text-anchor="middle" textLength="94%" lengthAdjust="spacingAndGlyphs"><?php echo esc_html( mb_strtoupper( $brand_word ) ); ?></text>
   <text class="alt-portal__type alt-portal__outline" x="50%" y="85%" text-anchor="middle" textLength="94%" lengthAdjust="spacingAndGlyphs"><?php echo esc_html( mb_strtoupper( $brand_word ) ); ?></text>
  </svg>
  <div class="alt-hero__stage">
   <h1><span><?php echo esc_html( $title[0] ?? '' ); ?></span><?php if ( ! empty( $title[1] ) ) : ?><em><?php echo esc_html( $title[1] ); ?></em><?php endif; ?></h1>
   <div class="alt-hero__aside"><p><?php echo esc_html( $hero['desc'] ?? '' ); ?></p><a class="alt-link" href="#contatti"><?php esc_html_e( 'Richiedi un preventivo', 'miraservices' ); ?><span>↗</span></a></div>
  </div>
  <figure class="alt-portal__landscape"><?php echo miraservices_image( $hero['image'] ?? '', array( 'loading' => 'eager', 'fetchpriority' => 'high', 'sizes' => '100vw', 'attachment_only' => true ) ); ?></figure>
  <div class="alt-portal__shade" aria-hidden="true"></div>
  <div class="alt-portal__footer"><a class="alt-portal__explore" href="#chi-siamo"><?php esc_html_e( 'Entra nel mondo Mira', 'miraservices' ); ?><span aria-hidden="true">↓</span></a><?php if ( $showroom['ids'] ) : ?><a class="alt-portal__work" href="#realizzazioni"><span><?php echo esc_html( $showroom['title'] ); ?></span><span aria-hidden="true">↗</span></a><?php endif; ?></div>
  </div>
 </section>
 <section class="alt-story" id="chi-siamo" data-alt-story>
  <div class="alt-story__stage">
   <div class="alt-story__copy"><h2 data-alt-reading><?php echo esc_html( $sections['intro']['title'] ); ?></h2><p><?php echo esc_html( $sections['intro']['text'] ); ?></p><a class="alt-link" href="#servizi"><?php esc_html_e( 'Esplora i nostri servizi', 'miraservices' ); ?><span>↘</span></a></div>
   <div class="alt-story__visual">
    <figure class="alt-story__photo alt-story__photo--main"><?php echo miraservices_image( get_option( 'ticinoweb_chi_siamo_image', '' ), array( 'sizes' => '(min-width: 900px) 40vw, 90vw', 'attachment_only' => true ) ); ?></figure>
    <?php foreach ( array_slice( $featured, 0, 2 ) as $index => $service ) : ?><figure class="alt-story__photo alt-story__photo--detail-<?php echo esc_attr( $index ); ?>"><?php echo miraservices_image( $service['secondary_image'], array( 'alt' => $service['title'], 'sizes' => '25vw', 'attachment_only' => true ) ); ?><figcaption><?php echo esc_html( $service['title'] ); ?></figcaption></figure><?php endforeach; ?>
   </div>
  </div>
 </section>
 <section class="alt-gallery" id="servizi" data-alt-gallery>
  <div class="alt-gallery__stage">
   <header class="alt-gallery__heading"><h2><?php echo esc_html( $sections['services']['title'] ); ?></h2><span class="alt-gallery__count" aria-hidden="true"><span data-alt-gallery-current>01</span> / <?php echo esc_html( str_pad( (string) count( $featured ), 2, '0', STR_PAD_LEFT ) ); ?></span></header>
   <div class="alt-gallery__viewport"><div class="alt-gallery__track" data-alt-track>
    <?php foreach ( $featured as $index => $service ) : ?>
    <article class="alt-chapter" data-alt-chapter>
     <div class="alt-chapter__photo"><?php echo miraservices_image( $service['image'], array( 'alt' => $service['title'], 'sizes' => '100vw', 'attachment_only' => true ) ); ?></div>
     <div class="alt-chapter__copy"><h3><?php echo esc_html( $service['title'] ); ?></h3><div><p><?php echo esc_html( $service['description'] ); ?></p><a class="alt-link" href="<?php echo esc_url( $service['url'] ); ?>"><?php esc_html_e( 'Esplora il servizio', 'miraservices' ); ?><span>↗</span></a></div></div>
    </article>
    <?php endforeach; ?>
   </div></div>
  </div>
 </section>
 <section class="alt-directory">
  <div class="alt-directory__heading"><h2><?php esc_html_e( 'Tutte le nostre competenze', 'miraservices' ); ?></h2><div><p><?php echo esc_html( $sections['services']['text'] ); ?></p><?php if ( $showroom['ids'] ) : ?><a class="alt-link" href="#realizzazioni"><?php esc_html_e( 'Le nostre realizzazioni', 'miraservices' ); ?><span aria-hidden="true">↘</span></a><?php endif; ?></div></div>
  <div class="alt-directory__body"><div class="alt-directory__list">
   <?php foreach ( $services as $index => $service ) : ?><a href="<?php echo esc_url( $service['url'] ); ?>" data-alt-directory-item="<?php echo esc_attr( $index ); ?>"<?php echo 0 === $index ? ' class="is-current"' : ''; ?>><span><?php echo esc_html( $service['title'] ); ?></span><i aria-hidden="true">↗</i></a><?php endforeach; ?>
  </div><div class="alt-directory__previews" aria-hidden="true"><?php foreach ( $services as $index => $service ) : ?><figure data-alt-directory-preview="<?php echo esc_attr( $index ); ?>"<?php echo 0 === $index ? ' class="is-current"' : ''; ?>><?php echo miraservices_image( $service['secondary_image'], array( 'alt' => '', 'sizes' => '(min-width: 900px) 40vw, 1px', 'attachment_only' => true ) ); ?><figcaption><?php echo esc_html( $service['description'] ); ?></figcaption></figure><?php endforeach; ?></div></div>
 </section>
 <?php if ( $showroom['ids'] ) : ?>
 <section class="alt-showroom" id="realizzazioni" aria-labelledby="alt-showroom-title" data-alt-showroom>
  <header class="alt-showroom__heading"><div><span class="alt-showroom__count"><?php echo esc_html( count( $showroom['ids'] ) ); ?> <span><?php esc_html_e( 'fotografie', 'miraservices' ); ?></span></span><h2 id="alt-showroom-title"><?php echo esc_html( $showroom['title'] ); ?></h2></div><p><?php echo esc_html( wp_strip_all_tags( $showroom['description'] ) ); ?></p></header>
  <div class="alt-showroom__collection">
  <?php foreach ( miraservices_showroom_rows( $showroom['ids'] ) as $row_index => $row ) : ?>
   <div class="alt-showroom__row" data-showroom-row>
   <?php foreach ( $row as $image_id ) :
    $meta = wp_get_attachment_metadata( $image_id ); $ratio = $meta['width'] / $meta['height'];
    $label = wp_strip_all_tags( get_the_title( $image_id ) );
    $full = wp_get_attachment_image_src( $image_id, 'full' );
    ?>
    <figure class="alt-showroom__photo<?php echo $ratio > 1.2 ? ' is-landscape' : ''; ?>" style="--photo-ratio:<?php echo esc_attr( round( $ratio, 5 ) ); ?>">
     <a href="<?php echo esc_url( $full[0] ); ?>" data-showroom-photo data-title="<?php echo esc_attr( $label ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Ingrandisci: %s', 'miraservices' ), $label ) ); ?>">
      <?php echo wp_get_attachment_image( $image_id, 'large', false, array( 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '(max-width: 600px) 90vw, (max-width: 899px) 45vw, 35vw' ) ); ?>
      <span class="alt-showroom__expand" aria-hidden="true">↗</span>
     </a><figcaption><?php echo esc_html( $label ); ?></figcaption>
    </figure>
   <?php endforeach; ?>
   </div>
  <?php endforeach; ?>
  </div>
  <dialog class="alt-lightbox" aria-label="<?php esc_attr_e( 'Galleria delle realizzazioni', 'miraservices' ); ?>" data-showroom-dialog data-lenis-prevent>
   <header><span data-showroom-position></span><button type="button" data-showroom-close><?php esc_html_e( 'Chiudi', 'miraservices' ); ?> <span aria-hidden="true">×</span></button></header>
   <figure><img data-showroom-image src="<?php echo esc_url( wp_get_attachment_image_url( $showroom['ids'][0], 'full' ) ); ?>" loading="lazy" decoding="async" alt=""><figcaption data-showroom-caption></figcaption></figure>
   <footer><button type="button" data-showroom-prev aria-label="<?php esc_attr_e( 'Foto precedente', 'miraservices' ); ?>">←</button><p data-showroom-announcement role="status" aria-live="polite"></p><button type="button" data-showroom-next aria-label="<?php esc_attr_e( 'Foto successiva', 'miraservices' ); ?>">→</button></footer>
  </dialog>
 </section>
 <?php endif; ?>
 <?php $steps = array_values( $sections['method']['steps'] ); ?>
 <section class="alt-process" id="perche-mira" data-alt-process>
  <div class="alt-process__stage">
   <div class="alt-process__visual"><div class="alt-process__photos"><?php foreach ( $steps as $index => $step ) : $visual = $services[ $index + 3 ] ?? array(); ?><figure data-alt-process-photo="<?php echo esc_attr( $index ); ?>"<?php echo 0 === $index ? ' class="is-current"' : ''; ?>><?php echo miraservices_image( $visual['secondary_image'] ?? '', array( 'alt' => '', 'sizes' => '(min-width: 900px) 50vw, 90vw', 'attachment_only' => true ) ); ?></figure><?php endforeach; ?></div><p class="alt-process__statement"><?php echo esc_html( $sections['advantage']['title'] ); ?></p></div>
   <div class="alt-process__copy"><h2><?php echo esc_html( $sections['method']['title'] ); ?></h2><p class="alt-process__intro"><?php echo esc_html( $sections['advantage']['text'] ); ?></p><div class="alt-process__steps">
    <?php foreach ( $steps as $index => $step ) : ?><article data-alt-process-step="<?php echo esc_attr( $index ); ?>"<?php echo 0 === $index ? ' class="is-current"' : ''; ?>><h3><button type="button" data-alt-process-jump="<?php echo esc_attr( $index ); ?>"><?php echo esc_html( $step['title'] ); ?></button></h3><p><?php echo esc_html( $step['text'] ); ?></p></article><?php endforeach; ?>
   </div><div class="alt-process__progress" aria-hidden="true"><span></span></div></div>
  </div>
 </section>
 <?php foreach ( $services as $service ) : if ( ! $service['is_emergency'] ) { continue; } ?>
 <section class="alt-urgent" id="picchetto"><div class="alt-urgent__photo"><?php echo miraservices_image( $service['secondary_image'], array( 'alt' => '', 'sizes' => '70vw', 'attachment_only' => true ) ); ?><span aria-hidden="true"><?php echo esc_html( $service['title'] ); ?></span></div><div class="alt-urgent__copy"><h2><?php echo esc_html( $sections['emergency']['title'] ); ?></h2><p><?php echo esc_html( $sections['emergency']['text'] ); ?></p><?php if ( ! empty( $contact['phone'] ) ) : ?><a class="alt-link" href="https://wa.me/<?php echo esc_attr( ltrim( miraservices_phone_uri( $contact['phone'] ), '+' ) ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Scrivici su WhatsApp', 'miraservices' ); ?><span>↗</span></a><?php endif; ?></div></section>
 <?php endforeach; ?>
 <section class="alt-connect" id="contatti" aria-labelledby="alt-connect-title">
  <header class="alt-connect__intro"><h2 id="alt-connect-title"><?php echo esc_html( $sections['contact']['title'] ); ?></h2><p><?php echo esc_html( $sections['contact']['text'] ); ?></p></header>
  <div class="alt-connect__channels">
   <?php if ( ! empty( $contact['phone'] ) ) : ?>
   <a class="alt-connect__phone" href="tel:<?php echo esc_attr( miraservices_phone_uri( $contact['phone'] ) ); ?>"><span class="alt-connect__label"><?php esc_html_e( 'Telefono', 'miraservices' ); ?></span><strong><?php echo esc_html( miraservices_format_phone( $contact['phone'] ) ); ?></strong><i aria-hidden="true">↗</i></a>
   <?php endif; ?>
   <div class="alt-connect__secondary">
    <?php if ( ! empty( $contact['email'] ) ) : ?><a href="mailto:<?php echo esc_attr( $contact['email'] ); ?>"><span class="alt-connect__label"><?php esc_html_e( 'Email', 'miraservices' ); ?></span><strong><?php echo esc_html( $contact['email'] ); ?></strong><i aria-hidden="true">↗</i></a><?php endif; ?>
    <?php if ( ! empty( $contact['phone'] ) ) : ?><a href="https://wa.me/<?php echo esc_attr( ltrim( miraservices_phone_uri( $contact['phone'] ), '+' ) ); ?>" target="_blank" rel="noopener noreferrer"><span class="alt-connect__label"><?php esc_html_e( 'WhatsApp', 'miraservices' ); ?></span><strong><?php esc_html_e( 'Scrivici direttamente', 'miraservices' ); ?></strong><i aria-hidden="true">↗</i></a><?php endif; ?>
   </div>
  </div>
  <?php if ( ! empty( $contact['address'] ) ) : ?><div class="alt-connect__address"><span class="alt-connect__label"><?php esc_html_e( 'Dove siamo', 'miraservices' ); ?></span><address><?php echo esc_html( $contact['address'] ); ?></address></div><?php endif; ?>
 </section>
</main>
<?php get_footer(); ?>
