<?php $service = $args['service']; $has_image = has_post_thumbnail( $service['id'] ); ?>
<header class="mira-service-hero<?php echo $has_image ? '' : ' mira-service-hero--without-visual'; ?>" data-mira-service-hero>
	<div class="mira-service-hero__ambient" aria-hidden="true"></div>
	<nav class="mira-service-breadcrumbs mira-service-shell" aria-label="<?php esc_attr_e( 'Percorso di navigazione', 'miraservices' ); ?>"><ol><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'miraservices' ); ?></a></li><li><a href="<?php echo esc_url( home_url( '/#servizi' ) ); ?>"><?php esc_html_e( 'Servizi', 'miraservices' ); ?></a></li><li aria-current="page"><?php echo esc_html( $service['title'] ); ?></li></ol></nav>
	<div class="mira-service-hero__stage mira-service-shell">
		<div class="mira-service-hero__copy">
			<?php if ( $service['eyebrow'] ) : ?><p class="mira-service-kicker"><?php echo esc_html( $service['eyebrow'] ); ?></p><?php endif; ?>
			<h1><?php echo esc_html( $service['title'] ); ?></h1>
			<?php if ( $service['lead'] ) : ?><p class="mira-service-hero__lead"><?php echo esc_html( $service['lead'] ); ?></p><?php endif; ?>
			<?php if ( ! empty( $service['hero_cta']['url'] ) && ! empty( $service['hero_cta']['label'] ) ) : ?><a class="mira-service-button" href="<?php echo esc_url( $service['hero_cta']['url'] ); ?>"><?php echo esc_html( $service['hero_cta']['label'] ); ?><span aria-hidden="true">↗</span></a><?php endif; ?>
		</div>
		<?php if ( $has_image ) : ?><figure class="mira-service-hero__visual" data-mira-service-visual><?php echo get_the_post_thumbnail( $service['id'], 'full', array( 'loading' => 'eager', 'fetchpriority' => 'high', 'decoding' => 'async', 'sizes' => '(min-width: 1100px) 46vw, 100vw' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php if ( $service['eyebrow'] ) : ?><figcaption><?php echo esc_html( $service['eyebrow'] ); ?></figcaption><?php endif; ?></figure><?php endif; ?>
	</div>
</header>
