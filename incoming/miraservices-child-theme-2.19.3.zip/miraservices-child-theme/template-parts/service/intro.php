<?php $service = $args['service']; if ( ! $service['intro_title'] || empty( $service['intro'] ) ) { return; } ?>
<section class="mira-service-intro mira-service-shell" aria-labelledby="mira-service-intro-title" data-mira-service-reveal>
	<div class="mira-service-section-head"><p class="mira-service-kicker"><?php printf( esc_html__( 'Servizio / %s', 'miraservices' ), esc_html( str_pad( (string) $service['index'], 2, '0', STR_PAD_LEFT ) ) ); ?></p><h2 id="mira-service-intro-title"><?php echo esc_html( $service['intro_title'] ); ?></h2></div>
	<div class="mira-service-intro__copy"><?php foreach ( $service['intro'] as $paragraph ) : ?><p><?php echo esc_html( $paragraph ); ?></p><?php endforeach; ?></div>
</section>
