<?php
/** Shared editorial composition for all Mira service pages. */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$mira_service = isset( $args['service'] ) && is_array( $args['service'] ) ? $args['service'] : array();
if ( empty( $mira_service ) ) { return; }
$mira_variant = ( ( max( 1, (int) $mira_service['index'] ) - 1 ) % 3 ) + 1;
$mira_classes = array( 'mira-service-page', 'mira-service-page--variant-' . $mira_variant, 'mira-service-page--' . sanitize_html_class( $mira_service['style'] ) );
if ( $mira_service['is_emergency'] ) { $mira_classes[] = 'mira-service-page--emergency'; }
?>
<article <?php post_class( implode( ' ', $mira_classes ) ); ?> data-mira-service-page>
	<?php foreach ( array( 'hero', 'intro', 'scope', 'audience', 'process', 'visual', 'why-mira', 'related' ) as $mira_part ) { get_template_part( 'template-parts/service/' . $mira_part, null, array( 'service' => $mira_service ) ); } ?>
</article>
