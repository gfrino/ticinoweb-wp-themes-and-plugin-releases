<?php
/**
 * Blog category archive (packaging-lines children: Caseario, Ortofrutta, …).
 *
 * Native rebuild of the approved Elementor "All Listed Post" archive template,
 * extended with custom commercial presentations for the 3 macro-sectors:
 * - Ortofrutta
 * - Gastronomia, Panetteria e IV Gamma
 * - Carne, Pesce e Caseario
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$hero_bg  = samswiss_hero_bg_url();
$cat      = get_queried_object();
$cat_slug = ( $cat instanceof WP_Term ) ? $cat->slug : '';
$sector   = function_exists( 'samswiss_get_sector_data' ) ? samswiss_get_sector_data( $cat_slug ) : null;

/*
 * Il volantino deve comparire anche sulle categorie tradotte (FR, DE), che
 * hanno uno slug diverso e quindi nessun $sector: lo si cerca sullo slug
 * della categoria originale italiana.
 */
$sector_flyer = ( $sector && ! empty( $sector['flyer'] ) ) ? $sector['flyer'] : null;
if ( ! $sector_flyer && $cat instanceof WP_Term && function_exists( 'samswiss_get_sector_data' ) ) {
	$orig_id = (int) apply_filters( 'wpml_object_id', $cat->term_id, 'category', true, apply_filters( 'wpml_default_language', null ) );
	if ( $orig_id && $orig_id !== (int) $cat->term_id ) {
		global $wpdb;
		$orig_slug   = $wpdb->get_var( $wpdb->prepare( "SELECT slug FROM {$wpdb->terms} WHERE term_id = %d", $orig_id ) );
		$orig_sector = $orig_slug ? samswiss_get_sector_data( $orig_slug ) : null;
		if ( $orig_sector && ! empty( $orig_sector['flyer'] ) ) {
			$sector_flyer = $orig_sector['flyer'];
		}
	}
}
?>

<main id="primary" class="samswiss-main samswiss-archive<?php echo $sector ? ' samswiss-sector-archive' : ''; ?>">

	<!-- Hero -->
	<section class="samswiss-arch-hero" style="background-image: linear-gradient(rgba(0,0,0,0.55), rgba(0,0,0,0.55)), url('<?php echo esc_url( $hero_bg ); ?>');">
		<div class="samswiss-container samswiss-arch-hero__grid">
			<div class="samswiss-arch-hero__box">
				<p class="sw-label">S.A.M. SA<?php echo ( $cat instanceof WP_Term ) ? ' · ' . esc_html( $cat->name ) : ''; ?></p>
				<h1 class="samswiss-arch-hero__title"><?php echo $sector ? esc_html( $sector['title'] ) : single_cat_title( '', false ); ?></h1>
				<?php if ( $sector && ! empty( $sector['subtitle'] ) ) : ?>
					<p class="samswiss-sector-subtitle"><?php echo esc_html( $sector['subtitle'] ); ?></p>
				<?php endif; ?>
			</div>
			<div class="samswiss-arch-hero__intro">
				<?php if ( $sector ) : ?>
					<?php if ( ! empty( $sector['theme_img'] ) ) : ?>
						<div class="samswiss-sector-photo-wrap">
							<?php echo samswiss_shipped_image( $sector['theme_img'], '', $sector['alt'], 'samswiss-sector-photo', 'eager' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</div>
					<?php endif; ?>
					<div class="samswiss-sector-intro-text">
						<p><?php echo esc_html( $sector['intro'] ); ?></p>
					</div>
				<?php else : ?>
					<h2 class="samswiss-arch-hero__brand"><?php esc_html_e( 'SAM SA Automatic Machine Systems', 'samswiss-child' ); ?></h2>
					<p><?php esc_html_e( 'Nel 1989 un gruppo di giovani tecnici ha iniziato la costruzione delle prime macchine confezionatrici e dei primi automatismi industriali MADE IN SAM…', 'samswiss-child' ); ?></p>
				<?php endif; ?>
			</div>
		</div>
	</section>

	<?php if ( $sector && ! empty( $sector['pills'] ) ) : ?>
		<!-- Product Pills Bar (es. Ortofrutta) -->
		<section class="samswiss-sector-pills-bar">
			<div class="samswiss-container">
				<?php if ( ! empty( $sector['pills_label'] ) ) : ?>
					<span class="samswiss-sector-pills__label"><?php echo esc_html( $sector['pills_label'] ); ?></span>
				<?php endif; ?>
				<ul class="samswiss-sector-pills-list">
					<?php foreach ( $sector['pills'] as $pill ) : ?>
						<li><span class="samswiss-pill"><?php echo esc_html( $pill ); ?></span></li>
					<?php endforeach; ?>
				</ul>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( $sector && ! empty( $sector['blocks'] ) ) : ?>
		<!-- Visual Sub-blocks (es. Gastronomia o Carne/Pesce) -->
		<section class="samswiss-sector-blocks-section">
			<div class="samswiss-container">
				<?php if ( ! empty( $sector['blocks_title'] ) ) : ?>
					<h2 class="samswiss-section-heading"><?php echo esc_html( $sector['blocks_title'] ); ?></h2>
				<?php endif; ?>
				<div class="samswiss-sector-blocks-grid">
					<?php foreach ( $sector['blocks'] as $block ) : ?>
						<div class="samswiss-sector-block-card">
							<?php if ( ! empty( $block['icon'] ) ) : ?>
								<span class="samswiss-sector-block__icon"><i class="fas <?php echo esc_attr( $block['icon'] ); ?>"></i></span>
							<?php endif; ?>
							<h3 class="samswiss-sector-block__name"><?php echo esc_html( $block['name'] ); ?></h3>
							<p class="samswiss-sector-block__desc"><?php echo esc_html( $block['desc'] ); ?></p>
							<?php if ( ! empty( $block['techs'] ) ) : ?>
								<div class="samswiss-sector-block__techs">
									<span class="samswiss-sector-block__techs-label"><?php esc_html_e( 'Tecnologie predominanti:', 'samswiss-child' ); ?></span>
									<div class="samswiss-sector-block__tech-links">
										<?php foreach ( $block['techs'] as $t ) : ?>
											<a href="<?php echo esc_url( $t['url'] ); ?>" class="samswiss-tech-pill"><?php echo esc_html( $t['name'] ); ?> &rarr;</a>
										<?php endforeach; ?>
									</div>
								</div>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>

				<?php if ( ! empty( $sector['materials_box'] ) ) : ?>
					<div class="samswiss-sector-materials-banner">
						<div class="samswiss-sector-materials__content">
							<h3><?php echo esc_html( $sector['materials_box']['title'] ); ?></h3>
							<p class="samswiss-sector-materials__text"><?php echo esc_html( $sector['materials_box']['text'] ); ?></p>
							<p class="samswiss-sector-materials__claim"><?php echo esc_html( $sector['materials_box']['claim'] ); ?></p>
						</div>
						<a href="<?php echo esc_url( $sector['materials_box']['url'] ); ?>" class="samswiss-btn samswiss-btn--green">
							<span><?php echo esc_html( $sector['materials_box']['btn'] ); ?></span>
							<span aria-hidden="true">&rarr;</span>
						</a>
					</div>
				<?php endif; ?>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( $sector_flyer ) : ?>
		<!-- Volantino del settore (IT/FR/DE) -->
		<section class="samswiss-sector-flyer-section">
			<div class="samswiss-container">
				<?php get_template_part( 'template-parts/flyer', null, $sector_flyer ); ?>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( $sector && ! empty( $sector['tech_cards'] ) ) : ?>
		<!-- Technology Cards Grid -->
		<section class="samswiss-sector-tech-section">
			<div class="samswiss-container">
				<h2 class="samswiss-section-heading"><?php echo esc_html( $sector['tech_title'] ); ?></h2>
				<?php if ( ! empty( $sector['tech_intro'] ) ) : ?>
					<p class="samswiss-section-lede"><?php echo esc_html( $sector['tech_intro'] ); ?></p>
				<?php endif; ?>
				<div class="samswiss-sector-tech-grid">
					<?php foreach ( $sector['tech_cards'] as $tc ) : ?>
						<a class="samswiss-sector-tech-card" href="<?php echo esc_url( $tc['url'] ); ?>">
							<span class="samswiss-sector-tech-card__icon"><i class="fas <?php echo esc_attr( $tc['icon'] ); ?>"></i></span>
							<span class="samswiss-sector-tech-card__title"><?php echo esc_html( $tc['title'] ); ?></span>
							<?php if ( ! empty( $tc['tag'] ) ) : ?>
								<span class="samswiss-sector-tech-card__tag"><?php echo esc_html( $tc['tag'] ); ?></span>
							<?php endif; ?>
							<span class="samswiss-sector-tech-card__arrow" aria-hidden="true">&rarr;</span>
						</a>
					<?php endforeach; ?>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( $sector && ! empty( $sector['assistenza'] ) ) : ?>
		<!-- Assistenza in Svizzera -->
		<section class="samswiss-sector-assistenza">
			<div class="samswiss-container">
				<div class="samswiss-sector-assistenza__box">
					<div class="samswiss-sector-assistenza__flag" aria-hidden="true"><i class="fas fa-shield-halved"></i></div>
					<div>
						<h3><?php echo esc_html( $sector['assistenza']['title'] ); ?> — <span class="sub"><?php echo esc_html( $sector['assistenza']['sub'] ); ?></span></h3>
						<p><?php echo esc_html( $sector['assistenza']['text'] ); ?></p>
					</div>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<!-- Red category nav: official 3 industrial sectors -->
	<nav class="samswiss-arch-nav" aria-label="<?php esc_attr_e( 'Settori Industriali', 'samswiss-child' ); ?>">
		<div class="samswiss-container">
			<?php
			if ( has_nav_menu( 'category-menu' ) ) {
				wp_nav_menu( array(
					'theme_location' => 'category-menu',
					'menu_class'     => 'samswiss-arch-nav__list',
					'container'      => false,
					'depth'          => 1,
					'fallback_cb'    => false,
				) );
			} else {
				$sec_items = function_exists( 'samswiss_get_official_sectors_nav_items' ) ? samswiss_get_official_sectors_nav_items() : array();
				if ( ! empty( $sec_items ) ) {
					echo '<ul class="samswiss-arch-nav__list">';
					foreach ( $sec_items as $si ) {
						$cls  = implode( ' ', (array) $si->classes );
						$aria = ! empty( $si->current ) ? ' aria-current="page"' : '';
						echo '<li class="' . esc_attr( $cls ) . '"><a href="' . esc_url( $si->url ) . '"' . $aria . '>' . esc_html( $si->title ) . '</a></li>';
					}
					echo '</ul>';
				}
			}
			?>
		</div>
	</nav>

	<!-- Machine cards -->
	<section class="samswiss-arch-list">
		<div class="samswiss-container">
			<?php if ( $sector ) : ?>
				<h2 class="samswiss-arch-list__heading"><?php esc_html_e( 'Macchine e linee disponibili per questo settore', 'samswiss-child' ); ?></h2>
			<?php endif; ?>

			<?php if ( have_posts() ) : ?>
				<div class="samswiss-arch-grid">
					<?php while ( have_posts() ) : the_post(); ?>
						<article <?php post_class( 'samswiss-card' ); ?>>
							<?php if ( has_post_thumbnail() ) : ?>
								<a class="samswiss-card__media" href="<?php the_permalink(); ?>">
									<?php the_post_thumbnail( 'medium_large', array( 'loading' => 'lazy' ) ); ?>
								</a>
							<?php endif; ?>
							<div class="samswiss-card__body">
								<h2 class="samswiss-card__title">
									<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
								</h2>
								<p class="samswiss-card__excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 18, '…' ) ); ?></p>
								<a class="samswiss-card__btn" href="<?php the_permalink(); ?>">
									<span><?php esc_html_e( 'Scopri di più', 'samswiss-child' ); ?></span>
									<span aria-hidden="true">&rarr;</span>
								</a>
							</div>
						</article>
					<?php endwhile; ?>
				</div>

				<?php
				// Prev/next only, matching the original archive pagination.
				$prev_link = get_previous_posts_link( '&laquo; ' . esc_html__( 'Precedente', 'samswiss-child' ) );
				$next_link = get_next_posts_link( esc_html__( 'Successivo', 'samswiss-child' ) . ' &raquo;' );
				if ( $prev_link || $next_link ) : ?>
					<nav class="samswiss-arch-pagination" aria-label="<?php esc_attr_e( 'Navigazione articoli', 'samswiss-child' ); ?>">
						<div class="nav-links">
							<span class="nav-prev"><?php echo wp_kses_post( $prev_link ); ?></span>
							<span class="nav-next"><?php echo wp_kses_post( $next_link ); ?></span>
						</div>
					</nav>
				<?php endif; ?>
			<?php else : ?>
				<p class="samswiss-arch-empty"><?php esc_html_e( 'Nessun contenuto disponibile in questa categoria.', 'samswiss-child' ); ?></p>
			<?php endif; ?>
		</div>
	</section>

	<!-- Boxed red newsletter -->
	<section class="samswiss-arch-newsletter">
		<div class="samswiss-container">
			<div class="samswiss-arch-newsletter__box">
				<div class="samswiss-newsletter-text">
					<p class="samswiss-newsletter-small"><?php esc_html_e( 'Iscriviti alla newsletter', 'samswiss-child' ); ?></p>
					<h2 class="samswiss-newsletter-big"><?php esc_html_e( 'TIENITI AGGIORNATO', 'samswiss-child' ); ?></h2>
				</div>
				<?php samswiss_newsletter_form( 'archive' ); ?>
			</div>
		</div>
	</section>

</main>

<?php
get_footer();
