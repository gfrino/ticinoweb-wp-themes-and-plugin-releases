<?php
/**
 * Single post / CPT template.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="primary" class="samswiss-main samswiss-single">
	<?php while ( have_posts() ) : the_post(); ?>
		<header class="samswiss-page-header">
			<div class="samswiss-container">
				<p class="sw-label"><?php echo esc_html( get_the_date() ); ?></p>
				<h1 class="samswiss-page-title"><?php the_title(); ?></h1>
			</div>
		</header>
		<article <?php post_class( 'samswiss-single-article' ); ?>>
			<div class="samswiss-container samswiss-single-inner">
				<?php if ( has_post_thumbnail() ) : ?>
					<div class="samswiss-single-thumb"><?php the_post_thumbnail( 'large' ); ?></div>
				<?php endif; ?>
				<div class="samswiss-single-content">
					<?php
					the_content();
					wp_link_pages();
					?>
				</div>
			</div>
		</article>
	<?php endwhile; ?>
</main>

<?php
get_footer();
