<?php
/**
 * SAM SWISS footer — reproduces the Elementor footer layout natively.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$contact  = samswiss_get_contact();
$logo     = samswiss_get_logo_url();
// "Area Riservata": ticinoWEB login URL (tw-login).
$reserved = home_url( '/tw-login/' );
?>
	</div><!-- #content -->

	<footer class="samswiss-footer">
		<div class="samswiss-footer-top">
			<div class="samswiss-container">

				<div class="footer-col footer-brand">
					<?php
					// The mark, not the wordmark. It stays an <h2> because the footer's
					// outline needs its heading, and the alt text carries the company
					// name the type used to say.
					?>
					<h2 class="footer-brand-mark"><img src="<?php echo esc_url( $logo ); ?>"<?php echo samswiss_logo_dimensions( $logo ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- helper returns escaped integers. ?> alt="S.A.M. SA"></h2>
					<p class="footer-brand-sub"><?php esc_html_e( 'Sistemi Automatici Macchine', 'samswiss-child' ); ?></p>
					<p class="footer-brand-desc"><?php esc_html_e( 'Nel 1989 un gruppo di giovani tecnici ha iniziato la costruzione delle prime macchine confezionatrici e dei primi automatismi industriali MADE IN SAM.', 'samswiss-child' ); ?></p>
				</div>

				<?php
				// The column used to repeat the logo, which now lives in the brand column
				// to its left. It carries the invitation instead; the class is renamed so
				// it stops claiming to hold a logo.
				?>
				<div class="footer-col footer-social-col">
					<h3><?php esc_html_e( 'Seguici sui social', 'samswiss-child' ); ?></h3>
					<?php
					// Same marks, same source: inline SVG that cannot fail to load.
					if ( function_exists( 'samswiss_social_links' ) ) {
						samswiss_social_links( 'samswiss-footer-social' );
					}
					?>
				</div>

				<div class="footer-col footer-contact">
					<h3><?php esc_html_e( 'Contatto', 'samswiss-child' ); ?></h3>
					<div class="footer-contact-item">
						<i class="fas fa-envelope"></i>
						<a href="mailto:<?php echo esc_attr( $contact['email'] ); ?>"><?php echo esc_html( $contact['email'] ); ?></a>
					</div>
					<div class="footer-contact-item">
						<i class="fas fa-phone-alt"></i>
						<a href="tel:<?php echo esc_attr( $contact['phone'] ); ?>"><?php echo esc_html( $contact['phone_display'] ); ?></a>
					</div>
					<?php if ( ! empty( $contact['address'] ) ) : ?>
						<div class="footer-contact-item">
							<i class="fas fa-map-marker-alt"></i>
							<span>
								<?php echo esc_html( $contact['address'] ); ?>
								<?php if ( ! empty( $contact['vat'] ) ) : ?>
									<br><?php echo esc_html( 'Nr. IVA: ' . $contact['vat'] ); ?>
								<?php endif; ?>
							</span>
						</div>
					<?php endif; ?>
				</div>

			</div>
		</div>

		<div class="samswiss-footer-bottom">
			<div class="samswiss-container">
				<span class="footer-copyright">&copy; <?php echo esc_html( date_i18n( 'Y' ) ); ?> S.A.M. SA <?php esc_html_e( 'Sistemi Automatici Macchine', 'samswiss-child' ); ?></span>
				<?php if ( $reserved ) : ?>
					<a class="footer-reserved" href="<?php echo esc_url( $reserved ); ?>"><i class="fas fa-lock"></i> <?php esc_html_e( 'Area Riservata', 'samswiss-child' ); ?></a>
				<?php endif; ?>
				<span class="footer-credit">design by <a href="https://ticinoweb.com" target="_blank" rel="noopener">ticinoWEB</a></span>
			</div>
		</div>

		<?php
		// The language row below the footer is rendered by WPML's automatic
		// "language switcher in the footer" (.wpml-ls-statics-footer), matching
		// the original site. We intentionally do NOT output a second one here.
		?>
	</footer>

</div><!-- #page -->
<?php wp_footer(); ?>
</body>
</html>
