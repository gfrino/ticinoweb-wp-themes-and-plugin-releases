/* SAM SWISS child theme — main.js
   Header interactions: mobile drawer, search modal, language dropdown. */
(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		var body = document.body;

		// --- Mobile drawer ---
		var drawer = document.querySelector('.samswiss-mobile-drawer');
		var overlay = document.querySelector('.samswiss-drawer-overlay');
		var openBtn = document.querySelector('.mobile-menu-trigger');
		var closeBtn = document.querySelector('.samswiss-mobile-drawer .drawer-close');

		var lastFocused = null;
		var FOCUSABLE = 'a[href], button:not([disabled]), input:not([disabled]), select, textarea, [tabindex]:not([tabindex="-1"])';

		function openDrawer() {
			if (drawer) { drawer.classList.add('is-open'); }
			if (overlay) { overlay.classList.add('is-open'); }
			body.style.overflow = 'hidden';
			if (openBtn) { openBtn.setAttribute('aria-expanded', 'true'); }
			// Move focus into the panel so keyboard and screen-reader users are
			// not left behind the overlay, and remember where to send them back.
			lastFocused = document.activeElement;
			if (closeBtn) { closeBtn.focus(); }
		}
		function closeDrawer() {
			var wasOpen = drawer && drawer.classList.contains('is-open');
			if (drawer) { drawer.classList.remove('is-open'); }
			if (overlay) { overlay.classList.remove('is-open'); }
			body.style.overflow = '';
			if (openBtn) { openBtn.setAttribute('aria-expanded', 'false'); }
			if (wasOpen && lastFocused && typeof lastFocused.focus === 'function') {
				lastFocused.focus();
				lastFocused = null;
			}
		}

		// Keep Tab inside the drawer while it is open.
		if (drawer) {
			drawer.addEventListener('keydown', function (e) {
				if (e.key !== 'Tab' || !drawer.classList.contains('is-open')) { return; }
				var items = Array.prototype.slice.call(drawer.querySelectorAll(FOCUSABLE))
					.filter(function (el) { return el.offsetParent !== null; });
				if (!items.length) { return; }
				var first = items[0];
				var last = items[items.length - 1];
				if (e.shiftKey && document.activeElement === first) {
					e.preventDefault();
					last.focus();
				} else if (!e.shiftKey && document.activeElement === last) {
					e.preventDefault();
					first.focus();
				}
			});
		}
		if (openBtn) { openBtn.addEventListener('click', openDrawer); }
		if (closeBtn) { closeBtn.addEventListener('click', closeDrawer); }
		if (overlay) { overlay.addEventListener('click', closeDrawer); }

		// --- Language dropdown (topbar / footer) ---
		document.querySelectorAll('.samswiss-lang-dropdown .samswiss-lang-current').forEach(function (btn) {
			btn.addEventListener('click', function (e) {
				e.stopPropagation();
				var parent = btn.closest('.samswiss-lang-dropdown');
				var isOpen = parent.classList.toggle('is-open');
				btn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
			});
		});
		document.addEventListener('click', function () {
			document.querySelectorAll('.samswiss-lang-dropdown.is-open').forEach(function (el) {
				el.classList.remove('is-open');
			});
		});

		// --- Search modal ---
		// The dialog ships with `hidden` so it is inert for everyone until asked
		// for, rather than an off-screen form that keyboard users can tab into.
		var searchModal = document.querySelector('.samswiss-search-modal');
		var searchLastFocused = null;

		function openSearch() {
			if (!searchModal) { return; }
			searchLastFocused = document.activeElement;
			searchModal.hidden = false;
			// Class is set on the next frame so the transition has a start state.
			requestAnimationFrame(function () { searchModal.classList.add('is-open'); });
			var input = searchModal.querySelector('input[type="search"]');
			if (input) { input.focus(); input.select(); }
		}
		function closeSearch() {
			if (!searchModal || searchModal.hidden) { return; }
			searchModal.classList.remove('is-open');
			searchModal.hidden = true;
			if (searchLastFocused && typeof searchLastFocused.focus === 'function') {
				searchLastFocused.focus();
				searchLastFocused = null;
			}
		}

		document.querySelectorAll('.search-trigger').forEach(function (btn) {
			btn.addEventListener('click', openSearch);
		});
		if (searchModal) {
			var searchClose = searchModal.querySelector('.search-modal-close');
			if (searchClose) { searchClose.addEventListener('click', closeSearch); }
			// Clicking the backdrop, but not the panel, dismisses.
			searchModal.addEventListener('click', function (e) {
				if (e.target === searchModal) { closeSearch(); }
			});
			// Keep Tab inside the dialog while it is open.
			searchModal.addEventListener('keydown', function (e) {
				if (e.key !== 'Tab') { return; }
				var items = Array.prototype.slice.call(searchModal.querySelectorAll(FOCUSABLE))
					.filter(function (el) { return el.offsetParent !== null; });
				if (!items.length) { return; }
				var first = items[0];
				var last = items[items.length - 1];
				if (e.shiftKey && document.activeElement === first) {
					e.preventDefault();
					last.focus();
				} else if (!e.shiftKey && document.activeElement === last) {
					e.preventDefault();
					first.focus();
				}
			});
		}
		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape') {
				closeDrawer();
				closeSearch();
			}
		});

		// --- Contact form (AJAX) ---
		var contactForm = document.querySelector('.samswiss-contact-form');
		if (contactForm && window.samswiss_ajax) {
			// The markup ships without `novalidate` so a no-JS visitor still gets the
			// browser's own required/email checks. Now that JS is running, its own
			// messages take over.
			contactForm.noValidate = true;
			contactForm.addEventListener('submit', function (e) {
				e.preventDefault();
				var feedback = contactForm.querySelector('.samswiss-form-feedback');
				var submitBtn = contactForm.querySelector('button[type="submit"]');
				var data = new FormData(contactForm);
				data.set('action', 'samswiss_contact');
				if (feedback) { feedback.textContent = ''; feedback.className = 'samswiss-form-feedback'; }
				if (submitBtn) { submitBtn.disabled = true; }
				fetch(window.samswiss_ajax.ajax_url, { method: 'POST', credentials: 'same-origin', body: data })
					.then(function (r) { return r.json(); })
					.then(function (res) {
						if (feedback) {
							feedback.textContent = res.message || '';
							feedback.classList.add(res.success ? 'is-success' : 'is-error');
						}
						if (res.success) { contactForm.reset(); }
						if (submitBtn) { submitBtn.disabled = false; }
					})
					.catch(function () {
						if (feedback) { feedback.textContent = 'Errore di rete. Riprova.'; feedback.classList.add('is-error'); }
						if (submitBtn) { submitBtn.disabled = false; }
					});
			});
		}

		// The hero's YouTube background video (and the mute/autoplay-enforcing
		// IFrame API logic that lived here for it) is gone as of point 50 — replaced
		// by a plain rotating photo, which needs no JS at all.

		// --- Sector array: engaging one frame dims the rest to evidence.
		// One orchestrated moment for the whole array, not per-card effects. ---
		document.querySelectorAll('[data-swiss-grid]').forEach(function (grid) {
			var frames = Array.prototype.slice.call(grid.querySelectorAll('.swiss-frame'));
			if (!frames.length) { return; }

			function engage(frame) {
				grid.classList.add('is-engaged');
				frames.forEach(function (f) { f.classList.toggle('is-active', f === frame); });
			}
			function release() {
				grid.classList.remove('is-engaged');
				frames.forEach(function (f) { f.classList.remove('is-active'); });
			}

			frames.forEach(function (frame) {
				frame.addEventListener('mouseenter', function () { engage(frame); });
				frame.addEventListener('focus', function () { engage(frame); });
				frame.addEventListener('blur', release);
			});
			grid.addEventListener('mouseleave', release);
		});

		// --- Newsletter signup: real endpoint, with a loading state and a
		// status message the screen reader announces (the form used to post to "#"
		// and silently drop the address). ---
		document.querySelectorAll('.samswiss-newsletter').forEach(function (form) {
			if (!window.samswiss_ajax) { return; }
			form.noValidate = true;
			var feedback = form.querySelector('.samswiss-newsletter-feedback');
			var submit = form.querySelector('button[type="submit"]');
			var submitLabel = submit ? submit.innerHTML : '';

			form.addEventListener('submit', function (e) {
				e.preventDefault();
				var email = form.querySelector('input[type="email"]');
				if (email && !email.checkValidity()) {
					if (feedback) {
						feedback.textContent = (window.samswiss_ajax.strings && window.samswiss_ajax.strings.invalid_email) || '';
						feedback.className = 'samswiss-newsletter-feedback is-error';
					}
					email.focus();
					return;
				}

				// action and source are hidden fields in the markup, because the form
				// must also work as a plain POST; only the AJAX target differs.
				var data = new FormData(form);
				data.set('action', 'samswiss_newsletter');

				if (feedback) { feedback.textContent = ''; feedback.className = 'samswiss-newsletter-feedback'; }
				if (submit) {
					submit.disabled = true;
					submit.setAttribute('aria-busy', 'true');
					submit.innerHTML = (window.samswiss_ajax.strings && window.samswiss_ajax.strings.sending) || submitLabel;
				}

				fetch(window.samswiss_ajax.ajax_url, { method: 'POST', credentials: 'same-origin', body: data })
					.then(function (r) { return r.json(); })
					.then(function (res) {
						if (feedback) {
							feedback.textContent = res.message || '';
							feedback.className = 'samswiss-newsletter-feedback ' + (res.success ? 'is-success' : 'is-error');
						}
						if (res.success) { form.reset(); }
					})
					.catch(function () {
						if (feedback) {
							feedback.textContent = (window.samswiss_ajax.strings && window.samswiss_ajax.strings.network_error) || '';
							feedback.className = 'samswiss-newsletter-feedback is-error';
						}
					})
					.finally(function () {
						if (submit) {
							submit.disabled = false;
							submit.removeAttribute('aria-busy');
							submit.innerHTML = submitLabel;
						}
					});
			});
		});

		// --- Live product search ---------------------------------------------
		// Suggests products while the visitor types. The field is a real input in a
		// real GET form, so with JavaScript unavailable it just submits to the
		// search page; this only adds the panel on top.
		document.querySelectorAll('[data-live-search]').forEach(function (input) {
			if (!window.samswiss_ajax || !window.samswiss_ajax.search_nonce) { return; }

			var wrap = input.closest('.samswiss-live-search');
			var panel = wrap && wrap.querySelector('.samswiss-live-search__panel');
			var status = input.closest('form')
				? input.closest('form').querySelector('[data-live-search-status]')
				: null;
			if (!panel) { return; }

			var strings = window.samswiss_ajax.strings || {};
			var timer = null;
			var controller = null;
			var options = [];
			var active = -1;
			var lastQuery = '';

			function say(text) { if (status) { status.textContent = text; } }

			function close() {
				panel.hidden = true;
				panel.innerHTML = '';
				input.setAttribute('aria-expanded', 'false');
				input.removeAttribute('aria-activedescendant');
				options = [];
				active = -1;
			}

			function highlight(index) {
				options.forEach(function (o, i) {
					var on = (i === index);
					o.classList.toggle('is-active', on);
					o.setAttribute('aria-selected', on ? 'true' : 'false');
				});
				active = index;
				if (index >= 0 && options[index]) {
					input.setAttribute('aria-activedescendant', options[index].id);
					// Keep the highlighted row in view without scrolling the page.
					var o = options[index];
					if (o.offsetTop < panel.scrollTop) { panel.scrollTop = o.offsetTop; }
					else if (o.offsetTop + o.offsetHeight > panel.scrollTop + panel.clientHeight) {
						panel.scrollTop = o.offsetTop + o.offsetHeight - panel.clientHeight;
					}
				} else {
					input.removeAttribute('aria-activedescendant');
				}
			}

			function render(data) {
				var q = data.query || '';
				panel.innerHTML = '';

				if (!data.results.length) {
					var empty = document.createElement('p');
					empty.className = 'samswiss-live-search__empty';
					empty.textContent = strings.no_results || '';
					panel.appendChild(empty);
					say(strings.no_results || '');
				} else {
					data.results.forEach(function (r, i) {
						var a = document.createElement('a');
						a.className = 'samswiss-live-search__hit';
						a.id = input.id + '-opt-' + i;
						a.href = r.url;
						a.setAttribute('role', 'option');
						a.setAttribute('aria-selected', 'false');

						var media = document.createElement('span');
						media.className = 'samswiss-live-search__media';
						if (r.thumb) {
							var im = document.createElement('img');
							im.src = r.thumb; im.alt = ''; im.loading = 'lazy';
							media.appendChild(im);
						}

						var body = document.createElement('span');
						body.className = 'samswiss-live-search__body';
						var t = document.createElement('span');
						t.className = 'samswiss-live-search__title';
						t.textContent = r.title;
						body.appendChild(t);
						if (r.price) {
							var pr = document.createElement('span');
							pr.className = 'samswiss-live-search__price';
							pr.textContent = r.price;
							body.appendChild(pr);
						}

						a.appendChild(media);
						a.appendChild(body);
						panel.appendChild(a);
					});

					if (data.total > data.results.length && window.samswiss_ajax.search_url) {
						var all = document.createElement('a');
						all.className = 'samswiss-live-search__all';
						all.href = window.samswiss_ajax.search_url + '?s=' + encodeURIComponent(q);
						all.setAttribute('role', 'option');
						all.setAttribute('aria-selected', 'false');
						all.id = input.id + '-opt-all';
						all.textContent = (strings.see_all || '') + ' (' + data.total + ')';
						panel.appendChild(all);
					}

					say((strings.result_count || '%s').replace('%s', data.total));
				}

				options = Array.prototype.slice.call(panel.querySelectorAll('[role="option"]'));
				active = -1;
				panel.hidden = false;
				input.setAttribute('aria-expanded', 'true');
			}

			function fetchSuggestions(q) {
				if (controller) { controller.abort(); }
				controller = new AbortController();
				var url = window.samswiss_ajax.ajax_url +
					'?action=samswiss_live_search&nonce=' + encodeURIComponent(window.samswiss_ajax.search_nonce) +
					'&q=' + encodeURIComponent(q);

				fetch(url, { credentials: 'same-origin', signal: controller.signal })
					.then(function (r) { return r.json(); })
					.then(function (data) {
						// A slower earlier response must not overwrite a newer query.
						if ((data.query || '') !== lastQuery) { return; }
						render(data);
					})
					.catch(function (err) {
						if (err && err.name === 'AbortError') { return; }
						close();
					});
			}

			input.addEventListener('input', function () {
				var q = input.value.trim();
				lastQuery = q;
				clearTimeout(timer);
				if (q.length < 2) { close(); return; }
				say(strings.searching || '');
				timer = setTimeout(function () { fetchSuggestions(q); }, 220);
			});

			input.addEventListener('keydown', function (e) {
				if (panel.hidden || !options.length) {
					if (e.key === 'ArrowDown' && input.value.trim().length >= 2) {
						fetchSuggestions(input.value.trim());
					}
					return;
				}
				if (e.key === 'ArrowDown') {
					e.preventDefault();
					highlight((active + 1) % options.length);
				} else if (e.key === 'ArrowUp') {
					e.preventDefault();
					highlight(active <= 0 ? options.length - 1 : active - 1);
				} else if (e.key === 'Enter') {
					// Enter without a highlighted row submits the form as usual.
					if (active >= 0 && options[active]) {
						e.preventDefault();
						window.location.href = options[active].href;
					}
				} else if (e.key === 'Escape') {
					e.stopPropagation();
					close();
				}
			});

			// Pointer highlight mirrors the keyboard one.
			panel.addEventListener('mousemove', function (e) {
				var o = e.target.closest('[role="option"]');
				if (o) { highlight(options.indexOf(o)); }
			});

			input.addEventListener('blur', function () {
				// Delay so a click on a suggestion still registers.
				setTimeout(close, 140);
			});
		});

		// --- Reveal motion on the Swiss surface -------------------------------
		// Thesis: nothing travels, things are uncovered. A wiping clip opens the
		// display type and the sector caption bands; only supporting prose settles.
		//
		// The observer watches SECTIONS, not the revealed elements. An element hidden
		// by a zero-area clip-path reports no intersection, so observing it directly
		// deadlocks: it stays clipped because it never intersects, and never
		// intersects because it is clipped. Sections are never clipped, and using
		// them as the trigger also makes each section's cascade its own.
		//
		// Classes are assigned here rather than in the template, so the markup keeps
		// no motion plumbing and a failed script leaves the page fully visible.
		(function () {
			var surface = document.querySelector('.swiss-page');
			if (!surface || !('IntersectionObserver' in window)) { return; }

			var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)');
			if (reduced && reduced.matches) { return; }

			// section root -> [selector, kind, index] ; index drives the delay so each
			// section reads as one authored cascade rather than a queue of fades.
			// The section is what gets watched, never the revealed element: an element
			// covered by a zero-area clip-path never intersects, so observing it would
			// leave it hidden for good.
			var groups = [
				['.swiss-hero', [
					['.swiss-hero__title', 'stamp', 0],
					['.swiss-hero__lede', 'rise', 1],
					['.swiss-cta__btn', 'rise', 2]
				]],
				// Only the display type is revealed. The fact strip stays put, and so
				// does the solutions grid: it has its own hover state per card, and an
				// entrance on top of that competed with it in the sector array this
				// replaced (point 46) — same reasoning, new selector.
				['.swiss-solutions', [
					['.swiss-solutions__title', 'stamp', 0]
				]],
				['.swiss-partners', [
					['.swiss-partners__title', 'stamp', 0]
				]],
				['.swiss-cta', [
					['.swiss-cta__icon', 'stamp', 0],
					['.swiss-cta__title', 'stamp', 1],
					['.swiss-cta__text', 'rise', 2],
					['.swiss-cta__btn', 'rise', 3]
				]]
			];

			var STAGGER_CAP = 7; // 7 x 80ms = 560ms for the longest run
			var sections = [];

			groups.forEach(function (group) {
				var root = surface.querySelector(group[0]);
				if (!root) { return; }
				var members = [];

				group[1].forEach(function (row) {
					var nodes = root.querySelectorAll(row[0]);
					Array.prototype.forEach.call(nodes, function (el) {
						el.setAttribute('data-sw-rv', row[1]);
						el.style.setProperty('--sw-rv-i', String( Math.min( row[2], STAGGER_CAP ) ));
						members.push(el);
					});
				});

				if (members.length) { sections.push({ root: root, members: members }); }
			});

			if (!sections.length) { return; }

			// Hidden states only exist from here on, so there is no flash of empty
			// page while the stylesheet loads.
			surface.classList.add('is-motion');

			function reveal(section) {
				if (section.done) { return; }
				section.done = true;
				io.unobserve(section.root);

				section.members.forEach(function (el) {
					el.style.willChange = 'clip-path, opacity, transform';
					el.classList.add('is-in');
				});

				// Drop the compositor hint once the longest run can have finished,
				// so scrolling costs nothing after the entrance.
				setTimeout(function () {
					section.members.forEach(function (el) { el.style.willChange = ''; });
				}, 1400);
			}

			var io = new IntersectionObserver(function (entries) {
				entries.forEach(function (entry) {
					if (!entry.isIntersecting) { return; }
					for (var i = 0; i < sections.length; i++) {
						if (sections[i].root === entry.target) { reveal( sections[i] ); return; }
					}
				});
			}, { threshold: 0.1 });

			sections.forEach(function (s) { io.observe(s.root); });

			// Safety net: a hidden state must never survive being on screen. The
			// observer's threshold can be missed by a short last section, and a
			// visitor who stops at the page bottom would be left with covered type.
			var sweeping = false;
			function sweep() {
				sweeping = false;
				var h = window.innerHeight || document.documentElement.clientHeight;
				var pending = 0;
				sections.forEach(function (s) {
					if (s.done) { return; }
					var r = s.root.getBoundingClientRect();
					if (r.top < h - 4 && r.bottom > 0) { reveal( s ); return; }
					pending++;
				});
				if (!pending) {
					window.removeEventListener('scroll', queueSweep);
					window.removeEventListener('resize', queueSweep);
				}
			}
			function queueSweep() {
				if (sweeping) { return; }
				sweeping = true;
				window.requestAnimationFrame( sweep );
			}
			window.addEventListener('scroll', queueSweep, { passive: true });
			window.addEventListener('resize', queueSweep);
			queueSweep();
		})();

		// --- Quantity stepper ------------------------------------------------
		// WooCommerce ships a bare number input. The native spinners are two 8px
		// arrows — below any reasonable tap target — so the control gets explicit
		// minus and plus cells. Added here rather than in the template on purpose:
		// with JavaScript off the input keeps its own spinners and nothing is lost.
		(function () {
			var fields = document.querySelectorAll('.quantity > input.qty');
			if (!fields.length) { return; }

			function step(input, delta) {
				var stepAttr = parseFloat(input.getAttribute('step')) || 1;
				var min = input.getAttribute('min');
				var max = input.getAttribute('max');
				var current = parseFloat(input.value);
				if (isNaN(current)) { current = min !== null && min !== '' ? parseFloat(min) : 0; }

				var next = current + delta * stepAttr;
				if (min !== null && min !== '' && next < parseFloat(min)) { next = parseFloat(min); }
				if (max !== null && max !== '' && next > parseFloat(max)) { next = parseFloat(max); }
				if (next === current) { return; }

				// Round off the float noise a fractional step can introduce (0.1 + 0.2).
				input.value = String(Math.round(next * 1000) / 1000);
				// Both events: WooCommerce listens for `change` to enable "update cart",
				// and other listeners (variations, extensions) watch `input`.
				input.dispatchEvent(new Event('input', { bubbles: true }));
				input.dispatchEvent(new Event('change', { bubbles: true }));
				sync(input);
			}

			function sync(input) {
				var wrap = input.parentNode;
				var less = wrap.querySelector('.samswiss-qty-step--less');
				var more = wrap.querySelector('.samswiss-qty-step--more');
				var value = parseFloat(input.value);
				var min = input.getAttribute('min');
				var max = input.getAttribute('max');
				if (less) { less.disabled = ( min !== null && min !== '' && !isNaN(value) && value <= parseFloat(min) ); }
				if (more) { more.disabled = ( max !== null && max !== '' && !isNaN(value) && value >= parseFloat(max) ); }
			}

			Array.prototype.forEach.call(fields, function (input) {
				if (input.readOnly || input.disabled) { return; }
				var wrap = input.parentNode;
				if (!wrap || wrap.classList.contains('has-stepper')) { return; }

				function button(kind, sign, label) {
					var b = document.createElement('button');
					b.type = 'button';
					b.className = 'samswiss-qty-step samswiss-qty-step--' + kind;
					b.setAttribute('aria-label', label);
					b.textContent = sign;
					return b;
				}

				var strings = window.samswiss_ajax && window.samswiss_ajax.strings ? window.samswiss_ajax.strings : {};
				var less = button('less', '\u2212', strings.qty_less || 'Diminuisci la quantità');
				var more = button('more', '+', strings.qty_more || 'Aumenta la quantità');

				less.addEventListener('click', function () { step(input, -1); });
				more.addEventListener('click', function () { step(input, 1); });
				input.addEventListener('input', function () { sync(input); });

				wrap.insertBefore(less, input);
				wrap.appendChild(more);
				wrap.classList.add('has-stepper');
				sync(input);
			});
		})();

		// --- Reveal motion on the INTRO gateway -------------------------------
		// One screen, so one entrance fired on load rather than on scroll.
		(function () {
			var gate = document.querySelector('.samswiss-intro-page');
			if (!gate) { return; }

			var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)');
			if (reduced && reduced.matches) { return; }

			var plan = [
				['.swiss-gate__logo', 'stamp', 0],
				['.swiss-gate__kicker', 'stamp', 0],
				['.swiss-gate__choice', 'stamp', 1],
				['.swiss-gate__foot', 'rise', 0]
			];

			var targets = [];
			plan.forEach(function (row) {
				Array.prototype.forEach.call(gate.querySelectorAll(row[0]), function (el, i) {
					el.setAttribute('data-sw-rv', row[1]);
					if (row[2]) { el.style.setProperty('--sw-rv-i', i + 1); }
					targets.push(el);
				});
			});

			if (!targets.length) { return; }
			gate.classList.add('is-motion');

			requestAnimationFrame(function () {
				requestAnimationFrame(function () {
					targets.forEach(function (el) { el.classList.add('is-in'); });
				});
			});
		})();

		// --- Partner logo slider (lightweight, responsive, autoplay) ---
		document.querySelectorAll('.samswiss-partner-slider').forEach(function (slider) {
			var track = slider.querySelector('.samswiss-partner-track');
			var dotsWrap = slider.querySelector('.samswiss-partner-dots');
			var slides = track ? Array.prototype.slice.call(track.children) : [];
			if (!track || slides.length === 0) { return; }

			function perView() {
				var w = window.innerWidth;
				if (w <= 560) { return 1; }
				if (w <= 900) { return 2; }
				return 4;
			}
			var page = 0;

			function pages() { return Math.max(1, Math.ceil(slides.length / perView())); }

			function render() {
				var pv = perView();
				var maxPage = pages() - 1;
				if (page > maxPage) { page = maxPage; }
				track.style.transform = 'translateX(-' + (page * 100) + '%)';
				if (dotsWrap) {
					dotsWrap.innerHTML = '';
					if (pages() > 1) {
						for (var i = 0; i < pages(); i++) {
							var b = document.createElement('button');
							b.type = 'button';
							if (i === page) { b.className = 'is-active'; }
							(function (idx) { b.addEventListener('click', function () { page = idx; render(); }); })(i);
							dotsWrap.appendChild(b);
						}
					}
				}
			}
			render();
			window.addEventListener('resize', render);

			if (slider.getAttribute('data-autoplay') === '1' && slides.length > perView()) {
				setInterval(function () {
					page = (page + 1) % pages();
					render();
				}, 4000);
			}
		});

		// --- Mobile submenu accordions ---
		document.querySelectorAll('.samswiss-mobile-menu .menu-item-has-children > a').forEach(function (link) {
			link.addEventListener('click', function (e) {
				var sub = link.parentNode.querySelector('.sub-menu, .samswiss-sub-menu');
				if (sub) {
					e.preventDefault();
					link.parentNode.classList.toggle('is-expanded');
				}
			});
		});

		// --- Single Technology Video Showcase ---
		var mainPlayer = document.getElementById('swissTechMainPlayer');
		var playerTitle = document.getElementById('swissTechVideoTitle');
		var playerDesc = document.getElementById('swissTechVideoDesc');
		var videoPills = document.querySelectorAll('.swiss-tech-video-pill');

		if (mainPlayer && videoPills.length > 0) {
			videoPills.forEach(function (pill) {
				pill.addEventListener('click', function () {
					var src = pill.getAttribute('data-video-src');
					var title = pill.getAttribute('data-video-title');
					var desc = pill.getAttribute('data-video-desc');

					videoPills.forEach(function (p) {
						p.classList.remove('is-active');
						p.setAttribute('aria-selected', 'false');
					});

					pill.classList.add('is-active');
					pill.setAttribute('aria-selected', 'true');

					if (src && mainPlayer.src !== src) {
						mainPlayer.src = src;
						mainPlayer.load();
						var playPromise = mainPlayer.play();
						if (playPromise !== undefined) {
							playPromise.catch(function () {
								// Browser autoplay policy might require user to interact with player controls if sound is on.
							});
						}
					}

					if (playerTitle && title) {
						playerTitle.textContent = title;
					}
					if (playerDesc && desc) {
						playerDesc.textContent = desc;
					}
				});
			});
		}

		// --- Hero machine slides crossfade ---
		var heroMedia = document.querySelector('.swiss-hero__media');
		if (heroMedia) {
			var heroSlides = heroMedia.querySelectorAll('.swiss-hero__slide');
			if (heroSlides.length > 1) {
				var currentSlide = 0;
				// Ensure initial state
				for (var s = 0; s < heroSlides.length; s++) {
					if (s === 0) {
						heroSlides[s].classList.add('is-active');
					} else {
						heroSlides[s].classList.remove('is-active');
					}
				}
				setInterval(function () {
					heroSlides[currentSlide].classList.remove('is-active');
					currentSlide = (currentSlide + 1) % heroSlides.length;
					heroSlides[currentSlide].classList.add('is-active');
				}, 3500);
			}
		}
	});
})();


