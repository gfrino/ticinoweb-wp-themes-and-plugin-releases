/* SAM SWISS child theme — shop sidebar interactions and filtering without reloads.
 *
 * Category tree expand/collapse, mobile sidebar toggle, and a partial page swap for
 * every control that used to navigate: the category links, the sorting select and the
 * pagination.
 *
 * The swap fetches the SAME URL the control points at and takes the rendered regions
 * out of the response. It deliberately does not call a custom endpoint: the shop query
 * carries visibility rules, sorting, pagination, WPML language and the catalogue's own
 * ordering, and re-implementing that server-side is how filter systems drift out of
 * agreement with the page they filter. Whatever the server renders for that URL is
 * what the visitor gets — the only thing this file changes is that the browser does
 * not throw the page away to show it.
 *
 * Progressive enhancement throughout: every control keeps its real href or form, so
 * with JavaScript off, or on any failure, the native navigation still happens.
 */
(function () {
	'use strict';

	// The regions replaced on every swap. Order matters only for readability.
	var REGIONS = [
		'.samswiss-shop-header .samswiss-container', // breadcrumb + category title
		'.samswiss-band--figures .samswiss-band__inner', // the live counts
		'.samswiss-shop-sidebar-inner', // current-category state and counts
		'.samswiss-shop-main' // toolbar, product grid, pagination
	];

	var MAIN = '.samswiss-shop-main';
	var pending = null; // AbortController of the in-flight request

	function reduceMotion() {
		return window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
	}

	/* ---------- tree + mobile, delegated so a swap needs no rebinding ---------- */

	document.addEventListener('click', function (e) {
		var toggle = e.target.closest('.samswiss-cat-toggle');
		if (toggle) {
			e.preventDefault();
			var li = toggle.closest('.samswiss-cat-item');
			if (li) { li.classList.toggle('is-open'); }
			return;
		}

		var trigger = e.target.closest('.samswiss-mobile-filter-trigger');
		if (trigger) {
			var sidebar = trigger.closest('.samswiss-shop-sidebar');
			if (sidebar) { sidebar.classList.toggle('is-open'); }
		}
	});

	// Open the branch that holds the current category, after load and after a swap.
	function openCurrentBranch() {
		var current = document.querySelector('.samswiss-cat-item.is-current');
		while (current) {
			current.classList.add('is-open');
			current = current.parentElement ? current.parentElement.closest('.samswiss-cat-item') : null;
		}
	}

	/* ---------- the swap ------------------------------------------------------ */

	function sameShopSurface(url) {
		var here = window.location;
		if (url.origin !== here.origin) { return false; }
		// Only URLs the shop archive itself can render: the shop page, a product
		// category, or the current path with a different query (sorting, paging).
		return /\/(shop|product-category|prodotti)\//.test(url.pathname)
			|| url.pathname === here.pathname;
	}

	function startLoading() {
		var main = document.querySelector(MAIN);
		if (!main) { return; }
		main.setAttribute('aria-busy', 'true');
		main.classList.add('is-filtering');
	}

	function stopLoading() {
		var main = document.querySelector(MAIN);
		if (!main) { return; }
		main.removeAttribute('aria-busy');
		main.classList.remove('is-filtering');
	}

	/**
	 * Stagger the new plates in. The delay is an inline custom property rather than
	 * a class per index: twelve classes for twelve cards is a stylesheet doing
	 * arithmetic it does not need to do.
	 */
	function revealPlates() {
		if (reduceMotion()) { return; }
		var plates = document.querySelectorAll(MAIN + ' ul.products > li.product');
		Array.prototype.forEach.call(plates, function (li, i) {
			li.style.setProperty('--sw-in-delay', Math.min(i, 11) * 40 + 'ms');
			li.classList.add('is-entering');
		});
		// Drop the class once the longest run has finished, so a later hover never
		// competes with an entrance transition.
		window.setTimeout(function () {
			Array.prototype.forEach.call(plates, function (li) {
				li.classList.remove('is-entering');
				li.style.removeProperty('--sw-in-delay');
			});
		}, 900);
	}

	/**
	 * Keep the results in view without yanking the page: only scroll when the top of
	 * the results has left the viewport, and stop just above it.
	 */
	function settleScroll() {
		var anchor = document.querySelector('.samswiss-shop-toolbar') || document.querySelector(MAIN);
		if (!anchor) { return; }
		var top = anchor.getBoundingClientRect().top;
		if (top >= 0) { return; }
		window.scrollTo({
			top: window.pageYOffset + top - 24,
			behavior: reduceMotion() ? 'auto' : 'smooth'
		});
	}

	function swap(url, push) {
		var target;
		try {
			target = new URL(url, window.location.href);
		} catch (err) {
			return false;
		}
		if (!sameShopSurface(target)) { return false; }
		if (!document.querySelector(MAIN)) { return false; }

		if (pending) { pending.abort(); }
		pending = new AbortController();

		startLoading();

		fetch(target.href, {
			credentials: 'same-origin',
			headers: { 'X-Requested-With': 'samswiss-filters' },
			signal: pending.signal
		})
			.then(function (res) {
				if (!res.ok) { throw new Error('HTTP ' + res.status); }
				return res.text();
			})
			.then(function (html) {
				var doc = new DOMParser().parseFromString(html, 'text/html');
				var next = doc.querySelector(MAIN);
				if (!next) { throw new Error('no results region in response'); }

				REGIONS.forEach(function (sel) {
					var here = document.querySelector(sel);
					var there = doc.querySelector(sel);
					if (!here) { return; }
					if (there) {
						here.innerHTML = there.innerHTML;
					} else {
						// The region does not exist for this URL (a category with no
						// figures band, say): empty it rather than leave stale content.
						here.innerHTML = '';
					}
				});

				if (doc.title) { document.title = doc.title; }
				if (push) { window.history.pushState({ samswiss: true }, '', target.href); }

				openCurrentBranch();
				stopLoading();
				revealPlates();
				settleScroll();
				pending = null;
			})
			.catch(function (err) {
				if (err && err.name === 'AbortError') { return; }
				// Never leave the visitor on a dimmed grid: hand the click back to the
				// browser and let it navigate the way it would have without this file.
				stopLoading();
				pending = null;
				window.location.href = target.href;
			});

		return true;
	}

	/* ---------- controls ----------------------------------------------------- */

	// Category links and pagination.
	document.addEventListener('click', function (e) {
		if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) {
			return;
		}
		var link = e.target.closest(
			'.samswiss-shop-sidebar a[href], nav.woocommerce-pagination a[href]'
		);
		if (!link || link.target === '_blank') { return; }

		if (swap(link.getAttribute('href'), true)) {
			e.preventDefault();
			// On a phone the sidebar is an overlay; a chosen category closes it.
			var sidebar = link.closest('.samswiss-shop-sidebar');
			if (sidebar) { sidebar.classList.remove('is-open'); }
		}
	});

	// Sorting. WooCommerce's own script submits this form on change, which fires a
	// real submit event, so one handler covers both paths.
	document.addEventListener('submit', function (e) {
		var form = e.target;
		if (!form.classList || !form.classList.contains('woocommerce-ordering')) { return; }

		var action = form.getAttribute('action') || window.location.href;
		var url;
		try {
			url = new URL(action, window.location.href);
		} catch (err) {
			return;
		}

		new FormData(form).forEach(function (value, key) {
			// `paged` is reset by a new sort: page 7 of the old order is meaningless.
			if ('paged' === key) { return; }
			url.searchParams.set(key, value);
		});
		url.searchParams.delete('paged');

		if (swap(url.href, true)) { e.preventDefault(); }
	}, true);

	// Back and forward must work: the URL is real, so the same swap restores it.
	window.addEventListener('popstate', function (event) {
		if (!event.state || !event.state.samswiss) { return; }
		swap(window.location.href, false);
	});

	document.addEventListener('DOMContentLoaded', function () {
		openCurrentBranch();
		// Mark the first entry so a real navigation can be told from a swap later.
		window.history.replaceState({ samswiss: true }, '', window.location.href);
	});
})();
