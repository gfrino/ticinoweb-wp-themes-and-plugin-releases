/**
 * Bacheca → Volantini: scelta, rimozione e ripristino dell'immagine per ogni
 * pagina e lingua. Il valore va nel campo nascosto della cella; si salva col
 * pulsante "Salva i volantini".
 *   > 0  ID dell'immagine scelta
 *   -1   nascosto
 *   0    volantino originale del tema (se esiste)
 */
( function ( $ ) {
	'use strict';

	function show( $cell, value, url, state ) {
		$cell.find( '.samswiss-flyer-value' ).val( value );
		var $img = $cell.find( '.samswiss-flyer-preview img' );
		if ( url ) {
			$img.attr( 'src', url ).show();
			$cell.find( '.samswiss-flyer-empty' ).hide();
		} else {
			$img.attr( 'src', '' ).hide();
			$cell.find( '.samswiss-flyer-empty' ).show();
		}
		$cell.find( '.samswiss-flyer-state' ).text( state || '' );
	}

	$( document ).on( 'click', '.samswiss-flyer-pick', function ( e ) {
		e.preventDefault();
		var $cell = $( this ).closest( '.samswiss-flyer-cell' );
		var frame = wp.media( {
			title: samswissFlyers.title,
			button: { text: samswissFlyers.button },
			library: { type: 'image' },
			multiple: false
		} );
		frame.on( 'select', function () {
			var att = frame.state().get( 'selection' ).first().toJSON();
			var url = att.sizes && att.sizes.medium ? att.sizes.medium.url : att.url;
			show( $cell, att.id, url, samswissFlyers.chosen );
		} );
		frame.open();
	} );

	$( document ).on( 'click', '.samswiss-flyer-remove', function ( e ) {
		e.preventDefault();
		show( $( this ).closest( '.samswiss-flyer-cell' ), -1, '', samswissFlyers.removed );
	} );

	$( document ).on( 'click', '.samswiss-flyer-reset', function ( e ) {
		e.preventDefault();
		var $cell = $( this ).closest( '.samswiss-flyer-cell' );
		show( $cell, 0, $cell.data( 'original' ), samswissFlyers.original );
	} );
}( jQuery ) );
