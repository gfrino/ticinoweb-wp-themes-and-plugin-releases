<?php
/**
 * Repair an invalid WooCommerce product permalink structure.
 *
 * THE BUG, measured on the live server (samswiss.com) on 2026-07-30:
 *
 *   /product-category/imballaggi-e-monouso-categoria/   -> 301 to the home page
 *   /prodotto/<...>/foglio-antigrasso-.../              -> 301 to /%product-category%/...
 *   /%product-category%/box-hamburger/                  -> 403
 *
 * `%product-category%` is not a WooCommerce rewrite tag. The valid one is
 * `%product_cat%`. The migration wrote the invalid string into
 * `woocommerce_permalinks['product_base']`, and WooCommerce then registers its
 * product rules around a tag that resolves to nothing: product URLs carry the
 * literal `%product-category%` and the product_cat archives never get a working
 * rule at all. A request for a category archive therefore 404s, and this install's
 * parent theme answers every 404 with a 301 to the home page — which on this site
 * is the INTRO gateway. That is the whole chain behind "Imballaggi e monouso and
 * Ingredienti send me back to Intro".
 *
 * WHY THE THEME REPAIRS IT. The value is not a preference someone chose, it is a
 * string WooCommerce cannot parse — no setting screen can produce it. Leaving it in
 * place means the shop stays unreachable until somebody opens Settings by hand on
 * every environment the database is copied to. The old value is backed up first, so
 * the change is reversible.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** The structure this catalogue is built for: prefix + the real category tag. */
const SAMSWISS_PRODUCT_BASE   = '/prodotto/%product_cat%';
const SAMSWISS_CATEGORY_BASE  = 'product-category';

/**
 * Check the option, repair it when it is invalid, flush once.
 */
function samswiss_guard_product_permalinks() {
	if ( ! function_exists( 'WC' ) || wp_doing_ajax() || wp_doing_cron() ) {
		return;
	}

	$perma = get_option( 'woocommerce_permalinks', array() );
	if ( ! is_array( $perma ) ) {
		$perma = array();
	}

	$base    = isset( $perma['product_base'] ) ? (string) $perma['product_base'] : '';
	$changed = array();

	// Any %tag% other than %product_cat% is one WooCommerce does not know. The
	// migration left `%product-category%`; catching the general case means a future
	// bad import is repaired too instead of producing the same week of debugging.
	preg_match_all( '/%[^%]+%/', $base, $tags );
	$unknown = array_diff( $tags[0], array( '%product_cat%' ) );

	if ( $unknown ) {
		$perma['product_base'] = SAMSWISS_PRODUCT_BASE;
		$changed[]             = sprintf( 'product_base "%s" -> "%s" (tag non valido: %s)', $base, SAMSWISS_PRODUCT_BASE, implode( ', ', $unknown ) );
	}

	// A product with no prefix at all steals every page URL: WordPress matches the
	// product rule first and ordinary pages fall through to the gateway.
	if ( ! $unknown && '%product_cat%' === trim( $base, '/' ) ) {
		$perma['product_base'] = SAMSWISS_PRODUCT_BASE;
		$changed[]             = 'product_base senza prefisso -> ' . SAMSWISS_PRODUCT_BASE;
	}

	if ( empty( $perma['category_base'] ) ) {
		$perma['category_base'] = SAMSWISS_CATEGORY_BASE;
		$changed[]              = 'category_base vuoto -> ' . SAMSWISS_CATEGORY_BASE;
	}

	if ( ! $changed ) {
		return;
	}

	// Keep the original exactly once, so the change can be undone by hand.
	if ( false === get_option( 'samswiss_permalinks_backup' ) ) {
		add_option( 'samswiss_permalinks_backup', get_option( 'woocommerce_permalinks', array() ), '', false );
	}

	update_option( 'woocommerce_permalinks', $perma );

	// NOT flush_rewrite_rules() here. WooCommerce registers `product` and
	// `product_cat` at `init`, reading this option — which at that point still held
	// the broken value. Regenerating the rules now rebuilds them from those stale
	// registrations, so they come out just as wrong, and the site keeps 404ing while
	// the option looks correct. That is precisely what happened on the live server:
	// the option was repaired, the rules were not, and pages worked while products
	// and categories did not.
	//
	// So the flush is deferred to the NEXT request, when `init` will register both
	// with the corrected base. samswiss_ensure_rewrite_rules() does it, and verifies
	// the result instead of assuming it.
	update_option( 'samswiss_rewrite_pending', 1, false );
	samswiss_purge_page_cache( 'struttura dei permalink corretta' );

	error_log( 'samswiss: struttura permalink prodotto riparata — ' . implode( ' | ', $changed ) . ' — flush rimandato alla prossima richiesta' );
}
add_action( 'wp_loaded', 'samswiss_guard_product_permalinks', 95 );

/**
 * Drop the page cache after the routing has been changed.
 *
 * On the live server LiteSpeed had stored the 404 these URLs used to return —
 * measured, the response carried `x-litespeed-tag: HTTP.404`. A cached 404 outlives
 * the repair that fixes it, so every correct deploy would still look broken until
 * somebody purged by hand. Purging is therefore part of the repair, not an
 * afterthought, and it only runs on the request that actually changed something.
 *
 * `litespeed_purge_all` is LiteSpeed's own public action; when the plugin is absent
 * nothing is registered and this is a no-op.
 *
 * @param string $why Short reason, for the log.
 */
function samswiss_purge_page_cache( $why ) {
	if ( has_action( 'litespeed_purge_all' ) ) {
		do_action( 'litespeed_purge_all' );
		error_log( 'samswiss: cache delle pagine svuotata (' . $why . ')' );
	}
}

/**
 * Make sure the rules on disk actually contain the product and category routes.
 *
 * This checks the outcome rather than trusting that a flush worked: it looks for a
 * rule whose pattern starts with the category base and one for the product prefix,
 * and only flushes when they are missing. Bounded to a few attempts per theme
 * version, because flush_rewrite_rules() is expensive and a permanent failure must
 * not turn into a flush on every page load.
 */
function samswiss_ensure_rewrite_rules() {
	if ( ! function_exists( 'WC' ) || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
		return;
	}
	if ( ! get_option( 'permalink_structure' ) ) {
		return; // Plain permalinks: there are no pretty rules to build.
	}

	$perma    = (array) get_option( 'woocommerce_permalinks', array() );
	$cat_base = ! empty( $perma['category_base'] ) ? trim( (string) $perma['category_base'], '/' ) : SAMSWISS_CATEGORY_BASE;
	$prod_pre = trim( (string) preg_replace( '/%[^%]+%/', '', $perma['product_base'] ?? '' ), '/' );

	$rules   = (array) get_option( 'rewrite_rules', array() );
	$has_cat = false;
	$has_prod = ( '' === $prod_pre );
	foreach ( array_keys( $rules ) as $pattern ) {
		if ( ! $has_cat && 0 === strpos( $pattern, $cat_base . '/' ) ) {
			$has_cat = true;
		}
		if ( ! $has_prod && 0 === strpos( $pattern, $prod_pre . '/' ) ) {
			$has_prod = true;
		}
		if ( $has_cat && $has_prod ) {
			break;
		}
	}

	$pending = (bool) get_option( 'samswiss_rewrite_pending' );

	if ( $has_cat && $has_prod && ! $pending ) {
		delete_option( 'samswiss_rewrite_attempts' );
		return;
	}

	$attempts = (int) get_option( 'samswiss_rewrite_attempts', 0 );
	if ( $attempts >= 3 ) {
		return; // Something else is wrong; stop paying for flushes.
	}

	flush_rewrite_rules( false );
	update_option( 'samswiss_rewrite_attempts', $attempts + 1, false );
	delete_option( 'samswiss_rewrite_pending' );
	samswiss_purge_page_cache( 'regole di riscrittura rigenerate' );

	error_log( sprintf(
		'samswiss: regole di riscrittura rigenerate (tentativo %d) — categoria "%s" presente prima: %s, prodotto "%s" presente prima: %s',
		$attempts + 1,
		$cat_base,
		$has_cat ? 'si' : 'no',
		$prod_pre,
		$has_prod ? 'si' : 'no'
	) );
}
add_action( 'wp_loaded', 'samswiss_ensure_rewrite_rules', 5 );

/**
 * Send the localised base to the configured one.
 *
 * When `category_base` is empty WooCommerce falls back to its own translated slug:
 * on an Italian install that is `categoria-prodotto`, not `product-category`. That
 * is why the same catalogue answered on two different URLs — measured on the live
 * server:
 *
 *   /categoria-prodotto/imballaggi-e-monouso-categoria/  -> 200
 *   /product-category/imballaggi-e-monouso-categoria/    -> 404 (then 301 to home)
 *
 * The base is now pinned in the option so both environments build the same URLs.
 * Anything already linked or indexed under the translated base must not break, so it
 * is redirected here instead of 404ing — at priority 1, because the parent theme
 * turns a 404 into a redirect to the home page at the default priority and would
 * swallow it first.
 */
function samswiss_redirect_legacy_category_base() {
	if ( is_admin() || ! function_exists( 'WC' ) ) {
		return;
	}

	$configured = trim( (string) ( get_option( 'woocommerce_permalinks', array() )['category_base'] ?? '' ), '/' );
	if ( '' === $configured ) {
		return;
	}

	// WooCommerce's own default, translated in the active locale.
	$localised = trim( _x( 'product-category', 'slug', 'woocommerce' ), '/' );
	if ( '' === $localised || $localised === $configured ) {
		return;
	}

	$path  = trim( (string) wp_parse_url( add_query_arg( array() ), PHP_URL_PATH ), '/' );
	$home  = trim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
	if ( '' !== $home && 0 === strpos( $path, $home . '/' ) ) {
		$path = substr( $path, strlen( $home ) + 1 );
	}

	$parts = array_values( array_filter( explode( '/', $path ) ) );
	if ( count( $parts ) < 2 || $parts[0] !== $localised ) {
		return;
	}

	// The last segment is the term; the ones between are its ancestors.
	$term = get_term_by( 'slug', sanitize_title( end( $parts ) ), 'product_cat' );
	if ( ! $term || is_wp_error( $term ) ) {
		return;
	}

	$link = get_term_link( $term );
	if ( is_wp_error( $link ) ) {
		return;
	}

	wp_safe_redirect( $link, 301 );
	exit;
}
add_action( 'template_redirect', 'samswiss_redirect_legacy_category_base', 1 );

/**
 * Resolve a product-category request without relying on the rewrite rules.
 *
 * Measured on the live server, at version 1.4.0, with the option already repaired
 * and the deferred flush in place:
 *
 *   /categoria-prodotto/imballaggi-e-monouso-categoria/ -> 301 to the URL below (my
 *                                                          redirect works)
 *   /product-category/imballaggi-e-monouso-categoria/   -> still 404
 *
 * So the rules on that install still do not contain the configured base, and no
 * amount of flushing from the theme has changed it — something else there owns the
 * taxonomy registration (WPML translates taxonomy slugs per language, which is the
 * likeliest owner on an eight-language site).
 *
 * Rather than keep fighting the rules table, this resolves the request at the point
 * WordPress decides what was asked for. `parse_request` runs before the 404 is
 * declared, so setting `product_cat` here does exactly what a matching rewrite rule
 * would have done: the archive renders, with its pagination, on any install and
 * whatever state the rules are in. Nothing is hidden and nothing is redirected — the
 * URL the visitor asked for is the URL that answers.
 *
 * @param WP $wp Current request.
 * @return void
 */
function samswiss_resolve_category_request( $wp ) {
	if ( is_admin() || ! function_exists( 'WC' ) ) {
		return;
	}

	// Already resolved by a rewrite rule: leave it alone.
	if ( ! empty( $wp->query_vars['product_cat'] ) ) {
		return;
	}

	$configured = trim( (string) ( get_option( 'woocommerce_permalinks', array() )['category_base'] ?? '' ), '/' );
	if ( '' === $configured ) {
		return;
	}

	$path = trim( (string) ( $wp->request ?? '' ), '/' );
	if ( '' === $path || 0 !== strpos( $path, $configured . '/' ) ) {
		return;
	}

	$parts = array_values( array_filter( explode( '/', substr( $path, strlen( $configured ) + 1 ) ) ) );
	if ( ! $parts ) {
		return;
	}

	// Trailing /page/N/ belongs to the query, not to the term path.
	$paged = 0;
	$count = count( $parts );
	if ( $count >= 2 && 'page' === $parts[ $count - 2 ] && ctype_digit( (string) $parts[ $count - 1 ] ) ) {
		$paged = (int) $parts[ $count - 1 ];
		array_splice( $parts, -2 );
	}
	if ( ! $parts ) {
		return;
	}

	$slug = sanitize_title( end( $parts ) );
	$term = get_term_by( 'slug', $slug, 'product_cat' );
	if ( ! $term || is_wp_error( $term ) ) {
		return; // Not a category after all: let WordPress answer as it would.
	}

	// Rebuild the query vars instead of patching them. WordPress had already tried
	// this path against other rules and left its attempts behind — measured on this
	// very request: `category_name = "product-category"` and `name = "imballaggi-…"`.
	// With those still in place the query asks for a blog category AND a product
	// category at once, finds nothing, and answers 404 even though `product_cat` was
	// set correctly. Only the vars that legitimately survive a taxonomy request are
	// carried over.
	$keep = array_intersect_key(
		$wp->query_vars,
		array_flip( array( 'lang', 'orderby', 'order', 'preview', 'post_type' ) )
	);

	$wp->query_vars = array_merge(
		$keep,
		array(
			'product_cat' => $term->slug,
			'taxonomy'    => 'product_cat',
			'term'        => $term->slug,
		)
	);

	if ( $paged > 1 ) {
		$wp->query_vars['paged'] = $paged;
	}

	$wp->matched_rule  = '';
	$wp->matched_query = '';
}
add_action( 'parse_request', 'samswiss_resolve_category_request', 20 );

/**
 * Resolve a product whose slug is a number.
 *
 * **The failure.** "CATALOGO INGREDIENTI" (#25682) carries the slug `25682`, and its own
 * permalink — the one WordPress generates and prints in every listing — cannot be read
 * back. The product rule ends with an optional numeric group for `<!--nextpage-->`
 * pagination:
 *
 *     prodotto/(.+?)/([^/]+)(?:/([0-9]+))?/?$
 *
 * so for `/prodotto/<cat>/dolciario-babbi/25682/` the engine takes `dolciario-babbi` as
 * the product and `25682` as the page number. `dolciario-babbi` is a category, no product
 * matches, and the request 404s — which the parent theme turns into a redirect to the
 * home page. Measured, not inferred: the matching rule and the resulting query vars were
 * read straight out of the rewrite table. It fails on every install, local included.
 *
 * WordPress avoids purely numeric slugs on its own for exactly this reason
 * (`wp_unique_post_slug()` appends a suffix); these two came in with the migration.
 *
 * **The repair.** When the engine reports a product that does not exist and a page number
 * that does, believe the number. Nothing else is touched, and a product with a real slug
 * never reaches the lookup.
 *
 * The durable fix is a slug that is not a number, on two products. After that this code
 * simply stops finding anything to do.
 *
 * @param WP $wp Current request.
 * @return void
 */
function samswiss_resolve_numeric_product_slug( $wp ) {
	if ( is_admin() || ! function_exists( 'WC' ) ) {
		return;
	}

	$slug = isset( $wp->query_vars['product'] ) ? (string) $wp->query_vars['product'] : '';
	$page = isset( $wp->query_vars['page'] ) ? (string) $wp->query_vars['page'] : '';

	if ( '' === $slug || '' === $page || ! ctype_digit( $page ) ) {
		return;
	}

	// A real product at the reported slug means the URL is ordinary pagination.
	if ( get_page_by_path( $slug, OBJECT, 'product' ) ) {
		return;
	}

	$product = get_page_by_path( $page, OBJECT, 'product' );
	if ( ! $product ) {
		return;
	}

	$wp->query_vars['product'] = $product->post_name;
	$wp->query_vars['name']    = $product->post_name;
	unset( $wp->query_vars['page'] );

	// And the category, or the page bounces. The rule that mis-parsed the address also
	// truncated `product_cat`: it captured only `ingredienti-…-categoria`, because
	// `dolciario-babbi` had been eaten as the product name. WooCommerce's own
	// wc_product_canonical_redirect() then compares the requested category path with
	// the one the product actually has, finds them different, and redirects to the
	// permalink — which is the address already being requested. Measured: a 301 to
	// itself, forever. Asking WooCommerce for the expected value is what keeps the two
	// in agreement, whatever filters a site has on its product links.
	if ( function_exists( 'wc_product_post_type_link' ) ) {
		$expected = wc_product_post_type_link( '%product_cat%', $product );
		if ( is_string( $expected ) && '' !== $expected ) {
			$wp->query_vars['product_cat'] = $expected;
		}
	}
}
add_action( 'parse_request', 'samswiss_resolve_numeric_product_slug', 20 );
