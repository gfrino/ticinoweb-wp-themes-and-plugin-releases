<?php
/**
 * Content definitions for theme auto-seeder (News and Second Hand).
 *
 * Provides complete structured data for editorial and machine articles so
 * that any target WordPress installation receives all posts, images, and
 * videos automatically upon theme activation or update.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	// =========================================================================
	// 1. NEWS & EDITORIAL ARTICLES (post_type: 'articolo-seo')
	// =========================================================================
	array(
		'title'       => 'SAM a Fruit Attraction 2026!',
		'slug'        => 'sam-a-fruit-attraction-2026',
		'post_type'   => 'articolo-seo',
		'date'        => '2026-09-01 12:00:00',
		'categories'  => array(),
		'tags'        => array(),
		'image_asset' => 'assets/img/news/fruit-attraction-sam-sa.jpeg',
		'image_name'  => 'fruit-attraction-sam-sa.jpeg',
		'content'     => '<!-- wp:paragraph -->
<p>Anche quest’anno <strong>SAM</strong> sarà presente a <strong>Fruit Attraction</strong>, uno degli appuntamenti internazionali più importanti dedicati al settore ortofrutticolo.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>L’evento rappresenta per noi un’occasione preziosa per incontrare clienti, partner e nuovi professionisti del settore, confrontarci sulle esigenze del mercato e presentare le nostre soluzioni per il confezionamento, la pesatura e l’etichettatura dei prodotti ortofrutticoli.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>La nostra <strong>Rafaela</strong> sarà presente in fiera e sarà felice di accogliervi, conoscervi personalmente e parlare insieme dei vostri progetti e delle vostre esigenze produttive.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Che si tratti di migliorare un processo già esistente, sviluppare una nuova linea o individuare una soluzione di confezionamento più efficiente, sarà un piacere confrontarsi direttamente e valutare insieme le possibilità più adatte alla vostra realtà.</p>
<!-- /wp:paragraph -->

<!-- wp:separator -->
<hr class="wp-block-separator has-alpha-channel-opacity"/>
<!-- /wp:separator -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Sarete anche voi a Fruit Attraction?</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Contattate Rafaela per fissare un incontro durante i giorni della fiera:</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list">
<!-- wp:list-item -->
<li>📞 <strong>Telefono / WhatsApp:</strong> <a href="tel:+41765942582">+41 76 594 25 82</a></li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>📍 <strong>Luogo:</strong> Fruit Attraction – Madrid</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>📅 <strong>Date:</strong> 6–8 ottobre 2026</li>
<!-- /wp:list-item -->
</ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p><strong>Vi aspettiamo a Madrid!</strong></p>
<!-- /wp:paragraph -->

<!-- wp:spacer {"height":"20px"} -->
<div style="height:20px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons">
<!-- wp:button {"textColor":"vivid-red","className":"is-style-outline","style":{"elements":{"link":{"color":{"text":"var:preset|color|vivid-red"}}}}} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link has-vivid-red-color has-text-color has-link-color wp-element-button" href="tel:+41765942582">Contatta Rafaela (+41 76 594 25 82)</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->',
	),
	array(
		'title'       => 'SAM a Macfrut 2026: innovazione, partnership e nuove opportunità nel mondo del packaging',
		'slug'        => 'sam-a-macfrut-2026-innovazione-partnership-e-nuove-opportunita-nel-mondo-del-packaging',
		'post_type'   => 'articolo-seo',
		'date'        => '2026-08-28 10:00:00',
		'categories'  => array(),
		'tags'        => array(),
		'image_asset' => 'assets/img/news/sam-a-macfrut-2026.jpeg',
		'image_name'  => 'sam-a-macfrut-2026.jpeg',
		'content'     => '<!-- wp:paragraph -->
<p>Anche quest’anno <strong>SAM</strong> ha partecipato con entusiasmo a <strong>Macfrut</strong>, uno degli appuntamenti internazionali più importanti dedicati al settore ortofrutticolo e alle tecnologie per la filiera agroalimentare.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Per noi è stata un’occasione preziosa per incontrare partner, clienti e professionisti del settore, confrontarci sulle nuove esigenze del mercato e scoprire le soluzioni più innovative nel mondo del confezionamento.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Un ringraziamento speciale va a <strong>Sorma Group</strong> per la calorosa accoglienza e l’ospitalità presso il loro stand. Collaborare con un partner di riferimento come Sorma significa poter offrire ai nostri clienti tecnologie affidabili, moderne e orientate al futuro.</p>
<!-- /wp:paragraph -->

<!-- wp:separator -->
<hr class="wp-block-separator has-alpha-channel-opacity"/>
<!-- /wp:separator -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Le soluzioni Sorma Group per l’ortofrutta</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Durante la fiera abbiamo avuto modo di approfondire le numerose soluzioni proposte da Sorma Group, leader internazionale nel packaging ortofrutticolo:</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list">
<!-- wp:list-item -->
<li><strong>Confezionatrici automatiche</strong> per reti, flowpack, carta e materiali sostenibili</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><strong>Retinatrici performanti</strong> per diverse tipologie di prodotto</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><strong>Packaging ecosostenibile</strong>, con linee mono-materiale, compostabili e in carta</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><strong>Etichette, film e materiali complementari</strong> personalizzabili</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><strong>Sistemi progettati per garantire efficienza</strong>, qualità e valorizzazione del prodotto</li>
<!-- /wp:list-item -->
</ul>
<!-- /wp:list -->

<!-- wp:separator -->
<hr class="wp-block-separator has-alpha-channel-opacity"/>
<!-- /wp:separator -->

<!-- wp:paragraph -->
<p>L’attenzione alla sostenibilità è oggi centrale, e vedere soluzioni concrete già pronte per il mercato conferma quanto il settore stia evolvendo rapidamente verso imballaggi sempre più responsabili.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Come <strong>SAM</strong>, continuiamo a investire in partnership solide e tecnologie d’eccellenza per portare in Svizzera il meglio del packaging professionale.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Grazie ancora a Sorma Group e a tutti coloro che ci hanno incontrato durante Macfrut.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Il futuro del confezionamento passa dall’innovazione. E noi vogliamo esserci.</strong></p>
<!-- /wp:paragraph -->

<!-- wp:spacer {"height":"20px"} -->
<div style="height:20px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons">
<!-- wp:button {"textColor":"vivid-red","className":"is-style-outline","style":{"elements":{"link":{"color":{"text":"var:preset|color|vivid-red"}}}}} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link has-vivid-red-color has-text-color has-link-color wp-element-button" href="{{SITE_URL}}/contatti/">Contattaci per informazioni</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->',
	),
	array(
		'title'       => 'SAM: Partner Ufficiale di Sorma Group in Svizzera – Soluzioni di macchine e assistenza tecnica su tutto il territorio',
		'slug'        => 'sam-partner-ufficiale-di-sorma-group-in-svizzera-soluzioni-di-macchine-e-assistenza-tecnica-su-tutto-il-territorio',
		'post_type'   => 'articolo-seo',
		'date'        => '2026-08-25 10:00:00',
		'categories'  => array(),
		'tags'        => array( 'sorma-group' ),
		'image_asset' => 'assets/img/news/sam-sorma-partner-ufficiale.jpeg',
		'image_name'  => 'sam-sorma-partner-ufficiale.jpeg',
		'content'     => '<!-- wp:paragraph -->
<p>Siamo orgogliosi di annunciare che <strong>SAM</strong> è <strong>partner ufficiale di Sorma Group in Svizzera</strong>, portando l’eccellenza delle tecnologie di confezionamento e automazione nel cuore dell’industria ortofrutticola svizzera. Grazie a questa partnership strategica, offriamo macchine d’avanguardia, soluzioni complete e supporto tecnico specializzato per soddisfare le esigenze di produttori, confezionatori e distributori in ogni regione del nostro paese.</p>
<!-- /wp:paragraph -->

<!-- wp:separator -->
<hr class="wp-block-separator has-alpha-channel-opacity"/>
<!-- /wp:separator -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Chi è Sorma Group</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><strong>Sorma Group</strong> è una multinazionale leader nella progettazione e costruzione di macchine automatizzate per il post-raccolta di frutta e verdura, con oltre 50 anni di esperienza nel settore e una reputazione di innovazione, affidabilità e competenza tecnica. Dalla sua fondazione nel 1973, il gruppo ha sviluppato una gamma completa di soluzioni per la selezione, pesatura, confezionamento e packaging dei prodotti ortofrutticoli.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Sorma è riconosciuta a livello internazionale per:</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list">
<!-- wp:list-item -->
<li><strong>Linee complete “chiavi in mano”</strong> per il processo di post-raccolta, dalla calibrazione alla pallettizzazione.</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><strong>Oltre 200 modelli</strong> di macchine automatizzate e più di 60 brevetti proprietari.</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><strong>Soluzioni di packaging tecnico integrate</strong>, con materiali per tutte le esigenze di confezionamento.</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><strong>Presenza globale</strong> con sedi e distributori in Europa, America, Asia e oltre 40 mercati nel mondo.</li>
<!-- /wp:list-item -->
</ul>
<!-- /wp:list -->

<!-- wp:separator -->
<hr class="wp-block-separator has-alpha-channel-opacity"/>
<!-- /wp:separator -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Cosa significa per la Svizzera la partnership con SAM</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>In qualità di partner ufficiale di Sorma Group in Svizzera, SAM è il riferimento per tutte le aziende che desiderano innovare i propri processi produttivi con tecnologie di selezione e confezionamento di ultima generazione.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>👉 <strong>Offriamo soluzioni complete per:</strong></p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list">
<!-- wp:list-item -->
<li><strong>Macchine automatiche di confezionamento e imballaggio</strong>, studiate per aumentare l’efficienza produttiva.</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><strong>Sistemi di calibrazione e pesatura di precisione</strong>, per garantire qualità costante.</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><strong>Materiali tecnici per il packaging</strong>, adatti ad ogni formato commerciale.</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><strong>Automazione e integrazione</strong> con sistemi di tracciabilità e controllo di processo.</li>
<!-- /wp:list-item -->
</ul>
<!-- /wp:list -->

<!-- wp:separator -->
<hr class="wp-block-separator has-alpha-channel-opacity"/>
<!-- /wp:separator -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Assistenza tecnica dedicata e supporto sul territorio</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Uno dei grandi vantaggi della nostra attività in Svizzera è la copertura completa dell’assistenza pre e post vendita:</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list">
<!-- wp:list-item -->
<li><strong>Supporto tecnico specialistico</strong> direttamente dai nostri tecnici sul campo.</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><strong>Consulenza personalizzata</strong> per configurare la soluzione più adatta alla tua produzione.</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><strong>Servizio rapido di manutenzione e ricambi</strong>, per ridurre i tempi di fermo macchina.</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><strong>Formazione operatori e messa in funzione</strong>, per un utilizzo sicuro ed efficiente.</li>
<!-- /wp:list-item -->
</ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p>La presenza locale di SAM garantisce una risposta tempestiva e competente, con una rete di tecnici altamente qualificati pronta a intervenire in tutto il territorio svizzero.</p>
<!-- /wp:paragraph -->

<!-- wp:separator -->
<hr class="wp-block-separator has-alpha-channel-opacity"/>
<!-- /wp:separator -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Perché scegliere SAM e Sorma Group</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Questa partnership unisce due realtà orientate all’eccellenza e all’innovazione:</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list">
<!-- wp:list-item -->
<li><strong>Sorma Group</strong>, con la sua esperienza di decenni nella progettazione e produzione di tecnologie per il mercato ortofrutticolo.</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><strong>SAM</strong>, con la sua profonda conoscenza del mercato svizzero e un impegno costante verso l’assistenza di primo livello.</li>
<!-- /wp:list-item -->
</ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p>Insieme, forniamo soluzioni che non sono solo macchine, ma vere e proprie risposte alle sfide di efficienza, qualità e sostenibilità della tua azienda.</p>
<!-- /wp:paragraph -->

<!-- wp:separator -->
<hr class="wp-block-separator has-alpha-channel-opacity"/>
<!-- /wp:separator -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Contattaci</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Se vuoi scoprire come le soluzioni Sorma possono trasformare la tua produzione o se desideri un preventivo personalizzato, contatta il team SAM oggi stesso: forniremo supporto completo, dalla prima consulenza alla messa in opera delle macchine.</p>
<!-- /wp:paragraph -->

<!-- wp:spacer {"height":"20px"} -->
<div style="height:20px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons">
<!-- wp:button {"textColor":"vivid-red","className":"is-style-outline","style":{"elements":{"link":{"color":{"text":"var:preset|color|vivid-red"}}}}} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link has-vivid-red-color has-text-color has-link-color wp-element-button" href="{{SITE_URL}}/contatti/">Richiedi una consulenza SAM</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->',
	),
	array(
		'title'       => 'Prima installazione del peso combinato Bulltec in Svizzera',
		'slug'        => 'prima-installazione-peso-combinato-bulltec-svizzera',
		'post_type'   => 'articolo-seo',
		'date'        => '2026-08-20 10:00:00',
		'categories'  => array(),
		'tags'        => array(),
		'image_asset' => 'assets/img/news/bulltec-salmsach-installazione.jpeg',
		'image_name'  => 'bulltec-salmsach-installazione.jpeg',
		'video_asset' => 'assets/video/news/bulltec-jonas-salmsach.mp4',
		'video_name'  => 'bulltec-jonas-salmsach.mp4',
		'content'     => '<!-- wp:paragraph -->
<p><strong>SAM Swiss SA</strong> amplia la propria gamma di soluzioni dedicate all’automazione con la <strong>prima installazione di un peso combinato Bulltec in Svizzera</strong>, presso un nostro cliente a Salmsach.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Un progetto importante che ci permette di offrire una soluzione concreta alle aziende che desiderano rendere più efficienti e precisi i propri processi di pesatura e confezionamento.</p>
<!-- /wp:paragraph -->

<!-- wp:separator -->
<hr class="wp-block-separator has-alpha-channel-opacity"/>
<!-- /wp:separator -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Precisione, velocità e meno prodotto in eccesso</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Il peso combinato <strong>Bulltec</strong> permette di gestire il prodotto sfuso e raggiungere automaticamente il peso desiderato attraverso la combinazione ottimale delle diverse porzioni.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Questo consente di ottenere una pesatura precisa e costante, riducendo il <strong>giveaway</strong> di prodotto e rendendo il processo più rapido ed efficiente.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Tra i principali vantaggi:</strong></p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list">
<!-- wp:list-item -->
<li>Elevata precisione di pesatura;</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Riduzione degli scarti e del prodotto in eccesso;</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Maggiore continuità produttiva;</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Riduzione delle operazioni manuali;</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Possibilità di gestire differenti prodotti e formati;</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Integrazione con le successive fasi di confezionamento.</li>
<!-- /wp:list-item -->
</ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p>Il prodotto pesato può essere successivamente destinato a vaschette, cassette o altre tipologie di confezione, permettendo di realizzare soluzioni personalizzate in base alle esigenze produttive.</p>
<!-- /wp:paragraph -->

<!-- wp:separator -->
<hr class="wp-block-separator has-alpha-channel-opacity"/>
<!-- /wp:separator -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Un progetto realizzato insieme al cliente</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Per noi ogni installazione nasce dall’ascolto delle reali necessità produttive.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Dopo aver analizzato il prodotto, i pesi richiesti e il processo di lavorazione, abbiamo individuato nel peso combinato Bulltec la soluzione più adatta per il nostro cliente di Salmsach.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>L’impianto è stato installato e messo in funzione con successo e, soprattutto, il risultato ha pienamente soddisfatto il cliente.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Dopo l’installazione del peso combinato Bulltec presso il cliente di Salmsach, Jonas ha voluto condividere direttamente con noi il risultato ottenuto, realizzando un video della macchina durante la produzione reale.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Un gesto che apprezziamo particolarmente, perché mostra in modo concreto il sistema al lavoro e l’efficienza raggiunta nella quotidianità produttiva.</p>
<!-- /wp:paragraph -->

<!-- wp:video {"controls":true,"preload":"metadata"} -->
<figure class="wp-block-video"><video controls poster="{{POSTER_URL}}" preload="metadata" src="{{VIDEO_URL}}"></video><figcaption class="wp-element-caption">Produzione reale del peso combinato Bulltec a Salmsach (video condiviso da Jonas)</figcaption></figure>
<!-- /wp:video -->

<!-- wp:paragraph -->
<p>Per noi è proprio questo il risultato più importante: non semplicemente fornire una macchina, ma trovare una soluzione che porti un beneficio concreto nella produzione quotidiana del cliente.</p>
<!-- /wp:paragraph -->

<!-- wp:separator -->
<hr class="wp-block-separator has-alpha-channel-opacity"/>
<!-- /wp:separator -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">State valutando di automatizzare la pesatura dei vostri prodotti?</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Contattate SAM Swiss SA. Studieremo insieme il vostro prodotto, i formati e le esigenze produttive per individuare la soluzione più adatta.</p>
<!-- /wp:paragraph -->

<!-- wp:spacer {"height":"20px"} -->
<div style="height:20px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons">
<!-- wp:button {"textColor":"vivid-red","className":"is-style-outline","style":{"elements":{"link":{"color":{"text":"var:preset|color|vivid-red"}}}}} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link has-vivid-red-color has-text-color has-link-color wp-element-button" href="{{SITE_URL}}/contatti/">Contattaci per una consulenza</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->',
	),

	// =========================================================================
	// 2. SECOND HAND / OCCASIONI ARTICLES (post_type: 'post')
	// =========================================================================
	array(
		'title'       => 'Confezionatrice automatica stretch d’occasione',
		'slug'        => 'confezionatrice-automatica-stretch-doccasione',
		'post_type'   => 'post',
		'date'        => '2026-09-01 10:57:09',
		'categories'  => array( 'packaging-lines', 'second-hand' ),
		'tags'        => array(),
		'image_asset' => 'assets/img/second-hand/confezionatrice-stretch-doccasione-1.jpeg',
		'image_name'  => 'confezionatrice-stretch-doccasione-1.jpeg',
		'content'     => '<!-- wp:paragraph --><p><strong>Soluzione professionale per il confezionamento automatico con film estensibile</strong></p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Disponibile presso SAM Swiss SA una confezionatrice automatica d’occasione, ideale per aziende che desiderano aumentare l’efficienza del confezionamento con un investimento più contenuto rispetto all’acquisto di una macchina nuova.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>La macchina è progettata per il confezionamento rapido e uniforme di prodotti alimentari in vaschetta mediante film estensibile, garantendo una presentazione ordinata e professionale del prodotto finale.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Revisionata e pronta all’uso</h3><!-- /wp:heading --><!-- wp:paragraph --><p>La macchina viene fornita completamente revisionata, controllata dai nostri tecnici e pronta all’uso. Una soluzione affidabile e immediatamente operativa, pronta per essere inserita nel processo produttivo senza dover attendere i tempi normalmente richiesti per la fornitura di una macchina nuova.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Ideale per</h3><!-- /wp:heading --><!-- wp:list --><ul><li>Frutta e verdura</li><li>Carne e pollame</li><li>Formaggi e latticini</li><li>Gastronomia</li><li>Prodotti freschi confezionati in vaschetta</li><li>Supermercati, laboratori alimentari e centri di confezionamento</li></ul><!-- /wp:list --><!-- wp:heading {"level":3} --><h3>I vantaggi</h3><!-- /wp:heading --><!-- wp:list --><ul><li>Confezionamento automatico e uniforme</li><li>Riduzione dei tempi di confezionamento</li><li>Semplicità di utilizzo</li><li>Ottima presentazione del prodotto</li><li>Macchina completamente revisionata</li><li>Pronta all’uso</li><li>Soluzione economicamente vantaggiosa rispetto al nuovo</li><li>Assistenza tecnica SAM</li><li>Disponibilità immediata, salvo vendita</li></ul><!-- /wp:list --><!-- wp:paragraph --><p><strong>Una soluzione d’occasione pronta per la produzione</strong></p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Scegliere una macchina d’occasione revisionata permette di ottenere una soluzione professionale e affidabile, contenendo l’investimento e riducendo i tempi di attesa. La macchina è disponibile per visione e maggiori informazioni presso SAM SA.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p><em>Contattaci per ricevere prezzo, caratteristiche tecniche, disponibilità, video della macchina in funzione o per organizzare una visita.</em></p><!-- /wp:paragraph -->',
	),
	array(
		'title'       => 'Macchina confezionatrice d’occasione – revisionata e pronta all’uso',
		'slug'        => 'macchina-confezionatrice-doccasione-revisionata-pronta-uso',
		'post_type'   => 'post',
		'date'        => '2026-09-01 10:58:19',
		'categories'  => array( 'packaging-lines', 'second-hand' ),
		'tags'        => array(),
		'image_asset' => 'assets/img/second-hand/confezionatrice-doccasione-sam-1.jpeg',
		'image_name'  => 'confezionatrice-doccasione-sam-1.jpeg',
		'content'     => '<!-- wp:paragraph --><p><strong>Disponibile presso SAM Swiss SA macchina confezionatrice automatica d’occasione</strong>, ideale per aziende che cercano una soluzione affidabile e immediatamente disponibile per il confezionamento dei propri prodotti.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>La macchina viene fornita revisionata dai nostri tecnici, testata e pronta all’uso, rappresentando un’interessante alternativa all’acquisto di un impianto nuovo.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Caratteristiche principali</h3><!-- /wp:heading --><!-- wp:list --><ul><li>Sistema di confezionamento automatico</li><li>Nastro di alimentazione e trasporto prodotto</li><li>Struttura robusta adatta all’utilizzo industriale</li><li>Sistema di svolgimento e gestione del film</li><li>Comandi operatore facilmente accessibili</li><li>Protezioni di sicurezza sulla zona di confezionamento</li><li>Macchina revisionata e verificata dai tecnici SAM</li><li>Pronta consegna</li></ul><!-- /wp:list --><!-- wp:paragraph --><p>Grazie alla sua configurazione, può essere utilizzata per il confezionamento di diverse tipologie di prodotto e inserita sia in produzioni artigianali sia in linee industriali.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Un’occasione pronta per la produzione</h3><!-- /wp:heading --><!-- wp:paragraph --><p>L’acquisto di una macchina d’occasione revisionata permette di ridurre l’investimento iniziale e, soprattutto, di evitare i lunghi tempi di consegna normalmente richiesti per una macchina nuova.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p><em>La macchina è disponibile in offerta fino ad esaurimento disponibilità.</em></p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Vuoi maggiori informazioni?</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Contattaci per ricevere prezzo, caratteristiche tecniche, dimensioni, disponibilità e ulteriori fotografie o video della macchina in funzione.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p><strong>SAM SA — Soluzioni professionali per il confezionamento e l’automazione.</strong></p><!-- /wp:paragraph -->',
	),
	array(
		'title'       => 'Confezionatrice termosaldatrice da banco SAM – In offerta',
		'slug'        => 'confezionatrice-termosaldatrice-da-banco-sam-in-offerta',
		'post_type'   => 'post',
		'date'        => '2026-09-01 12:30:42',
		'categories'  => array( 'packaging-lines', 'second-hand' ),
		'tags'        => array(),
		'image_asset' => 'assets/img/second-hand/confezionatrice-termosaldatrice-da-banco-sam-1.jpeg',
		'image_name'  => 'confezionatrice-termosaldatrice-da-banco-sam-1.jpeg',
		'content'     => '<!-- wp:paragraph --><p><strong>Disponibile in pronta consegna confezionatrice termosaldatrice da banco SAM</strong>, una soluzione compatta e professionale pensata per la chiusura di vaschette mediante film termosaldante.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>La macchina è ideale per piccole e medie produzioni e rappresenta una soluzione pratica per gastronomie, macellerie, laboratori alimentari, take-away, catering e attività che necessitano di un confezionamento semplice, ordinato e professionale.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Caratteristiche principali</h3><!-- /wp:heading --><!-- wp:list --><ul><li>Struttura compatta e robusta</li><li>Realizzazione in acciaio inox</li><li>Funzionamento manuale tramite leva</li><li>Regolazione elettronica della temperatura</li><li>Portabobina integrato</li><li>Sistema di termosaldatura per vaschette</li><li>Cambio formato semplice e immediato</li><li>Facile utilizzo e pulizia</li><li>Ingombro ridotto, ideale anche per spazi di lavoro contenuti</li></ul><!-- /wp:list --><!-- wp:paragraph --><p>La confezionatrice permette di ottenere una saldatura uniforme e precisa, contribuendo a proteggere il prodotto e a migliorarne la presentazione.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Può essere utilizzata con differenti tipologie di vaschette e materiali compatibili con la termosaldatura, in funzione del formato installato.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Macchina pronta all’uso</h3><!-- /wp:heading --><!-- wp:paragraph --><p>La confezionatrice viene fornita revisionata dai nostri tecnici, controllata e pronta all’utilizzo.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p><em>Disponibile in offerta fino ad esaurimento disponibilità.</em></p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Per informazioni su prezzo, formato disponibile, dimensioni delle vaschette e film compatibili, contattateci.</p><!-- /wp:paragraph -->',
	),
	array(
		'title'       => 'Offerta Esclusiva – Pesatrice revisionata e garantita',
		'slug'        => 'pesatrice-industriale-doccasione-revisionata-garantita',
		'post_type'   => 'post',
		'date'        => '2026-09-01 12:35:20',
		'categories'  => array( 'packaging-lines', 'second-hand' ),
		'tags'        => array(),
		'image_asset' => 'assets/img/second-hand/pesatrice-industriale-doccasione-1.jpg',
		'image_name'  => 'pesatrice-industriale-doccasione-1.jpg',
		'content'     => '<!-- wp:paragraph --><p><strong>Disponibile presso SAM pesatrice industriale d’occasione</strong>, completamente revisionata, testata e garantita, pronta per essere inserita in produzione.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Una soluzione particolarmente indicata per il settore ortofrutticolo e per il confezionamento di prodotti come pomodori, kiwi, pere, ciliegie, aglio e altri prodotti delicati, dove precisione e rispetto del prodotto sono fondamentali.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Precisione, delicatezza e produttività</h3><!-- /wp:heading --><!-- wp:paragraph --><p>La pesatrice è progettata per garantire una gestione accurata del prodotto durante tutte le fasi di pesatura, riducendo al minimo urti e danneggiamenti.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Il sistema permette di ottenere porzioni precise e uniformi, ottimizzando il peso di ogni confezione e contribuendo a ridurre il giveaway di prodotto.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Macchina d’occasione pronta all’uso</h3><!-- /wp:heading --><!-- wp:list --><ul><li>Completamente revisionata dai tecnici SAM</li><li>Testata e collaudata</li><li>Garantita</li><li>Pronta all’uso e all’inserimento in linea</li><li>Disponibile in offerta esclusiva</li></ul><!-- /wp:list --><!-- wp:paragraph --><p>Una soluzione ideale per chi desidera aumentare l’automazione della propria linea produttiva con un investimento più contenuto rispetto all’acquisto di una macchina nuova.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Applicazioni ortofrutticole</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Adatta alla pesatura di diversi prodotti ortofrutticoli e freschi, tra cui:</p><!-- /wp:paragraph --><!-- wp:list --><ul><li>Pomodori e pomodorini</li><li>Kiwi</li><li>Pere</li><li>Ciliegie</li><li>Aglio</li><li>Piccoli frutti e ortaggi a pezzatura controllata</li></ul><!-- /wp:list --><!-- wp:paragraph --><p>Può essere integrata con differenti sistemi di confezionamento (vaschette, cestini, vassoi o reti) in base alle esigenze produttive del cliente.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p><em>Macchina disponibile in pronta consegna fino ad esaurimento disponibilità.</em></p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Contattaci per conoscere prezzo, configurazione, caratteristiche tecniche e per ricevere ulteriori fotografie o video della macchina in funzione.</p><!-- /wp:paragraph -->',
	),
	array(
		'title'       => 'DREAM 700 – Macchina d’occasione revisionata e garantita',
		'slug'        => 'dream-700-macchina-doccasione-revisionata-garantita',
		'post_type'   => 'post',
		'date'        => '2026-09-01 12:36:51',
		'categories'  => array( 'packaging-lines', 'second-hand' ),
		'tags'        => array(),
		'image_asset' => 'assets/img/second-hand/dream-700-doccasione-1.jpeg',
		'image_name'  => 'dream-700-doccasione-1.jpeg',
		'content'     => '<!-- wp:paragraph --><p><strong>Disponibile in pronta consegna presso SAM Swiss SA</strong></p><!-- /wp:paragraph --><!-- wp:paragraph --><p>La DREAM 700 è una macchina confezionatrice verticale compatta e robusta, ideale per il confezionamento automatico di diversi prodotti alimentari in sacchetto.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>La macchina proposta è d’occasione, completamente revisionata dai nostri tecnici e fornita pronta all’uso, con garanzia SAM Swiss SA.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Grazie alla struttura in acciaio inox, al pannello di controllo intuitivo e alla configurazione compatta, rappresenta una soluzione ideale per le aziende che desiderano automatizzare il processo di confezionamento contenendo l’investimento.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Principali caratteristiche</h3><!-- /wp:heading --><!-- wp:list --><ul><li>Confezionatrice verticale automatica</li><li>Struttura robusta in acciaio inox</li><li>Pannello di controllo touch screen</li><li>Sistema automatico di formazione, riempimento e saldatura del sacchetto</li><li>Adatta al confezionamento di diversi prodotti alimentari</li><li>Ingombro contenuto e facile integrazione nella linea produttiva</li><li>Semplice utilizzo e gestione dei parametri di confezionamento</li></ul><!-- /wp:list --><!-- wp:heading {"level":3} --><h3>Macchina revisionata e pronta alla produzione</h3><!-- /wp:heading --><!-- wp:paragraph --><p>La DREAM 700 viene fornita revisionata, controllata e pronta all’impiego, offrendo una soluzione affidabile per chi cerca una macchina professionale d’occasione senza rinunciare alla sicurezza del servizio post-vendita.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p><em>Disponibilità limitata – macchina d’occasione in pronta consegna.</em></p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Contattaci per maggiori informazioni, caratteristiche tecniche, prezzo o per organizzare una visita presso la nostra sede.</p><!-- /wp:paragraph -->',
	),
	array(
		'title'       => 'VG 500 – Termosigillatrice semiautomatica d’occasione',
		'slug'        => 'vg-500-termosigillatrice-semiautomatica-doccasione',
		'post_type'   => 'post',
		'date'        => '2026-09-01 12:38:11',
		'categories'  => array( 'packaging-lines', 'second-hand' ),
		'tags'        => array(),
		'image_asset' => 'assets/img/second-hand/vg-500-termosigillatrice-semiautomatica-1.jpeg',
		'image_name'  => 'vg-500-termosigillatrice-semiautomatica-1.jpeg',
		'content'     => '<!-- wp:paragraph --><p><strong>La VG 500 è una termosigillatrice semiautomatica professionale</strong>, robusta e versatile, progettata per il confezionamento di prodotti alimentari in vaschetta.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Grazie alla possibilità di lavorare in <strong>semplice sigillatura, sottovuoto e atmosfera modificata (MAP)</strong>, rappresenta una soluzione particolarmente adatta per carne, salumi, gastronomia, prodotti freschi e piatti pronti.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>La macchina è disponibile d’occasione, completamente revisionata, garantita e pronta all’uso.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Caratteristiche principali</h3><!-- /wp:heading --><!-- wp:list --><ul><li>Struttura in acciaio inox AISI 304 e alluminio anodizzato</li><li>Funzionamento semiautomatico</li><li>Sigillatura, vuoto e atmosfera modificata (MAP)</li><li>Sistema di iniezione di gas inerte</li><li>Avanzamento automatico del film con riavvolgitore dello sfrido</li><li>Chiusura e apertura automatica del cassetto</li><li>Sollevamento delle vaschette per facilitarne l’estrazione</li><li>Cambio rapido di stampo (meno di un minuto)</li><li>Possibilità di utilizzare stampi a una o più impronte, in funzione del formato</li><li>Larghezza massima film: 500 mm</li></ul><!-- /wp:list --><!-- wp:heading {"level":3} --><h3>Elevata flessibilità di formato</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Uno dei principali vantaggi della VG 500 è la possibilità di lavorare con diversi stampi e differenti configurazioni di vaschetta.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Il sistema di cambio rapido consente di sostituire stampo e controstampo in meno di un minuto, rendendo la macchina particolarmente interessante per produzioni che richiedono frequenti cambi di formato. A seconda delle esigenze è possibile utilizzare stampi a una, due o più impronte, ottimizzando la produttività in base alle dimensioni della confezione.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Dati tecnici principali</h3><!-- /wp:heading --><!-- wp:list --><ul><li><strong>Alimentazione:</strong> 380 V – 50 Hz</li><li><strong>Potenza assorbita:</strong> 3,5 kW</li><li><strong>Larghezza massima film:</strong> 500 mm</li><li><strong>Peso:</strong> circa 180 kg</li><li><strong>Dimensioni:</strong> circa 1300 × 700 × 1700 mm</li></ul><!-- /wp:list --><!-- wp:paragraph --><p><em>La produttività varia in funzione del formato, del numero di impronte e del tipo di ciclo utilizzato.</em></p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Macchina d’occasione revisionata e garantita</h3><!-- /wp:heading --><!-- wp:paragraph --><p>La VG 500 viene fornita revisionata dai nostri tecnici, garantita e pronta per essere inserita nel processo produttivo. Una soluzione professionale per chi cerca una termosigillatrice flessibile e affidabile, con la possibilità di gestire differenti formati e tecnologie di confezionamento senza l\'investimento richiesto da una macchina nuova.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p><em>Disponibilità limitata – macchina d’occasione in pronta consegna.</em></p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Per maggiori informazioni, disponibilità degli stampi e configurazione della macchina, contattate SAM.</p><!-- /wp:paragraph -->',
	),
);
