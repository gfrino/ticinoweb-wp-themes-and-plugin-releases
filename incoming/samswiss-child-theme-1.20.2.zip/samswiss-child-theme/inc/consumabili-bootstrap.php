<?php
/**
 * Auto-provisioning, universal menu sanitizer, and virtual routing
 * for SAM Swiss commercial deployment.
 *
 * Ensures that deploying samswiss-child-theme as a standalone ZIP to any
 * server (e.g. LIVE production) automatically:
 * 1. Sanitizes all menus (removes old gelateria/ingredients and merged sector items).
 * 2. Injects / guarantees "Imballaggi e Consumabili" in Primary Menu.
 * 3. Enforces the 3 official industrial sectors in the category archive navigation.
 * 4. 301-redirects old category URLs and old landing URLs.
 * 5. Auto-creates and virtually serves the `/imballaggi-e-consumabili/` landing page.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Returns the 3 official industrial sector navigation objects for the category bar.
 *
 * @return array<int,stdClass>
 */
function samswiss_get_official_sectors_nav_items() {
	$current_slug = '';
	if ( is_category() ) {
		$term = get_queried_object();
		if ( $term instanceof WP_Term ) {
			$current_slug = $term->slug;
		}
	}

	$sectors = array(
		array(
			'slug'  => 'ortofrutta',
			'title' => __( 'Ortofrutta', 'samswiss-child' ),
			'match' => array( 'ortofrutta' ),
		),
		array(
			'slug'  => 'gastronomia-e-ristorazione',
			'title' => __( 'Gastronomia, Panetteria e IV Gamma', 'samswiss-child' ),
			'match' => array( 'gastronomia-e-ristorazione', 'pane-pasticceria-gelateria', 'quarta-gamma-gdo' ),
		),
		array(
			'slug'  => 'carne-pesce',
			'title' => __( 'Carne, Pesce e Settore Caseario', 'samswiss-child' ),
			'match' => array( 'carne-pesce', 'caseario' ),
		),
	);

	$items = array();
	$i     = 99900;
	foreach ( $sectors as $sec ) {
		$i++;
		$is_current = in_array( $current_slug, $sec['match'], true );

		$item                   = new stdClass();
		$item->ID               = $i;
		$item->db_id            = $i;
		$item->menu_item_parent = 0;
		$item->object_id        = 0;
		$item->object           = 'category';
		$item->type             = 'taxonomy';
		$item->type_label       = 'Category';
		$item->title            = $sec['title'];
		$item->url              = samswiss_category_url( $sec['slug'] );
		$item->target           = '';
		$item->attr_title       = '';
		$item->description      = '';
		$item->classes          = array(
			'menu-item',
			'menu-item-type-taxonomy',
			'menu-item-object-category',
			'menu-item-' . $i,
		);
		if ( $is_current ) {
			$item->classes[] = 'current-menu-item';
			$item->current   = true;
		} else {
			$item->current = false;
		}

		$items[] = $item;
	}

	return $items;
}

/**
 * Universal nav menu sanitizer: cleanses obsolete gelateria / monouso / old sector
 * items from ALL menus and guarantees "Imballaggi e Consumabili" presence.
 *
 * @param array    $items Array of menu item objects.
 * @param stdClass $args  wp_nav_menu arguments object.
 * @return array Sanitized menu item objects.
 */
function samswiss_clean_unwanted_nav_menu_items( $items, $args ) {
	if ( empty( $items ) || ! is_array( $items ) ) {
		return $items;
	}

	$location = isset( $args->theme_location ) ? $args->theme_location : '';

	// Category menu location: strictly enforce the 3 official macro-sectors
	if ( 'category-menu' === $location ) {
		return samswiss_get_official_sectors_nav_items();
	}

	$excluded_post_ids = function_exists( 'samswiss_get_gelateria_excluded_post_ids' ) ? samswiss_get_gelateria_excluded_post_ids() : array();
	$excluded_patterns = array(
		'imballaggi e monouso',
		'packaging & disposable',
		'emballage et jetable',
		'verpackung & einweg',
		'ingredienti',
		'ingredients',
		'ingrédients',
		'zutaten',
		'pane pasticceria e gelateria',
		'pane, pasticceria e gelateria',
		'quarta gamma',
		'4th range',
		'iv gamma',
	);

	$soluzioni_id    = 0;
	$has_consumabili = false;
	$cleaned         = array();

	foreach ( $items as $item ) {
		$title_lower = mb_strtolower( trim( (string) $item->title ), 'UTF-8' );
		$url_lower   = mb_strtolower( trim( (string) $item->url ), 'UTF-8' );
		$obj_id      = (int) ( $item->object_id ?? 0 );

		// Detect Soluzioni parent item
		if ( strpos( $title_lower, 'soluzioni' ) !== false || strpos( $url_lower, '#soluzioni' ) !== false ) {
			$soluzioni_id = (int) $item->ID;
		}

		// Detect Imballaggi e Consumabili
		if ( strpos( $title_lower, 'consumabili' ) !== false || strpos( $url_lower, 'imballaggi-e-consumabili' ) !== false ) {
			$has_consumabili = true;
			$item->url       = home_url( '/imballaggi-e-consumabili/' );
		}

		// Evaluate strip conditions
		$strip = false;

		// Strip by known ID (monouso 1270, ingredienti 1301, old landing 215, translations, gelateria posts)
		if ( in_array( $obj_id, array( 215, 1270, 1301, 10088, 10167, 10173 ), true ) || in_array( $obj_id, $excluded_post_ids, true ) ) {
			$strip = true;
		}

		// Strip by title / slug pattern
		if ( ! $strip ) {
			foreach ( $excluded_patterns as $pat ) {
				$slug_pat = str_replace( array( ' ', '&' ), array( '-', '' ), $pat );
				if ( strpos( $title_lower, $pat ) !== false || strpos( $url_lower, $slug_pat ) !== false ) {
					$strip = true;
					break;
				}
			}
		}

		// Standalone "Caseario" (when not part of "Carne, Pesce e Settore Caseario")
		if ( ! $strip && ( $title_lower === 'caseario' || strpos( $url_lower, '/caseario/' ) !== false ) && strpos( $title_lower, 'carne' ) === false ) {
			$strip = true;
		}

		if ( ! $strip ) {
			$cleaned[] = $item;
		}
	}

	// Auto-inject "Imballaggi e Consumabili" if missing from live menu
	if ( ! $has_consumabili && ( 'primary' === $location || empty( $location ) ) && $soluzioni_id ) {
		$consumabili_item                   = new stdClass();
		$consumabili_item->ID               = 99950;
		$consumabili_item->db_id            = 99950;
		$consumabili_item->menu_item_parent = $soluzioni_id;
		$consumabili_item->object_id        = 0;
		$consumabili_item->object           = 'custom';
		$consumabili_item->type             = 'custom';
		$consumabili_item->type_label       = 'Custom Link';
		$consumabili_item->title            = __( 'Imballaggi e Consumabili', 'samswiss-child' );
		$consumabili_item->url              = home_url( '/imballaggi-e-consumabili/' );
		$consumabili_item->target           = '';
		$consumabili_item->attr_title       = '';
		$consumabili_item->description      = '';
		$consumabili_item->classes          = array(
			'menu-item',
			'menu-item-type-custom',
			'menu-item-object-custom',
			'menu-item-99950',
		);
		$consumabili_item->current          = is_page( 'imballaggi-e-consumabili' );

		$new_items = array();
		$inserted  = false;
		$total     = count( $cleaned );
		for ( $idx = 0; $idx < $total; $idx++ ) {
			$it          = $cleaned[ $idx ];
			$new_items[] = $it;
			if ( (int) $it->menu_item_parent === $soluzioni_id ) {
				$next = $cleaned[ $idx + 1 ] ?? null;
				if ( ! $next || (int) $next->menu_item_parent !== $soluzioni_id ) {
					$new_items[] = $consumabili_item;
					$inserted    = true;
				}
			}
		}
		if ( ! $inserted ) {
			$new_items[] = $consumabili_item;
		}
		$cleaned = $new_items;
	}

	return $cleaned;
}
add_filter( 'wp_nav_menu_objects', 'samswiss_clean_unwanted_nav_menu_items', 25, 2 );

/**
 * 301-redirects old merged sector category archives to the corresponding active sector.
 */
function samswiss_redirect_merged_sectors() {
	if ( is_admin() ) {
		return;
	}

	if ( is_category() ) {
		$cat = get_queried_object();
		if ( $cat instanceof WP_Term ) {
			if ( in_array( $cat->slug, array( 'pane-pasticceria-gelateria', 'quarta-gamma-gdo' ), true ) ) {
				wp_safe_redirect( samswiss_category_url( 'gastronomia-e-ristorazione' ), 301 );
				exit;
			}
			if ( 'caseario' === $cat->slug ) {
				wp_safe_redirect( samswiss_category_url( 'carne-pesce' ), 301 );
				exit;
			}
		}
	}
}
add_action( 'template_redirect', 'samswiss_redirect_merged_sectors', 2 );

/**
 * Ensures the `imballaggi-e-consumabili` WordPress page exists in the database.
 * Runs idempotently on `init`.
 */
function samswiss_ensure_consumabili_page_exists() {
	static $checked = false;
	if ( $checked ) {
		return;
	}
	$checked = true;

	$page = get_page_by_path( 'imballaggi-e-consumabili' );
	if ( ! $page ) {
		wp_insert_post( array(
			'post_title'   => 'Imballaggi e Consumabili',
			'post_name'    => 'imballaggi-e-consumabili',
			'post_status'  => 'publish',
			'post_type'    => 'page',
			'post_content' => '',
		) );
	}
}
add_action( 'init', 'samswiss_ensure_consumabili_page_exists', 5 );

/**
 * Virtual route fallback for `/imballaggi-e-consumabili/` to guarantee HTTP 200
 * even if the database record is not present.
 *
 * @param string $template The path of the template to include.
 * @return string
 */
function samswiss_virtual_consumabili_route( $template ) {
	$req_path = trim( (string) wp_parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ), '/' );
	$parts    = explode( '/', $req_path );
	$slug     = end( $parts );

	if ( 'imballaggi-e-consumabili' === $slug ) {
		global $wp_query;
		$wp_query->is_404  = false;
		$wp_query->is_page = true;
		status_header( 200 );

		$page_template = get_stylesheet_directory() . '/page.php';
		if ( file_exists( $page_template ) ) {
			return $page_template;
		}
	}

	return $template;
}
add_filter( 'template_include', 'samswiss_virtual_consumabili_route', 99 );
