<?php
/**
 * Seeds the theme's WPML String Translation entries for 'samswiss-child'.
 *
 * Registers each Italian source string (matching the theme's __()/_e() calls)
 * plus its translations into WPML String Translation, so WPML's gettext hook
 * translates the theme UI at runtime across all 8 languages. Idempotent and
 * hash-gated: it only does real work when inc/wpml-translations.php changes.
 * WPML remains the editable source of truth in String Translation.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function samswiss_seed_wpml_translations() {
	if ( ! function_exists( 'icl_register_string' )
		|| ! function_exists( 'icl_get_string_id' )
		|| ! function_exists( 'icl_add_string_translation' ) ) {
		return;
	}

	$seed_file = get_stylesheet_directory() . '/inc/wpml-translations.php';
	if ( ! file_exists( $seed_file ) ) {
		return;
	}

	// Version tracks BOTH the data and this seeder, so logic changes re-run once.
	$version = md5_file( $seed_file ) . '-' . md5_file( __FILE__ );
	if ( get_option( 'samswiss_wpml_seed_version' ) === $version ) {
		return;
	}

	$rows = include $seed_file;
	if ( ! is_array( $rows ) ) {
		return;
	}

	$context  = 'samswiss-child';
	$complete = defined( 'ICL_TM_COMPLETE' ) ? ICL_TM_COMPLETE : 10;
	$langs    = array( 'en', 'de', 'fr', 'sk', 'hu', 'ro', 'ru' );

	foreach ( $rows as $row ) {
		if ( empty( $row['src'] ) ) {
			continue;
		}
		$src  = $row['src'];
		$name = md5( $src ); // Must match how WPML looks up __() strings.

		// Register with Italian as the SOURCE language. WPML's global
		// "strings language" is English on this install, so without this the
		// Italian source would be treated as already-English and would never
		// be translated into English (other languages worked, English didn't).
		icl_register_string( $context, $name, $src, false, 'it' );

		$string_id = icl_get_string_id( $src, $context, $name );
		if ( ! $string_id ) {
			continue;
		}
		foreach ( $langs as $lang ) {
			if ( ! empty( $row[ $lang ] ) ) {
				icl_add_string_translation( $string_id, $lang, $row[ $lang ], $complete );
			}
		}
	}

	// Self-heal strings registered before the source language was set: rows in
	// OUR context only, so no other plugin/theme strings are touched.
	global $wpdb;
	$wpdb->update(
		$wpdb->prefix . 'icl_strings',
		array( 'language' => 'it' ),
		array( 'context' => $context, 'language' => 'en' ),
		array( '%s' ),
		array( '%s', '%s' )
	);

	update_option( 'samswiss_wpml_seed_version', $version );
}
add_action( 'init', 'samswiss_seed_wpml_translations', 20 );
