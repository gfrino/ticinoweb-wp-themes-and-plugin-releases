<?php
/**
 * Unified content auto-seeder and date synchronizer for SAM Swiss child theme.
 *
 * Ensures all required editorial articles (post_type: 'articolo-seo') and
 * second-hand machines (post_type: 'post') exist in the database with their
 * canonical publication dates, featured images, media attachments, taxonomies
 * and WPML language settings.
 *
 * Runs automatically on `init` (priority 25) and is fully idempotent and
 * self-healing.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Copies a file from the theme assets to the uploads folder and registers it
 * as an attachment in the WordPress Media Library if not already present.
 *
 * If the attachment already exists in the database but its file is missing
 * on disk, this function self-heals it by copying the asset into place.
 *
 * @param string $rel_theme_path Relative path from stylesheet directory.
 * @param string $target_filename Desired filename in uploads.
 * @param string $title Attachment title.
 * @return array Array with 'id' and 'url' (both 0 / '' on failure).
 */
function samswiss_seed_ensure_attachment( $rel_theme_path, $target_filename, $title = '' ) {
	$result = array(
		'id'  => 0,
		'url' => '',
	);

	$src_file = trailingslashit( get_stylesheet_directory() ) . ltrim( $rel_theme_path, '/' );
	if ( ! file_exists( $src_file ) ) {
		return $result;
	}

	$upload_info = wp_upload_dir();
	$upload_dir  = $upload_info['path'];
	$upload_url  = $upload_info['url'];

	if ( ! file_exists( $upload_dir ) ) {
		wp_mkdir_p( $upload_dir );
	}

	// 1. Search if an attachment with this target filename already exists.
	global $wpdb;
	$clean_name = sanitize_file_name( $target_filename );
	$att_id = (int) $wpdb->get_var(
		$wpdb->prepare(
			"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_wp_attached_file' AND meta_value LIKE %s LIMIT 1",
			'%' . $wpdb->esc_like( $clean_name )
		)
	);

	if ( $att_id > 0 ) {
		$attached_file = get_attached_file( $att_id );
		if ( $attached_file && file_exists( $attached_file ) ) {
			$result['id']  = $att_id;
			$result['url'] = wp_get_attachment_url( $att_id ) ?: ( $upload_url . '/' . basename( $attached_file ) );
			return $result;
		}

		// Self-heal: Attachment row exists but the file is missing on disk.
		$dest_path = $attached_file ?: ( $upload_dir . '/' . $clean_name );
		$dest_dir  = dirname( $dest_path );
		if ( ! file_exists( $dest_dir ) ) {
			wp_mkdir_p( $dest_dir );
		}
		if ( copy( $src_file, $dest_path ) ) {
			require_once ABSPATH . 'wp-admin/includes/image.php';
			$meta = wp_generate_attachment_metadata( $att_id, $dest_path );
			if ( ! empty( $meta ) ) {
				wp_update_attachment_metadata( $att_id, $meta );
			}
			$result['id']  = $att_id;
			$result['url'] = wp_get_attachment_url( $att_id ) ?: ( $upload_url . '/' . basename( $dest_path ) );
			return $result;
		}
	}

	// 2. Create new attachment in media library.
	require_once ABSPATH . 'wp-admin/includes/image.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';

	$target_name = wp_unique_filename( $upload_dir, $clean_name );
	$target_path = $upload_dir . '/' . $target_name;

	if ( ! copy( $src_file, $target_path ) ) {
		// Fallback to direct theme asset URL if file copy fails (e.g. read-only uploads).
		$result['url'] = trailingslashit( get_stylesheet_directory_uri() ) . ltrim( $rel_theme_path, '/' );
		return $result;
	}

	$filetype   = wp_check_filetype( $target_name, null );
	$attachment = array(
		'guid'           => $upload_url . '/' . $target_name,
		'post_mime_type' => $filetype['type'],
		'post_title'     => $title ?: preg_replace( '/\.[^.]+$/', '', $clean_name ),
		'post_content'   => '',
		'post_status'    => 'inherit',
	);

	$new_att_id = wp_insert_attachment( $attachment, $target_path );
	if ( ! is_wp_error( $new_att_id ) && $new_att_id > 0 ) {
		$attach_data = wp_generate_attachment_metadata( $new_att_id, $target_path );
		if ( ! empty( $attach_data ) ) {
			wp_update_attachment_metadata( $new_att_id, $attach_data );
		}

		// If WPML is active, register media language as Italian.
		if ( function_exists( 'do_action' ) ) {
			do_action( 'wpml_set_element_language_details', array(
				'element_id'           => $new_att_id,
				'element_type'         => 'post_attachment',
				'trid'                 => false,
				'language_code'        => 'it',
				'source_language_code' => null,
			) );
		}

		$result['id']  = $new_att_id;
		$result['url'] = wp_get_attachment_url( $new_att_id ) ?: ( $upload_url . '/' . $target_name );
	} else {
		$result['url'] = $upload_url . '/' . $target_name;
	}

	return $result;
}

/**
 * Main auto-seeder routine. Checks all defined posts individually, creating any
 * that are missing, aligning their canonical publication dates, and ensuring
 * their featured images and taxonomies are wired up.
 */
function samswiss_seed_all_content() {
	$current_seed_version = '1.18.40';

	// Allow manual trigger for admins via ?samswiss_reseed=1, otherwise skip if already seeded.
	$is_reseed_requested = isset( $_GET['samswiss_reseed'] ) && current_user_can( 'manage_options' );
	if ( ! $is_reseed_requested && get_option( 'samswiss_content_seeded_version' ) === $current_seed_version ) {
		return;
	}

	$data_file = trailingslashit( get_stylesheet_directory() ) . 'inc/content-data.php';
	if ( ! file_exists( $data_file ) ) {
		return;
	}

	$items = include $data_file;
	if ( ! is_array( $items ) || empty( $items ) ) {
		return;
	}

	require_once ABSPATH . 'wp-admin/includes/image.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';

	global $wpdb;
	$site_url = untrailingslashit( home_url() );

	foreach ( $items as $item ) {
		$slug      = sanitize_title( $item['slug'] );
		$post_type = ! empty( $item['post_type'] ) ? $item['post_type'] : 'post';
		$title     = $item['title'];

		// 1. Check if post already exists (ignoring language filter so WPML doesn't hide it).
		$existing = get_posts( array(
			'name'             => $slug,
			'post_type'        => $post_type,
			'post_status'      => 'any',
			'numberposts'      => 1,
			'suppress_filters' => true,
		) );

		if ( ! empty( $existing ) ) {
			$post_id = (int) $existing[0]->ID;

			// Ensure canonical publication date is strictly aligned in database
			if ( ! empty( $item['date'] ) ) {
				$target_date = $item['date'];
				$target_gmt  = get_gmt_from_date( $target_date );
				$cur_date    = $existing[0]->post_date;

				if ( $cur_date !== $target_date ) {
					$wpdb->update(
						$wpdb->posts,
						array(
							'post_date'     => $target_date,
							'post_date_gmt' => $target_gmt,
							'post_status'   => 'publish',
						),
						array( 'ID' => $post_id ),
						array( '%s', '%s', '%s' ),
						array( '%d' )
					);
					clean_post_cache( $post_id );
				}
			}

			// Self-heal featured image if missing or detached.
			if ( ! empty( $item['image_asset'] ) ) {
				$thumb_id    = get_post_thumbnail_id( $post_id );
				$thumb_valid = false;
				if ( $thumb_id > 0 ) {
					$attached_file = get_attached_file( $thumb_id );
					if ( $attached_file && file_exists( $attached_file ) ) {
						$thumb_valid = true;
					}
				}

				if ( ! $thumb_valid ) {
					$att = samswiss_seed_ensure_attachment( $item['image_asset'], $item['image_name'], $title );
					if ( ! empty( $att['id'] ) ) {
						set_post_thumbnail( $post_id, $att['id'] );
					}
				}
			}

			// Ensure WPML knows this post is Italian.
			if ( function_exists( 'do_action' ) ) {
				do_action( 'wpml_set_element_language_details', array(
					'element_id'           => $post_id,
					'element_type'         => 'post_' . $post_type,
					'trid'                 => false,
					'language_code'        => 'it',
					'source_language_code' => null,
				) );
			}

			continue;
		}

		// 2. Post does not exist — prepare assets and content.
		$content = $item['content'];
		$content = str_replace( '{{SITE_URL}}', $site_url, $content );

		// Video handling (e.g. Bulltec case history).
		if ( ! empty( $item['video_asset'] ) ) {
			$video_name = ! empty( $item['video_name'] ) ? $item['video_name'] : basename( $item['video_asset'] );
			$video_att  = samswiss_seed_ensure_attachment( $item['video_asset'], $video_name, $slug . '-video' );
			$video_url  = ! empty( $video_att['url'] ) ? $video_att['url'] : ( trailingslashit( get_stylesheet_directory_uri() ) . $item['video_asset'] );
			$content    = str_replace( '{{VIDEO_URL}}', $video_url, $content );
		}

		// Image handling.
		$thumb_att_id = 0;
		if ( ! empty( $item['image_asset'] ) ) {
			$img_name  = ! empty( $item['image_name'] ) ? $item['image_name'] : basename( $item['image_asset'] );
			$img_att   = samswiss_seed_ensure_attachment( $item['image_asset'], $img_name, $title );
			$thumb_att_id = ! empty( $img_att['id'] ) ? $img_att['id'] : 0;
			$poster_url   = ! empty( $img_att['url'] ) ? $img_att['url'] : ( trailingslashit( get_stylesheet_directory_uri() ) . $item['image_asset'] );
			$content      = str_replace( '{{POSTER_URL}}', $poster_url, $content );
		}

		// 3. Taxonomies: categories.
		$cat_ids = array();
		if ( ! empty( $item['categories'] ) && is_array( $item['categories'] ) ) {
			foreach ( $item['categories'] as $cat_slug ) {
				$term = get_term_by( 'slug', $cat_slug, 'category' );
				if ( $term ) {
					$cat_ids[] = (int) $term->term_id;
				} else {
					$new_cat = wp_insert_term(
						ucwords( str_replace( '-', ' ', $cat_slug ) ),
						'category',
						array( 'slug' => $cat_slug )
					);
					if ( ! is_wp_error( $new_cat ) && isset( $new_cat['term_id'] ) ) {
						$cat_ids[] = (int) $new_cat['term_id'];
					}
				}
			}
		}

		// 4. Taxonomies: tags.
		$tag_slugs = ! empty( $item['tags'] ) && is_array( $item['tags'] ) ? $item['tags'] : array();

		// 5. Insert post.
		$target_date = ! empty( $item['date'] ) ? $item['date'] : current_time( 'mysql' );
		$target_gmt  = get_gmt_from_date( $target_date );

		$new_post_id = wp_insert_post( array(
			'post_title'    => $title,
			'post_name'     => $slug,
			'post_content'  => $content,
			'post_status'   => 'publish',
			'post_type'     => $post_type,
			'post_date'     => $target_date,
			'post_date_gmt' => $target_gmt,
			'post_category' => $cat_ids,
			'tags_input'    => $tag_slugs,
		) );

		if ( ! is_wp_error( $new_post_id ) && $new_post_id > 0 ) {
			// Direct DB update to ensure no timezone drift
			$wpdb->update(
				$wpdb->posts,
				array(
					'post_date'     => $target_date,
					'post_date_gmt' => $target_gmt,
					'post_status'   => 'publish',
				),
				array( 'ID' => $new_post_id ),
				array( '%s', '%s', '%s' ),
				array( '%d' )
			);
			clean_post_cache( $new_post_id );

			// Set featured image.
			if ( $thumb_att_id > 0 ) {
				set_post_thumbnail( $new_post_id, $thumb_att_id );
			}

			// Ensure WPML registers language as Italian.
			if ( function_exists( 'do_action' ) ) {
				do_action( 'wpml_set_element_language_details', array(
					'element_id'           => $new_post_id,
					'element_type'         => 'post_' . $post_type,
					'trid'                 => false,
					'language_code'        => 'it',
					'source_language_code' => null,
				) );
			}
		}
	}

	// 6. Synchronize canonical publication dates for all 2026 editorial news articles
	$editorial_dates = array(
		'sam-a-fruit-attraction-2026'                                                            => '2026-09-01 12:00:00',
		'sam-a-macfrut-2026-innovazione-partnership-e-nuove-opportunita-nel-mondo-del-packaging' => '2026-08-28 10:00:00',
		'sam-partner-ufficiale-di-sorma-group-in-svizzera-soluzioni-di-macchine-e-assistenza-tecnica-su-tutto-il-territorio' => '2026-08-25 10:00:00',
		'prima-installazione-peso-combinato-bulltec-svizzera'                                     => '2026-08-20 10:00:00',
		'frutta-e-verdura-confezionata-soluzioni-professionali-per-una-distribuzione-efficiente'  => '2026-07-21 08:23:37',
		'packaging-e-presentazione-come-il-confezionamento-influenza-davvero-le-vendite'          => '2026-06-18 11:00:00',
		'macchine-confezionatrici-i-7-errori-piu-comuni-nella-scelta-e-come-evitarli'             => '2026-06-04 11:00:00',
		'map-skin-o-sottovuoto-quale-tecnologia-scegliere-per-il-confezionamento-di-carne-e-pesce' => '2026-05-21 11:00:00',
		'sai-davvero-quanto-limballaggio-puo-fare-la-differenza-nella-conservazione-di-carne-e-pesce' => '2026-05-07 10:00:00',
		'come-scegliere-il-packaging-giusto-per-il-take-away'                                    => '2026-04-23 11:00:00',
		'come-automatizzare-la-tua-cucina-professionale'                                         => '2026-04-09 11:00:00',
		'quali-macchine-scegliere-per-pane-pasticceria-e-gelateria'                              => '2026-03-19 10:30:00',
		'vuoi-risparmiare-sul-confezionamento-dei-tuoi-prodotti-caseari'                          => '2026-03-05 10:30:00',
		'macchine-per-imballaggio-come-scegliere-la-soluzione-giusta-in-base-ai-volumi'           => '2026-02-19 11:54:59',
		'packaging-per-delivery-meno-reclami-piu-soddisfazione'                                   => '2026-02-09 11:41:28',
		'il-futuro-degli-imballaggi-ecosostenibili-per-carne-e-pesce-innovazione-sostenibilita-e-sicurezza-alimentare' => '2026-01-28 08:59:51',
		'macchine-confezionatrici-per-alimenti-freschi-quali-caratteristiche-deve-avere-un-impianto-moderno' => '2026-01-20 11:21:07',
		'ridurre-i-costi-aziendali-con-sistemi-di-automazione-per-il-packaging-la-guida-completa' => '2026-01-20 11:20:14',
		'linee-di-confezionamento-automatiche-come-ottimizzare-la-produzione-nel-settore-alimentare' => '2026-01-20 11:18:53',
	);

	foreach ( $editorial_dates as $ed_slug => $ed_date ) {
		$ed_posts = get_posts( array(
			'name'             => $ed_slug,
			'post_type'        => 'articolo-seo',
			'post_status'      => 'any',
			'numberposts'      => 1,
			'suppress_filters' => true,
		) );
		if ( ! empty( $ed_posts ) ) {
			$p_id     = (int) $ed_posts[0]->ID;
			$cur_date = $wpdb->get_var( $wpdb->prepare( "SELECT post_date FROM {$wpdb->posts} WHERE ID = %d", $p_id ) );
			if ( $cur_date !== $ed_date ) {
				$wpdb->update(
					$wpdb->posts,
					array(
						'post_date'     => $ed_date,
						'post_date_gmt' => get_gmt_from_date( $ed_date ),
						'post_status'   => 'publish',
					),
					array( 'ID' => $p_id ),
					array( '%s', '%s', '%s' ),
					array( '%d' )
				);
				clean_post_cache( $p_id );
			}
		}
	}

	// Update flags.
	update_option( 'samswiss_content_seeded_version', $current_seed_version );
	update_option( 'samswiss_secondhand_seeded_v1', 1 );
}
add_action( 'init', 'samswiss_seed_all_content', 25 );
