<?php
/**
 * "Cerchi una tecnologia specifica?" — ten dedicated technology pages
 * (point 89), reached at /tecnologie/{slug}/, each a real page (not a
 * popup/modal/accordion) sharing one template so every page stays visually
 * consistent by construction.
 *
 * Placeholder content on the client's explicit brief: cover photos are REAL
 * SAM machine photographs already in the catalogue (chosen per technology,
 * not random stock), never invented performance figures — descriptions are
 * generic explanations of what each technology class does, not claims about
 * a specific SAM machine's speed/capacity/certifications. Meant to be
 * replaced page by page once the client has real copy and media.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register the /tecnologie/{slug}/ rewrite + query var. The version-gated
 * flush in samswiss_flush_rules_on_version_change() (inc/helpers.php) picks
 * this up on the next request after a version bump — no manual "Save
 * Permalinks" needed on deploy.
 */
function samswiss_tecnologie_rewrite() {
	add_rewrite_rule( '^tecnologie/([^/]+)/?$', 'index.php?samswiss_tech=$matches[1]', 'top' );
}
add_action( 'init', 'samswiss_tecnologie_rewrite' );

function samswiss_tecnologie_query_vars( $vars ) {
	$vars[] = 'samswiss_tech';
	return $vars;
}
add_filter( 'query_vars', 'samswiss_tecnologie_query_vars' );

/**
 * Serve the shared template for any recognised slug; anything else (typo,
 * removed entry) falls through to the theme's normal 404 — never a broken
 * page silently rendered as blank.
 */
function samswiss_tecnologie_template( $template ) {
	$slug = get_query_var( 'samswiss_tech' );
	if ( '' === $slug ) {
		return $template;
	}
	if ( 'pesatura' === $slug || 'etichettatura' === $slug ) {
		wp_safe_redirect( home_url( '/tecnologie/pesatura-ed-etichettatura/' ), 301 );
		exit;
	}
	$catalog = samswiss_tech_catalog();
	if ( empty( $catalog[ $slug ] ) ) {
		global $wp_query;
		$wp_query->set_404();
		status_header( 404 );
		return get_query_template( '404' );
	}
	return get_stylesheet_directory() . '/template-parts/pages/tecnologia-single.php';
}
add_filter( 'template_include', 'samswiss_tecnologie_template' );

function samswiss_tecnologie_url( $slug ) {
	return home_url( '/tecnologie/' . $slug . '/' );
}

/**
 * There is no WP_Post behind /tecnologie/{slug}/, so WordPress's main query
 * resolves the URL as if it were the blog index — is_home() true, a real
 * (empty or irrelevant) posts query runs. Neither matters for the template
 * (it never touches the main query), but the parent theme's SEO module reads
 * is_home()/is_404() to decide what to put in <title> and OG tags, so left
 * alone every one of these ten pages would announce itself as the blog.
 */
function samswiss_tecnologie_fix_query_flags( $query ) {
	if ( ! $query->is_main_query() || is_admin() ) {
		return;
	}
	$slug = get_query_var( 'samswiss_tech' );
	if ( '' === $slug || empty( samswiss_tech_catalog()[ $slug ] ) ) {
		return;
	}
	$query->is_home = false;
	$query->is_404  = false;
}
add_action( 'pre_get_posts', 'samswiss_tecnologie_fix_query_flags' );

function samswiss_tecnologie_document_title( $parts ) {
	$slug = get_query_var( 'samswiss_tech' );
	if ( '' === $slug ) {
		return $parts;
	}
	$tech = samswiss_tech_catalog()[ $slug ] ?? null;
	if ( ! $tech ) {
		return $parts;
	}
	$parts['title'] = $tech['title'];
	unset( $parts['tagline'] );
	return $parts;
}
add_filter( 'document_title_parts', 'samswiss_tecnologie_document_title' );

/**
 * The ten technologies, in the client's own reference order. `cover`/`gallery`
 * entries are either a real catalogue post ID (its featured image is used) or
 * a `theme:` path shipped with the theme (portable across installs, like the
 * Sorma photos already used elsewhere on this page). Picked by matching each
 * machine's own title/description to the technology — e.g. "Dream 700 /
 * Confezionatrice Verticale" for net packaging, "VG 500 / Termosigillatrice"
 * for sealing — not a random draw from the catalogue.
 *
 * @return array<string,array>
 */
function samswiss_tech_catalog() {
	static $catalog = null;
	if ( null !== $catalog ) {
		return $catalog;
	}

	$applicazioni = array(
		__( 'Ortofrutta', 'samswiss-child' ),
		__( 'Gastronomia e Ristorazione', 'samswiss-child' ),
		__( 'Pane, Pasticceria e Gelateria', 'samswiss-child' ),
		__( 'Quarta Gamma/GDO', 'samswiss-child' ),
		__( 'Carne & Pesce', 'samswiss-child' ),
		__( 'Caseario', 'samswiss-child' ),
	);

	$catalog = array(
		'confezionamento-in-rete'     => array(
			'icon'              => 'fa-circle-nodes',
			'title'             => __( 'Confezionamento in Rete', 'samswiss-child' ),
			'subtitle'          => __( 'Visibilità, traspirabilità e valorizzazione del prodotto', 'samswiss-child' ),
			'card_text'         => __( 'Soluzioni per confezionare in rete con materiali sostenibili e di alta qualità.', 'samswiss-child' ),
			'intro'             => __( 'Il confezionamento in rete è una delle soluzioni più diffuse nel settore ortofrutticolo per prodotti come patate, cipolle, agrumi, mele, aglio, pomodori, zucchine e numerose altre tipologie di frutta e verdura. SAM SA propone in Svizzera le tecnologie Sorma Group, specialista internazionale nello sviluppo di macchine, linee automatiche e materiali per il confezionamento dei prodotti ortofrutticoli. Dalla tradizionale retina alle confezioni più evolute e personalizzabili, studiamo la soluzione più adatta in funzione del prodotto, del peso della confezione, della capacità produttiva richiesta e delle esigenze di presentazione sul punto vendita.', 'samswiss-child' ),
			'features_title'    => __( 'Perché scegliere il confezionamento in rete', 'samswiss-child' ),
			'features_intro'    => __( 'La struttura aperta della rete permette di mantenere il prodotto ben visibile e naturalmente ventilato, offrendo al tempo stesso una confezione pratica e resistente. A seconda della configurazione è possibile realizzare confezioni con:', 'samswiss-child' ),
			'features'          => array(
				__( 'Rete tessuta o estrusa', 'samswiss-child' ),
				__( 'Bande laterali personalizzabili', 'samswiss-child' ),
				__( 'Manico integrato o applicato', 'samswiss-child' ),
				__( 'Etichettatura e tracciabilità', 'samswiss-child' ),
				__( 'Stampa delle informazioni direttamente sulla confezione', 'samswiss-child' ),
				__( 'Differenti formati e pesi', 'samswiss-child' ),
				__( 'Materiali tradizionali, riciclabili o a ridotto impatto ambientale', 'samswiss-child' ),
			),
			'automation_title'  => __( 'Soluzioni per prodotti e produzioni differenti', 'samswiss-child' ),
			'automation_text'   => __( 'Non tutti i prodotti possono essere confezionati nello stesso modo. Per questo analizziamo caratteristiche come dimensione, forma, delicatezza del prodotto, peso richiesto e velocità di produzione, individuando la tecnologia più indicata. Sono disponibili soluzioni per prodotti più resistenti come patate e cipolle, ma anche sistemi studiati per lavorare con maggiore delicatezza prodotti come mele, pomodori, melanzane e zucchine. Le confezionatrici possono essere integrate con sistemi di pesatura, alimentazione, trasporto, etichettatura e fine linea, creando un processo automatico e coordinato dalla ricezione del prodotto fino alla confezione pronta per la distribuzione.', 'samswiss-child' ),
			'video_title'       => __( 'Guarda il confezionamento in rete in funzione', 'samswiss-child' ),
			'video_subtitle'    => __( 'Scopri nei video alcune applicazioni e le diverse possibilità di confezionamento.', 'samswiss-child' ),
			'videos'            => array(
				array(
					'title' => __( 'Confezionamento Arance in Rete', 'samswiss-child' ),
					'desc'  => __( 'Confezionamento automatico in rete con banda ed etichetta per arance.', 'samswiss-child' ),
					'tag'   => __( 'Arance', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/confezionamento-in-rete/ARANCE.RETE.mp4',
				),
				array(
					'title' => __( 'Linea Confezionamento Arance', 'samswiss-child' ),
					'desc'  => __( 'Soluzione ad alta produttività per agrumi ed arance in rete.', 'samswiss-child' ),
					'tag'   => __( 'Agrumi', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/confezionamento-in-rete/ARANCE.mp4',
				),
				array(
					'title' => __( 'Confezionamento Carote', 'samswiss-child' ),
					'desc'  => __( 'Lavorazione e confezionamento in rete per carote e radici.', 'samswiss-child' ),
					'tag'   => __( 'Carote', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/confezionamento-in-rete/CAROTE.mp4',
				),
				array(
					'title' => __( 'Frutti in Linea in Rete', 'samswiss-child' ),
					'desc'  => __( 'Confezionamento in linea continua di frutti singoli e calibrati in rete tubolare.', 'samswiss-child' ),
					'tag'   => __( 'Frutta in linea', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/confezionamento-in-rete/FRUTTI_INLINEA_RETE.mp4',
				),
				array(
					'title' => __( 'Confezionamento Lime', 'samswiss-child' ),
					'desc'  => __( 'Packaging compatto in rete per lime e piccoli agrumi.', 'samswiss-child' ),
					'tag'   => __( 'Lime', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/confezionamento-in-rete/LIME_RETE.mp4',
				),
				array(
					'title' => __( 'Confezionamento Limoni in Rete', 'samswiss-child' ),
					'desc'  => __( 'Rete estrusa o tessuta con banda personalizzata per limoni freschi.', 'samswiss-child' ),
					'tag'   => __( 'Limoni', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/confezionamento-in-rete/LIMONI.RETE.mp4',
				),
				array(
					'title' => __( 'Confezionamento Mele', 'samswiss-child' ),
					'desc'  => __( 'Movimentazione e confezionamento delicato in rete per mele.', 'samswiss-child' ),
					'tag'   => __( 'Mele', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/confezionamento-in-rete/MELE_RETE.mp4',
				),
				array(
					'title' => __( 'Confezionatrice in Rete Automatica', 'samswiss-child' ),
					'desc'  => __( 'Panoramica della tecnologia di confezionamento in rete ad alta cadenza.', 'samswiss-child' ),
					'tag'   => __( 'Panoramica', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/confezionamento-in-rete/RETE.mp4',
				),
			),
			'cta_box_title'     => __( 'Una soluzione completa per la tua produzione', 'samswiss-child' ),
			'cta_box_text'      => __( 'Non forniamo semplicemente una confezionatrice. Partiamo dal prodotto e dalle esigenze produttive per studiare la configurazione più adatta: dalla pesatura al confezionamento in rete, fino alla movimentazione, al fine linea e alla pallettizzazione.', 'samswiss-child' ),
			'cta_box_btn'       => __( 'Richiedi una consulenza', 'samswiss-child' ),
			'why_title'         => __( 'Materiali e soluzioni per ogni esigenza', 'samswiss-child' ),
			'why_intro'         => __( 'La rete non è più soltanto un materiale di confezionamento tradizionale. Oggi esistono diverse soluzioni studiate per combinare visibilità del prodotto, resistenza, comunicazione e sostenibilità. Grazie alla gamma Sorma possiamo proporre differenti tipologie di packaging in rete, scegliendo la soluzione più adatta in funzione del prodotto, del mercato di destinazione e degli obiettivi di sostenibilità:', 'samswiss-child' ),
			'vantaggi_detailed' => array(
				array(
					'title' => __( 'Sormapaper', 'samswiss-child' ),
					'desc'  => __( 'Soluzioni che combinano carta e rete in cellulosa, per una confezione dall\'immagine naturale e distintiva.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Sormacompostabile', 'samswiss-child' ),
					'desc'  => __( 'Packaging sviluppato con materiali compostabili, disponibile per differenti esigenze di confezionamento.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Sormapeel', 'samswiss-child' ),
					'desc'  => __( 'Una soluzione progettata per ridurre sensibilmente l\'utilizzo di plastica, integrando una componente in carta certificata FSC.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Mono Polimero', 'samswiss-child' ),
					'desc'  => __( 'Confezioni realizzate con materiali della stessa famiglia polimerica, pensate per facilitare la riciclabilità del packaging.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Packaging e Materiali Sorma', 'samswiss-child' ),
					'desc'  => __( 'Grazie alla gamma Sorma possiamo proporre differenti tipologie di reti, bande ed elementi di personalizzazione, seguendo anche la fornitura dei materiali di consumo necessari alla produzione.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Personalizzazione e Branding', 'samswiss-child' ),
					'desc'  => __( 'Differenti configurazioni di rete, bande e sistemi di personalizzazione per creare una confezione funzionale e riconoscibile sul punto vendita.', 'samswiss-child' ),
				),
			),
			'quote'             => __( 'La soluzione giusta parte dal prodotto: non esiste una rete adatta a tutto. SAM SA analizza insieme al cliente prodotto, formato, peso, velocità produttiva e obiettivi di packaging, individuando la combinazione più adatta tra macchina e materiale.', 'samswiss-child' ),
			'applicazioni'      => array(
				__( 'Ortofrutta e Agrumi (arance, limoni, mandarini, lime)', 'samswiss-child' ),
				__( 'Patate, Cipolle e Aglio', 'samswiss-child' ),
				__( 'Mele e Frutta Fresca calibrata', 'samswiss-child' ),
				__( 'Pomodori, Zucchine e Melanzane', 'samswiss-child' ),
				__( 'Quarta Gamma e Grande Distribuzione Organizzata (GDO)', 'samswiss-child' ),
				__( 'Packaging Sostenibile: Sormapaper, Sormacompostabile, Sormapeel', 'samswiss-child' ),
			),
			'cover'             => 'theme:assets/img/tecnologie/confezionamento-in-rete.webp',
			'gallery'           => array(),
		),
		'flow-pack'                   => array(
			'icon'              => 'fa-layer-group',
			'title'             => __( 'Flow-Pack', 'samswiss-child' ),
			'subtitle'          => __( 'Confezionamento flessibile per prodotti e formati diversi', 'samswiss-child' ),
			'card_text'         => __( 'Confezionamento orizzontale in flow-pack per la massima protezione e freschezza.', 'samswiss-child' ),
			'intro'             => __( 'Le soluzioni Flow-Pack permettono di confezionare prodotti singoli, sfusi o in vaschetta, adattandosi a differenti dimensioni, formati e capacità produttive. Grazie alla loro versatilità sono adatte a numerose applicazioni alimentari e possono essere configurate in funzione delle caratteristiche specifiche del prodotto.', 'samswiss-child' ),
			'features_title'    => __( 'Flessibilità e semplicità di utilizzo', 'samswiss-child' ),
			'features_intro'    => __( 'Le macchine possono offrire:', 'samswiss-child' ),
			'features'          => array(
				__( 'Cambio formato rapido e intuitivo', 'samswiss-child' ),
				__( 'Gestione tramite touch screen', 'samswiss-child' ),
				__( 'Regolazione della confezione in larghezza e altezza', 'samswiss-child' ),
				__( 'Utilizzo di film stampati', 'samswiss-child' ),
				__( 'Integrazione con stampanti, marcatori ed etichettatrici', 'samswiss-child' ),
				__( 'Collegamento con sistemi di dosaggio e alimentazione automatica', 'samswiss-child' ),
				__( 'Configurazioni compatte anche per spazi produttivi ridotti', 'samswiss-child' ),
			),
			'automation_title'  => __( 'Dalla macchina singola alla linea automatizzata', 'samswiss-child' ),
			'automation_text'   => __( 'Le soluzioni Flow-Pack possono essere utilizzate come macchine indipendenti oppure integrate con sistemi di riempimento, dosaggio e alimentazione automatica, creando una linea di confezionamento completa e ottimizzata.', 'samswiss-child' ),
			'video_title'       => __( 'Guarda le Flow-Pack in funzione', 'samswiss-child' ),
			'video_subtitle'    => __( 'Scopri nei video alcune applicazioni e le diverse possibilità di confezionamento.', 'samswiss-child' ),
			'videos'            => array(
				array(
					'title'    => __( 'Confezionamento Mele', 'samswiss-child' ),
					'desc'     => __( 'Flow-Pack per mele e frutti con film trasparente.', 'samswiss-child' ),
					'tag'      => __( 'Mele', 'samswiss-child' ),
					'src'      => 'uploads:tecnologie/flow-pack/MELE_FLOWPACK.mp4',
				),
				array(
					'title'    => __( 'Hamburger in Flow-Pack', 'samswiss-child' ),
					'desc'     => __( 'Confezionamento rapido e protetto per carne e preparati.', 'samswiss-child' ),
					'tag'      => __( 'Hamburger', 'samswiss-child' ),
					'src'      => 'uploads:tecnologie/flow-pack/hamburgher in flow-pack.mp4',
				),
				array(
					'title'    => __( 'Confezionamento Pomodori', 'samswiss-child' ),
					'desc'     => __( 'Soluzione per pomodori sfusi e a grappolo.', 'samswiss-child' ),
					'tag'      => __( 'Pomodori', 'samswiss-child' ),
					'src'      => 'uploads:tecnologie/flow-pack/FLOW-PACK TOMATOES.mp4',
				),
				array(
					'title'    => __( 'Insalate e Prezzemolo', 'samswiss-child' ),
					'desc'     => __( 'Protezione e confezionamento per aromatiche e IV gamma.', 'samswiss-child' ),
					'tag'      => __( 'Aromatiche', 'samswiss-child' ),
					'src'      => 'uploads:tecnologie/flow-pack/rgd_video_insalate,prezzemolo.mp4',
				),
				array(
					'title'    => __( 'Confezionamento Asparagi', 'samswiss-child' ),
					'desc'     => __( 'Confezionamento delicato per prodotti allungati in mazzo.', 'samswiss-child' ),
					'tag'      => __( 'Asparagi', 'samswiss-child' ),
					'src'      => 'uploads:tecnologie/flow-pack/ASPARAGGI_FLOWPACK.mp4',
				),
				array(
					'title'    => __( 'Peperone singolo e vaschette', 'samswiss-child' ),
					'desc'     => __( 'Versatilità su pezzo singolo o su vassoio.', 'samswiss-child' ),
					'tag'      => __( 'Peperoni', 'samswiss-child' ),
					'src'      => 'uploads:tecnologie/flow-pack/SINGLE Pepper and trays_FLOWPACK.mp4',
				),
				array(
					'title'    => __( 'Confezionamento Insalata', 'samswiss-child' ),
					'desc'     => __( 'Flusso continuo per foglie ed erbe.', 'samswiss-child' ),
					'tag'      => __( 'Insalata', 'samswiss-child' ),
					'src'      => 'uploads:tecnologie/flow-pack/INSALATA FLOW-PACK.mp4',
				),
				array(
					'title'    => __( 'Okra senza vassoio', 'samswiss-child' ),
					'desc'     => __( 'Confezionamento trayless ad alta efficienza.', 'samswiss-child' ),
					'tag'      => __( 'Trayless', 'samswiss-child' ),
					'src'      => 'uploads:tecnologie/flow-pack/Trayless Okra  packaging.mp4',
				),
				array(
					'title'    => __( 'VR4 Elektra S — Pomodori', 'samswiss-child' ),
					'desc'     => __( 'Macchina elettronica per confezionamento continuo.', 'samswiss-child' ),
					'tag'      => __( 'VR4 Elektra', 'samswiss-child' ),
					'src'      => 'uploads:tecnologie/flow-pack/FLOW-PACK VR4 Elektra S  tomatoes.MOV',
				),
				array(
					'title'    => __( 'RGD MAPE VR-6 Genio — Mele sfuse', 'samswiss-child' ),
					'desc'     => __( 'Gestione automatizzata senza vaschetta per ortofrutta.', 'samswiss-child' ),
					'tag'      => __( 'VR-6 Genio', 'samswiss-child' ),
					'src'      => 'uploads:tecnologie/flow-pack/RGDMAPE VR-6 Genio loose apples.MOV',
				),
				array(
					'title'    => __( 'Flow-Pack VR6 — Avocado', 'samswiss-child' ),
					'desc'     => __( 'Confezionamento frutti esotici e avocado.', 'samswiss-child' ),
					'tag'      => __( 'Avocado', 'samswiss-child' ),
					'src'      => 'uploads:tecnologie/flow-pack/Avocados_FLOWPACKVR6.mp4',
				),
				array(
					'title'    => __( 'Pannocchie senza vassoio', 'samswiss-child' ),
					'desc'     => __( 'Trayless packaging per cobs di mais.', 'samswiss-child' ),
					'tag'      => __( 'Pannocchie', 'samswiss-child' ),
					'src'      => 'uploads:tecnologie/flow-pack/trayless cobs of corn packaging.mp4',
				),
			),
			'cta_box_title'     => __( 'Raccontaci cosa vuoi confezionare.', 'samswiss-child' ),
			'cta_box_text'      => __( 'Studiamo insieme la configurazione più adatta al tuo prodotto e alla tua produzione.', 'samswiss-child' ),
			'cta_box_btn'       => __( 'Richiedi una consulenza', 'samswiss-child' ),
			'why_title'         => __( 'Perché scegliere il confezionamento Flow-Pack?', 'samswiss-child' ),
			'why_intro'         => __( 'Il Flow-Pack è una soluzione versatile che permette di confezionare prodotti di forme e dimensioni diverse in modo rapido, ordinato e professionale.', 'samswiss-child' ),
			'vantaggi_detailed' => array(
				array(
					'title' => __( 'Versatilità', 'samswiss-child' ),
					'desc'  => __( 'Adatto a numerosi prodotti e formati.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Protezione del prodotto', 'samswiss-child' ),
					'desc'  => __( 'La confezione protegge da contaminazioni e manipolazioni.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Ottima presentazione', 'samswiss-child' ),
					'desc'  => __( 'Confezioni curate e adatte alla vendita.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Elevata produttività', 'samswiss-child' ),
					'desc'  => __( 'Ideale anche per processi automatizzati.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Riduzione degli sprechi', 'samswiss-child' ),
					'desc'  => __( 'Utilizzo ottimizzato del materiale di confezionamento.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Ampia scelta di materiali', 'samswiss-child' ),
					'desc'  => __( 'Film tradizionali, riciclabili, biodegradabili e compostabili, in funzione dell’applicazione.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Facile integrazione', 'samswiss-child' ),
					'desc'  => __( 'Può essere collegato a sistemi di pesatura, dosaggio, alimentazione ed etichettatura.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Grande flessibilità', 'samswiss-child' ),
					'desc'  => __( 'Possibilità di lavorare prodotti singoli, sfusi o in vaschetta.', 'samswiss-child' ),
				),
			),
			'quote'             => __( 'Una tecnologia flessibile che si adatta al prodotto, non il contrario.', 'samswiss-child' ),
			'cover'             => 'theme:assets/img/tecnologie/flow-pack.jpeg',
			'gallery'           => array( 5127, 5133 ),
		),
		'peso-combinato'              => array(
			'icon'              => 'fa-scale-balanced',
			'title'             => __( 'Peso Combinato', 'samswiss-child' ),
			'subtitle'          => __( 'Più precisione. Meno prodotto regalato. Più produttività.', 'samswiss-child' ),
			'card_text'         => __( 'Tecnologia avanzata che combina più pesate per raggiungere il peso ideale con il minimo scarto.', 'samswiss-child' ),
			'intro'             => __( 'Le soluzioni a peso combinato Bulltec sono progettate per automatizzare e ottimizzare il confezionamento di ortaggi e prodotti freschi in vaschette, cestini, vassoi, casse o reti a peso garantito. Il sistema pesa singolarmente il prodotto e, attraverso uno specifico software, calcola automaticamente la migliore combinazione di pezzi per raggiungere il peso desiderato, riducendo al minimo il sovrappeso in ogni confezione.', 'samswiss-child' ),
			'automation_title'  => __( 'Dal prodotto sfuso alla confezione finale', 'samswiss-child' ),
			'automation_text'   => __( 'Dal prodotto sfuso a vaschette, cassette, cestini, vassoi, reti e altri formati di confezionamento, il sistema seleziona automaticamente la combinazione più efficace per raggiungere il peso target con il minor eccesso possibile. Una tecnologia che può raggiungere fino a 45 confezioni al minuto.', 'samswiss-child' ),
			'features_title'    => __( 'Alte prestazioni per prodotti freschi', 'samswiss-child' ),
			'features_intro'    => __( 'La tecnologia Bulltec è particolarmente indicata per:', 'samswiss-child' ),
			'features'          => array(
				__( 'Zucchine e cetrioli', 'samswiss-child' ),
				__( 'Pomodori e pomodorini a grappolo', 'samswiss-child' ),
				__( 'Melanzane e peperoni', 'samswiss-child' ),
				__( 'Finocchi e carote', 'samswiss-child' ),
				__( 'Patate e cipolle', 'samswiss-child' ),
				__( 'Uva da tavola e frutta fresca', 'samswiss-child' ),
				__( 'Ortaggi di forme e calibri differenti', 'samswiss-child' ),
			),
			'video_title'       => __( 'Guarda il Peso Combinato in funzione', 'samswiss-child' ),
			'video_subtitle'    => __( 'Scopri nei video le applicazioni Bulltec su diverse tipologie di ortofrutta.', 'samswiss-child' ),
			'videos'            => array(
				array(
					'title' => __( 'Zucchine — Peso Combinato Smart', 'samswiss-child' ),
					'desc'  => __( 'Pesatura combinata e dosaggio rapido per zucchine.', 'samswiss-child' ),
					'tag'   => __( 'Zucchine', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/peso-combinato/ZUCCHINE_PESOCOMBINATO SMART.mp4',
				),
				array(
					'title' => __( 'Peperoni a peso combinato', 'samswiss-child' ),
					'desc'  => __( 'Calcolo della combinazione ideale per peperoni.', 'samswiss-child' ),
					'tag'   => __( 'Peperoni', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/peso-combinato/PEPERONI_PESOCOMBINATO.mp4',
				),
				array(
					'title' => __( 'Lavorazione Finocchi', 'samswiss-child' ),
					'desc'  => __( 'Pesatura delicata e combinata per finocchi.', 'samswiss-child' ),
					'tag'   => __( 'Finocchi', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/peso-combinato/FINOCCHI_PESOCOMBINATO.mp4',
				),
				array(
					'title' => __( 'Pesatura e dosaggio Zucca', 'samswiss-child' ),
					'desc'  => __( 'Gestione pezzi grandi e irregolari con peso combinato.', 'samswiss-child' ),
					'tag'   => __( 'Zucca', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/peso-combinato/ZUCCA_PESOCOMBINATO.mp4',
				),
				array(
					'title' => __( 'Pomodoro a grappolo giallo', 'samswiss-child' ),
					'desc'  => __( 'Precisione e delicatezza su grappoli e pomodori.', 'samswiss-child' ),
					'tag'   => __( 'Pomodori', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/peso-combinato/sfera-grappolo giallo-002.mp4',
				),
				array(
					'title' => __( 'Masterfruit — Confezionamento Zucchine', 'samswiss-child' ),
					'desc'  => __( 'Linea in produzione Masterfruit su zucchine.', 'samswiss-child' ),
					'tag'   => __( 'Masterfruit', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/peso-combinato/MASTERFRUIT-zucchine (1).mp4',
				),
				array(
					'title' => __( 'Ortomi — Confezionamento e pesatura', 'samswiss-child' ),
					'desc'  => __( 'Impianto di confezionamento e pesatura automatica.', 'samswiss-child' ),
					'tag'   => __( 'Ortomi', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/peso-combinato/ORTOMI-CONFEZIONAMENTO (1).mp4',
				),
				array(
					'title' => __( 'Impianto Palumbo in lavorazione', 'samswiss-child' ),
					'desc'  => __( 'Linea Bulltec in ambiente di produzione reale.', 'samswiss-child' ),
					'tag'   => __( 'Palumbo', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/peso-combinato/Palumbo-in lavorazione.mp4',
				),
				array(
					'title' => __( 'Naturaiblea — Impianto in lavorazione', 'samswiss-child' ),
					'desc'  => __( 'Pesatura ad alta cadenza per ortaggi biologici e freschi.', 'samswiss-child' ),
					'tag'   => __( 'Naturaiblea', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/peso-combinato/Naturaiblea-in lavorazione-03-2025 (1).mp4',
				),
				array(
					'title' => __( 'Scarico e pesatura peperoni', 'samswiss-child' ),
					'desc'  => __( 'Fase di alimentazione e scarico controllato Masterfruit.', 'samswiss-child' ),
					'tag'   => __( 'Peperoni', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/peso-combinato/masterfruit-scarico peperoni.mp4',
				),
				array(
					'title' => __( 'Lavorazione e pesata finocchi (dettaglio)', 'samswiss-child' ),
					'desc'  => __( 'Ciclo continuo di pesatura e smistamento finocchi.', 'samswiss-child' ),
					'tag'   => __( 'Finocchi', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/peso-combinato/fino-lavorazione finocchio.mp4',
				),
				array(
					'title' => __( 'Panoramica Peso Combinato', 'samswiss-child' ),
					'desc'  => __( 'Carrellata delle teste di pesatura e del sistema integrato.', 'samswiss-child' ),
					'tag'   => __( 'Panoramica', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/peso-combinato/carrellata peso combo.mp4',
				),
			),
			'cta_box_title'     => __( 'Hai un prodotto da pesare o confezionare?', 'samswiss-child' ),
			'cta_box_text'      => __( 'Raccontaci cosa lavori: studiamo insieme la soluzione più adatta alla tua produzione.', 'samswiss-child' ),
			'cta_box_btn'       => __( 'Richiedi una consulenza', 'samswiss-child' ),
			'why_title'         => __( 'Perché scegliere il peso combinato?', 'samswiss-child' ),
			'why_intro'         => __( 'I principali vantaggi della tecnologia a peso combinato Bulltec per il tuo stabilimento:', 'samswiss-child' ),
			'vantaggi_detailed' => array(
				array(
					'title' => __( 'Riduzione del prodotto in eccesso', 'samswiss-child' ),
					'desc'  => __( 'Minore sovrappeso in ogni confezione e massimo controllo dei costi di produzione.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Maggiore produttività', 'samswiss-child' ),
					'desc'  => __( 'Fino a 45 confezioni al minuto con sensibile riduzione del lavoro manuale ripetitivo.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Peso preciso e costante', 'samswiss-child' ),
					'desc'  => __( 'Precisione garantita e conformità di peso confezione dopo confezione.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Movimentazione delicata', 'samswiss-child' ),
					'desc'  => __( 'Trattamento accurato del prodotto, ideale anche per ortaggi sensibili e delicati.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Flessibilità di pezzatura', 'samswiss-child' ),
					'desc'  => __( 'Possibilità di lavorare con efficienza prodotti di forme, dimensioni e pesi differenti.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Impianti personalizzabili', 'samswiss-child' ),
					'desc'  => __( 'Soluzioni su misura integrabili perfettamente nelle linee di confezionamento esistenti.', 'samswiss-child' ),
				),
			),
			'quote'             => __( 'Più precisione. Meno prodotto regalato. Più produttività.', 'samswiss-child' ),
			'cover'             => 'theme:assets/img/tecnologie/peso-combinato.jpeg',
			'gallery'           => array( 26155 ),
		),
		'pesatura-ed-etichettatura'   => array(
			'icon'              => 'fa-weight-scale',
			'title'             => __( 'Pesatura ed Etichettatura', 'samswiss-child' ),
			'subtitle'          => __( 'Precisione, controllo e tracciabilità direttamente in linea', 'samswiss-child' ),
			'card_text'         => __( 'Sistemi professionali di pesatura dinamica, controllo peso ed etichettatura automatica.', 'samswiss-child' ),
			'intro'             => __( 'SAM propone soluzioni professionali per la pesatura dinamica, il controllo peso e l’etichettatura automatica, integrabili all’interno delle linee di confezionamento. Sistemi progettati per automatizzare il processo, aumentare la precisione e garantire una corretta identificazione e tracciabilità del prodotto.', 'samswiss-child' ),
			'features_title'    => __( 'Funzionalità e Tecnologie in Linea', 'samswiss-child' ),
			'features_intro'    => __( 'Le peso-prezzatrici automatiche rilevano il peso di ogni confezione e generano l\'etichetta completa:', 'samswiss-child' ),
			'features'          => array(
				__( 'Lavorazioni a peso variabile e peso fisso con calcolo immediato', 'samswiss-child' ),
				__( 'Stampa di lotti, scadenze, date, codici a barre e QR Code', 'samswiss-child' ),
				__( 'Controllo peso continuo con soglie minime/massime ed espulsione non conformi', 'samswiss-child' ),
				__( 'Etichettatura superiore, inferiore, laterale o a sigillo', 'samswiss-child' ),
			),
			'automation_title'  => __( 'Soluzioni Integrate', 'samswiss-child' ),
			'automation_text'   => __( 'Pesatura, controllo ed etichettatura in un unico flusso continuo: Confezionamento → Pesatura dinamica → Controllo peso → Etichettatura → Fine linea. SAM studia la configurazione più adatta in funzione di prodotto, cadenza e spazi.', 'samswiss-child' ),
			'video_title'       => __( 'Guarda la Pesatura ed Etichettatura in funzione', 'samswiss-child' ),
			'video_subtitle'    => __( 'Scopri nei video le peso-prezzatrici e i sistemi di controllo peso in produzione reale.', 'samswiss-child' ),
			'videos'            => array(
				array(
					'title' => __( 'Peso-Prezzatura automatica in linea', 'samswiss-child' ),
					'desc'  => __( 'Rilevazione dinamica del peso e generazione automatica dell\'etichetta.', 'samswiss-child' ),
					'tag'   => __( 'Peso-Prezzatura', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/pesatura-ed-etichettatura/Pesoprezzatrici.mp4',
				),
				array(
					'title' => __( 'Controllo peso dinamico ed etichettatura', 'samswiss-child' ),
					'desc'  => __( 'Verifica tolleranza peso e applicazione etichetta a passaggio continuo.', 'samswiss-child' ),
					'tag'   => __( 'Controllo Peso', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/pesatura-ed-etichettatura/PesoPrezzatrici2.mp4',
				),
				array(
					'title' => __( 'Applicazione etichette ad alta velocità', 'samswiss-child' ),
					'desc'  => __( 'Stampa e applicazione precisa di dati variabili, barcode e QR code.', 'samswiss-child' ),
					'tag'   => __( 'Etichettatura', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/pesatura-ed-etichettatura/pesoprezzatrici3.mp4',
				),
			),
			'cta_box_title'     => __( 'Contattaci e raccontaci il tuo progetto', 'samswiss-child' ),
			'cta_box_text'      => __( 'SAM studia la configurazione più adatta in funzione del prodotto, della confezione, della produttività richiesta e degli spazi disponibili.', 'samswiss-child' ),
			'cta_box_btn'       => __( 'Richiedi una consulenza', 'samswiss-child' ),
			'why_title'         => __( 'Perché scegliere i sistemi di pesatura ed etichettatura?', 'samswiss-child' ),
			'why_intro'         => __( 'I principali vantaggi dell\'integrazione tra pesatura e stampa etichette in linea:', 'samswiss-child' ),
			'vantaggi_detailed' => array(
				array(
					'title' => __( 'Pesare ed etichettare in un unico processo', 'samswiss-child' ),
					'desc'  => __( 'Rilevazione istantanea del peso e stampa immediata delle informazioni commerciali.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Tracciabilità e conformità totale', 'samswiss-child' ),
					'desc'  => __( 'Gestione automatica di lotti, scadenze, ingredienti, codici a barre e QR code.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Controllo automatico di ogni confezione', 'samswiss-child' ),
					'desc'  => __( 'Identificazione e scarto automatico dei prodotti fuori tolleranza minima o massima.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Continuità e riduzione degli errori', 'samswiss-child' ),
					'desc'  => __( 'Eliminazione degli interventi manuali con conseguente aumento della produttività.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Flessibilità di applicazione', 'samswiss-child' ),
					'desc'  => __( 'Adattabile a qualsiasi posizione di etichetta: sopra, sotto, laterale o avvolgente.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Massima integrabilità', 'samswiss-child' ),
					'desc'  => __( 'Installabili come stazioni autonome o inseribili in linee di confezionamento complete.', 'samswiss-child' ),
				),
			),
			'quote'             => __( 'Precisione, controllo e tracciabilità direttamente in linea.', 'samswiss-child' ),
			'applicazioni'      => array(
				__( 'Ortofrutta confezionata', 'samswiss-child' ),
				__( 'Carni, salumi e formaggi', 'samswiss-child' ),
				__( 'Gastronomia e piatti pronti', 'samswiss-child' ),
				__( 'Prodotti da forno e pasticceria', 'samswiss-child' ),
				__( 'IV Gamma e surgelati', 'samswiss-child' ),
				__( 'Prodotti a peso variabile per la GDO', 'samswiss-child' ),
			),
			'cover'             => 'theme:assets/img/tecnologie/pesatura-ed-etichettatura.jpeg',
			'gallery'           => array( 26155, 26162, 26137, 26131 ),
		),
		'confezionamento-stretch'     => array(
			'icon'              => 'fa-arrows-left-right-to-line',
			'title'             => __( 'Confezionamento Stretch', 'samswiss-child' ),
			'subtitle'          => __( 'Semplice, versatile e pensato per valorizzare il prodotto fresco', 'samswiss-child' ),
			'card_text'         => __( 'Soluzione pratica ed efficiente per avvolgere prodotti freschi e freschissimi in vaschetta con film estensibile.', 'samswiss-child' ),
			'intro'             => __( 'Il confezionamento Stretch è una soluzione pratica ed efficiente per avvolgere prodotti freschi e freschissimi, sia in vaschetta sia, per alcune applicazioni, direttamente sul prodotto. Il film estensibile avvolge la confezione adattandosi alla forma del prodotto e viene chiuso nella parte inferiore della vaschetta, garantendo una presentazione ordinata, brillante e trasparente. SAM SA propone soluzioni professionali per il confezionamento Stretch destinate a industrie alimentari, centri di confezionamento, supermercati, macellerie, pescherie, gastronomie e reparti ortofrutta, studiando la configurazione più adatta in funzione del prodotto, dei volumi produttivi e dei formati da confezionare.', 'samswiss-child' ),
			'features_title'    => __( 'Una tecnologia adatta a numerosi prodotti', 'samswiss-child' ),
			'features_intro'    => __( 'La grande flessibilità della tecnologia permette di lavorare differenti tipologie e dimensioni di vaschette, rendendola particolarmente interessante per chi gestisce numerosi formati durante la produzione:', 'samswiss-child' ),
			'features'          => array(
				__( 'Carne rossa e bianca', 'samswiss-child' ),
				__( 'Pollame', 'samswiss-child' ),
				__( 'Pesce', 'samswiss-child' ),
				__( 'Formaggi e prodotti caseari', 'samswiss-child' ),
				__( 'Frutta e verdura', 'samswiss-child' ),
				__( 'Gastronomia', 'samswiss-child' ),
				__( 'Pane e prodotti da forno', 'samswiss-child' ),
				__( 'Prodotti freschi e freschissimi', 'samswiss-child' ),
			),
			'automation_title'  => __( 'Soluzioni automatiche per ogni esigenza produttiva', 'samswiss-child' ),
			'automation_text'   => __( 'SAM propone confezionatrici Stretch automatiche adatte sia a realtà che desiderano automatizzare il confezionamento precedentemente eseguito manualmente, sia a reparti e industrie con produzioni più elevate. Le soluzioni possono essere integrate, in funzione dell’applicazione, con sistemi di pesatura, prezzatura ed etichettatura, creando una postazione di confezionamento completa ed efficiente.', 'samswiss-child' ),
			'video_title'       => __( 'Guarda il confezionamento Stretch in funzione', 'samswiss-child' ),
			'video_subtitle'    => __( 'Scopri nei video alcune applicazioni e la versatilità del confezionamento con film estensibile.', 'samswiss-child' ),
			'videos'            => array(
				array(
					'title' => __( 'Confezionamento Stretch Automatico', 'samswiss-child' ),
					'desc'  => __( 'Processo automatico di confezionamento in vaschetta con film estensibile.', 'samswiss-child' ),
					'tag'   => __( 'Automatico', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/confezionamento-stretch/stretch_packaging.mp4',
				),
				array(
					'title' => __( 'Stretch Packaging per Frutta', 'samswiss-child' ),
					'desc'  => __( 'Confezionamento trasparente e brillante per vaschette di frutta fresca.', 'samswiss-child' ),
					'tag'   => __( 'Frutta', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/confezionamento-stretch/stretch_packaging_fruit.mp4',
				),
				array(
					'title' => __( 'Carne, Frutta e Verdura in Stretch', 'samswiss-child' ),
					'desc'  => __( 'Versatilità applicativa su carne, ortaggi e prodotti freschi di differenti formati.', 'samswiss-child' ),
					'tag'   => __( 'Freschi & Carni', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/confezionamento-stretch/stretch_packaging_meat_fruit_veg.mp4',
				),
				array(
					'title' => __( 'Avvolgimento Stretch ad Alta Velocità', 'samswiss-child' ),
					'desc'  => __( 'Avvolgimento preciso e chiusura inferiore della vaschetta a ciclo continuo.', 'samswiss-child' ),
					'tag'   => __( 'Avvolgimento', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/confezionamento-stretch/stretch_wrapping.mp4',
				),
			),
			'cta_box_title'     => __( 'Dalla macchina al confezionamento finito', 'samswiss-child' ),
			'cta_box_text'      => __( 'Ogni prodotto ha caratteristiche diverse: analizziamo insieme al cliente prodotto, vaschetta, film, formato e capacità produttiva, individuando la soluzione più adatta e seguendo il progetto fino alla messa in funzione. Completiamo la fornitura con materiali di consumo, ricambi e assistenza tecnica su tutto il territorio svizzero.', 'samswiss-child' ),
			'cta_box_btn'       => __( 'Richiedi una consulenza', 'samswiss-child' ),
			'why_title'         => __( 'Perché scegliere il confezionamento Stretch?', 'samswiss-child' ),
			'why_intro'         => __( 'Il confezionamento Stretch è una soluzione pratica ed efficiente pensata per proteggere e valorizzare il prodotto fresco sul punto vendita:', 'samswiss-child' ),
			'vantaggi_detailed' => array(
				array(
					'title' => __( 'Protezione del prodotto', 'samswiss-child' ),
					'desc'  => __( 'Il film mantiene il prodotto all’interno della vaschetta e contribuisce a proteggerlo dalle contaminazioni esterne durante movimentazione, esposizione e vendita.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Presentazione ottimale', 'samswiss-child' ),
					'desc'  => __( 'Trasparenza, brillantezza e aderenza del film consentono di mantenere il prodotto ben visibile e valorizzarne freschezza e qualità sul punto vendita.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Grande flessibilità', 'samswiss-child' ),
					'desc'  => __( 'Una stessa soluzione può essere utilizzata per differenti prodotti, forme e dimensioni di vaschette.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Processo semplice e veloce', 'samswiss-child' ),
					'desc'  => __( 'La tecnologia Stretch consente il confezionamento senza necessità di portare preventivamente la macchina alle temperature tipiche di altri sistemi di saldatura, facilitando l’avvio della produzione.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Ottimizzazione dei materiali', 'samswiss-child' ),
					'desc'  => __( 'L’elevata estensibilità del film permette di utilizzare quantità di materiale ottimizzate in funzione della confezione.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Film e vaschette: gamma completa', 'samswiss-child' ),
					'desc'  => __( 'SAM affianca il cliente nella fornitura di film neutri o stampati, tradizionali, a base PE, compostabili o riciclabili, compatibili anche con vaschette in cartone, cellulosa, PET ed etichette.', 'samswiss-child' ),
				),
			),
			'quote'             => __( 'Contattaci e raccontaci cosa vuoi confezionare: studiamo insieme la soluzione Stretch più adatta alla tua produzione.', 'samswiss-child' ),
			'applicazioni'      => array(
				__( 'Carne rossa, carne bianca e pollame', 'samswiss-child' ),
				__( 'Pesce fresco e preparazioni ittiche', 'samswiss-child' ),
				__( 'Formaggi e prodotti caseari', 'samswiss-child' ),
				__( 'Frutta e verdura fresca', 'samswiss-child' ),
				__( 'Gastronomia e piatti pronti', 'samswiss-child' ),
				__( 'Pane e prodotti da forno', 'samswiss-child' ),
				__( 'Supermercati, macellerie, pescherie e GDO', 'samswiss-child' ),
			),
			'cover'             => 'theme:assets/img/tecnologie/confezionamento-stretch.jpeg',
			'gallery'           => array(),
		),
		'sigillatura'                 => array(
			'icon'              => 'fa-stamp',
			'title'             => __( 'Confezionamento con Sigillatura', 'samswiss-child' ),
			'subtitle'          => __( 'Una chiusura sicura per proteggere e valorizzare il prodotto', 'samswiss-child' ),
			'card_text'         => __( 'Sistemi di sigillatura termosaldante per vaschette e contenitori sicuri e affidabili.', 'samswiss-child' ),
			'intro'             => __( 'La termosigillatura è una tecnologia di confezionamento che permette di chiudere vaschette e contenitori mediante l’applicazione di un film termosaldante. Una soluzione affidabile e versatile, utilizzata in numerosi settori alimentari per ottenere confezioni ben chiuse, protette, igieniche e pronte per la distribuzione e la vendita. SAM propone soluzioni di sigillatura studiate in funzione del prodotto, del contenitore, del film utilizzato e della capacità produttiva richiesta.', 'samswiss-child' ),
			'features_title'    => __( 'Per ogni produzione, la giusta soluzione', 'samswiss-child' ),
			'features_intro'    => __( 'Dalle piccole produzioni artigianali alle realtà industriali, la termosigillatura può essere gestita con sistemi su misura:', 'samswiss-child' ),
			'features'          => array(
				__( 'Sistemi Manuali – Per produzioni contenute e frequenti cambi formato con la massima semplicità.', 'samswiss-child' ),
				__( 'Sistemi Semiautomatici – Per aumentare produttività e uniformità del confezionamento mantenendo grande flessibilità.', 'samswiss-child' ),
				__( 'Sistemi Automatici – Per produzioni più elevate e perfetta integrazione all\'interno di linee complete.', 'samswiss-child' ),
				__( 'Flessibilità di Formato – Cambio stampo rapido e regolazione millimetrica della saldatura per qualsiasi tipologia di vaschetta.', 'samswiss-child' ),
			),
			'automation_title'  => __( 'Non solo una macchina, ma un sistema di confezionamento', 'samswiss-child' ),
			'automation_text'   => __( 'Per ottenere una sigillatura efficace è fondamentale che macchina, stampo, vaschetta e film lavorino correttamente insieme. SAM Swiss valuta: tipologia di prodotto, formato e materiale della vaschetta, film più adatto all\'applicazione, dimensioni e numero di formati, capacità produttiva richiesta, livello di automazione ed eventuale integrazione con altre fasi della linea.', 'samswiss-child' ),
			'video_title'       => __( 'Guarda la termosigillatura in funzione', 'samswiss-child' ),
			'video_subtitle'    => __( 'Scopri nei video le nostre soluzioni di sigillatura manuali da banco, semiautomatiche e su linee continue.', 'samswiss-child' ),
			'videos'            => array(
				array(
					'title' => __( 'Termosigillatura e saldatura film', 'samswiss-child' ),
					'desc'  => __( 'Ciclo di termosaldatura vaschette con chiusura ermetica e tenuta perfetta.', 'samswiss-child' ),
					'tag'   => __( 'Sigillatura', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/sigillatura/sigillatura.mp4',
				),
				array(
					'title' => __( 'Termosigillatrice semiautomatica VG 500', 'samswiss-child' ),
					'desc'  => __( 'Confezionamento professionale con cambio rapido stampo e iniezione gas MAP.', 'samswiss-child' ),
					'tag'   => __( 'VG 500', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/sigillatura/vg-500.mp4',
				),
				array(
					'title' => __( 'Termosigillatrice manuale SSM 400', 'samswiss-child' ),
					'desc'  => __( 'Sigillatura manuale da banco in acciaio inox per piccole e medie produzioni.', 'samswiss-child' ),
					'tag'   => __( 'SSM 400', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/sigillatura/ssm-400.mp4',
				),
				array(
					'title' => __( 'Chiusura ermetica e taglio perimetrale', 'samswiss-child' ),
					'desc'  => __( 'Saldatura precisa con finitura perfetta del bordo vaschetta senza sfrido.', 'samswiss-child' ),
					'tag'   => __( 'Top Seal', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/sigillatura/sigillatura-top.mp4',
				),
			),
			'cta_box_title'     => __( 'Studiamo la soluzione adatta al tuo prodotto', 'samswiss-child' ),
			'cta_box_text'      => __( 'Dalla singola termosigillatrice alla soluzione integrata, SAM Swiss affianca il cliente nella scelta della tecnologia, dei materiali e della configurazione più adatta alla propria produzione.', 'samswiss-child' ),
			'cta_box_btn'       => __( 'Contattaci per il tuo progetto', 'samswiss-child' ),
			'why_title'         => __( 'I vantaggi della sigillatura', 'samswiss-child' ),
			'vantaggi_cards'    => array(
				array(
					'title' => __( 'Tenuta e sicurezza', 'samswiss-child' ),
					'text'  => __( 'Una corretta termosaldatura permette di ottenere una chiusura stabile, ermetica o leak-proof, riducendo il rischio di aperture e fuoriuscite durante trasporto e movimentazione.', 'samswiss-child' ),
					'icon'  => 'fa-shield-halved',
				),
				array(
					'title' => __( 'Protezione del prodotto', 'samswiss-child' ),
					'text'  => __( 'La confezione protegge l\'alimento da contaminazioni esterne, manipolazioni e urti, mantenendolo protetto lungo tutto il percorso fino al punto vendita.', 'samswiss-child' ),
					'icon'  => 'fa-box',
				),
				array(
					'title' => __( 'Visibilità e presentazione', 'samswiss-child' ),
					'text'  => __( 'I film trasparenti ad alta brillantezza permettono al consumatore di vedere chiaramente il prodotto, valorizzandone aspetto, freschezza e qualità.', 'samswiss-child' ),
					'icon'  => 'fa-eye',
				),
				array(
					'title' => __( 'Massima versatilità', 'samswiss-child' ),
					'text'  => __( 'La sigillatura può essere applicata a numerosi formati e materiali di vaschette e contenitori, adattandosi a differenti tipologie merceologiche.', 'samswiss-child' ),
					'icon'  => 'fa-layer-group',
				),
				array(
					'title' => __( 'Resistenza e robustezza', 'samswiss-child' ),
					'text'  => __( 'Film e vaschetta formano una confezione resistente e adatta alle successive fasi di movimentazione, stoccaggio e distribuzione refrigerata.', 'samswiss-child' ),
					'icon'  => 'fa-cubes',
				),
				array(
					'title' => __( 'Materiali e sostenibilità', 'samswiss-child' ),
					'text'  => __( 'Compatibilità con materiali riciclabili, bio, compostabili e film con spessori ottimizzati per ridurre l\'impatto ambientale.', 'samswiss-child' ),
					'icon'  => 'fa-leaf',
				),
			),
			'quote'             => __( 'Tutto il necessario per il tuo confezionamento: vaschette, film termosaldanti, ricambi e assistenza tecnica su tutto il territorio svizzero.', 'samswiss-child' ),
			'applicazioni'      => array(
				__( 'Vaschette e contenitori per diverse applicazioni alimentari', 'samswiss-child' ),
				__( 'Vaschette ecosostenibili e soluzioni a ridotto impatto ambientale', 'samswiss-child' ),
				__( 'Film termosaldanti standard, barriera, microforati e pelabili', 'samswiss-child' ),
				__( 'Gastronomia, macellerie, pastifici e piatti pronti', 'samswiss-child' ),
				__( 'Take-away, catering, laboratori e centri di confezionamento', 'samswiss-child' ),
				__( 'Ricambi, materiali di consumo e supporto tecnico dedicato SAM Swiss', 'samswiss-child' ),
			),
			'cover'             => 'theme:assets/img/tecnologie/sigillatura.jpeg',
			'gallery'           => array( 27030, 27003, 14650, 14624 ),
		),
		'map'                         => array(
			'icon'              => 'fa-wind',
			'title'             => __( 'Confezionamento in Atmosfera Modificata – MAP', 'samswiss-child' ),
			'subtitle'          => __( 'Più freschezza. Più protezione. Più shelf life.', 'samswiss-child' ),
			'card_text'         => __( 'Confezionamento in atmosfera protettiva per prolungare la shelf-life senza alterare il prodotto.', 'samswiss-child' ),
			'intro'             => __( 'Il confezionamento in atmosfera modificata (MAP – Modified Atmosphere Packaging) è una tecnologia studiata per preservare più a lungo la qualità, la freschezza e le caratteristiche del prodotto alimentare. Durante il confezionamento, l\'aria presente all\'interno della confezione viene sostituita con una miscela controllata di gas alimentari, definita in funzione del prodotto e delle sue specifiche esigenze di conservazione. Il risultato è un packaging in grado di rallentare i naturali processi di deterioramento, mantenendo più a lungo aspetto, consistenza e qualità del prodotto.', 'samswiss-child' ),
			'features_title'    => __( 'Come funziona il confezionamento MAP', 'samswiss-child' ),
			'features_intro'    => __( 'Il processo MAP utilizza principalmente tre gas alimentari studiati in funzione del prodotto:', 'samswiss-child' ),
			'features'          => array(
				__( 'Azoto (N₂) – Gas inerte per sostituire l\'ossigeno e limitare i fenomeni di ossidazione.', 'samswiss-child' ),
				__( 'Anidride carbonica (CO₂) – Rallenta lo sviluppo dei microrganismi responsabili del deterioramento.', 'samswiss-child' ),
				__( 'Ossigeno (O₂) – Mantenuto o aggiunto in percentuali controllate per preservare caratteristiche e colore.', 'samswiss-child' ),
				__( 'Miscela calibrata – Studiata su misura per alimento, vaschetta, temperatura e shelf life.', 'samswiss-child' ),
			),
			'automation_title'  => __( 'Non solo una macchina, ma una soluzione completa', 'samswiss-child' ),
			'automation_text'   => __( 'Un buon confezionamento MAP nasce dalla corretta combinazione tra prodotto, macchina, gas, vaschetta e film. SAM affianca il cliente integrando l\'intera linea: Pesatura e dosaggio → Riempimento → Confezionamento MAP → Controllo → Etichettatura → Fine linea e pallettizzazione.', 'samswiss-child' ),
			'video_title'       => __( 'Guarda il confezionamento MAP in funzione', 'samswiss-child' ),
			'video_subtitle'    => __( 'Scopri nei video le nostre soluzioni di confezionamento in atmosfera modificata.', 'samswiss-child' ),
			'videos'            => array(
				array(
					'title' => __( 'Confezionamento MAP in vaschetta', 'samswiss-child' ),
					'desc'  => __( 'Ciclo di sigillatura con iniezione di miscela gas in vaschetta.', 'samswiss-child' ),
					'tag'   => __( 'Vaschette', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/map/MAP_PACKAGING.mp4',
				),
				array(
					'title' => __( 'Saldatura e iniezione gas protettivo', 'samswiss-child' ),
					'desc'  => __( 'Evacuazione aria e iniezione calibrata prima della sigillatura ermetica.', 'samswiss-child' ),
					'tag'   => __( 'Ciclo Gas', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/map/MAP_PACKAGING2.mp4',
				),
				array(
					'title' => __( 'Atmosfera Modificata per alimenti freschi', 'samswiss-child' ),
					'desc'  => __( 'Packaging ad alta protezione per preservare freschezza e shelf life.', 'samswiss-child' ),
					'tag'   => __( 'Freschi', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/map/MAP_PACKAGING3.mp4',
				),
			),
			'cta_box_title'     => __( 'Vuoi aumentare la shelf life del tuo prodotto?', 'samswiss-child' ),
			'cta_box_text'      => __( 'Contattaci e raccontaci cosa vuoi confezionare. Studiamo insieme la soluzione MAP più adatta al tuo prodotto, al formato e alla capacità produttiva richiesta.', 'samswiss-child' ),
			'cta_box_btn'       => __( 'Richiedi una consulenza', 'samswiss-child' ),
			'why_title'         => __( 'Perché scegliere il MAP?', 'samswiss-child' ),
			'why_intro'         => __( 'Il confezionamento in atmosfera modificata permette di ottenere numerosi vantaggi per la produzione e la distribuzione:', 'samswiss-child' ),
			'vantaggi_detailed' => array(
				array(
					'title' => __( 'Prolungamento della shelf life', 'samswiss-child' ),
					'desc'  => __( 'Aumenta significativamente la durata commerciale del prodotto senza conservanti chimici.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Conservazione della freschezza', 'samswiss-child' ),
					'desc'  => __( 'Preserva il gusto, l\'aroma, la consistenza e le caratteristiche organolettiche originali.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Aspetto e presentazione perfetti', 'samswiss-child' ),
					'desc'  => __( 'Mantiene inalterato il colore e la freschezza visiva del prodotto sullo scaffale.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Riduzione dei fenomeni di ossidazione', 'samswiss-child' ),
					'desc'  => __( 'L\'azoto e le miscele protettive evitano l\'irrancidimento e l\'imbrunimento.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Distribuzione a lungo raggio', 'samswiss-child' ),
					'desc'  => __( 'Possibilità di raggiungere mercati più lontani e ampliare i canali di vendita e logistica.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Riduzione degli sprechi alimentari', 'samswiss-child' ),
					'desc'  => __( 'Minori resi e scarti lungo tutta la catena distributiva e nel punto vendita.', 'samswiss-child' ),
				),
			),
			'quote'             => __( 'Più freschezza. Più protezione. Più shelf life.', 'samswiss-child' ),
			'applicazioni'      => array(
				__( 'Frutta e verdura (freschi e lavorati)', 'samswiss-child' ),
				__( 'IV Gamma (insalate e ortaggi pronti)', 'samswiss-child' ),
				__( 'Carne fresca e pollame', 'samswiss-child' ),
				__( 'Pesce e prodotti ittici', 'samswiss-child' ),
				__( 'Gastronomia, pasta fresca e piatti pronti', 'samswiss-child' ),
				__( 'Salumi e affettati libero servizio', 'samswiss-child' ),
				__( 'Formaggi e latticini porzionati', 'samswiss-child' ),
				__( 'Pane, focacce e prodotti da forno', 'samswiss-child' ),
			),
			'cover'             => 'theme:assets/img/tecnologie/map.jpeg',
			'gallery'           => array( 16627, 5183 ),
		),
		'skin'                        => array(
			'icon'              => 'fa-square',
			'title'             => __( 'Confezionamento Skin', 'samswiss-child' ),
			'subtitle'          => __( 'Protezione, durata e massima valorizzazione del prodotto', 'samswiss-child' ),
			'card_text'         => __( 'Confezionamento skin sottovuoto per una presentazione premium e una perfetta adesione.', 'samswiss-child' ),
			'intro'             => __( 'Il confezionamento Skin è una soluzione sottovuoto studiata per proteggere il prodotto e presentarlo in modo particolarmente curato e professionale. Durante il processo, il film superiore viene riscaldato e fatto aderire completamente al prodotto e al supporto, seguendone perfettamente la forma, quasi come una seconda pelle. Il prodotto rimane quindi stabile all’interno della confezione, ben visibile e protetto durante tutte le fasi di movimentazione, conservazione ed esposizione. Grazie all’elevata trasparenza del film e alla perfetta aderenza alla superficie del prodotto, il confezionamento Skin permette di ottenere una presentazione di forte impatto visivo, particolarmente adatta alla GDO, ai negozi specializzati e al food service.', 'samswiss-child' ),
			'features_title'    => __( 'Skin ed Extra-Skin', 'samswiss-child' ),
			'features_intro'    => __( 'Soluzioni studiate per valorizzare ogni tipologia di prodotto:', 'samswiss-child' ),
			'features'          => array(
				__( 'Configurazioni Extra-Skin per prodotti ad alto spessore che sporgono dal bordo', 'samswiss-child' ),
				__( 'Film ad altissima trasparenza ed elasticità per una visibilità a 360°', 'samswiss-child' ),
				__( 'Immobilizzazione del prodotto per evitare perdite di liquidi ed essudati', 'samswiss-child' ),
				__( 'Compatibilità con vaschette, cartoncini piani e supporti eco-friendly', 'samswiss-child' ),
			),
			'automation_title'  => __( 'Dal prodotto alla linea completa', 'samswiss-child' ),
			'automation_text'   => __( 'SAM SA progetta e realizza soluzioni complete per il confezionamento Skin: Alimentazione del prodotto → Sistemi di trasporto → Confezionamento Skin → Controllo peso → Etichettatura → Marcatura → Uscita e fine linea.', 'samswiss-child' ),
			'video_title'       => __( 'Guarda il confezionamento Skin in funzione', 'samswiss-child' ),
			'video_subtitle'    => __( 'Scopri nei video la qualità e la tenuta del confezionamento Skin sottovuoto.', 'samswiss-child' ),
			'videos'            => array(
				array(
					'title' => __( 'Confezionamento Skin sottovuoto', 'samswiss-child' ),
					'desc'  => __( 'Adesione perfetta del film sottovuoto al prodotto e al supporto.', 'samswiss-child' ),
					'tag'   => __( 'Sottovuoto', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/skin/SKIN_PACKAGING.mp4',
				),
				array(
					'title' => __( 'Ciclo Skin & Extra-Skin su supporti', 'samswiss-child' ),
					'desc'  => __( 'Confezionamento ad alta precisione anche su prodotti sporgenti.', 'samswiss-child' ),
					'tag'   => __( 'Extra-Skin', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/skin/SKIN_PACKAGIGNG.mp4',
				),
			),
			'cta_box_title'     => __( 'La soluzione giusta parte dal tuo prodotto', 'samswiss-child' ),
			'cta_box_text'      => __( 'Ogni prodotto ha caratteristiche differenti: analizziamo insieme il tipo di alimento, il formato, la capacità produttiva e le esigenze di conservazione, individuando la configurazione Skin più adatta.', 'samswiss-child' ),
			'cta_box_btn'       => __( 'Contattaci e raccontaci il tuo progetto', 'samswiss-child' ),
			'why_title'         => __( 'Perché scegliere il confezionamento Skin?', 'samswiss-child' ),
			'why_intro'         => __( 'I principali vantaggi della tecnologia Skin per i prodotti alimentari ad alto valore aggiunto:', 'samswiss-child' ),
			'vantaggi_detailed' => array(
				array(
					'title' => __( 'Presentazione premium', 'samswiss-child' ),
					'desc'  => __( 'Il film segue perfettamente il profilo del prodotto, creando una confezione pulita, moderna e altamente valorizzante.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Massima visibilità', 'samswiss-child' ),
					'desc'  => __( 'La trasparenza del film permette al consumatore di vedere chiaramente il prodotto, migliorandone la percezione qualitativa.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Maggiore stabilità nella confezione', 'samswiss-child' ),
					'desc'  => __( 'Il prodotto viene mantenuto fermo sul supporto, riducendo movimenti e danneggiamenti durante il trasporto.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Protezione del prodotto', 'samswiss-child' ),
					'desc'  => __( 'Il confezionamento sottovuoto contribuisce a preservare le caratteristiche del prodotto e a migliorarne la conservazione.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Ottimizzazione dell’esposizione', 'samswiss-child' ),
					'desc'  => __( 'La stabilità del prodotto permette una presentazione ordinata anche in confezioni verticali o inclinate a scaffale.', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Ampia flessibilità di formato', 'samswiss-child' ),
					'desc'  => __( 'La tecnologia Skin può essere adattata a prodotti di dimensioni e forme differenti con vaschette o cartoncini.', 'samswiss-child' ),
				),
			),
			'quote'             => __( 'Protezione, durata e massima valorizzazione del prodotto.', 'samswiss-child' ),
			'applicazioni'      => array(
				__( 'Carne fresca e lavorata', 'samswiss-child' ),
				__( 'Pesce e prodotti ittici', 'samswiss-child' ),
				__( 'Formaggi e prodotti caseari', 'samswiss-child' ),
				__( 'Gastronomia e piatti pronti', 'samswiss-child' ),
				__( 'Prodotti porzionati e affettati', 'samswiss-child' ),
				__( 'Alimenti freschi ad alto valore aggiunto', 'samswiss-child' ),
			),
			'cover'             => 'theme:assets/img/tecnologie/skin.jpeg',
			'gallery'           => array( 14453, 14426 ),
		),
		'fine-linea-pallettizzazione' => array(
			'icon'              => 'fa-cubes-stacked',
			'title'             => __( 'Fine Linea e Pallettizzazione', 'samswiss-child' ),
			'subtitle'          => __( 'Soluzioni complete per automatizzare il fine linea', 'samswiss-child' ),
			'card_text'         => __( 'Sistemi integrati per la movimentazione, pallettizzazione e reggiatura automatica.', 'samswiss-child' ),
			'intro'             => __( 'Dalla movimentazione delle confezioni fino al pallet pronto per lo stoccaggio o la spedizione, SAM propone soluzioni complete per il fine linea, sviluppate con tecnologie Sorma Group. Ogni progetto viene studiato in funzione del prodotto, dei formati utilizzati, degli spazi disponibili e della capacità produttiva richiesta, con l’obiettivo di creare un flusso di lavoro efficiente, ordinato e affidabile. SAM segue direttamente il cliente in tutta la Svizzera, dalla definizione della soluzione fino all’installazione e all’assistenza tecnica post-vendita.', 'samswiss-child' ),
			'features_title'    => __( 'Dal fine confezionamento al pallet completo', 'samswiss-child' ),
			'features_intro'    => __( 'Possiamo integrare tutte le principali fasi necessarie per completare e automatizzare il processo produttivo:', 'samswiss-child' ),
			'features'          => array(
				__( 'Impilatori e deimpilatori – Sistemi per la gestione automatica di cassette e contenitori, per rendere il flusso continuo e ridurre le movimentazioni manuali.', 'samswiss-child' ),
				__( 'Deimpilatori di pallet – Soluzioni per l\'alimentazione automatica dei pallet vuoti verso le successive fasi della linea.', 'samswiss-child' ),
				__( 'Pallettizzatori automatici – Formazione ordinata e precisa dei pallet, configurabili per diverse tipologie di cassette, confezioni e schemi.', 'samswiss-child' ),
				__( 'Navicelle e movimentazione – Trasferimento e distribuzione dei pallet tra le diverse postazioni, adattabili alla configurazione dello stabilimento.', 'samswiss-child' ),
				__( 'Reggiatrici automatiche – Stabilizzazione e messa in sicurezza del pallet prima dello stoccaggio o del trasporto su strada.', 'samswiss-child' ),
			),
			'automation_title'  => __( 'Un progetto, un unico referente', 'samswiss-child' ),
			'automation_text'   => __( 'Il fine linea non è semplicemente l’insieme di più macchine: per ottenere un impianto realmente efficiente è fondamentale che movimentazione, pallettizzazione e reggiatura lavorino come un unico sistema. SAM analizza insieme al cliente layout, spazi disponibili, capacità richiesta, tipologie di cassette e collegamento con le macchine esistenti.', 'samswiss-child' ),
			'video_title'       => __( 'Guarda il fine linea e la pallettizzazione in funzione', 'samswiss-child' ),
			'video_subtitle'    => __( 'Scopri nei video le tecnologie Sorma Group per la pallettizzazione e movimentazione automatica.', 'samswiss-child' ),
			'videos'            => array(
				array(
					'title' => __( 'Linea completa di fine linea e pallettizzazione', 'samswiss-child' ),
					'desc'  => __( 'Flusso automatizzato dalla gestione cassette al pallet finito pronto alla spedizione.', 'samswiss-child' ),
					'tag'   => __( 'Fine Linea', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/fine-linea/fine-linea-completo.mp4',
				),
				array(
					'title' => __( 'Pallettizzatori automatici ad alta velocità', 'samswiss-child' ),
					'desc'  => __( 'Formazione precisa e impilamento ordinato per cassette e casse ortofrutticole.', 'samswiss-child' ),
					'tag'   => __( 'Pallettizzatori', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/fine-linea/pallettizzatori.mp4',
				),
				array(
					'title' => __( 'Pallettizzazione e reggiatura integrate', 'samswiss-child' ),
					'desc'  => __( 'Sistema combinato per la pallettizzazione e stabilizzazione immediata del carico.', 'samswiss-child' ),
					'tag'   => __( 'Pallet & Reggia', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/fine-linea/pallettizzazione-reggiatura.mp4',
				),
				array(
					'title' => __( 'Deimpilatore e impilatore cassette', 'samswiss-child' ),
					'desc'  => __( 'Gestione continua del flusso contenitori e alimentazione automatica in linea.', 'samswiss-child' ),
					'tag'   => __( 'Deimpilatori', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/fine-linea/deimpilatore-impilatore.mp4',
				),
				array(
					'title' => __( 'Navicella automatica sposta-pedane', 'samswiss-child' ),
					'desc'  => __( 'Trasferimento robotizzato dei pallet tra le stazioni di lavoro e magazzino.', 'samswiss-child' ),
					'tag'   => __( 'Navicelle', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/fine-linea/navicella-sposta-pedana.mp4',
				),
				array(
					'title' => __( 'Reggiatrici con applicazione angolari', 'samswiss-child' ),
					'desc'  => __( 'Reggiatura automatica a 4 o 8 stock di angolari per massima tenuta logistica.', 'samswiss-child' ),
					'tag'   => __( 'Reggiatrici', 'samswiss-child' ),
					'src'   => 'uploads:tecnologie/fine-linea/reggiatrici-angolari.mp4',
				),
			),
			'cta_box_title'     => __( 'Vuoi automatizzare il tuo fine linea?', 'samswiss-child' ),
			'cta_box_text'      => __( 'Raccontaci come è organizzata oggi la tua produzione. Studieremo insieme la soluzione più adatta, dalla movimentazione alla pallettizzazione, con fornitura di singole macchine o impianti completi.', 'samswiss-child' ),
			'cta_box_btn'       => __( 'Parlaci del tuo progetto', 'samswiss-child' ),
			'why_title'         => __( 'Tecnologia Sorma, presenza SAM sul territorio', 'samswiss-child' ),
			'why_intro'         => __( 'La tecnologia e l\'esperienza di Sorma Group si uniscono alla presenza diretta e all\'assistenza SAM in tutta la Svizzera:', 'samswiss-child' ),
			'vantaggi_cards'    => array(
				array(
					'title' => __( 'Automazione continua', 'samswiss-child' ),
					'text'  => __( 'Flusso costante dalla fine confezionamento al pallet finito pronto per la spedizione, eliminando colli di bottiglia.', 'samswiss-child' ),
					'icon'  => 'fa-arrows-spin',
				),
				array(
					'title' => __( 'Impilaggio geometrico perfetto', 'samswiss-child' ),
					'text'  => __( 'Schemi di pallettizzazione precisi, stabili e ripetibili per ogni tipologia di cassa e confezione.', 'samswiss-child' ),
					'icon'  => 'fa-cubes-stacked',
				),
				array(
					'title' => __( 'Sicurezza e conformità', 'samswiss-child' ),
					'text'  => __( 'Riduzione drastica del lavoro manuale gravoso ed ergonomia e sicurezza totale per gli operatori.', 'samswiss-child' ),
					'icon'  => 'fa-user-shield',
				),
				array(
					'title' => __( 'Massima flessibilità di layout', 'samswiss-child' ),
					'text'  => __( 'Soluzioni modulari e navicelle personalizzabili in base agli spazi reali dello stabilimento.', 'samswiss-child' ),
					'icon'  => 'fa-ruler-combined',
				),
				array(
					'title' => __( 'Stabilità per il trasporto', 'samswiss-child' ),
					'text'  => __( 'Reggiatura automatica con angolari per pallet compatti e a prova di movimentazione logistica.', 'samswiss-child' ),
					'icon'  => 'fa-truck-fast',
				),
				array(
					'title' => __( 'Referente unico in Svizzera', 'samswiss-child' ),
					'text'  => __( 'Consulenza, ingegneria, installazione, collaudo e assistenza tecnica post-vendita diretta SAM.', 'samswiss-child' ),
					'icon'  => 'fa-handshake',
				),
			),
			'quote'             => __( 'La tecnologia e l’esperienza di Sorma Group si uniscono alla presenza diretta di SAM sul mercato svizzero per seguire il cliente durante l’intero ciclo di vita dell’impianto.', 'samswiss-child' ),
			'applicazioni'      => array(
				__( 'Ortofrutta e prodotti freschi in cassette e plateau', 'samswiss-child' ),
				__( 'Settore alimentare, conserviero e bevande', 'samswiss-child' ),
				__( 'Linee industriali di confezionamento ad alta cadenza', 'samswiss-child' ),
				__( 'Centri di distribuzione, logistica e packaging service', 'samswiss-child' ),
				__( 'Gestione pallet standard, Europallet, Chep e formati speciali', 'samswiss-child' ),
				__( 'Integrazione con sistemi ERP, tracciabilità ed etichettatura EAN/SSCC', 'samswiss-child' ),
			),
			'cover'             => 'theme:assets/img/tecnologie/fine-linea-pallettizzazione.jpeg',
			'gallery'           => array( 'theme:assets/img/sorma/image007.png', 'theme:assets/img/sorma/image011.png' ),
		),
	);

	foreach ( $catalog as $slug => &$tech ) {
		$tech['slug']         = $slug;
		$tech['url']          = samswiss_tecnologie_url( $slug );
		$tech['applicazioni'] = $tech['applicazioni'] ?? $applicazioni;
	}
	unset( $tech );

	return $catalog;
}

/**
 * Render one cover/gallery image entry — a catalogue post ID (uses its
 * featured image) or a `theme:` path shipped with the theme.
 *
 * @param int|string $entry Post ID, or 'theme:relative/path.png'.
 * @param string     $alt   Alt text.
 * @param string     $class CSS class(es).
 * @return string HTML, or '' if the entry resolves to nothing.
 */
function samswiss_tech_image( $entry, $alt, $class ) {
	if ( is_string( $entry ) && str_starts_with( $entry, 'theme:' ) ) {
		return samswiss_shipped_image( substr( $entry, 6 ), '', $alt, $class );
	}
	if ( is_string( $entry ) && str_starts_with( $entry, 'uploads:' ) ) {
		return samswiss_uploads_image( substr( $entry, 8 ), 'large', $class, $alt );
	}
	$id = (int) $entry;
	if ( $id && has_post_thumbnail( $id ) ) {
		return get_the_post_thumbnail( $id, 'large', array( 'class' => $class, 'alt' => $alt ) );
	}
	return '';
}

/**
 * Resolve a media/video source identifier into a full, playable URL.
 *
 * @param int|string $entry 'uploads:path/file.mp4', 'theme:path/file.mp4', full URL or attachment ID.
 * @return string Full URL or '' if empty/invalid.
 */
function samswiss_tech_media_url( $entry ) {
	if ( empty( $entry ) ) {
		return '';
	}
	if ( is_string( $entry ) ) {
		if ( str_starts_with( $entry, 'uploads:' ) ) {
			$rel        = substr( $entry, 8 );
			$upload_dir = wp_upload_dir();
			$basedir    = untrailingslashit( $upload_dir['basedir'] );
			$baseurl    = untrailingslashit( $upload_dir['baseurl'] );

			$filename  = wp_basename( $rel );
			$sanitized = sanitize_file_name( $filename );
			$dir       = dirname( $rel );
			$rel_san   = ( '.' === $dir || '' === $dir ) ? $sanitized : $dir . '/' . $sanitized;

			// 1. Standard upload dir (e.g. uploads/sites/17/ or uploads/)
			if ( file_exists( $basedir . '/' . $rel ) ) {
				return esc_url( $baseurl . '/' . $rel );
			}
			if ( file_exists( $basedir . '/' . $rel_san ) ) {
				return esc_url( $baseurl . '/' . $rel_san );
			}
			// 2. Root uploads/ fallback (for single-site deployments)
			$content_dir = defined( 'WP_CONTENT_DIR' ) ? WP_CONTENT_DIR : ABSPATH . 'wp-content';
			$content_url = defined( 'WP_CONTENT_URL' ) ? WP_CONTENT_URL : content_url();
			if ( file_exists( $content_dir . '/uploads/' . $rel ) ) {
				return esc_url( $content_url . '/uploads/' . $rel );
			}
			if ( file_exists( $content_dir . '/uploads/' . $rel_san ) ) {
				return esc_url( $content_url . '/uploads/' . $rel_san );
			}
			// 3. Multisite sites/17/ fallback (if folder transferred as sites/17/)
			if ( file_exists( $content_dir . '/uploads/sites/17/' . $rel ) ) {
				return esc_url( $content_url . '/uploads/sites/17/' . $rel );
			}
			if ( file_exists( $content_dir . '/uploads/sites/17/' . $rel_san ) ) {
				return esc_url( $content_url . '/uploads/sites/17/' . $rel_san );
			}
			// 4. Media Library fallback: check if file was uploaded via wp-admin -> Media
			$cache_key = 'sam_media_' . md5( $filename );
			$cached_id = wp_cache_get( $cache_key, 'samswiss_tech' );
			if ( false === $cached_id ) {
				global $wpdb;
				$like_a = '%' . $wpdb->esc_like( $filename );
				$like_b = '%' . $wpdb->esc_like( $sanitized );
				$stem   = pathinfo( $filename, PATHINFO_FILENAME );
				$like_c = '%' . $wpdb->esc_like( $stem ) . '%';

				$attachment_id = (int) $wpdb->get_var( $wpdb->prepare(
					"SELECT post_id FROM {$wpdb->postmeta} 
					WHERE meta_key = '_wp_attached_file' 
					AND (meta_value LIKE %s OR meta_value LIKE %s OR meta_value LIKE %s) 
					ORDER BY post_id DESC LIMIT 1",
					$like_a,
					$like_b,
					$like_c
				) );
				wp_cache_set( $cache_key, $attachment_id, 'samswiss_tech', 3600 );
				$cached_id = $attachment_id;
			}
			if ( ! empty( $cached_id ) ) {
				$att_url = wp_get_attachment_url( $cached_id );
				if ( $att_url ) {
					return esc_url( $att_url );
				}
			}
			// 5. Default URL if file is remote or CDN
			return esc_url( $baseurl . '/' . $rel );
		}
		if ( str_starts_with( $entry, 'theme:' ) ) {
			return esc_url( trailingslashit( get_stylesheet_directory_uri() ) . substr( $entry, 6 ) );
		}
		if ( preg_match( '#^(https?:)?//#i', $entry ) ) {
			return esc_url( $entry );
		}
	}
	$id = (int) $entry;
	if ( $id ) {
		$url = wp_get_attachment_url( $id );
		return $url ? esc_url( $url ) : '';
	}
	return '';
}

