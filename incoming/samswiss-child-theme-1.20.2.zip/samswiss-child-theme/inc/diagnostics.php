<?php
/**
 * Live diagnostics for the category links.
 *
 * Visible only to a logged-in administrator, on demand, at ?samswiss-diag=links.
 * It exists because the same code behaves differently on two installs and the
 * difference is in the database, not in the theme: this prints the database's
 * answers so the cause can be read instead of guessed.
 *
 * Remove this file once the links are confirmed working.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Render the report and stop.
 */
function samswiss_diagnostics() {
	if ( ! isset( $_GET['samswiss-diag'] ) || 'links' !== $_GET['samswiss-diag'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only report, capability-checked below.
		return;
	}
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	header( 'Content-Type: text/plain; charset=utf-8' );

	$out = array();
	$out[] = 'SAMSWISS — diagnostica link categorie';
	$out[] = str_repeat( '=', 64 );
	$out[] = 'home_url()      : ' . home_url( '/' );
	$out[] = 'site_url()      : ' . site_url( '/' );
	$out[] = 'tema attivo     : ' . wp_get_theme()->get( 'Name' ) . ' ' . wp_get_theme()->get( 'Version' );
	$out[] = 'multisite       : ' . ( is_multisite() ? 'si, blog_id ' . get_current_blog_id() : 'no' );
	$out[] = 'WooCommerce     : ' . ( class_exists( 'WooCommerce' ) ? WC()->version : 'NON ATTIVO' );
	$out[] = '';

	$perma = get_option( 'woocommerce_permalinks', array() );
	$out[] = 'woocommerce_permalinks:';
	foreach ( (array) $perma as $k => $v ) {
		$out[] = sprintf( '  %-22s %s', $k, '' === $v ? '(vuoto)' : $v );
	}
	$out[] = '  struttura permalink WP : ' . ( get_option( 'permalink_structure' ) ?: '(PLAIN — le regole di riscrittura non esistono)' );
	$out[] = '';

	// 1. I due termini, cercati come li cerca il tema.
	$wanted = array(
		'imballaggi-e-monouso-categoria'                => 'Imballaggi e Monouso',
		'ingredienti-gelaterie-e-pasticcerie-categoria' => 'Ingredienti gelaterie e pasticcerie',
	);

	$out[] = '1) RICERCA DEI TERMINI';
	foreach ( $wanted as $slug => $label ) {
		$term = get_term_by( 'slug', $slug, 'product_cat' );
		if ( $term && ! is_wp_error( $term ) ) {
			$link = get_term_link( $term );
			$out[] = sprintf( '  slug "%s" -> TROVATO id=%d, %d prodotti', $slug, $term->term_id, $term->count );
			$out[] = sprintf( '      URL generato: %s', is_wp_error( $link ) ? 'ERRORE: ' . $link->get_error_message() : $link );
			$out[] = sprintf( '      stato HTTP  : %s', samswiss_diag_probe( is_wp_error( $link ) ? '' : $link ) );
		} else {
			$out[] = sprintf( '  slug "%s" -> NON TROVATO', $slug );
		}
	}
	$out[] = '';

	// 2. Tutti i termini radice: se gli slug non coincidono, si vedono qui.
	$out[] = '2) CATEGORIE PRODOTTO DI PRIMO LIVELLO PRESENTI SU QUESTO SERVER';
	$roots = get_terms( array( 'taxonomy' => 'product_cat', 'parent' => 0, 'hide_empty' => false ) );
	if ( is_wp_error( $roots ) ) {
		$out[] = '  ERRORE: ' . $roots->get_error_message();
	} elseif ( empty( $roots ) ) {
		$out[] = '  NESSUNA CATEGORIA PRODOTTO (la tassonomia è vuota su questo server)';
	} else {
		foreach ( $roots as $t ) {
			$out[] = sprintf( '  id=%-6d slug=%-46s "%s" (%d)', $t->term_id, $t->slug, $t->name, $t->count );
		}
	}
	$out[] = '';

	// 3. Le voci di menu: sono contenuto del database, non del tema.
	$out[] = '3) VOCI DEL MENU PRINCIPALE';
	$locations = get_nav_menu_locations();
	$menu_id   = isset( $locations['primary'] ) ? (int) $locations['primary'] : 0;
	if ( ! $menu_id ) {
		$out[] = '  NESSUN MENU assegnato alla posizione "primary"';
	} else {
		$items = wp_get_nav_menu_items( $menu_id );
		foreach ( (array) $items as $item ) {
			$note = '';
			if ( 'taxonomy' === $item->type ) {
				$t    = get_term( (int) $item->object_id, $item->object );
				$note = ( $t && ! is_wp_error( $t ) )
					? 'termine ok (' . $t->slug . ')'
					: '>>> TERMINE #' . (int) $item->object_id . ' INESISTENTE SU QUESTO SERVER <<<';
			} elseif ( 'post_type' === $item->type ) {
				$p    = get_post( (int) $item->object_id );
				$note = $p ? 'pagina ok (' . $p->post_name . ')' : '>>> PAGINA #' . (int) $item->object_id . ' INESISTENTE <<<';
			}
			$out[] = sprintf( '  %-34s %-9s %s', mb_substr( $item->title, 0, 32 ), $item->type, $note );
			$out[] = sprintf( '      url: %s  [%s]', $item->url, samswiss_diag_probe( $item->url ) );
		}
	}
	$out[] = '';

	// 4. Il gateway: gli stessi link che il tema costruisce.
	$out[] = '4) LINK COSTRUITI DAL TEMA (gateway INTRO)';
	foreach ( array(
		array( 203, 'page', 'sam-sa-packaging-lines' ),
		array( 1270, 'product_cat', 'imballaggi-e-monouso-categoria' ),
		array( 1301, 'product_cat', 'ingredienti-gelaterie-e-pasticcerie-categoria' ),
	) as $spec ) {
		$url = samswiss_localized_permalink( $spec[0], $spec[1], $spec[2] );
		$out[] = sprintf( '  %-46s -> %s', $spec[2], '' === $url ? '(VUOTO)' : $url );
		$out[] = sprintf( '      stato HTTP: %s', samswiss_diag_probe( $url ) );
	}
	$out[] = '';
	$out[] = 'Fine. Copia tutto questo testo e mandalo indietro.';

	echo implode( "\n", $out ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- plain text report.
	exit;
}
add_action( 'template_redirect', 'samswiss_diagnostics', 1 );

/**
 * Ask the site itself what that URL returns.
 *
 * @param string $url URL to probe.
 * @return string
 */
function samswiss_diag_probe( $url ) {
	if ( ! $url ) {
		return 'nessun URL';
	}
	$res = wp_remote_get( $url, array( 'timeout' => 8, 'redirection' => 0, 'sslverify' => false ) );
	if ( is_wp_error( $res ) ) {
		return 'richiesta fallita: ' . $res->get_error_message();
	}
	$code = wp_remote_retrieve_response_code( $res );
	$loc  = wp_remote_retrieve_header( $res, 'location' );

	return $code . ( $loc ? ' -> redirect verso ' . $loc : '' );
}
