<?php
/**
 * SAM SWISS child theme — WooCommerce integration.
 *
 * The parent theme provides WooCommerce support (HPOS, image sizes, helpers)
 * but no templates. This file restyles the shop natively to match the approved
 * design: two-column archives with a category sidebar, "Acquista" buttons, and
 * clean product cards. Product/category translations are handled by WPML.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Products per row / per page — matches the approved 3-column, 12-per-page grid.
 */
add_filter( 'loop_shop_columns', function () { return 3; }, 20 );
add_filter( 'loop_shop_per_page', function () { return 12; }, 20 );

/**
 * Loop add-to-cart button label → "Acquista" (as in the original design).
 */
function samswiss_loop_add_to_cart_text( $text, $product = null ) {
	if ( $product && $product->is_type( 'simple' ) && $product->is_purchasable() && $product->is_in_stock() ) {
		return __( 'Acquista', 'samswiss-child' );
	}
	return $text;
}
add_filter( 'woocommerce_product_add_to_cart_text', 'samswiss_loop_add_to_cart_text', 20, 2 );

/**
 * Remove WooCommerce's default single-product breadcrumb duplication when our
 * own page header already shows context (kept on archives only).
 */
remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );
add_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );

/**
 * Render the shop/category sidebar (search + category tree). Hooked into the
 * WooCommerce sidebar slot used by our archive-product.php override.
 */
function samswiss_woocommerce_sidebar() {
	if ( ! ( is_shop() || is_product_taxonomy() ) ) {
		return;
	}
	get_template_part( 'template-parts/woocommerce/category-sidebar' );
}

/**
 * Return the top-level SAM SA product categories (the two trees:
 * "Imballaggi e Monouso" and "Ingredienti gelaterie e pasticcerie"),
 * WPML-aware (get_terms already runs in the current language context).
 *
 * @return WP_Term[]
 */
function samswiss_get_root_product_categories() {
	$terms = get_terms( array(
		'taxonomy'   => 'product_cat',
		'parent'     => 0,
		'hide_empty' => false,
	) );
	if ( is_wp_error( $terms ) ) {
		return array();
	}
	// Drop the WooCommerce "Uncategorized" default.
	$default = (int) get_option( 'default_product_cat', 0 );
	return array_values( array_filter( $terms, function ( $t ) use ( $default ) {
		return (int) $t->term_id !== $default;
	} ) );
}

/**
 * Recursively render a product-category tree as a nested, collapsible list.
 *
 * @param int $parent_id Parent term id.
 * @param int $depth     Current depth (0 = root).
 */
function samswiss_render_product_category_tree( $parent_id = 0, $depth = 0 ) {
	$terms = get_terms( array(
		'taxonomy'   => 'product_cat',
		'parent'     => $parent_id,
		'hide_empty' => false,
	) );
	if ( is_wp_error( $terms ) || empty( $terms ) ) {
		return;
	}
	if ( 0 === $parent_id ) {
		$default = (int) get_option( 'default_product_cat', 0 );
		$terms   = array_filter( $terms, function ( $t ) use ( $default ) {
			return (int) $t->term_id !== $default;
		} );
	}
	if ( empty( $terms ) ) {
		return;
	}

	$current_id = ( is_tax( 'product_cat' ) ) ? get_queried_object_id() : 0;

	echo '<ul class="samswiss-cat-tree depth-' . (int) $depth . '">';
	foreach ( $terms as $term ) {
		$children     = get_terms( array( 'taxonomy' => 'product_cat', 'parent' => $term->term_id, 'hide_empty' => false, 'fields' => 'ids' ) );
		$has_children = ! is_wp_error( $children ) && ! empty( $children );
		$is_current   = ( (int) $term->term_id === (int) $current_id );
		$classes      = 'samswiss-cat-item';
		if ( $has_children ) {
			$classes .= ' has-children';
		}
		if ( $is_current ) {
			$classes .= ' is-current';
		}
		echo '<li class="' . esc_attr( $classes ) . '">';
		echo '<a href="' . esc_url( get_term_link( $term ) ) . '">' . esc_html( $term->name );
		if ( $term->count ) {
			echo ' <span class="cat-count">(' . (int) $term->count . ')</span>';
		}
		echo '</a>';
		if ( $has_children ) {
			echo '<button type="button" class="samswiss-cat-toggle" aria-label="' . esc_attr__( 'Espandi', 'samswiss-child' ) . '"><i class="fas fa-plus" aria-hidden="true"></i></button>';
			samswiss_render_product_category_tree( $term->term_id, $depth + 1 );
		}
		echo '</li>';
	}
	echo '</ul>';
}

/**
 * Drop the WooCommerce product sidebar.
 *
 * `woocommerce_sidebar` renders the "shop" widget area, which on this install
 * still holds WordPress's default widget set — Search, Pages, Archives,
 * Categories. On the single product page that printed as a raw bulleted dump of
 * every page and month on the site, below the Swiss two-column layout, which has
 * no sidebar track to put it in. The parent theme ships the same line commented
 * out; this enables it for samswiss only.
 */
remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );

/**
 * Hide catalogue prices.
 *
 * Asked for by the client in August 2026: the prices in the catalogue are out of
 * date, so none of them should be shown until they are revised.
 *
 * `woocommerce_get_price_html` is the one place worth filtering, because every
 * surface funnels through it — the shop loop, the category archives, the single
 * product, related and up-sells, the theme's own search results and the live
 * search dropdown, which both call get_price_html() themselves. Emptying it also
 * removes the "IVA Inclusa" suffix, which is part of the same string and would
 * otherwise be left hanging under a product with no figure above it.
 *
 * NOT a price of zero and not `display: none`: a hidden price is still in the
 * markup, so it would still be read out by a screen reader, still be indexed, and
 * still be copied into a quotation by anyone viewing source.
 *
 * Deliberately does NOT touch cart, checkout or order e-mails. Those show what a
 * specific order actually costs, and a shop that takes an order without stating a
 * total would be worse than one with an old price. See the note in
 * docs/release-note.md: while the catalogue is silent and the checkout is not,
 * buying is still possible at the very figures the client considers wrong.
 *
 * Reversible in one line: remove the filter, or return $price from this callback.
 *
 * @param string $price Price HTML.
 * @return string
 */
function samswiss_hide_catalogue_prices( $price ) {
	return '';
}
add_filter( 'woocommerce_get_price_html', 'samswiss_hide_catalogue_prices', 99 );

/**
 * Take the price out of the product's structured data too.
 *
 * Hiding the price on the page is only half of it. WooCommerce also publishes a
 * `schema.org/Product` block in the head, and that block carried the same figure:
 *
 *     "offers":[{"price":"10.60","priceCurrency":"CHF", …}]
 *
 * That is the copy search engines read, and the one they can print beside the
 * result in a listing. Leaving it in place would have meant the out-of-date prices
 * kept circulating in exactly the place the client cannot see them — measured on a
 * product page after the visible price was already gone.
 *
 * The offer itself is kept, with its availability and its URL: the product is real
 * and still in the catalogue. Only the figures go.
 *
 * @param array $markup Structured data for the product.
 * @return array
 */
function samswiss_strip_price_from_structured_data( $markup ) {
	if ( empty( $markup['offers'] ) || ! is_array( $markup['offers'] ) ) {
		return $markup;
	}

	foreach ( $markup['offers'] as $i => $offer ) {
		unset(
			$markup['offers'][ $i ]['price'],
			$markup['offers'][ $i ]['priceCurrency'],
			$markup['offers'][ $i ]['priceSpecification'],
			$markup['offers'][ $i ]['priceValidUntil']
		);
	}

	return $markup;
}
add_filter( 'woocommerce_structured_data_product', 'samswiss_strip_price_from_structured_data', 99 );

/**
 * "Present as examples, invite to request measurements/availability/consultation" —
 * asked for by the client in August 2026 for the whole catalogue (in practice this
 * store's only two root categories, "Imballaggi e Monouso" #1270 and "Ingredienti
 * gelaterie e pasticcerie" #1301 — every product on the site sits in one of the two
 * trees, confirmed by listing every `product_cat` term rather than assumed). Prices
 * were already hidden everywhere (see samswiss_hide_catalogue_prices above); this
 * goes one step further and replaces "Acquista" / Add to cart itself with a CTA to
 * Contatti, on the loop card and on the single product page.
 *
 * Root IDs, not `samswiss_get_root_product_categories()`: that helper returns
 * whatever root categories exist today, which happens to be these two, but the
 * client named these two specifically — a third root added later (a real,
 * price-shown line) must not silently inherit this treatment just by being new.
 *
 * NOTHING is removed from WooCommerce itself: every product stays exactly as
 * purchasable, in stock, and priced in the backend as before — a direct
 * add-to-cart URL or an existing cart line still checks out. Only the buttons that
 * invite a visitor to start that flow are swapped for this specific catalogue.
 * Reversible in one line: unhook samswiss_swap_examples_purchase_ui below.
 */
const SAMSWISS_EXAMPLES_ROOT_CAT_IDS = array( 1270, 1301 );

/**
 * Is $term_id #1270/#1301 themselves, or somewhere underneath one of them?
 *
 * @param int $term_id product_cat term id.
 * @return bool
 */
function samswiss_term_in_examples_scope( $term_id ) {
	$term_id = (int) $term_id;
	foreach ( SAMSWISS_EXAMPLES_ROOT_CAT_IDS as $root ) {
		if ( $term_id === $root || term_is_ancestor_of( $root, $term_id, 'product_cat' ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Is the current request an archive or a single product inside the examples scope?
 * The general shop archive is always in scope too: with only these two roots in the
 * whole catalogue, /shop/ lists exactly the same products either view would.
 *
 * @return bool
 */
function samswiss_is_examples_scope() {
	if ( is_shop() ) {
		return true;
	}

	if ( is_tax( 'product_cat' ) ) {
		return samswiss_term_in_examples_scope( get_queried_object_id() );
	}

	if ( is_product() ) {
		$terms = get_the_terms( get_queried_object_id(), 'product_cat' );
		if ( is_array( $terms ) ) {
			foreach ( $terms as $term ) {
				if ( samswiss_term_in_examples_scope( $term->term_id ) ) {
					return true;
				}
			}
		}
	}

	return false;
}

/**
 * Swap the purchase UI for the "request info" CTA, scoped to the current request.
 */
function samswiss_swap_examples_purchase_ui() {
	if ( ! samswiss_is_examples_scope() ) {
		return;
	}

	remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );
	add_action( 'woocommerce_after_shop_loop_item', 'samswiss_examples_cta_loop', 10 );

	remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );
	add_action( 'woocommerce_single_product_summary', 'samswiss_examples_cta_single', 30 );

	add_action( 'woocommerce_archive_description', 'samswiss_examples_archive_note', 5 );
}
add_action( 'wp', 'samswiss_swap_examples_purchase_ui' );

/**
 * Compact CTA for a product card in a loop/archive.
 */
function samswiss_examples_cta_loop() {
	$url = samswiss_localized_permalink( 569, 'page', 'contatti' ) ?: home_url( '/contatti/' );
	echo '<a href="' . esc_url( $url ) . '" class="button samswiss-examples-cta samswiss-examples-cta--loop">' . esc_html__( 'Richiedi info', 'samswiss-child' ) . '</a>';
}

/**
 * Full CTA on the single product page, in place of the add-to-cart form.
 */
function samswiss_examples_cta_single() {
	$url = samswiss_localized_permalink( 569, 'page', 'contatti' ) ?: home_url( '/contatti/' );
	echo '<div class="samswiss-examples-cta samswiss-examples-cta--single">';
	echo '<p class="samswiss-examples-cta__note">' . esc_html__( 'Articolo presentato a titolo di esempio dalla nostra gamma. Misure, disponibilità e consulenza su richiesta.', 'samswiss-child' ) . '</p>';
	echo '<a href="' . esc_url( $url ) . '" class="button alt samswiss-examples-cta__btn">' . esc_html__( 'Richiedi misure, disponibilità e consulenza', 'samswiss-child' ) . '</a>';
	echo '</div>';
}

/**
 * Short note above the archive grid. Printed in code rather than set as 130
 * individual term descriptions, so every present and future subcategory in either
 * tree reads consistently without hand-editing each one.
 */
function samswiss_examples_archive_note() {
	echo '<p class="samswiss-examples-archive-note">' . esc_html__( 'Una selezione della nostra gamma, presentata a titolo di esempio. Misure, disponibilità e consulenza su richiesta.', 'samswiss-child' ) . '</p>';
}
