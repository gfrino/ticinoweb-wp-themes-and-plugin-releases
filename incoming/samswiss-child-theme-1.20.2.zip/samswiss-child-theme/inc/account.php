<?php
/**
 * The account pages this install expects but WooCommerce does not provide.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register `[woocommerce_edit_account]`.
 *
 * The "Modifica account" page (#941 on the reference install) has carried this
 * shortcode in its body since the migration, and it printed as literal text on
 * every environment — including this one. The reason is not a template that fails
 * to run shortcodes and not a missing do_shortcode(): **WooCommerce has never
 * registered a shortcode by that name.** Its account editing lives at an endpoint
 * of My Account (`/il-mio-account/edit-account/`), rendered by
 * WC_Shortcode_My_Account::edit_account().
 *
 * So either the page loses its content or the shortcode gains a meaning. This
 * gives it one, using WooCommerce's own template and its own form handler, so the
 * page saves exactly like the endpoint does.
 *
 * Guarded by shortcode_exists(): should WooCommerce ever ship one, theirs wins.
 */
function samswiss_register_edit_account_shortcode() {
	if ( ! function_exists( 'WC' ) || shortcode_exists( 'woocommerce_edit_account' ) ) {
		return;
	}

	add_shortcode( 'woocommerce_edit_account', 'samswiss_edit_account_shortcode' );
}
add_action( 'init', 'samswiss_register_edit_account_shortcode', 20 );

/**
 * Render the account form, or the login form when nobody is signed in.
 *
 * @return string
 */
function samswiss_edit_account_shortcode() {
	if ( ! function_exists( 'wc_get_template' ) ) {
		return '';
	}

	// The commerce stylesheet is enqueued by surface (shop, cart, checkout, account).
	// This shortcode can also sit on an ordinary page — it does here, while on the
	// live install the same page IS the account page — so the form pulls its own
	// styles in rather than depending on which of the two the server thinks it is.
	if ( ! wp_style_is( 'samswiss-commerce-swiss', 'enqueued' ) && function_exists( 'samswiss_asset_version' ) ) {
		wp_enqueue_style(
			'samswiss-commerce-swiss',
			get_stylesheet_directory_uri() . '/assets/css/commerce-swiss.css',
			array( 'samswiss-site-swiss' ),
			samswiss_asset_version( 'assets/css/commerce-swiss.css' )
		);
	}

	ob_start();

	if ( ! is_user_logged_in() ) {
		// Not an error state: an anonymous visitor needs the door, not a message.
		// WooCommerce's own login template also carries the notices region.
		if ( function_exists( 'wc_print_notices' ) ) {
			wc_print_notices();
		}
		wc_get_template( 'myaccount/form-login.php' );

		return ob_get_clean();
	}

	if ( function_exists( 'wc_print_notices' ) ) {
		// The save handler reports success and validation errors through notices; the
		// endpoint prints them via the My Account wrapper, which this page does not
		// have.
		wc_print_notices();
	}

	wc_get_template(
		'myaccount/form-edit-account.php',
		array( 'user' => get_user_by( 'id', get_current_user_id() ) )
	);

	return ob_get_clean();
}

/**
 * Let the form save when it is submitted from a plain page.
 *
 * `WC_Form_Handler::save_account_details` is bound to `template_redirect` and
 * returns early unless the request is a POST carrying its action — it does not
 * care which page rendered the form, so nothing else is needed. This assertion
 * exists to document that the save path was checked, not assumed: if a future
 * WooCommerce ties it to the endpoint, the check below starts failing loudly in
 * the log instead of silently losing a visitor's changes.
 */
function samswiss_assert_account_save_handler() {
	if ( ! is_admin() && defined( 'WP_DEBUG' ) && WP_DEBUG && class_exists( 'WC_Form_Handler' )
		&& ! has_action( 'template_redirect', array( 'WC_Form_Handler', 'save_account_details' ) ) ) {
		error_log( 'samswiss: WC_Form_Handler::save_account_details is no longer on template_redirect; [woocommerce_edit_account] cannot save.' );
	}
}
add_action( 'wp_loaded', 'samswiss_assert_account_save_handler' );
