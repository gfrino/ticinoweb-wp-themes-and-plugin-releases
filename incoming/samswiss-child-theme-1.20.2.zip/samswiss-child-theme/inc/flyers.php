<?php
/**
 * Volantini gestibili dalla bacheca (menu "Volantini").
 *
 * Per ogni posto del sito (pagina) e per ogni lingua si sceglie un'immagine
 * dalla Libreria media, la si sostituisce o la si nasconde. Dove non si è
 * scelto nulla vale il volantino originale spedito col tema
 * (assets/img/volantini/<slot>-<lingua>.jpg), se esiste.
 *
 * Salvataggio: opzione 'samswiss_flyers' = array( slot => array( lingua => valore ) ),
 * dove valore > 0 è l'ID dell'immagine e -1 vuol dire "nascosto".
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * I posti del sito che mostrano un volantino.
 *
 * @return array slot => array( label, desc, url )
 */
function samswiss_flyer_slots() {
	return array(
		'packaging-sostenibile' => array(
			'label' => __( 'Imballaggi e consumabili', 'samswiss-child' ),
			'desc'  => __( 'Sotto le soluzioni Bernucci. Oggi la pagina esiste solo in italiano: le altre lingue si vedranno quando verrà tradotta.', 'samswiss-child' ),
			'url'   => samswiss_localized_permalink( 0, 'page', 'imballaggi-e-consumabili' ) ?: home_url( '/imballaggi-e-consumabili/' ),
		),
		'gastro'                => array(
			'label' => __( 'Gastronomia, Panetteria e IV Gamma', 'samswiss-child' ),
			'desc'  => __( 'Nella pagina del settore, sopra le tecnologie.', 'samswiss-child' ),
			'url'   => samswiss_category_url( 'gastronomia-e-ristorazione' ),
		),
	);
}

/**
 * Lingue del sito, con l'italiano, il francese e il tedesco per primi.
 *
 * @return array codice => nome
 */
function samswiss_flyer_languages() {
	$langs  = array();
	$active = apply_filters( 'wpml_active_languages', null, 'skip_missing=0' );
	if ( is_array( $active ) ) {
		foreach ( $active as $code => $lang ) {
			$langs[ $code ] = ! empty( $lang['translated_name'] ) ? $lang['translated_name'] : strtoupper( $code );
		}
	}
	if ( ! $langs ) {
		$langs = array( 'it' => 'Italiano' );
	}

	$ordered = array();
	foreach ( array( 'it', 'fr', 'de' ) as $code ) {
		if ( isset( $langs[ $code ] ) ) {
			$ordered[ $code ] = $langs[ $code ];
		}
	}
	return $ordered + $langs;
}

/**
 * Volantino originale del tema per uno slot e una lingua (percorso relativo al tema).
 */
function samswiss_flyer_theme_file( $slot, $lang ) {
	$rel = 'assets/img/volantini/' . sanitize_file_name( $slot . '-' . $lang . '.jpg' );
	return file_exists( get_stylesheet_directory() . '/' . $rel ) ? $rel : '';
}

/**
 * Cosa mostrare per uno slot in una lingua.
 *
 * @return array|null array( 'url' => URL a tutta pagina, 'img' => HTML <img> ) oppure null.
 */
function samswiss_flyer_source( $slot, $lang, $alt = '', $class = '' ) {
	$saved = get_option( 'samswiss_flyers', array() );
	$value = isset( $saved[ $slot ][ $lang ] ) ? (int) $saved[ $slot ][ $lang ] : 0;

	if ( -1 === $value ) {
		return null;
	}

	if ( $value > 0 && wp_attachment_is_image( $value ) ) {
		$own_alt = trim( (string) get_post_meta( $value, '_wp_attachment_image_alt', true ) );
		return array(
			'url' => wp_get_attachment_url( $value ),
			'img' => wp_get_attachment_image( $value, 'large', false, array(
				'class'    => $class,
				'alt'      => $own_alt ? $own_alt : $alt,
				'loading'  => 'lazy',
				'decoding' => 'async',
				'sizes'    => '(max-width: 860px) 92vw, 460px',
			) ),
		);
	}

	$rel = samswiss_flyer_theme_file( $slot, $lang );
	if ( ! $rel ) {
		return null;
	}

	return array(
		'url' => get_stylesheet_directory_uri() . '/' . $rel,
		'img' => samswiss_shipped_image( $rel, '', $alt, $class ),
	);
}

/* ==========================================================================
   Bacheca
   ========================================================================== */

function samswiss_flyers_admin_menu() {
	add_menu_page(
		__( 'Volantini', 'samswiss-child' ),
		__( 'Volantini', 'samswiss-child' ),
		'edit_pages',
		'samswiss-flyers',
		'samswiss_render_flyers_page',
		'dashicons-format-image',
		21
	);
}
add_action( 'admin_menu', 'samswiss_flyers_admin_menu' );

function samswiss_flyers_admin_assets( $hook ) {
	if ( 'toplevel_page_samswiss-flyers' !== $hook ) {
		return;
	}
	wp_enqueue_media();
	wp_enqueue_script(
		'samswiss-admin-flyers',
		get_stylesheet_directory_uri() . '/assets/js/admin-flyers.js',
		array( 'jquery', 'media-editor' ),
		samswiss_asset_version( 'assets/js/admin-flyers.js' ),
		true
	);
	wp_localize_script( 'samswiss-admin-flyers', 'samswissFlyers', array(
		'title'    => __( 'Scegli il volantino', 'samswiss-child' ),
		'button'   => __( 'Usa questa immagine', 'samswiss-child' ),
		'chosen'   => __( 'Immagine scelta da te (ricorda di salvare)', 'samswiss-child' ),
		'removed'  => __( 'Tolto (ricorda di salvare)', 'samswiss-child' ),
		'original' => __( 'Volantino originale (ricorda di salvare)', 'samswiss-child' ),
	) );
}
add_action( 'admin_enqueue_scripts', 'samswiss_flyers_admin_assets' );

function samswiss_save_flyers() {
	if ( ! current_user_can( 'edit_pages' ) ) {
		wp_die( esc_html__( 'Permessi insufficienti.', 'samswiss-child' ) );
	}
	check_admin_referer( 'samswiss_save_flyers', 'samswiss_flyers_nonce' );

	$slots  = samswiss_flyer_slots();
	$langs  = samswiss_flyer_languages();
	$posted = isset( $_POST['flyer'] ) && is_array( $_POST['flyer'] ) ? wp_unslash( $_POST['flyer'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- ogni valore passa da intval sotto.
	$clean  = array();

	foreach ( $slots as $slot => $info ) {
		foreach ( $langs as $lang => $name ) {
			$value = isset( $posted[ $slot ][ $lang ] ) ? intval( $posted[ $slot ][ $lang ] ) : 0;
			if ( -1 === $value || ( $value > 0 && wp_attachment_is_image( $value ) ) ) {
				$clean[ $slot ][ $lang ] = $value;
			}
		}
	}

	update_option( 'samswiss_flyers', $clean, false );

	// Le pagine in cache mostrerebbero ancora il volantino di prima.
	do_action( 'litespeed_purge_all' );

	wp_safe_redirect( add_query_arg( array( 'page' => 'samswiss-flyers', 'updated' => 1 ), admin_url( 'admin.php' ) ) );
	exit;
}
add_action( 'admin_post_samswiss_save_flyers', 'samswiss_save_flyers' );

function samswiss_render_flyers_page() {
	$slots = samswiss_flyer_slots();
	$langs = samswiss_flyer_languages();
	$saved = get_option( 'samswiss_flyers', array() );
	?>
	<div class="wrap samswiss-flyers-admin">
		<h1><?php esc_html_e( 'Volantini', 'samswiss-child' ); ?></h1>
		<p style="max-width:760px;font-size:14px;">
			<?php esc_html_e( 'Qui scegli il volantino che appare in ogni pagina, lingua per lingua. Clicca «Scegli immagine», carica il file (JPG o PNG, in verticale) oppure prendilo dalla Libreria media, poi premi «Salva i volantini» in fondo. Ogni lingua mostra solo il suo volantino: se una lingua non ne ha, il riquadro non compare.', 'samswiss-child' ); ?>
		</p>

		<?php if ( isset( $_GET['updated'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
			<div class="notice notice-success is-dismissible"><p><strong><?php esc_html_e( 'Volantini salvati. Sono già visibili sul sito.', 'samswiss-child' ); ?></strong></p></div>
		<?php endif; ?>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="samswiss_save_flyers">
			<?php wp_nonce_field( 'samswiss_save_flyers', 'samswiss_flyers_nonce' ); ?>

			<?php foreach ( $slots as $slot => $info ) : ?>
				<div style="background:#fff;border:1px solid #ccd0d4;border-radius:8px;padding:20px;margin:24px 0;">
					<h2 style="margin:0 0 4px;font-size:18px;">
						<?php echo esc_html( $info['label'] ); ?>
						<a href="<?php echo esc_url( $info['url'] ); ?>" target="_blank" rel="noopener" style="font-size:13px;font-weight:400;margin-left:8px;"><?php esc_html_e( 'Vedi la pagina', 'samswiss-child' ); ?> &#8599;</a>
					</h2>
					<p style="margin:0 0 16px;color:#50575e;"><?php echo esc_html( $info['desc'] ); ?></p>

					<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:16px;">
						<?php
						foreach ( $langs as $lang => $lang_name ) :
							$value    = isset( $saved[ $slot ][ $lang ] ) ? (int) $saved[ $slot ][ $lang ] : 0;
							$original = samswiss_flyer_theme_file( $slot, $lang );
							$orig_url = $original ? get_stylesheet_directory_uri() . '/' . $original : '';
							$thumb    = '';
							if ( $value > 0 ) {
								$thumb = wp_get_attachment_image_url( $value, 'medium' );
							} elseif ( 0 === $value ) {
								$thumb = $orig_url;
							}
							?>
							<div class="samswiss-flyer-cell" data-original="<?php echo esc_url( $orig_url ); ?>" style="border:1px solid #e2e4e7;border-radius:6px;padding:12px;background:#f9fbf7;">
								<strong style="display:block;margin-bottom:8px;"><?php echo esc_html( $lang_name ); ?></strong>
								<input type="hidden" class="samswiss-flyer-value" name="flyer[<?php echo esc_attr( $slot ); ?>][<?php echo esc_attr( $lang ); ?>]" value="<?php echo esc_attr( $value ); ?>">
								<div class="samswiss-flyer-preview" style="height:200px;display:flex;align-items:center;justify-content:center;background:#fff;border:1px solid #e2e4e7;border-radius:4px;margin-bottom:6px;overflow:hidden;">
									<img src="<?php echo esc_url( $thumb ); ?>" alt="" style="max-width:100%;max-height:100%;<?php echo $thumb ? '' : 'display:none;'; ?>">
									<span class="samswiss-flyer-empty" style="color:#8c8f94;font-size:12px;text-align:center;padding:8px;<?php echo $thumb ? 'display:none;' : ''; ?>"><?php esc_html_e( 'Nessun volantino: in questa lingua il riquadro non compare', 'samswiss-child' ); ?></span>
								</div>
								<p class="samswiss-flyer-state" style="margin:0 0 8px;font-size:12px;color:#646970;min-height:16px;">
									<?php
									if ( $value > 0 ) {
										esc_html_e( 'Immagine scelta da te', 'samswiss-child' );
									} elseif ( 0 === $value && $orig_url ) {
										esc_html_e( 'Volantino originale', 'samswiss-child' );
									}
									?>
								</p>
								<button type="button" class="button button-primary samswiss-flyer-pick" style="width:100%;margin-bottom:6px;"><?php esc_html_e( 'Scegli immagine', 'samswiss-child' ); ?></button>
								<button type="button" class="button samswiss-flyer-remove" style="width:100%;margin-bottom:6px;"><?php esc_html_e( 'Togli', 'samswiss-child' ); ?></button>
								<?php if ( $orig_url ) : ?>
									<button type="button" class="button-link samswiss-flyer-reset" style="font-size:12px;"><?php esc_html_e( 'Rimetti l’originale', 'samswiss-child' ); ?></button>
								<?php endif; ?>
							</div>
						<?php endforeach; ?>
					</div>
				</div>
			<?php endforeach; ?>

			<?php submit_button( __( 'Salva i volantini', 'samswiss-child' ) ); ?>
		</form>
	</div>
	<?php
}
