<?php
/**
 * Show the new "Soluzioni"/"Ortofrutta"/"Macchine d'Occasione" primary-menu items
 * in every language, not just Italian.
 *
 * THE BUG. WPML does not filter a shared menu's items by translation status the
 * way a page's content is filtered — it keeps a genuinely SEPARATE `nav_menu`
 * taxonomy term per language (confirmed by querying `icl_translations`/
 * `wp_get_object_terms`: Italian is term 33, English is term 1256, French 1257,
 * German 1258, Hungarian 1259, Romanian 1260, Russian 1261, Slovak 1262), each
 * with its OWN small set of `nav_menu_item` posts actually assigned via
 * `wp_set_object_terms( $item_id, $term_id, 'nav_menu' )`. `wp_nav_menu()` swaps
 * to that language's term transparently. So every item added straight to the
 * Italian menu (term 33) with wp-cli — which is how Soluzioni, Ortofrutta's
 * current shape, and Macchine d'Occasione were built this session — is
 * invisible in every other language: it was never assigned to THEIR term, only
 * to Italian's.
 *
 * THE PROPER FIX would be WPML's own "Menus Sync" admin feature (Appearance →
 * Menus), which creates those per-language items through its own internal
 * AJAX-only class. It is not meant to be driven headlessly, and reassigning the
 * new items to each language's `nav_menu` term directly does not stick either —
 * WPML's own term-assignment guard for that taxonomy silently reverts it
 * (measured: `wp_set_object_terms()` returns success but the term comes right
 * back to 33 on the next read).
 *
 * THIS FIX. The translated items DO already exist as real posts — created with
 * `wp_update_nav_menu_item()` and correctly registered per language in
 * `icl_translations` (trid grouped with their Italian originals) — they are
 * just never reachable through the language-specific `nav_menu` term. This
 * filter runs on `wp_nav_menu_objects`, the hook WordPress itself calls right
 * before turning the item list into markup, i.e. AFTER WPML has already chosen
 * which language term to read from. For any language but Italian it appends the
 * known translated item IDs for that language, decorated through
 * `wp_setup_nav_menu_item()` — the same core function WordPress uses to prepare
 * every other item — so they render identically to a "natively" translated one.
 *
 * Two children could not be included in any language yet and are not listed
 * below: "Fine Linea e Pallettizzazione" and the "Sorma Group" item itself. Not
 * a menu problem — their destination, the Sorma Group page, has never been
 * translated at all (confirmed: `wpml_object_id_filter( 26425, 'page', false,
 * $lang )` returns nothing for any of the seven), and its own URL does not even
 * fall back to the Italian version in another language context — it redirects
 * to the home page instead. That page needs a real translation before either
 * item can be added here.
 *
 * PORTABILITY. The item IDs below are specific to the database they were
 * created on — they mean nothing on a copy of this site with its own post ID
 * sequence (e.g. production, after a theme-only deploy). `samswiss_menu_i18n_extra_ids()`
 * therefore checks the `samswiss_menu_i18n_ids` option first and only falls
 * back to this install's own numbers when nothing has been stored — see the
 * "SAM SWISS — Deploy Helper" plugin, whose job is to create the equivalent
 * items on another install and populate that option.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Item IDs for each non-Italian language, in the shape `wp_update_nav_menu_item()`
 * produces them. Each `children` id already carries the correct
 * `_menu_item_menu_item_parent` meta pointing at its own language's Soluzioni id
 * — set at creation time, not something this filter has to reconstruct.
 *
 * These IDs are per-install (a menu item created on this database will never
 * exist under the same numbers elsewhere), so this reads an option first —
 * populated on any OTHER install by the "SAM SWISS — Deploy Helper" plugin's
 * "Crea le voci di menu tradotte" action — and only falls back to this site's
 * own already-created items when nothing has been stored yet.
 */
function samswiss_menu_i18n_extra_ids() {
	$stored = get_option( 'samswiss_menu_i18n_ids' );
	if ( is_array( $stored ) && ! empty( $stored ) ) {
		return $stored;
	}
	return array(
		'en' => array( 'ortofrutta' => 26435, 'soluzioni' => 26436, 'children' => array( 26437, 26438, 26439, 26440 ), 'occasione' => 26441 ),
		'fr' => array( 'ortofrutta' => 26442, 'soluzioni' => 26443, 'children' => array( 26444, 26445, 26446, 26447 ), 'occasione' => 26448 ),
		'de' => array( 'ortofrutta' => 26449, 'soluzioni' => 26450, 'children' => array( 26451, 26452, 26453, 26454 ), 'occasione' => 26455 ),
		'hu' => array( 'ortofrutta' => 26456, 'soluzioni' => 26457, 'children' => array( 26458, 26459, 26460, 26461 ), 'occasione' => 26462 ),
		'ro' => array( 'ortofrutta' => 26463, 'soluzioni' => 26464, 'children' => array( 26465, 26466, 26467, 26468 ), 'occasione' => 26469 ),
		'ru' => array( 'ortofrutta' => 26470, 'soluzioni' => 26471, 'children' => array( 26472, 26473, 26474, 26475 ), 'occasione' => 26476 ),
		'sk' => array( 'ortofrutta' => 26477, 'soluzioni' => 26478, 'children' => array( 26479, 26480, 26481, 26482 ), 'occasione' => 26483 ),
	);
}

/**
 * The six native items ("Home", "Imballaggi e Monouso", "Ingredienti",
 * "InfoNews", "Chi Siamo", "Contatti") that already exist per language through
 * ordinary WPML content translation — unlike Soluzioni/Ortofrutta/Occasione,
 * they have a real Italian-side page or product_cat term to translate FROM, so
 * their position never needs a stored per-install ID: it is resolved below by
 * matching each item actually present in $items against `wpml_object_id()` of
 * this Italian source, for the language being rendered.
 *
 * @return array<int,array{id:int,type:string}> position => Italian source.
 */
function samswiss_menu_i18n_native_anchors() {
	return array(
		1 => array( 'id' => 203,  'type' => 'page' ),        // Home (Macchine confezionatrici)
		4 => array( 'id' => 1270, 'type' => 'product_cat' ), // Imballaggi e Monouso
		5 => array( 'id' => 1301, 'type' => 'product_cat' ), // Ingredienti
		7 => array( 'id' => 2225, 'type' => 'page' ),         // InfoNews
		8 => array( 'id' => 229,  'type' => 'page' ),         // Chi Siamo
		9 => array( 'id' => 569,  'type' => 'page' ),         // Contatti
	);
}

/**
 * Top-level order for one language's items: 1 Home, 2 Soluzioni, 3 Ortofrutta,
 * 4 Imballaggi e Monouso, 5 Ingredienti, 6 Macchine d'Occasione, 7 InfoNews,
 * 8 Chi Siamo, 9 Contatti — matching the Italian menu's own order. Built from
 * $items themselves (via the native anchors above) plus the three stored IDs,
 * not from a hardcoded ID list — those numbers are per-install and would not
 * mean anything on a different WordPress database.
 *
 * Forced here rather than trusted from `$item->menu_order`: measured, on the
 * six pre-existing translated items, that property arrives already resorted
 * to 1..6 by the time it reaches `wp_nav_menu_objects` regardless of what
 * `wp_posts.menu_order` or the term relationship's `term_order` say — neither
 * survives whatever WPML/WordPress does to the array before this filter runs.
 *
 * @param WP_Post[] $items Items already in the menu for this language.
 * @param string    $lang  Current WPML language code.
 * @param array     $extra This language's samswiss_menu_i18n_extra_ids() entry.
 * @return array<int,int> menu item post ID => position.
 */
function samswiss_menu_i18n_top_level_order( $items, $lang, $extra ) {
	$positions = array(
		(int) $extra['soluzioni']  => 2,
		(int) $extra['ortofrutta'] => 3,
		(int) $extra['occasione']  => 6,
	);

	$anchors = samswiss_menu_i18n_native_anchors();
	foreach ( $items as $item ) {
		if ( empty( $item->object_id ) || empty( $item->object ) ) {
			continue;
		}
		foreach ( $anchors as $position => $anchor ) {
			if ( $anchor['type'] !== $item->object ) {
				continue;
			}
			$translated_id = (int) apply_filters( 'wpml_object_id', $anchor['id'], $anchor['type'], true, $lang );
			if ( $translated_id && $translated_id === (int) $item->object_id ) {
				$positions[ (int) $item->ID ] = $position;
				break;
			}
		}
	}

	return $positions;
}

/**
 * @param WP_Post[]|null $items Already-resolved menu items for this menu/language.
 * @param stdClass       $args  wp_nav_menu() args, includes theme_location.
 * @return WP_Post[]
 */
function samswiss_add_untranslated_menu_items( $items, $args ) {
	if ( empty( $args->theme_location ) || 'primary' !== $args->theme_location ) {
		return $items;
	}

	$lang = apply_filters( 'wpml_current_language', null );
	if ( ! $lang || 'it' === $lang ) {
		return $items; // Italian already has every item natively.
	}

	$map = samswiss_menu_i18n_extra_ids();
	if ( empty( $map[ $lang ] ) ) {
		return $items;
	}

	$extra_ids = array_merge(
		array( $map[ $lang ]['soluzioni'], $map[ $lang ]['ortofrutta'], $map[ $lang ]['occasione'] ),
		$map[ $lang ]['children']
	);

	$existing_ids = wp_list_pluck( $items, 'ID' );

	foreach ( $extra_ids as $id ) {
		if ( in_array( (int) $id, $existing_ids, true ) ) {
			continue; // Already there (e.g. this filter ran twice for one request).
		}
		$post = get_post( $id );
		if ( ! $post || 'publish' !== $post->post_status ) {
			continue; // A future edit removed or unpublished it: fail quietly, not with a broken link.
		}
		$items[] = wp_setup_nav_menu_item( $post );
	}

	$positions = samswiss_menu_i18n_top_level_order( $items, $lang, $map[ $lang ] );

	usort( $items, function ( $a, $b ) use ( $positions ) {
		// A child (has menu_item_parent) is never in $positions and always
		// sorts after every top-level item; order among children themselves
		// does not matter here, Walker_Nav_Menu groups them under their
		// parent by menu_item_parent regardless of their position in this
		// flat array.
		$pos_a = $positions[ (int) $a->ID ] ?? 99;
		$pos_b = $positions[ (int) $b->ID ] ?? 99;
		return $pos_a <=> $pos_b;
	} );

	return $items;
}
add_filter( 'wp_nav_menu_objects', 'samswiss_add_untranslated_menu_items', 10, 2 );
