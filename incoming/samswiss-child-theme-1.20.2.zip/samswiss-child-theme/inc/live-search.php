<?php
/**
 * SAM SWISS child theme — live product search.
 *
 * Suggests products while the visitor types, in whatever language the site is
 * currently in. The catalogue is 131 products with long spec-string names
 * ("BOX MENU CON COPERCHIO INCERNIERATO, 2 SCOMPARTI / BAGASSA / 241 X 163 X 65
 * MM"), so typing the exact title is unrealistic — matching a fragment and
 * showing the answer immediately is the difference between finding an item and
 * giving up.
 *
 * Products only, on purpose: the full-page search covers pages and machine
 * articles too, and the suggestion list always ends with a link to it.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * How many suggestions to return. Enough to be useful, few enough to scan.
 */
const SAMSWISS_LIVE_SEARCH_LIMIT = 6;


/**
 * Turn a price/HTML fragment into plain text fit for textContent.
 *
 * @param string $html Markup.
 * @return string
 */
function samswiss_plain_text( $html ) {
	$text = wp_strip_all_tags( (string) $html );
	$text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
	// Non-breaking spaces come back as U+00A0; normalise so the row wraps sanely.
	$text = str_replace( "\xc2\xa0", ' ', $text );

	return trim( preg_replace( '/\s+/u', ' ', $text ) );
}

/**
 * Return product suggestions for a search fragment.
 */
function samswiss_live_search() {
	check_ajax_referer( 'samswiss_live_search', 'nonce' );

	$term = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : '';
	$term = trim( $term );

	if ( mb_strlen( $term ) < 2 ) {
		wp_send_json( array( 'results' => array(), 'total' => 0, 'query' => $term ) );
	}

	$args = array(
		'post_type'           => 'product',
		'post_status'         => 'publish',
		's'                   => $term,
		'posts_per_page'      => SAMSWISS_LIVE_SEARCH_LIMIT,
		'ignore_sticky_posts' => true,
		'no_found_rows'       => false,
		// Hidden products must not surface in a suggestion the visitor can click.
		'tax_query'           => array(
			array(
				'taxonomy' => 'product_visibility',
				'field'    => 'name',
				'terms'    => array( 'exclude-from-search' ),
				'operator' => 'NOT IN',
			),
		),
	);

	$query   = new WP_Query( $args );
	$results = array();

	foreach ( $query->posts as $post ) {
		$product = function_exists( 'wc_get_product' ) ? wc_get_product( $post->ID ) : null;
		$thumb   = get_the_post_thumbnail_url( $post->ID, 'thumbnail' );

		$results[] = array(
			'title' => html_entity_decode( get_the_title( $post ), ENT_QUOTES, 'UTF-8' ),
			'url'   => get_permalink( $post ),
			// Decoded and stripped: the JS writes this with textContent, so an entity
			// would render literally as "&#67;&#72;&#70;" instead of "CHF".
			'price' => $product ? samswiss_plain_text( $product->get_price_html() ) : '',
			'thumb' => $thumb ? $thumb : '',
		);
	}

	wp_send_json( array(
		'results' => $results,
		'total'   => (int) $query->found_posts,
		'query'   => $term,
	) );
}
add_action( 'wp_ajax_samswiss_live_search', 'samswiss_live_search' );
add_action( 'wp_ajax_nopriv_samswiss_live_search', 'samswiss_live_search' );

/**
 * Print a search field wired for live suggestions.
 *
 * The field is a real form input inside a real GET form: with JavaScript off it
 * submits to the search results page exactly as before, and the suggestion panel
 * simply never opens. ARIA follows the combobox pattern so the list is usable
 * from the keyboard and announced by a screen reader.
 *
 * @param array $args id, placeholder, label, input_class, submit_class, submit_label.
 */
function samswiss_live_search_field( $args = array() ) {
	$args = wp_parse_args( $args, array(
		'id'           => 'samswiss-live-search',
		'placeholder'  => __( 'Macchine, imballaggi, consumabili…', 'samswiss-child' ),
		'label'        => __( 'Cerca nel sito', 'samswiss-child' ),
		'label_class'  => 'screen-reader-text',
		'input_class'  => '',
		'submit_class' => '',
		'submit_label' => __( 'Cerca', 'samswiss-child' ),
	) );

	$list_id = $args['id'] . '-suggestions';
	?>
	<label class="<?php echo esc_attr( $args['label_class'] ); ?>" for="<?php echo esc_attr( $args['id'] ); ?>"><?php echo esc_html( $args['label'] ); ?></label>
	<div class="samswiss-live-search">
		<input
			class="<?php echo esc_attr( $args['input_class'] ); ?>"
			id="<?php echo esc_attr( $args['id'] ); ?>"
			type="search"
			name="s"
			value="<?php echo esc_attr( get_search_query() ); ?>"
			placeholder="<?php echo esc_attr( $args['placeholder'] ); ?>"
			autocomplete="off"
			role="combobox"
			aria-expanded="false"
			aria-controls="<?php echo esc_attr( $list_id ); ?>"
			aria-autocomplete="list"
			data-live-search>
		<button class="<?php echo esc_attr( $args['submit_class'] ); ?>" type="submit"><?php echo esc_html( $args['submit_label'] ); ?></button>
		<div class="samswiss-live-search__panel" id="<?php echo esc_attr( $list_id ); ?>" role="listbox" aria-label="<?php esc_attr_e( 'Prodotti suggeriti', 'samswiss-child' ); ?>" hidden></div>
	</div>
	<p class="screen-reader-text" aria-live="polite" data-live-search-status></p>
	<?php
}
