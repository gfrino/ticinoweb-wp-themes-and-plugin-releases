<?php
/**
 * Social marks, rendered as inline SVG.
 *
 * Two problems solved in one place.
 *
 * 1. **Scope.** The marks used to be printed only inside the header's "blog"
 *    variant, as the alternative to the cart — which is why they appeared on the
 *    Macchine landing and on articles and nowhere else. They belong to the site,
 *    not to a page template.
 *
 * 2. **Delivery.** They were glyphs from Font Awesome, loaded from cdnjs. A theme
 *    that needs a third-party CDN to draw its own brand marks fails whenever that
 *    request fails — a blocked host, a CSP, an older Font Awesome without
 *    `fa-x-twitter` (added in 6.4.2). Inline SVG has no such failure mode, adds no
 *    request, and cannot 404.
 *
 * The icons are the official simple marks, drawn on a 24x24 viewBox and inheriting
 * `currentColor`, so every existing hover and colour rule keeps working.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The SVG path data, keyed by the contact-info field that holds the URL.
 *
 * @return array<string,array{label:string,path:string}>
 */
function samswiss_social_marks() {
	return array(
		'facebook'  => array(
			'label' => 'Facebook',
			'path'  => 'M14 8.5V7a1 1 0 0 1 1-1h1.5V3.2A13 13 0 0 0 14.8 3C12.6 3 11 4.4 11 7v1.5H8.5V12H11v9h3v-9h2.3l.5-3.5H14z',
		),
		'x'         => array(
			'label' => 'X',
			'path'  => 'M17.6 3h2.9l-6.4 7.3L21.7 21h-5.9l-4.6-6-5.3 6H3l6.8-7.8L2.6 3h6l4.2 5.5L17.6 3zm-1 16.2h1.6L8.4 4.7H6.7l9.9 14.5z',
		),
		'youtube'   => array(
			'label' => 'YouTube',
			'path'  => 'M21.6 7.2a2.5 2.5 0 0 0-1.8-1.8C18.2 5 12 5 12 5s-6.2 0-7.8.4a2.5 2.5 0 0 0-1.8 1.8A26 26 0 0 0 2 12a26 26 0 0 0 .4 4.8 2.5 2.5 0 0 0 1.8 1.8C5.8 19 12 19 12 19s6.2 0 7.8-.4a2.5 2.5 0 0 0 1.8-1.8A26 26 0 0 0 22 12a26 26 0 0 0-.4-4.8zM10 15V9l5.2 3-5.2 3z',
		),
		'instagram' => array(
			'label' => 'Instagram',
			'path'  => 'M12 4.6c2.4 0 2.7 0 3.6.05.9.04 1.4.2 1.7.32.43.17.74.37 1.06.7.32.31.52.62.69 1.05.12.3.28.8.32 1.7.05.9.05 1.2.05 3.6s0 2.7-.05 3.6c-.04.9-.2 1.4-.32 1.7-.17.43-.37.74-.7 1.06-.31.32-.62.52-1.05.69-.3.12-.8.28-1.7.32-.9.05-1.2.05-3.6.05s-2.7 0-3.6-.05c-.9-.04-1.4-.2-1.7-.32a2.9 2.9 0 0 1-1.06-.7 2.9 2.9 0 0 1-.69-1.05c-.12-.3-.28-.8-.32-1.7C4.6 14.7 4.6 14.4 4.6 12s0-2.7.05-3.6c.04-.9.2-1.4.32-1.7.17-.43.37-.74.7-1.06.31-.32.62-.52 1.05-.69.3-.12.8-.28 1.7-.32.9-.05 1.2-.05 3.6-.05M12 3c-2.44 0-2.75.01-3.7.06-.96.04-1.61.2-2.18.42-.6.23-1.1.54-1.6 1.04-.5.5-.81 1-1.04 1.6-.22.57-.38 1.22-.42 2.18C3.01 9.25 3 9.56 3 12s.01 2.75.06 3.7c.4.96.2 1.61.42 2.18.23.6.54 1.1 1.04 1.6.5.5 1 .81 1.6 1.04.57.22 1.22.38 2.18.42.95.05 1.26.06 3.7.06s2.75-.01 3.7-.06c.96-.04 1.61-.2 2.18-.42.6-.23 1.1-.54 1.6-1.04.5-.5.81-1 1.04-1.6.22-.57.38-1.22.42-2.18.05-.95.06-1.26.06-3.7s-.01-2.75-.06-3.7c-.04-.96-.2-1.61-.42-2.18a4.5 4.5 0 0 0-1.04-1.6 4.5 4.5 0 0 0-1.6-1.04c-.57-.22-1.22-.38-2.18-.42C14.75 3.01 14.44 3 12 3zm0 4.38a4.62 4.62 0 1 0 0 9.24 4.62 4.62 0 0 0 0-9.24zm0 7.62a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm5.88-7.8a1.08 1.08 0 1 1-2.16 0 1.08 1.08 0 0 1 2.16 0z',
		),
		// LinkedIn's mark IS the square with "in" inside it — unlike the bare glyphs
		// above, there is no unbranded "just the letters" form in general use, so
		// drawing only "in" would not read as LinkedIn. This path draws the square
		// and both letters as ONE shape: the square and the letters wind in opposite
		// directions, so the default nonzero fill rule cuts the letters OUT of the
		// square instead of floating them separately on top of it. A first version
		// used a letters-only path with no enclosing square, and the "i" and "n"
		// read as two disconnected marks — caught by the client on sight.
		'linkedin'  => array(
			'label' => 'LinkedIn',
			'path'  => 'M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z',
		),
	);
}

/**
 * Print the social links.
 *
 * Renders nothing at all when no social URL is configured, rather than an empty
 * row of dead icons.
 *
 * @param string $class Wrapper class.
 * @return void
 */
function samswiss_social_links( $class = 'samswiss-social' ) {
	$contact = function_exists( 'samswiss_get_contact' ) ? samswiss_get_contact() : array();
	$marks   = samswiss_social_marks();

	$available = array_filter(
		$marks,
		function ( $key ) use ( $contact ) {
			return ! empty( $contact[ $key ] );
		},
		ARRAY_FILTER_USE_KEY
	);

	if ( empty( $available ) ) {
		return;
	}

	echo '<span class="' . esc_attr( $class ) . '">';
	foreach ( $available as $key => $mark ) {
		printf(
			'<a href="%1$s" target="_blank" rel="noopener" aria-label="%2$s">%3$s</a>',
			esc_url( $contact[ $key ] ),
			esc_attr( $mark['label'] ),
			samswiss_social_svg( $mark['path'] ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from a fixed path table below.
		);
	}
	echo '</span>';
}

/**
 * One mark. `currentColor` so the existing colour and hover rules still own it.
 *
 * @param string $path SVG path data from the table above.
 * @return string
 */
function samswiss_social_svg( $path ) {
	return '<svg class="samswiss-social__mark" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false" fill="currentColor"><path d="' . esc_attr( $path ) . '"/></svg>';
}
