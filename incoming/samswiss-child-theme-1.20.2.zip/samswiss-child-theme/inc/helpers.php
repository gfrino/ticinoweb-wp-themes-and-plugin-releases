<?php
/**
 * SAM SWISS child theme — presentation helpers.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return the SAM SA contact details, reusing the parent CMS helper where
 * available and falling back to the known SAM SA values otherwise.
 *
 * @return array{phone:string,phone_display:string,email:string,address:string,vat:string,facebook:string,instagram:string,youtube:string,x:string,linkedin:string,tiktok:string}
 */
function samswiss_get_contact() {
	// Social profiles used to be read only from the ticinoWEB CMS options. That is
	// per-install data: on the live server those rows were never filled, the URLs
	// came back empty and the icons were simply not printed — which is why they were
	// missing online while they showed here. SAM's profiles are brand facts, not
	// configuration, so they ship as defaults and the CMS overrides them when set.
	//
	// The distinction below is deliberate: get_option() returns null when the row
	// does not exist and '' when it exists but was cleared. A cleared field must
	// still hide its icon, so only a MISSING row falls back to the default.
	$profiles = array(
		'facebook'  => 'https://www.facebook.com/sam.sa.982292/',
		'instagram' => 'https://www.instagram.com/sam_sa_swissmade',
		'youtube'   => 'https://www.youtube.com/channel/UCH8hCG-BuOGIJpV7Z45DOHQ',
		'x'         => 'https://x.com/SistemiSa',
		'linkedin'  => '',
		'tiktok'    => '',
	);

	$defaults = array(
		'phone'         => '+41916404010',
		'phone_display' => '+41 (0) 91 640 40 10',
		'email'         => 'info@samswiss.com',
		'address'       => 'Via Sottobisio 9, CH - 6828 Balerna (Ticino)',
		'vat'           => 'CHE-106.499.609',
	);

	foreach ( $profiles as $key => $fallback ) {
		$stored           = get_option( 'ticinoweb_contact_' . $key, null );
		$defaults[ $key ] = ( null === $stored ) ? $fallback : (string) $stored;
	}

	if ( function_exists( 'ticinoweb_get_contact_info' ) ) {
		$info = ticinoweb_get_contact_info();
		if ( ! empty( $info['phone'] ) ) {
			$defaults['phone'] = preg_replace( '/[^0-9+]/', '', $info['phone'] );
			$defaults['phone_display'] = $info['phone'];
		}
		// Migration left `info@localhost` in some option rows; only trust a real address.
		if ( ! empty( $info['email'] ) && strpos( $info['email'], 'localhost' ) === false ) {
			$defaults['email'] = $info['email'];
		}
		foreach ( array( 'facebook', 'instagram', 'linkedin', 'address' ) as $k ) {
			if ( ! empty( $info[ $k ] ) ) {
				$defaults[ $k ] = $info[ $k ];
			}
		}
	}

	return $defaults;
}

/**
 * Render the WPML language switcher exactly as the original header/footer:
 * a list of the active languages with native names. Degrades to nothing when
 * WPML is not active.
 *
 * @param array $args { display: 'dropdown'|'inline', show_flags: bool }
 */
function samswiss_language_switcher( $args = array() ) {
	$args = wp_parse_args( $args, array(
		'display'    => 'inline',
		'show_names' => true,
		'show_flags' => false,
		'class'      => '',
	) );

	if ( ! function_exists( 'icl_get_languages' ) && ! has_filter( 'wpml_active_languages' ) ) {
		return;
	}

	$languages = apply_filters( 'wpml_active_languages', null, array( 'skip_missing' => 0, 'orderby' => 'custom' ) );
	if ( empty( $languages ) ) {
		return;
	}

	$wrapper_class = 'samswiss-lang-switcher samswiss-lang-' . esc_attr( $args['display'] );
	if ( $args['class'] ) {
		$wrapper_class .= ' ' . esc_attr( $args['class'] );
	}

	$current = '';
	foreach ( $languages as $lang ) {
		if ( ! empty( $lang['active'] ) ) {
			$current = $lang;
		}
	}
	?>
	<div class="<?php echo esc_attr( $wrapper_class ); ?>">
		<?php if ( 'dropdown' === $args['display'] && $current ) : ?>
			<button type="button" class="samswiss-lang-current" aria-haspopup="true" aria-expanded="false">
				<span class="lang-code"><?php echo esc_html( strtoupper( $current['language_code'] ) ); ?></span>
				<i class="fas fa-chevron-down" aria-hidden="true"></i>
			</button>
		<?php endif; ?>
		<ul class="samswiss-lang-list">
			<?php foreach ( $languages as $lang ) :
				$is_active = ! empty( $lang['active'] );
				?>
				<li class="samswiss-lang-item<?php echo $is_active ? ' is-active' : ''; ?>">
					<a href="<?php echo esc_url( $lang['url'] ); ?>" hreflang="<?php echo esc_attr( $lang['language_code'] ); ?>" lang="<?php echo esc_attr( $lang['language_code'] ); ?>" title="<?php echo esc_attr( $lang['translated_name'] ); ?>">
						<?php if ( $args['show_flags'] && ! empty( $lang['country_flag_url'] ) ) : ?>
							<img class="samswiss-lang-flag" src="<?php echo esc_url( $lang['country_flag_url'] ); ?>" alt="<?php echo esc_attr( $lang['translated_name'] ); ?>" width="18" height="12">
						<?php endif; ?>
						<?php if ( $args['show_names'] ) : ?>
							<span class="samswiss-lang-name"><?php echo esc_html( $lang['native_name'] ); ?></span>
						<?php elseif ( ! $args['show_flags'] ) : ?>
							<span class="samswiss-lang-code"><?php echo esc_html( strtoupper( $lang['language_code'] ) ); ?></span>
						<?php endif; ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
	<?php
}

/**
 * Return the site logo URL, reusing the parent helper then falling back to the
 * WordPress custom logo and finally the known SAM SA logo attachment.
 */
function samswiss_get_logo_url() {
	if ( function_exists( 'ticinoweb_get_site_logo' ) ) {
		$logo = ticinoweb_get_site_logo();
		if ( ! empty( $logo ) ) {
			return $logo;
		}
	}
	$custom_logo_id = get_theme_mod( 'custom_logo' );
	if ( $custom_logo_id ) {
		$img = wp_get_attachment_image_src( $custom_logo_id, 'full' );
		if ( $img ) {
			return $img[0];
		}
	}
	// Known SAM SA logo (with tagline + Swiss flag), resolved portably via uploads.
	$uploads = wp_get_upload_dir();
	return trailingslashit( $uploads['baseurl'] ) . '2020/07/logo_new.png';
}

/**
 * Intrinsic pixel size of the logo, as ready-to-print width/height attributes.
 *
 * The logo is the one image on every single page, and it shipped without
 * dimensions: the browser could not reserve its box, so the header jumped once
 * per page load. CSS still controls the rendered height; these attributes only
 * give the aspect ratio up front.
 *
 * Measured from the file, memoized per request, and silent if it cannot be read.
 *
 * @param string $url Logo URL, defaults to samswiss_get_logo_url().
 * @return string ` width="467" height="85"` or ''.
 */
function samswiss_logo_dimensions( $url = '' ) {
	static $cache = array();

	$url = $url ? $url : samswiss_get_logo_url();
	if ( isset( $cache[ $url ] ) ) {
		return $cache[ $url ];
	}

	$uploads = wp_get_upload_dir();
	$attr    = '';

	if ( 0 === strpos( $url, $uploads['baseurl'] ) ) {
		$path = $uploads['basedir'] . substr( $url, strlen( $uploads['baseurl'] ) );
		if ( is_readable( $path ) ) {
			$size = wp_getimagesize( $path );
			if ( ! empty( $size[0] ) && ! empty( $size[1] ) ) {
				$attr = sprintf( ' width="%d" height="%d"', (int) $size[0], (int) $size[1] );
			}
		}
	}

	$cache[ $url ] = $attr;

	return $attr;
}

/**
 * Return the permalink for a page or product_cat term, translated to the
 * current WPML language. Pass the DEFAULT-language ID; WPML resolves the
 * equivalent in the active language (falling back to the original if the
 * translation is missing). Guarantees a working URL across all 8 languages.
 *
 * @param int    $default_id Default-language post/term ID.
 * @param string $type       'page' | 'post' | 'product_cat'.
 * @return string
 */
function samswiss_localized_permalink( $default_id, $type = 'page', $slug = '' ) {
	$id = 0;

	// Slug first, ID second. Post and term IDs are per-install: this theme was
	// developed against a local import, and on another database the same numbers
	// point at a different object or at nothing — which is precisely how the gateway
	// links to "Imballaggi e monouso" and "Ingredienti" ended up 404ing on the live
	// server, and from there on the parent theme's 404-to-home redirect, i.e. INTRO.
	// The slug is content, so it travels with the export; the ID is a coincidence of
	// the row order in one database.
	if ( '' !== $slug ) {
		$id = samswiss_id_by_slug( $slug, $type );
	}

	if ( ! $id ) {
		$id = (int) $default_id;
	}

	if ( ! $id ) {
		return '';
	}

	if ( function_exists( 'apply_filters' ) ) {
		$translated = apply_filters( 'wpml_object_id', $id, $type, true );
		if ( $translated ) {
			$id = (int) $translated;
		}
	}

	if ( 'product_cat' === $type ) {
		$link = get_term_link( $id, 'product_cat' );
		return is_wp_error( $link ) ? '' : $link;
	}

	$link = get_permalink( $id );
	return $link ? $link : '';
}

/**
 * Resolve a page or term ID from its default-language slug, cached per request.
 *
 * @param string $slug Slug in the default language.
 * @param string $type 'page' or a taxonomy name.
 * @return int Object ID, or 0 when it cannot be resolved.
 */
function samswiss_id_by_slug( $slug, $type = 'page' ) {
	static $cache = array();
	$key = $type . '|' . $slug;
	if ( isset( $cache[ $key ] ) ) {
		return $cache[ $key ];
	}

	$id = 0;

	if ( 'page' === $type ) {
		$page = get_page_by_path( $slug );
		if ( $page instanceof WP_Post ) {
			$id = (int) $page->ID;
		}
	} else {
		// WPML filters term lookups by the current language, so ask for the term in
		// the default language and let the caller translate it as it does for IDs.
		$term = get_term_by( 'slug', $slug, $type );
		if ( $term && ! is_wp_error( $term ) ) {
			$id = (int) $term->term_id;
		}
	}

	$cache[ $key ] = $id;

	return $id;
}

/**
 * Return the archive URL for a blog category by slug, WPML-aware. Falls back to
 * a home-relative URL if the term cannot be resolved.
 *
 * @param string $slug Category slug (default language).
 * @return string
 */
function samswiss_category_url( $slug ) {
	$term = get_term_by( 'slug', $slug, 'category' );
	if ( $term && ! is_wp_error( $term ) ) {
		$id   = (int) apply_filters( 'wpml_object_id', $term->term_id, 'category', true );
		$link = get_term_link( $id ?: $term->term_id, 'category' );
		if ( ! is_wp_error( $link ) ) {
			return $link;
		}
	}
	return home_url( '/category/packaging-lines/' . $slug . '/' );
}

/**
 * Map of the rich Elementor landing pages to their template-part slug, keyed by
 * DEFAULT-language page ID. Used to route custom native layouts across all
 * WPML languages.
 *
 * @return array<int,string>
 */
function samswiss_landing_map() {
	return array(
		'sam-sa-packaging-lines'                              => 'macchine-confezionatrici',
		'sam-sa-ingredients-packaging'                        => 'imballaggi-monouso',
		'second-hand-machines-doccasion-gebrauchte-maschinen' => 'second-hand',
		'infonews'                                            => 'infonews',
		// ORTOFRUTTA → SORMA GROUP. A commercial presentation, not a catalogue page:
		// its body is empty on purpose and the layout lives in the template part.
		'sorma-group'                                         => 'sorma-group',
		'imballaggi-e-consumabili'                            => 'imballaggi-e-consumabili',
	);
}

/**
 * The same map keyed by the IDs of the install this theme was built against.
 *
 * Kept only as a fallback for the case where a page was given a different slug:
 * it is a coincidence of one database, not a fact about the site.
 *
 * @return array<int,string>
 */
function samswiss_landing_map_legacy_ids() {
	return array(
		203  => 'macchine-confezionatrici',
		215  => 'imballaggi-monouso',
		5886 => 'second-hand',
		2225 => 'infonews',
	);
}

/**
 * If the current page is one of the rich landing pages (in any language),
 * return its template-part slug; otherwise ''.
 *
 * @return string
 */
function samswiss_current_landing_slug() {
	if ( ! is_page() ) {
		return '';
	}
	$id      = get_queried_object_id();
	$default = (int) apply_filters( 'wpml_object_id', $id, 'page', true, apply_filters( 'wpml_default_language', null ) );

	// Slug of the default-language original: it survives an export, an import and a
	// change of database, which the ID does not.
	$post = get_post( $default ? $default : $id );
	$map  = samswiss_landing_map();
	if ( $post instanceof WP_Post && isset( $map[ $post->post_name ] ) ) {
		return $map[ $post->post_name ];
	}

	$legacy = samswiss_landing_map_legacy_ids();
	if ( isset( $legacy[ $default ] ) ) {
		return $legacy[ $default ];
	}
	if ( isset( $legacy[ $id ] ) ) {
		return $legacy[ $id ];
	}

	return '';
}

/**
 * Whether the current view should use the "blog" header variant (red top bar,
 * social icons, no cart) instead of the eCommerce header (navy, cart).
 * Mirrors the original site's Elementor header display conditions:
 * Header_blog was shown on the Macchine confezionatrici page (#203), single
 * posts and archives; Header_eCommerce on everything else.
 *
 * @return bool
 */
function samswiss_use_blog_header() {
	$is_blog = ( 'macchine-confezionatrici' === samswiss_current_landing_slug() )
		|| is_singular( 'post' )
		|| is_category() || is_tag() || is_date() || is_author()
		|| ( is_home() && ! is_front_page() );
	return (bool) apply_filters( 'samswiss_use_blog_header', $is_blog );
}

/**
 * Render an uploads-relative image through the media library so WordPress
 * serves a registered size plus srcset, instead of the full-resolution
 * original (some of these masters are several megabytes).
 *
 * Falls back to a plain image tag on the original URL when the file is not a
 * known attachment, so a missing DB row can never blank out the design.
 *
 * @param string $relative_path Path relative to the uploads base URL.
 * @param string $size          Registered image size.
 * @param string $classes       CSS classes for the image tag.
 * @param string $alt           Alt text ('' marks it decorative).
 * @param string $loading       'lazy' or 'eager'; the sector grid sits high enough to load eagerly.
 * @return string Escaped image markup.
 */
function samswiss_uploads_image( $relative_path, $size = 'large', $classes = '', $alt = '', $loading = 'lazy' ) {
	static $ids = array();

	$uploads = wp_get_upload_dir();
	$url     = trailingslashit( $uploads['baseurl'] ) . ltrim( $relative_path, '/' );

	if ( ! array_key_exists( $relative_path, $ids ) ) {
		$id = attachment_url_to_postid( $url );
		if ( ! $id && false !== strpos( $url, '-scaled.' ) ) {
			// WordPress stores the master without the -scaled suffix.
			$id = attachment_url_to_postid( str_replace( '-scaled.', '.', $url ) );
		}
		$ids[ $relative_path ] = $id ? (int) $id : 0;
	}

	if ( $ids[ $relative_path ] ) {
		$markup = wp_get_attachment_image(
			$ids[ $relative_path ],
			$size,
			false,
			array(
				'class'   => $classes,
				'alt'     => $alt,
				'loading' => $loading,
			)
		);

		// WordPress backfills an empty alt with the attachment title, which
		// would read these decorative photos out as file names. Force it back.
		if ( '' === $alt ) {
			$markup = preg_replace( '/\salt="[^"]*"/', ' alt=""', $markup, 1 );
		}

		return samswiss_prefer_jpeg_photos( $markup );
	}

	return samswiss_prefer_jpeg_photos(
		sprintf(
			'<img class="%s" src="%s" alt="%s" loading="%s">',
			esc_attr( $classes ),
			esc_url( $url ),
			esc_attr( $alt ),
			esc_attr( $loading )
		)
	);
}

/**
 * PNG photographs that have a purpose-built JPEG twin beside them on disk.
 *
 * PNG is lossless, so a photograph costs roughly ten times what the same pixels
 * cost as JPEG: these three alone were 2.4 MB of the 3.1 MB the Macchine page
 * downloaded. A JPEG twin of the master and of every registered size sits next to
 * each one (same basename, .jpg extension), so src and every srcset candidate can
 * be rewritten and still resolve.
 *
 * This is an explicit list on purpose, and must stay one. The library already
 * contains unrelated uploads that share a basename across extensions — 04-1.png
 * is 500x500 while 04-1.jpg is a different 1200x800 photo — so a rule like
 * "swap whenever a .jpg exists" would silently serve the wrong image. Only add a
 * basename here after generating its twins from the PNG itself, and never add a
 * PNG that needs its alpha channel: JPEG has none.
 *
 * See docs/cutover-and-rollback.md for the regeneration command.
 */
const SAMSWISS_JPEG_TWINS = array(
	'12001200p402EDNmainlatticini1',
	'WBOX',
	'carne-pesce',
);

/**
 * Serve the JPEG twin of a listed PNG photograph.
 *
 * The originals are untouched and no media library rows are added: this is a
 * delivery-time substitution, not a re-upload. Removing a twin from disk makes
 * delivery fall back to the PNG on the next request.
 *
 * @param string $html Markup that may reference PNG uploads.
 * @return string
 */
function samswiss_prefer_jpeg_photos( $html ) {
	if ( ! is_string( $html ) || false === strpos( $html, '.png' ) ) {
		return $html;
	}

	foreach ( SAMSWISS_JPEG_TWINS as $basename ) {
		if ( false === strpos( $html, $basename ) ) {
			continue;
		}
		// The master, "-scaled", and every "-WIDTHxHEIGHT" derivative — but only
		// where the twin is really on disk. The first version substituted blind, and
		// that is a portability bug, not a detail: the twins were generated into
		// wp-content/uploads, which does NOT travel with a theme. On the live server
		// the PNG originals were all present and answering 200 while every rewritten
		// .jpg answered 404, so three photographs on the machines landing — CASEARIO,
		// CARNE & PESCE, PESATURA ED ETICHETTATURA — rendered as broken images.
		// Checking existence makes the substitution self-limiting: it applies where
		// the lighter file exists and quietly does nothing where it does not, on any
		// install, in either direction, with no deploy step to remember.
		$html = preg_replace_callback(
			'#(' . preg_quote( $basename, '#' ) . '(?:-scaled)?(?:-\d+x\d+)?)\.png#',
			function ( $m ) use ( $html ) {
				return samswiss_jpeg_twin_exists( $m[1], $html ) ? $m[1] . '.jpg' : $m[0];
			},
			$html
		);
	}

	return $html;
}

/**
 * Is the JPEG twin of this upload actually on disk?
 *
 * Answered from the uploads basedir rather than by fetching the URL: one stat()
 * per distinct file per request, memoised, and — as the admin-bar favicon incident
 * taught this theme — memoised PER BLOG, because a plugin may switch_to_blog()
 * while these filters are running.
 *
 * @param string $stem Filename without extension, e.g. "carne-pesce-600x369".
 * @param string $html Markup being filtered, used to recover the year/month folder.
 * @return bool
 */
function samswiss_jpeg_twin_exists( $stem, $html ) {
	static $answers = array();

	$blog = get_current_blog_id();
	if ( isset( $answers[ $blog ][ $stem ] ) ) {
		return $answers[ $blog ][ $stem ];
	}

	// Recover the upload subfolder from the markup: the same file name can only
	// appear under one of them, and this avoids scanning the uploads tree.
	$dir = '';
	if ( preg_match( '#/uploads/(?:sites/\d+/)?(\d{4}/\d{2})/' . preg_quote( $stem, '#' ) . '\.png#', $html, $m ) ) {
		$dir = $m[1] . '/';
	}

	$basedir = untrailingslashit( wp_get_upload_dir()['basedir'] );
	$exists  = ( '' !== $basedir ) && file_exists( $basedir . '/' . $dir . $stem . '.jpg' );

	$answers[ $blog ][ $stem ] = $exists;

	return $exists;
}

// Reach the images this theme renders through WordPress rather than through
// samswiss_uploads_image(): archive thumbnails, product images, post content.
add_filter( 'post_thumbnail_html', 'samswiss_prefer_jpeg_photos', 20 );
add_filter( 'wp_get_attachment_image', 'samswiss_prefer_jpeg_photos', 20 );
add_filter( 'the_content', 'samswiss_prefer_jpeg_photos', 20 );
add_filter( 'woocommerce_short_description', 'samswiss_prefer_jpeg_photos', 20 );

/**
 * URL of the SAM headquarters photo used as a hero background.
 *
 * The library master is 2560x1920 at 968 KB; every surface that uses it puts it
 * behind a dark overlay or in grayscale, where a 1600px pass is
 * indistinguishable at a third of the weight. Falls back to the master so a
 * missing derivative can never blank out a hero.
 *
 * @return string
 */
function samswiss_hero_bg_url() {
	static $url = null;
	if ( null !== $url ) {
		return $url;
	}

	// The theme's own copy first. The derivative used to live only in uploads, which
	// is why the live server showed a different picture at a different aspect ratio:
	// a file generated on a laptop does not travel with a theme export, and the
	// fallback chain quietly landed on the 4:3 master. Now it ships with the code.
	$theme_file = get_stylesheet_directory() . '/' . SAMSWISS_GATE_HERO_THEME;
	if ( file_exists( $theme_file ) ) {
		$url = get_stylesheet_directory_uri() . '/' . SAMSWISS_GATE_HERO_THEME;
		return $url;
	}

	$uploads    = wp_get_upload_dir();
	$basedir    = trailingslashit( $uploads['basedir'] );
	$candidates = array( SAMSWISS_GATE_HERO_LIGHT, SAMSWISS_GATE_HERO_MASTER, SAMSWISS_HERO_LIGHT, SAMSWISS_HERO_MASTER );

	$rel = SAMSWISS_HERO_MASTER;
	foreach ( $candidates as $candidate ) {
		if ( file_exists( $basedir . $candidate ) ) {
			$rel = $candidate;
			break;
		}
	}

	$url = trailingslashit( $uploads['baseurl'] ) . $rel;

	return $url;
}

/* The gateway hero, replaced July 2026 with the aerial shot of the Balerna works.
   Its own pair of constants rather than a rewrite of the ones below: those two are
   also used by samswiss_lighten_hero_in_content(), which swaps the old exterior
   photo inside the Chi Siamo page body — repointing them would have silently
   changed a page nobody asked me to touch.

   The uploaded master is a 2.79 MB PNG with no transparency. The gateway is the
   site's entry page, so it is served as a 596 KB JPEG twin (79% lighter, method
   recorded in cutover-and-rollback.md); the PNG stays in the library untouched.
   The list is ordered, so a missing derivative falls back rather than blanking. */
/* Shipped with the theme, so every install has it. Relative to the stylesheet dir. */
const SAMSWISS_GATE_HERO_THEME  = 'assets/img/sede-sam-aerea.jpg';
const SAMSWISS_GATE_HERO_LIGHT  = '2026/07/sede-sam-aerea-1672.jpg';
const SAMSWISS_GATE_HERO_MASTER = '2026/07/ChatGPT-Image-28-lug-2026-17_13_26.png';

const SAMSWISS_HERO_LIGHT  = '2020/05/Foto-Esterno-di-SAM-sw1600.jpg';
const SAMSWISS_HERO_MASTER = '2020/05/Foto-Esterno-di-SAM-scaled.jpg';

/**
 * Slug of the category every machine lives under.
 */
const SAMSWISS_MACHINE_CATEGORY = 'packaging-lines';

/**
 * Machine photographs for the INTRO gateway's rotation.
 *
 * The gateway used to show one fixed photograph of the works. This returns the
 * catalogue's own machine shots instead, read live from the machine posts, so the
 * entry page shows what SAM actually builds and needs no separate image library to
 * be kept in step.
 *
 * Same query the machine counts use — the `packaging-lines` tree with
 * `include_children` — so "a machine" means here exactly what it means everywhere
 * else on this site. Only posts that really carry a featured image qualify:
 * `_thumbnail_id EXISTS` filters in SQL rather than fetching rows and discarding
 * them, and the id is re-read per post because a meta row can outlive its
 * attachment.
 *
 * Ordered by date, NOT randomly, and that is deliberate: LiteSpeed caches this
 * page's HTML, so a random order would be drawn once and then frozen into the
 * cached copy — the appearance of variety with none of it. A stable order is at
 * least honest about being stable.
 *
 * The photographs are returned WITHOUT machine names. The featured images on this
 * install do not reliably match their posts (the machine titled "TMS" carries
 * `TMSML.png`, "TMS MOD" carries `WBOX.png` — the set looks shifted by one), so
 * captioning each frame with its post title would state something the data does not
 * support. The rotation is presentational; the cell keeps one honest label.
 *
 * Memoized per blog, per the admin-bar favicon incident: this runs on a front page
 * that plugins can render while switched to another site of the network.
 *
 * @param int $limit How many photographs at most.
 * @return array<int,int> Attachment IDs, in display order.
 */
function samswiss_gate_machine_slides( $limit = 6 ) {
	static $cache = array();

	$limit = max( 1, (int) $limit );
	$key   = get_current_blog_id() . ':' . $limit;
	if ( isset( $cache[ $key ] ) ) {
		return $cache[ $key ];
	}

	$slides = array();
	$term   = get_term_by( 'slug', SAMSWISS_MACHINE_CATEGORY, 'category' );

	if ( $term && ! is_wp_error( $term ) ) {
		$query = new WP_Query( array(
			'post_type'              => 'post',
			'post_status'            => 'publish',
			'posts_per_page'         => $limit,
			'ignore_sticky_posts'    => true,
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
			'tax_query'              => array(
				array(
					'taxonomy'         => 'category',
					'field'            => 'term_id',
					'terms'            => (int) $term->term_id,
					'include_children' => true,
				),
			),
			'meta_query'             => array(
				array(
					'key'     => '_thumbnail_id',
					'compare' => 'EXISTS',
				),
			),
		) );

		foreach ( $query->posts as $machine ) {
			$thumb = (int) get_post_thumbnail_id( $machine->ID );
			if ( $thumb && wp_get_attachment_image_url( $thumb, 'large' ) ) {
				$slides[] = $thumb;
			}
		}
	}

	$cache[ $key ] = $slides;

	return $slides;
}

/**
 * Keep the gateway's rotation frames genuinely alt-less.
 *
 * The parent theme's SEO module (`tw_seo_auto_alt_tags`) fills any empty `alt` with
 * the attachment title, which is right nearly everywhere and wrong here: these
 * frames are `aria-hidden` children of one `role="img"` cell that already carries
 * the description, and the titles they were given are attachment filenames —
 * "TMSML", "image", "SPM+QI". An empty alt is the correct markup for a decorative
 * image, and this restores it for these frames only, leaving the parent's rule in
 * force for every other image on the site.
 *
 * Priority 20, so it runs after the parent's filter at 10.
 *
 * @param array $attr Image attributes.
 * @return array
 */
function samswiss_keep_gate_slides_decorative( $attr ) {
	if ( isset( $attr['class'] ) && false !== strpos( $attr['class'], 'swiss-gate__slide' ) ) {
		$attr['alt'] = '';
	}

	return $attr;
}
add_filter( 'wp_get_attachment_image_attributes', 'samswiss_keep_gate_slides_decorative', 20 );

/**
 * How many machines SAM has in the catalogue, counted once each.
 *
 * Every machine lives under PACKAGING_LINES or one of its sector children, so
 * counting that tree with `include_children` gives each machine exactly once —
 * including the one that currently has no sector assigned.
 *
 * This is deliberately NOT the sum of the sector frames. 29 of the 55 machines
 * serve more than one sector (twelve of them serve six: the VG 500, FG 40,
 * Ypsilon, Gamma, Magic 2.0 and Lari are generalist thermosealers that close a
 * tray of gelato as readily as a tray of fish). Summing the frames counts those
 * machines once per sector and reports 146 — the number of machine/sector
 * pairings, not the number of machines. The frames themselves are right to list
 * a shared machine in every sector it serves; only the total has to be distinct.
 *
 * Counted in the DEFAULT language: the label answers "how many machines does SAM
 * build", and that answer does not shrink because fewer pages are translated.
 * found_posts on a one-row query returns the total without loading the rows.
 *
 * @param int $fallback Value to return if the category is missing.
 * @return int
 */
function samswiss_machine_total( $fallback = 0 ) {
	static $total = null;
	if ( null !== $total ) {
		return $total;
	}

	$current = apply_filters( 'wpml_current_language', null );
	$default = apply_filters( 'wpml_default_language', null );
	$switch  = ( $current && $default && $current !== $default );

	if ( $switch ) {
		do_action( 'wpml_switch_language', $default );
	}

	$term  = get_term_by( 'slug', SAMSWISS_MACHINE_CATEGORY, 'category' );
	$count = 0;

	if ( $term && ! is_wp_error( $term ) ) {
		$query = new WP_Query( array(
			'post_type'              => 'post',
			'post_status'            => 'publish',
			'posts_per_page'         => 1,
			'fields'                 => 'ids',
			'ignore_sticky_posts'    => true,
			'no_found_rows'          => false,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
			'tax_query'              => array(
				array(
					'taxonomy'         => 'category',
					'field'            => 'term_id',
					'terms'            => (int) $term->term_id,
					'include_children' => true,
				),
			),
		) );
		$count = (int) $query->found_posts;
	}

	// Always restore, or the rest of the page renders in the wrong language.
	if ( $switch ) {
		do_action( 'wpml_switch_language', $current );
	}

	$total = $count ? $count : (int) $fallback;

	return $total;
}

/**
 * How many MACHINES a category holds.
 *
 * Not `$term->count`, which is what the sector frames used to print. WordPress
 * stores that as the number of objects assigned to the term across every post
 * type, and these categories also carry `articolo-seo` posts — so the frames were
 * counting SEO articles as machines. Second Hand showed 2 with one machine in it;
 * Carne & Pesce showed 29 with 20. The inflation was between 0 and 9 per sector.
 *
 * Machines are the `post` type, so that is what gets counted. found_posts on a
 * one-row query returns the total without loading the rows, and the result is
 * memoized per term for the request.
 *
 * @param WP_Term|int|null $term Category term or ID.
 * @return int
 */
function samswiss_machine_count( $term ) {
	static $cache = array();

	$term_id = is_object( $term ) ? (int) $term->term_id : (int) $term;
	if ( ! $term_id ) {
		return 0;
	}
	if ( isset( $cache[ $term_id ] ) ) {
		return $cache[ $term_id ];
	}

	$query = new WP_Query( array(
		'post_type'              => 'post',
		'post_status'            => 'publish',
		'posts_per_page'         => 1,
		'fields'                 => 'ids',
		'ignore_sticky_posts'    => true,
		'no_found_rows'          => false,
		'update_post_meta_cache' => false,
		'update_post_term_cache' => false,
		'tax_query'              => array(
			array(
				'taxonomy'         => 'category',
				'field'            => 'term_id',
				'terms'            => $term_id,
				'include_children' => false,
			),
		),
	) );

	$cache[ $term_id ] = (int) $query->found_posts;

	return $cache[ $term_id ];
}


/**
 * Drop WPML's own footer language switcher.
 *
 * WPML renders a "statics / footer" slot on wp_footer for every page: a 91px
 * white strip of eight language names that no one designed, landing under the
 * theme's dark footer — and on the INTRO gateway, which has no footer at all, it
 * simply hangs below the screen. The theme already provides the switcher twice
 * (topbar and footer), plus the flags on the gateway, so this is a third copy and
 * eight extra tab stops on every page.
 *
 * Matched on the slot's own wrapper class rather than on WPML's internal slot API,
 * so a plugin update cannot quietly turn it back on. Widget and menu switchers are
 * untouched; only this footer slot is suppressed. To keep it on inner pages and
 * remove it from the gateway alone, wrap the return in `is_front_page()`.
 *
 * @param string $html Rendered switcher markup.
 * @return string
 */
function samswiss_remove_wpml_footer_switcher( $html ) {
	if ( is_string( $html ) && false !== strpos( $html, 'wpml-ls-statics-footer' ) ) {
		return '';
	}

	return $html;
}
add_filter( 'wpml_ls_html', 'samswiss_remove_wpml_footer_switcher' );

/**
 * Canonical URL of the page being rendered.
 *
 * Used by the forms that post to admin-post.php: they need to say where to come
 * back to, and where the submission came from, without JavaScript supplying it.
 * Built from WordPress's own routing rather than from REQUEST_URI so it stays a
 * URL on this site, and so it is already language-correct under WPML.
 *
 * @return string
 */
function samswiss_current_url() {
	if ( is_singular() || is_page() ) {
		$link = get_permalink();
		if ( $link ) {
			return $link;
		}
	}
	if ( is_tax() || is_category() || is_tag() ) {
		$link = get_term_link( get_queried_object() );
		if ( ! is_wp_error( $link ) ) {
			return $link;
		}
	}
	if ( function_exists( 'is_shop' ) && is_shop() ) {
		$link = get_permalink( (int) get_option( 'woocommerce_shop_page_id' ) );
		if ( $link ) {
			return $link;
		}
	}

	return home_url( '/' );
}

/**
 * Serve the light hero derivative where page content asks for the master.
 *
 * "Chi Siamo" embeds the 2560x1920 master directly in its post content, so the
 * templates alone cannot reach it: that one image was the whole 968 KB the page
 * downloaded. It is never displayed wider than the content column, which makes
 * the 1600px pass indistinguishable. Rewritten on output rather than in the
 * database, so the editor keeps referring to the original media item.
 *
 * @param string $html Post content.
 * @return string
 */
function samswiss_lighten_hero_in_content( $html ) {
	if ( ! is_string( $html ) || false === strpos( $html, 'Foto-Esterno-di-SAM' ) ) {
		return $html;
	}

	$uploads = wp_get_upload_dir();
	$basedir = trailingslashit( $uploads['basedir'] );

	// Preferred: the aerial shot the INTRO gateway now uses, so Chi Siamo shows the
	// same current photograph of the works — the one in the page body still carries
	// the old signage. The substitution happens at render time on purpose: the file
	// name is written into the page body once in Italian and four times in each of
	// the seven translations, and rewriting eight post bodies to change a picture is
	// not a job for a theme. See docs/release-note.md: the durable fix is to swap the
	// image in the editor, after which this branch simply stops matching.
	$replacement = samswiss_hero_bg_url();
	if ( '' !== $replacement ) {
		$html = preg_replace(
			'#(?:https?://[^"\']*)?/uploads/(?:sites/\d+/)?2020/05/Foto-Esterno-di-SAM[^"\']*\.jpg#',
			$replacement,
			$html
		);

		// The content marks it decorative with an empty alt, which is wrong for a
		// photograph of the company's own premises: it carries information.
		$alt  = esc_attr__( 'La sede S.A.M. SA a Balerna vista dall\'alto', 'samswiss-child' );
		$html = str_replace(
			array( $replacement . '" alt=""', $replacement . "' alt=''" ),
			array( $replacement . '" alt="' . $alt . '"', $replacement . "' alt='" . $alt . "'" ),
			$html
		);

		return $html;
	}

	// Fallback, unchanged: serve the light twin of the original rather than the
	// 968 KB master.
	if ( ! file_exists( $basedir . SAMSWISS_HERO_LIGHT ) ) {
		return $html;
	}

	return str_replace( 'Foto-Esterno-di-SAM-scaled.jpg', basename( SAMSWISS_HERO_LIGHT ), $html );
}
add_filter( 'the_content', 'samswiss_lighten_hero_in_content', 21 );

/**
 * Repair upload URLs left pointing at the wrong host by the migration.
 *
 * All-in-One WP Migration wrote a large number of absolute upload URLs on a
 * host that no longer answers (they 404), and they survive in post content and
 * in attachment GUIDs, which is where srcset candidates come from. Rather than
 * rewriting thousands of database rows, this repairs them on output.
 *
 * It is host-agnostic on purpose: any absolute URL that points at this site's
 * uploads PATH but carries a different host is rewritten to the current uploads
 * base, so the same code keeps working when the site moves to production.
 *
 * @param string $html Markup possibly containing stale absolute upload URLs.
 * @return string
 */
function samswiss_fix_upload_host( $html ) {
	if ( ! is_string( $html ) || '' === $html || false === strpos( $html, '//' ) ) {
		return $html;
	}

	// Cached PER BLOG, and that qualifier is the whole point. This is a multisite,
	// and the Multisite Enhancements plugin draws every network site's favicon in the
	// admin bar: to do it, it switch_to_blog()s through the entire network during
	// wp_head. This filter runs inside those switches, so a plain `static $base`
	// froze on whichever blog happened to be current at the first call — measured:
	// blog 4, an unrelated site — and every product image for the rest of the request
	// was rewritten to /uploads/sites/4/, which 404s. Only logged-in visitors have an
	// admin bar, which is why anonymous requests looked perfectly healthy.
	static $bases = array();
	$blog = get_current_blog_id();
	if ( ! isset( $bases[ $blog ] ) ) {
		$bases[ $blog ] = untrailingslashit( wp_get_upload_dir()['baseurl'] );
	}
	$base = $bases[ $blog ];
	if ( ! $base ) {
		return $html;
	}

	// Host AND path. The first version matched only URLs carrying this install's
	// exact uploads path, which is fine while the path never changes — but this site
	// is blog 17 of a multisite, so its path contains `/sites/17/`. Moved to a single
	// install, or to a different blog id, none of the stored URLs would match and
	// every migrated image would stay broken. So: take everything after the last
	// `/uploads/`, drop a `sites/<n>/` segment if the old install had one, and hang
	// the remainder off whatever this install's uploads base happens to be.
	return preg_replace_callback(
		'#https?://[^/"\'\s]+/[^"\'\s]*?/uploads/(?:sites/\d+/)?([^"\'\s)]+)#i',
		function ( $m ) use ( $base ) {
			return $base . '/' . ltrim( $m[1], '/' );
		},
		$html
	);
}
add_filter( 'the_content', 'samswiss_fix_upload_host', 20 );
add_filter( 'widget_text', 'samswiss_fix_upload_host', 20 );
add_filter( 'the_excerpt', 'samswiss_fix_upload_host', 20 );
// WooCommerce renders the product short description through its own filter, not
// the_content: without this, product pages keep shipping 404 images.
add_filter( 'woocommerce_short_description', 'samswiss_fix_upload_host', 20 );
// Featured images are built from a relative path and are normally safe, but a
// migrated install can carry absolute URLs in the attachment's own markup; and
// block content bypasses the_content on some surfaces.
add_filter( 'post_thumbnail_html', 'samswiss_fix_upload_host', 20 );
add_filter( 'render_block', 'samswiss_fix_upload_host', 20 );

/**
 * Same repair for the srcset candidates, which WordPress builds from the
 * attachment GUID and therefore inherits the stale host.
 *
 * @param array $sources Srcset sources keyed by width.
 * @return array
 */
function samswiss_fix_srcset_host( $sources ) {
	if ( ! is_array( $sources ) ) {
		return $sources;
	}
	foreach ( $sources as $width => $source ) {
		if ( isset( $source['url'] ) ) {
			$sources[ $width ]['url'] = samswiss_fix_upload_host( $source['url'] );
		}
	}
	return $sources;
}
add_filter( 'wp_calculate_image_srcset', 'samswiss_fix_srcset_host', 20 );
add_filter( 'wp_get_attachment_url', 'samswiss_fix_upload_host', 20 );

/**
 * Nav walker that adds a caret to items with children (for the dropdown menus).
 */
class Samswiss_Walker_Nav_Menu extends Walker_Nav_Menu {
	public function start_lvl( &$output, $depth = 0, $args = null ) {
		$output .= '<ul class="samswiss-sub-menu">';
	}

	public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
		$classes   = empty( $item->classes ) ? array() : (array) $item->classes;
		$has_child = in_array( 'menu-item-has-children', $classes, true );
		$class_str = trim( implode( ' ', array_map( 'sanitize_html_class', $classes ) ) );

		$output .= '<li class="' . esc_attr( $class_str ) . '">';
		$atts    = ' href="' . esc_attr( $item->url ) . '"';
		if ( ! empty( $item->target ) ) {
			$atts .= ' target="' . esc_attr( $item->target ) . '"';
		}
		$title   = apply_filters( 'the_title', $item->title, $item->ID );
		$output .= '<a' . $atts . '>' . esc_html( $title );
		if ( $has_child && 0 === $depth ) {
			$output .= ' <i class="fas fa-chevron-down samswiss-menu-caret" aria-hidden="true"></i>';
		}
		$output .= '</a>';
	}
}

/**
 * Keep title-less posts out of the listings.
 *
 * The migration left five published posts with no title, no featured image and
 * no category: they hold one SEO article's Romanian, Hungarian, German, French
 * and Slovak translations, but WPML records each as an Italian original with its
 * own trid. So the Italian archives list them, and an Italian visitor met a card
 * with a blank heading and an excerpt in Romanian — while a Romanian visitor,
 * the only one who could read them, never saw them at all.
 *
 * A card can never render correctly without a title, whatever the cause, so the
 * listings skip those posts. This is a guard, not the repair: the posts stay
 * published and reachable by URL, and the content fix (assign the right language
 * and write the titles, or bin them) is recorded in docs/release-note.md.
 *
 * Scoped to front-end listing queries. Singular views are untouched, so a direct
 * link still resolves and nothing silently disappears from the admin.
 *
 * @param string   $where SQL WHERE clause.
 * @param WP_Query $query The query being filtered.
 * @return string
 */
function samswiss_hide_untitled_posts( $where, $query ) {
	global $wpdb;

	// Admin must keep seeing them: that is where they get fixed or binned.
	if ( is_admin() ) {
		return $where;
	}

	// A direct link still resolves; only listings skip them.
	if ( $query->is_singular() ) {
		return $where;
	}

	// Applies to any front-end listing of posts, main query or secondary loop
	// (InfoNews and Second Hand run their own WP_Query).
	$types = $query->get( 'post_type' );
	$types = $types ? (array) $types : array( 'post' );
	if ( ! in_array( 'post', $types, true ) && ! in_array( 'any', $types, true ) ) {
		return $where;
	}

	return $where . " AND TRIM({$wpdb->posts}.post_title) <> '' ";
}
add_filter( 'posts_where', 'samswiss_hide_untitled_posts', 10, 2 );

/**
 * Serve the card-brand marks from the theme instead of the generated upload.
 *
 * The Stripe gateway writes `stripe-card-icons.svg` into uploads and links it
 * with a hash query. The file is valid and returns 200 — verified from the
 * server and rendered in a clean browser — but it came back broken in the
 * client's browser twice, so the checkout depends on an asset we cannot verify
 * from here. A copy in the theme is the same picture from a path we control.
 *
 * Only the card gateway is touched; Klarna, Twint and Apple Pay keep the
 * gateway's own marks, which have never failed.
 */
function samswiss_card_icon( $icon, $gateway_id ) {
	if ( 'stripe_cc' !== $gateway_id ) {
		return $icon;
	}

	$src = get_stylesheet_directory_uri() . '/assets/img/card-marks.svg';

	return sprintf(
		'<img src="%s" alt="%s" width="155" height="22" />',
		esc_url( $src ),
		esc_attr__( 'Visa, Mastercard, American Express, Discover', 'samswiss' )
	);
}
add_filter( 'woocommerce_gateway_icon', 'samswiss_card_icon', 10, 2 );

/**
 * Repair menu items whose object no longer exists on this install.
 *
 * A nav menu item of type `taxonomy` stores a term ID, and a `post_type` item
 * stores a post ID. Those IDs belong to the database the menu was built in. Move
 * the site — or re-import the catalogue — and the row can point at a term that is
 * not there any more: WordPress then prints a link that resolves to nothing, the
 * request 404s, and this install's parent theme answers a 404 with a 301 to the
 * home page, which here is the INTRO gateway. That is exactly the reported
 * "Imballaggi e monouso and Ingredienti send me back to Intro".
 *
 * The repair is conservative. It only acts when the referenced object is missing,
 * and it only trusts two things that travel with an export: the slug already
 * present in the stored URL, and the item's own title. When neither resolves, the
 * item is left untouched rather than pointed somewhere invented.
 *
 * @param array $items Menu items.
 * @return array
 */
function samswiss_repair_menu_items( $items ) {
	if ( empty( $items ) || ! is_array( $items ) ) {
		return $items;
	}

	foreach ( $items as $item ) {
		if ( empty( $item->type ) ) {
			continue;
		}

		if ( 'taxonomy' === $item->type ) {
			$taxonomy = $item->object;
			$term     = get_term( (int) $item->object_id, $taxonomy );
			if ( $term && ! is_wp_error( $term ) ) {
				continue; // Nothing to repair.
			}

			// A menu item whose term is gone is flagged _invalid by
			// wp_setup_nav_menu_item() and then dropped by the walker, so repairing
			// the URL is not enough: the flag has to come off too. Note that such an
			// item keeps nothing of the term — no URL, no title — unless the editor
			// gave it a label of its own, which is the only case that can be resolved.
			$found = samswiss_find_term_like( $item->url, $item->post_title, $taxonomy );
			if ( $found ) {
				$link = get_term_link( $found );
				if ( ! is_wp_error( $link ) ) {
					$item->url       = $link;
					$item->object_id = $found->term_id;
					$item->title     = $item->title ? $item->title : $found->name;
					$item->_invalid  = false;
				}
			}
			continue;
		}

		if ( 'post_type' === $item->type ) {
			$post = get_post( (int) $item->object_id );
			if ( $post && 'publish' === $post->post_status ) {
				continue;
			}

			$slug = samswiss_slug_from_url( $item->url );
			$page = $slug ? get_page_by_path( $slug ) : null;
			if ( ! $page instanceof WP_Post ) {
				$by_title = get_page_by_title( $item->title );
				$page     = $by_title instanceof WP_Post ? $by_title : null;
			}
			if ( $page instanceof WP_Post ) {
				$link = get_permalink( $page );
				if ( $link ) {
					$item->url       = $link;
					$item->object_id = $page->ID;
				}
			}
		}
	}

	return $items;
}
add_filter( 'wp_get_nav_menu_items', 'samswiss_repair_menu_items', 20 );

/**
 * Find a term from the slug inside a stored URL, then from a title.
 *
 * @param string $url      Stored menu URL.
 * @param string $title    Menu item title.
 * @param string $taxonomy Taxonomy name.
 * @return WP_Term|null
 */
function samswiss_find_term_like( $url, $title, $taxonomy ) {
	if ( ! taxonomy_exists( $taxonomy ) ) {
		return null;
	}

	$slug = samswiss_slug_from_url( $url );
	if ( $slug ) {
		$term = get_term_by( 'slug', $slug, $taxonomy );
		if ( $term && ! is_wp_error( $term ) ) {
			return $term;
		}
	}

	if ( $title ) {
		$term = get_term_by( 'name', $title, $taxonomy );
		if ( $term && ! is_wp_error( $term ) ) {
			return $term;
		}
	}

	return null;
}

/**
 * The last path segment of a URL, which for a term archive is its slug.
 *
 * @param string $url URL.
 * @return string
 */
function samswiss_slug_from_url( $url ) {
	$path = wp_parse_url( (string) $url, PHP_URL_PATH );
	if ( ! $path ) {
		return '';
	}
	$parts = array_values( array_filter( explode( '/', $path ) ) );

	return $parts ? sanitize_title( end( $parts ) ) : '';
}

/**
 * Flush the rewrite rules once, after the theme is installed or updated.
 *
 * A child theme that ships templates for taxonomies and endpoints changes nothing
 * about the rules WordPress has already cached in the database — and those rules
 * are per-install. Deploy the theme onto a server whose rules were built before
 * WooCommerce's product_cat base existed (or before the permalink structure was
 * last saved) and every category archive answers 404. This install's parent theme
 * turns a 404 into a 301 to the home page, which is the INTRO gateway: exactly the
 * "Imballaggi e monouso and Ingredienti send me to Intro" report.
 *
 * Until now the only cure was for someone to remember to open Settings → Permalinks
 * and press Save on every deploy. This does it for them, once per version, on the
 * first request after the files change — flush_rewrite_rules() is expensive, so it
 * must never run on every load.
 */
function samswiss_flush_rules_on_version_change() {
	if ( wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
		return;
	}

	$theme   = wp_get_theme();
	$version = (string) $theme->get( 'Version' );
	$stored  = get_option( 'samswiss_rewrite_version' );

	if ( $stored === $version ) {
		return;
	}

	// A version change resets the attempt budget: a new deploy deserves a fresh
	// chance to build its rules, and samswiss_ensure_rewrite_rules() checks the
	// outcome on the next request rather than trusting this one.
	delete_option( 'samswiss_rewrite_attempts' );
	update_option( 'samswiss_rewrite_pending', 1, false );
	update_option( 'samswiss_rewrite_version', $version, false );
}
add_action( 'wp_loaded', 'samswiss_flush_rules_on_version_change', 99 );

/**
 * Also flush when the theme is switched on, which is the other moment the rules
 * can be older than the templates.
 */
function samswiss_flush_rules_on_activation() {
	delete_option( 'samswiss_rewrite_version' );
	flush_rewrite_rules( false );
}
add_action( 'after_switch_theme', 'samswiss_flush_rules_on_activation' );

/**
 * A partner mark, served from the THEME when it ships with it.
 *
 * **Why this exists.** The four marks the client sent in August 2026 — GB Bernucci,
 * Bulltec, RGD Mape, RS Bilance — were first put in the media library, and on the
 * live site they came out as broken images with the alt text showing. The reason is
 * the one already recorded at point 16 of the release note and it is worth stating
 * plainly: `wp-content/uploads` does NOT travel with a theme. A file added to the
 * library on a laptop exists on that laptop. The live install has its own library,
 * its own blog id, and no idea those files were ever created.
 *
 * The theme's own directory does travel, which is why the gateway photograph was
 * moved into `assets/img/` for exactly this reason (see SAMSWISS_GATE_HERO_THEME).
 * These four marks are 104 KB in total, so shipping them costs nothing and removes a
 * deployment step that has already been forgotten once.
 *
 * Falls back to the media library when no theme file is given, so the marks that came
 * with the migration — Sorma, the two Fabbri, BRAS — keep being served exactly as
 * before, from the library where they already exist on both installs.
 *
 * @param array $partner Partner row: `img` (uploads-relative), optional `theme`
 *                       (stylesheet-relative), `name`.
 * @return string Image markup.
 */
/**
 * An image that SHIPS WITH THE THEME, falling back to the media library.
 *
 * **Why this exists.** `wp-content/uploads` does not travel with a theme. A file added
 * to the library on this machine exists on this machine: the live install has its own
 * library, its own blog id, and no idea the file was ever created. It has already bitten
 * this project twice — the JPEG twins of point 16 and the partner marks of point 30b —
 * and it bites hardest at deploy time, because the theme lands correctly and the page
 * still comes out with broken images.
 *
 * Anything the design depends on therefore lives in `assets/img/` and travels in the
 * zip. The uploads path stays as a fallback, so an install that does have the file in
 * its library keeps using the library copy, with its generated sizes.
 *
 * @param string $theme_rel   Stylesheet-relative path, or '' to force the library.
 * @param string $uploads_rel Uploads-relative fallback path.
 * @param string $alt         Alternative text.
 * @param string $class       CSS class.
 * @param string $loading     'lazy' or 'eager'.
 * @return string Image markup.
 */
function samswiss_shipped_image( $theme_rel, $uploads_rel, $alt = '', $class = '', $loading = 'lazy' ) {
	if ( $theme_rel ) {
		$rel  = ltrim( $theme_rel, '/' );
		$file = get_stylesheet_directory() . '/' . $rel;

		if ( file_exists( $file ) ) {
			$size = @getimagesize( $file );

			return sprintf(
				'<img src="%s"%s alt="%s" class="%s" loading="%s" decoding="async">',
				esc_url( get_stylesheet_directory_uri() . '/' . $rel ),
				$size ? ' width="' . (int) $size[0] . '" height="' . (int) $size[1] . '"' : '',
				esc_attr( $alt ),
				esc_attr( $class ),
				esc_attr( $loading )
			);
		}
	}

	return samswiss_uploads_image( $uploads_rel, 'large', $class, $alt, $loading );
}

function samswiss_partner_image( $partner ) {
	return samswiss_shipped_image(
		isset( $partner['theme'] ) ? $partner['theme'] : '',
		$partner['img'],
		isset( $partner['name'] ) ? $partner['name'] : ''
	);
}
