<?php
/**
 * Gelateria machines front-end filter (Quark & Mantecatore lines).
 *
 * Hides the Quark and Mantecatore machine lines from all public front-end
 * queries (category archives, search, feeds, related posts) and restricts
 * direct single post access to administrators/editors.
 *
 * All posts, attachments, taxonomies, and metadata remain 100% intact in the
 * WordPress database and admin dashboard (wp-admin) for export to the new
 * gelateria website.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Returns all post IDs belonging to the Quark and Mantecatore lines across all
 * WPML active languages and taxonomies.
 *
 * @return array List of integer post IDs.
 */
function samswiss_get_gelateria_excluded_post_ids() {
	static $cached_ids = null;
	if ( null !== $cached_ids ) {
		return $cached_ids;
	}

	global $wpdb;

	// Core Italian post IDs for Quark, Mantecatori, Ginseng, Granite, Creme fredde
	$base_ids = array(
		5267,   // Easy 3 / Mantecatore Elettromeccanico
		5767,   // Quark 1 / Creme fredde
		15556,  // B-Cube 1 / Granite, Creme fredde, Sorbetti
		15806,  // B-Cube 2 / Granite, Creme fredde, Sorbetti
		15939,  // B-Cube 3 / Granite, Creme fredde, Sorbetti
		16056,  // Frozen 6.2 / Granite, Creme fredde, Sorbetti, Yogurt
		16132,  // B-Express / Ginseng, Orzo
		16197,  // Quark 2 / Creme fredde
		16263,  // Quark 3 / Creme fredde
		16507,  // Easy 4 / Mantecatore Elettromeccanico
		16533,  // Easy 5 / Mantecatore Elettromeccanico
		26273,  // Mantecatore Elettromeccanico (draft)
		26276,  // Linea Quark: Distributori Professionali (draft)
		26282,  // Quark 3: distributore professionale compatto (future)
	);

	$in_base = implode( ',', array_map( 'intval', $base_ids ) );

	// 1. Resolve all WPML multilingual translations for these posts
	$wpml_ids   = array();
	$wpml_table = $wpdb->prefix . 'icl_translations';
	// Check if table exists without throwing errors
	if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpml_table ) ) === $wpml_table ) {
		$wpml_ids = $wpdb->get_col(
			"SELECT element_id FROM {$wpml_table} WHERE trid IN (SELECT trid FROM {$wpml_table} WHERE element_id IN ({$in_base}))"
		);
	}

	// 2. Also match by title/slug pattern in wp_posts for gelateria, cold creams, granite, sorbetti, and ingredients
	$pattern_ids = $wpdb->get_col(
		"SELECT ID FROM {$wpdb->posts} WHERE (
			post_title LIKE '%quark%' OR post_title LIKE '%mantecat%' OR
			post_title LIKE '%ginseng%' OR post_title LIKE '%b-cube%' OR
			post_title LIKE '%frozen%' OR post_title LIKE '%creme fredde%' OR
			post_title LIKE '%cold creams%' OR post_title LIKE '%granite%' OR
			post_title LIKE '%sorbetti%' OR post_title LIKE '%b-express%' OR
			post_title LIKE '%b-würfel%' OR post_title LIKE '%gelat%' OR
			post_title LIKE '%ingredient%' OR post_title LIKE '%coppetta%' OR
			post_title LIKE '%paletta%' OR post_title LIKE '%monouso%' OR
			post_name LIKE '%quark%' OR post_name LIKE '%mantecat%' OR
			post_name LIKE '%ginseng%' OR post_name LIKE '%b-cube%' OR
			post_name LIKE '%frozen%' OR post_name LIKE '%b-express%' OR
			post_name LIKE '%gelat%' OR post_name LIKE '%ingredient%' OR
			post_name LIKE '%sorbett%' OR post_name LIKE '%granit%' OR
			post_name LIKE '%monouso%'
		) AND post_type NOT IN ('attachment', 'revision')"
	);

	$all_ids = array_unique( array_map( 'intval', array_merge( $base_ids, (array) $wpml_ids, (array) $pattern_ids ) ) );
	$cached_ids = array_values( array_filter( $all_ids ) );

	return $cached_ids;
}

/**
 * Excludes gelateria machine and ingredient posts from all public front-end queries.
 *
 * @param WP_Query $query The current query instance.
 */
function samswiss_exclude_gelateria_from_frontend_queries( $query ) {
	if ( is_admin() ) {
		return;
	}

	// Allow singular queries so template_redirect can gracefully 301-redirect public visitors
	if ( $query->is_main_query() && $query->is_singular() ) {
		return;
	}

	// Allow programmatic suppression if an internal helper explicitly requests all posts
	if ( $query->get( 'suppress_filters' ) || $query->get( 'samswiss_allow_gelateria' ) ) {
		return;
	}

	$excluded = samswiss_get_gelateria_excluded_post_ids();
	if ( empty( $excluded ) ) {
		return;
	}

	$post__not_in = (array) $query->get( 'post__not_in' );
	$query->set( 'post__not_in', array_unique( array_merge( $post__not_in, $excluded ) ) );
}
add_action( 'pre_get_posts', 'samswiss_exclude_gelateria_from_frontend_queries' );

/**
 * Guards direct access to single gelateria/ingredient URLs and old landing pages on the front end.
 *
 * Redirects non-logged-in public visitors to appropriate industrial packaging pages, while
 * allowing logged-in editors and administrators to view and verify the content in wp-admin.
 */
function samswiss_guard_gelateria_single_access() {
	if ( is_admin() || current_user_can( 'edit_posts' ) ) {
		return;
	}

	$req_uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '';
	if ( strpos( $req_uri, 'sam-sa-ingredients-packaging' ) !== false ) {
		wp_safe_redirect( home_url( '/imballaggi-e-consumabili/' ), 301 );
		exit;
	}

	if ( is_singular() ) {
		$post_id  = get_queried_object_id();
		$excluded = samswiss_get_gelateria_excluded_post_ids();

		// Old "Imballaggi e Monouso / Ingredienti" page redirect to new Imballaggi e Consumabili
		$old_landing_ids = array( 215, 10088, 10167, 10173 );
		if ( in_array( (int) $post_id, $old_landing_ids, true ) || is_page( 'sam-sa-ingredients-packaging' ) ) {
			wp_safe_redirect( home_url( '/imballaggi-e-consumabili/' ), 301 );
			exit;
		}

		if ( in_array( (int) $post_id, $excluded, true ) ) {
			// Redirect packaging/ingredient items to consumables, machine items to packaging machines
			$post = get_post( $post_id );
			$slug = $post ? $post->post_name : '';
			if ( strpos( $slug, 'ingredient' ) !== false || strpos( $slug, 'monouso' ) !== false || strpos( $slug, 'coppetta' ) !== false || strpos( $slug, 'paletta' ) !== false ) {
				wp_safe_redirect( home_url( '/imballaggi-e-consumabili/' ), 301 );
			} else {
				wp_safe_redirect( home_url( '/macchine-confezionatrici/' ), 301 );
			}
			exit;
		}
	}
}
add_action( 'template_redirect', 'samswiss_guard_gelateria_single_access', 1 );
