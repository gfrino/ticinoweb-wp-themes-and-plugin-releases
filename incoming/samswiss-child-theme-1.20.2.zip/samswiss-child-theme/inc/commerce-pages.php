<?php
/**
 * Guarantee that the commerce pages actually render commerce.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The shortcode each commerce surface must produce, keyed by nothing: resolved from
 * WooCommerce's own conditionals so a renamed page or a different page id on another
 * install changes nothing here.
 *
 * @return string Shortcode tag, or '' when this is not a surface we own.
 */
function samswiss_required_commerce_shortcode() {
	if ( ! function_exists( 'WC' ) || ! function_exists( 'is_cart' ) ) {
		return '';
	}

	if ( is_cart() ) {
		return 'woocommerce_cart';
	}

	// Endpoints included, deliberately. "Order received" and "pay for order" are
	// endpoints OF the checkout page, and it is `[woocommerce_checkout]` itself that
	// routes them: WC_Shortcode_Checkout::output() renders thankyou.php on
	// order-received and form-pay.php on order-pay. The first version excluded them,
	// reasoning that they "render themselves" — true only on a page that carries the
	// shortcode. On this live install the page carries a pasted snapshot instead, so
	// nothing detected the endpoint and a paying customer landed on a second copy of
	// the checkout form, prefilled with somebody else's name, followed by WordPress's
	// sample-page text. Handing the endpoint to the shortcode is what produces the
	// confirmation.
	if ( is_checkout() ) {
		return 'woocommerce_checkout';
	}

	return '';
}

/**
 * Render the real cart or checkout when the page body no longer does.
 *
 * **What was wrong.** On the live install the "Carrello" page (#903) does not contain
 * `[woocommerce_cart]`. Its body holds a pasted, class-stripped snapshot of a cart:
 * `<table cellspacing="0">` with no classes at all, `<th>Rimuovi articolo</th>` instead
 * of `<th class="product-remove">`, HTML comments — `<!--open column-1-->`,
 * `<!--open cart-totals-->` — where the wrapper divs used to be, and a
 * `_wp_http_referer` of `/wp-admin/admin-ajax.php`, which is where the snapshot was
 * captured from. The give-away is arithmetic: the header showed an empty cart while the
 * page listed two articles, because those articles are text.
 *
 * That is why the page looked unstyled. Nothing failed to load — every stylesheet is
 * byte-identical to the local one and answers 200 — but the design hangs off
 * WooCommerce's real classes (`woocommerce-cart-form`, `shop_table`, `product-remove`,
 * `.remove`), and a snapshot with the classes stripped out offers nothing to style.
 * No stylesheet can repair that, and no amount of extra CSS should try: the page also
 * cannot add to cart, update quantities or reach checkout, because none of it is real.
 *
 * **What this does.** A cart page renders the cart; a checkout page renders the
 * checkout. If the body already does so — shortcode or block — it is left completely
 * alone, which is the case locally. Otherwise the body is replaced by the genuine
 * output. The page content is never written to: the repair happens at render time, so
 * fixing the content in WordPress simply makes this stop finding anything to do.
 *
 * Priority 20 so it runs after wpautop: the same wpautop that turned the pasted
 * snapshot into `<p><!--open container--><br />` is not given the chance to do it
 * again to the real markup.
 *
 * @param string $content Post content.
 * @return string
 */
function samswiss_ensure_commerce_page_content( $content ) {
	if ( is_admin() || ! is_singular() || ! in_the_loop() || ! is_main_query() ) {
		return $content;
	}

	$tag = samswiss_required_commerce_shortcode();
	if ( '' === $tag ) {
		return $content;
	}

	// The RAW body, deliberately. By priority 20 core has already expanded shortcodes
	// (priority 11), so has_shortcode() on the filtered string would report "absent"
	// for every page, including the healthy ones.
	$raw = (string) get_post_field( 'post_content', get_the_ID() );

	$block = 'woocommerce_cart' === $tag ? 'woocommerce/cart' : 'woocommerce/checkout';
	if ( has_shortcode( $raw, $tag ) || has_block( $block, $raw ) ) {
		return $content;
	}

	if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		error_log( sprintf(
			'samswiss: la pagina %d non contiene [%s]; il tema rende il contenuto reale al suo posto.',
			(int) get_the_ID(),
			$tag
		) );
	}

	return do_shortcode( '[' . $tag . ']' );
}
add_filter( 'the_content', 'samswiss_ensure_commerce_page_content', 20 );
