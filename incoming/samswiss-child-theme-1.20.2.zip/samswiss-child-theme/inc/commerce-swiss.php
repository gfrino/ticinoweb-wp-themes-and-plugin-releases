<?php
/**
 * Shop archive and checkout: the two commerce surfaces of the Swiss world.
 *
 * Everything here is additive and hook-based. No WooCommerce template is
 * overridden and no field, label or calculation is touched — the surfaces are
 * composed by CSS, and this file only supplies the two pieces of structure that
 * CSS cannot invent: a wrapper around the shop toolbar, and the article code
 * that turns a product card into a catalogue entry.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Open the shop toolbar.
 *
 * `woocommerce_before_shop_loop` prints the notices (10), the result count (20)
 * and the ordering form (30) as three loose siblings. Wrapping the count and the
 * form makes them one control bar instead of two stray lines, which is what lets
 * the bar carry a ground and a rule of its own. Priority 15 puts the opening tag
 * after the notices, so a "added to cart" message stays above the bar rather
 * than inside it.
 */
function samswiss_shop_toolbar_open() {
	echo '<div class="samswiss-shop-toolbar">';
}
add_action( 'woocommerce_before_shop_loop', 'samswiss_shop_toolbar_open', 15 );

/**
 * Close the shop toolbar.
 */
function samswiss_shop_toolbar_close() {
	echo '</div>';
}
add_action( 'woocommerce_before_shop_loop', 'samswiss_shop_toolbar_close', 35 );

/**
 * Print the article code above a product card's name.
 *
 * The single-product page already leads with "Codice Articolo": on this catalogue
 * the code is how a buyer reorders, so the card carries it too. It is read from
 * the product's SKU — real data, never invented — and cards without one simply
 * omit the line.
 */
function samswiss_loop_article_code() {
	global $product;

	if ( ! $product instanceof WC_Product ) {
		return;
	}

	$sku = $product->get_sku();
	if ( '' === $sku ) {
		return;
	}

	printf(
		'<span class="samswiss-card-code">%s</span>',
		esc_html( $sku )
	);
}
add_action( 'woocommerce_shop_loop_item_title', 'samswiss_loop_article_code', 5 );

/**
 * Give the order-notes section a heading of its own.
 *
 * WooCommerce prints `<h3>` for billing and for shipping, but the additional
 * fields block ships without one on this install — so the notes arrived as a
 * loose field under two numbered sections, and the document lost its third step.
 * The heading is a heading only: the field, its name and its optional status are
 * untouched.
 */
function samswiss_order_notes_heading() {
	printf(
		'<h3>%s</h3>',
		esc_html__( 'Note sull\'ordine', 'samswiss-child' )
	);
}
add_action( 'woocommerce_before_order_notes', 'samswiss_order_notes_heading', 5 );

/**
 * Wrap the order summary and its heading in one panel.
 *
 * The checkout is laid out as two columns. With the heading and the review table
 * as separate grid children, the left column — which spans both rows — inflated
 * them, and the summary rendered 250px below its own title (measured). One
 * container makes the panel a single grid item, and lets it stay in view while
 * the form is filled.
 */
function samswiss_order_panel_open() {
	echo '<div class="samswiss-order-panel">';
}
add_action( 'woocommerce_checkout_before_order_review_heading', 'samswiss_order_panel_open', 5 );

/**
 * Close the order panel.
 */
function samswiss_order_panel_close() {
	echo '</div>';
}
add_action( 'woocommerce_checkout_after_order_review', 'samswiss_order_panel_close', 99 );

/**
 * The catalogue's own figures, on an ink field.
 *
 * The inversion band added July 2026: the shop was one uninterrupted paper sheet
 * between a red masthead and a black footer, and read as neutral because nothing
 * on it changed value. Ink is already a field in this world (the caption tag, the
 * submit button), so the beat costs no new colour.
 *
 * Both numbers are read live — the archive's own total from the WooCommerce loop,
 * and the categories that actually hold products in the current scope. Nothing is
 * hand-written and nothing is rounded.
 */
function samswiss_shop_data_band() {
	$total = (int) wc_get_loop_prop( 'total' );
	if ( $total < 1 ) {
		return;
	}

	$term = is_product_taxonomy() ? get_queried_object() : null;

	if ( $term instanceof WP_Term ) {
		$children    = get_terms( array(
			'taxonomy'   => $term->taxonomy,
			'parent'     => $term->term_id,
			'hide_empty' => true,
			'fields'     => 'ids',
		) );
		$cat_count   = is_wp_error( $children ) ? 0 : count( $children );
		$total_label = _n( 'Articolo in questa categoria', 'Articoli in questa categoria', $total, 'samswiss-child' );
		$cat_label   = _n( 'Sottocategoria', 'Sottocategorie', $cat_count, 'samswiss-child' );
	} else {
		$terms       = get_terms( array(
			'taxonomy'   => 'product_cat',
			'hide_empty' => true,
			'fields'     => 'ids',
		) );
		$cat_count   = is_wp_error( $terms ) ? 0 : count( $terms );
		$total_label = _n( 'Articolo in catalogo', 'Articoli in catalogo', $total, 'samswiss-child' );
		$cat_label   = _n( 'Categoria', 'Categorie', $cat_count, 'samswiss-child' );
	}

	$cells = array( array( $total, $total_label ) );

	if ( $cat_count > 0 ) {
		$cells[] = array( $cat_count, $cat_label );
	} elseif ( $term instanceof WP_Term ) {
		// A leaf category has no second figure of its own, and one cell left half
		// the ink field empty. The catalogue total is the context a buyer actually
		// wants there: how much else there is to look at.
		$catalogue = samswiss_catalogue_total();
		if ( $catalogue > $total ) {
			$cells[] = array( $catalogue, _n( 'Articolo in tutto il catalogo', 'Articoli in tutto il catalogo', $catalogue, 'samswiss-child' ) );
		}
	}
	?>
	<div class="samswiss-band samswiss-band--ink samswiss-band--figures samswiss-shop-figures">
		<div class="samswiss-band__inner">
			<?php foreach ( $cells as $cell ) : ?>
				<div class="samswiss-band__cell">
					<span class="samswiss-band__value"><?php echo esc_html( number_format_i18n( $cell[0] ) ); ?></span>
					<span class="samswiss-band__key"><?php echo esc_html( $cell[1] ); ?></span>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
	<?php
}

/**
 * The closing band: the shop's exit toward a quote.
 *
 * PRODUCT.md is explicit that the primary success action on this site is a quote
 * request, and that the shop is the secondary path. The page used to trail off
 * into the footer after the pagination; now it ends on an ink field that names the
 * other way through. A paper hairline separates it from the footer, which is ink
 * too — on an ink field the rule is paper, the inverse of the world's default.
 */
function samswiss_shop_closing_band() {
	?>
	<div class="samswiss-band samswiss-band--ink samswiss-band--close samswiss-shop-close">
		<div class="samswiss-band__inner">
			<p class="samswiss-band__lede"><?php esc_html_e( 'Non trovi l\'articolo che cerchi, o ti serve una quantità fuori catalogo?', 'samswiss-child' ); ?></p>
			<a class="samswiss-band__link" href="<?php echo esc_url( samswiss_contatti_url() ); ?>">
				<span><?php esc_html_e( 'Richiedi un\'offerta', 'samswiss-child' ); ?></span>
				<span class="samswiss-band__arrow" aria-hidden="true">&rarr;</span>
			</a>
		</div>
	</div>
	<?php
}

/**
 * The Contatti page URL, translated by WPML when a translation exists.
 *
 * Falls back to the site root rather than to a hard-coded path: a missing page is
 * a content problem, and a 404 in the shop's only exit would be worse than the
 * home page.
 */
function samswiss_contatti_url() {
	$page = get_page_by_path( 'contatti' );

	if ( $page instanceof WP_Post ) {
		$id = $page->ID;
		if ( function_exists( 'apply_filters' ) ) {
			$translated = apply_filters( 'wpml_object_id', $id, 'page', true );
			if ( $translated ) {
				$id = $translated;
			}
		}
		return get_permalink( $id );
	}

	return home_url( '/' );
}

/**
 * How many products the shop archive can actually show.
 *
 * Not `wp_count_posts`: that returns every published product (1044 here),
 * including the ones WooCommerce excludes from the catalogue, while the shop
 * itself lists 131. The band must agree with the page it sits on, so the count is
 * built with the same visibility exclusion and cached for an hour — it changes
 * when the catalogue changes, not when someone loads a category.
 */
function samswiss_catalogue_total() {
	$cached = get_transient( 'samswiss_catalogue_total' );
	if ( false !== $cached ) {
		return (int) $cached;
	}

	$args = array(
		'post_type'              => 'product',
		'post_status'            => 'publish',
		'posts_per_page'         => 1,
		'fields'                 => 'ids',
		'no_found_rows'          => false,
		'ignore_sticky_posts'    => true,
		'update_post_meta_cache' => false,
		'update_post_term_cache' => false,
	);

	$excluded = array( 'exclude-from-catalog' );
	if ( function_exists( 'wc_get_product_visibility_term_ids' ) ) {
		$args['tax_query'] = array(
			array(
				'taxonomy' => 'product_visibility',
				'field'    => 'slug',
				'terms'    => $excluded,
				'operator' => 'NOT IN',
			),
		);
	}

	$query = new WP_Query( $args );
	$total = (int) $query->found_posts;

	set_transient( 'samswiss_catalogue_total', $total, HOUR_IN_SECONDS );

	return $total;
}

/**
 * Replace the single product's breadcrumb trail with one way back.
 *
 * The trail on a deep product read as five slashes of grey text — "Home /
 * Ingredienti gelaterie e pasticcerie / Gelaterie / Coni e Cialde / Cialde
 * Stampate e Arrotolate / Privato: ARROTOLATO R23" — which is a sentence nobody
 * reads and a row of links nobody clicks. One control replaces it.
 *
 * It is a real link, not `history.back()`: it points at the category the product
 * belongs to, so it works on a page opened from a search result, is crawlable, and
 * needs no JavaScript. Only the product page is touched; the shop masthead keeps
 * its own trail, which is legible white-on-red and belongs to that composition.
 */
function samswiss_replace_product_breadcrumb() {
	remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );
	add_action( 'woocommerce_before_main_content', 'samswiss_product_back_link', 20 );
}
add_action( 'template_redirect', 'samswiss_replace_product_breadcrumb' );

/**
 * The back control: the deepest category the product sits in, or the shop.
 */
function samswiss_product_back_link() {
	if ( ! function_exists( 'is_product' ) || ! is_product() ) {
		return;
	}

	$url   = '';
	$label = '';
	$terms = get_the_terms( get_the_ID(), 'product_cat' );

	if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
		// The deepest term is the one the visitor most likely came through.
		usort( $terms, function ( $a, $b ) {
			return count( get_ancestors( $b->term_id, 'product_cat' ) )
				- count( get_ancestors( $a->term_id, 'product_cat' ) );
		} );
		$link = get_term_link( $terms[0] );
		if ( ! is_wp_error( $link ) ) {
			$url   = $link;
			$label = $terms[0]->name;
		}
	}

	if ( '' === $url && function_exists( 'wc_get_page_permalink' ) ) {
		$url   = wc_get_page_permalink( 'shop' );
		$label = __( 'Shop', 'samswiss-child' );
	}

	if ( '' === $url ) {
		return;
	}

	// The wrapper carries the page measure: this hook prints outside the theme's
	// container, and an inline-flex link cannot be centred by margins alone.
	printf(
		'<div class="samswiss-back-wrap"><a class="samswiss-back" href="%1$s"><span class="samswiss-back__arrow" aria-hidden="true">&larr;</span><span class="samswiss-back__label">%2$s</span><span class="screen-reader-text">: %3$s</span></a></div>',
		esc_url( $url ),
		esc_html__( 'Indietro', 'samswiss-child' ),
		esc_html( $label )
	);
}

/**
 * The confirmation, said properly.
 *
 * WooCommerce's thank-you page opens with "Grazie. Il tuo ordine è stato ricevuto."
 * set as ordinary body copy, followed by a thin strip of figures. It reads like a
 * system message on the one page where the visitor has just spent money and wants to
 * be told, clearly, that it worked. This gives the moment the weight the rest of the
 * site gives its openings: a label, a display line, and the order number as the thing
 * to write down.
 *
 * The receipt below it is kept. "Just a thank-you" would mean a customer who closes
 * the tab has no record of what they bought — the recap IS the confirmation, so it
 * stays and is merely made quiet.
 *
 * @param int $order_id Order id.
 * @return void
 */
function samswiss_thankyou_heading( $order_id ) {
	$order = wc_get_order( $order_id );
	if ( ! $order ) {
		return;
	}

	$failed = $order->has_status( 'failed' );
	?>
	<header class="samswiss-thankyou-head<?php echo $failed ? ' is-failed' : ''; ?>">
		<p class="sw-label"><?php echo $failed ? esc_html__( 'Pagamento non riuscito', 'samswiss-child' ) : esc_html__( 'Ordine confermato', 'samswiss-child' ); ?></p>
		<h2 class="samswiss-thankyou-title"><?php echo $failed ? esc_html__( 'Qualcosa non ha funzionato.', 'samswiss-child' ) : esc_html__( 'Grazie.', 'samswiss-child' ); ?></h2>
		<?php if ( ! $failed ) : ?>
			<p class="samswiss-thankyou-lede">
				<?php
				printf(
					/* translators: 1: order number, 2: billing email */
					esc_html__( 'Abbiamo ricevuto il suo ordine %1$s. Una conferma è in arrivo a %2$s.', 'samswiss-child' ),
					'<strong>' . esc_html( $order->get_order_number() ) . '</strong>',
					'<strong>' . esc_html( $order->get_billing_email() ) . '</strong>'
				);
				?>
			</p>
		<?php endif; ?>
	</header>
	<?php
}
add_action( 'woocommerce_before_thankyou', 'samswiss_thankyou_heading', 5 );

/**
 * Give the visitor somewhere to go next.
 *
 * A confirmation page with no exit is a dead end: the browser back button leads to a
 * checkout that no longer has a cart. Priority 20 puts this after
 * `woocommerce_order_details_table` (10), so the action closes the page rather than
 * interrupting the receipt.
 *
 * @return void
 */
function samswiss_thankyou_actions() {
	$shop = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : '';
	if ( ! $shop ) {
		return;
	}
	?>
	<div class="samswiss-thankyou-actions">
		<a class="samswiss-thankyou-cta" href="<?php echo esc_url( $shop ); ?>">
			<span><?php esc_html_e( 'Torna allo shop', 'samswiss-child' ); ?></span>
			<i aria-hidden="true">&rarr;</i>
		</a>
	</div>
	<?php
}
add_action( 'woocommerce_thankyou', 'samswiss_thankyou_actions', 20 );
