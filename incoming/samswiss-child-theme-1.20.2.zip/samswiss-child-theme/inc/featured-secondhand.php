<?php
/**
 * Gestione Macchina d'Occasione in Evidenza.
 *
 * Permette all'amministratore di selezionare quale macchina d'occasione
 * (post con categoria 'second-hand') mettere in evidenza sulla Home Page
 * (blocco "MACCHINE D'OCCASIONE") e assicura che la macchina scelta
 * si posizioni automaticamente in 1ª posizione nel catalogo /second-hand/.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Recupera l'ID del post della macchina d'occasione in evidenza.
 * Supporta la traduzione dell'ID nel caso in cui WPML sia attivo.
 *
 * @return int ID del post, oppure 0 se non impostato.
 */
function samswiss_get_featured_secondhand_id() {
	$featured_id = (int) get_option( 'samswiss_featured_secondhand_id', 0 );
	if ( ! $featured_id ) {
		return 0;
	}

	// Se WPML è attivo, traduce l'ID nella lingua corrente.
	if ( function_exists( 'apply_filters' ) ) {
		$translated_id = (int) apply_filters( 'wpml_object_id', $featured_id, 'post', true );
		if ( $translated_id > 0 ) {
			return $translated_id;
		}
	}

	return $featured_id;
}

/**
 * Recupera l'oggetto WP_Post della macchina in evidenza.
 * Se non è stata impostata manualmente o non è valida (es. cancellata/bozza/senza foto),
 * ricade automaticamente sulla macchina pubblicata più recente con foto.
 *
 * @return WP_Post|null
 */
function samswiss_get_featured_secondhand_post() {
	$featured_id = samswiss_get_featured_secondhand_id();
	if ( $featured_id ) {
		$post = get_post( $featured_id );
		if ( $post && 'publish' === $post->post_status && has_post_thumbnail( $post ) ) {
			return $post;
		}
	}

	// Fallback: macchina d'occasione più recente pubblicata con thumbnail.
	$fallback = get_posts(
		array(
			'post_type'      => 'post',
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			'orderby'        => 'date',
			'order'          => 'DESC',
			'category_name'  => 'second-hand',
			'meta_query'     => array(
				array(
					'key'     => '_thumbnail_id',
					'compare' => 'EXISTS',
				),
			),
		)
	);

	return ! empty( $fallback ) ? $fallback[0] : null;
}

/**
 * Modifica la clausola ORDER BY delle query per la categoria 'second-hand'
 * in modo che la macchina in evidenza compaia sempre come PRIMO elemento,
 * mentre tutte le altre macchine rimangano ordinate per data decrescente.
 *
 * @param array    $clauses Array delle clausole SQL generate da WP_Query.
 * @param WP_Query $query   Istanza corrente di WP_Query.
 * @return array
 */
function samswiss_featured_secondhand_orderby_clause( $clauses, $query ) {
	if ( is_admin() ) {
		return $clauses;
	}

	$is_second_hand = false;
	if ( $query->is_category( 'second-hand' ) ) {
		$is_second_hand = true;
	} elseif ( 'second-hand' === $query->get( 'category_name' ) ) {
		$is_second_hand = true;
	} elseif ( is_array( $query->get( 'category_name' ) ) && in_array( 'second-hand', $query->get( 'category_name' ), true ) ) {
		$is_second_hand = true;
	}

	if ( ! $is_second_hand ) {
		return $clauses;
	}

	$featured_post = samswiss_get_featured_secondhand_post();
	if ( ! $featured_post ) {
		return $clauses;
	}

	global $wpdb;
	$featured_id = (int) $featured_post->ID;
	$case_sql    = "CASE WHEN {$wpdb->posts}.ID = {$featured_id} THEN 0 ELSE 1 END ASC";

	if ( ! empty( $clauses['orderby'] ) ) {
		$clauses['orderby'] = $case_sql . ', ' . $clauses['orderby'];
	} else {
		$clauses['orderby'] = $case_sql . ", {$wpdb->posts}.post_date DESC";
	}

	return $clauses;
}
add_filter( 'posts_clauses', 'samswiss_featured_secondhand_orderby_clause', 10, 2 );

/* ==========================================================================
   ADMIN: Gestione Macchina in Evidenza
   ========================================================================== */

/**
 * Aggiunge la voce di menu sotto "Articoli" nel pannello di amministrazione.
 */
function samswiss_featured_secondhand_admin_menu() {
	add_submenu_page(
		'edit.php',
		__( 'Macchina d\'Occasione in Evidenza', 'samswiss-child' ),
		__( '⭐ Macchina in Evidenza', 'samswiss-child' ),
		'edit_posts',
		'samswiss-featured-machine',
		'samswiss_render_featured_secondhand_page'
	);
}
add_action( 'admin_menu', 'samswiss_featured_secondhand_admin_menu' );

/**
 * Gestisce il salvataggio dell'opzione da pannello admin.
 */
function samswiss_handle_featured_machine_action() {
	if ( ! isset( $_POST['samswiss_featured_action'] ) ) {
		return;
	}

	if ( ! current_user_can( 'edit_posts' ) ) {
		wp_die( esc_html__( 'Permessi insufficienti.', 'samswiss-child' ) );
	}

	check_admin_referer( 'samswiss_save_featured_machine', 'samswiss_nonce' );

	$action = sanitize_text_field( wp_unslash( $_POST['samswiss_featured_action'] ) );

	if ( 'set' === $action && isset( $_POST['featured_post_id'] ) ) {
		$post_id = (int) $_POST['featured_post_id'];
		if ( $post_id > 0 && get_post( $post_id ) ) {
			update_option( 'samswiss_featured_secondhand_id', $post_id );
			wp_safe_redirect( add_query_arg( array( 'page' => 'samswiss-featured-machine', 'updated' => 'set' ), admin_url( 'edit.php' ) ) );
			exit;
		}
	} elseif ( 'reset' === $action ) {
		delete_option( 'samswiss_featured_secondhand_id' );
		wp_safe_redirect( add_query_arg( array( 'page' => 'samswiss-featured-machine', 'updated' => 'reset' ), admin_url( 'edit.php' ) ) );
		exit;
	}
}
add_action( 'admin_init', 'samswiss_handle_featured_machine_action' );

/**
 * Render della pagina di amministrazione "Macchina in Evidenza".
 */
function samswiss_render_featured_secondhand_page() {
	$manual_featured_id = (int) get_option( 'samswiss_featured_secondhand_id', 0 );
	$active_post        = samswiss_get_featured_secondhand_post();

	// Recupera tutte le macchine della categoria second-hand.
	$machines = get_posts(
		array(
			'post_type'      => 'post',
			'post_status'    => 'publish',
			'posts_per_page' => 50,
			'orderby'        => 'date',
			'order'          => 'DESC',
			'category_name'  => 'second-hand',
		)
	);

	$notice = isset( $_GET['updated'] ) ? sanitize_text_field( wp_unslash( $_GET['updated'] ) ) : '';
	?>
	<div class="wrap samswiss-admin-featured">
		<h1 style="display:flex;align-items:center;gap:10px;font-size:24px;margin-bottom:20px;">
			<span style="color:#789c37;">⭐</span> <?php esc_html_e( 'Macchina d\'Occasione in Evidenza', 'samswiss-child' ); ?>
		</h1>

		<?php if ( 'set' === $notice ) : ?>
			<div class="notice notice-success is-dismissible">
				<p><strong><?php esc_html_e( 'Macchina in evidenza aggiornata con successo! Ora è visibile sulla Home Page ed è al 1° posto nel catalogo.', 'samswiss-child' ); ?></strong></p>
			</div>
		<?php elseif ( 'reset' === $notice ) : ?>
			<div class="notice notice-info is-dismissible">
				<p><strong><?php esc_html_e( 'Ripristinata la selezione automatica (la macchina più recente con foto verrà mostrata in evidenza).', 'samswiss-child' ); ?></strong></p>
			</div>
		<?php endif; ?>

		<div style="background:#fff;border:1px solid #ccd0d4;border-radius:8px;padding:20px;margin-bottom:30px;box-shadow:0 1px 3px rgba(0,0,0,0.05);">
			<h2 style="margin-top:0;font-size:18px;color:#1d2327;">
				<?php esc_html_e( 'Macchina Attualmente Mostrata sulla Home Page', 'samswiss-child' ); ?>
			</h2>
			<p style="color:#50575e;margin-bottom:20px;">
				<?php esc_html_e( 'Questa è la macchina che appare nel blocco "MACCHINE D\'OCCASIONE" della Home Page ed è posizionata al 1° posto nel catalogo /second-hand/.', 'samswiss-child' ); ?>
			</p>

			<?php if ( $active_post ) : ?>
				<div style="display:flex;gap:24px;align-items:center;background:#f9fbf7;border:2px solid #789c37;border-radius:6px;padding:16px;">
					<div style="width:140px;height:120px;display:flex;align-items:center;justify-content:center;background:#fff;border:1px solid #e2e4e7;border-radius:4px;overflow:hidden;flex-shrink:0;">
						<?php if ( has_post_thumbnail( $active_post ) ) : ?>
							<?php echo get_the_post_thumbnail( $active_post, 'medium', array( 'style' => 'max-width:100%;max-height:100%;object-fit:contain;' ) ); ?>
						<?php else : ?>
							<span style="color:#8c8f94;font-size:12px;"><?php esc_html_e( 'Nessuna foto', 'samswiss-child' ); ?></span>
						<?php endif; ?>
					</div>
					<div style="flex-grow:1;">
						<div style="display:inline-block;background:#789c37;color:#fff;font-size:11px;font-weight:700;letter-spacing:0.5px;padding:3px 8px;border-radius:3px;text-transform:uppercase;margin-bottom:6px;">
							<?php echo $manual_featured_id ? esc_html__( 'Scelta Manuale', 'samswiss-child' ) : esc_html__( 'Automatica (Più Recente)', 'samswiss-child' ); ?>
						</div>
						<h3 style="margin:0 0 6px 0;font-size:18px;">
							<a href="<?php echo esc_url( get_edit_post_link( $active_post ) ); ?>" style="text-decoration:none;color:#1d2327;">
								<?php echo esc_html( get_the_title( $active_post ) ); ?>
							</a>
						</h3>
						<p style="margin:0 0 10px 0;color:#646970;font-size:13px;">
							<?php esc_html_e( 'Pubblicata il:', 'samswiss-child' ); ?> <?php echo esc_html( get_the_date( '', $active_post ) ); ?>
						</p>
						<div style="display:flex;gap:12px;align-items:center;">
							<a href="<?php echo esc_url( home_url( '/macchine-confezionatrici/' ) ); ?>" target="_blank" class="button" style="display:inline-flex;align-items:center;gap:4px;">
								<span class="dashicons dashicons-external" style="font-size:16px;line-height:28px;"></span> <?php esc_html_e( 'Vedi sulla Home Page', 'samswiss-child' ); ?>
							</a>
							<a href="<?php echo esc_url( home_url( '/second-hand/' ) ); ?>" target="_blank" class="button" style="display:inline-flex;align-items:center;gap:4px;">
								<span class="dashicons dashicons-external" style="font-size:16px;line-height:28px;"></span> <?php esc_html_e( 'Vedi nel catalogo Usato', 'samswiss-child' ); ?>
							</a>
							<?php if ( $manual_featured_id ) : ?>
								<form method="post" action="" style="display:inline-block;margin:0;">
									<?php wp_nonce_field( 'samswiss_save_featured_machine', 'samswiss_nonce' ); ?>
									<input type="hidden" name="samswiss_featured_action" value="reset">
									<button type="submit" class="button button-link-delete" style="font-size:13px;padding:0 8px;">
										<?php esc_html_e( 'Ripristina selezione automatica', 'samswiss-child' ); ?>
									</button>
								</form>
							<?php endif; ?>
						</div>
					</div>
				</div>
			<?php else : ?>
				<p style="color:#d63638;"><?php esc_html_e( 'Nessuna macchina d\'occasione trovata con immagine in evidenza.', 'samswiss-child' ); ?></p>
			<?php endif; ?>
		</div>

		<!-- Elenco Macchine -->
		<div style="background:#fff;border:1px solid #ccd0d4;border-radius:8px;padding:20px;box-shadow:0 1px 3px rgba(0,0,0,0.05);">
			<h2 style="margin-top:0;font-size:18px;color:#1d2327;">
				<?php esc_html_e( 'Tutte le Macchine d\'Occasione Disponibili', 'samswiss-child' ); ?>
			</h2>
			<p style="color:#50575e;margin-bottom:20px;">
				<?php esc_html_e( 'Scegli quale macchina mettere in evidenza cliccando sul pulsante verde "⭐ Metti in Evidenza".', 'samswiss-child' ); ?>
			</p>

			<table class="wp-list-table widefat fixed striped posts" style="border:none;">
				<thead>
					<tr>
						<th style="width:100px;"><?php esc_html_e( 'Foto', 'samswiss-child' ); ?></th>
						<th><?php esc_html_e( 'Titolo Macchina', 'samswiss-child' ); ?></th>
						<th style="width:140px;"><?php esc_html_e( 'Data', 'samswiss-child' ); ?></th>
						<th style="width:160px;"><?php esc_html_e( 'Stato', 'samswiss-child' ); ?></th>
						<th style="width:200px;text-align:right;"><?php esc_html_e( 'Azione', 'samswiss-child' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( ! empty( $machines ) ) : ?>
						<?php foreach ( $machines as $m ) :
							$is_this_active = ( $active_post && $active_post->ID === $m->ID );
							$has_thumb      = has_post_thumbnail( $m );
							?>
							<tr style="<?php echo $is_this_active ? 'background-color:#f4f8ee;' : ''; ?>">
								<td style="vertical-align:middle;">
									<div style="width:70px;height:60px;display:flex;align-items:center;justify-content:center;background:#fff;border:1px solid #ddd;border-radius:4px;overflow:hidden;">
										<?php if ( $has_thumb ) : ?>
											<?php echo get_the_post_thumbnail( $m, 'thumbnail', array( 'style' => 'max-width:100%;max-height:100%;object-fit:contain;' ) ); ?>
										<?php else : ?>
											<span style="color:#a7aaad;font-size:11px;"><?php esc_html_e( 'No foto', 'samswiss-child' ); ?></span>
										<?php endif; ?>
									</div>
								</td>
								<td style="vertical-align:middle;">
									<strong>
										<a href="<?php echo esc_url( get_edit_post_link( $m ) ); ?>" style="font-size:14px;color:#1d2327;">
											<?php echo esc_html( get_the_title( $m ) ); ?>
										</a>
									</strong>
									<div class="row-actions">
										<span class="edit"><a href="<?php echo esc_url( get_edit_post_link( $m ) ); ?>"><?php esc_html_e( 'Modifica', 'samswiss-child' ); ?></a> | </span>
										<span class="view"><a href="<?php echo esc_url( get_permalink( $m ) ); ?>" target="_blank"><?php esc_html_e( 'Visualizza', 'samswiss-child' ); ?></a></span>
									</div>
								</td>
								<td style="vertical-align:middle;color:#646970;">
									<?php echo esc_html( get_the_date( '', $m ) ); ?>
								</td>
								<td style="vertical-align:middle;">
									<?php if ( $is_this_active ) : ?>
										<span style="background:#789c37;color:#fff;font-weight:700;font-size:11px;padding:4px 8px;border-radius:3px;display:inline-flex;align-items:center;gap:4px;">
											⭐ <?php esc_html_e( 'IN EVIDENZA ORA', 'samswiss-child' ); ?>
										</span>
									<?php else : ?>
										<span style="color:#646970;font-size:13px;"><?php esc_html_e( 'Pubblicata', 'samswiss-child' ); ?></span>
									<?php endif; ?>
								</td>
								<td style="vertical-align:middle;text-align:right;">
									<?php if ( $is_this_active ) : ?>
										<button type="button" class="button button-disabled" disabled style="opacity:0.7;">
											✓ <?php esc_html_e( 'Attualmente in Evidenza', 'samswiss-child' ); ?>
										</button>
									<?php else : ?>
										<form method="post" action="" style="display:inline-block;margin:0;">
											<?php wp_nonce_field( 'samswiss_save_featured_machine', 'samswiss_nonce' ); ?>
											<input type="hidden" name="samswiss_featured_action" value="set">
											<input type="hidden" name="featured_post_id" value="<?php echo esc_attr( $m->ID ); ?>">
											<button type="submit" class="button button-primary" style="background:#789c37;border-color:#65842c;box-shadow:none;text-shadow:none;">
												⭐ <?php esc_html_e( 'Metti in Evidenza', 'samswiss-child' ); ?>
											</button>
										</form>
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
					<?php else : ?>
						<tr>
							<td colspan="5"><?php esc_html_e( 'Nessuna macchina trovata nella categoria "second-hand".', 'samswiss-child' ); ?></td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
	</div>
	<?php
}

/* ==========================================================================
   ADMIN: Meta Box nella Modifica Singolo Articolo
   ========================================================================== */

/**
 * Registra il metabox nella sidebar di modifica post.
 */
function samswiss_add_featured_machine_metabox() {
	add_meta_box(
		'samswiss_featured_machine_meta',
		__( '⭐ Macchina in Evidenza (Home Page)', 'samswiss-child' ),
		'samswiss_render_featured_machine_metabox',
		'post',
		'side',
		'high'
	);
}
add_action( 'add_meta_boxes', 'samswiss_add_featured_machine_metabox' );

/**
 * Render del metabox.
 *
 * @param WP_Post $post
 */
function samswiss_render_featured_machine_metabox( $post ) {
	wp_nonce_field( 'samswiss_save_metabox_featured', 'samswiss_metabox_nonce' );
	$current_featured_id = (int) get_option( 'samswiss_featured_secondhand_id', 0 );
	$is_featured         = ( $current_featured_id === $post->ID );
	?>
	<div style="padding:4px 0;">
		<label style="display:flex;align-items:flex-start;gap:8px;cursor:pointer;">
			<input type="checkbox" name="samswiss_is_featured_machine" value="1" <?php checked( $is_featured ); ?> style="margin-top:2px;">
			<span>
				<strong><?php esc_html_e( 'Mostra in evidenza sulla Home Page', 'samswiss-child' ); ?></strong>
			</span>
		</label>
		<p class="description" style="margin-top:8px;font-size:12px;color:#646970;">
			<?php esc_html_e( 'Selezionando questa opzione, la foto di questa macchina apparirà nel box "MACCHINE D\'OCCASIONE" della Home Page e sarà posizionata al 1° posto nel catalogo usato.', 'samswiss-child' ); ?>
		</p>
		<?php if ( $is_featured ) : ?>
			<div style="margin-top:10px;padding:6px 10px;background:#f4f8ee;border:1px solid #789c37;border-radius:4px;color:#44611d;font-size:12px;font-weight:600;">
				⭐ <?php esc_html_e( 'Attualmente in evidenza sulla Home', 'samswiss-child' ); ?>
			</div>
		<?php endif; ?>
	</div>
	<?php
}

/**
 * Salva lo stato del metabox al salvataggio del post.
 *
 * @param int $post_id
 */
function samswiss_save_featured_machine_metabox( $post_id ) {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! isset( $_POST['samswiss_metabox_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['samswiss_metabox_nonce'] ) ), 'samswiss_save_metabox_featured' ) ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$current_featured_id = (int) get_option( 'samswiss_featured_secondhand_id', 0 );

	if ( isset( $_POST['samswiss_is_featured_machine'] ) ) {
		update_option( 'samswiss_featured_secondhand_id', $post_id );
	} elseif ( $current_featured_id === $post_id ) {
		// Se era la macchina in evidenza ed è stata deselezionata, rimuove l'opzione.
		delete_option( 'samswiss_featured_secondhand_id' );
	}
}
add_action( 'save_post', 'samswiss_save_featured_machine_metabox' );

/* ==========================================================================
   ADMIN: Colonna nella Lista Articoli (edit.php)
   ========================================================================== */

/**
 * Aggiunge la colonna "Evidenza Home" nella tabella articoli.
 *
 * @param array $columns
 * @return array
 */
function samswiss_add_featured_machine_column( $columns ) {
	$new_columns = array();
	foreach ( $columns as $key => $val ) {
		$new_columns[ $key ] = $val;
		if ( 'title' === $key ) {
			$new_columns['samswiss_featured'] = __( '⭐ Evidenza Home', 'samswiss-child' );
		}
	}
	return $new_columns;
}
add_filter( 'manage_posts_columns', 'samswiss_add_featured_machine_column' );

/**
 * Renderizza il contenuto della colonna "Evidenza Home".
 *
 * @param string $column_name
 * @param int    $post_id
 */
function samswiss_render_featured_machine_column( $column_name, $post_id ) {
	if ( 'samswiss_featured' !== $column_name ) {
		return;
	}

	$active_post = samswiss_get_featured_secondhand_post();
	if ( $active_post && $active_post->ID === $post_id ) {
		$manual_id = (int) get_option( 'samswiss_featured_secondhand_id', 0 );
		$is_manual = ( $manual_id === $post_id );
		echo '<span style="display:inline-block;background:#789c37;color:#fff;font-size:11px;font-weight:700;padding:3px 7px;border-radius:3px;" title="' . ( $is_manual ? esc_attr__( 'Scelta manuale da admin', 'samswiss-child' ) : esc_attr__( 'In evidenza automatica (più recente)', 'samswiss-child' ) ) . '">';
		echo '⭐ ' . esc_html__( 'IN EVIDENZA', 'samswiss-child' );
		echo '</span>';
	}
}
add_action( 'manage_posts_custom_column', 'samswiss_render_featured_machine_column', 10, 2 );
