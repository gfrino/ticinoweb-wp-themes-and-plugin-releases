<?php
/**
 * Seeds Second Hand / Macchine d'Occasione and News posts.
 *
 * Superseded by inc/content-seed.php which provides unified, per-post seeding
 * for both Second Hand machines and News articles. Kept for backwards
 * compatibility with older theme loaders.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/content-seed.php';
