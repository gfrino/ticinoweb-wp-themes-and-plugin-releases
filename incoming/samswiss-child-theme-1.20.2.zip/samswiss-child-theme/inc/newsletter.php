<?php
/**
 * SAM SWISS child theme — newsletter signup handler.
 *
 * The Swiss surfaces render a newsletter field that previously posted to "#":
 * the address was silently discarded with no feedback. This gives it a real
 * endpoint. There is no newsletter platform connected to this install, so a
 * signup is delivered as a notification to the company address via wp_mail()
 * (the parent theme routes wp_mail through SMTP/SendGrid). Nothing here claims
 * an integration that does not exist.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Outcome messages, keyed by code, shared by the AJAX and no-JS paths.
 *
 * @param string $code Outcome code.
 * @return string
 */
function samswiss_newsletter_message( $code ) {
	$messages = array(
		'ok'      => __( 'Grazie! Ti abbiamo aggiunto alla lista.', 'samswiss-child' ),
		'nonce'   => __( 'Sessione scaduta. Ricarica la pagina e riprova.', 'samswiss-child' ),
		'invalid' => __( 'Inserisci un indirizzo email valido.', 'samswiss-child' ),
		'failed'  => __( 'Si è verificato un errore durante l\'iscrizione. Riprova più tardi.', 'samswiss-child' ),
	);

	return isset( $messages[ $code ] ) ? $messages[ $code ] : $messages['invalid'];
}

/**
 * Validate and record a newsletter signup.
 *
 * @return array{code:string,success:bool}
 */
function samswiss_newsletter_process() {
	$nonce = isset( $_POST['samswiss_newsletter_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['samswiss_newsletter_nonce'] ) ) : '';
	if ( ! wp_verify_nonce( $nonce, 'samswiss_newsletter' ) ) {
		return array( 'code' => 'nonce', 'success' => false );
	}

	// Honeypot: real people leave it empty. Reported as success so a bot learns
	// nothing from the difference.
	if ( ! empty( $_POST['website'] ) ) {
		return array( 'code' => 'ok', 'success' => true );
	}

	$email = isset( $_POST['newsletter_email'] ) ? sanitize_email( wp_unslash( $_POST['newsletter_email'] ) ) : '';
	if ( ! is_email( $email ) ) {
		return array( 'code' => 'invalid', 'success' => false );
	}

	$contact = function_exists( 'samswiss_get_contact' ) ? samswiss_get_contact() : array();
	$to      = get_option( 'ticinoweb_contact_email' );
	if ( ! $to || strpos( $to, 'localhost' ) !== false ) {
		$to = ! empty( $contact['email'] ) ? $contact['email'] : get_option( 'admin_email' );
	}

	$source = isset( $_POST['source'] ) ? esc_url_raw( wp_unslash( $_POST['source'] ) ) : home_url();

	// Persist first, notify second. Mail delivery depends on SMTP/SendGrid being
	// configured in the CMS; if it is not, the signup must still not be lost.
	$stored = samswiss_store_subscriber( $email, $source );

	wp_mail(
		$to,
		__( 'Nuova iscrizione alla newsletter', 'samswiss-child' ),
		sprintf(
			/* translators: 1: subscriber email, 2: source page URL */
			__( "Nuova iscrizione alla newsletter.\n\nEmail: %1\$s\nPagina: %2\$s\n", 'samswiss-child' ),
			$email,
			$source
		),
		array( 'Content-Type: text/plain; charset=UTF-8' )
	);

	return $stored
		? array( 'code' => 'ok', 'success' => true )
		: array( 'code' => 'failed', 'success' => false );
}

/**
 * AJAX transport.
 */
function samswiss_handle_newsletter() {
	$result = samswiss_newsletter_process();
	wp_send_json( array(
		'success' => $result['success'],
		'message' => samswiss_newsletter_message( $result['code'] ),
	) );
}

/**
 * Ordinary form POST transport (no JavaScript).
 */
function samswiss_handle_newsletter_post() {
	$result = samswiss_newsletter_process();

	$back = isset( $_POST['redirect_to'] ) ? wp_unslash( $_POST['redirect_to'] ) : '';
	$back = $back ? wp_validate_redirect( $back, home_url( '/' ) ) : wp_get_referer();
	if ( ! $back ) {
		$back = home_url( '/' );
	}

	wp_safe_redirect( add_query_arg( 'samswiss_newsletter', $result['code'], $back ) );
	exit;
}
add_action( 'admin_post_nopriv_samswiss_newsletter', 'samswiss_handle_newsletter_post' );
add_action( 'admin_post_samswiss_newsletter', 'samswiss_handle_newsletter_post' );

/**
 * The outcome to render after a no-JS signup, or an empty array.
 *
 * @return array{code:string,success:bool,message:string}|array{}
 */
function samswiss_newsletter_feedback() {
	if ( empty( $_GET['samswiss_newsletter'] ) ) {
		return array();
	}

	$code = sanitize_key( wp_unslash( $_GET['samswiss_newsletter'] ) );

	return array(
		'code'    => $code,
		'success' => ( 'ok' === $code ),
		'message' => samswiss_newsletter_message( $code ),
	);
}

/**
 * Store a subscriber so a signup survives a mail failure.
 *
 * Kept in a single option as an email-keyed map: it de-duplicates by design and
 * stays small. Re-subscribing an existing address is reported as success
 * without creating a duplicate row.
 *
 * @param string $email  Validated subscriber address.
 * @param string $source URL the signup came from.
 * @return bool True when the address is on the list afterwards.
 */
function samswiss_store_subscriber( $email, $source = '' ) {
	$key  = strtolower( $email );
	$list = get_option( 'samswiss_newsletter_subscribers', array() );
	if ( ! is_array( $list ) ) {
		$list = array();
	}

	if ( isset( $list[ $key ] ) ) {
		return true;
	}

	$list[ $key ] = array(
		'email'  => $email,
		'date'   => current_time( 'mysql' ),
		'source' => $source,
		'lang'   => (string) apply_filters( 'wpml_current_language', null ),
	);

	return (bool) update_option( 'samswiss_newsletter_subscribers', $list, false );
}

/**
 * Expose the subscriber list to the admin as a CSV export, so the client can
 * take the addresses into whatever mailing tool they use.
 * URL: /wp-admin/admin-post.php?action=samswiss_export_subscribers
 */
function samswiss_export_subscribers() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Non hai i permessi per esportare gli iscritti.', 'samswiss-child' ), '', array( 'response' => 403 ) );
	}
	check_admin_referer( 'samswiss_export_subscribers' );

	$list = get_option( 'samswiss_newsletter_subscribers', array() );
	$list = is_array( $list ) ? $list : array();

	nocache_headers();
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename=samswiss-newsletter.csv' );

	$out = fopen( 'php://output', 'w' );
	fputcsv( $out, array( 'email', 'date', 'source', 'lang' ) );
	foreach ( $list as $row ) {
		fputcsv( $out, array(
			isset( $row['email'] ) ? $row['email'] : '',
			isset( $row['date'] ) ? $row['date'] : '',
			isset( $row['source'] ) ? $row['source'] : '',
			isset( $row['lang'] ) ? $row['lang'] : '',
		) );
	}
	fclose( $out );
	exit;
}
add_action( 'admin_post_samswiss_export_subscribers', 'samswiss_export_subscribers' );

/**
 * Export the recorded contact enquiries as CSV.
 *
 * Companion to the subscriber export: while no mail transport is configured,
 * this is the only way to read what visitors actually sent.
 * URL: /wp-admin/admin-post.php?action=samswiss_export_enquiries
 */
function samswiss_export_enquiries() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Non hai i permessi per esportare le richieste.', 'samswiss-child' ), '', array( 'response' => 403 ) );
	}
	check_admin_referer( 'samswiss_export_enquiries' );

	$list = get_option( 'samswiss_contact_enquiries', array() );
	$list = is_array( $list ) ? $list : array();

	nocache_headers();
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename=samswiss-richieste.csv' );

	$out = fopen( 'php://output', 'w' );
	fputcsv( $out, array( 'date', 'name', 'email', 'phone', 'lang', 'message' ) );
	foreach ( $list as $row ) {
		fputcsv( $out, array(
			isset( $row['date'] ) ? $row['date'] : '',
			isset( $row['name'] ) ? $row['name'] : '',
			isset( $row['email'] ) ? $row['email'] : '',
			isset( $row['phone'] ) ? $row['phone'] : '',
			isset( $row['lang'] ) ? $row['lang'] : '',
			isset( $row['message'] ) ? $row['message'] : '',
		) );
	}
	fclose( $out );
	exit;
}
add_action( 'admin_post_samswiss_export_enquiries', 'samswiss_export_enquiries' );
add_action( 'wp_ajax_samswiss_newsletter', 'samswiss_handle_newsletter' );
add_action( 'wp_ajax_nopriv_samswiss_newsletter', 'samswiss_handle_newsletter' );

/**
 * Print the newsletter form fields shared by every Swiss surface, so the two
 * templates cannot drift apart again.
 *
 * @param string $variant 'swiss' (Macchine surface) or 'archive'.
 */
function samswiss_newsletter_form( $variant = 'swiss' ) {
	$is_swiss = ( 'swiss' === $variant );
	$form_cls = $is_swiss ? 'swiss-news__form' : 'samswiss-newsletter-form';
	$input_cls = $is_swiss ? 'swiss-news__input' : '';
	$btn_cls  = $is_swiss ? 'swiss-news__submit' : 'samswiss-newsletter-btn';
	$id       = 'samswiss-newsletter-' . ( $is_swiss ? 'swiss' : 'archive' );

	// Outcome of a no-JS signup, rendered in place.
	$notice = samswiss_newsletter_feedback();
	?>
	<?php if ( $notice ) : ?>
		<p class="samswiss-newsletter-notice <?php echo $notice['success'] ? 'is-success' : 'is-error'; ?>" role="status">
			<?php echo esc_html( $notice['message'] ); ?>
		</p>
	<?php endif; ?>
	<?php
	// Posts to admin-post.php, not to "#": the form has to work when the AJAX in
	// main.js does not run, because a dropped signup is invisible to the visitor.
	// `novalidate` is set by main.js at runtime, so with no JavaScript the browser
	// still checks the email field itself.
	?>
	<form class="<?php echo esc_attr( $form_cls ); ?> samswiss-newsletter" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<label class="screen-reader-text" for="<?php echo esc_attr( $id ); ?>"><?php esc_html_e( 'Il tuo indirizzo email', 'samswiss-child' ); ?></label>
		<input class="<?php echo esc_attr( $input_cls ); ?>" id="<?php echo esc_attr( $id ); ?>" type="email" name="newsletter_email" placeholder="<?php esc_attr_e( 'Il tuo indirizzo email', 'samswiss-child' ); ?>" autocomplete="email" required>
		<span class="samswiss-newsletter-honeypot" aria-hidden="true"><label>Website<input type="text" name="website" tabindex="-1" autocomplete="off"></label></span>
		<?php wp_nonce_field( 'samswiss_newsletter', 'samswiss_newsletter_nonce' ); ?>
		<input type="hidden" name="action" value="samswiss_newsletter">
		<input type="hidden" name="source" value="<?php echo esc_url( samswiss_current_url() ); ?>">
		<input type="hidden" name="redirect_to" value="<?php echo esc_url( samswiss_current_url() ); ?>">
		<button class="<?php echo esc_attr( $btn_cls ); ?>" type="submit"><?php esc_html_e( 'Spedire', 'samswiss-child' ); ?> <i class="fas fa-chevron-right" aria-hidden="true"></i></button>
		<p class="samswiss-newsletter-feedback" role="status" aria-live="polite"></p>
	</form>
	<?php
}
