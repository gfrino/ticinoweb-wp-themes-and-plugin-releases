<?php
/**
 * Search results.
 *
 * The header exposes a search affordance, so its destination is a real surface
 * rather than the bare index.php fallback: results used to arrive with no
 * heading, no echo of the query and no count. Search reaches products, machine
 * posts and pages at once, so each hit names its own kind — a visitor who typed
 * "box" needs to know which of the 27 answers is a product they can buy and
 * which is an article about one.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$query = get_search_query();
$found = (int) $GLOBALS['wp_query']->found_posts;

// Ways out of an empty result: key destinations resolved to the current language
$ways = array_values( array_filter( array(
	array( 'label' => __( 'Macchine confezionatrici', 'samswiss-child' ), 'url' => samswiss_localized_permalink( 203, 'page', 'sam-sa-packaging-lines' ) ),
	array( 'label' => __( 'Imballaggi e consumabili', 'samswiss-child' ), 'url' => home_url( '/imballaggi-e-consumabili/' ) ),
	array( 'label' => __( 'Macchine d\'occasione', 'samswiss-child' ), 'url' => home_url( '/macchine-occasione/' ) ),
), function ( $w ) {
	return ! empty( $w['url'] );
} ) );
?>

<main id="primary" class="samswiss-main samswiss-search">

	<section class="samswiss-page-header samswiss-search-header">
		<div class="samswiss-container">
			<p class="sw-label"><?php esc_html_e( 'Ricerca', 'samswiss-child' ); ?></p>
			<h1 class="samswiss-page-title samswiss-search-title">
				<?php
				if ( '' === $query ) {
					esc_html_e( 'Cosa stai cercando?', 'samswiss-child' );
				} else {
					echo esc_html( $query );
				}
				?>
			</h1>
			<?php if ( '' !== $query ) : ?>
				<p class="samswiss-search-count">
					<?php
					printf(
						/* translators: %s: number of results found. */
						esc_html( _n( '%s risultato', '%s risultati', $found, 'samswiss-child' ) ),
						esc_html( number_format_i18n( $found ) )
					);
					?>
				</p>
			<?php endif; ?>
		</div>
	</section>

	<section class="samswiss-search-body">
		<div class="samswiss-container">

			<?php // The form is repeated here so a no-result page is a place to try again, not a dead end. ?>
			<form class="samswiss-search-inline" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
				<?php
				samswiss_live_search_field( array(
					'id'           => 'samswiss-search-results-field',
					'input_class'  => 'samswiss-search-inline__input',
					'submit_class' => 'samswiss-search-inline__submit',
				) );
				?>
			</form>

			<?php if ( have_posts() ) : ?>
				<ul class="samswiss-search-list">
					<?php
					while ( have_posts() ) :
						the_post();

						$type  = get_post_type();
						$kind  = __( 'Pagina', 'samswiss-child' );
						$price = '';
						if ( 'product' === $type ) {
							$kind    = __( 'Prodotto', 'samswiss-child' );
							$product = function_exists( 'wc_get_product' ) ? wc_get_product( get_the_ID() ) : null;
							if ( $product ) {
								$price = $product->get_price_html();
							}
						} elseif ( 'post' === $type ) {
							$kind = __( 'Macchina', 'samswiss-child' );
						}
						?>
						<li class="samswiss-search-hit">
							<a class="samswiss-search-hit__link" href="<?php the_permalink(); ?>">
								<span class="samswiss-search-hit__media">
									<?php
									if ( has_post_thumbnail() ) {
										the_post_thumbnail( 'thumbnail', array( 'loading' => 'lazy', 'alt' => '' ) );
									}
									?>
								</span>
								<span class="samswiss-search-hit__body">
									<span class="sw-label samswiss-search-hit__kind"><?php echo esc_html( $kind ); ?></span>
									<span class="samswiss-search-hit__title"><?php the_title(); ?></span>
									<?php if ( $price ) : ?>
										<span class="samswiss-search-hit__price"><?php echo wp_kses_post( $price ); ?></span>
									<?php else : ?>
										<span class="samswiss-search-hit__excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 20, '…' ) ); ?></span>
									<?php endif; ?>
								</span>
								<span class="samswiss-search-hit__arrow" aria-hidden="true">&rarr;</span>
							</a>
						</li>
					<?php endwhile; ?>
				</ul>

				<?php
				the_posts_pagination( array(
					'mid_size'           => 1,
					'prev_text'          => '&laquo; ' . esc_html__( 'Precedente', 'samswiss-child' ),
					'next_text'          => esc_html__( 'Successivo', 'samswiss-child' ) . ' &raquo;',
					'screen_reader_text' => esc_html__( 'Navigazione risultati', 'samswiss-child' ),
				) );
				?>

			<?php else : ?>
				<div class="samswiss-search-empty">
					<?php // Names the section, and keeps the outline h1 -> h2 with no result list to supply one. ?>
					<h2 class="samswiss-search-empty__title"><?php esc_html_e( 'Nessun risultato', 'samswiss-child' ); ?></h2>
					<p class="samswiss-search-empty__lead">
						<?php
						if ( '' === $query ) {
							esc_html_e( 'Scrivi il nome di una macchina o di una tecnologia di confezionamento.', 'samswiss-child' );
						} else {
							printf(
								/* translators: %s: the search term the visitor typed. */
								esc_html__( 'Nessun risultato per «%s». Prova con un termine più corto, o parti da un settore.', 'samswiss-child' ),
								esc_html( $query )
							);
						}
						?>
					</p>

					<?php if ( $ways ) : ?>
						<ul class="samswiss-search-ways">
							<?php foreach ( $ways as $way ) : ?>
								<li>
									<a class="samswiss-search-way" href="<?php echo esc_url( $way['url'] ); ?>">
										<span><?php echo esc_html( $way['label'] ); ?></span>
										<span aria-hidden="true">&rarr;</span>
									</a>
								</li>
							<?php endforeach; ?>
						</ul>
					<?php endif; ?>
				</div>
			<?php endif; ?>

		</div>
	</section>

</main>

<?php
get_footer();
