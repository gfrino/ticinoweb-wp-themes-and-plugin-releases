<?php
/**
 * Generic page template.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

// Rich Elementor landing pages are rebuilt natively as template-parts.
$landing = function_exists( 'samswiss_current_landing_slug' ) ? samswiss_current_landing_slug() : '';
if ( $landing ) {
	while ( have_posts() ) {
		the_post();
		get_template_part( 'template-parts/pages/' . $landing );
	}
	get_footer();
	return;
}
?>

<main id="primary" class="samswiss-main">
	<?php while ( have_posts() ) : the_post(); ?>
		<article <?php post_class( 'samswiss-page' ); ?>>
			<header class="samswiss-page-header">
				<div class="samswiss-container">
					<p class="sw-label">S.A.M. SA</p>
					<h1 class="samswiss-page-title"><?php the_title(); ?></h1>
				</div>
			</header>
			<div class="samswiss-page-content">
				<div class="samswiss-container">
					<?php
					the_content();
					wp_link_pages();
					?>
				</div>
			</div>
		</article>
	<?php endwhile; ?>
</main>

<?php
get_footer();
