<?php
/**
 * Product archive (shop + product_cat/product taxonomies) — SAM SWISS.
 *
 * Two-column layout: category sidebar + product grid, wrapping the standard
 * WooCommerce loop hooks so all core behaviour (ordering, pagination, notices)
 * is preserved.
 *
 * @package samswiss-child
 */

defined( 'ABSPATH' ) || exit;

get_header( 'shop' );

$page_title = woocommerce_page_title( false );
?>

<div class="samswiss-page-header samswiss-shop-header">
	<div class="samswiss-container">
		<?php woocommerce_breadcrumb(); ?>
		<p class="sw-label">S.A.M. SA</p>
		<h1 class="samswiss-page-title"><?php echo esc_html( $page_title ); ?></h1>
		<?php if ( is_product_taxonomy() || is_shop() ) {
			// is_shop() added alongside is_product_taxonomy() so the "presented as
			// examples" note (inc/woocommerce.php) also reaches /shop/ — with only
			// two root categories in the whole catalogue, it lists the same products.
			do_action( 'woocommerce_archive_description' );
		} ?>
	</div>
</div>

<?php samswiss_shop_data_band(); ?>

<div class="samswiss-container samswiss-shop-layout">

	<aside class="samswiss-shop-sidebar">
		<button type="button" class="samswiss-mobile-filter-trigger">
			<i class="fas fa-sliders-h" aria-hidden="true"></i> <?php esc_html_e( 'Categorie e filtri', 'samswiss-child' ); ?>
		</button>
		<div class="samswiss-shop-sidebar-inner">
			<?php get_template_part( 'template-parts/woocommerce/category-sidebar' ); ?>
		</div>
	</aside>

	<main class="samswiss-shop-main">
		<?php
		if ( woocommerce_product_loop() ) {

			/**
			 * woocommerce_before_shop_loop: notices (10), result count (20), ordering (30).
			 */
			do_action( 'woocommerce_before_shop_loop' );

			woocommerce_product_loop_start();

			if ( wc_get_loop_prop( 'total' ) ) {
				while ( have_posts() ) {
					the_post();
					do_action( 'woocommerce_shop_loop' );
					wc_get_template_part( 'content', 'product' );
				}
			}

			woocommerce_product_loop_end();

			/**
			 * woocommerce_after_shop_loop: pagination (10).
			 */
			do_action( 'woocommerce_after_shop_loop' );
		} else {
			do_action( 'woocommerce_no_products_found' );
		}
		?>
	</main>

</div>

<?php
samswiss_shop_closing_band();

get_footer( 'shop' );
