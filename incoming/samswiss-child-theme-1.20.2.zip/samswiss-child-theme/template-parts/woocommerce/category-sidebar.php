<?php
/**
 * Shop / category sidebar: product search + category tree.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="samswiss-sidebar-widget samswiss-widget-search">
	<?php // Live suggestions here too: this is the field a shopper actually uses. ?>
	<form role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
		<input type="hidden" name="post_type" value="product">
		<?php
		samswiss_live_search_field( array(
			'id'           => 'samswiss-shop-search',
			'label'        => __( 'Cerca prodotti', 'samswiss-child' ),
			'placeholder'  => __( 'Cerca prodotti…', 'samswiss-child' ),
			'submit_label' => __( 'Cerca', 'samswiss-child' ),
		) );
		?>
	</form>
</div>

<div class="samswiss-sidebar-widget samswiss-widget-categories">
	<?php // h2, not h3: the shop page's only h1 is its title, so a h3 here would skip a level. ?>
	<h2 class="samswiss-sidebar-title"><?php esc_html_e( 'Categorie', 'samswiss-child' ); ?></h2>
	<?php samswiss_render_product_category_tree( 0, 0 ); ?>
</div>
