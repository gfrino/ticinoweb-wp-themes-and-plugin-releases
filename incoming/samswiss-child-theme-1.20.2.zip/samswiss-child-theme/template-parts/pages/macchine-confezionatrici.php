<?php
/**
 * Landing page: "Macchine confezionatrici" (page #203).
 *
 * Swiss International Typographic Style surface. Structure, counts and links
 * are read from real WordPress data. The one declared exception is the "Le nostre
 * soluzioni" cards (point 46): two of the five have no real photo yet and show a
 * marked placeholder instead — everything else stays live data, no filler.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The sector-frame array this page used to open with (Ortofrutta, Pesatura ed
 * etichettatura, Gastronomia...) is gone as of point 46, replaced by the
 * "Le nostre soluzioni" cards below. Second Hand is the one piece of it that
 * survives, moved (point 48) into a two-column band with News & Approfondimenti,
 * placed after Link Partners. The client's reference layout for that band has no
 * machine count on this side, so — unlike the old sector frame — this one carries
 * no live number, just the link.
 */

/**
 * Second Hand cover photo: the featured image of the most recently published
 * machine in the `second-hand` category (point 60) — whoever adds a new used
 * machine in wp-admin automatically becomes the photo shown here, no theme
 * edit needed. Falls back to the fixed stock photo only if no second-hand
 * listing has a featured image yet, so the band is never left without one.
 */
$second_hand_cover   = '';
$second_hand_machine = function_exists( 'samswiss_get_featured_secondhand_post' )
	? samswiss_get_featured_secondhand_post()
	: null;

if ( $second_hand_machine && has_post_thumbnail( $second_hand_machine ) ) {
	$second_hand_cover = get_the_post_thumbnail( $second_hand_machine, 'medium_large', array( 'class' => 'swiss-promo__photo' ) );
}

/**
 * Latest 3 editorial articles for the News & Approfondimenti column. `articolo-seo`,
 * not `post` — on this install the machines ARE the post type `post`, and the
 * editorial pieces (fairs, installations, technical explainers) live in their own
 * post type so the client can write them from wp-admin without touching the
 * catalogue — same distinction already documented in `infonews.php`, which lists
 * all of them; this is just the latest three as a teaser.
 */
$latest_articles  = get_posts(
	array(
		'post_type'      => 'articolo-seo',
		'post_status'    => 'publish',
		'posts_per_page' => 3,
		'orderby'        => 'date',
		'order'          => 'DESC',
	)
);
$infonews_url = samswiss_localized_permalink( 2225, 'page', 'infonews' ) ?: home_url( '/infonews/' );

// Partner marks link out to each manufacturer. Both Fabbri marks (Caveco and
// the group logo) belong to Gruppo Fabbri.
$partners = array(
	array( 'img' => '2026/01/sorma.jpeg',                        'name' => 'Sorma Group',   'url' => 'https://www.sormagroup.com/it/' ),
	// These four carry a `theme` path as well, and it is the one that gets used. They
	// were added to the media library first and came out BROKEN on the live site,
	// because uploads/ does not travel with a theme — see samswiss_partner_image().
	// The `img` path stays as the fallback for an install where they are in the library.
	array( 'img' => '2026/08/gb-bernucci-logo.png', 'theme' => 'assets/img/partners/gb-bernucci-logo.png', 'name' => 'GB Bernucci', 'url' => home_url( '/imballaggi-e-consumabili/' ) ),
	array( 'img' => '2026/08/bulltec-logo.png',     'theme' => 'assets/img/partners/bulltec-logo.png',     'name' => 'Bulltec',     'url' => 'https://bulltec.it/' ),
	// The mark the client sent, newer than the one that came with the migration
	// (2023/11/RGD-Mape-logo_page-0001.jpg, left untouched in the library).
	array( 'img' => '2026/08/rgd-mape-logo.png',    'theme' => 'assets/img/partners/rgd-mape-logo.png',    'name' => 'RGD Mape',    'url' => 'https://rgdmape.com/home-it/' ),
	array( 'img' => '2026/08/rs-bilance-logo.png',  'theme' => 'assets/img/partners/rs-bilance-logo.png',  'name' => 'RS Bilance',  'url' => 'https://rsbilance.com/' ),
	// The migration carried two Fabbri marks (Caveco and the group logo). The
	// combined Caveco mark is gone on the client's explicit request — one cell now,
	// and it carries the link like every other partner (see the loop below: the
	// special no-link case existed only because of the two-mark ambiguity).
	array( 'img' => '2023/10/fabbri-logo-per-sito_page-0001.jpg', 'name' => 'Gruppo Fabbri', 'url' => 'https://www.gruppofabbri.com/' ),
);

/**
 * "Le nostre soluzioni" — five cards, copy taken from the client's own reference
 * layout (icon + title + photo + description). All five now carry a real photo
 * (Fine Linea e Pallettizzazione was the last to get one, reusing the Sorma
 * Group sorting-line shot already shipped in assets/img/sorma/).
 *
 * Fine Linea e Pallettizzazione is ONE card, not two as in the reference layout —
 * the client asked for them merged.
 */
$sorma_group_url = samswiss_localized_permalink( 26425, 'page', 'sorma-group' ) ?: home_url( '/sorma-group/' );
$solutions        = array(
	array(
		'icon'  => 'fa-box',
		'title' => __( 'Confezionamento', 'samswiss-child' ),
		'text'  => __( 'Tecnologie per diversi prodotti, formati e materiali.', 'samswiss-child' ),
		'img'   => '2020/10/VR4-confezionatrice-1big.jpg',
		'alt'   => __( 'Confezionatrice SAM VR4', 'samswiss-child' ),
		// Was 'macchine-confezionatrici' (point 64 fix): that category holds only
		// blog articles (post type `articolo-seo`), zero real machines — checked
		// directly, not assumed. 'packaging-lines' is the real catalogue category
		// for this concept: 55 published thermosealers/wrappers/vacuum packers.
		'url'   => samswiss_category_url( 'packaging-lines' ),
	),
	array(
		'icon'  => 'fa-weight-scale',
		'title' => __( 'Pesatura ed Etichettatura', 'samswiss-child' ),
		'text'  => __( "Soluzioni per il dosaggio, il controllo preciso del peso e l'etichettatura del prodotto.", 'samswiss-child' ),
		'img'   => '2026/03/WBOX-scaled.png',
		'alt'   => __( 'Pesatrice ed etichettatrice SAM WBOX', 'samswiss-child' ),
		'url'   => samswiss_category_url( 'pesatura-ed-etichettatura' ),
	),
	array(
		'icon'  => 'fa-arrows-left-right',
		'title' => __( 'Movimentazione e Automazione', 'samswiss-child' ),
		'text'  => __( 'Nastri, sistemi di alimentazione e gestione del prodotto.', 'samswiss-child' ),
		// No dedicated category exists for this concept (checked point 64): the
		// catalogue is organised by food sector, not by process step. The site's
		// own search for "movimentazione" does surface six real machines whose
		// description names a conveyor/handling system as a feature (MX AS2
		// DYNAMIC, GWX 270V/AS2 PLUS, SAP L/A/PX2 PLUS) — confirmed by checking the
		// search results page directly, not assumed from the machine names alone.
		'img'   => '2026/03/MXAS2DYNAMICNEW-scaled.png',
		'alt'   => __( 'Sistema di movimentazione e automazione SAM MX AS2 Dynamic', 'samswiss-child' ),
		'url'   => home_url( '/?s=movimentazione' ),
	),
	array(
		'icon'  => 'fa-cubes-stacked',
		'title' => __( 'Fine Linea e Pallettizzazione', 'samswiss-child' ),
		'text'  => __( 'Soluzioni per completare e automatizzare il processo di confezionamento, con sistemi automatici per la gestione finale del prodotto.', 'samswiss-child' ),
		// Same shipped photo already used on the Sorma Group page's "grappolo" section
		// (the multi-lane sorting/grading line) — client asked for this exact photo here.
		'theme' => 'assets/img/sorma/image013.png',
		'img'   => 'image013.png',
		'alt'   => __( 'Linea di smistamento e fine linea Sorma', 'samswiss-child' ),
		'url'   => $sorma_group_url . '#fine-linea',
	),
	array(
		// "Linee Complete" renamed to "Imballaggi e Consumabili" (point 63) — the
		// client's handwritten note on the reference photo ("IMBALLAGGI E ↑
		// CONSUMABILI", pointing at this exact dark tile) asked for this card's
		// content specifically, not just its position.
		'icon'  => 'fa-box-open',
		'title' => __( 'Imballaggi e Consumabili', 'samswiss-child' ),
		'text'  => __( 'Imballaggi alimentari, materiali monouso e consumabili per ogni esigenza di confezionamento.', 'samswiss-child' ),
		'img'   => '2024/03/Contenitore-quadrato-medium-JHS750.jpg',
		'alt'   => __( 'Imballaggi e materiali monouso SAM SA', 'samswiss-child' ),
		'url'   => samswiss_localized_permalink( 1270, 'product_cat', 'imballaggi-e-monouso-categoria' ) ?: home_url( '/product-category/imballaggi-e-monouso-categoria/' ),
		// The one inverted tile in the row, as in the client's reference layout: the
		// flagship offer reads as the row's conclusion. A flag rather than a
		// :last-child CSS rule, so reordering the array cannot silently move the
		// emphasis to a different solution.
		'dark'  => true,
	),
);

/**
 * "Scegli il tuo settore" — three combined-sector cards (point 85), reintroducing
 * a sector gateway on the client's explicit request after the original one was
 * removed at point 46. Each card links to the FIRST category of its group via the
 * existing `samswiss_category_url()`; the red category nav bar already rendered on
 * every category archive (category.php, point 81) is what lets a visitor reach the
 * other categories in the group from there — no new multi-category archive route
 * needed. Cover photos are the newest published article with a featured image in
 * the group's categories (same live-data pattern as $second_hand_cover above), not
 * new uploads: the client's reference photos were stock/AI mockups for layout only.
 */
$sectors = array(
	array(
		'icon'      => 'fa-apple-whole',
		'title'     => __( 'Ortofrutta', 'samswiss-child' ),
		'text'      => __( 'Frutta e verdura fresca in rete, flow-pack o vaschetta.', 'samswiss-child' ),
		'cat_slugs' => array( 'ortofrutta' ),
		'url'       => samswiss_category_url( 'ortofrutta' ),
		'theme_img' => 'assets/img/settori/ortofrutta.jpeg',
		'alt'       => __( 'Ortofrutta', 'samswiss-child' ),
	),
	array(
		'icon'      => 'fa-utensils',
		'title'     => __( 'Gastronomia, Panetteria e IV Gamma', 'samswiss-child' ),
		'text'      => __( 'Piatti pronti, prodotti da forno, insalate e prodotti freschi.', 'samswiss-child' ),
		'cat_slugs' => array( 'gastronomia-e-ristorazione', 'pane-pasticceria-gelateria', 'quarta-gamma-gdo' ),
		'url'       => samswiss_category_url( 'gastronomia-e-ristorazione' ),
		'theme_img' => 'assets/img/settori/gastronomia-4-gamma.jpeg',
		'alt'       => __( 'Gastronomia, Panetteria e IV Gamma', 'samswiss-child' ),
	),
	array(
		'icon'      => 'fa-drumstick-bite',
		'title'     => __( 'Carne, Pesce e Caseario', 'samswiss-child' ),
		'text'      => __( 'Carne, pesce, formaggi e latticini confezionati.', 'samswiss-child' ),
		'cat_slugs' => array( 'carne-pesce', 'caseario' ),
		'url'       => samswiss_category_url( 'carne-pesce' ),
		'theme_img' => 'assets/img/settori/carne-pesce-caseario.jpeg',
		'alt'       => __( 'Carne, Pesce e Caseario', 'samswiss-child' ),
	),
);
// Cover photos: user-supplied media shipped with the theme (assets/img/settori/),
// falling back to newest published machine post if theme file is absent.
$sector_used_ids = array();
foreach ( $sectors as $sector_key => $sector ) {
	$sector_cover = '';
	if ( ! empty( $sector['theme_img'] ) ) {
		$sector_cover = samswiss_shipped_image( $sector['theme_img'], '', $sector['alt'], 'swiss-solution__photo', 'lazy' );
	} else {
		$sector_posts = get_posts(
			array(
				'post_type'      => 'post',
				'post_status'    => 'publish',
				'posts_per_page' => 1,
				'orderby'        => 'date',
				'order'          => 'DESC',
				'category_name'  => implode( ',', $sector['cat_slugs'] ),
				'post__not_in'   => $sector_used_ids,
				'meta_query'     => array(
					array(
						'key'     => '_thumbnail_id',
						'compare' => 'EXISTS',
					),
				),
			)
		);
		if ( $sector_posts ) {
			$sector_cover      = get_the_post_thumbnail( $sector_posts[0], 'medium_large', array( 'class' => 'swiss-solution__photo' ) );
			$sector_used_ids[] = $sector_posts[0]->ID;
		}
	}
	$sectors[ $sector_key ]['cover'] = $sector_cover;
}
unset( $sector_key, $sector, $sector_cover, $sector_posts, $sector_used_ids );
?>
<!--
DIRECTION CONTRACT (point 58 — supersedes both contracts kept below as history)
THESIS: One supplier covering every stage of a packaging line, laid out as a
corporate brochure the buyer can scan in one pass — refuses both the hairline
Swiss grid and the all-cards glass pilot that preceded it.
OWN-WORLD: Flat white page. Rhythm comes from FULL-BLEED BANDS, not from floating
cards: brand green (#a7c957) for the hero and the closing CTA, a deep green-black
(#1e2418) for the partners band, white for everything between, hairline
rgba(29,29,31,.14) only where a divider is genuinely needed. Square corners, no
shadows, no translucency. Cards exist in exactly ONE row (the solutions), because
that is the one place the client's own reference uses them. Deep green (#46602a)
carries buttons on colour, brand green on white — black was ruled out at point 38.
System font stack, uppercase display, centred section heads over a 68px accent rule.
STORY: The buyer reads the offer, sees the four proof facts, picks their stage of
the line, sees who SAM builds with, then finds either a used machine or an article.
FIRST VIEWPORT: 45/55 split, flush — a green field with the stroke-draw title,
lede and one button, against a full-bleed photo rotation of real machines.
FORM: Client-supplied printed reference layout, translated into brand colour.
Brief-pinned, not rolled from a candidate list.

--- Superseded liquid-glass contract (point 53), for history ---
THESIS: A single maker's whole catalogue as floating glass panels on a soft colour-mesh field.
OWN-WORLD: Apple Liquid Glass — translucent frosted panels, colour-mesh ground over #f5f5f7, rounded corners, soft multi-layer shadows.
FORM: Liquid Glass card system — withdrawn at point 58 on the client's "non voglio schede ovunque".

--- Superseded Swiss contract, for history (point 46's update to it is now moot) ---
THESIS: One Swiss maker covers a food business's entire packaging line; refuses the B2B grid of equal icon-and-text cards.
OWN-WORLD: White paper, #111 ink, #D20001 red as a structural field (not an accent), #003882 navy. One family (Archivo, 400-800). 1px black hairline gutters are the only dividers; no radii, no drop shadows, tabular figures.
STORY: The buyer reads the catalogue's real scale, finds their sector by how much SAM builds for it, and enters that sector's machines.
FIRST VIEWPORT: Left 5/12 red field carries kicker, MACCHINE CONFEZIONATRICI at display scale, the 1989 line and one ruled link. Right 7/12 is the demo video, full-bleed, black caption bottom-left. A four-cell hairline fact strip closes the fold.
FORM: Swiss International Typographic Style, candidate 3 of 7; staging collective-fields-synchronized-array; seed af4d713e.
-->
<main id="primary" class="samswiss-main swiss-page">

	<!-- 1. Hero -->
	<section class="swiss-hero">
		<div class="swiss-hero__thesis">
			<div>
				<?php
				// Stroke-draw + fill-wipe title effect (point 53). Two real, separately
				// translated copies of the same string, not a JS split into characters:
				// splitting into per-letter spans would break `hyphens: auto` below on
				// long German/Russian compounds, a bug already fixed once on this exact
				// title. One unified draw+wipe keeps every language wrapping correctly.
				$hero_title = __( 'Soluzioni per il confezionamento industriale', 'samswiss-child' );
				?>
				<h1 class="sw-display swiss-hero__title">
					<span class="swiss-hero__title-a11y"><?php echo esc_html( $hero_title ); ?></span>
					<span class="swiss-hero__title-stroke" aria-hidden="true"><?php echo esc_html( $hero_title ); ?></span>
					<span class="swiss-hero__title-fill" aria-hidden="true"><?php echo esc_html( $hero_title ); ?></span>
				</h1>
			</div>
			<p class="swiss-hero__lede">
				<?php esc_html_e( 'Dalla singola macchina alla linea completa, studiamo la soluzione più adatta al tuo prodotto e al tuo processo produttivo.', 'samswiss-child' ); ?>
				<br><br>
				<?php esc_html_e( 'Pesatura, confezionamento, movimentazione, fine linea e pallettizzazione, con un unico interlocutore.', 'samswiss-child' ); ?>
			</p>
			<a class="swiss-cta__btn" href="<?php echo esc_url( samswiss_localized_permalink( 569, 'page', 'contatti' ) ?: home_url( '/contatti/' ) ); ?>">
				<span><?php esc_html_e( 'Contattaci per il tuo progetto', 'samswiss-child' ); ?></span>
			</a>
		</div>

		<?php
		// Dedicated machine photos provided by client (FOTO CHE GIRANO IN ALTO A DESTRA),
		// cycling automatically in the hero header.
		$hero_slides = array(
			'assets/img/hero-slides/fabbri-elixa-35.webp',
			'assets/img/hero-slides/vr6-sprinter.png',
			'assets/img/hero-slides/sorma-ro1-120.webp',
			'assets/img/hero-slides/fabbri-toplid-plus.jpg',
			'assets/img/hero-slides/vr7-box.png',
			'assets/img/hero-slides/sorma-cp810-vw5.webp',
			'assets/img/hero-slides/fabbri-elixa-14.jpg',
			'assets/img/hero-slides/vr5.png',
			'assets/img/hero-slides/sorma-rb3-120.webp',
			'assets/img/hero-slides/fabbri-ypsilon.jpg',
			'assets/img/hero-slides/vr4-elektra.png',
			'assets/img/hero-slides/sorma-bts-120.webp',
			'assets/img/hero-slides/fabbri-lari.jpg',
			'assets/img/hero-slides/vr6-genio.png',
			'assets/img/hero-slides/sorma-p14-126.webp',
			'assets/img/hero-slides/fabbri-slideshow.jpg',
			'assets/img/hero-slides/sorma-cp812.webp',
			'assets/img/hero-slides/sorma-w12-elevatore.webp',
			'assets/img/hero-slides/sorma-w12-weigher.webp',
			'assets/img/hero-slides/sorma-g09-126.webp',
			'assets/img/hero-slides/sorma-wd4.webp',
		);
		$hero_fade_step = 3.5;
		?>
		<div class="swiss-hero__media" role="img" aria-label="<?php esc_attr_e( 'Macchine confezionatrici SAM SA', 'samswiss-child' ); ?>">
			<?php foreach ( $hero_slides as $index => $rel_path ) : ?>
				<?php
				$slide_url  = get_stylesheet_directory_uri() . '/' . $rel_path;
				$slide_file = get_stylesheet_directory() . '/' . $rel_path;
				$slide_size = file_exists( $slide_file ) ? @getimagesize( $slide_file ) : false;
				?>
				<img src="<?php echo esc_url( $slide_url ); ?>"
					<?php if ( $slide_size ) : ?>width="<?php echo (int) $slide_size[0]; ?>" height="<?php echo (int) $slide_size[1]; ?>"<?php endif; ?>
					class="swiss-hero__slide<?php echo 0 === $index ? ' is-active' : ''; ?>"
					alt=""
					aria-hidden="true"
					loading="<?php echo 0 === $index ? 'eager' : 'lazy'; ?>"
					fetchpriority="<?php echo 0 === $index ? 'high' : 'low'; ?>"
					decoding="async">
			<?php endforeach; ?>
		</div>
	</section>

	<!-- 2. Catalogue facts — copy taken verbatim from the client's printed flyer,
	     not the previous live-count version (machine total / sector count). -->
	<section class="swiss-facts" aria-label="<?php esc_attr_e( 'Dati SAM SA', 'samswiss-child' ); ?>">
		<div class="swiss-facts__item">
			<span class="swiss-facts__icon" aria-hidden="true"><i class="fas fa-calendar-days"></i></span>
			<span class="swiss-facts__value">1989</span>
			<span class="sw-label swiss-facts__key">
				<?php esc_html_e( 'Anno di fondazione', 'samswiss-child' ); ?><br>
				<?php esc_html_e( '35+ anni di esperienza', 'samswiss-child' ); ?>
			</span>
		</div>
		<div class="swiss-facts__item">
			<span class="swiss-facts__icon" aria-hidden="true"><i class="fas fa-location-dot"></i></span>
			<span class="swiss-facts__value"><?php esc_html_e( 'Svizzera', 'samswiss-child' ); ?></span>
			<span class="sw-label swiss-facts__key"><?php esc_html_e( 'Presenza e assistenza sul territorio', 'samswiss-child' ); ?></span>
		</div>
		<div class="swiss-facts__item">
			<span class="swiss-facts__icon" aria-hidden="true"><i class="fas fa-gear"></i></span>
			<span class="swiss-facts__value"><?php esc_html_e( 'Soluzioni complete', 'samswiss-child' ); ?></span>
			<span class="sw-label swiss-facts__key"><?php esc_html_e( 'Dalla macchina singola alla linea completa', 'samswiss-child' ); ?></span>
		</div>
		<div class="swiss-facts__item swiss-facts__item--photo">
			<?php
			// Same building photo used as the INTRO gateway's fallback backdrop
			// (front-page.php, samswiss_hero_bg_url()) — shipped with the theme,
			// not an uploads/ reference.
			?>
			<img class="swiss-facts__photo" src="<?php echo esc_url( samswiss_hero_bg_url() ); ?>" alt="<?php esc_attr_e( 'Sede SAM SA, Balerna', 'samswiss-child' ); ?>" loading="lazy">
		</div>
	</section>

	<!-- 2.5. Sectors — "Scegli il tuo settore" gateway, reintroduced point 85. -->
	<section class="swiss-sectors" id="settori">
		<div class="sw-sectionhead swiss-sectors__head">
			<h2 class="sw-display swiss-sectors__title"><?php esc_html_e( 'Scegli il tuo settore', 'samswiss-child' ); ?></h2>
		</div>
		<div class="swiss-sectors__grid">
			<?php foreach ( $sectors as $sector ) : ?>
				<a class="swiss-solution" href="<?php echo esc_url( $sector['url'] ); ?>">
					<span class="swiss-solution__icon" aria-hidden="true"><i class="fas <?php echo esc_attr( $sector['icon'] ); ?>"></i></span>
					<span class="swiss-solution__title"><?php echo esc_html( $sector['title'] ); ?></span>
					<span class="swiss-solution__media">
						<?php if ( $sector['cover'] ) : ?>
							<?php echo $sector['cover']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- helper escapes. ?>
						<?php else : ?>
							<span class="swiss-solution__placeholder"><i class="fas <?php echo esc_attr( $sector['icon'] ); ?>" aria-hidden="true"></i></span>
						<?php endif; ?>
					</span>
					<span class="swiss-solution__arrow" aria-hidden="true">&rarr;</span>
				</a>
			<?php endforeach; ?>
		</div>
	</section>

	<!-- 3. Solutions — replaces the sector array on the client's explicit request
	     (icon + title + photo + description cards, from their own reference layout). -->
	<section class="swiss-solutions" id="soluzioni">
		<div class="sw-sectionhead swiss-solutions__head">
			<h2 class="sw-display swiss-solutions__title"><?php esc_html_e( 'Le nostre soluzioni', 'samswiss-child' ); ?></h2>
		</div>

		<div class="swiss-solutions__grid">
			<?php foreach ( $solutions as $sol ) : ?>
				<a class="swiss-solution<?php echo ! empty( $sol['dark'] ) ? ' swiss-solution--dark' : ''; ?>" href="<?php echo esc_url( $sol['url'] ); ?>">
					<span class="swiss-solution__icon" aria-hidden="true"><i class="fas <?php echo esc_attr( $sol['icon'] ); ?>"></i></span>
					<span class="swiss-solution__title"><?php echo esc_html( $sol['title'] ); ?></span>
					<span class="swiss-solution__media">
						<?php if ( ! empty( $sol['img'] ) ) : ?>
							<?php
							if ( ! empty( $sol['theme'] ) ) {
								echo samswiss_shipped_image( $sol['theme'], $sol['img'], $sol['alt'], 'swiss-solution__photo', 'lazy' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- helper escapes.
							} else {
								echo samswiss_uploads_image( $sol['img'], 'medium_large', 'swiss-solution__photo', $sol['alt'], 'lazy' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- helper escapes.
							}
							?>
						<?php else : ?>
							<span class="swiss-solution__placeholder">
								<i class="fas <?php echo esc_attr( $sol['icon'] ); ?>" aria-hidden="true"></i>
								<span class="sw-label"><?php esc_html_e( 'Foto in arrivo', 'samswiss-child' ); ?></span>
							</span>
						<?php endif; ?>
					</span>
					<span class="swiss-solution__text"><?php echo esc_html( $sol['text'] ); ?></span>
					<span class="swiss-solution__arrow" aria-hidden="true">&rarr;</span>
				</a>
			<?php endforeach; ?>
		</div>
	</section>

	<!-- 3b. Technologies — links to the ten dedicated /tecnologie/{slug}/ pages
	     (point 89). Same card component as "Le nostre soluzioni" above (which
	     stays hidden, point 87), reused rather than duplicated. -->
	<section class="swiss-tech-teaser" id="tecnologie">
		<div class="sw-sectionhead swiss-solutions__head">
			<h2 class="sw-display swiss-solutions__title"><?php esc_html_e( 'Cerchi una tecnologia specifica?', 'samswiss-child' ); ?></h2>
			<p><?php esc_html_e( 'Scopri le nostre soluzioni tecnologiche per ogni esigenza produttiva.', 'samswiss-child' ); ?></p>
		</div>

		<div class="swiss-solutions__grid swiss-tech-teaser__grid">
			<?php foreach ( samswiss_tech_catalog() as $tech ) : ?>
				<a class="swiss-solution" href="<?php echo esc_url( $tech['url'] ); ?>">
					<span class="swiss-solution__icon" aria-hidden="true"><i class="fas <?php echo esc_attr( $tech['icon'] ); ?>"></i></span>
					<span class="swiss-solution__title"><?php echo esc_html( $tech['title'] ); ?></span>
					<span class="swiss-solution__media">
						<?php
						$tech_cover = samswiss_tech_image( $tech['cover'], $tech['title'], 'swiss-solution__photo' );
						if ( $tech_cover ) {
							echo $tech_cover; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- helper escapes.
						} else {
							?>
							<span class="swiss-solution__placeholder"><i class="fas <?php echo esc_attr( $tech['icon'] ); ?>" aria-hidden="true"></i></span>
							<?php
						}
						?>
					</span>
					<span class="swiss-solution__text"><?php echo esc_html( $tech['card_text'] ); ?></span>
					<span class="swiss-solution__arrow" aria-hidden="true">&rarr;</span>
				</a>
			<?php endforeach; ?>

			<!-- 6. Card Contattami su WhatsApp (Rafaela Mehmeti) — sostituisce il buco accanto a Fine Linea -->
			<a class="swiss-solution swiss-solution--whatsapp" href="https://wa.me/41764678523" target="_blank" rel="noopener" aria-label="<?php esc_attr_e( 'Contattami su WhatsApp: +41 76 467 85 23', 'samswiss-child' ); ?>">
				<span class="swiss-solution__icon" aria-hidden="true"><i class="fab fa-whatsapp"></i></span>
				<span class="swiss-solution__title"><?php esc_html_e( 'Contattami su WhatsApp', 'samswiss-child' ); ?></span>
				<span class="swiss-solution__media">
					<?php
					echo samswiss_shipped_image(
						'assets/img/contatta-whatsapp.jpg',
						'2026/09/contatta-whatsapp.jpg',
						__( 'Contattami su WhatsApp - Rafaela Mehmeti', 'samswiss-child' ),
						'swiss-solution__photo',
						'lazy'
					); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- helper escapes.
					?>
				</span>
				<span class="swiss-solution__text">
					<?php esc_html_e( 'Hai bisogno di informazioni, un preventivo o assistenza? Scrivimi direttamente su WhatsApp.', 'samswiss-child' ); ?>
				</span>
				<span class="swiss-solution__arrow" aria-hidden="true">&rarr;</span>
			</a>
		</div>
	</section>

	<!-- 4. Partners — dark full-bleed band, per the client's reference layout.
	     The reference also carries a "Scopri tutti i partner" button here; it is
	     NOT built, because no partners page exists on this install to point it at
	     (checked) and a button to nowhere is worse than no button. -->
	<section class="swiss-partners">
		<div class="sw-sectionhead swiss-partners__head">
			<h2 class="sw-display swiss-partners__title"><?php esc_html_e( 'Tecnologie dei migliori partner', 'samswiss-child' ); ?></h2>
			<p class="swiss-partners__lede"><?php esc_html_e( 'Collaboriamo con produttori specializzati per offrire la tecnologia più adatta a ogni fase del processo.', 'samswiss-child' ); ?></p>
		</div>
		<div class="swiss-partners__row">
			<?php foreach ( $partners as $partner ) : ?>
				<a class="swiss-partners__cell" href="<?php echo esc_url( $partner['url'] ); ?>" target="_blank" rel="noopener">
					<?php echo samswiss_partner_image( $partner ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- helper escapes. ?>
				</a>
			<?php endforeach; ?>
		</div>
	</section>

	<!-- 4b. Second Hand + News — two columns, from the client's own reference
	     layout (point 48). Second Hand moved here from right after the solutions
	     cards; News & Approfondimenti is new, with a live preview of the latest 3
	     `articolo-seo` posts (real data, same post type infonews.php already
	     lists in full — this is just the teaser). -->
	<section class="swiss-promo">
		<div class="swiss-promo__col swiss-promo__col--offer">
			<h2 class="sw-display swiss-promo__title"><?php esc_html_e( "Macchine d'occasione", 'samswiss-child' ); ?></h2>
			<p class="swiss-promo__text"><?php esc_html_e( 'Soluzioni selezionate, disponibili in pronta consegna.', 'samswiss-child' ); ?></p>
			<a class="swiss-cta__btn swiss-cta__btn--onpaper" href="<?php echo esc_url( samswiss_category_url( 'second-hand' ) ); ?>">
				<span><?php esc_html_e( 'Scopri le disponibilità', 'samswiss-child' ); ?></span>
				<span aria-hidden="true">&rarr;</span>
			</a>
			<?php if ( $second_hand_cover ) : ?>
				<?php echo $second_hand_cover; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- get_the_post_thumbnail() escapes. ?>
			<?php else : ?>
				<?php echo samswiss_uploads_image( '2021/11/istockphoto-466319552-170667a.jpg', 'medium_large', 'swiss-promo__photo', '', 'lazy' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- helper escapes. ?>
			<?php endif; ?>
		</div>

		<div class="swiss-promo__col swiss-promo__col--news">
			<h2 class="sw-display swiss-promo__title"><?php esc_html_e( 'News & Approfondimenti', 'samswiss-child' ); ?></h2>
			<p class="swiss-promo__text"><?php esc_html_e( 'Tecnologie, applicazioni e novità dal settore del confezionamento industriale.', 'samswiss-child' ); ?></p>
			<a class="swiss-cta__btn swiss-cta__btn--ghost" href="<?php echo esc_url( $infonews_url ); ?>">
				<span><?php esc_html_e( 'Scopri tutti gli articoli', 'samswiss-child' ); ?></span>
				<span aria-hidden="true">&rarr;</span>
			</a>
			<?php if ( $latest_articles ) : ?>
				<div class="swiss-articles">
					<?php foreach ( $latest_articles as $article ) : ?>
						<article class="swiss-article">
							<a class="swiss-article__media" href="<?php echo esc_url( get_permalink( $article ) ); ?>">
								<?php echo get_the_post_thumbnail( $article, 'medium', array( 'class' => 'swiss-article__photo' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- core escapes. ?>
							</a>
							<span class="sw-label swiss-article__date"><?php echo esc_html( get_the_date( '', $article ) ); ?></span>
							<h3 class="swiss-article__title"><a href="<?php echo esc_url( get_permalink( $article ) ); ?>"><?php echo esc_html( get_the_title( $article ) ); ?></a></h3>
							<a class="swiss-article__link" href="<?php echo esc_url( get_permalink( $article ) ); ?>">
								<span><?php esc_html_e( "Leggi l'articolo", 'samswiss-child' ); ?></span>
								<span aria-hidden="true">&rarr;</span>
							</a>
						</article>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
	</section>

	<!-- 5. Contact CTA — replaces the newsletter block on this landing. The
	     signup form itself is not removed from the site: category.php carries its
	     own copy for the product archives, so no functionality is lost here. -->
	<section class="swiss-cta">
		<div class="swiss-cta__inner">
			<div class="swiss-cta__lead">
				<span class="swiss-cta__icon" aria-hidden="true"><i class="far fa-comments"></i></span>
				<h2 class="sw-display swiss-cta__title">
					<?php esc_html_e( 'Hai un progetto?', 'samswiss-child' ); ?><br>
					<?php esc_html_e( 'Parliamone.', 'samswiss-child' ); ?>
				</h2>
			</div>
			<div class="swiss-cta__body">
				<p class="swiss-cta__text">
					<?php esc_html_e( 'Raccontaci il prodotto, il formato e le esigenze produttive.', 'samswiss-child' ); ?><br>
					<?php esc_html_e( 'Studieremo insieme la soluzione più adatta.', 'samswiss-child' ); ?>
				</p>
				<a class="swiss-cta__btn" href="<?php echo esc_url( samswiss_localized_permalink( 569, 'page', 'contatti' ) ?: home_url( '/contatti/' ) ); ?>">
					<span><?php esc_html_e( 'Contattaci ora', 'samswiss-child' ); ?></span>
					<span aria-hidden="true">&rarr;</span>
				</a>
			</div>
		</div>
	</section>

</main>
