<?php
/**
 * ORTOFRUTTA → SORMA GROUP.
 *
 * Commercial presentation, built to the client's own brief of 13 August 2026: big
 * machine photographs, little text per screen, photo/text alternating, "Guarda video"
 * and "Richiedi informazioni" on every block, and on a phone the photograph stays the
 * protagonist.
 *
 * THE PHOTOGRAPHS ARE CUT-OUTS. All nine are transparent PNGs of a machine on no
 * background, so they are shown WHOLE on paper white — never cropped to a band. An
 * earlier version filled fixed boxes with object-fit: cover and cut the machines in
 * half, which is the one thing a machine photograph must not do.
 *
 * MODEL NAMES. AT5S-S120 and RO1-120 are named in the client's copy and are shown.
 * The others are not: their codes come from the image brief only.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$contatti = samswiss_localized_permalink( 569, 'page', 'contatti' ) ?: home_url( '/contatti/' );

/** Video links, from the client's brief. They open Sorma's own pages. */
$video = array(
	'pesatrici' => 'https://www.sormagroup.com/it/devices/phases/borse/pesatrici-divise-per-classi/fruits-tomatoes-garlic?videoPopup=0',
	'agrumi'    => 'https://www.sormagroup.com/it/devices/phases/borse/pesatrici-divise-per-classi/citrus-fruits?videoPopup=0',
	'ortaggi'   => 'https://www.sormagroup.com/it/devices/phases/borse/pesatrici-divise-per-classi/vegetables?videoPopup=0',
	'grappolo'  => 'https://www.sormagroup.com/it/devices/phases/borse/pesatrici-divise-per-classi/cluster-fruit-it-en-it?videoPopup=0',
	'rete_auto' => 'https://www.sormagroup.com/it/devices/phases/borse/retinatrici-1/rb-2-120-b-1?videoPopup=0',
	'ro1'       => 'https://www.sormagroup.com/it/devices/phases/borse/retinatrici-1/ro-1-120-1?videoPopup=0',
	'fine_linea' => 'https://sormagroup.com/it/devices/phases/pallettizzazione-e-reggiatura/reggiatrici-1/rm-8-124-a?videoPopup=0',
);

/**
 * Photographs. SHIPPED WITH THE THEME, with the library as fallback.
 *
 * They live in `assets/img/sorma/` so they travel in the zip: uploads/ does not, and a
 * page whose nine pictures all sit in the media library of one laptop arrives on the
 * live server as nine broken images. Re-saved at 1400px maximum — 12.7 MB down to
 * 3.9 MB — with the transparency intact.
 *
 * The uploads fallback keeps the month folder on purpose: `image001.png` and
 * `image007.png` also exist from May 2020 — two 121x108 pictures of disposable plates
 * from the packaging catalogue — so a lookup by bare filename lands on a paper plate.
 */
$img = array(
	'pesatrici'  => '2026/08/image007.png',
	'agrumi'     => '2026/08/image008.png',
	'ortaggi'    => '2026/08/image017.png',
	'grappolo'   => '2026/08/image013.png',
	'reti_intro' => '2026/08/image014.png',
	'rete_auto'  => '2026/08/image011.png',
	'at5s'       => '2026/08/image016.png',
	'ro1'        => '2026/08/image012.png',
	'linea'      => '2026/08/image001.png',
);

$sections = array(
	'pesatrici'   => __( 'Pesatrici', 'samswiss-child' ),
	'retinatrici' => __( 'Retinatrici', 'samswiss-child' ),
	'fine-linea'  => __( 'Fine linea & pallettizzazione', 'samswiss-child' ),
	'linee'       => __( 'Linee complete', 'samswiss-child' ),
);

/** The two actions, printed together wherever the brief asks for them. */
$actions = function ( $video_url ) use ( $contatti ) {
	echo '<div class="sorma-actions">';
	if ( $video_url ) {
		printf(
			'<a class="swiss-cta__btn swiss-cta__btn--ghost" href="%s" target="_blank" rel="noopener">%s</a>',
			esc_url( $video_url ),
			esc_html__( 'Guarda video', 'samswiss-child' )
		);
	}
	printf(
		'<a class="swiss-cta__btn swiss-cta__btn--onpaper" href="%s">%s</a>',
		esc_url( $contatti ),
		esc_html__( 'Richiedi informazioni', 'samswiss-child' )
	);
	echo '</div>';
};
?>
<main id="primary" class="samswiss-main swiss-page sorma-page">

	<!-- 1. Opening -->
	<section class="sorma-hero">
		<div class="sorma-hero__inner">
			<p class="sw-label sorma-hero__kicker"><?php esc_html_e( 'Ortofrutta · Sorma Group', 'samswiss-child' ); ?></p>
			<h1 class="sw-display sorma-hero__title"><?php esc_html_e( 'Soluzioni complete per il settore ortofrutticolo', 'samswiss-child' ); ?></h1>
			<p class="sorma-hero__lede"><?php esc_html_e( 'SAM propone sul mercato svizzero le tecnologie Sorma Group per creare linee complete, efficienti e su misura per pesatura, confezionamento e pallettizzazione.', 'samswiss-child' ); ?></p>
			<p class="sorma-hero__lede"><?php esc_html_e( 'Dalla singola macchina alla linea completa, studiamo la configurazione più adatta in funzione del prodotto, del formato di confezionamento e della capacità produttiva richiesta.', 'samswiss-child' ); ?></p>
			<a class="swiss-cta__btn" href="<?php echo esc_url( $contatti ); ?>"><?php esc_html_e( 'Richiedi informazioni', 'samswiss-child' ); ?></a>
		</div>
	</section>

	<?php // Internal navigation. Plain anchors, so it works with JavaScript off. ?>
	<nav class="sorma-nav" aria-label="<?php esc_attr_e( 'Sezioni di questa pagina', 'samswiss-child' ); ?>">
		<?php foreach ( $sections as $anchor => $label ) : ?>
			<a class="sorma-nav__item" href="#<?php echo esc_attr( $anchor ); ?>"><?php echo esc_html( $label ); ?></a>
		<?php endforeach; ?>
	</nav>

	<!-- 2. PESATRICI -->
	<section class="sorma-section" id="pesatrici">
		<header class="sorma-section__head">
			<p class="sw-label sorma-section__index">01 &middot; <?php esc_html_e( 'Pesatrici', 'samswiss-child' ); ?></p>
			<h2 class="sw-display sorma-section__title"><?php esc_html_e( 'Precisione anche sui prodotti più delicati', 'samswiss-child' ); ?></h2>
		</header>

		<div class="sorma-row">
			<figure class="sorma-row__media">
				<?php echo samswiss_shipped_image( 'assets/img/sorma/' . basename( $img['pesatrici'] ), $img['pesatrici'], __( 'Pesatrice Sorma per prodotti ortofrutticoli', 'samswiss-child' ), 'sorma-shot', 'eager' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- helper escapes. ?>
			</figure>
			<div class="sorma-row__body">
				<h3 class="sorma-row__title"><?php esc_html_e( 'Precisione, delicatezza ed efficienza', 'samswiss-child' ); ?></h3>
				<p class="sorma-row__text"><?php esc_html_e( 'Soluzioni di pesatura studiate in funzione del prodotto, del calibro, del peso richiesto e della produttività.', 'samswiss-child' ); ?></p>
				<p class="sorma-row__text"><?php esc_html_e( 'Sorma dispone di diverse tipologie di pesatrici, comprese soluzioni a canali vibranti e sistemi dinamici, per adattarsi alle caratteristiche dei diversi prodotti ortofrutticoli.', 'samswiss-child' ); ?></p>
				<p class="sorma-row__text"><?php esc_html_e( 'La produttività dei 5 modelli — senza discriminare la delicatezza — è modulabile a partire dalla scelta dei modelli a 12 o 14 canali e dalla possibilità di installare i precontenitori. A seconda del modello sono disponibili con 2 o 4 nastri di scarico, che alimentano altrettante confezionatrici. L\'altissima precisione del peso rende possibile realizzare cestini o borse da 125 g fino a 2,0 kg.', 'samswiss-child' ); ?></p>
				<?php $actions( $video['pesatrici'] ); ?>
			</div>
		</div>

		<div class="sorma-row sorma-row--flip">
			<figure class="sorma-row__media">
				<?php echo samswiss_shipped_image( 'assets/img/sorma/' . basename( $img['agrumi'] ), $img['agrumi'], __( 'Pesatrice Sorma per agrumi', 'samswiss-child' ), 'sorma-shot', 'lazy' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- helper escapes. ?>
			</figure>
			<div class="sorma-row__body">
				<p class="sw-label sorma-row__kicker"><?php esc_html_e( 'Agrumi', 'samswiss-child' ); ?></p>
				<h3 class="sorma-row__title"><?php esc_html_e( 'Delicatezza e flessibilità per ogni varietà', 'samswiss-child' ); ?></h3>
				<p class="sorma-row__text"><?php esc_html_e( 'Arance, limoni, mandarini, lime e pompelmi hanno caratteristiche molto diverse per forma, calibro e delicatezza. Per questo è importante scegliere il sistema di pesatura più adatto al prodotto da lavorare.', 'samswiss-child' ); ?></p>
				<p class="sorma-row__text"><?php esc_html_e( 'Sorma propone diverse configurazioni dedicate agli agrumi, comprese soluzioni dinamiche e a canali vibranti.', 'samswiss-child' ); ?></p>
				<p class="sw-label sorma-row__listlabel"><?php esc_html_e( 'Ideale per', 'samswiss-child' ); ?></p>
				<ul class="sorma-tags">
					<?php foreach ( array( 'Arance', 'Mandarini', 'Limoni', 'Lime', 'Pompelmi' ) as $tag ) : ?>
						<li><?php echo esc_html( $tag ); ?></li>
					<?php endforeach; ?>
				</ul>
				<?php $actions( $video['agrumi'] ); ?>
			</div>
		</div>

		<div class="sorma-row">
			<figure class="sorma-row__media">
				<?php echo samswiss_shipped_image( 'assets/img/sorma/' . basename( $img['ortaggi'] ), $img['ortaggi'], __( 'Linea Sorma per pesatura e confezionamento ortaggi', 'samswiss-child' ), 'sorma-shot', 'lazy' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- helper escapes. ?>
			</figure>
			<div class="sorma-row__body">
				<p class="sw-label sorma-row__kicker"><?php esc_html_e( 'Ortaggi', 'samswiss-child' ); ?></p>
				<h3 class="sorma-row__title"><?php esc_html_e( 'Soluzioni di pesatura per ortaggi e prodotti sfusi', 'samswiss-child' ); ?></h3>
				<p class="sorma-row__text"><?php esc_html_e( 'Configurazioni dedicate a patate, cipolle, carote, aglio, scalogno e altri ortaggi, selezionate in funzione del prodotto, del peso della confezione e della produttività richiesta.', 'samswiss-child' ); ?></p>
				<p class="sorma-row__text"><?php esc_html_e( 'La gamma comprende applicazioni per patate, cipolle, carote, castagne, cavoletti, peperoni, rape e altri prodotti.', 'samswiss-child' ); ?></p>
				<?php $actions( $video['ortaggi'] ); ?>
			</div>
		</div>

		<div class="sorma-row sorma-row--flip">
			<figure class="sorma-row__media">
				<?php echo samswiss_shipped_image( 'assets/img/sorma/' . basename( $img['grappolo'] ), $img['grappolo'], __( 'Pesatrice Sorma per pomodori a grappolo', 'samswiss-child' ), 'sorma-shot', 'lazy' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- helper escapes. ?>
			</figure>
			<div class="sorma-row__body">
				<p class="sw-label sorma-row__kicker"><?php esc_html_e( 'Prodotti a grappolo', 'samswiss-child' ); ?></p>
				<h3 class="sorma-row__title"><?php esc_html_e( 'Pesatrice per prodotti a grappolo', 'samswiss-child' ); ?></h3>
				<p class="sorma-row__text"><?php esc_html_e( 'Principio basato sul pre-riempimento manuale dei cestini e sulla ricerca automatica della migliore combinazione necessaria per raggiungere il peso impostato.', 'samswiss-child' ); ?></p>
				<?php $actions( $video['grappolo'] ); ?>
			</div>
		</div>

		<aside class="sorma-ask">
			<p class="sorma-ask__q"><?php esc_html_e( 'Non sai quale pesatrice scegliere?', 'samswiss-child' ); ?></p>
			<p class="sorma-ask__a"><?php esc_html_e( 'Partiamo dal tuo prodotto. Indicaci prodotto, calibro, peso della confezione e capacità produttiva richiesta: individueremo insieme la configurazione più adatta.', 'samswiss-child' ); ?></p>
			<a class="swiss-cta__btn swiss-cta__btn--onpaper" href="<?php echo esc_url( $contatti ); ?>"><?php esc_html_e( 'Richiedi una consulenza', 'samswiss-child' ); ?></a>
		</aside>
	</section>

	<!-- 3. RETINATRICI -->
	<section class="sorma-section" id="retinatrici">
		<header class="sorma-section__head">
			<p class="sw-label sorma-section__index">02 &middot; <?php esc_html_e( 'Retinatrici', 'samswiss-child' ); ?></p>
			<h2 class="sw-display sorma-section__title"><?php esc_html_e( 'Confezionamento in rete semplice, veloce e versatile', 'samswiss-child' ); ?></h2>
			<p class="sorma-section__lede"><?php esc_html_e( 'Le retinatrici Sorma sono disponibili in differenti configurazioni per il confezionamento di prodotti ortofrutticoli in rete. La gamma comprende soluzioni automatiche per diversi prodotti, formati e materiali di rete.', 'samswiss-child' ); ?></p>
		</header>

		<?php // The packed result, not a machine: it says at a glance what these produce. ?>
		<figure class="sorma-plate">
			<?php echo samswiss_shipped_image( 'assets/img/sorma/' . basename( $img['reti_intro'] ), $img['reti_intro'], __( 'Limoni confezionati in rete', 'samswiss-child' ), 'sorma-shot sorma-shot--plate', 'lazy' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- helper escapes. ?>
		</figure>

		<div class="sorma-row">
			<figure class="sorma-row__media">
				<?php echo samswiss_shipped_image( 'assets/img/sorma/' . basename( $img['rete_auto'] ), $img['rete_auto'], __( 'Retinatrice automatica verticale Sorma', 'samswiss-child' ), 'sorma-shot', 'lazy' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- helper escapes. ?>
			</figure>
			<div class="sorma-row__body">
				<h3 class="sorma-row__title"><?php esc_html_e( 'Confezionamento automatico in rete', 'samswiss-child' ); ?></h3>
				<p class="sorma-row__text"><?php esc_html_e( 'Clipsatrice automatica verticale a due tubi portarete diametro 225 mm, adatta a effettuare la chiusura di reti tubolari con agrumi, patate, cipolle e prodotti similari. Utilizza reggetta metallica avvolta in bobine.', 'samswiss-child' ); ?></p>
				<p class="sorma-row__text"><?php esc_html_e( 'Provvista di supporto bobina per l\'inserimento del nastrino da fissare nella retina a mo\' di manico, di pannello di controllo con touch screen 7" a colori e di kit per la lavorazione delle cipolle. Stampante di etichette a bandiera e clip to clip.', 'samswiss-child' ); ?></p>
				<p class="sorma-row__text"><?php esc_html_e( 'Peso delle confezioni: da 0,5 a 3 kg. Optional: dispositivo per il cambio tubo automatico a fine rete.', 'samswiss-child' ); ?></p>
				<?php $actions( $video['rete_auto'] ); ?>
			</div>
		</div>

		<div class="sorma-row sorma-row--flip">
			<figure class="sorma-row__media">
				<?php echo samswiss_shipped_image( 'assets/img/sorma/' . basename( $img['at5s'] ), $img['at5s'], __( 'Retinatrice Sorma AT5S-S120', 'samswiss-child' ), 'sorma-shot', 'lazy' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- helper escapes. ?>
			</figure>
			<div class="sorma-row__body">
				<p class="sw-label sorma-row__kicker">AT5S-S120</p>
				<h3 class="sorma-row__title"><?php esc_html_e( 'Soluzione automatica per cipolle, aglio e scalogno', 'samswiss-child' ); ?></h3>
				<p class="sorma-row__text"><?php esc_html_e( 'Clipsatrice automatica per il confezionamento in linea a 3 o 4 teste. Lavora indistintamente reti tubolari estruse, tessute, in cellulosa o in cotone. Disponibile anche nella versione clip to clip.', 'samswiss-child' ); ?></p>
				<?php $actions( '' ); ?>
			</div>
		</div>

		<div class="sorma-row">
			<figure class="sorma-row__media">
				<?php echo samswiss_shipped_image( 'assets/img/sorma/' . basename( $img['ro1'] ), $img['ro1'], __( 'Retinatrice Sorma RO1-120', 'samswiss-child' ), 'sorma-shot', 'lazy' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- helper escapes. ?>
			</figure>
			<div class="sorma-row__body">
				<p class="sw-label sorma-row__kicker">RO1-120</p>
				<h3 class="sorma-row__title"><?php esc_html_e( 'Confezionamento in rete anche per prodotti delicati', 'samswiss-child' ); ?></h3>
				<p class="sorma-row__text"><?php esc_html_e( 'Clipsatrice delicata orizzontale: effettua automaticamente la chiusura di reti tubolari contenenti prodotti ortofrutticoli delicati come mele, pomodori, melanzane e zucchine. Tubo portarete diametro 250 mm, reggetta metallica avvolta in bobine.', 'samswiss-child' ); ?></p>
				<p class="sorma-row__text"><?php esc_html_e( 'Provvista inoltre di supporto bobina per l\'inserimento del nastrino da fissare nella retina da grappa a grappa con funzione di manico, e di stampante di etichette a bandiera. Peso delle confezioni: da 0,5 a 2 kg.', 'samswiss-child' ); ?></p>
				<?php $actions( $video['ro1'] ); ?>
			</div>
		</div>
	</section>

	<!-- 4. FINE LINEA & PALLETTIZZAZIONE -->
	<section class="sorma-section" id="fine-linea">
		<header class="sorma-section__head">
			<p class="sw-label sorma-section__index">03 &middot; <?php esc_html_e( 'Fine linea & pallettizzazione', 'samswiss-child' ); ?></p>
			<h2 class="sw-display sorma-section__title"><?php esc_html_e( 'Completiamo la linea. Automatizziamo anche l\'ultima fase.', 'samswiss-child' ); ?></h2>
		</header>

		<div class="sorma-split">
			<div class="sorma-split__prose">
				<p class="sorma-row__text"><?php esc_html_e( 'Una linea efficiente non termina con il confezionamento. SAM propone soluzioni complete di fine linea per automatizzare la movimentazione, la gestione delle confezioni e la pallettizzazione del prodotto finito.', 'samswiss-child' ); ?></p>
				<p class="sorma-row__text"><?php esc_html_e( 'Grazie alle tecnologie Sorma Group possiamo integrare sistemi di trasporto, pallettizzatori automatici, reggiatura e gestione del pallet, creando un flusso continuo dalla confezionatrice fino al pallet pronto per la spedizione.', 'samswiss-child' ); ?></p>
				<p class="sorma-row__text"><?php esc_html_e( 'Le soluzioni vengono studiate in funzione degli spazi disponibili, dei formati lavorati e della capacità produttiva richiesta, con l\'obiettivo di ridurre le operazioni manuali, ottimizzare i tempi e rendere il processo più efficiente e sicuro.', 'samswiss-child' ); ?></p>
				<p class="sorma-row__text"><?php esc_html_e( 'Dalla singola macchina al fine linea completamente automatizzato, SAM segue il progetto fino all\'ultima fase della produzione.', 'samswiss-child' ); ?></p>
				<?php $actions( $video['fine_linea'] ); ?>
			</div>
			<div class="sorma-split__list">
				<p class="sw-label sorma-row__listlabel"><?php esc_html_e( 'Soluzioni disponibili', 'samswiss-child' ); ?></p>
				<ul class="sorma-list">
					<?php
					foreach ( array(
						__( 'Sistemi di trasporto e movimentazione', 'samswiss-child' ),
						__( 'Pallettizzatori automatici a pianale o a pinza', 'samswiss-child' ),
						__( 'Gestione automatica dei pallet', 'samswiss-child' ),
						__( 'Sistemi di reggiatura', 'samswiss-child' ),
						__( 'Integrazione con le linee di confezionamento', 'samswiss-child' ),
						__( 'Soluzioni personalizzate in base al layout produttivo', 'samswiss-child' ),
					) as $item ) :
						?>
						<li><?php echo esc_html( $item ); ?></li>
					<?php endforeach; ?>
				</ul>
				<p class="sorma-split__claim"><?php esc_html_e( 'Dalla confezione al pallet: un unico progetto, un unico interlocutore.', 'samswiss-child' ); ?></p>
			</div>
		</div>
	</section>

	<!-- 5. LINEE COMPLETE -->
	<section class="sorma-section" id="linee">
		<header class="sorma-section__head">
			<p class="sw-label sorma-section__index">04 &middot; <?php esc_html_e( 'Linee complete', 'samswiss-child' ); ?></p>
			<h2 class="sw-display sorma-section__title"><?php esc_html_e( 'Dalla singola macchina all\'impianto completo', 'samswiss-child' ); ?></h2>
		</header>

		<figure class="sorma-plate">
			<?php echo samswiss_shipped_image( 'assets/img/sorma/' . basename( $img['linea'] ), $img['linea'], __( 'Linea completa Sorma per il confezionamento ortofrutticolo', 'samswiss-child' ), 'sorma-shot sorma-shot--plate', 'lazy' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- helper escapes. ?>
		</figure>

		<div class="sorma-split">
			<div class="sorma-split__prose">
				<p class="sorma-row__text"><?php esc_html_e( 'SAM progetta e propone linee complete e integrate per la lavorazione, la pesatura, il confezionamento e il fine linea, costruite sulle reali esigenze produttive del cliente.', 'samswiss-child' ); ?></p>
				<p class="sorma-row__text"><?php esc_html_e( 'Non ci limitiamo alla fornitura del singolo macchinario: analizziamo prodotto, capacità produttiva, formati, spazi disponibili e obiettivi di automazione per definire la configurazione più adatta.', 'samswiss-child' ); ?></p>
				<p class="sorma-row__text"><?php esc_html_e( 'L\'obiettivo è creare un processo continuo, efficiente e perfettamente coordinato, riducendo le movimentazioni manuali e semplificando la gestione dell\'intera produzione. Un solo interlocutore, dalla progettazione all\'avviamento della linea.', 'samswiss-child' ); ?></p>
			</div>
			<div class="sorma-split__list">
				<p class="sw-label sorma-row__listlabel"><?php esc_html_e( 'Integriamo in un unico progetto', 'samswiss-child' ); ?></p>
				<ul class="sorma-list">
					<?php
					foreach ( array(
						__( 'Sistemi di alimentazione e movimentazione', 'samswiss-child' ),
						__( 'Calibratura e selezione', 'samswiss-child' ),
						__( 'Pesatura', 'samswiss-child' ),
						__( 'Confezionamento', 'samswiss-child' ),
						__( 'Controllo e automazione dei flussi', 'samswiss-child' ),
						__( 'Fine linea e pallettizzazione', 'samswiss-child' ),
					) as $item ) :
						?>
						<li><?php echo esc_html( $item ); ?></li>
					<?php endforeach; ?>
				</ul>
			</div>
		</div>

		<aside class="sorma-ask sorma-ask--wide">
			<p class="sorma-ask__q"><?php esc_html_e( 'Ogni linea nasce dalle vostre esigenze', 'samswiss-child' ); ?></p>
			<p class="sorma-ask__a"><?php esc_html_e( 'Ogni prodotto e ogni stabilimento richiedono una soluzione diversa. Per questo SAM studia configurazioni modulari e personalizzabili, che possono partire da una singola macchina ed evolvere nel tempo fino a una linea completamente automatizzata.', 'samswiss-child' ); ?></p>
			<p class="sorma-ask__a"><?php esc_html_e( 'Raccontaci il tuo progetto. Costruiamo insieme la linea più adatta alla tua produzione.', 'samswiss-child' ); ?></p>
			<a class="swiss-cta__btn swiss-cta__btn--onpaper" href="<?php echo esc_url( $contatti ); ?>"><?php esc_html_e( 'Richiedi informazioni', 'samswiss-child' ); ?></a>
		</aside>
	</section>

	<!-- 6. Closing band -->
	<section class="sorma-close">
		<div class="sorma-close__inner">
			<h2 class="sw-display sorma-close__title"><?php esc_html_e( 'Un unico interlocutore in Svizzera', 'samswiss-child' ); ?></h2>
			<ul class="sorma-close__list">
				<?php
				foreach ( array(
					__( 'Consulenza', 'samswiss-child' ),
					__( 'Progettazione', 'samswiss-child' ),
					__( 'Fornitura', 'samswiss-child' ),
					__( 'Installazione', 'samswiss-child' ),
					__( 'Formazione', 'samswiss-child' ),
					__( 'Assistenza tecnica', 'samswiss-child' ),
					__( 'Ricambi', 'samswiss-child' ),
					__( 'Materiali di consumo', 'samswiss-child' ),
				) as $service ) :
					?>
					<li><?php echo esc_html( $service ); ?></li>
				<?php endforeach; ?>
			</ul>
			<p class="sorma-close__text"><?php esc_html_e( 'SAM segue il cliente dalla scelta della tecnologia fino al post-vendita, con assistenza tecnica e fornitura dei materiali necessari alla continuità della produzione.', 'samswiss-child' ); ?></p>
			<p class="sorma-close__ask"><?php esc_html_e( 'Hai un progetto? Raccontaci cosa devi confezionare e quale risultato vuoi ottenere. Studieremo insieme la soluzione più adatta.', 'samswiss-child' ); ?></p>
			<?php // Point 68: closing band went back to a dark field (matching the home page's Partners band), so this is the base swiss-cta__btn again — not --onpaper, which would read as dark-on-dark here. ?>
			<a class="swiss-cta__btn sorma-cta--big" href="<?php echo esc_url( $contatti ); ?>"><?php esc_html_e( 'Contattaci', 'samswiss-child' ); ?></a>
		</div>
	</section>

</main>
