<?php
/**
 * Landing page: "Imballaggi e monouso" (page #215).
 * Hero + two category image-boxes + latest products + CTA.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$uploads  = trailingslashit( wp_get_upload_dir()['baseurl'] );
$shop_url = function_exists( 'ticinoweb_get_shop_url' ) ? ticinoweb_get_shop_url() : home_url( '/shop/' );

$boxes = array(
	array(
		'img'   => '2023/02/healthy-food-lunch-in-kraft-paper-carton-eco-friendly-box-disposable-bowl-packaging-container.jpg',
		'title' => __( 'Imballaggi e Monouso', 'samswiss-child' ),
		'url'   => samswiss_localized_permalink( 1270, 'product_cat', 'imballaggi-e-monouso-categoria' ),
	),
	array(
		'img'   => '2023/02/selection-of-different-ice-cream-scoops.jpg',
		'title' => __( 'Ingredienti gelaterie e pasticcerie', 'samswiss-child' ),
		'url'   => samswiss_localized_permalink( 1301, 'product_cat', 'ingredienti-gelaterie-e-pasticcerie-categoria' ),
	),
);
?>
<main id="primary" class="samswiss-main samswiss-landing samswiss-landing-imballaggi">

	<section class="samswiss-im-hero">
		<div class="samswiss-im-hero__thesis">
			<p class="sw-label">S.A.M. SA</p>
			<h1 class="samswiss-im-title"><?php esc_html_e( 'Imballaggi e Monouso & Ingredienti gelaterie e pasticcerie', 'samswiss-child' ); ?></h1>
			<a class="samswiss-btn samswiss-btn--red" href="<?php echo esc_url( $shop_url ); ?>"><?php esc_html_e( 'Acquistare Ora', 'samswiss-child' ); ?></a>
		</div>
		<div class="samswiss-im-hero__media" style="background-image:url('<?php echo esc_url( samswiss_hero_bg_url() ); ?>');" aria-hidden="true"></div>
	</section>

	<section class="samswiss-im-boxes">
		<div class="samswiss-container samswiss-im-box-grid">
			<?php foreach ( $boxes as $b ) : ?>
				<a class="samswiss-im-box" href="<?php echo esc_url( $b['url'] ); ?>">
					<span class="samswiss-im-box-media" style="background-image:url('<?php echo esc_url( $uploads . $b['img'] ); ?>');"></span>
					<span class="samswiss-im-box-title">
						<span><?php echo esc_html( $b['title'] ); ?></span>
						<span aria-hidden="true">&rarr;</span>
					</span>
				</a>
			<?php endforeach; ?>
		</div>
	</section>

	<section class="samswiss-im-latest">
		<div class="samswiss-container">
			<h2 class="samswiss-section-title"><?php esc_html_e( 'ULTIMI ARRIVI', 'samswiss-child' ); ?></h2>
			<?php echo do_shortcode( '[products limit="4" columns="4" orderby="date" order="DESC" visibility="visible"]' ); ?>
			<div class="samswiss-im-cta">
				<a class="samswiss-btn samswiss-btn--red" href="<?php echo esc_url( $shop_url ); ?>"><?php esc_html_e( 'Acquistare ora', 'samswiss-child' ); ?></a>
			</div>
		</div>
	</section>

</main>
