<?php
/**
 * Landing page: "SECOND HAND / Machines d'occasion" (page #5886).
 * Hero + used-machines posts listing.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$uploads = trailingslashit( wp_get_upload_dir()['baseurl'] );
?>
<main id="primary" class="samswiss-main samswiss-landing samswiss-landing-secondhand">

	<section class="samswiss-sh-hero">
		<div class="samswiss-sh-hero__thesis">
			<p class="sw-label"><?php esc_html_e( "MACCHINE D'OCCASIONE", 'samswiss-child' ); ?></p>
			<h1 class="samswiss-sh-title"><?php esc_html_e( 'SAM SA Automatic Machine Systems', 'samswiss-child' ); ?></h1>
			<p class="samswiss-sh-sub"><?php esc_html_e( "Nel 1989 un gruppo di giovani tecnici ha iniziato la costruzione delle prime macchine confezionatrici e dei primi automatismi industriali MADE IN SAM.", 'samswiss-child' ); ?></p>
		</div>
		<div class="samswiss-sh-hero__media" style="background-image:url('<?php echo esc_url( $uploads . '2021/11/istockphoto-466319552-170667a.jpg' ); ?>');" aria-hidden="true"></div>
	</section>

	<section class="samswiss-news-list">
		<div class="samswiss-container">
			<h2 class="samswiss-section-title"><?php esc_html_e( 'MACCHINE D\'OCCASIONE', 'samswiss-child' ); ?></h2>
			<?php
			$paged = max( 1, (int) get_query_var( 'paged' ), (int) get_query_var( 'page' ) );
			$sh    = new WP_Query( array(
				'post_type'      => 'post',
				'post_status'    => 'publish',
				'posts_per_page' => 9,
				'paged'          => $paged,
				'category_name'  => 'second-hand',
			) );
			if ( $sh->have_posts() ) : ?>
				<div class="samswiss-promos-grid">
					<?php while ( $sh->have_posts() ) : $sh->the_post(); ?>
						<article class="samswiss-promo-card">
							<a href="<?php the_permalink(); ?>" class="samswiss-promo-media"><?php if ( has_post_thumbnail() ) { the_post_thumbnail( 'medium_large' ); } ?></a>
							<div class="samswiss-promo-body">
								<h3 class="samswiss-promo-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
								<div class="samswiss-promo-excerpt"><?php the_excerpt(); ?></div>
							</div>
						</article>
					<?php endwhile; ?>
				</div>
				<div class="samswiss-pagination">
					<?php echo wp_kses_post( paginate_links( array( 'total' => $sh->max_num_pages, 'current' => $paged ) ) ); ?>
				</div>
				<?php wp_reset_postdata(); ?>
			<?php else : ?>
				<p><?php esc_html_e( 'Nessuna macchina disponibile al momento.', 'samswiss-child' ); ?></p>
			<?php endif; ?>
		</div>
	</section>
</main>
