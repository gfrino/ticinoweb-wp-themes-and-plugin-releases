<?php
/**
 * Landing page: "InfoNews" (page #2225) — heading + news posts grid.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<main id="primary" class="samswiss-main samswiss-landing samswiss-landing-infonews">
	<header class="samswiss-page-header">
		<div class="samswiss-container">
			<p class="sw-label">S.A.M. SA</p>
			<h1 class="samswiss-page-title"><?php the_title(); ?></h1>
		</div>
	</header>

	<section class="samswiss-news-list">
		<div class="samswiss-container">
			<?php
			$paged = max( 1, (int) get_query_var( 'paged' ), (int) get_query_var( 'page' ) );
			// `articolo-seo`, not `post`. On this install the machines ARE the posts —
			// all 342 of them — so a page called InfoNews was listing the catalogue and
			// hiding the 65 editorial pieces that actually are news: fairs ("SAM a
			// Macfrut 2026"), installations, technical explainers. They live in
			// `articolo-seo`, which the client can write and edit from wp-admin without
			// touching the catalogue. Recorded as open point 3d until the client asked
			// for a section they could keep up themselves; this is that decision.
			$news  = new WP_Query( array(
				'post_type'      => 'articolo-seo',
				'post_status'    => 'publish',
				'posts_per_page' => 9,
				'paged'          => $paged,
			) );
			if ( $news->have_posts() ) : ?>
				<div class="samswiss-promos-grid">
					<?php while ( $news->have_posts() ) : $news->the_post(); ?>
						<article class="samswiss-promo-card">
							<a href="<?php the_permalink(); ?>" class="samswiss-promo-media"><?php if ( has_post_thumbnail() ) { the_post_thumbnail( 'medium_large' ); } ?></a>
							<div class="samswiss-promo-body">
								<span class="samswiss-promo-date"><?php echo esc_html( get_the_date() ); ?></span>
								<h2 class="samswiss-promo-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
								<div class="samswiss-promo-excerpt"><?php the_excerpt(); ?></div>
							</div>
						</article>
					<?php endwhile; ?>
				</div>
				<div class="samswiss-pagination">
					<?php echo wp_kses_post( paginate_links( array( 'total' => $news->max_num_pages, 'current' => $paged ) ) ); ?>
				</div>
				<?php wp_reset_postdata(); ?>
			<?php else : ?>
				<p><?php esc_html_e( 'Nessuna notizia disponibile al momento.', 'samswiss-child' ); ?></p>
			<?php endif; ?>
		</div>
	</section>
</main>
