<?php
/**
 * Landing page: "Imballaggi e Consumabili" (page /imballaggi-e-consumabili/).
 *
 * Materiali di consumo professionali, packaging alimentare tecnico e
 * soluzioni ecologiche a base carta in partnership con GB Bernucci.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$hero_bg    = samswiss_hero_bg_url();
$contatti   = samswiss_localized_permalink( 569, 'page', 'contatti' ) ?: home_url( '/contatti/' );
$contact_url = add_query_arg( 'arg', 'materiali-di-consumo', $contatti );
$whatsapp_url = 'https://wa.me/41764678523';
$sorma_url    = samswiss_localized_permalink( 26334, 'page', 'sorma-group' ) ?: home_url( '/sorma-group/' );

/*
 * Pillole di navigazione rapida sotto l'hero: ogni tipologia rimanda alla
 * sezione della pagina (o del sito) in cui viene trattata.
 */
$material_pills = array(
	array( 'label' => __( 'Film estensibili & barriera', 'samswiss-child' ),         'url' => '#gamma' ),
	array( 'label' => __( 'Reti e materiali complementari', 'samswiss-child' ),      'url' => $sorma_url . '#retinatrici' ),
	array( 'label' => __( 'Vaschette e supporti tecnici', 'samswiss-child' ),        'url' => '#bernucci' ),
	array( 'label' => __( 'Buste sottovuoto', 'samswiss-child' ),                    'url' => '#gamma' ),
	array( 'label' => __( 'Etichette e tracciabilità', 'samswiss-child' ),           'url' => home_url( '/category/packaging-lines/pesatura-ed-etichettatura/' ) ),
	array( 'label' => __( 'Soluzioni personalizzate', 'samswiss-child' ),            'url' => '#consulenza' ),
	array( 'label' => __( 'Soluzioni a base carta e cellulosa', 'samswiss-child' ),  'url' => '#bernucci', 'eco' => true ),
);

$bernucci_solutions = array(
	array(
		'name'      => 'SlimFresh',
		'tag'       => __( 'Supporto a base carta · Skin', 'samswiss-child' ),
		'desc'      => __( 'Supporto a base carta per confezionamento Skin, completamente personalizzabile e riciclabile nella carta. Indicato in particolare per carne, pesce e formaggi.', 'samswiss-child' ),
		'apps'      => __( 'Ideale per: Carne fresca, pesce porzionato, formaggi e salumi.', 'samswiss-child' ),
		'icon'      => 'fa-leaf',
		'highlight' => __( 'Riciclabile nella carta', 'samswiss-child' ),
	),
	array(
		'name'      => 'PaperSeal',
		'tag'       => __( 'Cartoncino pretagliato + liner · MAP & Skin', 'samswiss-child' ),
		'desc'      => __( 'Vassoio formato da cartoncino pretagliato e liner protettivo, adatto a confezionamento in MAP e Skin. Le due componenti possono essere separate per facilitarne il corretto conferimento.', 'samswiss-child' ),
		'apps'      => __( 'Ideale per: Prodotti freschi, gastronomia, carni e piatti pronti.', 'samswiss-child' ),
		'icon'      => 'fa-box',
		'highlight' => __( 'Separabile & Sostenibile', 'samswiss-child' ),
	),
	array(
		'name'      => 'PaperSeal Cook',
		'tag'       => __( 'Forno & Microonde · Piatti pronti', 'samswiss-child' ),
		'desc'      => __( 'Evoluzione della gamma PaperSeal, pensata anche per prodotti destinati al riscaldamento in forno tradizionale o microonde, particolarmente interessante per piatti pronti.', 'samswiss-child' ),
		'apps'      => __( 'Ideale per: Ready meals, gastronomia calda, rosticceria, catering.', 'samswiss-child' ),
		'icon'      => 'fa-fire-burner',
		'highlight' => __( 'Termoresistente fino ad alte temperature', 'samswiss-child' ),
	),
	array(
		'name'      => 'PaperSeal Skin',
		'tag'       => __( 'Base carta Skin · Freschi & Tagli nobili', 'samswiss-child' ),
		'desc'      => __( 'Soluzione a base carta dedicata al confezionamento Skin, utilizzata per carne, pesce, formaggi e altri prodotti freschi.', 'samswiss-child' ),
		'apps'      => __( 'Ideale per: Carne, pesce, formaggi e freschi ad alta conservazione.', 'samswiss-child' ),
		'icon'      => 'fa-shield-halved',
		'highlight' => __( 'Protezione Skin avanzata', 'samswiss-child' ),
	),
	array(
		'name'      => 'Paper2Skin',
		'tag'       => __( 'Novità · Massima riduzione plastica', 'samswiss-child' ),
		'desc'      => __( 'Una delle soluzioni più recenti di Bernucci: packaging Skin con supporto in carta laminata e film superiore a prevalenza carta, sviluppato per ridurre ulteriormente la componente plastica e offrire ampie possibilità di personalizzazione grafica.', 'samswiss-child' ),
		'apps'      => __( 'Ideale per: Confezioni premium a minimo impatto ambientale.', 'samswiss-child' ),
		'icon'      => 'fa-recycle',
		'highlight' => __( 'Prevalenza carta fronte e retro', 'samswiss-child' ),
	),
);

$gamma_items = array(
	__( 'Vaschette PET · PP · CPET', 'samswiss-child' ),
	__( 'Vaschette in polpa di cellulosa', 'samswiss-child' ),
	__( 'Skin film ad alta barriera', 'samswiss-child' ),
	__( 'Top film saldanti e pelabili', 'samswiss-child' ),
	__( 'Buste sottovuoto lisce e goffrate', 'samswiss-child' ),
	__( 'Fascette, astucci ed espositori personalizzabili', 'samswiss-child' ),
);
?>
<main id="primary" class="samswiss-main samswiss-consumabili-page swiss-page">

	<!-- 1. Hero Section -->
	<section class="samswiss-consumabili-hero" style="background-image: linear-gradient(rgba(17, 24, 15, 0.78), rgba(17, 24, 15, 0.88)), url('<?php echo esc_url( $hero_bg ); ?>');">
		<div class="samswiss-container samswiss-consumabili-hero__inner">
			<div class="samswiss-consumabili-hero__content">
				<p class="sw-label samswiss-consumabili-hero__label"><?php esc_html_e( 'MATERIALI DI CONSUMO & PACKAGING ALIMENTARE', 'samswiss-child' ); ?></p>
				<h1 class="sw-display samswiss-consumabili-hero__title"><?php esc_html_e( 'Il packaging giusto per ogni prodotto.', 'samswiss-child' ); ?></h1>
				<p class="samswiss-consumabili-hero__lede"><?php esc_html_e( 'Film, reti, vaschette e materiali tecnici per il confezionamento alimentare.', 'samswiss-child' ); ?></p>
				<div class="samswiss-consumabili-hero__text">
					<p><?php esc_html_e( 'SAM fornisce materiali di consumo professionali per le diverse tecnologie di confezionamento, selezionati in funzione del prodotto, della macchina, del formato e delle prestazioni richieste.', 'samswiss-child' ); ?></p>
					<p><?php esc_html_e( 'Dall’ortofrutta ai prodotti freschi, dalla gastronomia alla carne, al pesce e al settore caseario, affianchiamo il cliente nella scelta del materiale più adatto alla propria applicazione, con soluzioni standard o personalizzate.', 'samswiss-child' ); ?></p>
				</div>
				<div class="samswiss-consumabili-hero__actions">
					<a class="samswiss-btn samswiss-btn--green" href="<?php echo esc_url( $contact_url ); ?>">
						<span><?php esc_html_e( 'Richiedi Informazioni', 'samswiss-child' ); ?></span>
						<span aria-hidden="true">&rarr;</span>
					</a>
					<a class="samswiss-btn samswiss-btn--ghost-white" href="<?php echo esc_url( $whatsapp_url ); ?>" target="_blank" rel="noopener">
						<i class="fab fa-whatsapp" aria-hidden="true"></i>
						<span><?php esc_html_e( 'Contattaci su WhatsApp', 'samswiss-child' ); ?></span>
					</a>
				</div>
			</div>
		</div>
	</section>

	<!-- 2. Strip delle categorie / Pills -->
	<section class="samswiss-consumabili-pills-bar">
		<div class="samswiss-container">
			<ul class="samswiss-consumabili-pills" aria-label="<?php esc_attr_e( 'Tipologie di materiali disponibili', 'samswiss-child' ); ?>">
				<?php foreach ( $material_pills as $pill ) : ?>
					<li>
						<a class="samswiss-pill<?php echo ! empty( $pill['eco'] ) ? ' samswiss-pill--eco' : ''; ?>" href="<?php echo esc_url( $pill['url'] ); ?>">
							<?php echo esc_html( $pill['label'] ); ?>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</section>

	<!-- 3. Partnership GB Bernucci -->
	<section class="samswiss-consumabili-bernucci" id="bernucci">
		<div class="samswiss-container">
			<div class="samswiss-bernucci-header">
				<div class="samswiss-bernucci-brand">
					<img class="samswiss-bernucci-logo" src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/img/partners/gb-bernucci-logo.png' ); ?>" alt="GB Bernucci Packaging" width="180" height="60" loading="lazy">
					<span class="samswiss-bernucci-badge"><?php esc_html_e( 'Partnership Ufficiale SAM Swiss', 'samswiss-child' ); ?></span>
				</div>
				<h2 class="sw-display samswiss-bernucci-title"><?php esc_html_e( 'Bernucci: packaging, supporti e materiali per valorizzare il prodotto', 'samswiss-child' ); ?></h2>
				<p class="samswiss-bernucci-intro">
					<?php esc_html_e( 'All’interno della nostra offerta di materiali di consumo, proponiamo anche le soluzioni GB Bernucci, specializzate in vaschette, supporti, top film, Skin film, buste sottovuoto e soluzioni a base carta per il confezionamento alimentare.', 'samswiss-child' ); ?>
				</p>
				<p class="samswiss-bernucci-subintro">
					<?php esc_html_e( 'Una gamma pensata per rispondere alle esigenze di diversi settori, con soluzioni standard o personalizzate, capaci di coniugare praticità, protezione e presentazione del prodotto.', 'samswiss-child' ); ?>
				</p>
			</div>

			<!-- Box Claim Bernucci -->
			<div class="samswiss-bernucci-claim">
				<div class="samswiss-bernucci-claim__icon" aria-hidden="true">
					<i class="fas fa-award"></i>
				</div>
				<div class="samswiss-bernucci-claim__body">
					<h3><?php esc_html_e( 'BERNUCCI – Soluzioni innovative per il packaging alimentare', 'samswiss-child' ); ?></h3>
					<p><?php esc_html_e( 'SAM propone le soluzioni GB Bernucci dedicate al confezionamento alimentare, con una gamma che unisce funzionalità, presentazione del prodotto, personalizzazione e riduzione dell’utilizzo di plastica.', 'samswiss-child' ); ?></p>
				</div>
			</div>

			<!-- Griglia delle 5 soluzioni Bernucci -->
			<div class="samswiss-bernucci-grid">
				<?php foreach ( $bernucci_solutions as $sol ) : ?>
					<article class="samswiss-bernucci-card">
						<header class="samswiss-bernucci-card__head">
							<span class="samswiss-bernucci-card__icon" aria-hidden="true"><i class="fas <?php echo esc_attr( $sol['icon'] ); ?>"></i></span>
							<span class="samswiss-bernucci-card__highlight"><?php echo esc_html( $sol['highlight'] ); ?></span>
						</header>
						<h3 class="samswiss-bernucci-card__name"><?php echo esc_html( $sol['name'] ); ?></h3>
						<p class="samswiss-bernucci-card__tag"><?php echo esc_html( $sol['tag'] ); ?></p>
						<p class="samswiss-bernucci-card__desc"><?php echo esc_html( $sol['desc'] ); ?></p>
						<p class="samswiss-bernucci-card__apps"><?php echo esc_html( $sol['apps'] ); ?></p>
					</article>
				<?php endforeach; ?>
			</div>

			<!-- Volantino packaging sostenibile (IT/FR/DE) -->
			<?php
			get_template_part( 'template-parts/flyer', null, array(
				'name'  => 'packaging-sostenibile',
				'label' => __( 'PACKAGING SOSTENIBILE', 'samswiss-child' ),
				'title' => __( 'Vaschette e vassoi a base carta e cellulosa', 'samswiss-child' ),
				'text'  => __( 'Polpa di cellulosa, PaperSeal, Paper2Skin e SlimFresh: le soluzioni Bernucci per ridurre la plastica, mantenere il prodotto fresco e valorizzarlo sullo scaffale.', 'samswiss-child' ),
				'alt'   => __( 'Volantino SAM packaging sostenibile: vaschette in polpa di cellulosa, PaperSeal, Paper2Skin e SlimFresh', 'samswiss-child' ),
			) );
			?>

			<!-- Completano la gamma -->
			<div class="samswiss-gamma-box" id="gamma">
				<h3 class="samswiss-gamma-box__title"><?php esc_html_e( 'Completano la gamma di materiali', 'samswiss-child' ); ?></h3>
				<ul class="samswiss-gamma-list">
					<?php foreach ( $gamma_items as $item ) : ?>
						<li>
							<i class="fas fa-check-circle" aria-hidden="true"></i>
							<span><?php echo esc_html( $item ); ?></span>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
		</div>
	</section>

	<!-- 4. Chiusura Commerciale e Assistenza -->
	<section class="samswiss-consumabili-close" id="consulenza">
		<div class="samswiss-container">
			<div class="samswiss-consumabili-close__box">
				<p class="sw-label"><?php esc_html_e( 'CONSULENZA & ASSISTENZA SAM SA', 'samswiss-child' ); ?></p>
				<h2 class="sw-display samswiss-consumabili-close__title">
					<?php esc_html_e( 'Packaging standard o personalizzato, studiato in funzione del prodotto, della conservazione e dell’immagine del cliente.', 'samswiss-child' ); ?>
				</h2>
				<p class="samswiss-consumabili-close__desc">
					<?php esc_html_e( 'Non vendiamo solo macchine: con SAM hai un unico interlocutore professionale per le confezionatrici, i materiali di consumo compatibili, i ricambi originali e il supporto tecnico qualificato su tutto il territorio svizzero.', 'samswiss-child' ); ?>
				</p>
				<div class="samswiss-consumabili-close__actions">
					<a class="samswiss-btn samswiss-btn--green" href="<?php echo esc_url( $contact_url ); ?>">
						<span><?php esc_html_e( 'Richiedi un preventivo sui materiali', 'samswiss-child' ); ?></span>
						<span aria-hidden="true">&rarr;</span>
					</a>
					<a class="samswiss-btn samswiss-btn--outline" href="<?php echo esc_url( $whatsapp_url ); ?>" target="_blank" rel="noopener">
						<i class="fab fa-whatsapp" aria-hidden="true"></i>
						<span><?php esc_html_e( 'Scrivici su WhatsApp (+41 76 467 85 23)', 'samswiss-child' ); ?></span>
					</a>
				</div>
			</div>
		</div>
	</section>

</main>
