<?php
/**
 * Single technology page — served for /tecnologie/{slug}/ by the
 * `template_include` filter in inc/tecnologie.php, not through page.php: this
 * IS the whole template (no WP_Post behind these URLs), so unlike the other
 * template-parts/pages/*.php files it calls get_header()/get_footer() itself.
 *
 * Supports both rich structured technology pages (such as Flow-Pack with video
 * showcase, feature list, detailed benefits and quote banner) and fallback
 * standard technology pages.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$slug     = get_query_var( 'samswiss_tech' );
$catalog  = samswiss_tech_catalog();
$tech     = $catalog[ $slug ];
$contatti = samswiss_localized_permalink( 569, 'page', 'contatti' ) ?: home_url( '/contatti/' );

get_header();
?>

<main id="primary" class="samswiss-main swiss-page tecnologia-page">

	<!-- 1. Hero -->
	<section class="swiss-tech-hero">
		<div class="swiss-tech-hero__text">
			<p class="sw-label"><a href="<?php echo esc_url( home_url( '/' ) ); ?>#tecnologie"><?php esc_html_e( '← Tecnologie', 'samswiss-child' ); ?></a></p>
			<h1 class="sw-display swiss-tech-hero__title"><?php echo esc_html( $tech['title'] ); ?></h1>
			<?php if ( ! empty( $tech['subtitle'] ) ) : ?>
				<p class="swiss-tech-hero__subtitle"><?php echo esc_html( $tech['subtitle'] ); ?></p>
			<?php endif; ?>
			<p class="swiss-tech-hero__lede"><?php echo esc_html( $tech['intro'] ); ?></p>
			<a class="swiss-cta__btn" href="<?php echo esc_url( $contatti ); ?>">
				<span><?php esc_html_e( 'Richiedi informazioni', 'samswiss-child' ); ?></span>
				<span aria-hidden="true">&rarr;</span>
			</a>
		</div>
		<div class="swiss-tech-hero__media">
			<?php
			$cover = samswiss_tech_image( $tech['cover'], $tech['title'], 'swiss-tech-hero__photo' );
			if ( $cover ) {
				echo $cover; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- helper escapes.
			} else {
				echo '<span class="swiss-tech-hero__placeholder"><i class="fas ' . esc_attr( $tech['icon'] ) . '" aria-hidden="true"></i></span>';
			}
			?>
		</div>
	</section>

	<?php if ( ! empty( $tech['features'] ) ) : ?>
	<!-- 2. Features & Automation -->
	<section class="swiss-tech-features">
		<div class="swiss-tech-features__main">
			<h2 class="sw-display swiss-tech-section-title"><?php echo esc_html( $tech['features_title'] ?? __( 'Flessibilità e semplicità di utilizzo', 'samswiss-child' ) ); ?></h2>
			<?php if ( ! empty( $tech['features_intro'] ) ) : ?>
				<p class="swiss-tech-features__intro"><?php echo esc_html( $tech['features_intro'] ); ?></p>
			<?php endif; ?>
			<ul class="swiss-tech-features__list">
				<?php foreach ( $tech['features'] as $feat ) : ?>
					<li class="swiss-tech-features__item">
						<span class="swiss-tech-features__icon" aria-hidden="true"><i class="fas fa-check"></i></span>
						<span class="swiss-tech-features__text"><?php echo esc_html( $feat ); ?></span>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php if ( ! empty( $tech['automation_title'] ) ) : ?>
		<div class="swiss-tech-features__automation">
			<div class="swiss-tech-automation-card">
				<span class="swiss-tech-automation-card__icon" aria-hidden="true"><i class="fas fa-diagram-project"></i></span>
				<h3 class="swiss-tech-automation-card__title"><?php echo esc_html( $tech['automation_title'] ); ?></h3>
				<p class="swiss-tech-automation-card__text"><?php echo esc_html( $tech['automation_text'] ); ?></p>
				<a class="swiss-tech-automation-card__link" href="<?php echo esc_url( $contatti ); ?>">
					<span><?php esc_html_e( 'Progetta la tua linea', 'samswiss-child' ); ?></span>
					<span aria-hidden="true">&rarr;</span>
				</a>
			</div>
		</div>
		<?php endif; ?>
	</section>
	<?php endif; ?>

	<!-- 3. Video Showcase -->
	<?php if ( ! empty( $tech['videos'] ) ) : ?>
		<?php
		$first_video = $tech['videos'][0];
		$first_src   = samswiss_tech_media_url( $first_video['src'] );
		?>
		<section class="swiss-tech-video-showcase" id="video-showcase">
			<div class="swiss-tech-video-showcase__header">
				<p class="sw-label"><?php esc_html_e( 'Video Dimostrativi', 'samswiss-child' ); ?></p>
				<h2 class="sw-display swiss-tech-section-title"><?php echo esc_html( $tech['video_title'] ?? __( 'Guarda le macchine in funzione', 'samswiss-child' ), ); ?></h2>
				<?php if ( ! empty( $tech['video_subtitle'] ) ) : ?>
					<p class="swiss-tech-video-showcase__subtitle"><?php echo esc_html( $tech['video_subtitle'] ); ?></p>
				<?php endif; ?>
			</div>

			<div class="swiss-tech-video-showcase__content">
				<!-- Main Video Player -->
				<div class="swiss-tech-video-showcase__player-wrap">
					<div class="swiss-tech-video-player-box">
						<video id="swissTechMainPlayer" class="swiss-tech-video-player" controls playsinline preload="metadata" src="<?php echo esc_url( $first_src ); ?>">
							<p><?php esc_html_e( 'Il tuo browser non supporta la riproduzione video.', 'samswiss-child' ); ?></p>
						</video>
					</div>
					<div class="swiss-tech-video-player-info">
						<h3 id="swissTechVideoTitle" class="swiss-tech-video-player-title"><?php echo esc_html( $first_video['title'] ); ?></h3>
						<p id="swissTechVideoDesc" class="swiss-tech-video-player-desc"><?php echo esc_html( $first_video['desc'] ); ?></p>
					</div>
				</div>

				<!-- Playlist Tabs / Selector -->
				<div class="swiss-tech-video-showcase__playlist">
					<p class="swiss-tech-video-playlist-heading">
						<i class="fas fa-film" aria-hidden="true"></i>
						<span><?php echo esc_html( sprintf( __( 'Applicazioni disponibili (%d)', 'samswiss-child' ), count( $tech['videos'] ) ) ); ?></span>
					</p>
					<div class="swiss-tech-video-playlist-items" role="tablist">
						<?php foreach ( $tech['videos'] as $idx => $v ) : ?>
							<?php $v_src = samswiss_tech_media_url( $v['src'] ); ?>
							<button type="button"
								class="swiss-tech-video-pill <?php echo 0 === $idx ? 'is-active' : ''; ?>"
								role="tab"
								aria-selected="<?php echo 0 === $idx ? 'true' : 'false'; ?>"
								data-video-src="<?php echo esc_url( $v_src ); ?>"
								data-video-title="<?php echo esc_attr( $v['title'] ); ?>"
								data-video-desc="<?php echo esc_attr( $v['desc'] ); ?>">
								<span class="swiss-tech-video-pill__icon" aria-hidden="true"><i class="fas fa-play"></i></span>
								<span class="swiss-tech-video-pill__body">
									<strong class="swiss-tech-video-pill__title"><?php echo esc_html( $v['title'] ); ?></strong>
									<?php if ( ! empty( $v['tag'] ) ) : ?>
										<span class="swiss-tech-video-pill__tag"><?php echo esc_html( $v['tag'] ); ?></span>
									<?php endif; ?>
								</span>
							</button>
						<?php endforeach; ?>
					</div>
				</div>
			</div>

			<?php if ( ! empty( $tech['cta_box_title'] ) ) : ?>
			<!-- Mid-page consultation callout -->
			<div class="swiss-tech-callout-box">
				<div class="swiss-tech-callout-box__lead">
					<span class="swiss-tech-callout-box__icon" aria-hidden="true"><i class="far fa-comments"></i></span>
					<div>
						<h3 class="swiss-tech-callout-box__title"><?php echo esc_html( $tech['cta_box_title'] ); ?></h3>
						<p class="swiss-tech-callout-box__text"><?php echo esc_html( $tech['cta_box_text'] ); ?></p>
					</div>
				</div>
				<a class="swiss-cta__btn swiss-tech-callout-box__btn" href="<?php echo esc_url( $contatti ); ?>">
					<span><?php echo esc_html( $tech['cta_box_btn'] ?? __( 'Richiedi una consulenza', 'samswiss-child' ) ); ?></span>
					<span aria-hidden="true">&rarr;</span>
				</a>
			</div>
			<?php endif; ?>
		</section>
	<?php else : ?>
		<!-- Stand-in video box for pages without videos yet -->
		<section class="swiss-tech-video">
			<div class="swiss-tech-video__box" role="img" aria-label="<?php esc_attr_e( 'Area video — segnaposto', 'samswiss-child' ); ?>">
				<span class="swiss-tech-video__play" aria-hidden="true"><i class="fas fa-play"></i></span>
				<p class="swiss-tech-video__label"><?php esc_html_e( 'Video dimostrativo in arrivo', 'samswiss-child' ); ?></p>
			</div>
		</section>
	<?php endif; ?>

	<!-- 4. Why Choose / Vantaggi -->
	<?php if ( ! empty( $tech['vantaggi_detailed'] ) ) : ?>
	<section class="swiss-tech-why-section">
		<div class="swiss-tech-why-header">
			<p class="sw-label"><?php esc_html_e( 'Punti di Forza', 'samswiss-child' ); ?></p>
			<h2 class="sw-display swiss-tech-section-title"><?php echo esc_html( $tech['why_title'] ?? __( 'Perché scegliere questa tecnologia', 'samswiss-child' ) ); ?></h2>
			<?php if ( ! empty( $tech['why_intro'] ) ) : ?>
				<p class="swiss-tech-why-intro"><?php echo esc_html( $tech['why_intro'] ); ?></p>
			<?php endif; ?>
		</div>
		<div class="swiss-tech-benefits-grid">
			<?php foreach ( $tech['vantaggi_detailed'] as $benefit ) : ?>
				<div class="swiss-tech-benefit-card">
					<span class="swiss-tech-benefit-card__icon" aria-hidden="true"><i class="fas fa-check-circle"></i></span>
					<div class="swiss-tech-benefit-card__body">
						<h3 class="swiss-tech-benefit-card__title"><?php echo esc_html( $benefit['title'] ); ?></h3>
						<p class="swiss-tech-benefit-card__desc"><?php echo esc_html( $benefit['desc'] ); ?></p>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</section>
	<?php elseif ( ! empty( $tech['come_funziona'] ) || ! empty( $tech['vantaggi'] ) ) : ?>
	<section class="swiss-tech-detail">
		<?php if ( ! empty( $tech['come_funziona'] ) ) : ?>
		<div class="swiss-tech-detail__col">
			<h2 class="sw-display swiss-tech-detail__title"><?php esc_html_e( 'Come funziona', 'samswiss-child' ); ?></h2>
			<ol class="swiss-tech-steps">
				<?php foreach ( $tech['come_funziona'] as $step ) : ?>
					<li><?php echo esc_html( $step ); ?></li>
				<?php endforeach; ?>
			</ol>
		</div>
		<?php endif; ?>
		<?php if ( ! empty( $tech['vantaggi'] ) ) : ?>
		<div class="swiss-tech-detail__col">
			<h2 class="sw-display swiss-tech-detail__title"><?php esc_html_e( 'Vantaggi', 'samswiss-child' ); ?></h2>
			<ul class="swiss-tech-advantages">
				<?php foreach ( $tech['vantaggi'] as $item ) : ?>
					<li><i class="fas fa-check" aria-hidden="true"></i><span><?php echo esc_html( $item ); ?></span></li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php endif; ?>
	</section>
	<?php endif; ?>

	<?php if ( ! empty( $tech['quote'] ) ) : ?>
	<!-- 5. Quote Banner -->
	<section class="swiss-tech-quote-band">
		<div class="swiss-tech-quote-inner">
			<span class="swiss-tech-quote-mark" aria-hidden="true">&ldquo;</span>
			<blockquote class="swiss-tech-quote-text"><?php echo esc_html( $tech['quote'] ); ?></blockquote>
		</div>
	</section>
	<?php endif; ?>

	<!-- 6. Applicazioni -->
	<section class="swiss-tech-apps">
		<h2 class="sw-display swiss-tech-detail__title"><?php esc_html_e( 'Settori e Applicazioni', 'samswiss-child' ); ?></h2>
		<ul class="swiss-tech-apps__list">
			<?php foreach ( $tech['applicazioni'] as $sector ) : ?>
				<li><?php echo esc_html( $sector ); ?></li>
			<?php endforeach; ?>
		</ul>
	</section>

	<?php if ( ! empty( $tech['gallery'] ) ) : ?>
	<!-- 7. Gallery -->
	<section class="swiss-tech-gallery">
		<h2 class="sw-display swiss-tech-detail__title"><?php esc_html_e( 'Galleria', 'samswiss-child' ); ?></h2>
		<div class="swiss-tech-gallery__grid">
			<?php foreach ( $tech['gallery'] as $index => $entry ) : ?>
				<?php
				$img = samswiss_tech_image(
					$entry,
					/* translators: %1$s technology name, %2$d image number */
					sprintf( __( '%1$s — foto %2$d', 'samswiss-child' ), $tech['title'], $index + 2 ),
					'swiss-tech-gallery__photo'
				);
				if ( $img ) :
					?>
					<div class="swiss-tech-gallery__cell"><?php echo $img; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- helper escapes. ?></div>
				<?php endif; ?>
			<?php endforeach; ?>
		</div>
	</section>
	<?php endif; ?>

	<!-- 8. Closing CTA -->
	<section class="swiss-cta">
		<div class="swiss-cta__inner">
			<div class="swiss-cta__lead">
				<span class="swiss-cta__icon" aria-hidden="true"><i class="far fa-comments"></i></span>
				<h2 class="sw-display swiss-cta__title">
					<?php esc_html_e( 'Hai un progetto?', 'samswiss-child' ); ?><br>
					<?php esc_html_e( 'Parliamone.', 'samswiss-child' ); ?>
				</h2>
			</div>
			<div class="swiss-cta__body">
				<p class="swiss-cta__text">
					<?php esc_html_e( 'Raccontaci il prodotto, il formato e le esigenze produttive.', 'samswiss-child' ); ?><br>
					<?php esc_html_e( 'Studieremo insieme la soluzione più adatta.', 'samswiss-child' ); ?>
				</p>
				<a class="swiss-cta__btn" href="<?php echo esc_url( $contatti ); ?>">
					<span><?php esc_html_e( 'Contattaci ora', 'samswiss-child' ); ?></span>
					<span aria-hidden="true">&rarr;</span>
				</a>
			</div>
		</div>
	</section>

</main>

<?php
get_footer();

