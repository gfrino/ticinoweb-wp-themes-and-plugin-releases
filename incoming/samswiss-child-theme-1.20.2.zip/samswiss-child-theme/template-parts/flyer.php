<?php
/**
 * Volantino del cliente nella lingua della pagina.
 *
 * L'immagine si sceglie in Bacheca → Volantini (inc/flyers.php); dove non si
 * è scelto nulla vale l'originale in assets/img/volantini/<name>-<lingua>.jpg.
 * Se una lingua non ha volantino il blocco non compare, piuttosto che
 * mostrarne uno in una lingua diversa da quella del visitatore.
 *
 * Argomenti: name, label, title, text, alt.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$flyer = wp_parse_args( $args, array(
	'name'  => '',
	'label' => '',
	'title' => '',
	'text'  => '',
	'alt'   => '',
) );

$flyer_lang   = apply_filters( 'wpml_current_language', null ) ?: 'it';
$flyer_source = ( $flyer['name'] && function_exists( 'samswiss_flyer_source' ) )
	? samswiss_flyer_source( $flyer['name'], $flyer_lang, $flyer['alt'], 'samswiss-flyer__img' )
	: null;

if ( ! $flyer_source ) {
	return;
}
?>
<div class="samswiss-flyer">
	<div class="samswiss-flyer__text">
		<?php if ( $flyer['label'] ) : ?>
			<p class="sw-label samswiss-flyer__label"><?php echo esc_html( $flyer['label'] ); ?></p>
		<?php endif; ?>
		<h2 class="sw-display samswiss-flyer__title"><?php echo esc_html( $flyer['title'] ); ?></h2>
		<?php if ( $flyer['text'] ) : ?>
			<p class="samswiss-flyer__desc"><?php echo esc_html( $flyer['text'] ); ?></p>
		<?php endif; ?>
		<a class="samswiss-btn samswiss-btn--green" href="<?php echo esc_url( $flyer_source['url'] ); ?>" target="_blank" rel="noopener">
			<span><?php esc_html_e( 'Apri il volantino', 'samswiss-child' ); ?></span>
			<span aria-hidden="true">&rarr;</span>
		</a>
	</div>
	<figure class="samswiss-flyer__figure">
		<a href="<?php echo esc_url( $flyer_source['url'] ); ?>" target="_blank" rel="noopener">
			<?php echo $flyer_source['img']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- HTML da wp_get_attachment_image() o samswiss_shipped_image(), già escapato. ?>
		</a>
	</figure>
</div>
