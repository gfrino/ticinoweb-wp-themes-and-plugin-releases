<?php
/**
 * Front page delegator.
 *
 * The parent theme (ticinoweb-ai-theme) ships its own front-page.php, and
 * WordPress's template hierarchy matches "front-page.php" by filename alone —
 * it is checked in the child theme, then the parent, before ever considering
 * page.php. So a child theme with NO front-page.php of its own silently falls
 * back to the parent's, not to page.php, no matter which page is assigned as
 * the front page. This file exists only to prevent that fallback: it hands
 * off to the exact same page.php that renders every other normal page, so the
 * front page (Macchine confezionatrici, since `page_on_front` was pointed at
 * it) gets the same rich landing template-part as its own permalink does.
 *
 * The previous INTRO gateway (a separate, self-contained chooser page) lived
 * here until the client asked to retire it as the site's entry point.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require get_stylesheet_directory() . '/page.php';
