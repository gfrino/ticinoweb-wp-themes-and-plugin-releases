<?php
/**
 * Template Name: SAM SWISS Contatti
 * Contact page — company details + native contact form.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$contact = samswiss_get_contact();
?>

<main id="primary" class="samswiss-main samswiss-contatti">
	<header class="samswiss-page-header">
		<div class="samswiss-container">
			<p class="sw-label">S.A.M. SA · Balerna</p>
			<h1 class="samswiss-page-title"><?php the_title(); ?></h1>
		</div>
	</header>

	<div class="samswiss-container samswiss-contatti-layout">

		<div class="samswiss-contatti-info">
			<?php
			while ( have_posts() ) : the_post();
				the_content();
			endwhile;
			?>
			<ul class="samswiss-contatti-details">
				<li><i class="fas fa-map-marker-alt"></i>
					<span><?php echo esc_html( $contact['address'] ); ?><?php if ( ! empty( $contact['vat'] ) ) : ?><br><?php echo esc_html( 'Nr. IVA: ' . $contact['vat'] ); ?><?php endif; ?></span>
				</li>
				<li><i class="fas fa-phone-alt"></i>
					<a href="tel:<?php echo esc_attr( $contact['phone'] ); ?>"><?php echo esc_html( $contact['phone_display'] ); ?></a>
				</li>
				<li><i class="fas fa-envelope"></i>
					<a href="mailto:<?php echo esc_attr( $contact['email'] ); ?>"><?php echo esc_html( $contact['email'] ); ?></a>
				</li>
			</ul>
		</div>

		<div class="samswiss-contatti-form-wrap" id="samswiss-contact">
			<p class="sw-label">S.A.M. SA</p>
			<h2 class="samswiss-contatti-form-title"><?php esc_html_e( 'Scrivici', 'samswiss-child' ); ?></h2>

			<?php
			// Outcome of a no-JS submission, rendered in place. With JavaScript the
			// same text arrives in .samswiss-form-feedback without a page load.
			$feedback = function_exists( 'samswiss_contact_feedback' ) ? samswiss_contact_feedback() : array();
			if ( $feedback ) :
				?>
				<p class="samswiss-form-notice <?php echo $feedback['success'] ? 'is-success' : 'is-error'; ?>" role="status">
					<?php echo esc_html( $feedback['message'] ); ?>
				</p>
			<?php endif; ?>

			<?php
			// No `novalidate` in the markup: without JavaScript the browser's own
			// required/email checks are the only validation the visitor gets. main.js
			// sets noValidate at runtime so its custom messages take over when it can.
			?>
			<form class="samswiss-contact-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<div class="form-row">
					<label for="samswiss-name"><?php esc_html_e( 'Nome *', 'samswiss-child' ); ?></label>
					<input type="text" id="samswiss-name" name="name" required>
				</div>
				<div class="form-row form-row-2">
					<div>
						<label for="samswiss-email"><?php esc_html_e( 'Email *', 'samswiss-child' ); ?></label>
						<input type="email" id="samswiss-email" name="email" required>
					</div>
					<div>
						<label for="samswiss-phone"><?php esc_html_e( 'Telefono', 'samswiss-child' ); ?></label>
						<input type="tel" id="samswiss-phone" name="phone">
					</div>
				</div>
				<div class="form-row">
					<label for="samswiss-message"><?php esc_html_e( 'Messaggio *', 'samswiss-child' ); ?></label>
					<textarea id="samswiss-message" name="message" rows="6" required></textarea>
				</div>
				<div class="form-honeypot" aria-hidden="true">
					<label>Website<input type="text" name="website" tabindex="-1" autocomplete="off"></label>
				</div>
				<?php wp_nonce_field( 'samswiss_contact', 'samswiss_contact_nonce' ); ?>
				<input type="hidden" name="action" value="samswiss_contact">
				<input type="hidden" name="redirect_to" value="<?php echo esc_url( get_permalink() ); ?>">
				<div class="form-row form-submit-row">
					<button type="submit" class="samswiss-btn samswiss-btn--red"><?php esc_html_e( 'Invia messaggio', 'samswiss-child' ); ?></button>
					<span class="samswiss-form-feedback" aria-live="polite"></span>
				</div>
			</form>
		</div>

	</div>
</main>

<?php
get_footer();
