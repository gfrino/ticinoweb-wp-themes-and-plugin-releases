<?php
/**
 * SAM SWISS header — reproduces the Elementor "Header_eCommerce" layout natively.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$contact     = samswiss_get_contact();
$logo        = samswiss_get_logo_url();
$has_wc      = function_exists( 'is_woocommerce' ) && function_exists( 'WC' );
$blog_header = function_exists( 'samswiss_use_blog_header' ) && samswiss_use_blog_header();
$header_variant = $blog_header ? 'blog' : 'ecommerce';

// The blog header drops search and account, which suits an article or an archive.
// The Macchine landing is a catalogue front door, so it keeps both while keeping
// the blog topbar it was designed with.
$show_actions = ! $blog_header
	|| ( function_exists( 'samswiss_current_landing_slug' ) && 'macchine-confezionatrici' === samswiss_current_landing_slug() );
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Vai al contenuto', 'samswiss-child' ); ?></a>

	<div class="samswiss-header-wrapper samswiss-header--<?php echo esc_attr( $header_variant ); ?>">

		<!-- Topbar -->
		<div class="samswiss-topbar samswiss-topbar--<?php echo esc_attr( $header_variant ); ?>">
			<div class="samswiss-container">
				<div class="topbar-contact">
					<span class="contact-item contact-phone">
						<i class="fas fa-phone-alt" aria-hidden="true"></i>
						<a href="tel:<?php echo esc_attr( $contact['phone'] ); ?>"><?php echo esc_html( $contact['phone_display'] ); ?></a>
					</span>
					<span class="contact-item contact-email">
						<i class="fas fa-envelope" aria-hidden="true"></i>
						<a href="mailto:<?php echo esc_attr( $contact['email'] ); ?>"><?php echo esc_html( $contact['email'] ); ?></a>
					</span>
				</div>
				<div class="topbar-right">
					<?php
					// The social marks belong to the site, not to one page template. They
					// used to be the "blog" header's alternative to the cart, which is why
					// they showed on Macchine and on articles and nowhere else.
					if ( function_exists( 'samswiss_social_links' ) ) {
						samswiss_social_links( 'topbar-social' );
					}
					?>
					<?php if ( ! $blog_header && $has_wc ) : ?>
						<span class="topbar-currency">
							<span class="cart-subtotal"><?php echo wp_kses_post( WC()->cart ? WC()->cart->get_cart_subtotal() : '' ); ?></span>
						</span>
						<a href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="topbar-cart">
							<i class="fas fa-shopping-cart" aria-hidden="true"></i>
							<span class="cart-label"><?php esc_html_e( 'Carrello', 'samswiss-child' ); ?></span>
							<span class="cart-count"><?php echo esc_html( WC()->cart ? WC()->cart->get_cart_contents_count() : 0 ); ?></span>
						</a>
					<?php endif; ?>
					<?php samswiss_language_switcher( array( 'display' => 'inline', 'show_names' => false, 'show_flags' => true, 'class' => 'topbar-langs' ) ); ?>
				</div>
			</div>
		</div>

		<!-- Main header row -->
		<div class="samswiss-header-main">
			<div class="samswiss-container">
				<div class="samswiss-logo">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
						<?php if ( $logo ) : ?>
							<img src="<?php echo esc_url( $logo ); ?>"<?php echo samswiss_logo_dimensions( $logo ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- helper returns escaped integers. ?> alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
						<?php else : ?>
							<span class="site-title"><?php bloginfo( 'name' ); ?></span>
						<?php endif; ?>
					</a>
				</div>

				<nav class="samswiss-primary-nav desktop-only" aria-label="<?php esc_attr_e( 'Menu principale', 'samswiss-child' ); ?>">
					<?php
					// The INTRO pill used to link to the separate front-page.php gateway. That
					// template is removed and Macchine confezionatrici (labelled "Home" in this
					// menu) is now the WordPress front page itself (`page_on_front`), so there is
					// no separate destination left for this pill to name.
					wp_nav_menu( array(
						'theme_location' => 'primary',
						'menu_class'     => 'samswiss-primary-menu',
						'container'      => false,
						'fallback_cb'    => false,
						'walker'         => new Samswiss_Walker_Nav_Menu(),
					) );
					?>
				</nav>

				<div class="samswiss-header-actions">
					<?php if ( $show_actions ) : ?>
						<button type="button" class="action-btn search-trigger" aria-label="<?php esc_attr_e( 'Cerca', 'samswiss-child' ); ?>">
							<i class="fas fa-search" aria-hidden="true"></i>
						</button>
						<?php if ( $has_wc ) : ?>
							<a href="<?php echo esc_url( get_permalink( get_option( 'woocommerce_myaccount_page_id' ) ) ); ?>" class="action-btn account-link" aria-label="<?php esc_attr_e( 'Il mio account', 'samswiss-child' ); ?>">
								<i class="far fa-user-circle" aria-hidden="true"></i>
							</a>
						<?php endif; ?>
					<?php endif; ?>
					<button class="action-btn mobile-menu-trigger" type="button" aria-label="<?php esc_attr_e( 'Apri menu', 'samswiss-child' ); ?>" aria-expanded="false" aria-controls="samswiss-mobile-drawer">
						<i class="fas fa-bars" aria-hidden="true"></i>
					</button>
				</div>
			</div>
		</div>

	</div><!-- .samswiss-header-wrapper -->

	<!-- Mobile drawer -->
	<div class="samswiss-drawer-overlay"></div>
	<aside class="samswiss-mobile-drawer" id="samswiss-mobile-drawer" aria-label="<?php esc_attr_e( 'Menu mobile', 'samswiss-child' ); ?>">
		<div class="drawer-header">
			<span class="drawer-title"><?php bloginfo( 'name' ); ?></span>
			<button type="button" class="drawer-close" aria-label="<?php esc_attr_e( 'Chiudi menu', 'samswiss-child' ); ?>">
				<i class="fas fa-times" aria-hidden="true"></i>
			</button>
		</div>
		<nav aria-label="<?php esc_attr_e( 'Menu mobile', 'samswiss-child' ); ?>">
			<?php
			wp_nav_menu( array(
				'theme_location' => 'primary',
				'menu_class'     => 'samswiss-mobile-menu',
				'container'      => false,
				'fallback_cb'    => false,
			) );
			?>
		</nav>
		<div class="drawer-lang">
			<?php // Flag + name: the flag is the fast scan, the native name is the proof. ?>
			<?php samswiss_language_switcher( array( 'display' => 'inline', 'show_names' => true, 'show_flags' => true ) ); ?>
		</div>
	</aside>

	<?php if ( $show_actions ) : ?>
		<!-- Search overlay. The trigger and its JS already existed; this is the markup
		     they were reaching for, so the header's magnifier does something. It is a
		     plain GET form: without JavaScript the trigger simply does not open, and the
		     shop's own search field remains the working path. -->
		<div class="samswiss-search-modal" id="samswiss-search-modal" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( 'Cerca nel sito', 'samswiss-child' ); ?>" hidden>
			<div class="samswiss-search-modal__inner">
				<form class="samswiss-search-form" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
					<div class="samswiss-search-form__row">
						<?php
						samswiss_live_search_field( array(
							'id'           => 'samswiss-search-field',
							'label'        => __( 'Cerca nel sito', 'samswiss-child' ),
							'label_class'  => 'screen-reader-text',
							'input_class'  => 'samswiss-search-form__input',
							'submit_class' => 'samswiss-search-form__submit',
						) );
						?>
					</div>
				</form>
				<button type="button" class="search-modal-close" aria-label="<?php esc_attr_e( 'Chiudi la ricerca', 'samswiss-child' ); ?>">
					<i class="fas fa-times" aria-hidden="true"></i>
				</button>
			</div>
		</div>
	<?php endif; ?>

	<div id="content" class="site-content">
