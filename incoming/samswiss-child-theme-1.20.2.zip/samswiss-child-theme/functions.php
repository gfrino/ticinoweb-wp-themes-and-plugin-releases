<?php
/**
 * SAM SWISS Child Theme functions.
 *
 * Core functionality (CMS, email, SEO, WooCommerce support, CPTs) is provided by
 * the parent theme `ticinoweb-ai-theme`. This child theme reproduces the approved
 * SAM SA design natively, replacing Elementor. It must never redeclare parent
 * functions that are not guarded with function_exists().
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SAMSWISS_TEXTDOMAIN', 'samswiss-child' );

/**
 * Per-file cache-busting version based on the asset's mtime, so browsers cache
 * assets between loads and only re-download when a file actually changes.
 */
function samswiss_asset_version( $relative_path ) {
	$file = trailingslashit( get_stylesheet_directory() ) . ltrim( $relative_path, '/' );
	if ( file_exists( $file ) ) {
		return (string) filemtime( $file );
	}
	$theme = wp_get_theme();
	return $theme->get( 'Version' ) ? $theme->get( 'Version' ) : '1.0.0';
}

/**
 * Enqueue parent + child styles and scripts.
 */
function samswiss_enqueue_assets() {
	// 1. Parent theme stylesheet (design system base).
	wp_enqueue_style( 'ticinoweb-ai-style', get_template_directory_uri() . '/style.css', array(), '1.0.0' );

	// 2. Google Fonts used across the SAM SA design (extracted from the Elementor kit).
	wp_enqueue_style(
		'samswiss-google-fonts',
		'https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;600;700&family=Roboto+Slab:wght@400;500;600;700&family=Rajdhani:wght@400;500;600;700&display=swap',
		array(),
		null
	);

	// 3. FontAwesome for iconography. Dashicons is deliberately NOT enqueued:
	// it is an admin icon font (60 KB) and nothing on the front end renders a
	// .dashicons element — the parent only uses it for admin menus and for the
	// Google Reviews stars, which these templates never call.
	wp_enqueue_style( 'font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css', array(), '6.4.2' );

	// 4. Child theme CSS.
	wp_enqueue_style( 'samswiss-main', get_stylesheet_directory_uri() . '/assets/css/main.css', array( 'ticinoweb-ai-style', 'samswiss-google-fonts' ), samswiss_asset_version( 'assets/css/main.css' ) );

	if ( function_exists( 'is_woocommerce' ) ) {
		wp_enqueue_style( 'samswiss-woocommerce', get_stylesheet_directory_uri() . '/assets/css/woocommerce.css', array( 'samswiss-main' ), samswiss_asset_version( 'assets/css/woocommerce.css' ) );

		if ( is_shop() || is_product_taxonomy() ) {
			wp_enqueue_style( 'samswiss-filters', get_stylesheet_directory_uri() . '/assets/css/ajax-filters.css', array( 'samswiss-woocommerce' ), samswiss_asset_version( 'assets/css/ajax-filters.css' ) );
		}
	}

	// 4b. The Swiss typographic world established by "Macchine confezionatrici"
	// now governs every surface, the INTRO gateway included.
	$is_inner_page = true;
	$landing_slug  = function_exists( 'samswiss_current_landing_slug' ) ? samswiss_current_landing_slug() : '';
	$is_machines   = 'macchine-confezionatrici' === $landing_slug;
	$is_sorma      = 'sorma-group' === $landing_slug;
	$is_consumabili = 'imballaggi-e-consumabili' === $landing_slug;
	// The /tecnologie/{slug}/ pages (point 89) have no WP_Post behind them —
	// samswiss_current_landing_slug() can never match one — so they need their
	// own check, not just another landing_slug case.
	$is_tecnologia = '' !== get_query_var( 'samswiss_tech' );
	// home-swiss.css carries the .swiss-page world itself — tokens, type primitives,
	// the ruled link — so any surface built in that world needs it, not just the one
	// it was first written for.
	$needs_swiss_world = $is_machines || $is_sorma || $is_tecnologia || $is_consumabili || is_category();

	if ( $is_inner_page ) {
		wp_enqueue_style(
			'samswiss-archivo',
			'https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600;700;800&display=swap',
			array(),
			null
		);
	}

	if ( $needs_swiss_world ) {
		wp_enqueue_style(
			'samswiss-home-swiss',
			get_stylesheet_directory_uri() . '/assets/css/home-swiss.css',
			array( 'samswiss-main', 'samswiss-archivo' ),
			samswiss_asset_version( 'assets/css/home-swiss.css' )
		);
	}

	if ( $is_inner_page ) {
		$swiss_dependencies = array( 'samswiss-main', 'samswiss-archivo' );
		if ( wp_style_is( 'samswiss-woocommerce', 'enqueued' ) ) {
			$swiss_dependencies[] = 'samswiss-woocommerce';
		}
		if ( $needs_swiss_world ) {
			$swiss_dependencies[] = 'samswiss-home-swiss';
		}
		wp_enqueue_style(
			'samswiss-site-swiss',
			get_stylesheet_directory_uri() . '/assets/css/site-swiss.css',
			$swiss_dependencies,
			samswiss_asset_version( 'assets/css/site-swiss.css' )
		);

		// ORTOFRUTTA → SORMA GROUP. Last, so it can lean on both sheets above.
		if ( $is_sorma ) {
			wp_enqueue_style(
				'samswiss-sorma',
				get_stylesheet_directory_uri() . '/assets/css/sorma-swiss.css',
				array( 'samswiss-home-swiss', 'samswiss-site-swiss' ),
				samswiss_asset_version( 'assets/css/sorma-swiss.css' )
			);
		}

		// The ten /tecnologie/{slug}/ pages (point 89) — same pattern as Sorma above.
		if ( $is_tecnologia ) {
			wp_enqueue_style(
				'samswiss-tecnologie',
				get_stylesheet_directory_uri() . '/assets/css/tecnologie.css',
				array( 'samswiss-home-swiss', 'samswiss-site-swiss' ),
				samswiss_asset_version( 'assets/css/tecnologie.css' )
			);
		}

		// Landing page "Imballaggi e Consumabili" (GB Bernucci)
		if ( $is_consumabili ) {
			wp_enqueue_style(
				'samswiss-consumabili',
				get_stylesheet_directory_uri() . '/assets/css/imballaggi-consumabili.css',
				array( 'samswiss-home-swiss', 'samswiss-site-swiss' ),
				samswiss_asset_version( 'assets/css/imballaggi-consumabili.css' )
			);
		}

		// Sector category archives (Ortofrutta, Gastronomia, Carne/Pesce)
		if ( is_category() ) {
			wp_enqueue_style(
				'samswiss-settori',
				get_stylesheet_directory_uri() . '/assets/css/settori-swiss.css',
				array( 'samswiss-home-swiss', 'samswiss-site-swiss' ),
				samswiss_asset_version( 'assets/css/settori-swiss.css' )
			);
		}

		// The commerce sheet, loaded after the shared one and only where it applies:
		// the shop, the product archives, the checkout, the order-received page
		// (which reuses the order panel) and the single product — the last one
		// because its "Prodotti correlati" block renders the same product plates,
		// and without the sheet they fell back to the old ruled-grid look.
		// is_account_page() included after a live/local divergence: on the live
		// database WooCommerce's "my account" page is a different page than here, so
		// that surface was an account page there and a plain page here — and the
		// stylesheet loaded only in one of the two. Which page holds the account is a
		// WooCommerce setting; the theme must dress it wherever it is.
		$is_commerce = function_exists( 'is_shop' ) && (
			is_shop() || is_product_taxonomy() || is_product()
			|| is_cart() || is_checkout() || is_order_received_page()
			|| is_account_page()
		);

		if ( $is_commerce ) {
			wp_enqueue_style(
				'samswiss-commerce-swiss',
				get_stylesheet_directory_uri() . '/assets/css/commerce-swiss.css',
				array( 'samswiss-site-swiss' ),
				samswiss_asset_version( 'assets/css/commerce-swiss.css' )
			);
		}
	}

	// 5. Child theme JS. No jQuery dependency: main.js is entirely vanilla, so
	// declaring one would force 278 KB of jQuery onto pages that do not need it.
	wp_enqueue_script( 'samswiss-main', get_stylesheet_directory_uri() . '/assets/js/main.js', array(), samswiss_asset_version( 'assets/js/main.js' ), true );
	wp_localize_script( 'samswiss-main', 'samswiss_ajax', array(
		'ajax_url'     => admin_url( 'admin-ajax.php' ),
		'search_nonce' => wp_create_nonce( 'samswiss_live_search' ),
		'search_url'   => esc_url( home_url( '/' ) ),
		// Translated in PHP: a static .js file can never pass through gettext.
		'strings'  => array(
			'sending'       => esc_html__( 'Invio…', 'samswiss-child' ),
			'invalid_email' => esc_html__( 'Inserisci un indirizzo email valido.', 'samswiss-child' ),
			'network_error' => esc_html__( 'Errore di rete. Riprova.', 'samswiss-child' ),
			'searching'     => esc_html__( 'Ricerca in corso…', 'samswiss-child' ),
			'no_results'    => esc_html__( 'Nessun prodotto trovato', 'samswiss-child' ),
			/* translators: %s: number of results. */
			'result_count'  => esc_html__( '%s prodotti trovati', 'samswiss-child' ),
			'see_all'       => esc_html__( 'Vedi tutti i risultati', 'samswiss-child' ),
			'qty_less'      => esc_attr__( 'Diminuisci la quantità', 'samswiss-child' ),
			'qty_more'      => esc_attr__( 'Aumenta la quantità', 'samswiss-child' ),
		),
	) );

	if ( function_exists( 'is_woocommerce' ) && ( is_shop() || is_product_taxonomy() ) ) {
		wp_enqueue_script( 'samswiss-filters', get_stylesheet_directory_uri() . '/assets/js/ajax-filters.js', array( 'jquery' ), samswiss_asset_version( 'assets/js/ajax-filters.js' ), true );
		wp_localize_script( 'samswiss-filters', 'samswiss_filters', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'samswiss_filters_nonce' ),
		) );
	}
}
add_action( 'wp_enqueue_scripts', 'samswiss_enqueue_assets', 20 );

/**
 * Print a build marker in the head.
 *
 * Diagnostic, not decoration. When a deploy "changes nothing", the first question
 * is always which theme the server is actually running, and until now the only way
 * to answer it was to guess. One line of HTML comment settles it:
 *
 *   - comment absent          -> this child theme is NOT the active theme on that
 *                                install (or its parent is missing, in which case
 *                                WordPress never loads the child at all)
 *   - comment with an old version -> an older copy is deployed, or a page cache is
 *                                still serving HTML built before the upload
 *   - comment with this version    -> the theme IS live, and the problem is
 *                                downstream: asset cache, CDN, or a plugin
 *
 * It also reports the parent, because the child cannot run without it, and the
 * social implementation, which is the fastest visual thing to confirm.
 */
function samswiss_build_marker() {
	$theme  = wp_get_theme();
	$parent = $theme->parent();

	printf(
		"<!-- samswiss-child-theme %s | parent %s %s | social=%s -->\n",
		esc_html( $theme->get( 'Version' ) ),
		esc_html( $parent ? $parent->get( 'Name' ) : 'MANCANTE' ),
		esc_html( $parent ? $parent->get( 'Version' ) : '' ),
		function_exists( 'samswiss_social_links' ) ? 'inline-svg' : 'font-awesome'
	);
}
add_action( 'wp_head', 'samswiss_build_marker', 1 );

/**
 * Drop jquery-migrate on the front end.
 *
 * Migrate exists to shim jQuery 1.x-era APIs that were removed in 3.x. Nothing
 * in this theme uses jQuery at all, and the WooCommerce scripts that do are
 * current. That makes it 31 KB of blocking JavaScript with no consumer. It stays
 * loaded in the admin, where third-party plugin screens may still rely on it.
 */
function samswiss_drop_jquery_migrate( $scripts ) {
	if ( is_admin() || ! isset( $scripts->registered['jquery'] ) ) {
		return;
	}
	$scripts->registered['jquery']->deps = array_diff(
		$scripts->registered['jquery']->deps,
		array( 'jquery-migrate' )
	);
}
add_action( 'wp_default_scripts', 'samswiss_drop_jquery_migrate' );

/**
 * Preconnect to font/icon CDNs (network optimisation only).
 */
function samswiss_resource_hints( $hints, $relation ) {
	if ( 'preconnect' === $relation ) {
		$hints[] = array( 'href' => 'https://fonts.gstatic.com', 'crossorigin' => 'anonymous' );
		$hints[] = 'https://fonts.googleapis.com';
		$hints[] = 'https://cdnjs.cloudflare.com';
	}
	return $hints;
}
add_filter( 'wp_resource_hints', 'samswiss_resource_hints', 10, 2 );

/**
 * Child theme setup: register the extra category-menu location used by the
 * original SAM SA header (the parent already registers `primary`).
 */
function samswiss_child_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	register_nav_menus( array(
		'primary'       => __( 'Menu Principale (SAM SWISS)', 'samswiss-child' ),
		'category-menu' => __( 'Menu Categorie (SAM SWISS)', 'samswiss-child' ),
	) );
}
add_action( 'after_setup_theme', 'samswiss_child_setup', 20 );

/**
 * Body class marker for scoping child styles.
 */
function samswiss_body_classes( $classes ) {
	$classes[] = 'samswiss-child-theme';
	$classes[] = 'samswiss-swiss-world';
	return $classes;
}
add_filter( 'body_class', 'samswiss_body_classes' );

/**
 * Remove WPML-injected language items from theme nav menus. The child renders
 * its own flag-based language switcher (header topbar + footer bar), so WPML's
 * duplicated in-menu language list is stripped to avoid a double switcher.
 */
function samswiss_strip_wpml_language_menu_items( $items, $args ) {
	if ( empty( $items ) || ! is_array( $items ) ) {
		return $items;
	}
	foreach ( $items as $key => $item ) {
		$classes = isset( $item->classes ) ? (array) $item->classes : array();
		if ( array_intersect( array( 'menu-item-language', 'wpml-ls-menu-item', 'wpml-ls-item' ), $classes ) ) {
			unset( $items[ $key ] );
		}
	}
	return $items;
}
add_filter( 'wp_nav_menu_objects', 'samswiss_strip_wpml_language_menu_items', 20, 2 );

/**
 * Repair the category menu links and flag the current item.
 *
 * The migrated "Category menu" stores its links with a legacy /blog/category/
 * prefix, which no longer resolves on this install (it 404s and is bounced to
 * the home page by the parent theme). We rewrite those URLs at render time —
 * preferring the real term permalink so the link follows the active WPML
 * language — without touching the stored menu items.
 */
function samswiss_fix_category_menu_items( $items, $args ) {
	if ( empty( $items ) || ! is_array( $items ) ) {
		return $items;
	}
	$location = isset( $args->theme_location ) ? $args->theme_location : '';
	if ( 'category-menu' !== $location ) {
		return $items;
	}

	$current_term_id = ( is_category() || is_tax() ) ? (int) get_queried_object_id() : 0;

	foreach ( $items as $item ) {
		$term_id = 0;

		if ( 'taxonomy' === $item->type && ! empty( $item->object_id ) ) {
			$term_id = (int) $item->object_id;
		} elseif ( ! empty( $item->url ) && strpos( $item->url, '/category/' ) !== false ) {
			// Custom link: resolve the trailing slug back to a real category.
			$slug = basename( untrailingslashit( wp_parse_url( $item->url, PHP_URL_PATH ) ) );
			$term = $slug ? get_term_by( 'slug', $slug, 'category' ) : null;
			if ( $term && ! is_wp_error( $term ) ) {
				$term_id = (int) $term->term_id;
			}
		}

		if ( $term_id ) {
			$link = get_term_link( $term_id, 'category' );
			if ( ! is_wp_error( $link ) ) {
				$item->url = $link;
			}
			if ( $current_term_id && $term_id === $current_term_id ) {
				$item->classes[] = 'current-menu-item';
			}
		} elseif ( ! empty( $item->url ) ) {
			$item->url = str_replace( '/blog/category/', '/category/', $item->url );
		}
	}

	return $items;
}
add_filter( 'wp_nav_menu_objects', 'samswiss_fix_category_menu_items', 21, 2 );

/**
 * "Soluzioni" is a custom link to `home_url() . '#soluzioni'` — an anchor
 * INSIDE the home page, not a distinct destination. WordPress's own
 * current-item detection compares an item's URL against the current request
 * ignoring the `#fragment`, so on the home page it marks "Soluzioni" current
 * right alongside "Home" itself: two menu items underlined/highlighted at
 * once, which is what "non si dovrebbe evidenziare Soluzioni nel menu" was
 * reporting. Any custom-type item whose URL is an in-page anchor is the same
 * case — stripped generically, not just for this one item, so a future
 * anchor link doesn't reintroduce the same bug.
 *
 * On `wp_nav_menu_objects`, mutating `$item->classes` directly, NOT on the
 * `nav_menu_css_class` filter: the desktop menu renders through
 * `Samswiss_Walker_Nav_Menu` (inc/helpers.php), which reads `$item->classes`
 * straight off the item and never calls that filter — confirmed by testing,
 * the class-filter version fixed the mobile drawer (default walker) but left
 * the desktop bar showing both "Home" and "Soluzioni" current at once. Fixing
 * the item itself, before either walker runs, reaches both.
 */
function samswiss_strip_anchor_current_class( $items ) {
	foreach ( $items as $item ) {
		if ( 'custom' === $item->type && false !== strpos( $item->url, '#' ) ) {
			$item->classes = array_diff( (array) $item->classes, array( 'current-menu-item', 'current_page_item', 'current-menu-ancestor', 'current_page_parent', 'current_page_ancestor' ) );
			// `aria-current="page"` is driven by this separate boolean, not by the
			// classes array — left true, the anchor's <a> would still announce
			// itself as the current page to assistive tech even with the visual
			// classes gone.
			$item->current                = false;
			$item->current_item_ancestor  = false;
			$item->current_item_parent    = false;
		}
	}
	return $items;
}
add_filter( 'wp_nav_menu_objects', 'samswiss_strip_anchor_current_class', 22 );

// Child helpers (language switcher, nav walker, contact helpers).
require_once get_stylesheet_directory() . '/inc/helpers.php';

// WooCommerce customisations and native AJAX product filters are loaded in later
// phases; the files are require_once-guarded so partial deploys stay safe.
foreach ( array( 'inc/woocommerce.php', 'inc/commerce-swiss.php', 'inc/account.php', 'inc/commerce-pages.php', 'inc/social.php', 'inc/permalink-guard.php', 'inc/menu-i18n-fix.php', 'inc/tecnologie.php', 'inc/settori-data.php', 'inc/consumabili-bootstrap.php', 'inc/diagnostics.php', 'inc/contact-form.php', 'inc/newsletter.php', 'inc/live-search.php', 'inc/ajax-filters.php', 'inc/wpml-seed.php', 'inc/wpml-translations.php', 'inc/wpml-wc-translations.php', 'inc/second-hand-seed.php', 'inc/content-seed.php', 'inc/gelateria-filter.php', 'inc/featured-secondhand.php', 'inc/flyers.php' ) as $inc ) {
	$path = get_stylesheet_directory() . '/' . $inc;
	if ( file_exists( $path ) ) {
		require_once $path;
	}
}
