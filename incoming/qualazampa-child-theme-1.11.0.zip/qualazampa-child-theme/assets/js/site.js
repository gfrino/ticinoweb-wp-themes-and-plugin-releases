(() => {
  'use strict';
  const header=document.querySelector('[data-header]');
  if(!header)return;
  const toggle=header.querySelector('.qz-menu-toggle'),nav=header.querySelector('#qz-navigation');
  const details=header.querySelector('[data-animal-menu]'),summary=details?.querySelector('summary'),panel=details?.querySelector('[data-animal-panel]');
  const scrim=document.querySelector('[data-menu-scrim]');
  const small=matchMedia('(max-width:760px)'),reduced=matchMedia('(prefers-reduced-motion:reduce)');
  let closing=0,opening=0;
  function animals(open,restoreFocus=false){
    if(!details)return;
    clearTimeout(closing);cancelAnimationFrame(opening);opening=0;
    summary.setAttribute('aria-expanded',String(open));panel.inert=!open;
    if(open){
      details.open=true;
      // One bounded style flush lets the drawer unfold from its navigation origin.
      panel.getBoundingClientRect();
      opening=requestAnimationFrame(()=>{header.setAttribute('data-animals-open','');opening=0;});
    }else{
      header.removeAttribute('data-animals-open');
      if(restoreFocus)summary.focus();
      if(reduced.matches)details.open=false;else closing=setTimeout(()=>{details.open=false;},210);
    }
  }
  function closeNav(){header.removeAttribute('data-nav-open');toggle?.setAttribute('aria-expanded','false');animals(false);}
  function size(){document.documentElement.style.setProperty('--qz-header',(header.offsetHeight+(parseFloat(getComputedStyle(header).top)||0))+'px');}
  toggle?.addEventListener('click',()=>{const open=!header.hasAttribute('data-nav-open');if(!open)animals(false);header.toggleAttribute('data-nav-open',open);toggle.setAttribute('aria-expanded',String(open));});
  summary?.addEventListener('click',event=>{event.preventDefault();animals(!header.hasAttribute('data-animals-open')&&!opening);});
  summary?.addEventListener('keydown',event=>{if(event.key==='ArrowDown'){event.preventDefault();animals(true);requestAnimationFrame(()=>panel.querySelector('a')?.focus());}});
  document.addEventListener('keydown',event=>{
    if(event.key!=='Escape')return;
    if(details?.open){event.preventDefault();animals(false,true);}
    else if(header.hasAttribute('data-nav-open')){closeNav();toggle?.focus();}
  });
  document.addEventListener('click',event=>{if(details?.open&&!details.contains(event.target))animals(false);if(header.hasAttribute('data-nav-open')&&!header.contains(event.target))closeNav();});
  document.addEventListener('focusin',event=>{if(details?.open&&!details.contains(event.target))animals(false);});
  nav?.addEventListener('click',event=>{if(event.target.closest('a'))closeNav();});
  scrim?.addEventListener('wheel',event=>event.preventDefault(),{passive:false});
  header.addEventListener('wheel',event=>{if(details?.open&&!small.matches&&(!panel.contains(event.target)||panel.scrollHeight<=panel.clientHeight))event.preventDefault();},{passive:false});
  small.addEventListener('change',()=>{closeNav();size();});
  reduced.addEventListener('change',()=>{if(!header.hasAttribute('data-animals-open')){clearTimeout(closing);if(details)details.open=false;}});
  new ResizeObserver(size).observe(header);
  header.setAttribute('data-nav-ready','');header.setAttribute('data-menu-ready','');
  if(details){panel.inert=!details.open;summary.setAttribute('aria-expanded',String(details.open));}
  size();
})();
