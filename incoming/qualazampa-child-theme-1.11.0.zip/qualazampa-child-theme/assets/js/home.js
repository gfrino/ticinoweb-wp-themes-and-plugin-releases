(() => {
  'use strict';
  const opening=document.querySelector('[data-opening]');
  if(!opening)return;
  const reduced=matchMedia('(prefers-reduced-motion:reduce)');
  const desktop=matchMedia('(min-width:1101px) and (min-height:800px)');
  const clamp=v=>Math.max(0,Math.min(1,v));
  const range=(a,b,v)=>clamp((v-a)/(b-a));
  const smooth=(a,b,v)=>{const n=range(a,b,v);return n*n*(3-2*n);};
  const round=v=>Number(v.toFixed(3));

  let featureScene=true,syncFeature=()=>{};
  // Fifteen native products, three new cards per desktop turn, native touch browsing.
  const feature=document.querySelector('[data-feature]');
  if(feature){
    const track=feature.querySelector('[data-feature-track]'),slides=[...feature.querySelectorAll('[data-feature-slide]')];
    const controls=feature.querySelector('[data-feature-controls]');
    const counter=feature.querySelector('[data-feature-count]');
    const edge=Math.min(3,slides.length),mobile=matchMedia('(max-width:760px)');
    let perView=mobile.matches?1:Math.min(3,slides.length),width=track.clientWidth/perView,index=0,timer=0,settle=0,visible=false,hovered=false,focused=false,paused=false;
    function clone(slide){const copy=slide.cloneNode(true);copy.inert=true;copy.setAttribute('aria-hidden','true');copy.removeAttribute('data-feature-slide');copy.querySelectorAll('[id]').forEach(el=>el.removeAttribute('id'));return copy;}
    track.prepend(...slides.slice(-edge).map(clone));track.append(...slides.slice(0,edge).map(clone));
    function stop(){clearTimeout(timer);timer=0;feature.removeAttribute('data-auto');}
    function arm(){stop();if(!featureScene||width<1||slides.length<=perView||paused||hovered||focused||!visible||document.hidden||reduced.matches)return;feature.setAttribute('data-auto','playing');timer=setTimeout(()=>go(index+perView),3800);}
    function update(){
      const physical=Math.round(track.scrollLeft/Math.max(1,width));index=((physical-edge)%slides.length+slides.length)%slides.length;
      if(physical<edge||physical>=slides.length+edge)track.scrollTo({left:(index+edge)*width,behavior:'instant'});
      counter.textContent=perView===1?`${index+1} / ${slides.length}`:`${index+1}–${Math.min(index+perView,slides.length)} / ${slides.length}`;
      slides.forEach((slide,i)=>{slide.inert=i<index||i>=index+perView;});arm();
    }
    let lastWidth=0;
    function resize(){if(track.clientWidth<1||track.clientWidth===lastWidth)return;lastWidth=track.clientWidth;perView=mobile.matches?1:Math.min(3,slides.length);width=track.clientWidth/perView;index=Math.floor(index/perView)*perView;track.scrollTo({left:(index+edge)*width,behavior:'instant'});update();}
    function go(target){stop();track.scrollTo({left:(target+edge)*width,behavior:reduced.matches?'instant':'smooth'});}
    feature.addEventListener('pointerenter',()=>{hovered=true;stop();});feature.addEventListener('pointerleave',()=>{hovered=false;arm();});
    feature.addEventListener('focusin',()=>{focused=true;paused=true;stop();});feature.addEventListener('focusout',()=>{focused=false;requestAnimationFrame(()=>{focused=feature.contains(document.activeElement);arm();});});
    track.addEventListener('pointerdown',()=>{paused=true;stop();},{passive:true});track.addEventListener('scroll',()=>{stop();clearTimeout(settle);settle=setTimeout(update,140);},{passive:true});
    track.addEventListener('keydown',event=>{if(event.target===track&&['ArrowLeft','ArrowRight'].includes(event.key)){event.preventDefault();paused=true;go(index+(event.key==='ArrowLeft'?-perView:perView));}});
    if(typeof ResizeObserver==='function')new ResizeObserver(resize).observe(track);
    if(typeof IntersectionObserver==='function')new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;arm();},{threshold:.25}).observe(feature);
    document.addEventListener('visibilitychange',arm);reduced.addEventListener('change',arm);mobile.addEventListener('change',resize);
    syncFeature=()=>{feature.inert=!featureScene;if(featureScene)arm();else stop();};
    controls.hidden=false;feature.setAttribute('data-ready','');resize();
  }

  const departments=document.querySelector('[data-worlds]');
  const worldsStage=document.querySelector('[data-worlds-stage]');
  const animalLandscape=departments?.querySelector('.qz-animals');
  const animals=[...document.querySelectorAll('[data-animal]')].map(link=>({link,image:link.querySelector('.qz-animal__image'),photo:link.querySelector('.qz-animal__image img'),label:link.querySelector('.qz-animal__label'),story:link.querySelector('.qz-animal__story'),drawing:link.querySelector('.qz-animal__drawing')}));
  const controls=departments?.querySelector('[data-world-controls]');
  const previous=departments?.querySelector('[data-world-prev]');
  const next=departments?.querySelector('[data-world-next]');
  const counter=departments?.querySelector('[data-world-count]');
  const cuddle=document.querySelector('[data-cuddle]');
  const story=document.querySelector('[data-chapter="story"]');
  const heroStory=opening.querySelector('.qz-hero__story'),heroCopy=opening.querySelector('[data-hero-copy]');
  const heroPin=opening.querySelector('[data-opening-pin]'),heroTarget=opening.querySelector('[data-hero-target]'),heroPhoto=opening.querySelector('[data-hero-photo]'),heroImage=heroPhoto?.querySelector('img'),heroShade=opening.querySelector('.qz-hero__shade');
  let ambientVisible=false;
  const ambient=()=>departments?.toggleAttribute('data-ambient-active',ambientVisible&&!document.hidden&&!reduced.matches);
  if(typeof IntersectionObserver==='function'&&departments)new IntersectionObserver(entries=>{ambientVisible=entries[0].isIntersecting;ambient();}).observe(departments);
  document.addEventListener('visibilitychange',ambient);reduced.addEventListener('change',ambient);
  let lenis=null,frame=0,dirty=true,immersive=false,lastY=-1,geometry=null,animalIndex=0,heroShop=false;
  const companion=typeof window.QZAnimalMotion==='function'?new window.QZAnimalMotion(wake):null;
  const heroHeadings=[...opening.querySelectorAll('[data-hero-heading]')],heroDescriptions=[...opening.querySelectorAll('[data-hero-description]')];
  const placed=el=>{const r=el.getBoundingClientRect();return {top:r.top+scrollY,height:r.height};};
  function measure(){
    const headerElement=document.querySelector('[data-header]');
    const header=headerElement?headerElement.offsetHeight+(parseFloat(getComputedStyle(headerElement).top)||0):0;
    const marker=document.querySelector('[data-flow-marker="story"]');
    const stageHeight=worldsStage?.offsetHeight||1,animalWidth=animals[0]?.link.offsetWidth||1;
    const landscapeTop=departments&&animalLandscape?animalLandscape.getBoundingClientRect().top-worldsStage.getBoundingClientRect().top:0;
    if(departments&&animalLandscape){const trim=Math.max(0,Math.min(300,stageHeight-landscapeTop-125-animalWidth-(animals[0]?.label.offsetHeight||40)-90));departments.style.setProperty('--worlds-trim',`${round(trim)}px`);}
    let hero=null;
    if(heroPin&&heroTarget&&heroImage){
      const pin=heroPin.getBoundingClientRect(),target=heroTarget.getBoundingClientRect(),w=heroPin.clientWidth,h=heroPin.offsetHeight,ratio=heroImage.naturalWidth/heroImage.naturalHeight||1.5;
      const iw=Math.max(w,h*ratio),ih=iw/ratio,fw=Math.max(target.width,target.height*ratio),fh=fw/ratio;
      hero={w,h,iw,ih,copyShift:Math.max(0,((heroStory?.offsetHeight||0)-(heroCopy?.offsetHeight||0))/2),x0:(w-iw)/2,y0:(h-ih)*.6,x:target.left-pin.left,y:target.top-pin.top,width:target.width,height:target.height,xf:target.left-pin.left+(target.width-fw)/2,yf:target.top-pin.top+(target.height-fh)*.6,scale:fw/iw};
      heroImage.style.width=`${iw}px`;heroImage.style.height=`${ih}px`;
    }
    geometry={hero,header,viewport:innerHeight,opening:placed(opening),departments:departments?placed(departments):null,
      worldLandscapeTop:landscapeTop,worldWidth:animalLandscape?.offsetWidth||1,animalWidth:animals[0]?.link.offsetWidth||1,worldStoryWidth:animals[0]?.story.offsetWidth||290,worldStageHeight:worldsStage?.offsetHeight||1,selection:placed(document.querySelector('[data-chapter="selection"]')),
      cuddle:cuddle?placed(cuddle):null,story:story?{top:marker?marker.getBoundingClientRect().top+scrollY:placed(story).top,height:story.offsetHeight}:null};
    const storyFits=story&&story.offsetHeight<=innerHeight-header;
    story?.toggleAttribute('data-stack-fit',!!storyFits);
    dirty=false;
  }
  function reset(){
    companion?.clear();
    [opening,heroPhoto,heroImage,heroShade,departments,cuddle,story,document.querySelector('[data-chapter="selection"]')].forEach(el=>el?.removeAttribute('style'));
    story?.removeAttribute('data-stack-fit');
    animals.forEach(a=>{[a.link,a.image,a.photo,a.label,a.story,a.drawing].forEach(el=>el?.removeAttribute('style'));a.link.inert=false;});
    if(controls)controls.hidden=!immersive;
  }
  function configure(){
    lenis?.destroy();lenis=null;
    immersive=desktop.matches&&!reduced.matches;
    document.documentElement.toggleAttribute('data-qz-motion',immersive);
    reset();heroShop=false;opening.removeAttribute('data-hero-shop');heroHeadings.concat(heroDescriptions).forEach(el=>el.setAttribute('aria-hidden',String(el.dataset.heroHeading==='2'||el.dataset.heroDescription==='2')));featureScene=!immersive;syncFeature();dirty=true;lastY=-1;
    if(immersive&&typeof Lenis==='function')lenis=new Lenis({lerp:.085,smoothWheel:true,syncTouch:false,autoRaf:false,anchors:false});
    wake();
  }
  function goAnimal(i){
    if(!immersive||!geometry||!animals.length)return;
    const target=Math.max(0,Math.min(animals.length-1,i));
    const travel=Math.max(1,geometry.departments.height-geometry.worldStageHeight);
    const progress=(target/(animals.length-1))*.82;
    const y=geometry.departments.top-geometry.header+travel*progress;
    if(lenis)lenis.scrollTo(y);else window.scrollTo({top:y,behavior:reduced.matches?'instant':'smooth'});
    wake();
  }
  previous?.addEventListener('click',()=>goAnimal(animalIndex-1));
  next?.addEventListener('click',()=>goAnimal(animalIndex+1));
  function paint(y){
    const g=geometry;
    let liveDrawing=null,liveWidth=0;
    if(g.departments&&animals.length&&y+g.viewport>=g.departments.top-100&&y<=g.departments.top+g.departments.height){
      const wp=clamp((y+g.header-g.departments.top)/Math.max(1,g.departments.height-g.worldStageHeight));
      const raw=range(0,.82,wp)*(animals.length-1);
      const base=Math.floor(raw),fraction=raw-base;
      // A continuous dissolve preserves one complete photograph beneath its successor.
      const blend=smooth(0,1,fraction),tour=base+blend,resolve=smooth(.85,.985,wp);
      const mainX=g.worldWidth*.24-g.animalWidth/2;
      const gap=(g.worldWidth-animals.length*g.animalWidth)/Math.max(1,animals.length-1);
      const portraitScale=Math.min(440,g.worldStageHeight*.52)/g.animalWidth;
      const textLeft=g.animalWidth+(portraitScale-1)*g.animalWidth/2+(g.worldWidth<1200?80:100);
      const drawingBase=Math.min(340,Math.max(110,g.worldWidth-mainX-textLeft-g.worldStoryWidth-24));
      const drawingWidth=drawingBase*1.14;
      const drawingDrop=Math.min(110,Math.max(64,g.worldStageHeight*.12),Math.max(0,g.worldStageHeight-g.worldLandscapeTop-150-g.animalWidth/2-drawingWidth/2-16));
      animalIndex=Math.min(animals.length-1,Math.round(tour));
      if(previous){previous.disabled=animalIndex===0;next.disabled=animalIndex===animals.length-1;counter.textContent=`${animalIndex+1} / ${animals.length}`;}
      if(controls){controls.style.opacity=1-resolve;controls.inert=resolve>.5;}
      animals.forEach((animal,i)=>{
        const photoOpacity=i===base?1:(i===base+1?blend:0);
        const copy=i===animalIndex?1:0;
        const x=mainX*(1-resolve)+i*(g.animalWidth+gap)*resolve;
        animal.link.style.transform=`translate(${round(x)}px,${round(150*(1-resolve)+125*resolve)}px)`;
        animal.link.style.opacity=1;animal.link.style.zIndex=String(i+1);animal.link.inert=resolve<.75&&i!==animalIndex;
        animal.image.style.transform=`scale(${round(portraitScale*(1-resolve)+resolve)})`;
        const opacity=round(photoOpacity+(1-photoOpacity)*resolve);
        animal.image.style.opacity=opacity;animal.image.style.visibility=opacity<.001?'hidden':'visible';
        if(animal.photo)animal.photo.style.transform=`scale(${round(1+(.025+.035*clamp(tour-i+1))*(1-resolve))})`;
        animal.label.style.opacity=resolve;
        animal.story.style.left=`${round(textLeft)}px`;
        animal.story.style.opacity=round(copy*(1-resolve));
        animal.story.style.transform=`translateY(${copy?0:12}px)`;
        animal.story.style.visibility=copy*(1-resolve)<.02?'hidden':'visible';
        if(animal.drawing){
          const ink=(i===base?1-blend:(i===base+1?blend:0))*(1-resolve);
          animal.drawing.style.width=`${round(drawingWidth)}px`;
          animal.drawing.style.left=`${round(g.worldWidth-mainX-drawingBase)}px`;
          animal.drawing.style.top=`${round((g.animalWidth-drawingWidth)/2+drawingDrop)}px`;
          animal.drawing.style.opacity=round(ink);
          animal.drawing.style.visibility=ink<.001?'hidden':'visible';
          animal.drawing.style.transform=`translateY(${round(10*(1-ink))}px) scale(${round(.97+.03*ink)})`;
          if(i===animalIndex&&ink>.5&&resolve<.2){liveDrawing=animal.drawing;liveWidth=drawingWidth;}
        }
      });
    }
    companion?.select(document.documentElement.hasAttribute('data-qz-keyboard')?null:liveDrawing,liveWidth);
    if(g.hero&&y<=g.opening.top+g.opening.height){
      const h=g.hero,t=range(0,.9,(y+g.header-g.opening.top)/Math.max(1,g.opening.height-h.h)),p=1-Math.pow(1-t,3);
      const shop=p>(heroShop ? .18 : .3);
      if(shop!==heroShop){heroShop=shop;opening.toggleAttribute('data-hero-shop',shop);heroHeadings.concat(heroDescriptions).forEach(el=>el.setAttribute('aria-hidden',String((el.dataset.heroHeading||el.dataset.heroDescription)!==(shop?'2':'1'))));}
      opening.style.setProperty('--hero-story-y',`${round(h.copyShift*(1-p))}px`);
      const reveal=smooth(.3,.72,p);opening.style.setProperty('--hero-products',round(reveal));
      const showProducts=p>.72;if(showProducts!==featureScene){featureScene=showProducts;syncFeature();}
      const mix=(a,b)=>a+(b-a)*p;
      heroPhoto.style.clipPath=`inset(${round(h.y*p)}px ${round((h.w-h.x-h.width)*p)}px ${round((h.h-h.y-h.height)*p)}px ${round(h.x*p)}px round ${round(150*p)}px ${round(12*p)}px ${round(12*p)}px ${round(12*p)}px)`;
      heroImage.style.transform=`translate(${round(mix(h.x0,h.xf))}px,${round(mix(h.y0,h.yf))}px) scale(${round(mix(1,h.scale))})`;
      if(heroShade)heroShade.style.opacity=round(1-p);
    }
    if(g.selection){const p=smooth(0,1,(y+g.viewport-g.selection.top)/(g.viewport*.65));document.querySelector('[data-chapter="selection"]').style.setProperty('--selection-y',`${round(65*(1-p))}px`);}
    if(g.cuddle){const c=clamp((y+g.viewport-g.cuddle.top)/(g.cuddle.height+g.viewport));cuddle.style.setProperty('--cuddle-inset',`${round(6*(1-smooth(.05,.5,c)))}%`);cuddle.style.setProperty('--cuddle-y',`${round(45*(.5-c))}px`);cuddle.style.setProperty('--cuddle-scale',round(1.035+.025*c));}
    if(g.story){const s=smooth(0,1,(y+g.viewport-g.story.top)/(g.story.height+g.viewport*.4));story.style.setProperty('--story-photo-y',`${round(25*(1-s))}px`);story.style.setProperty('--story-copy-y',`${round(-15*(1-s))}px`);}
  }
  function render(time){
    frame=0;if(document.hidden)return;
    lenis?.raf(time);
    if(immersive){if(dirty)measure();const y=window.scrollY;if(y!==lastY){paint(y);lastY=y;}}
    const gesturing=immersive&&companion?.tick(time);
    if(lenis?.isScrolling||gesturing)wake();
  }
  function wake(){if(!frame&&!document.hidden)frame=requestAnimationFrame(render);}
  addEventListener('scroll',wake,{passive:true});addEventListener('wheel',wake,{passive:true});
  document.addEventListener('click',event=>{
    if(!lenis||event.defaultPrevented||event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;
    const link=event.target.closest('a[href]');if(!link||link.target==='_blank')return;
    const url=new URL(link.href,location.href);if(url.origin!==location.origin||url.pathname!==location.pathname||url.search!==location.search||!url.hash)return;
    let target;try{target=document.getElementById(decodeURIComponent(url.hash.slice(1)));}catch{return;}if(!target)return;
    event.preventDefault();const padding=parseFloat(getComputedStyle(document.documentElement).scrollPaddingTop)||0;
    history.pushState(history.state,'',url.hash);lenis.scrollTo(target.getBoundingClientRect().top+window.scrollY-padding);wake();
  });
  document.addEventListener('keydown',event=>{if(event.key==='Tab'){document.documentElement.setAttribute('data-qz-keyboard','');dirty=true;lastY=-1;wake();}});
  document.addEventListener('pointerdown',()=>{document.documentElement.removeAttribute('data-qz-keyboard');dirty=true;lastY=-1;wake();},{passive:true});
  addEventListener('resize',()=>{dirty=true;lastY=-1;wake();},{passive:true});
  reduced.addEventListener('change',configure);desktop.addEventListener('change',configure);
  document.addEventListener('visibilitychange',()=>{if(document.hidden){companion?.clear();cancelAnimationFrame(frame);frame=0;}else{dirty=true;lastY=-1;wake();}});
  addEventListener('pagehide',()=>companion?.clear());
  if(typeof ResizeObserver==='function'){const observer=new ResizeObserver(()=>{dirty=true;lastY=-1;wake();});[opening,document.querySelector('[data-header]'),departments,cuddle,story].filter(Boolean).forEach(el=>observer.observe(el));}
  heroImage?.addEventListener('load',()=>{dirty=true;lastY=-1;wake();});
  document.fonts?.ready.then(()=>{dirty=true;lastY=-1;wake();});
  configure();
})();
