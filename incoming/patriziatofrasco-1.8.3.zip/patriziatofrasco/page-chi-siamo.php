<?php
/**
 * Template Name: Chi Siamo
 */
get_header();
?>

<style>
/* Custom styles for Chi Siamo - DARK THEME */
.site-main {
    background-color: var(--color-bg-body) !important;
}

.chi-siamo-intro {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: var(--space-xl);
    align-items: center;
    margin-top: 0;
    margin-bottom: var(--space-md);
}
.chi-siamo-text h2 {
    color: var(--color-secondary);
    font-size: 2.5rem;
    margin-bottom: var(--space-md);
    font-family: var(--font-heading);
}
.chi-siamo-text p {
    font-size: 1.15rem;
    line-height: 1.8;
    color: var(--color-text-main);
    margin-bottom: var(--space-md);
}
.chi-siamo-image {
    border-radius: var(--radius);
    overflow: hidden;
    box-shadow: 0 15px 35px rgba(0,0,0,0.1);
    background: transparent;
    font-size: 0;
    line-height: 0;
}
.chi-siamo-image img {
    width: 100%;
    height: auto;
    display: block;
    margin: 0;
    padding: 0;
    border: none;
    transition: transform 0.5s ease;
}
.chi-siamo-image:hover img {
    transform: scale(1.05);
}

/* Cards Section */
.team-section {
    background: var(--color-bg-body);
    padding: var(--space-xl) 0 var(--space-xxl) 0;
    margin-top: 0;
    border-top: 1px solid rgba(0, 0, 0, 0.05);
}
.team-header {
    text-align: center;
    max-width: 800px;
    margin: 0 auto var(--space-xl) auto;
}
.team-header h2 {
    color: var(--color-secondary);
    font-size: 2.5rem;
    margin-bottom: var(--space-sm);
    font-family: var(--font-heading);
}
.team-header p {
    color: var(--color-text-main);
    font-size: 1.15rem;
    line-height: 1.8;
}
.team-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: var(--space-lg);
}
.team-card {
    background: var(--color-bg-pure-white);
    padding: 30px 25px;
    border-radius: var(--radius);
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.04);
    border: 1px solid rgba(0, 0, 0, 0.05);
    transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
    position: relative;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    text-align: center;
}
.team-card::before {
    content: '';
    position: absolute;
    top: 0; left: 0; width: 100%; height: 4px;
    background: linear-gradient(90deg, var(--color-primary), var(--color-accent));
    transform: scaleX(0);
    transform-origin: left;
    transition: transform 0.4s cubic-bezier(0.16, 1, 0.3, 1);
    z-index: 2;
}
.team-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 35px rgba(0, 0, 0, 0.07);
}
.team-card:hover::before {
    transform: scaleX(1);
}
.team-card-bg-number {
    position: absolute;
    right: -10px;
    bottom: -30px;
    font-size: 8rem;
    font-family: var(--font-heading);
    font-weight: 700;
    color: rgba(60, 105, 231, 0.02);
    line-height: 1;
    transition: all 0.5s ease;
    z-index: 0;
    pointer-events: none;
}
.team-card:hover .team-card-bg-number {
    transform: scale(1.1) rotate(-5deg);
    color: rgba(60, 105, 231, 0.04);
}
.member-photo {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    object-fit: cover;
    margin: 0 auto 12px auto;
    display: block;
    background-color: var(--color-bg-body);
    position: relative;
    z-index: 1;
    border: 3px solid var(--color-bg-pure-white);
    box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.05), 0 6px 15px rgba(0, 0, 0, 0.06);
}
.team-card h3 {
    color: var(--color-primary-dark);
    font-size: 1.35rem;
    margin-top: 5px;
    margin-bottom: 15px;
    position: relative;
    z-index: 1;
    font-family: var(--font-heading);
    line-height: 1.3;
}
.team-card h3 small {
    display: block;
    font-size: 0.85rem;
    font-weight: 600;
    color: var(--color-accent);
    margin-top: 4px;
    font-family: var(--font-body);
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
.team-card p {
    color: var(--color-text-main);
    line-height: 1.6;
    position: relative;
    z-index: 1;
    font-size: 0.95rem;
    text-align: left;
    margin: 0;
}

@media (max-width: 768px) {
    .chi-siamo-intro { grid-template-columns: 1fr; }
    .team-grid { grid-template-columns: 1fr; }
}
</style>

<main id="primary" class="site-main page-content" style="padding-bottom: 0;">

    <?php 
    while ( have_posts() ) :
        the_post();
        $has_thumbnail = has_post_thumbnail();
        $thumbnail_url = $has_thumbnail ? get_the_post_thumbnail_url(get_the_ID(), 'full') : '';
        $header_class = $has_thumbnail ? 'page-header-cinematic has-bg' : 'page-header-cinematic no-bg';
        ?>
        <header class="<?php echo esc_attr($header_class); ?>" <?php if ($has_thumbnail) echo 'style="background-image: url(\'' . esc_url($thumbnail_url) . '\');"'; ?>>
            <div class="page-header-overlay"></div>
            <div class="container page-header-inner animate-on-scroll">
                <h1 class="page-title"><?php the_title(); ?></h1>
                <h2 style="color: var(--color-accent); font-size: 1.5rem; font-weight: 500; font-family: var(--font-heading); margin-top: var(--space-sm);">Scopri la storia e le persone dietro al Patriziato.</h2>
            </div>
        </header>

        <div class="container" style="padding: 40px 0 80px 0;">
            <div class="page-content custom-gutenberg-layout">
                <?php the_content(); ?>
            </div>
        </div>
    <?php endwhile; ?>

</main>

<?php get_footer(); ?>
