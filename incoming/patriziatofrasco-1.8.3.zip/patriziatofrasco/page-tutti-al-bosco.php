<?php
/**
 * Template Name: Tutti al Bosco
 * Template Post Type: page, punto_interesse
 */
get_header();

$upload_base = parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH );
$hero_img = $upload_base . '/2026/07/PHOTO-2024-07-09-23-07-05.webp';
?>

<style>
/* Reusing the reliable layout structure */
.rifugio-layout {
    display: grid;
    grid-template-columns: 1fr 420px;
    gap: var(--space-xl);
    padding: var(--space-xl) 0;
}

.rifugio-main-content {
    font-size: 1.15rem;
    line-height: 1.8;
}

.rifugio-main-content h3 {
    color: var(--color-primary-dark);
    font-size: 2rem;
    margin: var(--space-xl) 0 var(--space-md) 0;
}

.rifugio-main-content h4 {
    color: var(--color-primary);
    font-size: 1.5rem;
    margin: var(--space-lg) 0 var(--space-sm) 0;
    padding-bottom: var(--space-xs);
    border-bottom: 2px solid var(--color-bg-body);
}

.rifugio-main-content p {
    margin-bottom: var(--space-md);
}

.rifugio-main-content ul {
    margin-bottom: var(--space-md);
    padding-left: var(--space-lg);
}

.rifugio-main-content li {
    margin-bottom: var(--space-sm);
}

/* Sidebar Widget Card */
.rifugio-sidebar {
    position: sticky;
    top: 100px;
    height: fit-content;
}

.tech-details {
    background: var(--color-bg-pure-white);
    padding: 25px;
    border-radius: var(--radius);
    box-shadow: 0 10px 30px rgba(0,0,0,0.08);
    border-top: 4px solid var(--color-accent);
    margin-bottom: var(--space-lg);
}

.tech-details h3 {
    color: var(--color-primary-dark);
    margin-bottom: 1rem;
    text-align: center;
    font-size: 1.4rem;
}

.tech-details ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

.tech-details li {
    display: flex;
    justify-content: space-between;
    padding: 12px 0;
    border-bottom: 1px solid var(--color-bg-body);
    font-size: 0.95rem;
}

.tech-details li:last-child {
    border-bottom: none;
}

.tech-details strong {
    color: var(--color-text);
}

.tech-details span {
    color: var(--color-text-light);
    font-weight: 500;
}

.content-image {
    max-width: 600px;
    width: 100%;
    margin: var(--space-md) auto;
    display: block;
    border-radius: var(--radius);
    box-shadow: 0 4px 15px rgba(0,0,0,0.05);
}

.cerebral-logo {
    max-width: 200px;
    display: block;
    margin: var(--space-xl) auto 0;
}

/* Lightbox Styles */
.lightbox {
    position: fixed;
    z-index: 99999;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0,0,0,0.92);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    pointer-events: none;
    transition: opacity 0.3s ease;
}
.lightbox.active {
    opacity: 1;
    pointer-events: auto;
}
.lightbox img {
    max-width: 90%;
    max-height: 90vh;
    border-radius: 4px;
    box-shadow: 0 10px 50px rgba(0,0,0,0.8);
    transition: transform 0.3s ease;
}
.lightbox-close {
    position: absolute;
    top: 20px;
    right: 30px;
    color: white;
    font-size: 45px;
    cursor: pointer;
    line-height: 1;
    user-select: none;
    transition: color 0.2s;
}
.lightbox-close:hover { color: var(--color-accent); }

@media (max-width: 992px) {
    .rifugio-layout {
        grid-template-columns: 1fr;
    }
    .rifugio-sidebar {
        position: static;
        margin-top: var(--space-lg);
    }
}
</style>

<div class="page-header-cinematic">
    <div class="page-header-bg" style="background-image: url('<?php echo esc_url($hero_img); ?>'); background-position: center 40%;"></div>
    <div class="page-header-overlay"></div>
    
    <div class="container page-header-inner animate-on-scroll">
        <h1 class="page-title" style="margin-bottom: 0;">Tutti al Bosco</h1>
    </div>
</div>

<main id="primary" class="site-main">
    <div class="container">
        
        <div class="rifugio-layout">
            
            <div class="rifugio-main-content animate-on-scroll">
                
                <h3>L'offerta inclusiva</h3>
                <p><strong>“Tutti al Bosco”</strong> è l’offerta inclusiva dell’Associazione BoBosco, nata dalla collaborazione con la Fondazione Cerebral: noleggiando una carrozzina elettrica di altissima qualità, adatta anche ai sentieri sconnessi, le persone con difficoltà motorie possono ora scoprire in sicurezza e tranquillità le meraviglie dell’alta Val Verzasca.</p>

                <h4>Noleggio</h4>
                <p>Noleggiare la carrozzina è semplice:</p>
                <ul>
                    <li>prenotate il mezzo completando il formulario di contatto;</li>
                    <li>attendete l’email di conferma da parte nostra;</li>
                    <li>recatevi a Sonogno il giorno prestabilito.</li>
                </ul>
                <p>Qualora foste sul posto e decideste all’ultimo di noleggiare la carrozzina, potete presentarvi direttamente all’info point, che si trova in Via Stradómm 7 (vedi cartina allegata sotto): se disponibile, potete prendere a nolo il veicolo senza problemi. Verificate in ogni caso gli orari di apertura.</p>
                <p>Una volta lì, le cose procedono come per il noleggio di un’auto: fornite un documento valido (carta d’identità, passaporto o patente) e compilate un contratto di locazione. La persona presente sul posto vi istruisce sul funzionamento della carrozzina e sul suo corretto uso e adatta insieme a voi il mezzo, secondo le vostre necessità (poggiatesta, altezza del poggiapiedi, eventuale seggiolino per i bambini, ecc).</p>
                <p><strong>Prezzo noleggio:</strong> 25 CHF/3h; 40 CHF/giorno (Pagamento sul posto tramite contanti, carte di credito o TWINT)</p>
                <p>Ancora un attimo per illustrarvi la carrozzina e i percorsi ed è tutto: pronti, partenza, via!</p>

                <h4>La carrozzina</h4>
                <img src="<?php echo esc_url($upload_base . '/2026/07/pagina.webp'); ?>" alt="La carrozzina JST Multidrive" class="content-image">
                <p>La carrozzina JST Multidrive è un piccolo gioiellino prodotto in Svizzera. Grazie alla ruota posteriore che dà stabilità, questo veicolo permette di percorrere sentieri sconnessi e di muoversi senza problemi su strade sterrate e prati; la carrozzina ruota inoltre di 360° su sé stessa, ed è quindi molto maneggevole. Sentitevi quindi tranquilli, perché, oltre che confortevole, è assolutamente sicura: la velocità può essere regolata e non supera i 6 km/h; può essere guidata sia da bambini che da adulti, sia con la mano destra che con la mano sinistra. Qualora l’utente non potesse guidarla, si può mettere la carrozzina in modalità assistita e in quel caso è l’accompagnatore che prende i comandi. Il peso max. consentito è di 100 kg e la batteria capiente permette di affrontare oltre una giornata in movimento senza problemi.</p>
                <p>La carrozzina JST Multidrive è a disposizione di tutte le persone con difficoltà motorie, siano esse bambini, adulti o anziani.</p>

                <h4>Cartina dei percorsi</h4>
                <a href="<?php echo esc_url($upload_base . '/2026/07/carta_tutti.webp'); ?>" id="mappa-lightbox-link" style="text-decoration: none; display: block; text-align: center;">
                    <img src="<?php echo esc_url($upload_base . '/2026/07/carta_tutti.webp'); ?>" alt="Cartina dei percorsi" class="content-image" style="margin-bottom: 8px;">
                    <span style="font-size: 0.95rem; color: var(--color-primary); font-weight: 500; display: inline-block; margin-bottom: var(--space-md);"><em>Clicca sulla mappa per ingrandirla a tutto schermo</em> <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle;"><path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/></svg></span>
                </a>
                <p><strong>Attenzione:</strong> le carrozzine tradizionali non sono adatte ai sentieri indicati qui sotto.</p>

                <h3>Descrizione dei percorsi</h3>

                <h4>Boccia al bosco (Frasco Campagna - Frasco “Bolla”, 3,6 km)</h4>
                <p>Il percorso è inizialmente su strada asfaltata, fino al nucleo di Frasco Torbola. Si attraversa poi un primo ponticello, e, 200 metri dopo un secondo più lungo, sopra il fiume Verzasca. Da quel momento il sentiero si snoda lungo una strada sterrata, frequentata anche da ciclisti in Mountain Bike.</p>
                <p>È un sentiero in larga parte pianeggiante e tranquillo, che segue il fiume e che permette di giocare alle postazioni “Boccia al Bosco”, se muniti di una boccia in legno acquistabile presso uno dei nostri punti vendita. È particolarmente adatto, quindi, alle famiglie con bambini.</p>

                <h4>Val Redorta (Sonogno - Corte, 5,1 km)</h4>
                <p>La Val Redorta è la prima delle due valli laterali di Sonogno e permette di accedere a un paesaggio mozzafiato, incorniciato da montagne maestose. La carrozzina JST Multidrive è indispensabile, nonostante la strada sia asfaltata, perché ci sono alcuni brevi passaggi sterrati e alcuni punti in cui la pendenza la richiede. Grazie alla carrozzina è inoltre possibile accedere a un punto panoramico sul fiume e avvicinarsi alla scenografica cascata Froda, attraversando un ponticello. Oltrepassato il Grotto Efra, la presenza di veicoli a motore è estremamente limitata.</p>

                <h4>Val Vegornèss (Sonogno - Cabiói, 7,6 km)</h4>
                <p>La Val Vegornèss è la seconda delle valli laterali di Sonogno, in fondo alla quale si trova il nucleo pittoresco di Cabiói, con la sua chiesetta e le tipiche costruzioni in sasso (rustici), alle cui spalle ci sono ripidi pendii ricoperti di ginestre. Non è raro sentire il fischio delle marmotte e, seppure la passeggiata non sia lunga, sembra subito di essere lontani da tutto. La prima parte del percorso è su strada asfaltata, mentre la seconda è più irregolare, su agglomerati cementizi ed attraversamenti un po’ sconnessi. Il percorso ricalca sin qui uno degli itinerari etnografici del Museo di Val Verzasca, segnalato dalla cartellonistica marrone e provvisto di flyer esplicativo. La presenza di veicoli a motore è estremamente limitata.</p>
                
                <img src="<?php echo esc_url($upload_base . '/2026/07/PHOTO-2024-07-09-23-07-07.webp'); ?>" alt="Percorso Val Vegornèss" class="content-image">
                
                <p>Oltre ai tre percorsi ufficiali, il nucleo di Sonogno e quello di Frasco sono a vostra disposizione, così come la strada cantonale, lungo la quale si raccomanda prudenza.</p>
                <p><strong>Non avventuratevi su altri sentieri o al di fuori dei tre percorsi ufficiali: essi non sono adatti, nemmeno alla carrozzina JST Multidrive.</strong></p>

                <h4>Altre informazioni</h4>
                <p>Oltre che a Sonogno (all’imbocco della strada della Val Redorta, accanto al parco giochi), trovate un WC ecologico, adatto ai disabili, anche a Gerra V., lungo la strada cantonale: entrambi sono pubblici e a vostra disposizione.</p>
                <img src="<?php echo esc_url($upload_base . '/2026/07/PHOTO-2024-07-29-22-41-25.webp'); ?>" alt="WC Ecologico" class="content-image">
                <p>Se intendete andare a Frasco e non disponete di un mezzo sul quale caricare la carrozzina, avete due possibilità: 1. prendete il bus, linea 321, consultando gli orari sul sito www.ffs.ch; 2. percorrete con la carrozzina la strada cantonale (calcolate 30 minuti circa).</p>
                <p>Vi raccomandiamo di informarvi sulle condizioni meteo e di equipaggiarvi di conseguenza, con un abbigliamento adeguato. Le condizioni del tempo in montagna possono mutare rapidamente.</p>
                <p>Avete bisogno di un posto per dormire? Il ristorante Campagna/Familienhotel a Frasco, proprio alla partenza di uno degli itinerari qui sopra descritti (Boccia al bosco), dispone di una camera attrezzata; anche MyVerzasca, a Brione V., ne offre una; come pure l’hotel Pizzo Vogorno ne dispone.</p>
                
                <img src="<?php echo esc_url($upload_base . '/2026/07/cerebral_logo_ins_it_v_4f.webp'); ?>" alt="Fondazione Cerebral" class="cerebral-logo">

            </div>

            <aside class="rifugio-sidebar animate-on-scroll" style="animation-delay: 0.2s;">
                <div class="tech-details">
                    <h3>Info Rapide</h3>
                    <ul>
                        <li>
                            <strong>Prezzo 3h</strong>
                            <span>25 CHF</span>
                        </li>
                        <li>
                            <strong>Prezzo giorno</strong>
                            <span>40 CHF</span>
                        </li>
                        <li>
                            <strong>Info Point</strong>
                            <span>Via Stradómm 7, Sonogno</span>
                        </li>
                        <li>
                            <strong>Peso Max</strong>
                            <span>100 kg</span>
                        </li>
                        <li>
                            <strong>Velocità Max</strong>
                            <span>6 km/h</span>
                        </li>
                    </ul>
                    <a href="https://bobosco.ch/it/tutti" target="_blank" style="display: block; text-align: center; margin-top: 25px; font-weight: 600; padding: 12px; background: var(--color-primary); color: white; border-radius: var(--radius); text-decoration: none; transition: background 0.3s;">Vai al sito ufficiale</a>
                </div>
            </aside>

        </div>
    </div>
</main>

<!-- Lightbox HTML -->
<div class="lightbox" id="rifugio-lightbox">
    <span class="lightbox-close" onclick="closeLightbox()">&times;</span>
    <img id="lightbox-img" src="">
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const lightbox = document.getElementById('rifugio-lightbox');
    const lightboxImg = document.getElementById('lightbox-img');
    const mapLink = document.getElementById('mappa-lightbox-link');

    if (mapLink) {
        mapLink.addEventListener('click', function(e) {
            e.preventDefault();
            lightboxImg.src = this.href;
            lightbox.classList.add('active');
            document.body.style.overflow = 'hidden';
        });
    }

    window.closeLightbox = function() {
        lightbox.classList.remove('active');
        document.body.style.overflow = '';
    }

    lightbox.addEventListener('click', function(e) {
        if (e.target === lightbox) {
            closeLightbox();
        }
    });

    document.addEventListener('keydown', function(e) {
        if (!lightbox.classList.contains('active')) return;
        if (e.key === 'Escape') closeLightbox();
    });
});
</script>

<?php get_footer(); ?>
