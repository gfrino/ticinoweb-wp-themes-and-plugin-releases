<?php
/**
 * Template Name: Shop (Catalogo)
 */
get_header();

$has_thumbnail = has_post_thumbnail();
$thumbnail_url = $has_thumbnail ? get_the_post_thumbnail_url(get_the_ID(), 'full') : '';
$header_class = $has_thumbnail ? 'page-header-cinematic has-bg' : 'page-header-cinematic no-bg';

// Email di destinazione per gli acquisti
$email_acquisto = get_option('ticinoweb_contact_email', 'info@patriziatofrasco.ch');
?>

<style>


.shop-catalog {
    max-width: 1200px;
    margin: -80px auto var(--space-xl) auto; /* Tiriamo su tutto sopra il banner */
    padding: 0 var(--space-md);
    position: relative;
    z-index: 10;
}

@media (max-width: 992px) {
    .shop-catalog {
        margin-top: 40px;
    }
}

.shop-intro {
    text-align: center;
    max-width: 800px;
    margin: 0 auto var(--space-xl) auto;
    font-size: 1.15rem;
    line-height: 1.8;
    color: var(--color-text-main);
}

.shop-notice {
    background: var(--color-bg-white);
    padding: var(--space-md);
    margin-bottom: 40px; /* Ridotto lo spazio sotto l'avviso per attaccare le foto */
    border-radius: var(--radius); /* Arrotondamento completo per l'effetto card sollevata */
    box-shadow: 0 10px 30px rgba(0,0,0,0.08); /* Ombra più pronunciata per staccarlo dallo sfondo */
}

.shop-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
    gap: var(--space-lg);
}

.product-card {
    background: var(--color-bg-pure-white);
    border-radius: var(--radius);
    overflow: hidden;
    box-shadow: 0 4px 15px rgba(0,0,0,0.05);
    border: 1px solid rgba(0,0,0,0.05);
    display: flex;
    flex-direction: column;
    height: 100%;
}

.product-img {
    height: 250px;
    background: #f8f9fa;
    position: relative;
    overflow: hidden;
    padding: 20px;
    cursor: zoom-in;
}

.product-img img {
    width: 100%;
    height: 100%;
    object-fit: contain; /* Usa contain per non tagliare le magliette o oggetti */
    transition: transform 0.1s ease-out;
}

.product-content {
    padding: var(--space-md);
    display: flex;
    flex-direction: column;
    flex-grow: 1;
}

.product-title {
    color: var(--color-primary-dark);
    margin: 0 0 10px 0;
    font-size: 1.4rem;
    font-family: var(--font-heading);
}

.product-desc {
    font-size: 0.95rem;
    color: var(--color-text-light);
    line-height: 1.6;
    margin-bottom: 20px;
    flex-grow: 1; /* Spinge il bottone in basso */
}

.product-action {
    margin-top: auto;
}

.btn-order {
    display: block;
    text-align: center;
    background: var(--color-primary);
    color: white;
    padding: 12px 20px;
    border-radius: 6px;
    font-weight: bold;
    text-decoration: none;
    transition: background 0.3s;
}

.btn-order:hover {
    background: var(--color-primary-dark);
}

.btn-order.disabled {
    background: #ccc;
    cursor: not-allowed;
    pointer-events: none;
}
</style>

<header class="<?php echo esc_attr($header_class); ?>" <?php if ($has_thumbnail) echo 'style="background-image: url(\'' . esc_url($thumbnail_url) . '\');"'; else echo 'style="background-color: var(--color-primary-dark);"'; ?>>
    <div class="page-header-overlay"></div>
    <div class="container page-header-inner animate-on-scroll text-center">
        <h1 class="page-title"><?php the_title(); ?></h1>
        <h2 style="color: var(--color-accent); font-size: 1.5rem; font-weight: 500; font-family: var(--font-heading); margin-top: var(--space-sm);">Scopri i nostri articoli esclusivi.</h2>
    </div>
</header>

<main id="primary" class="site-main">
    <div class="shop-catalog">
        
        <!-- Intro rimossa per evitare conflitti con vecchi blocchi di Gutenberg -->

        <div class="shop-notice animate-on-scroll">
            <h4 style="color: var(--color-primary); margin-top: 0;">
                Informazioni per l'acquisto
            </h4>
            <p style="margin-bottom: 0;">Per procedere all'acquisto di qualsiasi articolo presente in questo catalogo, ti invitiamo a contattare direttamente l'Ufficio Patriziale tramite email all'indirizzo <a href="mailto:<?php echo esc_attr($email_acquisto); ?>" style="color: var(--color-primary); font-weight: bold;"><?php echo esc_html($email_acquisto); ?></a> indicando gli articoli desiderati e le eventuali taglie.</p>
        </div>

        <div class="shop-grid animate-on-scroll">
            <?php
            $args = array(
                'post_type'      => 'prodotto',
                'posts_per_page' => -1,
                'orderby'        => array(
                    'menu_order' => 'ASC',
                    'date'       => 'DESC'
                )
            );
            $prodotti_query = new WP_Query( $args );

            if ( $prodotti_query->have_posts() ) :
                while ( $prodotti_query->have_posts() ) : $prodotti_query->the_post();
                    
                    $descrizione = get_post_meta( get_the_ID(), '_prodotto_descrizione', true );
                    
                    // Creazione oggetto mail precompilato
                    $mail_subject = rawurlencode("Richiesta informazioni: " . get_the_title());
                    $mail_body = rawurlencode("Buongiorno,\n\nvorrei richiedere informazioni per il seguente articolo:\n- " . get_the_title() . "\n\nIn attesa di un vostro riscontro, porgo cordiali saluti.");
                    $mailto_link = "mailto:" . esc_attr($email_acquisto) . "?subject=" . $mail_subject . "&body=" . $mail_body;
                    ?>
                    
                    <div class="product-card">
                        <div class="product-img">
                            <?php if ( has_post_thumbnail() ) : ?>
                                <?php the_post_thumbnail('medium_large'); ?>
                            <?php else : ?>
                                <!-- Immagine placeholder se non presente -->
                                <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#ddd" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
                            <?php endif; ?>
                        </div>
                        
                        <div class="product-content">
                            <h3 class="product-title"><?php the_title(); ?></h3>
                            
                            <div class="product-desc">
                                <?php echo wpautop(wp_kses_post($descrizione)); ?>
                            </div>
                            
                            <div class="product-action">
                                <a href="<?php echo esc_url($mailto_link); ?>" class="btn-order">
                                    Richiedi informazioni
                                </a>
                            </div>
                        </div>
                    </div>

                <?php endwhile; wp_reset_postdata(); ?>
            <?php else : ?>
                <div style="grid-column: 1 / -1; text-align: center; padding: var(--space-xxl); background: var(--color-bg-pure-white); border-radius: var(--radius); border: 1px solid rgba(0,0,0,0.05);">
                    <p style="color: var(--color-primary-light); font-size: 1.2rem; margin: 0;">Nessun prodotto disponibile al momento.</p>
                </div>
            <?php endif; ?>
        </div>

    </div>
</main>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const productImages = document.querySelectorAll('.product-img');
    
    productImages.forEach(container => {
        const img = container.querySelector('img');
        if(!img) return; // Salta se c'è un placeholder testuale o nessun'immagine
        
        container.addEventListener('mousemove', function(e) {
            // Calcola la posizione del mouse relativa al contenitore
            const rect = container.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            // Converte in percentuale (da 0% a 100%)
            const xPercent = (x / rect.width) * 100;
            const yPercent = (y / rect.height) * 100;
            
            // Imposta l'origine dello zoom sul punto esatto del mouse
            img.style.transformOrigin = `${xPercent}% ${yPercent}%`;
        });
        
        container.addEventListener('mouseenter', function() {
            // Esegue lo zoom quando il mouse entra
            img.style.transform = 'scale(1.5)';
        });
        
        container.addEventListener('mouseleave', function() {
            // Ripristina l'immagine quando il mouse esce
            img.style.transform = 'scale(1)';
            setTimeout(() => {
                img.style.transformOrigin = 'center center';
            }, 100);
        });
    });
});
</script>

<?php get_footer(); ?>
