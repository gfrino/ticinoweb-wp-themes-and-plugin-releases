<?php
/**
 * Template Name: Territorio
 */
get_header();
?>

<style>
.territorio-container {
    max-width: 900px;
    margin: 0 auto;
    padding: 20px var(--space-md) 100px var(--space-md);
}

.territorio-article {
    font-size: 1.15rem;
    line-height: 1.8;
    color: var(--color-text-main);
}

.territorio-article h2 {
    font-family: var(--font-heading);
    color: var(--color-secondary);
    font-size: 2.5rem;
    margin-bottom: var(--space-lg);
    border-bottom: 2px solid rgba(0, 0, 0, 0.05);
    padding-bottom: 10px;
}

.territorio-article p {
    margin-bottom: var(--space-md);
}

.image-block {
    margin: 40px 0;
    border-radius: var(--radius);
    overflow: hidden;
    box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
}

.image-block img {
    width: 100%;
    height: auto;
    display: block;
}

.image-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
    margin: 40px 0;
    align-items: start;
}

.image-grid p {
    display: contents;
}

.image-grid .image-item {
    border-radius: var(--radius);
    overflow: hidden;
    box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
}

.image-grid img {
    width: 100%;
    height: auto;
    display: block;
}

@media (max-width: 768px) {
    .image-grid {
        grid-template-columns: 1fr;
    }
}
</style>

<main id="primary" class="site-main">
    
	<?php
	while ( have_posts() ) :
		the_post();
		
		$has_thumbnail = has_post_thumbnail();
		$thumbnail_url = $has_thumbnail ? get_the_post_thumbnail_url(get_the_ID(), 'full') : '';
		$header_class = $has_thumbnail ? 'page-header-cinematic has-bg' : 'page-header-cinematic no-bg';
		?>
		<header class="<?php echo esc_attr($header_class); ?>" <?php if ($has_thumbnail) echo 'style="background-image: url(\'' . esc_url($thumbnail_url) . '\');"'; ?>>
			<div class="page-header-overlay"></div>
			<div class="container page-header-inner animate-on-scroll">
				<?php the_title( '<h1 class="page-title">', '</h1>' ); ?>
			</div>
		</header>
        <div class="territorio-container animate-on-scroll">
            <div class="page-content custom-gutenberg-layout">
                <?php the_content(); ?>
            </div>
        </div>

	<?php endwhile; // End of the loop. ?>

</main>

<?php get_footer(); ?>
