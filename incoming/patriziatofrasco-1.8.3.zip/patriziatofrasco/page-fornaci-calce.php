<?php
/**
 * Template Name: Fornaci Calce
 */
get_header();

$hero_img = parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) . '/2026/06/fornaci.jpg';
?>

<style>
/* Reusing the reliable layout structure */
.rifugio-layout {
    display: grid;
    grid-template-columns: 1fr 420px;
    gap: var(--space-xl);
    padding: var(--space-xl) 0;
}

.rifugio-main-content {
    font-size: 1.15rem;
    line-height: 1.8;
}

.rifugio-main-content h4 {
    color: var(--color-primary);
    font-size: 1.5rem;
    margin: var(--space-lg) 0 var(--space-sm) 0;
    padding-bottom: var(--space-xs);
    border-bottom: 2px solid var(--color-bg-body);
}

.rifugio-main-content p {
    margin-bottom: var(--space-md);
}

/* Sidebar Widget Card */
.rifugio-sidebar {
    position: sticky;
    top: 100px;
    height: fit-content;
}

.tech-details {
    background: var(--color-bg-pure-white);
    padding: 25px;
    border-radius: var(--radius);
    box-shadow: 0 10px 30px rgba(0,0,0,0.08);
    border-top: 4px solid var(--color-accent);
    margin-bottom: var(--space-lg);
}

.tech-details h3 {
    color: var(--color-primary-dark);
    margin-bottom: 1rem;
    text-align: center;
    font-size: 1.4rem;
}

@media (max-width: 992px) {
    .rifugio-layout {
        grid-template-columns: 1fr;
    }
    .rifugio-sidebar {
        position: static;
        margin-top: var(--space-lg);
    }
}
</style>

<header class="page-header-cinematic has-bg" style="background-image: url('<?php echo esc_url($hero_img); ?>'); background-position: center;">
    <div class="page-header-overlay"></div>
    <div class="container page-header-inner animate-on-scroll" style="text-align: left;">
        <h1 class="page-title" style="margin-bottom: 0;">Le fornaci della calce</h1>
        <p style="font-size: 1.2rem; opacity: 0.9; margin-top: 10px; color: #FFFFFF;">Un'antica arte rurale di vitale importanza</p>
    </div>
</header>

<main id="primary" class="site-main">
    <div class="container rifugio-layout">
        
        <div class="rifugio-main-content animate-on-scroll">
            <p><strong>Le fornaci della calce in Val d’Efra</strong> sono una preziosa testimonianza del passato rurale di Frasco e del percorso dedicato all’acqua e al fuoco. Un tempo, il fuoco non serviva solo a riscaldare le case o a cuocere il pane nei forni del villaggio, ma anche a produrre la calce, materiale fondamentale per la costruzione.</p>
            
            <p>Nelle fornaci venivano cotti i sassi calcarei ad alte temperature, trasformandoli in calce viva. Questa veniva poi utilizzata per preparare malte e intonaci, indispensabili per costruire e mantenere case, muri e altri edifici del villaggio.</p>
            
            <p>Insieme al mulino, alla turbina della centralina, alla cascata della Val d’Efra e alla lüera, le fornaci raccontano l’ingegno degli abitanti di Frasco, capaci di sfruttare acqua, fuoco e risorse naturali per la vita quotidiana. Oggi rappresentano un importante punto d’interesse storico e culturale della Valle Verzasca.</p>
        </div>

        <div class="rifugio-sidebar animate-on-scroll">
            <div style="background: var(--color-bg-pure-white); padding: 15px; border-radius: var(--radius); box-shadow: 0 10px 30px rgba(0,0,0,0.08); border-top: 4px solid var(--color-primary);">
                <h3 style="color: var(--color-primary-dark); margin-bottom: 1rem; text-align: center; padding-top: 10px;">Posizione</h3>
                <iframe loading="lazy" src="https://maps.google.com/maps?q=Valle%20Efra,%20Frasco&t=k&z=15&output=embed&iwloc=near" title="Mappa Fornaci Calce" width="100%" height="250" style="border:0; border-radius: 8px;" allowfullscreen="" loading="lazy"></iframe>
            </div>
        </div>

    </div>
</main>

<?php get_footer(); ?>
