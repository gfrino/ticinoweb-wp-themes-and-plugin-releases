<?php
/**
 * Template Name: Cabioi
 */
get_header();

$hero_img = parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) . '/2026/06/ace1101b756f2c747a826cf1e0e25dbf.jpg';
?>

<style>
/* Reusing the reliable layout structure */
.rifugio-layout {
    display: grid;
    grid-template-columns: 1fr 420px;
    gap: var(--space-xl);
    padding-top: var(--space-xl);
    padding-bottom: var(--space-xl);
}

.rifugio-main-content {
    font-size: 1.15rem;
    line-height: 1.8;
}

.rifugio-main-content h4 {
    color: var(--color-primary);
    font-size: 1.5rem;
    margin: var(--space-lg) 0 var(--space-sm) 0;
    padding-bottom: var(--space-xs);
    border-bottom: 2px solid var(--color-bg-body);
}

.rifugio-main-content p {
    margin-bottom: var(--space-md);
}

/* Sidebar Widget Card */
.rifugio-sidebar {
    position: sticky;
    top: 100px;
    height: fit-content;
}

.tech-details {
    background: var(--color-bg-pure-white);
    padding: 25px;
    border-radius: var(--radius);
    box-shadow: 0 10px 30px rgba(0,0,0,0.08);
    border-top: 4px solid var(--color-accent);
    margin-bottom: var(--space-lg);
}

.tech-details h3 {
    color: var(--color-primary-dark);
    margin-bottom: 1rem;
    text-align: center;
    font-size: 1.4rem;
}

@media (max-width: 992px) {
    .rifugio-layout {
        grid-template-columns: 1fr;
    }
    .rifugio-sidebar {
        position: static;
        margin-top: var(--space-lg);
    }
}

/* Gallery Grid */
.rifugio-gallery {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
    gap: 15px;
    margin-top: 20px;
}

.rifugio-gallery a {
    display: block;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 4px 15px rgba(0,0,0,0.08);
}

.rifugio-gallery img {
    width: 100%;
    height: 140px;
    object-fit: cover;
    display: block;
    transition: transform 0.3s ease;
}

.rifugio-gallery a:hover img {
    transform: scale(1.05);
}

/* Lightbox Styles */
.lightbox {
    position: fixed;
    z-index: 99999;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.92);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    pointer-events: none;
    transition: opacity 0.3s ease;
}
.lightbox.active {
    opacity: 1;
    pointer-events: auto;
}
.lightbox img {
    max-width: 90%;
    max-height: 90vh;
    border-radius: 4px;
    box-shadow: 0 10px 50px rgba(0,0,0,0.8);
    transition: transform 0.3s ease;
}
.lightbox-close {
    position: absolute;
    top: 20px;
    right: 30px;
    color: white;
    font-size: 45px;
    cursor: pointer;
    line-height: 1;
    user-select: none;
    transition: color 0.2s;
}
.lightbox-close:hover { color: var(--color-accent); }
.lightbox-prev, .lightbox-next {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    color: white;
    font-size: 50px;
    cursor: pointer;
    padding: 20px;
    user-select: none;
    transition: color 0.2s;
}
.lightbox-prev { left: 20px; }
.lightbox-next { right: 20px; }
.lightbox-prev:hover, .lightbox-next:hover { color: var(--color-accent); }
</style>

<header class="page-header-cinematic has-bg" style="background-image: url('<?php echo esc_url($hero_img); ?>'); background-position: center;">
    <div class="page-header-overlay"></div>
    <div class="container page-header-inner animate-on-scroll" style="text-align: left;">
        <h1 class="page-title" style="margin-bottom: 0;">Cabioi</h1>
    </div>
</header>

<style>
/* FORZA BRUTA ANTI-PLUGIN: Disabilita i clic sull'intera galleria e su ogni elemento generato dinamicamente al suo interno */
.rifugio-gallery, .rifugio-gallery * {
    pointer-events: none !important;
    cursor: default !important;
}
</style>

<main id="primary" class="site-main">
    <div class="container rifugio-layout">
        
        <div class="rifugio-main-content animate-on-scroll">
            <h3 style="color: var(--color-primary-dark); font-size: 2rem; margin-bottom: var(--space-md);">Benvenuti a Cabiói</h3>
            <p>Il monte Cabiói (1079 m) si trova nel fondovalle della Valle Vogornesso, un naturale prolungamento della Valle Verzasca. È un caratteristico e compatto nucleo di cascine immerso in un ambiente selvaggio e sassoso, attorniato da ripide pareti di montagne.</p>
            <p>Questo piccolo e discosto angolo di mondo è ricco di testimonianza della presenza e della fatica dell'uomo. Un percorso etnografico invita alla visita della sèrra, delle fregère e dei sprügh. Una pausa meditativa è pure possibile nella piccola chiesetta dedicata a St. Teresa del Bambin Gesù (di Lisieux).</p>

            <h4>Il nucleo</h4>
            <p>Percorrendo la strada della Val Vogornesso, giunti alla serra, sul fondo si scorge il piccolo e antico nucleo di Cabiói. I suoi rustici riattati conservano tuttora un fascino autentico: baite e stalle in granito, tetti in piode e muretti a secco.</p>
            <p>Il monte Cabiói oggi è un apprezzato luogo di soggiorno, mentre in passato era usato come nucleo stagionale, abitato in primavera e in autunno durante il trasferimento del bestiame tra i pascoli inferiori e gli alpeggi superiori. Al centro spicca l'oratorio di Santa Teresa di Gesù Bambino (di Lisieux).</p>

            <h4>L'oratorio dedicato a Santa Teresa del Bambino Gesù</h4>
            <p>L'oratorio dedicato a Santa Teresa del Bambino Gesù, è un piccolo e suggestivo luogo di culto, costruito come luogo di devozione e meditazione per gli alpigiani di una volta. Oggi è meta per una breve sosta spirituale durante le passeggiate.</p>
            <p>L'edificio è semplice, in stile montano, con una piccola campana. L'interno offre uno spazio raccolto, ideale per riflessioni silenziose, lontano dal traffico e immerso nel paesaggio alpino.</p>

            <h4>Flora e fauna</h4>
            <p>La vegetazione che circonda il monte Cabiói varia a seconda dell'altitudine: le zone boschive sono composte da faggi e betulle, mentre nelle zone più elevate sono presenti larici e abeti rossi. I pascoli alpini sono prevalentemente prati magri dove trova spazio una grande quantità di ginestre. Malgrado sia una zona molto sassosa, il giallo della fioritura delle ginestre in primavera e il rosso dei faggi in autunno rappresentano un vero spettacolo della natura.</p>
            <p>La fauna è rappresentativa dell'arco alpino meridionale, con caprioli, cervi, volpi, marmotte e camosci. Durante le escursioni lungo la Val Vogornesso, è normale incontrare mucche e simpatiche capre libere al pascolo. Fra loro spicca la padrona di casa, ossia la Nera Verzasca, razza caprina originaria della Verzasca caratterizzata da un corto e fine mantello nero lucido. Questa tipica capra di montagna è una delle capre più grandi e forti della Svizzera ed è nota per la sua resistenza.</p>

            <h4 style="margin-top: var(--space-xxl); font-size: 1.5rem;">Come arrivare a Cabiói</h4>
            <p><strong>In automobile</strong><br>
            A Gordola prendere la strada per la Valle Verzasca e proseguire fino ad arrivare ai posteggi comunali di Sonogno.<br>
            Da Sonogno proseguire a piedi per circa 4 km. La stradina che porta a Cabiói è inizialmente asfaltata. Dopo circa 2.5 km, la strada attraversa un piccolo ponte e prosegue su fondo sterrato. Dopo circa altri 1.5km, dove anche la strada sterrata finisce, si arriva al nucleo del monte Cabiói.</p>
            <p style="background: rgba(var(--color-accent-rgb), 0.1); padding: 15px; border-left: 4px solid var(--color-accent); border-radius: 4px;"><strong>Nota per l'accesso e posteggio:</strong> L'accesso in auto fino a Cabiói è permesso solo agli autorizzati oppure agli escursionisti che intendono pernottare alla Capanna Cognora (spazio per posteggi situato prima del nucleo di Cabiói, all'altezza della serra) o alla Capanna Barone (spazio per posteggi ubicato alla fine della strada, appena oltre il nucleo di Cabiói). Per il posteggio dell'auto in una delle due aree riservate, è richiesta un'offerta di 5 CHF da lasciare sul posto in un'apposita scatola, oppure direttamente in capanna.</p>
            
            <p style="margin-top: var(--space-lg);"><strong>Con i mezzi pubblici</strong><br>
            Raggiungere in treno la stazione ferroviaria di Tenero. Qui si prende il bus, linea n. 321, fino a Sonogno.<br>
            Da Sonogno, prosegui a piedi seguendo le indicazioni per Cabiói come descritto sopra.</p>
            <div style="margin-top: 25px; margin-bottom: var(--space-xl); text-align: center;">
                <img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/mappa-ticino-scaled.jpg" alt="Mappa trasporti Ticino" class="content-image" style="max-width: 500px; width: 100%; border-radius: var(--radius); box-shadow: 0 5px 20px rgba(0,0,0,0.15); margin-bottom: 8px;">
            </div>

            <h4 style="margin-top: var(--space-xxl); font-size: 1.5rem; text-transform: uppercase;">Galleria Fotografica</h4>
            <div class="rifugio-gallery">
                <img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/959397823a87b2fa982706cebf38d78e.jpg">
                <img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/245299473617f68dd5f411c20e05972c.jpg">
                <img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/be7725198de5f6ad383bf735d1ea1541.jpg">
                <img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/aa8d594657b9b2ea2ffc7ff5179ae457.jpg">
                <img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/df99f0f2610cb3295e3254df52b5bd81.jpg">
                <img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/il_paesaggio_1_20121108_1110595376.jpg">
                <img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/santateresa2.jpg">
            </div>
        </div>

        <div class="rifugio-sidebar animate-on-scroll">
            <div class="tech-details">
                <h3>Informazioni</h3>
                <ul style="color: var(--color-text-main); font-size: 1rem; line-height: 1.8; list-style: none; padding: 0; text-align: center; margin-bottom: 0;">
                    <li><strong>Altitudine:</strong> 1079 m s.l.m.</li>
                    <li><strong>Valle:</strong> Vogornesso</li>
                    <li><strong>Flora:</strong> Faggi, betulle, larici, abeti rossi, ginestre</li>
                    <li><strong>Fauna:</strong> Caprioli, cervi, volpi, marmotte, camosci, Capra Nera Verzasca</li>
                    <li><strong>Luogo di culto:</strong> Oratorio di St. Teresa di Lisieux</li>
                </ul>
            </div>
            
            <div style="background: var(--color-bg-pure-white); padding: 15px; border-radius: var(--radius); box-shadow: 0 10px 30px rgba(0,0,0,0.08); border-top: 4px solid var(--color-primary);">
                <h3 style="color: var(--color-primary-dark); margin-bottom: 1rem; text-align: center; padding-top: 10px;">Posizione</h3>
                
                <div class="sidebar-map" style="position: relative; text-align: center;">
                    <a href="#" id="open-map-lightbox" data-map-src="https://maps.google.com/maps?q=46.3787503,8.7960383&t=k&z=14&output=embed&iwloc=near" style="text-decoration: none; display: block; position: relative;">
                        <div style="position: absolute; top:0; left:0; width:100%; height: 250px; z-index: 10; cursor: pointer;"></div>
                        <iframe loading="lazy" src="https://maps.google.com/maps?q=46.3787503,8.7960383&t=k&z=14&output=embed&iwloc=near" title="Mappa Cabioi" width="100%" height="250" style="border:0; border-radius: 8px;" allowfullscreen="" loading="lazy"></iframe>

                    </a>
                </div>
                
                <div style="text-align: center; margin-top: 5px;">
                    <a href="https://www.google.com/maps/place/Cabi%C3%B3i/@46.3755317,8.7962395,2878m/data=!3m1!1e3!4m6!3m5!1s0x4785a5ef965010c5:0xf9182a04642da459!8m2!3d46.3787503!4d8.7960383!16s%2Fg%2F11nfqbzych?entry=tts&g_ep=EgoyMDI1MDgxOS4wIPu8ASoASAFQAw%3D%3D&skid=4c7d053f-12fd-495d-ad12-5a6bf69c0648" target="_blank" class="btn-primary" style="padding: 10px 20px; font-size: 0.9rem;">Apri in Google Maps</a>
                </div>
            </div>
        </div>

    </div>
</main>

<script>
document.addEventListener('DOMContentLoaded', function() {

    // Map Lightbox Logic
    const mapLink = document.getElementById('open-map-lightbox');
    const mapLightbox = document.getElementById('map-lightbox');
    const mapIframe = document.getElementById('lightbox-map-iframe');

    if (mapLink && mapLightbox && mapIframe) {
        mapLink.addEventListener('click', function(e) {
            e.preventDefault();
            mapIframe.src = this.getAttribute('data-map-src');
            mapLightbox.classList.add('active');
            document.body.style.overflow = 'hidden';
        });

        window.closeMapLightbox = function() {
            mapLightbox.classList.remove('active');
            document.body.style.overflow = '';
            setTimeout(() => { mapIframe.src = ''; }, 300);
        }

        mapLightbox.addEventListener('click', function(e) {
            if (e.target === mapLightbox || e.target.classList.contains('lightbox-map-container')) {
                closeMapLightbox();
            }
        });
        
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                if (typeof closeMapLightbox === 'function' && document.getElementById('map-lightbox').classList.contains('active')) closeMapLightbox();
            }
        });
    }
});
</script>

<?php get_footer(); ?>
