<?php
/**
 * Template Name: Organizzazione (ex Missione)
 */
get_header();
?>

<style>
.org-container {
    width: 100%;
    max-width: 1500px;
    margin: 0 auto;
    padding: 60px clamp(24px, 4vw, 64px) 100px;
}

.org-row-1 {
    display: grid;
    grid-template-columns: minmax(0, 1.8fr) minmax(320px, 0.9fr);
    gap: clamp(32px, 5vw, 72px);
    align-items: start;
    margin-bottom: clamp(40px, 4vw, 64px);
}

/* The page already has its own outer spacing: avoid Gutenberg narrowing it again. */
.org-container .custom-gutenberg-layout > * {
    max-width: none;
    padding-left: 0;
    padding-right: 0;
}

.org-section {
    margin-bottom: 0;
}

.org-section h2 {
    font-family: var(--font-heading);
    color: var(--color-secondary);
    font-size: 2.3rem;
    margin-bottom: var(--space-lg);
    border-bottom: 2px solid rgba(0, 0, 0, 0.05);
    padding-bottom: 10px;
    margin-top: 0;
}

.law-quotes-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: clamp(24px, 3vw, 48px);
}

.law-quote-card {
    background: var(--color-bg-pure-white);
    border-radius: var(--radius);
    padding: clamp(28px, 3vw, 48px);
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.04);
    border-left: 4px solid var(--color-primary);
    border-top: 1px solid rgba(0, 0, 0, 0.02);
    border-right: 1px solid rgba(0, 0, 0, 0.02);
    border-bottom: 1px solid rgba(0, 0, 0, 0.02);
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}

.law-quote-text {
    font-size: 1.2rem;
    line-height: 1.8;
    color: var(--color-text-main);
    font-style: italic;
    margin-bottom: 15px;
}

.law-quote-cite {
    font-size: 0.95rem;
    color: var(--color-text-light);
    font-weight: 500;
    display: block;
}

.stemma-grid {
    display: grid;
    grid-template-columns: minmax(300px, 380px) minmax(0, 1fr);
    gap: clamp(32px, 5vw, 72px);
    align-items: start;
}

.stemma-card {
    background: var(--color-bg-pure-white);
    border-radius: var(--radius);
    padding: var(--space-lg);
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.04);
    text-align: center;
    border: 1px solid rgba(0, 0, 0, 0.04);
}

.stemma-image-wrapper {
    width: 100%;
    max-width: 320px;
    margin: 0 auto 15px auto;
    padding: 10px;
    background: var(--color-bg-body);
    border-radius: var(--radius);
    display: flex;
    align-items: center;
    justify-content: center;
    box-sizing: border-box;
}

.stemma-image-wrapper img {
    width: 100%;
    height: auto;
    display: block;
}

.stemma-caption {
    font-size: 0.95rem;
    color: var(--color-text-main);
    font-style: italic;
    margin-top: 10px;
    font-weight: 500;
}

.stemma-text {
    font-size: 1.15rem;
    line-height: 1.8;
    color: var(--color-text-main);
}

.stemma-text p:first-child {
    margin-top: 0;
}

.org-admin-section {
    border-top: 2px solid rgba(0, 0, 0, 0.05);
    padding-top: var(--space-xxl);
}

.admin-intro {
    font-size: 1.25rem;
    line-height: 1.8;
    color: var(--color-primary-dark);
    font-weight: 500;
    margin-bottom: var(--space-xl);
    text-align: center;
}

.admin-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: clamp(24px, 3vw, 48px);
}

.admin-card {
    background: var(--color-bg-pure-white);
    border-radius: var(--radius);
    padding: clamp(28px, 3vw, 48px);
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.04);
    border-top: 4px solid var(--color-primary);
    border-left: 1px solid rgba(0, 0, 0, 0.02);
    border-right: 1px solid rgba(0, 0, 0, 0.02);
    border-bottom: 1px solid rgba(0, 0, 0, 0.02);
}

.admin-card h3 {
    color: var(--color-primary-dark);
    font-size: 1.8rem;
    margin-top: 0;
    margin-bottom: 15px;
    font-family: var(--font-heading);
}

.admin-card .card-intro {
    font-size: 1.1rem;
    line-height: 1.6;
    color: var(--color-text-main);
    margin-bottom: 20px;
}

.admin-card h4 {
    color: var(--color-secondary);
    font-size: 1.15rem;
    margin-top: 25px;
    margin-bottom: 15px;
    font-weight: 600;
    border-bottom: 1px solid rgba(0,0,0,0.05);
    padding-bottom: 5px;
}

.admin-card ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

.admin-card ul li {
    padding: 10px 0;
    border-bottom: 1px solid rgba(0, 0, 0, 0.05);
    font-size: 1.05rem;
    line-height: 1.6;
    color: var(--color-text-main);
    display: flex;
    gap: var(--space-sm);
    align-items: start;
}

.admin-card ul li:last-child {
    border-bottom: none;
}

.admin-card ul li::before {
    content: "";
    display: inline-block;
    min-width: 16px;
    height: 16px;
    margin-top: 4px;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%233c69e7'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='3' d='M5 13l4 4L19 7'%3E%3C/path%3E%3C/svg%3E");
    background-size: contain;
    background-repeat: no-repeat;
    background-position: center;
}

@media (max-width: 1200px) {
    .org-row-1, .stemma-grid, .admin-grid {
        grid-template-columns: 1fr;
        gap: var(--space-xl);
    }
    .stemma-image-wrapper {
        max-width: 200px;
    }
}

@media (max-width: 768px) {
    .org-container {
        padding: 40px 20px 70px;
    }

    .law-quotes-grid {
        grid-template-columns: 1fr;
    }

    .law-quote-card,
    .admin-card {
        padding: 24px;
    }
}
</style>

<main id="primary" class="site-main">
    
	<?php
	while ( have_posts() ) :
		the_post();
		
		$has_thumbnail = has_post_thumbnail();
		$thumbnail_url = $has_thumbnail ? get_the_post_thumbnail_url(get_the_ID(), 'full') : '';
		$header_class = $has_thumbnail ? 'page-header-cinematic has-bg' : 'page-header-cinematic no-bg';
		?>
		<header class="<?php echo esc_attr($header_class); ?>" <?php if ($has_thumbnail) echo 'style="background-image: url(\'' . esc_url($thumbnail_url) . '\');"'; ?>>
			<div class="page-header-overlay"></div>
			<div class="container page-header-inner animate-on-scroll">
				<h1 class="page-title">Organizzazione</h1>
				<h2 style="color: var(--color-accent); font-size: 1.5rem; font-weight: 500; font-family: var(--font-heading); margin-top: var(--space-sm);">Struttura e mandato del Patriziato.</h2>
			</div>
		</header>

        <div class="org-container animate-on-scroll">
            <div class="page-content custom-gutenberg-layout">
                <?php the_content(); ?>
            </div>
        </div>

	<?php endwhile; // End of the loop. ?>

</main>

<?php get_footer(); ?>
