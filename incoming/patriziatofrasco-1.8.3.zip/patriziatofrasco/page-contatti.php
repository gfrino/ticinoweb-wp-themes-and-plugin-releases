<?php
/**
 * Template Name: Pagina Contatti
 */
get_header();

// Recupera i dati dal sistema centrale
$phone = get_option('ticinoweb_contact_phone', '079 570 66 36');
$email = get_option('ticinoweb_contact_email', 'patriziatofrasco@bluewin.ch');
$address = get_option('ticinoweb_contact_address', 'Casella Postale 11, 6636 Frasco');

$has_thumbnail = has_post_thumbnail();
$thumbnail_url = $has_thumbnail ? get_the_post_thumbnail_url(get_the_ID(), 'full') : '';
$header_class = $has_thumbnail ? 'page-header-cinematic has-bg' : 'page-header-cinematic no-bg';
?>

<style>
/* Reset per eventuali icone rotte o SVG giganti di Gutenberg inserite dall'utente */
.page-content .wp-block-icon,
.page-content svg,
.page-content .wp-block-image img {
    max-width: 40px !important;
    max-height: 40px !important;
    height: auto !important;
    display: inline-block;
}

.contact-layout {
    display: flex;
    flex-direction: column;
    gap: 40px;
    margin-top: 40px;
    margin-bottom: 80px;
}

.contact-map {
    width: 100%;
}

.contact-sidebar {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
}

.contact-card {
    background: var(--color-bg-pure-white);
    border-radius: var(--radius);
    padding: 30px;
    display: flex;
    align-items: center;
    gap: 20px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.05);
    border: 1px solid rgba(0,0,0,0.03);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    text-decoration: none;
    color: var(--color-text);
}

.contact-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 40px rgba(0,0,0,0.08);
}

.contact-icon-wrap {
    width: 60px;
    height: 60px;
    background: rgba(60, 105, 231, 0.05);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    color: var(--color-primary);
    transition: background 0.3s, color 0.3s;
}

.contact-card:hover .contact-icon-wrap {
    background: var(--color-primary);
    color: #FFFFFF;
}

.contact-icon-wrap svg {
    width: 24px;
    height: 24px;
}

.contact-info h3 {
    margin: 0 0 5px 0;
    font-size: 1.1rem;
    color: var(--color-primary-dark);
}

.contact-info p {
    margin: 0;
    font-size: 1rem;
    font-weight: bold;
    color: var(--color-text);
}

/* Stile per un eventuale Contact Form 7 o form di WP */
.wpcf7-form {
    background: var(--color-bg-pure-white);
    padding: 40px;
    border-radius: var(--radius);
    box-shadow: 0 10px 30px rgba(0,0,0,0.03);
    border: 1px solid rgba(0,0,0,0.05);
}

.wpcf7-form input[type="text"],
.wpcf7-form input[type="email"],
.wpcf7-form textarea {
    width: 100%;
    padding: 12px 15px;
    border: 1px solid #ddd;
    border-radius: 6px;
    margin-bottom: 20px;
    font-family: inherit;
    transition: border-color 0.3s;
}

.wpcf7-form input:focus,
.wpcf7-form textarea:focus {
    border-color: var(--color-primary);
    outline: none;
}

.wpcf7-form input[type="submit"] {
    background: var(--color-primary);
    color: white;
    border: none;
    padding: 15px 30px;
    border-radius: 6px;
    font-weight: bold;
    cursor: pointer;
    transition: background 0.3s;
}

.wpcf7-form input[type="submit"]:hover {
    background: var(--color-primary-dark);
}
</style>

<header class="<?php echo esc_attr($header_class); ?>" <?php if ($has_thumbnail) echo 'style="background-image: url(\'' . esc_url($thumbnail_url) . '\');"'; ?>>
    <div class="page-header-overlay"></div>
    <div class="container page-header-inner animate-on-scroll text-center">
        <h1 class="page-title"><?php the_title(); ?></h1>
        <h2 style="color: var(--color-accent); font-size: 1.5rem; font-weight: 500; font-family: var(--font-heading); margin-top: var(--space-sm);">Siamo a tua disposizione.</h2>
    </div>
</header>

<main id="primary" class="site-main">
    <div class="container">
        <div class="contact-layout animate-on-scroll">
            
            <!-- Lato Sinistro: Mappa Google -->
            <div class="contact-map" style="border-radius: var(--radius); overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.05); border: 1px solid rgba(0,0,0,0.03); height: 100%;">
                <iframe src="https://maps.google.com/maps?q=Frasco,+Switzerland&t=&z=12&ie=UTF8&iwloc=&output=embed" width="100%" height="100%" style="border:0; min-height: 450px;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>

            <!-- Lato Destro: Schede Interattive Contatti -->
            <div class="contact-sidebar">

                <?php if (!empty($email)): ?>
                <a href="mailto:<?php echo esc_attr($email); ?>" class="contact-card">
                    <div class="contact-icon-wrap">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                        </svg>
                    </div>
                    <div class="contact-info">
                        <h3>Mail</h3>
                        <p><?php echo esc_html($email); ?></p>
                    </div>
                </a>
                <?php endif; ?>

                <?php if (!empty($phone)): ?>
                <a href="tel:<?php echo esc_attr(str_replace(' ', '', $phone)); ?>" class="contact-card">
                    <div class="contact-icon-wrap">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                        </svg>
                    </div>
                    <div class="contact-info">
                        <h3>Telefono</h3>
                        <p><?php echo esc_html($phone); ?></p>
                    </div>
                </a>
                <?php endif; ?>

                <?php if (!empty($address)): ?>
                <div class="contact-card">
                    <div class="contact-icon-wrap">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                        </svg>
                    </div>
                    <div class="contact-info">
                        <h3>Indirizzo</h3>
                        <p><?php echo nl2br(esc_html($address)); ?></p>
                    </div>
                </div>
                <?php endif; ?>

            </div>

        </div>
    </div>

    <!-- Sezione Contatti Ufficio Patriziale -->
    <div class="container" style="margin-bottom: 80px;">
        <h2 style="font-family: var(--font-heading); color: var(--color-primary); font-size: 2rem; margin-bottom: var(--space-lg); text-align: center;">Contatti Ufficio Patriziale</h2>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: var(--space-lg);">
            <?php
            $ufficio_query = new WP_Query(array(
                'post_type' => 'ufficio',
                'posts_per_page' => -1,
                'orderby' => 'menu_order',
                'order' => 'ASC'
            ));
            if ($ufficio_query->have_posts()) :
                while ($ufficio_query->have_posts()) : $ufficio_query->the_post();
                    $ruolo = get_post_meta(get_the_ID(), '_ufficio_ruolo', true);
                    $uf_email = get_post_meta(get_the_ID(), '_ufficio_email', true);
            ?>
                <div style="background: var(--color-bg-pure-white); border-radius: var(--radius); padding: 25px 30px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); border: 1px solid rgba(0,0,0,0.03);">
                    <h3 style="margin: 0 0 4px 0; font-size: 1.15rem; font-family: var(--font-heading); color: var(--color-text-main);"><?php the_title(); ?></h3>
                    <?php if ($ruolo) : ?>
                        <p style="margin: 0 0 12px 0; font-size: 0.9rem; color: var(--color-primary); font-style: italic;"><?php echo esc_html($ruolo); ?></p>
                    <?php endif; ?>
                    <?php if ($uf_email) : ?>
                        <a href="mailto:<?php echo esc_attr($uf_email); ?>" style="color: var(--color-secondary); font-size: 0.95rem; text-decoration: none; font-weight: 500;"><?php echo esc_html($uf_email); ?></a>
                    <?php endif; ?>
                </div>
            <?php
                endwhile;
                wp_reset_postdata();
            endif;
            ?>
        </div>

        <h2 style="font-family: var(--font-heading); color: var(--color-primary); font-size: 2rem; margin: var(--space-lg) 0 var(--space-md); text-align: center;">Segretaria</h2>

        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: var(--space-lg);">
            <div style="background: var(--color-bg-pure-white); border-radius: var(--radius); padding: 25px 30px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); border: 1px solid rgba(0,0,0,0.03);">
                <h3 style="margin: 0 0 4px 0; font-size: 1.15rem; font-family: var(--font-heading); color: var(--color-text-main);">Daniela Gaggetta</h3>
                <p style="margin: 0 0 12px 0; font-size: 0.9rem; color: var(--color-primary); font-style: italic;">Segretaria</p>
                <p style="margin: 0 0 6px 0;"><a href="mailto:patriziatofrasco@bluewin.ch" style="color: var(--color-secondary); font-size: 0.95rem; text-decoration: none; font-weight: 500;">patriziatofrasco@bluewin.ch</a></p>
                <p style="margin: 0 0 6px 0;"><a href="tel:+41795706636" style="color: var(--color-secondary); font-size: 0.95rem; text-decoration: none; font-weight: 500;">079 570 66 36</a></p>
                <p style="margin: 0 0 6px 0; font-size: 0.95rem; color: var(--color-text-main);">Casella Postale 11, 6636 Frasco</p>
                <p style="margin: 0; font-size: 0.9rem; color: var(--color-text-light);"><strong>Orari cancelleria:</strong> Venerd&igrave; 8.00&ndash;11.00</p>
            </div>
        </div>

        <h2 style="font-family: var(--font-heading); color: var(--color-primary); font-size: 2rem; margin: var(--space-lg) 0 var(--space-md); text-align: center;">Canale WhatsApp</h2>

        <div style="background: var(--color-bg-pure-white); border-radius: var(--radius); padding: 30px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); border: 1px solid rgba(0,0,0,0.03); text-align: center; max-width: 420px; margin: 0 auto;">
            <p style="margin: 0 0 18px 0; color: var(--color-text-main);">Entra a far parte del nostro canale WhatsApp: scansiona il codice QR per restare aggiornato su novit&agrave; e comunicazioni del Patriziato.</p>
            <img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/07/Screenshot-2026-07-21-alle-15.54.30.png" alt="QR code canale WhatsApp Patriziato di Frasco" style="display: block; margin: 0 auto; max-width: 220px; width: 100%; height: auto;">
        </div>
    </div>

</main>

<?php get_footer(); ?>
