document.addEventListener('DOMContentLoaded', function() {
	// Header Scroll Effect - Cinematic transparent to blur
	const header = document.querySelector('.site-header');
	
	if (header) {
		window.addEventListener('scroll', function() {
			if (window.scrollY > 300) {
				header.classList.add('is-scrolled');
			} else {
				header.classList.remove('is-scrolled');
			}
		});
	}

	// Scroll Cue Click Behavior - Smooth scroll to next section
	const scrollCue = document.querySelector('.scroll-cue');
	if (scrollCue) {
		scrollCue.addEventListener('click', function() {
			const nextSection = document.querySelector('.section-chi-siamo');
			if (nextSection) {
				nextSection.scrollIntoView({ behavior: 'smooth' });
			}
		});
	}

	// Intersection Observer for Cinematic Reveal
	const observerOptions = {
		root: null,
		rootMargin: '0px 0px 50px 0px', // Scatta con 50px di anticipo
		threshold: 0 // Scatta al primo millimetro visibile
	};

	const revealObserver = new IntersectionObserver(function(entries, observer) {
		entries.forEach(function(entry) {
			if (entry.isIntersecting) {
				entry.target.classList.add('is-visible');
				// Let them stay visible to prevent re-animating on scroll up
				observer.unobserve(entry.target);
			}
		});
	}, observerOptions);

	// Select elements to animate
	const animateElements = document.querySelectorAll('.animate-on-scroll, .fp-text, .fp-media, .page-header, .page-header-cinematic');
	
	animateElements.forEach(function(el) {
		if (!el.classList.contains('animate-on-scroll')) {
			el.classList.add('animate-on-scroll');
		}
		
		revealObserver.observe(el);
	});

	// Lightweight Parallax Effect for Images
	const parallaxImages = document.querySelectorAll('.fp-media img');
	
	if (parallaxImages.length > 0) {
		window.addEventListener('scroll', function() {
			requestAnimationFrame(() => {
				parallaxImages.forEach(img => {
					// Only parallax if the image is in the viewport
					const rect = img.parentElement.getBoundingClientRect();
					if (rect.top < window.innerHeight && rect.bottom > 0) {
						// Calculate movement (move down slightly as we scroll down)
						const scrollPos = window.scrollY;
						const yPos = (rect.top - window.innerHeight / 2) * 0.15;
						img.style.transform = `translateY(${yPos}px) scale(1.15)`;
					}
				});
			});
		}, { passive: true });
	}

	// Mobile Menu Toggle
	var toggle = document.querySelector('.menu-toggle');
	var menu = document.querySelector('.main-navigation ul');

	if (toggle && menu) {
		// Initialize mobile dropdowns
		var parentItems = menu.querySelectorAll('.menu-item-has-children');
		parentItems.forEach(function(item) {
			// Ensure parent item is relative
			item.style.position = 'relative';
			
			// Create toggle button
			var btn = document.createElement('span');
			btn.className = 'mobile-submenu-toggle';
			btn.innerHTML = '▼';
			btn.style.cssText = 'position: absolute; right: 0; top: 0; width: 60px; padding-top: 18px; padding-bottom: 18px; cursor: pointer; z-index: 10; color: var(--color-primary-dark); font-size: 0.8em; display: none; align-items: center; justify-content: center;';
			
			// Show button only on mobile
			if (window.innerWidth <= 1200) {
				btn.style.display = 'flex';
			}
			window.addEventListener('resize', function() {
				if (window.innerWidth <= 1200) {
					btn.style.display = 'flex';
				} else {
					btn.style.display = 'none';
					item.classList.remove('submenu-open');
				}
			});

			var link = item.querySelector('a');
			link.parentNode.insertBefore(btn, link.nextSibling);
			
			// Toggle on click
			btn.addEventListener('click', function(e) {
				e.preventDefault();
				e.stopPropagation();
				
				// Seleziona gli altri menu e chiudili (Comportamento ad Accordion Singolo)
				if (!item.classList.contains('submenu-open')) {
					parentItems.forEach(function(otherItem) {
						if (otherItem !== item && otherItem.classList.contains('submenu-open')) {
							otherItem.classList.remove('submenu-open');
						}
					});
				}
				
				item.classList.toggle('submenu-open');
			});
		});

		toggle.addEventListener('click', function(e) {
			e.preventDefault();
			menu.classList.toggle('toggled');
			toggle.setAttribute('aria-expanded', menu.classList.contains('toggled'));
			
			// Nascondi o abbassa il pesce quando si apre il menu
			if (window.innerWidth <= 1200) {
				var fishContainer = document.querySelector('.pesce-volante-container');
				if (fishContainer) {
					if (menu.classList.contains('toggled')) {
						fishContainer.style.setProperty('display', 'none', 'important');
					} else {
						fishContainer.style.removeProperty('display');
					}
				}
			}
		});
	}
});

// Pesce Volante Animation
window.addEventListener('load', function() {
	setTimeout(function() {
		var container = document.querySelector('.pesce-volante-container');
		var bubble = document.querySelector('.pesce-bubble');
		
		if (container) {
			// Entra in scena
			container.classList.add('flying-in');
			
			// Si ferma a metà
			setTimeout(function() {
				// Apparizione morbidissima elastica
				bubble.classList.add('show');
				
				// Dopo che è apparsa, inizia a rimbalzare
				setTimeout(function() {
					bubble.classList.add('show-bounce');
				}, 600);
				
			}, 2000);

			container.addEventListener('mousedown', function(e) {
				e.preventDefault();
				if(bubble.classList.contains('show')) {
					// Nascondi fumetto morbidamente
					bubble.classList.remove('show');
					bubble.classList.remove('show-bounce');
					bubble.style.opacity = '0';
					
					// Riparti e esci
					container.classList.remove('flying-in');
					container.classList.add('flying-out');
					
					// Fai partire lo stormo
					stormoDiPesciVolanti();
				}
			});
			
			// Se l'utente scrolla, il pesce si spaventa e se ne va senza chiamare lo stormo
			window.addEventListener('scroll', function() {
				if (window.scrollY > 800 && bubble.classList.contains('show')) {
					bubble.classList.remove('show');
					bubble.classList.remove('show-bounce');
					bubble.style.opacity = '0';
					
					container.classList.remove('flying-in');
					container.classList.add('flying-out');
				}
			});
		}
	}, 1000); // Ritardo iniziale di 1 secondo
	
	function stormoDiPesciVolanti() {
		var imgSrc = 'https://ticinoweb04.jcloud.ik-server.com/patriziatofrasco/wp-content/uploads/sites/173/2026/06/pesce-volante.png';
		for (var i = 0; i < 15; i++) { // Solo 15 pesci per farlo durare meno
			setTimeout(function() {
				var fly = document.createElement('img');
				fly.src = imgSrc;
				fly.style.position = 'fixed';
				fly.style.left = '-300px';
				fly.style.top = (Math.random() * 80 + 10) + 'vh'; // Random altezza
				fly.style.width = (Math.random() * 80 + 50) + 'px'; // Variabili dimensioni (più grandi)
				fly.style.zIndex = '90';
				fly.style.pointerEvents = 'auto'; // Deve poter sentire il cursore
				fly.style.marginTop = '0px';
				// Campo di forza invisibile: allarga l'area sensibile al mouse di 80px in ogni direzione
				fly.style.border = '80px solid transparent';
				fly.style.borderRadius = '50%';
				fly.style.boxSizing = 'content-box';
				
				var isMobile = window.innerWidth <= 768;
				var baseDuration = isMobile ? 1.5 : 3;
				var varDuration = isMobile ? 2 : 4;
				var duration = Math.random() * varDuration + baseDuration;
				var wave = (Math.random() * 200 - 100); // Movimento a onda su Y
				
				// Aggiungiamo margin-top alle transizioni per lo scarto rapido
				fly.style.transition = 'margin-top 0.4s cubic-bezier(0.25, 1, 0.5, 1), left ' + duration + 's linear, transform ' + duration + 's ease-in-out';
				fly.style.transform = 'translateY(0) rotate(' + (Math.random() * 20 + 10) + 'deg)';
				
				// Intelligenza per evitare il cursore
				fly.addEventListener('mouseover', function(e) {
					var currentMargin = parseFloat(this.style.marginTop) || 0;
					var rect = this.getBoundingClientRect();
					var fishCenterY = rect.top + rect.height / 2;
					
					// Se il mouse arriva da sopra scappa giù, se arriva da sotto scappa su
					var dodgeY = e.clientY > fishCenterY ? -150 : 150; 
					
					// Applica lo scarto e inclina un po' il pesce per dare l'effetto di "guizzo"
					this.style.marginTop = (currentMargin + dodgeY) + 'px';
				});
				
				document.body.appendChild(fly);
				
				// Trigger del movimento
				setTimeout(function() {
					fly.style.left = '120vw';
					fly.style.transform = 'translateY(' + wave + 'px) rotate(' + (Math.random() * 20 + 10) + 'deg)';
				}, 50);
				
				// Pulizia
				setTimeout(function() {
					fly.remove();
				}, duration * 1000 + 100);
			}, i * 200); // Ritardo originale tra i pesci
		}
	}
});
