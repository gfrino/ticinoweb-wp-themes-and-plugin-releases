<?php
/**
 * Template Name: Pubblicazioni
 */
get_header();

$hero_img = parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) . '/2026/06/Logo-hd.png'; // Fallback
?>
<style>
.pub-catalog { max-width: 1200px; margin: var(--space-xl) auto; padding: 0 var(--space-md); }
.pub-intro { text-align: center; max-width: 800px; margin: 0 auto var(--space-xl) auto; font-size: 1.15rem; line-height: 1.8; color: var(--color-text-main); }
.pub-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: var(--space-lg); }
.pub-card { display: flex; flex-direction: column; background: var(--color-bg-pure-white); border-radius: var(--radius); overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.06); border: 1px solid rgba(0,0,0,0.03); transition: transform 0.3s ease; }
.pub-card:hover { transform: translateY(-5px); box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
/* Copertine mostrate per intero: contain + padding, mai ritagliate */
.pub-img { background: var(--color-bg-body); display: flex; align-items: center; justify-content: center; overflow: hidden; padding: var(--space-md); }
.pub-img img { width: 100%; height: auto; max-height: 400px; object-fit: contain; transition: transform 0.5s ease; }
.pub-card:hover .pub-img img { transform: scale(1.05); }
.pub-content { flex: 1; padding: var(--space-lg); display: flex; flex-direction: column; }
.pub-content h3 { color: var(--color-primary); margin: 0 0 10px 0; font-size: 1.5rem; line-height: 1.3; font-family: var(--font-heading); }
.pub-content .price { font-size: 1.2rem; color: var(--color-text-main); font-weight: bold; margin-bottom: 15px; display: block; }
.pub-content p { font-size: 1rem; margin-bottom: 8px; color: var(--color-text-main); line-height: 1.6; }
.pub-content .authors { font-size: 1.05rem; color: var(--color-primary); margin-bottom: 10px; font-weight: 500; }
.pub-content .pub-excerpt { font-size: 0.95rem; color: var(--color-text-light); line-height: 1.7; margin-top: 8px; }
.pub-lang-label { color: var(--color-primary); }
/* Spinge il pulsante in fondo: le card della stessa riga restano allineate */
.pub-action { margin-top: auto; padding-top: 20px; }

/* Modalità scura: il blu su fondo grigio non è leggibile, si passa all'azzurro d'accento */
html[data-theme="dark"] .pub-content .authors,
html[data-theme="dark"] .pub-lang-label { color: var(--color-accent-text); }

@media (max-width: 900px) {
    .pub-grid { grid-template-columns: 1fr; }
}
@media (max-width: 768px) {
    .pub-img img { max-height: 300px; }
    .pub-content { padding: var(--space-md); }
}

.external-shop {
    margin-top: var(--space-xxl);
    text-align: center;
    padding: var(--space-xl);
    background: var(--color-bg-white);
    border-radius: var(--radius);
    box-shadow: 0 10px 30px rgba(0,0,0,0.05);
    border-top: 4px solid var(--color-primary);
}

.btn-primary {
    display: inline-block;
    background: var(--color-primary);
    color: #FFFFFF;
    padding: 12px 30px;
    border-radius: 50px;
    text-decoration: none;
    font-weight: bold;
    font-size: 1.1rem;
    transition: background 0.3s ease, transform 0.2s ease;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}
.btn-primary:hover {
    background: var(--color-primary-dark);
    transform: translateY(-2px);
    color: #FFFFFF;
}
</style>

<div class="page-header-cinematic no-bg" style="background-color: var(--color-primary-dark);">
    <div class="page-header-overlay"></div>
    <div class="container page-header-inner animate-on-scroll">
        <h1 class="page-title">Pubblicazioni</h1>
        <h2 style="color: var(--color-accent); font-size: 1.5rem; font-weight: 500; font-family: var(--font-heading); margin-top: var(--space-sm);">Scopri i libri del nostro territorio.</h2>
    </div>
</div>

<main id="primary" class="site-main">
    <div class="pub-catalog">
        
        <div class="pub-intro animate-on-scroll">
            <p>Il Patriziato di Frasco promuove e sostiene le pubblicazioni legate al nostro territorio, alla sua storia e alle tradizioni della nostra comunità.</p>
        </div>

        <div class="pub-grid animate-on-scroll">
            
            <?php
            $pub_query = new WP_Query( array(
                'post_type'      => 'pubblicazione',
                'posts_per_page' => -1,
                'order'          => 'ASC'
            ) );

            if ( $pub_query->have_posts() ) :
                while ( $pub_query->have_posts() ) : $pub_query->the_post();
                    $post_id = get_the_ID();
                    $thumbnail_url = has_post_thumbnail() ? get_the_post_thumbnail_url( $post_id, 'large' ) : parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) . '/2026/06/Logo-hd.png';
                    
                    $price = get_post_meta( $post_id, '_pub_price', true );
                    $authors = get_post_meta( $post_id, '_pub_authors', true );
                    $edition = get_post_meta( $post_id, '_pub_edition', true );
                    $languages = get_post_meta( $post_id, '_pub_languages', true );
                    $link = get_post_meta( $post_id, '_pub_link', true );
                    $link_text = get_post_meta( $post_id, '_pub_link_text', true ) ?: 'Acquista online';
            ?>
                    <div class="pub-card">
                        <?php if ( $link ) : ?>
                            <a href="<?php echo esc_url( $link ); ?>" target="_blank" rel="noopener noreferrer" class="pub-img" style="cursor: pointer;">
                        <?php else : ?>
                            <div class="pub-img">
                        <?php endif; ?>
                            <img src="<?php echo esc_url( $thumbnail_url ); ?>" alt="<?php the_title_attribute(); ?>">
                        <?php if ( $link ) : ?>
                            </a>
                        <?php else : ?>
                            </div>
                        <?php endif; ?>
                        
                        <div class="pub-content">
                            <h3><?php the_title(); ?></h3>
                            <?php if ( $price ) : ?><div class="price"><?php echo esc_html( $price ); ?></div><?php endif; ?>
                            <?php if ( $authors ) : ?><p class="authors"><?php echo esc_html( $authors ); ?></p><?php endif; ?>
                            <?php if ( $edition ) : ?><p><em><?php echo esc_html( $edition ); ?></em></p><?php endif; ?>
                            <?php if ( $languages ) : ?><p style="margin-top: 10px;"><strong class="pub-lang-label">Lingue:</strong> <?php echo esc_html( $languages ); ?></p><?php endif; ?>

                            <?php
                            $excerpt = get_the_excerpt();
                            if ( $excerpt ) : ?>
                                <p class="pub-excerpt"><?php echo esc_html( $excerpt ); ?></p>
                            <?php endif; ?>

                            <?php if ( $link ) : ?>
                                <div class="pub-action">
                                    <a href="<?php echo esc_url( $link ); ?>" target="_blank" rel="noopener noreferrer" class="btn-primary" style="font-size: 1rem; padding: 10px 25px;"><?php echo esc_html( $link_text ); ?></a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
            <?php
                endwhile;
                wp_reset_postdata();
            else :
            ?>
                <p style="text-align: center; color: var(--color-text-light);">Nessun libro pubblicato al momento.</p>
            <?php endif; ?>

        </div>

        <div class="external-shop animate-on-scroll">
            <h3 style="color: var(--color-primary-dark); margin-bottom: 15px; font-size: 1.8rem;">Altre pubblicazioni sulla Valle Verzasca</h3>
            <p style="margin-bottom: 25px; font-size: 1.15rem; color: var(--color-text-main); max-width: 800px; margin-left: auto; margin-right: auto;">Sei interessato ad approfondire la storia, la cultura e le tradizioni della nostra splendida valle? Visita lo shop del Museo Val Verzasca per scoprire un'ampia selezione di libri dedicati al nostro territorio.</p>
            <a href="https://www.museovalverzasca.ch/shop" target="_blank" class="btn-primary">Vai allo Shop del Museo Val Verzasca</a>
        </div>

    </div>
</main>

<?php get_footer(); ?>
