<?php
/**
 * Template Name: Formulari
 */
get_header();

// Email di destinazione
$admin_email = get_option('ticinoweb_contact_email', 'patriziatofrasco@bluewin.ch');
$message_status = '';

// Gestione invio modulo
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_formulario'])) {
    if ( ! isset( $_POST['formulario_nonce'] ) || ! wp_verify_nonce( $_POST['formulario_nonce'], 'submit_formulario_action' ) ) {
        $message_status = '<div class="alert alert-error">Errore di sicurezza. Riprova.</div>';
    } else {
        $form_type = sanitize_text_field($_POST['form_type']);
        $nome = sanitize_text_field($_POST['nome']);
        $cognome = sanitize_text_field($_POST['cognome']);
        $email = sanitize_email($_POST['email']);
        $telefono = sanitize_text_field($_POST['telefono']);
        
        $subject = "Nuova richiesta dal sito: " . $form_type;
        $body = "Hai ricevuto una nuova richiesta tramite il sito web del Patriziato di Frasco.\n\n";
        $body .= "TIPO DI RICHIESTA: " . $form_type . "\n";
        $body .= "Nome e Cognome: $nome $cognome\n";
        $body .= "Email: $email\n";
        $body .= "Telefono: $telefono\n\n";

        if ($form_type === 'Taglio Legna') {
            $zona = sanitize_text_field($_POST['zona']);
            $dettagli = sanitize_textarea_field($_POST['dettagli']);
            $body .= "Zona/Mappale: $zona\n";
            $body .= "Dettagli/Quantità: \n$dettagli\n";
        } elseif ($form_type === 'Chiave Strada Vald') {
            $periodo = sanitize_text_field($_POST['periodo']);
            $motivazione = sanitize_textarea_field($_POST['motivazione']);
            $body .= "Periodo: $periodo\n";
            $body .= "Motivazione: \n$motivazione\n";
        }

        $headers = array('Content-Type: text/plain; charset=UTF-8', 'Reply-To: ' . $email);
        
        if (wp_mail($admin_email, $subject, $body, $headers)) {
            $message_status = '<div class="alert alert-success">Richiesta inviata con successo. L\'Ufficio Patriziale ti risponderà al più presto.</div>';
        } else {
            $message_status = '<div class="alert alert-error">Si è verificato un errore durante l\'invio. Riprova più tardi o contattaci direttamente via email.</div>';
        }
    }
}

$has_thumbnail = has_post_thumbnail();
$thumbnail_url = $has_thumbnail ? get_the_post_thumbnail_url(get_the_ID(), 'full') : '';
$header_class = $has_thumbnail ? 'page-header-cinematic has-bg' : 'page-header-cinematic no-bg';
?>

<!-- Flatpickr CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">

<style>
.formulari-wrapper {
    max-width: 900px;
    margin: var(--space-xl) auto;
    padding: 0 var(--space-md);
}

.forms-nav {
    display: flex;
    gap: 15px;
    margin-bottom: 30px;
    justify-content: center;
    flex-wrap: wrap;
}

.form-tab-btn {
    background: #f0f4f8;
    color: var(--color-primary-dark);
    border: 2px solid transparent;
    padding: 15px 30px;
    border-radius: 50px;
    font-weight: bold;
    cursor: pointer;
    transition: all 0.3s;
    font-size: 1.1rem;
}

.form-tab-btn:hover {
    background: var(--color-primary);
    color: #FFFFFF;
}

.form-tab-btn.active {
    background: var(--color-primary);
    color: white;
    border-color: var(--color-primary-dark);
    box-shadow: 0 5px 15px rgba(14,42,102,0.2);
}

.form-panel {
    display: none;
    background: var(--color-bg-pure-white);
    padding: 40px;
    border-radius: var(--radius);
    box-shadow: 0 10px 40px rgba(0,0,0,0.05);
    border: 1px solid rgba(0,0,0,0.03);
    animation: fadeIn 0.4s ease-out forwards;
}

.form-panel.active {
    display: block;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
}

.form-panel h3 {
    color: var(--color-primary-dark);
    margin-top: 0;
    margin-bottom: 10px;
    font-size: 1.8rem;
    font-family: var(--font-heading);
}

.form-panel p.intro {
    color: var(--color-text-light);
    margin-bottom: 30px;
    font-size: 1.05rem;
}

.pf-form-group {
    margin-bottom: 25px;
}

.pf-form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}

@media (max-width: 600px) {
    .pf-form-row {
        grid-template-columns: 1fr;
        gap: 0;
    }
    .form-panel { padding: 25px; }
}

.pf-form-group label {
    display: block;
    font-weight: 600;
    margin-bottom: 8px;
    color: var(--color-text);
}

.pf-form-group input[type="text"],
.pf-form-group input[type="email"],
.pf-form-group input[type="tel"],
.pf-form-group textarea {
    width: 100%;
    padding: 14px 18px;
    border: 1px solid #d1d5db;
    border-radius: 8px;
    font-size: 1rem;
    font-family: inherit;
    transition: all 0.3s;
    background: #f9fafb;
}

.pf-form-group input:focus,
.pf-form-group textarea:focus {
    outline: none;
    border-color: var(--color-primary);
    background: white;
    box-shadow: 0 0 0 4px rgba(14,42,102,0.1);
}

.pf-form-group textarea {
    resize: vertical;
    min-height: 120px;
}

.btn-submit {
    background: var(--color-accent);
    color: var(--color-primary-dark);
    border: none;
    padding: 16px 40px;
    font-size: 1.1rem;
    font-weight: bold;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s;
    display: inline-block;
    width: 100%;
    margin-top: 10px;
}

.btn-submit:hover {
    background: var(--color-primary);
    color: #FFFFFF;
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(60, 105, 231, 0.35);
}

.alert {
    padding: 20px;
    border-radius: 8px;
    margin-bottom: 30px;
    font-weight: bold;
    text-align: center;
}

.alert-success {
    background-color: #def7ec;
    color: #03543f;
    border: 1px solid #31c48d;
}

.alert-error {
    background-color: #fde8e8;
    color: #9b1c1c;
    border: 1px solid #f8b4b4;
}
</style>

<header class="<?php echo esc_attr($header_class); ?>" <?php if ($has_thumbnail) echo 'style="background-image: url(\'' . esc_url($thumbnail_url) . '\');"'; ?>>
    <div class="page-header-overlay"></div>
    <div class="container page-header-inner animate-on-scroll text-center">
        <h1 class="page-title"><?php the_title(); ?></h1>
        <h2 style="color: var(--color-accent); font-size: 1.5rem; font-weight: 500; font-family: var(--font-heading); margin-top: var(--space-sm);">Compila e invia le tue richieste online.</h2>
    </div>
</header>

<main id="primary" class="site-main">
    <div class="formulari-wrapper">

        <?php echo $message_status; ?>

        <div class="forms-nav animate-on-scroll">
            <button class="form-tab-btn active" onclick="openForm('legna')">Taglio Legna</button>
            <button class="form-tab-btn" onclick="openForm('vald')">Chiave Strada Vald</button>
        </div>

        <!-- FORM: Taglio Legna -->
        <div id="form-legna" class="form-panel active">
            <h3>Richiesta Taglio Legna</h3>
            <p class="intro">Compila il modulo sottostante per richiedere l'autorizzazione al taglio della legna sui fondi patriziali.</p>
            
            <form action="" method="POST">
                <?php wp_nonce_field('submit_formulario_action', 'formulario_nonce'); ?>
                <input type="hidden" name="form_type" value="Taglio Legna">
                
                <div class="pf-form-row">
                    <div class="pf-form-group">
                        <label>Nome *</label>
                        <input type="text" name="nome" required placeholder="Il tuo nome">
                    </div>
                    <div class="pf-form-group">
                        <label>Cognome *</label>
                        <input type="text" name="cognome" required placeholder="Il tuo cognome">
                    </div>
                </div>

                <div class="pf-form-row">
                    <div class="pf-form-group">
                        <label>Email *</label>
                        <input type="email" name="email" required placeholder="indirizzo@email.com">
                    </div>
                    <div class="pf-form-group">
                        <label>Telefono / Cellulare *</label>
                        <input type="tel" name="telefono" required placeholder="+41 ...">
                    </div>
                </div>

                <div class="pf-form-group">
                    <label>Zona o Mappale (Opzionale)</label>
                    <input type="text" name="zona" placeholder="Indica la zona in cui intendi operare">
                </div>

                <div class="pf-form-group">
                    <label>Dettagli e Quantità Stimata *</label>
                    <textarea name="dettagli" required placeholder="Descrivi il tipo di taglio e la quantità approssimativa che desideri prelevare..."></textarea>
                </div>

                <button type="submit" name="submit_formulario" class="btn-submit">Invia Richiesta</button>
            </form>
        </div>

        <!-- FORM: Chiave Strada Vald -->
        <div id="form-vald" class="form-panel">
            <h3>Richiesta Chiave Strada Vald</h3>
            <p class="intro">Modulo per la richiesta temporanea o stagionale della chiave per l'accesso alla Strada Vald.</p>
            
            <form action="" method="POST">
                <?php wp_nonce_field('submit_formulario_action', 'formulario_nonce'); ?>
                <input type="hidden" name="form_type" value="Chiave Strada Vald">
                
                <div class="pf-form-row">
                    <div class="pf-form-group">
                        <label>Nome *</label>
                        <input type="text" name="nome" required placeholder="Il tuo nome">
                    </div>
                    <div class="pf-form-group">
                        <label>Cognome *</label>
                        <input type="text" name="cognome" required placeholder="Il tuo cognome">
                    </div>
                </div>

                <div class="pf-form-row">
                    <div class="pf-form-group">
                        <label>Email *</label>
                        <input type="email" name="email" required placeholder="indirizzo@email.com">
                    </div>
                    <div class="pf-form-group">
                        <label>Telefono / Cellulare *</label>
                        <input type="tel" name="telefono" required placeholder="+41 ...">
                    </div>
                </div>

                <div class="pf-form-group">
                    <label>Periodo di necessità (Seleziona uno o più giorni dal calendario) *</label>
                    <input type="text" name="periodo" id="periodo_calendario" required placeholder="Clicca per aprire il calendario..." readonly style="background: white; cursor: pointer;">
                </div>

                <div class="pf-form-group">
                    <label>Motivazione / Esigenze particolari *</label>
                    <textarea name="motivazione" required placeholder="Spiega brevemente il motivo della richiesta..."></textarea>
                </div>

                <button type="submit" name="submit_formulario" class="btn-submit">Invia Richiesta</button>
            </form>
        </div>

    </div>
</main>

<script>
function openForm(formName) {
    // Nascondi tutti i pannelli
    document.querySelectorAll('.form-panel').forEach(panel => {
        panel.classList.remove('active');
    });
    
    // Disattiva tutti i bottoni
    document.querySelectorAll('.form-tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Attiva il pannello e il bottone scelti
    document.getElementById('form-' + formName).classList.add('active');
    event.currentTarget.classList.add('active');
}
</script>

<!-- Flatpickr JS & Lingua Italiana -->
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/it.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Inizializza il calendario per il periodo
    flatpickr("#periodo_calendario", {
        mode: "range",
        locale: "it",
        dateFormat: "d/m/Y",
        minDate: "today", // Disabilita i giorni passati
        disableMobile: "true" // Usa lo stile personalizzato anche su mobile per coerenza
    });
});
</script>

<?php get_footer(); ?>
