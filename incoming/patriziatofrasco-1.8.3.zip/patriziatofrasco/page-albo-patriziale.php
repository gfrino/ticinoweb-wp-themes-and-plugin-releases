<?php
/**
 * Template Name: Albo Patriziale
 */
get_header();
?>
<style>
.albo-catalog { max-width: 1200px; margin: var(--space-xl) auto; padding: 0 var(--space-md); }
.albo-intro { text-align: center; max-width: 800px; margin: 0 auto var(--space-xl) auto; font-size: 1.15rem; line-height: 1.8; color: var(--color-text-main); }
.albo-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: var(--space-lg); }
.albo-card { background: var(--color-bg-pure-white); border-radius: var(--radius); overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.05); border: 1px solid rgba(0,0,0,0.05); transition: transform 0.3s ease, box-shadow 0.3s ease; cursor: pointer; display: block; text-decoration: none; color: inherit; }
.albo-card:hover { transform: translateY(-5px); box-shadow: 0 10px 25px rgba(22,58,138,0.1); }
.albo-icon { height: 150px; background: rgba(60, 105, 231, 0.05); display: flex; align-items: center; justify-content: center; color: var(--color-primary); transition: all 0.3s ease; }
.albo-card:hover .albo-icon { background: var(--color-primary); color: white; }
.albo-content { padding: var(--space-md); text-align: center; }
.albo-content h3 { color: var(--color-primary-dark); margin: 0; font-size: 1.5rem; }
</style>

<div class="page-header-cinematic no-bg" style="background-color: var(--color-primary-dark);">
    <div class="page-header-overlay"></div>
    <div class="container page-header-inner animate-on-scroll">
        <h1 class="page-title">Albo Patriziale</h1>
        <h2 style="color: var(--color-accent); font-size: 1.5rem; font-weight: 500; font-family: var(--font-heading); margin-top: var(--space-sm);">Documenti ufficiali e organi istituzionali.</h2>
    </div>
</div>

<main id="primary" class="site-main">
    <div class="albo-catalog">
        
        <div class="albo-intro animate-on-scroll">
            <p>Benvenuti nell'Albo Patriziale. In questa sezione è possibile consultare tutti i documenti ufficiali, i comunicati, il regolamento, le attività in programma, scoprire le famiglie patrizie e l'organizzazione dell'Assemblea.</p>
        </div>

        <div class="albo-grid animate-on-scroll">
            <!-- Comunicati -->
            <a href="<?php echo esc_url( home_url( '/comunicati/' ) ); ?>" class="albo-card">
                <div class="albo-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" style="width: 4rem; height: 4rem;">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M10.34 15.84c-.688-.06-1.386-.09-2.09-.09H7.5a4.5 4.5 0 1 1 0-9h.75c.704 0 1.402-.03 2.09-.09m0 9.18c.253.962.584 1.892.985 2.783.247.55.06 1.21-.463 1.511l-.657.38c-.551.318-1.26.117-1.527-.461a20.845 20.845 0 0 1-1.44-4.282m3.102.069a18.03 18.03 0 0 1-.59-4.59c0-1.586.205-3.124.59-4.59m0 9.18a23.848 23.848 0 0 1 8.835 2.535M10.34 6.66a23.847 23.847 0 0 0 8.835-2.535m0 0A23.74 23.74 0 0 0 18.795 3m.38 1.125a23.91 23.91 0 0 1 1.014 5.395m-1.014 8.855c-.118.38-.245.754-.38 1.125m.38-1.125a23.91 23.91 0 0 0 1.014-5.395m0-3.46c.495.413.811 1.035.811 1.73 0 .695-.316 1.317-.811 1.73m0-3.46a24.347 24.347 0 0 1 0 3.46" />
                    </svg>
                </div>
                <div class="albo-content">
                    <h3>Comunicati</h3>
                </div>
            </a>

            <!-- Regolamento -->
            <a href="<?php echo esc_url( home_url( '/regolamento/' ) ); ?>" class="albo-card">
                <div class="albo-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" style="width: 4rem; height: 4rem;">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 0 0 2.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 0 0-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 0 0 .75-.75 2.25 2.25 0 0 0-.1-.664m-5.8 0A2.251 2.251 0 0 1 13.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25ZM6.75 12h.008v.008H6.75V12Zm0 3h.008v.008H6.75V15Zm0 3h.008v.008H6.75V18Z" />
                    </svg>
                </div>
                <div class="albo-content">
                    <h3>Regolamento</h3>
                </div>
            </a>

            <!-- Famiglie Patrizie -->
            <a href="<?php echo esc_url( home_url( '/famiglie-patrizie/' ) ); ?>" class="albo-card">
                <div class="albo-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" style="width: 4rem; height: 4rem;">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M15 19.128a9.38 9.38 0 0 0 2.625.372 9.337 9.337 0 0 0 4.121-.952 4.125 4.125 0 0 0-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 0 1 8.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0 1 11.964-3.07M12 6.375a3.375 3.375 0 1 1-6.75 0 3.375 3.375 0 0 1 6.75 0Zm8.25 2.25a2.625 2.625 0 1 1-5.25 0 2.625 2.625 0 0 1 5.25 0Z" />
                    </svg>
                </div>
                <div class="albo-content">
                    <h3>Famiglie Patrizie</h3>
                </div>
            </a>
            
             <!-- Assemblea Patriziale -->
            <a href="<?php echo esc_url( home_url( '/organizzazione/' ) ); ?>" class="albo-card">
                <div class="albo-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" style="width: 4rem; height: 4rem;">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M12 21v-8.25M15.75 21v-8.25M8.25 21v-8.25M3 9l9-6 9 6m-1.5 12V10.332A48.36 48.36 0 0 0 12 9.75c-2.551 0-5.056.2-7.5.582V21M3 21h18M12 6.75h.008v.008H12V6.75Z" />
                    </svg>
                </div>
                <div class="albo-content">
                    <h3>Organizzazione</h3>
                </div>
            </a>

            <!-- Attività -->
            <a href="<?php echo esc_url( home_url( '/attivita/' ) ); ?>" class="albo-card">
                <div class="albo-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" style="width: 4rem; height: 4rem;">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 0 1 2.25-2.25h13.5A2.25 2.25 0 0 1 21 7.5v11.25m-18 0A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75m-18 0v-7.5A2.25 2.25 0 0 1 5.25 9h13.5A2.25 2.25 0 0 1 21 11.25v7.5m-9-6h.008v.008H12v-.008ZM12 15h.008v.008H12V15Zm0 2.25h.008v.008H12v-.008ZM9.75 15h.008v.008H9.75V15Zm0 2.25h.008v.008H9.75v-.008ZM7.5 15h.008v.008H7.5V15Zm0 2.25h.008v.008H7.5v-.008Zm6.75-4.5h.008v.008h-.008v-.008Zm0 2.25h.008v.008h-.008V15Zm0 2.25h.008v.008h-.008v-.008Zm2.25-4.5h.008v.008H16.5v-.008Zm0 2.25h.008v.008H16.5V15Z" />
                    </svg>
                </div>
                <div class="albo-content">
                    <h3>Attività</h3>
                </div>
            </a>
        </div>

    </div>
</main>

<?php get_footer(); ?>
