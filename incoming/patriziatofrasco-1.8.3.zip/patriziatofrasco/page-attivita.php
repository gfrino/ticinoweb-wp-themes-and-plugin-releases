<?php
/**
 * Template Name: Pagina Attività
 * 
 * Modello per visualizzare l'elenco delle attività.
 */

get_header();

?>

<style>
/* Stili specifici per la lista Attività */
.attivita-list {
    max-width: 1000px;
    margin: 0 auto 80px auto;
    display: flex;
    flex-direction: column;
    gap: 40px;
}
.attivita-card {
    background: var(--color-bg-pure-white);
    border-radius: var(--radius);
    border: 1px solid rgba(0,0,0,0.08);
    box-shadow: 0 10px 30px rgba(0,0,0,0.05);
    display: flex;
    flex-direction: row;
    overflow: hidden;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.attivita-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 40px rgba(0,0,0,0.08);
}
.attivita-card.stato-conclusa {
    opacity: 0.75;
    background: #fdfdfd;
}
.attivita-card.stato-annullata {
    opacity: 0.6;
    background: #fafafa;
}
.attivita-card.stato-conclusa:hover, .attivita-card.stato-annullata:hover {
    transform: none;
    box-shadow: 0 10px 30px rgba(0,0,0,0.05);
}

.attivita-image {
    width: 35%;
    min-width: 300px;
    background-size: cover;
    background-position: center;
    background-color: var(--color-bg-light);
}

.attivita-content {
    padding: 30px;
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.attivita-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    flex-wrap: wrap;
    gap: 15px;
}
.attivita-title {
    color: var(--color-primary-dark);
    margin: 0;
    font-size: 1.8rem;
    font-family: var(--font-heading);
}

.attivita-status {
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 0.85rem;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    white-space: nowrap;
}
/* Colori semantici per lo stato */
.status-programmata { background-color: #d1ecf1; color: #0c5460; border: 1px solid #bee5eb; }
.status-conclusa { background-color: #e2e3e5; color: #383d41; border: 1px solid #d6d8db; }
.status-annullata { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }

.attivita-tipologia {
    display: inline-block;
    background: var(--color-primary);
    color: white;
    padding: 3px 10px;
    border-radius: 4px;
    font-size: 0.85rem;
    font-weight: bold;
    margin-bottom: 5px;
}

.attivita-meta {
    font-size: 0.95rem;
    color: var(--color-text-light);
    display: flex;
    flex-direction: column;
    gap: 8px;
}
.attivita-meta-item {
    display: flex;
    align-items: center;
    gap: 8px;
}
.attivita-meta strong {
    color: var(--color-text);
}

.attivita-excerpt {
    color: var(--color-text);
    line-height: 1.6;
    margin: 10px 0 0 0;
}

.attivita-action {
    margin-top: auto;
    padding-top: 15px;
}
.btn-attivita {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    background: var(--color-primary);
    color: white;
    padding: 10px 20px;
    border-radius: 4px;
    text-decoration: none;
    font-weight: bold;
    transition: background-color 0.3s;
}
.btn-attivita:hover {
    background: var(--color-primary-dark);
    color: white;
}

.attivita-empty {
    text-align: center;
    padding: 60px 20px;
    background: var(--color-bg-light);
    border-radius: var(--radius);
    color: var(--color-text-light);
    font-size: 1.1rem;
    font-style: italic;
}

/* Responsività */
@media (max-width: 768px) {
    .attivita-card {
        flex-direction: column;
    }
    .attivita-image {
        width: 100%;
        min-width: 100%;
        height: 250px;
    }
}
</style>

<!-- Hero Section -->
<div class="page-header-cinematic no-bg" style="background-color: var(--color-primary-dark);">
    <div class="page-header-overlay"></div>
    <div class="container page-header-inner text-center animate-on-scroll">
        <h1 class="page-title"><?php the_title(); ?></h1>
        <h2 style="color: var(--color-accent); font-size: 1.5rem; font-weight: 500; font-family: var(--font-heading); margin-top: var(--space-sm);">Gli appuntamenti e gli eventi del Patriziato</h2>
    </div>
</div>

<main id="primary" class="site-main">
    <div class="container section-padding">

        <!-- Lista Attività -->
        <div class="attivita-list">
            <?php
            // Query per le attività pubblicate
            $attivita_args = array(
                'post_type'      => 'attivita',
                'post_status'    => 'publish',
                'posts_per_page' => -1, // Mostra tutte
                'meta_key'       => '_attivita_data', // Ordina per la data personalizzata
                'orderby'        => 'meta_value',
                'order'          => 'DESC' // Dalla più recente alla più vecchia
            );
            $attivita_query = new WP_Query( $attivita_args );

            if ( $attivita_query->have_posts() ) :

                while ( $attivita_query->have_posts() ) : $attivita_query->the_post();
                    $attivita_id = get_the_ID();
                    $tipologia = get_post_meta( $attivita_id, '_attivita_tipologia', true );
                    $data = get_post_meta( $attivita_id, '_attivita_data', true );
                    $ora_inizio = get_post_meta( $attivita_id, '_attivita_ora_inizio', true );
                    $ora_fine = get_post_meta( $attivita_id, '_attivita_ora_fine', true );
                    $luogo = get_post_meta( $attivita_id, '_attivita_luogo', true );
                    $stato = get_post_meta( $attivita_id, '_attivita_stato', true );
                    $pdf_id = get_post_meta( $attivita_id, '_attivita_pdf_id', true );
                    $pdf_url = $pdf_id ? wp_get_attachment_url( $pdf_id ) : '';
                    
                    // Immagine
                    $img_url = has_post_thumbnail() ? get_the_post_thumbnail_url($attivita_id, 'large') : '';

                    // Formattazione data
                    $data_formattata = $data ? date_i18n( 'j F Y', strtotime( $data ) ) : 'Data da definire';

                    // Formattazione ora
                    $ora_formattata = '';
                    if ($ora_inizio) {
                        $ora_formattata = date_i18n('H:i', strtotime($ora_inizio));
                        if ($ora_fine) {
                            $ora_formattata .= ' - ' . date_i18n('H:i', strtotime($ora_fine));
                        }
                    }

                    // Classi stato
                    $status_class = 'status-programmata';
                    $card_class = 'stato-programmata';
                    if ( $stato == 'Conclusa' ) {
                        $status_class = 'status-conclusa';
                        $card_class = 'stato-conclusa';
                    }
                    if ( $stato == 'Annullata' ) {
                        $status_class = 'status-annullata';
                        $card_class = 'stato-annullata';
                    }
                    ?>

                    <div class="attivita-card <?php echo esc_attr($card_class); ?> animate-on-scroll">
                        
                        <?php if ($img_url) : ?>
                        <div class="attivita-image" style="background-image: url('<?php echo esc_url($img_url); ?>');"></div>
                        <?php endif; ?>

                        <div class="attivita-content">
                            <div class="attivita-header">
                                <div>
                                    <?php if ($tipologia): ?>
                                        <span class="attivita-tipologia"><?php echo esc_html($tipologia); ?></span>
                                    <?php endif; ?>
                                    <h2 class="attivita-title"><?php the_title(); ?></h2>
                                </div>
                                <?php if ( $stato ) : ?>
                                    <span class="attivita-status <?php echo esc_attr($status_class); ?>">
                                        <?php echo esc_html($stato); ?>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="attivita-meta">
                                <div class="attivita-meta-item">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="var(--color-primary)"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                                    <span>Data: <strong><?php echo esc_html($data_formattata); ?></strong></span>
                                </div>
                                
                                <?php if ( $ora_formattata ) : ?>
                                <div class="attivita-meta-item">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="var(--color-primary)"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                    <span>Ora: <strong><?php echo esc_html($ora_formattata); ?></strong></span>
                                </div>
                                <?php endif; ?>

                                <?php if ( $luogo ) : ?>
                                <div class="attivita-meta-item">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="var(--color-primary)"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                                    <span>Luogo: <strong><?php echo esc_html($luogo); ?></strong></span>
                                </div>
                                <?php endif; ?>
                            </div>

                            <?php if ( has_excerpt() ) : ?>
                                <div class="attivita-excerpt">
                                    <?php the_excerpt(); ?>
                                </div>
                            <?php endif; ?>

                            <?php
                            // Nota: il pulsante di download non si stampa qui.
                            // Lo fornisce gia' ptf_render_pdf_embed() sotto l'anteprima:
                            // due pulsanti con lo stesso link confondevano il lettore.
                            ?>
                            <?php
                            // Embed del PDF: si aggiunge SOTTO al testo, non lo sostituisce.
                            // L'anteprima è subito visibile (nessun pannello da aprire);
                            // il documento viene scaricato solo quando la scheda sta per
                            // entrare nel viewport, così la lista resta leggera.
                            if ( $pdf_id && function_exists( 'ptf_render_pdf_embed' ) ) {
                                ptf_render_pdf_embed( $pdf_id, array(
                                    'titolo'         => 'Programma dell\'attività',
                                    'testo_pulsante' => 'Scarica il programma (PDF)',
                                    'classe'         => 'ptf-pdf-embed--attivita',
                                ) );
                            }
                            ?>
                        </div>
                    </div>

                <?php 
                endwhile;
                wp_reset_postdata();

            else :
                ?>
                <div class="attivita-empty animate-on-scroll">
                    Al momento non sono presenti attività pubblicate.
                </div>
            <?php
            endif;
            ?>
        </div>

    </div>
</main>

<?php
get_footer();
