<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<script>
	// Applica il tema salvato prima del render per evitare il flash bianco
	(function () {
		try {
			var t = localStorage.getItem('ptf-theme') || 'light';
			document.documentElement.setAttribute('data-theme', t);
		} catch (e) {}
	})();
	</script>

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<script>
// GLOBALE: Distrugge i link lightbox attorno alle immagini SOLO nel contenuto principale (NON nella sidebar)
(function() {
    function killImageLinks() {
        // Selettori SOLO per il contenuto, MAI per la sidebar
        var allImages = document.querySelectorAll('.rifugio-main-content img, .entry-content img');
        allImages.forEach(function(img) {
            // Salta immagini nella sidebar
            if (img.closest('.rifugio-sidebar')) return;
            // Salta immagini nelle gallerie (hanno la loro lightbox dedicata)
            if (img.closest('.rifugio-gallery') || img.closest('.wp-block-gallery')) return;
            var parent = img.parentElement;
            if (parent && parent.tagName.toLowerCase() === 'a') {
                var wrapper = document.createElement('span');
                wrapper.innerHTML = parent.innerHTML;
                if (parent.className) wrapper.className = parent.className;
                parent.parentNode.replaceChild(wrapper, parent);
            }
            img.style.pointerEvents = 'none';
            img.style.cursor = 'default';
        });
    }

    document.addEventListener('DOMContentLoaded', function() {
        killImageLinks();
        setTimeout(killImageLinks, 500);
        setTimeout(killImageLinks, 1500);
    });

    // Scudo clic: solo su immagini nel contenuto, NON nella sidebar o nell'header/footer
    document.addEventListener('click', function(e) {
        if (e.target.tagName && e.target.tagName.toLowerCase() === 'img') {
            // Applica lo scudo SOLO alle immagini all'interno dell'articolo/contenuto
            if (!e.target.closest('.rifugio-main-content, .entry-content, .site-main')) return;
            if (e.target.closest('.rifugio-sidebar')) return; // Lascia stare la sidebar
            if (e.target.closest('.rifugio-gallery') || e.target.closest('.wp-block-gallery')) return; // Lascia stare le gallerie
            var parent = e.target.closest('a');
            if (parent && parent.querySelector('img')) {
                e.preventDefault();
                e.stopPropagation();
                e.stopImmediatePropagation();
                return false;
            }
        }
    }, true);
})();
</script>
<div id="page" class="site">
			<!-- IL PESCE VOLANTE -->
			<?php if ( is_front_page() || is_home() ) : ?>
			<style>
				/* FORZA BRUTA ANTI-CACHE */
				.pesce-volante-container {
					z-index: 10 !important;
				}
				.site-header {
					z-index: 999999 !important;
				}
			</style>
			<script>
				document.addEventListener('DOMContentLoaded', function() {
					document.addEventListener('click', function(e) {
						var toggle = e.target.closest('.menu-toggle');
						if (toggle) {
							var fish = document.querySelector('.pesce-volante-container');
							if (fish) {
								if (fish.style.display === 'none') {
									fish.style.display = 'block';
								} else {
									fish.style.display = 'none';
								}
							}
						}
					}, true); // Use capturing phase to bypass any stopPropagation
				});
			</script>
			<div class="pesce-volante-container">
				<img src="https://ticinoweb04.jcloud.ik-server.com/patriziatofrasco/wp-content/uploads/sites/173/2026/06/pesce-volante.png" alt="Pesce Volante" class="pesce-volante">
				<div class="pesce-bubble">Cliccami!</div>
			</div>
			<?php endif; ?>

	<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'patriziatofrasco' ); ?></a>

	<!-- Top Bar -->
	<div class="site-topbar">
		<div class="container topbar-inner">
			<div class="topbar-contact">

				<a href="mailto:patriziatofrasco@bluewin.ch" class="topbar-link">
					<svg class="icon" viewBox="0 0 576 512"><path d="M160 448c-25.6 0-51.2-22.4-64-32-64-44.8-83.2-60.8-96-70.4V480c0 17.67 14.33 32 32 32h256c17.67 0 32-14.33 32-32V345.6c-12.8 9.6-32 25.6-96 70.4-12.8 9.6-38.4 32-64 32zm128-192H32c-17.67 0-32 14.33-32 32v16c25.6 19.2 22.4 19.2 115.2 86.4 9.6 6.4 28.8 25.6 44.8 25.6s35.2-19.2 44.8-22.4c92.8-67.2 89.6-67.2 115.2-86.4V288c0-17.67-14.33-32-32-32zm256-96H224c-17.67 0-32 14.33-32 32v32h96c33.21 0 60.59 25.42 63.71 57.82l.29-.22V416h192c17.67 0 32-14.33 32-32V192c0-17.67-14.33-32-32-32zm-32 128h-64v-64h64v64zm-352-96c0-35.29 28.71-64 64-64h224V32c0-17.67-14.33-32-32-32H96C78.33 0 64 14.33 64 32v192h96v-32z"></path></svg>
					patriziatofrasco@bluewin.ch
				</a>
			</div>
			<button type="button" id="theme-toggle" class="theme-toggle" aria-label="Attiva modalità scura" title="Modalità giorno / notte">
				<span class="theme-toggle-icons">
					<svg class="icon-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="4"></circle><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"></path></svg>
					<svg class="icon-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3a7 7 0 0 0 9.79 9.79z"></path></svg>
				</span>
			</button>
		</div>
	</div>

	<!-- Main Header -->
	<header id="masthead" class="site-header">
		<div class="container header-inner">
			<div class="site-branding">
				<?php
				$site_logo_url = get_option('ticinoweb_site_logo');
				if (empty($site_logo_url)) {
					if (has_custom_logo()) {
						$custom_logo_id = get_theme_mod('custom_logo');
						$site_logo_url = wp_get_attachment_image_url($custom_logo_id, 'full');
					} else {
						$site_logo_url = parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) . '/2026/06/Frasco-coat_of_arms-white-2.png';
					}
				}
				?>
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="custom-logo-link" rel="home">
					<img src="<?php echo esc_url( $site_logo_url ); ?>" alt="Logo Patriziato di Frasco" class="site-logo" style="max-width: 130px; height: auto;">
				</a><?php
				$patriziatofrasco_description = get_bloginfo( 'description', 'display' );
				if ( $patriziatofrasco_description || is_customize_preview() ) :
					?>
						<p class="site-description"><?php echo $patriziatofrasco_description; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
					<?php endif;
				?>
			</div><!-- .site-branding -->


			<nav id="site-navigation" class="main-navigation">
				<button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false">
					<svg class="icon" viewBox="0 0 448 512"><path d="M16 132h416c8.837 0 16-7.163 16-16V76c0-8.837-7.163-16-16-16H16C7.163 60 0 67.163 0 76v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16z"></path></svg>
				</button>
				<?php
				wp_nav_menu(
					array(
						'menu'           => 'menu', // Usa il menu con slug 'menu'
						'theme_location' => 'menu-1',
						'menu_id'        => 'primary-menu',
						'menu_class'     => 'nav-menu',
						'fallback_cb'    => false,
					)
				);
				?>
			</nav><!-- #site-navigation -->
		</div>
	</header><!-- #masthead -->
