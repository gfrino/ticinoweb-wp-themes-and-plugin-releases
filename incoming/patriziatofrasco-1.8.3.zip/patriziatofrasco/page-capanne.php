<?php
/**
 * Template Name: Capanne
 */
get_header();

$hero_img = parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) . '/2026/06/Logo-hd.png'; // Placeholder
?>

<style>
.visual-list-container {
    max-width: 1200px;
    margin: var(--space-xl) auto;
    padding: 0 var(--space-md);
}

.visual-list-intro {
    text-align: center;
    max-width: 800px;
    margin: 0 auto var(--space-xl) auto;
    font-size: 1.15rem;
    line-height: 1.8;
}

.visual-list {
    display: flex;
    flex-direction: column;
    gap: var(--space-lg);
}

.visual-list-item {
    display: flex;
    background: var(--color-bg-pure-white);
    border-radius: var(--radius);
    overflow: hidden;
    box-shadow: 0 4px 15px rgba(0,0,0,0.05);
    border: 1px solid rgba(0,0,0,0.05);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.visual-list-item:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 25px rgba(22,58,138,0.1);
}

.visual-list-img {
    flex: 0 0 350px;
    background: var(--color-bg-body);
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
}

.visual-list-img img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.visual-list-content {
    padding: var(--space-lg);
    display: flex;
    flex-direction: column;
    justify-content: center;
    flex-grow: 1;
}

.visual-list-content h3 {
    color: var(--color-primary-dark);
    margin-top: 0;
    margin-bottom: var(--space-sm);
    font-size: 1.8rem;
}

.visual-list-content p {
    color: var(--color-text-light);
    line-height: 1.7;
    margin-bottom: var(--space-md);
}

.visual-list-action {
    margin-top: auto;
}

.btn-arrow {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: var(--color-primary);
    color: #FFFFFF !important;
    padding: 12px 28px;
    border-radius: var(--radius);
    font-weight: 600;
    text-decoration: none;
    transition: all 0.3s ease;
    box-shadow: 0 8px 20px rgba(14,42,102,0.15);
}

.btn-arrow:hover {
    background: var(--color-primary-light);
    transform: translateY(-3px);
    box-shadow: 0 12px 25px rgba(14,42,102,0.25);
}

@media (max-width: 768px) {
    .visual-list-item {
        flex-direction: column;
    }
    .visual-list-img {
        flex-basis: 250px;
    }
}
</style>

<div class="page-header-cinematic no-bg" style="background-color: var(--color-primary-dark);">
    <div class="page-header-overlay"></div>
    <div class="container page-header-inner animate-on-scroll">
        <h1 class="page-title">Capanne</h1>
        <h2 style="color: var(--color-accent); font-size: 1.5rem; font-weight: 500; font-family: var(--font-heading); margin-top: var(--space-sm);">Ristoro e accoglienza in alta quota.</h2>
    </div>
</div>

<main id="primary" class="site-main">
    <div class="visual-list-container">
        
        <div class="visual-list-intro animate-on-scroll">
            <p>Scopri le nostre capanne e i rifugi alpini che offrono ristoro e accoglienza agli escursionisti. Un punto di riferimento fondamentale per chi esplora le nostre montagne.</p>
        </div>

        <div class="visual-list animate-on-scroll">
            
            <?php
            $capanne_query = new WP_Query([
                'post_type'      => 'capanna',
                'posts_per_page' => -1,
                'post_status'    => 'publish',
                'orderby'        => 'menu_order title',
                'order'          => 'ASC',
            ]);

            if ( $capanne_query->have_posts() ) :
                while ( $capanne_query->have_posts() ) : $capanne_query->the_post();
                    $thumb_url = get_the_post_thumbnail_url( get_the_ID(), 'large' );
                    if ( ! $thumb_url ) {
                        $thumb_url = parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) . '/2026/06/Logo-hd.png';
                    }
            ?>
            <article class="visual-list-item">
                <div class="visual-list-img">
                    <img src="<?php echo esc_url( $thumb_url ); ?>" alt="<?php echo esc_attr( get_the_title() ); ?>">
                </div>
                <div class="visual-list-content">
                    <h3><?php the_title(); ?></h3>
                    <div class="sentiero-excerpt">
                        <p style="color: var(--color-text-light); line-height: 1.7; margin-bottom: var(--space-md);"><?php echo esc_html( ptf_riassunto( get_the_ID(), 30 ) ); ?></p>
                    </div>
                    <div class="visual-list-action">
                        <a href="<?php the_permalink(); ?>" class="btn-arrow">Vedi dettagli</a>
                    </div>
                </div>
            </article>
            <?php
                endwhile;
                wp_reset_postdata();
            else :
            ?>
            <p style="text-align: center; color: var(--color-text-light);">Nessuna capanna pubblicata al momento.</p>
            <?php endif; ?>

        </div>

    </div>
</main>

<?php get_footer(); ?>
