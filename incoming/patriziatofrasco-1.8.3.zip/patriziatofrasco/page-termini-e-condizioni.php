<?php
/**
 * Template Name: Termini e Condizioni
 */
get_header();
?>

<style>
.termini-container {
    max-width: 1400px;
    margin: 0 auto;
    padding: var(--space-xl) var(--space-md);
}
.termini-content-box {
    background: var(--color-bg-pure-white);
    padding: var(--space-xl);
    border-radius: var(--radius);
    box-shadow: 0 10px 30px rgba(0,0,0,0.05);
}
@media (max-width: 768px) {
    .termini-container {
        padding: var(--space-md) var(--space-sm);
    }
    .termini-content-box {
        padding: var(--space-md);
    }
}
</style>

<header class="page-header-cinematic no-bg">
    <div class="page-header-overlay"></div>
    <div class="container page-header-inner animate-on-scroll">
        <h1 class="page-title">Termini e Condizioni d'Uso</h1>
    </div>
</header>

<main id="primary" class="site-main">
    <div class="container termini-container">
        
        <div class="page-content termini-content-box">
            
            <p><strong>Ultimo aggiornamento:</strong> 25 giugno 2026</p>

            <p>Benvenuto sul sito del <strong>Patriziato di Frasco</strong>. L'accesso e l'utilizzo di questo sito comportano l'accettazione dei presenti Termini e Condizioni. Qualora non si accettino tali condizioni, si invita a non utilizzare il sito.</p>

            <h2 style="margin-top: var(--space-lg); color: var(--color-primary-dark); font-size: 1.8rem;">1. Titolare del sito</h2>
            <p>Il sito è gestito dal <strong>Patriziato di Frasco</strong>, con sede a Frasco, Valle Verzasca, Svizzera.</p>
            <p>Per qualsiasi informazione è possibile contattare il Patriziato tramite i recapiti indicati nella pagina "Contatti".</p>

            <h2 style="margin-top: var(--space-lg); color: var(--color-primary-dark); font-size: 1.8rem;">2. Finalità del sito</h2>
            <p>Il sito ha carattere esclusivamente informativo e istituzionale e ha lo scopo di:</p>
            <ul>
                <li>presentare il Patriziato di Frasco;</li>
                <li>informare sulle attività e sulle iniziative organizzate;</li>
                <li>pubblicare comunicazioni ufficiali;</li>
                <li>rendere disponibili regolamenti e documenti pubblici;</li>
                <li>fornire informazioni sul territorio, sui punti di interesse e sulle strutture gestite dal Patriziato;</li>
                <li>presentare eventuali articoli di merchandising.</li>
            </ul>

            <h2 style="margin-top: var(--space-lg); color: var(--color-primary-dark); font-size: 1.8rem;">3. Accuratezza delle informazioni</h2>
            <p>Il Patriziato si impegna a mantenere aggiornate le informazioni pubblicate. Tuttavia, non garantisce che tutti i contenuti siano sempre completi, aggiornati o privi di errori.</p>
            <p>Il Patriziato si riserva il diritto di modificare, aggiornare o rimuovere contenuti in qualsiasi momento e senza preavviso.</p>

            <h2 style="margin-top: var(--space-lg); color: var(--color-primary-dark); font-size: 1.8rem;">4. Documenti pubblicati</h2>
            <p>I documenti presenti sul sito, quali regolamenti, comunicazioni, mozioni, interpellanze o altri atti pubblici, hanno finalità esclusivamente informative.</p>
            <p>In caso di discrepanze tra la versione pubblicata online e il documento ufficiale conservato dal Patriziato, prevale sempre quest'ultimo.</p>

            <h2 style="margin-top: var(--space-lg); color: var(--color-primary-dark); font-size: 1.8rem;">5. Attività ed eventi</h2>
            <p>Le informazioni relative ad attività, manifestazioni, assemblee o altri eventi possono subire modifiche.</p>
            <p>Il Patriziato si riserva il diritto di modificare date, orari, luoghi o programmi, nonché di annullare un evento senza preavviso.</p>

            <h2 style="margin-top: var(--space-lg); color: var(--color-primary-dark); font-size: 1.8rem;">6. Merchandising</h2>
            <p>Qualora il sito presenti prodotti o articoli promozionali del Patriziato, le immagini hanno finalità illustrative e potrebbero non rappresentare perfettamente il prodotto finale.</p>
            <p>La disponibilità degli articoli è soggetta a variazioni.</p>

            <h2 style="margin-top: var(--space-lg); color: var(--color-primary-dark); font-size: 1.8rem;">7. Proprietà intellettuale</h2>
            <p>Tutti i contenuti del sito, inclusi testi, fotografie, immagini, loghi, grafica e documenti, sono di proprietà del Patriziato di Frasco o dei rispettivi titolari dei diritti.</p>
            <p>È vietata la riproduzione, distribuzione, modifica o utilizzo dei contenuti senza preventiva autorizzazione scritta, salvo quanto consentito dalla normativa vigente.</p>

            <h2 style="margin-top: var(--space-lg); color: var(--color-primary-dark); font-size: 1.8rem;">8. Collegamenti a siti esterni</h2>
            <p>Il sito può contenere collegamenti verso siti web di terze parti.</p>
            <p>Il Patriziato non è responsabile dei contenuti, dei servizi o delle politiche adottate dai siti esterni.</p>

            <h2 style="margin-top: var(--space-lg); color: var(--color-primary-dark); font-size: 1.8rem;">9. Limitazione di responsabilità</h2>
            <p>Il Patriziato di Frasco non potrà essere ritenuto responsabile per eventuali danni diretti o indiretti derivanti dall'utilizzo del sito o dall'impossibilità di accedervi.</p>
            <p>L'utilizzo delle informazioni presenti sul sito avviene sotto la responsabilità dell'utente.</p>

            <h2 style="margin-top: var(--space-lg); color: var(--color-primary-dark); font-size: 1.8rem;">10. Protezione dei dati</h2>
            <p>Il trattamento dei dati personali è disciplinato dalla Privacy Policy del sito, consultabile nell'apposita sezione.</p>

            <h2 style="margin-top: var(--space-lg); color: var(--color-primary-dark); font-size: 1.8rem;">11. Modifiche ai Termini e Condizioni</h2>
            <p>Il Patriziato si riserva il diritto di modificare in qualsiasi momento i presenti Termini e Condizioni.</p>
            <p>Le modifiche saranno efficaci dal momento della loro pubblicazione sul sito.</p>

            <h2 style="margin-top: var(--space-lg); color: var(--color-primary-dark); font-size: 1.8rem;">12. Diritto applicabile</h2>
            <p>I presenti Termini e Condizioni sono disciplinati dal diritto svizzero.</p>
            <p>Per eventuali controversie sarà competente il foro previsto dalla legislazione svizzera.</p>

        </div>
    </div>
</main>

<?php get_footer(); ?>
