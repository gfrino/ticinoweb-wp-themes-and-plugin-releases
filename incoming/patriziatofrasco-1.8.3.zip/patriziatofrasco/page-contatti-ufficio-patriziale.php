<?php
/**
 * Template Name: Contatti Ufficio Patriziale
 */
get_header();

$has_thumbnail = has_post_thumbnail();
$thumbnail_url = $has_thumbnail ? get_the_post_thumbnail_url(get_the_ID(), 'full') : '';
$header_class = $has_thumbnail ? 'page-header-cinematic has-bg' : 'page-header-cinematic no-bg';
?>

<style>
.ufficio-catalog {
    max-width: 1200px;
    margin: var(--space-xl) auto;
    padding: 0 var(--space-md);
}

.ufficio-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(380px, 1fr));
    gap: var(--space-lg);
}

@media (max-width: 768px) {
    .ufficio-grid {
        grid-template-columns: 1fr;
    }
}

.member-card {
    background: var(--color-bg-pure-white);
    border-radius: var(--radius);
    padding: var(--space-lg);
    box-shadow: 0 8px 25px rgba(0,0,0,0.08);
    border: 1px solid rgba(0,0,0,0.08);
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    position: relative;
    overflow: hidden;
}

.member-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(14,42,102,0.08);
}

.member-photo {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    object-fit: cover;
    margin-bottom: 20px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    border: 3px solid white;
}

.member-avatar-placeholder {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    background: #f0f4f8;
    color: var(--color-primary);
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 20px;
    border: 3px solid white;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
}

.member-avatar-placeholder svg {
    width: 40px;
    height: 40px;
}

.member-role {
    color: var(--color-accent);
    font-size: 0.9rem;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-bottom: 5px;
}

.member-name {
    color: var(--color-primary-dark);
    font-size: 1.4rem;
    font-family: var(--font-heading);
    margin: 0 0 20px 0;
}

.member-contacts {
    width: 100%;
    display: flex;
    flex-direction: column;
    gap: 10px;
    margin-top: auto;
}

.contact-link {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 12px 16px;
    border-radius: 6px;
    text-decoration: none;
    font-size: 0.9rem;
    font-weight: 500;
    transition: all 0.2s;
    width: 100%;
    box-sizing: border-box;
    text-align: center;
    line-height: 1.35;
    white-space: nowrap;
}

.contact-link.email {
    font-size: clamp(0.7rem, 1.5vw, 0.88rem);
    padding: 12px 10px;
}

.contact-link svg {
    width: 18px;
    height: 18px;
    flex-shrink: 0;
}

.contact-link.email {
    background: rgba(60, 105, 231, 0.05);
    color: var(--color-primary);
}

.contact-link.email:hover {
    background: var(--color-primary);
    color: white;
}

.contact-link.phone {
    background: #f8f9fa;
    color: var(--color-text);
    border: 1px solid #e9ecef;
}

.contact-link.phone:hover {
    background: #e9ecef;
}

.contact-link svg {
    width: 18px;
    height: 18px;
}

/* Cancelleria: contatto principale, in evidenza sopra i membri */
.cancelleria-box {
    max-width: 760px;
    margin: 0 auto var(--space-xl);
    background: var(--color-bg-pure-white);
    border-radius: var(--radius);
    border: 1px solid rgba(0,0,0,0.06);
    border-top: 4px solid var(--color-primary);
    box-shadow: 0 12px 34px rgba(0,0,0,0.07);
    padding: 34px 38px;
    text-align: center;
}
.cancelleria-titolo {
    margin: 0 0 6px;
    font-family: var(--font-heading);
    font-size: 1.6rem;
    color: var(--color-primary);
}
.cancelleria-sottotitolo {
    margin: 0 0 22px;
    color: var(--color-text-light);
    font-size: 0.98rem;
}
.cancelleria-righe {
    display: flex;
    flex-direction: column;
    gap: 14px;
    align-items: center;
}
.cancelleria-riga {
    display: flex;
    align-items: flex-start;
    gap: 12px;
    text-align: left;
    font-size: 1.05rem;
    color: var(--color-text-main);
}
.cancelleria-riga svg {
    width: 22px;
    height: 22px;
    flex: 0 0 auto;
    color: var(--color-primary);
    margin-top: 2px;
}
.cancelleria-riga a {
    color: var(--color-secondary);
    text-decoration: none;
    font-weight: 600;
}
.cancelleria-riga a:hover { text-decoration: underline; }

.ufficio-membri-titolo {
    text-align: center;
    font-family: var(--font-heading);
    font-size: 1.5rem;
    color: var(--color-primary);
    margin: 0 0 var(--space-lg);
}

html[data-theme="dark"] .cancelleria-titolo,
html[data-theme="dark"] .ufficio-membri-titolo { color: #FFFFFF; }
html[data-theme="dark"] .cancelleria-riga a { color: var(--color-accent-text, #9DB8F5); }

@media (max-width: 600px) {
    .cancelleria-box { padding: 26px 20px; }
    .cancelleria-righe { align-items: flex-start; }
}
</style>

<header class="<?php echo esc_attr($header_class); ?>" <?php if ($has_thumbnail) echo 'style="background-image: url(\'' . esc_url($thumbnail_url) . '\');"'; ?>>
    <div class="page-header-overlay"></div>
    <div class="container page-header-inner animate-on-scroll text-center">
        <h1 class="page-title"><?php the_title(); ?></h1>
        <h2 style="color: var(--color-accent); font-size: 1.5rem; font-weight: 500; font-family: var(--font-heading); margin-top: var(--space-sm);">Cancelleria e membri dell'Ufficio Patriziale</h2>
    </div>
</header>

<main id="primary" class="site-main">
    <div class="ufficio-catalog">
        
        <div class="page-content animate-on-scroll" style="text-align: center; margin-bottom: var(--space-xl); max-width: 800px; margin-left: auto; margin-right: auto; color: var(--color-text-main); font-size: 1.1rem;">
            <?php
            while ( have_posts() ) :
                the_post();
                the_content();
            endwhile;
            ?>
        </div>

        <?php
        // Contatto principale: la cancelleria. Va prima dei singoli membri.
        $ptf_tel   = get_option( 'ticinoweb_contact_phone', '+41 79 570 66 36' );
        $ptf_mail  = get_option( 'ticinoweb_contact_email', 'patriziatofrasco@bluewin.ch' );
        $ptf_indir = get_option( 'ticinoweb_contact_address', "Casella Postale 11\n6636 Frasco" );
        ?>
        <div class="cancelleria-box animate-on-scroll">
            <h2 class="cancelleria-titolo">Cancelleria patriziale</h2>
            <p class="cancelleria-sottotitolo">Per ogni richiesta il riferimento principale &egrave; la cancelleria.</p>

            <div class="cancelleria-righe">
                <div class="cancelleria-riga">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                    <span><?php echo nl2br( esc_html( $ptf_indir ) ); ?></span>
                </div>
                <div class="cancelleria-riga">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                    <a href="mailto:<?php echo esc_attr( $ptf_mail ); ?>"><?php echo esc_html( $ptf_mail ); ?></a>
                </div>
                <div class="cancelleria-riga">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
                    <a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $ptf_tel ) ); ?>"><?php echo esc_html( $ptf_tel ); ?></a>
                </div>
            </div>
        </div>

        <h2 class="ufficio-membri-titolo animate-on-scroll">I membri dell'Ufficio patriziale</h2>

        <div class="ufficio-grid animate-on-scroll">
            <?php
            $args = array(
                'post_type'      => 'ufficio',
                'posts_per_page' => -1,
                'orderby'        => array(
                    'menu_order' => 'ASC',
                    'date'       => 'DESC'
                )
            );
            $ufficio_query = new WP_Query( $args );

            if ( $ufficio_query->have_posts() ) :
                while ( $ufficio_query->have_posts() ) : $ufficio_query->the_post();
                    
                    $ruolo = get_post_meta( get_the_ID(), '_ufficio_ruolo', true );
                    $email = get_post_meta( get_the_ID(), '_ufficio_email', true );
                    $telefono = get_post_meta( get_the_ID(), '_ufficio_telefono', true );
                    $has_photo = has_post_thumbnail();
                    ?>
                    
                    <div class="member-card">
                        <?php if ($has_photo) : ?>
                            <img src="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'thumbnail'); ?>" alt="<?php the_title_attribute(); ?>" class="member-photo">
                        <?php else : ?>
                            <div class="member-avatar-placeholder">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                </svg>
                            </div>
                        <?php endif; ?>

                        <?php if (!empty($ruolo)) : ?>
                            <div class="member-role"><?php echo esc_html($ruolo); ?></div>
                        <?php endif; ?>
                        
                        <h3 class="member-name"><?php the_title(); ?></h3>
                        
                        <div class="member-contacts">
                            <?php if (!empty($email)) : ?>
                                <a href="mailto:<?php echo esc_attr($email); ?>" class="contact-link email">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                                    </svg>
                                    <?php echo esc_html($email); ?>
                                </a>
                            <?php endif; ?>

                            <?php if (!empty($telefono)) : ?>
                                <a href="tel:<?php echo esc_attr(str_replace(' ', '', $telefono)); ?>" class="contact-link phone">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                                    </svg>
                                    <?php echo esc_html($telefono); ?>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>

                <?php endwhile; wp_reset_postdata(); ?>
            <?php else : ?>
                <div style="grid-column: 1 / -1; text-align: center; padding: var(--space-xxl); background: var(--color-bg-pure-white); border-radius: var(--radius); border: 1px solid rgba(0,0,0,0.05);">
                    <p style="color: var(--color-primary-light); font-size: 1.2rem; margin: 0;">Nessun membro dell'Ufficio Patriziale inserito al momento.</p>
                </div>
            <?php endif; ?>
        </div>

    </div>
</main>

<?php get_footer(); ?>
