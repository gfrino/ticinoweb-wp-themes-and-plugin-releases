<?php
/**
 * The front page template file
 *
 * @package Patriziato Frasco
 */

get_header();
?>

<style>
	/* Riquadro didascalia (Luogo, Data) appoggiato sulla foto storica */
	.section-patriziato .editorial-image {
		position: relative;
	}

	.section-patriziato .ptf-caption-badge {
		position: absolute;
		bottom: -20px;
		right: -20px;
		max-width: calc(100% - 20px);
		background: var(--color-bg-pure-white);
		padding: 15px 25px;
		font-family: var(--font-heading);
		font-style: italic;
		font-size: 1.05rem;
		line-height: 1.3;
		color: var(--color-secondary);
		box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12);
	}

	/* Scuro: riquadro scuro con testo chiaro, mai testo blu su fondo grigio.
	   Il bordo serve a staccarlo dallo sfondo della sezione, che in scuro ha
	   lo stesso colore del riquadro. */
	html[data-theme="dark"] .section-patriziato .ptf-caption-badge {
		background: var(--color-bg-pure-white);
		color: var(--color-text-main);
		border: 1px solid rgba(255, 255, 255, 0.12);
		box-shadow: 0 10px 30px rgba(0, 0, 0, 0.45);
	}

	@media (max-width: 768px) {
		.section-patriziato .ptf-caption-badge {
			bottom: -14px;
			right: 0;
			padding: 12px 20px;
			font-size: 0.95rem;
		}
	}
</style>

<main id="primary" class="site-main">

	<?php
	while ( have_posts() ) :
		the_post();
		
		// Get the content and strip out all Elementor layout divs to prevent HTML corruption
		$content = get_the_content();
		
		// Fix hardcoded localhost URLs from old DB migrations
		$content = str_replace('http://localhost/patriziatofrasco', site_url(), $content);
		
		$content = strip_tags($content, '<h1><h2><h3><h4><h5><h6><p><a><ul><ol><li><br><strong><em><b><i><img>');
		
		// Clean up links: Elementor often leaves newlines inside <a> tags, which wpautop turns into <br> tags, breaking button alignment
		$content = preg_replace_callback('/<a([^>]*)>(.*?)<\/a>/is', function($matches) {
			$href_attrs = $matches[1];
			$button_text = trim(strip_tags($matches[2]));
			
			// Fix the broken "Scopri la galleria" link from the DB
			if (strtolower($button_text) === 'scopri la galleria' && strpos($href_attrs, 'href="#"') !== false) {
				$href_attrs = str_replace('href="#"', 'href="' . esc_url(home_url('/galleria/')) . '"', $href_attrs);
			}
			
			// Cambia "Riserva ora" in "Prenota ora"
			if (stripos($button_text, 'riserva ora') !== false) {
				$button_text = preg_replace('/riserva ora!?/i', 'Prenota ora', $button_text);
			}
			
			return '<a' . $href_attrs . '>' . $button_text . '</a>';
		}, $content);
		
		// Extract ALL images from Gutenberg galleries anywhere in the content
		preg_match_all('/<!-- wp:gallery.*?-->.*?<!-- \/wp:gallery -->/is', $content, $gallery_blocks);
		$global_gallery_images = array();
		
		if (!empty($gallery_blocks[0])) {
			foreach ($gallery_blocks[0] as $block) {
				preg_match_all('/<img[^>]+src="([^">]+)"/i', $block, $img_matches);
				if (!empty($img_matches[1])) {
					$global_gallery_images = array_merge($global_gallery_images, $img_matches[1]);
				}
			}
			// Remove gallery blocks from the full content so they don't show up in the text
			$content = preg_replace('/<!-- wp:gallery.*?-->.*?<!-- \/wp:gallery -->/is', '', $content);
		}
		
		// Split content by h2 to create distinct sections
		$sections = preg_split('/(?=<h2)/i', $content);
		
		// The first section is usually the Hero (h1 + img)
		$hero_content = array_shift($sections);
		
		// Parse sections dynamically into variables
		$chi_siamo = array('title' => '', 'text' => '', 'link' => '', 'image' => '');
		$missione = array('title' => '', 'text' => '', 'link' => '', 'image_url' => '');
		$famiglie = array('title' => '', 'text' => '', 'link' => '', 'image_url' => '');
		$rifugio = array('title' => '', 'text' => '', 'link' => '', 'image_url' => '');
		$comunicati = array('title' => '', 'link' => '');

		$historical_img_url = '';

		// Extract images from hero content (e.g. frasco_up-768x461-1.jpg)
		preg_match('/<img[^>]+src="([^">]+)"[^>]*>/i', $hero_content, $hero_img_src);
		preg_match('/<img[^>]+>/i', $hero_content, $hero_img_tag);

		$hero_title = '';
		if (preg_match('/<h1[^>]*>(.*?)<\/h1>/is', $hero_content, $h1_matches)) {
			$hero_title = trim($h1_matches[1]);
		}

		$hero_link = '';
		if (preg_match('/<a[^>]*>.*?<\/a>/is', $hero_content, $link_matches)) {
			$hero_link = $link_matches[0];
		}

		foreach ($sections as $section_content) {
			$title = '';
			if (preg_match('/<h2[^>]*>(.*?)<\/h2>/is', $section_content, $h2_matches)) {
				$title = trim(strip_tags($h2_matches[1]));
			}
			
			if (empty($title)) continue;
			
			if (stripos($title, 'Chi siamo') !== false) {
				$text = preg_replace('/<h2[^>]*>.*?<\/h2>/is', '', $section_content);
				$text = preg_replace('/<a[^>]*>.*?<\/a>/is', '', $text);
				$text = preg_replace('/<img[^>]+>/i', '', $text);
				preg_match('/<a[^>]*>.*?<\/a>/is', $section_content, $l_matches);
				
				$chi_siamo['title'] = $title;
				$chi_siamo['text'] = wpautop(trim($text));
				$chi_siamo['link'] = !empty($l_matches) ? $l_matches[0] : '';
				$chi_siamo['image'] = !empty($hero_img_tag) ? $hero_img_tag[0] : '';
			}
			elseif (stripos($title, 'missione') !== false) {
				$text = preg_replace('/<h2[^>]*>.*?<\/h2>/is', '', $section_content);
				$text = preg_replace('/<a[^>]*>.*?<\/a>/is', '', $text);
				
				preg_match('/<a[^>]*>.*?<\/a>/is', $section_content, $l_matches);
				preg_match_all('/<img[^>]+>/i', $section_content, $img_matches);
				$images = !empty($img_matches[0]) ? $img_matches[0] : array();
				
				$text = preg_replace('/<img[^>]+>/i', '', $text);
				
				$missione_img = !empty($images) ? $images[0] : '';
				preg_match('/src="([^">]+)"/i', $missione_img, $src_matches);
				$missione_img_url = !empty($src_matches[1]) ? $src_matches[1] : '';
				
				if (count($images) > 1) {
					$historical_img = $images[1];
					preg_match('/src="([^">]+)"/i', $historical_img, $src_matches_hist);
					$historical_img_url = !empty($src_matches_hist[1]) ? $src_matches_hist[1] : '';
				}
				
				$missione['title'] = $title;
				$missione['text'] = wpautop(trim($text));
				$missione['link'] = !empty($l_matches) ? $l_matches[0] : '';
				$missione['image_url'] = $missione_img_url;
			}
			elseif (stripos($title, 'Famiglie') !== false) {
				$text = preg_replace('/<h2[^>]*>.*?<\/h2>/is', '', $section_content);
				$text = preg_replace('/<a[^>]*>.*?<\/a>/is', '', $text);
				$text = preg_replace('/<img[^>]+>/i', '', $text);
				preg_match('/<a[^>]*>.*?<\/a>/is', $section_content, $l_matches);
				
				$famiglie['title'] = $title;
				$famiglie['text'] = wpautop(trim($text));
				$famiglie['link'] = !empty($l_matches) ? $l_matches[0] : '';
			}
			elseif (stripos($title, 'Rifugio') !== false) {
				$text = preg_replace('/<h2[^>]*>.*?<\/h2>/is', '', $section_content);
				$text = preg_replace('/<a[^>]*>.*?<\/a>/is', '', $text);
				
				preg_match('/<a[^>]*>.*?<\/a>/is', $section_content, $l_matches);
				preg_match('/<img[^>]+>/i', $section_content, $img_matches);
				$rifugio_img = !empty($img_matches[0]) ? $img_matches[0] : '';
				preg_match('/src="([^">]+)"/i', $rifugio_img, $src_matches);
				$rifugio_img_url = !empty($src_matches[1]) ? $src_matches[1] : '';
				
				$text = preg_replace('/<img[^>]+>/i', '', $text);
				
				$rifugio['title'] = $title;
				$rifugio['text'] = wpautop(trim($text));
				$rifugio['link'] = !empty($l_matches) ? $l_matches[0] : '';
				$rifugio['image_url'] = $rifugio_img_url;
			}
			elseif (stripos($title, 'Comunicati') !== false) {
				preg_match('/<a[^>]*>.*?<\/a>/is', $section_content, $l_matches);
				
				$comunicati['title'] = $title;
				$comunicati['link'] = !empty($l_matches) ? $l_matches[0] : '';
			}
		}

		// Assign historical image to famiglie
		$famiglie['image_url'] = $historical_img_url;
		?>
		
		<!-- 1. HERO SECTION -->
		<section class="hero-section">
			<?php 
			// Load the slider images explicitly configured by the user in settings
			$hero_images = array();
			for ( $i = 1; $i <= 5; $i++ ) {
				$img_url = get_option( 'ticinoweb_slider_image_' . $i );
				if ( ! empty( $img_url ) ) {
					$hero_images[] = $img_url;
				}
			}
			
			// Fallback to the extracted inline hero image
			if (empty($hero_images) && !empty($hero_img_src)) {
				$hero_images[] = $hero_img_src[1];
			}
			
			// Output the slider backgrounds
			if (!empty($hero_images)) {
				echo '<div class="hero-slider">';
				foreach($hero_images as $index => $img_url) {
					$active_class = $index === 0 ? 'active' : '';
					echo '<div class="hero-slide ' . $active_class . '" style="background-image: url(\'' . esc_url($img_url) . '\');"></div>';
				}
				echo '</div>';
			}
			?>
			
			<div class="hero-bg-overlay"></div>
			
			<div class="container hero-inner">
				<div class="hero-text-content">
					<?php if (!empty($hero_title)) : ?>
						<h1><?php echo wp_kses_post(str_replace(array('<br>', '<br/>', '<br />'), ' ', $hero_title)); ?></h1>
					<?php endif; ?>
					
					<?php if (!empty($hero_link)) : ?>
						<div class="hero-cta-wrapper">
							<?php echo wp_kses_post($hero_link); ?>
						</div>
					<?php endif; ?>
				</div>
			</div>
			
			<!-- Cinematic Scroll Cue -->
			<div class="scroll-cue" style="cursor: pointer;" onclick="document.querySelector('.section-patriziato').scrollIntoView({ behavior: 'smooth' });">
				<span class="scroll-line"></span>
			</div>
		</section>
		
		<script>
		document.addEventListener('DOMContentLoaded', function() {
			const slides = document.querySelectorAll('.hero-slide');
			if (slides.length > 1) {
				let currentSlide = 0;
				setInterval(() => {
					slides[currentSlide].classList.remove('active');
					currentSlide = (currentSlide + 1) % slides.length;
					slides[currentSlide].classList.add('active');
				}, 4000);
			}
		});
		</script>

		
		<!-- 2. PATRIZIATO -->
		<section class="section-patriziato animate-on-scroll" style="padding: 120px 0; background-color: var(--color-bg-pure-white);">
			<div class="container">
				<div class="editorial-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: var(--space-xl); align-items: center;">
					<div class="editorial-text">
						<h2 style="font-family: var(--font-heading); color: var(--color-primary-dark); font-size: 2.5rem; margin-bottom: var(--space-md);">Patriziato</h2>
						<p style="font-size: 1.15rem; line-height: 1.8; color: var(--color-text-main); margin-bottom: 1rem;">
							Il Patriziato di Frasco è un’antica collettività radicata nella storia della Valle Verzasca, erede delle antiche Vicinanze che per secoli hanno gestito le risorse comuni e strutturato la vita comunitaria. Oggi il patriziato rappresenta una realtà viva, composta da membri legati da attinenza al territorio e impegnati nella tutela del paesaggio, delle tradizioni e del patrimonio culturale locale.
						</p>
						<p style="font-size: 1.15rem; line-height: 1.8; color: var(--color-text-main); margin-bottom: 1rem;">
							Le famiglie patrizie – tra cui Badasci, Bernardasci, Giottonini, Ferrini, Lanini, Marci, Martella e altre – rappresentano le radici storiche della comunità, oggi distribuite tra Frasco e l’estero a causa della forte emigrazione del passato. Il Patriziato conta oltre 400 membri registrati.
						</p>
						<p style="font-size: 1.15rem; line-height: 1.8; color: var(--color-text-main);">
							Attraverso iniziative culturali, la cura del territorio, la gestione dei sentieri e dei rifugi alpini (come il Rifugio Alpe Costa), il Patriziato continua a svolgere un ruolo centrale nella vita della comunità, custodendo le tradizioni e garantendo la trasmissione del patrimonio collettivo alle generazioni future.
						</p>
						<div style="margin-top: var(--space-lg);">
							<a href="<?php echo esc_url( home_url( '/chi-siamo/' ) ); ?>" class="btn-primary">Chi siamo</a>
						</div>
					</div>
					<div class="editorial-image">
						<img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/Frasco-1969.jpg" alt="Frasco 1969" loading="lazy" decoding="async" style="border-radius: var(--radius); width: 100%;">
							<?php
							// Didascalia della foto storica. Se l'immagine è presente in Libreria
							// Media usiamo i campi Luogo/Data (così il cliente può modificarla da lì),
							// altrimenti ricadiamo sul testo storico "Frasco, 1969".
							$frasco_caption   = '';
							$frasco_media_url = trailingslashit( wp_upload_dir()['baseurl'] ) . '2026/06/Frasco-1969.jpg';

							if ( function_exists( 'ptf_media_caption' ) ) {
								$frasco_attachment_id = attachment_url_to_postid( $frasco_media_url );

								if ( $frasco_attachment_id ) {
									$frasco_caption = ptf_media_caption( $frasco_attachment_id );
								}
							}

							if ( '' === $frasco_caption ) {
								$frasco_caption = 'Frasco, 1969';
							}

							if ( function_exists( 'ptf_media_caption_badge' ) ) {
								ptf_media_caption_badge( $frasco_caption );
							} else {
								echo '<div class="ptf-caption-badge">' . esc_html( $frasco_caption ) . '</div>';
							}
							?>
					</div>
				</div>
			</div>
		</section>

		<!-- 3. TERRITORIO -->
		<section class="section-territorio animate-on-scroll" style="padding: 120px 0; background-color: var(--color-bg-pure-white);">
			<div class="container">
				<div class="editorial-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: var(--space-xl); align-items: center;">
					<div class="editorial-image">
						<figure style="margin: 0;">
							<img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/08/Frasco_cartina.jpg" alt="Il territorio dell&rsquo;ex-comune di Frasco nella Valle Verzasca" loading="lazy" decoding="async" style="border-radius: var(--radius); box-shadow: 0 15px 30px rgba(0,0,0,0.10); border: 1px solid rgba(0,0,0,0.06); background: #FFFFFF; width: 100%;">
							<figcaption style="margin-top: 8px; font-size: 0.78rem; color: var(--color-text-light); opacity: 0.75; text-align: right;">
								Fonte: <a href="https://www.verzasca.swiss/" target="_blank" rel="noopener" style="color: inherit; text-decoration: underline;">Comune di Verzasca</a>
							</figcaption>
						</figure>
					</div>
					<div class="editorial-text">
						<h2 style="font-family: var(--font-heading); color: var(--color-primary-dark); font-size: 2.5rem; margin-bottom: var(--space-md);">Territorio</h2>
						<p style="font-size: 1.15rem; line-height: 1.8; color: var(--color-text-main); margin-bottom: 1rem;">
							Frasco, penultimo paese della Val Verzasca, si trova a 876 metri di altitudine, ed ha una superficie complessiva di circa 26 km quadrati.
						</p>
						<p style="font-size: 1.15rem; line-height: 1.8; color: var(--color-text-main); margin-bottom: 1rem;">
							I boschi ricoprono oltre il 40% del territorio, mentre il 47% è composto da terreni montuosi, in gran parte improduttivi.
						</p>
						<p style="font-size: 1.15rem; line-height: 1.8; color: var(--color-text-main); margin-bottom: 1rem;">
							La zona abitata, circa l’1% della superficie, si suddivide tra diversi nuclei storici (Torbora, Cantòm, Pé, Scima er Mota,), ciascuno un tempo dotato di proprie strutture comunitarie come forni e fontane.
						</p>
						<p style="font-size: 1.15rem; line-height: 1.8; color: var(--color-text-main);">
							Diversi anche i nuclei prevalentemente stagionali, abitati durante il trasferimento del bestiame tra i pascoli inferiori e gli alpeggi superiori. Tra questi Cabioi, Vald, Mondada, Alpe Efra, Corte di Cima, e altri.
						</p>
						<div style="margin-top: var(--space-lg);">
							<a href="<?php echo esc_url( home_url( '/sentieri/' ) ); ?>" class="btn-primary">Sentieri</a>
						</div>
					</div>
				</div>
			</div>
		</section>

		<!-- 4. PUNTI DI INTERESSE -->
		<section class="section-punti animate-on-scroll" style="padding: 120px 0; background-color: var(--color-bg-pure-white);">
			<div class="container">
				<div class="editorial-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: var(--space-xl); align-items: center;">
					<div class="editorial-text">
						<h2 style="font-family: var(--font-heading); color: var(--color-primary-dark); font-size: 2.5rem; margin-bottom: var(--space-md);">Punti di interesse</h2>
						<p style="font-size: 1.15rem; line-height: 1.8; color: var(--color-text-main); margin-bottom: 1rem;">
							Oltre alle diverse possibilità di escursioni, Frasco offre diversi punti di interesse storico.
						</p>
						<p style="font-size: 1.15rem; line-height: 1.8; color: var(--color-text-main); margin-bottom: 1rem;">
							Tra questi spicca il Mulino di Frasco, uno degli edifici più significativi dell'alta Valle Verzasca, alimentato dall'acqua del riale Efra. Accanto al mulino si trova anche la centralina idraulica realizzata nel 1925 che forniva luce elettrica agli abitanti di Frasco e Sonogno fino agli anni '50.
						</p>
						<p style="font-size: 1.15rem; line-height: 1.8; color: var(--color-text-main); margin-bottom: 1rem;">
							Da Frasco parte anche il percorso etnografico "Acqua e Fuoco", un itinerario che racconta la vita contadina attraverso antichi forni, mulini e luoghi legati all'uso delle risorse naturali del territorio.
						</p>
						<p style="font-size: 1.15rem; line-height: 1.8; color: var(--color-text-main);">
							Per le famiglie, uno dei punti più amati dell'intera valle è BoBosco – Boccia al Bosco, un grande percorso di biglie nel bosco che unisce gioco e scoperta della natura.
						</p>
						<div style="margin-top: var(--space-lg);">
							<a href="<?php echo esc_url( home_url( '/punti-di-interesse/' ) ); ?>" class="btn-primary">Punti di interesse</a>
						</div>
					</div>
					<div class="editorial-image">
						<img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/ChatGPT-Image-25-giu-2026-15_41_34.png" alt="Punti di Interesse" loading="lazy" decoding="async" style="border-radius: var(--radius); box-shadow: 0 15px 30px rgba(0,0,0,0.15); width: 100%;">
					</div>
				</div>
			</div>
		</section>

		<!-- 5. RIFUGIO ALPE COSTA -->
		<?php if (!empty($rifugio['title'])) : ?>
			<section class="section-rifugio animate-on-scroll">
				<div class="container">
					<div class="rifugio-scenic-image" style="background-image: url('<?php echo esc_url($rifugio['image_url']); ?>'); border-radius: var(--radius); overflow: hidden;">
						<div class="rifugio-overlay"></div>
						<div class="rifugio-card">
							<span class="rifugio-tag">DESTINAZIONE</span>
							<h2 class="rifugio-title"><?php echo esc_html($rifugio['title']); ?></h2>
							<div class="rifugio-text">
								<?php echo wp_kses_post($rifugio['text']); ?>
							</div>
							<?php if (!empty($rifugio['link'])): ?>
								<div class="rifugio-cta"><?php echo wp_kses_post($rifugio['link']); ?></div>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</section>
		<?php endif; ?>

		<!-- 6. ULTIMI COMUNICATI -->
		<?php if (!empty($comunicati['title'])) : ?>
			<section class="section-comunicati animate-on-scroll">
				<div class="container-comunicati">
					<span class="comunicati-badge">INFORMAZIONI</span>
					<h2 class="comunicati-title"><?php echo esc_html($comunicati['title']); ?></h2>
					
					<?php
					// Query ultimi 2 comunicati dal Custom Post Type "comunicato"
					$recent_query = new WP_Query(array(
						'post_type' => 'comunicato',
						'posts_per_page' => 2,
						'post_status' => 'publish',
						'orderby' => 'date',
						'order' => 'DESC'
					));
					
					if ($recent_query->have_posts()) :
						echo '<div class="comunicati-grid">';
						while ($recent_query->have_posts()) : $recent_query->the_post();
							?>
							<article id="post-<?php the_ID(); ?>" <?php post_class('comunicato-card comunicato-card-horizontal'); ?>>
								<a href="<?php the_permalink(); ?>" class="comunicato-card-link">
									
									<div class="comunicato-card-image">
										<?php 
										if ( has_post_thumbnail() ) {
											the_post_thumbnail( 'large' );
										} else {
											echo '<div class="comunicato-no-image"><span class="dashicons dashicons-megaphone"></span></div>';
										}
										?>
									</div>

									<div class="comunicato-card-content">
										<div class="comunicato-card-date"><?php echo get_the_date(); ?></div>
										<h2 class="comunicato-card-title"><?php the_title(); ?></h2>
										<div class="comunicato-card-excerpt">
											<?php echo wp_trim_words( get_the_excerpt(), 20, '...' ); ?>
										</div>
										<div class="comunicato-card-readmore">Leggi tutto &rarr;</div>
									</div>
								</a>
							</article>
							<?php
						endwhile;
						wp_reset_postdata();
						echo '</div>';
					else:
						// Mostra un messaggio elegante se non ci sono comunicazioni
						?>
						<div class="comunicati-grid">
							<article class="comunicato-card" style="text-align: center; justify-content: center; width: 100%;">
								<p style="color: var(--color-text-main); font-style: italic; margin: 0;">Attualmente non ci sono nuove comunicazioni disponibili.</p>
							</article>
						</div>
						<?php
					endif;
					?>
					
					<div class="comunicati-cta" style="margin-top: 15px; text-align: center;">
						<a href="<?php echo esc_url( home_url( '/comunicati/' ) ); ?>" class="btn-primary" style="display: inline-block;">Vedi tutte le comunicazioni</a>
					</div>
				</div>
			</section>
		<?php endif; ?>

	<?php
	endwhile;
	?>

</main><!-- #main -->

<?php
get_footer();
