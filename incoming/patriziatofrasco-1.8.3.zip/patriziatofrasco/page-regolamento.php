<?php
/**
 * Template Name: Visualizzatore Regolamento PDF
 */

get_header(); ?>

<main id="primary" class="site-main page-content" style="padding-bottom: var(--space-xxl);">
	
	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
		<?php 
		$has_thumbnail = has_post_thumbnail();
		$thumbnail_url = $has_thumbnail ? get_the_post_thumbnail_url(get_the_ID(), 'full') : '';
		$header_class = $has_thumbnail ? 'page-header-cinematic has-bg' : 'page-header-cinematic no-bg';
		?>
		<header class="<?php echo esc_attr($header_class); ?>" <?php if ($has_thumbnail) echo 'style="background-image: url(\'' . esc_url($thumbnail_url) . '\');"'; ?>>
			<div class="page-header-overlay"></div>
			<div class="container page-header-inner animate-on-scroll">
				<h1 class="page-title"><?php the_title(); ?></h1>
				<h2 style="color: var(--color-accent); font-size: 1.5rem; font-weight: 500; font-family: var(--font-heading); margin-top: var(--space-sm);">Consulta il testo ufficiale del nostro statuto.</h2>
			</div>
		</header>
	<?php endwhile; endif; ?>

	<div class="container" style="margin-top: var(--space-xl); padding-bottom: var(--space-xxl);">
		<div class="pdf-wrapper" style="background: var(--color-bg-pure-white); padding: 15px; border-radius: var(--radius); box-shadow: 0 25px 50px rgba(14,42,102,0.1);">
			<!-- Usiamo l'URL esatto del PDF trovato nel database -->
			<iframe src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2023/12/regolamento_frasco.pdf" width="100%" height="900" style="border: none; border-radius: calc(var(--radius) - 5px); display: block;">
				Questo browser non supporta la visualizzazione dei PDF integrati.
			</iframe>
		</div>
		<div style="text-align: center; margin-top: var(--space-xl);">
			<a href="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2023/12/regolamento_frasco.pdf" download class="elementor-button" style="background: var(--color-primary); color: white; padding: 15px 35px; border-radius: var(--radius); text-decoration: none; font-weight: 700; font-size: 1.1rem; display: inline-flex; align-items: center; gap: 10px; transition: all 0.3s ease; box-shadow: 0 10px 20px rgba(14,42,102,0.2);">
				<span class="dashicons dashicons-download" style="font-size: 1.4rem; height: auto; width: auto;"></span>
				Scarica il PDF
			</a>
		</div>
	</div>
</main>

<style>
/* Effetto hover sul bottone di download */
.elementor-button:hover {
	background: var(--color-primary-light) !important;
	transform: translateY(-3px);
	box-shadow: 0 15px 30px rgba(14,42,102,0.3) !important;
}
</style>

<?php get_footer();
