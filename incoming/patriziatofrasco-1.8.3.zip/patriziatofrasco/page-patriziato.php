<?php
/**
 * Template Name: Pagina Patriziato
 * The template for displaying the Patriziato page.
 *
 * @package patriziatofrasco
 */

get_header();
?>

<main id="primary" class="site-main">

	<?php
	while ( have_posts() ) :
		the_post();
		
		$has_thumbnail = has_post_thumbnail();
		$thumbnail_url = $has_thumbnail ? get_the_post_thumbnail_url(get_the_ID(), 'full') : '';
		$header_class = $has_thumbnail ? 'page-header-cinematic has-bg' : 'page-header-cinematic no-bg';
		?>
		<header class="<?php echo esc_attr($header_class); ?>" <?php if ($has_thumbnail) echo 'style="background-image: url(\'' . esc_url($thumbnail_url) . '\');"'; ?>>
			<div class="page-header-overlay"></div>
			<div class="container page-header-inner animate-on-scroll">
				<?php the_title( '<h1 class="page-title">', '</h1>' ); ?>
			</div>
		</header>

        <div class="container" style="padding: 80px 0 120px 0;">
            <div class="page-content custom-gutenberg-layout">
                <?php the_content(); ?>
            </div>
        </div>

	<?php endwhile; // End of the loop. ?>

</main><!-- #main -->

<?php
get_footer();
