<?php
/**
 * Template Name: Famiglie Patrizie
 */

get_header(); ?>

<style>
.famiglie-container {
    max-width: 1000px;
    margin: 0 auto;
    padding: 60px var(--space-md) 100px var(--space-md);
}

.famiglie-content {
    font-size: 1.15rem;
    line-height: 1.8;
    color: var(--color-text-main);
}

.famiglie-content .lead-text {
    font-size: 1.25rem;
    font-weight: 500;
    line-height: 1.8;
    color: var(--color-primary-dark);
    margin-bottom: var(--space-md);
}

.famiglie-content p {
    margin-bottom: var(--space-md);
}

.image-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
    margin: 15px 0 35px 0;
    align-items: start;
}

.image-grid p {
    display: contents;
}

.image-grid img {
    width: 100%;
    height: auto;
    display: block;
    border-radius: var(--radius);
    box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
}

.cognomi-section {
    margin-top: var(--space-xxl);
    border-top: 2px solid rgba(0,0,0,0.05);
    padding-top: var(--space-xl);
}

.cognomi-section h3 {
    font-family: var(--font-heading);
    color: var(--color-secondary);
    font-size: 2rem;
    margin-bottom: var(--space-lg);
}

.famiglie-ul {
    column-count: 3;
    column-gap: var(--space-xxl);
    list-style: none;
    padding: 0;
    margin: 0;
}

.famiglie-ul li {
    font-size: 1.3rem;
    margin-bottom: var(--space-md);
    padding-bottom: var(--space-sm);
    border-bottom: 1px solid rgba(14,42,102,0.08);
    color: var(--color-primary-dark);
    font-weight: 500;
    display: flex;
    align-items: center;
}

.famiglie-ul li::before {
    content: "•";
    color: var(--color-accent);
    font-weight: bold;
    margin-right: 15px;
    font-size: 1.5rem;
}

@media (max-width: 992px) {
    .image-grid {
        grid-template-columns: 1fr;
    }
    .famiglie-ul {
        column-count: 2;
    }
}

@media (max-width: 576px) {
    .famiglie-ul {
        column-count: 1;
    }
}
</style>

<main id="primary" class="site-main page-content" style="padding-bottom: 0;">
	
	<?php while ( have_posts() ) : the_post(); ?>
		<?php 
		$has_thumbnail = has_post_thumbnail();
		$thumbnail_url = $has_thumbnail ? get_the_post_thumbnail_url(get_the_ID(), 'full') : '';
		$header_class = $has_thumbnail ? 'page-header-cinematic has-bg' : 'page-header-cinematic no-bg';
		?>
		<header class="<?php echo esc_attr($header_class); ?>" <?php if ($has_thumbnail) echo 'style="background-image: url(\'' . esc_url($thumbnail_url) . '\');"'; ?>>
			<div class="page-header-overlay"></div>
			<div class="container page-header-inner animate-on-scroll">
				<h1 class="page-title"><?php the_title(); ?></h1>
				<h2 style="color: var(--color-accent); font-size: 1.5rem; font-weight: 500; font-family: var(--font-heading); margin-top: var(--space-sm);">Le radici della nostra comunità.</h2>
			</div>
		</header>

        <div class="famiglie-container animate-on-scroll">
            <div class="famiglie-content custom-gutenberg-layout">
                <?php the_content(); ?>
            </div>
        </div>
	<?php endwhile; ?>

</main>

<?php get_footer(); ?>
