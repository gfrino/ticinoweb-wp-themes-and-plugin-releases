<?php
/**
 * Opzioni del tema Patriziato Frasco
 *
 * Pagina di impostazioni nel backend (Settings API) con le opzioni
 * di visibilità dei contenuti gestiti dal tema.
 *
 * @package Patriziato Frasco
 */

// Blocca l'accesso diretto al file
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Slug della pagina di impostazioni e del gruppo di opzioni
 */
if ( ! defined( 'PTF_OPTIONS_PAGE_SLUG' ) ) {
    define( 'PTF_OPTIONS_PAGE_SLUG', 'ptf-opzioni-tema' );
}
if ( ! defined( 'PTF_OPTIONS_GROUP' ) ) {
    define( 'PTF_OPTIONS_GROUP', 'ptf_theme_options_group' );
}

/**
 * ==========================================================================
 * 1. HELPER
 * ==========================================================================
 */

/**
 * Restituisce l'ID della pagina "Formulari", 0 se la pagina non esiste.
 * Il risultato viene messo in cache per la durata della richiesta.
 *
 * @return int
 */
function ptf_get_formulari_page_id() {
    static $page_id = null;

    if ( null !== $page_id ) {
        return $page_id;
    }

    $page    = get_page_by_path( 'formulari' );
    $page_id = ( $page instanceof WP_Post ) ? (int) $page->ID : 0;

    return $page_id;
}

/**
 * Verifica se l'opzione "nascondi la pagina Formulari" è attiva.
 *
 * @return bool
 */
function ptf_is_formulari_hidden() {
    return '1' === (string) get_option( 'ptf_hide_formulari', '' );
}

/**
 * Verifica se il menu principale del tema padre ("ticinoWEB CMS") è già
 * stato registrato: serve a decidere dove agganciare la pagina di opzioni.
 *
 * @param string $parent_slug Slug del menu di primo livello da cercare.
 * @return bool
 */
function ptf_admin_menu_exists( $parent_slug ) {
    global $admin_page_hooks, $menu;

    if ( isset( $admin_page_hooks[ $parent_slug ] ) ) {
        return true;
    }

    if ( is_array( $menu ) ) {
        foreach ( $menu as $item ) {
            if ( isset( $item[2] ) && $parent_slug === $item[2] ) {
                return true;
            }
        }
    }

    return false;
}

/**
 * ==========================================================================
 * 2. REGISTRAZIONE DELLA PAGINA DI IMPOSTAZIONI
 * ==========================================================================
 */

/**
 * Aggiunge la pagina "Patriziato Frasco" come sottovoce di "ticinoWEB CMS".
 * Se quel menu non esiste (tema padre cambiato o disattivato) la pagina
 * viene registrata sotto "Impostazioni", così resta sempre raggiungibile.
 *
 * Priorità 20: il menu del tema padre viene registrato a priorità 10.
 */
function ptf_register_options_page() {
    if ( ptf_admin_menu_exists( 'ticinoweb-cms' ) ) {
        add_submenu_page(
            'ticinoweb-cms',
            __( 'Patriziato Frasco', 'patriziatofrasco' ),
            __( 'Patriziato Frasco', 'patriziatofrasco' ),
            'manage_options',
            PTF_OPTIONS_PAGE_SLUG,
            'ptf_render_options_page'
        );
        return;
    }

    // Fallback: Impostazioni › Patriziato Frasco
    add_options_page(
        __( 'Patriziato Frasco', 'patriziatofrasco' ),
        __( 'Patriziato Frasco', 'patriziatofrasco' ),
        'manage_options',
        PTF_OPTIONS_PAGE_SLUG,
        'ptf_render_options_page'
    );
}
add_action( 'admin_menu', 'ptf_register_options_page', 20 );

/**
 * Registra le impostazioni tramite Settings API.
 */
function ptf_register_settings() {
    register_setting(
        PTF_OPTIONS_GROUP,
        'ptf_hide_formulari',
        array(
            'type'              => 'string',
            'sanitize_callback' => 'ptf_sanitize_checkbox',
            'default'           => '',
            'show_in_rest'      => false,
        )
    );

    add_settings_section(
        'ptf_section_visibilita',
        __( 'Visibilità delle pagine', 'patriziatofrasco' ),
        'ptf_render_section_visibilita',
        PTF_OPTIONS_PAGE_SLUG
    );

    add_settings_field(
        'ptf_hide_formulari',
        __( 'Pagina Formulari', 'patriziatofrasco' ),
        'ptf_render_field_hide_formulari',
        PTF_OPTIONS_PAGE_SLUG,
        'ptf_section_visibilita',
        array( 'label_for' => 'ptf_hide_formulari' )
    );
}
add_action( 'admin_init', 'ptf_register_settings' );

/**
 * Sanitizza un valore da checkbox: restituisce '1' oppure stringa vuota.
 *
 * @param mixed $value Valore inviato dal form.
 * @return string
 */
function ptf_sanitize_checkbox( $value ) {
    return ( '1' === (string) $value ) ? '1' : '';
}

/**
 * ==========================================================================
 * 3. RENDER DELLA PAGINA
 * ==========================================================================
 */

/**
 * Testo introduttivo della sezione.
 */
function ptf_render_section_visibilita() {
    echo '<p>' . esc_html__( 'Da qui puoi decidere quali pagine del sito sono visibili al pubblico. Le pagine nascoste restano modificabili dal backend.', 'patriziatofrasco' ) . '</p>';
}

/**
 * Checkbox "Nascondi la pagina Formulari dal sito".
 */
function ptf_render_field_hide_formulari() {
    $is_hidden = ptf_is_formulari_hidden();
    $page_id   = ptf_get_formulari_page_id();
    ?>
    <label for="ptf_hide_formulari">
        <input type="checkbox"
               id="ptf_hide_formulari"
               name="ptf_hide_formulari"
               value="1"
               <?php checked( $is_hidden ); ?> />
        <?php esc_html_e( 'Nascondi la pagina Formulari dal sito', 'patriziatofrasco' ); ?>
    </label>
    <p class="description">
        <?php esc_html_e( 'Se attivo, la voce "Formulari" sparisce dal menu di navigazione e la pagina non è più raggiungibile dai visitatori (mostra una pagina "non trovata"). La pagina resta comunque nel backend e continua a essere modificabile e visibile agli amministratori collegati.', 'patriziatofrasco' ); ?>
    </p>
    <?php
    if ( ! $page_id ) {
        echo '<p class="description" style="color:#b32d2e;">' . esc_html__( 'Attenzione: al momento non esiste nessuna pagina con indirizzo /formulari/. L\'opzione non avrà alcun effetto finché la pagina non viene creata.', 'patriziatofrasco' ) . '</p>';
    } else {
        printf(
            '<p class="description"><a href="%1$s">%2$s</a></p>',
            esc_url( get_edit_post_link( $page_id ) ),
            esc_html__( 'Modifica la pagina Formulari', 'patriziatofrasco' )
        );
    }
}

/**
 * Render della pagina di impostazioni.
 */
function ptf_render_options_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( esc_html__( 'Non hai i permessi per accedere a questa pagina.', 'patriziatofrasco' ) );
    }
    ?>
    <div class="wrap">
        <h1><?php echo esc_html__( 'Patriziato Frasco — Opzioni tema', 'patriziatofrasco' ); ?></h1>
        <p><?php esc_html_e( 'Impostazioni specifiche del sito del Patriziato di Frasco.', 'patriziatofrasco' ); ?></p>

        <form action="options.php" method="post">
            <?php
            // Aggiunge nonce, action e campo option_page richiesti dalla Settings API.
            settings_fields( PTF_OPTIONS_GROUP );
            do_settings_sections( PTF_OPTIONS_PAGE_SLUG );
            submit_button( __( 'Salva le modifiche', 'patriziatofrasco' ) );
            ?>
        </form>

        <hr>

        <h2><?php esc_html_e( 'Manutenzione', 'patriziatofrasco' ); ?></h2>
        <p><?php esc_html_e( 'Due operazioni che prima si lanciavano aprendo un indirizzo nel browser. Adesso stanno qui, protette dai permessi di WordPress.', 'patriziatofrasco' ); ?></p>

        <?php
        $ptf_esito = isset( $_GET['ptf_manutenzione'] ) ? sanitize_key( wp_unslash( $_GET['ptf_manutenzione'] ) ) : '';

        if ( 'menu-ok' === $ptf_esito ) {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Menu ricostruito: le voci e i sottomenu sono stati riagganciati.', 'patriziatofrasco' ) . '</p></div>';
        } elseif ( 'menu-ko' === $ptf_esito ) {
            echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__( 'Non e stato possibile ricostruire il menu.', 'patriziatofrasco' ) . '</p></div>';
        } elseif ( 'permalink-ok' === $ptf_esito ) {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Permalink rigenerati.', 'patriziatofrasco' ) . '</p></div>';
        }
        ?>

        <table class="form-table" role="presentation">
            <tr>
                <th scope="row"><?php esc_html_e( 'Menu di navigazione', 'patriziatofrasco' ); ?></th>
                <td>
                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;">
                        <input type="hidden" name="action" value="ptf_ricostruisci_menu">
                        <?php wp_nonce_field( 'ptf_ricostruisci_menu' ); ?>
                        <?php submit_button( __( 'Ricostruisci il menu', 'patriziatofrasco' ), 'secondary', 'submit', false ); ?>
                    </form>
                    <p class="description"><?php esc_html_e( 'Ricrea il menu del sito con tutte le voci e i sottomenu. Serve dopo aver aggiunto pagine nuove, per esempio dopo un trasferimento contenuti.', 'patriziatofrasco' ); ?></p>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php esc_html_e( 'Permalink', 'patriziatofrasco' ); ?></th>
                <td>
                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;">
                        <input type="hidden" name="action" value="ptf_rigenera_permalink">
                        <?php wp_nonce_field( 'ptf_rigenera_permalink' ); ?>
                        <?php submit_button( __( 'Rigenera i permalink', 'patriziatofrasco' ), 'secondary', 'submit', false ); ?>
                    </form>
                    <p class="description"><?php esc_html_e( 'Da usare se un indirizzo di sentiero, capanna o punto di interesse restituisce "pagina non trovata".', 'patriziatofrasco' ); ?></p>
                </td>
            </tr>
        </table>
    </div>
    <?php
}

/**
 * Ricostruisce il menu su richiesta dal pannello.
 */
function ptf_handle_ricostruisci_menu() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( esc_html__( 'Non hai i permessi necessari.', 'patriziatofrasco' ) );
    }

    check_admin_referer( 'ptf_ricostruisci_menu' );

    $esito = function_exists( 'ptf_ricostruisci_menu' ) && ptf_ricostruisci_menu();

    if ( $esito ) {
        flush_rewrite_rules();
    }

    wp_safe_redirect(
        add_query_arg(
            'ptf_manutenzione',
            $esito ? 'menu-ok' : 'menu-ko',
            admin_url( 'admin.php?page=' . PTF_OPTIONS_PAGE_SLUG )
        )
    );
    exit;
}
add_action( 'admin_post_ptf_ricostruisci_menu', 'ptf_handle_ricostruisci_menu' );

/**
 * Rigenera le regole dei permalink su richiesta dal pannello.
 */
function ptf_handle_rigenera_permalink() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( esc_html__( 'Non hai i permessi necessari.', 'patriziatofrasco' ) );
    }

    check_admin_referer( 'ptf_rigenera_permalink' );
    flush_rewrite_rules();

    wp_safe_redirect(
        add_query_arg(
            'ptf_manutenzione',
            'permalink-ok',
            admin_url( 'admin.php?page=' . PTF_OPTIONS_PAGE_SLUG )
        )
    );
    exit;
}
add_action( 'admin_post_ptf_rigenera_permalink', 'ptf_handle_rigenera_permalink' );

/**
 * ==========================================================================
 * 4. EFFETTI DELL'OPZIONE SUL FRONTEND
 * ==========================================================================
 */

/**
 * Rimuove la voce "Formulari" (e le sue eventuali sottovoci) dai menu di
 * navigazione quando l'opzione è attiva.
 *
 * L'item viene individuato confrontando l'object_id con l'ID della pagina,
 * non con il testo del titolo. Vengono gestiti anche i link personalizzati
 * che puntano all'indirizzo della pagina.
 *
 * @param array $items Voci del menu.
 * @return array
 */
function ptf_filter_formulari_menu_item( $items ) {
    if ( is_admin() || ! ptf_is_formulari_hidden() || ! is_array( $items ) ) {
        return $items;
    }

    $page_id = ptf_get_formulari_page_id();
    if ( ! $page_id ) {
        return $items;
    }

    $page_url = untrailingslashit( (string) get_permalink( $page_id ) );
    $removed  = array();

    foreach ( $items as $key => $item ) {
        $is_target = false;

        if ( isset( $item->object, $item->object_id ) && 'page' === $item->object && (int) $item->object_id === $page_id ) {
            $is_target = true;
        } elseif ( $page_url && isset( $item->type, $item->url ) && 'custom' === $item->type && untrailingslashit( $item->url ) === $page_url ) {
            $is_target = true;
        }

        if ( $is_target ) {
            $removed[] = (string) $item->ID;
            unset( $items[ $key ] );
        }
    }

    if ( empty( $removed ) ) {
        return $items;
    }

    // Rimuove anche le sottovoci rimaste orfane (a qualsiasi livello di profondità).
    do {
        $found_child = false;

        foreach ( $items as $key => $item ) {
            if ( isset( $item->menu_item_parent ) && in_array( (string) $item->menu_item_parent, $removed, true ) ) {
                $removed[]   = (string) $item->ID;
                $found_child = true;
                unset( $items[ $key ] );
            }
        }
    } while ( $found_child );

    return $items;
}
add_filter( 'wp_nav_menu_objects', 'ptf_filter_formulari_menu_item', 10, 1 );

/**
 * Rende la pagina "Formulari" non raggiungibile pubblicamente quando
 * l'opzione è attiva: restituisce un 404 pulito.
 *
 * Chi può modificare le pagine (amministratori/editori collegati) continua
 * a vederla normalmente, per poterci lavorare.
 */
function ptf_block_formulari_page() {
    if ( ! ptf_is_formulari_hidden() ) {
        return;
    }

    $page_id = ptf_get_formulari_page_id();
    if ( ! $page_id || ! is_page( $page_id ) ) {
        return;
    }

    if ( current_user_can( 'edit_pages' ) ) {
        return;
    }

    global $wp_query;
    $wp_query->set_404();
    status_header( 404 );
    nocache_headers();

    // Il tema non ha un 404.php dedicato: in quel caso si usa il template di default.
    $template = get_query_template( '404' );
    if ( ! $template ) {
        $template = get_index_template();
    }
    if ( $template ) {
        include $template;
    }
    exit;
}
add_action( 'template_redirect', 'ptf_block_formulari_page' );
