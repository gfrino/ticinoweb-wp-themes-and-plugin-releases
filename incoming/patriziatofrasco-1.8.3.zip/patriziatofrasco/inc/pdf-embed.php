<?php
/**
 * Embed condiviso per gli allegati PDF
 *
 * Unica fonte di verità per la visualizzazione dei PDF allegati a Mozioni,
 * Comunicati e Attività. Il blocco embed NON sostituisce mai il contenuto
 * testuale: si aggiunge sotto al testo già presente nel template.
 *
 * CSS e JS vengono stampati una sola volta per richiesta (flag static),
 * insieme al primo blocco embed della pagina.
 *
 * @package Patriziato Frasco
 */

/**
 * Restituisce l'URL dell'allegato solo se è davvero un PDF valido.
 *
 * @param int|string $pdf_id ID dell'allegato.
 * @return string URL dell'allegato, oppure stringa vuota.
 */
if ( ! function_exists( 'ptf_get_pdf_attachment_url' ) ) {
    function ptf_get_pdf_attachment_url( $pdf_id ) {
        $pdf_id = absint( $pdf_id );

        if ( ! $pdf_id ) {
            return '';
        }

        // Deve essere un allegato della Media Library...
        if ( 'attachment' !== get_post_type( $pdf_id ) ) {
            return '';
        }

        // ...e deve essere davvero un PDF.
        if ( 'application/pdf' !== get_post_mime_type( $pdf_id ) ) {
            return '';
        }

        $url = wp_get_attachment_url( $pdf_id );

        return $url ? $url : '';
    }
}

/**
 * Verifica rapida: questo post ha un PDF valido da mostrare?
 * Utile nelle liste, dove non serve stampare l'embed ma solo un'indicazione.
 *
 * @param int|string $pdf_id ID dell'allegato.
 * @return bool
 */
if ( ! function_exists( 'ptf_has_pdf_attachment' ) ) {
    function ptf_has_pdf_attachment( $pdf_id ) {
        return '' !== ptf_get_pdf_attachment_url( $pdf_id );
    }
}

/**
 * CSS + JS dell'embed, stampati una sola volta per richiesta.
 *
 * @return string
 */
if ( ! function_exists( 'ptf_get_pdf_embed_assets' ) ) {
    function ptf_get_pdf_embed_assets() {
        static $stampati = false;

        if ( $stampati ) {
            return '';
        }
        $stampati = true;

        ob_start();
        ?>
<style id="ptf-pdf-embed-css">
/* ==========================================================================
   Embed PDF condiviso (Mozioni, Comunicati, Attività)
   ========================================================================== */
.ptf-pdf-embed {
    margin-top: 25px;
    width: 100%;
}
.ptf-pdf-embed__title {
    font-family: var(--font-heading);
    font-size: 1.15rem;
    font-weight: 600;
    color: var(--color-text-main);
    margin: 0 0 12px 0;
    display: flex;
    align-items: center;
    gap: 8px;
}
.ptf-pdf-embed__title svg {
    flex: 0 0 auto;
    color: var(--color-primary);
}

/* Cornice del documento */
.ptf-pdf-embed__frame {
    position: relative;
    width: 100%;
    height: 80vh;
    min-height: 420px;
    max-height: 900px;
    border: 1px solid rgba(0, 0, 0, 0.10);
    border-radius: var(--radius);
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.06);
    background-color: #F1F3F7;
    overflow: hidden;
}
/* Nelle LISTE (mozioni, attività) la cornice è più bassa: con 80vh a scheda
   una lista di 20 voci diventava lunga una quindicina di schermate. Chi vuole
   leggere il documento intero usa il pulsante e lo apre a tutta pagina. */
.ptf-pdf-embed--mozione .ptf-pdf-embed__frame,
.ptf-pdf-embed--attivita .ptf-pdf-embed__frame {
    height: 55vh;
    min-height: 320px;
    max-height: 560px;
}

.ptf-pdf-embed__frame object,
.ptf-pdf-embed__frame iframe {
    display: block;
    width: 100%;
    height: 100%;
    border: 0;
}
.ptf-pdf-embed__fallback {
    padding: 30px;
    margin: 0;
    text-align: center;
    color: var(--color-text-light);
    line-height: 1.6;
}

/* Segnaposto mostrato finché il documento non è stato iniettato.
   L'attributo data-ptf-pdf-js viene messo dallo script: senza JavaScript
   il segnaposto non compare e resta visibile il contenuto del <noscript>. */
.ptf-pdf-embed__frame[data-ptf-pdf-js="1"]:not([data-ptf-pdf-loaded="1"])::after {
    content: "Caricamento del documento…";
    position: absolute;
    inset: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    padding: 20px;
    color: var(--color-text-light);
    font-size: 0.95rem;
}

/* Azioni: il pulsante è SEMPRE presente (iOS/Android non mostrano l'embed) */
.ptf-pdf-embed__actions {
    margin-top: 15px;
    display: flex;
    align-items: center;
    gap: 15px;
    flex-wrap: wrap;
}
.ptf-pdf-embed__btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    background-color: var(--color-primary);
    color: #FFFFFF;
    padding: 10px 20px;
    border-radius: 4px;
    text-decoration: none;
    font-weight: bold;
    transition: background-color 0.3s ease;
}
.ptf-pdf-embed__btn:hover,
.ptf-pdf-embed__btn:focus {
    background-color: var(--color-primary-light);
    color: #FFFFFF;
}
.ptf-pdf-embed__filename {
    font-size: 0.9rem;
    color: var(--color-text-light);
    word-break: break-word;
}
.ptf-pdf-embed__hint {
    margin: 12px 0 0 0;
    font-size: 0.9rem;
    color: var(--color-text-light);
}
.ptf-pdf-embed__mobile-note {
    display: none;
    margin: 0 0 12px 0;
    font-size: 0.95rem;
    line-height: 1.6;
    color: var(--color-text-light);
}

/* Su schermo piccolo l'embed è inutilizzabile: mostriamo solo il pulsante.
   Scelta fatta via media query, non via user-agent sniffing. */
@media (max-width: 768px) {
    .ptf-pdf-embed__frame {
        display: none;
    }
    .ptf-pdf-embed__hint {
        display: none;
    }
    .ptf-pdf-embed__mobile-note {
        display: block;
    }
    .ptf-pdf-embed__actions {
        margin-top: 0;
    }
    .ptf-pdf-embed__btn {
        width: 100%;
        justify-content: center;
    }
}

/* Modalità scura: mai testo blu su fondo grigio, pulsanti blu con testo bianco */
html[data-theme="dark"] .ptf-pdf-embed__title {
    color: #FFFFFF;
}
html[data-theme="dark"] .ptf-pdf-embed__title svg {
    color: #9DB8F5;
}
html[data-theme="dark"] .ptf-pdf-embed__frame {
    border-color: rgba(255, 255, 255, 0.14);
    background-color: #22252B;
}
html[data-theme="dark"] .ptf-pdf-embed__btn,
html[data-theme="dark"] .ptf-pdf-embed__btn:hover,
html[data-theme="dark"] .ptf-pdf-embed__btn:focus {
    color: #FFFFFF !important;
}
html[data-theme="dark"] .ptf-pdf-embed__hint,
html[data-theme="dark"] .ptf-pdf-embed__mobile-note,
html[data-theme="dark"] .ptf-pdf-embed__filename,
html[data-theme="dark"] .ptf-pdf-embed__fallback {
    color: var(--color-text-light);
}
</style>
<script id="ptf-pdf-embed-js">
(function () {
    'use strict';

    // Quanto prima del viewport far partire il caricamento del documento.
    var ANTICIPO = '400px 0px';

    // La cornice è nascosta via CSS sotto i 768px: in quel caso non iniettiamo
    // nulla, così il PDF non viene scaricato inutilmente su mobile.
    function isVisible(el) {
        return !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
    }

    // Restituisce true quando lo slot è a posto (caricato o già caricato),
    // false quando va tenuto sotto osservazione (es. cornice nascosta).
    function build(slot) {
        if (slot.getAttribute('data-ptf-pdf-loaded') === '1') {
            return true;
        }
        if (!isVisible(slot)) {
            return false;
        }

        var src = slot.getAttribute('data-ptf-pdf-src');
        if (!src) {
            return true;
        }

        var obj = document.createElement('object');
        obj.setAttribute('type', 'application/pdf');
        obj.setAttribute('data', src);
        obj.setAttribute('aria-label', slot.getAttribute('data-ptf-pdf-label') || 'Documento PDF');

        var fallback = document.createElement('p');
        fallback.className = 'ptf-pdf-embed__fallback';
        fallback.textContent = 'Il browser non riesce a mostrare il PDF qui. Usa il pulsante qui sotto per aprirlo.';
        obj.appendChild(fallback);

        slot.innerHTML = '';
        slot.appendChild(obj);
        slot.setAttribute('data-ptf-pdf-loaded', '1');
        return true;
    }

    var observer = null;

    function getObserver() {
        if (!observer) {
            observer = new window.IntersectionObserver(function (entries) {
                for (var i = 0; i < entries.length; i++) {
                    var entry = entries[i];
                    if (!entry.isIntersecting && !(entry.intersectionRatio > 0)) {
                        continue;
                    }
                    if (build(entry.target)) {
                        observer.unobserve(entry.target);
                    }
                }
            }, { root: null, rootMargin: ANTICIPO, threshold: 0 });
        }
        return observer;
    }

    function init() {
        var slots = document.querySelectorAll('.ptf-pdf-embed__frame[data-ptf-pdf-src]');
        // Senza IntersectionObserver (browser molto vecchi) si carica subito:
        // meglio pesante che invisibile.
        var differito = ('IntersectionObserver' in window);

        for (var i = 0; i < slots.length; i++) {
            // Segnala al CSS che il segnaposto "Caricamento…" può comparire.
            slots[i].setAttribute('data-ptf-pdf-js', '1');

            if (differito) {
                getObserver().observe(slots[i]);
            } else {
                build(slots[i]);
            }
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
</script>
        <?php
        return ob_get_clean();
    }
}

/**
 * Stampa (o restituisce) il blocco embed di un allegato PDF.
 *
 * Non stampa nulla se l'allegato non esiste o non è un PDF: il template può
 * quindi chiamare la funzione senza controlli aggiuntivi.
 *
 * L'anteprima è SEMPRE visibile: non c'è nessun pannello da aprire. Il PDF vero
 * e proprio viene però scaricato solo quando la cornice sta per entrare nel
 * viewport (IntersectionObserver, vedi ptf_get_pdf_embed_assets()), così una
 * lista con molte schede non carica tutti i documenti insieme.
 *
 * @param int|string $pdf_id ID dell'allegato PDF.
 * @param array      $args {
 *     @type string $titolo         Titolo sopra l'embed. '' per nasconderlo. Default 'Documento allegato'.
 *     @type string $testo_pulsante Etichetta del pulsante di apertura/download.
 *     @type bool   $mostra_nome    Mostra nome file e peso accanto al pulsante. Default true.
 *     @type string $classe         Classi CSS extra sul contenitore.
 *     @type bool   $echo           Se stampare direttamente. Default true.
 * }
 * @return string HTML del blocco (vuoto se non c'è un PDF valido).
 */
if ( ! function_exists( 'ptf_render_pdf_embed' ) ) {
    function ptf_render_pdf_embed( $pdf_id, $args = array() ) {
        $pdf_url = ptf_get_pdf_attachment_url( $pdf_id );

        if ( '' === $pdf_url ) {
            return '';
        }

        $defaults = array(
            'titolo'         => 'Documento allegato',
            'testo_pulsante' => 'Apri il PDF',
            'mostra_nome'    => true,
            'classe'         => '',
            'echo'           => true,
        );
        $args = wp_parse_args( $args, $defaults );

        $pdf_id      = absint( $pdf_id );
        $titolo_file = get_the_title( $pdf_id );
        $nome_file   = basename( wp_parse_url( $pdf_url, PHP_URL_PATH ) );
        $etichetta   = $titolo_file ? $titolo_file : $nome_file;

        // "#view=FitH" fa partire il visualizzatore adattato alla larghezza.
        $embed_url = $pdf_url . ( false === strpos( $pdf_url, '#' ) ? '#view=FitH' : '' );

        // Peso del file, se leggibile (utile prima di aprirlo da mobile).
        $peso    = '';
        $percorso = get_attached_file( $pdf_id );
        if ( $percorso && file_exists( $percorso ) ) {
            $peso = size_format( filesize( $percorso ) );
        }

        $icona_doc = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z"></path></svg>';
        $icona_apri = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path></svg>';

        $classi = 'ptf-pdf-embed';
        if ( $args['classe'] ) {
            $classi .= ' ' . $args['classe'];
        }

        // --- Corpo: cornice + azioni -------------------------------------
        $corpo  = '<div class="ptf-pdf-embed__body">';
        $corpo .= '<p class="ptf-pdf-embed__mobile-note">Su schermi piccoli il documento non viene mostrato qui: aprilo con il pulsante.</p>';
        $corpo .= '<div class="ptf-pdf-embed__frame" data-ptf-pdf-src="' . esc_url( $embed_url ) . '" data-ptf-pdf-label="' . esc_attr( $etichetta ) . '">';
        // Senza JavaScript l'embed viene comunque mostrato.
        $corpo .= '<noscript><object type="application/pdf" data="' . esc_url( $embed_url ) . '" aria-label="' . esc_attr( $etichetta ) . '"><p class="ptf-pdf-embed__fallback">Il browser non riesce a mostrare il PDF qui. Usa il pulsante qui sotto per aprirlo.</p></object></noscript>';
        $corpo .= '</div>';
        $corpo .= '<p class="ptf-pdf-embed__hint">Se il documento non viene visualizzato correttamente, aprilo in una nuova scheda.</p>';
        $corpo .= '<div class="ptf-pdf-embed__actions">';
        $corpo .= '<a class="ptf-pdf-embed__btn" href="' . esc_url( $pdf_url ) . '" target="_blank" rel="noopener">' . $icona_apri . esc_html( $args['testo_pulsante'] ) . '</a>';
        if ( $args['mostra_nome'] ) {
            $corpo .= '<span class="ptf-pdf-embed__filename">' . esc_html( $nome_file ) . ( $peso ? ' &middot; ' . esc_html( $peso ) : '' ) . '</span>';
        }
        $corpo .= '</div>';
        $corpo .= '</div>';

        // --- Contenitore --------------------------------------------------
        $html = '<div class="' . esc_attr( $classi ) . '">';

        if ( $args['titolo'] ) {
            $html .= '<h3 class="ptf-pdf-embed__title">' . $icona_doc . esc_html( $args['titolo'] ) . '</h3>';
        }

        $html .= $corpo;
        $html .= '</div>';

        // CSS e JS una sola volta per pagina, insieme al primo embed.
        $html = ptf_get_pdf_embed_assets() . $html;

        if ( $args['echo'] ) {
            echo $html; // phpcs:ignore WordPress.Security.EscapeOutput -- HTML già sanificato sopra.
        }

        return $html;
    }
}
