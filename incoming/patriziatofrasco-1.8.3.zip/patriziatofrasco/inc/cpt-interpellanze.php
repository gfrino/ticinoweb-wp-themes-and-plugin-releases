<?php
/**
 * Registrazione Custom Post Type per le Interpellanze
 */

// 1. Registra il Custom Post Type
function patriziatofrasco_register_interpellanze_cpt() {
    $labels = array(
        'name'                  => _x( 'Interpellanze', 'Post type general name', 'patriziatofrasco' ),
        'singular_name'         => _x( 'Interpellanza', 'Post type singular name', 'patriziatofrasco' ),
        'menu_name'             => _x( 'Interpellanze', 'Admin Menu text', 'patriziatofrasco' ),
        'name_admin_bar'        => _x( 'Interpellanza', 'Add New on Toolbar', 'patriziatofrasco' ),
        'add_new'               => __( 'Aggiungi Nuova', 'patriziatofrasco' ),
        'add_new_item'          => __( 'Aggiungi Nuova Interpellanza', 'patriziatofrasco' ),
        'new_item'              => __( 'Nuova Interpellanza', 'patriziatofrasco' ),
        'edit_item'             => __( 'Modifica Interpellanza', 'patriziatofrasco' ),
        'view_item'             => __( 'Visualizza Interpellanza', 'patriziatofrasco' ),
        'all_items'             => __( 'Tutte le Interpellanze', 'patriziatofrasco' ),
        'search_items'          => __( 'Cerca Interpellanze', 'patriziatofrasco' ),
        'parent_item_colon'     => __( 'Interpellanze Genitore:', 'patriziatofrasco' ),
        'not_found'             => __( 'Nessuna interpellanza trovata.', 'patriziatofrasco' ),
        'not_found_in_trash'    => __( 'Nessuna interpellanza trovata nel cestino.', 'patriziatofrasco' ),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'interpellanza' ),
        'capability_type'    => 'post',
        'has_archive'        => false,
        'hierarchical'       => false,
        'menu_position'      => 5.1, // 1° posizione custom
        'menu_icon'          => 'dashicons-format-chat', // Icona dialogo/messaggio
        'supports'           => array( 'title' ), // Solo Titolo
        'show_in_rest'       => false, // Disabilita Gutenberg per avere il layout classico pulito
    );

    register_post_type( 'interpellanza', $args );
}
add_action( 'init', 'patriziatofrasco_register_interpellanze_cpt' );

// 2. Aggiunge i Meta Box personalizzati
function patriziatofrasco_add_interpellanze_metaboxes() {
    add_meta_box(
        'interpellanze_meta_box', // ID
        'Dettagli Interpellanza', // Titolo
        'patriziatofrasco_interpellanze_metabox_callback', // Callback
        'interpellanza', // Post Type
        'normal', // Contesto
        'high' // Priorità
    );
}
add_action( 'add_meta_boxes', 'patriziatofrasco_add_interpellanze_metaboxes' );

// 3. Costruisce l'HTML per il Meta Box
function patriziatofrasco_interpellanze_metabox_callback( $post ) {
    wp_nonce_field( 'interpellanze_save_meta_box_data', 'interpellanze_meta_box_nonce' );

    // Recupera i valori attuali
    $data_presentazione = get_post_meta( $post->ID, '_interpellanza_data_presentazione', true );
    $proponente = get_post_meta( $post->ID, '_interpellanza_proponente', true );
    $oggetto = get_post_meta( $post->ID, '_interpellanza_oggetto', true );
    $testo = get_post_meta( $post->ID, '_interpellanza_testo', true );
    $stato = get_post_meta( $post->ID, '_interpellanza_stato', true );
    $risposta = get_post_meta( $post->ID, '_interpellanza_risposta', true );
    $data_risposta = get_post_meta( $post->ID, '_interpellanza_data_risposta', true );
    $pdf_id = get_post_meta( $post->ID, '_interpellanza_pdf_id', true );
    $pdf_url = $pdf_id ? wp_get_attachment_url( $pdf_id ) : '';

    // HTML del Form
    echo '<style>
        .interp-field-row { margin-bottom: 20px; }
        .interp-field-row label { display: block; font-weight: bold; margin-bottom: 5px; }
        .interp-field-row input[type="text"], .interp-field-row input[type="date"], .interp-field-row select { width: 100%; max-width: 500px; padding: 5px; }
        .interp-field-row textarea { width: 100%; max-width: 100%; padding: 10px; font-family: inherit; }
        .interp-pdf-preview { margin-top: 10px; display: block; }
        .interp-risposta-box { background: #f9f9f9; padding: 15px; border-left: 4px solid #0073aa; margin-top: 30px; }
        .interp-risposta-box h4 { margin-top: 0; margin-bottom: 15px; font-size: 14px; }
    </style>';

    // Data Presentazione
    echo '<div class="interp-field-row">';
    echo '<label for="interpellanza_data_presentazione">Data di presentazione</label>';
    echo '<input type="date" id="interpellanza_data_presentazione" name="interpellanza_data_presentazione" value="' . esc_attr( $data_presentazione ) . '" />';
    echo '</div>';

    // Interpellante
    echo '<div class="interp-field-row">';
    echo '<label for="interpellanza_proponente">Interpellante / Proponente</label>';
    echo '<input type="text" id="interpellanza_proponente" name="interpellanza_proponente" value="' . esc_attr( $proponente ) . '" placeholder="Es. Consigliere Mario Rossi" />';
    echo '</div>';

    // Oggetto
    echo '<div class="interp-field-row">';
    echo '<label for="interpellanza_oggetto">Oggetto dell\'interpellanza</label>';
    echo '<input type="text" id="interpellanza_oggetto" name="interpellanza_oggetto" value="' . esc_attr( $oggetto ) . '" placeholder="Es. Richiesta ripristino sentiero" />';
    echo '</div>';

    // Testo dell'interpellanza
    echo '<div class="interp-field-row">';
    echo '<label for="interpellanza_testo">Testo dell\'interpellanza</label>';
    echo '<textarea id="interpellanza_testo" name="interpellanza_testo" rows="8">' . esc_textarea( $testo ) . '</textarea>';
    echo '</div>';

    // Stato
    echo '<div class="interp-field-row">';
    echo '<label for="interpellanza_stato">Stato</label>';
    echo '<select id="interpellanza_stato" name="interpellanza_stato">';
    echo '<option value="In attesa di risposta" ' . selected( $stato, 'In attesa di risposta', false ) . '>In attesa di risposta</option>';
    echo '<option value="Risposta pubblicata" ' . selected( $stato, 'Risposta pubblicata', false ) . '>Risposta pubblicata</option>';
    echo '<option value="Chiusa" ' . selected( $stato, 'Chiusa', false ) . '>Chiusa</option>';
    echo '<option value="Ritirata" ' . selected( $stato, 'Ritirata', false ) . '>Ritirata</option>';
    echo '</select>';
    echo '</div>';

    // Allegato PDF
    echo '<div class="interp-field-row">';
    echo '<label>Allegato PDF (Facoltativo)</label>';
    echo '<input type="hidden" id="interpellanza_pdf_id" name="interpellanza_pdf_id" value="' . esc_attr( $pdf_id ) . '" />';
    echo '<button type="button" class="button button-secondary" id="interpellanza_upload_pdf_btn">Seleziona o carica PDF</button>';
    echo '<button type="button" class="button button-link-delete" id="interpellanza_remove_pdf_btn" style="' . ( $pdf_id ? '' : 'display:none;' ) . '">Rimuovi PDF</button>';
    echo '<span class="interp-pdf-preview" id="interpellanza_pdf_preview">';
    if ( $pdf_url ) {
        echo '<a href="' . esc_url( $pdf_url ) . '" target="_blank">Vedi PDF attuale (' . esc_html( basename( $pdf_url ) ) . ')</a>';
    }
    echo '</span>';
    echo '</div>';

    // Blocco Risposta Consiglio
    echo '<div class="interp-risposta-box">';
    echo '<h4>Risposta del Consiglio Patriziale</h4>';
    
    echo '<div class="interp-field-row">';
    echo '<label for="interpellanza_data_risposta">Data della risposta (Facoltativa)</label>';
    echo '<input type="date" id="interpellanza_data_risposta" name="interpellanza_data_risposta" value="' . esc_attr( $data_risposta ) . '" />';
    echo '</div>';

    echo '<div class="interp-field-row">';
    echo '<label for="interpellanza_risposta">Testo della risposta (Facoltativa)</label>';
    echo '<textarea id="interpellanza_risposta" name="interpellanza_risposta" rows="8">' . esc_textarea( $risposta ) . '</textarea>';
    echo '<p class="description">Inserisci qui la risposta ufficiale del Consiglio. Verrà mostrata graficamente staccata dal testo originale nel sito pubblico.</p>';
    echo '</div>';
    
    echo '</div>';

    // Script media uploader
    ?>
    <script>
    jQuery(document).ready(function($){
        var mediaUploader;
        $('#interpellanza_upload_pdf_btn').click(function(e) {
            e.preventDefault();
            if (mediaUploader) {
                mediaUploader.open();
                return;
            }
            mediaUploader = wp.media.frames.file_frame = wp.media({
                title: 'Seleziona Allegato PDF',
                button: { text: 'Usa questo file' },
                multiple: false,
                library: { type: 'application/pdf' }
            });
            mediaUploader.on('select', function() {
                var attachment = mediaUploader.state().get('selection').first().toJSON();
                $('#interpellanza_pdf_id').val(attachment.id);
                $('#interpellanza_pdf_preview').html('<a href="' + attachment.url + '" target="_blank">Vedi PDF attuale (' + attachment.filename + ')</a>');
                $('#interpellanza_remove_pdf_btn').show();
            });
            mediaUploader.open();
        });

        $('#interpellanza_remove_pdf_btn').click(function(e){
            e.preventDefault();
            $('#interpellanza_pdf_id').val('');
            $('#interpellanza_pdf_preview').html('');
            $(this).hide();
        });
    });
    </script>
    <?php
}

// 4. Salva i dati
function patriziatofrasco_save_interpellanze_meta_box_data( $post_id ) {
    if ( ! isset( $_POST['interpellanze_meta_box_nonce'] ) ) return;
    if ( ! wp_verify_nonce( $_POST['interpellanze_meta_box_nonce'], 'interpellanze_save_meta_box_data' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( isset( $_POST['post_type'] ) && 'interpellanza' == $_POST['post_type'] ) {
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;
    }

    $fields_text = array(
        '_interpellanza_data_presentazione' => 'interpellanza_data_presentazione',
        '_interpellanza_proponente'         => 'interpellanza_proponente',
        '_interpellanza_oggetto'            => 'interpellanza_oggetto',
        '_interpellanza_stato'              => 'interpellanza_stato',
        '_interpellanza_data_risposta'      => 'interpellanza_data_risposta',
        '_interpellanza_pdf_id'             => 'interpellanza_pdf_id'
    );

    // Campi standard (sanitize text)
    foreach ($fields_text as $meta_key => $post_field) {
        if ( isset( $_POST[$post_field] ) ) {
            update_post_meta( $post_id, $meta_key, sanitize_text_field( $_POST[$post_field] ) );
        }
    }

    // Campo textarea (testo interpellanza e risposta) che potrebbero contenere a capo
    if ( isset( $_POST['interpellanza_testo'] ) ) {
        update_post_meta( $post_id, '_interpellanza_testo', sanitize_textarea_field( wp_unslash( $_POST['interpellanza_testo'] ) ) );
    }
    
    if ( isset( $_POST['interpellanza_risposta'] ) ) {
        // Uso sanitize_textarea_field per preservare gli a capo
        update_post_meta( $post_id, '_interpellanza_risposta', sanitize_textarea_field( wp_unslash( $_POST['interpellanza_risposta'] ) ) );
    }
}
add_action( 'save_post', 'patriziatofrasco_save_interpellanze_meta_box_data' );

// 5. Supporto media uploader in admin
function patriziatofrasco_enqueue_interpellanze_admin_scripts( $hook ) {
    global $post;
    if ( $hook == 'post-new.php' || $hook == 'post.php' ) {
        if ( 'interpellanza' === $post->post_type ) {
            wp_enqueue_media();
        }
    }
}
add_action( 'admin_enqueue_scripts', 'patriziatofrasco_enqueue_interpellanze_admin_scripts' );
