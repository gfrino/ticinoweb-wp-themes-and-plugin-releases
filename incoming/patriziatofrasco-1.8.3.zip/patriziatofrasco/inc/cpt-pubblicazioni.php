<?php
function pf_register_pubblicazioni_cpt() {
    $labels = array(
        'name'                  => 'Pubblicazioni',
        'singular_name'         => 'Pubblicazione',
        'menu_name'             => 'Pubblicazioni',
        'name_admin_bar'        => 'Pubblicazione',
        'add_new'               => 'Aggiungi Nuova',
        'add_new_item'          => 'Aggiungi Nuova Pubblicazione',
        'new_item'              => 'Nuova Pubblicazione',
        'edit_item'             => 'Modifica Pubblicazione',
        'view_item'             => 'Visualizza Pubblicazione',
        'all_items'             => 'Tutte le Pubblicazioni',
        'search_items'          => 'Cerca Pubblicazioni',
        'not_found'             => 'Nessuna pubblicazione trovata.',
        'not_found_in_trash'    => 'Nessuna pubblicazione nel cestino.',
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'pubblicazione' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 9,
        'menu_icon'          => 'dashicons-book',
        'supports'           => array( 'title', 'thumbnail', 'excerpt' ), // No need for full editor unless there is a long description
    );

    register_post_type( 'pubblicazione', $args );
}
add_action( 'init', 'pf_register_pubblicazioni_cpt' );

function pf_pubblicazioni_add_metaboxes() {
    add_meta_box(
        'pf_pubblicazione_details',
        'Dettagli Libro',
        'pf_pubblicazione_details_callback',
        'pubblicazione',
        'normal',
        'high'
    );
}
add_action( 'add_meta_boxes', 'pf_pubblicazioni_add_metaboxes' );

function pf_pubblicazione_details_callback( $post ) {
    wp_nonce_field( 'pf_pubblicazione_save_data', 'pf_pubblicazione_meta_nonce' );

    $price = get_post_meta( $post->ID, '_pub_price', true );
    $authors = get_post_meta( $post->ID, '_pub_authors', true );
    $edition = get_post_meta( $post->ID, '_pub_edition', true );
    $languages = get_post_meta( $post->ID, '_pub_languages', true );
    $link = get_post_meta( $post->ID, '_pub_link', true );
    $link_text = get_post_meta( $post->ID, '_pub_link_text', true ) ?: 'Acquista online';
    ?>
    <style>
        .pf-meta-row { margin-bottom: 15px; }
        .pf-meta-row label { display: block; font-weight: bold; margin-bottom: 5px; }
        .pf-meta-row input[type="text"], .pf-meta-row input[type="url"] { width: 100%; max-width: 600px; padding: 5px; }
        .pf-meta-row p.description { color: #666; font-size: 12px; margin-top: 5px; }
    </style>
    <div class="pf-meta-row">
        <label for="pf_pub_price">Prezzo (es. 5.00 CHF)</label>
        <input type="text" id="pf_pub_price" name="pf_pub_price" value="<?php echo esc_attr( $price ); ?>">
    </div>
    <div class="pf-meta-row">
        <label for="pf_pub_authors">Autori</label>
        <input type="text" id="pf_pub_authors" name="pf_pub_authors" value="<?php echo esc_attr( $authors ); ?>">
    </div>
    <div class="pf-meta-row">
        <label for="pf_pub_edition">Edizione / Anno</label>
        <input type="text" id="pf_pub_edition" name="pf_pub_edition" value="<?php echo esc_attr( $edition ); ?>">
    </div>
    <div class="pf-meta-row">
        <label for="pf_pub_languages">Lingue</label>
        <input type="text" id="pf_pub_languages" name="pf_pub_languages" value="<?php echo esc_attr( $languages ); ?>">
    </div>
    <div class="pf-meta-row">
        <label for="pf_pub_link">Link per l'acquisto (URL)</label>
        <input type="url" id="pf_pub_link" name="pf_pub_link" value="<?php echo esc_url( $link ); ?>" placeholder="https://www.museovalverzasca.ch/shop">
    </div>
    <div class="pf-meta-row">
        <label for="pf_pub_link_text">Testo del Bottone</label>
        <input type="text" id="pf_pub_link_text" name="pf_pub_link_text" value="<?php echo esc_attr( $link_text ); ?>">
    </div>
    <?php
}

function pf_pubblicazione_save_meta( $post_id ) {
    if ( ! isset( $_POST['pf_pubblicazione_meta_nonce'] ) || ! wp_verify_nonce( $_POST['pf_pubblicazione_meta_nonce'], 'pf_pubblicazione_save_data' ) ) {
        return;
    }
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }

    if ( isset( $_POST['pf_pub_price'] ) ) update_post_meta( $post_id, '_pub_price', sanitize_text_field( $_POST['pf_pub_price'] ) );
    if ( isset( $_POST['pf_pub_authors'] ) ) update_post_meta( $post_id, '_pub_authors', sanitize_text_field( $_POST['pf_pub_authors'] ) );
    if ( isset( $_POST['pf_pub_edition'] ) ) update_post_meta( $post_id, '_pub_edition', sanitize_text_field( $_POST['pf_pub_edition'] ) );
    if ( isset( $_POST['pf_pub_languages'] ) ) update_post_meta( $post_id, '_pub_languages', sanitize_text_field( $_POST['pf_pub_languages'] ) );
    if ( isset( $_POST['pf_pub_link'] ) ) update_post_meta( $post_id, '_pub_link', esc_url_raw( $_POST['pf_pub_link'] ) );
    if ( isset( $_POST['pf_pub_link_text'] ) ) update_post_meta( $post_id, '_pub_link_text', sanitize_text_field( $_POST['pf_pub_link_text'] ) );
}
add_action( 'save_post', 'pf_pubblicazione_save_meta' );

function pf_pubblicazione_custom_columns( $columns ) {
    $new_columns = array();
    foreach($columns as $key => $value) {
        if ($key === 'title') {
            $new_columns['thumbnail'] = 'Copertina';
            $new_columns[$key] = $value;
            $new_columns['price'] = 'Prezzo';
            $new_columns['authors'] = 'Autori';
        } else {
            $new_columns[$key] = $value;
        }
    }
    return $new_columns;
}
add_filter( 'manage_pubblicazione_posts_columns', 'pf_pubblicazione_custom_columns' );

function pf_pubblicazione_custom_column_content( $column, $post_id ) {
    switch ( $column ) {
        case 'thumbnail':
            if ( has_post_thumbnail( $post_id ) ) {
                echo '<div style="width: 80px;">' . get_the_post_thumbnail( $post_id, array( 80, 80 ), array( 'style' => 'width:100%; height:auto; border-radius:4px; object-fit: cover;' ) ) . '</div>';
            } else {
                echo 'Nessuna';
            }
            break;
        case 'price':
            echo esc_html( get_post_meta( $post_id, '_pub_price', true ) );
            break;
        case 'authors':
            echo esc_html( get_post_meta( $post_id, '_pub_authors', true ) );
            break;
    }
}
add_action( 'manage_pubblicazione_posts_custom_column', 'pf_pubblicazione_custom_column_content', 10, 2 );

function pf_pubblicazione_custom_column_width() {
    echo '<style>.column-thumbnail { width: 100px !important; }</style>';
}
add_action('admin_head', 'pf_pubblicazione_custom_column_width');
