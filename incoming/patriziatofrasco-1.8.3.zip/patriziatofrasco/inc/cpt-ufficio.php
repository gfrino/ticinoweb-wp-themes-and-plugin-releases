<?php
/**
 * Registrazione Custom Post Type per l'Ufficio Patriziale
 */

// 1. Registra il Custom Post Type
function patriziatofrasco_register_ufficio_cpt() {
    $labels = array(
        'name'                  => _x( 'Ufficio Patriziale', 'Post type general name', 'patriziatofrasco' ),
        'singular_name'         => _x( 'Membro', 'Post type singular name', 'patriziatofrasco' ),
        'menu_name'             => _x( 'Ufficio Patriziale', 'Admin Menu text', 'patriziatofrasco' ),
        'name_admin_bar'        => _x( 'Membro Ufficio', 'Add New on Toolbar', 'patriziatofrasco' ),
        'add_new'               => __( 'Aggiungi Membro', 'patriziatofrasco' ),
        'add_new_item'          => __( 'Aggiungi Nuovo Membro', 'patriziatofrasco' ),
        'new_item'              => __( 'Nuovo Membro', 'patriziatofrasco' ),
        'edit_item'             => __( 'Modifica Membro', 'patriziatofrasco' ),
        'view_item'             => __( 'Visualizza Membro', 'patriziatofrasco' ),
        'all_items'             => __( 'Tutti i Membri', 'patriziatofrasco' ),
        'search_items'          => __( 'Cerca Membri', 'patriziatofrasco' ),
        'not_found'             => __( 'Nessun membro trovato.', 'patriziatofrasco' ),
        'not_found_in_trash'    => __( 'Nessun membro trovato nel cestino.', 'patriziatofrasco' ),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => false, // Non serve una pagina singola per ogni membro
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => false,
        'capability_type'    => 'post',
        'has_archive'        => false,
        'hierarchical'       => false,
        'menu_position'      => 5.46, // Esattamente sotto Prodotti
        'menu_icon'          => 'dashicons-groups', // Icona gruppo di persone
        'supports'           => array( 'title', 'thumbnail', 'page-attributes' ), // Titolo (Nome), Foto, Ordine
        'show_in_rest'       => false, // Interfaccia classica senza Gutenberg
    );

    register_post_type( 'ufficio', $args );
}
add_action( 'init', 'patriziatofrasco_register_ufficio_cpt' );

// 2. Aggiunge i Meta Box personalizzati
function patriziatofrasco_add_ufficio_metaboxes() {
    add_meta_box(
        'ufficio_meta_box', // ID
        'Dettagli del Membro', // Titolo
        'patriziatofrasco_ufficio_metabox_callback', // Callback
        'ufficio', // Post Type
        'normal', // Contesto
        'high' // Priorità
    );
}
add_action( 'add_meta_boxes', 'patriziatofrasco_add_ufficio_metaboxes' );

// 3. Costruisce l'HTML per il Meta Box
function patriziatofrasco_ufficio_metabox_callback( $post ) {
    wp_nonce_field( 'ufficio_save_meta_box_data', 'ufficio_meta_box_nonce' );

    // Recupera i valori attuali
    $ruolo = get_post_meta( $post->ID, '_ufficio_ruolo', true );
    $email = get_post_meta( $post->ID, '_ufficio_email', true );
    $telefono = get_post_meta( $post->ID, '_ufficio_telefono', true );

    echo '<style>
        .ufficio-metabox-wrapper { padding: 10px 5px; }
        .form-field-row { margin-bottom: 25px; }
        .form-field-row label { display: block; font-weight: 600; margin-bottom: 8px; font-size: 14px; color: #23282d; }
        .form-field-row input[type="text"], .form-field-row input[type="email"], .form-field-row input[type="tel"] { width: 100%; max-width: 100%; padding: 8px 12px; font-size: 14px; border-radius: 4px; border: 1px solid #ccc; }
        .form-help-text { background: #f0f6fc; border-left: 4px solid #72aee6; padding: 10px 15px; margin-bottom: 20px; color: #1d2327; font-size: 14px; }
    </style>';

    echo '<div class="ufficio-metabox-wrapper">';
    
    echo '<div class="form-help-text">💡 <strong>Istruzioni:</strong> Il "Titolo" in cima alla pagina sarà il Nome e Cognome della persona. Usa la colonna di destra per aggiungere un\'eventuale fototessera ("Immagine in evidenza").</div>';

    // Ruolo
    echo '<div class="form-field-row">';
    echo '<label for="ufficio_ruolo">Ruolo / Carica</label>';
    echo '<input type="text" id="ufficio_ruolo" name="ufficio_ruolo" value="' . esc_attr( $ruolo ) . '" placeholder="Es. Presidente, Segretaria, Membro..." />';
    echo '</div>';

    // Email
    echo '<div class="form-field-row">';
    echo '<label for="ufficio_email">Indirizzo E-mail</label>';
    echo '<input type="email" id="ufficio_email" name="ufficio_email" value="' . esc_attr( $email ) . '" placeholder="Es. mario.rossi@esempio.ch" />';
    echo '</div>';

    // Telefono
    echo '<div class="form-field-row">';
    echo '<label for="ufficio_telefono">Telefono (Opzionale)</label>';
    echo '<input type="tel" id="ufficio_telefono" name="ufficio_telefono" value="' . esc_attr( $telefono ) . '" placeholder="Es. +41 79 123 45 67" />';
    echo '</div>';

    echo '</div>';
}

// 4. Salva i dati
function patriziatofrasco_save_ufficio_meta_box_data( $post_id ) {
    if ( ! isset( $_POST['ufficio_meta_box_nonce'] ) ) return;
    if ( ! wp_verify_nonce( $_POST['ufficio_meta_box_nonce'], 'ufficio_save_meta_box_data' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( isset( $_POST['post_type'] ) && 'ufficio' == $_POST['post_type'] ) {
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;
    }

    if ( isset( $_POST['ufficio_ruolo'] ) ) {
        update_post_meta( $post_id, '_ufficio_ruolo', sanitize_text_field( $_POST['ufficio_ruolo'] ) );
    }

    if ( isset( $_POST['ufficio_email'] ) ) {
        update_post_meta( $post_id, '_ufficio_email', sanitize_email( $_POST['ufficio_email'] ) );
    }

    if ( isset( $_POST['ufficio_telefono'] ) ) {
        update_post_meta( $post_id, '_ufficio_telefono', sanitize_text_field( $_POST['ufficio_telefono'] ) );
    }
}
add_action( 'save_post', 'patriziatofrasco_save_ufficio_meta_box_data' );

// 5. Abilita il Drag & Drop per ordinare i membri nel backend
function patriziatofrasco_ufficio_enqueue_sortable() {
    global $typenow;
    if ( $typenow == 'ufficio' ) {
        wp_enqueue_script('jquery-ui-sortable');
        wp_add_inline_script('jquery-ui-sortable', "
            jQuery(document).ready(function($) {
                $('.wp-list-table tbody').sortable({
                    items: 'tr',
                    cursor: 'move',
                    axis: 'y',
                    update: function(e, ui) {
                        var postIDs = [];
                        $('.wp-list-table tbody tr').each(function() {
                            var id = $(this).attr('id').replace('post-', '');
                            postIDs.push(id);
                        });
                        
                        $.ajax({
                            url: ajaxurl,
                            type: 'POST',
                            data: {
                                action: 'update_ufficio_order',
                                order: postIDs,
                                security: '" . wp_create_nonce('update_ufficio_order_nonce') . "'
                            }
                        });
                    }
                });
            });
        ");
        
        echo '<style>.wp-list-table tbody tr { cursor: move; } .wp-list-table tbody tr:hover { background-color: #f6f7f7; }</style>';
    }
}
add_action( 'admin_enqueue_scripts', 'patriziatofrasco_ufficio_enqueue_sortable' );

// 6. Salva l'ordine Drag & Drop via AJAX
function patriziatofrasco_save_ufficio_order() {
    check_ajax_referer('update_ufficio_order_nonce', 'security');
    
    if ( ! current_user_can('edit_posts') ) {
        wp_die();
    }
    
    $order = isset($_POST['order']) ? $_POST['order'] : array();
    
    if ( !empty($order) && is_array($order) ) {
        global $wpdb;
        foreach ( $order as $menu_order => $post_id ) {
            $post_id = intval($post_id);
            $menu_order = intval($menu_order);
            
            $wpdb->update( 
                $wpdb->posts, 
                array( 'menu_order' => $menu_order ), 
                array( 'ID' => $post_id ), 
                array( '%d' ), 
                array( '%d' ) 
            );
        }
    }
    
    wp_send_json_success();
}
add_action('wp_ajax_update_ufficio_order', 'patriziatofrasco_save_ufficio_order');

?>
