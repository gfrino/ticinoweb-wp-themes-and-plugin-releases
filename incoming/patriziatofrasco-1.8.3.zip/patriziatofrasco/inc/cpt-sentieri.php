<?php
/**
 * Registrazione Custom Post Type: Capanne
 * (Originariamente "Sentieri & Capanne", ora solo Capanne)
 */
function patriziatofrasco_register_capanne_cpt() {
	$labels = array(
		'name'                  => _x( 'Capanne', 'Post type general name', 'patriziatofrasco' ),
		'singular_name'         => _x( 'Capanna', 'Post type singular name', 'patriziatofrasco' ),
		'menu_name'             => _x( 'Capanne', 'Admin Menu text', 'patriziatofrasco' ),
		'name_admin_bar'        => _x( 'Capanna', 'Add New on Toolbar', 'patriziatofrasco' ),
		'add_new'               => __( 'Aggiungi Nuova', 'patriziatofrasco' ),
		'add_new_item'          => __( 'Aggiungi Nuova Capanna', 'patriziatofrasco' ),
		'new_item'              => __( 'Nuova Capanna', 'patriziatofrasco' ),
		'edit_item'             => __( 'Modifica Capanna', 'patriziatofrasco' ),
		'view_item'             => __( 'Guarda Capanna', 'patriziatofrasco' ),
		'all_items'             => __( 'Tutte le Capanne', 'patriziatofrasco' ),
		'search_items'          => __( 'Cerca Capanne', 'patriziatofrasco' ),
		'not_found'             => __( 'Nessuna capanna trovata.', 'patriziatofrasco' ),
		'not_found_in_trash'    => __( 'Nessuna capanna nel cestino.', 'patriziatofrasco' ),
	);

	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'capanna' ),
		'capability_type'    => 'post',
		'has_archive'        => false, 
		'hierarchical'       => false,
		'menu_position'      => 5.5,
		'menu_icon'          => 'dashicons-admin-home',
		'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
		'show_in_rest'       => true,
	);

	register_post_type( 'capanna', $args );
}
add_action( 'init', 'patriziatofrasco_register_capanne_cpt' );

/**
 * Registrazione Custom Post Type: Sentieri (Percorsi)
 */
function patriziatofrasco_register_sentieri_cpt() {
	$labels = array(
		'name'                  => _x( 'Sentieri', 'Post type general name', 'patriziatofrasco' ),
		'singular_name'         => _x( 'Sentiero', 'Post type singular name', 'patriziatofrasco' ),
		'menu_name'             => _x( 'Sentieri', 'Admin Menu text', 'patriziatofrasco' ),
		'name_admin_bar'        => _x( 'Sentiero', 'Add New on Toolbar', 'patriziatofrasco' ),
		'add_new'               => __( 'Aggiungi Nuovo', 'patriziatofrasco' ),
		'add_new_item'          => __( 'Aggiungi Nuovo Sentiero', 'patriziatofrasco' ),
		'new_item'              => __( 'Nuovo Sentiero', 'patriziatofrasco' ),
		'edit_item'             => __( 'Modifica Sentiero', 'patriziatofrasco' ),
		'view_item'             => __( 'Guarda Sentiero', 'patriziatofrasco' ),
		'all_items'             => __( 'Tutti i Sentieri', 'patriziatofrasco' ),
		'search_items'          => __( 'Cerca Sentieri', 'patriziatofrasco' ),
		'not_found'             => __( 'Nessun sentiero trovato.', 'patriziatofrasco' ),
		'not_found_in_trash'    => __( 'Nessun sentiero nel cestino.', 'patriziatofrasco' ),
	);

	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'sentiero' ),
		'capability_type'    => 'post',
		'has_archive'        => false, 
		'hierarchical'       => false,
		'menu_position'      => 5.51,
		'menu_icon'          => 'dashicons-location-alt', // Icona mappa per i sentieri
		'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
		'show_in_rest'       => true,
	);

	register_post_type( 'sentiero', $args );
}
add_action( 'init', 'patriziatofrasco_register_sentieri_cpt' );

/**
 * Anteprima immagine nella lista di amministrazione - Capanne
 */
add_filter( 'manage_capanna_posts_columns', 'patriziatofrasco_sentiero_columns' );
function patriziatofrasco_sentiero_columns( $columns ) {
    $new_columns = array();
    foreach ( $columns as $key => $value ) {
        if ( $key == 'title' ) {
            $new_columns['featured_image'] = __( 'Copertina', 'patriziatofrasco' );
        }
        $new_columns[$key] = $value;
    }
    return $new_columns;
}

add_action( 'manage_capanna_posts_custom_column', 'patriziatofrasco_sentiero_custom_column', 10, 2 );
function patriziatofrasco_sentiero_custom_column( $column, $post_id ) {
    if ( $column == 'featured_image' ) {
        if ( has_post_thumbnail( $post_id ) ) {
            echo get_the_post_thumbnail( $post_id, array( 60, 60 ), array('style' => 'border-radius:4px; object-fit:cover;') );
        } else {
            echo '<span style="color:#999;">- Nessuna -</span>';
        }
    }
}

/**
 * Anteprima immagine nella lista di amministrazione - Sentieri
 */
add_filter( 'manage_sentiero_posts_columns', 'patriziatofrasco_sentiero_new_columns' );
function patriziatofrasco_sentiero_new_columns( $columns ) {
    $new_columns = array();
    foreach ( $columns as $key => $value ) {
        if ( $key == 'title' ) {
            $new_columns['featured_image'] = __( 'Copertina', 'patriziatofrasco' );
        }
        $new_columns[$key] = $value;
    }
    return $new_columns;
}

add_action( 'manage_sentiero_posts_custom_column', 'patriziatofrasco_sentiero_new_custom_column', 10, 2 );
function patriziatofrasco_sentiero_new_custom_column( $column, $post_id ) {
    if ( $column == 'featured_image' ) {
        if ( has_post_thumbnail( $post_id ) ) {
            echo get_the_post_thumbnail( $post_id, array( 60, 60 ), array('style' => 'border-radius:4px; object-fit:cover;') );
        } else {
            echo '<span style="color:#999;">- Nessuna -</span>';
        }
    }
}

add_action('admin_head', 'patriziatofrasco_sentiero_admin_css');
function patriziatofrasco_sentiero_admin_css() {
    echo '<style>
        .column-featured_image { width: 80px !important; }
    </style>';
}

/**
 * Registrazione Meta Box - Capanne
 */
function patriziatofrasco_add_sentieri_metaboxes() {
	add_meta_box(
		'patriziatofrasco_sentieri_dettagli',
		'Impostazioni Avanzate (Sidebar e Testata)',
		'patriziatofrasco_sentieri_dettagli_callback',
		'capanna',
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'patriziatofrasco_add_sentieri_metaboxes' );

function patriziatofrasco_sentieri_dettagli_callback( $post ) {
	wp_nonce_field( 'patriziatofrasco_save_sentieri_data', 'patriziatofrasco_sentieri_meta_nonce' );

	$subtitle = get_post_meta( $post->ID, '_sentiero_subtitle', true );
	$booking_url = get_post_meta( $post->ID, '_sentiero_booking_url', true );
	$booking_text = get_post_meta( $post->ID, '_sentiero_booking_text', true );
	$maps_query = get_post_meta( $post->ID, '_sentiero_maps_query', true );
	
	if(empty($booking_text)) $booking_text = 'Prenota Online';
	?>
	<div style="background: #f9f9f9; padding: 15px; border: 1px solid #ddd; margin-bottom: 20px;">
        <h4 style="margin-top:0;">Testata Principale</h4>
        <p>
            <label for="sentiero_subtitle"><strong>Sottotitolo (sotto il titolo principale)</strong></label><br>
            <input type="text" id="sentiero_subtitle" name="sentiero_subtitle" value="<?php echo esc_attr( $subtitle ); ?>" style="width:100%; max-width:600px;" />
            <br><small>Es: "1941 m s/m - Valle Verzasca, Monti di Frasco"</small>
        </p>
    </div>

    <div style="background: #f9f9f9; padding: 15px; border: 1px solid #ddd; margin-bottom: 20px;">
        <h4 style="margin-top:0;">Barra Laterale - Prenotazione e Mappa</h4>
        <p>
            <label for="sentiero_booking_url"><strong>Link Prenotazione</strong></label><br>
            <input type="url" id="sentiero_booking_url" name="sentiero_booking_url" value="<?php echo esc_url( $booking_url ); ?>" style="width:100%; max-width:600px;" />
            <br><small>Se vuoto, il blocco prenotazione non verrà mostrato.</small>
        </p>
        <p>
            <label for="sentiero_booking_text"><strong>Testo Bottone Prenotazione</strong></label><br>
            <input type="text" id="sentiero_booking_text" name="sentiero_booking_text" value="<?php echo esc_attr( $booking_text ); ?>" style="width:100%; max-width:600px;" />
        </p>
        <p>
            <label for="sentiero_maps_query"><strong>Query Google Maps (iframe)</strong></label><br>
            <input type="text" id="sentiero_maps_query" name="sentiero_maps_query" value="<?php echo esc_attr( $maps_query ); ?>" style="width:100%; max-width:600px;" />
            <br><small>Es: "Rifugio Alpe Costa Frasco" o "Capanna Efra"</small>
        </p>
    </div>

    <div style="background: #f9f9f9; padding: 15px; border: 1px solid #ddd;">
        <h4 style="margin-top:0;">Barra Laterale - Dettagli Tecnici</h4>
        <p><small>Lascia vuote le righe che non ti servono. Puoi usare codice HTML nei valori (es. per colori o badge).</small></p>
        <table class="form-table" style="background:#fff; border:1px solid #eee; padding:10px;">
            <thead>
                <tr>
                    <th style="width:30%;">Etichetta (es. Altitudine)</th>
                    <th>Valore (es. 2.039 m)</th>
                </tr>
            </thead>
            <tbody>
                <?php for($i=1; $i<=10; $i++): 
                    $lbl = get_post_meta( $post->ID, '_sentiero_tech_label_'.$i, true );
                    $val = get_post_meta( $post->ID, '_sentiero_tech_value_'.$i, true );
                ?>
                <tr>
                    <td><input type="text" name="sentiero_tech_label_<?php echo $i; ?>" value="<?php echo esc_attr($lbl); ?>" style="width:100%;" placeholder="Etichetta <?php echo $i; ?>"></td>
                    <td><input type="text" name="sentiero_tech_value_<?php echo $i; ?>" value="<?php echo esc_attr($val); ?>" style="width:100%;" placeholder="Valore <?php echo $i; ?>"></td>
                </tr>
                <?php endfor; ?>
            </tbody>
        </table>
    </div>
	<?php
}

function patriziatofrasco_save_sentieri_meta( $post_id ) {
	if ( ! isset( $_POST['patriziatofrasco_sentieri_meta_nonce'] ) ) return;
	if ( ! wp_verify_nonce( $_POST['patriziatofrasco_sentieri_meta_nonce'], 'patriziatofrasco_save_sentieri_data' ) ) return;
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
	if ( ! current_user_can( 'edit_post', $post_id ) ) return;

	$fields = ['sentiero_subtitle', 'sentiero_booking_url', 'sentiero_booking_text', 'sentiero_maps_query'];
    foreach($fields as $f) {
        if ( isset( $_POST[$f] ) ) {
            update_post_meta( $post_id, '_'.$f, sanitize_text_field( $_POST[$f] ) );
        }
    }

    for($i=1; $i<=10; $i++) {
        if(isset($_POST["sentiero_tech_label_$i"])) {
            update_post_meta($post_id, "_sentiero_tech_label_$i", sanitize_text_field($_POST["sentiero_tech_label_$i"]));
        }
        if(isset($_POST["sentiero_tech_value_$i"])) {
            update_post_meta($post_id, "_sentiero_tech_value_$i", wp_kses_post($_POST["sentiero_tech_value_$i"]));
        }
    }
}
add_action( 'save_post_capanna', 'patriziatofrasco_save_sentieri_meta' );

/**
 * Registrazione Meta Box - Sentieri (Percorsi)
 */
function patriziatofrasco_add_sentieri_new_metaboxes() {
	add_meta_box(
		'patriziatofrasco_sentieri_new_dettagli',
		'Impostazioni Avanzate (Sidebar e Testata)',
		'patriziatofrasco_sentieri_new_dettagli_callback',
		'sentiero',
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'patriziatofrasco_add_sentieri_new_metaboxes' );

function patriziatofrasco_sentieri_new_dettagli_callback( $post ) {
	wp_nonce_field( 'patriziatofrasco_save_sentieri_new_data', 'patriziatofrasco_sentieri_new_meta_nonce' );

	$subtitle = get_post_meta( $post->ID, '_sentiero_subtitle', true );
	$action_url = get_post_meta( $post->ID, '_sentiero_action_url', true );
	$action_text = get_post_meta( $post->ID, '_sentiero_action_text', true );
	$maps_query = get_post_meta( $post->ID, '_sentiero_maps_query', true );
	
	if(empty($action_text)) $action_text = 'Vedi su mappa';
	?>
	<div style="background: #f9f9f9; padding: 15px; border: 1px solid #ddd; margin-bottom: 20px;">
        <h4 style="margin-top:0;">Testata Principale</h4>
        <p>
            <label for="sentiero_subtitle"><strong>Sottotitolo (sotto il titolo principale)</strong></label><br>
            <input type="text" id="sentiero_subtitle" name="sentiero_subtitle" value="<?php echo esc_attr( $subtitle ); ?>" style="width:100%; max-width:600px;" />
            <br><small>Es: "Da Frasco all'Alpe Costa - 3h 30min"</small>
        </p>
    </div>

    <div style="background: #f9f9f9; padding: 15px; border: 1px solid #ddd; margin-bottom: 20px;">
        <h4 style="margin-top:0;">Barra Laterale - Link e Mappa</h4>
        <p>
            <label for="sentiero_action_url"><strong>Link Bottone</strong></label><br>
            <input type="text" id="sentiero_action_url" name="sentiero_action_url" value="<?php echo esc_attr( $action_url ); ?>" style="width:100%; max-width:600px;" />
            <br><small>URL, telefono (<code>tel:+41...</code>) o email (<code>mailto:info@...</code>).</small>
        </p>
        <p>
            <label for="sentiero_action_text"><strong>Testo Bottone</strong></label><br>
            <input type="text" id="sentiero_action_text" name="sentiero_action_text" value="<?php echo esc_attr( $action_text ); ?>" style="width:100%; max-width:600px;" />
        </p>
        <p>
            <label for="sentiero_maps_query"><strong>Query Google Maps (iframe)</strong></label><br>
            <input type="text" id="sentiero_maps_query" name="sentiero_maps_query" value="<?php echo esc_attr( $maps_query ); ?>" style="width:100%; max-width:600px;" />
            <br><small>Es: "Sentiero Frasco Alpe Costa"</small>
        </p>
    </div>

    <div style="background: #f9f9f9; padding: 15px; border: 1px solid #ddd;">
        <h4 style="margin-top:0;">Barra Laterale - Dettagli Tecnici</h4>
        <p><small>Lascia vuote le righe che non ti servono. Puoi usare codice HTML nei valori.</small></p>
        <table class="form-table" style="background:#fff; border:1px solid #eee; padding:10px;">
            <thead>
                <tr>
                    <th style="width:30%;">Etichetta (es. Durata)</th>
                    <th>Valore (es. 3h 30min)</th>
                </tr>
            </thead>
            <tbody>
                <?php for($i=1; $i<=10; $i++): 
                    $lbl = get_post_meta( $post->ID, '_sentiero_tech_label_'.$i, true );
                    $val = get_post_meta( $post->ID, '_sentiero_tech_value_'.$i, true );
                ?>
                <tr>
                    <td><input type="text" name="sentiero_tech_label_<?php echo $i; ?>" value="<?php echo esc_attr($lbl); ?>" style="width:100%;" placeholder="Etichetta <?php echo $i; ?>"></td>
                    <td><input type="text" name="sentiero_tech_value_<?php echo $i; ?>" value="<?php echo esc_attr($val); ?>" style="width:100%;" placeholder="Valore <?php echo $i; ?>"></td>
                </tr>
                <?php endfor; ?>
            </tbody>
        </table>
    </div>
	<?php
}

function patriziatofrasco_save_sentieri_new_meta( $post_id ) {
	if ( ! isset( $_POST['patriziatofrasco_sentieri_new_meta_nonce'] ) ) return;
	if ( ! wp_verify_nonce( $_POST['patriziatofrasco_sentieri_new_meta_nonce'], 'patriziatofrasco_save_sentieri_new_data' ) ) return;
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
	if ( ! current_user_can( 'edit_post', $post_id ) ) return;

	$fields = ['sentiero_subtitle', 'sentiero_action_url', 'sentiero_action_text', 'sentiero_maps_query'];
    foreach($fields as $f) {
        if ( isset( $_POST[$f] ) ) {
            update_post_meta( $post_id, '_'.$f, sanitize_text_field( $_POST[$f] ) );
        }
    }

    for($i=1; $i<=10; $i++) {
        if(isset($_POST["sentiero_tech_label_$i"])) {
            update_post_meta($post_id, "_sentiero_tech_label_$i", sanitize_text_field($_POST["sentiero_tech_label_$i"]));
        }
        if(isset($_POST["sentiero_tech_value_$i"])) {
            update_post_meta($post_id, "_sentiero_tech_value_$i", wp_kses_post($_POST["sentiero_tech_value_$i"]));
        }
    }
}
add_action( 'save_post_sentiero', 'patriziatofrasco_save_sentieri_new_meta' );
