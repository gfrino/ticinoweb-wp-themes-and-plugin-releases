<?php
/**
 * Registrazione Custom Post Type per le Mozioni
 */

// 1. Registra il Custom Post Type
function patriziatofrasco_register_mozioni_cpt() {
    $labels = array(
        'name'                  => _x( 'Mozioni', 'Post type general name', 'patriziatofrasco' ),
        'singular_name'         => _x( 'Mozione', 'Post type singular name', 'patriziatofrasco' ),
        'menu_name'             => _x( 'Mozioni', 'Admin Menu text', 'patriziatofrasco' ),
        'name_admin_bar'        => _x( 'Mozione', 'Add New on Toolbar', 'patriziatofrasco' ),
        'add_new'               => __( 'Aggiungi Nuova', 'patriziatofrasco' ),
        'add_new_item'          => __( 'Aggiungi Nuova Mozione', 'patriziatofrasco' ),
        'new_item'              => __( 'Nuova Mozione', 'patriziatofrasco' ),
        'edit_item'             => __( 'Modifica Mozione', 'patriziatofrasco' ),
        'view_item'             => __( 'Visualizza Mozione', 'patriziatofrasco' ),
        'all_items'             => __( 'Tutte le Mozioni', 'patriziatofrasco' ),
        'search_items'          => __( 'Cerca Mozioni', 'patriziatofrasco' ),
        'parent_item_colon'     => __( 'Mozioni Genitore:', 'patriziatofrasco' ),
        'not_found'             => __( 'Nessuna mozione trovata.', 'patriziatofrasco' ),
        'not_found_in_trash'    => __( 'Nessuna mozione trovata nel cestino.', 'patriziatofrasco' ),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'mozione' ),
        'capability_type'    => 'post',
        'has_archive'        => false,
        'hierarchical'       => false,
        'menu_position'      => 5.2, // 2° posizione custom
        'menu_icon'          => 'dashicons-media-document', // Icona documento
        'supports'           => array( 'title', 'excerpt' ), // Titolo e breve descrizione
        'show_in_rest'       => true, // Supporto per Gutenberg
    );

    register_post_type( 'mozione', $args );
}
add_action( 'init', 'patriziatofrasco_register_mozioni_cpt' );

// 2. Aggiunge i Meta Box personalizzati
function patriziatofrasco_add_mozioni_metaboxes() {
    add_meta_box(
        'mozioni_meta_box', // ID
        'Dettagli Mozione', // Titolo
        'patriziatofrasco_mozioni_metabox_callback', // Callback
        'mozione', // Post Type
        'normal', // Contesto
        'high' // Priorità
    );
}
add_action( 'add_meta_boxes', 'patriziatofrasco_add_mozioni_metaboxes' );

// 3. Costruisce l'HTML per il Meta Box
function patriziatofrasco_mozioni_metabox_callback( $post ) {
    // Aggiungi un nonce field per la sicurezza
    wp_nonce_field( 'mozioni_save_meta_box_data', 'mozioni_meta_box_nonce' );

    // Recupera i valori attuali
    $data_presentazione = get_post_meta( $post->ID, '_mozione_data', true );
    $proponente = get_post_meta( $post->ID, '_mozione_proponente', true );
    $stato = get_post_meta( $post->ID, '_mozione_stato', true );
    $pdf_id = get_post_meta( $post->ID, '_mozione_pdf_id', true );
    $pdf_url = $pdf_id ? wp_get_attachment_url( $pdf_id ) : '';

    // HTML del Form
    echo '<style>
        .mozione-field-row { margin-bottom: 15px; }
        .mozione-field-row label { display: block; font-weight: bold; margin-bottom: 5px; }
        .mozione-field-row input[type="text"], .mozione-field-row input[type="date"], .mozione-field-row select { width: 100%; max-width: 400px; padding: 5px; }
        .mozione-pdf-preview { margin-top: 10px; display: block; }
    </style>';

    // Data di presentazione
    echo '<div class="mozione-field-row">';
    echo '<label for="mozione_data">Data di presentazione</label>';
    echo '<input type="date" id="mozione_data" name="mozione_data" value="' . esc_attr( $data_presentazione ) . '" />';
    echo '</div>';

    // Proponente
    echo '<div class="mozione-field-row">';
    echo '<label for="mozione_proponente">Proponente (Facoltativo)</label>';
    echo '<input type="text" id="mozione_proponente" name="mozione_proponente" value="' . esc_attr( $proponente ) . '" placeholder="Es. Mario Rossi" />';
    echo '</div>';

    // Stato della mozione
    echo '<div class="mozione-field-row">';
    echo '<label for="mozione_stato">Stato della mozione</label>';
    echo '<select id="mozione_stato" name="mozione_stato">';
    echo '<option value="In esame" ' . selected( $stato, 'In esame', false ) . '>In esame</option>';
    echo '<option value="Accolta" ' . selected( $stato, 'Accolta', false ) . '>Accolta</option>';
    echo '<option value="Respinta" ' . selected( $stato, 'Respinta', false ) . '>Respinta</option>';
    echo '<option value="Ritirata" ' . selected( $stato, 'Ritirata', false ) . '>Ritirata</option>';
    echo '</select>';
    echo '</div>';

    // Allegato PDF
    echo '<div class="mozione-field-row">';
    echo '<label>Allegato PDF</label>';
    echo '<input type="hidden" id="mozione_pdf_id" name="mozione_pdf_id" value="' . esc_attr( $pdf_id ) . '" />';
    echo '<button type="button" class="button button-secondary" id="mozione_upload_pdf_btn">Seleziona o carica PDF</button>';
    echo '<button type="button" class="button button-link-delete" id="mozione_remove_pdf_btn" style="' . ( $pdf_id ? '' : 'display:none;' ) . '">Rimuovi PDF</button>';
    echo '<span class="mozione-pdf-preview" id="mozione_pdf_preview">';
    if ( $pdf_url ) {
        echo '<a href="' . esc_url( $pdf_url ) . '" target="_blank">Vedi PDF attuale (' . esc_html( basename( $pdf_url ) ) . ')</a>';
    }
    echo '</span>';
    echo '</div>';

    // Script per il media uploader di WordPress
    ?>
    <script>
    jQuery(document).ready(function($){
        var mediaUploader;
        $('#mozione_upload_pdf_btn').click(function(e) {
            e.preventDefault();
            if (mediaUploader) {
                mediaUploader.open();
                return;
            }
            mediaUploader = wp.media.frames.file_frame = wp.media({
                title: 'Seleziona Allegato PDF',
                button: { text: 'Usa questo file' },
                multiple: false,
                library: { type: 'application/pdf' }
            });
            mediaUploader.on('select', function() {
                var attachment = mediaUploader.state().get('selection').first().toJSON();
                $('#mozione_pdf_id').val(attachment.id);
                $('#mozione_pdf_preview').html('<a href="' + attachment.url + '" target="_blank">Vedi PDF attuale (' + attachment.filename + ')</a>');
                $('#mozione_remove_pdf_btn').show();
            });
            mediaUploader.open();
        });

        $('#mozione_remove_pdf_btn').click(function(e){
            e.preventDefault();
            $('#mozione_pdf_id').val('');
            $('#mozione_pdf_preview').html('');
            $(this).hide();
        });
    });
    </script>
    <?php
}

// 4. Salva i dati dei Meta Box
function patriziatofrasco_save_mozioni_meta_box_data( $post_id ) {
    // Controlla il nonce
    if ( ! isset( $_POST['mozioni_meta_box_nonce'] ) ) {
        return;
    }
    if ( ! wp_verify_nonce( $_POST['mozioni_meta_box_nonce'], 'mozioni_save_meta_box_data' ) ) {
        return;
    }
    // Evita l'autosave
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    // Controlla i permessi
    if ( isset( $_POST['post_type'] ) && 'mozione' == $_POST['post_type'] ) {
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }
    }

    // Salva "Data di presentazione"
    if ( isset( $_POST['mozione_data'] ) ) {
        update_post_meta( $post_id, '_mozione_data', sanitize_text_field( $_POST['mozione_data'] ) );
    }

    // Salva "Proponente"
    if ( isset( $_POST['mozione_proponente'] ) ) {
        update_post_meta( $post_id, '_mozione_proponente', sanitize_text_field( $_POST['mozione_proponente'] ) );
    }

    // Salva "Stato"
    if ( isset( $_POST['mozione_stato'] ) ) {
        update_post_meta( $post_id, '_mozione_stato', sanitize_text_field( $_POST['mozione_stato'] ) );
    }

    // Salva "Allegato PDF"
    if ( isset( $_POST['mozione_pdf_id'] ) ) {
        update_post_meta( $post_id, '_mozione_pdf_id', sanitize_text_field( $_POST['mozione_pdf_id'] ) );
    }
}
add_action( 'save_post', 'patriziatofrasco_save_mozioni_meta_box_data' );

// 5. Aggiungi il supporto per il media uploader nello script di admin
function patriziatofrasco_enqueue_mozioni_admin_scripts( $hook ) {
    global $post;
    if ( $hook == 'post-new.php' || $hook == 'post.php' ) {
        if ( 'mozione' === $post->post_type ) {
            wp_enqueue_media();
        }
    }
}
add_action( 'admin_enqueue_scripts', 'patriziatofrasco_enqueue_mozioni_admin_scripts' );
