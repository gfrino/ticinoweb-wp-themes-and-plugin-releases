<?php
/**
 * Registrazione Custom Post Type per le Attività
 */

// 1. Registra il Custom Post Type
function patriziatofrasco_register_attivita_cpt() {
    $labels = array(
        'name'                  => _x( 'Attività', 'Post type general name', 'patriziatofrasco' ),
        'singular_name'         => _x( 'Attività', 'Post type singular name', 'patriziatofrasco' ),
        'menu_name'             => _x( 'Attività', 'Admin Menu text', 'patriziatofrasco' ),
        'name_admin_bar'        => _x( 'Attività', 'Add New on Toolbar', 'patriziatofrasco' ),
        'add_new'               => __( 'Aggiungi Nuova', 'patriziatofrasco' ),
        'add_new_item'          => __( 'Aggiungi Nuova Attività', 'patriziatofrasco' ),
        'new_item'              => __( 'Nuova Attività', 'patriziatofrasco' ),
        'edit_item'             => __( 'Modifica Attività', 'patriziatofrasco' ),
        'view_item'             => __( 'Visualizza Attività', 'patriziatofrasco' ),
        'all_items'             => __( 'Tutte le Attività', 'patriziatofrasco' ),
        'search_items'          => __( 'Cerca Attività', 'patriziatofrasco' ),
        'parent_item_colon'     => __( 'Attività Genitore:', 'patriziatofrasco' ),
        'not_found'             => __( 'Nessuna attività trovata.', 'patriziatofrasco' ),
        'not_found_in_trash'    => __( 'Nessuna attività trovata nel cestino.', 'patriziatofrasco' ),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'attivita' ),
        'capability_type'    => 'post',
        'has_archive'        => false,
        'hierarchical'       => false,
        'menu_position'      => 5.4, // 4° posizione custom
        'menu_icon'          => 'dashicons-calendar-alt', // Icona calendario
        'supports'           => array( 'title', 'excerpt', 'thumbnail' ), // Titolo, breve descrizione, immagine principale
        'show_in_rest'       => true, // Supporto per Gutenberg
    );

    register_post_type( 'attivita', $args );
}
add_action( 'init', 'patriziatofrasco_register_attivita_cpt' );

// 2. Aggiunge i Meta Box personalizzati
function patriziatofrasco_add_attivita_metaboxes() {
    add_meta_box(
        'attivita_meta_box', // ID
        'Dettagli Attività', // Titolo
        'patriziatofrasco_attivita_metabox_callback', // Callback
        'attivita', // Post Type
        'normal', // Contesto
        'high' // Priorità
    );
}
add_action( 'add_meta_boxes', 'patriziatofrasco_add_attivita_metaboxes' );

// 3. Costruisce l'HTML per il Meta Box
function patriziatofrasco_attivita_metabox_callback( $post ) {
    wp_nonce_field( 'attivita_save_meta_box_data', 'attivita_meta_box_nonce' );

    // Recupera i valori attuali
    $tipologia = get_post_meta( $post->ID, '_attivita_tipologia', true );
    $data = get_post_meta( $post->ID, '_attivita_data', true );
    $ora_inizio = get_post_meta( $post->ID, '_attivita_ora_inizio', true );
    $ora_fine = get_post_meta( $post->ID, '_attivita_ora_fine', true );
    $luogo = get_post_meta( $post->ID, '_attivita_luogo', true );
    $stato = get_post_meta( $post->ID, '_attivita_stato', true );
    $pdf_id = get_post_meta( $post->ID, '_attivita_pdf_id', true );
    $pdf_url = $pdf_id ? wp_get_attachment_url( $pdf_id ) : '';

    // HTML del Form
    echo '<style>
        .attivita-field-row { margin-bottom: 15px; }
        .attivita-field-row label { display: block; font-weight: bold; margin-bottom: 5px; }
        .attivita-field-row input[type="text"], .attivita-field-row input[type="date"], .attivita-field-row input[type="time"], .attivita-field-row select { width: 100%; max-width: 400px; padding: 5px; }
        .attivita-pdf-preview { margin-top: 10px; display: block; }
        .attivita-time-group { display: flex; gap: 15px; max-width: 400px; }
        .attivita-time-group div { flex: 1; }
    </style>';

    // Tipologia
    $tipologie_opzioni = array('Pranzo', 'Festa', 'Giornata di pulizia', 'Conferenza', 'Escursione', 'Assemblea', 'Altro');
    echo '<div class="attivita-field-row">';
    echo '<label for="attivita_tipologia">Tipologia attività</label>';
    echo '<select id="attivita_tipologia" name="attivita_tipologia">';
    echo '<option value="">-- Seleziona una tipologia --</option>';
    foreach ($tipologie_opzioni as $opzione) {
        echo '<option value="' . esc_attr($opzione) . '" ' . selected( $tipologia, $opzione, false ) . '>' . esc_html($opzione) . '</option>';
    }
    echo '</select>';
    echo '</div>';

    // Data
    echo '<div class="attivita-field-row">';
    echo '<label for="attivita_data">Data attività</label>';
    echo '<input type="date" id="attivita_data" name="attivita_data" value="' . esc_attr( $data ) . '" />';
    echo '</div>';

    // Ora Inizio e Ora Fine
    echo '<div class="attivita-field-row attivita-time-group">';
    echo '<div>';
    echo '<label for="attivita_ora_inizio">Ora di inizio</label>';
    echo '<input type="time" id="attivita_ora_inizio" name="attivita_ora_inizio" value="' . esc_attr( $ora_inizio ) . '" />';
    echo '</div>';
    echo '<div>';
    echo '<label for="attivita_ora_fine">Ora di fine (Facoltativa)</label>';
    echo '<input type="time" id="attivita_ora_fine" name="attivita_ora_fine" value="' . esc_attr( $ora_fine ) . '" />';
    echo '</div>';
    echo '</div>';

    // Luogo
    echo '<div class="attivita-field-row">';
    echo '<label for="attivita_luogo">Luogo</label>';
    echo '<input type="text" id="attivita_luogo" name="attivita_luogo" value="' . esc_attr( $luogo ) . '" placeholder="Es. Rifugio Alpe Costa" />';
    echo '</div>';

    // Stato
    echo '<div class="attivita-field-row">';
    echo '<label for="attivita_stato">Stato attività</label>';
    echo '<select id="attivita_stato" name="attivita_stato">';
    echo '<option value="Programmata" ' . selected( $stato, 'Programmata', false ) . '>Programmata</option>';
    echo '<option value="Conclusa" ' . selected( $stato, 'Conclusa', false ) . '>Conclusa</option>';
    echo '<option value="Annullata" ' . selected( $stato, 'Annullata', false ) . '>Annullata</option>';
    echo '</select>';
    echo '</div>';

    // Allegato PDF
    echo '<div class="attivita-field-row">';
    echo '<label>Allegato PDF / Programma (Facoltativo)</label>';
    echo '<input type="hidden" id="attivita_pdf_id" name="attivita_pdf_id" value="' . esc_attr( $pdf_id ) . '" />';
    echo '<button type="button" class="button button-secondary" id="attivita_upload_pdf_btn">Seleziona o carica PDF</button>';
    echo '<button type="button" class="button button-link-delete" id="attivita_remove_pdf_btn" style="' . ( $pdf_id ? '' : 'display:none;' ) . '">Rimuovi PDF</button>';
    echo '<span class="attivita-pdf-preview" id="attivita_pdf_preview">';
    if ( $pdf_url ) {
        echo '<a href="' . esc_url( $pdf_url ) . '" target="_blank">Vedi PDF attuale (' . esc_html( basename( $pdf_url ) ) . ')</a>';
    }
    echo '</span>';
    echo '</div>';

    // Script per il media uploader
    ?>
    <script>
    jQuery(document).ready(function($){
        var mediaUploader;
        $('#attivita_upload_pdf_btn').click(function(e) {
            e.preventDefault();
            if (mediaUploader) {
                mediaUploader.open();
                return;
            }
            mediaUploader = wp.media.frames.file_frame = wp.media({
                title: 'Seleziona Allegato PDF',
                button: { text: 'Usa questo file' },
                multiple: false,
                library: { type: 'application/pdf' }
            });
            mediaUploader.on('select', function() {
                var attachment = mediaUploader.state().get('selection').first().toJSON();
                $('#attivita_pdf_id').val(attachment.id);
                $('#attivita_pdf_preview').html('<a href="' + attachment.url + '" target="_blank">Vedi PDF attuale (' + attachment.filename + ')</a>');
                $('#attivita_remove_pdf_btn').show();
            });
            mediaUploader.open();
        });

        $('#attivita_remove_pdf_btn').click(function(e){
            e.preventDefault();
            $('#attivita_pdf_id').val('');
            $('#attivita_pdf_preview').html('');
            $(this).hide();
        });
    });
    </script>
    <?php
}

// 4. Salva i dati dei Meta Box
function patriziatofrasco_save_attivita_meta_box_data( $post_id ) {
    if ( ! isset( $_POST['attivita_meta_box_nonce'] ) ) return;
    if ( ! wp_verify_nonce( $_POST['attivita_meta_box_nonce'], 'attivita_save_meta_box_data' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( isset( $_POST['post_type'] ) && 'attivita' == $_POST['post_type'] ) {
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;
    }

    $fields = array(
        '_attivita_tipologia'  => 'attivita_tipologia',
        '_attivita_data'       => 'attivita_data',
        '_attivita_ora_inizio' => 'attivita_ora_inizio',
        '_attivita_ora_fine'   => 'attivita_ora_fine',
        '_attivita_luogo'      => 'attivita_luogo',
        '_attivita_stato'      => 'attivita_stato',
        '_attivita_pdf_id'     => 'attivita_pdf_id'
    );

    foreach ($fields as $meta_key => $post_field) {
        if ( isset( $_POST[$post_field] ) ) {
            update_post_meta( $post_id, $meta_key, sanitize_text_field( $_POST[$post_field] ) );
        }
    }
}
add_action( 'save_post', 'patriziatofrasco_save_attivita_meta_box_data' );

// 5. Supporto media uploader in admin
function patriziatofrasco_enqueue_attivita_admin_scripts( $hook ) {
    global $post;
    if ( $hook == 'post-new.php' || $hook == 'post.php' ) {
        if ( 'attivita' === $post->post_type ) {
            wp_enqueue_media();
        }
    }
}
add_action( 'admin_enqueue_scripts', 'patriziatofrasco_enqueue_attivita_admin_scripts' );
