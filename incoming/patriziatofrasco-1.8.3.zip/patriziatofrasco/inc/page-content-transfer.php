<?php
/**
 * Trasferimento manuale dei contenuti pagina tra installazioni WordPress.
 *
 * @package Patriziato_Frasco
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pagine editoriali il cui contenuto viene stampato dai template del tema.
 *
 * @return array<string, string>
 */
function patriziatofrasco_transferable_pages() {
	return array(
		'organizzazione'                => 'Organizzazione',
		'chi-siamo'                     => 'Chi siamo',
		'famiglie-patrizie'             => 'Famiglie patrizie',
		'patriziato'                    => 'Patriziato',
		'territorio'                    => 'Territorio',
		'contatti-ufficio-patriziale'   => 'Contatti Ufficio Patriziale',
	);
}

/**
 * Tipi di contenuto trasferiti insieme alle pagine.
 *
 * @return string[]
 */
function patriziatofrasco_transferable_post_types() {
	return array( 'sentiero', 'capanna', 'punto_interesse', 'pubblicazione', 'ufficio' );
}

/**
 * Prefissi dei campi personalizzati da portare con i contenuti.
 *
 * @return string[]
 */
function patriziatofrasco_transferable_meta_prefixes() {
	return array( '_sentiero_', '_interesse_', '_pub_', '_ufficio_' );
}

/**
 * Opzioni del sito gestite dal tema, da trasferire insieme ai contenuti.
 *
 * @return string[]
 */
function patriziatofrasco_transferable_options() {
	return array(
		'ticinoweb_contact_phone',
		'ticinoweb_contact_email',
		'ticinoweb_contact_address',
		'ptf_hide_formulari',
	);
}

/**
 * Campi didascalia degli allegati (Luogo, Data, Didascalia).
 *
 * @return string[]
 */
function patriziatofrasco_transferable_media_meta() {
	return array( '_ptf_media_luogo', '_ptf_media_data', '_ptf_media_didascalia', '_wp_attachment_image_alt' );
}

/**
 * Registra la pagina amministrativa.
 */
function patriziatofrasco_content_transfer_menu() {
	add_management_page(
		'Trasferimento contenuti',
		'Trasferimento contenuti',
		'manage_options',
		'patriziatofrasco-content-transfer',
		'patriziatofrasco_content_transfer_screen'
	);
}
add_action( 'admin_menu', 'patriziatofrasco_content_transfer_menu' );

/**
 * Mostra lo strumento in Strumenti > Trasferimento contenuti.
 */
function patriziatofrasco_content_transfer_screen() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Non hai i permessi necessari.', 'patriziatofrasco' ) );
	}

	$notice   = isset( $_GET['pf_transfer_notice'] ) ? sanitize_key( wp_unslash( $_GET['pf_transfer_notice'] ) ) : '';
	$count    = isset( $_GET['pf_transfer_count'] ) ? absint( $_GET['pf_transfer_count'] ) : 0;
	$mancanti = isset( $_GET['pf_transfer_missing'] ) ? absint( $_GET['pf_transfer_missing'] ) : 0;
	?>
	<div class="wrap">
		<h1>Trasferimento contenuti del sito</h1>

		<?php if ( 'success' === $notice ) : ?>
			<div class="notice notice-success is-dismissible">
				<p><?php echo esc_html( sprintf( '%d contenuti importati o aggiornati correttamente.', $count ) ); ?></p>
				<?php if ( $mancanti ) : ?>
					<p><?php echo esc_html( sprintf( 'Attenzione: %d immagini richiamate dai contenuti non sono state trovate nella Libreria media di questo sito.', $mancanti ) ); ?>
					<strong>Trovi l’elenco dei nomi qui sotto</strong>: copialo, incollalo nel campo «Immagini da includere» sul sito di partenza e rifai esportazione e importazione.</p>
				<?php endif; ?>
			</div>
		<?php elseif ( 'error' === $notice ) : ?>
			<div class="notice notice-error is-dismissible">
				<p>Non è stato possibile importare il file.</p>
				<p>Le cause più frequenti sono due: il file <strong>supera il limite di caricamento di questo sito</strong>
				(<?php echo esc_html( size_format( wp_max_upload_size() ) ); ?>), oppure non è un pacchetto prodotto da questo strumento.</p>
				<p>Se hai spuntato «Includi anche i file delle immagini», il pacchetto diventa molto pesante: rifai
				l’esportazione <strong>senza</strong> quella casella, importa i contenuti, e poi usa l’elenco dei file
				mancanti che comparirà qui sotto per spedire solo le immagini che servono.</p>
			</div>
		<?php endif; ?>

		<p>Copia dal sito locale al server i contenuti gestiti dal tema, con le immagini e le loro didascalie. I contenuti vengono riconosciuti tramite slug: quelli già presenti vengono aggiornati, non duplicati.</p>
		<p><strong>Pagine incluse:</strong> <?php echo esc_html( implode( ', ', array_values( patriziatofrasco_transferable_pages() ) ) ); ?></p>
		<p><strong>Schede incluse:</strong> tutti i contenuti pubblicati di
			<?php
			$pf_etichette = array();
			foreach ( patriziatofrasco_transferable_post_types() as $pf_tipo ) {
				$pf_oggetto     = get_post_type_object( $pf_tipo );
				$pf_etichette[] = $pf_oggetto ? $pf_oggetto->label : $pf_tipo;
			}
			echo esc_html( implode( ', ', $pf_etichette ) );
			?>.
		</p>
		<p><strong>Incluso anche:</strong> le immagini con Luogo, Data e Didascalia e la galleria a cui appartengono; i recapiti del Patriziato; l'impostazione che nasconde la pagina Formulari.</p>
		<p><em>Non incluso:</em> Comunicati, Mozioni, Attività e Interpellanze, che si aggiornano direttamente dal pannello del server.</p>

		<div class="card" style="max-width: 760px; padding: 20px; margin-top: 24px;">
			<h2>1. Esporta dal sito locale</h2>
			<p>Scarica una copia JSON dei contenuti. Le immagini vengono riagganciate sul server confrontando il nome del file, quindi di norma <strong>non serve spedirle</strong>: il pacchetto resta di pochi MB.</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="patriziatofrasco_export_page_content">
				<?php wp_nonce_field( 'patriziatofrasco_export_page_content' ); ?>
				<p>
					<label for="pf_only_files"><strong>Immagini da includere</strong> (facoltativo, un nome file per riga)</label><br>
					<textarea id="pf_only_files" name="pf_only_files" rows="4" style="width:100%;max-width:640px;font-family:monospace;font-size:12px;" placeholder="cartina-cabioi-cognora.jpg&#10;mulino-efra-esterno.png"></textarea><br>
					<span class="description">Lascia vuoto per non spedire nessun file. Qui va incollato l’elenco che l’importazione segnala come mancante.</span>
				</p>
				<p>
					<label>
						<input type="checkbox" name="pf_include_files" value="1">
						Includi <em>tutti</em> i file delle immagini
					</label><br>
					<span class="description">Sconsigliato: il pacchetto arriva a decine di MB e supera il limite di caricamento
					(<?php echo esc_html( size_format( wp_max_upload_size() ) ); ?> su questo sito). Meglio usare l’elenco qui sopra.</span>
				</p>
				<?php submit_button( 'Scarica i contenuti', 'primary', 'submit', false ); ?>
			</form>
		</div>

		<?php $pf_mancanti = get_option( 'ptf_transfer_missing_files', array() ); ?>
		<?php if ( is_array( $pf_mancanti ) && $pf_mancanti ) : ?>
			<div class="card" style="max-width: 760px; padding: 20px; margin-top: 24px; border-left: 4px solid #d63638;">
				<h2>Immagini mancanti su questo sito</h2>
				<p>Queste immagini sono richiamate dai contenuti appena importati ma non sono nella Libreria media.
				Copia l’elenco, incollalo nel campo «Immagini da includere» sul sito di partenza e rifai l’esportazione.</p>
				<textarea rows="<?php echo esc_attr( min( 12, max( 3, count( $pf_mancanti ) ) ) ); ?>" style="width:100%;font-family:monospace;font-size:12px;" onclick="this.select();" readonly><?php echo esc_textarea( implode( "\n", $pf_mancanti ) ); ?></textarea>
			</div>
		<?php endif; ?>

		<div class="card" style="max-width: 760px; padding: 20px; margin-top: 24px;">
			<h2>2. Importa sul server</h2>
			<p>Le immagini vengono copiate nella Libreria media del server e i relativi URL vengono aggiornati. Prima di ogni modifica WordPress conserva una revisione della pagina esistente.</p>
			<form method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="patriziatofrasco_import_page_content">
				<?php wp_nonce_field( 'patriziatofrasco_import_page_content' ); ?>
				<input type="file" name="pf_page_content_file" accept="application/json,.json" required>
				<?php submit_button( 'Importa e aggiorna le pagine', 'primary', 'submit', false ); ?>
			</form>
		</div>
	</div>
	<?php
}

/**
 * Restituisce la pagina più recente associata allo slug.
 *
 * @param string $slug Slug pagina.
 * @return WP_Post|null
 */
function patriziatofrasco_get_page_for_transfer( $slug ) {
	$page = get_page_by_path( $slug, OBJECT, 'page' );
	return $page instanceof WP_Post ? $page : null;
}

/**
 * Campi personalizzati trasferibili per Sentieri e Capanne.
 *
 * @param int $post_id ID contenuto.
 * @return array<string, mixed>
 */
function patriziatofrasco_transferable_trail_meta( $post_id ) {
	$all       = get_post_meta( $post_id );
	$meta      = array();
	$prefissi  = patriziatofrasco_transferable_meta_prefixes();

	foreach ( $all as $key => $values ) {
		$ammesso = false;
		foreach ( $prefissi as $prefisso ) {
			if ( 0 === strpos( $key, $prefisso ) ) {
				$ammesso = true;
				break;
			}
		}
		if ( ! $ammesso ) {
			continue;
		}
		$meta[ $key ] = maybe_unserialize( $values[0] );
	}
	return $meta;
}

/**
 * Estrae dal markup tutti gli URL che puntano alla cartella uploads locale.
 *
 * @param string $content Contenuto HTML.
 * @return string[]
 */
function patriziatofrasco_extract_upload_urls( $content ) {
	$urls = array();
	if ( ! is_string( $content ) || '' === $content ) {
		return $urls;
	}

	preg_match_all(
		'~(?:https?:)?//[^\s\"\'()]+/wp-content/uploads/[^\s\"\'(),]+|/wp-content/uploads/[^\s\"\'(),]+~i',
		$content,
		$matches
	);

	foreach ( $matches[0] as $url ) {
		$url = html_entity_decode( $url, ENT_QUOTES, 'UTF-8' );
		$url = preg_replace( '/[?#].*$/', '', $url );
		if ( $url ) {
			$urls[] = $url;
		}
	}

	return array_values( array_unique( $urls ) );
}

/**
 * Converte un URL uploads nel percorso locale corrispondente.
 *
 * @param string $url URL immagine.
 * @return array|null
 */
function patriziatofrasco_upload_asset_from_url( $url ) {
	$path = wp_parse_url( $url, PHP_URL_PATH );
	if ( ! is_string( $path ) || false === strpos( $path, '/wp-content/uploads/' ) ) {
		return null;
	}

	$relative = ltrim( substr( $path, strpos( $path, '/wp-content/uploads/' ) + strlen( '/wp-content/uploads/' ) ), '/' );
	$file     = wp_normalize_path( WP_CONTENT_DIR . '/uploads/' . $relative );
	$root     = trailingslashit( wp_normalize_path( WP_CONTENT_DIR . '/uploads' ) );
	$real     = realpath( $file );

	if ( ! $real || 0 !== strpos( wp_normalize_path( $real ), $root ) || ! is_file( $real ) || ! is_readable( $real ) ) {
		return null;
	}

	$size = filesize( $real );
	if ( false === $size || $size > 10 * MB_IN_BYTES ) {
		return null;
	}

	$mime = wp_check_filetype( basename( $real ) );
	return array(
		'source'        => $url,
		'filename'      => basename( $real ),
		'relative_path' => $relative,
		'mime_type'     => $mime['type'] ? $mime['type'] : 'application/octet-stream',
		'sha256'        => hash_file( 'sha256', $real ),
		'data'          => base64_encode( file_get_contents( $real ) ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode,WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
	);
}

/**
 * Scarica il pacchetto JSON dei contenuti.
 */
function patriziatofrasco_export_page_content() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Non hai i permessi necessari.', 'patriziatofrasco' ) );
	}

	check_admin_referer( 'patriziatofrasco_export_page_content' );

	$pages      = array();
	$trail_posts = array();
	$asset_urls = array();
	foreach ( patriziatofrasco_transferable_pages() as $slug => $label ) {
		$page = patriziatofrasco_get_page_for_transfer( $slug );
		if ( ! $page ) {
			continue;
		}

		$pages[] = array(
			'slug'     => $slug,
			'title'    => $page->post_title,
			'content'  => $page->post_content,
			'excerpt'  => $page->post_excerpt,
			'template' => get_post_meta( $page->ID, '_wp_page_template', true ),
		);

		$asset_urls = array_merge(
			$asset_urls,
			patriziatofrasco_extract_upload_urls( $page->post_content ),
			patriziatofrasco_extract_upload_urls( $page->post_excerpt )
		);
	}

	$posts = get_posts(
		array(
			'post_type'      => patriziatofrasco_transferable_post_types(),
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'orderby'        => array( 'post_type' => 'ASC', 'menu_order' => 'ASC', 'ID' => 'ASC' ),
		)
	);

	foreach ( $posts as $post ) {
		$thumbnail_url = get_the_post_thumbnail_url( $post->ID, 'full' );
		$meta          = patriziatofrasco_transferable_trail_meta( $post->ID );
		$trail_posts[] = array(
			'post_type'        => $post->post_type,
			'slug'             => $post->post_name,
			'title'            => $post->post_title,
			'content'          => $post->post_content,
			'excerpt'          => $post->post_excerpt,
			'menu_order'       => (int) $post->menu_order,
			'meta'             => $meta,
			'thumbnail_source' => $thumbnail_url ? $thumbnail_url : '',
		);

		$asset_urls = array_merge(
			$asset_urls,
			patriziatofrasco_extract_upload_urls( $post->post_content ),
			patriziatofrasco_extract_upload_urls( $post->post_excerpt )
		);
		foreach ( $meta as $meta_value ) {
			if ( is_string( $meta_value ) ) {
				$asset_urls = array_merge( $asset_urls, patriziatofrasco_extract_upload_urls( $meta_value ) );
			}
		}
		if ( $thumbnail_url ) {
			$asset_urls[] = $thumbnail_url;
		}
	}

	// Didascalie delle foto di galleria: viaggiano SENZA il file, perché quelle
	// immagini sono già caricate sul sito di destinazione. Includerle come
	// binari faceva superare i 100 MB, rendendo il pacchetto inutilizzabile.
	// L'abbinamento avviene per nome del file.
	$media_captions = array();
	if ( taxonomy_exists( 'ticinoweb_media_gallery' ) ) {
		$galleria_ids = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'tax_query'      => array(
					array(
						'taxonomy' => 'ticinoweb_media_gallery',
						'operator' => 'EXISTS',
					),
				),
			)
		);

		foreach ( $galleria_ids as $galleria_id ) {
			$percorso = get_post_meta( $galleria_id, '_wp_attached_file', true );
			if ( ! $percorso ) {
				continue;
			}

			$voce = array( 'file' => basename( $percorso ) );

			foreach ( patriziatofrasco_transferable_media_meta() as $chiave ) {
				$valore = get_post_meta( $galleria_id, $chiave, true );
				if ( '' !== trim( (string) $valore ) ) {
					$voce[ $chiave ] = (string) $valore;
				}
			}

			$titolo = get_the_title( $galleria_id );
			if ( '' !== trim( (string) $titolo ) ) {
				$voce['titolo'] = $titolo;
			}

			$gallerie = wp_get_object_terms( $galleria_id, 'ticinoweb_media_gallery', array( 'fields' => 'names' ) );
			if ( ! is_wp_error( $gallerie ) && $gallerie ) {
				$voce['gallerie'] = $gallerie;
			}

			// Solo le foto che hanno davvero qualcosa da trasferire.
			if ( count( $voce ) > 1 ) {
				$media_captions[] = $voce;
			}
		}
	}

	// I file delle immagini pesano molto: si spediscono solo su richiesta.
	// Senza di essi il pacchetto resta di pochi MB e l'importazione riaggancia
	// le immagini già presenti sul server confrontando il nome del file.
	//
	// Spedirle TUTTE non è praticabile: il pacchetto arriva a decine di MB,
	// oltre il limite di WordPress. Per questo si può indicare l'elenco dei soli
	// file mancanti, che l'importazione stessa segnala a fine lavoro.
	$includi_file = ! empty( $_POST['pf_include_files'] );
	$solo_questi  = array();

	if ( ! empty( $_POST['pf_only_files'] ) ) {
		$righe = preg_split( '/[\r\n,]+/', (string) wp_unslash( $_POST['pf_only_files'] ) );
		foreach ( (array) $righe as $riga ) {
			$nome = sanitize_file_name( trim( $riga ) );
			if ( '' !== $nome ) {
				$solo_questi[ $nome ] = true;
			}
		}
		if ( $solo_questi ) {
			$includi_file = true;
		}
	}

	$media       = array();
	$media_index = array();

	foreach ( array_unique( $asset_urls ) as $asset_url ) {
		$nome_file = basename( parse_url( $asset_url, PHP_URL_PATH ) ?? '' );

		if ( '' !== $nome_file ) {
			$media_index[] = array( 'source' => $asset_url, 'file' => $nome_file );
		}

		if ( ! $includi_file ) {
			continue;
		}

		// Se è stato indicato un elenco, si spediscono solo quei file.
		if ( $solo_questi && ! isset( $solo_questi[ $nome_file ] ) ) {
			continue;
		}

		$asset = patriziatofrasco_upload_asset_from_url( $asset_url );
		if ( ! $asset ) {
			continue;
		}

		// Didascalie e testo alternativo viaggiano con l'immagine.
		$asset_id = attachment_url_to_postid( $asset_url );
		if ( $asset_id ) {
			$didascalie = array();
			foreach ( patriziatofrasco_transferable_media_meta() as $chiave ) {
				$valore = get_post_meta( $asset_id, $chiave, true );
				if ( '' !== trim( (string) $valore ) ) {
					$didascalie[ $chiave ] = (string) $valore;
				}
			}
			$titolo = get_the_title( $asset_id );
			if ( '' !== trim( (string) $titolo ) ) {
				$asset['titolo'] = $titolo;
			}
			if ( $didascalie ) {
				$asset['didascalie'] = $didascalie;
			}
			$gallerie = wp_get_object_terms( $asset_id, 'ticinoweb_media_gallery', array( 'fields' => 'names' ) );
			if ( ! is_wp_error( $gallerie ) && $gallerie ) {
				$asset['gallerie'] = $gallerie;
			}
		}

		$media[] = $asset;
	}

	$options = array();
	foreach ( patriziatofrasco_transferable_options() as $nome ) {
		$valore = get_option( $nome, null );
		if ( null !== $valore ) {
			$options[ $nome ] = $valore;
		}
	}

	$payload = array(
		'format'      => 'patriziatofrasco-page-content',
		'version'     => 2,
		'exported_at' => gmdate( 'c' ),
		'source_url'  => home_url(),
		'pages'       => $pages,
		'custom_posts'=> $trail_posts,
		'media'          => $media,
		'media_index'    => $media_index,
		'media_captions' => $media_captions,
		'options'        => $options,
	);

	$filename = 'patriziatofrasco-contenuti-' . gmdate( 'Y-m-d-His' ) . '.json';
	nocache_headers();
	header( 'Content-Type: application/json; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
	echo wp_json_encode( $payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
	exit;
}
add_action( 'admin_post_patriziatofrasco_export_page_content', 'patriziatofrasco_export_page_content' );

/**
 * Completa la mappa degli URL con le varianti comprensive del prefisso del
 * sotto-sito di partenza.
 *
 * La ricerca degli URL cattura anche forme relative che iniziano da
 * "/wp-content/...", senza il pezzo iniziale del percorso (es.
 * "/patriziatofrasco"). Sostituendo solo quella parte con un URL assoluto si
 * otteneva un indirizzo rotto del tipo
 * "/patriziatofrascohttp://localhost:8000/wp-content/...".
 * Registrando anche la chiave completa, la sostituzione parte dal punto giusto.
 *
 * @param array<string,string> $map        Mappa URL di partenza -> URL locale.
 * @param string               $source_url Home URL del sito di partenza.
 * @return array<string,string>
 */
function patriziatofrasco_expand_media_map( array $map, $source_url ) {
	$prefisso = trim( (string) wp_parse_url( (string) $source_url, PHP_URL_PATH ), '/' );

	if ( '' === $prefisso ) {
		return $map;
	}

	$prefisso = '/' . $prefisso;
	$estesa   = $map;

	foreach ( $map as $chiave => $valore ) {
		if ( 0 === strpos( $chiave, '/wp-content/' ) ) {
			$estesa[ $prefisso . $chiave ] = $valore;
		}
	}

	return $estesa;
}

/**
 * Cerca nella Libreria media locale un allegato dal solo nome del file.
 *
 * Serve per riagganciare gli URL delle immagini già presenti sul sito di
 * destinazione, senza doverle spedire dentro il pacchetto.
 *
 * @param string $filename Nome del file, senza percorso.
 * @return array{url:string,id:int}|null
 */
function patriziatofrasco_find_local_asset( $filename ) {
	global $wpdb;

	$filename = sanitize_file_name( (string) $filename );

	if ( '' === $filename ) {
		return null;
	}

	$attachment_id = (int) $wpdb->get_var(
		$wpdb->prepare(
			"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_wp_attached_file' AND meta_value LIKE %s ORDER BY post_id DESC LIMIT 1",
			'%' . $wpdb->esc_like( $filename )
		)
	);

	if ( ! $attachment_id ) {
		return null;
	}

	$url = wp_get_attachment_url( $attachment_id );

	return $url ? array( 'url' => $url, 'id' => $attachment_id ) : null;
}

/**
 * Copia nella Media Library un'immagine contenuta nel pacchetto.
 *
 * @param array $asset Dati dell'immagine esportata.
 * @return array|WP_Error Nuovo URL, ID allegato o errore.
 */
function patriziatofrasco_import_media_asset( $asset ) {
	if ( ! is_array( $asset ) || empty( $asset['filename'] ) || empty( $asset['data'] ) || empty( $asset['sha256'] ) ) {
		return new WP_Error( 'invalid_asset', 'Dati immagine non validi.' );
	}

	$filename = sanitize_file_name( $asset['filename'] );
	$binary   = base64_decode( $asset['data'], true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
	if ( ! $filename || false === $binary || hash( 'sha256', $binary ) !== $asset['sha256'] ) {
		return new WP_Error( 'invalid_asset_hash', 'Immagine danneggiata o incompleta.' );
	}

	$time = null;
	if ( ! empty( $asset['relative_path'] ) && preg_match( '~(?:^|/)(20\d{2})/(0[1-9]|1[0-2])(?:/|$)~', $asset['relative_path'], $date ) ) {
		$time = $date[1] . '/' . $date[2];
	}

	$uploads     = wp_upload_dir( $time );
	$target_file = trailingslashit( $uploads['path'] ) . $filename;
	$target_url  = trailingslashit( $uploads['url'] ) . rawurlencode( $filename );

	if ( file_exists( $target_file ) && hash_file( 'sha256', $target_file ) === $asset['sha256'] ) {
		$attachment_id = attachment_url_to_postid( $target_url );
		if ( ! $attachment_id ) {
			$filetype      = wp_check_filetype( $target_file );
			$attachment_id = wp_insert_attachment(
				array(
					'guid'           => $target_url,
					'post_mime_type' => $filetype['type'] ? $filetype['type'] : ( $asset['mime_type'] ?? 'application/octet-stream' ),
					'post_title'     => sanitize_text_field( pathinfo( $filename, PATHINFO_FILENAME ) ),
					'post_status'    => 'inherit',
				),
				$target_file
			);
		}
		return array( 'url' => $target_url, 'attachment_id' => is_wp_error( $attachment_id ) ? 0 : (int) $attachment_id );
	}

	$result = wp_upload_bits( $filename, null, $binary, $time );
	if ( ! empty( $result['error'] ) ) {
		return new WP_Error( 'upload_error', $result['error'] );
	}

	$filetype      = wp_check_filetype( $result['file'] );
	$attachment_id = wp_insert_attachment(
		array(
			'guid'           => $result['url'],
			'post_mime_type' => $filetype['type'] ? $filetype['type'] : ( $asset['mime_type'] ?? 'application/octet-stream' ),
			'post_title'     => sanitize_text_field( pathinfo( $filename, PATHINFO_FILENAME ) ),
			'post_status'    => 'inherit',
		),
		$result['file']
	);

	if ( ! is_wp_error( $attachment_id ) ) {
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$metadata = wp_generate_attachment_metadata( $attachment_id, $result['file'] );
		if ( $metadata ) {
			wp_update_attachment_metadata( $attachment_id, $metadata );
		}
	}

	return array( 'url' => $result['url'], 'attachment_id' => is_wp_error( $attachment_id ) ? 0 : (int) $attachment_id );
}

/**
 * Importa il pacchetto JSON aggiornando o creando le pagine consentite.
 */
function patriziatofrasco_import_page_content() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Non hai i permessi necessari.', 'patriziatofrasco' ) );
	}

	check_admin_referer( 'patriziatofrasco_import_page_content' );

	$redirect = admin_url( 'tools.php?page=patriziatofrasco-content-transfer' );
	$file     = isset( $_FILES['pf_page_content_file'] ) ? $_FILES['pf_page_content_file'] : null;

	$limite = max( (int) wp_max_upload_size(), 8 * MB_IN_BYTES );

	if ( ! is_array( $file ) || UPLOAD_ERR_OK !== (int) $file['error'] || empty( $file['tmp_name'] ) || (int) $file['size'] > $limite ) {
		wp_safe_redirect( add_query_arg( 'pf_transfer_notice', 'error', $redirect ) );
		exit;
	}

	$raw  = file_get_contents( $file['tmp_name'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
	$data = json_decode( $raw, true );

	$versione = (int) ( $data['version'] ?? 0 );

	if ( ! is_array( $data ) || 'patriziatofrasco-page-content' !== ( $data['format'] ?? '' ) || ! in_array( $versione, array( 1, 2 ), true ) || ! is_array( $data['pages'] ?? null ) ) {
		wp_safe_redirect( add_query_arg( 'pf_transfer_notice', 'error', $redirect ) );
		exit;
	}

	$allowed    = patriziatofrasco_transferable_pages();
	$source_url = isset( $data['source_url'] ) ? untrailingslashit( esc_url_raw( $data['source_url'] ) ) : '';
	$target_url = untrailingslashit( home_url() );
	$updated    = 0;
	$media_map  = array();
	$media_ids  = array();

	if ( is_array( $data['media'] ?? null ) ) {
		foreach ( $data['media'] as $asset ) {
			$source = isset( $asset['source'] ) ? (string) $asset['source'] : '';
			if ( ! $source ) {
				continue;
			}
			$new_url = patriziatofrasco_import_media_asset( $asset );
			if ( is_wp_error( $new_url ) ) {
				continue;
			}

			$media_map[ $source ] = $new_url['url'];
			$media_ids[ $source ] = (int) $new_url['attachment_id'];
			$nuovo_id             = (int) $new_url['attachment_id'];

			// Didascalie (Luogo, Data, Didascalia) e titolo dell'immagine.
			if ( $nuovo_id && is_array( $asset['didascalie'] ?? null ) ) {
				foreach ( patriziatofrasco_transferable_media_meta() as $chiave ) {
					if ( ! isset( $asset['didascalie'][ $chiave ] ) ) {
						continue;
					}
					update_post_meta( $nuovo_id, $chiave, sanitize_textarea_field( (string) $asset['didascalie'][ $chiave ] ) );
				}
			}

			if ( $nuovo_id && ! empty( $asset['titolo'] ) ) {
				wp_update_post(
					array(
						'ID'         => $nuovo_id,
						'post_title' => sanitize_text_field( (string) $asset['titolo'] ),
					)
				);
			}

			// Rimette la foto nelle stesse gallerie del sito di partenza.
			if ( $nuovo_id && is_array( $asset['gallerie'] ?? null ) && taxonomy_exists( 'ticinoweb_media_gallery' ) ) {
				$nomi = array_map( 'sanitize_text_field', $asset['gallerie'] );
				wp_set_object_terms( $nuovo_id, $nomi, 'ticinoweb_media_gallery', true );
			}
		}
	}

	// Immagini non spedite nel pacchetto: se sul server esistono già, si
	// riagganciano confrontando il nome del file. Quelle davvero mancanti
	// vengono elencate nell'avviso finale, così si sa cosa caricare a mano.
	$mancanti = array();

	if ( is_array( $data['media_index'] ?? null ) ) {
		foreach ( $data['media_index'] as $voce ) {
			$source = isset( $voce['source'] ) ? (string) $voce['source'] : '';
			$file   = isset( $voce['file'] ) ? (string) $voce['file'] : '';

			if ( '' === $source || isset( $media_map[ $source ] ) ) {
				continue;
			}

			$locale = patriziatofrasco_find_local_asset( $file );

			if ( $locale ) {
				$media_map[ $source ] = $locale['url'];
				$media_ids[ $source ] = $locale['id'];
			} else {
				$mancanti[] = $file;
			}
		}
	}

	$media_map = patriziatofrasco_expand_media_map( $media_map, $source_url );

	foreach ( $data['pages'] as $item ) {
		$slug = isset( $item['slug'] ) ? sanitize_title( $item['slug'] ) : '';
		if ( ! isset( $allowed[ $slug ] ) ) {
			continue;
		}

		$content = isset( $item['content'] ) ? (string) $item['content'] : '';
		$excerpt = isset( $item['excerpt'] ) ? (string) $item['excerpt'] : '';
		if ( $media_map ) {
			$content = strtr( $content, $media_map );
			$excerpt = strtr( $excerpt, $media_map );
		}
		if ( $source_url && $source_url !== $target_url ) {
			$content = str_replace( $source_url, $target_url, $content );
			$excerpt = str_replace( $source_url, $target_url, $excerpt );
		}

		$page = patriziatofrasco_get_page_for_transfer( $slug );
		$post = array(
			'post_type'    => 'page',
			'post_name'    => $slug,
			'post_title'   => isset( $item['title'] ) ? sanitize_text_field( $item['title'] ) : $allowed[ $slug ],
			'post_content' => wp_kses_post( $content ),
			'post_excerpt' => wp_kses_post( $excerpt ),
		);

		if ( $page ) {
			wp_save_post_revision( $page->ID );
			$post['ID'] = $page->ID;
			$result     = wp_update_post( wp_slash( $post ), true );
		} else {
			$post['post_status'] = 'publish';
			$result              = wp_insert_post( wp_slash( $post ), true );
		}

		if ( is_wp_error( $result ) ) {
			continue;
		}

		$template = isset( $item['template'] ) ? sanitize_file_name( $item['template'] ) : '';
		if ( $template ) {
			update_post_meta( $result, '_wp_page_template', $template );
		}
		++$updated;
	}

	$allowed_post_types = patriziatofrasco_transferable_post_types();
	if ( is_array( $data['custom_posts'] ?? null ) ) {
		foreach ( $data['custom_posts'] as $item ) {
			$post_type = isset( $item['post_type'] ) ? sanitize_key( $item['post_type'] ) : '';
			$slug      = isset( $item['slug'] ) ? sanitize_title( $item['slug'] ) : '';
			if ( ! in_array( $post_type, $allowed_post_types, true ) || ! $slug ) {
				continue;
			}

			$content = isset( $item['content'] ) ? (string) $item['content'] : '';
			$excerpt = isset( $item['excerpt'] ) ? (string) $item['excerpt'] : '';
			if ( $media_map ) {
				$content = strtr( $content, $media_map );
				$excerpt = strtr( $excerpt, $media_map );
			}
			if ( $source_url && $source_url !== $target_url ) {
				$content = str_replace( $source_url, $target_url, $content );
				$excerpt = str_replace( $source_url, $target_url, $excerpt );
			}

			$existing = get_page_by_path( $slug, OBJECT, $post_type );

			// Se lo stesso slug esiste con un ALTRO tipo fra quelli gestiti,
			// lo si converte invece di creare un doppione. Serve per i contenuti
			// che hanno cambiato natura (es. un sentiero diventato punto di
			// interesse): senza questo, sul sito di destinazione resterebbero
			// due voci, una vecchia e una nuova.
			if ( ! $existing instanceof WP_Post ) {
				foreach ( $allowed_post_types as $altro_tipo ) {
					if ( $altro_tipo === $post_type ) {
						continue;
					}
					$candidato = get_page_by_path( $slug, OBJECT, $altro_tipo );
					if ( $candidato instanceof WP_Post ) {
						$existing = $candidato;
						break;
					}
				}
			}

			$post_data = array(
				'post_type'    => $post_type,
				'post_name'    => $slug,
				'post_title'   => isset( $item['title'] ) ? sanitize_text_field( $item['title'] ) : $slug,
				'post_content' => wp_kses_post( $content ),
				'post_excerpt' => wp_kses_post( $excerpt ),
				'menu_order'   => isset( $item['menu_order'] ) ? (int) $item['menu_order'] : 0,
			);

			if ( $existing instanceof WP_Post ) {
				wp_save_post_revision( $existing->ID );
				$post_data['ID'] = $existing->ID;
				$result          = wp_update_post( wp_slash( $post_data ), true );
			} else {
				$post_data['post_status'] = 'publish';
				$result                   = wp_insert_post( wp_slash( $post_data ), true );
			}

			if ( is_wp_error( $result ) ) {
				continue;
			}

			if ( is_array( $item['meta'] ?? null ) ) {
				$prefissi_ammessi = patriziatofrasco_transferable_meta_prefixes();

				// Ripulisce i campi del tipo precedente, se il contenuto e' stato
				// convertito: altrimenti resterebbero valori orfani nel backend.
				foreach ( get_post_meta( $result ) as $chiave_esistente => $ignorato ) {
					foreach ( $prefissi_ammessi as $prefisso ) {
						if ( 0 === strpos( $chiave_esistente, $prefisso ) && ! isset( $item['meta'][ $chiave_esistente ] ) ) {
							delete_post_meta( $result, $chiave_esistente );
						}
					}
				}

				foreach ( $item['meta'] as $meta_key => $meta_value ) {
					$meta_key = sanitize_key( $meta_key );
					$ammesso  = false;
					foreach ( $prefissi_ammessi as $prefisso ) {
						if ( 0 === strpos( $meta_key, $prefisso ) ) {
							$ammesso = true;
							break;
						}
					}
					if ( ! $ammesso ) {
						continue;
					}
					if ( is_string( $meta_value ) && $media_map ) {
						$meta_value = strtr( $meta_value, $media_map );
					}
					update_post_meta( $result, $meta_key, wp_kses_post( $meta_value ) );
				}
			}

			$thumbnail_source = isset( $item['thumbnail_source'] ) ? (string) $item['thumbnail_source'] : '';
			if ( $thumbnail_source && ! empty( $media_ids[ $thumbnail_source ] ) ) {
				set_post_thumbnail( $result, $media_ids[ $thumbnail_source ] );
			}
			++$updated;
		}
	}

	// Didascalie delle foto di galleria: abbinamento per nome del file, senza
	// ricaricare nulla. Le foto che sul server non esistono vengono ignorate.
	if ( is_array( $data['media_captions'] ?? null ) ) {
		global $wpdb;

		foreach ( $data['media_captions'] as $voce ) {
			$nome_file = isset( $voce['file'] ) ? sanitize_file_name( (string) $voce['file'] ) : '';

			if ( '' === $nome_file ) {
				continue;
			}

			$attachment_id = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_wp_attached_file' AND meta_value LIKE %s ORDER BY post_id DESC LIMIT 1",
					'%' . $wpdb->esc_like( $nome_file )
				)
			);

			if ( ! $attachment_id ) {
				continue;
			}

			$toccato = false;

			foreach ( patriziatofrasco_transferable_media_meta() as $chiave ) {
				if ( ! isset( $voce[ $chiave ] ) ) {
					continue;
				}
				update_post_meta( $attachment_id, $chiave, sanitize_textarea_field( (string) $voce[ $chiave ] ) );
				$toccato = true;
			}

			if ( ! empty( $voce['titolo'] ) ) {
				wp_update_post(
					array(
						'ID'         => $attachment_id,
						'post_title' => sanitize_text_field( (string) $voce['titolo'] ),
					)
				);
				$toccato = true;
			}

			if ( is_array( $voce['gallerie'] ?? null ) && taxonomy_exists( 'ticinoweb_media_gallery' ) ) {
				wp_set_object_terms( $attachment_id, array_map( 'sanitize_text_field', $voce['gallerie'] ), 'ticinoweb_media_gallery', true );
				$toccato = true;
			}

			if ( $toccato ) {
				++$updated;
			}
		}
	}

	// Opzioni gestite dal tema (recapiti, pagina Formulari nascosta o visibile).
	if ( is_array( $data['options'] ?? null ) ) {
		$opzioni_ammesse = patriziatofrasco_transferable_options();
		foreach ( $data['options'] as $nome => $valore ) {
			if ( ! in_array( $nome, $opzioni_ammesse, true ) ) {
				continue;
			}
			update_option( $nome, is_string( $valore ) ? sanitize_textarea_field( $valore ) : $valore );
			++$updated;
		}
	}

	// Elenco delle immagini non trovate: resta a disposizione nella schermata,
	// così si può incollare nell'esportazione per spedire solo quelle.
	$mancanti = array_values( array_unique( array_filter( $mancanti ) ) );
	if ( $mancanti ) {
		update_option( 'ptf_transfer_missing_files', $mancanti, false );
	} else {
		delete_option( 'ptf_transfer_missing_files' );
	}

	// I permalink dei tipi personalizzati vanno rigenerati dopo l'importazione.
	flush_rewrite_rules();

	wp_safe_redirect(
		add_query_arg(
			array(
				'pf_transfer_notice' => $updated ? 'success' : 'error',
				'pf_transfer_count'  => $updated,
				'pf_transfer_missing'=> count( array_unique( $mancanti ) ),
			),
			$redirect
		)
	);
	exit;
}
add_action( 'admin_post_patriziatofrasco_import_page_content', 'patriziatofrasco_import_page_content' );
