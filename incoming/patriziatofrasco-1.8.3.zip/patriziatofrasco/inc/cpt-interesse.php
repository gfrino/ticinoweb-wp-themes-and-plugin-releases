<?php
/**
 * Registrazione Custom Post Type: Punti di Interesse
 */
function patriziatofrasco_register_interesse_cpt() {
	$labels = array(
		'name'                  => _x( 'Punti di Interesse', 'Post type general name', 'patriziatofrasco' ),
		'singular_name'         => _x( 'Punto di Interesse', 'Post type singular name', 'patriziatofrasco' ),
		'menu_name'             => _x( 'Punti di Interesse', 'Admin Menu text', 'patriziatofrasco' ),
		'name_admin_bar'        => _x( 'Punto Interesse', 'Add New on Toolbar', 'patriziatofrasco' ),
		'add_new'               => __( 'Aggiungi Nuovo', 'patriziatofrasco' ),
		'add_new_item'          => __( 'Aggiungi Nuovo Punto', 'patriziatofrasco' ),
		'new_item'              => __( 'Nuovo Punto', 'patriziatofrasco' ),
		'edit_item'             => __( 'Modifica Punto', 'patriziatofrasco' ),
		'view_item'             => __( 'Guarda Punto', 'patriziatofrasco' ),
		'all_items'             => __( 'Tutti i Punti di Interesse', 'patriziatofrasco' ),
		'search_items'          => __( 'Cerca', 'patriziatofrasco' ),
		'not_found'             => __( 'Nessun punto trovato.', 'patriziatofrasco' ),
		'not_found_in_trash'    => __( 'Nessun punto nel cestino.', 'patriziatofrasco' ),
	);

	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'punto-di-interesse' ),
		'capability_type'    => 'post',
		'has_archive'        => false, 
		'hierarchical'       => false,
		'menu_position'      => 5.7,
		'menu_icon'          => 'dashicons-location', // Icon for places/landmarks
		'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
		'show_in_rest'       => true,
	);

	register_post_type( 'punto_interesse', $args );
}
add_action( 'init', 'patriziatofrasco_register_interesse_cpt' );

/**
 * Anteprima immagine
 */
add_filter( 'manage_punto_interesse_posts_columns', 'patriziatofrasco_interesse_columns' );
function patriziatofrasco_interesse_columns( $columns ) {
    $new_columns = array();
    foreach ( $columns as $key => $value ) {
        if ( $key == 'title' ) {
            $new_columns['featured_image'] = __( 'Copertina', 'patriziatofrasco' );
        }
        $new_columns[$key] = $value;
    }
    return $new_columns;
}

add_action( 'manage_punto_interesse_posts_custom_column', 'patriziatofrasco_interesse_custom_column', 10, 2 );
function patriziatofrasco_interesse_custom_column( $column, $post_id ) {
    if ( $column == 'featured_image' ) {
        if ( has_post_thumbnail( $post_id ) ) {
            echo get_the_post_thumbnail( $post_id, array( 60, 60 ), array('style' => 'border-radius:4px; object-fit:cover;') );
        } else {
            echo '<span style="color:#999;">- Nessuna -</span>';
        }
    }
}

add_action('admin_head', 'patriziatofrasco_interesse_admin_css');
function patriziatofrasco_interesse_admin_css() {
    echo '<style>
        .column-featured_image { width: 80px !important; }
    </style>';
}

/**
 * Registrazione Meta Box Avanzato
 */
function patriziatofrasco_add_interesse_metaboxes() {
	add_meta_box(
		'patriziatofrasco_interesse_dettagli',
		'Impostazioni Avanzate (Sidebar e Testata)',
		'patriziatofrasco_interesse_dettagli_callback',
		'punto_interesse',
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'patriziatofrasco_add_interesse_metaboxes' );

function patriziatofrasco_interesse_dettagli_callback( $post ) {
	wp_nonce_field( 'patriziatofrasco_save_interesse_data', 'patriziatofrasco_interesse_meta_nonce' );

	$subtitle = get_post_meta( $post->ID, '_interesse_subtitle', true );
	$action_url = get_post_meta( $post->ID, '_interesse_action_url', true );
	$action_text = get_post_meta( $post->ID, '_interesse_action_text', true );
	$action_subtext = get_post_meta( $post->ID, '_interesse_action_subtext', true );
	$maps_query = get_post_meta( $post->ID, '_interesse_maps_query', true );
	
	if(empty($action_text)) $action_text = 'Contatta ora';
	?>
	<div style="background: #f9f9f9; padding: 15px; border: 1px solid #ddd; margin-bottom: 20px;">
        <h4 style="margin-top:0;">Testata Principale</h4>
        <p>
            <label for="interesse_subtitle"><strong>Sottotitolo (sotto il titolo principale)</strong></label><br>
            <input type="text" id="interesse_subtitle" name="interesse_subtitle" value="<?php echo esc_attr( $subtitle ); ?>" style="width:100%; max-width:600px;" />
            <br><small>Es: "Un tuffo negli antichi mestieri della valle"</small>
        </p>
    </div>

    <div style="background: #f9f9f9; padding: 15px; border: 1px solid #ddd; margin-bottom: 20px;">
        <h4 style="margin-top:0;">Barra Laterale - Contatto/Azione e Mappa</h4>
        <p>
            <label for="interesse_action_url"><strong>Link Bottone</strong></label><br>
            <input type="text" id="interesse_action_url" name="interesse_action_url" value="<?php echo esc_attr( $action_url ); ?>" style="width:100%; max-width:600px;" />
            <br><small>Può essere un URL normale (es. <code>https://...</code>), un telefono (<code>tel:+41...</code>) o un'email (<code>mailto:info@...</code>).</small>
        </p>
        <p>
            <label for="interesse_action_text"><strong>Testo Bottone</strong></label><br>
            <input type="text" id="interesse_action_text" name="interesse_action_text" value="<?php echo esc_attr( $action_text ); ?>" style="width:100%; max-width:600px;" />
        </p>
        <p>
            <label for="interesse_action_subtext"><strong>Sottotesto Bottone (opzionale)</strong></label><br>
            <input type="text" id="interesse_action_subtext" name="interesse_action_subtext" value="<?php echo esc_attr( $action_subtext ); ?>" style="width:100%; max-width:600px;" />
            <br><small>Es: "Visite guidate su richiesta"</small>
        </p>
        <p>
            <label for="interesse_maps_query"><strong>Query Google Maps (iframe)</strong></label><br>
            <input type="text" id="interesse_maps_query" name="interesse_maps_query" value="<?php echo esc_attr( $maps_query ); ?>" style="width:100%; max-width:600px;" />
            <br><small>Es: "Mulino Frasco"</small>
        </p>
    </div>

    <div style="background: #f9f9f9; padding: 15px; border: 1px solid #ddd;">
        <h4 style="margin-top:0;">Barra Laterale - Informazioni e Orari</h4>
        <p><small>Lascia vuote le righe che non ti servono. Puoi usare codice HTML nei valori.</small></p>
        <table class="form-table" style="background:#fff; border:1px solid #eee; padding:10px;">
            <thead>
                <tr>
                    <th style="width:30%;">Etichetta (es. Orari)</th>
                    <th>Valore (es. Tutti i sabati)</th>
                </tr>
            </thead>
            <tbody>
                <?php for($i=1; $i<=10; $i++): 
                    $lbl = get_post_meta( $post->ID, '_interesse_info_label_'.$i, true );
                    $val = get_post_meta( $post->ID, '_interesse_info_value_'.$i, true );
                ?>
                <tr>
                    <td><input type="text" name="interesse_info_label_<?php echo $i; ?>" value="<?php echo esc_attr($lbl); ?>" style="width:100%;" placeholder="Etichetta <?php echo $i; ?>"></td>
                    <td><input type="text" name="interesse_info_value_<?php echo $i; ?>" value="<?php echo esc_attr($val); ?>" style="width:100%;" placeholder="Valore <?php echo $i; ?>"></td>
                </tr>
                <?php endfor; ?>
            </tbody>
        </table>
    </div>
	<?php
}

function patriziatofrasco_save_interesse_meta( $post_id ) {
	if ( ! isset( $_POST['patriziatofrasco_interesse_meta_nonce'] ) ) return;
	if ( ! wp_verify_nonce( $_POST['patriziatofrasco_interesse_meta_nonce'], 'patriziatofrasco_save_interesse_data' ) ) return;
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
	if ( ! current_user_can( 'edit_post', $post_id ) ) return;

	$fields = ['interesse_subtitle', 'interesse_action_url', 'interesse_action_text', 'interesse_action_subtext', 'interesse_maps_query'];
    foreach($fields as $f) {
        if ( isset( $_POST[$f] ) ) {
            update_post_meta( $post_id, '_'.$f, sanitize_text_field( $_POST[$f] ) );
        }
    }

    for($i=1; $i<=10; $i++) {
        if(isset($_POST["interesse_info_label_$i"])) {
            update_post_meta($post_id, "_interesse_info_label_$i", sanitize_text_field($_POST["interesse_info_label_$i"]));
        }
        if(isset($_POST["interesse_info_value_$i"])) {
            update_post_meta($post_id, "_interesse_info_value_$i", wp_kses_post($_POST["interesse_info_value_$i"]));
        }
    }
}
add_action( 'save_post_punto_interesse', 'patriziatofrasco_save_interesse_meta' );
