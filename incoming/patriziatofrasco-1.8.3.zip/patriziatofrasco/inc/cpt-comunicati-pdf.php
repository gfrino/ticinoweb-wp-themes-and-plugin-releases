<?php
/**
 * Documento PDF allegato ai Comunicati
 *
 * Il Custom Post Type 'comunicato' è registrato in functions.php.
 * Qui aggiungiamo soltanto il meta box con l'uploader del PDF, seguendo
 * lo stesso schema usato per Mozioni e Attività.
 *
 * Il PDF NON sostituisce il contenuto del comunicato: si aggiunge sotto.
 *
 * @package Patriziato Frasco
 */

// 1. Aggiunge il Meta Box "Documento PDF"
function patriziatofrasco_add_comunicati_pdf_metabox() {
    add_meta_box(
        'comunicati_pdf_meta_box', // ID
        'Documento PDF', // Titolo
        'patriziatofrasco_comunicati_pdf_metabox_callback', // Callback
        'comunicato', // Post Type
        'side', // Contesto
        'default' // Priorità
    );
}
add_action( 'add_meta_boxes', 'patriziatofrasco_add_comunicati_pdf_metabox' );

// 2. Costruisce l'HTML per il Meta Box
function patriziatofrasco_comunicati_pdf_metabox_callback( $post ) {
    // Aggiungi un nonce field per la sicurezza
    wp_nonce_field( 'comunicati_pdf_save_meta_box_data', 'comunicati_pdf_meta_box_nonce' );

    // Recupera i valori attuali
    $pdf_id = get_post_meta( $post->ID, '_comunicato_pdf_id', true );
    $pdf_url = $pdf_id ? wp_get_attachment_url( $pdf_id ) : '';

    // HTML del Form
    echo '<style>
        .comunicato-field-row { margin-bottom: 15px; }
        .comunicato-field-row label { display: block; font-weight: bold; margin-bottom: 5px; }
        .comunicato-pdf-preview { margin-top: 10px; display: block; word-break: break-all; }
        .comunicato-pdf-help { margin-top: 10px; color: #646970; font-size: 12px; }
    </style>';

    // Allegato PDF
    echo '<div class="comunicato-field-row">';
    echo '<label>Allegato PDF (Facoltativo)</label>';
    echo '<input type="hidden" id="comunicato_pdf_id" name="comunicato_pdf_id" value="' . esc_attr( $pdf_id ) . '" />';
    echo '<button type="button" class="button button-secondary" id="comunicato_upload_pdf_btn">Seleziona o carica PDF</button> ';
    echo '<button type="button" class="button button-link-delete" id="comunicato_remove_pdf_btn" style="' . ( $pdf_id ? '' : 'display:none;' ) . '">Rimuovi PDF</button>';
    echo '<span class="comunicato-pdf-preview" id="comunicato_pdf_preview">';
    if ( $pdf_url ) {
        echo '<a href="' . esc_url( $pdf_url ) . '" target="_blank">Vedi PDF attuale (' . esc_html( basename( $pdf_url ) ) . ')</a>';
    }
    echo '</span>';
    echo '<p class="comunicato-pdf-help">Il PDF viene mostrato in fondo al comunicato, sotto al testo. Puoi usare testo e PDF insieme.</p>';
    echo '</div>';

    // Script per il media uploader di WordPress
    ?>
    <script>
    jQuery(document).ready(function($){
        var mediaUploader;
        $('#comunicato_upload_pdf_btn').click(function(e) {
            e.preventDefault();
            if (mediaUploader) {
                mediaUploader.open();
                return;
            }
            mediaUploader = wp.media.frames.file_frame = wp.media({
                title: 'Seleziona Allegato PDF',
                button: { text: 'Usa questo file' },
                multiple: false,
                library: { type: 'application/pdf' }
            });
            mediaUploader.on('select', function() {
                var attachment = mediaUploader.state().get('selection').first().toJSON();
                $('#comunicato_pdf_id').val(attachment.id);
                $('#comunicato_pdf_preview').html('<a href="' + attachment.url + '" target="_blank">Vedi PDF attuale (' + attachment.filename + ')</a>');
                $('#comunicato_remove_pdf_btn').show();
            });
            mediaUploader.open();
        });

        $('#comunicato_remove_pdf_btn').click(function(e){
            e.preventDefault();
            $('#comunicato_pdf_id').val('');
            $('#comunicato_pdf_preview').html('');
            $(this).hide();
        });
    });
    </script>
    <?php
}

// 3. Salva i dati del Meta Box
function patriziatofrasco_save_comunicati_pdf_meta_box_data( $post_id ) {
    // Controlla il nonce
    if ( ! isset( $_POST['comunicati_pdf_meta_box_nonce'] ) ) {
        return;
    }
    if ( ! wp_verify_nonce( $_POST['comunicati_pdf_meta_box_nonce'], 'comunicati_pdf_save_meta_box_data' ) ) {
        return;
    }
    // Evita l'autosave
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    // Controlla i permessi
    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }

    // Salva "Allegato PDF"
    if ( isset( $_POST['comunicato_pdf_id'] ) ) {
        $pdf_id = absint( $_POST['comunicato_pdf_id'] );
        if ( $pdf_id ) {
            update_post_meta( $post_id, '_comunicato_pdf_id', $pdf_id );
        } else {
            delete_post_meta( $post_id, '_comunicato_pdf_id' );
        }
    }
}
add_action( 'save_post', 'patriziatofrasco_save_comunicati_pdf_meta_box_data' );

// 4. Aggiungi il supporto per il media uploader nello script di admin
function patriziatofrasco_enqueue_comunicati_pdf_admin_scripts( $hook ) {
    global $post;
    if ( $hook == 'post-new.php' || $hook == 'post.php' ) {
        if ( $post && 'comunicato' === $post->post_type ) {
            wp_enqueue_media();
        }
    }
}
add_action( 'admin_enqueue_scripts', 'patriziatofrasco_enqueue_comunicati_pdf_admin_scripts' );
