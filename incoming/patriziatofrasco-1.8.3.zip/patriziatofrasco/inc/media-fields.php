<?php
/**
 * Campi media personalizzati: Luogo e Data.
 *
 * Aggiunge due campi ("Luogo" e "Data") ai dettagli allegato della Libreria Media
 * e mette a disposizione due helper riutilizzabili per stampare la didascalia
 * nello stile del riquadro usato nella pagina "Patriziato" (es. "Frasco, 1969").
 *
 * @package patriziatofrasco
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Campi aggiuntivi nei dettagli allegato (solo immagini).
 *
 * @param array   $form_fields Campi del form allegato.
 * @param WP_Post $post        Oggetto allegato.
 * @return array
 */
function patriziatofrasco_media_attachment_fields_to_edit( $form_fields, $post ) {
	if ( ! isset( $post->ID ) || ! wp_attachment_is_image( $post->ID ) ) {
		return $form_fields;
	}

	$form_fields['ptf_media_luogo'] = array(
		'label' => __( 'Luogo', 'patriziatofrasco' ),
		'input' => 'text',
		'value' => get_post_meta( $post->ID, '_ptf_media_luogo', true ),
		'helps' => __( 'Dove è stata scattata la foto. Es: "Frasco".', 'patriziatofrasco' ),
	);

	$form_fields['ptf_media_data'] = array(
		'label' => __( 'Data', 'patriziatofrasco' ),
		'input' => 'text',
		'value' => get_post_meta( $post->ID, '_ptf_media_data', true ),
		'helps' => __( 'Testo libero. Es: "1969" oppure "Estate 1978".', 'patriziatofrasco' ),
	);

	$form_fields['ptf_media_didascalia'] = array(
		'label' => __( 'Didascalia', 'patriziatofrasco' ),
		'input' => 'textarea',
		'value' => get_post_meta( $post->ID, '_ptf_media_didascalia', true ),
		'helps' => __( 'Compare solo quando si apre la foto a schermo intero. Luogo e Data restano nel riquadro in basso a destra sulla miniatura.', 'patriziatofrasco' ),
	);

	return $form_fields;
}
add_filter( 'attachment_fields_to_edit', 'patriziatofrasco_media_attachment_fields_to_edit', 10, 2 );

/**
 * Salvataggio dei campi Luogo e Data.
 *
 * Nota sul nonce: questo filtro viene eseguito da WordPress solo DOPO la verifica
 * del nonce della richiesta (check_ajax_referer( 'update-post_' . $id ) nel modale
 * media, wp_nonce nel modulo classico di modifica allegato), quindi qui non va
 * aggiunto un nonce proprio: restano a nostro carico il controllo capability e la
 * sanitizzazione, come negli altri inc/cpt-*.php.
 *
 * @param array $post       Dati dell'allegato in salvataggio.
 * @param array $attachment Campi inviati dal form.
 * @return array
 */
function patriziatofrasco_media_attachment_fields_to_save( $post, $attachment ) {
	if ( empty( $post['ID'] ) ) {
		return $post;
	}

	$attachment_id = (int) $post['ID'];

	if ( ! wp_attachment_is_image( $attachment_id ) ) {
		return $post;
	}

	if ( ! current_user_can( 'edit_post', $attachment_id ) ) {
		return $post;
	}

	$campi = array( 'ptf_media_luogo', 'ptf_media_data', 'ptf_media_didascalia' );

	foreach ( $campi as $campo ) {
		if ( ! isset( $attachment[ $campo ] ) ) {
			continue;
		}

		$valore = sanitize_text_field( wp_unslash( $attachment[ $campo ] ) );

		if ( '' === $valore ) {
			delete_post_meta( $attachment_id, '_' . $campo );
		} else {
			update_post_meta( $attachment_id, '_' . $campo, $valore );
		}
	}

	return $post;
}
add_filter( 'attachment_fields_to_save', 'patriziatofrasco_media_attachment_fields_to_save', 10, 2 );

/**
 * Slug della schermata "Media > Gestisci Gallerie".
 *
 * La pagina è registrata dal TEMA PADRE (inc/media-galleries.php, riga 263) come
 * sottopagina di upload.php: qui il valore serve solo per riconoscerla e caricare
 * gli script nel posto giusto. Il tema padre non viene toccato.
 */
if ( ! defined( 'PATRIZIATOFRASCO_GALLERIES_MANAGER_PAGE' ) ) {
	define( 'PATRIZIATOFRASCO_GALLERIES_MANAGER_PAGE', 'ticinoweb-media-galleries-manager' );
}

/**
 * Azione del nonce condiviso dalle due chiamate AJAX di questa schermata.
 */
if ( ! defined( 'PATRIZIATOFRASCO_MEDIA_CAPTION_NONCE' ) ) {
	define( 'PATRIZIATOFRASCO_MEDIA_CAPTION_NONCE', 'ptf_media_caption_inline' );
}

/**
 * Siamo nella schermata "Media > Gestisci Gallerie"?
 *
 * Doppio controllo volutamente ridondante: il parametro `page` in querystring
 * (che è ciò che il tema padre stesso usa) e l'hook della schermata, che per una
 * sottopagina di upload.php vale "media_page_ticinoweb-media-galleries-manager".
 *
 * @param string $hook Hook suffix passato da admin_enqueue_scripts.
 * @return bool
 */
function patriziatofrasco_is_galleries_manager_screen( $hook ) {
	$slug = PATRIZIATOFRASCO_GALLERIES_MANAGER_PAGE;

	// Lettura di sola identificazione della schermata: nessun dato viene elaborato o salvato.
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';

	if ( $slug !== $page ) {
		return false;
	}

	return ( is_string( $hook ) && false !== strpos( $hook, $slug ) );
}

/**
 * Script e stile per impostare Luogo e Data direttamente dalla griglia gallerie.
 *
 * Caricati SOLO su quella schermata e SOLO per chi può gestirla (stessa capability
 * con cui il tema padre registra la pagina).
 *
 * @param string $hook Hook suffix della schermata corrente.
 * @return void
 */
function patriziatofrasco_media_caption_inline_assets( $hook ) {
	if ( ! patriziatofrasco_is_galleries_manager_screen( $hook ) ) {
		return;
	}

	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$handle   = 'patriziatofrasco-media-caption-inline';
	$base_dir = get_stylesheet_directory();
	$base_uri = get_stylesheet_directory_uri();
	$css_rel  = '/assets/css/media-caption-inline.css';
	$js_rel   = '/assets/js/media-caption-inline.js';

	if ( ! file_exists( $base_dir . $css_rel ) || ! file_exists( $base_dir . $js_rel ) ) {
		return;
	}

	// Versione = data di modifica del file: cache-busting senza toccare la versione del tema.
	wp_enqueue_style( $handle, $base_uri . $css_rel, array(), (string) filemtime( $base_dir . $css_rel ) );
	wp_enqueue_script( $handle, $base_uri . $js_rel, array(), (string) filemtime( $base_dir . $js_rel ), true );

	wp_localize_script(
		$handle,
		'ptfMediaCaption',
		array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( PATRIZIATOFRASCO_MEDIA_CAPTION_NONCE ),
			'i18n'    => array(
				'buttonSet'       => __( 'Imposta didascalie', 'patriziatofrasco' ),
				'buttonEdit'      => __( 'Modifica didascalie', 'patriziatofrasco' ),
				'modalTitle'      => __( 'Didascalie della foto', 'patriziatofrasco' ),
				'modalHint'       => __( 'Lascia vuoto un campo per non mostrarlo.', 'patriziatofrasco' ),
				'labelLuogo'      => __( 'Luogo', 'patriziatofrasco' ),
				'labelData'       => __( 'Data', 'patriziatofrasco' ),
				'labelDidascalia' => __( 'Didascalia', 'patriziatofrasco' ),
				'placeholderLuogo' => __( 'Es. Frasco', 'patriziatofrasco' ),
				'placeholderData' => __( 'Es. 1969', 'patriziatofrasco' ),
				'placeholderDidascalia' => __( 'Testo che compare aprendo la foto', 'patriziatofrasco' ),
				'helpLuogoData'   => __( 'Luogo e data compaiono nel riquadro in basso a destra sulla miniatura.', 'patriziatofrasco' ),
				'helpDidascalia'  => __( 'Si vede solo quando la foto viene aperta a schermo intero.', 'patriziatofrasco' ),
				'save'            => __( 'Salva', 'patriziatofrasco' ),
				'saving'          => __( 'Salvataggio…', 'patriziatofrasco' ),
				'cancel'          => __( 'Annulla', 'patriziatofrasco' ),
				'errorGeneric'    => __( 'Non è stato possibile salvare. Riprova fra un istante.', 'patriziatofrasco' ),
				'errorNetwork'    => __( 'Connessione non riuscita. Controlla la rete e riprova.', 'patriziatofrasco' ),
				'errorTimeout'    => __( 'Il server non ha risposto in tempo. Riprova.', 'patriziatofrasco' ),
				'errorSession'    => __( 'Sessione scaduta. Ricarica la pagina e riprova.', 'patriziatofrasco' ),
				'errorLoad'       => __( 'Non è stato possibile leggere i valori attuali: puoi comunque scriverli e salvare.', 'patriziatofrasco' ),
			),
		)
	);
}
add_action( 'admin_enqueue_scripts', 'patriziatofrasco_media_caption_inline_assets' );

/**
 * AJAX: lettura di Luogo e Data di più allegati in una sola chiamata.
 *
 * Serve a precompilare il pannello e a mostrare la didascalia sulle card senza
 * duplicare, lato PHP, la query con cui il tema padre costruisce la griglia:
 * gli ID arrivano direttamente dal DOM della pagina.
 *
 * @return void
 */
function patriziatofrasco_ajax_get_media_captions() {
	check_ajax_referer( PATRIZIATOFRASCO_MEDIA_CAPTION_NONCE, 'nonce' );

	$grezzi = isset( $_POST['attachment_ids'] ) ? wp_unslash( $_POST['attachment_ids'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
	$grezzi = is_array( $grezzi ) ? $grezzi : array();
	$ids    = array_values( array_unique( array_filter( array_map( 'absint', $grezzi ) ) ) );
	$ids    = array_slice( $ids, 0, 500 );

	if ( empty( $ids ) ) {
		wp_send_json_success( array() );
	}

	// Una sola query per post e meta invece di una per allegato.
	if ( function_exists( '_prime_post_caches' ) ) {
		_prime_post_caches( $ids, false, true );
	}

	$risposta = array();

	foreach ( $ids as $id ) {
		if ( 'attachment' !== get_post_type( $id ) ) {
			continue;
		}

		if ( ! current_user_can( 'edit_post', $id ) ) {
			continue;
		}

		$risposta[ (string) $id ] = array(
			'luogo'      => (string) get_post_meta( $id, '_ptf_media_luogo', true ),
			'data'       => (string) get_post_meta( $id, '_ptf_media_data', true ),
			'didascalia' => (string) get_post_meta( $id, '_ptf_media_didascalia', true ),
			'caption' => ptf_media_caption( $id ),
		);
	}

	wp_send_json_success( (object) $risposta );
}
add_action( 'wp_ajax_ptf_get_media_captions', 'patriziatofrasco_ajax_get_media_captions' );

/**
 * AJAX: salvataggio di Luogo e Data dal gestore gallerie.
 *
 * Il permesso richiesto è 'edit_post' sul singolo allegato, non una capability
 * generica: chi non può modificare quella immagine non può modificarne i dati.
 *
 * @return void
 */
function patriziatofrasco_ajax_save_media_caption() {
	check_ajax_referer( PATRIZIATOFRASCO_MEDIA_CAPTION_NONCE, 'nonce' );

	$attachment_id = isset( $_POST['attachment_id'] ) ? absint( wp_unslash( $_POST['attachment_id'] ) ) : 0;

	if ( $attachment_id <= 0 || 'attachment' !== get_post_type( $attachment_id ) ) {
		wp_send_json_error(
			array( 'message' => __( 'Immagine non trovata. Ricarica la pagina e riprova.', 'patriziatofrasco' ) ),
			404
		);
	}

	if ( ! current_user_can( 'edit_post', $attachment_id ) ) {
		wp_send_json_error(
			array( 'message' => __( 'Non hai i permessi per modificare questa immagine.', 'patriziatofrasco' ) ),
			403
		);
	}

	$valori = array(
		'_ptf_media_luogo'      => isset( $_POST['luogo'] ) ? sanitize_text_field( wp_unslash( $_POST['luogo'] ) ) : '',
		'_ptf_media_data'       => isset( $_POST['data'] ) ? sanitize_text_field( wp_unslash( $_POST['data'] ) ) : '',
		'_ptf_media_didascalia' => isset( $_POST['didascalia'] ) ? sanitize_textarea_field( wp_unslash( $_POST['didascalia'] ) ) : '',
	);

	foreach ( $valori as $meta_key => $valore ) {
		$valore = trim( $valore );

		// Campo vuoto: si cancella il meta, non si salva una stringa vuota.
		if ( '' === $valore ) {
			delete_post_meta( $attachment_id, $meta_key );
		} else {
			update_post_meta( $attachment_id, $meta_key, $valore );
		}
	}

	wp_send_json_success(
		array(
			'attachment_id' => $attachment_id,
			'luogo'         => (string) get_post_meta( $attachment_id, '_ptf_media_luogo', true ),
			'data'          => (string) get_post_meta( $attachment_id, '_ptf_media_data', true ),
			'didascalia'    => (string) get_post_meta( $attachment_id, '_ptf_media_didascalia', true ),
			'caption'       => ptf_media_caption( $attachment_id ),
		)
	);
}
add_action( 'wp_ajax_ptf_save_media_caption', 'patriziatofrasco_ajax_save_media_caption' );

if ( ! function_exists( 'ptf_media_caption' ) ) {
	/**
	 * Didascalia formattata di un allegato: "Luogo, Data".
	 *
	 * Restituisce il testo GREZZO, senza escaping: l'escaping è responsabilità
	 * di chi stampa (usare esc_html() o ptf_media_caption_badge()).
	 *
	 * Ordine di precedenza:
	 * 1. Luogo + Data  -> "Luogo, Data"
	 * 2. Solo uno dei due -> quello valorizzato
	 * 3. Nessuno dei due -> didascalia nativa di WordPress (post_excerpt)
	 * 4. Niente -> stringa vuota (la didascalia nativa di WordPress non c'entra:
	 *    quella va in ptf_media_didascalia(), mostrata all'apertura della foto)
	 *
	 * @param int $attachment_id ID dell'allegato.
	 * @return string
	 */
	function ptf_media_caption( $attachment_id ) : string {
		$attachment_id = (int) $attachment_id;

		if ( $attachment_id <= 0 ) {
			return '';
		}

		$luogo = trim( (string) get_post_meta( $attachment_id, '_ptf_media_luogo', true ) );
		$data  = trim( (string) get_post_meta( $attachment_id, '_ptf_media_data', true ) );

		if ( '' !== $luogo && '' !== $data ) {
			return $luogo . ', ' . $data;
		}

		if ( '' !== $luogo ) {
			return $luogo;
		}

		if ( '' !== $data ) {
			return $data;
		}

		// Nessun ripiego sulla didascalia nativa di WordPress: quella appartiene
		// alla didascalia che si apre con la foto (vedi ptf_media_didascalia()).
		// Altrimenti lo stesso testo comparirebbe due volte.
		return '';
	}
}

if ( ! function_exists( 'ptf_media_didascalia' ) ) {
	/**
	 * Didascalia da mostrare quando la foto viene aperta a schermo intero.
	 *
	 * È un campo distinto da Luogo/Data: quelli restano nel riquadro in basso a
	 * destra sulla miniatura, questa è la descrizione più lunga della foto.
	 * Se il campo è vuoto ricade sulla didascalia nativa di WordPress.
	 *
	 * @param int $attachment_id ID dell'allegato.
	 * @return string
	 */
	function ptf_media_didascalia( $attachment_id ) : string {
		$attachment_id = (int) $attachment_id;

		if ( $attachment_id <= 0 ) {
			return '';
		}

		$testo = trim( (string) get_post_meta( $attachment_id, '_ptf_media_didascalia', true ) );

		if ( '' !== $testo ) {
			return $testo;
		}

		$nativa = wp_get_attachment_caption( $attachment_id );

		return is_string( $nativa ) ? trim( $nativa ) : '';
	}
}

if ( ! function_exists( 'ptf_media_caption_badge' ) ) {
	/**
	 * Stampa il riquadro didascalia (stile pagina "Patriziato").
	 *
	 * Stampa solo il markup con la classe .ptf-caption-badge: il posizionamento e
	 * l'aspetto sono definiti nel blocco <style> del template che la usa, perché
	 * ogni contesto (home, griglia galleria) ha bisogno di un ancoraggio diverso.
	 * Se il testo è vuoto non stampa nulla.
	 *
	 * @param string $testo       Testo già pronto (vedi ptf_media_caption()).
	 * @param string $extra_class Classe aggiuntiva opzionale per varianti locali.
	 * @return void
	 */
	function ptf_media_caption_badge( $testo, $extra_class = '' ) {
		$testo = trim( (string) $testo );

		if ( '' === $testo ) {
			return;
		}

		$classi = 'ptf-caption-badge';

		if ( '' !== $extra_class ) {
			$classi .= ' ' . $extra_class;
		}

		printf(
			'<div class="%1$s">%2$s</div>',
			esc_attr( $classi ),
			esc_html( $testo )
		);
	}
}
