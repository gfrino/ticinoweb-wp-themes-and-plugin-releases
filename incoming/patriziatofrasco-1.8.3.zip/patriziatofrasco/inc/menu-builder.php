<?php
/**
 * Ricostruzione del menu di navigazione del sito.
 *
 * Prima questa logica stava in build_menu.php nella cartella del tema, che sul
 * server era raggiungibile digitando il suo indirizzo. Ora si esegue solo dal
 * pannello, con controllo dei permessi.
 *
 * @package patriziatofrasco
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Ricostruisce da zero il menu del sito e lo aggancia alle posizioni del tema.
 *
 * @return bool True se la ricostruzione è andata a termine.
 */
function ptf_ricostruisci_menu() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return false;
	}
	$menu_name = 'Menu'; // The existing menu name from the audit
	$menu = wp_get_nav_menu_object($menu_name);

	if (!$menu) {
	    // Se non esiste, lo creo
	    $menu_id = wp_create_nav_menu($menu_name);
	} else {
	    $menu_id = $menu->term_id;
	    // Rimuovo tutti gli elementi vecchi per ricrearlo pulito
	    $menu_items = wp_get_nav_menu_items($menu_id);
	    foreach ($menu_items as $item) {
	        wp_delete_object_term_relationships($item->ID, 'nav_menu');
	        wp_delete_post($item->ID, true);
	    }
	}

	// Helper per trovare l'ID della pagina in modo sicuro
	function get_page_id_by_slugs($slugs) {
	    if (!is_array($slugs)) $slugs = [$slugs];
	    foreach ($slugs as $slug) {
	        $page = get_page_by_path($slug);
	        if ($page) return $page->ID;
	    }
	    return 0; // fallback
	}

	// Struttura del menu del cliente
	$menu_structure = [
	    [
	        'title' => 'Home', 'slugs' => ['home'], 'children' => []
	    ],
	    [
	        'title' => 'Patriziato', 'slugs' => ['patriziato'],
	        'children' => [
	            ['title' => 'Organizzazione', 'slugs' => ['organizzazione', 'la-nostra-missione']],
	            ['title' => 'Chi siamo', 'slugs' => ['chi-siamo']],
	            ['title' => 'Famiglie patrizie', 'slugs' => ['famiglie-patrizie']]
	        ]
	    ],
	    [
	        'title' => 'Territorio', 'slugs' => ['territorio'],
	        'children' => [
	            ['title' => 'Capanne', 'slugs' => ['capanne', 'sentieri-e-capanne']],
	            ['title' => 'Sentieri', 'slugs' => ['sentieri']],
	            ['title' => 'Punti di interesse', 'slugs' => ['punti-di-interesse']],
	            ['title' => 'Pubblicazioni', 'slugs' => ['pubblicazioni']]
	        ]
	    ],
	    [
	        'title' => 'Albo patriziale', 'slugs' => ['albo-patriziale'],
	        'children' => [
	            ['title' => 'Regolamento', 'slugs' => ['regolamento']],
	            ['title' => 'Leggi e ordinanze', 'slugs' => ['leggi-e-ordinanze']],
	            ['title' => 'Messaggi e decreti', 'slugs' => ['messaggi-e-decreti']],
	            ['title' => 'Interpellanze', 'slugs' => ['interpellanze']],
	            ['title' => 'Mozioni', 'slugs' => ['mozioni']],
	            ['title' => 'Comunicazioni', 'slugs' => ['comunicazioni', 'cumunicati']],
	            ['title' => 'Attività', 'slugs' => ['attivita']]
	        ]
	    ],
	    [
	        'title' => 'Galleria', 'slugs' => ['galleria'],
	        'children' => [
	            ['title' => 'Foto d\'altri tempi', 'slugs' => ['foto-d-altri-tempi']],
	            ['title' => 'Feste e attività', 'slugs' => ['feste-e-attivita']]
	        ]
	    ],
	    [
	        'title' => 'Rifugio Alpe Costa', 'slugs' => ['rifugio-alpe-costa'], 'children' => []
	    ],
	    [
	        'title' => 'Contatti', 'slugs' => ['contatti'],
	        'children' => [
	            ['title' => 'Formulari', 'slugs' => ['formulari']],
	            ['title' => 'Contatti Ufficio Patriziale', 'slugs' => ['contatti-ufficio-patriziale']]
	        ]
	    ],
	    [
	        'title' => 'Shop', 'slugs' => ['shop', 'prodotti'], 'children' => []
	    ]
	];

	// Inserimento degli elementi nel menu
	foreach ($menu_structure as $parent_item) {
	    $parent_page_id = get_page_id_by_slugs($parent_item['slugs']);
    
	    // Se la pagina genitore esiste
	    if ($parent_page_id) {
	        $parent_menu_item_id = wp_update_nav_menu_item($menu_id, 0, array(
	            'menu-item-title' => $parent_item['title'],
	            'menu-item-object-id' => $parent_page_id,
	            'menu-item-object' => 'page',
	            'menu-item-status' => 'publish',
	            'menu-item-type' => 'post_type',
	        ));
        
	        // Aggiungi i figli
	        if (!empty($parent_item['children'])) {
	            foreach ($parent_item['children'] as $child_item) {
	                $child_page_id = get_page_id_by_slugs($child_item['slugs']);
	                if ($child_page_id) {
	                    wp_update_nav_menu_item($menu_id, 0, array(
	                        'menu-item-title' => $child_item['title'],
	                        'menu-item-object-id' => $child_page_id,
	                        'menu-item-object' => 'page',
	                        'menu-item-status' => 'publish',
	                        'menu-item-type' => 'post_type',
	                        'menu-item-parent-id' => $parent_menu_item_id, // Associa come figlio!
	                    ));
	                }
	            }
	        }
	    }
	}

	// Assicuriamoci che il menu sia assegnato alla location primaria del tema genitore
	$locations = get_theme_mod('nav_menu_locations');
	// La location nei temi standard di solito è 'primary' o 'menu-1'
	$locations['primary'] = $menu_id;
	$locations['menu-1'] = $menu_id;
	set_theme_mod('nav_menu_locations', $locations);

	return true;

}
