<?php
/**
 * Template Name: Dettaglio Punto di Interesse
 */
get_header();

// Fetch meta values
$hero_img = has_post_thumbnail() ? get_the_post_thumbnail_url( get_the_ID(), 'full' ) : parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) . '/2026/06/Logo-hd.png';
$subtitle = get_post_meta( get_the_ID(), '_interesse_subtitle', true );
$action_url = get_post_meta( get_the_ID(), '_interesse_action_url', true );
$action_text = get_post_meta( get_the_ID(), '_interesse_action_text', true ) ?: 'Contatta ora';
$action_subtext = get_post_meta( get_the_ID(), '_interesse_action_subtext', true );
$maps_query = get_post_meta( get_the_ID(), '_interesse_maps_query', true );

$photo_credit = '';
for ($i = 1; $i <= 10; $i++) {
    $lbl = get_post_meta( get_the_ID(), '_interesse_info_label_' . $i, true );
    if ( strtolower($lbl) === 'fotografie' || strtolower($lbl) === 'foto' ) {
        $photo_credit = get_post_meta( get_the_ID(), '_interesse_info_value_' . $i, true );
        break;
    }
}
?>

<style>
/* CSS identical to single-sentiero.php */
.rifugio-layout {
    display: grid;
    grid-template-columns: 1fr 420px;
    gap: var(--space-xl);
    /* Poco spazio in alto: fra il banner e il primo titolo restava una fascia
       bianca molto ampia. Lo spazio sotto resta generoso. */
    padding: 24px var(--space-md) var(--space-xl);
}

.rifugio-sidebar p {
    font-size: 0.95rem;
}

/* Content Images Migrated (es. Tutti al Bosco) */
.rifugio-main-content .content-image {
    max-width: 500px;
    width: 100%;
    height: auto;
    border-radius: var(--radius);
    margin: var(--space-md) auto;
    display: block;
    box-shadow: 0 5px 20px rgba(0,0,0,0.08);
}

.rifugio-main-content .cerebral-logo {
    max-width: 200px;
    height: auto;
    margin: var(--space-xl) auto 0;
    display: block;
}

.rifugio-main-content {
    font-size: 1.15rem;
    line-height: 1.8;
}

.rifugio-main-content h4, .rifugio-main-content h3 {
    color: var(--color-primary);
    font-size: 1.5rem;
    margin: var(--space-lg) 0 var(--space-sm) 0;
    padding-bottom: var(--space-xs);
    border-bottom: 2px solid var(--color-bg-body);
}

.rifugio-main-content h3 {
    font-size: 2rem;
    color: var(--color-primary-dark);
    border-bottom: none;
}

.rifugio-main-content ul {
    list-style: none;
    padding: 0;
    margin-bottom: var(--space-lg);
}

.rifugio-main-content ul li {
    padding: var(--space-xs) 0;
    border-bottom: 1px solid rgba(0,0,0,0.05);
    display: flex;
    gap: var(--space-sm);
}

.rifugio-main-content ul li::before {
    content: "";
    display: inline-block;
    min-width: 18px;
    height: 18px;
    margin-top: 4px;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%233c69e7'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='3' d='M5 13l4 4L19 7'%3E%3C/path%3E%3C/svg%3E");
    background-size: contain;
    background-repeat: no-repeat;
}

/* Sidebar and Tech Details */
.rifugio-sidebar {
    position: sticky;
    top: 100px;
    height: fit-content;
}

.tech-details {
    background: var(--color-bg-pure-white);
    padding: 25px;
    border-radius: var(--radius);
    box-shadow: 0 10px 30px rgba(0,0,0,0.08);
    border-top: 4px solid var(--color-accent);
    margin-bottom: var(--space-lg);
}

.tech-details ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

.tech-details li {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 15px;
    padding: 12px 0;
    border-bottom: 1px solid rgba(0,0,0,0.05);
    font-size: 1.05rem;
}

.tech-details li.col-layout {
    flex-direction: column;
    align-items: flex-start;
    gap: 5px;
}

.tech-details li:last-child {
    border-bottom: none;
}

.tech-details li strong {
    color: var(--color-primary-dark);
    flex-shrink: 0;
}

.tech-details li > span, .tech-details li > div {
    text-align: right;
}

.tech-details li.col-layout > span, .tech-details li.col-layout > div {
    text-align: left;
    width: 100%;
}

.btn-prenota {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    background: var(--color-primary);
    color: #FFFFFF !important;
    padding: 15px 20px;
    font-size: 1.05rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 1px;
    white-space: nowrap;
    text-decoration: none;
    border-radius: var(--radius);
    transition: all 0.3s ease;
    box-shadow: 0 8px 20px rgba(14,42,102,0.15);
    width: 100%;
}

.btn-prenota:hover {
    background: var(--color-primary-light);
    transform: translateY(-3px);
    box-shadow: 0 12px 25px rgba(14,42,102,0.25);
}

.sidebar-map {
    margin-top: var(--space-lg);
    border-radius: var(--radius);
    overflow: hidden;
}

/* Gallery and Steps used in content */
.rifugio-gallery {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
    gap: 15px;
    margin-top: 20px;
    margin-bottom: 40px;
}

.rifugio-gallery a {
    display: block;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 4px 15px rgba(0,0,0,0.08);
}

.rifugio-gallery img {
    width: 100%;
    height: 140px;
    object-fit: cover;
    display: block;
    transition: transform 0.3s ease;
}

.rifugio-gallery a:hover img {
    transform: scale(1.05);
}

/* Galleria WordPress: cliccabile per lightbox */
.wp-block-gallery img {
    cursor: pointer;
    transition: transform 0.3s ease;
}
.wp-block-gallery figure:hover img {
    transform: scale(1.05);
}

/* Lightbox Styles */
.lightbox {
    position: fixed;
    z-index: 99999;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0,0,0,0.92);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    pointer-events: none;
    transition: opacity 0.3s ease;
}
.lightbox.active {
    opacity: 1;
    pointer-events: auto;
}
.lightbox img {
    max-width: 90%;
    max-height: 90vh;
    border-radius: 4px;
    box-shadow: 0 10px 50px rgba(0,0,0,0.8);
    transition: transform 0.3s ease;
}
.lightbox-close {
    position: absolute;
    top: 20px;
    right: 30px;
    color: white;
    font-size: 45px;
    cursor: pointer;
    line-height: 1;
    user-select: none;
    transition: color 0.2s;
}
.lightbox-close:hover { color: var(--color-accent); }
.lightbox-prev, .lightbox-next {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    color: white;
    font-size: 50px;
    cursor: pointer;
    padding: 20px;
    user-select: none;
    transition: color 0.2s;
}
.lightbox-prev { left: 20px; }
.lightbox-next { right: 20px; }
.lightbox-prev:hover, .lightbox-next:hover { color: var(--color-accent); }

@media (max-width: 992px) {
    .rifugio-layout {
        grid-template-columns: 1fr;
    }
    .rifugio-sidebar {
        position: static;
        margin-top: var(--space-lg);
    }
}
</style>

<header class="page-header-cinematic has-bg" style="background-image: url('<?php echo esc_url($hero_img); ?>'); background-position: center;">
    <div class="page-header-overlay"></div>
    <div class="container page-header-inner animate-on-scroll" style="text-align: left;">
        <h1 class="page-title" style="margin-bottom: 0;"><?php the_title(); ?></h1>
        <?php if($subtitle): ?>
            <p style="font-size: 1.2rem; opacity: 0.9; margin-top: 10px; color: #FFFFFF;"><?php echo esc_html($subtitle); ?></p>
        <?php endif; ?>
    </div>
</header>

<main id="primary" class="site-main">
    <div class="container rifugio-layout">
        
        <div class="rifugio-main-content animate-on-scroll">
            <?php 
            global $post;
            $current_post_id = $post->ID;
            while ( have_posts() ) :
                the_post();
                $content = get_the_content();
                $content = apply_filters('the_content', $content);
                
                // Proteggi le gallerie: estraile temporaneamente
                $gallery_placeholders = [];
                $content = preg_replace_callback(
                    '/<figure[^>]*class="[^"]*wp-block-gallery[^"]*"[^>]*>.*?<\/figure>/is',
                    function($match) use (&$gallery_placeholders) {
                        $key = '<!--GALLERY_' . count($gallery_placeholders) . '-->';
                        $gallery_placeholders[$key] = $match[0];
                        return $key;
                    },
                    $content
                );
                // Proteggi anche .rifugio-gallery
                $content = preg_replace_callback(
                    '/<div[^>]*class="[^"]*rifugio-gallery[^"]*"[^>]*>.*?<\/div>/is',
                    function($match) use (&$gallery_placeholders) {
                        $key = '<!--GALLERY_' . count($gallery_placeholders) . '-->';
                        $gallery_placeholders[$key] = $match[0];
                        return $key;
                    },
                    $content
                );
                
                // Anti-clic SOLO sulle immagini fuori dalla galleria
                $content = preg_replace('/<a\b[^>]*>\s*(<img[^>]+>)\s*<\/a>/i', '$1', $content);
                $content = preg_replace_callback('/<img([^>]+)>/i', function($matches) {
                    $attrs = $matches[1];
                    if (preg_match('/style\s*=/i', $attrs)) {
                        $attrs = preg_replace('/(style\s*=\s*["\'])([^"\']*)/i', '$1pointer-events:none;cursor:default;$2', $attrs);
                    } else {
                        $attrs .= ' style="pointer-events:none;cursor:default;"';
                    }
                    return '<img' . $attrs . '>';
                }, $content);
                
                // Reinserisci le gallerie intatte
                foreach ($gallery_placeholders as $key => $gallery_html) {
                    $content = str_replace($key, $gallery_html, $content);
                }
                
                $content = str_replace(']]>', ']]&gt;', $content);
                echo $content;
            endwhile; 
            ?>
        </div>

        <div class="rifugio-sidebar animate-on-scroll">
            
            <?php
            // Check if there are any tech details filled out
            $has_tech_details = false;
            for($i=1; $i<=10; $i++) {
                if(get_post_meta( $current_post_id, '_interesse_info_label_'.$i, true ) != '') {
                    $has_tech_details = true;
                    break;
                }
            }
            
            if($has_tech_details):
            ?>
            <!-- Informazioni Card -->
            <div class="tech-details">
                <h3 style="color: var(--color-primary-dark); margin-bottom: 1rem; text-align: center;">Informazioni</h3>
                <ul>
                    <?php 
                    for($i=1; $i<=10; $i++): 
                        $lbl = get_post_meta( $current_post_id, '_interesse_info_label_'.$i, true );
                        $val = get_post_meta( $current_post_id, '_interesse_info_value_'.$i, true );
                        if($lbl || $val):
                            // Se il valore contiene una lista o <ul>, usiamo col-layout per incolonnarlo sotto il titolo
                            $layout_class = strpos($val, '<ul') !== false ? 'col-layout' : '';
                    ?>
                    <li class="<?php echo $layout_class; ?>">
                        <strong><?php echo esc_html($lbl); ?></strong> 
                        <span><?php echo wp_kses_post($val); ?></span>
                    </li>
                    <?php 
                        endif;
                    endfor; 
                    ?>
                </ul>
            </div>
            <?php endif; ?>

            <?php if($action_url || $maps_query): ?>
            <!-- Contatto e Map Widget -->
            <div style="background: var(--color-bg-pure-white); padding: 25px; border-radius: var(--radius); box-shadow: 0 10px 30px rgba(0,0,0,0.08); border-top: 4px solid var(--color-primary); position: sticky; top: 100px;">
                
                <?php if($action_url): ?>
                    <a href="<?php echo esc_url($action_url); ?>" target="_blank" rel="noopener" class="btn-prenota">
                        <?php if (strpos($action_url, 'tel:') !== false): ?>
                            <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path></svg>
                        <?php elseif (strpos($action_url, 'mailto:') !== false): ?>
                            <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
                        <?php else: ?>
                            <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"></path></svg>
                        <?php endif; ?>
                        <?php echo esc_html($action_text); ?>
                    </a>
                    
                    <?php if($action_subtext): ?>
                        <p style="text-align: center; color: var(--color-text-light); margin-top: 10px; font-size: 0.9rem; margin-bottom:0;"><?php echo esc_html($action_subtext); ?></p>
                    <?php endif; ?>
                <?php endif; ?>

                <?php if($maps_query): ?>
                    <div class="sidebar-map" style="<?php echo $action_url ? 'margin-top: var(--space-lg);' : ''; ?> position: relative; text-align: center;">
                        <a href="#" id="open-map-lightbox" data-map-src="https://maps.google.com/maps?q=<?php echo urlencode($maps_query); ?>&t=m&z=15&output=embed&iwloc=near" style="text-decoration: none; display: block;">
                            <iframe loading="lazy" src="https://maps.google.com/maps?q=<?php echo urlencode($maps_query); ?>&t=m&z=15&output=embed&iwloc=near" title="Mappa" width="100%" height="250" style="border:0; pointer-events: none;" allowfullscreen="" loading="lazy"></iframe>
                            <span style="font-size: 0.95rem; color: var(--color-primary); font-weight: 500; display: inline-block; margin-top: 12px; margin-bottom: 8px;"><em>Clicca sulla mappa per ingrandirla a tutto schermo</em> <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle;"><path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/></svg></span>
                        </a>
                    </div>
                <?php endif; ?>

            </div>
            <?php endif; ?>

        </div>

    </div>
</main>

<!-- Lightbox HTML for Map -->
<div class="lightbox" id="map-lightbox">
    <span class="lightbox-close" onclick="closeMapLightbox()">&times;</span>
    <div class="lightbox-map-container" style="width: 90%; max-width: 1000px; height: 80vh; background: white; border-radius: 8px; overflow: hidden; position: relative;">
        <iframe id="lightbox-map-iframe" src="" style="border:0; width:100%; height:100%;" allowfullscreen="" loading="lazy"></iframe>
    </div>
</div>

<!-- Lightbox HTML for Gallery -->
<div class="lightbox" id="gallery-lightbox">
    <span class="lightbox-close" id="gallery-lb-close">&times;</span>
    <span class="lightbox-prev" id="gallery-lb-prev">&#10094;</span>
    <span class="lightbox-next" id="gallery-lb-next">&#10095;</span>
    <img id="gallery-lb-img" src="" alt="">
    <div style="position:absolute; bottom:20px; color:rgba(255,255,255,0.7); font-size:0.9rem;" id="gallery-lb-counter"></div>
    <?php if ( $photo_credit ) : ?>
        <div style="position:absolute; bottom:45px; left:0; right:0; text-align:center; color:rgba(255,255,255,0.85); font-size:0.95rem; font-family: var(--font-body); pointer-events: none;" id="gallery-lb-credit">
            Foto: <?php echo esc_html( strip_tags( $photo_credit ) ); ?>
        </div>
    <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {

    // ========== MAP LIGHTBOX ==========
    const mapLink = document.getElementById('open-map-lightbox');
    const mapLightbox = document.getElementById('map-lightbox');
    const mapIframe = document.getElementById('lightbox-map-iframe');

    if (mapLink && mapLightbox && mapIframe) {
        mapLink.addEventListener('click', function(e) {
            e.preventDefault();
            mapIframe.src = this.getAttribute('data-map-src');
            mapLightbox.classList.add('active');
            document.body.style.overflow = 'hidden';
        });

        window.closeMapLightbox = function() {
            mapLightbox.classList.remove('active');
            document.body.style.overflow = '';
            setTimeout(function() { mapIframe.src = ''; }, 300);
        }

        mapLightbox.addEventListener('click', function(e) {
            if (e.target === mapLightbox || e.target.classList.contains('lightbox-map-container')) {
                closeMapLightbox();
            }
        });
    }

    // ========== GALLERY LIGHTBOX ==========
    var galLb = document.getElementById('gallery-lightbox');
    var galImg = document.getElementById('gallery-lb-img');
    var galCounter = document.getElementById('gallery-lb-counter');
    var galImages = [];
    var galIndex = 0;

    // Trova tutte le immagini nelle gallerie (sia .rifugio-gallery che .wp-block-gallery)
    // Eseguiamo con ritardo per assicurarci che giri DOPO killImageLinks del header.php
    function setupGalleryLightbox() {
        var galleries = document.querySelectorAll('.rifugio-gallery, .wp-block-gallery');
        galleries.forEach(function(gallery) {
            var imgs = gallery.querySelectorAll('img');
            imgs.forEach(function(img) {
                // Salta se già configurata
                if (img.dataset.galleryReady) return;
                img.dataset.galleryReady = 'true';

                // Trova il src alla massima risoluzione
                var fullSrc = img.getAttribute('data-full-url') || img.getAttribute('data-orig-file') || img.getAttribute('src') || '';
                var originalSrc = fullSrc.replace(/-\d+x\d+(?=\.[a-z]+$)/i, '');
                galImages.push(originalSrc);

                // FORZA cliccabilità (override di qualsiasi script precedente)
                img.style.setProperty('pointer-events', 'auto', 'important');
                img.style.setProperty('cursor', 'pointer', 'important');

                // Blocca il link <a> se presente
                var parent = img.parentElement;
                if (parent && parent.tagName.toLowerCase() === 'a') {
                    parent.style.setProperty('pointer-events', 'auto', 'important');
                    parent.addEventListener('click', function(e) { e.preventDefault(); });
                }

                var idx = galImages.length - 1;
                img.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    e.stopImmediatePropagation();
                    openGalleryLightbox(idx);
                });
            });
        });
    }

    // Esegui subito e poi di nuovo dopo i delay di killImageLinks
    setupGalleryLightbox();
    setTimeout(setupGalleryLightbox, 600);
    setTimeout(setupGalleryLightbox, 1600);

    function openGalleryLightbox(index) {
        galIndex = index;
        galImg.src = galImages[galIndex];
        galCounter.textContent = (galIndex + 1) + ' / ' + galImages.length;
        galLb.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function closeGalleryLightbox() {
        galLb.classList.remove('active');
        document.body.style.overflow = '';
        galImg.src = '';
    }

    function changeGalleryImage(direction) {
        galIndex = (galIndex + direction + galImages.length) % galImages.length;
        galImg.src = galImages[galIndex];
        galCounter.textContent = (galIndex + 1) + ' / ' + galImages.length;
    }

    document.getElementById('gallery-lb-close').addEventListener('click', closeGalleryLightbox);
    document.getElementById('gallery-lb-prev').addEventListener('click', function() { changeGalleryImage(-1); });
    document.getElementById('gallery-lb-next').addEventListener('click', function() { changeGalleryImage(1); });

    galLb.addEventListener('click', function(e) {
        if (e.target === galLb) closeGalleryLightbox();
    });

    // Tastiera: frecce + ESC
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            if (mapLightbox && mapLightbox.classList.contains('active')) closeMapLightbox();
            if (galLb && galLb.classList.contains('active')) closeGalleryLightbox();
        }
        if (galLb && galLb.classList.contains('active')) {
            if (e.key === 'ArrowRight') changeGalleryImage(1);
            if (e.key === 'ArrowLeft') changeGalleryImage(-1);
        }
    });
});
</script>

<?php get_footer(); ?>
