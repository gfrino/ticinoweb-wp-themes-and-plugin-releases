<?php
/**
 * The template for displaying all single posts
 *
 * @package Patriziato Frasco
 */

get_header();
?>

<main id="primary" class="site-main">

	<?php
	while ( have_posts() ) :
		the_post();
		?>
		
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			
			<?php 
			$has_thumbnail = has_post_thumbnail();
			$is_comunicato = (get_post_type() === 'comunicato');
			
			if ($is_comunicato) {
				$header_class = 'page-header-cinematic no-bg';
				$bg_style = '';
			} else {
				$thumbnail_url = $has_thumbnail ? get_the_post_thumbnail_url(get_the_ID(), 'full') : '';
				$header_class = $has_thumbnail ? 'page-header-cinematic has-bg' : 'page-header-cinematic no-bg';
				$bg_style = $has_thumbnail ? 'style="background-image: url(\'' . esc_url($thumbnail_url) . '\');"' : '';
			}
			?>
			<header class="<?php echo esc_attr($header_class); ?>" <?php echo wp_kses_post($bg_style); ?>>
				<div class="page-header-overlay"></div>
				<div class="container page-header-inner animate-on-scroll">
					<span class="post-date" style="display:block; font-size:0.9rem; font-family:var(--font-body); color:rgba(255,255,255,0.7); text-transform:uppercase; letter-spacing:0.1em; margin-bottom:10px;"><?php echo get_the_date(); ?></span>
					<?php the_title( '<h1 class="page-title">', '</h1>' ); ?>
				</div>
			</header>

			<div class="page-content-wrapper" style="margin-top: var(--space-xl); margin-bottom: var(--space-xxl);">
				<div class="page-content custom-gutenberg-layout" style="font-size: 1.1rem; line-height: 1.8;">
				<?php
				// For comunicato, show the image inside the content area nicely
				if ($is_comunicato && $has_thumbnail) {
					echo '<div class="comunicato-single-image" style="margin-bottom: 2rem; text-align: center;">';
					the_post_thumbnail('large', array('style' => 'max-height: 400px; width: auto; max-width: 100%; border-radius: var(--radius); display: inline-block; box-shadow: 0 4px 15px rgba(0,0,0,0.05);'));
					echo '</div>';
				}
				
				the_content();

				wp_link_pages(
					array(
						'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'patriziatofrasco' ),
						'after'  => '</div>',
					)
				);
				?>
				</div><!-- .page-content -->
			</div><!-- .page-content-wrapper -->
		</article><!-- #post-<?php the_ID(); ?> -->

		<?php
	endwhile; // End of the loop.
	?>

</main><!-- #main -->

<?php
get_footer();
