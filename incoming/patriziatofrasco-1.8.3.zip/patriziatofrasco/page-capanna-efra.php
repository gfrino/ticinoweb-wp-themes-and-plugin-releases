<?php
/**
 * Template Name: Capanna Efra
 */
get_header();

// Temporary placeholder image, update when ready
$hero_img = parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) . '/2026/06/imgi_2_bb5e3eefdc605295c0c3e6327b5c5441b60c9c85-800x600-1.webp';
$booking_link = 'https://www.verzasca.net/reserve-online.php?submitted=1&article_id=130&site_id=1929&resource_id=4675';
?>

<style>
.rifugio-layout {
    display: grid;
    grid-template-columns: 1fr 420px;
    gap: var(--space-xl);
    padding: var(--space-xl) 0;
}

.rifugio-main-content {
    font-size: 1.15rem;
    line-height: 1.8;
}

.rifugio-main-content h4 {
    color: var(--color-primary);
    font-size: 1.5rem;
    margin: var(--space-lg) 0 var(--space-sm) 0;
    padding-bottom: var(--space-xs);
    border-bottom: 2px solid var(--color-bg-body);
}

.rifugio-main-content ul {
    list-style: none;
    padding: 0;
    margin-bottom: var(--space-lg);
}

.rifugio-main-content ul li {
    padding: var(--space-xs) 0;
    border-bottom: 1px solid rgba(0,0,0,0.05);
    display: flex;
    gap: var(--space-sm);
}

.rifugio-main-content ul li::before {
    content: "";
    display: inline-block;
    min-width: 18px;
    height: 18px;
    margin-top: 4px;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%233c69e7'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='3' d='M5 13l4 4L19 7'%3E%3C/path%3E%3C/svg%3E");
    background-size: contain;
    background-repeat: no-repeat;
}

/* Booking Widget Card */
.rifugio-sidebar {
    position: sticky;
    top: 100px;
    height: fit-content;
}

.btn-prenota {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    background: var(--color-primary);
    color: #FFFFFF !important;
    padding: 15px 20px;
    font-size: 1.05rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 1px;
    white-space: nowrap;
    text-decoration: none;
    border-radius: var(--radius);
    transition: all 0.3s ease;
    box-shadow: 0 8px 20px rgba(14,42,102,0.15);
    width: 100%;
}

.btn-prenota:hover {
    background: var(--color-primary-light);
    transform: translateY(-3px);
    box-shadow: 0 12px 25px rgba(14,42,102,0.25);
}

.sidebar-map {
    margin-top: var(--space-lg);
    border-radius: var(--radius);
    overflow: hidden;
}

/* Sidebar Tech Details */
.tech-details {
    background: var(--color-bg-pure-white);
    padding: 25px;
    border-radius: var(--radius);
    box-shadow: 0 10px 30px rgba(0,0,0,0.08);
    border-top: 4px solid var(--color-accent);
    margin-bottom: var(--space-lg);
}

.tech-details ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

.tech-details li {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 15px;
    padding: 12px 0;
    border-bottom: 1px solid rgba(0,0,0,0.05);
    font-size: 1.05rem;
}

.tech-details li:last-child {
    border-bottom: none;
}

.tech-details li strong {
    color: var(--color-primary-dark);
    flex-shrink: 0;
}

.tech-details li > span {
    text-align: right;
}

.diff-badge {
    background: #cc0000;
    color: white;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 0.9rem;
    font-weight: bold;
}

@media (max-width: 992px) {
    .rifugio-layout {
        grid-template-columns: 1fr;
    }
    .rifugio-sidebar {
        position: static;
        margin-top: var(--space-lg);
    }
}

/* Gallery Grid */
.rifugio-gallery {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
    gap: 15px;
    margin-top: 20px;
}

.rifugio-gallery a {
    display: block;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 4px 15px rgba(0,0,0,0.08);
}

.rifugio-gallery img {
    width: 100%;
    height: 140px;
    object-fit: cover;
    display: block;
    transition: transform 0.3s ease;
}

.rifugio-gallery a:hover img {
    transform: scale(1.05);
}

/* Lightbox Styles */
.lightbox {
    position: fixed;
    z-index: 99999;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0,0,0,0.92);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    pointer-events: none;
    transition: opacity 0.3s ease;
}
.lightbox.active {
    opacity: 1;
    pointer-events: auto;
}
.lightbox img {
    max-width: 90%;
    max-height: 90vh;
    border-radius: 4px;
    box-shadow: 0 10px 50px rgba(0,0,0,0.8);
    transition: transform 0.3s ease;
}
.lightbox-close {
    position: absolute;
    top: 20px;
    right: 30px;
    color: white;
    font-size: 45px;
    cursor: pointer;
    line-height: 1;
    user-select: none;
    transition: color 0.2s;
}
.lightbox-close:hover { color: var(--color-accent); }
.lightbox-prev, .lightbox-next {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    color: white;
    font-size: 50px;
    cursor: pointer;
    padding: 20px;
    user-select: none;
    transition: color 0.2s;
}
.lightbox-prev { left: 20px; }
.lightbox-next { right: 20px; }
.lightbox-prev:hover, .lightbox-next:hover { color: var(--color-accent); }
</style>

<header class="page-header-cinematic has-bg" style="background-image: url('<?php echo esc_url($hero_img); ?>'); background-position: center;">
    <div class="page-header-overlay"></div>
    <div class="container page-header-inner animate-on-scroll" style="text-align: left;">
        <h1 class="page-title" style="margin-bottom: 0;">Capanna Efra</h1>
        <p style="font-size: 1.2rem; opacity: 0.9; margin-top: 10px; color: #FFFFFF;">2.039 m s/m - Val d'Efra</p>
    </div>
</header>

<main id="primary" class="site-main">
    <div class="container rifugio-layout">
        
        <div class="rifugio-main-content animate-on-scroll">
            <h3 style="color: var(--color-primary-dark); font-size: 2rem; margin-bottom: var(--space-md);">Descrizione</h3>
            <p><strong>La capanna è il risultato della trasformazione di due stabili del Corte di Cima.</strong></p>
            <p>Isolazione termica, illuminazione elettrica con pannelli solari, acqua corrente interna per cucina e servizi, stufa economica a legna per cucina e riscaldamento. Moderno dormitorio con 25 posti letto con materassi e coperte.</p>
            <p>L'antico rifugio degli alpigiani si trova nella Val d'Efra a 2.039 m. È aperto da metà giugno a fine ottobre, ma senza la presenza del guardiano.</p>
            <p>È dotato di una cucina con acqua corrente, legna e gas. I 25 posti letto sono attrezzati con coperte di lana. Al rifugio si giunge in 3 ore e 30 con un'escursione attraverso la Val d'Efra, oppure in 5 ore e 30 / 6 ore e 30 attraversando la Val d'Ambra. Il bosco di larici e un piccolo lago nei pressi del rifugio rendono il paesaggio ancor più idilliaco.</p>

            <h4 style="margin-top: var(--space-xxl);">TRAVERSATE</h4>
            <ul>
                <li><strong>Alla capanna Cognora</strong> attraverso il Cramosino, Madom Gróss, Pizzo Mezzodì agibile solo per alpinisti esperti (VAV).</li>
                <li><strong>All'alpe Fümegna</strong>, 8 ore, con passaggi esposti (VAV) attraverso il Passo del Gagnone (2217 m).</li>
            </ul>

            <h4 style="margin-top: var(--space-xl);">ESCURSIONI</h4>
            <p style="margin-bottom: var(--space-lg);">Da Frasco attraverso la capanna Efra fino a Lavertezzo – passo Gagnone – Scaie (2457 m) – Mazer (2100 m) passando per la Val d'Agro.</p>

            <h4 style="margin-top: var(--space-xl);">ASCENSIONI</h4>
            <ul>
                <li>Cima di Gagnone (2518 m) segnata in bianco e rosso</li>
                <li>Cima Scaie (2457 m) segnata in bianco e rosso</li>
                <li>Cima d'Efra (2577 m)</li>
                <li>Basai (2587 m)</li>
                <li>Nedro (2622 m)</li>
                <li>Cramosino (2718 m)</li>
                <li>Madom Gróss (2741 m)</li>
            </ul>
            
            <p style="margin-top: var(--space-xl);">Periodo apertura, prezzi e altre informazioni: <a href="https://www.capanneti.ch/it/capanne/efra" target="_blank" rel="noopener" style="color: var(--color-primary); font-weight: bold; text-decoration: underline;">clicca qui</a></p>
            <p style="margin-top: var(--space-md);">Sito web ufficiale SEV: <a href="https://www.sev-verzasca.ch/efra" target="_blank" rel="noopener" style="color: var(--color-primary); font-weight: bold; text-decoration: underline;">www.sev-verzasca.ch/efra</a></p>

            <h4 style="margin-top: var(--space-xl);">GALLERIA COMPLETA</h4>
            <div class="rifugio-gallery">
                <a href="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/imgi_2_bb5e3eefdc605295c0c3e6327b5c5441b60c9c85-800x600-1.webp" target="_blank"><img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/imgi_2_bb5e3eefdc605295c0c3e6327b5c5441b60c9c85-800x600-1.webp"></a>
                <a href="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/imgi_3_be61d8e231d14a28f42a73a8b9ff0bce266d122c-800x600-1.webp" target="_blank"><img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/imgi_3_be61d8e231d14a28f42a73a8b9ff0bce266d122c-800x600-1.webp"></a>
                <a href="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/imgi_4_f62aa8e3db767a7e07e14163662d77f890469a77-800x600-1.webp" target="_blank"><img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/imgi_4_f62aa8e3db767a7e07e14163662d77f890469a77-800x600-1.webp"></a>
                <a href="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/imgi_41_db0e4ca44df033a9b93d09e73c0a70abba93133f-640x480-1.webp" target="_blank"><img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/imgi_41_db0e4ca44df033a9b93d09e73c0a70abba93133f-640x480-1.webp"></a>
                <a href="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/imgi_42_5323700df648f7d700729626d4ba02ea9e332068-1280x854-1.webp" target="_blank"><img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/imgi_42_5323700df648f7d700729626d4ba02ea9e332068-1280x854-1.webp"></a>
            </div>
        </div>

        <div class="rifugio-sidebar animate-on-scroll">
            <!-- Tech Details Card -->
            <div class="tech-details">
                <h3 style="color: var(--color-primary-dark); margin-bottom: 1rem; text-align: center;">Dettagli Tecnici</h3>
                <ul>
                    <li><strong>Altitudine</strong> <span>2.039 m s/m</span></li>
                    <li><strong>Posti letto</strong> <span>25 (con coperte)</span></li>
                    <li><strong>Apertura</strong> <span>Metà giu - Fine ott</span></li>
                    <li><strong>Guardiano</strong> <span>Non presente</span></li>
                    <li><strong>Cucina</strong> <span>Acqua, legna, gas</span></li>
                    <li><strong>Tempo di marcia</strong> <span>3h 30 (da Val d'Efra)</span></li>
                </ul>
            </div>

            <!-- Booking and Map Widget -->
            <div style="background: var(--color-bg-pure-white); padding: 25px; border-radius: var(--radius); box-shadow: 0 10px 30px rgba(0,0,0,0.08); border-top: 4px solid var(--color-primary); position: sticky; top: 100px;">
                <h3 style="color: var(--color-primary-dark); margin-bottom: 1rem; text-align: center;">Prenotazione</h3>
                <p style="text-align: center; color: var(--color-text-light); margin-bottom: 1.5rem; font-size: 0.95rem;">Verifica la disponibilità e prenota subito il tuo soggiorno al rifugio.</p>
                
                <a href="<?php echo esc_url($booking_link); ?>" target="_blank" rel="noopener" class="btn-prenota">
                    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                    Prenota Online
                </a>

                <div class="sidebar-map">
                    <iframe loading="lazy" src="https://maps.google.com/maps?q=Capanna%20Efra&t=m&z=12&output=embed&iwloc=near" title="Mappa Capanna Efra" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
            </div>

        </div>

    </div>
</main>

<!-- Lightbox HTML -->
<div class="lightbox" id="rifugio-lightbox">
    <span class="lightbox-close" onclick="closeLightbox()">&times;</span>
    <span class="lightbox-prev" onclick="changeLightboxImage(-1)">&#10094;</span>
    <img id="lightbox-img" src="">
    <span class="lightbox-next" onclick="changeLightboxImage(1)">&#10095;</span>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    let currentImageIndex = 0;
    const galleryLinks = document.querySelectorAll('.rifugio-gallery a');
    if(galleryLinks.length === 0) return;
    
    const images = Array.from(galleryLinks).map(a => a.href);
    const lightbox = document.getElementById('rifugio-lightbox');
    const lightboxImg = document.getElementById('lightbox-img');

    galleryLinks.forEach((link, index) => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            currentImageIndex = index;
            openLightbox();
        });
    });

    window.openLightbox = function() {
        lightboxImg.src = images[currentImageIndex];
        lightbox.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    window.closeLightbox = function() {
        lightbox.classList.remove('active');
        document.body.style.overflow = '';
    }

    window.changeLightboxImage = function(dir) {
        currentImageIndex += dir;
        if (currentImageIndex < 0) currentImageIndex = images.length - 1;
        if (currentImageIndex >= images.length) currentImageIndex = 0;
        lightboxImg.src = images[currentImageIndex];
    }

    lightbox.addEventListener('click', function(e) {
        if (e.target === lightbox) {
            closeLightbox();
        }
    });

    document.addEventListener('keydown', function(e) {
        if (!lightbox.classList.contains('active')) return;
        if (e.key === 'Escape') closeLightbox();
        if (e.key === 'ArrowRight') changeLightboxImage(1);
        if (e.key === 'ArrowLeft') changeLightboxImage(-1);
    });
});
</script>

<?php get_footer(); ?>
