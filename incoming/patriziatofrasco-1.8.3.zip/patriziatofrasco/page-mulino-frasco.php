<?php
/**
 * Template Name: Mulino Frasco
 */
get_header();

$hero_img = parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) . '/2026/06/30534aa5ecb62375e2dc8264961686a870719617-1920x1080-1.webp';
?>

<style>
/* Reusing the reliable layout structure */
.rifugio-layout {
    display: grid;
    grid-template-columns: 1fr 420px;
    gap: var(--space-xl);
    padding: var(--space-xl) 0;
}

.rifugio-main-content {
    font-size: 1.15rem;
    line-height: 1.8;
}

.rifugio-main-content h4 {
    color: var(--color-primary);
    font-size: 1.5rem;
    margin: var(--space-lg) 0 var(--space-sm) 0;
    padding-bottom: var(--space-xs);
    border-bottom: 2px solid var(--color-bg-body);
}

.rifugio-main-content p {
    margin-bottom: var(--space-md);
}

/* Sidebar Widget Card */
.rifugio-sidebar {
    position: sticky;
    top: 100px;
    height: fit-content;
}

.tech-details {
    background: var(--color-bg-pure-white);
    padding: 25px;
    border-radius: var(--radius);
    box-shadow: 0 10px 30px rgba(0,0,0,0.08);
    border-top: 4px solid var(--color-accent);
    margin-bottom: var(--space-lg);
}

.tech-details h3 {
    color: var(--color-primary-dark);
    margin-bottom: 1rem;
    text-align: center;
    font-size: 1.4rem;
}

.tech-details ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

.tech-details li {
    display: flex;
    flex-direction: column;
    gap: 5px;
    padding: 15px 0;
    border-bottom: 1px solid rgba(0,0,0,0.05);
}

.tech-details li:last-child {
    border-bottom: none;
}

.tech-details li strong {
    color: var(--color-primary-dark);
    font-size: 1.1rem;
}

.tech-details li > span {
    color: var(--color-text-light);
    font-size: 1rem;
}

.btn-contact {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    background: var(--color-primary);
    color: #FFFFFF !important;
    padding: 15px 20px;
    font-size: 1.05rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 1px;
    text-decoration: none;
    border-radius: var(--radius);
    transition: all 0.3s ease;
    box-shadow: 0 8px 20px rgba(14,42,102,0.15);
    width: 100%;
    margin-top: 20px;
}

.btn-contact:hover {
    background: var(--color-primary-light);
    transform: translateY(-3px);
    box-shadow: 0 12px 25px rgba(14,42,102,0.25);
}

@media (max-width: 992px) {
    .rifugio-layout {
        grid-template-columns: 1fr;
    }
    .rifugio-sidebar {
        position: static;
        margin-top: var(--space-lg);
    }
}

/* Gallery Grid */
.rifugio-gallery {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
    gap: 15px;
    margin-top: 20px;
}

.rifugio-gallery a {
    display: block;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 4px 15px rgba(0,0,0,0.08);
}

.rifugio-gallery img {
    width: 100%;
    height: 140px;
    object-fit: cover;
    display: block;
    transition: transform 0.3s ease;
}

.rifugio-gallery a:hover img {
    transform: scale(1.05);
}

/* Lightbox Styles */
.lightbox {
    position: fixed;
    z-index: 99999;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0,0,0,0.92);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    pointer-events: none;
    transition: opacity 0.3s ease;
}
.lightbox.active {
    opacity: 1;
    pointer-events: auto;
}
.lightbox img {
    max-width: 90%;
    max-height: 90vh;
    border-radius: 4px;
    box-shadow: 0 10px 50px rgba(0,0,0,0.8);
    transition: transform 0.3s ease;
}
.lightbox-close {
    position: absolute;
    top: 20px;
    right: 30px;
    color: white;
    font-size: 45px;
    cursor: pointer;
    line-height: 1;
    user-select: none;
    transition: color 0.2s;
}
.lightbox-close:hover { color: var(--color-accent); }
.lightbox-prev, .lightbox-next {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    color: white;
    font-size: 50px;
    cursor: pointer;
    padding: 20px;
    user-select: none;
    transition: color 0.2s;
}
.lightbox-prev { left: 20px; }
.lightbox-next { right: 20px; }
.lightbox-prev:hover, .lightbox-next:hover { color: var(--color-accent); }
</style>

<header class="page-header-cinematic has-bg" style="background-image: url('<?php echo esc_url($hero_img); ?>'); background-position: center;">
    <div class="page-header-overlay"></div>
    <div class="container page-header-inner animate-on-scroll" style="text-align: left;">
        <h1 class="page-title" style="margin-bottom: 0;">Mulino di Frasco</h1>
        <p style="font-size: 1.2rem; opacity: 0.9; margin-top: 10px; color: #FFFFFF;">Un tuffo negli antichi mestieri della valle</p>
    </div>
</header>

<style>
/* FORZA BRUTA ANTI-PLUGIN: Disabilita i clic sull'intera galleria e su ogni elemento generato dinamicamente al suo interno */
.rifugio-gallery, .rifugio-gallery * {
    pointer-events: none !important;
    cursor: default !important;
}
</style>

<main id="primary" class="site-main">
    <div class="container rifugio-layout">
        
        <div class="rifugio-main-content animate-on-scroll">
            <h3 style="color: var(--color-primary-dark); font-size: 2rem; margin-bottom: var(--space-md);">La Storia</h3>
            <p>Nell'Ottocento il villaggio di Frasco costituiva un piccolo centro artigianale per l'alta Valle. Fino all'alluvione del 1868 sono attestati una segheria, una cava di calcare con quattro fornaci, frantoi per lo schiacciamento delle noci, pestatoi per la battitura della canapa e del lino e alcuni mulini per cereali.</p>
            
            <p>Successivamente sorsero sul riale Efra due impianti ancora esistenti: <strong>il mulino</strong> e la <strong>centralina idraulica</strong>.</p>
            
            <p>Oggi, grazie agli interventi di restauro, il mulino è tornato a macinare farina di mais per polenta. Una visita al mulino permette di immergersi tra gli antichi gesti del mugnaio. La farina per polenta prodotta come un tempo può essere anche acquistata.</p>

            <h4 style="margin-top: var(--space-xxl);">GALLERIA FOTOGRAFICA</h4>
            <div class="rifugio-gallery">
                <img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/af5f0606d78fdd757f2d209151a3940b3c2701b6-1200x900-1.webp">
                <img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/3342d94f0ba48ec04662f313ed37c1ecf1b87c15-1200x900-1.webp">
                <img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/6b404cee6451a5ccfb67bd7ae3bde45005602463-1200x900-1.webp">
                <img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/5fb67dd2d5b2a24d7792eec241a83bfbf79a1acf-1500x1106-1.webp">
                <img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/b98af2fbeefe3b0976da09796a1ac28b6529b4d1-4032x3024-1.webp">
                <img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/bfa42145befbd4d4026754b833b2a94ef95acc32-801x548-1.webp">
            </div>
        </div>

        <div class="rifugio-sidebar animate-on-scroll">
            
            <!-- Orari e Prezzi Card -->
            <div class="tech-details">
                <h3>Informazioni Visita</h3>
                <ul>
                    <li>
                        <strong>Periodo d'apertura</strong> 
                        <span>Dal 1° maggio al 31 ottobre</span>
                    </li>
                    <li>
                        <strong>Orari</strong> 
                        <span>Tutti i sabato dalle 15:00 alle 17:00</span>
                    </li>
                    <li>
                        <strong>Prezzi d'entrata</strong>
                        <ul style="margin-top: 5px; list-style-type: circle; padding-left: 20px;">
                            <li style="padding: 2px 0; border: none;">Adulti: <strong>CHF 2.00</strong></li>
                            <li style="padding: 2px 0; border: none;">Dai 6 ai 14 anni: <strong>CHF 1.00</strong></li>
                            <li style="padding: 2px 0; border: none;">Sotto i 6 anni: <strong>gratuito</strong></li>
                            <li style="padding: 2px 0; border: none;">Gruppi (min 10 persone): <strong>forfait CHF 60.00</strong></li>
                        </ul>
                    </li>
                </ul>


                <a href="tel:+41917461777" class="btn-contact">
                    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path></svg>
                    +41 91 746 17 77
                </a>
                <p style="text-align: center; color: var(--color-text-light); margin-top: 10px; font-size: 0.9rem;">Visite guidate su richiesta</p>
            </div>

            <div style="background: var(--color-bg-pure-white); padding: 15px; border-radius: var(--radius); box-shadow: 0 10px 30px rgba(0,0,0,0.08);">
                <iframe loading="lazy" src="https://maps.google.com/maps?q=Mulino%20Frasco&t=m&z=15&output=embed&iwloc=near" title="Mappa Mulino" width="100%" height="200" style="border:0; border-radius: 8px;" allowfullscreen="" loading="lazy"></iframe>
            </div>

        </div>

    </div>
</main>



<?php get_footer(); ?>
