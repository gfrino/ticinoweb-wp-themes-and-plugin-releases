<?php
/**
 * Patriziato Frasco Theme functions and definitions
 *
 * @package Patriziato Frasco
 * @since 1.0.0
 */

if ( ! function_exists( 'patriziatofrasco_setup' ) ) :
	function patriziatofrasco_setup() {
		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		// Let WordPress manage the document title.
		add_theme_support( 'title-tag' );

		// Enable support for Post Thumbnails on posts and pages.
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'menu-1' => esc_html__( 'Primary Menu', 'patriziatofrasco' ),
		) );

		// HTML5 markup support
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		) );

		// Add support for core custom logo.
		add_theme_support( 'custom-logo', array(
			'height'      => 103,
			'width'       => 276,
			'flex-width'  => true,
			'flex-height' => true,
		) );
	}
endif;
add_action( 'after_setup_theme', 'patriziatofrasco_setup' );

/**
 * Enqueue scripts and styles.
 */
function patriziatofrasco_scripts() {
	$version = time(); // Force cache busting during development
	wp_enqueue_style( 'patriziatofrasco-style', get_stylesheet_uri(), array(), $version );
	
	// Add Google Fonts
	wp_enqueue_style( 'patriziatofrasco-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;1,400;1,600&family=Figtree:wght@400;500;600;700&display=swap', array(), null );
	
	// Add custom animations script
	wp_enqueue_script( 'patriziatofrasco-animations', get_stylesheet_directory_uri() . '/animations.js', array(), $version, true );
}
add_action( 'wp_enqueue_scripts', 'patriziatofrasco_scripts' );
/**
 * Registrazione Custom Post Type: Comunicati
 */
function patriziatofrasco_register_comunicati_cpt() {
	$labels = array(
		'name'                  => _x( 'Comunicati', 'Post type general name', 'patriziatofrasco' ),
		'singular_name'         => _x( 'Comunicato', 'Post type singular name', 'patriziatofrasco' ),
		'menu_name'             => _x( 'Comunicati', 'Admin Menu text', 'patriziatofrasco' ),
		'name_admin_bar'        => _x( 'Comunicato', 'Add New on Toolbar', 'patriziatofrasco' ),
		'add_new'               => __( 'Aggiungi Nuovo', 'patriziatofrasco' ),
		'add_new_item'          => __( 'Aggiungi Nuovo Comunicato', 'patriziatofrasco' ),
		'new_item'              => __( 'Nuovo Comunicato', 'patriziatofrasco' ),
		'edit_item'             => __( 'Modifica Comunicato', 'patriziatofrasco' ),
		'view_item'             => __( 'Guarda Comunicato', 'patriziatofrasco' ),
		'all_items'             => __( 'Tutti i Comunicati', 'patriziatofrasco' ),
		'search_items'          => __( 'Cerca Comunicati', 'patriziatofrasco' ),
		'not_found'             => __( 'Nessun comunicato trovato.', 'patriziatofrasco' ),
		'not_found_in_trash'    => __( 'Nessun comunicato nel cestino.', 'patriziatofrasco' ),
	);

	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'comunicato' ),
		'capability_type'    => 'post',
		'has_archive'        => false, 
		'hierarchical'       => false,
		'menu_position'      => 5.3, // 3° posizione custom
		'menu_icon'          => 'dashicons-megaphone',
		'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
		'show_in_rest'       => true, // Enable Gutenberg editor
	);

	register_post_type( 'comunicato', $args );
}
add_action( 'init', 'patriziatofrasco_register_comunicati_cpt' );

/**
 * Resource Hints per Google Fonts (Preconnect)
 */
function patriziatofrasco_resource_hints( $urls, $relation_type ) {
	if ( wp_style_is( 'patriziatofrasco-fonts', 'queue' ) && 'preconnect' === $relation_type ) {
		$urls[] = array(
			'href' => 'https://fonts.gstatic.com',
			'crossorigin',
		);
	}
	return $urls;
}
add_filter( 'wp_resource_hints', 'patriziatofrasco_resource_hints', 10, 2 );

/**
 * Defer JavaScript per non bloccare il render
 */
function patriziatofrasco_defer_scripts( $tag, $handle, $src ) {
	$defer_scripts = array( 
		'patriziatofrasco-animations',
	);

	if ( in_array( $handle, $defer_scripts ) ) {
		return '<script src="' . esc_url( $src ) . '" defer="defer"></script>' . "\n";
	}

	return $tag;
}
add_filter( 'script_loader_tag', 'patriziatofrasco_defer_scripts', 10, 3 );

/**
 * Gestione Forzata Template Pagine
 * Forza il nostro archivio per i comunicati, e forza il template di default
 * per tutte le altre pagine (bypassando Elementor) per mostrare i banner blu.
 */
function patriziatofrasco_force_page_templates( $value, $object_id, $meta_key, $single ) {
	if ( $meta_key === '_wp_page_template' ) {
		$post = get_post($object_id);

		// Solo le PAGINE: i custom post type (capanna, sentiero, punto_interesse)
		// possono avere lo stesso slug di una pagina, e senza questo controllo
		// ereditavano il suo template. Era il caso della capanna
		// "rifugio-alpe-costa", che finiva su page-rifugio.php (l'itinerario
		// scritto a mano) invece di mostrare il proprio contenuto.
		if ( ! $post || 'page' !== $post->post_type ) {
			return $value;
		}

		if ( $post && $post->post_name === 'cumunicati' ) {
			return 'page-cumunicati.php';
		}
		
		if ( $post && $post->post_name === 'chi-siamo' ) {
			return 'page-chi-siamo.php';
		}
		
		if ( $post && ( $post->post_name === 'la-nostra-missione' || $post->post_name === 'organizzazione' ) ) {
			return 'page-organizzazione.php';
		}
		
		if ( $post && $post->post_name === 'rifugio-alpe-costa' ) {
			return 'page-rifugio.php';
		}
		
		if ( $post && ( $post->post_name === 'shop' || $post->post_name === 'prodotti' ) ) {
			return 'page-shop.php';
		}
		
		if ( $post && $post->post_name === 'territorio' ) {
			return 'page-territorio.php';
		}
		
		if ( $post && $post->post_name === 'sentieri-e-capanne' ) {
			return 'page-sentieri.php';
		}
		
		if ( $post && $post->post_name === 'sentieri' ) {
			return 'page-sentieri.php';
		}
		
		if ( $post && $post->post_name === 'capanne' ) {
			return 'page-capanne.php';
		}
		
		if ( $post && $post->post_name === 'punti-di-interesse' ) {
			return 'page-punti-interesse.php';
		}
		
		if ( $post && $post->post_name === 'regolamento' ) {
			return 'page-regolamento.php';
		}

		if ( $post && $post->post_name === 'galleria' ) {
			return 'page-galleria.php';
		}
	}
	return $value;
}
add_filter( 'get_post_metadata', 'patriziatofrasco_force_page_templates', 10, 4 );

/**
 * ==========================================================================
 * MISURE DI SICUREZZA AGGIUNTIVE
 * ==========================================================================
 */

// 1. Rimuovere la versione di WordPress per nasconderla agli scanner automatici
remove_action('wp_head', 'wp_generator');

// 2. Disabilitare XML-RPC per prevenire attacchi brute-force e DDoS (pingback)
add_filter('xmlrpc_enabled', '__return_false');

// 3. Bloccare l'enumerazione degli autori per proteggere i nomi utente
function patriziatofrasco_block_author_scans() {
    if ( is_admin() ) {
        return;
    }
    if ( isset($_GET['author']) && is_numeric($_GET['author']) ) {
        wp_die( 'Impossibile accedere a questa risorsa.', 'Accesso Negato', array( 'response' => 403 ) );
    }
}
add_action('template_redirect', 'patriziatofrasco_block_author_scans');

// 4. Aggiungere Intestazioni HTTP di Sicurezza
function patriziatofrasco_security_headers() {
    if ( ! headers_sent() && ! is_admin() ) {
        header( 'X-Content-Type-Options: nosniff' );
        header( 'X-Frame-Options: SAMEORIGIN' );
        header( 'X-XSS-Protection: 1; mode=block' );
    }
}
add_action( 'send_headers', 'patriziatofrasco_security_headers' );

/**
 * Aggiunge le classi CSS di Elementor alle pagine personalizzate
 * Questo forza l'Header di Elementor a mantenere le dimensioni e i font corretti.
 */
function patriziatofrasco_add_elementor_body_classes( $classes ) {
	if ( is_page('cumunicati') || is_page('regolamento') || is_page('galleria') || is_singular('comunicato') ) {
		$classes[] = 'elementor-default';
		$classes[] = 'elementor-page';
		
		// Ottieni l'ID del kit attivo di Elementor (per i font e i colori globali)
		$kit_id = get_option( 'elementor_active_kit' );
		if ( $kit_id ) {
			$classes[] = 'elementor-kit-' . $kit_id;
		}
	}
	return $classes;
}
add_filter( 'body_class', 'patriziatofrasco_add_elementor_body_classes' );

/**
 * Corregge "al volo" gli URL delle immagini rotti (senza porta 8000)
 * inseriti nel contenuto della pagina.
 */
add_filter('the_content', 'patriziatofrasco_fix_local_urls');
function patriziatofrasco_fix_local_urls($content) {
	// Se siamo in locale e manca la porta 8000, la aggiungiamo per non rompere le immagini
	$content = str_replace('http://localhost/patriziatofrasco/', 'http://localhost:8000/patriziatofrasco/', $content);
	// Correzione anche per eventuali https
	$content = str_replace('https://localhost/patriziatofrasco/', 'http://localhost:8000/patriziatofrasco/', $content);

	// Lo stemma è un asset del layout: usa la copia inclusa nel tema, disponibile in ogni ambiente.
	// L'URL nel contenuto può essere assoluto (qualsiasi dominio) o relativo, e l'id del
	// subsite cambia da ambiente ad ambiente (sites/11 in locale, sites/173 in produzione):
	// per questo si intercetta l'intero URL partendo dal nome del file.
	if ( false !== stripos( $content, 'Frasco-coat_of_arms' ) ) {
		$stemma_url = get_stylesheet_directory_uri() . '/img/stemma-frasco.png';

		$content = preg_replace_callback(
			'#[^"\'\s()]*/wp-content/uploads/[^"\'\s()]*Frasco-coat_of_arms(?!-white)[^"\'\s()]*\.png#i',
			function () use ( $stemma_url ) {
				return $stemma_url;
			},
			$content
		);
	}

	return $content;
}

/**
 * La pagina /rifugio-alpe-costa/ conteneva l'itinerario scritto a mano, non le
 * informazioni del rifugio. Le informazioni della capanna (con la prenotazione
 * online) vivono sul custom post type "capanna": qui reindirizziamo, così il
 * vecchio indirizzo continua a funzionare e non c'è contenuto duplicato.
 */
function ptf_redirect_pagina_rifugio() {
	if ( is_admin() || ! is_page( 'rifugio-alpe-costa' ) ) {
		return;
	}

	$capanna = get_posts( array(
		'post_type'      => 'capanna',
		'name'           => 'rifugio-alpe-costa',
		'post_status'    => 'publish',
		'posts_per_page' => 1,
		'fields'         => 'ids',
	) );

	if ( empty( $capanna ) ) {
		return;
	}

	$destinazione = get_permalink( $capanna[0] );

	if ( $destinazione && untrailingslashit( $destinazione ) !== untrailingslashit( home_url( add_query_arg( array() ) ) ) ) {
		wp_safe_redirect( $destinazione, 301 );
		exit;
	}
}
add_action( 'template_redirect', 'ptf_redirect_pagina_rifugio' );

/**
 * Riassunto breve per le liste di capanne, sentieri e punti di interesse.
 *
 * Il riassunto automatico di WordPress appiattisce tutto il contenuto, comprese
 * le intestazioni di sezione: nelle liste si leggeva "Descrizione Dopo la
 * riattazione...", "La Storia Nell'Ottocento...", "Benvenuti a Cabiói...".
 * Qui le intestazioni vengono tolte, così resta solo il testo.
 *
 * @param int|WP_Post|null $post   Articolo di riferimento.
 * @param int              $parole Numero massimo di parole.
 * @return string Testo pronto da stampare (senza escaping).
 */
function ptf_riassunto( $post = null, $parole = 30 ) {
	$post = get_post( $post );

	if ( ! $post ) {
		return '';
	}

	// Un riassunto scritto a mano dall'utente vince sempre.
	if ( '' !== trim( (string) $post->post_excerpt ) ) {
		return wp_trim_words( wp_strip_all_tags( $post->post_excerpt ), $parole, '...' );
	}

	$contenuto = (string) $post->post_content;
	$contenuto = preg_replace( '#<(script|style)\b[^>]*>.*?</\1>#is', ' ', $contenuto );
	// Via le intestazioni: sono titoli di sezione, non testo descrittivo.
	$contenuto = preg_replace( '#<h[1-6]\b[^>]*>.*?</h[1-6]>#is', ' ', $contenuto );
	$contenuto = preg_replace( '#<figcaption\b[^>]*>.*?</figcaption>#is', ' ', $contenuto );
	$contenuto = strip_shortcodes( $contenuto );
	$contenuto = wp_strip_all_tags( $contenuto );
	$contenuto = preg_replace( '/\s+/u', ' ', $contenuto );

	return wp_trim_words( trim( (string) $contenuto ), $parole, '...' );
}

/**
 * Registrazione Custom Post Type e Meta Box per le Mozioni
 */
require get_theme_file_path( '/inc/cpt-mozioni.php' );

/**
 * Registrazione Custom Post Type e Meta Box per le Attività
 */
require get_theme_file_path( '/inc/cpt-attivita.php' );

/**
 * Registrazione Custom Post Type e Meta Box per le Interpellanze
 */
require get_theme_file_path( '/inc/cpt-interpellanze.php' );

/**
 * Registrazione Custom Post Type e Meta Box per i Prodotti
 */
require get_theme_file_path( '/inc/cpt-prodotti.php' );

/**
 * Registrazione Custom Post Type per l'Ufficio Patriziale
 */
require get_theme_file_path( '/inc/cpt-ufficio.php' );

/**
 * Registrazione Custom Post Type e Meta Box per Sentieri e Capanne
 */
require_once get_stylesheet_directory() . '/inc/cpt-sentieri.php';
require_once get_stylesheet_directory() . '/inc/cpt-interesse.php';
require_once get_stylesheet_directory() . '/inc/cpt-pubblicazioni.php';

/**
 * Esporta e importa i contenuti delle pagine gestite dal tema.
 */
require_once get_stylesheet_directory() . '/inc/page-content-transfer.php';

/**
 * Moduli aggiuntivi del tema.
 *
 * - theme-options.php      : pagina di impostazioni nel backend (es. nascondere i Formulari)
 * - media-fields.php       : campi Luogo/Data sugli allegati + helper ptf_media_caption()
 * - pdf-embed.php          : helper ptf_render_pdf_embed() per l'anteprima dei PDF
 * - cpt-comunicati-pdf.php : metabox PDF per il CPT "comunicato"
 *
 * Caricamento difensivo: se un file non è ancora presente il sito non va in errore.
 */
$patriziatofrasco_moduli = array(
	'/inc/theme-options.php',
	'/inc/menu-builder.php',
	'/inc/media-fields.php',
	'/inc/pdf-embed.php',
	'/inc/cpt-comunicati-pdf.php',
);

foreach ( $patriziatofrasco_moduli as $patriziatofrasco_modulo ) {
	$patriziatofrasco_modulo_path = get_stylesheet_directory() . $patriziatofrasco_modulo;

	if ( file_exists( $patriziatofrasco_modulo_path ) ) {
		require_once $patriziatofrasco_modulo_path;
	}
}
unset( $patriziatofrasco_moduli, $patriziatofrasco_modulo, $patriziatofrasco_modulo_path );

/**
 * Nascondi l'editor di testo per le pagine che fungono solo da "Archivio/Contenitore" dinamico
 */
add_action( 'admin_init', 'pf_hide_editor_for_archive_pages' );
function pf_hide_editor_for_archive_pages() {
    $post_id = isset($_GET['post']) ? $_GET['post'] : (isset($_POST['post_ID']) ? $_POST['post_ID'] : false);
    if( !isset( $post_id ) ) return;
    
    $template_file = get_post_meta($post_id, '_wp_page_template', true);
    
    $templates_without_editor = array(
        'page-cumunicati.php',
        'page-sentieri.php',
        'page-pubblicazioni.php',
        'page-punti-interesse.php'
    );
    
    if( in_array($template_file, $templates_without_editor) ){
        remove_post_type_support('page', 'editor');
    }
}

/**
 * Intercetta l'URL /termini-e-condizioni/ e mostra il template dedicato
 */
add_action( 'parse_request', function( $wp ) {
	if ( trim( $wp->request, '/' ) === 'termini-e-condizioni' ) {
		status_header( 200 );
		include get_stylesheet_directory() . '/page-termini-e-condizioni.php';
		exit;
	}
});
