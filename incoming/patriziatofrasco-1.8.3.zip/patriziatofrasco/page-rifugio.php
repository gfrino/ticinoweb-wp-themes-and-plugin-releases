<?php
/**
 * Template Name: Rifugio Alpe Costa
 */
get_header();

$hero_img = parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) . '/2026/06/alpe-costa1.jpg';
$booking_link = 'https://www.planyo.com/booking.php?resource_id=205857&mode=reserve';
?>

<style>
.rifugio-layout {
    display: grid;
    grid-template-columns: 1fr 420px;
    gap: var(--space-xl);
    padding-top: var(--space-xl);
    padding-bottom: var(--space-xl);
}

.rifugio-main-content {
    font-size: 1.15rem;
    line-height: 1.8;
}

.rifugio-main-content h4 {
    color: var(--color-primary);
    font-size: 1.5rem;
    margin: var(--space-lg) 0 var(--space-sm) 0;
    padding-bottom: var(--space-xs);
    border-bottom: 2px solid var(--color-bg-body);
}

.rifugio-main-content ul {
    list-style: none;
    padding: 0;
    margin-bottom: var(--space-lg);
}

.rifugio-main-content ul li {
    padding: var(--space-xs) 0;
    border-bottom: 1px solid rgba(0,0,0,0.05);
    display: flex;
    gap: var(--space-sm);
}

.rifugio-main-content ul li::before {
    content: "";
    display: inline-block;
    min-width: 18px;
    height: 18px;
    margin-top: 4px;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%233c69e7'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='3' d='M5 13l4 4L19 7'%3E%3C/path%3E%3C/svg%3E");
    background-size: contain;
    background-repeat: no-repeat;
}

/* Booking Widget Card */
.rifugio-sidebar {
    position: sticky;
    top: 100px;
    height: fit-content;
}

.btn-prenota {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    background: var(--color-primary);
    color: #FFFFFF !important;
    padding: 15px 20px;
    font-size: 1.05rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 1px;
    white-space: nowrap;
    text-decoration: none;
    border-radius: var(--radius);
    transition: all 0.3s ease;
    box-shadow: 0 8px 20px rgba(14,42,102,0.15);
    width: 100%;
}

.btn-prenota:hover {
    background: var(--color-primary-light);
    transform: translateY(-3px);
    box-shadow: 0 12px 25px rgba(14,42,102,0.25);
}

.sidebar-map {
    margin-top: var(--space-lg);
    border-radius: var(--radius);
    overflow: hidden;
}

/* Gallery Grid */
.rifugio-gallery {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: var(--space-sm);
    margin-top: var(--space-lg);
}
.rifugio-gallery img {
    width: 100%;
    height: 150px;
    object-fit: cover;
    border-radius: var(--radius);
    transition: transform 0.3s ease;
}
.rifugio-gallery img:hover {
    transform: scale(1.05);
}

/* Sidebar Tech Details */
.tech-details {
    background: var(--color-bg-pure-white);
    padding: 25px;
    border-radius: var(--radius);
    box-shadow: 0 10px 30px rgba(0,0,0,0.08);
    border-top: 4px solid var(--color-accent);
    margin-bottom: var(--space-lg);
}

.tech-details ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

.tech-details li {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 15px;
    padding: 12px 0;
    border-bottom: 1px solid rgba(0,0,0,0.05);
    font-size: 1.05rem;
}

.tech-details li:last-child {
    border-bottom: none;
}

.tech-details li strong {
    color: var(--color-primary-dark);
    flex-shrink: 0;
}

.tech-details li > span {
    text-align: right;
}

.diff-badge {
    background: #cc0000;
    color: white;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 0.9rem;
    font-weight: bold;
}

/* Itinerary Steps */
.itinerary-steps {
    position: relative;
    padding-left: 40px;
    margin-top: var(--space-lg);
}

.itinerary-steps::before {
    content: '';
    position: absolute;
    top: 0;
    bottom: 0;
    left: 10px;
    width: 2px;
    background: rgba(14,42,102,0.1);
}

html[data-theme="dark"] .itinerary-steps::before {
    background: rgba(255,255,255,0.22);
}

.step-item {
    position: relative;
    margin-bottom: var(--space-lg);
}

.step-icon {
    position: absolute;
    left: -40px;
    top: 0;
    width: 24px;
    height: 24px;
    background: var(--color-primary-dark);
    color: white;
    border-radius: 4px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.8rem;
    z-index: 2;
}

.step-item h5 {
    margin: 0 0 5px 0;
    color: var(--color-primary-dark);
    font-size: 1.15rem;
    display: flex;
    justify-content: space-between;
    align-items: baseline;
}

.step-dist {
    color: var(--color-text-light);
    font-size: 0.95rem;
    font-weight: normal;
    font-family: var(--font-body);
}

@media (max-width: 992px) {
    .rifugio-layout {
        grid-template-columns: 1fr;
    }
    .rifugio-sidebar {
        position: static;
        margin-top: var(--space-lg);
    }
}

/* Gallery Grid */
.rifugio-gallery {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
    gap: 15px;
    margin-top: 20px;
}

.rifugio-gallery a {
    display: block;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 4px 15px rgba(0,0,0,0.08);
}

.rifugio-gallery img {
    width: 100%;
    height: 140px;
    object-fit: cover;
    display: block;
    transition: transform 0.3s ease;
}

.rifugio-gallery a:hover img {
    transform: scale(1.05);
}

/* Lightbox Styles */
.lightbox {
    position: fixed;
    z-index: 99999;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.92);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    pointer-events: none;
    transition: opacity 0.3s ease;
}
.lightbox.active {
    opacity: 1;
    pointer-events: auto;
}
.lightbox img {
    max-width: 90%;
    max-height: 90vh;
    border-radius: 4px;
    box-shadow: 0 10px 50px rgba(0,0,0,0.8);
    transition: transform 0.3s ease;
}
.lightbox-close {
    position: absolute;
    top: 20px;
    right: 30px;
    color: white;
    font-size: 45px;
    cursor: pointer;
    line-height: 1;
    user-select: none;
    transition: color 0.2s;
}
.lightbox-close:hover { color: var(--color-accent); }
.lightbox-prev, .lightbox-next {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    color: white;
    font-size: 50px;
    cursor: pointer;
    padding: 20px;
    user-select: none;
    transition: color 0.2s;
}
.lightbox-prev { left: 20px; }
.lightbox-next { right: 20px; }
.lightbox-prev:hover, .lightbox-next:hover { color: var(--color-accent); }

</style>

<header class="page-header-cinematic has-bg" style="background-image: url('<?php echo esc_url($hero_img); ?>');">
    <div class="page-header-overlay"></div>
    <div class="container page-header-inner animate-on-scroll" style="text-align: left;">
        <h1 class="page-title" style="margin-bottom: 0;">Rifugio Alpe Costa</h1>
        <p style="font-size: 1.2rem; opacity: 0.9; margin-top: 10px; color: #FFFFFF;">1941 m s/m - Valle Verzasca, Monti di Frasco</p>
    </div>
</header>

<main id="primary" class="site-main">
    <div class="container rifugio-layout">
        
        <div class="rifugio-main-content animate-on-scroll">
            <h3 style="color: var(--color-primary-dark); font-size: 2rem; margin-bottom: var(--space-md);">Sintesi dell'itinerario</h3>
            <p><strong>Escursione di un giorno all'Alpe Costa, sulle alture di Frasco. Un tour rosso-bianco che grazie alla sua posizione assolata è fattibile dalla primavera all'autunno inoltrato.</strong></p>
            <p>Frasco, il punto di partenza del tour, è raggiungibile in auto o autobus (linea Locarno-Tenero-Sonogno). Il percorso è relativamente ripido sin dalla partenza. All'inizio si cammina ancora nel bosco ombroso, dopodiché la flora cambia e i larici dominano il paesaggio. Il sentiero serpeggia tra i villaggi, fino a A coo der Prèda, l'ultimo, dove si inerpica ripido e sempre a zig-zag fino al vasto prato dell'Alpe Costa e all'omonimo rifugio.</p>
            <p>La struttura autogestita è il luogo ideale per rilassarsi e staccare la spina, con possibilità di pernottamento (aperta da maggio a ottobre). La capanna offre 7 posti, WC/doccia e l'occorrente per cucinare.</p>
            <p>Si ritorna a Frasco sullo stesso sentiero dell'andata. Sulla strada del ritorno si può fare una tappa all'azienda agricola "La Ghironda" (A coo der Prèda) per acquistare prodotti tipici come formaggio di capra o salumi. Chi desidera rinfrescarsi dopo le fatiche della camminata può concedersi un bagno nel Verzasca (ma attenzione!).</p>

            <h4 style="margin-top: var(--space-xxl);">DIREZIONI DA SEGUIRE</h4>
            <p style="color: var(--color-text-light); margin-bottom: var(--space-lg);">Frasco-Sciürés-Rifugio Alpe Costa-Sciüres-Frasco</p>
            
            <div class="itinerary-steps">
                <div class="step-item">
                    <div class="step-icon">S</div>
                    <h5><span>Frasco, Chiesa</span> <span class="step-dist">0 km</span></h5>
                    <p style="font-size: 0.95rem; color: var(--color-text-light); margin: 0;">Punto di partenza</p>
                </div>
                <div class="step-item">
                    <div class="step-icon">▼</div>
                    <h5><span>Punto più basso, 885 m</span> <span class="step-dist">0 km</span></h5>
                </div>
                <div class="step-item">
                    <div class="step-icon" style="background: #a67c52;">~</div>
                    <h5><span>Tipo di strada: Sentiero</span> <span class="step-dist">0,2 km</span></h5>
                    <p style="font-size: 0.95rem; color: var(--color-text-light); margin: 0;">Lunghezza: 3,4 km, inizio</p>
                </div>
                <div class="step-item">
                    <div class="step-icon">▲</div>
                    <h5><span>Punto più alto, 1.943 m</span> <span class="step-dist">3,6 km</span></h5>
                </div>
                <div class="step-item" style="background: var(--color-bg-light); padding: 20px 40px; border-radius: var(--radius); margin-left: -40px; margin-right: -40px;">
                    <div class="step-icon" style="background: #e3000f; left: 0; top: 20px;">⌂</div>
                    <h5><span>Rifugio Alpe Costa</span> <span class="step-dist">3,6 km</span></h5>
                    <p style="font-size: 0.95rem; color: var(--color-text-light); margin-bottom: 15px;">Punti di sosta e ristoro</p>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                        <div style="background-image: url('<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2023/12/alpe_costa-1024x512.jpg'); background-size: cover; background-position: center; height: 180px; border-radius: 8px;"></div>
                        <div style="background-image: url('<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2023/11/images-3.jpeg'); background-size: cover; background-position: center 75%; height: 180px; border-radius: 8px;"></div>
                    </div>
                </div>
            </div>

            <h4 style="margin-top: var(--space-xl);">GALLERIA COMPLETA</h4>
            <div class="rifugio-gallery">
                <a href="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2023/11/images-3.jpeg" target="_blank"><img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2023/11/images-3.jpeg"></a>
                <a href="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2023/11/images-2.jpeg" target="_blank"><img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2023/11/images-2.jpeg"></a>
                <a href="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2023/11/images.jpeg" target="_blank"><img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2023/11/images.jpeg"></a>
                <a href="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2023/11/dsc02838.jpg" target="_blank"><img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2023/11/dsc02838.jpg"></a>
                <a href="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2023/11/15s.jpg" target="_blank"><img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2023/11/15s.jpg"></a>
            </div>
        </div>

        <div class="rifugio-sidebar animate-on-scroll">
            
            <!-- Tech Details Card -->
            <div class="tech-details">
                <h3 style="color: var(--color-primary-dark); margin-bottom: 1rem; text-align: center;">Dettagli Itinerario</h3>
                <ul>
                    <li><strong>Difficoltà</strong> <span><span style="border:1px solid #ccc; padding:2px 5px; border-radius:4px; font-size:0.9rem; margin-right:5px; color: #666;">T3</span><span class="diff-badge">media</span></span></li>
                    <li><strong>Distanza</strong> <span>7,3 km</span></li>
                    <li><strong>Durata</strong> <span>4:50 h</span></li>
                    <li><strong>Salita</strong> <span>1.090 m</span></li>
                    <li><strong>Discesa</strong> <span>1.090 m</span></li>
                    <li><strong>Punto più alto</strong> <span>1.943 m</span></li>
                    <li><strong>Punto più basso</strong> <span>885 m</span></li>
                    <li style="flex-direction: column; border-bottom: none; margin-top: 10px;">
                        <strong>Periodo consigliato</strong>
                        <div style="display: flex; gap: 5px; margin-top: 8px; font-size: 0.85rem; color: white;">
                            <span style="background: #e0e0e0; padding: 2px 6px; border-radius: 10px; color: #666;">gen-apr</span>
                            <span style="background: #6b7a18; padding: 2px 8px; border-radius: 10px;">mag-ott</span>
                            <span style="background: #e0e0e0; padding: 2px 6px; border-radius: 10px; color: #666;">nov-dic</span>
                        </div>
                    </li>
                </ul>
            </div>

            <!-- Booking and Map Widget -->
            <div style="background: var(--color-bg-pure-white); padding: 25px; border-radius: var(--radius); box-shadow: 0 10px 30px rgba(0,0,0,0.08); border-top: 4px solid var(--color-primary); position: sticky; top: 100px;">
                <h3 style="color: var(--color-primary-dark); margin-bottom: 1rem; text-align: center;">Prenotazione</h3>
                <p style="text-align: center; color: var(--color-text-light); margin-bottom: 1.5rem; font-size: 0.95rem;">Verifica la disponibilità e prenota subito il tuo soggiorno al rifugio.</p>
                
                <a href="<?php echo esc_url($booking_link); ?>" target="_blank" rel="noopener" class="btn-prenota">
                    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                    Prenota Online
                </a>

                <div class="sidebar-map">
                    <iframe loading="lazy" src="https://maps.google.com/maps?q=Rifugio%20Alpe%20Costa%20Frasco&t=m&z=12&output=embed&iwloc=near" title="Mappa Rifugio" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
            </div>

        </div>

    </div>
</main>

<!-- Lightbox HTML -->
<div class="lightbox" id="rifugio-lightbox">
    <span class="lightbox-close" onclick="closeLightbox()">&times;</span>
    <span class="lightbox-prev" onclick="changeLightboxImage(-1)">&#10094;</span>
    <img id="lightbox-img" src="">
    <span class="lightbox-next" onclick="changeLightboxImage(1)">&#10095;</span>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    let currentImageIndex = 0;
    const galleryLinks = document.querySelectorAll('.rifugio-gallery a');
    if(galleryLinks.length === 0) return;
    
    const images = Array.from(galleryLinks).map(a => a.href);
    const lightbox = document.getElementById('rifugio-lightbox');
    const lightboxImg = document.getElementById('lightbox-img');

    galleryLinks.forEach((link, index) => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            currentImageIndex = index;
            openLightbox();
        });
    });

    window.openLightbox = function() {
        lightboxImg.src = images[currentImageIndex];
        lightbox.classList.add('active');
        document.body.style.overflow = 'hidden'; // block page scrolling
    }

    window.closeLightbox = function() {
        lightbox.classList.remove('active');
        document.body.style.overflow = ''; // restore scrolling
    }

    window.changeLightboxImage = function(dir) {
        currentImageIndex += dir;
        if (currentImageIndex < 0) currentImageIndex = images.length - 1;
        if (currentImageIndex >= images.length) currentImageIndex = 0;
        lightboxImg.src = images[currentImageIndex];
    }

    // Close on background click
    lightbox.addEventListener('click', function(e) {
        if (e.target === lightbox) {
            closeLightbox();
        }
    });

    // Keyboard navigation
    document.addEventListener('keydown', function(e) {
        if (!lightbox.classList.contains('active')) return;
        if (e.key === 'Escape') closeLightbox();
        if (e.key === 'ArrowRight') changeLightboxImage(1);
        if (e.key === 'ArrowLeft') changeLightboxImage(-1);
    });
});
</script>

<?php get_footer(); ?>
