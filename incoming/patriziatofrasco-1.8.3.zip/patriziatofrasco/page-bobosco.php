<?php
/**
 * Template Name: Bobosco
 */
get_header();

$hero_img = parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) . '/2026/06/imgi_2_b369f74c6dbd7a7ec2b7f271ba702349c822d2a6-1024x768-1.webp';
?>

<style>
/* Reusing the reliable layout structure */
.rifugio-layout {
    display: grid;
    grid-template-columns: 1fr 420px;
    gap: var(--space-xl);
    padding: var(--space-xl) 0;
}

.rifugio-main-content {
    font-size: 1.15rem;
    line-height: 1.8;
}

.rifugio-main-content h4 {
    color: var(--color-primary);
    font-size: 1.5rem;
    margin: var(--space-lg) 0 var(--space-sm) 0;
    padding-bottom: var(--space-xs);
    border-bottom: 2px solid var(--color-bg-body);
}

.rifugio-main-content p {
    margin-bottom: var(--space-md);
}

/* Sidebar Widget Card */
.rifugio-sidebar {
    position: sticky;
    top: 100px;
    height: fit-content;
}

.tech-details {
    background: var(--color-bg-pure-white);
    padding: 25px;
    border-radius: var(--radius);
    box-shadow: 0 10px 30px rgba(0,0,0,0.08);
    border-top: 4px solid var(--color-accent);
    margin-bottom: var(--space-lg);
}

.tech-details h3 {
    color: var(--color-primary-dark);
    margin-bottom: 1rem;
    text-align: center;
    font-size: 1.4rem;
}

@media (max-width: 992px) {
    .rifugio-layout {
        grid-template-columns: 1fr;
    }
    .rifugio-sidebar {
        position: static;
        margin-top: var(--space-lg);
    }
}

/* Gallery Grid */
.rifugio-gallery {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
    gap: 15px;
    margin-top: 20px;
}

.rifugio-gallery a {
    display: block;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 4px 15px rgba(0,0,0,0.08);
}

.rifugio-gallery img {
    width: 100%;
    height: 140px;
    object-fit: cover;
    display: block;
    transition: transform 0.3s ease;
}

.rifugio-gallery a:hover img {
    transform: scale(1.05);
}

/* Lightbox Styles */
.lightbox {
    position: fixed;
    z-index: 99999;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0,0,0,0.92);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    pointer-events: none;
    transition: opacity 0.3s ease;
}
.lightbox.active {
    opacity: 1;
    pointer-events: auto;
}
.lightbox img {
    max-width: 90%;
    max-height: 90vh;
    border-radius: 4px;
    box-shadow: 0 10px 50px rgba(0,0,0,0.8);
    transition: transform 0.3s ease;
}
.lightbox-close {
    position: absolute;
    top: 20px;
    right: 30px;
    color: white;
    font-size: 45px;
    cursor: pointer;
    line-height: 1;
    user-select: none;
    transition: color 0.2s;
}
.lightbox-close:hover { color: var(--color-accent); }
.lightbox-prev, .lightbox-next {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    color: white;
    font-size: 50px;
    cursor: pointer;
    padding: 20px;
    user-select: none;
    transition: color 0.2s;
}
.lightbox-prev { left: 20px; }
.lightbox-next { right: 20px; }
.lightbox-prev:hover, .lightbox-next:hover { color: var(--color-accent); }
</style>

<header class="page-header-cinematic has-bg" style="background-image: url('<?php echo esc_url($hero_img); ?>'); background-position: center;">
    <div class="page-header-overlay"></div>
    <div class="container page-header-inner animate-on-scroll" style="text-align: left;">
        <h1 class="page-title" style="margin-bottom: 0;">BoBosco</h1>
        <p style="font-size: 1.2rem; opacity: 0.9; margin-top: 10px; color: #FFFFFF;">Boccia al bosco nella natura incontaminata</p>
    </div>
</header>

<style>
/* FORZA BRUTA ANTI-PLUGIN: Disabilita i clic sull'intera galleria e su ogni elemento generato dinamicamente al suo interno */
.rifugio-gallery, .rifugio-gallery * {
    pointer-events: none !important;
    cursor: default !important;
}
</style>

<main id="primary" class="site-main">
    <div class="container rifugio-layout">
        
        <div class="rifugio-main-content animate-on-scroll">
            <h3 style="color: var(--color-primary-dark); font-size: 2rem; margin-bottom: var(--space-md);">L'esperienza BoBosco</h3>
            <p><strong>Scopri la Valle Verzasca con un gioco.</strong> BoBosco ti fa immergere completamente nella natura e rende l'hiking un'esperienza divertente anche per i bambini.</p>
            <p>Boccia al bosco – o BoBosco in breve – è un ingegnoso percorso per bocce completamente costruito in legno di castagno composto da due tracciati distinti: uno si estende tra Brione Verzasca e Lavertezzo, l'altro da Gerra Verzasca a Sonogno. L'itinerario di 9,8 km totali nel bosco, lungo le acque smeraldine del fiume Verzasca, ne fanno non solo un gioco emozionante per le famiglie, ma anche uno spettacolo naturale da ammirare in un paesaggio suggestivo.</p>
            <p>Diverse piste per bocce realizzate in legno di castagno per conoscere la Valle Verzasca: un modo simpatico per far entrare in contatto i bambini con la natura e aggiungere un tocco di divertimento in più alle escursioni in famiglia. Le bocce di legno da far correre in pista possono essere acquistate per <strong>9 CHF</strong> in uno dei punti vendita. L'escursione si compone di due parti, entrambe hanno aree pic-nic dove fare una pausa. Tenendo gli occhi ben aperti si possono incontrare perfino alcuni degli abitanti di questo bellissimo bosco di castagni.</p>
            <p>La <strong>prima parte</strong> si estende da Brione Verzasca e l'arrivo a Lavertezzo, dove si può ammirare il famoso Ponte dei Salti. Lungo i 5,5 km s'incontrano tredici emozionanti postazioni – come carrucole e chiuse d'acqua – che portano la boccia a continuare la sua corsa.</p>
            <p>La <strong>seconda parte</strong> parte da Gerra Verzasca e arriva fino a Sonogno, l'ultimo villaggio della valle. Sul percorso di 4,3 km si trovano dieci postazioni per far correre la boccia. Considerata la lunghezza dei due tracciati, per poter avere il tempo di giocare ad ogni postazione è consigliato percorrere le due parti in momenti diversi. Si può anche accorciare l'escursione a piacimento.</p>
            <p>BoBosco è un'avventura pensata per le famiglie e per tutti coloro che amano la natura e si divertono giocando.</p>

            <h4 style="margin-top: var(--space-xxl);">GALLERIA FOTOGRAFICA</h4>
            <div class="rifugio-gallery">
                <img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/imgi_2_b369f74c6dbd7a7ec2b7f271ba702349c822d2a6-1024x768-1.webp">
                <img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/imgi_3_8578e40624e789ccb6dc2e61adabc763234043e9-1024x768-1.webp">
                <img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/imgi_4_adf99e719ca277f424891853d604ee037c75e3e1-1024x768-1.webp">
            </div>
        </div>

        <div class="rifugio-sidebar animate-on-scroll">
            <div class="tech-details">
                <h3>Punti Vendita</h3>
                <p style="color: var(--color-text-main); font-size: 0.95rem; line-height: 1.5; margin-bottom: 15px; text-align: center;">Informarsi anticipatamente sulle aperture e chiusure.<br><strong>Info tel: <a href="tel:+41848091091">+41 848 091 091</a></strong></p>
                <ul style="color: var(--color-text-main); font-size: 0.95rem; line-height: 1.6; padding-left: 20px; margin-bottom: 0;">
                    <li>Panetteria El Prestin, Sonogno</li>
                    <li>Info Shop, Sonogno</li>
                    <li>Distributore automatico 24/7, Gerra Verzasca <br><small>(G Pay, V Pay, Mastercard, Maestro, Visa, TWINT, Apple Pay, Samsung Pay)</small></li>
                    <li>Distributore automatico 24/7, Brione Verzasca (Piée)</li>
                    <li>Supermercato Coop, Brione Verzasca</li>
                    <li>Gelateria Verzasca, Brione Verzasca (Ganne)</li>
                    <li>Kiosk Lavertezzo</li>
                    <li>Grotto Al Ponte, Lavertezzo</li>
                    <li>Albergo Diffuso, Corippo</li>
                    <li>Info Shop Diga Verzasca, Gordola</li>
                    <li>Sportelli turistici (Ascona, Avegno, Brissago, Locarno, Tenero, Vira Gambarogno)</li>
                </ul>
            </div>
            
            <div style="background: var(--color-bg-pure-white); padding: 15px; border-radius: var(--radius); box-shadow: 0 10px 30px rgba(0,0,0,0.08); border-top: 4px solid var(--color-primary);">
                <h3 style="color: var(--color-primary-dark); margin-bottom: 1rem; text-align: center; padding-top: 10px;">Posizione</h3>
                <iframe loading="lazy" src="https://maps.google.com/maps?q=Valle%20Verzasca,%20Bobosco&t=k&z=13&output=embed&iwloc=near" title="Mappa Bobosco" width="100%" height="250" style="border:0; border-radius: 8px;" allowfullscreen="" loading="lazy"></iframe>
            </div>
        </div>

    </div>
</main>



<?php get_footer(); ?>
