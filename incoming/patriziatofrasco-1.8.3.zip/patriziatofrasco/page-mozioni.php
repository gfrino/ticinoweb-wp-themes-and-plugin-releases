<?php
/**
 * Template Name: Pagina Mozioni
 * 
 * Modello per visualizzare l'elenco delle mozioni pubbliche.
 */

get_header();

// Hero image predefinita (da cambiare se necessario, o usare quella in evidenza)
$hero_img = has_post_thumbnail() ? get_the_post_thumbnail_url(get_the_ID(), 'full') : parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) . '/2023/12/alpe_costa-1024x512.jpg';
?>

<style>
/* Stili specifici per la lista Mozioni */
.mozioni-list {
    max-width: 900px;
    margin: 0 auto 80px auto;
    display: flex;
    flex-direction: column;
    gap: 30px;
}
.mozione-card {
    background: var(--color-bg-pure-white);
    border-radius: var(--radius);
    padding: 30px;
    border: 1px solid rgba(0,0,0,0.08);
    box-shadow: 0 10px 30px rgba(0,0,0,0.05);
    display: flex;
    flex-direction: column;
    gap: 15px;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.mozione-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 40px rgba(0,0,0,0.08);
}
.mozione-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    flex-wrap: wrap;
    gap: 15px;
}
.mozione-title {
    color: var(--color-primary-dark);
    margin: 0;
    font-size: 1.8rem;
    font-family: var(--font-heading);
}
.mozione-meta {
    font-size: 0.95rem;
    color: var(--color-text-light);
    display: flex;
    gap: 20px;
    flex-wrap: wrap;
    align-items: center;
}
.mozione-meta strong {
    color: var(--color-text);
}
.mozione-status {
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 0.85rem;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
/* Colori semantici per lo stato */
.status-in-esame { background-color: #fff3cd; color: #856404; }
.status-accolta { background-color: #d4edda; color: #155724; }
.status-respinta { background-color: #f8d7da; color: #721c24; }
.status-ritirata { background-color: #e2e3e5; color: #383d41; }

.mozione-excerpt {
    color: var(--color-text);
    line-height: 1.6;
    margin: 0;
}
.mozione-action {
    margin-top: 10px;
}
.btn-mozione {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    background: var(--color-primary);
    color: white;
    padding: 10px 20px;
    border-radius: 4px;
    text-decoration: none;
    font-weight: bold;
    transition: background-color 0.3s;
}
.btn-mozione:hover {
    background: var(--color-primary-dark);
    color: white;
}
.mozioni-empty {
    text-align: center;
    padding: 60px 20px;
    background: var(--color-bg-light);
    border-radius: var(--radius);
    color: var(--color-text-light);
    font-size: 1.1rem;
    font-style: italic;
}
</style>

<!-- Hero Section -->
<div class="page-header-cinematic no-bg" style="background-color: var(--color-primary-dark);">
    <div class="page-header-overlay"></div>
    <div class="container page-header-inner text-center animate-on-scroll">
        <h1 class="page-title"><?php the_title(); ?></h1>
        <h2 style="color: var(--color-accent); font-size: 1.5rem; font-weight: 500; font-family: var(--font-heading); margin-top: var(--space-sm);">Archivio pubblico delle Mozioni del Patriziato</h2>
    </div>
</div>

<main id="primary" class="site-main">

    <div class="container section-padding">
        


        <!-- Lista Mozioni -->
        <div class="mozioni-list">
            <?php
            // Query per le mozioni pubblicate
            $mozioni_args = array(
                'post_type'      => 'mozione',
                'post_status'    => 'publish',
                'posts_per_page' => -1, // Mostra tutte
                'orderby'        => 'date', // Ordine di default (creazione post)
                'order'          => 'DESC'  // Dalla più recente
            );
            $mozioni_query = new WP_Query( $mozioni_args );

            if ( $mozioni_query->have_posts() ) :

                while ( $mozioni_query->have_posts() ) : $mozioni_query->the_post();
                    $mozione_id = get_the_ID();
                    $data = get_post_meta( $mozione_id, '_mozione_data', true );
                    $proponente = get_post_meta( $mozione_id, '_mozione_proponente', true );
                    $stato = get_post_meta( $mozione_id, '_mozione_stato', true );
                    $pdf_id = get_post_meta( $mozione_id, '_mozione_pdf_id', true );
                    $pdf_url = $pdf_id ? wp_get_attachment_url( $pdf_id ) : '';
                    
                    // Formattazione della data (se presente, altrimenti usa la data di pubblicazione del post)
                    if ( $data ) {
                        $data_formattata = date_i18n( 'j F Y', strtotime( $data ) );
                    } else {
                        $data_formattata = get_the_date();
                    }

                    // Classe CSS per lo stato
                    $status_class = 'status-in-esame'; // Default
                    if ( $stato == 'Accolta' ) $status_class = 'status-accolta';
                    if ( $stato == 'Respinta' ) $status_class = 'status-respinta';
                    if ( $stato == 'Ritirata' ) $status_class = 'status-ritirata';
                    ?>

                    <div class="mozione-card animate-on-scroll">
                        <div class="mozione-header">
                            <h2 class="mozione-title"><?php the_title(); ?></h2>
                            <?php if ( $stato ) : ?>
                                <span class="mozione-status <?php echo esc_attr($status_class); ?>">
                                    <?php echo esc_html($stato); ?>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="mozione-meta">
                            <span class="meta-item">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" style="vertical-align: text-bottom;"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                                Data: <strong><?php echo esc_html($data_formattata); ?></strong>
                            </span>
                            
                            <?php if ( $proponente ) : ?>
                            <span class="meta-item">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" style="vertical-align: text-bottom;"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
                                Proponente: <strong><?php echo esc_html($proponente); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>

                        <?php if ( has_excerpt() ) : ?>
                            <div class="mozione-excerpt">
                                <?php the_excerpt(); ?>
                            </div>
                        <?php endif; ?>

                        <?php
                        // Nota: il pulsante di download non si stampa qui.
                        // Lo fornisce gia' ptf_render_pdf_embed() sotto l'anteprima:
                        // due pulsanti con lo stesso link confondevano il lettore.
                        ?>
                        <?php
                        // Embed del PDF: si aggiunge SOTTO al testo, non lo sostituisce.
                        // L'anteprima è subito visibile (nessun pannello da aprire);
                        // il documento viene scaricato solo quando la scheda sta per
                        // entrare nel viewport, così la lista resta leggera.
                        if ( $pdf_id && function_exists( 'ptf_render_pdf_embed' ) ) {
                            ptf_render_pdf_embed( $pdf_id, array(
                                'titolo'         => 'Testo della mozione',
                                'testo_pulsante' => 'Scarica il PDF della mozione',
                                'classe'         => 'ptf-pdf-embed--mozione',
                            ) );
                        }
                        ?>
                    </div>

                <?php 
                endwhile;
                wp_reset_postdata(); // Ripristina query principale

            else :
                // Messaggio in caso di assenza mozioni
                ?>
                <div class="mozioni-empty animate-on-scroll">
                    Al momento non sono presenti mozioni pubblicate.
                </div>
            <?php
            endif;
            ?>
        </div>

    </div>
</main>

<?php
get_footer();
