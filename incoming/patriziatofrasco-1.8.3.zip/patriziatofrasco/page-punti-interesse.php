<?php
/**
 * Template Name: Punti di Interesse
 */
get_header();

$hero_img = parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) . '/2026/06/Logo-hd.png'; // Placeholder
?>

<style>
/* Reusing the same Visual List CSS from Sentieri for perfect consistency */
.visual-list-container {
    max-width: 1200px;
    margin: var(--space-xl) auto;
    padding: 0 var(--space-md);
}

.visual-list-intro {
    text-align: center;
    max-width: 800px;
    margin: 0 auto var(--space-xl) auto;
    font-size: 1.15rem;
    line-height: 1.8;
}

.visual-list {
    display: flex;
    flex-direction: column;
    gap: var(--space-lg);
}

.visual-list-item {
    display: flex;
    background: var(--color-bg-pure-white);
    border-radius: var(--radius);
    overflow: hidden;
    box-shadow: 0 4px 15px rgba(0,0,0,0.05);
    border: 1px solid rgba(0,0,0,0.05);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.visual-list-item:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 25px rgba(22,58,138,0.1);
}

.visual-list-img {
    flex: 0 0 350px;
    background: var(--color-bg-body);
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
}

.visual-list-img img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.visual-list-content {
    padding: var(--space-lg);
    display: flex;
    flex-direction: column;
    justify-content: center;
    flex-grow: 1;
}

.visual-list-content h3 {
    color: var(--color-primary-dark);
    margin-top: 0;
    margin-bottom: var(--space-sm);
    font-size: 1.8rem;
}

.visual-list-content p {
    color: var(--color-text-light);
    line-height: 1.7;
    margin-bottom: var(--space-md);
}

.visual-list-action {
    margin-top: auto;
}

.btn-arrow {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: var(--color-primary);
    color: #FFFFFF !important;
    padding: 12px 28px;
    border-radius: var(--radius);
    font-weight: 600;
    text-decoration: none;
    transition: all 0.3s ease;
    box-shadow: 0 8px 20px rgba(14,42,102,0.15);
}

.btn-arrow:hover {
    background: var(--color-primary-light);
    transform: translateY(-3px);
    box-shadow: 0 12px 25px rgba(14,42,102,0.25);
}

@media (max-width: 768px) {
    .visual-list-item {
        flex-direction: column;
    }
    .visual-list-img {
        flex-basis: 250px;
    }
}
</style>

<div class="page-header-cinematic no-bg" style="background-color: var(--color-primary-dark);">
    <div class="page-header-overlay"></div>
    <div class="container page-header-inner animate-on-scroll">
        <h1 class="page-title">Punti di Interesse</h1>
        <h2 style="color: var(--color-accent); font-size: 1.5rem; font-weight: 500; font-family: var(--font-heading); margin-top: var(--space-sm);">I luoghi storici della nostra valle.</h2>
    </div>
</div>

<style>
/* FORZA BRUTA ANTI-PLUGIN: Disabilita i clic sulle immagini delle schede (archivio) */
.visual-list-img, .visual-list-img * {
    cursor: default !important;
}
</style>

<script>
// SCUDO JAVASCRIPT: Intercetta e uccide qualsiasi clic prima che altri script possano reagire
document.addEventListener('DOMContentLoaded', function() {
    var containers = document.querySelectorAll('.visual-list-img');
    containers.forEach(function(container) {
        // Disinnesca i link
        var links = container.querySelectorAll('a');
        links.forEach(function(link) {
            link.removeAttribute('href');
        });
        
        // Uccide il clic in fase di cattura (prima che arrivi alla card o alla lightbox)
        container.addEventListener('click', function(e) {
            e.stopPropagation();
            e.preventDefault();
        }, true);
    });
});
</script>

<main id="primary" class="site-main">
    <div class="visual-list-container">
        
        <div class="visual-list-intro animate-on-scroll">
            <p>Un viaggio attraverso le testimonianze storiche e culturali del Patriziato di Frasco. Esplora le antiche strutture che raccontano la vita e il lavoro dei nostri antenati.</p>
        </div>

        <div class="visual-list animate-on-scroll">
            
            <?php
            $interesse_query = new WP_Query( array(
                'post_type'      => 'punto_interesse',
                'posts_per_page' => -1,
                'order'          => 'ASC'
            ) );

            $bobosco_post = null;
            $tutti_al_bosco_post = null;
            $other_posts = array();

            if ( $interesse_query->have_posts() ) {
                while ( $interesse_query->have_posts() ) {
                    $interesse_query->the_post();
                    $title = strtolower(trim(get_the_title()));
                    
                    if ( $title === 'casa patriziale' ) {
                        continue;
                    }
                    
                    if ( $title === 'bobosco' ) {
                        $bobosco_post = get_post();
                    } elseif ( $title === 'tutti al bosco' ) {
                        $tutti_al_bosco_post = get_post();
                    } else {
                        $other_posts[] = get_post();
                    }
                }
                wp_reset_postdata();
            }

            $all_posts = array();
            if ( $bobosco_post ) {
                $all_posts[] = $bobosco_post;
            }
            if ( $tutti_al_bosco_post ) {
                $all_posts[] = $tutti_al_bosco_post;
            }
            $all_posts = array_merge($all_posts, $other_posts);

            if ( !empty($all_posts) ) :
                global $post;
                foreach ( $all_posts as $post ) :
                    setup_postdata( $post );
                    $thumbnail_url = has_post_thumbnail() ? get_the_post_thumbnail_url( get_the_ID(), 'large' ) : parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) . '/2026/06/Logo-hd.png';
                    
                    if ( strtolower(trim(get_the_title())) === 'tutti al bosco' && !has_post_thumbnail() ) {
                        $thumbnail_url = parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) . '/2026/07/PHOTO-2024-07-09-23-07-05.webp';
                    }
            ?>
                    <article class="visual-list-item">
                        <div class="visual-list-img">
                            <img src="<?php echo esc_url( $thumbnail_url ); ?>" alt="<?php the_title_attribute(); ?>">
                        </div>
                        <div class="visual-list-content">
                            <h3><?php the_title(); ?></h3>
                            <div class="interesse-excerpt">
                                <?php 
                                if ( strtolower(trim(get_the_title())) === 'tutti al bosco' ) {
                                    echo '<p style="color: var(--color-text-light); line-height: 1.7; margin-bottom: var(--space-md);">“Tutti al Bosco” è l’offerta inclusiva dell’Associazione BoBosco, nata dalla collaborazione con la Fondazione Cerebral: noleggia una carrozzina elettrica per scoprire le meraviglie della Valle.</p>';
                                } else {
                                    echo '<p style="color: var(--color-text-light); line-height: 1.7; margin-bottom: var(--space-md);">' . esc_html( ptf_riassunto( get_the_ID(), 30 ) ) . '</p>';
                                }
                                ?>
                            </div>
                            <div class="visual-list-action">
                                <a href="<?php the_permalink(); ?>" class="btn-arrow">Vedi scheda dettagliata</a>
                            </div>
                        </div>
                    </article>
            <?php
                endforeach;
                wp_reset_postdata();
            else :
            ?>
                <p style="text-align: center; color: var(--color-text-light);">Nessun punto di interesse pubblicato al momento. Aggiungili dal pannello di controllo.</p>
            <?php endif; ?>

        </div>

    </div>
</main>

<?php get_footer(); ?>
