<?php
/**
 * Template Name: Singolo Comunicato
 */

get_header(); ?>

<main id="primary" class="site-main" style="background-color: var(--color-bg-light); min-height: 100vh;">
	<?php while ( have_posts() ) : the_post(); ?>
		
		<article id="post-<?php the_ID(); ?>" <?php post_class('single-comunicato-article'); ?>>
			
			<header class="single-comunicato-header">
				<div class="container">
					<div class="single-comunicato-meta">
						<a href="<?php echo home_url('/comunicati/'); ?>" class="single-comunicato-back">&larr; Torna ai comunicati</a>
						<span class="single-comunicato-date"><?php echo get_the_date(); ?></span>
					</div>
					<?php the_title( '<h1 class="single-comunicato-title">', '</h1>' ); ?>
				</div>
			</header>

			<?php if ( has_post_thumbnail() ) : ?>
				<div class="single-comunicato-hero">
					<div class="container">
						<?php the_post_thumbnail( 'full', array( 'class' => 'comunicato-hero-img' ) ); ?>
					</div>
				</div>
			<?php endif; ?>

			<div class="single-comunicato-content page-content">
				<div class="container">
					<div class="comunicato-text-wrapper">
						<?php the_content(); ?>

						<?php
						// Documento PDF allegato: si AGGIUNGE al testo, non lo sostituisce.
						$comunicato_pdf_id = get_post_meta( get_the_ID(), '_comunicato_pdf_id', true );
						if ( $comunicato_pdf_id && function_exists( 'ptf_render_pdf_embed' ) ) {
							ptf_render_pdf_embed( $comunicato_pdf_id, array(
								'titolo'         => 'Documento allegato',
								'testo_pulsante' => 'Apri il PDF',
								'classe'         => 'ptf-pdf-embed--comunicato',
							) );
						}
						?>
					</div>
				</div>
			</div>
			
		</article>

	<?php endwhile; ?>
</main>

<?php get_footer();
