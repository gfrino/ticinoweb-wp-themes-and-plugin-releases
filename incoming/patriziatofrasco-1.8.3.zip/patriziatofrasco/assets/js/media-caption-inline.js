/**
 * Luogo e Data al volo dal gestore gallerie.
 *
 * Aggiunge a ogni foto della schermata "Media > Gestisci Gallerie" un secondo
 * pulsante in hover che apre un pannello per impostare Luogo e Data
 * (meta _ptf_media_luogo / _ptf_media_data / _ptf_media_didascalia), senza
 * aprire la scheda del media.
 *
 * SELETTORI DEL TEMA PADRE (sola lettura, ticinoweb-ai-theme/inc/media-galleries.php):
 * - .twgm-image-card[data-attachment-id] .... riga 721 (card della foto)
 * - .twgm-image-overlay ..................... riga 734 (strato in hover con "Rimuovi")
 * - #gallery-images (.twgm-grid) ............ riga 684 (contenitore della griglia)
 * Nessuno di questi file viene modificato: qui vengono solo letti.
 *
 * La griglia viene rimescolata da jQuery UI Sortable e ricreata dopo l'aggiunta di
 * foto, quindi: delega degli eventi su document + MutationObserver sulla griglia.
 *
 * @package patriziatofrasco
 */

(function () {
	'use strict';

	var CFG = window.ptfMediaCaption || {};
	var I18N = CFG.i18n || {};

	var SEL_CARD = '.twgm-image-card[data-attachment-id]';
	var SEL_OVERLAY = '.twgm-image-overlay';
	var SEL_GRID = '#gallery-images';

	var CLS_BTN = 'ptf-cap-btn';
	var CLS_STRIP = 'ptf-cap-strip';
	var CLS_SAVED = 'ptf-cap-card--saved';

	var ICON = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none"' +
		' stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"' +
		' aria-hidden="true" focusable="false">' +
		'<path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path>' +
		'<line x1="7" y1="7" x2="7.01" y2="7"></line></svg>';

	/** Valori conosciuti: id allegato -> { luogo, data, caption }. */
	var store = Object.create(null);
	/** Id per cui è in corso una lettura, per non chiedere due volte la stessa cosa. */
	var pending = Object.create(null);

	var modal = null;
	var ui = {};
	var currentId = 0;
	var previousFocus = null;
	var isBusy = false;
	var savedTimers = Object.create(null);

	/** Oltre questa soglia la richiesta viene interrotta, per non lasciare il pannello bloccato. */
	var TIMEOUT_MS = 20000;

	/* ---------------------------------------------------------------------
	 * Utility
	 * ------------------------------------------------------------------ */

	function t(key, fallback) {
		var value = I18N[key];
		return (typeof value === 'string' && value !== '') ? value : fallback;
	}

	function el(tag, className, text) {
		var node = document.createElement(tag);
		if (className) {
			node.className = className;
		}
		if (typeof text === 'string' && text !== '') {
			node.textContent = text;
		}
		return node;
	}

	function cards() {
		return Array.prototype.slice.call(document.querySelectorAll(SEL_CARD));
	}

	function cardId(card) {
		var raw = card.getAttribute('data-attachment-id');
		var id = parseInt(raw, 10);
		return (isNaN(id) || id <= 0) ? 0 : id;
	}

	function cardById(id) {
		return document.querySelector('.twgm-image-card[data-attachment-id="' + String(id) + '"]');
	}

	/**
	 * Chiamata AJAX verso admin-ajax.php.
	 * Normalizza tutti gli errori (rete, permessi, nonce scaduto, risposta non JSON)
	 * in un Error con un messaggio in italiano già pronto da mostrare.
	 */
	function post(action, params) {
		var body = new URLSearchParams();
		body.append('action', action);
		body.append('nonce', CFG.nonce || '');

		Object.keys(params || {}).forEach(function (key) {
			var value = params[key];
			if (Array.isArray(value)) {
				value.forEach(function (item) {
					body.append(key + '[]', String(item));
				});
			} else {
				body.append(key, String(value));
			}
		});

		var controller = (typeof window.AbortController === 'function') ? new window.AbortController() : null;
		var timer = controller
			? window.setTimeout(function () { controller.abort(); }, TIMEOUT_MS)
			: null;

		var options = {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body.toString()
		};

		if (controller) {
			options.signal = controller.signal;
		}

		return fetch(CFG.ajaxUrl, options).then(function (response) {
			if (timer) {
				window.clearTimeout(timer);
			}

			return response.text().then(function (text) {
				var payload = null;

				try {
					payload = JSON.parse(text);
				} catch (e) {
					payload = null;
				}

				// check_ajax_referer fallito: WordPress risponde "-1" o "0".
				if (payload === -1 || payload === 0 || payload === '-1' || payload === '0') {
					throw new Error(t('errorSession', 'Sessione scaduta. Ricarica la pagina e riprova.'));
				}

				if (!payload || typeof payload.success === 'undefined') {
					throw new Error(t('errorGeneric', 'Non è stato possibile completare l\'operazione. Riprova.'));
				}

				if (!payload.success) {
					var message = (payload.data && payload.data.message) ? payload.data.message : '';
					throw new Error(message || t('errorGeneric', 'Non è stato possibile completare l\'operazione. Riprova.'));
				}

				return payload.data;
			});
		}, function (error) {
			if (timer) {
				window.clearTimeout(timer);
			}

			if (error && error.name === 'AbortError') {
				throw new Error(t('errorTimeout', 'Il server non ha risposto in tempo. Riprova.'));
			}

			throw new Error(t('errorNetwork', 'Connessione non riuscita. Controlla la rete e riprova.'));
		});
	}

	/* ---------------------------------------------------------------------
	 * Card: pulsante e fascia didascalia
	 * ------------------------------------------------------------------ */

	function buildButton(insideOverlay) {
		var button = document.createElement('button');
		button.type = 'button';
		button.className = CLS_BTN + (insideOverlay ? '' : ' ' + CLS_BTN + '--floating');
		button.innerHTML = ICON;

		var label = t('buttonSet', 'Imposta didascalie');
		button.setAttribute('title', label);
		button.setAttribute('aria-label', label);

		return button;
	}

	/** Inietta il pulsante nelle card che non ce l'hanno ancora. Idempotente. */
	function injectButtons() {
		cards().forEach(function (card) {
			if (!cardId(card) || card.querySelector('.' + CLS_BTN)) {
				return;
			}

			var overlay = card.querySelector(SEL_OVERLAY);
			var button = buildButton(!!overlay);

			if (overlay) {
				// Prima di "Rimuovi": il rosso resta l'ultima azione, la più a destra.
				overlay.insertBefore(button, overlay.firstChild);
			} else {
				// Ripiego se il markup del tema padre dovesse cambiare.
				card.appendChild(button);
			}
		});
	}

	/** Allinea fascia didascalia ed etichette del pulsante ai valori conosciuti. */
	function renderCard(card) {
		var id = cardId(card);

		if (!id) {
			return;
		}

		var entry = store[id];
		var caption = (entry && entry.caption) ? entry.caption : '';
		var strip = card.querySelector('.' + CLS_STRIP);

		if (caption) {
			if (!strip) {
				strip = el('div', CLS_STRIP);
				var overlay = card.querySelector(SEL_OVERLAY);
				// Prima dell'overlay, così i pulsanti in hover restano sopra.
				if (overlay) {
					card.insertBefore(strip, overlay);
				} else {
					card.appendChild(strip);
				}
			}
			// Scrivi SOLO se il valore è cambiato: il setter di textContent
			// sostituisce sempre il nodo di testo e genera una mutazione
			// childList, che rischedulerebbe il MutationObserver all'infinito.
			if (strip.textContent !== caption) {
				strip.textContent = caption;
			}
			if (strip.getAttribute('title') !== caption) {
				strip.setAttribute('title', caption);
			}
			if (card.getAttribute('data-ptf-has-caption') !== '1') {
				card.setAttribute('data-ptf-has-caption', '1');
			}
		} else {
			if (strip && strip.parentNode) {
				strip.parentNode.removeChild(strip);
			}
			card.removeAttribute('data-ptf-has-caption');
		}

		var button = card.querySelector('.' + CLS_BTN);

		if (button && entry) {
			// L'etichetta segue i CAMPI luogo/data, non la didascalia mostrata:
			// ptf_media_caption() ricade sulla didascalia nativa di WordPress, che
			// da questo pannello non è modificabile. Dire "Modifica" quando i due
			// campi sono vuoti manderebbe l'utente su un pannello vuoto.
			var haCampi = !!((entry.luogo && entry.luogo !== '') || (entry.data && entry.data !== '') || (entry.didascalia && entry.didascalia !== ''));
			var label = haCampi
				? t('buttonEdit', 'Modifica didascalie')
				: t('buttonSet', 'Imposta didascalie');
			button.setAttribute('title', label);
			button.setAttribute('aria-label', label);
		}
	}

	function renderAll() {
		cards().forEach(renderCard);
	}

	function flashSaved(card) {
		var id = cardId(card);

		card.classList.remove(CLS_SAVED);
		// Forza il riavvio dell'animazione anche a salvataggi ravvicinati.
		void card.offsetWidth;
		card.classList.add(CLS_SAVED);

		if (savedTimers[id]) {
			window.clearTimeout(savedTimers[id]);
		}

		savedTimers[id] = window.setTimeout(function () {
			card.classList.remove(CLS_SAVED);
			delete savedTimers[id];
		}, 1600);
	}

	/* ---------------------------------------------------------------------
	 * Lettura valori attuali
	 * ------------------------------------------------------------------ */

	function fetchValues(ids) {
		var wanted = ids.filter(function (id) {
			return id && !(id in pending);
		});

		if (!wanted.length) {
			return Promise.resolve();
		}

		wanted.forEach(function (id) {
			pending[id] = true;
		});

		return post('ptf_get_media_captions', { attachment_ids: wanted })
			.then(function (data) {
				data = data || {};
				wanted.forEach(function (id) {
					delete pending[id];
					var entry = data[id] || data[String(id)];
					store[id] = {
						luogo: (entry && entry.luogo) ? entry.luogo : '',
						data: (entry && entry.data) ? entry.data : '',
						caption: (entry && entry.caption) ? entry.caption : ''
					};
				});
				renderAll();
			})
			.catch(function (error) {
				wanted.forEach(function (id) {
					delete pending[id];
				});
				throw error;
			});
	}

	/** Chiede i valori delle card ancora sconosciute. Fallimento silenzioso: si ritenta all'apertura. */
	function syncUnknown() {
		var missing = [];

		cards().forEach(function (card) {
			var id = cardId(card);
			if (id && !(id in store) && !(id in pending)) {
				missing.push(id);
			}
		});

		if (!missing.length) {
			return;
		}

		fetchValues(missing).catch(function () {
			// Nessun messaggio qui: il pannello ritenta la lettura quando viene aperto.
		});
	}

	/* ---------------------------------------------------------------------
	 * Pannello di modifica
	 * ------------------------------------------------------------------ */

	function buildModal() {
		var root = el('div', 'ptf-cap-modal');
		root.setAttribute('role', 'dialog');
		root.setAttribute('aria-modal', 'true');
		root.setAttribute('aria-labelledby', 'ptf-cap-modal-title');
		root.hidden = true;

		var backdrop = el('div', 'ptf-cap-modal__backdrop');
		root.appendChild(backdrop);

		var panel = document.createElement('form');
		panel.className = 'ptf-cap-modal__panel';
		panel.setAttribute('novalidate', 'novalidate');

		var title = el('h2', 'ptf-cap-modal__title', t('modalTitle', 'Didascalie della foto'));
		title.id = 'ptf-cap-modal-title';
		panel.appendChild(title);

		panel.appendChild(el(
			'p',
			'ptf-cap-modal__hint',
			t('modalHint', 'Compaiono come didascalia sotto la foto nel sito. Lascia vuoto un campo per non mostrarlo.')
		));

		var preview = el('div', 'ptf-cap-modal__preview');
		var thumb = document.createElement('img');
		thumb.className = 'ptf-cap-modal__thumb';
		thumb.alt = '';
		preview.appendChild(thumb);
		var previewText = el('span', 'ptf-cap-modal__preview-text');
		preview.appendChild(previewText);
		panel.appendChild(preview);

		var fieldLuogo = buildField('luogo', t('labelLuogo', 'Luogo'), t('placeholderLuogo', 'Es. Frasco'),
			t('helpLuogoData', 'Luogo e data compaiono nel riquadro in basso a destra sulla miniatura.'));
		var fieldData = buildField('data', t('labelData', 'Data'), t('placeholderData', 'Es. 1969'));
		var fieldDidascalia = buildField('didascalia', t('labelDidascalia', 'Didascalia'),
			t('placeholderDidascalia', 'Testo che compare aprendo la foto'),
			t('helpDidascalia', 'Si vede solo quando la foto viene aperta a schermo intero.'), true);
		panel.appendChild(fieldLuogo.wrapper);
		panel.appendChild(fieldData.wrapper);
		panel.appendChild(fieldDidascalia.wrapper);

		var error = el('p', 'ptf-cap-modal__error');
		error.setAttribute('role', 'alert');
		error.hidden = true;
		panel.appendChild(error);

		var actions = el('div', 'ptf-cap-modal__actions');

		var cancel = document.createElement('button');
		cancel.type = 'button';
		cancel.className = 'ptf-cap-modal__cancel';
		cancel.textContent = t('cancel', 'Annulla');
		actions.appendChild(cancel);

		var save = document.createElement('button');
		save.type = 'submit';
		save.className = 'ptf-cap-modal__save';
		save.textContent = t('save', 'Salva');
		actions.appendChild(save);

		panel.appendChild(actions);
		root.appendChild(panel);
		document.body.appendChild(root);

		ui = {
			root: root,
			panel: panel,
			backdrop: backdrop,
			preview: preview,
			thumb: thumb,
			previewText: previewText,
			luogo: fieldLuogo.input,
			data: fieldData.input,
			didascalia: fieldDidascalia.input,
			error: error,
			cancel: cancel,
			save: save
		};

		panel.addEventListener('submit', function (event) {
			event.preventDefault();
			saveCurrent();
		});

		cancel.addEventListener('click', function (event) {
			event.preventDefault();
			closeModal();
		});

		// Clic fuori dal pannello: si comporta come "Annulla", senza rompere nulla.
		root.addEventListener('mousedown', function (event) {
			if (!panel.contains(event.target)) {
				closeModal();
			}
		});

		root.addEventListener('keydown', function (event) {
			if (event.key === 'Escape' || event.key === 'Esc') {
				event.preventDefault();
				closeModal();
				return;
			}

			if (event.key === 'Tab') {
				trapTab(event);
			}
		});

		return root;
	}

	function buildField(name, labelText, placeholder, aiuto, multiriga) {
		var wrapper = el('label', 'ptf-cap-field');
		wrapper.appendChild(el('span', 'ptf-cap-field__label', labelText));

		var input;

		if (multiriga) {
			input = document.createElement('textarea');
			input.rows = 3;
		} else {
			input = document.createElement('input');
			input.type = 'text';
			input.autocomplete = 'off';
		}

		input.className = 'ptf-cap-field__input';
		input.name = name;
		input.setAttribute('placeholder', placeholder);
		wrapper.appendChild(input);

		if (aiuto) {
			wrapper.appendChild(el('span', 'ptf-cap-field__help', aiuto));
		}

		return { wrapper: wrapper, input: input };
	}

	function trapTab(event) {
		var focusable = Array.prototype.slice.call(
			ui.panel.querySelectorAll('input, button, select, textarea, a[href]')
		).filter(function (node) {
			return !node.disabled && node.offsetParent !== null;
		});

		if (!focusable.length) {
			return;
		}

		var first = focusable[0];
		var last = focusable[focusable.length - 1];

		if (event.shiftKey && document.activeElement === first) {
			event.preventDefault();
			last.focus();
		} else if (!event.shiftKey && document.activeElement === last) {
			event.preventDefault();
			first.focus();
		}
	}

	function showError(message) {
		ui.error.textContent = message;
		ui.error.hidden = false;
	}

	function hideError() {
		ui.error.textContent = '';
		ui.error.hidden = true;
	}

	function setBusy(busy) {
		isBusy = !!busy;
		ui.root.classList.toggle('is-busy', isBusy);
		ui.save.disabled = isBusy;
		ui.cancel.disabled = isBusy;
		ui.save.textContent = isBusy ? t('saving', 'Salvataggio…') : t('save', 'Salva');
	}

	function openModal(card) {
		var id = cardId(card);

		if (!id) {
			return;
		}

		if (!modal) {
			modal = buildModal();
		}

		currentId = id;
		previousFocus = document.activeElement;

		hideError();
		setBusy(false);

		var entry = store[id];
		ui.luogo.value = entry ? entry.luogo : '';
		ui.data.value = entry ? entry.data : '';
		ui.didascalia.value = (entry && entry.didascalia) ? entry.didascalia : '';

		var img = card.querySelector('img');

		if (img && img.getAttribute('src')) {
			ui.thumb.src = img.getAttribute('src');
			ui.previewText.textContent = img.getAttribute('alt') || '';
			ui.preview.hidden = false;
		} else {
			ui.preview.hidden = true;
		}

		ui.root.hidden = false;
		ui.luogo.focus();
		ui.luogo.select();

		// Valori non ancora noti (o lettura iniziale fallita): riprova adesso.
		if (!entry) {
			fetchValues([id])
				.then(function () {
					if (currentId !== id) {
						return;
					}
					var fresh = store[id];
					// Non sovrascrive quello che l'utente ha già scritto nel frattempo.
					if (fresh && ui.luogo.value === '' && ui.data.value === '' && ui.didascalia.value === '') {
						ui.luogo.value = fresh.luogo;
						ui.data.value = fresh.data;
						ui.didascalia.value = fresh.didascalia || '';
						ui.luogo.select();
					}
				})
				.catch(function () {
					if (currentId === id) {
						showError(t('errorLoad', 'Non è stato possibile leggere i valori attuali: puoi comunque scriverli e salvare.'));
					}
				});
		}
	}

	function closeModal() {
		// Durante il salvataggio il pannello resta aperto: così l'esito (o l'errore)
		// viene sempre mostrato dove l'utente sta guardando. Il timeout garantisce
		// che non possa restare bloccato.
		if (!modal || ui.root.hidden || isBusy) {
			return;
		}

		ui.root.hidden = true;
		currentId = 0;
		hideError();
		setBusy(false);

		if (previousFocus && document.body.contains(previousFocus)) {
			previousFocus.focus();
		}

		previousFocus = null;
	}

	function saveCurrent() {
		var id = currentId;

		if (!id) {
			closeModal();
			return;
		}

		var luogo = ui.luogo.value;
		var data = ui.data.value;
		var didascalia = ui.didascalia.value;

		hideError();
		setBusy(true);

		post('ptf_save_media_caption', {
			attachment_id: id,
			luogo: luogo,
			data: data,
			didascalia: didascalia
		}).then(function (result) {
			store[id] = {
				luogo: (result && result.luogo) ? result.luogo : '',
				data: (result && result.data) ? result.data : '',
				didascalia: (result && result.didascalia) ? result.didascalia : '',
				caption: (result && result.caption) ? result.caption : ''
			};

			var card = cardById(id);

			if (card) {
				renderCard(card);
				flashSaved(card);
			}

			setBusy(false);
			closeModal();
		}).catch(function (error) {
			setBusy(false);
			showError((error && error.message) ? error.message : t('errorGeneric', 'Non è stato possibile salvare. Riprova.'));
			ui.luogo.focus();
		});
	}

	/* ---------------------------------------------------------------------
	 * Avvio
	 * ------------------------------------------------------------------ */

	function refresh() {
		injectButtons();
		renderAll();
		syncUnknown();
	}

	function init() {
		if (!CFG.ajaxUrl || !CFG.nonce) {
			return;
		}

		refresh();

		// Delega: funziona anche sulle card create dopo il caricamento.
		document.addEventListener('click', function (event) {
			var button = event.target.closest ? event.target.closest('.' + CLS_BTN) : null;

			if (!button) {
				return;
			}

			var card = button.closest(SEL_CARD);

			if (!card) {
				return;
			}

			event.preventDefault();
			// Evita che il clic finisca sulla card o su handler del tema padre.
			event.stopPropagation();
			openModal(card);
		}, true);

		// La griglia viene riordinata (drag&drop) e ripopolata: teniamo il passo.
		if (typeof window.MutationObserver === 'function') {
			var target = document.querySelector(SEL_GRID) || document.body;
			var scheduled = false;
			var observerOptions = { childList: true, subtree: true };

			var observer = new MutationObserver(function () {
				if (scheduled) {
					return;
				}
				scheduled = true;
				window.setTimeout(function () {
					scheduled = false;
					// Sospendi l'osservazione mentre modifichiamo il DOM: le nostre
					// stesse mutazioni non devono rischedulare un altro refresh,
					// altrimenti l'osservatore si autoalimenta all'infinito.
					observer.disconnect();
					try {
						refresh();
					} finally {
						// Scarta le mutazioni prodotte da refresh() prima di riattivare.
						observer.takeRecords();
						observer.observe(target, observerOptions);
					}
				}, 120);
			});

			observer.observe(target, observerOptions);
		}
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
})();
