	<footer id="colophon" class="site-footer">
		<div class="container footer-inner">
			<div class="footer-columns">
				<div class="footer-widget">
					<?php
					$footer_logo_url = get_option('ticinoweb_site_logo');
					if (empty($footer_logo_url)) {
						if (has_custom_logo()) {
							$custom_logo_id = get_theme_mod('custom_logo');
							$footer_logo_url = wp_get_attachment_image_url($custom_logo_id, 'full');
						} else {
							$footer_logo_url = parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) . '/2026/06/Frasco-coat_of_arms.svg.png';
						}
					}
					?>
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="footer-logo-link" rel="home" style="display: block; margin-bottom: 15px;">
						<img src="<?php echo esc_url( $footer_logo_url ); ?>" alt="Stemma Patriziato di Frasco" class="footer-logo" style="max-width: 80px; height: auto;">
					</a>
					<h3 class="widget-title" style="margin-top: 0;">Patriziato di Frasco</h3>
					<p>Frasco è posto sul lato destro della valle Verzasca; il territorio patriziale comprende il laghetto alpino Efra e la rispettiva valle come pure la parte destra della valle Vogornesso.</p>
				</div>
				<div class="footer-widget">
					<?php 
					// Dynamic fetching from TicinoWEB CMS Panel
					$phone = get_option('ticinoweb_contact_phone', '+41 79 570 66 36');
					$email = get_option('ticinoweb_contact_email', 'patriziatofrasco@bluewin.ch');
					$address = get_option('ticinoweb_contact_address', '6636 FRASCO');
					$facebook = get_option('ticinoweb_contact_facebook', '');
					$instagram = get_option('ticinoweb_contact_instagram', '');
					?>
					<div class="footer-widget-spacer"></div>
					<h3 class="widget-title">Contatti</h3>
					<ul style="list-style: none; padding: 0; margin: 0;">
						<li style="margin-bottom: 0.8rem; display: flex; align-items: center; gap: 10px;">
							<svg style="min-width:20px;" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.8)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
							<a href="<?php echo esc_url( home_url( '/contatti/' ) ); ?>" style="text-decoration: none; color: inherit;"><?php echo esc_html($address); ?></a>
						</li>
						<li style="margin-bottom: 0.8rem; display: flex; align-items: center; gap: 10px;">
							<svg style="min-width:20px;" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.8)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
							<a href="mailto:<?php echo esc_attr($email); ?>" style="text-decoration: none; color: inherit;"><?php echo esc_html($email); ?></a>
						</li>

					</ul>
				</div>
				<div class="footer-widget">
					<div class="footer-widget-spacer"></div>
					<h3 class="widget-title">Legale</h3>
					<ul>
						<li><a href="<?php echo esc_url( home_url( '/privacy-policy/' ) ); ?>">Privacy Policy</a></li>
						<li><a href="<?php echo esc_url( home_url( '/termini-e-condizioni/' ) ); ?>">Termini e Condizioni</a></li>
						<li><a href="<?php echo esc_url( home_url( '/comunicati/' ) ); ?>">Comunicati</a></li>
					</ul>
				</div>
				<div class="footer-widget">
					<div class="footer-widget-spacer"></div>
					<h3 class="widget-title">Canale WhatsApp</h3>
					<p style="margin-bottom: 12px;">Entra a far parte del nostro canale WhatsApp per restare aggiornato su novità e comunicazioni del Patriziato.</p>
					<img src="<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/07/Screenshot-2026-07-21-alle-15.54.30.png" alt="QR code canale WhatsApp Patriziato di Frasco" style="max-width: 150px; width: 100%; height: auto; background: #fff; padding: 8px; border-radius: 8px;">
				</div>
			</div>
		</div><!-- .container -->
		
		<div class="site-info">
			<div class="container">
				<p>&copy; <?php echo date('Y'); ?> Patriziato di Frasco. Tutti i diritti riservati. | <a href="<?php echo esc_url( home_url( '/tw-login/' ) ); ?>" style="color: rgba(255, 255, 255, 0.8); text-decoration: none;">Area Riservata</a> | Design by <a href="https://ticinoweb.com" target="_blank" rel="noopener" style="color: rgba(255, 255, 255, 0.8); text-decoration: none;">TicinoWEB</a></p>
			</div>
		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<script>
// Toggle modalità giorno / notte
(function () {
	var btn = document.getElementById('theme-toggle');
	if (!btn) return;
	var root = document.documentElement;
	function sync() {
		var dark = root.getAttribute('data-theme') === 'dark';
		btn.setAttribute('aria-label', dark ? 'Attiva modalità chiara' : 'Attiva modalità scura');
	}
	sync();
	// Easter egg: 15 clic in 6 secondi avviano "Flappy Pesce"
	var clicks = [];
	var FISH_SRC = '<?php echo esc_url( parse_url( wp_upload_dir()['baseurl'], PHP_URL_PATH ) ); ?>/2026/06/pesce-volante.png';
	var BG_SRCS = <?php
		$ptf_bg = array();
		$ptf_terms = get_terms( array( 'taxonomy' => 'ticinoweb_media_gallery', 'hide_empty' => false ) );
		if ( ! empty( $ptf_terms ) && ! is_wp_error( $ptf_terms ) ) {
			foreach ( $ptf_terms as $ptf_term ) {
				if ( $ptf_term->name !== 'Galleria' ) { continue; }
				$ptf_q = new WP_Query( array(
					'post_type'      => 'attachment',
					'post_status'    => 'inherit',
					'posts_per_page' => 12,
					'tax_query'      => array( array(
						'taxonomy' => 'ticinoweb_media_gallery',
						'field'    => 'term_id',
						'terms'    => $ptf_term->term_id,
					) ),
				) );
				foreach ( $ptf_q->posts as $ptf_att ) {
					$ptf_src = wp_get_attachment_image_src( $ptf_att->ID, 'large' );
					if ( $ptf_src ) { $ptf_bg[] = $ptf_src[0]; }
				}
			}
		}
		echo wp_json_encode( $ptf_bg );
	?>;

	function easterEgg() {
		if (document.querySelector('.ptf-game-overlay')) return;

		var W = 420, H = 560, GRAV = 0.42, JUMP = -7.2, GAP = 155, PIPE_W = 62, SPEED = 2.4;

		var overlay = document.createElement('div');
		overlay.className = 'ptf-game-overlay';
		overlay.innerHTML =
			'<p class="ptf-game-title">Flappy Pesce</p>' +
			'<div class="ptf-game-stage">' +
				'<button type="button" class="ptf-game-close" aria-label="Chiudi gioco">&times;</button>' +
				'<canvas width="' + W + '" height="' + H + '"></canvas>' +
			'</div>' +
			'<p class="ptf-game-hint">Clic / Spazio per nuotare &middot; Esc o &times; per uscire</p>';
		document.body.appendChild(overlay);

		var canvas = overlay.querySelector('canvas');
		var ctx = canvas.getContext('2d');
		ctx.imageSmoothingEnabled = true;
		ctx.imageSmoothingQuality = 'high';

		// Rendering nitido su schermi Retina
		var DPR = Math.min(window.devicePixelRatio || 1, 3);
		canvas.width = W * DPR;
		canvas.height = H * DPR;
		canvas.style.width = W + 'px';
		canvas.style.height = H + 'px';
		ctx.scale(DPR, DPR);

		var fishImg = new Image();
		fishImg.src = FISH_SRC;

		// Sfondo: immagini della galleria in dissolvenza continua
		var bgImgs = [];
		(BG_SRCS || []).forEach(function (src) {
			var im = new Image();
			im.src = src;
			bgImgs.push(im);
		});
		var bgIndex = 0, bgT = 0, BG_HOLD = 260, BG_FADE = 90;

		function drawBackground() {
			if (!bgImgs.length) { return; }
			bgT++;
			var cur = bgImgs[bgIndex % bgImgs.length];
			var nxt = bgImgs[(bgIndex + 1) % bgImgs.length];
			var fade = bgT > BG_HOLD ? Math.min(1, (bgT - BG_HOLD) / BG_FADE) : 0;

			cover(cur, 1 - fade);
			if (fade > 0) { cover(nxt, fade); }
			if (bgT > BG_HOLD + BG_FADE) { bgT = 0; bgIndex++; }

			ctx.fillStyle = 'rgba(12, 16, 28, 0.55)';
			ctx.fillRect(0, 0, W, H);
		}

		function cover(im, alpha) {
			if (!im.complete || !im.naturalWidth) { return; }
			var r = Math.max(W / im.naturalWidth, H / im.naturalHeight);
			var w = im.naturalWidth * r, h = im.naturalHeight * r;
			ctx.globalAlpha = alpha;
			ctx.drawImage(im, (W - w) / 2, (H - h) / 2, w, h);
			ctx.globalAlpha = 1;
		}

		var best = 0;
		try { best = parseInt(localStorage.getItem('ptf-flappy-best') || '0', 10); } catch (e) {}

		var fish, pipes, score, state, raf;

		function reset() {
			fish = { x: 110, y: H / 2, v: 0, w: 96, h: 66 };
			pipes = [];
			score = 0;
			state = 'ready';
		}

		function addPipe() {
			var top = 60 + Math.random() * (H - GAP - 180);
			pipes.push({ x: W, top: top, scored: false });
		}

		function flap() {
			if (state === 'ready') { state = 'play'; addPipe(); }
			if (state === 'play') { fish.v = JUMP; }
			else if (state === 'over') { reset(); }
		}

		function hit(p) {
			return fish.x + fish.w * 0.42 > p.x && fish.x - fish.w * 0.42 < p.x + PIPE_W &&
				(fish.y - fish.h * 0.35 < p.top || fish.y + fish.h * 0.35 > p.top + GAP);
		}

		function drawPipe(p) {
			ctx.fillStyle = '#4a9d3f';
			ctx.fillRect(p.x, 0, PIPE_W, p.top);
			ctx.fillRect(p.x, p.top + GAP, PIPE_W, H - p.top - GAP);
			ctx.fillStyle = '#3d8434';
			ctx.fillRect(p.x - 5, p.top - 22, PIPE_W + 10, 22);
			ctx.fillRect(p.x - 5, p.top + GAP, PIPE_W + 10, 22);
		}

		function loop() {
			ctx.clearRect(0, 0, W, H);
			drawBackground();

			if (state === 'play') {
				fish.v += GRAV;
				fish.y += fish.v;

				for (var i = pipes.length - 1; i >= 0; i--) {
					var p = pipes[i];
					p.x -= SPEED;
					if (!p.scored && p.x + PIPE_W < fish.x) { p.scored = true; score++; }
					if (p.x + PIPE_W < -10) { pipes.splice(i, 1); }
					if (hit(p)) { state = 'over'; }
				}

				if (!pipes.length || pipes[pipes.length - 1].x < W - 210) { addPipe(); }
				if (fish.y > H - 30 || fish.y < 0) { state = 'over'; }

				if (state === 'over' && score > best) {
					best = score;
					try { localStorage.setItem('ptf-flappy-best', String(best)); } catch (e) {}
				}
			}

			pipes.forEach(drawPipe);

			ctx.save();
			ctx.translate(fish.x, fish.y);
			ctx.rotate(Math.max(-0.5, Math.min(1, fish.v / 12)));
			if (fishImg.complete && fishImg.naturalWidth) {
				ctx.drawImage(fishImg, -fish.w / 2, -fish.h / 2, fish.w, fish.h);
			} else {
				ctx.fillStyle = '#3C69E7';
				ctx.beginPath();
				ctx.ellipse(0, 0, fish.w / 2, fish.h / 2, 0, 0, Math.PI * 2);
				ctx.fill();
			}
			ctx.restore();

			ctx.fillStyle = '#fff';
			ctx.strokeStyle = 'rgba(0,0,0,0.45)';
			ctx.lineWidth = 4;
			ctx.font = 'bold 40px sans-serif';
			ctx.textAlign = 'center';
			ctx.strokeText(score, W / 2, 70);
			ctx.fillText(score, W / 2, 70);

			ctx.font = 'bold 18px sans-serif';
			if (state === 'ready') {
				ctx.strokeText('Clic per iniziare', W / 2, H / 2 + 90);
				ctx.fillText('Clic per iniziare', W / 2, H / 2 + 90);
			} else if (state === 'over') {
				ctx.font = 'bold 30px sans-serif';
				ctx.strokeText('Ahia!', W / 2, H / 2 - 10);
				ctx.fillText('Ahia!', W / 2, H / 2 - 10);
				ctx.font = 'bold 18px sans-serif';
				ctx.strokeText('Record: ' + best + ' — clic per riprovare', W / 2, H / 2 + 25);
				ctx.fillText('Record: ' + best + ' — clic per riprovare', W / 2, H / 2 + 25);
			}

			raf = requestAnimationFrame(loop);
		}

		function close() {
			cancelAnimationFrame(raf);
			document.removeEventListener('keydown', onKey);
			overlay.remove();
		}

		function onKey(e) {
			if (e.key === 'Escape' || e.key === 'Esc') { e.preventDefault(); close(); }
			else if (e.code === 'Space' || e.key === ' ') { e.preventDefault(); flap(); }
		}

		canvas.addEventListener('pointerdown', flap);

		// Delega sull'overlay: intercetta il clic sulla X ovunque si trovi
		overlay.addEventListener('pointerdown', function (e) {
			if (e.target.closest('.ptf-game-close')) {
				e.preventDefault();
				e.stopPropagation();
				close();
			}
		}, true);
		document.addEventListener('keydown', onKey);

		reset();
		loop();
	}

	function toggleTheme() {
		if (document.querySelector('.ptf-game-overlay')) { return; }
		var next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
		root.setAttribute('data-theme', next);
		try { localStorage.setItem('ptf-theme', next); } catch (e) {}
		sync();

		var now = Date.now();
		clicks.push(now);
		clicks = clicks.filter(function (t) { return now - t < 6000; });
		if (clicks.length >= 15) {
			clicks = [];
			easterEgg();
		}
	}

	// Su touch reagiamo a touchend annullando il comportamento nativo del browser
	// (doppio-tap = zoom su iOS), su desktop resta il click normale.
	var touched = false;

	btn.addEventListener('touchend', function (e) {
		e.preventDefault();
		touched = true;
		toggleTheme();
	}, { passive: false });

	btn.addEventListener('touchstart', function (e) {
		e.preventDefault();
	}, { passive: false });

	btn.addEventListener('click', function (e) {
		if (touched) { touched = false; return; }
		toggleTheme();
	});

	// Blocca lo zoom da doppio-tap sul pulsante anche su Safari legacy
	btn.addEventListener('dblclick', function (e) { e.preventDefault(); });
	btn.addEventListener('gesturestart', function (e) { e.preventDefault(); });
})();
</script>

<?php wp_footer(); ?>



</body>
</html>
