<?php
/**
 * Template Name: Pagina Interpellanze
 * 
 * Modello per visualizzare l'elenco delle interpellanze.
 */

get_header();

?>

<style>
/* Stili specifici per la lista Interpellanze */
.interpellanze-list {
    max-width: 900px;
    margin: 0 auto 80px auto;
    display: flex;
    flex-direction: column;
    gap: 40px;
}
.interp-card {
    background: var(--color-bg-pure-white);
    border-radius: var(--radius);
    border: 1px solid rgba(0,0,0,0.08);
    box-shadow: 0 10px 30px rgba(0,0,0,0.05);
    padding: 30px;
    display: flex;
    flex-direction: column;
    gap: 20px;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.interp-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 40px rgba(0,0,0,0.08);
}

.interp-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    flex-wrap: wrap;
    gap: 15px;
    border-bottom: 1px solid rgba(0,0,0,0.05);
    padding-bottom: 15px;
}

.interp-title {
    color: var(--color-primary-dark);
    margin: 0;
    font-size: 1.8rem;
    font-family: var(--font-heading);
}

.interp-oggetto {
    font-size: 1.1rem;
    color: var(--color-text);
    font-weight: bold;
    margin-top: 5px;
}

.interp-status {
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 0.85rem;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    white-space: nowrap;
}
/* Colori semantici per lo stato */
.status-in-attesa-di-risposta { background-color: #fff3cd; color: #856404; border: 1px solid #ffeeba; }
.status-risposta-pubblicata { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
.status-chiusa { background-color: #e2e3e5; color: #383d41; border: 1px solid #d6d8db; }
.status-ritirata { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }

.interp-meta {
    font-size: 0.95rem;
    color: var(--color-text-light);
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
}
.interp-meta-item {
    display: flex;
    align-items: center;
    gap: 8px;
}
.interp-meta strong {
    color: var(--color-text);
}

.interp-content {
    color: var(--color-text);
    line-height: 1.7;
    font-size: 1.05rem;
}

/* Riquadro Risposta */
.interp-risposta-box {
    background: #f4f7fb;
    border-left: 4px solid var(--color-primary);
    padding: 20px 25px;
    border-radius: 0 8px 8px 0;
    margin-top: 10px;
}
.interp-risposta-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
    flex-wrap: wrap;
    gap: 10px;
}
.interp-risposta-title {
    font-weight: bold;
    color: var(--color-primary-dark);
    font-size: 1.1rem;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 8px;
}
.interp-risposta-data {
    font-size: 0.9rem;
    color: var(--color-text-light);
}
.interp-risposta-text {
    color: var(--color-text);
    line-height: 1.6;
    margin: 0;
    white-space: pre-wrap; /* Preserva gli a capo inseriti nella textarea */
}

/* Modalità scura: riquadro risposta leggibile */
html[data-theme="dark"] .interp-risposta-box {
    background: rgba(255, 255, 255, 0.06);
}
html[data-theme="dark"] .interp-risposta-title {
    color: #FFFFFF;
}
html[data-theme="dark"] .interp-risposta-text,
html[data-theme="dark"] .interp-content,
html[data-theme="dark"] .interp-content p {
    color: var(--color-text-main);
}
html[data-theme="dark"] .interp-risposta-data {
    color: var(--color-text-light);
}

.interp-action {
    margin-top: 10px;
}
.btn-interp {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    background: var(--color-primary);
    color: white;
    padding: 10px 20px;
    border-radius: 4px;
    text-decoration: none;
    font-weight: bold;
    transition: background-color 0.3s;
}
.btn-interp:hover {
    background: var(--color-primary-dark);
    color: white;
}

.interp-empty {
    text-align: center;
    padding: 60px 20px;
    background: var(--color-bg-light);
    border-radius: var(--radius);
    color: var(--color-text-light);
    font-size: 1.1rem;
    font-style: italic;
}
</style>

<!-- Hero Section -->
<div class="page-header-cinematic no-bg" style="background-color: var(--color-primary-dark);">
    <div class="page-header-overlay"></div>
    <div class="container page-header-inner text-center animate-on-scroll">
        <h1 class="page-title"><?php the_title(); ?></h1>
        <h2 style="color: var(--color-accent); font-size: 1.5rem; font-weight: 500; font-family: var(--font-heading); margin-top: var(--space-sm);">Dialogo ufficiale tra cittadini e istituzione</h2>
    </div>
</div>

<main id="primary" class="site-main">
    <div class="container section-padding">

        <!-- Lista Interpellanze -->
        <div class="interpellanze-list">
            <?php
            // Query per le interpellanze pubblicate
            $interp_args = array(
                'post_type'      => 'interpellanza',
                'post_status'    => 'publish',
                'posts_per_page' => -1, // Mostra tutte
                'meta_key'       => '_interpellanza_data_presentazione', // Ordina per la data
                'orderby'        => 'meta_value',
                'order'          => 'DESC' // Dalla più recente alla più vecchia
            );
            $interp_query = new WP_Query( $interp_args );

            if ( $interp_query->have_posts() ) :

                while ( $interp_query->have_posts() ) : $interp_query->the_post();
                    $interp_id = get_the_ID();
                    
                    $data_pres = get_post_meta( $interp_id, '_interpellanza_data_presentazione', true );
                    $proponente = get_post_meta( $interp_id, '_interpellanza_proponente', true );
                    $oggetto = get_post_meta( $interp_id, '_interpellanza_oggetto', true );
                    $testo = get_post_meta( $interp_id, '_interpellanza_testo', true );
                    $stato = get_post_meta( $interp_id, '_interpellanza_stato', true );
                    $risposta = get_post_meta( $interp_id, '_interpellanza_risposta', true );
                    $data_risposta = get_post_meta( $interp_id, '_interpellanza_data_risposta', true );
                    
                    $pdf_id = get_post_meta( $interp_id, '_interpellanza_pdf_id', true );
                    $pdf_url = $pdf_id ? wp_get_attachment_url( $pdf_id ) : '';
                    
                    // Formattazione data presentazione
                    $data_pres_formattata = $data_pres ? date_i18n( 'j F Y', strtotime( $data_pres ) ) : get_the_date();

                    // Formattazione data risposta
                    $data_risp_formattata = $data_risposta ? date_i18n( 'j F Y', strtotime( $data_risposta ) ) : '';

                    // Classi stato
                    $status_class = sanitize_title($stato); // es. in-attesa-di-risposta
                    ?>

                    <div class="interp-card animate-on-scroll">
                        
                        <div class="interp-header">
                            <div>
                                <h2 class="interp-title"><?php the_title(); ?></h2>
                                <?php if ($oggetto) : ?>
                                    <div class="interp-oggetto"><?php echo esc_html($oggetto); ?></div>
                                <?php endif; ?>
                            </div>
                            
                            <?php if ( $stato ) : ?>
                                <span class="interp-status status-<?php echo esc_attr($status_class); ?>">
                                    <?php echo esc_html($stato); ?>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="interp-meta">
                            <div class="interp-meta-item">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="var(--color-primary)"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                                <span>Presentata il: <strong><?php echo esc_html($data_pres_formattata); ?></strong></span>
                            </div>
                            
                            <?php if ( $proponente ) : ?>
                            <div class="interp-meta-item">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="var(--color-primary)"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
                                <span>Interpellante: <strong><?php echo esc_html($proponente); ?></strong></span>
                            </div>
                            <?php endif; ?>
                        </div>

                        <!-- Testo Interpellanza (Meta personalizzato) -->
                        <?php if ($testo): ?>
                        <div class="interp-content">
                            <?php echo wpautop( esc_html($testo) ); ?>
                        </div>
                        <?php endif; ?>

                        <!-- Riquadro Risposta (se presente) -->
                        <?php if ( !empty($risposta) ) : ?>
                            <div class="interp-risposta-box">
                                <div class="interp-risposta-header">
                                    <h3 class="interp-risposta-title">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6"></path></svg>
                                        Risposta del Consiglio Patriziale
                                    </h3>
                                    <?php if ($data_risp_formattata): ?>
                                        <span class="interp-risposta-data">Risposta del <?php echo esc_html($data_risp_formattata); ?></span>
                                    <?php endif; ?>
                                </div>
                                <p class="interp-risposta-text"><?php echo esc_html($risposta); ?></p>
                            </div>
                        <?php endif; ?>

                        <!-- Bottone PDF -->
                        <?php if ( $pdf_url ) : ?>
                            <div class="interp-action">
                                <a href="<?php echo esc_url($pdf_url); ?>" class="btn-interp" target="_blank" rel="noopener">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                                    Scarica Documento Originale (PDF)
                                </a>
                            </div>
                        <?php endif; ?>

                    </div>

                <?php 
                endwhile;
                wp_reset_postdata();

            else :
                ?>
                <div class="interp-empty animate-on-scroll">
                    Al momento non sono presenti interpellanze pubblicate.
                </div>
            <?php
            endif;
            ?>
        </div>

    </div>
</main>

<?php
get_footer();
