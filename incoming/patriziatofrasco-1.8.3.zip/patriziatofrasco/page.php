<?php
/**
 * The template for displaying all pages
 *
 * @package Patriziato Frasco
 */

get_header();
?>

<main id="primary" class="site-main">

	<?php
	while ( have_posts() ) :
		the_post();
		?>
		
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			
			<?php 
			$has_thumbnail = has_post_thumbnail();
			$thumbnail_url = $has_thumbnail ? get_the_post_thumbnail_url(get_the_ID(), 'full') : '';
			$header_class = $has_thumbnail ? 'page-header-cinematic has-bg' : 'page-header-cinematic no-bg';
			?>
			<header class="<?php echo esc_attr($header_class); ?>" <?php if ($has_thumbnail) echo 'style="background-image: url(\'' . esc_url($thumbnail_url) . '\');"'; ?>>
				<div class="page-header-overlay"></div>
				<div class="container page-header-inner animate-on-scroll">
					<?php the_title( '<h1 class="page-title">', '</h1>' ); ?>
				</div>
			</header>

			<div class="page-content-wrapper" style="margin-top: var(--space-xl); margin-bottom: var(--space-xxl);">
				<div class="page-content custom-gutenberg-layout" style="font-size: 1.1rem; line-height: 1.8;">
					<?php
					the_content();

					wp_link_pages(
						array(
							'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'patriziatofrasco' ),
							'after'  => '</div>',
						)
					);
					?>
				</div><!-- .page-content -->
			</div>
			
		</article><!-- #post-<?php the_ID(); ?> -->

		<?php
	endwhile; // End of the loop.
	?>

</main><!-- #main -->

<?php
get_footer();
