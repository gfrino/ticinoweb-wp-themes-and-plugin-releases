<?php
/**
 * Template Name: Page Galleria
 */

get_header();
?>

<style>
    .gallery-grid-images {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: var(--space-lg);
        margin-top: var(--space-md);
        margin-bottom: var(--space-xl);
    }

    .gallery-image-item {
        position: relative;
        border-radius: calc(var(--radius) - 5px);
        overflow: hidden;
        box-shadow: 0 10px 20px rgba(60, 105, 231, 0.05);
        transition: var(--transition);
        cursor: pointer;
        height: 250px;
        background-color: var(--color-bg-light);
    }

    .gallery-image-item:hover {
        transform: scale(1.02);
        box-shadow: 0 15px 30px rgba(60, 105, 231, 0.15);
    }

    .gallery-image-item img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        display: block;
    }

    /* Riquadro didascalia (Luogo, Data) appoggiato sulla miniatura */
    .gallery-image-item .ptf-caption-badge {
        position: absolute;
        bottom: 12px;
        right: 12px;
        max-width: calc(100% - 24px);
        background: var(--color-bg-pure-white);
        padding: 8px 16px;
        border-radius: calc(var(--radius) - 4px);
        font-family: var(--font-heading);
        font-style: italic;
        font-size: 0.95rem;
        line-height: 1.3;
        color: var(--color-secondary);
        box-shadow: 0 6px 18px rgba(0, 0, 0, 0.18);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        pointer-events: none;
        user-select: none;
    }

    /* Scuro: il riquadro diventa scuro con testo chiaro (mai blu su grigio) */
    html[data-theme="dark"] .gallery-image-item .ptf-caption-badge {
        background: var(--color-bg-pure-white);
        color: var(--color-text-main);
        box-shadow: 0 6px 18px rgba(0, 0, 0, 0.45);
    }

    /* Frecce di navigazione Lightbox */
    .lightbox-arrow {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        color: #FFFFFF;
        font-size: 3rem;
        font-weight: bold;
        cursor: pointer;
        padding: 20px;
        transition: var(--transition);
        user-select: none;
        z-index: 10000;
        opacity: 0.7;
    }
    .lightbox-arrow:hover {
        opacity: 1;
        color: var(--color-accent);
        transform: translateY(-50%) scale(1.1);
    }
    .lightbox-prev {
        left: 30px;
    }
    .lightbox-next {
        right: 30px;
    }

    /* Immagine + didascalia impilate al centro della Lightbox */
    .lightbox-figure {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        max-width: 85%;
        max-height: 90vh;
        z-index: 9999;
    }

    /* Sfondo blu pieno: la didascalia deve essere bianca */
    #simple-lightbox .lightbox-caption {
        margin-top: var(--space-sm);
        max-width: 100%;
        text-align: center;
        font-family: var(--font-heading);
        font-style: italic;
        font-size: 1.15rem;
        line-height: 1.4;
        color: #FFFFFF;
        text-shadow: 0 2px 10px rgba(0, 0, 0, 0.45);
        cursor: default;
    }

    @media (max-width: 768px) {
        .lightbox-arrow {
            font-size: 2rem;
            padding: 10px;
        }
        .lightbox-prev { left: 5px; }
        .lightbox-next { right: 5px; }

        .gallery-image-item .ptf-caption-badge {
            bottom: 8px;
            right: 8px;
            max-width: calc(100% - 16px);
            padding: 6px 12px;
            font-size: 0.85rem;
        }

        #simple-lightbox .lightbox-caption {
            font-size: 1rem;
        }
    }

    /* Lightbox: didascalia in evidenza, luogo e data come riga secondaria */
    #simple-lightbox .lightbox-didascalia {
        display: block;
        font-size: 1.05rem;
        line-height: 1.5;
        color: #FFFFFF;
        max-width: 70ch;
        margin: 0 auto;
    }
    #simple-lightbox .lightbox-luogodata {
        display: block;
        margin-top: 8px;
        font-size: 0.9rem;
        font-style: italic;
        color: rgba(255, 255, 255, 0.8);
    }
    @media (max-width: 768px) {
        #simple-lightbox .lightbox-didascalia { font-size: 0.95rem; }
        #simple-lightbox .lightbox-luogodata { font-size: 0.82rem; }
    }
</style>

<main id="primary" class="site-main page-content" style="padding-bottom: var(--space-xxl);">

	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
		<?php 
		$has_thumbnail = has_post_thumbnail();
		$thumbnail_url = $has_thumbnail ? get_the_post_thumbnail_url(get_the_ID(), 'full') : '';
		$header_class = $has_thumbnail ? 'page-header-cinematic has-bg' : 'page-header-cinematic no-bg';
		?>
		<header class="<?php echo esc_attr($header_class); ?>" <?php if ($has_thumbnail) echo 'style="background-image: url(\'' . esc_url($thumbnail_url) . '\');"'; ?>>
			<div class="page-header-overlay"></div>
			<div class="container page-header-inner animate-on-scroll">
				<h1 class="page-title"><?php the_title(); ?></h1>
				<h2 style="color: var(--color-accent); font-size: 1.5rem; font-weight: 500; font-family: var(--font-heading); margin-top: var(--space-sm);">Sfoglia le immagini e i ricordi del Patriziato.</h2>
			</div>
		</header>
	<?php endwhile; endif; ?>

    <div class="container" style="margin-top: var(--space-xl);">

        <?php
        $terms = get_terms(array(
            'taxonomy' => 'ticinoweb_media_gallery',
            'hide_empty' => false,
        ));

        if (!empty($terms) && !is_wp_error($terms)) {
            $found_images = false;

            foreach ($terms as $term) {
                // Filtra per mostrare SOLTANTO la galleria chiamata "Galleria"
                if ($term->name != "Galleria") {
                    continue;
                }

                $args_all = array(
                    'post_type' => 'attachment',
                    'post_status' => 'inherit',
                    'posts_per_page' => -1,
                    'tax_query' => array(
                        array(
                            'taxonomy' => 'ticinoweb_media_gallery',
                            'field' => 'term_id',
                            'terms' => $term->term_id,
                        )
                    )
                );
                $query_all = new WP_Query($args_all);

                if ($query_all->have_posts()) {
                    $found_images = true;
                    ?>
                    <div class="gallery-grid-images">
                        <?php
                        while ($query_all->have_posts()) {
                            $query_all->the_post();
                            $full_url_src = wp_get_attachment_image_src(get_the_ID(), 'full');
                            $full_url = $full_url_src ? $full_url_src[0] : '';

                            $thumb_url_src = wp_get_attachment_image_src(get_the_ID(), 'medium_large');
                            $thumb_url = $thumb_url_src ? $thumb_url_src[0] : '';

                            if (empty($thumb_url)) $thumb_url = $full_url;

                            // Riquadro sulla miniatura: solo "Luogo, Data".
                            $didascalia = function_exists('ptf_media_caption') ? ptf_media_caption(get_the_ID()) : '';
                            // Testo mostrato quando si apre la foto: campo "Didascalia".
                            $testo_apertura = function_exists('ptf_media_didascalia') ? ptf_media_didascalia(get_the_ID()) : '';

                            if (!empty($full_url)) {
                                ?>
                                <div class="gallery-image-item" data-full-url="<?php echo esc_url($full_url); ?>" data-caption="<?php echo esc_attr($didascalia); ?>" data-didascalia="<?php echo esc_attr($testo_apertura); ?>">
                                    <img src="<?php echo esc_url($thumb_url); ?>" loading="lazy" alt="<?php the_title_attribute(); ?>">
                                    <?php
                                    if (function_exists('ptf_media_caption_badge')) {
                                        ptf_media_caption_badge($didascalia);
                                    }
                                    ?>
                                </div>
                                <?php
                            }
                        }
                        ?>
                    </div>
                    <?php
                }
                wp_reset_postdata();
            }
        } else {
            echo '<div style="text-align: center; padding: var(--space-xxl); background: var(--color-bg-pure-white); border-radius: var(--radius);"><p style="color: var(--color-primary-light); font-size: 1.2rem;">Nessuna foto pubblicata al momento.</p></div>';
        }
        ?>

    </div>

    <!-- SIMPLE LIGHTBOX MODAL WITH ARROWS -->
    <div id="simple-lightbox" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(60, 105, 231, 0.95); z-index: 9999; align-items: center; justify-content: center; opacity: 0; transition: opacity 0.3s; cursor: pointer;">
        <span onclick="closeLightbox()" style="position: absolute; top: 20px; right: 30px; color: var(--color-accent); font-size: 50px; cursor: pointer; transition: var(--transition); z-index: 10000;">&times;</span>
        
        <div class="lightbox-arrow lightbox-prev" onclick="changeImage(-1, event)">&#10094;</div>
        <div class="lightbox-figure">
            <img id="lightbox-img" src="" style="max-width: 100%; max-height: 78vh; border-radius: calc(var(--radius) - 5px); box-shadow: 0 25px 50px rgba(0,0,0,0.5); cursor: default; object-fit: contain; z-index: 9999;" onclick="event.stopPropagation()">
            <div id="lightbox-caption" class="lightbox-caption" style="display: none;" onclick="event.stopPropagation()"></div>
        </div>
        <div class="lightbox-arrow lightbox-next" onclick="changeImage(1, event)">&#10095;</div>
    </div>

</main>

<script>
    let currentImageIndex = 0;
    let galleryImages = [];

    // All'avvio della pagina, raccogliamo tutte le foto in un array
    document.addEventListener("DOMContentLoaded", function() {
        var items = document.querySelectorAll('.gallery-image-item');
        items.forEach(function(item, index) {
            galleryImages.push({
                url: item.getAttribute('data-full-url'),
                caption: item.getAttribute('data-caption') || '',
                didascalia: item.getAttribute('data-didascalia') || ''
            });
            // Associamo il click all'indice della foto
            item.onclick = function() {
                openLightbox(index);
            };
        });
    });

    function openLightbox(index) {
        currentImageIndex = index;
        updateLightboxImage();
        
        var lightbox = document.getElementById('simple-lightbox');
        lightbox.style.display = 'flex';
        void lightbox.offsetWidth; // force reflow
        lightbox.style.opacity = '1';
        document.body.style.overflow = 'hidden';
        
        // Ascoltiamo i comandi da tastiera
        document.addEventListener('keydown', handleKeydown);
    }

    function updateLightboxImage() {
        var current = galleryImages[currentImageIndex];
        if (!current) return;

        var img = document.getElementById('lightbox-img');
        img.src = current.url;
        img.alt = current.didascalia || current.caption;

        // Sotto la foto: prima la didascalia, poi luogo e data in piccolo.
        // Se non c'è nulla da mostrare, il blocco resta nascosto.
        var caption = document.getElementById('lightbox-caption');
        var righe = '';

        if (current.didascalia) {
            righe += '<span class="lightbox-didascalia"></span>';
        }
        if (current.caption) {
            righe += '<span class="lightbox-luogodata"></span>';
        }

        caption.innerHTML = righe;

        if (current.didascalia) {
            caption.querySelector('.lightbox-didascalia').textContent = current.didascalia;
        }
        if (current.caption) {
            caption.querySelector('.lightbox-luogodata').textContent = current.caption;
        }

        caption.style.display = (current.didascalia || current.caption) ? 'block' : 'none';
    }

    function changeImage(direction, event) {
        // Impediamo che il clic sulla freccia chiuda la galleria
        if(event) event.stopPropagation(); 
        
        currentImageIndex += direction;
        
        // Ciclo continuo infinito (Carousel)
        if (currentImageIndex >= galleryImages.length) {
            currentImageIndex = 0;
        } else if (currentImageIndex < 0) {
            currentImageIndex = galleryImages.length - 1;
        }
        
        updateLightboxImage();
    }

    function closeLightbox() {
        var lightbox = document.getElementById('simple-lightbox');
        lightbox.style.opacity = '0';
        document.body.style.overflow = '';
        
        // Rimuoviamo l'ascolto della tastiera per sicurezza
        document.removeEventListener('keydown', handleKeydown);
        
        setTimeout(function () {
            lightbox.style.display = 'none';
            document.getElementById('lightbox-img').src = '';
            document.getElementById('lightbox-caption').textContent = '';
        }, 300);
    }

    // Gestione dei comandi freccia e Esc sulla tastiera
    function handleKeydown(e) {
        if (e.key === 'ArrowLeft') {
            changeImage(-1, null);
        } else if (e.key === 'ArrowRight') {
            changeImage(1, null);
        } else if (e.key === 'Escape') {
            closeLightbox();
        }
    }

    // Chiude la galleria cliccando fuori dall'immagine
    document.getElementById('simple-lightbox').addEventListener('click', function (e) {
        closeLightbox();
    });
</script>

<?php get_footer(); ?>
