( function () {
    var url = ( window.liceoHero || {} ).video;
    var img = document.querySelector( '.hero-slider .slide .slide-image' );
    // Con il movimento ridotto resta la foto.
    if ( ! url || ! img || ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) ) {
        return;
    }
    var v = document.createElement( 'video' );
    v.className = 'slide-image slide-video';
    v.muted = true;
    v.loop = true;
    v.autoplay = true;
    v.playsInline = true;
    v.setAttribute( 'playsinline', '' );
    v.setAttribute( 'muted', '' );
    v.setAttribute( 'aria-hidden', 'true' );
    v.preload = 'metadata';
    v.poster = img.currentSrc || img.src;
    v.src = url;
    img.parentNode.insertBefore( v, img.nextSibling );
    v.addEventListener( 'playing', function () { img.style.visibility = 'hidden'; } );
    var p = v.play();
    if ( p && p.catch ) {
        p.catch( function () {} ); // se il browser blocca l'avvio resta la foto
    }
} )();
