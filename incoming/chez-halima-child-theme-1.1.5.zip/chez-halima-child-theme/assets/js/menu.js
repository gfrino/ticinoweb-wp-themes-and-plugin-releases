/* Menu da telefono e tablet: un pulsante apre e chiude la navigazione del parent.
 * Senza questo script il menu resta visibile come lo stampa il parent. */
(function () {
    var header = document.querySelector('.site-header');
    var nav = header && header.querySelector('.main-navigation');
    var button = header && header.querySelector('.ch-menu-toggle');
    if (!nav || !button) {
        return;
    }
    var label = button.querySelector('.ch-menu-toggle__label');
    var compact = window.matchMedia('(max-width: 64em)');

    // Il pulsante va prima del menu, così con il tasto Tab si entra subito nelle voci aperte.
    header.insertBefore(button, nav);
    nav.id = nav.id || 'ch-primary-nav';
    button.setAttribute('aria-controls', nav.id);
    header.classList.add('ch-nav-ready');

    function setOpen(open) {
        header.classList.toggle('is-menu-open', open);
        button.setAttribute('aria-expanded', open ? 'true' : 'false');
        label.textContent = open ? button.dataset.labelClose : button.dataset.labelOpen;
    }

    button.addEventListener('click', function () {
        setOpen(button.getAttribute('aria-expanded') !== 'true');
    });

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape' && header.classList.contains('is-menu-open')) {
            setOpen(false);
            button.focus();
        }
    });

    nav.addEventListener('click', function (event) {
        if (event.target.closest('a')) {
            setOpen(false);
        }
    });

    compact.addEventListener('change', function () {
        setOpen(false);
    });
})();
