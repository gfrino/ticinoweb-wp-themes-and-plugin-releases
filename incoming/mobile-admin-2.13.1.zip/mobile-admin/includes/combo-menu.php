<?php
/**
 * Menù combinati dell'app (v2.13.0)
 *
 * When the cart holds a poké and no drink/dessert, the app offers a menu
 * before checkout ("Crea Menù": poké + acqua / + dessert / + acqua e dessert,
 * each a fixed surcharge) and, if the customer skips it, a quick "Aggiungi una
 * bibita" page. Everything shown there is managed here:
 *
 *  - Admin page  Gestione App → Menù combinati (brand hub only, like Metodi di
 *                Pagamento). One configuration for every sede: products are
 *                chosen BY NAME, so each sede shows the ones it actually sells.
 *  - Storage     NETWORK option `ard_app_combo_menu`.
 *  - REST        GET mobile-admin/v1/combo-menu?site=<sede host>: the config
 *                with the products resolved in that sede (id, price, image),
 *                plus the category ids the app needs to recognise a poké and
 *                a drink/dessert already in the cart.
 */

defined( 'ABSPATH' ) || exit;

const ARD_COMBO_OPTION = 'ard_app_combo_menu';

/** The three menu offers, in the order the app shows them. */
function ARD_combo_offers_catalog() {
	return array(
		'water'         => array( 'label' => 'Pokè + Acqua', 'price' => 1.0, 'parts' => array( 'water' ) ),
		'dessert'       => array( 'label' => 'Pokè + Dessert', 'price' => 3.0, 'parts' => array( 'dessert' ) ),
		'water_dessert' => array( 'label' => 'Pokè + Acqua + Dessert', 'price' => 4.0, 'parts' => array( 'water', 'dessert' ) ),
	);
}

function ARD_combo_defaults() {
	$offers = array();
	foreach ( ARD_combo_offers_catalog() as $key => $offer ) {
		$offers[ $key ] = array( 'enabled' => true, 'price' => $offer['price'] );
	}
	return array(
		'enabled'        => false,
		'offers'         => $offers,
		'waters'         => array(),
		'desserts'       => array(),
		'drinks_enabled' => false,
		'drinks'         => array(),
	);
}

function ARD_combo_settings() {
	$saved    = (array) get_site_option( ARD_COMBO_OPTION, array() );
	$defaults = ARD_combo_defaults();
	$settings = array_merge( $defaults, array_intersect_key( $saved, $defaults ) );
	foreach ( $defaults['offers'] as $key => $offer ) {
		$settings['offers'][ $key ] = array_merge( $offer, (array) ( $settings['offers'][ $key ] ?? array() ) );
	}
	foreach ( array( 'waters', 'desserts', 'drinks' ) as $list ) {
		$settings[ $list ] = array_values( array_filter( array_map( 'strval', (array) $settings[ $list ] ) ) );
	}
	return $settings;
}

/** Product names are matched case- and accent-insensitively across sedi. */
function ARD_combo_name_key( $name ) {
	$name = wp_strip_all_tags( html_entity_decode( (string) $name, ENT_QUOTES, 'UTF-8' ) );
	return strtolower( remove_accents( trim( preg_replace( '/\s+/', ' ', $name ) ) ) );
}

/** blog_id for a sede host, 0 if unknown. */
function ARD_combo_blog_id( $host ) {
	if ( ! is_multisite() ) {
		return get_current_blog_id();
	}
	$site = get_site_by_path( ARD_payment_methods_normalize_host( $host ), '/' );
	return $site ? (int) $site->blog_id : 0;
}

/**
 * Published products of the current blog: [ name_key => data ].
 * Must run inside switch_to_blog() for a sede. Reads the tables directly: the
 * brand hub (where this runs) has no WooCommerce, so `product` and
 * `product_cat` are not registered there and the WP query API returns nothing.
 */
function ARD_combo_blog_products() {
	global $wpdb;
	$rows = $wpdb->get_results(
		"SELECT p.ID, p.post_title,
			MAX(CASE WHEN m.meta_key = '_price' THEN m.meta_value END) AS price,
			MAX(CASE WHEN m.meta_key = '_stock_status' THEN m.meta_value END) AS stock,
			MAX(CASE WHEN m.meta_key = '_thumbnail_id' THEN m.meta_value END) AS thumb
		FROM {$wpdb->posts} p
		LEFT JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key IN ('_price','_stock_status','_thumbnail_id')
		WHERE p.post_type = 'product' AND p.post_status = 'publish'
		GROUP BY p.ID
		ORDER BY p.menu_order, p.ID"
	);
	if ( ! $rows ) {
		return array();
	}

	$cats = array();
	foreach ( (array) $wpdb->get_results(
		"SELECT tr.object_id, t.term_id, t.name
		FROM {$wpdb->term_relationships} tr
		JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id AND tt.taxonomy = 'product_cat'
		JOIN {$wpdb->terms} t ON t.term_id = tt.term_id"
	) as $c ) {
		$cats[ (int) $c->object_id ][] = array( 'id' => (int) $c->term_id, 'name' => html_entity_decode( $c->name, ENT_QUOTES, 'UTF-8' ) );
	}

	$products = array();
	foreach ( $rows as $row ) {
		$key = ARD_combo_name_key( $row->post_title );
		if ( '' === $key || isset( $products[ $key ] ) ) {
			continue;
		}
		$thumb = (int) $row->thumb;
		$products[ $key ] = array(
			'id'         => (int) $row->ID,
			'name'       => html_entity_decode( $row->post_title, ENT_QUOTES, 'UTF-8' ),
			'price'      => ( null === $row->price || '' === $row->price ) ? null : (float) $row->price,
			'image'      => $thumb ? (string) wp_get_attachment_image_url( $thumb, 'thumbnail' ) : '',
			'in_stock'   => 'outofstock' !== $row->stock,
			'categories' => $cats[ (int) $row->ID ] ?? array(),
		);
	}
	return $products;
}

/** product_cat terms of the current blog whose name or slug mentions poké. */
function ARD_combo_blog_poke_categories() {
	global $wpdb;
	$ids = array();
	foreach ( (array) $wpdb->get_results(
		"SELECT t.term_id, t.name, t.slug FROM {$wpdb->terms} t
		JOIN {$wpdb->term_taxonomy} tt ON tt.term_id = t.term_id AND tt.taxonomy = 'product_cat'"
	) as $t ) {
		if ( false !== strpos( ARD_combo_name_key( $t->name . ' ' . $t->slug ), 'pok' ) ) {
			$ids[] = (int) $t->term_id;
		}
	}
	return $ids;
}

/**
 * Catalog for the admin pickers: every product name sold in at least one sede,
 * with the sedi that sell it. Cached for 30 minutes, flushed on save.
 */
function ARD_combo_catalog() {
	$cached = get_site_transient( 'ard_combo_catalog' );
	if ( is_array( $cached ) ) {
		return $cached;
	}
	$catalog = array();
	foreach ( ARD_payment_methods_sites() as $host => $label ) {
		$blog_id = ARD_combo_blog_id( $host );
		if ( ! $blog_id ) {
			continue;
		}
		switch_to_blog( $blog_id );
		foreach ( ARD_combo_blog_products() as $key => $product ) {
			if ( ! isset( $catalog[ $key ] ) ) {
				$catalog[ $key ] = array(
					'name'     => $product['name'],
					'image'    => $product['image'],
					'price'    => $product['price'],
					'category' => $product['categories'][0]['name'] ?? '',
					'sedi'     => array(),
				);
			}
			$catalog[ $key ]['sedi'][] = $label;
		}
		restore_current_blog();
	}
	uasort( $catalog, static function ( $a, $b ) {
		return strcasecmp( $a['category'] . ' ' . $a['name'], $b['category'] . ' ' . $b['name'] );
	} );
	set_site_transient( 'ard_combo_catalog', $catalog, 30 * MINUTE_IN_SECONDS );
	return $catalog;
}

function ARD_combo_flush_cache() {
	delete_site_transient( 'ard_combo_catalog' );
	foreach ( array_keys( ARD_payment_methods_sites() ) as $host ) {
		delete_site_transient( 'ard_combo_' . md5( $host ) );
	}
	do_action( 'litespeed_purge_all' );
}

/* ------------------------------------------------------------------ admin */

add_action( 'admin_menu', 'ARD_combo_menu', 21 );
function ARD_combo_menu() {
	if ( ! ARD_payment_methods_is_hub() ) {
		return;
	}
	add_submenu_page( 'ard_stato_app', 'Menù combinati', 'Menù combinati', 'manage_options', 'ard_combo_menu', 'ARD_combo_render_page' );
}

function ARD_combo_handle_save() {
	if ( ! isset( $_POST['ard_combo_nonce'] )
		|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ard_combo_nonce'] ) ), 'ard_save_combo_menu' ) ) {
		return null;
	}
	$posted   = wp_unslash( $_POST );
	$catalog  = ARD_combo_catalog();
	$settings = ARD_combo_defaults();

	$settings['enabled']        = ! empty( $posted['ard_combo_enabled'] );
	$settings['drinks_enabled'] = ! empty( $posted['ard_combo_drinks_enabled'] );
	foreach ( ARD_combo_offers_catalog() as $key => $offer ) {
		$price = isset( $posted['ard_combo_offer'][ $key ]['price'] ) ? str_replace( ',', '.', (string) $posted['ard_combo_offer'][ $key ]['price'] ) : $offer['price'];
		$settings['offers'][ $key ] = array(
			'enabled' => ! empty( $posted['ard_combo_offer'][ $key ]['enabled'] ),
			'price'   => max( 0, round( (float) $price, 2 ) ),
		);
	}
	// Only names that exist in the catalog are kept (no free text).
	foreach ( array( 'waters', 'desserts', 'drinks' ) as $list ) {
		$names = isset( $posted[ 'ard_combo_' . $list ] ) ? (array) $posted[ 'ard_combo_' . $list ] : array();
		$keep  = array();
		foreach ( $names as $key ) {
			$key = sanitize_text_field( (string) $key );
			if ( isset( $catalog[ $key ] ) ) {
				$keep[] = $key;
			}
		}
		$settings[ $list ] = array_values( array_unique( $keep ) );
	}

	$problems = array();
	if ( $settings['enabled'] ) {
		if ( ! array_filter( wp_list_pluck( $settings['offers'], 'enabled' ) ) ) {
			$problems[] = 'accendi almeno un\'offerta del menù';
		}
		$needs_water   = $settings['offers']['water']['enabled'] || $settings['offers']['water_dessert']['enabled'];
		$needs_dessert = $settings['offers']['dessert']['enabled'] || $settings['offers']['water_dessert']['enabled'];
		if ( $needs_water && ! $settings['waters'] ) {
			$problems[] = 'scegli almeno un\'acqua';
		}
		if ( $needs_dessert && ! $settings['desserts'] ) {
			$problems[] = 'scegli almeno un dessert';
		}
	}
	if ( $settings['drinks_enabled'] && ! $settings['drinks'] ) {
		$problems[] = 'scegli almeno una bibita da proporre';
	}

	update_site_option( ARD_COMBO_OPTION, $settings );
	ARD_combo_flush_cache();
	return $problems;
}

function ARD_combo_render_page() {
	if ( ! ARD_payment_methods_is_hub() || ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Pagina disponibile solo sul sito principale del brand.' );
	}
	if ( isset( $_GET['ard_combo_refresh'] ) && check_admin_referer( 'ard_combo_refresh' ) ) {
		delete_site_transient( 'ard_combo_catalog' );
	}
	$problems = ARD_combo_handle_save();
	$settings = ARD_combo_settings();
	$catalog  = ARD_combo_catalog();
	$offers   = ARD_combo_offers_catalog();

	if ( is_array( $problems ) ) {
		if ( $problems ) {
			echo '<div class="notice notice-warning"><p>Salvato, ma l\'app non mostrerà la pagina finché non ' . esc_html( implode( ', ', $problems ) ) . '.</p></div>';
		} else {
			echo '<div class="notice notice-success"><p>Menù combinati salvati. L\'app li usa dal prossimo carrello.</p></div>';
		}
	}
	$refresh_url = wp_nonce_url( add_query_arg( 'ard_combo_refresh', 1 ), 'ard_combo_refresh' );
	?>
	<style>
		.ard-cm-wrap { max-width: 1000px; }
		.ard-cm-intro { color: #50575e; margin: 0 0 18px; max-width: 780px; }
		.ard-cm-card { background: #fff; border: 1px solid #dcdcde; border-radius: 12px; padding: 18px 22px; margin-bottom: 16px; }
		.ard-cm-card h2 { margin: 0 0 4px; font-size: 17px; display: flex; align-items: center; gap: 12px; }
		.ard-cm-card > p.desc { color: #646970; margin: 0 0 14px; }
		.ard-cm-switch { position: relative; display: inline-flex; align-items: center; gap: 8px; cursor: pointer; font-weight: 600; font-size: 13px; }
		.ard-cm-switch input { position: absolute; opacity: 0; width: 0; height: 0; }
		.ard-cm-switch .knob { width: 34px; height: 20px; border-radius: 999px; background: #c3c4c7; position: relative; transition: background .15s; flex: none; }
		.ard-cm-switch .knob::after { content: ""; position: absolute; top: 2px; left: 2px; width: 16px; height: 16px; border-radius: 50%; background: #fff; box-shadow: 0 1px 2px rgba(0,0,0,.25); transition: left .15s; }
		.ard-cm-switch input:checked + .knob { background: #1ca5a8; }
		.ard-cm-switch input:checked + .knob::after { left: 16px; }
		.ard-cm-switch input:focus-visible + .knob { outline: 2px solid #1ca5a8; outline-offset: 2px; }
		.ard-cm-layout { display: grid; grid-template-columns: 1fr 300px; gap: 22px; align-items: start; }
		.ard-cm-offer { display: flex; align-items: center; gap: 14px; padding: 10px 0; border-top: 1px solid #f0f0f1; }
		.ard-cm-offer:first-child { border-top: 0; }
		.ard-cm-offer .name { flex: 1; font-size: 14px; font-weight: 600; }
		.ard-cm-price { display: inline-flex; align-items: center; border: 1px solid #8c8f94; border-radius: 6px; overflow: hidden; }
		.ard-cm-price span { background: #f6f7f7; padding: 0 8px; color: #50575e; font-size: 12px; line-height: 30px; border-right: 1px solid #dcdcde; }
		.ard-cm-price input { border: 0; width: 70px; text-align: right; box-shadow: none; }
		.ard-cm-phone { background: #f6f7f7; border-radius: 26px; padding: 16px; border: 6px solid #1d2327; }
		.ard-cm-phone h3 { margin: 0 0 10px; color: #1ca5a8; font-size: 15px; text-align: center; }
		.ard-cm-phone .row { background: #fff; border-radius: 12px; padding: 10px 12px; margin-bottom: 8px; display: flex; justify-content: space-between; font-size: 13px; box-shadow: 0 1px 2px rgba(0,0,0,.08); }
		.ard-cm-phone .row b { color: #1ca5a8; }
		.ard-cm-phone .skip { text-align: center; color: #646970; font-size: 12px; margin-top: 6px; text-decoration: underline; }
		.ard-cm-phone .empty { color: #8c8f94; font-size: 12px; text-align: center; }
		.ard-cm-pickers { display: grid; grid-template-columns: 1fr 1fr; gap: 18px; }
		.ard-cm-picker h3 { margin: 0 0 6px; font-size: 14px; }
		.ard-cm-chosen { display: flex; flex-wrap: wrap; gap: 6px; min-height: 30px; margin-bottom: 8px; }
		.ard-cm-chip { display: inline-flex; align-items: center; gap: 6px; background: #e7f6f6; border: 1px solid #1ca5a8; border-radius: 999px; padding: 3px 6px 3px 4px; font-size: 12px; }
		.ard-cm-chip img { width: 22px; height: 22px; border-radius: 50%; object-fit: cover; }
		.ard-cm-chip button { border: 0; background: none; cursor: pointer; color: #50575e; font-size: 14px; line-height: 1; padding: 0 2px; }
		.ard-cm-none { color: #8c8f94; font-size: 12px; align-self: center; }
		.ard-cm-search { width: 100%; margin-bottom: 6px; }
		.ard-cm-list { max-height: 260px; overflow: auto; border: 1px solid #dcdcde; border-radius: 8px; }
		.ard-cm-item { display: flex; align-items: center; gap: 10px; padding: 6px 10px; cursor: pointer; border-top: 1px solid #f0f0f1; }
		.ard-cm-item:first-child { border-top: 0; }
		.ard-cm-item:hover { background: #f6f7f7; }
		.ard-cm-item img, .ard-cm-item .ph { width: 34px; height: 34px; border-radius: 6px; object-fit: cover; background: #f0f0f1; flex: none; }
		.ard-cm-item .txt { flex: 1; min-width: 0; }
		.ard-cm-item .txt strong { display: block; font-size: 13px; }
		.ard-cm-item .txt span { display: block; color: #646970; font-size: 11px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
		.ard-cm-item.is-on { background: #e7f6f6; }
		.ard-cm-actions { display: flex; align-items: center; gap: 14px; margin-top: 6px; }
		.ard-cm-actions .button-primary { background: #1ca5a8; border-color: #1ca5a8; padding: 4px 22px; }
		.ard-cm-actions .button-primary:hover { background: #178a8d; border-color: #178a8d; }
		.ard-cm-unsaved { color: #996800; font-size: 13px; display: none; }
		.is-off-section { opacity: .55; }
		@media (max-width: 960px) { .ard-cm-layout, .ard-cm-pickers { grid-template-columns: 1fr; } }
	</style>
	<div class="wrap ard-cm-wrap">
		<h1>Menù combinati</h1>
		<p class="ard-cm-intro">Quando nel carrello dell'app c'è una poké senza bibite né dessert, dopo «Procedere» l'app propone il menù. Se il cliente lo salta, può proporre una bibita. I prodotti si scelgono per nome e valgono per tutte le sedi: ogni sede mostra solo quelli che vende.
			<a href="<?php echo esc_url( $refresh_url ); ?>">Aggiorna l'elenco dei prodotti</a></p>

		<form method="post" id="ard-cm-form">
			<?php wp_nonce_field( 'ard_save_combo_menu', 'ard_combo_nonce' ); ?>

			<div class="ard-cm-card" data-section="combo">
				<h2>1. Pagina «Crea Menù»
					<label class="ard-cm-switch"><input type="checkbox" name="ard_combo_enabled" value="1" <?php checked( $settings['enabled'] ); ?> data-toggle-section="combo"><span class="knob"></span><span class="lbl"><?php echo $settings['enabled'] ? 'Attiva' : 'Spenta'; ?></span></label>
				</h2>
				<p class="desc">Il prezzo è quanto si aggiunge alla poké. Puoi spegnere una singola offerta.</p>
				<div class="ard-cm-layout">
					<div class="ard-cm-offers">
						<?php foreach ( $offers as $key => $offer ) :
							$o = $settings['offers'][ $key ]; ?>
							<div class="ard-cm-offer" data-offer="<?php echo esc_attr( $key ); ?>">
								<label class="ard-cm-switch"><input type="checkbox" name="ard_combo_offer[<?php echo esc_attr( $key ); ?>][enabled]" value="1" <?php checked( $o['enabled'] ); ?>><span class="knob"></span></label>
								<span class="name"><?php echo esc_html( $offer['label'] ); ?></span>
								<span class="ard-cm-price"><span>+ CHF</span><input type="number" min="0" step="0.05" name="ard_combo_offer[<?php echo esc_attr( $key ); ?>][price]" value="<?php echo esc_attr( number_format( (float) $o['price'], 2, '.', '' ) ); ?>"></span>
							</div>
						<?php endforeach; ?>
						<div class="ard-cm-pickers" style="margin-top:16px">
							<?php ARD_combo_render_picker( 'waters', 'Acque del menù', 'Il cliente sceglie quale.', $settings['waters'], $catalog ); ?>
							<?php ARD_combo_render_picker( 'desserts', 'Dessert del menù', 'Il cliente sceglie quale.', $settings['desserts'], $catalog ); ?>
						</div>
					</div>
					<div class="ard-cm-phone" aria-label="Anteprima nell'app">
						<h3>Crea il tuo Menù</h3>
						<div id="ard-cm-preview-combo"></div>
						<div class="skip">Salta</div>
					</div>
				</div>
			</div>

			<div class="ard-cm-card" data-section="drinks">
				<h2>2. Pagina «Aggiungi una bibita»
					<label class="ard-cm-switch"><input type="checkbox" name="ard_combo_drinks_enabled" value="1" <?php checked( $settings['drinks_enabled'] ); ?> data-toggle-section="drinks"><span class="knob"></span><span class="lbl"><?php echo $settings['drinks_enabled'] ? 'Attiva' : 'Spenta'; ?></span></label>
				</h2>
				<p class="desc">Compare solo se il cliente ha premuto «Salta» sul menù. Le bibite si aggiungono al loro prezzo normale con un tocco.</p>
				<div class="ard-cm-layout">
					<div class="ard-cm-pickers" style="grid-template-columns:1fr">
						<?php ARD_combo_render_picker( 'drinks', 'Bibite proposte', 'Nell\'ordine in cui le scegli.', $settings['drinks'], $catalog ); ?>
					</div>
					<div class="ard-cm-phone" aria-label="Anteprima nell'app">
						<h3>Aggiungi una bibita?</h3>
						<div id="ard-cm-preview-drinks"></div>
						<div class="skip">No grazie</div>
					</div>
				</div>
			</div>

			<div class="ard-cm-actions">
				<?php submit_button( 'Salva menù combinati', 'primary', 'submit', false ); ?>
				<span class="ard-cm-unsaved" id="ard-cm-unsaved">Modifiche non salvate</span>
			</div>
		</form>
	</div>
	<script>
	(function () {
		var form = document.getElementById('ard-cm-form');
		var catalog = <?php echo wp_json_encode( $catalog ); ?>;
		var labels = <?php echo wp_json_encode( wp_list_pluck( $offers, 'label' ) ); ?>;
		function esc(s) { var d = document.createElement('div'); d.textContent = s == null ? '' : String(s); return d.innerHTML; }
		function money(v) { return 'CHF ' + Number(v || 0).toFixed(2); }

		function chosen(list) {
			return Array.prototype.map.call(form.querySelectorAll('input[name="ard_combo_' + list + '[]"]'), function (i) { return i.value; });
		}
		function renderChips(picker) {
			var list = picker.dataset.list, box = picker.querySelector('.ard-cm-chosen'), keys = chosen(list);
			box.querySelectorAll('.ard-cm-chip,.ard-cm-none').forEach(function (n) { n.remove(); });
			if (!keys.length) { box.insertAdjacentHTML('beforeend', '<span class="ard-cm-none">Nessun prodotto scelto</span>'); }
			keys.forEach(function (k) {
				var p = catalog[k] || { name: k };
				box.insertAdjacentHTML('beforeend', '<span class="ard-cm-chip">' + (p.image ? '<img src="' + esc(p.image) + '" alt="">' : '') + esc(p.name) + '<button type="button" data-remove="' + esc(k) + '" aria-label="Togli ' + esc(p.name) + '">×</button></span>');
			});
			picker.querySelectorAll('.ard-cm-item').forEach(function (it) { it.classList.toggle('is-on', keys.indexOf(it.dataset.key) !== -1); });
		}
		function toggle(picker, key) {
			var list = picker.dataset.list, existing = form.querySelector('input[name="ard_combo_' + list + '[]"][value="' + CSS.escape(key) + '"]');
			if (existing) { existing.remove(); } else { picker.insertAdjacentHTML('beforeend', '<input type="hidden" name="ard_combo_' + list + '[]" value="' + esc(key) + '">'); }
			renderChips(picker); preview(); dirty();
		}
		function preview() {
			var box = document.getElementById('ard-cm-preview-combo'), html = '';
			form.querySelectorAll('.ard-cm-offer').forEach(function (row) {
				if (!row.querySelector('input[type=checkbox]').checked) return;
				html += '<div class="row"><span>' + esc(labels[row.dataset.offer]) + '</span><b>+ ' + money(row.querySelector('input[type=number]').value) + '</b></div>';
			});
			box.innerHTML = html || '<div class="empty">Nessuna offerta accesa</div>';
			var drinks = chosen('drinks').slice(0, 4), dh = '';
			drinks.forEach(function (k) { var p = catalog[k] || { name: k }; dh += '<div class="row"><span>' + esc(p.name) + '</span><b>' + (p.price != null ? money(p.price) : '') + '</b></div>'; });
			document.getElementById('ard-cm-preview-drinks').innerHTML = dh || '<div class="empty">Nessuna bibita scelta</div>';
		}
		function sections() {
			form.querySelectorAll('[data-toggle-section]').forEach(function (sw) {
				var card = form.querySelector('[data-section="' + sw.dataset.toggleSection + '"]');
				card.classList.toggle('is-off-section', !sw.checked);
				sw.parentNode.querySelector('.lbl').textContent = sw.checked ? 'Attiva' : 'Spenta';
				card.querySelectorAll('.ard-cm-layout').forEach(function (l) { l.style.opacity = sw.checked ? '' : '.55'; });
			});
		}
		function dirty() { document.getElementById('ard-cm-unsaved').style.display = 'inline'; }

		form.querySelectorAll('.ard-cm-picker').forEach(function (picker) {
			renderChips(picker);
			picker.addEventListener('click', function (e) {
				var rm = e.target.closest('[data-remove]'); if (rm) { toggle(picker, rm.dataset.remove); return; }
				var it = e.target.closest('.ard-cm-item'); if (it) { toggle(picker, it.dataset.key); }
			});
			picker.addEventListener('keydown', function (e) {
				var it = e.target.closest('.ard-cm-item');
				if (it && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); toggle(picker, it.dataset.key); }
			});
			picker.querySelector('.ard-cm-search').addEventListener('input', function (e) {
				var q = e.target.value.toLowerCase();
				picker.querySelectorAll('.ard-cm-item').forEach(function (it) { it.style.display = !q || it.dataset.search.indexOf(q) !== -1 ? '' : 'none'; });
			});
		});
		form.addEventListener('input', function () { preview(); sections(); dirty(); });
		form.addEventListener('change', function () { preview(); sections(); dirty(); });
		preview(); sections();
		document.getElementById('ard-cm-unsaved').style.display = 'none';
	})();
	</script>
	<?php
}

function ARD_combo_render_picker( $list, $title, $hint, array $selected, array $catalog ) {
	?>
	<div class="ard-cm-picker" data-list="<?php echo esc_attr( $list ); ?>">
		<h3><?php echo esc_html( $title ); ?> <span style="font-weight:400;color:#646970;font-size:12px"><?php echo esc_html( $hint ); ?></span></h3>
		<div class="ard-cm-chosen"></div>
		<?php foreach ( $selected as $key ) : ?>
			<input type="hidden" name="ard_combo_<?php echo esc_attr( $list ); ?>[]" value="<?php echo esc_attr( $key ); ?>">
		<?php endforeach; ?>
		<input type="search" class="ard-cm-search" placeholder="Cerca un prodotto…" aria-label="Cerca un prodotto per <?php echo esc_attr( $title ); ?>">
		<div class="ard-cm-list" role="listbox" aria-multiselectable="true">
			<?php if ( ! $catalog ) : ?>
				<p class="ard-cm-none" style="padding:10px">Nessun prodotto trovato nelle sedi.</p>
			<?php endif; ?>
			<?php foreach ( $catalog as $key => $p ) :
				$sedi = count( $p['sedi'] ) === count( ARD_payment_methods_sites() ) ? 'tutte le sedi' : implode( ', ', $p['sedi'] ); ?>
				<div class="ard-cm-item" role="option" tabindex="0" data-key="<?php echo esc_attr( $key ); ?>" data-search="<?php echo esc_attr( strtolower( $p['name'] . ' ' . $p['category'] ) ); ?>">
					<?php if ( $p['image'] ) : ?><img src="<?php echo esc_url( $p['image'] ); ?>" alt="" loading="lazy"><?php else : ?><span class="ph"></span><?php endif; ?>
					<span class="txt"><strong><?php echo esc_html( $p['name'] ); ?></strong><span><?php echo esc_html( trim( $p['category'] . ' · ' . ( null !== $p['price'] ? 'CHF ' . number_format( (float) $p['price'], 2 ) : '' ) . ' · ' . $sedi, ' ·' ) ); ?></span></span>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
	<?php
}

/* ------------------------------------------------------------------- REST */

add_action( 'rest_api_init', function () {
	register_rest_route( 'mobile-admin/v1', '/combo-menu', array(
		'methods'             => 'GET',
		'callback'            => 'ARD_rest_get_combo_menu',
		'permission_callback' => '__return_true',
		'args'                => array(
			'site' => array( 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ),
		),
	) );
} );

/**
 * GET /wp-json/mobile-admin/v1/combo-menu?site=biasca.littleinka.ch
 *   → { enabled, offers: [ { key, label, price, parts: [water|dessert] } ],
 *       waters: [product], desserts: [product], drinks_enabled, drinks: [product],
 *       poke_category_ids: [int], skip_category_ids: [int], skip_product_ids: [int] }
 * product = { id, name, price, image }. Only products this sede sells and has
 * in stock. "enabled" is false when the sede could not show a usable page.
 */
function ARD_rest_get_combo_menu( WP_REST_Request $request ) {
	$host = ARD_payment_methods_normalize_host( $request->get_param( 'site' ) );
	if ( ! array_key_exists( $host, ARD_payment_methods_sites() ) ) {
		return new WP_Error( 'ard_unknown_site', 'Sede sconosciuta', array( 'status' => 404 ) );
	}

	$cache_key = 'ard_combo_' . md5( $host );
	$data      = get_site_transient( $cache_key );
	if ( ! is_array( $data ) ) {
		$data = ARD_combo_build_for_host( $host );
		set_site_transient( $cache_key, $data, 5 * MINUTE_IN_SECONDS );
	}

	$response = rest_ensure_response( $data );
	$response->header( 'Cache-Control', 'no-cache, no-store, must-revalidate' );
	$response->header( 'X-LiteSpeed-Cache-Control', 'no-cache' );
	return $response;
}

function ARD_combo_build_for_host( $host ) {
	$settings = ARD_combo_settings();
	$empty    = array(
		'enabled'           => false,
		'offers'            => array(),
		'waters'            => array(),
		'desserts'          => array(),
		'drinks_enabled'    => false,
		'drinks'            => array(),
		'poke_category_ids' => array(),
		'skip_category_ids' => array(),
		'skip_product_ids'  => array(),
	);
	$blog_id = ARD_combo_blog_id( $host );
	if ( ! $blog_id ) {
		return $empty;
	}

	switch_to_blog( $blog_id );
	$products = ARD_combo_blog_products();
	$poke_ids = ARD_combo_blog_poke_categories();
	restore_current_blog();

	$skip_categories = array();
	$skip_products   = array();
	$resolve         = static function ( array $keys ) use ( $products, &$skip_categories, &$skip_products ) {
		$out = array();
		foreach ( $keys as $key ) {
			if ( ! isset( $products[ $key ] ) ) {
				continue;
			}
			$p = $products[ $key ];
			// A drink/dessert already in the cart (even out of stock now) means no offer.
			$skip_products[] = $p['id'];
			foreach ( $p['categories'] as $cat ) {
				$skip_categories[] = $cat['id'];
			}
			if ( ! $p['in_stock'] || null === $p['price'] ) {
				continue;
			}
			$out[] = array( 'id' => $p['id'], 'name' => $p['name'], 'price' => $p['price'], 'image' => $p['image'] );
		}
		return $out;
	};

	$data             = $empty;
	$data['waters']   = $resolve( $settings['waters'] );
	$data['desserts'] = $resolve( $settings['desserts'] );
	$data['drinks']   = $resolve( $settings['drinks'] );

	foreach ( ARD_combo_offers_catalog() as $key => $offer ) {
		$o = $settings['offers'][ $key ];
		if ( ! $o['enabled'] ) {
			continue;
		}
		// An offer is shown only if this sede has something for every part.
		foreach ( $offer['parts'] as $part ) {
			if ( empty( $data[ $part . 's' ] ) ) {
				continue 2;
			}
		}
		$data['offers'][] = array( 'key' => $key, 'label' => $offer['label'], 'price' => (float) $o['price'], 'parts' => $offer['parts'] );
	}

	$data['enabled']           = $settings['enabled'] && ! empty( $data['offers'] );
	$data['drinks_enabled']    = $settings['drinks_enabled'] && ! empty( $data['drinks'] );
	$data['poke_category_ids'] = array_values( array_unique( $poke_ids ) );
	// Poké categories never count as "drink/dessert" even if a chosen product sits in one.
	$data['skip_category_ids'] = array_values( array_diff( array_unique( $skip_categories ), $data['poke_category_ids'] ) );
	$data['skip_product_ids']  = array_values( array_unique( $skip_products ) );
	return $data;
}
