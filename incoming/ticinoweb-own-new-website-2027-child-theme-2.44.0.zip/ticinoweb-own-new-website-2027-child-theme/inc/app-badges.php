<?php
/**
 * Badge ufficiali «App Store» e «Google Play» nella lingua della pagina.
 *
 * Uso nell'editor (blocco Shortcode):
 * [tw_app_badges apple="https://apps.apple.com/app/id…" google="https://play.google.com/store/apps/details?id=…"]
 * Si può indicare anche un solo store. Le immagini sono quelle ufficiali di Apple e Google
 * (assets/images/store-badges), in italiano, inglese, francese e tedesco; per le altre lingue l'inglese.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_shortcode( 'tw_app_badges', static function ( $atts ) {
	$atts  = shortcode_atts( array( 'apple' => '', 'google' => '' ), $atts, 'tw_app_badges' );
	$lang  = strtolower( substr( determine_locale(), 0, 2 ) );
	$langs = array(
		'it' => array( 'apple' => 'it-it', 'apple_alt' => 'Scarica su App Store', 'google_alt' => 'Disponibile su Google Play' ),
		'en' => array( 'apple' => 'en-us', 'apple_alt' => 'Download on the App Store', 'google_alt' => 'Get it on Google Play' ),
		'fr' => array( 'apple' => 'fr-fr', 'apple_alt' => 'Télécharger dans l’App Store', 'google_alt' => 'Disponible sur Google Play' ),
		'de' => array( 'apple' => 'de-de', 'apple_alt' => 'Laden im App Store', 'google_alt' => 'Jetzt bei Google Play' ),
	);
	if ( ! isset( $langs[ $lang ] ) ) {
		$lang = 'en';
	}
	$l    = $langs[ $lang ];
	$base = get_stylesheet_directory_uri() . '/assets/images/store-badges/';
	$out  = '';
	$apple  = esc_url( $atts['apple'], array( 'https' ) );
	$google = esc_url( $atts['google'], array( 'https' ) );
	if ( $apple ) {
		$out .= sprintf(
			'<a class="tw-app-badges__link" href="%1$s" target="_blank" rel="noopener"><img src="%2$s" alt="%3$s" width="144" height="48" decoding="async" loading="lazy"></a>',
			$apple,
			esc_url( $base . 'app-store-badge-' . $l['apple'] . '.svg' ),
			esc_attr( $l['apple_alt'] )
		);
	}
	if ( $google ) {
		$out .= sprintf(
			'<a class="tw-app-badges__link" href="%1$s" target="_blank" rel="noopener"><img src="%2$s" alt="%3$s" width="163" height="48" decoding="async" loading="lazy"></a>',
			$google,
			esc_url( $base . 'google-play-badge-' . $lang . '.png' ),
			esc_attr( $l['google_alt'] )
		);
	}
	// translate="no": tW Translate non deve tradurre i testi alternativi, già nella lingua giusta.
	return $out ? '<p class="tw-app-badges" translate="no">' . $out . '</p>' : '';
} );
