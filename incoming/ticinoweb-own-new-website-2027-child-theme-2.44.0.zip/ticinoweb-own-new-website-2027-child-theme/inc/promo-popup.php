<?php
/**
 * Popup promozione: mostra i dati di ticinoWEB CMS → Promozioni (parent).
 *
 * Nessun dato nel tema: titolo, testo, immagine, link, date di inizio/fine e
 * l'interruttore "disattiva promozioni" arrivano dalle opzioni del parent
 * (`ticinoweb_promozioni_*`). Fuori dal periodo impostato il parent svuota le
 * opzioni sul sito pubblico, quindi il popup non viene stampato.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Dati della promozione da mostrare, oppure array vuoto se non c'è nulla. */
function tw_promo_popup_data() {
	if ( get_option( 'ticinoweb_disable_promozioni' ) ) {
		return array();
	}
	if ( function_exists( 'ticinoweb_promozioni_is_active' ) && ! ticinoweb_promozioni_is_active() ) {
		return array();
	}
	$data = array(
		'title' => trim( (string) get_option( 'ticinoweb_promozioni_title', '' ) ),
		'text'  => trim( (string) get_option( 'ticinoweb_promozioni_text', '' ) ),
		'image' => trim( (string) get_option( 'ticinoweb_promozioni_image', '' ) ),
		'link'  => trim( (string) get_option( 'ticinoweb_promozioni_link', '' ) ),
	);
	if ( '' === $data['title'] && '' === $data['text'] && '' === $data['image'] ) {
		return array();
	}
	return $data;
}

/** Promozione attiva su una pagina pubblica: non nelle pagine di acquisto, nell'editor o nelle anteprime. */
function tw_promo_popup_is_active() {
	if ( is_admin() || is_feed() || is_404() || is_customize_preview() || is_preview() ) {
		return false;
	}
	if ( function_exists( 'is_cart' ) && ( is_cart() || is_checkout() ) ) {
		return false;
	}
	return ! empty( tw_promo_popup_data() );
}

/**
 * Template delle pagine interne in cui il popup compare oltre alla home (in ogni lingua):
 * la pagina «Siti Web», dove arriva chi cerca un sito nuovo o un restyling.
 */
const TW_PROMO_POPUP_PAGE_TEMPLATES = array( 'page-siti-web.php' );

/** Il popup compare sulla home page e sulle pagine con i template elencati sopra (in ogni lingua). */
function tw_promo_popup_should_show() {
	if ( ! tw_promo_popup_is_active() ) {
		return false;
	}
	return is_front_page() || is_page_template( TW_PROMO_POPUP_PAGE_TEMPLATES );
}

/** Chiave della promozione: cambia quando cambiano testo, immagine, link o data di fine. */
function tw_promo_popup_key() {
	return substr( md5( wp_json_encode( tw_promo_popup_data() ) . get_option( 'ticinoweb_promozioni_end', '' ) ), 0, 12 );
}

/** Numero massimo di visite al sito in cui il popup può comparire. */
const TW_PROMO_POPUP_MAX_VISITS = 3;

/*
 * Conta le visite al sito su ogni pagina, non solo sulla home: una visita è una sessione del
 * browser (si conta alla prima pagina vista). Script in linea di poche righe, nessun file in più;
 * il conteggio vive nel browser, quindi funziona anche con le pagine in cache.
 */
add_action( 'wp_footer', static function () {
	if ( ! tw_promo_popup_is_active() ) {
		return;
	}
	?>
	<script>(function(k){try{var s='tw-promo-s-'+k,v='tw-promo-v-'+k;if(!sessionStorage.getItem(s)){sessionStorage.setItem(s,'1');localStorage.setItem(v,String((parseInt(localStorage.getItem(v),10)||0)+1));}}catch(e){}})(<?php echo wp_json_encode( tw_promo_popup_key() ); ?>);</script>
	<?php
}, 59 );

add_action( 'wp_enqueue_scripts', static function () {
	if ( ! tw_promo_popup_should_show() ) {
		return;
	}
	$version = wp_get_theme()->get( 'Version' );
	wp_enqueue_style( 'tw-promo-popup', get_stylesheet_directory_uri() . '/assets/css/promo-popup.css', array( 'ticinoweb-child-site' ), $version );
	wp_enqueue_script( 'tw-promo-popup', get_stylesheet_directory_uri() . '/assets/js/promo-popup.js', array(), $version, true );
	wp_script_add_data( 'tw-promo-popup', 'strategy', 'defer' );
}, 30 );

add_action( 'wp_footer', static function () {
	if ( ! tw_promo_popup_should_show() ) {
		return;
	}
	$d    = tw_promo_popup_data();
	$key  = tw_promo_popup_key();
	$link = $d['link'];
	$ext  = $link && wp_parse_url( $link, PHP_URL_HOST ) && wp_parse_url( $link, PHP_URL_HOST ) !== wp_parse_url( home_url(), PHP_URL_HOST );
	$alt  = $d['title'] ?: __( 'Promozione ticinoWEB', 'ticinoweb-child-theme' );
	?>
	<div class="tw-promo" id="tw-promo" data-key="<?php echo esc_attr( $key ); ?>" data-max-visits="<?php echo (int) TW_PROMO_POPUP_MAX_VISITS; ?>" role="dialog" aria-modal="true" aria-labelledby="tw-promo-title" hidden>
		<div class="tw-promo__overlay" data-tw-promo-close></div>
		<div class="tw-promo__card">
			<button type="button" class="tw-promo__close" data-tw-promo-close aria-label="<?php esc_attr_e( 'Chiudi la promozione', 'ticinoweb-child-theme' ); ?>">
				<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12"/></svg>
			</button>
			<?php if ( $d['image'] ) : ?>
				<img class="tw-promo__img" src="<?php echo esc_url( $d['image'] ); ?>" alt="<?php echo esc_attr( $alt ); ?>" decoding="async">
			<?php endif; ?>
			<div class="tw-promo__body">
				<p class="tw-promo__kicker"><?php esc_html_e( 'Offerta speciale', 'ticinoweb-child-theme' ); ?></p>
				<?php if ( $d['title'] ) : ?>
					<h2 class="tw-promo__title" id="tw-promo-title"><?php echo esc_html( $d['title'] ); ?></h2>
				<?php endif; ?>
				<?php if ( $d['text'] ) : ?>
					<div class="tw-promo__text"><?php echo wp_kses_post( wpautop( $d['text'] ) ); ?></div>
				<?php endif; ?>
				<div class="tw-promo__actions">
					<?php if ( $link ) : ?>
						<a class="tw-promo__cta" href="<?php echo esc_url( $link ); ?>"<?php echo $ext ? ' target="_blank" rel="noopener"' : ''; ?>>
							<?php esc_html_e( 'Scopri l\'offerta', 'ticinoweb-child-theme' ); ?> <span aria-hidden="true">→</span>
						</a>
					<?php endif; ?>
					<button type="button" class="tw-promo__dismiss" data-tw-promo-close><?php esc_html_e( 'Continua a navigare', 'ticinoweb-child-theme' ); ?></button>
				</div>
			</div>
		</div>
	</div>
	<?php
}, 60 );
