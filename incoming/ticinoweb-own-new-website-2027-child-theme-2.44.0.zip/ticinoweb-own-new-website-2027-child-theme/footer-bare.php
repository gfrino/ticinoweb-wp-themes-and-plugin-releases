<?php
/**
 * Chiusura pagina senza footer del sito: solo gli script (wp_footer). Per pagine «schermo»
 * come la Classifica BNI, che si guardano dal telefono durante il meeting.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
wp_footer();
?>
</body>
</html>
